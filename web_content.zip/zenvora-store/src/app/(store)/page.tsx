import Image from "next/image";
import Link from "next/link";
import { ArrowRight, SparkIcon, StarIcon, TruckIcon, LeafIcon, ShieldIcon } from "@/components/icons";
import { ProductCard } from "@/components/store/ProductCard";
import { Badge, LinkButton, SectionHeading } from "@/components/ui";
import { NewsletterForm } from "@/components/store/NewsletterForm";
import { getBestSellers, getCollections, listProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

const HERO_IMAGE =
  "https://images.pexels.com/photos/5570222/pexels-photo-5570222.jpeg?auto=compress&cs=tinysrgb&w=1200&h=1500&fit=crop";
const HERO_IMAGE_2 =
  "https://images.pexels.com/photos/28755965/pexels-photo-28755965.jpeg?auto=compress&cs=tinysrgb&w=800&h=1000&fit=crop";

const TESTIMONIALS = [
  {
    quote:
      "Ordered on a Tuesday, arrived Thursday in paper-only packaging. The vase is heavier and prettier than the photos.",
    name: "Marisol D.",
    location: "Austin, TX",
    rating: 5,
  },
  {
    quote:
      "Third order from Zenvora. Their support answered in 40 minutes and replaced a candle that cracked in transit — no return needed.",
    name: "Jordan K.",
    location: "Brooklyn, NY",
    rating: 5,
  },
  {
    quote:
      "The Aurora headphones genuinely compete with pairs twice the price. I use them six hours a day and the battery lasts the week.",
    name: "Theo R.",
    location: "Portland, OR",
    rating: 5,
  },
  {
    quote:
      "I've been hunting for a tote that isn't fast fashion for years. The leather has already started to soften at the handles.",
    name: "Amara O.",
    location: "Chicago, IL",
    rating: 5,
  },
];

export default async function HomePage() {
  const [collections, bestSellers, newArrivals, saleItems] = await Promise.all([
    getCollections(),
    getBestSellers(8),
    listProducts({ sort: "newest", limit: 8 }),
    listProducts({ query: "sale", limit: 4 }),
  ]);

  const featured = (saleItems.items.length >= 4 ? saleItems.items : newArrivals.items).slice(0, 4);
  const heroCollection = collections[0];

  return (
    <>
      {/* ---------------------------------------------------------- hero */}
      <section className="relative overflow-hidden border-b border-line bg-paper">
        <div className="mx-auto grid max-w-[1400px] items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:py-20">
          <div className="animate-rise">
            <Badge tone="moss" className="mb-5">
              <SparkIcon className="h-3.5 w-3.5" /> New season · Spring collection
            </Badge>
            <h1 className="font-display text-[clamp(2.6rem,6.4vw,4.6rem)] leading-[0.98] font-medium">
              Things worth
              <span className="relative ml-3 inline-block">
                keeping
                <svg
                  viewBox="0 0 200 12"
                  preserveAspectRatio="none"
                  className="absolute -bottom-1 left-0 h-3 w-full text-clay"
                  aria-hidden="true"
                >
                  <path d="M2 8c40-6 90-7 196-3" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                </svg>
              </span>
              ,<br />
              made by people
              <br />
              you could meet.
            </h1>
            <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-ink-2">
              Zenvora is a small independent store for ceramics, audio, wellness and leather goods — sourced
              directly from 24 family-run workshops and shipped plastic-free from Portland.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <LinkButton href="/collections" size="lg">
                Shop the collection <ArrowRight className="h-4 w-4" />
              </LinkButton>
              <LinkButton href="/pages/about" variant="outline" size="lg">
                Meet the makers
              </LinkButton>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4 border-t border-line pt-6">
              {[
                { value: "24", label: "Independent workshops" },
                { value: "4.9★", label: "Average from 1,284 reviews" },
                { value: "30 days", label: "Free returns, no questions" },
              ].map((stat) => (
                <div key={stat.label}>
                  <dt className="font-display text-[26px] leading-none">{stat.value}</dt>
                  <dd className="mt-1.5 text-[12px] leading-snug text-muted">{stat.label}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <div className="relative aspect-4/5 overflow-hidden rounded-[28px] bg-paper-2 shadow-[0_40px_90px_rgba(25,21,18,0.18)]">
              <Image
                src={HERO_IMAGE}
                alt="A sunlit living room styled with Zenvora ceramics and textiles"
                fill
                priority
                sizes="(max-width: 1024px) 100vw, 52vw"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-4 hidden w-44 overflow-hidden rounded-2xl border-4 border-paper bg-paper-2 shadow-xl sm:block lg:-left-10 lg:w-52">
              <div className="relative aspect-4/5">
                <Image src={HERO_IMAGE_2} alt="Editorial styling detail" fill sizes="200px" className="object-cover" />
              </div>
            </div>
            {heroCollection ? (
              <Link
                href={`/collections/${heroCollection.handle}`}
                className="absolute -top-3 right-2 flex items-center gap-2 rounded-full bg-surface px-4 py-2.5 text-[12.5px] font-bold shadow-lg transition hover:bg-ink hover:text-paper lg:right-6"
              >
                <span className="relative h-7 w-7 overflow-hidden rounded-full bg-paper-2">
                  {heroCollection.image ? <Image src={heroCollection.image} alt="" fill sizes="28px" className="object-cover" /> : null}
                </span>
                {heroCollection.title}
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            ) : null}
          </div>
        </div>
      </section>

      {/* --------------------------------------------------- value strip */}
      <section className="border-b border-line bg-surface">
        <div className="mx-auto grid max-w-[1400px] gap-6 px-4 py-7 sm:grid-cols-3 sm:px-6">
          {[
            { icon: TruckIcon, title: "Free carbon-neutral shipping", copy: "On orders over $75, delivered in 4–7 days." },
            { icon: ShieldIcon, title: "Two-year guarantee", copy: "We repair or replace anything we sell." },
            { icon: LeafIcon, title: "Plastic-free, always", copy: "Paper tape, mushroom foam, recycled boxes." },
          ].map((item) => (
            <div key={item.title} className="flex items-center gap-3.5">
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-paper text-clay">
                <item.icon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[13.5px] font-bold">{item.title}</p>
                <p className="text-[12.5px] text-muted">{item.copy}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --------------------------------------------------- collections */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:py-20">
        <SectionHeading
          eyebrow="Browse by category"
          title="Four collections, one standard"
          copy="Everything is chosen because a maker we trust still makes it the slow way."
          action={
            <LinkButton href="/collections" variant="outline">
              All collections <ArrowRight className="h-4 w-4" />
            </LinkButton>
          }
        />
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {collections.map((collection, index) => (
            <Link
              key={collection.handle}
              href={`/collections/${collection.handle}`}
              className="group relative overflow-hidden rounded-[22px] bg-ink"
            >
              <div className={`relative w-full ${index % 2 === 0 ? "aspect-4/5" : "aspect-4/5 sm:aspect-3/4"}`}>
                {collection.image ? (
                  <Image
                    src={collection.image}
                    alt={collection.title}
                    fill
                    sizes="(max-width: 640px) 100vw, 25vw"
                    className="object-cover opacity-90 transition duration-700 group-hover:scale-105 group-hover:opacity-100"
                  />
                ) : null}
                <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5 text-paper">
                  <p className="eyebrow text-paper/70">{collection.productCount} products</p>
                  <h3 className="font-display mt-1 text-[24px] leading-tight">{collection.title}</h3>
                  <span className="mt-2 inline-flex items-center gap-1.5 text-[13px] font-semibold text-paper/85 transition group-hover:text-white">
                    Shop now <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------- best sellers */}
      <section className="border-y border-line bg-surface/70">
        <div className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:py-20">
          <SectionHeading
            eyebrow="Customer favourites"
            title="Bestsellers this month"
            copy="Ranked by units sold over the last 30 days, straight from the order book."
            action={
              <LinkButton href="/collections?sort=best-selling" variant="outline">
                View all <ArrowRight className="h-4 w-4" />
              </LinkButton>
            }
          />
          <div className="mt-9 grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
            {bestSellers.map((product, index) => (
              <ProductCard key={product.handle} product={product} priority={index < 4} />
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------- editorial */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="relative order-2 lg:order-1">
            <div className="relative aspect-16/11 overflow-hidden rounded-[26px] bg-paper-2">
              <Image
                src="https://images.pexels.com/photos/34299319/pexels-photo-34299319.jpeg?auto=compress&cs=tinysrgb&w=1200&h=840&fit=crop"
                alt="A striped stoneware mug beside dried lavender"
                fill
                sizes="(max-width: 1024px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-6 right-4 hidden max-w-[240px] rounded-2xl border border-line bg-surface p-4 shadow-xl lg:block">
              <p className="eyebrow text-clay">Studio note</p>
              <p className="mt-1.5 text-[13px] leading-relaxed text-ink-2">
                Each mug is glazed by hand in Aveiro, so the stripe never lands in quite the same place twice.
              </p>
            </div>
          </div>
          <div className="order-1 lg:order-2">
            <SectionHeading
              eyebrow="The Kiln Edit"
              title="Ceramics that survive daily life"
              copy="Fired at 1,240°C, glazed without lead, and tested in our own kitchens for six months before they ever reach the shop. Dishwasher safe, chip resistant, and repairable if the worst happens."
            />
            <ul className="mt-7 space-y-3">
              {[
                "Hand-thrown stoneware from red clay dug 40 km from the studio",
                "Reactive matte glaze — every piece is genuinely one-off",
                "Free replacement within two years if it chips or cracks",
              ].map((point) => (
                <li key={point} className="flex items-start gap-3 text-[14.5px] leading-relaxed text-ink-2">
                  <span className="mt-1.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-clay/12 text-clay">
                    <svg viewBox="0 0 24 24" className="h-3 w-3" fill="none" stroke="currentColor" strokeWidth={3}>
                      <path d="m5 13 4.5 4.5L19 7" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </span>
                  {point}
                </li>
              ))}
            </ul>
            <div className="mt-8">
              <LinkButton href="/collections/home-living" size="lg">
                Shop the Kiln Edit <ArrowRight className="h-4 w-4" />
              </LinkButton>
            </div>
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------- new in */}
      <section className="mx-auto max-w-[1400px] px-4 pb-16 sm:px-6 lg:pb-20">
        <SectionHeading
          eyebrow="Just landed"
          title="New arrivals"
          action={
            <LinkButton href="/collections?sort=newest" variant="outline">
              See everything new <ArrowRight className="h-4 w-4" />
            </LinkButton>
          }
        />
        <div className="mt-9 grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
          {newArrivals.items.slice(0, 4).map((product) => (
            <ProductCard key={product.handle} product={product} />
          ))}
        </div>
      </section>

      {/* -------------------------------------------------- testimonials */}
      <section className="border-y border-line bg-paper-2/70">
        <div className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6 lg:py-20">
          <SectionHeading
            eyebrow="1,284 verified reviews"
            title="What customers say"
            align="center"
          />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TESTIMONIALS.map((testimonial) => (
              <figure key={testimonial.name} className="flex flex-col rounded-[20px] border border-line bg-surface p-5">
                <span className="flex gap-0.5 text-gold">
                  {Array.from({ length: testimonial.rating }).map((_, index) => (
                    <StarIcon key={index} filled className="h-4 w-4" strokeWidth={1.2} />
                  ))}
                </span>
                <blockquote className="mt-3 flex-1 text-[14px] leading-relaxed text-ink-2">
                  “{testimonial.quote}”
                </blockquote>
                <figcaption className="mt-4 flex items-center gap-2.5 border-t border-line pt-3.5">
                  <span className="grid h-8 w-8 place-items-center rounded-full bg-clay/12 text-[11px] font-black text-clay">
                    {testimonial.name[0]}
                  </span>
                  <span>
                    <span className="block text-[13px] font-bold">{testimonial.name}</span>
                    <span className="block text-[11.5px] text-muted">{testimonial.location}</span>
                  </span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------------------------------------------- deals strip */}
      <section className="mx-auto max-w-[1400px] px-4 py-16 sm:px-6">
        <SectionHeading
          eyebrow="On sale now"
          title="Last of the season"
          copy="Reduced to clear — once these colourways are gone, they're gone."
        />
        <div className="mt-9 grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
          {featured.map((product) => (
            <ProductCard key={product.handle} product={product} />
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------ newsletter */}
      <section className="mx-auto max-w-[1400px] px-4 pb-20 sm:px-6">
        <div className="relative overflow-hidden rounded-[28px] bg-ink px-6 py-14 text-paper sm:px-12">
          <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-clay/25 blur-3xl" />
          <div className="relative grid gap-8 lg:grid-cols-[1.2fr_1fr] lg:items-center">
            <div>
              <p className="eyebrow text-clay-soft">The Sunday letter</p>
              <h2 className="font-display mt-3 text-[clamp(1.9rem,4vw,3rem)] leading-[1.05]">
                10% off your first order, plus early access to restocks.
              </h2>
              <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-paper/70">
                One email a week: new makers, behind-the-scenes studio visits, and members-only pricing. Unsubscribe in
                a click — we use code <span className="font-bold text-paper">WELCOME10</span> for your first order.
              </p>
            </div>
            <div className="rounded-[20px] border border-paper/15 bg-paper/8 p-5">
              <p className="mb-3 text-[13px] font-bold text-paper/85">Join 12,400 readers</p>
              <NewsletterForm compact />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
