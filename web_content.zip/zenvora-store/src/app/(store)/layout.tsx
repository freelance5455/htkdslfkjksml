import type { ReactNode } from "react";
import { CartProvider } from "@/components/cart/CartProvider";
import { Header } from "@/components/store/Header";
import { CartDrawer } from "@/components/store/CartDrawer";
import { Footer } from "@/components/store/Footer";
import { getBestSellers, getCollections } from "@/lib/catalog";

export const dynamic = "force-dynamic";

export default async function StoreLayout({ children }: { children: ReactNode }) {
  const collections = await getCollections();
  const suggestions = await getBestSellers(4);

  return (
    <CartProvider>
      <div className="flex min-h-screen flex-col">
        <Header collections={collections} />
        <main className="flex-1">{children}</main>
        <Footer collections={collections} />
        <CartDrawer suggestions={suggestions} />
      </div>
    </CartProvider>
  );
}
