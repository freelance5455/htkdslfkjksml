import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ProductGallery } from "@/components/store/ProductGallery";
import { ProductPurchase } from "@/components/store/ProductPurchase";
import { ReviewSection } from "@/components/store/ReviewSection";
import { ProductCard } from "@/components/store/ProductCard";
import { getProductByHandle, getRelatedProducts } from "@/lib/catalog";

export const dynamic = "force-dynamic";

type Params = Promise<{ handle: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { handle } = await params;
  const product = await getProductByHandle(handle);
  if (!product) return { title: "Product not found" };
  return {
    title: product.title,
    description: product.description.replace(/\n/g, " ").slice(0, 155),
    openGraph: product.images[0] ? { images: [{ url: product.images[0] }] } : undefined,
  };
}

export default async function ProductPage({ params }: { params: Params }) {
  const { handle } = await params;
  const product = await getProductByHandle(handle);
  if (!product) notFound();

  const related = await getRelatedProducts(product, 4);

  const purchaseProduct = {
    id: product.id,
    handle: product.handle,
    title: product.title,
    vendor: product.vendor,
    description: product.description,
    priceCents: product.priceCents,
    compareAtPriceCents: product.compareAtPriceCents,
    inventoryQty: product.inventoryQty,
    trackInventory: product.trackInventory,
    weightGrams: product.weightGrams,
    sku: product.sku,
    tags: product.tags,
    optionNames: product.optionNames,
    optionValues: product.optionValues,
    images: product.images,
    collectionHandle: product.collection?.handle ?? null,
    collectionTitle: product.collection?.title ?? null,
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    image: product.images,
    description: product.description.slice(0, 300),
    sku: product.sku,
    brand: { "@type": "Brand", name: product.vendor },
    offers: {
      "@type": "Offer",
      price: (product.priceCents / 100).toFixed(2),
      priceCurrency: "USD",
      availability: product.inventoryQty > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    aggregateRating: product.rating
      ? { "@type": "AggregateRating", ratingValue: product.rating, reviewCount: product.reviewCount }
      : undefined,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6 lg:py-12">
        <nav className="mb-6 flex flex-wrap items-center gap-2 text-[12.5px] text-muted">
          <Link href="/" className="hover:text-clay">Home</Link>
          <span>/</span>
          {product.collection ? (
            <>
              <Link href={`/collections/${product.collection.handle}`} className="hover:text-clay">
                {product.collection.title}
              </Link>
              <span>/</span>
            </>
          ) : null}
          <span className="font-semibold text-ink">{product.title}</span>
        </nav>

        <div className="grid gap-10 lg:grid-cols-2 lg:gap-14">
          <ProductGallery images={product.images} title={product.title} />
          <ProductPurchase
            product={purchaseProduct}
            variants={product.variants}
            rating={product.rating}
            reviewCount={product.reviewCount}
          />
        </div>

        <div className="mt-16">
          <ReviewSection
            productId={product.id}
            reviews={product.reviews}
            rating={product.rating}
            reviewCount={product.reviewCount}
          />
        </div>

        {related.length > 0 ? (
          <section className="mt-16 border-t border-line pt-14">
            <div className="flex items-end justify-between gap-4">
              <div>
                <p className="eyebrow text-clay">Pairs well with</p>
                <h2 className="font-display mt-2 text-[clamp(1.6rem,3vw,2.2rem)] leading-tight">You may also like</h2>
              </div>
              <Link href="/collections" className="hidden text-[13.5px] font-bold text-ink-2 hover:text-clay sm:block">
                View all products →
              </Link>
            </div>
            <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
              {related.map((item) => (
                <ProductCard key={item.handle} product={item} />
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </>
  );
}
