import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { Badge, LinkButton } from "@/components/ui";
import { ArrowRight, CheckIcon, PackageIcon, TruckIcon, LockIcon, MailIcon } from "@/components/icons";
import { ProductCard } from "@/components/store/ProductCard";
import { ensureSeeded, listProducts } from "@/lib/catalog";
import { formatDate, formatDateTime, money } from "@/lib/format";

export const dynamic = "force-dynamic";

type Params = Promise<{ number: string }>;
type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export const metadata: Metadata = { title: "Order status", robots: { index: false } };

export default async function OrderStatusPage({ params, searchParams }: { params: Params; searchParams: SearchParams }) {
  const { number } = await params;
  const raw = await searchParams;
  const email = (Array.isArray(raw.email) ? raw.email[0] : raw.email) ?? "";
  const confirmed = (Array.isArray(raw.confirmed) ? raw.confirmed[0] : raw.confirmed) === "1";

  await ensureSeeded();
  const orderNumber = decodeURIComponent(number).startsWith("#") ? decodeURIComponent(number) : `#${decodeURIComponent(number)}`;

  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  if (!order) notFound();
  if (email && order.email.toLowerCase() !== email.toLowerCase()) notFound();

  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  const recommended = (await listProducts({ featuredOnly: true, limit: 4 })).items;
  const fulfilled = order.fulfillmentStatus === "fulfilled";

  const timeline = [
    { label: "Order placed", detail: formatDateTime(order.createdAt), done: true },
    { label: "Payment confirmed", detail: order.paymentStatus === "paid" ? `${money(order.totalCents)} captured` : "Awaiting capture", done: order.paymentStatus === "paid" },
    { label: "Packed at our Portland studio", detail: fulfilled ? "Shipped" : "In the queue", done: fulfilled },
    { label: "Out for delivery", detail: fulfilled ? "With the carrier" : "Pending", done: fulfilled },
  ];

  const eta = (() => {
    const date = new Date(order.createdAt);
    date.setDate(date.getDate() + (order.shippingMethod === "express" ? 2 : order.shippingMethod === "overnight" ? 1 : 6));
    return date;
  })();

  return (
    <div className="mx-auto max-w-[1100px] px-4 py-10 sm:px-6 lg:py-14">
      <nav className="mb-5 flex items-center gap-2 text-[12.5px] text-muted">
        <Link href="/" className="hover:text-clay">Home</Link>
        <span>/</span>
        <Link href="/account" className="hover:text-clay">Orders</Link>
        <span>/</span>
        <span className="font-semibold text-ink">{order.orderNumber}</span>
      </nav>

      {confirmed ? (
        <div className="animate-rise mb-8 flex flex-col items-start gap-4 rounded-[24px] border border-moss/25 bg-moss/8 p-6 sm:flex-row sm:items-center">
          <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-moss text-paper">
            <CheckIcon className="h-6 w-6" strokeWidth={2.6} />
          </span>
          <div className="flex-1">
            <h1 className="font-display text-[clamp(1.6rem,3.4vw,2.2rem)] leading-tight">Thank you — your order is confirmed!</h1>
            <p className="mt-1 text-[14px] text-ink-2">
              Order <span className="font-bold">{order.orderNumber}</span> · a receipt was sent to{" "}
              <span className="font-bold">{order.email}</span>. Estimated delivery{" "}
              <span className="font-bold">{formatDate(eta)}</span>.
            </p>
          </div>
          <LinkButton href="/collections" variant="outline">
            Continue shopping <ArrowRight className="h-4 w-4" />
          </LinkButton>
        </div>
      ) : (
        <h1 className="font-display mb-6 text-[clamp(1.9rem,4vw,2.8rem)] leading-none">Order {order.orderNumber}</h1>
      )}

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="space-y-6">
          <section className="rounded-[22px] border border-line bg-surface p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className={`grid h-11 w-11 place-items-center rounded-full ${fulfilled ? "bg-moss text-paper" : "bg-clay/12 text-clay"}`}>
                  {fulfilled ? <TruckIcon className="h-5 w-5" /> : <PackageIcon className="h-5 w-5" />}
                </span>
                <div>
                  <p className="text-[15px] font-bold">{fulfilled ? "Fulfilled — on its way" : "Preparing your order"}</p>
                  <p className="text-[13px] text-muted">
                    Placed {formatDateTime(order.createdAt)} · {order.shippingMethod} shipping
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge tone={order.paymentStatus === "paid" ? "moss" : "gold"}>
                  Payment {order.paymentStatus}
                </Badge>
                <Badge tone={fulfilled ? "moss" : "neutral"}>{order.fulfillmentStatus}</Badge>
              </div>
            </div>

            <ol className="mt-6 space-y-0">
              {timeline.map((entry, index) => (
                <li key={entry.label} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <span className={`grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 ${entry.done ? "border-moss bg-moss text-paper" : "border-line bg-surface"}`}>
                      {entry.done ? <CheckIcon className="h-3.5 w-3.5" strokeWidth={3} /> : null}
                    </span>
                    {index < timeline.length - 1 ? <span className={`h-9 w-px ${entry.done ? "bg-moss/40" : "bg-line"}`} /> : null}
                  </div>
                  <div className="pb-5">
                    <p className={`text-[14px] font-bold ${entry.done ? "text-ink" : "text-muted"}`}>{entry.label}</p>
                    <p className="text-[12.5px] text-muted">{entry.detail}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>

          <section className="rounded-[22px] border border-line bg-surface">
            <div className="flex items-center justify-between border-b border-line px-6 py-4">
              <h2 className="font-display text-[20px]">Items in this order</h2>
              <span className="text-[12.5px] text-muted">{items.length} line{items.length === 1 ? "" : "s"}</span>
            </div>
            <ul className="divide-y divide-line">
              {items.map((item) => (
                <li key={item.id} className="flex gap-4 px-6 py-4">
                  <Link
                    href={item.productHandle ? `/products/${item.productHandle}` : "/collections"}
                    className="relative h-20 w-16 shrink-0 overflow-hidden rounded-xl bg-paper-2"
                  >
                    {item.image ? <Image src={item.image} alt={item.title} fill sizes="64px" className="object-cover" /> : null}
                  </Link>
                  <div className="min-w-0 flex-1">
                    <Link
                      href={item.productHandle ? `/products/${item.productHandle}` : "/collections"}
                      className="text-[14.5px] font-bold hover:text-clay"
                    >
                      {item.title}
                    </Link>
                    {item.variantTitle && item.variantTitle !== "Default Title" ? (
                      <p className="mt-0.5 text-[13px] text-muted">{item.variantTitle}</p>
                    ) : null}
                    <p className="mt-0.5 text-[12px] uppercase tracking-[0.08em] text-muted">SKU {item.sku || "—"}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[14px] font-bold">{money(item.totalCents)}</p>
                    <p className="text-[12.5px] text-muted">Qty {item.quantity}</p>
                  </div>
                </li>
              ))}
            </ul>

            <div className="space-y-2 border-t border-line px-6 py-5 text-[14px]">
              <div className="flex justify-between">
                <span className="text-ink-2">Subtotal</span>
                <span className="font-bold">{money(order.subtotalCents)}</span>
              </div>
              {order.discountCents > 0 ? (
                <div className="flex justify-between text-moss">
                  <span>Discount {order.discountCode ? `(${order.discountCode})` : ""}</span>
                  <span className="font-bold">−{money(order.discountCents)}</span>
                </div>
              ) : null}
              <div className="flex justify-between">
                <span className="text-ink-2">Shipping</span>
                <span className="font-bold">{order.shippingCents === 0 ? "Free" : money(order.shippingCents)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ink-2">Tax</span>
                <span className="font-bold">{money(order.taxCents)}</span>
              </div>
              <div className="flex items-end justify-between border-t border-line pt-3">
                <span className="text-[14px] font-bold">Total</span>
                <span className="font-display text-[26px] leading-none">{money(order.totalCents)}</span>
              </div>
            </div>
          </section>

          {order.note ? (
            <section className="rounded-[22px] border border-line bg-paper-2/60 p-6">
              <p className="eyebrow text-muted">Order notes</p>
              <p className="mt-2 text-[14px] leading-relaxed text-ink-2">{order.note}</p>
            </section>
          ) : null}
        </div>

        <aside className="space-y-4">
          <section className="rounded-[22px] border border-line bg-surface p-6">
            <h2 className="font-display text-[20px]">Delivery details</h2>
            <address className="mt-3 not-italic text-[13.5px] leading-relaxed text-ink-2">
              <span className="block font-bold text-ink">
                {order.firstName} {order.lastName}
              </span>
              {order.address1}
              {order.address2 ? <>, {order.address2}</> : null}
              <br />
              {order.city}, {order.province} {order.zip}
              <br />
              {order.country}
            </address>
            {order.phone ? <p className="mt-2 text-[13px] text-muted">{order.phone}</p> : null}
            <p className="mt-3 flex items-center gap-2 text-[13px] text-ink-2">
              <MailIcon className="h-4 w-4 text-clay" /> {order.email}
            </p>
          </section>

          <section className="rounded-[22px] border border-line bg-surface p-6">
            <h2 className="font-display text-[20px]">Payment</h2>
            <p className="mt-3 flex items-center gap-2 text-[13.5px] font-semibold">
              <LockIcon className="h-4 w-4 text-clay" />
              {order.paymentBrand.toUpperCase()} ···· {order.paymentLast4}
            </p>
            <p className="mt-1.5 text-[13px] text-muted">
              {money(order.totalCents)} · {order.paymentStatus}
            </p>
            <p className="mt-4 rounded-xl bg-paper/70 px-3.5 py-3 text-[12.5px] leading-relaxed text-ink-2">
              Need to change something? Reply to your confirmation email or contact us within 1 hour of ordering and we
              can still adjust the address or cancel.
            </p>
            <LinkButton href="/pages/contact" variant="outline" size="sm" className="mt-4 w-full">
              Contact support
            </LinkButton>
          </section>

          <section className="rounded-[22px] border border-line bg-paper-2/60 p-6">
            <p className="eyebrow text-muted">Arriving by</p>
            <p className="font-display mt-2 text-[24px] leading-tight">{formatDate(eta)}</p>
            <p className="mt-1 text-[13px] text-ink-2">
              {order.shippingMethod === "express" ? "Express" : order.shippingMethod === "overnight" ? "Overnight" : "Standard"}{" "}
              shipping · tracked
            </p>
          </section>
        </aside>
      </div>

      {recommended.length > 0 ? (
        <section className="mt-16 border-t border-line pt-12">
          <h2 className="font-display text-[clamp(1.5rem,3vw,2rem)]">Customers who bought this also liked</h2>
          <div className="mt-7 grid grid-cols-2 gap-x-4 gap-y-9 lg:grid-cols-4">
            {recommended.map((product) => (
              <ProductCard key={product.handle} product={product} />
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
