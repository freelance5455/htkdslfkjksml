import Link from "next/link";
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { StarIcon } from "@/components/icons";
import { money, pctOff } from "@/lib/format";

/* ---------------------------------------------------------------- buttons */

type ButtonVariant = "primary" | "accent" | "outline" | "ghost" | "light" | "danger";
type ButtonSize = "sm" | "md" | "lg";

const VARIANTS: Record<ButtonVariant, string> = {
  primary: "bg-ink text-paper hover:bg-ink-2 border border-ink",
  accent: "bg-clay text-white hover:brightness-110 border border-clay",
  outline: "border border-ink/25 bg-transparent text-ink hover:border-ink hover:bg-ink/5",
  ghost: "bg-transparent text-ink-2 hover:bg-ink/5 border border-transparent",
  light: "bg-surface text-ink border border-line hover:border-ink/40",
  danger: "bg-transparent text-clay border border-clay/30 hover:bg-clay hover:text-white",
};

const SIZES: Record<ButtonSize, string> = {
  sm: "h-9 px-3.5 text-[13px]",
  md: "h-11 px-5 text-sm",
  lg: "h-13 px-7 text-[15px]",
};

export function buttonClass(variant: ButtonVariant = "primary", size: ButtonSize = "md", extra = "") {
  return `inline-flex items-center justify-center gap-2 rounded-full font-semibold tracking-tight transition-all duration-200 disabled:cursor-not-allowed disabled:opacity-45 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-clay active:scale-[.985] ${VARIANTS[variant]} ${SIZES[size]} ${extra}`;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: ButtonSize;
};

export function Button({ variant = "primary", size = "md", className = "", ...props }: ButtonProps) {
  return <button className={buttonClass(variant, size, className)} {...props} />;
}

type LinkButtonProps = {
  href: string;
  children: ReactNode;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  prefetch?: boolean;
};

export function LinkButton({ href, children, variant = "primary", size = "md", className = "", prefetch }: LinkButtonProps) {
  return (
    <Link href={href} prefetch={prefetch} className={buttonClass(variant, size, className)}>
      {children}
    </Link>
  );
}

/* ----------------------------------------------------------------- badges */

export function Badge({
  children,
  tone = "neutral",
  className = "",
}: {
  children: ReactNode;
  tone?: "neutral" | "sale" | "moss" | "gold" | "ink" | "line";
  className?: string;
}) {
  const tones: Record<string, string> = {
    neutral: "bg-paper-2 text-ink-2 border-line",
    sale: "bg-clay text-white border-clay",
    moss: "bg-moss/10 text-moss border-moss/25",
    gold: "bg-gold/12 text-gold border-gold/30",
    ink: "bg-ink text-paper border-ink",
    line: "bg-transparent text-muted border-line",
  };
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-[0.1em] ${tones[tone]} ${className}`}
    >
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ price */

export function Price({
  priceCents,
  compareAtPriceCents,
  className = "",
  showSave = true,
}: {
  priceCents: number;
  compareAtPriceCents?: number | null;
  className?: string;
  showSave?: boolean;
}) {
  const off = pctOff(priceCents, compareAtPriceCents);
  return (
    <span className={`inline-flex items-baseline gap-2 ${className}`}>
      <span>{money(priceCents)}</span>
      {compareAtPriceCents && compareAtPriceCents > priceCents ? (
        <span className="text-[0.85em] text-muted line-through decoration-clay/60">{money(compareAtPriceCents)}</span>
      ) : null}
      {off && showSave ? <span className="text-[0.78em] font-bold text-clay">−{off}%</span> : null}
    </span>
  );
}

/* ------------------------------------------------------------------ stars */

export function Stars({ rating, count, size = 14, className = "" }: { rating: number | null; count?: number; size?: number; className?: string }) {
  const value = rating ?? 0;
  return (
    <span className={`inline-flex items-center gap-1.5 ${className}`}>
      <span className="inline-flex items-center gap-[1.5px] text-gold">
        {[1, 2, 3, 4, 5].map((star) => (
          <StarIcon key={star} filled={value >= star - 0.35} style={{ width: size, height: size }} strokeWidth={1.2} />
        ))}
      </span>
      {rating != null ? (
        <span className="text-[12px] font-medium text-muted">
          {rating.toFixed(1)}
          {count != null ? ` (${count})` : ""}
        </span>
      ) : null}
    </span>
  );
}

/* ------------------------------------------------------------------ forms */

export function Label({ children, htmlFor }: { children: ReactNode; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.11em] text-muted">
      {children}
    </label>
  );
}

const fieldBase =
  "w-full rounded-xl border border-line bg-surface px-3.5 py-2.5 text-[14px] text-ink placeholder:text-muted/70 transition focus:border-ink focus:outline-none focus:ring-2 focus:ring-ink/8";

export function Input({ className = "", ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`${fieldBase} ${className}`} {...props} />;
}

export function Textarea({ className = "", ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`${fieldBase} min-h-28 resize-y ${className}`} {...props} />;
}

export function Select({ className = "", children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select className={`${fieldBase} appearance-none bg-[length:14px] pr-9 ${className}`} {...props}>
      {children}
    </select>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
      {hint ? <p className="mt-1 text-[12px] text-muted">{hint}</p> : null}
    </div>
  );
}

/* ----------------------------------------------------------------- misc  */

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <span
      className={`inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent ${className}`}
      aria-label="Loading"
    />
  );
}

export function SectionHeading({
  eyebrow,
  title,
  copy,
  action,
  align = "left",
}: {
  eyebrow?: string;
  title: string;
  copy?: string;
  action?: ReactNode;
  align?: "left" | "center";
}) {
  return (
    <div
      className={`flex flex-col gap-4 ${align === "center" ? "items-center text-center" : "md:flex-row md:items-end md:justify-between"}`}
    >
      <div className={align === "center" ? "max-w-xl" : "max-w-2xl"}>
        {eyebrow ? <p className="eyebrow text-clay">{eyebrow}</p> : null}
        <h2 className="font-display mt-2 text-[clamp(1.7rem,3.4vw,2.6rem)] leading-[1.08] font-medium">{title}</h2>
        {copy ? <p className="mt-3 text-[15px] leading-relaxed text-ink-2">{copy}</p> : null}
      </div>
      {action}
    </div>
  );
}

export function Divider({ className = "" }: { className?: string }) {
  return <div className={`h-px w-full bg-line ${className}`} />;
}

export function EmptyState({ title, copy, action }: { title: string; copy: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-line bg-surface/60 px-6 py-16 text-center">
      <h3 className="font-display text-2xl">{title}</h3>
      <p className="max-w-sm text-sm text-ink-2">{copy}</p>
      {action}
    </div>
  );
}
