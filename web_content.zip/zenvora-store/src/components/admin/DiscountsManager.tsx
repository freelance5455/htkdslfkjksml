"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Discount } from "@/db/schema";
import { Badge, Button, Input, Label, Select, Spinner } from "@/components/ui";
import { CheckIcon, PlusIcon, TrashIcon } from "@/components/icons";
import { formatDate, money } from "@/lib/format";

export function DiscountsManager({ discounts }: { discounts: Discount[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(discounts);
  const [form, setForm] = useState({ code: "", type: "percentage", value: "10", minSubtotal: "0", usageLimit: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const create = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setSaved(false);
    const payload = {
      code: form.code,
      type: form.type,
      value: form.type === "percentage" ? Number(form.value) : Math.round(Number(form.value) * 100),
      minSubtotalCents: Math.round(Number(form.minSubtotal || 0) * 100),
      usageLimit: form.usageLimit ? Number(form.usageLimit) : null,
    };
    try {
      const response = await fetch("/api/admin/discounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { error?: string; discount?: Discount };
      if (!response.ok) throw new Error(data.error ?? "Could not create the discount.");
      if (data.discount) setRows((prev) => [...prev, data.discount as Discount]);
      setForm({ code: "", type: "percentage", value: "10", minSubtotal: "0", usageLimit: "" });
      setSaved(true);
      router.refresh();
    } catch (createError) {
      setError((createError as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (discount: Discount) => {
    setRows((prev) => prev.map((row) => (row.id === discount.id ? { ...row, active: !row.active } : row)));
    await fetch("/api/admin/discounts", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: discount.id, active: !discount.active }),
    });
    router.refresh();
  };

  const remove = async (discount: Discount) => {
    if (!window.confirm(`Delete ${discount.code}?`)) return;
    setRows((prev) => prev.filter((row) => row.id !== discount.id));
    await fetch("/api/admin/discounts", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: discount.id }),
    });
    router.refresh();
  };

  const describe = (discount: Discount) =>
    discount.type === "percentage"
      ? `${discount.value}% off`
      : discount.type === "fixed_amount"
        ? `${money(discount.value)} off`
        : "Free shipping";

  return (
    <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_360px]">
      <div className="overflow-hidden rounded-[20px] border border-line bg-surface">
        <div className="border-b border-line px-5 py-4">
          <h2 className="font-display text-[19px]">Active codes</h2>
          <p className="text-[12.5px] text-muted">Shoppers enter these in the bag or at checkout.</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-[13.5px]">
            <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
              <tr>
                <th className="px-5 py-3 font-bold">Code</th>
                <th className="px-4 py-3 font-bold">Discount</th>
                <th className="px-4 py-3 font-bold">Minimum</th>
                <th className="px-4 py-3 font-bold">Used</th>
                <th className="px-4 py-3 font-bold">Created</th>
                <th className="px-4 py-3 font-bold">Status</th>
                <th className="px-5 py-3 text-right font-bold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((discount) => (
                <tr key={discount.id} className="transition hover:bg-paper/50">
                  <td className="px-5 py-3 font-black tracking-wide">{discount.code}</td>
                  <td className="px-4 py-3 font-semibold">{describe(discount)}</td>
                  <td className="px-4 py-3 text-ink-2">
                    {discount.minSubtotalCents > 0 ? money(discount.minSubtotalCents) : "None"}
                  </td>
                  <td className="px-4 py-3 text-ink-2">
                    {discount.usageCount}
                    {discount.usageLimit ? ` / ${discount.usageLimit}` : ""}
                  </td>
                  <td className="px-4 py-3 text-muted">{formatDate(discount.createdAt)}</td>
                  <td className="px-4 py-3">
                    <Badge tone={discount.active ? "moss" : "neutral"}>{discount.active ? "active" : "disabled"}</Badge>
                  </td>
                  <td className="px-5 py-3">
                    <span className="flex items-center justify-end gap-1.5">
                      <Button variant="light" size="sm" onClick={() => toggle(discount)}>
                        {discount.active ? "Disable" : "Enable"}
                      </Button>
                      <button
                        type="button"
                        onClick={() => remove(discount)}
                        className="grid h-9 w-9 place-items-center rounded-full border border-line text-muted transition hover:border-clay hover:text-clay"
                        aria-label={`Delete ${discount.code}`}
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </span>
                  </td>
                </tr>
              ))}
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-12 text-center text-muted">
                    No discount codes yet — create your first one on the right.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      <form onSubmit={create} className="h-fit rounded-[20px] border border-line bg-surface p-5 xl:sticky xl:top-6">
        <h2 className="font-display text-[19px]">Create discount</h2>
        <div className="mt-4 space-y-4">
          <div>
            <Label htmlFor="code">Code</Label>
            <Input
              id="code"
              required
              value={form.code}
              onChange={(event) => {
                setForm((prev) => ({ ...prev, code: event.target.value.toUpperCase() }));
                setError(null);
              }}
              placeholder="SUMMER15"
              className="uppercase"
            />
          </div>
          <div>
            <Label htmlFor="type">Type</Label>
            <Select id="type" value={form.type} onChange={(event) => setForm((prev) => ({ ...prev, type: event.target.value }))}>
              <option value="percentage">Percentage</option>
              <option value="fixed_amount">Fixed amount</option>
              <option value="free_shipping">Free shipping</option>
            </Select>
          </div>
          {form.type !== "free_shipping" ? (
            <div>
              <Label htmlFor="value">{form.type === "percentage" ? "Percentage (%)" : "Amount ($)"}</Label>
              <Input id="value" inputMode="decimal" value={form.value} onChange={(event) => setForm((prev) => ({ ...prev, value: event.target.value }))} />
            </div>
          ) : null}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="minSubtotal">Minimum spend ($)</Label>
              <Input id="minSubtotal" inputMode="decimal" value={form.minSubtotal} onChange={(event) => setForm((prev) => ({ ...prev, minSubtotal: event.target.value }))} />
            </div>
            <div>
              <Label htmlFor="usageLimit">Usage limit</Label>
              <Input id="usageLimit" type="number" min={1} value={form.usageLimit} onChange={(event) => setForm((prev) => ({ ...prev, usageLimit: event.target.value }))} placeholder="Unlimited" />
            </div>
          </div>

          {error ? <p className="rounded-lg bg-clay/10 px-3 py-2 text-[12.5px] font-semibold text-clay">{error}</p> : null}
          {saved ? (
            <p className="flex items-center gap-2 rounded-lg bg-moss/10 px-3 py-2 text-[12.5px] font-semibold text-moss">
              <CheckIcon className="h-4 w-4" strokeWidth={2.6} /> Discount created
            </p>
          ) : null}

          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? <Spinner className="h-4 w-4" /> : <PlusIcon className="h-4 w-4" />} Create discount
          </Button>
        </div>
      </form>
    </div>
  );
}
