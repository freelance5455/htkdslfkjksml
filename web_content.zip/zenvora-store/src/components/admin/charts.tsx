import { money } from "@/lib/format";

export function SalesChart({ data }: { data: { date: string; totalCents: number; orders: number }[] }) {
  if (data.length === 0) {
    return <p className="mt-8 text-center text-[13.5px] text-muted">No sales recorded yet.</p>;
  }
  const max = Math.max(...data.map((point) => point.totalCents), 1);
  const total = data.reduce((sum, point) => sum + point.totalCents, 0);
  const orders = data.reduce((sum, point) => sum + point.orders, 0);

  return (
    <div>
      <div className="mt-4 flex flex-wrap gap-6">
        <div>
          <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-muted">Period total</p>
          <p className="font-display mt-1 text-[26px] leading-none">{money(total)}</p>
        </div>
        <div>
          <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-muted">Orders</p>
          <p className="font-display mt-1 text-[26px] leading-none">{orders}</p>
        </div>
        <div>
          <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-muted">Peak day</p>
          <p className="font-display mt-1 text-[26px] leading-none">
            {money(data.reduce((best, point) => (point.totalCents > best.totalCents ? point : best), data[0]).totalCents)}
          </p>
        </div>
      </div>

      <div className="mt-6 flex h-44 items-end gap-1.5">
        {data.map((point) => {
          const height = Math.max(4, Math.round((point.totalCents / max) * 100));
          const label = new Date(`${point.date}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" });
          return (
            <div key={point.date} className="group relative flex flex-1 flex-col items-center justify-end">
              <div
                className="w-full rounded-t-md bg-clay/85 transition group-hover:bg-clay"
                style={{ height: `${height}%` }}
                aria-label={`${label}: ${money(point.totalCents)} across ${point.orders} orders`}
              />
              <span className="mt-2 hidden text-[10px] text-muted sm:block">{label.split(" ")[1]}</span>
              <span className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-2 hidden -translate-x-1/2 whitespace-nowrap rounded-lg bg-ink px-2.5 py-1.5 text-[11px] font-bold text-paper group-hover:block">
                {label} · {money(point.totalCents)}
              </span>
            </div>
          );
        })}
      </div>
      <div className="mt-1 flex justify-between text-[11px] text-muted">
        <span>{new Date(`${data[0].date}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
        <span>
          {new Date(`${data[data.length - 1].date}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
        </span>
      </div>
    </div>
  );
}

export function Donut({ data, colors }: { data: { label: string; value: number }[]; colors: string[] }) {
  const total = data.reduce((sum, row) => sum + row.value, 0);
  if (total === 0) return <p className="mt-6 text-[13.5px] text-muted">Nothing to show yet.</p>;

  const radius = 42;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div className="mt-4 flex items-center gap-5">
      <svg viewBox="0 0 100 100" className="h-28 w-28 -rotate-90">
        <circle cx="50" cy="50" r={radius} fill="none" stroke="#efe9de" strokeWidth="13" />
        {data.map((row, index) => {
          const length = (row.value / total) * circumference;
          const circle = (
            <circle
              key={row.label}
              cx="50"
              cy="50"
              r={radius}
              fill="none"
              stroke={colors[index % colors.length]}
              strokeWidth="13"
              strokeDasharray={`${length} ${circumference - length}`}
              strokeDashoffset={-offset}
              strokeLinecap="butt"
            />
          );
          offset += length;
          return circle;
        })}
      </svg>
      <ul className="flex-1 space-y-2">
        {data.map((row, index) => (
          <li key={row.label} className="flex items-center gap-2 text-[13px]">
            <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: colors[index % colors.length] }} />
            <span className="flex-1 capitalize text-ink-2">{row.label}</span>
            <span className="font-bold">
              {row.value} · {Math.round((row.value / total) * 100)}%
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
