"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Collection, Product, Variant } from "@/db/schema";
import { Badge, Button, Input, Label, Select, Spinner, Textarea } from "@/components/ui";
import { ArrowRight, CheckIcon, PlusIcon, RefreshIcon, TrashIcon } from "@/components/icons";
import { money, slugify } from "@/lib/format";
import type { ProductInput, VariantInput } from "@/lib/admin/product-payload";

type EditableVariant = VariantInput & { id?: number };

type Props = {
  product?: Product | null;
  variants?: Variant[];
  collections: Collection[];
};

const toDollars = (cents: number | null | undefined) => (cents ? (cents / 100).toFixed(2) : "");
const toCents = (value: string) => Math.round(Number(value.replace(/[^0-9.]/g, "")) * 100 || 0);

export function ProductForm({ product, variants, collections }: Props) {
  const router = useRouter();
  const isEdit = Boolean(product);

  const [form, setForm] = useState({
    title: product?.title ?? "",
    handle: product?.handle ?? "",
    description: product?.description ?? "",
    vendor: product?.vendor ?? "Zenvora",
    collectionId: product?.collectionId ? String(product.collectionId) : "",
    status: product?.status ?? "active",
    price: toDollars(product?.priceCents ?? 0),
    compareAt: toDollars(product?.compareAtPriceCents),
    cost: toDollars(product?.costCents ?? 0),
    sku: product?.sku ?? "",
    weight: String(product?.weightGrams ?? 500),
    trackInventory: product?.trackInventory ?? true,
    featured: product?.featured ?? false,
    images: (product?.images ?? []).join("\n"),
    tags: (product?.tags ?? []).join(", "),
    option1Name: product?.optionNames?.[0] ?? "",
    option1Values: product?.optionValues?.[0]?.join(", ") ?? "",
    option2Name: product?.optionNames?.[1] ?? "",
    option2Values: product?.optionValues?.[1]?.join(", ") ?? "",
  });

  const [variantRows, setVariantRows] = useState<EditableVariant[]>(
    variants?.length
      ? variants.map((variant) => ({
          id: variant.id,
          title: variant.title,
          sku: variant.sku,
          priceCents: variant.priceCents,
          compareAtPriceCents: variant.compareAtPriceCents,
          inventoryQty: variant.inventoryQty,
          option1: variant.option1,
          option2: variant.option2,
          image: variant.image,
        }))
      : [{ title: "Default Title", sku: "", priceCents: 0, inventoryQty: 10, option1: null, option2: null, image: null }],
  );

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const imageList = useMemo(
    () => form.images.split("\n").map((line) => line.trim()).filter(Boolean),
    [form.images],
  );
  const tagList = useMemo(() => form.tags.split(",").map((tag) => tag.trim()).filter(Boolean), [form.tags]);

  const optionNames = [form.option1Name, form.option2Name].map((name) => name.trim()).filter(Boolean);
  const optionValues = [
    form.option1Values.split(",").map((value) => value.trim()).filter(Boolean),
    form.option2Values.split(",").map((value) => value.trim()).filter(Boolean),
  ].filter((values) => values.length > 0);

  const priceCents = toCents(form.price);
  const costCents = toCents(form.cost);
  const margin = priceCents > 0 ? Math.round(((priceCents - costCents) / priceCents) * 100) : 0;
  const totalInventory = variantRows.reduce((sum, row) => sum + Number(row.inventoryQty || 0), 0);

  const set = (key: keyof typeof form, value: string | boolean) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  const generateVariants = () => {
    if (optionValues.length === 0) {
      setVariantRows([{ title: "Default Title", sku: form.sku, priceCents, inventoryQty: totalInventory || 10, option1: null, option2: null, image: imageList[0] ?? null }]);
      return;
    }
    const combos = optionValues.reduce<string[][]>(
      (acc, values) => acc.flatMap((prev) => values.map((value) => [...prev, value])),
      [[]],
    );
    setVariantRows(
      combos.map((combo, index) => ({
        title: combo.join(" / ") || "Default Title",
        sku: form.sku ? `${form.sku}-${index + 1}` : "",
        priceCents,
        compareAtPriceCents: toCents(form.compareAt) || null,
        inventoryQty: variantRows[index]?.inventoryQty ?? 10,
        option1: combo[0] ?? null,
        option2: combo[1] ?? null,
        image: imageList[index % Math.max(imageList.length, 1)] ?? null,
      })),
    );
  };

  const updateVariant = (index: number, patch: Partial<EditableVariant>) => {
    setVariantRows((prev) => prev.map((row, rowIndex) => (rowIndex === index ? { ...row, ...patch } : row)));
    setSaved(false);
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);

    if (!form.title.trim()) {
      setError("A product title is required.");
      setBusy(false);
      return;
    }
    if (priceCents <= 0) {
      setError("Set a price greater than zero.");
      setBusy(false);
      return;
    }

    const payload: ProductInput = {
      title: form.title,
      handle: form.handle || slugify(form.title),
      description: form.description,
      vendor: form.vendor,
      collectionId: form.collectionId ? Number(form.collectionId) : null,
      status: form.status,
      priceCents,
      compareAtPriceCents: toCents(form.compareAt) || null,
      costCents,
      sku: form.sku,
      trackInventory: form.trackInventory,
      weightGrams: Number(form.weight) || 500,
      images: imageList,
      tags: tagList,
      optionNames,
      optionValues,
      featured: form.featured,
      variants: variantRows.map((row, index) => ({
        title: row.title || `Option ${index + 1}`,
        sku: row.sku ?? "",
        priceCents: Number(row.priceCents) || priceCents,
        compareAtPriceCents: row.compareAtPriceCents ?? null,
        inventoryQty: Number(row.inventoryQty) || 0,
        option1: row.option1 ?? null,
        option2: row.option2 ?? null,
        image: row.image ?? imageList[0] ?? null,
      })),
    };

    try {
      const response = await fetch(isEdit ? `/api/admin/products/${product!.id}` : "/api/admin/products", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { error?: string; product?: Product };
      if (!response.ok) throw new Error(data.error ?? "Could not save the product.");
      setSaved(true);
      router.push(`/admin/products/${data.product?.id ?? product?.id}`);
      router.refresh();
    } catch (saveError) {
      setError((saveError as Error).message);
      setBusy(false);
    }
  };

  const removeProduct = async () => {
    if (!product) return;
    if (!window.confirm(`Delete "${product.title}"? This cannot be undone.`)) return;
    setBusy(true);
    const response = await fetch(`/api/admin/products/${product.id}`, { method: "DELETE" });
    if (response.ok) {
      router.push("/admin/products");
      router.refresh();
    } else {
      setError("Could not delete that product.");
      setBusy(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-6 grid gap-6 xl:grid-cols-[1fr_360px]">
      <div className="space-y-6">
        <Card title="Product details">
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={form.title}
                onChange={(event) => {
                  set("title", event.target.value);
                  if (!isEdit || !form.handle) set("handle", slugify(event.target.value));
                }}
                placeholder="Kiln Ceramic Vase"
              />
            </div>
            <div>
              <Label htmlFor="handle">URL handle</Label>
              <div className="flex items-center gap-2">
                <span className="text-[13px] text-muted">/products/</span>
                <Input id="handle" value={form.handle} onChange={(event) => set("handle", slugify(event.target.value))} />
              </div>
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={form.description}
                onChange={(event) => set("description", event.target.value)}
                placeholder={"Hand-thrown stoneware…\n\n• Bullet points start with •\n• Each line becomes a list item"}
                className="min-h-40"
              />
              <p className="mt-1.5 text-[12px] text-muted">
                Lines starting with “•” render as bullet points on the product page.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="vendor">Vendor / maker</Label>
                <Input id="vendor" value={form.vendor} onChange={(event) => set("vendor", event.target.value)} />
              </div>
              <div>
                <Label htmlFor="sku">SKU</Label>
                <Input id="sku" value={form.sku} onChange={(event) => set("sku", event.target.value.toUpperCase())} placeholder="KIL-1042" />
              </div>
              <div>
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input id="tags" value={form.tags} onChange={(event) => set("tags", event.target.value)} placeholder="ceramics, handmade, gift" />
              </div>
              <div>
                <Label htmlFor="weight">Weight (grams)</Label>
                <Input id="weight" type="number" min={0} value={form.weight} onChange={(event) => set("weight", event.target.value)} />
              </div>
            </div>
          </div>
        </Card>

        <Card title="Media">
          <div className="grid gap-4 sm:grid-cols-[1fr_200px]">
            <div>
              <Label htmlFor="images">Image URLs (one per line)</Label>
              <Textarea
                id="images"
                value={form.images}
                onChange={(event) => set("images", event.target.value)}
                placeholder="https://images.pexels.com/photos/…jpeg"
                className="min-h-32 font-mono text-[12px]"
              />
              <p className="mt-1.5 text-[12px] text-muted">{imageList.length} image(s) · first is the listing thumbnail</p>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-2">
              {imageList.slice(0, 6).map((image) => (
                <span key={image} className="relative aspect-square overflow-hidden rounded-lg bg-paper-2">
                  <Image src={image} alt="" fill sizes="80px" className="object-cover" />
                </span>
              ))}
              {imageList.length === 0 ? (
                <span className="col-span-3 rounded-lg border border-dashed border-line px-3 py-6 text-center text-[12px] text-muted sm:col-span-2">
                  No images yet
                </span>
              ) : null}
            </div>
          </div>
        </Card>

        <Card title="Pricing">
          <div className="grid gap-4 sm:grid-cols-3">
            <div>
              <Label htmlFor="price">Price ($)</Label>
              <Input id="price" inputMode="decimal" value={form.price} onChange={(event) => set("price", event.target.value)} placeholder="68.00" />
            </div>
            <div>
              <Label htmlFor="compareAt">Compare-at price ($)</Label>
              <Input id="compareAt" inputMode="decimal" value={form.compareAt} onChange={(event) => set("compareAt", event.target.value)} placeholder="84.00" />
            </div>
            <div>
              <Label htmlFor="cost">Cost per item ($)</Label>
              <Input id="cost" inputMode="decimal" value={form.cost} onChange={(event) => set("cost", event.target.value)} placeholder="24.00" />
            </div>
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            <Badge tone={margin >= 60 ? "moss" : margin >= 40 ? "gold" : "sale"}>Margin {margin}%</Badge>
            <Badge tone="neutral">Profit {money(Math.max(priceCents - costCents, 0))}</Badge>
            {toCents(form.compareAt) > priceCents ? (
              <Badge tone="sale">Saves the customer {money(toCents(form.compareAt) - priceCents)}</Badge>
            ) : null}
          </div>
        </Card>

        <Card
          title="Variants & inventory"
          action={
            <Button type="button" variant="light" size="sm" onClick={generateVariants}>
              <RefreshIcon className="h-3.5 w-3.5" /> Generate from options
            </Button>
          }
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="option1Name">Option 1 name</Label>
              <Input id="option1Name" value={form.option1Name} onChange={(event) => set("option1Name", event.target.value)} placeholder="Colour" />
            </div>
            <div>
              <Label htmlFor="option1Values">Option 1 values (comma separated)</Label>
              <Input id="option1Values" value={form.option1Values} onChange={(event) => set("option1Values", event.target.value)} placeholder="Sand, Charcoal" />
            </div>
            <div>
              <Label htmlFor="option2Name">Option 2 name (optional)</Label>
              <Input id="option2Name" value={form.option2Name} onChange={(event) => set("option2Name", event.target.value)} placeholder="Size" />
            </div>
            <div>
              <Label htmlFor="option2Values">Option 2 values</Label>
              <Input id="option2Values" value={form.option2Values} onChange={(event) => set("option2Values", event.target.value)} placeholder='9", 12"' />
            </div>
          </div>

          <div className="mt-5 overflow-x-auto rounded-xl border border-line">
            <table className="w-full min-w-[720px] text-left text-[13px]">
              <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
                <tr>
                  <th className="px-3 py-2.5 font-bold">Variant</th>
                  <th className="px-3 py-2.5 font-bold">Price ($)</th>
                  <th className="px-3 py-2.5 font-bold">SKU</th>
                  <th className="px-3 py-2.5 font-bold">Inventory</th>
                  <th className="px-3 py-2.5 font-bold">Image</th>
                  <th className="px-3 py-2.5" />
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {variantRows.map((row, index) => (
                  <tr key={`${row.title}-${index}`}>
                    <td className="px-3 py-2">
                      <Input value={row.title} onChange={(event) => updateVariant(index, { title: event.target.value })} className="h-10 text-[13px]" />
                    </td>
                    <td className="w-28 px-3 py-2">
                      <Input
                        value={(row.priceCents / 100).toFixed(2)}
                        onChange={(event) => updateVariant(index, { priceCents: toCents(event.target.value) })}
                        className="h-10 text-[13px]"
                      />
                    </td>
                    <td className="w-36 px-3 py-2">
                      <Input value={row.sku ?? ""} onChange={(event) => updateVariant(index, { sku: event.target.value })} className="h-10 text-[13px]" />
                    </td>
                    <td className="w-28 px-3 py-2">
                      <Input
                        type="number"
                        min={0}
                        value={row.inventoryQty}
                        onChange={(event) => updateVariant(index, { inventoryQty: Number(event.target.value) })}
                        className="h-10 text-[13px]"
                      />
                    </td>
                    <td className="w-24 px-3 py-2">
                      <span className="relative block h-10 w-10 overflow-hidden rounded-lg bg-paper-2">
                        {row.image ? <Image src={row.image} alt="" fill sizes="40px" className="object-cover" /> : null}
                      </span>
                    </td>
                    <td className="w-12 px-3 py-2 text-right">
                      <button
                        type="button"
                        onClick={() => setVariantRows((prev) => prev.filter((_, rowIndex) => rowIndex !== index))}
                        className="grid h-9 w-9 place-items-center rounded-full text-muted transition hover:bg-clay/10 hover:text-clay"
                        aria-label="Remove variant"
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-3">
            <Button
              type="button"
              variant="light"
              size="sm"
              onClick={() =>
                setVariantRows((prev) => [
                  ...prev,
                  {
                    title: prev.length ? `${prev[prev.length - 1].title} copy` : "Default Title",
                    sku: "",
                    priceCents: priceCents || prev[0]?.priceCents || 0,
                    inventoryQty: 10,
                    option1: null,
                    option2: null,
                    image: imageList[0] ?? null,
                  },
                ])
              }
            >
              <PlusIcon className="h-3.5 w-3.5" /> Add variant
            </Button>
            <span className="text-[13px] text-muted">
              {variantRows.length} variant{variantRows.length === 1 ? "" : "s"} · {totalInventory} units tracked
            </span>
          </div>
        </Card>
      </div>

      <aside className="space-y-4 xl:sticky xl:top-6 xl:self-start">
        <Card title="Publish">
          <div className="space-y-4">
            <div>
              <Label htmlFor="status">Status</Label>
              <Select id="status" value={form.status} onChange={(event) => set("status", event.target.value)}>
                <option value="active">Active</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </Select>
            </div>
            <label className="flex items-center gap-2.5 text-[13.5px]">
              <input
                type="checkbox"
                checked={form.featured}
                onChange={(event) => set("featured", event.target.checked)}
                className="h-4 w-4 accent-[#a4472a]"
              />
              Feature on the homepage
            </label>
            <label className="flex items-center gap-2.5 text-[13.5px]">
              <input
                type="checkbox"
                checked={form.trackInventory}
                onChange={(event) => set("trackInventory", event.target.checked)}
                className="h-4 w-4 accent-[#a4472a]"
              />
              Track inventory for this product
            </label>

            {error ? <p className="rounded-lg bg-clay/10 px-3 py-2 text-[12.5px] font-semibold text-clay">{error}</p> : null}
            {saved ? (
              <p className="flex items-center gap-2 rounded-lg bg-moss/10 px-3 py-2 text-[12.5px] font-semibold text-moss">
                <CheckIcon className="h-4 w-4" strokeWidth={2.6} /> Saved
              </p>
            ) : null}

            <Button type="submit" size="lg" className="w-full" disabled={busy}>
              {busy ? <Spinner className="h-4 w-4" /> : <CheckIcon className="h-4 w-4" />}
              {isEdit ? "Save changes" : "Create product"}
            </Button>

            {isEdit && product ? (
              <>
                <Link
                  href={`/products/${product.handle}`}
                  target="_blank"
                  className="flex h-11 w-full items-center justify-center gap-2 rounded-full border border-line bg-surface text-[13.5px] font-bold transition hover:border-ink"
                >
                  View on storefront <ArrowRight className="h-4 w-4" />
                </Link>
                <Button type="button" variant="danger" className="w-full" onClick={removeProduct} disabled={busy}>
                  <TrashIcon className="h-4 w-4" /> Delete product
                </Button>
              </>
            ) : null}
          </div>
        </Card>

        <Card title="Organisation">
          <div>
            <Label htmlFor="collection">Collection</Label>
            <Select id="collection" value={form.collectionId} onChange={(event) => set("collectionId", event.target.value)}>
              <option value="">No collection</option>
              {collections.map((item) => (
                <option key={item.id} value={String(item.id)}>
                  {item.title}
                </option>
              ))}
            </Select>
          </div>
          <div className="mt-4">
            <p className="eyebrow mb-2 text-muted">Current tags</p>
            <div className="flex flex-wrap gap-1.5">
              {tagList.length === 0 ? <span className="text-[12.5px] text-muted">No tags yet</span> : null}
              {tagList.map((tag) => (
                <Badge key={tag} tone="neutral">{tag}</Badge>
              ))}
            </div>
          </div>
        </Card>

        <Card title="Search engine listing">
          <p className="text-[12.5px] font-bold">{form.title || "Product title"}</p>
          <p className="mt-0.5 text-[12px] text-moss">haven.co/products/{form.handle || slugify(form.title) || "handle"}</p>
          <p className="mt-2 line-clamp-3 text-[12.5px] leading-relaxed text-muted">
            {form.description || "Add a description to preview the meta summary shoppers see in search results."}
          </p>
        </Card>
      </aside>
    </form>
  );
}

function Card({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <section className="rounded-[20px] border border-line bg-surface p-5 sm:p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-[19px]">{title}</h2>
        {action}
      </div>
      {children}
    </section>
  );
}
