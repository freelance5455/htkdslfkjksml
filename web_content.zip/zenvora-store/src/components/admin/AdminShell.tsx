"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import type { ReactNode } from "react";
import {
  ChartIcon,
  CloseIcon,
  GridIcon,
  LogoutIcon,
  MailIcon,
  MenuIcon,
  PackageIcon,
  StoreIcon,
  TagIcon,
  UsersIcon,
} from "@/components/icons";

const NAV = [
  { href: "/admin", label: "Overview", icon: ChartIcon, exact: true },
  { href: "/admin/orders", label: "Orders", icon: PackageIcon },
  { href: "/admin/products", label: "Products", icon: GridIcon },
  { href: "/admin/discounts", label: "Discounts", icon: TagIcon },
  { href: "/admin/customers", label: "Customers", icon: UsersIcon },
  { href: "/admin/inbox", label: "Inbox", icon: MailIcon },
];

export function AdminShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (item: (typeof NAV)[number]) =>
    item.exact ? pathname === item.href : pathname.startsWith(item.href);

  const logout = async () => {
    await fetch("/api/admin/session", { method: "DELETE" });
    router.push("/admin/login");
    router.refresh();
  };

  const sidebar = (
    <div className="flex h-full flex-col bg-ink text-paper">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-clay">
          <StoreIcon className="h-5 w-5" />
        </span>
        <div>
          <p className="font-display text-[16px] leading-none">Zenvora Admin</p>
          <p className="mt-1 text-[11px] text-paper/55">haven-co.myshop</p>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(false)}
          className="ml-auto grid h-8 w-8 place-items-center rounded-full hover:bg-paper/10 lg:hidden"
          aria-label="Close navigation"
        >
          <CloseIcon className="h-4 w-4" />
        </button>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-2">
        {NAV.map((item) => {
          const active = isActive(item);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setMobileOpen(false)}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-semibold transition ${
                active ? "bg-paper/14 text-paper" : "text-paper/65 hover:bg-paper/8 hover:text-paper"
              }`}
            >
              <item.icon className="h-[18px] w-[18px]" />
              {item.label}
              {active ? <span className="ml-auto h-1.5 w-1.5 rounded-full bg-clay" /> : null}
            </Link>
          );
        })}
      </nav>

      <div className="space-y-2 border-t border-paper/12 p-3">
        <Link
          href="/"
          target="_blank"
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13.5px] font-semibold text-paper/70 transition hover:bg-paper/8 hover:text-paper"
        >
          <StoreIcon className="h-[18px] w-[18px]" /> View storefront
        </Link>
        <button
          type="button"
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[13.5px] font-semibold text-paper/70 transition hover:bg-clay/25 hover:text-paper"
        >
          <LogoutIcon className="h-[18px] w-[18px]" /> Log out
        </button>
        <p className="px-3 pb-2 pt-1 text-[11px] leading-relaxed text-paper/40">
          Demo admin · passphrase <span className="font-bold text-paper/70">haven</span>
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-paper">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 lg:block">{sidebar}</aside>

      {mobileOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="animate-fade absolute inset-0 bg-ink/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="animate-slide-in absolute inset-y-0 left-0 w-72">{sidebar}</div>
        </div>
      ) : null}

      <div className="lg:pl-64">
        <div className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-paper/90 px-4 backdrop-blur lg:hidden">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="grid h-10 w-10 place-items-center rounded-full hover:bg-ink/6"
            aria-label="Open navigation"
          >
            <MenuIcon className="h-5 w-5" />
          </button>
          <span className="font-display text-[16px]">Zenvora Admin</span>
        </div>
        <div className="mx-auto max-w-[1400px] px-4 py-7 sm:px-6 lg:px-8 lg:py-9">{children}</div>
      </div>
    </div>
  );
}
