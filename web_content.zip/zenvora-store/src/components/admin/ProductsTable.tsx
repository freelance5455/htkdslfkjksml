"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Collection, Product } from "@/db/schema";
import { Badge, Button, Input, Select, Spinner } from "@/components/ui";
import { EditIcon, SearchIcon, TrashIcon, StoreIcon } from "@/components/icons";
import { formatDate, money, pctOff } from "@/lib/format";

export type AdminProductRow = Product & {
  collection: Collection | null;
  variantCount: number;
  soldUnits: number;
};

export function ProductsTable({ products }: { products: AdminProductRow[] }) {
  const router = useRouter();
  const [term, setTerm] = useState("");
  const [status, setStatus] = useState("all");
  const [collection, setCollection] = useState("all");
  const [busyId, setBusyId] = useState<number | null>(null);
  const [rows, setRows] = useState(products);
  const [confirmId, setConfirmId] = useState<number | null>(null);

  const filtered = useMemo(
    () =>
      rows.filter((row) => {
        const matchesTerm =
          term.trim() === "" ||
          `${row.title} ${row.vendor} ${row.sku} ${row.tags.join(" ")}`.toLowerCase().includes(term.toLowerCase());
        const matchesStatus = status === "all" || row.status === status;
        const matchesCollection = collection === "all" || String(row.collectionId ?? "") === collection;
        return matchesTerm && matchesStatus && matchesCollection;
      }),
    [rows, term, status, collection],
  );

  const collections = useMemo(
    () => Array.from(new Map(products.filter((row) => row.collection).map((row) => [row.collectionId, row.collection!])).values()),
    [products],
  );

  const toggleStatus = async (product: AdminProductRow) => {
    setBusyId(product.id);
    const next = product.status === "active" ? "draft" : "active";
    setRows((prev) => prev.map((row) => (row.id === product.id ? { ...row, status: next } : row)));
    await fetch(`/api/admin/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...product, status: next }),
    });
    setBusyId(null);
    router.refresh();
  };

  const remove = async (product: AdminProductRow) => {
    setBusyId(product.id);
    const response = await fetch(`/api/admin/products/${product.id}`, { method: "DELETE" });
    if (response.ok) {
      setRows((prev) => prev.filter((row) => row.id !== product.id));
      router.refresh();
    }
    setBusyId(null);
    setConfirmId(null);
  };

  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <SearchIcon className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Search title, vendor, SKU or tag"
            className="h-11 rounded-full pl-10"
          />
        </div>
        <Select value={status} onChange={(event) => setStatus(event.target.value)} className="h-11 w-40 rounded-full">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="draft">Draft</option>
          <option value="archived">Archived</option>
        </Select>
        <Select value={collection} onChange={(event) => setCollection(event.target.value)} className="h-11 w-48 rounded-full">
          <option value="all">All collections</option>
          {collections.map((item) => (
            <option key={item.id} value={String(item.id)}>
              {item.title}
            </option>
          ))}
        </Select>
        <Link
          href="/admin/products/new"
          className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-[13.5px] font-bold text-paper transition hover:bg-clay"
        >
          + Add product
        </Link>
      </div>

      <p className="mt-4 text-[13px] text-muted">
        Showing <span className="font-bold text-ink">{filtered.length}</span> of {rows.length} products
      </p>

      <div className="mt-3 overflow-hidden rounded-[20px] border border-line bg-surface">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-[13.5px]">
            <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
              <tr>
                <th className="px-5 py-3 font-bold">Product</th>
                <th className="px-4 py-3 font-bold">Status</th>
                <th className="px-4 py-3 font-bold">Collection</th>
                <th className="px-4 py-3 font-bold">Inventory</th>
                <th className="px-4 py-3 font-bold">Price</th>
                <th className="px-4 py-3 font-bold">Sold</th>
                <th className="px-4 py-3 font-bold">Updated</th>
                <th className="px-5 py-3 text-right font-bold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {filtered.map((product) => {
                const off = pctOff(product.priceCents, product.compareAtPriceCents);
                return (
                  <tr key={product.id} className="transition hover:bg-paper/50">
                    <td className="px-5 py-3">
                      <span className="flex items-center gap-3">
                        <span className="relative h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-paper-2">
                          {product.images[0] ? (
                            <Image src={product.images[0]} alt="" fill sizes="44px" className="object-cover" />
                          ) : null}
                        </span>
                        <span className="min-w-0">
                          <Link href={`/admin/products/${product.id}`} className="block max-w-[240px] truncate font-bold hover:text-clay">
                            {product.title}
                          </Link>
                          <span className="block text-[12px] text-muted">
                            {product.vendor} · {product.sku} · {product.variantCount} variant{product.variantCount === 1 ? "" : "s"}
                          </span>
                        </span>
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={product.status === "active" ? "moss" : product.status === "draft" ? "gold" : "neutral"}>
                        {product.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-ink-2">{product.collection?.title ?? "—"}</td>
                    <td className="px-4 py-3">
                      <span className={product.inventoryQty === 0 ? "font-bold text-clay" : product.inventoryQty <= 5 ? "font-bold text-gold" : "font-bold"}>
                        {product.inventoryQty}
                      </span>
                      <span className="block text-[11.5px] text-muted">{product.trackInventory ? "tracked" : "untracked"}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-bold">{money(product.priceCents)}</span>
                      {off ? <span className="ml-1.5 text-[11.5px] font-bold text-clay">−{off}%</span> : null}
                      <span className="block text-[11.5px] text-muted">cost {money(product.costCents)}</span>
                    </td>
                    <td className="px-4 py-3 text-ink-2">{product.soldUnits}</td>
                    <td className="px-4 py-3 text-muted">{formatDate(product.updatedAt)}</td>
                    <td className="px-5 py-3">
                      <span className="flex items-center justify-end gap-1.5">
                        <Link
                          href={`/products/${product.handle}`}
                          target="_blank"
                          className="grid h-9 w-9 place-items-center rounded-full border border-line text-ink-2 transition hover:border-ink hover:text-ink"
                          aria-label="View on storefront"
                        >
                          <StoreIcon className="h-4 w-4" />
                        </Link>
                        <button
                          type="button"
                          onClick={() => toggleStatus(product)}
                          disabled={busyId === product.id}
                          className="h-9 rounded-full border border-line px-3 text-[12.5px] font-bold text-ink-2 transition hover:border-ink hover:text-ink disabled:opacity-50"
                        >
                          {busyId === product.id ? <Spinner className="h-3.5 w-3.5" /> : product.status === "active" ? "Unpublish" : "Publish"}
                        </button>
                        <Link
                          href={`/admin/products/${product.id}`}
                          className="grid h-9 w-9 place-items-center rounded-full border border-line text-ink-2 transition hover:border-ink hover:text-ink"
                          aria-label="Edit product"
                        >
                          <EditIcon className="h-4 w-4" />
                        </Link>
                        <button
                          type="button"
                          onClick={() => setConfirmId(product.id)}
                          className="grid h-9 w-9 place-items-center rounded-full border border-line text-muted transition hover:border-clay hover:text-clay"
                          aria-label="Delete product"
                        >
                          <TrashIcon className="h-4 w-4" />
                        </button>
                      </span>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-14 text-center text-muted">
                    No products match those filters.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      {confirmId != null ? (
        <div className="fixed inset-0 z-[80] grid place-items-center px-4">
          <div className="animate-fade absolute inset-0 bg-ink/50 backdrop-blur-sm" onClick={() => setConfirmId(null)} />
          <div className="animate-rise relative w-full max-w-md rounded-[22px] border border-line bg-surface p-6">
            <h2 className="font-display text-[22px]">Delete this product?</h2>
            <p className="mt-2 text-[13.5px] leading-relaxed text-ink-2">
              This removes the product, its variants and its reviews. Order history is kept for accounting. This can't be
              undone.
            </p>
            <div className="mt-6 flex justify-end gap-2">
              <Button variant="light" onClick={() => setConfirmId(null)}>
                Cancel
              </Button>
              <Button
                variant="accent"
                onClick={() => {
                  const target = rows.find((row) => row.id === confirmId);
                  if (target) void remove(target);
                }}
              >
                Delete product
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
