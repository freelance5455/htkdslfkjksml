import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { isAdmin } from "@/lib/admin";
import { AdminShell } from "@/components/admin/AdminShell";

/**
 * Server-side gate: every admin screen renders through this so the shell,
 * navigation and auth check stay in one place.
 */
export async function AdminGate({ children }: { children: ReactNode }) {
  if (!(await isAdmin())) {
    redirect("/admin/login");
  }
  return <AdminShell>{children}</AdminShell>;
}
