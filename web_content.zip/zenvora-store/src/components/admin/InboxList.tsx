"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Message } from "@/db/schema";
import { Badge, Button, Spinner } from "@/components/ui";
import { CheckIcon, MailIcon, TrashIcon } from "@/components/icons";
import { formatDateTime } from "@/lib/format";

export function InboxList({ messages }: { messages: Message[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(messages);
  const [openId, setOpenId] = useState<number | null>(messages[0]?.id ?? null);
  const [busyId, setBusyId] = useState<number | null>(null);

  const markRead = async (message: Message) => {
    setBusyId(message.id);
    setRows((prev) => prev.map((row) => (row.id === message.id ? { ...row, read: true } : row)));
    await fetch("/api/contact", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: message.id, read: true }),
    });
    setBusyId(null);
    router.refresh();
  };

  const remove = async (message: Message) => {
    if (!window.confirm("Delete this message?")) return;
    setBusyId(message.id);
    setRows((prev) => prev.filter((row) => row.id !== message.id));
    await fetch("/api/contact", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: message.id }),
    });
    setBusyId(null);
    setOpenId(null);
    router.refresh();
  };

  const unread = rows.filter((row) => !row.read).length;

  return (
    <div className="mt-6">
      <p className="text-[13px] text-muted">
        <span className="font-bold text-ink">{rows.length}</span> messages ·{" "}
        <span className="font-bold text-clay">{unread} unread</span>
      </p>

      <div className="mt-3 overflow-hidden rounded-[20px] border border-line bg-surface">
        {rows.length === 0 ? (
          <p className="px-5 py-14 text-center text-[13.5px] text-muted">
            No messages yet. Submissions from the contact form land here instantly.
          </p>
        ) : (
          <ul className="divide-y divide-line">
            {rows.map((message) => {
              const open = openId === message.id;
              return (
                <li key={message.id}>
                  <button
                    type="button"
                    onClick={() => setOpenId(open ? null : message.id)}
                    className={`flex w-full items-center gap-4 px-5 py-4 text-left transition hover:bg-paper/60 ${
                      message.read ? "" : "bg-clay/4"
                    }`}
                  >
                    <span className={`h-2 w-2 shrink-0 rounded-full ${message.read ? "bg-line" : "bg-clay"}`} />
                    <span className="min-w-0 flex-1">
                      <span className="flex flex-wrap items-center gap-2">
                        <span className="text-[14px] font-bold">
                          {message.name || "Anonymous"}
                        </span>
                        <Badge tone="neutral">{message.topic}</Badge>
                        {message.orderNumber ? <Badge tone="gold">{message.orderNumber}</Badge> : null}
                      </span>
                      <span className="mt-0.5 block truncate text-[13px] text-muted">{message.body}</span>
                    </span>
                    <span className="shrink-0 text-right">
                      <span className="block text-[12px] text-muted">{formatDateTime(message.createdAt)}</span>
                      <span className="block text-[12px] text-ink-2">{message.email}</span>
                    </span>
                  </button>

                  {open ? (
                    <div className="animate-fade border-t border-line bg-paper/50 px-5 py-5">
                      <p className="whitespace-pre-wrap text-[14px] leading-relaxed text-ink-2">{message.body}</p>
                      <div className="mt-5 flex flex-wrap items-center gap-2">
                        <a
                          href={`mailto:${message.email}?subject=Re: ${message.topic}&body=${encodeURIComponent(
                            `\n\n---\n${message.body}`,
                          )}`}
                          className="inline-flex h-10 items-center gap-2 rounded-full bg-ink px-4 text-[13px] font-bold text-paper transition hover:bg-clay"
                        >
                          <MailIcon className="h-4 w-4" /> Reply by email
                        </a>
                        <Button variant="light" size="sm" onClick={() => markRead(message)} disabled={busyId === message.id || message.read}>
                          {busyId === message.id ? <Spinner className="h-3.5 w-3.5" /> : <CheckIcon className="h-3.5 w-3.5" />}
                          {message.read ? "Read" : "Mark as read"}
                        </Button>
                        <Button variant="danger" size="sm" onClick={() => remove(message)} disabled={busyId === message.id}>
                          <TrashIcon className="h-3.5 w-3.5" /> Delete
                        </Button>
                      </div>
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
