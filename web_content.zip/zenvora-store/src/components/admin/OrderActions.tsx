"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Order } from "@/db/schema";
import { Badge, Button, Spinner, Textarea } from "@/components/ui";
import { CheckIcon, RefreshIcon, TruckIcon } from "@/components/icons";

export function OrderActions({ order }: { order: Order }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState(order.note ?? "");
  const [message, setMessage] = useState<string | null>(null);

  const patch = async (body: Record<string, unknown>, label: string) => {
    setBusy(label);
    setMessage(null);
    try {
      const response = await fetch(`/api/admin/orders/${order.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Update failed.");
      setMessage(`${label} updated`);
      router.refresh();
    } catch (error) {
      setMessage((error as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[20px] border border-line bg-surface p-5">
        <h2 className="font-display text-[19px]">Fulfilment</h2>
        <p className="mt-1.5 text-[13px] text-muted">
          Current status:{" "}
          <Badge tone={order.fulfillmentStatus === "fulfilled" ? "moss" : "neutral"}>{order.fulfillmentStatus}</Badge>
        </p>
        <Button
          className="mt-4 w-full"
          variant={order.fulfillmentStatus === "fulfilled" ? "light" : "primary"}
          onClick={() =>
            patch(
              { fulfillmentStatus: order.fulfillmentStatus === "fulfilled" ? "unfulfilled" : "fulfilled" },
              "Fulfilment",
            )
          }
          disabled={busy !== null}
        >
          {busy === "Fulfilment" ? <Spinner className="h-4 w-4" /> : <TruckIcon className="h-4 w-4" />}
          {order.fulfillmentStatus === "fulfilled" ? "Mark as unfulfilled" : "Mark as fulfilled"}
        </Button>
      </div>

      <div className="rounded-[20px] border border-line bg-surface p-5">
        <h2 className="font-display text-[19px]">Payment</h2>
        <p className="mt-1.5 text-[13px] text-muted">
          Status: <Badge tone={order.paymentStatus === "paid" ? "moss" : order.paymentStatus === "refunded" ? "sale" : "gold"}>{order.paymentStatus}</Badge>
          <span className="ml-2">
            {order.paymentBrand.toUpperCase()} ···· {order.paymentLast4}
          </span>
        </p>
        <div className="mt-4 grid gap-2">
          {order.paymentStatus !== "refunded" ? (
            <Button variant="danger" className="w-full" onClick={() => patch({ paymentStatus: "refunded" }, "Payment")} disabled={busy !== null}>
              {busy === "Payment" ? <Spinner className="h-4 w-4" /> : <RefreshIcon className="h-4 w-4" />} Refund order
            </Button>
          ) : (
            <Button variant="light" className="w-full" onClick={() => patch({ paymentStatus: "paid" }, "Payment")} disabled={busy !== null}>
              <CheckIcon className="h-4 w-4" /> Mark as paid again
            </Button>
          )}
          {order.paymentStatus === "pending" ? (
            <Button variant="light" className="w-full" onClick={() => patch({ paymentStatus: "paid" }, "Payment")} disabled={busy !== null}>
              Capture payment
            </Button>
          ) : null}
        </div>
      </div>

      <div className="rounded-[20px] border border-line bg-surface p-5">
        <h2 className="font-display text-[19px]">Internal note</h2>
        <Textarea
          value={note}
          onChange={(event) => setNote(event.target.value)}
          placeholder="Monogram requested: initials AR on the inside pocket."
          className="mt-3 min-h-24"
        />
        <Button variant="light" className="mt-3 w-full" onClick={() => patch({ note }, "Note")} disabled={busy !== null}>
          {busy === "Note" ? <Spinner className="h-4 w-4" /> : <CheckIcon className="h-4 w-4" />} Save note
        </Button>
        {message ? <p className="mt-3 text-[12.5px] font-semibold text-moss">{message}</p> : null}
      </div>
    </div>
  );
}
