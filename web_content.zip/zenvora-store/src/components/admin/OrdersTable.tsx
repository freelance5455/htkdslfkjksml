"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Order } from "@/db/schema";
import { Badge, Button, Input, Select, Spinner } from "@/components/ui";
import { SearchIcon, TruckIcon } from "@/components/icons";
import { formatDateTime, initials, money } from "@/lib/format";

export function OrdersTable({ orders }: { orders: Order[] }) {
  const router = useRouter();
  const [rows, setRows] = useState(orders);
  const [term, setTerm] = useState("");
  const [fulfillment, setFulfillment] = useState("all");
  const [payment, setPayment] = useState("all");
  const [busyId, setBusyId] = useState<number | null>(null);

  const filtered = useMemo(
    () =>
      rows.filter((order) => {
        const haystack = `${order.orderNumber} ${order.email} ${order.firstName} ${order.lastName} ${order.city}`.toLowerCase();
        return (
          (term.trim() === "" || haystack.includes(term.toLowerCase())) &&
          (fulfillment === "all" || order.fulfillmentStatus === fulfillment) &&
          (payment === "all" || order.paymentStatus === payment)
        );
      }),
    [rows, term, fulfillment, payment],
  );

  const revenue = filtered.reduce((sum, order) => sum + order.totalCents, 0);

  const markFulfilled = async (order: Order) => {
    setBusyId(order.id);
    const next = order.fulfillmentStatus === "fulfilled" ? "unfulfilled" : "fulfilled";
    setRows((prev) => prev.map((row) => (row.id === order.id ? { ...row, fulfillmentStatus: next } : row)));
    await fetch(`/api/admin/orders/${order.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fulfillmentStatus: next }),
    });
    setBusyId(null);
    router.refresh();
  };

  return (
    <div className="mt-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-56 flex-1">
          <SearchIcon className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input value={term} onChange={(event) => setTerm(event.target.value)} placeholder="Search order, email, name or city" className="h-11 rounded-full pl-10" />
        </div>
        <Select value={fulfillment} onChange={(event) => setFulfillment(event.target.value)} className="h-11 w-44 rounded-full">
          <option value="all">All fulfilment</option>
          <option value="unfulfilled">Unfulfilled</option>
          <option value="fulfilled">Fulfilled</option>
        </Select>
        <Select value={payment} onChange={(event) => setPayment(event.target.value)} className="h-11 w-40 rounded-full">
          <option value="all">All payments</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
          <option value="refunded">Refunded</option>
        </Select>
      </div>

      <p className="mt-4 text-[13px] text-muted">
        <span className="font-bold text-ink">{filtered.length}</span> orders ·{" "}
        <span className="font-bold text-ink">{money(revenue)}</span> in this view
      </p>

      <div className="mt-3 overflow-hidden rounded-[20px] border border-line bg-surface">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-[13.5px]">
            <thead className="border-b border-line bg-paper/60 text-[11px] uppercase tracking-[0.09em] text-muted">
              <tr>
                <th className="px-5 py-3 font-bold">Order</th>
                <th className="px-4 py-3 font-bold">Date</th>
                <th className="px-4 py-3 font-bold">Customer</th>
                <th className="px-4 py-3 font-bold">Destination</th>
                <th className="px-4 py-3 font-bold">Payment</th>
                <th className="px-4 py-3 font-bold">Fulfilment</th>
                <th className="px-4 py-3 text-right font-bold">Total</th>
                <th className="px-5 py-3 text-right font-bold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {filtered.map((order) => (
                <tr key={order.id} className="transition hover:bg-paper/50">
                  <td className="px-5 py-3">
                    <Link href={`/admin/orders/${order.id}`} className="font-bold hover:text-clay">
                      {order.orderNumber}
                    </Link>
                    <span className="block text-[12px] text-muted">{order.shippingMethod}</span>
                  </td>
                  <td className="px-4 py-3 text-muted">{formatDateTime(order.createdAt)}</td>
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-2">
                      <span className="grid h-7 w-7 place-items-center rounded-full bg-paper-2 text-[10.5px] font-black text-ink-2">
                        {initials(`${order.firstName} ${order.lastName}`)}
                      </span>
                      <span className="min-w-0">
                        <span className="block max-w-[150px] truncate font-semibold">
                          {order.firstName} {order.lastName}
                        </span>
                        <span className="block max-w-[170px] truncate text-[12px] text-muted">{order.email}</span>
                      </span>
                    </span>
                  </td>
                  <td className="px-4 py-3 text-ink-2">
                    {order.city}, {order.province}
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={order.paymentStatus === "paid" ? "moss" : order.paymentStatus === "refunded" ? "sale" : "gold"}>
                      {order.paymentStatus}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge tone={order.fulfillmentStatus === "fulfilled" ? "moss" : "neutral"}>{order.fulfillmentStatus}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right font-bold">{money(order.totalCents)}</td>
                  <td className="px-5 py-3 text-right">
                    <Button variant="light" size="sm" onClick={() => markFulfilled(order)} disabled={busyId === order.id}>
                      {busyId === order.id ? <Spinner className="h-3.5 w-3.5" /> : <TruckIcon className="h-3.5 w-3.5" />}
                      {order.fulfillmentStatus === "fulfilled" ? "Unfulfil" : "Fulfil"}
                    </Button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-5 py-14 text-center text-muted">
                    No orders match those filters.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
