"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { Badge, Button, EmptyState, Input, Label, LinkButton, Spinner } from "@/components/ui";
import { ArrowRight, CardIcon, CheckIcon, ChevronLeft, LockIcon, ShieldIcon, TagIcon, TruckIcon } from "@/components/icons";
import { computeTotals, money, SHIPPING_RATES } from "@/lib/format";

const STORAGE_KEY = "haven-checkout-v1";

type InfoForm = {
  email: string;
  firstName: string;
  lastName: string;
  address1: string;
  address2: string;
  city: string;
  province: string;
  zip: string;
  country: string;
  phone: string;
  marketingOptIn: boolean;
};

const EMPTY_INFO: InfoForm = {
  email: "",
  firstName: "",
  lastName: "",
  address1: "",
  address2: "",
  city: "",
  province: "",
  zip: "",
  country: "United States",
  phone: "",
  marketingOptIn: true,
};

const STEPS = ["Information", "Delivery", "Payment"] as const;

export function CheckoutFlow() {
  const router = useRouter();
  const { lines, subtotalCents, itemCount, cart, applyDiscount, removeDiscount, pushToast } = useCart();

  const [step, setStep] = useState(0);
  const [info, setInfo] = useState<InfoForm>(EMPTY_INFO);
  const [shippingMethod, setShippingMethod] = useState<string>("standard");
  const [card, setCard] = useState({ name: "", number: "", expiry: "", cvc: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [placing, setPlacing] = useState(false);
  const [code, setCode] = useState("");
  const [applying, setApplying] = useState(false);
  const [codeError, setCodeError] = useState<string | null>(null);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) setInfo({ ...EMPTY_INFO, ...(JSON.parse(stored) as Partial<InfoForm>) });
    } catch {
      /* ignore malformed storage */
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(info));
    } catch {
      /* ignore */
    }
  }, [info]);

  const totals = useMemo(
    () =>
      computeTotals({
        subtotalCents,
        shippingMethod,
        discount: cart?.discount
          ? {
              code: cart.discount.code,
              type: cart.discount.type,
              value: cart.discount.value,
              minSubtotalCents: cart.discount.minSubtotalCents,
            }
          : null,
      }),
    [subtotalCents, shippingMethod, cart?.discount],
  );

  const setField = (key: keyof InfoForm, value: string | boolean) => {
    setInfo((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const validateInfo = () => {
    const next: Record<string, string> = {};
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(info.email.trim())) next.email = "Enter a valid email address.";
    if (!info.firstName.trim()) next.firstName = "Required";
    if (!info.lastName.trim()) next.lastName = "Required";
    if (!info.address1.trim()) next.address1 = "Enter your street address.";
    if (!info.city.trim()) next.city = "Required";
    if (!info.province.trim()) next.province = "Required";
    if (!/^[0-9]{4,10}$/.test(info.zip.trim().replace(/\s|-/g, ""))) next.zip = "Invalid postal code";
    if (info.phone && !/^[0-9+()\s-]{7,20}$/.test(info.phone.trim())) next.phone = "Invalid phone number";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const validatePayment = () => {
    const next: Record<string, string> = {};
    const digits = card.number.replace(/\D/g, "");
    if (!card.name.trim()) next.cardName = "Enter the name on the card.";
    if (digits.length < 15) next.cardNumber = "Enter a 16-digit card number.";
    if (!/^(0[1-9]|1[0-2])\s*\/\s*\d{2}$/.test(card.expiry.trim())) next.expiry = "MM/YY";
    else {
      const [, mm, yy] = card.expiry.trim().match(/^(\d{2})\s*\/\s*(\d{2})$/) ?? [];
      if (mm && yy && new Date(2000 + Number(yy), Number(mm), 0) < new Date()) next.expiry = "Card expired";
    }
    if (!/^\d{3,4}$/.test(card.cvc)) next.cvc = "3–4 digits";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const nextStep = () => {
    if (step === 0 && !validateInfo()) {
      pushToast({ title: "Check your details", message: "Some fields need attention." });
      return;
    }
    if (step === 2) {
      void placeOrder();
      return;
    }
    setStep((current) => Math.min(current + 1, 2));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const placeOrder = async () => {
    if (!validateInfo() || !validatePayment()) {
      pushToast({ title: "Check your details", message: "Some fields need attention." });
      if (!validateInfo()) setStep(0);
      return;
    }
    setPlacing(true);
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...info, shippingMethod, cardName: card.name, cardNumber: card.number.replace(/\D/g, ""), expiry: card.expiry, cvc: card.cvc, note: cart?.note ?? "" }),
      });
      const data = (await response.json()) as { orderNumber?: string; error?: string };
      if (!response.ok || !data.orderNumber) throw new Error(data.error ?? "Payment could not be processed.");
      window.localStorage.removeItem(STORAGE_KEY);
      pushToast({ title: `Order ${data.orderNumber} confirmed`, message: "A receipt is on its way to your inbox." });
      router.replace(`/orders/${encodeURIComponent(data.orderNumber)}?email=${encodeURIComponent(info.email)}&confirmed=1`);
    } catch (error) {
      setPlacing(false);
      pushToast({ title: "Payment failed", message: (error as Error).message });
    }
  };

  const fillDemoDetails = () => {
    setInfo({
      ...EMPTY_INFO,
      email: "demo@haven.co",
      firstName: "Demo",
      lastName: "Shopper",
      address1: "118 Alder St",
      city: "Portland",
      province: "OR",
      zip: "97204",
      phone: "(555) 018 4420",
    });
    setCard({ name: "Demo Shopper", number: "4242 4242 4242 4242", expiry: "04/29", cvc: "242" });
    setStep(2);
    setErrors({});
    pushToast({ title: "Demo details filled", message: "Review the payment step and place the order." });
  };

  if (lines.length === 0 && !placing) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
        <EmptyState
          title="Nothing to check out"
          copy="Your bag is empty. Add a few things and the checkout will open up."
          action={
            <LinkButton href="/collections">
              Browse the store <ArrowRight className="h-4 w-4" />
            </LinkButton>
          }
        />
      </div>
    );
  }

  const formatCardNumber = (value: string) =>
    value
      .replace(/\D/g, "")
      .slice(0, 16)
      .replace(/(.{4})/g, "$1 ")
      .trim();

  const formatExpiry = (value: string) => {
    const digits = value.replace(/\D/g, "").slice(0, 4);
    if (digits.length <= 2) return digits;
    return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  };

  return (
    <div className="min-h-screen bg-paper">
      <div className="mx-auto grid max-w-[1400px] gap-10 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_520px] lg:py-12">
        {/* ------------------------------------------------ left: form */}
        <div className="order-2 lg:order-1">
          <Link href="/" className="font-display inline-flex items-center gap-2 text-[22px] hover:text-clay">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-ink text-paper">
              <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth={1.5}>
                <path d="M4 20V7.5L12 3l8 4.5V20" strokeLinejoin="round" />
                <path d="M9 20v-6h6v6" strokeLinejoin="round" />
              </svg>
            </span>
            Zenvora<span className="-ml-2 text-clay">&</span>
          </Link>

          <ol className="mt-7 flex items-center gap-2">
            {STEPS.map((label, index) => (
              <li key={label} className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => index < step && setStep(index)}
                  className={`flex items-center gap-2 rounded-full px-3 py-1.5 text-[12.5px] font-bold transition ${
                    index === step
                      ? "bg-ink text-paper"
                      : index < step
                        ? "bg-moss/12 text-moss hover:bg-moss/20"
                        : "bg-paper-2 text-muted"
                  }`}
                >
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-white/15 text-[11px]">
                    {index < step ? <CheckIcon className="h-3 w-3" strokeWidth={3} /> : index + 1}
                  </span>
                  {label}
                </button>
                {index < STEPS.length - 1 ? <span className="h-px w-4 bg-line sm:w-8" /> : null}
              </li>
            ))}
          </ol>

          <div className="mt-7 rounded-[22px] border border-line bg-surface p-6 sm:p-8">
            {/* express */}
            <div className="mb-7 rounded-2xl border border-dashed border-line bg-paper/60 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-[13.5px] font-bold">In a hurry?</p>
                  <p className="text-[12.5px] text-muted">Fill demo buyer + card details and jump to payment.</p>
                </div>
                <Button variant="light" size="sm" onClick={fillDemoDetails} type="button">
                  Use demo details
                </Button>
              </div>
            </div>

            {step === 0 ? (
              <div className="animate-fade space-y-7">
                <section>
                  <h2 className="font-display text-[22px]">Contact</h2>
                  <div className="mt-3">
                    <Label htmlFor="email">Email address</Label>
                    <Input
                      id="email"
                      type="email"
                      autoComplete="email"
                      placeholder="you@example.com"
                      value={info.email}
                      onChange={(event) => setField("email", event.target.value)}
                    />
                    {errors.email ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.email}</p> : null}
                    <label className="mt-2.5 flex items-center gap-2.5 text-[13px] text-ink-2">
                      <input
                        type="checkbox"
                        checked={info.marketingOptIn}
                        onChange={(event) => setField("marketingOptIn", event.target.checked)}
                        className="h-4 w-4 accent-[#a4472a]"
                      />
                      Email me news, restocks and member-only offers
                    </label>
                  </div>
                </section>

                <section>
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-[22px]">Delivery address</h2>
                    <Badge tone="line">
                      <ShieldIcon className="h-3 w-3" /> Encrypted
                    </Badge>
                  </div>
                  <div className="mt-3 grid gap-3 sm:grid-cols-2">
                    <div>
                      <Label htmlFor="firstName">First name</Label>
                      <Input id="firstName" autoComplete="given-name" value={info.firstName} onChange={(event) => setField("firstName", event.target.value)} />
                      {errors.firstName ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.firstName}</p> : null}
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last name</Label>
                      <Input id="lastName" autoComplete="family-name" value={info.lastName} onChange={(event) => setField("lastName", event.target.value)} />
                      {errors.lastName ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.lastName}</p> : null}
                    </div>
                    <div className="sm:col-span-2">
                      <Label htmlFor="address1">Street address</Label>
                      <Input id="address1" autoComplete="address-line1" placeholder="118 Alder St" value={info.address1} onChange={(event) => setField("address1", event.target.value)} />
                      {errors.address1 ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.address1}</p> : null}
                    </div>
                    <div className="sm:col-span-2">
                      <Label htmlFor="address2">Apartment, suite, etc. (optional)</Label>
                      <Input id="address2" autoComplete="address-line2" value={info.address2} onChange={(event) => setField("address2", event.target.value)} />
                    </div>
                    <div>
                      <Label htmlFor="city">City</Label>
                      <Input id="city" autoComplete="address-level2" value={info.city} onChange={(event) => setField("city", event.target.value)} />
                      {errors.city ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.city}</p> : null}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label htmlFor="province">State</Label>
                        <Input id="province" autoComplete="address-level1" placeholder="OR" value={info.province} onChange={(event) => setField("province", event.target.value)} />
                        {errors.province ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.province}</p> : null}
                      </div>
                      <div>
                        <Label htmlFor="zip">ZIP</Label>
                        <Input id="zip" autoComplete="postal-code" placeholder="97204" value={info.zip} onChange={(event) => setField("zip", event.target.value)} />
                        {errors.zip ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.zip}</p> : null}
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="country">Country</Label>
                      <Input id="country" value={info.country} onChange={(event) => setField("country", event.target.value)} />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone (optional, for delivery updates)</Label>
                      <Input id="phone" type="tel" autoComplete="tel" placeholder="(555) 018 4420" value={info.phone} onChange={(event) => setField("phone", event.target.value)} />
                      {errors.phone ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.phone}</p> : null}
                    </div>
                  </div>
                </section>
              </div>
            ) : null}

            {step === 1 ? (
              <div className="animate-fade space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-[22px]">Delivery method</h2>
                  <button type="button" onClick={() => setStep(0)} className="flex items-center gap-1 text-[12.5px] font-bold text-muted hover:text-clay">
                    <ChevronLeft className="h-3.5 w-3.5" /> Edit address
                  </button>
                </div>

                <div className="rounded-2xl border border-line bg-paper/50 p-4 text-[13.5px]">
                  <p className="font-bold">
                    {info.firstName} {info.lastName}
                  </p>
                  <p className="text-ink-2">
                    {info.address1}
                    {info.address2 ? `, ${info.address2}` : ""}
                  </p>
                  <p className="text-ink-2">
                    {info.city}, {info.province} {info.zip} · {info.country}
                  </p>
                  <p className="mt-1 text-muted">{info.email}</p>
                </div>

                <div className="space-y-2.5">
                  {SHIPPING_RATES.map((rate) => {
                    const free = rate.freeOverCents != null && subtotalCents >= rate.freeOverCents;
                    return (
                      <label
                        key={rate.id}
                        className={`flex cursor-pointer items-center gap-3.5 rounded-2xl border px-4 py-4 transition ${
                          shippingMethod === rate.id ? "border-ink bg-paper" : "border-line hover:border-ink/40"
                        }`}
                      >
                        <input
                          type="radio"
                          name="shipping"
                          checked={shippingMethod === rate.id}
                          onChange={() => setShippingMethod(rate.id)}
                          className="h-4 w-4 accent-[#a4472a]"
                        />
                        <TruckIcon className="h-5 w-5 text-clay" />
                        <span className="min-w-0 flex-1">
                          <span className="block text-[14px] font-bold">{rate.label}</span>
                          <span className="block text-[12.5px] text-muted">{rate.detail}</span>
                        </span>
                        <span className="text-[14px] font-bold">{free ? "Free" : money(rate.priceCents)}</span>
                      </label>
                    );
                  })}
                </div>

                <p className="flex items-start gap-2 rounded-xl bg-moss/8 px-4 py-3 text-[12.5px] text-moss">
                  <ShieldIcon className="mt-0.5 h-4 w-4 shrink-0" />
                  Every order ships plastic-free with tracked delivery and a prepaid return label in the box.
                </p>
              </div>
            ) : null}

            {step === 2 ? (
              <div className="animate-fade space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-[22px]">Payment</h2>
                  <Badge tone="line">
                    <LockIcon className="h-3 w-3" /> 256-bit TLS
                  </Badge>
                </div>

                <div className="rounded-2xl border border-line bg-paper/50 p-4">
                  <p className="eyebrow text-muted">Billing address</p>
                  <p className="mt-1 text-[13.5px] font-bold">
                    {info.firstName} {info.lastName} · {info.address1}, {info.city} {info.zip}
                  </p>
                  <button type="button" onClick={() => setStep(0)} className="mt-1.5 text-[12.5px] font-bold text-clay hover:underline">
                    Change
                  </button>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2 rounded-xl border border-ink bg-ink/4 px-3.5 py-3">
                    <CardIcon className="h-5 w-5 text-clay" />
                    <span className="text-[14px] font-bold">Card</span>
                    <span className="ml-auto flex gap-1">
                      {["VISA", "MC", "AMEX"].map((brand) => (
                        <span key={brand} className="grid h-5 min-w-9 place-items-center rounded border border-line bg-surface px-1 text-[9px] font-black text-ink-2">
                          {brand}
                        </span>
                      ))}
                    </span>
                  </div>

                  <div>
                    <Label htmlFor="cardName">Name on card</Label>
                    <Input id="cardName" autoComplete="cc-name" value={card.name} onChange={(event) => setCard((prev) => ({ ...prev, name: event.target.value }))} />
                    {errors.cardName ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.cardName}</p> : null}
                  </div>
                  <div>
                    <Label htmlFor="cardNumber">Card number</Label>
                    <Input
                      id="cardNumber"
                      inputMode="numeric"
                      autoComplete="cc-number"
                      placeholder="4242 4242 4242 4242"
                      value={card.number}
                      onChange={(event) => setCard((prev) => ({ ...prev, number: formatCardNumber(event.target.value) }))}
                    />
                    {errors.cardNumber ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.cardNumber}</p> : null}
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="expiry">Expiry (MM/YY)</Label>
                      <Input
                        id="expiry"
                        inputMode="numeric"
                        autoComplete="cc-exp"
                        placeholder="04/29"
                        value={card.expiry}
                        onChange={(event) => setCard((prev) => ({ ...prev, expiry: formatExpiry(event.target.value) }))}
                      />
                      {errors.expiry ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.expiry}</p> : null}
                    </div>
                    <div>
                      <Label htmlFor="cvc">Security code</Label>
                      <Input
                        id="cvc"
                        inputMode="numeric"
                        autoComplete="cc-csc"
                        placeholder="123"
                        value={card.cvc}
                        onChange={(event) => setCard((prev) => ({ ...prev, cvc: event.target.value.replace(/\D/g, "").slice(0, 4) }))}
                      />
                      {errors.cvc ? <p className="mt-1 text-[12px] font-semibold text-clay">{errors.cvc}</p> : null}
                    </div>
                  </div>
                </div>

                <p className="flex items-start gap-2 text-[12.5px] leading-relaxed text-muted">
                  <LockIcon className="mt-0.5 h-4 w-4 shrink-0" />
                  This is a demo storefront — no real card is charged and no payment data leaves your browser.
                </p>
              </div>
            ) : null}

            <div className="mt-8 flex flex-col-reverse gap-3 border-t border-line pt-6 sm:flex-row sm:items-center sm:justify-between">
              <Link href="/cart" className="flex items-center justify-center gap-1.5 text-[13.5px] font-bold text-ink-2 hover:text-clay">
                <ChevronLeft className="h-4 w-4" /> Return to bag
              </Link>
              <Button size="lg" className="w-full sm:w-auto" onClick={nextStep} disabled={placing}>
                {placing ? <Spinner className="h-4 w-4" /> : <LockIcon className="h-4 w-4" />}
                {step < 2 ? `Continue to ${STEPS[step + 1].toLowerCase()}` : `Pay ${money(totals.totalCents)}`}
                {step < 2 ? <ArrowRight className="h-4 w-4" /> : null}
              </Button>
            </div>
          </div>

          <p className="mt-6 flex items-center justify-center gap-4 text-[12px] text-muted">
            <Link href="/pages/policies" className="hover:text-clay">Refund policy</Link>
            <span className="h-3 w-px bg-line" />
            <Link href="/pages/shipping" className="hover:text-clay">Shipping policy</Link>
            <span className="h-3 w-px bg-line" />
            <Link href="/pages/policies" className="hover:text-clay">Privacy policy</Link>
          </p>
        </div>

        {/* ---------------------------------------------- right: summary */}
        <aside className="order-1 lg:order-2 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-[22px] border border-line bg-surface p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-[20px]">Order summary</h2>
              <span className="text-[12.5px] font-bold text-muted">{itemCount} item{itemCount === 1 ? "" : "s"}</span>
            </div>

            <ul className="thin-scroll mt-4 max-h-[38vh] space-y-3.5 overflow-y-auto pr-1">
              {lines.map((line) => (
                <li key={line.id} className="flex items-center gap-3">
                  <span className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-paper-2">
                    {line.image ? <Image src={line.image} alt={line.title} fill sizes="64px" className="object-cover" /> : null}
                    <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-ink px-1 text-[10.5px] font-black text-paper">
                      {line.quantity}
                    </span>
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13.5px] font-bold">{line.title}</span>
                    {line.variantTitle && line.variantTitle !== "Default Title" ? (
                      <span className="block truncate text-[12px] text-muted">{line.variantTitle}</span>
                    ) : null}
                  </span>
                  <span className="text-[13.5px] font-bold">{money(line.priceCents * line.quantity)}</span>
                </li>
              ))}
            </ul>

            <div className="mt-5 border-t border-line pt-5">
              {cart?.discount ? (
                <div className="mb-3 flex items-center justify-between rounded-xl bg-moss/10 px-3.5 py-2.5 text-[13px] font-semibold text-moss">
                  <span className="flex items-center gap-2">
                    <TagIcon className="h-4 w-4" /> {cart.discount.code}
                  </span>
                  <button type="button" onClick={removeDiscount} className="underline-offset-2 hover:underline">
                    Remove
                  </button>
                </div>
              ) : (
                <form
                  className="mb-3 flex gap-2"
                  onSubmit={async (event) => {
                    event.preventDefault();
                    setApplying(true);
                    setCodeError(null);
                    const result = await applyDiscount(code);
                    setApplying(false);
                    if (result.ok) setCode("");
                    else setCodeError(result.message);
                  }}
                >
                  <div className="relative flex-1">
                    <TagIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                    <Input
                      placeholder="Discount code"
                      className="h-11 rounded-full pl-9 uppercase"
                      value={code}
                      onChange={(event) => {
                        setCode(event.target.value);
                        setCodeError(null);
                      }}
                    />
                  </div>
                  <Button type="submit" variant="light" disabled={applying || !code.trim()}>
                    {applying ? <Spinner className="h-4 w-4" /> : "Apply"}
                  </Button>
                </form>
              )}
              {codeError ? <p className="mb-2 text-[12px] font-semibold text-clay">{codeError}</p> : null}

              <div className="space-y-2 text-[13.5px]">
                <Row label={`Subtotal (${itemCount})`} value={money(totals.subtotalCents)} />
                {totals.discountCents > 0 ? (
                  <Row label={`Discount${totals.discountLabel ? ` · ${totals.discountLabel}` : ""}`} value={`−${money(totals.discountCents)}`} tone="moss" />
                ) : null}
                <Row
                  label={`Shipping · ${totals.shippingLabel}`}
                  value={totals.shippingCents === 0 ? "Free" : money(totals.shippingCents)}
                />
                <Row label="Estimated tax (8.25%)" value={money(totals.taxCents)} />
              </div>

              <div className="mt-4 flex items-end justify-between border-t border-line pt-4">
                <span className="text-[14px] font-bold">Total</span>
                <span className="text-right">
                  <span className="block text-[11px] font-semibold uppercase tracking-[0.08em] text-muted">USD</span>
                  <span className="font-display block text-[30px] leading-none">{money(totals.totalCents)}</span>
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            {[
              { icon: TruckIcon, label: "Tracked delivery" },
              { icon: ShieldIcon, label: "2-year warranty" },
              { icon: CheckIcon, label: "30-day returns" },
            ].map((item) => (
              <div key={item.label} className="rounded-xl border border-line bg-surface px-2 py-3">
                <item.icon className="mx-auto h-4 w-4 text-clay" />
                <p className="mt-1.5 text-[11px] font-semibold leading-tight text-ink-2">{item.label}</p>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

function Row({ label, value, tone }: { label: string; value: string; tone?: "moss" }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className={tone === "moss" ? "text-moss" : "text-ink-2"}>{label}</span>
      <span className={`font-bold ${tone === "moss" ? "text-moss" : ""}`}>{value}</span>
    </div>
  );
}
