"use client";

import Image from "next/image";
import { useState } from "react";
import { ChevronLeft, ChevronRight } from "@/components/icons";

export function ProductGallery({ images, title }: { images: string[]; title: string }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState<{ x: number; y: number } | null>(null);
  const list = images.length ? images : [];

  if (list.length === 0) {
    return (
      <div className="grid aspect-4/5 place-items-center rounded-[24px] border border-line bg-paper-2 text-muted">
        <span className="font-display text-5xl">H&amp;Co</span>
      </div>
    );
  }

  const go = (delta: number) => setActive((current) => (current + delta + list.length) % list.length);

  return (
    <div className="flex flex-col-reverse gap-3 md:flex-row">
      {list.length > 1 ? (
        <div className="no-scrollbar flex gap-2.5 overflow-x-auto md:w-20 md:flex-col md:overflow-visible">
          {list.map((image, index) => (
            <button
              key={`${image}-${index}`}
              type="button"
              onClick={() => setActive(index)}
              aria-label={`View image ${index + 1}`}
              className={`relative h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 bg-paper-2 transition ${
                index === active ? "border-ink" : "border-transparent opacity-70 hover:opacity-100"
              }`}
            >
              <Image src={image} alt="" fill sizes="80px" className="object-cover" />
            </button>
          ))}
        </div>
      ) : null}

      <div className="relative flex-1">
        <div
          className="group relative aspect-4/5 overflow-hidden rounded-[24px] bg-paper-2"
          onMouseMove={(event) => {
            const rect = event.currentTarget.getBoundingClientRect();
            setZoom({
              x: ((event.clientX - rect.left) / rect.width) * 100,
              y: ((event.clientY - rect.top) / rect.height) * 100,
            });
          }}
          onMouseLeave={() => setZoom(null)}
        >
          <Image
            src={list[active]}
            alt={`${title} — view ${active + 1}`}
            fill
            priority
            sizes="(max-width: 768px) 100vw, 52vw"
            className="object-cover transition duration-300 group-hover:scale-150"
            style={zoom ? { transformOrigin: `${zoom.x}% ${zoom.y}%` } : undefined}
          />

          {list.length > 1 ? (
            <>
              <button
                type="button"
                onClick={() => go(-1)}
                aria-label="Previous image"
                className="absolute left-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-surface/90 opacity-0 shadow-md backdrop-blur transition hover:bg-surface group-hover:opacity-100 md:opacity-100"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <button
                type="button"
                onClick={() => go(1)}
                aria-label="Next image"
                className="absolute right-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-surface/90 opacity-0 shadow-md backdrop-blur transition hover:bg-surface group-hover:opacity-100 md:opacity-100"
              >
                <ChevronRight className="h-5 w-5" />
              </button>
            </>
          ) : null}

          <div className="absolute bottom-3 right-3 rounded-full bg-ink/75 px-3 py-1.5 text-[11.5px] font-bold text-paper backdrop-blur">
            {active + 1} / {list.length}
          </div>
        </div>
      </div>
    </div>
  );
}
