"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { CloseIcon, MinusIcon, PlusIcon, TrashIcon, TruckIcon, LockIcon, ArrowRight, TagIcon } from "@/components/icons";
import { Button, Spinner } from "@/components/ui";
import { money } from "@/lib/format";
import { useState } from "react";

const FREE_SHIPPING_THRESHOLD = 7500;

type Suggestion = { handle: string; title: string; priceCents: number; image: string | null };

export function CartDrawer({ suggestions = [] }: { suggestions?: Suggestion[] }) {
  const { isOpen, closeCart, lines, subtotalCents, itemCount, updateLine, removeLine, applyDiscount, cart } = useCart();
  const [code, setCode] = useState("");
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeCart();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [isOpen, closeCart]);

  if (!isOpen) return null;

  const remaining = Math.max(FREE_SHIPPING_THRESHOLD - subtotalCents, 0);
  const progress = Math.min(100, Math.round((subtotalCents / FREE_SHIPPING_THRESHOLD) * 100));

  const submitDiscount = async (event: React.FormEvent) => {
    event.preventDefault();
    setApplying(true);
    setError(null);
    const result = await applyDiscount(code);
    setApplying(false);
    if (result.ok) setCode("");
    else setError(result.message);
  };

  return (
    <div className="fixed inset-0 z-[80]">
      <div className="animate-fade absolute inset-0 bg-ink/45 backdrop-blur-[3px]" onClick={closeCart} />
      <aside className="animate-slide-in absolute inset-y-0 right-0 flex w-full max-w-[440px] flex-col bg-paper shadow-2xl">
        <div className="flex items-center justify-between border-b border-line px-5 py-4">
          <div>
            <h2 className="font-display text-[22px] leading-none">Your bag</h2>
            <p className="mt-1 text-[12.5px] text-muted">
              {itemCount === 0 ? "No items yet" : `${itemCount} item${itemCount > 1 ? "s" : ""}`}
            </p>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="grid h-9 w-9 place-items-center rounded-full transition hover:bg-ink/6"
            aria-label="Close bag"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        {lines.length > 0 ? (
          <div className="border-b border-line bg-surface/70 px-5 py-3">
            <div className="flex items-center gap-2 text-[12.5px] font-semibold">
              <TruckIcon className="h-4 w-4 text-moss" />
              {remaining > 0 ? (
                <span>
                  <span className="text-clay">{money(remaining)}</span> away from free standard shipping
                </span>
              ) : (
                <span className="text-moss">You've unlocked free standard shipping</span>
              )}
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-paper-2">
              <div className="h-full rounded-full bg-moss transition-all duration-500" style={{ width: `${progress}%` }} />
            </div>
          </div>
        ) : null}

        <div className="thin-scroll flex-1 overflow-y-auto px-5 py-4">
          {lines.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-paper-2 text-muted">
                <TruckIcon className="h-7 w-7" />
              </span>
              <div>
                <p className="font-display text-xl">Your bag is empty</p>
                <p className="mt-1 text-[13.5px] text-ink-2">Add something you'll use every day.</p>
              </div>
              <Button variant="primary" onClick={closeCart}>
                Start shopping
              </Button>
            </div>
          ) : (
            <ul className="space-y-4">
              {lines.map((line) => (
                <li key={line.id} className="flex gap-3.5 rounded-2xl border border-line bg-surface p-3">
                  <Link href={`/products/${line.handle}`} onClick={closeCart} className="relative h-24 w-20 shrink-0 overflow-hidden rounded-xl bg-paper-2">
                    {line.image ? <Image src={line.image} alt={line.title} fill sizes="80px" className="object-cover" /> : null}
                  </Link>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <Link href={`/products/${line.handle}`} onClick={closeCart} className="text-[14px] font-bold leading-tight hover:text-clay">
                        {line.title}
                      </Link>
                      <button
                        type="button"
                        onClick={() => removeLine(line.id)}
                        className="shrink-0 rounded-full p-1.5 text-muted transition hover:bg-clay/10 hover:text-clay"
                        aria-label={`Remove ${line.title}`}
                      >
                        <TrashIcon className="h-4 w-4" />
                      </button>
                    </div>
                    {line.variantTitle && line.variantTitle !== "Default Title" ? (
                      <p className="mt-0.5 text-[12.5px] text-muted">{line.variantTitle}</p>
                    ) : null}
                    <div className="mt-auto flex items-center justify-between pt-2">
                      <div className="flex items-center rounded-full border border-line">
                        <button
                          type="button"
                          onClick={() => updateLine(line.id, line.quantity - 1)}
                          className="grid h-8 w-8 place-items-center rounded-l-full transition hover:bg-paper-2"
                          aria-label="Decrease quantity"
                        >
                          <MinusIcon className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-7 text-center text-[13px] font-bold">{line.quantity}</span>
                        <button
                          type="button"
                          onClick={() => updateLine(line.id, line.quantity + 1)}
                          className="grid h-8 w-8 place-items-center rounded-r-full transition hover:bg-paper-2"
                          aria-label="Increase quantity"
                        >
                          <PlusIcon className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <span className="text-[14px] font-bold">{money(line.priceCents * line.quantity)}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {suggestions.length > 0 ? (
            <div className="mt-7">
              <p className="eyebrow text-muted">Complete your bag</p>
              <div className="no-scrollbar mt-3 flex gap-3 overflow-x-auto pb-2">
                {suggestions.map((item) => (
                  <Link
                    key={item.handle}
                    href={`/products/${item.handle}`}
                    onClick={closeCart}
                    className="group w-32 shrink-0"
                  >
                    <span className="relative block aspect-4/5 overflow-hidden rounded-xl bg-paper-2">
                      {item.image ? (
                        <Image
                          src={item.image}
                          alt={item.title}
                          fill
                          sizes="128px"
                          className="object-cover transition duration-500 group-hover:scale-105"
                        />
                      ) : null}
                    </span>
                    <span className="mt-1.5 block truncate text-[12.5px] font-semibold">{item.title}</span>
                    <span className="block text-[12px] text-muted">{money(item.priceCents)}</span>
                  </Link>
                ))}
              </div>
            </div>
          ) : null}
        </div>

        {lines.length > 0 ? (
          <div className="border-t border-line bg-surface px-5 py-4">
            <form onSubmit={submitDiscount} className="mb-3 flex gap-2">
              <div className="relative flex-1">
                <TagIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
                <input
                  value={code}
                  onChange={(event) => {
                    setCode(event.target.value);
                    setError(null);
                  }}
                  placeholder="Discount code"
                  className="h-11 w-full rounded-xl border border-line bg-paper/60 pl-9 pr-3 text-[13.5px] uppercase tracking-wide outline-none focus:border-ink"
                />
              </div>
              <Button type="submit" variant="light" size="md" disabled={applying || !code.trim()}>
                {applying ? <Spinner /> : "Apply"}
              </Button>
            </form>
            {error ? <p className="mb-2 text-[12.5px] font-semibold text-clay">{error}</p> : null}
            {cart?.discount ? (
              <p className="mb-3 flex items-center justify-between rounded-lg bg-moss/10 px-3 py-2 text-[12.5px] font-semibold text-moss">
                <span>
                  {cart.discount.code} applied {cart.totals.discountLabel ? `· ${cart.totals.discountLabel}` : ""}
                </span>
                <span>−{money(cart.totals.discountCents)}</span>
              </p>
            ) : null}

            <div className="space-y-1.5 text-[13.5px]">
              <div className="flex justify-between">
                <span className="text-ink-2">Subtotal</span>
                <span className="font-bold">{money(subtotalCents)}</span>
              </div>
              {cart && cart.totals.discountCents > 0 ? (
                <div className="flex justify-between text-moss">
                  <span>Discount</span>
                  <span className="font-bold">−{money(cart.totals.discountCents)}</span>
                </div>
              ) : null}
              <p className="text-[12px] text-muted">Shipping, taxes and discounts calculated at checkout.</p>
            </div>

            <Link
              href="/checkout"
              onClick={closeCart}
              className="mt-3 flex h-13 w-full items-center justify-center gap-2 rounded-full bg-ink text-[14.5px] font-bold text-paper transition hover:bg-clay"
            >
              <LockIcon className="h-4 w-4" /> Secure checkout · {money(subtotalCents)}
            </Link>
            <Link
              href="/cart"
              onClick={closeCart}
              className="mt-2 flex items-center justify-center gap-1.5 text-[13px] font-semibold text-ink-2 hover:text-clay"
            >
              View full bag <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        ) : null}
      </aside>
    </div>
  );
}
