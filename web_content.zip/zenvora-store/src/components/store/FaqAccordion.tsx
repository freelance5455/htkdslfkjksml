"use client";

import { useState } from "react";
import { ChevronDown } from "@/components/icons";

type Group = { group: string; items: { q: string; a: string }[] };

export function FaqAccordion({ groups }: { groups: Group[] }) {
  const [open, setOpen] = useState<string | null>(groups[0]?.items[0]?.q ?? null);

  return (
    <div className="mt-10 space-y-8">
      {groups.map((group) => (
        <section key={group.group}>
          <h2 className="eyebrow mb-4 text-clay">{group.group}</h2>
          <div className="divide-y divide-line overflow-hidden rounded-[20px] border border-line bg-surface">
            {group.items.map((item) => {
              const isOpen = open === item.q;
              return (
                <div key={item.q}>
                  <button
                    type="button"
                    onClick={() => setOpen(isOpen ? null : item.q)}
                    aria-expanded={isOpen}
                    className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left transition hover:bg-paper/60"
                  >
                    <span className="text-[14.5px] font-bold">{item.q}</span>
                    <ChevronDown className={`h-4 w-4 shrink-0 text-muted transition ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  {isOpen ? (
                    <p className="animate-fade px-5 pb-5 text-[14px] leading-relaxed text-ink-2">{item.a}</p>
                  ) : null}
                </div>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
