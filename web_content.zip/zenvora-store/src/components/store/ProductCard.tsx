import Link from "next/link";
import Image from "next/image";
import type { ProductCard as ProductCardData } from "@/lib/catalog";
import { Badge, Price, Stars } from "@/components/ui";
import { pctOff } from "@/lib/format";
import { QuickAdd } from "@/components/store/QuickAdd";

export function ProductCard({ product, priority = false }: { product: ProductCardData; priority?: boolean }) {
  const soldOut = product.inventoryQty <= 0;
  const off = pctOff(product.priceCents, product.compareAtPriceCents);

  return (
    <article className="group relative flex flex-col">
      <div className="relative aspect-4/5 overflow-hidden rounded-[20px] bg-paper-2">
        {product.images[0] || product.image ? (
          <>
            <Image
              src={(product.images[0] ?? product.image) as string}
              alt={product.title}
              fill
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
              className="object-cover transition duration-700 ease-out group-hover:scale-[1.06]"
              priority={priority}
            />
            {product.images[1] ? (
              <Image
                src={product.images[1]}
                alt=""
                fill
                sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                className="object-cover opacity-0 transition duration-700 group-hover:opacity-100"
              />
            ) : null}
          </>
        ) : (
          <div className="grid h-full place-items-center text-muted">
            <span className="font-display text-4xl">H&amp;Co</span>
          </div>
        )}

        <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {soldOut ? <Badge tone="ink">Sold out</Badge> : null}
          {!soldOut && off ? <Badge tone="sale">−{off}%</Badge> : null}
          {!soldOut && !off && product.tags.includes("bestseller") ? <Badge tone="gold">Bestseller</Badge> : null}
          {!soldOut && product.inventoryQty <= 5 ? <Badge tone="moss">Low stock</Badge> : null}
        </div>

        {!soldOut ? (
          <div className="absolute inset-x-3 bottom-3 translate-y-3 opacity-0 transition duration-300 group-hover:translate-y-0 group-hover:opacity-100">
            <QuickAdd product={product} />
          </div>
        ) : null}
      </div>

      <div className="mt-3.5 flex flex-1 flex-col">
        <p className="text-[11.5px] font-semibold uppercase tracking-[0.09em] text-muted">{product.vendor}</p>
        <Link href={`/products/${product.handle}`} className="mt-1 text-[15px] font-bold leading-snug hover:text-clay">
          {product.title}
        </Link>
        {product.reviewCount > 0 ? (
          <Stars rating={product.rating} count={product.reviewCount} className="mt-1.5" />
        ) : null}
        <Price
          priceCents={product.priceCents}
          compareAtPriceCents={product.compareAtPriceCents}
          showSave={false}
          className={`mt-1.5 text-[15px] font-bold ${soldOut ? "text-muted" : ""}`}
        />
      </div>
    </article>
  );
}
