"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Review } from "@/db/schema";
import { Button, Spinner, Textarea, Input } from "@/components/ui";
import { CheckIcon, StarIcon } from "@/components/icons";
import { formatDate } from "@/lib/format";

export function ReviewSection({
  productId,
  reviews,
  rating,
  reviewCount,
}: {
  productId: number;
  reviews: Review[];
  rating: number | null;
  reviewCount: number;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ author: "", email: "", title: "", body: "", rating: 5 });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hoverRating, setHoverRating] = useState(0);

  const distribution = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: reviews.filter((review) => review.rating === star).length,
  }));

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, ...form }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not save your review.");
      setForm({ author: "", email: "", title: "", body: "", rating: 5 });
      setOpen(false);
      router.refresh();
    } catch (submitError) {
      setError((submitError as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section id="reviews" className="scroll-mt-28 border-t border-line pt-14">
      <div className="grid gap-10 lg:grid-cols-[320px_1fr]">
        <div>
          <h2 className="font-display text-[clamp(1.6rem,3vw,2.2rem)] leading-tight">Customer reviews</h2>
          <div className="mt-4 flex items-end gap-3">
            <span className="font-display text-[52px] leading-none">{rating ? rating.toFixed(1) : "—"}</span>
            <div className="pb-1.5">
              <span className="flex gap-0.5 text-gold">
                {[1, 2, 3, 4, 5].map((star) => (
                  <StarIcon key={star} filled={(rating ?? 0) >= star - 0.35} className="h-4 w-4" strokeWidth={1.2} />
                ))}
              </span>
              <p className="mt-1 text-[12.5px] text-muted">
                Based on {reviewCount} verified review{reviewCount === 1 ? "" : "s"}
              </p>
            </div>
          </div>

          <div className="mt-5 space-y-1.5">
            {distribution.map((row) => {
              const width = reviewCount ? Math.round((row.count / reviewCount) * 100) : 0;
              return (
                <div key={row.star} className="flex items-center gap-2.5">
                  <span className="w-8 text-[12px] font-semibold text-muted">{row.star}★</span>
                  <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-paper-2">
                    <span className="block h-full rounded-full bg-gold" style={{ width: `${width}%` }} />
                  </span>
                  <span className="w-6 text-right text-[12px] text-muted">{row.count}</span>
                </div>
              );
            })}
          </div>

          <Button variant="outline" className="mt-6 w-full" onClick={() => setOpen((value) => !value)}>
            {open ? "Close" : "Write a review"}
          </Button>

          {open ? (
            <form onSubmit={submit} className="animate-rise mt-4 space-y-3 rounded-2xl border border-line bg-surface p-4">
              <div>
                <p className="eyebrow mb-2 text-muted">Your rating</p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setForm((prev) => ({ ...prev, rating: star }))}
                      onMouseEnter={() => setHoverRating(star)}
                      onMouseLeave={() => setHoverRating(0)}
                      aria-label={`${star} star${star > 1 ? "s" : ""}`}
                      className={`transition hover:scale-110 ${
                        (hoverRating || form.rating) >= star ? "text-gold" : "text-line"
                      }`}
                    >
                      <StarIcon filled={(hoverRating || form.rating) >= star} className="h-6 w-6" strokeWidth={1.2} />
                    </button>
                  ))}
                </div>
              </div>
              <Input
                placeholder="Your name"
                required
                value={form.author}
                onChange={(event) => setForm((prev) => ({ ...prev, author: event.target.value }))}
              />
              <Input
                type="email"
                placeholder="Email (optional, never published)"
                value={form.email}
                onChange={(event) => setForm((prev) => ({ ...prev, email: event.target.value }))}
              />
              <Input
                placeholder="Headline"
                value={form.title}
                onChange={(event) => setForm((prev) => ({ ...prev, title: event.target.value }))}
              />
              <Textarea
                placeholder="What did you like or dislike? How did you use it?"
                required
                minLength={10}
                value={form.body}
                onChange={(event) => setForm((prev) => ({ ...prev, body: event.target.value }))}
              />
              {error ? <p className="text-[12.5px] font-semibold text-clay">{error}</p> : null}
              <Button type="submit" disabled={busy} className="w-full">
                {busy ? <Spinner className="h-4 w-4" /> : <CheckIcon className="h-4 w-4" />} Submit review
              </Button>
            </form>
          ) : null}
        </div>

        <div className="space-y-4">
          {reviews.length === 0 ? (
            <p className="rounded-2xl border border-dashed border-line bg-surface/60 px-5 py-12 text-center text-[14px] text-muted">
              No reviews yet — be the first to tell people how it works in real life.
            </p>
          ) : (
            reviews.map((review) => (
              <article key={review.id} className="rounded-[20px] border border-line bg-surface p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <span className="grid h-10 w-10 place-items-center rounded-full bg-clay/12 text-[13px] font-black text-clay">
                      {review.author[0]?.toUpperCase()}
                    </span>
                    <div>
                      <p className="text-[14px] font-bold">{review.author}</p>
                      <p className="flex items-center gap-1.5 text-[12px] text-muted">
                        <CheckIcon className="h-3.5 w-3.5 text-moss" strokeWidth={2.4} /> Verified buyer ·{" "}
                        {formatDate(review.createdAt)}
                      </p>
                    </div>
                  </div>
                  <span className="flex shrink-0 gap-0.5 text-gold">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <StarIcon key={star} filled={review.rating >= star} className="h-3.5 w-3.5" strokeWidth={1.2} />
                    ))}
                  </span>
                </div>
                {review.title ? <h3 className="mt-3.5 text-[15px] font-bold">{review.title}</h3> : null}
                <p className="mt-1.5 text-[14px] leading-relaxed text-ink-2">{review.body}</p>
              </article>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
