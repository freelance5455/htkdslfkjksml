"use client";

import { useState } from "react";
import { ArrowRight, CheckIcon } from "@/components/icons";
import { Spinner } from "@/components/ui";

export function NewsletterForm({ compact = false }: { compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setState("loading");
    try {
      const response = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = (await response.json()) as { message?: string; error?: string };
      if (!response.ok) throw new Error(data.error ?? "Something went wrong");
      setMessage(data.message ?? "Subscribed");
      setState("done");
      setEmail("");
    } catch (error) {
      setMessage((error as Error).message);
      setState("error");
    }
  };

  if (state === "done") {
    return (
      <div className="flex items-center gap-2 rounded-full border border-moss/30 bg-moss/10 px-4 py-3 text-[13.5px] font-semibold text-moss">
        <CheckIcon className="h-4 w-4" /> {message}
      </div>
    );
  }

  return (
    <form onSubmit={submit} className={compact ? "w-full" : "w-full max-w-md"}>
      <div className="flex items-center gap-2 rounded-full border border-line bg-surface p-1.5 pl-4 focus-within:border-ink">
        <input
          type="email"
          required
          value={email}
          onChange={(event) => {
            setEmail(event.target.value);
            setState("idle");
          }}
          placeholder="Email address"
          className="h-9 w-full bg-transparent text-[13.5px] outline-none placeholder:text-muted"
        />
        <button
          type="submit"
          disabled={state === "loading"}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-ink text-paper transition hover:bg-clay disabled:opacity-60 sm:w-auto sm:px-4"
          aria-label="Subscribe"
        >
          {state === "loading" ? <Spinner className="h-4 w-4" /> : <ArrowRight className="h-4 w-4 sm:hidden" />}
          <span className="hidden text-[13px] font-bold sm:block">
            {state === "loading" ? "…" : "Join"}
          </span>
        </button>
      </div>
      {state === "error" ? <p className="mt-2 text-[12.5px] font-semibold text-clay">{message}</p> : null}
    </form>
  );
}
