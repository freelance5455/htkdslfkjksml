import Link from "next/link";
import { NewsletterForm } from "@/components/store/NewsletterForm";
import { InstagramIcon, PinterestIcon, TruckIcon, RefreshIcon, ShieldIcon, LeafIcon } from "@/components/icons";
import type { Collection } from "@/db/schema";

const SERVICE_BADGES = [
  { icon: TruckIcon, title: "Free shipping over $75", copy: "Carbon-neutral, 4–7 business days" },
  { icon: RefreshIcon, title: "30-day returns", copy: "No questions, prepaid label included" },
  { icon: ShieldIcon, title: "2-year warranty", copy: "On every electronic and leather good" },
  { icon: LeafIcon, title: "Plastic-free packing", copy: "Mushroom foam and paper tape" },
];

export function Footer({ collections }: { collections: Collection[] }) {
  return (
    <footer className="mt-24 border-t border-line bg-paper-2/60">
      <div className="mx-auto max-w-[1400px] px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-4 border-b border-line py-10 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICE_BADGES.map((badge) => (
            <div key={badge.title} className="flex items-start gap-3">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-surface text-clay shadow-sm">
                <badge.icon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-[13.5px] font-bold">{badge.title}</p>
                <p className="text-[12.5px] text-muted">{badge.copy}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid gap-10 py-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-9 w-9 place-items-center rounded-full bg-ink text-paper">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.5}>
                  <path d="M4 20V7.5L12 3l8 4.5V20" strokeLinejoin="round" />
                  <path d="M9 20v-6h6v6" strokeLinejoin="round" />
                </svg>
              </span>
              <span className="font-display text-[19px] font-semibold">
                Zenvora<span className="text-clay">&</span>
              </span>
            </div>
            <p className="mt-4 max-w-sm text-[13.5px] leading-relaxed text-ink-2">
              A small independent shop stocking well-made things for home, desk and travel. Designed in Copenhagen,
              made by 24 family-run workshops, shipped from Portland.
            </p>
            <div className="mt-5">
              <p className="eyebrow mb-2 text-muted">Get 10% off your first order</p>
              <NewsletterForm />
            </div>
          </div>

          <FooterColumn
            title="Shop"
            links={[
              { href: "/collections", label: "All products" },
              ...collections.map((collection) => ({ href: `/collections/${collection.handle}`, label: collection.title })),
              { href: "/search?q=sale", label: "Sale" },
            ]}
          />
          <FooterColumn
            title="Support"
            links={[
              { href: "/pages/shipping", label: "Shipping & returns" },
              { href: "/pages/faq", label: "FAQ" },
              { href: "/account", label: "Track your order" },
              { href: "/pages/contact", label: "Contact us" },
            ]}
          />
          <FooterColumn
            title="Company"
            links={[
              { href: "/pages/about", label: "Our story" },
              { href: "/pages/about#makers", label: "Our makers" },
              { href: "/pages/policies", label: "Policies" },
              { href: "/admin", label: "Store admin" },
            ]}
          />
        </div>

        <div className="flex flex-col items-center justify-between gap-5 border-t border-line py-7 sm:flex-row">
          <p className="text-[12.5px] text-muted">© {new Date().getFullYear()} Zenvora All rights reserved.</p>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              {["VISA", "MC", "AMEX", "PAY", "GPAY"].map((brand) => (
                <span
                  key={brand}
                  className="grid h-7 min-w-11 place-items-center rounded-md border border-line bg-surface px-2 text-[10px] font-black tracking-wide text-ink-2"
                >
                  {brand}
                </span>
              ))}
            </div>
            <span className="h-5 w-px bg-line" />
            <div className="flex items-center gap-1">
              <Link href="/pages/contact" className="grid h-9 w-9 place-items-center rounded-full transition hover:bg-surface" aria-label="Instagram">
                <InstagramIcon className="h-4.5 w-4.5" />
              </Link>
              <Link href="/pages/contact" className="grid h-9 w-9 place-items-center rounded-full transition hover:bg-surface" aria-label="Pinterest">
                <PinterestIcon className="h-4.5 w-4.5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <p className="eyebrow text-ink">{title}</p>
      <ul className="mt-4 space-y-2.5">
        {links.map((link) => (
          <li key={`${title}-${link.href}-${link.label}`}>
            <Link href={link.href} className="text-[13.5px] text-ink-2 transition hover:text-clay">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
