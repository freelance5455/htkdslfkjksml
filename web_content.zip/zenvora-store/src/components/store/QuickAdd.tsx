"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import type { ProductCard } from "@/lib/catalog";
import type { Variant } from "@/db/schema";
import { useCart } from "@/components/cart/CartProvider";
import { Spinner } from "@/components/ui";
import { CloseIcon, PlusIcon } from "@/components/icons";
import { money } from "@/lib/format";

export function QuickAdd({ product }: { product: ProductCard }) {
  const { addItem } = useCart();
  const [open, setOpen] = useState(false);
  const [variants, setVariants] = useState<Variant[] | null>(null);
  const [optionNames, setOptionNames] = useState<string[]>([]);
  const [optionValues, setOptionValues] = useState<string[][]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [selected, setSelected] = useState<Record<number, string>>({});
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onClick = (event: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const fetchVariants = async () => {
    if (variants) return variants;
    setLoading(true);
    try {
      const response = await fetch(`/api/products/${product.handle}`);
      const data = (await response.json()) as {
        variants?: Variant[];
        product?: { optionNames?: string[]; optionValues?: string[][] };
      };
      const list = data.variants ?? [];
      setVariants(list);
      setOptionNames(data.product?.optionNames ?? []);
      setOptionValues(data.product?.optionValues ?? []);
      if (list.length === 1) {
        setSelected({ 0: list[0].option1 ?? "", 1: list[0].option2 ?? "" });
      }
      return list;
    } finally {
      setLoading(false);
    }
  };

  const handleClick = async () => {
    const list = await fetchVariants();
    if (list.length <= 1) {
      const variant = list[0];
      if (!variant) return;
      setBusy(true);
      await addItem(variant.id, 1, { title: product.title, image: product.images[0] ?? product.image });
      setBusy(false);
      setOpen(false);
      return;
    }
    setOpen(true);
  };

  const matchedVariant = () => {
    if (!variants?.length) return null;
    const wanted = optionNames.map((_name: string, index: number) => selected[index]);
    if (wanted.some((value) => !value)) return null;
    return (
      variants.find((variant) =>
        wanted.every((value, index) => (index === 0 ? variant.option1 === value : variant.option2 === value)),
      ) ?? null
    );
  };

  const addMatched = async () => {
    const variant = matchedVariant();
    if (!variant) return;
    setBusy(true);
    await addItem(variant.id, 1, {
      title: `${product.title} — ${variant.title}`,
      image: variant.image ?? product.images[0] ?? product.image,
    });
    setBusy(false);
    setOpen(false);
  };

  return (
    <div ref={wrapRef} className="relative">
      <button
        type="button"
        onClick={handleClick}
        disabled={busy}
        className="flex h-11 w-full items-center justify-center gap-2 rounded-full bg-surface/95 text-[13.5px] font-bold text-ink shadow-[0_10px_30px_rgba(25,21,18,0.18)] backdrop-blur transition hover:bg-ink hover:text-paper disabled:opacity-60"
      >
        {busy || loading ? <Spinner className="h-4 w-4" /> : <PlusIcon className="h-4 w-4" />}
        Quick add
      </button>

      {open && variants && variants.length > 1 ? (
        <div className="animate-rise absolute inset-x-0 bottom-14 z-20 rounded-2xl border border-line bg-surface p-4 shadow-[0_24px_60px_rgba(25,21,18,0.22)]">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate text-[14px] font-bold">{product.title}</p>
              <p className="text-[12.5px] text-muted">{money(product.priceCents)}</p>
            </div>
            <button type="button" onClick={() => setOpen(false)} className="rounded-full p-1 hover:bg-ink/6" aria-label="Close">
              <CloseIcon className="h-4 w-4" />
            </button>
          </div>

          {optionNames.map((name: string, index: number) => {
            const values = optionValues[index] ?? [];
            return (
              <div key={name} className="mt-3">
                <p className="eyebrow text-muted">{name}</p>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {values.map((value) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setSelected((prev) => ({ ...prev, [index]: value as string }))}
                      className={`rounded-full border px-3 py-1.5 text-[12.5px] font-semibold transition ${
                        selected[index] === value
                          ? "border-ink bg-ink text-paper"
                          : "border-line bg-paper/60 hover:border-ink/50"
                      }`}
                    >
                      {value}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}

          {(() => {
            const variant = matchedVariant();
            return (
              <button
                type="button"
                onClick={addMatched}
                disabled={!variant || busy}
                className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-full bg-ink text-[13.5px] font-bold text-paper transition hover:bg-clay disabled:opacity-40"
              >
                {busy ? <Spinner className="h-4 w-4" /> : null}
                {variant ? `Add · ${money(variant.priceCents)}` : "Select options"}
              </button>
            );
          })()}
          <p className="mt-2 flex items-center gap-1.5 text-[11.5px] text-muted">
            {product.images[0] ? (
              <span className="relative h-4 w-4 overflow-hidden rounded">
                <Image src={product.images[0]} alt="" fill sizes="16px" className="object-cover" />
              </span>
            ) : null}
            Free returns within 30 days
          </p>
        </div>
      ) : null}
    </div>
  );
}
