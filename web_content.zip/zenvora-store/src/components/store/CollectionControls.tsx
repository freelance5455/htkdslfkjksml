"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { SlidersIcon, CloseIcon, CheckIcon } from "@/components/icons";
import { Button, Select } from "@/components/ui";
import { money } from "@/lib/format";

export type Facets = {
  vendors: string[];
  tags: string[];
  priceRange: { min: number; max: number };
};

type Props = {
  basePath: string;
  params: Record<string, string | undefined>;
  facets: Facets;
  total: number;
  showing: number;
};

const SORTS = [
  { value: "featured", label: "Featured" },
  { value: "best-selling", label: "Best selling" },
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "title-asc", label: "Alphabetical" },
];

export function CollectionControls({ basePath, params, facets, total, showing }: Props) {
  const router = useRouter();
  const [sheetOpen, setSheetOpen] = useState(false);

  const update = (changes: Record<string, string | null>) => {
    const next = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value && key !== "page") next.set(key, value);
    });
    Object.entries(changes).forEach(([key, value]) => {
      if (value === null || value === "") next.delete(key);
      else next.set(key, value);
    });
    const qs = next.toString();
    router.push(qs ? `${basePath}?${qs}` : basePath, { scroll: false });
  };

  const toggleMulti = (key: string, value: string) => {
    const current = (params[key] ?? "").split(",").filter(Boolean);
    const nextValues = current.includes(value) ? current.filter((item) => item !== value) : [...current, value];
    update({ [key]: nextValues.length ? nextValues.join(",") : null });
  };

  const activeChips = [
    ...(params.vendor ? params.vendor.split(",").map((value) => ({ key: "vendor", value, label: value })) : []),
    ...(params.tag ? params.tag.split(",").map((value) => ({ key: "tag", value, label: `#${value}` })) : []),
    ...(params.inStock ? [{ key: "inStock", value: "1", label: "In stock only" }] : []),
    ...(params.minPrice ? [{ key: "minPrice", value: params.minPrice, label: `From ${money(Number(params.minPrice) * 100)}` }] : []),
    ...(params.maxPrice ? [{ key: "maxPrice", value: params.maxPrice, label: `Up to ${money(Number(params.maxPrice) * 100)}` }] : []),
    ...(params.q ? [{ key: "q", value: params.q, label: `“${params.q}”` }] : []),
  ];

  const removeChip = (key: string, value: string) => {
    if (key === "inStock" || key === "minPrice" || key === "maxPrice" || key === "q") {
      update({ [key]: null });
      return;
    }
    const current = (params[key] ?? "").split(",").filter(Boolean);
    const nextValues = current.filter((item) => item !== value);
    update({ [key]: nextValues.length ? nextValues.join(",") : null });
  };

  const filterPanel = (
    <div className="space-y-7">
      <FilterGroup title="Availability">
        <CheckRow
          label="In stock only"
          checked={Boolean(params.inStock)}
          onChange={() => update({ inStock: params.inStock ? null : "1" })}
        />
      </FilterGroup>

      {facets.vendors.length > 0 ? (
        <FilterGroup title="Maker">
          {facets.vendors.map((vendor) => (
            <CheckRow
              key={vendor}
              label={vendor}
              checked={(params.vendor ?? "").split(",").includes(vendor)}
              onChange={() => toggleMulti("vendor", vendor)}
            />
          ))}
        </FilterGroup>
      ) : null}

      <FilterGroup title="Price">
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={0}
            placeholder="Min"
            defaultValue={params.minPrice ?? ""}
            onBlur={(event) => update({ minPrice: event.target.value ? event.target.value : null })}
            className="h-10 w-full rounded-xl border border-line bg-paper/50 px-3 text-[13px] outline-none focus:border-ink"
          />
          <span className="text-muted">–</span>
          <input
            type="number"
            min={0}
            placeholder="Max"
            defaultValue={params.maxPrice ?? ""}
            onBlur={(event) => update({ maxPrice: event.target.value ? event.target.value : null })}
            className="h-10 w-full rounded-xl border border-line bg-paper/50 px-3 text-[13px] outline-none focus:border-ink"
          />
        </div>
        <p className="mt-2 text-[12px] text-muted">
          Range in this collection: {money(facets.priceRange.min)} – {money(facets.priceRange.max)}
        </p>
      </FilterGroup>

      {facets.tags.length > 0 ? (
        <FilterGroup title="Tags">
          <div className="flex flex-wrap gap-1.5">
            {facets.tags.slice(0, 14).map((tag) => {
              const active = (params.tag ?? "").split(",").includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleMulti("tag", tag)}
                  className={`rounded-full border px-3 py-1.5 text-[12px] font-semibold transition ${
                    active ? "border-ink bg-ink text-paper" : "border-line bg-paper/60 hover:border-ink/50"
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </FilterGroup>
      ) : null}

      {activeChips.length > 0 ? (
        <Button variant="outline" size="sm" className="w-full" onClick={() => router.push(basePath, { scroll: false })}>
          Clear all filters
        </Button>
      ) : null}
    </div>
  );

  return (
    <>
      <div className="flex flex-col gap-4 border-b border-line pb-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setSheetOpen(true)}
            className="flex h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-[13.5px] font-bold transition hover:border-ink lg:hidden"
          >
            <SlidersIcon className="h-4 w-4" /> Filter &amp; sort
            {activeChips.length ? (
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-clay px-1 text-[11px] text-white">
                {activeChips.length}
              </span>
            ) : null}
          </button>
          <p className="text-[13.5px] text-muted">
            <span className="font-bold text-ink">{showing}</span> of {total} product{total === 1 ? "" : "s"}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {activeChips.length > 0 ? (
            <div className="no-scrollbar hidden max-w-[46%] items-center gap-1.5 overflow-x-auto lg:flex">
              {activeChips.map((chip) => (
                <button
                  key={`${chip.key}-${chip.value}`}
                  type="button"
                  onClick={() => removeChip(chip.key, chip.value)}
                  className="flex shrink-0 items-center gap-1.5 rounded-full border border-line bg-surface px-3 py-1.5 text-[12px] font-semibold transition hover:border-clay hover:text-clay"
                >
                  {chip.label}
                  <CloseIcon className="h-3 w-3" />
                </button>
              ))}
            </div>
          ) : null}
          <div className="relative">
            <Select
              aria-label="Sort by"
              className="h-11 w-[210px] rounded-full border-line bg-surface pr-10 text-[13.5px] font-semibold"
              value={params.sort ?? "featured"}
              onChange={(event) => update({ sort: event.target.value })}
            >
              {SORTS.map((sort) => (
                <option key={sort.value} value={sort.value}>
                  {sort.label}
                </option>
              ))}
            </Select>
            <svg
              viewBox="0 0 24 24"
              className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted"
              fill="none"
              stroke="currentColor"
              strokeWidth={1.8}
            >
              <path d="m6 9 6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </div>

      <aside className="hidden w-60 shrink-0 lg:block">{filterPanel}</aside>

      {sheetOpen ? (
        <div className="fixed inset-0 z-[75] lg:hidden">
          <div className="animate-fade absolute inset-0 bg-ink/45 backdrop-blur-sm" onClick={() => setSheetOpen(false)} />
          <div className="animate-slide-in absolute inset-y-0 right-0 flex w-[88%] max-w-sm flex-col bg-paper">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="font-display text-xl">Filter &amp; sort</h2>
              <button type="button" onClick={() => setSheetOpen(false)} className="grid h-9 w-9 place-items-center rounded-full hover:bg-ink/6" aria-label="Close filters">
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>
            <div className="thin-scroll flex-1 overflow-y-auto px-5 py-5">{filterPanel}</div>
            <div className="border-t border-line p-4">
              <Button className="w-full" onClick={() => setSheetOpen(false)}>
                Show {total} result{total === 1 ? "" : "s"}
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="eyebrow mb-3 text-ink">{title}</p>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function CheckRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <button type="button" onClick={onChange} className="flex w-full items-center gap-2.5 text-left">
      <span
        className={`grid h-5 w-5 shrink-0 place-items-center rounded-md border transition ${
          checked ? "border-ink bg-ink text-paper" : "border-line bg-surface"
        }`}
      >
        {checked ? <CheckIcon className="h-3 w-3" strokeWidth={3} /> : null}
      </span>
      <span className={`text-[13.5px] ${checked ? "font-bold" : "text-ink-2"}`}>{label}</span>
    </button>
  );
}

export function Pagination({ basePath, params, page, pages }: { basePath: string; params: Record<string, string | undefined>; page: number; pages: number }) {
  const router = useRouter();
  if (pages <= 1) return null;

  const go = (target: number) => {
    const next = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value && key !== "page") next.set(key, value);
    });
    if (target > 1) next.set("page", String(target));
    const qs = next.toString();
    router.push(qs ? `${basePath}?${qs}` : basePath, { scroll: false });
  };

  return (
    <nav className="mt-12 flex items-center justify-center gap-1.5" aria-label="Pagination">
      <button
        type="button"
        onClick={() => go(page - 1)}
        disabled={page <= 1}
        className="h-10 rounded-full border border-line bg-surface px-4 text-[13px] font-bold transition hover:border-ink disabled:opacity-40"
      >
        Previous
      </button>
      {Array.from({ length: pages }).map((_, index) => (
        <button
          key={index}
          type="button"
          onClick={() => go(index + 1)}
          className={`h-10 w-10 rounded-full border text-[13px] font-bold transition ${
            index + 1 === page ? "border-ink bg-ink text-paper" : "border-line bg-surface hover:border-ink"
          }`}
        >
          {index + 1}
        </button>
      ))}
      <button
        type="button"
        onClick={() => go(page + 1)}
        disabled={page >= pages}
        className="h-10 rounded-full border border-line bg-surface px-4 text-[13px] font-bold transition hover:border-ink disabled:opacity-40"
      >
        Next
      </button>
    </nav>
  );
}
