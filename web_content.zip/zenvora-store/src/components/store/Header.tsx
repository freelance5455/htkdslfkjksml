"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import {
  CartIcon,
  ChevronDown,
  CloseIcon,
  MenuIcon,
  SearchIcon,
  UserIcon,
  ArrowRight,
} from "@/components/icons";
import { useCart } from "@/components/cart/CartProvider";
import { money } from "@/lib/format";

type NavCollection = { handle: string; title: string; image: string | null; productCount: number };

const ANNOUNCEMENTS = [
  "Complimentary standard shipping over $75",
  "New season drop — Home & Living is live",
  "Use code WELCOME10 for 10% off your first order",
  "Carbon-neutral delivery on every order",
];

export function Header({ collections }: { collections: NavCollection[] }) {
  const { itemCount, openCart } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [announcementIndex, setAnnouncementIndex] = useState(0);
  const [shopOpen, setShopOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setAnnouncementIndex((index) => (index + 1) % ANNOUNCEMENTS.length), 4200);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
    setShopOpen(false);
  }, [pathname]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSearchOpen(false);
        setMenuOpen(false);
      }
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const navLinks = [
    { href: "/collections", label: "All collections" },
    ...collections.slice(0, 4).map((collection) => ({ href: `/collections/${collection.handle}`, label: collection.title })),
  ];

  return (
    <header className="sticky top-0 z-50">
      <div className="relative overflow-hidden bg-ink text-paper">
        <div key={announcementIndex} className="animate-fade flex h-9 items-center justify-center px-4">
          <p className="eyebrow text-[10.5px] text-paper/85">{ANNOUNCEMENTS[announcementIndex]}</p>
        </div>
      </div>

      <div
        className={`border-b transition-all duration-300 ${
          scrolled ? "border-line bg-paper/92 backdrop-blur-xl" : "border-transparent bg-paper"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-[1400px] items-center gap-3 px-4 sm:px-6 lg:h-[74px]">
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="-ml-1 grid h-10 w-10 place-items-center rounded-full text-ink transition hover:bg-ink/6 lg:hidden"
            aria-label="Open menu"
          >
            <MenuIcon className="h-5 w-5" />
          </button>

          <nav className="hidden items-center gap-1 lg:flex">
            <div
              className="relative"
              onMouseEnter={() => setShopOpen(true)}
              onMouseLeave={() => setShopOpen(false)}
            >
              <button
                type="button"
                onClick={() => setShopOpen((open) => !open)}
                className="flex h-10 items-center gap-1.5 rounded-full px-3.5 text-[13.5px] font-semibold text-ink-2 transition hover:bg-ink/6 hover:text-ink"
              >
                Shop
                <ChevronDown className={`h-4 w-4 transition ${shopOpen ? "rotate-180" : ""}`} />
              </button>
              {shopOpen ? (
                <div className="animate-fade absolute left-0 top-12 w-[560px] overflow-hidden rounded-2xl border border-line bg-surface shadow-[0_28px_70px_rgba(25,21,18,0.16)]">
                  <div className="grid grid-cols-2 gap-1 p-3">
                    {collections.map((collection) => (
                      <Link
                        key={collection.handle}
                        href={`/collections/${collection.handle}`}
                        className="group flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-paper"
                      >
                        <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-paper-2">
                          {collection.image ? (
                            <Image
                              src={collection.image}
                              alt=""
                              fill
                              sizes="48px"
                              className="object-cover transition duration-500 group-hover:scale-105"
                            />
                          ) : null}
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate text-[13.5px] font-bold">{collection.title}</span>
                          <span className="block text-[12px] text-muted">{collection.productCount} products</span>
                        </span>
                      </Link>
                    ))}
                  </div>
                  <div className="flex items-center justify-between border-t border-line bg-paper/60 px-4 py-3">
                    <p className="text-[12.5px] text-ink-2">Free returns within 30 days.</p>
                    <Link
                      href="/collections"
                      className="flex items-center gap-1 text-[12.5px] font-bold text-clay hover:underline"
                    >
                      Browse everything <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
              ) : null}
            </div>

            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`h-10 rounded-full px-3.5 text-[13.5px] font-semibold leading-10 transition hover:bg-ink/6 ${
                  pathname === link.href ? "text-ink" : "text-ink-2 hover:text-ink"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/pages/about"
              className="h-10 rounded-full px-3.5 text-[13.5px] font-semibold leading-10 text-ink-2 transition hover:bg-ink/6 hover:text-ink"
            >
              Our story
            </Link>
          </nav>

          <Link href="/" className="group mx-auto flex items-center gap-2 lg:mx-0 lg:ml-4">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-ink text-paper transition group-hover:bg-clay">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.5}>
                <path d="M4 20V7.5L12 3l8 4.5V20" strokeLinejoin="round" />
                <path d="M9 20v-6h6v6" strokeLinejoin="round" />
              </svg>
            </span>
            <span className="font-display text-[19px] font-semibold tracking-tight">
              Zenvora<span className="text-clay">&</span>
            </span>
          </Link>

          <div className="ml-auto flex items-center gap-1">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="grid h-10 w-10 place-items-center rounded-full text-ink transition hover:bg-ink/6"
              aria-label="Search"
            >
              <SearchIcon className="h-5 w-5" />
            </button>
            <Link
              href="/account"
              className="hidden h-10 w-10 place-items-center rounded-full text-ink transition hover:bg-ink/6 sm:grid"
              aria-label="Account"
            >
              <UserIcon className="h-5 w-5" />
            </Link>
            <button
              type="button"
              onClick={openCart}
              className="relative grid h-10 w-10 place-items-center rounded-full text-ink transition hover:bg-ink/6"
              aria-label={`Open bag, ${itemCount} items`}
            >
              <CartIcon className="h-5 w-5" />
              {itemCount > 0 ? (
                <span className="absolute -right-0.5 -top-0.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-clay px-1 text-[10px] font-black text-white">
                  {itemCount}
                </span>
              ) : null}
            </button>
          </div>
        </div>
      </div>

      {searchOpen ? <SearchOverlay onClose={() => setSearchOpen(false)} router={router} /> : null}

      {menuOpen ? (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <div className="animate-fade absolute inset-0 bg-ink/45 backdrop-blur-sm" onClick={() => setMenuOpen(false)} />
          <div className="animate-slide-in absolute inset-y-0 left-0 flex w-[86%] max-w-sm flex-col bg-paper">
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <span className="font-display text-lg">Menu</span>
              <button
                type="button"
                onClick={() => setMenuOpen(false)}
                className="grid h-9 w-9 place-items-center rounded-full hover:bg-ink/6"
                aria-label="Close menu"
              >
                <CloseIcon className="h-5 w-5" />
              </button>
            </div>
            <div className="thin-scroll flex-1 overflow-y-auto px-3 py-4">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center justify-between rounded-xl px-3 py-3 text-[15px] font-semibold hover:bg-surface"
                >
                  {link.label}
                  <ArrowRight className="h-4 w-4 text-muted" />
                </Link>
              ))}
              <div className="my-3 h-px bg-line" />
              {[
                { href: "/pages/about", label: "Our story" },
                { href: "/pages/shipping", label: "Shipping & returns" },
                { href: "/pages/contact", label: "Contact" },
                { href: "/account", label: "Track an order" },
                { href: "/admin", label: "Store admin" },
              ].map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="block rounded-xl px-3 py-2.5 text-[14px] text-ink-2 hover:bg-surface"
                >
                  {link.label}
                </Link>
              ))}
            </div>
            <div className="border-t border-line p-4">
              <Link
                href="/cart"
                className="flex h-12 items-center justify-center gap-2 rounded-full bg-ink text-[14px] font-bold text-paper"
              >
                <CartIcon className="h-4 w-4" /> View bag ({itemCount})
              </Link>
            </div>
          </div>
        </div>
      ) : null}
    </header>
  );
}

function SearchOverlay({ onClose, router }: { onClose: () => void; router: ReturnType<typeof useRouter> }) {
  const [term, setTerm] = useState("");
  const [results, setResults] = useState<{ handle: string; title: string; priceCents: number; image: string | null }[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (term.trim().length < 2) {
      setResults([]);
      return;
    }
    let active = true;
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(term)}`);
        const data = (await response.json()) as { results?: typeof results };
        if (active) setResults(data.results ?? []);
      } finally {
        if (active) setLoading(false);
      }
    }, 220);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [term]);

  const trending = ["Candle", "Leather tote", "Serum", "Headphones", "Ceramics"];

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center px-4 pt-24">
      <div className="animate-fade absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={onClose} />
      <div className="animate-rise relative w-full max-w-2xl overflow-hidden rounded-2xl border border-line bg-surface shadow-[0_30px_80px_rgba(25,21,18,0.28)]">
        <form
          className="flex items-center gap-3 border-b border-line px-4 py-3.5"
          onSubmit={(event) => {
            event.preventDefault();
            if (!term.trim()) return;
            router.push(`/search?q=${encodeURIComponent(term.trim())}`);
            onClose();
          }}
        >
          <SearchIcon className="h-5 w-5 shrink-0 text-muted" />
          <input
            ref={inputRef}
            value={term}
            onChange={(event) => setTerm(event.target.value)}
            placeholder="Search products, collections, vendors…"
            className="w-full bg-transparent text-[15px] outline-none placeholder:text-muted"
          />
          {loading ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-line border-t-ink" /> : null}
          <button type="button" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-full hover:bg-ink/6" aria-label="Close search">
            <CloseIcon className="h-4 w-4" />
          </button>
        </form>

        <div className="thin-scroll max-h-[52vh] overflow-y-auto p-3">
          {term.trim().length < 2 ? (
            <div className="px-2 py-3">
              <p className="eyebrow text-muted">Trending searches</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {trending.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => setTerm(item)}
                    className="rounded-full border border-line bg-paper px-3 py-1.5 text-[12.5px] font-semibold transition hover:border-ink"
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          ) : results.length === 0 && !loading ? (
            <p className="px-3 py-8 text-center text-sm text-muted">
              No matches for “{term}”. Try “candle”, “leather” or “audio”.
            </p>
          ) : (
            results.map((result) => (
              <Link
                key={result.handle}
                href={`/products/${result.handle}`}
                onClick={onClose}
                className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-paper"
              >
                <span className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg bg-paper-2">
                  {result.image ? <Image src={result.image} alt="" fill sizes="48px" className="object-cover" /> : null}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[14px] font-semibold">{result.title}</span>
                  <span className="block text-[12.5px] text-muted">{money(result.priceCents)}</span>
                </span>
                <ArrowRight className="h-4 w-4 text-muted" />
              </Link>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
