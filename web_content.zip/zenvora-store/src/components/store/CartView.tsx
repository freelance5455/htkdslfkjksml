"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { useCart } from "@/components/cart/CartProvider";
import { Button, EmptyState, Input, LinkButton, Spinner, Textarea } from "@/components/ui";
import { ArrowRight, LockIcon, MinusIcon, PlusIcon, TagIcon, TrashIcon, TruckIcon } from "@/components/icons";
import { money, SHIPPING_RATES } from "@/lib/format";

export function CartView() {
  const { lines, subtotalCents, itemCount, updateLine, removeLine, applyDiscount, removeDiscount, cart, setNote } = useCart();
  const [code, setCode] = useState("");
  const [applying, setApplying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [shippingMethod, setShippingMethod] = useState("standard");
  const [noteOpen, setNoteOpen] = useState(Boolean(cart?.note));
  const [noteText, setNoteText] = useState(cart?.note ?? "");

  if (lines.length === 0) {
    return (
      <div className="mt-8">
        <EmptyState
          title="Your bag is empty"
          copy="Browse the collections and add something you'll reach for every day. Free standard shipping kicks in at $75."
          action={
            <LinkButton href="/collections">
              Start shopping <ArrowRight className="h-4 w-4" />
            </LinkButton>
          }
        />
      </div>
    );
  }

  const submitDiscount = async (event: React.FormEvent) => {
    event.preventDefault();
    setApplying(true);
    setError(null);
    const result = await applyDiscount(code);
    setApplying(false);
    if (result.ok) setCode("");
    else setError(result.message);
  };

  const selectedRate = SHIPPING_RATES.find((rate) => rate.id === shippingMethod) ?? SHIPPING_RATES[0];
  const shippingCents =
    selectedRate.freeOverCents != null && subtotalCents >= selectedRate.freeOverCents
      ? 0
      : cart?.totals.discountType === "free_shipping"
        ? 0
        : selectedRate.priceCents;
  const discountCents = cart?.totals.discountCents ?? 0;
  const taxCents = Math.round((subtotalCents - discountCents) * 0.0825);
  const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

  return (
    <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_380px]">
      <div>
        <div className="hidden grid-cols-[1fr_auto_auto] gap-4 border-b border-line pb-3 text-[11px] font-bold uppercase tracking-[0.11em] text-muted sm:grid">
          <span>Product</span>
          <span className="w-28 text-center">Quantity</span>
          <span className="w-24 text-right">Total</span>
        </div>

        <ul className="divide-y divide-line">
          {lines.map((line) => (
            <li key={line.id} className="flex gap-4 py-5">
              <Link href={`/products/${line.handle}`} className="relative h-28 w-24 shrink-0 overflow-hidden rounded-xl bg-paper-2 sm:h-32 sm:w-28">
                {line.image ? <Image src={line.image} alt={line.title} fill sizes="112px" className="object-cover" /> : null}
              </Link>

              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <Link href={`/products/${line.handle}`} className="text-[15px] font-bold leading-snug hover:text-clay">
                      {line.title}
                    </Link>
                    {line.variantTitle && line.variantTitle !== "Default Title" ? (
                      <p className="mt-1 text-[13px] text-muted">{line.variantTitle}</p>
                    ) : null}
                    <p className="mt-1 text-[12px] uppercase tracking-[0.08em] text-muted">{line.vendor}</p>
                    {line.trackInventory && line.inventoryQty <= 5 ? (
                      <p className="mt-1.5 text-[12px] font-semibold text-gold">Only {line.inventoryQty} left</p>
                    ) : null}
                  </div>
                  <div className="text-right">
                    <p className="text-[15px] font-bold sm:hidden">{money(line.priceCents * line.quantity)}</p>
                    <p className="hidden text-[15px] font-bold sm:block">{money(line.priceCents * line.quantity)}</p>
                    <p className="mt-0.5 text-[12.5px] text-muted">{money(line.priceCents)} each</p>
                  </div>
                </div>

                <div className="mt-auto flex items-center gap-3 pt-3">
                  <div className="flex items-center rounded-full border border-line bg-surface">
                    <button
                      type="button"
                      onClick={() => updateLine(line.id, line.quantity - 1)}
                      className="grid h-9 w-9 place-items-center rounded-l-full transition hover:bg-paper-2"
                      aria-label="Decrease quantity"
                    >
                      <MinusIcon className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-8 text-center text-[13.5px] font-bold">{line.quantity}</span>
                    <button
                      type="button"
                      onClick={() => updateLine(line.id, line.quantity + 1)}
                      className="grid h-9 w-9 place-items-center rounded-r-full transition hover:bg-paper-2"
                      aria-label="Increase quantity"
                    >
                      <PlusIcon className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeLine(line.id)}
                    className="flex items-center gap-1.5 rounded-full px-3 py-2 text-[12.5px] font-semibold text-muted transition hover:bg-clay/10 hover:text-clay"
                  >
                    <TrashIcon className="h-4 w-4" /> Remove
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <form onSubmit={submitDiscount} className="flex w-full max-w-sm gap-2">
            <div className="relative flex-1">
              <TagIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <input
                value={code}
                onChange={(event) => {
                  setCode(event.target.value);
                  setError(null);
                }}
                placeholder="Discount code"
                className="h-11 w-full rounded-full border border-line bg-surface pl-9 pr-4 text-[13.5px] uppercase tracking-wide outline-none focus:border-ink"
              />
            </div>
            <Button type="submit" variant="light" disabled={applying || !code.trim()}>
              {applying ? <Spinner className="h-4 w-4" /> : "Apply"}
            </Button>
          </form>
          <p className="text-[12.5px] text-muted">
            Try <span className="font-bold text-ink">WELCOME10</span>, <span className="font-bold text-ink">SPRING25</span> or{" "}
            <span className="font-bold text-ink">FREESHIP</span>
          </p>
        </div>
        {error ? <p className="mt-2 text-[12.5px] font-semibold text-clay">{error}</p> : null}
        {cart?.discount ? (
          <div className="mt-3 flex items-center justify-between rounded-xl bg-moss/10 px-4 py-2.5 text-[13px] font-semibold text-moss">
            <span>
              {cart.discount.code} applied{cart.totals.discountLabel ? ` · ${cart.totals.discountLabel}` : ""}
            </span>
            <button type="button" onClick={removeDiscount} className="underline-offset-2 hover:underline">
              Remove
            </button>
          </div>
        ) : null}

        <div className="mt-6 rounded-2xl border border-line bg-surface">
          <button
            type="button"
            onClick={() => setNoteOpen((open) => !open)}
            className="flex w-full items-center justify-between px-4 py-3.5 text-[13.5px] font-bold"
          >
            <span className="flex items-center gap-2">
              <TruckIcon className="h-4 w-4 text-clay" /> Add order notes (gift message, monogram, delivery instructions)
            </span>
            <span className="text-muted">{noteOpen ? "−" : "+"}</span>
          </button>
          {noteOpen ? (
            <div className="border-t border-line p-4">
              <Textarea
                value={noteText}
                onChange={(event) => setNoteText(event.target.value)}
                onBlur={() => void setNote(noteText)}
                placeholder="e.g. Please leave with the neighbour at number 12."
                maxLength={500}
              />
              <p className="mt-1.5 text-[12px] text-muted">{noteText.length}/500 characters</p>
            </div>
          ) : null}
        </div>
      </div>

      <aside className="lg:sticky lg:top-28 lg:self-start">
        <div className="rounded-[22px] border border-line bg-surface p-6">
          <h2 className="font-display text-[22px]">Order summary</h2>

          <div className="mt-5 space-y-3 border-b border-line pb-5 text-[14px]">
            <div className="flex justify-between">
              <span className="text-ink-2">Subtotal ({itemCount} item{itemCount === 1 ? "" : "s"})</span>
              <span className="font-bold">{money(subtotalCents)}</span>
            </div>
            {discountCents > 0 ? (
              <div className="flex justify-between text-moss">
                <span>Discount</span>
                <span className="font-bold">−{money(discountCents)}</span>
              </div>
            ) : null}
            <div className="flex justify-between">
              <span className="text-ink-2">Estimated tax</span>
              <span className="font-bold">{money(taxCents)}</span>
            </div>
          </div>

          <div className="border-b border-line py-5">
            <p className="eyebrow mb-3 text-ink">Shipping</p>
            <div className="space-y-2">
              {SHIPPING_RATES.map((rate) => {
                const free = rate.freeOverCents != null && subtotalCents >= rate.freeOverCents;
                const price = free || cart?.totals.discountType === "free_shipping" ? 0 : rate.priceCents;
                return (
                  <label
                    key={rate.id}
                    className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3.5 py-3 transition ${
                      shippingMethod === rate.id ? "border-ink bg-paper" : "border-line hover:border-ink/40"
                    }`}
                  >
                    <input
                      type="radio"
                      name="cart-shipping"
                      checked={shippingMethod === rate.id}
                      onChange={() => setShippingMethod(rate.id)}
                      className="h-4 w-4 accent-[#a4472a]"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block text-[13.5px] font-bold">{rate.label}</span>
                      <span className="block text-[12px] text-muted">{rate.detail}</span>
                    </span>
                    <span className="text-[13.5px] font-bold">{free ? "Free" : money(price)}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex items-end justify-between py-5">
            <span className="text-[14px] font-bold">Total</span>
            <span className="font-display text-[30px] leading-none">{money(totalCents)}</span>
          </div>

          <Link
            href="/checkout"
            className="flex h-13 w-full items-center justify-center gap-2 rounded-full bg-ink text-[14.5px] font-bold text-paper transition hover:bg-clay"
          >
            <LockIcon className="h-4 w-4" /> Checkout securely
          </Link>
          <p className="mt-3 text-center text-[12px] text-muted">
            Taxes and shipping finalised at checkout · 30-day free returns
          </p>

          <div className="mt-5 flex items-center justify-center gap-1.5">
            {["VISA", "MC", "AMEX", "PAY", "GPAY"].map((brand) => (
              <span key={brand} className="grid h-6 min-w-10 place-items-center rounded border border-line bg-paper px-1.5 text-[9.5px] font-black text-ink-2">
                {brand}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-4 rounded-[22px] border border-line bg-paper-2/60 p-5">
          <p className="text-[13px] font-bold">Applying a code at checkout?</p>
          <p className="mt-1 text-[12.5px] leading-relaxed text-ink-2">
            Discounts carry over to the checkout page automatically. You can also enter a different code there.
          </p>
        </div>
      </aside>
    </div>
  );
}
