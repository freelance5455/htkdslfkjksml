"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Variant } from "@/db/schema";
import { useCart } from "@/components/cart/CartProvider";
import { Badge, Button, Price, Spinner } from "@/components/ui";
import { CartIcon, CheckIcon, ChevronDown, HeartIcon, LeafIcon, LockIcon, PackageIcon, RefreshIcon, TruckIcon } from "@/components/icons";
import { money, pctOff } from "@/lib/format";

export type PurchaseProduct = {
  id: number;
  handle: string;
  title: string;
  vendor: string;
  description: string;
  priceCents: number;
  compareAtPriceCents: number | null;
  inventoryQty: number;
  trackInventory: boolean;
  weightGrams: number;
  sku: string;
  tags: string[];
  optionNames: string[];
  optionValues: string[][];
  images: string[];
  collectionHandle: string | null;
  collectionTitle: string | null;
};

export function ProductPurchase({
  product,
  variants,
  rating,
  reviewCount,
}: {
  product: PurchaseProduct;
  variants: Variant[];
  rating: number | null;
  reviewCount: number;
}) {
  const { addItem, pushToast } = useCart();
  const router = useRouter();
  const [selected, setSelected] = useState<Record<number, string>>({});
  const [quantity, setQuantity] = useState(1);
  const [busy, setBusy] = useState<"cart" | "buy" | null>(null);
  const [openPanel, setOpenPanel] = useState<string | null>("description");
  const [wished, setWished] = useState(false);

  const hasOptions = product.optionNames.length > 0 && variants.length > 1;

  const variant = useMemo(() => {
    if (!hasOptions) return variants[0] ?? null;
    const wanted = product.optionNames.map((_name, index) => selected[index]);
    if (wanted.some((value) => !value)) return null;
    return (
      variants.find((candidate) =>
        wanted.every((value, index) => (index === 0 ? candidate.option1 === value : candidate.option2 === value)),
      ) ?? null
    );
  }, [hasOptions, product.optionNames, selected, variants]);

  const priceCents = variant?.priceCents ?? product.priceCents;
  const compareAt = variant?.compareAtPriceCents ?? product.compareAtPriceCents;
  const off = pctOff(priceCents, compareAt);
  const stock = variant ? variant.inventoryQty : product.inventoryQty;
  const soldOut = product.trackInventory && stock <= 0;
  const lowStock = product.trackInventory && stock > 0 && stock <= 5;

  const needsSelection = hasOptions && !variant;

  const handleAdd = async (mode: "cart" | "buy") => {
    if (needsSelection || !variant) {
      pushToast({ title: "Select your options first" });
      return;
    }
    setBusy(mode);
    const ok = await addItem(variant.id, quantity, {
      title: `${product.title}${variant.title !== "Default Title" ? ` — ${variant.title}` : ""}`,
      image: variant.image ?? product.images[0] ?? null,
    });
    setBusy(null);
    if (ok && mode === "buy") router.push("/checkout");
  };

  const deliveryEstimate = (() => {
    const date = new Date();
    date.setDate(date.getDate() + 5);
    return date.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" });
  })();

  const panels = [
    {
      id: "description",
      title: "Description",
      content: (
        <div className="space-y-3">
          {product.description.split("\n").filter(Boolean).map((paragraph, index) =>
            paragraph.startsWith("•") ? (
              <p key={index} className="flex gap-2 text-[14px] leading-relaxed text-ink-2">
                <span className="text-clay">•</span>
                <span>{paragraph.replace(/^•\s*/, "")}</span>
              </p>
            ) : (
              <p key={index} className="text-[14.5px] leading-relaxed text-ink-2">
                {paragraph}
              </p>
            ),
          )}
        </div>
      ),
    },
    {
      id: "shipping",
      title: "Shipping & returns",
      content: (
        <ul className="space-y-2.5 text-[14px] text-ink-2">
          <li className="flex gap-2.5">
            <TruckIcon className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
            Standard shipping $6.95 (free over $75), dispatched within 24 hours from Portland, OR.
          </li>
          <li className="flex gap-2.5">
            <PackageIcon className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
            Express 2-day $18.95 and overnight $34.95 available at checkout.
          </li>
          <li className="flex gap-2.5">
            <RefreshIcon className="mt-0.5 h-4 w-4 shrink-0 text-clay" />
            30-day free returns with a prepaid label in every box — even on sale items.
          </li>
        </ul>
      ),
    },
    {
      id: "details",
      title: "Details & care",
      content: (
        <dl className="grid grid-cols-2 gap-x-6 gap-y-3 text-[13.5px]">
          {[
            ["Maker", product.vendor],
            ["SKU", variant?.sku || product.sku || "—"],
            ["Weight", `${(product.weightGrams / 1000).toFixed(2)} kg`],
            ["Availability", soldOut ? "Sold out" : `${stock} in stock`],
            ["Warranty", "2 years, repair or replace"],
            ["Packaging", "Plastic-free, recyclable"],
          ].map(([label, value]) => (
            <div key={label}>
              <dt className="text-[11px] font-bold uppercase tracking-[0.1em] text-muted">{label}</dt>
              <dd className="mt-0.5 text-ink-2">{value}</dd>
            </div>
          ))}
        </dl>
      ),
    },
  ];

  return (
    <div className="flex flex-col">
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-[12px] font-bold uppercase tracking-[0.1em] text-clay">{product.vendor}</span>
        {product.tags.includes("bestseller") ? <Badge tone="gold">Bestseller</Badge> : null}
        {off ? <Badge tone="sale">Save {off}%</Badge> : null}
        {product.tags.includes("refillable") ? (
          <Badge tone="moss">
            <LeafIcon className="h-3 w-3" /> Refillable
          </Badge>
        ) : null}
      </div>

      <h1 className="font-display mt-3 text-[clamp(1.9rem,3.6vw,2.7rem)] leading-[1.06]">{product.title}</h1>

      <a href="#reviews" className="mt-3 flex items-center gap-2 text-[13px] text-muted hover:text-ink">
        <span className="flex gap-0.5 text-gold">
          {[1, 2, 3, 4, 5].map((star) => (
            <svg key={star} viewBox="0 0 24 24" className="h-3.5 w-3.5" fill={(rating ?? 0) >= star - 0.35 ? "currentColor" : "none"} stroke="currentColor" strokeWidth={1.2}>
              <path d="m12 3.6 2.5 5.1 5.6.8-4 4 1 5.6-5.1-2.7-5 2.7.9-5.6-4-4 5.6-.8L12 3.6Z" strokeLinejoin="round" />
            </svg>
          ))}
        </span>
        {rating ? `${rating.toFixed(1)} · ${reviewCount} review${reviewCount === 1 ? "" : "s"}` : "No reviews yet"}
      </a>

      <div className="mt-4 flex items-end gap-3">
        <Price priceCents={priceCents} compareAtPriceCents={compareAt} showSave={false} className="font-display text-[30px] leading-none" />
        {compareAt && compareAt > priceCents ? (
          <span className="mb-1 text-[13px] font-semibold text-clay">
            was {money(compareAt)} · you save {money(compareAt - priceCents)}
          </span>
        ) : null}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 text-[13px]">
        {soldOut ? (
          <span className="flex items-center gap-1.5 font-bold text-clay">
            <span className="h-2 w-2 rounded-full bg-clay" /> Sold out
          </span>
        ) : lowStock ? (
          <span className="flex items-center gap-1.5 font-bold text-gold">
            <span className="h-2 w-2 animate-pulse rounded-full bg-gold" /> Only {stock} left
          </span>
        ) : (
          <span className="flex items-center gap-1.5 font-bold text-moss">
            <span className="h-2 w-2 rounded-full bg-moss" /> In stock · ships today
          </span>
        )}
      </div>

      {/* options */}
      {product.optionNames.map((name, index) => {
        const values = product.optionValues[index] ?? [];
        if (!values.length) return null;
        return (
          <div key={name} className="mt-7">
            <div className="flex items-baseline justify-between">
              <p className="eyebrow text-ink">{name}</p>
              {selected[index] ? <p className="text-[13px] font-bold text-clay">{selected[index]}</p> : null}
            </div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              {values.map((value) => {
                const isActive = selected[index] === value;
                const variantForValue = variants.find((candidate) =>
                  index === 0 ? candidate.option1 === value : candidate.option2 === value,
                );
                const unavailable = variantForValue != null && variantForValue.inventoryQty <= 0 && variants.length > 1;
                return (
                  <button
                    key={value}
                    type="button"
                    onClick={() => setSelected((prev) => ({ ...prev, [index]: value }))}
                    className={`relative rounded-full border px-4 py-2.5 text-[13.5px] font-semibold transition ${
                      isActive ? "border-ink bg-ink text-paper" : "border-line bg-surface hover:border-ink/60"
                    } ${unavailable ? "opacity-45" : ""}`}
                  >
                    {value}
                    {unavailable ? <span className="absolute inset-x-2 top-1/2 h-px rotate-[-14deg] bg-current" /> : null}
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}

      {/* quantity + add */}
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <div className="flex h-13 items-center justify-between rounded-full border border-line bg-surface px-2 sm:w-36">
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            className="grid h-9 w-9 place-items-center rounded-full text-[18px] font-bold transition hover:bg-paper-2"
            aria-label="Decrease quantity"
          >
            −
          </button>
          <span className="min-w-6 text-center text-[15px] font-bold">{quantity}</span>
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.min(99, value + 1))}
            className="grid h-9 w-9 place-items-center rounded-full text-[18px] font-bold transition hover:bg-paper-2"
            aria-label="Increase quantity"
          >
            +
          </button>
        </div>

        <Button
          variant={soldOut ? "light" : "primary"}
          size="lg"
          className="flex-1"
          disabled={soldOut || busy !== null}
          onClick={() => handleAdd("cart")}
        >
          {busy === "cart" ? <Spinner className="h-4 w-4" /> : <CartIcon className="h-4.5 w-4.5" />}
          {soldOut ? "Sold out" : needsSelection ? "Select options" : `Add to bag · ${money(priceCents * quantity)}`}
        </Button>

        <button
          type="button"
          onClick={() => {
            setWished((value) => !value);
            pushToast({
              title: wished ? "Removed from wishlist" : "Saved to wishlist",
              message: product.title,
              image: product.images[0] ?? null,
            });
          }}
          className={`grid h-13 w-13 shrink-0 place-items-center rounded-full border transition ${
            wished ? "border-clay bg-clay/10 text-clay" : "border-line bg-surface text-ink-2 hover:border-ink"
          }`}
          aria-label="Save to wishlist"
        >
          <HeartIcon filled={wished} className="h-5 w-5" />
        </button>
      </div>

      {!soldOut ? (
        <Button variant="accent" size="lg" className="mt-3 w-full" disabled={busy !== null} onClick={() => handleAdd("buy")}>
          {busy === "buy" ? <Spinner className="h-4 w-4" /> : <LockIcon className="h-4 w-4" />}
          Buy it now
        </Button>
      ) : (
        <div className="mt-3 rounded-2xl border border-line bg-surface p-4">
          <p className="text-[13.5px] font-bold">Back in stock soon</p>
          <p className="mt-1 text-[13px] text-ink-2">
            This colourway is being re-fired right now. Join the list and we'll email you the moment it lands.
          </p>
        </div>
      )}

      <div className="mt-5 flex items-center gap-2 rounded-2xl bg-moss/8 px-4 py-3 text-[13px] font-semibold text-moss">
        <TruckIcon className="h-4 w-4" />
        Order within 4 hrs 12 mins for delivery by {deliveryEstimate}
      </div>

      {/* accordions */}
      <div className="mt-8 divide-y divide-line border-y border-line">
        {panels.map((panel) => {
          const isOpen = openPanel === panel.id;
          return (
            <div key={panel.id}>
              <button
                type="button"
                onClick={() => setOpenPanel(isOpen ? null : panel.id)}
                className="flex w-full items-center justify-between py-4 text-left"
                aria-expanded={isOpen}
              >
                <span className="text-[14px] font-bold">{panel.title}</span>
                <ChevronDown className={`h-4 w-4 text-muted transition ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {isOpen ? <div className="animate-fade pb-5">{panel.content}</div> : null}
            </div>
          );
        })}
      </div>

      <div className="mt-6 flex items-start gap-3 rounded-2xl border border-line bg-surface p-4">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-clay/10 text-clay">
          <CheckIcon className="h-4 w-4" strokeWidth={2.4} />
        </span>
        <p className="text-[13px] leading-relaxed text-ink-2">
          <span className="font-bold text-ink">Two-year promise.</span> If it chips, cracks or stops working under normal
          use, we repair or replace it — no receipt hunting, no restocking fee.
        </p>
      </div>
    </div>
  );
}
