"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import type { CartLine, CartPayload } from "@/lib/cart";
import { money } from "@/lib/format";

type Toast = { id: number; title: string; message?: string; image?: string | null };

type CartContextValue = {
  ready: boolean;
  cart: CartPayload | null;
  lines: CartLine[];
  itemCount: number;
  subtotalCents: number;
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  refresh: () => Promise<void>;
  addItem: (variantId: number, quantity?: number, meta?: { title?: string; image?: string | null }) => Promise<boolean>;
  updateLine: (lineId: number, quantity: number) => Promise<void>;
  removeLine: (lineId: number) => Promise<void>;
  applyDiscount: (code: string) => Promise<{ ok: boolean; message: string }>;
  removeDiscount: () => Promise<void>;
  setNote: (note: string) => Promise<void>;
  toasts: Toast[];
  pushToast: (toast: Omit<Toast, "id">) => void;
};

const CartContext = createContext<CartContextValue | null>(null);

const EMPTY_CART: CartPayload = {
  lines: [],
  itemCount: 0,
  subtotalCents: 0,
  discount: null,
  note: "",
  totals: {
    subtotalCents: 0,
    discountCents: 0,
    discountCode: null,
    discountLabel: null,
    discountType: null,
    shippingCents: 0,
    shippingLabel: "Standard shipping",
    taxCents: 0,
    totalCents: 0,
  },
};

async function call<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error((data as { error?: string }).error ?? "Something went wrong");
  return data as T;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartPayload | null>(null);
  const [ready, setReady] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const refresh = useCallback(async () => {
    try {
      const data = await call<CartPayload>("/api/cart");
      setCart(data);
    } catch {
      setCart(EMPTY_CART);
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const pushToast = useCallback((toast: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((item) => item.id !== id)), 4200);
  }, []);

  const addItem = useCallback<CartContextValue["addItem"]>(
    async (variantId, quantity = 1, meta) => {
      try {
        const data = await call<CartPayload>("/api/cart", {
          method: "POST",
          body: JSON.stringify({ variantId, quantity }),
        });
        setCart(data);
        setIsOpen(true);
        pushToast({
          title: "Added to bag",
          message: meta?.title ? `${quantity} × ${meta.title}` : undefined,
          image: meta?.image,
        });
        return true;
      } catch (error) {
        pushToast({ title: "Could not add to bag", message: (error as Error).message });
        return false;
      }
    },
    [pushToast],
  );

  const updateLine = useCallback<CartContextValue["updateLine"]>(async (lineId, quantity) => {
    setCart((prev) => {
      if (!prev) return prev;
      const lines = prev.lines.map((line) => (line.id === lineId ? { ...line, quantity } : line));
      const subtotalCents = lines.reduce((sum, line) => sum + line.priceCents * line.quantity, 0);
      return {
        ...prev,
        lines,
        subtotalCents,
        itemCount: lines.reduce((sum, line) => sum + line.quantity, 0),
        totals: { ...prev.totals, subtotalCents, totalCents: subtotalCents },
      };
    });
    try {
      const data = await call<CartPayload>("/api/cart/line", {
        method: "PATCH",
        body: JSON.stringify({ lineId, quantity }),
      });
      setCart(data);
    } catch (error) {
      pushToast({ title: "Update failed", message: (error as Error).message });
      await refresh();
    }
  }, [pushToast, refresh]);

  const removeLine = useCallback<CartContextValue["removeLine"]>(async (lineId) => {
    try {
      const data = await call<CartPayload>("/api/cart/line", { method: "DELETE", body: JSON.stringify({ lineId }) });
      setCart(data);
    } catch (error) {
      pushToast({ title: "Remove failed", message: (error as Error).message });
    }
  }, [pushToast]);

  const applyDiscount = useCallback<CartContextValue["applyDiscount"]>(async (code) => {
    try {
      const data = await call<CartPayload & { message?: string }>("/api/cart/discount", {
        method: "POST",
        body: JSON.stringify({ code }),
      });
      setCart(data);
      pushToast({ title: `Discount ${code.toUpperCase()} applied`, message: data.message });
      return { ok: true, message: data.message ?? "Discount applied" };
    } catch (error) {
      const message = (error as Error).message;
      pushToast({ title: "Discount rejected", message });
      return { ok: false, message };
    }
  }, [pushToast]);

  const removeDiscount = useCallback(async () => {
    try {
      const data = await call<CartPayload>("/api/cart/discount", { method: "DELETE" });
      setCart(data);
    } catch {
      /* ignore */
    }
  }, []);

  const setNote = useCallback(async (note: string) => {
    try {
      const data = await call<CartPayload>("/api/cart/note", { method: "PATCH", body: JSON.stringify({ note }) });
      setCart(data);
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<CartContextValue>(() => {
    const active = cart ?? EMPTY_CART;
    return {
      ready,
      cart: active,
      lines: active.lines,
      itemCount: active.itemCount,
      subtotalCents: active.subtotalCents,
      isOpen,
      openCart: () => setIsOpen(true),
      closeCart: () => setIsOpen(false),
      refresh,
      addItem,
      updateLine,
      removeLine,
      applyDiscount,
      removeDiscount,
      setNote,
      toasts,
      pushToast,
    };
  }, [ready, cart, isOpen, refresh, addItem, updateLine, removeLine, applyDiscount, removeDiscount, setNote, toasts, pushToast]);

  return (
    <CartContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[90] flex flex-col items-center gap-2 px-4 sm:bottom-6 sm:items-end sm:pr-6">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className="animate-toast pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-2xl border border-line bg-surface/95 p-3 shadow-[0_18px_50px_rgba(25,21,18,0.16)] backdrop-blur"
          >
            {toast.image ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={toast.image} alt="" className="h-12 w-12 shrink-0 rounded-xl object-cover" />
            ) : (
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-moss/12 text-moss">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.8}>
                  <path d="m5 13 4.5 4.5L19 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate text-[13px] font-bold">{toast.title}</p>
              {toast.message ? <p className="truncate text-[12px] text-muted">{toast.message}</p> : null}
            </div>
          </div>
        ))}
      </div>
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("useCart must be used inside <CartProvider>");
  return context;
}

export function CartSubtotal({ className = "" }: { className?: string }) {
  const { subtotalCents } = useCart();
  return <span className={className}>{money(subtotalCents)}</span>;
}
