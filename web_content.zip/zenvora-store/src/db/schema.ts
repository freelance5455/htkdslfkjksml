import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  handle: text("handle").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  image: text("image"),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  handle: text("handle").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  vendor: text("vendor").notNull().default("Zenvora"),
  collectionId: integer("collection_id").references(() => collections.id, {
    onDelete: "set null",
  }),
  status: text("status").notNull().default("active"), // active | draft | archived
  priceCents: integer("price_cents").notNull().default(0),
  compareAtPriceCents: integer("compare_at_price_cents"),
  costCents: integer("cost_cents").notNull().default(0),
  sku: text("sku").notNull().default(""),
  inventoryQty: integer("inventory_qty").notNull().default(0),
  trackInventory: boolean("track_inventory").notNull().default(true),
  weightGrams: integer("weight_grams").notNull().default(500),
  images: jsonb("images").$type<string[]>().notNull().default([]),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  optionNames: jsonb("option_names").$type<string[]>().notNull().default([]),
  optionValues: jsonb("option_values").$type<string[][]>().notNull().default([]),
  featured: boolean("featured").notNull().default(false),
  publishedAt: timestamp("published_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const variants = pgTable(
  "variants",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    title: text("title").notNull().default("Default Title"),
    sku: text("sku").notNull().default(""),
    priceCents: integer("price_cents").notNull().default(0),
    compareAtPriceCents: integer("compare_at_price_cents"),
    inventoryQty: integer("inventory_qty").notNull().default(0),
    option1: text("option1"),
    option2: text("option2"),
    image: text("image"),
    position: integer("position").notNull().default(0),
  },
  (table) => [uniqueIndex("variants_product_idx").on(table.productId, table.position)],
);

export const carts = pgTable("carts", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  discountCode: text("discount_code"),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const cartItems = pgTable(
  "cart_items",
  {
    id: serial("id").primaryKey(),
    cartId: integer("cart_id")
      .notNull()
      .references(() => carts.id, { onDelete: "cascade" }),
    variantId: integer("variant_id")
      .notNull()
      .references(() => variants.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull().default(1),
  },
  (table) => [uniqueIndex("cart_items_unique").on(table.cartId, table.variantId)],
);

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  email: text("email").notNull(),
  firstName: text("first_name").notNull().default(""),
  lastName: text("last_name").notNull().default(""),
  address1: text("address1").notNull().default(""),
  address2: text("address2").notNull().default(""),
  city: text("city").notNull().default(""),
  province: text("province").notNull().default(""),
  zip: text("zip").notNull().default(""),
  country: text("country").notNull().default("United States"),
  phone: text("phone").notNull().default(""),
  shippingMethod: text("shipping_method").notNull().default("standard"),
  shippingCents: integer("shipping_cents").notNull().default(0),
  subtotalCents: integer("subtotal_cents").notNull().default(0),
  taxCents: integer("tax_cents").notNull().default(0),
  discountCents: integer("discount_cents").notNull().default(0),
  totalCents: integer("total_cents").notNull().default(0),
  discountCode: text("discount_code"),
  paymentBrand: text("payment_brand").notNull().default("card"),
  paymentLast4: text("payment_last4").notNull().default(""),
  paymentStatus: text("payment_status").notNull().default("paid"), // paid | pending | refunded
  fulfillmentStatus: text("fulfillment_status").notNull().default("unfulfilled"), // unfulfilled | fulfilled
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.id, { onDelete: "cascade" }),
  productId: integer("product_id"),
  variantId: integer("variant_id"),
  productHandle: text("product_handle").notNull().default(""),
  title: text("title").notNull(),
  variantTitle: text("variant_title").notNull().default(""),
  sku: text("sku").notNull().default(""),
  image: text("image"),
  priceCents: integer("price_cents").notNull().default(0),
  quantity: integer("quantity").notNull().default(1),
  totalCents: integer("total_cents").notNull().default(0),
});

export const discounts = pgTable("discounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  type: text("type").notNull().default("percentage"), // percentage | fixed_amount | free_shipping
  value: integer("value").notNull().default(0), // percent (10) or cents (1000)
  active: boolean("active").notNull().default(true),
  minSubtotalCents: integer("min_subtotal_cents").notNull().default(0),
  usageLimit: integer("usage_limit"),
  usageCount: integer("usage_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firstName: text("first_name").notNull().default(""),
  lastName: text("last_name").notNull().default(""),
  ordersCount: integer("orders_count").notNull().default(0),
  totalSpentCents: integer("total_spent_cents").notNull().default(0),
  marketingOptIn: boolean("marketing_opt_in").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id, { onDelete: "cascade" }),
  author: text("author").notNull(),
  email: text("email").notNull().default(""),
  rating: integer("rating").notNull().default(5),
  title: text("title").notNull().default(""),
  body: text("body").notNull().default(""),
  approved: boolean("approved").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default(""),
  email: text("email").notNull(),
  topic: text("topic").notNull().default("General"),
  body: text("body").notNull(),
  orderNumber: text("order_number"),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Message = typeof messages.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Variant = typeof variants.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
export type Cart = typeof carts.$inferSelect;
export type CartItem = typeof cartItems.$inferSelect;
export type Discount = typeof discounts.$inferSelect;
export type Review = typeof reviews.$inferSelect;
