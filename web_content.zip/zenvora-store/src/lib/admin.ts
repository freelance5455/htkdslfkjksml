import { cookies } from "next/headers";

export const ADMIN_COOKIE = "haven_admin";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "haven";

export async function isAdmin(): Promise<boolean> {
  const store = await cookies();
  return store.get(ADMIN_COOKIE)?.value === "granted";
}

export async function grantAdmin() {
  const store = await cookies();
  store.set(ADMIN_COOKIE, "granted", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 8,
  });
}

export async function revokeAdmin() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
}
