import { and, asc, desc, eq, gte, ilike, inArray, isNotNull, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  carts,
  collections,
  customers,
  discounts,
  orderItems,
  orders,
  products,
  reviews,
  variants,
} from "@/db/schema";
import type { Collection, Product, Variant } from "@/db/schema";
import { seedIfEmpty } from "@/lib/seed";

let seeded: Promise<void> | null = null;

/** Idempotent bootstrap: seeds the demo catalogue the first time data is read. */
export async function ensureSeeded() {
  if (!seeded) {
    seeded = seedIfEmpty()
      .then(() => undefined)
      .catch((error: unknown) => {
        seeded = null;
        console.error("[seed] failed", error);
      });
  }
  await seeded;
}

export type ProductCard = {
  id: number;
  handle: string;
  title: string;
  vendor: string;
  priceCents: number;
  compareAtPriceCents: number | null;
  image: string | null;
  images: string[];
  tags: string[];
  featured: boolean;
  inventoryQty: number;
  collectionHandle: string | null;
  collectionTitle: string | null;
  rating: number | null;
  reviewCount: number;
  publishedAt: Date;
};

function toCard(row: Record<string, unknown>): ProductCard {
  return row as unknown as ProductCard;
}

async function ratingMap(productIds: number[]): Promise<Record<number, { avg: number; count: number }>> {
  if (productIds.length === 0) return {};
  const rows = await db
    .select({
      productId: reviews.productId,
      avg: sql<number>`avg(${reviews.rating})`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(and(inArray(reviews.productId, productIds), eq(reviews.approved, true)))
    .groupBy(reviews.productId);

  const map: Record<number, { avg: number; count: number }> = {};
  for (const row of rows) {
    map[row.productId] = { avg: Number(row.avg), count: Number(row.count) };
  }
  return map;
}

export async function getCollections(): Promise<(Collection & { productCount: number })[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      collection: collections,
      productCount: sql<number>`count(${products.id})::int`,
    })
    .from(collections)
    .leftJoin(products, and(eq(products.collectionId, collections.id), eq(products.status, "active")))
    .groupBy(collections.id)
    .orderBy(asc(collections.position));

  return rows.map((row) => ({ ...row.collection, productCount: Number(row.productCount) }));
}

export async function getCollectionByHandle(handle: string) {
  await ensureSeeded();
  const [row] = await db.select().from(collections).where(eq(collections.handle, handle)).limit(1);
  return row ?? null;
}

export type ListProductFilters = {
  collectionHandle?: string;
  query?: string;
  sort?: string;
  minPrice?: number;
  maxPrice?: number;
  tags?: string[];
  vendors?: string[];
  inStockOnly?: boolean;
  featuredOnly?: boolean;
  status?: string;
  limit?: number;
  offset?: number;
};

export async function listProducts(filters: ListProductFilters = {}) {
  await ensureSeeded();
  const conditions = [];

  if (filters.status) {
    conditions.push(eq(products.status, filters.status));
  } else {
    conditions.push(eq(products.status, "active"));
  }

  if (filters.collectionHandle) {
    const collection = await getCollectionByHandle(filters.collectionHandle);
    if (!collection) return { items: [] as ProductCard[], total: 0, facets: emptyFacets };
    conditions.push(eq(products.collectionId, collection.id));
  }

  if (filters.query && filters.query.trim().length > 0) {
    const term = `%${filters.query.trim()}%`;
    conditions.push(
      or(ilike(products.title, term), ilike(products.description, term), ilike(products.vendor, term), sql`${products.tags}::text ilike ${term}`)!,
    );
  }

  if (typeof filters.minPrice === "number") conditions.push(gte(products.priceCents, filters.minPrice * 100));
  if (typeof filters.maxPrice === "number") conditions.push(lte(products.priceCents, filters.maxPrice * 100));
  if (filters.vendors?.length) conditions.push(inArray(products.vendor, filters.vendors));
  if (filters.tags?.length) {
    const pattern = `(${filters.tags.map((tag) => tag.replace(/[^\w-]/g, "")).join("|")})`;
    conditions.push(sql`${products.tags}::text ~* ${pattern}`);
  }
  if (filters.featuredOnly) conditions.push(eq(products.featured, true));
  if (filters.inStockOnly) conditions.push(gte(products.inventoryQty, 1));

  const where = conditions.length ? and(...conditions) : undefined;

  const order = (() => {
    switch (filters.sort) {
      case "price-asc":
        return asc(products.priceCents);
      case "price-desc":
        return desc(products.priceCents);
      case "newest":
        return desc(products.publishedAt);
      case "title-asc":
        return asc(products.title);
      case "best-selling":
        return desc(products.featured);
      default:
        return desc(products.featured);
    }
  })();

  const rows = await db
    .select({
      id: products.id,
      handle: products.handle,
      title: products.title,
      vendor: products.vendor,
      priceCents: products.priceCents,
      compareAtPriceCents: products.compareAtPriceCents,
      image: sql<string | null>`(select ${products.images}->>0)`,
      images: products.images,
      tags: products.tags,
      featured: products.featured,
      inventoryQty: products.inventoryQty,
      publishedAt: products.publishedAt,
      collectionHandle: collections.handle,
      collectionTitle: collections.title,
    })
    .from(products)
    .leftJoin(collections, eq(collections.id, products.collectionId))
    .where(where)
    .orderBy(order, desc(products.publishedAt), asc(products.title))
    .limit(filters.limit ?? 24)
    .offset(filters.offset ?? 0);

  const totalRows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .leftJoin(collections, eq(collections.id, products.collectionId))
    .where(where);
  const total = Number(totalRows[0]?.count ?? 0);

  const ratings = await ratingMap(rows.map((row) => row.id));
  const items = rows.map((row) =>
    toCard({
      ...row,
      images: (row.images as string[]) ?? [],
      tags: (row.tags as string[]) ?? [],
      rating: ratings[row.id] ? Number(ratings[row.id].avg.toFixed(1)) : null,
      reviewCount: ratings[row.id]?.count ?? 0,
    }),
  );

  const facets = await getFacets(filters.collectionHandle);
  return { items, total, facets };
}

const emptyFacets = {
  vendors: [] as string[],
  tags: [] as string[],
  priceRange: { min: 0, max: 0 },
};

export async function getFacets(collectionHandle?: string) {
  const conditions = [eq(products.status, "active"), isNotNull(products.collectionId)];
  if (collectionHandle) {
    const collection = await getCollectionByHandle(collectionHandle);
    if (!collection) return emptyFacets;
    conditions.push(eq(products.collectionId, collection.id));
  }
  const rows = await db
    .select({ vendor: products.vendor, tags: products.tags, priceCents: products.priceCents })
    .from(products)
    .where(and(...conditions));

  const vendors = Array.from(new Set(rows.map((row) => row.vendor).filter(Boolean))).sort();
  const tags = Array.from(new Set(rows.flatMap((row) => (row.tags as string[] | null) ?? []))).sort();
  const prices = rows.map((row) => Number(row.priceCents ?? 0));

  return {
    vendors,
    tags,
    priceRange: {
      min: prices.length ? Math.min(...prices) : 0,
      max: prices.length ? Math.max(...prices) : 0,
    },
  };
}

export type ProductDetail = Product & {
  collection: Collection | null;
  variants: Variant[];
  reviews: (typeof reviews.$inferSelect)[];
  rating: number | null;
  reviewCount: number;
};

export async function getProductByHandle(handle: string): Promise<ProductDetail | null> {
  await ensureSeeded();
  const [product] = await db.select().from(products).where(eq(products.handle, handle)).limit(1);
  if (!product) return null;
  return assembleProduct(product);
}

export async function getProductById(id: number): Promise<ProductDetail | null> {
  await ensureSeeded();
  const [product] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!product) return null;
  return assembleProduct(product);
}

async function assembleProduct(product: Product): Promise<ProductDetail> {
  const [variantRows, reviewRows, collectionRow] = await Promise.all([
    db.select().from(variants).where(eq(variants.productId, product.id)).orderBy(asc(variants.position)),
    db
      .select()
      .from(reviews)
      .where(and(eq(reviews.productId, product.id), eq(reviews.approved, true)))
      .orderBy(desc(reviews.createdAt)),
    product.collectionId
      ? db.select().from(collections).where(eq(collections.id, product.collectionId)).limit(1)
      : Promise.resolve([]),
  ]);

  const count = reviewRows.length;
  const avg = count ? reviewRows.reduce((sum, review) => sum + review.rating, 0) / count : null;

  return {
    ...product,
    collection: collectionRow[0] ?? null,
    variants: variantRows,
    reviews: reviewRows,
    rating: avg ? Number(avg.toFixed(1)) : null,
    reviewCount: count,
  };
}

export async function getRelatedProducts(product: Product, limit = 4) {
  const rows = await db
    .select({
      id: products.id,
      handle: products.handle,
      title: products.title,
      vendor: products.vendor,
      priceCents: products.priceCents,
      compareAtPriceCents: products.compareAtPriceCents,
      image: sql<string | null>`(select ${products.images}->>0)`,
      images: products.images,
      tags: products.tags,
      featured: products.featured,
      inventoryQty: products.inventoryQty,
      publishedAt: products.publishedAt,
      collectionHandle: collections.handle,
      collectionTitle: collections.title,
    })
    .from(products)
    .leftJoin(collections, eq(collections.id, products.collectionId))
    .where(
      and(
        eq(products.status, "active"),
        sql`${products.id} <> ${product.id}`,
        or(eq(products.collectionId, product.collectionId ?? -1), eq(products.vendor, product.vendor)),
      ),
    )
    .orderBy(desc(products.featured), desc(products.publishedAt))
    .limit(limit);

  const ratings = await ratingMap(rows.map((row) => row.id));
  return rows.map((row) =>
    toCard({
      ...row,
      images: (row.images as string[]) ?? [],
      tags: (row.tags as string[]) ?? [],
      rating: ratings[row.id] ? Number(ratings[row.id].avg.toFixed(1)) : null,
      reviewCount: ratings[row.id]?.count ?? 0,
    }),
  );
}

export async function getBestSellers(limit = 4) {
  await ensureSeeded();
  const rows = await db
    .select({
      productId: orderItems.productId,
      qty: sql<number>`sum(${orderItems.quantity})::int`,
    })
    .from(orderItems)
    .where(isNotNull(orderItems.productId))
    .groupBy(orderItems.productId)
    .orderBy(desc(sql`sum(${orderItems.quantity})`))
    .limit(limit);

  const ids = rows.map((row) => row.productId).filter((id): id is number => id != null);
  if (ids.length === 0) {
    const featured = await listProducts({ featuredOnly: true, limit });
    return featured.items;
  }

  const productRows = await db
    .select({
      id: products.id,
      handle: products.handle,
      title: products.title,
      vendor: products.vendor,
      priceCents: products.priceCents,
      compareAtPriceCents: products.compareAtPriceCents,
      image: sql<string | null>`(select ${products.images}->>0)`,
      images: products.images,
      tags: products.tags,
      featured: products.featured,
      inventoryQty: products.inventoryQty,
      publishedAt: products.publishedAt,
      collectionHandle: collections.handle,
      collectionTitle: collections.title,
    })
    .from(products)
    .leftJoin(collections, eq(collections.id, products.collectionId))
    .where(and(inArray(products.id, ids), eq(products.status, "active")));

  const ratings = await ratingMap(productRows.map((row) => row.id));
  const ordered = ids
    .map((id) => productRows.find((row) => row.id === id))
    .filter((row): row is (typeof productRows)[number] => Boolean(row));

  return ordered.map((row) =>
    toCard({
      ...row,
      images: (row.images as string[]) ?? [],
      tags: (row.tags as string[]) ?? [],
      rating: ratings[row.id] ? Number(ratings[row.id].avg.toFixed(1)) : null,
      reviewCount: ratings[row.id]?.count ?? 0,
    }),
  );
}

export async function findDiscountByCode(code: string) {
  await ensureSeeded();
  const [row] = await db
    .select()
    .from(discounts)
    .where(and(eq(discounts.code, code.trim().toUpperCase()), eq(discounts.active, true)))
    .limit(1);
  return row ?? null;
}

export async function getVariantById(variantId: number) {
  const [row] = await db
    .select({
      variant: variants,
      product: products,
    })
    .from(variants)
    .innerJoin(products, eq(products.id, variants.productId))
    .where(eq(variants.id, variantId))
    .limit(1);
  return row ?? null;
}

export type AdminStats = {
  revenueCents: number;
  orderCount: number;
  customerCount: number;
  productCount: number;
  draftCount: number;
  lowStockCount: number;
  conversionRate: number;
  averageOrderCents: number;
  unitsSold: number;
  salesByDay: { date: string; totalCents: number; orders: number }[];
  paymentBreakdown: { status: string; count: number }[];
  fulfillmentBreakdown: { status: string; count: number }[];
  topProducts: { title: string; qty: number; revenueCents: number; handle: string }[];
  openCarts: number;
};

export async function getAdminStats(): Promise<AdminStats> {
  await ensureSeeded();
  const [totals] = await db
    .select({
      revenue: sql<number>`coalesce(sum(${orders.totalCents}),0)::int`,
      count: sql<number>`count(*)::int`,
      avg: sql<number>`coalesce(avg(${orders.totalCents}),0)::int`,
    })
    .from(orders);

  const [customerRow] = await db.select({ count: sql<number>`count(*)::int` }).from(customers);
  const [productRow] = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  const [draftRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .where(sql`${products.status} <> 'active'`);
  const [lowStockRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(products)
    .where(lte(products.inventoryQty, 5));
  const [cartRow] = await db.select({ count: sql<number>`count(*)::int` }).from(carts);
  const [unitsRow] = await db
    .select({ qty: sql<number>`coalesce(sum(${orderItems.quantity}),0)::int` })
    .from(orderItems);

  const salesByDayRows = await db
    .select({
      date: sql<string>`to_char(${orders.createdAt}, 'YYYY-MM-DD')`,
      totalCents: sql<number>`sum(${orders.totalCents})::int`,
      orders: sql<number>`count(*)::int`,
    })
    .from(orders)
    .groupBy(sql`to_char(${orders.createdAt}, 'YYYY-MM-DD')`)
    .orderBy(sql`to_char(${orders.createdAt}, 'YYYY-MM-DD')`)
    .limit(14);

  const paymentRows = await db
    .select({ status: orders.paymentStatus, count: sql<number>`count(*)::int` })
    .from(orders)
    .groupBy(orders.paymentStatus);

  const fulfillmentRows = await db
    .select({ status: orders.fulfillmentStatus, count: sql<number>`count(*)::int` })
    .from(orders)
    .groupBy(orders.fulfillmentStatus);

  const topRows = await db
    .select({
      title: orderItems.title,
      handle: orderItems.productHandle,
      qty: sql<number>`sum(${orderItems.quantity})::int`,
      revenueCents: sql<number>`sum(${orderItems.totalCents})::int`,
    })
    .from(orderItems)
    .groupBy(orderItems.title, orderItems.productHandle)
    .orderBy(desc(sql`sum(${orderItems.quantity})`))
    .limit(5);

  const sessions = Math.max(Number(cartRow?.count ?? 0), Number(totals?.count ?? 0));

  return {
    revenueCents: Number(totals?.revenue ?? 0),
    orderCount: Number(totals?.count ?? 0),
    customerCount: Number(customerRow?.count ?? 0),
    productCount: Number(productRow?.count ?? 0),
    draftCount: Number(draftRow?.count ?? 0),
    lowStockCount: Number(lowStockRow?.count ?? 0),
    conversionRate: sessions ? Number(((Number(totals?.count ?? 0) / sessions) * 100).toFixed(1)) : 0,
    averageOrderCents: Number(totals?.avg ?? 0),
    unitsSold: Number(unitsRow?.qty ?? 0),
    salesByDay: salesByDayRows.map((row) => ({
      date: row.date,
      totalCents: Number(row.totalCents),
      orders: Number(row.orders),
    })),
    paymentBreakdown: paymentRows.map((row) => ({ status: row.status ?? "unknown", count: Number(row.count) })),
    fulfillmentBreakdown: fulfillmentRows.map((row) => ({
      status: row.status ?? "unknown",
      count: Number(row.count),
    })),
    topProducts: topRows.map((row) => ({
      title: row.title,
      handle: row.handle,
      qty: Number(row.qty),
      revenueCents: Number(row.revenueCents),
    })),
    openCarts: Number(cartRow?.count ?? 0),
  };
}

export async function searchSuggestions(query: string, limit = 6) {
  await ensureSeeded();
  const term = `%${query.trim()}%`;
  const rows = await db
    .select({
      handle: products.handle,
      title: products.title,
      priceCents: products.priceCents,
      image: sql<string | null>`(select ${products.images}->>0)`,
    })
    .from(products)
    .where(and(eq(products.status, "active"), or(ilike(products.title, term), ilike(products.vendor, term), sql`${products.tags}::text ilike ${term}`)!))
    .orderBy(desc(products.featured))
    .limit(limit);
  return rows;
}
