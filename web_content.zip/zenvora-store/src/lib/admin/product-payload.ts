import { slugify } from "@/lib/format";

export type VariantInput = {
  title: string;
  sku?: string;
  priceCents: number;
  compareAtPriceCents?: number | null;
  inventoryQty: number;
  option1?: string | null;
  option2?: string | null;
  image?: string | null;
};

export type ProductInput = {
  title: string;
  handle?: string;
  description?: string;
  vendor?: string;
  collectionId?: number | null;
  status?: string;
  priceCents: number;
  compareAtPriceCents?: number | null;
  costCents?: number;
  sku?: string;
  inventoryQty?: number;
  trackInventory?: boolean;
  weightGrams?: number;
  images?: string[];
  tags?: string[];
  optionNames?: string[];
  optionValues?: string[][];
  featured?: boolean;
  variants?: VariantInput[];
};

export function normaliseProduct(input: ProductInput) {
  const images = (input.images ?? []).map((image) => image.trim()).filter(Boolean);
  const tags = (input.tags ?? []).map((tag) => tag.trim().toLowerCase()).filter(Boolean);
  const optionNames = (input.optionNames ?? []).map((name) => name.trim()).filter(Boolean);
  const optionValues = (input.optionValues ?? []).map((values) => values.map((value) => value.trim()).filter(Boolean));
  const inventoryTotal =
    input.variants && input.variants.length
      ? input.variants.reduce((sum, variant) => sum + Number(variant.inventoryQty ?? 0), 0)
      : Number(input.inventoryQty ?? 0);

  return {
    title: input.title.trim(),
    handle: slugify(input.handle || input.title),
    description: input.description ?? "",
    vendor: (input.vendor ?? "Zenvora").trim() || "Zenvora",
    collectionId: input.collectionId ?? null,
    status: input.status ?? "active",
    priceCents: Math.max(0, Math.round(Number(input.priceCents) || 0)),
    compareAtPriceCents:
      input.compareAtPriceCents && Number(input.compareAtPriceCents) > 0 ? Math.round(Number(input.compareAtPriceCents)) : null,
    costCents: Math.max(0, Math.round(Number(input.costCents ?? 0) || 0)),
    sku: (input.sku ?? "").trim(),
    inventoryQty: inventoryTotal,
    trackInventory: input.trackInventory ?? true,
    weightGrams: Math.max(0, Math.round(Number(input.weightGrams ?? 500) || 0)),
    images,
    tags,
    optionNames,
    optionValues,
    featured: Boolean(input.featured),
    updatedAt: new Date(),
  };
}
