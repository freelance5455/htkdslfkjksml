import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  cartItems,
  carts,
  collections,
  customers,
  discounts,
  orderItems,
  orders,
  products,
  reviews,
  variants,
} from "@/db/schema";

const img = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=900&h=900&fit=crop`;

const wide = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=1400&h=900&fit=crop`;

/** Tiny deterministic PRNG so demo data is stable between reseeds. */
function makeRandom(seed: number) {
  let state = seed;
  return () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
}

type SeedProduct = {
  handle: string;
  title: string;
  vendor: string;
  collection: string;
  description: string;
  price: number;
  compareAt?: number;
  cost: number;
  images: string[];
  tags: string[];
  weight: number;
  featured?: boolean;
  status?: string;
  options?: { name: string; values: string[] }[];
  stock?: number[];
};

const COLLECTIONS = [
  {
    handle: "home-living",
    title: "Home & Living",
    description:
      "Slow-made ceramics, candles and textiles for rooms that feel lived in. Every piece is fired, poured or woven by small studios we visit in person.",
    image: wide(5570222),
    position: 1,
  },
  {
    handle: "audio-tech",
    title: "Audio & Tech",
    description:
      "Considered electronics that disappear into your day — tuned drivers, recycled aluminium, and cases designed to be repaired, not replaced.",
    image: wide(4533076),
    position: 2,
  },
  {
    handle: "beauty-wellness",
    title: "Beauty & Wellness",
    description:
      "Clean, clinically-tested formulas in refillable glass. Free from parabens, sulfates and anything we would not use ourselves.",
    image: wide(4841273),
    position: 3,
  },
  {
    handle: "carry-accessories",
    title: "Bags & Carry",
    description:
      "Full-grain leather, solid hardware and lifetime stitching. Goods that pick up a patina instead of falling apart.",
    image: wide(28755965),
    position: 4,
  },
];

const SEED_PRODUCTS: SeedProduct[] = [
  {
    handle: "kiln-ceramic-vase",
    title: "Kiln Ceramic Vase",
    vendor: "Zenvora",
    collection: "home-living",
    description:
      "Hand-thrown in our Porto studio from local red clay, then finished with a matte reactive glaze so no two vases read the same. Weighted base, food-safe interior, sized for a single branch or a full bouquet.\n\n• Stoneware, matte reactive glaze\n• Watertight interior seal\n• Dishwasher safe (hand wash recommended)\n• Made in Portugal",
    price: 6800,
    cost: 2400,
    images: [img(29904622), img(15028227), img(39199677)],
    tags: ["ceramics", "handmade", "bestseller"],
    weight: 1400,
    featured: true,
    options: [
      { name: "Finish", values: ["Sand", "Charcoal"] },
      { name: "Size", values: ['9"', '12"'] },
    ],
    stock: [14, 9, 6, 0],
  },
  {
    handle: "striped-stoneware-mug-set",
    title: "Striped Stoneware Mug — Set of 2",
    vendor: "Zenvora",
    collection: "home-living",
    description:
      "A 12 oz mug with a comfortable thumb rest and a hand-painted stripe that wraps the full body. Sold as a pair because one is never enough.\n\n• 12 oz / 350 ml\n• Hand-painted underglaze\n• Microwave + dishwasher safe",
    price: 3400,
    compareAt: 4400,
    cost: 1200,
    images: [img(34299319), img(34299343)],
    tags: ["ceramics", "kitchen", "sale"],
    weight: 900,
    options: [{ name: "Colourway", values: ["Oat / Clay", "Sage / Cream"] }],
    stock: [32, 18],
  },
  {
    handle: "ember-soy-candle",
    title: "Ember Soy Candle",
    vendor: "Northlight",
    collection: "home-living",
    description:
      "Poured into a reusable amber glass tumbler with a crackling wooden wick. 60+ hours of burn time and a scent throw that fills a room without shouting.\n\n• 9 oz coconut-soy wax\n• FSC-certified wooden wick\n• Phthalate-free fragrance\n• Vessel refills available",
    price: 2800,
    cost: 900,
    images: [img(18748134), img(17307177)],
    tags: ["candles", "gift", "bestseller"],
    weight: 450,
    featured: true,
    options: [{ name: "Scent", values: ["Cedar & Fig", "Amber Smoke", "Wild Lavender"] }],
    stock: [40, 26, 4],
  },
  {
    handle: "heritage-ceramic-pitcher",
    title: "Heritage Ceramic Pitcher",
    vendor: "Zenvora",
    collection: "home-living",
    description:
      "An heirloom-shaped pitcher with a drip-free spout, thrown in porcelain and finished in a soft chalk glaze. 1.2 litre capacity for water, juice or a very large latte.",
    price: 7600,
    cost: 2800,
    images: [img(39199677), img(29904622)],
    tags: ["ceramics", "kitchen"],
    weight: 1100,
    options: [],
    stock: [11],
  },
  {
    handle: "dried-botanicals-bundle",
    title: "Dried Botanicals Bundle",
    vendor: "Field & Stem",
    collection: "home-living",
    description:
      "Air-dried, never bleached. Each bundle is assembled by hand from seasonal stems — citrus, grasses and seed heads that hold their shape for years.",
    price: 4200,
    cost: 1500,
    images: [img(17307177), img(9839457)],
    tags: ["decor", "gift"],
    weight: 300,
    options: [],
    stock: [22],
  },
  {
    handle: "orchard-linen-table-runner",
    title: "Orchard Linen Table Runner",
    vendor: "Field & Stem",
    collection: "home-living",
    description:
      "Stonewashed European flax, hemmed on all four sides. Gets softer with every wash and drapes without fuss.",
    price: 5400,
    cost: 1900,
    images: [img(9839457), img(7434244)],
    tags: ["textiles", "kitchen"],
    weight: 500,
    options: [{ name: "Size", values: ['54"', '90"'] }],
    stock: [16, 7],
  },
  {
    handle: "studio-stationery-set",
    title: "Studio Stationery Set",
    vendor: "Margin Goods",
    collection: "home-living",
    description:
      "Everything for a tidy desk: 3 gel pens, a linen-bound notebook, washi roll, brass clips and a set of printable-look stickers. Recycled papers throughout.",
    price: 3800,
    compareAt: 4600,
    cost: 1300,
    images: [img(7434244)],
    tags: ["desk", "gift", "sale"],
    weight: 600,
    options: [],
    stock: [28],
  },
  {
    handle: "aurora-wireless-headphones",
    title: "Aurora Wireless Headphones",
    vendor: "Sonora",
    collection: "audio-tech",
    description:
      "Adaptive noise cancellation, 40 mm beryllium-coated drivers and a 60-hour battery. Memory-foam cups wrapped in protein leather, folding flat into a recycled felt case.\n\n• Hybrid ANC with transparency mode\n• 60 h playback / 5 min = 6 h quick charge\n• Multipoint Bluetooth 5.4, LDAC + AAC\n• USB-C and 3.5 mm wired listening",
    price: 24900,
    compareAt: 29900,
    cost: 11800,
    images: [img(3394650), img(3394653), img(3394648)],
    tags: ["audio", "bestseller", "sale"],
    weight: 700,
    featured: true,
    options: [{ name: "Colour", values: ["Ivory", "Onyx"] }],
    stock: [19, 12],
  },
  {
    handle: "halo-studio-headphones",
    title: "Halo Studio Headphones",
    vendor: "Sonora",
    collection: "audio-tech",
    description:
      "Closed-back reference cans tuned flat for mixing. Replaceable pads, detachable cable, and a headband that survives a decade of sessions.",
    price: 17900,
    cost: 7600,
    images: [img(9058878), img(9058883)],
    tags: ["audio", "studio"],
    weight: 650,
    options: [{ name: "Colour", values: ["Bone", "Graphite"] }],
    stock: [9, 3],
  },
  {
    handle: "pebble-portable-speaker",
    title: "Pebble Portable Speaker",
    vendor: "Sonora",
    collection: "audio-tech",
    description:
      "Pocket-sized, IP67 waterproof and loud enough for a kitchen. 18-hour battery, aluminium shell, and a lanyard loop cast into the body.",
    price: 11900,
    cost: 4900,
    images: [img(33298190), img(3394648)],
    tags: ["audio", "travel", "bestseller"],
    weight: 520,
    featured: true,
    options: [],
    stock: [24],
  },
  {
    handle: "everyday-tech-kit",
    title: "Everyday Tech Kit",
    vendor: "Margin Goods",
    collection: "audio-tech",
    description:
      "A roll-up organiser for the cables you actually carry: 3-in-1 braided cable, 45 W GaN charger, lens cloth, card slot and a magnetic pouch.",
    price: 8900,
    cost: 3400,
    images: [img(7989742), img(4533076)],
    tags: ["travel", "desk", "gift"],
    weight: 400,
    options: [],
    stock: [17],
  },
  {
    handle: "analog-listening-bundle",
    title: "Analog Listening Bundle",
    vendor: "Sonora",
    collection: "audio-tech",
    description:
      "For record nights: a pair of retro-styled on-ears, a cork slipmat, an anti-static brush and two archival print sleeves.",
    price: 14800,
    cost: 6100,
    images: [img(18224279), img(9058883)],
    tags: ["audio", "gift"],
    weight: 1200,
    options: [],
    stock: [8],
  },
  {
    handle: "workspace-desk-mat",
    title: "Workspace Desk Mat",
    vendor: "Margin Goods",
    collection: "audio-tech",
    description:
      "Vegetable-tanned leather over a wool-felt backing, 90 × 40 cm. Rolls up for travel and develops a proper patina within a month.",
    price: 5800,
    cost: 2100,
    images: [img(4533076), img(39774571)],
    tags: ["desk", "leather"],
    weight: 900,
    options: [],
    stock: [13],
  },
  {
    handle: "ritual-haircare-duo",
    title: "Ritual Shampoo + Conditioner Duo",
    vendor: "Aster Lab",
    collection: "beauty-wellness",
    description:
      "Sulfate-free, colour-safe and weighted for fine to medium hair. Panthenol and rice protein do the work; the scent is a soft green tea with a hint of cedar.\n\n• 2 × 300 ml recyclable aluminium bottles\n• pH balanced 5.5\n• Vegan, cruelty-free, silicone-free",
    price: 4600,
    cost: 1600,
    images: [img(33525723), img(5912001)],
    tags: ["haircare", "bestseller", "refillable"],
    weight: 750,
    featured: true,
    options: [{ name: "Type", values: ["Fine Hair", "Curly Hair"] }],
    stock: [30, 21],
  },
  {
    handle: "glacier-facial-serum",
    title: "Glacier Facial Serum",
    vendor: "Aster Lab",
    collection: "beauty-wellness",
    description:
      "10% niacinamide, 2% alpha arbutin and a cold-pressed glacier water base. Clinically shown to improve tone in 4 weeks on 92% of testers.\n\n• Amber glass dropper, refillable\n• Fragrance-free, non-comedogenic\n• Dermatologist tested",
    price: 7200,
    compareAt: 8800,
    cost: 2400,
    images: [img(36238538), img(5912001), img(4841273)],
    tags: ["skincare", "sale", "bestseller"],
    weight: 300,
    featured: true,
    options: [{ name: "Size", values: ["30 ml", "50 ml"] }],
    stock: [44, 26],
  },
  {
    handle: "stillwater-skincare-set",
    title: "Stillwater Skincare Set",
    vendor: "Aster Lab",
    collection: "beauty-wellness",
    description:
      "The full four-step routine in a linen zip case: gel cleanser, hydrating toner, glacier serum and a barrier cream. Save 18% versus buying separately.",
    price: 12800,
    compareAt: 15600,
    cost: 4700,
    images: [img(4841273), img(36238538)],
    tags: ["skincare", "gift", "sale"],
    weight: 1500,
    options: [],
    stock: [12],
  },
  {
    handle: "gold-leaf-night-cream",
    title: "Gold Leaf Night Cream",
    vendor: "Aster Lab",
    collection: "beauty-wellness",
    description:
      "A rich but fast-absorbing overnight cream with bakuchiol, squalane and 24k gold flecks suspended in a whipped shea base.",
    price: 6400,
    cost: 2200,
    images: [img(19117855), img(33525723)],
    tags: ["skincare", "luxury"],
    weight: 400,
    options: [],
    stock: [19],
  },
  {
    handle: "daily-greens-gummies",
    title: "Daily Greens Gummies",
    vendor: "Vitalis",
    collection: "beauty-wellness",
    description:
      "Pectin-based (no gelatin), 12 greens and 8 vitamins in a blackcurrant gummy. Two a day, no aftertaste, no fridge required.",
    price: 3200,
    cost: 1100,
    images: [img(14027296), img(13779106)],
    tags: ["wellness", "bestseller"],
    weight: 250,
    options: [{ name: "Supply", values: ["30 days", "60 days"] }],
    stock: [52, 33],
  },
  {
    handle: "balance-multivitamin",
    title: "Balance Multivitamin",
    vendor: "Vitalis",
    collection: "beauty-wellness",
    description:
      "A once-daily multivitamin in an amber apothecary bottle. Third-party tested, 23 micronutrients, zero fillers you cannot pronounce.",
    price: 2900,
    cost: 950,
    images: [img(13779106), img(13779102)],
    tags: ["wellness"],
    weight: 200,
    options: [],
    stock: [2],
  },
  {
    handle: "solstice-leather-tote",
    title: "Solstice Leather Tote",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "Cut from a single hide of full-grain Italian leather, saddle-stitched and unlined so it softens to your shape. Fits a 16\" laptop, a gym kit and a week of groceries.\n\n• 2.2 mm full-grain leather\n• Solid brass hardware, hand-burnished edges\n• Interior zip pocket + key clip\n• Lifetime stitching guarantee",
    price: 28500,
    compareAt: 34000,
    cost: 11200,
    images: [img(34976481), img(19869756), img(3808249)],
    tags: ["leather", "bags", "bestseller", "sale"],
    weight: 1600,
    featured: true,
    options: [{ name: "Colour", values: ["Cognac", "Noir", "Cherry"] }],
    stock: [11, 8, 0],
  },
  {
    handle: "meridian-automatic-watch",
    title: "Meridian Automatic Watch",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "A 38 mm automatic with a sapphire crystal, 41-hour power reserve and a quick-release strap you can swap without tools. Assembled in Neuchâtel.",
    price: 42000,
    cost: 18500,
    images: [img(6157408), img(6157411), img(28977357)],
    tags: ["watches", "leather", "luxury"],
    weight: 350,
    featured: true,
    options: [{ name: "Strap", values: ["Tan Leather", "Steel Bracelet"] }],
    stock: [7, 4],
  },
  {
    handle: "voyager-chronograph",
    title: "Voyager Chronograph",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "Three-register chronograph in brushed steel with a travel roll and an extra NATO strap. 100 m water resistance, luminous indices.",
    price: 56000,
    cost: 24000,
    images: [img(30077330), img(28977357)],
    tags: ["watches", "luxury", "gift"],
    weight: 500,
    options: [],
    stock: [3],
  },
  {
    handle: "everyday-leather-kit",
    title: "Everyday Leather Kit",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "Card sleeve, key fob and cord taco in matching vegetable-tanned leather. Monogramming available at checkout notes.",
    price: 9800,
    cost: 3600,
    images: [img(4452374), img(6157408)],
    tags: ["leather", "gift", "eds"],
    weight: 300,
    options: [],
    stock: [21],
  },
  {
    handle: "city-crossbody",
    title: "City Crossbody",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "A structured half-moon crossbody with an adjustable webbing strap and a magnetic closure that opens one-handed.",
    price: 14500,
    compareAt: 17500,
    cost: 5400,
    images: [img(3808249), img(34976481)],
    tags: ["bags", "sale"],
    weight: 700,
    options: [{ name: "Colour", values: ["Blush", "Black"] }],
    stock: [15, 10],
  },
  {
    handle: "court-leather-sneaker",
    title: "Court Leather Sneaker",
    vendor: "Atlas Leather Co.",
    collection: "carry-accessories",
    description:
      "A low-profile court shoe on a vulcanised cup sole, resoleable at any cobbler. Unlined leather upper, cork-footbed insole.",
    price: 16800,
    cost: 6800,
    images: [img(27127413), img(19869756)],
    tags: ["footwear", "leather", "bestseller"],
    weight: 1200,
    options: [{ name: "Size", values: ["US 7", "US 8", "US 9", "US 10", "US 11"] }],
    stock: [6, 9, 12, 5, 2],
  },
];

const REVIEW_POOL = [
  { author: "Marisol D.", rating: 5, title: "Exactly as described", body: "Arrived in three days, packaging was plastic-free and the quality is well above what I paid. Already ordered a second one as a gift." },
  { author: "Theo R.", rating: 4, title: "Great, with one note", body: "Really happy with this. Took off a star only because I wish it came in one more colourway. Build quality is excellent." },
  { author: "Priya N.", rating: 5, title: "Replaced three cheaper versions", body: "I've bought the budget version of this twice and it never lasted. This one feels like it will outlive me." },
  { author: "Jordan K.", rating: 5, title: "Gift-approved", body: "Bought for my sister, she texted me a photo the same evening. Shipping was fast and the note card was a nice touch." },
  { author: "Lena W.", rating: 4, title: "Solid everyday pick", body: "Uses it daily. Nothing dramatic to report, which is the highest compliment I can give a product like this." },
  { author: "Amara O.", rating: 5, title: "The details are the point", body: "Stitching, weight, the way the packaging opens — someone clearly thought about all of it. Customer support replied in under an hour too." },
  { author: "Ben H.", rating: 3, title: "Good but sizing runs small", body: "Quality is there. I'd recommend going one size up from your usual, which support confirmed is a known thing." },
  { author: "Sofia M.", rating: 5, title: "Second order from Zenvora", body: "Consistent every time. The loyalty discount landed automatically at checkout which I appreciated." },
];

const CUSTOMER_POOL = [
  { first: "Marisol", last: "Delgado", email: "marisol@example.com", city: "Austin", province: "TX" },
  { first: "Theo", last: "Rasmussen", email: "theo.r@example.com", city: "Portland", province: "OR" },
  { first: "Priya", last: "Nair", email: "priya.n@example.com", city: "Seattle", province: "WA" },
  { first: "Jordan", last: "Kessler", email: "jordan.k@example.com", city: "Brooklyn", province: "NY" },
  { first: "Lena", last: "Whitfield", email: "lena.w@example.com", city: "Denver", province: "CO" },
  { first: "Amara", last: "Okonkwo", email: "amara.o@example.com", city: "Chicago", province: "IL" },
  { first: "Ben", last: "Hartley", email: "ben.h@example.com", city: "Nashville", province: "TN" },
  { first: "Sofia", last: "Moreau", email: "sofia.m@example.com", city: "San Diego", province: "CA" },
];

const STREETS = ["118 Alder St", "42 Rowan Ave", "900 Cypress Blvd", "7 Juniper Lane", "233 Mercer St", "51 Foxglove Rd"];

const DEMO_DISCOUNTS = [
  { code: "WELCOME10", type: "percentage", value: 10, minSubtotalCents: 0, usageLimit: null },
  { code: "SPRING25", type: "percentage", value: 25, minSubtotalCents: 15000, usageLimit: 200 },
  { code: "SAVE20", type: "fixed_amount", value: 2000, minSubtotalCents: 10000, usageLimit: 100 },
  { code: "FREESHIP", type: "free_shipping", value: 0, minSubtotalCents: 4000, usageLimit: null },
];

export async function seedIfEmpty() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  if (Number(count) > 0) return false;
  await seedAll();
  return true;
}

export async function reseedAll() {
  await db.delete(cartItems);
  await db.delete(carts);
  await db.delete(orderItems);
  await db.delete(orders);
  await db.delete(reviews);
  await db.delete(variants);
  await db.delete(products);
  await db.delete(customers);
  await db.delete(discounts);
  await db.delete(collections);
  await seedAll();
  return true;
}

async function seedAll() {
  const rand = makeRandom(20260214);
  const collectionByHandle = new Map<string, number>();

  for (const collection of COLLECTIONS) {
    const [row] = await db.insert(collections).values(collection).returning({ id: collections.id });
    collectionByHandle.set(collection.handle, row.id);
  }

  for (const [index, seed] of SEED_PRODUCTS.entries()) {
    const collectionId = collectionByHandle.get(seed.collection) ?? null;
    const optionNames = (seed.options ?? []).map((option) => option.name);
    const optionValues = (seed.options ?? []).map((option) => option.values);

    const combos: string[][] = optionNames.length
      ? optionValues.reduce<string[][]>((acc, values) => acc.flatMap((prev) => values.map((value) => [...prev, value])), [[]])
      : [[]];

    const stockPlan = seed.stock ?? combos.map(() => 12);
    const totalStock = stockPlan.reduce((sum, value) => sum + value, 0);

    const [product] = await db
      .insert(products)
      .values({
        handle: seed.handle,
        title: seed.title,
        description: seed.description,
        vendor: seed.vendor,
        collectionId,
        status: seed.status ?? "active",
        priceCents: seed.price,
        compareAtPriceCents: seed.compareAt ?? null,
        costCents: seed.cost,
        sku: `${seed.handle.slice(0, 3).toUpperCase()}-${1000 + index}`,
        inventoryQty: totalStock,
        weightGrams: seed.weight,
        images: seed.images,
        tags: seed.tags,
        optionNames,
        optionValues,
        featured: Boolean(seed.featured),
        publishedAt: new Date(Date.now() - (SEED_PRODUCTS.length - index) * 86400000 * 3),
      })
      .returning({ id: products.id });

    const variantRows = combos.map((combo, position) => {
      const title = combo.length ? combo.join(" / ") : "Default Title";
      return {
        productId: product.id,
        title,
        sku: `${seed.handle.slice(0, 3).toUpperCase()}-${1000 + index}-${position + 1}`,
        priceCents: seed.price,
        compareAtPriceCents: seed.compareAt ?? null,
        inventoryQty: stockPlan[position] ?? 10,
        option1: combo[0] ?? null,
        option2: combo[1] ?? null,
        image: seed.images[position % seed.images.length] ?? null,
        position: position + 1,
      };
    });

    await db.insert(variants).values(variantRows);

    const reviewCount = 2 + (index % 5);
    const reviewRows = Array.from({ length: reviewCount }).map((_, reviewIndex) => {
      const pool = REVIEW_POOL[(index + reviewIndex) % REVIEW_POOL.length];
      return {
        productId: product.id,
        author: pool.author,
        email: `${pool.author.split(" ")[0].toLowerCase()}@example.com`,
        rating: pool.rating,
        title: pool.title,
        body: pool.body,
        approved: true,
        createdAt: new Date(Date.now() - (reviewIndex + 1) * 86400000 * (2 + (index % 6))),
      };
    });
    await db.insert(reviews).values(reviewRows);
  }

  for (const discount of DEMO_DISCOUNTS) {
    await db.insert(discounts).values({ ...discount, active: true, usageCount: 0 });
  }

  // ---- Customers ----
  const customerIds = new Map<string, number>();
  for (const person of CUSTOMER_POOL) {
    const [row] = await db
      .insert(customers)
      .values({
        email: person.email,
        firstName: person.first,
        lastName: person.last,
        marketingOptIn: rand() > 0.4,
        createdAt: new Date(Date.now() - Math.floor(rand() * 120) * 86400000),
      })
      .returning({ id: customers.id, email: customers.email });
    customerIds.set(row.email, row.id);
  }

  // ---- Orders ----
  const allProducts = await db.select().from(products);
  const allVariants = await db.select().from(variants);
  let orderNumber = 1042;

  for (let dayOffset = 20; dayOffset >= 0; dayOffset--) {
    const ordersToday = dayOffset % 3 === 0 ? 2 : 1;
    for (let n = 0; n < ordersToday; n++) {
      const person = CUSTOMER_POOL[Math.floor(rand() * CUSTOMER_POOL.length)];
      const product = allProducts[Math.floor(rand() * allProducts.length)];
      const productVariants = allVariants.filter((variant) => variant.productId === product.id);
      const lineCount = 1 + Math.floor(rand() * 2);
      const lines = Array.from({ length: lineCount }).map(() => {
        const variant = productVariants[Math.floor(rand() * productVariants.length)] ?? allVariants[0];
        const quantity = 1 + Math.floor(rand() * 2);
        const lineProduct = allProducts.find((candidate) => candidate.id === variant.productId)!;
        return { variant, quantity, product: lineProduct };
      });

      const subtotalCents = lines.reduce((sum, line) => sum + line.variant.priceCents * line.quantity, 0);
      const shippingMethod = rand() > 0.7 ? "express" : "standard";
      const shippingCents = shippingMethod === "express" ? 1895 : subtotalCents >= 7500 ? 0 : 695;
      const discountApplied = rand() > 0.75;
      const discountCents = discountApplied ? Math.round(subtotalCents * 0.1) : 0;
      const taxCents = Math.round((subtotalCents - discountCents) * 0.0825);
      const totalCents = subtotalCents - discountCents + shippingCents + taxCents;

      const created = new Date(Date.now() - dayOffset * 86400000 - Math.floor(rand() * 8) * 3600000);

      const [order] = await db
        .insert(orders)
        .values({
          orderNumber: `#${orderNumber}`,
          email: person.email,
          firstName: person.first,
          lastName: person.last,
          address1: STREETS[Math.floor(rand() * STREETS.length)],
          city: person.city,
          province: person.province,
          zip: `${10000 + Math.floor(rand() * 89999)}`,
          country: "United States",
          phone: `(555) 0${10 + Math.floor(rand() * 89)} ${1000 + Math.floor(rand() * 8999)}`,
          shippingMethod,
          shippingCents,
          subtotalCents,
          taxCents,
          discountCents,
          totalCents,
          discountCode: discountApplied ? "WELCOME10" : null,
          paymentBrand: rand() > 0.5 ? "visa" : "mastercard",
          paymentLast4: `${4000 + Math.floor(rand() * 999)}`.slice(0, 4),
          paymentStatus: rand() > 0.92 ? "pending" : "paid",
          fulfillmentStatus: dayOffset > 6 ? "fulfilled" : rand() > 0.5 ? "fulfilled" : "unfulfilled",
          createdAt: created,
        })
        .returning({ id: orders.id });

      await db.insert(orderItems).values(
        lines.map((line) => ({
          orderId: order.id,
          productId: line.product.id,
          variantId: line.variant.id,
          productHandle: line.product.handle,
          title: line.product.title,
          variantTitle: line.variant.title,
          sku: line.variant.sku,
          image: line.product.images[0] ?? null,
          priceCents: line.variant.priceCents,
          quantity: line.quantity,
          totalCents: line.variant.priceCents * line.quantity,
        })),
      );

      await db
        .update(customers)
        .set({
          ordersCount: sql`${customers.ordersCount} + 1`,
          totalSpentCents: sql`${customers.totalSpentCents} + ${totalCents}`,
        })
        .where(eqEmail(person.email));

      orderNumber += 1 + Math.floor(rand() * 2);
    }
  }

  // A couple of abandoned carts for the admin dashboard.
  for (let i = 0; i < 3; i++) {
    const [cart] = await db
      .insert(carts)
      .values({ token: `seed-cart-${i}`, createdAt: new Date(Date.now() - i * 86400000) })
      .returning({ id: carts.id });
    const variant = allVariants[i % allVariants.length];
    await db.insert(cartItems).values({ cartId: cart.id, variantId: variant.id, quantity: 1 + i });
  }
}

function eqEmail(email: string) {
  return sql`${customers.email} = ${email}`;
}
