import { cookies } from "next/headers";
import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, carts, products, variants } from "@/db/schema";
import { computeTotals } from "@/lib/format";
import { findDiscountByCode } from "@/lib/catalog";

export const CART_COOKIE = "haven_cart";

export async function readCartToken(): Promise<string | null> {
  const store = await cookies();
  return store.get(CART_COOKIE)?.value ?? null;
}

export async function createCartToken(): Promise<string> {
  const token = randomUUID();
  const store = await cookies();
  store.set(CART_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
  return token;
}

export async function setCartToken(token: string) {
  const store = await cookies();
  store.set(CART_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function clearCartCookie() {
  const store = await cookies();
  store.delete(CART_COOKIE);
}

/** Ensures a cart row exists for the current visitor and returns it. */
export async function ensureCart(): Promise<{ id: number; token: string; discountCode: string | null; note: string }> {
  const token = (await readCartToken()) ?? (await createCartToken());
  const [existing] = await db.select().from(carts).where(eq(carts.token, token)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(carts).values({ token }).returning();
  return created;
}

export type CartLine = {
  id: number;
  variantId: number;
  quantity: number;
  title: string;
  variantTitle: string;
  handle: string;
  sku: string;
  image: string | null;
  priceCents: number;
  compareAtPriceCents: number | null;
  inventoryQty: number;
  trackInventory: boolean;
  vendor: string;
  productId: number;
};

export type CartPayload = {
  lines: CartLine[];
  itemCount: number;
  subtotalCents: number;
  totals: ReturnType<typeof computeTotals>;
  discount: { code: string; type: string; value: number; minSubtotalCents: number } | null;
  note: string;
};

export async function loadCart(cartId: number): Promise<CartPayload> {
  const rows = await db
    .select({
      id: cartItems.id,
      variantId: cartItems.variantId,
      quantity: cartItems.quantity,
      title: products.title,
      handle: products.handle,
      vendor: products.vendor,
      trackInventory: products.trackInventory,
      productId: products.id,
      variantTitle: variants.title,
      sku: variants.sku,
      image: variants.image,
      priceCents: variants.priceCents,
      compareAtPriceCents: variants.compareAtPriceCents,
      inventoryQty: variants.inventoryQty,
    })
    .from(cartItems)
    .innerJoin(variants, eq(variants.id, cartItems.variantId))
    .innerJoin(products, eq(products.id, variants.productId))
    .where(eq(cartItems.cartId, cartId))
    .orderBy(cartItems.id);

  const lines: CartLine[] = rows.map((row) => ({
    ...row,
    image: row.image ?? null,
  }));

  const subtotalCents = lines.reduce((sum, line) => sum + line.priceCents * line.quantity, 0);
  const itemCount = lines.reduce((sum, line) => sum + line.quantity, 0);

  const [cart] = await db.select().from(carts).where(eq(carts.id, cartId)).limit(1);
  const discount = cart?.discountCode ? await findDiscountByCode(cart.discountCode) : null;

  const totals = computeTotals({
    subtotalCents,
    shippingMethod: "standard",
    discount,
  });

  return {
    lines,
    itemCount,
    subtotalCents,
    totals,
    discount: discount
      ? {
          code: discount.code,
          type: discount.type,
          value: discount.value,
          minSubtotalCents: discount.minSubtotalCents,
        }
      : null,
    note: cart?.note ?? "",
  };
}

export async function emptyCart(cartId: number) {
  await db.delete(cartItems).where(eq(cartItems.cartId, cartId));
  await db.update(carts).set({ discountCode: null, note: "", updatedAt: new Date() }).where(eq(carts.id, cartId));
}
