export const CURRENCY = "USD";

export function money(cents: number, opts: { sign?: boolean } = {}): string {
  const value = (cents ?? 0) / 100;
  const formatted = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: CURRENCY,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(value));
  if (value < 0) return `-${formatted}`;
  return opts.sign ? `+${formatted}` : formatted;
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 70);
}

export function formatDate(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

export function formatDateTime(value: Date | string | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function initials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export function pctOff(priceCents: number, compareAtCents: number | null | undefined): number | null {
  if (!compareAtCents || compareAtCents <= priceCents) return null;
  return Math.round(((compareAtCents - priceCents) / compareAtCents) * 100);
}

export const SHIPPING_RATES = [
  {
    id: "standard",
    label: "Standard shipping",
    detail: "4–7 business days",
    priceCents: 695,
    freeOverCents: 7500,
  },
  {
    id: "express",
    label: "Express shipping",
    detail: "2 business days",
    priceCents: 1895,
    freeOverCents: null,
  },
  {
    id: "overnight",
    label: "Overnight",
    detail: "Next business day",
    priceCents: 3495,
    freeOverCents: null,
  },
] as const;

export type ShippingRate = (typeof SHIPPING_RATES)[number];

export function getShippingRate(id: string): ShippingRate {
  return SHIPPING_RATES.find((rate) => rate.id === id) ?? SHIPPING_RATES[0];
}

export const TAX_RATE = 0.0825;

export type DiscountSummary = {
  code: string | null;
  type: "percentage" | "fixed_amount" | "free_shipping" | null;
  label: string | null;
  amountCents: number;
};

export function computeTotals(input: {
  subtotalCents: number;
  shippingMethod: string;
  discount?: { code: string; type: string; value: number; minSubtotalCents: number } | null;
}) {
  const { subtotalCents, shippingMethod } = input;
  const discount = input.discount ?? null;
  const qualifies =
    discount != null && subtotalCents >= (discount.minSubtotalCents ?? 0) && subtotalCents > 0;

  let discountCents = 0;
  let discountLabel: string | null = null;
  let discountType: DiscountSummary["type"] = null;

  if (qualifies && discount) {
    if (discount.type === "percentage") {
      discountCents = Math.round((subtotalCents * discount.value) / 100);
      discountLabel = `${discount.value}% off`;
      discountType = "percentage";
    } else if (discount.type === "fixed_amount") {
      discountCents = Math.min(discount.value, subtotalCents);
      discountLabel = `${money(discount.value)} off`;
      discountType = "fixed_amount";
    } else if (discount.type === "free_shipping") {
      discountType = "free_shipping";
      discountLabel = "Free shipping";
    }
  }

  const rate = getShippingRate(shippingMethod);
  let shippingCents = subtotalCents === 0 ? 0 : rate.priceCents;
  if (rate.freeOverCents != null && subtotalCents >= rate.freeOverCents) shippingCents = 0;
  if (discountType === "free_shipping") shippingCents = 0;

  const taxable = Math.max(subtotalCents - discountCents, 0);
  const taxCents = Math.round(taxable * TAX_RATE);
  const totalCents = taxable + shippingCents + taxCents;

  return {
    subtotalCents,
    discountCents,
    discountCode: discountType ? discount?.code ?? null : null,
    discountLabel,
    discountType,
    shippingCents,
    shippingLabel: rate.label,
    taxCents,
    totalCents,
  };
}

export type Totals = ReturnType<typeof computeTotals>;
