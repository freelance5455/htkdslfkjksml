import type { CapacitorConfig } from "@capacitor/cli";

// Set CAPACITOR_SERVER_URL to the deployed HTTPS Zenvora store URL before
// syncing/building the Android app. Example: https://your-store.example
const storeUrl = process.env.CAPACITOR_SERVER_URL?.trim();
const storeHostname = storeUrl ? new URL(storeUrl).hostname : undefined;

const config: CapacitorConfig = {
  appId: "com.zenvora.store",
  appName: "Zenvora",
  webDir: "www",
  ...(storeUrl
    ? {
        server: {
          url: storeUrl,
          cleartext: false,
          allowNavigation: storeHostname ? [storeHostname] : [],
        },
      }
    : {}),
  android: {
    allowMixedContent: false,
  },
};

export default config;
