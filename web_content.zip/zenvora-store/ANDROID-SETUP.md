# Zenvora Android app setup

This ZIP contains the Zenvora Next.js store and a Capacitor Android wrapper configuration. It is source code, not a ready-made APK.

## Important: the store needs a server

The project uses Next.js server pages/API routes and PostgreSQL (`DATABASE_URL`). It cannot run as a complete offline/static APK. Deploy the Next.js project to a host that supports Next.js server routes and configure a PostgreSQL database on that host. Keep database credentials on the server; never put them in the Android app.

## Build the Android wrapper

1. Deploy the store and confirm its HTTPS URL works in Chrome.
2. Configure `DATABASE_URL` in the hosting provider and apply the project's database schema/migrations as required.
3. In the project folder, set `CAPACITOR_SERVER_URL` to the deployed store URL. Example:

   ```bash
   export CAPACITOR_SERVER_URL=https://your-real-store-domain.com
   ```

   On Windows PowerShell:

   ```powershell
   $env:CAPACITOR_SERVER_URL="https://your-real-store-domain.com"
   ```

4. Install dependencies and create/sync the Android project:

   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

5. In Android Studio, use **Build > Generate Signed Bundle / APK > APK** to create a signed APK.

## App identity

- App name: Zenvora
- Android application ID: `com.zenvora.store`

## Before launching the store

Review and replace all sample products, images, reviews, maker/story text, contact details, shipping/return terms, prices, and payment claims with your real business information. The included content is demo/template content and must not be presented as verified Zenvora policies or real customer reviews.
