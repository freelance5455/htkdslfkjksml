NOVA CALCULADORA — pacote web para app

Conteúdo:
- index.html: a calculadora preta e laranja
- manifest.webmanifest: configurações para instalação como aplicação web (PWA)

Para instalar como PWA, publique esta pasta num alojamento HTTPS e abra o endereço no Chrome Android; depois use o menu ⋮ > Adicionar ao ecrã inicial/Instalar app.

Este pacote ainda não é um APK Android. Para gerar um APK, é necessário empacotar o site com uma ferramenta Android/WebView depois de o publicar num endereço HTTPS.
