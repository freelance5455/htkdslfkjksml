"use strict";

/* ==================================================
MUEEN | ATTENDANCE
================================================== */

/* ==================================================
STORAGE KEYS
================================================== */

const SUBJECTS_KEY = "mueen_subjects";
const CLASSES_KEY = "mueen_classes";
const ATTENDANCE_KEY = "mueen_attendance_records";
const WEEKS_KEY = "mueen_school_weeks";

/* ==================================================
ELEMENTS
================================================== */

const attendanceDate =
document.getElementById("attendanceDate");

const attendanceDay =
document.getElementById("attendanceDay");

const subjectSelect =
document.getElementById("subjectSelect");

const classSelect =
document.getElementById("classSelect");

const selectedClassCode =
document.getElementById("selectedClassCode");

const attendanceStudentsCard =
document.getElementById("attendanceStudentsCard");

const attendanceClassTitle =
document.getElementById("attendanceClassTitle");

const attendanceTotal =
document.getElementById("attendanceTotal");

const attendanceStudentList =
document.getElementById("attendanceStudentList");

const attendanceEmptyClass =
document.getElementById("attendanceEmptyClass");

const presentAllButton =
document.getElementById("presentAllButton");

const saveAttendanceButton =
document.getElementById("saveAttendanceButton");

const livePresentCount =
document.getElementById("livePresentCount");

const liveAbsentCount =
document.getElementById("liveAbsentCount");

const liveTotalCount =
document.getElementById("liveTotalCount");

const absenceRecords =
document.getElementById("absenceRecords");

const absenceEmpty =
document.getElementById("absenceEmpty");

const absenceSubjectFilter =
document.getElementById("absenceSubjectFilter");

const subjectManagement =
document.getElementById("subjectManagement");

const subjectModal =
document.getElementById("subjectModal");

const subjectModalTitle =
document.getElementById("subjectModalTitle");

const subjectNameInput =
document.getElementById("subjectNameInput");

const saveSubjectButton =
document.getElementById("saveSubjectButton");

const weekModal =
document.getElementById("weekModal");

const weekModalTitle =
document.getElementById("weekModalTitle");

const weekNameInput =
document.getElementById("weekNameInput");

const weekStartInput =
document.getElementById("weekStartInput");

const weekEndInput =
document.getElementById("weekEndInput");

const weeksList =
document.getElementById("weeksList");

const weeksEmpty =
document.getElementById("weeksEmpty");

const weekDetails =
document.getElementById("weekDetails");

const weekRecords =
document.getElementById("weekRecords");

const selectedWeekLabel =
document.getElementById("selectedWeekLabel");

const selectedWeekDates =
document.getElementById("selectedWeekDates");

const deleteAttendanceDataTopButton =
document.getElementById("deleteAttendanceDataTopButton");

/* ==================================================
STATE
================================================== */

let currentStatuses = {};
let editingSubjectId = null;
let editingWeekId = null;
let selectedWeekId = null;

/* ==================================================
STORAGE HELPERS
================================================== */

function readStorage(key, fallback) {

    try {

        const value =
            localStorage.getItem(key);

        if (!value) {
            return fallback;
        }

        const parsed =
            JSON.parse(value);

        return parsed ?? fallback;

    } catch (error) {

        console.error(
            "Storage read error:",
            key,
            error
        );

        return fallback;
    }
}

function writeStorage(key, value) {

    localStorage.setItem(
        key,
        JSON.stringify(value)
    );
}

/* ==================================================
DATE HELPERS
================================================== */

function getLocalDateString(date = new Date()) {

    const year =
        date.getFullYear();

    const month =
        String(date.getMonth() + 1)
            .padStart(2, "0");

    const day =
        String(date.getDate())
            .padStart(2, "0");

    return `${year}-${month}-${day}`;
}

function parseLocalDate(value) {

    if (!value) return null;

    const parts =
        value.split("-");

    if (parts.length !== 3) {
        return null;
    }

    return new Date(
        Number(parts[0]),
        Number(parts[1]) - 1,
        Number(parts[2])
    );
}

function formatDateArabic(value) {

    const date =
        parseLocalDate(value);

    if (!date) return "—";

    return date.toLocaleDateString(
        "ar-EG",
        {
            day: "numeric",
            month: "long",
            year: "numeric"
        }
    );
}

function getDayName(value) {

    const date =
        parseLocalDate(value);

    if (!date) return "—";

    return date.toLocaleDateString(
        "ar-EG",
        {
            weekday: "long"
        }
    );
}

function formatDateRange(start, end) {

    return `من ${formatDateArabic(start)} إلى ${formatDateArabic(end)}`;
}

/* ==================================================
WEEK DATE HELPERS
================================================== */

function addDaysToDateString(dateString, days) {

    const date =
        parseLocalDate(dateString);

    if (!date) return "";

    date.setDate(
        date.getDate() + days
    );

    return getLocalDateString(date);
}

function getNextThursday(startDateString) {

    const date =
        parseLocalDate(startDateString);

    if (!date) return "";

    /*
       الأحد = 0
       الإثنين = 1
       الثلاثاء = 2
       الأربعاء = 3
       الخميس = 4
    */

    const day =
        date.getDay();

    let daysUntilThursday =
        4 - day;

    if (daysUntilThursday < 0) {
        daysUntilThursday += 7;
    }

    date.setDate(
        date.getDate() +
        daysUntilThursday
    );

    return getLocalDateString(date);
}

/*
   يحول رقم الأسبوع إلى اسم عربي.
*/

function getArabicWeekName(number) {

    const names = {

        1: "الأسبوع الأول",
        2: "الأسبوع الثاني",
        3: "الأسبوع الثالث",
        4: "الأسبوع الرابع",
        5: "الأسبوع الخامس",
        6: "الأسبوع السادس",
        7: "الأسبوع السابع",
        8: "الأسبوع الثامن",
        9: "الأسبوع التاسع",
        10: "الأسبوع العاشر",
        11: "الأسبوع الحادي عشر",
        12: "الأسبوع الثاني عشر",
        13: "الأسبوع الثالث عشر",
        14: "الأسبوع الرابع عشر",
        15: "الأسبوع الخامس عشر",
        16: "الأسبوع السادس عشر",
        17: "الأسبوع السابع عشر",
        18: "الأسبوع الثامن عشر",
        19: "الأسبوع التاسع عشر",
        20: "الأسبوع العشرون"

    };

    return names[number] ||
        `الأسبوع ${number}`;
}

/* ==================================================
WEEK HELPERS
================================================== */

function getWeeks() {

    const weeks =
        readStorage(
            WEEKS_KEY,
            []
        );

    return Array.isArray(weeks)
        ? weeks
        : [];
}

function saveWeeks(weeks) {

    writeStorage(
        WEEKS_KEY,
        weeks
    );
}

function getWeekForDate(dateString) {

    const weeks =
        getWeeks();

    return weeks.find(
        function(week) {

            return (
                dateString >= week.start &&
                dateString <= week.end
            );

        }
    ) || null;
}

function getDefaultWeekDates() {

    const today =
        new Date();

    const day =
        today.getDay();

    const sunday =
        new Date(today);

    sunday.setDate(
        today.getDate() - day
    );

    const thursday =
        new Date(sunday);

    thursday.setDate(
        sunday.getDate() + 4
    );

    return {

        start:
            getLocalDateString(sunday),

        end:
            getLocalDateString(thursday)

    };
}

function getNextWeekNumber() {

    const weeks =
        getWeeks();

    if (!weeks.length) {
        return 1;
    }

    return (
        Math.max(
            ...weeks.map(
                week =>
                    Number(
                        week.number
                    ) || 0
            )
        ) + 1
    );
}

/* ==================================================
AUTOMATIC WEEK CREATION
================================================== */

/*
   هذه هي الإضافة الأساسية.

   لا تنشئ أسبوعًا إلا إذا كان تاريخ الحضور
   بعد نهاية آخر أسبوع موجود.

   إذا كان لدينا:

   الأسبوع الأول:
   6/9 → 10/9

   وسجلنا حضورًا يوم:
   13/9

   ينشئ تلقائيًا:

   الأسبوع الثاني:
   11/9 → 17/9

   ثم يتم ربط سجل 13/9 بالأسبوع الثاني.

   وإذا كان التاريخ بعيدًا، مثل 27/9،
   سيتم إنشاء الأسابيع المتتالية اللازمة.
*/

function ensureWeeksUntilDate(dateString) {

    if (!dateString) {
        return null;
    }

    let weeks =
        getWeeks();

    /*
       عند أول حفظ حضور/غياب، ينشأ الأسبوع الأول تلقائيًا.
       لا يحتاج المستخدم إلى إنشاء الأسابيع يدويًا.
    */

    if (!weeks.length) {
        const dates = getDefaultWeekDates();
        const firstWeek = {
            id: Date.now().toString() + "_1",
            number: 1,
            name: getArabicWeekName(1),
            start: dates.start,
            end: dates.end,
            createdAt: new Date().toISOString(),
            automatic: true
        };

        weeks.push(firstWeek);
        saveWeeks(weeks);
        return firstWeek;
    }

    /*
       ترتيب نسخة من الأسابيع حسب النهاية.
    */

    weeks.sort(
        function(a, b) {

            return a.end.localeCompare(
                b.end
            );

        }
    );

    let lastWeek =
        weeks[weeks.length - 1];

    /*
       إذا كان التاريخ داخل أسبوع موجود،
       نعيد ذلك الأسبوع مباشرة.
    */

    const existing =
        weeks.find(
            function(week) {

                return (
                    dateString >= week.start &&
                    dateString <= week.end
                );

            }
        );

    if (existing) {
        return existing;
    }

    /*
       إذا كان التاريخ قبل آخر أسبوع
       فلا ننشئ شيئًا.
    */

    if (dateString <= lastWeek.end) {

        return getWeekForDate(
            dateString
        );
    }

    /*
       التاريخ بعد نهاية آخر أسبوع.

       نبدأ من اليوم التالي لنهاية آخر أسبوع.
    */

    while (
        dateString >
        lastWeek.end
    ) {

        const nextStart =
            addDaysToDateString(
                lastWeek.end,
                1
            );

        const nextEnd =
            getNextThursday(
                nextStart
            );

        const nextNumber =
            getNextWeekNumber();

        const newWeek = {

            id:
                Date.now().toString() +
                "_" +
                nextNumber,

            number:
                nextNumber,

            name:
                getArabicWeekName(
                    nextNumber
                ),

            start:
                nextStart,

            end:
                nextEnd,

            createdAt:
                new Date().toISOString(),

            automatic:
                true

        };

        weeks.push(
            newWeek
        );

        lastWeek =
            newWeek;
    }

    saveWeeks(
        weeks
    );

    /*
       بعد إنشاء الأسابيع،
       نبحث عن الأسبوع الذي يحتوي تاريخ الحضور.
    */

    return getWeekForDate(
        dateString
    );
}

/* ==================================================
SUBJECTS
================================================== */

function getSubjects() {

    const subjects =
        readStorage(
            SUBJECTS_KEY,
            []
        );

    return Array.isArray(subjects)
        ? subjects
        : [];
}

function saveSubjects(subjects) {

    writeStorage(
        SUBJECTS_KEY,
        subjects
    );
}

function renderSubjects() {

    const subjects =
        getSubjects();

    subjectSelect.innerHTML = `
        <option value="">
            اختر المادة
        </option>
    `;

    absenceSubjectFilter.innerHTML = `
        <option value="">
            جميع المواد
        </option>
    `;

    subjects.forEach(
        function(subject) {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                subject.id;

            option.textContent =
                subject.name;

            subjectSelect.appendChild(
                option
            );

            const filterOption =
                option.cloneNode(true);

            absenceSubjectFilter.appendChild(
                filterOption
            );

        }
    );

    renderSubjectManagement();
}

function renderSubjectManagement() {

    const subjects =
        getSubjects();

    subjectManagement.innerHTML =
        "";

    subjects.forEach(
        function(subject) {

            const chip =
                document.createElement(
                    "div"
                );

            chip.className =
                "subject-chip";

            chip.innerHTML = `
                <span>
                    ${escapeHTML(subject.name)}
                </span>

                <button
                    type="button"
                    data-edit-subject="${escapeHTML(subject.id)}">
                    ✎
                </button>

                <button
                    type="button"
                    data-delete-subject="${escapeHTML(subject.id)}">
                    ×
                </button>
            `;

            subjectManagement.appendChild(
                chip
            );

        }
    );
}

function openSubjectModal(id = null) {

    editingSubjectId =
        id;

    if (id) {

        const subject =
            getSubjects().find(
                item =>
                    String(item.id) ===
                    String(id)
            );

        if (!subject) return;

        subjectModalTitle.textContent =
            "تعديل المادة";

        subjectNameInput.value =
            subject.name;

    } else {

        subjectModalTitle.textContent =
            "إضافة مادة";

        subjectNameInput.value =
            "";

    }

    subjectModal.hidden =
        false;

    setTimeout(
        function() {

            subjectNameInput.focus();

        },
        50
    );
}

function closeSubjectModal() {

    subjectModal.hidden =
        true;

    editingSubjectId =
        null;

    subjectNameInput.value =
        "";
}

function saveSubject() {

    const name =
        subjectNameInput.value.trim();

    if (!name) {

        alert(
            "يرجى كتابة اسم المادة."
        );

        return;
    }

    const subjects =
        getSubjects();

    const duplicate =
        subjects.some(
            function(subject) {

                return (
                    subject.name.trim() ===
                    name &&
                    String(subject.id) !==
                    String(editingSubjectId)
                );

            }
        );

    if (duplicate) {

        alert(
            "هذه المادة موجودة بالفعل."
        );

        return;
    }

    if (editingSubjectId) {

        const index =
            subjects.findIndex(
                item =>
                    String(item.id) ===
                    String(editingSubjectId)
            );

        if (index !== -1) {

            subjects[index].name =
                name;
        }

    } else {

        subjects.push({

            id:
                Date.now().toString(),

            name:
                name,

            createdAt:
                new Date().toISOString()

        });

    }

    saveSubjects(
        subjects
    );

    renderSubjects();

    closeSubjectModal();
}

function deleteSubject(id) {

    const subjects =
        getSubjects();

    const subject =
        subjects.find(
            item =>
                String(item.id) ===
                String(id)
        );

    if (!subject) return;

    const confirmed =
        confirm(
            `هل تريد حذف مادة "${subject.name}"؟`
        );

    if (!confirmed) return;

    saveSubjects(
        subjects.filter(
            item =>
                String(item.id) !==
                String(id)
        )
    );

    renderSubjects();
}

/* ==================================================
CLASSES
================================================== */

function getClasses() {

    const classes =
        readStorage(
            CLASSES_KEY,
            []
        );

    return Array.isArray(classes)
        ? classes
        : [];
}

function getStudentList(classData) {

    if (
        classData &&
        Array.isArray(
            classData.students
        )
    ) {

        return classData.students;
    }

    return [];
}

function getClassDisplay(classData) {

    if (!classData) return "—";

    if (classData.code) {

        return classData.code;
    }

    const gradeNumber =
        getGradeNumber(
            classData.grade
        );

    if (
        gradeNumber &&
        classData.section
    ) {

        return `${gradeNumber}/${classData.section}`;
    }

    return (
        classData.grade ||
        "صف"
    );
}

function getGradeNumber(grade) {

    const map = {

        "الصف الأول الابتدائي": "1",
        "الصف الثاني الابتدائي": "2",
        "الصف الثالث الابتدائي": "3",
        "الصف الرابع الابتدائي": "4",
        "الصف الخامس الابتدائي": "5",
        "الصف السادس الابتدائي": "6",

        "الصف الأول الإعدادي": "1",
        "الصف الثاني الإعدادي": "2",
        "الصف الثالث الإعدادي": "3",

        "الصف الأول الثانوي": "1",
        "الصف الثاني الثانوي": "2",
        "الصف الثالث الثانوي": "3"

    };

    return map[grade] || "";
}

function renderClasses() {

    const classes =
        getClasses();

    classSelect.innerHTML = `
        <option value="">
            اختر الصف
        </option>
    `;

    classes.forEach(
        function(classData) {

            const option =
                document.createElement(
                    "option"
                );

            option.value =
                classData.id;

            option.textContent =
                getClassDisplay(
                    classData
                );

            classSelect.appendChild(
                option
            );

        }
    );
}

function getSelectedClass() {

    const id =
        classSelect.value;

    if (!id) return null;

    return getClasses().find(
        classData =>
            String(classData.id) ===
            String(id)
    ) || null;
}

/* ==================================================
STUDENTS
================================================== */

function prepareStatuses(classData) {

    const students =
        getStudentList(
            classData
        );

    currentStatuses =
        {};

    students.forEach(
        function(student) {

            currentStatuses[
                String(student.id)
            ] =
                "present";

        }
    );
}

function renderStudents() {

    const classData =
        getSelectedClass();

    if (!classData) {

        attendanceStudentsCard.hidden =
            true;

        selectedClassCode.textContent =
            "";

        return;
    }

    const students =
        getStudentList(
            classData
        );

    attendanceStudentsCard.hidden =
        false;

    attendanceClassTitle.textContent =
        `${getClassDisplay(classData)} — ${classData.grade || ""}`;

    attendanceTotal.textContent =
        students.length;

    selectedClassCode.textContent =
        `الفصل ${getClassDisplay(classData)}`;

    attendanceStudentList.innerHTML =
        "";

    attendanceEmptyClass.hidden =
        students.length !== 0;

    presentAllButton.hidden =
        students.length === 0;

    saveAttendanceButton.hidden =
        students.length === 0;

    if (students.length === 0) {

        updateLiveSummary();

        return;
    }

    students.forEach(
        function(student, index) {

            const id =
                String(student.id);

            if (!currentStatuses[id]) {

                currentStatuses[id] =
                    "present";
            }

            const row =
                document.createElement(
                    "div"
                );

            row.className =
                "student-row";

            const name =
                student.name ||
                student.studentName ||
                "طالب";

            row.innerHTML = `

                <div class="student-name-area">

                    <span class="student-number">
                        ${index + 1}
                    </span>

                    <span class="student-name">
                        ${escapeHTML(name)}
                    </span>

                </div>

                <button
                    type="button"
                    class="status-button ${currentStatuses[id]}"
                    data-student-id="${escapeHTML(id)}">

                    ${currentStatuses[id] === "present"
                        ? "حاضر"
                        : "غائب"}

                </button>

            `;

            attendanceStudentList.appendChild(
                row
            );

        }
    );

    updateLiveSummary();
}

/* ==================================================
STATUS
================================================== */

function toggleStudentStatus(id) {

    const key =
        String(id);

    currentStatuses[key] =
        currentStatuses[key] ===
            "absent"
            ? "present"
            : "absent";

    const button =
        attendanceStudentList.querySelector(
            `[data-student-id="${CSS.escape(key)}"]`
        );

    if (button) {

        const status =
            currentStatuses[key];

        button.className =
            `status-button ${status}`;

        button.textContent =
            status === "present"
                ? "حاضر"
                : "غائب";
    }

    updateLiveSummary();
}

function setEveryonePresent() {

    Object.keys(
        currentStatuses
    ).forEach(
        function(id) {

            currentStatuses[id] =
                "present";

        }
    );

    renderStudents();
}

function updateLiveSummary() {

    const values =
        Object.values(
            currentStatuses
        );

    const total =
        values.length;

    const absent =
        values.filter(
            value =>
                value === "absent"
        ).length;

    const present =
        total - absent;

    livePresentCount.textContent =
        present;

    liveAbsentCount.textContent =
        absent;

    liveTotalCount.textContent =
        total;
}

/* ==================================================
ATTENDANCE RECORDS
================================================== */

function getAttendanceRecords() {

    const records =
        readStorage(
            ATTENDANCE_KEY,
            []
        );

    return Array.isArray(records)
        ? records
        : [];
}

function saveAttendanceRecord() {

    const classData =
        getSelectedClass();

    const subjectId =
        subjectSelect.value;

    const date =
        attendanceDate.value;

    if (!date) {

        alert(
            "يرجى اختيار التاريخ."
        );

        return;
    }

    if (!subjectId) {

        alert(
            "يرجى اختيار المادة."
        );

        return;
    }

    if (!classData) {

        alert(
            "يرجى اختيار الصف."
        );

        return;
    }

    const students =
        getStudentList(
            classData
        );

    if (students.length === 0) {

        alert(
            "لا يمكن حفظ الحضور لأن الصف لا يحتوي على طلاب."
        );

        return;
    }

    const subject =
        getSubjects().find(
            item =>
                String(item.id) ===
                String(subjectId)
        );

    if (!subject) {

        alert(
            "المادة غير موجودة."
        );

        return;
    }

    /*
       ============================================
       التعديل الأساسي:
       إنشاء الأسابيع تلقائيًا عند الحاجة.
       ============================================
    */

    const week =
        ensureWeeksUntilDate(
            date
        );

    const statuses =
        {
            ...currentStatuses
        };

    const absentStudents =
        students.filter(
            student =>
                statuses[
                    String(student.id)
                ] === "absent"
        );

    const presentCount =
        students.length -
        absentStudents.length;

    const records =
        getAttendanceRecords();

    /*
       المفتاح المنطقي للسجل:

       التاريخ
       +
       المادة
       +
       الصف

       لذلك لا يمكن لنفس الصف والمادة
       والتاريخ إنشاء سجلين.
    */

    const existingIndex =
        records.findIndex(
            record =>

                record.date === date &&

                String(record.subjectId) ===
                String(subjectId) &&

                String(record.classId) ===
                String(classData.id)
        );

    const record = {

        id:
            existingIndex !== -1
                ? records[existingIndex].id
                : Date.now().toString(),

        date:
            date,

        dayName:
            getDayName(date),

        subjectId:
            subjectId,

        subjectName:
            subject.name,

        classId:
            classData.id,

        classCode:
            getClassDisplay(
                classData
            ),

        className:
            classData.grade || "",

        total:
            students.length,

        presentCount:
            presentCount,

        absentCount:
            absentStudents.length,

        absentStudents:
            absentStudents.map(
                student => ({

                    id:
                        student.id,

                    name:
                        student.name ||
                        student.studentName ||
                        "طالب"

                })
            ),

        /*
           إذا تم إنشاء أسبوع تلقائي،
           سيتم حفظ رقمه هنا.
        */

        weekId:
            week
                ? week.id
                : null,

        savedAt:
            new Date().toISOString()

    };

    if (existingIndex !== -1) {

        records[existingIndex] =
            record;

    } else {

        records.push(
            record
        );
    }

    writeStorage(
        ATTENDANCE_KEY,
        records
    );

    alert(
        "تم حفظ سجل الحضور بنجاح."
    );

    renderAbsenceRecords();

    renderWeeks();

    if (week) {
        selectedWeekId = week.id;
        openWeek(week.id);
    }

    prepareStatuses(
        classData
    );

    renderStudents();
}

/* ==================================================
ABSENCE RECORDS
================================================== */

function renderAbsenceRecords() {

    const records =
        getAttendanceRecords();

    const filter =
        absenceSubjectFilter.value;

    let filtered =
        records.filter(
            function(record) {

                if (!filter) {
                    return true;
                }

                return (
                    String(record.subjectId) ===
                    String(filter)
                );

            }
        );

    filtered.sort(
        function(a, b) {

            return (
                b.date.localeCompare(
                    a.date
                ) ||
                b.savedAt.localeCompare(
                    a.savedAt
                )
            );

        }
    );

    absenceRecords.innerHTML =
        "";

    absenceEmpty.hidden =
        filtered.length !== 0;

    filtered.forEach(
        function(record) {

            absenceRecords.appendChild(
                createRecordCard(record)
            );

        }
    );
}

function createRecordCard(record) {

    const card =
        document.createElement(
            "article"
        );

    card.className =
        "absence-record";

    const week =
        getWeekForDate(
            record.date
        );

    const weekLabel =
        week
            ? week.name
            : "غير مرتبط بأسبوع";

    const absentNames =
        Array.isArray(
            record.absentStudents
        )
            ? record.absentStudents
            : [];

    card.innerHTML = `

        <div class="record-top">

            <div>

                <div class="record-day">
                    ${escapeHTML(record.dayName)}
                </div>

                <div class="record-date">
                    ${escapeHTML(
                        formatDateArabic(
                            record.date
                        )
                    )}
                </div>

            </div>

        </div>

        <div class="record-subject">
            ${escapeHTML(record.subjectName)}
        </div>

        <div class="record-class">
            الصف ${escapeHTML(record.classCode)}
        </div>

        <div class="record-stats">

            <span class="record-stat present">
                الحضور: ${record.presentCount} من ${record.total}
            </span>

            <span class="record-stat absent">
                الغياب: ${record.absentCount}
            </span>

        </div>

        ${
            absentNames.length
                ? `
                    <div class="absent-list-title">
                        الغائبون
                    </div>

                    <ul class="absent-list">

                        ${absentNames.map(
                            student => `
                                <li>
                                    ${escapeHTML(
                                        student.name
                                    )}
                                </li>
                            `
                        ).join("")}

                    </ul>
                `
                : `
                    <div class="absent-list-title">
                        لا يوجد غياب — الجميع حاضر
                    </div>
                `
        }

        <div class="record-week">
            ${escapeHTML(weekLabel)}
        </div>

        <div class="record-actions">
            <button type="button" class="record-delete-button"
                    data-record-id="${escapeHTML(record.id)}">
                حذف السجل
            </button>
        </div>

    `;

    return card;
}

/* ==================================================
DELETE ATTENDANCE RECORD
================================================== */
async function deleteAttendanceRecord(recordId) {
    const records = getAttendanceRecords();
    const record = records.find(item => String(item.id) === String(recordId));
    if (!record) return;

    const ok = await window.MueenUI.confirm(
        `سيتم حذف سجل الحضور بتاريخ ${formatDateArabic(record.date)} للمادة ${record.subjectName || "—"} بشكل نهائي.\nلا يمكن التراجع عن هذا الإجراء.`,
        "تأكيد حذف السجل",
        "حذف السجل"
    );
    if (!ok) return;

    const next = records.filter(item => String(item.id) !== String(recordId));
    writeStorage(ATTENDANCE_KEY, next);
    renderAbsenceRecords();
    renderWeeks();
    if (selectedWeekId) {
        const week = getWeeks().find(w => String(w.id) === String(selectedWeekId));
        if (week) renderWeekDetails(week);
    }
    window.MueenUI.toast("تم حذف السجل بنجاح.", "success");
}

/* ==================================================
DELETE WEEK
================================================== */
async function deleteWeek(weekId) {
    const weeks = getWeeks();
    const week = weeks.find(item => String(item.id) === String(weekId));
    if (!week) return;

    const records = getAttendanceRecords();
    const linkedCount = records.filter(r => String(r.weekId) === String(week.id)).length;

    const ok = await window.MueenUI.confirm(
        `سيتم حذف ${week.name} وجميع سجلات الحضور المرتبطة به (${linkedCount} سجل) نهائيًا.\nلا يمكن التراجع عن هذا الإجراء.`,
        "تأكيد حذف الأسبوع",
        "حذف الأسبوع"
    );
    if (!ok) return;

    saveWeeks(weeks.filter(item => String(item.id) !== String(week.id)));
    writeStorage(
        ATTENDANCE_KEY,
        records.filter(r => String(r.weekId) !== String(week.id))
    );

    selectedWeekId = null;
    if (weekDetails) weekDetails.hidden = true;
    if (weeksList) weeksList.hidden = false;
    renderWeeks();
    renderAbsenceRecords();
    window.MueenUI.toast("تم حذف الأسبوع وسجلاته المرتبطة.", "success");
}

/* ==================================================
WEEKS
================================================== */

function renderWeeks() {

    const weeks =
        getWeeks();

    weeksList.innerHTML =
        "";

    weeksEmpty.hidden =
        weeks.length !== 0;

    weeks
        .sort(
            function(a, b) {

                return (
                    Number(a.number) -
                    Number(b.number)
                );

            }
        )
        .forEach(
            function(week) {

                weeksList.appendChild(
                    createWeekCard(
                        week
                    )
                );

            }
        );

    if (selectedWeekId) {

        const selected =
            weeks.find(
                week =>
                    String(week.id) ===
                    String(selectedWeekId)
            );

        if (selected) {

            renderWeekDetails(
                selected
            );
        }
    }
}

function createWeekCard(week) {

    const records =
        getAttendanceRecords()
            .filter(
                record =>
                    String(record.weekId) ===
                    String(week.id)
            );

    const card =
        document.createElement(
            "article"
        );

    card.className =
        "week-card";

    card.innerHTML = `

        <div class="week-card-top">

            <div>

                <div class="week-number">
                    الأسبوع ${week.number}
                </div>

                <div class="week-title">
                    ${escapeHTML(
                        week.name
                    )}
                </div>

                <div class="week-dates">
                    ${escapeHTML(
                        formatDateRange(
                            week.start,
                            week.end
                        )
                    )}
                </div>

            </div>

            <div class="week-record-count">

                <strong>
                    ${records.length}
                </strong>

                <span>
                    سجل
                </span>

            </div>

        </div>

        <div class="week-card-actions">

            <button
                type="button"
                class="week-open-button">
                فتح الأسبوع
            </button>

            <button
                type="button"
                class="week-edit-button">
                تعديل
            </button>

            <button
                type="button"
                class="week-delete-button"
                aria-label="حذف الأسبوع">
                حذف
            </button>

        </div>

    `;

    card.querySelector(
        ".week-open-button"
    ).addEventListener(
        "click",
        function() {

            openWeek(
                week.id
            );

        }
    );

    card.querySelector(
        ".week-edit-button"
    ).addEventListener(
        "click",
        function() {

            openWeekModal(
                week.id
            );

        }
    );

    return card;
}

/* ==================================================
WEEK DETAILS
================================================== */

function openWeek(id) {

    const week =
        getWeeks().find(
            item =>
                String(item.id) ===
                String(id)
        );

    if (!week) return;

    selectedWeekId =
        id;

    weeksList.hidden =
        true;

    weeksEmpty.hidden =
        true;

    weekDetails.hidden =
        false;

    renderWeekDetails(
        week
    );
}

function renderWeekDetails(week) {

    selectedWeekLabel.textContent =
        week.name;

    selectedWeekDates.textContent =
        formatDateRange(
            week.start,
            week.end
        );

    const records =
        getAttendanceRecords()
            .filter(
                record =>
                    String(record.weekId) ===
                    String(week.id)
            )
            .sort(
                (a, b) =>
                    a.date.localeCompare(
                        b.date
                    )
            );

    weekRecords.innerHTML =
        "";

    if (!records.length) {

        const empty =
            document.createElement(
                "div"
            );

        empty.className =
            "empty-records";

        empty.hidden =
            false;

        empty.innerHTML = `
            <div class="empty-record-icon">—</div>
            <h3>لا توجد سجلات في هذا الأسبوع</h3>
            <p>عند حفظ الحضور ستظهر السجلات هنا.</p>
        `;

        weekRecords.appendChild(
            empty
        );

        return;
    }

    records.forEach(
        function(record) {

            weekRecords.appendChild(
                createRecordCard(
                    record
                )
            );

        }
    );
}

/* ==================================================
WEEK MODAL
================================================== */

function openWeekModal(id = null) {

    editingWeekId =
        id;

    if (id) {

        const week =
            getWeeks().find(
                item =>
                    String(item.id) ===
                    String(id)
            );

        if (!week) return;

        weekModalTitle.textContent =
            "تعديل الأسبوع";

        weekNameInput.value =
            week.name;

        weekStartInput.value =
            week.start;

        weekEndInput.value =
            week.end;

    } else {

        const number =
            getNextWeekNumber();

        const defaults =
            getDefaultWeekDates();

        weekModalTitle.textContent =
            "إضافة أسبوع";

        weekNameInput.value =
            getArabicWeekName(
                number
            );

        weekStartInput.value =
            defaults.start;

        weekEndInput.value =
            defaults.end;
    }

    weekModal.hidden =
        false;
}

function closeWeekModal() {

    weekModal.hidden =
        true;

    editingWeekId =
        null;
}

function saveWeek() {

    const name =
        weekNameInput.value.trim();

    const start =
        weekStartInput.value;

    const end =
        weekEndInput.value;

    if (!name) {

        alert(
            "يرجى كتابة اسم الأسبوع."
        );

        return;
    }

    if (!start || !end) {

        alert(
            "يرجى اختيار تاريخ بداية ونهاية الأسبوع."
        );

        return;
    }

    if (start > end) {

        alert(
            "تاريخ البداية يجب أن يكون قبل تاريخ النهاية."
        );

        return;
    }

    const weeks =
        getWeeks();

    const overlap =
        weeks.some(
            function(week) {

                if (
                    editingWeekId &&
                    String(week.id) ===
                    String(editingWeekId)
                ) {

                    return false;
                }

                return (
                    start <= week.end &&
                    end >= week.start
                );

            }
        );

    if (overlap) {

        alert(
            "توجد فترة أسبوع أخرى تتداخل مع هذه التواريخ."
        );

        return;
    }

    if (editingWeekId) {

        const index =
            weeks.findIndex(
                week =>
                    String(week.id) ===
                    String(editingWeekId)
            );

        if (index !== -1) {

            weeks[index] = {

                ...weeks[index],

                name:
                    name,

                start:
                    start,

                end:
                    end

            };
        }

    } else {

        weeks.push({

            id:
                Date.now().toString(),

            number:
                getNextWeekNumber(),

            name:
                name,

            start:
                start,

            end:
                end,

            createdAt:
                new Date().toISOString()

        });
    }

    saveWeeks(
        weeks
    );

    closeWeekModal();

    renderWeeks();

    renderAbsenceRecords();
}

/* ==================================================
DELETE ALL ATTENDANCE DATA
================================================== */

async function deleteAllAttendanceRecords() {

    const records = getAttendanceRecords();

    if (!records.length) {
        window.MueenUI.toast("لا توجد سجلات حضور وغياب محفوظة لحذفها.", "info");
        return;
    }

    const ok = await window.MueenUI.confirm(
        `سيتم حذف جميع سجلات الحضور والغياب المحفوظة (${records.length} سجل) نهائيًا.\n\nلن يتم حذف الطلاب أو الصفوف أو المواد أو الأسابيع.\nلا يمكن التراجع عن هذا الإجراء.`,
        "تأكيد حذف جميع السجلات",
        "حذف جميع السجلات"
    );

    if (!ok) return;

    writeStorage(ATTENDANCE_KEY, []);
    currentStatuses = {};
    selectedWeekId = null;

    if (weekDetails) weekDetails.hidden = true;
    if (weeksList) weeksList.hidden = false;

    renderAbsenceRecords();
    renderWeeks();
    window.MueenUI.toast("تم حذف جميع سجلات الحضور والغياب بنجاح.", "success");
}

async function deleteAllWeeksAndRecords() {

    const weeks = getWeeks();
    const records = getAttendanceRecords();

    if (!weeks.length && !records.length) {
        window.MueenUI.toast("لا توجد أسابيع أو سجلات محفوظة لحذفها.", "info");
        return;
    }

    const ok = await window.MueenUI.confirm(
        `سيتم حذف جميع الأسابيع الدراسية (${weeks.length}) وجميع سجلات الحضور المرتبطة بها، كما سيتم حذف أي سجلات حضور متبقية (${records.length} سجل إجمالًا).\n\nلن يتم حذف الطلاب أو الصفوف أو المواد.\nلا يمكن التراجع عن هذا الإجراء.`,
        "تأكيد حذف الأسابيع والسجلات",
        "حذف الكل"
    );

    if (!ok) return;

    saveWeeks([]);
    writeStorage(ATTENDANCE_KEY, []);

    selectedWeekId = null;
    currentStatuses = {};

    if (weekDetails) weekDetails.hidden = true;
    if (weeksList) weeksList.hidden = false;

    renderWeeks();
    renderAbsenceRecords();
    window.MueenUI.toast("تم حذف جميع الأسابيع والسجلات بنجاح.", "success");
}

function updateTopDeleteButton(target) {

    if (!deleteAttendanceDataTopButton) return;

    const visible = target === "absence" || target === "weeks";
    deleteAttendanceDataTopButton.hidden = !visible;

    if (!visible) return;

    if (target === "absence") {
        deleteAttendanceDataTopButton.setAttribute("aria-label", "حذف جميع سجلات الغياب");
        deleteAttendanceDataTopButton.setAttribute("title", "حذف جميع سجلات الغياب");
    } else {
        deleteAttendanceDataTopButton.setAttribute("aria-label", "حذف جميع الأسابيع والسجلات");
        deleteAttendanceDataTopButton.setAttribute("title", "حذف جميع الأسابيع والسجلات");
    }
}

/* ==================================================
NAVIGATION TABS
================================================== */

if (deleteAttendanceDataTopButton) {
    deleteAttendanceDataTopButton.addEventListener("click", () => {
        const activeTab = document.querySelector(".attendance-tab.active")?.dataset.tab;
        if (activeTab === "absence") {
            deleteAllAttendanceRecords();
        } else if (activeTab === "weeks") {
            deleteAllWeeksAndRecords();
        }
    });
}

function setupTabs() {

    const tabs =
        document.querySelectorAll(
            ".attendance-tab"
        );

    tabs.forEach(
        function(tab) {

            tab.addEventListener(
                "click",
                function() {

                    const target =
                        tab.dataset.tab;

                    updateTopDeleteButton(target);

                    tabs.forEach(
                        item =>
                            item.classList.remove(
                                "active"
                            )
                    );

                    tab.classList.add(
                        "active"
                    );

                    document
                        .querySelectorAll(
                            ".tab-panel"
                        )
                        .forEach(
                            panel => {

                                panel.hidden =
                                    true;

                                panel.classList.remove(
                                    "active"
                                );

                            }
                        );

                    const panel =
                        document.getElementById(
                            target === "attendance"
                                ? "attendancePanel"
                                : target === "absence"
                                    ? "absencePanel"
                                    : "weeksPanel"
                        );

                    if (panel) {

                        panel.hidden =
                            false;

                        panel.classList.add(
                            "active"
                        );
                    }

                    if (
                        target ===
                        "absence"
                    ) {

                        renderAbsenceRecords();
                    }

                    if (
                        target ===
                        "weeks"
                    ) {

                        renderWeeks();
                    }

                }
            );

        }
    );
}

/* ==================================================
EVENTS
================================================== */

function setupEvents() {

    attendanceDate.addEventListener(
        "change",
        function() {

            attendanceDay.textContent =
                getDayName(
                    attendanceDate.value
                );

        }
    );

    subjectSelect.addEventListener(
        "change",
        function() {

            /*
               تغيير المادة لا يمسح حالة الطلاب.
            */

        }
    );

    classSelect.addEventListener(
        "change",
        function() {

            prepareStatuses(
                getSelectedClass()
            );

            renderStudents();

        }
    );

    attendanceStudentList.addEventListener(
        "click",
        function(event) {

            const button =
                event.target.closest(
                    ".status-button"
                );

            if (!button) return;

            toggleStudentStatus(
                button.dataset.studentId
            );

        }
    );

    presentAllButton.addEventListener(
        "click",
        setEveryonePresent
    );

    saveAttendanceButton.addEventListener(
        "click",
        saveAttendanceRecord
    );

    document
        .getElementById("addSubjectButton")
        ?.addEventListener(
            "click",
            () => {
                window.location.href = "settings.html#subjects";
            }
        );

    document
        .getElementById("addSubjectTopButton")
        ?.addEventListener(
            "click",
            () => {
                window.location.href = "settings.html#subjects";
            }
        );

    document
        .getElementById(
            "closeSubjectModalButton"
        )
        .addEventListener(
            "click",
            closeSubjectModal
        );

    document
        .getElementById(
            "cancelSubjectButton"
        )
        .addEventListener(
            "click",
            closeSubjectModal
        );

    saveSubjectButton.addEventListener(
        "click",
        saveSubject
    );

    subjectManagement.addEventListener(
        "click",
        function(event) {

            const editButton =
                event.target.closest(
                    "[data-edit-subject]"
                );

            const deleteButton =
                event.target.closest(
                    "[data-delete-subject]"
                );

            if (editButton) {

                openSubjectModal(
                    editButton.dataset.editSubject
                );

                return;
            }

            if (deleteButton) {

                deleteSubject(
                    deleteButton.dataset.deleteSubject
                );
            }

        }
    );

    absenceSubjectFilter.addEventListener(
        "change",
        renderAbsenceRecords
    );

    document
        .getElementById(
            "addWeekButton"
        )
        .addEventListener(
            "click",
            () =>
                openWeekModal()
        );

    document
        .getElementById(
            "emptyAddWeekButton"
        )
        .addEventListener(
            "click",
            () =>
                openWeekModal()
        );

    document
        .getElementById(
            "closeWeekModalButton"
        )
        .addEventListener(
            "click",
            closeWeekModal
        );

    document
        .getElementById(
            "cancelWeekButton"
        )
        .addEventListener(
            "click",
            closeWeekModal
        );

    document
        .getElementById(
            "saveWeekButton"
        )
        .addEventListener(
            "click",
            saveWeek
        );

    document
        .getElementById(
            "backWeekButton"
        )
        .addEventListener(
            "click",
            function() {

                selectedWeekId =
                    null;

                weekDetails.hidden =
                    true;

                weeksList.hidden =
                    false;

                renderWeeks();

            }
        );

    document
        .getElementById(
            "editSelectedWeekButton"
        )
        .addEventListener(
            "click",
            function() {

                if (selectedWeekId) {

                    openWeekModal(
                        selectedWeekId
                    );
                }

            }
        );

    subjectModal.addEventListener(
        "click",
        function(event) {

            if (
                event.target ===
                subjectModal
            ) {

                closeSubjectModal();
            }

        }
    );

    weekModal.addEventListener(
        "click",
        function(event) {

            if (
                event.target ===
                weekModal
            ) {

                closeWeekModal();
            }

        }
    );
}

/* ==================================================
ESCAPE HTML
================================================== */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}

/* ==================================================
INIT
================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        attendanceDate.value =
            getLocalDateString();

        attendanceDay.textContent =
            getDayName(
                attendanceDate.value
            );

        renderSubjects();

        renderClasses();

        setupTabs();

        setupEvents();

        updateLiveSummary();

    }
);

/* ==================================================
BACK/FORWARD PAGE STATE
================================================== */

window.addEventListener(
    "pageshow",
    function() {

        renderSubjects();

        renderClasses();

        renderAbsenceRecords();

        renderWeeks();

    }
);
/* ==================================================
   SMART MAIN NAVIGATION
================================================== */

function goMain(page) {

    const currentPage =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();


    /*
     * الرئيسية → قسم رئيسي
     *
     * نستخدم href حتى تبقى
     * الرئيسية في سجل الرجوع.
     */

    if (
        currentPage === "home.html" ||
        currentPage === ""
    ) {

        window.location.href =
            page;

        return;
    }


    /*
     * قسم رئيسي → قسم رئيسي
     *
     * نستخدم replace حتى لا تتراكم
     * الصفحات في سجل الرجوع.
     */

    window.location.replace(
        page
    );
}


/* ==================================================
   BOTTOM NAVIGATION
================================================== */

const homeNavigation =
    document.getElementById(
        "homeNavigation"
    );

const attendanceNavigation =
    document.getElementById(
        "attendanceNavigation"
    );

const studentsNavigation =
    document.getElementById(
        "studentsNavigation"
    );

const scheduleNavigation =
    document.getElementById(
        "scheduleNavigation"
    );

const gradesNavigation =
    document.getElementById(
        "gradesNavigation"
    );

const reportsNavigation =
    document.getElementById(
        "reportsNavigation"
    );


if (homeNavigation) {

    homeNavigation.addEventListener(
        "click",
        () => goMain("home.html")
    );
}


if (attendanceNavigation) {

    attendanceNavigation.addEventListener(
        "click",
        () => goMain("attendance.html")
    );
}


if (studentsNavigation) {

    studentsNavigation.addEventListener(
        "click",
        () => goMain("students.html")
    );
}


if (scheduleNavigation) {

    scheduleNavigation.addEventListener(
        "click",
        () => goMain("schedule.html")
    );
}


if (gradesNavigation) {

    gradesNavigation.addEventListener(
        "click",
        () => goMain("grades.html")
    );
}


if (reportsNavigation) {

    reportsNavigation.addEventListener(
        "click",
        () => goMain("reports.html")
    );
}

// الحالة الابتدائية لزر الحذف العلوي
updateTopDeleteButton("attendance");
