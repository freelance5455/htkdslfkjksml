import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

from backup_data import build_backup, verify_backup


class BackupTests(unittest.TestCase):
    def test_backup_manifest_and_integrity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"
            data.mkdir()
            (data / "users.json").write_text('[{"id":1}]', encoding="utf-8")
            (data / "sessions.json").write_text('[]', encoding="utf-8")
            (data / ".local_jwt_secret").write_text("must-not-be-backed-up", encoding="utf-8")
            target = root / "backup.zip"
            build_backup(data, target)
            result = verify_backup(target)
            self.assertTrue(result["valid"])
            self.assertEqual(result["files_checked"], 2)
            with ZipFile(target) as archive:
                self.assertNotIn("data/.local_jwt_secret", archive.namelist())

    def test_tampered_backup_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data = root / "data"
            data.mkdir()
            (data / "users.json").write_text('[]', encoding="utf-8")
            target = root / "backup.zip"
            build_backup(data, target)
            with ZipFile(target, "a") as archive:
                with self.assertWarns(UserWarning):
                    archive.writestr("data/users.json", '[{"tampered":true}]')
            with self.assertRaises(ValueError):
                verify_backup(target)


if __name__ == "__main__":
    unittest.main()
