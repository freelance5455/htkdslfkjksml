from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class SliderConfigTests(unittest.TestCase):
    def test_admin_exposes_and_persists_timing_controls(self):
        html = (ROOT / "static" / "admin.html").read_text()
        self.assertIn('id="themeSlideInterval"', html)
        self.assertIn('id="themeSlideTransition"', html)
        self.assertIn('hero_slide_interval:Number', html)
        self.assertIn('hero_slide_transition:Number', html)

    def test_client_applies_saved_interval_and_fade(self):
        html = (ROOT / "static" / "app.html").read_text()
        self.assertIn("intervalSeconds*1000", html)
        self.assertIn("--hero-fade-ms", html)
        self.assertIn("settings.hero_slide_interval", html)
        self.assertIn("settings.hero_slide_transition", html)

    def test_server_validates_timing_ranges(self):
        source = (ROOT / "server.py").read_text()
        self.assertIn('"hero_slide_interval": (3, 30)', source)
        self.assertIn('"hero_slide_transition": (200, 3000)', source)
        self.assertIn('"hero_slide_interval": 6', source)
        self.assertIn('"hero_slide_transition": 1350', source)

if __name__ == "__main__":
    unittest.main()
