from pathlib import Path
import unittest

APP = Path(__file__).resolve().parents[1] / 'static' / 'app.html'

class UserExperienceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = APP.read_text(encoding='utf-8')

    def test_main_navigation_exposes_favorites_and_more(self):
        self.assertIn('data-tab="favorites"', self.html)
        self.assertIn('data-tab="more"', self.html)
        self.assertIn('id="tab-favorites"', self.html)
        self.assertIn('id="tab-more"', self.html)

    def test_more_menu_exposes_account_options(self):
        for label in ('پروفایل کاربری', 'علاقه‌مندی‌ها', 'اشتراک و خرید', 'پشتیبانی', 'تنظیمات'):
            self.assertIn(label, self.html)

    def test_favorites_are_account_scoped_and_persisted(self):
        self.assertIn("'cg_favorites_' + (currentUser || 'guest')", self.html)
        self.assertIn('function toggleFavorite(type,id)', self.html)
        self.assertIn('function renderFavorites()', self.html)

    def test_home_theme_is_loaded_from_global_settings(self):
        self.assertIn("api('/api/app-settings')", self.html)
        self.assertIn("applyPublicAppearance(settings)", self.html)
        self.assertIn("--primary", self.html)
        self.assertIn("--bg", self.html)

    def test_home_hero_uses_uploaded_content_poster_and_has_empty_state(self):
        self.assertIn('id="homeHero"', self.html)
        self.assertIn('featured.poster_url', self.html)
        self.assertIn('settings.hero_description', self.html)
        self.assertIn("hero.classList.remove(\'has-poster\')", self.html)

    def test_home_hero_has_manual_controls_and_touch_navigation(self):
        self.assertIn('id="heroPrev"', self.html)
        self.assertIn('id="heroNext"', self.html)
        self.assertIn('id="heroPause"', self.html)
        self.assertIn("dot.addEventListener('click'", self.html)
        self.assertIn('hero.ontouchstart', self.html)
        self.assertIn('hero.ontouchend', self.html)
        self.assertIn("prefers-reduced-motion: reduce", self.html)

if __name__ == '__main__':
    unittest.main()
