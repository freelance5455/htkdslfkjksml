import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import storage


class JsonStorageTests(unittest.TestCase):
    def test_atomic_json_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(storage, "DATA_DIR", Path(tmp)), patch.object(storage, "BACKEND", "json"):
                storage.initialize()
                records = [{"id": 1, "username": "sample"}, {"id": 2, "username": "second"}]
                storage.save("users", records)
                self.assertEqual(storage.load("users"), records)
                self.assertEqual(json.loads((Path(tmp) / "users.json").read_text()), records)

    def test_unknown_collection_is_rejected(self):
        with self.assertRaises(ValueError):
            storage.load("arbitrary_path")

    def test_non_list_collection_is_rejected(self):
        with self.assertRaises(TypeError):
            storage.save("users", {"id": 1})


if __name__ == "__main__":
    unittest.main()
