import unittest
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class SubscriptionAdminTests(unittest.TestCase):
    def test_admin_has_subscription_controls_and_free_paid_content_choices(self):
        html = (ROOT / "static" / "admin.html").read_text()
        for item in ("subsEnabled", "subsMonthlyPrice", "subsQuarterDiscount", "subsHalfDiscount", "subscriptionPricePreview"):
            self.assertIn(f'id="{item}"', html)
        self.assertIn('id="m_access_type"', html)
        self.assertIn('id="s_access_type"', html)
        self.assertIn("saveSubscriptionSettings", html)

    def test_server_has_three_day_trial_and_dynamic_plan_prices(self):
        source = (ROOT / "server.py").read_text()
        self.assertIn('now + timedelta(days=3)', source)
        self.assertIn('def subscription_plans()', source)
        self.assertIn('quarterly_discount', source)
        self.assertIn('semiannual_discount', source)
        self.assertIn('has_item_access', source)

    def test_plan_prices_are_derived_from_monthly_price(self):
        source = (ROOT / "server.py").read_text()
        self.assertIn('monthly * 3 * (100-int(cfg["quarterly_discount"])) / 100', source)
        self.assertIn('monthly * 6 * (100-int(cfg["semiannual_discount"])) / 100', source)

    def test_free_content_bypasses_subscription_but_paid_content_does_not(self):
        import sys
        sys.path.insert(0, str(ROOT))
        import server
        with tempfile.TemporaryDirectory() as tmp:
            old_dir, old_enabled = server.DATA_DIR, server.SUBSCRIPTIONS_ENABLED
            server.DATA_DIR = Path(tmp)
            server.SUBSCRIPTIONS_ENABLED = True
            try:
                from storage import initialize
                import storage
                old_storage_dir = storage.DATA_DIR
                storage.DATA_DIR = Path(tmp)
                initialize()
                self.assertTrue(server.has_item_access({"id": 10, "role": "user"}, {"access_type": "free"}, []))
                self.assertFalse(server.has_item_access({"id": 10, "role": "user"}, {"access_type": "subscription"}, []))
                storage.DATA_DIR = old_storage_dir
            finally:
                server.DATA_DIR, server.SUBSCRIPTIONS_ENABLED = old_dir, old_enabled

if __name__ == "__main__":
    unittest.main()
