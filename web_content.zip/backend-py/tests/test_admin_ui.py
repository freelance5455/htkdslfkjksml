import unittest
from pathlib import Path


class AdminMediaEditorTests(unittest.TestCase):

    def test_android_termux_launcher_is_local_only_and_documented(self):
        root = Path(__file__).resolve().parents[2]
        launcher = (root / "start-android-termux.sh").read_text(encoding="utf-8")
        guide = (root / "ANDROID-TERMUX-GUIDE-FA.md").read_text(encoding="utf-8")
        self.assertIn('export HOST=127.0.0.1', launcher)
        self.assertIn('export PORT=3000', launcher)
        self.assertIn('python3 setup_admin.py', launcher)
        self.assertIn('http://127.0.0.1:3000/admin', guide)
        self.assertIn('termux-setup-storage', guide)
        self.assertIn('این روش فقط روی همان گوشی', guide)
    def test_admin_and_user_sessions_use_separate_browser_storage_keys(self):
        root = Path(__file__).resolve().parents[1]
        admin = (root / "static" / "admin.html").read_text(encoding="utf-8")
        app = (root / "static" / "app.html").read_text(encoding="utf-8")
        self.assertIn("localStorage.getItem('cg_admin_token')", admin)
        self.assertIn("localStorage.setItem('cg_admin_token', token)", admin)
        self.assertIn("localStorage.removeItem('cg_admin_token')", admin)
        self.assertNotIn("localStorage.setItem('cp_token', token)", admin)
        self.assertIn("localStorage.setItem('cp_token', token)", app)

    def test_edit_forms_offer_direct_media_replacement(self):
        admin = Path(__file__).resolve().parents[1] / "static" / "admin.html"
        source = admin.read_text(encoding="utf-8")
        self.assertIn("function chooseLocalFile(accept)", source)
        self.assertIn("async function uploadReplacement(kind, accept, confirmFirst = true)", source)
        self.assertIn("const newPoster = await uploadReplacement('poster'", source)
        self.assertIn("const newVideo = await uploadReplacement('video'", source)
        self.assertIn("/api/admin/movies/' + id", source)
        self.assertIn("/api/admin/series/' + id", source)

    def test_admin_can_manage_home_banner_and_global_theme(self):
        admin = Path(__file__).resolve().parents[1] / "static" / "admin.html"
        app = Path(__file__).resolve().parents[1] / "static" / "app.html"
        server = Path(__file__).resolve().parents[1] / "server.py"
        admin_html = admin.read_text(encoding="utf-8")
        app_html = app.read_text(encoding="utf-8")
        server_py = server.read_text(encoding="utf-8")
        self.assertIn("showTab('appearance')", admin_html)
        self.assertIn('class="admin-appearance-shortcut"', admin_html)
        self.assertIn('مدیریت پوستر و رنگ‌ها', admin_html)
        self.assertIn('id="appearancePreview"', admin_html)
        self.assertIn('id="appearancePreviewHero"', admin_html)
        self.assertIn('id="themePosterFile"', admin_html)
        self.assertIn("uploadInChunks(file,'poster','themePosterStatus','themePosterProgress')", admin_html)
        self.assertIn("async function saveAppearance()", admin_html)
        self.assertIn("/api/admin/settings", admin_html)
        self.assertIn("/api/app-settings", app_html)
        self.assertIn("function applyPublicAppearance(settings)", app_html)
        self.assertIn("customHeroPoster", app_html)
        self.assertIn('if path == "/api/admin/settings":', server_py)

    def test_admin_can_upload_hls_zip_for_movies_and_episodes(self):
        admin = Path(__file__).resolve().parents[1] / "static" / "admin.html"
        source = admin.read_text(encoding="utf-8")
        self.assertIn('id="m_hls_file"', source)
        self.assertIn("uploadInChunks(hlsFile,'hls_bundle'", source)
        self.assertIn('id="m_subtitle_file"', source)
        self.assertIn("uploadInChunks(subtitleFile,'subtitle'", source)
        self.assertIn('id="ehls-${season.id}"', source)
        self.assertIn("uploadInChunks(hlsFile,'hls_bundle'", source)
        self.assertIn('id="ee-hls-${ep.id}"', source)
        self.assertIn('id="ee-sub-file-${ep.id}"', source)
        self.assertIn("uploadInChunks(hlsFile, 'hls_bundle'", source)

    def test_season_editor_supports_number_and_title_changes(self):
        admin = Path(__file__).resolve().parents[1] / "static" / "admin.html"
        source = admin.read_text(encoding="utf-8")
        self.assertIn("function toggleSeasonEditor(id)", source)
        self.assertIn("async function saveSeasonEdit(id)", source)
        self.assertIn("/api/admin/seasons/' + id", source)

    def test_episode_editor_supports_direct_video_replacement_and_patch(self):
        admin = Path(__file__).resolve().parents[1] / "static" / "admin.html"
        source = admin.read_text(encoding="utf-8")
        self.assertIn("function toggleEpisodeEditor(id)", source)
        self.assertIn("async function saveEpisodeEdit(id)", source)
        self.assertIn("uploadInChunks(videoFile, 'video'", source)
        self.assertIn("/api/admin/episodes/' + id", source)
        self.assertIn("ویدئوی فعلی حفظ می‌شود", source)

    def test_android_view_rebinds_player_when_content_changes(self):
        root = Path(__file__).resolve().parents[2]
        player = (root / "android/app/src/main/java/com/cinemaplus/app/ui/player/PlayerScreen.kt").read_text(encoding="utf-8")
        self.assertIn("update = { view ->", player)
        self.assertIn("if (view.player !== exoPlayer) view.player = exoPlayer", player)
        self.assertIn("DisposableEffect(exoPlayer)", player)

    def test_android_player_shows_retry_after_playback_error(self):
        root = Path(__file__).resolve().parents[2]
        player = (root / "android/app/src/main/java/com/cinemaplus/app/ui/player/PlayerScreen.kt").read_text(encoding="utf-8")
        self.assertIn("override fun onPlayerError", player)
        self.assertIn("var playbackError by remember", player)
        self.assertIn("دریافت لینک تازه و تلاش دوباره", player)
        self.assertIn("createCurrentMediaSource(selectedVideoUrl", player)
        self.assertIn("val resumeAt = exoPlayer.currentPosition", player)

    def test_android_player_exposes_quality_audio_and_subtitle_tracks(self):
        root = Path(__file__).resolve().parents[2]
        player = (root / "android/app/src/main/java/com/cinemaplus/app/ui/player/PlayerScreen.kt").read_text(encoding="utf-8")
        models = (root / "android/app/src/main/java/com/cinemaplus/app/data/model/Models.kt").read_text(encoding="utf-8")
        movie = (root / "android/app/src/main/java/com/cinemaplus/app/ui/detail/MovieDetailScreen.kt").read_text(encoding="utf-8")
        series = (root / "android/app/src/main/java/com/cinemaplus/app/ui/detail/SeriesDetailScreen.kt").read_text(encoding="utf-8")
        self.assertIn("TrackSelectionOverride", player)
        self.assertIn("MergingMediaSource", player)
        self.assertIn("remember(playInfo.id, playInfo.videoUrl)", player)
        self.assertIn("DisposableEffect(exoPlayer)", player)
        self.assertIn("selectedVideoUrl", player)
        self.assertIn("selectedVideoMime", player)
        self.assertIn("subtitleLanguage", player)
        self.assertIn("qualityOptions", player)
        self.assertIn("audioTracks", player)
        self.assertIn("subtitleTracks", player)
        self.assertIn("quality_options: List<PlaybackTrackDto>", models)
        self.assertIn("audio_tracks: List<PlaybackTrackDto>", models)
        self.assertIn("subtitle_tracks: List<PlaybackTrackDto>", models)
        self.assertIn("var activeAudioChoice by remember", player)
        self.assertIn("fun createCurrentMediaSource", player)
        self.assertIn("createCurrentMediaSource(selectedVideoUrl, null, selectedVideoMime, activeAudioChoice)", player)
        self.assertIn("createCurrentMediaSource(next, activeSubtitleUrl, detectedMime, activeAudioChoice)", player)
        self.assertIn("qualityOptions = play.quality_options.map", movie)
        self.assertIn("play.quality_options.map", series)


    def test_android_player_replaces_expired_track_catalog_after_refresh(self):
        root = Path(__file__).resolve().parents[2]
        player = (root / "android/app/src/main/java/com/cinemaplus/app/ui/player/PlayerScreen.kt").read_text(encoding="utf-8")
        self.assertIn("var qualityChoices by remember", player)
        self.assertIn("var audioChoices by remember", player)
        self.assertIn("var subtitleChoices by remember", player)
        self.assertIn("qualityChoices = fresh.qualityOptions", player)
        self.assertIn("audioChoices = fresh.audioTracks", player)
        self.assertIn("subtitleChoices = fresh.subtitleTracks", player)
        self.assertIn("qualityChoices.forEach", player)
        self.assertIn("audioChoices.forEach", player)
        self.assertIn("subtitleChoices.forEach", player)

    def test_android_player_refreshes_expired_signed_links(self):
        root = Path(__file__).resolve().parents[2]
        player = (root / "android/app/src/main/java/com/cinemaplus/app/ui/player/PlayerScreen.kt").read_text(encoding="utf-8")
        main = (root / "android/app/src/main/java/com/cinemaplus/app/MainActivity.kt").read_text(encoding="utf-8")
        api = (root / "android/app/src/main/java/com/cinemaplus/app/data/api/CinemaApi.kt").read_text(encoding="utf-8")
        self.assertIn("InvalidResponseCodeException", player)
        self.assertIn("responseCode == 401 || responseCode == 403", player)
        self.assertIn("onRefreshPlayInfo", player)
        self.assertIn("exoPlayer.currentPosition.coerceAtLeast(0L)", player)
        self.assertIn("api.playEpisode(play.id)", main)
        self.assertIn("api.playMovie(play.id)", main)
        self.assertIn("contentType = \"movie\"", (root / "android/app/src/main/java/com/cinemaplus/app/ui/detail/MovieDetailScreen.kt").read_text(encoding="utf-8"))
        self.assertIn('"episode")', (root / "android/app/src/main/java/com/cinemaplus/app/ui/detail/SeriesDetailScreen.kt").read_text(encoding="utf-8"))



if __name__ == "__main__":
    unittest.main()


class MobileUploadCompatibilityTests(unittest.TestCase):
    def test_mobile_upload_does_not_require_webcrypto_and_uses_broad_picker_types(self):
        root = Path(__file__).resolve().parents[1]
        admin = (root / "static" / "admin.html").read_text(encoding="utf-8")
        self.assertIn("The server\n          // computes and verifies SHA-256", admin)
        self.assertNotIn("await chunk.arrayBuffer()", admin)
        self.assertIn("accept=\"image/*,.jpg,.jpeg,.png,.webp,.gif\"", admin)
        self.assertIn("accept=\"video/*,.mp4,.m4v,.mov,.webm,.mkv,.ts\"", admin)
        self.assertIn("chunkHashHex ? {'X-Chunk-SHA256':chunkHashHex} : {}", admin)

    def test_local_server_listens_on_lan_for_phone_testing(self):
        root = Path(__file__).resolve().parents[1]
        self.assertIn('HOST:-0.0.0.0', (root / "run_local.sh").read_text())
        self.assertIn('HOST=0.0.0.0', (root / "run_local.bat").read_text())
