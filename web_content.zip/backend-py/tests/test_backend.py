import json
import os
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from http.server import HTTPServer
from pathlib import Path

os.environ.setdefault("JWT_SECRET", "test-only-secret-value-with-more-than-32-characters")
os.environ.setdefault("APP_ENV", "development")
import server
import storage

class BackendIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        server.SUBSCRIPTIONS_ENABLED = False  # Preserve legacy free-mode baseline for unrelated tests.
        server.DATA_DIR = Path(cls.tmp.name)
        storage.DATA_DIR = Path(cls.tmp.name)
        for name in ("users", "sessions", "support_tickets", "support_messages", "content_reports", "subscriptions", "plans", "movies", "series", "episodes", "payments", "downloads", "comments", "ratings", "seasons", "admin_audit_logs", "watch_progress", "app_settings"):
            server.save(name, [])
        cls.httpd = HTTPServer(("127.0.0.1", 0), server.Handler)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.port}"

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        cls.tmp.cleanup()

    def request(self, path, method="GET", body=None, token=None):
        data = json.dumps(body).encode() if body is not None else None
        headers = {"Content-Type": "application/json"}
        if token: headers["Authorization"] = "Bearer " + token
        req = urllib.request.Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req) as res:
                return res.status, json.loads(res.read().decode())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode())

    def test_home_appearance_settings_are_public_read_and_admin_write_only(self):
        public_status, defaults = self.request("/api/app-settings")
        self.assertEqual(public_status, 200)
        self.assertEqual(defaults["hero_poster_url"], "")
        self.assertIn("primary", defaults["colors"])
        reg_status, registered = self.request("/api/auth/register", "POST", {
            "username": "appearanceadmin", "password": "LongPassword123!"
        })
        self.assertEqual(reg_status, 201)
        users = storage.load("users")
        admin = next(u for u in users if u["username"] == "appearanceadmin")
        admin["role"] = "admin"
        storage.save("users", users)
        login_status, logged = self.request("/api/auth/login", "POST", {
            "username": "appearanceadmin", "password": "LongPassword123!"
        })
        self.assertEqual(login_status, 200)
        admin_token = logged["token"]
        self.assertEqual(self.request("/api/admin/settings")[0], 403)
        admin_read_status, _ = self.request("/api/admin/settings", token=admin_token)
        self.assertEqual(admin_read_status, 200)
        patch_status, _ = self.request("/api/admin/settings", "PATCH", {
            "hero_poster_url": "/media/uploads/home-banner.webp",
            "hero_title": "سینما در خانه", "hero_description": "بنر اختصاصی",
            "hero_button": "تماشا", "theme": "midnight",
            "colors": {"bg": "#071522", "primary": "#55b9e8"}
        }, admin_token)
        self.assertEqual(patch_status, 200)
        _, visible = self.request("/api/app-settings")
        self.assertEqual(visible["hero_poster_url"], "/media/uploads/home-banner.webp")
        self.assertEqual(visible["hero_title"], "سینما در خانه")
        self.assertEqual(visible["colors"]["primary"], "#55b9e8")
        bad_status, _ = self.request("/api/admin/settings", "PATCH", {"colors": {"bg": "red"}}, admin_token)
        self.assertEqual(bad_status, 400)

    def test_password_hash_and_legacy_upgrade(self):
        hashed = server.hash_password("VeryStrongTestPassword123")
        self.assertTrue(hashed.startswith("pbkdf2_sha256$"))
        self.assertTrue(server.verify_password("VeryStrongTestPassword123", hashed))
        self.assertFalse(server.verify_password("wrong", hashed))
        legacy = __import__("hashlib").sha256(("cinema_salt_v1" + "OldPass123!").encode()).hexdigest()
        self.assertTrue(server.verify_password("OldPass123!", legacy))

    def test_register_login_logout_and_session_revocation(self):
        code, created = self.request("/api/auth/register", "POST", {
            "username": "sessionuser", "password": "LongPassword123!"
        })
        self.assertEqual(code, 201)
        token = created["token"]
        self.assertEqual(self.request("/api/auth/me", token=token)[0], 200)
        login_code, logged_in = self.request("/api/auth/login", "POST", {
            "username": "sessionuser", "password": "LongPassword123!"
        })
        self.assertEqual(login_code, 200)
        self.assertEqual(self.request("/api/auth/logout", "POST", {}, token)[0], 200)
        self.assertEqual(self.request("/api/auth/me", token=token)[0], 401)

    def test_password_change_revokes_all_sessions(self):
        code, created = self.request("/api/auth/register", "POST", {
            "username": "changepass", "password": "InitialPassword123!"
        })
        self.assertEqual(code, 201)
        old_token = created["token"]
        status, _ = self.request("/api/me/password", "POST", {
            "current_password": "wrong-password", "new_password": "NewPassword123!",
            "confirm_password": "NewPassword123!"
        }, old_token)
        self.assertEqual(status, 400)
        status, _ = self.request("/api/me/password", "POST", {
            "current_password": "InitialPassword123!", "new_password": "NewPassword123!",
            "confirm_password": "NewPassword123!"
        }, old_token)
        self.assertEqual(status, 200)
        self.assertEqual(self.request("/api/auth/me", token=old_token)[0], 401)
        login_status, _ = self.request("/api/auth/login", "POST", {
            "username": "changepass", "password": "NewPassword123!"
        })
        self.assertEqual(login_status, 200)
        bad_login, _ = self.request("/api/auth/login", "POST", {
            "username": "changepass", "password": "InitialPassword123!"
        })
        self.assertEqual(bad_login, 401)

    def test_duplicate_username_and_weak_password_rejected(self):
        code, _ = self.request("/api/auth/register", "POST", {
            "username": "another", "password": "123"
        })
        self.assertEqual(code, 400)
        code, _ = self.request("/api/auth/register", "POST", {
            "username": "dupeuser", "password": "LongPassword123!"
        })
        self.assertEqual(code, 201)
        code, _ = self.request("/api/auth/register", "POST", {
            "username": "dupeuser", "password": "LongPassword123!"
        })
        self.assertEqual(code, 409)


    def test_signed_playback_link_and_expiry_validation(self):
        code, created = self.request("/api/auth/register", "POST", {
            "username": "playerone", "password": "PlayerPassword123!"
        })
        self.assertEqual(code, 201)
        token = created["token"]
        server.save("movies", [{"id": 41, "title": "Test Movie", "is_active": True,
            "video_url": "https://media.example.test/movie.mp4", "duration": 120,
            "quality_options": [{"label": "720p", "url": "https://media.example.test/720.mp4"}],
            "audio_tracks": [], "subtitle_tracks": []}])
        status, playback = self.request("/api/movies/41/play", token=token)
        self.assertEqual(status, 200)
        self.assertNotIn("media.example.test", playback["video_url"])
        self.assertTrue(playback["video_url"].startswith("/api/media/resolve?token="))
        signed = playback["video_url"].split("token=", 1)[1]
        req = urllib.request.Request(self.base + "/api/media/resolve?token=" + signed, method="GET")
        opener = urllib.request.build_opener(urllib.request.HTTPHandler())
        # Disable redirect following so the response itself can be asserted.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl): return None
        opener = urllib.request.build_opener(NoRedirect)
        try:
            opener.open(req)
        except urllib.error.HTTPError as e:
            self.assertEqual(e.code, 302)
            self.assertEqual(e.headers.get("Location"), "https://media.example.test/movie.mp4")
        tampered = signed[:-1] + ("A" if signed[-1] != "A" else "B")
        bad, _ = self.request("/api/media/resolve?token=" + tampered)
        self.assertEqual(bad, 403)

    def test_playback_reports_actual_expiry_for_each_signed_link(self):
        user = {"id": 991, "username": "expiry", "role": "user", "is_active": True}
        item = {"id": 992, "title": "Expiry metadata", "video_url": "/media/uploads/master.m3u8",
            "quality_options": [{"label": "720p", "url": "https://cdn.example.test/720.m3u8"}],
            "audio_tracks": [{"label": "فارسی", "url": "/media/uploads/audio.m3u8"}],
            "subtitle_tracks": [{"label": "فارسی", "language": "fa", "url": "/media/uploads/subtitle.vtt"}]}
        result = server.playback_payload(user, item, "movie")
        self.assertEqual(result["video_link_expires_in_seconds"], 21600)
        self.assertEqual(result["link_expires_in_seconds"], 21600)
        self.assertEqual(result["quality_options"][0]["link_expires_in_seconds"], 900)
        self.assertEqual(result["audio_tracks"][0]["link_expires_in_seconds"], 21600)
        self.assertEqual(result["subtitle_tracks"][0]["link_expires_in_seconds"], 900)
        self.assertTrue(result["video_url"].startswith("/api/media/resolve?token="))

    def test_playback_tracks_include_signed_urls_and_mime_types(self):
        _, created = self.request("/api/auth/register", "POST", {"username":"tracktestuser", "password":"TrackPassword123!"})
        server.save("movies", [{"id": 78, "title": "Tracks", "is_active": True,
            "video_url": "https://media.example.test/master.m3u8",
            "quality_options": [{"label":"720p", "url":"https://media.example.test/720.m3u8"}],
            "audio_tracks": [{"label":"فارسی", "language":"fa", "url":"https://media.example.test/fa.m3u8"}],
            "subtitle_tracks": [{"label":"English", "language":"en", "url":"https://media.example.test/en.vtt"}]}])
        status, playback = self.request("/api/movies/78/play", token=created["token"])
        self.assertEqual(status, 200)
        self.assertTrue(playback["quality_options"][0]["url"].startswith("/api/media/resolve?token="))
        self.assertEqual(playback["quality_options"][0]["mime_type"], "application/vnd.apple.mpegurl")
        self.assertEqual(playback["audio_tracks"][0]["mime_type"], "application/vnd.apple.mpegurl")
        self.assertTrue(playback["subtitle_tracks"][0]["url"].startswith("/api/media/resolve?token="))
        self.assertNotIn("mime_type", playback["subtitle_tracks"][0])

    def test_hls_playback_declares_manifest_mime_type(self):
        _, created = self.request("/api/auth/register", "POST", {"username":"hlstestuser", "password":"HlsPassword123!"})
        server.save("movies", [{"id": 77, "title": "HLS test", "is_active": True,
            "video_url": "https://media.example.test/master.m3u8?source=cdn"}])
        status, playback = self.request("/api/movies/77/play", token=created["token"])
        self.assertEqual(status, 200)
        self.assertEqual(playback["video_mime_type"], "application/vnd.apple.mpegurl")
        self.assertTrue(playback["video_url"].startswith("/api/media/resolve?token="))

    def test_watch_progress_is_private_and_resumes(self):
        _, a = self.request("/api/auth/register", "POST", {"username":"watchuser", "password":"WatchPassword123!"})
        _, b = self.request("/api/auth/register", "POST", {"username":"watchother", "password":"WatchPassword123!"})
        token_a, token_b = a["token"], b["token"]
        status, _ = self.request("/api/me/watch-progress", "POST", {"type":"movie", "id": 7, "position_seconds": 125}, token_a)
        self.assertEqual(status, 200)
        status, result = self.request("/api/me/watch-progress?type=movie&id=7", token=token_a)
        self.assertEqual(status, 200)
        self.assertEqual(result["position_seconds"], 125)
        server.save("movies", [{"id": 7, "title": "Resume Test", "is_active": True, "video_url": "https://media.example.test/resume.mp4"}])
        play_status, play_data = self.request("/api/movies/7/play", token=token_a)
        self.assertEqual(play_status, 200)
        self.assertEqual(play_data["resume_position"], 125)
        _, other = self.request("/api/me/watch-progress?type=movie&id=7", token=token_b)
        self.assertEqual(other["position_seconds"], 0)
        bad, _ = self.request("/api/me/watch-progress", "POST", {"type":"movie", "id":7, "position_seconds":-1}, token_a)
        self.assertEqual(bad, 400)

    def test_continue_watching_list_is_enriched_private_and_clearable(self):
        _, a = self.request("/api/auth/register", "POST", {"username":"shelfuser", "password":"ShelfPassword123!"})
        _, b = self.request("/api/auth/register", "POST", {"username":"shelfother", "password":"ShelfPassword123!"})
        token_a, token_b = a["token"], b["token"]
        server.save("movies", [
            {"id": 81, "title": "فیلم آزمایشی", "poster_url": "https://img.example.test/p.jpg", "duration": 3600, "is_active": True},
            {"id": 82, "title": "فیلم تمام‌شده", "poster_url": "https://img.example.test/done.jpg", "duration": 3600, "is_active": True},
        ])
        server.save("series", [{"id": 91, "title": "سریال آزمایشی", "poster_url": "https://img.example.test/s.jpg", "is_active": True}])
        server.save("seasons", [{"id": 92, "series_id": 91, "season_number": 1}])
        server.save("episodes", [{"id": 93, "season_id": 92, "title": "قسمت اول", "duration": 1800, "is_active": True}])
        self.assertEqual(self.request("/api/me/watch-progress", "POST", {"type":"movie", "id":81, "position_seconds":900}, token_a)[0], 200)
        self.assertEqual(self.request("/api/me/watch-progress", "POST", {"type":"movie", "id":82, "position_seconds":3550}, token_a)[0], 200)
        self.assertEqual(self.request("/api/me/watch-progress", "POST", {"type":"episode", "id":93, "position_seconds":450}, token_a)[0], 200)
        status, shelf = self.request("/api/me/watch-progress", token=token_a)
        self.assertEqual(status, 200)
        self.assertEqual(len(shelf), 2)
        self.assertNotIn(82, [x["id"] for x in shelf])
        movie = next(x for x in shelf if x["type"] == "movie")
        episode = next(x for x in shelf if x["type"] == "episode")
        self.assertEqual(movie["title"], "فیلم آزمایشی")
        self.assertEqual(movie["poster_url"], "https://img.example.test/p.jpg")
        self.assertEqual(episode["series_title"], "سریال آزمایشی")
        self.assertEqual(episode["series_id"], 91)
        self.assertEqual(self.request("/api/me/watch-progress", token=token_b)[1], [])
        self.assertEqual(self.request("/api/me/watch-progress", "POST", {"action":"remove", "type":"movie", "id":81}, token_a)[0], 200)
        self.assertEqual(len(self.request("/api/me/watch-progress", token=token_a)[1]), 1)
        self.assertEqual(self.request("/api/me/watch-progress", "POST", {"action":"clear"}, token_a)[0], 200)
        self.assertEqual(self.request("/api/me/watch-progress", token=token_a)[1], [])

    def test_support_ticket_is_private_to_owner(self):
        code, data = self.request("/api/auth/register", "POST", {
            "username": "owneruser", "password": "OwnerPassword123!"
        })
        self.assertEqual(code, 201)
        token = data["token"]
        code, ticket = self.request("/api/me/support/tickets", "POST", {
            "subject": "مشکل پخش فیلم", "category": "playback", "message": "فیلم برای من پخش نمی‌شود"
        }, token)
        self.assertEqual(code, 201)
        self.assertEqual(self.request(f"/api/me/support/tickets/{ticket['ticket_id']}", token=token)[0], 200)
        other_code, other = self.request("/api/auth/register", "POST", {
            "username": "otheruser", "password": "OtherPassword123!"
        })
        self.assertEqual(other_code, 201)
        self.assertEqual(self.request(f"/api/me/support/tickets/{ticket['ticket_id']}", token=other["token"])[0], 404)

    def test_admin_can_reply_to_ticket_and_update_status(self):
        code, user_data = self.request("/api/auth/register", "POST", {
            "username": "ticketuser", "password": "TicketPassword123!"
        })
        self.assertEqual(code, 201)
        _, ticket = self.request("/api/me/support/tickets", "POST", {
            "subject": "درخواست پشتیبانی", "category": "account", "message": "لطفاً راهنمایی کنید"
        }, user_data["token"])
        users = server.load("users")
        admin = {"id": 999, "username": "testadmin", "password": server.hash_password("AdminPassword123!"),
                 "role": "admin", "is_active": True}
        users.append(admin); server.save("users", users)
        admin_token = server.create_session_token(admin)
        self.assertEqual(self.request("/api/admin/support/tickets", token=admin_token)[0], 200)
        self.assertEqual(self.request(f"/api/admin/support/tickets/{ticket['ticket_id']}", token=admin_token)[0], 200)
        reply_code, _ = self.request(f"/api/admin/support/tickets/{ticket['ticket_id']}/messages", "POST",
                                     {"message": "پاسخ پشتیبانی"}, admin_token)
        self.assertEqual(reply_code, 201)
        patch_code, _ = self.request(f"/api/admin/support/tickets/{ticket['ticket_id']}", "PATCH",
                                     {"status": "closed"}, admin_token)
        self.assertEqual(patch_code, 200)

    def test_content_report_and_admin_status(self):
        code, user_data = self.request("/api/auth/register", "POST", {
            "username": "reportuser", "password": "ReportPassword123!"
        })
        self.assertEqual(code, 201)
        server.save("movies", [{"id": 1, "title": "Sample", "is_active": True}])
        report_code, report = self.request("/api/reports", "POST", {
            "content_type": "movie", "content_id": 1, "category": "broken_link", "description": "لینک باز نمی‌شود"
        }, user_data["token"])
        self.assertEqual(report_code, 201)
        users = server.load("users")
        admin = {"id": 2000, "username": "reportadmin", "password": server.hash_password("AdminPassword123!"),
                 "role": "admin", "is_active": True}
        users.append(admin); server.save("users", users)
        admin_token = server.create_session_token(admin)
        self.assertEqual(self.request("/api/admin/reports", token=admin_token)[0], 200)
        patch_code, _ = self.request(f"/api/admin/reports/{report['report_id']}", "PATCH",
                                     {"status": "resolved"}, admin_token)
        self.assertEqual(patch_code, 200)

    def test_subscription_trial_and_automatic_plan_prices(self):
        server.save("app_settings", [{"subscriptions_enabled": True, "monthly_price": 100000,
                                      "quarterly_discount": 10, "semiannual_discount": 20}])
        plans = server.subscription_plans()
        self.assertEqual([p["price"] for p in plans], [100000, 270000, 480000])
        code, user_data = self.request("/api/auth/register", "POST", {
            "username": "trialuser31", "password": "TrialUserPass123!"
        })
        self.assertEqual(code, 201)
        status, sub = self.request("/api/subscription/me", token=user_data["token"])
        self.assertEqual(status, 200)
        self.assertTrue(sub["hasAccess"])
        self.assertEqual(sub["type"], "free_trial")
        server.save("app_settings", [])

    def test_free_launch_mode(self):
        code, user_data = self.request("/api/auth/register", "POST", {
            "username": "freeviewer", "password": "FreeViewerPass123!"
        })
        self.assertEqual(code, 201)
        status, sub = self.request("/api/subscription/me", token=user_data["token"])
        self.assertEqual(status, 200)
        self.assertTrue(sub["hasAccess"])
        self.assertEqual(sub["type"], "free")
        self.assertEqual(self.request("/api/subscription/plans")[1], [])
        pay_code, _ = self.request("/api/subscription/pay", "POST", {"plan_id": 1}, user_data["token"])
        self.assertEqual(pay_code, 403)


    def test_admin_user_management_and_audit_log(self):
        # Isolate the account set so the last-admin safeguard is deterministic.
        _, created = self.request("/api/auth/register", "POST", {
            "username": "manageduser", "password": "ManagedUserPass123!"
        })
        user_token = created["token"]
        users = server.load("users")
        admin = {"id": 8001, "username": "auditadmin", "password": server.hash_password("AuditAdminPass123!"),
                 "role": "admin", "is_active": True}
        users.append(admin)
        server.save("users", users)
        admin_token = server.create_session_token(admin)

        status, listed = self.request("/api/admin/users", token=admin_token)
        self.assertEqual(status, 200)
        target = next(x for x in listed if x["username"] == "manageduser")
        self.assertNotIn("password", target)

        status, _ = self.request(f"/api/admin/users/{target['id']}", "PATCH", {"is_active": False}, admin_token)
        self.assertEqual(status, 200)
        self.assertEqual(self.request("/api/auth/me", token=user_token)[0], 401)

        # Reactivation is permitted and is also audited.
        status, _ = self.request(f"/api/admin/users/{target['id']}", "PATCH", {"is_active": True}, admin_token)
        self.assertEqual(status, 200)
        status, logs = self.request("/api/admin/audit-logs?limit=20", token=admin_token)
        self.assertEqual(status, 200)
        actions = [x["action"] for x in logs]
        self.assertIn("user_blocked", actions)
        self.assertIn("user_activated", actions)

        # An admin cannot disable the only remaining admin or themselves.
        self.assertEqual(self.request(f"/api/admin/users/{admin['id']}", "PATCH", {"is_active": False}, admin_token)[0], 400)
        self.assertEqual(self.request("/api/admin/audit-logs", token=user_token)[0], 403)

    def test_admin_can_edit_season_and_duplicate_number_is_rejected(self):
        admin = {"id": 9101, "username": "seasonadmin", "role": "admin", "is_active": True,
                 "password_hash": server.hash_password("SeasonAdminPass123!")}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        server.save("series", [{"id": 301, "title": "سریال آزمایشی", "is_active": True}])
        server.save("seasons", [
            {"id": 401, "series_id": 301, "season_number": 1, "title": "فصل اول"},
            {"id": 402, "series_id": 301, "season_number": 2, "title": "فصل دوم"},
        ])
        status, result = self.request("/api/admin/seasons/402", "PATCH", {"season_number": 3, "title": "فصل سوم"}, token)
        self.assertEqual(status, 200)
        self.assertEqual(result["season"]["season_number"], 3)
        self.assertEqual(result["season"]["title"], "فصل سوم")
        status, _ = self.request("/api/admin/seasons/402", "PATCH", {"season_number": 1}, token)
        self.assertEqual(status, 409)
        status, _ = self.request("/api/admin/seasons/402", "PATCH", {"season_number": True}, token)
        self.assertEqual(status, 400)

    def test_admin_content_edit_and_validation(self):
        admin = {"id": 9001, "username": "contentadmin", "role": "admin", "is_active": True,
                 "password_hash": server.hash_password("StrongAdminPassword123!")}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        server.save("movies", [{"id": 1, "title": "Old title", "description": "old", "poster_url": "",
                                 "video_url": "https://media.example/old.mp4", "is_active": True,
                                 "audio_tracks": [], "subtitle_tracks": [], "quality_options": []}])
        status, updated = self.request("/api/admin/movies/1", "PATCH", {
            "title": "New title", "video_url": "https://media.example/new.mp4",
            "quality_options": [{"label": "1080p", "url": "https://media.example/1080.mp4"}],
            "audio_tracks": [{"label": "دوبله فارسی", "language": "fa"}],
            "content_rating": "۱۲+"
        }, token)
        self.assertEqual(status, 200)
        self.assertEqual(updated["item"]["title"], "New title")
        self.assertEqual(updated["item"]["quality_options"][0]["label"], "1080p")
        self.assertEqual(self.request("/api/admin/movies/1", "PATCH", {"video_url": "http://unsafe.example/x.mp4"}, token)[0], 400)
        self.assertEqual(self.request("/api/admin/movies/1", "PATCH", {"password_hash": "oops"}, token)[0], 400)
        status, logs = self.request("/api/admin/audit-logs?limit=20", token=token)
        self.assertEqual(status, 200)
        self.assertTrue(any(x["action"] == "movie_updated" for x in logs))

    def test_admin_content_edit_accepts_existing_uploaded_media_only(self):
        import shutil
        temp_uploads = Path(server.DATA_DIR).parent / "static" / "uploads"
        temp_uploads.mkdir(parents=True, exist_ok=True)
        previous_upload_dir = server.UPLOAD_DIR
        server.UPLOAD_DIR = temp_uploads
        try:
            (temp_uploads / "poster_test.webp").write_bytes(b"poster")
            admin = {"id": 9055, "username": "mediaeditor", "role": "admin", "is_active": True}
            server.save("users", server.load("users") + [admin])
            token = server.create_session_token(admin)
            server.save("movies", [{"id": 955, "title": "Uploaded movie", "is_active": True,
                                     "video_url": "https://media.example/old.mp4"}])
            status, updated = self.request("/api/admin/movies/955", "PATCH", {
                "poster_url": "/media/uploads/poster_test.webp",
                "video_url": "/media/uploads/movie_test.mp4"
            }, token)
            self.assertEqual(status, 400)  # video file does not exist
            (temp_uploads / "movie_test.mp4").write_bytes(b"video")
            status, updated = self.request("/api/admin/movies/955", "PATCH", {
                "poster_url": "/media/uploads/poster_test.webp",
                "video_url": "/media/uploads/movie_test.mp4"
            }, token)
            self.assertEqual(status, 200)
            self.assertEqual(updated["item"]["poster_url"], "/media/uploads/poster_test.webp")
            self.assertEqual(updated["item"]["video_url"], "/media/uploads/movie_test.mp4")
            self.assertEqual(self.request("/api/admin/movies/955", "PATCH", {
                "video_url": "/media/uploads/../secrets.mp4"
            }, token)[0], 400)
            self.assertEqual(self.request("/api/admin/movies/955", "PATCH", {
                "poster_url": "/media/uploads/subdir/poster.webp"
            }, token)[0], 400)
        finally:
            server.UPLOAD_DIR = previous_upload_dir
            shutil.rmtree(temp_uploads, ignore_errors=True)

    def test_static_path_traversal_is_blocked(self):
        status, _ = self.request("/static/../../README.md")
        self.assertIn(status, (403, 404))

    def test_admin_chunked_media_upload_and_public_media_read(self):
        from urllib.request import Request, urlopen
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admin = {"id": 7001, "username": "uploadadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        status, init = self.request("/api/admin/uploads/init", "POST", {
            "name": "sample.mp4", "size": 8, "kind": "video"
        }, token)
        self.assertEqual(status, 201)
        chunk = b"MP4TEST!"
        import hashlib
        req = Request(self.base + "/api/admin/uploads/" + init["upload_id"] + "/chunk", data=chunk,
                      headers={"Authorization": "Bearer " + token, "Content-Type": "application/octet-stream",
                               "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(chunk).hexdigest()}, method="POST")
        with urlopen(req) as response:
            self.assertEqual(response.status, 200)
        resumed_status, upload_state = self.request("/api/admin/uploads/" + init["upload_id"] + "/status", token=token)
        self.assertEqual(resumed_status, 200)
        self.assertEqual(upload_state["received"], [0])
        self.assertEqual(upload_state["chunk_hashes"]["0"], hashlib.sha256(chunk).hexdigest())
        status, completed = self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, token)
        self.assertEqual(status, 201)
        self.assertEqual(completed["sha256"], hashlib.sha256(chunk).hexdigest())
        with self.assertRaises(urllib.error.HTTPError) as denied:
            urlopen(self.base + completed["url"])
        self.assertEqual(denied.exception.code, 403)
        playback = server.playback_payload(admin, {"id": 88, "video_url": completed["url"]}, "movie")
        with urlopen(self.base + playback["video_url"]) as response:
            self.assertEqual(response.read(), chunk)
        range_req = Request(self.base + playback["video_url"], headers={"Range": "bytes=2-4"})
        with urlopen(range_req) as response:
            self.assertEqual(response.status, 206)
            self.assertEqual(response.read(), chunk[2:5])
        self.assertEqual(self.request("/api/admin/uploads/init", "POST", {
            "name": "bad.exe", "size": 10, "kind": "video"
        }, token)[0], 400)


    def test_hls_zip_bundle_upload_rewrites_manifest_and_protects_segments(self):
        import hashlib
        import io
        import shutil
        import zipfile
        from urllib.request import Request, urlopen
        previous_upload_dir, previous_upload_tmp = server.UPLOAD_DIR, server.UPLOAD_TMP
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        server.UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        admin = {"id": 8123, "username": "hlspackadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("master.m3u8", "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000\nvideo/720p.m3u8\n")
            archive.writestr("video/720p.m3u8", '#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXT-X-KEY:METHOD=AES-128,URI="../keys/key.key"\n#EXTINF:4.0,\nseg001.ts\n#EXT-X-ENDLIST\n')
            archive.writestr("video/seg001.ts", b"TEST-TS-SEGMENT")
            archive.writestr("keys/key.key", b"0123456789abcdef")
        payload = bundle.getvalue()
        try:
            status, init = self.request("/api/admin/uploads/init", "POST", {
                "name": "film-hls.zip", "size": len(payload), "kind": "hls_bundle"
            }, token)
            self.assertEqual(status, 201)
            req = Request(self.base + "/api/admin/uploads/" + init["upload_id"] + "/chunk", data=payload,
                headers={"Authorization": "Bearer " + token, "Content-Type": "application/octet-stream",
                         "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(payload).hexdigest()}, method="POST")
            with urlopen(req) as response:
                self.assertEqual(response.status, 200)
            status, completed = self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, token)
            self.assertEqual(status, 201)
            self.assertTrue(completed["url"].endswith("/master.m3u8"))
            playback = server.playback_payload(admin, {"id": 901, "title": "HLS", "video_url": completed["url"]}, "movie")
            self.assertEqual(playback["video_mime_type"], "application/vnd.apple.mpegurl")
            self.assertTrue(playback["video_url"].startswith("/api/media/resolve?token="))
            with urlopen(self.base + playback["video_url"]) as response:
                self.assertIn("application/vnd.apple.mpegurl", response.headers.get("Content-Type", ""))
                master_text = response.read().decode()
            self.assertIn("/api/media/resolve?token=", master_text)
            variant_url = next(line for line in master_text.splitlines() if line.startswith("/api/media/resolve"))
            with urlopen(self.base + variant_url) as response:
                variant_text = response.read().decode()
            self.assertIn('URI="/api/media/resolve?token=', variant_text)
            segment_url = next(line for line in variant_text.splitlines() if line.startswith("/api/media/resolve"))
            with urlopen(self.base + segment_url) as response:
                self.assertEqual(response.read(), b"TEST-TS-SEGMENT")
            with self.assertRaises(urllib.error.HTTPError) as denied:
                urlopen(self.base + completed["url"].replace("/master.m3u8", "/video/seg001.ts"))
            self.assertEqual(denied.exception.code, 403)
            with self.assertRaises(urllib.error.HTTPError) as manifest_denied:
                urlopen(self.base + completed["url"])
            self.assertEqual(manifest_denied.exception.code, 403)
            subtitle_path = Path(server.UPLOAD_DIR) / "sample.vtt"
            subtitle_path.write_text("WEBVTT\n\n00:00:00.000 --> 00:00:01.000\nTest\n", encoding="utf-8")
            subtitle_url = "/media/uploads/sample.vtt"
            with self.assertRaises(urllib.error.HTTPError) as subtitle_denied:
                urlopen(self.base + subtitle_url)
            self.assertEqual(subtitle_denied.exception.code, 403)
            subtitle_signed = server.signed_media_url(admin, subtitle_url)
            with urlopen(self.base + subtitle_signed) as response:
                self.assertIn("text/vtt", response.headers.get("Content-Type", ""))
                self.assertTrue(response.read().startswith(b"WEBVTT"))
        finally:
            server.UPLOAD_DIR, server.UPLOAD_TMP = previous_upload_dir, previous_upload_tmp
            shutil.rmtree(Path(server.DATA_DIR).parent / "static", ignore_errors=True)
            shutil.rmtree(Path(server.DATA_DIR) / "upload_chunks", ignore_errors=True)

    def test_hls_bundle_rejects_zip_path_traversal(self):
        import hashlib
        import io
        import zipfile
        from urllib.request import Request, urlopen
        previous_upload_dir, previous_upload_tmp = server.UPLOAD_DIR, server.UPLOAD_TMP
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admin = {"id": 8124, "username": "hlsbadadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w") as archive:
            archive.writestr("../escape.ts", b"bad")
            archive.writestr("master.m3u8", "#EXTM3U\nseg.ts\n")
        payload = bundle.getvalue()
        try:
            status, init = self.request("/api/admin/uploads/init", "POST", {
                "name": "bad-hls.zip", "size": len(payload), "kind": "hls_bundle"
            }, token)
            self.assertEqual(status, 201)
            req = Request(self.base + "/api/admin/uploads/" + init["upload_id"] + "/chunk", data=payload,
                headers={"Authorization": "Bearer " + token, "Content-Type": "application/octet-stream",
                         "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(payload).hexdigest()}, method="POST")
            with urlopen(req): pass
            status, result = self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, token)
            self.assertEqual(status, 400)
            self.assertIn("ناامن", result["error"])
        finally:
            server.UPLOAD_DIR, server.UPLOAD_TMP = previous_upload_dir, previous_upload_tmp

    def test_upload_chunks_require_owner_exact_size_and_checksum(self):
        import hashlib
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admins = [
            {"id": 7101, "username": "owneradmin", "role": "admin", "is_active": True},
            {"id": 7102, "username": "otheradmin", "role": "admin", "is_active": True},
        ]
        server.save("users", server.load("users") + admins)
        owner_token = server.create_session_token(admins[0])
        other_token = server.create_session_token(admins[1])
        status, init = self.request("/api/admin/uploads/init", "POST", {
            "name": "owner.mp4", "size": 8, "kind": "video"
        }, owner_token)
        self.assertEqual(status, 201)
        upload_path = "/api/admin/uploads/" + init["upload_id"]
        self.assertEqual(self.request(upload_path + "/status", token=other_token)[0], 404)
        self.assertEqual(self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, other_token)[0], 404)
        payload = b"12345678"
        wrong_hash_req = urllib.request.Request(self.base + upload_path + "/chunk", data=payload,
            headers={"Authorization": "Bearer " + owner_token, "Content-Type": "application/octet-stream",
                     "X-Chunk-Index": "0", "X-Chunk-SHA256": "0" * 64}, method="POST")
        with self.assertRaises(urllib.error.HTTPError) as bad_hash:
            urllib.request.urlopen(wrong_hash_req)
        self.assertEqual(bad_hash.exception.code, 400)
        wrong_size_req = urllib.request.Request(self.base + upload_path + "/chunk", data=b"1234567",
            headers={"Authorization": "Bearer " + owner_token, "Content-Type": "application/octet-stream",
                     "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(b"1234567").hexdigest()}, method="POST")
        with self.assertRaises(urllib.error.HTTPError) as bad_size:
            urllib.request.urlopen(wrong_size_req)
        self.assertEqual(bad_size.exception.code, 400)
        good_req = urllib.request.Request(self.base + upload_path + "/chunk", data=payload,
            headers={"Authorization": "Bearer " + owner_token, "Content-Type": "application/octet-stream",
                     "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(payload).hexdigest()}, method="POST")
        with urllib.request.urlopen(good_req) as response:
            self.assertEqual(response.status, 200)
        self.assertEqual(self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, owner_token)[0], 201)

    def test_upload_finalize_rejects_chunk_changed_after_receipt(self):
        import hashlib
        import shutil
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admin = {"id": 7121, "username": "integrityadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        status, init = self.request("/api/admin/uploads/init", "POST", {
            "name": "integrity.mp4", "size": 8, "kind": "video"
        }, token)
        self.assertEqual(status, 201)
        upload_path = "/api/admin/uploads/" + init["upload_id"]
        payload = b"12345678"
        req = urllib.request.Request(self.base + upload_path + "/chunk", data=payload,
            headers={"Authorization": "Bearer " + token, "Content-Type": "application/octet-stream",
                     "X-Chunk-Index": "0", "X-Chunk-SHA256": hashlib.sha256(payload).hexdigest()}, method="POST")
        with urllib.request.urlopen(req) as response:
            self.assertEqual(response.status, 200)
        part = server.UPLOAD_TMP / init["upload_id"] / "00000000.part"
        part.write_bytes(b"87654321")
        status, state = self.request(upload_path + "/status", token=token)
        self.assertEqual(status, 200)
        self.assertEqual(state["received"], [])
        status, result = self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, token)
        self.assertEqual(status, 409)
        self.assertEqual(result["corrupt_chunk"], 0)
        shutil.rmtree(server.UPLOAD_TMP / init["upload_id"], ignore_errors=True)

    def test_upload_chunk_accepts_server_computed_hash_for_mobile_http_origins(self):
        import hashlib
        admins = [{"id": 7111, "username": "mobileadmin", "role": "admin", "is_active": True}]
        server.save("users", server.load("users") + admins)
        token = server.create_session_token(admins[0])
        status, init = self.request("/api/admin/uploads/init", "POST", {
            "name": "mobile.mp4", "size": 8, "kind": "video"
        }, token)
        self.assertEqual(status, 201)
        upload_path = "/api/admin/uploads/" + init["upload_id"]
        req = urllib.request.Request(self.base + upload_path + "/chunk", data=b"12345678",
            headers={"Authorization": "Bearer " + token, "Content-Type": "application/octet-stream",
                     "X-Chunk-Index": "0"}, method="POST")
        with urllib.request.urlopen(req) as response:
            self.assertEqual(response.status, 200)
            self.assertEqual(json.loads(response.read())["sha256"], hashlib.sha256(b"12345678").hexdigest())
        self.assertEqual(self.request("/api/admin/uploads/finalize", "POST", {"upload_id": init["upload_id"]}, token)[0], 201)


    def test_upload_status_returns_server_chunk_policy_for_resume(self):
        import shutil
        previous_upload_dir, previous_upload_tmp = server.UPLOAD_DIR, server.UPLOAD_TMP
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admin = {"id": 7131, "username": "resumeadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        try:
            status, init = self.request("/api/admin/uploads/init", "POST", {
                "name": "resume.mp4", "size": 8, "kind": "video"
            }, token)
            self.assertEqual(status, 201)
            status, state = self.request("/api/admin/uploads/" + init["upload_id"] + "/status", token=token)
            self.assertEqual(status, 200)
            self.assertEqual(state["chunk_size"], server.UPLOAD_CHUNK_SIZE)
            self.assertEqual(state["max_upload_size"], server.MAX_UPLOAD_SIZE)
            self.assertGreater(state["expires_in_seconds"], 0)
            self.assertEqual(state["received"], [])
        finally:
            server.UPLOAD_DIR, server.UPLOAD_TMP = previous_upload_dir, previous_upload_tmp
            shutil.rmtree(Path(server.DATA_DIR) / "upload_chunks", ignore_errors=True)

    def test_upload_status_reports_corrupt_metadata_as_conflict(self):
        import shutil
        previous_upload_dir, previous_upload_tmp = server.UPLOAD_DIR, server.UPLOAD_TMP
        server.UPLOAD_DIR = Path(server.DATA_DIR).parent / "static" / "uploads"
        server.UPLOAD_TMP = Path(server.DATA_DIR) / "upload_chunks"
        admin = {"id": 7132, "username": "badmetaadmin", "role": "admin", "is_active": True}
        server.save("users", server.load("users") + [admin])
        token = server.create_session_token(admin)
        try:
            status, init = self.request("/api/admin/uploads/init", "POST", {
                "name": "badmeta.mp4", "size": 8, "kind": "video"
            }, token)
            self.assertEqual(status, 201)
            meta_path = server.UPLOAD_TMP / init["upload_id"] / "meta.json"
            meta_path.write_text("{broken json")
            status, result = self.request("/api/admin/uploads/" + init["upload_id"] + "/status", token=token)
            self.assertEqual(status, 409)
            self.assertIn("فراداده", result["error"])
        finally:
            server.UPLOAD_DIR, server.UPLOAD_TMP = previous_upload_dir, previous_upload_tmp
            shutil.rmtree(Path(server.DATA_DIR) / "upload_chunks", ignore_errors=True)

if __name__ == "__main__":
    unittest.main()
