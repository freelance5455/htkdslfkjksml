#!/usr/bin/env python3
"""Create or rotate the local development administrator without a default password."""
import getpass
import re
import sys
import base64, hashlib, secrets
from storage import load, save, initialize

initialize()

def hash_password(password):
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    enc = lambda b: base64.urlsafe_b64encode(b).decode().rstrip("=")
    return f"pbkdf2_sha256$310000${enc(salt)}${enc(digest)}"

username = input("Admin username [admin]: ").strip() or "admin"
if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username):
    print("Username must be 3-24 characters: letters, numbers, underscore.")
    sys.exit(1)
p1 = getpass.getpass("New admin password (minimum 12 characters): ")
p2 = getpass.getpass("Repeat password: ")
if len(p1) < 12 or len(p1) > 128 or p1 != p2:
    print("Password mismatch or invalid length.")
    sys.exit(1)
users = load("users")
existing = next((u for u in users if u.get("role") == "admin"), None)
if existing:
    existing["username"] = username
    existing["password"] = hash_password(p1)
    existing["is_active"] = True
    admin_id = existing["id"]
else:
    admin_id = max((u.get("id", 0) for u in users), default=0) + 1
    users.append({"id": admin_id, "username": username, "password": hash_password(p1),
                  "role": "admin", "is_active": True, "free_trial_started_at": None,
                  "free_trial_ends_at": None})
save("users", users)
# Revoke all previous admin sessions after password rotation.
sessions = load("sessions")
for sess in sessions:
    if sess.get("user_id") == admin_id:
        sess["revoked_at"] = "password-rotated"
save("sessions", sessions)
print(f"Administrator '{username}' is ready. Password is not displayed or stored in plaintext.")
