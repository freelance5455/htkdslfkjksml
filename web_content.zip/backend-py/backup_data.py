#!/usr/bin/env python3
"""Create and verify integrity-checked local backups of CINEMA GOLD JSON data."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from zipfile import ZIP_DEFLATED, BadZipFile, ZipFile

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
BACKUPS = HERE / "backups"
MANIFEST = "backup-manifest.json"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def build_backup(data_dir: Path, output: Path) -> Path:
    data_dir = data_dir.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in data_dir.glob("*.json") if p.is_file())
    if not files:
        raise ValueError(f"No JSON data files found in {data_dir}")

    payloads = {}
    for path in files:
        name = path.name
        if name in (".local_jwt_secret", "admin_credentials.json"):
            continue
        payloads[f"data/{name}"] = path.read_bytes()
    if not payloads:
        raise ValueError("No eligible data files found")

    manifest = {
        "format": "cinema-gold-json-backup-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "files": [{"path": name, "size": len(data), "sha256": sha256(data)}
                  for name, data in sorted(payloads.items())],
    }
    fd, temp_name = tempfile.mkstemp(prefix=output.name + ".", suffix=".tmp", dir=output.parent)
    os.close(fd)
    temp_path = Path(temp_name)
    try:
        with ZipFile(temp_path, "w", ZIP_DEFLATED) as archive:
            for name, data in sorted(payloads.items()):
                archive.writestr(name, data)
            archive.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
        verify_backup(temp_path)
        os.replace(temp_path, output)
    finally:
        temp_path.unlink(missing_ok=True)
    return output


def verify_backup(archive_path: Path) -> dict:
    try:
        with ZipFile(archive_path, "r") as archive:
            bad_member = archive.testzip()
            if bad_member:
                raise ValueError(f"Corrupt ZIP member: {bad_member}")
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise ValueError("Duplicate archive paths are not allowed")
            for name in names:
                member = PurePosixPath(name)
                if member.is_absolute() or ".." in member.parts or not name.startswith("data/") and name != MANIFEST:
                    raise ValueError(f"Unsafe archive path: {name}")
            if MANIFEST not in names:
                raise ValueError("Backup manifest is missing")
            manifest = json.loads(archive.read(MANIFEST).decode("utf-8"))
            if manifest.get("format") != "cinema-gold-json-backup-v1":
                raise ValueError("Unsupported backup format")
            expected = manifest.get("files")
            if not isinstance(expected, list) or not expected:
                raise ValueError("Backup manifest contains no files")
            expected_names = set()
            for entry in expected:
                name = entry.get("path")
                if not isinstance(name, str) or name not in names or name == MANIFEST or not name.startswith("data/"):
                    raise ValueError("Manifest references an invalid or missing file")
                if name in expected_names:
                    raise ValueError("Manifest contains duplicate file entries")
                expected_names.add(name)
                data = archive.read(name)
                if len(data) != entry.get("size") or sha256(data) != entry.get("sha256"):
                    raise ValueError(f"Integrity check failed: {name}")
            actual_names = set(names) - {MANIFEST}
            if actual_names != expected_names:
                raise ValueError("Archive files do not match manifest")
            return {"created_at": manifest.get("created_at"), "files_checked": len(expected_names), "valid": True}
    except (BadZipFile, json.JSONDecodeError, KeyError, TypeError) as exc:
        raise ValueError(f"Invalid backup archive: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify", type=Path, help="Verify an existing backup ZIP")
    parser.add_argument("--output", type=Path, help="Output ZIP path for a new backup")
    args = parser.parse_args()
    if args.verify:
        result = verify_backup(args.verify)
        print(f"Backup valid: {result['files_checked']} files; created {result['created_at']}")
        return 0
    BACKUPS.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-UTC")
    output = args.output or (BACKUPS / f"cinema-gold-data-{stamp}.zip")
    result = build_backup(DATA, output)
    print(f"Backup created and verified: {result}")
    print("Copy it to storage outside the server. It may contain personal data.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
