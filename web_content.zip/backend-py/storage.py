"""Storage adapter for CINEMA GOLD.

JSON remains the zero-dependency local default. PostgreSQL mode stores each
record as JSONB in a collection table, keeping the current API contract intact.
"""
import json
import os
import threading
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
BACKEND = os.environ.get("DB_BACKEND", "json").strip().lower()
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
_LOCK = threading.RLock()
_ALLOWED = {
    "admin_audit_logs", "comments", "content_reports", "downloads", "episodes", "movies",
    "payments", "plans", "ratings", "seasons", "series", "sessions",
    "subscriptions", "support_messages", "support_tickets", "users", "watch_progress", "app_settings",
}


def _pg_connect():
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is required when DB_BACKEND=postgres")
    try:
        import psycopg
    except ImportError as exc:
        raise RuntimeError("Install PostgreSQL dependencies: pip install -r requirements.txt") from exc
    return psycopg.connect(DATABASE_URL)


def initialize():
    if BACKEND == "json":
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        return
    if BACKEND != "postgres":
        raise RuntimeError("DB_BACKEND must be 'json' or 'postgres'")
    with _pg_connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS cinema_records (
                collection TEXT NOT NULL,
                record_key TEXT NOT NULL,
                payload JSONB NOT NULL,
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                PRIMARY KEY (collection, record_key)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS cinema_records_collection_idx ON cinema_records(collection)")


def load(name):
    if name not in _ALLOWED:
        raise ValueError("Unknown data collection")
    if BACKEND == "postgres":
        with _pg_connect() as conn:
            rows = conn.execute(
                "SELECT payload FROM cinema_records WHERE collection = %s ORDER BY record_key",
                (name,),
            ).fetchall()
        return [row[0] for row in rows]
    p = DATA_DIR / f"{name}.json"
    if not p.exists():
        return []
    with _LOCK:
        try:
            with p.open("r", encoding="utf-8") as f:
                value = json.load(f)
            return value if isinstance(value, list) else []
        except (json.JSONDecodeError, OSError):
            raise RuntimeError(f"Data file is unreadable: {p.name}; restore from backup before continuing")


def save(name, data):
    if name not in _ALLOWED:
        raise ValueError("Unknown data collection")
    if not isinstance(data, list):
        raise TypeError("Collection data must be a list")
    if BACKEND == "postgres":
        # One transaction makes a collection replacement atomic. The current
        # HTTP server intentionally remains single-process while API mutations
        # are being converted to row-level transactions.
        with _pg_connect() as conn:
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("cinema:" + name,))
            conn.execute("DELETE FROM cinema_records WHERE collection = %s", (name,))
            for index, item in enumerate(data):
                if not isinstance(item, dict):
                    raise TypeError("Every collection item must be an object")
                key = str(item.get("id", item.get("username", index)))
                conn.execute(
                    "INSERT INTO cinema_records(collection, record_key, payload) VALUES (%s, %s, %s::jsonb)",
                    (name, key, json.dumps(item, ensure_ascii=False)),
                )
        return
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    p = DATA_DIR / f"{name}.json"
    with _LOCK:
        tmp = p.with_suffix(p.suffix + ".tmp")
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, p)


def backend_name():
    return BACKEND
