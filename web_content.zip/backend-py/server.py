#!/usr/bin/env python3
"""CINEMA GOLD API v3.7.34 — local development backend."""
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, urlsplit, unquote
import json, os, hashlib, hmac, time, base64, secrets, re, uuid, threading, zipfile, stat
from datetime import datetime, timedelta, timezone
from pathlib import Path

PORT = int(os.environ.get("PORT", 3000))
DATA_DIR = Path(__file__).parent / "data"
from storage import load, save, initialize as initialize_storage, backend_name
JWT_SECRET = os.environ.get("JWT_SECRET", "")
APP_ENV = os.environ.get("APP_ENV", "production")
FREE_TRIAL_DAYS = 3
SUBSCRIPTIONS_ENABLED = os.environ.get("SUBSCRIPTIONS_ENABLED", "true").lower() == "true"

def subscription_settings():
    rows = load("app_settings")
    cfg = rows[0] if rows else {}
    return {"subscriptions_enabled": cfg.get("subscriptions_enabled", SUBSCRIPTIONS_ENABLED),
            "free_trial_days": 3, "monthly_price": cfg.get("monthly_price", 99000),
            "quarterly_discount": cfg.get("quarterly_discount", 10),
            "semiannual_discount": cfg.get("semiannual_discount", 20)}

def subscription_plans():
    cfg = subscription_settings(); monthly = int(cfg["monthly_price"])
    q = round(monthly * 3 * (100-int(cfg["quarterly_discount"])) / 100)
    h = round(monthly * 6 * (100-int(cfg["semiannual_discount"])) / 100)
    return [{"id":1,"name":"ماهانه","name_en":"monthly","duration_days":30,"price":monthly,"is_active":True},
            {"id":2,"name":"سه‌ماهه","name_en":"quarterly","duration_days":90,"price":q,"is_active":True},
            {"id":3,"name":"شش‌ماهه","name_en":"semi_annual","duration_days":180,"price":h,"is_active":True}]
PBKDF2_ITERATIONS = 310_000
LOGIN_ATTEMPTS = {}
UPLOAD_DIR = DATA_DIR.parent / "static" / "uploads"
UPLOAD_TMP = DATA_DIR / "upload_chunks"
UPLOAD_CHUNK_SIZE = 4 * 1024 * 1024
MAX_UPLOAD_SIZE = 20 * 1024 * 1024 * 1024

if not JWT_SECRET or len(JWT_SECRET) < 32:
    raise RuntimeError("JWT_SECRET must be set to a random value of at least 32 characters. Use run_local.sh for local testing.")

def utcnow():
    return datetime.now(timezone.utc)

def parse_utc(value):
    dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)

def next_id(collection):
    items = load(collection)
    return max((i.get("id", 0) for i in items), default=0) + 1

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return "pbkdf2_sha256${}${}${}".format(
        PBKDF2_ITERATIONS,
        base64.urlsafe_b64encode(salt).decode().rstrip("="),
        base64.urlsafe_b64encode(digest).decode().rstrip("=")
    )

def verify_password(password: str, stored: str) -> bool:
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, rounds, salt_b64, digest_b64 = stored.split("$", 3)
            salt = base64.urlsafe_b64decode(salt_b64 + "=" * (-len(salt_b64) % 4))
            expected = base64.urlsafe_b64decode(digest_b64 + "=" * (-len(digest_b64) % 4))
            actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
            return hmac.compare_digest(actual, expected)
        except Exception:
            return False
    # One-time compatibility for old SHA-256 hashes. Successful login upgrades them.
    legacy = hashlib.sha256(("cinema_salt_v1" + password).encode()).hexdigest()
    return hmac.compare_digest(legacy, stored)

def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

def make_token(payload: dict, expires_seconds=604800) -> str:
    header = b64url(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = dict(payload)
    payload["iat"] = int(time.time())
    payload["exp"] = int(time.time()) + expires_seconds
    body = b64url(json.dumps(payload, separators=(",", ":")).encode())
    sig = b64url(hmac.new(JWT_SECRET.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
    return f"{header}.{body}.{sig}"

def decode_token(token: str):
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        header, body, sig = parts
        pad = "=" * (-len(header) % 4)
        header_data = json.loads(base64.urlsafe_b64decode(header + pad))
        if header_data.get("alg") != "HS256":
            return None
        expected = b64url(hmac.new(JWT_SECRET.encode(), f"{header}.{body}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(expected, sig):
            return None
        pad = "=" * (-len(body) % 4)
        payload = json.loads(base64.urlsafe_b64decode(body + pad))
        if payload.get("exp", 0) <= time.time():
            return None
        return payload
    except Exception:
        return None

def create_session_token(user):
    sid = str(uuid.uuid4())
    now = utcnow()
    sessions = load("sessions")
    sessions.append({"id": sid, "user_id": user["id"], "created_at": now.isoformat(),
                     "expires_at": (now + timedelta(days=7)).isoformat(), "revoked_at": None})
    save("sessions", sessions)
    return make_token({"id": user["id"], "username": user["username"], "role": user["role"], "sid": sid})

def audit_admin_action(admin, action, entity_type, entity_id=None, details=None):
    """Append a minimal audit event; never include secrets or request bodies."""
    logs = load("admin_audit_logs")
    logs.append({
        "id": next_id("admin_audit_logs"),
        "admin_id": admin.get("id"),
        "admin_username": admin.get("username"),
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "details": details or {},
        "created_at": utcnow().isoformat(),
    })
    save("admin_audit_logs", logs[-10000:])


def has_watch_access(user, subscriptions):
    if not user:
        return False
    if user.get("role") == "admin":
        return True
    if not subscription_settings()["subscriptions_enabled"]:
        return True
    ends = user.get("free_trial_ends_at")
    if ends:
        try:
            if parse_utc(ends) > utcnow():
                return True
        except Exception:
            pass
    for s in subscriptions:
        if s.get("user_id") == user.get("id") and s.get("status") == "active":
            try:
                if parse_utc(s["end_date"]) > utcnow():
                    return True
            except Exception:
                pass
    return False

def has_item_access(user, item, subscriptions):
    # Content explicitly marked free remains playable without a subscription.
    if item and item.get("access_type", "subscription") == "free":
        return bool(user) or True
    return has_watch_access(user, subscriptions)

def get_user_from_auth(handler):
    auth = handler.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    payload = decode_token(auth[7:])
    if not payload or not payload.get("sid"):
        return None
    sessions = load("sessions")
    session = next((x for x in sessions if x.get("id") == payload.get("sid")), None)
    if not session or session.get("revoked_at") or session.get("user_id") != payload.get("id"):
        return None
    try:
        if datetime.fromisoformat(session["expires_at"]) <= utcnow():
            return None
    except Exception:
        return None
    users = load("users")
    user = next((u for u in users if u["id"] == payload.get("id")), None)
    if not user or user.get("is_active", True) is False:
        return None
    return user

def issue_media_token(user, media_url, ttl=900):
    """Short-lived signed redirect token. It does not replace DRM or prevent capture."""
    if not isinstance(media_url, str) or len(media_url) > 2048:
        return None
    parsed = urlsplit(media_url)
    internal_upload = isinstance(media_url, str) and media_url.startswith("/media/uploads/") and ".." not in Path(media_url).parts
    if not internal_upload and (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password):
        return None
    payload = {"uid": user["id"], "url": media_url, "exp": int(time.time()) + ttl}
    raw = b64url(json.dumps(payload, separators=(",", ":")).encode())
    sig = b64url(hmac.new(JWT_SECRET.encode(), ("media:" + raw).encode(), hashlib.sha256).digest())
    return raw + "." + sig

def signed_media_url(user, media_url, ttl=900):
    token = issue_media_token(user, media_url, ttl)
    return "/api/media/resolve?token=" + token if token else None

def uploaded_media_path(media_url):
    """Resolve a managed upload URL without allowing traversal or encoded path tricks."""
    if not isinstance(media_url, str) or not media_url.startswith("/media/uploads/"):
        return None
    relative = media_url[len("/media/uploads/"):]
    if not relative or "\\" in relative or "?" in relative or "#" in relative or "\x00" in relative:
        return None
    parts = Path(relative).parts
    if any(part in ("", ".", "..") for part in parts):
        return None
    root = UPLOAD_DIR.resolve()
    target = (root / relative).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        return None
    return target

def playback_link_ttl(media_url, default=900):
    """Return the actual TTL used for a playback URL (uploaded HLS needs longer sessions)."""
    parsed = urlsplit(media_url or "")
    if parsed.path.lower().endswith(".m3u8") and (media_url or "").startswith("/media/uploads/"):
        return 21600
    return default

def playback_payload(user, item, kind):
    qualities = []
    for option in item.get("quality_options", []) or []:
        if isinstance(option, dict):
            option_url = option.get("url")
            option_ttl = playback_link_ttl(option_url)
            qualities.append({**option, "url": signed_media_url(user, option_url, option_ttl),
                              "link_expires_in_seconds": option_ttl,
                              "mime_type": "application/vnd.apple.mpegurl" if urlsplit(option_url or "").path.lower().endswith(".m3u8") else None})
    audios = []
    for track in item.get("audio_tracks", []) or []:
        if isinstance(track, dict):
            track_url = track.get("url")
            track_ttl = playback_link_ttl(track_url)
            audios.append({**track, "url": signed_media_url(user, track_url, track_ttl),
                           "link_expires_in_seconds": track_ttl,
                           "mime_type": "application/vnd.apple.mpegurl" if urlsplit(track_url or "").path.lower().endswith(".m3u8") else None})
    subtitles = []
    for track in item.get("subtitle_tracks", []) or []:
        if isinstance(track, dict):
            subtitle_url = track.get("url")
            subtitle_ttl = playback_link_ttl(subtitle_url)
            subtitles.append({**track, "url": signed_media_url(user, subtitle_url, subtitle_ttl),
                              "link_expires_in_seconds": subtitle_ttl})
    if item.get("subtitle_url"):
        subtitle_url = item.get("subtitle_url")
        subtitle_ttl = playback_link_ttl(subtitle_url)
        subtitles.append({"label": "فارسی", "language": "fa", "url": signed_media_url(user, subtitle_url, subtitle_ttl),
                          "link_expires_in_seconds": subtitle_ttl, "default": True})
    video_url = item.get("video_url")
    video_ttl = playback_link_ttl(video_url)
    return {
        "id": item["id"], "type": kind, "title": item.get("title"),
        "video_url": signed_media_url(user, video_url, video_ttl),
        "video_mime_type": "application/vnd.apple.mpegurl" if urlsplit(video_url or "").path.lower().endswith(".m3u8") else None,
        "duration": item.get("duration"), "allow_download": item.get("allow_download", True),
        "quality_options": qualities, "audio_tracks": audios, "subtitle_tracks": subtitles,
        "resume_position": get_watch_position(user["id"], kind, item["id"]),
        # Backward-compatible alias; now accurately reflects the main video URL.
        "link_expires_in_seconds": video_ttl,
        "video_link_expires_in_seconds": video_ttl,
    }

def get_watch_position(user_id, kind, content_id):
    entry = next((x for x in load("watch_progress") if x.get("user_id") == user_id and x.get("content_type") == kind and x.get("content_id") == content_id), None)
    return entry.get("position_seconds", 0) if entry else 0

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Signed media tokens are bearer credentials; never write them to access logs.
        message = fmt % args if args else fmt
        message = re.sub(r"([?&]token=)[^&\s]+", r"\1[REDACTED]", message)
        print(f"[{datetime.now(timezone.utc).strftime('%H:%M:%S')}] {message}")

    def _cors(self):
        origin = self.headers.get("Origin", "")
        allowed = {"http://localhost:3000", "http://127.0.0.1:3000", "http://10.0.2.2:3000"}
        if origin in allowed:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PATCH, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def _json(self, code, data):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self._cors()
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0:
            return {}
        if length > 1_048_576:
            raise ValueError("درخواست بیش از حد بزرگ است")
        raw = self.rfile.read(length)
        try:
            text = raw.decode("utf-8").strip()
            if not text:
                return {}
            return json.loads(text)
        except Exception:
            return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"
        qs = parse_qs(parsed.query)

        upload_status = re.fullmatch(r"/api/admin/uploads/([a-f0-9]{32})/status", path)
        if upload_status:
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin": return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            folder = UPLOAD_TMP / upload_status.group(1)
            meta_path = folder / "meta.json"
            if not meta_path.exists(): return self._json(404, {"error": "نشست بارگذاری پیدا نشد"})
            try:
                meta = json.loads(meta_path.read_text())
                if (not isinstance(meta, dict) or not isinstance(meta.get("chunks"), int)
                        or not isinstance(meta.get("size"), int) or meta["chunks"] < 1
                        or meta["chunks"] > (MAX_UPLOAD_SIZE + UPLOAD_CHUNK_SIZE - 1) // UPLOAD_CHUNK_SIZE
                        or meta["size"] < 1 or meta["size"] > MAX_UPLOAD_SIZE
                        or not isinstance(meta.get("name"), str)):
                    raise ValueError("invalid upload metadata")
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                return self._json(409, {"error": "فراداده نشست بارگذاری خراب است؛ بارگذاری را از ابتدا آغاز کنید"})
            if meta.get("owner_id") != user.get("id"):
                return self._json(404, {"error": "نشست بارگذاری پیدا نشد"})
            received, chunk_hashes = [], {}
            recorded_hashes = meta.get("chunk_hashes", {})
            for i in range(meta["chunks"]):
                part = folder / f"{i:08d}.part"
                if part.is_file():
                    part_hash = hashlib.sha256(part.read_bytes()).hexdigest()
                    recorded = recorded_hashes.get(str(i))
                    # A changed or truncated part is not resumable; the client will resend it.
                    if recorded and not hmac.compare_digest(recorded, part_hash):
                        continue
                    received.append(i)
                    chunk_hashes[str(i)] = part_hash
            try:
                created_at = int(meta.get("created_at", time.time()))
            except (TypeError, ValueError):
                created_at = int(time.time())
            age = max(0, int(time.time()) - created_at)
            return self._json(200, {"chunks": meta["chunks"], "chunk_size": UPLOAD_CHUNK_SIZE,
                "max_upload_size": MAX_UPLOAD_SIZE, "expires_in_seconds": max(0, 48 * 3600 - age),
                "received": received, "chunk_hashes": chunk_hashes,
                "name": meta["name"], "size": meta["size"]})

        if path == "/api/media/resolve":
            raw = qs.get("token", [""])[0]
            try:
                encoded, signature = raw.split(".", 1)
                expected = b64url(hmac.new(JWT_SECRET.encode(), ("media:" + encoded).encode(), hashlib.sha256).digest())
                if not hmac.compare_digest(expected, signature): raise ValueError("signature")
                payload = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
                target = str(payload.get("url", ""))
                target_parts = urlsplit(target)
                internal_target = target.startswith("/media/uploads/") and ".." not in Path(target).parts
                if payload.get("exp", 0) <= time.time() or (not internal_target and (target_parts.scheme != "https" or not target_parts.hostname or target_parts.username or target_parts.password)):
                    raise ValueError("expired")
            except Exception:
                return self._json(403, {"error": "لینک رسانه نامعتبر یا منقضی شده است"})
            if target.startswith("/media/uploads/"):
                media_path = uploaded_media_path(target)
                if not media_path:
                    return self._json(403, {"error": "مسیر رسانه نامعتبر است"})
                if not media_path.is_file():
                    return self._json(404, {"error": "فایل رسانه پیدا نشد"})
                if media_path.suffix.lower() == ".m3u8":
                    try:
                        playlist = media_path.read_text(encoding="utf-8-sig")
                        rewritten = self._rewrite_hls_playlist(playlist, media_path, user_id=payload.get("uid"))
                    except (OSError, UnicodeError, ValueError) as exc:
                        return self._json(502, {"error": "مانیفست HLS نامعتبر یا ناقص است"})
                    return self._serve_hls_playlist(rewritten)
                return self._serve_media_stream(media_path)
            self.send_response(302)
            self.send_header("Location", target)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Referrer-Policy", "no-referrer")
            self.end_headers()
            return

        if path in ("/api/app-settings", "/api/admin/settings"):
            if path == "/api/admin/settings":
                admin_user = get_user_from_auth(self)
                if not admin_user or admin_user.get("role") != "admin":
                    return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            rows = load("app_settings")
            settings = rows[0] if rows else {}
            defaults = {"subscriptions_enabled": SUBSCRIPTIONS_ENABLED, "free_trial_days": 3, "monthly_price": 99000, "quarterly_discount": 10, "semiannual_discount": 20, "hero_poster_url": "", "hero_slides": [], "hero_title": "دنیای فیلم و سریال، در یک قاب",
                        "hero_description": "جدیدترین فیلم‌ها و سریال‌ها را با تجربه‌ای سینمایی دنبال کنید.",
                        "hero_button": "ورود به فیلم‌ها", "hero_slide_interval": 6, "hero_slide_transition": 1350, "theme": "gold",
                        "colors": {"bg": "#090d19", "card": "#17172a", "primary": "#dfbd78",
                                   "text": "#f6f1e8", "muted": "#aaa2b4", "border": "#393149"}}
            defaults.update({k: v for k, v in settings.items() if k != "colors"})
            defaults["colors"] = {**defaults["colors"], **(settings.get("colors") or {})}
            return self._json(200, defaults)

        if path == "/api/health":
            return self._json(200, {"status": "ok", "app": "CINEMA GOLD API v3.7.34", "time": datetime.utcnow().isoformat() + "Z"})

        if path == "/api/auth/me":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "نشست معتبر نیست"})
            return self._json(200, {"id": user["id"], "username": user["username"], "role": user["role"]})

        if path == "/api/me/watch-progress":
            user = get_user_from_auth(self)
            if not user: return self._json(401, {"error": "احراز هویت لازم است"})
            # No query parameters: return this account's resumable items only.
            if not qs:
                records = [x for x in load("watch_progress") if x.get("user_id") == user["id"] and x.get("position_seconds", 0) > 0]
                movies = {x.get("id"): x for x in load("movies") if x.get("is_active")}
                episodes = {x.get("id"): x for x in load("episodes") if x.get("is_active")}
                seasons = {x.get("id"): x for x in load("seasons")}
                series = {x.get("id"): x for x in load("series") if x.get("is_active")}
                output = []
                for record in records:
                    kind, cid = record.get("content_type"), record.get("content_id")
                    if kind == "movie":
                        item = movies.get(cid)
                        if not item: continue
                        data = {"type": "movie", "id": cid, "title": item.get("title", "فیلم"), "poster_url": item.get("poster_url"), "duration": item.get("duration", 0)}
                    elif kind == "episode":
                        item = episodes.get(cid)
                        if not item: continue
                        season = seasons.get(item.get("season_id"), {})
                        parent = series.get(season.get("series_id"), {})
                        if not parent: continue
                        data = {"type": "episode", "id": cid, "title": item.get("title") or ("قسمت " + str(item.get("episode_number", ""))), "series_title": parent.get("title", "سریال"), "series_id": parent.get("id"), "poster_url": parent.get("poster_url"), "duration": item.get("duration", 0)}
                    else:
                        continue
                    position = max(0, int(record.get("position_seconds", 0) or 0))
                    duration = max(0, int(data.get("duration", 0) or 0))
                    # Keep completed items in private history, but hide them from resume shelf.
                    completion_margin = max(60, int(duration * 0.05)) if duration > 0 else 0
                    if duration > 0 and position >= max(0, duration - completion_margin):
                        continue
                    data.update({"position_seconds": position, "updated_at": record.get("updated_at")})
                    output.append(data)
                output.sort(key=lambda x: x.get("updated_at", ""), reverse=True)
                return self._json(200, output[:20])
            try:
                cid = int(qs.get("id", ["0"])[0]); kind = qs.get("type", [""])[0]
            except ValueError:
                return self._json(400, {"error": "شناسه نامعتبر"})
            if kind not in ("movie", "episode") or cid < 1: return self._json(400, {"error": "نوع محتوا نامعتبر است"})
            return self._json(200, {"position_seconds": get_watch_position(user["id"], kind, cid)})

        if path == "/api/me/support/tickets":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            tickets = [t for t in load("support_tickets") if t.get("user_id") == user["id"]]
            tickets.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            return self._json(200, tickets[:100])

        if path.startswith("/api/me/support/tickets/"):
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            try: tid = int(path.rsplit("/", 1)[1])
            except ValueError: return self._json(400, {"error": "شناسه نامعتبر"})
            ticket = next((t for t in load("support_tickets") if t["id"] == tid and t["user_id"] == user["id"]), None)
            if not ticket:
                return self._json(404, {"error": "درخواست پیدا نشد"})
            messages = [m for m in load("support_messages") if m.get("ticket_id") == tid]
            return self._json(200, {"ticket": ticket, "messages": messages})

        if path.startswith("/api/admin/support/tickets/"):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            try: tid = int(path.rsplit("/", 1)[1])
            except ValueError: return self._json(400, {"error": "شناسه نامعتبر"})
            ticket = next((t for t in load("support_tickets") if t["id"] == tid), None)
            if not ticket:
                return self._json(404, {"error": "تیکت پیدا نشد"})
            messages = [m for m in load("support_messages") if m.get("ticket_id") == tid]
            return self._json(200, {"ticket": ticket, "messages": messages})

        if path == "/api/admin/support/tickets":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            tickets = load("support_tickets")
            tickets.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            users = {u["id"]: u.get("username", "کاربر") for u in load("users")}
            return self._json(200, [{**t, "username": users.get(t.get("user_id"), "کاربر")} for t in tickets[:500]])

        if path == "/api/admin/reports":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            return self._json(200, load("content_reports")[-500:][::-1])

        if path == "/api/admin/users":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            users = load("users")
            safe_users = [{"id": u.get("id"), "username": u.get("username"),
                           "role": u.get("role", "user"), "is_active": u.get("is_active", True),
                           "created_at": u.get("created_at")} for u in users]
            return self._json(200, sorted(safe_users, key=lambda x: x.get("id") or 0, reverse=True)[:1000])

        if path == "/api/admin/audit-logs":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            try:
                limit = max(1, min(int(qs.get("limit", ["100"])[0]), 300))
            except (ValueError, TypeError):
                limit = 100
            logs = load("admin_audit_logs")
            return self._json(200, logs[-limit:][::-1])


        if path == "/api/genres":
            movies = load("movies")
            series = load("series")
            genres = sorted({(m.get("genre") or "").strip() for m in movies + series if m.get("is_active") and (m.get("genre") or "").strip()})
            return self._json(200, genres)

        if path == "/api/movies/popular":
            movies = sorted([m for m in load("movies") if m.get("is_active")], key=lambda x: x.get("view_count", 0), reverse=True)[:20]
            keys = ("id", "title", "poster_url", "rating_avg", "rating_count", "view_count", "year", "genre")
            return self._json(200, [{k: m.get(k) for k in keys} for m in movies])

        if path == "/api/movies":
            q = (qs.get("q", [""])[0] or "").strip().lower()
            genre = (qs.get("genre", [""])[0] or "").strip()
            movies = [m for m in load("movies") if m.get("is_active")]
            if q:
                movies = [m for m in movies if q in (m.get("title") or "").lower() or q in (m.get("description") or "").lower()]
            if genre:
                movies = [m for m in movies if (m.get("genre") or "") == genre]
            keys = ("id", "title", "poster_url", "rating_avg", "rating_count", "view_count", "year", "genre")
            return self._json(200, [{k: m.get(k) for k in keys} for m in movies])

        if path.startswith("/api/movies/") and path.endswith("/play"):
            mid = int(path.split("/")[3])
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            movie = next((m for m in load("movies") if m["id"] == mid and m.get("is_active")), None)
            if not movie:
                return self._json(404, {"error": "فیلم یافت نشد"})
            if not has_item_access(user, movie, load("subscriptions")):
                return self._json(403, {"error": "اشتراک شما منقضی شده. لطفاً اشتراک تهیه کنید."})
            return self._json(200, playback_payload(user, movie, "movie"))

        if path.startswith("/api/movies/"):
            mid = int(path.split("/")[-1])
            movies = load("movies")
            movie = next((m for m in movies if m["id"] == mid and m.get("is_active")), None)
            if not movie:
                return self._json(404, {"error": "فیلم یافت نشد"})
            movie["view_count"] = movie.get("view_count", 0) + 1
            save("movies", movies)
            user = get_user_from_auth(self)
            can = has_item_access(user, movie, load("subscriptions")) if user else movie.get("access_type", "subscription") == "free"
            out = dict(movie)
            out["can_watch"] = can
            if not can:
                out["video_url"] = None
                out["subtitle_url"] = None
            return self._json(200, out)

        if path == "/api/series/popular":
            series = sorted([s for s in load("series") if s.get("is_active")], key=lambda x: x.get("view_count", 0), reverse=True)[:20]
            keys = ("id", "title", "poster_url", "rating_avg", "rating_count", "view_count", "year", "genre")
            return self._json(200, [{k: s.get(k) for k in keys} for s in series])

        if path == "/api/series":
            q = (qs.get("q", [""])[0] or "").strip().lower()
            genre = (qs.get("genre", [""])[0] or "").strip()
            series = [s for s in load("series") if s.get("is_active")]
            if q:
                series = [s for s in series if q in (s.get("title") or "").lower() or q in (s.get("description") or "").lower()]
            if genre:
                series = [s for s in series if (s.get("genre") or "") == genre]
            keys = ("id", "title", "poster_url", "rating_avg", "rating_count", "view_count", "year", "genre")
            return self._json(200, [{k: s.get(k) for k in keys} for s in series])

        if path.startswith("/api/series/episodes/") and path.endswith("/play"):
            eid = int(path.split("/")[4])
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            episodes = load("episodes")
            ep = next((e for e in episodes if e["id"] == eid and e.get("is_active")), None)
            if not ep:
                return self._json(404, {"error": "قسمت یافت نشد"})
            if not has_item_access(user, ep, load("subscriptions")):
                return self._json(403, {"error": "اشتراک شما منقضی شده"})
            ep["view_count"] = ep.get("view_count", 0) + 1
            save("episodes", episodes)
            return self._json(200, playback_payload(user, ep, "episode"))

        if path.startswith("/api/series/") and path.count("/") == 3:
            sid = int(path.split("/")[-1])
            series_list = load("series")
            series = next((s for s in series_list if s["id"] == sid and s.get("is_active")), None)
            if not series:
                return self._json(404, {"error": "سریال یافت نشد"})
            series["view_count"] = series.get("view_count", 0) + 1
            save("series", series_list)
            seasons = sorted([s for s in load("seasons") if s["series_id"] == sid], key=lambda x: (x.get("season_number", 0), x.get("id", 0)))
            episodes = load("episodes")
            user = get_user_from_auth(self)
            can = has_item_access(user, series, load("subscriptions")) if user else series.get("access_type", "subscription") == "free"
            out = dict(series)
            out["can_watch"] = can
            out["seasons"] = []
            for s in seasons:
                eps = sorted([e for e in episodes if e["season_id"] == s["id"] and e.get("is_active")], key=lambda x: (x.get("episode_number", 0), x.get("id", 0)))
                out["seasons"].append({
                    **s,
                    "episodes": [{
                        "id": e["id"], "episode_number": e.get("episode_number"), "title": e.get("title"),
                        "duration": e.get("duration"), "view_count": e.get("view_count"),
                        "video_url": e.get("video_url") if can else None,
                        "subtitle_url": e.get("subtitle_url") if can else None,
                        "allow_download": e.get("allow_download", True),
                        "quality_options": e.get("quality_options", []) if can else [],
                        "audio_tracks": e.get("audio_tracks", []) if can else [],
                        "subtitle_tracks": e.get("subtitle_tracks", []) if can else []
                    } for e in eps]
                })
            return self._json(200, out)

        if path.startswith("/api/comments/"):
            parts = path.split("/")
            if len(parts) >= 5:
                typ, cid = parts[3], int(parts[4])
                comments = [c for c in load("comments") if c.get("commentable_type") == typ and c.get("commentable_id") == cid]
                comments.sort(key=lambda x: x.get("created_at", ""), reverse=True)
                users = {u["id"]: u for u in load("users")}
                result = [{
                    "id": c["id"], "body": c["body"],
                    "username": users.get(c["user_id"], {}).get("username", "کاربر"),
                    "created_at": c.get("created_at")
                } for c in comments]
                return self._json(200, result)

        if path == "/api/subscription/plans":
            cfg = subscription_settings()
            return self._json(200, subscription_plans() if cfg["subscriptions_enabled"] else [])

        if path == "/api/subscription/me":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            if not subscription_settings()["subscriptions_enabled"]:
                return self._json(200, {"hasAccess": True, "type": "free", "endsAt": None})
            if user.get("role") == "admin":
                return self._json(200, {"hasAccess": True, "type": "admin", "endsAt": None})
            ends = user.get("free_trial_ends_at")
            if ends:
                try:
                    if parse_utc(ends) > utcnow():
                        return self._json(200, {"hasAccess": True, "type": "free_trial", "endsAt": ends})
                except Exception:
                    pass
            active = [s for s in load("subscriptions") if s.get("user_id") == user["id"] and s.get("status") == "active"]
            active = sorted(active, key=lambda x: x.get("end_date", ""), reverse=True)
            if active:
                try:
                    if parse_utc(active[0]["end_date"]) > utcnow():
                        return self._json(200, {"hasAccess": True, "type": active[0].get("plan"), "endsAt": active[0]["end_date"]})
                except Exception:
                    pass
            return self._json(200, {"hasAccess": False, "type": None, "endsAt": None})

        if path == "/api/subscription/verify-mock":
            if not subscription_settings()["subscriptions_enabled"] or APP_ENV != "development":
                return self._json(404, {"error": "درگاه آزمایشی در این محیط غیرفعال است"})
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            authority = qs.get("authority", [None])[0]
            payments = load("payments")
            payment = next((p for p in payments if p.get("authority") == authority and p.get("user_id") == user["id"]), None)
            if not payment:
                return self._json(404, {"error": "پرداخت یافت نشد"})
            if payment.get("status") == "success":
                return self._json(200, {"message": "قبلاً تأیید شده"})
            payment["status"] = "success"
            save("payments", payments)
            plan = next((p for p in subscription_plans() if p["id"] == payment["plan_id"]), None)
            start = datetime.utcnow()
            end = start + timedelta(days=plan["duration_days"])
            subs = load("subscriptions")
            for s in subs:
                if s.get("user_id") == user["id"] and s.get("status") == "active":
                    s["status"] = "expired"
            subs.append({
                "id": next_id("subscriptions"), "user_id": user["id"],
                "plan": plan.get("name_en"), "plan_id": plan["id"],
                "start_date": start.isoformat(), "end_date": end.isoformat(),
                "status": "active", "payment_id": payment["id"]
            })
            save("subscriptions", subs)
            return self._json(200, {"message": "پرداخت موفق. اشتراک فعال شد.", "plan": plan["name"], "end_date": end.isoformat()})

        if path == "/api/downloads/my":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            downloads = [d for d in load("downloads") if d.get("user_id") == user["id"]]
            downloads.sort(key=lambda x: x.get("created_at", ""), reverse=True)
            return self._json(200, downloads[:50])

        # Static / web app / admin panel
        if path in ("/", "/app", "/app.html", "/index.html"):
            return self._serve_file(DATA_DIR.parent / "static" / "app.html", "text/html; charset=utf-8")
        if path == "/admin" or path == "/admin.html":
            return self._serve_file(DATA_DIR.parent / "static" / "admin.html", "text/html; charset=utf-8")
        if path.startswith("/media/uploads/"):
            fname = path.split("/media/uploads/", 1)[-1]
            media_root = UPLOAD_DIR.resolve()
            fpath = (media_root / fname).resolve()
            try: fpath.relative_to(media_root)
            except ValueError: return self._json(404, {"error": "فایل پیدا نشد"})
            if fpath.exists() and fpath.is_file():
                ext = fpath.suffix.lower()
                if ext in {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".ts", ".m3u8", ".m4s", ".aac", ".mp3", ".m4a", ".mp4a", ".key", ".srt", ".vtt"}:
                    return self._json(403, {"error": "برای پخش ویدیو از لینک امن پخش استفاده کنید"})
                return self._serve_media_stream(fpath)

        if path.startswith("/static/"):
            fname = path.split("/static/", 1)[-1]
            static_root = (DATA_DIR.parent / "static").resolve()
            fpath = (static_root / fname).resolve()
            try:
                fpath.relative_to(static_root)
            except ValueError:
                return self._json(404, {"error": "فایل پیدا نشد"})
            if fpath.exists() and fpath.is_file():
                ctype = "text/html; charset=utf-8" if fpath.suffix.lower() == ".html" else "application/octet-stream"
                return self._serve_file(fpath, ctype)

        return self._json(404, {"error": "مسیر یافت نشد"})

    def _rewrite_hls_playlist(self, playlist, playlist_path, user_id=None):
        """Rewrite every local HLS URI to a short-lived signed media URL."""
        users = load("users")
        user = next((u for u in users if u.get("id") == user_id and u.get("is_active", True)), None)
        if not user:
            raise ValueError("media owner unavailable")
        root = UPLOAD_DIR.resolve()
        def signed_uri(uri):
            uri = uri.strip()
            if not uri:
                raise ValueError("empty HLS URI")
            parsed = urlsplit(uri)
            if parsed.scheme or parsed.netloc:
                if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
                    raise ValueError("unsupported HLS URI")
                return signed_media_url(user, uri, 21600)
            if uri.startswith("/"):
                local_url = uri
            else:
                rel = (playlist_path.parent / unquote(parsed.path)).resolve()
                try:
                    rel.relative_to(root)
                except ValueError:
                    raise ValueError("HLS path escapes media directory")
                if not rel.is_file():
                    raise ValueError("HLS resource missing")
                local_url = "/media/uploads/" + rel.relative_to(root).as_posix()
            local_path = uploaded_media_path(local_url)
            if not local_path or not local_path.is_file():
                raise ValueError("HLS resource missing")
            result = signed_media_url(user, local_url, 21600)
            if not result:
                raise ValueError("HLS resource cannot be signed")
            return result

        if not playlist.lstrip().startswith("#EXTM3U"):
            raise ValueError("invalid HLS manifest header")
        output = []
        for line in playlist.splitlines():
            stripped = line.strip()
            if not stripped:
                output.append(line)
            elif stripped.startswith("#"):
                output.append(re.sub(r'URI="([^"]+)"', lambda m: 'URI="' + signed_uri(m.group(1)) + '"', line))
            else:
                output.append(signed_uri(stripped))
        if not any(line.strip() and not line.lstrip().startswith("#") for line in output):
            raise ValueError("empty HLS playlist")
        return "\n".join(output) + "\n"

    def _serve_hls_playlist(self, content):
        data = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def _serve_media_stream(self, fpath):
        ext = fpath.suffix.lower()
        ctype = ("image/jpeg" if ext in (".jpg", ".jpeg") else "image/png" if ext == ".png" else "image/webp" if ext == ".webp" else "image/gif" if ext == ".gif" else "application/vnd.apple.mpegurl; charset=utf-8" if ext == ".m3u8" else "text/vtt; charset=utf-8" if ext == ".vtt" else "application/x-subrip; charset=utf-8" if ext == ".srt" else "video/mp4" if ext in (".mp4", ".m4v", ".mov", ".m4s") else "video/webm" if ext == ".webm" else "video/x-matroska" if ext == ".mkv" else "video/mp2t" if ext == ".ts" else "audio/aac" if ext == ".aac" else "audio/mpeg" if ext == ".mp3" else "audio/mp4" if ext in (".m4a", ".mp4a") else "application/octet-stream")
        size = fpath.stat().st_size
        start, end, code = 0, max(0, size - 1), 200
        requested = self.headers.get("Range", "")
        if requested.startswith("bytes="):
            try:
                left, right = requested[6:].split("-", 1)
                if left: start = int(left)
                if right: end = min(int(right), size - 1)
                if start > end or start >= size: raise ValueError()
                code = 206
            except ValueError:
                self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.end_headers(); return
        length = max(0, end - start + 1)
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Accept-Ranges", "bytes")
        if code == 206: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self._cors(); self.end_headers()
        try:
            with fpath.open("rb") as media:
                media.seek(start); remaining = length
                while remaining:
                    block = media.read(min(1024 * 1024, remaining))
                    if not block: break
                    self.wfile.write(block); remaining -= len(block)
        except (BrokenPipeError, ConnectionResetError): pass
        return

    def _serve_file(self, fpath, content_type):
        try:
            data = open(fpath, "rb").read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self._cors()
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._json(500, {"error": str(e)})

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/")
        # Binary chunk endpoint: each request carries one bounded raw chunk.
        if re.fullmatch(r"/api/admin/uploads/[a-f0-9]{32}/chunk", path):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            upload_id = path.split("/")[-2]
            try:
                index = int(self.headers.get("X-Chunk-Index", "-1"))
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                return self._json(400, {"error": "مشخصات بخش نامعتبر است"})
            if index < 0 or length <= 0 or length > UPLOAD_CHUNK_SIZE:
                return self._json(413, {"error": "اندازه بخش بارگذاری نامعتبر است"})
            folder = UPLOAD_TMP / upload_id
            meta_path = folder / "meta.json"
            if not meta_path.exists(): return self._json(404, {"error": "بارگذاری پیدا نشد"})
            try:
                data = self.rfile.read(length)
                if len(data) != length: return self._json(400, {"error": "بخش ناقص دریافت شد"})
                expected = json.loads(meta_path.read_text())
                if expected.get("owner_id") != user.get("id"):
                    return self._json(404, {"error": "بارگذاری پیدا نشد"})
                if index >= expected["chunks"]: return self._json(400, {"error": "شماره بخش نامعتبر است"})
                expected_length = min(UPLOAD_CHUNK_SIZE, expected["size"] - index * UPLOAD_CHUNK_SIZE)
                if length != expected_length:
                    return self._json(400, {"error": "اندازه این بخش با اندازه مورد انتظار برابر نیست"})
                supplied_hash = self.headers.get("X-Chunk-SHA256", "").lower()
                actual_hash = hashlib.sha256(data).hexdigest()
                if supplied_hash and (not re.fullmatch(r"[a-f0-9]{64}", supplied_hash) or not hmac.compare_digest(supplied_hash, actual_hash)):
                    return self._json(400, {"error": "بررسی صحت بخش بارگذاری ناموفق بود"})
                part_path = folder / f"{index:08d}.part"
                temp_part = folder / f"{index:08d}.part.tmp"
                temp_part.write_bytes(data)
                os.replace(temp_part, part_path)
                # Persist the server-computed digest so later resume/finalize operations
                # can detect disk corruption or a part replaced after upload.
                expected.setdefault("chunk_hashes", {})[str(index)] = actual_hash
                meta_tmp = folder / "meta.json.tmp"
                meta_tmp.write_text(json.dumps(expected, ensure_ascii=False))
                os.replace(meta_tmp, meta_path)
                return self._json(200, {"ok": True, "chunk": index, "sha256": actual_hash})
            except Exception as exc: return self._json(400, {"error": "ذخیره بخش ناموفق بود"})
        try:
            body = self._read_json()
        except ValueError:
            return self._json(413, {"error": "حجم درخواست بیش از حد مجاز است"})

        if path in ("/api/admin/uploads/init", "/api/admin/uploads/finalize"):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            if path.endswith("/init"):
                name = Path(str(body.get("name", "file"))).name
                size = body.get("size")
                kind = body.get("kind")
                ext = Path(name).suffix.lower()
                allowed = {"poster": {".jpg", ".jpeg", ".png", ".webp", ".gif"}, "video": {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".ts"}, "subtitle": {".srt", ".vtt"}, "hls_bundle": {".zip"}}
                if kind not in allowed or ext not in allowed[kind]: return self._json(400, {"error": "نوع یا پسوند فایل پشتیبانی نمی‌شود"})
                if not isinstance(size, int) or size <= 0 or size > MAX_UPLOAD_SIZE: return self._json(413, {"error": "حجم فایل نامعتبر یا بیش از ۲۰ گیگابایت است"})
                UPLOAD_TMP.mkdir(parents=True, exist_ok=True)
                # Remove abandoned partial uploads after 48 hours to prevent unbounded disk growth.
                for stale in UPLOAD_TMP.iterdir():
                    try:
                        stale_meta = json.loads((stale / "meta.json").read_text())
                        if int(stale_meta.get("created_at", 0)) < int(time.time()) - 48 * 3600:
                            import shutil
                            shutil.rmtree(stale, ignore_errors=True)
                    except Exception:
                        # Corrupt or partially-created sessions are also removed after
                        # the retention window; otherwise malformed folders accumulate forever.
                        try:
                            if stale.is_dir() and stale.stat().st_mtime < time.time() - 48 * 3600:
                                import shutil
                                shutil.rmtree(stale, ignore_errors=True)
                        except OSError:
                            pass
                upload_id = uuid.uuid4().hex
                chunks = (size + UPLOAD_CHUNK_SIZE - 1) // UPLOAD_CHUNK_SIZE
                folder = UPLOAD_TMP / upload_id
                folder.mkdir(parents=True, exist_ok=False)
                (folder / "meta.json").write_text(json.dumps({"name": name, "size": size, "kind": kind, "chunks": chunks,
                    "chunk_hashes": {}, "owner_id": user.get("id"), "created_at": int(time.time())}, ensure_ascii=False))
                return self._json(201, {"upload_id": upload_id, "chunk_size": UPLOAD_CHUNK_SIZE, "chunks": chunks})
            upload_id = str(body.get("upload_id", ""))
            if not re.fullmatch(r"[a-f0-9]{32}", upload_id): return self._json(400, {"error": "شناسه بارگذاری نامعتبر است"})
            folder = UPLOAD_TMP / upload_id
            meta_path = folder / "meta.json"
            if not meta_path.exists(): return self._json(404, {"error": "اطلاعات بارگذاری پیدا نشد"})
            meta = json.loads(meta_path.read_text())
            if meta.get("owner_id") != user.get("id"):
                return self._json(404, {"error": "اطلاعات بارگذاری پیدا نشد"})
            parts = [folder / f"{i:08d}.part" for i in range(meta["chunks"])]
            if any(not part.is_file() for part in parts): return self._json(409, {"error": "همه بخش‌ها دریافت نشده‌اند؛ بارگذاری را ادامه دهید"})
            recorded_hashes = meta.get("chunk_hashes", {})
            for index, part in enumerate(parts):
                expected_hash = recorded_hashes.get(str(index))
                if expected_hash:
                    actual_hash = hashlib.sha256(part.read_bytes()).hexdigest()
                    if not hmac.compare_digest(expected_hash, actual_hash):
                        return self._json(409, {"error": f"صحت بخش {index + 1} تأیید نشد؛ آن بخش را دوباره بارگذاری کنید", "corrupt_chunk": index})
            UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
            safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(meta["name"]).name).strip("._") or "media"
            stored = f"{uuid.uuid4().hex}_{safe_name}"
            destination = UPLOAD_DIR / stored
            assembling = UPLOAD_DIR / (stored + ".assembling")
            written = 0
            digest = hashlib.sha256()
            try:
                with assembling.open("wb") as out:
                    for part in parts:
                        with part.open("rb") as src:
                            while True:
                                block = src.read(1024 * 1024)
                                if not block: break
                                out.write(block); digest.update(block); written += len(block)
                if written != meta["size"]:
                    return self._json(400, {"error": "اندازه فایل نهایی با مقدار اعلام‌شده برابر نیست"})
                os.replace(assembling, destination)
            finally:
                assembling.unlink(missing_ok=True)
            import shutil
            if meta.get("kind") == "hls_bundle":
                bundle_dir = UPLOAD_DIR / uuid.uuid4().hex
                try:
                    bundle_dir.mkdir(parents=True, exist_ok=False)
                    with zipfile.ZipFile(destination, "r") as archive:
                        infos = archive.infolist()
                        if not infos or len(infos) > 5000:
                            raise ValueError("تعداد فایل‌های بسته HLS نامعتبر است")
                        total_uncompressed = sum(x.file_size for x in infos)
                        if total_uncompressed > MAX_UPLOAD_SIZE:
                            raise ValueError("حجم استخراج‌شده بسته HLS بیش از حد مجاز است")
                        seen = set()
                        allowed_hls = {".m3u8", ".ts", ".m4s", ".mp4", ".aac", ".mp3", ".m4a", ".vtt", ".key"}
                        for info in infos:
                            raw_name = info.filename
                            if "\\" in raw_name or "\x00" in raw_name:
                                raise ValueError("مسیر فایل داخل بسته HLS نامعتبر است")
                            rel = Path(raw_name)
                            if rel.is_absolute() or any(part in ("", ".", "..") for part in rel.parts):
                                raise ValueError("مسیر ناامن داخل بسته HLS شناسایی شد")
                            mode = (info.external_attr >> 16) & 0xFFFF
                            if stat.S_ISLNK(mode):
                                raise ValueError("لینک نمادین در بسته HLS مجاز نیست")
                            key = rel.as_posix().casefold()
                            if key in seen:
                                raise ValueError("نام تکراری در بسته HLS وجود دارد")
                            seen.add(key)
                            target_path = (bundle_dir / rel).resolve()
                            target_path.relative_to(bundle_dir.resolve())
                            if info.is_dir():
                                target_path.mkdir(parents=True, exist_ok=True)
                                continue
                            if target_path.suffix.lower() not in allowed_hls:
                                raise ValueError("نوع فایل داخل بسته HLS پشتیبانی نمی‌شود: " + target_path.suffix)
                            target_path.parent.mkdir(parents=True, exist_ok=True)
                            copied = 0
                            with archive.open(info, "r") as src, target_path.open("xb") as out:
                                while True:
                                    block = src.read(1024 * 1024)
                                    if not block: break
                                    copied += len(block)
                                    if copied > info.file_size:
                                        raise ValueError("اندازه فایل داخل بسته HLS نامعتبر است")
                                    out.write(block)
                            if copied != info.file_size:
                                raise ValueError("استخراج فایل بسته HLS ناقص است")
                    playlists = sorted(bundle_dir.rglob("*.m3u8"), key=lambda x: (x.name.lower() not in ("master.m3u8", "index.m3u8"), len(x.parts), x.as_posix()))
                    if not playlists:
                        raise ValueError("در بسته ZIP هیچ فایل m3u8 پیدا نشد")
                    master = playlists[0]
                    result_url = "/media/uploads/" + master.relative_to(UPLOAD_DIR).as_posix()
                except Exception as exc:
                    shutil.rmtree(bundle_dir, ignore_errors=True)
                    destination.unlink(missing_ok=True)
                    shutil.rmtree(folder, ignore_errors=True)
                    message = str(exc) if isinstance(exc, (ValueError, zipfile.BadZipFile, RuntimeError)) else "استخراج بسته HLS ناموفق بود"
                    return self._json(400, {"error": message})
                destination.unlink(missing_ok=True)
            else:
                result_url = "/media/uploads/" + stored
            shutil.rmtree(folder, ignore_errors=True)
            return self._json(201, {"url": result_url, "name": stored, "size": written,
                "kind": meta["kind"], "sha256": digest.hexdigest()})

        if path in ("/api/auth/register", "/api/auth/login"):
            ip = self.client_address[0]
            now_ts = time.time()
            attempts = [t for t in LOGIN_ATTEMPTS.get(ip, []) if now_ts - t < 300]
            if len(attempts) >= 15:
                return self._json(429, {"error": "تلاش‌های زیاد؛ پنج دقیقه بعد دوباره امتحان کنید"})
            LOGIN_ATTEMPTS[ip] = attempts + [now_ts]
            username = (body.get("username") or "").strip()
            password = body.get("password") or ""
            if not re.fullmatch(r"[A-Za-z0-9_]{3,24}", username):
                return self._json(400, {"error": "نام کاربری باید ۳ تا ۲۴ نویسه انگلیسی، عدد یا _ باشد"})
            if not isinstance(password, str) or len(password) < 10 or len(password) > 128:
                return self._json(400, {"error": "رمز عبور باید بین ۱۰ تا ۱۲۸ نویسه باشد"})
            users = load("users")
            if path == "/api/auth/register":
                if any(u["username"].lower() == username.lower() for u in users):
                    return self._json(409, {"error": "این نام کاربری قبلاً ثبت شده"})
                now = utcnow()
                trial_end = now + timedelta(days=3)
                user = {
                    "id": next_id("users"), "username": username,
                    "password": hash_password(password), "role": "user", "is_active": True,
                    "free_trial_started_at": now.isoformat(),
                    "free_trial_ends_at": trial_end.isoformat(),
                    "created_at": now.isoformat()
                }
                users.append(user)
                save("users", users)
                LOGIN_ATTEMPTS.pop(ip, None)
                token = create_session_token(user)
                return self._json(201, {
                    "message": "ثبت‌نام موفق. حساب رایگان شما فعال شد.",
                    "token": token,
                    "user": {"id": user["id"], "username": user["username"], "role": user["role"], "free_trial_ends_at": user["free_trial_ends_at"]}
                })

            user = next((u for u in users if u["username"].lower() == username.lower()), None)
            if not user or user.get("is_active", True) is False or not verify_password(password, user.get("password", "")):
                return self._json(401, {"error": "نام کاربری یا رمز عبور اشتباه است"})
            # Upgrade legacy SHA-256 hashes after a successful login.
            if not user.get("password", "").startswith("pbkdf2_sha256$"):
                user["password"] = hash_password(password)
                save("users", users)
            LOGIN_ATTEMPTS.pop(ip, None)
            token = create_session_token(user)
            return self._json(200, {
                "token": token,
                "user": {"id": user["id"], "username": user["username"], "role": user["role"], "free_trial_ends_at": user.get("free_trial_ends_at")}
            })

        if path == "/api/auth/logout":
            auth = self.headers.get("Authorization", "")
            payload = decode_token(auth[7:]) if auth.startswith("Bearer ") else None
            if not payload or not payload.get("sid"):
                return self._json(401, {"error": "نشست معتبر نیست"})
            sessions = load("sessions")
            for session in sessions:
                if session.get("id") == payload["sid"]:
                    session["revoked_at"] = utcnow().isoformat()
            save("sessions", sessions)
            return self._json(200, {"message": "از حساب خارج شدید"})

        if path == "/api/me/password":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            current_password = body.get("current_password") or ""
            new_password = body.get("new_password") or ""
            confirm_password = body.get("confirm_password") or ""
            if not isinstance(current_password, str) or not isinstance(new_password, str):
                return self._json(400, {"error": "اطلاعات رمز عبور معتبر نیست"})
            if not verify_password(current_password, user.get("password", "")):
                return self._json(400, {"error": "رمز عبور فعلی اشتباه است"})
            if len(new_password) < 10 or len(new_password) > 128:
                return self._json(400, {"error": "رمز جدید باید بین ۱۰ تا ۱۲۸ نویسه باشد"})
            if new_password != confirm_password:
                return self._json(400, {"error": "تکرار رمز جدید یکسان نیست"})
            if hmac.compare_digest(current_password, new_password):
                return self._json(400, {"error": "رمز جدید باید با رمز فعلی متفاوت باشد"})
            users = load("users")
            for item in users:
                if item.get("id") == user.get("id"):
                    item["password"] = hash_password(new_password)
                    item["password_changed_at"] = utcnow().isoformat()
                    break
            save("users", users)
            sessions = load("sessions")
            revoked_at = utcnow().isoformat()
            for session in sessions:
                if session.get("user_id") == user.get("id") and not session.get("revoked_at"):
                    session["revoked_at"] = revoked_at
            save("sessions", sessions)
            return self._json(200, {"message": "رمز عبور تغییر کرد؛ برای ورود دوباره از رمز جدید استفاده کنید"})

        if path == "/api/me/watch-progress":
            user = get_user_from_auth(self)
            if not user: return self._json(401, {"error": "احراز هویت لازم است"})
            records = load("watch_progress")
            action = body.get("action")
            if action == "clear":
                save("watch_progress", [x for x in records if x.get("user_id") != user["id"]])
                return self._json(200, {"message": "تاریخچه ادامه تماشا پاک شد"})
            kind = body.get("type"); cid = body.get("id")
            if action == "remove":
                if kind not in ("movie", "episode") or not isinstance(cid, int) or isinstance(cid, bool) or cid < 1:
                    return self._json(400, {"error": "شناسه محتوا نامعتبر است"})
                save("watch_progress", [x for x in records if not (x.get("user_id") == user["id"] and x.get("content_type") == kind and x.get("content_id") == cid)])
                return self._json(200, {"message": "مورد از تاریخچه حذف شد"})
            position = body.get("position_seconds")
            if kind not in ("movie", "episode") or not isinstance(cid, int) or isinstance(cid, bool) or cid < 1 or not isinstance(position, (int, float)) or isinstance(position, bool) or position < 0 or position > 86400:
                return self._json(400, {"error": "اطلاعات زمان تماشا نامعتبر است"})
            entry = next((x for x in records if x.get("user_id") == user["id"] and x.get("content_type") == kind and x.get("content_id") == cid), None)
            values = {"user_id": user["id"], "content_type": kind, "content_id": cid, "position_seconds": int(position), "updated_at": utcnow().isoformat()}
            if entry: entry.update(values)
            else: records.append({"id": next_id("watch_progress"), **values})
            save("watch_progress", records[-20000:])
            return self._json(200, {"message": "زمان تماشا ذخیره شد"})

        if path == "/api/me/support/tickets":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            subject = (body.get("subject") or "").strip()
            category = body.get("category") or "other"
            message_text = (body.get("message") or "").strip()
            allowed = {"account", "payment", "playback", "subtitle", "download", "other"}
            if len(subject) < 4 or len(subject) > 150 or len(message_text) < 5 or len(message_text) > 3000 or category not in allowed:
                return self._json(400, {"error": "عنوان، دسته‌بندی یا متن درخواست معتبر نیست"})
            tickets = load("support_tickets")
            tid = next_id("support_tickets")
            now = utcnow().isoformat()
            tickets.append({"id": tid, "user_id": user["id"], "subject": subject, "category": category,
                            "status": "open", "priority": "normal", "created_at": now, "updated_at": now})
            save("support_tickets", tickets)
            messages = load("support_messages")
            messages.append({"id": next_id("support_messages"), "ticket_id": tid, "sender_id": user["id"],
                             "sender_role": "user", "message": message_text, "created_at": now})
            save("support_messages", messages)
            return self._json(201, {"ticket_id": tid, "status": "open"})

        if path.startswith("/api/me/support/tickets/") and path.endswith("/messages"):
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            try: tid = int(path.split("/")[5])
            except (ValueError, IndexError): return self._json(400, {"error": "شناسه نامعتبر"})
            tickets = load("support_tickets")
            ticket = next((t for t in tickets if t["id"] == tid and t["user_id"] == user["id"]), None)
            msg = (body.get("message") or "").strip()
            if not ticket: return self._json(404, {"error": "درخواست پیدا نشد"})
            if ticket["status"] == "closed": return self._json(409, {"error": "درخواست بسته شده است"})
            if not msg or len(msg) > 3000: return self._json(400, {"error": "متن پیام نامعتبر است"})
            messages = load("support_messages")
            messages.append({"id": next_id("support_messages"), "ticket_id": tid, "sender_id": user["id"],
                             "sender_role": "user", "message": msg, "created_at": utcnow().isoformat()})
            save("support_messages", messages)
            ticket["status"] = "open"; ticket["updated_at"] = utcnow().isoformat(); save("support_tickets", tickets)
            return self._json(201, {"message": "پیام ثبت شد"})

        if path.startswith("/api/admin/support/tickets/") and path.endswith("/messages"):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin": return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            try: tid = int(path.split("/")[5])
            except (ValueError, IndexError): return self._json(400, {"error": "شناسه نامعتبر"})
            tickets = load("support_tickets")
            ticket = next((t for t in tickets if t["id"] == tid), None)
            msg = (body.get("message") or "").strip()
            if not ticket: return self._json(404, {"error": "درخواست پیدا نشد"})
            if not msg or len(msg) > 3000: return self._json(400, {"error": "متن پیام نامعتبر است"})
            messages = load("support_messages")
            messages.append({"id": next_id("support_messages"), "ticket_id": tid, "sender_id": user["id"],
                             "sender_role": "admin", "message": msg, "created_at": utcnow().isoformat()})
            save("support_messages", messages)
            ticket["status"] = "answered"; ticket["updated_at"] = utcnow().isoformat(); save("support_tickets", tickets)
            audit_admin_action(user, "support_reply_sent", "support_ticket", tid)
            return self._json(201, {"message": "پاسخ ارسال شد"})

        if path == "/api/reports":
            user = get_user_from_auth(self)
            if not user: return self._json(401, {"error": "احراز هویت لازم است"})
            typ = body.get("content_type"); cid = body.get("content_id")
            category = body.get("category") or "playback"
            description = (body.get("description") or "").strip()
            if typ not in ("movie", "series", "episode") or not isinstance(cid, int) or category not in ("broken_link", "video", "audio", "subtitle", "quality", "other") or len(description) > 1500:
                return self._json(400, {"error": "اطلاعات گزارش معتبر نیست"})
            collection = {"movie": "movies", "series": "series", "episode": "episodes"}[typ]
            if not any(x.get("id") == cid for x in load(collection)):
                return self._json(404, {"error": "محتوا پیدا نشد"})
            reports = load("content_reports")
            rid = next_id("content_reports")
            reports.append({"id": rid, "user_id": user["id"], "content_type": typ, "content_id": cid,
                            "category": category, "description": description, "status": "new", "created_at": utcnow().isoformat()})
            save("content_reports", reports)
            return self._json(201, {"report_id": rid, "status": "new"})

        if path.startswith("/api/comments/"):
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            parts = path.split("/")
            typ, cid = parts[3], int(parts[4])
            text = (body.get("body") or "").strip()
            if len(text) < 2 or len(text) > 500:
                return self._json(400, {"error": "متن نظر نامعتبر است"})
            comments = load("comments")
            c = {
                "id": next_id("comments"), "user_id": user["id"],
                "commentable_type": typ, "commentable_id": cid,
                "body": text, "is_approved": True,
                "created_at": datetime.utcnow().isoformat()
            }
            comments.append(c)
            save("comments", comments)
            return self._json(201, {"id": c["id"], "body": c["body"], "username": user["username"], "created_at": c["created_at"]})

        if path.startswith("/api/ratings/"):
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            parts = path.split("/")
            typ, cid = parts[3], int(parts[4])
            score = int(body.get("score", 0))
            if score < 1 or score > 10:
                return self._json(400, {"error": "امتیاز باید بین ۱ تا ۱۰ باشد"})
            ratings = load("ratings")
            existing = next((i for i, r in enumerate(ratings) if r["user_id"] == user["id"] and r["rateable_type"] == typ and r["rateable_id"] == cid), None)
            if existing is not None:
                ratings[existing]["score"] = score
            else:
                ratings.append({
                    "id": next_id("ratings"), "user_id": user["id"],
                    "rateable_type": typ, "rateable_id": cid, "score": score,
                    "created_at": datetime.utcnow().isoformat()
                })
            save("ratings", ratings)
            item_ratings = [r for r in ratings if r["rateable_type"] == typ and r["rateable_id"] == cid]
            avg = round(sum(r["score"] for r in item_ratings) / len(item_ratings), 1)
            coll = "movies" if typ == "movie" else "series"
            items = load(coll)
            for it in items:
                if it["id"] == cid:
                    it["rating_avg"] = avg
                    it["rating_count"] = len(item_ratings)
            save(coll, items)
            return self._json(200, {"score": score, "rating_avg": avg, "rating_count": len(item_ratings)})

        if path == "/api/subscription/pay":
            if not subscription_settings()["subscriptions_enabled"]:
                return self._json(403, {"error": "خرید اشتراک در حال حاضر غیرفعال است"})
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            plan_id = int(body.get("plan_id", 0))
            plan = next((p for p in subscription_plans() if p["id"] == plan_id), None)
            if not plan:
                return self._json(400, {"error": "پلن نامعتبر"})
            payments = load("payments")
            payment = {
                "id": next_id("payments"), "user_id": user["id"], "plan_id": plan["id"],
                "amount": plan["price"], "gateway": "mock",
                "authority": f"MOCK-{int(time.time())}", "status": "pending",
                "created_at": datetime.utcnow().isoformat()
            }
            payments.append(payment)
            save("payments", payments)
            return self._json(200, {
                "message": "درگاه پرداخت (نسخه آزمایشی)",
                "payment_id": payment["id"], "authority": payment["authority"],
                "amount": plan["price"],
                "mock_pay_url": f"/api/subscription/verify-mock?authority={payment['authority']}"
            })

        if path == "/api/downloads/request":
            user = get_user_from_auth(self)
            if not user:
                return self._json(401, {"error": "احراز هویت لازم است"})
            # The selected item is checked below after it has been loaded.
            typ = body.get("type")
            cid = int(body.get("id", 0))
            item = None
            if typ == "movie":
                item = next((m for m in load("movies") if m["id"] == cid and m.get("is_active")), None)
            elif typ == "episode":
                item = next((e for e in load("episodes") if e["id"] == cid and e.get("is_active")), None)
            if not item:
                return self._json(404, {"error": "محتوا یافت نشد"})
            if not has_item_access(user, item, load("subscriptions")):
                return self._json(403, {"error": "برای دانلود این محتوا اشتراک فعال لازم است"})
            if item.get("allow_download") is False:
                return self._json(403, {"error": "دانلود این محتوا مجاز نیست"})
            downloads = load("downloads")
            downloads.append({
                "id": next_id("downloads"), "user_id": user["id"],
                "type": typ, "content_id": cid, "created_at": datetime.utcnow().isoformat()
            })
            save("downloads", downloads)
            return self._json(200, {
                "title": item.get("title"), "video_url": signed_media_url(user, item.get("video_url"), 3600),
                "subtitle_url": signed_media_url(user, item.get("subtitle_url"), 3600), "expires_in_seconds": 3600,
                "message": "لینک دانلود آماده است."
            })

        if path == "/api/movies":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            movies = load("movies")
            movie = {
                "id": next_id("movies"), "title": body.get("title"),
                "description": body.get("description", ""), "poster_url": body.get("poster_url", ""),
                "video_url": body.get("video_url"), "subtitle_url": body.get("subtitle_url"),
                "duration": body.get("duration", 0), "year": body.get("year", datetime.utcnow().year),
                "genre": body.get("genre", "عمومی"), "view_count": 0, "rating_avg": 0, "rating_count": 0,
                "is_active": True, "allow_download": body.get("allow_download", True),
                "access_type": "free" if body.get("access_type") == "free" else "subscription",
                "created_at": datetime.utcnow().isoformat()
            }
            movies.append(movie)
            save("movies", movies)
            audit_admin_action(user, "movie_created", "movie", movie["id"], {"title": movie["title"]})
            return self._json(201, movie)

        # Admin: create series
        if path == "/api/series":
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            title = (body.get("title") or "").strip()
            if not title:
                return self._json(400, {"error": "عنوان سریال الزامی است"})
            series_list = load("series")
            item = {
                "id": next_id("series"),
                "title": title,
                "description": body.get("description", ""),
                "poster_url": body.get("poster_url", ""),
                "year": body.get("year", datetime.utcnow().year),
                "genre": body.get("genre", "عمومی"),
                "view_count": 0, "rating_avg": 0, "rating_count": 0,
                "is_active": True,
                "allow_download": body.get("allow_download", True),
                "access_type": "free" if body.get("access_type") == "free" else "subscription",
                "created_at": datetime.utcnow().isoformat()
            }
            series_list.append(item)
            save("series", series_list)
            audit_admin_action(user, "series_created", "series", item["id"], {"title": item["title"]})
            return self._json(201, item)

        # Admin: add season  POST /api/series/{id}/seasons
        if path.startswith("/api/series/") and path.endswith("/seasons"):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            parts = path.split("/")
            series_id = int(parts[3])
            if not any(s["id"] == series_id for s in load("series")):
                return self._json(404, {"error": "سریال یافت نشد"})
            seasons = load("seasons")
            season_number = int(body.get("season_number") or (max((s.get("season_number", 0) for s in seasons if s["series_id"] == series_id), default=0) + 1))
            season = {
                "id": next_id("seasons"),
                "series_id": series_id,
                "season_number": season_number,
                "title": body.get("title") or f"فصل {season_number}"
            }
            seasons.append(season)
            save("seasons", seasons)
            audit_admin_action(user, "season_created", "season", season["id"], {"series_id": series_id, "season_number": season_number})
            return self._json(201, season)

        # Admin: add episode  POST /api/series/seasons/{seasonId}/episodes
        if path.startswith("/api/series/seasons/") and path.endswith("/episodes"):
            user = get_user_from_auth(self)
            if not user or user.get("role") != "admin":
                return self._json(403, {"error": "دسترسی فقط برای مدیر"})
            season_id = int(path.split("/")[4])
            seasons = load("seasons")
            if not any(s["id"] == season_id for s in seasons):
                return self._json(404, {"error": "فصل یافت نشد"})
            video_url = body.get("video_url")
            if not video_url:
                return self._json(400, {"error": "لینک ویدیو الزامی است"})
            episodes = load("episodes")
            ep_num = int(body.get("episode_number") or (max((e.get("episode_number", 0) for e in episodes if e["season_id"] == season_id), default=0) + 1))
            ep = {
                "id": next_id("episodes"),
                "season_id": season_id,
                "episode_number": ep_num,
                "title": body.get("title") or f"قسمت {ep_num}",
                "video_url": video_url,
                "subtitle_url": body.get("subtitle_url") or None,
                "duration": int(body.get("duration") or 0),
                "view_count": 0,
                "is_active": True,
                "allow_download": body.get("allow_download", True)
            }
            episodes.append(ep)
            save("episodes", episodes)
            audit_admin_action(user, "episode_created", "episode", ep["id"], {"title": ep["title"]})
            return self._json(201, ep)

        # Admin: soft-delete series
        if path.startswith("/api/series/") and path.count("/") == 3:
            # handled only as GET usually; for DELETE we use method below
            pass

        return self._json(404, {"error": "مسیر یافت نشد"})


    def do_PATCH(self):
        path = urlparse(self.path).path.rstrip("/")
        try:
            body = self._read_json()
        except ValueError:
            return self._json(413, {"error": "حجم درخواست بیش از حد مجاز است"})
        user = get_user_from_auth(self)
        if not user or user.get("role") != "admin":
            return self._json(403, {"error": "دسترسی فقط برای مدیر"})
        if path == "/api/admin/settings":
            if not isinstance(body, dict):
                return self._json(400, {"error": "تنظیمات نامعتبر است"})
            allowed_fields = {"subscriptions_enabled", "monthly_price", "quarterly_discount", "semiannual_discount", "hero_poster_url", "hero_slides", "hero_title", "hero_description", "hero_button", "hero_slide_interval", "hero_slide_transition", "theme", "colors"}
            if set(body) - allowed_fields:
                return self._json(400, {"error": "فیلد تنظیمات ناشناخته است"})
            current_rows = load("app_settings")
            current = current_rows[0] if current_rows else {}
            updated = dict(current)
            if "subscriptions_enabled" in body:
                if not isinstance(body["subscriptions_enabled"], bool):
                    return self._json(400, {"error": "وضعیت اشتراک نامعتبر است"})
                updated["subscriptions_enabled"] = body["subscriptions_enabled"]
            for key, lo, hi in (("monthly_price", 1000, 1000000000), ("quarterly_discount", 0, 80), ("semiannual_discount", 0, 80)):
                if key in body:
                    value = body[key]
                    if isinstance(value, bool) or not isinstance(value, int) or not lo <= value <= hi:
                        return self._json(400, {"error": "قیمت یا درصد تخفیف خارج از محدوده مجاز است"})
                    updated[key] = value
            updated["free_trial_days"] = 3
            for key in ("hero_title", "hero_description", "hero_button", "theme"):
                if key in body:
                    value = body[key]
                    if not isinstance(value, str) or len(value) > (1600 if key == "hero_description" else 120):
                        return self._json(400, {"error": "مقدار متنی تنظیمات نامعتبر است"})
                    updated[key] = value.strip()
            numeric_ranges = {"hero_slide_interval": (3, 30), "hero_slide_transition": (200, 3000)}
            for key, (minimum, maximum) in numeric_ranges.items():
                if key in body:
                    value = body[key]
                    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
                        return self._json(400, {"error": "زمان‌بندی اسلایدر خارج از محدوده مجاز است"})
                    updated[key] = value
            if "hero_poster_url" in body:
                value = body["hero_poster_url"]
                parsed_poster = urlsplit(value) if isinstance(value, str) else None
                internal_ok = isinstance(value, str) and value.startswith("/media/uploads/") and ".." not in Path(value).parts
                external_ok = bool(parsed_poster and parsed_poster.scheme == "https" and parsed_poster.hostname and not parsed_poster.username and not parsed_poster.password)
                if not isinstance(value, str) or len(value) > 500 or (value and not (internal_ok or external_ok)):
                    return self._json(400, {"error": "آدرس پوستر صفحه اصلی نامعتبر است"})
                updated["hero_poster_url"] = value
            if "hero_slides" in body:
                slides = body["hero_slides"]
                if not isinstance(slides, list) or len(slides) > 5:
                    return self._json(400, {"error": "حداکثر پنج پوستر برای اسلایدر مجاز است"})
                for value in slides:
                    parsed_slide = urlsplit(value) if isinstance(value, str) else None
                    internal_ok = isinstance(value, str) and value.startswith("/media/uploads/") and ".." not in Path(value).parts
                    external_ok = bool(parsed_slide and parsed_slide.scheme == "https" and parsed_slide.hostname and not parsed_slide.username and not parsed_slide.password)
                    if not isinstance(value, str) or len(value) > 500 or not (internal_ok or external_ok):
                        return self._json(400, {"error": "آدرس یکی از پوسترهای اسلایدر نامعتبر است"})
                updated["hero_slides"] = slides
                updated["hero_poster_url"] = slides[0] if slides else ""
            if "colors" in body:
                colors = body["colors"]
                valid_keys = {"bg", "card", "primary", "text", "muted", "border"}
                if not isinstance(colors, dict) or set(colors) - valid_keys:
                    return self._json(400, {"error": "رنگ‌بندی نامعتبر است"})
                merged = dict(current.get("colors") or {})
                for key, value in colors.items():
                    if not isinstance(value, str) or not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
                        return self._json(400, {"error": "رنگ باید با قالب HEX شش‌رقمی باشد"})
                    merged[key] = value.lower()
                updated["colors"] = merged
            save("app_settings", [updated])
            audit_admin_action(user, "app_settings_updated", "app_settings", 1, {"theme": updated.get("theme")})
            return self._json(200, {"message": "تنظیمات ظاهر صفحه اصلی ذخیره شد", "settings": updated})
        if path.startswith("/api/admin/users/"):
            try: target_id = int(path.rsplit("/", 1)[1])
            except ValueError: return self._json(400, {"error": "شناسه نامعتبر"})
            if not isinstance(body.get("is_active"), bool):
                return self._json(400, {"error": "وضعیت فعال/مسدود باید مشخص شود"})
            users = load("users")
            target = next((u for u in users if u.get("id") == target_id), None)
            if not target:
                return self._json(404, {"error": "کاربر پیدا نشد"})
            if target.get("role") == "admin" and target.get("id") == user.get("id") and body["is_active"] is False:
                return self._json(400, {"error": "مدیر نمی‌تواند حساب خودش را مسدود کند"})
            if target.get("role") == "admin" and body["is_active"] is False and target.get("is_active", True):
                active_admins = [u for u in users if u.get("role") == "admin" and u.get("is_active", True)]
                if len(active_admins) <= 1:
                    return self._json(400, {"error": "حداقل یک مدیر فعال باید باقی بماند"})
            target["is_active"] = body["is_active"]
            target["updated_at"] = utcnow().isoformat()
            save("users", users)
            if not body["is_active"]:
                sessions = load("sessions")
                for session in sessions:
                    if session.get("user_id") == target_id and not session.get("revoked_at"):
                        session["revoked_at"] = utcnow().isoformat()
                save("sessions", sessions)
            audit_admin_action(user, "user_activated" if body["is_active"] else "user_blocked", "user", target_id,
                               {"target_username": target.get("username")})
            return self._json(200, {"message": "وضعیت حساب کاربر به‌روزرسانی شد", "is_active": target["is_active"]})

        # Admin season editor: PATCH /api/admin/seasons/{id}
        season_match = re.fullmatch(r"/api/admin/seasons/(\d+)", path)
        if season_match:
            season_id = int(season_match.group(1))
            if not isinstance(body, dict) or not body or not set(body).issubset({"title", "season_number"}):
                return self._json(400, {"error": "فیلدهای فصل نامعتبر هستند"})
            seasons = load("seasons")
            season = next((x for x in seasons if x.get("id") == season_id), None)
            if not season:
                return self._json(404, {"error": "فصل پیدا نشد"})
            if "title" in body:
                title = body["title"]
                if not isinstance(title, str) or not title.strip() or len(title.strip()) > 120:
                    return self._json(400, {"error": "عنوان فصل نامعتبر است"})
                season["title"] = title.strip()
            if "season_number" in body:
                number = body["season_number"]
                if not isinstance(number, int) or isinstance(number, bool) or number < 1 or number > 999:
                    return self._json(400, {"error": "شماره فصل باید بین ۱ تا ۹۹۹ باشد"})
                if any(x.get("id") != season_id and x.get("series_id") == season.get("series_id") and x.get("season_number") == number for x in seasons):
                    return self._json(409, {"error": "این شماره فصل برای همین سریال قبلاً ثبت شده است"})
                season["season_number"] = number
            season["updated_at"] = utcnow().isoformat()
            save("seasons", seasons)
            audit_admin_action(user, "season_updated", "season", season_id, {"updated_fields": sorted(body.keys())})
            return self._json(200, {"message": "اطلاعات فصل به‌روزرسانی شد", "season": season})

        # Admin content editor: PATCH /api/admin/{movies|series|episodes}/{id}
        content_match = re.fullmatch(r"/api/admin/(movies|series|episodes)/(\d+)", path)
        if content_match:
            kind, raw_id = content_match.groups()
            content_id = int(raw_id)
            collection = {"movies": "movies", "series": "series", "episodes": "episodes"}[kind]
            fields = {
                "movies": {"title", "description", "poster_url", "video_url", "subtitle_url", "duration", "year", "genre", "allow_download", "access_type", "is_active", "audio_tracks", "subtitle_tracks", "quality_options", "content_rating"},
                "series": {"title", "description", "poster_url", "year", "genre", "allow_download", "access_type", "is_active", "audio_tracks", "subtitle_tracks", "quality_options", "content_rating"},
                "episodes": {"title", "video_url", "subtitle_url", "duration", "episode_number", "allow_download", "access_type", "is_active", "audio_tracks", "subtitle_tracks", "quality_options"},
            }[kind]
            if not body or not isinstance(body, dict) or not set(body).issubset(fields):
                return self._json(400, {"error": "فیلدهای ارسالی نامعتبر هستند"})
            items = load(collection)
            item = next((x for x in items if x.get("id") == content_id), None)
            if not item:
                return self._json(404, {"error": "محتوا پیدا نشد"})
            for key, value in body.items():
                if key in ("title", "genre"):
                    if not isinstance(value, str) or not value.strip() or len(value.strip()) > (200 if key == "title" else 80):
                        return self._json(400, {"error": "عنوان یا ژانر نامعتبر است"})
                    item[key] = value.strip()
                elif key in ("description",):
                    if not isinstance(value, str) or len(value) > 10000:
                        return self._json(400, {"error": "توضیحات نامعتبر است"})
                    item[key] = value
                elif key in ("poster_url", "video_url", "subtitle_url"):
                    if value in (None, "") and key != "video_url":
                        item[key] = None if value is None else ""
                    elif not isinstance(value, str) or len(value) > 2048:
                        return self._json(400, {"error": "نشانی رسانه نامعتبر است"})
                    elif value.startswith("/media/uploads/"):
                        media_path = uploaded_media_path(value)
                        if not media_path:
                            return self._json(400, {"error": "مسیر فایل بارگذاری‌شده نامعتبر است"})
                        if not media_path.is_file():
                            return self._json(400, {"error": "فایل بارگذاری‌شده پیدا نشد"})
                        item[key] = value
                    elif not value.startswith("https://"):
                        return self._json(400, {"error": "لینک خارجی باید HTTPS معتبر باشد"})
                    else:
                        item[key] = value
                elif key in ("duration", "year", "episode_number"):
                    if not isinstance(value, int) or isinstance(value, bool) or value < (0 if key == "duration" else 1) or value > (100000 if key == "duration" else 9999):
                        return self._json(400, {"error": "مقدار عددی نامعتبر است"})
                    item[key] = value
                elif key == "access_type":
                    if value not in ("free", "subscription"):
                        return self._json(400, {"error": "نوع دسترسی محتوا نامعتبر است"})
                    item[key] = value
                elif key in ("allow_download", "is_active"):
                    if not isinstance(value, bool):
                        return self._json(400, {"error": "مقدار بولی نامعتبر است"})
                    item[key] = value
                elif key in ("audio_tracks", "subtitle_tracks", "quality_options"):
                    if not isinstance(value, list) or len(value) > 20 or any(not isinstance(x, dict) for x in value):
                        return self._json(400, {"error": "فهرست کیفیت/صدا/زیرنویس نامعتبر است"})
                    if any(len(json.dumps(x, ensure_ascii=False)) > 1000 for x in value):
                        return self._json(400, {"error": "اطلاعات هر گزینه بیش از حد مجاز است"})
                    item[key] = value
                elif key == "content_rating":
                    if not isinstance(value, str) or value not in ("همه سنین", "۷+", "۱۲+", "۱۵+", "۱۸+"):
                        return self._json(400, {"error": "رده‌بندی سنی نامعتبر است"})
                    item[key] = value
            item["updated_at"] = utcnow().isoformat()
            save(collection, items)
            singular = {"movies": "movie", "series": "series", "episodes": "episode"}[kind]
            audit_admin_action(user, f"{singular}_updated", singular, content_id,
                               {"updated_fields": sorted(body.keys())})
            return self._json(200, {"message": "اطلاعات محتوا به‌روزرسانی شد", "item": item})

        if path.startswith("/api/admin/support/tickets/"):
            try: tid = int(path.rsplit("/", 1)[1])
            except ValueError: return self._json(400, {"error": "شناسه نامعتبر"})
            tickets = load("support_tickets")
            ticket = next((t for t in tickets if t["id"] == tid), None)
            if not ticket: return self._json(404, {"error": "تیکت پیدا نشد"})
            if body.get("status") not in (None, "open", "in_progress", "answered", "closed"):
                return self._json(400, {"error": "وضعیت نامعتبر"})
            if body.get("priority") not in (None, "low", "normal", "high"):
                return self._json(400, {"error": "اولویت نامعتبر"})
            if "status" in body: ticket["status"] = body["status"]
            if "priority" in body: ticket["priority"] = body["priority"]
            ticket["updated_at"] = utcnow().isoformat(); save("support_tickets", tickets)
            audit_admin_action(user, "support_ticket_updated", "support_ticket", tid, {"status": ticket.get("status"), "priority": ticket.get("priority")})
            return self._json(200, {"message": "تیکت به‌روزرسانی شد"})
        if path.startswith("/api/admin/reports/"):
            try: rid = int(path.rsplit("/", 1)[1])
            except ValueError: return self._json(400, {"error": "شناسه نامعتبر"})
            reports = load("content_reports")
            report = next((r for r in reports if r["id"] == rid), None)
            if not report: return self._json(404, {"error": "گزارش پیدا نشد"})
            if body.get("status") not in ("in_review", "resolved", "rejected"):
                return self._json(400, {"error": "وضعیت نامعتبر"})
            report["status"] = body["status"]; report["updated_at"] = utcnow().isoformat()
            save("content_reports", reports)
            audit_admin_action(user, "content_report_updated", "content_report", rid, {"status": report["status"]})
            return self._json(200, {"message": "گزارش به‌روزرسانی شد"})
        return self._json(404, {"error": "مسیر یافت نشد"})

    def do_DELETE(self):
        path = urlparse(self.path).path.rstrip("/")
        user = get_user_from_auth(self)
        if not user or user.get("role") != "admin":
            return self._json(403, {"error": "دسترسی فقط برای مدیر"})

        if path.startswith("/api/movies/"):
            mid = int(path.split("/")[-1])
            movies = load("movies")
            m = next((x for x in movies if x["id"] == mid), None)
            if not m:
                return self._json(404, {"error": "فیلم یافت نشد"})
            m["is_active"] = False
            save("movies", movies)
            audit_admin_action(user, "movie_archived", "movie", mid, {"title": m.get("title")})
            return self._json(200, {"message": "فیلم حذف شد"})

        if path.startswith("/api/series/") and path.count("/") == 3 and "/seasons" not in path and "/episodes" not in path:
            sid = int(path.split("/")[-1])
            series_list = load("series")
            s = next((x for x in series_list if x["id"] == sid), None)
            if not s:
                return self._json(404, {"error": "سریال یافت نشد"})
            s["is_active"] = False
            save("series", series_list)
            audit_admin_action(user, "series_archived", "series", sid, {"title": s.get("title")})
            return self._json(200, {"message": "سریال حذف شد"})

        if path.startswith("/api/series/episodes/"):
            eid = int(path.split("/")[-1])
            episodes = load("episodes")
            e = next((x for x in episodes if x["id"] == eid), None)
            if not e:
                return self._json(404, {"error": "قسمت یافت نشد"})
            e["is_active"] = False
            save("episodes", episodes)
            audit_admin_action(user, "episode_archived", "episode", eid, {"title": e.get("title")})
            return self._json(200, {"message": "قسمت حذف شد"})

        return self._json(404, {"error": "مسیر یافت نشد"})

def ensure_admin():
    # Never create a known default administrator password.
    if not load("plans"):
        save("plans", [
            {"id": 1, "name": "ماهانه", "name_en": "monthly", "duration_days": 30, "price": 99000, "is_active": True},
            {"id": 2, "name": "سه‌ماهه", "name_en": "quarterly", "duration_days": 90, "price": 249000, "is_active": True},
            {"id": 3, "name": "شش‌ماهه", "name_en": "semi_annual", "duration_days": 180, "price": 449000, "is_active": True},
        ])
    for name in ("sessions", "support_tickets", "support_messages", "content_reports", "admin_audit_logs", "watch_progress"):
        if not load(name):
            save(name, [])

if __name__ == "__main__":
    initialize_storage()
    ensure_admin()
    server = HTTPServer((os.environ.get("HOST", "0.0.0.0"), PORT), Handler)
    print(f"CINEMA GOLD API v3.7.34 running on http://{os.environ.get('HOST', '0.0.0.0')}:{PORT}")
    print(f"Storage backend: {backend_name()}")
    print("Local development server only. Use HTTPS + production ASGI/WSGI deployment before public launch.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()
