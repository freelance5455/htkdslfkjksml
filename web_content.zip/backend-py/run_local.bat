@echo off
cd /d %~dp0
set APP_ENV=development
if not defined HOST set HOST=0.0.0.0
if not defined PORT set PORT=3000
if not exist .local_jwt_secret (
  python -c "import secrets; print(secrets.token_urlsafe(48))" > .local_jwt_secret
)
set /p JWT_SECRET=<.local_jwt_secret
python -c "from storage import initialize,load; initialize(); u=load('users'); import sys; sys.exit(0 if any(x.get('role')=='admin' and x.get('password','').startswith('pbkdf2_sha256$') for x in u) else 1)"
if errorlevel 1 (
  echo First set up the admin account:
  python setup_admin.py
  if errorlevel 1 exit /b 1
)
python server.py
