#!/usr/bin/env python3
"""Copy existing JSON collections into PostgreSQL without overwriting data by default."""
import argparse
import json
import os
from pathlib import Path

COLLECTIONS = (
    "admin_audit_logs", "comments", "content_reports", "downloads", "episodes", "movies", "payments",
    "plans", "ratings", "seasons", "series", "sessions", "subscriptions",
    "support_messages", "support_tickets", "users", "watch_progress",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace", action="store_true", help="replace each destination collection")
    args = parser.parse_args()
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        raise SystemExit("DATABASE_URL is not set")
    try:
        import psycopg
    except ImportError:
        raise SystemExit("Install dependencies first: pip install -r requirements.txt")

    data_dir = Path(__file__).parent / "data"
    with psycopg.connect(url) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS cinema_records (
            collection TEXT NOT NULL, record_key TEXT NOT NULL, payload JSONB NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY(collection, record_key))""")
        conn.execute("CREATE INDEX IF NOT EXISTS cinema_records_collection_idx ON cinema_records(collection)")
        for collection in COLLECTIONS:
            path = data_dir / f"{collection}.json"
            if not path.exists():
                continue
            records = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(records, list):
                raise SystemExit(f"Invalid JSON collection: {path.name}")
            count = conn.execute("SELECT COUNT(*) FROM cinema_records WHERE collection=%s", (collection,)).fetchone()[0]
            if count and not args.replace:
                print(f"SKIP {collection}: PostgreSQL already has {count} records (use --replace deliberately)")
                continue
            conn.execute("SELECT pg_advisory_xact_lock(hashtext(%s))", ("cinema:" + collection,))
            conn.execute("DELETE FROM cinema_records WHERE collection=%s", (collection,))
            for index, item in enumerate(records):
                if not isinstance(item, dict):
                    raise SystemExit(f"Invalid record in {path.name}: expected object")
                key = str(item.get("id", item.get("username", index)))
                conn.execute("INSERT INTO cinema_records(collection,record_key,payload) VALUES (%s,%s,%s::jsonb)",
                             (collection, key, json.dumps(item, ensure_ascii=False)))
            print(f"MIGRATED {collection}: {len(records)} records")
    print("Migration finished. Keep the JSON backup until PostgreSQL data is verified.")


if __name__ == "__main__":
    main()
