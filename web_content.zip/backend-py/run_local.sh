#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export APP_ENV=development
export HOST="${HOST:-0.0.0.0}"
export PORT="${PORT:-3000}"
SECRET_FILE=".local_jwt_secret"
if [[ ! -s "$SECRET_FILE" ]]; then
  python3 - <<'PY' > "$SECRET_FILE"
import secrets
print(secrets.token_urlsafe(48))
PY
  chmod 600 "$SECRET_FILE"
fi
export JWT_SECRET="$(cat "$SECRET_FILE")"
if ! python3 - <<'PY'
from storage import initialize, load
initialize()
users=load('users')
raise SystemExit(0 if any(u.get('role')=='admin' and u.get('password','').startswith('pbkdf2_sha256$') for u in users) else 1)
PY
then
  echo "Set up or rotate the administrator first: python3 setup_admin.py"
  python3 setup_admin.py
fi
python3 server.py
