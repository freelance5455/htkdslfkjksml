# Cross-Platform Mobile Deployment Guide
## Student Mark Entry System (`com.studentmarkentry.app`)

This project is fully enabled for **online app conversion** (via Microsoft PWABuilder, Google TWA, WebIntoApp) and **native cross-platform mobile export** (via Ionic Capacitor and Apache Cordova for iOS and Android).

---

## 🚀 Option 1: 100% Online Conversion (Zero Installation)

Online tools convert this live web application into signed Google Play and Apple App Store packages:

### A. Microsoft PWABuilder (Recommended for Google Play & iOS)
1. Open [https://www.pwabuilder.com](https://www.pwabuilder.com).
2. Enter your published app URL.
3. PWABuilder automatically validates:
   - ✅ **Web App Manifest**: `/manifest.webmanifest` & `/manifest.json` (ID, Scope, Display: Standalone, Theme Color, Orientation: Any).
   - ✅ **Service Worker**: `/sw.js` (Offline cache with CacheFirst / Stale-While-Revalidate).
   - ✅ **Icon Resolution**: 192x192, 512x512, Maskable 512x512, Apple Touch 180x180.
4. Click **"Package for Stores"**:
   - **Android**: Generates an Android App Bundle (`.aab`) and `.apk` ready for Google Play Console.
   - **iOS**: Generates an Apple Xcode project package with WebKit container for App Store / TestFlight.
   - **Windows**: Generates an `.msix` package for the Microsoft Store.

### B. WebIntoApp
1. Visit [https://www.webintoapp.com/maker](https://www.webintoapp.com/maker).
2. Enter your app URL.
3. Download the generated `.apk` for direct Android installation or `.ipa` for iOS.

---

## 📦 Option 2: Native Cross-Platform Deployment (Ionic Capacitor)

The repository is pre-configured with `capacitor.config.json` and `capacitor.config.ts`.

### 1. Install Capacitor runtimes
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
```

### 2. Build the web distribution bundle
```bash
npm run build
```

### 3. Add Android and iOS native platforms
```bash
npx cap add android
npx cap add ios
```

### 4. Sync web assets into native wrappers
```bash
npx cap sync
```

### 5. Open in Android Studio or Xcode
```bash
# Android (Compile APK / AAB, test on emulator or real Android device)
npx cap open android

# iOS (Requires macOS with Xcode to build and sign for iPhone/iPad)
npx cap open ios
```

---

## 🤖 Option 3: Google Bubblewrap CLI (Trusted Web Activity)

Google's official CLI tool generates Android Play Store packages directly from the web manifest:

```bash
# Install Bubblewrap CLI
npm i -g @bubblewrap/cli

# Initialize project using your manifest
bubblewrap init --manifest=https://your-domain.com/manifest.webmanifest

# Build the Android App Bundle (.aab)
bubblewrap build
```

---

## 📲 Option 4: In-App PWA Install (Direct to Device)

Users can install the app directly without any store:
- **Android / Chrome / Edge**: Tap **"Install App"** in the top navigation bar.
- **iOS Safari**: Tap **Share** (square with upward arrow) -> **Add to Home Screen** -> **Add**.

---

## 🎯 Mobile Enhancements Included

1. **Touch-Optimized Numeric Keypad**: All mark input fields feature `inputmode="decimal"` and `autocomplete="off"` so Android and iOS devices automatically display the large number keyboard with a decimal point.
2. **Haptic Touch Vibration**: Real-time tactile vibration feedback when typing marks, saving, deleting, or changing views (can be toggled in Mobile Studio).
3. **Safe Area Notch Padding**: Uses `env(safe-area-inset-top)` and `env(safe-area-inset-bottom)` to prevent iPhone Dynamic Island, notches, or Android system gesture bars from overlapping headers or buttons.
4. **100% Offline Capability**: All assets (including SheetJS and jsPDF) are precached locally; student records and marks are saved in persistent storage.
5. **Interactive In-App Mobile Studio**: Click the **"Mobile Deployment ▾"** button in the header to download a complete `.zip` mobile package or launch PWABuilder with one click.
