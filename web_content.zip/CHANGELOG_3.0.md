# X Gaming 3.0 — Changelog

- Native Android DownloadManager for APK/OBB/DATA.
- Android notification permission and background sync.
- Persistent PostgreSQL backend.
- Server-side user registration/login.
- Favorites.
- Safer server catalog sync: no destructive first-run purge.
- Existing UI/design preserved.
