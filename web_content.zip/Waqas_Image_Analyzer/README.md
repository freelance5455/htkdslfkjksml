# Waqas Image Analyzer

## Project structure
- `html/index.html` — page structure
- `css/style.css` — design, floating developer credit and heart animation
- `js/app.js` — upload, object detection, cropped object cards and controls
- `android-wrapper/` — notes for making an Android APK

## Run
For best results, serve the project with a local web server (rather than opening the HTML as a `file://` URL):
1. Extract the ZIP.
2. Open the project folder in VS Code.
3. Run a local server (for example, the Live Server extension).
4. Open `html/index.html`.

The first object analysis downloads TensorFlow.js and the COCO-SSD model from public CDNs, so an internet connection is needed initially. The uploaded image itself is processed in the browser and is not sent to an app server.

## What it does
- Selects a photo from the device.
- Detects common objects supported by COCO-SSD.
- Shows a separate cropped card and name for each detected object.
- Draws numbered detection boxes; labels can be hidden/shown.
- Clear image button resets the workspace.
- A small fixed left-side “Developed by Mr. Waqas” credit follows scrolling, with animated hearts.

## Android APK
This ZIP contains the web-app source, not a compiled APK. To make an APK, wrap the project with Capacitor and build it using Android Studio:
1. Install Node.js and Android Studio.
2. In a new Capacitor app, copy these `html`, `css`, and `js` folders into the web assets folder and set the web directory to the folder containing `index.html` (or move the three folders so `index.html` is at the web root).
3. Add the Android platform with `npx cap add android`.
4. Run `npx cap sync android`, open the Android project with `npx cap open android`, then build an APK in Android Studio.

Note: this is object detection, not pixel-perfect segmentation. It identifies supported objects (such as people, cars, phones, bottles, etc.) and crops each detected bounding box. Objects outside the model's supported classes may not be named.
