Android APK wrapper notes

The delivered ZIP is the HTML/CSS/JavaScript source project. A compiled APK requires Android SDK/Gradle tooling and signing/build configuration, which are not included here. Follow the APK steps in the root README using Capacitor + Android Studio.
