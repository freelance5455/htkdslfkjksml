const input = document.getElementById('imageInput');
const image = document.getElementById('sourceImage');
const canvas = document.getElementById('overlay');
const ctx = canvas.getContext('2d');
const workspace = document.getElementById('workspace');
const statusEl = document.getElementById('status');
const results = document.getElementById('results');
const detectBtn = document.getElementById('detectBtn');
const toggleBtn = document.getElementById('toggleBtn');
const clearBtn = document.getElementById('clearBtn');

let model = null;
let predictions = [];
let labelsVisible = true;
let objectUrl = null;

function setStatus(message) { statusEl.textContent = message; }

input.addEventListener('change', () => {
  const file = input.files && input.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) { setStatus('Please choose a valid image file.'); return; }
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = URL.createObjectURL(file);
  image.onload = () => {
    workspace.classList.remove('hidden');
    results.innerHTML = '<div class="empty">Tap “Analyze photo” to identify objects.</div>';
    predictions = [];
    clearOverlay();
    toggleBtn.disabled = true;
    setStatus('Photo ready. Tap Analyze photo.');
  };
  image.src = objectUrl;
});

function clearOverlay() {
  const rect = image.getBoundingClientRect();
  canvas.width = Math.max(1, Math.round(rect.width * devicePixelRatio));
  canvas.height = Math.max(1, Math.round(rect.height * devicePixelRatio));
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  ctx.clearRect(0, 0, rect.width, rect.height);
}
function drawBoxes() {
  clearOverlay();
  if (!labelsVisible) return;
  const scaleX = image.clientWidth / image.naturalWidth;
  const scaleY = image.clientHeight / image.naturalHeight;
  ctx.lineWidth = 2.5;
  ctx.font = 'bold 13px system-ui';
  predictions.forEach((p, i) => {
    const [x,y,w,h] = p.bbox;
    const dx=x*scaleX, dy=y*scaleY, dw=w*scaleX, dh=h*scaleY;
    ctx.strokeStyle = '#38bdf8'; ctx.fillStyle = '#0b1120dd';
    ctx.strokeRect(dx,dy,dw,dh);
    const label = `${i+1}. ${p.class}`;
    const tw = ctx.measureText(label).width + 12;
    ctx.fillRect(dx,Math.max(0,dy-23),tw,22);
    ctx.fillStyle='#fff'; ctx.fillText(label,dx+6,Math.max(15,dy-8));
  });
}
async function loadModel() {
  if (model) return model;
  if (!window.cocoSsd) throw new Error('The AI model library did not load. Check your internet connection and reload.');
  setStatus('Loading object recognition model…');
  model = await cocoSsd.load({base:'lite_mobilenet_v2'});
  return model;
}
detectBtn.addEventListener('click', async () => {
  if (!image.src) return;
  detectBtn.disabled = true;
  try {
    const detector = await loadModel();
    setStatus('Analyzing photo…');
    predictions = await detector.detect(image, 30, 0.35);
    labelsVisible = true;
    drawBoxes();
    showObjects();
    toggleBtn.disabled = predictions.length === 0;
    toggleBtn.textContent = 'Hide labels';
    setStatus(predictions.length ? `Found ${predictions.length} object(s).` : 'No recognizable objects found. Try a clearer photo.');
  } catch (err) {
    setStatus(err.message || 'Could not analyze this photo.');
  } finally { detectBtn.disabled = false; }
});
function showObjects() {
  results.innerHTML = '';
  if (!predictions.length) {
    results.innerHTML = '<div class="empty">No objects were detected in this photo.</div>';
    return;
  }
  const scaleX = image.naturalWidth / image.clientWidth;
  const scaleY = image.naturalHeight / image.clientHeight;
  predictions.forEach((p, index) => {
    const [x,y,w,h] = p.bbox;
    const crop = document.createElement('canvas');
    crop.width = Math.max(1, Math.round(w)); crop.height = Math.max(1, Math.round(h));
    const c = crop.getContext('2d');
    c.drawImage(image, x,y,w,h, 0,0,crop.width,crop.height);
    const card = document.createElement('article');
    card.className = 'object-card';
    const thumb = document.createElement('img');
    thumb.src = crop.toDataURL('image/jpeg', .88);
    thumb.alt = `Detected ${p.class}`;
    const name = document.createElement('div'); name.className='object-name';
    name.textContent = `${index+1}. ${p.class}`;
    const confidence = document.createElement('div'); confidence.className='confidence';
    confidence.textContent = `${Math.round(p.score*100)}% confidence`;
    card.append(thumb,name,confidence); results.append(card);
  });
}
toggleBtn.addEventListener('click', () => {
  labelsVisible = !labelsVisible; drawBoxes();
  toggleBtn.textContent = labelsVisible ? 'Hide labels' : 'Show labels';
});
clearBtn.addEventListener('click', () => {
  if (objectUrl) URL.revokeObjectURL(objectUrl);
  objectUrl = null; input.value=''; image.removeAttribute('src');
  workspace.classList.add('hidden'); predictions=[]; clearOverlay();
  setStatus('Waiting for an image…');
});
window.addEventListener('resize', () => { if (image.src && predictions.length) drawBoxes(); });
