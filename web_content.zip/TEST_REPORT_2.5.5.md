# ANONYMOUX STUDIO 2.5.5 — test report

## Executed checks

| Check | Result | Detail |
|---|---|---|
| PHP syntax | PASS | `php -l` passed for all 81 PHP files in the extracted application. |
| Agent browser JavaScript syntax | PASS | Node.js syntax check passed for `assets/agent-chat.js` and `assets/agent-studio.js`. |
| Billing source regression | PASS | Existing `tests/billing_source_check.py`. |
| SQLite wallet contract | PASS | Existing `tests/billing_sqlite_contract_check.py`: insufficient balance rollback, atomic reservation/refund and settled-operation protection. |
| Branding / voice integration | PASS | Existing `tests/branding_voice_integration_check.py`. |
| Tools & Tutorials admin regression | PASS | Existing `tests/resource_admin_regression_check.py`. |
| Resource migration regression | PASS | Existing `tests/resource_migration_check.py`. |
| Voice dashboard follow-up | PASS | Existing `tests/voice_dashboard_followup_check.py`. |
| Voice / Agent flow regression | PASS | Existing `tests/voice_flow_repair_check.py`, including saved agent voice override, SDK pin and usage idempotency checks. |
| Voice idempotency migration | PASS | Existing `tests/voice_idempotency_migration_check.py`. |
| New SQLite package migration | PASS | Python sqlite3 executed migration 003 and 006; verified new columns, inserted all four packages, and verified the 1000-kobo-per-credit relationship. |

## Not executable in this build environment

- `php tests/smoke.php` could not complete because this PHP runtime has PDO but **does not have the PDO_SQLITE driver**.
- PHP cURL is not installed in this build runtime. Therefore no live Fish Audio or Flutterwave API request was made.
- No Fish Audio API key, Flutterwave test credentials, or target shared-hosting environment was supplied for live acceptance.
- No browser automation runtime was available to perform real mobile checkout, admin UI interaction, or a full end-to-end session.

## Required deployment acceptance tests

1. On the target host, confirm PHP cURL, OpenSSL, PDO_SQLITE (or PDO MySQL), and outbound HTTPS are available.
2. In Admin → Voice AI, confirm an active Fish Audio key and the same encryption secret used to encrypt it. Create an agent, update/publish it, start a real voice/chat session, send a message, end the session and inspect sanitized logs and usage reconciliation.
3. In Flutterwave test mode, buy each package; verify pending, successful and failed outcomes, wrong amount/currency/reference rejection, repeated redirect and repeated webhook idempotency, and one ledger credit only.
4. Verify Explore remains accessible and `/shorts-studio.php` responds with HTTP 404.
5. Verify Tools & Tutorials on mobile and desktop using the production database and uploaded resource media.

**Release status:** Source-level changes and available automated regression checks passed. Production readiness and live integrations remain unverified pending the deployment-host tests above.
