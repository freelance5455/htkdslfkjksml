# المتداول الآلي — مشروع APK جاهز للبناء

## الطريقة 1: أندرويد ستوديو (كمبيوتر)
1. افتح مجلد TraderBot بـ Android Studio → انتظر Sync (يحتاج إنترنت أول مرة).
2. Build → Build APK(s) → الملف: app/build/outputs/apk/debug/app-debug.apk
3. انقله للجوال وثبّته (اسمح بالتثبيت من مصدر غير معروف).

## الطريقة 2: GitHub Actions (من الجوال بدون كمبيوتر)
1. أنشئ مستودع GitHub جديد (خاص).
2. ارفع كل الملفات بنفس المسارات (Add file → Create new file واكتب المسار كامل مع / ثم الصق المحتوى).
   الملفات: settings.gradle.kts • build.gradle.kts • gradle.properties • gradle/wrapper/gradle-wrapper.properties •
   app/build.gradle.kts • app/src/main/AndroidManifest.xml • app/src/main/java/com/trader/bot/Main.kt •
   app/src/main/assets/index.html • .github/workflows/build.yml
3. تبويب Actions → Build APK → Run workflow → بعد دقائق نزّل artifact باسم TraderBot-apk (فيه app-debug.apk).

## بعد التثبيت
- أول تشغيل يطلب إذن الإشعارات ثم استثناء البطارية: وافق عليهم.
- شاومي/هواوي/سامسونغ: فعّل «التشغيل التلقائي» وقفل التطبيق بقائمة التطبيقات الأخيرة (Lock)، وإلا الشركة تقتله.
- زر Back يخفي التطبيق فقط. للإيقاف الكامل اضغط «إيقاف كامل» بإشعار التطبيق.
- ابدأ بالوضع التجريبي، وجرّب قفل الشاشة 30 دقيقة وراجع تبويب 📒 السجل.
- لتحديث الواجهة: استبدل app/src/main/assets/index.html وابنِ من جديد.
