package com.trader.bot

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import androidx.webkit.WebViewAssetLoader

/** الـWebView الوحيد: يعيش مع العملية (وليس مع الواجهة) فيكمل البوت لو انغلقت الشاشة. */
object Bot {
    var wv: WebView? = null
    var ctx: MutableContextWrapper? = null
    var act: Activity? = null

    fun get(app: Context): WebView {
        wv?.let { return it }
        val c = MutableContextWrapper(app); ctx = c
        val w = WebView(c)
        w.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false; setSupportZoom(false) }
        w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        w.addJavascriptInterface(Bridge(app), "Android")
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(app)).build()
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                try { act?.startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (e: Exception) {}
                return true
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView, u: String, m: String, r: JsResult): Boolean { ask(m, r, false); return true }
            override fun onJsConfirm(v: WebView, u: String, m: String, r: JsResult): Boolean { ask(m, r, true); return true }
            override fun onJsPrompt(v: WebView, u: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val a = act
                if (a == null) { r.cancel(); return true }
                ask(m, r, true, EditText(a).apply { setText(d ?: "") }); return true
            }
        }
        w.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        wv = w; return w
    }

    fun ask(msg: String?, r: JsResult, neg: Boolean, et: EditText? = null) {
        val a = act
        if (a == null) { r.cancel(); return }
        val b = AlertDialog.Builder(a).setMessage(msg).setCancelable(true)
            .setOnCancelListener { r.cancel() }
            .setPositiveButton("موافق") { _, _ -> if (et != null) (r as JsPromptResult).confirm(et.text.toString()) else r.confirm() }
        if (neg) b.setNegativeButton("إلغاء") { _, _ -> r.cancel() }
        if (et != null) b.setView(et)
        b.show()
    }
}

/** الجسر: الصفحة تنادي Android.requestBackground() و Android.notify(نص) */
class Bridge(private val app: Context) {
    @JavascriptInterface fun requestBackground() { val a = Bot.act ?: return; a.runOnUiThread { askPerms(a) } }
    @JavascriptInterface fun notify(m: String) { Notif.alert(app, m) }
}

fun askPerms(a: Activity) {
    if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
        a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7); return
    }
    askBattery(a)
}

fun askBattery(a: Activity) {
    val pm = a.getSystemService(PowerManager::class.java)
    if (!pm.isIgnoringBatteryOptimizations(a.packageName))
        try { a.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + a.packageName))) } catch (e: Exception) {}
}

object Notif {
    const val FG = "fg"
    const val AL = "alerts"
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(FG, "التشغيل بالخلفية", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(AL, "تنبيهات التداول", NotificationManager.IMPORTANCE_HIGH))
    }
    fun open(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    fun alert(c: Context, m: String) {
        channels(c)
        val n = Notification.Builder(c, AL).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🤖 المتداول الآلي").setContentText(m)
            .setStyle(Notification.BigTextStyle().bigText(m))
            .setContentIntent(open(c)).setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % 100000).toInt() + 10, n)
    }
}

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Bot.act = this
        val w = Bot.get(applicationContext)
        Bot.ctx?.setBaseContext(this)
        (w.parent as? ViewGroup)?.removeView(w)
        setContentView(w)
        startForegroundService(Intent(this, BotService::class.java))
        val p = getSharedPreferences("p", 0)
        if (!p.getBoolean("asked", false)) { p.edit().putBoolean("asked", true).apply(); askPerms(this) }
    }
    override fun onResume() { super.onResume(); Bot.act = this; Bot.ctx?.setBaseContext(this) }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        askBattery(this)
    }
    @Deprecated("back = إخفاء فقط، البوت يكمل")
    override fun onBackPressed() { moveTaskToBack(true) }
    override fun onDestroy() {
        if (Bot.act === this) {
            Bot.act = null
            Bot.ctx?.setBaseContext(applicationContext)
            (Bot.wv?.parent as? ViewGroup)?.removeView(Bot.wv)
        }
        super.onDestroy()
    }
}

class BotService : Service() {
    private var wl: PowerManager.WakeLock? = null
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") {
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            android.os.Process.killProcess(android.os.Process.myPid())
            return START_NOT_STICKY
        }
        Notif.channels(this)
        val stop = PendingIntent.getService(this, 1, Intent(this, BotService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, Notif.FG).setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("المتداول الآلي يعمل").setContentText("يمسح السوق ويتداول بالخلفية")
            .setContentIntent(Notif.open(this)).setOngoing(true)
            .addAction(Notification.Action.Builder(0, "إيقاف كامل", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        if (wl == null) wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bot:run").apply { acquire() }
        Bot.get(applicationContext)
        return START_STICKY
    }
    override fun onDestroy() { wl?.let { if (it.isHeld) it.release() }; super.onDestroy() }
}
