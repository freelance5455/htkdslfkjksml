V30 পরিবর্তন:
- Full Screen চালুর সময় requestFullscreen({navigationUI: "hide"}) ব্যবহার করা হয়েছে, যাতে ব্রাউজারের নেভিগেশন UI লুকানোর অনুরোধ করা হয়।
- Android Chrome-এর নিজস্ব Full Screen নিরাপত্তা/এক্সিট নির্দেশনা Toast ওয়েবপেজ বা HTML থেকে বন্ধ করা যায় না। এটি Chrome/Android সিস্টেম UI; APK-এর ভিতরে চললে আচরণ আলাদা হতে পারে।
- বাকি ফিচার V28 থেকে অপরিবর্তিত।
