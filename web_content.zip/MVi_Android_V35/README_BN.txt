MVi Video Player — Native Android Project (V36 Native Bridge)
============================================================

এই প্রজেক্টটি HTML-to-APK Builder-এর জন্য নয়। এটি সম্পূর্ণ Android Studio Gradle project।

যা আছে
------
1. WebView-এর মধ্যে আগের MVi V35 HTML player interface রাখা হয়েছে।
2. Android 11+ এ All files access Settings flow; অনুমতি দিলে Internal Shared Storage এবং ফোনে Android যেসব removable volume expose করে সেগুলো scan করার চেষ্টা করে।
3. MediaStore index + accessible filesystem scan একত্র করে ভিডিও তালিকা বানায়; ফাইলের আসল নাম ও relative folder path রাখে।
4. OTG/USB বা Android-এর scoped access-এ থাকা removable folder-এর জন্য ACTION_OPEN_DOCUMENT_TREE একবার ব্যবহার করে persistent read permission নেয়। অনুমতি Android-এ সংরক্ষিত থাকে; প্রতিটি ভিডিও আলাদা করে বাছাই করতে হয় না।
5. Native Media3 ExoPlayer + MediaSessionService: স্টোরেজ থেকে খোলা content:// বা file:// ভিডিও Background Play mode চালু থাকলে Native playback service-এ পাঠানো হয়। Notification/media controls Android সামলায়।
6. Native PiP Activity: নির্বাচিত ভিডিও/ভিডিওগুলোর queue-তে একটি করে ভিডিও চলে এবং Android Picture-in-Picture-এ বর্তমান ভিডিও ছোট উইন্ডোতে দেখা যায়। Android-এর standard PiP এক উইন্ডোতে একটিমাত্র video surface দেখায়; একসঙ্গে একাধিক ভিডিওর grid PiP হিসেবে সম্ভব নয়।

গুরুত্বপূর্ণ সীমাবদ্ধতা ও অনুমতি
------------------------------
- Android All files access একটি বিশেষ Settings permission। এটি স্বয়ংক্রিয়ভাবে grant করা যায় না; ব্যবহারকারীকে Settings-এ Allow দিতে হয়। কিছু নির্মাতা/Android সংস্করণে SD/USB volume আলাদাভাবে দেখায় বা সীমাবদ্ধ করে।
- OTG-এর ক্ষেত্রে Android SAF folder picker-এ একবার সংশ্লিষ্ট USB/OTG root folder নির্বাচন করে Use this folder চাপতে হবে। USB বিচ্ছিন্ন/পুনরায় যুক্ত হলে কিছু ফোনে grant পুনরায় চাইতে পারে।
- Android standard PiP-তে একসঙ্গে একটিমাত্র video surface থাকে। এখানে একাধিক নির্বাচিত ভিডিও queue আকারে পরপর চালানো যায়, grid আকারে একসঙ্গে নয়।
- Native background playback-এ Android Media3 service ব্যবহার করা হয়েছে। HTML Blob/File input থেকে যোগ করা অস্থায়ী browser object URL Native service-এ পাঠানো যায় না; Storage library থেকে content:// বা file:// ভিডিও চালাতে হবে।
- Android 13+ এ Notification permission না দিলে playback চললেও notification controls দেখা নাও যেতে পারে।
- MANAGE_EXTERNAL_STORAGE Google Play-তে কঠোরভাবে সীমাবদ্ধ। ব্যক্তিগত sideload/test APK-তে ব্যবহার করা যায়; Play Store-এ প্রকাশের আগে নীতিমালা যাচাই করতে হবে।

Build করার নিয়ম
----------------
1. ZIP extract করুন।
2. Android Studio > Open > MVi_Android_V35 ফোল্ডার নির্বাচন করুন (যে ফোল্ডারে settings.gradle আছে)।
3. Gradle sync সম্পন্ন হতে দিন। Internet প্রয়োজন, কারণ Android Gradle Plugin ও Media3 dependency download হবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s)।
5. app/build/outputs/apk/debug/app-debug.apk ইনস্টল করে পরীক্ষা করুন।

Package: com.civiltech.mviplayer
Min SDK: 26 (Android 8.0)
Compile/Target SDK: 35
Version: 36.0

এটি source project; এই পরিবেশে Android SDK/Gradle দিয়ে বাস্তব APK build ও ফোনে পরীক্ষা করা হয়নি। প্রথম ইনস্টলের পর Storage access Settings এবং প্রয়োজন হলে OTG root folder একবার অনুমোদন দিন।
