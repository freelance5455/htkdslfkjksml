package com.civiltech.mviplayer

import android.content.Intent
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Real Android media playback service. Media3 owns decoding and the media notification. */
class MviPlaybackService : MediaSessionService() {
    private lateinit var player: ExoPlayer
    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val raw = intent.getStringExtra(EXTRA_URI)
                if (!raw.isNullOrBlank()) {
                    val item = MediaItem.Builder().setUri(Uri.parse(raw))
                        .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(intent.getStringExtra(EXTRA_TITLE) ?: "MVi Video Player").build()).build()
                    player.setMediaItem(item)
                    player.prepare()
                    player.playWhenReady = true
                }
            }
            ACTION_PAUSE -> player.pause()
            ACTION_RESUME -> player.play()
            ACTION_STOP -> { player.stop(); stopSelf() }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        mediaSession?.run { player.release(); release() }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.civiltech.mviplayer.PLAY"
        const val ACTION_PAUSE = "com.civiltech.mviplayer.PAUSE"
        const val ACTION_RESUME = "com.civiltech.mviplayer.RESUME"
        const val ACTION_STOP = "com.civiltech.mviplayer.STOP"
        const val EXTRA_URI = "uri"
        const val EXTRA_TITLE = "title"
    }
}
