package com.civiltech.mviplayer

import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray

/** Native one-window floating player. Android PiP supports one video surface per window. */
class NativePipActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        val root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        val playerView = PlayerView(this).apply { useController = true }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        val pipButton = Button(this).apply {
            text = "ছোট উইন্ডো"
            setOnClickListener { enterNativePip() }
        }
        root.addView(pipButton, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        setContentView(root)

        val urls = try { JSONArray(intent.getStringExtra("urls") ?: "[]") } catch (_: Exception) { JSONArray() }
        val items = ArrayList<MediaItem>()
        for (i in 0 until urls.length()) {
            val raw = urls.optString(i)
            if (raw.startsWith("content:") || raw.startsWith("file:")) items.add(MediaItem.fromUri(raw))
        }
        if (items.isEmpty()) { finish(); return }
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItems(items)
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    private fun enterNativePip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) } catch (_: Exception) { }
        }
    }

    override fun onUserLeaveHint() { super.onUserLeaveHint(); enterNativePip() }
    override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
