package com.civiltech.mviplayer

import android.Manifest
import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import java.io.File
import android.provider.MediaStore
import android.util.Rational
import android.view.View
import android.view.WindowManager
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * MVi native storage bridge.
 * Uses Android MediaStore's VIDEO collection only; it never uploads files and
 * never asks the user to pick a folder. Runtime permission is requested once.
 */
class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var pageReady = false
    @Volatile private var scanRunning = false
    @Volatile private var pendingRescan = false
    private val prefs by lazy { getSharedPreferences("mvi_storage", MODE_PRIVATE) }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        prefs.edit().putBoolean("video_permission_request_attempted", true).apply()
        if (granted) scanAllVideos() else sendPermissionStatus(false)
    }

    private val allFilesSettings = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (hasBroadStorageAccess()) scanAllVideos() else sendPermissionStatus(false)
    }

    // SAF is required for removable USB/OTG folders and provides persistent,
    // user-approved access without requesting unrestricted MANAGE_EXTERNAL_STORAGE.
    private val treePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val uri = result.data?.data
            if (uri != null) {
                val flags = result.data?.flags?.and(Intent.FLAG_GRANT_READ_URI_PERMISSION) ?: 0
                try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) { }
                val saved = prefs.getStringSet("storage_tree_uris", emptySet())?.toMutableSet() ?: mutableSetOf()
                saved.add(uri.toString())
                prefs.edit().putStringSet("storage_tree_uris", saved).apply()
                web.postDelayed({ scanAllVideos() }, 500)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyImmersiveMode()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowContentAccess = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.setSupportMultipleWindows(true)
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                requestPermissionOnceOrScan()
            }
        }
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Back is always handled inside the player. At the root screen it
                // stays in the app instead of showing an exit confirmation.
                web.evaluateJavascript("window.closeActiveWindowFromAndroid && window.closeActiveWindowFromAndroid()", null)
            }
        })
    }

    /** Keep Android status/navigation bars hidden while the player is active.
     * Re-apply after focus returns so transient system bars do not remain visible.
     */
    private fun applyImmersiveMode() {
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    override fun onResume() {
        super.onResume()
        // Returning to the app refreshes the index automatically. No new dialog
        // is shown here; Android keeps a granted runtime permission across launches.
        if (pageReady && (hasBroadStorageAccess() || hasVideoPermission())) web.postDelayed({ scanAllVideos() }, 250)
    }

    private fun videoPermission(): String = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasVideoPermission(): Boolean = ContextCompat.checkSelfPermission(this, videoPermission()) == PackageManager.PERMISSION_GRANTED

    private fun hasBroadStorageAccess(): Boolean = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else hasVideoPermission()

    private fun requestPermissionOnceOrScan() {
        // Android 11+: request the system's "All files access" once. This is the
        // file-manager style permission needed for recursive local/SD scanning.
        if (Build.VERSION.SDK_INT >= 30 && !hasBroadStorageAccess()) {
            if (!prefs.getBoolean("all_files_access_prompted", false)) {
                prefs.edit().putBoolean("all_files_access_prompted", true).apply()
                launchAllFilesAccessSettings()
            } else sendPermissionStatus(false)
            return
        }
        if (Build.VERSION.SDK_INT < 30 && !hasVideoPermission()) {
            val attempted = prefs.getBoolean("video_permission_request_attempted", false)
            if (!attempted) {
                prefs.edit().putBoolean("video_permission_request_attempted", true).apply()
                permissionRequest.launch(videoPermission())
            } else sendPermissionStatus(false)
            return
        }
        scanAllVideos()
    }

    inner class AndroidBridge {
        @JavascriptInterface fun requestVideoStoragePermission() {
            runOnUiThread { requestPermissionOnceOrScan() }
        }
        @JavascriptInterface fun rescanVideoFolders() {
            runOnUiThread {
                if (hasBroadStorageAccess() || hasVideoPermission()) scanAllVideos() else requestPermissionOnceOrScan()
            }
        }
        @JavascriptInterface fun addStorageFolder() {
            runOnUiThread { launchStorageFolderPicker() }
        }
        @JavascriptInterface fun requestAllFilesAccess() {
            runOnUiThread { launchAllFilesAccessSettings() }
        }
        @JavascriptInterface fun openAppPermissionSettings() {
            runOnUiThread {
                try {
                    val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun openVideoPopup(urlsJson: String) {
            runOnUiThread {
                try {
                    val intent = Intent(this@MainActivity, NativePipActivity::class.java)
                    intent.putExtra("urls", urlsJson)
                    startActivity(intent)
                } catch (_: Exception) { sendPermissionStatus(hasBroadStorageAccess() || hasVideoPermission()) }
            }
        }
        @JavascriptInterface fun startNativeBackground(uri: String, title: String) {
            runOnUiThread {
                if (!uri.startsWith("content:") && !uri.startsWith("file:")) return@runOnUiThread
                val intent = Intent(this@MainActivity, MviPlaybackService::class.java).apply {
                    action = MviPlaybackService.ACTION_PLAY
                    putExtra(MviPlaybackService.EXTRA_URI, uri)
                    putExtra(MviPlaybackService.EXTRA_TITLE, title)
                }
                try { if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent) } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun pauseNativeBackground() = runOnUiThread {
            startService(Intent(this@MainActivity, MviPlaybackService::class.java).setAction(MviPlaybackService.ACTION_PAUSE))
        }
        @JavascriptInterface fun resumeNativeBackground() = runOnUiThread {
            startService(Intent(this@MainActivity, MviPlaybackService::class.java).setAction(MviPlaybackService.ACTION_RESUME))
        }
        @JavascriptInterface fun stopNativeBackground() = runOnUiThread {
            startService(Intent(this@MainActivity, MviPlaybackService::class.java).setAction(MviPlaybackService.ACTION_STOP))
        }
    }

    private fun scanAllVideos() {
        if (!hasBroadStorageAccess() && !hasVideoPermission()) return
        if (scanRunning) { pendingRescan = true; return }
        scanRunning = true
        if (::web.isInitialized && pageReady) web.post { web.evaluateJavascript("window.onNativeFolderScanStart && window.onNativeFolderScanStart()", null) }
        worker.execute {
            val rows = JSONArray()
            scanMediaStoreVideos(rows)
            if (hasBroadStorageAccess()) scanAccessibleStorageFiles(rows)
            scanGrantedTreeFolders(rows)
            runOnUiThread {
                scanRunning = false
                if (!isFinishing && pageReady) {
                    // Transfer small batches to WebView instead of one huge JSON payload.
                    // This keeps the UI responsive with thousands of indexed videos.
                    val batchSize = 150
                    var start = 0
                    while (start < rows.length()) {
                        val batch = JSONArray()
                        val end = minOf(start + batchSize, rows.length())
                        for (i in start until end) batch.put(rows.getJSONObject(i))
                        val safe = JSONObject.quote(batch.toString())
                        web.evaluateJavascript("window.onNativeFolderScanChunk && window.onNativeFolderScanChunk($safe)", null)
                        start = end
                    }
                    web.evaluateJavascript("window.onNativeFolderScanComplete && window.onNativeFolderScanComplete()", null)
                    sendPermissionStatus(true)
                }
                if (pendingRescan) {
                    pendingRescan = false
                    web.postDelayed({ scanAllVideos() }, 250)
                }
            }
        }
    }

    private fun launchAllFilesAccessSettings() {
        if (Build.VERSION.SDK_INT < 30 || hasBroadStorageAccess()) { scanAllVideos(); return }
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            allFilesSettings.launch(intent)
        } catch (_: Exception) {
            try { allFilesSettings.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            catch (_: Exception) { sendPermissionStatus(false) }
        }
    }

    private fun launchStorageFolderPicker() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            }
            treePicker.launch(intent)
        } catch (_: Exception) {
            sendPermissionStatus(hasVideoPermission())
        }
    }

    /** Recursively scan shared storage after the user explicitly grants Android
     * All files access. This avoids asking for each video and includes files not
     * indexed by MediaStore. OTG providers may still require one SAF folder grant.
     */
    private fun scanAccessibleStorageFiles(rows: JSONArray) {
        val roots = linkedSetOf<File>()
        roots.add(Environment.getExternalStorageDirectory())
        try {
            getExternalFilesDirs(null).filterNotNull().forEach { appDir ->
                var root: File? = appDir
                repeat(4) { if (root?.parentFile != null) root = root?.parentFile }
                root?.let { roots.add(it) }
            }
        } catch (_: Exception) { }
        val storageDir = File("/storage")
        storageDir.listFiles()?.filter { it.isDirectory && it.name !in setOf("emulated", "self") }?.forEach { roots.add(it) }
        val seen = HashSet<String>()
        for (i in 0 until rows.length()) try { seen.add(rows.getJSONObject(i).optString("url")) } catch (_: Exception) { }
        roots.filter { it.exists() && it.canRead() }.forEach { root ->
            walkStorage(root, root.absolutePath, rows, seen)
        }
    }

    private fun walkStorage(dir: File, rootPath: String, rows: JSONArray, seen: MutableSet<String>) {
        val children = try { dir.listFiles() ?: return } catch (_: Exception) { return }
        for (file in children) {
            try {
                val path = file.absolutePath
                // Avoid protected/system trees, app-private data and symlink loops.
                if (file.isDirectory) {
                    if (file.name in setOf("Android", ".thumbnails", "LOST.DIR") && path != rootPath) continue
                    if (file.canonicalPath != path) continue
                    walkStorage(file, rootPath, rows, seen)
                } else if (file.isFile && isVideoExtension(file.name)) {
                    val uri = Uri.fromFile(file).toString()
                    if (seen.add(uri)) {
                        val rel = path.removePrefix(rootPath).trimStart('/')
                        rows.put(JSONObject().put("id", uri).put("name", file.name)
                            .put("path", rel).put("url", uri).put("mime", "video/*"))
                    }
                }
            } catch (_: SecurityException) { } catch (_: Exception) { }
        }
    }

    /** Recursively index only video files inside folders explicitly approved by
     * the user. This is how USB OTG and providers outside MediaStore are covered.
     */
    private fun scanGrantedTreeFolders(rows: JSONArray) {
        val roots = prefs.getStringSet("storage_tree_uris", emptySet())?.toList() ?: emptyList()
        val seen = HashSet<String>()
        for (i in 0 until rows.length()) {
            try { seen.add(rows.getJSONObject(i).optString("url")) } catch (_: Exception) { }
        }
        roots.forEach { raw ->
            try {
                val root = DocumentFile.fromTreeUri(this, Uri.parse(raw)) ?: return@forEach
                scanDocumentTree(root, "", rows, seen)
            } catch (_: SecurityException) { }
            catch (_: Exception) { }
        }
    }

    private fun scanDocumentTree(dir: DocumentFile, relative: String, rows: JSONArray, seen: MutableSet<String>) {
        val children = try { dir.listFiles() } catch (_: Exception) { return }
        children.forEach { child ->
            try {
                val name = child.name ?: return@forEach
                val path = if (relative.isBlank()) name else "$relative/$name"
                if (child.isDirectory) {
                    scanDocumentTree(child, path, rows, seen)
                } else if (child.isFile && isVideoExtension(name)) {
                    val uri = child.uri.toString()
                    if (seen.add(uri)) rows.put(JSONObject()
                        .put("id", uri).put("name", name).put("path", path)
                        .put("url", uri).put("mime", child.type ?: "video/*"))
                }
            } catch (_: Exception) { }
        }
    }

    /** Query the aggregated external volume on Android 10+, which covers indexed
     * shared videos across internal storage and SD cards. Older Android uses the
     * legacy external video collection. Only MediaStore.Video rows are returned.
     */
    private fun scanMediaStoreVideos(rows: JSONArray) {
        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val projection = mutableListOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.SIZE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) projection.add(MediaStore.Video.Media.RELATIVE_PATH)
        else projection.add(MediaStore.Video.Media.DATA)

        val sort = "${MediaStore.Video.Media.BUCKET_DISPLAY_NAME} COLLATE NOCASE, ${MediaStore.Video.Media.DISPLAY_NAME} COLLATE NOCASE"
        try {
            contentResolver.query(collection, projection.toTypedArray(), null, null, sort)?.use { c: Cursor ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val mimeCol = c.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = c.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val pathCol = c.getColumnIndex(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) MediaStore.Video.Media.RELATIVE_PATH else MediaStore.Video.Media.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val name = c.getString(nameCol) ?: continue
                    // Defensive extension check: even if a provider has a bad MIME
                    // value, non-video documents/images cannot enter this list.
                    if (!isVideoExtension(name)) continue
                    val bucket = if (bucketCol >= 0) c.getString(bucketCol) else null
                    val rawPath = if (pathCol >= 0) c.getString(pathCol) else null
                    val folder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        rawPath?.trimEnd('/')?.takeIf { it.isNotBlank() } ?: bucket ?: "অন্যান্য ভিডিও"
                    else rawPath?.substringBeforeLast('/', "")?.takeIf { it.isNotBlank() } ?: bucket ?: "অন্যান্য ভিডিও"
                    val uri = Uri.withAppendedPath(collection, id.toString())
                    val mime = if (mimeCol >= 0) c.getString(mimeCol) else null
                    rows.put(JSONObject()
                        .put("id", uri.toString())
                        .put("name", name)
                        .put("path", "$folder/$name")
                        .put("url", uri.toString())
                        .put("mime", mime ?: "video/*"))
                }
            }
        } catch (_: SecurityException) {
            // Permission may have been revoked in Android Settings.
        } catch (_: Exception) { }
    }

    private fun isVideoExtension(name: String): Boolean = name.lowercase().matches(
        Regex(".*\\.(mp4|m4v|mkv|webm|mov|avi|3gp|3g2|ts|m2ts|mts|mpg|mpeg|mpe|m2v|ogv|wmv|flv|f4v|vob|divx|asf)$")
    )

    private fun sendPermissionStatus(granted: Boolean) {
        if (!::web.isInitialized || !pageReady) return
        web.post {
            web.evaluateJavascript("window.onNativePermissionStatus && window.onNativePermissionStatus(${if (granted) "true" else "false"})", null)
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
