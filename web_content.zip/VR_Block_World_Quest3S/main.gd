extends Node3D

const BLOCK_SIZE := 1.0
const GRID_RADIUS := 5
const MAX_RAY_DISTANCE := 8.0

var xr_interface: XRInterface
var xr_origin: XROrigin3D
var xr_camera: XRCamera3D
var left_controller: XRController3D
var right_controller: XRController3D
var block_materials: Dictionary = {}
var blocks: Dictionary = {}
var ray_line: MeshInstance3D
var status_label: Label3D
var last_trigger := false
var last_grip := false

func _ready() -> void:
    _setup_xr()
    _make_materials()
    _build_scene()
    _build_world()
    _make_ray_visual()
    _make_status()

func _setup_xr() -> void:
    xr_interface = XRServer.find_interface("OpenXR")
    if xr_interface and xr_interface.is_initialized():
        get_viewport().use_xr = true
    elif xr_interface:
        var ok := xr_interface.initialize()
        if ok:
            get_viewport().use_xr = true
        else:
            push_warning("OpenXR не запустился. Проверь настройки Godot и устройство.")
    else:
        push_warning("Интерфейс OpenXR не найден. Проверь сборку Godot с OpenXR.")

    xr_origin = XROrigin3D.new()
    xr_origin.name = "XROrigin3D"
    add_child(xr_origin)

    xr_camera = XRCamera3D.new()
    xr_camera.name = "XRCamera3D"
    xr_origin.add_child(xr_camera)
    xr_camera.position = Vector3(0, 1.65, 0)

    left_controller = XRController3D.new()
    left_controller.name = "LeftHand"
    left_controller.tracker = "left_hand"
    xr_origin.add_child(left_controller)

    right_controller = XRController3D.new()
    right_controller.name = "RightHand"
    right_controller.tracker = "right_hand"
    xr_origin.add_child(right_controller)

    # Простые видимые модели рук-контроллеров для прототипа.
    _add_hand_model(left_controller, Color(0.25, 0.55, 1.0))
    _add_hand_model(right_controller, Color(1.0, 0.55, 0.25))

func _add_hand_model(parent: Node3D, tint: Color) -> void:
    var hand := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = Vector3(0.12, 0.08, 0.18)
    hand.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = tint
    mat.roughness = 0.8
    hand.material_override = mat
    hand.position = Vector3(0, 0, -0.08)
    parent.add_child(hand)

func _make_materials() -> void:
    block_materials["grass"] = _material(Color(0.22, 0.62, 0.18))
    block_materials["dirt"] = _material(Color(0.42, 0.25, 0.12))
    block_materials["stone"] = _material(Color(0.48, 0.50, 0.53))
    block_materials["wood"] = _material(Color(0.48, 0.30, 0.12))

func _material(color: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = 1.0
    return m

func _build_scene() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.sky.sky_material = ProceduralSkyMaterial.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.7, 0.78, 0.9)
    env.ambient_light_energy = 0.8
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -30, 0)
    sun.light_energy = 1.1
    add_child(sun)

func _build_world() -> void:
    for x in range(-GRID_RADIUS, GRID_RADIUS + 1):
        for z in range(-GRID_RADIUS, GRID_RADIUS + 1):
            _add_block(Vector3i(x, -1, z), "dirt")
            _add_block(Vector3i(x, 0, z), "grass")
    # Маленький каменный столб для теста разрушения.
    for y in range(1, 4):
        _add_block(Vector3i(2, y, -2), "stone")
    for y in range(1, 3):
        _add_block(Vector3i(-2, y, -2), "wood")

func _add_block(cell: Vector3i, kind: String) -> void:
    if blocks.has(cell):
        return
    var body := StaticBody3D.new()
    body.name = "Block_%s_%s_%s" % [cell.x, cell.y, cell.z]
    body.position = Vector3(cell.x, cell.y, cell.z)
    var mesh_instance := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3.ONE * BLOCK_SIZE
    mesh_instance.mesh = box
    mesh_instance.material_override = block_materials.get(kind, block_materials["grass"])
    body.add_child(mesh_instance)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3.ONE * BLOCK_SIZE
    collision.shape = shape
    body.add_child(collision)
    body.set_meta("cell", cell)
    body.set_meta("kind", kind)
    add_child(body)
    blocks[cell] = body

func _make_ray_visual() -> void:
    ray_line = MeshInstance3D.new()
    var line_mesh := ImmediateMesh.new()
    ray_line.mesh = line_mesh
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = Color(1.0, 0.9, 0.25)
    ray_line.material_override = mat
    add_child(ray_line)

func _make_status() -> void:
    status_label = Label3D.new()
    status_label.text = "VR Block World | Trigger: ломать | Grip: ставить"
    status_label.position = Vector3(-2.0, 3.0, -2.0)
    status_label.font_size = 32
    status_label.pixel_size = 0.003
    add_child(status_label)

func _process(_delta: float) -> void:
    if not is_instance_valid(right_controller):
        return
    var origin := right_controller.global_position
    var direction := -right_controller.global_basis.z
    var end := origin + direction * MAX_RAY_DISTANCE
    _update_ray(origin, end)

    var hit := _raycast(origin, end)
    var trigger := _button_pressed(right_controller, "trigger")
    var grip := _button_pressed(right_controller, "grip_click") or _button_pressed(right_controller, "grip")

    if hit and trigger and not last_trigger:
        var collider = hit.get("collider")
        if collider and collider is Node and collider.has_meta("cell"):
            var cell: Vector3i = collider.get_meta("cell")
            blocks.erase(cell)
            collider.queue_free()
    if hit and grip and not last_grip:
        var collider = hit.get("collider")
        if collider and collider is Node and collider.has_meta("cell"):
            var cell: Vector3i = collider.get_meta("cell")
            var normal: Vector3 = hit.get("normal")
            var offset := Vector3i(roundi(normal.x), roundi(normal.y), roundi(normal.z))
            _add_block(cell + offset, "grass")

    last_trigger = trigger
    last_grip = grip

func _button_pressed(controller: XRController3D, action: String) -> bool:
    # Godot/OpenXR action names depend on the project's action map and controller profile.
    # Try common action names; if no action map exists, return false safely.
    if controller.get_input(action) is bool:
        return controller.get_input(action)
    return false

func _raycast(from: Vector3, to: Vector3) -> Dictionary:
    var query := PhysicsRayQueryParameters3D.create(from, to)
    query.collide_with_areas = false
    query.collide_with_bodies = true
    return get_world_3d().direct_space_state.intersect_ray(query)

func _update_ray(from: Vector3, to: Vector3) -> void:
    var mesh := ray_line.mesh as ImmediateMesh
    mesh.clear_surfaces()
    mesh.surface_begin(Mesh.PRIMITIVE_LINES)
    mesh.surface_add_vertex(ray_line.to_local(from))
    mesh.surface_add_vertex(ray_line.to_local(to))
    mesh.surface_end()
