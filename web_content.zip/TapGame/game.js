let score = 0;
const box = document.getElementById("box");
const scoreText = document.getElementById("score");

function moveBox() {
    const x = Math.random() * (window.innerWidth - 70);
    const y = Math.random() * (window.innerHeight - 70);

    box.style.left = x + "px";
    box.style.top = y + "px";
}

box.onclick = function () {
    score++;
    scoreText.textContent = score;
    moveBox();
};

moveBox();