plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.richar.kdramaplus"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.richar.kdramaplus"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-demo"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:25.5.0")
}
