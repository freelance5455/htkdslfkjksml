package com.richar.kdramaplus

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.richar.kdramaplus.ads.RewardedAdsManager

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var rewardedAds: RewardedAdsManager

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        rewardedAds = RewardedAdsManager(this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AdsBridge(), "KDramaNative")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
        rewardedAds.initializeAndLoad { ready ->
            if (!ready) runOnUiThread {
                Toast.makeText(this, "Anuncio de prueba no disponible todavía. Intenta otra vez.", Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class AdsBridge {
        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                rewardedAds.show(this@MainActivity,
                    onRewardEarned = { amount, _ ->
                        webView.evaluateJavascript("window.onNativeReward && window.onNativeReward($amount)", null)
                    },
                    onUnavailable = {
                        Toast.makeText(this@MainActivity, "El anuncio todavía está cargando. Pulsa de nuevo en unos segundos.", Toast.LENGTH_LONG).show()
                    })
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
