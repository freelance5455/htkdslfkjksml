package com.richar.kdramaplus.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class RewardedAdsManager(private val context: Context) {
    private var rewardedAd: RewardedAd? = null
    private var loading = false
    private var initialized = false
    private var pendingReady: ((Boolean) -> Unit)? = null

    companion object {
        // Google's official TEST rewarded-ad unit. Never use live ads for development.
        const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    }

    fun initializeAndLoad(onReady: (Boolean) -> Unit = {}) {
        if (initialized) { load(onReady); return }
        MobileAds.initialize(context) {
            initialized = true
            load(onReady)
        }
    }

    fun load(onReady: (Boolean) -> Unit = {}) {
        if (loading) { pendingReady = onReady; return }
        loading = true
        RewardedAd.load(context, TEST_REWARDED_AD_UNIT_ID, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    loading = false
                    rewardedAd = ad
                    onReady(true)
                    pendingReady?.invoke(true)
                    pendingReady = null
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    loading = false
                    rewardedAd = null
                    onReady(false)
                    pendingReady?.invoke(false)
                    pendingReady = null
                }
            })
    }

    fun show(activity: Activity, onRewardEarned: (amount: Int, type: String) -> Unit, onUnavailable: () -> Unit) {
        val ad = rewardedAd
        if (ad == null) {
            onUnavailable()
            load()
            return
        }
        rewardedAd = null
        ad.show(activity) { rewardItem ->
            // This callback is the only place where the app grants the ad reward.
            onRewardEarned(rewardItem.amount, rewardItem.type)
        }
        load()
    }
}
