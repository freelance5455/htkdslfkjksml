K-DRAMA PLUS — PROYECTO ANDROID (BASE DE DESARROLLO)
====================================================

Qué incluye
- Proyecto Android Studio con Gradle, Kotlin y WebView.
- Catálogo/prototipo rojo y negro en app/src/main/assets/index.html.
- SDK de Google Mobile Ads.
- Anuncios recompensados usando IDs OFICIALES DE PRUEBA de Google.
- Las monedas se entregan desde la devolución de recompensa del SDK, no al cerrar el anuncio.

ESTADO HONESTO
- Este es un proyecto fuente para abrir en Android Studio, NO un APK ya compilado.
- En este entorno no está instalado Android SDK ni Gradle, así que no se pudo compilar ni probar el APK aquí.
- Los anuncios usan IDs de prueba: no generan dinero.
- El catálogo y los episodios son ficticios; el reproductor aún no tiene dramas completos con licencia.
- Antes de publicar hay que revisar consentimiento/privacidad, clasificación por edad, políticas de Google Play y derechos de los videos.

Cómo abrirlo
1. En una computadora, instala Android Studio y sus componentes de Android SDK.
2. Descomprime la carpeta completa y abre la carpeta KDramaPlus_Android como proyecto en Android Studio.
3. Espera la sincronización de Gradle y compila/ejecuta en un teléfono o emulador.
4. Para desarrollo, conserva los IDs de prueba. Nunca hagas clic en anuncios reales propios.
5. Para monetizar, el titular adulto de la cuenta debe crear la app y una unidad de anuncios en AdMob y configurar los IDs propios; luego hay que actualizar el proyecto y probarlo antes de publicar.

CUENTA Y PAGOS
Si el desarrollador es menor de 18 años, Google indica que un padre/madre/tutor puede gestionar la cuenta de AdMob con su propia información, sujeto a aprobación. Los pagos aprobados serían a nombre de esa persona. No introduzcas datos falsos.

DERECHOS DE CONTENIDO
No uses episodios de DramaBox, Netflix u otros servicios sin permiso. Añade solo videos propios, de dominio público o con licencia que permita distribuirlos en la app.

Documentación oficial
- Anuncios recompensados: https://developers.google.com/admob/android/rewarded
- IDs de prueba: https://developers.google.com/admob/android/test-ads
- Crear unidad recompensada: https://support.google.com/admob/answer/7311747?hl=es
