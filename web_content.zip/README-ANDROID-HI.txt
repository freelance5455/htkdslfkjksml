MY DUTY & OT TRACKER — ANDROID SETUP

IMPORTANT: ZIP ko seedha open karke PWA install nahi hota. PWA ko HTTPS website par host karna zaroori hai. index.html ko file:// se kholne par service worker/install features kaam nahi karenge.

PACKAGE FILES
- index.html: app
- manifest.webmanifest: install information
- sw.js: offline cache
- icon-192.png and icon-512.png: Android install icons

ANDROID PAR FREE HOSTING (Netlify Drop)
1. ZIP download karke Android Files app mein Extract karein.
2. Extracted folder ke andar ki sab files ek hi folder mein honi chahiye (index.html root mein ho).
3. Chrome mein https://app.netlify.com/drop kholein aur free account sign in karein.
4. Netlify Drop par extracted folder upload karein. Folder ke andar index.html, manifest.webmanifest, sw.js aur dono PNG icons hon.
5. Netlify jo https://...netlify.app address de, use Chrome mein kholein.
6. Chrome menu ⋮ > Install app (ya Add to Home screen) chunein.

TROUBLESHOOTING
- Sirf ZIP/file preview khol rahe hain? Extract karke HTTPS hosting karein.
- Blank page? Ensure index.html root folder mein hai, kisi extra nested folder mein nahi.
- Install option nahi aa raha? HTTPS URL use karein, page reload karein, Chrome update karein.
- Changes update nahi hue? Website ko reload karein; zarurat par Chrome site settings se site data clear karke dobara kholein. Backup pehle download karein.

DATA NOTE
Duty entries is browser/device ke local storage mein rehti hain. Browser data clear karne ya device badalne se pehle Settings > Backup & Restore se backup download karein.
