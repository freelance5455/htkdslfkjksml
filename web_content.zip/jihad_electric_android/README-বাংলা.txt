জিহাদ ইলেক্ট্রিক — Android Studio project

এই প্রজেক্টটি আপনার দেওয়া HTML ক্যালকুলেটরকে Android WebView অ্যাপ হিসেবে প্যাকেজ করে।
অ্যাপটি HTML ফাইলটি ফোনের ভেতরের assets থেকে খোলে, তাই ব্যবহারের জন্য ইন্টারনেট লাগে না।

APK বানানোর নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে এই ZIP ফাইলটি Extract করে JihadElectric ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন। Android SDK Platform 35 এবং JDK 17 ইনস্টল থাকতে হবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK তৈরি হলে Android Studio-তে notification থেকে Locate চাপুন।
6. APK ফোনে পাঠিয়ে ইনস্টল করুন। ফোনে ইনস্টল করার সময় প্রয়োজন হলে “Install unknown apps” অনুমতি দিন।

নোট:
- এটি Android Studio project; এই ZIP নিজে APK নয়।
- এই প্রজেক্টে কোনো ইন্টারনেট permission দেওয়া হয়নি।
- তারের সাইজ ও MCB অংশটি প্রাথমিক ধারণা; বাস্তব স্থাপনার আগে যোগ্য ইলেকট্রিশিয়ান/প্রকৌশলীর যাচাই প্রয়োজন।
