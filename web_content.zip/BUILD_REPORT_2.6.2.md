# Build report — ANONYMOUX STUDIOS 2.6.2

## Scope delivered
1. Centralized the dark/light theme tokens and made the theme stylesheet the final CSS authority in both the shared application shell and the standalone Realtime Studio shell.
2. Standardized the charcoal/white/neon-green identity and retained purple, teal and blue as restrained secondary accents.
3. Added one Admin → Models form to edit the default pricing for all six workspaces.
4. Aligned the Voice clone, Lip Sync and AI Agent defaults with the values exposed by the new pricing editor.
5. Added clear pricing disclosures to Image Studio, Video Edit Studio and Realtime Studio.
6. Kept Realtime billing transparent: its configurable planning rate is not debited until provider session metering is available.

## Default rates
| Workspace | Default | Charge basis | Enforcement status |
|---|---:|---|---|
| Image Studio | 10 | Per generation | Existing server-side reserve/settle/refund |
| Video Edit Studio | 50 | Per generation | Existing server-side reserve/settle/refund |
| Realtime Studio | 10 | Per minute | Display/planning only; no debit |
| Lip Sync Studio | 30 | Per generation | Existing server-side charge path |
| Voice Studio | 1 | Per 100 characters | Existing server-side charge path |
| Voice private clone | 100 | Per clone | Existing server-side charge path |
| AI Agent Studio | 200 | Per USD of measured provider usage | Measured post-session settlement |

## Validation results
- PHP lint: all PHP files passed.
- Static source/contract tests: passed.
- SQLite billing contract tests: passed.
- Dashboard/sidebar and theme regression tests: passed.
- Resource, voice, agent and realtime source checks: passed.
- `tests/voice_idempotency_migration_check.py` was not executable in the current build container because PHP `pdo_sqlite` is not installed. This is an environment limitation, not a reported test pass.

## Deployment notes
- Upload the ZIP contents to the existing PHP shared-hosting application.
- Preserve the existing private `config.local.php` and `storage/workspace.sqlite`; do not overwrite private credentials or user data.
- Keep the storage directory writable by PHP and ensure `pdo_sqlite` is enabled by the hosting provider.
- Pricing changes affect new operations only; historical wallet entries and balances are preserved.
