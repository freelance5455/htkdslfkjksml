package com.miji.ledger;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.Toast;

public class MainActivity extends Activity {
  WebView web;
  SharedPreferences prefs;
  @Override public void onCreate(Bundle saved) {
    super.onCreate(saved);
    prefs = getSharedPreferences("miji", MODE_PRIVATE);
    web = new WebView(this);
    web.setBackgroundColor(0xFF0B1020);
    WebSettings s = web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new Bridge(this), "NativeBridge");
    setContentView(web); web.loadUrl("file:///android_asset/index.html");
  }
  class Bridge {
    Context c; Bridge(Context c){this.c=c;}
    @JavascriptInterface public String loadData(){ return prefs.getString("data", "[]"); }
    @JavascriptInterface public void saveData(String data){ prefs.edit().putString("data", data).apply(); }
    @JavascriptInterface public void exportText(String text){
      try { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"秘密记账备份"); i.putExtra(Intent.EXTRA_TEXT,text); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(Intent.createChooser(i,"导出/备份")); }
      catch(Exception e){ Toast.makeText(c,"导出失败",Toast.LENGTH_SHORT).show(); }
    }
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
