# 秘密记账 Android App

功能：每场日期/净输赢/备注；累计盈利曲线；历史搜索与修改；累计净盈利、胜率、胜负场次、单场最大赢/亏；JSON 备份导出和恢复。数据默认只保存在本机，不需要账号或网络。

## 手机端构建 APK（GitHub Actions）
1. 在 GitHub 新建一个空仓库，例如 `miji-ledger`。
2. 将本项目中的所有文件上传到仓库根目录（保持目录结构），提交到 `main` 分支。
3. 打开仓库的 **Actions**，允许启用 Actions；进入 **Build 秘密记账 APK**，点 **Run workflow**。
4. 构建完成后打开该次运行页面，在 **Artifacts** 下载 `miji-ledger-debug-apk`，解压得到 `app-debug.apk`。
5. 在 Android 手机上打开 APK 安装；如提示，允许浏览器/文件管理器安装未知来源应用。

这是 debug APK，适合个人安装测试；未签发 Play Store 发布签名。每次牌局数据建议通过 App 的“备份”页导出保存。
