
// Direct Android/WebView button bridge: bind clicks without relying on inline onclick.
(function(){
  function call(fn,args){ try{ if(typeof window[fn]==='function'){ window[fn].apply(window,args||[]); return true; } }catch(e){ console.error(fn,e); alert('حدث خطأ: '+(e&&e.message||e)); } return false; }
  document.addEventListener('click',function(e){
    const t=e.target.closest && e.target.closest('button,[data-page]'); if(!t)return;
    const page=t.getAttribute('data-page');
    if(page){ e.preventDefault(); call('showPage',[page]); return; }
    const act=t.getAttribute('data-action'), id=t.getAttribute('data-id')||'', ma=t.getAttribute('data-modal-action');
    const deleteKind=t.getAttribute('data-delete-action');
    const deleteModal=ma==='delete-booking'?'booking':ma==='delete-period'?'period':ma==='delete-surgery'?'surgery':'';
    const kind=deleteKind||deleteModal||(act==='delete'?'booking':'');
    if(kind){
      e.preventDefault(); e.stopImmediatePropagation();
      const handlers={booking:'deleteBookingPermanent',period:'deletePeriod',rate:'deleteRate',wait:'deleteWait',operation:'deleteOperation',expense:'deleteExpense',surgery:'deleteSurgery'};
      const fn=handlers[kind];
      if(fn)call(fn,[t.getAttribute('data-id')||'']);
      return;
    }
    if(act==='add'){e.preventDefault();call('openBookingModal',['','','',t.dataset.time||'']);}
    else if(act==='edit'){e.preventDefault();call('openBookingModal',[id]);}
    else if(act==='delete'){e.preventDefault();call('deleteBookingPermanent',[id]);}
    else if(ma==='save-booking'){e.preventDefault();call('saveBooking',[t.getAttribute('data-id')||'']);}
    else if(ma==='delete-booking'){e.preventDefault();call('deleteBookingPermanent',[t.getAttribute('data-id')||'']);}
  },true);
})();
