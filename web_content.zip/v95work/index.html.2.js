
(function(){
  const levels=[0.2,0.3,0.5,0.7,1,1.2,1.5];
  const zKey='clinicPageZooms';
  const dKey='clinicDarkMode';
  const root=document.documentElement, body=document.body;
  let zooms={};
  try{zooms=JSON.parse(localStorage.getItem(zKey)||'{}')||{};}catch(e){zooms={};}

  function activePage(){
    const el=document.querySelector('.page.active');
    return el ? el.id.replace(/^page-/,'') : 'home';
  }
  function nearestLevel(v){
    return levels.reduce((a,b)=>Math.abs(b-v)<Math.abs(a-v)?b:a,1);
  }
  function applyPageZoom(page,v,save=true){
    v=nearestLevel(Number(v)||1);
    document.querySelectorAll('.page').forEach(el=>{
      el.style.zoom = el.classList.contains('active') ? String(v) : '';
    });
    const sel=document.getElementById('zoomSelect');
    if(sel) sel.value=String(v);
    const label=document.getElementById('zoomPageName');
    if(label) label.textContent=page==='home'?'الرئيسية':({queue:'متابعة الدور',bookings:'الحجوزات',attendance:'الحضور','hourly-attendance':'الحضور بالساعة',operations:'العمليات',expenses:'المصروفات',reports:'التقارير',patients:'ملفات المرضى',archive:'الأرشيف',analytics:'لوحة التحكم',calendar:'التقويم'}[page]||page);
    if(save){zooms[page]=v;try{localStorage.setItem(zKey,JSON.stringify(zooms));}catch(e){}}
  }
  function refreshForActivePage(){
    const page=activePage();
    const v=nearestLevel(zooms[page] ?? 1);
    applyPageZoom(page,v,false);
  }
  window.setPageZoom=function(v){applyPageZoom(activePage(),v,true);};

  function applyDark(on){
    body.classList.toggle('dark-mode',!!on);
    root.classList.toggle('dark-mode',!!on);
    const b=document.getElementById('globalDarkToggle');
    if(b){b.textContent=on?'☀':'☾';b.title=on?'الوضع الفاتح':'الوضع الداكن';}
    try{localStorage.setItem(dKey,on?'1':'0');}catch(e){}
  }

  function init(){
    const sel=document.getElementById('zoomSelect'),minus=document.getElementById('zoomMinus'),plus=document.getElementById('zoomPlus'),dark=document.getElementById('globalDarkToggle');
    let d=false;try{d=localStorage.getItem(dKey)==='1';}catch(e){}
    applyDark(d);
    refreshForActivePage();
    if(sel) sel.addEventListener('change',()=>window.setPageZoom(parseFloat(sel.value)));
    if(minus) minus.addEventListener('click',()=>{const i=levels.indexOf(nearestLevel(parseFloat(sel.value)));window.setPageZoom(levels[Math.max(0,i-1)]);});
    if(plus) plus.addEventListener('click',()=>{const i=levels.indexOf(nearestLevel(parseFloat(sel.value)));window.setPageZoom(levels[Math.min(levels.length-1,i+1)]);});
    if(dark) dark.addEventListener('click',()=>applyDark(!body.classList.contains('dark-mode')));
    const observer=new MutationObserver(()=>refreshForActivePage());
    document.querySelectorAll('.page').forEach(el=>observer.observe(el,{attributes:true,attributeFilter:['class']}));
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();

