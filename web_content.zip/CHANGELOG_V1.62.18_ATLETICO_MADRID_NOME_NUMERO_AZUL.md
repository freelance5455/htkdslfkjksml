# Carreira de Craque v1.62.18 — Atlético de Madrid em azul

- Alterada a cor do nome e do número nas camisas do Atlético de Madrid para azul royal (#00529F).
- Mantidos os ajustes anteriores dos uniformes do Barcelona e Real Madrid e os demais uniformes da LaLiga.
- Atualizado o cache do service worker para garantir que a versão nova seja carregada.

## Validação
- Teste dos 20 uniformes da LaLiga: aprovado.
- Regressão LaLiga: aprovada.
- Inicialização da carreira LaLiga: aprovada.
- Sintaxe dos scripts JavaScript embutidos: aprovada.
