# Câmara se Fashion Model

Projeto atualizado para a plataforma de concursos e votação online.

A implementação deve seguir `CAMARA_FASHION_MODEL_REGRAS.md`.

Fluxo principal:
1. Login com Google
2. Lista de concursos publicados pelo administrador
3. Página do concurso
4. Participantes cadastrados pelo administrador
5. Escolha da quantidade de votos
6. Cálculo em MT
7. Pagamento online
8. Confirmação do pagamento
9. Registo dos votos
10. Área administrativa para gerir concursos, participantes, preços e resultados

O aplicativo requer internet.


**Importante:** não há participante pré-cadastrado. O administrador coloca todos os nomes, fotos, códigos e concursos. O app funciona somente com internet.
