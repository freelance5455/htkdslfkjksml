// Run: node tests/logic.test.js
const assert = require('assert');
const L = require('../logic.js');

const vals = (w) => L.parseMultipliers(w).map((v) => v.value);

// OCR parsing
assert.deepStrictEqual(vals([{ text: '1.23x', confidence: 90 }]), [1.23]);
assert.deepStrictEqual(vals([{ text: '2.10', confidence: 80 }, { text: 'x', confidence: 70 }]), [2.1]);
assert.deepStrictEqual(vals([{ text: 'Round', confidence: 90 }, { text: '3.4O', confidence: 50 }, { text: 'x', confidence: 60 }]), [3.4]);
assert.deepStrictEqual(vals([{ text: '12.5', confidence: 90 }]), [], 'bare number without x is ignored');
assert.deepStrictEqual(vals([{ text: '0.50x', confidence: 90 }]), [], 'below 1.00x is rejected');
assert.deepStrictEqual(vals([{ text: 'x', confidence: 90 }]), [], 'lone x is ignored');
assert.deepStrictEqual(vals([{ text: '10.5×', confidence: 91 }]), [10.5]);

// Crop geometry
assert.deepStrictEqual(L.cropRect(1000, 500, { top: 10, bottom: 10, left: 0, right: 0 }), { sx: 0, sy: 50, sw: 1000, sh: 400 });
assert.deepStrictEqual(L.cropRect(100, 100, { top: 200 }), { sx: 0, sy: 40, sw: 100, sh: 60 }, 'crop clamps to 40%');

// Statistics
const s = L.computeStats([1.5, 3, 12, 1.2, 2.5, 1.1]);
assert.deepStrictEqual([s.count, s.average, s.median, s.highest, s.lowest], [6, 3.55, 2, 12, 1.1]);
assert.deepStrictEqual([s.lowCount, s.midCount, s.highCount], [3, 2, 1]);
assert.strictEqual(s.longestLowStreak, 1);
assert.strictEqual(s.currentLowStreak, 1);
assert.strictEqual(s.windows.last10.partial, true);
const t = L.computeStats([1.1, 1.2, 1.3, 5, 1.4]);
assert.strictEqual(t.longestLowStreak, 3);
assert.strictEqual(t.currentLowStreak, 1);

console.log('All logic tests passed.');
