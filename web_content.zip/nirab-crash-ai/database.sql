-- ============================================================
-- NIRAB CRASH AI — Supabase database schema
-- Run this whole file once in: Supabase Dashboard -> SQL Editor -> New query
-- Safe to re-run: uses IF NOT EXISTS / OR REPLACE / DROP POLICY IF EXISTS.
-- ============================================================

-- 1) users: one row per auth user (filled automatically by the trigger below)
create table if not exists public.users (
  id           uuid primary key references auth.users (id) on delete cascade,
  email        text,
  display_name text,
  created_at   timestamptz not null default now()
);

-- 2) scan_history: one row per analysed screenshot
create table if not exists public.scan_history (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.users (id) on delete cascade,
  image_name  text not null default 'screenshot' check (char_length(image_name) <= 255),
  created_at  timestamptz not null default now()
);

-- 3) multiplier_history: one row per multiplier value (chronological position within a scan)
create table if not exists public.multiplier_history (
  id          uuid primary key default gen_random_uuid(),
  scan_id     uuid not null references public.scan_history (id) on delete cascade,
  user_id     uuid not null references public.users (id) on delete cascade,
  value       numeric(10, 2) not null check (value >= 1 and value <= 100000),
  confidence  numeric(5, 2) check (confidence is null or (confidence >= 0 and confidence <= 100)),
  source      text not null check (source in ('ocr', 'corrected', 'manual')),
  position    integer not null check (position >= 0),
  created_at  timestamptz not null default now(),
  unique (scan_id, position)
);

-- 4) settings: per-user preferences as JSON
create table if not exists public.settings (
  user_id     uuid primary key references public.users (id) on delete cascade,
  data        jsonb not null default '{}'::jsonb,
  updated_at  timestamptz not null default now()
);

-- Indexes for history and statistics queries
create index if not exists scan_history_user_created_idx on public.scan_history (user_id, created_at desc);
create index if not exists multiplier_history_user_idx on public.multiplier_history (user_id, scan_id);

-- Auto-create the public.users row when someone signs up
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- Row Level Security: every user can only see and change their own rows.
-- The app uses the anon key; these policies are what keep data private.
-- ============================================================
alter table public.users               enable row level security;
alter table public.scan_history        enable row level security;
alter table public.multiplier_history  enable row level security;
alter table public.settings            enable row level security;

drop policy if exists "own profile" on public.users;
create policy "own profile" on public.users
  for all using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "own scans" on public.scan_history;
create policy "own scans" on public.scan_history
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own rounds" on public.multiplier_history;
create policy "own rounds" on public.multiplier_history
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own settings" on public.settings;
create policy "own settings" on public.settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Make sure the anon / signed-in roles can use the tables (RLS still applies)
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.users, public.scan_history,
  public.multiplier_history, public.settings to authenticated;

-- Optional: a quick check query after running the file
-- select table_name from information_schema.tables where table_schema = 'public';
