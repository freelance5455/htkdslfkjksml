// Optional cloud configuration.
// Paste your Supabase project URL and the ANON (public) key here, or enter them in
// Settings -> Cloud sync. Leave both empty to run fully offline on this device.
//
// NEVER put the service_role key (or any other secret) in this file. Anything in the
// frontend is visible to every visitor. The anon key is designed to be public; Row Level
// Security in database.sql protects the data.
window.NIRAB_CONFIG = {
  SUPABASE_URL: '',
  SUPABASE_ANON_KEY: ''
};
