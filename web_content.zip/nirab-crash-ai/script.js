/* NIRAB CRASH AI — application logic (UI + storage + OCR).
 * Pure parsing / statistics live in logic.js.
 */
'use strict';

const L = window.NiraLogic;
const LS_KEY = 'nirab_crash_ai_v1';        // local database (LocalStorage)
const LS_CFG = 'nirab_cloud_config_v1';    // optional Supabase URL + anon key
const ACCEPT = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_BYTES = 15 * 1024 * 1024;
const MAX_QUEUE = 20;

/* ---------- helpers ---------- */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = () => (window.crypto && crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 10));
const fmtX = (n) => (Number.isFinite(n) ? n.toFixed(2) + 'x' : '—');
const fmtPct = (n) => (Number.isFinite(n) ? n.toFixed(1) + '%' : '—');
const fmtDate = (s) => { const d = new Date(s); return isNaN(d) ? '' : d.toLocaleString(); };
const chipClass = (v) => (v < L.LOW_T ? 'low' : v >= L.HIGH_T ? 'high' : 'mid');
const emptyState = (msg) => `<div class="empty"><div class="empty-icon">◎</div><p>${esc(msg)}</p></div>`;
const statCard = (label, value, plain) => `<div class="stat"><div class="label">${label}</div><div class="value ${plain ? 'plain' : ''}">${value}</div></div>`;
const meter = (label, p, c, cls) => `<div class="meter"><div class="label-row"><span>${label}</span><span>${fmtPct(p)} · ${c}</span></div><div class="track"><div class="fill ${cls}" style="width:${p}%"></div></div></div>`;

function toast(msg, type) {
  const t = document.createElement('div');
  t.className = 'toast ' + (type || 'info');
  t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.classList.add('out'), 3200);
  setTimeout(() => t.remove(), 3700);
}

function setProgress(el, ratio, text) {
  el.querySelector('.bar').style.width = Math.max(0, Math.min(100, Math.round(ratio * 100))) + '%';
  el.querySelector('small').textContent = text || '';
}

/* ---------- application state ---------- */
const state = {
  store: null,            // LocalStore or RemoteStore (same async API)
  scans: [],              // [{id, image_name, created_at, rounds:[{value, confidence, source, position}]}]
  items: [],              // scanner queue
  scanning: false,
  worker: null,           // Tesseract worker (created once, reused)
  onProgress: null,
  prefs: { order: 'newest_top' },
  dataError: null,
  notice: null,
};

/* ---------- storage: local (LocalStorage) ---------- */
const LocalStore = {
  mode: 'local',
  _read() {
    try {
      const d = JSON.parse(localStorage.getItem(LS_KEY));
      return d && Array.isArray(d.scans) ? d : { scans: [], settings: {} };
    } catch (e) { return { scans: [], settings: {} }; }
  },
  _write(d) { localStorage.setItem(LS_KEY, JSON.stringify(d)); },
  async listScans() {
    return this._read().scans.slice().sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  },
  async addScan(imageName, values) {
    const d = this._read();
    const scan = {
      id: uid(),
      image_name: imageName,
      created_at: new Date().toISOString(),
      rounds: values.map((v, i) => ({ value: v.value, confidence: v.confidence == null ? null : v.confidence, source: v.source, position: i })),
    };
    d.scans.push(scan);
    this._write(d);
    return scan;
  },
  async deleteScan(id) { const d = this._read(); d.scans = d.scans.filter((s) => s.id !== id); this._write(d); },
  async clearAll() { const d = this._read(); d.scans = []; this._write(d); },
  async getSettings() { return this._read().settings || {}; },
  async saveSettings(patch) { const d = this._read(); d.settings = Object.assign({}, d.settings, patch); this._write(d); },
};

/* ---------- storage: Supabase (cloud) ---------- */
const RemoteStore = {
  mode: 'cloud',
  client: null,
  user: null,
  connect(url, key) {
    this.client = window.supabase.createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true } });
    return this.client;
  },
  async restoreSession() {
    const { data, error } = await this.client.auth.getSession();
    if (error) throw error;
    this.user = data.session ? data.session.user : null;
    return this.user;
  },
  async signIn(email, password) {
    const { data, error } = await this.client.auth.signInWithPassword({ email: email, password: password });
    if (error) throw error;
    this.user = data.user;
    return data.user;
  },
  async signUp(email, password) {
    const { data, error } = await this.client.auth.signUp({ email: email, password: password });
    if (error) throw error;
    this.user = data.session ? data.user : null;
    return { needsConfirm: !data.session };
  },
  async signOut() { await this.client.auth.signOut(); this.user = null; },
  _uid() {
    if (!this.user) throw new Error('Sign in (Settings) to use cloud history.');
    return this.user.id;
  },
  async listScans() {
    const u = this._uid();
    const { data, error } = await this.client.from('scan_history')
      .select('id, image_name, created_at, multiplier_history ( value, confidence, source, position )')
      .eq('user_id', u)
      .order('created_at', { ascending: false })
      .limit(1000);
    if (error) throw error;
    return data.map((s) => ({
      id: s.id,
      image_name: s.image_name,
      created_at: s.created_at,
      rounds: (s.multiplier_history || [])
        .map((r) => ({ value: Number(r.value), confidence: r.confidence, source: r.source, position: r.position }))
        .sort((a, b) => a.position - b.position),
    }));
  },
  async addScan(imageName, values) {
    const u = this._uid();
    const { data: scan, error } = await this.client.from('scan_history')
      .insert({ user_id: u, image_name: imageName })
      .select('id, image_name, created_at').single();
    if (error) throw error;
    const rows = values.map((v, i) => ({ scan_id: scan.id, user_id: u, value: v.value, confidence: v.confidence == null ? null : v.confidence, source: v.source, position: i }));
    const { error: e2 } = await this.client.from('multiplier_history').insert(rows);
    if (e2) {
      await this.client.from('scan_history').delete().eq('id', scan.id); // roll back the scan row
      throw e2;
    }
    return scan;
  },
  async deleteScan(id) {
    this._uid();
    const { error } = await this.client.from('scan_history').delete().eq('id', id);
    if (error) throw error;
  },
  async clearAll() {
    const u = this._uid();
    const { error } = await this.client.from('scan_history').delete().eq('user_id', u);
    if (error) throw error;
  },
  async getSettings() {
    const { data, error } = await this.client.from('settings').select('data').eq('user_id', this._uid()).maybeSingle();
    if (error) throw error;
    return (data && data.data) || {};
  },
  async saveSettings(patch) {
    const u = this._uid();
    const current = await this.getSettings();
    const { error } = await this.client.from('settings').upsert(
      { user_id: u, data: Object.assign({}, current, patch), updated_at: new Date().toISOString() },
      { onConflict: 'user_id' }
    );
    if (error) throw error;
  },
};

/* ---------- configuration ---------- */
function validUrl(u) {
  try { const x = new URL(u); return x.protocol === 'https:' || (x.protocol === 'http:' && x.hostname === 'localhost'); }
  catch (e) { return false; }
}

// Refuse a service_role key: it must never reach the browser.
function jwtRole(key) {
  try {
    const part = key.split('.')[1];
    const json = atob(part.replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(json).role || null;
  } catch (e) { return null; }
}

function loadCloudConfig() {
  try {
    const saved = JSON.parse(localStorage.getItem(LS_CFG) || 'null');
    if (saved && saved.url && saved.key) return saved;
  } catch (e) { /* ignore */ }
  const c = window.NIRAB_CONFIG || {};
  return c.SUPABASE_URL && c.SUPABASE_ANON_KEY ? { url: c.SUPABASE_URL, key: c.SUPABASE_ANON_KEY } : null;
}

async function loadPrefs() {
  const local = await LocalStore.getSettings();
  let remote = {};
  if (state.store === RemoteStore && RemoteStore.user) {
    try { remote = await RemoteStore.getSettings(); } catch (e) { /* keep local */ }
  }
  state.prefs = Object.assign({ order: 'newest_top' }, local, remote);
}

async function savePrefs(patch) {
  state.prefs = Object.assign({}, state.prefs, patch);
  await LocalStore.saveSettings(state.prefs);
  if (state.store === RemoteStore && RemoteStore.user) {
    try { await RemoteStore.saveSettings(patch); }
    catch (e) { toast('Settings sync failed: ' + e.message, 'error'); }
  }
}

/* ---------- boot ---------- */
async function boot() {
  bindUI();
  const cfg = loadCloudConfig();
  if (cfg) {
    $('#sbUrl').value = cfg.url;
    const storedCfg = localStorage.getItem(LS_CFG);
    if (storedCfg) $('#sbKey').value = JSON.parse(storedCfg).key;
  }
  state.store = LocalStore;
  if (cfg && window.supabase) {
    try {
      RemoteStore.connect(cfg.url, cfg.key);
      await RemoteStore.restoreSession();
      state.store = RemoteStore;
      RemoteStore.client.auth.onAuthStateChange((_evt, session) => {
        RemoteStore.user = session ? session.user : null;
        loadPrefs().then(refreshAll);
      });
      $('#modeBadge').textContent = 'CLOUD';
    } catch (e) {
      state.notice = 'Cloud connection failed (' + e.message + '). Using local mode.';
      state.store = LocalStore;
    }
  } else if (cfg) {
    state.notice = 'Supabase library could not load (check internet). Using local mode.';
  }
  await loadPrefs();
  $('#orderSelect').value = state.prefs.order;
  renderAuth();
  await refreshAll();
}

function bindUI() {
  $$('[data-view]').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));

  $('#fileInput').addEventListener('change', (e) => { handleFiles(e.target.files); e.target.value = ''; });
  $('#scanAllBtn').addEventListener('click', () => scanItems(state.items.slice()));
  $('#clearQueueBtn').addEventListener('click', () => {
    state.items.forEach((i) => URL.revokeObjectURL(i.url));
    state.items = [];
    renderQueue();
  });

  const q = $('#queue');
  q.addEventListener('click', onQueueClick);
  q.addEventListener('input', onQueueInput);

  $('#historyList').addEventListener('click', onHistoryClick);
  $('#clearHistoryBtn').addEventListener('click', clearAllHistory);

  $('#orderSelect').addEventListener('change', async (e) => {
    await savePrefs({ order: e.target.value });
    toast('Order saved', 'success');
    renderQueue();
  });

  $('#cloudForm').addEventListener('submit', onCloudSave);
  $('#testBtn').addEventListener('click', testCloud);
  $('#disconnectBtn').addEventListener('click', () => { localStorage.removeItem(LS_CFG); location.reload(); });
  $('#signInBtn').addEventListener('click', onSignIn);
  $('#signUpBtn').addEventListener('click', onSignUp);
  $('#signOutBtn').addEventListener('click', onSignOut);
  $('#exportBtn').addEventListener('click', exportData);
  $('#clearLocalBtn').addEventListener('click', clearLocal);
}

function showView(name) {
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  $$('.nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  window.scrollTo(0, 0);
  refreshAll();
}

async function refreshAll() {
  try {
    state.scans = await state.store.listScans();
    state.dataError = null;
  } catch (e) {
    state.scans = [];
    state.dataError = e.message;
  }
  renderBanner();
  renderHome();
  renderHistory();
  renderAnalysis();
  renderAuth();
}

function renderBanner() {
  const b = $('#banner');
  let msg = '';
  if (state.notice) msg = state.notice;
  else if (state.store === RemoteStore && !RemoteStore.user) msg = 'Cloud mode: sign in from Settings to load your history.';
  else if (state.dataError) msg = 'Could not load history: ' + state.dataError;
  b.hidden = !msg;
  b.textContent = msg;
}

/* ---------- derived data ---------- */
function chronologicalValues(scans) {
  const sorted = scans.slice().sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)));
  const out = [];
  for (const s of sorted) {
    const rounds = (s.rounds || []).slice().sort((a, b) => a.position - b.position);
    for (const r of rounds) out.push(Number(r.value));
  }
  return out;
}

/* ---------- HOME ---------- */
function renderHome() {
  const values = chronologicalValues(state.scans);
  const s = L.computeStats(values);
  const last = values.length ? values[values.length - 1] : null;
  $('#homeStats').innerHTML = [
    statCard('Scans saved', state.scans.length, true),
    statCard('Rounds', s.count || 0, true),
    statCard('Average', fmtX(s.average)),
    statCard('Last', fmtX(last)),
  ].join('');
  const lastTen = values.slice(-10).reverse();
  $('#homeLast').innerHTML = lastTen.length
    ? lastTen.map((v) => `<span class="chip ${chipClass(v)}">${fmtX(v)}</span>`).join('')
    : '<span class="muted">No rounds saved yet.</span>';
}

/* ---------- SCANNER: upload ---------- */
function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      if (!img.naturalWidth || !img.naturalHeight) { URL.revokeObjectURL(url); reject(new Error('empty image')); return; }
      resolve({ img: img, url: url });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode failed')); };
    img.src = url;
  });
}

async function handleFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;
  const bar = $('#uploadProgress');
  bar.hidden = false;
  let added = 0;
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    setProgress(bar, i / files.length, `Loading ${i + 1} of ${files.length}: ${f.name}`);
    if (state.items.length >= MAX_QUEUE) { toast(`Queue limit is ${MAX_QUEUE} images.`, 'error'); break; }
    if (ACCEPT.indexOf(f.type) === -1) { toast(`Invalid image: ${f.name}. Use JPG, JPEG, PNG or WEBP.`, 'error'); continue; }
    if (f.size > MAX_BYTES) { toast(`${f.name} is larger than 15 MB.`, 'error'); continue; }
    try {
      const loaded = await loadImage(f);
      state.items.push({
        id: uid(), name: f.name, img: loaded.img, url: loaded.url,
        crop: { top: 0, bottom: 0, left: 0, right: 0 },
        cropOpen: false, status: 'ready', error: null, values: [],
      });
      added++;
    } catch (err) {
      toast(`Invalid or unreadable image: ${f.name}`, 'error');
    }
    setProgress(bar, (i + 1) / files.length, `Loaded ${i + 1} of ${files.length}`);
  }
  setTimeout(() => { bar.hidden = true; }, 700);
  renderQueue();
  if (added) toast(`${added} image(s) added`, 'success');
}

/* ---------- SCANNER: queue rendering ---------- */
function findItem(id) { return state.items.find((i) => i.id === id) || null; }

function removeItem(id) {
  const it = findItem(id);
  if (it) URL.revokeObjectURL(it.url);
  state.items = state.items.filter((i) => i.id !== id);
  renderQueue();
}

function statusText(item) {
  const map = { ready: 'Ready', scanning: 'Scanning…', done: `${item.values.length} multiplier(s) found`, error: 'Needs attention' };
  return map[item.status] || '';
}

function cropHTML(item) {
  const c = item.crop;
  const slider = (k, label) => `<label>${label}: <span data-out="${k}">${c[k]}</span>%
      <input type="range" min="0" max="40" step="1" value="${c[k]}" data-crop="${k}"></label>`;
  return `<div class="crop-box">
      <div class="sliders">${slider('top', 'Top')}${slider('bottom', 'Bottom')}${slider('left', 'Left')}${slider('right', 'Right')}</div>
      <canvas class="crop-canvas"></canvas>
      <div class="row-actions"><button class="btn ghost small" data-act="resetcrop">Reset crop</button></div>
      <p class="crop-note">Crop to the round-history list so only multiplier values remain. The preview shows exactly what OCR reads.</p>
    </div>`;
}

function resultsHTML(item) {
  const rows = item.values.map((v, i) => `
      <div class="val-row ${v.confidence != null && v.confidence < 60 ? 'warn' : ''}" data-vid="${v.id}">
        <span class="idx">${i + 1}</span>
        <input class="val-input ${v.invalid ? 'invalid' : ''}" type="number" step="0.01" min="1" max="100000"
               value="${Number.isFinite(v.value) ? v.value.toFixed(2) : ''}" data-act="edit" aria-label="Multiplier ${i + 1}">
        <span class="conf">${v.source === 'manual' ? 'manual' : (v.confidence != null ? Math.round(v.confidence) + '%' : '')}</span>
        <button class="icon-btn danger" data-act="delval" title="Delete value">✕</button>
      </div>`).join('');
  return `<div class="results">
      <div class="results-head">${item.values.length} value(s) detected. Check each one and correct it before saving. Amber rows had low OCR confidence.</div>
      ${rows}
      <div class="qc-actions">
        <button class="btn ghost small" data-act="addval">+ Add value</button>
        <button class="btn primary small" data-act="save">Save to history</button>
      </div>
    </div>`;
}

function buildCard(item) {
  const card = document.createElement('article');
  card.className = 'card queue-card';
  card.dataset.id = item.id;
  card.innerHTML = `
    <div class="qc-head">
      <img class="thumb" src="${item.url}" alt="Screenshot preview">
      <div class="qc-meta">
        <strong>${esc(item.name)}</strong>
        <span class="status s-${item.status}">${esc(statusText(item))}</span>
      </div>
      <button class="icon-btn danger" data-act="remove" title="Remove image">✕</button>
    </div>
    <div class="qc-actions">
      <button class="btn ghost small" data-act="crop">${item.cropOpen ? 'Hide crop' : 'Crop'}</button>
      <button class="btn primary small" data-act="scan" ${state.scanning ? 'disabled' : ''}>Scan</button>
    </div>
    ${item.cropOpen ? cropHTML(item) : ''}
    ${item.error ? `<p class="error">${esc(item.error)}</p>` : ''}
    ${item.values.length ? resultsHTML(item) : ''}`;
  return card;
}

function renderQueue() {
  const box = $('#queue');
  box.innerHTML = '';
  state.items.forEach((item) => box.appendChild(buildCard(item)));
  $('#emptyQueue').hidden = state.items.length > 0;
  $('#scanAllBtn').disabled = state.items.length === 0 || state.scanning;
  state.items.forEach((item) => {
    if (item.cropOpen) drawCropPreview(box.querySelector(`[data-id="${item.id}"]`), item);
  });
}

function drawCropPreview(card, item) {
  const cv = card && card.querySelector('.crop-canvas');
  if (!cv || !item.img) return;
  const r = L.cropRect(item.img.naturalWidth, item.img.naturalHeight, item.crop);
  const w = Math.min((cv.parentElement.clientWidth || 300) - 24, 520) || 300;
  const h = Math.min(320, Math.round(w * r.sh / r.sw));
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.round(w * dpr);
  cv.height = Math.round(h * dpr);
  cv.style.height = h + 'px';
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.drawImage(item.img, r.sx, r.sy, r.sw, r.sh, 0, 0, w, h);
}

/* ---------- SCANNER: events ---------- */
function onQueueClick(e) {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const card = btn.closest('[data-id]');
  const item = card && findItem(card.dataset.id);
  if (!item) return;
  switch (btn.dataset.act) {
    case 'remove': removeItem(item.id); break;
    case 'crop': item.cropOpen = !item.cropOpen; renderQueue(); break;
    case 'resetcrop': item.crop = { top: 0, bottom: 0, left: 0, right: 0 }; renderQueue(); break;
    case 'scan': scanItems([item]); break;
    case 'delval': {
      const row = btn.closest('[data-vid]');
      item.values = item.values.filter((v) => v.id !== row.dataset.vid);
      if (!item.values.length && item.status === 'done') item.status = 'ready';
      renderQueue();
      break;
    }
    case 'addval':
      item.values.push({ id: uid(), value: 1, confidence: null, source: 'manual', invalid: false });
      if (item.status !== 'done') item.status = 'done';
      renderQueue();
      break;
    case 'save': saveItem(item); break;
    default: break;
  }
}

function onQueueInput(e) {
  const card = e.target.closest('[data-id]');
  const item = card && findItem(card.dataset.id);
  if (!item) return;
  if (e.target.matches('[data-crop]')) {
    const k = e.target.dataset.crop;
    item.crop[k] = Number(e.target.value);
    card.querySelector(`[data-out="${k}"]`).textContent = item.crop[k];
    drawCropPreview(card, item);
    return;
  }
  if (e.target.matches('[data-act="edit"]')) {
    const row = e.target.closest('[data-vid]');
    const v = item.values.find((x) => x.id === row.dataset.vid);
    if (!v) return;
    const num = Number(e.target.value);
    const ok = e.target.value !== '' && Number.isFinite(num) && num >= L.MIN_M && num <= L.MAX_M;
    v.invalid = !ok;
    e.target.classList.toggle('invalid', !ok);
    if (ok) {
      const rounded = Math.round(num * 100) / 100;
      v.value = rounded;
      if (v.ocrValue !== undefined) v.source = rounded === v.ocrValue ? 'ocr' : 'corrected';
    }
  }
}

/* ---------- OCR ---------- */
async function getWorker(onP) {
  state.onProgress = onP;
  if (state.worker) return state.worker;
  if (!window.Tesseract) throw new Error('OCR engine did not load. Check the internet connection and reload.');
  const worker = await window.Tesseract.createWorker('eng', 1, {
    logger: (m) => { if (state.onProgress && typeof m.progress === 'number') state.onProgress(m.progress); },
  });
  await worker.setParameters({ tessedit_pageseg_mode: '11' }); // sparse text: suits scattered labels
  state.worker = worker;
  return worker;
}

// Crops, upscales and boosts contrast so small digits are readable.
function prepareCanvas(img, crop, scale) {
  const r = L.cropRect(img.naturalWidth, img.naturalHeight, crop);
  const s = Math.min(scale, 3000 / r.sw);
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(r.sw * s));
  c.height = Math.max(1, Math.round(r.sh * s));
  const ctx = c.getContext('2d');
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, r.sx, r.sy, r.sw, r.sh, 0, 0, c.width, c.height);
  const im = ctx.getImageData(0, 0, c.width, c.height);
  const d = im.data;
  for (let i = 0; i < d.length; i += 4) {
    const g = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
    let v = (g - 128) * 1.4 + 128;
    v = v < 0 ? 0 : v > 255 ? 255 : v;
    d[i] = d[i + 1] = d[i + 2] = v;
  }
  ctx.putImageData(im, 0, 0);
  return c;
}

async function runOCR(item, onP) {
  const worker = await getWorker(onP);
  const canvas = prepareCanvas(item.img, item.crop, 2);
  const result = await worker.recognize(canvas);
  const data = result && result.data ? result.data : {};
  const words = (data.words || []).map((w) => ({ text: w.text, confidence: w.confidence }));
  return L.parseMultipliers(words).map((v) => Object.assign({ id: uid(), invalid: false, ocrValue: v.value }, v));
}

async function scanItems(list) {
  const targets = list.filter((i) => i.status !== 'scanning');
  if (state.scanning || !targets.length) return;
  state.scanning = true;
  renderQueue();
  const bar = $('#scanProgress');
  bar.hidden = false;
  let done = 0;
  try {
    for (const item of targets) {
      item.status = 'scanning';
      item.error = null;
      renderQueue();
      const base = done / targets.length;
      try {
        const values = await runOCR(item, (p) => setProgress(bar, base + p / targets.length, `Reading ${item.name} · ${Math.round(p * 100)}%`));
        item.values = values;
        if (values.length) {
          item.status = 'done';
        } else {
          item.status = 'error';
          item.error = 'No multiplier values found (a number followed by x). Crop closer to the round-history list and scan again.';
        }
      } catch (err) {
        item.status = 'error';
        item.error = err && err.message ? err.message : 'OCR failed.';
      }
      done++;
      setProgress(bar, done / targets.length, `Finished ${done} of ${targets.length}`);
      renderQueue();
    }
  } finally {
    state.scanning = false;
    setTimeout(() => { bar.hidden = true; }, 900);
    renderQueue();
  }
}

/* ---------- SCANNER: save ---------- */
async function saveItem(item) {
  if (!item.values.length) return toast('No values to save.', 'error');
  const bad = item.values.some((v) => v.invalid || !Number.isFinite(v.value) || v.value < L.MIN_M || v.value > L.MAX_M);
  if (bad) return toast('Fix the highlighted values (1.00x to 100000x) first.', 'error');
  const onScreen = item.values.map((v) => ({
    value: Math.round(v.value * 100) / 100,
    confidence: v.confidence == null ? null : v.confidence,
    source: v.source,
  }));
  // Screen order -> chronological order (oldest first) using the Settings choice.
  const chronological = state.prefs.order === 'newest_top' ? onScreen.slice().reverse() : onScreen;
  try {
    await state.store.addScan(item.name, chronological);
    removeItem(item.id);
    toast(`Saved ${chronological.length} rounds`, 'success');
    await refreshAll();
  } catch (err) {
    toast('Save failed: ' + err.message, 'error');
  }
}

/* ---------- HISTORY ---------- */
function renderHistory() {
  const box = $('#historyList');
  if (!state.scans.length) {
    box.innerHTML = emptyState(state.dataError ? 'Could not load history.' : 'No saved scans yet.');
    return;
  }
  const scans = state.scans.slice().sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
  box.innerHTML = scans.map((s) => {
    const rounds = (s.rounds || []).slice().sort((a, b) => a.position - b.position);
    return `<article class="card hist">
        <div class="hist-head">
          <div>
            <strong>${esc(s.image_name || 'Screenshot')}</strong>
            <small>${esc(fmtDate(s.created_at))} · ${rounds.length} rounds · oldest → newest</small>
          </div>
          <button class="icon-btn danger" data-del="${esc(s.id)}" title="Delete scan">🗑</button>
        </div>
        <div class="chips">${rounds.map((r) => `<span class="chip ${chipClass(r.value)}">${fmtX(r.value)}</span>`).join('')}</div>
      </article>`;
  }).join('');
}

async function onHistoryClick(e) {
  const btn = e.target.closest('[data-del]');
  if (!btn) return;
  if (!window.confirm('Delete this scan and all its rounds?')) return;
  try {
    await state.store.deleteScan(btn.dataset.del);
    toast('Scan deleted', 'success');
    await refreshAll();
  } catch (err) { toast('Delete failed: ' + err.message, 'error'); }
}

async function clearAllHistory() {
  if (!state.scans.length) return toast('History is already empty.');
  if (!window.confirm('Delete ALL saved scans? This cannot be undone.')) return;
  try {
    await state.store.clearAll();
    toast('History cleared', 'success');
    await refreshAll();
  } catch (err) { toast('Clear failed: ' + err.message, 'error'); }
}

/* ---------- ANALYSIS ---------- */
function renderAnalysis() {
  const body = $('#analysisBody');
  const values = chronologicalValues(state.scans);
  if (!values.length) {
    body.innerHTML = emptyState('No saved rounds yet. Scan a screenshot and save it to see statistics.');
    return;
  }
  const s = L.computeStats(values);
  const win = (label, w) => !w ? '' : `<div class="tr">
      <span>${label}${w.partial ? ' *' : ''}</span><span>${w.count}</span><span>${fmtX(w.average)}</span>
      <span>${fmtX(w.highest)}</span><span>${fmtPct(w.lowPercent)}</span></div>`;
  body.innerHTML = `
    <div class="grid stats">
      ${statCard('Rounds', s.count, true)}
      ${statCard('Average', fmtX(s.average))}
      ${statCard('Median', fmtX(s.median))}
      ${statCard('Highest', fmtX(s.highest))}
      ${statCard('Lowest', fmtX(s.lowest))}
    </div>
    <div class="card">
      <div class="card-head"><h3>Recent windows</h3></div>
      <div class="table">
        <div class="tr head"><span>Window</span><span>Rounds</span><span>Avg</span><span>High</span><span>Below 2x</span></div>
        ${win('Last 10', s.windows.last10)}${win('Last 50', s.windows.last50)}${win('Last 100', s.windows.last100)}
      </div>
      ${s.windows.last10 && s.windows.last10.partial ? '<small>* fewer rounds saved than this window size</small>' : ''}
    </div>
    <div class="card">
      <div class="card-head"><h3>Risk analysis</h3><small>historical share only</small></div>
      ${meter('Below 2.00x (low)', s.lowPercent, s.lowCount, 'low')}
      ${meter('2.00x – 9.99x (mid)', s.midPercent, s.midCount, 'mid')}
      ${meter('10.00x and above (high)', s.highPercent, s.highCount, 'high')}
      <div class="chips" style="margin-top:12px">
        <span class="chip low">Longest low streak: ${s.longestLowStreak}</span>
        <span class="chip low">Current low streak: ${s.currentLowStreak}</span>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><h3>Historical distribution</h3></div>
      ${s.distribution.map((b) => `<div class="dist-row"><span>${b.label}</span>
        <div class="track"><div class="fill" style="width:${b.percent}%"></div></div><span>${b.count}</span></div>`).join('')}
    </div>
    <div class="card">
      <div class="card-head"><h3>Historical trend</h3><small>last ${Math.min(100, s.count)} rounds</small></div>
      <canvas id="trendCanvas" class="trend"></canvas>
      <div class="chips" style="margin-top:10px"><span class="chip low">Dashed red: 2.00x</span><span class="chip high">Dashed purple: 10.00x</span></div>
    </div>
    <p class="disclaimer">Statistics describe past rounds only. Past patterns do not predict or guarantee the next Crash multiplier.</p>`;
  drawTrend(L.trendSeries(values, 100));
}

function drawTrend(arr) {
  const cv = $('#trendCanvas');
  if (!cv || !arr.length) return;
  const W = cv.clientWidth;
  if (W < 50) return;
  const H = 200;
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.round(W * dpr);
  cv.height = Math.round(H * dpr);
  cv.style.height = H + 'px';
  const ctx = cv.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  const pad = { l: 42, r: 10, t: 10, b: 20 };
  const max = Math.max(10, arr.reduce((a, b) => (b > a ? b : a), 0));
  const x = (i) => pad.l + (arr.length < 2 ? (W - pad.l - pad.r) / 2 : i * (W - pad.l - pad.r) / (arr.length - 1));
  const y = (v) => pad.t + (H - pad.t - pad.b) * (1 - v / max);

  ctx.font = '11px system-ui, sans-serif';
  ctx.strokeStyle = 'rgba(255,255,255,0.08)';
  ctx.fillStyle = '#8b9bc4';
  for (let g = 0; g <= 4; g++) {
    const v = max * g / 4;
    ctx.beginPath(); ctx.moveTo(pad.l, y(v)); ctx.lineTo(W - pad.r, y(v)); ctx.stroke();
    ctx.fillText(v.toFixed(v < 10 ? 1 : 0) + 'x', 2, y(v) + 4);
  }
  [[L.LOW_T, '#ff6b6b'], [L.HIGH_T, '#b388ff']].forEach((pair) => {
    ctx.setLineDash([4, 4]); ctx.strokeStyle = pair[1];
    ctx.beginPath(); ctx.moveTo(pad.l, y(pair[0])); ctx.lineTo(W - pad.r, y(pair[0])); ctx.stroke();
    ctx.setLineDash([]);
  });
  ctx.strokeStyle = '#38bdf8'; ctx.lineWidth = 2;
  ctx.beginPath();
  arr.forEach((v, i) => (i ? ctx.lineTo(x(i), y(v)) : ctx.moveTo(x(i), y(v))));
  ctx.stroke();
  ctx.fillStyle = '#38bdf8';
  arr.forEach((v, i) => { ctx.beginPath(); ctx.arc(x(i), y(v), 2.2, 0, Math.PI * 2); ctx.fill(); });
}

/* ---------- SETTINGS: cloud + auth + data ---------- */
function renderAuth() {
  const remote = state.store === RemoteStore;
  $('#modeBadge').textContent = remote ? 'CLOUD' : 'LOCAL';
  $('#cloudStatus').textContent = remote
    ? (RemoteStore.user ? 'Connected to Supabase.' : 'Connected. Sign in to load your history.')
    : 'Local mode: data is stored only on this device.';
  $('#authCard').hidden = !remote;
  $('#authForm').hidden = !!RemoteStore.user;
  $('#signedInBox').hidden = !RemoteStore.user;
  if (RemoteStore.user) $('#whoami').textContent = 'Signed in as ' + RemoteStore.user.email;
}

function onCloudSave(e) {
  e.preventDefault();
  const url = $('#sbUrl').value.trim().replace(/\/$/, '');
  const key = $('#sbKey').value.trim();
  if (!validUrl(url) || key.length < 20) return toast('Enter a valid https project URL and the anon key.', 'error');
  if (jwtRole(key) === 'service_role') return toast('That is a service_role key. Never use it in the app. Use the anon public key.', 'error');
  localStorage.setItem(LS_CFG, JSON.stringify({ url: url, key: key }));
  toast('Saved. Reconnecting…', 'success');
  setTimeout(() => location.reload(), 500);
}

async function testCloud() {
  const url = $('#sbUrl').value.trim().replace(/\/$/, '');
  const key = $('#sbKey').value.trim();
  if (!validUrl(url) || !key) return toast('Fill in the URL and anon key first.', 'error');
  try {
    const client = window.supabase.createClient(url, key);
    const { error } = await client.from('users').select('id').limit(1);
    if (error) throw error;
    toast('Connection OK. Tables are reachable.', 'success');
  } catch (err) { toast('Test failed: ' + err.message, 'error'); }
}

async function afterAuth() {
  await loadPrefs();
  $('#orderSelect').value = state.prefs.order;
  await refreshAll();
}

async function onSignIn() {
  const email = $('#authEmail').value.trim();
  const pass = $('#authPass').value;
  if (!email || pass.length < 6) return toast('Enter an email and a password of at least 6 characters.', 'error');
  try { await RemoteStore.signIn(email, pass); toast('Signed in', 'success'); await afterAuth(); }
  catch (err) { toast('Sign in failed: ' + err.message, 'error'); }
}

async function onSignUp() {
  const email = $('#authEmail').value.trim();
  const pass = $('#authPass').value;
  if (!email || pass.length < 6) return toast('Enter an email and a password of at least 6 characters.', 'error');
  try {
    const r = await RemoteStore.signUp(email, pass);
    toast(r.needsConfirm ? 'Account created. Confirm your email, then sign in.' : 'Account created', 'success');
    if (!r.needsConfirm) await afterAuth();
  } catch (err) { toast('Sign up failed: ' + err.message, 'error'); }
}

async function onSignOut() {
  await RemoteStore.signOut();
  toast('Signed out');
  await loadPrefs();
  await refreshAll();
}

function exportData() {
  const blob = new Blob([JSON.stringify({ app: 'NIRAB CRASH AI', exported_at: new Date().toISOString(), scans: state.scans }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'nirab-crash-history-' + Date.now() + '.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast('Export started', 'success');
}

async function clearLocal() {
  if (!window.confirm('Delete all history stored on this device?')) return;
  await LocalStore.clearAll();
  toast('Local history cleared', 'success');
  await refreshAll();
}

/* ---------- start ---------- */
boot().catch((err) => {
  console.error(err);
  toast('Startup error: ' + (err && err.message ? err.message : err), 'error');
});
