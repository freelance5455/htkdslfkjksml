/* NIRAB CRASH AI — pure logic (no DOM access).
 * Used by the browser app and by the Node unit tests.
 */
(function (root) {
  'use strict';

  const MIN_M = 1;          // smallest accepted multiplier (1.00x)
  const MAX_M = 100000;     // sanity ceiling
  const LOW_T = 2;          // "low" round: below 2.00x
  const HIGH_T = 10;        // "high" round: 10.00x and above
  const X_MARKS = ['x', 'X', '×'];
  const OCR_FIX = { O: '0', o: '0', I: '1', l: '1', '|': '1' };

  const BUCKETS = [
    { label: 'Below 1.00x', min: -Infinity, max: 1 },
    { label: '1.00x – 1.99x', min: 1, max: 2 },
    { label: '2.00x – 2.99x', min: 2, max: 3 },
    { label: '3.00x – 4.99x', min: 3, max: 5 },
    { label: '5.00x – 9.99x', min: 5, max: 10 },
    { label: '10.00x – 49.99x', min: 10, max: 50 },
    { label: '50.00x and above', min: 50, max: Infinity },
  ];

  /* ---------- OCR parsing ---------- */

  // Turns an OCR token such as "2.3l" or "3.4O" into "2.31" / "3.40".
  // Returns null if the token does not look like a multiplier number.
  function normalizeNumeric(raw) {
    let s = String(raw == null ? '' : raw).trim();
    s = s.replace(/[xX×]$/, '');
    if (!s || !/^[0-9OoIl|.,]+$/.test(s)) return null;
    s = s.replace(/[OoIl|]/g, (c) => OCR_FIX[c]).replace(/,/g, '.');
    return /^\d{1,5}\.\d{1,2}$/.test(s) ? s : null;
  }

  // words: [{ text, confidence }] in reading order.
  // Accepts "2.31x", "2.31X", "2.31×" and "2.31" followed by a separate "x" token.
  // A bare number without an x is NOT treated as a multiplier.
  function parseMultipliers(words) {
    const list = Array.isArray(words) ? words : [];
    const out = [];
    for (let i = 0; i < list.length; i++) {
      const text = String(list[i] && list[i].text != null ? list[i].text : '').trim();
      const conf = Number(list[i] && list[i].confidence) || 0;
      const attached = /[xX×]$/.test(text);
      const num = normalizeNumeric(text);
      let used = 0;
      let confidence = conf;
      if (num && attached) {
        used = 1;
      } else if (num && i + 1 < list.length) {
        const nextText = String(list[i + 1] && list[i + 1].text != null ? list[i + 1].text : '').trim();
        if (X_MARKS.indexOf(nextText) !== -1) {
          used = 2;
          confidence = Math.min(conf, Number(list[i + 1].confidence) || 0);
        }
      }
      if (!used) continue;
      const value = Number(num);
      if (!(value >= MIN_M && value <= MAX_M)) continue;
      out.push({ value: value, confidence: Math.round(confidence), source: 'ocr' });
      i += used - 1;
    }
    return out;
  }

  /* ---------- Crop geometry ---------- */

  // crop: percentages {top, bottom, left, right}, each clamped to 0–40.
  function cropRect(w, h, crop) {
    const c = crop || {};
    const p = (k) => Math.min(40, Math.max(0, Number(c[k]) || 0)) / 100;
    const sx = Math.round(w * p('left'));
    const sy = Math.round(h * p('top'));
    let sw = Math.round(w * (1 - p('left') - p('right')));
    let sh = Math.round(h * (1 - p('top') - p('bottom')));
    sw = Math.max(1, Math.min(sw, w - sx));
    sh = Math.max(1, Math.min(sh, h - sy));
    return { sx: sx, sy: sy, sw: sw, sh: sh };
  }

  /* ---------- Statistics ---------- */

  const round2 = (n) => (n == null || !Number.isFinite(n) ? null : Math.round(n * 100) / 100);
  const pct = (part, whole) => (whole ? round2((part * 100) / whole) : 0);
  const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null);
  const maxOf = (arr) => arr.reduce((a, b) => (b > a ? b : a), -Infinity);
  const minOf = (arr) => arr.reduce((a, b) => (b < a ? b : a), Infinity);

  function median(arr) {
    if (!arr.length) return null;
    const s = arr.slice().sort((a, b) => a - b);
    const m = s.length >> 1;
    return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
  }

  // values: numbers in chronological order (oldest first).
  function windowStats(values, k) {
    const slice = values.slice(-k);
    if (!slice.length) return null;
    const low = slice.filter((v) => v < LOW_T).length;
    return {
      size: k,
      count: slice.length,
      partial: slice.length < k,
      average: round2(avg(slice)),
      highest: round2(maxOf(slice)),
      lowest: round2(minOf(slice)),
      lowPercent: pct(low, slice.length),
    };
  }

  function computeStats(values) {
    const n = values.length;
    if (!n) return { count: 0 };
    let low = 0, high = 0;
    let longestLow = 0, run = 0;
    for (const v of values) {
      if (v < LOW_T) { low++; run++; if (run > longestLow) longestLow = run; } else { run = 0; }
      if (v >= HIGH_T) high++;
    }
    const mid = n - low - high;
    let currentLow = 0;
    for (let i = n - 1; i >= 0 && values[i] < LOW_T; i--) currentLow++;

    const distribution = BUCKETS.map((b) => {
      const count = values.filter((v) => v >= b.min && v < b.max).length;
      return { label: b.label, count: count, percent: pct(count, n) };
    });

    return {
      count: n,
      average: round2(avg(values)),
      median: round2(median(values)),
      highest: round2(maxOf(values)),
      lowest: round2(minOf(values)),
      lowCount: low,
      midCount: mid,
      highCount: high,
      lowPercent: pct(low, n),
      midPercent: pct(mid, n),
      highPercent: pct(high, n),
      longestLowStreak: longestLow,
      currentLowStreak: currentLow,
      windows: {
        last10: windowStats(values, 10),
        last50: windowStats(values, 50),
        last100: windowStats(values, 100),
      },
      distribution: distribution,
    };
  }

  function trendSeries(values, k) {
    return values.slice(-(k || 100));
  }

  const api = {
    MIN_M: MIN_M, MAX_M: MAX_M, LOW_T: LOW_T, HIGH_T: HIGH_T,
    normalizeNumeric: normalizeNumeric,
    parseMultipliers: parseMultipliers,
    cropRect: cropRect,
    computeStats: computeStats,
    trendSeries: trendSeries,
    BUCKETS: BUCKETS,
  };

  root.NiraLogic = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
