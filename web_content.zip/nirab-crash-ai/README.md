# NIRAB CRASH AI

Crash game screenshot analyzer for 499Bet Crash screenshots, by **Nirab 10k**.

It reads multiplier values from screenshots with OCR (Tesseract.js), lets you correct them,
saves them to history, and builds statistics and charts from past rounds.

> **Important:** the app does not predict the next Crash multiplier. Each round is random.
> Statistics only describe rounds that have already happened.

---

## 1. What it does

| Area | Feature |
|---|---|
| Upload | Gallery picker, JPG / JPEG / PNG / WEBP, up to 15 MB each, up to 20 in a queue, preview, crop (4 sliders with live preview), remove, invalid-file errors, upload progress |
| OCR | Tesseract.js (`eng`), sparse-text mode, crop + 2× upscale + contrast boost before reading, reads `x`-suffixed values, fixes common OCR letter/digit confusions (O→0, l→1), per-value confidence, low-confidence rows highlighted, clear error when nothing is found |
| Correction | Edit any value, add a missing value, delete a wrong one. Values outside 1.00x–100000x are blocked from saving |
| Save / delete | Save a scan's values to history; delete one scan or all history |
| Statistics | Average, median, highest, lowest, last 10 / 50 / 100 rounds, low (<2x) / mid / high (≥10x) shares, longest and current low streaks, historical distribution, trend chart |
| Storage | Works fully offline on the device (LocalStorage). Optional Supabase cloud with email/password accounts and Row Level Security |
| Navigation | HOME · SCANNER · ANALYSIS · HISTORY · SETTINGS (all buttons are wired to views) |
| Mobile | Responsive, touch-sized controls, safe-area support, offline shell via service worker |

---

## 2. Project files

```
nirab-crash-ai/
├── index.html        App shell, all five screens, loads the libraries
├── style.css         Dark glassmorphism theme, neon accents, responsive layout
├── script.js         UI, upload, crop, OCR, storage (local + Supabase), charts
├── logic.js          Pure logic: multiplier parsing, crop geometry, statistics
├── config.js         Optional Supabase URL + anon key (empty by default)
├── database.sql      Supabase schema, triggers and RLS policies
├── manifest.json     PWA manifest (installable, standalone display)
├── sw.js             Service worker: offline app shell
├── icon.svg          App icon
├── tests/logic.test.js  Unit tests for parsing and statistics
└── README.md         This guide
```

Tables (see `database.sql`): `users`, `scan_history`, `multiplier_history`, `settings`.

---

## 3. Run it locally (no Supabase needed)

Browsers block service workers and some features on `file://`, so serve the folder over HTTP.

```bash
cd nirab-crash-ai
python3 -m http.server 8080
```

Open `http://localhost:8080` on your computer. On a phone on the same Wi-Fi, use your computer's
LAN address (for example `http://192.168.1.20:8080`). Note that camera-style secure-context features
need HTTPS, but the gallery picker works over HTTP.

**First scan needs internet** because the OCR engine (about 10 MB of language data) is loaded from
the jsDelivr CDN. After that, the service worker caches the files it has fetched.

To run OCR fully offline, download `tesseract.min.js`, its worker and the `eng` language data
into a `vendor/` folder and change the two `<script>` tags in `index.html` to point there.

---

## 4. Set up Supabase (optional cloud sync)

1. Create a project at https://supabase.com.
2. Open **SQL Editor → New query**, paste the whole of `database.sql`, and click **Run**.
3. Open **Project Settings → API** and copy:
   - **Project URL**
   - **anon public** key (this is the only key the app uses)
4. Put them in the app: **Settings → Cloud sync → Save & connect**, or in `config.js`.
5. Go to **Settings → Account**, create an account with email and password (min 6 characters),
   and sign in.
   - If email confirmation is on (default), confirm the email first.
   - Optional: under **Authentication → Providers → Email**, turn off "Confirm email" while testing.

**Security rules**

- Only the **anon public** key goes in the app. It is designed to be public.
- **Never** put the `service_role` key in the app, `config.js` or any frontend file.
  The app refuses a key whose JWT role is `service_role`.
- RLS policies in `database.sql` ensure each user can only read and write their own rows.

If you are not signed in while in cloud mode, history stays empty and the app shows a banner.
Without Supabase settings, the app runs in local mode and all data stays on the device.

---

## 5. How scanning works

1. **Pick screenshots** from the gallery. Each file is checked for type, size and whether it can be decoded.
2. **Crop** (optional but recommended) so only the round-history list remains.
3. **Scan** reads the image. The app crops, upscales 2×, converts to grayscale and boosts contrast,
   then runs Tesseract. It keeps values written as a number followed by `x` (for example `2.31x`).
4. **Review** the detected values. Amber rows had low OCR confidence. Fix any wrong ones.
5. **Save.** Settings → *Screenshot order* decides which end of the list is the newest round:
   - *Newest at the top* (default): the list is reversed before saving, so the bottom is the oldest.
   - *Newest at the bottom*: saved in the on-screen order.

Accuracy depends on screenshot quality. Crop tightly, avoid blur, and always check the values
before saving.

---

## 6. Build an Android APK (Capacitor)

The app is plain HTML/CSS/JS, so it runs in an Android WebView through Capacitor.
Capacitor serves the files from `https://localhost`, which allows the service worker and the CDN calls.

**Requirements:** Node.js 18+, Android Studio (with an Android SDK), JDK 17.

```bash
# 1. Make a Capacitor project next to the app folder
mkdir nirab-apk && cd nirab-apk
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Copy the web app into www/
mkdir www
cp -r ../nirab-crash-ai/* www/

# 3. Initialise and add Android
npx cap init "NIRAB CRASH AI" com.nirab.crashai --web-dir=www
npx cap add android
npx cap copy android

# 4. Open in Android Studio and build
npx cap open android
```

In Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The APK appears under
`android/app/build/outputs/apk/debug/`. For a release build, create a signing key and use
**Build → Generate Signed Bundle / APK**.

After you change the web files, run `cp -r ../nirab-crash-ai/* www/ && npx cap copy android`
and rebuild. Bump `CACHE_VERSION` in `sw.js` so installed copies refresh.

Notes for the WebView:

- The gallery picker uses the standard file input. Capacitor's WebView supports it.
- The OCR and Supabase libraries load from the internet on first use.
- Local data is stored in the WebView's LocalStorage. Clearing the app's data deletes it.

---

## 7. Testing status (honest summary)

| Check | Result |
|---|---|
| JavaScript syntax (`node --check`) on all `.js` files | Passed |
| `manifest.json` is valid JSON; `index.html` tags are balanced; every ID used by `script.js` exists | Passed |
| Multiplier parser and statistics unit tests (`node tests/logic.test.js`) | Passed |
| Real OCR on a generated crash-history image using Tesseract 5.3.4 (the same `eng` model family) → parser | All 8 values read correctly (`1.23, 2.45, 10.67, 1.05, 3.40, 1.91, 25.10, 1.00`) |
| In-browser run of the full UI (taps, crop sliders, save, delete, chart drawing) | **Not tested.** It needs a real browser. Please test it. |
| Browser OCR with tesseract.js on your real 499Bet screenshots | **Not tested.** Accuracy varies with screenshot quality. |
| Supabase connection, sign-up and RLS against a live project | **Not tested.** Run `database.sql` and check it yourself. |
| Android APK build and install | **Not tested.** Follow Section 6 and test on a device. |

Please run through this checklist on your device before using the app for decisions:

- [ ] Pick 2–3 screenshots from the gallery; invalid files show an error
- [ ] Crop works and the preview matches what is read
- [ ] Scan finds the multipliers; correct a wrong value; save
- [ ] Analysis numbers match a manual count of the same values
- [ ] Delete one scan; delete all history
- [ ] Cloud: create account, save, reload, data is still there; second account sees none of it
- [ ] Every bottom-nav button opens its screen; layout is fine at phone width

---

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| "OCR engine did not load" | Check internet. The first scan downloads the OCR files. |
| "No multiplier values found" | Crop closer to the list of multipliers, make sure the image is sharp, and scan again. |
| Cloud banner "Sign in" | Open Settings → Account and sign in. |
| "Invalid or unreadable image" | Use JPG, PNG or WEBP. Re-export HEIC/odd formats first. |
| Old version still showing | Hard-refresh, or bump `CACHE_VERSION` in `sw.js` and reload. |

---

## 9. Credits

Project: **NIRAB CRASH AI** · Creator: **Nirab 10k**
