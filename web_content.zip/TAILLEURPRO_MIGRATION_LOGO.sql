alter table public.ateliers add column if not exists logo_url text;
