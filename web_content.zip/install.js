(() => {
  const button = document.getElementById('installApp');
  const status = document.getElementById('appStatus');
  const help = document.getElementById('installHelp');
  const instructions = document.getElementById('installInstructions');
  const standalone = window.matchMedia('(display-mode: standalone)');
  let promptEvent = null;
  const installed = () => {
    if (standalone.matches || navigator.standalone) {
      button.hidden = true;
      status.textContent = 'Forma অ্যাপে স্বাগতম।';
    }
  };
  const showHelp = () => {
    if (location.protocol === 'file:') instructions.textContent = 'অ্যাপ ইনস্টল করতে এই ফাইলগুলো HTTPS ওয়েবসাইটে আপলোড করে সেই লিংক Chrome-এ খুলুন। স্থানীয় HTML থেকে ইনস্টল করা যায় না।';
    else if (/iPhone|iPad|iPod/.test(navigator.userAgent)) instructions.textContent = 'Safari-তে এই ওয়েবসাইট খুলুন। Share → Add to Home Screen → Add চাপুন।';
    if (typeof help.showModal === 'function') help.showModal();
    else alert(instructions.textContent);
  };
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); promptEvent = event;
    button.hidden = false; button.textContent = '↓ Install App'; installed();
  });
  window.addEventListener('appinstalled', () => {
    promptEvent = null; button.hidden = true; status.textContent = 'ইনস্টল হয়েছে — হোমস্ক্রিনে Forma খুঁজুন।';
  });
  button.addEventListener('click', async () => {
    if (!promptEvent) { showHelp(); return; }
    const event = promptEvent; promptEvent = null; button.disabled = true;
    try {
      await event.prompt();
      const choice = await event.userChoice;
      status.textContent = choice.outcome === 'accepted' ? 'ইনস্টল প্রক্রিয়া চলছে…' : 'পরে চাইলে আবার ইনস্টল করতে পারবেন।';
    } catch { showHelp(); }
    finally { button.disabled = false; }
  });
  standalone.addEventListener?.('change', installed);
  installed();
  if ('serviceWorker' in navigator && window.isSecureContext && location.protocol !== 'file:') {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js', {scope: './'}).catch(() => {
        status.textContent = 'ইনস্টল সহায়তার জন্য Install App চাপুন।';
      });
    });
  }
})();
