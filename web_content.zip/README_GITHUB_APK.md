# InterLink All Stock V36

This project includes the native Android PrintManager and Share bridge.

## GitHub APK build
1. Create a new GitHub repository.
2. Upload the contents of this project to the repository root (not the ZIP file itself).
3. Open **Actions** and select **Build InterLink APK**.
4. Click **Run workflow**.
5. After the run finishes, open the workflow run and download the artifact named **InterLinkAllStock-v36-debug-apk**.
6. Inside the downloaded artifact is the APK.
