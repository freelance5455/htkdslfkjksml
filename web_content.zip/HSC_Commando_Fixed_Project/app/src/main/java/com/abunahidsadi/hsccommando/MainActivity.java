package com.abunahidsadi.hsccommando;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT_JSON = 701;
    private static final int REQUEST_EXPORT_JSON = 702;
    private static final int REQUEST_IMPORT_NATIVE_JSON = 703;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupBase64;
    private String pendingBackupName = "HSC-Commando-backup.json";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7,17,31));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,17,31));
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "application/octet-stream", "text/plain"});
                try { startActivityForResult(intent, REQUEST_IMPORT_JSON); }
                catch (Exception e) {
                    filePathCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No file picker is available on this device.", Toast.LENGTH_LONG).show();
                }
                return true;
            }

            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }

            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton("Continue", (d, w) -> result.confirm())
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }

            @Override public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setText(defaultValue == null ? "" : defaultValue);
                new AlertDialog.Builder(MainActivity.this).setTitle(message).setView(input)
                    .setPositiveButton("OK", (d, w) -> result.confirm(input.getText().toString()))
                    .setNegativeButton("Cancel", (d, w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }

            @Override public boolean onConsoleMessage(ConsoleMessage message) {
                Log.d("HSC-WebView", message.message() + " (line " + message.lineNumber() + ")");
                return true;
            }
        });
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private class AndroidBridge {
        @android.webkit.JavascriptInterface
        public void chooseBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
                try { startActivityForResult(intent, REQUEST_IMPORT_NATIVE_JSON); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Could not open the file picker.", Toast.LENGTH_LONG).show(); }
            });
        }

        @android.webkit.JavascriptInterface
        public void saveBackup(String base64, String filename) {
            runOnUiThread(() -> {
                pendingBackupBase64 = base64;
                pendingBackupName = (filename == null || filename.trim().isEmpty()) ? "HSC-Commando-backup.json" : filename.replaceAll("[^A-Za-z0-9._-]", "_");
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                try { startActivityForResult(intent, REQUEST_EXPORT_JSON); }
                catch (Exception e) { pendingBackupBase64 = null; Toast.makeText(MainActivity.this, "Could not open Android save dialog.", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT_JSON) {
            if (filePathCallback != null) {
                Uri[] results = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else if (requestCode == REQUEST_IMPORT_NATIVE_JSON) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                Toast.makeText(this, "Backup import cancelled.", Toast.LENGTH_SHORT).show();
                return;
            }
            try (InputStream in = getContentResolver().openInputStream(data.getData());
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) throw new IllegalStateException("Cannot open selected backup");
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                String quoted = org.json.JSONObject.quote(json);
                webView.post(() -> webView.evaluateJavascript("window.importBackupText(" + quoted + ")", null));
            } catch (Exception e) {
                Log.e("HSC-Backup", "Import failed", e);
                Toast.makeText(this, "Could not read that JSON backup.", Toast.LENGTH_LONG).show();
            }
        } else if (requestCode == REQUEST_EXPORT_JSON) {
            if (resultCode != RESULT_OK || data == null || data.getData() == null || pendingBackupBase64 == null) {
                Toast.makeText(this, "Backup save cancelled.", Toast.LENGTH_SHORT).show();
                pendingBackupBase64 = null;
                return;
            }
            Uri uri = data.getData();
            String encoded = pendingBackupBase64;
            pendingBackupBase64 = null;
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IllegalStateException("Cannot open destination");
                byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                out.write(bytes);
                out.flush();
                Toast.makeText(this, "JSON backup saved successfully.", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Log.e("HSC-Backup", "Export failed", e);
                Toast.makeText(this, "Backup export failed. Please try another folder.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) { webView.removeJavascriptInterface("AndroidBridge"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
