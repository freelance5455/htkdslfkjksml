# HSC Commando — repaired Android project

This project reconstructs an editable Android Studio project around the uploaded HSC Tracker web app and repairs the broken controls identified in the APK review.

## Repairs included

- **Remove/delete/clear controls:** destructive actions now use an in-app confirmation overlay instead of relying on JavaScript `confirm()` dialogs, which can fail in some Android WebView wrappers. This covers topic/chapter removal, exam deletion, subject removal, planner target clearing, and reset.
- **JSON export:** implements `exportBackup()`. Android builds open the native “Save as” document picker and write the JSON bytes through `ContentResolver`; browser preview uses a Blob download fallback.
- **JSON import:** Android uses a native document picker and passes the selected JSON directly into the app; the app validates the backup, asks before replacing local state using the in-app confirmation overlay, and restores subjects, topics, exams, progress, and planner data. Browser fallback remains available.
- **Add chapter:** replaces the multi-prompt workflow with an in-app subject/paper/chapter form and refreshes syllabus, planner, and exam pickers.
- **Manage Subjects restored:** Settings includes Add Subject and Remove Subject controls again, with linked chapter/exam/planner references cleaned up on removal.
- **Android WebView:** enables JavaScript and DOM storage; native Android file pickers are used for import/export, with an in-app confirmation overlay for destructive actions.
- Keeps the 135 preloaded chapter records and the existing offline-first UI.

## Build an APK (computer or phone-only via GitHub Actions)

### Android Studio

1. Open this folder in **Android Studio** on a computer with Android SDK Platform 35 and JDK 17 installed.
2. Allow Gradle to sync/download the Android Gradle Plugin and dependencies.
3. Select **Build → Build APK(s)**.
4. The debug APK should be generated at `app/build/outputs/apk/debug/app-debug.apk`.

### If you only have an Android phone

1. Create a new repository on GitHub (or use a separate test repository).
2. Upload the **contents** of this ZIP into the repository's main branch, keeping `.github/workflows/android-build.yml` and the `app/` folder structure intact. GitHub's website may require enabling “Show hidden files” in a file manager if uploading through a ZIP extraction workflow.
3. Open the repository's **Actions** tab, choose **Build HSC Commando APK**, then tap **Run workflow** (or push a commit to `main`).
4. When the run succeeds, open that run and download the `HSC-Commando-debug-APK` artifact. Extract the artifact ZIP to get `app-debug.apk`.
5. Install only after exporting a backup from the current app. Android may treat this rebuilt app as a different signing identity.

This chat environment does not have Android SDK/build tools installed, so an APK has **not** been compiled or installed here. The source package is provided rather than a falsely labelled “tested APK”. Android Studio needs internet access for its first Gradle sync unless the required plugin and SDK packages are already cached.

## Important data warning

The package uses the same app ID as the reconstructed project only. The original APK's package ID and signing key could not be verified from the available build tools, and its signing key is not available here. Android may install this as a separate app or refuse an in-place update, depending on the original package ID. Export a JSON backup from the current app first. If Android requires uninstalling the old package before installing a differently signed build, uninstalling can erase that app's private WebView data.

## Test checklist after building

- Install and launch offline; confirm dashboard and syllabus render.
- Create an exam, tap Delete, choose Cancel (exam remains), then Delete (exam disappears).
- Export JSON and confirm the file exists and parses as JSON.
- Import the exported file and confirm topics, checkpoints, exams, custom subjects and planner targets return.
- Try importing malformed JSON; app should show an error and retain existing data.
- Add a chapter and confirm it appears in HSC Syllabus, My Exams picker and Planner picker.
- Close and reopen the app; confirm local progress persists.

JavaScript syntax and ZIP integrity can be checked in this environment, but this environment does not have the Android SDK/Gradle build tools. The APK has not been compiled or device-tested here; run the Android build and device checklist before treating the changes as verified on-device.
