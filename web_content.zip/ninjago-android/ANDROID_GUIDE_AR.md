# دليل تحويل «سبينجيتسو بريكس» إلى تطبيق أندرويد (Capacitor)

## ما الذي تغيّر في الكود
| الملف | الدور |
|---|---|
| `www/index.html` | الصفحة فقط (ميتا موبايل، تحميل الملفات). |
| `www/css/game.css` | التنسيق + تخطيط الأفقي (Landscape) + مناطق الأمان (notch). |
| `www/js/boot.js` | يستعيد الحفظ من تخزين أندرويد قبل تشغيل اللعبة. |
| `www/js/game.js` | اللعبة نفسها (+ تحسينات الأداء أدناه). |
| `www/js/mobile.js` | طبقة الموبايل: منع سلوكيات المتصفح، الحفظ، دورة الحياة، زر الرجوع، الدقة الديناميكية. |

**الأداء:** ظلال 1024 بدل 2048 وفلتر أخف على الموبايل، سقف دقة 1.5×، دقة ديناميكية (تنزل حتى 0.7× لو الإطارات أقل من ~46 وترجع تلقائيًا)، التوهج (Bloom) مقفول افتراضيًا على الأجهزة الضعيفة (قابل للتشغيل من الإعدادات)، وتحرير ذاكرة الـGPU عند تغيير المرحلة.
**الحفظ:** `localStorage` + نسخة في Capacitor Preferences (SharedPreferences)، وتُستعاد تلقائيًا لو مسح النظام بيانات الـWebView.
**دورة الحياة:** إيقاف مؤقت تلقائي عند الخروج للخلفية، تعليق الصوت واستئنافه، وزر الرجوع يغلق اللوحات بالترتيب ثم يوقف اللعبة ثم يخرج من القائمة الرئيسية.
**الاتجاه:** إعداد جديد «الاتجاه» (تلقائي/طولي/عرضي) والواجهة تتكيّف مع الاثنين.

## المتطلبات
- Node.js (LTS) و JDK 21 و Android Studio الأحدث مع Android SDK **36**.
- حساب Google Play Developer (رسم تسجيل لمرة واحدة).

## الخطوات
1. **فك الضغط** وافتح الطرفية داخل المجلد `ninjago-android`.
2. **تثبيت Capacitor** (يجلب أحدث إصدار يدعم API 36):
   ```bash
   npm i @capacitor/core @capacitor/app @capacitor/preferences @capacitor/status-bar @capacitor/screen-orientation
   npm i -D @capacitor/cli
   ```
3. **غيّر المعرّف**: افتح `capacitor.config.json` وغيّر `appId` إلى معرّفك الفريد (مثال `com.yourname.ninjagobricks`) — لا يتغير بعد النشر.
4. **ضع مكتبة three محليًا** (لتعمل اللعبة بدون إنترنت):
   ```bash
   npm i three@0.128.0
   cp node_modules/three/build/three.min.js www/lib/three.min.js
   ```
5. **(اختياري) الخطوط محليًا**: حمّل Lalezar و Cairo (600/800) بصيغة woff2 من google-webfonts-helper، ضعها في `www/fonts`، وفعّل القواعد في `www/css/fonts.css`. بدونها تستخدم الخطوط الاحتياطية.
6. **إضافة أندرويد وتزامن الملفات**:
   ```bash
   npx cap add android
   npx cap sync android
   ```
7. **الوضع الغامر**: انسخ `android-snippets/MainActivity.java` فوق `android/app/src/main/java/<مسار الحزمة>/MainActivity.java` (عدّل سطر `package` ليطابق `appId`).
8. **النوتش**: ضع `android-snippets/styles-v28.xml` (بدون سطر التعليق الأول) في `android/app/src/main/res/values-v28/styles.xml`.
9. **المانيفست** `android/app/src/main/AndroidManifest.xml` داخل `<activity>`:
   - `android:screenOrientation="fullSensor"` (أو `sensorPortrait` لو تريد طوليًا فقط)
   - `android:hardwareAccelerated="true"`
10. **إصدار الـSDK**: في `android/variables.gradle` اجعل `compileSdkVersion` و `targetSdkVersion` = **36** (جوجل تشترطه للتطبيقات الجديدة والتحديثات منذ 31 أغسطس 2026) و `minSdkVersion` = 24 أو ما يضعه Capacitor.
11. **الأيقونة وشاشة البداية**: ضع `resources/icon.png` (1024×1024) و `resources/splash.png` (2732×2732) ثم:
    ```bash
    npm i -D @capacitor/assets && npx capacitor-assets generate --android
    ```
12. **التجربة على جهاز/محاكي**:
    ```bash
    npx cap sync android && npx cap open android
    ```
    ثم Run ▶ من Android Studio (أو `npx cap run android`). فعّل USB debugging على هاتفك.
    **جرّب:** النوم/الاستيقاظ، زر الرجوع، تدوير الشاشة، الصوت بعد أول لمسة، وإغلاق التطبيق وفتحه للتأكد من الحفظ.

## بناء الملفات
- **APK للتجربة:** `cd android && ./gradlew assembleDebug` ← `android/app/build/outputs/apk/debug/app-debug.apk`.
- **AAB للنشر (جوجل بلاي تقبل AAB وليس APK):**
  1. أنشئ مفتاح التوقيع **واحتفظ به ونسخته الاحتياطية**:
     ```bash
     keytool -genkeypair -v -keystore ninjago-release.jks -alias ninjago -keyalg RSA -keysize 2048 -validity 10000
     ```
  2. من Android Studio: Build ▸ Generate Signed App Bundle ▸ Android App Bundle ▸ اختر المفتاح ▸ release.
     أو أضف إعداد التوقيع في Gradle ثم `./gradlew bundleRelease`.
  3. الناتج: `android/app/build/outputs/bundle/release/app-release.aab`.
- كل نسخة جديدة: ارفع `versionCode` في `android/app/build.gradle`.

## النشر على Google Play
1. Play Console ▸ إنشاء تطبيق (اللغة، لعبة، مجاني/مدفوع).
2. ارفع الـAAB أولًا على مسار **Internal testing** وجرّبه.
3. أكمل: صفحة المتجر (أيقونة 512، صورة 1024×500، لقطات شاشة)، **تقييم المحتوى**، **Data safety** (اللعبة لا ترسل بيانات؛ الحفظ محلي)، **سياسة الخصوصية** (رابط)، **الجمهور المستهدف**.
4. الحسابات الشخصية الجديدة قد تتطلب **اختبارًا مغلقًا** بعدد محدد من المختبرين لفترة قبل الإنتاج؛ راجع شروط حسابك في Console.
5. بما أن اللعبة بعلامات NINJAGO/LEGO: جهّز وثائق الترخيص لأن مراجعة جوجل قد تطلب إثبات حقوق استخدام العلامة والأسماء والصور.
6. بعد الموافقة: Production ▸ Release.

## مشاكل شائعة
- **شاشة سوداء:** تأكد أن `three.min.js` موجود في `www/lib` ثم `npx cap sync`. افحص عبر `chrome://inspect` على الحاسوب.
- **لا صوت:** الأندرويد يشترط لمسة أولى؛ اللعبة تفعّل الصوت عند الضغط على «ابدأ».
- **زر الرجوع يغلق التطبيق مباشرة:** تأكد من تثبيت `@capacitor/app` ثم `npx cap sync` (مع API 36 يعتمد على «Predictive Back» الذي يدعمه Capacitor الحديث).
- **الواجهة خلف أشرطة النظام/النوتش:** تأكد من الخطوتين 7 و 8 وأنك تستخدم أحدث Capacitor.
- **بطء:** من الإعدادات أوقف «التوهج» أو اضبط «الرسوميات» على خفيفة.
