/* boot.js: يستعيد الحفظ من Capacitor Preferences (تخزين أندرويد) قبل تشغيل اللعبة */
(function(){window.__restoring=false;var C=window.Capacitor,P=C&&C.Plugins&&C.Plugins.Preferences;if(!P)return;
var ks=['marari_v3','marari_set'],need=ks.filter(function(k){return localStorage.getItem(k)===null});
if(!need.length||sessionStorage.getItem('rst'))return;window.__restoring=true;
Promise.all(need.map(function(k){return P.get({key:k}).then(function(r){var ok=r&&r.value!=null;if(ok)localStorage.setItem(k,r.value);return ok})})).then(function(a){window.__restoring=false;if(a.some(Boolean)){sessionStorage.setItem('rst','1');location.reload()}}).catch(function(){window.__restoring=false})})();
