/* mobile.js: طبقة الموبايل والتغليف (Capacitor / WebView) — تُحمّل بعد game.js */
(()=>{'use strict';
const CAP=window.Capacitor,PL=(CAP&&CAP.Plugins)||{},NAT=!!(CAP&&CAP.isNativePlatform&&CAP.isNativePlatform());
/* 1) منع سلوكيات المتصفح: قائمة الضغط المطوّل، التحديد، التكبير بالقرص، النقر المزدوج، السحب للتحديث */
const stop=e=>e.preventDefault();
['contextmenu','selectstart','dragstart','gesturestart','gesturechange','gestureend','dblclick'].forEach(t=>document.addEventListener(t,stop,{passive:false}));
document.addEventListener('touchmove',e=>{if(!(e.target.closest&&e.target.closest('.ov2')))e.preventDefault()},{passive:false});
document.addEventListener('touchstart',e=>{if(e.touches.length>1)e.preventDefault()},{passive:false});
/* 2) تخزين: localStorage كذاكرة سريعة + مرآة في Capacitor Preferences (SharedPreferences في أندرويد) */
const P=PL.Preferences,KEYS=['marari_v3','marari_set','marari_ori'];let tm=0;
function flush(){if(!P||window.__restoring)return;KEYS.forEach(k=>{const v=localStorage.getItem(k);if(v!==null)P.set({key:k,value:v})})}
const _si=Storage.prototype.setItem;Storage.prototype.setItem=function(k,v){_si.call(this,k,v);if(P&&this===localStorage&&KEYS.includes(k)){clearTimeout(tm);tm=setTimeout(flush,1200)}};
/* 3) الإعدادات المحفوظة + الاتجاه + التوهج */
try{Object.assign(S,JSON.parse(localStorage.getItem('marari_set')||'{}'))}catch(e){}
const saveSet=()=>{try{localStorage.setItem('marari_set',JSON.stringify(S))}catch(e){}};
let OR=localStorage.getItem('marari_ori')||'auto';window.ORIL=()=>OR==='auto'?'any':OR;
function applyOri(){try{if(PL.ScreenOrientation)OR==='auto'?PL.ScreenOrientation.unlock():PL.ScreenOrientation.lock({orientation:OR});else if(screen.orientation)OR==='auto'?screen.orientation.unlock():screen.orientation.lock(OR).catch(()=>{})}catch(e){}}
L2.sBl=['التوهج (Bloom)','bl'];const box=document.querySelector('#set .set'),b1=document.createElement('button'),b2=document.createElement('button');b1.id='sBl';b2.id='sOri';box.append(b1,b2);
b1.onclick=()=>{S.bl=S.bl?0:1;setLab();saveSet()};
b2.onclick=()=>{OR={auto:'portrait',portrait:'landscape',landscape:'auto'}[OR];localStorage.setItem('marari_ori',OR);applyOri();setLab()};
['sSnd','sVoice','sMusic','sQ'].forEach(i=>$(i).addEventListener('click',saveSet));
const _sl=setLab;setLab=function(){_sl();b2.innerHTML='<span>الاتجاه</span><span>'+{auto:'تلقائي',portrait:'طولي',landscape:'عرضي'}[OR]+'</span>'};
applyQ();setLab();applyOri();
/* 4) دورة حياة أندرويد: إيقاف مؤقت في الخلفية، استئناف الصوت، زر الرجوع */
const pauseGame=()=>{if(state==='play')$('pzb').click();try{if(ac&&ac.state==='running')ac.suspend()}catch(e){}try{speechSynthesis.cancel()}catch(e){}flush()};
const resumeAudio=()=>{try{if(ac&&ac.state==='suspended')ac.resume()}catch(e){}};
document.addEventListener('visibilitychange',()=>document.hidden?pauseGame():resumeAudio());addEventListener('pagehide',pauseGame);
function onBack(){const sh=i=>$(i)&&$(i).classList.contains('show');
 if(sh('rm')){$('rmb').click();return true}if(sh('shp')){$('shb').click();return true}if(sh('lvm')){$('lvb').click();return true}if(sh('set')){$('back').click();return true}
 if(sh('pz')){$('pzc').click();return true}if(state==='play'){$('pzb').click();return true}if(sh('over')){$('toMenu').click();return true}
 return state==='comic'||state==='cine'}
if(PL.App){PL.App.addListener('appStateChange',s=>s.isActive?resumeAudio():pauseGame());PL.App.addListener('backButton',()=>{if(!onBack()&&PL.App.exitApp)PL.App.exitApp()})}
else try{history.pushState({g:1},'');addEventListener('popstate',()=>{history.pushState({g:1},'');onBack()})}catch(e){}
/* 5) المقاس والاتجاه + وضع ملء الشاشة */
const fit=()=>{try{resize()}catch(e){}};addEventListener('orientationchange',()=>setTimeout(fit,250));if(window.visualViewport)visualViewport.addEventListener('resize',fit);
if(PL.StatusBar&&PL.StatusBar.hide)try{PL.StatusBar.hide()}catch(e){}
/* 6) دقّة ديناميكية للحفاظ على ~60 إطار */
let fr=0,pr=Math.min(devicePixelRatio,PRM),base=pr,tk=performance.now(),cool=0;(function c(){fr++;requestAnimationFrame(c)})();
setInterval(()=>{const n=performance.now(),fps=fr*1000/(n-tk);fr=0;tk=n;if(document.hidden||state!=='play'||!S.q)return;
 if(fps<46&&pr>.7){pr=Math.max(.7,pr-.15);renderer.setPixelRatio(pr);resize();cool=4}else if(fps>57&&pr<base&&--cool<=0){pr=Math.min(base,pr+.1);renderer.setPixelRatio(pr);resize();cool=4}},2000);
})();
