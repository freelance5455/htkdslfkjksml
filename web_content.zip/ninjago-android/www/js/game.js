const T=THREE,$=id=>document.getElementById(id);
const COARSE=matchMedia('(pointer:coarse)').matches,LOW=COARSE&&((navigator.deviceMemory||4)<=3||(navigator.hardwareConcurrency||4)<=4),PRM=COARSE?1.5:2;
const HERO_LINE='يا مرار يا مراري!',ENEMY_LINE='يا نهار أبيض يا نهار أبيض!';
const renderer=new T.WebGLRenderer({antialias:!LOW,canvas:$('c'),powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,PRM));renderer.shadowMap.enabled=true;renderer.shadowMap.type=COARSE?T.PCFShadowMap:T.PCFSoftShadowMap;
const scene=new T.Scene();scene.background=new T.Color(0x14213d);scene.fog=new T.Fog(0x14213d,28,75);
const cam=new T.PerspectiveCamera(55,1,.1,200);
scene.add(new T.HemisphereLight(0xbfd4ff,0x2a2438,.85));
const sun=new T.DirectionalLight(0xffe2b0,.9);sun.position.set(12,22,10);sun.castShadow=true;sun.shadow.mapSize.set(COARSE?1024:2048,COARSE?1024:2048);
Object.assign(sun.shadow.camera,{left:-26,right:26,top:26,bottom:-26,near:1,far:60});scene.add(sun);const rim=new T.DirectionalLight(0x6ea8ff,.5);rim.position.set(-10,8,-12);scene.add(rim);
{const p=[];for(let i=0;i<500;i++){const a=Math.random()*6.283,b=Math.random()*1.3+.15,r=95;p.push(Math.cos(a)*Math.cos(b)*r,Math.sin(b)*r,Math.sin(a)*Math.cos(b)*r)}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));scene.add(new T.Points(g,new T.PointsMaterial({color:0xffffff,size:1.4,fog:false})));
const mo=new T.Mesh(new T.SphereGeometry(5,24,16),new T.MeshBasicMaterial({color:0xfff1c1,fog:false}));mo.position.set(-50,60,-80);scene.add(mo)}

function tex(w,h,f,rx,ry){const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'));const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rx||1,ry||1);return t}
const gt=tex(256,256,x=>{x.fillStyle='#232a3b';x.fillRect(0,0,256,256);for(let i=0;i<900;i++){x.fillStyle='rgba(255,255,255,'+Math.random()*.05+')';x.fillRect(Math.random()*256,Math.random()*256,2,2)}x.strokeStyle='rgba(255,183,3,.35)';x.lineWidth=4;x.setLineDash([24,20]);x.strokeRect(8,8,240,240)},4,4);
const ground=new T.Mesh(new T.PlaneGeometry(46,46),new T.MeshLambertMaterial({map:gt}));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
const far=new T.Mesh(new T.PlaneGeometry(220,220),new T.MeshLambertMaterial({color:0x182036}));far.rotation.x=-Math.PI/2;far.position.y=-.05;scene.add(far);
const wt=tex(64,128,x=>{x.fillStyle='#1b2540';x.fillRect(0,0,64,128);for(let i=0;i<8;i++)for(let j=0;j<16;j++){x.fillStyle=Math.random()<.45?'#ffd166':'#27345a';x.fillRect(i*8+1,j*8+2,5,4)}});
const bm=new T.MeshLambertMaterial({map:wt,emissive:0x777777,emissiveMap:wt});
for(let i=0;i<30;i++){const a=i/30*Math.PI*2,r=27+Math.random()*5,w=5+Math.random()*4,h=10+Math.random()*20;
 const b=new T.Mesh(new T.BoxGeometry(w,h,w),bm);b.position.set(Math.cos(a)*r,h/2,Math.sin(a)*r);b.rotation.y=-a;scene.add(b)}
const CR=[];for(const [x,z] of [[-12,-10],[13,-6],[-8,12],[11,13],[-16,2],[16,3],[0,-16],[3,16]]){ // crates and lamps for cover and mood
 const c=new T.Mesh(new T.BoxGeometry(2,2,2),new T.MeshLambertMaterial({color:0x8d5524}));c.position.set(x,1,z);c.rotation.y=x;c.castShadow=c.receiveShadow=true;scene.add(c);CR.push({m:c,on:1,t:0});
 if(CR.length<=4){const l=new T.PointLight(0xffc766,.6,16);l.position.set(x,5,z);scene.add(l)}}

const mat=c=>new T.MeshLambertMaterial({color:c});
/* ===== شخصية النينجا (نسخة Ninjago): الوجه ===== */
// نسيج شق العينين: خلفية بيضاء تُضرب بلون البشرة (فيتغيّر مع الجلد) + عيون وحواجب سوداء
function bandTex(angry){const c=document.createElement('canvas');c.width=256;c.height=64;const x=c.getContext('2d');
 x.fillStyle='#fff';x.fillRect(0,0,256,64);
 let g=x.createLinearGradient(0,0,0,64);g.addColorStop(0,'rgba(0,0,0,.30)');g.addColorStop(.25,'rgba(0,0,0,0)');g.addColorStop(.78,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.32)');x.fillStyle=g;x.fillRect(0,0,256,64);
 g=x.createLinearGradient(0,0,256,0);g.addColorStop(0,'rgba(0,0,0,.32)');g.addColorStop(.18,'rgba(0,0,0,0)');g.addColorStop(.82,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.32)');x.fillStyle=g;x.fillRect(0,0,256,64);
 x.lineCap='round';
 for(const s of [-1,1]){const ex=128+s*34;
  x.fillStyle='#14110f';x.beginPath();x.ellipse(ex,41,angry?10:11,angry?10:14,0,0,7);x.fill();
  x.fillStyle='#fff';x.beginPath();x.arc(ex-3,36,3,0,7);x.fill();
  x.strokeStyle='#14110f';x.lineWidth=angry?9:7;x.beginPath();
  if(angry){x.moveTo(128+s*10,30);x.lineTo(128+s*58,9)}else{x.moveTo(128+s*14,17);x.quadraticCurveTo(128+s*36,8,128+s*58,15)}
  x.stroke()}
 return new T.CanvasTexture(c)}
const BANDTEX=[bandTex(0),bandTex(1)];
function box(w,h,d,c,x,y,z,p){const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat(c));m.position.set(x,y,z);m.castShadow=true;p.add(m);return m}
function limb(p,w,h,d,c,x,y,z){const g=new T.Group();g.position.set(x,y,z);p.add(g);box(w,h,d,c,0,-h/2,0,g);return g}
/* ===== شخصية النينجا (نسخة Ninjago): البناء =====
   o: suit,pants,hat(غطاء الرأس),mask(الوشاح على الوجه),band(رباط الجبهة),armor(واقي الكتف),
      strap(الأحزمة),wrap(أربطة المعصم/الكاحل),cape(الوشاح الخلفي),skin,emblem(المعدن/الذهبي),boot
   o.lite: نسخة أخف للأعداء (مجسمات أقل) */
const SHADE=(c,f)=>{const r=Math.min(255,((c>>16)&255)*f)|0,g=Math.min(255,((c>>8)&255)*f)|0,b=Math.min(255,(c&255)*f)|0;return (r<<16)|(g<<8)|b};
const GCACHE={};
function G(t,...a){const k=t+a.join(',');return GCACHE[k]||(GCACHE[k]=new T[t](...a))}
const PI=Math.PI;
/* ===== NINJAGO 3D model library (LEGO minifigs): 5 ninjas + Skulkin / Serpentine / Nindroid enemies ===== */
/* ===== NINJAGO 3D model library (LEGO minifigs): 5 ninjas + Skulkin / Serpentine / Nindroid enemies ===== */
function NJMODELS(T){
const PI=Math.PI,GC={},G=(t,...a)=>{const k=t+a.join(',');return GC[k]||(GC[k]=new T[t](...a))},TX={};
const cv=(w,h,f)=>{const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'),w,h);return new T.CanvasTexture(c)};
const B=(w,h,d)=>G('BoxGeometry',w,h,d),C=(a,b,h,n)=>G('CylinderGeometry',a,b,h,n||14),S=(r,a,b)=>G('SphereGeometry',r,a||12,b||10),CN=(r,h,n)=>G('ConeGeometry',r,h,n||6);
const P=(p,geo,m,x,y,z,sh)=>{const e=new T.Mesh(geo,m);e.position.set(x,y,z);if(sh)e.castShadow=true;p.add(e);return e};
const lam=()=>{const MC={};return c=>MC[c]||(MC[c]=new T.MeshLambertMaterial({color:c}))};
const pho=()=>{const MC={};return(c,s)=>MC[c]||(MC[c]=new T.MeshPhongMaterial({color:c,shininess:s||60,specular:0x3a3a3a}))};
const decalM=map=>new T.MeshLambertMaterial({map,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2});
/* --- textures (printed LEGO details) --- */
const face=a=>TX['f'+a]||(TX['f'+a]=cv(256,64,(x,w,h)=>{x.fillStyle='#fff';x.fillRect(0,0,w,h);x.lineCap='round';for(const s of[-1,1]){const ex=128+s*42;x.fillStyle='#14110f';x.beginPath();x.ellipse(ex,38,9,12,0,0,7);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(ex-3,33,3.4,0,7);x.fill();x.strokeStyle='#14110f';x.lineWidth=a?11:9;x.beginPath();if(a){x.moveTo(128+s*12,28);x.lineTo(128+s*66,8)}else{x.moveTo(128+s*16,18);x.quadraticCurveTo(128+s*42,6,128+s*66,14)}x.stroke()}}));
function decal(k,pt){const key='d'+k+pt;if(TX[key])return TX[key];return TX[key]=cv(128,128,x=>{
 if(pt==='torso'&&k===3){x.strokeStyle='#6b3a1a';x.lineWidth=10;x.lineCap='round';[[8,8],[120,12],[10,116],[118,100],[64,126]].forEach(p=>{x.setLineDash([3,3]);x.beginPath();x.moveTo(64,64);x.lineTo(p[0],p[1]);x.stroke()});x.setLineDash([]);x.fillStyle='#f2c230';x.beginPath();for(let i=0;i<20;i++){const r=i%2?15:30,a=i*PI/10;x[i?'lineTo':'moveTo'](64+Math.cos(a)*r,64+Math.sin(a)*r)}x.fill();x.fillStyle='#222';[-8,8].forEach(d=>{x.beginPath();x.arc(64+d,60,3,0,7);x.fill()});x.fillRect(58,74,12,3)}
 else if(pt==='torso'){x.fillStyle='#d8a82c';x.beginPath();[[10,24],[34,6],[52,16],[74,22],[112,50],[86,56],[102,66],[72,70],[60,102],[44,126],[36,98],[22,72],[30,48],[12,40]].forEach((p,i)=>x[i?'lineTo':'moveTo'](p[0],p[1]));x.fill();x.fillStyle='#111';x.beginPath();x.arc(62,36,3,0,7);x.fill();x.fillStyle='#fff';for(let i=0;i<4;i++)x.fillRect(80+i*5,56+(i%2)*3,3,6);
  if(k===1){x.fillStyle='#f6a21a';x.beginPath();x.moveTo(108,58);x.lineTo(124,40);x.lineTo(118,64);x.lineTo(128,84);x.lineTo(106,68);x.fill()}
  if(k===2){x.strokeStyle='#e8f4ff';x.lineWidth=4;x.beginPath();x.moveTo(108,60);x.lineTo(120,68);x.lineTo(112,74);x.lineTo(126,90);x.stroke()}}
 else{x.strokeStyle='#d8a82c';x.lineWidth=13;x.lineCap='round';x.beginPath();x.moveTo(30,6);x.bezierCurveTo(100,30,10,70,80,122);x.stroke()}})}
const ETEX={
 hyp:x=>{x.fillStyle='#a8d93c';x.fillRect(0,0,128,128);x.strokeStyle='#2f7d32';x.lineWidth=3;for(let j=0;j<6;j++)for(let i=0;i<5;i++){const cx=i*28+(j%2)*14,cy=j*24+8;x.beginPath();x.moveTo(cx,cy-12);x.lineTo(cx+14,cy);x.lineTo(cx,cy+12);x.lineTo(cx-14,cy);x.closePath();x.stroke()}x.fillStyle='#d62828';x.beginPath();x.arc(30,50,12,0,7);x.fill()},
 fang:x=>{x.fillStyle='#f4f4f4';x.fillRect(0,0,128,128);x.fillStyle='#d94a3d';x.fillRect(46,0,36,128);x.strokeStyle='#1c2a55';x.lineWidth=6;x.lineCap='round';for(let i=0;i<4;i++){x.beginPath();x.moveTo(10,20+i*26);x.quadraticCurveTo(26,30+i*26,40,16+i*26);x.stroke();x.beginPath();x.moveTo(118,20+i*26);x.quadraticCurveTo(102,30+i*26,88,16+i*26);x.stroke()}},
 con:x=>{x.fillStyle='#2a2a2e';x.fillRect(0,0,128,128);x.strokeStyle='#cfcfcf';x.lineWidth=2;for(let j=0;j<7;j++)for(let i=0;i<6;i++){x.beginPath();x.arc(i*24+(j%2)*12,j*20,10,0,PI);x.stroke()}x.fillStyle='#f0a02a';for(let j=0;j<3;j++){x.beginPath();x.roundRect?x.roundRect(34,52+j*24,60,18,6):x.rect(34,52+j*24,60,18);x.fill()}},
 ven:x=>{x.fillStyle='#b4e33d';x.fillRect(0,0,128,128);x.strokeStyle='#5a3a1c';x.lineWidth=16;x.beginPath();x.moveTo(110,0);x.lineTo(30,128);x.stroke();x.fillStyle='#e9d9b0';x.fillRect(26,36,22,6);x.fillStyle='#fff';x.beginPath();x.arc(36,30,7,0,7);x.fill();x.fillStyle='#222';x.fillRect(32,28,3,3);x.fillRect(37,28,3,3)},
 skel:x=>{x.fillStyle='#34343c';x.fillRect(0,0,128,128);x.strokeStyle='#f2f2ea';x.lineWidth=7;x.lineCap='round';for(let i=0;i<3;i++){x.beginPath();x.moveTo(20,22+i*24);x.quadraticCurveTo(64,36+i*24,108,22+i*24);x.stroke()}x.fillStyle='#d8232a';x.beginPath();x.arc(64,90,14,0,7);x.fill();x.fillStyle='#fff';x.fillRect(58,86,12,8)},
 nind:x=>{x.fillStyle='#1c1c20';x.fillRect(0,0,128,128);x.fillStyle='#aab4bd';x.fillRect(34,14,60,92);x.fillStyle='#6b7480';x.fillRect(40,70,48,14);x.fillStyle='#e03030';x.beginPath();x.arc(64,44,12,0,7);x.fill();x.strokeStyle='#4a3fc4';x.lineWidth=18;x.beginPath();x.moveTo(8,0);x.lineTo(110,128);x.stroke()}};
const etex=k=>TX['e'+k]||(TX['e'+k]=cv(128,128,ETEX[k]));
/* --- NINJA: minifig body + hood/mask window --- */
function ninja(o){const M=pho(),b=MB.build({m:M,lg:o.pants,bt:o.boot,tc:o.suit,hand:0x111114,skin:o.skin,belt:o.strap}),{g,L,R,AL,AR,hd,P}=b,dec=[],pads=[];
 const D=(p,pt,w,h,x,y,z)=>{const q=new T.Mesh(G('PlaneGeometry',w,h),decalM(decal(0,pt)));q.position.set(x,y,z);q.userData.dec=pt;p.add(q);dec.push(q)};
 D(R,'leg',.4,.8,0,-.5,.27);D(g,'torso',.86,.84,-.04,1.86,.29);
 P(hd,G('CylinderGeometry',.43,.43,.64,24,1,true,.95,PI*2-1.9),o.hat,0,.08,0);P(hd,G('SphereGeometry',.43,22,10,0,PI*2,0,PI/2),o.hat,0,.39,0,0,[1,.8,1]);
 P(hd,G('CylinderGeometry',.43,.43,.2,22,1,true,-.95,1.9),o.hat,0,.29,0);P(hd,G('CylinderGeometry',.425,.425,.3,22,1,true,-1.55,3.1),o.mask,0,-.16,0);P(hd,G('BoxGeometry',.3,.1,.05),o.band,0,.27,.44);
 const fm=new T.Mesh(G('CylinderGeometry',.415,.415,.26,20,1,true,-.95,1.9),new T.MeshLambertMaterial({color:o.skin,map:face(o.angry===0?0:1)}));fm.position.y=.07;hd.add(fm);
 const gm=new T.MeshPhongMaterial({color:0xd8a82c,shininess:90,specular:0x888888});
 for(const [a,sg] of [[AL,-1],[AR,1]]){const pad=new T.Group();pad.visible=false;a.add(pad);pads.push(pad);const d=new T.Mesh(G('SphereGeometry',.28,12,8,0,PI*2,0,PI/2),gm);d.position.set(sg*.04,.1,0);d.scale.set(1.1,.7,1.15);pad.add(d);for(const j of[-1,0,1]){const s=new T.Mesh(G('ConeGeometry',.065,.3,6),gm);s.position.set(sg*(.22+(1-Math.abs(j))*.06),.3,j*.14);s.rotation.z=-sg*.65;pad.add(s)}}
 const flow=[];for(const l of[L,R]){P(l,G('BoxGeometry',.51,.14,.56),o.wrap,0,-.9,.0);P(l,G('BoxGeometry',.22,.14,.06),o.armor,0,-.45,.28)}
 for(const a of[AL,AR])P(a,G('CylinderGeometry',.18,.18,.14,12),o.wrap,0,-.8,0);
 P(g,G('BoxGeometry',.2,.17,.05),o.emblem,0,1.4,.31);for(const r of[-.83,.83])P(g,G('BoxGeometry',.1,1,.04),o.strap,0,1.88,.3,[0,0,r]);P(g,G('BoxGeometry',.22,.22,.05),o.emblem,0,1.88,.33,[0,0,PI/4]);
 for(const s of[-1,1]){const sw=new T.Group();sw.position.set(0,1.9,-.33);sw.rotation.z=s*.6;g.add(sw);P(sw,G('BoxGeometry',.08,1.1,.05),0xc9d3de,0,.1,0);P(sw,G('BoxGeometry',.22,.06,.09),o.emblem,0,.58,0);P(sw,G('BoxGeometry',.07,.22,.07),o.strap,0,.72,0)}
 P(hd,G('CylinderGeometry',.09,.09,.1,10),o.hat,0,.76,0);
 const tl=(x,rz,len,ph)=>{const t=new T.Group();t.position.set(x,.27,-.42);t.rotation.z=rz;hd.add(t);P(t,G('BoxGeometry',.09,len*.55,.02),o.band,0,-len*.275,0);const t2=new T.Group();t2.position.y=-len*.55;t.add(t2);P(t2,G('BoxGeometry',.08,len*.45,.02),o.band,0,-len*.225,0);flow.push({n:t,a:.2,b:.9,amp:.12,sp:11,ph,zb:rz,zz:.05},{n:t2,a:.1,b:.5,amp:.18,sp:11,ph:ph+1,zb:0,zz:.04})};tl(-.07,.18,.5,0);tl(.07,-.22,.4,1.7);
 return{g,L,R,AL,AR,cape:new T.Group(),flow,dec,pads}}
/* --- ENEMIES --- */
function enemy(k,o){o=o||{};const g=new T.Group(),M=lam(),sk=k==='skel'||k==='ghost',nd=k==='nind',bone=k==='ghost'?(o.tint||0x7ff5df):0xf2f2ea,
 pal={hyp:[0x1e6b34,0x1e6b34,0x9ccf36],fang:[0xc9302c,0xc9302c,0xf2f2f2],con:[0x1c1c20,0x55555a,0x1c1c20],ven:[0xb4e33d,0x1f6b34,0x1f6b34]}[k]||[0x222226,0x1c1c20,0x1c1c20],Hc=o.tint&&!sk&&!nd?o.tint:pal[0];
 const leg=x=>{const l=new T.Group();l.position.set(x,1.2,0);g.add(l);P(l,B(.46,1.1,.5),M(sk?0x4a4a52:nd?0x1c1c20:pal[2]),0,-.55,0,1);P(l,B(.5,.2,.62),M(sk?bone:nd?0x111114:0x4b2e12),0,-1.1,.06);if(nd)P(l,B(.06,.9,.04),M(0xc0262d),x*.2,-.5,.26);return l};
 const L=leg(-.25),R=leg(.25);
 P(g,B(1,.9,.56),M(sk?0x34343c:nd?0x1c1c20:k==='hyp'||k==='ven'?0xa8d93c:k==='fang'?0xf4f4f4:0x2a2a2e),0,1.85,0,1);P(g,B(.88,.5,.5),M(sk?0x2b2b32:nd?0x1c1c20:pal[2]),0,1.28,0);
 const tp=new T.Mesh(G('PlaneGeometry',.96,.86),decalM(etex(k==='ghost'?'skel':k)));tp.position.set(0,1.85,.285);g.add(tp);
 if(sk)P(g,B(.92,.18,.54),M(0x2a6fb5),0,1.04,0);else if(nd)P(g,B(.92,.14,.54),M(0x4a3fc4),0,1.05,0);else P(g,B(.92,.14,.54),M(0x5a3a1c),0,1.05,0);
 if(k==='ven')P(g,C(.62,.5,.2,16),M(0x14532d),0,2.38,0);
 const arm=x=>{const a=new T.Group();a.position.set(x,2.2,0);g.add(a);P(a,S(.17,10,8),M(sk?bone:nd?0x1c1c20:pal[1]),0,0,0);P(a,C(.15,.14,.95,10),M(sk?bone:nd?0x1c1c20:(k==='ven'&&x>0)?0xff8c1a:pal[1]),0,-.47,0,1);if(sk)P(a,S(.15,8,6),M(bone),0,-.5,0);P(a,G('TorusGeometry',.12,.06,8,12,5),M(sk?0xc8c8c0:0x111114),0,-1.02,0).rotation.set(0,PI/2,0);return a};
 const AL=arm(-.66),AR=arm(.66),hd=new T.Group();hd.position.y=2.75;g.add(hd);
 if(sk){P(hd,B(.8,.64,.68),M(bone),0,.1,0,1);P(hd,B(.5,.2,.5),M(bone),0,-.32,.05);P(hd,B(.3,.1,.5),M(bone),0,.46,0);for(let i=-2;i<=2;i++)P(hd,B(.04,.14,.04),M(0x222222),i*.1,-.3,.32);for(const s of[-1,1]){P(hd,S(.15,10,8),M(0x14141a),s*.2,.14,.3);P(hd,S(.075,8,6),M(0xe0202a),s*.2,.14,.38)}P(hd,B(.1,.14,.04),M(0x14141a),0,-.02,.34);if(k==='ghost')P(hd,B(.84,.1,.74),M(0x7b6cf6),0,.5,0)}
 else if(nd){P(hd,C(.37,.37,.64,18),M(0x1c1c20),0,.05,0,1);P(hd,G('SphereGeometry',.37,18,8,0,PI*2,0,PI/2),M(0x1c1c20),0,.37,0).scale.y=.85;P(hd,B(.46,.5,.12),M(0xaab4bd),-.14,.12,.35);P(hd,S(.1,8,6),M(0xe02020),-.14,.12,.43);P(hd,B(.3,.1,.05),M(0xe02020),.16,.14,.36);P(hd,B(.3,.14,.5),M(0x888f99),-.34,.3,.1)}
 else{const hc=M(Hc);P(hd,S(.5,16,10),hc,0,.12,-.02,1).scale.set(1.05,.9,1.15);P(hd,B(.5,.32,.52),hc,0,-.08,.4);P(hd,B(.56,.08,.7),M(SH(Hc,.8)),0,.52,.05);
  for(const s of[-1,1]){P(hd,B(.1,.7,.5),hc,s*.5,.15,-.05).rotation.z=-s*.25;const ey=P(hd,S(.1,10,8),M(0xffd42a),s*.2,.3,.42);ey.scale.set(1.3,.7,.6);P(hd,B(.02,.14,.02),M(0x111111),s*.2,.3,.5);P(hd,CN(.07,.3),M(0xffffff),s*.15,-.4,.5).rotation.x=PI}
  if(k==='con')for(const s of[-1,0,1])P(hd,CN(.1,.34),M(0xf0a02a),s*.28,.62-Math.abs(s)*.1,-.05);if(k==='fang')P(hd,B(.4,.1,.3),M(0x1c2a44),0,.58,.1);if(k==='ven'){P(hd,B(.46,.14,.4),M(0x7a1d1d),0,-.3,.4)}}
 const gold=M(0xd8a82c),brown=M(0x6b3a1a),pole=(c,h)=>P(AR,C(.05,.05,h||2.4,8),c,0,-.9,.1);
 if(sk){pole(gold,2.3);const bl=P(AR,G('TorusGeometry',.38,.07,6,12,PI*.85),gold,.3,.32,.1);bl.rotation.z=.9;for(let i=0;i<5;i++)P(g,G('TorusGeometry',.1,.03,6,10),gold,-.3+i*.15,1.0-Math.sin(i/4*PI)*.16,.3)}
 else if(nd){P(AR,B(.12,.14,1.6),M(0x555560),0,-1.0,.28);for(let i=0;i<6;i++)P(AR,CN(.05,.14,4),M(0x555560),(i%2?.1:-.1),-.4-i*.2,.28);P(AR,B(.5,.7,.06),new T.MeshLambertMaterial({color:0xc0262d,transparent:true,opacity:.8}),.28,-1.3,.28)}
 else if(k==='hyp'){pole(gold);P(AR,S(.12,10,8),M(0x6fe05a),0,.4,.1).scale.y=1.6;P(AR,CN(.08,.5,5),M(0xffffff),-.2,.1,.1).rotation.z=.9}
 else if(k==='fang'){pole(M(0x777a80));P(AR,B(.55,.5,.06),M(0x888b92),.3,.15,.1);P(AR,B(.2,.5,.06),M(0x888b92),.15,.15,.1)}
 else if(k==='con'){pole(brown);for(const s of[-1,1])P(AR,B(.08,.9,.04),M(0x7a4fd0),s*.18,.55,.1).rotation.z=-s*.25}
 else{pole(brown);P(AR,CN(.1,.4),gold,0,.4,.1);P(AR,B(.3,.2,.2),brown,0,-1.9,.1)}
 return{g,L,R,AL,AR,cape:new T.Group(),flow:[]}}
function SH(c,f){const r=Math.min(255,((c>>16)&255)*f)|0,g=Math.min(255,((c>>8)&255)*f)|0,b=Math.min(255,(c&255)*f)|0;return(r<<16)|(g<<8)|b}
const setDecal=(m,k)=>m.dec.forEach(d=>{const t=decal(k,d.userData.dec);if(d.material.map!==t){d.material.map=t;d.material.needsUpdate=true}});

/* --- ANIMATION SET (shared by viewer and game). pose() returns {ty:twist,yo:height,sx,sy} offsets --- */
const NA=[['وقوف','idle'],['جري','run'],['لكمة','jab'],['خطّاف','hook'],['ركلة دوّارة','kick'],['قفز','jump'],['سقوط','fall'],['تفادي','dodge'],['إصابة','hurt'],['سبينجيتسو','spin'],['فوز','win'],['هزيمة','die']],EA=[['وقوف','idle'],['مشي','walk'],['هجوم','attack'],['إصابة','hit']];
function pose(m,a,t,u){const{g,L,R,AL,AR}=m,S=Math.sin,e=S((u||0)*PI),o={ty:0,yo:0,sx:1,sy:1};[L,R,AL,AR].forEach(l=>l.rotation.set(0,0,0));g.rotation.x=g.rotation.z=0;
 if(a==='idle'){const b=S(t*2.2);AL.rotation.x=-.25+b*.05;AR.rotation.x=-.25-b*.05;AL.rotation.z=-.2;AR.rotation.z=.2;L.rotation.z=-.07;R.rotation.z=.07;g.rotation.x=.05;g.rotation.z=S(t*1.1)*.015;o.sy=1+b*.012}
 else if(a==='run'){const s=S(t*10);L.rotation.x=s*.95;R.rotation.x=-s*.95;AL.rotation.x=-s*.9-.35;AR.rotation.x=s*.9-.35;g.rotation.x=.2;g.rotation.z=s*.04;o.yo=Math.abs(s)*.1}
 else if(a==='jab'){AR.rotation.x=-1.65*e;AL.rotation.x=.5*e;g.rotation.x=.22*e;o.ty=-.4*e;L.rotation.x=.5*e;R.rotation.x=-.4*e}
 else if(a==='hook'){AL.rotation.x=-1.5*e;AL.rotation.z=.9*e;AR.rotation.x=.4*e;o.ty=.5*e;g.rotation.x=.15*e;L.rotation.x=-.3*e;R.rotation.x=.4*e}
 else if(a==='kick'){o.ty=u*PI*2;R.rotation.x=-1.6*e;L.rotation.x=.3*e;AL.rotation.z=-1.3*e;AR.rotation.z=1.3*e;g.rotation.x=.1*e;o.yo=.2*e}
 else if(a==='jump'){AL.rotation.x=AR.rotation.x=-2.7;AL.rotation.z=-.3;AR.rotation.z=.3;L.rotation.x=-.55;R.rotation.x=.45;g.rotation.x=-.08;o.sy=1.06;o.sx=.96}
 else if(a==='fall'){AL.rotation.z=-1.15;AR.rotation.z=1.15;L.rotation.z=-.3;R.rotation.z=.3;g.rotation.x=.08}
 else if(a==='dodge'){g.rotation.x=1.05;AL.rotation.x=AR.rotation.x=-2.4;L.rotation.x=.6;R.rotation.x=.4;o.yo=.25*e}
 else if(a==='hurt'){g.rotation.x=-.4*e;AL.rotation.z=-.9*e;AR.rotation.z=.9*e;AL.rotation.x=AR.rotation.x=-.4*e;L.rotation.x=.3*e;R.rotation.x=-.3*e;o.ty=S(t*40)*.08*e}
 else if(a==='spin'){o.ty=t*18;AL.rotation.z=-1.5;AR.rotation.z=1.5;L.rotation.z=-.1;R.rotation.z=.1;o.yo=.2+S(t*8)*.05}
 else if(a==='win'){const w=S(t*8);AL.rotation.x=-2.9+w*.3;AR.rotation.x=-2.9-w*.3;AL.rotation.z=-.35;AR.rotation.z=.35;o.yo=Math.abs(S(t*5))*.35;o.ty=S(t*2)*.5}
 else if(a==='die'){const k=Math.min(1,(u||0)*3);g.rotation.x=-1.45*k;AL.rotation.z=-1.2*k;AR.rotation.z=1.2*k;AL.rotation.x=-.3*k}
 return o}
function epose(m,a,t,u,kind){const{g,L,R,AL,AR}=m,S=Math.sin,o={ty:0,yo:0},sn=kind==='hyp'||kind==='fang'||kind==='con'||kind==='ven',gh=kind==='ghost';[L,R,AL,AR].forEach(l=>l.rotation.set(0,0,0));g.rotation.x=g.rotation.z=0;
 if(a==='walk'){const s=S(t*10);L.rotation.x=s*.8;R.rotation.x=-s*.8;AL.rotation.x=-s*.7;AR.rotation.x=s*.5;g.rotation.x=.1;o.yo=Math.abs(s)*.05;if(sn)g.rotation.z=S(t*40)*.08;else if(kind==='skel'||gh)g.rotation.z=S(t*140)*.03;if(gh)o.yo+=.25+S(t*20)*.08}
 else if(a==='idle'){const b=S(t*2);AL.rotation.z=-.15-b*.04;AR.rotation.z=.15+b*.04;AL.rotation.x=-.2;AR.rotation.x=-.3;if(sn)g.rotation.z=S(t*2)*.05;if(gh)o.yo=.25+b*.1}
 else if(a==='attack'){AR.rotation.x=-.75-1.65*u;AL.rotation.x=.5*u;g.rotation.x=-.15+.45*u;o.ty=-.3*u;L.rotation.x=.4*u;R.rotation.x=-.3*u}
 else{g.rotation.x=-.45;AL.rotation.z=-.9;AR.rotation.z=.9;AL.rotation.x=AR.rotation.x=-.3;L.rotation.x=.3;R.rotation.x=-.3}
 return o}
const NINJAS=[['لويد · النينجا الأخضر',{suit:0x1f9a3a,pants:0x1f9a3a,hat:0x1f9a3a,mask:0x1a8a33,skin:0xf6c744,strap:0x0f3d1c,crest:1,angry:1},0,1],['كاي · النينجا الأحمر',{suit:0xd8231f,pants:0xd8231f,hat:0xd8231f,mask:0xc01d1a,skin:0xf6c744,strap:0x5a0f0f,angry:1},1],['جاي · النينجا الأزرق',{suit:0x1c55d8,pants:0x1c55d8,hat:0x1c55d8,mask:0x1948bb,skin:0xf6c744,strap:0x0b1f4a,angry:1},2],['زين · النينجا الأبيض',{suit:0xf2f2f2,pants:0xf2f2f2,hat:0xf2f2f2,mask:0xe2e2e2,skin:0xf6c744,strap:0xaaaaaa,angry:1},3],['كول · النينجا الأسود',{suit:0x18181c,pants:0x18181c,hat:0x18181c,mask:0x222228,skin:0xf6c744,strap:0x33333a,angry:1},4]];
const ENEMIES=[['سكولكين · الهيكل','skel'],['هيبنوبراي','hyp'],['فانغبايري','fang'],['كونستريكتاي','con'],['فينوماري','ven'],['نيندرويد','nind'],['شبح الموسم 5','ghost']];
return{ninja,enemy,setDecal,decal,pose,epose,NA,EA,NINJAS,ENEMIES}}

/* ===== جسم ليجو ميني فيج حقيقي: رأس أسطواني بزرار، رقبة، جذع مخروط، أيدي C، ورك ورجلين بقدم ===== */
const MB=(()=>{const TG=new T.BoxGeometry(1,.95,.56);{const a=TG.attributes.position;for(let i=0;i<a.count;i++)if(a.getY(i)<0)a.setX(i,a.getX(i)*.92)}
const HG=new T.CylinderGeometry(.38,.41,.62,28),SG=new T.CylinderGeometry(.2,.2,.14,16),NG=new T.CylinderGeometry(.17,.19,.2,12);
return{build(o){const m=o.m,g=new T.Group(),P=(p,geo,c,x,y,z,r,s)=>{const e=new T.Mesh(geo,m(c));e.position.set(x,y,z);if(r)e.rotation.set(r[0]||0,r[1]||0,r[2]||0);if(s)e.scale.set(s[0],s[1],s[2]);e.castShadow=true;p.add(e);return e};
 const leg=x=>{const l=new T.Group();l.position.set(x,1.2,0);g.add(l);if(!o.nl){P(l,G('BoxGeometry',.47,1,.52),o.lg,0,-.5,0);P(l,G('BoxGeometry',.5,.2,.6),o.bt||o.lg,0,-1.1,.04)}return l},L=leg(-.25),R=leg(.25);
 P(g,G('BoxGeometry',1,.2,.54),o.hip||o.lg,0,1.28,0);if(o.belt)P(g,G('BoxGeometry',1.02,.09,.58),o.belt,0,1.4,0);
 P(g,TG,o.tc,0,1.86,0);P(g,NG,o.skin,0,2.43,0);
 const ar=(x,c)=>{const a=new T.Group();a.position.set(x,2.2,0);g.add(a);P(a,G('SphereGeometry',.17,12,8),c,0,0,0);P(a,G('CylinderGeometry',.17,.145,.82,14),c,0,-.43,0);P(a,G('CylinderGeometry',.09,.09,.12,10),o.hand,0,-.9,0);P(a,G('TorusGeometry',.12,.055,8,16,5),o.hand,0,-1,0,[0,PI/2,0]);return a},AL=ar(-.66,o.al||o.tc),AR=ar(.66,o.ar||o.tc);
 const hd=new T.Group();hd.position.y=2.75;g.add(hd);if(!o.nh){P(hd,HG,o.skin,0,.08,0);P(hd,SG,o.skin,0,.46,0)}
 return{g,L,R,AL,AR,hd,P}}}})();
let EK=null;const NJM=NJMODELS(T);
function ninja(o){const r=NJM.ninja(o);r.g.scale.setScalar(o.s||1);scene.add(r.g);return r}
function enemy(o,E){const r=NJM.enemy(E.k,{tint:E.tint});r.g.scale.setScalar(o.s||1);scene.add(r.g);return r}
function starGeo(){if(starGeo.g)return starGeo.g;const sh=new T.Shape();for(let i=0;i<10;i++){const r=i%2?.11:.27,a=Math.PI/2+i*Math.PI/5,x=Math.cos(a)*r,y=Math.sin(a)*r;i?sh.lineTo(x,y):sh.moveTo(x,y)}sh.closePath();const g=new T.ExtrudeGeometry(sh,{depth:.05,bevelEnabled:false});g.translate(0,0,-.025);return starGeo.g=g}
function person(o){if(!o.lite)return ninja(o);if(EK)return enemy(o,EK);
 const g=new T.Group(),lite=!!o.lite,flow=[],MC={};
 const D=(k,v)=>o[k]!==undefined?o[k]:v;
 const C={suit:o.suit,pants:o.pants,hat:o.hat,skin:o.skin,
  mask:D('mask',SHADE(o.hat,1.7)),band:D('band',0xc1121f),armor:D('armor',SHADE(o.suit,.55)),strap:D('strap',0x1a1a1f),
  wrap:D('wrap',0x8a8f98),boot:D('boot',0x15161a),emblem:D('emblem',0x9aa0a8)};
 // خامة واحدة لكل لون داخل الشخصية (المعادن Phong لتلمع)
 const M=(c,metal)=>{const k=(metal?'p':'l')+c;return MC[k]||(MC[k]=metal?new T.MeshPhongMaterial({color:c,shininess:70,specular:0x777777}):new T.MeshLambertMaterial({color:c}))};
 const part=(p,geo,m,x,y,z,sh)=>{const e=new T.Mesh(geo,m);e.position.set(x,y,z);if(sh)e.castShadow=true;p.add(e);return e};
 const cyl=(a,b,h,n)=>G('CylinderGeometry',a,b,h,n||12),bx=(w,h,d)=>G('BoxGeometry',w,h,d);

 /* --- الأرجل: فخذ + مفصل ركبة + ساق + رباط كاحل + حذاء --- */
 const leg=x=>{const l=new T.Group();l.position.set(x,1.2,0);g.add(l);
  if(lite)part(l,cyl(.19,.17,1.05,10),M(C.pants),0,-.525,0,1);
  else{part(l,cyl(.2,.185,.58),M(C.pants),0,-.29,0,1);
   part(l,cyl(.21,.21,.1),M(C.strap),0,-.6,0);                      // مفصل الركبة
   part(l,bx(.2,.13,.05),M(C.armor,1),0,-.6,.21);                    // واقي الركبة
   part(l,cyl(.185,.165,.4),M(C.pants),0,-.84,0,1)}
  part(l,cyl(.215,.205,.2),M(C.wrap),0,-.95,0);                     // رباط الكاحل
  part(l,bx(.4,.16,.58),M(C.boot),0,-1.12,.08,1);                   // الحذاء
  return l};
 const L=leg(-.25),R=leg(.25);

 /* --- الجذع: صدر + خصر + حزام + أحزمة متقاطعة + شارة --- */
 if(lite){part(g,bx(.95,1.1,.55),M(o.suit),0,1.75,0,1)}
 else{part(g,bx(1,.72,.56),M(o.suit),0,1.94,0,1);part(g,bx(.86,.4,.5),M(o.suit),0,1.41,0,1)}
 part(g,bx(.9,.14,.54),M(C.strap),0,1.3,0);                          // الحزام
 if(!lite){
  part(g,bx(.2,.17,.05),M(C.emblem,1),0,1.3,.275);                  // إبزيم
  for(const r of [-.83,.83])part(g,bx(.11,1.06,.05),M(C.strap),0,1.9,.3).rotation.z=r; // حزام الصدر المتقاطع
  const bd=part(g,bx(.24,.24,.05),M(C.emblem,1),0,1.9,.335);bd.rotation.z=PI/4;       // شارة العنصر
  part(g,bx(.11,.11,.06),M(C.strap),0,1.9,.34).rotation.z=PI/4;
  // سيفان على الظهر
  for(const s of [-1,1]){const sw=new T.Group();sw.position.set(0,1.88,-.33);sw.rotation.z=s*.6;g.add(sw);
   part(sw,bx(.1,1.0,.06),M(C.strap),0,0,0);
   part(sw,bx(.22,.06,.09),M(C.emblem,1),0,.52,0);
   part(sw,bx(.07,.22,.07),M(C.strap),0,.66,0);
   part(sw,G('SphereGeometry',.055,8,6),M(C.emblem,1),0,.8,0)}}

 /* --- الرأس: غطاء + شق العينين + وشاح الوجه + رباط الجبهة --- */
 part(g,cyl(.34,.34,.5,20),M(o.hat),0,2.7,0,1);                       // غطاء الرأس
 part(g,G('SphereGeometry',.34,18,8,0,PI*2,0,PI/2),M(o.hat),0,2.95,0).scale.y=.75;part(g,cyl(.1,.1,.09,12),M(o.hat),0,3.22,0);if(!lite)part(g,starGeo(),M(C.emblem,1),0,3.17,.06);
 const eyes=new T.Mesh(G('CylinderGeometry',.352,.352,.17,14,1,true,-.95,1.9),new T.MeshLambertMaterial({color:o.skin,map:BANDTEX[o.angry?1:0]}));
 eyes.position.set(0,2.74,0);g.add(eyes);                             // فتحة العينين بلون البشرة
 part(g,G('CylinderGeometry',.357,.357,.22,18,1,true,-1.3,2.6),M(C.mask),0,2.555,0); // الوشاح على الفم والأنف
 part(g,cyl(.3,.33,.14,14),M(C.mask),0,2.42,0);                       // لفة الرقبة
 part(g,cyl(.36,.36,.1,20),M(C.band),0,2.9,0);                        // رباط الجبهة
 if(!lite){
  part(g,bx(.1,.07,.07),M(C.mask),0,2.645,.355);                     // جسر الأنف
  part(g,bx(.22,.13,.04),M(C.emblem,1),0,2.9,.365);                   // لوحة الجبهة المعدنية
  part(g,bx(.07,.07,.045),M(C.strap),0,2.9,.39).rotation.z=PI/4}
 // ذيلا رباط الرأس (يتحركان)
 const tail=(x,rz,len,ph)=>{const t=new T.Group();t.position.set(x,2.9,-.34);t.rotation.z=rz;g.add(t);
  part(t,bx(.09,len*.55,.02),M(C.band),0,-len*.275,0);
  const t2=new T.Group();t2.position.y=-len*.55;t.add(t2);part(t2,bx(.08,len*.45,.02),M(C.band),0,-len*.225,0);
  flow.push({n:t,a:.2,b:.9,amp:.12,sp:11,ph,zb:rz,zz:.05},{n:t2,a:.1,b:.5,amp:.18,sp:11,ph:ph+1,zb:0,zz:.04})};
 tail(-.07,.18,.5,0);tail(.07,-.22,.4,1.7);

 /* --- الأذرع: كتف + مرفق + ساعد + رباط معصم + يد + واقي كتف --- */
 const arm=x=>{const a=new T.Group();a.position.set(x,2.2,0);g.add(a);
  if(lite)part(a,cyl(.16,.14,.95,10),M(o.suit),0,-.475,0,1);
  else{part(a,cyl(.165,.15,.52),M(o.suit),0,-.26,0,1);
   part(a,cyl(.17,.17,.09),M(C.strap),0,-.52,0);                     // مفصل المرفق
   part(a,cyl(.145,.13,.4),M(o.suit),0,-.74,0,1)}
  part(a,cyl(.175,.165,.2),M(C.wrap),0,-.86,0);                      // رباط المعصم
  part(a,G('TorusGeometry',.12,.065,8,14,5),M(o.skin),0,-1,0,1).rotation.set(0,Math.PI/2,0);           // اليد
  const sg=Math.sign(x);                                             // واقي الكتف (قبة)
  part(a,G('SphereGeometry',.28,14,8,0,PI*2,0,PI/2),M(C.armor,1),sg*.03,.1,0,1).scale.set(1.1,.7,1.15);
   if(!lite)for(const j of[-1,0,1]){const sp=part(a,G('ConeGeometry',.065,.3,6),M(C.armor,1),sg*(.22+(1-Math.abs(j))*.06),.3,j*.14);sp.rotation.z=-sg*.65}
  if(!lite){part(a,cyl(.3,.3,.06,14),M(C.emblem,1),sg*.03,.1,0);
   part(a,G('ConeGeometry',.055,.12,8),M(C.emblem,1),sg*.03,.3,0)}
  return a};
 const AL=arm(-.66),AR=arm(.66);

 /* --- الوشاح الخلفي المتحرك (3 مفاصل لكل ذيل) --- */
 let cape=null;
 if(o.cape){cape=new T.Group();cape.position.set(0,2.42,-.38);g.add(cape);
  part(cape,G('SphereGeometry',.09,8,6),M(o.cape),0,0,.07);          // عقدة الوشاح
  for(const [tx,len,ph] of [[-.13,1.05,0],[.13,.8,1.3]]){let par=cape;
   for(let i=0;i<3;i++){const sg=new T.Group();sg.position.set(i?0:tx,i?-len/3:-.02,0);par.add(sg);
    part(sg,bx(.3-.05*i,len/3,.04),M(o.cape),0,-len/6,0);
    flow.push({n:sg,a:.04,b:.12,amp:.1,sp:9,ph:ph+i*.9,zb:0,zz:.04});par=sg}}}
 g.scale.setScalar(o.s||1);scene.add(g);
 return {g,L,R,AL,AR,cape,flow};
}
// حركة الوشاح وذيل رباط الرأس حسب سرعة الحركة
function animFlow(h,t,len){const F=h.flow;if(!F)return;const k=.4+len;for(let i=0;i<F.length;i++){const f=F[i];f.n.rotation.x=f.a+len*f.b+Math.sin(t*f.sp-f.ph)*f.amp*k;f.n.rotation.z=f.zb+Math.sin(t*f.sp*.8-f.ph)*f.zz*k}}
function mkBub(cls){const d=document.createElement('div');d.className='bub '+cls;$('bubbles').appendChild(d);return d}

const hold={p:0},inp={x:0,z:0,p:0,j:0,s:0,d:0},keys={},S={snd:1,voice:1,music:1,q:1,bl:LOW?0:1};
const SK=[
// مراري (البطل الافتراضي) — الألوان الأصلية للعبة مع تفاصيل النينجا
{n:'مراري',suit:0xffb703,pants:0x1d3557,hat:0x6a994e,mask:0x4f772d,band:0xe63946,armor:0x3d5a80,strap:0x15151a,wrap:0xc1121f,cape:0xa3c93a,skin:0xf6c744,emblem:0xffd166,boot:0x22223b},
// كاي: أحمر + ذهبي
{n:'كاي · النار',suit:0xd62828,pants:0x8f1515,hat:0xd62828,mask:0xa81d1d,band:0xffc933,armor:0xe0a526,strap:0x1a1a1f,wrap:0xe0a526,cape:0xb5121b,skin:0xf6c744,emblem:0xffd166,boot:0x1a1a1f},
// جاي: أزرق + أصفر
{n:'جاي · البرق',suit:0x1d6fe0,pants:0x0b3a82,hat:0x1d6fe0,mask:0x1657b8,band:0xffd60a,armor:0xaab4c0,strap:0x1a1a1f,wrap:0xf5c400,cape:0x1344a6,skin:0xf6c744,emblem:0xc9d3de,boot:0x0b2a5e},
// زين: أبيض + فضي
{n:'زين · الثلج',suit:0xf1f5f9,pants:0xcdd6df,hat:0xf1f5f9,mask:0xdbe3ec,band:0xb4bfcc,armor:0xe0b020,strap:0x8d99a8,wrap:0xb4bfcc,cape:0xa9c6dd,skin:0xe8eef4,emblem:0xe8b923,boot:0x9aa7b5},
// كول: أسود + بني
{n:'كول · الأرض',suit:0x2a2d34,pants:0x17181d,hat:0x2a2d34,mask:0x1d1f25,band:0x8b5a2b,armor:0x9aa0a8,strap:0x7a4f26,wrap:0x9c6a38,cape:0x6b4423,skin:0xf6c744,emblem:0xb9bec6,boot:0x3b2412},
// لويد: أخضر + ذهبي
{n:'لويد · الطاقة',suit:0x2fbf4a,pants:0x1a7a30,hat:0x2fbf4a,mask:0x23993a,band:0xffd166,armor:0xaab4c0,strap:0xe0a800,wrap:0xffd166,cape:0x146c2e,skin:0xf6c744,emblem:0xc9d3de,boot:0x0f4f22}];
const H={...person(SK[0]),b:mkBub('h')};
let gfT=0,rdT=0;
let state='menu',enemies=[],fx=[],score=0,wave=0,waveWait=1,shake=0,ac=null,lastSp=0,mode='arcade',combo=0,comboT=0,hs=0,seen={};
Object.assign(H,{hp:100,rage:0,y:0,vy:0,at:0,did:true,inv:0,rot:0,ph:0,bt:0,sx:0,sz:0});

let curSk=0,buff=0,wpT=4,wc=0,ult=0,ultT=0;const wp=[];const pas=k=>buff>0&&curSk===k;
const KM={};for(const k in SK[0])if(k!=='n')KM[SK[0][k]]=k;
H.aura=new T.PointLight(0xffffff,0,9);H.aura.position.y=2;H.g.add(H.aura);
H.g.traverse(m=>{if(m.isMesh&&m.material.color){const k=KM[m.material.color.getHex()];if(k)m.userData.k=k}});
const NJ=[null,{w:0},{w:3},{w:2},{w:1},{w:0}],EC=[0xa3c93a,0xff6a1a,0x5ac8ff,0xcdefff,0xb08a55,0x6aff6a];
function bolt(x,z,c){const m=new T.Mesh(new T.CylinderGeometry(.08,.08,14,5),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.9}));m.position.set(x,7,z);scene.add(m);let t=0;fx.push(dt=>{t+=dt;m.material.opacity=Math.max(0,.9-t*4);if(t>.22){scene.remove(m);return true}})}
function skill(){const k=curSk,p=H.g.position,R_=[0,9,16,10,12,0][k];
 for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z,d=Math.hypot(dx,dz);if(!R_||d>=R_)continue;bolt(e.g.position.x,e.g.position.z,EC[k]);
  if(k===1)hurtEnemy(e,35,dx/(d||1),dz/(d||1),8);
  else if(k===2)hurtEnemy(e,40,0,0,0);
  else if(k===3){e.stun=2.5;e.kx=e.kz=0}
  else if(k===4){hurtEnemy(e,15,dx/(d||1),dz/(d||1),26);e.stun=1.5}}
 if(k===5){H.hp=Math.min(100,H.hp+30);spark(p.x,2,p.z)}}
function setSkin(i){curSk=i;if(H.aura)H.aura.color.setHex(EC[i]);H.g.traverse(m=>{if(m.userData.k)m.material.color.setHex(SK[i][m.userData.k])})}
const GOLD=new T.MeshPhongMaterial({color:0xffc933,emissive:0x9a6400,specular:0xffffff,shininess:120});
const GEM=c=>new T.MeshLambertMaterial({color:c,emissive:c});
const G2=new T.MeshPhongMaterial({color:0xffd34d,emissive:0xb36b00,specular:0xffffff,shininess:150});
const HALO=new T.SpriteMaterial({map:tex(64,64,x=>{const g=x.createRadialGradient(32,32,2,32,32,32);g.addColorStop(0,'rgba(255,230,120,.9)');g.addColorStop(1,'rgba(255,200,50,0)');x.fillStyle=g;x.fillRect(0,0,64,64)}),blending:T.AdditiveBlending,depthWrite:false,transparent:true,fog:false});
const STARM=new T.SpriteMaterial({map:tex(64,64,x=>{x.translate(32,32);const g=x.createRadialGradient(0,0,0,0,0,12);g.addColorStop(0,'#fff');g.addColorStop(1,'rgba(255,240,160,0)');x.fillStyle=g;x.fillRect(-32,-32,64,64);x.fillStyle='#fff';x.beginPath();x.moveTo(0,-31);x.lineTo(3,-3);x.lineTo(31,0);x.lineTo(3,3);x.lineTo(0,31);x.lineTo(-3,3);x.lineTo(-31,0);x.lineTo(-3,-3);x.closePath();x.fill()}),blending:T.AdditiveBlending,depthWrite:false,transparent:true,fog:false});
const SHINE=[];
function shine(t){const gp=.5+.5*Math.sin(t*3);GOLD.emissiveIntensity=.7+.7*gp;G2.emissiveIntensity=.8+.8*gp;
 for(let i=SHINE.length-1;i>=0;i--){const g=SHINE[i];if(!g.parent){SHINE.splice(i,1);continue}const o=g.userData.sh,p=o.ph,k=2.6+.55*Math.sin(t*4+p);o.hl.scale.set(k,k,1);
  o.sts.forEach((st,j)=>{const a=t*2.2+p+j*1.571,tw=Math.max(0,Math.sin(t*5+j*1.9+p));st.position.set(Math.cos(a)*.75,.9+Math.sin(t*1.3+j*2+p)*.9,Math.sin(a)*.75);st.scale.setScalar(.12+tw*.5)})}}
function ex(sh,d){const geo=new T.ExtrudeGeometry(sh,{depth:d,bevelEnabled:true,bevelSize:.02,bevelThickness:.02,bevelSegments:1});geo.translate(0,0,-d/2);return geo}
function wpn(t){const g=new T.Group(),M=t===4?G2:GOLD,C=(r,h,n)=>new T.CylinderGeometry(r,r,h,n||10),K=(r,h)=>new T.ConeGeometry(r,h,8),TR=r=>new T.TorusGeometry(r,.025,6,10);
 const A=(geo,x,y,z,r,m)=>{const o=new T.Mesh(geo,m||M);o.position.set(x,y,z);if(r)o.rotation.set(r[0],r[1],r[2]);o.castShadow=true;g.add(o);return o};
 if(t===0){const s=new T.Shape();s.moveTo(-.13,0);s.quadraticCurveTo(-.05,1,.32,1.9);s.quadraticCurveTo(.3,1,.13,0);A(ex(s,.06),0,.15,0);
  A(C(.09,.6),0,-.2,0);for(let i=0;i<3;i++)A(TR(.1),0,-.35+i*.15,0,[1.57,0,0]);A(K(.2,.4),0,.1,.05);A(new T.BoxGeometry(.55,.07,.12),0,.12,0,[0,0,.2]);A(new T.SphereGeometry(.05,8,6),.08,.12,.16,0,GEM(0xff2244))}
 else if(t===1){A(C(.07,2.6),0,.3,0);for(let i=0;i<8;i++)A(TR(.08),0,-.9+i*.35,0,[1.57,0,0]);
  const s=new T.Shape();s.moveTo(.15,0);s.quadraticCurveTo(-.5,.8,-1.4,.3);s.quadraticCurveTo(-.5,.3,.1,-.3);A(ex(s,.08),0,1.6,0);
  A(K(.1,.5),.4,1.7,0,[0,0,-1.2]);A(K(.08,.4),.35,1.45,0,[0,0,-1.8]);A(new T.SphereGeometry(.08,8,6),.1,1.6,.08,0,GEM(0x8844ff))}
 else if(t===2){const s=new T.Shape();for(let i=0;i<3;i++){const a=i*2.094,b=a+1.047,c=a+2.094;if(!i)s.moveTo(Math.cos(a)*1.1,Math.sin(a)*1.1);s.quadraticCurveTo(Math.cos(b)*.15,Math.sin(b)*.15,Math.cos(c)*1.1,Math.sin(c)*1.1)}
  const h=new T.Path();h.absarc(0,0,.25,0,6.283,true);s.holes.push(h);A(ex(s,.1),0,.9,0);
  for(let i=0;i<3;i++)A(new T.SphereGeometry(.07,8,6),Math.cos(i*2.094+.5)*.5,.9+Math.sin(i*2.094+.5)*.5,.1,0,GEM(0xc9a7ff))}
 else if(t===3){for(const sg of [-1,1]){A(C(.1,1.2,8),sg*.5,.2+(sg>0?.7:0),0,[0,0,sg*.45]);A(K(.15,.4),sg*.8,.8+(sg>0?.7:0),0,[0,0,-sg*1.1+(sg>0?0:0)]);A(new T.SphereGeometry(.06,8,6),sg*.8,.9+(sg>0?.7:0),.1,0,GEM(0x3a5bff))}
  A(C(.02,1,4),0,.8,0,[0,0,1.2],GEM(0x9be7ff))}
 else{A(C(.06,2.5),0,.5,0);A(K(.22,.6),0,-.95,0,[3.14,0,0]);for(let i=0;i<10;i++)A(TR(.07),0,-.5+i*.22,0,[1.57,0,0]);
  A(new T.SphereGeometry(.22,10,8),0,1.85,0);for(let i=0;i<7;i++)A(K(.1+(i%3)*.03,.6+((i*37)%5)*.2),(i-3)*.13,2.25+((i*37)%5)*.1,((i%2)-.5)*.2,[0,0,(i-3)*.12]);
  const s=new T.Shape();s.moveTo(0,0);s.lineTo(.35,.5);s.lineTo(.15,.5);s.lineTo(.5,1.2);s.lineTo(-.05,.6);s.lineTo(.15,.6);A(ex(s,.06),.3,1.75,0)}
 const hl=new T.Sprite(HALO);hl.scale.set(2.6,2.6,1);hl.position.y=.9;g.add(hl);
 const sts=[];for(let i=0;i<4;i++){const s=new T.Sprite(STARM);s.scale.setScalar(.01);g.add(s);sts.push(s)}
 g.userData.sh={hl,sts,ph:Math.random()*6.28};SHINE.push(g);return g}
function unequip(){if(H.wm){H.AR.remove(H.wm);H.wm=null}}
function equip(t){unequip();H.wm=wpn(t);H.wt=t;H.wm.scale.setScalar(.6);H.wm.position.set(0,-1,.1);H.wm.rotation.x=-1.4;H.AR.add(H.wm)}
const WN=['سيف التنين الذهبي','منجل اللهب الذهبي','شوريكن التنين الذهبي','نانشاكو الصاعقة الذهبي','رمح الإعصار الأقصى'];
function dropWpn(cx,cz){const t=Math.random()*4|0,x=cx!==undefined?cx:(Math.random()-.5)*30,z=cz!==undefined?cz:(Math.random()-.5)*30,m=wpn(t);m.scale.setScalar(1.5);m.add(new T.PointLight(0xffc933,1.2,9));m.position.set(x,28,z);scene.add(m);
 const r=new T.Mesh(new T.RingGeometry(.9,1.2,32),new T.MeshBasicMaterial({color:0xffd166,transparent:true,opacity:.8,side:T.DoubleSide}));r.rotation.x=-Math.PI/2;r.position.set(x,.1,z);scene.add(r);wp.push({m,r,t,vy:-6,land:0})}
function landFx(w){const x=w.m.position.x,z=w.m.position.z;ring(x,z,0xffc933);spark(x,1,z);shake=Math.max(shake,.35);sfx(140,.3,'sawtooth');
 for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-x,dz=e.g.position.z-z,d=Math.hypot(dx,dz);if(d<3)hurtEnemy(e,30,dx/(d||1),dz/(d||1),12)}}
const NJI=['','🔥','⚡','❄️','⛰️','🌿'],ABIL=['','هالة نار تحرق كل اللي حواليك','سرعة برق + صواعق عشوائية + تفادي أسرع','صقيع يبطّئ الأعداء القريبين','درع صخري: ضرر أقل للنص + ضرب أقوى','طاقة تشفيك وتشحن المرار أسرع'];
function banner(t,sub,c){const el=$('tf');el.style.setProperty('--c','#'+c.toString(16).padStart(6,'0'));el.innerHTML='<b>'+t+'</b>'+(sub?'<small>'+sub+'</small>':'');el.classList.remove('show');void el.offsetWidth;el.classList.add('show')}
function transformFx(n){const c=EC[n],p=H.g.position,m=new T.Mesh(new T.CylinderGeometry(1.6,1.6,12,24,1,true),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.8,side:T.DoubleSide,blending:T.AdditiveBlending,depthWrite:false}));m.position.set(p.x,6,p.z);scene.add(m);let t=0;
 fx.push(dt=>{t+=dt;m.position.set(H.g.position.x,6,H.g.position.z);m.scale.set(1+t*1.2,1,1+t*1.2);m.rotation.y+=dt*10;m.material.opacity=Math.max(0,.8-t*1.3);if(t>.65){scene.remove(m);m.geometry.dispose();m.material.dispose();return true}});
 ring(p.x,p.z,c);setTimeout(()=>ring(H.g.position.x,H.g.position.z,0xffc933),130);for(let i=0;i<4;i++)spark(p.x,.8+i*.7,p.z,i%2?c:0xffd166,10);
 banner(NJI[n]+' '+SK[n].n,ABIL[n],c)}
function grab(w){scene.remove(w.m);scene.remove(w.r);let n=1+(Math.random()*5|0);if(n===curSk)n=1+(n%5);setSkin(n);gNin(n);equip(NJ[n].w);buff=10;score+=5;$('sc').textContent=score;H.hp=Math.min(100,H.hp+10);
 transformFx(n);spark(H.g.position.x,2,H.g.position.z);sfx(800,.3,'sine');say(H,SK[n].n+' + '+WN[NJ[n].w]+'!',1);
 if(++wc>=5){wc=0;equip(4);buff=18;ult=18;ultT=0;windStorm();gAdd(3,1);sfx(60,1,'sawtooth');shake=1;say(H,'رمح الإعصار الأقصى! الإعصار الذهبي!',.9);banner('🌪️ الإعصار الذهبي','رمح الإعصار الأقصى · ضرر هائل',0xffd166)}}
function windStorm(){const m=new T.Mesh(new T.CylinderGeometry(4,.8,7,20,1,true),new T.MeshBasicMaterial({color:0xffd166,transparent:true,opacity:.35,side:T.DoubleSide}));scene.add(m);
 fx.push(dt=>{m.position.set(H.g.position.x,3.5,H.g.position.z);m.rotation.y+=dt*18;if(ult<=0||state!=='play'){scene.remove(m);return true}})}
const TG=[];
function mixW(c,k){const f=v=>Math.round(v+(255-v)*k);return f(c>>16&255)<<16|f(c>>8&255)<<8|f(c&255)}
function tornCol(){if(gfT>0)return 0xffd23f;const q=window.heroCol?heroCol():(SK[curSk]||SK[0]);let c=q.suit,b=q.band;const lum=x=>((x>>16&255)*.3+(x>>8&255)*.59+(x&255)*.11)/255;
 if(lum(c)<.28)c=lum(b)>.28?b:0x7aa7ff;else if(lum(c)>.85)c=0x9be7ff;return c}
function tornado(){const c=tornCol(),mk=(col,o)=>new T.MeshBasicMaterial({color:col,transparent:true,opacity:o,side:T.DoubleSide,blending:T.AdditiveBlending,depthWrite:false}),mA=mk(c,.6),mB=mk(mixW(c,.6),.75),root=new T.Group(),P=[];
 if(!TG.length)for(let i=0;i<16;i++){const k=i/15;TG.push(new T.TorusGeometry(.35+Math.pow(k,1.5)*3.1,.1+k*.14,5,26,3.3))}
 for(let i=0;i<16;i++){const k=i/15,pv=new T.Group();pv.position.y=.15+k*5.2;for(let j=0;j<2;j++){const m=new T.Mesh(TG[i],j?mB:mA);m.rotation.x=Math.PI/2;m.rotation.z=j*Math.PI;pv.add(m)}root.add(pv);P.push([pv,k])}
 scene.add(root);ring(H.g.position.x,H.g.position.z,c);let t=0;
 fx.push(dt=>{t+=dt;const a=Math.min(1,t/.15),o=Math.max(0,Math.min(1,(.9-t)/.25));root.position.set(H.g.position.x,0,H.g.position.z);root.scale.set(a,a,a);mA.opacity=.6*o;mB.opacity=.75*o;
  P.forEach(([pv,k],i)=>{pv.rotation.y+=dt*(22-k*8);pv.position.x=Math.sin(t*9+i*.6)*.12*(.4+k)});
  if(t>.9){scene.remove(root);return true}})}

const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));

function sfx(f,d,type){if(!ac||!S.snd)return;const o=ac.createOscillator(),g=ac.createGain();o.type=type||'square';o.frequency.setValueAtTime(f,ac.currentTime);o.frequency.exponentialRampToValueAtTime(40,ac.currentTime+d);g.gain.setValueAtTime(.18,ac.currentTime);g.gain.exponentialRampToValueAtTime(.001,ac.currentTime+d);o.connect(g).connect(ac.destination);o.start();o.stop(ac.currentTime+d)}
function tone(f,d,type,g){if(!ac||!S.snd)return;const o=ac.createOscillator(),a=ac.createGain();o.type=type;o.frequency.value=f;a.gain.setValueAtTime(g,ac.currentTime);a.gain.exponentialRampToValueAtTime(.001,ac.currentTime+d);o.connect(a).connect(ac.destination);o.start();o.stop(ac.currentTime+d)}
const NOTES=[0,3,7,10,12,10,7,3];let mi=0;setInterval(()=>{0},230);
function jingle(){[0,4,7,12].forEach((n,i)=>setTimeout(()=>tone(262*Math.pow(2,n/12),.25,'square',.12),i*160))}
function speak(t,pitch){try{if(!S.voice||!('speechSynthesis' in window))return;const n=performance.now();if(n-lastSp<1000)return;lastSp=n;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t),v=speechSynthesis.getVoices().find(v=>/^ar/i.test(v.lang));if(v)u.voice=v;u.lang=v?v.lang:'ar-EG';u.pitch=pitch;u.rate=1.15;speechSynthesis.speak(u)}catch(e){}}
function say(e,t,pitch){e.b.textContent=t;e.b.style.display='block';e.bt=1.1;speak(t,pitch)}

const sparkG=new T.BoxGeometry(.18,.18,.18),sparkM=new T.MeshBasicMaterial({color:0xffe066});
const sparkMs={};const sparkMat=c=>c?(sparkMs[c]||(sparkMs[c]=new T.MeshBasicMaterial({color:c}))):sparkM;
function spark(x,y,z,c,n){for(let i=0;i<(n||9);i++){const m=new T.Mesh(sparkG,sparkMat(c));m.position.set(x,y,z);scene.add(m);const v=new T.Vector3(Math.random()-.5,Math.random()*.8+.2,Math.random()-.5).multiplyScalar(7);let t=0;
 fx.push(dt=>{t+=dt;v.y-=18*dt;m.position.addScaledVector(v,dt);m.scale.setScalar(Math.max(0,1-t*2.2));if(t>.45){scene.remove(m);return true}})}}
function ember(x,y,z,c){const m=new T.Mesh(sparkG,sparkMat(c||0xffb347)),s0=.5+Math.random()*.6;m.position.set(x+(Math.random()-.5)*.9,y,z+(Math.random()-.5)*.9);m.scale.setScalar(s0);scene.add(m);const v=new T.Vector3((Math.random()-.5)*1.2,2.5+Math.random()*3,(Math.random()-.5)*1.2);let t=0;
 fx.push(dt=>{t+=dt;m.position.addScaledVector(v,dt);m.rotation.x+=dt*6;m.rotation.y+=dt*5;m.scale.setScalar(Math.max(0,s0*(1-t/.9)));if(t>.9){scene.remove(m);return true}})}
function dot(e,d,c){if(e.dead)return;e.hp-=d;spark(e.g.position.x,1.8,e.g.position.z,c,4);if(e.hp<=0){e.dead=.001;score+=e.boss?60:10;$('sc').textContent=score;if(e.boss||Math.random()<.3)drop(e.g.position.x,e.g.position.z);say(e,'آخ يا ضهري!',1.45)}}
const TR_N=16,TR_LIFE=.3,TIPS=[[2,.2],[1.7,-.3],[2,.3],[1.6,.2],[2.6,.5]],trail=(()=>{const geo=new T.BufferGeometry(),pos=new Float32Array(TR_N*6),col=new Float32Array(TR_N*6),idx=[];for(let i=0;i<TR_N-1;i++){const a=i*2;idx.push(a,a+1,a+2,a+1,a+3,a+2)}
 geo.setAttribute('position',new T.BufferAttribute(pos,3).setUsage(T.DynamicDrawUsage));geo.setAttribute('color',new T.BufferAttribute(col,3).setUsage(T.DynamicDrawUsage));geo.setIndex(idx);
 const m=new T.Mesh(geo,new T.MeshBasicMaterial({vertexColors:true,transparent:true,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide,fog:false}));m.frustumCulled=false;m.visible=false;scene.add(m);return {m,geo,pos,col,pts:[]}})();
const _a=new T.Vector3(),_b=new T.Vector3(),_c1=new T.Color(),_c2=new T.Color();
function trailAdd(){H.g.updateMatrixWorld(true);if(H.wm){const t=TIPS[H.wt||0];H.wm.localToWorld(_a.set(0,t[0],0));H.wm.localToWorld(_b.set(0,t[1],0))}else{H.AR.localToWorld(_a.set(0,-1.2,.6));H.AR.localToWorld(_b.set(0,-.4,0))}trail.pts.unshift({a:_a.clone(),b:_b.clone(),t:0})}
function trailUpd(dt){const P=trail.pts;for(const q of P)q.t+=dt;while(P.length&&(P[P.length-1].t>TR_LIFE||P.length>TR_N))P.pop();
 if(P.length<2){trail.m.visible=false;return}trail.m.visible=true;
 _c1.setHex(ult>0?0xffd166:curSk?EC[curSk]:buff>0?0xffd166:0xffb703);_c2.copy(_c1).lerp(new T.Color(0xffffff),.55);
 for(let i=0;i<TR_N;i++){const q=P[Math.min(i,P.length-1)],f=i<P.length?Math.max(0,1-q.t/TR_LIFE):0,o=i*6;
  trail.pos[o]=q.a.x;trail.pos[o+1]=q.a.y;trail.pos[o+2]=q.a.z;trail.pos[o+3]=q.b.x;trail.pos[o+4]=q.b.y;trail.pos[o+5]=q.b.z;
  trail.col[o]=_c2.r*f;trail.col[o+1]=_c2.g*f;trail.col[o+2]=_c2.b*f;trail.col[o+3]=_c1.r*f*.35;trail.col[o+4]=_c1.g*f*.35;trail.col[o+5]=_c1.b*f*.35}
 trail.geo.attributes.position.needsUpdate=true;trail.geo.attributes.color.needsUpdate=true}
function ring(x,z,c){const m=new T.Mesh(new T.RingGeometry(.8,1,40),new T.MeshBasicMaterial({color:c||0xa3c93a,transparent:true,side:T.DoubleSide}));m.rotation.x=-Math.PI/2;m.position.set(x,.15,z);scene.add(m);let t=0;
 fx.push(dt=>{t+=dt;m.scale.setScalar(1+t*20);m.material.opacity=1-t*2.2;if(t>.45){scene.remove(m);return true}})}

const pk=[],pkG=new T.OctahedronGeometry(.4),pkM=new T.MeshLambertMaterial({color:0xff4d6d,emissive:0x990022});
function drop(x,z){const m=new T.Mesh(pkG,pkM);m.position.set(x,.8,z);scene.add(m);pk.push(m)}
const PAL=[0x6d597a,0xb56576,0x355070,0x588157];
const BK=[{n:'ملازم سم',s:1.45,c:0x7b2cbf,hp:160,sp:.75,dm:16},{n:'الثور',s:1.9,c:0xc1121f,hp:230,sp:.55,dm:24},{n:'شبح الليل',s:1.25,c:0x4cc9f0,hp:130,sp:1.3,dm:14,tp:1},{n:'الساحرة',s:1.35,c:0x9d4edd,hp:150,sp:.8,dm:12,sm:1},{n:'الأسطى سم',s:1.8,c:0x222222,hp:340,sp:.85,dm:22,tp:1,sm:1}];
const BA={3:0,5:1,7:2,9:3,10:4};
function spawn(boss,kind){const K=boss?BK[kind||0]:null;const a=Math.random()*Math.PI*2,r=15+Math.random()*3;
 const fast=!boss&&wave>=2&&Math.random()<.3;const e={fast,...person({suit:K?K.c:fast?0xe76f51:PAL[Math.random()*4|0],pants:0x22252f,hat:0x111111,angry:1,lite:1,skin:0xe3a72f,s:K?K.s:fast?.85:1}),b:mkBub('e'),hp:K?K.hp:fast?30:50,dead:0,stun:0,wind:0,kx:0,kz:0,ph:Math.random()*6,bt:0,boss,K,tp:3,sm:5,sa:Math.random()*6.283};
 e.g.position.set(Math.cos(a)*r,0,Math.sin(a)*r);e.mhp=e.hp;e.hbEl=document.createElement('div');e.hbEl.className='hb';e.hbEl.style.width=(K?90:46)+'px';e.hbEl.innerHTML='<i></i>';$('bubbles').appendChild(e.hbEl);enemies.push(e);if(K)say(e,K.n+'!',.6)}
function flashE(e){const f=h=>e.g.traverse(m=>{if(m.material&&m.material.emissive)m.material.emissive.setHex(h)});f(0xffffff);setTimeout(()=>f(0),90)}
function hurtEnemy(e,dmg,nx,nz,kb){if(e.dead)return;flashE(e);e.shk=.15;e.hp-=dmg;e.kx=nx*kb;e.kz=nz*kb;e.stun=.55;e.wind=0;
 spark(e.g.position.x,2.2,e.g.position.z);sfx(180,.18);shake=Math.max(shake,.25);
 combo++;gAdd(4,0,combo);comboT=2.5;hs=.05;if(e.hp<=0){e.dead=.001;if(e.boss)gAdd(2,1);score+=(e.boss?60:10)+combo;$('sc').textContent=score;if(e.boss||Math.random()<.3)drop(e.g.position.x,e.g.position.z)}
 say(e,e.hp<=0?'آخ يا ضهري!':ENEMY_LINE,1.45)}
function hurtHero(d){if(H.inv>0||H.hp<=0||gfT>0||rdT>0)return;if(pas(4))d*=.5;H.hp-=d;combo=0;H.inv=.6;H.rage=Math.min(100,H.rage+25);sfx(110,.25,'sawtooth');shake=.45;
 const f=$('flash');f.style.opacity=.35;setTimeout(()=>f.style.opacity=0,120);say(H,HERO_LINE,.75);
 if(H.hp<=0){state='over';setTimeout(()=>finish(false),600)}}

function slash(){const st=H.cs||0,m=new T.Mesh(new T.RingGeometry(1.3,2.3+st*.3,20,1,-Math.PI/2-1.2,2.4),new T.MeshBasicMaterial({color:curSk?EC[curSk]:buff>0?0xffd166:0xffb703,transparent:true,opacity:.85,side:T.DoubleSide,blending:T.AdditiveBlending,depthWrite:false})),pv=new T.Group();
 m.rotation.x=-Math.PI/2;if(st===1)m.scale.x=-1;if(st===2)m.rotation.y=.5;pv.add(m);pv.position.set(H.g.position.x,1.6+H.g.position.y,H.g.position.z);pv.rotation.y=H.rot;scene.add(pv);let t=0;
 fx.push(dt=>{t+=dt;pv.scale.setScalar(1+t*1.5);m.material.opacity=.85-t*4.5;if(t>.19){scene.remove(pv);return true}})}
function chips(x,z){for(let i=0;i<10;i++){const m=new T.Mesh(new T.BoxGeometry(.3,.12,.5),new T.MeshLambertMaterial({color:0x8d5524}));m.position.set(x,1,z);scene.add(m);const v=new T.Vector3(Math.random()-.5,Math.random()*.9+.3,Math.random()-.5).multiplyScalar(6);let t=0;fx.push(dt=>{t+=dt;v.y-=18*dt;m.position.addScaledVector(v,dt);m.rotation.x+=dt*8;if(m.position.y<.1){m.position.y=.1;v.set(0,0,0)}if(t>1.2){scene.remove(m);return true}})}}
function hitCrates(){const p=H.g.position;if(window.hitProps)hitProps();for(const c of CR){if(!c.on)continue;const dx=c.m.position.x-p.x,dz=c.m.position.z-p.z,d=Math.hypot(dx,dz);
  if(d<3.3&&(d<1.5||(dx*Math.sin(H.rot)+dz*Math.cos(H.rot))/d>0)){c.on=0;c.t=20;c.m.visible=false;gAdd(0,1);if(window.coinPop)coinPop(c.m.position.x,c.m.position.z,4+(Math.random()*6|0));chips(c.m.position.x,c.m.position.z);sfx(150,.2);const r=Math.random();if(r<.5)drop(c.m.position.x,c.m.position.z);else if(r<.8)dropWpn(c.m.position.x,c.m.position.z)}}}
function punch(){const p=H.g.position,fx_=Math.sin(H.rot),fz=Math.cos(H.rot);slash();hitCrates();if(H.cs===2){ring(p.x,p.z,0xffd166);shake=Math.max(shake,.5)}
 for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z,d=Math.hypot(dx,dz);
  if(d<(buff>0?4:3.1)&&(d<1||(dx*fx_+dz*fz)/d>0))hurtEnemy(e,(gfT>0?160:ult>0?90:buff>0?42:25)*[1,1.2,1.8][H.cs||0]*(pas(4)?1.3:1),dx/(d||1),dz/(d||1),[10,10,20][H.cs||0])}}
function special(){H.rage=0;if(gfT>0)goldRush();tornado();ring(H.g.position.x,H.g.position.z,EC[curSk]);skill();shake=.7;sfx(90,.5,'sawtooth');
 for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-H.g.position.x,dz=e.g.position.z-H.g.position.z,d=Math.hypot(dx,dz);if(d<9)hurtEnemy(e,60,dx/(d||1),dz/(d||1),18)}}

const STORY={};
function comic(ps,cb){state='comic';let i=0;const o=$('comic');o.classList.add('show');
 const draw=()=>{o.style.background='radial-gradient(circle at 50% 40%,'+(ps[i][2]||'#1d3557')+',#05070f 78%)';o.innerHTML='<small class="sn">مشهد '+(i+1)+'/'+ps.length+'</small><div class="panel"><div class="art">'+ps[i][0]+'</div><div class="cap">'+ps[i][1]+'</div></div><button class="go">'+(i<ps.length-1?'كمّل':'يلا')+'</button>';
  o.querySelector('button').onclick=()=>{sfx(500,.08);if(++i<ps.length)draw();else{o.classList.remove('show');state='play';cb()}}};draw()}
function finish(win){state='over';$('ot').textContent=win?'كسبت يا بطل!':'سقط النينجا!';$('fin').textContent=(win?'رجعت العربية! ':'')+'وصلت للموجة '+wave+' وجمعت '+score+' نقطة.';if(win)jingle();$('over').classList.add('show')}
function reset(){enemies.forEach(e=>{scene.remove(e.g);e.b.remove();e.hbEl.remove()});enemies=[];pk.forEach(m=>scene.remove(m));pk.length=0;wp.forEach(w=>{scene.remove(w.m);scene.remove(w.r)});wp.length=0;buff=0;wc=0;ult=0;wpT=4;unequip();setSkin(0);trail.pts.length=0;trail.m.visible=false;H.pt=0;$('tf').classList.remove('show');seen={};combo=0;score=0;wave=0;waveWait=.8;
 Object.assign(H,{hp:100,rage:0,y:0,vy:0,at:0,inv:0});H.g.position.set(0,0,0);$('sc').textContent=0;$('wv').textContent='الموجة 1';state='play'}

function step(dt){
 comboT-=dt;if(comboT<=0)combo=0;
 let ix=inp.x,iz=inp.z;
 if(keys.a||keys.arrowleft)ix-=1;if(keys.d||keys.arrowright)ix+=1;if(keys.w||keys.arrowup)iz-=1;if(keys.s||keys.arrowdown)iz+=1;
 let len=Math.hypot(ix,iz);if(len>1){ix/=len;iz/=len;len=1}
 const p=H.g.position;
 if(len>.1){const spd=7.5*(pas(2)?1.35:pas(5)?1.12:1);p.x+=ix*spd*dt;p.z+=iz*spd*dt;H.rot+=wrap(Math.atan2(ix,iz)-H.rot)*Math.min(1,dt*14)}
 H.dc=Math.max(0,(H.dc||0)-dt);H.cw=Math.max(0,(H.cw||0)-dt);
 if(inp.d&&H.dc<=0){H.ddx=len>.1?ix/len:Math.sin(H.rot);H.ddz=len>.1?iz/len:Math.cos(H.rot);H.dd=.18;H.dc=pas(2)?.4:.8;H.inv=Math.max(H.inv,.35);sfx(520,.14,'sine');ring(p.x,p.z,0x9be7ff)}inp.d=0;
 if(H.dd>0){H.dd-=dt;p.x+=H.ddx*20*dt;p.z+=H.ddz*20*dt;if(Math.random()<.5)spark(p.x,1,p.z)}
 for(const c of CR)if(!c.on&&(c.t-=dt)<=0){c.on=1;c.m.visible=true}
 p.x=Math.max(-19,Math.min(19,p.x));p.z=Math.max(-19,Math.min(19,p.z));
 if(inp.j&&H.y===0)H.vy=10;inp.j=0;H.vy-=28*dt;H.y=Math.max(0,H.y+H.vy*dt);if(H.y===0)H.vy=0;p.y=H.y;
 if((inp.p||hold.p)&&H.at<=0){H.cs=H.cw>0?((H.cs||0)+1)%3:0;H.cw=.8;H.at0=[.28,.28,.42][H.cs];H.at=H.at0;H.did=false;sfx(300+H.cs*120,.1)}inp.p=0;
 if(H.at>0){H.at-=dt;if(!H.did&&H.at<H.at0*.6){H.did=true;punch()}}
 if(inp.s&&H.rage>=100)special();inp.s=0;
 H.inv=Math.max(0,H.inv-dt);H.g.visible=H.inv<=0||Math.floor(H.inv*22)%2===0;H.g.rotation.y=H.rot;
 H.ph+=dt*len*13;const sw=Math.sin(H.ph)*.9*len;H.L.rotation.x=sw;H.R.rotation.x=-sw;H.AL.rotation.x=-sw;
 H.AR.rotation.x=H.at>0?-1.7*Math.sin(Math.max(0,H.at)/(H.at0||.32)*Math.PI):sw;
 H.cape.rotation.x=.25+len*.6+Math.sin(performance.now()/120)*.08+(H.vy>0?.3:0);
 animFlow(H,performance.now()/1000,Math.min(1.2,len+(H.vy>0?.4:0)));
 if(H.at>0&&dt>0)trailAdd();trailUpd(dt);

 for(let i=pk.length-1;i>=0;i--){const m=pk[i];m.rotation.y+=dt*3;m.position.y=.8+Math.sin(performance.now()/200)*.15;if(Math.hypot(m.position.x-p.x,m.position.z-p.z)<1.6){H.hp=Math.min(100,H.hp+25);sfx(700,.25,'sine');scene.remove(m);pk.splice(i,1)}}
 buff=Math.max(0,buff-dt);if(buff<=0&&H.wm)unequip();
 if(buff<=0&&curSk){ring(p.x,p.z,EC[curSk]);spark(p.x,2,p.z,EC[curSk],8);setSkin(0);banner('🥷 رجعت مراري','',0xa3c93a)}
 H.aura.intensity=buff>0&&curSk?1.6+Math.sin(performance.now()/120)*.4:0;
 if(buff>0&&curSk){H.pt=(H.pt||0)-dt;const k=curSk,ec=EC[k];if(Math.random()<dt*12)ember(p.x+(Math.random()-.5)*1.6,.3,p.z+(Math.random()-.5)*1.6,ec);
  if(k===1&&H.pt<=0){H.pt=.45;for(const e of enemies)if(!e.dead&&Math.hypot(e.g.position.x-p.x,e.g.position.z-p.z)<3.6)dot(e,7,0xff6a1a)}
  else if(k===2&&H.pt<=0){H.pt=1.3;let b=null,bd=14;for(const e of enemies){if(e.dead)continue;const d=Math.hypot(e.g.position.x-p.x,e.g.position.z-p.z);if(d<bd){bd=d;b=e}}if(b){bolt(b.g.position.x,b.g.position.z,ec);hurtEnemy(b,28,0,0,0)}}
  else if(k===5){H.hp=Math.min(100,H.hp+4*dt);H.rage=Math.min(100,H.rage+6*dt)}}
 if(ult>0){ult-=dt;ultT-=dt;if(ultT<=0){ultT=.35;for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z,d=Math.hypot(dx,dz);if(d<5)hurtEnemy(e,35,dx/(d||1),dz/(d||1),14)}}}
 wpT-=dt;if(wpT<=0&&wp.length<2){dropWpn();wpT=8+Math.random()*5}
 for(let i=wp.length-1;i>=0;i--){const w=wp[i];
  if(!w.land){w.vy-=30*dt;w.m.position.y+=w.vy*dt;w.m.rotation.y+=dt*8;if(w.m.position.y<=1){w.m.position.y=1;w.land=1;landFx(w)}}
  else{w.m.rotation.y+=dt*3;w.m.position.y=1.2+Math.sin(performance.now()/200)*.2;w.r.scale.setScalar(1+Math.sin(performance.now()/150)*.12);if(Math.hypot(w.m.position.x-p.x,w.m.position.z-p.z)<1.9){grab(w);wp.splice(i,1)}}}
 let alive=0;
 for(const e of enemies){const g=e.g,ep=g.position;
  if(e.dead){e.dead+=dt;g.rotation.x=-Math.min(1.5,e.dead*5);ep.y=0;
   if(!e.dz){e.dz=1;e.sc0=g.scale.x;g.traverse(m=>{if(m.material)m.material.transparent=true});for(let k=0;k<6;k++)spark(ep.x,.8+k*.4,ep.z,k%2?0xfff1a8:0xffb347,5);ring(ep.x,ep.z,0xffd166)}
   if(e.dead>.3){const q=Math.min(1,(e.dead-.3)/1.15),o=1-q;g.traverse(m=>{if(m.material){m.material.opacity=o;if(m.material.emissive)m.material.emissive.setRGB(Math.min(1,q*2.4),q*.75,q*.18)}});ep.y=-q*.9;g.scale.setScalar(e.sc0*(1-q*.4));
    if(Math.random()<.75)ember(ep.x,.4+Math.random()*1.8*e.sc0,ep.z,Math.random()<.5?0xffd166:0xff8a3d);if(Math.random()<.25)spark(ep.x,1.2+Math.random(),ep.z,0xfff1a8,2)}continue}
  alive++;
  animFlow(e,performance.now()/1000,e.stun>0?0:.8);
  if(e.K&&e.stun<=0){if(e.K.tp&&(e.tp-=dt)<=0){e.tp=3.5;ring(ep.x,ep.z,0x4cc9f0);ep.x=p.x+(Math.random()-.5)*8;ep.z=p.z+(Math.random()-.5)*8;ring(ep.x,ep.z,0x4cc9f0)}if(e.K.sm&&(e.sm-=dt)<=0){e.sm=7;spawn(false);spawn(false)}}
  if(e.stun>0){e.stun-=dt;ep.x+=e.kx*dt;ep.z+=e.kz*dt;e.kx*=.9;e.kz*=.9}
  else{const dx=p.x-ep.x,dz=p.z-ep.z,d=Math.hypot(dx,dz)||1,sp=Math.min(4.6,2.6+wave*.18)*(e.K?e.K.sp:e.fast?1.5:1)*(pas(3)&&d<7?.45:1);
   g.rotation.y=Math.atan2(dx,dz);
   if(e.wind>0){e.wind-=dt;e.AR.rotation.x=-2.4+e.wind*3;if(e.wind<=0&&d<(e.boss?3:2.4)&&H.y<1)hurtHero((e.K?e.K.dm:7)+wave)}
   else if(d>(e.boss?2.5:1.7)){e.sa+=dt*.4;const fo=Math.min(4,Math.max(0,d-2.5)*.7),mx=dx+Math.cos(e.sa)*fo,mz=dz+Math.sin(e.sa)*fo,md=Math.hypot(mx,mz)||1;ep.x+=mx/md*sp*dt;ep.z+=mz/md*sp*dt;e.ph+=dt*sp*3;e.L.rotation.x=Math.sin(e.ph)*.8;e.R.rotation.x=-e.L.rotation.x;e.AR.rotation.x=0}
   else e.wind=.55}
  for(const o of enemies){if(o===e||o.dead)continue;const dx=ep.x-o.g.position.x,dz=ep.z-o.g.position.z,d=Math.hypot(dx,dz);if(d<1.4&&d>0){ep.x+=dx/d*dt*3;ep.z+=dz/d*dt*3}}
  ep.x=Math.max(-20,Math.min(20,ep.x));ep.z=Math.max(-20,Math.min(20,ep.z))}
 for(let i=enemies.length-1;i>=0;i--)if(enemies[i].dead>1.6){scene.remove(enemies[i].g);enemies[i].b.remove();enemies[i].hbEl.remove();enemies.splice(i,1)}
 if(mode==='lv'){if(!alive&&state==='play')lvWave(dt);return}if(!alive&&state==='play'){waveWait-=dt;if(waveWait<=0){
  if(mode==='story'&&STORY[wave]&&!seen[wave]){seen[wave]=1;comic(STORY[wave],()=>{if(wave===10)finish(true);else waveWait=0});return}
  wave++;waveWait=2;H.hp=Math.min(100,H.hp+20);$('wv').textContent=mode==='story'?'المرحلة '+wave+'/10':'الموجة '+wave;
  for(let i=0;i<Math.min(2+wave,10);i++)spawn(false);if(mode==='story'){if(BA[wave]!==undefined)spawn(true,BA[wave])}else if(wave%3===0)spawn(true,(wave/3-1)%4)}}
}

const v3=new T.Vector3();
function bubPos(e,h){if(e.bt>0){e.bt-=1/60;v3.set(e.g.position.x,e.g.position.y+h,e.g.position.z).project(cam);e.b.style.left=(v3.x*.5+.5)*innerWidth+'px';e.b.style.top=(-v3.y*.5+.5)*innerHeight+'px'}else e.b.style.display='none'}
function hbPos(e){if(e.dead){e.hbEl.style.display='none';return}v3.set(e.g.position.x,e.g.position.y+e.g.scale.x*3.45,e.g.position.z).project(cam);const q=e.hbEl.style;q.display='block';q.left=(v3.x*.5+.5)*innerWidth+'px';q.top=(-v3.y*.5+.5)*innerHeight+'px';e.hbEl.firstChild.style.width=Math.max(0,e.hp/e.mhp*100)+'%'}
let last=performance.now();
function loop(n){requestAnimationFrame(loop);let dt=Math.min((n-last)/1000,.05);last=n;const rdt=dt;if(hs>0){hs-=dt;dt=0}
 for(const e of enemies){if(e.shk>0){e.shk-=rdt;e.g.rotation.z=(Math.random()-.5)*.25}else e.g.rotation.z=0}
 if(state==='play')step(dt);
 if(state!=='pause')for(let i=fx.length-1;i>=0;i--)if(fx[i](dt))fx.splice(i,1);
 const p=H.g.position;shake=Math.max(0,shake-dt*1.6);
 const sh=$('shp').classList.contains('show'),tx=sh?p.x+1.5:p.x*.65,tz=sh?p.z+6.5:p.z+12;
 cam.position.x+=(tx-cam.position.x)*Math.min(1,dt*5)+(Math.random()-.5)*shake*.5;cam.position.y=(sh?3.4:11)+(Math.random()-.5)*shake*.5;cam.position.z+=(tz-cam.position.z)*Math.min(1,dt*5);
 cam.lookAt(sh?p.x:tx,sh?-.2:1.2,p.z-1);if(sh)H.g.rotation.y+=dt*.9;
 $('buff').textContent=ult>0?'⚡ الإعصار الذهبي '+Math.ceil(ult)+'ث':buff>0?(curSk?NJI[curSk]+' '+SK[curSk].n+' · ':'سلاح ذهبي · ')+Math.ceil(buff)+'ث':'';$('buff').style.display=buff>0?'block':'none';
 $('wpc').textContent='🗡️ '+'●'.repeat(wc)+'○'.repeat(5-wc);$('bd').style.opacity=H.dc>0?.45:1;shine(n/1000);bubPos(H,3.9);for(const e of enemies){bubPos(e,e.g.scale.x*3.9+.3);hbPos(e)}
 $('combo').textContent=combo>1?'كومبو ×'+combo:'';$('hp').firstChild.style.width=Math.max(0,H.hp)+'%';$('rage').firstChild.style.width=H.rage+'%';
 const full=H.rage>=100;$('rage').classList.toggle('full',full);$('bs').classList.toggle('on',full);
 renderer.render(scene,cam)}
function resize(){renderer.setSize(innerWidth,innerHeight,false);cam.aspect=innerWidth/innerHeight;cam.fov=innerWidth<innerHeight?72:55;cam.updateProjectionMatrix()}
addEventListener('resize',resize);resize();cam.position.set(0,11,12);

function begin(m){try{ac=ac||new (window.AudioContext||window.webkitAudioContext)()}catch(e){}['start','over','set'].forEach(i=>$(i).classList.remove('show'));mode=m;reset()}
$('pStory').onclick=()=>begin('story');$('pArc').onclick=()=>begin('arcade');$('again').onclick=()=>begin(mode);
$('toMenu').onclick=()=>{$('over').classList.remove('show');$('start').classList.add('show');state='menu'};
$('pSet').onclick=()=>{$('start').classList.remove('show');$('set').classList.add('show')};
$('back').onclick=()=>{$('set').classList.remove('show');$('start').classList.add('show')};
const L2={sSnd:['المؤثرات','snd'],sVoice:['أصوات الشخصيات','voice'],sMusic:['الموسيقى','music'],sQ:['الرسوميات','q']};
function setLab(){for(const id in L2){const [n,k]=L2[id];$(id).innerHTML='<span>'+n+'</span><span>'+(k==='q'?(S.q?'عالية':'خفيفة'):(S[k]?'شغّال':'مقفول'))+'</span>'}}
function applyQ(){renderer.setPixelRatio(S.q?Math.min(devicePixelRatio,PRM):1);sun.castShadow=!!S.q;scene.traverse(o=>{if(o.material)o.material.needsUpdate=true});resize()}
for(const id in L2)$(id).onclick=()=>{const k=L2[id][1];S[k]=S[k]?0:1;if(k==='q')applyQ();setLab()};
setLab();
addEventListener('keydown',e=>{const k=e.key.toLowerCase();keys[k]=1;if(k===' '){inp.j=1;e.preventDefault()}if(k==='j'||k==='z'||k==='enter')inp.p=1;if(k==='k'||k==='x')inp.s=1;if(k==='shift'||k==='l')inp.d=1});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=0);
$('c').addEventListener('pointerdown',e=>{if(e.pointerType==='mouse')inp.p=1});
const press=(id,k)=>{const b=$(id),up=()=>{b.classList.remove('dn');if(k==='p')hold.p=0};
 b.addEventListener('pointerdown',e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}inp[k]=1;if(k==='p')hold.p=1;b.classList.add('dn')});
 b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('contextmenu',e=>e.preventDefault())};
press('bp','p');press('bj','j');press('bs','s');press('bd','d');
const st=$('stick'),kn=$('knob');let sid=null;
function stick(e){const r=st.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.min(1,Math.hypot(dx,dy)/(r.width*.36)),a=Math.atan2(dy,dx);
 inp.x=Math.cos(a)*m;inp.z=Math.sin(a)*m;kn.style.transform='translate('+Math.cos(a)*m*r.width*.25+'px,'+Math.sin(a)*m*r.width*.25+'px)'}
st.addEventListener('pointerdown',e=>{sid=e.pointerId;st.setPointerCapture(sid);stick(e)});
st.addEventListener('pointermove',e=>{if(e.pointerId===sid)stick(e)});
const rel=e=>{if(e.pointerId===sid){sid=null;inp.x=inp.z=0;kn.style.transform=''}};
st.addEventListener('pointerup',rel);st.addEventListener('pointercancel',rel);
if(matchMedia('(pointer:coarse)').matches)document.querySelector('.kb').style.display='none';
requestAnimationFrame(loop);
/* ===== v3: LEGO levels / powers / shop / save (additive layer) ===== */
(()=>{
const KEY='marari_v3';let SV={lv:1,coins:0,pw:[],eq:0,sk:[0],cur:0};
try{const r=JSON.parse(localStorage.getItem(KEY)||'null');if(r)SV={...SV,...r}}catch(e){}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(SV))}catch(e){}};
SV.gq=SV.gq||[0,0,0,0,0];SV.gu=SV.gu||[];SV.gn=SV.gn||[];let gcd=0,GI=-1,gdN=0;
const rng=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const LMC={},LM=c=>LMC[c]||(LMC[c]=new T.MeshLambertMaterial({color:c})),STG=new T.CylinderGeometry(.4,.4,.28,10),DM=new T.Object3D();
const GTX=tex(128,128,x=>{x.fillStyle='#e6e6e6';x.fillRect(0,0,128,128);for(let i=0;i<4;i++)for(let j=0;j<4;j++){const a=16+i*32,b=16+j*32;x.fillStyle='rgba(0,0,0,.3)';x.beginPath();x.arc(a+2,b+3,12,0,7);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(a,b,11,0,7);x.fill()}},8,8);
const BLD=scene.children.filter(o=>o.material===bm);
/* ---- skins ---- */
const ND=[['فارس الغابة',0x2e7d32,0x5d4037,0xffd54f],['رائد الفضاء',0xeceff1,0x90a4ae,0xff7043],['قرصان البحر',0x6d1b1b,0x263238,0xffca28],['رجل الإطفاء',0xd32f2f,0x37474f,0xffee58],['الشرطي',0x1a3a8a,0x263238,0xfdd835],['سلطان الصحراء',0xe9b44c,0x8d5524,0xc1121f],['الفرعون',0x2a9d8f,0xe9c46a,0x264653],['الفايكنج',0x795548,0x4e342e,0xcfd8dc],['فارس القلعة',0x9e9e9e,0x455a64,0xc1121f],['الروبوت',0x607d8b,0x37474f,0x00e5ff],['الشبح',0xe0e0f0,0xb0b0d0,0x7c4dff],['الساحر',0x5a189a,0x3c096c,0xffd166],['نينجا الظل',0x111118,0x0a0a10,0x7c4dff],['ملك الجليد',0x81d4fa,0xe1f5fe,0xffffff],['سيد اللافا',0xff5722,0x3e2723,0xffc107],['الغواص',0x0277bd,0x01579b,0xffeb3b],['الطيار',0x5d6b3a,0x3e4a28,0xffb300],['عامل البناء',0xff9800,0x1565c0,0xffeb3b],['شيف الفول',0xfafafa,0x424242,0xe63946],['الذئب',0x78909c,0x455a64,0xff5252],['التنين الأخضر',0x00a86b,0x006b44,0xffd54f],['البرق الأزرق',0x2962ff,0x0d1b6b,0xffff00],['الكريستال',0xb388ff,0x4527a0,0x18ffff],['الملك الذهبي',0xffc400,0xb8860b,0xd50000]];
const mkS=(a,i)=>({n:a[0],suit:a[1],pants:a[2],hat:a[1],mask:SHADE(a[1],.8),band:a[3],armor:SHADE(a[1],.55),strap:0x15151a,wrap:a[3],cape:SHADE(a[1],.7),skin:0xf6c744,emblem:a[3],boot:0x22223b,p:60+i*40,l:8+i*8});
const SKS=SK.map((s,i)=>({...s,p:i?100:0,l:i?3*i:0})).concat(ND.map(mkS));
const own=i=>SV.sk.includes(i)||(SKS[i].l&&SV.lv>SKS[i].l);
function paint(i){const s=SKS[i]||SKS[0];H.g.traverse(m=>{if(m.userData.k&&s[m.userData.k]!==undefined)m.material.color.setHex(s[m.userData.k])})}
const _ss=setSkin;setSkin=function(i){_ss(i);if(!i)paint(SV.cur)};
/* ---- powers ---- */
const PN=['نوفا اللهب','سلسلة البرق','صقيع الشتاء','درع الصخر','نبض الشفاء','زلزال الأرض','دوامة الريح','اندفاع التنين','مطر النيازك','غضب النينجا'];
const AD=['الأول','المتوهج','الذهبي','الفضي','العاصف','الغاضب','الملكي','الأسطوري','الصامت','السريع','الثقيل','الساطع','المظلم','الجليدي','الناري','الكوني','الحديدي','الخارق','النقي','الأعظم'];
const pName=n=>PN[(n-1)%10]+' '+AD[((n-1)/10|0)%20];
let pcd=0;
function usePower(){if(state!=='play'||pcd>0||!SV.eq||!SV.pw.includes(SV.eq))return;
 const n=SV.eq,t=(n-1)%10,s=1+((n-1)/10|0)*.12,p=H.g.position,col=EC[1+t%5];pcd=Math.max(3.5,8-n/40);
 const E=enemies.filter(e=>!e.dead).map(e=>{const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z;return{e,dx,dz,d:Math.hypot(dx,dz)}}).sort((a,b)=>a.d-b.d);
 const hit=(o,d)=>hurtEnemy(o.e,d,o.dx/(o.d||1),o.dz/(o.d||1),10),zap=(o,d)=>{bolt(o.e.g.position.x,o.e.g.position.z,col);hit(o,d)};
 ring(p.x,p.z,col);shake=Math.max(shake,.5);sfx(200,.4,'sawtooth');banner('✨ '+pName(n),'',col);
 if(t===0)E.filter(o=>o.d<9).forEach(o=>zap(o,45*s));
 else if(t===1)E.slice(0,3+(s|0)).forEach(o=>zap(o,50*s));
 else if(t===2)E.filter(o=>o.d<13).forEach(o=>{o.e.stun=2.5+s;o.e.kx=o.e.kz=0;spark(o.e.g.position.x,1.5,o.e.g.position.z,col,5)});
 else if(t===3)H.inv=Math.max(H.inv,3+s);
 else if(t===4){H.hp=Math.min(100,H.hp+35*s);H.rage=Math.min(100,H.rage+30);spark(p.x,2,p.z,col,10)}
 else if(t===5){shake=1;E.filter(o=>o.d<14).forEach(o=>{hit(o,30*s);o.e.stun=1})}
 else if(t===6)E.filter(o=>o.d<12).forEach(o=>{o.e.g.position.x-=o.dx*.6;o.e.g.position.z-=o.dz*.6;hit(o,25*s)});
 else if(t===7){const dx=Math.sin(H.rot),dz=Math.cos(H.rot);H.dd=.35;H.ddx=dx;H.ddz=dz;H.inv=Math.max(H.inv,.6);E.filter(o=>o.d<10&&(o.dx*dx+o.dz*dz)/(o.d||1)>.5).forEach(o=>hit(o,55*s))}
 else if(t===8)E.slice(0,4+(s|0)).forEach((o,i)=>setTimeout(()=>{if(!o.e.dead&&state==='play')zap({e:o.e,dx:0,dz:0,d:1},45*s)},i*200));
 else{H.rage=100;E.filter(o=>o.d<6).forEach(o=>hit(o,30*s))}}
/* ---- LEGO props / environments ---- */
function brk(g,w,h,d,c,x,y,z){const m=new T.Mesh(G('BoxGeometry',w,h,d),LM(c));m.position.set(x,y+h/2,z);m.castShadow=m.receiveShadow=true;g.add(m);
 const nx=Math.max(1,Math.round(w/1.4)),nz=Math.max(1,Math.round(d/1.4)),im=new T.InstancedMesh(STG,LM(c),nx*nz);let k=0;
 for(let i=0;i<nx;i++)for(let j=0;j<nz;j++){DM.position.set(x+(i-(nx-1)/2)*1.4,y+h+.14,z+(j-(nz-1)/2)*1.4);DM.updateMatrix();im.setMatrixAt(k++,DM.matrix)}g.add(im);return m}
function prop(kind,pal,rn){const g=new T.Group(),s=1+rn()*.5,c=()=>pal[rn()*pal.length|0];
 if(kind===0){let w=2.8*s;for(let i=0;i<4;i++){brk(g,w,1,w,c(),0,i,0);w*=.82}}
 else if(kind===1){brk(g,1.4,2,1.4,0x8d5524,0,0,0);brk(g,3.4*s,1.2,3.4*s,pal[0],0,2,0);brk(g,2.2*s,1.2,2.2*s,pal[1],0,3.2,0);brk(g,1.4,1.2,1.4,pal[2],0,4.4,0)}
 else if(kind===2){brk(g,4.2*s,.9,1.4,c(),0,0,0);brk(g,4.2*s,.9,1.4,c(),0,.9,0);brk(g,2.8*s,.9,1.4,c(),0,1.8,0)}
 else{brk(g,2.8,1,2.8,c(),0,0,0);const m=new T.Mesh(G('OctahedronGeometry',1.5*s),new T.MeshLambertMaterial({color:pal[1],emissive:pal[1],emissiveIntensity:.5}));m.position.y=3;m.scale.y=1.6;g.add(m)}
 return[g,[1.7,1.9,2.4,1.6][kind]*s]}
const TH=[['حي الفول',0x14213d,0x3a4260,[0xffb703,0xe63946,0x3a86ff]],['غابة الطوب',0x1b4332,0x2d6a4f,[0x95d5b2,0x52b788,0x2d9d5a]],['صحراء ذهبية',0xe9c46a,0xd4a259,[0xe76f51,0xf4a261,0x8d5524]],['جبال الجليد',0x9bd4f5,0xdff3ff,[0xa8dadc,0x457b9d,0xffffff]],['بركان اللافا',0x2b0a0a,0x5a1a10,[0xff6a1a,0xffb703,0x555555]],['مدينة النيون',0x0a0a2a,0x1d1d44,[0xff00aa,0x00e5ff,0xffee00]],['قلعة الفرسان',0x4a6fa5,0x6b7280,[0xb0b0b0,0xc1121f,0x3a5bff]],['ميناء القراصنة',0x0b3a5b,0x6b4f2d,[0x8d5524,0xe63946,0xfff1c1]],['فضاء بعيد',0x050514,0x2a2a4a,[0x9d4edd,0x4cc9f0,0xf72585]],['مصنع الروبوتات',0x2b2d31,0x474b52,[0xfca311,0x8d99ae,0xef233c]],['معبد الفراعنة',0xf2cc8f,0xc9a15b,[0x2a9d8f,0xe9c46a,0x264653]],['حديقة الألعاب',0x7bdff2,0x70c26b,[0xff595e,0xffca3a,0x1982c4]],['كهف الكريستال',0x10002b,0x3c096c,[0x9d4edd,0x4cc9f0,0xe0aaff]],['أعماق البحر',0x023e8a,0x0077b6,[0x00b4d8,0xff7096,0xffd166]],['مزرعة الحصاد',0x8ecae6,0x7cb518,[0xe63946,0xffb703,0x8d5524]],['شتاء الثلج',0x6c8ead,0xe8f1f8,[0x2a9d8f,0xe63946,0x1d3557]],['مستنقع السم',0x1a2e05,0x3b5d1e,[0xa3c93a,0x6a994e,0x7b2cbf]],['سماء الغيوم',0xa0d8ef,0xf1f7ff,[0xffffff,0xffd166,0x4cc9f0]],['سوق الليل',0x1b1034,0x3d2c5a,[0xffb703,0xe63946,0x2ec4b6]],['قلعة الأسطى سم',0x1a0003,0x3a0a12,[0xc1121f,0x6a040f,0xffb703]]];
const r2=(n,f)=>Array.from({length:n},(_,i)=>f(i));
const PT=[(r,A)=>r2(8,i=>[Math.cos(i*.785)*9,Math.sin(i*.785)*9]),(r,A)=>r2(10,()=>[(r()-.5)*2*(A-4),(r()-.5)*2*(A-4)]),
(r,A)=>r2(14,i=>[(i%2?6:-6),-12+Math.floor(i/2)*4]),(r,A)=>r2(12,i=>i<6?[(i-2.5)*4,0]:[0,(i-8.5)*4]),(r,A)=>r2(9,i=>[(i-4)*3.6,(i-4)*3.6]),
(r,A)=>r2(6,i=>[Math.cos(i*1.047)*6,Math.sin(i*1.047)*6]),(r,A)=>r2(9,i=>[(i%3-1)*9,(Math.floor(i/3)-1)*9]),(r,A)=>r2(12,i=>[Math.cos(i*.9)*(4+i),Math.sin(i*.9)*(4+i)]),
(r,A)=>r2(8,i=>[-14+i*4,(i%2?5:-5)]),(r,A)=>r2(8,i=>[(i%2?1:-1)*(10+(i>>2)*3),(i&2?1:-1)*(10+(i>>2)*3)]),(r,A)=>r2(10,i=>[(i-4.5)*2.6*(i<5?1:-1),-4-Math.abs(i-4.5)*2.4]),
(r,A)=>r2(12,i=>i<6?[Math.cos(i*1.047)*6.5,Math.sin(i*1.047)*6.5]:[Math.cos(i*1.047)*12.5,Math.sin(i*1.047)*12.5])];
const CT=['تطهير المنطقة','صمود','اجمع الطوب الذهبي','حشد سريع','زعماء مصغّرين','هجوم الحشود'];
let LG=null,OB=[],HZ=[],IT=[],lvS=null,curLv=1,AR_=19;
function clearLv(){if(LG){scene.remove(LG);LG=null}OB=[];HZ=[];IT=[];lvS=null}
function exitLv(){clearLv();scene.background.setHex(0x14213d);scene.fog.color.setHex(0x14213d);far.material.color.setHex(0x182036);ground.material.map=gt;ground.material.color.setHex(0xffffff);ground.material.needsUpdate=true;bm.color.setHex(0xffffff);for(const c of CR){c.on=1;c.m.visible=true}}
function buildLevel(n){clearLv();const ti=themeIdx(n),th=TH2[ti],pal=th[3],rn=rng(n*7919+13);AR_=10+(n%3);LG=new T.Group();scene.add(LG);
 scene.background.setHex(th[1]);scene.fog.color.setHex(th[1]);far.material.color.setHex(SHADE(th[1],.8));ground.material.map=GTX;ground.material.color.setHex(th[2]);ground.material.needsUpdate=true;bm.color.setHex(pal[0]);
 for(const c of CR){c.on=0;c.t=1e9;c.m.visible=false}
 const W=AR_+1.2;brk(LG,2*AR_+4,1.2,1.4,pal[0],0,0,-W);brk(LG,2*AR_+4,1.2,1.4,pal[0],0,0,W);brk(LG,1.4,1.2,2*AR_+4,pal[0],-W,0,0);brk(LG,1.4,1.2,2*AR_+4,pal[0],W,0,0);
 const kind=(ti+n)%5;for(const p of PT[(n-1)%12](rn,AR_)){if(Math.hypot(p[0],p[1])<4.5||Math.abs(p[0])>AR_-1.5||Math.abs(p[1])>AR_-1.5)continue;const[g,r]=prop(kind,pal,rn);g.position.set(p[0],0,p[1]);g.rotation.y=rn()*6;LG.add(g);OB.push({x:p[0],z:p[1],r,g,hp:2})}
 for(let i=0;i<12;i++){const a=i/12*6.283,[g]=prop((ti+2)%5,pal,rn);g.scale.setScalar(1.8);g.position.set(Math.cos(a)*(AR_+9),0,Math.sin(a)*(AR_+9));g.rotation.y=-a;LG.add(g)}
 const hz=n%3;for(let i=0;i<hz;i++){const x=(rn()-.5)*2*(AR_-5),z=(rn()-.5)*2*(AR_-5),r=2.4+rn();if(Math.hypot(x,z)<8)continue;const m=new T.Mesh(new T.CircleGeometry(r,24),new T.MeshBasicMaterial({color:th[4]?0xff4400:pal[1],transparent:true,opacity:.6}));m.rotation.x=-PI/2;m.position.set(x,.07,z);LG.add(m);HZ.push({x,z,r})}
 const ct=isBoss(n)?0:Math.floor(n/3)%6;lvS={n,ct,boss:isBoss(n),W:ct===1||ct===2?0:2+Math.min(3,n/50|0),w:0,T:35+Math.min(40,n/4|0),K:5+(n/20|0),got:0,sp:2,cd:1,done:0,ht:1};
 if(ct===2)for(let i=0;i<lvS.K;i++){let x,z,t=0;do{x=(rn()-.5)*2*(AR_-3);z=(rn()-.5)*2*(AR_-3);t++}while(t<20&&OB.some(o=>Math.hypot(o.x-x,o.z-z)<o.r+1.2));const m=new T.Mesh(G('CylinderGeometry',.5,.5,.35,12),G2);m.position.set(x,1,z);m.rotation.x=1.2;LG.add(m);IT.push(m)}
 wave=1+(n/20|0);curLv=n;$('wv').textContent=PARTS[partOf(n)].n+' · مرحلة '+n;banner(th[0]+' · '+n,lvS.boss?'معركة الزعيم · '+pName(n):CT[ct]+' · قوة: '+pName(n),pal[0]);}
function spawnK(boss,kind,fast){spawn(boss,kind);const e=enemies[enemies.length-1],k=1+lvS.n/70;e.hp=e.mhp=e.hp*k;if(fast)e.fast=true}
function lvWave(dt){const L=lvS;if(!L||L.done||L.ct===1||L.ct===2)return;L.cd-=dt;if(L.cd>0)return;if(L.w>=L.W)return lvEnd(true);
 L.w++;L.cd=1.5;H.hp=Math.min(100,H.hp+10);const n=L.n,c=(Math.min(3+L.w+(n/16|0),9))*(L.ct===5?2:1);$('wv').textContent='مرحلة '+n+' · موجة '+L.w+'/'+L.W;
 if(L.ct===4&&!L.boss){spawnK(true,(n+L.w)%5);spawnK(true,(n+L.w+2)%5);for(let i=0;i<3;i++)spawnK(false)}else for(let i=0;i<c;i++)spawnK(false,0,L.ct===3);
 if(L.boss&&L.w===L.W){const P=PARTS[partOf(n)];if(n===P.to)spawnK(true,P.fb);else spawnK(true,P.mb[(n/10|0)%P.mb.length])}}
function lvPost(dt){const L=lvS;if(!L||L.done||state!=='play')return;const p=H.g.position;
 const push=(q,rr)=>{for(const o of OB){const dx=q.x-o.x,dz=q.z-o.z,d=Math.hypot(dx,dz),m=o.r+rr;if(d<m&&d>0){q.x=o.x+dx/d*m;q.z=o.z+dz/d*m}}q.x=Math.max(-AR_,Math.min(AR_,q.x));q.z=Math.max(-AR_,Math.min(AR_,q.z))};
 push(p,.5);let al=0;for(const e of enemies)if(!e.dead){al++;push(e.g.position,.5)}
 L.ht-=dt;if(L.ht<=0){L.ht=1.2;for(const h of HZ)if(Math.hypot(p.x-h.x,p.z-h.z)<h.r&&H.y<.4){hurtHero(5+(L.n/40|0));spark(p.x,.5,p.z,0xff6a1a,5)}}
 if(L.ct===1){L.T-=dt;$('wv').textContent='مرحلة '+L.n+' · صمود '+Math.ceil(Math.max(0,L.T))+'ث';if(L.T<=0)return lvEnd(true);L.sp-=dt;if(L.sp<=0&&al<Math.min(5+(L.n/25|0),9)){L.sp=2.8;spawnK(false);if(L.n>60)spawnK(false)}}
 if(L.ct===2){$('wv').textContent='مرحلة '+L.n+' · طوب '+L.got+'/'+L.K;L.sp-=dt;if(L.sp<=0&&al<Math.min(3+(L.n/40|0),6)){L.sp=4;spawnK(false)}
  for(let i=IT.length-1;i>=0;i--){const m=IT[i];m.rotation.z+=dt*3;if(Math.hypot(m.position.x-p.x,m.position.z-p.z)<1.7){LG.remove(m);IT.splice(i,1);L.got++;sfx(900,.2,'sine');spark(p.x,1.5,p.z,0xffd34d,8)}}
  if(L.got>=L.K)return lvEnd(true)}}
function lvEnd(w){const L=lvS;if(!L||L.done)return;L.done=1;state='over';const n=L.n;let m='';
 if(w){const first=!SV.pw.includes(n);if(first){SV.pw.push(n);SV.eq=n}if(n>=SV.lv&&n<200)SV.lv=n+1;const g=10+(n/2|0)+(score/10|0);SV.coins+=g;m='+'+g+' 🪙'+(first?' · قوة جديدة: '+pName(n):'')+(n===200?' · خلّصت كل المراحل!':'');jingle()}
 else SV.coins+=score/20|0;save();$('ot').textContent=w?'كسبت المرحلة '+n+'!':'سقط النينجا!';$('fin').textContent=(w?m:'جمعت '+score+' نقطة. جرّب تاني!');$('nx').style.display=w&&n<200?'':'none';$('over').classList.add('show')}
/* ---- wrappers (keep original systems) ---- */
const _b=begin;begin=function(m){_b(m);$('lvm').classList.remove('show');$('shp').classList.remove('show');setSkin(0);pcd=0;if(m==='lv')buildLevel(curLv);else exitLv()};
const _f=finish;finish=function(w){if(mode==='lv')return lvEnd(w);_f(w);SV.coins+=score/20|0;save()};
const _st=step;step=function(dt){_st(dt);if(inp.w){inp.w=0;usePower()}if(mode==='lv')lvPost(dt)};
window.lvWave=lvWave;
/* ---- UI ---- */
const st_=document.createElement('style');st_.textContent=`.ov2{position:fixed;inset:0;z-index:30;background:rgba(8,12,28,.97);display:none;flex-direction:column;align-items:center;padding:calc(14px + env(safe-area-inset-top,0px)) 12px 24px;overflow-y:auto;touch-action:pan-y;-webkit-overflow-scrolling:touch}.ov2.show{display:flex}.ov2 h2{font-family:Lalezar;font-weight:400;margin:4px 0;color:var(--gold);font-size:30px}.lg{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;width:min(420px,96vw);margin:8px 0}.lg button,.sb{font-family:Lalezar;font-size:20px;padding:8px 0;border-radius:10px;border:2px solid #fff4;background:#d62828;color:#fff}.lg button[disabled]{background:#333;opacity:.5}.lg button.d{background:#2fbf4a}.sk{display:flex;align-items:center;gap:8px;width:min(420px,96vw);background:var(--panel);border:2px solid #fff3;border-radius:12px;padding:6px 10px;margin:4px 0}.sk b{flex:1;font-family:Lalezar;font-weight:400;font-size:18px}.sk i{width:16px;height:16px;border-radius:4px;border:2px solid #000a}.sk.on{border-color:var(--gold)}.sb{padding:6px 12px;font-size:16px;background:var(--gold);color:#222}.sb[disabled]{opacity:.45}.tabs{display:flex;gap:8px;margin:6px 0}#bw{right:110px;bottom:calc(190px + env(safe-area-inset-bottom,0px));width:66px;height:66px;font-size:26px;background:#7c4dff}`;document.head.appendChild(st_);
const mk=(h,id)=>{const d=document.createElement('div');d.className='ov2';d.id=id;d.innerHTML=h;document.body.appendChild(d);return d};
mk('<h2>المراحل</h2><div id="lvh"></div><div class="lg" id="lvg"></div><button class="go alt" id="lvb">رجوع</button>','lvm');
mk('<h2>المتجر</h2><div id="shh"></div><div class="tabs"><button class="sb" id="t1">Skins</button><button class="sb" id="t2">القوى</button></div><div id="shl"></div><button class="go alt" id="shb">رجوع</button>','shp');
const bw=document.createElement('div');bw.className='btn';bw.id='bw';bw.textContent='✨';$('ctl').appendChild(bw);press('bw','w');
addEventListener('keydown',e=>{if(e.key.toLowerCase()==='e')inp.w=1});
const mn=$('pStory').parentNode,mkb=(t,f)=>{const b=document.createElement('button');b.className='go alt';b.textContent=t;b.onclick=f;mn.insertBefore(b,$('pSet'))};
mkb('🧱 المراحل (200)',()=>{rLv();$('lvm').classList.add('show')});mkb('🛒 المتجر والـSkins',()=>{rShop(1);$('shp').classList.add('show')});
function rLv(){$('lvh').textContent='🪙 '+SV.coins+' · القوى: '+SV.pw.length+'/200';const g=$('lvg');g.innerHTML='';for(let n=1;n<=200;n++){const b=document.createElement('button'),ok=n<=SV.lv;b.textContent=ok?n:'🔒';b.disabled=!ok;if(SV.pw.includes(n))b.className='d';b.onclick=()=>{curLv=n;$('lvm').classList.remove('show');$('start').classList.remove('show');begin('lv')};g.appendChild(b)}}
let tab=1;function rShop(t){tab=t||tab;$('shh').textContent='🪙 '+SV.coins;const l=$('shl');l.innerHTML='';
 if(tab===1)SKS.forEach((s,i)=>{const d=document.createElement('div');d.className='sk'+(SV.cur===i?' on':'');d.innerHTML=[s.suit,s.pants,s.band].map(c=>'<i style="background:#'+c.toString(16).padStart(6,'0')+'"></i>').join('')+'<b>'+s.n+'</b>';const b=document.createElement('button');b.className='sb';
  if(own(i)){b.textContent=SV.cur===i?'مجهّز':'تجهيز';b.disabled=SV.cur===i;b.onclick=()=>{SV.cur=i;if(!SV.sk.includes(i))SV.sk.push(i);save();setSkin(0);rShop()}}
  else{b.textContent='🪙'+s.p+(s.l?' / مرحلة '+s.l:'');b.disabled=SV.coins<s.p;b.onclick=()=>{SV.coins-=s.p;SV.sk.push(i);SV.cur=i;save();setSkin(0);rShop()}}d.appendChild(b);l.appendChild(d)});
 else if(!SV.pw.length)l.textContent='اكسب مراحل لتحصل على قوى!';else SV.pw.slice().sort((a,b)=>a-b).forEach(n=>{const d=document.createElement('div');d.className='sk'+(SV.eq===n?' on':'');d.innerHTML='<b>'+pName(n)+'</b>';const b=document.createElement('button');b.className='sb';b.textContent=SV.eq===n?'مجهّزة':'تجهيز';b.disabled=SV.eq===n;b.onclick=()=>{SV.eq=n;save();rShop()};d.appendChild(b);l.appendChild(d)})}
$('t1').onclick=()=>rShop(1);$('t2').onclick=()=>rShop(2);$('lvb').onclick=()=>$('lvm').classList.remove('show');$('shb').onclick=()=>$('shp').classList.remove('show');
const nx=document.createElement('button');nx.className='go';nx.id='nx';nx.textContent='المرحلة التالية';nx.onclick=()=>{curLv=Math.min(200,curLv+1);$('over').classList.remove('show');begin('lv')};$('toMenu').parentNode.insertBefore(nx,$('toMenu'));
const lb=document.createElement('button');lb.className='go alt';lb.textContent='المراحل';lb.onclick=()=>{rLv();$('lvm').classList.add('show')};$('toMenu').parentNode.insertBefore(lb,$('toMenu'));
setInterval(()=>{if(state==='play')pcd=Math.max(0,pcd-.1);bw.style.opacity=pcd<=0?1:.4;bw.textContent=pcd>0?Math.ceil(pcd):'✨'},100);

/* ===== v4: NINJAGO heroes / elements / dragons / upgrades / story / camera (additive) ===== */
SV.up=SV.up||{atk:0,hp:0,sk:0};SV.dr=SV.dr||[];SV.ch=SV.ch||0;SV.el2=SV.el2||0;SV.dg=SV.dg||0;
const NB=SKS.length,NIN=[['لويد',0x1f9a3a,0x1f9a3a,0xd8a82c,0x0f3d1c],['كاي',0xd8231f,0xd8231f,0xd8a82c,0x5a0f0f],['جاي',0x1c55d8,0x1c55d8,0xd8a82c,0x0b1f4a],['زين',0xf2f2f2,0xf2f2f2,0xe8b923,0xaaaaaa],['كول',0x18181c,0x18181c,0xd8a82c,0x33333a]];
NIN.forEach((a,i)=>SKS.push({...mkS(a,i),p:0,l:0,n:a[0]+' · NINJAGO',strap:a[4],armor:a[3],emblem:a[3]}));
for(let i=0;i<5;i++)if(!SV.sk.includes(NB+i))SV.sk.push(NB+i);
if(!SV.v4){SV.v4=1;SV.cur=NB+SV.ch;save()}
try{[['سكيلز الأفعى',0x2e8b3a],['بايثور',0x8e44ad],['سامكاي الهيكل',0xe8e4d0],['نوكل',0xb8b09a],['لورد جارمادون',0x2b2b3a]].forEach((a,i)=>{BK[i].n=a[0];BK[i].c=a[1]});PAL.splice(0,4,0x3fa34d,0xe8e4d0,0x7a3fa0,0xc9a227)}catch(e){}
const _he=hurtEnemy;hurtEnemy=function(e,d,...a){return _he(e,d*(1+SV.up.atk*.12),...a)};
const _hh=hurtHero;hurtHero=function(d){return _hh(d*(1-Math.min(.5,SV.up.hp*.05)))};
/* elements + fusion */
const EL=[5,1,2,3,4],ELN=['','نار 🔥','برق ⚡','جليد ❄️','أرض ⛰️','طاقة 🌿'];let cx=0,cg=0;
const elCast=k=>{const o=curSk;curSk=k;try{skill()}finally{curSk=o}};
const aoe=(r,d,kb)=>{const p=H.g.position;enemies.forEach(e=>{if(!e.dead&&Math.hypot(e.g.position.x-p.x,e.g.position.z-p.z)<r)hurtEnemy(e,d,0,0,kb)})};
function ability(){if(state!=='play'||cx>0)return;const el=EL[SV.ch],s2=SV.el2||curSk,p=H.g.position,k=1+SV.up.sk*.2;cx=Math.max(2.5,7-SV.up.sk*.45);
 elCast(el);if(el===5)aoe(9,30*k,8);ring(p.x,p.z,EC[el]);shake=Math.max(shake,.4);sfx(260,.3,'sawtooth');
 if(s2&&s2!==el){elCast(s2);ring(p.x,p.z,EC[s2]);aoe(10,28*k,6);banner('🔀 دمج '+ELN[el]+' + '+ELN[s2],'',EC[s2])}else banner(ELN[el],NIN[SV.ch][0],EC[el])}
/* element dragons */
function dragon(){const e=(curSk>0&&curSk<6)?curSk:SV.dg;if(state!=='play'||cg>0||!e||(e!==curSk&&!SV.dr.includes(e)))return;cg=Math.max(8,16-SV.up.sk);
 const p=H.g.position,dx=Math.sin(H.rot),dz=Math.cos(H.rot),col=e===5?0xffd23f:EC[e],g=new T.Group(),mt=new T.MeshLambertMaterial({color:col,emissive:col,emissiveIntensity:.55});
 for(let i=0;i<8;i++){const m=new T.Mesh(G('SphereGeometry',1,10,8),mt);m.scale.setScalar(i?1.05-i*.09:1.35);m.position.z=-i*1.25;g.add(m)}
 [-1,1].forEach(x=>{const h=new T.Mesh(G('ConeGeometry',.3,1.4,6),mt);h.position.set(x*.7,.9,.2);g.add(h);const w=new T.Mesh(G('BoxGeometry',2.6,.1,1.4),mt);w.position.set(x*1.9,.4,-2.5);g.add(w)});
 g.rotation.y=H.rot;g.position.set(p.x,1.8,p.z);scene.add(g);banner('🐉 تنين '+(e===5?'الذهبي ✨':ELN[e]),'',col);sfx(120,.6,'sawtooth');shake=Math.max(shake,.5);
 let t=0;const hit=new Set(),k=1+SV.up.sk*.2;
 fx.push(dt=>{t+=dt;g.position.x+=dx*24*dt;g.position.z+=dz*24*dt;g.position.y=1.8+Math.sin(t*12)*.3;
  for(const n of enemies){if(n.dead||hit.has(n))continue;if(Math.hypot(n.g.position.x-g.position.x,n.g.position.z-g.position.z)<3.4){hit.add(n);hurtEnemy(n,(e===4?75:55)*k,dx,dz,e===4?24:10);spark(n.g.position.x,1.6,n.g.position.z,col,8);if(e===3)n.stun=2.5;if(e===2)bolt(n.g.position.x,n.g.position.z,col);if(e===5)H.hp=Math.min(100,H.hp+8)}}
  if(t>1.2){scene.remove(g);return true}})}
/* shop tabs: upgrades / dragons / heroes */
const _rs=rShop;rShop=function(t){t=t||tab;if(t<3)return _rs(t);tab=t;$('shh').textContent='🪙 '+SV.coins;const l=$('shl');l.innerHTML='';
 const row=(h,bt,fn,dis,on)=>{const d=document.createElement('div');d.className='sk'+(on?' on':'');d.innerHTML=h;const b=document.createElement('button');b.className='sb';b.textContent=bt;b.disabled=!!dis;b.onclick=fn;d.appendChild(b);l.appendChild(d)};
 if(t===3)[['atk','⚔️ قوة الضرب'],['hp','🛡️ الدرع'],['sk','✨ المهارات والتنانين']].forEach(([k,n])=>{const v=SV.up[k],c=40+v*35;row('<b>'+n+' · '+v+'/10</b>',v>=10?'أقصى':'🪙'+c,()=>{SV.coins-=c;SV.up[k]++;save();rShop()},v>=10||SV.coins<c)});
 else if(t===4)[1,2,3,4,5].forEach(k=>{const o=SV.dr.includes(k);row('<b>🐉 تنين '+ELN[k]+'</b>',o?(SV.dg===k?'مجهّز':'تجهيز'):'🪙250',()=>{if(!o)SV.coins-=250;if(!o)SV.dr.push(k);SV.dg=k;save();rShop()},o?SV.dg===k:SV.coins<250,SV.dg===k)});
 else{NIN.forEach((a,i)=>row([a[1],a[2],a[3]].map(c=>'<i style="background:#'+c.toString(16).padStart(6,'0')+'"></i>').join('')+'<b>'+a[0]+' — '+ELN[EL[i]]+'</b>',SV.ch===i?'مختار':'اختيار',()=>{SV.ch=i;SV.cur=NB+i;save();setSkin(0);rShop()},SV.ch===i,SV.ch===i));
  [0,1,2,3,4,5].forEach(k=>row('<b>🔀 دمج مع: '+(k?ELN[k]:'بدون')+'</b>',SV.el2===k?'مفعّل':'تفعيل',()=>{SV.el2=k;save();rShop()},SV.el2===k,SV.el2===k))}};
{const tb=document.querySelector('#shp .tabs');[['t5','الأبطال',5],['t3','ترقيات',3],['t4','🐉 تنانين',4]].forEach(([id,x,n])=>{const b=document.createElement('button');b.className='sb';b.id=id;b.textContent=x;b.onclick=()=>rShop(n);tb.appendChild(b)})}
mkb('🥷 الأبطال والتنانين',()=>{rShop(5);$('shp').classList.add('show')});
/* buttons, keys, camera, landscape */
const mkB=(id,x,fn)=>{const b=document.createElement('div');b.className='btn';b.id=id;b.textContent=x;$('ctl').appendChild(b);b.addEventListener('pointerdown',e=>{e.preventDefault();fn()});return b};
const bX=mkB('bx','عنصر',ability),bG=mkB('bg','🐉',()=>dragon());
let ci=0;const CZ=[1,.82,1.22],CN=['عادية','قريبة','واسعة'];mkB('bc','📷',()=>{ci=(ci+1)%3;banner('📷 كاميرا','سينمائية: '+CN[ci],0xffffff)});
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k==='q')ability();if(k==='r')dragon();if(k==='c')$('bc').dispatchEvent(new Event('pointerdown'))});
setInterval(()=>{if(state==='play'){cx=Math.max(0,cx-.1);cg=Math.max(0,cg-.1)}bX.textContent=cx>0?Math.ceil(cx):'عنصر';bG.style.opacity=((curSk>0&&curSk<6)||(SV.dg&&SV.dr.includes(SV.dg)))&&cg<=0?1:.4;bG.textContent=cg>0?Math.ceil(cg):'🐉';
 const f=(innerWidth<innerHeight?72:55)*CZ[ci];if(Math.abs(cam.fov-f)>.05){cam.fov+=(f-cam.fov)*.4;cam.updateProjectionMatrix()}},100);
if(matchMedia('(pointer:coarse)').matches)addEventListener('pointerdown',()=>{try{const d=document.documentElement;(d.requestFullscreen?d.requestFullscreen():Promise.resolve()).then(()=>screen.orientation.lock(window.ORIL?ORIL():'any')).catch(()=>{})}catch(e){}},{once:true});
/* ===== v5: Parts/Seasons, portrait maps, NINJAGO story, menu, audio ===== */
const TH2=[['ساحة الدوجو',0xd9a05b,0xb98b5a,[0xc0392b,0xe67e22,0x3d2b1f]],['ممرّ الدير',0x3b2a1a,0x7a5230,[0x8d5524,0xc0392b,0xf4a261]],['شوارع نينجاغو',0x8ecae6,0x6b7280,[0xe63946,0x3a86ff,0xffd166]],['كهوف الهياكل',0x120a18,0x2b2338,[0xe8e4d0,0x9d4edd,0x6a994e]],
['مقابر الأفاعي',0x1a2e05,0x3b5d1e,[0xa3c93a,0x6a994e,0x7b2cbf]],['صحراء الأنياب',0xe9c46a,0xd4a259,[0xe76f51,0xf4a261,0x8d5524]],['غابة الفينوماري',0x1b4332,0x2d6a4f,[0x95d5b2,0x52b788,0x7b2cbf]],['كهف الهيبنوبراي',0x10002b,0x3c096c,[0x9d4edd,0x4cc9f0,0xe0aaff]],
['جزيرة الظلام',0x23123a,0x4a3a5a,[0x6a040f,0x9d4edd,0xffb703]],['قلعة جارمادون',0x1a0003,0x3a0a12,[0xc1121f,0x6a040f,0xffb703],1],['معبد التنين',0x0b3a5b,0xc9a15b,[0xffb703,0x2a9d8f,0xc0392b]],['بركان التنين',0x2b0a0a,0x5a1a10,[0xff6a1a,0xffb703,0x555555],1],
['برج بورغ',0x0a0a2a,0x1d1d44,[0xff00aa,0x00e5ff,0xffee00]],['مصنع النيندرويد',0x2b2d31,0x474b52,[0xfca311,0x8d99ae,0xef233c]],['المدينة الرقمية',0x050514,0x2a2a4a,[0x00e5ff,0x9d4edd,0xf72585]],['عالم الأوفرلورد',0x0d001a,0x1b0b33,[0x7b2cbf,0x00e5ff,0xff3d81]],
['ساحة البطولة',0x7bdff2,0xd4a259,[0xff595e,0xffca3a,0x1982c4]],['جزيرة تشين',0x8ecae6,0x7cb518,[0xe63946,0xffb703,0x8d5524]],['قمم الجليد',0x9bd4f5,0xdff3ff,[0xa8dadc,0x457b9d,0xffffff]],['قصر الأناكوندراي',0x1a1030,0x3d2c5a,[0xc9a227,0x7b2cbf,0xe63946]],
['ضباب الأشباح',0x1d3b3a,0x2f5d5a,[0x7bf5df,0x5ac8ff,0xe0fffa]],['مقبرة مورو',0x0a1a1a,0x1e3a38,[0x2fd6b5,0x7b6cf6,0xe8e4d0]],['العالم الملعون',0x1a0a2e,0x3a1f5a,[0xd062ff,0x2fd6b5,0xffd166]],['سماء العواصف',0x3d4f6b,0x6b7a90,[0xffffff,0xffd166,0x5ac8ff]]];
BK.length=0;BK.push({n:'نوكل',s:1.5,c:0xb8b09a,hp:170,sp:.75,dm:16},{n:'سكيلز',s:1.6,c:0x2e8b3a,hp:190,sp:.8,dm:18},{n:'لورد جارمادون',s:1.9,c:0x2b2b3a,hp:260,sp:.6,dm:24},{n:'نيندرويد القائد',s:1.5,c:0x8d99ae,hp:200,sp:1.2,dm:16,tp:1},{n:'قائد الأناكوندراي',s:1.6,c:0x7b2cbf,hp:230,sp:.85,dm:18,sm:1},
{n:'سامكاي',s:2.1,c:0xe8e4d0,hp:300,sp:.8,dm:22},{n:'بايثور',s:2,c:0x7b2cbf,hp:340,sp:.85,dm:22,tp:1,sm:1},{n:'الثعبان الأعظم',s:2.6,c:0x2e8b3a,hp:420,sp:.55,dm:28},{n:'الأوفرلورد',s:2.3,c:0x2a0a4a,hp:480,sp:.8,dm:26,tp:1,sm:1},{n:'المعلم تشين',s:2.1,c:0xc9a227,hp:520,sp:.9,dm:26,sm:1},{n:'مورو',s:2,c:0x2fd6b5,hp:560,sp:1,dm:26,tp:1,sm:1});
const PARTS=[
{n:'الطيار',s:'درب النينجا',e:'🥋',f:1,to:20,th:[0,1,2,3],pal:[0xe8e4d0,0x9a9a8a,0x6a6a7a,0xb8b09a],sk:0xeeeae0,mb:[0],fb:5,col:'#8a4b08',sh:['كراك!','العظام لا تموت!','سامكاي يأمر!'],
 intro:[['🏯','<b>وو:</b> «أربعة أسلحة ذهبية على قمم أربعة جبال. من يجمعها يحكم نينجاغو.»'],['💀','<b>سامكاي:</b> «جيش الهياكل، تقدّموا! الأسلحة لي!»<br><b>كاي:</b> «ليس وأنا حيًّا!»']],
 mid:[['🛡️','<b>كول:</b> «الهياكل في كل مكان!»<br><b>جاي:</b> «ثقوا بالسبينجيتسو!»']],fin:[['👑','<b>سامكاي:</b> «أنا ملك العالم السفلي!»<br><b>زين:</b> «ليس اليوم.»']],outro:[['🏆','سقط سامكاي وبقيت الأسلحة بأمان.<br><b>وو:</b> «هذه البداية فقط.»']]},
{n:'الموسم 1',s:'صعود الأفاعي',e:'🐍',f:21,to:50,th:[4,5,6,7],pal:[0x3fa34d,0x7a3fa0,0x2e8b57,0xc9a227],sk:0x7bc96f,mb:[1,0],fb:6,col:'#1b5e20',sh:['ششش!','قبيلة الأنياب!','سمٌّ قاتل!'],
 intro:[['🐍','قبور الأفاعي تنفتح… قبائل السيربنتاين تستيقظ بعد ألف عام.'],['🥷','<b>لويد:</b> «أعرف أين يختبئون!»<br><b>كول:</b> «حسنًا يا صغير، قُد الطريق.»']],
 mid:[['🌵','<b>جاي:</b> «سمعت فحيحًا خلفي!»<br><b>كاي:</b> «هذا أنا أتنفس بقوة!»']],fin:[['🐍','<b>بايثور:</b> «سأوقظ الثعبان الأعظم!»<br><b>كاي:</b> «أوقفوه!»']],outro:[['🛡️','هُزم بايثور، لكن الأرض ما زالت تهتز…']]},
{n:'الموسم 2',s:'إرث النينجا الأخضر',e:'🐉',f:51,to:85,th:[8,9,10,11],pal:[0x7b2cbf,0x3fa34d,0xc9a227,0x2b2b3a],sk:0x7bc96f,mb:[2,1],fb:7,col:'#4a148c',sh:['باسم جارمادون!','الظلام يقترب!','فحيح!'],
 intro:[['🌑','<b>وو:</b> «النبوءة تقول إن النينجا الأخضر سيهزم الظلام.»'],['🥷','<b>لويد:</b> «أنا؟!»<br><b>وو:</b> «أنت.»']],
 mid:[['⚔️','<b>لورد جارمادون:</b> «انضم إليّ يا ابني!»<br><b>لويد:</b> «أبدًا!»']],fin:[['🐍','الثعبان الأعظم يلتهم كل شيء!<br><b>لويد:</b> «حان وقت قوتي!»']],outro:[['🐉','لويد يهزمه بقوة النينجا الأخضر. ينتصر الأمل.']]},
{n:'الموسم 3',s:'إعادة التشغيل',e:'🤖',f:86,to:120,th:[12,13,14,15],pal:[0x8d99ae,0xe07a1f,0x4a5568,0xb0bec5],sk:0xb0bec5,mb:[3,2],fb:8,col:'#0d47a1',sh:['تم رصد الهدف!','تحديث… حذف!','نيندرويد!'],
 intro:[['🤖','جيش النيندرويد يغزو المدينة بقيادة قوة غامضة.'],['⚙️','<b>زين:</b> «ذاكرتي تحمل أسرارًا… لنكتشفها معًا.»']],
 mid:[['💥','<b>كاي:</b> «مصنعهم بلا نهاية!»<br><b>جاي:</b> «ندمّره بالبرق!»']],fin:[['👁️','<b>الأوفرلورد:</b> «سأعيد تشغيل نينجاغو!»<br><b>زين:</b> «سأوقفك مهما كلّف الأمر.»']],outro:[['✨','انهار عالم الأوفرلورد الرقمي. عاد السلام… لحين.']]},
{n:'الموسم 4',s:'بطولة العناصر',e:'🏆',f:121,to:160,th:[16,17,18,19],pal:[0xc9a227,0x7b2cbf,0x2a9d8f,0xd62828],sk:0xe3a72f,mb:[4,3],fb:9,col:'#e65100',sh:['البطولة لي!','أنا الأقوى!','تشين يراقبكم!'],
 intro:[['🏆','<b>المعلم تشين:</b> «بطولة العناصر! الفائز ينال القوة المطلقة.»'],['🔥','<b>كاي:</b> «هذه فرصتنا!»<br><b>كول:</b> «أو فخّ…»']],
 mid:[['🧊','<b>زين:</b> «القمم متجمدة والخصوم يتزايدون.»<br><b>جاي:</b> «ومعي شحنة برق إضافية!»']],fin:[['🐍','<b>تشين:</b> «الجميع في قبضتي!»<br><b>لويد:</b> «معًا نقدر على كل شيء.»']],outro:[['🏅','انتهت البطولة وسقطت خدعة تشين. النينجا أحرار.']]},
{n:'الموسم 5',s:'الاستحواذ',e:'👻',f:161,to:200,th:[20,21,22,23],pal:[0x2fd6b5,0x5ac8ff,0x7b6cf6,0xa0f0e0],sk:0xbff6ee,mb:[4,2],fb:10,col:'#004d40',sh:['أووووه…','الأرواح تعود!','استحواذ!'],
 intro:[['👻','أرواح قديمة تتسلل إلى الأحياء وتستحوذ على أجسادهم.'],['🥷','<b>لويد:</b> «احذروا! الروح تتحدث من داخل وو!»']],
 mid:[['🌫️','<b>كاي:</b> «الضباب يخفيهم!»<br><b>زين:</b> «أحسّ بوجودهم من هنا.»']],fin:[['🌀','<b>مورو:</b> «أنا سيد الرياح والأرواح!»<br><b>لويد:</b> «وأنا من سيوقفك.»']],outro:[['🌅','حُرّر وو وانتهت الحرب. نينجاغو آمنة، والمغامرة مستمرة!']]}];
const partOf=n=>{for(let i=0;i<6;i++)if(n<=PARTS[i].to)return i;return 5},isBoss=n=>n%5===0||n===PARTS[partOf(n)].to,themeIdx=n=>{const P=PARTS[partOf(n)];return P.th[(n-P.f)%4]};
/* NINJAGO pagoda prop (red pillars + tiled roof) */
const _pr=prop;prop=function(k,pal,rn){if(k!==4)return _pr(k,pal,rn);const g=new T.Group();brk(g,2.8,.4,2.8,0x8a8f98,0,0,0);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([x,z])=>brk(g,.32,2.2,.32,0xc0392b,x*1.05,.4,z*1.05));brk(g,3.4,.35,3.4,0x2d3436,0,2.6,0);brk(g,2.4,.35,2.4,0xc0392b,0,2.95,0);brk(g,3,.3,3,0x2d3436,0,3.3,0);brk(g,.4,.5,.4,0xffc933,0,3.6,0);return[g,1.6]};
/* enemies follow the current season; spawn inside the small arena */
const PAL0=[0x6d597a,0xb56576,0x355070,0x588157];
const BKK=['skel','hyp','con','nind','ven','skel','con','hyp','nind','ven','ghost'],PK=[['skel'],['hyp','fang','con','ven'],['hyp','con','fang','ven'],['nind'],['con','ven','fang'],['ghost']];
const _spw=spawn;spawn=function(b,k){const lv=mode==='lv',P=lv?partOf(curLv):-1,K=b?BK[k||0]:null;EK={k:b?BKK[k||0]:rp(P<0?['skel','hyp','con','nind','fang','ven']:PK[P]),tint:b?K.c:null};const ek=EK;try{_spw(b,k)}finally{EK=null}const e=enemies[enemies.length-1];if(e)e.kind=ek.k;if(e&&lv){const a=Math.random()*6.283,r=AR_*.9;e.g.position.set(Math.cos(a)*r,0,Math.sin(a)*r)}};
const _le=lvEnd;lvEnd=function(w){const L=lvS,was=L&&L.done,n=L&&L.n;_le(w);if(w&&L&&!was&&n===PARTS[partOf(n)].to){const P=PARTS[partOf(n)];setTimeout(()=>comic(P.outro.map(x=>[x[0],x[1],P.col]),()=>{state='over'}),900)}};
const _b5=begin;begin=function(m){_b5(m);cx=cg=0;PAL.splice(0,4,...(m==='lv'?PARTS[partOf(curLv)].pal:PAL0));if(m!=='lv')return;const P=PARTS[partOf(curLv)];let ps=null;if(curLv===P.f)ps=P.intro;else if(curLv===P.f+((P.to-P.f)>>1))ps=P.mid;else if(curLv===P.to)ps=P.fin;if(ps)comic(ps.map(x=>[x[0],x[1],P.col]),()=>{})};
/* parts screen (seasons) with progressive unlock */
let selPart=0;
rLv=function(){let pc=$('pts');if(!pc){pc=document.createElement('div');pc.id='pts';$('lvm').insertBefore(pc,$('lvh'))}pc.innerHTML='';
 PARTS.forEach((P,i)=>{const ok=SV.lv>=P.f,b=document.createElement('button');b.className='pc'+(i===selPart?' on':'')+(ok?'':' lk');b.innerHTML='<span>'+(ok?P.e:'🔒')+'</span><b>'+P.n+'</b><small>'+P.s+'</small>';b.disabled=!ok;b.onclick=()=>{selPart=i;rLv()};pc.appendChild(b)});
 const P=PARTS[selPart];$('lvh').textContent='🪙 '+SV.coins+' · '+P.n+': '+P.s;const g=$('lvg');g.innerHTML='';
 for(let n=P.f;n<=P.to;n++){const ok=n<=SV.lv,b=document.createElement('button');b.textContent=ok?(n===P.to?'👑':n):'🔒';b.disabled=!ok;if(SV.pw.includes(n))b.className='d';b.onclick=()=>{curLv=n;$('lvm').classList.remove('show');$('start').classList.remove('show');begin('lv')};g.appendChild(b)}};
const openParts=()=>{selPart=partOf(SV.lv);rLv();$('lvm').classList.add('show')};$('pStory').onclick=openParts;
/* main menu */
{const mn2=$('pStory').parentNode;[...mn2.children].forEach(b=>{if(!['pStory','pArc','pSet'].includes(b.id))b.remove()});
 $('pStory').textContent='▶ المغامرة';$('pArc').textContent='♾️ لعب حر';$('pSet').textContent='⚙️ الإعدادات';
 mkb('🥷 الأبطال والمتجر',()=>{rShop(5);$('shp').classList.add('show')});mn2.appendChild($('pArc'));mn2.appendChild($('pSet'));
 const st=$('start');for(let i=0;i<12;i++){const d=document.createElement('i');d.className='bk';d.style.cssText='left:'+(Math.random()*95)+'%;background:'+['#e63946','#ffb703','#3a86ff','#2fbf4a','#fff'][i%5]+';animation-duration:'+(8+Math.random()*10)+'s;animation-delay:-'+(Math.random()*10)+'s';st.prepend(d)}}
setInterval(()=>{const m=$('mchips');if(m)m.textContent='🪙 '+SV.coins+' · 🧱 '+(SV.gb||0)+' · '+PARTS[partOf(SV.lv)].n+' · مرحلة '+SV.lv+'/200'},700);
/* audio: varied voice lines (no repeated catchphrases) + layered sfx */
const rp=a=>a[Math.random()*a.length|0],HL=['هيّا!','سبينجيتسو!','خذ هذه!','بقوة العنصر!','لن تمرّوا!','للتنين!'],DL=['آخ!','انتهيت!','ما هذا؟!','لااا!'];
const _sy=say;say=function(e,t,p){if(t===HERO_LINE){if(Math.random()<.6)return;t=rp(HL)}else if(t===ENEMY_LINE){if(Math.random()<.5)return;t=rp(PARTS[mode==='lv'?partOf(curLv):0].sh)}else if(t==='آخ يا ضهري!')t=rp(DL);_sy(e,t,p)};
sfx=function(f,d,type){if(!ac||!S.snd)return;const t=ac.currentTime,o=ac.createOscillator(),g=ac.createGain(),fl=ac.createBiquadFilter();fl.type='lowpass';fl.frequency.value=Math.min(6000,f*8+600);o.type=type||'square';o.frequency.setValueAtTime(f,t);o.frequency.exponentialRampToValueAtTime(Math.max(30,f*.35),t+d);g.gain.setValueAtTime(.16,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(fl);fl.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+d);
 if(f<400){const n=ac.createBufferSource(),b=ac.createBuffer(1,Math.max(1,ac.sampleRate*d|0),ac.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=(Math.random()*2-1)*(1-i/a.length);n.buffer=b;const ng=ac.createGain();ng.gain.value=.12;n.connect(ng);ng.connect(ac.destination);n.start(t)}};
/* ===== v6: original NINJAGO story, reference-accurate heroes & enemies ===== */
const ST=(i,a,b,c,d)=>Object.assign(PARTS[i],{intro:a,mid:b,fin:c,outro:d});
ST(0,[['🏯','في دوجو قديم يحرس <b>السنسي وو</b> أربعة أسلحة ذهبية: منجل الزلازل، نانشاكو البرق، شوريكن الجليد وسيف النار.'],['🥷','<b>وو:</b> «يا كاي وجاي وزين وكول، دوركم أن تحموها بالسبينجيتسو!»']],[['💀','<b>كول:</b> «جيش الهياكل (Skulkin) يزحف نحو الجبال!»<br><b>كاي:</b> «لن يلمسوا الأسلحة!»']],[['👑','<b>سامكاي:</b> «ملك الهياكل هنا! الأسلحة لي ولسيدي جارمادون!»'],['⚡','<b>جاي:</b> «معًا يا فريق!»<br><b>زين:</b> «سبينجيتسو!»']],[['🏆','هُزم سامكاي. لكن <b>وو</b> يعلم أن أخاه الشرير <b>جارمادون</b> لن يتوقف.']]);
ST(1,[['🐍','<b>لويد</b> ابن جارمادون يفتح مقابر الأفاعي بالخطأ… فتستيقظ قبائل <b>السيربنتاين</b>: هيبنوبراي، فانغبايري، فينوماري، كونستريكتاي وأناكوندراي.'],['🥷','<b>وو:</b> «أوقفوا الأفاعي قبل أن يوقظ بايثور الثعبان الأعظم!»']],[['🌵','<b>جاي:</b> «الأنياب في كل مكان!»<br><b>كول:</b> «احذروا السم والتنويم!»']],[['🐍','<b>بايثور:</b> «أنا آخر الأناكوندراي. سيأكل الثعبان الأعظم كل نينجاغو!»'],['🔥','<b>كاي:</b> «ليس قبل أن نمرّ من فوقك!»']],[['🛡️','أُحبطت خطة بايثور، لكن أسرار <b>لويد</b> وأبيه لم تنكشف بعد.']]);
ST(2,[['🌑','<b>وو:</b> «النبوءة تقول إن <b>النينجا الأخضر</b> سيهزم الظلام. إنه لويد!»'],['⚔️','<b>لويد:</b> «لكن أبي هو الشرير…»<br><b>وو:</b> «ولهذا أنت وحدك القادر.»']],[['🌋','<b>لورد جارمادون:</b> «تعال إلى الظلام يا بني!»<br><b>لويد:</b> «لن أصبح مثلك!»']],[['🐍','<b>الثعبان الأعظم</b> ينهض ويلتهم الأرض!'],['🐉','<b>لويد:</b> «حان وقت قوة النينجا الأخضر!»']],[['🐉','هُزم الظلام وصار لويد البطل الذي تنبّأت به النبوءة.']]);
ST(3,[['🤖','<b>سايروس بورغ</b> يفتتح برجه الضخم، ثم يهاجم جيش <b>النيندرويد</b> المدينة!'],['⚙️','<b>زين:</b> «ذاكرتي تحمل أسرارًا عن صنعي… سأكتشفها.»']],[['💥','<b>كاي:</b> «مصنعهم لا ينتهي!»<br><b>جاي:</b> «سندمّره بالبرق!»']],[['👁️','<b>الأوفرلورد:</b> «سأعيد تشغيل نينجاغو كلها!»'],['✨','<b>زين:</b> «لن أسمح بذلك… مهما كلّفني.»']],[['🌅','انهار عالم الأوفرلورد الرقمي وعاد السلام لنينجاغو.']]);
ST(4,[['🏆','<b>المعلم تشين</b> يدعو أساتذة العناصر إلى بطولة على جزيرته. الجائزة: قوة لا حدود لها.'],['🔥','<b>كاي:</b> «هذه فرصتنا!»<br><b>كول:</b> «أو فخّ…»']],[['🧊','<b>زين:</b> «القمم تتجمد والخصوم يزدادون!»<br><b>جاي:</b> «وأنا مستعد بشحنة برق!»']],[['🐍','<b>تشين:</b> «أنا من الأناكوندراي! قوتكم كلها لي!»'],['🌟','<b>لويد:</b> «معًا نقدر على كل شيء.»']],[['🏅','سقطت خدعة تشين وتحرر الأسياد.']]);
ST(5,[['👻','<b>مورو</b> يتسلل من العالم الملعون ويستحوذ على أجساد الأحياء، حتى السنسي وو!'],['🥷','<b>لويد:</b> «الروح تتكلم من داخل وو! يجب أن نحرره!»']],[['🌫️','<b>كاي:</b> «الضباب يخفيهم!»<br><b>زين:</b> «أحسّ بوجودهم من هنا.»']],[['🌀','<b>مورو:</b> «أنا سيد الرياح والأرواح!»'],['⚡','<b>لويد:</b> «وأنا من سيوقفك. هيّا يا فريق!»']],[['🌅','حُرّر وو وانتهت الحرب. نينجاغو آمنة… والمغامرة مستمرة!']]);
const _s6=setSkin;setSkin=function(i){_s6(i);if(i)return;const q=SV.cur>=NB?SV.cur-NB:0;NJM.setDecal(H,q);H.pads.forEach(p=>{p.visible=q===0&&SV.cur>=NB})};
/* ===== v8: full animation layer (idle/run/combo/jump/dodge/hurt/spinjitzu/win/die + enemy walk/attack/hit/spawn) ===== */
let wasAir=false,sqT=0,hurtT=0,specT=0,dieT=0;
const _hh8=hurtHero;hurtHero=function(d){const hp=H.hp;_hh8(d);if(H.hp<hp)hurtT=.4};
const _sp8=special;special=function(){_sp8();specT=.9};
const _st8=step;step=function(dt){H.g.rotation.y-=H.tw||0;H.tw=0;H.g.position.y-=H.yo||0;H.yo=0;for(const e of enemies){e.g.rotation.y-=e.tw||0;e.tw=0;e.g.position.y-=e.yo||0;e.yo=0}_st8(dt);anim8(dt)};
function anim8(dt){const now=performance.now()/1000,p=H.g.position;H.g.rotation.order='YXZ';
 const sp=dt>0?Math.hypot(p.x-(H.px===undefined?p.x:H.px),p.z-(H.pz===undefined?p.z:H.pz))/dt:(H.sp||0);H.px=p.x;H.pz=p.z;H.sp=sp;
 if(dt>0){hurtT=Math.max(0,hurtT-dt);specT=Math.max(0,specT-dt)}
 const air=H.y>.05;let a='idle',u=0,t=now;
 if(H.hp<=0){a='die';dieT+=dt;u=Math.min(1,dieT)}else{dieT=0;
  if(state==='over')a='win';else if(specT>0){a='spin';t=.9-specT}else if(hurtT>0){a='hurt';u=1-hurtT/.4}else if(H.dd>0){a='dodge';u=1-H.dd/.18}else if(air)a=H.vy>0?'jump':'fall';else if(H.at>0){a=['jab','hook','kick'][H.cs||0];u=1-H.at/(H.at0||.3)}else if(sp>1.5){a='run';t=H.ph/10}}
 const o=NJM.pose(H,a,t,u);if(wasAir&&!air)sqT=.18;wasAir=air;if(sqT>0){sqT-=dt;const k=Math.max(0,sqT)/.18;o.sy*=1-.14*k;o.sx*=1+.1*k}
 H.g.rotation.y+=o.ty;H.tw=o.ty;H.g.position.y+=o.yo;H.yo=o.yo;H.g.scale.set(o.sx,o.sy,o.sx);
 for(const e of enemies){if(e.dead)continue;e.g.rotation.order='YXZ';if(e.s0===undefined)e.s0=e.g.scale.x;e.age=(e.age||0)+dt;
  const ep=e.g.position,es=dt>0?Math.hypot(ep.x-(e.px===undefined?ep.x:e.px),ep.z-(e.pz===undefined?ep.z:e.pz))/dt:(e.sp||0);e.px=ep.x;e.pz=ep.z;e.sp=es;
  let ea='idle',eu=0;if(e.stun>0)ea='hit';else if(e.wind>0){ea='attack';eu=Math.min(1,Math.max(0,1-e.wind/.55))}else if(es>.4)ea='walk';
  const eo=NJM.epose(e,ea,ea==='walk'?e.ph/10:now,eu,e.kind);e.g.rotation.y+=eo.ty;e.tw=eo.ty;ep.y+=eo.yo;e.yo=eo.yo;
  if(e.age<.45){const k=Math.min(1,e.age/.4),c=k-1;e.g.scale.setScalar(Math.max(.05,e.s0*(1+2.7*c*c*c+1.7*c*c)))}else if(e.age<.5)e.g.scale.setScalar(e.s0)}}
setSkin(0);
/* ===== NINJA الذهبي: trials, form, golden dragon, skins, shop preview ===== */
const GQ=[{n:'كسّر 15 صندوق',g:15},{n:'تحوّل لكل النينجا الخمسة (كاي، جاي، زين، كول، لويد)',g:5},{n:'اهزم 5 زعماء',g:5},{n:'اجمع رمح الإعصار الأقصى مرتين',g:2},{n:'اعمل كومبو 30 ضربة متتالية بدون ما تتصاب',g:30}];
const gStep=()=>SV.gq.findIndex((v,i)=>v<GQ[i].g);
const GD={n:'النينجا الذهبي',suit:0xffd23f,pants:0xe0a800,hat:0xffd23f,mask:0xffe27a,band:0x2e7d32,armor:0xe0a800,strap:0x7a5a00,wrap:0xfff1a8,cape:0xe0a800,skin:0xffd9a0,emblem:0x4caf50,boot:0x7a5a00};
[['ملك التنين',0x7b2cbf,0x2b0a4a,0xffd166],['نينجا الجليد',0xbfefff,0x4a90c2,0xffffff],['نينجا اللهب',0xff6a1a,0x7a1010,0xffd166],['شبح الليل',0x1b1b2e,0x0a0a14,0x00e5ff]].forEach((a,j)=>SKS.push(mkS(a,ND.length+j)));
function ensureGold(){if(!SKS.some(x=>x.g))SKS.push({...GD,p:0,l:0,g:1});GI=SKS.findIndex(x=>x.g);if(!SV.sk.includes(GI)){SV.sk.push(GI);save()}}
if(SV.gold)ensureGold();
function gAdd(i,a,mx){if(SV.gold||gStep()!==i)return;SV.gq[i]=Math.min(GQ[i].g,mx!==undefined?Math.max(SV.gq[i],mx):SV.gq[i]+a);const nx=gStep();
 if(nx<0){SV.gold=1;ensureGold();banner('🌟 فتحت النينجا الذهبي!','المتجر ← الذهبي، وفي اللعبة اضغط 🌟 أو G',0xffd23f);sfx(700,.5,'sine')}
 else if(SV.gq[i]>=GQ[i].g)banner('✅ خطوة '+(i+1)+' تمت','الجاية: '+GQ[nx].n,0xffd23f);save()}
function gNin(n){if(!SV.gold&&gStep()===1&&!SV.gn.includes(n)){SV.gn.push(n);gAdd(1,1)}}
const _s3=setSkin;setSkin=function(i){_s3(i);if(gfT>0){paint(GI);if(H.aura)H.aura.color.setHex(0xffd23f)}};
const GEMG=new T.MeshBasicMaterial({color:0xff2244});
function gdr(){const g=dragonModel(0xffd23f,5);g.scale.setScalar(1.5);scene.add(g);return g}
function goldDragon(){const p=H.g.position,g=gdr(),sx=p.x-14,sz=p.z-14;g.rotation.order='YXZ';g.rotation.y=Math.PI/4;let t=0,hit=0;
 fx.push(dt=>{t+=dt;flap(g,t);if(t<.9){const k=t/.9;g.position.set(sx+(p.x-sx)*k,38-36.5*k,sz+(p.z-sz)*k);g.rotation.x=1.1*(1-k)}
  else{if(!hit){hit=1;shake=1.6;breakAround(16);sfx(60,.9,'sawtooth');for(let i=0;i<3;i++)ring(p.x,p.z,0xffd23f);
   for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z,d=Math.hypot(dx,dz)||1;hurtEnemy(e,e.K?Math.max(150,e.mhp*.6):9999,dx/d,dz/d,25);spark(e.g.position.x,1.6,e.g.position.z,0xffd23f,10)}}
   const k=t-.9;g.position.set(p.x+k*14,1.5+k*k*30,p.z+k*14);g.rotation.x=-k*.9}
  if(t>2){scene.remove(g);return true}})}
function goldRush(){const p=H.g.position,g=gdr(),dx=Math.sin(H.rot),dz=Math.cos(H.rot),hit=new Set();g.rotation.y=H.rot;g.scale.setScalar(1.1);g.position.set(p.x,1.8,p.z);let t=0;sfx(120,.5,'sawtooth');
 fx.push(dt=>{t+=dt;flap(g,t);g.position.x+=dx*34*dt;g.position.z+=dz*34*dt;g.position.y=1.8+Math.sin(t*14)*.4;
  for(const e of enemies){if(e.dead||hit.has(e))continue;if(Math.hypot(e.g.position.x-g.position.x,e.g.position.z-g.position.z)<4.2){hit.add(e);hurtEnemy(e,e.K?e.mhp*.35:9999,dx,dz,22);spark(e.g.position.x,1.6,e.g.position.z,0xffd23f,8)}}
  if(t>1.4){scene.remove(g);return true}})}
function glow(h){H.g.traverse(m=>{if(m.userData.k&&m.material.emissive)m.material.emissive.setHex(h)})}
function goldForm(){if(!SV.gold||state!=='play'||gfT>0)return;const pi=PARTS.findIndex(p=>curLv>=p.f&&curLv<=p.to),fin=mode==='lv'&&pi>=0&&curLv===PARTS[pi].to;
 if(!fin){banner('🔒 التحول الذهبي','مرة واحدة لكل موسم في مرحلة النهاية: 20 · 50 · 85 · 120 · 160 · 200',0xffd23f);return}
 if(SV.gu.includes(pi)){banner('استخدمته في الموسم ده','هيرجع لك في نهاية الموسم الجاي',0xffd23f);return}
 SV.gu.push(pi);save();ensureGold();gfT=45;gdN=1;ult=45;ultT=0;windStorm();setSkin(0);glow(0x6b4a00);pcd=0;banner('🌟 النينجا الذهبي!','45 ثانية قوة أسطورية · التنين الذهبي نازل',0xffd23f);goldDragon()}
function goldOff(){gfT=0;ult=0;glow(0);setSkin(0);banner('التحول الذهبي خلص','بيمشي لحد نهاية الموسم الجاي',0xffd23f)}
const bGn=mkB('bgn','🌟',goldForm);
addEventListener('keydown',e=>{if(e.key.toLowerCase()==='g')goldForm()});
setInterval(()=>{bGn.style.display=SV.gold?'grid':'none';if(state!=='play'){if(gfT>0){gfT=0;ult=0;glow(0);setSkin(0)}return}
 const pi=PARTS.findIndex(p=>curLv>=p.f&&curLv<=p.to),av=mode==='lv'&&pi>=0&&curLv===PARTS[pi].to&&!SV.gu.includes(pi);
 if(gfT>0){gfT=Math.max(0,gfT-.1);if(gfT<=0)goldOff();else if((gdN<2&&gfT<=30)||(gdN<3&&gfT<=15)){gdN++;goldDragon()}}
 bGn.style.opacity=av||gfT>0?1:.4;bGn.textContent=gfT>0?Math.ceil(gfT):'🌟'},100);
const _rs6=rShop;rShop=function(t){t=t||tab;if(t!==6)return _rs6(t);tab=6;$('shh').textContent='🪙 '+SV.coins;const l=$('shl');l.innerHTML='';const cur=gStep();
 const hd=document.createElement('div');hd.className='sk'+(SV.gold?' on':'');hd.innerHTML='<b>🌟 النينجا الذهبي</b><small>'+(SV.gold?'مفتوح! اتحول مرة واحدة في كل موسم، في مرحلة النهاية (20 · 50 · 85 · 120 · 160 · 200) بزر 🌟 أو G. 45 ثانية قوة أسطورية: تنين ذهبي ينزل 3 مرات يمسح الأعداء، إعصار ذهبي، حماية كاملة، ✨ بتطلّع موجة طاقة ذهبية، والمرار يخرّج تنين من جسمك. بعدها بيمشي لحد الموسم الجاي.':'أنجز الخطوات الخمس بالترتيب عشان تفتح الذهبي، وبعدها اتحول في مرحلة نهاية أي موسم (مرة واحدة لكل موسم). مرحلة 85 نهاية الموسم التاني وفيها سيد الظلام.')+'</small>';l.appendChild(hd);
 GQ.forEach((q,i)=>{const d=document.createElement('div'),dn=SV.gold||SV.gq[i]>=q.g;d.className='sk'+(dn?' on':'');d.innerHTML='<b>'+(dn?'✅ ':i===cur?'▶️ ':'🔒 ')+(i+1)+'. '+q.n+'</b><small>'+(dn?q.g:(i===cur?SV.gq[i]:0))+' / '+q.g+'</small>';l.appendChild(d)})};
{const b=document.createElement('button');b.className='sb';b.id='t6';b.textContent='🌟 الذهبي';b.onclick=()=>rShop(6);document.querySelector('#shp .tabs').appendChild(b)}
new MutationObserver(()=>{const o=$('shp').classList.contains('show');['start','over'].forEach(i=>$(i).style.visibility=o?'hidden':'')}).observe($('shp'),{attributes:true,attributeFilter:['class']});
{const st=document.createElement('style');st.textContent="#shp.show{inset:auto 0 0 0;height:62vh;background:linear-gradient(rgba(8,12,28,0),rgba(8,12,28,.96) 22%)!important;backdrop-filter:none!important;justify-content:flex-start}.sk small{display:block;font-size:12px;opacity:.85;line-height:1.5;margin-top:3px}#bgn{right:92px;bottom:calc(236px + env(safe-area-inset-bottom,0px));width:62px;height:62px;background:linear-gradient(#ffe27a,#d99a00);color:#3a2a00;font-size:20px;display:none}";document.head.appendChild(st)}
window.gAdd=gAdd;window.gNin=gNin;window.goldRush=goldRush;
window.heroCol=()=>curSk>0?SK[curSk]:(SKS[SV.cur]||SKS[0]);

/* ---- sky instead of buildings, breakable props with coins, better enemy animation ---- */
BLD.forEach(o=>o.visible=false);
const SKYC=document.createElement('canvas');SKYC.width=4;SKYC.height=256;const SKYX=SKYC.getContext('2d'),SKYT=new T.CanvasTexture(SKYC);
const sky=new T.Mesh(new T.SphereGeometry(150,24,16),new T.MeshBasicMaterial({map:SKYT,side:T.BackSide,fog:false,depthWrite:false}));sky.renderOrder=-1;scene.add(sky);
const cloudM=new T.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.85,fog:false,depthWrite:false}),CL=new T.Group();scene.add(CL);
for(let i=0;i<14;i++){const c=new T.Group(),a=i/14*6.283+Math.random(),r=65+Math.random()*30;for(let j=0;j<4;j++){const m=new T.Mesh(new T.SphereGeometry(3.5+Math.random()*2.5,10,8),cloudM);m.scale.y=.45;m.position.set(j*4.2-6,Math.random()*1.5,Math.random()*2);c.add(m)}c.position.set(Math.cos(a)*r,24+Math.random()*18,Math.sin(a)*r);c.rotation.y=-a+1.57;CL.add(c)}
(function f(){CL.rotation.y+=.0005;requestAnimationFrame(f)})();
function skyCol(c){const hx=v=>'#'+(v&0xffffff).toString(16).padStart(6,'0'),top=(((c>>16&255)*.4|0)<<16)|(((c>>8&255)*.5|0)<<8)|Math.min(255,(c&255)*.7+40|0),hz=mixW(c,.45),g=SKYX.createLinearGradient(0,0,0,256);
 g.addColorStop(0,hx(top));g.addColorStop(.5,hx(hz));g.addColorStop(1,hx(hz));SKYX.fillStyle=g;SKYX.fillRect(0,0,4,256);SKYT.needsUpdate=true;cloudM.color.setHex(mixW(c,.6));if(window.moM)window.moM.color.setHex(mixW(c,.75))}
skyCol(scene.background.getHex());
const _bl9=buildLevel;buildLevel=function(n){_bl9(n);skyCol(scene.background.getHex())};
const _ex9=exitLv;exitLv=function(){_ex9();skyCol(scene.background.getHex())};
const PR=[],AP=new T.Group();scene.add(AP);
function coinPop(x,z,n){SV.coins+=n;save();spark(x,1.6,z,0xffd23f,8);sfx(900,.08,'sine');const d=document.createElement('div');d.className='cpop';d.textContent='+'+n+' 🪙';v3.set(x,2.2,z).project(cam);d.style.left=(v3.x*.5+.5)*innerWidth+'px';d.style.top=(-v3.y*.5+.5)*innerHeight+'px';document.body.appendChild(d);setTimeout(()=>d.remove(),1000)}
function breakProp(o){if(o.dead)return;o.dead=1;o.rt=45;const i=OB.indexOf(o);if(i>=0)OB.splice(i,1);chips(o.x,o.z);coinPop(o.x,o.z,3+(Math.random()*5|0));let t=0;
 fx.push(dt=>{t+=dt;const k=Math.max(0,1-t/.22);o.g.scale.set(k,k,k);if(t>.22){o.g.visible=false;return true}})}
function hitProp(o,d){if(o.dead)return;o.hp-=d;sfx(200,.1);let t=0;fx.push(dt=>{t+=dt;o.g.rotation.z=Math.sin(t*40)*.12*Math.max(0,1-t/.25);if(t>.25){o.g.rotation.z=0;return true}});if(o.hp<=0)breakProp(o)}
function hitProps(){const p=H.g.position,fx_=Math.sin(H.rot),fz=Math.cos(H.rot),Rg=buff>0?4:3.3;
 for(const o of [...PR,...OB]){if(o.dead||!o.g)continue;const dx=o.x-p.x,dz=o.z-p.z,d=Math.hypot(dx,dz);if(d>Rg+(o.r||1)*.6)continue;if(d>1.2&&(dx*fx_+dz*fz)/d<-.1)continue;hitProp(o,H.cs===2?2:1)}}
function breakAround(r){const p=H.g.position;for(const o of [...PR,...OB])if(!o.dead&&o.g&&Math.hypot(o.x-p.x,o.z-p.z)<r)breakProp(o)}
function arcProps(m){PR.length=0;while(AP.children.length)AP.remove(AP.children[0]);AP.visible=m!=='lv';if(m==='lv')return;const pal=[0x52b788,0x2d9d5a,0x95d5b2],rn=rng(Date.now()|0);
 for(let i=0,n=0;i<60&&n<12;i++){const x=(rn()-.5)*34,z=(rn()-.5)*34;if(Math.hypot(x,z)<6||CR.some(c=>Math.hypot(c.m.position.x-x,c.m.position.z-z)<3.5)||PR.some(o=>Math.hypot(o.x-x,o.z-z)<4))continue;
  const [g,r]=prop([1,1,0,2,3][n%5],pal,rn);g.position.set(x,0,z);g.rotation.y=rn()*6;AP.add(g);PR.push({x,z,r,g,hp:2,rt:0});n++}}
const _b9=begin;begin=function(m){_b9(m);arcProps(m)};
const _sp9=special;special=function(){_sp9();breakAround(8)};
setInterval(()=>{for(const o of PR)if(o.dead&&(o.rt-=1)<=0){o.dead=0;o.hp=2;o.g.visible=true;o.g.scale.set(1,1,1)}},1000);
const cnE=document.createElement('div');cnE.id='cn';document.body.appendChild(cnE);
setInterval(()=>{const on=state==='play'||state==='pause';cnE.style.display=on?'flex':'none';if(on)cnE.textContent='🪙 '+SV.coins},300);
{const st=document.createElement('style');st.textContent=".cpop{position:fixed;transform:translate(-50%,-50%);font-family:'Lalezar',sans-serif;font-size:20px;color:#ffd23f;text-shadow:2px 2px 0 #000;pointer-events:none;z-index:8;animation:cp 1s ease-out forwards}@keyframes cp{to{transform:translate(-50%,-190%);opacity:0}}#cn{position:fixed;top:calc(8px + env(safe-area-inset-top,0px));left:calc(50% + 32px);height:40px;padding:0 12px;border-radius:20px;background:var(--panel);border:2px solid #fff5;color:#ffd23f;font-family:'Lalezar',sans-serif;font-size:16px;align-items:center;display:none;z-index:6;pointer-events:none}";document.head.appendChild(st)}
NJM.epose=function(m,a,t,u,kind){const{g,L,R,AL,AR}=m,S=Math.sin,PI=Math.PI,o={ty:0,yo:0},now=performance.now()/1000,sn=kind==='hyp'||kind==='fang'||kind==='con'||kind==='ven',gh=kind==='ghost',sk=kind==='skel',rb=kind==='nind';
 if(m.o7===undefined)m.o7=Math.random()*6.28;[L,R,AL,AR].forEach(l=>l.rotation.set(0,0,0));g.rotation.x=g.rotation.z=0;
 if(a==='walk'){const ph=t*10,s=S(ph),c=Math.cos(ph);L.rotation.x=s*(sk?.7:.9);R.rotation.x=-s*(sk?.7:.9);
  if(sk||gh){AL.rotation.x=-1.25+s*.15;AR.rotation.x=-1.25-s*.15}else if(rb){AL.rotation.x=-s*.5;AR.rotation.x=s*.5}else{AL.rotation.x=-s*.8;AR.rotation.x=s*.8;AL.rotation.z=-.12;AR.rotation.z=.12}
  g.rotation.x=.14+Math.abs(c)*.03;g.rotation.z=sn?S(ph*.5)*.14:S(ph)*.05;o.ty=S(ph)*(rb?.04:.13);o.yo=Math.abs(s)*(rb?.04:.09);if(gh)o.yo+=.35+S(now*3+m.o7)*.12}
 else if(a==='idle'){const b=S(now*1.8+m.o7);AL.rotation.z=-.14-b*.05;AR.rotation.z=.14+b*.05;AL.rotation.x=-.25+b*.04;AR.rotation.x=-.3-b*.04;g.rotation.x=b*.02;g.rotation.z=sn?S(now*1.2+m.o7)*.07:0;o.ty=S(now*.7+m.o7)*.12;L.rotation.x=b*.02;if(gh)o.yo=.35+S(now*3+m.o7)*.12}
 else if(a==='attack'){const w=Math.min(1,u/.7),k=u<.7?w*w*(3-2*w):1,st=u<.7?0:Math.min(1,(u-.7)/.3);AR.rotation.x=-.3-2.3*k+2.1*st;AL.rotation.x=-.4*k+.2*st;g.rotation.x=-.28*k+.7*st;o.ty=.35*k-.7*st;L.rotation.x=-.25*k+.5*st;R.rotation.x=.3*k-.2*st;o.yo=.06*st}
 else{const p=Math.min(1,Math.max(0,1-(m.stun||0)/.55)),r=p<.35?S(p/.35*PI/2):1-(p-.35)/.65;g.rotation.x=-.6*r;AL.rotation.z=-1.1*r;AR.rotation.z=1.1*r;AL.rotation.x=AR.rotation.x=-.4*r;L.rotation.x=.35*r;R.rotation.x=-.35*r;o.ty=S(p*12)*.1*(1-p);o.yo=.12*r}
 return o};
window.hitProps=hitProps;window.coinPop=coinPop;
/* ---- hand element casting, new dragons + riding, music, motes ---- */
const PG=new T.SphereGeometry(1,6,5),CG=new T.ConeGeometry(1,1,5),CTT=.75,BM=(c,o)=>new T.MeshBasicMaterial({color:c,transparent:true,opacity:o===undefined?.9:o,blending:T.AdditiveBlending,depthWrite:false});
let castT=0,castEl=1;
function ptc(x,y,z,vx,vy,vz,life,sz,c,geo){const m=new T.Mesh(geo||PG,BM(c));m.position.set(x,y,z);scene.add(m);let t=0;fx.push(dt=>{t+=dt;m.position.x+=vx*dt;m.position.y+=vy*dt;m.position.z+=vz*dt;const k=Math.max(0,1-t/life);m.scale.setScalar(sz*(.3+k));m.material.opacity=.9*k;if(t>=life){scene.remove(m);return true}})}
function beam(a,b,c){const n=5,P=[];for(let i=0;i<=n;i++){const k=i/n,j=i&&i<n?.9:0;P.push({x:a.x+(b.x-a.x)*k+(Math.random()-.5)*j,y:a.y+(b.y-a.y)*k+(Math.random()-.5)*j,z:a.z+(b.z-a.z)*k+(Math.random()-.5)*j})}
 const g=new T.Group(),mt=BM(c,.95);for(let i=0;i<n;i++){const p=P[i],q=P[i+1],L=Math.hypot(q.x-p.x,q.y-p.y,q.z-p.z)||.1,m=new T.Mesh(new T.BoxGeometry(.13,.13,L),mt);m.position.set((p.x+q.x)/2,(p.y+q.y)/2,(p.z+q.z)/2);m.lookAt(new T.Vector3(q.x,q.y,q.z));g.add(m)}
 scene.add(g);let t=0;fx.push(dt=>{t+=dt;mt.opacity=.95*Math.max(0,1-t/.16);if(t>.16){scene.remove(g);return true}})}
function inCone(R_,dm){const p=H.g.position,fx_=Math.sin(H.rot),fz=Math.cos(H.rot),r=[];for(const e of enemies){if(e.dead)continue;const dx=e.g.position.x-p.x,dz=e.g.position.z-p.z,d=Math.hypot(dx,dz)||1;if(d<R_&&(dx*fx_+dz*fz)/d>dm)r.push({e,dx,dz,d})}return r.sort((a,b)=>a.d-b.d)}
function orb(ang,c,dmg,sz){const p=H.g.position,a=H.rot+ang,dx=Math.sin(a),dz=Math.cos(a),hv=new T.Vector3();H.AR.localToWorld(hv.set(0,-1.1,0));const m=new T.Mesh(PG,BM(c,.95));m.scale.setScalar(sz);m.position.set(hv.x||p.x,hv.y||1.8,hv.z||p.z);scene.add(m);const hit=new Set();let t=0;
 fx.push(dt=>{t+=dt;m.position.x+=dx*26*dt;m.position.z+=dz*26*dt;ptc(m.position.x,m.position.y,m.position.z,0,.5,0,.3,sz*.7,c);
  for(const e of enemies){if(e.dead||hit.has(e))continue;if(Math.hypot(e.g.position.x-m.position.x,e.g.position.z-m.position.z)<1.9){hit.add(e);hurtEnemy(e,dmg,dx,dz,8);spark(e.g.position.x,1.6,e.g.position.z,c,8)}}
  if(t>.75){scene.remove(m);return true}})}
function spike(x,z,delay,col){let t=0,m=null,did=0;fx.push(dt=>{t+=dt;if(t<delay)return false;const u=t-delay;if(!m){m=new T.Mesh(CG,new T.MeshLambertMaterial({color:col,emissive:0x3a2410}));m.position.set(x,0,z);scene.add(m);chips(x,z)}
  const k=u<.12?u/.12:u<.4?1:Math.max(0,1-(u-.4)/.2);m.scale.set(.9,2.6*k+.01,.9);m.position.y=1.3*k;
  if(!did){did=1;for(const e of enemies){if(e.dead)continue;if(Math.hypot(e.g.position.x-x,e.g.position.z-z)<2.3){hurtEnemy(e,40,0,0,0);e.stun=1.3;e.kx=e.kz=0}}}
  if(u>.6){scene.remove(m);return true}})}
function emitEl(el,n){const p=H.g.position,hv=new T.Vector3();H.AR.localToWorld(hv.set(0,-1.1,0));const hx=hv.x||p.x,hy=hv.y||1.8,hz=hv.z||p.z,dx=Math.sin(H.rot),dz=Math.cos(H.rot),px=dz,pz=-dx;
 if(gfT>0){for(let i=-3;i<=3;i++)orb(i*.2,i%2?0xffd23f:0xfff1a8,80,.7);return}
 if(el===1){for(let i=0;i<18;i++){const sp=11+Math.random()*6,l=(Math.random()-.5)*5;ptc(hx,hy,hz,dx*sp+px*l,Math.random()*2,dz*sp+pz*l,.55,.38,i%2?0xff6a1a:0xffd166)}
  inCone(9,.5).forEach(o=>{hurtEnemy(o.e,38,o.dx/o.d,o.dz/o.d,9);dot(o.e,8,0xff6a1a)})}
 else if(el===2){const T3=inCone(16,.1).slice(0,3);if(!T3.length)beam({x:hx,y:hy,z:hz},{x:hx+dx*9,y:1,z:hz+dz*9},0x8fd8ff);T3.forEach(o=>{beam({x:hx,y:hy,z:hz},{x:o.e.g.position.x,y:1.6,z:o.e.g.position.z},0xbfefff);bolt(o.e.g.position.x,o.e.g.position.z,0x5ac8ff);hurtEnemy(o.e,45,o.dx/o.d,o.dz/o.d,6)})}
 else if(el===3){for(let i=0;i<16;i++){const sp=14+Math.random()*5,l=(Math.random()-.5)*6;ptc(hx,hy,hz,dx*sp+px*l,Math.random()*1.5,dz*sp+pz*l,.55,.3,i%2?0x9be7ff:0xffffff,CG)}
  inCone(11,.4).forEach(o=>{hurtEnemy(o.e,22,o.dx/o.d,o.dz/o.d,4);o.e.stun=2.6;o.e.kx=o.e.kz=0;spark(o.e.g.position.x,1.6,o.e.g.position.z,0x9be7ff,8)})}
 else if(el===4){const off=(n-2)*1.6;for(let i=1;i<=7;i++)spike(p.x+dx*(1.8+i*1.8)+px*off,p.z+dz*(1.8+i*1.8)+pz*off,i*.07,0x8b6b3f)}
 else orb(0,0x6aff6a,42,.6)}
function handCast(){if(state!=='play'||pcd>0)return;const el=(curSk>0&&curSk<6)?curSk:(EL[SV.ch]||1);castEl=el;castT=CTT;pcd=gfT>0?2.5:5;H.at=0;
 banner((gfT>0?'🌟 طاقة ذهبية':ELN[el]),'من إيدك!',gfT>0?0xffd23f:EC[el]);sfx(300,.35,'sawtooth');
 let tt=0,n=0;fx.push(dt=>{tt+=dt;if(n<3&&tt>.22+n*.16){n++;emitEl(el,n)}if(tt>CTT)return true})}
function handPose(){const k=1-castT/CTT,e=k<.2?k/.2:k>.85?(1-k)/.15:1,s=e*e*(3-2*e);H.AR.rotation.x=-1.8*s;H.AR.rotation.z=.12*s;H.AL.rotation.x=-.7*s;H.AL.rotation.z=-.25*s;H.g.rotation.x=-.1*s;H.L.rotation.x=.25*s;H.R.rotation.x=-.3*s}
const _an9=anim8;anim8=function(dt){_an9(dt);if(castT>0){castT=Math.max(0,castT-dt);handPose()}if(rdT>0){H.g.position.y+=1.15;H.yo=(H.yo||0)+1.15}};
usePower=function(){handCast()};
function flap(g,t){const w=g.userData.wings;if(w)w.forEach(([q,x])=>q.rotation.z=x*(.15+Math.sin(t*9)*.6))}
function dragonModel(col,el){const g=new T.Group(),Lc=mixW(col,.4),
 M=new T.MeshPhongMaterial({color:col,emissive:col,emissiveIntensity:.3,shininess:70,specular:0xffffff}),B=new T.MeshPhongMaterial({color:Lc,emissive:Lc,emissiveIntensity:.15,shininess:30}),
 Wm=new T.MeshPhongMaterial({color:Lc,emissive:col,emissiveIntensity:.4,side:T.DoubleSide,transparent:true,opacity:.85}),E=new T.MeshBasicMaterial({color:0xfff2a0}),SP=new T.SphereGeometry(1,12,10),CN=new T.ConeGeometry(1,1,6),BX=new T.BoxGeometry(1,1,1);
 const A=(geo,m,x,y,z,r,s)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);if(r)o.rotation.set(r[0],r[1],r[2]);if(s)o.scale.set(s[0],s[1],s[2]);g.add(o);return o};
 for(let i=0;i<9;i++){const r=1-i*.085;A(SP,M,0,-i*.03,-i*1.05,0,[r,r*.9,.75]);A(SP,B,0,-r*.45,-i*1.05,0,[r*.7,r*.45,.7]);A(CN,M,0,r*.85,-i*1.05,0,[.18,.5,.18])}
 for(let i=0;i<3;i++){const r=.72-i*.05;A(SP,M,0,.35+i*.4,1.05+i*.7,[-.5,0,0],[r,r,.7]);A(CN,M,0,.35+i*.4+r*.85,1.05+i*.7,0,[.14,.4,.14])}
 A(BX,M,0,1.65,3.5,0,[.95,.8,1.3]);A(BX,M,0,1.5,4.3,0,[.6,.5,1]);A(BX,B,0,1.15,4.2,[.2,0,0],[.5,.2,.9]);A(CN,B,0,-.25,-9.4,[-1.57,0,0],[.45,1.6,.12]);
 g.userData.wings=[];
 for(const x of [-1,1]){A(SP,E,x*.5,1.85,3.9,0,[.14,.14,.14]);A(CN,M,x*.35,2.2,3.0,[-.9,0,x*.3],[.18,.9,.18]);A(new T.CylinderGeometry(.18,.12,1.1,6),M,x*.65,-.8,1.3);A(new T.CylinderGeometry(.18,.12,1.1,6),M,x*.65,-.8,-2.3);A(CN,B,x*.65,-1.4,1.5,[1.57,0,0],[.15,.4,.15]);
  const wp=new T.Group();wp.position.set(x*.8,.9,-.3);g.add(wp);const sh=new T.Shape();sh.moveTo(0,0);sh.lineTo(3.2,.8);sh.lineTo(4.4,-.1);sh.lineTo(3.6,-.9);sh.lineTo(2.6,-.5);sh.lineTo(1.8,-1.4);sh.lineTo(.8,-.8);sh.lineTo(0,-1);
  const mem=new T.Mesh(new T.ShapeGeometry(sh),Wm);mem.rotation.x=Math.PI/2;mem.scale.x=x;wp.add(mem);const bn=new T.Mesh(new T.CylinderGeometry(.08,.05,3.8,5),M);bn.rotation.z=Math.PI/2;bn.position.x=x*1.9;wp.add(bn);g.userData.wings.push([wp,x])}
 if(el===1)for(let i=0;i<6;i++)A(CN,BM(0xff8a1a,.85),0,.9+i*.12,1.2+i*.6,[-.3,0,0],[.28,1.1,.28]);
 if(el===2)A(new T.TorusGeometry(1.4,.05,5,18),BM(0x9fe0ff,.8),0,.2,0,[1.57,0,0]);
 if(el===3)for(let i=0;i<6;i++)A(new T.OctahedronGeometry(.4),BM(0xbfefff,.8),0,1.1,-i*1.3);
 if(el===4)for(let i=0;i<6;i++)A(BX,new T.MeshLambertMaterial({color:0x777777}),0,1.0,-i*1.4,0,[.8,.5,.9]);
 if(el===5){const h=new T.Sprite(HALO);h.scale.set(10,10,1);h.position.y=1;g.add(h)}
 g.add(new T.PointLight(col,1.6,18));g.scale.setScalar(1.15);return g}
function rideDragon(e){if(rdT>0)return;const col=e===5?0xffd23f:EC[e],g=dragonModel(col,e);scene.add(g);rdT=12;banner('🐉 اركب تنين '+(e===5?'الذهبي ✨':ELN[e]),'12 ثانية · اتحرك واكتسح الأعداء',col);sfx(120,.6,'sawtooth');shake=Math.max(shake,.5);
 const p=H.g.position;let t=0,tk=0,lx=p.x,lz=p.z;
 fx.push(dt=>{t+=dt;tk+=dt;if(state!=='play'&&state!=='pause'){scene.remove(g);rdT=0;return true}if(state==='pause')return false;
  rdT=Math.max(0,rdT-dt);p.x+=(p.x-lx);p.z+=(p.z-lz);p.x=Math.max(-19.5,Math.min(19.5,p.x));p.z=Math.max(-19.5,Math.min(19.5,p.z));lx=p.x;lz=p.z;
  g.position.set(p.x,.05+Math.sin(t*3)*.12,p.z);g.rotation.y=H.rot;flap(g,t);
  if(tk>.35){tk=0;for(const n of enemies){if(n.dead)continue;const dx=n.g.position.x-p.x,dz=n.g.position.z-p.z,d=Math.hypot(dx,dz)||1;if(d<3.6){hurtEnemy(n,28,dx/d,dz/d,8);if(e===3){n.stun=2;n.kx=n.kz=0}if(e===2)bolt(n.g.position.x,n.g.position.z,0x5ac8ff);if(e===1)dot(n,6,0xff6a1a)}}if(e===5)H.hp=Math.min(100,H.hp+2);breakAround(4)}
  if(rdT<=0){scene.remove(g);banner('نزلت من التنين','',col);return true}})}
dragon=function(){const e=(curSk>0&&curSk<6)?curSk:SV.dg;if(state!=='play')return;if(rdT>0){rdT=0;return}if(cg>0||!e||(e!==curSk&&!SV.dr.includes(e)))return;cg=Math.max(8,16-SV.up.sk);rideDragon(e)};
const MP=[[0,[0,3,7]],[-4,[0,4,7]],[3,[0,4,7]],[-2,[0,4,7]]];let mus=0;
(function mt(){const fast=enemies.some(e=>e.K&&!e.dead)||gfT>0||ult>0;
 if(S.music&&ac&&state==='play'){const bar=mus>>4&3,st=mus&15,[r,ch]=MP[bar],pi=mode==='lv'?PARTS.findIndex(p=>curLv>=p.f&&curLv<=p.to)+1:0,k=(pi*3)%12,F=(o,x)=>x*Math.pow(2,(r+k+o)/12);
  if([0,3,6,8,11,14].includes(st))tone(F(0,55),.2,'triangle',.11);if(st%4===0)tone(70,.12,'sine',.16);if(st&1)tone(9000,.02,'square',.012);
  tone(F(ch[st%3]+(st&4?12:0),220),.14,'square',.035);
  if(fast&&[0,6,8,12].includes(st))tone(F(ch[(st>>1)%3]+12,440),.25,'sawtooth',.045);if(gfT>0&&st%4===0)tone(1760,.2,'sine',.03);mus++}
 setTimeout(mt,fast?125:165)})();
window.moM=BM(0xffe9a8,.7);const MO=new T.Group();scene.add(MO);
for(let i=0;i<50;i++){const m=new T.Mesh(PG,window.moM);m.scale.setScalar(.06+Math.random()*.08);m.position.set((Math.random()-.5)*40,.5+Math.random()*7,(Math.random()-.5)*40);m.userData.b=m.position.y;m.userData.p=Math.random()*6;MO.add(m)}
(function f2(){const t=performance.now()/1000;MO.children.forEach(m=>{m.position.y=m.userData.b+Math.sin(t*.8+m.userData.p)*.6;m.position.x+=.003});requestAnimationFrame(f2)})();

{const pb=document.createElement('div');pb.id='pzb';pb.textContent='⏸';document.body.appendChild(pb);
 const pz=document.createElement('div');pz.className='ov';pz.id='pz';pz.style.zIndex=40;pz.innerHTML='<h1>⏸ متوقّف</h1><button class="go" id="pzc">كمّل</button><button class="go alt" id="pzm">القائمة الرئيسية</button>';document.body.appendChild(pz);
 const pause=()=>{if(state!=='play')return;state='pause';pz.classList.add('show')},resume=()=>{if(state!=='pause')return;state='play';pz.classList.remove('show')};
 pb.onclick=pause;$('pzc').onclick=resume;
 $('pzm').onclick=()=>{pz.classList.remove('show');gfT=0;glow(0);reset();$('toMenu').onclick()};
 addEventListener('keydown',e=>{if(e.key==='Escape'||e.key.toLowerCase()==='p')state==='pause'?resume():pause()});
 setInterval(()=>{pb.style.display=(state==='play'||state==='pause')?'grid':'none'},200);
 const st=document.createElement('style');st.textContent="#pzb{position:fixed;top:calc(8px + env(safe-area-inset-top,0px));left:50%;transform:translateX(-50%);width:40px;height:40px;border-radius:50%;background:var(--panel);border:2px solid #fff5;color:var(--ink);display:none;place-items:center;font-size:18px;z-index:6;cursor:pointer}";document.head.appendChild(st)}
/* ===== v9: بوس كل 5 مراحل + أعداء/زعماء على شكل الصور + قدرات خاصة ===== */
let CM={};const mm=c=>CM[c]||(CM[c]=new T.MeshLambertMaterial({color:c}));
const mesh=(p,geo,c,x,y,z,r,s)=>{const e=new T.Mesh(geo,mm(c));e.position.set(x,y,z);if(r)e.rotation.set(r[0]||0,r[1]||0,r[2]||0);if(s)e.scale.set(s[0],s[1],s[2]);e.castShadow=true;p.add(e);return e};
const Bx=(p,w,h,d,c,x,y,z,r)=>mesh(p,G('BoxGeometry',w,h,d),c,x,y,z,r),Cy=(p,a,h,c,x,y,z,r)=>mesh(p,G('CylinderGeometry',a,a,h,12),c,x,y,z,r),Sp=(p,a,c,x,y,z,s)=>mesh(p,G('SphereGeometry',a,14,10),c,x,y,z,0,s),Co=(p,a,h,c,x,y,z,r)=>mesh(p,G('ConeGeometry',a,h,8),c,x,y,z,r);
const TXC={},PL=(A,c,h)=>Cy(A,.05,h||2.4,c,0,-.9,.1);
const SNH=(h,c,ey)=>{Sp(h,.5,c,0,.12,-.02,[1.05,.9,1.15]);Bx(h,.5,.32,.52,c,0,-.08,.4);[-1,1].forEach(s=>{Sp(h,.1,ey,s*.2,.3,.42,[1.3,.7,.6]);Co(h,.07,.3,0xffffff,s*.15,-.22,.55,[PI,0,0]);Bx(h,.1,.7,.5,c,s*.5,.15,-.05,[0,0,-s*.25])});Bx(h,.56,.08,.7,SHADE(c,.7),0,.52,.05)};
function MF(o){const b=MB.build({m:mm,lg:o.lg,bt:o.bt,tc:o.tc,al:o.al||o.tc,ar:o.ar||o.tc,hand:0x15151a,skin:o.hc||0xf6c744,nh:o.nh,nl:o.nl});
 if(o.dec){const q=new T.Mesh(G('PlaneGeometry',.9,.86),new T.MeshLambertMaterial({map:TXC[o.k]||(TXC[o.k]=tex(128,128,o.dec)),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));q.position.set(0,1.86,.285);b.g.add(q)}
 o.head(b.hd);if(o.wp)o.wp(b.AR,b.AL);if(o.ex)o.ex(b.g);return{g:b.g,L:b.L,R:b.R,AL:b.AL,AR:b.AR,cape:new T.Group(),flow:[]}}
const NEW={
hyp:{nh:1,tc:0x2a62c8,lg:0x2a62c8,dec:x=>{x.fillStyle='#f2d21b';x.fillRect(48,0,32,128);x.fillStyle='#caa800';for(let i=0;i<7;i++)x.fillRect(48,8+i*18,32,4)},head:h=>SNH(h,0x2a62c8,0xff3030),wp:A=>{PL(A,0x6b3a1a,2);Bx(A,.14,1.2,.06,0xd89a2a,.3,.5,.1,[0,0,-.5])}},
con:{nh:1,tc:0x1c1c20,lg:0x1c1c20,al:0x55555a,ar:0x55555a,dec:x=>{x.fillStyle='#f0a02a';for(let j=0;j<3;j++)x.fillRect(44,20+j*34,40,24)},head:h=>{SNH(h,0x1c1c20,0xffd42a);[-1,0,1].forEach(s=>Co(h,.1,.34,0xf0a02a,s*.28,.62-Math.abs(s)*.1,-.05))},wp:A=>{PL(A,0x7a4a24);[-1,1].forEach(s=>Bx(A,.08,1,.04,0x7a4fd0,s*.2,.6,.1,[0,0,-s*.25]))}},
fang:{nh:1,tc:0xf4f4f4,lg:0xf4f4f4,ar:0xd8231f,dec:x=>{x.fillStyle='#d94a3d';x.fillRect(50,0,28,128);x.strokeStyle='#1c2a55';x.lineWidth=6;for(let i=0;i<4;i++){x.beginPath();x.moveTo(14,20+i*26);x.lineTo(50,34+i*26);x.moveTo(114,20+i*26);x.lineTo(78,34+i*26);x.stroke()}},head:h=>SNH(h,0xd8231f,0xffd42a),wp:A=>{PL(A,0x777a80);Bx(A,.55,.5,.06,0x888b92,.3,.15,.1)}},
ven:{nh:1,tc:0xa8d93c,lg:0x1f6b34,bt:0x6b3a1a,ar:0xff8c1a,dec:x=>{x.strokeStyle='#5a3a1c';x.lineWidth=14;x.beginPath();x.moveTo(110,0);x.lineTo(30,128);x.stroke();x.fillStyle='#fff';x.fillRect(24,30,26,6)},head:h=>SNH(h,0xa8d93c,0xff8c1a),ex:g=>Cy(g,.62,.2,0x14532d,0,2.38,0),wp:A=>{PL(A,0x6b3a1a);Co(A,.1,.4,0xd8a82c,0,.4,.1)}},
skel:{hc:0xf2f2ea,tc:0x34343c,lg:0x4a4a52,bt:0xf2f2ea,al:0xf2f2ea,ar:0xf2f2ea,dec:x=>{x.fillStyle='#34343c';x.fillRect(0,0,128,128);x.strokeStyle='#f2f2ea';x.lineWidth=7;for(let i=0;i<3;i++){x.beginPath();x.moveTo(20,22+i*24);x.quadraticCurveTo(64,36+i*24,108,22+i*24);x.stroke()}},head:h=>{[-1,1].forEach(s=>Sp(h,.12,0x141414,s*.15,.12,.34,[1,1.2,.5]));Bx(h,.3,.08,.05,0x222222,0,-.12,.4)},wp:A=>{PL(A,0xd8a82c,2.3);Co(A,.12,.7,0xf4f4f4,.3,.3,.1,[0,0,.9])}},
ghost:{hc:0x7ff5df,tc:0x2f8d80,lg:0x4a6a66,bt:0x7ff5df,al:0x7ff5df,ar:0x7ff5df,head:h=>{[-1,1].forEach(s=>Sp(h,.12,0x0a3a34,s*.15,.12,.34,[1,1.2,.5]));Bx(h,.3,.08,.05,0x0a3a34,0,-.12,.4)},wp:A=>{PL(A,0x7ff5df,2.3);Co(A,.12,.7,0xffffff,.3,.3,.1,[0,0,.9])}},
nind:{hc:0x1c1c20,tc:0x1c1c20,lg:0x1c1c20,dec:x=>{x.fillStyle='#aab4bd';x.fillRect(34,14,60,92);x.fillStyle='#e03030';x.beginPath();x.arc(64,44,12,0,7);x.fill()},head:h=>{Bx(h,.46,.5,.12,0xaab4bd,-.14,.1,.4);Sp(h,.1,0xe02020,-.14,.1,.47);Sp(h,.07,0xe02020,.14,.14,.39)},wp:A=>{Bx(A,.12,1.6,.14,0x555560,0,-1,.28)}},
stn:{hc:0x15151a,tc:0x7a7f88,lg:0x15151a,al:0x15151a,ar:0x15151a,dec:x=>{x.fillStyle='#d8231f';x.fillRect(10,10,108,70);x.fillStyle='#9aa0a8';x.beginPath();x.arc(64,60,26,0,7);x.fill();x.strokeStyle='#8ae02a';x.lineWidth=8;x.beginPath();x.arc(64,60,13,0,5);x.stroke()},head:h=>{Bx(h,.5,.3,.05,0xe8d870,0,.08,.41);[-1,1].forEach(s=>Sp(h,.07,0xa8e02a,s*.14,.12,.43));Co(h,1,.5,0xe0231f,0,.62,0)},ex:g=>Bx(g,.35,1,.3,0xe0231f,-.35,2.3,-.45,[0,0,.5])},
stg:{nh:1,tc:0xd02a22,lg:0x15151a,dec:x=>{x.fillStyle='#e8e8e8';for(let i=0;i<6;i++)x.fillRect(14+i*16,76,10,18);x.fillStyle='#d8e050';x.beginPath();x.arc(64,42,12,0,7);x.fill()},head:h=>{Bx(h,.72,.7,.66,0x15151a,0,.1,0);Bx(h,.5,.22,.05,0x7a1010,0,.14,.34);[-1,1].forEach(s=>{Sp(h,.06,0xe8e870,s*.14,.15,.36);Bx(h,.12,.7,.12,0xe0231f,s*.3,.85,0,[0,0,-s*.5]);Bx(h,.5,.4,.08,0x15151a,s*.6,.3,0,[0,0,-s*.5])})},ex:g=>Bx(g,1.5,.22,.9,0xd02a22,0,2.42,0),wp:A=>{PL(A,0x2a2a30,1.2);Bx(A,.18,1.6,.05,0x2a2a30,.25,.4,.1,[0,0,-.35])}},
skal:{nh:1,tc:0xa8d93c,lg:0x1e6b34,al:0x1e6b34,ar:0x1e6b34,dec:x=>{x.fillStyle='#1e6b34';x.fillRect(0,0,128,128);x.fillStyle='#a8d93c';for(let j=0;j<5;j++)for(let i=0;i<4;i++)x.fillRect(14+i*26+(j%2)*10,6+j*24,18,14);x.fillStyle='#d8231f';x.beginPath();x.arc(30,84,10,0,7);x.fill()},head:h=>SNH(h,0x1e6b34,0xffd42a),wp:A=>{PL(A,0xd89a2a);Sp(A,.14,0x6fe05a,0,.45,.1,[1,1.6,1]);Co(A,.1,.6,0xffffff,-.25,.15,.1,[0,0,.9])}},
fng2:{nh:1,tc:0xd8231f,lg:0xd8231f,al:0xf4f4f4,dec:x=>{x.fillStyle='#f4f4f4';for(let j=0;j<6;j++)x.fillRect(48,6+j*20,32,10)},head:h=>[-1,1].forEach(s=>{const q=new T.Group();q.position.set(s*.3,.25,0);q.rotation.z=-s*.22;q.scale.setScalar(.78);h.add(q);SNH(q,0xd8231f,0xffffff)}),wp:A=>{PL(A,0xd89a2a,2.6);Cy(A,.2,.08,0x1c2a55,0,.55,.18,[PI/2,0,0])}},
nbos:{nh:1,tc:0x1c1c20,lg:0x1c1c20,dec:x=>{x.fillStyle='#aab4bd';x.fillRect(34,14,60,92);x.fillStyle='#4a3fc4';x.beginPath();x.moveTo(0,0);x.lineTo(30,0);x.lineTo(128,110);x.lineTo(100,128);x.fill();x.fillStyle='#e02020';x.beginPath();x.arc(64,44,10,0,7);x.fill()},head:h=>{Cy(h,.37,.64,0x1c1c20,0,.05,0);Sp(h,.37,0x1c1c20,0,.37,0,[1,.85,1]);Bx(h,.46,.5,.12,0xaab4bd,-.14,.12,.35);Sp(h,.1,0xe02020,-.14,.12,.43);Sp(h,.07,0xe02020,.14,.15,.35)},wp:A=>{Bx(A,.22,2.2,.14,0x555560,0,-.2,.3);for(let i=0;i<6;i++)Co(A,.07,.2,0x555560,i%2?.2:-.2,-1+i*.35,.3,[0,0,i%2?-1.57:1.57]);Bx(A,.14,.9,.7,0xc0262d,0,.5,.55)}},
anac:{nh:1,tc:0x7b2cbf,lg:0x7b2cbf,nl:1,al:0x55555a,ar:0x55555a,head:h=>SNH(h,0x7b2cbf,0xffd42a),ex:g=>{Sp(g,.9,0x7b2cbf,0,.7,0,[1.2,1,1.2]);for(let i=0;i<7;i++)Sp(g,.45-i*.04,0x7b2cbf,Math.sin(i*.7)*1.4,.3,-1.1-i*.5,[1,.8,1])},wp:A=>Co(A,.16,1.2,0xf4f4f4,.2,-.6,.3,[2.4,0,0])},
bliz:{nh:1,tc:0x9a1f26,lg:0x6b6b70,al:0xbfeee4,ar:0x7a1018,dec:x=>{x.fillStyle='#35b8e0';for(let i=0;i<5;i++){x.beginPath();x.moveTo(76,i*24);x.lineTo(128,i*24+10);x.lineTo(84,i*24+22);x.fill()}x.fillStyle='#e8e8e8';x.fillRect(20,60,60,10)},head:h=>{Sp(h,.5,0x7a1018,0,.2,-.04,[1.05,.9,1.1]);Bx(h,.2,.55,.3,0x7a1018,0,.75,0);Bx(h,.58,.5,.12,0xbfeee4,0,.02,.4);[-1,1].forEach(s=>Sp(h,.08,0x55e0ff,s*.15,.08,.47))},ex:g=>[0,1].forEach(i=>Co(g,.14,.7,0x55d0e8,-.75+i*.25,2.7,-.1,[0,0,.4])),wp:A=>{PL(A,0x35b8e0,2);Bx(A,.14,1.5,.05,0xdff8ff,0,.9,.1)}}};
const _en9=NJM.enemy;NJM.enemy=(k,o)=>NEW[k]?(CM={},MF({...NEW[k],k})):_en9(k,o);
PK[0].push('stn');PK[4].push('stn');
/* --- الزعماء: 6 شخصيات، كل 5 مراحل واحد مختلف، وكل ظهور جديد أقوى وبقدرة زيادة --- */
const BD=[{n:'جنرال الحجر',c:0xc1121f,ab:['charge','slam','shot','summon','spin','blink']},{n:'سكيلز المنوّم',c:0x2e8b3a,ab:['hypno','shot','slam','poison','summon','blink']},{n:'ثعبان الرأسين',c:0xe63946,ab:['twin','poison','charge','hypno','summon','spin']},{n:'نيندرويد المنشار',c:0x8d99ae,ab:['spin','shot','charge','blink','summon','slam']},{n:'ملك الأناكوندراي',c:0x7b2cbf,ab:['slam','poison','shot','charge','summon','hypno']},{n:'ساموراي الجليد',c:0x5ac8ff,ab:['ice','spike','shot','blink','summon','charge']}],
ABN={slam:'ضربة أرضية',ice:'صقيع يجمّدك',spike:'أشواك الجليد',charge:'اندفاع',spin:'دوامة المنشار',shot:'قذائف',twin:'قذيفتان',poison:'بِرَك السم',hypno:'تنويم (عكس الحركة)',blink:'انتقال خاطف',summon:'استدعاء جنود'},TT=['','المتوحش','المظلم','الأسطوري','الملكي','الأبدي','الأعظم'];
BK.length=0;BK.push({n:'جنرال الحجر',s:2,c:0xc1121f,hp:300,sp:.8,dm:20},{n:'سكيلز',s:1.9,c:0x2e8b3a,hp:280,sp:.85,dm:18},{n:'ثعبان الرأسين',s:2,c:0xe63946,hp:320,sp:.8,dm:20},{n:'نيندرويد المنشار',s:1.9,c:0x8d99ae,hp:340,sp:.95,dm:22},{n:'ملك الأناكوندراي',s:2.4,c:0x7b2cbf,hp:420,sp:.7,dm:24},{n:'ساموراي الجليد',s:2.1,c:0x5ac8ff,hp:380,sp:.85,dm:22});
BKK.length=0;BKK.push('stg','skal','fng2','nbos','anac','bliz');
const FIN={20:0,50:4,85:2,120:3,160:1,200:5},BS={},CNT=[0,0,0,0,0,0];{let cy=0,pv=-1;for(let n=5;n<=200;n+=5){let k;if(FIN[n]!==undefined)k=FIN[n];else do{k=cy++%6}while(k===pv||k===FIN[n+5]);BS[n]={k,t:CNT[k]++};pv=k}}
const hitH=(x,z,r,dm)=>{const p=H.g.position;if(state==='play'&&H.y<1.3&&Math.hypot(p.x-x,p.z-z)<r){if(dm)hurtHero(dm);return true}return false};
function tel(x,z,r,c,d,fn){const m=new T.Mesh(G('CircleGeometry',r,24),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.25,side:T.DoubleSide,depthWrite:false}));m.rotation.x=-PI/2;m.position.set(x,.1,z);scene.add(m);let t=0;fx.push(dt=>{t+=dt;m.material.opacity=.2+.3*Math.abs(Math.sin(t*10));m.scale.setScalar(.4+.6*Math.min(1,t/d));if(t>=d){scene.remove(m);fn();return true}})}
function pool(x,z,r,dm){const m=new T.Mesh(G('CircleGeometry',r,20),new T.MeshBasicMaterial({color:0x7bd62a,transparent:true,opacity:.5}));m.rotation.x=-PI/2;m.position.set(x,.09,z);scene.add(m);let t=0,k=0;fx.push(dt=>{t+=dt;k-=dt;if(k<=0){k=.5;hitH(x,z,r,dm)}m.material.opacity=.5*Math.min(1,5-t);if(t>5){scene.remove(m);return true}})}
function vol(e,n,sp){const ep=e.g.position,p=H.g.position,a0=Math.atan2(p.x-ep.x,p.z-ep.z),c=BD[e.bi].c;for(let i=0;i<n;i++){const a=a0+(i-(n-1)/2)*sp,vx=Math.sin(a)*11,vz=Math.cos(a)*11,m=new T.Mesh(G('SphereGeometry',.45,8,6),new T.MeshBasicMaterial({color:c}));m.position.set(ep.x,1.8,ep.z);scene.add(m);let t=0;fx.push(dt=>{t+=dt;m.position.x+=vx*dt;m.position.z+=vz*dt;if(Math.hypot(m.position.x-H.g.position.x,m.position.z-H.g.position.z)<1.2&&H.y<1.6){hurtHero(e.K.dm*.6);spark(m.position.x,1.5,m.position.z,c,6);scene.remove(m);return true}if(t>2.4){scene.remove(m);return true}})}sfx(300,.2,'sawtooth')}
const AB={
slam:e=>{e.lock=.9;const x=e.g.position.x,z=e.g.position.z,r=6.5+e.tier*.4;tel(x,z,r,0xff8a1a,.9,()=>{ring(x,z,0xff8a1a);shake=Math.max(shake,.8);sfx(80,.4,'sawtooth');hitH(x,z,r,e.K.dm*1.2)})},
ice:e=>{e.lock=1;const x=e.g.position.x,z=e.g.position.z;tel(x,z,7.5,0x9be7ff,1,()=>{ring(x,z,0x9be7ff);shake=Math.max(shake,.6);if(hitH(x,z,7.5,e.K.dm)){H.frz=1.6;banner('🧊 تجمّدت!','',0x9be7ff)}})},
spike:e=>{e.lock=.8;const ep=e.g.position,p=H.g.position,dx=p.x-ep.x,dz=p.z-ep.z,d=Math.hypot(dx,dz)||1;for(let i=1;i<=6;i++){const x=ep.x+dx/d*i*2.4,z=ep.z+dz/d*i*2.4;tel(x,z,1.7,0xcfefff,.5+i*.14,()=>{spark(x,1,z,0xcfefff,6);hitH(x,z,1.7,e.K.dm*.7)})}},
charge:e=>{e.lock=.8;ring(e.g.position.x,e.g.position.z,0xffd166);let t=0;fx.push(dt=>{t+=dt;if(e.dead)return true;if(t>.8){const ep=e.g.position,p=H.g.position,dx=p.x-ep.x,dz=p.z-ep.z,d=Math.hypot(dx,dz)||1;e.dsh=.6;e.dvx=dx/d*22;e.dvz=dz/d*22;return true}})},
spin:e=>{e.spn=2.2;ring(e.g.position.x,e.g.position.z,0xcfd2d8)},
shot:e=>vol(e,e.tier>=2?3:1,.28),twin:e=>vol(e,e.tier>=3?3:2,.3),
poison:e=>{const p=H.g.position;for(let i=0;i<3;i++){const x=p.x+(Math.random()-.5)*9,z=p.z+(Math.random()-.5)*9;tel(x,z,2.4,0x7bd62a,.7+i*.15,()=>pool(x,z,2.4,e.K.dm*.3))}},
hypno:e=>{e.lock=.9;const x=e.g.position.x,z=e.g.position.z;tel(x,z,13,0xd062ff,.9,()=>{ring(x,z,0xd062ff);if(hitH(x,z,13,0)){H.hyp=3.5;banner('😵 تنويم!','الاتجاهات انعكست',0xd062ff)}})},
blink:e=>{const ep=e.g.position,p=H.g.position,a=Math.random()*6.28;ring(ep.x,ep.z,0x4cc9f0);ep.x=p.x+Math.cos(a)*4;ep.z=p.z+Math.sin(a)*4;ring(ep.x,ep.z,0x4cc9f0);AB.slam(e)},
summon:e=>{if(enemies.filter(x=>!x.dead).length<8){spawnK(false);spawnK(false)}say(e,'يا جنودي!',.6)}};
function bossAI(e,dt){if(state!=='play')return;const ep=e.g.position,p=H.g.position;
 if(!e.rg&&e.hp<e.mhp*.5){e.rg=1;e.K.sp*=1.3;e.K.dm*=1.2;e.cdm=.7;banner('😡 '+e.bn+' غاضب!','سرعة وضرر أعلى',BD[e.bi].c);shake=1;ring(ep.x,ep.z,0xff2244)}
 if(e.lock>0){e.lock-=dt;ep.x=e._x;ep.z=e._z}
 if(e.dsh>0){e.dsh-=dt;ep.x+=e.dvx*dt;ep.z+=e.dvz*dt;if(!e.dh&&Math.hypot(p.x-ep.x,p.z-ep.z)<2.4&&H.y<1.2){e.dh=1;hurtHero(e.K.dm*1.1)}if(e.dsh<=0)e.dh=0}
 if(e.spn>0){e.spn-=dt;e.spA=(e.spA||0)+dt*16;e.g.rotation.y+=e.spA;e.stk=(e.stk||0)-dt;if(e.stk<=0){e.stk=.4;if(Math.hypot(p.x-ep.x,p.z-ep.z)<4.4&&H.y<1.5)hurtHero(e.K.dm*.5)}ep.x+=(p.x-ep.x)*dt*.6;ep.z+=(p.z-ep.z)*dt*.6}
 e.cd=(e.cd===undefined?2:e.cd)-dt;if(e.cd>0||e.stun>0||e.lock>0||e.dsh>0||e.spn>0)return;
 const A=BD[e.bi].ab.slice(0,Math.min(6,2+e.tier));e.cd=(3.2-Math.min(1.4,e.tier*.25))*(e.cdm||1);AB[A[Math.random()*A.length|0]](e)}
const _sK9=spawnK;spawnK=function(boss,kind,fast){if(!(boss&&lvS&&lvS.boss))return _sK9(boss,kind,fast);const s=BS[lvS.n]||{k:0,t:0},d=BD[s.k];_sK9(true,s.k,fast);const e=enemies[enemies.length-1];
 e.bi=s.k;e.tier=s.t;e.bd=1;e.K={...e.K,dm:e.K.dm+s.t*2};e.hp=e.mhp=e.hp*(1+s.t*.4+(lvS.n===PARTS[partOf(lvS.n)].to?.35:0));e.bn=d.n+(s.t?' '+TT[Math.min(6,s.t)]:'');e.g.add(new T.PointLight(d.c,1+s.t*.3,11));e.hbEl.style.width='130px';
 banner('👑 '+e.bn,d.ab.slice(0,Math.min(6,2+s.t)).map(a=>ABN[a]).join(' · '),d.c)};
const _st9=step;step=function(dt){const p=H.g.position,px=p.x,pz=p.z,B=enemies.filter(e=>e.bd&&!e.dead);B.forEach(e=>{e._x=e.g.position.x;e._z=e.g.position.z});_st9(dt);
 if(dt>0){if(H.frz>0){H.frz-=dt;p.x=px;p.z=pz}else if(H.hyp>0){H.hyp-=dt;p.x=2*px-p.x;p.z=2*pz-p.z}B.forEach(e=>bossAI(e,dt))}};

/* ===== v10: 28 سكن جديد في المتجر (من الصور) ===== */
{const N=(n,suit,pants,hat,mask,band,armor,emb,p,dk,pad,strap)=>({n,suit,pants,hat,mask,band,armor,strap:strap||0x15151a,wrap:emb,cape:SHADE(suit,.7),skin:0xf6c744,emblem:emb,boot:0x15151a,p,l:0,dk,pad}),K=0x1a1a1e,KP=0x111114,
GR=0x1f9a3a,RD=0xd62828,BL=0x1d6fe0,WH=0xf1f5f9,GO=0xe0b020,SI=0xc0c6ce;
[// يد الزمن
N('كول · يد الزمن',K,KP,K,0x9a9ea6,0x9a9ea6,0x2a2a30,0xf08a2a,150,3),N('زين · يد الزمن',K,KP,K,0xf4f4f4,0xf4f4f4,0x2a2a30,0x9be7ff,150,2),
N('نيا · يد الزمن',0xb0201f,0x9a1a1a,0xb0201f,0x2fc4e0,0x2fc4e0,GO,GO,200,2,1,0x2fc4e0),N('لويد · يد الزمن',K,KP,K,0x1f9a3a,0x1f9a3a,0x2a2a30,0x2fbf4a,150,0),
N('كاي · يد الزمن',K,KP,K,0xe03a1a,0xe03a1a,0x2a2a30,0xe03a1a,150,1),N('جاي · يد الزمن',K,KP,K,0x1c55d8,0x1c55d8,0x2a2a30,0x3a86ff,150,0),
// ثوب التنين
N('لويد · ثوب التنين',GR,GR,GR,GR,GO,GO,GO,250,0,1),N('كول · ثوب التنين',0x1d1d20,0x1d1d20,0x1d1d20,0x1d1d20,GO,0x3a3a40,GO,250,0),
N('كاي · ثوب التنين',RD,RD,RD,RD,GO,GO,GO,250,0),N('زين · ثوب التنين',WH,WH,WH,WH,SI,SI,GO,250,0),N('جاي · ثوب التنين',BL,BL,BL,BL,GO,GO,GO,250,0),
// الدرع الفضي والذهبي
N('كاي · الدرع الذهبي',RD,0x8f1515,RD,RD,GO,GO,SI,300,1,1),N('جاي · الدرع الفضي',BL,0x0b3a82,BL,BL,SI,SI,SI,300,0,1),N('لويد · الدرع الفضي',GR,0x146c2e,GR,GR,SI,SI,SI,300,0,1),
N('كول · الدرع الفضي',K,KP,K,0x1d1f25,SI,SI,0x9aa0a8,300,3,1,0x7a4a24),N('زين · الدرع الذهبي',WH,0xcdd6df,WH,WH,GO,GO,0x7a4a24,300,2,1,0x9b5a2a),
// النجم
N('زين · النجم',0x2a2d34,0x1a1a22,WH,WH,GO,0x8d99ae,SI,350,2),N('كول · النجم',0x3a3d44,0x1a1a22,0x1a1a1e,0x1a1a1e,SI,0x8d99ae,SI,350,3),
N('كاي · النجم',0x1a1a22,0x15151a,RD,RD,GO,0x8f1515,RD,350,1),N('جاي · النجم',0x1a1a22,0x15151a,BL,BL,SI,0x0b3a82,BL,350,0),N('لويد · النجم',0x1a1a22,0x15151a,GR,GR,GO,0x146c2e,GR,350,0),
N('النينجا الذهبي · النجم',0xd8a82c,0xc89a20,0xd8a82c,0xe0b83a,0xfff1a8,0xe0a800,0x7a5a00,500,0,1,0x7a5a00),
// المغامرة
N('لويد · المغامرة',GR,0x1a7a30,GR,GR,0x8a4b14,0x8a4b14,0xd8a040,200,0,0,0x8a4b14),N('جاي · المغامرة',BL,0x1657b8,BL,BL,0x8a4b14,0x8a4b14,0xd8a040,200,0,0,0x8a4b14),
N('كاي · المغامرة',RD,0xa81d1d,RD,RD,0x8a4b14,0x8a4b14,0xd8a040,200,1,0,0x8a4b14),N('سكايلور · المغامرة',0xf0a020,0xd88a10,0xf0a020,0xf0a020,0xfff1d0,0x8a4b14,0xd8a040,250,1,0,0x8a4b14),
N('زين · التيتانيوم',0x8d99ae,0x7a8696,0x6f7a8a,0x6f7a8a,0x35c0f0,0x6f7a8a,0x35c0f0,350,2,1),N('كول · المغامرة',K,KP,K,K,0xf08a2a,0x2a2a30,0xf08a2a,200,3,0,0x8a4b14)
].forEach(s=>SKS.push(s))}
{const _s10=setSkin;setSkin=function(i){_s10(i);if(i||gfT>0)return;const s=SKS[SV.cur];if(s&&s.dk!==undefined){NJM.setDecal(H,s.dk);H.pads.forEach(p=>p.visible=!!s.pad)}};setSkin(0)}

/* ===== v11: خريطة العالم (Hub) + تنين جديد + بلوم + شيدر العناصر ===== */
const HC=[0xff8a1a,0x7bd62a,0xb06bff,0x5ac8ff,0xffc933,0x2fd6b5],ELR=[4,5,1,2,3,5];SV.gb=SV.gb||0;
const NP=420,pg=new T.BufferGeometry(),pP=new Float32Array(NP*3),pC=new Float32Array(NP*3),pC0=new Float32Array(NP*3),pV=new Float32Array(NP*3),pL=new Float32Array(NP);let pI=0;
pg.setAttribute('position',new T.BufferAttribute(pP,3));pg.setAttribute('color',new T.BufferAttribute(pC,3));
const pm=new T.Points(pg,new T.PointsMaterial({size:.9,map:HALO.map,vertexColors:true,transparent:true,blending:T.AdditiveBlending,depthWrite:false,fog:false}));pm.frustumCulled=false;scene.add(pm);
const _cc=new T.Color(),_v=new T.Vector3();
function emit(x,y,z,c,sp,up){_cc.setHex(c);const i=pI++%NP,k=i*3;pP[k]=x;pP[k+1]=y;pP[k+2]=z;pV[k]=(Math.random()-.5)*(sp||1.5);pV[k+1]=(up===undefined?.5:up)+Math.random()*.6;pV[k+2]=(Math.random()-.5)*(sp||1.5);pC0[k]=_cc.r;pC0[k+1]=_cc.g;pC0[k+2]=_cc.b;pL[i]=1}
fx.push(dt=>{for(let i=0;i<NP;i++){const k=i*3;if(pL[i]>0){pL[i]-=dt*1.3;const q=Math.max(0,pL[i]);pP[k]+=pV[k]*dt;pP[k+1]+=pV[k+1]*dt;pP[k+2]+=pV[k+2]*dt;pC[k]=pC0[k]*q;pC[k+1]=pC0[k+1]*q;pC[k+2]=pC0[k+2]*q}else pC[k]=pC[k+1]=pC[k+2]=0}pg.attributes.position.needsUpdate=pg.attributes.color.needsUpdate=true;return false});
/* --- التنين الجديد: 16 فقرة، رقبة، رأس بقرون، 4 أرجل، أجنحة بمفصلين + أصابع + أغشية --- */
dragonModel=function(col,el){const g=new T.Group(),Lc=mixW(col,.45),
 M=new T.MeshPhongMaterial({color:col,emissive:col,emissiveIntensity:.3,shininess:90,specular:0xffffff}),B=new T.MeshPhongMaterial({color:Lc,emissive:Lc,emissiveIntensity:.14,shininess:30}),
 Wm=new T.MeshPhongMaterial({color:Lc,emissive:col,emissiveIntensity:.55,side:T.DoubleSide,transparent:true,opacity:.8}),E=new T.MeshBasicMaterial({color:0xfff2a0}),
 SPg=G('SphereGeometry',1,14,10),CNg=G('ConeGeometry',1,1,7),BXg=G('BoxGeometry',1,1,1),CYg=G('CylinderGeometry',1,1,1,8),UP=new T.Vector3(0,1,0);
 const A=(p,geo,m,x,y,z,s,r)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);if(s)o.scale.set(s[0],s[1],s[2]);if(r)o.rotation.set(r[0],r[1],r[2]);o.castShadow=true;p.add(o);return o},
 bone=(p,m,x,z,r)=>{const L_=Math.hypot(x,z),o=A(p,CYg,m,x/2,0,z/2,[r,L_,r]);o.quaternion.setFromUnitVectors(UP,new T.Vector3(x,0,z).normalize());return o},
 mk=pts=>{const sh=new T.Shape();pts.forEach((q,i)=>i?sh.lineTo(q[0],q[1]):sh.moveTo(q[0],q[1]));const o=new T.Mesh(new T.ShapeGeometry(sh),Wm);o.rotation.x=PI/2;return o},segs=[],wing=[],u=g.userData;
 for(let i=0;i<16;i++){const r=i<6?1-i*.02:Math.max(.12,.88-(i-5)*.075),s=new T.Group();s.position.z=-i*.95;g.add(s);A(s,SPg,M,0,0,0,[r,r*.9,.85]);A(s,SPg,B,0,-r*.42,.05,[r*.72,r*.45,.8]);A(s,CNg,M,0,r*.85,0,[.16+r*.06,.35+r*.5,.16+r*.06]);segs.push([s,i])}
 const tip=new T.Object3D();tip.position.z=-15.6;g.add(tip);A(g,BXg,Wm,0,0,-16.2,[.05,.9,1.5]);
 const nk=new T.Group();g.add(nk);for(let i=0;i<4;i++){const r=.72-i*.05;A(nk,SPg,M,0,.3+i*.38,.9+i*.62,[r,r,.8]);A(nk,CNg,M,0,.3+i*.38+r*.85,.9+i*.62,[.14,.4,.14])}
 const hd=new T.Group();hd.position.set(0,1.95,3.45);g.add(hd);A(hd,BXg,M,0,0,0,[.95,.8,1.4]);A(hd,BXg,M,0,-.12,.95,[.62,.46,1]);A(hd,BXg,B,0,-.42,.85,[.58,.18,1.1],[.12,0,0]);
 [-1,1].forEach(s=>{A(hd,SPg,E,s*.5,.25,.35,[.14,.14,.14]);A(hd,CNg,M,s*.38,.55,-.55,[.16,1.1,.16],[-.9,0,s*.3]);A(hd,CNg,B,s*.2,-.2,1.35,[.07,.3,.07],[PI,0,0]);A(hd,SPg,E,s*.15,.02,1.5,[.06,.06,.06])});
 for(const s of[-1,1])for(const zz of[1.6,-2.6]){A(g,CYg,M,s*.8,-.8,zz,[.2,1.2,.2]);A(g,CNg,B,s*.8,-1.5,zz+.2,[.15,.4,.15],[1.57,0,0])}
 u.wt=[];for(const x of[-1,1]){const w=new T.Group();w.position.set(.65*x,1,.7);w.scale.x=x;g.add(w);const inn=new T.Group();w.add(inn);A(inn,CYg,M,1.1,0,0,[.17,2.2,.17],[0,0,1.57]);inn.add(mk([[0,0],[2.2,.2],[2.6,-3.2],[.2,-3.4]]));
  const out=new T.Group();out.position.x=2.2;inn.add(out);A(out,CYg,M,1.3,0,.1,[.13,2.6,.13],[0,0,1.57]);[[3.9,-2.4],[3.2,-3.9],[1.9,-4.3]].forEach(q=>bone(out,B,q[0],q[1],.07));
  out.add(mk([[0,0],[2.6,0],[3.9,-2.4],[3.2,-3.9],[1.9,-4.3],[0,-3.3]]));const wp=new T.Object3D();wp.position.set(3.9,0,-2.4);out.add(wp);u.wt.push(wp);wing.push([inn,out])}
 if(el===1)for(let i=0;i<8;i++)A(g,CNg,BM(0xff8a1a,.85),0,1,2-i*1.6,[.3,1.2,.3],[-.3,0,0]);
 if(el===2)A(g,new T.TorusGeometry(1.5,.05,5,18),BM(0x9fe0ff,.8),0,.3,0,0,[1.57,0,0]);
 if(el===3)for(let i=0;i<6;i++)A(g,new T.OctahedronGeometry(.45),BM(0xbfefff,.8),0,1.2,2-i*1.6);
 if(el===4)for(let i=0;i<6;i++)A(g,BXg,new T.MeshLambertMaterial({color:0x777777}),0,1.1,2-i*1.8,[.8,.5,.9]);
 if(el===5){const h=new T.Sprite(HALO);h.scale.set(14,14,1);h.position.y=1;g.add(h)}
 u.col=col;u.tip=tip;u.an=t=>{const f=Math.sin(t*7);wing.forEach(([i,o])=>{i.rotation.z=.12+f*.7;o.rotation.z=Math.sin(t*7-1)*.55-.1;i.rotation.y=f*.08});segs.forEach(([s,i])=>{s.position.y=Math.sin(t*4-i*.55)*.14*(.3+i/16);s.position.x=Math.sin(t*2.5-i*.4)*.25*(i/16)});hd.rotation.x=Math.sin(t*3)*.06};
 g.add(new T.PointLight(col,1.8,22));g.scale.setScalar(.85);return g};
const _fl=flap;flap=function(g,t){const u=g.userData;if(!u.an)return _fl(g,t);u.an(t);const ry=g.rotation.y,dy=wrap(ry-(u.ly===undefined?ry:u.ly));u.ly=ry;u.bk=(u.bk||0)+(Math.max(-.7,Math.min(.7,-dy*18))-(u.bk||0))*.12;g.rotation.z=u.bk;
 if(Math.random()<.8){u.tip.getWorldPosition(_v);emit(_v.x,_v.y,_v.z,u.col,1.2,.3)}if(Math.random()<.5)u.wt.forEach(o=>{o.getWorldPosition(_v);emit(_v.x,_v.y,_v.z,u.col,.8,.2)})};
/* --- شيدر الإلقاء (دوامة رونية تحت البطل) --- */
function castDisc(c){const m=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,side:T.DoubleSide,uniforms:{uT:{value:0},uC:{value:new T.Color(c)}},vertexShader:'varying vec2 v;void main(){v=uv-.5;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
 fragmentShader:'varying vec2 v;uniform float uT;uniform vec3 uC;void main(){float r=length(v)*2.,a=atan(v.y,v.x),sw=.5+.5*sin(a*8.+r*14.-uT*14.),rg=smoothstep(.06,0.,abs(r-.85))+smoothstep(.04,0.,abs(r-.55))*.8,f=(rg+sw*smoothstep(1.,.2,r)*.5)*smoothstep(1.,.85,r)*(1.-uT*.9);gl_FragColor=vec4(uC*(1.+rg),max(f,0.));}'}),
 d=new T.Mesh(new T.PlaneGeometry(11,11),m);d.rotation.x=-PI/2;scene.add(d);let t=0;fx.push(dt=>{t+=dt;d.position.set(H.g.position.x,.12,H.g.position.z);m.uniforms.uT.value=t/.9;if(t>.9){scene.remove(d);return true}})}
const _hc=handCast;handCast=function(){const ok=state==='play'&&pcd<=0,el=(curSk>0&&curSk<6)?curSk:(EL[SV.ch]||1);_hc();if(ok)castDisc(gfT>0?0xffd23f:EC[el])};
/* --- بلوم (Bloom) + ظلال أنعم --- */
sun.shadow.bias=-.0004;sun.shadow.normalBias=.03;let CINE=null,BLF=0,rA,rB,rC,bw_=0,bh_=0;
const _rr=renderer.render.bind(renderer),FQ=new T.Mesh(new T.PlaneGeometry(2,2),null),FS=new T.Scene(),FC=new T.OrthographicCamera(-1,1,1,-1,0,1);FS.add(FQ);
const shd=(f,u)=>new T.ShaderMaterial({uniforms:u,vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:f,depthTest:false,depthWrite:false}),
mBr=shd('varying vec2 vUv;uniform sampler2D tD;void main(){vec3 c=texture2D(tD,vUv).rgb;float l=dot(c,vec3(.299,.587,.114));gl_FragColor=vec4(c*smoothstep(.66,1.,l),1.);}',{tD:{value:null}}),
mBl=shd('varying vec2 vUv;uniform sampler2D tD;uniform vec2 uD;void main(){vec4 s=texture2D(tD,vUv)*.227;s+=(texture2D(tD,vUv+uD*1.384)+texture2D(tD,vUv-uD*1.384))*.3162;s+=(texture2D(tD,vUv+uD*3.23)+texture2D(tD,vUv-uD*3.23))*.0703;gl_FragColor=s;}',{tD:{value:null},uD:{value:new T.Vector2()}}),
mCo=shd('varying vec2 vUv;uniform sampler2D tA,tB;void main(){gl_FragColor=vec4(texture2D(tA,vUv).rgb+texture2D(tB,vUv).rgb*1.15,1.);}',{tA:{value:null},tB:{value:null}}),
pass=(m,tg)=>{FQ.material=m;renderer.setRenderTarget(tg);_rr(FS,FC)};
renderer.render=function(sc,cm){if(CINE)CINE();if(!S.q||!S.bl||BLF)return _rr(sc,cm);
 try{const s=renderer.getDrawingBufferSize(new T.Vector2()),w=s.x|0,h=s.y|0;
  if(w!==bw_||h!==bh_){[rA,rB,rC].forEach(r=>r&&r.dispose());const o={minFilter:T.LinearFilter,magFilter:T.LinearFilter,format:T.RGBAFormat};rA=renderer.capabilities.isWebGL2?new T.WebGLMultisampleRenderTarget(w,h,o):new T.WebGLRenderTarget(w,h,o);rB=new T.WebGLRenderTarget(w>>2,h>>2,o);rC=new T.WebGLRenderTarget(w>>2,h>>2,o);bw_=w;bh_=h}
  renderer.setRenderTarget(rA);_rr(sc,cm);mBr.uniforms.tD.value=rA.texture;pass(mBr,rB);
  mBl.uniforms.tD.value=rB.texture;mBl.uniforms.uD.value.set(1/(w>>2),0);pass(mBl,rC);mBl.uniforms.tD.value=rC.texture;mBl.uniforms.uD.value.set(0,1/(h>>2));pass(mBl,rB);
  mCo.uniforms.tA.value=rA.texture;mCo.uniforms.tB.value=rB.texture;pass(mCo,null)}catch(e){BLF=1;renderer.setRenderTarget(null);_rr(sc,cm)}};
/* --- خريطة العالم --- */
let HUB=null,HPX=[],hubT=0,hcd=0,selP=0,selL=0;
function clearHub(){if(HUB){scene.remove(HUB);HUB=null;HPX.length=0}}
function lbl(t,s,c){const k=document.createElement('canvas');k.width=320;k.height=110;const x=k.getContext('2d');x.textAlign='center';x.direction='rtl';x.fillStyle='rgba(8,12,28,.75)';x.fillRect(0,0,320,110);x.strokeStyle='#'+c.toString(16).padStart(6,'0');x.lineWidth=5;x.strokeRect(2,2,316,106);x.fillStyle='#fff';x.font='40px Lalezar,Cairo,sans-serif';x.fillText(t,160,52);x.fillStyle='#ffd166';x.font='22px Cairo,sans-serif';x.fillText(s,160,90);const sp=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(k),transparent:true,depthWrite:false}));sp.scale.set(6,2.06,1);return sp}
function buildHub(){clearLv();exitLv();clearHub();HUB=new T.Group();scene.add(HUB);const bg=0x1b2a55;scene.background.setHex(bg);scene.fog.color.setHex(bg);skyCol(bg);
 brk(HUB,6,.5,6,0xffb703,0,0,0);brk(HUB,3.4,.5,3.4,0xe63946,0,.5,0);
 PARTS.forEach((P,i)=>{const a=i/6*PI*2-PI/2,x=Math.cos(a)*12,z=Math.sin(a)*12,ok=SV.lv>=P.f,c=ok?HC[i]:0x555a66;brk(HUB,3.4,.5,3.4,0x2d3436,x,0,z);
  const r=new T.Mesh(new T.TorusGeometry(2,.18,8,32),new T.MeshBasicMaterial({color:c}));r.rotation.x=PI/2;r.position.set(x,.7,z);HUB.add(r);
  if(ok){const b=new T.Mesh(new T.CylinderGeometry(1.5,1.5,16,20,1,true),new T.MeshBasicMaterial({color:c,transparent:true,opacity:.22,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));b.position.set(x,8,z);HUB.add(b)}
  const cr=new T.Mesh(new T.OctahedronGeometry(.9),new T.MeshLambertMaterial({color:c,emissive:c,emissiveIntensity:ok?.7:.1}));cr.scale.y=1.5;cr.position.set(x,3.5,z);HUB.add(cr);
  const l=lbl(P.e+' '+P.n,ok?P.s:'🔒 مقفول',c);l.position.set(x,6.6,z);HUB.add(l);HPX.push({x,z,i,ok,cr})})}
function enterHub(){try{ac=ac||new (window.AudioContext||window.webkitAudioContext)()}catch(e){}['start','over','set','rm','lvm','shp'].forEach(i=>$(i).classList.remove('show'));mode='lv';reset();$('wv').textContent='🗺️ الخريطة';buildHub();arcProps('lv');H.g.position.set(0,0,5);state='play';hcd=1;setSkin(0);banner('🗺️ عالم نينجاغو','ادخل بوابة موسم أو اضغط 🗺️',0xffd166)}
const rm=mk('<h2 id="rmt"></h2><div id="rmh" style="margin-bottom:6px"></div><div class="tabs" id="rmp"></div><div class="lg" id="rmg"></div><button class="go" id="rmf"></button><button class="go alt" id="rmb">رجوع للخريطة</button>','rm');
function rRm(){const P=PARTS[selP];$('rmt').textContent=P.e+' '+P.n+' · '+P.s;$('rmh').textContent='🪙 '+SV.coins+' · 🧱 طوب ذهبي '+SV.gb+' · تقدم '+Math.max(0,Math.min(P.to,SV.lv-1)-P.f+1)+'/'+(P.to-P.f+1);
 const tb=$('rmp');tb.innerHTML='';PARTS.forEach((q,i)=>{const b=document.createElement('button');b.className='sb';b.textContent=SV.lv>=q.f?q.e+' '+q.n:'🔒';b.disabled=SV.lv<q.f;b.style.opacity=i===selP?1:.6;b.onclick=()=>{selP=i;selL=Math.min(SV.lv,PARTS[i].to);rRm()};tb.appendChild(b)});
 const g=$('rmg');g.innerHTML='';for(let n=P.f;n<=P.to;n++){const ok=n<=SV.lv,b=document.createElement('button');b.textContent=ok?(isBoss(n)?'👑'+n:n):'🔒';b.disabled=!ok;if(SV.pw.includes(n))b.className='d';if(n===selL)b.style.outline='3px solid #ffd166';b.onclick=()=>{selL=n;rRm()};g.appendChild(b)}
 $('rmf').disabled=!selL;$('rmf').textContent=selL?'🐉 استدعاء التنين والطيران · مرحلة '+selL:'اختار مرحلة'}
function openRealm(i){if(state!=='play'||!HUB)return;state='pause';selP=i===undefined?partOf(SV.lv):i;selL=Math.min(SV.lv,PARTS[selP].to);rRm();rm.classList.add('show')}
$('rmb').onclick=()=>{rm.classList.remove('show');state='play';hcd=1.5;H.g.position.x*=.7;H.g.position.z*=.7};$('rmf').onclick=()=>{if(selL)flyTo(selP,selL)};
function flyTo(i,n){rm.classList.remove('show');const o=HPX[i],el=ELR[i],col=el===5?0xffd23f:EC[el],d=dragonModel(col,el),p=H.g.position,sx=p.x,sz=p.z,h0=Math.atan2(o.x-sx,o.z-sz),camP=new T.Vector3(),look=new T.Vector3();
 d.scale.setScalar(.01);d.position.set(sx,.2,sz);d.rotation.order='YXZ';d.rotation.y=h0;scene.add(d);state='cine';hcd=99;let t=0,lx=sx,ly=.2,lz=sz,go=0,xs=0,zs=0;ring(sx,sz,col);sfx(100,.8,'sawtooth');shake=1;banner('🐉 تنين '+ELN[el],PARTS[i].n+' · مرحلة '+n,col);
 CINE=()=>{if(d.parent){cam.position.copy(camP);cam.lookAt(look)}};
 fx.push(dt=>{t+=dt;let x,y,z;
  if(t<1.1){const k=t/1.1;d.scale.setScalar(Math.max(.01,.85*(1-Math.pow(1-k,3))));x=sx;y=.2;z=sz;if(Math.random()<.3)ring(sx,sz,col)}
  else if(t<2.8){const k=(t-1.1)/1.7,a=h0+k*PI*2,R=k*9;x=sx+Math.sin(a)*R;z=sz+Math.cos(a)*R;y=.2+k*k*15;xs=x;zs=z}
  else{const k=Math.min(1,(t-2.8)/1.5),e=k*k*(3-2*k);x=xs+(o.x-xs)*e;z=zs+(o.z-zs)*e;y=15.2+(2-15.2)*Math.pow(k,1.5)}
  const vx=x-lx,vy=y-ly,vz=z-lz,hz=Math.hypot(vx,vz);if(hz>1e-4){d.rotation.y+=wrap(Math.atan2(vx,vz)-d.rotation.y)*.2;d.rotation.x+=(-Math.atan2(vy,hz)*.7-d.rotation.x)*.2}
  d.position.set(x,y,z);p.set(x,y+1.4,z);H.g.rotation.y=d.rotation.y;flap(d,t);
  if(t<1.1){camP.set(sx+7,1.5,sz+7);look.set(sx,2.5,sz)}else{const ang=d.rotation.y+PI+Math.sin(t*1.2)*.8;camP.set(x+Math.sin(ang)*13,y+(t>2.8?3:6),z+Math.cos(ang)*13);look.set(x,y+1,z)}
  if(t>4.2&&!go){go=1;const f=$('flash');f.style.background='#fff';f.style.opacity=1}
  if(t>4.6){scene.remove(d);CINE=null;p.y=0;H.g.rotation.x=0;state='play';curLv=n;begin('lv');setTimeout(()=>{const f=$('flash');f.style.opacity=0;f.style.background=''},350);return true}
  lx=x;ly=y;lz=z})}
const _st10=step;step=function(dt){_st10(dt);if(!HUB||mode!=='lv'||lvS||state!=='play'||dt<=0)return;hubT+=dt;hcd-=dt;const p=H.g.position;
 HPX.forEach(o=>{o.cr.rotation.y+=dt*1.5;o.cr.position.y=3.5+Math.sin(hubT*2+o.i)*.3;if(o.ok&&Math.random()<.5)emit(o.x+(Math.random()-.5)*2.5,.3,o.z+(Math.random()-.5)*2.5,HC[o.i],.3,3);
  if(hcd<=0&&Math.hypot(p.x-o.x,p.z-o.z)<2.4){if(o.ok)openRealm(o.i);else{hcd=2;banner('🔒 مقفول','اخلّص '+PARTS[o.i-1].n+' الأول',0xff5555)}}})};
const _b10=begin;begin=function(m){clearHub();_b10(m)};
const _le10=lvEnd;lvEnd=function(w){const L=lvS,was=L&&L.done,n=L&&L.n,first=L&&!SV.pw.includes(n);_le10(w);if(w&&L&&!was&&first){SV.gb+=BS[n]?3:1;save()}};
$('pStory').onclick=enterHub;
{const hb=document.createElement('button');hb.className='go alt';hb.textContent='🗺️ الخريطة';hb.onclick=()=>{$('over').classList.remove('show');enterHub()};$('toMenu').parentNode.insertBefore(hb,$('toMenu'))}
const bM=mkB('bmap','🗺️',()=>openRealm());addEventListener('keydown',e=>{if(e.key.toLowerCase()==='m')openRealm()});
{const st=document.createElement('style');st.textContent='#bmap{right:14px;top:calc(212px + env(safe-area-inset-top,0px));width:46px;height:46px;font-size:20px;display:none}';document.head.appendChild(st)}
setInterval(()=>{bM.style.display=HUB&&state==='play'?'grid':'none'},200);

/* تحرير ذاكرة الـGPU عند تغيير المرحلة */
{const _cl9=clearLv;clearLv=function(){if(LG)LG.traverse(o=>{if(o.geometry&&o.geometry.dispose)o.geometry.dispose()});_cl9()}}
})();


