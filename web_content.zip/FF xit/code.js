// Configurações Globais
const features = {
    aim: false,
    esp: false,
    speed: false
};

let isInjected = false;

// Elementos DOM
const crosshair = document.getElementById('crosshair');
const status = document.getElementById('status');

// Função para Ligar/Desligar Features
function toggleFeature(feature) {
    features[feature] = !features[feature];
    
    // Atualiza visual dos botões
    const btnId = `btn-${feature}`;
    const btn = document.getElementById(btnId);
    
    if (features[feature]) {
        btn.classList.add('active');
        btn.innerText = `${feature.toUpperCase()}: ON`;
        status.innerText = `✅ ${feature.toUpperCase()} INJETADO`;
        status.style.color = '#00ff00';
        
        // Se for Aimbot, mostra a mira
        if(feature === 'aim') crosshair.style.display = 'block';
    } else {
        btn.classList.remove('active');
        btn.innerText = `${feature.toUpperCase()}: OFF`;
        status.innerText = `❌ ${feature.toUpperCase()} DESATIVADO`;
        status.style.color = 'red';
        
        if(feature === 'aim') crosshair.style.display = 'none';
    }
}

// Simula a injeção ao detectar foco
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        status.innerText = "🟢 APP ATIVO - INJETANDO...";
        setTimeout(() => {
            status.innerText = "✅ INJEÇÃO COMPLETA";
            isInjected = true;
            // Aqui você poderia adicionar lógica extra de movimento se fosse Root
        }, 1000);
    } else {
        status.innerText = "⏸️ PAUSADO";
    }
});

// Botão para abrir o Free Fire
function launchGame() {
    // Tenta abrir o pacote oficial do Free Fire
    window.location.href = "android.intent.action.VIEW"; 
    // Nota: Em WebViews puras, abrir intent direto varia conforme o conversor usado.
    // O mais comum é usar um link universal ou deixar o usuário clicar manualmente no ícone gerado pelo APK.
    
    alert("Abrindo Free Fire... Dê permissão de 'Desenho sobre outros apps' se pedir.");
    // Foca na janela
    window.focus();
}

// Arrastar o painel
let panel = document.getElementById("panel");
let isDragging = false;
let offsetX, offsetY;

panel.addEventListener("touchstart", function(e) {
    isDragging = true;
    offsetX = e.touches[0].clientX - panel.offsetLeft;
    offsetY = e.touches[0].clientY - panel.offsetTop;
});

panel.addEventListener("touchmove", function(e) {
    if (isDragging) {
        e.preventDefault();
        panel.style.left = (e.touches[0].clientX - offsetX) + "px";
        panel.style.top = (e.touches[0].clientY - offsetY) + "px";
    }
});

panel.addEventListener("touchend", function() {
    isDragging = false;
});