document.addEventListener('DOMContentLoaded', () => {
    const espToggle = document.getElementById('esp-toggle');
    const aimbotToggle = document.getElementById('aimbot-toggle');
    const speedSlider = document.getElementById('speed-slider');
    const fovSlider = document.getElementById('fov-slider');
    const injectBtn = document.getElementById('inject-btn');
    const log = document.getElementById('log');

    // Atualizar status dos toggles
    espToggle.addEventListener('change', () => {
        updateStatus('esp', espToggle.checked);
    });

    aimbotToggle.addEventListener('change', () => {
        updateStatus('aimbot', aimbotToggle.checked);
    });

    speedSlider.addEventListener('input', () => {
        document.getElementById('speed-value').textContent = `${speedSlider.value}x`;
    });

    fovSlider.addEventListener('input', () => {
        document.getElementById('fov-value').textContent = `${fovSlider.value}°`;
    });

    function updateStatus(feature, isActive) {
        const statusElement = feature === 'esp' ? 
            espToggle.nextElementSibling : aimbotToggle.nextElementSibling;
        
        statusElement.textContent = isActive ? 'Ativado' : 'Desativado';
        statusElement.className = `status ${isActive ? 'on' : 'off'}`;
    }

    injectBtn.addEventListener('click', async () => {
        try {
            await inject();
        } catch (error) {
            log.innerHTML += `<br>❌ Erro: ${error.message}`;
        }
    });

    async function inject() {
        log.innerHTML += '<br>🔄 Iniciando injeção...';
        
        // Simular delay de injeção
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        log.innerHTML += '<br>✅ ESP Hack injetado!';
        log.innerHTML += '<br>✅ Aimbot configurado';
        log.innerHTML += `<br>✅ Speed: ${speedSlider.value}x`;
        log.innerHTML += `<br>✅ FOV: ${fovSlider.value}°`;
        
        // Notificação visual
        injectBtn.style.background = '#2ed573';
        setTimeout(() => {
            injectBtn.style.background = '';
        }, 1000);
    }
});