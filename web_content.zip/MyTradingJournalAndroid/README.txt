MY TRADING JOURNAL — OFFLINE ANDROID PROJECT

This is Android Studio SOURCE CODE, not an already-built APK.

To build an APK:
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open the extracted MyTradingJournalAndroid folder as a project.
3. Let Android Studio download/sync Gradle and Android SDK (internet required ONCE for building).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Copy app/build/outputs/apk/debug/app-debug.apk to your Android tablet and install it.

The installed app works without internet and asks for no internet permission.
Entries are stored locally inside Android WebView storage. Uninstalling the app or clearing app data deletes them.
Use Export Backup to save a JSON file and Restore Backup to import it.
Candlestick examples are educational illustrations, not live quotes.
This project has not been compiled or tested on an Android device in this environment.
