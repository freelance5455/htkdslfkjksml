import os, io, json, uuid, zipfile, mimetypes
from pathlib import Path
from typing import Optional
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

load_dotenv()
APP_DIR = Path(__file__).parent
MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "25"))
API_KEY = os.getenv("AI_API_KEY", "")
BASE_URL = os.getenv("AI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
MODEL = os.getenv("AI_MODEL", "gpt-4.1-mini")
app = FastAPI(title="CODE IA PRO")
app.mount("/static", StaticFiles(directory=APP_DIR / "static"), name="static")

# In-memory project storage for this single-user starter. Restarting the server clears it.
projects = {}
conversations = {}

@app.get("/style.css")
async def root_style():
    return (APP_DIR / "static" / "style.css").read_text(encoding="utf-8")

@app.get("/app.js")
async def root_script():
    return (APP_DIR / "static" / "app.js").read_text(encoding="utf-8")

@app.get("/manifest.json")
async def root_manifest():
    return (APP_DIR / "static" / "manifest.json").read_text(encoding="utf-8")

@app.get("/", response_class=HTMLResponse)
async def home():
    return (APP_DIR / "static" / "index.html").read_text(encoding="utf-8")

def read_zip(data: bytes):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise HTTPException(400, "O arquivo enviado não é um ZIP válido.")
    items, names = {}, []
    for info in zf.infolist():
        name = info.filename.replace("\\", "/")
        p = Path(name)
        if p.is_absolute() or ".." in p.parts or info.is_dir():
            continue
        names.append(name)
        if info.file_size > 1_000_000:
            continue
        try:
            raw = zf.read(info)
            if b"\x00" not in raw:
                items[name] = raw.decode("utf-8")
        except Exception:
            pass
    return items, names

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > MAX_MB * 1024 * 1024:
        raise HTTPException(413, f"ZIP maior que o limite de {MAX_MB} MB.")
    items, names = read_zip(data)
    pid = str(uuid.uuid4())
    projects[pid] = {"source": data, "files": items, "names": names, "changed": {}}
    return {"project_id": pid, "file_count": len(names), "text_file_count": len(items),
            "files": names[:300], "message": "Projeto carregado. Arquivos de texto disponíveis para análise."}

SYSTEM = """Você é o CODE IA PRO, um engenheiro de software experiente. Ajude a criar, explicar, revisar e corrigir projetos.
Responda em português brasileiro. Ao modificar um projeto, devolva SOMENTE um JSON válido no formato:
{"summary":"resumo curto","files":[{"path":"caminho/arquivo.ext","content":"conteúdo COMPLETO do arquivo"}]}
Inclua apenas arquivos que devem ser criados ou substituídos. Não use reticências nem omita trechos.
Não altere arquivos sem necessidade. Nunca solicite nem exponha segredos. Não afirme que executou testes que não executou.
Para perguntas conceituais sem alteração de arquivos, responda em texto normal."""

async def ask_model(messages):
    if not API_KEY or API_KEY == "COLOQUE_SUA_CHAVE_AQUI":
        raise HTTPException(400, "Configure AI_API_KEY no arquivo .env antes de usar a IA.")
    url = BASE_URL + "/chat/completions"
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    payload = {"model": MODEL, "messages": messages, "temperature": 0.2}
    async with httpx.AsyncClient(timeout=180) as client:
        try:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        except httpx.HTTPStatusError as e:
            detail = e.response.text[:1200]
            raise HTTPException(502, f"Erro do provedor de IA ({e.response.status_code}): {detail}")
        except Exception as e:
            raise HTTPException(502, f"Não foi possível conectar ao provedor de IA: {str(e)}")

@app.post("/api/chat")
async def chat(message: str = Form(...), project_id: Optional[str] = Form(None), mode: str = Form("create"), session_id: str = Form("default")):
    if len(message) > 12000:
        raise HTTPException(400, "Mensagem muito longa.")
    context = ""
    if project_id:
        project = projects.get(project_id)
        if not project:
            raise HTTPException(404, "Projeto não encontrado. Envie o ZIP novamente.")
        chunks = []
        total = 0
        for path, content in project["files"].items():
            piece = f"\n--- FILE: {path} ---\n{content}\n"
            if total + len(piece) > 85000:
                break
            chunks.append(piece); total += len(piece)
        context = "\nArquivos do projeto (conteúdo textual):\n" + "".join(chunks)
    mode_text = {
        "create": "Crie a solução solicitada. Se forem necessários arquivos, devolva o JSON com arquivos completos.",
        "fix": "Analise cuidadosamente o projeto, identifique e corrija os problemas. Devolva JSON com arquivos completos alterados.",
        "explain": "Explique de forma didática, sem alterar arquivos, a menos que o usuário peça explicitamente."
    }.get(mode, "Ajude com programação.")
    history = conversations.setdefault(session_id, [])
    messages = [{"role":"system","content":SYSTEM}]
    messages.extend(history[-12:])
    messages.append({"role":"user","content":mode_text + "\\nPedido: " + message + context})
    answer = await ask_model(messages)
    history.extend([
        {"role":"user","content":mode_text + "\\nPedido: " + message},
        {"role":"assistant","content":answer}
    ])
    conversations[session_id] = history[-20:]
    return {"answer": answer}

@app.post("/api/apply")
async def apply_changes(project_id: str = Form(...), response: str = Form(...)):
    project = projects.get(project_id)
    if not project: raise HTTPException(404, "Projeto não encontrado.")
    try:
        obj = json.loads(response)
        changes = obj.get("files", [])
        if not isinstance(changes, list): raise ValueError()
        for item in changes:
            path = str(item["path"]).replace("\\", "/")
            p = Path(path)
            if p.is_absolute() or ".." in p.parts or not isinstance(item.get("content"), str):
                raise ValueError()
            project["changed"][path] = item["content"]
        return {"summary": obj.get("summary", "Alterações preparadas."), "changed": list(project["changed"].keys())}
    except Exception:
        raise HTTPException(400, "A resposta não contém JSON de arquivos válido. Peça à IA para devolver o formato JSON especificado.")

@app.get("/api/download/{project_id}")
async def download(project_id: str):
    project = projects.get(project_id)
    if not project: raise HTTPException(404, "Projeto não encontrado.")
    original = io.BytesIO(project["source"])
    out = io.BytesIO()
    with zipfile.ZipFile(original) as src, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        changed = project["changed"]
        for info in src.infolist():
            name = info.filename.replace("\\", "/")
            if name in changed: continue
            if info.is_dir(): continue
            p = Path(name)
            if p.is_absolute() or ".." in p.parts: continue
            dst.writestr(info, src.read(info))
        for name, content in changed.items():
            dst.writestr(name, content.encode("utf-8"))
    out.seek(0)
    return StreamingResponse(out, media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="code-ia-pro-projeto.zip"'})

@app.get("/api/status")
async def status():
    return {"configured": bool(API_KEY and API_KEY != "COLOQUE_SUA_CHAVE_AQUI"), "model": MODEL}
