// URL HTTPS do servidor Python. Deixe vazio se a página e a API estiverem no mesmo domínio.
window.CODE_IA_CONFIG = { API_BASE_URL: "" };
