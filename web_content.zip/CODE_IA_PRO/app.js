let mode="create", projectId=null, lastAnswer="";
const sessionId=(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random());
const $=id=>document.getElementById(id);
const API_BASE=(window.CODE_IA_CONFIG?.API_BASE_URL||"").trim().replace(/\\/$/,"");
const apiUrl=(path)=>API_BASE + path;
const labels={create:"Criar projeto",fix:"Corrigir projeto",explain:"Explicar código"};
document.querySelectorAll(".mode").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".mode").forEach(x=>x.classList.remove("active"));b.classList.add("active");mode=b.dataset.mode;$("modeLabel").textContent="Modo: "+labels[mode]}));
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>{$("prompt").value=b.querySelector("span").textContent;$("prompt").focus()}));
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function add(who,text){let el=document.createElement("div");el.className="bubble "+who;el.textContent=text;$("messages").appendChild(el);$("messages").scrollTop=$("messages").scrollHeight}
async function status(){try{let r=await fetch(apiUrl("/api/status")),d=await r.json();$("status").textContent=d.configured?"IA conectada · "+d.model:"Configure a chave da IA";$("status").previousElementSibling.style.background=d.configured?"#4ed6a0":"#efb85d"}catch{$("status").textContent="Servidor indisponível"}}
$("zip").addEventListener("change",async e=>{let f=e.target.files[0];if(!f)return;$("projectInfo").textContent="Enviando arquivo...";let fd=new FormData();fd.append("file",f);try{let r=await fetch(apiUrl("/api/upload"),{method:"POST",body:fd}),d=await r.json();if(!r.ok)throw Error(d.detail||"Falha no envio");projectId=d.project_id;$("projectInfo").textContent=`${f.name} · ${d.file_count} arquivos encontrados · ${d.text_file_count} arquivos de texto`; $("fileList").innerHTML=d.files.slice(0,80).map(x=>`<li>${escapeHtml(x)}</li>`).join("");add("ai","Projeto recebido! Já posso analisar os arquivos disponíveis. Diga o que você quer corrigir ou modificar.");}catch(err){$("projectInfo").textContent=err.message}});
async function send(){let msg=$("prompt").value.trim();if(!msg)return;$("prompt").value="";add("user",msg);$("send").disabled=true;$("send").textContent="Processando...";let fd=new FormData();fd.append("message",msg);fd.append("mode",mode);fd.append("session_id",sessionId);if(projectId)fd.append("project_id",projectId);try{let r=await fetch(apiUrl("/api/chat"),{method:"POST",body:fd}),d=await r.json();if(!r.ok)throw Error(d.detail||"Erro ao consultar a IA");lastAnswer=d.answer;add("ai",lastAnswer);$("applyArea").hidden=true;try{let obj=JSON.parse(lastAnswer);if(Array.isArray(obj.files)&&obj.files.length){
  $("applyArea").hidden=false;
  if(projectId){$("apply").hidden=false;$("buildNew").hidden=true}
  else{$("apply").hidden=true;$("buildNew").hidden=false}
}}catch{}}catch(err){add("ai","Falha de conexão com o servidor da IA: "+err.message+"\\n\\nConfira se o servidor Python está hospedado e se API_BASE_URL em config.js aponta para a URL HTTPS correta.")}finally{$("send").disabled=false;$("send").innerHTML='Enviar mensagem <b>➤</b>'}}
$("send").addEventListener("click",send);$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("apply").addEventListener("click",async()=>{let fd=new FormData();fd.append("project_id",projectId);fd.append("response",lastAnswer);try{let r=await fetch(apiUrl("/api/apply"),{method:"POST",body:fd}),d=await r.json();if(!r.ok)throw Error(d.detail);add("ai",d.summary+"\nArquivos preparados: "+d.changed.join(", "));$("download").href=apiUrl("/api/download/"+projectId);$("download").hidden=false}catch(e){add("ai",e.message)}});
$("newChat").addEventListener("click",()=>{location.reload()});
status();if("serviceWorker"in navigator)navigator.serviceWorker.register("/static/sw.js").catch(()=>{});

$("makeQr").addEventListener("click",async()=>{
  const value=$("qrText").value.trim();
  if(!value){$("qrResult").textContent="Digite um link ou texto primeiro.";return;}
  const fd=new FormData();fd.append("text",value);
  $("makeQr").disabled=true;$("makeQr").textContent="Gerando...";
  try{
    const r=await fetch(apiUrl("/api/qrcode"),{method:"POST",body:fd});
    if(!r.ok){let d=await r.json();throw Error(d.detail||"Falha ao gerar QR Code");}
    const blob=await r.blob();const url=URL.createObjectURL(blob);
    $("qrResult").innerHTML="";
    const img=document.createElement("img");img.src=url;img.alt="QR Code gerado";$("qrResult").appendChild(img);
    const a=document.createElement("a");a.href=url;a.download="qrcode.png";a.textContent="Baixar QR Code PNG";$("qrResult").appendChild(a);
  }catch(e){$("qrResult").textContent=e.message}
  finally{$("makeQr").disabled=false;$("makeQr").textContent="Gerar QR Code"}
});
$("buildNew").addEventListener("click",async()=>{
  const fd=new FormData();fd.append("response",lastAnswer);
  try{
    const r=await fetch(apiUrl("/api/build"),{method:"POST",body:fd});
    if(!r.ok){let d=await r.json();throw Error(d.detail||"Não foi possível montar o ZIP")}
    const blob=await r.blob();const url=URL.createObjectURL(blob);
    $("newDownload").href=url;$("newDownload").download="code-ia-pro-projeto.zip";$("newDownload").hidden=false;
  }catch(e){add("ai",e.message)}
});
