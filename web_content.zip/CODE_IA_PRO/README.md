# CODE IA PRO — versão interface profissional

Aplicação web responsiva, otimizada para celular e que pode ser aberta em um navegador Android ou empacotada por um criador de WebView como ToApp.

## Atenção: como usar com ToApp
Este projeto tem um servidor Python (FastAPI) que conversa com o provedor de IA e processa ZIPs. **Não basta importar os arquivos locais no ToApp**: primeiro hospede este projeto em um serviço que execute Python e mantenha o servidor ativo. Depois copie a URL pública HTTPS do aplicativo e cole em `Target URL` no ToApp. O modo `Local Files` sozinho não executa o backend Python.

## Instalação
1. Extraia o ZIP em um computador ou ambiente com Python 3.10+.
2. Crie ambiente virtual e instale:
   `pip install -r requirements.txt`
3. Copie `.env.example` para `.env`.
4. Edite `.env`: configure `AI_API_KEY`, `AI_BASE_URL` e `AI_MODEL` do provedor compatível.
5. Inicie: `uvicorn app:app --host 0.0.0.0 --port 8000`
6. Abra a URL do servidor. Para produção, use HTTPS e configure armazenamento persistente.

## Recursos
- Interface renovada e responsiva.
- Chat com histórico de contexto durante a sessão.
- Modos Criar, Corrigir e Explicar.
- Upload de ZIP, leitura de arquivos de texto e preservação de arquivos originais.
- Preparação de alterações e download do ZIP atualizado.

## Segurança e limites
- Não inclui chave de API, créditos nem hospedagem.
- Não executa o código do ZIP recebido.
- O histórico e os projetos ficam em memória e são apagados ao reiniciar o servidor.
- Configure autenticação, limites, armazenamento persistente e HTTPS antes de disponibilizar publicamente.
- A sessão de conversa usa contexto recente em memória; o botão Nova conversa reinicia a sessão no navegador.


## Correção para ToApp / Local Files
O HTML agora referencia CSS, JavaScript e manifesto com caminhos relativos (`./static/...`) para que o WebView consiga encontrar os arquivos quando o `index.html` é aberto localmente. Também há cópias dos assets na raiz do ZIP para construtores que solicitam os arquivos web diretamente.

**Importante:** abrir como `Local Files` carrega a aparência, mas as funções de IA, envio de ZIP e download dependem do servidor Python estar hospedado e acessível. Para usar todas as funções, selecione `URL` no ToApp e informe a URL HTTPS do servidor.
