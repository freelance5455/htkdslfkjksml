import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const PORT=Number(process.env.PORT||8787);
const GRAPH_API_VERSION=process.env.GRAPH_API_VERSION||'v23.0';
const PHONE_ID=process.env.WHATSAPP_PHONE_NUMBER_ID||'';
const TOKEN=process.env.WHATSAPP_ACCESS_TOKEN||'';
const CONFIRM_TEMPLATE=process.env.WHATSAPP_CONFIRM_TEMPLATE||'appointment_confirmation';
const REMINDER_TEMPLATE=process.env.WHATSAPP_REMINDER_TEMPLATE||'appointment_reminder_3h';
const LANG=process.env.WHATSAPP_TEMPLATE_LANGUAGE||'ar_EG';
const SEND_ENABLED=String(process.env.WHATSAPP_SEND_ENABLED||'false').toLowerCase()==='true';
const DATA_DIR=path.join(process.cwd(),'data');
const JOBS_FILE=path.join(DATA_DIR,'jobs.json');
fs.mkdirSync(DATA_DIR,{recursive:true});

function readJobs(){try{return JSON.parse(fs.readFileSync(JOBS_FILE,'utf8'))}catch{return []}}
function writeJobs(jobs){fs.writeFileSync(JOBS_FILE,JSON.stringify(jobs,null,2),'utf8')}
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});res.end(JSON.stringify(data))}
function parseBody(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>2e6)req.destroy()});req.on('end',()=>{try{resolve(JSON.parse(s||'{}'))}catch(e){reject(e)}});req.on('error',reject)})}
function normalizePhone(phone){let p=String(phone||'').replace(/[^0-9+]/g,'');if(p.startsWith('00'))p='+'+p.slice(2);if(/^01[0125]\d{8}$/.test(p))p='+20'+p;else if(/^20?1[0125]\d{8}$/.test(p)&&!p.startsWith('+'))p='+'+p.replace(/^20/,'20');return p.replace(/^\+/,'')}
function displayTime(t){const m=String(t||'').match(/^(\d{1,2}):(\d{2})$/);if(!m)return String(t||'');let h=Number(m[1]),min=m[2],ap=h<12?'ص':'م';h=h%12||12;return `${h}:${min} ${ap}`}
function fmtDate(d){const m=String(d||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?`${m[3]}/${m[2]}/${m[1]}`:String(d||'')}
function appointmentDate(date,time){const [y,m,d]=String(date||'').split('-').map(Number);const [hh,mm]=String(time||'').split(':').map(Number);if(!y||!m||!d||Number.isNaN(hh)||Number.isNaN(mm))return null;return new Date(y,m-1,d,hh,mm,0,0)}
function templatePayload(to,template,booking){
  return {messaging_product:'whatsapp',to,type:'template',template:{name:template,language:{code:LANG},components:[{type:'body',parameters:[
    {type:'text',text:String(booking.name||'')},
    {type:'text',text:fmtDate(booking.date)},
    {type:'text',text:displayTime(booking.time)},
    {type:'text',text:String(booking.periodName||'')}
  ]}]}};
}
async function sendTemplate(to,template,booking){
  if(!PHONE_ID||!TOKEN)throw new Error('Meta credentials are missing');
  const url=`https://graph.facebook.com/${GRAPH_API_VERSION}/${PHONE_ID}/messages`;
  if(!SEND_ENABLED){console.log('[DRY RUN]',template,to,booking.name,booking.date,booking.time);return {dryRun:true}}
  const r=await fetch(url,{method:'POST',headers:{Authorization:`Bearer ${TOKEN}`,'Content-Type':'application/json'},body:JSON.stringify(templatePayload(to,template,booking))});
  const text=await r.text();let body;try{body=JSON.parse(text)}catch{body={raw:text}};if(!r.ok)throw new Error(JSON.stringify(body));return body;
}
async function processJobs(){
  const jobs=readJobs();const now=Date.now();let changed=false;
  for(const j of jobs){
    if(j.canceled||j.sent||!j.remindAt)continue;
    if(new Date(j.remindAt).getTime()<=now){
      try{await sendTemplate(j.to,REMINDER_TEMPLATE,j.booking);j.sent=true;j.sentAt=new Date().toISOString();j.error=null;changed=true;console.log('Reminder sent:',j.id)}
      catch(e){j.attempts=(j.attempts||0)+1;j.error=String(e?.message||e);j.lastAttemptAt=new Date().toISOString();changed=true;console.error('Reminder failed:',j.id,j.error)}
    }
  }
  if(changed)writeJobs(jobs);
}
async function handleManualConfirmation(payload){
  const b=payload.booking||{}; const to=normalizePhone(b.phone); if(!to)throw new Error('Invalid phone number');
  const booking={...b,periodName:String(b.periodName||'')};
  const confirmation=await sendTemplate(to,CONFIRM_TEMPLATE,booking);
  return {ok:true,dryRun:!!confirmation?.dryRun,confirmation};
}
async function handleBooking(payload){
  const b=payload.booking||{};const old=payload.oldBooking||null;const to=normalizePhone(b.phone);if(!to)throw new Error('Invalid phone number');
  const when=appointmentDate(b.date,b.time);if(!when)throw new Error('Invalid appointment date/time');
  const remindAt=new Date(when.getTime()-3*60*60*1000).toISOString();
  const id=String(b.id||`${b.date}-${b.time}-${to}`);
  const jobs=readJobs();
  // Cancel prior reminder jobs for this booking; the new appointment gets a fresh reminder time.
  for(const j of jobs)if(j.bookingId===id&&!j.sent)j.canceled=true;
  const booking={...b,periodName:String(b.periodName||'')};
  if(String(b.status)==='canceled'){
    writeJobs(jobs);return {ok:true,canceled:true,remindAt:null};
  }
  const result={confirmation:null};
  try{result.confirmation=await sendTemplate(to,CONFIRM_TEMPLATE,booking)}catch(e){result.confirmationError=String(e?.message||e)}
  jobs.push({id:`${id}:${Date.now()}`,bookingId:id,to,booking,remindAt,sent:false,attempts:0,canceled:false,createdAt:new Date().toISOString()});
  writeJobs(jobs);
  return {ok:true,remindAt,confirmation:result.confirmation||null,confirmationError:result.confirmationError||null};
}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS')return json(res,204,{});
  try{
    if(req.method==='GET'&&req.url==='/api/health')return json(res,200,{ok:true,sendEnabled:SEND_ENABLED,phoneConfigured:!!PHONE_ID,tokenConfigured:!!TOKEN,jobs:readJobs().filter(x=>!x.canceled&&!x.sent).length});
    if(req.method==='POST'&&req.url==='/api/bookings')return json(res,200,await handleBooking(await parseBody(req)));
    if(req.method==='POST'&&req.url==='/api/send-confirmation')return json(res,200,await handleManualConfirmation(await parseBody(req)));
    return json(res,404,{ok:false,error:'Not found'});
  }catch(e){console.error(e);return json(res,400,{ok:false,error:String(e?.message||e)})}
});
server.listen(PORT,()=>console.log(`Clinic WhatsApp server listening on http://0.0.0.0:${PORT}`));
setInterval(()=>processJobs().catch(console.error),30*1000);
processJobs().catch(console.error);
