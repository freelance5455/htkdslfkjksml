# CryptoPulse — Stage 1108

Wallet/navigation refinement based on the supplied mobile Wallet reference.

Changes:
- Removed Profile from the bottom navigation.
- Kept Profile accessible from the compact header profile button.
- Bottom navigation now contains Home, Trade, Futures, and Wallet.
- Android versionCode/versionName: 110 / 11.0.0.
- No fabricated blockchain addresses, balances, or transaction receipts.
- Sepolia safety gating remains unchanged.
