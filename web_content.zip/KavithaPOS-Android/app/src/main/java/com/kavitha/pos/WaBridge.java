package com.kavitha.pos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * JS bridge named "AndroidApp". The POS html already calls these methods:
 *  shareToWhatsApp(phone10, base64, filename, mime)  -> bill goes straight into that number's chat (preview + Send)
 *  sendWhatsApp(...)                                 -> same
 *  shareFile(base64, filename, mime, title)          -> normal share sheet
 *  saveFile(base64, filename, mime)                  -> saves to Downloads
 *  printHtml(html, jobName)                          -> Android print / Save as PDF
 */
public class WaBridge {
    private final Activity act;
    private WebView printView;

    public WaBridge(Activity a) { act = a; }

    private boolean installed(String pkg) {
        try { act.getPackageManager().getPackageInfo(pkg, 0); return true; }
        catch (PackageManager.NameNotFoundException e) { return false; }
    }

    private void toast(final String m) {
        act.runOnUiThread(() -> Toast.makeText(act, m, Toast.LENGTH_LONG).show());
    }

    private Uri cacheUri(String b64, String filename) throws Exception {
        byte[] data = Base64.decode(b64, Base64.DEFAULT);
        File dir = new File(act.getCacheDir(), "bills");
        dir.mkdirs();
        File f = new File(dir, filename);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
        return FileProvider.getUriForFile(act, act.getPackageName() + ".fileprovider", f);
    }

    /* ---------- Bill straight into the customer's WhatsApp chat (saved or unsaved number) ---------- */
    @JavascriptInterface
    public void shareToWhatsApp(final String phone10, String b64, String filename, final String mime) {
        try {
            final Uri uri = cacheUri(b64, filename);
            final String jid = "91" + phone10 + "@s.whatsapp.net";
            final boolean wa = installed("com.whatsapp"), biz = installed("com.whatsapp.w4b");
            act.runOnUiThread(() -> {
                if (wa && biz) {
                    new AlertDialog.Builder(act).setTitle("எந்த WhatsApp?")
                            .setItems(new String[]{"WhatsApp", "WhatsApp Business"},
                                    (d, which) -> sendToChat(which == 0 ? "com.whatsapp" : "com.whatsapp.w4b", jid, uri, mime))
                            .show();
                } else if (wa) sendToChat("com.whatsapp", jid, uri, mime);
                else if (biz) sendToChat("com.whatsapp.w4b", jid, uri, mime);
                else Toast.makeText(act, "WhatsApp நிறுவப்படவில்லை", Toast.LENGTH_LONG).show();
            });
        } catch (Exception e) {
            toast("அனுப்ப முடியவில்லை");
        }
    }

    @JavascriptInterface
    public void sendWhatsApp(String phone10, String b64, String filename, String mime) {
        shareToWhatsApp(phone10, b64, filename, mime);
    }

    private void sendToChat(String pkg, String jid, Uri uri, String mime) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.putExtra("jid", jid);     // opens THAT number's chat directly, image preview + Send button
        i.setPackage(pkg);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { act.startActivity(i); }
        catch (Exception e) { toast("WhatsApp திறக்க முடியவில்லை"); }
    }

    /* ---------- Normal share sheet ---------- */
    @JavascriptInterface
    public void shareFile(String b64, String filename, String mime, String title) {
        try {
            Uri uri = cacheUri(b64, filename);
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.runOnUiThread(() -> act.startActivity(Intent.createChooser(i, "Share")));
        } catch (Exception e) {
            toast("ஷேர் செய்ய முடியவில்லை");
        }
    }

    /* ---------- Save to Downloads ---------- */
    @JavascriptInterface
    public void saveFile(String b64, String filename, String mime) {
        try {
            byte[] data = Base64.decode(b64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = act.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                try (OutputStream o = act.getContentResolver().openOutputStream(u)) { o.write(data); }
                toast("Downloads-ல் சேமிக்கப்பட்டது: " + filename);
            } else {
                File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                dir.mkdirs();
                File f = new File(dir, filename);
                try (FileOutputStream o = new FileOutputStream(f)) { o.write(data); }
                toast("சேமிக்கப்பட்டது: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            toast("சேமிக்க முடியவில்லை");
        }
    }

    /* ---------- Print / Save as PDF ---------- */
    @JavascriptInterface
    public void printHtml(final String html, final String jobName) {
        act.runOnUiThread(() -> {
            printView = new WebView(act);
            printView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView v, String url) {
                    PrintManager pm = (PrintManager) act.getSystemService(Context.PRINT_SERVICE);
                    pm.print(jobName, v.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
                }
            });
            printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        });
    }
}
