KAVITHA OIL MILL POS - Android Studio project
=============================================
1) ZIP-ஐ Extract செய்யுங்க.
2) Android Studio -> File -> Open -> "KavithaPOS-Android" ஃபோல்டரை தேர்ந்தெடுங்க.
3) Gradle Sync முடியும் வரை காத்திருங்க (முதல் முறை இணையம் வேணும்).
   (Gradle wrapper கேட்டா: "Use default Gradle wrapper" / OK அழுத்துங்க)
4) Build -> Build Bundle(s)/APK(s) -> Build APK(s)
5) APK இங்க வரும்: app/build/outputs/apk/debug/app-debug.apk -> போனுக்கு அனுப்பி நிறுவுங்க.

POS ஃபைல்: app/src/main/assets/index.html  (இதை மாற்றினா, மறுபடி Build APK செய்யணும்)
நேரடி WhatsApp கோடு: app/src/main/java/com/kavitha/pos/WaBridge.java
