/**
 * db.js - Offline IndexedDB Storage Engine
 * Handles Items, Customers, Stock Movements (Goods In/Out), and Payments.
 * 100% Offline, persists on device.
 */

const DB_NAME = 'RetailStockDB';
const DB_VERSION = 1;

let dbInstance = null;

function openDatabase() {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      return resolve(dbInstance);
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;

      // 1. Items Store
      if (!db.objectStoreNames.contains('items')) {
        const itemStore = db.createObjectStore('items', { keyPath: 'id', autoIncrement: true });
        itemStore.createIndex('name', 'name', { unique: false });
        itemStore.createIndex('currentStock', 'currentStock', { unique: false });
      }

      // 2. Customers Store
      if (!db.objectStoreNames.contains('customers')) {
        const custStore = db.createObjectStore('customers', { keyPath: 'id', autoIncrement: true });
        custStore.createIndex('name', 'name', { unique: false });
        custStore.createIndex('phone', 'phone', { unique: false });
      }

      // 3. Transactions (Goods In / Goods Out)
      if (!db.objectStoreNames.contains('transactions')) {
        const txnStore = db.createObjectStore('transactions', { keyPath: 'id', autoIncrement: true });
        txnStore.createIndex('type', 'type', { unique: false }); // 'IN' or 'OUT'
        txnStore.createIndex('itemId', 'itemId', { unique: false });
        txnStore.createIndex('customerId', 'customerId', { unique: false });
        txnStore.createIndex('timestamp', 'timestamp', { unique: false });
      }

      // 4. Payments (Customer debt settlements)
      if (!db.objectStoreNames.contains('payments')) {
        const payStore = db.createObjectStore('payments', { keyPath: 'id', autoIncrement: true });
        payStore.createIndex('customerId', 'customerId', { unique: false });
        payStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = event.target.result;
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      console.error('IndexedDB error:', event.target.error);
      reject(event.target.error);
    };
  });
}

// ----------------- ITEMS (INVENTORY) -----------------

async function getAllItems() {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('items', 'readonly');
    const store = tx.objectStore('items');
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function getItemById(id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('items', 'readonly');
    const store = tx.objectStore('items');
    const req = store.get(Number(id));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveItem(item) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('items', 'readwrite');
    const store = tx.objectStore('items');
    
    const data = {
      name: item.name.trim(),
      unit: item.unit || 'pcs',
      purchasePrice: parseFloat(item.purchasePrice) || 0,
      sellingPrice: parseFloat(item.sellingPrice) || 0,
      currentStock: parseFloat(item.currentStock) || 0,
      minStockAlert: parseFloat(item.minStockAlert) || 5,
      updatedAt: new Date().toISOString()
    };

    let req;
    if (item.id) {
      data.id = Number(item.id);
      req = store.put(data);
    } else {
      data.createdAt = new Date().toISOString();
      req = store.add(data);
    }

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function deleteItem(id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('items', 'readwrite');
    const store = tx.objectStore('items');
    const req = store.delete(Number(id));
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

// ----------------- CUSTOMERS -----------------

async function getAllCustomers() {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('customers', 'readonly');
    const store = tx.objectStore('customers');
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function getCustomerById(id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('customers', 'readonly');
    const store = tx.objectStore('customers');
    const req = store.get(Number(id));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function saveCustomer(customer) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('customers', 'readwrite');
    const store = tx.objectStore('customers');

    const data = {
      name: customer.name.trim(),
      phone: (customer.phone || '').trim(),
      address: (customer.address || '').trim(),
      notes: (customer.notes || '').trim(),
      totalPurchases: parseFloat(customer.totalPurchases) || 0,
      totalPaid: parseFloat(customer.totalPaid) || 0,
      balanceDue: parseFloat(customer.balanceDue) || 0,
      updatedAt: new Date().toISOString()
    };

    let req;
    if (customer.id) {
      data.id = Number(customer.id);
      req = store.put(data);
    } else {
      data.createdAt = new Date().toISOString();
      req = store.add(data);
    }

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function deleteCustomer(id) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('customers', 'readwrite');
    const store = tx.objectStore('customers');
    const req = store.delete(Number(id));
    req.onsuccess = () => resolve(true);
    req.onerror = () => reject(req.error);
  });
}

// ----------------- TRANSACTIONS (GOODS IN / GOODS OUT) -----------------

/**
 * Record Goods In (Restock / Purchase)
 * Increases stock count on the item.
 */
async function recordGoodsIn({ itemId, quantity, purchasePrice, supplier, notes, date }) {
  const db = await openDatabase();
  const tx = db.transaction(['items', 'transactions'], 'readwrite');
  const itemStore = tx.objectStore('items');
  const txnStore = tx.objectStore('transactions');

  return new Promise((resolve, reject) => {
    const itemReq = itemStore.get(Number(itemId));
    
    itemReq.onsuccess = () => {
      const item = itemReq.result;
      if (!item) {
        return reject(new Error('Item not found'));
      }

      const inQty = parseFloat(quantity);
      const unitPrice = parseFloat(purchasePrice) || item.purchasePrice || 0;
      const totalCost = inQty * unitPrice;

      // Update item stock & optionally last purchase price
      item.currentStock = (parseFloat(item.currentStock) || 0) + inQty;
      if (unitPrice > 0) {
        item.purchasePrice = unitPrice;
      }
      item.updatedAt = new Date().toISOString();
      itemStore.put(item);

      // Record transaction
      const txn = {
        type: 'IN',
        itemId: item.id,
        itemName: item.name,
        unit: item.unit,
        quantity: inQty,
        unitPrice: unitPrice,
        totalAmount: totalCost,
        supplier: (supplier || '').trim(),
        notes: (notes || '').trim(),
        timestamp: date ? new Date(date).toISOString() : new Date().toISOString()
      };
      txnStore.add(txn);
    };

    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Record Goods Out (Sale / Customer Dispatch)
 * Decreases stock, updates customer's balance due & total purchase history.
 */
async function recordGoodsOut({ itemId, customerId, quantity, sellingPrice, paidAmount, paymentMode, notes, date }) {
  const db = await openDatabase();
  const tx = db.transaction(['items', 'customers', 'transactions'], 'readwrite');
  const itemStore = tx.objectStore('items');
  const custStore = tx.objectStore('customers');
  const txnStore = tx.objectStore('transactions');

  return new Promise((resolve, reject) => {
    const itemReq = itemStore.get(Number(itemId));
    const custReq = custStore.get(Number(customerId));

    let item = null;
    let customer = null;

    itemReq.onsuccess = () => {
      item = itemReq.result;
      if (!item) return reject(new Error('Item not found'));
      
      const outQty = parseFloat(quantity);
      if (item.currentStock < outQty) {
        return reject(new Error(`Insufficient stock! Available: ${item.currentStock} ${item.unit}, Requested: ${outQty}`));
      }

      custReq.onsuccess = () => {
        customer = custReq.result;
        if (!customer) return reject(new Error('Customer not found'));

        const unitPrice = parseFloat(sellingPrice) || item.sellingPrice || 0;
        const totalAmount = outQty * unitPrice;
        const paid = parseFloat(paidAmount) || 0;
        const due = Math.max(0, totalAmount - paid);

        // 1. Deduct Stock
        item.currentStock = (parseFloat(item.currentStock) || 0) - outQty;
        item.updatedAt = new Date().toISOString();
        itemStore.put(item);

        // 2. Update Customer totals
        customer.totalPurchases = (parseFloat(customer.totalPurchases) || 0) + totalAmount;
        customer.totalPaid = (parseFloat(customer.totalPaid) || 0) + paid;
        customer.balanceDue = (parseFloat(customer.balanceDue) || 0) + due;
        customer.updatedAt = new Date().toISOString();
        custStore.put(customer);

        // 3. Record Transaction
        const txn = {
          type: 'OUT',
          itemId: item.id,
          itemName: item.name,
          unit: item.unit,
          customerId: customer.id,
          customerName: customer.name,
          customerPhone: customer.phone,
          quantity: outQty,
          unitPrice: unitPrice,
          totalAmount: totalAmount,
          paidAmount: paid,
          dueAmount: due,
          paymentMode: paymentMode || 'Cash',
          notes: (notes || '').trim(),
          timestamp: date ? new Date(date).toISOString() : new Date().toISOString()
        };
        txnStore.add(txn);
      };
    };

    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Record Payment Received from Customer (Settling old debt)
 */
async function recordCustomerPayment({ customerId, amount, paymentMode, notes, date }) {
  const db = await openDatabase();
  const tx = db.transaction(['customers', 'payments'], 'readwrite');
  const custStore = tx.objectStore('customers');
  const payStore = tx.objectStore('payments');

  return new Promise((resolve, reject) => {
    const custReq = custStore.get(Number(customerId));

    custReq.onsuccess = () => {
      const customer = custReq.result;
      if (!customer) return reject(new Error('Customer not found'));

      const paidAmt = parseFloat(amount) || 0;
      if (paidAmt <= 0) return reject(new Error('Payment amount must be greater than 0'));

      // Update customer balance
      customer.totalPaid = (parseFloat(customer.totalPaid) || 0) + paidAmt;
      customer.balanceDue = Math.max(0, (parseFloat(customer.balanceDue) || 0) - paidAmt);
      customer.updatedAt = new Date().toISOString();
      custStore.put(customer);

      // Record payment log
      const payment = {
        customerId: customer.id,
        customerName: customer.name,
        amount: paidAmt,
        paymentMode: paymentMode || 'Cash',
        notes: (notes || '').trim(),
        timestamp: date ? new Date(date).toISOString() : new Date().toISOString()
      };
      payStore.add(payment);
    };

    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

// ----------------- HISTORIES & STATS -----------------

async function getAllTransactions(limit = 200) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('transactions', 'readonly');
    const store = tx.objectStore('transactions');
    const req = store.getAll();
    req.onsuccess = () => {
      const results = (req.result || []).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      resolve(results.slice(0, limit));
    };
    req.onerror = () => reject(req.error);
  });
}

async function getItemHistory(itemId) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('transactions', 'readonly');
    const store = tx.objectStore('transactions');
    const index = store.index('itemId');
    const req = index.getAll(Number(itemId));
    req.onsuccess = () => {
      const results = (req.result || []).sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      resolve(results);
    };
    req.onerror = () => reject(req.error);
  });
}

async function getCustomerHistory(customerId) {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['transactions', 'payments'], 'readonly');
    const txnStore = tx.objectStore('transactions');
    const payStore = tx.objectStore('payments');

    const txnIndex = txnStore.index('customerId');
    const payIndex = payStore.index('customerId');

    const txnReq = txnIndex.getAll(Number(customerId));
    const payReq = payIndex.getAll(Number(customerId));

    let goodsOut = [];
    let payments = [];

    txnReq.onsuccess = () => {
      goodsOut = (txnReq.result || []).map(t => ({ ...t, recordCategory: 'GOODS_OUT' }));
    };

    payReq.onsuccess = () => {
      payments = (payReq.result || []).map(p => ({ ...p, recordCategory: 'PAYMENT' }));
    };

    tx.oncomplete = () => {
      // Merge goods out and payments chronologically
      const timeline = [...goodsOut, ...payments].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      resolve(timeline);
    };

    tx.onerror = () => reject(tx.error);
  });
}

async function getDashboardStats() {
  const [items, customers, txns] = await Promise.all([
    getAllItems(),
    getAllCustomers(),
    getAllTransactions(100)
  ]);

  let totalStockValue = 0;
  let lowStockCount = 0;
  let totalStockUnits = 0;

  for (const it of items) {
    const qty = parseFloat(it.currentStock) || 0;
    const price = parseFloat(it.purchasePrice) || 0;
    totalStockValue += (qty * price);
    totalStockUnits += qty;
    if (qty <= (parseFloat(it.minStockAlert) || 5)) {
      lowStockCount++;
    }
  }

  let totalCustomerDue = 0;
  for (const c of customers) {
    totalCustomerDue += (parseFloat(c.balanceDue) || 0);
  }

  // Today's activity
  const todayStr = new Date().toISOString().slice(0, 10);
  let todayInCount = 0;
  let todayOutCount = 0;
  let todayCollectedCash = 0;

  for (const t of txns) {
    if (t.timestamp && t.timestamp.startsWith(todayStr)) {
      if (t.type === 'IN') todayInCount++;
      if (t.type === 'OUT') {
        todayOutCount++;
        todayCollectedCash += (parseFloat(t.paidAmount) || 0);
      }
    }
  }

  return {
    totalStockValue,
    totalStockUnits,
    itemCount: items.length,
    lowStockCount,
    totalCustomerDue,
    customerCount: customers.length,
    todayInCount,
    todayOutCount,
    todayCollectedCash
  };
}

// ----------------- EXPORT / BACKUP & RESTORE -----------------

async function exportFullBackup() {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['items', 'customers', 'transactions', 'payments'], 'readonly');
    const itemsReq = tx.objectStore('items').getAll();
    const custReq = tx.objectStore('customers').getAll();
    const txnReq = tx.objectStore('transactions').getAll();
    const payReq = tx.objectStore('payments').getAll();

    tx.oncomplete = () => {
      const backupData = {
        version: DB_VERSION,
        exportedAt: new Date().toISOString(),
        items: itemsReq.result || [],
        customers: custReq.result || [],
        transactions: txnReq.result || [],
        payments: payReq.result || []
      };
      resolve(backupData);
    };

    tx.onerror = () => reject(tx.error);
  });
}

async function importFullBackup(data) {
  if (!data || !data.items || !data.customers) {
    throw new Error('Invalid backup file format.');
  }

  const db = await openDatabase();
  const tx = db.transaction(['items', 'customers', 'transactions', 'payments'], 'readwrite');
  
  // Clear existing
  tx.objectStore('items').clear();
  tx.objectStore('customers').clear();
  tx.objectStore('transactions').clear();
  tx.objectStore('payments').clear();

  // Populate items
  const itemStore = tx.objectStore('items');
  for (const item of data.items) {
    itemStore.put(item);
  }

  // Populate customers
  const custStore = tx.objectStore('customers');
  for (const cust of data.customers) {
    custStore.put(cust);
  }

  // Populate transactions
  const txnStore = tx.objectStore('transactions');
  for (const txn of (data.transactions || [])) {
    txnStore.put(txn);
  }

  // Populate payments
  const payStore = tx.objectStore('payments');
  for (const pay of (data.payments || [])) {
    payStore.put(pay);
  }

  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}
