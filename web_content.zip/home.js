"use strict";


/* ==================================================
   STORAGE
================================================== */

const CLASSES_STORAGE_KEY =
    "mueen_classes";

const ATTENDANCE_STORAGE_KEY =
    "mueen_attendance_records";

const SCHEDULE_CURRENT_STORAGE_KEY =
    "mueen_schedule_current";

const SCHEDULE_STORAGE_KEY =
    "mueen_schedule";

const SCHEDULE_SETTINGS_STORAGE_KEY =
    "mueen_schedule_settings";

/*
 * حالة الترم الدراسي:
 *
 * active   = الترم مستمر
 * vacation = انتهى الترم / إجازة
 */
const TERM_STATUS_STORAGE_KEY =
    "mueen_term_status";


/* ==================================================
   HELPERS
================================================== */

const $ = id =>
    document.getElementById(id);


function readJSON(key, fallback) {

    try {

        const raw =
            localStorage.getItem(key);

        if (!raw) {
            return fallback;
        }

        const value =
            JSON.parse(raw);

        return value ?? fallback;

    } catch (error) {

        console.error(
            "تعذر قراءة البيانات:",
            key,
            error
        );

        return fallback;
    }
}


/* ==================================================
   TERM STATUS
================================================== */

function getTermStatus() {

    const status =
        localStorage.getItem(
            TERM_STATUS_STORAGE_KEY
        );


    return status === "vacation"
        ? "vacation"
        : "active";
}


function isVacationMode() {

    return (
        getTermStatus() ===
        "vacation"
    );
}


/* ==================================================
   DATE
================================================== */

const dayNames = [
    "الأحد",
    "الاثنين",
    "الثلاثاء",
    "الأربعاء",
    "الخميس",
    "الجمعة",
    "السبت"
];


const englishDayNames = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday"
];


const monthNames = [
    "يناير",
    "فبراير",
    "مارس",
    "أبريل",
    "مايو",
    "يونيو",
    "يوليو",
    "أغسطس",
    "سبتمبر",
    "أكتوبر",
    "نوفمبر",
    "ديسمبر"
];


function getToday() {

    return new Date();
}


function getTodayISO() {

    const date =
        getToday();

    const y =
        date.getFullYear();

    const m =
        String(
            date.getMonth() + 1
        ).padStart(2, "0");

    const d =
        String(
            date.getDate()
        ).padStart(2, "0");

    return `${y}-${m}-${d}`;
}


function updateDate() {

    const date =
        getToday();

    const todayDate =
        $("todayDate");

    const hijriDate =
        $("hijriDate");


    if (todayDate) {

        todayDate.textContent =
            `${dayNames[date.getDay()]}، ${date.getDate()} ${monthNames[date.getMonth()]} ${date.getFullYear()}`;
    }


    if (hijriDate) {

        try {

            const formatter =
                new Intl.DateTimeFormat(
                    "ar-SA-u-ca-islamic",
                    {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                    }
                );

            hijriDate.textContent =
                formatter.format(date);

        } catch (error) {

            hijriDate.textContent =
                "التاريخ الهجري";
        }
    }
}


/* ==================================================
   CLOCK
================================================== */

function updateClock() {

    const clock =
        $("liveClock");

    if (!clock) return;


    const now =
        new Date();


    const hours =
        String(
            now.getHours()
        ).padStart(2, "0");


    const minutes =
        String(
            now.getMinutes()
        ).padStart(2, "0");


    const seconds =
        String(
            now.getSeconds()
        ).padStart(2, "0");


    clock.textContent =
        `${hours}:${minutes}:${seconds}`;
}


/* ==================================================
   CLASSES
================================================== */

function getClasses() {

    const data =
        readJSON(
            CLASSES_STORAGE_KEY,
            []
        );

    return Array.isArray(data)
        ? data
        : [];
}


function buildClassCode(cls) {

    if (!cls) {
        return "";
    }


    if (cls.code) {

        return String(
            cls.code
        );
    }


    if (
        cls.grade !== undefined &&
        cls.section !== undefined
    ) {

        return (
            `${cls.grade}/${cls.section}`
        );
    }


    return "";
}


function countStudents() {

    const classes =
        getClasses();

    let total = 0;


    classes.forEach(
        cls => {

            if (
                cls &&
                Array.isArray(
                    cls.students
                )
            ) {

                total +=
                    cls.students.length;
            }

        }
    );


    return total;
}


/* ==================================================
   ATTENDANCE
================================================== */

function getAttendanceRecords() {

    const data =
        readJSON(
            ATTENDANCE_STORAGE_KEY,
            []
        );

    return Array.isArray(data)
        ? data
        : [];
}


function updateAttendanceSummary() {

    const records =
        getAttendanceRecords();


    const today =
        getTodayISO();


    const todayRecords =
        records.filter(
            record =>
                String(record.date) ===
                today
        );


    let present = 0;
    let absent = 0;


    todayRecords.forEach(
        record => {

            present +=
                Number(
                    record.presentCount || 0
                );


            absent +=
                Number(
                    record.absentCount || 0
                );

        }
    );


    const totalStudents =
        countStudents();


    const studentsCount =
        $("studentsCount");


    const presentCount =
        $("presentCount");


    const absentCount =
        $("absentCount");


    if (studentsCount) {

        studentsCount.textContent =
            totalStudents;
    }


    if (presentCount) {

        presentCount.textContent =
            present;
    }


    if (absentCount) {

        absentCount.textContent =
            absent;
    }
}


/* ==================================================
   SCHEDULE
================================================== */

function getCurrentSchedule() {

    const data =
        readJSON(
            SCHEDULE_CURRENT_STORAGE_KEY,
            null
        );


    if (
        data &&
        typeof data === "object" &&
        !Array.isArray(data)
    ) {

        return data;
    }


    const oldData =
        readJSON(
            SCHEDULE_STORAGE_KEY,
            []
        );


    if (Array.isArray(oldData)) {

        return {

            version: 1,

            updatedAt:
                Date.now(),

            columns: [],

            assignments: {},

            legacyItems:
                oldData
        };
    }


    return null;
}


/* ==================================================
   SCHEDULE SETTINGS
================================================== */

function getScheduleSettings() {

    const settings =
        readJSON(
            SCHEDULE_SETTINGS_STORAGE_KEY,
            {}
        );


    if (
        !settings ||
        typeof settings !== "object"
    ) {

        return {

            assemblyStartTime:
                "07:00",

            assemblyEndTime:
                "07:30",

            lessonDuration:
                45
        };
    }


    if (
        settings.assemblyStartTime ||
        settings.assemblyEndTime
    ) {

        return {

            assemblyStartTime:
                settings.assemblyStartTime ||
                "07:00",

            assemblyEndTime:
                settings.assemblyEndTime ||
                "07:30",

            lessonDuration:
                Number(
                    settings.lessonDuration
                ) || 45
        };
    }


    if (settings.dayStartTime) {

        const end =
            timeToMinutes(
                settings.dayStartTime
            );


        if (end !== null) {

            const start =
                Math.max(
                    0,
                    end - 30
                );


            return {

                assemblyStartTime:
                    minutesToTime(start),

                assemblyEndTime:
                    settings.dayStartTime,

                lessonDuration:
                    Number(
                        settings.lessonDuration
                    ) || 45
            };
        }
    }


    return {

        assemblyStartTime:
            "07:00",

        assemblyEndTime:
            "07:30",

        lessonDuration:
            Number(
                settings.lessonDuration
            ) || 45
    };
}


/* ==================================================
   TIME HELPERS
================================================== */

function timeToMinutes(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return null;
    }


    const text =
        String(value).trim();


    const match =
        text.match(
            /^(\d{1,2}):(\d{2})$/
        );


    if (!match) {

        return null;
    }


    const hours =
        Number(match[1]);

    const minutes =
        Number(match[2]);


    if (
        hours < 0 ||
        hours > 23 ||
        minutes < 0 ||
        minutes > 59
    ) {

        return null;
    }


    return (
        hours * 60 +
        minutes
    );
}


function minutesToTime(minutes) {

    let value =
        Number(minutes);


    if (
        !Number.isFinite(value)
    ) {

        value = 0;
    }


    value =
        Math.max(
            0,
            Math.min(
                1439,
                Math.round(value)
            )
        );


    const hours =
        Math.floor(
            value / 60
        );


    const mins =
        value % 60;


    return (
        String(hours).padStart(2, "0") +
        ":" +
        String(mins).padStart(2, "0")
    );
}


function formatDisplayTime(value) {

    const minutes =
        timeToMinutes(value);


    if (minutes === null) {

        return String(
            value || ""
        );
    }


    let hours =
        Math.floor(
            minutes / 60
        );


    const mins =
        minutes % 60;


    const period =
        hours >= 12
            ? "م"
            : "ص";


    hours =
        hours % 12;


    if (hours === 0) {

        hours = 12;
    }


    return (
        `${hours}:${String(mins).padStart(2, "0")} ${period}`
    );
}


function formatTimeRange(
    start,
    end
) {

    if (
        !start &&
        !end
    ) {

        return "";
    }


    if (
        start &&
        end
    ) {

        return (
            `${formatDisplayTime(start)} - ${formatDisplayTime(end)}`
        );
    }


    return formatDisplayTime(
        start || end
    );
}


/* ==================================================
   DAY HELPERS
================================================== */

function itemBelongsToDay(
    item,
    dayNumber
) {

    if (!item) {
        return false;
    }


    if (
        item.dayNumber !== undefined
    ) {

        return (
            Number(item.dayNumber) ===
            Number(dayNumber)
        );
    }


    if (
        item.dayIndex !== undefined
    ) {

        return (
            Number(item.dayIndex) ===
            Number(dayNumber)
        );
    }


    if (
        item.day !== undefined
    ) {

        const day =
            String(
                item.day
            ).trim().toLowerCase();


        return (
            day ===
            String(dayNumber)
        ) ||
        day ===
        dayNames[dayNumber].toLowerCase() ||
        day ===
        englishDayNames[dayNumber];
    }


    if (
        item.dayName !== undefined
    ) {

        const day =
            String(
                item.dayName
            ).trim().toLowerCase();


        return (
            day ===
            dayNames[dayNumber].toLowerCase()
        ) ||
        day ===
        englishDayNames[dayNumber];
    }


    return false;
}


/* ==================================================
   ASSIGNMENT NORMALIZATION
================================================== */

function normalizeAssignment(
    value
) {

    if (
        value === null ||
        value === undefined
    ) {

        return null;
    }


    if (
        typeof value === "string"
    ) {

        const subject =
            value.trim();


        if (!subject) {
            return null;
        }


        return {

            subject,

            className: ""
        };
    }


    if (
        typeof value !== "object"
    ) {

        return null;
    }


    if (
        value.assignment !== undefined &&
        value.assignment !== value
    ) {

        const nested =
            normalizeAssignment(
                value.assignment
            );


        if (nested) {
            return nested;
        }
    }


    if (
        value.value !== undefined &&
        value.value !== value
    ) {

        const nested =
            normalizeAssignment(
                value.value
            );


        if (nested) {
            return nested;
        }
    }


    let subject =
        value.subject ??
        value.subjectName ??
        value.subjectTitle ??
        value.name ??
        value.title ??
        "";


    let className =
        value.className ??
        value.class ??
        value.classCode ??
        value.code ??
        "";


    if (
        subject &&
        typeof subject === "object"
    ) {

        subject =
            subject.name ??
            subject.subjectName ??
            subject.title ??
            "";
    }


    if (
        !className &&
        value.classId !== undefined
    ) {

        const classes =
            getClasses();


        const found =
            classes.find(
                cls =>
                    String(cls?.id) ===
                    String(value.classId)
            );


        if (found) {

            className =
                found.code ||
                buildClassCode(found);
        }
    }


    if (
        !className &&
        value.grade !== undefined
    ) {

        if (
            value.section !== undefined
        ) {

            className =
                `${value.grade}/${value.section}`;

        } else {

            className =
                String(value.grade);
        }
    }


    subject =
        String(
            subject || ""
        ).trim();


    className =
        String(
            className || ""
        ).trim();


    if (
        !subject &&
        !className
    ) {

        return null;
    }


    return {

        subject,

        className
    };
}


/* ==================================================
   ASSIGNMENT SEARCH
================================================== */

function findAssignment(
    assignments,
    dayNumber,
    column
) {

    if (
        !assignments ||
        !column
    ) {

        return null;
    }


    const columnId =
        String(
            column.id ??
            column.columnId ??
            column.key ??
            ""
        );


    const columnIndex =
        Number.isFinite(
            Number(column.index)
        )
            ? Number(column.index)
            : null;


    const dayName =
        dayNames[dayNumber];


    const englishDay =
        englishDayNames[dayNumber];


    const embeddedValues = [

        column.assignment,

        column.assignedTo,

        column.value,

        column.subject
            ? column
            : null

    ];


    for (
        const value of embeddedValues
    ) {

        const normalized =
            normalizeAssignment(
                value
            );


        if (normalized) {

            return normalized;
        }
    }


    if (
        Array.isArray(assignments)
    ) {

        const found =
            assignments.find(
                item => {

                    if (!item) {
                        return false;
                    }


                    if (
                        !itemBelongsToDay(
                            item,
                            dayNumber
                        )
                    ) {

                        return false;
                    }


                    const itemColumn =
                        String(
                            item.columnId ??
                            item.column ??
                            item.lessonId ??
                            item.columnKey ??
                            item.id ??
                            ""
                        );


                    return (
                        itemColumn ===
                        columnId
                    ) ||
                    (
                        columnIndex !== null &&
                        Number(
                            itemColumn
                        ) ===
                        columnIndex
                    );
                }
            );


        if (found) {

            return normalizeAssignment(
                found.assignment ??
                found.value ??
                found
            );
        }
    }


    const dayKeys = [

        dayNumber,

        String(dayNumber),

        dayName,

        englishDay,

        dayName.toLowerCase(),

        englishDay.toLowerCase()

    ];


    for (
        const dayKey of dayKeys
    ) {

        const dayAssignments =
            assignments[dayKey];


        if (
            !dayAssignments ||
            typeof dayAssignments !==
            "object"
        ) {

            continue;
        }


        const directKeys = [

            columnId,

            String(columnIndex),

            `column-${columnIndex}`,

            `lesson-${columnIndex}`

        ];


        for (
            const key of directKeys
        ) {

            if (
                key === "null" ||
                key === "undefined"
            ) {

                continue;
            }


            if (
                dayAssignments[key] !==
                undefined
            ) {

                const normalized =
                    normalizeAssignment(
                        dayAssignments[key]
                    );


                if (normalized) {

                    return normalized;
                }
            }
        }


        if (
            Array.isArray(
                dayAssignments
            )
        ) {

            const found =
                dayAssignments.find(
                    item => {

                        if (
                            !item ||
                            typeof item !==
                            "object"
                        ) {

                            return false;
                        }


                        const itemColumn =
                            String(
                                item.columnId ??
                                item.column ??
                                item.lessonId ??
                                item.id ??
                                ""
                            );


                        return (
                            itemColumn ===
                            columnId
                        );
                    }
                );


            if (found) {

                const normalized =
                    normalizeAssignment(
                        found.assignment ??
                        found.value ??
                        found
                    );


                if (normalized) {

                    return normalized;
                }
            }
        }
    }


    const keys = [

        `${dayNumber}-${columnId}`,

        `${dayNumber}_${columnId}`,

        `${dayNumber}:${columnId}`,

        `${dayNumber}.${columnId}`,

        `${dayName}-${columnId}`,

        `${dayName}_${columnId}`,

        `${dayName}:${columnId}`,

        `${englishDay}-${columnId}`,

        `${englishDay}_${columnId}`,

        `${englishDay}:${columnId}`

    ];


    for (
        const key of keys
    ) {

        if (
            assignments[key] !==
            undefined
        ) {

            const normalized =
                normalizeAssignment(
                    assignments[key]
                );


            if (normalized) {

                return normalized;
            }
        }
    }


    const targetColumn =
        String(columnId);


    if (
        !targetColumn
    ) {

        return null;
    }


    for (
        const key of Object.keys(
            assignments
        )
    ) {

        const value =
            assignments[key];


        const keyText =
            String(key).toLowerCase();


        const hasColumn =
            keyText.includes(
                targetColumn.toLowerCase()
            );


        const hasDay =
            keyText.includes(
                dayName.toLowerCase()
            ) ||
            keyText.includes(
                englishDay.toLowerCase()
            ) ||
            keyText.includes(
                String(dayNumber)
            );


        if (
            hasDay &&
            hasColumn
        ) {

            const normalized =
                normalizeAssignment(
                    value
                );


            if (normalized) {

                return normalized;
            }
        }
    }


    return null;
}


/* ==================================================
   COLUMNS
================================================== */

function getColumnsForToday(
    schedule,
    dayNumber
) {

    if (
        !schedule ||
        !Array.isArray(
            schedule.columns
        )
    ) {

        return [];
    }


    return schedule.columns
        .map(
            (column, index) => {

                if (
                    !column ||
                    typeof column !==
                    "object"
                ) {

                    return null;
                }


                if (
                    column.dayNumber !==
                        undefined ||
                    column.dayIndex !==
                        undefined ||
                    column.day !==
                        undefined ||
                    column.dayName !==
                        undefined
                ) {

                    if (
                        !itemBelongsToDay(
                            column,
                            dayNumber
                        )
                    ) {

                        return null;
                    }
                }


                if (
                    Array.isArray(
                        column.days
                    )
                ) {

                    const matches =
                        column.days.some(
                            day =>
                                Number(day) ===
                                Number(dayNumber) ||
                                String(day).toLowerCase() ===
                                dayNames[
                                    dayNumber
                                ].toLowerCase() ||
                                String(day).toLowerCase() ===
                                englishDayNames[
                                    dayNumber
                                ]
                        );


                    if (!matches) {

                        return null;
                    }
                }


                if (
                    Array.isArray(
                        column.dayNumbers
                    )
                ) {

                    const matches =
                        column.dayNumbers.some(
                            day =>
                                Number(day) ===
                                Number(dayNumber)
                        );


                    if (!matches) {

                        return null;
                    }
                }


                const type =
                    String(
                        column.type || ""
                    ).toLowerCase();


                return {

                    ...column,

                    id:
                        column.id ??
                        column.columnId ??
                        column.key ??
                        `column-${index}`,

                    index,

                    type:
                        type === "break"
                            ? "break"
                            : "lesson",

                    name:
                        column.name ??
                        column.title ??
                        (
                            type === "break"
                                ? "فسحة"
                                : `الحصة ${index + 1}`
                        )
                };
            }
        )
        .filter(Boolean);
}


/* ==================================================
   CALCULATE DAY TIMES
================================================== */

function calculateDayItems(
    columns,
    settings
) {

    const result = [];


    let cursor =
        timeToMinutes(
            settings.assemblyEndTime
        );


    if (cursor === null) {

        cursor = 450;
    }


    const lessonDuration =
        Number(
            settings.lessonDuration
        ) || 45;


    columns.forEach(
        (column, index) => {

            if (!column) {
                return;
            }


            if (
                column.type ===
                "break"
            ) {

                let duration =
                    Number(
                        column.duration
                    );


                if (
                    !Number.isFinite(
                        duration
                    ) ||
                    duration <= 0
                ) {

                    const oldStart =
                        timeToMinutes(
                            column.startTime ??
                            column.start
                        );


                    const oldEnd =
                        timeToMinutes(
                            column.endTime ??
                            column.end
                        );


                    if (
                        oldStart !== null &&
                        oldEnd !== null &&
                        oldEnd > oldStart
                    ) {

                        duration =
                            oldEnd -
                            oldStart;

                    } else {

                        duration =
                            20;
                    }
                }


                const start =
                    cursor;


                const end =
                    Math.min(
                        1439,
                        start +
                        duration
                    );


                result.push({

                    ...column,

                    index,

                    type:
                        "break",

                    start:
                        minutesToTime(
                            start
                        ),

                    end:
                        minutesToTime(
                            end
                        ),

                    duration:
                        Math.max(
                            0,
                            end - start
                        )
                });


                cursor =
                    end;

                return;
            }


            const start =
                cursor;


            const end =
                Math.min(
                    1439,
                    start +
                    lessonDuration
                );


            result.push({

                ...column,

                index,

                type:
                    "lesson",

                start:
                    minutesToTime(
                        start
                    ),

                end:
                    minutesToTime(
                        end
                    ),

                duration:
                    Math.max(
                        0,
                        end - start
                    )
            });


            cursor =
                end;
        }
    );


    return result;
}


/* ==================================================
   REMAINING TIME
================================================== */

function formatRemainingMinutes(
    minutes
) {

    const value =
        Number(minutes);


    if (
        !Number.isFinite(value) ||
        value <= 0
    ) {

        return "الآن";
    }


    if (
        value === 1
    ) {

        return "دقيقة";
    }


    if (
        value === 2
    ) {

        return "دقيقتان";
    }


    if (
        value >= 3 &&
        value <= 10
    ) {

        return `${value} دقائق`;
    }


    return `${value} دقيقة`;
}


/* ==================================================
   TIME STATE
================================================== */

function getTimeState(
    start,
    end
) {

    const startMinutes =
        timeToMinutes(start);

    const endMinutes =
        timeToMinutes(end);


    if (
        startMinutes === null ||
        endMinutes === null
    ) {

        return {

            state:
                "upcoming",

            progress:
                0,

            remainingText:
                "موعد الحصة"
        };
    }


    const now =
        new Date();


    const nowMinutes =
        now.getHours() * 60 +
        now.getMinutes() +
        (
            now.getSeconds() /
            60
        );


    if (
        nowMinutes <
        startMinutes
    ) {

        const remaining =
            Math.ceil(
                startMinutes -
                nowMinutes
            );


        return {

            state:
                "upcoming",

            progress:
                0,

            remainingText:
                `تبدأ بعد ${formatRemainingMinutes(remaining)}`
        };
    }


    if (
        nowMinutes <
        endMinutes
    ) {

        const duration =
            Math.max(
                1,
                endMinutes -
                startMinutes
            );


        const elapsed =
            nowMinutes -
            startMinutes;


        const progress =
            Math.max(
                0,
                Math.min(
                    100,
                    (
                        elapsed /
                        duration
                    ) * 100
                )
            );


        const remaining =
            Math.ceil(
                endMinutes -
                nowMinutes
            );


        return {

            state:
                "current",

            progress,

            remainingText:
                remaining <= 1
                    ? "متبقي أقل من دقيقة"
                    : `متبقي ${formatRemainingMinutes(remaining)}`
        };
    }


    return {

        state:
            "finished",

        progress:
            100,

        remainingText:
            "انتهت الحصة"
    };
}


/* ==================================================
   ASSEMBLY STATE
================================================== */

function getAssemblyState(
    settings
) {

    const start =
        timeToMinutes(
            settings.assemblyStartTime
        );

    const end =
        timeToMinutes(
            settings.assemblyEndTime
        );


    if (
        start === null ||
        end === null
    ) {

        return {

            state:
                "upcoming",

            progress:
                0,

            remainingText:
                "بداية اليوم"
        };
    }


    const now =
        new Date();


    const nowMinutes =
        now.getHours() * 60 +
        now.getMinutes() +
        now.getSeconds() / 60;


    if (
        nowMinutes <
        start
    ) {

        const remaining =
            Math.ceil(
                start -
                nowMinutes
            );


        return {

            state:
                "upcoming",

            progress:
                0,

            remainingText:
                `يبدأ بعد ${formatRemainingMinutes(remaining)}`
        };
    }


    if (
        nowMinutes <
        end
    ) {

        const duration =
            Math.max(
                1,
                end - start
            );


        const elapsed =
            nowMinutes -
            start;


        const progress =
            Math.max(
                0,
                Math.min(
                    100,
                    (
                        elapsed /
                        duration
                    ) * 100
                )
            );


        const remaining =
            Math.ceil(
                end -
                nowMinutes
            );


        return {

            state:
                "current",

            progress,

            remainingText:
                remaining <= 1
                    ? "متبقي أقل من دقيقة"
                    : `متبقي ${formatRemainingMinutes(remaining)}`
        };
    }


    return {

        state:
            "finished",

        progress:
            100,

        remainingText:
            "انتهى الطابور"
    };
}


/* ==================================================
   ASSEMBLY CARD
================================================== */

function createAssemblyCard(
    settings
) {

    const card =
        document.createElement(
            "article"
        );


    const state =
        getAssemblyState(
            settings
        );


    card.className =
        "lesson-card assembly-card " +
        state.state;


    card.dataset.kind =
        "assembly";


    card.dataset.start =
        settings.assemblyStartTime;


    card.dataset.end =
        settings.assemblyEndTime;


    const duration =
        Math.max(
            0,
            (
                timeToMinutes(
                    settings.assemblyEndTime
                ) -
                timeToMinutes(
                    settings.assemblyStartTime
                )
            )
        );


    const stateLabel =
        state.state === "current"
            ? "الطابور الآن"
            : state.state === "finished"
                ? "انتهى الطابور"
                : "بداية اليوم";


    card.innerHTML = `

        <div class="lesson-top">

            <span class="lesson-number">
                طابور الصباح
            </span>

            <span
                class="lesson-state ${state.state}"
                data-role="state"
            >
                ${escapeHTML(stateLabel)}
            </span>

        </div>


        <div class="lesson-info">

            <div class="lesson-name">
                صباح الخير معلمي
            </div>


            <div class="lesson-class">
                مُعين معك... ابدأ يومك بهدوء وثقة، ونحن هنا لدعمك في يومك خطوة بخطوة 🌿
            </div>


            <div
                class="lesson-time"
                dir="ltr"
            >
                ${escapeHTML(
                    formatTimeRange(
                        settings.assemblyStartTime,
                        settings.assemblyEndTime
                    )
                )}
            </div>


            <div class="lesson-progress">

                <div
                    class="lesson-progress-bar"
                    data-role="progress"
                    style="width:${state.progress}%"
                ></div>

            </div>

        </div>


        <div class="lesson-footer">

            <span
                class="lesson-remaining"
                data-role="remaining"
            >
                ${escapeHTML(
                    state.remainingText
                )}
            </span>


            <span class="lesson-duration">
                ${escapeHTML(
                    String(duration)
                )}
                دقيقة
            </span>

        </div>

    `;


    return card;
}


/* ==================================================
   LESSON CARD
================================================== */

function createLessonCard(
    data
) {

    const card =
        document.createElement(
            "article"
        );


    const assignment =
        normalizeAssignment(
            data.assignment
        );


    const rawSubject =
        assignment?.subject ||
        data.subject ||
        "";


    const rawClassName =
        assignment?.className ||
        data.className ||
        "";


    const hasAssignment =
        !!(
            String(
                rawSubject || ""
            ).trim() ||
            String(
                rawClassName || ""
            ).trim()
        );


    const subject =
        hasAssignment
            ? (
                String(
                    rawSubject || ""
                ).trim() ||
                "المادة"
            )
            : "حصة فارغة ☕";


    const className =
        hasAssignment
            ? (
                String(
                    rawClassName || ""
                ).trim() ||
                "الصف غير محدد"
            )
            : "خذ نفسًا عميقًا واستمتع ببضع دقائق من الراحة… تستحقها.";


    const state =
        getTimeState(
            data.start,
            data.end
        );


    card.className =
        "lesson-card " +
        state.state +
        (
            hasAssignment
                ? ""
                : " empty"
        );


    card.dataset.kind =
        "lesson";


    card.dataset.start =
        data.start;


    card.dataset.end =
        data.end;


    card.dataset.lessonIndex =
        String(
            data.lessonIndex ?? ""
        );


    card.dataset.hasAssignment =
        hasAssignment
            ? "true"
            : "false";


    const title =
        data.title ||
        `الحصة ${data.number}`;


    const stateLabel =
        state.state === "current"
            ? "جارية الآن"
            : state.state === "finished"
                ? "انتهت الحصة"
                : "قادمة";


    card.innerHTML = `

        <div class="lesson-top">

            <span class="lesson-number">
                ${escapeHTML(title)}
            </span>


            <span
                class="lesson-state ${state.state}"
                data-role="state"
            >
                ${escapeHTML(stateLabel)}
            </span>

        </div>


        <div class="lesson-info">

            <div
                class="lesson-time"
                dir="ltr"
            >
                ${escapeHTML(
                    formatTimeRange(
                        data.start,
                        data.end
                    )
                )}
            </div>


            <div class="lesson-name">
                ${escapeHTML(subject)}
            </div>


            <div class="lesson-class">
                ${escapeHTML(className)}
            </div>


            <div class="lesson-progress">

                <div
                    class="lesson-progress-bar"
                    data-role="progress"
                    style="width:${state.progress}%"
                ></div>

            </div>

        </div>


        <div class="lesson-footer">

            <span
                class="lesson-remaining"
                data-role="remaining"
            >
                ${escapeHTML(
                    state.remainingText
                )}
            </span>


            <span class="lesson-duration">

                ${escapeHTML(
                    String(
                        data.duration || ""
                    )
                )}
                دقيقة

            </span>

        </div>

    `;


    return card;
}


/* ==================================================
   BREAK CARD
================================================== */

function createBreakCard(
    data
) {

    const card =
        document.createElement(
            "article"
        );


    const state =
        getTimeState(
            data.start,
            data.end
        );


    card.className =
        "lesson-card break-card " +
        state.state;


    card.dataset.kind =
        "break";


    card.dataset.start =
        data.start;


    card.dataset.end =
        data.end;


    const stateLabel =
        state.state === "current"
            ? "استراحة الآن"
            : state.state === "finished"
                ? "انتهت الفسحة"
                : "فسحة قادمة";


    card.innerHTML = `

        <div class="lesson-top">

            <span class="lesson-number">
                ${escapeHTML(
                    data.name ||
                    "فسحة"
                )}
            </span>


            <span
                class="lesson-state ${state.state}"
                data-role="state"
            >
                ${escapeHTML(stateLabel)}
            </span>

        </div>


        <div class="lesson-info">

            <div
                class="lesson-time"
                dir="ltr"
            >
                ${escapeHTML(
                    formatTimeRange(
                        data.start,
                        data.end
                    )
                )}
            </div>


            <div class="lesson-name">
                وقت الفسحة
            </div>


            <div class="lesson-class">
                استراحة قصيرة قبل متابعة اليوم
            </div>


            <div class="lesson-progress">

                <div
                    class="lesson-progress-bar"
                    data-role="progress"
                    style="width:${state.progress}%"
                ></div>

            </div>

        </div>


        <div class="lesson-footer">

            <span
                class="lesson-remaining"
                data-role="remaining"
            >
                ${escapeHTML(
                    state.remainingText
                )}
            </span>


            <span class="lesson-duration">

                ${escapeHTML(
                    String(
                        data.duration ||
                        ""
                    )
                )}
                دقيقة

            </span>

        </div>

    `;


    return card;
}


/* ==================================================
   VACATION CARD
================================================== */

function createVacationCard() {

    const card =
        document.createElement(
            "article"
        );


    card.className =
        "schedule-empty-card vacation-card";


    card.dataset.kind =
        "vacation";


    card.innerHTML = `

        <div class="empty-title">
            إجازة سعيدة 🌿
        </div>


        <div class="empty-description">
            انتهى الترم الدراسي، خذ وقتك للراحة والاستمتاع.
        </div>


        <div class="empty-description">
            نلتقي مع بداية الترم الجديد بإذن الله.
        </div>

    `;


    return card;
}


/* ==================================================
   RENDER VACATION
================================================== */

function renderVacationSchedule(
    list
) {

    if (!list) {
        return;
    }


    list.innerHTML = "";


    list.dataset.schoolDayFinished =
        "false";


    list.dataset.vacation =
        "true";


    window.__mueenCurrentScheduleCard =
        null;


    window.__mueenNextScheduleCard =
        null;


    window.__mueenLastFocusedScheduleCard =
        null;


    list.appendChild(
        createVacationCard()
    );
}


/* ==================================================
   END OF SCHOOL DAY CARD
================================================== */

function createEndOfDayCard() {

    const card =
        document.createElement(
            "article"
        );


    card.className =
        "schedule-empty-card end-of-day-card";


    card.innerHTML = `

        <div class="empty-title">
            انتهى اليوم الدراسي 🌿
        </div>


        <div class="empty-description">
            أحسنت، لقد أنجزت يومًا جديدًا.
        </div>


        <div class="empty-description">
            مُعين معك دائمًا، خطوة بخطوة.
        </div>


        <div class="empty-description">
            نلتقي غدًا بإذن الله 🤍
        </div>


        <div class="empty-description">
            أتمنى لك يومًا جميلًا وهادئًا.
        </div>

    `;


    return card;
}


/* ==================================================
   SHOULD SHOW END OF DAY
================================================== */

function isSchoolDayFinished(
    dayItems
) {

    if (
        !Array.isArray(dayItems) ||
        !dayItems.length
    ) {

        return false;
    }


    const lessons =
        dayItems.filter(
            item =>
                item &&
                item.type ===
                "lesson"
        );


    if (!lessons.length) {

        return false;
    }


    const lastLesson =
        lessons[
            lessons.length - 1
        ];


    const endMinutes =
        timeToMinutes(
            lastLesson.end
        );


    if (endMinutes === null) {

        return false;
    }


    const now =
        new Date();


    const nowMinutes =
        now.getHours() * 60 +
        now.getMinutes() +
        now.getSeconds() / 60;


    return (
        nowMinutes >=
        endMinutes
    );
}


/* ==================================================
   RENDER END OF DAY
================================================== */

function renderEndOfDay(
    list
) {

    if (!list) {
        return;
    }


    list.innerHTML = "";


    window.__mueenCurrentScheduleCard =
        null;


    window.__mueenNextScheduleCard =
        null;


    window.__mueenLastFocusedScheduleCard =
        null;


    list.appendChild(
        createEndOfDayCard()
    );


    list.dataset.schoolDayFinished =
        "true";


    list.dataset.vacation =
        "false";
}


/* ==================================================
   LEGACY SCHEDULE
================================================== */

function renderLegacySchedule(
    list,
    schedule
) {

    const oldItems =
        Array.isArray(
            schedule?.legacyItems
        )
            ? schedule.legacyItems
            : [];


    if (!oldItems.length) {

        return false;
    }


    const day =
        getToday().getDay();


    const todayItems =
        oldItems.filter(
            item =>
                itemBelongsToDay(
                    item,
                    day
                )
        );


    const items =
        todayItems.length
            ? todayItems
            : oldItems;


    items.forEach(
        (lesson, index) => {

            const subject =
                lesson.subject ??
                lesson.subjectName ??
                lesson.name ??
                lesson.title ??
                "";


            const className =
                lesson.className ??
                lesson.class ??
                lesson.classCode ??
                lesson.code ??
                lesson.grade ??
                "";


            const start =
                lesson.start ??
                lesson.startTime ??
                "";


            const end =
                lesson.end ??
                lesson.endTime ??
                "";


            const number =
                lesson.number ??
                lesson.lessonNumber ??
                index + 1;


            const assignment =
                normalizeAssignment(
                    lesson.assignment ??
                    {
                        subject,
                        className
                    }
                );


            const duration =
                start &&
                end &&
                timeToMinutes(end) !== null &&
                timeToMinutes(start) !== null
                    ? Math.max(
                        0,
                        timeToMinutes(end) -
                        timeToMinutes(start)
                    )
                    : 0;


            const card =
                createLessonCard({

                    number,

                    title:
                        `الحصة ${number}`,

                    subject,

                    className,

                    start,

                    end,

                    duration,

                    assignment,

                    lessonIndex:
                        index
                });


            list.appendChild(
                card
            );
        }
    );


    return true;
}


/* ==================================================
   RENDER EMPTY
================================================== */

function renderScheduleEmpty(
    list,
    title,
    description
) {

    const empty =
        document.createElement(
            "article"
        );


    empty.className =
        "schedule-empty-card";


    empty.innerHTML = `

        <div class="empty-title">
            ${escapeHTML(title)}
        </div>


        <div class="empty-description">
            ${escapeHTML(description)}
        </div>

    `;


    list.appendChild(
        empty
    );
}


/* ==================================================
   RENDER CURRENT SCHEDULE
================================================== */

function renderSchedule() {

    const list =
        $("scheduleList");


    if (!list) {
        return;
    }


    /*
     * الإجازة لها أولوية كاملة.
     *
     * لا نقرأ الجدول ولا نعرض:
     * - بطاقات الحصص
     * - الطابور
     * - لا توجد حصص
     * - انتهى اليوم الدراسي
     *
     * إلا إذا كان الترم مستمرًا.
     */

    if (isVacationMode()) {

        renderVacationSchedule(
            list
        );

        return;
    }


    list.innerHTML = "";


    list.dataset.schoolDayFinished =
        "false";


    list.dataset.vacation =
        "false";


    window.__mueenCurrentScheduleCard =
        null;

    window.__mueenNextScheduleCard =
        null;


    const schedule =
        getCurrentSchedule();


    /*
     * لا يوجد جدول.
     */

    if (!schedule) {

        renderScheduleEmpty(
            list,
            "لم تتم إضافة جدول بعد",
            "يمكنك إدارة جدولك من صفحة حصصي"
        );

        return;
    }


    /*
     * دعم الجدول القديم.
     */

    if (
        Array.isArray(
            schedule.legacyItems
        )
    ) {

        const rendered =
            renderLegacySchedule(
                list,
                schedule
            );


        if (rendered) {

            requestAnimationFrame(
                () => {

                    updateScheduleProgress();

                    focusCurrentScheduleCard();

                }
            );

            return;
        }
    }


    const today =
        getToday().getDay();


    /*
     * الجمعة والسبت.
     */

    if (
        today === 5 ||
        today === 6
    ) {

        renderScheduleEmpty(
            list,
            "لا توجد حصص اليوم",
            "نتمنى لك يومًا هادئًا وسعيدًا 🌿"
        );

        return;
    }


    const columns =
        getColumnsForToday(
            schedule,
            today
        );


    if (!columns.length) {

        renderScheduleEmpty(
            list,
            "لا توجد حصص اليوم",
            "يمكنك تعديل جدول اليوم من صفحة حصصي"
        );

        return;
    }


    const settings =
        getScheduleSettings();


    const dayItems =
        calculateDayItems(
            columns,
            settings
        );


    if (
        isSchoolDayFinished(
            dayItems
        )
    ) {

        renderEndOfDay(
            list
        );

        return;
    }


    /*
     * طابور الصباح أولًا.
     */

    list.appendChild(
        createAssemblyCard(
            settings
        )
    );


    let lessonNumber =
        0;


    dayItems.forEach(
        item => {

            /*
             * الفسحة.
             */

            if (
                item.type ===
                "break"
            ) {

                list.appendChild(
                    createBreakCard({

                        name:
                            item.name ||
                            "فسحة",

                        start:
                            item.start,

                        end:
                            item.end,

                        duration:
                            item.duration
                    })
                );


                return;
            }


            /*
             * الحصة.
             *
             * الحصة الفارغة لا تُحذف.
             */

            lessonNumber += 1;


            const assignment =
                findAssignment(
                    schedule.assignments,
                    today,
                    item
                );


            list.appendChild(
                createLessonCard({

                    number:
                        lessonNumber,

                    title:
                        `الحصة ${lessonNumber}`,

                    subject:
                        assignment?.subject ||
                        "",

                    className:
                        assignment?.className ||
                        "",

                    start:
                        item.start,

                    end:
                        item.end,

                    duration:
                        item.duration,

                    assignment,

                    lessonIndex:
                        lessonNumber - 1
                })
            );
        }
    );


    if (
        !dayItems.length
    ) {

        renderScheduleEmpty(
            list,
            "لا توجد حصص اليوم",
            "يمكنك تعديل جدول اليوم من صفحة حصصي"
        );

        return;
    }


    requestAnimationFrame(
        () => {

            updateScheduleProgress();

            focusCurrentScheduleCard();

        }
    );
}


/* ==================================================
   UPDATE ASSEMBLY LIVE STATE
================================================== */

function updateAssemblyLiveState() {

    const list =
        $("scheduleList");


    if (!list) {
        return;
    }


    if (isVacationMode()) {
        return;
    }


    const card =
        list.querySelector(
            '[data-kind="assembly"]'
        );


    if (!card) {
        return;
    }


    const start =
        card.dataset.start;


    const end =
        card.dataset.end;


    const state =
        getAssemblyState({

            assemblyStartTime:
                start,

            assemblyEndTime:
                end
        });


    card.classList.remove(
        "current",
        "upcoming",
        "finished"
    );


    card.classList.add(
        state.state
    );


    const progressBar =
        card.querySelector(
            '[data-role="progress"]'
        );


    if (progressBar) {

        progressBar.style.width =
            `${state.progress}%`;
    }


    const remaining =
        card.querySelector(
            '[data-role="remaining"]'
        );


    if (remaining) {

        remaining.textContent =
            state.remainingText;
    }


    const stateElement =
        card.querySelector(
            '[data-role="state"]'
        );


    if (stateElement) {

        const text =
            state.state === "current"
                ? "الطابور الآن"
                : state.state === "finished"
                    ? "انتهى الطابور"
                    : "بداية اليوم";


        stateElement.textContent =
            text;


        stateElement.className =
            `lesson-state ${state.state}`;
    }
}


/* ==================================================
   UPDATE SCHEDULE PROGRESS
================================================== */

function updateScheduleProgress() {

    const list =
        $("scheduleList");


    if (!list) {
        return;
    }


    /*
     * لا توجد تحديثات زمنية
     * أثناء الإجازة.
     */

    if (isVacationMode()) {

        return;
    }


    if (
        list.dataset.schoolDayFinished ===
        "true"
    ) {

        return;
    }


    updateAssemblyLiveState();


    const cards =
        Array.from(
            list.querySelectorAll(
                ".lesson-card"
            )
        );


    let currentLesson =
        null;


    let nextLesson =
        null;


    let nextStart =
        Infinity;


    cards.forEach(
        card => {

            const kind =
                card.dataset.kind;


            if (
                kind ===
                "assembly"
            ) {

                return;
            }


            const start =
                card.dataset.start;


            const end =
                card.dataset.end;


            if (
                !start ||
                !end
            ) {

                return;
            }


            const state =
                getTimeState(
                    start,
                    end
                );


            card.classList.remove(
                "current",
                "upcoming",
                "finished",
                "next-lesson"
            );


            card.classList.add(
                state.state
            );


            if (
                kind === "lesson" &&
                state.state === "current"
            ) {

                currentLesson =
                    card;
            }


            if (
                kind === "lesson" &&
                state.state === "upcoming"
            ) {

                const startMinutes =
                    timeToMinutes(
                        start
                    );


                if (
                    startMinutes !== null &&
                    startMinutes <
                    nextStart
                ) {

                    nextStart =
                        startMinutes;

                    nextLesson =
                        card;
                }
            }


            const progressBar =
                card.querySelector(
                    '[data-role="progress"]'
                );


            if (progressBar) {

                progressBar.style.width =
                    `${state.progress}%`;
            }


            const remaining =
                card.querySelector(
                    '[data-role="remaining"]'
                );


            if (remaining) {

                remaining.textContent =
                    state.remainingText;
            }


            const stateElement =
                card.querySelector(
                    '[data-role="state"]'
                );


            if (stateElement) {

                if (
                    kind === "break"
                ) {

                    stateElement.textContent =
                        state.state === "current"
                            ? "استراحة الآن"
                            : state.state === "finished"
                                ? "انتهت الفسحة"
                                : "فسحة قادمة";

                } else {

                    stateElement.textContent =
                        state.state === "current"
                            ? "جارية الآن"
                            : state.state === "finished"
                                ? "انتهت الحصة"
                                : "قادمة";
                }


                stateElement.className =
                    `lesson-state ${state.state}`;
            }
        }
    );


    nextLesson =
        cards
            .filter(
                card =>
                    card.dataset.kind ===
                    "lesson" &&
                    card.classList.contains(
                        "upcoming"
                    )
            )
            .sort(
                (a, b) => {

                    const aStart =
                        timeToMinutes(
                            a.dataset.start
                        );


                    const bStart =
                        timeToMinutes(
                            b.dataset.start
                        );


                    return (
                        (aStart ?? Infinity) -
                        (bStart ?? Infinity)
                    );
                }
            )[0] || null;


    if (
        nextLesson &&
        nextLesson !== currentLesson
    ) {

        nextLesson.classList.add(
            "next-lesson"
        );
    }


    window.__mueenCurrentScheduleCard =
        currentLesson;


    window.__mueenNextScheduleCard =
        nextLesson;


    const currentReference =
        currentLesson ||
        nextLesson;


    if (
        currentReference &&
        window.__mueenLastFocusedScheduleCard !==
            currentReference
    ) {

        window.__mueenLastFocusedScheduleCard =
            currentReference;


        focusCurrentScheduleCard(
            currentReference
        );
    }


    checkSchoolDayEnd();
}


/* ==================================================
   CHECK SCHOOL DAY END
================================================== */

function checkSchoolDayEnd() {

    const list =
        $("scheduleList");


    if (!list) {
        return;
    }


    if (isVacationMode()) {
        return;
    }


    if (
        list.dataset.schoolDayFinished ===
        "true"
    ) {

        return;
    }


    const lessonCards =
        Array.from(
            list.querySelectorAll(
                '[data-kind="lesson"]'
            )
        );


    if (!lessonCards.length) {

        return;
    }


    const lastLesson =
        lessonCards[
            lessonCards.length - 1
        ];


    const endMinutes =
        timeToMinutes(
            lastLesson.dataset.end
        );


    if (endMinutes === null) {

        return;
    }


    const now =
        new Date();


    const nowMinutes =
        now.getHours() * 60 +
        now.getMinutes() +
        now.getSeconds() / 60;


    if (
        nowMinutes >=
        endMinutes
    ) {

        renderEndOfDay(
            list
        );
    }
}


/* ==================================================
   FOCUS CURRENT / NEXT CARD
================================================== */

function focusCurrentScheduleCard(
    preferredTarget
) {

    const list =
        $("scheduleList");


    if (!list) {
        return;
    }


    if (isVacationMode()) {
        return;
    }


    const current =
        preferredTarget ||
        window.__mueenCurrentScheduleCard;


    const next =
        window.__mueenNextScheduleCard;


    const target =
        current ||
        next;


    if (!target) {
        return;
    }


    setTimeout(
        () => {

            try {

                target.scrollIntoView({

                    behavior:
                        "smooth",

                    block:
                        "nearest",

                    inline:
                        "center"

                });

            } catch (error) {

                const listRect =
                    list.getBoundingClientRect();


                const cardRect =
                    target.getBoundingClientRect();


                const offset =
                    (
                        cardRect.left +
                        cardRect.width / 2
                    ) -
                    (
                        listRect.left +
                        listRect.width / 2
                    );


                list.scrollLeft +=
                    offset;
            }

        },
        180
    );
}


/* ==================================================
   ESCAPE HTML
================================================== */

function escapeHTML(value) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


/* ==================================================
   MAIN NAVIGATION
================================================== */

function goMain(page) {

    window.location.replace(
        page
    );
}


/* ==================================================
   SERVICE NAVIGATION
================================================== */

function goServicePage(page) {

    window.location.href =
        page;
}


/* ==================================================
   SUB PAGE NAVIGATION
================================================== */

function goSubPage(page) {

    window.location.href =
        page;
}


/* ==================================================
   BOTTOM NAVIGATION
================================================== */

$("homeNavigation")?.addEventListener(
    "click",
    () => {

        const currentPage =
            window.location.pathname
                .split("/")
                .pop()
                .toLowerCase();


        if (
            currentPage ===
                "home.html" ||
            currentPage === ""
        ) {

            return;
        }


        goMain(
            "home.html"
        );
    }
);


$("attendanceNavigation")?.addEventListener(
    "click",
    () =>
        goMain(
            "attendance.html"
        )
);


$("studentsNavigation")?.addEventListener(
    "click",
    () =>
        goMain(
            "students.html"
        )
);


$("scheduleNavigation")?.addEventListener(
    "click",
    () =>
        goMain(
            "schedule.html"
        )
);


$("gradesNavigation")?.addEventListener(
    "click",
    () =>
        goMain(
            "grades.html"
        )
);


$("reportsNavigation")?.addEventListener(
    "click",
    () =>
        goMain(
            "reports.html"
        )
);


/* ==================================================
   SERVICE BUTTONS
================================================== */

$("studentsButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "students.html"
        )
);


$("attendanceButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "attendance.html"
        )
);


$("gradesButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "grades.html"
        )
);


$("reportsButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "reports.html"
        )
);


$("scheduleButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "schedule.html"
        )
);


$("scheduleServiceButton")?.addEventListener(
    "click",
    () =>
        goServicePage(
            "schedule.html"
        )
);


/* ==================================================
   SETTINGS
================================================== */

$("settingsButton")?.addEventListener(
    "click",
    () => {

        goSubPage(
            "settings.html"
        );
    }
);


/* ==================================================
   DATE EDIT
================================================== */

$("editDateButton")?.addEventListener(
    "click",
    () => {

        const selected =
            prompt(
                "أدخل التاريخ بالصيغة: YYYY-MM-DD",
                getTodayISO()
            );


        if (!selected) {
            return;
        }


        if (
            /^\d{4}-\d{2}-\d{2}$/.test(
                selected
            )
        ) {

            localStorage.setItem(
                "mueen_home_selected_date",
                selected
            );


            updateSelectedDate(
                selected
            );

        } else {

            alert(
                "صيغة التاريخ غير صحيحة."
            );
        }
    }
);


function updateSelectedDate(
    iso
) {

    const parts =
        String(iso)
            .split("-")
            .map(Number);


    if (
        parts.length !== 3 ||
        parts.some(
            Number.isNaN
        )
    ) {

        updateDate();

        return;
    }


    const date =
        new Date(
            parts[0],
            parts[1] - 1,
            parts[2]
        );


    const todayDate =
        $("todayDate");


    const hijriDate =
        $("hijriDate");


    if (todayDate) {

        todayDate.textContent =
            `${dayNames[date.getDay()]}، ${date.getDate()} ${monthNames[date.getMonth()]} ${date.getFullYear()}`;
    }


    if (hijriDate) {

        try {

            const formatter =
                new Intl.DateTimeFormat(
                    "ar-SA-u-ca-islamic",
                    {
                        day: "numeric",
                        month: "long",
                        year: "numeric"
                    }
                );


            hijriDate.textContent =
                formatter.format(date);

        } catch (error) {

            hijriDate.textContent =
                "التاريخ الهجري";
        }
    }
}


/* ==================================================
   REFRESH SCHEDULE
================================================== */

function refreshHomeSchedule() {

    updateAttendanceSummary();

    renderSchedule();

    updateClock();
}


/* ==================================================
   INITIALIZATION
================================================== */

function initHome() {

    const savedDate =
        localStorage.getItem(
            "mueen_home_selected_date"
        );


    if (savedDate) {

        updateSelectedDate(
            savedDate
        );

    } else {

        updateDate();
    }


    updateClock();


    updateAttendanceSummary();


    renderSchedule();


    /*
     * الساعة.
     */

    setInterval(
        updateClock,
        1000
    );


    /*
     * تحديث حالة الجدول
     * والتقدم كل ثانية.
     */

    setInterval(
        updateScheduleProgress,
        1000
    );


    /*
     * التخزين المشترك.
     *
     * تمت إضافة حالة الترم حتى تتغير
     * الصفحة الرئيسية فورًا عند تغييرها
     * من صفحة الإعدادات.
     */

    window.addEventListener(
        "storage",
        event => {

            if (
                !event.key ||
                event.key ===
                    CLASSES_STORAGE_KEY ||
                event.key ===
                    ATTENDANCE_STORAGE_KEY ||
                event.key ===
                    SCHEDULE_CURRENT_STORAGE_KEY ||
                event.key ===
                    SCHEDULE_SETTINGS_STORAGE_KEY ||
                event.key ===
                    SCHEDULE_STORAGE_KEY ||
                event.key ===
                    TERM_STATUS_STORAGE_KEY
            ) {

                refreshHomeSchedule();
            }
        }
    );


    /*
     * عند العودة من صفحة أخرى.
     */

    document.addEventListener(
        "visibilitychange",
        () => {

            if (
                document.visibilityState ===
                "visible"
            ) {

                refreshHomeSchedule();
            }
        }
    );


    /*
     * عند الرجوع للصفحة بواسطة
     * زر الرجوع في الهاتف.
     */

    window.addEventListener(
        "pageshow",
        () => {

            refreshHomeSchedule();
        }
    );
}


document.addEventListener(
    "DOMContentLoaded",
    initHome
);