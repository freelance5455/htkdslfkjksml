(function () {
  var A = window.App, $ = A.$, esc = A.esc;
  if (!A.init({ nav: 'home' })) return;
  var query = '', filter = 'all';
  var FILTERS = { all: 'Tümü', online: 'Çevrimiçi', unread: 'Okunmamış', best: 'En iyi arkadaşlar' };

  function greet() {
    var h = new Date().getHours();
    return h >= 5 && h < 11 ? 'GÜNAYDIN' : h < 18 ? 'İYİ GÜNLER' : h < 23 ? 'İYİ AKŞAMLAR' : 'İYİ GECELER';
  }
  function header() {
    var u = A.me();
    $('#greet').textContent = greet() + ' 👋';
    $('#hdr-name').textContent = u.name;
    $('#hdr-avatar').src = A.avatar(u);
  }
  function preview(f) {
    var m = A.lastMsg(f.id);
    if (!m) return 'Sohbeti başlat 👋';
    var p = m.from === A.me().id ? 'Sen: ' : '';
    if (m.type === 'image') return p + '📷 Fotoğraf';
    if (m.type === 'file') return p + '📎 ' + m.name;
    if (m.type === 'voice') return p + '🎤 Sesli mesaj';
    if (m.type === 'location') return p + '📍 Canlı konum';
    if (m.type === 'call') return (m.video ? '📹 ' : '📞 ') + m.text;
    return p + m.text;
  }
  function sortKey(f) { var m = A.lastMsg(f.id); return m ? m.ts : f.addedAt; }

  function renderStrip() {
    var list = A.friends().sort(function (a, b) { return (b.online - a.online) || (b.best - a.best) || (b.addedAt - a.addedAt); });
    var html = '<button type="button" id="strip-add" class="shrink-0 w-[68px] text-center"><div class="mx-auto mb-2 size-16 rounded-full border-2 border-dashed border-primary text-primary flex items-center justify-center bg-primary/10"><iconify-icon icon="solar:user-plus-bold" width="26" height="26"></iconify-icon></div><p class="text-xs font-bold text-primary">Ekle</p></button>';
    html += list.map(function (f) {
      var ring = f.online ? 'bg-accent' : f.best ? 'bg-primary' : 'bg-muted';
      return '<a href="chat.html?id=' + encodeURIComponent(f.id) + '" class="shrink-0 w-[68px] text-center ' + (f.online ? '' : 'opacity-80') + '">' +
        '<div class="relative mx-auto mb-2 size-16 rounded-full p-1 ' + ring + '"><img src="' + A.avatar(f) + '" class="size-full rounded-full object-cover border-2 border-background" alt="" />' +
        '<span class="absolute right-0 bottom-0 size-4 rounded-full border-2 border-card ' + (f.online ? 'bg-accent' : 'bg-muted-foreground') + '"></span></div>' +
        '<p class="text-xs font-bold truncate">' + esc(f.name.split(' ')[0]) + '</p></a>';
    }).join('');
    $('#strip').innerHTML = html;
    $('#strip-add').addEventListener('click', function () { A.openAddFriend(); });
    $('#strip-sub').textContent = list.length ? list.filter(function (f) { return f.online; }).length + ' kişi çevrimiçi' : 'Henüz kimse yok';
    $('#strip-empty').classList.toggle('hidden', !!list.length);
  }

  function renderChats() {
    var all = A.friends(), q = query.trim().toLocaleLowerCase('tr-TR');
    var list = all.filter(function (f) {
      if (filter === 'online' && !f.online) return false;
      if (filter === 'unread' && !A.unread(f.id)) return false;
      if (filter === 'best' && !f.best) return false;
      if (q && (f.name + ' ' + f.username + ' ' + preview(f)).toLocaleLowerCase('tr-TR').indexOf(q) < 0) return false;
      return true;
    }).sort(function (a, b) { return sortKey(b) - sortKey(a); });
    $('#chat-count').textContent = all.filter(function (f) { return f.online; }).length + ' aktif';
    var chip = $('#filter-chip');
    chip.style.display = filter === 'all' ? 'none' : 'inline-flex';
    chip.querySelector('span').textContent = FILTERS[filter];
    var box = $('#chat-list');
    if (!all.length) {
      box.innerHTML = '<div class="text-center py-10 px-6 rounded-2xl bg-card border border-dashed border-border"><div class="size-14 rounded-full bg-primary/15 text-primary mx-auto flex items-center justify-center mb-3"><iconify-icon icon="solar:users-group-rounded-linear" width="28" height="28"></iconify-icon></div><p class="font-heading font-extrabold">Henüz sohbetin yok</p><p class="text-xs text-muted-foreground font-semibold mt-1 mb-4">Arkadaş ekle, sohbetler burada görünsün.</p><button type="button" id="empty-add" class="h-11 px-5 rounded-2xl bg-primary text-primary-foreground text-sm font-extrabold">Arkadaş ekle</button></div>';
      $('#empty-add').addEventListener('click', function () { A.openAddFriend(); });
      return;
    }
    if (!list.length) {
      box.innerHTML = '<p class="text-center text-sm font-semibold text-muted-foreground py-8">Eşleşen sohbet yok.</p>';
      return;
    }
    box.innerHTML = list.map(function (f) {
      var n = A.unread(f.id), m = A.lastMsg(f.id);
      return '<a href="chat.html?id=' + encodeURIComponent(f.id) + '" class="w-full flex items-center gap-3.5 p-3 rounded-2xl bg-card border border-border text-left">' +
        '<div class="relative shrink-0"><img src="' + A.avatar(f) + '" class="size-14 rounded-full object-cover ring-4 ' + (f.best ? 'ring-primary/20' : 'ring-secondary/70') + '" alt="" />' +
        '<span class="absolute right-0 bottom-0 size-3.5 rounded-full border-2 border-card ' + (f.online ? 'bg-accent' : 'bg-muted-foreground') + '"></span>' +
        (f.best ? '<span class="absolute -top-1 -left-1 size-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[10px]">♥</span>' : '') + '</div>' +
        '<div class="min-w-0 flex-1"><div class="flex justify-between gap-2"><p class="font-heading font-extrabold truncate">' + esc(f.name) + '</p>' +
        '<span class="text-[11px] text-muted-foreground shrink-0">' + (m ? A.fmtListTime(m.ts) : '') + '</span></div>' +
        '<p class="text-sm truncate mt-1 ' + (n ? 'text-foreground font-bold' : 'text-muted-foreground') + '">' + esc(preview(f)) + '</p></div>' +
        (n ? '<span class="min-w-5 h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[11px] font-extrabold flex items-center justify-center">' + n + '</span>' : '') + '</a>';
    }).join('');
  }

  function renderAll() { header(); renderStrip(); renderChats(); }

  $('#search').addEventListener('input', function (e) { query = e.target.value; renderChats(); });
  $('#filter-btn').addEventListener('click', function () {
    A.actionSheet('Sohbetleri filtrele', Object.keys(FILTERS).map(function (k) {
      return { label: FILTERS[k] + (k === filter ? '  ✓' : ''), icon: { all: 'solar:chat-round-dots-bold', online: 'solar:users-group-rounded-linear', unread: 'solar:bell-bing-bold-duotone', best: 'solar:heart-bold' }[k], run: function () { filter = k; renderChats(); } };
    }));
  });
  $('#filter-chip').addEventListener('click', function () { filter = 'all'; renderChats(); });
  $('#new-chat').addEventListener('click', function () { A.openFriendPicker(); });
  $('#add-friend').addEventListener('click', function () { A.openAddFriend(); });
  $('#see-all').addEventListener('click', function () { location.href = 'friends.html'; });
  A.bindBell($('#bell'), $('#bell-badge'));
  A.onChange(function () { renderStrip(); renderChats(); header(); });
  renderAll();
})();
