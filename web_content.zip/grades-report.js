/* ==================================================
   MUEEN | GRADES REPORT
   تقرير الدرجات
================================================== */


/* ==================================================
   STORAGE
================================================== */

const STORAGE = {

    subjects:
        "mueen_subjects",

    classes:
        "mueen_classes",

    gradeRecords:
        "mueen_grade_records",

    gradeEvaluations:
        "mueen_grade_evaluations",

    weeks:
        "mueen_school_weeks",

    /*
       دفتر الدرجات الحديث يستخدم مخزنًا موحدًا.
       نقرأه أيضًا هنا حتى يظهر في السجل والتقارير.
    */
    modernGrades: "mueen_grades_data",
    attendanceGrades: "mueen_attendance_grade_records",
    attendanceSettings: "mueen_attendance_grade_settings",
    attendanceRecords: "mueen_attendance_records"

};


/* ==================================================
   STATE
================================================== */

const state = {

    subjects: [],

    classes: [],

    gradeRecords: [],

    gradeEvaluations: [],

    schoolWeeks: [],

    months: [],

    students: [],

    selectedStudents: new Set(),

    report: null

};


/* ==================================================
   DOM
================================================== */

const $ = id =>
    document.getElementById(id);


/* ==================================================
   SAFE STORAGE
================================================== */

function readStorage(key, fallback) {

    try {

        const raw =
            localStorage.getItem(key);

        if (!raw) {

            return fallback;
        }

        const parsed =
            JSON.parse(raw);

        return parsed ?? fallback;

    } catch (error) {

        console.error(
            "MUEEN storage error:",
            key,
            error
        );

        return fallback;
    }

}


function writeStorage(key, value) {

    try {

        localStorage.setItem(
            key,
            JSON.stringify(value)
        );

    } catch (error) {

        console.error(
            "MUEEN storage write error:",
            key,
            error
        );

    }

}


/* ==================================================
   REFRESH STORAGE
================================================== */

function readModernGradeData() {

    const raw =
        readStorage(
            STORAGE.modernGrades,
            null
        );

    if (!raw || typeof raw !== "object") {
        return {
            weeks: [],
            evaluations: [],
            records: []
        };
    }

    const weeks =
        Array.isArray(raw.weeks)
            ? raw.weeks
                .map((week, index) => ({
                    ...week,
                    id: String(
                        week?.id ??
                        week?.weekId ??
                        `week-${index + 1}`
                    ),
                    start: week?.start ?? week?.startDate ?? week?.from ?? week?.date ?? "",
                    end: week?.end ?? week?.endDate ?? week?.to ?? week?.date ?? ""
                }))
            : [];

    const evaluations =
        Array.isArray(raw.evaluations)
            ? raw.evaluations
                .map((evaluation, index) => ({
                    ...evaluation,
                    id: String(
                        evaluation?.id ??
                        evaluation?.evaluationId ??
                        `evaluation-${index + 1}`
                    ),
                    weekId: String(
                        evaluation?.weekId ??
                        evaluation?.week ??
                        evaluation?.week_id ??
                        ""
                    ),
                    subject: evaluation?.subject ?? evaluation?.subjectName ?? evaluation?.material ?? evaluation?.subjectId ?? "",
                    subjectId: evaluation?.subjectId ?? evaluation?.subjectID ?? (typeof evaluation?.subject === "object" ? getObjectId(evaluation.subject) : evaluation?.subject) ?? "",
                    classId: String(
                        evaluation?.classId ??
                        evaluation?.class ??
                        evaluation?.class_id ??
                        ""
                    ),
                    name: evaluation?.name ?? evaluation?.title ?? evaluation?.evaluationName ?? "تقييم",
                    max: evaluation?.max ?? evaluation?.maxScore ?? evaluation?.maximum ?? evaluation?.total ?? 10
                }))
            : [];

    const records = [];
    const rawRecords = raw.records;

    if (rawRecords && typeof rawRecords === "object" && !Array.isArray(rawRecords)) {
        Object.entries(rawRecords).forEach(([key, value]) => {

            /*
               يدعم سجل الدرجات جميع الصيغ التي استخدمتها النسخ السابقة.
               النسخة الحالية تحفظ المفتاح بالشكل:
               week::subject::class::student::evaluation
               وبعض النسخ الأقدم استخدمت ||| بدل ::.
            */
            const textKey = String(key);
            const parts = textKey.includes("::")
                ? textKey.split("::")
                : textKey.split("|||");

            if (parts.length >= 5) {
                const [weekId, subject, classId, studentId, evaluationId] = parts;

                records.push({
                    key: [weekId, subject, classId, studentId, evaluationId]
                        .map(v => String(v ?? ""))
                        .join("::"),
                    weekId: String(weekId || ""),
                    subject: String(subject || ""),
                    subjectId: String(subject || ""),
                    classId: String(classId || ""),
                    studentId: String(studentId || ""),
                    evaluationId: String(evaluationId || ""),
                    value
                });
            }
        });
    } else if (Array.isArray(rawRecords)) {
        rawRecords.forEach(record => records.push(record));
    }

    return { weeks, evaluations, records };
}


function refreshStorage() {

    state.subjects =
        readStorage(
            STORAGE.subjects,
            []
        );

    state.classes =
        readStorage(
            STORAGE.classes,
            []
        );

    state.gradeRecords =
        readStorage(
            STORAGE.gradeRecords,
            []
        );

    if (
        state.gradeRecords &&
        !Array.isArray(state.gradeRecords) &&
        typeof state.gradeRecords === "object"
    ) {
        const legacyObject = state.gradeRecords;
        const normalized = [];

        Object.entries(legacyObject).forEach(([key, value]) => {
            const textKey = String(key);
            const parts = textKey.includes("::")
                ? textKey.split("::")
                : textKey.split("|||");

            if (parts.length >= 5) {
                const [weekId, subject, classId, studentId, evaluationId] = parts;
                normalized.push({
                    key: [weekId, subject, classId, studentId, evaluationId].join("::"),
                    weekId: String(weekId || ""),
                    subject: String(subject || ""),
                    subjectId: String(subject || ""),
                    classId: String(classId || ""),
                    studentId: String(studentId || ""),
                    evaluationId: String(evaluationId || ""),
                    value
                });
            }
        });

        state.gradeRecords = normalized;
    }

    state.gradeEvaluations =
        readStorage(
            STORAGE.gradeEvaluations,
            []
        );

    state.schoolWeeks =
        readStorage(
            STORAGE.weeks,
            []
        );

    /*
       مزامنة بيانات دفتر الدرجات الحديث مع التقرير.
       هذا هو الإصلاح الأساسي: grades.js يحفظ كل شيء في
       mueen_grades_data، بينما التقرير القديم كان يقرأ
       مفاتيح منفصلة، لذلك كان يرى السجل فارغًا.
    */
    const modern = readModernGradeData();

    if (modern.evaluations.length) {
        const map = new Map();

        state.gradeEvaluations
            .filter(Boolean)
            .forEach((item, index) => {
                const id = String(
                    item?.id ??
                    item?.evaluationId ??
                    `legacy-evaluation-${index + 1}`
                );
                map.set(id, item);
            });

        modern.evaluations.forEach(item => {
            map.set(String(item.id), item);
        });

        state.gradeEvaluations = [...map.values()];
    }

    if (modern.records.length) {
        const existing = Array.isArray(state.gradeRecords)
            ? state.gradeRecords
            : [];

        state.gradeRecords = [
            ...existing,
            ...modern.records
        ];
    }

    if (modern.weeks.length) {
        const map = new Map();

        state.schoolWeeks
            .filter(Boolean)
            .forEach((item, index) => {
                const id = String(
                    item?.id ??
                    item?.weekId ??
                    `legacy-week-${index + 1}`
                );
                map.set(id, item);
            });

        modern.weeks.forEach(item => {
            map.set(String(item.id), item);
        });

        state.schoolWeeks = [...map.values()];
    }


    if (!Array.isArray(state.subjects)) {

        state.subjects = [];
    }


    if (!Array.isArray(state.classes)) {

        state.classes = [];
    }


    if (!Array.isArray(state.gradeRecords)) {

        state.gradeRecords = [];
    }


    if (!Array.isArray(state.gradeEvaluations)) {

        state.gradeEvaluations = [];
    }


    if (!Array.isArray(state.schoolWeeks)) {

        state.schoolWeeks = [];
    }


    state.months =
        getRegisteredMonths();
}


/* ==================================================
   TEXT HELPERS
================================================== */

function normalizeText(value) {

    return String(value ?? "")
        .trim()
        .replace(/\s+/g, " ")
        .toLowerCase();
}


function normalizeId(value) {

    if (
        value === undefined ||
        value === null
    ) {

        return "";
    }


    return String(value).trim();
}


function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function formatNumber(value) {

    const number =
        Number(value);

    if (!Number.isFinite(number)) {

        return "";
    }

    return new Intl.NumberFormat(
        "ar-EG"
    ).format(number);
}


function pad2(value) {

    return String(value).padStart(
        2,
        "0"
    );
}


/* ==================================================
   OBJECT ID
================================================== */

function getObjectId(object) {

    if (
        !object ||
        typeof object !== "object"
    ) {

        return "";
    }


    return normalizeId(
        object?.id ??
        object?._id ??
        object?.key ??
        object?.uuid
    );
}


/* ==================================================
   DATE HELPERS
================================================== */

function parseDate(value) {

    if (!value) {

        return null;
    }


    const text =
        String(value).trim();


    const match =
        text.match(
            /^(\d{4})-(\d{1,2})-(\d{1,2})$/
        );


    if (match) {

        const year =
            Number(match[1]);

        const month =
            Number(match[2]);

        const day =
            Number(match[3]);


        const date =
            new Date(
                year,
                month - 1,
                day
            );


        date.setHours(
            0,
            0,
            0,
            0
        );


        return date;
    }


    const date =
        new Date(value);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return null;
    }


    date.setHours(
        0,
        0,
        0,
        0
    );


    return date;
}


function dateToKey(date) {

    if (!date) {

        return "";
    }


    return [

        date.getFullYear(),

        pad2(
            date.getMonth() + 1
        ),

        pad2(
            date.getDate()
        )

    ].join("-");
}


function monthKeyFromDate(value) {

    const date =
        parseDate(value);


    if (!date) {

        return "";
    }


    return [

        date.getFullYear(),

        pad2(
            date.getMonth() + 1
        )

    ].join("-");
}


function monthLabel(monthKey) {

    if (!monthKey) {

        return "";
    }


    const parts =
        String(monthKey).split("-");


    if (parts.length !== 2) {

        return monthKey;
    }


    const year =
        Number(parts[0]);

    const month =
        Number(parts[1]);


    if (
        !Number.isFinite(year) ||
        !Number.isFinite(month)
    ) {

        return monthKey;
    }


    const date =
        new Date(
            year,
            month - 1,
            1
        );


    return new Intl.DateTimeFormat(
        "ar-EG",
        {
            month: "long",
            year: "numeric"
        }
    ).format(date);
}


function formatDate(value) {

    const date =
        parseDate(value);


    if (!date) {

        return "";
    }


    return new Intl.DateTimeFormat(
        "ar-EG",
        {
            day: "numeric",
            month: "numeric"
        }
    ).format(date);
}


function formatDateRange(start, end) {

    const startDate =
        parseDate(start);

    const endDate =
        parseDate(end);


    if (
        !startDate &&
        !endDate
    ) {

        return "";
    }


    if (
        startDate &&
        endDate
    ) {

        return `${formatDate(startDate)} – ${formatDate(endDate)}`;
    }


    return formatDate(
        startDate || endDate
    );
}


/* ==================================================
   SUBJECT HELPERS
================================================== */

function subjectId(subject) {

    return normalizeId(
        subject?.id ??
        subject?._id ??
        subject?.key ??
        subject?.subjectId
    );
}


function subjectName(subject) {

    return String(
        subject?.name ??
        subject?.title ??
        subject?.label ??
        subject?.subjectName ??
        ""
    ).trim();
}


/* ==================================================
   CLASS HELPERS
================================================== */

function classId(classItem) {

    return normalizeId(
        classItem?.id ??
        classItem?._id ??
        classItem?.key ??
        classItem?.classId
    );
}


/* ==================================================
   CLASS NAME
   عرض الصف بالشكل:
   3/1
================================================== */

function className(classItem) {

    if (
        !classItem ||
        typeof classItem !== "object"
    ) {

        return "الصف";
    }


    const code =
        String(
            classItem?.code ??
            ""
        ).trim();


    if (code) {

        const codeMatch =
            code.match(
                /(\d+)\s*\/\s*(\d+)/
            );


        if (codeMatch) {

            return `${codeMatch[1]}/${codeMatch[2]}`;
        }
    }


    const grade =
        String(
            classItem?.grade ??
            classItem?.gradeNumber ??
            classItem?.classGrade ??
            ""
        ).trim();


    const section =
        String(
            classItem?.section ??
            classItem?.sectionNumber ??
            classItem?.division ??
            ""
        ).trim();


    if (
        grade &&
        section
    ) {

        const gradeNumber =
            getGradeNumberFromName(
                grade
            );


        const sectionNumberMatch =
            section.match(
                /\d+/
            );


        const sectionNumber =
            sectionNumberMatch
                ? sectionNumberMatch[0]
                : "";


        if (
            gradeNumber &&
            sectionNumber
        ) {

            return `${gradeNumber}/${sectionNumber}`;
        }
    }


    const direct =
        String(
            classItem?.name ??
            classItem?.title ??
            classItem?.label ??
            classItem?.className ??
            ""
        ).trim();


    const directMatch =
        direct.match(
            /(\d+)\s*\/\s*(\d+)/
        );


    if (directMatch) {

        return `${directMatch[1]}/${directMatch[2]}`;
    }


    return "الصف";
}


/* ==================================================
   GRADE NUMBER
================================================== */

function getGradeNumberFromName(grade) {

    const map = {

        "الصف الأول الابتدائي": "1",
        "الصف الثاني الابتدائي": "2",
        "الصف الثالث الابتدائي": "3",
        "الصف الرابع الابتدائي": "4",
        "الصف الخامس الابتدائي": "5",
        "الصف السادس الابتدائي": "6",

        "الصف الأول الإعدادي": "1",
        "الصف الثاني الإعدادي": "2",
        "الصف الثالث الإعدادي": "3",

        "الصف الأول الثانوي": "1",
        "الصف الثاني الثانوي": "2",
        "الصف الثالث الثانوي": "3"

    };


    return map[grade] || "";
}


function getClassStudents(classItem) {

    const students =
        classItem?.students ??
        classItem?.studentList ??
        classItem?.children ??
        classItem?.members ??
        [];


    return Array.isArray(students)
        ? students
        : [];
}


/* ==================================================
   STUDENT HELPERS
================================================== */

function studentId(
    student,
    index = 0
) {

    const direct =
        student?.id ??
        student?.studentId ??
        student?._id ??
        student?.key;


    if (
        direct !== undefined &&
        direct !== null &&
        String(direct).trim()
    ) {

        return String(direct);
    }


    const name =
        studentName(student);


    if (name) {

        return `name-${name}`;
    }


    return `student-${index + 1}`;
}


function studentName(student) {

    return String(
        student?.name ??
        student?.studentName ??
        student?.fullName ??
        student?.title ??
        ""
    ).trim();
}


/* ==================================================
   WEEK HELPERS
================================================== */

function weekId(
    week,
    index = 0
) {

    const direct =
        week?.id ??
        week?._id ??
        week?.key ??
        week?.weekId;


    if (
        direct !== undefined &&
        direct !== null &&
        String(direct).trim()
    ) {

        return String(direct);
    }


    return `week-${index + 1}`;
}


function getWeekNumber(
    week,
    index = 0
) {

    const number =
        Number(
            week?.number ??
            week?.weekNumber ??
            week?.order ??
            index + 1
        );


    return Number.isFinite(number)
        ? number
        : index + 1;
}


function getWeekName(
    week,
    index = 0
) {

    const explicit =
        String(
            week?.name ??
            week?.title ??
            week?.weekName ??
            week?.label ??
            ""
        ).trim();


    if (explicit) {

        return explicit;
    }


    const number =
        getWeekNumber(
            week,
            index
        );


    const arabicNumbers = [

        "الأول",
        "الثاني",
        "الثالث",
        "الرابع",
        "الخامس",
        "السادس",
        "السابع",
        "الثامن",
        "التاسع",
        "العاشر",
        "الحادي عشر",
        "الثاني عشر",
        "الثالث عشر",
        "الرابع عشر",
        "الخامس عشر",
        "السادس عشر",
        "السابع عشر",
        "الثامن عشر",
        "التاسع عشر",
        "العشرون"

    ];


    const arabic =
        arabicNumbers[
            number - 1
        ] ||
        formatNumber(number);


    return `الأسبوع ${arabic}`;
}


/* ==================================================
   REGISTERED MONTHS
================================================== */

function getRegisteredMonths() {

    const months =
        new Set();


    /*
       الشهور من الأسابيع الدراسية.
    */

    state.schoolWeeks
        .forEach(
            week => {

                const start =
                    parseDate(
                        week?.start ?? week?.startDate ?? week?.from ?? week?.date
                    );

                const end =
                    parseDate(
                        week?.end ?? week?.endDate ?? week?.to ?? week?.date
                    );


                if (start) {

                    months.add(
                        monthKeyFromDate(
                            start
                        )
                    );
                }


                if (end) {

                    months.add(
                        monthKeyFromDate(
                            end
                        )
                    );
                }

            }
        );


    /*
       الشهور من سجلات الدرجات.
    */

    state.gradeRecords
        .forEach(
            record => {

                const date =
                    record?.date ??
                    record?.evaluationDate ??
                    record?.createdAt ??
                    record?.timestamp;


                const month =
                    monthKeyFromDate(
                        date
                    );


                if (month) {

                    months.add(month);
                }

            }
        );


    /*
       الشهور من التقييمات.
    */

    state.gradeEvaluations
        .forEach(
            evaluation => {

                const date =
                    evaluation?.date ??
                    evaluation?.evaluationDate ??
                    evaluation?.day ??
                    evaluation?.createdAt;


                const month =
                    monthKeyFromDate(
                        date
                    );


                if (month) {

                    months.add(month);
                }

            }
        );


    return [...months]
        .filter(Boolean)
        .sort();
}


/* ==================================================
   MONTH SELECT
================================================== */

function buildMonthSelect() {

    const select =
        $("monthSelect");


    if (!select) {

        return;
    }


    const previous =
        select.value;


    select.innerHTML = "";


    if (!state.months.length) {

        const option =
            document.createElement(
                "option"
            );


        option.value = "";


        option.textContent =
            "لا توجد أشهر مسجلة";


        select.appendChild(
            option
        );


        select.disabled = true;

        return;
    }


    select.disabled = false;


    state.months.forEach(
        month => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                month;


            option.textContent =
                monthLabel(month);


            select.appendChild(
                option
            );

        }
    );


    if (
        previous &&
        [...select.options]
            .some(
                option =>
                    option.value ===
                    previous
            )
    ) {

        select.value =
            previous;

    } else {

        select.value =
            state.months[
                state.months.length - 1
            ];
    }
}


/* ==================================================
   SUBJECT SELECT
================================================== */

function buildSubjectSelect() {

    const select =
        $("subjectSelect");


    if (!select) {

        return;
    }


    const previous =
        select.value;


    select.innerHTML = "";


    const first =
        document.createElement(
            "option"
        );


    first.value = "";


    first.textContent =
        "كل المواد";


    select.appendChild(
        first
    );


    state.subjects.forEach(
        subject => {

            const id =
                subjectId(subject);


            if (!id) {

                return;
            }


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            option.textContent =
                subjectName(subject) ||
                "مادة";


            select.appendChild(
                option
            );

        }
    );


    if (
        previous &&
        [...select.options]
            .some(
                option =>
                    option.value ===
                    previous
            )
    ) {

        select.value =
            previous;
    }
}


/* ==================================================
   CLASS SELECT
================================================== */

function buildClassSelect() {

    const select =
        $("classSelect");


    if (!select) {

        return;
    }


    const previous =
        select.value;


    select.innerHTML = "";


    const first =
        document.createElement(
            "option"
        );


    first.value = "";


    first.textContent =
        "كل الصفوف";


    select.appendChild(
        first
    );


    state.classes.forEach(
        classItem => {

            const id =
                classId(classItem);


            if (!id) {

                return;
            }


            const option =
                document.createElement(
                    "option"
                );


            option.value =
                id;


            option.textContent =
                className(classItem);


            select.appendChild(
                option
            );

        }
    );


    if (
        previous &&
        [...select.options]
            .some(
                option =>
                    option.value ===
                    previous
            )
    ) {

        select.value =
            previous;
    }
}


/* ==================================================
   STUDENT LIST
================================================== */

function rebuildStudents() {

    const classSelect =
        $("classSelect");


    const selectedClassId =
        String(
            classSelect?.value || ""
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                selectedClassId
        );


    if (classItem) {

        state.students =
            getClassStudents(
                classItem
            )
            .map(
                (student, index) => ({

                    raw:
                        student,

                    id:
                        studentId(
                            student,
                            index
                        ),

                    name:
                        studentName(
                            student
                        )

                })
            )
            .filter(
                student =>
                    student.name
            );

    } else {

        const map =
            new Map();


        state.classes.forEach(
            classItem => {

                getClassStudents(
                    classItem
                )
                .forEach(
                    (student, index) => {

                        const id =
                            studentId(
                                student,
                                index
                            );


                        const name =
                            studentName(
                                student
                            );


                        if (
                            name &&
                            !map.has(id)
                        ) {

                            map.set(
                                id,
                                {

                                    raw:
                                        student,

                                    id,

                                    name

                                }
                            );

                        }

                    }
                );

            }
        );


        state.students =
            [...map.values()];
    }


    const validIds =
        new Set(
            state.students.map(
                student =>
                    student.id
            )
        );


    state.selectedStudents =
        new Set(
            [...state.selectedStudents]
                .filter(
                    id =>
                        validIds.has(id)
                )
        );


    updateSelectionUI();

    renderStudentSearch();
}


/* ==================================================
   STUDENT SEARCH
================================================== */

function renderStudentSearch() {

    const results =
        $("studentSearchResults");


    const input =
        $("studentSearch");


    if (
        !results ||
        !input
    ) {

        return;
    }


    const query =
        String(
            input.value || ""
        )
        .trim()
        .toLowerCase();


    if (!query) {

        results.innerHTML = "";

        results.hidden = true;

        return;
    }


    const matches =
        state.students
            .filter(
                student =>
                    student.name
                        .toLowerCase()
                        .includes(query)
            )
            .slice(0, 50);


    results.innerHTML = "";


    if (!matches.length) {

        const empty =
            document.createElement(
                "div"
            );


        empty.className =
            "student-candidate";


        empty.style.cursor =
            "default";


        empty.innerHTML = `

            <span class="student-candidate-name">
                لا توجد نتائج
            </span>

        `;


        results.appendChild(
            empty
        );


        results.hidden = false;

        return;
    }


    matches.forEach(
        student => {

            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "student-candidate";


            if (
                state.selectedStudents.has(
                    student.id
                )
            ) {

                button.classList.add(
                    "selected"
                );
            }


            button.innerHTML = `

                <span
                    class="student-candidate-check"
                >
                    ${
                        state.selectedStudents.has(
                            student.id
                        )
                            ? "✓"
                            : ""
                    }
                </span>


                <span
                    class="student-candidate-name"
                >
                    ${escapeHTML(
                        student.name
                    )}
                </span>

            `;


            button.addEventListener(
                "click",
                () => {

                    toggleStudent(
                        student.id
                    );


                    renderStudentSearch();

                }
            );


            results.appendChild(
                button
            );

        }
    );


    results.hidden = false;
}


/* ==================================================
   STUDENT TOGGLE
================================================== */

function toggleStudent(id) {

    const value =
        String(id);


    if (
        state.selectedStudents.has(
            value
        )
    ) {

        state.selectedStudents.delete(
            value
        );

    } else {

        state.selectedStudents.add(
            value
        );

    }


    updateSelectionUI();

    buildReport();
}


/* ==================================================
   SELECTION UI
================================================== */

function updateSelectionUI() {

    const count =
        $("selectionCount");


    const clear =
        $("clearStudentSelection");


    const selected =
        state.selectedStudents.size;


    if (count) {

        count.textContent =
            selected
                ? `تم اختيار ${formatNumber(selected)}`
                : "كل الطلاب";
    }


    if (clear) {

        clear.hidden =
            selected === 0;
    }
}


/* ==================================================
   WEEK SORT
================================================== */

function sortWeeks(weeks) {

    return [...weeks]
        .sort(
            (a, b) => {

                const aStart =
                    parseDate(
                        a?.start
                    );


                const bStart =
                    parseDate(
                        b?.start
                    );


                if (
                    aStart &&
                    bStart
                ) {

                    return (
                        aStart.getTime() -
                        bStart.getTime()
                    );
                }


                if (aStart) {

                    return -1;
                }


                if (bStart) {

                    return 1;
                }


                return (
                    getWeekNumber(a, 0) -
                    getWeekNumber(b, 0)
                );

            }
        );
}


/* ==================================================
   WEEKS FOR MONTH
================================================== */

function getWeeksForMonth(monthKey) {

    const monthStart =
        parseDate(
            `${monthKey}-01`
        );


    if (!monthStart) {

        return [];
    }


    const monthEnd =
        new Date(
            monthStart.getFullYear(),
            monthStart.getMonth() + 1,
            0
        );


    monthEnd.setHours(
        0,
        0,
        0,
        0
    );


    const registeredWeeks =
        sortWeeks(
            state.schoolWeeks
        )
        .filter(
            week => {

                const start =
                    parseDate(
                        week?.start ?? week?.startDate ?? week?.from ?? week?.date
                    );


                const end =
                    parseDate(
                        week?.end ?? week?.endDate ?? week?.to ?? week?.date
                    );


                if (
                    !start &&
                    !end
                ) {

                    return false;
                }


                const actualStart =
                    start || end;


                const actualEnd =
                    end || start;


                return (
                    actualStart <= monthEnd &&
                    actualEnd >= monthStart
                );

            }
        );


    /*
       إذا كانت الأسابيع موجودة، نستخدمها.
    */

    if (registeredWeeks.length) {

        return registeredWeeks;
    }


    /*
       احتياط:
       إذا كانت التقييمات تحتوي على تواريخ
       ولكن لا توجد أسابيع مسجلة، ننشئ
       أسابيع مؤقتة مبنية على تواريخ التقييمات.
       هذا يمنع ظهور بطاقة عدم وجود تقييمات
       رغم وجود بيانات فعلية.
    */

    const temporaryWeeks =
        [];


    const seen =
        new Set();


    state.gradeEvaluations.forEach(
        evaluation => {

            const date =
                parseDate(
                    evaluation?.date ??
                    evaluation?.evaluationDate ??
                    evaluation?.day ??
                    evaluation?.createdAt
                );


            if (!date) {

                return;
            }


            if (
                monthKeyFromDate(date) !==
                monthKey
            ) {

                return;
            }


            const key =
                dateToKey(date);


            if (
                seen.has(key)
            ) {

                return;
            }


            seen.add(key);


            temporaryWeeks.push({

                id:
                    `temporary-week-${key}`,

                name:
                    `الأسبوع`,

                start:
                    key,

                end:
                    key,

                _temporary:
                    true

            });

        }
    );


    return sortWeeks(
        temporaryWeeks
    );
}


/* ==================================================
   EVALUATION HELPERS
================================================== */

function evaluationId(
    evaluation,
    index = 0
) {

    const direct =
        evaluation?.id ??
        evaluation?._id ??
        evaluation?.key ??
        evaluation?.evaluationId;


    if (
        direct !== undefined &&
        direct !== null &&
        String(direct).trim()
    ) {

        return String(direct);
    }


    const name =
        evaluationName(
            evaluation
        );


    if (name) {

        return `evaluation-${name}`;
    }


    return `evaluation-${index + 1}`;
}


function evaluationName(evaluation) {

    return String(
        evaluation?.name ??
        evaluation?.title ??
        evaluation?.label ??
        evaluation?.evaluationName ??
        evaluation?.typeName ??
        evaluation?.type ??
        "تقييم"
    ).trim();
}


/* ==================================================
   EVALUATION TOTAL / MAX GRADE
================================================== */

function evaluationTotal(evaluation) {

    if (
        !evaluation ||
        typeof evaluation !== "object"
    ) {

        return null;
    }


    /*
       نحاول قراءة الدرجة الكلية
       من أكثر الأسماء الشائعة.
    */

    const candidates = [

        evaluation?.total,

        evaluation?.max,

        evaluation?.maxGrade,

        evaluation?.totalGrade,

        evaluation?.maximum,

        evaluation?.outOf,

        evaluation?.fullMark,

        evaluation?.fullMarks,

        evaluation?.maxScore,

        evaluation?.totalScore,

        evaluation?.maximumScore,

        evaluation?.points,

        evaluation?.degree,

        evaluation?.settings?.total,

        evaluation?.settings?.max,

        evaluation?.settings?.maxGrade,

        evaluation?.settings?.totalGrade,

        evaluation?.settings?.maximum,

        evaluation?.settings?.outOf,

        evaluation?.settings?.fullMark,

        evaluation?.settings?.maxScore,

        evaluation?.meta?.total,

        evaluation?.meta?.max,

        evaluation?.meta?.maxGrade,

        evaluation?.meta?.totalGrade,

        evaluation?.data?.total,

        evaluation?.data?.max,

        evaluation?.data?.maxGrade,

        evaluation?.data?.totalGrade

    ];


    for (
        const candidate of candidates
    ) {

        if (
            candidate === undefined ||
            candidate === null
        ) {

            continue;
        }


        if (
            typeof candidate === "object"
        ) {

            continue;
        }


        const text =
            String(
                candidate
            ).trim();


        if (!text) {

            continue;
        }


        const number =
            Number(
                text.replace(
                    ",",
                    "."
                )
            );


        if (
            Number.isFinite(number)
        ) {

            return number;
        }

    }


    return null;
}


/* ==================================================
   EVALUATION WEEK
================================================== */

function evaluationWeekId(evaluation) {

    return normalizeId(
        evaluation?.weekId ??
        evaluation?.schoolWeekId ??
        evaluation?.weekID ??
        (
            typeof evaluation?.week === "object"
                ? getObjectId(
                    evaluation.week
                )
                : evaluation?.week
        )
    );
}


/* ==================================================
   EVALUATION SUBJECT
================================================== */

function evaluationSubjectId(evaluation) {

    const value =
        evaluation?.subjectId ??
        evaluation?.subjectID ??
        (
            typeof evaluation?.subject === "object"
                ? getObjectId(
                    evaluation.subject
                )
                : evaluation?.subject
        );


    return normalizeId(
        value
    );
}


/* ==================================================
   EVALUATION CLASS
================================================== */

function evaluationClassId(evaluation) {

    const value =
        evaluation?.classId ??
        evaluation?.classID ??
        (
            typeof evaluation?.class === "object"
                ? getObjectId(
                    evaluation.class
                )
                : evaluation?.class
        );


    return normalizeId(
        value
    );
}


/* ==================================================
   EVALUATION DATE
================================================== */

function evaluationDate(evaluation) {

    return parseDate(
        evaluation?.date ??
        evaluation?.evaluationDate ??
        evaluation?.day ??
        evaluation?.createdAt
    );
}


/* ==================================================
   EVALUATION MONTH
================================================== */

function evaluationBelongsToMonth(
    evaluation,
    monthKey,
    week
) {

    const date =
        evaluationDate(
            evaluation
        );


    if (date) {

        return (
            monthKeyFromDate(date) ===
            monthKey
        );
    }


    const evaluationWeek =
        evaluationWeekId(
            evaluation
        );


    if (
        evaluationWeek &&
        week
    ) {

        return (
            evaluationWeek ===
            weekId(week)
        );
    }


    if (week) {

        const start =
            parseDate(
                week?.start
            );


        const end =
            parseDate(
                week?.end
            );


        const monthStart =
            parseDate(
                `${monthKey}-01`
            );


        if (
            start &&
            end &&
            monthStart
        ) {

            const monthEnd =
                new Date(
                    monthStart.getFullYear(),
                    monthStart.getMonth() + 1,
                    0
                );


            monthEnd.setHours(
                0,
                0,
                0,
                0
            );


            return (
                start <= monthEnd &&
                end >= monthStart
            );
        }
    }


    return false;
}


/* ==================================================
   EVALUATION MATCH
================================================== */

function evaluationMatches(
    evaluation,
    week,
    subjectValue,
    classValue,
    monthKey
) {

    if (!evaluation) {

        return false;
    }


    const evaluationSubject =
        evaluationSubjectId(
            evaluation
        );


    const evaluationClass =
        evaluationClassId(
            evaluation
        );


    /*
       المادة:
       إذا كان التقييم محددًا بمادة
       فيجب أن يطابق المادة المختارة.
    */

    if (
        subjectValue &&
        evaluationSubject &&
        evaluationSubject !==
            String(subjectValue)
    ) {

        return false;
    }


    /*
       الصف:
       إذا كان التقييم محددًا بصف
       فيجب أن يطابق الصف المختار.
    */

    if (
        classValue &&
        evaluationClass &&
        evaluationClass !==
            String(classValue)
    ) {

        return false;
    }


    const evalWeek =
        evaluationWeekId(
            evaluation
        );


    /*
       إذا كان للتقييم أسبوع محدد
       فالمطابقة تكون مع هذا الأسبوع.
    */

    if (
        evalWeek
    ) {

        if (!week) {

            return false;
        }


        return (
            evalWeek ===
            weekId(week)
        );
    }


    /*
       إذا لم يوجد weekId،
       نستخدم تاريخ التقييم.
    */

    const date =
        evaluationDate(
            evaluation
        );


    if (date) {

        if (
            monthKeyFromDate(date) !==
            monthKey
        ) {

            return false;
        }


        if (!week) {

            return true;
        }


        const start =
            parseDate(
                week?.start
            );


        const end =
            parseDate(
                week?.end
            );


        if (
            start &&
            end
        ) {

            return (
                date >= start &&
                date <= end
            );
        }


        /*
           الأسبوع المؤقت.
        */

        return true;
    }


    /*
       إذا لم يوجد تاريخ ولا weekId،
       لا نرمي التقييم مباشرة.

       إذا كان التقييم نفسه موجودًا ضمن
       بيانات الشهر، نسمح له بالظهور.
    */

    return evaluationBelongsToMonth(
        evaluation,
        monthKey,
        week
    );
}


/* ==================================================
   GET EVALUATIONS FOR WEEK
================================================== */

function getEvaluationsForWeek(
    week,
    monthKey,
    subjectValue,
    classValue
) {

    const list =
        state.gradeEvaluations
            .filter(
                evaluation =>
                    evaluationMatches(
                        evaluation,
                        week,
                        subjectValue,
                        classValue,
                        monthKey
                    )
            );


    /*
       إزالة التكرار.
    */

    const map =
        new Map();


    list.forEach(
        (evaluation, index) => {

            const id =
                evaluationId(
                    evaluation,
                    index
                );


            if (
                !map.has(id)
            ) {

                map.set(
                    id,
                    {
                        ...evaluation,
                        _reportId: id
                    }
                );
            }

        }
    );


    return [...map.values()];
}


/* ==================================================
   RECORD HELPERS
================================================== */

function makeRecordKey(
    weekValue,
    subjectValue,
    classValue,
    studentValue,
    evaluationValue
) {

    return [

        String(weekValue || ""),

        String(subjectValue || ""),

        String(classValue || ""),

        String(studentValue || ""),

        String(evaluationValue || "")

    ].join("::");
}


function recordStudentId(record) {

    return normalizeId(
        record?.studentId ??
        record?.studentID ??
        record?.student?._id ??
        record?.student?.id ??
        record?.student?.studentId
    );
}


function recordEvaluationId(record) {

    return normalizeId(
        record?.evaluationId ??
        record?.evaluationID ??
        record?.assessmentId ??
        record?.gradeEvaluationId ??
        (
            typeof record?.evaluation === "object"
                ? getObjectId(
                    record.evaluation
                )
                : record?.evaluation
        )
    );
}


function recordWeekId(record) {

    return normalizeId(
        record?.weekId ??
        record?.schoolWeekId ??
        record?.weekID ??
        (
            typeof record?.week === "object"
                ? getObjectId(
                    record.week
                )
                : record?.week
        )
    );
}


function recordSubjectId(record) {

    return normalizeId(
        record?.subjectId ??
        record?.subjectID ??
        (
            typeof record?.subject === "object"
                ? getObjectId(
                    record.subject
                )
                : record?.subject
        )
    );
}


function recordClassId(record) {

    return normalizeId(
        record?.classId ??
        record?.classID ??
        (
            typeof record?.class === "object"
                ? getObjectId(
                    record.class
                )
                : record?.class
        )
    );
}


/* ==================================================
   RECORD VALUE
================================================== */

function getGradeValue(record) {

    if (
        record === null ||
        record === undefined
    ) {

        return null;
    }


    if (
        typeof record === "number"
    ) {

        return record;
    }


    if (
        typeof record === "string"
    ) {

        const text =
            record.trim();


        if (!text) {

            return null;
        }


        const numeric =
            Number(
                text.replace(
                    ",",
                    "."
                )
            );


        return Number.isFinite(
            numeric
        )
            ? numeric
            : text;
    }


    if (
        typeof record !== "object"
    ) {

        return null;
    }


    const candidates = [

        record.value,

        record.score,

        record.grade,

        record.mark,

        record.points,

        record.result,

        record.degree,

        record.gradeValue,

        record.studentGrade

    ];


    for (
        const candidate of candidates
    ) {

        if (
            candidate !== undefined &&
            candidate !== null &&
            String(candidate).trim() !== ""
        ) {

            return getGradeValue(
                candidate
            );
        }
    }


    return null;
}


/* ==================================================
   RECORD MATCH
================================================== */

function gradeRecordMatches(
    record,
    week,
    evaluation,
    student,
    subjectValue,
    classValue
) {

    if (!record) {

        return false;
    }


    const studentValue =
        String(student.id);


    const recordStudent =
        recordStudentId(
            record
        );


    if (
        recordStudent &&
        recordStudent !==
            studentValue
    ) {

        const recordName =
            normalizeText(
                record?.studentName ??
                record?.student?.name
            );


        if (
            recordName !==
            normalizeText(
                student.name
            )
        ) {

            return false;
        }
    }


    if (
        subjectValue &&
        recordSubjectId(record) &&
        recordSubjectId(record) !==
            String(subjectValue)
    ) {

        return false;
    }


    if (
        classValue &&
        recordClassId(record) &&
        recordClassId(record) !==
            String(classValue)
    ) {

        return false;
    }


    const expectedEvaluationId =
        evaluationId(
            evaluation
        );


    const recordEvaluation =
        recordEvaluationId(
            record
        );


    if (
        recordEvaluation
    ) {

        if (recordEvaluation !== expectedEvaluationId) {
            const recordName = normalizeText(record?.evaluationName ?? record?.assessmentName ?? record?.evaluation?.name);
            const keyLooksLikeName = normalizeText(recordEvaluation) === normalizeText(evaluationName(evaluation));
            if ((!recordName || recordName !== normalizeText(evaluationName(evaluation))) && !keyLooksLikeName) return false;
        }

    } else {

        const recordEvaluationName =
            normalizeText(
                record?.evaluationName ??
                record?.assessmentName ??
                record?.evaluation?.name
            );


        if (
            recordEvaluationName &&
            recordEvaluationName !==
                normalizeText(
                    evaluationName(
                        evaluation
                    )
                )
        ) {

            return false;
        }
    }


    const expectedWeekId =
        weekId(week);


    const recordWeek =
        recordWeekId(
            record
        );


    if (
        recordWeek
    ) {

        return (
            recordWeek ===
            expectedWeekId
        );
    }


    const recordDate =
        parseDate(
            record?.date ??
            record?.evaluationDate ??
            record?.createdAt
        );


    const weekStart =
        parseDate(
            week?.start ?? week?.startDate ?? week?.from ?? week?.date
        );


    const weekEnd =
        parseDate(
            week?.end ?? week?.endDate ?? week?.to ?? week?.date
        );


    if (
        recordDate &&
        weekStart &&
        weekEnd
    ) {

        return (
            recordDate >= weekStart &&
            recordDate <= weekEnd
        );
    }


    return true;
}


/* ==================================================
   GET GRADE RECORD
================================================== */

function getGradeRecord(
    week,
    evaluation,
    student,
    subjectValue,
    classValue
) {

    const expectedKey =
        makeRecordKey(
            weekId(week),
            subjectValue,
            classValue,
            student.id,
            evaluationId(
                evaluation
            )
        );


    const direct =
        state.gradeRecords.find(
            record =>
                normalizeId(
                    record?.key ??
                    record?.recordKey
                ) ===
                expectedKey
        );


    if (direct) {

        return direct;
    }


    return (
        state.gradeRecords.find(
            record =>
                gradeRecordMatches(
                    record,
                    week,
                    evaluation,
                    student,
                    subjectValue,
                    classValue
                )
        ) ||
        null
    );
}


/* ==================================================
   FORMAT GRADE
================================================== */

function formatGrade(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "—";
    }


    if (
        typeof value === "string"
    ) {

        const text =
            value.trim();


        if (!text) {

            return "—";
        }


        const numeric =
            Number(
                text.replace(
                    ",",
                    "."
                )
            );


        if (
            Number.isFinite(
                numeric
            )
        ) {

            return formatNumber(
                numeric
            );
        }


        return text;
    }


    if (
        Number.isFinite(
            Number(value)
        )
    ) {

        return formatNumber(
            Number(value)
        );
    }


    return String(value);
}


/* ==================================================
   NUMERIC GRADE
================================================== */

function numericGrade(value) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {

        return null;
    }


    const number =
        Number(
            String(value)
                .replace(
                    ",",
                    "."
                )
        );


    return Number.isFinite(
        number
    )
        ? number
        : null;
}


/* ==================================================
   SELECT REPORT STUDENTS
================================================== */

function getReportStudents() {

    if (
        state.selectedStudents.size === 0
    ) {

        return [...state.students];
    }


    return state.students.filter(
        student =>
            state.selectedStudents.has(
                student.id
            )
    );
}


/* ==================================================
   TOTAL POSSIBLE GRADE
================================================== */

function getReportMaximumTotal(
    tableData
) {

    let total =
        0;


    let hasAny =
        false;


    tableData.forEach(
        item => {

            total += getAttendanceMaxForWeek(item.week, $("subjectSelect")?.value || "", $("classSelect")?.value || "");
            hasAny = true;

            item.evaluations.forEach(
                evaluation => {

                    const value =
                        evaluationTotal(
                            evaluation
                        );


                    if (
                        value !== null
                    ) {

                        total +=
                            value;

                        hasAny =
                            true;
                    }

                }
            );

        }
    );


    return hasAny
        ? total
        : null;
}


/* ==================================================
   ATTENDANCE GRADE HELPERS
================================================== */
function attendanceContextKey(week, subjectValue, classValue){return [String(weekId(week)),String(subjectValue||""),String(classValue||"")].join("::");}
function getAttendanceMaxForWeek(week, subjectValue, classValue){const x=readStorage(STORAGE.attendanceSettings,{}); const n=Number(x?.[attendanceContextKey(week,subjectValue,classValue)]); return Number.isFinite(n)&&n>0?n:10;}
function getAttendanceGradeForReport(week,student,subjectValue,classValue){const grades=readStorage(STORAGE.attendanceGrades,{}); const ctx=attendanceContextKey(week,subjectValue,classValue); const ids=[student.id,student.raw?.id,student.raw?.studentId,student.raw?._id,student.raw?.key].filter(v=>v!=null).map(String); for(const id of ids){const v=grades[ctx+"::"+id]; if(v!==undefined&&v!==null&&v!=="") return v;} const records=readStorage(STORAGE.attendanceRecords,[]); const rel=Array.isArray(records)?records.filter(r=>{const rs=String(r?.subjectId??r?.subject??""); const rc=String(r?.classId??r?.class??""); const rw=String(r?.weekId??r?.week??""); return (!rs||rs===String(subjectValue))&&(!rc||rc===String(classValue))&&rw===weekId(week);}):[]; if(!rel.length)return ""; let absent=0; const wanted=normalizeText(student.name); for(const r of rel){const arr=Array.isArray(r.absentStudents)?r.absentStudents:[]; if(arr.some(a=>ids.includes(String(a?.id??a?.studentId??a?._id??a?.key??"")) || (wanted&&normalizeText(a?.name??a?.studentName??a?.fullName??"")===wanted))) absent++;} const max=getAttendanceMaxForWeek(week,subjectValue,classValue); return Math.round(((rel.length-absent)/rel.length)*max);}


/* ==================================================
   BUILD REPORT
================================================== */

function buildReport() {

    refreshStorage();

    rebuildStudents();


    const month =
        String(
            $("monthSelect")?.value || ""
        );


    const subjectValue =
        String(
            $("subjectSelect")?.value || ""
        );


    const classValue =
        String(
            $("classSelect")?.value || ""
        );


    const table =
        $("absenceReportTable") ||
        $("gradesReportTable");


    const empty =
        $("reportEmpty");


    if (!table) {

        return;
    }


    table.innerHTML = "";

    table.hidden = true;


    if (empty) {

        empty.hidden = true;
    }


    if (!month) {

        showEmpty(
            "لا توجد بيانات",
            "لم يتم تسجيل أي شهر في بيانات الدرجات."
        );

        return;
    }


    const weeks =
        getWeeksForMonth(
            month
        );


    const students =
        getReportStudents();


    if (!weeks.length) {

        showEmpty(
            "لا توجد أسابيع مسجلة",
            "لا توجد أسابيع مرتبطة بالشهر المحدد."
        );

        return;
    }


    if (!students.length) {

        showEmpty(
            "لا يوجد طلاب",
            "لا يوجد طلاب مسجلون في الصف المحدد."
        );

        return;
    }


    const tableData =
        [];


    let totalEvaluationColumns =
        0;


    weeks.forEach(
        week => {

            const evaluations =
                getEvaluationsForWeek(
                    week,
                    month,
                    subjectValue,
                    classValue
                );


            if (
                evaluations.length
            ) {

                totalEvaluationColumns +=
                    evaluations.length;


                tableData.push({

                    week,

                    evaluations

                });

            }

        }
    );


    /*
       احتياط إضافي:
       إذا لم ترتبط التقييمات بالأسابيع،
       نحاول عرضها مباشرة حسب الشهر.
    */

    if (
        totalEvaluationColumns === 0
    ) {

        const fallbackEvaluations =
            state.gradeEvaluations
                .filter(
                    evaluation => {

                        const evaluationSubject =
                            evaluationSubjectId(
                                evaluation
                            );


                        const evaluationClass =
                            evaluationClassId(
                                evaluation
                            );


                        if (
                            subjectValue &&
                            evaluationSubject &&
                            evaluationSubject !==
                                subjectValue
                        ) {

                            return false;
                        }


                        if (
                            classValue &&
                            evaluationClass &&
                            evaluationClass !==
                                classValue
                        ) {

                            return false;
                        }


                        const date =
                            evaluationDate(
                                evaluation
                            );


                        if (date) {

                            return (
                                monthKeyFromDate(
                                    date
                                ) ===
                                month
                            );
                        }


                        /*
                           إذا لم يوجد تاريخ،
                           نبحث عن أي سجل درجة
                           يشير لهذا التقييم.
                        */

                        const id =
                            evaluationId(
                                evaluation
                            );


                        return state.gradeRecords.some(
                            record =>
                                recordEvaluationId(
                                    record
                                ) === id
                        );

                    }
                );


        if (
            fallbackEvaluations.length
        ) {

            const map =
                new Map();


            fallbackEvaluations.forEach(
                (evaluation, index) => {

                    const id =
                        evaluationId(
                            evaluation,
                            index
                        );


                    if (
                        !map.has(id)
                    ) {

                        map.set(
                            id,
                            {
                                ...evaluation,
                                _reportId:
                                    id
                            }
                        );

                    }

                }
            );


            const evaluations =
                [...map.values()];


            if (
                evaluations.length
            ) {

                tableData.push({

                    week:
                        weeks[0],

                    evaluations

                });


                totalEvaluationColumns =
                    evaluations.length;
            }

        }

    }


    /*
       إذا لم توجد تقييمات فعلًا فقط هنا
       تظهر بطاقة عدم وجود تقييمات.
    */

    if (
        totalEvaluationColumns === 0
    ) {

        showEmpty(
            "لا توجد تقييمات",
            "لا توجد تقييمات مسجلة ضمن الشهر والمادة والصف المحدد."
        );

        return;
    }


    /* ==================================================
       TOTAL POSSIBLE
    ================================================== */

    const maximumMonthlyTotal =
        getReportMaximumTotal(
            tableData
        );


    /* ==================================================
       HEADER ROW 1
    ================================================== */

    const headerRow1 =
        document.createElement(
            "tr"
        );


    const studentHeader =
        document.createElement(
            "th"
        );


    studentHeader.rowSpan = 2;


    studentHeader.className =
        "report-student-header";


    studentHeader.textContent =
        "اسم الطالب";


    headerRow1.appendChild(
        studentHeader
    );


    tableData.forEach(
        item => {

            const th =
                document.createElement(
                    "th"
                );


            th.colSpan =
                item.evaluations.length + 1;


            th.className =
                "report-week-header";


            th.innerHTML = `

                <div class="report-week-name">
                    ${escapeHTML(
                        getWeekName(
                            item.week,
                            state.schoolWeeks.indexOf(
                                item.week
                            )
                        )
                    )}
                </div>

                <div class="report-week-date">
                    ${escapeHTML(
                        formatDateRange(
                            item.week?.start,
                            item.week?.end
                        )
                    )}
                </div>

            `;


            headerRow1.appendChild(
                th
            );

        }
    );


    /* ==================================================
       MONTH TOTAL HEADER
    ================================================== */

    const totalHeader =
        document.createElement(
            "th"
        );


    totalHeader.rowSpan = 2;


    totalHeader.className =
        "total-absence-header";


    totalHeader.innerHTML = `

        <div class="report-total-title">
            المجموع الكلي للشهر
        </div>

        <div class="report-total-max">
            ${
                maximumMonthlyTotal !== null
                    ? escapeHTML(
                        formatGrade(
                            maximumMonthlyTotal
                        )
                    )
                    : "—"
            }
        </div>

    `;


    headerRow1.appendChild(
        totalHeader
    );


    table.appendChild(
        headerRow1
    );


    /* ==================================================
       HEADER ROW 2
    ================================================== */

    const headerRow2 =
        document.createElement(
            "tr"
        );


    tableData.forEach(
        item => {

            { const th=document.createElement("th"); th.className="report-day-header attendance-report-header"; th.innerHTML=`<span class="report-day-name">الحضور</span><span class="report-evaluation-total">${escapeHTML(formatGrade(getAttendanceMaxForWeek(item.week,subjectValue,classValue)))}</span>`; headerRow2.appendChild(th); }

            item.evaluations.forEach(
                evaluation => {

                    const th =
                        document.createElement(
                            "th"
                        );


                    th.className =
                        "report-day-header";


                    const maxGrade =
                        evaluationTotal(
                            evaluation
                        );


                    th.innerHTML = `

                        <span class="report-day-name">
                            ${escapeHTML(
                                evaluationName(
                                    evaluation
                                )
                            )}
                        </span>

                        <span class="report-evaluation-total">
                            ${
                                maxGrade !== null
                                    ? escapeHTML(
                                        formatGrade(
                                            maxGrade
                                        )
                                    )
                                    : "—"
                            }
                        </span>

                    `;


                    headerRow2.appendChild(
                        th
                    );

                }
            );

        }
    );


    table.appendChild(
        headerRow2
    );


    /* ==================================================
       STUDENT ROWS
    ================================================== */

    students.forEach(
        (
            student,
            studentIndex
        ) => {

            const row =
                document.createElement(
                    "tr"
                );


            const nameCell =
                document.createElement(
                    "td"
                );


            nameCell.className =
                "report-student-cell";


            nameCell.innerHTML = `

                <span class="student-number">
                    ${formatNumber(
                        studentIndex + 1
                    )}
                </span>

                ${escapeHTML(
                    student.name
                )}

            `;


            row.appendChild(
                nameCell
            );


            let monthlyTotal =
                0;


            tableData.forEach(
                item => {

                    { const cell=document.createElement("td"); cell.className="attendance-cell"; const value=getAttendanceGradeForReport(item.week,student,subjectValue,classValue); const numeric=numericGrade(value); if(numeric!==null) monthlyTotal+=numeric; cell.textContent=numeric!==null?formatGrade(numeric):"—"; row.appendChild(cell); }

                    item.evaluations.forEach(
                        evaluation => {

                            const cell =
                                document.createElement(
                                    "td"
                                );


                            cell.className =
                                "attendance-cell";


                            const record =
                                getGradeRecord(
                                    item.week,
                                    evaluation,
                                    student,
                                    subjectValue,
                                    classValue
                                );


                            const value =
                                getGradeValue(
                                    record
                                );


                            const numeric =
                                numericGrade(
                                    value
                                );


                            if (
                                numeric !== null
                            ) {

                                monthlyTotal +=
                                    numeric;


                                cell.classList.add(
                                    "present"
                                );


                                cell.textContent =
                                    formatGrade(
                                        numeric
                                    );

                            } else if (
                                value !== null &&
                                value !== undefined &&
                                String(value).trim()
                            ) {

                                cell.classList.add(
                                    "present"
                                );


                                cell.textContent =
                                    formatGrade(
                                        value
                                    );

                            } else {

                                cell.classList.add(
                                    "empty"
                                );


                                cell.textContent =
                                    "—";
                            }


                            row.appendChild(
                                cell
                            );

                        }
                    );

                }
            );


            const totalCell =
                document.createElement(
                    "td"
                );


            totalCell.className =
                "total-absence-cell";


            totalCell.textContent =
                formatGrade(
                    monthlyTotal
                );


            row.appendChild(
                totalCell
            );


            table.appendChild(
                row
            );

        }
    );


    /*
       مهم:
       إظهار الجدول وإخفاء بطاقة عدم وجود البيانات
       يتمان في النهاية فقط بعد اكتمال بنائه.
    */

    table.hidden = false;


    if (empty) {

        empty.hidden = true;
    }


    updateReportInfo(
        month,
        subjectValue,
        classValue,
        students.length
    );


    state.report = {

        month,

        subjectId:
            subjectValue,

        classId:
            classValue,

        weeks:
            tableData,

        students,

        maximumMonthlyTotal

    };
}


/* ==================================================
   EMPTY
================================================== */

function showEmpty(
    title,
    description
) {

    const table =
        $("absenceReportTable") ||
        $("gradesReportTable");


    const empty =
        $("reportEmpty");


    if (table) {

        table.hidden = true;

        table.innerHTML = "";
    }


    if (empty) {

        empty.hidden = false;


        const titleElement =
            empty.querySelector(
                ".report-empty-title"
            );


        const textElement =
            empty.querySelector(
                ".report-empty-text"
            );


        if (titleElement) {

            titleElement.textContent =
                title;
        }


        if (textElement) {

            textElement.textContent =
                description;
        }

    }


    const subtitle =
        $("reportSubtitle");


    if (subtitle) {

        subtitle.textContent =
            description;
    }


    const status =
        $("reportStatus");


    if (status) {

        status.textContent =
            "لا توجد بيانات";
    }


    state.report =
        null;
}


/* ==================================================
   REPORT INFO
================================================== */

function updateReportInfo(
    month,
    subjectValue,
    classValue,
    studentCount
) {

    const subtitle =
        $("reportSubtitle");


    const status =
        $("reportStatus");


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                subjectValue
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                classValue
        );


    const subjectText =
        subjectValue
            ? (
                subjectName(subject) ||
                "المادة"
            )
            : "كل المواد";


    const classText =
        classValue
            ? (
                className(classItem) ||
                "الصف"
            )
            : "كل الصفوف";


    if (subtitle) {

        subtitle.textContent =
            `${monthLabel(month)} • ${subjectText} • ${classText} • ${formatNumber(studentCount)} طالب`;
    }


    if (status) {

        status.textContent =
            "تم إعداد التقرير";
    }
}


/* ==================================================
   DOWNLOAD TOAST
================================================== */

let downloadToastTimer =
    null;


function showDownloadToast(
    title = "جاري تنزيل الملف...",
    text = "سيتم حفظ التقرير على جهازك"
) {

    const toast =
        $("downloadToast");


    const titleElement =
        $("downloadToastTitle");


    const textElement =
        $("downloadToastText");


    if (!toast) {

        return;
    }


    if (titleElement) {

        titleElement.textContent =
            title;
    }


    if (textElement) {

        textElement.textContent =
            text;
    }


    clearTimeout(
        downloadToastTimer
    );


    toast.hidden =
        false;


    requestAnimationFrame(
        () => {

            toast.classList.add(
                "show"
            );

        }
    );


    downloadToastTimer =
        setTimeout(
            () => {

                toast.classList.remove(
                    "show"
                );


                setTimeout(
                    () => {

                        toast.hidden =
                            true;

                    },
                    250
                );

            },
            3000
        );
}


/* ==================================================
   CLEAR TOAST
================================================== */

function hideDownloadToast() {

    const toast =
        $("downloadToast");


    if (!toast) {

        return;
    }


    toast.classList.remove(
        "show"
    );


    setTimeout(
        () => {

            toast.hidden =
                true;

        },
        250
    );
}


/* ==================================================
   EXCEL HELPERS
================================================== */

function getExportRows() {

    if (
        !state.report
    ) {

        return [];
    }


    const rows = [];


    const students =
        state.report.students;


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                state.report.subjectId
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                state.report.classId
        );


    rows.push([
        "تقرير الدرجات"
    ]);


    rows.push([
        "الشهر",
        monthLabel(
            state.report.month
        )
    ]);


    rows.push([
        "المادة",
        state.report.subjectId
            ? subjectName(subject)
            : "كل المواد"
    ]);


    rows.push([
        "الصف",
        state.report.classId
            ? className(classItem)
            : "كل الصفوف"
    ]);


    rows.push([
        "عدد الطلاب",
        students.length
    ]);


    rows.push([]);


    /*
       صف الأسابيع.
    */

    const weekHeader = [

        "اسم الطالب"

    ];


    state.report.weeks.forEach(
        item => {

            item.evaluations.forEach(
                () => {

                    weekHeader.push(
                        getWeekName(
                            item.week,
                            state.schoolWeeks.indexOf(
                                item.week
                            )
                        )
                    );

                }
            );

        }
    );


    weekHeader.push(
        "المجموع الكلي للشهر"
    );


    rows.push(
        weekHeader
    );


    /*
       صف أسماء التقييمات + الدرجة الكلية.
    */

    const evaluationHeader = [

        ""

    ];


    state.report.weeks.forEach(
        item => {

            item.evaluations.forEach(
                evaluation => {

                    const total =
                        evaluationTotal(
                            evaluation
                        );


                    const name =
                        evaluationName(
                            evaluation
                        );


                    evaluationHeader.push(

                        total !== null

                            ? `${name} (${formatGrade(total)})`

                            : name

                    );

                }
            );

        }
    );


    evaluationHeader.push(

        state.report.maximumMonthlyTotal !== null

            ? `(${formatGrade(
                state.report.maximumMonthlyTotal
            )})`

            : ""

    );


    rows.push(
        evaluationHeader
    );


    /*
       بيانات الطلاب.
    */

    students.forEach(
        student => {

            const row = [

                student.name

            ];


            let total =
                0;


            state.report.weeks.forEach(
                item => {

                    item.evaluations.forEach(
                        evaluation => {

                            const record =
                                getGradeRecord(
                                    item.week,
                                    evaluation,
                                    student,
                                    state.report.subjectId,
                                    state.report.classId
                                );


                            const value =
                                getGradeValue(
                                    record
                                );


                            const numeric =
                                numericGrade(
                                    value
                                );


                            if (
                                numeric !== null
                            ) {

                                total +=
                                    numeric;


                                row.push(
                                    numeric
                                );

                            } else if (
                                value !== null &&
                                value !== undefined &&
                                String(value).trim()
                            ) {

                                row.push(
                                    value
                                );

                            } else {

                                row.push(
                                    "—"
                                );
                            }

                        }
                    );

                }
            );


            row.push(
                total
            );


            rows.push(
                row
            );

        }
    );


    return rows;
}


/* ==================================================
   EXCEL EXPORT
================================================== */

function exportTableToExcel() {

    refreshStorage();


    if (
        !state.report
    ) {

        buildReport();
    }


    if (
        !state.report ||
        !state.report.weeks.length
    ) {

        return;
    }


    if (!window.MueenXLSX || typeof window.MueenXLSX.create !== "function") {
        window.MueenUI.alert("تعذر تجهيز ملف Excel.", "تعذر التصدير");
        return;
    }


    showDownloadToast(
        "جاري تجهيز التقرير...",
        "يتم إنشاء ملف Excel وتنزيله على جهازك الآن"
    );


    const button =
        $("exportExcelButton");


    if (button) {

        button.disabled =
            true;
    }


    setTimeout(
        () => {

            try {

                const rows =
                    getExportRows();


                const fileName = `تقرير الدرجات - ${monthLabel(state.report.month)}.xlsx`;

                const blob = window.MueenXLSX.create(rows, "تقرير الدرجات");

                if (window.MueenNative?.available && typeof window.MueenNative.saveFileBase64 === "function") {
                    const reader = new FileReader();
                    reader.onload = () => {
                        const result = String(reader.result || "");
                        const comma = result.indexOf(",");
                        const base64 = comma >= 0 ? result.slice(comma + 1) : result;
                        window.MueenNative.saveFileBase64(
                            base64,
                            fileName,
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        ).then(() => {
                            showDownloadToast(
                                "تم حفظ ملف Excel في مجلد التنزيلات ✓",
                                "تم حفظ التقرير على جهازك"
                            );
                        }).catch((error) => {
                            console.error("MUEEN native export error:", error);
                            showDownloadToast(
                                error?.message || "تعذر حفظ ملف Excel على الهاتف",
                                "تعذر الحفظ"
                            );
                        });
                    };
                    reader.readAsDataURL(blob);
                } else {
                    try {
                        const file = new File([blob], fileName, {
                            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        });
                        if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                            navigator.share({
                                title: "ملف من مُعين",
                                text: fileName,
                                files: [file]
                            }).catch(() => {});
                        } else {
                            const url = URL.createObjectURL(blob);
                            window.open(url, "_blank", "noopener");
                            setTimeout(() => URL.revokeObjectURL(url), 10000);
                        }
                    } catch (shareError) {
                        console.warn("MUEEN export share failed:", shareError);
                    }
                }




                showDownloadToast(
                    "تم تنزيل ملف Excel ✓",
                    "تم حفظ تقرير الدرجات على جهازك"
                );


            } catch (error) {

                console.error(
                    "Excel export error:",
                    error
                );


                showDownloadToast(
                    "تعذر تنزيل الملف",
                    "حدث خطأ أثناء تجهيز تقرير Excel"
                );

            } finally {

                if (button) {

                    button.disabled =
                        false;
                }

            }

        },
        120
    );
}


/* ==================================================
   PRINT TABLE
================================================== */

function buildPrintableTable() {

    const table =
        $("absenceReportTable") ||
        $("gradesReportTable");


    if (!table) {

        return "";
    }


    return table.outerHTML;
}


/* ==================================================
   PRINT / PDF
================================================== */

function exportToPDF() {

    refreshStorage();


    if (
        !state.report
    ) {

        buildReport();
    }


    if (
        !state.report ||
        !state.report.weeks.length
    ) {

        return;
    }


    if (window.MueenNative?.available && typeof window.MueenNative.printHtml === "function") {
        try {
            window.MueenNative.printHtml(
                document.documentElement.outerHTML,
                "تقرير مُعين"
            );
            return;
        } catch (_) {}
    }

    const printWindow =
        window.open(
            "",
            "_blank",
            "noopener,noreferrer,width=1200,height=850,scrollbars=yes,resizable=yes"
        );


    if (!printWindow) {

        alert(
            "تعذر فتح نافذة الطباعة. يرجى السماح للنوافذ المنبثقة ثم المحاولة مرة أخرى."
        );

        return;
    }


    const subject =
        state.subjects.find(
            item =>
                subjectId(item) ===
                state.report.subjectId
        );


    const classItem =
        state.classes.find(
            item =>
                classId(item) ===
                state.report.classId
        );


    const subjectText =
        state.report.subjectId
            ? (
                subjectName(subject) ||
                "المادة"
            )
            : "كل المواد";


    const classText =
        state.report.classId
            ? (
                className(classItem) ||
                "الصف"
            )
            : "كل الصفوف";


    const studentCount =
        state.report.students.length;


    const printableTable =
        buildPrintableTable();


    const printDocument = `

<!DOCTYPE html>

<html
    lang="ar"
    dir="rtl"
>

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        تقرير الدرجات - ${escapeHTML(
            monthLabel(
                state.report.month
            )
        )}
    </title>


    <style>

        @page {

            size: A4 landscape;

            margin: 10mm;

        }


        * {

            box-sizing: border-box;

        }


        html {

            direction: rtl;

        }


        body {

            margin: 0;

            padding: 0;

            background: white;

            color: #18343A;

            font-family:
                Arial,
                Tahoma,
                sans-serif;

            direction: rtl;

        }


        .print-page {

            width: 100%;

        }


        .print-header {

            margin-bottom: 12px;

            padding-bottom: 10px;

            border-bottom:
                2px solid #073B46;

        }


        .print-brand {

            color: #073B46;

            font-size: 19px;

            font-weight: 900;

        }


        .print-title {

            margin-top: 3px;

            color: #18343A;

            font-size: 16px;

            font-weight: 800;

        }


        .print-info {

            margin-top: 10px;

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 7px;

        }


        .print-info-item {

            padding:
                7px 9px;

            background: #F5F7F6;

            border:
                1px solid #E3E9E7;

            border-radius: 7px;

            font-size: 10px;

        }


        .print-info-label {

            color: #687B80;

            font-weight: 700;

        }


        .print-info-value {

            margin-right: 4px;

            color: #073B46;

            font-weight: 900;

        }


        .print-table-wrap {

            width: 100%;

            overflow: visible;

        }


        table {

            width: 100%;

            border-collapse: collapse;

            table-layout: auto;

            direction: rtl;

            font-size: 8px;

        }


        th,
        td {

            padding:
                4px 3px;

            border:
                1px solid #CBD5D3;

            text-align: center;

            vertical-align: middle;

        }


        th {

            background: #F1F5F4;

            color: #073B46;

            font-weight: 900;

        }


        td {

            color: #18343A;

            font-weight: 700;

        }


        .report-student-header,
        .report-student-cell {

            min-width: 90px;

            text-align: right !important;

        }


        .student-number {

            display: inline-block;

            min-width: 18px;

            margin-left: 3px;

            padding: 2px 3px;

            border-radius: 4px;

            background: #EDF5F5;

            color: #073B46;

            font-size: 7px;

            font-weight: 900;

        }


        .report-week-header {

            background: #EDF5F5 !important;

        }


        .report-week-name {

            color: #073B46;

            font-size: 9px;

            font-weight: 900;

        }


        .report-week-date {

            margin-top: 2px;

            color: #687B80;

            font-size: 7px;

            font-weight: 700;

        }


        .report-day-header {

            width: 34px;

            min-width: 34px;

            height: 76px;

            padding:
                3px 2px !important;

        }


        .report-day-name {

            display: block;

            writing-mode:
                vertical-rl;

            text-orientation:
                mixed;

            white-space:
                nowrap;

            margin:
                0 auto 7px;

            color: #073B46;

            font-size: 7px;

            font-weight: 900;

            line-height: 1;

        }


        .report-evaluation-total {

            display: block;

            direction: ltr;

            color: #8D6A30;

            font-size: 8px;

            font-weight: 900;

            line-height: 1;

        }


        .report-total-title {

            color: #8D6A30;

            font-size: 8px;

            font-weight: 900;

        }


        .report-total-max {

            margin-top: 5px;

            color: #8D6A30;

            font-size: 9px;

            font-weight: 900;

        }


        .attendance-cell {

            width: 34px;

            min-width: 34px;

            height: 30px;

            font-size: 9px !important;

            font-weight: 900 !important;

        }


        .attendance-cell.present {

            color: #4F8064 !important;

            background: #F7FBF8 !important;

        }


        .attendance-cell.empty {

            color: #AAB5B6 !important;

            background: #FCFDFC !important;

        }


        .total-absence-header {

            min-width: 70px;

            background:
                #F8F2E8 !important;

            color:
                #8D6A30 !important;

        }


        .total-absence-cell {

            min-width: 70px;

            background:
                #FFFCF6 !important;

            color:
                #8D6A30 !important;

            font-weight: 900 !important;

        }


        .print-footer {

            margin-top: 10px;

            padding-top: 6px;

            border-top:
                1px solid #E3E9E7;

            color: #687B80;

            font-size: 7px;

            text-align: center;

        }


        @media print {

            body {

                -webkit-print-color-adjust:
                    exact;

                print-color-adjust:
                    exact;

            }


            .print-page {

                page-break-inside:
                    avoid;

            }

        }

    </style>

</head>


<body>


<div class="print-page">


    <div class="print-header">

        <div class="print-brand">
            مُعين | MUEEN
        </div>


        <div class="print-title">
            تقرير الدرجات
        </div>


        <div class="print-info">


            <div class="print-info-item">

                <span class="print-info-label">
                    الشهر:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        monthLabel(
                            state.report.month
                        )
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    المادة:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        subjectText
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    الصف:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        classText
                    )}
                </span>

            </div>


            <div class="print-info-item">

                <span class="print-info-label">
                    عدد الطلاب:
                </span>

                <span class="print-info-value">
                    ${escapeHTML(
                        formatNumber(
                            studentCount
                        )
                    )}
                </span>

            </div>


        </div>

    </div>


    <div class="print-table-wrap">

        ${printableTable}

    </div>


    <div class="print-footer">

        تقرير الدرجات الشهري — مُعين | MUEEN

    </div>


</div>


<script>

    window.onload = function () {

        setTimeout(
            function () {

                window.focus();

                window.print();

            },
            500
        );

    };


    window.onafterprint = function () {

        setTimeout(
            function () {

                window.close();

            },
            300
        );

    };

</script>


</body>

</html>

`;


    printWindow.document.open();

    printWindow.document.write(
        printDocument
    );

    printWindow.document.close();

}


/* ==================================================
   NAVIGATION
================================================== */

function goMain(page) {

    window.location.replace(
        page
    );
}


function goServicePage(page) {

    window.location.href =
        page;
}


function goSubPage(page) {

    window.location.href =
        page;
}


/* ==================================================
   EVENTS
================================================== */

function bindEvents() {


    /* --------------------------------------------------
       FILTERS
    -------------------------------------------------- */

    $("monthSelect")
        ?.addEventListener(
            "change",
            () => {

                state.selectedStudents =
                    new Set();


                rebuildStudents();

                buildReport();

            }
        );


    $("subjectSelect")
        ?.addEventListener(
            "change",
            () => {

                buildReport();

            }
        );


    $("classSelect")
        ?.addEventListener(
            "change",
            () => {

                state.selectedStudents =
                    new Set();


                rebuildStudents();

                buildReport();

            }
        );


    /* --------------------------------------------------
       STUDENT SEARCH
    -------------------------------------------------- */

    $("studentSearch")
        ?.addEventListener(
            "input",
            () => {

                renderStudentSearch();

            }
        );


    $("clearStudentSearch")
        ?.addEventListener(
            "click",
            () => {

                const input =
                    $("studentSearch");


                if (input) {

                    input.value = "";

                    input.focus();

                }


                renderStudentSearch();

            }
        );


    $("clearStudentSelection")
        ?.addEventListener(
            "click",
            () => {

                state.selectedStudents =
                    new Set();


                updateSelectionUI();

                renderStudentSearch();

                buildReport();

            }
        );


    /* --------------------------------------------------
       EXPORT
    -------------------------------------------------- */

    $("exportExcelButton")
        ?.addEventListener(
            "click",
            exportTableToExcel
        );


    $("exportPdfButton")
        ?.addEventListener(
            "click",
            exportToPDF
        );


    /* --------------------------------------------------
       HEADER BACK
    -------------------------------------------------- */

    $("backButton")
        ?.addEventListener(
            "click",
            () => {

                goMain(
                    "reports.html"
                );

            }
        );


    /* --------------------------------------------------
       BOTTOM NAVIGATION
       نفس الصفحة الرئيسية
    -------------------------------------------------- */

    $("homeNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "home.html"
                )
        );


    $("attendanceNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "attendance.html"
                )
        );


    $("studentsNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "students.html"
                )
        );


    $("scheduleNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "schedule.html"
                )
        );


    $("gradesNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "grades.html"
                )
        );


    $("reportsNavigation")
        ?.addEventListener(
            "click",
            () =>
                goMain(
                    "reports.html"
                )
        );

}


/* ==================================================
   INITIALIZE
================================================== */

function initialize() {

    refreshStorage();

    buildMonthSelect();

    buildSubjectSelect();

    buildClassSelect();

    rebuildStudents();

    updateSelectionUI();

    bindEvents();

    buildReport();

}


/* ==================================================
   STORAGE REFRESH
================================================== */

window.addEventListener(
    "storage",
    () => {

        refreshStorage();

        buildMonthSelect();

        buildSubjectSelect();

        buildClassSelect();

        rebuildStudents();

        buildReport();

    }
);


/* ==================================================
   PAGE VISIBILITY
================================================== */

document.addEventListener(
    "visibilitychange",
    () => {

        if (
            document.visibilityState ===
            "visible"
        ) {

            refreshStorage();

            buildMonthSelect();

            buildSubjectSelect();

            buildClassSelect();

            rebuildStudents();

            buildReport();

        }

    }
);


/* ==================================================
   START
================================================== */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initialize
    );

} else {

    initialize();

}