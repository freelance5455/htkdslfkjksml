import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'pk.bilaltraders.wholesale',
  appName: 'Bilal Traders Wholesale',
  webDir: 'dist',
  bundledWebRuntime: false
};
export default config;
