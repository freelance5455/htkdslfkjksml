export type UnitId = 'piece'|'dozen'|'tora'|'bundle'|'carton'|'peti'|'kg'|'gram'|'packet'|'box'|'sack'|'custom';
export type OrderStatus = 'pending'|'confirmed'|'dispatched'|'delivered'|'cancelled';
export type PayStatus = 'paid'|'partially_paid'|'unpaid';
export interface PackUnit { id:string; name:string; conversion:number; price:number; minQty:number; enabled:boolean }
export interface Product {
  id:string; sku:string; name:string; category:string; description:string; baseUnit:string;
  stock:number; reorder:number; image?:string; available:boolean; units:PackUnit[];
}
export interface Customer { id:string; name:string; shop:string; phone:string; village:string; address:string; creditLimit:number; balance:number; approved:boolean; blocked:boolean }
export interface CartLine { productId:string; unitId:string; qty:number }
export interface OrderLine { productId:string; productName:string; unitName:string; qty:number; conversion:number; unitPrice:number; total:number; baseUsed:number }
export interface Order {
  id:string; number:string; customerId:string; customerName:string; shop:string; phone:string; village:string;
  address:string; lines:OrderLine[]; subtotal:number; discount:number; delivery:number; total:number;
  paid:number; balance:number; status:OrderStatus; paymentStatus:PayStatus; createdAt:string;
}
export interface Txn { id:string; customerId:string; kind:'credit'|'payment'|'adjustment'; amount:number; note:string; date:string; balanceAfter:number }
export interface Visit { id:string; date:string; village:string; status:'visited'|'pending'|'skipped'; cash:number; orders:number; notes:string }
export interface AppData { products:Product[]; customers:Customer[]; orders:Order[]; txns:Txn[]; visits:Visit[]; adminPin:string; shopPin:string }
