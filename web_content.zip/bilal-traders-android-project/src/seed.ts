import type { AppData, Product } from './types';
const product=(id:string,sku:string,name:string,category:string,baseUnit:string,stock:number,reorder:number,units:Product['units']):Product=>({id,sku,name,category,description:'ہول سیل آئٹم',baseUnit,stock,reorder,available:true,units});
export const initialData:AppData={
 products:[
  product('p1','SNK-COCOMO-10','کوکومو بسکٹ 10 روپے','گولی، ٹافی، پاپڑ اور سنیکس','پیکٹ',1440,192,[
   {id:'carton',name:'کارٹن (48 پیکٹ)',conversion:48,price:410,minQty:1,enabled:true},{id:'peti',name:'پیٹی (288 پیکٹ)',conversion:288,price:2400,minQty:1,enabled:true},{id:'bundle',name:'بنڈل (12 پیکٹ)',conversion:12,price:108,minQty:4,enabled:true}]),
  product('p2','SNK-DINGDONG','ڈنگ ڈانگ ببل گم','گولی، ٹافی، پاپڑ اور سنیکس','عدد',3600,480,[{id:'box',name:'ڈبہ (120 عدد)',conversion:120,price:480,minQty:1,enabled:true},{id:'carton',name:'کارٹن (1440 عدد)',conversion:1440,price:5600,minQty:1,enabled:true},{id:'dozen',name:'درجن',conversion:12,price:52,minQty:2,enabled:true}]),
  product('p3','GRC-TAPAL','ٹیپل دانیدار چائے 95 گرام','کریانہ اسٹور','پیکٹ',720,120,[{id:'carton',name:'کارٹن (24 پیکٹ)',conversion:24,price:4680,minQty:1,enabled:true},{id:'bundle',name:'بنڈل (6 پیکٹ)',conversion:6,price:1200,minQty:2,enabled:true}]),
  product('p4','GEN-DETTOL','ڈیٹول صابن 110 گرام','جنرل اسٹور','عدد',864,144,[{id:'carton',name:'کارٹن (72 عدد)',conversion:72,price:9720,minQty:1,enabled:true},{id:'dozen',name:'درجن',conversion:12,price:1680,minQty:1,enabled:true}]),
  product('p5','BK-COPY-120','اسکول کاپی 120 صفحات','بک ڈپو و اسٹیشنری','عدد',2400,240,[{id:'bundle',name:'بنڈل (60 کاپیاں)',conversion:60,price:3300,minQty:1,enabled:true},{id:'dozen',name:'درجن',conversion:12,price:690,minQty:2,enabled:true}])
 ],
 customers:[],orders:[],txns:[],visits:[],adminPin:'1234',shopPin:'7860'
};
