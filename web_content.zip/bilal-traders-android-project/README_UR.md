# بلال ٹریڈرز ہول سیل — Android-ready starter project

یہ React + TypeScript + Vite + Capacitor کا ابتدائی مکمل چلنے والا پروجیکٹ ہے۔

## شامل فیچرز
- اردو ہول سیل کیٹلاگ اور کیٹیگری فلٹر/تلاش
- کارٹ، پیکنگ یونٹ، MOQ، قیمت اور دستیاب اسٹاک چیک
- دکاندار پروفائل
- آرڈر محفوظ کرنا اور WhatsApp پر آرڈر شیئر کرنے کی کوشش
- آرڈر اسٹیٹس، جزوی/مکمل ادائیگی کا بنیادی حساب
- کسٹمر کھاتہ اور وصولی اندراج
- ایڈمن PIN، مصنوعات شامل/ترمیم، اسٹاک اضافہ/کمی
- گاہک بلاک/ان بلاک، دیہاتی وزٹ، رپورٹ CSV
- JSON بیک اپ
- Capacitor Android configuration

## چلانے کا طریقہ
1. کمپیوٹر پر Node.js LTS اور Android Studio انسٹال کریں۔
2. اس فولڈر میں terminal کھولیں:
   `npm install`
3. ویب ورژن چلائیں:
   `npm run dev`
4. production build:
   `npm run build`
5. Android platform بنائیں:
   `npx cap add android`
6. Android فائلیں sync کریں:
   `npx cap sync android`
7. Android Studio کھولیں:
   `npx cap open android`

## اہم سکیورٹی اور ڈیٹا وارننگ
یہ starter فی الحال localStorage میں ڈیٹا محفوظ کرتا ہے۔ اس کا مطلب:
- ڈیٹا صرف اسی براؤزر/ڈیوائس میں رہتا ہے؛ مختلف موبائلوں کے درمیان sync نہیں ہوتا۔
- ایڈمن PIN کلائنٹ ایپ میں ہے، اس لیے یہ production-grade authentication نہیں۔
- دکاندار کی شناخت اور admin permissions سرور سے verify نہیں ہوتیں۔
- WhatsApp کھولنے کا عمل موبائل/browser کے رویے پر منحصر ہے۔
- آرڈر، قیمت، اسٹاک اور کھاتہ کے حتمی لین دین کو production سے پہلے Firebase یا محفوظ backend کے server-side transactions اور security rules میں منتقل کرنا ضروری ہے۔
- موجودہ default admin PIN صرف demo کے لیے `1234` ہے۔ اسے حقیقی کاروبار میں استعمال نہ کریں۔

## Production مکمل کرنے کے لیے اگلا مرحلہ
Firebase Authentication/OTP، Firestore database، Firestore Security Rules، admin role claims، server-side order/stock/ledger transaction، image storage، audit logs اور signed Android release build شامل کرنا ہوگا۔

## کاروباری تفصیلات
Bilal Traders — Pakpattan Sharif
Owais Bilal Wattoo — 03017144300

نمونہ قیمتیں اور stock اعداد آپ کے فراہم کردہ کوڈ سے لیے گئے/نمونے ہیں؛ فروخت شروع کرنے سے پہلے ہر چیز کی تصدیق کریں۔
