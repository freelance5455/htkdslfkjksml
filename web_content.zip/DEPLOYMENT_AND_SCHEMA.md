# GNMTC SGNR — College Management System Architecture & Deployment Guide

## 1. Overview
The **GNMTC SGNR College Management System** is a mobile-first, native Android application built using **Kotlin**, **Jetpack Compose (Material 3)**, and **Google Cloud Firestore**. The design adheres to a professional nursing college aesthetic with a signature green (`#0D6938`), clean white (`#FFFFFF`), and clinical blue/teal (`#0284C7`) palette.

---

## 2. Core Modules (8 Main Folders)
1. **Know Your Teacher (शिक्षक परिचय):**
   - Searchable faculty directory by name, post, and department.
   - Profile cards showing degrees (M.Sc. Nursing, Ph.D.), experience, department, and contact info.
   - Admin controls to add, update, and deactivate teacher records.
2. **Batch (बैच प्रबंधन):**
   - 4 Discrete Batches: `Batch 2023-24`, `Batch 2024-25`, `Batch 2025-26`, `Batch 2026-27`.
   - 4 Sections per batch:
     - **A. About Coordinator:** Profile, qualifications, contact info, and admin assignment.
     - **B. Student Details:** Public student profile vs. sensitive private data (Bank Account, IFSC, Aadhaar, Jan Aadhaar, PAN) accessible only by verified administrators.
     - **C. Syllabus:** 8 core nursing subjects (Anatomy, Physiology, Psychology, Community Health, Fundamentals of Nursing, Nutrition, Microbiology, Medical-Surgical). Complete vs. Pending lecture topics.
     - **D. Attendance:** Weekly, Monthly, and Yearly attendance percentages computed dynamically from real database records.
3. **Complaint Registration (शिकायत दर्ज करें):**
   - Student grievance form (Name, Mobile, Batch, Description).
   - Generates a unique, confidential 4-digit tracking code (e.g. `1024` to `9999`).
   - One-touch copy to clipboard.
4. **Complaint Status (शिकायत की स्थिति):**
   - Real-time grievance lookup via 4-digit tracking code.
   - Visual progress timeline: `Received` ➔ `Under Review` ➔ `In Progress` ➔ `Resolved` / `Rejected`.
   - Official resolution remarks without leaking private student contact details.
5. **Notice Board (सूचना पट्ट):**
   - Category filtering (Academic, Clinical, Exams, Events, General).
   - Pinned urgent notices highlighted at the top.
   - Admin posting interface with circular attachment previews.
6. **Holiday Calendar (अवकाश कैलेंडर):**
   - Academic and state gazetted holidays in the `Asia/Kolkata` (IST) timezone.
   - Deepawali, Guru Nanak Jayanti, Winter Break, and International Nurses Day.
7. **Clinical Duty (क्लिनिकल ड्यूटी):**
   - **Section A. Teacher:** Clinical supervisors posted at Govt. District Hospital Sri Ganganagar.
   - **Section B. Roster:** Shift and ward schedules (Emergency/Trauma, ICU/OT, Maternal & Child Health) + Present/Absent attendance tracking.
8. **Admin Dashboard (प्रशासक लॉगिन):**
   - **Admin ID:** `GNMTC26`
   - **Admin Password:** `GNMTC2026`
   - Live metrics (Faculty count, enrolled students, active grievances, published notices).
   - Proctorial grievance queue with one-tap status advancement.
   - Administrative audit log and system settings.

---

## 3. Database Schema (Cloud Firestore)
- `/teachers/{teacherId}`: Faculty directory documents.
- `/coordinators/{batchId}`: Designated faculty coordinator per batch.
- `/students/{studentId}`: Public student profiles (Roll No, Name, Batch, Joining Date, DOB, Address).
- `/privateStudentRecords/{studentId}`: Protected financial & Indian identity records (Bank, IFSC, Aadhaar, Jan Aadhaar, PAN). Read and write restricted strictly to `isAdmin()`.
- `/subjects/{subjectId}`: Course curricula mapped to batches and faculty.
- `/syllabusLectures/{lectureId}`: Topic schedules, notes, and `isCompleted` boolean flag.
- `/studentAttendance/{attendanceId}`: Daily theory attendance entries.
- `/clinicalRosters/{rosterId}`: Clinical ward rotation schedules.
- `/clinicalAttendance/{dutyId}`: Hospital ward attendance logs.
- `/complaints/{complaintId}`: Student grievances with `trackingCode`, `status`, and `resolutionNote`.
- `/notices/{noticeId}`: College announcements with `isPinned` and `isPublished`.
- `/holidays/{holidayId}`: College holidays and academic vacations.

---

## 4. Security Rules Architecture
Hardened zero-trust rules deployed in `firestore.rules`:
- Default-deny catch-all: `match /{document=**} { allow read, write: if false; }`
- Verified administrator identification: checking email (`kuldeepsinghshekhawat5075@gmail.com`) and `/admins/{uid}` document existence.
- Zero PII leaks: `/privateStudentRecords/{studentId}` is gated exclusively to authorized administrators.
- Complaint validation: Ensures payload carries a valid 4-digit tracking string and limits description lengths to prevent storage abuse.

---

## 5. APK Generation & Distribution
1. In the AI Studio build environment, the APK is automatically compiled and signed with the configured debug keystore.
2. To download the compiled APK, click the **Export APK/AAB** or **Settings > Export Project** option in the AI Studio interface.
3. To package for production on Android Studio:
   ```bash
   gradle :app:assembleRelease
   ```
   The production APK will be generated at `app/build/outputs/apk/release/app-release.apk`.
