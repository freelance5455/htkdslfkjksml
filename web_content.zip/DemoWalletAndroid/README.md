# Demo Wallet Android project

A local-only Android demo wallet simulator. It has no internet permission and cannot connect to banks or payment networks.

## Features
- Sample balance starts at ₦250,000.00
- Simulated send, receive, deposit and withdrawal actions
- Local transaction history and demo receipt view
- Reset demo data
- Balance hide/show
- DEMO-only labeling throughout

## Build an APK
This project requires Android Studio (or Android SDK + Gradle) and JDK 17 or newer.
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Default local demo PIN: 1234. This is a basic app-entry PIN, not bank-grade security. No real funds, bank accounts, or payment rails are involved.
