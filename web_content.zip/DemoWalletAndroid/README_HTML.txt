HTML DEMO INCLUDED

Open demo-wallet.html in Chrome or another browser to use the offline Demo Wallet.
The same HTML file is also included at app/src/main/assets/index.html for Android WebView integration.
All balances and transactions are fictional and stored locally in the browser. No real payments are made.
