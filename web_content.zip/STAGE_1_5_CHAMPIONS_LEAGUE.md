# V117 — Socle 1.5 : Champions League Galactique

## Audit du format historique
Le fichier V116 a été inspecté directement. Son moteur `makeGroups()` / `cgdCLNext()` / `cgdCLKnockout()` confirme :
- 32 clubs qualifiés, ordonnés par points puis niveau ;
- quatre chapeaux de huit, répartition en serpentin dans huit groupes de quatre ;
- six journées de groupes en aller-retour ; chaque groupe joue 12 matchs, soit 96 matchs de groupes au total ;
- les deux premiers de chaque groupe sont qualifiés ;
- 16 clubs en phase finale : huitièmes, quarts, demi-finales, finale ;
- matchs à élimination directe en une seule rencontre, sans petite finale ;
- 15 matchs de phase finale, donc 111 rencontres par édition.

Le classement des groupes suit les critères observés dans V116 : points, différence de buts, buts marqués. En cas d'égalité parfaite, le moteur V117 conserve l'ordre stable du tirage comme départage technique, sans inventer un critère sportif.

## Portage réalisé
- Nouveau module `src/champions-league.js`.
- 32 clubs issus des divisions actives ; démarrage refusé si moins de 32 clubs sont disponibles.
- Huit groupes, six journées aller-retour et tableau final dynamique jusqu'au champion.
- Les 96 rencontres de groupes sont inscrites au calendrier central dès la création de l'édition ; les tours à élimination directe sont ajoutés après qualification.
- Les créneaux déjà attribués aux journées de groupes sont protégés lorsque des tours suivants d'autres coupes sont créés. Un test de capacité vérifie les 19 créneaux FGD du mardi actuellement connus pour la Coupe Galactique, la Coupe Fédéral et la Champions League, en gardant les jeudis lunaires et les samedis de championnat libres. Les créneaux de la Coupe Lunaire ne sont pas inventés : le code V116 l’identifie comme compétition AGD et son calendrier/moteur restent à auditer.
- Simulation des rencontres par le moteur commun de dames ; le match du club dirigé reste jouable manuellement.
- Statistiques de compétition séparées des classements des divisions ; protection contre les doubles résultats.
- Tableau de groupes et phase finale affichés dans l'interface.
- Les égalités de groupes sont conservées ; une égalité en élimination directe est départagée de façon reproductible pour éviter un blocage.

## Contrôles
- `npm test` : 107 tests réussis, 0 échec.
- Vérification syntaxique de tous les modules JavaScript réussie.
- Test réel navigateur/mobile non confirmé dans cet environnement ; ne pas le présenter comme validé.

## Limites restantes
La saison ne peut toujours pas démarrer complètement : les moteurs des deux compétitions AGD, de la Coupe Lunaire et de la Dame d'Or restent à intégrer. Les dates officielles FGD/AGD et les sept jeudis lunaires doivent être fournis par leurs calendriers officiels. Les identités de clubs affichées restent des données de démonstration et ne remplacent pas encore l'import historique V116.

### Précision institutionnelle à confirmer
Le code V116 identifie la Coupe Lunaire comme une compétition AGD (`CGDAGDLunarCup` et libellés « Coupe Lunaire — AGD »). La nouvelle clarification institutionnelle de l'utilisateur cite deux compétitions galactiques AGD. Pour ne pas attribuer la Coupe Lunaire à la FGD par supposition, V117 la conserve provisoirement sous AGD et ne lui attribue aucune date FGD du mardi. Son calendrier officiel et son statut exact dans la nouvelle organisation devront être confirmés avant activation.
