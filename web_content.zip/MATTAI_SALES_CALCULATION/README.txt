MATTAI SALES CALCULATION

This app is focused only on Mattai buying, expenses, sales and profit/loss.
- Other expense entries use editable Person 1 to Person 5 labels.
- Partner profit sharing (Chandru / Arul 50%) has been removed.
- Select calculation date, save calculation history, and export a print-ready PDF.
- On Android, choose Save PDF in the print screen.

Install:
1. Publish these files on an HTTPS static host.
2. Open the published site in Chrome.
3. Chrome menu ⋮ → Install app / Add to Home screen.

This is an installable PWA, not a native APK.
