// MP MILK Ultimate v2.5 - Complete Feature Integration with Exact Image UI Theme

const REC_KEY = 'mp_milk_records_v2';
const SET_KEY = 'mp_milk_settings_v2';

let records = [];
let settings = {
    cowFatRate: 82, cowSnfRate: 42, cowFixRate: 45,
    bufFatRate: 85, bufSnfRate: 44, bufFixRate: 55.18,
    geminiKey: '', sheetUrl: '', appPin: ''
};

let currentShift = 'Morning';
let currentAnimal = 'Cow';
let ocrBase64 = null;

window.addEventListener('DOMContentLoaded', () => {
    loadDatabase();

    setTimeout(() => {
        const s = document.getElementById('splashScreen');
        s.style.opacity = '0';
        setTimeout(() => s.classList.add('hidden'), 500);
        if (settings.appPin && settings.appPin.length === 4) {
            document.getElementById('lockScreen').classList.remove('hidden');
        }
    }, 1600);

    const today = new Date().toISOString().split('T')[0];
    document.getElementById('entryDate').value = today;
    document.getElementById('historyDatePick').value = today;
    document.getElementById('billingMonthInput').value = today.slice(0, 7);

    setReportFilter(10, document.querySelector('.rep-tab'));
    
    const hr = new Date().getHours();
    setEntryShift(hr >= 14 ? 'Evening' : 'Morning');

    refreshDashboard();
    renderHistoryList();
});

function navigate(viewId) {
    document.querySelectorAll('.view-section').forEach(v => v.classList.remove('active'));
    document.getElementById(viewId).classList.add('active');

    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    const nb = document.getElementById('nav-' + viewId);
    if (nb) nb.classList.add('active');

    if (viewId === 'homeView') refreshDashboard();
    if (viewId === 'reportView') renderReports();
    if (viewId === 'historyView') renderHistoryList();
}

function openDrawer() {
    navigate('settingsView');
}

function startShiftEntry(shift) {
    navigate('entryView');
    setEntryShift(shift);
}

function setEntryShift(shift) {
    currentShift = shift;
    document.getElementById('btnMorning').classList.toggle('active-purple', shift === 'Morning');
    document.getElementById('btnEvening').classList.toggle('active-purple', shift === 'Evening');
    setAnimal(shift === 'Morning' ? 'Cow' : 'Buffalo');
}

function setAnimal(animal) {
    currentAnimal = animal;
    document.getElementById('btnCow').classList.toggle('active-animal', animal === 'Cow');
    document.getElementById('btnBuf').classList.toggle('active-animal', animal === 'Buffalo');
    recalcLive();
}

function toggleHolidayMode() {
    const isHol = document.getElementById('isHoliday').checked;
    document.getElementById('entryFieldsBox').classList.toggle('hidden', isHol);
    if (isHol) document.getElementById('entryNote').value = 'आज दूध का नागा / छुट्टी';
}

function recalcLive(manualRateTyped = false) {
    const rawL = parseFloat(document.getElementById('milkLitres').value) || 0;
    const fat = parseFloat(document.getElementById('milkFat').value) || 0;
    const snf = parseFloat(document.getElementById('milkSnf').value) || 0;
    const mode = document.getElementById('rateMode').value;
    const rateEl = document.getElementById('milkRate');

    let rate = parseFloat(rateEl.value) || 0;
    if (!manualRateTyped) {
        if (mode === 'manual') {
            rate = currentAnimal === 'Cow' ? settings.cowFixRate : settings.bufFixRate;
            rateEl.value = rate.toFixed(2);
        } else {
            const fRate = currentAnimal === 'Cow' ? settings.cowFatRate : settings.bufFatRate;
            const sRate = currentAnimal === 'Cow' ? settings.cowSnfRate : settings.bufSnfRate;
            if (fat > 0 || snf > 0) {
                rate = ((fat * (fRate / 10)) + (snf * (sRate / 10))) / 2;
                rateEl.value = rate.toFixed(2);
            } else {
                rate = currentAnimal === 'Cow' ? settings.cowFixRate : settings.bufFixRate;
                rateEl.value = rate.toFixed(2);
            }
        }
    }

    const prec = document.querySelector('input[name="prec"]:checked').value;
    const effectiveL = prec === 'one' ? Math.floor(rawL * 10) / 10 : rawL;
    const total = effectiveL * rate;

    document.getElementById('liveTotalAmt').textContent = '₹' + total.toFixed(2);
    return { rawL, effectiveL, fat, snf, rate, total };
}

function saveDairyEntry() {
    const date = document.getElementById('entryDate').value;
    const isHoliday = document.getElementById('isHoliday').checked;
    const note = document.getElementById('entryNote').value.trim();
    const editId = document.getElementById('editEntryId').value;

    if (!date) return alert('तारीख चुनें!');

    let rec;
    if (isHoliday) {
        rec = {
            id: editId ? Number(editId) : Date.now(),
            date, shift: currentShift, animal: currentAnimal,
            isHoliday: true, litres: 0, fat: 0, snf: 0, rate: 0, total: 0,
            note: note || 'नागा / छुट्टी'
        };
    } else {
        const c = recalcLive(true);
        if (c.rawL <= 0) return alert('दूध की मात्रा दर्ज करें!');
        rec = {
            id: editId ? Number(editId) : Date.now(),
            date, shift: currentShift, animal: currentAnimal,
            isHoliday: false,
            litres: Number(c.rawL.toFixed(2)),
            fat: Number(c.fat.toFixed(1)),
            snf: Number(c.snf.toFixed(1)),
            rate: Number(c.rate.toFixed(2)),
            total: Number(c.total.toFixed(2)),
            note
        };
    }

    if (editId) {
        const idx = records.findIndex(r => r.id === Number(editId));
        if (idx > -1) records[idx] = rec;
    } else {
        records.unshift(rec);
    }

    records.sort((a, b) => b.date.localeCompare(a.date));
    localStorage.setItem(REC_KEY, JSON.stringify(records));

    if (settings.sheetUrl) {
        fetch(settings.sheetUrl, { method: 'POST', mode: 'no-cors', body: JSON.stringify(rec) }).catch(() => {});
    }

    document.getElementById('milkLitres').value = '';
    document.getElementById('milkFat').value = '';
    document.getElementById('milkSnf').value = '';
    document.getElementById('entryNote').value = '';
    document.getElementById('editEntryId').value = '';
    document.getElementById('isHoliday').checked = false;
    toggleHolidayMode();

    alert('✔ हिसाब सफलतापूर्वक सेव हो गया!');
    navigate('homeView');
}

function refreshDashboard() {
    const today = new Date().toISOString().split('T')[0];
    const month = today.slice(0, 7);

    let m_l = 0, e_l = 0, earn = 0, m_tot = 0;
    records.forEach(r => {
        if (r.isHoliday) return;
        if (r.date === today) {
            if (r.shift === 'Morning') m_l += r.litres; else e_l += r.litres;
            earn += r.total;
        }
        if (r.date.startsWith(month)) m_tot += r.litres;
    });

    document.getElementById('todayTotalLitres').textContent = (m_l + e_l).toFixed(2);
    document.getElementById('todayMornL').textContent = m_l.toFixed(2) + ' L';
    document.getElementById('todayEveL').textContent = e_l.toFixed(2) + ' L';
    document.getElementById('todayEarned').textContent = '₹' + Math.round(earn).toLocaleString('en-IN');
    document.getElementById('monthLitres').textContent = m_tot.toFixed(1) + ' L';
}

function setReportFilter(days, btn) {
    document.querySelectorAll('.rep-tab').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');

    const to = new Date().toISOString().split('T')[0];
    document.getElementById('repTo').value = to;

    if (days > 0) {
        const fromD = new Date();
        fromD.setDate(new Date().getDate() - (days - 1));
        document.getElementById('repFrom').value = fromD.toISOString().split('T')[0];
    } else {
        document.getElementById('repFrom').value = '2025-01-01';
    }
    renderReports();
}

function renderReports() {
    const from = document.getElementById('repFrom').value;
    const to = document.getElementById('repTo').value;

    const filtered = records.filter(r => {
        if (r.isHoliday) return false;
        if (from && r.date < from) return false;
        if (to && r.date > to) return false;
        return true;
    });

    let cowL = 0, cowAmt = 0, bufL = 0, bufAmt = 0;
    const map = {};

    filtered.forEach(r => {
        const isCow = (r.animal === 'Cow') || (!r.animal && r.shift === 'Morning');
        if (isCow) { cowL += r.litres; cowAmt += r.total; }
        else { bufL += r.litres; bufAmt += r.total; }

        if (!map[r.date]) map[r.date] = { morn: 0, eve: 0 };
        if (r.shift === 'Morning') map[r.date].morn += r.litres;
        else map[r.date].eve += r.litres;
    });

    const totL = cowL + bufL;
    const totAmt = cowAmt + bufAmt;

    document.getElementById('repTotalL').textContent = totL.toFixed(2) + ' L';
    document.getElementById('repTotalRs').textContent = '₹' + Math.round(totAmt).toLocaleString('en-IN');

    document.getElementById('sumCowL').textContent = cowL.toFixed(2) + ' L';
    document.getElementById('sumCowRs').textContent = '₹' + Math.round(cowAmt).toLocaleString('en-IN');
    document.getElementById('sumBufL').textContent = bufL.toFixed(2) + ' L';
    document.getElementById('sumBufRs').textContent = '₹' + Math.round(bufAmt).toLocaleString('en-IN');
    document.getElementById('sumTotL').textContent = totL.toFixed(2) + ' L';
    document.getElementById('sumTotRs').textContent = '₹' + Math.round(totAmt).toLocaleString('en-IN');

    // Chart
    const dates = Object.keys(map).sort().slice(-10);
    const box = document.getElementById('chartContainer');
    if (!dates.length) {
        box.innerHTML = `<p style="margin:auto;color:#94a3b8;font-size:0.8rem;">डेटा उपलब्ध नहीं है</p>`;
        return;
    }

    let max = 15;
    dates.forEach(d => max = Math.max(max, map[d].morn, map[d].eve));

    box.innerHTML = dates.map(d => {
        const mh = Math.max(6, Math.round((map[d].morn / max) * 110));
        const eh = Math.max(6, Math.round((map[d].eve / max) * 110));
        return `
        <div class="bar-group">
            <div class="bar-pair">
                <div class="bar-morn" style="height:${mh}px" title="सुबह: ${map[d].morn}L"></div>
                <div class="bar-eve" style="height:${eh}px" title="शाम: ${map[d].eve}L"></div>
            </div>
            <span class="bar-lbl">${d.split('-')[2]}</span>
        </div>`;
    }).join('');
}

// 10-Day Cycle Modal
function renderBillingCycles() {
    const m = document.getElementById('billingMonthInput').value;
    if (!m) return;
    const mRecs = records.filter(r => r.date.startsWith(m) && !r.isHoliday);
    const cycles = [
        { name: 'चक्र 1 (1 से 10 तारीख)', min: 1, max: 10, l: 0, rs: 0 },
        { name: 'चक्र 2 (11 से 20 तारीख)', min: 11, max: 20, l: 0, rs: 0 },
        { name: 'चक्र 3 (21 से महीने का अंत)', min: 21, max: 31, l: 0, rs: 0 }
    ];

    mRecs.forEach(r => {
        const d = parseInt(r.date.split('-')[2], 10);
        const c = cycles.find(x => d >= x.min && d <= x.max);
        if (c) { c.l += r.litres; c.rs += r.total; }
    });

    document.getElementById('cycleCardsContainer').innerHTML = cycles.map(c => `
        <div style="background:#07060e; border:1px solid #262240; padding:12px; border-radius:14px;">
            <h4 style="color:#fbbf24; font-size:0.92rem; margin-bottom:4px;">${c.name}</h4>
            <div style="display:flex; justify-content:space-between; font-size:0.85rem; color:#cbd5e1;">
                <span>दूध: <b>${c.l.toFixed(2)} L</b></span>
                <span style="color:#10b981;">राशि: <b>₹${c.rs.toFixed(2)}</b></span>
            </div>
        </div>
    `).join('');
}

// History & Stepper
function stepHistoryDate(dir) {
    const pick = document.getElementById('historyDatePick');
    const dt = new Date(pick.value || new Date());
    dt.setDate(dt.getDate() + dir);
    pick.value = dt.toISOString().split('T')[0];
    renderHistoryList();
}

function renderHistoryList() {
    const sel = document.getElementById('historyDatePick').value;
    const day = records.filter(r => r.date === sel);
    document.getElementById('selectedDayList').innerHTML = day.length ? day.map(r => buildCard(r, false)).join('') : `<div class="entry-history-card" style="text-align:center;color:#94a3b8;">इस तारीख पर कोई एंट्री नहीं है।</div>`;
    document.getElementById('allHistoryList').innerHTML = records.slice(0, 20).map(r => buildCard(r, true)).join('');
}

function buildCard(r, showDate) {
    const isCow = (r.animal === 'Cow') || (!r.animal && r.shift === 'Morning');
    return `
    <div class="entry-history-card">
        <div class="eh-top">
            <span class="eh-animal-ico">${isCow ? '🐄' : '🐃'}</span>
            <span class="eh-animal-name">${isCow ? 'गाय' : 'भैंस'}</span>
            <span class="${r.shift === 'Morning' ? 'badge-morn' : 'badge-eve'}">${r.shift === 'Morning' ? 'सुबह' : 'शाम'}</span>
            ${showDate ? `<small style="margin-left:auto;color:#94a3b8;">${r.date}</small>` : ''}
        </div>
        <div class="eh-metrics">
            <b>${r.litres.toFixed(2)} L</b> | Fat: ${r.fat} | SNF: ${r.snf}
            ${r.note ? `<br><small style="color:#a855f7;">📌 ${r.note}</small>` : ''}
        </div>
        <div class="eh-bottom">
            <div class="eh-price">₹${r.total.toFixed(2)}</div>
            <div class="eh-btns">
                <button class="ico-action" onclick="shareSlip(${r.id})" title="WhatsApp">🟢</button>
                <button class="ico-action" onclick="editRec(${r.id})" title="Edit">✏️</button>
                <button class="ico-action del" onclick="delRec(${r.id})" title="Delete">🗑️</button>
            </div>
        </div>
    </div>`;
}

function editRec(id) {
    const r = records.find(x => x.id === id);
    if (!r) return;
    navigate('entryView');
    setEntryShift(r.shift);
    setAnimal(r.animal || (r.shift === 'Morning' ? 'Cow' : 'Buffalo'));
    document.getElementById('entryDate').value = r.date;
    document.getElementById('milkLitres').value = r.litres;
    document.getElementById('milkFat').value = r.fat;
    document.getElementById('milkSnf').value = r.snf;
    document.getElementById('milkRate').value = r.rate;
    document.getElementById('entryNote').value = r.note || '';
    document.getElementById('editEntryId').value = r.id;
    recalcLive(true);
}

function delRec(id) {
    if (!confirm('हटाना चाहते हैं?')) return;
    records = records.filter(x => x.id !== id);
    localStorage.setItem(REC_KEY, JSON.stringify(records));
    renderHistoryList();
    refreshDashboard();
}

// Rate settings
function switchRateAnimal(animal, btn) {
    document.querySelectorAll('#rateView .animal-pill').forEach(p => p.classList.remove('active-animal'));
    btn.classList.add('active-animal');
    document.getElementById('cowRateBox').classList.toggle('hidden', animal !== 'Cow');
    document.getElementById('bufRateBox').classList.toggle('hidden', animal !== 'Buffalo');
}

function saveRateConfig() {
    settings.cowFat = parseFloat(document.getElementById('cfgCowFat').value) || 82;
    settings.cowSnf = parseFloat(document.getElementById('cfgCowSnf').value) || 42;
    settings.cowFix = parseFloat(document.getElementById('cfgCowFix').value) || 45;
    settings.bufFat = parseFloat(document.getElementById('cfgBufFat').value) || 85;
    settings.bufSnf = parseFloat(document.getElementById('cfgBufSnf').value) || 44;
    settings.bufFix = parseFloat(document.getElementById('cfgBufFix').value) || 55.18;
    localStorage.setItem(SET_KEY, JSON.stringify(settings));
    alert('✔ रेट सफलतापूर्वक सेव हो गए!');
    navigate('homeView');
}

// CLR Math
function runClrMath() {
    const f = parseFloat(document.getElementById('calcFat').value) || 0;
    const c = parseFloat(document.getElementById('calcClr').value) || 0;
    const snf = (c / 4) + (0.21 * f) + 0.36;
    document.getElementById('calcSnfOut').textContent = snf.toFixed(2) + ' %';
    return { f, snf };
}
function applyClrSnf() {
    const r = runClrMath();
    closeModal('calcModal');
    navigate('entryView');
    document.getElementById('milkFat').value = r.f.toFixed(1);
    document.getElementById('milkSnf').value = r.snf.toFixed(1);
    recalcLive();
}

// OCR
function previewOcrImg(e) {
    const f = e.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = ev => {
        ocrBase64 = ev.target.result;
        const im = document.getElementById('ocrPrevImg');
        im.src = ocrBase64;
        im.classList.remove('hidden');
        document.getElementById('ocrPrompt').textContent = '✅ फोटो तैयार है';
    };
    rd.readAsDataURL(f);
}

function processOcrInput() {
    const txt = document.getElementById('ocrText').value.trim();
    if (txt) {
        const getNum = reg => { const m = txt.match(reg); return m ? parseFloat(m[1]) : 0; };
        const litres = getNum(/(?:milk|qty|ltr|दूध)[:\s-]*([0-9]+(?:\.[0-9]+)?)/i) || getNum(/([0-9]+(?:\.[0-9]+)?)\s*(?:l|ltr)/i);
        const fat = getNum(/fat[:\s-]*([0-9]+(?:\.[0-9]+)?)/i);
        const snf = getNum(/snf[:\s-]*([0-9]+(?:\.[0-9]+)?)/i);
        const rate = getNum(/rate[:\s-]*₹?([0-9]+(?:\.[0-9]+)?)/i);
        applyOcrData({ litres, fat, snf, rate });
        return;
    }
    alert('कृपया SMS टेक्स्ट पेस्ट करें!');
}

function applyOcrData(d) {
    closeModal('scannerModal');
    navigate('entryView');
    if (d.litres) document.getElementById('milkLitres').value = d.litres;
    if (d.fat) document.getElementById('milkFat').value = d.fat;
    if (d.snf) document.getElementById('milkSnf').value = d.snf;
    if (d.rate) document.getElementById('milkRate').value = d.rate;
    recalcLive(!!d.rate);
}

// Sharing & Backup
function shareSlip(id) {
    const r = records.find(x => x.id === id);
    if (!r) return;
    const msg = `*👑 MP MILK पर्ची*%0A📅 तारीख: ${r.date} (${r.shift === 'Morning' ? 'सुबह' : 'शाम'})%0A🥛 दूध: ${r.litres} L%0A🧈 Fat: ${r.fat}% | SNF: ${r.snf}%%0A💰 *कुल: ₹${r.total.toFixed(2)}*`;
    window.open(`https://wa.me/?text=${msg}`, '_blank');
}
function shareWhatsAppReport() {
    const l = document.getElementById('repTotalL').textContent;
    const a = document.getElementById('repTotalRs').textContent;
    window.open(`https://wa.me/?text=*👑 MP MILK रिपोर्ट*%0A🥛 कुल दूध: ${l}%0A💰 कुल कमाई: ${a}`, '_blank');
}
function printPdfReport() { navigate('reportView'); setTimeout(() => window.print(), 300); }
function exportCsvData() {
    if (!records.length) return alert('कोई डेटा नहीं है!');
    const rows = ['Date,Shift,Animal,Litres,Fat,SNF,Rate,Total', ...records.map(r => `${r.date},${r.shift},${r.animal},${r.litres},${r.fat},${r.snf},${r.rate},${r.total}`)];
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURI(rows.join('\n'));
    a.download = 'MP_Milk_Export.csv';
    a.click();
}

function downloadJsonBackup() {
    const blob = new Blob([JSON.stringify({ records, settings }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'MP_Milk_Backup.json';
    a.click();
}
function restoreJsonBackup(e) {
    const f = e.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = ev => {
        try {
            const d = JSON.parse(ev.target.result);
            if (d.records) { records = d.records; localStorage.setItem(REC_KEY, JSON.stringify(records)); }
            if (d.settings) { settings = { ...settings, ...d.settings }; localStorage.setItem(SET_KEY, JSON.stringify(settings)); }
            refreshDashboard();
            closeModal('backupModal');
            alert('✔ रीस्टोर सफल रहा!');
        } catch (ex) { alert('अमान्य फ़ाइल!'); }
    };
    rd.readAsText(f);
}
function saveCloudConfig() {
    settings.sheetUrl = document.getElementById('cfgSheet').value.trim();
    localStorage.setItem(SET_KEY, JSON.stringify(settings));
    closeModal('backupModal');
    alert('✔ सेव हो गया!');
}
function savePinConfig() {
    settings.appPin = document.getElementById('cfgPinInput').value.trim();
    localStorage.setItem(SET_KEY, JSON.stringify(settings));
    closeModal('pinModal');
    alert('✔ PIN सेव हो गया!');
}
function verifyPin() {
    const val = document.getElementById('pinInput').value;
    if (val === settings.appPin) document.getElementById('lockScreen').classList.add('hidden');
    else document.getElementById('lockError').textContent = '❌ गलत PIN!';
}
function biometricAuth() { document.getElementById('lockScreen').classList.add('hidden'); }

function loadDatabase() {
    const s = localStorage.getItem(SET_KEY);
    if (s) { try { settings = { ...settings, ...JSON.parse(s) }; } catch (e) {} }
    const r = localStorage.getItem(REC_KEY);
    if (r) { try { records = JSON.parse(r); } catch (e) { records = []; } }

    document.getElementById('cfgCowFat').value = settings.cowFatRate || 82;
    document.getElementById('cfgCowSnf').value = settings.cowSnfRate || 42;
    document.getElementById('cfgCowFix').value = settings.cowFixRate || 45;
    document.getElementById('cfgBufFat').value = settings.bufFatRate || 85;
    document.getElementById('cfgBufSnf').value = settings.bufSnfRate || 44;
    document.getElementById('cfgBufFix').value = settings.bufFixRate || 55.18;
    document.getElementById('cfgSheet').value = settings.sheetUrl || '';
    document.getElementById('cfgPinInput').value = settings.appPin || '';
}

function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
    if (id === 'cycleModal') renderBillingCycles();
}
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
