# Chess Assistant Android

This Android Studio project includes a redesigned dark Chess Assistant start screen with a centered green PLAY button and three feature tiles.

## HTML entry
- `index.html` — root copy of the UI.
- `app/src/main/assets/web/index.html` — HTML loaded by the Android WebView at `file:///android_asset/web/index.html`.

Keep these two files synchronized when editing the UI.

## Run
1. Extract the ZIP.
2. Open the `ChessAssistantAndroid` folder in Android Studio.
3. Sync Gradle and run on an Android device.
4. Tap PLAY. Android asks for overlay permission first if needed, then opens its system screen-capture prompt. Approve it to start the capture service.

## Current scope
The project includes the start screen, permission flow, and floating-tab capture service prototype. Automatic chessboard recognition and live Stockfish move analysis are not implemented yet. Screen capture requires Android's system confirmation each session.
