// Cole aqui a configuração do seu projeto Firebase (Firebase Console > Configurações do projeto > Seus apps).
// Nunca coloque chaves privadas ou segredos de servidor neste arquivo.
export const firebaseConfig = {
  apiKey: "COLOQUE_SUA_API_KEY",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  databaseURL: "https://SEU_PROJETO-default-rtdb.firebaseio.com",
  projectId: "SEU_PROJETO",
  appId: "SEU_APP_ID"
};
// Informe os e-mails Google autorizados a administrar scripts.
export const ADMIN_EMAILS = ["seu-email@gmail.com"];
