NG C VS — PROTÓTIPO WEB COM DOIS APPS

Arquivos
- index.html: app dos usuários
- admin.html: painel para adicionar, editar e remover scripts
- firebase-config.js: configuração do Firebase
- database.rules.json: exemplo inicial de regras de banco

IMPORTANTE
Este pacote é um protótipo de interface. Login Google e sincronização entre celulares só funcionam depois de configurar Firebase e hospedar os arquivos em HTTPS (por exemplo, Firebase Hosting). Não abra simplesmente como arquivo local.

CONFIGURAÇÃO
1. Crie um projeto em https://console.firebase.google.com/.
2. Ative Authentication > Sign-in method > Google (usado apenas no painel admin) e Anonymous (usado pelo app principal).
3. Crie um Realtime Database.
4. Copie a configuração web do Firebase para firebase-config.js.
5. Em ADMIN_EMAILS, coloque o e-mail Google do administrador. O usuário final informa o Nick Roblox, que é consultado na API oficial do Roblox e tem o avatar carregado automaticamente. O Nick pode ser alterado em Configurações; gerar uma key não exige digitá-lo de novo.
6. Publique index.html, admin.html e firebase-config.js em Firebase Hosting ou outro host HTTPS.
7. Configure regras de segurança. Não deixe o banco público.

LIMITAÇÕES DE SEGURANÇA
- A chave gerada no navegador é um protótipo e não deve ser usada como autenticação real de um executor ou sistema pago. Para validação real, gere e valide chaves em backend confiável (por exemplo, Cloud Functions) e aplique regras que impeçam usuários de criar/alterar chaves arbitrariamente.
- A lista de e-mails de admin no JavaScript só controla a interface; NÃO é uma barreira de segurança suficiente. A autorização precisa ser validada nas regras do Firebase ou no backend.
- Os checkpoints de 30 segundos são demonstração de fluxo. Eles não exibem anúncios reais nem geram receita. Para monetizar, integre uma rede de anúncios compatível com seu tipo de app e siga as políticas dela. Não simule visualizações publicitárias.
- As regras em database.rules.json são um exemplo didático inicial, não uma configuração pronta para produção. Revise antes de publicar.
