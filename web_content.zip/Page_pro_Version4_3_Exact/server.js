const express=require("express");
const path=require("path"),crypto=require("crypto"),bcrypt=require("bcryptjs");
const {Pool}=require("pg");
const app=express(),PORT=process.env.PORT||3000;
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});

async function init(){
  await pool.query(`
    CREATE TABLE IF NOT EXISTS accounts(
      id SERIAL PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      page_name TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS posts(
      id SERIAL PRIMARY KEY,
      account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
      text TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY,
      account_id INTEGER REFERENCES accounts(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
}
app.use(express.json({limit:"200kb"}));
app.use(express.static(path.join(__dirname,"public")));

async function auth(req,res,next){
  try{
    const t=(req.headers.authorization||"").replace(/^Bearer\s+/i,"").trim();
    if(!t) return res.status(401).json({error:"Connexion requise"});
    const r=await pool.query(
      "SELECT a.id,a.phone,a.page_name FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token=$1",[t]
    );
    if(!r.rows.length) return res.status(401).json({error:"Session expirée"});
    req.account=r.rows[0]; next();
  }catch(e){res.status(500).json({error:"Erreur serveur"});}
}

app.get("/api/health",(q,s)=>s.json({ok:true,version:"4.3"}));

app.post("/api/register",async(q,s)=>{
  const phone=String(q.body.phone||q.body.identifier||"").trim();
  const pw=String(q.body.password||"");
  const name=String(q.body.pageName||"").trim();
  if(phone.length<5||pw.length<4||name.length<2)
    return s.status(400).json({error:"Nom de Page, e-mail/téléphone et mot de passe sont obligatoires."});
  try{
    const h=await bcrypt.hash(pw,10);
    const r=await pool.query(
      "INSERT INTO accounts(phone,password_hash,page_name) VALUES($1,$2,$3) RETURNING id,phone,page_name",
      [phone,h,name]
    );
    const a=r.rows[0],t=crypto.randomBytes(32).toString("hex");
    await pool.query("INSERT INTO sessions(token,account_id) VALUES($1,$2)",[t,a.id]);
    s.json({token:t,account:{id:a.id,phone:a.phone,pageName:a.page_name}});
  }catch(e){
    s.status(e.code==="23505"?409:500).json({error:e.code==="23505"?"Cet e-mail ou numéro est déjà utilisé.":"Erreur serveur"});
  }
});

app.post("/api/login",async(q,s)=>{
  try{
    const identifier=String(q.body.identifier||q.body.phone||"").trim();
    const pw=String(q.body.password||"");
    const r=await pool.query("SELECT * FROM accounts WHERE phone=$1",[identifier]);
    if(!r.rows.length || !(await bcrypt.compare(pw,r.rows[0].password_hash)))
      return s.status(401).json({error:"E-mail/téléphone ou mot de passe incorrect."});
    const a=r.rows[0],t=crypto.randomBytes(32).toString("hex");
    await pool.query("INSERT INTO sessions(token,account_id) VALUES($1,$2)",[t,a.id]);
    s.json({token:t,account:{id:a.id,phone:a.phone,pageName:a.page_name}});
  }catch(e){s.status(500).json({error:"Erreur serveur"});}
});

app.get("/api/me",auth,async(q,s)=>{
  const r=await pool.query("SELECT id,text,created_at FROM posts WHERE account_id=$1 ORDER BY id DESC",[q.account.id]);
  s.json({account:q.account,posts:r.rows});
});

app.post("/api/posts",auth,async(q,s)=>{
  const text=String(q.body.text||"").trim();
  if(!text) return s.status(400).json({error:"Écrivez une publication."});
  if(text.length>2000) return s.status(400).json({error:"Publication trop longue."});
  const r=await pool.query(
    "INSERT INTO posts(account_id,text) VALUES($1,$2) RETURNING id,text,created_at",[q.account.id,text]
  );
  s.json(r.rows[0]);
});

app.get("/api/pages/search",async(q,s)=>{
  const x=String(q.query.q||"").trim();
  if(!x) return s.json([]);
  const r=await pool.query(
    "SELECT id,page_name,created_at FROM accounts WHERE page_name ILIKE $1 ORDER BY id DESC LIMIT 30",
    ["%"+x+"%"]
  );
  s.json(r.rows);
});

app.get("/api/pages/:id",async(q,s)=>{
  const a=await pool.query("SELECT id,page_name,created_at FROM accounts WHERE id=$1",[q.params.id]);
  if(!a.rows.length) return s.status(404).json({error:"Page introuvable"});
  const p=await pool.query(
    "SELECT id,text,created_at FROM posts WHERE account_id=$1 ORDER BY id DESC",[q.params.id]
  );
  s.json({page:a.rows[0],posts:p.rows});
});

app.get("*",(q,s)=>s.sendFile(path.join(__dirname,"public","index.html")));

init().then(()=>app.listen(PORT,()=>console.log("Page Pro 4.3 running")))
  .catch(e=>{console.error(e);process.exit(1)});
