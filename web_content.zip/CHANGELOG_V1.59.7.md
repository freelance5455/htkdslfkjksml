# Carreira de Craque v1.59.7

## Correção urgente — Copa do Brasil e navegação
- Corrigido o erro que impedia abrir a tela da Copa do Brasil: o renderizador dos confrontos (`cupMatchLine`) era chamado, mas não estava definido.
- Corrigido o acesso a LIGAS → COPA DO BRASIL, com navegação direta e retorno ao menu de LIGAS.
- Adicionado atalho visível **ABRIR COPA** em Partidas, que abre diretamente a competição.
- Garantido que o clube controlado pelo jogador participe da Copa quando estiver na Série C, substituindo o último selecionado entre os oito representantes da divisão.
- Mantidos os 48 participantes, o chaveamento sem BYE, os resultados e o calendário integrado.
- Cache do PWA atualizado para forçar a instalação dos arquivos corrigidos.
- Limpeza de carreiras salva com novo marcador de versão, conforme preferência de atualização do usuário; arquivos estáticos, clubes e escudos são preservados.
