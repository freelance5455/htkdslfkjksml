import{db,auth}from"./firebase.js";
import{doc,getDoc,collection,getDocs,query,where,limit}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import{onAuthStateChanged}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import{money,esc}from"./common.js";
const qp=new URLSearchParams(location.search),id=qp.get("id"),initialVariant=Math.max(0,Number(qp.get("variant")||0)),el=document.getElementById("detail");
let product=null,variantIndex=initialVariant;
function variantsOf(p){return Array.isArray(p.variants)&&p.variants.length?p.variants:[{imageUrl:p.imageUrl||"",colorName:""}]}
function sizesOf(p){
 const raw=Array.isArray(p?.sizes)?p.sizes:(Array.isArray(p?.options)?p.options:(Array.isArray(p?.sizeOptions)?p.sizeOptions:(p?.sizes!=null?[p.sizes]:[])));
 return raw.map(x=>String(x).trim()).filter(Boolean);
}
function formatDescription(text){const lines=String(text||"").replace(/\r/g,"").split("\n"),out=[];let bullets=[];const flush=()=>{if(bullets.length){out.push(`<ul>${bullets.map(x=>`<li>${esc(x)}</li>`).join("")}</ul>`);bullets=[]}};for(const raw of lines){const line=raw.trim();if(!line){flush();continue}if(/^[-*•]\s+/.test(line)){bullets.push(line.replace(/^[-*•]\s+/,""));continue}flush();if(/:$/.test(line)||/^#{1,3}\s/.test(line)){out.push(`<p class="desc-heading">${esc(line.replace(/^#{1,3}\s/,""))}</p>`)}else out.push(`<p>${esc(line)}</p>`)}flush();return out.join("")||`<p>ShopBox Fashion Hub-এর প্রিমিয়াম ফ্যাশন প্রোডাক্ট।</p>`}
function render(){
 const vs=variantsOf(product); if(variantIndex>=vs.length)variantIndex=0; const v=vs[variantIndex]||vs[0];
 const stock=Number(v.stock??product.stock??0),image=v.imageUrl||product.imageUrl||"";
 el.className="detail-card";
 el.innerHTML=`<div class="detail-image">${image?`<img id="mainProductImage" src="${esc(image)}" alt="${esc(product.name)}">`:`ছবি নেই`}</div>
 <h1 class="detail-name">${esc(product.name)}</h1><div class="detail-price">${money(product.price)}</div>
 ${vs.length>1?`<div class="variant-picker"><h3>কালার চয়েজ করুন</h3><div class="variant-row">${vs.map((x,i)=>`<button class="variant-chip ${i===variantIndex?'active':''}" data-variant="${i}">${x.imageUrl?`<img src="${esc(x.imageUrl)}" alt="">`:''}<span>${esc(x.colorName||`কালার ${i+1}`)}</span></button>`).join("")}</div></div>`:""}
 <section class="description-box"><h3 class="description-title">প্রোডাক্টের বিবরণ</h3>${formatDescription(product.description)}</section>
 <div class="detail-table"><div class="detail-row"><b>স্টক</b><span>${stock}</span></div><div class="detail-row"><b>সাইজ</b><span class="size-row">${(sizesOf(product).length?sizesOf(product):[]).map(x=>`<label class="size-option"><input type="radio" name="size" value="${esc(x)}">${esc(x)}</label>`).join("")||"<span>প্রযোজ্য নয়</span>"}</span></div><div class="detail-row"><b>পরিমাণ</b><span><input id="qty" class="input" type="number" min="1" max="${Math.max(stock,1)}" value="1"></span></div></div>
 <button id="buy" class="btn-orange" style="width:100%;margin-top:15px" ${stock<=0?"disabled":""}>অর্ডার করুন ››</button>
 <section class="related-products"><h2>আরও প্রোডাক্ট</h2><div id="relatedList" class="product-grid"></div></section>`;
 document.querySelectorAll("[data-variant]").forEach(b=>b.onclick=()=>{variantIndex=Number(b.dataset.variant);render()});
 document.getElementById("buy").onclick=()=>onAuthStateChanged(auth,u=>{if(!u){location.href="auth.html";return}const qty=Math.max(1,Number(document.getElementById("qty").value||1));const size=document.querySelector("input[name=size]:checked")?.value||"";if(sizesOf(product).length&&!size){alert("সাইজ নির্বাচন করুন।");return}location.href=`order.html?id=${encodeURIComponent(id)}&variant=${variantIndex}&qty=${qty}&size=${encodeURIComponent(size)}`});
 loadRelated();
}
async function loadRelated(){
 const box=document.getElementById("relatedList"); if(!box)return;
 try{
  const s=await getDocs(query(collection(db,"products"),where("subcategoryId","==",product.subcategoryId),limit(12)));
  const html=[];s.docs.forEach(d=>{if(d.id===id)return;const p={id:d.id,...d.data()};const vs=variantsOf(p);vs.slice(0,3).forEach((v,i)=>{const im=v.imageUrl||p.imageUrl||"";html.push(`<article class="product-card"><a href="product.html?id=${encodeURIComponent(p.id)}&variant=${i}"><div class="product-image">${im?`<img src="${esc(im)}" alt="${esc(p.name)}" loading="lazy">`:`<span class="no-img">ছবি নেই</span>`}</div><div class="product-info"><h3>${esc(p.name)}</h3><div class="price">${money(p.price)}</div></div></a></article>`)})});
  box.innerHTML=html.join("")||'<div class="empty">আর কোনো প্রোডাক্ট নেই।</div>';
 }catch(e){box.innerHTML=""}
}
if(!id){el.innerHTML="<div class='empty'>প্রোডাক্ট আইডি নেই।</div>"}else{const s=await getDoc(doc(db,"products",id));if(!s.exists())el.innerHTML="<div class='empty'>প্রোডাক্ট পাওয়া যায়নি।</div>";else{product={id:s.id,...s.data()};render()}}
