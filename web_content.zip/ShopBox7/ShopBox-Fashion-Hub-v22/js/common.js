
import{auth,db}from"./firebase.js";
import{onAuthStateChanged}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import{collection,getDocs,query,orderBy,limit}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
export const money=n=>"৳"+Number(n||0).toLocaleString("bn-BD");
export const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
export function card(p,id){
 const stock=Number(p.stock??0);
 return `<article class="product-card">
   <a href="product.html?id=${encodeURIComponent(id)}">
    <div class="product-image">${p.imageUrl?`<img src="${esc(p.imageUrl)}" alt="${esc(p.name)}" loading="lazy">`:`<span class="no-img">ছবি নেই</span>`}</div>
    <div class="product-info"><small>${esc(p.category||"Fashion")}</small><h3>${esc(p.name||"Product")}</h3><div class="price">${money(p.price)}</div></div>
   </a>
   <div class="product-actions"><a class="icon-btn order" href="product.html?id=${encodeURIComponent(id)}" aria-label="Order">🛒</a><button class="icon-btn" data-fav="${esc(id)}">♡</button></div>
 </article>`;
}
export function toast(t){const e=document.getElementById("toast");if(!e)return;e.textContent=t;e.style.display="block";clearTimeout(window.__toast);window.__toast=setTimeout(()=>e.style.display="none",2200)}
export function requireLogin(){return new Promise(resolve=>{let done=false;const unsub=onAuthStateChanged(auth,u=>{if(!done){done=true;unsub();resolve(u)}})})}
const PRODUCTS_CACHE_KEY="shopbox_products_cache_v2";
export async function getProducts(){
 const readCache=()=>{try{const c=JSON.parse(localStorage.getItem(PRODUCTS_CACHE_KEY)||"null");return Array.isArray(c?.data)?c.data:null}catch(e){return null}};
 const cached=readCache();
 if(cached) {
   // Refresh in the background; the cached list appears immediately.
   getDocs(query(collection(db,"products"),orderBy("createdAt","desc"),limit(200))).then(s=>{const data=s.docs.map(d=>({id:d.id,...d.data()}));localStorage.setItem(PRODUCTS_CACHE_KEY,JSON.stringify({at:Date.now(),data}))}).catch(()=>{});
   return cached;
 }
 try{
  const s=await getDocs(query(collection(db,"products"),orderBy("createdAt","desc"),limit(200)));
  const data=s.docs.map(d=>({id:d.id,...d.data()}));
  try{localStorage.setItem(PRODUCTS_CACHE_KEY,JSON.stringify({at:Date.now(),data}))}catch(e){}
  return data;
 }catch(e){console.error(e);return []}
}
document.addEventListener("click",e=>{
 const btn=e.target.closest("[data-fav]"); if(!btn)return;
 const id=btn.dataset.fav;const k="shopbox_favs";let a=JSON.parse(localStorage.getItem(k)||"[]");
 if(a.includes(id)){a=a.filter(x=>x!==id);btn.textContent="♡";toast("ফেভারিট থেকে সরানো হয়েছে")}
 else{a.push(id);btn.textContent="♥";toast("ফেভারিটে যোগ হয়েছে")}
 localStorage.setItem(k,JSON.stringify(a));
});
