import{db}from"./firebase.js";import{doc,getDoc}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
const page=location.pathname.split("/").pop()||"index.html";
const active=page==="index.html"?"home":page==="products.html"?"products":page==="help.html"?"help":page==="product.html"?"products":page==="categories.html"?"products":page==="search.html"?"products":page==="orders.html"||page==="active-orders.html"?"orders":page==="profile.html"?"profile":page==="top-selling.html"?"products":"";
const menuItems=[["index.html","⌂","হোম"],["profile.html","●","প্রোফাইল"],["products.html","▦","সকল প্রোডাক্ট"],["products.html?filter=new","✦","নতুন প্রোডাক্ট"],["top-selling.html","▥","টপ সেলিং প্রোডাক্ট"],["categories.html","◈","ক্যাটাগরি"],["search.html","⌕","প্রোডাক্ট সার্চ"],["orders.html","▤","কমপ্লিট অর্ডার"],["active-orders.html","▣","অ্যাক্টিভ অর্ডার"],["help.html","?","হেল্প সেন্টার"],["faq.html","!","শপিং গাইডলাইন"],["about.html","i","About Us"],["privacy.html","◉","প্রাইভেসি পলিসি"]];
const menuHTML=menuItems.map(([href,icon,label])=>`<a href="${href}"><span class="dicon">${icon}</span>${label}</a>`).join("");
document.body.insertAdjacentHTML("afterbegin",`<header class="app-header"><button class="menu-btn" id="menuBtn" aria-label="Menu"><span class="hamburger"><i></i><i></i><i></i></span></button><a class="app-brand" href="index.html"><span class="brand-copy">ShopBox Fashion Hub</span></a><a class="profile-btn" href="profile.html" aria-label="Profile"><span class="profile-icon">👤</span></a></header><div class="drawer-backdrop" id="drawerBackdrop"></div><aside class="drawer" id="drawer"><div class="drawer-head"><span>ShopBox Fashion Hub</span><button class="drawer-close" id="drawerClose">×</button></div><nav class="drawer-menu">${menuHTML}</nav></aside>`);
document.body.insertAdjacentHTML("beforeend",`<nav class="bottom-nav"><a class="${active==="home"?"active":""}" href="index.html">⌂<small>হোম</small></a><a class="${active==="products"?"active":""}" href="products.html">▦<small>অল প্রোডাক্ট</small></a><a class="${active==="help"?"active":""}" href="help.html">?<small>সাপোর্ট সেন্টার</small></a></nav>`);
const d=document.getElementById("drawer"),b=document.getElementById("drawerBackdrop");function close(){d.classList.remove("open");b.classList.remove("open")}document.getElementById("menuBtn").onclick=()=>{d.classList.add("open");b.classList.add("open")};document.getElementById("drawerClose").onclick=close;b.onclick=close;d.querySelectorAll("a").forEach(a=>a.onclick=close);
const defaults={phone:"01994864792",email:"Shopboxfashionhub@gmail.com",address:"H-717, Road-1, Mohakhali, Dhaka, Bangladesh",whatsapp:"https://wa.me/message/RBON6FZYTQ5LN1",facebook:"https://www.facebook.com/share/19HtbnNjDQ/",tiktok:"https://tiktok.com/@shopbox_fashionhub",telegram:"",messenger:"",termsUrl:"terms.html",returnUrl:"return-refund.html",privacyUrl:"privacy.html",aboutUrl:"about.html",servicesUrl:"categories.html",productsUrl:"products.html",contactUrl:"contact.html",copyright:"Copyright © All rights reserved by ShopBox Fashion Hub 2026",aboutText:"ShopBox Fashion Hub একটি অনলাইন ফ্যাশন স্টোর। আমাদের লক্ষ্য হলো সহজে প্রোডাক্ট দেখা, অর্ডার করা এবং অর্ডারের স্ট্যাটাস জানা।",termsText:"প্রোডাক্ট অর্ডার করার আগে নাম, ফোন, ঠিকানা, সাইজ ও কালার সঠিকভাবে দিন।",returnText:"ডেলিভারি গ্রহণের আগে প্রোডাক্ট দেখে নিন। ডেলিভারি সম্পন্ন হওয়ার পর রিটার্ন/রিফান্ডের নিয়ম প্রযোজ্য হবে দোকানের নির্ধারিত নীতিমালা অনুযায়ী।",privacyText:"অর্ডার ও অ্যাকাউন্ট পরিচালনার জন্য প্রয়োজনীয় তথ্য ব্যবহার করা হয়। ব্যক্তিগত তথ্য নিরাপদ রাখার জন্য Firebase Authentication ও Firestore ব্যবহার করা হয়।",helpText:"প্রোডাক্ট নির্বাচন করে অর্ডার করুন। অর্ডারের স্ট্যাটাস দেখতে Active Order বা কমপ্লিট অর্ডারে যান। সমস্যা হলে কল, WhatsApp বা Contact Us ব্যবহার করুন।",servicesText:"প্রোডাক্ট দেখা, কালার ও সাইজ নির্বাচন, অনলাইন অর্ডার, অর্ডার স্ট্যাটাস দেখা এবং সাপোর্টের মাধ্যমে যোগাযোগের সুবিধা রয়েছে।",productsText:"ছেলেদের, মেয়েদের ও বাচ্চাদের বিভিন্ন ফ্যাশন প্রোডাক্ট ক্যাটাগরি অনুযায়ী দেখা ও অর্ডার করা যাবে।",contactText:"অর্ডার বা যেকোনো সহায়তার জন্য কল, WhatsApp, মেইল, Telegram, Messenger অথবা Contact Us পেজ ব্যবহার করুন."};
function safeUrl(u,fallback){const v=String(u||fallback||"").trim();return /^(https?:|mailto:|tel:|#|\/|[A-Za-z0-9_.-]+\.html)/i.test(v)?v:fallback}
function injectFooter(s){if(document.querySelector(".site-footer"))return;const f=`<footer class="footer premium-footer site-footer"><div class="footer-brand-row"><div class="footer-logo">SB</div><div><h2>ShopBox Fashion Hub</h2><p>Online Fashion Store</p></div></div><div class="footer-contact"><p><strong>Call:</strong> <a id="sitePhone"></a></p><p><strong>Email:</strong> <a id="siteEmail"></a></p><p><strong>Address:</strong> <span id="siteAddress"></span></p></div><div class="footer-links"><h3>Legal & Information</h3><a id="ftTerms">Terms and Conditions</a><a id="ftReturn">Return & Refund Policy</a><a id="ftPrivacy">Privacy Policy</a><a id="ftAbout">About Us</a><a id="ftServices">Our Services</a><a id="ftProducts">Products</a><a id="ftContact">Contact Us</a></div><div class="footer-social"><a id="ftWhatsApp" target="_blank" rel="noopener">WhatsApp</a><a id="ftFacebook" target="_blank" rel="noopener">Facebook</a><a id="ftTiktok" target="_blank" rel="noopener">TikTok</a></div><div class="copyright" id="siteCopyright"></div></footer>`;document.body.insertAdjacentHTML("beforeend",f)}
function normalizeWhatsApp(v){let x=String(v||"").trim();if(/^https?:\/\//i.test(x))return x;if(/^\+?\d{10,15}$/.test(x)){x=x.replace(/[^0-9]/g,"");if(x.startsWith("01")&&x.length===11)x="88"+x;return "https://wa.me/"+x}return x}
function setLink(id,url){const e=document.getElementById(id);if(!e)return;e.href=safeUrl(url,e.href||"#");if(/^tel:/i.test(e.href))e.textContent=String(url||"").replace(/^tel:/,"")}
async function applySettings(){
  let stored={};
  try{
    const snap=await getDoc(doc(db,"settings","site"));
    if(snap.exists()) stored=snap.data()||{};
  }catch(e){}
  const s={...defaults};
  Object.keys(defaults).forEach(k=>{
    const v=stored[k];
    s[k]=(typeof v==="string" ? (v.trim()!=="" ? v : defaults[k]) : (v ?? defaults[k]));
  });
  const phone=document.getElementById("sitePhone"),email=document.getElementById("siteEmail"),address=document.getElementById("siteAddress"),copyright=document.getElementById("siteCopyright");
  if(phone){phone.href=`tel:${String(s.phone).replace(/[^0-9+]/g,"")}`;phone.textContent=s.phone}
  if(email){email.href=`mailto:${s.email}`;email.textContent=s.email}
  if(address)address.textContent=s.address;
  if(copyright)copyright.textContent=s.copyright;
  [["ftTerms","terms.html"],["ftReturn","return-refund.html"],["ftPrivacy","privacy.html"],["ftAbout","about.html"],["ftServices","categories.html"],["ftProducts","products.html"],["ftContact","contact.html"]].forEach(([id,url])=>setLink(id,url));
  setLink("ftWhatsApp",normalizeWhatsApp(s.whatsapp));setLink("ftFacebook",s.facebook);setLink("ftTiktok",s.tiktok);
  const bodyMap={"privacy.html":["#privacyContent",s.privacyText],"help.html":["#helpContent",s.helpText],"about.html":["#aboutContent",s.aboutText],"terms.html":["#termsContent",s.termsText],"return-refund.html":["#returnContent",s.returnText]};
  const x=bodyMap[page];
  if(x){const el=document.querySelector(x[0]);if(el)el.innerHTML=escHtml(String(x[1]||"")).replace(/\n/g,"<br>")}
  [["#servicesContent",s.servicesText],["#productsContent",s.productsText],["#contactContent",s.contactText]].forEach(([sel,val])=>{const el=document.querySelector(sel);if(el)el.innerHTML=escHtml(String(val||"")).replace(/\n/g,"<br>")});
  const ph=document.getElementById("dynamicPhone"),phLink=document.getElementById("dynamicPhoneLink"),phText=document.getElementById("dynamicPhoneText"),wa=document.getElementById("dynamicWhatsapp"),em=document.getElementById("dynamicEmail"),emLink=document.getElementById("dynamicEmailLink"),tg=document.getElementById("dynamicTelegram"),ms=document.getElementById("dynamicMessenger"),ad=document.getElementById("dynamicAddress");
  const tel=`tel:${String(s.phone).replace(/[^0-9+]/g,"")}`;
  if(ph){ph.href=tel;if(phText)phText.textContent=s.phone}
  if(phLink)phLink.href=tel;
  if(wa)wa.href=normalizeWhatsApp(s.whatsapp);
  if(em){em.href=`mailto:${s.email}`;em.textContent=s.email}
  if(emLink)emLink.href=`mailto:${s.email}`;
  if(tg){tg.href=s.telegram||"#";tg.setAttribute("aria-disabled",!s.telegram);if(!s.telegram)tg.onclick=e=>e.preventDefault()}
  if(ms){ms.href=s.messenger||"#";ms.setAttribute("aria-disabled",!s.messenger);if(!s.messenger)ms.onclick=e=>e.preventDefault()}
  if(ad)ad.textContent=s.address;
  const homeAbout=document.getElementById("homeAbout"),homeTik=document.getElementById("homeTiktok"),homeFb=document.getElementById("homeFacebook");
  if(homeAbout)homeAbout.href="about.html";if(homeTik)homeTik.href=s.tiktok||"#";if(homeFb)homeFb.href=s.facebook||"#";
}
function escHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]))}
applySettings();
