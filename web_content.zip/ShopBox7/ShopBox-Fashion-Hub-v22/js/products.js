import {db} from "./firebase.js";
import {collection,getDocs,query,orderBy} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import {esc} from "./common.js";
const demo={
 Men:["কাতুয়া","পোলো শার্ট","টি-শার্ট","শার্ট","পাঞ্জাবি","শার্ট কম্বো","প্যান্ট ও ট্রাউজার","স্পোর্টস ও জার্সি","সেট ও অন্যান্য"],
 Women:["শাড়ি","থ্রি-পিস","কুর্তি","গাউন","সালোয়ার-কামিজ","কামিজ","লেহেঙ্গা","মেয়েদের টপস","অন্যান্য"],
 Kids:["ছেলেদের কিডস ড্রেস","মেয়েদের কিডস ড্রেস","কিডস টি-শার্ট","কিডস শার্ট","কিডস প্যান্ট","কিডস সেট","স্কুল ড্রেস","বেবি ড্রেস","অন্যান্য"]
};
const titles={Men:"ছেলেদের পোশাক",Women:"মেয়েদের পোশাক",Kids:"বাচ্চাদের পোশাক"};
const icons={Men:"👔",Women:"👗",Kids:"🧒"};
const categorySections=document.getElementById("categorySections");
async function loadSubcategories(){
 try{
  const s=await getDocs(query(collection(db,"subcategories"),orderBy("sort","asc")));
  const saved=s.docs.map(d=>({id:d.id,...d.data()}));
  const keys=new Set(saved.map(x=>x.demoKey).filter(Boolean));
  const virtual=Object.entries(demo).flatMap(([group,names])=>names.map((name,i)=>({id:`demo-${group}-${i}`,groupKey:group,name,imageUrl:"",sort:i,demo:true,demoKey:`${group}-${i}`})).filter(x=>!keys.has(x.demoKey)));
  return [...saved,...virtual];
 }catch(e){console.warn("Using demo categories",e)}
 return Object.entries(demo).flatMap(([group,names])=>names.map((name,i)=>({id:`demo-${group}-${i}`,groupKey:group,name,imageUrl:"",sort:i,demo:true,demoKey:`${group}-${i}`})));
}
async function loadProductCounts(){
 const counts=new Map();
 try{
  const snap=await getDocs(collection(db,"products"));
  snap.forEach(d=>{const p=d.data()||{};const id=String(p.subcategoryId||"");if(!id)return;const variantCount=Array.isArray(p.variants)&&p.variants.length?p.variants.length:1;counts.set(id,(counts.get(id)||0)+variantCount);});
 }catch(e){}
 return counts;
}
function section(group,items,counts){
 const arr=items.filter(x=>x.groupKey===group);
 return `<section class="category-block"><h2 class="category-main-title">${titles[group]}</h2><div class="subcategory-grid">${arr.map(x=>{const n=counts.get(x.id)||0;return `<a class="subcategory-card" href="subcategory.html?id=${encodeURIComponent(x.id)}&name=${encodeURIComponent(x.name)}&group=${group}"><div class="subcategory-image">${x.imageUrl?`<img src="${esc(x.imageUrl)}" alt="${esc(x.name)}" loading="lazy">`:`<span>${icons[group]}</span>`}</div><b>${esc(x.name)}</b><small class="category-count">${n}</small></a>`}).join("")}</div></section>`;
}
const items=await loadSubcategories();
const counts=await loadProductCounts();
categorySections.innerHTML=["Men","Women","Kids"].map(g=>section(g,items,counts)).join("");
