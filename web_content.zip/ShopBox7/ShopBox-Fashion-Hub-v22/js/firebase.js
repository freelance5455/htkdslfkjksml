// Firebase Web App config — paste your project's config here.
import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
    getAuth
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
const firebaseConfig = {
  apiKey: "AIzaSyD4zyLGdnj3xviHrzg7Z6yieqfUTQJAd0k",
  authDomain: "shopboxfashionhub-com.firebaseapp.com",
  projectId: "shopboxfashionhub-com",
  storageBucket: "shopboxfashionhub-com.firebasestorage.app",
  messagingSenderId: "791569507850",
  appId: "1:791569507850:web:8e60ac51518c341cf7e1f3",
  measurementId: "G-65TF43KP7X"
};
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);