import{db}from"./firebase.js";
import{doc,getDoc}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
let i=0;
const slides=document.getElementById("slides");
const slideEls=[...document.querySelectorAll("#slides .slide")];
const dots=[...document.querySelectorAll("#dots .dot")];
const defaults={
 marqueeText:"📢 নতুন প্রোডাক্ট যুক্ত হয়েছে • অর্ডার করতে প্রোডাক্ট সিলেক্ট করুন • ShopBox Fashion Hub-এ স্বাগতম • সারাদেশে ডেলিভারি সুবিধা",
 urgentNotice:"আপনার পছন্দের প্রোডাক্ট বেছে নিয়ে সহজেই অর্ডার করুন। প্রোফাইল থেকে আপনার অর্ডারের তথ্য ও স্ট্যাটাস দেখতে পারবেন।",
 slide1Image:"",slide2Image:"",slide3Image:""
};
function safeText(v,f){const x=String(v??"").trim();return x||f}
function applySlider(s){
 const imgs=[s.slide1Image,s.slide2Image,s.slide3Image];
 slideEls.forEach((el,k)=>{const url=String(imgs[k]||"").trim();if(url){el.style.backgroundImage=`linear-gradient(90deg,rgba(0,0,0,.42),rgba(0,0,0,.08)),url("${url.replace(/"/g,'\\"')}")`;el.style.backgroundSize="cover";el.style.backgroundPosition="center";const art=el.querySelector(".slide-art");if(art)art.style.display="none";}});
}
async function loadHomeSettings(){
 let s={...defaults};
 try{const snap=await getDoc(doc(db,"settings","site"));if(snap.exists())s={...s,...snap.data()}}catch(e){}
 const mq=document.getElementById("homeMarquee");if(mq)mq.textContent=safeText(s.marqueeText,defaults.marqueeText);
 const urgent=document.getElementById("homeUrgentNotice");if(urgent)urgent.textContent=safeText(s.urgentNotice,defaults.urgentNotice);
 applySlider(s);
}
loadHomeSettings();
if(slides){setInterval(()=>{i=(i+1)%slideEls.length;slides.style.transform=`translateX(-${i*100}%)`;dots.forEach((d,k)=>d.classList.toggle("active",k===i));},4000);}
