import{auth,db}from"./firebase.js";
import{createUserWithEmailAndPassword,signInWithEmailAndPassword,sendPasswordResetEmail}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import{doc,setDoc,serverTimestamp}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
const msg=document.getElementById("msg");const show=x=>{if(msg)msg.textContent=x?.message||x};
const login=document.getElementById("login"),reg=document.getElementById("register"),forgot=document.getElementById("forgot");
if(login)login.onsubmit=async e=>{e.preventDefault();try{await signInWithEmailAndPassword(auth,document.getElementById("email").value.trim(),document.getElementById("password").value);location.href="profile.html"}catch(x){show(x)}};
if(reg)reg.onsubmit=async e=>{e.preventDefault();try{const c=await createUserWithEmailAndPassword(auth,document.getElementById("email").value.trim(),document.getElementById("password").value);await setDoc(doc(db,"users",c.user.uid),{uid:c.user.uid,email:c.user.email,role:"customer",createdAt:serverTimestamp()});location.href="profile.html"}catch(x){show(x)}};
if(forgot)forgot.onsubmit=async e=>{e.preventDefault();try{await sendPasswordResetEmail(auth,document.getElementById("email").value.trim());show("রিসেট ইমেইল পাঠানো হয়েছে।")}catch(x){show(x)}};
