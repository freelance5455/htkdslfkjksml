import{auth,db}from"./firebase.js";import{onAuthStateChanged}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";import{doc,getDoc,collection,addDoc,setDoc,serverTimestamp,runTransaction}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";import{money,esc}from"./common.js";
const qp=new URLSearchParams(location.search),pid=qp.get("id"),variantIndex=Math.max(0,Number(qp.get("variant")||0)),initialQty=Math.max(1,Number(qp.get("qty")||1)),initialSize=qp.get("size")||"";
const summary=document.getElementById("summary"),form=document.getElementById("orderForm"),msg=document.getElementById("msg");let product=null,profileData=null;
function recalc(){if(!product)return;const qty=initialQty,base=Number(product.price||0)*qty,district=document.getElementById("district").value,delivery=district==="ঢাকা"?70:120;document.getElementById("deliveryCharge").textContent=money(delivery);document.getElementById("grandTotal").textContent=money(base+delivery);const q=document.getElementById("sumQty");if(q)q.textContent=qty}
document.getElementById("district").onchange=recalc;
function fillProfile(p){document.getElementById("customerName").value=p.name||"";document.getElementById("customerPhone").value=p.phone||"";document.getElementById("district").value=p.district||"";document.getElementById("thana").value=p.thana||"";document.getElementById("address").value=p.address||"";recalc()}
function clearProfile(){["customerName","customerPhone","district","thana","address"].forEach(id=>document.getElementById(id).value="");recalc()}
function hasProfile(p){return !!(p&&(p.name||p.phone||p.district||p.thana||p.address))}
function askProfile(p){return new Promise(resolve=>{const modal=document.getElementById("profileChoice"),yes=document.getElementById("profileYes"),no=document.getElementById("profileNo");if(!modal||!hasProfile(p)){resolve(false);return}modal.hidden=false;const finish=use=>{modal.hidden=true;yes.onclick=null;no.onclick=null;resolve(use)};yes.onclick=()=>finish(true);no.onclick=()=>finish(false);});}
onAuthStateChanged(auth,async u=>{if(!u){location.href="auth.html";return}if(!pid){summary.innerHTML="<div class='empty'>প্রোডাক্ট পাওয়া যায়নি।</div>";form.style.display="none";return}
try{
 const productPromise=getDoc(doc(db,"products",pid));const profilePromise=getDoc(doc(db,"users",u.uid));
 const s=await productPromise;if(!s.exists()){summary.innerHTML="<div class='empty'>প্রোডাক্ট পাওয়া যায়নি।</div>";form.style.display="none";return}
 product=s.data();const ps=await profilePromise;profileData=ps.exists()?ps.data():{};
 const variants=Array.isArray(product.variants)&&product.variants.length?product.variants:[{imageUrl:product.imageUrl||"",colorName:""}],selected=variants[variantIndex]||variants[0];
 summary.innerHTML=`<div class="summary-item">${selected.imageUrl?`<img src="${esc(selected.imageUrl)}" loading="eager" decoding="async">`:""}<div><b>${esc(product.name)}</b><br>দাম: ${money(product.price)}<br>কালার: ${esc(selected.colorName||"প্রযোজ্য নয়")}<br>সাইজ: ${esc(initialSize||"প্রযোজ্য নয়")}<br>পরিমাণ: <span id="sumQty">${initialQty}</span></div></div>`;
 recalc();
 const useProfile=await askProfile(profileData);if(useProfile)fillProfile(profileData);else clearProfile();
 form.onsubmit=async e=>{e.preventDefault();try{const qty=initialQty,district=document.getElementById("district").value,delivery=district==="ঢাকা"?70:120,base=Number(product.price||0)*qty;if(!district){msg.textContent="জেলা নির্বাচন করুন";return}const customerName=document.getElementById("customerName").value.trim(),phone=document.getElementById("customerPhone").value.trim(),thana=document.getElementById("thana").value.trim(),address=document.getElementById("address").value.trim();if(!customerName||!phone||!thana||!address){msg.textContent="সব প্রয়োজনীয় তথ্য পূরণ করুন।";return}
 const orderRef=doc(collection(db,"orders"));
 const trackingCode=`SBFH-${orderRef.id.slice(0,6).toUpperCase()}`;
 await runTransaction(db,async tx=>{
   const productRef=doc(db,"products",pid),snap=await tx.get(productRef);
   if(!snap.exists())throw new Error("প্রোডাক্ট পাওয়া যায়নি।");
   const latest=snap.data();
   const currentStock=Math.max(0,Number(latest.stock||0));
   if(currentStock<qty)throw new Error(`স্টকে মাত্র ${currentStock}টি আছে।`);
   const nextStock=currentStock-qty;
   const latestVariants=Array.isArray(latest.variants)?latest.variants.map(v=>({...v,stock:nextStock})):[];
   tx.set(orderRef,{userId:u.uid,userEmail:u.email,productId:pid,productName:latest.name||product.name,imageUrl:selected.imageUrl||latest.imageUrl||product.imageUrl||"",variantIndex,variantColor:selected.colorName||"",price:Number(latest.price??product.price),quantity:qty,size:initialSize||"",customerName,phone,district,thana,address,deliveryCharge:delivery,total:base+delivery,paymentMethod:"Cash on Delivery",status:"Pending",trackingCode,stockOrderId:orderRef.id,createdAt:serverTimestamp()});
   tx.update(productRef,{stock:nextStock,variants:latestVariants,lastStockOrderId:orderRef.id,updatedAt:serverTimestamp()});
 });
 location.href="active-orders.html"}catch(x){msg.textContent=x.message}}
}catch(x){msg.textContent=x.message}});