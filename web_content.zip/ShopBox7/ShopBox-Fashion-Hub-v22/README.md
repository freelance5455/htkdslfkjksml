# ShopBox Fashion Hub — Admin v6

## Firebase setup
1. Firebase Authentication → Email/Password enable করুন.
2. Firestore Database create করুন.
3. `js/firebase.js`-এ শুধু Firebase Web App config বসান.
4. `firestore.rules` publish করুন.
5. Admin account-এর Firebase UID অবশ্যই `5YbwtrmBNYU1mXQxhnfrTFSLgOM2` হতে হবে.

## Image system
এই version-এ **Firebase Storage ব্যবহার করা হয়নি**। Admin panel-এ category ও product-এর image-এর জন্য direct HTTPS image URL ব্যবহার করা হয়। তাই Storage enable করার দরকার নেই এবং `storage.rules`-ও নেই.

## Admin dashboard
- Dashboard cards: Orders, Categories, Products, Add Product, Pending, Delivered
- Orders: Pending / Delivered / All tabs এবং status update
- Categories: list, image URL edit, name edit, delete, new category
- Products: all products, search/filter, edit, add product
- Multi-color: একই product-এর জন্য যত খুশি color + image URL যোগ করা যায়; product details-এ color chooser দেখাবে.

## PHP / responsive
এই project PHP hosting-compatible: HTML/JS files PHP hosting-এ সরাসরি serve করা যাবে। UI responsive/mobile-app style. Firebase-ই authentication/database backend হিসেবে কাজ করে; PHP আলাদা backend হিসেবে প্রয়োজন নেই.


## Profile + Top Selling Update
- Customer profile stores name, phone, district, thana/upazila and full address.
- Order form auto-fills saved profile information but edits made on the order form are saved only to that order.
- Profile edits persist for future orders.
- Top Selling page displays up to 10 products by delivered quantity. Cancelled/non-delivered orders are excluded.
- Admin refresh/status updates maintain `settings/topSelling`.


### v24 updates
- Tracking code format is `SBFH-XXXXXX`.
- Admin Site Settings can change 3 home slider image URLs, scrolling notice and urgent notice.
- Home category cards show live product counts per subcategory. Deleting a product decreases the count; adding a product increases it.


## Product count behavior
One admin product document may contain multiple color/image variants. The admin panel counts that as one product, while storefront category counts each variant/color as a separate product card. For example, one product with 10 color images appears as 10 on the user category count and 10 visual product cards. Deleting the parent product removes all of those cards; editing/posting another multi-color product updates the count automatically.
