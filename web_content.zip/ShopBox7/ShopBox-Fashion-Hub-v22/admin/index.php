<?php
// PHP-hosting compatible admin entry point.
include __DIR__ . '/index.html';
?>
