import{auth,db}from"../js/firebase.js";
import{onAuthStateChanged,signOut}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import{collection,addDoc,getDocs,query,orderBy,serverTimestamp,updateDoc,doc,deleteDoc,setDoc,getDoc}from"https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import{money,esc}from"../js/common.js";
const ADMIN_UID="5YbwtrmBNYU1mXQxhnfrTFSLgOM2";const $=id=>document.getElementById(id);
const GROUPS={Men:"ছেলেদের পোশাক",Women:"মেয়েদের পোশাক",Kids:"বাচ্চাদের পোশাক"};
const DEMO={Men:["কাতুয়া","পোলো শার্ট","টি-শার্ট","শার্ট","পাঞ্জাবি","শার্ট কম্বো","প্যান্ট ও ট্রাউজার","স্পোর্টস ও জার্সি","সেট ও অন্যান্য"],Women:["শাড়ি","থ্রি-পিস","কুর্তি","গাউন","সালোয়ার-কামিজ","কামিজ","লেহেঙ্গা","মেয়েদের টপস","অন্যান্য"],Kids:["ছেলেদের কিডস ড্রেস","মেয়েদের কিডস ড্রেস","কিডস টি-শার্ট","কিডস শার্ট","কিডস প্যান্ট","কিডস সেট","স্কুল ড্রেস","বেবি ড্রেস","অন্যান্য"]};
let categories=[],products=[],orders=[],users=[],orderTab="pending",orderSearch="";
const DEFAULT_SETTINGS={phone:"01994864792",email:"Shopboxfashionhub@gmail.com",address:"H-717, Road-1, Mohakhali, Dhaka, Bangladesh",whatsapp:"https://wa.me/message/RBON6FZYTQ5LN1",facebook:"https://www.facebook.com/share/19HtbnNjDQ/",tiktok:"https://tiktok.com/@shopbox_fashionhub",telegram:"",messenger:"",copyright:"Copyright © All rights reserved by ShopBox Fashion Hub 2026",aboutText:"ShopBox Fashion Hub একটি অনলাইন ফ্যাশন স্টোর। আমাদের লক্ষ্য হলো সহজে প্রোডাক্ট দেখা, অর্ডার করা এবং অর্ডারের স্ট্যাটাস জানা।",termsText:"প্রোডাক্ট অর্ডার করার আগে নাম, ফোন, ঠিকানা, সাইজ ও কালার সঠিকভাবে দিন। অর্ডার নিশ্চিত হওয়ার পর প্রয়োজনীয় ক্ষেত্রে পরিবর্তনের জন্য সাপোর্টে যোগাযোগ করুন।",returnText:"ডেলিভারি গ্রহণের আগে প্রোডাক্ট দেখে নিন। ডেলিভারি সম্পন্ন হওয়ার পর রিটার্ন/রিফান্ডের নিয়ম প্রযোজ্য হবে দোকানের নির্ধারিত নীতিমালা অনুযায়ী।",privacyText:"অর্ডার ও অ্যাকাউন্ট পরিচালনার জন্য প্রয়োজনীয় তথ্য ব্যবহার করা হয়। ব্যক্তিগত তথ্য নিরাপদ রাখার জন্য Firebase Authentication ও Firestore ব্যবহার করা হয়।",helpText:"প্রোডাক্ট নির্বাচন করে অর্ডার করুন। অর্ডারের স্ট্যাটাস দেখতে Active Order বা কমপ্লিট অর্ডারে যান। সমস্যা হলে কল, WhatsApp বা Contact Us ব্যবহার করুন।",servicesText:"প্রোডাক্ট দেখা, কালার ও সাইজ নির্বাচন, অনলাইন অর্ডার, অর্ডার স্ট্যাটাস দেখা এবং সাপোর্টের মাধ্যমে যোগাযোগের সুবিধা রয়েছে।",productsText:"ছেলেদের, মেয়েদের ও বাচ্চাদের বিভিন্ন ফ্যাশন প্রোডাক্ট ক্যাটাগরি অনুযায়ী দেখা ও অর্ডার করা যাবে।",contactText:"অর্ডার বা যেকোনো সহায়তার জন্য কল, WhatsApp, মেইল, Telegram, Messenger অথবা Contact Us পেজ ব্যবহার করুন.",slide1Image:"",slide2Image:"",slide3Image:"",marqueeText:"📢 নতুন প্রোডাক্ট যুক্ত হয়েছে • অর্ডার করতে প্রোডাক্ট সিলেক্ট করুন • ShopBox Fashion Hub-এ স্বাগতম • সারাদেশে ডেলিভারি সুবিধা",urgentNotice:"আপনার পছন্দের প্রোডাক্ট বেছে নিয়ে সহজেই অর্ডার করুন। প্রোফাইল থেকে আপনার অর্ডারের তথ্য ও স্ট্যাটাস দেখতে পারবেন."};
function safe(v){return esc(v??"")}
function showView(view){document.querySelectorAll(".view").forEach(x=>x.style.display="none");$("view-"+view).style.display="block";document.querySelectorAll(".nav[data-view]").forEach(n=>n.classList.toggle("active",n.dataset.view===view));if(view==="orders")renderOrders();if(view==="categories")renderCategories();if(view==="products")renderProducts();if(view==="productForm")prepareProductForm();if(view==="users")renderUsers();if(window.innerWidth<901)$("side").classList.remove("open")}
function open(view){showView(view)}

document.querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>open(b.dataset.open));
$("settingsForm").onsubmit=saveSettings; $("resetSettings").onclick=()=>fillSettings(DEFAULT_SETTINGS);
document.querySelectorAll(".nav[data-view]").forEach(b=>b.onclick=()=>showView(b.dataset.view));
$("menuBtn").onclick=()=>$("side").classList.toggle("open");
$("logoutBtn").onclick=()=>signOut(auth);
$("cancelEdit").onclick=()=>{resetProductForm();showView("products")};
$("showCatForm").onclick=()=>$("catFormWrap").style.display=$("catFormWrap").style.display==="none"?"block":"none";
$("addVariant").onclick=()=>addVariantRow();$("addFirstVariant").onclick=()=>addVariantRow();
$("pgroup").onchange=()=>fillSubcategories();
$("productSearch").oninput=renderProducts;$("productFilter").onchange=renderProducts;
document.querySelectorAll("[data-order-tab]").forEach(b=>b.onclick=()=>{orderTab=b.dataset.orderTab;document.querySelectorAll("[data-order-tab]").forEach(x=>x.classList.toggle("active",x===b));renderOrders()});
$("orderSearch").oninput=e=>{orderSearch=e.target.value.trim().toLowerCase();renderOrders()};

onAuthStateChanged(auth,async user=>{
 if(!user){$("authBox").querySelector("p").textContent="Login required";$("authBox").querySelector(".auth-card").innerHTML='<div class="admin-logo">SB</div><h2>Login required</h2><p>Admin account দিয়ে Login করুন।</p><a class="primary" href="../auth.html">Login</a>';return}
 if(user.uid!==ADMIN_UID){$("authBox").querySelector(".auth-card").innerHTML=`<div class="admin-logo">!</div><h2>Access Denied</h2><p>এই account admin নয়।</p><p class="muted">UID: ${safe(user.uid)}</p>`;return}
 $("authBox").style.display="none";$("app").style.display="block";await refreshAll();
});

async function getCol(name){try{return await getDocs(query(collection(db,name),orderBy("createdAt","desc")))}catch(e){return await getDocs(collection(db,name))}}
async function refreshAll(){
  const status=$("adminStatus");
  status.textContent="● Admin verified • Loading data…";
  try {
    const results=await Promise.allSettled([getCol("subcategories"),getCol("products"),getCol("orders"),getCol("users")]);
    const [cs,ps,os,us]=results;
    categories=cs.status==="fulfilled"?cs.value.docs.map(d=>({id:d.id,...d.data()})):[];
    products=ps.status==="fulfilled"?ps.value.docs.map(d=>({id:d.id,...d.data()})):[];
    orders=os.status==="fulfilled"?os.value.docs.map(d=>({id:d.id,...d.data()})):[];
    users=us.status==="fulfilled"?us.value.docs.map(d=>({id:d.id,...d.data()})):[];
    // Always keep the demo categories visible alongside saved/custom categories.
    // A demo category is only a UI placeholder until the admin edits/saves it.
    const existingDemoKeys=new Set(categories.map(c=>c.demoKey).filter(Boolean));
    const virtualDemos=Object.entries(DEMO).flatMap(([g,arr])=>arr.map((name,i)=>({id:`demo-${g}-${i}`,groupKey:g,name,imageUrl:"",sort:i,demo:true,demoKey:`${g}-${i}`})).filter(c=>!existingDemoKeys.has(c.demoKey)));
    categories=[...categories,...virtualDemos];
    $("dashOrders").textContent=orders.length;
    $("dashCategories").textContent=categories.length;
    $("dashProducts").textContent=products.length;
    $("dashUsers").textContent=users.length;
    const pending=orders.filter(o=>{const s=String(o.status||"Pending").toLowerCase();return s!=="delivered"&&s!=="cancelled"}).length;
    const delivered=orders.filter(o=>String(o.status||"").toLowerCase()==="delivered").length;
    const cancelled=orders.filter(o=>String(o.status||"").toLowerCase()==="cancelled").length;
    $("dashPending").textContent=pending; $("dashDelivered").textContent=delivered; $("dashCancelled").textContent=cancelled;
    $("pendingCount").textContent=pending; $("deliveredCount").textContent=delivered; $("cancelledCount").textContent=cancelled; $("allCount").textContent=orders.length;
    await updateTopSelling();
    await loadSettings();
    fillSubcategories(); renderCategories(); renderProducts(); renderOrders(); renderUsers();
    const failed=[]; if(cs.status!=="fulfilled")failed.push("categories"); if(ps.status!=="fulfilled")failed.push("products"); if(os.status!=="fulfilled")failed.push("orders"); if(us.status!=="fulfilled")failed.push("users");
    status.textContent=failed.length?"● Admin verified • Firestore access issue: "+failed.join(", "):"● Admin verified • All systems ready";
  } catch(e){
    console.error("Admin dashboard error",e);
    status.textContent="● Admin verified • Dashboard error: "+(e?.message||e);
    try{ renderCategories(); renderProducts(); renderOrders(); }catch(_){}
  }
}
async function updateTopSelling(){
  try{
    const totals=new Map();
    for(const o of orders){
      if(String(o.status||"Pending").toLowerCase()!=="delivered") continue;
      const id=o.productId||`name:${o.productName||"unknown"}`;
      const qty=Math.max(0,Number(o.quantity||1));
      const old=totals.get(id)||{productId:o.productId||"",name:o.productName||"Product",price:Number(o.price||0),sold:0,imageUrl:o.imageUrl||""};
      old.sold+=qty;
      if(!old.imageUrl&&o.imageUrl)old.imageUrl=o.imageUrl;
      totals.set(id,old);
    }
    for(const x of totals.values()){
      const p=products.find(v=>v.id===x.productId);
      if(p){x.name=p.name||x.name;x.price=Number(p.price??x.price);const v=Array.isArray(p.variants)&&p.variants[x.variantIndex||0];x.imageUrl=x.imageUrl||v?.imageUrl||p.imageUrl||"";}
    }
    const items=[...totals.values()].sort((a,b)=>b.sold-a.sold).slice(0,10);
    await setDoc(doc(db,"settings","topSelling"),{items,updatedAt:serverTimestamp()},{merge:true});
  }catch(e){console.warn("Top selling update failed",e)}
}

async function loadSettings(){try{const snap=await getDoc(doc(db,"settings","site"));fillSettings(snap.exists()?{...DEFAULT_SETTINGS,...snap.data()}:DEFAULT_SETTINGS)}catch(e){fillSettings(DEFAULT_SETTINGS)}}
function fillSettings(x){Object.entries({sPhone:"phone",sEmail:"email",sAddress:"address",sWhatsapp:"whatsapp",sFacebook:"facebook",sTiktok:"tiktok",sTelegram:"telegram",sMessenger:"messenger",sCopyright:"copyright",sAboutText:"aboutText",sTermsText:"termsText",sReturnText:"returnText",sPrivacyText:"privacyText",sHelpText:"helpText",sServicesText:"servicesText",sProductsText:"productsText",sContactText:"contactText",sSlide1Image:"slide1Image",sSlide2Image:"slide2Image",sSlide3Image:"slide3Image",sMarqueeText:"marqueeText",sUrgentNotice:"urgentNotice"}).forEach(([id,key])=>{const el=$(id);if(el)el.value=x[key]??""})}
async function saveSettings(e){e.preventDefault();const map={phone:"sPhone",email:"sEmail",address:"sAddress",whatsapp:"sWhatsapp",facebook:"sFacebook",tiktok:"sTiktok",telegram:"sTelegram",messenger:"sMessenger",copyright:"sCopyright",aboutText:"sAboutText",termsText:"sTermsText",returnText:"sReturnText",privacyText:"sPrivacyText",helpText:"sHelpText",servicesText:"sServicesText",productsText:"sProductsText",contactText:"sContactText",slide1Image:"sSlide1Image",slide2Image:"sSlide2Image",slide3Image:"sSlide3Image",marqueeText:"sMarqueeText",urgentNotice:"sUrgentNotice"};const data={};Object.entries(map).forEach(([k,id])=>data[k]=$(id).value.trim());try{await setDoc(doc(db,"settings","site"),{...data,updatedAt:serverTimestamp()},{merge:true});$("settingsMsg").textContent="Site Settings সফলভাবে Save হয়েছে।"}catch(err){$("settingsMsg").textContent="Save failed: "+err.message}}

function fillSubcategories(){const group=$("pgroup").value;$("subcategory").innerHTML='<option value="">Sub-category নির্বাচন করুন</option>'+categories.filter(c=>c.groupKey===group).map(c=>`<option value="${safe(c.id)}">${safe(c.name)}</option>`).join("")}

function renderCategories(){const list=$("categoryList");list.innerHTML=["Men","Women","Kids"].map(g=>{const arr=categories.filter(c=>c.groupKey===g);return `<div><h2 class="cat-section">${GROUPS[g]}</h2>${arr.map(c=>`<div class="cat-card"><div>${c.imageUrl?`<img src="${safe(c.imageUrl)}" alt="">`:'<div style="font-size:32px">🖼️</div>'}</div><div><b>${safe(c.name)}</b><div class="cat-group">${c.demo?'Demo category':'Firestore category'}</div></div><input data-cat-name="${safe(c.id)}" value="${safe(c.name)}"><input data-cat-url="${safe(c.id)}" value="${safe(c.imageUrl||"")}" placeholder="Image URL"><button class="secondary" data-cat-save="${safe(c.id)}">Save</button><button class="secondary" data-cat-del="${safe(c.id)}">Delete</button></div>`).join("")}</div>`}).join("");
 document.querySelectorAll("[data-cat-save]").forEach(b=>b.onclick=()=>saveCategory(b.dataset.catSave));document.querySelectorAll("[data-cat-del]").forEach(b=>b.onclick=()=>deleteCategory(b.dataset.catDel));
}
async function materializeAllDemos(){
  const snap=await getDocs(collection(db,"subcategories"));
  const existing=snap.docs.map(d=>({id:d.id,...d.data()}));
  const byKey=new Map(existing.map(c=>[c.demoKey,c]));
  const jobs=[];
  Object.entries(DEMO).forEach(([g,arr])=>arr.forEach((name,i)=>{
    const key=`${g}-${i}`;
    if(!byKey.has(key)){
      jobs.push(setDoc(doc(db,"subcategories",`demo-${g}-${i}`),{groupKey:g,name,imageUrl:"",sort:i,demo:true,demoKey:key,createdAt:serverTimestamp(),updatedAt:serverTimestamp()},{merge:true}));
    }
  }));
  if(jobs.length) await Promise.all(jobs);
  return getDocs(collection(db,"subcategories"));
}
async function saveCategory(id){
  const nameEl=document.querySelector(`[data-cat-name="${id}"]`),urlEl=document.querySelector(`[data-cat-url="${id}"]`);
  const name=nameEl?.value.trim()||"",imageUrl=urlEl?.value.trim()||"";
  if(!name){alert("Category name দিন।");return}
  if(id.startsWith("demo-")){
    // Convert the demo set into real Firestore categories before editing one.
    await materializeAllDemos();
    await setDoc(doc(db,"subcategories",id),{groupKey:id.split("-")[1],name,imageUrl,sort:Number(id.split("-").pop()||0),demo:true,demoKey:id.replace(/^demo-/ ,""),updatedAt:serverTimestamp()},{merge:true});
    await refreshAll();return;
  }
  await updateDoc(doc(db,"subcategories",id),{name,imageUrl,updatedAt:serverTimestamp()});
  await refreshAll();
}
async function deleteCategory(id){
  if(!confirm("এই category delete করবেন?"))return;
  if(id.startsWith("demo-")){
    // Make all demos real first, then delete only the selected one. Others stay.
    await materializeAllDemos();
  }
  await deleteDoc(doc(db,"subcategories",id));
  await refreshAll();
}
$("catForm").onsubmit=async e=>{e.preventDefault();try{await addDoc(collection(db,"subcategories"),{groupKey:$("catGroup").value,name:$("catName").value.trim(),imageUrl:$("catImageUrl").value.trim(),sort:Number($("catSort").value||0),createdAt:serverTimestamp(),updatedAt:serverTimestamp()});e.target.reset();$("catMsg").textContent="Category added.";await refreshAll()}catch(x){$("catMsg").textContent=x.message}};

async function deleteProduct(id){
  const p=products.find(x=>x.id===id);
  if(!p) return;
  if(!confirm(`“${p.name||"এই Product"}” delete করবেন?\nএটি Firestore থেকে স্থায়ীভাবে মুছে যাবে।`)) return;
  try{
    await deleteDoc(doc(db,"products",id));
    await refreshAll();
  }catch(e){
    alert("Product delete failed: "+e.message);
  }
}

function renderProducts(){const search=$("productSearch").value.toLowerCase().trim(),filter=$("productFilter").value;const arr=products.filter(p=>(!filter||p.groupKey===filter)&&(!search||String(p.name||"").toLowerCase().includes(search)||String(p.subcategoryName||"").toLowerCase().includes(search)));$("productList").innerHTML=arr.map(p=>{const v=Array.isArray(p.variants)&&p.variants.length?p.variants[0]:{};const img=v.imageUrl||p.imageUrl||"";return `<article class="product-admin-card">${img?`<img src="${safe(img)}" alt="${safe(p.name)}">`:'<div style="height:180px;display:grid;place-items:center;background:#f0f1f4">No image</div>'}<div class="product-admin-info"><h3>${safe(p.name)}</h3><div class="muted">${safe(GROUPS[p.groupKey]||"")} • ${safe(p.subcategoryName||"")}</div><div style="margin:8px 0"><b>${money(p.price||0)}</b> • ${Array.isArray(p.variants)?p.variants.length:1} Color • <b>Stock: ${Number(p.stock||0)}</b></div><div class="product-admin-actions"><button class="primary" data-edit-product="${safe(p.id)}">Edit Product</button><button class="danger-btn" data-delete-product="${safe(p.id)}">Delete</button></div></div></article>`}).join("")||'<div class="quick-card">কোনো Product পাওয়া যায়নি।</div>';document.querySelectorAll("[data-edit-product]").forEach(b=>b.onclick=()=>editProduct(b.dataset.editProduct));document.querySelectorAll("[data-delete-product]").forEach(b=>b.onclick=()=>deleteProduct(b.dataset.deleteProduct))}
function resetProductForm(){$("productForm").reset();$("editProductId").value="";$("productFormTitle").textContent="Add Product";$("variantRows").innerHTML="";fillSubcategories()}
function prepareProductForm(){if(!$("editProductId").value)fillSubcategories()}
function addVariantRow(data={}){const row=document.createElement("div");row.className="variant-row";row.innerHTML=`<img class="variant-preview" src="${safe(data.imageUrl||"")}" onerror="this.style.opacity=.25" alt=""><input class="vcolor" placeholder="Color name" value="${safe(data.colorName||"")}" required><input class="vurl" placeholder="Image URL https://..." value="${safe(data.imageUrl||"")}" required><button type="button" class="remove">×</button>`;row.querySelector(".vurl").oninput=e=>row.querySelector("img").src=e.target.value;row.querySelector(".remove").onclick=()=>row.remove();$("variantRows").appendChild(row)}
async function editProduct(id){const p=products.find(x=>x.id===id);if(!p)return;open("productForm");$("editProductId").value=id;$("productFormTitle").textContent="Edit Product";$("pname").value=p.name||"";$("price").value=p.price||0;$("pgroup").value=p.groupKey||p.category||"Men";fillSubcategories();$("subcategory").value=p.subcategoryId||"";$("stock").value=p.stock||0;$("sizeText").value=Array.isArray(p.sizes)?p.sizes.join(","):"";$("description").value=p.description||"";$("isNew").checked=!!p.isNew;$("isTop").checked=!!p.isTop;$("variantRows").innerHTML="";(Array.isArray(p.variants)&&p.variants.length?p.variants:[{colorName:"",imageUrl:p.imageUrl||""}]).forEach(addVariantRow)}
$("productForm").onsubmit=async e=>{e.preventDefault();$("productMsg").textContent="Saving…";try{const cat=categories.find(c=>c.id===$("subcategory").value);if(!cat)throw new Error("Sub-category নির্বাচন করুন");const variants=[...document.querySelectorAll("#variantRows .variant-row")].map((r,i)=>({colorName:r.querySelector(".vcolor").value.trim()||`Color ${i+1}`,imageUrl:r.querySelector(".vurl").value.trim(),stock:Number($("stock").value||0),sort:i})).filter(v=>v.imageUrl);if(!variants.length)throw new Error("কমপক্ষে ১টি image URL দিন");const data={name:$("pname").value.trim(),price:Number($("price").value),stock:Number($("stock").value||0),groupKey:cat.groupKey,category:cat.groupKey,subcategoryId:cat.id,subcategoryName:cat.name,sizes:$("sizeText").value.split(",").map(x=>x.trim()).filter(Boolean),description:$("description").value.trim(),variants,imageUrl:variants[0].imageUrl,isNew:$("isNew").checked,isTop:$("isTop").checked,updatedAt:serverTimestamp()};const id=$("editProductId").value;if(id)await updateDoc(doc(db,"products",id),data);else await addDoc(collection(db,"products"),{...data,createdAt:serverTimestamp()});$("productMsg").textContent=id?"Product updated successfully.":"Product added successfully.";await refreshAll();setTimeout(()=>{resetProductForm();open("products")},300)}catch(x){console.error(x);$("productMsg").textContent=x.message}};

function renderUsers(){
 const list=$("userList");
 if(!list)return;
 const q=String($("userSearch")?.value||"").trim().toLowerCase();
 const arr=users.filter(u=>!q||[u.name,u.email,u.phone,u.district,u.thana,u.address,u.uid].some(v=>String(v||"").toLowerCase().includes(q)));
 list.innerHTML=arr.map(u=>`<article class="user-card"><div class="user-avatar">${safe((u.name||u.email||"U").charAt(0).toUpperCase())}</div><div class="user-card-body"><div class="user-card-head"><h3>${safe(u.name||"নাম দেওয়া হয়নি")}</h3><span>Customer</span></div><div class="user-details"><p><b>ইমেইল:</b> ${safe(u.email||"—")}</p><p><b>মোবাইল:</b> ${safe(u.phone||"—")}</p><p><b>ঠিকানা:</b> ${safe(u.district||"")}${u.thana?`, ${safe(u.thana)}`:""}${u.address?`, ${safe(u.address)}`:""}</p><p class="muted"><b>User ID:</b> ${safe(u.uid||u.id)}</p></div></div></article>`).join("")||'<div class="quick-card">কোনো ব্যবহারকারী পাওয়া যায়নি।</div>';
}
$("userSearch")?.addEventListener("input",renderUsers);

function renderOrders(){
 const list=$("orderList");
 let arr=orders;
 if(orderTab==="pending")arr=orders.filter(o=>{const s=String(o.status||"Pending").toLowerCase();return s!=="delivered"&&s!=="cancelled"});
 if(orderTab==="delivered")arr=orders.filter(o=>String(o.status||"").toLowerCase()==="delivered");
 if(orderTab==="cancelled")arr=orders.filter(o=>String(o.status||"").toLowerCase()==="cancelled");
 if(orderSearch)arr=arr.filter(o=>[o.trackingCode,o.customerName,o.phone,o.productName,o.userEmail,o.id].some(v=>String(v||"").toLowerCase().includes(orderSearch)));
 list.innerHTML=arr.map(o=>{
   const s=o.status||"Pending";
   const img=o.imageUrl||((Array.isArray(products.find(p=>p.id===o.productId)?.variants)&&products.find(p=>p.id===o.productId)?.variants[o.variantIndex||0]?.imageUrl)||products.find(p=>p.id===o.productId)?.imageUrl||"");
   return `<article class="order-card admin-order-card"><div class="admin-order-image">${img?`<img src="${safe(img)}" alt="${safe(o.productName||'Product')}" onerror="this.style.display='none'">`:'<div class="no-order-image">No Image</div>'}</div><div class="admin-order-body"><div class="order-top"><div><b class="admin-order-title">${safe(o.productName||"Order")}</b><div class="order-meta"><strong>Tracking:</strong> <span class="tracking-code">${safe(o.trackingCode||"—")}</span><br><strong>Customer:</strong> ${safe(o.customerName||"")}<br><strong>Phone:</strong> ${safe(o.phone||"")}<br><strong>Address:</strong> ${safe(o.district||"")}, ${safe(o.thana||"")}, ${safe(o.address||"")}<br><strong>Color:</strong> ${safe(o.variantColor||"—")} &nbsp; <strong>Size:</strong> ${safe(o.size||"—")} &nbsp; <strong>Qty:</strong> ${safe(o.quantity||1)}<br><strong>Payment:</strong> ${safe(o.paymentMethod||"Cash on Delivery")}</div></div><div class="admin-order-total"><span class="order-status ${String(s).toLowerCase()==="delivered"?'delivered':''}">${safe(s)}</span><strong>${money(o.total||0)}</strong></div></div><div class="admin-order-action"><label>Order Status</label><select class="status-select" data-status-order="${safe(o.id)}">${["Pending","Confirmed","Processing","Shipped","Delivered","Cancelled"].map(x=>`<option ${x===s?'selected':''}>${x}</option>`).join("")}</select><button class="download-order-btn" data-download-order="${safe(o.id)}">⬇ Download Order</button></div></div></article>`
 }).join("")||'<div class="quick-card">এই section-এ কোনো order নেই।</div>';
 document.querySelectorAll("[data-status-order]").forEach(s=>s.onchange=()=>changeOrderStatus(s.dataset.statusOrder,s.value));
 document.querySelectorAll("[data-download-order]").forEach(b=>b.onclick=()=>downloadOrderImage(b.dataset.downloadOrder));
}
async function changeOrderStatus(id,status){try{await updateDoc(doc(db,"orders",id),{status,updatedAt:serverTimestamp()});await refreshAll();renderOrders()}catch(e){alert("Order update failed: "+e.message)}}


async function downloadOrderImage(orderId){
  const o=orders.find(x=>x.id===orderId); if(!o) return;
  const p=products.find(x=>x.id===o.productId);
  const variant=(Array.isArray(p?.variants)&&p.variants[o.variantIndex||0])||{};
  const img=o.imageUrl||variant.imageUrl||p?.imageUrl||"";
  const total=Number(o.total ?? ((Number(o.price)||0)*(Number(o.quantity)||1)));
  const safeText=v=>String(v??"—").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
  const box=document.createElement("div");
  box.style.cssText="position:fixed;left:-10000px;top:0;width:760px;padding:38px;background:#fff;color:#171717;font-family:Arial,sans-serif;border-radius:24px;box-sizing:border-box;z-index:-1";
  box.innerHTML=`<div style="text-align:center;border-bottom:2px solid #eee;padding-bottom:18px"><div style="font-size:30px;font-weight:800">ShopBox Fashion Hub</div><div style="font-size:14px;color:#777;margin-top:6px">Order Details</div></div>
  <div style="display:flex;gap:24px;margin-top:24px;align-items:flex-start"><div style="width:230px;height:230px;border-radius:18px;overflow:hidden;background:#f2f2f2;flex:none;display:grid;place-items:center"><img id="receiptProductImage" src="${safeText(img)}" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span style="display:none;color:#999">Product image</span></div><div style="flex:1"><h2 style="margin:0 0 14px;font-size:24px">${safeText(o.productName||p?.name||"Product")}</h2><div style="font-size:16px;line-height:1.9"><b>Price:</b> ${money(o.price||0)}<br><b>Quantity:</b> ${safeText(o.quantity||1)}<br><b>Color:</b> ${safeText(o.variantColor||variant.colorName||"—")}<br><b>Size:</b> ${safeText(o.size||"—")}<br><b>Status:</b> ${safeText(o.status||"Pending")}</div></div></div>
  <div style="margin-top:24px;padding:20px;background:#f7f7f7;border-radius:18px"><h3 style="margin:0 0 10px">Customer Details</h3><div style="line-height:1.8"><b>Name:</b> ${safeText(o.customerName)}<br><b>Phone:</b> ${safeText(o.phone)}<br><b>Address:</b> ${safeText(o.district)}, ${safeText(o.thana)}, ${safeText(o.address)}</div></div>
  <div style="display:flex;justify-content:space-between;align-items:center;margin-top:22px;padding-top:18px;border-top:2px solid #eee"><span style="font-size:14px;color:#777">Tracking: ${safeText(o.trackingCode||"—")}<br>Order ID: ${safeText(orderId)}</span><strong style="font-size:26px">Total: ${money(total)}</strong></div>`;
  document.body.appendChild(box);
  try{
    if(!window.html2canvas) throw new Error("Image renderer not loaded");
    await new Promise(r=>setTimeout(r,120));
    const canvas=await window.html2canvas(box,{backgroundColor:"#fff",scale:2,useCORS:true,allowTaint:false});
    const a=document.createElement("a");a.download=`ShopBox-Order-${orderId}.png`;a.href=canvas.toDataURL("image/png");a.click();
  }catch(e){
    alert("Order image তৈরি করা যায়নি। আবার চেষ্টা করুন।");console.error(e);
  }finally{box.remove();}
}
