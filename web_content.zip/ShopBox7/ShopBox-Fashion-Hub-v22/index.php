<?php
// PHP-hosting compatible entry point. Firebase handles auth/database.
include __DIR__ . '/index.html';
?>
