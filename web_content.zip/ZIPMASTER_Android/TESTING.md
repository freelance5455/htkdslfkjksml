# Lista de pruebas manuales antes de publicar

Esta versión aún no se ha compilado ni ejecutado en un dispositivo dentro de este entorno. Antes de distribuirla, verifica:

- [ ] Android Studio sincroniza Gradle con JDK 17 y SDK 35.
- [ ] Crear ZIP con un archivo pequeño y con varios archivos.
- [ ] Crear ZIP con nombres repetidos y archivos sin extensión.
- [ ] Comprimir una carpeta con subcarpetas y nombres con acentos.
- [ ] Extraer un ZIP normal y comprobar que crea las carpetas correctamente.
- [ ] Probar un ZIP inválido y un ZIP con entradas `../` (debe rechazarse).
- [ ] Convertir un MP4 de prueba a MP3, WAV y MP4.
- [ ] Probar un PVR real y revisar el mensaje si FFmpeg no reconoce el contenedor/códec.
- [ ] Probar con poco espacio libre y comprobar que se muestra un error entendible.
- [ ] Probar en Android 8 o superior, especialmente el selector de carpetas.

No publiques la app hasta completar estas pruebas.
