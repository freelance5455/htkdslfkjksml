# Conversión PVR en ZIPMASTER

La app intenta convertir archivos con extensión `.pvr` a MP4 usando tres perfiles FFmpeg:
1. H.264 + AAC (compatible con la mayoría de reproductores).
2. MPEG-4 Part 2 + AAC como alternativa.
3. Copia de los flujos sin recodificar, si el códec es aceptado por el contenedor MP4.

También intenta extraer la primera pista de audio a MP3 o WAV. El archivo de entrada se copia en bloques a la caché porque FFmpegKit requiere una ruta local en esta implementación.

**Límites reales:** `.pvr` no es un formato universal de vídeo. Si FFmpeg no reconoce el contenedor, el códec, la pista está cifrada o se trata de una textura PVR/PVRTC, el convertidor no puede inventar una decodificación. Para soporte específico de un formato propietario se necesita una muestra no sensible o su especificación. La compatibilidad real aún requiere compilar y probar en Android con archivos representativos.
