# Cambios

## v1.3
- Compresión de varios archivos y carpetas recursivas.
- Extracción de ZIP con validación de rutas, nombres duplicados y límite de expansión de seguridad.
- Análisis de archivo por extensión, MIME y tamaño.
- Conversión multimedia: audio a MP3/WAV y reencodificación a MP4 cuando FFmpegKit soporta el origen y los códecs.
- Procesamiento de entrada/salida por bloques para reducir el uso de RAM.

## Límites conocidos
- No se ha verificado una compilación en este entorno.
- PVR es ambiguo: solo se podrá convertir si FFmpegKit reconoce el contenedor y los códecs del archivo concreto.
- Los archivos fuente se copian temporalmente a la caché para conversión; se necesita espacio libre adicional.
- FFmpegKit es una dependencia de terceros; si Gradle no encuentra el artefacto, habrá que cambiar la distribución de FFmpeg por una mantenida.

- Añadido icono vectorial sencillo para el launcher.
