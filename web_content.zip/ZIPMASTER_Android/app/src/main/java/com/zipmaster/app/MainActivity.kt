package com.zipmaster.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import android.app.AlertDialog
import androidx.core.view.setPadding
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var createButton: Button
    private lateinit var extractButton: Button
    private lateinit var convertButton: Button
    private var pickedForZip: List<Uri> = emptyList()
    private var pickedFolderUri: Uri? = null
    private var pickedForExtract: Uri? = null
    private var pickedForConvert: Uri? = null
    private var outputZipUri: Uri? = null
    private var extractFolderUri: Uri? = null

    private val pickZipFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) {
            setStatus("No seleccionaste archivos.")
        } else {
            pickedForZip = uris
            val names = uris.take(3).joinToString { displayName(it) } + if (uris.size > 3) " y ${uris.size - 3} más" else ""
            setStatus("${uris.size} archivo(s) seleccionado(s): $names")
            createZipDestination.launch("ZIPMASTER_archivos.zip")
        }
    }

    private val createZipDestination = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null && pickedForZip.isNotEmpty()) {
            outputZipUri = uri
            runZipCreation(pickedForZip, uri)
        } else setStatus("Creación de ZIP cancelada.")
    }

    private val pickFolderToZip = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { tree ->
        if (tree != null) {
            pickedFolderUri = tree
            folderZipDestination.launch("ZIPMASTER_carpeta.zip")
        } else setStatus("Selección de carpeta cancelada.")
    }

    private val folderZipDestination = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { destination ->
        if (destination != null && pickedFolderUri != null) {
            runFolderZip(pickedFolderUri!!, destination)
        } else setStatus("Creación de ZIP cancelada.")
    }

    private val pickZipToExtract = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedForExtract = uri
            extractFolderPicker.launch(null)
        } else setStatus("No seleccionaste un ZIP.")
    }

    private val extractFolderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null && pickedForExtract != null) {
            extractFolderUri = uri
            runExtraction(pickedForExtract!!, uri)
        } else setStatus("Extracción cancelada.")
    }

    private var chosenConversion: String = "mp3"

    private val pickVideoToConvert = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedForConvert = uri
            val options = arrayOf("Extraer audio MP3", "Convertir/recomprimir a MP4", "Extraer audio WAV")
            AlertDialog.Builder(this)
                .setTitle("Elige el formato de salida")
                .setItems(options) { _, which ->
                    chosenConversion = when (which) { 1 -> "mp4"; 2 -> "wav"; else -> "mp3" }
                    val ext = chosenConversion
                    outputMediaDestination.launch(displayName(uri).substringBeforeLast('.', "archivo") + "." + ext)
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } else setStatus("No seleccionaste un vídeo.")
    }

    private val outputMediaDestination = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        if (uri != null && pickedForConvert != null) {
            runMediaConversion(pickedForConvert!!, uri, chosenConversion)
        } else setStatus("Conversión cancelada.")
    }

    private val pickPvrFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analyzePvr(uri) else setStatus("Selección PVR cancelada.")
    }

    private val pickInspectFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) inspectFile(uri) else setStatus("Análisis cancelado.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24)
            setBackgroundColor(0xFF17152B.toInt())
        }
        val title = TextView(this).apply {
            text = "ZIPMASTER"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Comprime · Extrae · Convierte"
            textSize = 15f
            setTextColor(0xFFCBC9E8.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 26 })

        createButton = makeButton("📦  Crear archivo ZIP", "Selecciona varios archivos y guárdalos en un ZIP.") {
            pickZipFiles.launch(arrayOf("*/*"))
        }
        extractButton = makeButton("🗂️  Extraer archivo ZIP", "Elige un ZIP y una carpeta de destino.") {
            pickZipToExtract.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
        }
        convertButton = makeButton("🎬  Convertir vídeo / PVR", "Extrae audio MP3/WAV o convierte un vídeo compatible a MP4.") {
            pickVideoToConvert.launch(arrayOf("video/*", "application/octet-stream"))
        }
        root.addView(createButton)
        root.addView(extractButton)
        root.addView(convertButton)

        val folderButton = makeButton("📁  Comprimir una carpeta", "Incluye los archivos de una carpeta y sus subcarpetas en un ZIP.") {
            pickFolderToZip.launch(null)
        }
        val inspectButton = makeButton("🔎  Analizar archivo", "Muestra nombre, tamaño y tipo aproximado de un archivo sin modificarlo.") {
            pickInspectFile.launch(arrayOf("*/*"))
        }
        val pvrButton = makeButton("🎞️  Analizar / convertir PVR", "Inspecciona cabecera y metadatos PVR. Si FFmpeg reconoce el archivo, permite extraer audio o convertirlo a MP4.") {
            pickPvrFile.launch(arrayOf("*/*"))
        }
        val largeButton = makeButton("💾  Ayuda para archivos grandes", "Consejos para trabajar con archivos de gran tamaño.") {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Archivos grandes")
                .setMessage("ZIPMASTER lee y escribe en bloques de 256 KiB para reducir el uso de RAM. Para archivos enormes, usa almacenamiento con espacio suficiente, evita cerrar la app y recuerda que la conversión multimedia necesita espacio temporal adicional. La división en partes se añadirá en una actualización posterior.")
                .setPositiveButton("Entendido", null)
                .show()
        }
        root.addView(folderButton)
        root.addView(inspectButton)
        root.addView(pvrButton)
        root.addView(largeButton)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, 12).apply { topMargin = 22; bottomMargin = 12 })

        status = TextView(this).apply {
            text = "Listo. Tus archivos se procesan en el dispositivo."
            textSize = 14f
            setTextColor(0xFFE4E2F7.toInt())
            gravity = Gravity.CENTER
            setPadding(12)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val note = TextView(this).apply {
            text = "Los archivos grandes se leen por bloques para reducir el uso de memoria. La conversión depende de que el códec sea compatible. No cierres la app durante una operación."
            textSize = 12f
            setTextColor(0xFFAAA7C8.toInt())
            setPadding(8)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun makeButton(label: String, description: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF6C63FF.toInt())
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(label)
                    .setMessage(description)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Continuar") { _, _ -> action() }
                    .show()
            }
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 }
            layoutParams = params
        }
    }

    private fun setStatus(message: String, showProgress: Boolean = false) {
        runOnUiThread {
            status.text = message
            progress.visibility = if (showProgress) View.VISIBLE else View.GONE
            if (!showProgress) progress.progress = 0
            setBusy(showProgress)
        }
    }

    private fun setBusy(busy: Boolean) {
        createButton.isEnabled = !busy
        extractButton.isEnabled = !busy
        convertButton.isEnabled = !busy
    }

    private fun runZipCreation(uris: List<Uri>, destination: Uri) {
        setStatus("Creando ZIP…", true)
        thread {
            try {
                contentResolver.openOutputStream(destination, "wt")?.use { raw ->
                    ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                        val buffer = ByteArray(1024 * 256)
                        uris.forEachIndexed { index, uri ->
                            val name = safeEntryName(displayName(uri))
                            zip.putNextEntry(ZipEntry(uniqueEntryName(name, index)))
                            contentResolver.openInputStream(uri)?.use { input ->
                                BufferedInputStream(input).use { stream ->
                                    while (true) {
                                        val n = stream.read(buffer)
                                        if (n < 0) break
                                        zip.write(buffer, 0, n)
                                    }
                                }
                            } ?: throw IOException("No se pudo leer ${displayName(uri)}")
                            zip.closeEntry()
                            updateProgress(((index + 1) * 100) / uris.size)
                        }
                    }
                } ?: throw IOException("No se pudo crear el archivo de salida.")
                setStatus("¡ZIP creado correctamente! Ya puedes abrirlo o compartirlo.")
            } catch (e: Exception) {
                setStatus("Error al crear ZIP: ${e.message ?: "error desconocido"}")
            }
        }
    }

    private fun runFolderZip(treeUri: Uri, destination: Uri) {
        setStatus("Comprimiendo carpeta…", true)
        thread {
            try {
                val root = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, treeUri)
                    ?: throw IOException("No se pudo abrir la carpeta.")
                val baseName = root.name?.trim('/').takeUnless { it.isNullOrBlank() } ?: "carpeta"
                val buffer = ByteArray(1024 * 256)
                var count = 0
                contentResolver.openOutputStream(destination, "wt")?.use { raw ->
                    ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                        var visitedNodes = 0
                        fun addDirectory(doc: androidx.documentfile.provider.DocumentFile, prefix: String, depth: Int = 0) {
                            if (depth > 128) throw IOException("La carpeta tiene demasiados niveles de subcarpetas.")
                            for (child in doc.listFiles()) {
                                visitedNodes++
                                if (visitedNodes > 1_000_000) throw IOException("La carpeta contiene demasiados elementos.")
                                val name = child.name?.replace('\\', '/')?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: continue
                                val path = "$prefix$name"
                                if (child.isDirectory) {
                                    zip.putNextEntry(ZipEntry("$path/"))
                                    zip.closeEntry()
                                    addDirectory(child, "$path/", depth + 1)
                                } else {
                                    zip.putNextEntry(ZipEntry(path))
                                    contentResolver.openInputStream(child.uri)?.use { input ->
                                        BufferedInputStream(input).use { stream ->
                                            while (true) {
                                                val n = stream.read(buffer)
                                                if (n < 0) break
                                                zip.write(buffer, 0, n)
                                            }
                                        }
                                    } ?: throw IOException("No se pudo leer $name")
                                    zip.closeEntry()
                                    count++
                                    updateProgress(count % 100)
                                }
                            }
                        }
                        addDirectory(root, "$baseName/")
                    }
                } ?: throw IOException("No se pudo crear el ZIP.")
                setStatus("¡Carpeta comprimida! Se incluyeron $count archivo(s).")
            } catch (e: Exception) {
                setStatus("Error al comprimir carpeta: ${e.message ?: "error desconocido"}")
            }
        }
    }

    private fun runExtraction(source: Uri, tree: Uri) {
        setStatus("Extrayendo archivos…", true)
        thread {
            try {
                val rootDoc = androidx.documentfile.provider.DocumentFile.fromTreeUri(this, tree)
                    ?: throw IOException("No se pudo abrir la carpeta.")
                val usedNames = mutableSetOf<String>()
                contentResolver.openInputStream(source)?.use { raw ->
                    ZipInputStream(BufferedInputStream(raw)).use { zip ->
                        val buffer = ByteArray(1024 * 256)
                        var entry: ZipEntry? = zip.nextEntry
                        var count = 0
                        var totalBytes = 0L
                        while (entry != null) {
                            val current = entry!!
                            val normalized = (current.name ?: "").replace('\\', '/')
                            if (normalized.startsWith("/") || Regex("^[A-Za-z]:").containsMatchIn(normalized) ||
                                normalized.split('/').any { it == ".." }) {
                                throw IOException("El ZIP contiene una ruta no segura.")
                            }
                            val parts = normalized.split('/').filter { it.isNotBlank() && it != "." }
                            if (parts.isNotEmpty()) {
                                var parent = rootDoc
                                for (part in parts.dropLast(1)) {
                                    var child = parent.findFile(part)
                                    if (child == null) child = parent.createDirectory(part)
                                    parent = child ?: throw IOException("No se pudo crear la carpeta $part")
                                }
                                if (current.isDirectory) {
                                    if (parent.findFile(parts.last()) == null) parent.createDirectory(parts.last())
                                } else {
                                    var fileName = parts.last()
                                    var suffix = 1
                                    while (parent.findFile(fileName) != null) {
                                        val dot = parts.last().lastIndexOf('.')
                                        fileName = if (dot > 0) parts.last().substring(0, dot) + "_$suffix" + parts.last().substring(dot)
                                                   else parts.last() + "_$suffix"
                                        suffix++
                                    }
                                    val outDoc = parent.createFile("application/octet-stream", fileName)
                                        ?: throw IOException("No se pudo crear $fileName")
                                    contentResolver.openOutputStream(outDoc.uri, "wt")?.use { out ->
                                        while (true) {
                                            val n = zip.read(buffer)
                                            if (n < 0) break
                                            totalBytes += n
                                            // Guard against ZIP bombs / unexpectedly huge expansion.
                                            if (totalBytes > 50L * 1024 * 1024 * 1024) throw IOException("El ZIP supera el límite de seguridad de 50 GB.")
                                            out.write(buffer, 0, n)
                                        }
                                    } ?: throw IOException("No se pudo escribir $fileName")
                                }
                            }
                            zip.closeEntry()
                            count++
                            updateProgress((count % 100))
                            entry = zip.nextEntry
                        }
                        if (count == 0) throw IOException("El ZIP está vacío o no es válido.")
                    }
                } ?: throw IOException("No se pudo leer el ZIP.")
                setStatus("¡Extracción terminada! Revisa la carpeta elegida.")
            } catch (e: Exception) {
                setStatus("Error al extraer: ${e.message ?: "archivo ZIP inválido"}")
            }
        }
    }

    private fun runMediaConversion(source: Uri, destination: Uri, format: String) {
        setStatus("Preparando conversión…", true)
        thread {
            var tempInput: java.io.File? = null
            var tempOutput: java.io.File? = null
            try {
                tempInput = java.io.File(cacheDir, "zipmaster_input_${System.currentTimeMillis()}.media")
                tempOutput = java.io.File(cacheDir, "zipmaster_output_${System.currentTimeMillis()}.$format")
                val sourceSize = querySize(source)
                val available = cacheDir.usableSpace
                // FFmpegKit trabaja con una ruta local; copiamos en bloques para no cargar el archivo entero en RAM.
                if (sourceSize > 0 && sourceSize > available - 32L * 1024 * 1024) {
                    throw IOException("No hay suficiente espacio temporal. Libera espacio e inténtalo de nuevo.")
                }
                contentResolver.openInputStream(source)?.use { input ->
                    tempInput.outputStream().buffered().use { output ->
                        val buffer = ByteArray(256 * 1024)
                        var total = 0L
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            total += n
                            if (total > cacheDir.usableSpace - 8L * 1024 * 1024) {
                                throw IOException("Se agotó el espacio temporal durante la copia.")
                            }
                            output.write(buffer, 0, n)
                        }
                    }
                } ?: throw IOException("No se pudo leer el archivo de origen.")

                val inputPath = tempInput.absolutePath
                val outputPath = tempOutput.absolutePath
                // Cada intento usa un perfil distinto: primero conversión estándar y luego alternativas.
                // FFmpeg solo puede convertir formatos que consiga demultiplexar/decodificar.
                val attempts: List<String> = when (format.lowercase(Locale.ROOT)) {
                    "mp4" -> listOf(
                        "-y -hide_banner -i \"$inputPath\" -map 0:v:0? -map 0:a:0? -sn -dn -c:v libx264 -preset veryfast -crf 23 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart -f mp4 \"$outputPath\"",
                        "-y -hide_banner -i \"$inputPath\" -map 0:v:0? -map 0:a:0? -sn -dn -c:v mpeg4 -q:v 4 -c:a aac -b:a 128k -movflags +faststart -f mp4 \"$outputPath\"",
                        "-y -hide_banner -i \"$inputPath\" -map 0:v:0? -map 0:a:0? -sn -dn -c copy -movflags +faststart -f mp4 \"$outputPath\""
                    )
                    "wav" -> listOf(
                        "-y -hide_banner -i \"$inputPath\" -map 0:a:0 -vn -c:a pcm_s16le -f wav \"$outputPath\""
                    )
                    else -> listOf(
                        "-y -hide_banner -i \"$inputPath\" -map 0:a:0 -vn -c:a libmp3lame -q:a 3 -f mp3 \"$outputPath\"",
                        "-y -hide_banner -i \"$inputPath\" -map 0:a:0 -vn -c:a aac -b:a 192k -f mp3 \"$outputPath\""
                    )
                }

                var lastFailure = "FFmpeg no pudo reconocer el contenedor o los códecs."
                var succeeded = false
                for ((index, args) in attempts.withIndex()) {
                    runOnUiThread { setStatus("Probando conversión ${index + 1}/${attempts.size}…", true) }
                    tempOutput.delete()
                    val session = FFmpegKit.execute(args)
                    if (ReturnCode.isSuccess(session.returnCode) && tempOutput.exists() && tempOutput.length() > 0L) {
                        succeeded = true
                        break
                    }
                    val logText = try { session.allLogsAsString ?: "" } catch (_: Exception) { "" }
                    lastFailure = logText.lineSequence()
                        .map { it.trim() }
                        .filter { it.contains("error", true) || it.contains("unknown", true) || it.contains("invalid", true) || it.contains("not found", true) }
                        .takeLast(3)
                        .joinToString(" ")
                        .take(420)
                        .ifBlank { "El perfil ${index + 1} no funcionó con este archivo." }
                }
                if (!succeeded) {
                    throw IOException("$lastFailure. Puede que este PVR sea propietario, esté cifrado o no contenga una pista compatible.")
                }

                contentResolver.openOutputStream(destination, "wt")?.use { out ->
                    tempOutput.inputStream().buffered().use { input -> input.copyTo(out, 256 * 1024) }
                } ?: throw IOException("No se pudo guardar el archivo convertido.")
                setStatus("¡Conversión terminada! Archivo .$format guardado.")
            } catch (e: Exception) {
                setStatus("No se pudo convertir: ${e.message ?: "formato no compatible"}")
            } finally {
                tempInput?.delete()
                tempOutput?.delete()
            }
        }
    }

    private fun analyzePvr(uri: Uri) {
        setStatus("Analizando archivo PVR…", true)
        thread {
            try {
                val name = displayName(uri)
                val size = querySize(uri)
                val prefix = ByteArray(64)
                var read = 0
                contentResolver.openInputStream(uri)?.use { input ->
                    while (read < prefix.size) {
                        val n = input.read(prefix, read, prefix.size - read)
                        if (n < 0) break
                        read += n
                    }
                } ?: throw IOException("No se pudo leer el archivo.")
                val hex = prefix.take(read).joinToString(" ") { "%02X".format(it) }
                val ascii = prefix.take(read).map { b ->
                    val v = b.toInt() and 0xff
                    if (v in 32..126) v.toChar() else '.'
                }.joinToString("")
                val looksLikeMp4 = read >= 8 && String(prefix, 4, 4, Charsets.US_ASCII) == "ftyp"
                val looksLikeOgg = read >= 4 && String(prefix, 0, 4, Charsets.US_ASCII) == "OggS"
                val looksLikeRiff = read >= 4 && String(prefix, 0, 4, Charsets.US_ASCII) == "RIFF"
                val result = buildString {
                    appendLine("Archivo: $name")
                    appendLine("Tamaño: ${formatBytes(size)}")
                    appendLine("Cabecera (hex): $hex")
                    appendLine("Texto inicial: $ascii")
                    appendLine()
                    appendLine("Resultado:")
                    when {
                        looksLikeMp4 -> appendLine("La cabecera parece un contenedor ISO-BMFF/MP4, aunque el archivo termine en .pvr.")
                        looksLikeOgg -> appendLine("La cabecera parece Ogg.")
                        looksLikeRiff -> appendLine("La cabecera parece RIFF (por ejemplo AVI/WAV); necesita más comprobaciones.")
                        else -> appendLine("La cabecera no permite identificar con certeza un vídeo PVR estándar.")
                    }
                    appendLine()
                    append("Puedes intentar convertirlo con FFmpeg si su contenedor y códecs están soportados. La extensión .pvr por sí sola no identifica un formato universal; si falla, no significa que el archivo esté dañado.")
                }
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Diagnóstico PVR")
                        .setMessage(result)
                        .setPositiveButton("Convertir a MP4") { _, _ -> askPvrConversion(uri, "mp4") }
                        .setNeutralButton("Más formatos") { _, _ ->
                            AlertDialog.Builder(this)
                                .setTitle("Salida del PVR")
                                .setItems(arrayOf("MP4 (vídeo)", "MP3 (audio)", "WAV (audio)")) { _, choice ->
                                    askPvrConversion(uri, when (choice) { 1 -> "mp3"; 2 -> "wav"; else -> "mp4" })
                                }
                                .setNegativeButton("Cancelar", null)
                                .show()
                        }
                        .setNegativeButton("Cerrar", null)
                        .show()
                    setStatus("Análisis PVR completado.")
                }
            } catch (e: Exception) {
                setStatus("No se pudo analizar el PVR: ${e.message}")
            }
        }
    }

    private fun askPvrConversion(uri: Uri, format: String) {
        pickedForConvert = uri
        chosenConversion = format
        outputMediaDestination.launch(displayName(uri).substringBeforeLast('.', "archivo") + "_convertido.$format")
    }

    private fun inspectFile(uri: Uri) {
        thread {
            try {
                val name = displayName(uri)
                val size = querySize(uri)
                val extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                val mime = contentResolver.getType(uri) ?: "desconocido"
                val details = buildString {
                    appendLine("Nombre: $name")
                    appendLine("Tamaño: ${formatBytes(size)}")
                    appendLine("Tipo MIME: $mime")
                    appendLine("Extensión: ${if (extension.isBlank()) "(sin extensión)" else extension}")
                    appendLine()
                    when (extension) {
                        "pvr" -> append("PVR detectado por extensión. Hay variantes de vídeo y de texturas; la conversión dependerá del contenedor/códecs que pueda leer FFmpeg.")
                        "mp4", "mkv", "mov", "avi", "webm", "3gp" -> append("Parece un contenedor de vídeo. Puedes intentar extraer el audio con la herramienta Vídeo a MP3.")
                        "zip" -> append("Archivo ZIP detectado. Usa Extraer archivo ZIP.")
                        "jpg", "jpeg", "png", "webp", "gif" -> append("Archivo de imagen. En esta versión se puede empaquetar en ZIP, pero aún no convertir imágenes.")
                        else -> append("Se puede empaquetar en ZIP sin cambiar su formato. La conversión depende de que exista un conversor compatible.")
                    }
                }
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Análisis del archivo")
                        .setMessage(details)
                        .setPositiveButton("Entendido", null)
                        .show()
                    setStatus("Análisis completado: $name")
                }
            } catch (e: Exception) {
                setStatus("No se pudo analizar el archivo: ${e.message}")
            }
        }
    }

    private fun querySize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0)
        }
        return -1L
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "No disponible"
        var value = bytes.toDouble()
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var index = 0
        while (value >= 1024 && index < units.lastIndex) { value /= 1024; index++ }
        return String.format(Locale.getDefault(), "%.2f %s", value, units[index])
    }

    private fun updateProgress(value: Int) {
        runOnUiThread { progress.progress = value.coerceIn(0, 100) }
    }

    private fun displayName(uri: Uri): String {
        var name = "archivo"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
        }
        return name
    }

    private fun safeEntryName(name: String): String {
        val cleaned = name.replace('\\', '/').substringAfterLast('/').filter { it.code >= 32 && it != ':' }
        return cleaned.ifBlank { "archivo" }
    }

    private fun uniqueEntryName(name: String, index: Int): String = if (index == 0) name else "${index + 1}_$name"
}
