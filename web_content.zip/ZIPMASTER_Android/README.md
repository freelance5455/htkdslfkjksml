# ZIPMASTER para Android — versión inicial 1.0

ZIPMASTER es un proyecto Android nativo con tres herramientas:
- Crear archivos ZIP a partir de varios archivos seleccionados.
- Extraer archivos ZIP en una carpeta elegida.
- Extraer audio a MP3/WAV o reencodificar vídeos compatibles a MP4 mediante FFmpegKit.
- Comprimir una carpeta completa, incluidas subcarpetas.
- Analizar nombre, tamaño, MIME y extensión aproximada.
- Mostrar recomendaciones básicas según el tipo de archivo.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK 35
- Conexión a internet la primera vez para que Gradle descargue dependencias. La app puede hacer las operaciones después de instalarse sin conexión.

## Cómo abrir
1. Descomprime `ZIPMASTER_Android.zip`.
   Android Studio puede abrir el proyecto directamente; este paquete incluye la configuración de Gradle, pero no los scripts binarios del wrapper.
2. Abre la carpeta `ZIPMASTER_Android` desde Android Studio.
3. Espera a que termine la sincronización de Gradle.
4. Ejecuta en un teléfono Android o emulador.

## Uso
- **Crear ZIP:** selecciona varios archivos; elige nombre y ubicación de salida.
- **Extraer ZIP:** selecciona un archivo ZIP y luego una carpeta de destino.
- **Vídeo a MP3:** selecciona un vídeo compatible y elige dónde guardar el MP3.

## Archivos grandes
La compresión de archivos, compresión de carpetas y extracción usan buffers de 256 KiB, en lugar de cargar el archivo completo en RAM. El espacio disponible, el proveedor de almacenamiento y la duración de la operación siguen siendo límites prácticos. La conversión a MP3 usa archivos temporales en la caché, así que necesita espacio libre adicional similar al tamaño del vídeo.

## Sobre PVR
“PVR” puede referirse a distintos formatos. Esta versión permite empaquetar archivos PVR en ZIP sin cambiar sus datos. La conversión de un PVR de vídeo solo funcionará si FFmpegKit reconoce el contenedor y sus códecs; no se garantiza para todos los archivos PVR.

## Seguridad
La extracción rechaza rutas absolutas y segmentos `..` para evitar que el contenido del ZIP intente salir de la carpeta seleccionada.

## Limitaciones de esta versión
- No incluye todavía una web.
- La opción “Archivos muy grandes” explica los límites; no divide archivos en partes todavía.
- La conversión implementada ofrece vídeo compatible → MP3/WAV y reencodificación a MP4, no conversión universal entre todos los formatos.
- El proyecto contiene código fuente; el APK se compila desde Android Studio. No se incluye APK precompilado en este ZIP.
- FFmpegKit es una dependencia de terceros y puede tener limitaciones de compatibilidad en versiones nuevas de Android.

## Estructura
- `app/src/main/java/com/zipmaster/app/MainActivity.kt`: interfaz y operaciones.
- `app/build.gradle.kts`: configuración y dependencia de conversión.


## Diagnóstico de PVR
La app incluye una herramienta para mostrar los primeros 64 bytes (hexadecimal y texto) y reconocer algunas cabeceras comunes. Desde ese diálogo se puede intentar reencodificar a MP4 o extraer MP3 usando FFmpegKit. No existe un único formato de vídeo universal llamado PVR: la compatibilidad depende de la estructura real del archivo y de los demultiplexores/códecs disponibles. No se promete compatibilidad con todos los archivos `.pvr`.

## Archivos grandes
Las operaciones ZIP leen/escriben por bloques para reducir RAM, pero el proveedor de almacenamiento de Android puede imponer límites y la conversión multimedia usa espacio temporal en caché. La app no puede garantizar tamaño ilimitado.


## Conversión PVR: intentos escalonados
La conversión a MP4 ahora prueba varios perfiles en orden:
1. H.264 + AAC (perfil MP4 habitual).
2. MPEG-4 Part 2 + AAC como alternativa.
3. Copia de flujos sin recodificar, si el contenido ya usa códecs admitidos por MP4.

Para MP3/WAV se intenta extraer la primera pista de audio. Los archivos se copian a caché en bloques, sin cargar el vídeo completo en memoria. Se requiere espacio temporal adicional aproximadamente comparable al tamaño de entrada y salida. Los resultados dependen de que FFmpegKit pueda leer el contenedor y decodificar sus pistas. No se puede garantizar convertir archivos propietarios, cifrados, dañados o PVR que no sean vídeo.
