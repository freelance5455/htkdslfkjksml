# Voucher Desk: install and use offline

Files: index.html, config.js, sw.js, manifest.webmanifest, icon.svg, icon-192.png, icon-512.png
There are no online libraries. Once installed, the app needs no internet.

## A. Put it on your phone (do this once, with internet)
1. Upload this folder to any free host: Netlify Drop (app.netlify.com/drop), Cloudflare Pages or GitHub Pages.
   (PythonAnywhere also works: add a static files mapping to the folder.)
2. On the phone, open the https link in Chrome (Android) or Safari (iPhone).
3. Android: menu (three dots) > "Install app" or "Add to Home screen".
   iPhone: Share > "Add to Home Screen".
4. Open the app once from the home screen. It is now saved on the phone and works with no network, even in flight mode.

## B. No hosting at all (Android, quick option)
1. Copy index.html and the other files to the phone (all in the same folder).
2. Open index.html from the Files app with Chrome. It works offline.
   Note: data is kept per file location, so always open it from the same place. Option A is more reliable.

## C. Real Android APK (optional)
Upload the hosted link (Option A) to pwabuilder.com, choose Android, download the APK and install it.

## Where files go
- Export PDF / Word, Save backup file: saved to the phone's Downloads folder.
- "Share or save to Files" (shown on phones): opens the share sheet. Choose Files, Google Drive, WhatsApp, etc.
- Print: opens the phone's print dialog (print to a printer or "Save as PDF").

## Daily use
1. Create an account (once). Log in.
2. New month. Add rows (choose how many). Type in the table, or paste rows copied from Excel.
3. Search box: type part of a name, account number or bank.
4. Columns: add (for example Allowance, Loan, Note), rename or delete columns. Choose whether an amount adds to or subtracts from the total.
5. Export: the list shows only name, account name, account number, bank and the net amount, with TOTAL PAYABLE and a total per bank.

## Google backup to Gmail
See SYNC_SETUP.md (one-time setup by the app owner). Users then back up to their own Google Drive from Profile > Cloud backup.

## Keep your data safe
Data lives only on this phone. Profile > Save backup file once a week and keep the file in Google Drive or send it to yourself.
Clearing the browser's site data or uninstalling the app removes the data, so restore from your backup file if that happens.
