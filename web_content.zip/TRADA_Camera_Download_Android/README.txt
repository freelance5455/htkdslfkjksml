TRADA Photo Manager - Android MediaStore build

PURPOSE
This build automatically imports images from Android MediaStore entries whose relative path is under:
  /storage/emulated/0/DCIM/
  /storage/emulated/0/Download/

IMPORTANT
This is a native Android WebView project, not a plain HTML-only ZIP. A plain HTML-to-APK wrapper cannot enumerate Android folders by itself. The native bridge in MainActivity.java queries MediaStore and sends image content URIs to the HTML interface.

PERMISSIONS
Android 13+: READ_MEDIA_IMAGES
Android 12 and below: READ_EXTERNAL_STORAGE

BUILD
Open this project in Android Studio or another Android Gradle build environment and build the app module. The project uses compileSdk 35 and Android Gradle Plugin 8.6.1.

BEHAVIOR
- Automatically requests the photo permission on first launch.
- Queries MediaStore.Images.
- Imports all indexed images under DCIM and Download.
- Displays images directly from their content:// URIs.
- No folder picker is required.
- The Scan button refreshes the MediaStore query.

NOTE ABOUT APKFORGE
If your APKForge is an HTML-to-APK wrapper that cannot compile/merge the included Android Java source and manifest, do not upload only index.html expecting direct filesystem access. Use the native Android project or an APKForge mode that supports native source/manifest changes.
