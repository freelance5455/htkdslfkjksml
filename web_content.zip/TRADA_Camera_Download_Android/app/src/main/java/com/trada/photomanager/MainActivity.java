package com.trada.photomanager;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ = 1001;
    private WebView web;
    private final String[] roots = {"DCIM", "Download"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new PhotoBridge(), "TRADAAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestPhotoPermission();
    }

    private void requestPhotoPermission() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{p}, REQ);
        else sendPhotos();
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g); if (r==REQ) sendPhotos();
    }

    private void sendPhotos() {
        new Thread(() -> {
            String json = queryPhotos();
            runOnUiThread(() -> web.evaluateJavascript("window.TRADA_RECEIVE(" + JSONObject.quote(json) + ");", null));
        }).start();
    }

    private String queryPhotos() {
        JSONArray out = new JSONArray();
        String[] proj = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATE_TAKEN, MediaStore.Images.Media.DATE_ADDED,
                MediaStore.Images.Media.SIZE, MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.BUCKET_DISPLAY_NAME, MediaStore.Images.Media.RELATIVE_PATH};
        String sel = MediaStore.Images.Media.RELATIVE_PATH + " LIKE ? OR " + MediaStore.Images.Media.RELATIVE_PATH + " LIKE ?";
        String[] args = {"DCIM/%", "Download/%"};
        String order = MediaStore.Images.Media.DATE_TAKEN + " DESC, " + MediaStore.Images.Media.DATE_ADDED + " DESC";
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, sel, args, order)) {
            if (c == null) return "[]";
            int idI=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID), nI=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int dtI=c.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN), daI=c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED);
            int szI=c.getColumnIndex(MediaStore.Images.Media.SIZE), mtI=c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
            int bI=c.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME), rI=c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
            while(c.moveToNext()) {
                long id=c.getLong(idI); Uri u=ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,id);
                JSONObject o=new JSONObject(); o.put("id",id); o.put("uri",u.toString()); o.put("name",c.getString(nI));
                o.put("dateTaken",dtI>=0&&!c.isNull(dtI)?c.getLong(dtI):0); o.put("dateAdded",daI>=0&&!c.isNull(daI)?c.getLong(daI)*1000L:0);
                o.put("size",szI>=0&&!c.isNull(szI)?c.getLong(szI):0); o.put("mime",mtI>=0&&!c.isNull(mtI)?c.getString(mtI):"");
                o.put("folder",bI>=0&&!c.isNull(bI)?c.getString(bI):""); o.put("relativePath",rI>=0&&!c.isNull(rI)?c.getString(rI):""); out.put(o);
            }
        } catch(Exception e) { return "[]"; }
        return out.toString();
    }

    public class PhotoBridge {
        @JavascriptInterface public String getPhotoFolders() { return "DCIM,Download"; }
        @JavascriptInterface public void refresh() { sendPhotos(); }
    }
}
