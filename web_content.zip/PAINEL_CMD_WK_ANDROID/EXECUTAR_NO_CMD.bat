@echo off
setlocal
title PAINEL CMD WK
cd /d "%~dp0"
set "SCRIPT=%~dp0PAINEL_CMD_WK.ps1"

if not exist "%SCRIPT%" (
    echo ERRO: PAINEL_CMD_WK.ps1 nao encontrado.
    echo Extraia todos os arquivos do ZIP para a mesma pasta.
    pause
    exit /b 1
)

echo Iniciando PAINEL CMD WK...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%SCRIPT%"
if errorlevel 1 (
    echo.
    echo O painel foi encerrado com erro. Verifique a instalacao do PowerShell/Windows.
    pause
)
endlocal
