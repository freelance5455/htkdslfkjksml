﻿#requires -version 5.1
# PAINEL CMD WK - Windows Optimizer
# Interface escura com verde-menta e deteccao dinamica de programas de inicializacao.
# Requer Windows PowerShell 5.1. Execute como Administrador para tarefas do sistema.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()

# ==================================================
# AUTENTICACAO POR KEY - PAINEL CMD WK
# Tela no mesmo tema preto/cinza e verde-menta do painel.
# ==================================================
$script:AccessKey = 'Otmmaximawk'

function Show-KeyGate {
    $mint = [Drawing.Color]::FromArgb(9,212,156)
    $dark = [Drawing.Color]::FromArgb(10,11,14)
    $panel = [Drawing.Color]::FromArgb(20,22,26)
    $panel2 = [Drawing.Color]::FromArgb(24,27,31)
    $white = [Drawing.Color]::FromArgb(235,239,242)
    $muted = [Drawing.Color]::FromArgb(160,168,177)

    $gate = New-Object Windows.Forms.Form
    $gate.Text = 'PAINEL CMD WK | Verificacao de Key'
    $gate.StartPosition = 'CenterScreen'
    $gate.Size = New-Object Drawing.Size(540,410)
    $gate.MinimumSize = $gate.Size
    $gate.MaximumSize = $gate.Size
    $gate.FormBorderStyle = 'FixedSingle'
    $gate.MaximizeBox = $false
    $gate.MinimizeBox = $false
    $gate.BackColor = $dark
    $gate.ForeColor = $white
    $gate.Font = New-Object Drawing.Font('Segoe UI',10)
    $gate.TopMost = $true

    $top = New-Object Windows.Forms.Panel
    $top.Location = New-Object Drawing.Point(0,0)
    $top.Size = New-Object Drawing.Size(524,7)
    $top.BackColor = $mint
    $gate.Controls.Add($top)

    $brand = New-Object Windows.Forms.Label
    $brand.Text = 'W'
    $brand.Location = New-Object Drawing.Point(28,23)
    $brand.Size = New-Object Drawing.Size(48,48)
    $brand.TextAlign = 'MiddleCenter'
    $brand.BackColor = $panel2
    $brand.ForeColor = $mint
    $brand.Font = New-Object Drawing.Font('Segoe UI',23,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($brand)

    $brandText = New-Object Windows.Forms.Label
    $brandText.Text = 'PAINEL CMD WK'
    $brandText.Location = New-Object Drawing.Point(88,25)
    $brandText.Size = New-Object Drawing.Size(360,25)
    $brandText.ForeColor = $white
    $brandText.Font = New-Object Drawing.Font('Segoe UI',14,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($brandText)

    $brandSub = New-Object Windows.Forms.Label
    $brandSub.Text = 'Windows Optimizer'
    $brandSub.Location = New-Object Drawing.Point(90,51)
    $brandSub.Size = New-Object Drawing.Size(300,20)
    $brandSub.ForeColor = $muted
    $gate.Controls.Add($brandSub)

    $divider = New-Object Windows.Forms.Panel
    $divider.Location = New-Object Drawing.Point(0,86)
    $divider.Size = New-Object Drawing.Size(524,1)
    $divider.BackColor = [Drawing.Color]::FromArgb(43,47,52)
    $gate.Controls.Add($divider)

    # Icone de cadeado desenhado em verde-menta (nao depende de fonte emoji).
    $lock = New-Object Windows.Forms.Panel
    $lock.Location = New-Object Drawing.Point(34,112)
    $lock.Size = New-Object Drawing.Size(58,58)
    $lock.BackColor = $dark
    $lock.Add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $pen = New-Object Drawing.Pen($mint, 6)
        $pen.StartCap = [Drawing.Drawing2D.LineCap]::Round
        $pen.EndCap = [Drawing.Drawing2D.LineCap]::Round
        $brush = New-Object Drawing.SolidBrush($mint)
        $g.DrawArc($pen, 14, 3, 30, 34, 180, 180)
        $g.FillRectangle($brush, 7, 25, 44, 30)
        $hole = New-Object Drawing.SolidBrush($dark)
        $g.FillEllipse($hole, 25, 32, 8, 8)
        $g.FillRectangle($hole, 27, 38, 4, 9)
        $hole.Dispose()
        $brush.Dispose()
        $pen.Dispose()
    })
    $gate.Controls.Add($lock)

    $heading = New-Object Windows.Forms.Label
    $heading.Text = 'Verificacao de Key'
    $heading.Location = New-Object Drawing.Point(105,112)
    $heading.Size = New-Object Drawing.Size(370,40)
    $heading.ForeColor = $white
    $heading.Font = New-Object Drawing.Font('Segoe UI',20,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($heading)

    $desc = New-Object Windows.Forms.Label
    $desc.Text = 'Digite a Key correta para liberar o acesso ao painel!'
    $desc.Location = New-Object Drawing.Point(35,180)
    $desc.Size = New-Object Drawing.Size(450,27)
    $desc.ForeColor = $white
    $desc.Font = New-Object Drawing.Font('Segoe UI',11,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($desc)

    $keyBox = New-Object Windows.Forms.TextBox
    $keyBox.Location = New-Object Drawing.Point(35,218)
    $keyBox.Size = New-Object Drawing.Size(450,38)
    $keyBox.Font = New-Object Drawing.Font('Segoe UI',12)
    $keyBox.UseSystemPasswordChar = $true
    $keyBox.BackColor = $panel2
    $keyBox.ForeColor = $white
    $keyBox.BorderStyle = 'FixedSingle'
    $gate.Controls.Add($keyBox)

    $status = New-Object Windows.Forms.Label
    $status.Text = ''
    $status.Location = New-Object Drawing.Point(37,260)
    $status.Size = New-Object Drawing.Size(445,20)
    $status.ForeColor = [Drawing.Color]::FromArgb(235,95,95)
    $status.Font = New-Object Drawing.Font('Segoe UI',9)
    $gate.Controls.Add($status)

    $cancel = New-Object Windows.Forms.Button
    $cancel.Text = 'Sair'
    $cancel.Location = New-Object Drawing.Point(35,290)
    $cancel.Size = New-Object Drawing.Size(205,42)
    $cancel.FlatStyle = 'Flat'
    $cancel.FlatAppearance.BorderColor = [Drawing.Color]::FromArgb(55,60,66)
    $cancel.BackColor = $panel2
    $cancel.ForeColor = $white
    $cancel.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($cancel)

    $enter = New-Object Windows.Forms.Button
    $enter.Text = 'Verificar Key'
    $enter.Location = New-Object Drawing.Point(255,290)
    $enter.Size = New-Object Drawing.Size(230,42)
    $enter.FlatStyle = 'Flat'
    $enter.FlatAppearance.BorderSize = 0
    $enter.BackColor = $mint
    $enter.ForeColor = [Drawing.Color]::FromArgb(5,28,22)
    $enter.Font = New-Object Drawing.Font('Segoe UI',10,[Drawing.FontStyle]::Bold)
    $gate.Controls.Add($enter)

    $footer = New-Object Windows.Forms.Label
    $footer.Text = 'Acesso restrito  |  Painel protegido'
    $footer.Location = New-Object Drawing.Point(35,350)
    $footer.Size = New-Object Drawing.Size(450,20)
    $footer.ForeColor = $muted
    $gate.Controls.Add($footer)

    $script:keyAccepted = $false
    $enter.Add_Click({
        if ([string]::Equals($keyBox.Text, $script:AccessKey, [StringComparison]::Ordinal)) {
            $script:keyAccepted = $true
            $gate.DialogResult = [Windows.Forms.DialogResult]::OK
            $gate.Close()
        } else {
            $status.Text = 'Key incorreta. Tente novamente.'
            $keyBox.Clear()
            $keyBox.Focus()
        }
    })
    $cancel.Add_Click({ $gate.DialogResult = [Windows.Forms.DialogResult]::Cancel; $gate.Close() })
    $gate.AcceptButton = $enter
    $gate.CancelButton = $cancel
    $gate.Add_Shown({ $keyBox.Focus() })
    [void]$gate.ShowDialog()
    return [bool]$script:keyAccepted
}

if (-not (Show-KeyGate)) {
    exit
}

$script:LogPath = Join-Path $PSScriptRoot ("PAINEL_CMD_WK_{0}.log" -f $env:COMPUTERNAME)
$script:StartupItems = @()
$script:StartupBackupKey = 'HKCU:\Software\PAINEL_CMD_WK\DisabledStartup'
$script:StartupFolderDisabled = Join-Path $env:APPDATA 'PAINEL_CMD_WK\StartupDisabled'
$script:StartupCommonDisabled = Join-Path $env:ProgramData 'PAINEL_CMD_WK\StartupDisabled'

$C = @{
    bg = [Drawing.Color]::FromArgb(10,11,14)
    side = [Drawing.Color]::FromArgb(14,15,19)
    card = [Drawing.Color]::FromArgb(20,22,26)
    card2 = [Drawing.Color]::FromArgb(24,27,31)
    cardOn = [Drawing.Color]::FromArgb(17,34,29)
    line = [Drawing.Color]::FromArgb(43,47,52)
    green = [Drawing.Color]::FromArgb(9,212,156)
    greenSoft = [Drawing.Color]::FromArgb(8,165,125)
    greenDark = [Drawing.Color]::FromArgb(13,47,39)
    white = [Drawing.Color]::FromArgb(235,239,242)
    muted = [Drawing.Color]::FromArgb(145,151,160)
    blue = [Drawing.Color]::FromArgb(65,145,230)
    red = [Drawing.Color]::FromArgb(220,90,90)
}
$font = 'Segoe UI'
$script:IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator

function Write-Log([string]$Message) {
    Add-Content -LiteralPath $script:LogPath -Value ("[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message) -Encoding UTF8
}
function Show-Info([string]$Message, [string]$Title='PAINEL CMD WK') {
    [void][Windows.Forms.MessageBox]::Show($Message,$Title,[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Information)
}
function New-Label($Text,$X,$Y,$W,$H,$Size=10,$Bold=$false,$Color=$C.white) {
    $l = New-Object Windows.Forms.Label
    $l.Text = $Text; $l.Location = New-Object Drawing.Point($X,$Y)
    $l.Size = New-Object Drawing.Size($W,$H); $l.ForeColor = $Color
    $style = if($Bold){[Drawing.FontStyle]::Bold}else{[Drawing.FontStyle]::Regular}
    $l.Font = New-Object Drawing.Font($font,$Size,$style)
    $l
}
function New-Button($Text,$X,$Y,$W,$H,$Primary=$false) {
    $b = New-Object Windows.Forms.Button
    $b.Text=$Text; $b.Location=New-Object Drawing.Point($X,$Y); $b.Size=New-Object Drawing.Size($W,$H)
    $b.FlatStyle='Flat'; $b.FlatAppearance.BorderColor=$C.line; $b.FlatAppearance.BorderSize=1
    $b.BackColor=if($Primary){$C.green}else{$C.card2}
    $b.ForeColor=if($Primary){[Drawing.Color]::FromArgb(7,25,18)}else{$C.white}
    $b.Font=New-Object Drawing.Font($font,9,[Drawing.FontStyle]::Bold)
    $b
}
function New-Card($Parent,$X,$Y,$W,$H) {
    $p=New-Object Windows.Forms.Panel
    $p.Location=New-Object Drawing.Point($X,$Y); $p.Size=New-Object Drawing.Size($W,$H)
    $p.BackColor=$C.card
    $p.BorderStyle='FixedSingle'
    $Parent.Controls.Add($p); $p
}
function Add-StartupItem($Name,$Command,$Location,$Kind,$ValueName,$ValueData,$RegPath,$FilePath,$User) {
    $script:StartupItems += [pscustomobject]@{
        Name=$Name; Command=$Command; Location=$Location; Kind=$Kind
        ValueName=$ValueName; ValueData=$ValueData; RegPath=$RegPath
        FilePath=$FilePath; User=$User; Enabled=$true
    }
}
function Get-StartupItems {
    $script:StartupItems = @()
    $runPaths = @(
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'
    )
    foreach($rp in $runPaths) {
        if(Test-Path $rp) {
            $props=Get-ItemProperty -Path $rp -ErrorAction SilentlyContinue
            if($props) {
                foreach($pr in $props.PSObject.Properties) {
                    if($pr.Name -notmatch '^PS') {
                        Add-StartupItem $pr.Name ([string]$pr.Value) $rp 'Registry' $pr.Name ([string]$pr.Value) $rp $null $env:USERNAME
                    }
                }
            }
        }
    }
    $folders=@(
        [Environment]::GetFolderPath('Startup'),
        [Environment]::GetFolderPath('CommonStartup')
    ) | Where-Object { $_ -and (Test-Path $_) }
    foreach($folder in $folders) {
        Get-ChildItem -LiteralPath $folder -File -ErrorAction SilentlyContinue | ForEach-Object {
            Add-StartupItem $_.BaseName $_.FullName $folder 'Shortcut' $_.Name $null $null $_.FullName $env:USERNAME
        }
    }
    # Itens desativados pelo proprio painel continuam visiveis para poder reativar.
    if(Test-Path $script:StartupBackupKey) {
        $backup=Get-ChildItem $script:StartupBackupKey -ErrorAction SilentlyContinue
        foreach($key in $backup) {
            $data=Get-ItemProperty -LiteralPath $key.PSPath -ErrorAction SilentlyContinue
            if($data) {
                $kind=[string]$data.Kind
                Add-StartupItem ([string]$data.DisplayName) ([string]$data.Command) ([string]$data.OriginalPath) 'DisabledRegistry' ([string]$data.ValueName) ([string]$data.Command) ([string]$data.OriginalPath) $null $env:USERNAME
                $script:StartupItems[-1].Enabled=$false
            }
        }
    }
    foreach($disabledFolder in @($script:StartupFolderDisabled,$script:StartupCommonDisabled)) {
        if(Test-Path $disabledFolder) {
            Get-ChildItem -LiteralPath $disabledFolder -File -ErrorAction SilentlyContinue | ForEach-Object {
                Add-StartupItem $_.BaseName $_.FullName $disabledFolder 'DisabledShortcut' $_.Name $null $null $_.FullName $env:USERNAME
                $script:StartupItems[-1].Enabled=$false
            }
        }
    }
    $script:StartupItems | Sort-Object Name -Unique
}
function Set-StartupItemState($Item,[bool]$Enable) {
    if($Item.Kind -in @('Registry','DisabledRegistry')) {
        if($Enable) {
            if($Item.Kind -eq 'DisabledRegistry') {
                $backupPath=Join-Path $script:StartupBackupKey ($Item.ValueName -replace '[\\/:*?"<>|]','_')
                $saved=Get-ItemProperty -LiteralPath $backupPath -ErrorAction SilentlyContinue
                if($saved -and $saved.OriginalPath -and $saved.ValueName) {
                    if(-not (Test-Path $saved.OriginalPath)){New-Item -Path $saved.OriginalPath -Force | Out-Null}
                    New-ItemProperty -Path $saved.OriginalPath -Name $saved.ValueName -Value $saved.Command -PropertyType String -Force | Out-Null
                    Remove-Item -LiteralPath $backupPath -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } else {
            if($Item.Kind -eq 'Registry' -and (Test-Path $Item.RegPath)) {
                if(-not (Test-Path $script:StartupBackupKey)){New-Item -Path $script:StartupBackupKey -Force | Out-Null}
                $safeName=$Item.ValueName -replace '[\\/:*?"<>|]','_'
                $bp=Join-Path $script:StartupBackupKey $safeName
                if(-not (Test-Path $bp)){New-Item -Path $bp -Force | Out-Null}
                New-ItemProperty -LiteralPath $bp -Name DisplayName -Value $Item.Name -PropertyType String -Force | Out-Null
                New-ItemProperty -LiteralPath $bp -Name Command -Value $Item.ValueData -PropertyType String -Force | Out-Null
                New-ItemProperty -LiteralPath $bp -Name ValueName -Value $Item.ValueName -PropertyType String -Force | Out-Null
                New-ItemProperty -LiteralPath $bp -Name OriginalPath -Value $Item.RegPath -PropertyType String -Force | Out-Null
                Remove-ItemProperty -Path $Item.RegPath -Name $Item.ValueName -ErrorAction Stop
            }
        }
    } elseif($Item.Kind -in @('Shortcut','DisabledShortcut')) {
        if($Enable -and $Item.Kind -eq 'DisabledShortcut') {
            $target=if($Item.Location -eq $script:StartupCommonDisabled){[Environment]::GetFolderPath('CommonStartup')}else{[Environment]::GetFolderPath('Startup')}
            if(-not (Test-Path $target)){New-Item -ItemType Directory -Path $target -Force | Out-Null}
            Move-Item -LiteralPath $Item.FilePath -Destination $target -Force
        } elseif((-not $Enable) -and $Item.Kind -eq 'Shortcut') {
            $target=if($Item.Location -eq [Environment]::GetFolderPath('CommonStartup')){$script:StartupCommonDisabled}else{$script:StartupFolderDisabled}
            if(-not (Test-Path $target)){New-Item -ItemType Directory -Path $target -Force | Out-Null}
            Move-Item -LiteralPath $Item.FilePath -Destination $target -Force
        }
    }
}
function Add-PageTitle($Page,$Title,$Subtitle) {
    $Page.Controls.Add((New-Label $Title 22 16 700 38 22 $true $C.white))
    $Page.Controls.Add((New-Label $Subtitle 24 56 900 28 9 $false $C.muted))
}
function Add-InfoCard($Page,$X,$Y,$W,$Title,$Value,$Hint) {
    $p=New-Card $Page $X $Y $W 118
    $p.Controls.Add((New-Label $Title 16 14 ($W-32) 24 9 $false $C.muted))
    $p.Controls.Add((New-Label $Value 16 42 ($W-32) 34 19 $true $C.green))
    $p.Controls.Add((New-Label $Hint 16 82 ($W-32) 22 8 $false $C.muted))
    $p
}

$form=New-Object Windows.Forms.Form
$form.Text='PAINEL CMD WK'; $form.StartPosition='CenterScreen'
$form.Size=New-Object Drawing.Size(1450,900); $form.MinimumSize=New-Object Drawing.Size(1100,720)
$form.BackColor=$C.bg; $form.ForeColor=$C.white; $form.Font=New-Object Drawing.Font($font,9)
$form.FormBorderStyle='Sizable'; $form.MaximizeBox=$true

$sidebar=New-Object Windows.Forms.Panel
$sidebar.Dock='Left'; $sidebar.Width=245; $sidebar.BackColor=$C.side
$form.Controls.Add($sidebar)
$logo=New-Object Windows.Forms.Label
$logo.Text='W'; $logo.TextAlign='MiddleCenter'; $logo.Font=New-Object Drawing.Font($font,23,[Drawing.FontStyle]::Bold)
$logo.ForeColor=$C.green; $logo.BackColor=$C.greenDark; $logo.Location=New-Object Drawing.Point(20,22); $logo.Size=New-Object Drawing.Size(58,58)
$sidebar.Controls.Add($logo)
$sidebar.Controls.Add((New-Label 'PAINEL CMD WK' 90 25 145 25 12 $true $C.white))
$sidebar.Controls.Add((New-Label 'Windows Optimizer' 91 51 140 22 8 $false $C.muted))
$nav=New-Object Windows.Forms.FlowLayoutPanel
$nav.Location=New-Object Drawing.Point(12,130); $nav.Size=New-Object Drawing.Size(220,480)
$nav.FlowDirection='TopDown'; $nav.WrapContents=$false; $nav.BackColor=$C.side
$sidebar.Controls.Add($nav)
$license=New-Card $sidebar 16 780 212 75
$license.Controls.Add((New-Label '●  LOCAL MODE' 14 12 180 22 10 $true $C.green))
$license.Controls.Add((New-Label 'Windows maintenance tools' 14 39 185 20 8 $false $C.muted))

$pages=New-Object Windows.Forms.TabControl
$pages.Dock='Fill'; $pages.Appearance='FlatButtons'; $pages.ItemSize=New-Object Drawing.Size(1,1); $pages.SizeMode='Fixed'
$pages.BackColor=$C.bg; $pages.Padding=New-Object Drawing.Point(0,0)
$form.Controls.Add($pages); $pages.BringToFront(); $sidebar.BringToFront()
$pageNames=@('Dashboard','Optimize','Network','Startup Apps','Services','Logs','Settings')
$pageMap=@{}
foreach($n in $pageNames) {
    $tp=New-Object Windows.Forms.TabPage
    $tp.Text=$n; $tp.BackColor=$C.bg; $tp.AutoScroll=$true
    [void]$pages.TabPages.Add($tp); $pageMap[$n]=$tp
}
$navButtons=@{}
$icons=@{'Dashboard'='⌂';'Optimize'='ϟ';'Network'='◉';'Startup Apps'='➤';'Services'='⚙';'Logs'='▤';'Settings'='☷'}
foreach($n in $pageNames) {
    $b=New-Object Windows.Forms.Button
    $b.Text="  $($icons[$n])   $n"; $b.Size=New-Object Drawing.Size(205,48); $b.Margin=New-Object Windows.Forms.Padding(0,3,0,5)
    $b.FlatStyle='Flat'; $b.FlatAppearance.BorderSize=0; $b.TextAlign='MiddleLeft'
    $b.Font=New-Object Drawing.Font($font,10,[Drawing.FontStyle]::Bold)
    $b.BackColor=$C.side; $b.ForeColor=$C.muted
    $b.Add_Click({$pages.SelectedTab=$pageMap[$this.Tag]; foreach($key in $navButtons.Keys){$navButtons[$key].BackColor=$C.side;$navButtons[$key].ForeColor=$C.muted};$this.BackColor=$C.greenDark;$this.ForeColor=$C.green}.GetNewClosure())
    $b.Tag=$n; $nav.Controls.Add($b); $navButtons[$n]=$b
}
function Select-Page($Name) {
    $pages.SelectedTab=$pageMap[$Name]
    foreach($key in $navButtons.Keys){$navButtons[$key].BackColor=$C.side;$navButtons[$key].ForeColor=$C.muted}
    $navButtons[$Name].BackColor=$C.greenDark; $navButtons[$Name].ForeColor=$C.green
}

# DASHBOARD
$dash=$pageMap['Dashboard']; Add-PageTitle $dash 'Dashboard' 'Visao geral do seu sistema e acesso rapido as principais ferramentas.'
$dash.Controls.Add((New-Button '↻  Atualizar' 950 18 120 38 $false))
$dash.Controls.Add((New-Button '⚡  Aplicar Tudo' 1080 18 150 38 $true))
Add-InfoCard $dash 22 110 270 'Status do Sistema' 'Verificando...' 'Resumo do computador'
Add-InfoCard $dash 310 110 270 'Desempenho' 'Monitoramento' 'CPU, memoria e disco'
Add-InfoCard $dash 598 110 300 'Informacoes do Sistema' $env:COMPUTERNAME 'Nome deste computador'
$quick=New-Card $dash 22 245 620 250
$quick.Controls.Add((New-Label 'Acoes Rapidas' 18 14 300 28 13 $true $C.white))
$quickButtons=@(
    @('Otimizacao Rapida','Optimize'),@('Limpeza de Sistema','Optimize'),
    @('Verificar Rede','Network'),@('Gerenciar Inicializacao','Startup Apps'),
    @('Gerenciar Servicos','Services'),@('Abrir Logs','Logs')
)
$qi=0
foreach($q in $quickButtons) {
    $x=18+(($qi%3)*195);$y=58+([math]::Floor($qi/3)*78)
    $qb=New-Button $q[0] $x $y 180 58 $false
    $target=$q[1];$qb.Add_Click({Select-Page $target}.GetNewClosure());$quick.Controls.Add($qb);$qi++
}
$resource=New-Card $dash 660 245 570 250
$resource.Controls.Add((New-Label 'Uso de Recursos' 18 14 300 28 13 $true $C.white))
$resource.Controls.Add((New-Label 'Os indicadores sao atualizados ao abrir o painel.' 18 55 520 24 9 $false $C.muted))
$resource.Controls.Add((New-Label ("Windows: {0}" -f [Environment]::OSVersion.VersionString) 18 100 520 25 9 $false $C.white))
$resource.Controls.Add((New-Label ("Usuario: {0}" -f $env:USERNAME) 18 138 520 25 9 $false $C.white))
$resource.Controls.Add((New-Label ("PowerShell: {0}" -f $PSVersionTable.PSVersion) 18 176 520 25 9 $false $C.white))
$tip=New-Card $dash 22 515 1208 72
$tip.Controls.Add((New-Label 'Dica do Painel:' 18 10 180 22 10 $true $C.green))
$tip.Controls.Add((New-Label 'Revise os programas de inicializacao antes de desativa-los. Alguns sao importantes para drivers e seguranca.' 18 35 1150 24 9 $false $C.muted))

# OPTIMIZE
$opt=$pageMap['Optimize']; Add-PageTitle $opt 'Optimize' 'Ferramentas de manutencao e reparo do Windows.'
$optScroll=New-Object Windows.Forms.FlowLayoutPanel
$optScroll.Location=New-Object Drawing.Point(22,100);$optScroll.Size=New-Object Drawing.Size(1200,650)
$optScroll.FlowDirection='TopDown';$optScroll.WrapContents=$false;$optScroll.AutoScroll=$true;$optScroll.BackColor=$C.bg
$opt.Controls.Add($optScroll)
$script:OptChecks=@{}
$optTasks=@(
    @('Limpar arquivos temporarios','Remove arquivos temporarios do usuario e do Windows.','temp'),
    @('Limpeza de componentes','Executa a limpeza de componentes antigos do Windows.','component'),
    @('Reparar imagem do Windows (DISM)','Verifica e tenta reparar a imagem do sistema.','dism'),
    @('Verificar arquivos do sistema (SFC)','Verifica arquivos protegidos do Windows.','sfc'),
    @('Otimizar SSD / HD','Usa a otimizacao recomendada pelo Windows.','drive'),
    @('Limpar cache DNS','Esvazia o cache DNS local.','dns')
)
foreach($task in $optTasks) {
    $row=New-Card $optScroll 0 0 1120 70
    $row.Margin=New-Object Windows.Forms.Padding(0,4,0,4)
    $row.Controls.Add((New-Label $task[0] 18 10 790 24 10 $true $C.white))
    $row.Controls.Add((New-Label $task[1] 18 36 850 22 8 $false $C.muted))
    $ck=New-Object Windows.Forms.CheckBox;$ck.Text='Ativar';$ck.Checked=$true;$ck.ForeColor=$C.green;$ck.BackColor=$C.card
    $ck.Location=New-Object Drawing.Point(970,22);$ck.AutoSize=$true;$row.Controls.Add($ck)
    $script:OptChecks[$task[2]]=$ck
}
$runOpt=New-Button '⚡  Executar tarefas selecionadas' 22 765 280 42 $true
$opt.Controls.Add($runOpt)
$runOpt.Add_Click({
    $selected=@($script:OptChecks.Keys | Where-Object {$script:OptChecks[$_].Checked})
    if(-not $selected.Count){Show-Info 'Selecione ao menos uma tarefa.';return}
    $runOpt.Enabled=$false
    try {
        foreach($k in $selected) {
            Write-Log "Inicio da tarefa: $k"
            switch($k) {
                'temp' { foreach($path in @($env:TEMP,(Join-Path $env:windir 'Temp'))) {if(Test-Path $path){Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue}} }
                'component' {Start-Process dism.exe -ArgumentList '/Online','/Cleanup-Image','/StartComponentCleanup' -Wait -NoNewWindow}
                'dism' {Start-Process dism.exe -ArgumentList '/Online','/Cleanup-Image','/RestoreHealth' -Wait -NoNewWindow}
                'sfc' {Start-Process sfc.exe -ArgumentList '/scannow' -Wait -NoNewWindow}
                'drive' {Get-Volume -ErrorAction SilentlyContinue | Where-Object {$_.DriveLetter -and $_.DriveType -eq 'Fixed'} | ForEach-Object {Start-Process defrag.exe -ArgumentList "$($_.DriveLetter): /O" -Wait -NoNewWindow}}
                'dns' {Start-Process ipconfig.exe -ArgumentList '/flushdns' -Wait -NoNewWindow}
            }
            Write-Log "Concluida a tarefa: $k"
        }
        Show-Info 'Rotina finalizada. Consulte a aba Logs.'
    } catch {Write-Log $_.Exception.Message;Show-Info $_.Exception.Message 'Erro'} finally {$runOpt.Enabled=$true}
})

# NETWORK
$net=$pageMap['Network']; Add-PageTitle $net 'Network' 'Ferramentas de conectividade e diagnostico de rede.'
$netTasks=@(
    @('Limpar DNS','Limpa o cache DNS do Windows.','dns'),
    @('Renovar IP','Solicita um novo endereco IP ao DHCP.','renew'),
    @('Redefinir Winsock','Restaura o catalogo Winsock. Pode exigir reinicializacao.','winsock'),
    @('Informacoes da Rede','Exibe configuracao IP e adaptadores.','info'),
    @('Verificar Conexao','Testa conectividade com um destino publico.','ping'),
    @('Abrir Configuracoes de Rede','Abre as configuracoes de rede do Windows.','settings')
)
$ny=105
foreach($t in $netTasks) {
    $r=New-Card $net 22 $ny 1205 66
    $r.Controls.Add((New-Label $t[0] 18 9 820 23 10 $true $C.white))
    $r.Controls.Add((New-Label $t[1] 18 34 850 20 8 $false $C.muted))
    $b=New-Button 'Executar' 1040 15 135 36 $false;$key=$t[2]
    $b.Add_Click({
        try {
            switch($key) {
                'dns' {ipconfig /flushdns | Out-String | Write-Log;Show-Info 'Cache DNS limpo.'}
                'renew' {Start-Process ipconfig.exe -ArgumentList '/release' -Wait -NoNewWindow;Start-Process ipconfig.exe -ArgumentList '/renew' -Wait -NoNewWindow;Show-Info 'Solicitacao de renovacao de IP concluida.'}
                'winsock' {if([Windows.Forms.MessageBox]::Show('Redefinir Winsock pode exigir reiniciar o Windows. Continuar?','Confirmar',[Windows.Forms.MessageBoxButtons]::YesNo) -eq 'Yes'){netsh winsock reset | Out-String | Write-Log;Show-Info 'Winsock redefinido. Reinicie o computador.'}}
                'info' {$out=ipconfig /all | Out-String;[Windows.Forms.MessageBox]::Show($out,'Informacoes da Rede') | Out-Null}
                'ping' {$out=ping.exe -n 4 1.1.1.1 | Out-String;[Windows.Forms.MessageBox]::Show($out,'Teste de Conexao') | Out-Null}
                'settings' {Start-Process 'ms-settings:network-status'}
            }
        } catch {Write-Log $_.Exception.Message;Show-Info $_.Exception.Message 'Erro'}
    }.GetNewClosure())
    $r.Controls.Add($b);$ny+=76
}

# STARTUP APPS - listagem dinamica
$startup=$pageMap['Startup Apps']; Add-PageTitle $startup 'Startup Apps' 'Os itens abaixo sao lidos do Windows neste computador; nao sao exemplos fixos.'
$startup.Controls.Add((New-Label 'Os programas configurados para iniciar com o Windows aparecem automaticamente. Apps apenas instalados, mas que nao iniciam com o Windows, nao entram nesta lista.' 24 88 1180 42 8 $false $C.muted))
$refreshStartup=New-Button '↻  Atualizar Lista' 22 138 160 38 $false
$disableAll=New-Button 'Desativar Selecionados' 190 138 190 38 $true
$enableAll=New-Button 'Ativar Selecionados' 388 138 180 38 $false
$startup.Controls.AddRange(@($refreshStartup,$disableAll,$enableAll))
$grid=New-Object Windows.Forms.DataGridView
$grid.Location=New-Object Drawing.Point(22,190);$grid.Size=New-Object Drawing.Size(1205,510)
$grid.BackgroundColor=$C.card;$grid.ForeColor=$C.white;$grid.GridColor=$C.line
$grid.BorderStyle='None';$grid.AllowUserToAddRows=$false;$grid.AllowUserToDeleteRows=$false
$grid.ReadOnly=$false;$grid.RowHeadersVisible=$false;$grid.SelectionMode='FullRowSelect'
$grid.AutoSizeColumnsMode='Fill';$grid.EnableHeadersVisualStyles=$false
$grid.ColumnHeadersDefaultCellStyle.BackColor=$C.card2;$grid.ColumnHeadersDefaultCellStyle.ForeColor=$C.green
$grid.DefaultCellStyle.BackColor=$C.card;$grid.DefaultCellStyle.ForeColor=$C.white
$grid.DefaultCellStyle.SelectionBackColor=$C.greenDark;$grid.DefaultCellStyle.SelectionForeColor=$C.white
$iconCol=New-Object Windows.Forms.DataGridViewImageColumn
$iconCol.Name='Icon';$iconCol.HeaderText='';$iconCol.ImageLayout='Zoom';$iconCol.FillWeight=7
$grid.Columns.Add($iconCol) | Out-Null
$grid.Columns.Add('Name','Programa') | Out-Null
$grid.Columns.Add('User','Usuario') | Out-Null
$grid.Columns.Add('Location','Origem') | Out-Null
$grid.Columns.Add('Command','Comando / Caminho') | Out-Null
$enabledCol=New-Object Windows.Forms.DataGridViewCheckBoxColumn
$enabledCol.Name='Enabled';$enabledCol.HeaderText='Ativo';$grid.Columns.Add($enabledCol) | Out-Null
$startup.Controls.Add($grid)
$startupStatus=New-Label 'Carregando itens de inicializacao...' 24 712 1100 25 9 $false $C.green
$startup.Controls.Add($startupStatus)
function Get-StartupIcon([string]$Command,[string]$FilePath) {
    try {
        $candidate=$FilePath
        if(-not $candidate -and $Command) {
            if($Command -match '^\s*"([^\"]+\.exe)"') {$candidate=$matches[1]}
            elseif($Command -match '^\s*([^,]+?\.exe)(?:\s|,|$)') {$candidate=$matches[1].Trim('"')}
        }
        if($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            $ico=[Drawing.Icon]::ExtractAssociatedIcon($candidate)
            if($ico){return $ico.ToBitmap()}
        }
    } catch {}
    return $null
}
function Refresh-StartupGrid {
    $grid.Rows.Clear()
    $items=@(Get-StartupItems)
    foreach($it in $items) {
        $icon=Get-StartupIcon $it.Command $it.FilePath
        $idx=$grid.Rows.Add($icon,$it.Name,$it.User,$it.Location,$it.Command,[bool]$it.Enabled)
        $grid.Rows[$idx].Tag=$it
        $grid.Rows[$idx].Height=38
    }
    $startupStatus.Text=("{0} item(ns) encontrado(s) nesta conta/instalacao." -f $items.Count)
}
function Change-SelectedStartup([bool]$Enable) {
    $rows=@($grid.SelectedRows)
    if(-not $rows.Count){Show-Info 'Selecione um ou mais programas na lista.';return}
    foreach($row in $rows) {
        $it=$row.Tag
        try {
            Set-StartupItemState $it $Enable
            Write-Log ("Startup {0}: {1}" -f $(if($Enable){'ativado'}else{'desativado'}),$it.Name)
        } catch {Write-Log ("Falha ao alterar {0}: {1}" -f $it.Name,$_.Exception.Message)}
    }
    Refresh-StartupGrid
}
$refreshStartup.Add_Click({Refresh-StartupGrid})
$disableAll.Add_Click({Change-SelectedStartup $false})
$enableAll.Add_Click({Change-SelectedStartup $true})
$grid.Add_CellValueChanged({
    if($_.RowIndex -ge 0 -and $_.ColumnIndex -eq 5) {
        $it=$grid.Rows[$_.RowIndex].Tag
        try {Set-StartupItemState $it ([bool]$grid.Rows[$_.RowIndex].Cells[5].Value);Refresh-StartupGrid}
        catch {Show-Info $_.Exception.Message 'Nao foi possivel alterar';Refresh-StartupGrid}
    }
})
$grid.Add_CurrentCellDirtyStateChanged({if($grid.IsCurrentCellDirty){$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)}})

# SERVICES
$services=$pageMap['Services']; Add-PageTitle $services 'Services' 'Consulte e controle servicos do Windows. Evite desativar servicos essenciais.'
$svcGrid=New-Object Windows.Forms.DataGridView
$svcGrid.Location=New-Object Drawing.Point(22,105);$svcGrid.Size=New-Object Drawing.Size(1205,580)
$svcGrid.BackgroundColor=$C.card;$svcGrid.ForeColor=$C.white;$svcGrid.GridColor=$C.line
$svcGrid.BorderStyle='None';$svcGrid.AllowUserToAddRows=$false;$svcGrid.ReadOnly=$true;$svcGrid.RowHeadersVisible=$false
$svcGrid.SelectionMode='FullRowSelect';$svcGrid.AutoSizeColumnsMode='Fill';$svcGrid.EnableHeadersVisualStyles=$false
$svcGrid.ColumnHeadersDefaultCellStyle.BackColor=$C.card2;$svcGrid.ColumnHeadersDefaultCellStyle.ForeColor=$C.green
$svcGrid.DefaultCellStyle.BackColor=$C.card;$svcGrid.DefaultCellStyle.ForeColor=$C.white
foreach($col in @('Name','DisplayName','Status','StartType')){$svcGrid.Columns.Add($col,$col) | Out-Null}
$services.Controls.Add($svcGrid)
$svcRefresh=New-Button '↻  Atualizar' 22 705 140 38 $false
$svcStart=New-Button 'Iniciar Servico' 172 705 150 38 $true
$svcStop=New-Button 'Parar Servico' 332 705 150 38 $false
$services.Controls.AddRange(@($svcRefresh,$svcStart,$svcStop))
function Refresh-Services {
    $svcGrid.Rows.Clear()
    Get-Service | Sort-Object DisplayName | ForEach-Object {
        $start='Desconhecido'
        try {$start=(Get-CimInstance Win32_Service -Filter "Name='$($_.Name.Replace("'","''"))'" -ErrorAction Stop).StartMode}catch{}
        $i=$svcGrid.Rows.Add($_.Name,$_.DisplayName,$_.Status,$start);$svcGrid.Rows[$i].Tag=$_.Name
    }
}
$svcRefresh.Add_Click({Refresh-Services})
$svcStart.Add_Click({if($svcGrid.SelectedRows.Count){$n=$svcGrid.SelectedRows[0].Tag;try{Start-Service -Name $n -ErrorAction Stop;Refresh-Services}catch{Show-Info $_.Exception.Message 'Erro'}}})
$svcStop.Add_Click({if($svcGrid.SelectedRows.Count){$n=$svcGrid.SelectedRows[0].Tag;if([Windows.Forms.MessageBox]::Show("Parar o servico $n? Alguns recursos do Windows podem parar de funcionar.",'Confirmar',[Windows.Forms.MessageBoxButtons]::YesNo) -eq 'Yes'){try{Stop-Service -Name $n -Force -ErrorAction Stop;Refresh-Services}catch{Show-Info $_.Exception.Message 'Erro'}}}})

# LOGS
$logs=$pageMap['Logs']; Add-PageTitle $logs 'Logs' 'Historico das acoes realizadas pelo PAINEL CMD WK.'
$logBox=New-Object Windows.Forms.TextBox
$logBox.Location=New-Object Drawing.Point(22,105);$logBox.Size=New-Object Drawing.Size(1205,580)
$logBox.Multiline=$true;$logBox.ReadOnly=$true;$logBox.ScrollBars='Vertical'
$logBox.BackColor=$C.card;$logBox.ForeColor=$C.white;$logBox.Font=New-Object Drawing.Font('Consolas',9)
$logs.Controls.Add($logBox)
$logRefresh=New-Button '↻  Atualizar' 22 705 140 38 $false
$logExport=New-Button 'Exportar Log' 172 705 150 38 $true
$logs.Controls.AddRange(@($logRefresh,$logExport))
function Refresh-Logs {if(Test-Path $script:LogPath){$logBox.Text=Get-Content -LiteralPath $script:LogPath -Raw -ErrorAction SilentlyContinue}else{$logBox.Text='Nenhum registro ainda.'}}
$logRefresh.Add_Click({Refresh-Logs})
$logExport.Add_Click({$dlg=New-Object Windows.Forms.SaveFileDialog;$dlg.Filter='Arquivo de texto (*.txt)|*.txt';$dlg.FileName='PAINEL_CMD_WK_log.txt';if($dlg.ShowDialog() -eq 'OK'){[IO.File]::WriteAllText($dlg.FileName,$logBox.Text,[Text.Encoding]::UTF8);Show-Info 'Log exportado.'}})

# SETTINGS
$settings=$pageMap['Settings']; Add-PageTitle $settings 'Settings' 'Preferencias e informacoes do painel.'
$general=New-Card $settings 22 110 570 300
$general.Controls.Add((New-Label 'Geral' 18 14 300 28 13 $true $C.white))
$general.Controls.Add((New-Label 'Executar como Administrador' 18 65 420 24 10 $true $C.white))
$general.Controls.Add((New-Label ($(if($script:IsAdmin){'Permissoes administrativas ativas'}else{'Algumas tarefas exigem permissao elevada'})) 18 92 520 22 8 $false $C.muted))
$general.Controls.Add((New-Label 'Arquivo de log:' 18 145 420 22 9 $true $C.white))
$general.Controls.Add((New-Label $script:LogPath 18 172 530 55 8 $false $C.muted))
$about=New-Card $settings 615 110 590 300
$about.Controls.Add((New-Label 'Sobre o Painel' 18 14 300 28 13 $true $C.white))
$about.Controls.Add((New-Label 'PAINEL CMD WK' 18 65 400 28 15 $true $C.green))
$about.Controls.Add((New-Label 'Windows Optimizer • Modo Local' 18 102 500 22 9 $false $C.muted))
$about.Controls.Add((New-Label 'A lista de inicializacao e obtida do Windows localmente.' 18 155 530 42 9 $false $C.white))
$restore=New-Button 'Restaurar Aparencia Padrao' 22 435 220 40 $false
$settings.Controls.Add($restore)
$restore.Add_Click({Show-Info 'A aparencia padrao ja esta aplicada. Reinicie o painel se alterar arquivos externos.'})

$form.Add_Shown({
    Select-Page 'Dashboard'
    try {Refresh-StartupGrid;Refresh-Services;Refresh-Logs} catch {Write-Log $_.Exception.Message}
})
$form.Add_FormClosing({Write-Log 'Painel encerrado.'})
Write-Log 'Painel iniciado.'
[void]$form.ShowDialog()
