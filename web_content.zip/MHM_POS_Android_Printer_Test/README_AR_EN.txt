# MHM POS - Android Printer Test (Source Project)

## What this package contains
- `app/src/main/assets/index.html`: a test copy of the uploaded MHM POS HTML with only the Android printer bridge routing added.
- `نظام إدارة المطاعم المتكامل - MHM POS (5).html`: untouched original file.
- A native Android WebView host with a Bluetooth Classic / ESC-POS printing bridge.

## Important status
This is a **source test project**, not a compiled APK. The current build environment does not have Android SDK / Gradle installed, so an APK cannot honestly be claimed as built or device-tested here.
The PrinterKit dependency is an experimental candidate and must be built, installed, and tested with the exact `POS58IV SB` printer before it is approved for production.

## Build
1. Open this folder in Android Studio (JDK 17).
2. Allow Gradle sync and download dependencies.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the phone.
5. Open the app, allow Bluetooth permission, choose `POS58IV SB`, and test a sample receipt.

## Test order
1. Pairing/listing the already-paired printer.
2. Connect to `POS58IV SB`.
3. Print one sample customer receipt.
4. Print one kitchen ticket.
5. Print driver settlement, treasury statement, and shift Z report.
6. Test Arabic shaping, right-to-left alignment, paper feed, and cut behavior (if supported).

## Scope / preservation
No sales, stock, cashbox, user, activation, or data logic was intentionally changed.
Only the printer selection/connection path and the routing of existing 58mm HTML print layouts to the native Android print bridge were added.
The original HTML is included unchanged for recovery and comparison.

## Known limitations to resolve during hardware test
- Exact POS58IV SB Bluetooth profile / ESC-POS compatibility has not been independently verified.
- The test bridge uses Bluetooth Classic paired-device RFCOMM. BLE-only models are not supported by this candidate.
- This test wrapper does not yet add a foreground printer service; connection is owned by the app process and is expected to be re-established if Android kills the app.
- Existing external CDN resources in the HTML remain unchanged; this wrapper needs internet access for those remote CSS/font assets.
