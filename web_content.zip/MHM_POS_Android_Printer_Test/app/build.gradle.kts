plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mhm.pos"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.mhm.pos"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0-printer-test"
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.github.DeveloperRejaul:android-printer-kit:v0.1.1")
}
