package com.mhm.pos

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.rezaul.printerkit.PosPrinter
import com.rezaul.printerkit.model.ConnectPrinterParams
import com.rezaul.printerkit.model.PrintHtmlParams
import com.rezaul.printerkit.model.PrinterFilter
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var printer: PosPrinter
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var lastPrinterAddress: String? = null
    @Volatile private var lastPrinterName: String? = null

    companion object {
        private const val REQUEST_BT = 4102
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        printer = PosPrinter(this)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidPrinterBridge(), "AndroidPrinter")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        ensureBluetoothPermission()
    }

    private fun ensureBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT),
                REQUEST_BT
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BT &&
            (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED)
        ) {
            notifyJs("window.onNativePrinterConnected && window.onNativePrinterConnected(false,'يجب السماح بصلاحية البلوتوث للاتصال بالطابعة')")
        }
    }

    private fun jsCall(script: String) {
        runOnUiThread { webView.evaluateJavascript(script, null) }
    }

    private fun jsString(value: String): String =
        JSONObject.quote(value)

    inner class AndroidPrinterBridge {
        @JavascriptInterface
        fun listPairedPrinters(): String {
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT)
                        != PackageManager.PERMISSION_GRANTED
                ) return "[]"

                val devices = printer.getBondedBluetoothPrinters(PrinterFilter.ALL)
                val json = JSONArray()
                devices.forEach { device ->
                    json.put(JSONObject().put("name", device.name ?: "Printer").put("address", device.address))
                }
                json.toString()
            } catch (_: SecurityException) {
                "[]"
            } catch (_: Exception) {
                "[]"
            }
        }

        @JavascriptInterface
        fun connect(address: String) {
            worker.execute {
                try {
                    val ok = printer.connectPrinter(ConnectPrinterParams(address = address))
                    if (ok) {
                        val device = printer.getConnectedPrinter()
                        lastPrinterAddress = address
                        lastPrinterName = device?.name ?: "POS58IV SB"
                        jsCall(
                            "window.onNativePrinterConnected && window.onNativePrinterConnected(true,'تم الاتصال'," +
                                "${jsString(address)},${jsString(lastPrinterName ?: "POS58IV SB")})"
                        )
                    } else {
                        jsCall("window.onNativePrinterConnected && window.onNativePrinterConnected(false,'تعذر الاتصال بالطابعة')")
                    }
                } catch (e: Exception) {
                    jsCall("window.onNativePrinterConnected && window.onNativePrinterConnected(false,${jsString(e.message ?: "خطأ اتصال")})")
                }
            }
        }

        @JavascriptInterface
        fun printHtml(html: String) {
            worker.execute {
                try {
                    if (!printer.isConnectedPrinter()) {
                        jsCall("window.onNativePrintResult && window.onNativePrintResult(false,'الطابعة غير متصلة')")
                        return@execute
                    }
                    printer.printHtml(
                        PrintHtmlParams(
                            html = html,
                            printerWidthDots = 384,
                            pageWidthDp = 204,
                            bandHeightDots = 16,
                            bandDelayMs = 70L
                        )
                    ) { success ->
                        jsCall(
                            "window.onNativePrintResult && window.onNativePrintResult(" +
                                "$success,${jsString(if (success) "تمت الطباعة" else "فشلت الطباعة")})"
                        )
                    }
                } catch (e: Exception) {
                    jsCall("window.onNativePrintResult && window.onNativePrintResult(false,${jsString(e.message ?: "خطأ أثناء الطباعة")})")
                }
            }
        }

        @JavascriptInterface
        fun isConnected(): Boolean = try {
            printer.isConnectedPrinter()
        } catch (_: Exception) {
            false
        }
    }

    private fun notifyJs(script: String) = jsCall(script)

    override fun onDestroy() {
        try { printer.disconnectPrinter() } catch (_: Exception) {}
        worker.shutdown()
        webView.removeJavascriptInterface("AndroidPrinter")
        webView.destroy()
        super.onDestroy()
    }
}
