Change Album: UK coin collection app

Files
  index.html            the app
  manifest.webmanifest  lets phones install it like an app
  sw.js                 lets it work offline once installed
  icon-192.png, icon-512.png

To use it
  Quick: open index.html in any browser. Coins are saved in that browser on that device.

  As an installable app: upload this whole folder to any free HTTPS host
  (GitHub Pages, Netlify Drop, Cloudflare Pages), then open the address on your phone.
    iPhone (Safari): Share, then Add to Home Screen.
    Android (Chrome): menu, then Install app.

Your coins stay on the device you use. Use the Export tab to download a backup file,
and restore it on another device.
