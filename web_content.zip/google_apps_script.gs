// CALEROS BARBER SHOP — Google Apps Script backend
// 1) Crea un proyecto en https://script.google.com/
// 2) Pega este código. Cambia SECRET_KEY por una clave larga y privada.
// 3) Implementar > Nueva implementación > Aplicación web
//    Ejecutar como: Yo | Quién tiene acceso: Cualquier usuario
// 4) Copia la URL /exec en el software y usa la misma clave privada.
// NOTA: Este backend guarda una copia JSON en Script Properties.
// Para un negocio con varios operadores simultáneos, conviene migrar a Firestore.

const SECRET_KEY = 'CAMBIA-ESTA-CLAVE-POR-UNA-LARGA-Y-PRIVADA';
const DATA_KEY = 'CALEROS_BARBER_LOYALTY_DATA';

function doGet(e) {
  const key = (e && e.parameter && e.parameter.key) || '';
  if (key !== SECRET_KEY) return json({error:'Clave incorrecta'});
  const raw = PropertiesService.getScriptProperties().getProperty(DATA_KEY);
  return json({data: raw ? JSON.parse(raw) : {clients:[], events:[]}, ok:true});
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.key !== SECRET_KEY) return json({error:'Clave incorrecta'});
    if (!body.data || !Array.isArray(body.data.clients) || !Array.isArray(body.data.events)) {
      return json({error:'Formato de datos inválido'});
    }
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      PropertiesService.getScriptProperties().setProperty(DATA_KEY, JSON.stringify(body.data));
    } finally {
      lock.releaseLock();
    }
    return json({ok:true, savedAt:new Date().toISOString()});
  } catch (err) {
    return json({error:String(err)});
  }
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
