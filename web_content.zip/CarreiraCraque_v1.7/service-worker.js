const CACHE_NAME = 'carreira-craque-pwa-v110-uniformes';
const APP_SHELL = ["./", "./index.html", "./manifest.webmanifest", "./data/jogadores_reais_2026.json", "./icons/icon-192.png", "./icons/icon-512.png", "./assets/escudos/abc.svg", "./assets/escudos/america-mg.svg", "./assets/escudos/atletico-go.svg", "./assets/escudos/atletico-mg.svg", "./assets/escudos/atletico-pr.svg", "./assets/escudos/avai.svg", "./assets/escudos/bahia.svg", "./assets/escudos/boa-esporte.svg", "./assets/escudos/botafogo.svg", "./assets/escudos/bragantino.svg", "./assets/escudos/brasil-de-pelotas.svg", "./assets/escudos/ceara.svg", "./assets/escudos/chapecoense.svg", "./assets/escudos/corinthians.svg", "./assets/escudos/coritiba.svg", "./assets/escudos/crb.svg", "./assets/escudos/criciuma.svg", "./assets/escudos/cruzeiro.svg", "./assets/escudos/figueirense.svg", "./assets/escudos/flamengo.svg", "./assets/escudos/fluminense.svg", "./assets/escudos/goias.svg", "./assets/escudos/gremio.svg", "./assets/escudos/internacional.svg", "./assets/escudos/joinville.svg", "./assets/escudos/londrina.svg", "./assets/escudos/luverdense.svg", "./assets/escudos/macae.svg", "./assets/escudos/mogi-mirim.svg", "./assets/escudos/nautico.svg", "./assets/escudos/oeste.svg", "./assets/escudos/palmeiras.svg", "./assets/escudos/parana.svg", "./assets/escudos/paysandu.svg", "./assets/escudos/ponte-preta.svg", "./assets/escudos/sampaio-correa.svg", "./assets/escudos/santa-cruz.svg", "./assets/escudos/santos.svg", "./assets/escudos/sao-paulo.svg", "./assets/escudos/sport.svg", "./assets/escudos/tupi.svg", "./assets/escudos/vasco.svg", "./assets/escudos/vila-nova.svg", "./assets/escudos/vitoria.svg"];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('carreira-craque-pwa-') && key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then(response => { const copy=response.clone(); caches.open(CACHE_NAME).then(cache=>cache.put('./index.html',copy)); return response; }).catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => { if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(req,copy));} return response; })));
});
