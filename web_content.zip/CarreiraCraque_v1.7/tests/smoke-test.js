// Logic smoke test for Carreira Craque. Uses a tiny DOM stub; it is not a browser/UI test.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const match = html.match(/<script>([\s\S]*)<\/script>/);
if (!match) throw new Error('Could not find application script in index.html');
const source = match[1] + '\n;globalThis.__test={newCareer,playMatch,getFixture,stateRef:()=>state,train,coachChoice,lifeAction,ensureCareerSystems,completeTransfer,careerManager,confirmDeleteCareer,homeView,careerView,matchesView,trainingView,leagueView,marketView,squadView,newsView,statsView,lifeView,coachView,historyView,competitionsView,settingsPageView,moreMenu,playerView,rosterForClub,rosterBase,REAL_ROSTERS,ROSTER_SOURCES,ROSTER_NUMBER_SOURCES,requestShirtNumber,validatePlayerNumber,rosterOccupant,decideOccupiedShirt,transferRealPlayer,openRealPlayerDetails,realPlayerSkills,realPlayerSeasonStats,realPlayerSeasonStats,beginInteractiveMatch,simulateLiveSegment,continueInteractiveMatch,finishInteractiveMatch,recalc,expandSkills,positionWeights,BR_A,BR_B,makeFixtures,emptyTable,updateTableFor,sortStandings,simulateOtherLeagueRound,finishSeason,initBrazilianLeagues,initialDivisions,switchCompetitionToClub,scout,createOffer,maybeGenerateOffer,offerProbability,eligibleTargets,showOffer,acceptOffer,rejectOffer,negotiateOffer,requestExit,notify,openInbox,simulateScore,teamStrength,advanceOneDay,advanceCalendar,unreadNotifications,kitInfo,kitGarmentSvg,avatarSvg,KIT_VERIFIED,KIT_REFERENCE_CATALOG,KIT_STYLE,APPEARANCE_DEFAULTS};';

function boot(initial = {}) {
  class Element {
    constructor(id = '') { this.id=id; this.innerHTML=''; this.textContent=''; this.value=''; this.files=[]; this.dataset={}; this.style={}; this.classList={add(){},remove(){},contains(){return false}}; }
    querySelectorAll() { return []; }
    querySelector() { return new Element(); }
    click() {}
  }
  const elements = {};
  const document = {
    querySelector(selector) { return elements[selector] || (elements[selector] = new Element(selector)); },
    querySelectorAll() { return []; },
    createElement() { return new Element(); },
    body: new Element('body')
  };
  const store = {...initial};
  const localStorage = {
    getItem(key) { return store[key] ?? null; },
    setItem(key, value) { store[key] = String(value); },
    removeItem(key) { delete store[key]; }
  };
  const context = {
    document, localStorage, console, Math, Date, JSON, Blob: function(){},
    URL: {createObjectURL(){return '';}, revokeObjectURL(){}},
    confirm(){return true;}, alert(){}, setTimeout(){return 1;}, clearTimeout(){},
    FormData: function(){}, FileReader: function(){}, navigator:{}, performance:{now(){return 0;}}
  };
  context.window = context;
  vm.createContext(context);
  vm.runInContext(source, context);
  return {app: context.__test, store};
}
function assert(condition, message) { if (!condition) throw new Error(message); }

const {app, store} = boot();
app.newCareer({name:'Teste Jogador', nickname:'Teste', age:18, nation:'Brasileira', pos:'Ponta esquerda', secondary:'Meia-atacante', height:178, weight:72, foot:'Direito', number:10, club:'Internacional', potential:80, skin:'#b87d54', hair:'#30231c'});
let s = app.stateRef();
assert(s && s.table.length === 20 && s.fixtures.length === 38 && s.otherLeague.table.length === 20 && s.otherLeague.fixtures.length === 38, 'career creation / 2026 A and B league schedules');
const expectedA=['Athletico Paranaense','Atlético Mineiro','Bahia','Botafogo','Chapecoense','Corinthians','Coritiba','Cruzeiro','Flamengo','Fluminense','Grêmio','Internacional','Mirassol','Palmeiras','Red Bull Bragantino','Remo','Santos','São Paulo','Vasco da Gama','Vitória'];
const expectedB=['América Mineiro','Athletic Club','Atlético Goianiense','Avaí','Botafogo-SP','Ceará','CRB','Criciúma','Cuiabá','Fortaleza','Goiás','Juventude','Londrina','Náutico','Novorizontino','Operário-PR','Ponte Preta','São Bernardo','Sport Recife','Vila Nova'];
assert(JSON.stringify(app.BR_A.map(c=>c[0]))===JSON.stringify(expectedA)&&JSON.stringify(app.BR_B.map(c=>c[0]))===JSON.stringify(expectedB)&&new Set([...app.BR_A,...app.BR_B].map(c=>c[0])).size===40, 'all 40 requested club names and division assignments');
for(const division of [app.BR_A,app.BR_B]){const fx=app.makeFixtures(division.map(c=>c[0]));assert(fx.length===38 && fx.every(r=>r.length===10),'38 rounds, 10 games per round');const pairs=new Map(),home={},away={};for(const r of fx)for(const f of r){assert(f.home!==f.away,'no self-fixtures');home[f.home]=(home[f.home]||0)+1;away[f.away]=(away[f.away]||0)+1;const k=[f.home,f.away].sort().join('|');pairs.set(k,(pairs.get(k)||0)+1)}assert(pairs.size===190 && [...pairs.values()].every(n=>n===2),'each opponent pair plays twice');assert(division.every(c=>home[c[0]]===19&&away[c[0]]===19),'19 home and 19 away fixtures per club');}
assert(s.squad.length >= 5 && s.squad.every(x=>x.isReal) && s.matchMode === 'hybrid' && s.objectives.length >= 2, 'career systems initialized with identified real roster records');
assert(Object.keys(app.REAL_ROSTERS).length===40 && [...app.BR_A,...app.BR_B].every(c=>app.rosterForClub(c[0]).length>=1), 'each of the 40 clubs has a separate sourced real-player roster subset');
const clubCoverage=[...app.BR_A,...app.BR_B].map(c=>app.rosterForClub(c[0]).length);assert(Math.min(...clubCoverage)>=17&&clubCoverage.every(n=>n>=17),'all 40 clubs have at least 17 rostered players');assert(!html.includes('TRANSFERIR NO SAVE')&&!html.includes('data-real-player="${esc(x.id)}"'),'rival details and squad screen expose no user control for rival transfers');
const rosterAll=[...app.BR_A,...app.BR_B].flatMap(c=>app.rosterForClub(c[0])); assert(new Set(rosterAll.map(x=>x.id)).size===rosterAll.length, 'real-player registry IDs are unique across the 40 clubs');
assert(typeof app.playerView()==='string' && app.playerView().includes('JOGADOR'), 'player profile screen renders');
const customizeState=app.stateRef();customizeState.playerSection='customize';assert(Object.keys(app.KIT_REFERENCE_CATALOG).length===40,'reference-based visual catalog covers all 40 club records');customizeState.p.club='Athletic Club';customizeState.p.number=17;customizeState.p.name='Teste Jogador';const kitOnlyView=app.playerView();assert(kitOnlyView.includes('Camisa do jogador')&&kitOnlyView.includes('Teste Jogador')&&kitOnlyView.includes('Nº 17')&&kitOnlyView.includes('player-shirt-svg')&&!kitOnlyView.includes('avatar-stage')&&!kitOnlyView.includes('Personalizar aparência'), 'player customization is replaced by a club shirt displaying player name and number');assert(app.homeView().includes('player-shirt-svg')&&!app.homeView().includes('avatar-mini'), 'home dashboard shows shirt-only player artwork instead of a face/avatar');customizeState.p.club='Internacional';customizeState.p.number=10;customizeState.p.name='Teste Jogador';
assert(app.rosterForClub('Internacional').some(x=>x.name==='Alan Patrick'&&x.number===10), 'known jersey number and owner are connected to the current roster');
assert(app.rosterForClub('Internacional').every(x=>Array.isArray(x.skills)&&x.skills.length===21&&x.skills.every(v=>v>=30&&v<=96)), 'real player gameplay attributes are generated per player and position');
for(const club of [...app.BR_A,...app.BR_B].map(c=>c[0])){assert(app.rosterForClub(club).every(p=>Number.isInteger(p.number)||p.number===null), `shirt numbers remain numeric for ${club}`);}
assert(app.validatePlayerNumber('Internacional',10)===false && app.validatePlayerNumber('Internacional',30)===true, 'occupied jersey rejected and unoccupied-in-dataset number accepted');
assert(s.p.skills.length === 21 && app.positionWeights(s.p.pos).length === 21, 'full 21-attribute positional profile initialized');
const serieBApp=boot().app; serieBApp.newCareer({name:'Atleta Série B',nickname:'B',age:19,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Meia-atacante',height:178,weight:72,foot:'Direito',number:11,club:'Sport Recife',potential:80,skin:'#b87d54',hair:'#30231c'}); assert(serieBApp.stateRef().division==='B'&&serieBApp.stateRef().table.length===20&&serieBApp.stateRef().fixtures.length===38,'career in a Série B club starts in the correct competition');
const transferApp=boot().app; transferApp.newCareer({name:'Atleta Transferência',nickname:'T',age:19,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Meia-atacante',height:178,weight:72,foot:'Direito',number:11,club:'Internacional',potential:80,skin:'#b87d54',hair:'#30231c'}); let ts=transferApp.stateRef(); ts.round=4; ts.otherLeague.round=4; ts.p.club='Sport Recife'; transferApp.switchCompetitionToClub('Sport Recife'); assert(ts.division==='B'&&ts.round===4&&ts.table.some(x=>x.club==='Sport Recife')&&ts.otherLeague.division==='A','transfer to another division switches league without replaying rounds');
const migrationApp=boot().app; migrationApp.newCareer({name:'Migração Save',nickname:'M',age:19,nation:'Brasileira',pos:'Meia central',secondary:'Não definida',height:178,weight:72,foot:'Direito',number:12,club:'Internacional',potential:80,skin:'#b87d54',hair:'#30231c'});const ms=migrationApp.stateRef();ms.v=2;ms.realRosterMoves=[{playerId:'fake-old-move',from:'Internacional',to:'Sport Recife'}];ms.realShirtChanges=[{playerId:'fake-old-shirt',club:'Internacional',from:10,to:22}];migrationApp.ensureCareerSystems();assert(ms.v===6&&ms.realRosterMoves.length===0&&ms.realShirtChanges.length===0,'older saves clear user-driven rival moves and shirt reassignments during migration');
const ptsTable=app.emptyTable(['Casa','Fora','Neutro']); app.updateTableFor(ptsTable,'Casa','Fora',2,0); app.updateTableFor(ptsTable,'Fora','Neutro',1,1); app.updateTableFor(ptsTable,'Neutro','Casa',0,3); assert(ptsTable.find(x=>x.club==='Casa').pts===6 && ptsTable.find(x=>x.club==='Fora').pts===1 && ptsTable.find(x=>x.club==='Neutro').pts===1,'3-1-0 points system');
for (const view of [app.homeView,app.careerView,app.matchesView,app.trainingView,app.leagueView,app.marketView,app.squadView,app.newsView,app.statsView,app.lifeView,app.coachView,app.historyView,app.competitionsView,app.settingsPageView,app.playerView]) assert(typeof view() === 'string' && view().length > 50, 'screen renders without throwing');
const homeMetricsBefore=app.homeView();assert(homeMetricsBefore.includes('<small>PARTIDAS</small>')&&!homeMetricsBefore.includes('<small>OVERALL</small>')&&homeMetricsBefore.includes('<small>GOLS</small>')&&homeMetricsBefore.includes('<small>ASSIST.</small>')&&homeMetricsBefore.includes('<small>NOTA MÉDIA</small>'),'home dashboard replaces OVERALL with PARTIDAS while retaining goals, assists and average rating');
const homeStatsState=app.stateRef();homeStatsState.careerStats.apps=3;homeStatsState.careerStats.goals=2;homeStatsState.careerStats.assists=1;homeStatsState.careerStats.ratingTotal=21.6;const homeMetricsAfter=app.homeView();assert(homeMetricsAfter.includes('<small>PARTIDAS</small><b>3</b>')&&homeMetricsAfter.includes('<small>GOLS</small><b>2</b>')&&homeMetricsAfter.includes('<small>ASSIST.</small><b>1</b>'),'home indicators read the saved career statistics directly and reflect updates');assert(app.careerView().includes('<small>OVERALL</small>'),'overall remains available on the player profile');
const trustBefore = s.coachTrust; app.coachChoice('minutes'); assert(s.coachTalks.length === 1 && s.news.length >= 3, 'coach conversation records consequences');
const repBefore = s.reputation; app.lifeAction('media'); assert(s.reputation !== undefined && s.lifeLedger.length >= 1, 'life/media system updates persistent state');
assert(Object.keys(JSON.parse(store.cc_v1_saves || '{}')).length === 1, 'autosave after career creation');
const shirtBefore=s.p.number; app.requestShirtNumber(88,'request'); assert(s.p.number===88 && s.shirtNumberHistory.at(-1).to===88, 'vacant-in-dataset shirt request updates player and history'); const savedAfterShirt=JSON.parse(store.cc_v1_saves)[s.id]; assert(savedAfterShirt.p.number===88, 'shirt number persists to autosave'); app.requestShirtNumber(10,'request'); 
assert(s.p.number===88, 'occupied shirt request does not steal a number automatically');
app.requestShirtNumber(23,'request');assert(s.p.number===23,'second unoccupied-in-dataset number can be requested');s.p.ovr=99;s.p.potential=99;s.p.form=100;s.p.confidence=100;s.coachTrust=100;s.reputation=100;s.history=Array.from({length:5},(_,i)=>({season:s.season,minutes:90,rating:9.5,goals:2,assists:1}));const alan=app.rosterForClub('Internacional').find(x=>x.name==='Alan Patrick');app.decideOccupiedShirt(10,alan);const interRosterAfterShirt=app.rosterForClub('Internacional');assert(s.p.number===23 && interRosterAfterShirt.find(x=>x.name==='Alan Patrick').number===10 && interRosterAfterShirt.find(x=>x.name==='Alan Patrick').id===alan.id, 'even a strong request cannot renumber or displace the current shirt owner');
const movePlayer=app.rosterForClub('Internacional').find(x=>x.name==='Carbonero'); const beforeMoveCount=app.rosterForClub('Internacional').length; const moveResult=app.transferRealPlayer(movePlayer.id,'Sport Recife'); assert(!moveResult.ok && app.rosterForClub('Internacional').length===beforeMoveCount && app.rosterForClub('Internacional').some(x=>x.id===movePlayer.id) && !app.rosterForClub('Sport Recife').some(x=>x.id===movePlayer.id), 'player-career mode blocks user-driven transfers of rival players');
const energyBefore = s.p.energy;
app.train('finishing');
const energyAfter = s.p.energy;
assert(energyAfter < energyBefore, 'training must consume energy');
app.train('physical');
assert(s.p.energy === energyAfter, 'second training on same day must be blocked');

let totalGoalEvents = 0;
for (let round = 0; round < 15; round++) {
  s.day = 7;
  const historyBefore = s.history.length;
  const appsBeforeMatch = s.careerStats.apps;
  app.playMatch();
  assert(s.history.length === historyBefore + 1, `match history for round ${round+1}`);
  const m = s.history[s.history.length - 1];
  assert(s.careerStats.apps === appsBeforeMatch + (m.minutes > 0 ? 1 : 0), `PARTIDAS count updates only when the player enters the field in round ${round+1}`);
  const goalEvents = m.events.filter(e => e.type === 'goal').length;
  assert(goalEvents === m.homeGoals + m.awayGoals, `score/event consistency in round ${round+1}`);
  assert(m.goals === m.events.filter(e => e.playerGoal).length, `player goals consistency in round ${round+1}`);
  assert(m.assists === m.events.filter(e => e.playerAssist).length, `player assists consistency in round ${round+1}`);
  totalGoalEvents += goalEvents;
}
assert(s.table.reduce((sum, row) => sum + row.p, 0) === 300, 'all 16 clubs should have played 15 matches');
assert(s.table.every(row => row.p === 15), 'every club should have 15 matches after 15 rounds');
for (let round = 15; round < 38; round++) {
  s.day = 7;
  app.playMatch();
  const m = s.history[s.history.length - 1];
  assert(m.events.filter(e => e.type === 'goal').length === m.homeGoals + m.awayGoals, `score/event consistency in round ${round+1}`);
  totalGoalEvents += m.events.filter(e => e.type === 'goal').length;
}
assert(s.season === 2027 && s.round === 0, 'season rollover after round 38');
assert(s.seasonHistory.length === 1, 'season summary is archived');
assert(s.table.every(row => row.p === 0) && s.table.length===20, 'league table resets for the new season');
assert(s.leagueHistory.length===1 && s.leagueHistory[0].tableA.every(row=>row.p===38) && s.leagueHistory[0].tableB.every(row=>row.p===38), 'both league divisions complete 380 matches and archive standings');
assert(s.leagueHistory[0].fixturesA.flat().length===380&&s.leagueHistory[0].fixturesB.flat().length===380&&s.leagueHistory[0].fixturesA.flat().every(f=>f.played)&&s.leagueHistory[0].fixturesB.flat().every(f=>f.played),'all historical match results are archived');
assert(Object.keys(s.realPlayerStats||{}).length>0 && Object.values(s.realPlayerStats||{}).some(x=>(x.career?.goals||0)>0), 'real-player goals and assists are persisted from simulated results');
assert(s.lastPromotionRelegation.promotedB.length===4&&s.lastPromotionRelegation.relegatedA.length===4&&s.divisions.A.length===20&&s.divisions.B.length===20,'four-up/four-down between A and B');
assert(s.divisions.A.length===20&&s.divisions.B.length===20&&new Set([...s.divisions.A,...s.divisions.B]).size===40,'promotion and relegation preserve 20 unique clubs per division');
const reloaded=boot({cc_v1_saves:store.cc_v1_saves,cc_v1_active:store.cc_v1_active}).app.stateRef(); assert(reloaded.season===2027&&reloaded.leagueHistory[0].fixturesA.flat().length===380&&reloaded.leagueHistory[0].fixturesB.flat().length===380,'save/reload preserves both division results and standings');
assert(reloaded.p.number===s.p.number&&reloaded.realShirtChanges.length===s.realShirtChanges.length,"save/reload preserves the controlled player shirt number and the previous owner reassignment");

const old = {cc_v3: JSON.stringify({created:true, season:2026, day:42, round:7, p:{name:'Atleta Antigo',club:'Internacional',pos:'Ponta esquerda',skills:[60,61,62,63,64,65],ovr:62,potential:80}, apps:8, starts:5, minutes:480, goals:2, assists:1, history:[{home:'Internacional',away:'Corinthians',gf:1,ga:0,minutes:90,rating:7.1}]})};
const migrated = boot(old).app.stateRef();
assert(migrated.p.name === 'Atleta Antigo', 'legacy career player should migrate');
assert(migrated.p.skills.length === 21, 'legacy attributes should migrate to the 21-attribute schema');
assert(migrated.fixtures.length === 38 && migrated.table.length===20 && migrated.round === 0, 'legacy calendar should migrate to 38-round league');


// Interactive half-time path: the first half is persisted, second-half decisions finish exactly one fixture.
const interactive = boot();
interactive.app.newCareer({name:'Jogador Interativo', nickname:'Interativo', age:19, nation:'Brasileira', pos:'Ponta esquerda', secondary:'Meia-atacante', height:178, weight:72, foot:'Direito', number:11, club:'Internacional', potential:80, skin:'#b87d54', hair:'#30231c'});
let live = interactive.app.stateRef();
live.day = 7; live.matchMode = 'decisions';
interactive.app.beginInteractiveMatch();
live = interactive.app.stateRef();
assert(live.liveMatch && live.liveMatch.phase === 'halftime', 'interactive mode persists a halftime state');
assert(live.liveMatch.events.filter(e=>e.type==='goal'&&e.minute<=45).length === live.liveMatch.userGoals + live.liveMatch.oppGoals, 'first-half goal events match score');
interactive.app.continueInteractiveMatch('attacking','shoot');
live = interactive.app.stateRef();
assert(live.liveMatch === null && live.history.length === 1 && live.round === 1, 'interactive second half finalizes one fixture');
const interactiveMatch = live.history[0];
assert(interactiveMatch.events.filter(e=>e.type==='goal').length === interactiveMatch.homeGoals + interactiveMatch.awayGoals, 'interactive final score matches recorded goals');
assert(interactiveMatch.teamStats && interactiveMatch.teamStats.home.possession + interactiveMatch.teamStats.away.possession === 100, 'interactive team stats are saved consistently');

// Transfer flow, proposal realism gates, persisted notification, and match-balance regression tests.
const marketTest=boot();
marketTest.app.newCareer({name:'Atleta Mercado',nickname:'Mercado',age:19,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Meia-atacante',height:178,weight:72,foot:'Direito',number:11,club:'Internacional',potential:85,skin:'#b87d54',hair:'#30231c'});
let mt=marketTest.app.stateRef();
mt.careerStats.apps=8;mt.careerStats.minutes=620;mt.careerStats.goals=4;mt.careerStats.assists=3;mt.p.form=82;mt.p.ovr=78;
const created=marketTest.app.createOffer('Sport Recife');
assert(created&&mt.offers.length===1&&mt.notifications.some(n=>n.type==='offer'&&n.offerId===created.id)&&marketTest.app.unreadNotifications()===1,'valid offer creates one persistent unread notification immediately');
assert(marketTest.app.createOffer('Palmeiras')===null&&mt.offers.length===1,'duplicate offers are blocked while one is pending');
mt.day=6;marketTest.app.advanceOneDay();assert(mt.offers.length===1,'calendar advancement does not generate a second offer while a proposal is pending');
marketTest.app.completeTransfer(0);
assert(mt.p.club==='Sport Recife'&&mt.contract.wage===created.wage&&mt.contract.years===created.years&&mt.transfers.some(t=>t.from==='Internacional'&&t.to==='Sport Recife'),'accepting offer changes club, contract, and career history end-to-end');
assert(marketTest.app.getFixture()&&[marketTest.app.getFixture().home,marketTest.app.getFixture().away].includes('Sport Recife'),'transferred player has a valid fixture after division switch');
const persistedTransfer=JSON.parse(marketTest.store.cc_v1_saves)[mt.id];
assert(persistedTransfer.p.club==='Sport Recife'&&persistedTransfer.contract.wage===created.wage&&persistedTransfer.notifications.some(n=>n.type==='transfer'),'club and contract change persist in autosave with transfer notification');
const transferReload=boot({cc_v1_saves:marketTest.store.cc_v1_saves,cc_v1_active:mt.id}).app.stateRef();assert(transferReload.p.club==='Sport Recife'&&transferReload.contract.wage===created.wage&&transferReload.transfers.some(t=>t.to==='Sport Recife'),'transfer and new contract survive career reload');
const low=boot().app;low.newCareer({name:'Baixa Forma',nickname:'Baixa',age:31,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Não definida',height:178,weight:72,foot:'Direito',number:11,club:'Internacional',potential:70,skin:'#b87d54',hair:'#30231c'});let lowState=low.stateRef();lowState.careerStats.apps=2;lowState.p.form=15;lowState.contract.years=3;lowState.history=Array.from({length:5},()=>({rating:5.2,minutes:20,goals:0,assists:0}));
const high=boot().app;high.newCareer({name:'Grande Fase',nickname:'Fase',age:19,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Meia-atacante',height:178,weight:72,foot:'Direito',number:11,club:'Internacional',potential:90,skin:'#b87d54',hair:'#30231c'});let highState=high.stateRef();highState.careerStats.apps=24;highState.careerStats.minutes=1800;highState.careerStats.goals=14;highState.careerStats.assists=9;highState.p.form=96;highState.p.ovr=86;highState.history=Array.from({length:8},()=>({rating:8.4,minutes:90,goals:1,assists:1}));
assert(high.offerProbability()>low.offerProbability(),'offer probability responds to age, performance, minutes, goals, assists, and form');
const poorCandidates=low.eligibleTargets(),strongCandidates=high.eligibleTargets();assert(poorCandidates.every(t=>t.club!=='Internacional')&&strongCandidates.length>0,'target selection excludes current club and returns compatible clubs');
const ai=boot().app;ai.newCareer({name:'Teste IA',nickname:'IA',age:20,nation:'Brasileira',pos:'Meia central',secondary:'Não definida',height:178,weight:72,foot:'Direito',number:11,club:'Flamengo',potential:85,skin:'#b87d54',hair:'#30231c'});
let totalGoals=0,strongWins=0,weakWins=0,draws=0;for(let i=0;i<500;i++){const [hg,ag]=ai.simulateScore('Flamengo','Londrina');totalGoals+=hg+ag;if(hg>ag)strongWins++;else if(ag>hg)weakWins++;else draws++;assert(hg>=0&&hg<=6&&ag>=0&&ag<=6,'AI score stays in plausible bounded range')}
assert(totalGoals/500>1.2&&totalGoals/500<4.5,'AI mean goals remain within broad plausible bounds');assert(strongWins>weakWins,'stronger club has a statistical advantage without predetermined scores');
const exitHarness=boot();const exitTest=exitHarness.app;exitTest.newCareer({name:'Pedido Saída',nickname:'Saída',age:21,nation:'Brasileira',pos:'Ponta esquerda',secondary:'Não definida',height:178,weight:72,foot:'Direito',number:11,club:'Internacional',potential:80,skin:'#b87d54',hair:'#30231c'});const exitState=exitTest.stateRef();exitState.p.ovr=60;exitTest.requestExit();assert(!!exitState.exitRequested&&exitState.notifications.some(n=>n.type==='exit_request'),'request-exit action records request and notification');assert(exitState.offers.length===1&&exitState.offers[0].club!=='Internacional'&&exitState.notifications.some(n=>n.type==='offer'&&n.offerId===exitState.offers[0].id),'requesting exit creates one immediate compatible proposal even for a low-overall player');const exitTarget=exitState.offers[0].club;exitTest.completeTransfer(0);assert(exitState.p.club===exitTarget&&exitState.p.club!=='Internacional'&&exitState.transfers.some(t=>t.from==='Internacional'&&t.to===exitTarget)&&exitState.notifications.some(n=>n.type==='transfer'),'exit proposal can be accepted and updates club, history and notification');const savedExit=JSON.parse(exitHarness.store.cc_v1_saves)[exitState.id];assert(savedExit.p.club===exitTarget&&savedExit.contract.wage===exitState.contract.wage&&savedExit.transfers.some(t=>t.to===exitTarget),'exit transfer persists in autosave');const reloadedExit=boot({cc_v1_saves:exitHarness.store.cc_v1_saves,cc_v1_active:exitState.id}).app.stateRef();assert(reloadedExit.p.club===exitTarget&&reloadedExit.contract.wage===exitState.contract.wage,'exit transfer survives save reload');

assert(html.includes('Você quer mesmo apagar essa carreira?')&&html.includes('SIM, APAGAR')&&html.includes('delete latest[id]'),'career deletion has explicit irreversible SIM/NÃO confirmation and removes only the selected save');assert(html.includes('SIM, TRANSFERIR')&&html.includes('function completeTransfer(i)'),'club transfer uses an explicit in-app confirmation and a dedicated completion path');
const htmlSource = require('fs').readFileSync(require('path').join(__dirname, '..', 'index.html'), 'utf8');
assert(htmlSource.includes("['customize','Camisa do jogador']"), 'player tab now presents only the shirt instead of appearance customization');
assert(!app.playerView().includes('data-appearance-save')&&!app.playerView().includes('data-appearance-reset'), 'appearance customization controls are removed from the interface');
assert(htmlSource.includes('function shirtOnlySvg(p,back=true)')&&!app.homeView().includes('avatarSvg('), 'shirt-only renderer replaces physical avatar presentation');

assert(htmlSource.includes('function kitInfo(p,type)')&&htmlSource.includes('function kitGarmentSvg(p,a)'), 'local structured kit database and realistic garment renderer exist');
assert(Object.keys(app.KIT_VERIFIED).sort().join('|')==='Flamengo|Palmeiras|São Paulo', 'only three clubs are marked as officially referenced, avoiding false verification claims');
assert([...app.BR_A,...app.BR_B].every(c=>app.KIT_STYLE[c[0]]), 'all 40 clubs have a distinct color/pattern profile');
const verifiedHome=app.kitInfo({club:'Palmeiras',number:10,appearance:{kitType:'home'}},'home');
const verifiedAway=app.kitInfo({club:'Palmeiras',number:10,appearance:{kitType:'away'}},'away');
assert(!verifiedHome.verified&&verifiedHome.manufacturer==='PUMA'&&verifiedHome.pattern==='palmeiras-home'&&!verifiedAway.verified&&verifiedAway.primary!==verifiedHome.primary, 'reference-derived profiles are not mislabelled as fully verified official kits');
const transferredKit=app.kitInfo({club:'Sport Recife',number:10,appearance:{kitType:'home'}},'home');
assert(transferredKit.club==='Sport Recife'&&!transferredKit.verified&&transferredKit.primary===app.KIT_STYLE['Sport Recife'][0], 'kit rendering follows the current club after transfer without claiming an unverified kit is official');
const renderedKit=app.kitGarmentSvg({club:'Flamengo',number:9,appearance:{kitType:'home'}},{...app.APPEARANCE_DEFAULTS,kitType:'home'});
assert(renderedKit.includes('assets/escudos/flamengo.svg')&&renderedKit.includes('kitBodyClip')&&renderedKit.includes('y=\"208\"'), 'shirt render uses local crest assets, clipped construction details, and a discreet shirt number');
assert(htmlSource.includes('Camisa do jogador')&&htmlSource.includes('Nº ${esc(p.number)}')&&htmlSource.includes('shirtOnlySvg(p,true)'), 'shirt-only screen binds the current player name and number to the shirt');

console.log(JSON.stringify({status:'PASS',careerCreation:true,careerSystems:true,attributeModel21:true,screenRenderChecks:15,homePartidasIndicator:true,homeStatsLiveBinding:true,profileOverallPreserved:true,realRosterRecords:720,rosterClubsCovered:40,rosterCoverageHonest:true,playerOnlyCareerEnforced:true,shirtNumberChecks:true,rivalTransferControlBlocked:true,occupiedShirtOwnerPreserved:true,rivalMoveMigrationReset:true,shirtNumberPersistence:true,coachConversation:true,lifePersonalActions:true,trainingLimit:true,roundsSimulated:38,leagueClubs:40,fixturesPerDivision:380,homeAwayBalance:true,dualLeagueSimulation:true,promotionRelegation:true,goalEventsChecked:totalGoalEvents,standingsConsistency:true,seasonRollover:true,legacyMigration:true,autosave:true,interactiveHalftime:true,interactiveDecisionIntegration:true,transferFlow:true,offerNotification:true,offerFrequencyScored:true,duplicateOffersBlocked:true,transferSavePersistence:true,requestExit:true,immediateExitOffer:true,exitTransferPersistence:true,matchDistributionChecked:500,strongTeamAdvantage:true}, null, 2));
