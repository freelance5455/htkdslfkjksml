## v1.22.8 — Menu inicial
- Criado menu inicial com “CRIAR NOVA CARREIRA” e “CONTINUAR CARREIRA”.
- “Continuar carreira” lista os saves existentes e permite retomar um deles sem apagar progresso.
- Adicionado acesso ao Instagram @guiii.__09.
- Adicionado botão para voltar ao menu inicial a partir da criação de carreira.

## v1.22.7 — Status pré-jogo e entrada no minuto da substituição
- Central de pré-jogo informa se o atleta será titular, reserva ou não relacionado.
- Para reservas, a partida avança até o minuto de entrada; a participação individual começa a partir desse momento.
- Titulares participam desde o início; não relacionados terminam sem minutos.

## v1.22.6 — Permanência mínima e propostas da Premier League
- O atleta precisa concluir uma temporada completa no clube atual antes de solicitar saída ou concluir uma transferência. A validação também ocorre ao confirmar a proposta, evitando contornar a regra por telas diferentes.
- Clubes da Premier League entram no mercado de propostas mesmo quando o jogador está em um clube brasileiro.
- Propostas da Premier League exigem mais reputação e desempenho; os grandes clubes exigem overall alto, sequência de jogos, participação direta em gols e boas notas.
- Propostas inglesas oferecem condições financeiras ajustadas ao mercado europeu.

## v1.22.5 — Brasileirão com avanço automático
- Removidos os controles “Simular rodada completa” e “Reiniciar esta Série”.
- Ao concluir uma partida da carreira, as rodadas correspondentes das Séries A e B avançam automaticamente, com resultados persistidos no aparelho.
- Acompanhar o Brasileirão não altera o resultado da partida do jogador.

## v1.22.4 — Brasileirão independente da carreira

- Brasil permanece acessível em LIGAS mesmo quando a carreira do jogador é na Inglaterra.
- Séries A e B têm calendário, resultados simulados, classificação e progresso salvos separadamente da carreira.
- Simular/reiniciar o Brasileirão não altera a carreira inglesa.
- Esta área simula os campeonatos localmente; resultados reais ao vivo exigem integração com uma API externa.

## v1.22.3 — Menu LIGAS reorganizado
- Removida a opção “Europa” da barra principal.
- Renomeada a opção “Brasileirão” para “LIGAS”.
- Criado menu por país: Brasil → Brasileirão A e B; Inglaterra → Premier League; demais ligas exibem “Dados do Jogador” e aviso de indisponibilidade.

## v1.22.2 — Cores das camisas inglesas
- Corrigidas as cores-base dos 20 clubes ingleses; cada uniforme usa a identidade cromática do próprio clube.
- Mantido o sistema de uniformes e a experiência dos clubes brasileiros.

## v1.22.2 — Escudos da Premier League
- Mapeados os 20 escudos ESPN fornecidos para os clubes ingleses.
- Mantidos transparentes, proporcionais e sem moldura.
- Observação: o carregamento dos escudos exige internet.

## v1.22.2 — Premier League jogável na carreira
- A criação de carreira permite escolher um dos 20 clubes ingleses da Premier League.
- A carreira inglesa recebe calendário próprio de 38 rodadas, classificação, jogos jogáveis no motor de partidas e persistência local.
- Elencos cadastrados da Premier League são usados para estimar a força dos adversários e identificar jogadores em eventos.
- O modo brasileiro Série A/B permanece separado e preservado.

# v1.20.1 — País e clube inicial

- Em Dados do Atleta, o campo Clube inicial agora é organizado por país: BRASIL, INGLATERRA, ESPANHA, FRANÇA, ALEMANHA e ITÁLIA.
- BRASIL lista os 40 clubes já cadastrados nas Séries A e B.
- INGLATERRA lista os 20 clubes da Premier League presentes na base europeia.
- Os clubes dos outros quatro países ficam sinalizados como “em breve”, para serem adicionados nas próximas atualizações.
- O país selecionado é salvo no cadastro inicial do atleta.
- A integração da temporada inglesa ao motor da carreira ainda será feita na atualização de Premier League jogável.

# v1.20.0 — Premier League jogável

- Adicionada base local de elencos da Premier League 2026/27 a partir das listas enviadas.
- Nova tabela de elenco por clube com camisa, posição e identificação visual de números repetidos.
- Mantidos calendário ida e volta, simulação por rodada, classificação e salvamento local já existentes.
- Preservada a tela pré-jogo e a estrutura das ligas brasileiras.
- Os dados de elenco são fornecidos pelo usuário e não foram verificados independentemente.

## v1.19.0 — Expansão Europeia inicial
- Adicionada a área Europa com Premier League (20 clubes), Serie A TIM (20), Bundesliga (18), LaLiga (20) e Ligue 1 (18), composição 2026/27.
- Calendário ida e volta gerado para cada liga, com 38 rodadas nas ligas de 20 clubes e 34 nas ligas de 18 clubes.
- Simulação de resultados por rodada, classificação automática e persistência local independente da carreira brasileira.
- Mantida a estrutura pré-jogo aprovada na v1.18.0.
- Limitação desta etapa: elencos completos licenciados, escudos e uniformes oficiais europeus ainda não foram integrados; não são apresentados como completos.

## v1.18.0 — Formação pré-jogo sem mistura
- Separação maior entre as duas equipes, cada uma na própria metade do campo.
- Campo mais alto e nomes/números ligeiramente maiores para melhorar a leitura no celular.
- Mantém 11 jogadores por equipe.

## v1.17.8 — Formação pré-jogo separada
- Corrigidas as coordenadas verticais da formação: cada equipe fica na própria metade do campo, com 11 posições por equipe e sem sobreposição entre as duas formações.

## v1.17.7 — Formação pré-jogo corrigida
- Separadas visualmente as duas escalações no campo, com 11 posições por equipe e sem sobreposição entre os jogadores.
- Ajustado o posicionamento vertical das equipes para mostrar um time em cada metade do campo.

## v1.17.6 — Escalações pré-jogo corrigidas
- Formação tática agora exibe 11 posições por equipe, em estrutura 4-3-3.
- Seleção automática prioriza jogadores disponíveis de cada posição e, em seguida, os melhores OVR restantes.
- O jogador da carreira aparece na posição mais compatível com sua posição cadastrada.
- Evita repetir o mesmo atleta na escalação.

## v1.17.5 — Camisa inicial automática
- Removido o campo “Camisa” da tela de criação em “Dados do atleta”.
- O jogo atribui automaticamente o primeiro número disponível de 1 a 99, priorizando os números preferenciais configurados, sem usar número já cadastrado no elenco do clube.

## v1.17.4 — Correção de números de camisa
- Bahia: Marco Moreno camisa 3; Gabriel Xavier movido para 14 para evitar duplicidade.
- Palmeiras: Arthur Gabriel 56, Maurício 18, Marlon Freitas 17, Andreas Pereira 8, Jhon Arias 11 e Paulinho 10.
- Vitória: Erick 33, Renê 91, Matheuzinho 10; Lucas Halter movido para 14 para evitar duplicidade.

# Changelog — v1.17.3

- Consolidação dos elencos dos 20 clubes da Série B com as listas Transfermarkt fornecidas pelo usuário em 26/10/2026.
- Números de camisa duplicados removidos por clube, priorizando a primeira ocorrência da lista.
- Para nomes separados por “/”, mantida apenas a primeira opção.
- Atualizados dados de elenco, fontes indicadas e data de referência no jogo e no arquivo JSON.
- Alguns clubes ficam com menos de 22 atletas porque a regra de prioridade remove entradas com numeração repetida; não foram inventados atletas para preencher vagas.

# v1.16.9 — Elenco Athletico-PR atualizado

- Atualizado o elenco do Athletico-PR com 21 atletas e numeração fornecida para 25/10/2026.
- Mantidos os demais sistemas e a estrutura da carreira.

# CHANGELOG

## v1.14.0 — Referências visuais reais de camisas 2026
- A prévia em JOGADOR → PERSONALIZAR pode exibir imagens de camisas reais hospedadas por páginas de referência/lojas, em vez de SVG genérico.
- Cada imagem tem origem registrada no manifesto e na interface.
- O catálogo cobre os 40 clubes e marca claramente os clubes sem imagem.
- As imagens são carregadas remotamente e exigem internet; não estão embutidas no ZIP porque a licença de redistribuição não foi confirmada.
- Não foram adicionadas vistas traseiras falsas nem reservas/terceiras genéricas.
- Saves, atributos, calendário, contratos e transferências não foram alterados.

# Changelog

## v1.12.0 — Catálogo visual de 40 clubes (2026)
- Expandido o catálogo de prévias vetoriais para os 40 clubes existentes no jogo.
- Adicionadas referências públicas de temporada e fornecedores, além de detalhes de design conhecidos.
- Patrocinadores só são exibidos quando identificados na referência consultada.
- Manifesto separa prévia vetorial de fotografia oficial: nenhuma foto oficial/licenciada foi incluída.
- Preservados carreira, progressão, campeonatos e saves.


## v1.16.7 — Diversidade de padrões de camisas
- A prévia traseira agora respeita o padrão cadastrado por clube, em vez de aplicar sempre quatro faixas horizontais.
- Adicionados padrões visuais distintos: camisa lisa/texturizada, faixas horizontais finas e múltiplas, listras verticais, faixa diagonal e painéis laterais.
- Refinadas escolhas de padrões para clubes como Vasco, Operário-PR, Vitória, Atlético-MG, Botafogo, Corinthians, Santos, Cruzeiro, Ponte Preta e Sport Recife.
- Nome e número seguem dinâmicos; cores continuam vindo do cadastro de cada uniforme. Nenhuma alteração intencional nos sistemas de carreira.


## v1.16.8 — Listras verticais ampliadas
- Corrigida a largura das listras verticais: agora alternam cores em faixas largas e contínuas, cobrindo o corpo da camisa de cima até a barra.
- Aplicado a padrões verticais comuns, múltiplas listras, tricolores, Fortaleza e Botafogo.
- Mantidos o molde, nome/número nas costas, demais padrões e sistemas do jogo.


## v1.17.0 — Elencos Série A (25/10/2026)
- Atualizados os 19 elencos enviados pelo usuário: Flamengo, Palmeiras, Corinthians, São Paulo, Santos, Cruzeiro, Atlético-MG, Grêmio, Internacional, Vasco, Fluminense, Botafogo, Remo, Chapecoense, Mirassol, Red Bull Bragantino, Bahia, Vitória e Coritiba.
- Mantido o elenco Athletico Paranaense já cadastrado na versão anterior.
- “Galo” consolidado como apelido do Atlético-MG, sem clube duplicado.
- Preservados os nomes, números e todos os jogadores listados; quando há números repetidos na lista recebida, eles são mantidos conforme informado.
