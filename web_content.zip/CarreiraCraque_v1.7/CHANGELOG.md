# v1.16.9 — Elenco Athletico-PR atualizado

- Atualizado o elenco do Athletico-PR com 21 atletas e numeração fornecida para 25/10/2026.
- Mantidos os demais sistemas e a estrutura da carreira.

# CHANGELOG

## v1.14.0 — Referências visuais reais de camisas 2026
- A prévia em JOGADOR → PERSONALIZAR pode exibir imagens de camisas reais hospedadas por páginas de referência/lojas, em vez de SVG genérico.
- Cada imagem tem origem registrada no manifesto e na interface.
- O catálogo cobre os 40 clubes e marca claramente os clubes sem imagem.
- As imagens são carregadas remotamente e exigem internet; não estão embutidas no ZIP porque a licença de redistribuição não foi confirmada.
- Não foram adicionadas vistas traseiras falsas nem reservas/terceiras genéricas.
- Saves, atributos, calendário, contratos e transferências não foram alterados.

# Changelog

## v1.12.0 — Catálogo visual de 40 clubes (2026)
- Expandido o catálogo de prévias vetoriais para os 40 clubes existentes no jogo.
- Adicionadas referências públicas de temporada e fornecedores, além de detalhes de design conhecidos.
- Patrocinadores só são exibidos quando identificados na referência consultada.
- Manifesto separa prévia vetorial de fotografia oficial: nenhuma foto oficial/licenciada foi incluída.
- Preservados carreira, progressão, campeonatos e saves.


## v1.16.7 — Diversidade de padrões de camisas
- A prévia traseira agora respeita o padrão cadastrado por clube, em vez de aplicar sempre quatro faixas horizontais.
- Adicionados padrões visuais distintos: camisa lisa/texturizada, faixas horizontais finas e múltiplas, listras verticais, faixa diagonal e painéis laterais.
- Refinadas escolhas de padrões para clubes como Vasco, Operário-PR, Vitória, Atlético-MG, Botafogo, Corinthians, Santos, Cruzeiro, Ponte Preta e Sport Recife.
- Nome e número seguem dinâmicos; cores continuam vindo do cadastro de cada uniforme. Nenhuma alteração intencional nos sistemas de carreira.


## v1.16.8 — Listras verticais ampliadas
- Corrigida a largura das listras verticais: agora alternam cores em faixas largas e contínuas, cobrindo o corpo da camisa de cima até a barra.
- Aplicado a padrões verticais comuns, múltiplas listras, tricolores, Fortaleza e Botafogo.
- Mantidos o molde, nome/número nas costas, demais padrões e sistemas do jogo.


## v1.17.0 — Elencos Série A (25/10/2026)
- Atualizados os 19 elencos enviados pelo usuário: Flamengo, Palmeiras, Corinthians, São Paulo, Santos, Cruzeiro, Atlético-MG, Grêmio, Internacional, Vasco, Fluminense, Botafogo, Remo, Chapecoense, Mirassol, Red Bull Bragantino, Bahia, Vitória e Coritiba.
- Mantido o elenco Athletico Paranaense já cadastrado na versão anterior.
- “Galo” consolidado como apelido do Atlético-MG, sem clube duplicado.
- Preservados os nomes, números e todos os jogadores listados; quando há números repetidos na lista recebida, eles são mantidos conforme informado.
