CGD V117 — SOCLE 5.0-D : SÉLECTION INTERACTIVE GALAXIE / CLUB

Cette étape ajoute la sélection interactive préalable à la prise de fonction.

Fonctionnalités :
- catalogue des 24 galaxies historiques, avec identifiant de sélection stable ;
- catalogue de 60 emplacements de clubs répartis sur cinq divisions de 12 ;
- sélection des 36 clubs réellement actifs au démarrage ;
- verrouillage des 12 emplacements de Ligue C jusqu'à l'activation de la division (saison 3) ;
- verrouillage des 12 emplacements de Ligue D jusqu'à l'activation de la division (saison 5) ;
- validation serveur logique côté moteur avant la création du profil de carrière ;
- prise en charge des modes Club, Club & International et Sans emploi ;
- aucune création anticipée de faux clubs dans les divisions et aucune modification des identifiants des clubs actifs.

NOTE SUR LE CATALOGUE : l'archive 5.0-C contient 36 objets-clubs actifs et 24 emplacements futurs représentés par les divisions C/D annoncées. Les noms et fiches détaillées des 24 futurs clubs ne figurent pas encore dans cette archive. L'interface les signale donc comme emplacements verrouillés, sans inventer leurs identités. Lors de l'activation réelle d'une division, les clubs réels injectés dans cette division deviennent sélectionnables.

Tests ajoutés :
- 24 galaxies et 60 emplacements comptabilisés ;
- 36 actifs et 24 verrouillés au démarrage ;
- saisons de déblocage 3 et 5 ;
- refus d'un club verrouillé ;
- validation d'un club actif et du mode sans emploi ;
- disponibilité des clubs après activation effective de la division.

Vérification : `npm test` depuis le dossier v117.
Résultat au moment de la livraison : 250 tests réussis, 0 échec.
