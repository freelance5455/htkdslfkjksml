# KidsViral Studio — versão semiautomática

Aplicação local com biblioteca de MP4, duração máxima de 5 minutos, agendamento persistente em SQLite e upload via YouTube Data API v3.

## Instalação

1. Instale Python 3.10+ e FFmpeg (com `ffprobe` no PATH).
2. Execute `pip install -r requirements.txt`.
3. No Google Cloud Console: crie projeto, ative **YouTube Data API v3**, configure OAuth consent screen e OAuth Client ID do tipo **Web application**. Adicione `http://127.0.0.1:8765/oauth/callback` como URI de redirecionamento autorizada. Para contas externas em modo teste, inclua seu e-mail nos usuários de teste.
4. Configure as variáveis de ambiente `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET` com os valores obtidos no Google Cloud. Opcional: `STUDIO_TZ=America/Sao_Paulo`.
5. Execute `python server.py` e abra `http://127.0.0.1:8765` no mesmo computador.
6. Em Configurações, clique em Conectar minha conta Google. Depois envie vídeos MP4 e agende as publicações.

## Observações importantes

- O servidor deve permanecer ligado. Para publicação 24h/7d, use uma máquina sempre ativa e configure inicialização automática; **não exponha o servidor diretamente à internet**.
- Publicação é feita como **pública** no horário programado. A API pode impor restrições a uploads de projetos não verificados, inclusive obrigar visibilidade privada. Consulte as regras e o processo de auditoria do YouTube.
- Todos os uploads são marcados como **feitos para crianças** (`selfDeclaredMadeForKids: true`). Use somente conteúdo próprio ou devidamente licenciado.
- A aplicação foi feita para **um único operador local**. Não inclui login multiusuário, criptografia de tokens em repouso, tratamento robusto de retomada de upload ou infraestrutura de produção.
- Falhas de upload ficam marcadas como `error` e não são reenviadas automaticamente, para evitar duplicações. Você pode reagendar.
- O YouTube pode consumir cotas por upload; as políticas e limites mudam. Verifique a cota no Google Cloud.
- O agendamento depende do fuso configurado no servidor, não do fuso do navegador.
- Não há garantia de visualizações ou viralização.
