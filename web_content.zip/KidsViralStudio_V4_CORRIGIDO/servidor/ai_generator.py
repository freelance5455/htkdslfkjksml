"""Optional OpenAI-powered children's video generator. Requires API key, Pillow and ffmpeg."""
import os, json, base64, subprocess, tempfile, math
from pathlib import Path
from PIL import Image, ImageOps, ImageDraw, ImageFont
import requests

API='https://api.openai.com/v1'
def call(path, payload, timeout=180):
 key=os.getenv('OPENAI_API_KEY','')
 if not key: raise RuntimeError('Configure OPENAI_API_KEY no servidor (a API é cobrada separadamente).')
 r=requests.post(API+path,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},json=payload,timeout=timeout)
 if not r.ok: raise RuntimeError('Falha na API de IA: '+r.text[:350])
 return r.json()
def generate(topic, directions, length, folder):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
 seconds=max(30,min(300,int(length)))
 scenes=max(3,min(8,math.ceil(seconds/40)))
 instruction=(f'Crie um vídeo educativo infantil original em português brasileiro sobre: {topic}. '
  f'Instruções do criador: {directions}. Duração alvo {seconds} segundos, {scenes} cenas. '
  'Estilo de animação infantil 3D pré-escolar com personagens humanos fictícios originais, cabeças arredondadas, olhos expressivos, cenários luminosos, formas suaves, cores vivas, sem copiar personagens, músicas, logotipos ou designs de canais existentes. Personagens devem manter as mesmas roupas, cabelos e características em todas as cenas. Seguro, gentil, sem sustos, violência, alegações enganosas, marcas ou personagens protegidos. '
  'Crie uma pequena bíblia visual descrevendo 2 a 4 personagens originais consistentes em character_bible (texto em inglês). Responda SOMENTE JSON com title (até 90 caracteres), description, scenes: lista de objetos com narration '
  '(texto simples, entre 30 e 65 palavras conforme duração) e image_prompt (em inglês, imagem horizontal 16:9, ilustração infantil colorida, sem texto). '
  'Narração deve ser educativa e conectar as cenas. Não inclua trilha musical protegida.')
 result=call('/chat/completions',{'model':os.getenv('OPENAI_TEXT_MODEL','gpt-4o-mini'),'response_format':{'type':'json_object'},'messages':[{'role':'system','content':'Você é roteirista especializado em conteúdo infantil seguro e educativo. Responda JSON válido.'},{'role':'user','content':instruction}]})
 plan=json.loads(result['choices'][0]['message']['content']); items=plan.get('scenes',[])[:scenes]
 if not items: raise RuntimeError('IA não retornou cenas.')
 segments=[]
 for idx,item in enumerate(items):
  prompt=('Original preschool 3D CGI animation still, friendly fictional children, vibrant toy-like world, rounded features, soft studio lighting, consistent recurring cast. Character bible: '+str(plan.get('character_bible',''))[:1200]+'. Scene: '+str(item.get('image_prompt','Colorful friendly children educational illustration'))[:1000]+'. No text, no logos, no copyrighted characters.')[:2400]
  img=call('/images/generations',{'model':os.getenv('OPENAI_IMAGE_MODEL','gpt-image-1'),'prompt':prompt,'size':'1536x1024','n':1},timeout=240)
  entry=img['data'][0]
  if 'b64_json' in entry: data=base64.b64decode(entry['b64_json'])
  elif 'url' in entry:
   rr=requests.get(entry['url'],timeout=90);rr.raise_for_status();data=rr.content
  else:raise RuntimeError('Imagem não retornada pela IA')
  source=folder/f'image_{idx}.png';source.write_bytes(data)
  im=Image.open(source).convert('RGB');im=ImageOps.fit(im,(1280,720),method=Image.Resampling.LANCZOS)
  image_path=folder/f'frame_{idx}.jpg';im.save(image_path,quality=90)
  speech=requests.post(API+'/audio/speech',headers={'Authorization':'Bearer '+os.environ['OPENAI_API_KEY']},json={'model':os.getenv('OPENAI_TTS_MODEL','tts-1'),'voice':'nova','input':str(item.get('narration',''))[:4000],'response_format':'mp3'},timeout=180)
  if not speech.ok:raise RuntimeError('Erro de narração: '+speech.text[:250])
  audio=folder/f'voice_{idx}.mp3';audio.write_bytes(speech.content)
  part=folder/f'part_{idx}.mp4'
  cmd=['ffmpeg','-y','-loop','1','-framerate','25','-i',str(image_path),'-i',str(audio),'-c:v','libx264','-preset','veryfast','-tune','stillimage','-c:a','aac','-b:a','128k','-pix_fmt','yuv420p','-vf','scale=1280:720,zoompan=z=min(zoom+0.0005\\,1.10):d=1:s=1280x720:fps=25','-shortest','-movflags','+faststart',str(part)]
  subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=240)
  segments.append(part)
 concat=folder/'concat.txt';concat.write_text(''.join("file '"+str(p).replace("'","'\\''")+"'\n" for p in segments))
 final=folder/'video.mp4'
 subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(final)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,timeout=240)
 return {'path':str(final),'title':str(plan.get('title',topic))[:100],'description':str(plan.get('description',''))[:5000],'scenes':len(items)}
