"""KidsViral Studio: local single-user YouTube scheduler (Python 3.10+)."""
import os, json, sqlite3, secrets, threading, time, subprocess, shutil, mimetypes
from pathlib import Path
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from urllib.parse import urlencode, urlparse, parse_qs
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import requests

BASE=Path(__file__).resolve().parent
DATA=BASE/'data'; UPLOADS=DATA/'uploads'; DATA.mkdir(exist_ok=True); UPLOADS.mkdir(exist_ok=True)
DB=DATA/'studio.sqlite3'; PORT=int(os.getenv('PORT','8765')); HOST=os.getenv('HOST','127.0.0.1')
CLIENT_ID=os.getenv('GOOGLE_CLIENT_ID',''); CLIENT_SECRET=os.getenv('GOOGLE_CLIENT_SECRET','')
REDIRECT=f'http://127.0.0.1:{PORT}/oauth/callback'; TZ=os.getenv('STUDIO_TZ','America/Sao_Paulo')
MAX_BYTES=500*1024*1024
lock=threading.Lock(); oauth_states=set(); ai_jobs={}; ai_lock=threading.Lock()
def connect():
 c=sqlite3.connect(DB,timeout=30); c.row_factory=sqlite3.Row; return c
def init():
 with connect() as c:
  c.execute('CREATE TABLE IF NOT EXISTS videos (id TEXT PRIMARY KEY, filename TEXT, title TEXT, description TEXT, category TEXT, duration REAL, status TEXT, scheduled_at TEXT, youtube_id TEXT, error TEXT, created_at TEXT)')
  c.execute('CREATE TABLE IF NOT EXISTS secrets (name TEXT PRIMARY KEY, value TEXT)')
def secret_get(k):
 with connect() as c:
  r=c.execute('SELECT value FROM secrets WHERE name=?',(k,)).fetchone(); return r['value'] if r else None
def secret_set(k,v):
 with connect() as c:c.execute('INSERT OR REPLACE INTO secrets VALUES (?,?)',(k,v))
def json_bytes(obj):return json.dumps(obj,ensure_ascii=False).encode()
def probe(path):
 if not shutil.which('ffprobe'): raise ValueError('Instale ffmpeg/ffprobe para validar a duração no servidor.')
 p=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)],capture_output=True,text=True,timeout=30)
 try:duration=float(p.stdout.strip())
 except:raise ValueError('Arquivo de vídeo inválido ou ilegível.')
 if not 0<duration<=300:raise ValueError('O vídeo deve ter entre 1 segundo e 5 minutos.')
 return duration
def token():
 raw=secret_get('google_token')
 if not raw:raise ValueError('Conecte sua conta YouTube primeiro.')
 t=json.loads(raw)
 if time.time()>t.get('expires_at',0)-120:
  r=requests.post('https://oauth2.googleapis.com/token',data={'client_id':CLIENT_ID,'client_secret':CLIENT_SECRET,'refresh_token':t.get('refresh_token'),'grant_type':'refresh_token'},timeout=30);r.raise_for_status()
  new=r.json();t['access_token']=new['access_token'];t['expires_at']=time.time()+new.get('expires_in',3600);secret_set('google_token',json.dumps(t))
 return t['access_token']
def youtube_upload(v):
 path=UPLOADS/v['filename']; access=token()
 meta={'snippet':{'title':v['title'],'description':v['description'],'categoryId':'1'},'status':{'privacyStatus':'public','selfDeclaredMadeForKids':True}}
 size=path.stat().st_size
 r=requests.post('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',headers={'Authorization':'Bearer '+access,'Content-Type':'application/json; charset=UTF-8','X-Upload-Content-Length':str(size),'X-Upload-Content-Type':'video/mp4'},json=meta,timeout=60)
 r.raise_for_status();url=r.headers.get('Location')
 if not url:raise ValueError('YouTube não retornou sessão de upload.')
 # Resumable session; single request for small files. No arbitrary external URLs used.
 if not url.startswith('https://www.googleapis.com/') and not url.startswith('https://youtube.googleapis.com/'):
  raise ValueError('URL de upload inesperada.')
 with path.open('rb') as f:
  response=requests.put(url,data=f,headers={'Content-Type':'video/mp4','Content-Length':str(size)},timeout=1200)
 response.raise_for_status();return response.json()['id']
def worker():
 while True:
  try:
   now=datetime.now(timezone.utc).isoformat()
   with lock:
    with connect() as c:
     v=c.execute("SELECT * FROM videos WHERE status='scheduled' AND scheduled_at<=? ORDER BY scheduled_at LIMIT 1",(now,)).fetchone()
     if v:c.execute("UPDATE videos SET status='uploading',error='' WHERE id=?",(v['id'],))
   if v:
    try:
     yt=youtube_upload(v)
     with connect() as c:c.execute("UPDATE videos SET status='published',youtube_id=? WHERE id=?",(yt,v['id']))
    except Exception as e:
     with connect() as c:c.execute("UPDATE videos SET status='error',error=? WHERE id=?",(str(e)[:400],v['id']))
  except Exception as e:print('Worker:',e)
  time.sleep(15)
def ai_work(job_id, topic, directions, length):
 from ai_generator import generate
 folder=DATA/'ai_jobs'/job_id
 try:
  with ai_lock:ai_jobs[job_id]['status']='generating'
  result=generate(topic,directions,length,folder)
  duration=probe(result['path'])
  name=job_id+'.mp4';shutil.copy2(result['path'],UPLOADS/name)
  with connect() as c:c.execute('INSERT INTO videos VALUES (?,?,?,?,?,?,?,?,?,?,?)',(job_id,name,result['title'],result['description'],'Gerado por IA',duration,'draft',None,None,None,datetime.now(timezone.utc).isoformat()))
  with ai_lock:ai_jobs[job_id].update(status='ready',title=result['title'],duration=duration)
 except Exception as e:
  with ai_lock:ai_jobs[job_id].update(status='error',error=str(e)[:500])
 finally:
  shutil.rmtree(folder,ignore_errors=True)

class Handler(BaseHTTPRequestHandler):
 def reply(self,status,data):
  b=json_bytes(data);self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(b)
 def error(self,msg,status=400):self.reply(status,{'error':str(msg)})
 def body(self):
  n=int(self.headers.get('Content-Length','0'))
  if n>MAX_BYTES:self.error('Arquivo muito grande',413);return None
  return self.rfile.read(n)
 def do_GET(self):
  u=urlparse(self.path)
  if u.path=='/':
   b=(BASE/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b);return
  if u.path=='/api/health':
   self.reply(200,{'ok':True,'ai_key_configured':bool(os.getenv('OPENAI_API_KEY')),'ffmpeg_installed':bool(shutil.which('ffmpeg')),'ffprobe_installed':bool(shutil.which('ffprobe')),'generator_ready':bool(os.getenv('OPENAI_API_KEY') and shutil.which('ffmpeg') and shutil.which('ffprobe'))});return
  if u.path=='/api/ai/jobs':
   with ai_lock: jobs=list(ai_jobs.values())
   self.reply(200,{'jobs':jobs[-30:],'enabled':bool(os.getenv('OPENAI_API_KEY'))});return
  if u.path=='/api/videos':
   with connect() as c:rows=[dict(x) for x in c.execute('SELECT * FROM videos ORDER BY created_at DESC')]
   self.reply(200,{'videos':rows,'connected':bool(secret_get('google_token')),'oauth_configured':bool(CLIENT_ID and CLIENT_SECRET),'timezone':TZ});return
  if u.path=='/oauth/start':
   if not CLIENT_ID or not CLIENT_SECRET:return self.error('Configure GOOGLE_CLIENT_ID e GOOGLE_CLIENT_SECRET')
   state=secrets.token_urlsafe(32);oauth_states.add(state)
   q=urlencode({'client_id':CLIENT_ID,'redirect_uri':REDIRECT,'response_type':'code','scope':'https://www.googleapis.com/auth/youtube.upload','access_type':'offline','prompt':'consent','state':state})
   self.send_response(302);self.send_header('Location','https://accounts.google.com/o/oauth2/v2/auth?'+q);self.end_headers();return
  if u.path=='/oauth/callback':
   q=parse_qs(u.query);state=q.get('state',[''])[0]
   if state not in oauth_states:return self.error('Estado OAuth inválido')
   oauth_states.remove(state)
   if 'code' not in q:return self.error(q.get('error',['Autorização cancelada'])[0])
   try:
    r=requests.post('https://oauth2.googleapis.com/token',data={'code':q['code'][0],'client_id':CLIENT_ID,'client_secret':CLIENT_SECRET,'redirect_uri':REDIRECT,'grant_type':'authorization_code'},timeout=30);r.raise_for_status();t=r.json();t['expires_at']=time.time()+t.get('expires_in',3600)
    secret_set('google_token',json.dumps(t));self.send_response(302);self.send_header('Location','/?connected=1');self.end_headers()
   except Exception as e:self.error(e)
   return
  self.error('Rota não encontrada',404)
 def do_POST(self):
  u=urlparse(self.path)
  try:
   if u.path=='/api/upload':
    import cgi
    ct=self.headers.get('Content-Type','')
    if 'multipart/form-data' not in ct:return self.error('Envie multipart/form-data')
    length=int(self.headers.get('Content-Length','0'))
    if length<=0 or length>MAX_BYTES:return self.error('Arquivo excede 500 MB',413)
    # cgi.FieldStorage handles multipart streaming; only local single-user service.
    form=cgi.FieldStorage(fp=self.rfile,headers=self.headers,environ={'REQUEST_METHOD':'POST','CONTENT_TYPE':ct,'CONTENT_LENGTH':str(length)})
    f=form['video'] if 'video' in form else None
    if f is None or not getattr(f,'file',None):return self.error('Selecione um vídeo')
    title=str(form.getfirst('title','')).strip()[:100];desc=str(form.getfirst('description',''))[:5000];category=str(form.getfirst('category','Histórias'))[:60]
    if not title:return self.error('Informe o título')
    ident=secrets.token_hex(12);name=ident+'.mp4';path=UPLOADS/name
    try:
     with path.open('wb') as out:shutil.copyfileobj(f.file,out)
     duration=probe(path)
    except Exception:
     path.unlink(missing_ok=True);raise
    with connect() as c:c.execute('INSERT INTO videos VALUES (?,?,?,?,?,?,?,?,?,?,?)',(ident,name,title,desc,category,duration,'draft',None,None,None,datetime.now(timezone.utc).isoformat()))
    self.reply(200,{'id':ident,'duration':duration});return
   data=self.body()
   if data is None:return
   obj=json.loads(data or b'{}')
   if u.path=='/api/ai/create':
    topic=str(obj.get('topic','')).strip()[:250]
    directions=str(obj.get('directions','')).strip()[:1200]
    length=int(obj.get('length',90))
    if not topic:return self.error('Descreva sobre o que é o vídeo.')
    if not 30<=length<=300:return self.error('Duração permitida: 30 a 300 segundos.')
    if not os.getenv('OPENAI_API_KEY'):return self.error('Configure OPENAI_API_KEY no servidor. A geração usa API paga.')
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):return self.error('Instale ffmpeg e ffprobe no servidor.')
    with ai_lock:
     if sum(j['status']=='generating' for j in ai_jobs.values())>=1:return self.error('Aguarde o vídeo atual terminar.')
     ident=secrets.token_hex(12);ai_jobs[ident]={'id':ident,'topic':topic,'status':'generating','created_at':datetime.now(timezone.utc).isoformat()}
    threading.Thread(target=ai_work,args=(ident,topic,directions,length),daemon=True).start()
    self.reply(202,{'id':ident,'status':'generating'});return
   if u.path=='/api/schedule':
    ident=obj.get('id');local=obj.get('datetime')
    dt=datetime.fromisoformat(local)
    if dt.tzinfo is None:dt=dt.replace(tzinfo=ZoneInfo(TZ))
    utc=dt.astimezone(timezone.utc)
    if utc<=datetime.now(timezone.utc):return self.error('Escolha um horário futuro')
    with connect() as c:
     cur=c.execute("UPDATE videos SET scheduled_at=?,status='scheduled',error=NULL WHERE id=? AND status IN ('draft','scheduled','error')",(utc.isoformat(),ident))
     if not cur.rowcount:return self.error('Vídeo indisponível para agendar')
    self.reply(200,{'ok':True});return
   if u.path=='/api/delete':
    with connect() as c:
     row=c.execute('SELECT * FROM videos WHERE id=?',(obj.get('id'),)).fetchone()
     if not row or row['status']=='uploading':return self.error('Não é possível excluir este vídeo')
     c.execute('DELETE FROM videos WHERE id=?',(row['id'],))
    (UPLOADS/row['filename']).unlink(missing_ok=True);self.reply(200,{'ok':True});return
   if u.path=='/api/disconnect':secret_set('google_token','');self.reply(200,{'ok':True});return
   self.error('Rota não encontrada',404)
  except Exception as e:self.error(str(e))
if __name__=='__main__':
 init();threading.Thread(target=worker,daemon=True).start()
 print(f'KidsViral Studio: http://127.0.0.1:{PORT} (timezone {TZ})')
 ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
