# KidsViral Studio — pacote unificado Android + site + servidor

Este ZIP contém o **projeto Android para compilar um APK** e o **site com backend Python**. Não é um APK pronto, nem pode ser convertido em APK apenas renomeando o ZIP.

## Pastas
- `android/`: projeto Gradle para abrir no Android Studio e gerar APK.
- `servidor/`: painel web, API, banco SQLite, upload MP4 e agendador de vídeos.

## Gerar o APK
1. Descompacte o ZIP.
2. Abra a pasta `android` no Android Studio (JDK 17, Android SDK 35).
3. Use **Build > Build APK(s)**.
4. O APK debug estará em `android/app/build/outputs/apk/debug/app-debug.apk`.

## Servidor
1. Instale Python 3.10+, ffmpeg/ffprobe.
2. Na pasta `servidor`, execute `pip install -r requirements.txt`.
3. Configure `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET` para OAuth do YouTube.
4. Execute `python server.py` e abra `http://127.0.0.1:8765` **no computador que executa o servidor**.

## Limitações importantes
- O APK é um cliente WebView. **Não** contém servidor Python e não publica vídeos por conta própria.
- O backend incluído é **somente para uso local**. Não exponha à internet: ainda não tem autenticação, HTTPS nem OAuth remoto.
- Para usar o APK em celular, é necessário implantar uma versão segura do backend em HTTPS e ajustar a URL de redirecionamento OAuth.
- Uploads e publicações precisam ser testados com conta Google real; o YouTube pode impor verificação e limites de cota.
- O site organiza e agenda vídeos enviados pelo usuário; não gera vídeos automaticamente nem garante viralização.
- Vídeos infantis devem respeitar direitos autorais e a classificação **feito para crianças**.

## NOVO: GERADOR DE VÍDEOS COM IA
Na aba "Criar com IA", informe apenas o assunto e como quer o vídeo. O servidor usa a API da OpenAI para roteiro, imagens e narração e o FFmpeg para montar o MP4. É um recurso REAL, mas exige configuração e uso pago de API.

Instale as dependências de `servidor/requirements.txt` e o programa FFmpeg (com ffprobe). Defina a variável de ambiente `OPENAI_API_KEY` **somente no servidor**. Não coloque a chave no HTML ou APK. Inicie `python server.py`, abra a aba "Criar com IA", descreva o vídeo e clique em gerar. Quando terminar, ele aparecerá na biblioteca para revisão e agendamento. O resultado é uma sequência de ilustrações narradas, não uma animação 3D contínua. A duração real depende da fala gerada e é validada pelo servidor (até 300 segundos); vídeos acima do limite não entram na biblioteca. Geração pode consumir créditos mesmo quando falhar.

O projeto Android é um cliente WebView; o servidor e a geração por IA não são executados dentro do APK. Para acesso fora do computador, implante um backend seguro com autenticação e HTTPS. A configuração de OAuth existente foi concebida para localhost e exige ajustes para produção. Nunca exponha o servidor local diretamente à internet.
