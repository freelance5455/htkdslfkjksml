# Correção do erro “Failed to fetch”

O erro significa que o navegador não conseguiu acessar a API do servidor. Não é necessariamente um problema da chave da IA.

## Executar localmente (computador)

1. Instale Python 3.10–3.12, FFmpeg e FFprobe.
2. No terminal, entre em `servidor` e instale `pip install -r requirements.txt`.
3. Configure a variável de ambiente `OPENAI_API_KEY` no servidor, nunca no HTML ou APK. A API tem custos.
4. Execute `python server.py`.
5. Abra **http://127.0.0.1:8765** no navegador desse mesmo computador.
6. Acesse **http://127.0.0.1:8765/api/health** para conferir a configuração.

## Android / APK

Abrir `index.html` diretamente, ou empacotá-lo num APK offline, NÃO executa o servidor Python. `127.0.0.1` no celular é o próprio celular, não o computador. Para funcionar fora do computador, hospede o servidor em um ambiente seguro com HTTPS e autenticação, ajuste OAuth para o domínio e configure o aplicativo para esse endereço. **Não exponha este servidor local diretamente à internet**, pois ainda não possui autenticação de usuário.

Esta atualização melhora diagnóstico e mensagens. Não transforma o site em gerador offline nem valida a geração paga de ponta a ponta.
