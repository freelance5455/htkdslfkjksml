# KidsViral Studio — projeto Android

Este é o **código-fonte de um aplicativo Android**, ainda não é um APK compilado.

## Como gerar APK

1. Abra esta pasta como projeto no Android Studio (com JDK 17 e Android SDK 35).
2. Aguarde a sincronização Gradle (Android Gradle Plugin 8.7.3).
3. Escolha Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Instale o arquivo gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Como conectar

O app pede um endereço **HTTPS** para o servidor KidsViral Studio V2. A versão anterior do servidor opera apenas em `127.0.0.1`, sem autenticação multiusuário, portanto **não a exponha diretamente à internet**. Antes de conectar, implante o backend com autenticação, proxy HTTPS e configuração OAuth apropriada. O app é uma interface WebView e **não executa uploads agendados sozinho**.

## Limitações

Não foi possível compilar/testar um APK neste ambiente porque o Android SDK/Gradle não estão instalados. Este projeto fornece o código para compilação. O fluxo OAuth do backend usa redirecionamento local e precisa ser adaptado para um domínio HTTPS antes do uso remoto. A segurança do servidor e a integração real com YouTube precisam ser testadas.
