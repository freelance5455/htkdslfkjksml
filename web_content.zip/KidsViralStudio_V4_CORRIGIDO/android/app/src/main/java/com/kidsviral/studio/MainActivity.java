package com.kidsviral.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView browser;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_FILES = 2001;
    private String serverUrl;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        serverUrl = getPreferences(MODE_PRIVATE).getString("server", "");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Button settings = new Button(this);
        settings.setText("Configurar endereço do servidor");
        root.addView(settings);
        browser = new WebView(this);
        root.addView(browser, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        WebSettings web = browser.getSettings();
        web.setJavaScriptEnabled(true);
        web.setDomStorageEnabled(true);
        web.setAllowFileAccess(false);
        web.setAllowContentAccess(true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && uri.getHost() != null && serverUrl.startsWith("https://") && uri.getHost().equals(Uri.parse(serverUrl).getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { Toast.makeText(MainActivity.this,"Não foi possível abrir o link",Toast.LENGTH_SHORT).show(); }
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("video/mp4");
                try { startActivityForResult(intent, PICK_FILES); return true; }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
            }
        });
        settings.setOnClickListener(v -> configure());
        if (serverUrl.isEmpty()) configure(); else browser.loadUrl(serverUrl);
    }
    private void configure() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://seu-servidor.com");
        input.setText(serverUrl);
        new AlertDialog.Builder(this).setTitle("Servidor KidsViral Studio")
            .setMessage("Informe o endereço HTTPS do servidor configurado com o KidsViral Studio. Não use localhost do computador.")
            .setView(input).setPositiveButton("Conectar", (d, w) -> {
                String url = input.getText().toString().trim();
                Uri parsed = Uri.parse(url);
                if (!"https".equals(parsed.getScheme()) || parsed.getHost() == null) {
                    Toast.makeText(this, "Use um endereço HTTPS válido", Toast.LENGTH_LONG).show(); return;
                }
                serverUrl = url;
                getPreferences(MODE_PRIVATE).edit().putString("server", url).apply();
                browser.loadUrl(url);
            }).setNegativeButton("Cancelar", null).show();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILES && fileCallback != null) {
            Uri[] files = resultCode == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(files);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (browser.canGoBack()) browser.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { browser.destroy(); super.onDestroy(); }
}
