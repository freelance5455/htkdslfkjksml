# KidsViral Studio V3 — IA infantil 3D + YouTube

## Incluído
- Painel web responsivo com upload MP4 e biblioteca
- Gerador de episódios: tema + instruções + duração de 1 a 5 minutos
- Roteiro em português, imagens 3D originais de personagens fictícios, narração sintética e montagem MP4 com leve movimento de câmera
- Agendamento de 1 a 10 vídeos por dia e publicação pelo servidor via YouTube Data API
- Projeto Android WebView para compilar em APK

## Limitações importantes
- **Não é um APK pronto**: o projeto Android precisa ser compilado.
- **Não é animação 3D de personagens com movimentos labiais ou dança**: é vídeo de cenas ilustradas em estilo 3D, com voz e movimento de câmera.
- **Não cria música automaticamente**; não usa músicas ou personagens do CoComelon.
- Geração depende de chave OpenAI API paga, internet, Pillow, requests e FFmpeg.
- A publicação depende da configuração OAuth do Google Cloud, da autorização do canal, de cotas/restrições e de um servidor ligado.
- O servidor é local, sem autenticação web. **Não exponha diretamente na internet**. Para hospedagem pública, implemente autenticação, HTTPS, proteção de tokens, controle de custos e persistência de tarefas.
- Os vídeos devem ser revisados antes da publicação e corretamente marcados como feitos para crianças.

## Instalar servidor
1. Instale Python 3.10+, ffmpeg e ffprobe.
2. Entre na pasta `servidor`.
3. `python -m pip install -r requirements.txt`
4. Configure `OPENAI_API_KEY` em variável de ambiente para gerar vídeos.
5. Configure `GOOGLE_CLIENT_ID` e `GOOGLE_CLIENT_SECRET` para conectar YouTube.
6. `python server.py`
7. Abra http://127.0.0.1:8765

O projeto Android está na pasta `android`; consulte o README de lá.
