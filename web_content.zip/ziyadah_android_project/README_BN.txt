ZIYADAH HISAB Android Project

এই অ্যাপে ব্যবহারকারীর দেওয়া মূল ZIYADAH FOUNDATION লোগো অপরিবর্তিতভাবে app header, login screen এবং launcher icon-এ রাখা হয়েছে।

সুবিধা:
- সদস্য তালিকা ও মাসিক চাঁদা গ্রহণ
- মানবকল্যাণ অনুদান আলাদা হিসাব
- অসহায় মানুষকে সহায়তার নাম/ধরন/ব্যয় নথি
- আয়-ব্যয়ের খাতভিত্তিক মাসিক রিপোর্ট
- CSV রিপোর্ট, JSON ব্যাকআপ/রিস্টোর
- প্রথমবার পাসওয়ার্ড সেট ও অ্যাপ লক

APK build:
Android Studio-তে এই প্রজেক্ট ফোল্ডার Open করুন, SDK Platform 35 install হতে দিন, তারপর Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন। APK app/build/outputs/apk/debug/app-debug.apk-এ পাওয়া যাবে।

এই রানটাইমে Android SDK এবং Gradle ইনস্টল নেই; তাই সরাসরি APK কম্পাইল করা যায়নি। পাসওয়ার্ডটি অ্যাপের basic screen lock, ডেটা encryption নয়। এটি অফলাইন এবং একই ডিভাইসে local storage ব্যবহার করে। নিয়মিত JSON backup রাখুন।
