STOCK MANAGER PREMIUM - RD EDITZ (CATEGORY UPDATE)
===================================================

අලුත් Category පහසුකම්:
- භාණ්ඩයක් Add/Edit කරන විට Category එකක් තෝරාගත හැක.
- ආහාර, බීම, සබන් සහ පෞද්ගලික සත්කාර, පිරිසිදු කිරීමේ ද්‍රව්‍ය, ගෘහ භාණ්ඩ, ලිපි ද්‍රව්‍ය සහ වෙනත් යන Categories ඇත.
- භාණ්ඩ ලැයිස්තුවේ Category එක පෙන්වයි.
- Search box එකෙන් භාණ්ඩ නමෙන් හෝ Category නමෙන් සෙවිය හැක.
- Category filter එකෙන් තෝරාගත් වර්ගයේ භාණ්ඩ පමණක් පෙන්විය හැක.
- Excel Template එකට Category තීරුව එකතු කර ඇත. Excel Upload එකේ Category heading එක තිබේ නම් එයද Import වේ.
- පැරණි භාණ්ඩවල Category එකක් නොමැති නම් "වෙනත්" ලෙස පෙන්වයි.

පෙර පහසුකම්:
- මිලදී ගත් ඒකක මිල සහ විකුණුම් ඒකක මිල.
- Stock මිලදී ගැනීමේදී ප්‍රමාණය ස්වයංක්‍රීයව වැඩි වේ.
- විකුණුමක් සටහන් කළ විට Stock ස්වයංක්‍රීයව අඩු වේ.
- Dashboard එකේ මුළු Purchase, Sales, Profit සහ Stock Cost.
- Excel/CSV Upload සහ Backup/Restore.

ආරම්භය:
1. ZIP Extract කරන්න.
2. Stock_Manager_Premium_Offline folder එක open කරන්න.
3. index.html Chrome හෝ Edge Browser එකෙන් open කරන්න.

දත්ත Browser Local Storage තුළ සුරැකේ. Browser data clear නොකරන්න; නිතර Backup ගන්න.


ANDROID APK සටහන (වැදගත්)
-------------------------
මෙම ZIP එකේ Excel Template Download සහ Backup Download දැන් Android Share
Sheet එකට ගොනුව යැවීමට උත්සාහ කරයි. එතැනින් "Save to device" / "Files"
තෝරාගත හැක. Chrome Browser එකේදී සාමාන්‍ය Download ක්‍රමය භාවිතා වේ.

නමුත් APK එක සෑදූ WebView/Website-to-APK converter එකේ පහත පහසුකම්
සක්‍රීය නොකර ඇත්නම් ZIP එකේ HTML/JavaScript පමණක් වෙනස් කර Excel file
picker හෝ APK download එක සම්පූර්ණයෙන් සකස් කළ නොහැක:
1. File chooser / Upload files permission (WebChromeClient onShowFileChooser)
2. Download handling / DownloadListener සහ Android storage/share support
3. JavaScript සහ DOM storage (localStorage) enabled

ඒ නිසා APK maker එකේ "File Upload", "File Download", "JavaScript",
"DOM Storage" යන options තිබේ නම් ON කරන්න. File Upload සඳහා Android
Photos/Files permission ඉල්ලූ විට Allow කරන්න.

දත්ත ආරක්ෂාව:
- App data clear / uninstall කළහොත් local data මැකිය හැක.
- නිතර Backup ගෙන Files තුළ වෙනම තැනක තබාගන්න.
