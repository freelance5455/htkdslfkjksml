# دليل النشر على VPS (خطوة بخطوة)

> الأوامر تشتغل على Ubuntu 22.04 / 24.04 (أو Debian 12). تقدر تنفّذها من الجوال عبر **Termux** (`pkg install openssh`) أو من أي كمبيوتر.

## 0) المتطلبات
- VPS صغير (1 vCPU / 1GB RAM يكفي) بنظام Ubuntu.
- دومين أو دومين فرعي، مثل `osint.example.com`.
- ملف المشروع `osint-hub-server.zip`.

## 1) وجّه الدومين للسيرفر
في لوحة الدومين أضف سجل **A**: `osint` ← IP السيرفر. (انتظر دقائق لين ينتشر.)

## 2) تأمين السيرفر (مرة وحدة)
```bash
ssh root@IP_السيرفر
adduser deploy && usermod -aG sudo deploy          # مستخدم عادي بدل root
rsync --archive --chown=deploy:deploy ~/.ssh /home/deploy   # ينسخ مفتاح SSH للمستخدم الجديد
```
افتح جلسة ثانية **قبل ما تقفل الأولى** وتأكد إن `ssh deploy@IP` يدخل بالمفتاح، بعدها:
```bash
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/; s/^#\?PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config
sudo systemctl restart ssh
sudo apt update && sudo apt -y upgrade && sudo apt -y install ufw fail2ban unattended-upgrades
sudo ufw allow OpenSSH && sudo ufw allow 80/tcp && sudo ufw allow 443/tcp && sudo ufw allow 443/udp && sudo ufw --force enable
sudo dpkg-reconfigure -plow unattended-upgrades
```

## 3) تثبيت Docker
```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER && newgrp docker
docker --version && docker compose version
```

## 4) رفع المشروع
من جهازك (أو Termux):
```bash
scp osint-hub-server.zip deploy@IP_السيرفر:~
```
على السيرفر:
```bash
sudo apt -y install unzip
unzip osint-hub-server.zip -d osint-hub && cd osint-hub
```

## 5) الإعدادات
```bash
cp .env.example .env && nano .env
```
- `DOMAIN` = دومينك.
- `ADMIN_USER` = اسم الأدمن.
- `ADMIN_PASS` اتركه **فاضي** ليتولّد باسورد عشوائي قوي (الأفضل).

## 6) التشغيل
```bash
docker compose up -d --build
docker compose ps                     # كل الخدمات لازم تكون Up / healthy
docker compose logs app | grep -i "admin"
```
راح تلقى سطر: `GENERATED ADMIN PASSWORD (shown once...)` — انسخ الباسورد الحين (ما يظهر مرة ثانية).
Caddy يجيب شهادة HTTPS تلقائيًا من Let's Encrypt (يحتاج المنفذين 80 و443 مفتوحين والدومين موجّه صح).

## 7) أول دخول (مهم)
1. افتح `https://دومينك` وادخل بالأدمن.
2. تبويب **ACCOUNT** ← غيّر الباسورد لباسورد من عندك (مدير كلمات مرور).
3. فعّل **2FA**: أضف المفتاح في Google Authenticator / Aegis / 2FAS، أكّد بالرمز، و**احفظ رموز الاسترجاع الثمانية** خارج السيرفر.
4. احذف `ADMIN_PASS` من `.env` (لو كتبته) ثم `docker compose up -d`.

## 8) النسخ الاحتياطي (يوميًا)
```bash
crontab -e
```
أضف:
```cron
0 3 * * * cd /home/deploy/osint-hub && docker compose exec -T app node scripts/backup.js >> backup.log 2>&1
```
النسخ تنحفظ داخل الحاوية في `/data/backups` (آخر 14 نسخة). **انسخها خارج السيرفر** أسبوعيًا على الأقل:
```bash
docker compose cp app:/data/backups ./backups
# من جهازك:  scp -r deploy@IP:~/osint-hub/backups ./
```

### الاستعادة من نسخة
```bash
docker compose stop app
docker compose run --rm --no-deps -v "$PWD/backups:/restore:ro" app sh -c "cp /restore/osint-XXXX.db /data/osint.db && rm -f /data/osint.db-wal /data/osint.db-shm"
docker compose start app
```

## 9) صيانة يومية
| المهمة | الأمر |
|---|---|
| اللوغ | `docker compose logs -f app` |
| تحديث بعد تعديل الكود | ارفع الملفات الجديدة ثم `docker compose up -d --build` |
| أدمن جديد / إعادة باسورد أدمن | `docker compose exec app node scripts/create-admin.js NAME 'PASSWORD-12+'` |
| ضاع جهاز الـ2FA | `docker compose exec app node scripts/reset-2fa.js USERNAME` (أو الأدمن من لوحة ADMIN ← reset) |
| إيقاف | `docker compose down` (البيانات تبقى في الـ volume) |

## 10) قائمة فحص أمان قبل الإعلان
- [ ] `ssh` بالمفتاح فقط وبدون root، و`ufw` شغال (22/80/443).
- [ ] باسورد الأدمن قوي وفعّلت 2FA وحفظت رموز الاسترجاع.
- [ ] `ADMIN_PASS` مشطوب من `.env`، وملف `.env` ما يطلع لأي مكان (git / مشاركة).
- [ ] النسخ الاحتياطي يشتغل وجربت الاستعادة مرة.
- [ ] لا تعطي حساب أدمن إلا لمن تثق فيه (الأدمن يشوف سجل النشاط وقيم بحث الكل).
- [ ] تحديثات النظام التلقائية شغالة، وتعيد بناء الصورة (`docker compose up -d --build`) كل شهر لتحديث Node والمكتبات.

## 11) الخصوصية
- **سجل النشاط** يحفظ قيم البحث (مثل الدومين أو الإيميل) ويشوفه الأدمن. لتقليل ذلك ضع `LOG_SEARCH_VALUES=0` في `.env` فيحفظ نوع البحث فقط.
- **الحالات (Cases)** وسجل البحث الشخصي خاصة بكل مستخدم ولا يشوفها حتى الأدمن من الواجهة، لكنها محفوظة بقاعدة البيانات على السيرفر، فاحمِ السيرفر والنسخ الاحتياطية.
- الأداة تبني روابط لمصادر عامة ولا ترسل قيم بحثك لأي طرف ثالث إلا لما تفتح الرابط بنفسك. استخدمها فقط ضمن القانون ومع إذن صاحب الهدف.

## 12) مشاكل شائعة
| المشكلة | الحل |
|---|---|
| الموقع لا يفتح / شهادة HTTPS ما انصدرت | تأكد إن الـ A record صح (`dig +short دومينك`) وإن 80 و443 مفتوحين، وشوف `docker compose logs caddy` |
| `DOMAIN` error أثناء `up` | ما كتبت `DOMAIN` في `.env` |
| `app` يظهر unhealthy | `docker compose logs app` (غالبًا خطأ في `.env` أو في صلاحيات الـ volume) |
| نسيت باسورد الأدمن | أمر `create-admin.js` أعلاه |
| «محاولات كثيرة» عند الدخول | قفل مؤقت 15 دقيقة بعد 5 محاولات فاشلة لنفس اسم المستخدم، انتظر أو أعد تشغيل `app` |
