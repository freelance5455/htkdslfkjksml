# الحفاظ على دوال الجسر بين الجافاسكربت والأندرويد
-keepclassmembers class com.huda.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
