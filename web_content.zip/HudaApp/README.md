# تطبيق هدى 📱

عبارات • حكم • مسجات • شعر • أدعية • نكت

**جميع الحقوق محفوظة للمبرمج عبدالمجيد عبدالله المسلمي**

---

## هيكل المشروع

| المسار | الوصف |
|---|---|
| `app/src/main/assets/index.html` | واجهة التطبيق كاملة (HTML/CSS/JS) — **هذا هو الملف الذي تعدّله غالباً** |
| `app/src/main/java/com/huda/app/MainActivity.java` | غلاف WebView (نسخ، مشاركة، زر الرجوع، لون شريط الحالة) |
| `app/src/main/res/mipmap-*` | أيقونات التطبيق |
| `app/src/main/assets/images/logo.png` | الشعار |
| `store_icon_512.png`, `store_feature_1024x500.png` | صور لمتجر Google Play |
| `database.rules.json` | قواعد Firebase جاهزة للصق |
| `.github/workflows/android.yml` | بناء APK تلقائياً على GitHub |

> لتجربة الواجهة بسرعة دون بناء: افتح `app/src/main/assets/index.html` في متصفح الحاسوب.

---

## الرفع على GitHub وبناء APK تلقائياً

```bash
cd HudaApp
git init
git add .
git commit -m "Initial commit: Huda app"
git branch -M main
git remote add origin https://github.com/USERNAME/huda.git
git push -u origin main
```

بعد الرفع: افتح تبويب **Actions** في المستودع ← **Build APK** ← بعد انتهائه نزّل الملف من قسم **Artifacts** (`Huda-debug-apk`). يعمل البناء تلقائياً عند كل `push`، ويمكن تشغيله يدوياً بزر **Run workflow**.

الـ APK الناتج (debug) يُثبَّت مباشرة على الهاتف للتجربة. للنشر على Google Play تحتاج نسخة موقّعة (Release) عبر Android Studio: **Build > Generate Signed Bundle / APK**. احتفظ بملف المفتاح بعيداً عن المستودع (مُستثنى في `.gitignore`).

## البناء من Android Studio

1. **File > Open** واختر مجلد المشروع.
2. انتظر مزامنة Gradle (JDK 17).
3. **Run ▶** للتجربة، أو **Build > Build APK(s)**.

لا يوجد `gradle-wrapper.jar` في المستودع، لكن Android Studio ينشئه تلقائياً. إن أردت أن يعمل `./gradlew` من الطرفية، شغّل مرة واحدة: `gradle wrapper --gradle-version 8.7` ثم ارفع ملفات `gradlew` و`gradle/wrapper`.

---

## كيف يعمل التطبيق

- **دخول المالك:** الإعدادات ⚙️ ← حساب المالك. كلمة المرور الافتراضية `huda2026` — **غيّرها فوراً**. (هي مكتوبة في الكود، فحتى تغيّرها يعرفها من يقرأ المستودع.)
- **المالك:** ينشر باسمه مع علامة ✔، ويثبّت ويحذف أي منشور.
- **المستخدم:** ينشر في أي قسم، ويضيف للمفضلة، ويعجب، وينسخ ويشارك.
- كل منشور بتاريخه ووقته.
- **الإعدادات:** وضع نهاري/ليلي/تلقائي، نوع الخط، حجمه، لونه.

## جعل المنشورات مشتركة بين كل المستخدمين (Firebase)

افتراضياً كل منشور يُحفظ على جهاز صاحبه فقط. لكي يراه الجميع:

1. أنشئ مشروعاً في [console.firebase.google.com](https://console.firebase.google.com) ثم **Build > Realtime Database > Create Database**.
2. في تبويب **Rules** الصق محتوى `database.rules.json` ثم **Publish**.
3. ضع رابط القاعدة في `app/src/main/assets/index.html`:

```js
var DB_URL = 'https://اسم-مشروعك-default-rtdb.firebaseio.com';
```

4. ابنِ التطبيق. يتحدث المحتوى كل 15 ثانية وعند الرجوع للتطبيق. للتأكد: الإعدادات ← دخول المالك ← **اختبار الاتصال بقاعدة البيانات**.

رابط Firebase ليس سراً (يوجد داخل كل APK)، لذلك الحماية الفعلية تأتي من القواعد لا من إخفاء الرابط.

### تنبيه أمني
القواعد الحالية تتحقق من الأقسام وطول النص فقط والكتابة مفتوحة، وكلمة مرور المالك داخل التطبيق. فيمكن لشخص متمرّس انتحال المالك أو الكتابة مباشرة في القاعدة. للحماية الحقيقية أضف **Firebase Authentication** وقواعد تحصر الحذف والتثبيت بحساب المالك، وراجع المنشورات قبل ظهورها.

## الخطوط

الخطوط تُحمَّل من Google Fonts عند توفر الإنترنت، وبدونه يظهر خط النظام. لتضمينها دون إنترنت: ضع ملفات `.woff2` في `app/src/main/assets/fonts/` وأضف قواعد `@font-face` في `index.html`.

## إضافة قسم جديد

في `index.html` ابحث عن `var CATS` وأضف:

```js
{id:'stories', name:'قصص'}
```

ثم أضف المعرّف نفسه في قاعدة `cat` داخل `database.rules.json`.
