CHAUFF'DOC - TOP COMPTEUR GAZ
Version Android 1.0

Fonctions :
- Logo Chauff'Doc fourni
- Chrono bleu marine
- Durées 30 s / 1 min / 2 min / 5 min
- Arrêt automatique du chrono
- Saisie index départ / fin
- Calcul de l'écart compteur en m³
- Bouton Nouveau contrôle
- Fonctionne hors connexion

POUR PRODUIRE L'APK :
1. Ouvrir ce dossier dans Android Studio.
2. Laisser Android Studio synchroniser Gradle.
3. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. L'APK de debug sera généré dans app/build/outputs/apk/debug/.

Pour diffusion publique, créer une version signée via
Build > Generate Signed App Bundle or APK.

Note sécurité : l'outil calcule uniquement l'écart de compteur et ne remplace
pas la procédure professionnelle/réglementaire de contrôle gaz.
