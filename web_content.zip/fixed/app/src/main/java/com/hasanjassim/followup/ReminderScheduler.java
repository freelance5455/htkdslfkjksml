package com.hasanjassim.followup;
import android.app.*;import android.content.*;import android.os.*;import org.json.*;import java.text.*;import java.util.*;
public class ReminderScheduler{
 public static void scheduleAll(Context c){ JSONArray a=AppointmentStore.get(c); for(int i=0;i<a.length();i++){try{JSONObject o=a.getJSONObject(i);String d=o.optString("date"),t=o.optString("time");Date when=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(d+" "+t);if(when!=null&&when.getTime()>System.currentTimeMillis()){Intent in=new Intent(c,ReminderReceiver.class);in.putExtra("title",o.optString("title"));PendingIntent pi=PendingIntent.getBroadcast(c,i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when.getTime(),pi);else am.set(AlarmManager.RTC_WAKEUP,when.getTime(),pi);}}catch(Exception ignored){}}}
}
