package com.hasanjassim.followup;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new AndroidBridge(this),"AndroidApp");
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},8);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    public static class AndroidBridge {
        final Context c; AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public void toast(String x){ Toast.makeText(c,x,Toast.LENGTH_SHORT).show(); }
        @JavascriptInterface public void schedule(String title,String date,String time,String reminders){
            try { AppointmentStore.add(c,title,date,time,reminders); } catch(Exception ignored){}
        }
        @JavascriptInterface public void rescheduleAll(){ ReminderScheduler.scheduleAll(c); }
    }
}
