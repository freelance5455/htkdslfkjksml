package com.hasanjassim.followup;
import android.content.*;import org.json.*;
public class AppointmentStore{
 static final String P="appointments_native",K="data";
 static JSONArray get(Context c){try{return new JSONArray(c.getSharedPreferences(P,0).getString(K,"[]"));}catch(Exception e){return new JSONArray();}}
 static void add(Context c,String title,String date,String time,String rem){try{JSONArray a=get(c);JSONObject o=new JSONObject();o.put("title",title);o.put("date",date);o.put("time",time);o.put("reminders",rem);a.put(o);c.getSharedPreferences(P,0).edit().putString(K,a.toString()).apply();}catch(Exception ignored){}}
}
