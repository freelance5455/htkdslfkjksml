import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

// Lightweight, low-poly 3D racer. Internet is needed to load Three.js from the CDN.
const wrap = document.getElementById('game-wrap');
const speedEl = document.getElementById('speed');
const distanceEl = document.getElementById('distance');
const scoreEl = document.getElementById('score');
const startPanel = document.getElementById('message');
const crashPanel = document.getElementById('crash-overlay');
const finalScore = document.getElementById('final-score');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8ec9ed);
scene.fog = new THREE.Fog(0x8ec9ed, 42, 180);

const camera = new THREE.PerspectiveCamera(65, innerWidth / innerHeight, 0.1, 250);
camera.position.set(0, 5.2, 10.5);
camera.lookAt(0, 0.7, -5);

const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'low-power' });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.5));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
wrap.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xe8f6ff, 0x556344, 2.0));
const sun = new THREE.DirectionalLight(0xffffff, 1.7);
sun.position.set(-6, 12, 7);
scene.add(sun);

const mat = (color, roughness=0.85) => new THREE.MeshStandardMaterial({ color, roughness, metalness: 0.02 });
const grassMat = mat(0x4b8d4b), roadMat = mat(0x343b43), lineMat = mat(0xf6f1d7);
const shoulderMat = mat(0xd8d4c5), tireMat = mat(0x17191d), glassMat = new THREE.MeshStandardMaterial({color:0x9fd5e8, roughness:0.25, metalness:0.05});
const world = new THREE.Group(); scene.add(world);

function box(parent, w, h, d, material, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
  mesh.position.set(x,y,z); parent.add(mesh); return mesh;
}

// Ground and road
box(world, 200, 0.2, 220, grassMat, 0, -0.22, -75);
box(world, 10.5, 0.12, 220, roadMat, 0, -0.1, -75);
box(world, 0.28, 0.14, 220, shoulderMat, -5.25, -0.06, -75);
box(world, 0.28, 0.14, 220, shoulderMat, 5.25, -0.06, -75);

// Dashed lane dividers, repeated as the road scrolls toward the player.
const dashes = [];
for (let z=-180; z<20; z+=8) {
  for (const x of [-1.75, 1.75]) {
    const dash = box(world, 0.12, 0.025, 3.3, lineMat, x, -0.02, z);
    dashes.push(dash);
  }
}

// Simple roadside trees and posts for depth, no expensive textures.
const scenery = [];
const trunkMat = mat(0x745035), leafMat = mat(0x2f7541), postMat = mat(0xe7e5d9), redMat = mat(0xd84c43);
for (let i=0; i<30; i++) {
  const z = -i*7 - 4;
  for (const side of [-1,1]) {
    const x = side*(7.0 + (i%3)*1.1);
    const g = new THREE.Group(); g.position.set(x,0,z); world.add(g);
    box(g, 0.25, 1.0, 0.25, trunkMat, 0, 0.45, 0);
    const crown = new THREE.Mesh(new THREE.ConeGeometry(0.85, 2.0, 5), leafMat);
    crown.position.y = 1.8; g.add(crown);
    const post = box(world, 0.12, 0.85, 0.12, postMat, side*5.9, 0.35, z);
    box(world, 0.13, 0.18, 0.14, redMat, side*5.9, 0.65, z-0.02);
    scenery.push({group:g, post, z});
  }
}

function makeCar(color, isPlayer=false) {
  const car = new THREE.Group();
  const bodyMat = mat(color, 0.38);
  box(car, 1.55, 0.48, 2.7, bodyMat, 0, 0.62, 0);
  box(car, 1.12, 0.55, 1.25, bodyMat, 0, 1.08, -0.2);
  box(car, 0.98, 0.32, 0.08, glassMat, 0, 1.12, -0.85);
  box(car, 0.98, 0.3, 0.08, glassMat, 0, 1.12, 0.45);
  const wheelGeo = new THREE.CylinderGeometry(0.29,0.29,0.18,8);
  for (const x of [-0.81,0.81]) for (const z of [-0.83,0.88]) {
    const wheel = new THREE.Mesh(wheelGeo, tireMat);
    wheel.rotation.z = Math.PI/2; wheel.position.set(x,0.36,z); car.add(wheel);
  }
  if (isPlayer) {
    const lightMat = new THREE.MeshStandardMaterial({color:0xfff2bd, emissive:0x6b5015});
    box(car,0.28,0.13,0.08,lightMat,-0.48,0.65,-1.37);
    box(car,0.28,0.13,0.08,lightMat,0.48,0.65,-1.37);
  }
  car.userData.halfW = 0.72;
  car.userData.halfD = 1.2;
  return car;
}

const player = makeCar(0x1e78e8, true);
player.position.set(0,0,3);
scene.add(player);

const traffic = [];
const trafficColors = [0xe74b3c,0xf0bd31,0xeeeeee,0x9b68c8,0x2aa889,0x343a40];
function spawnTraffic(z=-60) {
  const lane = [-3.4,0,3.4][Math.floor(Math.random()*3)];
  const car = makeCar(trafficColors[Math.floor(Math.random()*trafficColors.length)]);
  car.position.set(lane,0,z);
  car.rotation.y = Math.PI;
  scene.add(car);
  traffic.push({mesh:car, speed: 7 + Math.random()*9, lane});
}
for(let i=0;i<5;i++) spawnTraffic(-30-i*28);

const state = {running:false, crashed:false, speed:0, distance:0, score:0, steer:0, gas:false, brake:false, left:false, right:false};
const maxSpeed = 42;
function bindHold(id, key) {
  const el = document.getElementById(id);
  const down = e => { e.preventDefault(); state[key]=true; el.classList.add('pressed'); };
  const up = e => { e.preventDefault(); state[key]=false; el.classList.remove('pressed'); };
  el.addEventListener('pointerdown', down);
  ['pointerup','pointercancel','pointerleave'].forEach(ev=>el.addEventListener(ev,up));
}
bindHold('left-btn','left'); bindHold('right-btn','right');
bindHold('gas-btn','gas'); bindHold('brake-btn','brake');

document.getElementById('start-btn').addEventListener('click', startGame);
document.getElementById('restart-btn').addEventListener('click', resetGame);
function startGame(){ state.running=true; state.crashed=false; startPanel.classList.add('hidden'); crashPanel.classList.add('hidden'); }
function resetGame(){
  state.speed=0; state.distance=0; state.score=0; state.steer=0; state.running=true; state.crashed=false;
  player.position.x=0; player.rotation.z=0;
  traffic.forEach((t,i)=>{t.mesh.position.set([-3.4,0,3.4][i%3],0,-35-i*29);t.speed=7+Math.random()*9;});
  crashPanel.classList.add('hidden'); startPanel.classList.add('hidden');
}
function crash(){
  state.running=false; state.crashed=true; state.speed=0;
  finalScore.textContent=`Score: ${Math.floor(state.score)} • Distance: ${Math.floor(state.distance)} m`;
  crashPanel.classList.remove('hidden');
}
function clamp(v,a,b){ return Math.max(a,Math.min(b,v)); }

let last = performance.now();
function animate(now){
  requestAnimationFrame(animate);
  const dt = Math.min((now-last)/1000,0.04); last=now;
  if(state.running){
    const target = state.gas ? maxSpeed : 23;
    state.speed += ((state.brake ? -34 : (target-state.speed)*1.6) - (state.brake?0:0))*dt;
    state.speed = clamp(state.speed,0,maxSpeed);
    const steerInput = (state.right?1:0) - (state.left?1:0);
    player.position.x += steerInput * (3.2 + state.speed*0.045) * dt;
    player.position.x = clamp(player.position.x,-4.15,4.15);
    player.rotation.z = THREE.MathUtils.lerp(player.rotation.z,-steerInput*0.10,dt*7);
    player.position.y = Math.sin(now*0.012)*0.012;
    const worldMove = state.speed*dt*1.7;
    state.distance += state.speed*dt*1.8;
    state.score += state.speed*dt*0.75;
    dashes.forEach(d=>{d.position.z += worldMove; if(d.position.z>12)d.position.z-=200;});
    scenery.forEach(s=>{s.z+=worldMove; if(s.z>12)s.z-=210; s.group.position.z=s.z; s.post.position.z=s.z;});
    traffic.forEach(t=>{
      t.mesh.position.z += (worldMove - t.speed*dt*0.45);
      if(t.mesh.position.z>10){ t.mesh.position.z=-125-Math.random()*35; t.mesh.position.x=[-3.4,0,3.4][Math.floor(Math.random()*3)]; t.speed=7+Math.random()*9; }
      const dz=Math.abs(t.mesh.position.z-player.position.z);
      const dx=Math.abs(t.mesh.position.x-player.position.x);
      if(dz<2.0 && dx<1.25){ crash(); }
    });
    if(Math.abs(player.position.x)>4.0) state.speed=Math.min(state.speed,20);
  }
  // Camera follows slightly, with a gentle lateral look.
  camera.position.x = THREE.MathUtils.lerp(camera.position.x, player.position.x*0.22, 0.035);
  camera.lookAt(player.position.x*0.12,0.75,-5);
  speedEl.textContent=Math.round(state.speed*3.2);
  distanceEl.textContent=Math.floor(state.distance);
  scoreEl.textContent=Math.floor(state.score);
  renderer.render(scene,camera);
}
requestAnimationFrame(animate);

addEventListener('resize',()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5)); renderer.setSize(innerWidth,innerHeight);
});

// Keyboard support is useful when testing on a computer.
addEventListener('keydown',e=>{
  if(e.code==='ArrowLeft'||e.code==='KeyA') state.left=true;
  if(e.code==='ArrowRight'||e.code==='KeyD') state.right=true;
  if(e.code==='ArrowUp'||e.code==='KeyW') state.gas=true;
  if(e.code==='ArrowDown'||e.code==='Space') state.brake=true;
  if(e.code==='Enter'&&!state.running&&!state.crashed) startGame();
});
addEventListener('keyup',e=>{
  if(e.code==='ArrowLeft'||e.code==='KeyA') state.left=false;
  if(e.code==='ArrowRight'||e.code==='KeyD') state.right=false;
  if(e.code==='ArrowUp'||e.code==='KeyW') state.gas=false;
  if(e.code==='ArrowDown'||e.code==='Space') state.brake=false;
});
