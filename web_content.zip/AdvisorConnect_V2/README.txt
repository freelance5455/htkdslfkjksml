Advisor Connect V2 — HTML-to-APK ready offline recruitment CRM.
Includes Recruiting Partners + Advisor Candidates, editable records, partner assignment, follow-ups, dashboard, Call, and WhatsApp chooser. Data is stored locally.
