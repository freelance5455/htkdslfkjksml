WORK REGISTER 2027 — GOOGLE DRIVE AUTO-SYNC SOURCE

WHAT THIS PACKAGE DOES
- Mobile-friendly Work Register 2027 app source.
- Daily work amount, automatic 40% incentive, monthly and annual reports.
- Two average graphs with numbers, CSV export, Print/Save PDF.
- Keeps a local copy and can sync the entries to a JSON backup file in the user's Google Drive.
- After connecting, saving an entry triggers Drive sync. On another device, open the hosted app, enter the same OAuth Client ID, connect the same Google account, and it merges entries by per-day update timestamps.

IMPORTANT
This is source code, NOT a deployed website and NOT a signed APK. Google Drive sync will NOT work until you configure a Google Cloud OAuth Client ID and host the app on an authorized HTTPS origin (localhost can be used for local development). No credentials are included. Do not put private secrets in this source. The OAuth Client ID is a public web-client identifier, not a client secret.

GOOGLE DRIVE SETUP (one-time)
1. On a computer, open https://console.cloud.google.com/ and sign in with the Google account you want to use.
2. Create a project, e.g. Work Register 2027.
3. Open APIs & Services > Library, find Google Drive API, and click Enable.
4. Open Google Auth Platform (or APIs & Services > OAuth consent screen). Configure the app name and support email. Add your own Google account as a test user if the app is in Testing mode.
5. Open Clients / Credentials > Create OAuth client ID > Web application.
6. Add the exact website origin to Authorized JavaScript origins, e.g. https://YOUR-SITE.example or http://localhost:8000 for local testing. Do not add a path after the domain. Save and copy the Client ID ending in .apps.googleusercontent.com.
7. Host the contents of this folder on an HTTPS static host. For local testing, run a local web server from this folder (for example, Python's http.server on port 8000) and use http://localhost:8000. Opening index.html directly as file:// is not supported for Google OAuth.
8. Open the hosted app on the phone. Go to Google Drive Sync, paste the OAuth Client ID and press Connect Google Drive. Approve access. The app creates Work_Register_2027_backup.json in the connected Google Drive's My Drive.
9. Test by entering a sample amount, refreshing, and checking the JSON backup in Google Drive. On a second device, use the same hosted app and Google account, connect Drive, and verify the entries appear.

AUTO-SYNC NOTES
- Local browser storage remains as a local copy. The app syncs to Drive only while the Google access token is active; tokens expire, so reconnect if the app reports an authorization error. The Google OAuth token is kept in memory, not saved as a password.
- If you use another device, connect the same Google account. A Drive backup file is created/updated by the app; the app needs internet access.
- When the same date is edited on multiple devices, the newest per-date timestamp wins on the next sync. Avoid editing the same date simultaneously on two devices.
- Google Drive backup is a JSON file, not an Excel file. You can download the JSON file from Drive as a backup. Use the app's Export CSV for Excel-compatible export.
- Do not use for critical accounting until you test sync/recovery and keep independent backups.

SECURITY
- Scope requested: drive.file, limited to files created/opened by this app.
- The app does not ask for your Google password. Consent is handled by Google.
- Use your own OAuth Client ID and only host on a domain you control. Never share access tokens.


ANDROID APK IMPORTANT — LOGIN HANDOFF PATCH
The HTML wrapper cannot reliably complete Google's OAuth flow inside an embedded WebView. This patched source detects the Android WebView/appassets origin and attempts to open the hosted HTTPS app in Chrome. It passes the public OAuth Client ID to the hosted app. If Android blocks the Chrome intent, open the Netlify URL in Chrome manually.

DATA TRANSFER FROM APK TO CHROME
The APK and Chrome have separate local storage. Before moving your entries, open the APK's Google Drive Sync section and tap Export Local Data JSON. Then open the hosted app in Chrome, tap Import Local Data JSON, choose that exported file, connect Google Drive, and tap Sync Now. Verify Work_Register_2027_backup.json exists in Google Drive before relying on it. After this handoff, use the hosted app/Chrome as the primary app for Drive auto-sync. Entries made only in the old APK will not auto-sync to Drive.

LIMITATION
This is a web-source workaround, not a native Android OAuth implementation and not a rebuilt/signed APK. For direct Drive auto-sync from inside an APK, rebuild the Android wrapper with external-browser OAuth redirect handling or native Google Sign-In. Never share access tokens or client secrets.
