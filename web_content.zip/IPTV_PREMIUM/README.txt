IPTV PREMIUM — version HTML

FICHIERS
- index.html : application web autonome.

UTILISATION SUR ANDROID
1. Décompressez IPTV_PREMIUM_HTML.zip avec un gestionnaire de fichiers.
2. Ouvrez index.html avec Chrome.
3. Appuyez sur « Charger la playlist » si elle ne s'est pas chargée automatiquement.
4. Touchez une chaîne ou utilisez « Chaîne précédente / Chaîne suivante ».

FONCTIONS
- Playlist par défaut : https://iptv-org.github.io/iptv/index.language.m3u
- Zapping précédent/suivant
- Recherche, catégories, favoris
- Sauvegarde locale de l'URL de playlist et des favoris.

LIMITATIONS
- Le navigateur peut empêcher le téléchargement de la playlist à cause de CORS. Si cela arrive, l'application affiche un message; il faut servir le fichier depuis un hébergement compatible CORS ou utiliser une playlist accessible.
- Les flux IPTV ne sont pas tous compatibles avec la balise vidéo HTML. Certains flux HLS fonctionnent dans Chrome, mais certains formats/codecs ou flux nécessitant des en-têtes particuliers peuvent échouer.
- Ce ZIP est une application HTML, pas un APK Android natif.
