/**
 * ترید یار - سرور همگام‌سازی Cloudflare Worker (پروکسی CORS)
 * 
 * این Worker به‌عنوان پل بین کاربر و textdb.dev عمل می‌کند:
 * - کاربر به این Worker درخواست می‌فرستد (Cloudflare در ایران فیلتر نیست)
 * - Worker داده‌ها را در textdb.dev ذخیره/بازیابی می‌کند
 * - نیازی به KV یا ذخیره‌سازی دائمی در Worker نیست
 * 
 * دستورالعمل:
 * 1. کد قبلی را در Cloudflare Worker پاک کنید
 * 2. این کد را کپی و جایگزین کنید
 * 3. روی Deploy بزنید
 * 4. URL شما: https://square-wind-j49bc.lyakbrrytpyshh.workers.dev
 */

// textdb.dev endpoint for data storage
const TEXTDB_URL = 'https://textdb.dev/api/data/4b1d3f97-6c1a-4e8b-9f2a-1a2b3c4d5e6f';

export default {
  async fetch(request) {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Content-Type': 'application/json',
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    try {
      // GET - fetch data from textdb.dev
      if (request.method === 'GET') {
        const resp = await fetch(TEXTDB_URL, { method: 'GET' });
        const text = await resp.text();
        
        // Try to parse as JSON
        let doc = null;
        try { doc = JSON.parse(text); } catch(e) {}
        
        if (doc && doc.v) {
          return new Response(JSON.stringify({ ok: true, doc: doc }), {
            status: 200, headers: corsHeaders,
          });
        }
        
        return new Response(JSON.stringify({ ok: false, reason: 'no_data' }), {
          status: 200, headers: corsHeaders,
        });
      }

      // POST - save data to textdb.dev
      if (request.method === 'POST') {
        const body = await request.text();
        
        // Forward to textdb.dev
        const resp = await fetch(TEXTDB_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain' },
          body: body,
        });
        
        if (resp.ok) {
          return new Response(JSON.stringify({ ok: true }), {
            status: 200, headers: corsHeaders,
          });
        }
        
        return new Response(JSON.stringify({ ok: false, error: 'textdb_error' }), {
          status: 500, headers: corsHeaders,
        });
      }

      return new Response(JSON.stringify({ ok: false, error: 'method_not_allowed' }), {
        status: 405, headers: corsHeaders,
      });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: String(e) }), {
        status: 500, headers: corsHeaders,
      });
    }
  },
};
