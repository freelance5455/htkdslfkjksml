/* MY AI FOOTBALL — Unified Interactive Franchise Hub
 * Interconnects Transfer Market, Club & Squad, Cards & Packs, Tactics Studio,
 * Player Career, Manager Career, Pro Circular Controls Configurator & 3D Match Engine */
(function () {
  "use strict";

  const STORAGE_KEY = "myai_football_franchise_v1";
  const FORMATIONS_COORDS = {
    "4-3-3": [
      { idx: 0, role: "GK", x: 50, y: 90 },
      { idx: 1, role: "LB", x: 16, y: 72 },
      { idx: 2, role: "LCB", x: 38, y: 76 },
      { idx: 3, role: "RCB", x: 62, y: 76 },
      { idx: 4, role: "RB", x: 84, y: 72 },
      { idx: 5, role: "CDM", x: 50, y: 56 },
      { idx: 6, role: "LCM", x: 28, y: 46 },
      { idx: 7, role: "CAM", x: 72, y: 46 },
      { idx: 8, role: "LW", x: 18, y: 22 },
      { idx: 9, role: "ST", x: 50, y: 15 },
      { idx: 10, role: "RW", x: 82, y: 22 },
    ],
    "4-2-3-1": [
      { idx: 0, role: "GK", x: 50, y: 90 },
      { idx: 1, role: "LB", x: 16, y: 72 },
      { idx: 2, role: "LCB", x: 38, y: 76 },
      { idx: 3, role: "RCB", x: 62, y: 76 },
      { idx: 4, role: "RB", x: 84, y: 72 },
      { idx: 5, role: "CDM", x: 37, y: 58 },
      { idx: 6, role: "RDM", x: 63, y: 58 },
      { idx: 8, role: "LAM", x: 20, y: 36 },
      { idx: 7, role: "CAM", x: 50, y: 34 },
      { idx: 10, role: "RAM", x: 80, y: 36 },
      { idx: 9, role: "ST", x: 50, y: 14 },
    ],
    "4-4-2": [
      { idx: 0, role: "GK", x: 50, y: 90 },
      { idx: 1, role: "LB", x: 16, y: 72 },
      { idx: 2, role: "LCB", x: 38, y: 76 },
      { idx: 3, role: "RCB", x: 62, y: 76 },
      { idx: 4, role: "RB", x: 84, y: 72 },
      { idx: 6, role: "LM", x: 16, y: 46 },
      { idx: 5, role: "LCM", x: 39, y: 50 },
      { idx: 7, role: "RCM", x: 61, y: 50 },
      { idx: 8, role: "RM", x: 84, y: 46 },
      { idx: 9, role: "ST", x: 38, y: 18 },
      { idx: 10, role: "CF", x: 62, y: 18 },
    ],
    "3-5-2": [
      { idx: 0, role: "GK", x: 50, y: 90 },
      { idx: 2, role: "LCB", x: 26, y: 75 },
      { idx: 3, role: "CB", x: 50, y: 77 },
      { idx: 4, role: "RCB", x: 74, y: 75 },
      { idx: 1, role: "LWB", x: 14, y: 49 },
      { idx: 5, role: "CDM", x: 37, y: 54 },
      { idx: 7, role: "CAM", x: 50, y: 38 },
      { idx: 6, role: "CM", x: 63, y: 54 },
      { idx: 8, role: "RWB", x: 86, y: 49 },
      { idx: 9, role: "ST", x: 38, y: 17 },
      { idx: 10, role: "CF", x: 62, y: 17 },
    ],
    "5-3-2": [
      { idx: 0, role: "GK", x: 50, y: 90 },
      { idx: 1, role: "LWB", x: 13, y: 66 },
      { idx: 2, role: "LCB", x: 32, y: 76 },
      { idx: 3, role: "CB", x: 50, y: 78 },
      { idx: 4, role: "RCB", x: 68, y: 76 },
      { idx: 5, role: "RWB", x: 87, y: 66 },
      { idx: 6, role: "LCM", x: 30, y: 46 },
      { idx: 7, role: "CM", x: 50, y: 48 },
      { idx: 8, role: "RCM", x: 70, y: 46 },
      { idx: 9, role: "ST", x: 38, y: 18 },
      { idx: 10, role: "CF", x: 62, y: 18 },
    ],
  };

  const DEFAULT_PRESETS = [
    { id: "pro_arc", name: "قياسي احترافي (دائري)", joySize: 112, btnSize: 62, opacity: 88, sensitivity: 100, offsetX: 0, offsetY: 0 },
    { id: "compact_phone", name: "هاتف مدمج", joySize: 96, btnSize: 54, opacity: 82, sensitivity: 110, offsetX: 0, offsetY: 4 },
    { id: "large_thumb", name: "أزرار كبيرة مريحة", joySize: 128, btnSize: 70, opacity: 92, sensitivity: 95, offsetX: 4, offsetY: 6 },
  ];

  const INSTRUCTIONS_LABELS = {
    balanced: "متوازن",
    push_forward: "تقدم هجومي",
    stay_back: "ثبات دفاعي",
    free_roam: "حرية حركة",
  };

  function esc(v) {
    return typeof window.escapeHTML === "function"
      ? window.escapeHTML(String(v ?? ""))
      : String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function say(msg) {
    if (typeof window.notify === "function") window.notify(msg);
  }

  function sfx(name) {
    try {
      window.MYAISound?.[name]?.();
    } catch (_) {}
  }

  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  function getDb() {
    return window.MYAI_PLAYERS_DB || { TEAMS: [], PLAYERS: [], getTeamLineupForMatch: () => ({ team: {}, squad: [] }) };
  }

  function buildClubRosterFromDb(clubId) {
    const db = getDb();
    const lineup = db.getTeamLineupForMatch(clubId);
    const starters = lineup.squad.map((m, i) => ({
      ...m,
      id: m.id || `${clubId}_s_${i}`,
      slotIdx: i,
      contractYears: 3,
      wageK: m.ovr ? Math.max(18, Math.round((m.ovr - 60) * 4.5)) : 45,
      valueM: m.ovr ? Math.max(2, Math.round(Math.pow((m.ovr - 62) / 6.5, 2) * 1.4 * 10) / 10) : 12,
    }));
    // Build a 6-player realistic bench from remaining DB pool or complementary reserves
    const usedIds = new Set(starters.map((s) => s.id));
    const teamExtras = (db.PLAYERS || []).filter((p) => p.clubId === clubId && !usedIds.has(p.id));
    const benchRoles = ["GK", "CB", "CM", "CAM", "LW", "ST"];
    const baseOvr = Math.max(70, (lineup.team?.ovr || 80) - 5);
    const bench = benchRoles.map((r, bi) => {
      const ex = teamExtras[bi];
      if (ex) {
        return {
          id: ex.id,
          name: ex.name,
          pos: ex.pos,
          role: r,
          ovr: ex.ovr,
          pac: ex.pac,
          sho: ex.sho,
          pas: ex.pas,
          dri: ex.dri,
          def: ex.def,
          phy: ex.phy,
          stam: ex.stam,
          jerseyNo: ex.jerseyNo,
          skinHex: ex.skinHex,
          hairHex: ex.hairHex,
          hairStyle: ex.hairStyle,
          bootColor: ex.bootColor,
          rarity: ex.rarity,
          skillMoves: ex.skillMoves,
          weakFoot: ex.weakFoot,
          contractYears: 3,
          wageK: ex.wageK,
          valueM: ex.valueM,
        };
      }
      return {
        id: `${clubId}_res_${bi}`,
        name: `${lineup.team?.nameEn || "Club"} Sub #${20 + bi}`,
        pos: r,
        role: r,
        ovr: baseOvr - (bi % 3),
        pac: baseOvr,
        sho: r === "ST" || r === "LW" ? baseOvr : 64,
        pas: baseOvr - 2,
        dri: baseOvr - 2,
        def: r === "CB" ? baseOvr : 50,
        phy: baseOvr - 3,
        stam: 88,
        jerseyNo: 20 + bi,
        skinHex: bi % 2 === 0 ? "#cfa17d" : "#e6bfa3",
        hairHex: "#171414",
        hairStyle: bi % 2 === 0 ? "fade" : "short",
        bootColor: "#38bdf8",
        rarity: "common",
        skillMoves: 3,
        weakFoot: 3,
        contractYears: 2,
        wageK: 28,
        valueM: 5.5,
      };
    });
    return {
      starters,
      bench,
      roles: {
        captainId: starters[2]?.id || starters[9]?.id,
        fkId: starters[7]?.id || starters[10]?.id,
        ckId: starters[8]?.id || starters[7]?.id,
        pkId: starters[9]?.id || starters[10]?.id,
      },
    };
  }

  function buildLeagueStandings(focusClubId) {
    const db = getDb();
    const teams = (db.TEAMS || []).slice();
    const club = teams.find((t) => t.id === focusClubId) || teams[0];
    const pool = teams.filter((t) => t.id !== focusClubId && t.league !== "national" && t.league !== "legends");
    const picked = [club, ...pool.slice(0, 9)].filter(Boolean);
    return picked.map((t) => ({
      teamId: t.id,
      name: t.name,
      ovr: t.ovr || 82,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      gf: 0,
      ga: 0,
      pts: 0,
    }));
  }

  function createDefaultState() {
    const firstClubId = "liverpool";
    return {
      version: 2,
      managedClubId: firstClubId,
      awayClubId: "real_madrid",
      budgetM: 165.0,
      wageBudgetK: 2800,
      facilities: { training: 1, youth: 1, stadium: 1 },
      squadsByClub: {
        [firstClubId]: buildClubRosterFromDb(firstClubId),
      },
      loanedPlayers: [],
      incomingBids: [
        { id: "bid_1", playerName: "أحد لاعبي فريقك", clubName: "بايرن ميونخ", playerId: "", offerM: 48.5, type: "transfer" },
      ],
      transferHistory: [],
      tactics: {
        activeSlotIndex: 0,
        slots: [
          {
            name: "خطة أساسية هجومية",
            formation: "4-3-3",
            attackStyle: "balanced",
            defenseStyle: "high_press",
            defenseLine: 6,
            pressIntensity: 7,
            buildUpSpeed: 7,
            instructions: {},
          },
          {
            name: "استحواذ وتمرير قصير",
            formation: "4-2-3-1",
            attackStyle: "possession",
            defenseStyle: "balanced",
            defenseLine: 5,
            pressIntensity: 5,
            buildUpSpeed: 5,
            instructions: {},
          },
          {
            name: "مرتدات وتأمين دفاعي",
            formation: "5-3-2",
            attackStyle: "counter",
            defenseStyle: "deep_block",
            defenseLine: 3,
            pressIntensity: 4,
            buildUpSpeed: 9,
            instructions: {},
          },
        ],
      },
      cards: {
        owned: {
          salah: { playerId: "salah", level: 0, count: 1, acquiredAt: Date.now() },
          macallister: { playerId: "macallister", level: 0, count: 1, acquiredAt: Date.now() },
          emam: { playerId: "emam", level: 0, count: 1, acquiredAt: Date.now() },
        },
        lastOpened: [],
      },
      playerCareer: {
        created: false,
        pro: {
          id: "my_pro_1",
          name: "بطل MY AI",
          nationality: "مصر",
          pos: "مهاجم",
          roleIdx: 9,
          age: 19,
          skinHex: "#cfa17d",
          hairHex: "#171414",
          hairStyle: "fade",
          bootColor: "#ff263f",
          ovr: 76,
          pac: 81,
          sho: 77,
          pas: 73,
          dri: 78,
          def: 46,
          phy: 75,
          jerseyNo: 99,
          skillMoves: 4,
          weakFoot: 4,
          rarity: "epic",
        },
        clubId: "al_ahly_eg",
        season: 1,
        matchday: 1,
        xp: 0,
        apps: 0,
        goals: 0,
        assists: 0,
        avgRating: 7.2,
        trophies: 0,
        wageK: 42,
        contractYears: 3,
        transferOffers: [],
        log: [],
      },
      managerCareer: {
        active: false,
        clubId: "liverpool",
        season: 1,
        matchday: 1,
        reputation: 64,
        morale: 80,
        trophies: 0,
        boardTarget: "التواجد في المربع الذهبي",
        leagueTable: buildLeagueStandings("liverpool"),
        jobOffers: [],
        resultsLog: [],
      },
      controls: {
        activePresetId: "pro_arc",
        presets: clone(DEFAULT_PRESETS),
      },
      matchSettings: {
        difficulty: "متوسط",
        lighting: "night",
        quality: "medium",
        halfSeconds: 90,
        camera: "broadcast",
        cameraZoom: 1.0,
        gameSpeed: "normal",
        opponentStrength: "قوي",
        gkLevel: "متميز",
        opponentStyle: "متوازن",
        controlAssist: "شبه مساعد",
      },
    };
  }

  let state = null;
  let loadedFromServer = false;
  let saveTimer = null;
  let activeTab = "kickoff";
  let uiState = {
    marketQuery: "",
    marketPos: "all",
    negotiationPlayerId: null,
    negotiationMode: "buy",
    bidPriceM: 35,
    bidWageK: 90,
    tacticSwapIdx: null,
    cardsRarityFilter: "all",
  };

  function hydrateState() {
    if (state) return state;
    const def = createDefaultState();
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          state = deepMerge(def, parsed);
          return state;
        }
      }
    } catch (_) {}
    state = def;
    return state;
  }

  function deepMerge(target, src) {
    const out = Array.isArray(target) ? target.slice() : Object.assign({}, target);
    if (!src || typeof src !== "object") return out;
    Object.keys(src).forEach((k) => {
      const v = src[k];
      if (v && typeof v === "object" && !Array.isArray(v) && target[k] && typeof target[k] === "object" && !Array.isArray(target[k])) {
        out[k] = deepMerge(target[k], v);
      } else if (v !== undefined) {
        out[k] = v;
      }
    });
    return out;
  }

  function saveStateNow() {
    if (!state) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (_) {}
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      if (typeof navigator !== "undefined" && navigator.onLine === false) return;
      if (typeof window.myaiApiFetch !== "function") return;
      try {
        await window.myaiApiFetch("/api/football/state", {
          method: "POST",
          body: JSON.stringify({ state }),
        });
      } catch (_) {}
    }, 350);
  }

  async function ensureLoaded() {
    hydrateState();
    if (loadedFromServer) return state;
    loadedFromServer = true;
    if (typeof navigator === "undefined" || navigator.onLine === false || typeof window.myaiApiFetch !== "function") {
      return state;
    }
    try {
      const res = await window.myaiApiFetch("/api/football/state");
      if (res?.state && typeof res.state === "object" && Object.keys(res.state).length > 0) {
        state = deepMerge(createDefaultState(), res.state);
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
        } catch (_) {}
      }
    } catch (_) {}
    return state;
  }

  function getClubRoster(clubId) {
    const s = hydrateState();
    const id = clubId || s.managedClubId || "liverpool";
    if (!s.squadsByClub[id]) {
      s.squadsByClub[id] = buildClubRosterFromDb(id);
    }
    return s.squadsByClub[id];
  }

  function getActiveTactic() {
    const s = hydrateState();
    const idx = Math.max(0, Math.min((s.tactics.slots?.length || 1) - 1, s.tactics.activeSlotIndex || 0));
    return s.tactics.slots[idx];
  }

  function getActiveControlPreset() {
    const s = hydrateState();
    const presets = s.controls?.presets || DEFAULT_PRESETS;
    return presets.find((p) => p.id === s.controls?.activePresetId) || presets[0];
  }

  function refreshIncomingBids() {
    const s = hydrateState();
    const db = getDb();
    const roster = getClubRoster(s.managedClubId);
    const stars = roster.starters.filter((p) => p.role !== "GK").slice().sort((a, b) => b.ovr - a.ovr);
    const bidders = (db.TEAMS || []).filter((t) => t.id !== s.managedClubId && t.ovr >= 82);
    s.incomingBids = stars.slice(0, 2).map((pl, idx) => {
      const buyer = bidders[(idx * 5 + Math.floor(Math.random() * 5)) % bidders.length] || { name: "باريس سان جيرمان" };
      const val = pl.valueM || getDb().estimateMarketValue?.(pl.ovr, 25) || 35;
      return {
        id: `bid_${Date.now()}_${idx}`,
        playerId: pl.id,
        playerName: pl.name,
        playerOvr: pl.ovr,
        clubName: buyer.name,
        offerM: Math.round(val * (1.05 + Math.random() * 0.2) * 10) / 10,
        type: idx === 1 ? "loan" : "transfer",
      };
    });
  }

  function formatM(n) {
    return `${Number(n || 0).toFixed(1)}M €`;
  }

  function getActiveMatchPayload(overrides) {
    const s = hydrateState();
    const ov = overrides || {};
    const homeId = ov.homeTeamId || s.managedClubId || "liverpool";
    const awayId = ov.awayTeamId || s.awayClubId || "real_madrid";
    const db = getDb();
    const homeTeam = (db.TEAMS || []).find((t) => t.id === homeId) || { id: homeId, name: "MY AI FC", nameEn: "MY AI FC", primary: "#ff142e", secondary: "#facc15", ovr: 84, formation: "4-3-3" };
    const awayTeam = (db.TEAMS || []).find((t) => t.id === awayId) || { id: awayId, name: "Real Madrid", nameEn: "Real Madrid", primary: "#f8fafc", secondary: "#d4af37", ovr: 89, formation: "4-3-3" };
    const homeRoster = getClubRoster(homeId);
    const awayRoster = buildClubRosterFromDb(awayId);
    const tactic = clone(getActiveTactic());
    const preset = clone(getActiveControlPreset());

    // Build starters array ordered to slots, inject Pro Player if careerMode === 'player'
    const homeSquad = clone(homeRoster.starters);
    let proSlotIdx = -1;
    if (ov.careerMode === "player" && s.playerCareer?.created) {
      const pro = s.playerCareer.pro;
      proSlotIdx = Math.max(1, Math.min(10, Number(pro.roleIdx || 9)));
      homeSquad[proSlotIdx] = { ...clone(pro), role: homeSquad[proSlotIdx]?.role || "ST" };
    }

    return {
      homeTeamId: homeId,
      awayTeamId: awayId,
      homeTeam,
      awayTeam,
      homeSquad,
      homeBench: clone(homeRoster.bench),
      awaySquad: awayRoster.starters,
      tactics: tactic,
      controlPreset: preset,
      matchSettings: clone(s.matchSettings),
      careerMode: ov.careerMode || null,
      proSlotIdx,
    };
  }

  function simulateAiMatchday(table, userClubId, userHomeGoals, userAwayGoals, opponentId) {
    if (!Array.isArray(table) || table.length < 2) return;
    const apply = (teamId, gf, ga) => {
      const row = table.find((r) => r.teamId === teamId);
      if (!row) return;
      row.played += 1;
      row.gf += gf;
      row.ga += ga;
      if (gf > ga) {
        row.won += 1;
        row.pts += 3;
      } else if (gf === ga) {
        row.drawn += 1;
        row.pts += 1;
      } else {
        row.lost += 1;
      }
    };

    apply(userClubId, userHomeGoals, userAwayGoals);
    apply(opponentId, userAwayGoals, userHomeGoals);

    // Other clubs play pairwise AI fixtures on this matchday
    const others = table.filter((r) => r.teamId !== userClubId && r.teamId !== opponentId);
    for (let i = 0; i + 1 < others.length; i += 2) {
      const a = others[i];
      const b = others[i + 1];
      const edge = ((a.ovr - b.ovr) / 25);
      const ga = Math.max(0, Math.min(5, Math.floor(Math.random() * 2.8 + Math.max(0, edge))));
      const gb = Math.max(0, Math.min(5, Math.floor(Math.random() * 2.5 + Math.max(0, -edge))));
      apply(a.teamId, ga, gb);
      apply(b.teamId, gb, ga);
    }
    table.sort((x, y) => y.pts - x.pts || (y.gf - y.ga) - (x.gf - x.ga) || y.gf - x.gf);
  }

  function recordMatchOutcome(summary) {
    const s = hydrateState();
    const hg = Number(summary.homeGoals || 0);
    const ag = Number(summary.awayGoals || 0);
    const won = hg > ag;
    const draw = hg === ag;
    const rewardM = won ? 6.5 : draw ? 3.2 : 1.5;
    s.budgetM = Math.round((s.budgetM + rewardM) * 10) / 10;

    // Update starter fitness/goals stats if scorings passed
    if (Array.isArray(summary.scorers) && summary.scorers.length) {
      const roster = getClubRoster(s.managedClubId);
      summary.scorers.forEach((sc) => {
        const p = roster.starters.find((x) => x.id === sc.playerId || x.name === sc.name);
        if (p) p.goals = (p.goals || 0) + 1;
      });
    }

    if (summary.careerMode === "player" && s.playerCareer?.created) {
      const pc = s.playerCareer;
      const pg = Number(summary.proGoals || 0);
      const pa = Number(summary.proAssists || 0);
      const rating = Math.min(10, Math.max(5.8, Number(summary.proRating || (6.4 + pg * 0.9 + pa * 0.5 + (won ? 0.6 : 0)))));
      pc.apps += 1;
      pc.goals += pg;
      pc.assists += pa;
      pc.avgRating = Math.round((((pc.avgRating || 7) * (pc.apps - 1) + rating) / pc.apps) * 10) / 10;
      pc.xp += 120 + pg * 90 + pa * 50 + (won ? 60 : 20);
      pc.matchday += 1;
      // Grow OVR with XP
      while (pc.xp >= 250 && pc.pro.ovr < 96) {
        pc.xp -= 250;
        pc.pro.ovr += 1;
        pc.pro.pac = Math.min(99, pc.pro.pac + 1);
        pc.pro.sho = Math.min(99, pc.pro.sho + 1);
        pc.pro.dri = Math.min(99, pc.pro.dri + 1);
        pc.pro.pas = Math.min(99, pc.pro.pas + 1);
      }
      if (pc.apps >= 2 && (!pc.transferOffers || pc.transferOffers.length < 2) && (pc.pro.ovr >= 78 || pc.goals >= 2)) {
        const db = getDb();
        const bigClubs = (db.TEAMS || []).filter((t) => t.id !== pc.clubId && t.ovr >= 83);
        const pick = bigClubs[Math.floor(Math.random() * bigClubs.length)];
        if (pick) {
          pc.transferOffers.push({
            id: `poff_${Date.now()}`,
            clubId: pick.id,
            clubName: pick.name,
            wageK: Math.round((pc.pro.ovr - 55) * 4),
            role: "لاعب أساسي",
          });
        }
      }
      pc.log.unshift({
        date: new Date().toLocaleDateString("ar-EG"),
        match: `${summary.homeName} ${hg}-${ag} ${summary.awayName}`,
        goals: pg,
        assists: pa,
        rating: rating.toFixed(1),
      });
      pc.log = pc.log.slice(0, 15);
    }

    if (summary.careerMode === "manager" && s.managerCareer?.active) {
      const mc = s.managerCareer;
      const oppId = summary.awayTeamId || mc.leagueTable.find((r) => r.teamId !== mc.clubId)?.teamId;
      simulateAiMatchday(mc.leagueTable, mc.clubId, hg, ag, oppId);
      mc.matchday += 1;
      mc.reputation = Math.min(99, Math.max(20, mc.reputation + (won ? 3 : draw ? 1 : -2)));
      mc.morale = Math.min(99, Math.max(25, mc.morale + (won ? 6 : draw ? 0 : -5)));
      mc.resultsLog.unshift(`الجولة ${mc.matchday - 1}: ${summary.homeName} ${hg} - ${ag} ${summary.awayName}`);
      mc.resultsLog = mc.resultsLog.slice(0, 18);
      if (mc.matchday > 1 && mc.reputation >= 68 && mc.jobOffers.length < 2) {
        const db = getDb();
        const nextClub = (db.TEAMS || []).find((t) => t.id !== mc.clubId && t.ovr >= 85);
        if (nextClub) {
          mc.jobOffers.push({
            id: `joff_${Date.now()}`,
            clubId: nextClub.id,
            clubName: nextClub.name,
            budgetM: Math.round(nextClub.ovr * 2.2),
          });
        }
      }
    }

    saveStateNow();
  }

  // =========================================================================
  // HUB MODAL UI RENDERER
  // =========================================================================
  function getOverlay() {
    return document.getElementById("myaiFootballHubOverlay");
  }

  function closeHub() {
    const el = getOverlay();
    if (el) el.remove();
    document.body.style.overflow = "";
  }

  function openHub(tabName) {
    window.closeFeature?.();
    hydrateState();
    if (tabName) activeTab = tabName;
    ensureLoaded().then(() => {
      if (getOverlay()) renderHub();
    });

    let overlay = getOverlay();
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "myaiFootballHubOverlay";
      overlay.className = "myai-fhub-overlay";
      document.body.appendChild(overlay);
      document.body.style.overflow = "hidden";
    }
    renderHub();
  }

  function setHeader(points) {
    if (window.myaiSessionState?.user && typeof points === "number") {
      window.myaiSessionState.user.points = points;
      const ptEl = document.querySelector("header .points");
      if (ptEl) ptEl.textContent = "💎 " + Number(points).toLocaleString("en-US") + "　＋";
    }
  }

  function renderHub() {
    const overlay = getOverlay();
    if (!overlay) return;
    const s = hydrateState();
    const db = getDb();
    const club = (db.TEAMS || []).find((t) => t.id === s.managedClubId) || { name: "MY AI FC", ovr: 84, primary: "#ff142e" };
    const userPts = window.myaiSessionState?.user?.points ?? 0;

    const tabs = [
      { id: "kickoff", label: "🏟️ مباراة 3D" },
      { id: "market", label: "💸 سوق الانتقالات" },
      { id: "club", label: "🏛️ النادي والتشكيلة" },
      { id: "tactics", label: "📐 التكتيكات" },
      { id: "cards", label: "🃏 البطاقات والباكات" },
      { id: "player_career", label: "⭐ مهنة اللاعب" },
      { id: "manager_career", label: "👔 مهنة المدرب" },
      { id: "controls", label: "🎮 التحكم والإعدادات" },
    ];

    let bodyHtml = "";
    if (activeTab === "kickoff") bodyHtml = renderKickoffTab();
    else if (activeTab === "market") bodyHtml = renderMarketTab();
    else if (activeTab === "club") bodyHtml = renderClubTab();
    else if (activeTab === "tactics") bodyHtml = renderTacticsTab();
    else if (activeTab === "cards") bodyHtml = renderCardsTab();
    else if (activeTab === "player_career") bodyHtml = renderPlayerCareerTab();
    else if (activeTab === "manager_career") bodyHtml = renderManagerCareerTab();
    else if (activeTab === "controls") bodyHtml = renderControlsTab();

    overlay.innerHTML = `
      <div class="myai-fhub-shell">
        <div class="myai-fhub-topbar">
          <div>
            <h2>⚽ MY AI FOOTBALL PRO</h2>
            <small>${esc(club.name)} · الميزانية <b>${formatM(s.budgetM)}</b> · 💎 <b>${Number(userPts).toLocaleString("en-US")}</b> نقطة</small>
          </div>
          <button type="button" class="feature-close" onclick="MYAIFootballHub.closeHub()">×</button>
        </div>
        <div class="myai-fhub-tabs">
          ${tabs.map((t) => `<button type="button" class="${activeTab === t.id ? "active" : ""}" onclick="MYAIFootballHub.setTab('${t.id}')">${t.label}</button>`).join("")}
        </div>
        <div class="myai-fhub-body" id="myaiFhubBody">${bodyHtml}</div>
      </div>
    `;
  }

  function renderKickoffTab() {
    const s = hydrateState();
    const db = getDb();
    const teams = db.TEAMS || [];
    const roster = getClubRoster(s.managedClubId);
    const avgOvr = Math.round(roster.starters.reduce((a, p) => a + (p.ovr || 78), 0) / (roster.starters.length || 1));
    const tactic = getActiveTactic();
    const preset = getActiveControlPreset();
    const ms = s.matchSettings;

    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>🏟️ إقامة مباراة ثلاثية الأبعاد (بتشكيلتك وتكتيكك الحي)</h3>
          <span class="myai-badge ok">تقييم التشكيلة: ${avgOvr} OVR</span>
        </div>
        <div class="myai-pro-grid2">
          <div>
            <label>ناديـك (تشكيلة النادي المفعّلة)</label>
            <select class="feature-field" onchange="MYAIFootballHub.setManagedClub(this.value)">
              ${teams.map((t) => `<option value="${esc(t.id)}" ${t.id === s.managedClubId ? "selected" : ""}>${esc(t.name)} (OVR ${t.ovr})</option>`).join("")}
            </select>
          </div>
          <div>
            <label>الفريق المنافس</label>
            <select class="feature-field" onchange="MYAIFootballHub.setAwayClub(this.value)">
              ${teams.map((t) => `<option value="${esc(t.id)}" ${t.id === s.awayClubId ? "selected" : ""}>${esc(t.name)} (OVR ${t.ovr})</option>`).join("")}
            </select>
          </div>
          <div>
            <label>الخطة التكتيكية النشطة</label>
            <select class="feature-field" onchange="MYAIFootballHub.selectTacticSlot(Number(this.value))">
              ${s.tactics.slots.map((sl, idx) => `<option value="${idx}" ${idx === s.tactics.activeSlotIndex ? "selected" : ""}>${esc(sl.name)} (${sl.formation})</option>`).join("")}
            </select>
          </div>
          <div>
            <label>تخطيط الأزرار الدائرية</label>
            <select class="feature-field" onchange="MYAIFootballHub.selectControlPreset(this.value)">
              ${s.controls.presets.map((pr) => `<option value="${esc(pr.id)}" ${pr.id === s.controls.activePresetId ? "selected" : ""}>${esc(pr.name)}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>مستوى صعوبة الذكاء الاصطناعي</label>
            <select class="feature-field" onchange="MYAIFootballHub.setMatchSetting('difficulty', this.value)">
              ${["مبتدئ", "سهل", "متوسط", "صعب", "محترف", "أسطوري"].map((d) => `<option value="${d}" ${ms.difficulty === d ? "selected" : ""}>${d}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>مدة الشوط الواحد</label>
            <select class="feature-field" onchange="MYAIFootballHub.setMatchSetting('halfSeconds', Number(this.value))">
              <option value="60" ${ms.halfSeconds === 60 ? "selected" : ""}>60 ثانية (سريعة)</option>
              <option value="90" ${ms.halfSeconds === 90 ? "selected" : ""}>90 ثانية (قياسية)</option>
              <option value="120" ${ms.halfSeconds === 120 ? "selected" : ""}>120 ثانية</option>
              <option value="180" ${ms.halfSeconds === 180 ? "selected" : ""}>180 ثانية</option>
            </select>
          </div>
          <div>
            <label>قوة المنافس ومستوى الحارس</label>
            <div style="display:flex;gap:6px">
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('opponentStrength', this.value)">
                ${["عادي", "قوي", "نخبة"].map((x) => `<option value="${x}" ${(ms.opponentStrength || "قوي") === x ? "selected" : ""}>قوة: ${x}</option>`).join("")}
              </select>
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('gkLevel', this.value)">
                ${["عادي", "متميز", "أسطوري"].map((x) => `<option value="${x}" ${(ms.gkLevel || "متميز") === x ? "selected" : ""}>حارس: ${x}</option>`).join("")}
              </select>
            </div>
          </div>
          <div>
            <label>أسلوب الخصم ومساعدة التحكم</label>
            <div style="display:flex;gap:6px">
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('opponentStyle', this.value)">
                ${["متوازن", "استحواذ", "مرتدات", "ضغط عالٍ"].map((x) => `<option value="${x}" ${(ms.opponentStyle || "متوازن") === x ? "selected" : ""}>${x}</option>`).join("")}
              </select>
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('controlAssist', this.value)">
                ${["يدوي", "شبه مساعد", "مساعد كامل"].map((x) => `<option value="${x}" ${(ms.controlAssist || "شبه مساعد") === x ? "selected" : ""}>تحكم: ${x}</option>`).join("")}
              </select>
            </div>
          </div>
          <div>
            <label>أجواء الملعب وتقريب الكاميرا (<span id="fhubCamZoomVal">${Math.round((ms.cameraZoom || 1) * 100)}</span>%)</label>
            <div style="display:flex;gap:6px;align-items:center">
              <select class="feature-field" style="flex:1;margin:0" onchange="MYAIFootballHub.setMatchSetting('lighting', this.value)">
                <option value="night" ${ms.lighting === "night" ? "selected" : ""}>ليلي ✨</option>
                <option value="day" ${ms.lighting === "day" ? "selected" : ""}>نهاري ☀️</option>
              </select>
              <input type="range" min="0.7" max="1.35" step="0.05" value="${ms.cameraZoom || 1}" style="flex:1" oninput="MYAIFootballHub.setMatchSetting('cameraZoom', Number(this.value));const el=document.getElementById('fhubCamZoomVal');if(el)el.textContent=Math.round(this.value*100)">
            </div>
          </div>
          <div>
            <label>الكاميرا وجودة الجرافيك</label>
            <div style="display:flex;gap:6px">
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('camera', this.value)">
                <option value="broadcast" ${ms.camera === "broadcast" ? "selected" : ""}>بث تلفزيوني</option>
                <option value="dynamic" ${ms.camera === "dynamic" ? "selected" : ""}>ديناميكية</option>
                <option value="close" ${ms.camera === "close" ? "selected" : ""}>قريبة (تفاصيل عالية)</option>
                <option value="wide" ${ms.camera === "wide" ? "selected" : ""}>واسعة</option>
                <option value="tele" ${ms.camera === "tele" ? "selected" : ""}>علوية</option>
                <option value="focus" ${ms.camera === "focus" ? "selected" : ""}>تركيز اللاعب</option>
              </select>
              <select class="feature-field" style="flex:1" onchange="MYAIFootballHub.setMatchSetting('quality', this.value)">
                <option value="low" ${ms.quality === "low" ? "selected" : ""}>منخفض</option>
                <option value="medium" ${ms.quality === "medium" ? "selected" : ""}>متوسط</option>
                <option value="high" ${ms.quality === "high" ? "selected" : ""}>مرتفع</option>
                <option value="ultra" ${ms.quality === "ultra" ? "selected" : ""}>فائق</option>
              </select>
            </div>
          </div>
        </div>
        <div class="myai-pro-grid2" style="margin-top:10px">
          <button type="button" class="primary" onclick="MYAIFootballHub.launchMatch()">⚽ انطلاق المباراة 3D الآن</button>
          <button type="button" class="myai-v3-btn" onclick="MYAIFootballHub.setTab('controls')">🎮 تخصيص الأزرار الدائرية (${esc(preset.name)})</button>
        </div>
      </div>
      <div class="myai-pro-card">
        <h3>📋 التشكيلة الأساسية الجاهزة للملعب (${esc(tactic.formation)})</h3>
        <div class="myai-fhub-mini-grid">
          ${roster.starters.map((p) => `<div class="myai-fhub-pill"><span>#${p.jerseyNo} ${esc(p.name)}</span><b>${p.ovr}</b></div>`).join("")}
        </div>
      </div>
    `;
  }

  function renderMarketTab() {
    const s = hydrateState();
    const db = getDb();
    const roster = getClubRoster(s.managedClubId);
    const ownedNames = new Set([...roster.starters, ...roster.bench].map((x) => x.name));
    const q = (uiState.marketQuery || "").trim().toLowerCase();
    const posF = uiState.marketPos || "all";

    const list = (db.PLAYERS || [])
      .filter((p) => {
        if (posF !== "all") {
          if (posF === "دفاع" && !p.pos.includes("دفاع") && !p.pos.includes("ظهير")) return false;
          else if (posF === "وسط" && !p.pos.includes("وسط") && !p.pos.includes("صانع")) return false;
          else if (posF !== "دفاع" && posF !== "وسط" && !p.pos.includes(posF)) return false;
        }
        if (q) {
          const hay = `${p.name} ${p.nameEn} ${p.club} ${p.pos}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => b.ovr - a.ovr);

    let negModal = "";
    if (uiState.negotiationPlayerId) {
      const target = (db.PLAYERS || []).find((p) => p.id === uiState.negotiationPlayerId);
      if (target) {
        const val = target.valueM || 25;
        const wage = target.wageK || 60;
        const isLoan = uiState.negotiationMode === "loan";
        const askPrice = isLoan ? Math.round(val * 0.22 * 10) / 10 : val;
        const chancePct = Math.min(98, Math.max(12, Math.round(((uiState.bidPriceM / Math.max(1, askPrice)) * 65) + ((uiState.bidWageK / Math.max(10, wage)) * 28))));
        negModal = `
          <div class="myai-pro-card" style="border-color:#facc15;background:linear-gradient(135deg,#251015,#0c0a0f)">
            <div class="myai-pro-row">
              <h3>🤝 مفاوضات ${isLoan ? "الإعارة" : "الانتقال"}: ${esc(target.name)} (${target.ovr} OVR)</h3>
              <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.closeNegotiation()">إلغاء</button>
            </div>
            <p class="myai-v3-muted">القيمة التقديرية: <b>${formatM(askPrice)}</b> · الراتب المطلوب: <b>${wage}K €/أسبوع</b> · نسبة قبول الصفقة الآن: <b id="fhubNegChanceVal" data-ask="${askPrice}" data-wage="${wage}" style="color:${chancePct >= 70 ? "#4ade80" : "#facc15"}">${chancePct}%</b></p>
            <div class="myai-pro-grid2">
              <div>
                <label>العرض المالي للنادي: <b id="fhubNegPriceVal">${formatM(uiState.bidPriceM)}</b></label>
                <input type="range" min="1" max="${Math.max(20, Math.round(val * 1.8))}" step="0.5" value="${uiState.bidPriceM}" oninput="MYAIFootballHub.updateNegotiation('price', Number(this.value))">
              </div>
              <div>
                <label>الراتب الأسبوعي للاعب: <b id="fhubNegWageVal">${uiState.bidWageK}K €</b></label>
                <input type="range" min="10" max="${Math.max(150, wage * 2)}" step="5" value="${uiState.bidWageK}" oninput="MYAIFootballHub.updateNegotiation('wage', Number(this.value))">
              </div>
            </div>
            <button type="button" class="primary feature-action" style="margin-top:8px" onclick="MYAIFootballHub.submitOffer()">📩 تقديم العرض الرسمي وإتمام التفاوض</button>
          </div>
        `;
      }
    }

    return `
      ${negModal}
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>💸 سوق الانتقالات والتفاوض</h3>
          <span class="myai-badge ok">الميزانية: ${formatM(s.budgetM)}</span>
        </div>
        <div class="myai-pro-grid2">
          <input id="fhubMarketSearch" class="feature-field" value="${esc(uiState.marketQuery)}" placeholder="ابحث عن لاعب أو نادي..." oninput="MYAIFootballHub.setMarketFilter(this.value, null)">
          <select class="feature-field" onchange="MYAIFootballHub.setMarketFilter(null, this.value)">
            <option value="all" ${posF === "all" ? "selected" : ""}>كل المراكز</option>
            <option value="حارس مرمى" ${posF === "حارس مرمى" ? "selected" : ""}>حارس مرمى</option>
            <option value="دفاع" ${posF === "دفاع" ? "selected" : ""}>مدافعون</option>
            <option value="وسط" ${posF === "وسط" ? "selected" : ""}>خط الوسط</option>
            <option value="جناح" ${posF === "جناح" ? "selected" : ""}>أجنحة</option>
            <option value="مهاجم" ${posF === "مهاجم" ? "selected" : ""}>مهاجمون</option>
          </select>
        </div>
      </div>

      ${
        (s.incomingBids || []).length
          ? `<div class="myai-pro-card">
              <div class="myai-pro-row">
                <h3>📬 عروض الأندية لشراء / إعارة لاعبيك</h3>
                <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.refreshBids()">🔄 عروض جديدة</button>
              </div>
              <div class="myai-table-list" style="max-height:170px">
                ${s.incomingBids.map((b) => `
                  <div class="myai-list-item myai-pro-row">
                    <div><b>${esc(b.clubName)}</b> يطلب ${b.type === "loan" ? "إعارة" : "شراء"} <b>${esc(b.playerName)}</b> بـ <b>${formatM(b.offerM)}</b></div>
                    <div style="display:flex;gap:6px">
                      <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.respondIncomingBid('${esc(b.id)}', true)">قبول البيع</button>
                      <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.respondIncomingBid('${esc(b.id)}', false)">رفض</button>
                    </div>
                  </div>
                `).join("")}
              </div>
            </div>`
          : ""
      }

      <div class="myai-pro-grid2">
        ${list.slice(0, 30).map((p) => {
          const isOwned = ownedNames.has(p.name);
          const avatar = db.getPlayerAvatarSvgDataUrl ? db.getPlayerAvatarSvgDataUrl(p) : "";
          return `<div class="myai-pro-card" style="padding:10px;margin:0">
            <div style="display:flex;gap:10px;align-items:center">
              <img src="${avatar}" alt="${esc(p.name)}" style="width:54px;height:54px;border-radius:12px;border:1px solid rgba(255,68,88,0.45)">
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between;align-items:center">
                  <b>${esc(p.name)}</b>
                  <span class="myai-badge ok">${p.ovr}</span>
                </div>
                <small class="myai-v3-muted">${esc(p.club)} · ${esc(p.pos)} · ${p.age} سنة</small><br>
                <small style="color:#facc15;font-weight:700">القيمة ${formatM(p.valueM)} · راتب ${p.wageK}K €</small>
              </div>
            </div>
            <div style="display:flex;gap:6px;margin-top:8px">
              ${
                isOwned
                  ? `<span class="myai-badge ok" style="flex:1;text-align:center">✓ في تشكيلتك</span>`
                  : `<button type="button" class="primary" style="flex:1" onclick="MYAIFootballHub.openNegotiation('${esc(p.id)}', 'buy')">🤝 شراء وتفاوض</button>
                     <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.openNegotiation('${esc(p.id)}', 'loan')">استعارة</button>`
              }
            </div>
          </div>`;
        }).join("")}
      </div>

      ${
        (s.transferHistory || []).length
          ? `<div class="myai-pro-card" style="margin-top:10px"><h3>📜 سجل الانتقالات</h3>${s.transferHistory.slice(0, 8).map((h) => `<div class="myai-list-item">${esc(h)}</div>`).join("")}</div>`
          : ""
      }
    `;
  }

  function renderClubTab() {
    const s = hydrateState();
    const db = getDb();
    const roster = getClubRoster(s.managedClubId);
    const club = (db.TEAMS || []).find((t) => t.id === s.managedClubId) || { name: "MY AI FC", ovr: 84 };
    const facCost = (lvl) => (lvl * 18);

    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>🏛️ إدارة نادي ${esc(club.name)}</h3>
          <span class="myai-badge ok">الميزانية ${formatM(s.budgetM)}</span>
        </div>
        <div class="myai-pro-grid2" style="margin-top:6px">
          <div>
            <label>تغيير النادي المُدار</label>
            <select class="feature-field" onchange="MYAIFootballHub.setManagedClub(this.value)">
              ${(db.TEAMS || []).map((t) => `<option value="${esc(t.id)}" ${t.id === s.managedClubId ? "selected" : ""}>${esc(t.name)} (OVR ${t.ovr})</option>`).join("")}
            </select>
          </div>
          <div>
            <label>قائد الفريق (الكابتن)</label>
            <select class="feature-field" onchange="MYAIFootballHub.setRoleAssignment('captainId', this.value)">
              ${roster.starters.map((p) => `<option value="${esc(p.id)}" ${roster.roles.captainId === p.id ? "selected" : ""}>#${p.jerseyNo} ${esc(p.name)}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>منفذ الضربات الحرة والركنيات</label>
            <select class="feature-field" onchange="MYAIFootballHub.setRoleAssignment('fkId', this.value)">
              ${roster.starters.map((p) => `<option value="${esc(p.id)}" ${roster.roles.fkId === p.id ? "selected" : ""}>#${p.jerseyNo} ${esc(p.name)} (PAS ${p.pas})</option>`).join("")}
            </select>
          </div>
          <div>
            <label>منفذ ركلات الجزاء</label>
            <select class="feature-field" onchange="MYAIFootballHub.setRoleAssignment('pkId', this.value)">
              ${roster.starters.map((p) => `<option value="${esc(p.id)}" ${roster.roles.pkId === p.id ? "selected" : ""}>#${p.jerseyNo} ${esc(p.name)} (SHO ${p.sho})</option>`).join("")}
            </select>
          </div>
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>🏗️ تطوير منشآت النادي</h3>
        <div class="myai-pro-grid2">
          <div class="myai-list-item myai-pro-row">
            <div><b>🏋️ مركز التدريب</b><br><small>المستوى ${s.facilities.training} / 5</small></div>
            <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.upgradeFacility('training')">ترقية (${facCost(s.facilities.training)}M)</button>
          </div>
          <div class="myai-list-item myai-pro-row">
            <div><b>🌱 أكاديمية الناشئين</b><br><small>المستوى ${s.facilities.youth} / 5</small></div>
            <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.upgradeFacility('youth')">ترقية (${facCost(s.facilities.youth)}M)</button>
          </div>
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>👕 التشكيلة الأساسية (11 لاعبًا — متصلة بمباراة 3D)</h3>
        <div class="myai-pro-grid2">
          ${roster.starters.map((p, idx) => `
            <div class="myai-list-item myai-pro-row">
              <div><b>#${p.jerseyNo} ${esc(p.name)}</b> <small>(${esc(p.role)} · ${p.ovr} OVR)</small></div>
              <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.swapStarterBench(${idx}, 0)">⇄ استبدال بالبديل #1</button>
            </div>
          `).join("")}
        </div>
        <h3 style="margin-top:12px">🪑 مقاعد البدلاء (${roster.bench.length})</h3>
        <div class="myai-pro-grid2">
          ${roster.bench.map((b, bi) => `
            <div class="myai-list-item myai-pro-row">
              <div><b>${esc(b.name)}</b> <small>(${esc(b.role)} · ${b.ovr} OVR · قيمة ${formatM(b.valueM || 8)})</small></div>
              <div style="display:flex;gap:4px">
                <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.promoteBench(${bi})">▲ للأساسي</button>
                <button type="button" class="myai-mini-btn" onclick="MYAIFootballHub.sellBenchPlayer(${bi})">بيع</button>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }

  function renderTacticsTab() {
    const s = hydrateState();
    const roster = getClubRoster(s.managedClubId);
    const slotIdx = s.tactics.activeSlotIndex || 0;
    const t = getActiveTactic();
    const coords = FORMATIONS_COORDS[t.formation] || FORMATIONS_COORDS["4-3-3"];

    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>📐 استوديو التكتيكات (مربوط مباشرة بالذكاء الاصطناعي في المباراة 3D)</h3>
          <div style="display:flex;gap:5px">
            ${s.tactics.slots.map((sl, i) => `<button type="button" class="myai-mini-btn ${i === slotIdx ? "primary-mini" : ""}" onclick="MYAIFootballHub.selectTacticSlot(${i})">خطة ${i + 1}</button>`).join("")}
          </div>
        </div>
        <div class="myai-pro-grid2" style="margin-top:8px">
          <div>
            <label>الخطة التشكيلية</label>
            <select class="feature-field" onchange="MYAIFootballHub.updateTactic('formation', this.value)">
              ${Object.keys(FORMATIONS_COORDS).map((f) => `<option value="${f}" ${t.formation === f ? "selected" : ""}>${f}</option>`).join("")}
            </select>
          </div>
          <div>
            <label>أسلوب الهجوم</label>
            <select class="feature-field" onchange="MYAIFootballHub.updateTactic('attackStyle', this.value)">
              <option value="balanced" ${t.attackStyle === "balanced" ? "selected" : ""}>متوازن</option>
              <option value="possession" ${t.attackStyle === "possession" ? "selected" : ""}>استحواذ وتمرير قصير</option>
              <option value="counter" ${t.attackStyle === "counter" ? "selected" : ""}>هجمات مرتدة سريعة</option>
              <option value="all_out" ${t.attackStyle === "all_out" ? "selected" : ""}>هجوم ضاغط شامل</option>
            </select>
          </div>
          <div>
            <label>أسلوب الدفاع</label>
            <select class="feature-field" onchange="MYAIFootballHub.updateTactic('defenseStyle', this.value)">
              <option value="balanced" ${t.defenseStyle === "balanced" ? "selected" : ""}>دفاع متوازن</option>
              <option value="high_press" ${t.defenseStyle === "high_press" ? "selected" : ""}>ضغط عالٍ متواصل</option>
              <option value="deep_block" ${t.defenseStyle === "deep_block" ? "selected" : ""}>تكتل دفاعي عميق</option>
            </select>
          </div>
          <div>
            <label>سرعة بناء اللعب (<span id="fhubTacSpeedVal">${t.buildUpSpeed}</span>/10)</label>
            <input type="range" min="1" max="10" value="${t.buildUpSpeed}" oninput="MYAIFootballHub.updateTactic('buildUpSpeed', Number(this.value))">
          </div>
          <div>
            <label>ارتفاع خط الدفاع (<span id="fhubTacLineVal">${t.defenseLine}</span>/10)</label>
            <input type="range" min="1" max="10" value="${t.defenseLine}" oninput="MYAIFootballHub.updateTactic('defenseLine', Number(this.value))">
          </div>
          <div>
            <label>كثافة الضغط (<span id="fhubTacPressVal">${t.pressIntensity}</span>/10)</label>
            <input type="range" min="1" max="10" value="${t.pressIntensity}" oninput="MYAIFootballHub.updateTactic('pressIntensity', Number(this.value))">
          </div>
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>🏃 المراكز على الملعب (اضغط على لاعبين للتبديل · أو غيّر التعليمات)</h3>
        <div class="myai-fhub-pitch">
          ${coords.map((c) => {
            const pl = roster.starters[c.idx] || { name: c.role, ovr: 78, jerseyNo: c.idx + 1 };
            const isSel = uiState.tacticSwapIdx === c.idx;
            const inst = t.instructions?.[c.idx] || "balanced";
            return `
              <button type="button" class="myai-fhub-node ${isSel ? "selected" : ""}" style="left:${c.x}%;top:${c.y}%" onclick="MYAIFootballHub.tapPitchNode(${c.idx})">
                <span>${pl.jerseyNo}</span>
                <b>${esc(pl.name.split(" ")[0])}</b>
                <small>${c.role} · ${INSTRUCTIONS_LABELS[inst]}</small>
              </button>
            `;
          }).join("")}
        </div>
        ${
          uiState.tacticSwapIdx !== null
            ? `<div class="myai-pro-card" style="margin-top:8px;border-color:#facc15">
                <div class="myai-pro-row">
                  <b>تعليمات: ${esc(roster.starters[uiState.tacticSwapIdx]?.name || "")}</b>
                  <select class="feature-field" style="width:auto;margin:0" onchange="MYAIFootballHub.setPlayerInstruction(${uiState.tacticSwapIdx}, this.value)">
                    ${Object.entries(INSTRUCTIONS_LABELS).map(([k, lbl]) => `<option value="${k}" ${(t.instructions?.[uiState.tacticSwapIdx] || "balanced") === k ? "selected" : ""}>${lbl}</option>`).join("")}
                  </select>
                </div>
                <small class="myai-v3-muted">اضغط على لاعب آخر في الملعب لتبديل مركزه مع هذا اللاعب.</small>
              </div>`
            : ""
        }
      </div>
    `;
  }

  function renderCardsTab() {
    const s = hydrateState();
    const db = getDb();
    const ownedMap = s.cards?.owned || {};
    const ownedList = Object.values(ownedMap)
      .map((entry) => {
        const pl = (db.PLAYERS || []).find((p) => p.id === entry.playerId);
        return pl ? { ...pl, cardLevel: entry.level || 0, count: entry.count || 1 } : null;
      })
      .filter(Boolean)
      .filter((c) => uiState.cardsRarityFilter === "all" || c.rarity === uiState.cardsRarityFilter)
      .sort((a, b) => (b.ovr + b.cardLevel) - (a.ovr + a.cardLevel));

    const packs = [
      { tier: "bronze", name: "باقة برونزية", cost: 20, desc: "3 لاعبين (74 - 84 OVR)" },
      { tier: "silver", name: "باقة فضية", cost: 65, desc: "3 لاعبين (78 - 88 OVR)" },
      { tier: "gold", name: "باقة ذهبية", cost: 140, desc: "3 نجوم (83 - 92 OVR)" },
      { tier: "legend", name: "باقة الأساطير", cost: 280, desc: "3 أساطير (87 - 99 OVR)" },
    ];

    return `
      <div class="myai-pro-card">
        <h3>🎁 فتح باقات البطاقات (بنقاط MY AI الحقيقية)</h3>
        <p class="myai-v3-muted">بطاقات MY AI ذات تصميم معدني خاص، قابلة للتطوير والإضافة المباشرة إلى تشكيلة النادي والمباريات 3D.</p>
        <div class="myai-pro-grid2">
          ${packs.map((pk) => `
            <div class="myai-list-item myai-pro-row">
              <div><b>${pk.name}</b><br><small class="myai-v3-muted">${pk.desc}</small></div>
              <button type="button" class="primary" onclick="MYAIFootballHub.openPack('${pk.tier}')">فتح (${pk.cost} 💎)</button>
            </div>
          `).join("")}
        </div>
        ${
          (s.cards.lastOpened || []).length
            ? `<div style="margin-top:10px"><h4>✨ آخر البطاقات المكتسبة:</h4><div class="myai-fhub-cards-grid">${s.cards.lastOpened.map((pid) => {
                const pl = (db.PLAYERS || []).find((p) => p.id === pid);
                if (!pl) return "";
                const svgUrl = db.getPlayerCardSvgDataUrl ? db.getPlayerCardSvgDataUrl(pl, 0) : "";
                return `<div class="myai-fhub-card-item"><img src="${svgUrl}" alt="${esc(pl.name)}"><b>${esc(pl.name)}</b></div>`;
              }).join("")}</div></div>`
            : ""
        }
      </div>

      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>🃏 مجموعتي (${ownedList.length} بطاقة)</h3>
          <div style="display:flex;gap:4px">
            ${[["all", "الكل"], ["legend", "أسطوري"], ["epic", "مميز"], ["rare", "نادر"], ["common", "عادي"]].map(([k, l]) => `<button type="button" class="myai-mini-btn ${uiState.cardsRarityFilter === k ? "primary-mini" : ""}" onclick="MYAIFootballHub.setCardsFilter('${k}')">${l}</button>`).join("")}
          </div>
        </div>
        <div class="myai-fhub-cards-grid" style="margin-top:10px">
          ${ownedList.map((pl) => {
            const svgUrl = db.getPlayerCardSvgDataUrl ? db.getPlayerCardSvgDataUrl(pl, pl.cardLevel) : "";
            return `
              <div class="myai-fhub-card-item">
                <img src="${svgUrl}" alt="${esc(pl.name)}">
                <b>${esc(pl.name)} (+${pl.cardLevel})</b>
                <div style="display:flex;gap:4px;width:100%">
                  <button type="button" class="myai-mini-btn" style="flex:1" onclick="MYAIFootballHub.levelUpCard('${esc(pl.id)}')">⬆ تطوير</button>
                  <button type="button" class="myai-mini-btn primary-mini" style="flex:1" onclick="MYAIFootballHub.equipCardToClub('${esc(pl.id)}')">⚽ للنادي</button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      </div>
    `;
  }

  function renderPlayerCareerTab() {
    const s = hydrateState();
    const db = getDb();
    const pc = s.playerCareer;
    const pro = pc.pro;

    if (!pc.created) {
      return `
        <div class="myai-pro-card">
          <h3>⭐ إنشاء لاعبك المحترف (Player Career Mode)</h3>
          <p class="myai-v3-muted">صمّم لاعبك الخاص وابدأ مسيرتك الاحترافية داخل المباريات ثلاثية الأبعاد، طوّر طاقاتك، واستلم عروض أندية كبرى!</p>
          <div class="myai-pro-grid2">
            <div><label>اسم اللاعب</label><input id="pcName" class="feature-field" value="${esc(pro.name)}"></div>
            <div><label>الجنسية</label><input id="pcNat" class="feature-field" value="${esc(pro.nationality)}"></div>
            <div>
              <label>المركز في الملعب</label>
              <select id="pcPos" class="feature-field">
                <option value="9|مهاجم">مهاجم صريح (ST)</option>
                <option value="8|جناح أيسر">جناح أيسر (LW)</option>
                <option value="10|جناح أيمن">جناح أيمن (RW)</option>
                <option value="7|صانع ألعاب">صانع ألعاب (CAM)</option>
                <option value="6|وسط">لاعب وسط (CM)</option>
                <option value="2|قلب دفاع">قلب دفاع (CB)</option>
              </select>
            </div>
            <div>
              <label>النادي الأول</label>
              <select id="pcClub" class="feature-field">
                ${(db.TEAMS || []).slice(0, 22).map((t) => `<option value="${esc(t.id)}" ${t.id === pc.clubId ? "selected" : ""}>${esc(t.name)}</option>`).join("")}
              </select>
            </div>
            <div>
              <label>تصميم الشعر والحذاء</label>
              <select id="pcHair" class="feature-field">
                <option value="fade">شعر قصير Fade</option>
                <option value="curly">شعر كيرلي</option>
                <option value="long">شعر طويل</option>
                <option value="short">شعر كلاسيكي</option>
              </select>
            </div>
            <div>
              <label>رقم القميص</label>
              <input id="pcNo" type="number" min="1" max="99" class="feature-field" value="${pro.jerseyNo}">
            </div>
          </div>
          <button type="button" class="primary feature-action" onclick="MYAIFootballHub.createProPlayer()">🚀 بدء مسيرة اللاعب الآن</button>
        </div>
      `;
    }

    const curClub = (db.TEAMS || []).find((t) => t.id === pc.clubId) || { name: "MY AI FC" };
    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <div><h3>⭐ ${esc(pro.name)} (#${pro.jerseyNo})</h3><small class="myai-v3-muted">${esc(curClub.name)} · ${esc(pro.pos)} · ${esc(pro.nationality)}</small></div>
          <span class="myai-badge ok">OVR ${pro.ovr}</span>
        </div>
        <div class="myai-v3-stat" style="margin:10px 0">
          <div><strong>${pc.apps}</strong>مباريات</div>
          <div><strong>${pc.goals}</strong>أهداف</div>
          <div><strong>${pc.assists}</strong>أسيست</div>
          <div><strong>${pc.avgRating}</strong>التقييم</div>
        </div>
        <div class="myai-pro-grid2">
          <button type="button" class="primary" onclick="MYAIFootballHub.playCareerMatch('player')">⚽ خوض المباراة القادمة (3D بالمحترف)</button>
          <button type="button" class="myai-v3-btn" onclick="MYAIFootballHub.trainProPlayer()">🏋️ حصة تدريب خاصة (+XP)</button>
        </div>
      </div>

      ${
        (pc.transferOffers || []).length
          ? `<div class="myai-pro-card"><h3>📩 عروض انتقال لك من أندية جديدة</h3>
              ${pc.transferOffers.map((o) => `
                <div class="myai-list-item myai-pro-row">
                  <div><b>${esc(o.clubName)}</b> · راتب ${o.wageK}K € · دور: ${esc(o.role)}</div>
                  <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.acceptProOffer('${esc(o.id)}')">انتقال للنادي</button>
                </div>
              `).join("")}
            </div>`
          : ""
      }

      <div class="myai-pro-card">
        <h3>📊 سجل مباريات المسيرة</h3>
        <div class="myai-table-list" style="max-height:200px">
          ${(pc.log || []).map((l) => `<div class="myai-list-item">${esc(l.match)} · أهداف: ${l.goals} · أسيست: ${l.assists} · تقييم: <b>${l.rating}</b></div>`).join("") || '<p class="myai-v3-muted">العب أول مباراة في مسيرتك لبدء تسجيل أرقامك!</p>'}
        </div>
      </div>
    `;
  }

  function renderManagerCareerTab() {
    const s = hydrateState();
    const db = getDb();
    const mc = s.managerCareer;
    if (!mc.active) {
      return `
        <div class="myai-pro-card">
          <h3>👔 بدء مهنة المدرب (Manager Career Mode)</h3>
          <p class="myai-v3-muted">اختر ناديك، قدِ التشكيلة في جدول دوري حقيقي، تحكم في الصفقات والميزانية، العب مبارياتك في 3D أو حاكِ الجولات!</p>
          <select id="mcStartClub" class="feature-field">
            ${(db.TEAMS || []).filter((t) => t.league !== "national").map((t) => `<option value="${esc(t.id)}" ${t.id === s.managedClubId ? "selected" : ""}>${esc(t.name)} (OVR ${t.ovr})</option>`).join("")}
          </select>
          <button type="button" class="primary feature-action" onclick="MYAIFootballHub.startManagerCareer()">🏁 توقيع العقد وبدء الموسم</button>
        </div>
      `;
    }

    const curClub = (db.TEAMS || []).find((t) => t.id === mc.clubId) || { name: "MY AI FC" };
    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <div><h3>👔 المدير الفني: ${esc(curClub.name)}</h3><small class="myai-v3-muted">الجولة ${mc.matchday} · هدف الإدارة: ${esc(mc.boardTarget)}</small></div>
          <span class="myai-badge ok">السمعة ${mc.reputation} · معنويات ${mc.morale}%</span>
        </div>
        <div class="myai-pro-grid2" style="margin-top:8px">
          <button type="button" class="primary" onclick="MYAIFootballHub.playCareerMatch('manager')">⚽ لعب مباراة الدوري (3D)</button>
          <button type="button" class="myai-v3-btn" onclick="MYAIFootballHub.simManagerMatchday()">⚡ محاكاة سريعة للجولة</button>
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>🏆 جدول ترتيب الدوري</h3>
        <div style="overflow:auto">
          <table class="myai-fhub-table">
            <thead><tr><th>#</th><th>النادي</th><th>لعب</th><th>ف</th><th>ت</th><th>خ</th><th>فارق</th><th>نقاط</th></tr></thead>
            <tbody>
              ${(mc.leagueTable || []).map((r, i) => `
                <tr class="${r.teamId === mc.clubId ? "me" : ""}">
                  <td>${i + 1}</td><td>${esc(r.name)}</td><td>${r.played}</td><td>${r.won}</td><td>${r.drawn}</td><td>${r.lost}</td><td>${r.gf - r.ga}</td><td><b>${r.pts}</b></td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </div>

      ${
        (mc.jobOffers || []).length
          ? `<div class="myai-pro-card"><h3>📩 عروض تدريب من أندية أخرى</h3>
              ${mc.jobOffers.map((o) => `
                <div class="myai-list-item myai-pro-row">
                  <div><b>${esc(o.clubName)}</b> · ميزانية ${formatM(o.budgetM)}</div>
                  <button type="button" class="myai-mini-btn primary-mini" onclick="MYAIFootballHub.acceptManagerOffer('${esc(o.id)}')">قبول العقد</button>
                </div>
              `).join("")}
            </div>`
          : ""
      }
    `;
  }

  function renderControlsTab() {
    const s = hydrateState();
    const pr = getActiveControlPreset();
    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>🎮 تخصيص الأزرار الدائرية وعصا التحكم</h3>
          <select class="feature-field" style="width:auto;margin:0" onchange="MYAIFootballHub.selectControlPreset(this.value)">
            ${s.controls.presets.map((x) => `<option value="${esc(x.id)}" ${x.id === pr.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}
          </select>
        </div>

        <div id="fhubCtrlPreview" class="myai-fhub-ctrl-preview" style="opacity:${(pr.opacity / 100).toFixed(2)}">
          <div id="fhubPreviewJoy" class="myai-fhub-preview-joy" style="width:${Math.round(pr.joySize * 0.75)}px;height:${Math.round(pr.joySize * 0.75)}px">
            <div class="myai-fhub-preview-knob"></div>
          </div>
          <div class="myai-fhub-preview-arc">
            <div class="myai-fhub-preview-btn fhub-pv-main" style="width:${Math.round(pr.btnSize * 0.72)}px;height:${Math.round(pr.btnSize * 0.72)}px;background:#7f1d1d;border-color:#ff475d">⚡</div>
            <div class="myai-fhub-preview-btn fhub-pv-sub" style="width:${Math.round(pr.btnSize * 0.64)}px;height:${Math.round(pr.btnSize * 0.64)}px;background:#0c4a6e;border-color:#38bdf8">🎯</div>
            <div class="myai-fhub-preview-btn fhub-pv-sub" style="width:${Math.round(pr.btnSize * 0.64)}px;height:${Math.round(pr.btnSize * 0.64)}px;background:#713f12;border-color:#facc15">🪽</div>
            <div class="myai-fhub-preview-btn fhub-pv-sm" style="width:${Math.round(pr.btnSize * 0.6)}px;height:${Math.round(pr.btnSize * 0.6)}px;background:#581c87;border-color:#c084fc">✨</div>
          </div>
        </div>

        <div class="myai-pro-grid2">
          <div>
            <label>حجم الأزرار الدائرية (<span id="fhubCtrlBtnSizeVal">${pr.btnSize}</span>px)</label>
            <input type="range" min="48" max="82" value="${pr.btnSize}" oninput="MYAIFootballHub.updateControlField('btnSize', Number(this.value))">
          </div>
          <div>
            <label>حجم عصا التحكم الدائرية (<span id="fhubCtrlJoySizeVal">${pr.joySize}</span>px)</label>
            <input type="range" min="88" max="148" value="${pr.joySize}" oninput="MYAIFootballHub.updateControlField('joySize', Number(this.value))">
          </div>
          <div>
            <label>شفافية الأزرار (<span id="fhubCtrlOpacityVal">${pr.opacity}</span>%)</label>
            <input type="range" min="45" max="100" value="${pr.opacity}" oninput="MYAIFootballHub.updateControlField('opacity', Number(this.value))">
          </div>
          <div>
            <label>حساسية عصا التحرك (<span id="fhubCtrlSensitivityVal">${pr.sensitivity}</span>%)</label>
            <input type="range" min="65" max="140" value="${pr.sensitivity}" oninput="MYAIFootballHub.updateControlField('sensitivity', Number(this.value))">
          </div>
          <div>
            <label>إزاحة رأسية (<span id="fhubCtrlOffsetYVal">${pr.offsetY}</span>px)</label>
            <input type="range" min="0" max="28" value="${pr.offsetY}" oninput="MYAIFootballHub.updateControlField('offsetY', Number(this.value))">
          </div>
          <div>
            <label>سرعة اللعب والفيزياء</label>
            <select class="feature-field" onchange="MYAIFootballHub.setMatchSetting('gameSpeed', this.value)">
              <option value="relaxed" ${s.matchSettings.gameSpeed === "relaxed" ? "selected" : ""}>هادئة تكتيكية</option>
              <option value="normal" ${s.matchSettings.gameSpeed === "normal" ? "selected" : ""}>قياسية متوازنة</option>
              <option value="fast" ${s.matchSettings.gameSpeed === "fast" ? "selected" : ""}>سريعة ديناميكية</option>
            </select>
          </div>
        </div>
        <button type="button" class="primary feature-action" style="margin-top:8px" onclick="MYAIFootballHub.resetControls()">↺ استعادة الافتراضي لهذا المخطط</button>
      </div>
    `;
  }

  // =========================================================================
  // INTERACTION HANDLERS
  // =========================================================================
  const API = {
    openHub,
    closeHub,
    ensureLoaded,
    getState: hydrateState,
    getActiveMatchPayload,
    recordMatchOutcome,
    setTab(t) {
      activeTab = t;
      sfx("click");
      renderHub();
    },
    setManagedClub(clubId) {
      const s = hydrateState();
      s.managedClubId = clubId;
      getClubRoster(clubId);
      refreshIncomingBids();
      saveStateNow();
      renderHub();
    },
    setAwayClub(clubId) {
      const s = hydrateState();
      s.awayClubId = clubId;
      saveStateNow();
    },
    setMatchSetting(k, v) {
      const s = hydrateState();
      s.matchSettings[k] = v;
      saveStateNow();
    },
    launchMatch(overrides) {
      const payload = getActiveMatchPayload(overrides);
      closeHub();
      if (typeof window.myaiOpenFootball3D === "function") {
        window.myaiOpenFootball3D(payload);
      } else {
        say("جارٍ تجهيز محرك MY AI FOOTBALL 3D...");
      }
    },
    // Market
    setMarketFilter(q, pos) {
      if (q !== null) uiState.marketQuery = q;
      if (pos !== null) uiState.marketPos = pos;
      renderHub();
      if (q !== null) {
        const el = document.getElementById("fhubMarketSearch");
        if (el) {
          el.focus();
          el.setSelectionRange(el.value.length, el.value.length);
        }
      }
    },
    openNegotiation(playerId, mode) {
      const db = getDb();
      const pl = (db.PLAYERS || []).find((p) => p.id === playerId);
      if (!pl) return;
      uiState.negotiationPlayerId = playerId;
      uiState.negotiationMode = mode || "buy";
      uiState.bidPriceM = mode === "loan" ? Math.round((pl.valueM || 20) * 0.22 * 10) / 10 : pl.valueM || 25;
      uiState.bidWageK = pl.wageK || 60;
      sfx("click");
      renderHub();
    },
    closeNegotiation() {
      uiState.negotiationPlayerId = null;
      renderHub();
    },
    updateNegotiation(field, val) {
      if (field === "price") uiState.bidPriceM = val;
      if (field === "wage") uiState.bidWageK = val;
      const pEl = document.getElementById("fhubNegPriceVal");
      if (pEl) pEl.textContent = formatM(uiState.bidPriceM);
      const wEl = document.getElementById("fhubNegWageVal");
      if (wEl) wEl.textContent = `${uiState.bidWageK}K €`;
      const cEl = document.getElementById("fhubNegChanceVal");
      if (cEl) {
        const askPrice = Number(cEl.dataset.ask || 25);
        const wage = Number(cEl.dataset.wage || 60);
        const pct = Math.min(98, Math.max(12, Math.round(((uiState.bidPriceM / Math.max(1, askPrice)) * 65) + ((uiState.bidWageK / Math.max(10, wage)) * 28))));
        cEl.textContent = `${pct}%`;
        cEl.style.color = pct >= 70 ? "#4ade80" : "#facc15";
      }
    },
    submitOffer() {
      const s = hydrateState();
      const db = getDb();
      const pl = (db.PLAYERS || []).find((p) => p.id === uiState.negotiationPlayerId);
      if (!pl) return;
      if (s.budgetM < uiState.bidPriceM) {
        sfx("wrong");
        say("ميزانية النادي غير كافية لهذا العرض المالي.");
        return;
      }
      const isLoan = uiState.negotiationMode === "loan";
      const ask = isLoan ? Math.round((pl.valueM || 20) * 0.22 * 10) / 10 : pl.valueM || 25;
      const ratio = (uiState.bidPriceM / Math.max(1, ask)) * 0.72 + (uiState.bidWageK / Math.max(10, pl.wageK || 50)) * 0.3;
      if (ratio < 0.85) {
        sfx("wrong");
        const counter = Math.round(ask * 1.05 * 10) / 10;
        uiState.bidPriceM = counter;
        say(`❌ النادي رفض العرض! السعر المقابل المقترح: ${formatM(counter)}`);
        renderHub();
        return;
      }

      s.budgetM = Math.round((s.budgetM - uiState.bidPriceM) * 10) / 10;
      const roster = getClubRoster(s.managedClubId);
      const added = {
        id: pl.id,
        name: pl.name,
        pos: pl.pos,
        role: pl.posShort || "ST",
        ovr: pl.ovr,
        pac: pl.pac,
        sho: pl.sho,
        pas: pl.pas,
        dri: pl.dri,
        def: pl.def,
        phy: pl.phy,
        stam: pl.stam,
        heightCm: pl.heightCm,
        weightKg: pl.weightKg,
        stats15: pl.stats15,
        jerseyNo: pl.jerseyNo,
        skinHex: pl.skinHex,
        hairHex: pl.hairHex,
        hairStyle: pl.hairStyle,
        bootColor: pl.bootColor,
        rarity: pl.rarity,
        skillMoves: pl.skillMoves,
        weakFoot: pl.weakFoot,
        contractYears: isLoan ? 1 : 4,
        wageK: uiState.bidWageK,
        valueM: pl.valueM,
      };
      // Automatically place high-rated signing into Starting XI slot matching position
      const targetSlot = pl.pos.includes("حارس") ? 0 : pl.pos.includes("دفاع") || pl.pos.includes("ظهير") ? 2 : pl.pos.includes("وسط") || pl.pos.includes("صانع") ? 6 : 9;
      const displaced = roster.starters[targetSlot];
      roster.starters[targetSlot] = { ...added, role: displaced?.role || added.role };
      if (displaced) roster.bench.unshift(displaced);
      s.transferHistory.unshift(`${isLoan ? "استعارة" : "تعاقد مع"} ${pl.name} مقابل ${formatM(uiState.bidPriceM)}`);
      s.transferHistory = s.transferHistory.slice(0, 20);
      uiState.negotiationPlayerId = null;
      sfx("coin");
      say(`✅ تمت الصفقة! انضم ${pl.name} إلى التشكيلة الأساسية مباشرة!`);
      saveStateNow();
      renderHub();
    },
    refreshBids() {
      refreshIncomingBids();
      saveStateNow();
      renderHub();
    },
    respondIncomingBid(bidId, accept) {
      const s = hydrateState();
      const idx = (s.incomingBids || []).findIndex((b) => b.id === bidId);
      if (idx < 0) return;
      const bid = s.incomingBids[idx];
      s.incomingBids.splice(idx, 1);
      if (accept) {
        const roster = getClubRoster(s.managedClubId);
        const si = roster.starters.findIndex((p) => p.id === bid.playerId || p.name === bid.playerName);
        if (si > 0 && roster.bench.length) {
          const rep = roster.bench.shift();
          roster.starters[si] = { ...rep, role: roster.starters[si].role };
        }
        s.budgetM = Math.round((s.budgetM + bid.offerM) * 10) / 10;
        s.transferHistory.unshift(`بيع ${bid.playerName} إلى ${bid.clubName} بـ ${formatM(bid.offerM)}`);
        sfx("coin");
        say(`💰 تم بيع ${bid.playerName} وإضافة ${formatM(bid.offerM)} لميزانيتك.`);
      } else {
        say("تم رفض العرض والإبقاء على اللاعب.");
      }
      saveStateNow();
      renderHub();
    },
    // Club & Squad
    setRoleAssignment(roleKey, playerId) {
      const roster = getClubRoster();
      roster.roles[roleKey] = playerId;
      saveStateNow();
    },
    upgradeFacility(key) {
      const s = hydrateState();
      const cur = s.facilities[key] || 1;
      if (cur >= 5) {
        say("المنشأة في أقصى مستوى (5/5)!");
        return;
      }
      const cost = cur * 18;
      if (s.budgetM < cost) {
        sfx("wrong");
        say(`تحتاج إلى ${cost}M € للترقية.`);
        return;
      }
      s.budgetM = Math.round((s.budgetM - cost) * 10) / 10;
      s.facilities[key] = cur + 1;
      sfx("coin");
      say("✅ تم تطوير منشأة النادي بنجاح!");
      saveStateNow();
      renderHub();
    },
    swapStarterBench(starterIdx, benchIdx) {
      const roster = getClubRoster();
      if (!roster.bench[benchIdx] || !roster.starters[starterIdx]) return;
      const a = roster.starters[starterIdx];
      const b = roster.bench[benchIdx];
      roster.starters[starterIdx] = { ...b, role: a.role };
      roster.bench[benchIdx] = a;
      sfx("click");
      saveStateNow();
      renderHub();
    },
    promoteBench(benchIdx) {
      const roster = getClubRoster();
      const b = roster.bench[benchIdx];
      if (!b) return;
      const targetIdx = b.role === "GK" ? 0 : b.role === "CB" ? 2 : b.role === "CM" || b.role === "CAM" ? 6 : 9;
      API.swapStarterBench(targetIdx, benchIdx);
    },
    sellBenchPlayer(benchIdx) {
      const s = hydrateState();
      const roster = getClubRoster(s.managedClubId);
      const pl = roster.bench[benchIdx];
      if (!pl) return;
      const val = pl.valueM || 6;
      roster.bench.splice(benchIdx, 1);
      s.budgetM = Math.round((s.budgetM + val) * 10) / 10;
      sfx("coin");
      say(`تم بيع ${pl.name} مقابل ${formatM(val)}`);
      saveStateNow();
      renderHub();
    },
    // Tactics
    selectTacticSlot(idx) {
      const s = hydrateState();
      s.tactics.activeSlotIndex = idx;
      uiState.tacticSwapIdx = null;
      sfx("click");
      saveStateNow();
      renderHub();
    },
    updateTactic(field, value) {
      const t = getActiveTactic();
      t[field] = value;
      saveStateNow();
      if (field === "formation") renderHub();
      else {
        const map = { buildUpSpeed: "fhubTacSpeedVal", defenseLine: "fhubTacLineVal", pressIntensity: "fhubTacPressVal" };
        const el = map[field] ? document.getElementById(map[field]) : null;
        if (el) el.textContent = String(value);
      }
    },
    tapPitchNode(idx) {
      if (uiState.tacticSwapIdx === null) {
        uiState.tacticSwapIdx = idx;
        sfx("click");
        renderHub();
        return;
      }
      if (uiState.tacticSwapIdx === idx) {
        uiState.tacticSwapIdx = null;
        renderHub();
        return;
      }
      const roster = getClubRoster();
      const a = roster.starters[uiState.tacticSwapIdx];
      const b = roster.starters[idx];
      if (a && b) {
        const tmpRole = a.role;
        roster.starters[uiState.tacticSwapIdx] = { ...b, role: tmpRole };
        roster.starters[idx] = { ...a, role: b.role };
        sfx("correct");
        saveStateNow();
      }
      uiState.tacticSwapIdx = null;
      renderHub();
    },
    setPlayerInstruction(idx, val) {
      const t = getActiveTactic();
      if (!t.instructions) t.instructions = {};
      t.instructions[idx] = val;
      saveStateNow();
      renderHub();
    },
    // Cards & Packs
    async openPack(tier) {
      const s = hydrateState();
      const db = getDb();
      let minOvr = tier === "legend" ? 87 : tier === "gold" ? 83 : tier === "silver" ? 78 : 74;
      let maxOvr = tier === "legend" ? 99 : tier === "gold" ? 92 : tier === "silver" ? 88 : 84;
      try {
        if (typeof window.myaiApiFetch === "function" && navigator.onLine !== false) {
          const res = await window.myaiApiFetch("/api/football/open-pack", {
            method: "POST",
            body: JSON.stringify({ tier }),
          });
          setHeader(res.points);
          if (res.packMeta) {
            minOvr = res.packMeta.minOvr;
            maxOvr = res.packMeta.maxOvr;
          }
        }
      } catch (err) {
        sfx("wrong");
        say(err?.message || "تعذر فتح الباقة الآن.");
        return;
      }
      const pool = (db.getPackPool ? db.getPackPool(minOvr, maxOvr) : db.PLAYERS || []);
      const drawn = [];
      for (let i = 0; i < 3; i++) {
        const card = pool[Math.floor(Math.random() * pool.length)] || db.PLAYERS[i];
        if (!card) continue;
        drawn.push(card.id);
        if (!s.cards.owned[card.id]) {
          s.cards.owned[card.id] = { playerId: card.id, level: 0, count: 1, acquiredAt: Date.now() };
        } else {
          s.cards.owned[card.id].count = (s.cards.owned[card.id].count || 1) + 1;
        }
      }
      s.cards.lastOpened = drawn;
      sfx("packOpen");
      say("🎉 تم فتح الباقة وإضافة 3 بطاقات لمجموعتك!");
      saveStateNow();
      renderHub();
    },
    setCardsFilter(r) {
      uiState.cardsRarityFilter = r;
      renderHub();
    },
    levelUpCard(playerId) {
      const s = hydrateState();
      const entry = s.cards.owned[playerId];
      if (!entry) return;
      if (entry.level >= 5) {
        say("البطاقة في أعلى مستوى (+5)!");
        return;
      }
      if (s.budgetM < 4) {
        say("تحتاج إلى 4M € من ميزانية النادي لتطوير البطاقة.");
        return;
      }
      s.budgetM = Math.round((s.budgetM - 4) * 10) / 10;
      entry.level += 1;
      sfx("coin");
      saveStateNow();
      renderHub();
    },
    equipCardToClub(playerId) {
      const s = hydrateState();
      const db = getDb();
      const pl = (db.PLAYERS || []).find((p) => p.id === playerId);
      const entry = s.cards.owned[playerId];
      if (!pl || !entry) return;
      const boost = entry.level || 0;
      const roster = getClubRoster(s.managedClubId);
      const idx = pl.pos.includes("حارس") ? 0 : pl.pos.includes("دفاع") || pl.pos.includes("ظهير") ? 2 : pl.pos.includes("وسط") || pl.pos.includes("صانع") ? 7 : 9;
      if (!roster.starters.some((x) => x.id === pl.id)) {
        const old = roster.starters[idx];
        roster.starters[idx] = {
          ...pl,
          ovr: Math.min(99, pl.ovr + boost),
          pac: Math.min(99, pl.pac + boost),
          sho: Math.min(99, pl.sho + boost),
          pas: Math.min(99, pl.pas + boost),
          dri: Math.min(99, pl.dri + boost),
          def: Math.min(99, pl.def + boost),
          heightCm: pl.heightCm || 180,
          weightKg: pl.weightKg || 76,
          stats15: pl.stats15 ? Object.fromEntries(Object.entries(pl.stats15).map(([k, v]) => [k, Math.min(99, Number(v) + boost)])) : undefined,
          role: old?.role || pl.posShort || "ST",
        };
        if (old) roster.bench.unshift(old);
        sfx("correct");
        say(`✅ تم تفعيل بطاقة ${pl.name} في التشكيلة الأساسية لمباريات 3D!`);
        saveStateNow();
      } else {
        say(`${pl.name} موجود بالفعل في التشكيلة الأساسية!`);
      }
    },
    // Player Career
    createProPlayer() {
      const s = hydrateState();
      const name = (document.getElementById("pcName")?.value || "بطل MY AI").trim();
      const nat = (document.getElementById("pcNat")?.value || "مصر").trim();
      const [roleIdxStr, posName] = String(document.getElementById("pcPos")?.value || "9|مهاجم").split("|");
      const clubId = document.getElementById("pcClub")?.value || "al_ahly_eg";
      const hair = document.getElementById("pcHair")?.value || "fade";
      const jerseyNo = Math.max(1, Math.min(99, Number(document.getElementById("pcNo")?.value || 99)));
      s.playerCareer.created = true;
      s.playerCareer.clubId = clubId;
      s.playerCareer.pro.name = name;
      s.playerCareer.pro.nationality = nat;
      s.playerCareer.pro.roleIdx = Number(roleIdxStr) || 9;
      s.playerCareer.pro.pos = posName || "مهاجم";
      s.playerCareer.pro.hairStyle = hair;
      s.playerCareer.pro.jerseyNo = jerseyNo;
      s.managedClubId = clubId;
      sfx("fanfare");
      saveStateNow();
      renderHub();
    },
    trainProPlayer() {
      const s = hydrateState();
      const pc = s.playerCareer;
      pc.xp += 140;
      while (pc.xp >= 250 && pc.pro.ovr < 96) {
        pc.xp -= 250;
        pc.pro.ovr += 1;
        pc.pro.pac = Math.min(99, pc.pro.pac + 1);
        pc.pro.sho = Math.min(99, pc.pro.sho + 1);
        pc.pro.dri = Math.min(99, pc.pro.dri + 1);
      }
      sfx("coin");
      say(`🏋️ حصة تدريبية ممتازة! XP الحالي: ${pc.xp}/250 · التقييم: ${pc.pro.ovr} OVR`);
      saveStateNow();
      renderHub();
    },
    acceptProOffer(offerId) {
      const s = hydrateState();
      const pc = s.playerCareer;
      const off = (pc.transferOffers || []).find((o) => o.id === offerId);
      if (!off) return;
      pc.clubId = off.clubId;
      pc.wageK = off.wageK;
      pc.transferOffers = [];
      s.managedClubId = off.clubId;
      sfx("fanfare");
      say(`🎉 وقّعت عقدًا رسميًا مع ${off.clubName}!`);
      saveStateNow();
      renderHub();
    },
    // Manager Career
    startManagerCareer() {
      const s = hydrateState();
      const clubId = document.getElementById("mcStartClub")?.value || "liverpool";
      s.managerCareer = {
        active: true,
        clubId,
        season: 1,
        matchday: 1,
        reputation: 66,
        morale: 82,
        trophies: 0,
        boardTarget: "المنافسة على اللقب",
        leagueTable: buildLeagueStandings(clubId),
        jobOffers: [],
        resultsLog: [],
      };
      s.managedClubId = clubId;
      sfx("fanfare");
      saveStateNow();
      renderHub();
    },
    simManagerMatchday() {
      const s = hydrateState();
      const mc = s.managerCareer;
      const opp = mc.leagueTable[(mc.matchday) % mc.leagueTable.length] || mc.leagueTable[1];
      const mine = mc.leagueTable.find((r) => r.teamId === mc.clubId) || { ovr: 82 };
      const hg = Math.max(0, Math.floor(Math.random() * 3 + (mine.ovr > (opp?.ovr || 80) ? 0.6 : 0)));
      const ag = Math.max(0, Math.floor(Math.random() * 2.5));
      recordMatchOutcome({
        homeName: mine.name || "فريقك",
        awayName: opp?.name || "المنافس",
        homeGoals: hg,
        awayGoals: ag,
        awayTeamId: opp?.teamId,
        careerMode: "manager",
      });
      sfx(hg > ag ? "fanfare" : "whistle");
      say(`نتيجة الجولة: ${mine.name || "فريقك"} ${hg} - ${ag} ${opp?.name || "المنافس"}`);
      renderHub();
    },
    acceptManagerOffer(offerId) {
      const s = hydrateState();
      const mc = s.managerCareer;
      const off = (mc.jobOffers || []).find((o) => o.id === offerId);
      if (!off) return;
      mc.clubId = off.clubId;
      mc.leagueTable = buildLeagueStandings(off.clubId);
      mc.jobOffers = [];
      mc.matchday = 1;
      s.managedClubId = off.clubId;
      s.budgetM = off.budgetM;
      sfx("fanfare");
      say(`🤝 أصبحت المدير الفني الجديد لنادي ${off.clubName}!`);
      saveStateNow();
      renderHub();
    },
    playCareerMatch(mode) {
      const s = hydrateState();
      const db = getDb();
      if (mode === "player") {
        const pool = (db.TEAMS || []).filter((t) => t.id !== s.playerCareer.clubId && t.league !== "national");
        const away = pool[Math.floor(Math.random() * pool.length)] || db.TEAMS[1];
        API.launchMatch({ homeTeamId: s.playerCareer.clubId, awayTeamId: away.id, careerMode: "player" });
      } else {
        const mc = s.managerCareer;
        const opp = mc.leagueTable.filter((r) => r.teamId !== mc.clubId)[(mc.matchday - 1) % Math.max(1, mc.leagueTable.length - 1)] || { teamId: "real_madrid" };
        API.launchMatch({ homeTeamId: mc.clubId, awayTeamId: opp.teamId, careerMode: "manager" });
      }
    },
    // Controls
    selectControlPreset(id) {
      const s = hydrateState();
      s.controls.activePresetId = id;
      sfx("click");
      saveStateNow();
      renderHub();
    },
    updateControlField(field, val) {
      const pr = getActiveControlPreset();
      pr[field] = val;
      saveStateNow();
      const labelMap = {
        btnSize: "fhubCtrlBtnSizeVal",
        joySize: "fhubCtrlJoySizeVal",
        opacity: "fhubCtrlOpacityVal",
        sensitivity: "fhubCtrlSensitivityVal",
        offsetY: "fhubCtrlOffsetYVal",
      };
      const lbl = labelMap[field] ? document.getElementById(labelMap[field]) : null;
      if (lbl) lbl.textContent = String(val);
      const pv = document.getElementById("fhubCtrlPreview");
      if (pv) pv.style.opacity = (pr.opacity / 100).toFixed(2);
      const joy = document.getElementById("fhubPreviewJoy");
      if (joy) {
        const s = Math.round(pr.joySize * 0.75) + "px";
        joy.style.width = s;
        joy.style.height = s;
      }
      document.querySelectorAll(".fhub-pv-main").forEach((el) => {
        const s = Math.round(pr.btnSize * 0.72) + "px";
        el.style.width = s;
        el.style.height = s;
      });
      document.querySelectorAll(".fhub-pv-sub").forEach((el) => {
        const s = Math.round(pr.btnSize * 0.64) + "px";
        el.style.width = s;
        el.style.height = s;
      });
      document.querySelectorAll(".fhub-pv-sm").forEach((el) => {
        const s = Math.round(pr.btnSize * 0.6) + "px";
        el.style.width = s;
        el.style.height = s;
      });
    },
    resetControls() {
      const s = hydrateState();
      const curId = s.controls.activePresetId;
      const def = DEFAULT_PRESETS.find((x) => x.id === curId) || DEFAULT_PRESETS[0];
      const idx = s.controls.presets.findIndex((x) => x.id === curId);
      if (idx >= 0) s.controls.presets[idx] = clone(def);
      sfx("click");
      saveStateNow();
      renderHub();
    },
  };

  window.MYAIFootballHub = API;
  // Auto-sync once at boot in background
  setTimeout(() => ensureLoaded().catch(() => {}), 900);
})();
