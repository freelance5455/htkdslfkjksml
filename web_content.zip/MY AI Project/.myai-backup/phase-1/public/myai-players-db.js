/* MY AI World Football Players & Teams Curated Database + Interactive Explorer */
(function () {
  "use strict";

  const LEAGUES = [
    { id: "all", name: "جميع الدوريات والمنتخبات" },
    { id: "premier_league", name: "الدوري الإنجليزي الممتاز" },
    { id: "la_liga", name: "الدوري الإسباني" },
    { id: "serie_a", name: "الدوري الإيطالي" },
    { id: "bundesliga", name: "الدوري الألماني" },
    { id: "ligue_1", name: "الدوري الفرنسي" },
    { id: "saudi_pro", name: "دوري روشن السعودي" },
    { id: "egyptian_pro", name: "الدوري المصري الممتاز" },
    { id: "national", name: "المنتخبات الدولية" },
    { id: "legends", name: "نجوم الأساطير" },
  ];

  const TEAMS = [
    { id: "liverpool", name: "ليفربول", nameEn: "Liverpool", league: "premier_league", country: "إنجلترا", primary: "#c8102e", secondary: "#f6eb61", ovr: 86, formation: "4-3-3" },
    { id: "man_city", name: "مانشستر سيتي", nameEn: "Manchester City", league: "premier_league", country: "إنجلترا", primary: "#6cabdd", secondary: "#1c2c5b", ovr: 88, formation: "4-3-3" },
    { id: "arsenal", name: "آرسنال", nameEn: "Arsenal", league: "premier_league", country: "إنجلترا", primary: "#ef0107", secondary: "#ffffff", ovr: 86, formation: "4-3-3" },
    { id: "chelsea", name: "تشيلسي", nameEn: "Chelsea", league: "premier_league", country: "إنجلترا", primary: "#034694", secondary: "#ffffff", ovr: 83, formation: "4-2-3-1" },
    { id: "man_utd", name: "مانشستر يونايتد", nameEn: "Manchester United", league: "premier_league", country: "إنجلترا", primary: "#da291c", secondary: "#fbe122", ovr: 83, formation: "4-2-3-1" },
    { id: "real_madrid", name: "ريال مدريد", nameEn: "Real Madrid", league: "la_liga", country: "إسبانيا", primary: "#f5f5f5", secondary: "#d4af37", ovr: 89, formation: "4-3-3" },
    { id: "barcelona", name: "برشلونة", nameEn: "Barcelona", league: "la_liga", country: "إسبانيا", primary: "#004d98", secondary: "#a50044", ovr: 87, formation: "4-3-3" },
    { id: "atletico", name: "أتلتيكو مدريد", nameEn: "Atletico Madrid", league: "la_liga", country: "إسبانيا", primary: "#cb3524", secondary: "#ffffff", ovr: 84, formation: "3-5-2" },
    { id: "inter", name: "إنتر ميلان", nameEn: "Inter Milan", league: "serie_a", country: "إيطاليا", primary: "#010e80", secondary: "#000000", ovr: 86, formation: "3-5-2" },
    { id: "ac_milan", name: "إي سي ميلان", nameEn: "AC Milan", league: "serie_a", country: "إيطاليا", primary: "#fb090b", secondary: "#000000", ovr: 84, formation: "4-3-3" },
    { id: "juventus", name: "يوفنتوس", nameEn: "Juventus", league: "serie_a", country: "إيطاليا", primary: "#18181b", secondary: "#f4f4f5", ovr: 83, formation: "4-3-3" },
    { id: "bayern", name: "بايرن ميونخ", nameEn: "Bayern Munich", league: "bundesliga", country: "ألمانيا", primary: "#dc052d", secondary: "#ffffff", ovr: 87, formation: "4-2-3-1" },
    { id: "dortmund", name: "بوروسيا دورتموند", nameEn: "Borussia Dortmund", league: "bundesliga", country: "ألمانيا", primary: "#fde100", secondary: "#111111", ovr: 83, formation: "4-2-3-1" },
    { id: "leverkusen", name: "باير ليفركوزن", nameEn: "Bayer Leverkusen", league: "bundesliga", country: "ألمانيا", primary: "#e32221", secondary: "#111111", ovr: 85, formation: "3-5-2" },
    { id: "psg", name: "باريس سان جيرمان", nameEn: "Paris Saint-Germain", league: "ligue_1", country: "فرنسا", primary: "#004170", secondary: "#da291c", ovr: 86, formation: "4-3-3" },
    { id: "al_hilal", name: "الهلال السعودي", nameEn: "Al Hilal", league: "saudi_pro", country: "السعودية", primary: "#0047ba", secondary: "#ffffff", ovr: 82, formation: "4-2-3-1" },
    { id: "al_nassr", name: "النصر السعودي", nameEn: "Al Nassr", league: "saudi_pro", country: "السعودية", primary: "#f5c518", secondary: "#003087", ovr: 81, formation: "4-3-3" },
    { id: "al_ittihad", name: "الاتحاد السعودي", nameEn: "Al Ittihad", league: "saudi_pro", country: "السعودية", primary: "#f2c100", secondary: "#141414", ovr: 80, formation: "4-3-3" },
    { id: "al_ahli_ksa", name: "الأهلي السعودي", nameEn: "Al Ahli KSA", league: "saudi_pro", country: "السعودية", primary: "#006c35", secondary: "#ffffff", ovr: 80, formation: "4-3-3" },
    { id: "al_ahly_eg", name: "الأهلي المصري", nameEn: "Al Ahly SC", league: "egyptian_pro", country: "مصر", primary: "#cc0019", secondary: "#d4af37", ovr: 79, formation: "4-3-3" },
    { id: "zamalek", name: "الزمالك المصري", nameEn: "Zamalek SC", league: "egyptian_pro", country: "مصر", primary: "#f5f5f5", secondary: "#d91628", ovr: 77, formation: "4-3-3" },
    { id: "pyramids", name: "بيراميدز", nameEn: "Pyramids FC", league: "egyptian_pro", country: "مصر", primary: "#1b4d9e", secondary: "#3ec8ff", ovr: 77, formation: "4-3-3" },
    { id: "egypt_nt", name: "منتخب مصر", nameEn: "Egypt", league: "national", country: "مصر", primary: "#ce1126", secondary: "#141414", ovr: 81, formation: "4-3-3" },
    { id: "morocco_nt", name: "منتخب المغرب", nameEn: "Morocco", league: "national", country: "المغرب", primary: "#c1272d", secondary: "#006233", ovr: 84, formation: "4-3-3" },
    { id: "saudi_nt", name: "منتخب السعودية", nameEn: "Saudi Arabia", league: "national", country: "السعودية", primary: "#006c35", secondary: "#ffffff", ovr: 78, formation: "4-3-3" },
    { id: "argentina_nt", name: "منتخب الأرجنتين", nameEn: "Argentina", league: "national", country: "الأرجنتين", primary: "#75aadb", secondary: "#ffffff", ovr: 88, formation: "4-3-3" },
    { id: "france_nt", name: "منتخب فرنسا", nameEn: "France", league: "national", country: "فرنسا", primary: "#002395", secondary: "#ed2939", ovr: 88, formation: "4-3-3" },
    { id: "brazil_nt", name: "منتخب البرازيل", nameEn: "Brazil", league: "national", country: "البرازيل", primary: "#f7d117", secondary: "#009c3b", ovr: 87, formation: "4-3-3" },
    { id: "spain_nt", name: "منتخب إسبانيا", nameEn: "Spain", league: "national", country: "إسبانيا", primary: "#aa151b", secondary: "#f1bf00", ovr: 87, formation: "4-3-3" },
    { id: "england_nt", name: "منتخب إنجلترا", nameEn: "England", league: "national", country: "إنجلترا", primary: "#f4f4f6", secondary: "#00247d", ovr: 86, formation: "4-2-3-1" },
    { id: "germany_nt", name: "منتخب ألمانيا", nameEn: "Germany", league: "national", country: "ألمانيا", primary: "#f4f4f6", secondary: "#171717", ovr: 86, formation: "4-2-3-1" },
    { id: "portugal_nt", name: "منتخب البرتغال", nameEn: "Portugal", league: "national", country: "البرتغال", primary: "#bf1e2e", secondary: "#006600", ovr: 86, formation: "4-3-3" },
    { id: "myai_legends", name: "أساطير MY AI", nameEn: "MY AI Legends", league: "legends", country: "عالمي", primary: "#ff142e", secondary: "#facc15", ovr: 92, formation: "4-3-3" },
    { id: "myai_united", name: "MY AI يونايتد", nameEn: "MY AI United", league: "egyptian_pro", country: "MY AI", primary: "#d90429", secondary: "#111111", ovr: 84, formation: "4-3-3" },
  ];

  // Raw player tuples to keep file compact while storing rich authentic attributes:
  // [id, nameAr, nameEn, age, nationality, clubId, pos, foot, pac, sho, pas, dri, def, phy, ovr, jerseyNo, skinHex, hairHex]
  const RAW_PLAYERS = [
    // Liverpool / Egypt
    ["salah", "محمد صلاح", "Mohamed Salah", 32, "مصر", "liverpool", "جناح أيمن", "يسرى", 89, 88, 84, 88, 45, 76, 90, 11, "#c8966b", "#171313"],
    ["vandijk", "فيرجيل فان دايك", "Virgil van Dijk", 33, "هولندا", "liverpool", "قلب دفاع", "يمنى", 78, 60, 74, 71, 90, 88, 89, 4, "#a6754f", "#1e1b18"],
    ["macallister", "ماك أليستر", "Alexis Mac Allister", 26, "الأرجنتين", "liverpool", "وسط", "يمنى", 72, 82, 86, 84, 76, 76, 86, 10, "#e6bfa3", "#2b1f18"],
    ["alisson", "أليسون بيكر", "Alisson Becker", 32, "البرازيل", "liverpool", "حارس مرمى", "يمنى", 54, 42, 85, 58, 52, 84, 89, 1, "#e2b89b", "#3a2920"],
    ["trent", "ترينت ألكسندر أرنولد", "Trent Alexander-Arnold", 26, "إنجلترا", "liverpool", "ظهير أيمن", "يمنى", 78, 74, 91, 80, 78, 72, 86, 66, "#9e6b47", "#181515"],

    // Man City
    ["haaland", "إيرلينغ هالاند", "Erling Haaland", 24, "النرويج", "man_city", "مهاجم", "يسرى", 89, 93, 68, 81, 45, 90, 91, 9, "#f1ccb0", "#e6c36a"],
    ["debruyne", "كيفين دي بروين", "Kevin De Bruyne", 33, "بلجيكا", "man_city", "صانع ألعاب", "يمنى", 69, 86, 94, 85, 65, 76, 90, 17, "#f0c8ab", "#d69a5c"],
    ["rodri", "رودري", "Rodri", 28, "إسبانيا", "man_city", "وسط دفاعي", "يمنى", 68, 81, 88, 84, 88, 86, 91, 16, "#e3baa0", "#261c17"],
    ["foden", "فيل فودين", "Phil Foden", 24, "إنجلترا", "man_city", "جناح", "يسرى", 84, 84, 85, 90, 56, 65, 88, 47, "#ecc4aa", "#2a2019"],
    ["marmoush", "عمر مرموش", "Omar Marmoush", 26, "مصر", "man_city", "مهاجم", "يمنى", 90, 84, 78, 86, 42, 74, 85, 7, "#cfa07a", "#171414"],
    ["ederson", "إيدرسون مورايش", "Ederson", 31, "البرازيل", "man_city", "حارس مرمى", "يسرى", 55, 45, 90, 62, 50, 82, 88, 31, "#cfa17d", "#181515"],

    // Arsenal
    ["saka", "بوكايو ساكا", "Bukayo Saka", 23, "إنجلترا", "arsenal", "جناح أيمن", "يسرى", 87, 83, 84, 89, 60, 74, 88, 7, "#6c452d", "#121010"],
    ["odegaard", "مارتن أوديغارد", "Martin Odegaard", 26, "النرويج", "arsenal", "صانع ألعاب", "يسرى", 76, 80, 90, 89, 65, 68, 89, 8, "#f0cbb2", "#c8a15d"],
    ["rice", "ديكلان رايس", "Declan Rice", 26, "إنجلترا", "arsenal", "وسط دفاعي", "يمنى", 76, 74, 83, 81, 86, 86, 87, 41, "#e7be9f", "#30231b"],
    ["saliba", "ويليام ساليبا", "William Saliba", 24, "فرنسا", "arsenal", "قلب دفاع", "يمنى", 82, 46, 74, 74, 88, 85, 87, 2, "#784c33", "#121010"],

    // Chelsea & Man Utd
    ["palmer", "كول بالمر", "Cole Palmer", 22, "إنجلترا", "chelsea", "صانع ألعاب", "يسرى", 80, 85, 86, 87, 50, 68, 86, 20, "#deb391", "#2c221b"],
    ["caicedo", "مويسيس كايسيدو", "Moises Caicedo", 23, "الإكوادور", "chelsea", "وسط دفاعي", "يمنى", 78, 66, 80, 80, 84, 82, 84, 25, "#7d5034", "#151212"],
    ["fernandes", "برونو فرنانديز", "Bruno Fernandes", 30, "البرتغال", "man_utd", "صانع ألعاب", "يمنى", 73, 85, 89, 83, 68, 74, 87, 8, "#e3b797", "#231a15"],
    ["martinez", "ليساندرو مارتينيز", "Lisandro Martinez", 27, "الأرجنتين", "man_utd", "قلب دفاع", "يسرى", 75, 52, 78, 76, 85, 80, 84, 6, "#dfb595", "#1c1512"],

    // Real Madrid
    ["mbappe", "كيليان مبابي", "Kylian Mbappe", 26, "فرنسا", "real_madrid", "مهاجم", "يمنى", 97, 90, 80, 92, 36, 78, 91, 9, "#8a5a3c", "#141111"],
    ["vinicius", "فينيسيوس جونيور", "Vinicius Jr", 24, "البرازيل", "real_madrid", "جناح أيسر", "يمنى", 95, 84, 81, 94, 30, 70, 90, 7, "#6e4730", "#111010"],
    ["bellingham", "جود بيلينغهام", "Jude Bellingham", 21, "إنجلترا", "real_madrid", "صانع ألعاب", "يمنى", 82, 87, 84, 90, 78, 84, 90, 5, "#b3805a", "#171313"],
    ["valverde", "فيديريكو فالفيردي", "Federico Valverde", 26, "الأوروغواي", "real_madrid", "وسط", "يمنى", 88, 84, 85, 84, 82, 84, 88, 8, "#e4bca0", "#2d211a"],
    ["courtois", "تيبو كورتوا", "Thibaut Courtois", 32, "بلجيكا", "real_madrid", "حارس مرمى", "يسرى", 50, 40, 76, 52, 50, 85, 89, 1, "#ecc7ae", "#2c2119"],

    // Barcelona
    ["yamal", "لامين يامال", "Lamine Yamal", 17, "إسبانيا", "barcelona", "جناح أيمن", "يسرى", 87, 79, 84, 91, 34, 58, 86, 19, "#9d6a49", "#151212"],
    ["pedri", "بيدري", "Pedri", 22, "إسبانيا", "barcelona", "وسط", "يمنى", 78, 72, 88, 90, 72, 70, 87, 8, "#e7bfa1", "#201712"],
    ["lewandowski", "روبرت ليفاندوفسكي", "Robert Lewandowski", 36, "بولندا", "barcelona", "مهاجم", "يمنى", 76, 90, 79, 85, 44, 84, 88, 9, "#ecc6ac", "#2d221b"],
    ["raphinha", "رافينيا", "Raphinha", 28, "البرازيل", "barcelona", "جناح أيسر", "يسرى", 90, 84, 83, 87, 52, 74, 87, 11, "#aa7854", "#171313"],

    // Atletico
    ["griezmann", "أنطوان غريزمان", "Antoine Griezmann", 33, "فرنسا", "atletico", "مهاجم", "يسرى", 79, 87, 86, 87, 58, 72, 87, 7, "#efcab0", "#c29d5e"],
    ["alvarez", "خوليان ألفاريز", "Julian Alvarez", 25, "الأرجنتين", "atletico", "مهاجم", "يمنى", 85, 86, 80, 85, 56, 76, 86, 19, "#e6bfa3", "#251c16"],
    ["oblak", "يان أوبلاك", "Jan Oblak", 32, "سلوفينيا", "atletico", "حارس مرمى", "يمنى", 48, 38, 74, 50, 52, 84, 88, 13, "#ecc6ac", "#241b16"],

    // Serie A
    ["lautaro", "لاوتارو مارتينيز", "Lautaro Martinez", 27, "الأرجنتين", "inter", "مهاجم", "يمنى", 83, 89, 75, 86, 52, 84, 89, 10, "#e1b799", "#1d1512"],
    ["barella", "نيكولو باريلا", "Nicolo Barella", 28, "إيطاليا", "inter", "وسط", "يمنى", 80, 78, 86, 86, 80, 78, 87, 23, "#e4bca0", "#271d16"],
    ["bastoni", "أليساندرو باستوني", "Alessandro Bastoni", 25, "إيطاليا", "inter", "قلب دفاع", "يسرى", 75, 52, 79, 76, 88, 84, 87, 95, "#ebc4aa", "#2c2119"],
    ["leao", "رافاييل لياو", "Rafael Leao", 25, "البرتغال", "ac_milan", "جناح أيسر", "يمنى", 93, 80, 79, 89, 32, 79, 86, 10, "#75482e", "#121010"],
    ["theo", "ثيو هيرنانديز", "Theo Hernandez", 27, "فرنسا", "ac_milan", "ظهير أيسر", "يسرى", 93, 76, 78, 83, 80, 85, 86, 19, "#e8c0a5", "#c8a464"],
    ["vlahovic", "دوشان فلاهوفيتش", "Dusan Vlahovic", 25, "صربيا", "juventus", "مهاجم", "يسرى", 80, 86, 68, 78, 38, 84, 84, 9, "#ebc4aa", "#291e17"],
    ["yildiz", "كينان يلدز", "Kenan Yildiz", 19, "تركيا", "juventus", "جناح", "يمنى", 83, 78, 77, 85, 40, 68, 81, 10, "#e5bda1", "#201713"],

    // Bundesliga
    ["kane", "هاري كين", "Harry Kane", 31, "إنجلترا", "bayern", "مهاجم", "يمنى", 70, 93, 84, 83, 49, 84, 90, 9, "#f0cab1", "#6c4f37"],
    ["musiala", "جمال موسيالا", "Jamal Musiala", 22, "ألمانيا", "bayern", "صانع ألعاب", "يمنى", 85, 80, 82, 93, 60, 66, 88, 42, "#c6926a", "#171313"],
    ["kimmich", "جوشوا كيميش", "Joshua Kimmich", 30, "ألمانيا", "bayern", "وسط دفاعي", "يمنى", 70, 74, 89, 83, 83, 78, 87, 6, "#efcab0", "#5a422e"],
    ["wirtz", "فلوريان فيرتز", "Florian Wirtz", 21, "ألمانيا", "leverkusen", "صانع ألعاب", "يمنى", 82, 80, 88, 91, 56, 67, 88, 10, "#efcab0", "#59412d"],
    ["guirassy", "سيرهو غيراسي", "Serhou Guirassy", 28, "غينيا", "dortmund", "مهاجم", "يمنى", 78, 86, 70, 78, 40, 84, 84, 9, "#75472d", "#121010"],

    // Ligue 1 / Morocco
    ["hakimi", "أشرف حكيمي", "Achraf Hakimi", 26, "المغرب", "psg", "ظهير أيمن", "يمنى", 93, 75, 81, 82, 78, 79, 86, 2, "#c8966b", "#151212"],
    ["dembele", "عثمان ديمبيلي", "Ousmane Dembele", 27, "فرنسا", "psg", "جناح أيمن", "يسرى", 93, 79, 82, 90, 36, 60, 86, 10, "#75482e", "#121010"],
    ["vitinha", "فيتينيا", "Vitinha", 25, "البرتغال", "psg", "وسط", "يمنى", 76, 78, 87, 88, 75, 70, 86, 17, "#e7bfa1", "#281e17"],
    ["donnarumma", "جانلويجي دوناروما", "Gianluigi Donnarumma", 26, "إيطاليا", "psg", "حارس مرمى", "يمنى", 48, 38, 72, 54, 48, 86, 89, 1, "#e7bfa1", "#201713"],

    // Saudi Pro League
    ["ronaldo", "كريستيانو رونالدو", "Cristiano Ronaldo", 40, "البرتغال", "al_nassr", "مهاجم", "يمنى", 77, 90, 77, 82, 34, 79, 86, 7, "#dfb392", "#1e1612"],
    ["mane", "ساديو ماني", "Sadio Mane", 32, "السنغال", "al_nassr", "جناح أيسر", "يمنى", 85, 82, 78, 84, 44, 76, 84, 10, "#633b24", "#121010"],
    ["neymar_hl", "سالم الدوسري", "Salem Al-Dawsari", 33, "السعودية", "al_hilal", "جناح أيسر", "يمنى", 85, 79, 79, 85, 45, 70, 82, 29, "#c8966b", "#151212"],
    ["mitrovic", "ألكسندر ميتروفيتش", "Aleksandar Mitrovic", 30, "صربيا", "al_hilal", "مهاجم", "يمنى", 69, 85, 70, 74, 40, 88, 83, 9, "#e6bfa3", "#251c16"],
    ["milinkovic", "ميلينكوفيتش سافيتش", "Sergej Milinkovic-Savic", 30, "صربيا", "al_hilal", "وسط", "يمنى", 70, 82, 84, 82, 78, 87, 85, 22, "#e5bda1", "#281f18"],
    ["bono", "ياسين بونو", "Yassine Bounou", 33, "المغرب", "al_hilal", "حارس مرمى", "يسرى", 48, 38, 76, 52, 50, 82, 85, 37, "#cfa17d", "#181412"],
    ["benzema", "كريم بنزيما", "Karim Benzema", 37, "فرنسا", "al_ittihad", "مهاجم", "يمنى", 75, 87, 83, 85, 40, 77, 86, 9, "#cfa17d", "#171414"],
    ["kante", "نغولو كانتي", "N'Golo Kante", 33, "فرنسا", "al_ittihad", "وسط دفاعي", "يمنى", 78, 66, 80, 81, 86, 82, 85, 7, "#653d26", "#111010"],
    ["mahrez", "رياض محرز", "Riyad Mahrez", 34, "الجزائر", "al_ahli_ksa", "جناح أيمن", "يسرى", 79, 82, 84, 89, 38, 62, 84, 7, "#cfa17d", "#181515"],

    // Egyptian Premier League
    ["emam", "إمام عاشور", "Emam Ashour", 27, "مصر", "al_ahly_eg", "وسط", "يمنى", 81, 80, 79, 81, 70, 79, 80, 22, "#c8966b", "#171414"],
    ["abouali", "وسام أبو علي", "Wessam Abou Ali", 26, "فلسطين", "al_ahly_eg", "مهاجم", "يمنى", 82, 81, 70, 77, 38, 80, 79, 9, "#dfb392", "#241b16"],
    ["elshenawy", "محمد الشناوي", "Mohamed El Shenawy", 36, "مصر", "al_ahly_eg", "حارس مرمى", "يمنى", 46, 36, 74, 48, 50, 82, 79, 1, "#c8966b", "#171414"],
    ["abdelmonem", "رامي ربيعة", "Ramy Rabia", 31, "مصر", "al_ahly_eg", "قلب دفاع", "يمنى", 72, 52, 68, 66, 78, 80, 77, 5, "#c59368", "#171414"],
    ["zizo", "أحمد مصطفى زيزو", "Ahmed Sayed Zizo", 29, "مصر", "zamalek", "جناح أيمن", "يمنى", 84, 80, 81, 82, 52, 74, 80, 25, "#cfa17d", "#181413"],
    ["donja", "نبيل عماد دونجا", "Nabil Donga", 28, "مصر", "zamalek", "وسط دفاعي", "يمنى", 72, 66, 74, 72, 77, 81, 76, 8, "#c29067", "#151212"],
    ["fathy", "مصطفى فتحي", "Mostafa Fathi", 30, "مصر", "pyramids", "جناح أيمن", "يسرى", 84, 75, 76, 84, 38, 62, 77, 11, "#c9976c", "#171414"],
    ["mayele", "فيستون مايلي", "Fiston Mayele", 30, "الكونغو", "pyramids", "مهاجم", "يمنى", 83, 80, 66, 75, 36, 82, 78, 9, "#6a4128", "#121010"],

    // National Team Captains / Stars
    ["messi", "ليونيل ميسي", "Lionel Messi", 37, "الأرجنتين", "argentina_nt", "صانع ألعاب", "يسرى", 78, 89, 90, 94, 34, 65, 89, 10, "#e6bfa3", "#2b1f18"],
    ["mostafa_m", "مصطفى محمد", "Mostafa Mohamed", 27, "مصر", "egypt_nt", "مهاجم", "يمنى", 78, 82, 67, 74, 42, 85, 80, 19, "#cfa17d", "#171414"],
    ["trezeguet", "محمود حسن تريزيجيه", "Trezeguet", 30, "مصر", "egypt_nt", "جناح أيسر", "يمنى", 84, 78, 75, 81, 52, 76, 79, 7, "#cfa17d", "#171414"],
    ["ziyech", "حكيم زياش", "Hakim Ziyech", 31, "المغرب", "morocco_nt", "جناح أيمن", "يسرى", 77, 80, 86, 85, 48, 62, 82, 7, "#cfa17d", "#171414"],
    ["amrabat", "سفيان أمرابط", "Sofyan Amrabat", 28, "المغرب", "morocco_nt", "وسط دفاعي", "يمنى", 73, 64, 78, 77, 83, 86, 81, 4, "#cfa17d", "#181413"],
    ["rodrygo", "رودريغو غوس", "Rodrygo", 24, "البرازيل", "brazil_nt", "جناح أيمن", "يمنى", 89, 83, 81, 88, 42, 66, 86, 10, "#b6835d", "#151212"],

    // Legends (اساطير كرة القدم)
    ["maradona", "دييغو مارادونا", "Diego Maradona", 26, "الأرجنتين", "myai_legends", "صانع ألعاب", "يسرى", 88, 92, 92, 97, 38, 76, 97, 10, "#d8a882", "#141111"],
    ["pele", "بيليه", "Pele", 25, "البرازيل", "myai_legends", "مهاجم", "يمنى", 93, 95, 90, 95, 52, 79, 98, 10, "#6f442a", "#121010"],
    ["zidane", "زين الدين زيدان", "Zinedine Zidane", 29, "فرنسا", "myai_legends", "صانع ألعاب", "يمنى", 81, 89, 95, 95, 68, 84, 95, 5, "#dfc0a4", "#221a16"],
    ["r9", "رونالدو الظاهرة", "Ronaldo Nazario", 24, "البرازيل", "myai_legends", "مهاجم", "يمنى", 96, 95, 81, 95, 42, 83, 96, 9, "#a5724d", "#131111"],
    ["ronaldinho", "رونالدينيو", "Ronaldinho", 25, "البرازيل", "myai_legends", "جناح أيسر", "يمنى", 91, 89, 90, 97, 38, 78, 94, 10, "#996845", "#141111"],
    ["maldini", "باولو مالديني", "Paolo Maldini", 28, "إيطاليا", "myai_legends", "قلب دفاع", "يسرى", 84, 58, 80, 74, 96, 88, 94, 3, "#dfb494", "#201712"],
    ["buffon", "جانلويجي بوفون", "Gianluigi Buffon", 28, "إيطاليا", "myai_legends", "حارس مرمى", "يمنى", 52, 42, 78, 56, 54, 88, 93, 1, "#ebc4aa", "#221914"],
    ["aboutrika", "محمد أبو تريكة", "Mohamed Aboutrika", 28, "مصر", "myai_legends", "صانع ألعاب", "يمنى", 78, 86, 90, 88, 48, 72, 89, 22, "#c8966b", "#171414"],
    ["majed", "ماجد عبد الله", "Majed Abdullah", 26, "السعودية", "myai_legends", "مهاجم", "يمنى", 87, 91, 78, 84, 36, 82, 88, 9, "#845539", "#141111"],
  ];

  const HAIR_STYLES_MAP = {
    salah: "curly",
    haaland: "long",
    griezmann: "long",
    maradona: "curly",
    ronaldinho: "long",
    maldini: "long",
    zidane: "short",
    pele: "short",
    yamal: "curly",
    foden: "fade",
    mbappe: "fade",
    vinicius: "curly",
    bellingham: "fade",
    emam: "fade",
    hakimi: "fade",
    neymar_hl: "fade",
    kante: "short",
    buffon: "long",
  };

  const BOOT_COLORS = ["#ff263f", "#38bdf8", "#facc15", "#10b981", "#f8fafc", "#a855f7", "#f97316"];

  function estimateMarketValue(ovr, age) {
    const base = Math.pow(Math.max(1, (ovr - 62) / 6.5), 2.15) * 1.45;
    const ageFactor = age <= 23 ? 1.32 : age <= 28 ? 1.15 : age <= 32 ? 0.85 : 0.55;
    return Math.max(1.2, Math.round(base * ageFactor * 10) / 10);
  }

  function estimateWageK(ovr) {
    return Math.max(12, Math.round(Math.pow(Math.max(1, ovr - 65), 1.45) * 1.4));
  }

  function computeRarity(ovr, clubId) {
    if (clubId === "myai_legends" || ovr >= 91) return "legend";
    if (ovr >= 86) return "epic";
    if (ovr >= 81) return "rare";
    return "common";
  }

  const RARITY_LABELS = {
    legend: "أسطوري",
    epic: "مميز",
    rare: "نادر",
    common: "عادي",
  };

  const RARITY_PALETTES = {
    legend: { top: "#7c2d12", mid: "#facc15", bot: "#451a03", border: "#fef08a", text: "#fff7ed", badgeBg: "#9a3412" },
    epic: { top: "#581c87", mid: "#ff142e", bot: "#18050d", border: "#ff6b81", text: "#fdf4ff", badgeBg: "#831843" },
    rare: { top: "#0f172a", mid: "#2563eb", bot: "#020617", border: "#60a5fa", text: "#eff6ff", badgeBg: "#1e3a8a" },
    common: { top: "#27272a", mid: "#52525b", bot: "#09090b", border: "#a1a1aa", text: "#f4f4f5", badgeBg: "#3f3f46" },
  };

  const POS_SHORT_MAP = {
    "حارس مرمى": "GK",
    "قلب دفاع": "CB",
    "ظهير أيمن": "RB",
    "ظهير أيسر": "LB",
    "وسط دفاعي": "CDM",
    "وسط": "CM",
    "صانع ألعاب": "CAM",
    "جناح أيمن": "RW",
    "جناح أيسر": "LW",
    "جناح": "RW",
    "مهاجم": "ST",
  };

  const REAL_HEIGHTS_CM = {
    haaland: 195,
    courtois: 200,
    donnarumma: 196,
    vandijk: 195,
    alisson: 193,
    rodri: 191,
    saliba: 192,
    milinkovic: 192,
    vlahovic: 190,
    mitrovic: 189,
    kane: 188,
    oblak: 188,
    buffon: 192,
    elshenawy: 191,
    ronaldo: 187,
    maldini: 186,
    bellingham: 186,
    rice: 188,
    lewandowski: 185,
    bastoni: 190,
    guirassy: 187,
    zidane: 185,
    benzema: 185,
    ederson: 188,
    bono: 195,
    debruyne: 181,
    valverde: 182,
    hakimi: 181,
    yamal: 180,
    trent: 180,
    mbappe: 178,
    saka: 178,
    odegaard: 178,
    vinicius: 176,
    salah: 175,
    martinez: 175,
    foden: 171,
    pedri: 174,
    vitinha: 172,
    alvarez: 170,
    messi: 170,
    maradona: 165,
    kante: 168,
  };

  function buildStats15(idStr, pos, ovr, pac, sho, pas, dri, def, phy) {
    let h = 0;
    for (let k = 0; k < idStr.length; k++) h = (h * 31 + idStr.charCodeAt(k)) & 0xffff;
    const jitter = (shift, span) => (((h >> shift) % (span * 2 + 1)) - span);
    const isGk = pos.includes("حارس");
    const isDef = pos.includes("دفاع") || pos.includes("ظهير");
    const isMid = pos.includes("وسط") || pos.includes("صانع");
    const clamp = (v) => Math.max(35, Math.min(99, Math.round(v)));

    const heightCm = REAL_HEIGHTS_CM[idStr] || (isGk
      ? 188 + (h % 11)
      : isDef
        ? 179 + (h % 14)
        : isMid
          ? 171 + (h % 14)
          : 173 + (h % 17));
    const weightKg = Math.round(heightCm - 103 + (phy - 75) * 0.28);

    const speed = clamp(pac + jitter(0, 2));
    const acceleration = clamp(pac + (heightCm < 178 ? 3 : -2) + jitter(2, 2));
    const agility = clamp((dri * 0.65 + pac * 0.35) + (heightCm < 178 ? 4 : -3) + jitter(3, 2));
    const balance = clamp((dri * 0.5 + phy * 0.4) + (heightCm < 180 ? 5 : -2) + jitter(4, 2));
    const staminaStat = clamp((phy * 0.55 + pac * 0.35 + ovr * 0.1) + jitter(5, 3));
    const shotPower = clamp((sho * 0.68 + phy * 0.32) + jitter(1, 2));
    const shotAccuracy = clamp(sho + jitter(6, 2));
    const passAccuracy = clamp(pas + jitter(2, 2));
    const vision = clamp((pas * 0.72 + (isMid ? 8 : 0) + ovr * 0.18) + jitter(7, 2));
    const dribbling = clamp(dri + jitter(3, 2));
    const physical = clamp(phy + jitter(4, 2));
    const tackling = clamp((def * 0.78 + phy * 0.22) + (isDef ? 3 : 0) + jitter(5, 2));
    const positioning = clamp((ovr * 0.58 + (isDef ? def : sho) * 0.32 + vision * 0.1) + jitter(2, 2));
    const defending = clamp(def + jitter(1, 2));
    const gkReflexes = isGk ? clamp(ovr + 3 + jitter(3, 2)) : clamp(18 + (ovr % 12));

    return {
      heightCm,
      weightKg,
      stats15: {
        speed,
        acceleration,
        agility,
        balance,
        staminaStat,
        shotPower,
        shotAccuracy,
        passAccuracy,
        vision,
        dribbling,
        physical,
        tackling,
        positioning,
        defending,
        gkReflexes,
      },
    };
  }

  const PLAYERS = RAW_PLAYERS.map((r, i) => {
    const team = TEAMS.find((t) => t.id === r[5]);
    const rarity = computeRarity(r[14], r[5]);
    const ovr = r[14];
    const age = r[3];
    const dri = r[11];
    const bio = buildStats15(r[0], r[6], ovr, r[8], r[9], r[10], dri, r[12], r[13]);
    return {
      id: r[0],
      name: r[1],
      nameEn: r[2],
      age,
      nationality: r[4],
      clubId: r[5],
      club: team ? team.name : "نادي حر",
      league: team ? team.league : "legends",
      pos: r[6],
      posShort: POS_SHORT_MAP[r[6]] || "CM",
      foot: r[7],
      pac: r[8],
      sho: r[9],
      pas: r[10],
      dri,
      def: r[12],
      phy: r[13],
      ovr,
      stam: bio.stats15.staminaStat,
      heightCm: bio.heightCm,
      weightKg: bio.weightKg,
      stats15: bio.stats15,
      jerseyNo: r[15],
      skinHex: r[16],
      hairHex: r[17],
      hairStyle: HAIR_STYLES_MAP[r[0]] || (i % 3 === 0 ? "fade" : i % 3 === 1 ? "short" : "curly"),
      bootColor: BOOT_COLORS[i % BOOT_COLORS.length],
      weakFoot: r[14] >= 89 ? 5 : r[14] >= 83 ? 4 : 3,
      skillMoves: dri >= 90 ? 5 : dri >= 83 ? 4 : r[6].includes("حارس") ? 2 : 3,
      rarity,
      rarityLabel: RARITY_LABELS[rarity],
      valueM: estimateMarketValue(ovr, age),
      wageK: estimateWageK(ovr),
      isLegend: r[5] === "myai_legends",
    };
  });

  function esc(v) {
    return typeof window.escapeHTML === "function"
      ? window.escapeHTML(String(v ?? ""))
      : String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function getPlayerAvatarSvgDataUrl(player, kitPrimary, kitSecondary) {
    const p = player || {};
    const t = TEAMS.find((x) => x.id === p.clubId);
    const primary = kitPrimary || t?.primary || "#d90429";
    const secondary = kitSecondary || t?.secondary || "#111111";
    const skin = p.skinHex || "#cfa17d";
    const hair = p.hairHex || "#171414";
    const num = p.jerseyNo || 10;
    const hStyle = p.hairStyle || "short";
    const hairPath =
      hStyle === "curly"
        ? "M36 45 C34 20 86 20 84 45 C80 35 72 30 60 32 C48 30 40 35 36 45 Z"
        : hStyle === "long"
          ? "M37 48 Q40 18 60 18 Q80 18 83 48 L84 68 L76 62 L76 42 Q60 32 44 42 L44 62 L36 68 Z"
          : "M40 44 Q42 22 60 22 Q78 22 80 44 Q74 34 60 34 Q46 34 40 44 Z";
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#191014"/>
          <stop offset="100%" stop-color="#070709"/>
        </linearGradient>
      </defs>
      <rect width="120" height="120" rx="18" fill="url(#bg)"/>
      <circle cx="60" cy="48" r="34" fill="${primary}" opacity="0.22"/>
      <path d="M22 120 Q28 84 60 82 Q92 84 98 120 Z" fill="${primary}" stroke="${secondary}" stroke-width="2.5"/>
      <path d="M46 82 L60 95 L74 82" fill="none" stroke="${secondary}" stroke-width="3"/>
      <rect x="52" y="66" width="16" height="18" rx="6" fill="${skin}"/>
      <ellipse cx="60" cy="48" rx="19" ry="22" fill="${skin}"/>
      <path d="${hairPath}" fill="${hair}"/>
      <circle cx="53" cy="49" r="2.2" fill="#171717"/>
      <circle cx="67" cy="49" r="2.2" fill="#171717"/>
      <path d="M54 58 Q60 62 66 58" fill="none" stroke="#7c4738" stroke-width="2" stroke-linecap="round"/>
      <text x="60" y="112" text-anchor="middle" fill="${secondary}" font-family="Arial,sans-serif" font-weight="900" font-size="14">${num}</text>
    </svg>`;
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  // Legal MY AI original metallic/shield Player Card SVG generator
  function getPlayerCardSvgDataUrl(player, levelBoost) {
    const p = player || {};
    const boost = Math.max(0, Number(levelBoost || 0));
    const ovr = Math.min(99, (p.ovr || 78) + boost);
    const pal = RARITY_PALETTES[p.rarity] || RARITY_PALETTES.common;
    const t = TEAMS.find((x) => x.id === p.clubId);
    const kit = t?.primary || "#d90429";
    const sec = t?.secondary || "#facc15";
    const skin = p.skinHex || "#cfa17d";
    const hair = p.hairHex || "#171414";
    const safeName = String(p.nameEn || p.name || "MY AI STAR").slice(0, 16).toUpperCase();
    const posCode = p.posShort || POS_SHORT_MAP[p.pos] || "ST";
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 310">
      <defs>
        <linearGradient id="cbg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="${pal.top}"/>
          <stop offset="52%" stop-color="${pal.mid}"/>
          <stop offset="100%" stop-color="${pal.bot}"/>
        </linearGradient>
        <linearGradient id="shine" x1="0" y1="0" x2="0.8" y2="1">
          <stop offset="0%" stop-color="#ffffff" stop-opacity="0.28"/>
          <stop offset="45%" stop-color="#ffffff" stop-opacity="0"/>
          <stop offset="100%" stop-color="#000000" stop-opacity="0.32"/>
        </linearGradient>
      </defs>
      <path d="M22 18 Q110 4 198 18 L208 42 L202 248 Q110 296 18 248 L12 42 Z" fill="url(#cbg)" stroke="${pal.border}" stroke-width="3.5"/>
      <path d="M22 18 Q110 4 198 18 L208 42 L202 248 Q110 296 18 248 L12 42 Z" fill="url(#shine)"/>
      <text x="52" y="64" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="34">${ovr}</text>
      <text x="52" y="86" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="800" font-size="14">${posCode}</text>
      <rect x="34" y="95" width="36" height="4" rx="2" fill="${pal.border}"/>
      <text x="52" y="114" text-anchor="middle" fill="${pal.border}" font-family="Arial,sans-serif" font-weight="800" font-size="10">MY AI</text>
      <circle cx="132" cy="84" r="42" fill="${kit}" opacity="0.24"/>
      <path d="M86 164 Q94 128 132 126 Q170 128 178 164 Z" fill="${kit}" stroke="${sec}" stroke-width="2.5"/>
      <rect x="123" y="109" width="18" height="20" rx="6" fill="${skin}"/>
      <ellipse cx="132" cy="86" rx="22" ry="25" fill="${skin}"/>
      <path d="M109 81 Q112 56 132 56 Q152 56 155 81 Q146 70 132 70 Q118 70 109 81 Z" fill="${hair}"/>
      <circle cx="124" cy="86" r="2.3" fill="#141414"/>
      <circle cx="140" cy="86" r="2.3" fill="#141414"/>
      <rect x="28" y="170" width="164" height="26" rx="6" fill="rgba(5,5,9,0.72)" stroke="${pal.border}" stroke-opacity="0.5"/>
      <text x="110" y="188" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="14">${safeName}</text>
      <text x="64" y="218" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.pac || 75) + boost)} PAC</text>
      <text x="156" y="218" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.dri || 75) + boost)} DRI</text>
      <text x="64" y="236" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.sho || 75) + boost)} SHO</text>
      <text x="156" y="236" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.def || 60) + boost)} DEF</text>
      <text x="64" y="254" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.pas || 75) + boost)} PAS</text>
      <text x="156" y="254" text-anchor="middle" fill="${pal.text}" font-family="Arial,sans-serif" font-weight="900" font-size="13">${Math.min(99, (p.phy || 75) + boost)} PHY</text>
    </svg>`;
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function getPackPool(minOvr, maxOvr) {
    return PLAYERS.filter((p) => p.ovr >= (minOvr || 70) && p.ovr <= (maxOvr || 99));
  }

  // Generate an authentic 11-player matchday squad for MY AI FOOTBALL 3D
  function getTeamLineupForMatch(teamId) {
    const team = TEAMS.find((t) => t.id === teamId) || TEAMS[0];
    const teamPlayers = PLAYERS.filter((p) => p.clubId === team.id || (team.country && p.nationality === team.country && team.league === "national"));
    const pickByRole = (matcher, used) => {
      const found = teamPlayers.find((p) => !used.has(p.id) && matcher(p));
      if (found) used.add(found.id);
      return found || null;
    };
    const used = new Set();
    const roles = [
      { label: "GK", match: (p) => p.pos.includes("حارس") },
      { label: "LB", match: (p) => p.pos.includes("ظهير أيسر") || p.pos.includes("دفاع") },
      { label: "LCB", match: (p) => p.pos.includes("قلب دفاع") },
      { label: "RCB", match: (p) => p.pos.includes("قلب دفاع") || p.pos.includes("دفاع") },
      { label: "RB", match: (p) => p.pos.includes("ظهير أيمن") || p.pos.includes("دفاع") },
      { label: "CDM", match: (p) => p.pos.includes("وسط دفاعي") || p.pos.includes("وسط") },
      { label: "LCM", match: (p) => p.pos.includes("وسط") || p.pos.includes("صانع") },
      { label: "CAM", match: (p) => p.pos.includes("صانع") || p.pos.includes("وسط") },
      { label: "LW", match: (p) => p.pos.includes("جناح أيسر") || p.pos.includes("جناح") },
      { label: "ST", match: (p) => p.pos.includes("مهاجم") },
      { label: "RW", match: (p) => p.pos.includes("جناح أيمن") || p.pos.includes("جناح") },
    ];
    const fallbackSkins = ["#c8966b", "#dfb392", "#75482e", "#e6bfa3", "#a5724d"];
    const styles = ["short", "fade", "curly", "long"];
    const squad = roles.map((r, idx) => {
      const star = pickByRole(r.match, used) || teamPlayers.find((p) => !used.has(p.id));
      if (star) {
        used.add(star.id);
        return {
          id: star.id,
          name: star.name,
          pos: star.pos,
          role: r.label,
          ovr: star.ovr,
          pac: star.pac,
          sho: star.sho,
          pas: star.pas,
          dri: star.dri,
          def: star.def,
          phy: star.phy,
          stam: star.stam,
          heightCm: star.heightCm,
          weightKg: star.weightKg,
          stats15: star.stats15,
          jerseyNo: star.jerseyNo,
          skinHex: star.skinHex,
          hairHex: star.hairHex,
          hairStyle: star.hairStyle,
          bootColor: star.bootColor,
          rarity: star.rarity,
          skillMoves: star.skillMoves,
          weakFoot: star.weakFoot,
        };
      }
      const baseOvr = Math.max(70, Math.min(89, (team.ovr || 80) - 2 + (idx % 5)));
      const gPac = Math.max(58, baseOvr - 3);
      const gSho = idx >= 7 ? baseOvr : 65;
      const gPas = baseOvr - 3;
      const gDri = baseOvr - 4;
      const gDef = idx <= 5 ? baseOvr : 48;
      const gPhy = baseOvr - 4;
      const gPosName = r.label === "GK" ? "حارس مرمى" : idx <= 4 ? "قلب دفاع" : idx <= 7 ? "وسط" : "مهاجم";
      const bio = buildStats15(`${team.id}_${idx}`, gPosName, baseOvr, gPac, gSho, gPas, gDri, gDef, gPhy);
      return {
        id: `${team.id}_gen_${idx + 1}`,
        name: `${team.nameEn} #${idx + 1}`,
        pos: r.label,
        role: r.label,
        ovr: baseOvr,
        pac: gPac,
        sho: gSho,
        pas: gPas,
        dri: gDri,
        def: gDef,
        phy: gPhy,
        stam: bio.stats15.staminaStat,
        heightCm: bio.heightCm,
        weightKg: bio.weightKg,
        stats15: bio.stats15,
        jerseyNo: idx === 0 ? 1 : idx + 1,
        skinHex: fallbackSkins[idx % fallbackSkins.length],
        hairHex: "#181515",
        hairStyle: styles[idx % styles.length],
        bootColor: BOOT_COLORS[idx % BOOT_COLORS.length],
        rarity: "common",
        skillMoves: 3,
        weakFoot: 3,
      };
    });
    return { team, squad };
  }

  let explorerFilter = { query: "", league: "all", pos: "all" };

  window.myaiOpenPlayersDatabase = function (initialFilter) {
    if (initialFilter && typeof initialFilter === "object") {
      explorerFilter = Object.assign({ query: "", league: "all", pos: "all" }, initialFilter);
    }
    window.openFeature(
      "🌍 قاعدة بيانات اللاعبين والأندية",
      "ابحث في الأندية والمنتخبات العالمية والعربية، قارن النجوم بـ Sport AI، أو أضف فريقك إلى MY AI FOOTBALL 3D.",
      `<div class="myai-pro-card">
        <input id="dbSearchInput" class="feature-field" value="${esc(explorerFilter.query)}" placeholder="ابحث بالاسم (مثال: صلاح، مبابي، ميسي، الأهلي، ريال مدريد)..." oninput="myaiFilterPlayersDb()">
        <div class="myai-pro-grid2">
          <select id="dbLeagueSelect" class="feature-field" onchange="myaiFilterPlayersDb()">
            ${LEAGUES.map((l) => `<option value="${l.id}" ${explorerFilter.league === l.id ? "selected" : ""}>${esc(l.name)}</option>`).join("")}
          </select>
          <select id="dbPosSelect" class="feature-field" onchange="myaiFilterPlayersDb()">
            <option value="all">كل المراكز</option>
            <option value="حارس مرمى">حارس مرمى</option>
            <option value="دفاع">دفاع</option>
            <option value="وسط">وسط / صانع ألعاب</option>
            <option value="جناح">جناح</option>
            <option value="مهاجم">مهاجم</option>
          </select>
        </div>
        <p class="myai-v3-muted" style="margin-top:4px">ℹ️ ملاحظة: التقييمات والطاقات والأشكال هنا تقديرية تعليمية خاصة بمنصة MY AI ولا تمثل ترخيصًا رسميًا لـ EA أو FIFA.</p>
      </div>
      <div id="dbTeamsStrip" style="display:flex;gap:8px;overflow:auto;padding-bottom:6px;margin-bottom:8px"></div>
      <div id="dbPlayersResults"></div>`,
    );
    window.myaiFilterPlayersDb();
  };

  window.myaiFilterPlayersDb = function () {
    const q = (document.getElementById("dbSearchInput")?.value || "").trim().toLowerCase();
    const league = document.getElementById("dbLeagueSelect")?.value || "all";
    const pos = document.getElementById("dbPosSelect")?.value || "all";
    explorerFilter = { query: q, league, pos };

    const matchingTeams = TEAMS.filter((t) => {
      if (league !== "all" && t.league !== league) return false;
      if (q && !t.name.toLowerCase().includes(q) && !t.nameEn.toLowerCase().includes(q)) return false;
      return true;
    });

    const teamsStrip = document.getElementById("dbTeamsStrip");
    if (teamsStrip) {
      teamsStrip.innerHTML = matchingTeams
        .slice(0, 14)
        .map(
          (t) => `<button type="button" class="myai-pro-tab" style="display:flex;align-items:center;gap:6px;border-color:${t.primary}" onclick="myaiDbSelectTeam('${t.id}')">
            <span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:${t.primary};border:2px solid ${t.secondary}"></span>
            <span>${esc(t.name)} (${t.ovr})</span>
          </button>`,
        )
        .join("");
    }

    const filteredPlayers = PLAYERS.filter((p) => {
      if (league !== "all" && p.league !== league) return false;
      if (pos !== "all") {
        if (pos === "دفاع" && !p.pos.includes("دفاع") && !p.pos.includes("ظهير")) return false;
        else if (pos === "وسط" && !p.pos.includes("وسط") && !p.pos.includes("صانع")) return false;
        else if (pos !== "دفاع" && pos !== "وسط" && !p.pos.includes(pos)) return false;
      }
      if (q) {
        const hay = `${p.name} ${p.nameEn} ${p.club} ${p.nationality} ${p.pos}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    }).sort((a, b) => b.ovr - a.ovr);

    const out = document.getElementById("dbPlayersResults");
    if (!out) return;
    if (!filteredPlayers.length) {
      out.innerHTML = `<div class="myai-pro-card"><p class="myai-v3-muted">لم يتم العثور على لاعبين مطابقين للبحث الحالي.</p></div>`;
      return;
    }

    out.innerHTML = `<div class="myai-pro-grid2">
      ${filteredPlayers
        .slice(0, 40)
        .map((p) => {
          const avatar = getPlayerAvatarSvgDataUrl(p);
          return `<div class="myai-pro-card" style="padding:11px;margin:0">
            <div style="display:flex;align-items:center;gap:10px">
              <img src="${avatar}" alt="${esc(p.name)}" style="width:62px;height:62px;border-radius:12px;flex-shrink:0;border:1px solid rgba(255,68,88,0.4)">
              <div style="flex:1;min-width:0">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:6px">
                  <strong style="font-size:14px">${esc(p.name)}</strong>
                  <span class="myai-badge ok">${p.ovr}</span>
                </div>
                <small class="myai-v3-muted">${esc(p.club)} · ${esc(p.pos)} · ${esc(p.nationality)}</small><br>
                <small class="myai-v3-muted">العمر ${p.age} · القدم: ${esc(p.foot)} · #${p.jerseyNo}</small>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(6,1fr);gap:4px;margin-top:8px;text-align:center;font-size:11px;background:#0a080a;border-radius:10px;padding:6px 4px">
              <div><small class="myai-v3-muted">PAC</small><br><b>${p.pac}</b></div>
              <div><small class="myai-v3-muted">SHO</small><br><b>${p.sho}</b></div>
              <div><small class="myai-v3-muted">PAS</small><br><b>${p.pas}</b></div>
              <div><small class="myai-v3-muted">DRI</small><br><b>${p.dri}</b></div>
              <div><small class="myai-v3-muted">DEF</small><br><b>${p.def}</b></div>
              <div><small class="myai-v3-muted">PHY</small><br><b>${p.phy}</b></div>
            </div>
            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:9px">
              <button type="button" class="myai-mini-btn" style="flex:1" onclick="myaiDbComparePlayer('${esc(p.name)}')">⚖️ قارن بـ Sport AI</button>
              <button type="button" class="myai-mini-btn" onclick="myaiDbAddToClub('${esc(p.id)}')">➕ لـ Ultimate Club</button>
              <button type="button" class="myai-mini-btn primary-mini" onclick="myaiDbPlay3D('${esc(p.clubId)}')">⚽ العب 3D</button>
            </div>
          </div>`;
        })
        .join("")}
    </div>`;
  };

  window.myaiDbSelectTeam = function (teamId) {
    const team = TEAMS.find((t) => t.id === teamId);
    if (!team) return;
    const inp = document.getElementById("dbSearchInput");
    if (inp) inp.value = team.name;
    window.myaiFilterPlayersDb();
  };

  let comparePickFirst = "";
  window.myaiDbComparePlayer = function (playerName) {
    if (!comparePickFirst || comparePickFirst === playerName) {
      comparePickFirst = playerName;
      if (typeof window.notify === "function") {
        window.notify(`تم اختيار ${playerName} كأول لاعب — اختر لاعبًا ثانيًا للمقارنة!`);
      }
      return;
    }
    const first = comparePickFirst;
    comparePickFirst = "";
    if (typeof window.showSportMenu === "function") {
      window.showSportMenu();
      setTimeout(() => {
        if (typeof window.sportCompare === "function") window.sportCompare();
        const a = document.getElementById("playerA");
        const b = document.getElementById("playerB");
        if (a) a.value = first;
        if (b) b.value = playerName;
        if (typeof window.comparePlayers === "function") window.comparePlayers();
      }, 60);
    }
  };

  window.myaiDbAddToClub = function (playerId) {
    const p = PLAYERS.find((x) => x.id === playerId);
    if (!p) return;
    try {
      const list = Array.isArray(window.clubPlayers) ? window.clubPlayers : JSON.parse(localStorage.getItem("myai_club_players") || "[]");
      if (list.some((x) => x.name === p.name)) {
        if (typeof window.notify === "function") window.notify(`${p.name} موجود بالفعل في ناديك!`);
        return;
      }
      list.push({
        id: Date.now() + Math.floor(Math.random() * 999),
        name: p.name,
        pos: p.pos,
        rating: p.ovr,
        price: p.ovr * 95000,
        image: getPlayerAvatarSvgDataUrl(p),
        status: "احتياطي",
        stats: { pace: p.pac, shoot: p.sho, pass: p.pas, def: p.def, phys: p.phy, stamina: 86 },
        age: p.age,
        morale: 85,
        fitness: 98,
        goals: 0,
        assists: 0,
        apps: 0,
        yellow: 0,
        red: 0,
        form: 2,
        contract: 4,
      });
      localStorage.setItem("myai_club_players", JSON.stringify(list));
      if (Array.isArray(window.clubPlayers)) {
        window.clubPlayers.length = 0;
        list.forEach((x) => window.clubPlayers.push(x));
      }
      window.MYAISound?.coin?.();
      if (typeof window.notify === "function") window.notify(`✅ تمت إضافة ${p.name} إلى قائمة Ultimate Club!`);
    } catch (_) {}
  };

  window.myaiDbPlay3D = function (teamId) {
    if (typeof window.myaiOpenFootball3D === "function") {
      window.myaiOpenFootball3D({ homeTeamId: teamId });
    } else if (typeof window.notify === "function") {
      window.notify("جارٍ تجهيز محرك MY AI FOOTBALL 3D...");
    }
  };

  window.MYAI_PLAYERS_DB = {
    LEAGUES,
    TEAMS,
    PLAYERS,
    RARITY_LABELS,
    buildStats15,
    getPlayerAvatarSvgDataUrl,
    getPlayerCardSvgDataUrl,
    estimateMarketValue,
    estimateWageK,
    computeRarity,
    getPackPool,
    getTeamLineupForMatch,
  };
})();
