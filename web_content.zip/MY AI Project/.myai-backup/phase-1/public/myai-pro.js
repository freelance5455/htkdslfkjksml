/* MY AI Pro Frontend Engine — Preserves all existing MY AI features & upgrades to full production platform */
(function () {
  "use strict";

  const SESSION_TOKEN_KEY = "myai_session_token_v1";
  const USER_CACHE_KEY = "myai_user_cache_v1";
  const OFFLINE_TOKEN_KEY = "myai_offline_token_v1";
  const OFFLINE_ENABLED_KEY = "myai_offline_enabled_v1";
  const CURRICULUM_KEY = "myai_study_curriculum_v1";
  const MEDIA_DB_NAME = "myai_media_store";
  const MEDIA_STORE_NAME = "items";

  let deferredInstallPrompt = null;
  let adminGeneratedCodes = [];
  let adminCodeFilter = "all";
  let lastStudioAnalyzedImage = "";
  let avAudioBlob = null;
  let avRecorder = null;

  const state = {
    user: null,
    plans: [],
    serviceCosts: {},
    shopItems: [],
    event: null,
    hasOwner: true,
    offlineToken: localStorage.getItem(OFFLINE_TOKEN_KEY) || "",
    admob: { enabled: false },
    imageGenEnabled: false,
    booted: false,
  };
  window.myaiSessionState = state;

  function esc(v) {
    return typeof window.escapeHTML === "function"
      ? window.escapeHTML(String(v ?? ""))
      : String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function say(msg) {
    if (typeof window.notify === "function") window.notify(msg);
  }

  function getToken() {
    return localStorage.getItem(SESSION_TOKEN_KEY) || "";
  }

  function setToken(t) {
    if (t && typeof t === "string") {
      localStorage.setItem(SESSION_TOKEN_KEY, t);
    }
  }

  function getCurriculum() {
    try {
      const parsed = JSON.parse(localStorage.getItem(CURRICULUM_KEY) || "null");
      if (parsed && typeof parsed === "object") {
        return {
          curriculum: String(parsed.curriculum || "المنهج المصري"),
          grade: String(parsed.grade || "الثانوية العامة"),
        };
      }
    } catch (_) {}
    return { curriculum: "المنهج المصري", grade: "الثانوية العامة" };
  }

  function saveCurriculum(curriculum, grade) {
    const clean = {
      curriculum: String(curriculum || "المنهج العربي العام").trim(),
      grade: String(grade || "").trim(),
    };
    localStorage.setItem(CURRICULUM_KEY, JSON.stringify(clean));
    return clean;
  }

  function formatDateAr(ms) {
    if (!ms) return "—";
    try {
      return new Date(ms).toLocaleDateString("ar-EG", {
        year: "numeric",
        month: "short",
        day: "numeric",
      });
    } catch (_) {
      return new Date(ms).toISOString().slice(0, 10);
    }
  }

  function daysRemaining(ms) {
    if (!ms) return null;
    return Math.max(0, Math.ceil((ms - Date.now()) / 86400000));
  }

  function decodeOfflineTokenPayload(token) {
    try {
      if (!token || !token.includes(".")) return null;
      const b64 = token.split(".")[0].replace(/-/g, "+").replace(/_/g, "/");
      const pad = b64.length % 4 ? "=".repeat(4 - (b64.length % 4)) : "";
      const json = decodeURIComponent(escape(atob(b64 + pad)));
      return JSON.parse(json);
    } catch (_) {
      return null;
    }
  }

  async function myaiApiFetch(url, options = {}) {
    const token = getToken();
    const headers = Object.assign(
      {
        Accept: "application/json",
      },
      options.headers || {},
    );
    if (options.body && !headers["Content-Type"]) {
      headers["Content-Type"] = "application/json";
    }
    if (token) {
      headers["x-myai-token"] = token;
    }
    const controller = new AbortController();
    const timeoutMs = Number(options.timeoutMs || 45000);
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        ...options,
        headers,
        credentials: "same-origin",
        cache: "no-store",
        signal: options.signal || controller.signal,
      });
      const hdrToken = res.headers.get("x-myai-token");
      if (hdrToken) setToken(hdrToken);
      let data = null;
      try {
        data = await res.json();
      } catch (_) {}
      if (!res.ok) {
        const err = new Error((data && data.error) || `تعذر إتمام الطلب (${res.status})`);
        err.status = res.status;
        err.code = data && data.code;
        err.payload = data;
        throw err;
      }
      if (data && data.sessionToken) setToken(data.sessionToken);
      if (data && data.offlineToken) {
        state.offlineToken = data.offlineToken;
        localStorage.setItem(OFFLINE_TOKEN_KEY, data.offlineToken);
      }
      if (data && data.user) {
        applyServerUser(data.user);
      } else if (data && typeof data.points === "number" && state.user) {
        state.user.points = data.points;
        syncPointsUI(data.points);
      }
      return data;
    } catch (err) {
      if (err && err.name === "AbortError") {
        throw new Error("انتهت مهلة الاتصال بالخادم. تأكد من الإنترنت وأعد المحاولة.");
      }
      throw err;
    } finally {
      clearTimeout(timer);
    }
  }
  window.myaiApiFetch = myaiApiFetch;

  function syncPointsUI(points) {
    const n = Math.max(0, Math.floor(Number(points) || 0));
    localStorage.setItem("myai_points", String(n));
    const el = document.querySelector("header .points");
    if (el) el.textContent = "💎 " + n.toLocaleString("en-US") + "　＋";
  }

  function applyThemeAndTypography(user) {
    const u = user || state.user || {};
    const accent = u.themeAccent || localStorage.getItem("myai_theme_accent") || "red";
    const fontSize = Math.max(13, Math.min(22, Number(u.chatFontSize || localStorage.getItem("myai_chat_font") || 15)));
    const dialect = u.dialect || localStorage.getItem("myai_dialect_v1") || "ar_eg";
    if (accent === "red") delete document.documentElement.dataset.accent;
    else document.documentElement.dataset.accent = accent;
    document.documentElement.style.setProperty("--myai-chat-font", fontSize + "px");
    localStorage.setItem("myai_theme_accent", accent);
    localStorage.setItem("myai_chat_font", String(fontSize));
    localStorage.setItem("myai_dialect_v1", dialect);
  }

  function applyServerUser(user) {
    if (!user) return;
    state.user = user;
    try {
      localStorage.setItem(USER_CACHE_KEY, JSON.stringify(user));
    } catch (_) {}
    applyThemeAndTypography(user);
    syncPointsUI(user.points);
    const av = document.querySelector("header .avatar");
    if (av) {
      av.textContent = (user.name || "M").trim().slice(0, 1).toUpperCase() || "M";
      av.title = user.name || "حسابي";
    }
    renderStatusStrip();
  }

  async function bootSession() {
    try {
      const cached = localStorage.getItem(USER_CACHE_KEY);
      if (cached) {
        const u = JSON.parse(cached);
        if (u && u.id) applyServerUser(u);
      }
    } catch (_) {}

    if (navigator.onLine === false) {
      state.booted = true;
      renderStatusStrip();
      return;
    }

    try {
      const data = await myaiApiFetch("/api/auth/me", { method: "GET", timeoutMs: 15000 });
      if (Array.isArray(data.plans)) state.plans = data.plans;
      if (data.serviceCosts) state.serviceCosts = data.serviceCosts;
      if (Array.isArray(data.shopItems)) state.shopItems = data.shopItems;
      if (data.event) state.event = data.event;
      if (typeof data.hasOwner === "boolean") state.hasOwner = data.hasOwner;
      if (data.admob) state.admob = data.admob;
      state.imageGenEnabled = Boolean(data.imageGenEnabled);
      if (data.user) applyServerUser(data.user);
      if (data.streakResult?.bonusAwarded > 0) {
        say(`🔥 مكافأة الالتزام اليومي (اليوم ${data.streakResult.streakDays}): +${data.streakResult.bonusAwarded} نقطة!`);
      }
      state.booted = true;
      renderStatusStrip();
      renderAdMobSlot();
    } catch (err) {
      console.warn("MY AI session boot warning:", err);
      renderStatusStrip();
    }
  }

  // Wrap index.html's myaiSecurePostOptions & myaiPostAI so all AI endpoints send x-myai-token, curriculum & update points
  const origSecureOpts = window.myaiSecurePostOptions;
  if (typeof origSecureOpts === "function") {
    window.myaiSecurePostOptions = function (payload, signal) {
      const opts = origSecureOpts(payload, signal);
      const token = getToken();
      if (token) {
        opts.headers = Object.assign({}, opts.headers, { "x-myai-token": token });
      }
      return opts;
    };
  }

  const origPostAI = window.myaiPostAI;
  if (typeof origPostAI === "function") {
    window.myaiPostAI = async function (payload, timeoutMs = 60000) {
      const cleanPayload = Object.assign({}, payload || {});
      if (!cleanPayload.dialect) {
        cleanPayload.dialect = state.user?.dialect || localStorage.getItem("myai_dialect_v1") || "ar_eg";
      }
      if (cleanPayload.assistant === "Study AI") {
        const cur = getCurriculum();
        if (!cleanPayload.curriculum) cleanPayload.curriculum = cur.curriculum;
        if (!cleanPayload.grade) cleanPayload.grade = cur.grade;
      }
      if (navigator.onLine === false) {
        const offlineActive = isOfflineModeActive();
        throw new Error(
          offlineActive
            ? "أنت الآن في وضع Offline: المحادثات المحفوظة والمعرض والألعاب المحلية جاهزة، أما استفسارات Gemini السحابية فتتطلب اتصالاً بالإنترنت."
            : "انقطع الاتصال بالإنترنت حاليًا. فعّل الإنترنت لإرسال الطلبات إلى Gemini (ولم يتم خصم أي نقاط).",
        );
      }
      const data = await origPostAI(cleanPayload, timeoutMs);
      if (data && typeof data.points === "number") {
        syncPointsUI(data.points);
        if (state.user) {
          state.user.points = data.points;
          if (typeof data.dailyUsed === "number") state.user.dailyUsed = data.dailyUsed;
          if (typeof data.dailyLimit === "number") state.user.dailyLimit = data.dailyLimit;
          try {
            localStorage.setItem(USER_CACHE_KEY, JSON.stringify(state.user));
          } catch (_) {}
          renderStatusStrip();
        }
      }
      return data;
    };
  }

  function isOfflineModeActive() {
    if (localStorage.getItem(OFFLINE_ENABLED_KEY) !== "1") return false;
    const sub = state.user?.subscription;
    if (sub && sub.offlineAllowed) {
      if (!sub.offlineLeaseUntil || sub.offlineLeaseUntil > Date.now()) return true;
    }
    const tokenPayload = decodeOfflineTokenPayload(localStorage.getItem(OFFLINE_TOKEN_KEY));
    if (tokenPayload && tokenPayload.typ === "myai_offline_lease" && tokenPayload.leaseUntil > Date.now()) {
      return true;
    }
    return false;
  }

  function renderStatusStrip() {
    const main = document.querySelector("main");
    if (!main) return;
    let strip = document.getElementById("myaiStatusStrip");
    if (!strip) {
      strip = document.createElement("section");
      strip.id = "myaiStatusStrip";
      main.insertBefore(strip, main.firstChild);
    }
    const online = navigator.onLine !== false;
    const sub = state.user?.subscription;
    const planLabel = sub?.planInfo?.name || "الباقة المجانية";
    const offlineReady = isOfflineModeActive();

    strip.className = "myai-status-strip" + (online ? "" : " is-offline");
    strip.innerHTML = `
      <div style="display:flex;align-items:center;gap:7px;flex-wrap:wrap">
        <span class="myai-badge ${online ? "ok" : "warn"}">${online ? "متصل بالإنترنت" : "وضع غير متصل · Offline"}</span>
        <span class="myai-badge">${esc(planLabel)}</span>
        ${offlineReady ? `<span class="myai-badge ok">Offline مُفعّل</span>` : ""}
      </div>
      <div class="myai-status-strip-actions">
        <button type="button" class="myai-mini-btn" onclick="openActivationCodePage()">🎟️ تفعيل اشتراك</button>
        <button type="button" class="myai-mini-btn" onclick="myaiOpenAccountPro('offline')">📴 وضع Offline</button>
        ${deferredInstallPrompt ? `<button type="button" class="myai-mini-btn primary-mini" onclick="myaiTriggerInstall()">📲 تثبيت</button>` : ""}
      </div>
    `;
  }

  function renderAdMobSlot() {
    const main = document.querySelector("main");
    if (!main) return;
    let slot = document.getElementById("myaiAdMobBannerSlot");
    if (!state.admob?.enabled) {
      if (slot) slot.remove();
      return;
    }
    if (!slot) {
      slot = document.createElement("div");
      slot.id = "myaiAdMobBannerSlot";
      slot.className = "myai-admob-slot";
      main.appendChild(slot);
    }
    slot.innerHTML = `<strong>مساحة إعلان Google AdMob مفعّلة</strong><div class="myai-v3-muted">عرض الوحدات الإعلانية يتطلب حزمة AdMob SDK داخل غلاف Android النهائي.</div>`;
  }

  // PWA Install Prompt
  window.addEventListener("beforeinstallprompt", (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
    renderStatusStrip();
  });

  window.myaiTriggerInstall = async function () {
    if (!deferredInstallPrompt) {
      say("استخدم قائمة المتصفح «إضافة إلى الشاشة الرئيسية» لتثبيت MY AI.");
      return;
    }
    deferredInstallPrompt.prompt();
    try {
      await deferredInstallPrompt.userChoice;
    } catch (_) {}
    deferredInstallPrompt = null;
    renderStatusStrip();
  };

  window.addEventListener("online", async () => {
    renderStatusStrip();
    if (state.booted) {
      try {
        await myaiApiFetch("/api/subscription", { method: "GET" });
        if (state.user?.syncEnabled) {
          await pushCloudBackup(true);
        }
      } catch (_) {}
    }
  });
  window.addEventListener("offline", () => {
    renderStatusStrip();
  });

  // =========================================================================
  // 1) Quick Start + Dead Buttons Fix
  // =========================================================================
  window.myaiOpenQuickStart = function () {
    const cur = getCurriculum();
    window.openFeature(
      "مرحبًا بك في MY AI Pro",
      "اختر المسار الذي تريد البدء به الآن عبر خادم Gemini الآمن.",
      `<div class="myai-v3-grid">
        <button class="myai-v3-tile" onclick="myaiOpenFootball3D()"><span style="font-size:24px">⚽</span><b>MY AI FOOTBALL 3D</b><small>مباراة كرة قدم حقيقية 3D</small></button>
        <button class="myai-v3-tile" onclick="openCompanion('Sport AI')"><span style="font-size:24px">🏃</span><b>Sport AI Coach</b><small>المدرب والمتابع الذكي + قاعدة اللاعبين</small></button>
        <button class="myai-v3-tile" onclick="openCompanion('Study AI')"><span style="font-size:24px">🎓</span><b>Study AI Pro</b><small>${esc(cur.curriculum)} · ${esc(cur.grade || "معلم من الصفر")}</small></button>
        <button class="myai-v3-tile" onclick="myaiOpenMediaStudio('edit')"><span style="font-size:24px">🎨</span><b>Media &amp; Photo Editor</b><small>تحليل، تحرير صور، فيديو وصوت</small></button>
        <button class="myai-v3-tile" onclick="openActivationCodePage()"><span style="font-size:24px">🎟️</span><b>تفعيل اشتراك</b><small>أدخل كود الاشتراك الفوري</small></button>
        <button class="myai-v3-tile" onclick="myaiOpenSupportCenter()"><span style="font-size:24px">📞</span><b>تواصل مع المطور</b><small>أرسل استفسارك أو اقتراحك</small></button>
      </div>`,
    );
  };

  function bindHeroAndMediaButtons() {
    const heroBtn = document.querySelector(".hero button.primary");
    if (heroBtn) {
      heroBtn.onclick = window.myaiOpenQuickStart;
    }
    const mediaButtons = document.querySelectorAll(".media-grid button.media");
    if (mediaButtons[0]) mediaButtons[0].onclick = () => window.myaiOpenMediaStudio("analyze");
    if (mediaButtons[1]) mediaButtons[1].onclick = () => window.myaiOpenMediaStudio("av");
    if (mediaButtons[2]) mediaButtons[2].onclick = () => window.myaiOpenMediaStudio("av");
    // Rebind bottom navigation direct references from earlier inline scripts
    const nav = document.querySelectorAll(".bottom button");
    if (nav[1]) nav[1].onclick = () => window.myaiOpenMediaStudio("analyze");
    if (nav[2]) nav[2].onclick = () => window.myaiOpenCenter();
    if (nav[4]) nav[4].onclick = () => window.myaiOpenAccountPro("profile");
  }

  // =========================================================================
  // 2) Study AI Pro Tutor (9 Pedagogical Capabilities + Curriculum Persistence)
  // =========================================================================
  function curriculumBoxHtml(compact = false) {
    const cur = getCurriculum();
    const presets = [
      "المنهج المصري",
      "المنهج السعودي",
      "المنهج الإماراتي",
      "المنهج الأردني",
      "المنهج المغربي",
      "منهج دولي / لغات",
      "الدراسة الجامعية",
    ];
    return `
      <details class="myai-study-bar" ${compact ? "" : "open"}>
        <summary>📚 المنهج الدراسي المعتمد: ${esc(cur.curriculum)}${cur.grade ? " — " + esc(cur.grade) : ""}</summary>
        <div class="myai-pro-grid2" style="margin-top:8px">
          <div>
            <label style="font-size:12px">المنهج / الدولة</label>
            <select id="myaiStudyCurrSelect" class="feature-field" onchange="myaiApplyCurriculumFromInputs()">
              ${presets.map((p) => `<option ${cur.curriculum === p ? "selected" : ""}>${p}</option>`).join("")}
              ${presets.includes(cur.curriculum) ? "" : `<option selected>${esc(cur.curriculum)}</option>`}
            </select>
          </div>
          <div>
            <label style="font-size:12px">الصف أو المرحلة أو المقرر</label>
            <input id="myaiStudyGradeInput" class="feature-field" value="${esc(cur.grade)}" placeholder="مثال: الصف الثالث الثانوي / أولى طب" onchange="myaiApplyCurriculumFromInputs()">
          </div>
        </div>
        <button type="button" class="myai-mini-btn" style="margin-top:4px" onclick="myaiApplyCurriculumFromInputs(true)">💾 تثبيت المنهج لكل شروحات Study AI</button>
      </details>
    `;
  }

  window.myaiApplyCurriculumFromInputs = function (showToast = false) {
    const cEl = document.getElementById("myaiStudyCurrSelect");
    const gEl = document.getElementById("myaiStudyGradeInput");
    if (!cEl) return;
    const saved = saveCurriculum(cEl.value, gEl ? gEl.value : "");
    const summary = document.querySelector(".myai-study-bar summary");
    if (summary) {
      summary.textContent = `📚 المنهج الدراسي المعتمد: ${saved.curriculum}${saved.grade ? " — " + saved.grade : ""}`;
    }
    if (showToast) say("تم اعتماد المنهج الدراسي بنجاح");
  };

  window.myaiPickStudySubject = function (subj) {
    window.studyAction("شرح");
    setTimeout(() => {
      const el = document.getElementById("studySubject");
      if (el) {
        el.value = subj;
        el.focus();
      }
    }, 30);
  };

  window.showStudyMenu = function () {
    const subjects = ["الفيزياء", "الكيمياء", "الأحياء", "الرياضيات", "اللغة العربية", "اللغة الإنجليزية"];
    window.openFeature(
      "Study AI Pro · المعلّم الشخصي",
      "شرح من الصفر، تبسيط، قوانين ورموز، أمثلة عملية، تدريب وتوجيه للحل، وسبورة تفاعلية وفق منهجك.",
      `${curriculumBoxHtml(false)}
      <div class="myai-subject-chips">
        ${subjects.map((s) => `<button type="button" class="myai-mini-btn" onclick="myaiPickStudySubject('${s}')">📖 ${s}</button>`).join("")}
      </div>
      <div class="myai-v3-grid">
        <button class="myai-v3-tile" onclick="studyAction('شرح')">📘<b>شرح من الصفر</b><small>مفاهيم وقوانين وأمثلة وتطبيقات</small></button>
        <button class="myai-v3-tile" onclick="studyAction('حل')">✍️<b>حل بالتفكير والخطوات</b><small>معطيات، قانون، وحدات وسبب كل خطوة</small></button>
        <button class="myai-v3-tile" onclick="studyAction('تدريب')">🧩<b>درّبني بنفسي</b><small>تلميحات متدرجة لتصل للحل بنفسك</small></button>
        <button class="myai-v3-tile" onclick="myaiOpenStudyBoard()">🧑‍🏫<b>السبورة الذكية</b><small>شرح بالورقة والقلم والرسم والصوت</small></button>
        <button class="myai-v3-tile" onclick="studyAction('اختبارات')">📝<b>اختبارات ذكية</b><small>أسئلة وتصحيح وتفسير الإجابة</small></button>
        <button class="myai-v3-tile" onclick="showAssistantChat('Study AI')">📷<b>محادثة + تصوير درس</b><small>ناقش المدرس وارفع صور الأسئلة</small></button>
      </div>
      <div id="studyArea"></div>`,
    );
  };

  const baseStudyAction = window.studyAction;
  window.studyAction = function (type) {
    const area = document.getElementById("studyArea");
    if (!area) return;
    if (type === "تدريب") {
      area.innerHTML = `<div class="feature-result">
        <h3>🧩 تدريب موجه لتصل للحل بنفسك</h3>
        <label for="studySubject">المادة أو الدرس</label>
        <input class="feature-field" id="studySubject" placeholder="مثال: الفيزياء — قانون أوم">
        <label for="studyQuestion">اكتب المسألة أو السؤال</label>
        <textarea class="feature-field" id="studyQuestion" rows="3" placeholder="سيقسم المدرس السؤال ويعطيك تلميحًا متدرجًا دون حرق الحل..."></textarea>
        <button class="primary feature-action" id="studySubmitBtn" onclick="studySubmitPro('تدريب','guided_practice')">ابدأ التدريب الموجّه</button>
        <div id="studyFeedback"></div>
      </div>`;
      return;
    }
    if (type === "اختبارات") {
      if (typeof baseStudyAction === "function") baseStudyAction("اختبارات");
      return;
    }
    const modeName = type === "شرح" ? "شرح من الصفر + القوانين والأمثلة" : "حل تفصيلي خطوة بخطوة";
    const teachMode = type === "شرح" ? "explain_from_scratch" : "solve_stepwise";
    area.innerHTML = `<div class="feature-result">
      <h3>${esc(modeName)}</h3>
      <label for="studySubject">المادة أو الموضوع</label>
      <input class="feature-field" id="studySubject" placeholder="مثال: الرياضيات، الكيمياء، النحو...">
      <label for="studyQuestion">اكتب الدرس أو السؤال</label>
      <textarea class="feature-field" id="studyQuestion" rows="3" placeholder="اكتب ما تريد تعلمه أو حله..."></textarea>
      <button class="primary feature-action" id="studySubmitBtn" onclick="studySubmitPro('${esc(type)}','${teachMode}')">متابعة</button>
      <div id="studyFeedback"></div>
    </div>`;
  };

  window.studySubmitPro = async function (type, teachingMode) {
    window.myaiApplyCurriculumFromInputs(false);
    const cur = getCurriculum();
    const subject = (document.getElementById("studySubject")?.value || "").trim();
    const question = (document.getElementById("studyQuestion")?.value || "").trim();
    const fb = document.getElementById("studyFeedback");
    const btn = document.getElementById("studySubmitBtn");
    if (!subject && !question) {
      say("اكتب المادة أو السؤال أولاً");
      return;
    }
    if (btn) btn.disabled = true;
    fb.innerHTML = `<p>⏳ يجهز Study AI (${esc(cur.curriculum)}) شرحًا متدرجًا لـ <b>${esc(subject || "سؤالك")}</b>...</p>`;
    try {
      const mode = type === "حل" || type === "تدريب" ? "study_solve" : "study_explain";
      const promptText = `(${type} — ${cur.curriculum} ${cur.grade}) المادة: ${subject || "عام"} — ${question || subject}`;
      const history = typeof window.myaiGetHistory === "function" ? window.myaiGetHistory("Study AI") : [];
      const data = await window.myaiPostAI({
        assistant: "Study AI",
        mode,
        teachingMode,
        curriculum: cur.curriculum,
        grade: cur.grade,
        subject,
        question,
        message: promptText,
        history,
      });
      const reply = String(data.reply || data.text || "");
      if (typeof window.myaiPushHistory === "function") {
        window.myaiPushHistory("Study AI", "user", promptText);
        window.myaiPushHistory("Study AI", "model", reply);
      }
      fb.innerHTML = `<div style="margin-top:8px">
        <b>${esc(type)} · ${esc(subject || "Study AI")}</b>
        <p style="margin-top:8px;white-space:pre-wrap">${esc(reply)}</p>
        <div class="myai-study-followups">
          <button type="button" onclick="studyFollowupTeaching('re_explain_simpler')">🔁 لم أفهم — اشرح بأسلوب أبسط</button>
          <button type="button" onclick="studyFollowupTeaching('check_understanding')">❓ اختبر فهمي بسؤال</button>
          <button type="button" onclick="studyFollowupTeaching('guided_practice')">🧩 درّبني خطوة بخطوة</button>
          <button type="button" onclick="showAssistantChat('Study AI')">💬 فتح المحادثة الكاملة</button>
        </div>
      </div>`;
    } catch (err) {
      fb.innerHTML = `<p>⚠️ ${esc(err.message || "تعذر الاتصال بالخادم.")}</p><button class="primary feature-action" onclick="studySubmitPro('${esc(type)}','${esc(teachingMode)}')">إعادة المحاولة</button>`;
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  window.studyFollowupTeaching = async function (teachingMode) {
    const cur = getCurriculum();
    const fb = document.getElementById("studyFeedback");
    if (!fb) {
      window.showAssistantChat("Study AI");
      return;
    }
    const labelMap = {
      re_explain_simpler: "إعادة الشرح بأسلوب أبسط مع تشبيه يومي",
      check_understanding: "طرح سؤال للتأكد من فهمك",
      guided_practice: "التدريب التفاعلي خطوة بخطوة",
    };
    const promptMsg =
      teachingMode === "re_explain_simpler"
        ? "لم أفهم الشرح السابق تمامًا، من فضلك اشرحه بأسلوب مختلف وأبسط مع مثال من الحياة اليومية."
        : teachingMode === "check_understanding"
          ? "اطرح عليّ سؤالاً تطبيقيًا واحدًا مناسبًا للتأكد من فهمي ولا تعطني الحل مسبقًا."
          : "درّبني خطوة بخطوة للوصول إلى حل مسألة مشابهة بنفسي مع تلميح أول فقط.";

    const noteEl = document.createElement("p");
    noteEl.textContent = "⏳ " + (labelMap[teachingMode] || "جاري التجهيز") + "...";
    fb.appendChild(noteEl);
    try {
      const history = typeof window.myaiGetHistory === "function" ? window.myaiGetHistory("Study AI") : [];
      const data = await window.myaiPostAI({
        assistant: "Study AI",
        teachingMode,
        curriculum: cur.curriculum,
        grade: cur.grade,
        message: promptMsg,
        history,
      });
      const reply = String(data.reply || data.text || "");
      if (typeof window.myaiPushHistory === "function") {
        window.myaiPushHistory("Study AI", "user", promptMsg);
        window.myaiPushHistory("Study AI", "model", reply);
      }
      noteEl.innerHTML = `<div class="myai-pro-card"><strong>${esc(labelMap[teachingMode] || "Study AI")}</strong><p style="white-space:pre-wrap;margin:6px 0 0">${esc(reply)}</p></div>`;
    } catch (err) {
      noteEl.textContent = "⚠️ " + (err.message || "تعذر إتمام الطلب.");
    }
  };

  // Clean TTS reading without button labels
  window.speakAssistantLast = function () {
    const log = document.getElementById("aiChatLog");
    if (!log) return;
    const bubbles = log.querySelectorAll(".ai-bubble.bot");
    const last = bubbles[bubbles.length - 1];
    if (!last) {
      say("لا يوجد رد لتشغيله");
      return;
    }
    if (!window.speechSynthesis) {
      say("تشغيل الصوت غير مدعوم");
      return;
    }
    const textOnly = String(last.dataset.fullText || last.querySelector(".myai-bubble-text")?.textContent || last.textContent || "").trim();
    const u = new SpeechSynthesisUtterance(textOnly);
    const d = state.user?.dialect || localStorage.getItem("myai_dialect_v1") || "ar_eg";
    u.lang = d === "en" ? "en-US" : "ar-EG";
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  function revealAndAttachActions(el, fullText, animate) {
    if (!el || el.dataset.myaiEnhanced === "1") return;
    const clean = String(fullText || "").trim();
    if (!clean || clean.startsWith("⏳") || clean.startsWith("⚠️")) return;
    el.dataset.myaiEnhanced = "1";
    el.dataset.fullText = clean;
    el.textContent = "";
    const textNode = document.createElement("div");
    textNode.className = "myai-bubble-text";
    textNode.style.whiteSpace = "pre-wrap";
    el.appendChild(textNode);
    attachBubbleActions(el, () => el.dataset.fullText || clean);

    const reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!animate || reduceMotion || clean.length < 24) {
      textNode.textContent = clean;
      return;
    }
    const totalSteps = 16;
    const stepSize = Math.max(1, Math.ceil(clean.length / totalSteps));
    let pos = 0;
    const timer = setInterval(() => {
      if (!document.body.contains(el)) {
        clearInterval(timer);
        return;
      }
      pos = Math.min(clean.length, pos + stepSize);
      textNode.textContent = clean.slice(0, pos);
      const log = document.getElementById("aiChatLog");
      if (log) log.scrollTop = log.scrollHeight;
      if (pos >= clean.length) clearInterval(timer);
    }, 20);
  }

  // Enhance assistantBubble with Copy & Share buttons on bot responses
  const baseAssistantBubble = window.assistantBubble;
  window.assistantBubble = function (text, who = "bot") {
    const el = baseAssistantBubble ? baseAssistantBubble(text, who) : null;
    if (el && who === "bot" && !String(text).startsWith("⏳") && !String(text).startsWith("⚠️")) {
      revealAndAttachActions(el, text, false);
    }
    return el;
  };

  function attachBubbleActions(el, getTextFnOrStr) {
    if (!el || el.querySelector(".myai-bubble-actions")) return;
    const bar = document.createElement("div");
    bar.className = "myai-bubble-actions";
    const copyBtn = document.createElement("button");
    copyBtn.type = "button";
    copyBtn.textContent = "📋 نسخ";
    copyBtn.onclick = () => {
      const txt = typeof getTextFnOrStr === "function" ? getTextFnOrStr() : (el.dataset.fullText || el.querySelector(".myai-bubble-text")?.textContent || el.textContent);
      navigator.clipboard?.writeText(String(txt || "").trim());
      say("تم نسخ الرد");
    };
    const shareBtn = document.createElement("button");
    shareBtn.type = "button";
    shareBtn.textContent = "📤 مشاركة";
    shareBtn.onclick = async () => {
      const txt = String((typeof getTextFnOrStr === "function" ? getTextFnOrStr() : (el.dataset.fullText || el.querySelector(".myai-bubble-text")?.textContent || el.textContent)) || "").trim();
      if (navigator.share) {
        try {
          await navigator.share({ title: "MY AI", text: txt });
          return;
        } catch (_) {}
      }
      navigator.clipboard?.writeText(txt);
      say("تم نسخ النص للمشاركة");
    };
    bar.appendChild(copyBtn);
    bar.appendChild(shareBtn);
    el.appendChild(bar);
  }

  window.myaiQuickSetDialect = async function (dialect) {
    localStorage.setItem("myai_dialect_v1", dialect);
    if (state.user) state.user.dialect = dialect;
    document.querySelectorAll("[data-dialect-btn]").forEach((b) => b.classList.toggle("primary-mini", b.dataset.dialectBtn === dialect));
    try {
      await myaiApiFetch("/api/auth/preferences", {
        method: "POST",
        body: JSON.stringify({ dialect }),
      });
    } catch (_) {}
    const lbl = dialect === "ar_eg" ? "المصرية" : dialect === "ar_msa" ? "العربية الفصحى" : "English";
    say("تم ضبط لغة المساعد إلى: " + lbl);
  };

  window.myaiStepFont = async function (delta) {
    const cur = Math.max(13, Math.min(22, Number(localStorage.getItem("myai_chat_font") || 15)));
    const next = Math.max(13, Math.min(22, cur + delta));
    document.documentElement.style.setProperty("--myai-chat-font", next + "px");
    localStorage.setItem("myai_chat_font", String(next));
    if (state.user) state.user.chatFontSize = next;
    try {
      await myaiApiFetch("/api/auth/preferences", { method: "POST", body: JSON.stringify({ chatFontSize: next }) });
    } catch (_) {}
  };

  // Enhance showAssistantChat with Dialect Switcher, Font Size Controls, Live Typing Reveal & Study AI Curriculum Bar
  const baseShowAssistantChat = window.showAssistantChat;
  window.showAssistantChat = function (name) {
    baseShowAssistantChat(name);
    const chat = document.querySelector("#featureBody .ai-chat");
    if (!chat) return;
    const log = document.getElementById("aiChatLog");
    if (log && !log.dataset.myaiObserved) {
      log.dataset.myaiObserved = "1";
      const obs = new MutationObserver((mutations) => {
        for (const m of mutations) {
          const target = m.target.nodeType === 1 ? m.target : m.target.parentElement;
          const bubble = target && target.closest ? target.closest(".ai-bubble.bot") : null;
          if (bubble && !bubble.dataset.myaiEnhanced && !bubble.querySelector(".myai-v3-btn")) {
            const raw = bubble.textContent || "";
            if (raw && !raw.startsWith("⏳") && !raw.startsWith("⚠️")) {
              revealAndAttachActions(bubble, raw, true);
            }
          }
        }
      });
      obs.observe(log, { childList: true, characterData: true, subtree: true });
    }
    const curDialect = state.user?.dialect || localStorage.getItem("myai_dialect_v1") || "ar_eg";
    const bar = document.createElement("div");
    bar.className = "myai-chat-bar";
    bar.innerHTML = `
      <div style="display:flex;gap:5px;flex-wrap:wrap;align-items:center">
        <small class="myai-v3-muted">اللهجة:</small>
        <button type="button" class="myai-mini-btn ${curDialect === "ar_eg" ? "primary-mini" : ""}" data-dialect-btn="ar_eg" onclick="myaiQuickSetDialect('ar_eg')">🇪🇬 مصري</button>
        <button type="button" class="myai-mini-btn ${curDialect === "ar_msa" ? "primary-mini" : ""}" data-dialect-btn="ar_msa" onclick="myaiQuickSetDialect('ar_msa')">📜 فصحى</button>
        <button type="button" class="myai-mini-btn ${curDialect === "en" ? "primary-mini" : ""}" data-dialect-btn="en" onclick="myaiQuickSetDialect('en')">EN</button>
      </div>
      <div style="display:flex;gap:5px;align-items:center">
        <button type="button" class="myai-mini-btn" onclick="myaiStepFont(-1)">A-</button>
        <button type="button" class="myai-mini-btn" onclick="myaiStepFont(1)">A+</button>
      </div>
    `;
    chat.insertBefore(bar, chat.firstChild);

    if (name === "Study AI") {
      const wrapper = document.createElement("div");
      wrapper.innerHTML = curriculumBoxHtml(true);
      chat.insertBefore(wrapper.firstElementChild, chat.firstChild);
      const tools = chat.querySelector(".ai-chat-tools");
      if (tools) {
        const btns = [
          ["🔁 لم أفهم (بسّط الشرح)", "اشرح النقطة السابقة بأسلوب أبسط جدًا مع تشبيه عملي."],
          ["❓ اختبر فهمي", "اسألني سؤالاً واحدًا لتختبر فهمي لهذا الجزء دون أن تكتب الحل."],
          ["🧩 درّبني على الحل", "أعطني مسألة تدريبية وابدأ معي بالتلميح الأول فقط لأصل للحل بنفسي."],
        ];
        btns.forEach(([label, txt]) => {
          const b = document.createElement("button");
          b.type = "button";
          b.textContent = label;
          b.onclick = () => {
            const box = document.getElementById("aiChatText");
            if (box) {
              box.value = txt;
              window.sendAssistantChat();
            }
          };
          tools.appendChild(b);
        });
      }
    }
  };

  // Enhance openCalculator with Linear & Quadratic Equation Solver panel
  const baseOpenCalculator = window.openCalculator;
  if (typeof baseOpenCalculator === "function") {
    window.openCalculator = function () {
      baseOpenCalculator();
      const body = document.getElementById("featureBody");
      if (!body || document.getElementById("myaiEqSolverBox")) return;
      const box = document.createElement("div");
      box.id = "myaiEqSolverBox";
      box.className = "myai-pro-card";
      box.innerHTML = `
        <h3>📐 حلال المعادلات السريع (ax² + bx + c = 0)</h3>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px">
          <input id="eqA" type="number" step="any" class="feature-field" value="1" placeholder="a (اتركه 0 للخطية)">
          <input id="eqB" type="number" step="any" class="feature-field" value="-5" placeholder="b">
          <input id="eqC" type="number" step="any" class="feature-field" value="6" placeholder="c">
        </div>
        <button type="button" class="primary feature-action" onclick="myaiSolveQuadratic()">حل المعادلة الآن</button>
        <div id="eqSolverOut" class="myai-v3-muted" style="margin-top:8px">للمعادلة الخطية (bx + c = 0) اجعل قيمة a = 0.</div>
      `;
      body.appendChild(box);
    };
  }
  window.myaiSolveQuadratic = function () {
    const a = Number(document.getElementById("eqA")?.value || 0);
    const b = Number(document.getElementById("eqB")?.value || 0);
    const c = Number(document.getElementById("eqC")?.value || 0);
    const out = document.getElementById("eqSolverOut");
    if (!out) return;
    if (a === 0) {
      if (b === 0) {
        out.textContent = c === 0 ? "عدد لا نهائي من الحلول" : "لا يوجد حل حقيقي للمعادلة";
      } else {
        out.innerHTML = `معادلة خطية: <b>x = ${Number((-c / b).toPrecision(10))}</b>`;
      }
      return;
    }
    const disc = b * b - 4 * a * c;
    if (disc > 0) {
      const x1 = (-b + Math.sqrt(disc)) / (2 * a);
      const x2 = (-b - Math.sqrt(disc)) / (2 * a);
      out.innerHTML = `المميز Δ = ${disc} > 0 · جذران حقيقيان:<br><b>x₁ = ${Number(x1.toPrecision(10))}</b> &nbsp;|&nbsp; <b>x₂ = ${Number(x2.toPrecision(10))}</b>`;
    } else if (disc === 0) {
      const x = -b / (2 * a);
      out.innerHTML = `المميز Δ = 0 · جذر وحيد: <b>x = ${Number(x.toPrecision(10))}</b>`;
    } else {
      const real = (-b / (2 * a)).toFixed(4);
      const imag = (Math.sqrt(-disc) / (2 * a)).toFixed(4);
      out.innerHTML = `المميز Δ = ${disc} < 0 · جذران مركبان:<br><b>x = ${real} ± ${imag}i</b>`;
    }
  };

  // =========================================================================
  // 3) IndexedDB Media Gallery + Full Media Studio
  // =========================================================================
  function openMediaDb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) {
        reject(new Error("IndexedDB غير متاح في هذا المتصفح."));
        return;
      }
      const req = indexedDB.open(MEDIA_DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(MEDIA_STORE_NAME)) {
          db.createObjectStore(MEDIA_STORE_NAME, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error("تعذر فتح معرض الوسائط"));
    });
  }

  async function saveToGallery(item) {
    const db = await openMediaDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(MEDIA_STORE_NAME, "readwrite");
      const store = tx.objectStore(MEDIA_STORE_NAME);
      const record = Object.assign(
        {
          id: "med_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7),
          createdAt: Date.now(),
          folder: "عام",
        },
        item,
      );
      store.put(record);
      tx.oncomplete = () => resolve(record);
      tx.onerror = () => reject(tx.error || new Error("تعذر الحفظ في المعرض"));
    });
  }

  async function listGalleryItems() {
    const db = await openMediaDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(MEDIA_STORE_NAME, "readonly");
      const req = tx.objectStore(MEDIA_STORE_NAME).getAll();
      req.onsuccess = () => {
        const arr = Array.isArray(req.result) ? req.result : [];
        arr.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        resolve(arr);
      };
      req.onerror = () => reject(req.error || new Error("تعذر قراءة المعرض"));
    });
  }

  async function removeGalleryItem(id) {
    const db = await openMediaDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(MEDIA_STORE_NAME, "readwrite");
      tx.objectStore(MEDIA_STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  window.myaiOpenMediaStudio = function (initialTab = "analyze") {
    if (typeof window.myaiSetNavActive === "function") window.myaiSetNavActive(1);
    const tabs = [
      ["analyze", "🖼️ تحليل الصور"],
      ["edit", "✂️ محرر الصور"],
      ["create", "✨ الصور والوصف"],
      ["av", "🎬 الفيديو والصوت"],
      ["gallery", "🗂️ معرضي المحفوظ"],
    ];
    window.openFeature(
      "استوديو الوسائط · Media Studio",
      "تحليل الصور بالذكاء الاصطناعي، تعديل وتحرير الصور محليًا، هندسة الأوصاف، سيناريوهات الفيديو والصوت، ومعرضك المنظم.",
      `<div class="myai-pro-tabs">
        ${tabs.map(([id, label]) => `<button type="button" class="myai-pro-tab ${initialTab === id ? "active" : ""}" data-studio-tab="${id}" onclick="myaiStudioSwitch('${id}')">${label}</button>`).join("")}
      </div>
      <div id="myaiStudioBody"></div>`,
    );
    window.myaiStudioSwitch(initialTab);
  };

  window.myaiOpenCreative = function () {
    window.myaiOpenMediaStudio("analyze");
  };

  let studioEditorState = { img: null, rot: 0, flipX: false, bright: 100, contrast: 100, sat: 100, preset: "none", text: "" };

  window.myaiStudioSwitch = async function (tab) {
    document.querySelectorAll("[data-studio-tab]").forEach((b) => b.classList.toggle("active", b.dataset.studioTab === tab));
    const body = document.getElementById("myaiStudioBody");
    if (!body) return;

    if (tab === "edit") {
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>✂️ محرر وتعديل الصور الفوري (Canvas Editor)</h3>
          <input id="editorImgInput" type="file" accept="image/*" hidden onchange="myaiEditorLoadFile(this)">
          <div style="display:flex;gap:7px;flex-wrap:wrap;margin:8px 0">
            <button type="button" class="primary" onclick="document.getElementById('editorImgInput').click()">📁 اختيار صورة للتعديل</button>
            ${lastStudioAnalyzedImage ? `<button type="button" class="myai-mini-btn" onclick="myaiEditorLoadDataUrl(lastStudioAnalyzedImage)">🔄 استيراد آخر صورة مرفوعة</button>` : ""}
          </div>
          <div class="myai-editor-canvas-wrap"><canvas id="myaiEditorCanvas" width="480" height="320"></canvas></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin:6px 0">
            <button type="button" class="myai-mini-btn" onclick="myaiEditorRotate()">↻ تدوير 90°</button>
            <button type="button" class="myai-mini-btn" onclick="myaiEditorFlip()">⇆ قلب أفقي</button>
            <button type="button" class="myai-mini-btn" onclick="myaiEditorPreset('none')">أصلي</button>
            <button type="button" class="myai-mini-btn" onclick="myaiEditorPreset('grayscale(100%)')">أبيض وأسود</button>
            <button type="button" class="myai-mini-btn" onclick="myaiEditorPreset('sepia(80%)')">كلاسيكي Sepia</button>
          </div>
          <div class="myai-pro-grid2">
            <label>السطوع <input id="edBright" type="range" min="40" max="180" value="${studioEditorState.bright}" oninput="myaiEditorRender()"></label>
            <label>التباين <input id="edContrast" type="range" min="40" max="180" value="${studioEditorState.contrast}" oninput="myaiEditorRender()"></label>
            <label>التشبع اللوني <input id="edSat" type="range" min="0" max="200" value="${studioEditorState.sat}" oninput="myaiEditorRender()"></label>
            <input id="edTextStamp" class="feature-field" style="margin:0" placeholder="نص / علامة مائية فوق الصورة..." oninput="myaiEditorRender()">
          </div>
          <div class="myai-pro-grid2" style="margin-top:10px">
            <button type="button" class="primary" onclick="myaiEditorSaveGallery()">💾 حفظ بالمعرض</button>
            <button type="button" class="myai-v3-btn" onclick="myaiEditorDownload()">⬇️ تنزيل PNG</button>
          </div>
        </div>
      `;
      if (lastStudioAnalyzedImage && !studioEditorState.img) {
        window.myaiEditorLoadDataUrl(lastStudioAnalyzedImage);
      } else {
        window.myaiEditorRender();
      }
      return;
    }

    if (tab === "analyze") {
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>🖼️ رفع وتحليل الصور عبر Gemini Vision</h3>
          <p class="myai-v3-muted">ارفع أي صورة (ورقة امتحان، رسم هندسي، تصميم، منتج، أو نص) ليقرأها Gemini ويحللها بدقة.</p>
          <input id="studioImgInput" type="file" accept="image/*" hidden onchange="myaiStudioPickImage(this)">
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0">
            <button type="button" class="primary" onclick="document.getElementById('studioImgInput').click()">📁 اختيار صورة</button>
            <select id="studioImgFolder" class="feature-field" style="width:auto;margin:0;min-width:130px">
              <option>دراسة</option><option>تصميم</option><option>أفكار</option><option selected>عام</option>
            </select>
          </div>
          <div id="studioImgPreview">${lastStudioAnalyzedImage ? `<img src="${lastStudioAnalyzedImage}" alt="الصورة المرفوعة" style="max-width:100%;max-height:220px;border-radius:12px;display:block;margin:8px auto">` : ""}</div>
          <label>ماذا تريد من Gemini تحليلُه في الصورة؟</label>
          <textarea id="studioAnalyzePrompt" class="feature-field" rows="2" placeholder="مثال: استخرج النص واشرحه بالتفصيل أو حل المسألة بالخطوات..."></textarea>
          <button type="button" class="primary feature-action" id="studioAnalyzeBtn" onclick="myaiStudioRunAnalyze()">🔍 تحليل الصورة عبر Gemini</button>
          <div id="studioAnalyzeOut"></div>
        </div>
      `;
      return;
    }

    if (tab === "create") {
      const genReady = state.imageGenEnabled;
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>✨ مهندس أوصاف الصور (Prompt Architect · مجاني بـ Gemini)</h3>
          <p class="myai-v3-muted">اكتب فكرتك بالعربية وسيحوّلها Gemini إلى وصف احترافي دقيق جاهز لتوليد الصور مع تفاصيل الإضاءة والعدسة.</p>
          <textarea id="studioPromptIdea" class="feature-field" rows="2" placeholder="مثال: رائد فضاء عربي ينظر إلى أهرامات الجيزة ليلًا بإضاءة حمراء وسوداء سينمائية"></textarea>
          <button type="button" class="primary feature-action" onclick="myaiStudioEnhance('image','studioPromptIdea','studioEnhanceOut')">✨ تحسين وتصميم الوصف</button>
          <div id="studioEnhanceOut"></div>
        </div>

        <div class="myai-pro-card">
          <div class="myai-pro-row">
            <h3>🎨 توليد الصور بالذكاء الاصطناعي</h3>
            <span class="myai-badge ${genReady ? "ok" : "warn"}">${genReady ? "مفعّل على الخادم" : "بانتظار موافقة المفتاح المدفوع"}</span>
          </div>
          <p class="myai-v3-muted">${
            genReady
              ? "اكتب وصف الصورة المطلوبة وسيتم توليدها وحفظها في معرضك."
              : "ملاحظة أمان وصدق: نموذج توليد الصور الحقيقي (Gemini Image) يتطلب تفعيل مفتاح مدفوع / Cloud Billing وإضافة ENABLE_GEMINI_IMAGE_GEN=true في Secrets بعد موافقتك. لن نعرض صورًا وهمية أبدًا."
          }</p>
          <textarea id="studioGenPrompt" class="feature-field" rows="2" placeholder="وصف الصورة المراد توليدها..."></textarea>
          <select id="studioGenRatio" class="feature-field">
            <option value="1:1">مربع 1:1</option>
            <option value="9:16">طولي للهاتف 9:16</option>
            <option value="16:9">عريض 16:9</option>
            <option value="3:4">3:4</option>
          </select>
          <button type="button" class="primary feature-action" onclick="myaiStudioGenerateImage()">🎨 طلب توليد الصورة الحقيقية</button>
          <div id="studioGenOut"></div>
        </div>
      `;
      return;
    }

    if (tab === "av") {
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>🎬 استوديو سيناريو الفيديو والصوت (Gemini)</h3>
          <textarea id="studioAvIdea" class="feature-field" rows="2" placeholder="اكتب فكرة الفيديو أو التعليق الصوتي..."></textarea>
          <div class="myai-pro-grid2">
            <button type="button" class="primary" onclick="myaiStudioEnhance('video','studioAvIdea','studioAvOut')">🎬 كتابة سيناريو فيديو</button>
            <button type="button" class="myai-v3-btn" onclick="myaiStudioEnhance('audio','studioAvIdea','studioAvOut')">🎙️ نص تعليق صوتي</button>
          </div>
          <div id="studioAvOut"></div>
        </div>
        <div class="myai-pro-card">
          <h3>🎧 تسجيل وتفريغ الصوت بالذكاء الاصطناعي</h3>
          <p class="myai-v3-muted">سجّل صوتك ليفرّغه Gemini إلى نص عربي دقيق ويرد عليه أو يحفظه في معرضك.</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="button" class="myai-v3-btn" id="studioRecBtn" onclick="myaiStudioToggleRecord()">⏺️ بدء / إيقاف التسجيل</button>
            <button type="button" class="primary" onclick="myaiStudioTranscribe()">📝 تفريغ وتحليل التسجيل</button>
          </div>
          <div id="studioRecStatus" class="myai-v3-muted" style="margin-top:8px">${avAudioBlob ? "🎧 يوجد تسجيل جاهز للتفريغ." : ""}</div>
          <div id="studioRecOut"></div>
        </div>
      `;
      return;
    }

    if (tab === "gallery") {
      body.innerHTML = `<div class="myai-pro-card"><h3>🗂️ معرض الوسائط المحفوظ (IndexedDB)</h3>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:8px">
          ${["الكل", "دراسة", "تصميم", "أفكار", "عام"].map((f) => `<button type="button" class="myai-mini-btn" onclick="myaiStudioRenderGallery('${f}')">${f}</button>`).join("")}
        </div>
        <div id="studioGalleryList"><p class="myai-v3-muted">⏳ جاري تحميل المعرض...</p></div>
      </div>`;
      window.myaiStudioRenderGallery("الكل");
    }
  };

  window.myaiEditorLoadDataUrl = function (dataUrl) {
    const img = new Image();
    img.onload = () => {
      studioEditorState = { img, rot: 0, flipX: false, bright: 100, contrast: 100, sat: 100, preset: "none", text: "" };
      window.myaiEditorRender();
    };
    img.src = dataUrl;
  };
  window.myaiEditorLoadFile = function (input) {
    const f = input.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => window.myaiEditorLoadDataUrl(String(r.result || ""));
    r.readAsDataURL(f);
  };
  window.myaiEditorRotate = function () { studioEditorState.rot = (studioEditorState.rot + 90) % 360; window.myaiEditorRender(); };
  window.myaiEditorFlip = function () { studioEditorState.flipX = !studioEditorState.flipX; window.myaiEditorRender(); };
  window.myaiEditorPreset = function (p) { studioEditorState.preset = p; window.myaiEditorRender(); };
  window.myaiEditorRender = function () {
    const c = document.getElementById("myaiEditorCanvas");
    if (!c) return;
    const ctx = c.getContext("2d");
    const b = document.getElementById("edBright")?.value || 100;
    const co = document.getElementById("edContrast")?.value || 100;
    const s = document.getElementById("edSat")?.value || 100;
    const txt = document.getElementById("edTextStamp")?.value || "";
    studioEditorState.bright = Number(b);
    studioEditorState.contrast = Number(co);
    studioEditorState.sat = Number(s);
    studioEditorState.text = txt;
    ctx.clearRect(0, 0, c.width, c.height);
    if (!studioEditorState.img) {
      ctx.fillStyle = "#120c10";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.fillStyle = "#aaa";
      ctx.font = "16px Tahoma, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("اختر صورة من جهازك للبدء في التعديل", c.width / 2, c.height / 2);
      return;
    }
    const img = studioEditorState.img;
    const rotRad = (studioEditorState.rot * Math.PI) / 180;
    const scale = Math.min(c.width / (studioEditorState.rot % 180 ? img.height : img.width), c.height / (studioEditorState.rot % 180 ? img.width : img.height));
    ctx.save();
    ctx.translate(c.width / 2, c.height / 2);
    ctx.rotate(rotRad);
    ctx.scale(studioEditorState.flipX ? -scale : scale, scale);
    ctx.filter = `brightness(${b}%) contrast(${co}%) saturate(${s}%)${studioEditorState.preset !== "none" ? " " + studioEditorState.preset : ""}`;
    ctx.drawImage(img, -img.width / 2, -img.height / 2);
    ctx.restore();
    if (txt) {
      ctx.save();
      ctx.font = "bold 24px Cairo, Arial, sans-serif";
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillText(txt, c.width / 2 + 2, c.height - 22);
      ctx.fillStyle = "#ffffff";
      ctx.fillText(txt, c.width / 2, c.height - 24);
      ctx.restore();
    }
  };
  window.myaiEditorDownload = function () {
    const c = document.getElementById("myaiEditorCanvas");
    if (!c || !studioEditorState.img) { say("اختر صورة أولاً"); return; }
    const a = document.createElement("a");
    a.href = c.toDataURL("image/png");
    a.download = "myai-edited-" + Date.now() + ".png";
    a.click();
  };
  window.myaiEditorSaveGallery = async function () {
    const c = document.getElementById("myaiEditorCanvas");
    if (!c || !studioEditorState.img) { say("اختر صورة أولاً"); return; }
    await saveToGallery({ kind: "edited_image", folder: "تصميم", title: "صورة معدلة · MY AI", dataUrl: c.toDataURL("image/png"), note: studioEditorState.text || "محرر الصور" });
    say("تم حفظ الصورة المعدلة في المعرض");
  };

  window.myaiStudioPickImage = function (input) {
    const file = input.files && input.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 8 * 1024 * 1024) {
      say("اختر صورة صالحة أقل من 8 ميجابايت");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      lastStudioAnalyzedImage = String(reader.result || "");
      const prev = document.getElementById("studioImgPreview");
      if (prev) {
        prev.innerHTML = `<img src="${lastStudioAnalyzedImage}" alt="الصورة المرفوعة" style="max-width:100%;max-height:220px;border-radius:12px;display:block;margin:8px auto">`;
      }
    };
    reader.readAsDataURL(file);
  };

  window.myaiStudioRunAnalyze = async function () {
    if (!lastStudioAnalyzedImage) {
      say("اختر صورة أولاً");
      return;
    }
    const out = document.getElementById("studioAnalyzeOut");
    const btn = document.getElementById("studioAnalyzeBtn");
    const prompt = (document.getElementById("studioAnalyzePrompt")?.value || "").trim();
    const folder = document.getElementById("studioImgFolder")?.value || "عام";
    if (btn) btn.disabled = true;
    out.innerHTML = `<p class="myai-v3-muted">⏳ يقرأ Gemini الصورة ويحللها الآن...</p>`;
    try {
      const data = await myaiApiFetch("/api/media/analyze", {
        method: "POST",
        timeoutMs: 55000,
        body: JSON.stringify({ image: lastStudioAnalyzedImage, prompt }),
      });
      const text = String(data.analysis || "");
      out.innerHTML = `<div class="feature-result"><strong>نتيجة التحليل (خصم ${data.costDeducted ?? 0} نقاط):</strong><p style="white-space:pre-wrap">${esc(text)}</p><button type="button" class="myai-v3-btn" onclick="myaiSaveCurrentAnalyzedToGallery('${esc(folder)}')">💾 حفظ الصورة والتحليل في المعرض</button></div>`;
      window._lastAnalyzeText = text;
    } catch (err) {
      out.innerHTML = `<div class="feature-result">⚠️ ${esc(err.message || "تعذر تحليل الصورة.")}</div>`;
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  window.myaiSaveCurrentAnalyzedToGallery = async function (folder) {
    if (!lastStudioAnalyzedImage) return;
    try {
      await saveToGallery({
        kind: "analyzed_image",
        folder: folder || "عام",
        title: "صورة محللة عبر Gemini",
        dataUrl: lastStudioAnalyzedImage,
        note: window._lastAnalyzeText || "",
      });
      say("تم الحفظ في معرض MY AI بنجاح");
    } catch (err) {
      say(err.message || "تعذر الحفظ");
    }
  };

  window.myaiStudioEnhance = async function (kind, inputId, outId) {
    const idea = (document.getElementById(inputId)?.value || "").trim();
    const out = document.getElementById(outId);
    if (!idea) {
      say("اكتب الفكرة أولاً");
      return;
    }
    out.innerHTML = `<p class="myai-v3-muted">⏳ جاري التجهيز عبر Gemini...</p>`;
    try {
      const data = await myaiApiFetch("/api/media/enhance-prompt", {
        method: "POST",
        timeoutMs: 50000,
        body: JSON.stringify({ kind, prompt: idea }),
      });
      const resText = String(data.result || "");
      window._lastEnhancedStudioText = { kind, idea, resText };
      out.innerHTML = `<div class="feature-result"><p style="white-space:pre-wrap">${esc(resText)}</p>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:8px">
          <button type="button" class="myai-mini-btn" onclick="navigator.clipboard?.writeText(window._lastEnhancedStudioText.resText);say('تم النسخ')">📋 نسخ</button>
          ${kind === "audio" ? `<button type="button" class="myai-mini-btn" onclick="myaiSpeakText(window._lastEnhancedStudioText.resText)">🔊 قراءة النص</button>` : ""}
          <button type="button" class="myai-mini-btn" onclick="myaiSaveStudioNoteToGallery()">💾 حفظ في المعرض</button>
        </div></div>`;
    } catch (err) {
      out.innerHTML = `<div class="feature-result">⚠️ ${esc(err.message)}</div>`;
    }
  };

  window.myaiSaveStudioNoteToGallery = async function () {
    const item = window._lastEnhancedStudioText;
    if (!item) return;
    try {
      await saveToGallery({
        kind: "studio_note",
        folder: "أفكار",
        title: item.idea.slice(0, 48),
        note: item.resText,
      });
      say("تم حفظ المخرجات في معرضك");
    } catch (err) {
      say(err.message || "تعذر الحفظ");
    }
  };

  window.myaiStudioGenerateImage = async function () {
    const prompt = (document.getElementById("studioGenPrompt")?.value || "").trim();
    const aspectRatio = document.getElementById("studioGenRatio")?.value || "1:1";
    const out = document.getElementById("studioGenOut");
    if (!prompt) {
      say("اكتب وصف الصورة أولاً");
      return;
    }
    out.innerHTML = `<p class="myai-v3-muted">⏳ جاري الاتصال بخدمة توليد الصور...</p>`;
    try {
      const data = await myaiApiFetch("/api/media/generate", {
        method: "POST",
        timeoutMs: 60000,
        body: JSON.stringify({ prompt, aspectRatio }),
      });
      window._lastGeneratedImage = { prompt, dataUrl: data.imageDataUrl };
      out.innerHTML = `<div class="feature-result">
        <img src="${data.imageDataUrl}" alt="${esc(prompt)}" style="width:100%;border-radius:12px;margin-bottom:8px">
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a class="myai-mini-btn primary-mini" href="${data.imageDataUrl}" download="myai-image.png" style="text-decoration:none">⬇️ تنزيل</a>
          <button type="button" class="myai-mini-btn" onclick="myaiSaveGenImage()">💾 حفظ في المعرض</button>
        </div>
      </div>`;
    } catch (err) {
      out.innerHTML = `<div class="feature-result"><strong>تنبيه الخدمة:</strong><p>${esc(err.message)}</p></div>`;
    }
  };

  window.myaiSaveGenImage = async function () {
    const g = window._lastGeneratedImage;
    if (!g?.dataUrl) return;
    await saveToGallery({
      kind: "generated_image",
      folder: "تصميم",
      title: g.prompt.slice(0, 45),
      dataUrl: g.dataUrl,
      note: g.prompt,
    });
    say("تم حفظ الصورة المولدة في المعرض");
  };

  window.myaiStudioToggleRecord = async function () {
    const status = document.getElementById("studioRecStatus");
    if (avRecorder && avRecorder.state === "recording") {
      avRecorder.stop();
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      say("تسجيل الصوت غير مدعوم في هذا المتصفح");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chunks = [];
      avRecorder = new MediaRecorder(stream);
      avRecorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      avRecorder.onstop = () => {
        avAudioBlob = new Blob(chunks, { type: avRecorder.mimeType || "audio/webm" });
        stream.getTracks().forEach((t) => t.stop());
        if (status) status.textContent = `🎧 تم تسجيل مقطع صوتي (${Math.round(avAudioBlob.size / 1024)} KB). اضغط «تفريغ وتحليل التسجيل».`;
      };
      avRecorder.start();
      if (status) status.textContent = "🔴 جاري التسجيل... اضغط مرة أخرى للإيقاف.";
    } catch (_) {
      say("يرجى السماح بالوصول للميكروفون");
    }
  };

  window.myaiStudioTranscribe = async function () {
    if (!avAudioBlob) {
      say("سجّل مقطعًا صوتيًا أولاً");
      return;
    }
    const out = document.getElementById("studioRecOut");
    out.innerHTML = `<p class="myai-v3-muted">⏳ جاري تفريغ وتحليل التسجيل عبر Gemini...</p>`;
    try {
      const dataUrl = await window.blobToDataURL(avAudioBlob);
      const data = await window.myaiPostAI({
        assistant: "Creative AI",
        message: "فرّغ التسجيل الصوتي ثم لخّص النقاط الأساسية فيه.",
        audio: dataUrl,
      });
      out.innerHTML = `<div class="feature-result"><p style="white-space:pre-wrap">${esc(data.reply || data.text || "")}</p></div>`;
    } catch (err) {
      out.innerHTML = `<div class="feature-result">⚠️ ${esc(err.message)}</div>`;
    }
  };

  window.myaiStudioRenderGallery = async function (folderFilter = "الكل") {
    const box = document.getElementById("studioGalleryList");
    if (!box) return;
    try {
      const all = await listGalleryItems();
      const filtered = folderFilter === "الكل" ? all : all.filter((x) => x.folder === folderFilter);
      if (!filtered.length) {
        box.innerHTML = `<p class="myai-v3-muted">لا توجد عناصر محفوظة في تصنيف «${esc(folderFilter)}» بعد.</p>`;
        return;
      }
      box.innerHTML = `<div class="myai-gallery-grid">
        ${filtered
          .map(
            (item) => `<div class="myai-media-item">
            ${item.dataUrl ? `<img src="${item.dataUrl}" alt="${esc(item.title)}">` : `<div style="height:80px;display:grid;place-items:center;background:#191216;border-radius:10px;font-size:28px">📝</div>`}
            <strong style="font-size:12px">${esc(item.title || "عنصر محفوظ")}</strong>
            <small class="myai-v3-muted">${esc(item.folder || "عام")} · ${formatDateAr(item.createdAt)}</small>
            ${item.note ? `<small class="myai-v3-muted" style="max-height:54px;overflow:hidden">${esc(item.note.slice(0, 120))}</small>` : ""}
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              ${item.dataUrl ? `<a class="myai-mini-btn" href="${item.dataUrl}" download="myai-${esc(item.id)}.png" style="text-decoration:none">⬇️</a>` : ""}
              <button type="button" class="myai-mini-btn" onclick="myaiDeleteMediaItem('${esc(item.id)}','${esc(folderFilter)}')">🗑️</button>
            </div>
          </div>`,
          )
          .join("")}
      </div>`;
    } catch (err) {
      box.innerHTML = `<p class="myai-v3-muted">⚠️ ${esc(err.message)}</p>`;
    }
  };

  window.myaiDeleteMediaItem = async function (id, filter) {
    await removeGalleryItem(id);
    window.myaiStudioRenderGallery(filter || "الكل");
    say("تم الحذف من المعرض");
  };

  window.myaiSpeakText = function (txt) {
    if (!window.speechSynthesis || !txt) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(txt);
    u.lang = "ar-EG";
    window.speechSynthesis.speak(u);
  };

  // =========================================================================
  // 4) Unified Account, Server Points, Plans, «تفعيل الاشتراك», Offline, Backup & Admin
  // =========================================================================
  window.openActivationCodePage = function () {
    window.myaiOpenAccountPro("activate");
  };

  window.myaiOpenAccountPro = async function (initialTab = "profile") {
    if (typeof window.myaiSetNavActive === "function") window.myaiSetNavActive(4);
    const u = state.user || {};
    const isOwner = u.role === "owner";
    const tabs = [
      ["profile", "👤 الحساب"],
      ["points", "💎 النقاط والمهام"],
      ["plans", "⭐ الباقات"],
      ["activate", "🎟️ تفعيل الاشتراك"],
      ["offline", "📴 وضع Offline"],
      ["backup", "☁️ النسخ والخصوصية"],
      ["support", "📞 تواصل مع المطور"],
      ["network", "📶 الشبكة"],
    ];
    if (isOwner) {
      tabs.push(["admin", "🛡️ إدارة المالك"]);
    }

    window.openFeature(
      "حسابي واشتراكاتي · MY AI",
      "إدارة الحساب، النقاط الموثوقة، الباقات، كود التفعيل، وضع Offline الحصري، وتواصل مع المطور.",
      `<div class="myai-pro-tabs">
        ${tabs.map(([id, label]) => `<button type="button" class="myai-pro-tab ${initialTab === id ? "active" : ""}" data-acct-tab="${id}" onclick="myaiAccountTabSwitch('${id}')">${label}</button>`).join("")}
      </div>
      <div id="myaiProAccountBody"><p class="myai-v3-muted">⏳ جاري التحميل...</p></div>`,
    );
    window.myaiAccountTabSwitch(initialTab);
  };

  window.myaiOpenSupportCenter = () => window.myaiOpenAccountPro("support");

  // Reroute legacy account triggers smoothly
  window.myaiOpenAccount = () => window.myaiOpenAccountPro("profile");
  window.myaiV3OpenAccount = (tab) => window.myaiOpenAccountPro(tab || "profile");
  window.openAccount = () => window.myaiOpenAccountPro("profile");
  window.openCodes = () => window.myaiOpenAccountPro("activate");
  window.openAds = () => window.myaiOpenAccountPro("plans");

  window.myaiAccountTabSwitch = async function (tab) {
    document.querySelectorAll("[data-acct-tab]").forEach((b) => b.classList.toggle("active", b.dataset.acctTab === tab));
    const body = document.getElementById("myaiProAccountBody");
    if (!body) return;

    if (tab === "network") {
      if (typeof window.myaiV3Network === "function") window.myaiV3Network();
      return;
    }

    if (tab === "support") {
      await renderSupportTab(body);
      return;
    }

    if (tab === "profile") {
      const u = state.user || {};
      const sub = u.subscription || {};
      const curDialect = u.dialect || localStorage.getItem("myai_dialect_v1") || "ar_eg";
      const curFont = Number(u.chatFontSize || localStorage.getItem("myai_chat_font") || 15);
      const curAccent = u.themeAccent || localStorage.getItem("myai_theme_accent") || "red";
      body.innerHTML = `
        <div class="myai-pro-card">
          <div class="profile-row">
            <div class="profile-avatar">${esc((u.name || "M").slice(0, 1))}</div>
            <div style="flex:1">
              <h3 style="margin:0">${esc(u.name || "مستخدم MY AI")} ${u.role === "owner" ? '<span class="myai-badge ok">مالك التطبيق</span>' : ""}</h3>
              <small class="myai-v3-muted">${esc(u.email || "جلسة محلية على الخادم (سجّل بريدًا لحفظ حسابك بين الأجهزة)")}</small><br>
              <span class="myai-badge">${esc(sub.planInfo?.name || "الباقة المجانية")}</span>
            </div>
          </div>
        </div>

        <div class="myai-pro-card">
          <h3>🎨 تخصيص اللهجة والخط والمظهر</h3>
          <label>لهجة ولغة المساعدين الذكيين</label>
          <select id="prefDialect" class="feature-field">
            <option value="ar_eg" ${curDialect === "ar_eg" ? "selected" : ""}>🇪🇬 العربية المصرية (الافتراضي)</option>
            <option value="ar_msa" ${curDialect === "ar_msa" ? "selected" : ""}>📜 العربية الفصحى</option>
            <option value="en" ${curDialect === "en" ? "selected" : ""}>🌐 English</option>
          </select>
          <label>حجم خط المحادثة: <b id="prefFontVal">${curFont}px</b></label>
          <input id="prefFontRange" type="range" min="13" max="22" value="${curFont}" class="feature-field" oninput="document.getElementById('prefFontVal').textContent=this.value+'px';document.documentElement.style.setProperty('--myai-chat-font',this.value+'px')">
          <label>لون الإضاءة والثيم</label>
          <select id="prefAccent" class="feature-field">
            <option value="red" ${curAccent === "red" ? "selected" : ""}>🔴 الأحمر القاني الأصلي (MY AI Classic)</option>
            <option value="gold" ${curAccent === "gold" ? "selected" : ""}>🟡 الذهبي الملكي</option>
            <option value="emerald" ${curAccent === "emerald" ? "selected" : ""}>🟢 الزمردي الرياضي</option>
            <option value="ice" ${curAccent === "ice" ? "selected" : ""}>🔵 الأزرق السماوي</option>
          </select>
          <button type="button" class="primary feature-action" onclick="myaiSaveAppPreferences()">حفظ التخصيص</button>
        </div>

        <div class="myai-pro-card">
          <h3>تحديث البيانات الشخصية</h3>
          <label>الاسم</label>
          <input id="proProfileName" class="feature-field" value="${esc(u.name || "")}">
          <label>الدولة</label>
          <input id="proProfileCountry" class="feature-field" value="${esc(u.country || "")}" placeholder="مصر / السعودية / ...">
          <button type="button" class="primary feature-action" onclick="myaiProSaveProfile()">حفظ المعلومات على الخادم</button>
        </div>

        ${
          u.isGuest
            ? `<div class="myai-pro-card">
                <h3>🔐 تسجيل حساب أو تسجيل الدخول</h3>
                <p class="myai-v3-muted">سجّل حسابًا لتحفظ نقاطك واشتراكاتك ونسختك الاحتياطية على أي جهاز. كلمات المرور تُشفّر على الخادم ولا تُعرض أبدًا.</p>
                <input id="proAuthEmail" type="email" class="feature-field" placeholder="البريد الإلكتروني">
                <input id="proAuthPassword" type="password" class="feature-field" placeholder="كلمة المرور (6 أحرف فأكثر)">
                <div class="myai-pro-grid2">
                  <button type="button" class="primary" onclick="myaiProRegister()">إنشاء / ربط الحساب</button>
                  <button type="button" class="myai-v3-btn" onclick="myaiProLogin()">تسجيل الدخول</button>
                </div>
              </div>`
            : `<div class="myai-pro-card">
                <div class="myai-pro-row">
                  <span>مسجّل بالبريد: <b>${esc(u.email)}</b></span>
                  <button type="button" class="myai-mini-btn" onclick="myaiProLogout()">تسجيل الخروج</button>
                </div>
              </div>`
        }

        ${
          u.role !== "owner" && !state.hasOwner
            ? `<details class="myai-pro-card">
                <summary style="cursor:pointer;font-weight:700">🛡️ تهيئة حساب مالك التطبيق (للمالك فقط — لمرة واحدة)</summary>
                <p class="myai-v3-muted" style="margin-top:8px">متاح فقط قبل إعداد أول مالك للتطبيق. إذا تم ضبط MYAI_OWNER_SECRET أو MYAI_OWNER_EMAIL في الخادم فسيتم التحقق منه.</p>
                <input id="ownEmail" type="email" class="feature-field" placeholder="بريد المالك">
                <input id="ownName" class="feature-field" placeholder="اسم المالك">
                <input id="ownPass" type="password" class="feature-field" placeholder="كلمة مرور قوية (8 أحرف فأكثر)">
                <input id="ownSecret" type="password" class="feature-field" placeholder="MYAI_OWNER_SECRET (إذا كان مضبوطًا بالخادم)">
                <button type="button" class="primary feature-action" onclick="myaiClaimOwner()">تفعيل حساب المالك</button>
              </details>`
            : ""
        }
      `;
      return;
    }

    if (tab === "points") {
      body.innerHTML = `<p class="myai-v3-muted">⏳ جاري جلب الرصيد والمعاملات والمكافآت من الخادم...</p>`;
      try {
        const data = await myaiApiFetch("/api/points", { method: "GET" });
        if (Array.isArray(data.shopItems)) state.shopItems = data.shopItems;
        if (data.event) state.event = data.event;
        const u = data.user || state.user || {};
        const sub = u.subscription || state.user?.subscription;
        const discount = sub?.planInfo?.pointDiscountPct || 0;
        const owned = Array.isArray(u.ownedItems) ? u.ownedItems : [];
        const evt = data.event;
        const evtClaimed = evt && u.lastEventClaimed === evt.id;

        const costsRows = Object.entries(data.serviceCosts || {})
          .map(([k, info]) => {
            const eff = discount >= 100 ? 0 : Math.max(0, Math.round((info.cost * (100 - discount)) / 100));
            return `<div class="myai-list-item myai-pro-row"><span>${esc(info.label)}</span><b>${eff} نقطة ${discount > 0 ? `(بدل ${info.cost})` : ""}</b></div>`;
          })
          .join("");
        const missionsHtml = (data.missions || [])
          .map(
            (m) => `<div class="myai-v3-mission">
              <div><b>${esc(m.title)}</b><small>+${m.points} نقطة</small></div>
              <button type="button" class="myai-v3-btn" ${m.claimed ? "disabled" : ""} onclick="myaiProClaimMission('${esc(m.id)}')">${m.claimed ? "تم الاستلام" : "استلام"}</button>
            </div>`,
          )
          .join("");
        const shopHtml = (data.shopItems || [])
          .map((it) => {
            const isOwned = owned.includes(it.id);
            return `<div class="myai-list-item">
              <div class="myai-pro-row"><b>${esc(it.icon)} ${esc(it.name)}</b><span class="myai-badge ${isOwned ? "ok" : ""}">${isOwned ? "مملوك ✓" : it.cost + " نقطة"}</span></div>
              <p class="myai-v3-muted" style="margin:5px 0">${esc(it.description)}</p>
              ${
                isOwned
                  ? `<button type="button" class="myai-mini-btn" disabled>مُفعّل بحسابك</button>`
                  : `<button type="button" class="primary" style="width:100%" onclick="myaiBuyVirtualItem('${esc(it.id)}')">شراء بـ ${it.cost} نقطة</button>`
              }
            </div>`;
          })
          .join("");
        const statsHtml = (data.gameStats || [])
          .map(
            (g) => `<div class="myai-list-item myai-pro-row"><span>🎮 ${esc(g.game_id)} (${g.wins}/${g.plays} فوز)</span><b>أعلى: ${g.high_score} · XP ${g.xp}</b></div>`,
          )
          .join("");
        const txHtml = (data.transactions || [])
          .map(
            (t) => `<div class="myai-list-item myai-pro-row">
              <span>${t.delta >= 0 ? "＋" + t.delta : t.delta} نقطة · ${esc(t.description)}</span>
              <small class="myai-v3-muted">${formatDateAr(t.created_at)}</small>
            </div>`,
          )
          .join("");

        body.innerHTML = `
          <div class="myai-pro-card">
            <div class="myai-v3-stat">
              <div><strong>${Number(data.points).toLocaleString("en-US")}</strong>رصيد النقاط الموثق</div>
              <div><strong>🔥 ${u.streakDays || 1} يوم</strong>سلسلة الالتزام اليومي</div>
            </div>
            <div class="myai-pro-row" style="margin-top:8px">
              <span class="myai-badge ok">استخدام AI اليوم: ${u.dailyUsed || 0}/${u.dailyLimit || 40}</span>
              <span class="myai-badge">نقاط الألعاب اليوم: ${u.dailyGamePoints || 0}/${u.dailyGamePointsCap || 150}</span>
            </div>
            <p class="myai-badge ok" style="margin-top:8px">ضمان: لا تُخصم أي نقاط عند فشل الطلب أو انقطاع الإنترنت</p>
          </div>

          ${
            evt && evt.active
              ? `<div class="myai-pro-card">
                  <div class="myai-pro-row">
                    <h3>🎊 فعالية: ${esc(evt.title)}</h3>
                    <span class="myai-badge ok">+${evt.bonusPoints} نقطة</span>
                  </div>
                  <p class="myai-v3-muted">${esc(evt.description)}</p>
                  <button type="button" class="primary feature-action" ${evtClaimed ? "disabled" : ""} onclick="myaiClaimEvent()">${evtClaimed ? "✓ تم استلام مكافأة هذه الفعالية" : `🎁 استلم +${evt.bonusPoints} نقطة الآن`}</button>
                </div>`
              : ""
          }

          <div class="myai-pro-card">
            <h3>🤝 برنامج الإحالة ودعوة الأصدقاء</h3>
            <p class="myai-v3-muted">شارك كودك مع مستخدمين جدد (بعد تسجيلهم بالبريد): يحصل المدعو على +60 نقطة وتحصل أنت على +100 نقطة (بحد أقصى 10 دعوات/أسبوع).</p>
            <div class="myai-pro-row" style="margin:8px 0">
              <span>كودك الخاص: <span class="myai-code-pill">${esc(u.referralCode || "REF-MYAI")}</span></span>
              <button type="button" class="myai-mini-btn" onclick="navigator.clipboard?.writeText('${esc(u.referralCode || "")}');say('تم نسخ كود الإحالة')">📋 نسخ الكود</button>
            </div>
            ${
              u.referredBy
                ? `<p class="myai-badge ok">✓ تم ربط الحساب بكود إحالة من قبل</p>`
                : `<div style="display:flex;gap:8px;margin-top:8px">
                    <input id="proReferralInput" class="feature-field" style="margin:0;direction:ltr;text-align:center;text-transform:uppercase" placeholder="REF-XXXXXX">
                    <button type="button" class="primary" onclick="myaiClaimReferral()">تفعيل</button>
                  </div>`
            }
          </div>

          <div class="myai-pro-card">
            <h3>🛒 متجر النقاط (مزايا بصرية وصوتية للألعاب والنادي)</h3>
            <div class="myai-pro-grid2">${shopHtml || "<p class='myai-v3-muted'>لا توجد عناصر حاليًا.</p>"}</div>
          </div>

          <div class="myai-pro-card"><h3>📊 تكلفة الخدمات بالنقاط</h3>${costsRows}</div>
          <div class="myai-pro-card"><h3>🎯 المهام اليومية</h3>${missionsHtml}</div>
          ${statsHtml ? `<div class="myai-pro-card"><h3>🏆 إحصائيات الألعاب والخبرة (XP)</h3>${statsHtml}</div>` : ""}
          <div class="myai-pro-card"><h3>📜 سجل معاملات النقاط</h3><div class="myai-table-list">${txHtml || "<p class='myai-v3-muted'>لا توجد معاملات بعد.</p>"}</div></div>
        `;
      } catch (err) {
        body.innerHTML = `<div class="myai-pro-card">⚠️ ${esc(err.message)}</div>`;
      }
      return;
    }

    if (tab === "plans") {
      const sub = state.user?.subscription || {};
      const plans = state.plans.length ? state.plans : [];
      const admobEnabled = Boolean(state.admob?.enabled);
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>باقتك الحالية: ${esc(sub.planInfo?.name || "الباقة المجانية")}</h3>
          <p class="myai-v3-muted">
            ${sub.isPaid ? (sub.expiresAt ? `تاريخ الانتهاء: ${formatDateAr(sub.expiresAt)} (متبقي ${daysRemaining(sub.expiresAt)} يومًا)` : "عضوية دائمة مدى الحياة") : "استخدام عبر الإنترنت فقط. يمكنك الترقية بكود التفعيل في أي وقت."}
          </p>
          <p class="myai-v3-muted">سياسة حفظ البيانات: عند انتهاء أي باقة تبقى محادثاتك وملفاتك وإعداداتك محفوظة بالكامل ولا يتم حذفها.</p>
        </div>

        <div class="myai-pro-grid2">
          ${plans
            .map(
              (p) => `<div class="myai-pro-card">
                <div class="myai-pro-row"><b>${esc(p.name)}</b><span class="myai-badge">${esc(p.badge)}</span></div>
                <p class="myai-v3-muted" style="margin:8px 0">${esc(p.description)}</p>
                <p style="font-size:12px">• حد يومي: ${p.dailyAiLimit} طلب<br>• خصم النقاط: ${p.pointDiscountPct}%<br>• وضع Offline: ${p.offlineAllowed ? "نعم (" + p.offlineLeaseDays + " يوم)" : "لا"}</p>
                ${
                  p.id !== "free"
                    ? `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
                        <button type="button" class="primary" style="flex:1" onclick="openActivationCodePage()">تفعيل بكود</button>
                        <button type="button" class="myai-v3-btn" onclick="myaiRequestUpgrade('${esc(p.id)}')">طلب ترقية</button>
                      </div>`
                    : ""
                }
              </div>`,
            )
            .join("")}
        </div>

        <div class="myai-pro-card">
          <h3>📺 إعداد Google AdMob</h3>
          <p class="myai-v3-muted">${admobEnabled ? "تكامل AdMob مفعّل في إعدادات المالك وجاهز للربط داخل حزمة Android." : "الإعلانات غير مفعّلة حاليًا (معطّلة افتراضيًا ولن تُعرض إعلانات وهمية)."}</p>
        </div>
      `;
      return;
    }

    if (tab === "activate") {
      const sub = state.user?.subscription || {};
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>🎟️ تفعيل الاشتراك عبر الكود</h3>
          <p class="myai-v3-muted">أدخل كود الاشتراك الذي حصلت عليه من مالك التطبيق لتفعيل باقتك فورًا (يعمل كل كود لمرة واحدة فقط ومربوط بالخادم).</p>
          <input id="redeemCodeInput" class="feature-field" style="direction:ltr;text-align:center;font-weight:800;letter-spacing:.08em" placeholder="MYAI-XXXX-XXXX-XXXX">
          <button type="button" class="primary feature-action" id="redeemCodeBtn" onclick="myaiRedeemCode()">تفعيل الكود الآن</button>
          <div id="redeemCodeResult"></div>
        </div>
        <div class="myai-pro-card">
          <strong>حالة اشتراكك الحالي:</strong> ${esc(sub.planInfo?.name || "الباقة المجانية")}
          ${sub.expiresAt ? `<div class="myai-v3-muted">ينتهي في: ${formatDateAr(sub.expiresAt)}</div>` : ""}
        </div>
      `;
      return;
    }

    if (tab === "offline") {
      const sub = state.user?.subscription || {};
      const enabled = isOfflineModeActive();
      const leaseRem = daysRemaining(sub.offlineLeaseUntil);
      const hasChromeAi = Boolean(window.LanguageModel || (window.ai && window.ai.languageModel));
      body.innerHTML = `
        <div class="myai-pro-card">
          <div class="myai-pro-row">
            <h3>📴 وضع Offline الحصري للمشتركين</h3>
            <span class="myai-badge ${enabled ? "ok" : "warn"}">${enabled ? "مُفعّل" : sub.offlineAllowed ? "جاهز للتفعيل" : "للمشتركين فقط"}</span>
          </div>
          <p class="myai-v3-muted">• المستخدم المجاني: أونلاين فقط.<br>• المشترك المدفوع: يمكنه تفعيل وضع Offline لاستخدام المحادثات المحفوظة، المعرض، الألعاب المحلية، والحاسبة بدون إنترنت لمدة ترخيص متجددة، وتتم المزامنة تلقائيًا فور عودة الشبكة.</p>
          ${
            sub.offlineAllowed
              ? `<p style="font-size:13px">مدة ترخيص Offline المتبقية: <b>${leaseRem !== null ? leaseRem + " يومًا" : "بحاجة للتفعيل"}</b></p>
                 <div class="myai-pro-grid2">
                   <button type="button" class="primary" onclick="myaiEnableOfflineLease()">⚡ تفعيل / تجديد ترخيص Offline</button>
                   <button type="button" class="myai-v3-btn" onclick="myaiDisableOfflineMode()">إيقاف وضع Offline</button>
                 </div>`
              : `<div class="feature-result"><p>هذه الميزة مقفولة للباقة المجانية. فعّل اشتراكك أولاً للاستمتاع بوضع Offline.</p>
                  <button type="button" class="primary feature-action" onclick="openActivationCodePage()">🎟️ الذهاب إلى «تفعيل الاشتراك»</button></div>`
          }
        </div>
        <div class="myai-pro-card">
          <h3>🧠 قدرات الذكاء الاصطناعي على الجهاز</h3>
          <p class="myai-v3-muted">${
            hasChromeAi
              ? "✅ متصفحك يدعم نموذج Chrome المحلي المدمج (On-Device AI) للمهام النصية البسيطة بدون إنترنت."
              : "ℹ️ نموذج Gemini السحابي يتطلب إنترنت، بينما تظل المحادثات المحفوظة، معرض Media Studio، Ultimate Club، الحاسبة، والألعاب المحلية تعمل بالكامل Offline."
          }</p>
        </div>
      `;
      return;
    }

    if (tab === "backup") {
      const u = state.user || {};
      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>💾 النسخ الاحتياطي والخصوصية</h3>
          <p class="myai-v3-muted">جميع محادثاتك، إعدادات الدراسة، ألعابك المخصصة، وناديك في Ultimate Club تُحفظ محليًا، ويمكنك تصديرها كملف JSON أو مزامنتها بأمان مع الخادم.</p>
          <label style="display:flex;align-items:center;gap:8px;margin:10px 0">
            <input type="checkbox" ${u.syncEnabled !== false ? "checked" : ""} onchange="myaiToggleSyncPrivacy(this.checked)">
            <span>السماح بالمزامنة السحابية للنسخ الاحتياطي عند الاتصال بالإنترنت</span>
          </label>
          <div class="myai-pro-grid2">
            <button type="button" class="primary" onclick="exportFullBackup()">⬇️ تصدير نسخة JSON</button>
            <button type="button" class="myai-v3-btn" onclick="document.getElementById('importBackupFile').click()">⬆️ استيراد نسخة JSON</button>
          </div>
          <input id="importBackupFile" type="file" accept=".json,application/json" hidden onchange="importFullBackup(this)">
          <div class="myai-pro-grid2" style="margin-top:9px">
            <button type="button" class="myai-v3-btn" onclick="pushCloudBackup(false)">☁️ رفع نسخة للخادم الآن</button>
            <button type="button" class="myai-v3-btn" onclick="pullCloudBackup()">📥 استرجاع من الخادم</button>
          </div>
        </div>
      `;
      return;
    }

    if (tab === "admin") {
      await renderOwnerAdminTab(body);
    }
  };

  window.myaiProSaveProfile = async function () {
    const name = (document.getElementById("proProfileName")?.value || "").trim();
    const country = (document.getElementById("proProfileCountry")?.value || "").trim();
    try {
      await myaiApiFetch("/api/auth/profile", {
        method: "POST",
        body: JSON.stringify({ name, country }),
      });
      say("تم حفظ بياناتك على الخادم");
      window.myaiAccountTabSwitch("profile");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiProRegister = async function () {
    const email = (document.getElementById("proAuthEmail")?.value || "").trim();
    const password = document.getElementById("proAuthPassword")?.value || "";
    const name = (document.getElementById("proProfileName")?.value || state.user?.name || "مستخدم MY AI").trim();
    const country = (document.getElementById("proProfileCountry")?.value || "").trim();
    try {
      await myaiApiFetch("/api/auth/register", {
        method: "POST",
        body: JSON.stringify({ email, password, name, country }),
      });
      say("تم إنشاء الحساب وربطه برصيدك بنجاح");
      window.myaiOpenAccountPro("profile");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiProLogin = async function () {
    const email = (document.getElementById("proAuthEmail")?.value || "").trim();
    const password = document.getElementById("proAuthPassword")?.value || "";
    try {
      await myaiApiFetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      say("تم تسجيل الدخول بنجاح");
      window.myaiOpenAccountPro("profile");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiProLogout = async function () {
    try {
      await myaiApiFetch("/api/auth/logout", { method: "POST" });
      localStorage.removeItem(OFFLINE_ENABLED_KEY);
      localStorage.removeItem(OFFLINE_TOKEN_KEY);
      say("تم تسجيل الخروج");
      window.myaiOpenAccountPro("profile");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiClaimOwner = async function () {
    const email = (document.getElementById("ownEmail")?.value || "").trim();
    const name = (document.getElementById("ownName")?.value || "مالك التطبيق").trim();
    const password = document.getElementById("ownPass")?.value || "";
    const ownerSecret = document.getElementById("ownSecret")?.value || "";
    try {
      await myaiApiFetch("/api/auth/owner-claim", {
        method: "POST",
        body: JSON.stringify({ email, name, password, ownerSecret }),
      });
      state.hasOwner = true;
      say("تم تفعيل حساب مالك التطبيق ولوحة التحكم بنجاح");
      window.myaiOpenAccountPro("admin");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiProClaimMission = async function (missionId) {
    try {
      const data = await myaiApiFetch("/api/missions/claim", {
        method: "POST",
        body: JSON.stringify({ missionId }),
      });
      if (typeof data.points === "number") syncPointsUI(data.points);
      window.MYAISound?.coin?.();
      say(`تم إضافة +${data.added} نقطة إلى رصيدك`);
      window.myaiAccountTabSwitch("points");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiClaimReferral = async function () {
    const code = (document.getElementById("proReferralInput")?.value || "").trim().toUpperCase();
    if (!code) {
      say("أدخل كود الإحالة أولاً");
      return;
    }
    try {
      const data = await myaiApiFetch("/api/referrals/claim", {
        method: "POST",
        body: JSON.stringify({ code }),
      });
      window.MYAISound?.fanfare?.();
      say(`🎉 تم تفعيل كود الإحالة وإضافة +${data.bonus || 60} نقطة لحسابك!`);
      window.myaiAccountTabSwitch("points");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiClaimEvent = async function () {
    try {
      const data = await myaiApiFetch("/api/events/claim", { method: "POST" });
      window.MYAISound?.fanfare?.();
      say(`🎊 تم استلام مكافأة الفعالية +${data.added || 0} نقطة!`);
      window.myaiAccountTabSwitch("points");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiRequestUpgrade = async function (plan) {
    try {
      const data = await myaiApiFetch("/api/subscription/request", {
        method: "POST",
        body: JSON.stringify({ plan }),
      });
      say(data.message || "تم تسجيل طلب الترقية");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiRedeemCode = async function () {
    const code = (document.getElementById("redeemCodeInput")?.value || "").trim();
    const out = document.getElementById("redeemCodeResult");
    const btn = document.getElementById("redeemCodeBtn");
    if (!code) {
      say("أدخل كود التفعيل أولاً");
      return;
    }
    if (btn) btn.disabled = true;
    try {
      const data = await myaiApiFetch("/api/codes/redeem", {
        method: "POST",
        body: JSON.stringify({ code }),
      });
      if (data.offlineToken) localStorage.setItem(OFFLINE_ENABLED_KEY, "1");
      out.innerHTML = `<div class="feature-result"><span class="myai-badge ok">تم التفعيل بنجاح</span><p>تم تفعيل <b>${esc(data.activatedPlan?.name || "الاشتراك")}</b>${data.expiresAt ? ` حتى ${formatDateAr(data.expiresAt)}` : " (دائم)"}، وإضافة +${data.bonusPoints || 0} نقطة إضافية!</p></div>`;
      say("مبروك! تم تفعيل اشتراكك بنجاح");
      renderStatusStrip();
    } catch (err) {
      out.innerHTML = `<div class="feature-result">⚠️ ${esc(err.message)}</div>`;
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  window.myaiEnableOfflineLease = async function () {
    try {
      const data = await myaiApiFetch("/api/subscription/offline-lease", { method: "POST" });
      if (data.offlineToken) {
        localStorage.setItem(OFFLINE_TOKEN_KEY, data.offlineToken);
        localStorage.setItem(OFFLINE_ENABLED_KEY, "1");
      }
      say("تم تفعيل وتجديد وضع Offline بنجاح");
      renderStatusStrip();
      window.myaiAccountTabSwitch("offline");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiDisableOfflineMode = function () {
    localStorage.removeItem(OFFLINE_ENABLED_KEY);
    say("تم إيقاف وضع Offline (لن يتم حذف أي بيانات)");
    renderStatusStrip();
    window.myaiAccountTabSwitch("offline");
  };

  // =========================================================================
  // 5) Export / Import JSON Backup & Cloud Sync
  // =========================================================================
  function collectBackupPayload() {
    const keys = [
      "myai_conversations_v1",
      "myai_study_curriculum_v1",
      "myai_companion_gender",
      "myai_tasbeeh_count",
      "myai_club_players",
      "myai_club_budget",
      "myai_club_state",
      "myai_custom_games_v1",
      "myai_ut_v3",
    ];
    const store = {};
    keys.forEach((k) => {
      const val = localStorage.getItem(k);
      if (val !== null) store[k] = val;
    });
    return {
      app: "MY AI Pro",
      version: 1,
      exportedAt: Date.now(),
      storage: store,
    };
  }

  function applyBackupPayload(payload) {
    if (!payload || typeof payload !== "object" || !payload.storage || typeof payload.storage !== "object") {
      throw new Error("ملف النسخة الاحتياطية غير صالح.");
    }
    const allowedPrefixes = ["myai_"];
    Object.entries(payload.storage).forEach(([k, v]) => {
      if (allowedPrefixes.some((p) => k.startsWith(p)) && typeof v === "string") {
        localStorage.setItem(k, v);
      }
    });
  }

  window.exportFullBackup = function () {
    const payload = collectBackupPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `myai-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    say("تم تصدير النسخة الاحتياطية");
  };

  window.importFullBackup = function (input) {
    const file = input.files && input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || "{}"));
        applyBackupPayload(parsed);
        say("تمت استعادة البيانات! سيتم تحديث الواجهة.");
        setTimeout(() => location.reload(), 600);
      } catch (err) {
        say(err.message || "ملف غير صالح");
      }
    };
    reader.readAsText(file);
  };

  window.pushCloudBackup = async function (silent = false) {
    try {
      const res = await myaiApiFetch("/api/sync/push", {
        method: "POST",
        body: JSON.stringify(collectBackupPayload()),
      });
      if (!silent) say("تم حفظ النسخة السحابية (" + formatDateAr(res.updatedAt) + ")");
    } catch (err) {
      if (!silent) say(err.message);
    }
  };

  window.pullCloudBackup = async function () {
    try {
      const data = await myaiApiFetch("/api/sync/pull", { method: "GET" });
      if (!data.backup) {
        say("لا توجد نسخة سحابية محفوظة لهذا الحساب بعد.");
        return;
      }
      applyBackupPayload(data.backup);
      say("تم استرجاع النسخة من الخادم بنجاح!");
      setTimeout(() => location.reload(), 600);
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiToggleSyncPrivacy = async function (enabled) {
    try {
      await myaiApiFetch("/api/auth/profile", {
        method: "POST",
        body: JSON.stringify({ syncEnabled: Boolean(enabled) }),
      });
      say(enabled ? "تم تفعيل المزامنة السحابية" : "تم تعطيل المزامنة السحابية لحفظ خصوصيتك محليًا");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiSaveAppPreferences = async function () {
    const dialect = document.getElementById("prefDialect")?.value || "ar_eg";
    const chatFontSize = Number(document.getElementById("prefFontRange")?.value || 15);
    const themeAccent = document.getElementById("prefAccent")?.value || "red";
    try {
      await myaiApiFetch("/api/auth/preferences", {
        method: "POST",
        body: JSON.stringify({ dialect, chatFontSize, themeAccent }),
      });
      applyThemeAndTypography({ dialect, chatFontSize, themeAccent });
      say("تم حفظ تفضيلات اللهجة والخط والمظهر");
    } catch (err) {
      say(err.message);
    }
  };

  async function renderSupportTab(body) {
    body.innerHTML = `<p class="myai-v3-muted">⏳ جاري تحميل مركز التواصل والدعم...</p>`;
    try {
      const [infoRes, ticketsRes] = await Promise.all([
        myaiApiFetch("/api/support/info", { method: "GET" }),
        myaiApiFetch("/api/support/tickets", { method: "GET" }),
      ]);
      const info = infoRes?.supportContact || infoRes?.contact || {};
      const tickets = Array.isArray(ticketsRes?.tickets) ? ticketsRes.tickets : [];
      const devEmail = info.contactEmail || info.email || "";
      const devWa = info.whatsappUrl || info.whatsapp || "";
      const devNote = info.notes || info.note || "";
      const channels = [
        info.developerName ? `👤 المطور: <b>${esc(info.developerName)}</b>` : "",
        devEmail ? `📧 البريد: <b dir="ltr">${esc(devEmail)}</b>` : "",
        devWa ? `💬 واتساب / تواصل: <b dir="ltr">${esc(devWa)}</b>` : "",
      ].filter(Boolean);

      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>📞 تواصل مع المطور</h3>
          ${channels.length ? `<div class="myai-list-item">${channels.join("<br>")}</div>` : ""}
          ${devNote ? `<p class="myai-v3-muted">${esc(devNote)}</p>` : ""}
          <label>نوع الرسالة</label>
          <select id="supCat" class="feature-field">
            <option value="suggestion">💡 اقتراح ميزة جديدة</option>
            <option value="bug">🐞 الإبلاغ عن مشكلة</option>
            <option value="subscription">🎟️ استفسار اشتراك / تفعيل</option>
            <option value="general">💬 رسالة عامة للمطور</option>
          </select>
          <label>عنوان الرسالة</label>
          <input id="supSubject" class="feature-field" placeholder="موضوع رسالتك باختصار">
          <label>التفاصيل</label>
          <textarea id="supMsg" class="feature-field" rows="3" placeholder="اكتب رسالتك أو تفاصيل المشكلة للمطور..."></textarea>
          <button type="button" class="primary feature-action" onclick="myaiSubmitSupportTicket()">📨 إرسال للمطور</button>
        </div>
        <div class="myai-pro-card">
          <h3>📬 رسائلي السابقة (${tickets.length})</h3>
          <div class="myai-table-list">
            ${tickets.map((t) => `<div class="myai-list-item">
              <div class="myai-pro-row"><b>${esc(t.subject)}</b><span class="myai-badge ${t.status === "replied" || t.status === "closed" ? "ok" : "warn"}">${t.status === "replied" ? "تم الرد ✓" : t.status === "closed" ? "مغلق" : "قيد المراجعة"}</span></div>
              <p class="myai-v3-muted" style="margin:4px 0">${esc(t.message)}</p>
              ${t.admin_reply ? `<div style="padding:7px;border-radius:9px;background:#191216;border-right:3px solid #22c55e;margin-top:5px"><b>رد المطور:</b> ${esc(t.admin_reply)}</div>` : ""}
            </div>`).join("") || `<p class="myai-v3-muted">لم ترسل أي رسائل بعد.</p>`}
          </div>
        </div>
      `;
    } catch (err) {
      body.innerHTML = `<div class="myai-pro-card">⚠️ ${esc(err.message)}</div>`;
    }
  }

  window.myaiSubmitSupportTicket = async function () {
    const category = document.getElementById("supCat")?.value || "general";
    const subject = (document.getElementById("supSubject")?.value || "").trim();
    const message = (document.getElementById("supMsg")?.value || "").trim();
    if (subject.length < 3 || message.length < 5) {
      say("اكتب عنوانًا وتفاصيل كافية للرسالة");
      return;
    }
    try {
      await myaiApiFetch("/api/support/tickets", { method: "POST", body: JSON.stringify({ category, subject, message }) });
      window.MYAISound?.coin?.();
      say("✅ تم إرسال رسالتك للمطور بنجاح");
      window.myaiAccountTabSwitch("support");
    } catch (err) {
      say(err.message);
    }
  };

  // =========================================================================
  // 6) Protected Owner Admin Panel (Strict Server RBAC)
  // =========================================================================
  async function renderOwnerAdminTab(body) {
    body.innerHTML = `<p class="myai-v3-muted">⏳ جاري تحميل لوحة إدارة المالك...</p>`;
    try {
      const data = await myaiApiFetch("/api/admin/overview", { method: "GET" });
      const codes = Array.isArray(data.codes) ? data.codes : [];
      const filteredCodes = adminCodeFilter === "all" ? codes : codes.filter((c) => c.status === adminCodeFilter);
      const admob = data.admob || { enabled: false, appId: "", bannerUnitId: "", rewardedUnitId: "" };
      const analytics = data.analytics || {};
      const evt = data.event || { id: "", title: "", description: "", bonusPoints: 50, active: false };
      const tickets = Array.isArray(data.supportTickets) ? data.supportTickets : [];
      const contactCfg = data.supportContact || { developerName: "", email: "", whatsapp: "", website: "", note: "" };

      body.innerHTML = `
        <div class="myai-pro-card">
          <h3>📈 تحليلات المنصة المباشرة</h3>
          <div class="myai-pro-grid2">
            <div class="myai-list-item">👥 إجمالي الجلسات: <b>${analytics.totalUsers || 0}</b> · مسجلون: <b>${analytics.registeredUsers || 0}</b> · باقات مدفوعة: <b>${analytics.paidUsers || 0}</b></div>
            <div class="myai-list-item">💎 نقاط متداولة: <b>${analytics.pointsInCirculation || 0}</b> · مكتسبة: <b>${analytics.pointsEarnedTotal || 0}</b> · منفقَة: <b>${analytics.pointsSpentTotal || 0}</b></div>
            <div class="myai-list-item">⚽ 3D Football: <b>${analytics.football3dMatchesPlayed || 0}</b> · تمارين Sport AI: <b>${analytics.sportWorkoutsCompleted || 0}</b></div>
            <div class="myai-list-item">🎮 جولات الألعاب: <b>${analytics.gameMatchesPlayed || 0}</b> · تذاكر دعم مفتوحة: <b>${analytics.openSupportTickets || 0}</b></div>
          </div>
        </div>

        <div class="myai-pro-card">
          <h3>🎊 إدارة الفعاليات والمناسبات الموسمية</h3>
          <input id="admEvtId" class="feature-field" value="${esc(evt.id)}" placeholder="معرف الفعالية (غيّره لفتح فعالية جديدة)">
          <input id="admEvtTitle" class="feature-field" value="${esc(evt.title)}" placeholder="عنوان الفعالية">
          <input id="admEvtDesc" class="feature-field" value="${esc(evt.description)}" placeholder="وصف المكافأة">
          <input id="admEvtBonus" type="number" class="feature-field" value="${Number(evt.bonusPoints || 50)}" min="0" max="1000" placeholder="نقاط المكافأة">
          <label style="display:flex;align-items:center;gap:8px;margin:8px 0">
            <input id="admEvtActive" type="checkbox" ${evt.active ? "checked" : ""}>
            <span>تفعيل هذه الفعالية للمستخدمين الآن</span>
          </label>
          <button type="button" class="primary feature-action" onclick="myaiAdminSaveEvent()">حفظ وتحديث الفعالية</button>
        </div>

        <div class="myai-pro-card">
          <h3>🎟️ إنشاء أكواد اشتراك عشوائية آمنة</h3>
          <div class="myai-pro-grid2">
            <div>
              <label>الباقة المستهدفة</label>
              <select id="admPlan" class="feature-field">
                <option value="weekly">الباقة الأسبوعية (Plus)</option>
                <option value="monthly" selected>الباقة الشهرية (Pro)</option>
                <option value="quarterly">باقة 3 أشهر (Pro+)</option>
                <option value="yearly">الباقة السنوية (Elite)</option>
                <option value="lifetime">العضوية الدائمة (VIP)</option>
              </select>
            </div>
            <div>
              <label>مدة الصلاحية</label>
              <select id="admDur" class="feature-field">
                <option value="week">أسبوع (7 أيام)</option>
                <option value="month" selected>شهر (30 يومًا)</option>
                <option value="3months">3 شهور (90 يومًا)</option>
                <option value="year">سنة (365 يومًا)</option>
                <option value="lifetime">مدى الحياة (دائم)</option>
              </select>
            </div>
            <div>
              <label>نقاط إضافية عند التفعيل</label>
              <input id="admBonus" type="number" class="feature-field" value="500" min="0" max="50000">
            </div>
            <div>
              <label>عدد الأكواد المطلوب توليدها</label>
              <input id="admCount" type="number" class="feature-field" value="1" min="1" max="25">
            </div>
          </div>
          <label>ملاحظة إدارية (اختياري)</label>
          <input id="admNote" class="feature-field" placeholder="مثال: كود لعميل رقم #12">
          <button type="button" class="primary feature-action" onclick="myaiAdminGenerateCodes()">⚡ توليد الأكواد الآن</button>
          <div id="admGenResult"></div>
        </div>

        <div class="myai-pro-card">
          <div class="myai-pro-row">
            <h3>📋 سجل الأكواد (${codes.length})</h3>
            <div style="display:flex;gap:5px;flex-wrap:wrap">
              <button type="button" class="myai-mini-btn" onclick="myaiExportCodes('csv')">CSV</button>
              <button type="button" class="myai-mini-btn" onclick="myaiExportCodes('json')">JSON</button>
            </div>
          </div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
            ${[
              ["all", "الكل"],
              ["active", "نشط"],
              ["used", "مستخدم"],
              ["revoked", "ملغي"],
              ["expired", "منتهي"],
            ]
              .map(([f, lbl]) => `<button type="button" class="myai-mini-btn ${adminCodeFilter === f ? "primary-mini" : ""}" onclick="myaiSetAdminFilter('${f}')">${lbl}</button>`)
              .join("")}
          </div>
          <div class="myai-table-list">
            ${filteredCodes
              .map(
                (c) => `<div class="myai-list-item">
                  <div class="myai-pro-row">
                    <span class="myai-code-pill">${esc(c.code)}</span>
                    <span class="myai-badge ${c.status === "active" ? "ok" : c.status === "used" ? "" : "warn"}">${esc(c.status)}</span>
                  </div>
                  <div class="myai-v3-muted">الباقة: ${esc(c.plan)} (${esc(c.duration_key)}) · مكافأة: +${c.bonus_points} نقطة ${c.used_by_email ? `· فُعّل بواسطة: ${esc(c.used_by_email)}` : ""}</div>
                  <div style="display:flex;gap:6px;margin-top:6px">
                    <button type="button" class="myai-mini-btn" onclick="navigator.clipboard?.writeText('${esc(c.code)}');say('تم نسخ الكود')">📋 نسخ</button>
                    ${c.status === "active" ? `<button type="button" class="myai-mini-btn" onclick="myaiAdminRevokeCode('${esc(c.id)}')">🚫 إلغاء الكود</button>` : ""}
                  </div>
                </div>`,
              )
              .join("") || `<p class="myai-v3-muted">لا توجد أكواد ضمن هذا التصنيف.</p>`}
          </div>
        </div>

        <div class="myai-pro-card">
          <h3>👥 الاشتراكات وطلبات الترقية</h3>
          <div class="myai-table-list">
            ${(data.subscriptions || [])
              .map(
                (s) => `<div class="myai-list-item">
                  <b>${esc(s.name)}</b> (${esc(s.email)}) — <span class="myai-badge ${s.status === "active" ? "ok" : "warn"}">${esc(s.planName)}</span> · ${s.expiresAt ? formatDateAr(s.expiresAt) : "دائم"}
                </div>`,
              )
              .join("")}
            ${(data.requests || [])
              .map(
                (r) => `<div class="myai-list-item">⏳ طلب ترقية: <b>${esc(r.user_name || "مستخدم")}</b> طلب باقة <b>${esc(r.plan)}</b> (${formatDateAr(r.created_at)})</div>`,
              )
              .join("")}
          </div>
        </div>

        <div class="myai-pro-card">
          <h3>📺 إعدادات Google AdMob (معطّلة افتراضيًا)</h3>
          <label style="display:flex;align-items:center;gap:8px;margin:8px 0">
            <input id="admAdmobEnabled" type="checkbox" ${admob.enabled ? "checked" : ""}>
            <span>تفعيل جاهزية AdMob في التطبيق (يتطلب App ID حقيقي)</span>
          </label>
          <input id="admAdmobAppId" class="feature-field" value="${esc(admob.appId)}" placeholder="AdMob App ID (ca-app-pub-...)">
          <input id="admAdmobBanner" class="feature-field" value="${esc(admob.bannerUnitId)}" placeholder="Banner Unit ID">
          <input id="admAdmobRewarded" class="feature-field" value="${esc(admob.rewardedUnitId)}" placeholder="Rewarded Unit ID">
          <button type="button" class="primary feature-action" onclick="myaiAdminSaveAdMob()">حفظ إعدادات AdMob</button>
        </div>

        <div class="myai-pro-card">
          <h3>📬 رسائل وتذاكر المستخدمين (${tickets.length})</h3>
          <div class="myai-table-list">
            ${tickets.map((t) => `<div class="myai-list-item">
              <div class="myai-pro-row"><b>${esc(t.subject)}</b><span class="myai-badge ${t.status === "replied" ? "ok" : "warn"}">${esc(t.status)}</span></div>
              <small class="myai-v3-muted">من: ${esc(t.user_name)} (${esc(t.user_email || "زائر")}) · ${esc(t.category)}</small>
              <p style="margin:5px 0">${esc(t.message)}</p>
              <div style="display:flex;gap:6px;margin-top:6px">
                <input id="admReply_${esc(t.id)}" class="feature-field" style="margin:0;flex:1" value="${esc(t.admin_reply || "")}" placeholder="اكتب رد المطور هنا...">
                <button type="button" class="primary" onclick="myaiAdminReplyTicket('${esc(t.id)}')">رد</button>
              </div>
            </div>`).join("") || `<p class="myai-v3-muted">لا توجد رسائل دعم حاليًا.</p>`}
          </div>
        </div>

        <div class="myai-pro-card">
          <h3>📞 بيانات تواصل المطور الظاهرة للمستخدمين</h3>
          <input id="admSupName" class="feature-field" value="${esc(contactCfg.developerName || "")}" placeholder="اسم المطور أو الفريق">
          <input id="admSupEmail" class="feature-field" value="${esc(contactCfg.contactEmail || contactCfg.email || "")}" placeholder="البريد الإلكتروني الرسمي للدعم">
          <input id="admSupWa" class="feature-field" value="${esc(contactCfg.whatsappUrl || contactCfg.whatsapp || "")}" placeholder="رابط أو رقم واتساب الدعم (اختياري)">
          <input id="admSupNote" class="feature-field" value="${esc(contactCfg.notes || contactCfg.note || "")}" placeholder="رسالة ترحيب في صفحة التواصل">
          <button type="button" class="primary feature-action" onclick="myaiAdminSaveSupportContact()">حفظ بيانات التواصل</button>
        </div>
      `;
      adminGeneratedCodes = codes;
    } catch (err) {
      body.innerHTML = `<div class="myai-pro-card">⚠️ ${esc(err.message)}</div>`;
    }
  }

  window.myaiAdminReplyTicket = async function (ticketId) {
    const adminReply = (document.getElementById("admReply_" + ticketId)?.value || "").trim();
    if (!adminReply) { say("اكتب نص الرد أولاً"); return; }
    try {
      await myaiApiFetch(`/api/admin/support/${encodeURIComponent(ticketId)}`, {
        method: "POST",
        body: JSON.stringify({ adminReply, status: "replied" }),
      });
      say("تم إرسال رد المطور");
      window.myaiAccountTabSwitch("admin");
    } catch (err) { say(err.message); }
  };

  window.myaiAdminSaveSupportContact = async function () {
    const payload = {
      developerName: document.getElementById("admSupName")?.value || "",
      contactEmail: document.getElementById("admSupEmail")?.value || "",
      whatsappUrl: document.getElementById("admSupWa")?.value || "",
      notes: document.getElementById("admSupNote")?.value || "",
    };
    try {
      await myaiApiFetch("/api/admin/support-contact", { method: "POST", body: JSON.stringify(payload) });
      say("تم تحديث بيانات تواصل المطور");
    } catch (err) { say(err.message); }
  };

  window.myaiSetAdminFilter = function (f) {
    adminCodeFilter = f;
    window.myaiAccountTabSwitch("admin");
  };

  window.myaiAdminGenerateCodes = async function () {
    const plan = document.getElementById("admPlan")?.value || "monthly";
    const durationKey = document.getElementById("admDur")?.value || "month";
    const bonusPoints = Number(document.getElementById("admBonus")?.value || 0);
    const count = Number(document.getElementById("admCount")?.value || 1);
    const note = document.getElementById("admNote")?.value || "";
    try {
      const res = await myaiApiFetch("/api/admin/codes/generate", {
        method: "POST",
        body: JSON.stringify({ plan, durationKey, bonusPoints, count, note }),
      });
      const out = document.getElementById("admGenResult");
      if (out && Array.isArray(res.codes)) {
        out.innerHTML = `<div class="feature-result"><strong>تم توليد الأكواد بنجاح:</strong><br>${res.codes.map((c) => `<div style="margin:6px 0"><span class="myai-code-pill">${esc(c.code)}</span> <button type="button" class="myai-mini-btn" onclick="navigator.clipboard?.writeText('${esc(c.code)}');say('تم النسخ')">📋 نسخ</button></div>`).join("")}</div>`;
      }
      say("تم توليد الأكواد وحفظها بأمان");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiAdminRevokeCode = async function (codeId) {
    try {
      await myaiApiFetch(`/api/admin/codes/${encodeURIComponent(codeId)}/revoke`, { method: "POST" });
      say("تم إلغاء الكود بنجاح");
      window.myaiAccountTabSwitch("admin");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiAdminSaveAdMob = async function () {
    const enabled = Boolean(document.getElementById("admAdmobEnabled")?.checked);
    const appId = (document.getElementById("admAdmobAppId")?.value || "").trim();
    const bannerUnitId = (document.getElementById("admAdmobBanner")?.value || "").trim();
    const rewardedUnitId = (document.getElementById("admAdmobRewarded")?.value || "").trim();
    try {
      const res = await myaiApiFetch("/api/admin/admob", {
        method: "POST",
        body: JSON.stringify({ enabled, appId, bannerUnitId, rewardedUnitId }),
      });
      state.admob = res.admob;
      renderAdMobSlot();
      say("تم حفظ إعدادات AdMob");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiAdminSaveEvent = async function () {
    const id = (document.getElementById("admEvtId")?.value || "").trim();
    const title = (document.getElementById("admEvtTitle")?.value || "").trim();
    const description = (document.getElementById("admEvtDesc")?.value || "").trim();
    const bonusPoints = Number(document.getElementById("admEvtBonus")?.value || 50);
    const active = Boolean(document.getElementById("admEvtActive")?.checked);
    try {
      const res = await myaiApiFetch("/api/admin/event", {
        method: "POST",
        body: JSON.stringify({ id, title, description, bonusPoints, active }),
      });
      state.event = res.event;
      say("تم حفظ وتحديث الفعالية الموسمية بنجاح");
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiExportCodes = function (format) {
    const rows = adminGeneratedCodes || [];
    if (!rows.length) {
      say("لا توجد أكواد للتصدير");
      return;
    }
    let content = "";
    let mime = "text/plain";
    let ext = format;
    if (format === "json") {
      content = JSON.stringify(rows, null, 2);
      mime = "application/json";
    } else {
      const header = "code,plan,duration_key,bonus_points,status,used_by_email,note\n";
      content =
        header +
        rows
          .map((c) => [c.code, c.plan, c.duration_key, c.bonus_points, c.status, c.used_by_email || "", (c.note || "").replace(/,/g, " ")].join(","))
          .join("\n");
      mime = "text/csv;charset=utf-8";
      ext = "csv";
    }
    const blob = new Blob([content], { type: mime });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `myai-codes.${ext}`;
    a.click();
  };

  // Enhance Navigation Center so Football 3D, Players DB, Sport Coach, Support & Admin are accessible
  const baseOpenCenter = window.myaiOpenCenter;
  window.myaiOpenCenter = function () {
    if (typeof baseOpenCenter === "function") baseOpenCenter();
    const grid = document.querySelector("#featureBody .ai-nav-grid");
    if (!grid) return;
    const extras = [
      ["⚽", "MY AI FOOTBALL 3D", "myaiOpenFootball3D()"],
      ["🌍", "قاعدة اللاعبين", "myaiOpenPlayersDatabase()"],
      ["🏃", "المدرب الذكي", "myaiOpenSportCoach()"],
      ["🎨", "استوديو الوسائط", "myaiOpenMediaStudio('analyze')"],
      ["🎟️", "تفعيل الاشتراك", "openActivationCodePage()"],
      ["📞", "تواصل مع المطور", "myaiOpenSupportCenter()"],
      ["☁️", "النسخ الاحتياطي", "myaiOpenAccountPro('backup')"],
    ];
    if (state.user?.role === "owner") {
      extras.push(["🛡️", "لوحة تحكم المالك", "myaiOpenAccountPro('admin')"]);
    }
    extras.forEach(([ic, lbl, fn]) => {
      const b = document.createElement("button");
      b.className = "nav-tile";
      b.innerHTML = `${ic}<b>${lbl}</b>`;
      b.setAttribute("onclick", fn);
      grid.appendChild(b);
    });
  };

  // Boot once DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      applyThemeAndTypography();
      bindHeroAndMediaButtons();
      bootSession();
    });
  } else {
    applyThemeAndTypography();
    bindHeroAndMediaButtons();
    bootSession();
  }
})();
