/* MY AI Procedural Web Audio SFX Engine (works online & offline) */
(function () {
  const MUTE_KEY = "myai_sound_muted";
  let ctx = null;
  let musicTimer = null;
  let musicActive = false;

  function ensureCtx() {
    if (localStorage.getItem(MUTE_KEY) === "1") return null;
    if (!ctx) {
      const AudioCtor = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtor) return null;
      try {
        ctx = new AudioCtor();
      } catch (_) {
        return null;
      }
    }
    if (ctx.state === "suspended") {
      ctx.resume().catch(() => {});
    }
    return ctx;
  }

  function hasProSound() {
    try {
      const owned = window.myaiSessionState?.user?.ownedItems;
      return Array.isArray(owned) && owned.includes("sound_pack_pro");
    } catch (_) {
      return false;
    }
  }

  function tone(freq, duration = 0.09, type = "triangle", gainVal = 0.14, endFreq = null, delay = 0) {
    const c = ensureCtx();
    if (!c) return;
    const t0 = c.currentTime + delay;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (endFreq && endFreq > 0) {
      osc.frequency.exponentialRampToValueAtTime(endFreq, t0 + duration);
    }
    g.gain.setValueAtTime(0.001, t0);
    g.gain.linearRampToValueAtTime(gainVal, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + duration);
    osc.connect(g);
    g.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + duration + 0.02);
  }

  function noiseBurst(duration = 0.25, gainVal = 0.08, delay = 0) {
    const c = ensureCtx();
    if (!c) return;
    const sampleCount = Math.floor(c.sampleRate * duration);
    const buf = c.createBuffer(1, sampleCount, c.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < sampleCount; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (sampleCount * 0.45));
    }
    const src = c.createBufferSource();
    src.buffer = buf;
    const filter = c.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = 1100;
    const g = c.createGain();
    g.gain.value = gainVal;
    src.connect(filter);
    filter.connect(g);
    g.connect(c.destination);
    src.start(c.currentTime + delay);
  }

  const MYAISound = {
    isMuted() {
      return localStorage.getItem(MUTE_KEY) === "1";
    },
    setMuted(muted) {
      localStorage.setItem(MUTE_KEY, muted ? "1" : "0");
      if (muted) this.stopMusic();
      return muted;
    },
    toggleMute() {
      const next = !this.isMuted();
      this.setMuted(next);
      if (!next) this.click();
      return next;
    },
    click() {
      tone(620, 0.045, "sine", 0.08, 420);
    },
    kick() {
      tone(150, 0.11, "sine", 0.22, 42);
      noiseBurst(0.06, 0.07);
    },
    bounce() {
      tone(280, 0.06, "triangle", 0.14, 190);
    },
    post() {
      tone(540, 0.26, "square", 0.11, 310);
    },
    whistle() {
      const pro = hasProSound();
      tone(2580, 0.18, "sine", pro ? 0.11 : 0.09, 2720, 0);
      tone(2720, 0.22, "sine", pro ? 0.11 : 0.08, 2500, 0.16);
    },
    goal() {
      const pro = hasProSound();
      tone(523.25, 0.14, "triangle", 0.16, null, 0);
      tone(659.25, 0.14, "triangle", 0.16, null, 0.1);
      tone(783.99, 0.16, "triangle", 0.18, null, 0.2);
      tone(1046.5, 0.36, "sawtooth", pro ? 0.15 : 0.12, null, 0.32);
      noiseBurst(pro ? 0.75 : 0.45, pro ? 0.14 : 0.09, 0.08);
    },
    correct() {
      tone(587.33, 0.09, "sine", 0.13, null, 0);
      tone(880, 0.18, "sine", 0.15, null, 0.08);
    },
    wrong() {
      tone(220, 0.14, "sawtooth", 0.1, 155, 0);
      tone(155, 0.2, "sawtooth", 0.1, 115, 0.12);
    },
    coin() {
      tone(987.77, 0.07, "sine", 0.12, null, 0);
      tone(1318.51, 0.18, "sine", 0.14, null, 0.06);
    },
    packOpen() {
      [440, 554, 659, 880, 1108].forEach((f, idx) => {
        tone(f, 0.15, "triangle", 0.13, null, idx * 0.07);
      });
      if (hasProSound()) noiseBurst(0.45, 0.1, 0.22);
    },
    fanfare() {
      [523, 659, 784, 1046].forEach((f, idx) => {
        tone(f, 0.18, "triangle", 0.14, null, idx * 0.09);
      });
    },
    toggleMusic() {
      if (musicActive) {
        this.stopMusic();
        return false;
      }
      if (this.isMuted()) return false;
      musicActive = true;
      const seq = [220, 261.63, 329.63, 293.66, 220, 329.63, 392, 329.63];
      let step = 0;
      const playStep = () => {
        if (!musicActive || this.isMuted()) return;
        const note = seq[step % seq.length];
        tone(note, 0.22, "triangle", hasProSound() ? 0.05 : 0.035);
        if (step % 2 === 0) tone(note / 2, 0.28, "sine", 0.03);
        step++;
      };
      playStep();
      musicTimer = setInterval(playStep, 420);
      return true;
    },
    stopMusic() {
      musicActive = false;
      if (musicTimer) {
        clearInterval(musicTimer);
        musicTimer = null;
      }
    },
    isMusicPlaying() {
      return musicActive;
    },
  };

  window.MYAISound = MYAISound;
})();
