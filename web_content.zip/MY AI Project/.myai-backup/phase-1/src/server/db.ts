import { DatabaseSync } from "node:sqlite";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export type PlanId = "free" | "weekly" | "monthly" | "quarterly" | "yearly" | "lifetime";
export type DurationKey = "week" | "month" | "3months" | "year" | "lifetime";
export type UserRole = "user" | "owner";

export interface PlanDefinition {
  id: PlanId;
  name: string;
  badge: string;
  durationKey: DurationKey | "free";
  durationDays: number | null;
  offlineAllowed: boolean;
  offlineLeaseDays: number;
  dailyAiLimit: number;
  pointDiscountPct: number;
  features: string[];
  description: string;
}

export const PLANS: Record<PlanId, PlanDefinition> = {
  free: {
    id: "free",
    name: "الباقة المجانية",
    badge: "Free",
    durationKey: "free",
    durationDays: 0,
    offlineAllowed: false,
    offlineLeaseDays: 0,
    dailyAiLimit: 40,
    pointDiscountPct: 0,
    features: ["chat", "study_basic", "games_online", "media_analyze"],
    description: "استخدام جميع المساعدين السبعة عبر الإنترنت مع رصيد ترحيبي ومهام يومية (بدون وضع Offline).",
  },
  weekly: {
    id: "weekly",
    name: "الباقة الأسبوعية · Plus",
    badge: "7 أيام",
    durationKey: "week",
    durationDays: 7,
    offlineAllowed: true,
    offlineLeaseDays: 7,
    dailyAiLimit: 180,
    pointDiscountPct: 30,
    features: ["chat", "study_pro", "games_online", "media_studio", "offline_mode", "cloud_sync"],
    description: "تفعيل وضع Offline للألعاب والمحادثات المحفوظة + خصم 30% على تكلفة النقاط + مزامنة سحابية.",
  },
  monthly: {
    id: "monthly",
    name: "الباقة الشهرية · Pro",
    badge: "30 يومًا",
    durationKey: "month",
    durationDays: 30,
    offlineAllowed: true,
    offlineLeaseDays: 14,
    dailyAiLimit: 500,
    pointDiscountPct: 50,
    features: ["chat", "study_pro", "games_online", "media_studio", "offline_mode", "cloud_sync", "priority"],
    description: "المساعد الدراسي المتقدم + استوديو الوسائط + وضع Offline (صلاحية 14 يومًا قابلة للتجديد) + خصم 50% للنقاط.",
  },
  quarterly: {
    id: "quarterly",
    name: "باقة 3 أشهر · Pro+",
    badge: "90 يومًا",
    durationKey: "3months",
    durationDays: 90,
    offlineAllowed: true,
    offlineLeaseDays: 21,
    dailyAiLimit: 800,
    pointDiscountPct: 60,
    features: ["chat", "study_pro", "games_online", "media_studio", "offline_mode", "cloud_sync", "priority"],
    description: "صلاحية ربع سنوية كاملة مع وضع Offline لمدة 21 يومًا وخصم 60% على استهلاك النقاط.",
  },
  yearly: {
    id: "yearly",
    name: "الباقة السنوية · Elite",
    badge: "365 يومًا",
    durationKey: "year",
    durationDays: 365,
    offlineAllowed: true,
    offlineLeaseDays: 30,
    dailyAiLimit: 1500,
    pointDiscountPct: 75,
    features: ["chat", "study_pro", "games_online", "media_studio", "offline_mode", "cloud_sync", "priority"],
    description: "وصول سنوي كامل مع وضع Offline حتى 30 يومًا وخصم 75% على النقاط وأعلى أولوية.",
  },
  lifetime: {
    id: "lifetime",
    name: "العضوية الدائمة · VIP",
    badge: "دائم",
    durationKey: "lifetime",
    durationDays: null,
    offlineAllowed: true,
    offlineLeaseDays: 30,
    dailyAiLimit: 5000,
    pointDiscountPct: 100,
    features: ["chat", "study_pro", "games_online", "media_studio", "offline_mode", "cloud_sync", "priority", "vip_badge"],
    description: "عضوية دائمة مع إعفاء كامل من خصم النقاط على المحادثات ووضع Offline دائم التجديد.",
  },
};

export const DURATION_DAYS: Record<DurationKey, number | null> = {
  week: 7,
  month: 30,
  "3months": 90,
  year: 365,
  lifetime: null,
};

export const BASE_SERVICE_COSTS = {
  chat: { cost: 2, label: "محادثة ذكاء اصطناعي" },
  study: { cost: 3, label: "المساعد الدراسي والسبورة والاختبار" },
  sport_tool: { cost: 3, label: "أدوات Sport AI المتقدمة" },
  media_analyze: { cost: 5, label: "تحليل صورة عبر Gemini" },
  media_studio: { cost: 4, label: "استوديو الفيديو / الصوت / تحسين الوصف" },
  media_generate: { cost: 15, label: "توليد صورة بالذكاء الاصطناعي" },
} as const;

export type ServiceKey = keyof typeof BASE_SERVICE_COSTS;

export type DialectPreference = "ar_eg" | "ar_msa" | "en";
export type ThemeAccentPreference = "red" | "gold" | "emerald" | "ice";

export interface UserRecord {
  id: string;
  email: string | null;
  name: string;
  country: string;
  role: UserRole;
  is_guest: number;
  points: number;
  plan: PlanId;
  subscription_expires_at: number | null;
  subscription_features: string;
  offline_lease_until: number | null;
  sync_enabled: number;
  daily_requests_date: string;
  daily_requests_count: number;
  referral_code: string | null;
  referred_by: string | null;
  streak_days: number;
  last_streak_date: string;
  last_event_claimed: string;
  daily_game_points_date: string;
  daily_game_points: number;
  dialect: DialectPreference;
  chat_font_size: number;
  theme_accent: ThemeAccentPreference;
  last_sport_claim_at: number;
  created_at: number;
  updated_at: number;
}

export interface ShopItemDefinition {
  id: string;
  name: string;
  category: "club" | "games";
  cost: number;
  badge: string;
  description: string;
}

export const SHOP_ITEMS: ShopItemDefinition[] = [
  {
    id: "kit_crimson_obsidian",
    name: "طقم MY AI القرمزي الفاخر",
    category: "club",
    cost: 120,
    badge: "تخصيص النادي",
    description: "يمنح فريقك في Ultimate Club زي المباراة الأسود والأحمر اللامع وتفاصيل قمصان ثلاثية الأبعاد.",
  },
  {
    id: "stadium_night_lights",
    name: "أضواء الملعب الليلية السينمائية",
    category: "club",
    cost: 150,
    badge: "ملعب احترافي",
    description: "يفتح إضاءة الملاعب الليلية وتأثيرات الجمهور التفاعلية في ساحة المباريات المباشرة.",
  },
  {
    id: "sound_pack_pro",
    name: "حزمة مؤثرات الملاعب والصوت",
    category: "games",
    cost: 90,
    badge: "صوتيات",
    description: "تفتح نغمات الصافرة الاحترافية وهتاف الأهداف والمؤثرات الصوتية الموسعة لجميع الألعاب.",
  },
  {
    id: "arcade_neon_trail",
    name: "مسار الكرة المضيء في الألعاب",
    category: "games",
    cost: 80,
    badge: "تأثير بصري",
    description: "تأثير ذيل ضوئي أحمر وذهبي للكرة في ألعاب ركلات الترجيح ومبارزة الساحة 2D.",
  },
  {
    id: "club_youth_academy",
    name: "حصة أكاديمية الناشئين",
    category: "club",
    cost: 180,
    badge: "تطوير النادي",
    description: "تمنحك أدوات تدريب مركزية مطوّرة لمتابعة تطور طاقات اللاعبين الشباب ولياقتهم.",
  },
];

export interface EventConfig {
  id: string;
  title: string;
  description: string;
  bonusPoints: number;
  active: boolean;
  updatedAt: number;
}

export interface AdMobConfig {
  enabled: boolean;
  appId: string;
  bannerUnitId: string;
  rewardedUnitId: string;
  updatedAt: number;
}

const DATA_DIR = path.resolve(process.cwd(), ".myai-data");
const DB_PATH = path.join(DATA_DIR, "myai.sqlite");

let dbInstance: DatabaseSync | null = null;
let cachedHmacSecret: string | null = null;

export function getDb(): DatabaseSync {
  if (dbInstance) return dbInstance;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const db = new DatabaseSync(DB_PATH);
  db.exec("PRAGMA journal_mode = WAL;");
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec(`
    CREATE TABLE IF NOT EXISTS app_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE,
      name TEXT NOT NULL DEFAULT '',
      country TEXT NOT NULL DEFAULT '',
      password_hash TEXT,
      role TEXT NOT NULL DEFAULT 'user',
      is_guest INTEGER NOT NULL DEFAULT 1,
      points INTEGER NOT NULL DEFAULT 1250,
      plan TEXT NOT NULL DEFAULT 'free',
      subscription_expires_at INTEGER,
      subscription_features TEXT NOT NULL DEFAULT '[]',
      offline_lease_until INTEGER,
      sync_enabled INTEGER NOT NULL DEFAULT 1,
      daily_requests_date TEXT NOT NULL DEFAULT '',
      daily_requests_count INTEGER NOT NULL DEFAULT 0,
      last_mission_date TEXT NOT NULL DEFAULT '',
      claimed_missions TEXT NOT NULL DEFAULT '[]',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS point_transactions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      delta INTEGER NOT NULL,
      balance_after INTEGER NOT NULL,
      service TEXT NOT NULL,
      description TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activation_codes (
      id TEXT PRIMARY KEY,
      code TEXT UNIQUE NOT NULL,
      plan TEXT NOT NULL,
      duration_key TEXT NOT NULL,
      duration_days INTEGER,
      features TEXT NOT NULL DEFAULT '[]',
      bonus_points INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      created_by TEXT NOT NULL,
      used_by TEXT,
      used_at INTEGER,
      expires_at INTEGER,
      note TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS subscription_requests (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      plan TEXT NOT NULL,
      duration_key TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      note TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS user_backups (
      user_id TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS user_inventory (
      user_id TEXT NOT NULL,
      item_id TEXT NOT NULL,
      purchased_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, item_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS game_stats (
      user_id TEXT NOT NULL,
      game_id TEXT NOT NULL,
      plays INTEGER NOT NULL DEFAULT 0,
      wins INTEGER NOT NULL DEFAULT 0,
      high_score INTEGER NOT NULL DEFAULT 0,
      xp INTEGER NOT NULL DEFAULT 0,
      best_difficulty TEXT NOT NULL DEFAULT 'متوسط',
      updated_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, game_id),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS pvp_matches (
      id TEXT PRIMARY KEY,
      room_code TEXT NOT NULL,
      home_user_id TEXT NOT NULL,
      away_user_id TEXT NOT NULL,
      home_club TEXT NOT NULL,
      away_club TEXT NOT NULL,
      home_goals INTEGER NOT NULL,
      away_goals INTEGER NOT NULL,
      winner_user_id TEXT,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sport_profiles (
      user_id TEXT PRIMARY KEY,
      position TEXT NOT NULL DEFAULT 'وسط',
      age INTEGER NOT NULL DEFAULT 18,
      level TEXT NOT NULL DEFAULT 'متوسط',
      weekly_days INTEGER NOT NULL DEFAULT 4,
      goal TEXT NOT NULL DEFAULT 'رفع اللياقة والتحكم بالكرة',
      plan_json TEXT NOT NULL DEFAULT '{}',
      skill_stats_json TEXT NOT NULL DEFAULT '{}',
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sport_workouts (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      drill_type TEXT NOT NULL,
      duration_min INTEGER NOT NULL DEFAULT 10,
      target_skill TEXT NOT NULL DEFAULT 'dribbling',
      score INTEGER NOT NULL DEFAULT 100,
      completed_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sport_goals (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      target_value INTEGER NOT NULL DEFAULT 10,
      current_value INTEGER NOT NULL DEFAULT 0,
      unit TEXT NOT NULL DEFAULT 'تمرين',
      completed INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS support_tickets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'suggestion',
      subject TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      admin_reply TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS football_match_logs (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      mode TEXT NOT NULL DEFAULT '3d_match',
      difficulty TEXT NOT NULL DEFAULT 'متوسط',
      home_team TEXT NOT NULL,
      away_team TEXT NOT NULL,
      home_goals INTEGER NOT NULL,
      away_goals INTEGER NOT NULL,
      stats_json TEXT NOT NULL DEFAULT '{}',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS football_career_state (
      user_id TEXT PRIMARY KEY,
      state_json TEXT NOT NULL DEFAULT '{}',
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Safe idempotent column migrations for existing databases
  const cols = db.prepare("PRAGMA table_info(users)").all() as Array<{ name: string }>;
  const existingCols = new Set(cols.map((c) => c.name));
  const migrations: Array<[string, string]> = [
    ["referral_code", "ALTER TABLE users ADD COLUMN referral_code TEXT"],
    ["referred_by", "ALTER TABLE users ADD COLUMN referred_by TEXT"],
    ["streak_days", "ALTER TABLE users ADD COLUMN streak_days INTEGER NOT NULL DEFAULT 0"],
    ["last_streak_date", "ALTER TABLE users ADD COLUMN last_streak_date TEXT NOT NULL DEFAULT ''"],
    ["last_event_claimed", "ALTER TABLE users ADD COLUMN last_event_claimed TEXT NOT NULL DEFAULT ''"],
    ["daily_game_points_date", "ALTER TABLE users ADD COLUMN daily_game_points_date TEXT NOT NULL DEFAULT ''"],
    ["daily_game_points", "ALTER TABLE users ADD COLUMN daily_game_points INTEGER NOT NULL DEFAULT 0"],
    ["dialect", "ALTER TABLE users ADD COLUMN dialect TEXT NOT NULL DEFAULT 'ar_eg'"],
    ["chat_font_size", "ALTER TABLE users ADD COLUMN chat_font_size INTEGER NOT NULL DEFAULT 15"],
    ["theme_accent", "ALTER TABLE users ADD COLUMN theme_accent TEXT NOT NULL DEFAULT 'red'"],
    ["last_sport_claim_at", "ALTER TABLE users ADD COLUMN last_sport_claim_at INTEGER NOT NULL DEFAULT 0"],
  ];
  for (const [col, sql] of migrations) {
    if (!existingCols.has(col)) {
      db.exec(sql);
    }
  }
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);");

  // Backfill missing referral codes cleanly
  const missingRefRows = db
    .prepare("SELECT id FROM users WHERE referral_code IS NULL OR referral_code = ''")
    .all() as Array<{ id: string }>;
  for (const row of missingRefRows) {
    db.prepare("UPDATE users SET referral_code = ? WHERE id = ?").run(generateReferralCodeString(), row.id);
  }

  dbInstance = db;
  return db;
}

function generateReferralCodeString(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.randomBytes(6);
  let out = "REF-";
  for (let i = 0; i < 6; i++) {
    out += alphabet[bytes[i] % alphabet.length];
  }
  return out;
}

export function getTodayKey(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}

function getHmacSecret(): string {
  const envSecret = String(process.env.MYAI_SESSION_SECRET || "").trim();
  if (envSecret.length >= 16) return envSecret;
  if (cachedHmacSecret) return cachedHmacSecret;
  const db = getDb();
  const row = db.prepare("SELECT value FROM app_config WHERE key = ?").get("hmac_secret") as
    | { value: string }
    | undefined;
  if (row?.value) {
    cachedHmacSecret = row.value;
    return cachedHmacSecret;
  }
  const generated = crypto.randomBytes(32).toString("hex");
  db.prepare("INSERT OR REPLACE INTO app_config (key, value, updated_at) VALUES (?, ?, ?)").run(
    "hmac_secret",
    generated,
    Date.now(),
  );
  cachedHmacSecret = generated;
  return generated;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string | null): boolean {
  if (!stored || !stored.includes(":")) return false;
  const [salt, hex] = stored.split(":");
  if (!salt || !hex) return false;
  const candidate = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(hex, "hex");
  if (candidate.length !== expected.length) return false;
  return crypto.timingSafeEqual(candidate, expected);
}

export function signPayload(data: Record<string, unknown>): string {
  const encoded = Buffer.from(JSON.stringify(data), "utf8").toString("base64url");
  const sig = crypto.createHmac("sha256", getHmacSecret()).update(encoded).digest("base64url");
  return `${encoded}.${sig}`;
}

export function verifySignedPayload<T extends Record<string, unknown>>(token: string | null | undefined): T | null {
  if (!token || typeof token !== "string" || !token.includes(".")) return null;
  const [encoded, sig] = token.split(".");
  if (!encoded || !sig) return null;
  const expectedSig = crypto.createHmac("sha256", getHmacSecret()).update(encoded).digest("base64url");
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    return JSON.parse(Buffer.from(encoded, "base64url").toString("utf8")) as T;
  } catch {
    return null;
  }
}

export function signSessionToken(userId: string): string {
  return signPayload({
    uid: userId,
    iat: Date.now(),
    exp: Date.now() + 1000 * 60 * 60 * 24 * 60,
  });
}

export function verifySessionToken(token: string | null | undefined): { uid: string } | null {
  const parsed = verifySignedPayload<{ uid?: string; exp?: number }>(token);
  if (!parsed || typeof parsed.uid !== "string" || !parsed.exp || parsed.exp < Date.now()) {
    return null;
  }
  return { uid: parsed.uid };
}

export function getUserById(id: string): UserRecord | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM users WHERE id = ?").get(id) as UserRecord | undefined;
  return row ?? null;
}

export function createGuestUser(): UserRecord {
  const db = getDb();
  const now = Date.now();
  const id = `usr_${crypto.randomUUID()}`;
  const today = getTodayKey();
  const refCode = generateReferralCodeString();
  db.prepare(
    `INSERT INTO users (id, email, name, country, role, is_guest, points, plan, subscription_features, daily_requests_date, daily_requests_count, referral_code, streak_days, last_streak_date, created_at, updated_at)
     VALUES (?, NULL, ?, '', 'user', 1, 1250, 'free', ?, ?, 0, ?, 1, ?, ?, ?)`,
  ).run(id, "مستخدم MY AI", JSON.stringify(PLANS.free.features), today, refCode, today, now, now);

  db.prepare(
    `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
     VALUES (?, ?, 1250, 1250, 'welcome_bonus', 'رصيد ترحيبي لحساب MY AI', ?)`,
  ).run(`tx_${crypto.randomUUID()}`, id, now);

  return getUserById(id)!;
}

export function hasOwnerAccount(): boolean {
  const db = getDb();
  const row = db.prepare("SELECT id FROM users WHERE role = 'owner' LIMIT 1").get() as { id: string } | undefined;
  return Boolean(row);
}

export function getEffectiveSubscription(user: UserRecord): {
  plan: PlanId;
  planInfo: PlanDefinition;
  isPaid: boolean;
  isExpired: boolean;
  expiresAt: number | null;
  features: string[];
  offlineAllowed: boolean;
  offlineLeaseUntil: number | null;
} {
  const rawPlan = (PLANS[user.plan] ? user.plan : "free") as PlanId;
  const now = Date.now();
  const expired =
    rawPlan !== "free" &&
    rawPlan !== "lifetime" &&
    user.subscription_expires_at !== null &&
    user.subscription_expires_at <= now;

  const activePlanId: PlanId = expired ? "free" : rawPlan;
  const planInfo = PLANS[activePlanId];
  let customFeatures: string[] = [];
  try {
    const parsed = JSON.parse(user.subscription_features || "[]");
    if (Array.isArray(parsed)) customFeatures = parsed.map(String);
  } catch {
    customFeatures = [];
  }
  const features = activePlanId === "free" ? PLANS.free.features : Array.from(new Set([...planInfo.features, ...customFeatures]));
  const offlineAllowed = activePlanId !== "free" && (planInfo.offlineAllowed || features.includes("offline_mode"));

  return {
    plan: activePlanId,
    planInfo,
    isPaid: activePlanId !== "free",
    isExpired: expired,
    expiresAt: rawPlan === "lifetime" ? null : user.subscription_expires_at,
    features,
    offlineAllowed,
    offlineLeaseUntil: offlineAllowed ? user.offline_lease_until : null,
  };
}

export function getOwnedItemIds(userId: string): string[] {
  const db = getDb();
  const rows = db.prepare("SELECT item_id FROM user_inventory WHERE user_id = ?").all(userId) as Array<{ item_id: string }>;
  return rows.map((r) => r.item_id);
}

export function getUserGameStats(userId: string) {
  const db = getDb();
  return db
    .prepare("SELECT game_id, plays, wins, high_score, xp, best_difficulty, updated_at FROM game_stats WHERE user_id = ? ORDER BY updated_at DESC")
    .all(userId);
}

export function sanitizeUserPublic(user: UserRecord) {
  const sub = getEffectiveSubscription(user);
  const today = getTodayKey();
  const dailyUsed = user.daily_requests_date === today ? user.daily_requests_count : 0;
  const dailyGamePts = user.daily_game_points_date === today ? user.daily_game_points : 0;
  const dialect: DialectPreference =
    user.dialect === "ar_msa" || user.dialect === "en" ? user.dialect : "ar_eg";
  const themeAccent: ThemeAccentPreference =
    user.theme_accent === "gold" || user.theme_accent === "emerald" || user.theme_accent === "ice"
      ? user.theme_accent
      : "red";
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    country: user.country,
    role: user.role,
    isGuest: Boolean(user.is_guest),
    points: user.points,
    syncEnabled: Boolean(user.sync_enabled),
    dailyUsed,
    dailyLimit: sub.planInfo.dailyAiLimit,
    dailyGamePoints: dailyGamePts,
    dailyGamePointsCap: 150,
    referralCode: user.referral_code || "",
    referredBy: user.referred_by || null,
    streakDays: Number(user.streak_days || 0),
    lastStreakDate: user.last_streak_date || "",
    lastEventClaimed: user.last_event_claimed || "",
    dialect,
    chatFontSize: Math.max(13, Math.min(22, Number(user.chat_font_size || 15))),
    themeAccent,
    ownedItems: getOwnedItemIds(user.id),
    subscription: sub,
  };
}

export function registerAccount(params: {
  guestUserId?: string;
  email: string;
  name: string;
  country?: string;
  password: string;
}): { user: UserRecord } | { error: string; status: number } {
  const db = getDb();
  const email = params.email.trim().toLowerCase();
  const name = params.name.trim() || "مستخدم MY AI";
  const country = (params.country || "").trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "صيغة البريد الإلكتروني غير صحيحة.", status: 400 };
  }
  if (params.password.length < 6) {
    return { error: "كلمة المرور يجب أن تكون 6 أحرف على الأقل.", status: 400 };
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email) as { id: string } | undefined;
  if (existing) {
    return { error: "هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول مباشرة.", status: 409 };
  }

  const now = Date.now();
  const passwordHash = hashPassword(params.password);

  if (params.guestUserId) {
    const guest = getUserById(params.guestUserId);
    if (guest && guest.is_guest === 1 && !guest.email) {
      db.prepare(
        `UPDATE users SET email = ?, name = ?, country = ?, password_hash = ?, is_guest = 0, updated_at = ? WHERE id = ?`,
      ).run(email, name, country, passwordHash, now, guest.id);
      return { user: getUserById(guest.id)! };
    }
  }

  const id = `usr_${crypto.randomUUID()}`;
  const today = getTodayKey();
  const refCode = generateReferralCodeString();
  db.prepare(
    `INSERT INTO users (id, email, name, country, password_hash, role, is_guest, points, plan, subscription_features, daily_requests_date, daily_requests_count, referral_code, streak_days, last_streak_date, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'user', 0, 1250, 'free', ?, ?, 0, ?, 1, ?, ?, ?)`,
  ).run(id, email, name, country, passwordHash, JSON.stringify(PLANS.free.features), today, refCode, today, now, now);

  db.prepare(
    `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
     VALUES (?, ?, 1250, 1250, 'welcome_bonus', 'رصيد ترحيبي لحساب جديد', ?)`,
  ).run(`tx_${crypto.randomUUID()}`, id, now);

  return { user: getUserById(id)! };
}

export function loginAccount(emailRaw: string, password: string): { user: UserRecord } | { error: string; status: number } {
  const db = getDb();
  const email = emailRaw.trim().toLowerCase();
  const row = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as
    | (UserRecord & { password_hash: string | null })
    | undefined;
  if (!row || !verifyPassword(password, row.password_hash)) {
    return { error: "البريد الإلكتروني أو كلمة المرور غير صحيحة.", status: 401 };
  }
  return { user: row };
}

export function claimOwnerAccount(params: {
  email: string;
  name: string;
  password: string;
  ownerSecret?: string;
}): { user: UserRecord } | { error: string; status: number } {
  const db = getDb();
  const email = params.email.trim().toLowerCase();
  const name = params.name.trim() || "مالك التطبيق";
  const requiredSecret = String(process.env.MYAI_OWNER_SECRET || "").trim();
  const requiredEmail = String(process.env.MYAI_OWNER_EMAIL || "").trim().toLowerCase();

  if (requiredSecret) {
    const provided = String(params.ownerSecret || "").trim();
    const a = Buffer.from(provided);
    const b = Buffer.from(requiredSecret);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return { error: "رمز أمان المالك (MYAI_OWNER_SECRET) غير صحيح.", status: 403 };
    }
  }

  if (requiredEmail && email !== requiredEmail) {
    return { error: "البريد الإلكتروني لا يطابق بريد المالك المصرح به في إعدادات الخادم.", status: 403 };
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { error: "أدخل بريدًا إلكترونيًا صحيحًا للمالك.", status: 400 };
  }
  if (params.password.length < 8) {
    return { error: "كلمة مرور المالك يجب أن تكون 8 أحرف على الأقل.", status: 400 };
  }

  if (hasOwnerAccount()) {
    return { error: "يوجد حساب مالك مُعد بالفعل. سجّل الدخول بحساب المالك.", status: 403 };
  }

  const now = Date.now();
  const passwordHash = hashPassword(params.password);
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email) as { id: string } | undefined;
  if (existing) {
    db.prepare(
      `UPDATE users SET role = 'owner', password_hash = ?, name = ?, plan = 'lifetime', subscription_expires_at = NULL, subscription_features = ?, updated_at = ? WHERE id = ?`,
    ).run(passwordHash, name, JSON.stringify(PLANS.lifetime.features), now, existing.id);
    return { user: getUserById(existing.id)! };
  }

  const id = `own_${crypto.randomUUID()}`;
  const today = getTodayKey();
  const refCode = generateReferralCodeString();
  db.prepare(
    `INSERT INTO users (id, email, name, country, password_hash, role, is_guest, points, plan, subscription_expires_at, subscription_features, daily_requests_date, daily_requests_count, referral_code, streak_days, last_streak_date, created_at, updated_at)
     VALUES (?, ?, ?, '', ?, 'owner', 0, 10000, 'lifetime', NULL, ?, ?, 0, ?, 1, ?, ?, ?)`,
  ).run(id, email, name, passwordHash, JSON.stringify(PLANS.lifetime.features), today, refCode, today, now, now);

  db.prepare(
    `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
     VALUES (?, ?, 10000, 10000, 'owner_init', 'تهيئة حساب مالك MY AI', ?)`,
  ).run(`tx_${crypto.randomUUID()}`, id, now);

  return { user: getUserById(id)! };
}

export function getServicePointCost(user: UserRecord, service: ServiceKey): number {
  const base = BASE_SERVICE_COSTS[service]?.cost ?? 2;
  const sub = getEffectiveSubscription(user);
  if (sub.planInfo.pointDiscountPct >= 100) return 0;
  return Math.max(0, Math.round((base * (100 - sub.planInfo.pointDiscountPct)) / 100));
}

export function checkQuotaAndPoints(
  user: UserRecord,
  service: ServiceKey,
): { ok: true; cost: number } | { ok: false; status: number; code: string; error: string } {
  const sub = getEffectiveSubscription(user);
  const today = getTodayKey();
  const dailyUsed = user.daily_requests_date === today ? user.daily_requests_count : 0;
  if (dailyUsed >= sub.planInfo.dailyAiLimit) {
    return {
      ok: false,
      status: 429,
      code: "DAILY_LIMIT_REACHED",
      error: `وصلت إلى الحد اليومي لباقتك (${sub.planInfo.dailyAiLimit} طلب). يمكنك الترقية إلى باقة أعلى أو المحاولة غدًا.`,
    };
  }
  const cost = getServicePointCost(user, service);
  if (user.points < cost) {
    return {
      ok: false,
      status: 402,
      code: "INSUFFICIENT_POINTS",
      error: `رصيدك الحالي (${user.points} نقطة) لا يكفي لهذه الخدمة (${cost} نقاط). أكمل المهام اليومية أو فعّل باقة عبر كود اشتراك.`,
    };
  }
  return { ok: true, cost };
}

export function commitServiceUsage(userId: string, service: ServiceKey, cost: number, customLabel?: string): {
  points: number;
  dailyUsed: number;
} {
  const db = getDb();
  const now = Date.now();
  const today = getTodayKey();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) throw new Error("USER_NOT_FOUND");
    const nextDaily = user.daily_requests_date === today ? user.daily_requests_count + 1 : 1;
    const nextPoints = Math.max(0, user.points - Math.max(0, cost));
    db.prepare(
      `UPDATE users SET points = ?, daily_requests_date = ?, daily_requests_count = ?, updated_at = ? WHERE id = ?`,
    ).run(nextPoints, today, nextDaily, now, userId);

    if (cost > 0) {
      db.prepare(
        `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ).run(
        `tx_${crypto.randomUUID()}`,
        userId,
        -cost,
        nextPoints,
        service,
        customLabel || BASE_SERVICE_COSTS[service]?.label || service,
        now,
      );
    }
    db.exec("COMMIT;");
    return { points: nextPoints, dailyUsed: nextDaily };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function getUserTransactions(userId: string, limit = 40) {
  const db = getDb();
  return db
    .prepare(
      `SELECT id, delta, balance_after, service, description, created_at
       FROM point_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?`,
    )
    .all(userId, limit);
}

const DAILY_MISSIONS: Record<string, { title: string; points: number }> = {
  login: { title: "تسجيل الدخول اليومي", points: 15 },
  study: { title: "فتح أدوات Study AI", points: 10 },
  sport: { title: "تحدي الأسئلة الكروية", points: 10 },
  companion: { title: "محادثة مع أحد الرفقاء", points: 10 },
  game_play: { title: "إكمال جولة في مركز الألعاب", points: 20 },
  club_match: { title: "خوض مباراة في Ultimate Club", points: 25 },
};

export function getUserMissionsStatus(userId: string) {
  const db = getDb();
  const row = db.prepare("SELECT last_mission_date, claimed_missions FROM users WHERE id = ?").get(userId) as
    | { last_mission_date: string; claimed_missions: string }
    | undefined;
  const today = getTodayKey();
  let claimed: string[] = [];
  if (row && row.last_mission_date === today) {
    try {
      const parsed = JSON.parse(row.claimed_missions || "[]");
      if (Array.isArray(parsed)) claimed = parsed.map(String);
    } catch {
      claimed = [];
    }
  }
  return Object.entries(DAILY_MISSIONS).map(([id, info]) => ({
    id,
    title: info.title,
    points: info.points,
    claimed: claimed.includes(id),
  }));
}

export function claimDailyMission(userId: string, missionId: string): {
  ok: boolean;
  error?: string;
  points?: number;
  added?: number;
} {
  const mission = DAILY_MISSIONS[missionId];
  if (!mission) return { ok: false, error: "مهمة غير معروفة." };
  const db = getDb();
  const today = getTodayKey();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const row = db
      .prepare("SELECT points, last_mission_date, claimed_missions FROM users WHERE id = ?")
      .get(userId) as { points: number; last_mission_date: string; claimed_missions: string } | undefined;
    if (!row) {
      db.exec("ROLLBACK;");
      return { ok: false, error: "المستخدم غير موجود." };
    }
    let claimed: string[] = [];
    if (row.last_mission_date === today) {
      try {
        const parsed = JSON.parse(row.claimed_missions || "[]");
        if (Array.isArray(parsed)) claimed = parsed.map(String);
      } catch {
        claimed = [];
      }
    }
    if (claimed.includes(missionId)) {
      db.exec("ROLLBACK;");
      return { ok: false, error: "تم استلام مكافأة هذه المهمة اليوم بالفعل." };
    }
    claimed.push(missionId);
    const nextPoints = row.points + mission.points;
    db.prepare(
      `UPDATE users SET points = ?, last_mission_date = ?, claimed_missions = ?, updated_at = ? WHERE id = ?`,
    ).run(nextPoints, today, JSON.stringify(claimed), now, userId);

    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'daily_mission', ?, ?)`,
    ).run(`tx_${crypto.randomUUID()}`, userId, mission.points, nextPoints, `مهمة يومية: ${mission.title}`, now);

    db.exec("COMMIT;");
    return { ok: true, points: nextPoints, added: mission.points };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function issueOfflineLease(userId: string): {
  allowed: boolean;
  error?: string;
  leaseUntil?: number | null;
  offlineToken?: string;
} {
  const user = getUserById(userId);
  if (!user) return { allowed: false, error: "الحساب غير موجود." };
  const sub = getEffectiveSubscription(user);
  if (!sub.offlineAllowed) {
    return {
      allowed: false,
      error: "وضع Offline حصري للمشتركين في الباقات المدفوعة. يمكنك تفعيل باقة عبر صفحة «تفعيل الاشتراك».",
    };
  }
  const now = Date.now();
  const maxLease = now + sub.planInfo.offlineLeaseDays * 86400000;
  const leaseUntil = sub.expiresAt ? Math.min(sub.expiresAt, maxLease) : maxLease;
  const db = getDb();
  db.prepare("UPDATE users SET offline_lease_until = ?, updated_at = ? WHERE id = ?").run(leaseUntil, now, userId);

  const offlineToken = signPayload({
    typ: "myai_offline_lease",
    uid: userId,
    plan: sub.plan,
    features: sub.features,
    subExpiresAt: sub.expiresAt,
    leaseUntil,
    issuedAt: now,
  });

  return { allowed: true, leaseUntil, offlineToken };
}

function generateSecureCodeString(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.randomBytes(12);
  let out = "MYAI";
  for (let g = 0; g < 3; g++) {
    out += "-";
    for (let i = 0; i < 4; i++) {
      out += alphabet[bytes[g * 4 + i] % alphabet.length];
    }
  }
  return out;
}

export function generateActivationCodes(params: {
  createdBy: string;
  plan: PlanId;
  durationKey: DurationKey;
  features?: string[];
  bonusPoints?: number;
  count?: number;
  codeExpiresInDays?: number | null;
  note?: string;
}) {
  const db = getDb();
  const planId: PlanId = PLANS[params.plan] && params.plan !== "free" ? params.plan : "monthly";
  const durationKey: DurationKey = params.durationKey in DURATION_DAYS ? params.durationKey : "month";
  const durationDays = DURATION_DAYS[durationKey];
  const count = Math.max(1, Math.min(25, Math.floor(Number(params.count) || 1)));
  const bonusPoints = Math.max(0, Math.min(50000, Math.floor(Number(params.bonusPoints) || 0)));
  const planFeatures = PLANS[planId].features;
  const features = Array.isArray(params.features) && params.features.length
    ? Array.from(new Set([...planFeatures, ...params.features.map(String)]))
    : planFeatures;
  const now = Date.now();
  const expiresAt =
    params.codeExpiresInDays && params.codeExpiresInDays > 0
      ? now + params.codeExpiresInDays * 86400000
      : null;

  const created: Array<Record<string, unknown>> = [];
  const stmt = db.prepare(
    `INSERT INTO activation_codes (id, code, plan, duration_key, duration_days, features, bonus_points, status, created_by, expires_at, note, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?)`,
  );

  for (let i = 0; i < count; i++) {
    const id = `cod_${crypto.randomUUID()}`;
    const code = generateSecureCodeString();
    stmt.run(
      id,
      code,
      planId,
      durationKey,
      durationDays,
      JSON.stringify(features),
      bonusPoints,
      params.createdBy,
      expiresAt,
      String(params.note || "").slice(0, 200),
      now,
    );
    created.push({
      id,
      code,
      plan: planId,
      durationKey,
      durationDays,
      features,
      bonusPoints,
      status: "active",
      expiresAt,
      createdAt: now,
    });
  }
  return created;
}

export function redeemActivationCode(userId: string, rawCode: string): {
  ok: boolean;
  status: number;
  error?: string;
  user?: ReturnType<typeof sanitizeUserPublic>;
  offlineToken?: string;
  activatedPlan?: PlanDefinition;
  expiresAt?: number | null;
  bonusPoints?: number;
} {
  const code = String(rawCode || "").trim().toUpperCase().replace(/\s+/g, "");
  if (!code || code.length < 8) {
    return { ok: false, status: 400, error: "أدخل كود تفعيل صحيحًا." };
  }

  const db = getDb();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const row = db.prepare("SELECT * FROM activation_codes WHERE code = ?").get(code) as
      | {
          id: string;
          code: string;
          plan: PlanId;
          duration_key: DurationKey;
          duration_days: number | null;
          features: string;
          bonus_points: number;
          status: string;
          used_by: string | null;
          expires_at: number | null;
        }
      | undefined;

    if (!row) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "كود التفعيل غير موجود. تأكد من كتابة الكود بشكل صحيح." };
    }
    if (row.status === "revoked") {
      db.exec("ROLLBACK;");
      return { ok: false, status: 400, error: "تم إلغاء هذا الكود من قبل مالك التطبيق ولا يمكن استخدامه." };
    }
    if (row.status === "used" || row.used_by) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 409, error: "هذا الكود مستخدم من قبل. كل كود يعمل لمرة واحدة فقط." };
    }
    if (row.expires_at && row.expires_at <= now) {
      db.prepare("UPDATE activation_codes SET status = 'expired' WHERE id = ?").run(row.id);
      db.exec("COMMIT;");
      return { ok: false, status: 400, error: "انتهت صلاحية كود التفعيل قبل استخدامه." };
    }

    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "الحساب غير موجود." };
    }

    const updateCodeRes = db
      .prepare(
        `UPDATE activation_codes SET status = 'used', used_by = ?, used_at = ?
         WHERE id = ? AND status = 'active' AND used_by IS NULL`,
      )
      .run(userId, now, row.id);
    if (updateCodeRes.changes !== 1) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 409, error: "تعذر تفعيل الكود لأنه استُخدم للتو." };
    }

    const targetPlan: PlanId = PLANS[row.plan] ? row.plan : "monthly";
    let newExpiresAt: number | null = null;
    if (row.duration_key === "lifetime" || row.duration_days === null) {
      newExpiresAt = null;
    } else {
      const currentActiveBase =
        user.plan !== "free" && user.subscription_expires_at && user.subscription_expires_at > now
          ? user.subscription_expires_at
          : now;
      newExpiresAt = currentActiveBase + row.duration_days * 86400000;
    }

    let parsedFeatures: string[] = PLANS[targetPlan].features;
    try {
      const f = JSON.parse(row.features || "[]");
      if (Array.isArray(f) && f.length) parsedFeatures = Array.from(new Set([...parsedFeatures, ...f.map(String)]));
    } catch {}

    const bonus = Math.max(0, Number(row.bonus_points) || 0);
    const nextPoints = user.points + bonus;

    db.prepare(
      `UPDATE users SET plan = ?, subscription_expires_at = ?, subscription_features = ?, points = ?, updated_at = ?
       WHERE id = ?`,
    ).run(targetPlan, newExpiresAt, JSON.stringify(parsedFeatures), nextPoints, now, userId);

    if (bonus > 0) {
      db.prepare(
        `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
         VALUES (?, ?, ?, ?, 'code_bonus', ?, ?)`,
      ).run(`tx_${crypto.randomUUID()}`, userId, bonus, nextPoints, `مكافأة تفعيل كود ${row.code}`, now);
    }

    db.exec("COMMIT;");
    const lease = issueOfflineLease(userId);
    const updatedUser = getUserById(userId)!;
    return {
      ok: true,
      status: 200,
      user: sanitizeUserPublic(updatedUser),
      offlineToken: lease.offlineToken,
      activatedPlan: PLANS[targetPlan],
      expiresAt: newExpiresAt,
      bonusPoints: bonus,
    };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function listAllCodesForAdmin() {
  const db = getDb();
  const now = Date.now();
  db.prepare("UPDATE activation_codes SET status = 'expired' WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at <= ?").run(
    now,
  );
  return db
    .prepare(
      `SELECT c.*, u.email AS used_by_email, u.name AS used_by_name
       FROM activation_codes c
       LEFT JOIN users u ON u.id = c.used_by
       ORDER BY c.created_at DESC LIMIT 200`,
    )
    .all();
}

export function revokeActivationCode(codeId: string): { ok: boolean; error?: string } {
  const db = getDb();
  const row = db.prepare("SELECT status FROM activation_codes WHERE id = ?").get(codeId) as { status: string } | undefined;
  if (!row) return { ok: false, error: "الكود غير موجود." };
  if (row.status === "used") return { ok: false, error: "لا يمكن إلغاء كود مستخدم بالفعل." };
  db.prepare("UPDATE activation_codes SET status = 'revoked' WHERE id = ? AND status = 'active'").run(codeId);
  return { ok: true };
}

export function listSubscriptionsForAdmin() {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT id, email, name, role, is_guest, points, plan, subscription_expires_at, offline_lease_until, created_at, updated_at
       FROM users WHERE plan != 'free' OR role = 'owner' ORDER BY updated_at DESC LIMIT 200`,
    )
    .all() as unknown as UserRecord[];
  const now = Date.now();
  return rows.map((u) => {
    const expired =
      u.plan !== "free" && u.plan !== "lifetime" && u.subscription_expires_at !== null && u.subscription_expires_at <= now;
    return {
      id: u.id,
      email: u.email || "جلسة جهاز",
      name: u.name,
      role: u.role,
      points: u.points,
      plan: u.plan,
      planName: PLANS[u.plan]?.name || u.plan,
      status: expired ? "expired" : "active",
      expiresAt: u.subscription_expires_at,
      offlineLeaseUntil: u.offline_lease_until,
      updatedAt: u.updated_at,
    };
  });
}

export function createSubscriptionRequest(userId: string, plan: PlanId, note = "") {
  const db = getDb();
  const now = Date.now();
  const planInfo = PLANS[plan] || PLANS.monthly;
  const id = `req_${crypto.randomUUID()}`;
  db.prepare(
    `INSERT INTO subscription_requests (id, user_id, plan, duration_key, status, note, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'pending', ?, ?, ?)`,
  ).run(id, userId, planInfo.id, planInfo.durationKey, String(note || "").slice(0, 300), now, now);
  return { id, plan: planInfo.id, status: "pending", createdAt: now };
}

export function listSubscriptionRequestsForAdmin() {
  const db = getDb();
  return db
    .prepare(
      `SELECT r.*, u.name AS user_name, u.email AS user_email
       FROM subscription_requests r
       LEFT JOIN users u ON u.id = r.user_id
       ORDER BY r.created_at DESC LIMIT 100`,
    )
    .all();
}

export function saveUserBackup(userId: string, payload: unknown): number {
  const db = getDb();
  const now = Date.now();
  const json = JSON.stringify(payload ?? {});
  if (json.length > 4_000_000) {
    throw new Error("حجم النسخة الاحتياطية كبير جدًا.");
  }
  db.prepare(
    `INSERT INTO user_backups (user_id, payload, updated_at)
     VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at`,
  ).run(userId, json, now);
  return now;
}

export function getUserBackup(userId: string): { payload: unknown; updatedAt: number } | null {
  const db = getDb();
  const row = db.prepare("SELECT payload, updated_at FROM user_backups WHERE user_id = ?").get(userId) as
    | { payload: string; updated_at: number }
    | undefined;
  if (!row) return null;
  try {
    return { payload: JSON.parse(row.payload), updatedAt: row.updated_at };
  } catch {
    return null;
  }
}

export function getAdMobConfig(): AdMobConfig {
  const db = getDb();
  const row = db.prepare("SELECT value, updated_at FROM app_config WHERE key = 'admob_config'").get() as
    | { value: string; updated_at: number }
    | undefined;
  if (!row) {
    return { enabled: false, appId: "", bannerUnitId: "", rewardedUnitId: "", updatedAt: 0 };
  }
  try {
    const parsed = JSON.parse(row.value) as Partial<AdMobConfig>;
    return {
      enabled: Boolean(parsed.enabled),
      appId: String(parsed.appId || ""),
      bannerUnitId: String(parsed.bannerUnitId || ""),
      rewardedUnitId: String(parsed.rewardedUnitId || ""),
      updatedAt: row.updated_at,
    };
  } catch {
    return { enabled: false, appId: "", bannerUnitId: "", rewardedUnitId: "", updatedAt: 0 };
  }
}

export function saveAdMobConfig(cfg: Partial<AdMobConfig>): AdMobConfig {
  const db = getDb();
  const now = Date.now();
  const clean: AdMobConfig = {
    enabled: Boolean(cfg.enabled && cfg.appId),
    appId: String(cfg.appId || "").trim().slice(0, 120),
    bannerUnitId: String(cfg.bannerUnitId || "").trim().slice(0, 120),
    rewardedUnitId: String(cfg.rewardedUnitId || "").trim().slice(0, 120),
    updatedAt: now,
  };
  db.prepare("INSERT OR REPLACE INTO app_config (key, value, updated_at) VALUES ('admob_config', ?, ?)").run(
    JSON.stringify(clean),
    now,
  );
  return clean;
}

function getYesterdayKey(): string {
  const d = new Date(Date.now() - 86400000);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}

export function recordLoginStreak(userId: string): {
  streakDays: number;
  bonusAwarded: number;
  points: number;
} {
  const db = getDb();
  const today = getTodayKey();
  const yesterday = getYesterdayKey();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) throw new Error("USER_NOT_FOUND");
    if (user.last_streak_date === today) {
      db.exec("COMMIT;");
      return { streakDays: user.streak_days || 1, bonusAwarded: 0, points: user.points };
    }
    const nextStreak = user.last_streak_date === yesterday ? Math.min(365, (user.streak_days || 0) + 1) : 1;
    let bonus = 0;
    if (nextStreak > 1) {
      bonus = nextStreak % 7 === 0 ? 50 : nextStreak % 3 === 0 ? 25 : 10;
    }
    const nextPoints = user.points + bonus;
    db.prepare(
      "UPDATE users SET streak_days = ?, last_streak_date = ?, points = ?, updated_at = ? WHERE id = ?",
    ).run(nextStreak, today, nextPoints, now, userId);

    if (bonus > 0) {
      db.prepare(
        `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
         VALUES (?, ?, ?, ?, 'streak_bonus', ?, ?)`,
      ).run(
        `tx_${crypto.randomUUID()}`,
        userId,
        bonus,
        nextPoints,
        `مكافأة الالتزام اليومي (اليوم ${nextStreak})`,
        now,
      );
    }
    db.exec("COMMIT;");
    return { streakDays: nextStreak, bonusAwarded: bonus, points: nextPoints };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function claimReferralCode(userId: string, rawCode: string): {
  ok: boolean;
  status: number;
  error?: string;
  points?: number;
  bonus?: number;
  user?: ReturnType<typeof sanitizeUserPublic>;
} {
  const code = String(rawCode || "").trim().toUpperCase();
  if (!/^REF-[A-Z0-9]{6}$/.test(code)) {
    return { ok: false, status: 400, error: "صيغة كود الإحالة غير صحيحة (مثال: REF-ABC123)." };
  }
  const db = getDb();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "الحساب غير موجود." };
    }
    if (user.is_guest === 1) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 403, error: "يرجى تسجيل الحساب بالبريد الإلكتروني أولاً لاستخدام أكواد الإحالة بأمان." };
    }
    if (user.referred_by) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 409, error: "تم استخدام كود إحالة على هذا الحساب من قبل." };
    }
    const referrer = db.prepare("SELECT * FROM users WHERE referral_code = ?").get(code) as UserRecord | undefined;
    if (!referrer) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "كود الإحالة غير موجود." };
    }
    if (referrer.id === user.id) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 400, error: "لا يمكنك استخدام كود الإحالة الخاص بك." };
    }
    const weekAgo = now - 7 * 86400000;
    const recentCountRow = db
      .prepare("SELECT COUNT(*) AS cnt FROM point_transactions WHERE user_id = ? AND service = 'referral_reward' AND created_at >= ?")
      .get(referrer.id, weekAgo) as { cnt: number };
    if ((recentCountRow?.cnt || 0) >= 10) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 429, error: "وصل صاحب الكود إلى الحد الأسبوعي العادل للإحالات (10 دعوات)." };
    }

    const inviteeBonus = 60;
    const referrerBonus = 100;
    const nextUserPts = user.points + inviteeBonus;
    const nextRefPts = referrer.points + referrerBonus;

    db.prepare("UPDATE users SET referred_by = ?, points = ?, updated_at = ? WHERE id = ?").run(
      referrer.id,
      nextUserPts,
      now,
      user.id,
    );
    db.prepare("UPDATE users SET points = ?, updated_at = ? WHERE id = ?").run(nextRefPts, now, referrer.id);

    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'referral_invitee', ?, ?)`,
    ).run(`tx_${crypto.randomUUID()}`, user.id, inviteeBonus, nextUserPts, `مكافأة الانضمام عبر كود ${code}`, now);

    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'referral_reward', ?, ?)`,
    ).run(`tx_${crypto.randomUUID()}`, referrer.id, referrerBonus, nextRefPts, `مكافأة دعوة صديق (${user.name})`, now);

    db.exec("COMMIT;");
    return {
      ok: true,
      status: 200,
      points: nextUserPts,
      bonus: inviteeBonus,
      user: sanitizeUserPublic(getUserById(user.id)!),
    };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function getEventConfig(): EventConfig {
  const db = getDb();
  const row = db.prepare("SELECT value, updated_at FROM app_config WHERE key = 'event_config'").get() as
    | { value: string; updated_at: number }
    | undefined;
  if (!row) {
    return {
      id: "ultimate_launch_2026",
      title: "احتفالية إطلاق MY AI Ultimate",
      description: "مكافأة موسمية للترحيب باللاعبين والطلاب في الإصدار الاحترافي المتكامل.",
      bonusPoints: 50,
      active: true,
      updatedAt: 0,
    };
  }
  try {
    const p = JSON.parse(row.value) as Partial<EventConfig>;
    return {
      id: String(p.id || "ultimate_launch_2026"),
      title: String(p.title || "فعالية MY AI"),
      description: String(p.description || ""),
      bonusPoints: Math.max(0, Math.min(1000, Number(p.bonusPoints || 0))),
      active: Boolean(p.active),
      updatedAt: row.updated_at,
    };
  } catch {
    return {
      id: "ultimate_launch_2026",
      title: "احتفالية إطلاق MY AI Ultimate",
      description: "مكافأة موسمية لرواد MY AI.",
      bonusPoints: 50,
      active: true,
      updatedAt: 0,
    };
  }
}

export function saveEventConfig(cfg: Partial<EventConfig>): EventConfig {
  const db = getDb();
  const now = Date.now();
  const clean: EventConfig = {
    id: String(cfg.id || `evt_${now}`).trim().slice(0, 60),
    title: String(cfg.title || "فعالية MY AI").trim().slice(0, 120),
    description: String(cfg.description || "").trim().slice(0, 300),
    bonusPoints: Math.max(0, Math.min(1000, Math.floor(Number(cfg.bonusPoints) || 50))),
    active: Boolean(cfg.active),
    updatedAt: now,
  };
  db.prepare("INSERT OR REPLACE INTO app_config (key, value, updated_at) VALUES ('event_config', ?, ?)").run(
    JSON.stringify(clean),
    now,
  );
  return clean;
}

export function claimSeasonalEvent(userId: string): {
  ok: boolean;
  status: number;
  error?: string;
  points?: number;
  added?: number;
  event?: EventConfig;
} {
  const evt = getEventConfig();
  if (!evt.active || evt.bonusPoints <= 0) {
    return { ok: false, status: 400, error: "لا توجد فعالية مفتوحة للمطالبة حاليًا." };
  }
  const db = getDb();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "المستخدم غير موجود." };
    }
    if (user.last_event_claimed === evt.id) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 409, error: "تم استلام مكافأة هذه الفعالية بالفعل." };
    }
    const nextPoints = user.points + evt.bonusPoints;
    db.prepare("UPDATE users SET points = ?, last_event_claimed = ?, updated_at = ? WHERE id = ?").run(
      nextPoints,
      evt.id,
      now,
      userId,
    );
    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'event_bonus', ?, ?)`,
    ).run(`tx_${crypto.randomUUID()}`, userId, evt.bonusPoints, nextPoints, `فعالية: ${evt.title}`, now);
    db.exec("COMMIT;");
    return { ok: true, status: 200, points: nextPoints, added: evt.bonusPoints, event: evt };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function buyShopItem(userId: string, itemId: string): {
  ok: boolean;
  status: number;
  error?: string;
  user?: ReturnType<typeof sanitizeUserPublic>;
  item?: ShopItemDefinition;
} {
  const item = SHOP_ITEMS.find((i) => i.id === itemId);
  if (!item) {
    return { ok: false, status: 404, error: "العنصر المطلوب غير موجود في المتجر." };
  }
  const db = getDb();
  const now = Date.now();
  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "المستخدم غير موجود." };
    }
    const owned = db
      .prepare("SELECT item_id FROM user_inventory WHERE user_id = ? AND item_id = ?")
      .get(userId, itemId) as { item_id: string } | undefined;
    if (owned) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 409, error: "تم فتح هذا العنصر بالفعل في حسابك." };
    }
    if (user.points < item.cost) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 402, error: `رصيدك (${user.points}) أقل من تكلفة العنصر (${item.cost} نقطة).` };
    }
    const nextPoints = user.points - item.cost;
    db.prepare("UPDATE users SET points = ?, updated_at = ? WHERE id = ?").run(nextPoints, now, userId);
    db.prepare("INSERT INTO user_inventory (user_id, item_id, purchased_at) VALUES (?, ?, ?)").run(userId, itemId, now);
    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'shop_purchase', ?, ?)`,
    ).run(`tx_${crypto.randomUUID()}`, userId, -item.cost, nextPoints, `شراء من المتجر: ${item.name}`, now);

    db.exec("COMMIT;");
    return { ok: true, status: 200, user: sanitizeUserPublic(getUserById(userId)!), item };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

const VALID_GAME_IDS = new Set([
  "ultimate_club_match",
  "football_3d_match",
  "penalty_arena",
  "pitch_striker",
  "football_quiz",
  "guess_player",
  "study_quiz",
  "sport_coach",
]);

export function recordGameCompletion(
  userId: string,
  params: {
    gameId: string;
    score?: number;
    won?: boolean;
    difficulty?: string;
  },
): {
  ok: boolean;
  status: number;
  error?: string;
  points?: number;
  rewardAdded?: number;
  dailyGamePoints?: number;
  dailyGamePointsCap: number;
  stats?: unknown;
} {
  const gameId = String(params.gameId || "").trim();
  if (!VALID_GAME_IDS.has(gameId)) {
    return { ok: false, status: 400, error: "معرف اللعبة غير معروف.", dailyGamePointsCap: 150 };
  }
  const score = Math.max(0, Math.min(100000, Math.floor(Number(params.score) || 0)));
  const won = Boolean(params.won);
  const difficulty = ["سهل", "مبتدئ", "متوسط", "احترافي", "صعب", "نخبة", "أسطوري"].includes(String(params.difficulty || "متوسط"))
    ? String(params.difficulty)
    : "متوسط";

  const diffBonus =
    difficulty === "أسطوري" || difficulty === "نخبة"
      ? 10
      : difficulty === "صعب" || difficulty === "احترافي"
        ? 5
        : 0;
  const rawReward = won ? 15 + diffBonus : 5;
  const xpGain = won ? 35 + diffBonus * 2 : 12;

  const db = getDb();
  const today = getTodayKey();
  const now = Date.now();
  const DAILY_CAP = 150;

  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "المستخدم غير موجود.", dailyGamePointsCap: DAILY_CAP };
    }

    const usedToday = user.daily_game_points_date === today ? user.daily_game_points : 0;
    const allowedReward = Math.max(0, Math.min(rawReward, DAILY_CAP - usedToday));
    const nextUsedToday = usedToday + allowedReward;
    const nextPoints = user.points + allowedReward;

    db.prepare(
      "UPDATE users SET points = ?, daily_game_points_date = ?, daily_game_points = ?, updated_at = ? WHERE id = ?",
    ).run(nextPoints, today, nextUsedToday, now, userId);

    const prevStat = db
      .prepare("SELECT plays, wins, high_score, xp, best_difficulty FROM game_stats WHERE user_id = ? AND game_id = ?")
      .get(userId, gameId) as
      | { plays: number; wins: number; high_score: number; xp: number; best_difficulty: string }
      | undefined;

    const nextPlays = (prevStat?.plays || 0) + 1;
    const nextWins = (prevStat?.wins || 0) + (won ? 1 : 0);
    const nextHigh = Math.max(prevStat?.high_score || 0, score);
    const nextXp = (prevStat?.xp || 0) + xpGain;

    db.prepare(
      `INSERT INTO game_stats (user_id, game_id, plays, wins, high_score, xp, best_difficulty, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(user_id, game_id) DO UPDATE SET
         plays = excluded.plays,
         wins = excluded.wins,
         high_score = excluded.high_score,
         xp = excluded.xp,
         best_difficulty = CASE WHEN excluded.high_score >= game_stats.high_score THEN excluded.best_difficulty ELSE game_stats.best_difficulty END,
         updated_at = excluded.updated_at`,
    ).run(userId, gameId, nextPlays, nextWins, nextHigh, nextXp, difficulty, now);

    if (allowedReward > 0) {
      db.prepare(
        `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
         VALUES (?, ?, ?, ?, 'game_reward', ?, ?)`,
      ).run(
        `tx_${crypto.randomUUID()}`,
        userId,
        allowedReward,
        nextPoints,
        `مكافأة تحدي (${gameId} · ${won ? "فوز" : "مشاركة"})`,
        now,
      );
    }

    db.exec("COMMIT;");
    return {
      ok: true,
      status: 200,
      points: nextPoints,
      rewardAdded: allowedReward,
      dailyGamePoints: nextUsedToday,
      dailyGamePointsCap: DAILY_CAP,
      stats: getUserGameStats(userId),
    };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function recordPvpMatch(params: {
  roomCode: string;
  homeUserId: string;
  awayUserId: string;
  homeClub: string;
  awayClub: string;
  homeGoals: number;
  awayGoals: number;
}) {
  const db = getDb();
  const now = Date.now();
  const winnerUserId =
    params.homeGoals > params.awayGoals
      ? params.homeUserId
      : params.awayGoals > params.homeGoals
        ? params.awayUserId
        : null;
  db.prepare(
    `INSERT INTO pvp_matches (id, room_code, home_user_id, away_user_id, home_club, away_club, home_goals, away_goals, winner_user_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    `pvp_${crypto.randomUUID()}`,
    params.roomCode,
    params.homeUserId,
    params.awayUserId,
    params.homeClub,
    params.awayClub,
    params.homeGoals,
    params.awayGoals,
    winnerUserId,
    now,
  );
  recordGameCompletion(params.homeUserId, {
    gameId: "ultimate_club_match",
    score: params.homeGoals * 100,
    won: params.homeGoals > params.awayGoals,
    difficulty: "احترافي",
  });
  recordGameCompletion(params.awayUserId, {
    gameId: "ultimate_club_match",
    score: params.awayGoals * 100,
    won: params.awayGoals > params.homeGoals,
    difficulty: "احترافي",
  });
}

export function getOwnerAnalytics() {
  const db = getDb();
  const users = db
    .prepare("SELECT COUNT(*) AS total, SUM(CASE WHEN is_guest = 0 THEN 1 ELSE 0 END) AS registered, SUM(CASE WHEN plan != 'free' THEN 1 ELSE 0 END) AS paid, SUM(points) AS totalPoints FROM users")
    .get() as { total: number; registered: number; paid: number; totalPoints: number };
  const txAgg = db
    .prepare("SELECT SUM(CASE WHEN delta > 0 THEN delta ELSE 0 END) AS earned, SUM(CASE WHEN delta < 0 THEN -delta ELSE 0 END) AS spent FROM point_transactions")
    .get() as { earned: number; spent: number };
  const refCount = db.prepare("SELECT COUNT(*) AS cnt FROM point_transactions WHERE service = 'referral_reward'").get() as {
    cnt: number;
  };
  const shopCount = db.prepare("SELECT COUNT(*) AS cnt FROM user_inventory").get() as { cnt: number };
  const gamesCount = db.prepare("SELECT COALESCE(SUM(plays), 0) AS plays, COALESCE(SUM(wins), 0) AS wins FROM game_stats").get() as {
    plays: number;
    wins: number;
  };
  const pvpCount = db.prepare("SELECT COUNT(*) AS cnt FROM pvp_matches").get() as { cnt: number };
  const openTickets = db.prepare("SELECT COUNT(*) AS cnt FROM support_tickets WHERE status != 'resolved'").get() as {
    cnt: number;
  };
  const workoutsCount = db.prepare("SELECT COUNT(*) AS cnt FROM sport_workouts").get() as { cnt: number };
  const f3dCount = db.prepare("SELECT COUNT(*) AS cnt FROM football_match_logs").get() as { cnt: number };

  return {
    totalUsers: Number(users?.total || 0),
    registeredUsers: Number(users?.registered || 0),
    paidUsers: Number(users?.paid || 0),
    pointsInCirculation: Number(users?.totalPoints || 0),
    pointsEarnedTotal: Number(txAgg?.earned || 0),
    pointsSpentTotal: Number(txAgg?.spent || 0),
    referralsCount: Number(refCount?.cnt || 0),
    shopPurchasesCount: Number(shopCount?.cnt || 0),
    gameMatchesPlayed: Number(gamesCount?.plays || 0),
    pvpMatchesPlayed: Number(pvpCount?.cnt || 0),
    openSupportTickets: Number(openTickets?.cnt || 0),
    sportWorkoutsCompleted: Number(workoutsCount?.cnt || 0),
    football3dMatchesPlayed: Number(f3dCount?.cnt || 0),
  };
}

export function updateUserPreferences(
  userId: string,
  prefs: { dialect?: string; chatFontSize?: number; themeAccent?: string },
) {
  const db = getDb();
  const user = getUserById(userId);
  if (!user) return null;
  const dialect: DialectPreference =
    prefs.dialect === "ar_msa" || prefs.dialect === "en" || prefs.dialect === "ar_eg"
      ? prefs.dialect
      : user.dialect || "ar_eg";
  const chatFontSize = Number.isFinite(Number(prefs.chatFontSize))
    ? Math.max(13, Math.min(22, Math.round(Number(prefs.chatFontSize))))
    : Number(user.chat_font_size || 15);
  const themeAccent: ThemeAccentPreference =
    prefs.themeAccent === "gold" ||
    prefs.themeAccent === "emerald" ||
    prefs.themeAccent === "ice" ||
    prefs.themeAccent === "red"
      ? prefs.themeAccent
      : user.theme_accent || "red";

  db.prepare("UPDATE users SET dialect = ?, chat_font_size = ?, theme_accent = ?, updated_at = ? WHERE id = ?").run(
    dialect,
    chatFontSize,
    themeAccent,
    Date.now(),
    userId,
  );
  return sanitizeUserPublic(getUserById(userId)!);
}

// =========================================================================
// Sport AI Coach & Tracker Persistence
// =========================================================================
const DEFAULT_SKILL_STATS = {
  dribbling: 55,
  passing: 55,
  shooting: 55,
  control: 55,
  positioning: 55,
  fitness: 60,
};

export function saveSportProfile(
  userId: string,
  params: {
    position?: string;
    age?: number;
    level?: string;
    weeklyDays?: number;
    goal?: string;
    planJson?: unknown;
  },
) {
  const db = getDb();
  const now = Date.now();
  const existing = db.prepare("SELECT * FROM sport_profiles WHERE user_id = ?").get(userId) as
    | {
        position: string;
        age: number;
        level: string;
        weekly_days: number;
        goal: string;
        plan_json: string;
        skill_stats_json: string;
      }
    | undefined;

  const position = String(params.position ?? existing?.position ?? "وسط").trim().slice(0, 40) || "وسط";
  const age = Math.max(7, Math.min(60, Math.floor(Number(params.age ?? existing?.age ?? 18))));
  const level = ["مبتدئ", "متوسط", "متقدم", "محترف"].includes(String(params.level ?? existing?.level ?? "متوسط"))
    ? String(params.level ?? existing?.level ?? "متوسط")
    : "متوسط";
  const weeklyDays = Math.max(2, Math.min(7, Math.floor(Number(params.weeklyDays ?? existing?.weekly_days ?? 4))));
  const goal = String(params.goal ?? existing?.goal ?? "تطوير المهارات واللياقة").trim().slice(0, 140);
  const planStr = params.planJson !== undefined ? JSON.stringify(params.planJson) : existing?.plan_json || "{}";
  const skillsStr = existing?.skill_stats_json || JSON.stringify(DEFAULT_SKILL_STATS);

  db.prepare(
    `INSERT INTO sport_profiles (user_id, position, age, level, weekly_days, goal, plan_json, skill_stats_json, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET
       position = excluded.position,
       age = excluded.age,
       level = excluded.level,
       weekly_days = excluded.weekly_days,
       goal = excluded.goal,
       plan_json = excluded.plan_json,
       updated_at = excluded.updated_at`,
  ).run(userId, position, age, level, weeklyDays, goal, planStr, skillsStr, now);

  return getSportDashboard(userId);
}

export function completeSportDrill(
  userId: string,
  params: {
    title: string;
    drillType?: string;
    durationMin?: number;
    targetSkill?: string;
    elapsedSec?: number;
  },
): {
  ok: boolean;
  status: number;
  error?: string;
  rewardAdded?: number;
  points?: number;
  dashboard?: ReturnType<typeof getSportDashboard>;
} {
  const db = getDb();
  const now = Date.now();
  const elapsedSec = Math.max(0, Math.floor(Number(params.elapsedSec) || 0));
  if (elapsedSec < 15) {
    return {
      ok: false,
      status: 400,
      error: "لا يمكن احتساب التمرين بمجرد الضغط؛ أكمل المؤقت (15 ثانية على الأقل للتجربة العملية أو مدة التمرين).",
    };
  }
  const title = String(params.title || "تمرين مهاري").trim().slice(0, 100);
  const drillType = String(params.drillType || "مهارات").trim().slice(0, 40);
  const durationMin = Math.max(1, Math.min(120, Math.round(Number(params.durationMin) || 10)));
  const validSkills = ["dribbling", "passing", "shooting", "control", "positioning", "fitness"];
  const targetSkill = validSkills.includes(String(params.targetSkill || ""))
    ? String(params.targetSkill)
    : "dribbling";

  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "المستخدم غير موجود." };
    }
    if (user.last_sport_claim_at && now - user.last_sport_claim_at < 30_000) {
      db.exec("ROLLBACK;");
      return {
        ok: false,
        status: 429,
        error: "تمهل قليلاً قبل تسجيل التمرين التالي (30 ثانية بين كل تمرين وآخر لمنع التكرار).",
      };
    }

    const today = getTodayKey();
    const todayCap = 150;
    const usedToday = user.daily_game_points_date === today ? user.daily_game_points : 0;
    const rawReward = Math.min(20, 8 + Math.floor(durationMin / 4));
    const rewardAdded = Math.max(0, Math.min(rawReward, todayCap - usedToday));
    const nextPoints = user.points + rewardAdded;
    const nextUsedToday = usedToday + rewardAdded;

    db.prepare(
      "UPDATE users SET points = ?, daily_game_points_date = ?, daily_game_points = ?, last_sport_claim_at = ?, updated_at = ? WHERE id = ?",
    ).run(nextPoints, today, nextUsedToday, now, now, userId);

    db.prepare(
      `INSERT INTO sport_workouts (id, user_id, title, drill_type, duration_min, target_skill, score, completed_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    ).run(`wrk_${crypto.randomUUID()}`, userId, title, drillType, durationMin, targetSkill, 100, now);

    // Update player skill matrix
    const prof = db.prepare("SELECT skill_stats_json FROM sport_profiles WHERE user_id = ?").get(userId) as
      | { skill_stats_json: string }
      | undefined;
    let skills: Record<string, number> = { ...DEFAULT_SKILL_STATS };
    if (prof?.skill_stats_json) {
      try {
        skills = { ...skills, ...JSON.parse(prof.skill_stats_json) };
      } catch {}
    }
    skills[targetSkill] = Math.min(99, (skills[targetSkill] || 55) + 2);
    skills.fitness = Math.min(99, (skills.fitness || 60) + 1);

    db.prepare(
      `INSERT INTO sport_profiles (user_id, skill_stats_json, updated_at) VALUES (?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET skill_stats_json = excluded.skill_stats_json, updated_at = excluded.updated_at`,
    ).run(userId, JSON.stringify(skills), now);

    if (rewardAdded > 0) {
      db.prepare(
        `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
         VALUES (?, ?, ?, ?, 'sport_workout', ?, ?)`,
      ).run(`tx_${crypto.randomUUID()}`, userId, rewardAdded, nextPoints, `إتمام تمرين Sport AI: ${title}`, now);
    }

    db.exec("COMMIT;");
    return {
      ok: true,
      status: 200,
      rewardAdded,
      points: nextPoints,
      dashboard: getSportDashboard(userId),
    };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

export function createSportGoal(userId: string, params: { title: string; targetValue?: number; unit?: string }) {
  const db = getDb();
  const now = Date.now();
  const id = `gol_${crypto.randomUUID()}`;
  const title = String(params.title || "").trim().slice(0, 100);
  if (!title) return { error: "اكتب عنوان الهدف الرياضي." };
  const targetValue = Math.max(1, Math.min(1000, Math.round(Number(params.targetValue) || 5)));
  const unit = String(params.unit || "تمرين").trim().slice(0, 30);
  db.prepare(
    `INSERT INTO sport_goals (id, user_id, title, target_value, current_value, unit, completed, created_at, updated_at)
     VALUES (?, ?, ?, ?, 0, ?, 0, ?, ?)`,
  ).run(id, userId, title, targetValue, unit, now, now);
  return { ok: true, goal: db.prepare("SELECT * FROM sport_goals WHERE id = ?").get(id), dashboard: getSportDashboard(userId) };
}

export function progressSportGoal(userId: string, goalId: string, increment = 1) {
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM sport_goals WHERE id = ? AND user_id = ?")
    .get(goalId, userId) as { current_value: number; target_value: number; completed: number } | undefined;
  if (!row) return { error: "الهدف غير موجود." };
  const nextVal = Math.max(0, Math.min(row.target_value, row.current_value + Math.max(1, Math.floor(increment))));
  const done = nextVal >= row.target_value ? 1 : 0;
  const justCompleted = !row.completed && done === 1;
  db.prepare("UPDATE sport_goals SET current_value = ?, completed = ?, updated_at = ? WHERE id = ? AND user_id = ?").run(
    nextVal,
    done,
    Date.now(),
    goalId,
    userId,
  );
  return { ok: true, justCompleted, dashboard: getSportDashboard(userId) };
}

export function getSportDashboard(userId: string) {
  const db = getDb();
  const profRow = db.prepare("SELECT * FROM sport_profiles WHERE user_id = ?").get(userId) as
    | {
        position: string;
        age: number;
        level: string;
        weekly_days: number;
        goal: string;
        plan_json: string;
        skill_stats_json: string;
        updated_at: number;
      }
    | undefined;

  let plan: unknown = null;
  let skills: Record<string, number> = { ...DEFAULT_SKILL_STATS };
  if (profRow) {
    try {
      const p = JSON.parse(profRow.plan_json || "{}");
      if (p && Object.keys(p).length) plan = p;
    } catch {}
    try {
      skills = { ...skills, ...JSON.parse(profRow.skill_stats_json || "{}") };
    } catch {}
  }

  const workouts = db
    .prepare("SELECT * FROM sport_workouts WHERE user_id = ? ORDER BY completed_at DESC LIMIT 60")
    .all(userId) as Array<{
    id: string;
    title: string;
    drill_type: string;
    duration_min: number;
    target_skill: string;
    score: number;
    completed_at: number;
  }>;

  const goals = db
    .prepare("SELECT * FROM sport_goals WHERE user_id = ? ORDER BY created_at DESC LIMIT 25")
    .all(userId);

  const now = Date.now();
  const dayMs = 86400000;
  const workouts7d = workouts.filter((w) => w.completed_at >= now - 7 * dayMs);
  const workouts30d = workouts.filter((w) => w.completed_at >= now - 30 * dayMs);
  const targetWeekly = profRow?.weekly_days || 4;
  const uniqueDays7d = new Set(workouts7d.map((w) => new Date(w.completed_at).toISOString().slice(0, 10))).size;
  const adherencePct = Math.min(100, Math.round((uniqueDays7d / Math.max(1, targetWeekly)) * 100));
  const totalMinutes = workouts.reduce((a, w) => a + Number(w.duration_min || 0), 0);

  // Identify strengths & areas to improve
  const skillEntries = Object.entries(skills).sort((a, b) => b[1] - a[1]);
  const strongest = skillEntries[0]?.[0] || "fitness";
  const weakest = skillEntries[skillEntries.length - 1]?.[0] || "shooting";

  return {
    profile: {
      position: profRow?.position || "وسط",
      age: profRow?.age || 18,
      level: profRow?.level || "متوسط",
      weeklyDays: profRow?.weekly_days || 4,
      goal: profRow?.goal || "تطوير المهارات واللياقة",
      updatedAt: profRow?.updated_at || 0,
    },
    plan,
    skills,
    workouts,
    goals,
    summary: {
      totalWorkouts: workouts.length,
      workoutsThisWeek: workouts7d.length,
      workoutsThisMonth: workouts30d.length,
      totalMinutes,
      adherencePct,
      strongestSkill: strongest,
      weakestSkill: weakest,
    },
  };
}

// =========================================================================
// MY AI FOOTBALL 3D Match Log & Stats
// =========================================================================
export function recordFootball3dMatch(
  userId: string,
  params: {
    homeTeam: string;
    awayTeam: string;
    homeGoals: number;
    awayGoals: number;
    difficulty: string;
    possessionPct?: number;
    shots?: number;
    shotsOnTarget?: number;
    passes?: number;
    durationSec?: number;
  },
) {
  const db = getDb();
  const homeGoals = Math.max(0, Math.min(25, Math.floor(Number(params.homeGoals) || 0)));
  const awayGoals = Math.max(0, Math.min(25, Math.floor(Number(params.awayGoals) || 0)));
  const won = homeGoals > awayGoals;
  const score = Math.max(50, homeGoals * 150 + (won ? 200 : homeGoals === awayGoals ? 80 : 20));
  const stats = {
    possessionPct: Math.max(0, Math.min(100, Math.round(Number(params.possessionPct ?? 50)))),
    shots: Math.max(0, Math.min(80, Math.floor(Number(params.shots || 0)))),
    shotsOnTarget: Math.max(0, Math.min(80, Math.floor(Number(params.shotsOnTarget || 0)))),
    passes: Math.max(0, Math.min(400, Math.floor(Number(params.passes || 0)))),
    durationSec: Math.max(30, Math.min(1800, Math.floor(Number(params.durationSec || 120)))),
  };

  db.prepare(
    `INSERT INTO football_match_logs (id, user_id, mode, difficulty, home_team, away_team, home_goals, away_goals, stats_json, created_at)
     VALUES (?, ?, '3d_match', ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    `f3d_${crypto.randomUUID()}`,
    userId,
    String(params.difficulty || "متوسط").slice(0, 20),
    String(params.homeTeam || "MY AI FC").slice(0, 60),
    String(params.awayTeam || "AI Rivals").slice(0, 60),
    homeGoals,
    awayGoals,
    JSON.stringify(stats),
    Date.now(),
  );

  return recordGameCompletion(userId, {
    gameId: "football_3d_match",
    score,
    won,
    difficulty: params.difficulty,
  });
}

// =========================================================================
// MY AI FOOTBALL Franchise State (Club, Market, Tactics, Cards, Careers, HUD)
// =========================================================================
export type PackTierKey = "bronze" | "silver" | "gold" | "legend";

export const PACK_COSTS: Record<PackTierKey, { cost: number; label: string; minOvr: number; maxOvr: number; count: number }> = {
  bronze: { cost: 20, label: "باقة برونزية (مبتدئة)", minOvr: 74, maxOvr: 84, count: 3 },
  silver: { cost: 65, label: "باقة فضية احترافية", minOvr: 78, maxOvr: 88, count: 3 },
  gold: { cost: 140, label: "باقة ذهبية نادرة", minOvr: 83, maxOvr: 92, count: 3 },
  legend: { cost: 280, label: "باقة الأساطير الذهبية", minOvr: 87, maxOvr: 99, count: 3 },
};

export function getFootballState(userId: string): { state: Record<string, unknown> | null; updatedAt: number } {
  const db = getDb();
  const row = db
    .prepare("SELECT state_json, updated_at FROM football_career_state WHERE user_id = ?")
    .get(userId) as { state_json: string; updated_at: number } | undefined;
  if (!row) return { state: null, updatedAt: 0 };
  try {
    const parsed = JSON.parse(row.state_json || "{}") as Record<string, unknown>;
    return { state: parsed, updatedAt: row.updated_at };
  } catch {
    return { state: null, updatedAt: 0 };
  }
}

export function saveFootballState(
  userId: string,
  incomingState: Record<string, unknown>,
): { ok: boolean; updatedAt: number; error?: string } {
  const db = getDb();
  if (!incomingState || typeof incomingState !== "object" || Array.isArray(incomingState)) {
    return { ok: false, updatedAt: 0, error: "تنسيق بيانات النادي غير صالح." };
  }
  const serialized = JSON.stringify(incomingState);
  if (serialized.length > 600_000) {
    return { ok: false, updatedAt: 0, error: "حجم بيانات المسيرة تجاوز الحد المسموح." };
  }
  const now = Date.now();
  db.prepare(
    `INSERT INTO football_career_state (user_id, state_json, updated_at)
     VALUES (?, ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET state_json = excluded.state_json, updated_at = excluded.updated_at`,
  ).run(userId, serialized, now);
  return { ok: true, updatedAt: now };
}

export function openFootballCardPack(
  userId: string,
  packTierRaw: string,
): {
  ok: boolean;
  status: number;
  error?: string;
  tier?: PackTierKey;
  packMeta?: { cost: number; label: string; minOvr: number; maxOvr: number; count: number };
  points?: number;
  seed?: string;
} {
  const tier: PackTierKey =
    packTierRaw === "silver" || packTierRaw === "gold" || packTierRaw === "legend" ? packTierRaw : "bronze";
  const packMeta = PACK_COSTS[tier];
  const db = getDb();
  const now = Date.now();

  db.exec("BEGIN IMMEDIATE;");
  try {
    const user = getUserById(userId);
    if (!user) {
      db.exec("ROLLBACK;");
      return { ok: false, status: 404, error: "المستخدم غير موجود." };
    }
    if (user.points < packMeta.cost) {
      db.exec("ROLLBACK;");
      return {
        ok: false,
        status: 402,
        error: `رصيدك الحالي (${user.points} نقطة) لا يكفي لفتح ${packMeta.label} (${packMeta.cost} نقطة).`,
        points: user.points,
      };
    }

    const nextPoints = user.points - packMeta.cost;
    db.prepare("UPDATE users SET points = ?, updated_at = ? WHERE id = ?").run(nextPoints, now, userId);
    db.prepare(
      `INSERT INTO point_transactions (id, user_id, delta, balance_after, service, description, created_at)
       VALUES (?, ?, ?, ?, 'football_pack', ?, ?)`,
    ).run(
      `tx_${crypto.randomUUID()}`,
      userId,
      -packMeta.cost,
      nextPoints,
      `فتح ${packMeta.label} في MY AI FOOTBALL`,
      now,
    );

    db.exec("COMMIT;");
    return {
      ok: true,
      status: 200,
      tier,
      packMeta,
      points: nextPoints,
      seed: crypto.randomUUID(),
    };
  } catch (err) {
    db.exec("ROLLBACK;");
    throw err;
  }
}

// =========================================================================
// Support / Contact Developer Center
// =========================================================================
export interface SupportContactConfig {
  developerName: string;
  contactEmail: string;
  whatsappUrl: string;
  notes: string;
  updatedAt: number;
}

export function getSupportContactConfig(): SupportContactConfig {
  const db = getDb();
  const row = db.prepare("SELECT value, updated_at FROM app_config WHERE key = 'support_contact'").get() as
    | { value: string; updated_at: number }
    | undefined;
  if (!row) {
    return {
      developerName: "فريق تطوير MY AI",
      contactEmail: "",
      whatsappUrl: "",
      notes: "تقدر تبعت أي مشكلة أو اقتراح مباشر من هنا وهيتابعها المطور في لوحة التحكم.",
      updatedAt: 0,
    };
  }
  try {
    const p = JSON.parse(row.value) as Partial<SupportContactConfig>;
    return {
      developerName: String(p.developerName || "فريق تطوير MY AI"),
      contactEmail: String(p.contactEmail || ""),
      whatsappUrl: String(p.whatsappUrl || ""),
      notes: String(p.notes || ""),
      updatedAt: row.updated_at,
    };
  } catch {
    return {
      developerName: "فريق تطوير MY AI",
      contactEmail: "",
      whatsappUrl: "",
      notes: "",
      updatedAt: 0,
    };
  }
}

export function saveSupportContactConfig(cfg: Partial<SupportContactConfig>): SupportContactConfig {
  const db = getDb();
  const now = Date.now();
  const clean: SupportContactConfig = {
    developerName: String(cfg.developerName || "فريق تطوير MY AI").trim().slice(0, 80),
    contactEmail: String(cfg.contactEmail || "").trim().slice(0, 120),
    whatsappUrl: String(cfg.whatsappUrl || "").trim().slice(0, 180),
    notes: String(cfg.notes || "").trim().slice(0, 300),
    updatedAt: now,
  };
  db.prepare("INSERT OR REPLACE INTO app_config (key, value, updated_at) VALUES ('support_contact', ?, ?)").run(
    JSON.stringify(clean),
    now,
  );
  return clean;
}

export function createSupportTicket(
  userId: string,
  params: { category?: string; subject: string; message: string },
) {
  const db = getDb();
  const subject = String(params.subject || "").trim().slice(0, 120);
  const message = String(params.message || "").trim().slice(0, 2000);
  if (!subject || !message) {
    return { ok: false, status: 400, error: "اكتب عنوان الرسالة والتفاصيل أولاً." };
  }
  const category = ["bug", "game", "assistant", "suggestion", "subscription"].includes(String(params.category || ""))
    ? String(params.category)
    : "suggestion";
  const now = Date.now();
  const id = `tkt_${crypto.randomUUID()}`;
  db.prepare(
    `INSERT INTO support_tickets (id, user_id, category, subject, message, status, admin_reply, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'open', '', ?, ?)`,
  ).run(id, userId, category, subject, message, now, now);

  return {
    ok: true,
    status: 200,
    ticket: db.prepare("SELECT * FROM support_tickets WHERE id = ?").get(id),
  };
}

export function listUserSupportTickets(userId: string) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC LIMIT 30")
    .all(userId);
}

export function listAllSupportTicketsForAdmin() {
  const db = getDb();
  return db
    .prepare(
      `SELECT t.*, u.name AS user_name, u.email AS user_email
       FROM support_tickets t
       LEFT JOIN users u ON u.id = t.user_id
       ORDER BY CASE WHEN t.status = 'open' THEN 0 WHEN t.status = 'in_progress' THEN 1 ELSE 2 END, t.created_at DESC
       LIMIT 100`,
    )
    .all();
}

export function replySupportTicketAdmin(ticketId: string, params: { status?: string; adminReply?: string }) {
  const db = getDb();
  const existing = db.prepare("SELECT id FROM support_tickets WHERE id = ?").get(ticketId) as { id: string } | undefined;
  if (!existing) return { ok: false, error: "التذكرة غير موجودة." };
  const status = ["open", "in_progress", "replied", "resolved", "closed"].includes(String(params.status || ""))
    ? String(params.status)
    : "replied";
  const reply = String(params.adminReply || "").trim().slice(0, 1500);
  db.prepare("UPDATE support_tickets SET status = ?, admin_reply = ?, updated_at = ? WHERE id = ?").run(
    status,
    reply,
    Date.now(),
    ticketId,
  );
  return { ok: true, ticket: db.prepare("SELECT * FROM support_tickets WHERE id = ?").get(ticketId) };
}

