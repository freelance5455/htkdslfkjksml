import type { IncomingMessage, Server as HttpServer } from "node:http";
import type { Duplex } from "node:stream";
import { WebSocketServer, WebSocket } from "ws";
import {
  getUserById,
  recordPvpMatch,
  sanitizeUserPublic,
  verifySessionToken,
} from "./db.ts";

interface PlayerSlot {
  userId: string;
  userName: string;
  clubName: string;
  rating: number;
  formation: string;
  style: string;
  stamina: number;
  pressBoostUntil: number;
  ws: WebSocket | null;
}

interface MatchState {
  status: "waiting" | "playing" | "finished";
  minute: number;
  ballX: number;
  ballY: number;
  ballVx: number;
  ballVy: number;
  possessionSide: "home" | "away";
  homePossTicks: number;
  awayPossTicks: number;
  homeGoals: number;
  awayGoals: number;
  homeShots: number;
  awayShots: number;
  homeShotsOn: number;
  awayShotsOn: number;
  homeCorners: number;
  awayCorners: number;
  events: Array<{ minute: number; text: string; side?: "home" | "away" }>;
  intervalId: ReturnType<typeof setInterval> | null;
}

interface ClubRoom {
  code: string;
  createdAt: number;
  updatedAt: number;
  host: PlayerSlot;
  away: PlayerSlot | null;
  match: MatchState;
}

const VALID_FORMATIONS = new Set(["4-3-3", "4-2-3-1", "4-4-2", "3-5-2", "5-3-2"]);
const VALID_STYLES = new Set(["متوازن", "استحواذ", "ضغط عالٍ", "مرتدات", "دفاع متأخر"]);
const PRESET_EMOTES = new Set([
  "هدف رائع! ⚽",
  "دفاع محكم! 🛡️",
  "هجمة مرتدة خطيرة! ⚡",
  "مباراة قوية! 🔥",
  "بالتوفيق! 🤝",
]);

const rooms = new Map<string, ClubRoom>();
const socketMeta = new WeakMap<WebSocket, { userId: string; roomCode: string | null }>();

function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  for (let attempt = 0; attempt < 20; attempt++) {
    let code = "";
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    if (!rooms.has(code)) return code;
  }
  return `C${Date.now().toString(36).toUpperCase().slice(-5)}`;
}

function createInitialMatchState(): MatchState {
  return {
    status: "waiting",
    minute: 0,
    ballX: 50,
    ballY: 50,
    ballVx: 0,
    ballVy: 0,
    possessionSide: "home",
    homePossTicks: 1,
    awayPossTicks: 1,
    homeGoals: 0,
    awayGoals: 0,
    homeShots: 0,
    awayShots: 0,
    homeShotsOn: 0,
    awayShotsOn: 0,
    homeCorners: 0,
    awayCorners: 0,
    events: [],
    intervalId: null,
  };
}

function sendJson(ws: WebSocket | null, payload: unknown): void {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  try {
    ws.send(JSON.stringify(payload));
  } catch {
    // Ignore transient send errors
  }
}

function serializeRoom(room: ClubRoom) {
  const totalPoss = Math.max(1, room.match.homePossTicks + room.match.awayPossTicks);
  return {
    code: room.code,
    createdAt: room.createdAt,
    host: {
      userId: room.host.userId,
      userName: room.host.userName,
      clubName: room.host.clubName,
      rating: room.host.rating,
      formation: room.host.formation,
      style: room.host.style,
      stamina: Math.round(room.match.status === "waiting" ? 100 : room.host.stamina),
      connected: Boolean(room.host.ws && room.host.ws.readyState === WebSocket.OPEN),
      pressBoostActive: room.host.pressBoostUntil > Date.now(),
    },
    away: room.away
      ? {
          userId: room.away.userId,
          userName: room.away.userName,
          clubName: room.away.clubName,
          rating: room.away.rating,
          formation: room.away.formation,
          style: room.away.style,
          stamina: Math.round(room.match.status === "waiting" ? 100 : room.away.stamina),
          connected: Boolean(room.away.ws && room.away.ws.readyState === WebSocket.OPEN),
          pressBoostActive: room.away.pressBoostUntil > Date.now(),
        }
      : null,
    match: {
      status: room.match.status,
      minute: Math.min(90, Math.round(room.match.minute)),
      ballX: Number(room.match.ballX.toFixed(1)),
      ballY: Number(room.match.ballY.toFixed(1)),
      possessionSide: room.match.possessionSide,
      homePossession: Math.round((room.match.homePossTicks / totalPoss) * 100),
      homeGoals: room.match.homeGoals,
      awayGoals: room.match.awayGoals,
      homeShots: room.match.homeShots,
      awayShots: room.match.awayShots,
      homeShotsOn: room.match.homeShotsOn,
      awayShotsOn: room.match.awayShotsOn,
      homeCorners: room.match.homeCorners,
      awayCorners: room.match.awayCorners,
      events: room.match.events.slice(-14),
    },
  };
}

function broadcastRoom(room: ClubRoom, type: string, extra?: Record<string, unknown>): void {
  const payload = {
    type,
    room: serializeRoom(room),
    ...(extra || {}),
  };
  sendJson(room.host.ws, payload);
  if (room.away) sendJson(room.away.ws, payload);
}

export function getPublicClubRooms() {
  const now = Date.now();
  const list: Array<{
    code: string;
    hostClub: string;
    hostName: string;
    hostRating: number;
    formation: string;
    status: string;
    createdAt: number;
  }> = [];
  for (const [code, room] of rooms.entries()) {
    if (now - room.updatedAt > 20 * 60 * 1000 && room.match.status !== "playing") {
      if (room.match.intervalId) clearInterval(room.match.intervalId);
      rooms.delete(code);
      continue;
    }
    if (room.match.status === "waiting" && !room.away && room.host.ws?.readyState === WebSocket.OPEN) {
      list.push({
        code: room.code,
        hostClub: room.host.clubName,
        hostName: room.host.userName,
        hostRating: room.host.rating,
        formation: room.host.formation,
        status: "waiting",
        createdAt: room.createdAt,
      });
    }
  }
  return list;
}

function stylePowerBonus(style: string): { attack: number; possession: number; staminaDrain: number } {
  switch (style) {
    case "ضغط عالٍ":
      return { attack: 4, possession: 2, staminaDrain: 1.5 };
    case "استحواذ":
      return { attack: 2, possession: 7, staminaDrain: 0.9 };
    case "مرتدات":
      return { attack: 3.5, possession: -4, staminaDrain: 1.0 };
    case "دفاع متأخر":
      return { attack: -2, possession: -5, staminaDrain: 0.7 };
    default:
      return { attack: 1.5, possession: 1, staminaDrain: 1.0 };
  }
}

function startRoomSimulation(room: ClubRoom): void {
  if (room.match.intervalId) clearInterval(room.match.intervalId);
  if (!room.away) return;

  room.host.stamina = 100;
  room.away.stamina = 100;
  room.match = {
    ...createInitialMatchState(),
    status: "playing",
    events: [{ minute: 1, text: `صفارة البداية! ${room.host.clubName} × ${room.away.clubName}` }],
  };
  broadcastRoom(room, "match_started");

  room.match.intervalId = setInterval(() => {
    if (!room.away || room.match.status !== "playing") {
      if (room.match.intervalId) clearInterval(room.match.intervalId);
      return;
    }

    const m = room.match;
    m.minute = Math.min(90, m.minute + 1.5);
    const minInt = Math.max(1, Math.round(m.minute));
    const now = Date.now();

    const homeStyle = stylePowerBonus(room.host.style);
    const awayStyle = stylePowerBonus(room.away.style);
    room.host.stamina = Math.max(38, room.host.stamina - 0.6 * homeStyle.staminaDrain);
    room.away.stamina = Math.max(38, room.away.stamina - 0.6 * awayStyle.staminaDrain);

    const homeBoost = room.host.pressBoostUntil > now ? 6 : 0;
    const awayBoost = room.away.pressBoostUntil > now ? 6 : 0;

    const homeMidStrength = room.host.rating + homeStyle.possession + homeBoost + (room.host.stamina - 70) * 0.12;
    const awayMidStrength = room.away.rating + awayStyle.possession + awayBoost + (room.away.stamina - 70) * 0.12;

    const possProb = Math.max(0.28, Math.min(0.72, 0.5 + (homeMidStrength - awayMidStrength) * 0.012));
    if (Math.random() < (Math.random() < 0.35 ? 1 : 0)) {
      m.possessionSide = Math.random() < possProb ? "home" : "away";
    }
    if (m.possessionSide === "home") m.homePossTicks++;
    else m.awayPossTicks++;

    // Move ball organically toward opponent's goal with tactical drift
    const targetX =
      m.possessionSide === "home"
        ? 56 + Math.random() * 38
        : 6 + Math.random() * 38;
    const targetY = 14 + Math.random() * 72;
    m.ballX = Math.max(4, Math.min(96, m.ballX + (targetX - m.ballX) * 0.42));
    m.ballY = Math.max(7, Math.min(93, m.ballY + (targetY - m.ballY) * 0.48));

    // Evaluate chance / shot generation
    const attackRoll = Math.random();
    const attacker = m.possessionSide === "home" ? room.host : room.away;
    const defender = m.possessionSide === "home" ? room.away : room.host;
    const attStyle = m.possessionSide === "home" ? homeStyle : awayStyle;
    const defStyle = m.possessionSide === "home" ? awayStyle : homeStyle;
    const attBoost = attacker.pressBoostUntil > now ? 5 : 0;

    const inDangerZone =
      (m.possessionSide === "home" && m.ballX > 76) ||
      (m.possessionSide === "away" && m.ballX < 24);

    if (inDangerZone && attackRoll < 0.38) {
      if (m.possessionSide === "home") m.homeShots++;
      else m.awayShots++;

      const shootPower = attacker.rating + attStyle.attack + attBoost + (attacker.stamina - 75) * 0.1;
      const defResistance = defender.rating + (defStyle.attack < 0 ? 4 : 0) + (defender.stamina - 75) * 0.1;
      const goalChance = Math.max(0.11, Math.min(0.36, 0.2 + (shootPower - defResistance) * 0.008));

      const outcome = Math.random();
      if (outcome < goalChance) {
        if (m.possessionSide === "home") {
          m.homeShotsOn++;
          m.homeGoals++;
          m.ballX = 97;
        } else {
          m.awayShotsOn++;
          m.awayGoals++;
          m.ballX = 3;
        }
        m.ballY = 46 + Math.random() * 8;
        m.events.push({
          minute: minInt,
          side: m.possessionSide,
          text: `⚽ ${minInt}′ هدف! ${attacker.clubName} يسجل (${m.homeGoals} - ${m.awayGoals})`,
        });
        m.possessionSide = m.possessionSide === "home" ? "away" : "home";
      } else if (outcome < goalChance + 0.36) {
        if (m.possessionSide === "home") m.homeShotsOn++;
        else m.awayShotsOn++;
        m.events.push({
          minute: minInt,
          side: m.possessionSide,
          text: `🧤 ${minInt}′ تصدٍ مذهل من حارس ${defender.clubName}!`,
        });
        if (Math.random() < 0.45) {
          if (m.possessionSide === "home") m.homeCorners++;
          else m.awayCorners++;
        } else {
          m.possessionSide = m.possessionSide === "home" ? "away" : "home";
        }
      } else if (outcome < goalChance + 0.55) {
        if (m.possessionSide === "home") m.homeCorners++;
        else m.awayCorners++;
        m.events.push({
          minute: minInt,
          side: m.possessionSide,
          text: `🚩 ${minInt}′ ركلة ركنية لصالح ${attacker.clubName}`,
        });
      }
    }

    if (m.minute >= 90) {
      m.minute = 90;
      m.status = "finished";
      if (m.intervalId) {
        clearInterval(m.intervalId);
        m.intervalId = null;
      }
      m.events.push({
        minute: 90,
        text: `🏁 نهاية المباراة: ${room.host.clubName} ${m.homeGoals} - ${m.awayGoals} ${room.away.clubName}`,
      });

      try {
        recordPvpMatch({
          roomCode: room.code,
          homeUserId: room.host.userId,
          awayUserId: room.away.userId,
          homeClub: room.host.clubName,
          awayClub: room.away.clubName,
          homeGoals: m.homeGoals,
          awayGoals: m.awayGoals,
        });
      } catch (err) {
        console.error("[MY AI PvP record error]:", err);
      }

      const hostUser = getUserById(room.host.userId);
      const awayUser = getUserById(room.away.userId);
      sendJson(room.host.ws, {
        type: "match_finished",
        room: serializeRoom(room),
        points: hostUser ? sanitizeUserPublic(hostUser).points : undefined,
      });
      sendJson(room.away.ws, {
        type: "match_finished",
        room: serializeRoom(room),
        points: awayUser ? sanitizeUserPublic(awayUser).points : undefined,
      });
      return;
    }

    room.updatedAt = now;
    broadcastRoom(room, "match_state");
  }, 250);
}

function leaveCurrentRoom(ws: WebSocket): void {
  const meta = socketMeta.get(ws);
  if (!meta || !meta.roomCode) return;
  const room = rooms.get(meta.roomCode);
  meta.roomCode = null;
  if (!room) return;

  if (room.host.userId === meta.userId) {
    if (room.match.intervalId) clearInterval(room.match.intervalId);
    if (room.away?.ws) {
      const awayMeta = socketMeta.get(room.away.ws);
      if (awayMeta) awayMeta.roomCode = null;
      sendJson(room.away.ws, {
        type: "room_closed",
        reason: "غادر منشئ الغرفة المباراة.",
      });
    }
    rooms.delete(room.code);
    return;
  }

  if (room.away && room.away.userId === meta.userId) {
    if (room.match.intervalId) {
      clearInterval(room.match.intervalId);
      room.match.intervalId = null;
    }
    const leaverName = room.away.clubName;
    room.away = null;
    room.match.status = "waiting";
    room.match.events.push({ minute: Math.round(room.match.minute), text: `غادر المنافس (${leaverName}) الغرفة.` });
    broadcastRoom(room, "opponent_left");
  }
}

function parseTokenFromUpgrade(req: IncomingMessage): string | null {
  try {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    const qToken = url.searchParams.get("token");
    if (qToken && qToken.trim()) return qToken.trim();
  } catch {
    // Ignore URL parse issues
  }
  const cookieHeader = req.headers.cookie || "";
  const match = /(?:^|;\s*)myai_session=([^;]+)/.exec(cookieHeader);
  return match ? decodeURIComponent(match[1]) : null;
}

export function attachClubMultiplayer(httpServer: HttpServer): void {
  const wss = new WebSocketServer({ noServer: true });

  httpServer.on("upgrade", (req: IncomingMessage, socket: Duplex, head: Buffer) => {
    const rawUrl = req.url || "";
    const pathname = rawUrl.split("?")[0];
    if (pathname !== "/ws/club") {
      return;
    }

    const token = parseTokenFromUpgrade(req);
    const verified = verifySessionToken(token);
    const user = verified ? getUserById(verified.uid) : null;
    if (!user) {
      socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
      socket.destroy();
      return;
    }

    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req, user);
    });
  });

  wss.on("connection", (ws: WebSocket, _req: IncomingMessage, user: NonNullable<ReturnType<typeof getUserById>>) => {
    socketMeta.set(ws, { userId: user.id, roomCode: null });

    sendJson(ws, {
      type: "connected",
      userId: user.id,
      userName: user.name,
      rooms: getPublicClubRooms(),
    });

    ws.on("message", (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(String(raw || "{}")) as Record<string, unknown>;
      } catch {
        sendJson(ws, { type: "error", error: "رسالة غير صالحة." });
        return;
      }

      const action = String(msg.type || "");
      const meta = socketMeta.get(ws);
      if (!meta) return;

      if (action === "list_rooms") {
        sendJson(ws, { type: "rooms_list", rooms: getPublicClubRooms() });
        return;
      }

      if (action === "create_room") {
        leaveCurrentRoom(ws);
        const clubName = String(msg.clubName || `${user.name} FC`).trim().slice(0, 32) || "MY AI FC";
        const rating = Math.max(55, Math.min(96, Math.round(Number(msg.rating) || 78)));
        const formation = VALID_FORMATIONS.has(String(msg.formation || "")) ? String(msg.formation) : "4-3-3";
        const style = VALID_STYLES.has(String(msg.style || "")) ? String(msg.style) : "متوازن";
        const code = generateRoomCode();
        const now = Date.now();
        const room: ClubRoom = {
          code,
          createdAt: now,
          updatedAt: now,
          host: {
            userId: user.id,
            userName: user.name,
            clubName,
            rating,
            formation,
            style,
            stamina: 100,
            pressBoostUntil: 0,
            ws,
          },
          away: null,
          match: createInitialMatchState(),
        };
        rooms.set(code, room);
        meta.roomCode = code;
        sendJson(ws, { type: "room_created", side: "home", room: serializeRoom(room) });
        return;
      }

      if (action === "join_room") {
        const code = String(msg.code || "").trim().toUpperCase();
        const room = rooms.get(code);
        if (!room) {
          sendJson(ws, { type: "error", error: "لم يتم العثور على غرفة بهذا الرمز." });
          return;
        }
        if (room.host.userId === user.id) {
          sendJson(ws, { type: "error", error: "لا يمكنك اللعب ضد نفس الحساب. شارك رمز الغرفة مع صديق أو لاعب آخر." });
          return;
        }
        if (room.away && room.away.userId !== user.id) {
          sendJson(ws, { type: "error", error: "هذه الغرفة ممتلئة بالفعل (لاعِبان)." });
          return;
        }
        leaveCurrentRoom(ws);
        const clubName = String(msg.clubName || `${user.name} XI`).trim().slice(0, 32) || "RIVAL XI";
        const rating = Math.max(55, Math.min(96, Math.round(Number(msg.rating) || 78)));
        const formation = VALID_FORMATIONS.has(String(msg.formation || "")) ? String(msg.formation) : "4-3-3";
        const style = VALID_STYLES.has(String(msg.style || "")) ? String(msg.style) : "متوازن";
        room.away = {
          userId: user.id,
          userName: user.name,
          clubName,
          rating,
          formation,
          style,
          stamina: 100,
          pressBoostUntil: 0,
          ws,
        };
        room.updatedAt = Date.now();
        meta.roomCode = room.code;
        sendJson(ws, { type: "room_joined", side: "away", room: serializeRoom(room) });
        broadcastRoom(room, "room_updated");
        return;
      }

      if (action === "leave_room") {
        leaveCurrentRoom(ws);
        sendJson(ws, { type: "left_room", rooms: getPublicClubRooms() });
        return;
      }

      const room = meta.roomCode ? rooms.get(meta.roomCode) : null;
      if (!room) {
        sendJson(ws, { type: "error", error: "لست داخل غرفة حاليًا." });
        return;
      }

      const side: "home" | "away" | null =
        room.host.userId === user.id ? "home" : room.away?.userId === user.id ? "away" : null;
      if (!side) return;
      const slot = side === "home" ? room.host : room.away!;

      if (action === "set_tactics") {
        if (VALID_FORMATIONS.has(String(msg.formation || ""))) {
          slot.formation = String(msg.formation);
        }
        if (VALID_STYLES.has(String(msg.style || ""))) {
          slot.style = String(msg.style);
        }
        if (msg.pressBoost === true && Date.now() >= slot.pressBoostUntil + 7000) {
          slot.pressBoostUntil = Date.now() + 4000;
          if (room.match.status === "playing") {
            room.match.events.push({
              minute: Math.max(1, Math.round(room.match.minute)),
              side,
              text: `⚡ ${slot.clubName} يفعّل الضغط العالي التكتيكي!`,
            });
          }
        }
        room.updatedAt = Date.now();
        broadcastRoom(room, "room_updated");
        return;
      }

      if (action === "start_match") {
        if (room.host.userId !== user.id) {
          sendJson(ws, { type: "error", error: "منشئ الغرفة فقط يبدأ المباراة." });
          return;
        }
        if (!room.away) {
          sendJson(ws, { type: "error", error: "بانتظار انضمام منافس حقيقي أولاً." });
          return;
        }
        if (room.match.status === "playing") return;
        startRoomSimulation(room);
        return;
      }

      if (action === "rematch") {
        if (!room.away) {
          sendJson(ws, { type: "error", error: "لا يوجد منافس في الغرفة لإعادة المباراة." });
          return;
        }
        startRoomSimulation(room);
        return;
      }

      if (action === "chat_emote") {
        const text = String(msg.emote || "").trim();
        if (!PRESET_EMOTES.has(text)) return;
        broadcastRoom(room, "emote", {
          side,
          clubName: slot.clubName,
          emote: text,
        });
      }
    });

    ws.on("close", () => {
      leaveCurrentRoom(ws);
    });
  });
}
