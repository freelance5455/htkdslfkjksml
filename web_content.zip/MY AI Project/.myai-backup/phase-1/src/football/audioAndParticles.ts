import * as THREE from 'three';

/**
 * Zero-dependency Web Audio stadium atmosphere & crisp match SFX engine.
 */
export class StadiumAudioEngine {
  private ctx: AudioContext | null = null;
  private crowdGain: GainNode | null = null;
  private crowdSource: AudioBufferSourceNode | null = null;
  private muted = false;
  private masterVol = 0.72;
  private targetCrowdLevel = 0.06;
  private curCrowdLevel = 0.06;

  constructor(muted = false, volume = 0.72) {
    this.muted = muted;
    this.masterVol = THREE.MathUtils.clamp(volume, 0, 1);
  }

  public unlock(): void {
    if (this.muted) return;
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.startCrowdLoop();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume().catch(() => {});
      }
    } catch {
      // ignore if audio blocked
    }
  }

  private startCrowdLoop(): void {
    if (!this.ctx || this.crowdSource) return;
    const sr = this.ctx.sampleRate;
    const len = sr * 2.5;
    const buf = this.ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);
    let b0 = 0;
    let b1 = 0;
    let b2 = 0;
    for (let i = 0; i < len; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.997 * b0 + white * 0.029;
      b1 = 0.985 * b1 + white * 0.032;
      b2 = 0.95 * b2 + white * 0.048;
      data[i] = (b0 + b1 + b2) * 0.45;
    }

    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 540;
    filter.Q.value = 0.65;

    const gain = this.ctx.createGain();
    gain.gain.value = this.muted ? 0 : this.curCrowdLevel * this.masterVol;

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.ctx.destination);
    src.start();
    this.crowdSource = src;
    this.crowdGain = gain;
  }

  public setMuted(m: boolean): void {
    this.muted = m;
    if (this.crowdGain && this.ctx) {
      this.crowdGain.gain.setTargetAtTime(m ? 0 : this.curCrowdLevel * this.masterVol, this.ctx.currentTime, 0.08);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public pulseCrowdExcitement(level: number): void {
    this.targetCrowdLevel = Math.max(this.targetCrowdLevel, THREE.MathUtils.clamp(level, 0.05, 0.42));
  }

  public update(dt: number): void {
    this.targetCrowdLevel = THREE.MathUtils.damp(this.targetCrowdLevel, 0.055, 0.85, dt);
    this.curCrowdLevel = THREE.MathUtils.damp(this.curCrowdLevel, this.targetCrowdLevel, 3.2, dt);
    if (this.crowdGain && this.ctx) {
      const g = this.muted ? 0 : this.curCrowdLevel * this.masterVol;
      this.crowdGain.gain.setTargetAtTime(g, this.ctx.currentTime, 0.06);
    }
  }

  public playKick(power01 = 0.6): void {
    if (this.muted || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      const startFreq = 115 + power01 * 55;
      osc.frequency.setValueAtTime(startFreq, now);
      osc.frequency.exponentialRampToValueAtTime(34, now + 0.11);
      gain.gain.setValueAtTime((0.28 + power01 * 0.25) * this.masterVol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.13);
    } catch {
      // ignore
    }
  }

  public playPostClang(): void {
    if (this.muted || !this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(620, now);
      osc.frequency.exponentialRampToValueAtTime(410, now + 0.35);
      gain.gain.setValueAtTime(0.28 * this.masterVol, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.37);
    } catch {
      // ignore
    }
  }

  public playWhistle(pattern: 'short' | 'double' | 'fulltime' = 'short'): void {
    if (this.muted || !this.ctx) return;
    try {
      const bursts = pattern === 'fulltime' ? [0, 0.24, 0.48] : pattern === 'double' ? [0, 0.19] : [0];
      const durs = pattern === 'fulltime' ? [0.16, 0.16, 0.45] : [0.14, 0.22];
      bursts.forEach((offset, idx) => {
        if (!this.ctx) return;
        const t0 = this.ctx.currentTime + offset;
        const dur = durs[idx] || 0.15;
        const osc = this.ctx.createOscillator();
        const lfo = this.ctx.createOscillator();
        const lfoGain = this.ctx.createGain();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(2860, t0);
        lfo.frequency.setValueAtTime(38, t0);
        lfoGain.gain.setValueAtTime(85, t0);

        lfo.connect(lfoGain);
        lfoGain.connect(osc.frequency);
        osc.connect(gain);
        gain.connect(this.ctx.destination);

        gain.gain.setValueAtTime(0.001, t0);
        gain.gain.linearRampToValueAtTime(0.14 * this.masterVol, t0 + 0.02);
        gain.gain.setValueAtTime(0.14 * this.masterVol, t0 + dur - 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

        osc.start(t0);
        lfo.start(t0);
        osc.stop(t0 + dur + 0.02);
        lfo.stop(t0 + dur + 0.02);
      });
    } catch {
      // ignore
    }
  }

  public dispose(): void {
    try {
      this.crowdSource?.stop();
      this.crowdSource?.disconnect();
      this.crowdGain?.disconnect();
      if (this.ctx && this.ctx.state !== 'closed') {
        this.ctx.close().catch(() => {});
      }
    } catch {
      // ignore
    }
    this.crowdSource = null;
    this.crowdGain = null;
    this.ctx = null;
  }
}

interface ParticleItem {
  active: boolean;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  scale: number;
}

/**
 * Zero-GC InstancedMesh grass spray & turf divot particle system.
 */
export class TurfParticlePool {
  private mesh: THREE.InstancedMesh;
  private pool: ParticleItem[] = [];
  private dummy = new THREE.Object3D();
  private cursor = 0;

  constructor(scene: THREE.Scene, count = 110) {
    const geo = new THREE.BoxGeometry(0.09, 0.04, 0.14);
    const mat = new THREE.MeshStandardMaterial({ color: '#2b7a38', roughness: 0.9 });
    this.mesh = new THREE.InstancedMesh(geo, mat, count);
    this.mesh.frustumCulled = false;

    const palette = [new THREE.Color('#277234'), new THREE.Color('#195324'), new THREE.Color('#4a3b22'), new THREE.Color('#3e8e44')];
    for (let i = 0; i < count; i++) {
      this.pool.push({
        active: false,
        x: 0,
        y: -10,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        maxLife: 0.5,
        scale: 1,
      });
      this.dummy.position.set(0, -10, 0);
      this.dummy.scale.setScalar(0.001);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
      this.mesh.setColorAt(i, palette[i % palette.length]);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
    scene.add(this.mesh);
  }

  public burst(x: number, z: number, dirX: number, dirZ: number, amount = 10, power = 4.5): void {
    for (let i = 0; i < amount; i++) {
      const p = this.pool[this.cursor];
      this.cursor = (this.cursor + 1) % this.pool.length;
      p.active = true;
      p.x = x + (Math.random() - 0.5) * 0.4;
      p.y = 0.05;
      p.z = z + (Math.random() - 0.5) * 0.4;
      p.vx = dirX * power * (0.4 + Math.random() * 0.8) + (Math.random() - 0.5) * 2.8;
      p.vy = 1.6 + Math.random() * 2.8;
      p.vz = dirZ * power * (0.4 + Math.random() * 0.8) + (Math.random() - 0.5) * 2.8;
      p.maxLife = 0.35 + Math.random() * 0.35;
      p.life = p.maxLife;
      p.scale = 0.7 + Math.random() * 0.8;
    }
  }

  public update(dt: number): void {
    let anyDirty = false;
    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.active) continue;
      anyDirty = true;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        this.dummy.position.set(0, -10, 0);
        this.dummy.scale.setScalar(0.001);
        this.dummy.updateMatrix();
        this.mesh.setMatrixAt(i, this.dummy.matrix);
        continue;
      }
      p.vy -= 14.5 * dt;
      p.x += p.vx * dt;
      p.y = Math.max(0.02, p.y + p.vy * dt);
      p.z += p.vz * dt;
      const s = p.scale * (p.life / p.maxLife);
      this.dummy.position.set(p.x, p.y, p.z);
      this.dummy.rotation.set(p.life * 8, p.life * 5, 0);
      this.dummy.scale.setScalar(Math.max(0.01, s));
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
    }
    if (anyDirty) {
      this.mesh.instanceMatrix.needsUpdate = true;
    }
  }

  public dispose(): void {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
  }
}
