import * as THREE from 'three';

export interface PoseChannels {
  pelvisY: number;
  pelvisRotX: number;
  pelvisRotZ: number;
  torsoRotX: number;
  torsoRotY: number;
  headYaw: number;
  headPitch: number;
  lHipX: number;
  lHipZ: number;
  lKneeX: number;
  rHipX: number;
  rHipZ: number;
  rKneeX: number;
  lShX: number;
  lShZ: number;
  lElbX: number;
  rShX: number;
  rShZ: number;
  rElbX: number;
}

export function createDefaultPose(): PoseChannels {
  return {
    pelvisY: 0.94,
    pelvisRotX: 0,
    pelvisRotZ: 0,
    torsoRotX: 0.03,
    torsoRotY: 0,
    headYaw: 0,
    headPitch: 0,
    lHipX: 0,
    lHipZ: 0.03,
    lKneeX: 0.06,
    rHipX: 0,
    rHipZ: -0.03,
    rKneeX: 0.06,
    lShX: 0.04,
    lShZ: -0.09,
    lElbX: -0.22,
    rShX: 0.04,
    rShZ: 0.09,
    rElbX: -0.22,
  };
}

export function dampPose(
  cur: PoseChannels,
  tgt: PoseChannels,
  lambda: number,
  dt: number,
): void {
  cur.pelvisY = THREE.MathUtils.damp(cur.pelvisY, tgt.pelvisY, lambda, dt);
  cur.pelvisRotX = THREE.MathUtils.damp(cur.pelvisRotX, tgt.pelvisRotX, lambda, dt);
  cur.pelvisRotZ = THREE.MathUtils.damp(cur.pelvisRotZ, tgt.pelvisRotZ, lambda, dt);
  cur.torsoRotX = THREE.MathUtils.damp(cur.torsoRotX, tgt.torsoRotX, lambda, dt);
  cur.torsoRotY = THREE.MathUtils.damp(cur.torsoRotY, tgt.torsoRotY, lambda, dt);
  cur.headYaw = THREE.MathUtils.damp(cur.headYaw, tgt.headYaw, lambda, dt);
  cur.headPitch = THREE.MathUtils.damp(cur.headPitch, tgt.headPitch, lambda, dt);
  cur.lHipX = THREE.MathUtils.damp(cur.lHipX, tgt.lHipX, lambda, dt);
  cur.lHipZ = THREE.MathUtils.damp(cur.lHipZ, tgt.lHipZ, lambda, dt);
  cur.lKneeX = THREE.MathUtils.damp(cur.lKneeX, tgt.lKneeX, lambda, dt);
  cur.rHipX = THREE.MathUtils.damp(cur.rHipX, tgt.rHipX, lambda, dt);
  cur.rHipZ = THREE.MathUtils.damp(cur.rHipZ, tgt.rHipZ, lambda, dt);
  cur.rKneeX = THREE.MathUtils.damp(cur.rKneeX, tgt.rKneeX, lambda, dt);
  cur.lShX = THREE.MathUtils.damp(cur.lShX, tgt.lShX, lambda, dt);
  cur.lShZ = THREE.MathUtils.damp(cur.lShZ, tgt.lShZ, lambda, dt);
  cur.lElbX = THREE.MathUtils.damp(cur.lElbX, tgt.lElbX, lambda, dt);
  cur.rShX = THREE.MathUtils.damp(cur.rShX, tgt.rShX, lambda, dt);
  cur.rShZ = THREE.MathUtils.damp(cur.rShZ, tgt.rShZ, lambda, dt);
  cur.rElbX = THREE.MathUtils.damp(cur.rElbX, tgt.rElbX, lambda, dt);
}

/**
 * Generates an athletic knit football jersey texture (front & back mapped around Lathe UVs).
 */
export function makeKitFabricTexture(
  primaryHex: string,
  accentHex: string,
  jerseyNo: number,
  isGk: boolean,
): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = primaryHex;
  ctx.fillRect(0, 0, 256, 256);

  // Subtle fabric breathability mesh stripes
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  for (let x = 0; x < 256; x += 24) {
    ctx.fillRect(x, 0, 10, 256);
  }
  if (!isGk) {
    // Athletic diagonal chest sash / trim
    ctx.fillStyle = accentHex;
    ctx.globalAlpha = 0.22;
    ctx.beginPath();
    ctx.moveTo(0, 210);
    ctx.lineTo(256, 75);
    ctx.lineTo(256, 115);
    ctx.lineTo(0, 250);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Subtle weave horizontal micro-lines
  ctx.fillStyle = 'rgba(0,0,0,0.06)';
  for (let y = 0; y < 256; y += 6) {
    ctx.fillRect(0, y, 256, 1);
  }

  // Collar cuff border along top
  ctx.fillStyle = accentHex;
  ctx.fillRect(0, 0, 256, 16);

  // Club badge on left chest (~u=0.22 -> front torso side)
  ctx.fillStyle = accentHex;
  ctx.beginPath();
  ctx.arc(64, 86, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Sponsor bar across mid chest
  ctx.fillStyle = 'rgba(255,255,255,0.88)';
  ctx.font = '900 18px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('MY AI', 96, 142);

  // Back number crisp graphic (~u=0.75)
  ctx.fillStyle = accentHex;
  ctx.strokeStyle = 'rgba(0,0,0,0.75)';
  ctx.lineWidth = 4;
  ctx.font = '900 46px Arial, sans-serif';
  const numStr = String(jerseyNo || 10);
  ctx.strokeText(numStr, 196, 128);
  ctx.fillText(numStr, 196, 128);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Generates an athletic sculpted head/face UV map for human footballer heads.
 */
export function makeFaceSkinTexture(skinHex: string, hairHex: string, hasStubble: boolean): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext('2d')!;

  ctx.fillStyle = skinHex;
  ctx.fillRect(0, 0, 256, 128);

  // Cheekbones & jawline natural subsurface shadow
  const grad = ctx.createLinearGradient(0, 0, 0, 128);
  grad.addColorStop(0, 'rgba(255,255,255,0.06)');
  grad.addColorStop(0.6, 'rgba(0,0,0,0)');
  grad.addColorStop(1, 'rgba(40,12,8,0.22)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 128);

  if (hasStubble) {
    ctx.fillStyle = hairHex;
    ctx.globalAlpha = 0.16;
    ctx.beginPath();
    ctx.ellipse(128, 102, 42, 22, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Forehead hairline shade
  ctx.fillStyle = hairHex;
  ctx.globalAlpha = 0.25;
  ctx.fillRect(0, 0, 256, 22);
  ctx.globalAlpha = 1;

  // Center front face is around u=0.25 on SphereGeometry (+Z face depends on rotation, calibrate nose/eyes at x=64 or 192)
  // On Three.js SphereGeometry: angle phi=0 starts at -X, theta maps vertically; front (+Z) corresponds to phi = PI/2 -> u = 0.25 -> x=64
  const cx = 64;
  // Eyebrows
  ctx.strokeStyle = hairHex;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cx - 22, 47);
  ctx.lineTo(cx - 7, 45);
  ctx.moveTo(cx + 7, 45);
  ctx.lineTo(cx + 22, 47);
  ctx.stroke();

  // Eyes (natural almond whites + iris + catchlight)
  [-14, 14].forEach((ox) => {
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.ellipse(cx + ox, 57, 6.2, 3.6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#1e1b18';
    ctx.beginPath();
    ctx.arc(cx + ox, 57, 2.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(cx + ox - 1, 56, 0.9, 0, Math.PI * 2);
    ctx.fill();
  });

  // Subtle mouth & philtrum shadow
  ctx.strokeStyle = 'rgba(110,45,40,0.65)';
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.moveTo(cx - 8, 88);
  ctx.quadraticCurveTo(cx, 91, cx + 8, 88);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface SharedLimbGeometries {
  torsoGeo: THREE.BufferGeometry;
  pelvisGeo: THREE.BufferGeometry;
  shoulderCapGeo: THREE.BufferGeometry;
  collarGeo: THREE.BufferGeometry;
  armbandGeo: THREE.BufferGeometry;
  shortsTopGeo: THREE.BufferGeometry;
  thighGeo: THREE.BufferGeometry;
  kneeGeo: THREE.BufferGeometry;
  calfGeo: THREE.BufferGeometry;
  sockCuffGeo: THREE.BufferGeometry;
  bootUpperGeo: THREE.BufferGeometry;
  bootSoleGeo: THREE.BufferGeometry;
  bootStudGeo: THREE.BufferGeometry;
  sleeveGeo: THREE.BufferGeometry;
  upperArmGeo: THREE.BufferGeometry;
  elbowGeo: THREE.BufferGeometry;
  forearmGeo: THREE.BufferGeometry;
  handGeo: THREE.BufferGeometry;
  gloveGeo: THREE.BufferGeometry;
  neckGeo: THREE.BufferGeometry;
  headGeo: THREE.BufferGeometry;
  jawGeo: THREE.BufferGeometry;
  noseGeo: THREE.BufferGeometry;
  earGeo: THREE.BufferGeometry;
  hairShortGeo: THREE.BufferGeometry;
  hairFadeTopGeo: THREE.BufferGeometry;
  hairCurlyGeo: THREE.BufferGeometry;
  hairLongGeo: THREE.BufferGeometry;
  pShadowGeo: THREE.BufferGeometry;
  badgeGeo: THREE.BufferGeometry;
}

export function createAthleticGeometries(track: <T extends { dispose: () => void }>(item: T) => T): SharedLimbGeometries {
  // Muscular athletic torso profile (V-tapered waist -> chest -> broad deltoids)
  const torsoProfile = [
    new THREE.Vector2(0.01, -0.26),
    new THREE.Vector2(0.152, -0.25),
    new THREE.Vector2(0.142, -0.05),
    new THREE.Vector2(0.188, 0.16),
    new THREE.Vector2(0.208, 0.30),
    new THREE.Vector2(0.09, 0.35),
    new THREE.Vector2(0.01, 0.35),
  ];
  const torsoGeo = track(new THREE.LatheGeometry(torsoProfile, 16));

  // Anatomically tapered quadriceps
  const thighProfile = [
    new THREE.Vector2(0.01, -0.205),
    new THREE.Vector2(0.056, -0.195),
    new THREE.Vector2(0.074, -0.02),
    new THREE.Vector2(0.084, 0.14),
    new THREE.Vector2(0.076, 0.20),
    new THREE.Vector2(0.01, 0.205),
  ];
  const thighGeo = track(new THREE.LatheGeometry(thighProfile, 12));

  // Sculpted gastrocnemius calf + ankle taper
  const calfProfile = [
    new THREE.Vector2(0.01, -0.20),
    new THREE.Vector2(0.042, -0.19),
    new THREE.Vector2(0.048, -0.06),
    new THREE.Vector2(0.064, 0.08),
    new THREE.Vector2(0.058, 0.19),
    new THREE.Vector2(0.01, 0.20),
  ];
  const calfGeo = track(new THREE.LatheGeometry(calfProfile, 12));

  // Tapered upper arm & forearm
  const upperArmProfile = [
    new THREE.Vector2(0.01, -0.13),
    new THREE.Vector2(0.043, -0.12),
    new THREE.Vector2(0.055, 0.02),
    new THREE.Vector2(0.052, 0.12),
    new THREE.Vector2(0.01, 0.13),
  ];
  const upperArmGeo = track(new THREE.LatheGeometry(upperArmProfile, 10));

  const forearmProfile = [
    new THREE.Vector2(0.01, -0.125),
    new THREE.Vector2(0.032, -0.115),
    new THREE.Vector2(0.044, 0.05),
    new THREE.Vector2(0.043, 0.12),
    new THREE.Vector2(0.01, 0.125),
  ];
  const forearmGeo = track(new THREE.LatheGeometry(forearmProfile, 10));

  return {
    torsoGeo,
    pelvisGeo: track(new THREE.CylinderGeometry(0.165, 0.155, 0.18, 12)),
    shoulderCapGeo: track(new THREE.SphereGeometry(0.075, 10, 8)),
    collarGeo: track(new THREE.TorusGeometry(0.082, 0.02, 6, 14)),
    armbandGeo: track(new THREE.CylinderGeometry(0.068, 0.068, 0.055, 10)),
    shortsTopGeo: track(new THREE.CylinderGeometry(0.09, 0.098, 0.24, 12)),
    thighGeo,
    kneeGeo: track(new THREE.SphereGeometry(0.058, 8, 8)),
    calfGeo,
    sockCuffGeo: track(new THREE.CylinderGeometry(0.065, 0.064, 0.05, 10)),
    bootUpperGeo: track(new THREE.BoxGeometry(0.106, 0.076, 0.265)),
    bootSoleGeo: track(new THREE.BoxGeometry(0.112, 0.024, 0.275)),
    bootStudGeo: track(new THREE.CylinderGeometry(0.011, 0.008, 0.018, 6)),
    sleeveGeo: track(new THREE.CylinderGeometry(0.066, 0.058, 0.19, 10)),
    upperArmGeo,
    elbowGeo: track(new THREE.SphereGeometry(0.043, 8, 8)),
    forearmGeo,
    handGeo: track(new THREE.SphereGeometry(0.040, 8, 8)),
    gloveGeo: track(new THREE.BoxGeometry(0.094, 0.128, 0.068)),
    neckGeo: track(new THREE.CylinderGeometry(0.055, 0.065, 0.105, 10)),
    headGeo: track(new THREE.SphereGeometry(0.122, 18, 14)),
    jawGeo: track(new THREE.BoxGeometry(0.132, 0.082, 0.122)),
    noseGeo: track(new THREE.ConeGeometry(0.019, 0.052, 5)),
    earGeo: track(new THREE.SphereGeometry(0.024, 6, 6)),
    hairShortGeo: track(new THREE.SphereGeometry(0.129, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.56)),
    hairFadeTopGeo: track(new THREE.CylinderGeometry(0.118, 0.126, 0.085, 12)),
    hairCurlyGeo: track(new THREE.DodecahedronGeometry(0.148, 1)),
    hairLongGeo: track(new THREE.CylinderGeometry(0.126, 0.145, 0.21, 12)),
    pShadowGeo: track(new THREE.CircleGeometry(0.42, 16)),
    badgeGeo: track(new THREE.PlaneGeometry(0.25, 0.25)),
  };
}
