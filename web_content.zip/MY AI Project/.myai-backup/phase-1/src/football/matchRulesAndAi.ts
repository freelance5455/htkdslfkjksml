export type DifficultyKey = 'مبتدئ' | 'سهل' | 'متوسط' | 'صعب' | 'محترف' | 'أسطوري';
export type FormationKey = '4-3-3' | '4-2-3-1' | '4-4-2' | '3-5-2' | '5-3-2';
export type StrengthTier = 'عادي' | 'قوي' | 'نخبة';
export type GkTier = 'عادي' | 'متميز' | 'أسطوري';

export const PITCH_W = 104;
export const PITCH_D = 68;
export const HALF_W = PITCH_W / 2;
export const HALF_D = PITCH_D / 2;
export const GOAL_W = 7.6;
export const GOAL_HALF_W = GOAL_W / 2;
export const GOAL_H = 2.58;
export const GOAL_DEPTH = 2.45;
export const BALL_R = 0.235;
export const PEN_BOX_X = HALF_W - 16.5;
export const PEN_BOX_HALF_Z = 20.16;

export const FORMATIONS: Record<FormationKey, Array<[number, number]>> = {
  '4-3-3': [
    [-49.5, 0],
    [-34, -22], [-37, -8], [-37, 8], [-34, 22],
    [-19, 0], [-14, -15], [-14, 15],
    [-4, -22], [-1.2, 0], [-4, 22],
  ],
  '4-2-3-1': [
    [-49.5, 0],
    [-34, -22], [-37, -8], [-37, 8], [-34, 22],
    [-22, -8], [-22, 8],
    [-9, 0], [-9, -19], [-1.2, 0], [-9, 19],
  ],
  '4-4-2': [
    [-49.5, 0],
    [-34, -22], [-37, -8], [-37, 8], [-34, 22],
    [-16, -8], [-15, -22], [-16, 8], [-15, 22],
    [-2, -8], [-2, 8],
  ],
  '3-5-2': [
    [-49.5, 0],
    [-24, -24], [-37, -14], [-38, 0], [-37, 14],
    [-20, -9], [-20, 9], [-11, 0], [-24, 24],
    [-2, -8], [-2, 8],
  ],
  '5-3-2': [
    [-49.5, 0],
    [-31, -24], [-38, -12], [-39, 0], [-38, 12], [-31, 24],
    [-17, -14], [-19, 0], [-17, 14],
    [-2, -8], [-2, 8],
  ],
};

export interface DifficultyFactors {
  aiSpeed: number;
  aiThinkPeriod: number;
  aiVision: number;
  aiShotRate: number;
  pressTight: number;
  gkReach: number;
  tackleDiscipline: number;
}

export function getDifficultyFactors(
  difficulty: DifficultyKey,
  opponentStrength: StrengthTier = 'قوي',
  gkLevel: GkTier = 'متميز',
): DifficultyFactors {
  // Balanced & fair progression: higher levels sharpen tactical intelligence, reaction cadence, and placement without unfair speed cheating
  const strMul = opponentStrength === 'نخبة' ? 1.04 : opponentStrength === 'عادي' ? 0.92 : 1.0;
  const gkMul = gkLevel === 'أسطوري' ? 1.16 : gkLevel === 'عادي' ? 0.82 : 1.0;
  switch (difficulty) {
    case 'مبتدئ':
      return { aiSpeed: 0.78 * strMul, aiThinkPeriod: 0.44, aiVision: 0.36, aiShotRate: 0.45, pressTight: 0.48, gkReach: 0.65 * gkMul, tackleDiscipline: 0.65 };
    case 'سهل':
      return { aiSpeed: 0.86 * strMul, aiThinkPeriod: 0.34, aiVision: 0.52, aiShotRate: 0.62, pressTight: 0.64, gkReach: 0.78 * gkMul, tackleDiscipline: 0.72 };
    case 'صعب':
      return { aiSpeed: 0.97 * strMul, aiThinkPeriod: 0.16, aiVision: 0.84, aiShotRate: 0.92, pressTight: 0.92, gkReach: 1.04 * gkMul, tackleDiscipline: 0.86 };
    case 'محترف':
      return { aiSpeed: 1.01 * strMul, aiThinkPeriod: 0.11, aiVision: 0.94, aiShotRate: 1.06, pressTight: 1.02, gkReach: 1.12 * gkMul, tackleDiscipline: 0.91 };
    case 'أسطوري':
      return { aiSpeed: 1.04 * strMul, aiThinkPeriod: 0.06, aiVision: 1.06, aiShotRate: 1.18, pressTight: 1.12, gkReach: 1.22 * gkMul, tackleDiscipline: 0.95 };
    default: // متوسط
      return { aiSpeed: 0.93 * strMul, aiThinkPeriod: 0.22, aiVision: 0.70, aiShotRate: 0.78, pressTight: 0.78, gkReach: 0.90 * gkMul, tackleDiscipline: 0.80 };
  }
}

export interface SimplePlayerPos {
  id: string;
  side: 'home' | 'away';
  x: number;
  z: number;
}

/**
 * Checks official football offside law at moment of a forward pass.
 */
export function evaluateOffside(
  passerSide: 'home' | 'away',
  ballXAtKick: number,
  receiver: SimplePlayerPos,
  allPlayers: SimplePlayerPos[],
): boolean {
  const dir = passerSide === 'home' ? 1 : -1;
  // Must be in opponent half & strictly ahead of the ball
  if (receiver.x * dir <= 0.3) return false;
  if (receiver.x * dir <= ballXAtKick * dir + 0.25) return false;

  // Sort defenders along attack axis descending (closest to defending goal line first)
  const oppXPositions = allPlayers
    .filter((p) => p.side !== passerSide)
    .map((p) => p.x * dir)
    .sort((a, b) => b - a);
  if (oppXPositions.length < 2) return false;
  const secondLastDefenderX = oppXPositions[1];
  return receiver.x * dir > secondLastDefenderX + 0.35;
}

export type BoundaryRestart =
  | { type: 'throw_in'; team: 'home' | 'away'; x: number; z: number }
  | { type: 'goal_kick'; team: 'home' | 'away'; x: number; z: number }
  | { type: 'corner'; team: 'home' | 'away'; x: number; z: number };

export function classifyBoundaryExit(
  bx: number,
  bz: number,
  lastTouchSide: 'home' | 'away',
): BoundaryRestart | null {
  const restartSide: 'home' | 'away' = lastTouchSide === 'home' ? 'away' : 'home';
  if (Math.abs(bz) > HALF_D + 0.35) {
    return {
      type: 'throw_in',
      team: restartSide,
      x: Math.max(-HALF_W + 2, Math.min(HALF_W - 2, bx)),
      z: Math.sign(bz) * (HALF_D - 0.3),
    };
  }
  if (Math.abs(bx) > HALF_W + 0.4 && Math.abs(bz) >= GOAL_HALF_W) {
    // Ball crossed right goal line (defended by away) or left goal line (defended by home)
    const defendingSide: 'home' | 'away' = bx > 0 ? 'away' : 'home';
    if (lastTouchSide === defendingSide) {
      return {
        type: 'corner',
        team: defendingSide === 'away' ? 'home' : 'away',
        x: Math.sign(bx) * (HALF_W - 0.65),
        z: Math.sign(bz || 1) * (HALF_D - 0.65),
      };
    }
    return {
      type: 'goal_kick',
      team: defendingSide,
      x: Math.sign(bx) * (HALF_W - 5.5),
      z: Math.sign(bz || 1) * 4.5,
    };
  }
  return null;
}

export function isInsidePenaltyBox(attackerSide: 'home' | 'away', x: number, z: number): boolean {
  if (Math.abs(z) > PEN_BOX_HALF_Z) return false;
  return attackerSide === 'home' ? x >= PEN_BOX_X : x <= -PEN_BOX_X;
}
