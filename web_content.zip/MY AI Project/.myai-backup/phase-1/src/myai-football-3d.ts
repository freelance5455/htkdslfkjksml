import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { StadiumAudioEngine, TurfParticlePool } from './football/audioAndParticles';
import {
  createAthleticGeometries,
  createDefaultPose,
  dampPose,
  makeFaceSkinTexture,
  makeKitFabricTexture,
  type PoseChannels,
} from './football/materialsAndRig';
import {
  BALL_R,
  classifyBoundaryExit,
  evaluateOffside,
  FORMATIONS,
  getDifficultyFactors,
  GOAL_DEPTH,
  GOAL_H,
  GOAL_HALF_W,
  GOAL_W,
  HALF_D,
  HALF_W,
  isInsidePenaltyBox,
  PITCH_D,
  PITCH_W,
  type DifficultyKey,
  type FormationKey,
  type GkTier,
  type StrengthTier,
} from './football/matchRulesAndAi';

interface TeamInfo {
  id: string;
  name: string;
  nameEn: string;
  league: string;
  country: string;
  primary: string;
  secondary: string;
  ovr: number;
  formation: string;
}

export interface Stats15 {
  speed: number;
  acceleration: number;
  agility: number;
  balance: number;
  staminaStat: number;
  shotPower: number;
  shotAccuracy: number;
  passAccuracy: number;
  vision: number;
  dribbling: number;
  physical: number;
  tackling: number;
  positioning: number;
  defending: number;
  gkReflexes: number;
}

interface SquadMember {
  id?: string;
  name: string;
  pos?: string;
  role: string;
  ovr: number;
  pac: number;
  sho: number;
  pas: number;
  dri: number;
  def: number;
  phy?: number;
  stam?: number;
  heightCm?: number;
  weightKg?: number;
  stats15?: Stats15;
  jerseyNo: number;
  skinHex: string;
  hairHex: string;
  hairStyle?: 'short' | 'fade' | 'curly' | 'long';
  bootColor?: string;
  skillMoves?: number;
  weakFoot?: number;
}

interface ControlPreset {
  id: string;
  name: string;
  joySize: number;
  btnSize: number;
  opacity: number;
  sensitivity: number;
  offsetX: number;
  offsetY: number;
}

interface TacticsConfig {
  formation: string;
  attackStyle: 'balanced' | 'possession' | 'counter' | 'all_out';
  defenseStyle: 'balanced' | 'high_press' | 'deep_block';
  defenseLine: number;
  pressIntensity: number;
  buildUpSpeed: number;
  instructions?: Record<number, 'balanced' | 'push_forward' | 'stay_back' | 'free_roam'>;
}

declare global {
  interface Window {
    MYAI_PLAYERS_DB?: {
      TEAMS: TeamInfo[];
      getTeamLineupForMatch: (teamId: string) => { team: TeamInfo; squad: SquadMember[] };
    };
    MYAIFootballHub?: {
      openHub: (tab?: string) => void;
      getActiveMatchPayload: (ov?: any) => any;
      recordMatchOutcome: (summary: any) => void;
    };
    MYAISound?: {
      click?: () => void;
      kick?: () => void;
      bounce?: () => void;
      post?: () => void;
      whistle?: () => void;
      goal?: () => void;
      fanfare?: () => void;
      coin?: () => void;
      correct?: () => void;
    };
    myaiApiFetch?: (url: string, options?: RequestInit & { timeoutMs?: number }) => Promise<any>;
    notify?: (msg: string) => void;
    escapeHTML?: (s: string) => string;
    myaiOpenFootball3D?: (opts?: Record<string, unknown>) => void;
    closeFeature?: () => void;
  }
}

type QualityKey = 'low' | 'medium' | 'high' | 'ultra';
type LightingKey = 'night' | 'day';
type CameraModeKey = 'broadcast' | 'dynamic' | 'close' | 'wide' | 'tele' | 'focus';
type OppStyleKey = 'متوازن' | 'استحواذ' | 'مرتدات' | 'ضغط عالٍ';
type AssistLevel = 'يدوي' | 'شبه مساعد' | 'مساعد كامل';

interface MatchConfig {
  homeTeamId: string;
  awayTeamId: string;
  homeTeam?: TeamInfo;
  awayTeam?: TeamInfo;
  homeSquad?: SquadMember[];
  homeBench?: SquadMember[];
  awaySquad?: SquadMember[];
  tactics?: TacticsConfig;
  controlPreset?: ControlPreset;
  formation: FormationKey;
  halfSeconds: number;
  difficulty: DifficultyKey;
  lighting: LightingKey;
  quality: QualityKey;
  camera: CameraModeKey;
  cameraZoom: number;
  gameSpeed: 'relaxed' | 'normal' | 'fast';
  opponentStrength: StrengthTier;
  gkLevel: GkTier;
  opponentStyle: OppStyleKey;
  controlAssist: AssistLevel;
  careerMode?: 'player' | 'manager' | null;
  proSlotIdx?: number;
}

interface PlayerEntity {
  id: string;
  side: 'home' | 'away';
  idx: number;
  info: SquadMember;
  s15: Stats15;
  heightCm: number;
  scaleFactor: number;
  baseX: number;
  baseZ: number;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  facing: number;
  bankAngle: number;
  stamina: number;
  yellowCards: number;
  sentOff: boolean;
  isGk: boolean;
  kickAnim: number;
  kickSide: 1 | -1;
  tackleTimer: number;
  tackleCooldown: number;
  stumbleTimer: number;
  skillTimer: number;
  headerTimer: number;
  diveTimer: number;
  diveDir: number;
  dribbleStepTimer: number;
  aiThinkTimer: number;
  aiDecisionCooldown: number;
  stridePhase: number;
  pose: PoseChannels;
  group: THREE.Group;
  pelvis: THREE.Group;
  torso: THREE.Group;
  headGroup: THREE.Group;
  leftHip: THREE.Group;
  leftKnee: THREE.Group;
  rightHip: THREE.Group;
  rightKnee: THREE.Group;
  leftShoulder: THREE.Group;
  leftElbow: THREE.Group;
  rightShoulder: THREE.Group;
  rightElbow: THREE.Group;
  numberBadge: THREE.Mesh;
}

interface NetMeshRecord {
  mesh: THREE.Mesh;
  restPos: Float32Array;
  side: number;
}

interface PendingPassCheck {
  passerSide: 'home' | 'away';
  ballXAtKick: number;
  receiverId: string;
  expiresAt: number;
}

const CAMERA_LABELS: Record<CameraModeKey, string> = {
  broadcast: 'بث تلفزيوني',
  dynamic: 'ديناميكية',
  close: 'قريبة',
  wide: 'واسعة',
  tele: 'علوية',
  focus: 'تركيز اللاعب',
};
const CAMERA_ORDER: CameraModeKey[] = ['broadcast', 'dynamic', 'close', 'wide', 'tele', 'focus'];
const ALL_FORMATIONS: FormationKey[] = ['4-3-3', '4-2-3-1', '4-4-2', '3-5-2', '5-3-2'];

// Reusable temp vectors/quaternions (Zero GC inside frame loop)
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _qStep = new THREE.Quaternion();
const _dummyObj = new THREE.Object3D();
const _poseTarget = createDefaultPose();

function resolveStats15(m: SquadMember): Stats15 {
  if (m.stats15 && typeof m.stats15.speed === 'number') return m.stats15;
  const ovr = m.ovr || 78;
  const pac = m.pac || ovr;
  const sho = m.sho || ovr;
  const pas = m.pas || ovr;
  const dri = m.dri || ovr;
  const def = m.def || 60;
  const phy = m.phy || 74;
  const isGk = m.role === 'GK' || (m.pos || '').includes('حارس');
  return {
    speed: pac,
    acceleration: Math.min(99, pac + 1),
    agility: Math.round(dri * 0.65 + pac * 0.35),
    balance: Math.round(dri * 0.5 + phy * 0.45),
    staminaStat: m.stam || Math.round(phy * 0.55 + pac * 0.4),
    shotPower: Math.round(sho * 0.7 + phy * 0.3),
    shotAccuracy: sho,
    passAccuracy: pas,
    vision: Math.round(pas * 0.75 + ovr * 0.22),
    dribbling: dri,
    physical: phy,
    tackling: Math.round(def * 0.8 + phy * 0.2),
    positioning: Math.round(ovr * 0.6 + (isGk ? ovr : sho) * 0.35),
    defending: def,
    gkReflexes: isGk ? Math.min(99, ovr + 3) : 24,
  };
}

function detectSoftwareGl(): boolean {
  try {
    const c = document.createElement('canvas');
    const gl = (c.getContext('webgl2') || c.getContext('webgl')) as WebGLRenderingContext | null;
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      const r = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
      if (/SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(r)) return true;
    }
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return false;
  } catch {
    return true;
  }
}

function escHtml(v: unknown): string {
  if (typeof window.escapeHTML === 'function') return window.escapeHTML(String(v ?? ''));
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));
}

function sfx(name: keyof NonNullable<Window['MYAISound']>): void {
  try {
    window.MYAISound?.[name]?.();
  } catch {
    // ignore
  }
}

function makeJerseyBadgeTexture(jerseyNo: number, textColor: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 96;
  c.height = 96;
  const ctx = c.getContext('2d')!;
  ctx.clearRect(0, 0, 96, 96);
  ctx.fillStyle = textColor;
  ctx.strokeStyle = 'rgba(0,0,0,0.82)';
  ctx.lineWidth = 6;
  ctx.font = '900 54px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const txt = String(jerseyNo || 10);
  ctx.strokeText(txt, 48, 50);
  ctx.fillText(txt, 48, 50);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeAdBoardTexture(homeName: string, awayName: string): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 96;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 1024, 0);
  grad.addColorStop(0, '#120408');
  grad.addColorStop(0.25, '#8f0018');
  grad.addColorStop(0.5, '#0b0b12');
  grad.addColorStop(0.75, '#b8001f');
  grad.addColorStop(1, '#120408');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1024, 96);

  ctx.strokeStyle = '#ff384f';
  ctx.lineWidth = 4;
  ctx.strokeRect(2, 2, 1020, 92);

  ctx.fillStyle = '#ffffff';
  ctx.font = '900 32px Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(`MY AI STADIUM PRO   ★   ${homeName}  VS  ${awayName}   ★   MY AI SPORTS`, 512, 48);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.repeat.set(2, 1);
  return tex;
}

function makePitchTexture(highRes: boolean): THREE.CanvasTexture {
  const w = highRes ? 2048 : 1024;
  const h = highRes ? 1360 : 680;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  const sc = w / 1024;

  const stripes = 18;
  const sw = w / stripes;
  for (let i = 0; i < stripes; i++) {
    ctx.fillStyle = i % 2 === 0 ? '#155825' : '#1b6d2e';
    ctx.fillRect(i * sw, 0, sw + 1, h);
  }
  const hStripes = 10;
  const sh = h / hStripes;
  for (let r = 0; r < hStripes; r++) {
    if (r % 2 === 0) {
      ctx.fillStyle = 'rgba(255,255,255,0.025)';
      ctx.fillRect(0, r * sh, w, sh);
    }
  }

  for (let i = 0; i < (highRes ? 5600 : 1800); i++) {
    const gx = (i * 193 + (i % 7) * 29) % w;
    const gy = (i * 131 + (i % 5) * 41) % h;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(10,36,14,0.19)' : 'rgba(125,215,125,0.09)';
    ctx.fillRect(gx, gy, 2 * sc, 2 * sc);
  }

  const m = 24 * sc;
  const pw = w - m * 2;
  const ph = h - m * 2;
  const wearGradL = ctx.createRadialGradient(m + 42 * sc, h / 2, 10 * sc, m + 42 * sc, h / 2, 110 * sc);
  wearGradL.addColorStop(0, 'rgba(62,56,28,0.22)');
  wearGradL.addColorStop(1, 'rgba(62,56,28,0)');
  ctx.fillStyle = wearGradL;
  ctx.fillRect(m, h / 2 - 120 * sc, 160 * sc, 240 * sc);

  const wearGradR = ctx.createRadialGradient(w - m - 42 * sc, h / 2, 10 * sc, w - m - 42 * sc, h / 2, 110 * sc);
  wearGradR.addColorStop(0, 'rgba(62,56,28,0.22)');
  wearGradR.addColorStop(1, 'rgba(62,56,28,0)');
  ctx.fillStyle = wearGradR;
  ctx.fillRect(w - m - 160 * sc, h / 2 - 120 * sc, 160 * sc, 240 * sc);

  ctx.strokeStyle = 'rgba(248,252,250,0.92)';
  ctx.lineWidth = 4 * sc;
  ctx.strokeRect(m, m, pw, ph);

  ctx.beginPath();
  ctx.moveTo(w / 2, m);
  ctx.lineTo(w / 2, h - m);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(w / 2, h / 2, 86 * sc, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, 5.5 * sc, 0, Math.PI * 2);
  ctx.fill();

  const penW = pw * 0.16;
  const penH = ph * 0.58;
  const sixW = pw * 0.055;
  const sixH = ph * 0.27;
  ctx.strokeRect(m, h / 2 - penH / 2, penW, penH);
  ctx.strokeRect(m, h / 2 - sixH / 2, sixW, sixH);
  ctx.strokeRect(w - m - penW, h / 2 - penH / 2, penW, penH);
  ctx.strokeRect(w - m - sixW, h / 2 - sixH / 2, sixW, sixH);

  ctx.beginPath();
  ctx.arc(m + pw * 0.11, h / 2, 4 * sc, 0, Math.PI * 2);
  ctx.arc(w - m - pw * 0.11, h / 2, 4 * sc, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.arc(m + pw * 0.11, h / 2, 68 * sc, -0.7, 0.7);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(w - m - pw * 0.11, h / 2, 68 * sc, Math.PI - 0.7, Math.PI + 0.7);
  ctx.stroke();

  const cr = 18 * sc;
  [
    [m, m, 0, Math.PI / 2],
    [w - m, m, Math.PI / 2, Math.PI],
    [w - m, h - m, Math.PI, Math.PI * 1.5],
    [m, h - m, Math.PI * 1.5, Math.PI * 2],
  ].forEach(([cx, cy, a0, a1]) => {
    ctx.beginPath();
    ctx.arc(cx, cy, cr, a0, a1);
    ctx.stroke();
  });

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeBallTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 256;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, c.width, c.height);

  const cols = 8;
  const rows = 4;
  for (let r = 0; r < rows; r++) {
    for (let col = 0; col < cols; col++) {
      const cx = (col + 0.5) * (c.width / cols);
      const cy = (r + 0.5) * (c.height / rows);
      if ((r + col) % 2 === 0) {
        ctx.fillStyle = '#111827';
        ctx.beginPath();
        for (let k = 0; k < 5; k++) {
          const ang = (k / 5) * Math.PI * 2 - Math.PI / 2;
          const x = cx + Math.cos(ang) * 24;
          const y = cy + Math.sin(ang) * 24;
          if (k === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.strokeStyle = '#dc2626';
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(cx, cy, 18, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

class Football3DEngine {
  private container: HTMLElement;
  private cfg: MatchConfig;
  private onMatchEnd: (summary: any) => void;
  private onExit: () => void;

  private isSoftwareGl: boolean;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private pmremGenerator!: THREE.PMREMGenerator;
  private envRenderTarget: THREE.WebGLRenderTarget | null = null;
  private disposables: Array<{ dispose: () => void }> = [];
  private audio: StadiumAudioEngine;
  private turfParticles!: TurfParticlePool;

  private homeTeam!: TeamInfo;
  private awayTeam!: TeamInfo;
  private homeBench: SquadMember[] = [];
  private players: PlayerEntity[] = [];
  private activeHomeIdx = 9;
  private activeAwayIdx = 9;
  private carrier: PlayerEntity | null = null;
  private lastTouchSide: 'home' | 'away' = 'home';
  private lastTouchHomePlayer: PlayerEntity | null = null;
  private prevTouchHomePlayer: PlayerEntity | null = null;
  private lastTouchPlayer: PlayerEntity | null = null;
  private pendingPass: PendingPassCheck | null = null;

  private ballMesh!: THREE.Mesh;
  private ballShadow!: THREE.Mesh;
  private activeRing!: THREE.Mesh;
  private passRing!: THREE.Mesh;
  private crowdMesh: THREE.InstancedMesh | null = null;
  private crowdBaseData: Array<{ x: number; y: number; z: number; phase: number }> = [];
  private crowdWaveTimer = 0;
  private netRecords: NetMeshRecord[] = [];
  private netImpactTimer = 0;
  private netImpactSide = 1;

  private ballPos = new THREE.Vector3(0, BALL_R, 0);
  private ballVel = new THREE.Vector3(0, 0, 0);
  private ballSpinZ = 0;
  private ballTopSpin = 0;
  private camPos = new THREE.Vector3(0, 10.8, 20.6);
  private camTarget = new THREE.Vector3(0, 1.05, 0);
  private cameraZoom = 1.0;

  private half = 1;
  private matchClock = 0;
  private homeGoals = 0;
  private awayGoals = 0;
  private phase: 'kickoff' | 'playing' | 'goal' | 'halftime' | 'fulltime' = 'kickoff';
  private phaseTimer = 0.85;
  private paused = false;
  private destroyed = false;
  private cameraMode: CameraModeKey = 'broadcast';
  private liveTacticPosture: 'def' | 'bal' | 'att' = 'bal';
  private liveFormation: FormationKey = '4-3-3';
  private goalScorerFocus: PlayerEntity | null = null;

  private homePossTime = 0;
  private awayPossTime = 0;
  private homeShots = 0;
  private homeShotsOnTarget = 0;
  private homePasses = 0;
  private homeFouls = 0;
  private awayFouls = 0;
  private proGoals = 0;
  private proAssists = 0;
  private scorers: Array<{ playerId?: string; name: string }> = [];

  private keys = new Set<string>();
  private joyVec = { x: 0, z: 0, active: false };
  private joyPointerId: number | null = null;
  private sprintHeld = false;
  private pressHeld = false;
  private shootCharging = false;
  private shootCharge = 0;
  private passCharging = false;
  private passCharge = 0;
  private benchUsed = 0;
  private selectedSubStarterIdx: number | null = null;

  private rafId: number | null = null;
  private timerId: number | null = null;
  private lastTick = 0;

  private scoreEl: HTMLElement | null = null;
  private clockEl: HTMLElement | null = null;
  private halfEl: HTMLElement | null = null;
  private playerLabelEl: HTMLElement | null = null;
  private staminaFillEl: HTMLElement | null = null;
  private bannerEl: HTMLElement | null = null;
  private commEl: HTMLElement | null = null;
  private shootCircleEl: SVGCircleElement | null = null;
  private offenseBtnsEl: HTMLElement | null = null;
  private defenseBtnsEl: HTMLElement | null = null;
  private radarCtx: CanvasRenderingContext2D | null = null;

  constructor(
    container: HTMLElement,
    cfg: MatchConfig,
    onMatchEnd: Football3DEngine['onMatchEnd'],
    onExit: () => void,
  ) {
    this.container = container;
    this.cfg = cfg;
    this.cameraMode = cfg.camera || 'broadcast';
    this.cameraZoom = THREE.MathUtils.clamp(Number(cfg.cameraZoom || 1.0), 0.7, 1.35);
    this.liveFormation = cfg.formation || '4-3-3';
    this.onMatchEnd = onMatchEnd;
    this.onExit = onExit;
    this.isSoftwareGl = detectSoftwareGl();
    this.audio = new StadiumAudioEngine(false, 0.72);

    const db = window.MYAI_PLAYERS_DB;
    const homeFallback = db?.getTeamLineupForMatch(cfg.homeTeamId) || this.fallbackLineup('MY AI يونايتد', '#ff142e', '#111111');
    const awayFallback = db?.getTeamLineupForMatch(cfg.awayTeamId) || this.fallbackLineup('ريال مدريد', '#f4f4f5', '#d4af37');
    this.homeTeam = cfg.homeTeam || homeFallback.team;
    this.awayTeam = cfg.awayTeam || awayFallback.team;
    const homeSquad = cfg.homeSquad?.length ? cfg.homeSquad : homeFallback.squad;
    const awaySquad = cfg.awaySquad?.length ? cfg.awaySquad : awayFallback.squad;
    this.homeBench = cfg.homeBench?.length ? cfg.homeBench : homeSquad.slice(0, 5);

    this.buildDomHud();
    this.initThree(homeSquad, awaySquad);
    this.bindInputs();
    this.resetKickoff('home');
    this.setCommentary(`🎙️ صافرة البداية! ${this.homeTeam.name} × ${this.awayTeam.name}`);
    sfx('whistle');

    this.lastTick = performance.now();
    this.scheduleLoop();
  }

  private fallbackLineup(name: string, primary: string, secondary: string) {
    const team: TeamInfo = { id: 'custom', name, nameEn: name, league: 'custom', country: 'MY AI', primary, secondary, ovr: 82, formation: '4-3-3' };
    const squad: SquadMember[] = Array.from({ length: 11 }, (_, i) => ({
      id: `fb_${i}`,
      name: `${name} #${i + 1}`,
      role: i === 0 ? 'GK' : 'OUT',
      ovr: 80,
      pac: 80,
      sho: 78,
      pas: 79,
      dri: 79,
      def: 76,
      phy: 76,
      heightCm: i === 0 ? 191 : 178 + (i % 7),
      weightKg: 75 + (i % 6),
      jerseyNo: i + 1,
      skinHex: '#cfa17d',
      hairHex: '#181414',
      hairStyle: 'short',
      bootColor: '#ff263f',
    }));
    return { team, squad };
  }

  private buildDomHud(): void {
    const cp = this.cfg.controlPreset || {
      id: 'pro_arc',
      name: 'قياسي',
      joySize: 112,
      btnSize: 62,
      opacity: 88,
      sensitivity: 100,
      offsetX: 0,
      offsetY: 0,
    };
    const ctrlStyle = `opacity:${((cp.opacity || 88) / 100).toFixed(2)};--f3d-joy-size:${cp.joySize || 112}px;--f3d-btn-size:${cp.btnSize || 62}px;--f3d-offset-x:${cp.offsetX || 0}px;--f3d-offset-y:${cp.offsetY || 0}px;`;

    this.container.innerHTML = `
      <div class="myai-f3d-stage" id="myaiF3dCanvasHost"></div>

      <div class="myai-f3d-topbar">
        <div class="myai-f3d-scorecard">
          <span class="team-pill" style="border-color:${escHtml(this.homeTeam.primary)}">${escHtml(this.homeTeam.name)}</span>
          <strong id="f3dScoreText">0 - 0</strong>
          <span class="team-pill" style="border-color:${escHtml(this.awayTeam.primary)}">${escHtml(this.awayTeam.name)}</span>
          <span class="clock-pill"><b id="f3dHalfText">الشوط 1</b> · <span id="f3dClockText">00'</span></span>
        </div>

        <div class="myai-f3d-quicktactic" id="f3dQuickTacticBar">
          <button type="button" data-posture="def">🛡️ دفاع</button>
          <button type="button" data-posture="bal" class="active">⚖️ توازن</button>
          <button type="button" data-posture="att">🔥 هجوم</button>
        </div>

        <div class="myai-f3d-topactions">
          <button type="button" id="f3dSoundBtn" title="صوت الملعب">🔊</button>
          <button type="button" id="f3dZoomOutBtn" title="إبعاد الكاميرا">🔍−</button>
          <button type="button" id="f3dZoomInBtn" title="تقريب الكاميرا">🔍+</button>
          <button type="button" id="f3dCamBtn">🎥 ${CAMERA_LABELS[this.cameraMode]}</button>
          <button type="button" id="f3dPauseBtn">⏸ المدرب</button>
          <button type="button" id="f3dExitBtn">✕</button>
        </div>
      </div>

      <div class="myai-f3d-comm" id="f3dCommText">🎙️ الأجواء مشتعلة في ملعب MY AI PRO</div>

      <div class="myai-f3d-playerbar">
        <span id="f3dPlayerLabel">${escHtml(this.homeTeam.name)} · #10</span>
        <div class="myai-f3d-stamina"><div id="f3dStaminaFill" style="width:100%"></div></div>
      </div>

      <div class="myai-f3d-rotate-tip" id="f3dRotateTip">
        <span>📱 أدر الهاتف أفقيًا (Landscape) لتجربة PES/FC كاملة</span>
        <button type="button" class="myai-mini-btn" id="f3dForceLandBtn">تدوير الآن</button>
      </div>

      <div class="myai-f3d-banner" id="f3dBanner" style="display:none"></div>

      <div class="myai-f3d-radar-wrap">
        <canvas id="f3dRadarCanvas" width="156" height="98"></canvas>
      </div>

      <div class="myai-f3d-controls" style="${ctrlStyle}">
        <div class="myai-f3d-joy-zone" id="f3dJoyZone">
          <div class="myai-f3d-joy-base">
            <div class="myai-f3d-joy-knob" id="f3dJoyKnob"></div>
          </div>
        </div>

        <div class="myai-f3d-action-pad">
          <div id="f3dOffenseBtns" class="myai-f3d-arc-cluster">
            <button type="button" class="f3d-cbtn pos-main f3d-shoot" id="f3dShootBtn">
              <svg class="f3d-charge-ring" viewBox="0 0 80 80"><circle id="f3dShootRing" cx="40" cy="40" r="35"/></svg>
              <span class="cico">⚡</span><span class="clbl">تسديد</span>
            </button>
            <button type="button" class="f3d-cbtn pos-left f3d-pass" id="f3dPassBtn"><span class="cico">🎯</span><span class="clbl">تمرير</span></button>
            <button type="button" class="f3d-cbtn pos-diag f3d-lob" id="f3dThroughBtn"><span class="cico">🪽</span><span class="clbl">بينية</span></button>
            <button type="button" class="f3d-cbtn pos-top f3d-lob" id="f3dCrossBtn"><span class="cico">⤴️</span><span class="clbl">عرضية</span></button>
            <button type="button" class="f3d-cbtn pos-sprint f3d-sprint" id="f3dSprintBtn"><span class="cico">🏃</span><span class="clbl">سرعة</span></button>
            <button type="button" class="f3d-cbtn pos-skill f3d-skill" id="f3dSkillBtn"><span class="cico">✨</span><span class="clbl">مهارة</span></button>
          </div>

          <div id="f3dDefenseBtns" class="myai-f3d-arc-cluster" style="display:none">
            <button type="button" class="f3d-cbtn pos-main f3d-tackle" id="f3dTackleBtn"><span class="cico">🦵</span><span class="clbl">افتكاك</span></button>
            <button type="button" class="f3d-cbtn pos-left f3d-press" id="f3dPressBtn"><span class="cico">🛡️</span><span class="clbl">ضغط</span></button>
            <button type="button" class="f3d-cbtn pos-top f3d-switch" id="f3dSwitchBtn"><span class="cico">🔄</span><span class="clbl">تبديل</span></button>
            <button type="button" class="f3d-cbtn pos-sprint f3d-sprint" id="f3dSprintDefBtn"><span class="cico">🏃</span><span class="clbl">سرعة</span></button>
          </div>

          <div class="myai-f3d-kbd-hint">⌨️ WASD / الأسهم · J تمرير · K تسديد · L بينية · U عرضية · E مهارة · Shift سرعة · Q تبديل</div>
        </div>
      </div>

      <div class="myai-f3d-pause" id="f3dPauseModal" style="display:none">
        <div class="myai-f3d-pause-card">
          <h3>⏸ لوحة المدرب والتكتيكات الحية</h3>
          <p>${escHtml(this.homeTeam.name)} ${this.homeGoals} - ${this.awayGoals} ${escHtml(this.awayTeam.name)}</p>
          <div style="font-size:12px;margin-bottom:2px"><b>♟️ تغيير الخطة مباشرة:</b></div>
          <div class="myai-f3d-coach-form" id="f3dCoachFormBar"></div>
          <div id="f3dPauseSubsBox" style="text-align:right"></div>
          <button type="button" class="primary" id="f3dResumeBtn">▶ استكمال المباراة</button>
          <button type="button" class="myai-v3-btn" id="f3dCycleCamPause">🎥 تغيير زاوية الكاميرا</button>
          <button type="button" class="myai-v3-btn" id="f3dEndNowBtn">🏁 إنهاء المباراة الآن</button>
        </div>
      </div>
    `;

    this.scoreEl = document.getElementById('f3dScoreText');
    this.clockEl = document.getElementById('f3dClockText');
    this.halfEl = document.getElementById('f3dHalfText');
    this.playerLabelEl = document.getElementById('f3dPlayerLabel');
    this.staminaFillEl = document.getElementById('f3dStaminaFill');
    this.bannerEl = document.getElementById('f3dBanner');
    this.commEl = document.getElementById('f3dCommText');
    this.shootCircleEl = document.getElementById('f3dShootRing') as unknown as SVGCircleElement | null;
    this.offenseBtnsEl = document.getElementById('f3dOffenseBtns');
    this.defenseBtnsEl = document.getElementById('f3dDefenseBtns');
    const radarCanvas = document.getElementById('f3dRadarCanvas') as HTMLCanvasElement | null;
    this.radarCtx = radarCanvas ? radarCanvas.getContext('2d') : null;
  }

  private setCommentary(msg: string): void {
    if (this.commEl) this.commEl.textContent = msg;
  }

  private applyFormationToTeam(side: 'home' | 'away', formation: FormationKey): void {
    const pts = FORMATIONS[formation] || FORMATIONS['4-3-3'];
    const sign = side === 'home' ? 1 : -1;
    for (const p of this.players) {
      if (p.side !== side) continue;
      const pt = pts[p.idx] || pts[0];
      p.baseX = pt[0] * sign;
      p.baseZ = pt[1] * sign;
    }
  }

  private renderPauseSubs(): void {
    const formBar = document.getElementById('f3dCoachFormBar');
    if (formBar) {
      formBar.innerHTML = ALL_FORMATIONS.map(
        (f) => `<button type="button" class="${this.liveFormation === f ? 'active' : ''}" data-live-form="${f}">${f}</button>`,
      ).join('');
      formBar.querySelectorAll<HTMLButtonElement>('[data-live-form]').forEach((btn) => {
        btn.onclick = () => {
          const nextForm = (btn.getAttribute('data-live-form') as FormationKey) || '4-3-3';
          this.liveFormation = nextForm;
          this.applyFormationToTeam('home', nextForm);
          this.setCommentary(`♟️ المدرب يغيّر خطة اللعب إلى ${nextForm}`);
          sfx('click');
          this.renderPauseSubs();
        };
      });
    }

    const box = document.getElementById('f3dPauseSubsBox');
    if (!box) return;
    const homeOutfield = this.players.filter((p) => p.side === 'home' && !p.isGk && !p.sentOff);
    box.innerHTML = `
      <div style="font-size:12px;margin-bottom:6px"><b>🔄 التبديلات الحية</b> (المستخدم: ${this.benchUsed}/5)</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;max-height:155px;overflow:auto">
        <div>
          <small style="color:#facc15">اختر لاعبًا يخرج:</small>
          ${homeOutfield.map((p) => `<button type="button" class="myai-mini-btn ${this.selectedSubStarterIdx === p.idx ? 'primary-mini' : ''}" style="width:100%;margin:2px 0;font-size:11px" data-sub-out="${p.idx}">#${p.info.jerseyNo} ${escHtml(p.info.name.split(' ')[0])} (${Math.round(p.stamina)}%)</button>`).join('')}
        </div>
        <div>
          <small style="color:#38bdf8">بديل يدخل الملعب:</small>
          ${this.homeBench.map((b, bi) => `<button type="button" class="myai-mini-btn" style="width:100%;margin:2px 0;font-size:11px" data-sub-in="${bi}">#${b.jerseyNo} ${escHtml(b.name.split(' ')[0])} (${b.ovr})</button>`).join('')}
        </div>
      </div>
    `;
    box.querySelectorAll<HTMLButtonElement>('[data-sub-out]').forEach((btn) => {
      btn.onclick = () => {
        this.selectedSubStarterIdx = Number(btn.getAttribute('data-sub-out'));
        this.renderPauseSubs();
      };
    });
    box.querySelectorAll<HTMLButtonElement>('[data-sub-in]').forEach((btn) => {
      btn.onclick = () => {
        if (this.benchUsed >= 5) {
          window.notify?.('استنفدت التبديلات الخمسة المتاحة.');
          return;
        }
        const bi = Number(btn.getAttribute('data-sub-in'));
        const targetIdx = this.selectedSubStarterIdx ?? this.activeHomeIdx;
        const fieldPlayer = this.players.find((p) => p.side === 'home' && p.idx === targetIdx);
        const subInfo = this.homeBench[bi];
        if (!fieldPlayer || !subInfo) return;
        const outgoing = fieldPlayer.info;
        fieldPlayer.info = { ...subInfo, role: outgoing.role };
        fieldPlayer.s15 = resolveStats15(fieldPlayer.info);
        fieldPlayer.stamina = 100;
        this.homeBench[bi] = outgoing;
        const badgeMat = fieldPlayer.numberBadge.material as THREE.MeshBasicMaterial;
        const nextTex = this.track(makeJerseyBadgeTexture(subInfo.jerseyNo, this.homeTeam.secondary || '#ffffff'));
        badgeMat.map = nextTex;
        badgeMat.needsUpdate = true;
        this.benchUsed++;
        this.selectedSubStarterIdx = null;
        sfx('correct');
        this.setCommentary(`🔄 تبديل في صفوف ${this.homeTeam.name}: دخول ${subInfo.name}`);
        this.renderPauseSubs();
      };
    });
  }

  private getCameraFov(): number {
    switch (this.cameraMode) {
      case 'broadcast':
        return 33;
      case 'dynamic':
        return 35;
      case 'close':
        return 37;
      case 'wide':
        return 38;
      case 'tele':
        return 38;
      default:
        return 40;
    }
  }

  private initThree(homeSquad: SquadMember[], awaySquad: SquadMember[]): void {
    const host = document.getElementById('myaiF3dCanvasHost') || this.container;
    const w = host.clientWidth || window.innerWidth;
    const h = host.clientHeight || window.innerHeight;
    const q = this.cfg.quality;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && q !== 'low',
      powerPreference: 'high-performance',
    });
    const dprCap = q === 'ultra' ? 2.0 : q === 'high' ? 1.65 : q === 'medium' ? 1.3 : 1.0;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, dprCap));
    this.renderer.setSize(w, h);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.cfg.lighting === 'night' ? 1.2 : 1.06;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl && (q === 'high' || q === 'ultra');
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const isNight = this.cfg.lighting === 'night';
    this.scene.background = new THREE.Color(isNight ? '#050812' : '#7eb7eb');
    this.scene.fog = new THREE.Fog(isNight ? '#060b16' : '#9cc8ed', 98, 225);

    this.camera = new THREE.PerspectiveCamera(this.getCameraFov(), w / h, 0.4, 280);
    this.camera.position.copy(this.camPos);

    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.envRenderTarget = this.pmremGenerator.fromScene(roomEnv, 0.04);
    this.scene.environment = this.envRenderTarget.texture;
    roomEnv.dispose();

    const hemi = new THREE.HemisphereLight(isNight ? '#c8daff' : '#ffffff', isNight ? '#13281b' : '#1b4724', isNight ? 0.96 : 1.22);
    this.scene.add(hemi);

    const keySun = new THREE.DirectionalLight(isNight ? '#f4f8ff' : '#fff8e8', isNight ? 1.75 : 2.2);
    keySun.position.set(24, 52, 34);
    if (this.renderer.shadowMap.enabled) {
      keySun.castShadow = true;
      const smSize = q === 'ultra' ? 2048 : 1024;
      keySun.shadow.mapSize.set(smSize, smSize);
      keySun.shadow.bias = -0.0005;
      keySun.shadow.normalBias = 0.02;
      keySun.shadow.camera.left = -62;
      keySun.shadow.camera.right = 62;
      keySun.shadow.camera.top = 44;
      keySun.shadow.camera.bottom = -44;
    }
    this.scene.add(keySun);

    const rimLight = new THREE.DirectionalLight(isNight ? '#93c5fd' : '#e0f2fe', isNight ? 0.65 : 0.45);
    rimLight.position.set(-28, 30, -34);
    this.scene.add(rimLight);

    this.turfParticles = new TurfParticlePool(this.scene, q === 'ultra' ? 140 : 90);
    this.buildStadium();
    this.buildGoals();
    this.buildBallAndMarkers();
    this.buildTeams(homeSquad, awaySquad);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }
  }

  private track<T extends { dispose: () => void }>(item: T): T {
    this.disposables.push(item);
    return item;
  }

  private buildStadium(): void {
    const q = this.cfg.quality;
    const highResGrass = q === 'high' || q === 'ultra';
    const pitchTex = this.track(makePitchTexture(highResGrass));
    pitchTex.anisotropy = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
    const pitchGeo = this.track(new THREE.PlaneGeometry(PITCH_W, PITCH_D));
    const pitchMat = this.track(new THREE.MeshStandardMaterial({ map: pitchTex, roughness: 0.88, metalness: 0.02 }));
    const pitch = new THREE.Mesh(pitchGeo, pitchMat);
    pitch.rotation.x = -Math.PI / 2;
    pitch.receiveShadow = true;
    this.scene.add(pitch);

    const apronGeo = this.track(new THREE.PlaneGeometry(PITCH_W + 36, PITCH_D + 32));
    const apronMat = this.track(new THREE.MeshStandardMaterial({ color: '#11181f', roughness: 0.92 }));
    const apron = new THREE.Mesh(apronGeo, apronMat);
    apron.rotation.x = -Math.PI / 2;
    apron.position.y = -0.025;
    apron.receiveShadow = true;
    this.scene.add(apron);

    const trackGeo = this.track(new THREE.PlaneGeometry(PITCH_W + 9, PITCH_D + 7.5));
    const trackMat = this.track(new THREE.MeshStandardMaterial({ color: '#144421', roughness: 0.9 }));
    const trackMesh = new THREE.Mesh(trackGeo, trackMat);
    trackMesh.rotation.x = -Math.PI / 2;
    trackMesh.position.y = -0.012;
    trackMesh.receiveShadow = true;
    this.scene.add(trackMesh);

    const flagPoleGeo = this.track(new THREE.CylinderGeometry(0.035, 0.035, 1.45, 6));
    const flagClothGeo = this.track(new THREE.PlaneGeometry(0.45, 0.3));
    const flagPoleMat = this.track(new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.4 }));
    const flagClothMat = this.track(new THREE.MeshStandardMaterial({ color: '#ff263f', side: THREE.DoubleSide, roughness: 0.7 }));
    [
      [-HALF_W, -HALF_D],
      [HALF_W, -HALF_D],
      [-HALF_W, HALF_D],
      [HALF_W, HALF_D],
    ].forEach(([fx, fz]) => {
      const pole = new THREE.Mesh(flagPoleGeo, flagPoleMat);
      pole.position.set(fx, 0.72, fz);
      const cloth = new THREE.Mesh(flagClothGeo, flagClothMat);
      cloth.position.set(fx + (fx < 0 ? 0.22 : -0.22), 1.28, fz);
      this.scene.add(pole, cloth);
    });

    const adTex = this.track(makeAdBoardTexture(this.homeTeam.nameEn || this.homeTeam.name, this.awayTeam.nameEn || this.awayTeam.name));
    const boardMat = this.track(
      new THREE.MeshStandardMaterial({
        map: adTex,
        emissiveMap: adTex,
        emissive: '#ffffff',
        emissiveIntensity: this.cfg.lighting === 'night' ? 0.68 : 0.28,
        roughness: 0.4,
      }),
    );
    const northGeo = this.track(new THREE.BoxGeometry(PITCH_W + 6, 1.15, 0.36));
    [-HALF_D - 2.8, HALF_D + 2.8].forEach((z) => {
      const b = new THREE.Mesh(northGeo, boardMat);
      b.position.set(0, 0.58, z);
      this.scene.add(b);
    });
    const eastGeo = this.track(new THREE.BoxGeometry(0.36, 1.15, PITCH_D + 5.8));
    [-HALF_W - 3.6, HALF_W + 3.6].forEach((x) => {
      const b = new THREE.Mesh(eastGeo, boardMat);
      b.position.set(x, 0.58, 0);
      this.scene.add(b);
    });

    const lowerStandMat = this.track(new THREE.MeshStandardMaterial({ color: '#1b202b', roughness: 0.85 }));
    const upperStandMat = this.track(new THREE.MeshStandardMaterial({ color: '#12161f', roughness: 0.88 }));
    const roofMat = this.track(new THREE.MeshStandardMaterial({ color: '#272c38', metalness: 0.45, roughness: 0.45 }));
    const standNGeo = this.track(new THREE.BoxGeometry(PITCH_W + 18, 7.5, 9));
    const upperNGeo = this.track(new THREE.BoxGeometry(PITCH_W + 24, 6.5, 9));
    const roofNGeo = this.track(new THREE.BoxGeometry(PITCH_W + 26, 0.7, 13));
    [-1, 1].forEach((s) => {
      const low = new THREE.Mesh(standNGeo, lowerStandMat);
      low.position.set(0, 3.6, s * (HALF_D + 9.2));
      const hi = new THREE.Mesh(upperNGeo, upperStandMat);
      hi.position.set(0, 9.8, s * (HALF_D + 14.5));
      const rf = new THREE.Mesh(roofNGeo, roofMat);
      rf.position.set(0, 14.4, s * (HALF_D + 12.2));
      this.scene.add(low, hi, rf);
    });
    const standEGeo = this.track(new THREE.BoxGeometry(9, 7.5, PITCH_D + 15));
    const upperEGeo = this.track(new THREE.BoxGeometry(9, 6.5, PITCH_D + 22));
    const roofEGeo = this.track(new THREE.BoxGeometry(13, 0.7, PITCH_D + 24));
    [-1, 1].forEach((s) => {
      const low = new THREE.Mesh(standEGeo, lowerStandMat);
      low.position.set(s * (HALF_W + 9.4), 3.6, 0);
      const hi = new THREE.Mesh(upperEGeo, upperStandMat);
      hi.position.set(s * (HALF_W + 14.8), 9.8, 0);
      const rf = new THREE.Mesh(roofEGeo, roofMat);
      rf.position.set(s * (HALF_W + 12.6), 14.4, 0);
      this.scene.add(low, hi, rf);
    });

    const crowdCount = q === 'ultra' ? 760 : q === 'high' ? 540 : q === 'medium' ? 280 : 120;
    const crowdGeo = this.track(new THREE.BoxGeometry(0.75, 1.15, 0.65));
    const crowdMat = this.track(new THREE.MeshStandardMaterial({ roughness: 0.75 }));
    const crowd = new THREE.InstancedMesh(crowdGeo, crowdMat, crowdCount);
    const palette = [
      new THREE.Color(this.homeTeam.primary),
      new THREE.Color('#f8fafc'),
      new THREE.Color(this.awayTeam.primary),
      new THREE.Color('#ef4444'),
      new THREE.Color('#facc15'),
    ];
    this.crowdBaseData = [];
    for (let i = 0; i < crowdCount; i++) {
      const side = i % 4;
      const frac = ((i * 41) % 100) / 100 - 0.5;
      const tier = i % 6;
      const y = 1.9 + tier * 1.45;
      let x = 0;
      let z = 0;
      if (side === 0) {
        x = frac * PITCH_W;
        z = -HALF_D - 5.6 - tier * 1.25;
      } else if (side === 1) {
        x = frac * PITCH_W;
        z = HALF_D + 5.6 + tier * 1.25;
      } else if (side === 2) {
        x = -HALF_W - 5.8 - tier * 1.25;
        z = frac * PITCH_D;
      } else {
        x = HALF_W + 5.8 + tier * 1.25;
        z = frac * PITCH_D;
      }
      this.crowdBaseData.push({ x, y, z, phase: (i * 0.73) % (Math.PI * 2) });
      _dummyObj.position.set(x, y, z);
      _dummyObj.updateMatrix();
      crowd.setMatrixAt(i, _dummyObj.matrix);
      crowd.setColorAt(i, palette[i % palette.length]);
    }
    crowd.instanceMatrix.needsUpdate = true;
    if (crowd.instanceColor) crowd.instanceColor.needsUpdate = true;
    crowd.computeBoundingSphere();
    this.crowdMesh = crowd;
    this.scene.add(crowd);

    const poleGeo = this.track(new THREE.CylinderGeometry(0.45, 0.76, 26, 8));
    const poleMat = this.track(new THREE.MeshStandardMaterial({ color: '#3b4252', metalness: 0.6, roughness: 0.4 }));
    const headGeo = this.track(new THREE.BoxGeometry(5.4, 2.3, 1.1));
    const lampMat = this.track(new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#fff6da', emissiveIntensity: this.cfg.lighting === 'night' ? 1.9 : 0.35 }));
    [
      [-HALF_W - 11, -HALF_D - 10],
      [HALF_W + 11, -HALF_D - 10],
      [-HALF_W - 11, HALF_D + 10],
      [HALF_W + 11, HALF_D + 10],
    ].forEach(([tx, tz]) => {
      const tower = new THREE.Group();
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.y = 13;
      const head = new THREE.Mesh(headGeo, lampMat);
      head.position.y = 26;
      head.lookAt(-tx, 0, -tz);
      tower.add(pole, head);
      tower.position.set(tx, 0, tz);
      this.scene.add(tower);
    });
  }

  private buildGoals(): void {
    const postMat = this.track(new THREE.MeshStandardMaterial({ color: '#f8fafc', metalness: 0.55, roughness: 0.22 }));
    const netMat = this.track(
      new THREE.MeshStandardMaterial({
        color: '#f1f5f9',
        transparent: true,
        opacity: 0.44,
        side: THREE.DoubleSide,
        wireframe: true,
      }),
    );
    const postGeo = this.track(new THREE.CylinderGeometry(0.085, 0.085, GOAL_H, 10));
    const barGeo = this.track(new THREE.CylinderGeometry(0.085, 0.085, GOAL_W + 0.18, 10));
    const stanchionGeo = this.track(new THREE.CylinderGeometry(0.055, 0.055, GOAL_DEPTH, 8));

    [-1, 1].forEach((dir) => {
      const gx = dir * HALF_W;
      const g = new THREE.Group();

      const p1 = new THREE.Mesh(postGeo, postMat);
      p1.position.set(0, GOAL_H / 2, -GOAL_HALF_W);
      p1.castShadow = true;
      const p2 = new THREE.Mesh(postGeo, postMat);
      p2.position.set(0, GOAL_H / 2, GOAL_HALF_W);
      p2.castShadow = true;
      const bar = new THREE.Mesh(barGeo, postMat);
      bar.rotation.x = Math.PI / 2;
      bar.position.set(0, GOAL_H, 0);
      bar.castShadow = true;

      const baseL = new THREE.Mesh(stanchionGeo, postMat);
      baseL.rotation.z = Math.PI / 2;
      baseL.position.set(dir * (GOAL_DEPTH / 2), 0.04, -GOAL_HALF_W);
      const baseR = new THREE.Mesh(stanchionGeo, postMat);
      baseR.rotation.z = Math.PI / 2;
      baseR.position.set(dir * (GOAL_DEPTH / 2), 0.04, GOAL_HALF_W);

      const backNetGeo = this.track(new THREE.PlaneGeometry(GOAL_W, GOAL_H, 16, 8));
      const back = new THREE.Mesh(backNetGeo, netMat);
      back.rotation.y = Math.PI / 2;
      back.position.set(dir * GOAL_DEPTH, GOAL_H / 2, 0);
      this.netRecords.push({
        mesh: back,
        restPos: new Float32Array((backNetGeo.attributes.position.array as Float32Array).slice()),
        side: dir,
      });

      const sideNetGeo = this.track(new THREE.PlaneGeometry(GOAL_DEPTH, GOAL_H, 8, 8));
      const sideL = new THREE.Mesh(sideNetGeo, netMat);
      sideL.position.set(dir * (GOAL_DEPTH / 2), GOAL_H / 2, -GOAL_HALF_W);
      const sideR = new THREE.Mesh(sideNetGeo, netMat);
      sideR.position.set(dir * (GOAL_DEPTH / 2), GOAL_H / 2, GOAL_HALF_W);

      const topNetGeo = this.track(new THREE.PlaneGeometry(GOAL_W, GOAL_DEPTH, 16, 6));
      const top = new THREE.Mesh(topNetGeo, netMat);
      top.rotation.x = Math.PI / 2;
      top.rotation.z = Math.PI / 2;
      top.position.set(dir * (GOAL_DEPTH / 2), GOAL_H, 0);

      g.add(p1, p2, bar, baseL, baseR, back, sideL, sideR, top);
      g.position.set(gx, 0, 0);
      this.scene.add(g);
    });
  }

  private buildBallAndMarkers(): void {
    const ballGeo = this.track(new THREE.SphereGeometry(BALL_R, 24, 18));
    const ballTex = this.track(makeBallTexture());
    const ballMat = this.track(new THREE.MeshStandardMaterial({ map: ballTex, roughness: 0.3, metalness: 0.08 }));
    this.ballMesh = new THREE.Mesh(ballGeo, ballMat);
    this.ballMesh.castShadow = true;
    this.scene.add(this.ballMesh);

    const shadowGeo = this.track(new THREE.CircleGeometry(BALL_R * 1.35, 18));
    const shadowMat = this.track(new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.44 }));
    this.ballShadow = new THREE.Mesh(shadowGeo, shadowMat);
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.ballShadow.position.y = 0.02;
    this.scene.add(this.ballShadow);

    const ringGeo = this.track(new THREE.RingGeometry(0.72, 0.96, 28));
    const ringMat = this.track(new THREE.MeshBasicMaterial({ color: '#ff263f', side: THREE.DoubleSide }));
    this.activeRing = new THREE.Mesh(ringGeo, ringMat);
    this.activeRing.rotation.x = -Math.PI / 2;
    this.activeRing.position.y = 0.03;
    this.scene.add(this.activeRing);

    const passGeo = this.track(new THREE.RingGeometry(0.58, 0.78, 24));
    const passMat = this.track(new THREE.MeshBasicMaterial({ color: '#facc15', transparent: true, opacity: 0.85, side: THREE.DoubleSide }));
    this.passRing = new THREE.Mesh(passGeo, passMat);
    this.passRing.rotation.x = -Math.PI / 2;
    this.passRing.position.y = 0.025;
    this.scene.add(this.passRing);
  }

  private buildTeams(homeSquad: SquadMember[], awaySquad: SquadMember[]): void {
    const geom = createAthleticGeometries((i) => this.track(i));
    const pShadowMat = this.track(new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.36 }));
    const soleMat = this.track(new THREE.MeshStandardMaterial({ color: '#0f172a', roughness: 0.75 }));
    const gloveMat = this.track(new THREE.MeshStandardMaterial({ color: '#f8fafc', roughness: 0.42 }));

    const makePlayerRig = (info: SquadMember, side: 'home' | 'away', idx: number, baseX: number, baseZ: number): PlayerEntity => {
      const team = side === 'home' ? this.homeTeam : this.awayTeam;
      const isGk = idx === 0;
      const jerseyHex = isGk ? (side === 'home' ? '#facc15' : '#06b6d4') : team.primary;
      const accentHex = team.secondary || '#ffffff';
      const s15 = resolveStats15(info);
      const heightCm = info.heightCm || (isGk ? 191 : 180);
      const weightKg = info.weightKg || 76;
      const heightScale = THREE.MathUtils.clamp(heightCm / 181, 0.91, 1.12) * 1.12;
      const buildXZ = THREE.MathUtils.clamp(weightKg / 76, 0.90, 1.12) * 1.12;

      const faceTex = this.track(makeFaceSkinTexture(info.skinHex || '#cfa17d', info.hairHex || '#181414', idx % 2 === 0));
      const skinHeadMat = this.track(new THREE.MeshStandardMaterial({ map: faceTex, roughness: 0.56, metalness: 0.02 }));
      const skinLimbMat = this.track(new THREE.MeshStandardMaterial({ color: info.skinHex || '#cfa17d', roughness: 0.58, metalness: 0.02 }));
      const hairMat = this.track(new THREE.MeshStandardMaterial({ color: info.hairHex || '#181414', roughness: 0.82 }));
      const kitTex = this.track(makeKitFabricTexture(jerseyHex, accentHex, info.jerseyNo || idx + 1, isGk));
      const jerseyMat = this.track(new THREE.MeshStandardMaterial({ map: kitTex, roughness: 0.56, metalness: 0.04 }));
      const plainJerseyMat = this.track(new THREE.MeshStandardMaterial({ color: jerseyHex, roughness: 0.56, metalness: 0.04 }));
      const accentMat = this.track(new THREE.MeshStandardMaterial({ color: accentHex, roughness: 0.42 }));
      const socksMat = this.track(new THREE.MeshStandardMaterial({ color: isGk ? '#111827' : jerseyHex, roughness: 0.62 }));
      const shortsMat = this.track(new THREE.MeshStandardMaterial({ color: side === 'home' ? '#14151b' : '#f1f5f9', roughness: 0.66 }));
      const bootMat = this.track(new THREE.MeshStandardMaterial({ color: info.bootColor || '#ff263f', roughness: 0.30, metalness: 0.16 }));

      const group = new THREE.Group();
      group.scale.set(buildXZ, heightScale, buildXZ);

      const gShadow = new THREE.Mesh(geom.pShadowGeo, pShadowMat);
      gShadow.rotation.x = -Math.PI / 2;
      gShadow.position.y = 0.02;
      group.add(gShadow);

      const pelvis = new THREE.Group();
      pelvis.position.y = 0.94;
      group.add(pelvis);

      const hipMesh = new THREE.Mesh(geom.pelvisGeo, shortsMat);
      hipMesh.scale.set(1.06, 1, 0.72);
      pelvis.add(hipMesh);

      const torso = new THREE.Group();
      torso.position.y = 0.08;
      pelvis.add(torso);

      const chestMesh = new THREE.Mesh(geom.torsoGeo, jerseyMat);
      chestMesh.position.y = 0.25;
      chestMesh.scale.set(1.12, 1, 0.68);
      chestMesh.rotation.y = Math.PI; // orient jersey badge & number cleanly front/back
      chestMesh.castShadow = true;
      torso.add(chestMesh);

      const collar = new THREE.Mesh(geom.collarGeo, accentMat);
      collar.rotation.x = Math.PI / 2;
      collar.position.y = 0.59;
      torso.add(collar);

      const badgeTex = this.track(makeJerseyBadgeTexture(info.jerseyNo || idx + 1, accentHex));
      const badgeMat = this.track(new THREE.MeshBasicMaterial({ map: badgeTex, transparent: true }));
      const numberBadge = new THREE.Mesh(geom.badgeGeo, badgeMat);
      numberBadge.position.set(0, 0.31, -0.15);
      numberBadge.rotation.y = Math.PI;
      torso.add(numberBadge);

      const neck = new THREE.Mesh(geom.neckGeo, skinLimbMat);
      neck.position.y = 0.63;
      torso.add(neck);

      const headGroup = new THREE.Group();
      headGroup.position.y = 0.77;
      torso.add(headGroup);

      const skull = new THREE.Mesh(geom.headGeo, skinHeadMat);
      skull.scale.set(0.92, 1.08, 0.98);
      skull.castShadow = true;
      const jaw = new THREE.Mesh(geom.jawGeo, skinLimbMat);
      jaw.position.set(0, -0.054, 0.022);
      const nose = new THREE.Mesh(geom.noseGeo, skinLimbMat);
      nose.rotation.x = Math.PI / 2;
      nose.position.set(0, -0.008, 0.122);
      const earL = new THREE.Mesh(geom.earGeo, skinLimbMat);
      earL.position.set(-0.112, -0.005, 0);
      const earR = new THREE.Mesh(geom.earGeo, skinLimbMat);
      earR.position.set(0.112, -0.005, 0);

      const hStyle = info.hairStyle || 'short';
      const hair = new THREE.Mesh(
        hStyle === 'curly' ? geom.hairCurlyGeo : hStyle === 'long' ? geom.hairLongGeo : hStyle === 'fade' ? geom.hairFadeTopGeo : geom.hairShortGeo,
        hairMat,
      );
      if (hStyle === 'fade') hair.position.set(0, 0.088, -0.006);
      else if (hStyle === 'long') hair.position.set(0, 0.015, -0.024);
      else if (hStyle === 'curly') hair.position.set(0, 0.045, -0.01);
      else hair.position.set(0, 0.025, -0.006);

      headGroup.add(skull, jaw, nose, earL, earR, hair);

      const makeArm = (armSign: -1 | 1) => {
        const shoulder = new THREE.Group();
        shoulder.position.set(armSign * 0.24, 0.54, 0);
        const cap = new THREE.Mesh(geom.shoulderCapGeo, plainJerseyMat);
        const sleeve = new THREE.Mesh(geom.sleeveGeo, plainJerseyMat);
        sleeve.position.y = -0.085;
        const uArm = new THREE.Mesh(geom.upperArmGeo, skinLimbMat);
        uArm.position.y = -0.18;
        if (armSign === -1 && idx === 2) {
          const armband = new THREE.Mesh(geom.armbandGeo, accentMat);
          armband.position.y = -0.19;
          shoulder.add(armband);
        }
        const elbow = new THREE.Group();
        elbow.position.y = -0.29;
        const eJoint = new THREE.Mesh(geom.elbowGeo, skinLimbMat);
        const fArm = new THREE.Mesh(geom.forearmGeo, skinLimbMat);
        fArm.position.y = -0.125;
        const hand = new THREE.Mesh(isGk ? geom.gloveGeo : geom.handGeo, isGk ? gloveMat : skinLimbMat);
        hand.position.y = -0.265;
        elbow.add(eJoint, fArm, hand);
        shoulder.add(cap, sleeve, uArm, elbow);
        torso.add(shoulder);
        return { shoulder, elbow };
      };
      const lArm = makeArm(-1);
      const rArm = makeArm(1);

      const makeLeg = (legSign: -1 | 1) => {
        const hip = new THREE.Group();
        hip.position.set(legSign * 0.095, -0.04, 0);
        const shortLeg = new THREE.Mesh(geom.shortsTopGeo, shortsMat);
        shortLeg.position.y = -0.10;
        const thigh = new THREE.Mesh(geom.thighGeo, skinLimbMat);
        thigh.position.y = -0.21;

        const knee = new THREE.Group();
        knee.position.y = -0.41;
        const kJoint = new THREE.Mesh(geom.kneeGeo, skinLimbMat);
        const cuff = new THREE.Mesh(geom.sockCuffGeo, accentMat);
        cuff.position.y = -0.08;
        const shin = new THREE.Mesh(geom.calfGeo, socksMat);
        shin.position.y = -0.23;

        const bootUpper = new THREE.Mesh(geom.bootUpperGeo, bootMat);
        bootUpper.position.set(0, -0.44, 0.045);
        const bootSole = new THREE.Mesh(geom.bootSoleGeo, soleMat);
        bootSole.position.set(0, -0.482, 0.045);
        const studFront = new THREE.Mesh(geom.bootStudGeo, soleMat);
        studFront.position.set(0, -0.496, 0.13);
        const studBack = new THREE.Mesh(geom.bootStudGeo, soleMat);
        studBack.position.set(0, -0.496, -0.05);

        knee.add(kJoint, cuff, shin, bootUpper, bootSole, studFront, studBack);
        hip.add(shortLeg, thigh, knee);
        pelvis.add(hip);
        return { hip, knee };
      };
      const lLeg = makeLeg(-1);
      const rLeg = makeLeg(1);

      this.scene.add(group);

      return {
        id: `${side}_${idx}`,
        side,
        idx,
        info,
        s15,
        heightCm,
        scaleFactor: heightScale,
        baseX,
        baseZ,
        x: baseX,
        y: 0,
        z: baseZ,
        vx: 0,
        vy: 0,
        vz: 0,
        facing: side === 'home' ? Math.PI / 2 : -Math.PI / 2,
        bankAngle: 0,
        stamina: 100,
        yellowCards: 0,
        sentOff: false,
        isGk,
        kickAnim: 0,
        kickSide: 1,
        tackleTimer: 0,
        tackleCooldown: 0,
        stumbleTimer: 0,
        skillTimer: 0,
        headerTimer: 0,
        diveTimer: 0,
        diveDir: 0,
        dribbleStepTimer: 0,
        aiThinkTimer: (idx * 0.04) % 0.25,
        aiDecisionCooldown: 0,
        stridePhase: idx * 0.7,
        pose: createDefaultPose(),
        group,
        pelvis,
        torso,
        headGroup,
        leftHip: lLeg.hip,
        leftKnee: lLeg.knee,
        rightHip: rLeg.hip,
        rightKnee: rLeg.knee,
        leftShoulder: lArm.shoulder,
        leftElbow: lArm.elbow,
        rightShoulder: rArm.shoulder,
        rightElbow: rArm.elbow,
        numberBadge,
      };
    };

    const formPts = FORMATIONS[this.liveFormation] || FORMATIONS['4-3-3'];
    formPts.forEach(([fx, fz], i) => {
      this.players.push(makePlayerRig(homeSquad[i] || homeSquad[0], 'home', i, fx, fz));
    });
    const awayForm = (this.awayTeam.formation as FormationKey) || '4-3-3';
    const awayPts = FORMATIONS[awayForm] || FORMATIONS['4-3-3'];
    awayPts.forEach(([fx, fz], i) => {
      this.players.push(makePlayerRig(awaySquad[i] || awaySquad[0], 'away', i, -fx, -fz));
    });
  }

  private resetKickoff(kickoffSide: 'home' | 'away'): void {
    this.ballPos.set(0, BALL_R, 0);
    this.ballVel.set(0, 0, 0);
    this.ballSpinZ = 0;
    this.ballTopSpin = 0;
    this.carrier = null;
    this.pendingPass = null;
    this.goalScorerFocus = null;
    this.shootCharging = false;
    this.shootCharge = 0;
    this.passCharging = false;
    this.passCharge = 0;
    this.updateShootRing(0);

    this.players.forEach((p) => {
      if (p.sentOff) return;
      const startX = p.side === 'home' ? Math.min(-1.6, p.baseX) : Math.max(1.6, p.baseX);
      p.x = p.idx === 9 && p.side === kickoffSide ? (kickoffSide === 'home' ? -0.9 : 0.9) : startX;
      p.y = 0;
      p.z = p.idx === 9 && p.side === kickoffSide ? 0 : p.baseZ;
      p.vx = 0;
      p.vy = 0;
      p.vz = 0;
      p.diveTimer = 0;
      p.stumbleTimer = 0;
      p.skillTimer = 0;
      p.tackleTimer = 0;
      p.headerTimer = 0;
      p.bankAngle = 0;
    });

    this.activeHomeIdx = this.cfg.careerMode === 'player' && typeof this.cfg.proSlotIdx === 'number' && this.cfg.proSlotIdx > 0 ? this.cfg.proSlotIdx : 9;
    this.activeAwayIdx = 9;
    this.phase = 'kickoff';
    this.phaseTimer = 0.65;
  }

  private showBanner(text: string, durationMs = 1900): void {
    if (!this.bannerEl) return;
    this.bannerEl.textContent = text;
    this.bannerEl.style.display = 'block';
    window.setTimeout(() => {
      if (this.bannerEl && !this.destroyed) this.bannerEl.style.display = 'none';
    }, durationMs);
  }

  private updateShootRing(charge01: number): void {
    if (!this.shootCircleEl) return;
    const circ = 220;
    this.shootCircleEl.style.strokeDashoffset = String(Math.round(circ * (1 - Math.max(0, Math.min(1, charge01)))));
  }

  private getControlledHome(): PlayerEntity {
    return this.players.find((p) => p.side === 'home' && p.idx === this.activeHomeIdx && !p.sentOff) || this.players.find((p) => p.side === 'home' && !p.isGk && !p.sentOff) || this.players[9];
  }

  private getAssistWeight(): number {
    if (this.cfg.controlAssist === 'يدوي') return 0.24;
    if (this.cfg.controlAssist === 'مساعد كامل') return 1.0;
    return 0.68;
  }

  private findBestHomeTeammate(ctrl: PlayerEntity, biasVision = 80): PlayerEntity | null {
    const dirX = Math.sin(ctrl.facing);
    const dirZ = Math.cos(ctrl.facing);
    const visionFactor = 0.5 + (biasVision / 100) * 0.6;
    const assist = this.getAssistWeight();
    let best: PlayerEntity | null = null;
    let bestScore = -9999;

    for (const p of this.players) {
      if (p.side !== 'home' || p.id === ctrl.id || p.sentOff) continue;
      const dx = p.x - ctrl.x;
      const dz = p.z - ctrl.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 1.8 || dist > 64) continue;
      const dot = (dx * dirX + dz * dirZ) / dist;
      const coneMin = this.cfg.controlAssist === 'يدوي' ? 0.35 : -0.18;
      if (dot < coneMin) continue;
      const spaceScore = p.x > ctrl.x ? 9.5 * visionFactor : 0;
      const sc = dot * (36 + (1 - assist) * 18) - dist * 0.42 + spaceScore;
      if (sc > bestScore) {
        bestScore = sc;
        best = p;
      }
    }
    return best;
  }

  private performPass(mode: 'short' | 'through' | 'cross', extraPower01 = 0.25): void {
    const ctrl = this.getControlledHome();
    if (!this.carrier || this.carrier.side !== 'home') {
      this.switchNearestHomeDefender();
      return;
    }
    const passer = this.carrier;
    const target = this.findBestHomeTeammate(passer, passer.s15.vision);
    this.prevTouchHomePlayer = this.lastTouchHomePlayer;
    this.lastTouchHomePlayer = passer;
    this.lastTouchPlayer = passer;
    this.lastTouchSide = 'home';
    this.carrier = null;
    passer.kickAnim = 0.30;
    passer.kickSide = passer.info.role === 'LW' || passer.info.role === 'LB' ? -1 : 1;
    this.homePasses++;
    this.audio.playKick(0.45 + extraPower01 * 0.25);
    sfx('kick');

    let dx = Math.sin(passer.facing);
    let dz = Math.cos(passer.facing);
    const pasAcc = passer.s15.passAccuracy / 100;
    const vision = passer.s15.vision / 100;
    let speed = (mode === 'through' ? 24 : mode === 'cross' ? 21 : 20 + pasAcc * 5) + extraPower01 * 4.5;

    if (target) {
      // Check offside condition at exact moment of kick
      if (evaluateOffside('home', this.ballPos.x, target, this.players.filter((p) => !p.sentOff))) {
        this.pendingPass = { passerSide: 'home', ballXAtKick: this.ballPos.x, receiverId: target.id, expiresAt: performance.now() + 2600 };
      } else {
        this.pendingPass = null;
      }

      const leadSec = mode === 'through' ? 0.44 + vision * 0.34 : mode === 'cross' ? 0.36 : 0.16 + vision * 0.12;
      const throughSpace = mode === 'through' ? 4.8 + vision * 4.5 : 0;
      const tx = target.x + target.vx * leadSec + throughSpace;
      const tz = target.z + target.vz * leadSec;
      const dist = Math.hypot(tx - passer.x, tz - passer.z) || 1;
      const rawDx = (tx - passer.x) / dist;
      const rawDz = (tz - passer.z) / dist;
      const assist = this.getAssistWeight();
      const blend = THREE.MathUtils.clamp(assist * (0.68 + pasAcc * 0.32), 0.16, 0.98);
      dx = dx * (1 - blend) + rawDx * blend;
      dz = dz * (1 - blend) + rawDz * blend;
      const n = Math.hypot(dx, dz) || 1;
      dx /= n;
      dz /= n;
      const spread = (1 - pasAcc) * 0.10;
      dx += (Math.random() - 0.5) * spread;
      dz += (Math.random() - 0.5) * spread;
      speed = THREE.MathUtils.clamp(dist * (mode === 'through' ? 1.05 : mode === 'cross' ? 0.96 : 1.15) + extraPower01 * 3.5, 14, 32);
      if (this.cfg.careerMode !== 'player') {
        this.activeHomeIdx = target.idx;
      }
    }
    const loft = mode === 'cross' ? 9.5 : mode === 'through' ? 2.5 : 0.5 + extraPower01 * 1.1;
    this.ballSpinZ = mode === 'cross' ? Math.sign(-passer.z || 1) * 5.4 : 0;
    this.ballTopSpin = mode === 'cross' ? 2.4 : -1.5;
    this.ballVel.set(dx * speed, loft, dz * speed);
    this.turfParticles.burst(this.ballPos.x, this.ballPos.z, -dx, -dz, 6, 3.2);
  }

  private performShoot(charge01: number): void {
    if (!this.carrier || this.carrier.side !== 'home') {
      this.performTackle();
      return;
    }
    const shooter = this.carrier;
    this.prevTouchHomePlayer = this.lastTouchHomePlayer;
    this.lastTouchHomePlayer = shooter;
    this.lastTouchPlayer = shooter;
    this.lastTouchSide = 'home';
    this.pendingPass = null;
    this.carrier = null;
    shooter.kickAnim = 0.40;
    shooter.kickSide = Math.random() > 0.25 ? 1 : -1;
    this.homeShots++;
    this.audio.playKick(0.65 + charge01 * 0.35);
    this.audio.pulseCrowdExcitement(0.24);
    sfx('kick');

    const goalX = HALF_W;
    const accNorm = shooter.s15.shotAccuracy / 100;
    const powNorm = shooter.s15.shotPower / 100;
    const assist = this.getAssistWeight();
    const stickAim = Math.cos(shooter.facing) * 4.2 + shooter.z * 0.28 * assist;
    const errSpread = (1 - accNorm) * (2.4 - assist * 1.0);
    const aimZ = THREE.MathUtils.clamp(stickAim + (Math.random() - 0.5) * errSpread, -GOAL_HALF_W - 0.85, GOAL_HALF_W + 0.85);
    const dx = goalX - shooter.x;
    const dz = aimZ - shooter.z;
    const dist = Math.hypot(dx, dz) || 1;
    if (Math.abs(aimZ) < GOAL_HALF_W) this.homeShotsOnTarget++;

    const power = (22.5 + charge01 * 18.5) * (0.85 + powNorm * 0.30);
    const loft = 1.85 + charge01 * 5.2 + (1 - accNorm) * 1.1;
    this.ballSpinZ = -Math.sign(shooter.z || 1) * charge01 * (4.8 + accNorm * 3.8);
    this.ballTopSpin = charge01 * 4.8;
    this.ballVel.set((dx / dist) * power, loft, (dz / dist) * power);
    this.turfParticles.burst(shooter.x, shooter.z, -dx / dist, -dz / dist, 12, 5.2);
    this.setCommentary(`⚡ تسديدة قوية من ${shooter.info.name}!`);
  }

  private performSkillMove(): void {
    const ctrl = this.getControlledHome();
    if (ctrl.skillTimer > 0) return;
    const agi = ctrl.s15.agility / 100;
    const dri = ctrl.s15.dribbling / 100;
    ctrl.skillTimer = 0.52;
    const burst = 5.4 + agi * 2.5 + dri * 2.1;
    ctrl.vx += Math.sin(ctrl.facing) * burst;
    ctrl.vz += Math.cos(ctrl.facing) * burst;
    this.turfParticles.burst(ctrl.x, ctrl.z, -Math.sin(ctrl.facing), -Math.cos(ctrl.facing), 8, 3.6);
    sfx('bounce');
  }

  private performTackle(): void {
    const ctrl = this.getControlledHome();
    if (ctrl.tackleCooldown > 0) return;
    const tack = ctrl.s15.tackling / 100;
    ctrl.tackleCooldown = Math.max(0.58, 1.05 - tack * 0.38);
    ctrl.tackleTimer = 0.40;
    ctrl.kickAnim = 0.30;
    const dirX = Math.sin(ctrl.facing);
    const dirZ = Math.cos(ctrl.facing);
    const lunge = 9.5 + tack * 4.2;
    ctrl.vx += dirX * lunge;
    ctrl.vz += dirZ * lunge;
    this.turfParticles.burst(ctrl.x, ctrl.z, -dirX, -dirZ, 14, 4.8);
    sfx('bounce');

    const reach = 1.9 + tack * 0.85;
    const distBall = Math.hypot(this.ballPos.x - ctrl.x, this.ballPos.z - ctrl.z);
    if (distBall < reach && this.ballPos.y < 1.3) {
      if (this.carrier) this.carrier.stumbleTimer = Math.max(0.2, 0.55 - (this.carrier.s15.balance / 100) * 0.28);
      this.carrier = ctrl;
      this.lastTouchSide = 'home';
      this.lastTouchHomePlayer = ctrl;
      this.lastTouchPlayer = ctrl;
      this.audio.playKick(0.4);
      this.setCommentary(`🦾 افتكاك نظيف للكرة بواسطة ${ctrl.info.name}`);
      sfx('kick');
      return;
    }

    // Check foul if player slid directly into opponent carrier without reaching ball
    if (this.carrier && this.carrier.side === 'away') {
      const distCarrier = Math.hypot(this.carrier.x - ctrl.x, this.carrier.z - ctrl.z);
      if (distCarrier < 1.35) {
        this.triggerFoul(ctrl, this.carrier);
      }
    }
  }

  private triggerFoul(offender: PlayerEntity, victim: PlayerEntity): void {
    this.audio.playWhistle('short');
    sfx('whistle');
    if (offender.side === 'home') this.homeFouls++;
    else this.awayFouls++;
    offender.yellowCards += 1;

    const restartSide: 'home' | 'away' = victim.side;
    const inBox = isInsidePenaltyBox(restartSide, victim.x, victim.z);

    if (offender.yellowCards >= 2) {
      offender.sentOff = true;
      offender.group.visible = false;
      this.showBanner(`🟥 بطاقة حمراء! طرد ${offender.info.name}`, 2100);
      this.setCommentary(`🟥 طرد مستحق للاعب ${offender.info.name} بعد تدخل عنيف`);
    } else if (Math.random() < 0.55 || inBox) {
      this.showBanner(`🟨 بطاقة صفراء على ${offender.info.name}`, 1800);
    }

    this.carrier = null;
    if (inBox) {
      // Penalty Kick! Set ball on penalty spot and let attacker take a live strike
      const penX = restartSide === 'home' ? HALF_W - 11 : -HALF_W + 11;
      this.ballPos.set(penX, BALL_R, 0);
      this.ballVel.set(0, 0, 0);
      victim.x = penX - (restartSide === 'home' ? 1.0 : -1.0);
      victim.z = 0;
      this.carrier = victim;
      if (restartSide === 'home') this.activeHomeIdx = victim.idx;
      this.showBanner(`⚠️ ركلة جزاء لصالح ${restartSide === 'home' ? this.homeTeam.name : this.awayTeam.name}!`, 2100);
      this.setCommentary(`⚠️ ركلة جزاء حاسمة في منطقة الـ 18!`);
    } else {
      this.ballPos.set(victim.x, BALL_R, victim.z);
      this.ballVel.set(0, 0, 0);
      this.carrier = victim;
      if (restartSide === 'home') this.activeHomeIdx = victim.idx;
      this.showBanner(`📢 خطأ وضربة حرة لصالح ${restartSide === 'home' ? this.homeTeam.name : this.awayTeam.name}`, 1500);
      this.setCommentary(`📢 ضربة حرة مباشرة بعد تدخل على ${victim.info.name}`);
    }
  }

  private switchNearestHomeDefender(): void {
    let bestIdx = this.activeHomeIdx;
    let bestD = Infinity;
    for (const p of this.players) {
      if (p.side !== 'home' || p.isGk || p.sentOff) continue;
      const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
      if (d < bestD) {
        bestD = d;
        bestIdx = p.idx;
      }
    }
    this.activeHomeIdx = bestIdx;
    sfx('click');
  }

  private bindInputs(): void {
    const unlockAudio = () => this.audio.unlock();
    window.addEventListener('pointerdown', unlockAudio, { once: true });

    const onResize = () => {
      if (this.destroyed) return;
      const host = document.getElementById('myaiF3dCanvasHost') || this.container;
      const w = host.clientWidth || window.innerWidth;
      const h = host.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const onKeyDown = (e: KeyboardEvent) => {
      if (this.destroyed) return;
      this.audio.unlock();
      const k = e.key.toLowerCase();
      this.keys.add(k);
      if (k === 'shift') this.sprintHeld = true;
      if (k === 'j') this.performPass('short', 0.3);
      if (k === 'l') this.performPass('through', 0.4);
      if (k === 'u') this.performPass('cross', 0.5);
      if (k === 'e') this.performSkillMove();
      if (k === 'q') this.switchNearestHomeDefender();
      if (k === 'k' || e.code === 'Space') {
        if (!this.shootCharging) {
          this.shootCharging = true;
          this.shootCharge = 0.25;
        }
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      this.keys.delete(k);
      if (k === 'shift') this.sprintHeld = false;
      if ((k === 'k' || e.code === 'Space') && this.shootCharging) {
        this.performShoot(this.shootCharge);
        this.shootCharging = false;
        this.shootCharge = 0;
        this.updateShootRing(0);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const joyZone = document.getElementById('f3dJoyZone');
    const joyKnob = document.getElementById('f3dJoyKnob');
    const sens = (this.cfg.controlPreset?.sensitivity || 100) / 100;
    const updateJoy = (clientX: number, clientY: number) => {
      if (!joyZone) return;
      const r = joyZone.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const maxR = Math.max(22, (r.width * 0.36) / sens);
      const dx = clientX - cx;
      const dy = clientY - cy;
      const dist = Math.hypot(dx, dy);
      const ratio = dist > 3 ? Math.min(1, dist / maxR) : 0;
      const ang = Math.atan2(dy, dx);
      this.joyVec.x = Math.cos(ang) * ratio;
      this.joyVec.z = Math.sin(ang) * ratio;
      if (joyKnob) {
        const knobTravel = r.width * 0.26 * ratio;
        joyKnob.style.transform = `translate(${Math.cos(ang) * knobTravel}px, ${Math.sin(ang) * knobTravel}px)`;
      }
    };

    const onJoyDown = (e: PointerEvent) => {
      e.preventDefault();
      this.audio.unlock();
      this.joyPointerId = e.pointerId;
      this.joyVec.active = true;
      joyZone?.setPointerCapture?.(e.pointerId);
      updateJoy(e.clientX, e.clientY);
    };
    const onJoyMove = (e: PointerEvent) => {
      if (this.joyPointerId !== e.pointerId) return;
      updateJoy(e.clientX, e.clientY);
    };
    const onJoyUp = (e: PointerEvent) => {
      if (this.joyPointerId !== e.pointerId) return;
      this.joyPointerId = null;
      this.joyVec.active = false;
      this.joyVec.x = 0;
      this.joyVec.z = 0;
      if (joyKnob) joyKnob.style.transform = 'translate(0px, 0px)';
    };
    joyZone?.addEventListener('pointerdown', onJoyDown);
    joyZone?.addEventListener('pointermove', onJoyMove);
    joyZone?.addEventListener('pointerup', onJoyUp);
    joyZone?.addEventListener('pointercancel', onJoyUp);

    const shootBtn = document.getElementById('f3dShootBtn');
    shootBtn?.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      this.audio.unlock();
      this.shootCharging = true;
      this.shootCharge = 0.28;
      this.updateShootRing(0.28);
    });
    const releaseShoot = () => {
      if (!this.shootCharging) return;
      this.performShoot(this.shootCharge);
      this.shootCharging = false;
      this.shootCharge = 0;
      this.updateShootRing(0);
    };
    shootBtn?.addEventListener('pointerup', releaseShoot);
    shootBtn?.addEventListener('pointercancel', releaseShoot);

    // Chargeable pass button (tap for crisp pass, hold briefly for driven pass)
    const passBtn = document.getElementById('f3dPassBtn');
    passBtn?.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      this.audio.unlock();
      this.passCharging = true;
      this.passCharge = 0.2;
    });
    const releasePass = () => {
      if (!this.passCharging) return;
      this.performPass('short', this.passCharge);
      this.passCharging = false;
      this.passCharge = 0;
    };
    passBtn?.addEventListener('pointerup', releasePass);
    passBtn?.addEventListener('pointercancel', releasePass);

    document.getElementById('f3dThroughBtn')?.addEventListener('click', () => this.performPass('through', 0.45));
    document.getElementById('f3dCrossBtn')?.addEventListener('click', () => this.performPass('cross', 0.55));
    document.getElementById('f3dSkillBtn')?.addEventListener('click', () => this.performSkillMove());
    document.getElementById('f3dTackleBtn')?.addEventListener('click', () => this.performTackle());
    document.getElementById('f3dSwitchBtn')?.addEventListener('click', () => this.switchNearestHomeDefender());

    const pressBtn = document.getElementById('f3dPressBtn');
    pressBtn?.addEventListener('pointerdown', () => (this.pressHeld = true));
    pressBtn?.addEventListener('pointerup', () => (this.pressHeld = false));
    pressBtn?.addEventListener('pointercancel', () => (this.pressHeld = false));

    const bindSprint = (el: HTMLElement | null) => {
      el?.addEventListener('pointerdown', () => (this.sprintHeld = true));
      el?.addEventListener('pointerup', () => (this.sprintHeld = false));
      el?.addEventListener('pointercancel', () => (this.sprintHeld = false));
    };
    bindSprint(document.getElementById('f3dSprintBtn'));
    bindSprint(document.getElementById('f3dSprintDefBtn'));

    document.querySelectorAll<HTMLButtonElement>('#f3dQuickTacticBar button').forEach((btn) => {
      btn.onclick = () => {
        const p = (btn.getAttribute('data-posture') as 'def' | 'bal' | 'att') || 'bal';
        this.liveTacticPosture = p;
        document.querySelectorAll('#f3dQuickTacticBar button').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        sfx('click');
      };
    });

    const soundBtn = document.getElementById('f3dSoundBtn');
    soundBtn?.addEventListener('click', () => {
      this.audio.unlock();
      const nextMuted = !this.audio.isMuted();
      this.audio.setMuted(nextMuted);
      soundBtn.textContent = nextMuted ? '🔇' : '🔊';
    });

    document.getElementById('f3dForceLandBtn')?.addEventListener('click', () => {
      try {
        this.container.requestFullscreen?.().catch(() => {});
        (screen.orientation as any)?.lock?.('landscape').catch(() => {});
      } catch {
        // ignore
      }
    });

    const cycleCam = () => {
      const nextIdx = (CAMERA_ORDER.indexOf(this.cameraMode) + 1) % CAMERA_ORDER.length;
      this.cameraMode = CAMERA_ORDER[nextIdx];
      this.camera.fov = this.getCameraFov();
      this.camera.updateProjectionMatrix();
      const btn = document.getElementById('f3dCamBtn');
      if (btn) btn.textContent = `🎥 ${CAMERA_LABELS[this.cameraMode]}`;
      sfx('click');
    };
    document.getElementById('f3dCamBtn')?.addEventListener('click', cycleCam);
    document.getElementById('f3dCycleCamPause')?.addEventListener('click', cycleCam);

    document.getElementById('f3dZoomInBtn')?.addEventListener('click', () => {
      this.cameraZoom = THREE.MathUtils.clamp(this.cameraZoom + 0.1, 0.7, 1.35);
      sfx('click');
    });
    document.getElementById('f3dZoomOutBtn')?.addEventListener('click', () => {
      this.cameraZoom = THREE.MathUtils.clamp(this.cameraZoom - 0.1, 0.7, 1.35);
      sfx('click');
    });

    const togglePause = () => {
      this.paused = !this.paused;
      const pm = document.getElementById('f3dPauseModal');
      if (pm) pm.style.display = this.paused ? 'flex' : 'none';
      if (this.paused) this.renderPauseSubs();
      sfx('click');
    };
    document.getElementById('f3dPauseBtn')?.addEventListener('click', togglePause);
    document.getElementById('f3dResumeBtn')?.addEventListener('click', togglePause);
    document.getElementById('f3dEndNowBtn')?.addEventListener('click', () => this.finishMatch());
    document.getElementById('f3dExitBtn')?.addEventListener('click', () => this.disposeAndExit());

    this.disposables.push({
      dispose: () => {
        window.removeEventListener('pointerdown', unlockAudio);
        window.removeEventListener('resize', onResize);
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
      },
    });
  }

  private scheduleLoop(): void {
    const step = (now: number) => {
      if (this.destroyed) return;
      const rawDt = Math.min(0.05, Math.max(0.005, (now - this.lastTick) / 1000));
      const speedMul = this.cfg.gameSpeed === 'fast' ? 1.15 : this.cfg.gameSpeed === 'relaxed' ? 0.88 : 1.0;
      const dt = rawDt * speedMul;
      this.lastTick = now;

      if (!this.paused && this.phase !== 'fulltime') {
        this.update(dt);
      }
      this.render();

      if (this.isSoftwareGl) {
        const gl = this.renderer.getContext() as WebGL2RenderingContext;
        if (typeof gl.fenceSync === 'function') {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
          gl.flush();
          const waitSync = () => {
            if (this.destroyed) return;
            const st = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
            if (st === gl.UNSIGNALED) {
              this.timerId = window.setTimeout(waitSync, 5);
            } else {
              if (sync) gl.deleteSync(sync);
              this.timerId = window.setTimeout(() => {
                if (!this.destroyed) this.rafId = requestAnimationFrame(step);
              }, 30);
            }
          };
          this.timerId = window.setTimeout(waitSync, 5);
        } else {
          this.timerId = window.setTimeout(() => {
            if (!this.destroyed) this.rafId = requestAnimationFrame(step);
          }, 30);
        }
      } else {
        this.rafId = requestAnimationFrame(step);
      }
    };
    this.rafId = requestAnimationFrame(step);
  }

  private update(dt: number): void {
    this.audio.update(dt);
    this.turfParticles.update(dt);

    if (this.shootCharging) {
      this.shootCharge = Math.min(1, this.shootCharge + dt * 1.45);
      this.updateShootRing(this.shootCharge);
    }
    if (this.passCharging) {
      this.passCharge = Math.min(1, this.passCharge + dt * 1.6);
    }

    if (this.netImpactTimer > 0) {
      this.netImpactTimer = Math.max(0, this.netImpactTimer - dt);
      const amp = this.netImpactTimer * 0.48;
      for (const nr of this.netRecords) {
        if (nr.side !== this.netImpactSide) continue;
        const posAttr = nr.mesh.geometry.attributes.position as THREE.BufferAttribute;
        const arr = posAttr.array as Float32Array;
        const rest = nr.restPos;
        for (let i = 0; i < arr.length; i += 3) {
          const rx = rest[i];
          const ry = rest[i + 1];
          const ripple = Math.sin(this.netImpactTimer * 26 - Math.hypot(rx, ry) * 1.8) * amp;
          arr[i + 2] = rest[i + 2] + ripple * nr.side;
        }
        posAttr.needsUpdate = true;
      }
    }

    if (this.phase === 'kickoff' || this.phase === 'goal' || this.phase === 'halftime') {
      this.phaseTimer -= dt;
      if (this.phaseTimer <= 0) {
        if (this.phase === 'halftime') {
          this.half = 2;
          this.resetKickoff('away');
          this.phase = 'playing';
          this.showBanner('بداية الشوط الثاني!');
          this.audio.playWhistle('short');
          sfx('whistle');
        } else {
          this.phase = 'playing';
          this.goalScorerFocus = null;
        }
      }
      this.updateMeshes(dt);
      this.drawRadarMinimap();
      return;
    }

    this.matchClock += dt;
    const totalHalfSec = this.cfg.halfSeconds;
    const matchMinute = Math.min(90, Math.floor((((this.half - 1) * totalHalfSec + this.matchClock) / (totalHalfSec * 2)) * 90));
    if (this.clockEl) this.clockEl.textContent = `${String(matchMinute).padStart(2, '0')}'`;
    if (this.halfEl) this.halfEl.textContent = this.half === 1 ? 'الشوط 1' : 'الشوط 2';

    if (this.matchClock >= totalHalfSec) {
      this.matchClock = 0;
      if (this.half === 1) {
        this.phase = 'halftime';
        this.phaseTimer = 1.6;
        this.showBanner('نهاية الشوط الأول', 1500);
        this.audio.playWhistle('short');
        sfx('whistle');
        return;
      } else {
        this.finishMatch();
        return;
      }
    }

    if (this.carrier) {
      if (this.carrier.side === 'home') this.homePossTime += dt;
      else this.awayPossTime += dt;
    }

    const homeHasBall = this.carrier?.side === 'home' || (!this.carrier && this.lastTouchSide === 'home');
    if (this.offenseBtnsEl && this.defenseBtnsEl) {
      this.offenseBtnsEl.style.display = homeHasBall ? 'block' : 'none';
      this.defenseBtnsEl.style.display = homeHasBall ? 'none' : 'block';
    }

    const diff = getDifficultyFactors(this.cfg.difficulty, this.cfg.opponentStrength, this.cfg.gkLevel);
    const ctrl = this.getControlledHome();

    for (const p of this.players) {
      if (p.sentOff) continue;
      if (p.kickAnim > 0) p.kickAnim = Math.max(0, p.kickAnim - dt);
      if (p.tackleTimer > 0) p.tackleTimer = Math.max(0, p.tackleTimer - dt);
      if (p.tackleCooldown > 0) p.tackleCooldown = Math.max(0, p.tackleCooldown - dt);
      if (p.stumbleTimer > 0) p.stumbleTimer = Math.max(0, p.stumbleTimer - dt);
      if (p.skillTimer > 0) p.skillTimer = Math.max(0, p.skillTimer - dt);
      if (p.headerTimer > 0) p.headerTimer = Math.max(0, p.headerTimer - dt);
      if (p.diveTimer > 0) p.diveTimer = Math.max(0, p.diveTimer - dt);

      const s15 = p.s15;
      const stamDrainRate = Math.max(8, 22 - (s15.staminaStat / 100) * 11);
      const stamRecRate = 8 + (s15.staminaStat / 100) * 8;
      const stamFactor = 0.84 + (p.stamina / 100) * 0.16;
      const maxSpd = (5.7 + (s15.speed / 100) * 4.2) * stamFactor * (p.side === 'away' ? diff.aiSpeed : 1);
      const accelLambda = 5.4 + (s15.acceleration / 100) * 9.6;
      const turnLambda = 7.5 + (s15.agility / 100) * 12.5;

      if (p.id === ctrl.id) {
        let ix = this.joyVec.x;
        let iz = this.joyVec.z;
        if (this.keys.has('w') || this.keys.has('arrowup')) iz -= 1;
        if (this.keys.has('s') || this.keys.has('arrowdown')) iz += 1;
        if (this.keys.has('a') || this.keys.has('arrowleft')) ix -= 1;
        if (this.keys.has('d') || this.keys.has('arrowright')) ix += 1;

        if (this.pressHeld && !this.carrier && Math.abs(ix) < 0.05 && Math.abs(iz) < 0.05) {
          const d = Math.hypot(this.ballPos.x - p.x, this.ballPos.z - p.z) || 1;
          ix = (this.ballPos.x - p.x) / d;
          iz = (this.ballPos.z - p.z) / d;
        }

        const mag = Math.hypot(ix, iz);
        if (mag > 0.05 && p.stumbleTimer <= 0 && p.tackleTimer <= 0) {
          const sprinting = (this.sprintHeld || p.skillTimer > 0) && p.stamina > 6;
          if (sprinting) p.stamina = Math.max(0, p.stamina - dt * stamDrainRate);
          else p.stamina = Math.min(100, p.stamina + dt * stamRecRate * 0.65);

          const dribbleDrag = this.carrier === p ? (0.90 + (s15.dribbling / 100) * 0.09) : 1.0;
          const spd = maxSpd * (sprinting ? 1.29 : 1) * dribbleDrag * Math.min(1, mag);
          const targetVx = (ix / mag) * spd;
          const targetVz = (iz / mag) * spd;
          p.vx = THREE.MathUtils.damp(p.vx, targetVx, accelLambda, dt);
          p.vz = THREE.MathUtils.damp(p.vz, targetVz, accelLambda, dt);

          const targetAng = Math.atan2(p.vx, p.vz);
          const diffAng = Math.atan2(Math.sin(targetAng - p.facing), Math.cos(targetAng - p.facing));
          if (Math.abs(diffAng) > 1.2 && spd > 6.5 && Math.random() < 0.25) {
            this.turfParticles.burst(p.x, p.z, -Math.sin(p.facing), -Math.cos(p.facing), 3, 2.5);
          }
          p.facing += diffAng * (1 - Math.exp(-turnLambda * dt));
          p.bankAngle = THREE.MathUtils.damp(p.bankAngle, THREE.MathUtils.clamp(-diffAng * 0.42, -0.26, 0.26), 10, dt);
        } else {
          p.vx = THREE.MathUtils.damp(p.vx, 0, accelLambda * 0.85, dt);
          p.vz = THREE.MathUtils.damp(p.vz, 0, accelLambda * 0.85, dt);
          p.bankAngle = THREE.MathUtils.damp(p.bankAngle, 0, 10, dt);
          p.stamina = Math.min(100, p.stamina + dt * stamRecRate);
        }
      } else if (p.isGk) {
        const homeSide = p.side === 'home';
        const baseGkX = homeSide ? -HALF_W + 2.2 : HALF_W - 2.2;
        const gkRef = p.side === 'away' ? (s15.gkReflexes / 100) * diff.gkReach : s15.gkReflexes / 100;
        const shotIncoming = (homeSide && this.ballVel.x < -8.0) || (!homeSide && this.ballVel.x > 8.0);
        // Sweeper keeper: steps slightly off the line if 1v1 breakaway
        const opp1v1 =
          this.carrier &&
          this.carrier.side !== p.side &&
          ((homeSide && this.carrier.x < -HALF_W + 20) || (!homeSide && this.carrier.x > HALF_W - 20));
        const sweepX = opp1v1 ? THREE.MathUtils.lerp(baseGkX, this.carrier!.x, 0.22) : baseGkX;

        const predictedZ = shotIncoming
          ? this.ballPos.z + (this.ballVel.z * Math.abs(baseGkX - this.ballPos.x)) / Math.max(6, Math.abs(this.ballVel.x))
          : this.ballPos.z * 0.45;
        const targetZ = THREE.MathUtils.clamp(predictedZ, -GOAL_HALF_W + 0.35, GOAL_HALF_W - 0.35);
        p.vx = (sweepX - p.x) * 4.5;
        p.vz = THREE.MathUtils.clamp((targetZ - p.z) * (4.2 + gkRef * 3.8), -8.6, 8.6);
        p.facing = homeSide ? Math.PI / 2 : -Math.PI / 2;

        const distBall = Math.hypot(this.ballPos.x - p.x, this.ballPos.z - p.z);
        const saveReach = 1.48 + gkRef * 0.56;
        if (distBall < saveReach && this.ballPos.y < GOAL_H + 0.35 && !this.carrier) {
          p.diveTimer = 0.54;
          p.diveDir = Math.sign(this.ballPos.z - p.z || this.ballVel.z || 1);
          this.audio.playKick(0.5);
          this.audio.pulseCrowdExcitement(0.22);
          sfx('bounce');
          const clearDir = homeSide ? 1 : -1;
          this.ballSpinZ = 0;
          this.ballTopSpin = 0;
          this.ballVel.set(clearDir * (19 + gkRef * 6.5), 5.6, (Math.random() - 0.5) * 13);
          this.lastTouchSide = p.side;
          this.lastTouchPlayer = p;
          this.setCommentary(`🧤 تصدٍ رائع من الحارس ${p.info.name}!`);
        }
      } else {
        this.updateAiOutfield(p, maxSpd, accelLambda, turnLambda, diff, dt);
      }

      if (p.y > 0 || p.vy !== 0) {
        p.vy -= 21 * dt;
        p.y += p.vy * dt;
        if (p.y <= 0) {
          p.y = 0;
          p.vy = 0;
        }
      }

      p.x = THREE.MathUtils.clamp(p.x + p.vx * dt, -HALF_W - 1, HALF_W + 1);
      p.z = THREE.MathUtils.clamp(p.z + p.vz * dt, -HALF_D - 1, HALF_D + 1);
    }

    // Physical shoulder-to-shoulder player separation weighted by physical & balance
    for (let i = 0; i < this.players.length; i++) {
      const a = this.players[i];
      if (a.sentOff) continue;
      for (let j = i + 1; j < this.players.length; j++) {
        const b = this.players[j];
        if (b.sentOff) continue;
        const dx = b.x - a.x;
        const dz = b.z - a.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.001 && d < 0.88) {
          const overlap = (0.88 - d) * 0.5;
          const nx = dx / d;
          const nz = dz / d;
          const massA = a.s15.physical + a.s15.balance * 0.4;
          const massB = b.s15.physical + b.s15.balance * 0.4;
          const ratioA = massB / Math.max(1, massA + massB);
          const ratioB = 1 - ratioA;
          a.x -= nx * overlap * ratioA;
          a.z -= nz * overlap * ratioA;
          b.x += nx * overlap * ratioB;
          b.z += nz * overlap * ratioB;
        }
      }
    }

    this.updateBallPhysics(dt);
    this.updateMeshes(dt);
    this.drawRadarMinimap();
  }

  private updateAiOutfield(
    p: PlayerEntity,
    maxSpd: number,
    accelLambda: number,
    turnLambda: number,
    diff: ReturnType<typeof getDifficultyFactors>,
    dt: number,
  ): void {
    const attackDir = p.side === 'home' ? 1 : -1;
    const s15 = p.s15;
    if (p.aiDecisionCooldown > 0) p.aiDecisionCooldown -= dt;

    if (this.carrier === p) {
      const goalX = p.side === 'away' ? -HALF_W : HALF_W;
      // Steer subtly away from nearest immediate presser while advancing toward goal
      let evadeZ = 0;
      for (const opp of this.players) {
        if (opp.side === p.side || opp.sentOff) continue;
        const d = Math.hypot(opp.x - p.x, opp.z - p.z);
        if (d < 5.5) {
          evadeZ += Math.sign(p.z - opp.z || 1) * (5.5 - d) * 1.4;
        }
      }
      const dx = goalX - p.x;
      const styleWidth = this.cfg.opponentStyle === 'استحواذ' && p.side === 'away' ? 0.25 : 0.55;
      const dz = -p.z * styleWidth + evadeZ;
      const distGoal = Math.hypot(dx, dz) || 1;
      const spScale = p.side === 'away' && this.cfg.opponentStyle === 'مرتدات' ? 1.0 : 0.91;
      p.vx = THREE.MathUtils.damp(p.vx, (dx / distGoal) * maxSpd * spScale, accelLambda, dt);
      p.vz = THREE.MathUtils.damp(p.vz, (dz / distGoal) * maxSpd * spScale, accelLambda, dt);
      const tang = Math.atan2(p.vx, p.vz);
      p.facing += Math.atan2(Math.sin(tang - p.facing), Math.cos(tang - p.facing)) * (1 - Math.exp(-turnLambda * dt));

      p.aiThinkTimer -= dt;
      if (p.aiThinkTimer <= 0 && p.aiDecisionCooldown <= 0) {
        p.aiThinkTimer = diff.aiThinkPeriod;
        const shotDist = Math.abs(goalX - p.x);
        const shotChance = (shotDist < 25 ? 0.36 : 0.04) * diff.aiShotRate;
        if (shotDist < 27 && Math.random() < shotChance) {
          this.carrier = null;
          this.lastTouchSide = p.side;
          this.lastTouchPlayer = p;
          p.kickAnim = 0.36;
          this.audio.playKick(0.75);
          this.audio.pulseCrowdExcitement(0.22);
          sfx('kick');
          const aimAcc = s15.shotAccuracy / 100;
          const aimZ = THREE.MathUtils.clamp((Math.random() - 0.5) * (GOAL_W * (1.2 - aimAcc * 0.4)), -GOAL_HALF_W, GOAL_HALF_W);
          const sdx = goalX - p.x;
          const sdz = aimZ - p.z;
          const sdist = Math.hypot(sdx, sdz) || 1;
          const shotSpd = (23 + (s15.shotPower / 100) * 11) * diff.aiSpeed;
          this.ballSpinZ = (Math.random() - 0.5) * 4.5;
          this.ballVel.set((sdx / sdist) * shotSpd, 3.0, (sdz / sdist) * shotSpd);
          p.aiDecisionCooldown = 0.6;
          return;
        }
        const passPref = this.cfg.opponentStyle === 'استحواذ' ? 0.45 : 0.28;
        if (Math.random() < passPref * diff.aiVision) {
          const mates = this.players.filter((m) => m.side === p.side && m.id !== p.id && !m.sentOff && Math.hypot(m.x - p.x, m.z - p.z) < 34);
          mates.sort((a, b) => (b.x - a.x) * attackDir - Math.hypot(b.x - p.x, b.z - p.z) * 0.18);
          const mate = mates[0];
          if (mate) {
            this.carrier = null;
            this.lastTouchSide = p.side;
            this.lastTouchPlayer = p;
            p.kickAnim = 0.26;
            this.audio.playKick(0.45);
            sfx('kick');
            const pd = Math.hypot(mate.x - p.x, mate.z - p.z) || 1;
            const err = (1 - s15.passAccuracy / 100) * 0.13;
            this.ballVel.set(
              ((mate.x - p.x) / pd + (Math.random() - 0.5) * err) * 23,
              0.8,
              ((mate.z - p.z) / pd + (Math.random() - 0.5) * err) * 23,
            );
            p.aiDecisionCooldown = 0.5;
          }
        }
      }
      return;
    }

    const isChaser = p.side === 'away' && p.idx === this.activeAwayIdx;
    if (isChaser) {
      const dx = this.ballPos.x - p.x;
      const dz = this.ballPos.z - p.z;
      const d = Math.hypot(dx, dz) || 1;
      const pressBoost = (this.cfg.opponentStyle === 'ضغط عالٍ' ? 1.0 : 0.92) * diff.pressTight;
      p.vx = THREE.MathUtils.damp(p.vx, (dx / d) * maxSpd * Math.min(1.06, pressBoost), accelLambda, dt);
      p.vz = THREE.MathUtils.damp(p.vz, (dz / d) * maxSpd * Math.min(1.06, pressBoost), accelLambda, dt);
      p.facing = Math.atan2(p.vx, p.vz);
      return;
    }

    // Off-ball tactical movement: forwards make diagonal runs into channels, defenders hold cover shadow
    const posSkill = s15.positioning / 100;
    const tac = this.cfg.tactics;
    let postureShift = 0;
    if (p.side === 'home') {
      const baseLineShift = tac ? (tac.defenseLine - 5) * 1.8 : 0;
      const liveShift = this.liveTacticPosture === 'att' ? 7 : this.liveTacticPosture === 'def' ? -7 : 0;
      const styleShift = tac?.attackStyle === 'all_out' ? 5 : tac?.attackStyle === 'possession' ? 2 : tac?.attackStyle === 'counter' ? -3 : 0;
      const inst = tac?.instructions?.[p.idx] || 'balanced';
      const instShift = inst === 'push_forward' ? 8.5 : inst === 'stay_back' ? -7.5 : 0;
      postureShift = baseLineShift + liveShift + styleShift + instShift;
    } else if (this.cfg.opponentStyle === 'ضغط عالٍ') {
      postureShift = -6;
    } else if (this.cfg.opponentStyle === 'مرتدات') {
      postureShift = 6;
    }

    const ballPullX = this.ballPos.x * (0.34 + posSkill * 0.14);
    const weHaveBall = this.carrier?.side === p.side;
    // Attackers open space diagonally when their side has possession
    const channelRun = weHaveBall && p.idx >= 8 ? attackDir * (6.5 + posSkill * 5.5) : 0;
    const attackPush = weHaveBall ? attackDir * (8 + posSkill * 5) + channelRun : -attackDir * 4.5;
    const tx = THREE.MathUtils.clamp(p.baseX + ballPullX + attackPush + postureShift, -HALF_W + 3.5, HALF_W - 3.5);
    const tz = THREE.MathUtils.clamp(p.baseZ + this.ballPos.z * (0.18 + posSkill * 0.12), -HALF_D + 2.5, HALF_D - 2.5);
    const dx = tx - p.x;
    const dz = tz - p.z;
    const d = Math.hypot(dx, dz);
    if (d > 1.0) {
      p.vx = THREE.MathUtils.damp(p.vx, (dx / d) * maxSpd * 0.84, accelLambda * 0.9, dt);
      p.vz = THREE.MathUtils.damp(p.vz, (dz / d) * maxSpd * 0.84, accelLambda * 0.9, dt);
      p.facing = Math.atan2(p.vx, p.vz);
    } else {
      p.vx = THREE.MathUtils.damp(p.vx, 0, accelLambda, dt);
      p.vz = THREE.MathUtils.damp(p.vz, 0, accelLambda, dt);
    }
  }

  private updateBallPhysics(dt: number): void {
    let minAway = Infinity;
    for (const p of this.players) {
      if (p.side !== 'away' || p.isGk || p.sentOff) continue;
      const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
      if (d < minAway) {
        minAway = d;
        this.activeAwayIdx = p.idx;
      }
    }

    if (this.carrier) {
      const c = this.carrier;
      const dri = c.s15.dribbling / 100;
      const spd = Math.hypot(c.vx, c.vz);
      const isUserSprinting = c.idx === this.activeHomeIdx && c.side === 'home' && this.sprintHeld;
      // Organic rhythmic dribble foot-touches rather than static magnet glue
      const touchPush = spd > 1.2 ? Math.abs(Math.sin(c.stridePhase * 0.5)) * (isUserSprinting ? 0.36 : 0.22 - dri * 0.08) : 0;
      const lead = 0.44 - dri * 0.08 + touchPush;
      const targetBx = c.x + Math.sin(c.facing) * lead;
      const targetBz = c.z + Math.cos(c.facing) * lead;
      this.ballPos.x = THREE.MathUtils.damp(this.ballPos.x, targetBx, isUserSprinting ? 15 : 21, dt);
      this.ballPos.z = THREE.MathUtils.damp(this.ballPos.z, targetBz, isUserSprinting ? 15 : 21, dt);
      this.ballPos.y = BALL_R;
      this.ballVel.set(c.vx, 0, c.vz);

      // Physical duel & tackling check
      for (const opp of this.players) {
        if (opp.side === c.side || opp.isGk || opp.stumbleTimer > 0 || opp.sentOff) continue;
        if (c.skillTimer > 0) continue;
        const reach = 1.0 + (opp.s15.tackling / 100) * 0.28;
        if (Math.hypot(opp.x - c.x, opp.z - c.z) < reach) {
          const oppForce = opp.s15.tackling * 0.45 + opp.s15.physical * 0.35 + opp.s15.defending * 0.20;
          const carrierForce = c.s15.dribbling * 0.50 + c.s15.balance * 0.30 + c.s15.physical * 0.20;
          const stealChance = THREE.MathUtils.clamp(0.055 + (oppForce - carrierForce) * 0.0022, 0.02, 0.16);
          if (Math.random() < stealChance) {
            c.stumbleTimer = Math.max(0.18, 0.46 - (c.s15.balance / 100) * 0.22);
            this.carrier = opp;
            this.lastTouchSide = opp.side;
            this.lastTouchPlayer = opp;
            if (opp.side === 'home') {
              this.activeHomeIdx = opp.idx;
              this.lastTouchHomePlayer = opp;
            }
            this.audio.playKick(0.35);
            sfx('bounce');
            break;
          }
        }
      }
      return;
    }

    // Gravity + Magnus curl + topspin dip
    this.ballVel.y -= (20.6 + this.ballTopSpin * 0.6) * dt;
    if (this.ballPos.y > BALL_R + 0.15 && Math.abs(this.ballSpinZ) > 0.1) {
      this.ballVel.z += this.ballSpinZ * dt * 2.4;
      this.ballSpinZ *= Math.pow(0.68, dt);
    }
    this.ballPos.addScaledVector(this.ballVel, dt);

    if (this.ballPos.y <= BALL_R) {
      this.ballPos.y = BALL_R;
      if (Math.abs(this.ballVel.y) > 2.0) {
        this.ballVel.y = -this.ballVel.y * 0.56;
        sfx('bounce');
      } else {
        this.ballVel.y = 0;
      }
      const turfDrag = Math.pow(0.32, dt);
      this.ballVel.x *= turfDrag;
      this.ballVel.z *= turfDrag;
      this.ballSpinZ *= Math.pow(0.25, dt);
      this.ballTopSpin *= Math.pow(0.25, dt);
    } else {
      const airDrag = Math.pow(0.86, dt);
      this.ballVel.x *= airDrag;
      this.ballVel.z *= airDrag;
    }

    // Goalposts & Crossbar cylindrical collisions
    for (const dir of [-1, 1]) {
      const gx = dir * HALF_W;
      for (const pz of [-GOAL_HALF_W, GOAL_HALF_W]) {
        const pd = Math.hypot(this.ballPos.x - gx, this.ballPos.z - pz);
        if (pd < BALL_R + 0.11 && this.ballPos.y < GOAL_H + 0.11) {
          this.ballVel.x = -this.ballVel.x * 0.72;
          this.ballVel.z += (this.ballPos.z - pz) * 5;
          this.audio.playPostClang();
          this.setCommentary('💥 يا إلهي! الكرة ترتطم بالقائم!');
          sfx('post');
        }
      }
      if (Math.abs(this.ballPos.z) <= GOAL_HALF_W + 0.12) {
        const barDist = Math.hypot(this.ballPos.x - gx, this.ballPos.y - GOAL_H);
        if (barDist < BALL_R + 0.11) {
          this.ballVel.x = -this.ballVel.x * 0.65;
          this.ballVel.y = -this.ballVel.y * 0.65;
          this.audio.playPostClang();
          this.setCommentary('💥 العارضة تحرم الفريق من هدف محقق!');
          sfx('post');
        }
      }
    }

    // Goal detection
    if (Math.abs(this.ballPos.z) < GOAL_HALF_W - 0.1 && this.ballPos.y < GOAL_H) {
      if (this.ballPos.x > HALF_W + BALL_R * 0.45) {
        this.homeGoals++;
        this.onGoalScored('home', 1);
        return;
      }
      if (this.ballPos.x < -HALF_W - BALL_R * 0.45) {
        this.awayGoals++;
        this.onGoalScored('away', -1);
        return;
      }
    }

    // Real Throw-In / Corner Kick / Goal Kick restarts
    const boundary = classifyBoundaryExit(this.ballPos.x, this.ballPos.z, this.lastTouchSide);
    if (boundary) {
      this.pendingPass = null;
      this.audio.playWhistle('short');
      sfx('whistle');
      this.ballPos.set(boundary.x, BALL_R, boundary.z);
      this.ballVel.set(0, 0, 0);
      this.ballSpinZ = 0;

      // Find nearest eligible player on restarting team to put ball back in play
      const candidates = this.players.filter((p) => p.side === boundary.team && !p.sentOff && (boundary.type === 'goal_kick' ? p.isGk : !p.isGk));
      candidates.sort((a, b) => Math.hypot(a.x - boundary.x, a.z - boundary.z) - Math.hypot(b.x - boundary.x, b.z - boundary.z));
      const taker = candidates[0];
      if (taker) {
        taker.x = boundary.x;
        taker.z = boundary.z;
        this.carrier = taker;
        this.lastTouchSide = boundary.team;
        this.lastTouchPlayer = taker;
        if (boundary.team === 'home' && !taker.isGk) this.activeHomeIdx = taker.idx;
      }

      if (boundary.type === 'throw_in') {
        this.setCommentary(`✋ رمية تماس لصالح ${boundary.team === 'home' ? this.homeTeam.name : this.awayTeam.name}`);
      } else if (boundary.type === 'corner') {
        this.showBanner(`🚩 ركلة ركنية لصالح ${boundary.team === 'home' ? this.homeTeam.name : this.awayTeam.name}!`, 1400);
        this.setCommentary(`🚩 ركلة ركنية خطيرة!`);
      } else {
        this.setCommentary(`🧤 ضربة مرمى لصالح ${boundary.team === 'home' ? this.homeTeam.name : this.awayTeam.name}`);
      }
      return;
    }

    // Ball trap / header interception / body collision
    if (this.ballPos.y < 1.98) {
      const ballSpeed = Math.hypot(this.ballVel.x, this.ballVel.z);
      for (const p of this.players) {
        if (p.isGk || p.stumbleTimer > 0 || p.sentOff) continue;
        const trapR = p.side === 'home' ? 1.02 + (p.s15.dribbling / 100) * 0.26 : 1.02 + (p.s15.defending / 100) * 0.26;
        const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
        if (d < trapR) {
          // Check Offside violation if targeted receiver receives pass while offside
          if (
            this.pendingPass &&
            performance.now() < this.pendingPass.expiresAt &&
            p.id === this.pendingPass.receiverId
          ) {
            this.pendingPass = null;
            this.audio.playWhistle('short');
            sfx('whistle');
            const freeSide: 'home' | 'away' = p.side === 'home' ? 'away' : 'home';
            const defKeeper = this.players.find((dPly) => dPly.side === freeSide && dPly.isGk) || this.players.find((dPly) => dPly.side === freeSide && !dPly.sentOff);
            this.ballVel.set(0, 0, 0);
            this.carrier = defKeeper || null;
            this.lastTouchSide = freeSide;
            this.showBanner('🚩 تسلل! ضربة حرة غير مباشرة', 1600);
            this.setCommentary('🚩 راية التسلل ترفع ضد المهاجم');
            break;
          }

          if (this.ballPos.y > 1.15 && this.ballPos.y < 1.98) {
            p.vy = 4.9;
            p.headerTimer = 0.42;
            const headDirX = Math.sin(p.facing);
            const headDirZ = Math.cos(p.facing);
            this.ballVel.set(headDirX * 16.5, 2.2, headDirZ * 16.5);
            this.lastTouchSide = p.side;
            this.lastTouchPlayer = p;
            if (p.side === 'home') this.lastTouchHomePlayer = p;
            this.audio.playKick(0.5);
            sfx('kick');
            break;
          }

          // Physical body deflection instead of ball passing straight through legs/torso
          if (ballSpeed > 23.5 && Math.random() > 0.36 + (p.s15.dribbling / 100) * 0.62) {
            const nx = (this.ballPos.x - p.x) / Math.max(0.1, d);
            const nz = (this.ballPos.z - p.z) / Math.max(0.1, d);
            this.ballPos.x = p.x + nx * 0.55;
            this.ballPos.z = p.z + nz * 0.55;
            this.ballVel.multiplyScalar(0.32);
            sfx('bounce');
            break;
          }

          this.carrier = p;
          this.lastTouchSide = p.side;
          this.lastTouchPlayer = p;
          if (p.side === 'home') {
            if (this.cfg.careerMode !== 'player') this.activeHomeIdx = p.idx;
            this.lastTouchHomePlayer = p;
          }
          break;
        }
      }
    }
  }

  private onGoalScored(scoringSide: 'home' | 'away', netSide: number): void {
    this.phase = 'goal';
    this.phaseTimer = 2.05;
    this.netImpactTimer = 1.45;
    this.netImpactSide = netSide;
    this.crowdWaveTimer = 2.4;
    this.ballVel.multiplyScalar(0.22);
    this.audio.pulseCrowdExcitement(0.42);
    this.audio.playWhistle('short');

    if (scoringSide === 'home' && this.lastTouchHomePlayer) {
      this.goalScorerFocus = this.lastTouchHomePlayer;
      this.scorers.push({ playerId: this.lastTouchHomePlayer.info.id, name: this.lastTouchHomePlayer.info.name });
      if (this.cfg.careerMode === 'player') {
        if (this.lastTouchHomePlayer.idx === this.cfg.proSlotIdx) this.proGoals++;
        else if (this.prevTouchHomePlayer?.idx === this.cfg.proSlotIdx) this.proAssists++;
      }
    } else if (this.lastTouchPlayer) {
      this.goalScorerFocus = this.lastTouchPlayer;
    }

    if (this.scoreEl) this.scoreEl.textContent = `${this.homeGoals} - ${this.awayGoals}`;
    sfx('goal');
    const teamLabel = scoringSide === 'home' ? this.homeTeam.name : this.awayTeam.name;
    const scorerName = this.goalScorerFocus?.info.name || teamLabel;
    this.showBanner(`⚽ جووول! ${scorerName} يسجل لصالح ${teamLabel}!`, 2100);
    this.setCommentary(`⚽ هدف رائع! ${scorerName} يهز الشباك لصالح ${teamLabel}!`);
    window.setTimeout(() => {
      if (!this.destroyed && this.phase === 'goal') {
        this.resetKickoff(scoringSide === 'home' ? 'away' : 'home');
      }
    }, 1850);
  }

  private updateMeshes(dt: number): void {
    const ctrl = this.getControlledHome();
    if (this.playerLabelEl) {
      this.playerLabelEl.textContent = `${ctrl.info.name} · #${ctrl.info.jerseyNo} (${ctrl.heightCm}cm)`;
    }
    if (this.staminaFillEl) this.staminaFillEl.style.width = `${Math.round(ctrl.stamina)}%`;

    const ballDxCam = this.ballPos.x;
    const ballDzCam = this.ballPos.z;
    const nowSec = performance.now() * 0.0026;

    for (const p of this.players) {
      if (p.sentOff) continue;
      p.group.position.set(p.x, p.y, p.z);
      const skillSpin = p.skillTimer > 0 ? Math.sin((p.skillTimer / 0.52) * Math.PI) * (Math.PI * 2) : 0;
      p.group.rotation.y = p.facing + skillSpin;

      const angleToBall = Math.atan2(ballDxCam - p.x, ballDzCam - p.z);
      const relHeadYaw = THREE.MathUtils.clamp(Math.atan2(Math.sin(angleToBall - p.facing), Math.cos(angleToBall - p.facing)), -0.65, 0.65);

      const spd = Math.hypot(p.vx, p.vz);
      const sprint01 = THREE.MathUtils.clamp((spd - 4.5) / 5.5, 0, 1);

      // Build continuous target pose across states, then damp every joint smoothly
      _poseTarget.headYaw = relHeadYaw * 0.55;
      _poseTarget.headPitch = 0;

      if (p.diveTimer > 0) {
        _poseTarget.pelvisY = 0.56;
        _poseTarget.pelvisRotX = 0;
        _poseTarget.pelvisRotZ = p.diveDir * 1.15;
        _poseTarget.torsoRotX = 0.15;
        _poseTarget.torsoRotY = 0;
        _poseTarget.lShX = -2.6;
        _poseTarget.lShZ = -0.3;
        _poseTarget.rShX = -2.6;
        _poseTarget.rShZ = 0.3;
        _poseTarget.lElbX = -0.15;
        _poseTarget.rElbX = -0.15;
        _poseTarget.lHipX = -0.25;
        _poseTarget.lHipZ = 0.08;
        _poseTarget.rHipX = 0.25;
        _poseTarget.rHipZ = -0.08;
        _poseTarget.lKneeX = 0.45;
        _poseTarget.rKneeX = 0.2;
      } else if (p.tackleTimer > 0) {
        _poseTarget.pelvisY = 0.48;
        _poseTarget.pelvisRotX = -0.35;
        _poseTarget.pelvisRotZ = 0.22;
        _poseTarget.torsoRotX = -0.1;
        _poseTarget.torsoRotY = 0;
        _poseTarget.rHipX = -1.25;
        _poseTarget.rHipZ = -0.05;
        _poseTarget.rKneeX = 0.12;
        _poseTarget.lHipX = 0.45;
        _poseTarget.lHipZ = 0.05;
        _poseTarget.lKneeX = 1.25;
        _poseTarget.lShX = 0.5;
        _poseTarget.lShZ = -0.2;
        _poseTarget.lElbX = -0.5;
        _poseTarget.rShX = -0.6;
        _poseTarget.rShZ = 0.2;
        _poseTarget.rElbX = -0.5;
      } else if (p.headerTimer > 0) {
        const hPhase = Math.sin((p.headerTimer / 0.42) * Math.PI);
        _poseTarget.pelvisY = 0.96;
        _poseTarget.pelvisRotX = 0;
        _poseTarget.pelvisRotZ = 0;
        _poseTarget.torsoRotX = 0.38 * hPhase;
        _poseTarget.torsoRotY = 0;
        _poseTarget.headPitch = 0.25 * hPhase;
        _poseTarget.lShX = -0.35;
        _poseTarget.lShZ = -0.65;
        _poseTarget.rShX = -0.35;
        _poseTarget.rShZ = 0.65;
        _poseTarget.lElbX = -0.6;
        _poseTarget.rElbX = -0.6;
        _poseTarget.lHipX = -0.3;
        _poseTarget.lHipZ = 0.05;
        _poseTarget.rHipX = 0.3;
        _poseTarget.rHipZ = -0.05;
        _poseTarget.lKneeX = 0.7;
        _poseTarget.rKneeX = 0.7;
      } else if (spd > 0.35) {
        p.stridePhase += spd * dt * 2.15;
        const sinP = Math.sin(p.stridePhase);
        const legAmp = 0.46 + sprint01 * 0.48;
        _poseTarget.pelvisY = 0.94 + Math.abs(Math.cos(p.stridePhase)) * (0.03 + sprint01 * 0.045);
        _poseTarget.pelvisRotX = 0;
        _poseTarget.pelvisRotZ = p.bankAngle;
        _poseTarget.lHipX = sinP * legAmp;
        _poseTarget.lHipZ = 0.03;
        _poseTarget.lKneeX = Math.max(0.08, -Math.cos(p.stridePhase) * 0.78 + 0.42);
        _poseTarget.rHipZ = -0.03;

        if (p.kickAnim > 0) {
          const kNorm = 1 - p.kickAnim / 0.40;
          const whip = kNorm < 0.35 ? 0.55 : -1.15 * Math.sin(kNorm * Math.PI);
          if (p.kickSide > 0) {
            _poseTarget.rHipX = whip;
            _poseTarget.rKneeX = kNorm < 0.35 ? 1.15 : 0.18;
          } else {
            _poseTarget.lHipX = whip;
            _poseTarget.lKneeX = kNorm < 0.35 ? 1.15 : 0.18;
            _poseTarget.rHipX = -sinP * legAmp;
            _poseTarget.rKneeX = Math.max(0.08, Math.cos(p.stridePhase) * 0.78 + 0.42);
          }
          _poseTarget.torsoRotY = p.kickSide * -0.28;
        } else {
          _poseTarget.rHipX = -sinP * legAmp;
          _poseTarget.rKneeX = Math.max(0.08, Math.cos(p.stridePhase) * 0.78 + 0.42);
          _poseTarget.torsoRotY = -sinP * (0.10 + sprint01 * 0.10);
        }
        _poseTarget.torsoRotX = 0.08 + sprint01 * 0.18;
        _poseTarget.lShX = -sinP * (0.48 + sprint01 * 0.38);
        _poseTarget.lShZ = -0.10;
        _poseTarget.rShX = sinP * (0.48 + sprint01 * 0.38);
        _poseTarget.rShZ = 0.10;
        _poseTarget.lElbX = -0.82 - sprint01 * 0.32;
        _poseTarget.rElbX = -0.82 - sprint01 * 0.32;
      } else {
        const breath = Math.sin(nowSec + p.idx) * 0.015;
        _poseTarget.pelvisY = p.isGk ? 0.88 : 0.94 + breath;
        _poseTarget.pelvisRotX = 0;
        _poseTarget.pelvisRotZ = p.stumbleTimer > 0 ? 0.28 : 0;
        _poseTarget.torsoRotX = p.isGk ? 0.18 : 0.03;
        _poseTarget.torsoRotY = 0;
        _poseTarget.lHipX = p.isGk ? -0.18 : 0;
        _poseTarget.lHipZ = 0.04;
        _poseTarget.lKneeX = p.isGk ? 0.36 : 0.06;
        _poseTarget.rHipX = p.kickAnim > 0 ? -1.05 : p.isGk ? -0.18 : 0;
        _poseTarget.rHipZ = -0.04;
        _poseTarget.rKneeX = p.kickAnim > 0 ? 0.22 : p.isGk ? 0.36 : 0.06;
        _poseTarget.lShX = p.isGk ? -0.45 : 0.04;
        _poseTarget.lShZ = p.isGk ? -0.25 : -0.09;
        _poseTarget.rShX = p.isGk ? -0.45 : 0.04;
        _poseTarget.rShZ = p.isGk ? 0.25 : 0.09;
        _poseTarget.lElbX = p.isGk ? -0.85 : -0.22;
        _poseTarget.rElbX = p.isGk ? -0.85 : -0.22;
      }

      // Smooth continuous blend across all states (Zero abrupt pose snapping!)
      const blendLambda = p.diveTimer > 0 || p.tackleTimer > 0 || p.kickAnim > 0 ? 22 : 14;
      dampPose(p.pose, _poseTarget, blendLambda, dt);

      p.pelvis.position.y = p.pose.pelvisY;
      p.pelvis.rotation.set(p.pose.pelvisRotX, 0, p.pose.pelvisRotZ);
      p.torso.rotation.set(p.pose.torsoRotX, p.pose.torsoRotY, 0);
      p.headGroup.rotation.set(p.pose.headPitch, p.pose.headYaw, 0);
      p.leftHip.rotation.set(p.pose.lHipX, 0, p.pose.lHipZ);
      p.leftKnee.rotation.x = p.pose.lKneeX;
      p.rightHip.rotation.set(p.pose.rHipX, 0, p.pose.rHipZ);
      p.rightKnee.rotation.x = p.pose.rKneeX;
      p.leftShoulder.rotation.set(p.pose.lShX, 0, p.pose.lShZ);
      p.leftElbow.rotation.x = p.pose.lElbX;
      p.rightShoulder.rotation.set(p.pose.rShX, 0, p.pose.rShZ);
      p.rightElbow.rotation.x = p.pose.rElbX;
    }

    this.ballMesh.position.copy(this.ballPos);
    const bSpd = Math.hypot(this.ballVel.x, this.ballVel.z);
    if (bSpd > 0.05) {
      _v1.set(this.ballVel.z, 0, -this.ballVel.x).normalize();
      _qStep.setFromAxisAngle(_v1, (bSpd * dt) / BALL_R);
      this.ballMesh.quaternion.premultiply(_qStep);
    }
    this.ballShadow.position.set(this.ballPos.x, 0.02, this.ballPos.z);

    this.activeRing.position.set(ctrl.x, 0.03, ctrl.z);
    const mate = this.findBestHomeTeammate(ctrl, ctrl.s15.vision);
    if (mate && this.carrier?.side === 'home') {
      this.passRing.visible = true;
      this.passRing.position.set(mate.x, 0.025, mate.z);
    } else {
      this.passRing.visible = false;
    }

    if (this.crowdMesh && this.crowdWaveTimer > 0) {
      this.crowdWaveTimer = Math.max(0, this.crowdWaveTimer - dt);
      const t = performance.now() * 0.011;
      for (let i = 0; i < this.crowdBaseData.length; i++) {
        const c = this.crowdBaseData[i];
        const hop = Math.abs(Math.sin(t + c.phase)) * 0.45 * Math.min(1, this.crowdWaveTimer);
        _dummyObj.position.set(c.x, c.y + hop, c.z);
        _dummyObj.updateMatrix();
        this.crowdMesh.setMatrixAt(i, _dummyObj.matrix);
      }
      this.crowdMesh.instanceMatrix.needsUpdate = true;
    }

    // Dynamic Goal Celebration Camera or Telephoto Broadcast Framing
    if (this.phase === 'goal' && this.goalScorerFocus) {
      const sc = this.goalScorerFocus;
      _v2.set(sc.x, 1.45, sc.z);
      this.camTarget.x = THREE.MathUtils.damp(this.camTarget.x, _v2.x, 6.5, dt);
      this.camTarget.y = THREE.MathUtils.damp(this.camTarget.y, _v2.y, 6.5, dt);
      this.camTarget.z = THREE.MathUtils.damp(this.camTarget.z, _v2.z, 6.5, dt);
      this.camPos.x = THREE.MathUtils.damp(this.camPos.x, sc.x - 4.8, 4.5, dt);
      this.camPos.y = THREE.MathUtils.damp(this.camPos.y, 3.1, 4.5, dt);
      this.camPos.z = THREE.MathUtils.damp(this.camPos.z, sc.z + 5.8, 4.5, dt);
    } else {
      const lookAheadX = this.ballVel.x * 0.08;
      const targetX = this.cameraMode === 'focus' ? ctrl.x : this.ballPos.x * 0.84 + lookAheadX;
      const targetZ = this.cameraMode === 'focus' ? ctrl.z : this.ballPos.z * 0.68;
      _v2.set(targetX, 1.08, targetZ);
      this.camTarget.x = THREE.MathUtils.damp(this.camTarget.x, _v2.x, 6.2, dt);
      this.camTarget.y = THREE.MathUtils.damp(this.camTarget.y, 1.08, 6.2, dt);
      this.camTarget.z = THREE.MathUtils.damp(this.camTarget.z, _v2.z, 6.2, dt);

      const distScale = 1 / this.cameraZoom;
      let desiredCamX = this.camTarget.x;
      let desiredCamY = 10.8 * distScale;
      let desiredCamZ = (20.6 + this.camTarget.z * 0.35) * distScale;
      if (this.cameraMode === 'dynamic') {
        desiredCamX = this.camTarget.x + this.ballVel.x * 0.14;
        desiredCamY = (8.4 + Math.abs(this.ballPos.z) * 0.04) * distScale;
        desiredCamZ = (16.0 + this.camTarget.z * 0.42) * distScale;
      } else if (this.cameraMode === 'close') {
        desiredCamY = 6.1 * distScale;
        desiredCamZ = (11.8 + this.camTarget.z * 0.5) * distScale;
      } else if (this.cameraMode === 'wide') {
        desiredCamY = 16.5 * distScale;
        desiredCamZ = 27.5 * distScale;
        desiredCamX *= 0.65;
      } else if (this.cameraMode === 'tele') {
        desiredCamY = 23.0 * distScale;
        desiredCamZ = 14.0 * distScale;
        desiredCamX *= 0.72;
      } else if (this.cameraMode === 'focus') {
        desiredCamX = ctrl.x - 8.2 * distScale;
        desiredCamY = 4.6 * distScale;
        desiredCamZ = ctrl.z + 9.6 * distScale;
      }

      this.camPos.x = THREE.MathUtils.damp(this.camPos.x, desiredCamX, 5.2, dt);
      this.camPos.y = THREE.MathUtils.damp(this.camPos.y, desiredCamY, 5.2, dt);
      this.camPos.z = THREE.MathUtils.damp(this.camPos.z, desiredCamZ, 5.2, dt);
    }

    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camTarget);
  }

  private drawRadarMinimap(): void {
    const ctx = this.radarCtx;
    if (!ctx) return;
    const w = ctx.canvas.width;
    const h = ctx.canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Translucent pitch lines
    ctx.fillStyle = 'rgba(14, 52, 24, 0.72)';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.42)';
    ctx.lineWidth = 1;
    ctx.strokeRect(2, 2, w - 4, h - 4);
    ctx.beginPath();
    ctx.moveTo(w / 2, 2);
    ctx.lineTo(w / 2, h - 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, 12, 0, Math.PI * 2);
    ctx.stroke();

    const toRx = (x: number) => ((x + HALF_W) / PITCH_W) * (w - 8) + 4;
    const toRy = (z: number) => ((z + HALF_D) / PITCH_D) * (h - 8) + 4;

    const homeColor = this.homeTeam.primary || '#ef4444';
    const awayColor = this.awayTeam.primary || '#f8fafc';
    for (const p of this.players) {
      if (p.sentOff) continue;
      const rx = toRx(p.x);
      const ry = toRy(p.z);
      ctx.beginPath();
      ctx.arc(rx, ry, p.side === 'home' && p.idx === this.activeHomeIdx ? 4.2 : 2.8, 0, Math.PI * 2);
      ctx.fillStyle = p.side === 'home' ? homeColor : awayColor;
      ctx.fill();
      if (p.side === 'home' && p.idx === this.activeHomeIdx) {
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1.4;
        ctx.stroke();
      }
    }

    // Ball dot
    ctx.beginPath();
    ctx.arc(toRx(this.ballPos.x), toRy(this.ballPos.z), 3.1, 0, Math.PI * 2);
    ctx.fillStyle = '#facc15';
    ctx.fill();
  }

  private render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  private finishMatch(): void {
    if (this.phase === 'fulltime') return;
    this.phase = 'fulltime';
    this.audio.playWhistle('fulltime');
    sfx('whistle');
    const totalPoss = Math.max(0.1, this.homePossTime + this.awayPossTime);
    const possessionPct = Math.round((this.homePossTime / totalPoss) * 100);
    this.onMatchEnd({
      homeName: this.homeTeam.name,
      awayName: this.awayTeam.name,
      homeTeamId: this.homeTeam.id,
      awayTeamId: this.awayTeam.id,
      homeGoals: this.homeGoals,
      awayGoals: this.awayGoals,
      possessionPct,
      shots: this.homeShots,
      shotsOnTarget: this.homeShotsOnTarget,
      passes: this.homePasses,
      fouls: this.homeFouls,
      difficulty: this.cfg.difficulty,
      durationSec: Math.max(30, Math.round(this.homePossTime + this.awayPossTime)),
      scorers: this.scorers,
      careerMode: this.cfg.careerMode || null,
      proGoals: this.proGoals,
      proAssists: this.proAssists,
    });
  }

  public dispose(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    if (this.timerId !== null) clearTimeout(this.timerId);
    this.audio.dispose();
    this.turfParticles?.dispose();
    this.disposables.forEach((d) => {
      try {
        d.dispose();
      } catch {
        // ignore
      }
    });
    this.envRenderTarget?.dispose();
    this.pmremGenerator?.dispose();
    this.renderer?.dispose();
    this.container.innerHTML = '';
  }

  private disposeAndExit(): void {
    this.dispose();
    this.onExit();
  }
}

let activeEngine: Football3DEngine | null = null;

function launchEngineWithConfig(overlay: HTMLElement, cfg: MatchConfig, closeAll: () => void): void {
  sfx('click');
  try {
    (screen.orientation as any)?.lock?.('landscape').catch(() => {});
  } catch {
    // ignore
  }
  activeEngine = new Football3DEngine(
    overlay,
    cfg,
    async (summary) => {
      activeEngine?.dispose();
      activeEngine = null;
      window.MYAIFootballHub?.recordMatchOutcome?.(summary);
      let rewardText = '';
      try {
        if (typeof window.myaiApiFetch === 'function' && navigator.onLine !== false) {
          const res = await window.myaiApiFetch('/api/football3d/complete', {
            method: 'POST',
            body: JSON.stringify({
              homeTeam: summary.homeName,
              awayTeam: summary.awayName,
              homeGoals: summary.homeGoals,
              awayGoals: summary.awayGoals,
              difficulty: summary.difficulty,
              possessionPct: summary.possessionPct,
              shots: summary.shots,
              shotsOnTarget: summary.shotsOnTarget,
              passes: summary.passes,
              durationSec: summary.durationSec,
            }),
          });
          if (res?.rewardAdded > 0) {
            sfx('coin');
            rewardText = `🎁 مكافأة المباراة: +${res.rewardAdded} نقطة!`;
          }
        }
      } catch {
        // offline
      }
      const won = summary.homeGoals > summary.awayGoals;
      overlay.innerHTML = `
        <div class="myai-f3d-lobby">
          <div class="myai-pro-card" style="text-align:center">
            <h2>${won ? '🏆 فوز مستحق!' : summary.homeGoals === summary.awayGoals ? '🤝 تعادل مثير!' : '⚽ صافرة النهاية'}</h2>
            <p style="font-size:30px;font-weight:900;margin:10px 0">${escHtml(summary.homeName)} ${summary.homeGoals} - ${summary.awayGoals} ${escHtml(summary.awayName)}</p>
            ${rewardText ? `<p class="myai-badge ok">${rewardText}</p>` : ''}
            <div class="myai-v3-stat" style="margin:12px 0">
              <div><strong>${summary.possessionPct}%</strong>الاستحواذ</div>
              <div><strong>${summary.shots} (${summary.shotsOnTarget})</strong>التسديدات (على المرمى)</div>
              <div><strong>${summary.passes}</strong>التمريرات</div>
              <div><strong>${escHtml(summary.difficulty)}</strong>المستوى</div>
            </div>
            <div class="myai-pro-grid2">
              <button type="button" class="primary" id="f3dRematchBtn">🔁 مباراة جديدة</button>
              <button type="button" class="myai-v3-btn" id="f3dOpenHubAfterBtn">🏆 العودة لمركز MY AI FOOTBALL</button>
              <button type="button" class="myai-v3-btn" id="f3dDoneCloseBtn">إغلاق</button>
            </div>
          </div>
        </div>
      `;
      document.getElementById('f3dRematchBtn')?.addEventListener('click', () => mountFootball3DOverlay({ homeTeamId: cfg.homeTeamId, awayTeamId: cfg.awayTeamId }));
      document.getElementById('f3dOpenHubAfterBtn')?.addEventListener('click', () => {
        closeAll();
        window.MYAIFootballHub?.openHub?.(cfg.careerMode === 'player' ? 'player_career' : cfg.careerMode === 'manager' ? 'manager_career' : 'kickoff');
      });
      document.getElementById('f3dDoneCloseBtn')?.addEventListener('click', closeAll);
    },
    closeAll,
  );
}

function mountFootball3DOverlay(opts?: Record<string, any>): void {
  window.closeFeature?.();
  if (activeEngine) {
    activeEngine.dispose();
    activeEngine = null;
  }
  document.getElementById('myaiFootball3dOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'myaiFootball3dOverlay';
  overlay.className = 'myai-f3d-overlay';
  document.body.appendChild(overlay);
  document.body.style.overflow = 'hidden';

  const closeAll = () => {
    activeEngine?.dispose();
    activeEngine = null;
    overlay.remove();
    document.body.style.overflow = '';
  };

  if (opts?.homeSquad && opts?.tactics && opts?.controlPreset) {
    const ms = opts.matchSettings || {};
    const cfg: MatchConfig = {
      homeTeamId: String(opts.homeTeamId || 'liverpool'),
      awayTeamId: String(opts.awayTeamId || 'real_madrid'),
      homeTeam: opts.homeTeam,
      awayTeam: opts.awayTeam,
      homeSquad: opts.homeSquad,
      homeBench: opts.homeBench,
      awaySquad: opts.awaySquad,
      tactics: opts.tactics,
      controlPreset: opts.controlPreset,
      formation: (opts.tactics?.formation as FormationKey) || '4-3-3',
      halfSeconds: Number(ms.halfSeconds || 90),
      difficulty: (ms.difficulty as DifficultyKey) || 'متوسط',
      lighting: (ms.lighting as LightingKey) || 'night',
      quality: (ms.quality as QualityKey) || 'medium',
      camera: (ms.camera as CameraModeKey) || 'broadcast',
      cameraZoom: Number(ms.cameraZoom || 1.0),
      gameSpeed: ms.gameSpeed || 'normal',
      opponentStrength: ms.opponentStrength || 'قوي',
      gkLevel: ms.gkLevel || 'متميز',
      opponentStyle: ms.opponentStyle || 'متوازن',
      controlAssist: ms.controlAssist || 'شبه مساعد',
      careerMode: opts.careerMode || null,
      proSlotIdx: typeof opts.proSlotIdx === 'number' ? opts.proSlotIdx : -1,
    };
    launchEngineWithConfig(overlay, cfg, closeAll);
    return;
  }

  const db = window.MYAI_PLAYERS_DB;
  const teams: TeamInfo[] = db?.TEAMS || [
    { id: 'myai_united', name: 'MY AI يونايتد', nameEn: 'MY AI United', league: 'local', country: 'MY AI', primary: '#ff142e', secondary: '#111111', ovr: 84, formation: '4-3-3' },
    { id: 'real_madrid', name: 'ريال مدريد', nameEn: 'Real Madrid', league: 'la_liga', country: 'إسبانيا', primary: '#f5f5f5', secondary: '#d4af37', ovr: 89, formation: '4-3-3' },
  ];
  const hubPayload = window.MYAIFootballHub?.getActiveMatchPayload?.(opts);
  const ms = hubPayload?.matchSettings || {};
  const homeDefault = String(opts?.homeTeamId || hubPayload?.homeTeamId || 'liverpool');
  const awayDefault = String(opts?.awayTeamId || hubPayload?.awayTeamId || 'real_madrid');

  overlay.innerHTML = `
    <div class="myai-f3d-lobby">
      <div class="myai-f3d-lobby-head">
        <div>
          <h2>⚽ MY AI FOOTBALL · NEXT-GEN 3D ENGINE</h2>
          <p>أجسام بشرية نحتية 1:7.5 · 15 مهارة حقيقية · رادار مباشر · تسلل وركلات حرة وجزاء · 6 مستويات ذكاء</p>
        </div>
        <button type="button" class="feature-close" id="f3dLobbyClose">×</button>
      </div>

      <div class="myai-pro-card">
        <div class="myai-pro-grid2">
          <div>
            <label>فريقك (Home)</label>
            <select id="f3dHomeTeam" class="feature-field">
              ${teams.map((t) => `<option value="${escHtml(t.id)}" ${t.id === homeDefault ? 'selected' : ''}>${escHtml(t.name)} (OVR ${t.ovr})</option>`).join('')}
            </select>
          </div>
          <div>
            <label>الخصم (Away)</label>
            <select id="f3dAwayTeam" class="feature-field">
              ${teams.map((t) => `<option value="${escHtml(t.id)}" ${t.id === awayDefault ? 'selected' : ''}>${escHtml(t.name)} (OVR ${t.ovr})</option>`).join('')}
            </select>
          </div>
          <div>
            <label>التشكيلة التكتيكية</label>
            <select id="f3dFormation" class="feature-field">
              <option value="4-3-3">4-3-3 هجومية</option>
              <option value="4-2-3-1">4-2-3-1 صانع ألعاب</option>
              <option value="4-4-2">4-4-2 متوازنة</option>
              <option value="3-5-2">3-5-2 سيطرة وسط</option>
              <option value="5-3-2">5-3-2 تأمين ومرتدات</option>
            </select>
          </div>
          <div>
            <label>مستوى صعوبة المباراة</label>
            <select id="f3dDifficulty" class="feature-field">
              <option value="مبتدئ">مبتدئ</option>
              <option value="سهل">سهل</option>
              <option value="متوسط" selected>متوسط</option>
              <option value="صعب">صعب</option>
              <option value="محترف">محترف</option>
              <option value="أسطوري">أسطوري</option>
            </select>
          </div>
          <div>
            <label>قوة المنافس ومستوى الحارس</label>
            <div style="display:flex;gap:6px">
              <select id="f3dOppStrength" class="feature-field" style="flex:1">
                <option value="عادي">قوة: عادي</option>
                <option value="قوي" selected>قوة: قوي</option>
                <option value="نخبة">قوة: نخبة</option>
              </select>
              <select id="f3dGkLevel" class="feature-field" style="flex:1">
                <option value="عادي">حارس: عادي</option>
                <option value="متميز" selected>حارس: متميز</option>
                <option value="أسطوري">حارس: أسطوري</option>
              </select>
            </div>
          </div>
          <div>
            <label>أسلوب الخصم ومساعدة التحكم</label>
            <div style="display:flex;gap:6px">
              <select id="f3dOppStyle" class="feature-field" style="flex:1">
                <option value="متوازن" selected>متوازن</option>
                <option value="استحواذ">استحواذ</option>
                <option value="مرتدات">مرتدات</option>
                <option value="ضغط عالٍ">ضغط عالٍ</option>
              </select>
              <select id="f3dControlAssist" class="feature-field" style="flex:1">
                <option value="يدوي">يدوي</option>
                <option value="شبه مساعد" selected>شبه مساعد</option>
                <option value="مساعد كامل">مساعد كامل</option>
              </select>
            </div>
          </div>
          <div>
            <label>المدة والزاوية وتقريب الكاميرا (<span id="f3dLobbyZoomLbl">${Math.round((ms.cameraZoom || 1) * 100)}</span>%)</label>
            <div style="display:flex;gap:6px;align-items:center">
              <select id="f3dHalfSec" class="feature-field" style="flex:1;margin:0">
                <option value="60">60ث</option>
                <option value="90" selected>90ث</option>
                <option value="120">120ث</option>
                <option value="180">180ث</option>
              </select>
              <select id="f3dCamSelect" class="feature-field" style="flex:1;margin:0">
                <option value="broadcast" selected>بث تلفزيوني</option>
                <option value="dynamic">ديناميكية</option>
                <option value="close">قريبة</option>
                <option value="wide">واسعة</option>
                <option value="tele">علوية</option>
                <option value="focus">تركيز</option>
              </select>
              <input id="f3dZoomSlider" type="range" min="0.7" max="1.35" step="0.05" value="${ms.cameraZoom || 1}" style="flex:1" oninput="const el=document.getElementById('f3dLobbyZoomLbl');if(el)el.textContent=Math.round(this.value*100)">
            </div>
          </div>
          <div>
            <label>الأجواء وجودة الجرافيك</label>
            <div style="display:flex;gap:6px">
              <select id="f3dLighting" class="feature-field" style="flex:1">
                <option value="night" selected>ليلي ✨</option>
                <option value="day">نهاري ☀️</option>
              </select>
              <select id="f3dQuality" class="feature-field" style="flex:1">
                <option value="low">منخفض</option>
                <option value="medium" selected>متوسط</option>
                <option value="high">مرتفع</option>
                <option value="ultra">فائق</option>
              </select>
            </div>
          </div>
        </div>
        <div class="myai-pro-grid2" style="margin-top:8px">
          <button type="button" class="primary" id="f3dStartBtn">⚽ انطلاق المباراة 3D الآن</button>
          <button type="button" class="myai-v3-btn" id="f3dOpenFranchiseBtn">🏆 السوق والتكتيك والمهنة والبطاقات</button>
          <button type="button" class="myai-v3-btn" id="f3dFullscreenBtn">📱 ملء الشاشة بالعرض Landscape</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('f3dLobbyClose')?.addEventListener('click', closeAll);
  document.getElementById('f3dOpenFranchiseBtn')?.addEventListener('click', () => {
    closeAll();
    window.MYAIFootballHub?.openHub?.('kickoff');
  });
  document.getElementById('f3dFullscreenBtn')?.addEventListener('click', () => {
    try {
      overlay.requestFullscreen?.().catch(() => {});
      (screen.orientation as any)?.lock?.('landscape').catch(() => {});
    } catch {
      // ignore
    }
  });

  document.getElementById('f3dStartBtn')?.addEventListener('click', () => {
    const hId = (document.getElementById('f3dHomeTeam') as HTMLSelectElement)?.value || homeDefault;
    const aId = (document.getElementById('f3dAwayTeam') as HTMLSelectElement)?.value || awayDefault;
    const livePayload = window.MYAIFootballHub?.getActiveMatchPayload?.({ homeTeamId: hId, awayTeamId: aId });
    const form = ((document.getElementById('f3dFormation') as HTMLSelectElement)?.value as FormationKey) || '4-3-3';
    const cfg: MatchConfig = {
      homeTeamId: hId,
      awayTeamId: aId,
      homeTeam: livePayload?.homeTeam,
      awayTeam: livePayload?.awayTeam,
      homeSquad: livePayload?.homeSquad,
      homeBench: livePayload?.homeBench,
      awaySquad: livePayload?.awaySquad,
      tactics: livePayload?.tactics ? { ...livePayload.tactics, formation: form } : undefined,
      controlPreset: livePayload?.controlPreset,
      formation: form,
      difficulty: ((document.getElementById('f3dDifficulty') as HTMLSelectElement)?.value as DifficultyKey) || 'متوسط',
      halfSeconds: Number((document.getElementById('f3dHalfSec') as HTMLSelectElement)?.value || 90),
      lighting: ((document.getElementById('f3dLighting') as HTMLSelectElement)?.value as LightingKey) || 'night',
      quality: ((document.getElementById('f3dQuality') as HTMLSelectElement)?.value as QualityKey) || 'medium',
      camera: ((document.getElementById('f3dCamSelect') as HTMLSelectElement)?.value as CameraModeKey) || 'broadcast',
      cameraZoom: Number((document.getElementById('f3dZoomSlider') as HTMLInputElement)?.value || 1.0),
      gameSpeed: livePayload?.matchSettings?.gameSpeed || 'normal',
      opponentStrength: ((document.getElementById('f3dOppStrength') as HTMLSelectElement)?.value as StrengthTier) || 'قوي',
      gkLevel: ((document.getElementById('f3dGkLevel') as HTMLSelectElement)?.value as GkTier) || 'متميز',
      opponentStyle: ((document.getElementById('f3dOppStyle') as HTMLSelectElement)?.value as OppStyleKey) || 'متوازن',
      controlAssist: ((document.getElementById('f3dControlAssist') as HTMLSelectElement)?.value as AssistLevel) || 'شبه مساعد',
    };
    launchEngineWithConfig(overlay, cfg, closeAll);
  });
}

window.myaiOpenFootball3D = mountFootball3DOverlay;
export {};
