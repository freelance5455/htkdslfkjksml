/* MY AI Pro Games Engine & MY AI Ultimate Club Live 2D + Real WebSocket PvP */
(function () {
  "use strict";

  const LOCAL_GAME_RECORDS_KEY = "myai_local_game_records_v1";
  let activeLoopCancel = null;
  let activeClubWs = null;
  let pvpState = {
    connected: false,
    connecting: false,
    rooms: [],
    room: null,
    side: null,
    error: "",
    lastEmote: "",
    pressCooldownAt: 0,
    prevGoals: { h: 0, a: 0 },
  };

  function esc(v) {
    return typeof window.escapeHTML === "function"
      ? window.escapeHTML(String(v ?? ""))
      : String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function say(msg) {
    if (typeof window.notify === "function") window.notify(msg);
  }

  function sfx(name) {
    try {
      if (window.MYAISound && typeof window.MYAISound[name] === "function") {
        window.MYAISound[name]();
      }
    } catch (_) {}
  }

  function hasOwnedItem(itemId) {
    try {
      const owned = window.myaiSessionState?.user?.ownedItems;
      return Array.isArray(owned) && owned.includes(itemId);
    } catch (_) {
      return false;
    }
  }

  function stopActiveCanvasLoop() {
    if (typeof activeLoopCancel === "function") {
      try {
        activeLoopCancel();
      } catch (_) {}
      activeLoopCancel = null;
    }
  }

  // Hook closeFeature so any active arcade/match loop cleans up cleanly
  const prevCloseFeature = window.closeFeature;
  window.closeFeature = function () {
    stopActiveCanvasLoop();
    if (typeof prevCloseFeature === "function") prevCloseFeature();
  };

  function getLocalRecords() {
    try {
      return JSON.parse(localStorage.getItem(LOCAL_GAME_RECORDS_KEY) || "{}") || {};
    } catch (_) {
      return {};
    }
  }

  function saveLocalRecord(gameId, score, won) {
    const all = getLocalRecords();
    const cur = all[gameId] || { plays: 0, wins: 0, highScore: 0 };
    cur.plays += 1;
    if (won) cur.wins += 1;
    cur.highScore = Math.max(cur.highScore || 0, Math.round(score || 0));
    all[gameId] = cur;
    localStorage.setItem(LOCAL_GAME_RECORDS_KEY, JSON.stringify(all));
    return cur;
  }

  async function reportGameResult(gameId, score, won, difficulty = "متوسط") {
    saveLocalRecord(gameId, score, won);
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      return { offline: true };
    }
    if (typeof window.myaiApiFetch !== "function") return null;
    try {
      const res = await window.myaiApiFetch("/api/games/complete", {
        method: "POST",
        body: JSON.stringify({ gameId, score: Math.round(score || 0), won: Boolean(won), difficulty }),
      });
      if (res && res.rewardAdded > 0) {
        sfx("coin");
        say(`🎉 حصلت على +${res.rewardAdded} نقطة (${res.dailyGamePoints}/${res.dailyGamePointsCap} حد الألعاب اليومي)`);
      }
      return res;
    } catch (_) {
      return null;
    }
  }
  window.myaiReportGameResult = reportGameResult;

  // =========================================================================
  // Shared 2D Stadium Canvas Renderer (used for Local Live Sim + Online PvP)
  // =========================================================================
  const FORMATIONS_HOME = {
    "4-3-3": [[8,50],[24,18],[22,39],[22,61],[24,82],[43,30],[40,50],[43,70],[64,18],[68,50],[64,82]],
    "4-2-3-1": [[8,50],[24,18],[21,39],[21,61],[24,82],[37,38],[37,62],[55,22],[55,50],[55,78],[70,50]],
    "4-4-2": [[8,50],[24,18],[21,39],[21,61],[24,82],[44,18],[44,40],[44,60],[44,82],[66,38],[66,62]],
    "3-5-2": [[8,50],[23,28],[21,50],[23,72],[43,14],[39,35],[43,50],[39,65],[43,86],[67,38],[67,62]],
    "5-3-2": [[8,50],[22,14],[20,33],[19,50],[20,67],[22,86],[44,30],[41,50],[44,70],[67,38],[67,62]],
  };

  function getFormationPoints(formation, mirrorAway) {
    const base = FORMATIONS_HOME[formation] || FORMATIONS_HOME["4-3-3"];
    return base.map(([x, y]) => (mirrorAway ? [100 - x, 100 - y] : [x, y]));
  }

  function createStadiumRenderer(canvas, options = {}) {
    const ctx = canvas.getContext("2d");
    const width = canvas.width;
    const height = canvas.height;
    const padX = 28;
    const padY = 20;
    const pw = width - padX * 2;
    const ph = height - padY * 2;
    const crimsonKit = hasOwnedItem("kit_crimson_obsidian");
    const nightLights = hasOwnedItem("stadium_night_lights");
    const neonTrail = hasOwnedItem("arcade_neon_trail");

    let smoothBall = { x: 50, y: 50 };
    const trail = [];
    let goalFlash = 0;
    let lastHomeColor = options.homeColor || (crimsonKit ? "#ff142e" : "#e11d48");
    let lastAwayColor = options.awayColor || "#38bdf8";

    function px(xPct) {
      return padX + (xPct / 100) * pw;
    }
    function py(yPct) {
      return padY + (yPct / 100) * ph;
    }

    function drawPitch(t) {
      // Stadium outer apron
      ctx.fillStyle = nightLights ? "#070b12" : "#0b110d";
      ctx.fillRect(0, 0, width, height);

      // Animated crowd dots in stands
      for (let i = 0; i < 42; i++) {
        const cx = ((i * 29) % (width - 20)) + 10;
        const pulse = Math.sin(t * 0.004 + i) * 1.4;
        ctx.fillStyle = i % 3 === 0 ? "rgba(255,40,70,0.45)" : "rgba(220,230,240,0.22)";
        ctx.beginPath();
        ctx.arc(cx, 8 + pulse, 2.2, 0, Math.PI * 2);
        ctx.arc(cx, height - 8 - pulse, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }

      // Grass stripes
      const stripes = 10;
      for (let s = 0; s < stripes; s++) {
        ctx.fillStyle = s % 2 === 0 ? "#124d27" : "#15592d";
        ctx.fillRect(padX + (pw / stripes) * s, padY, pw / stripes + 1, ph);
      }

      // Night floodlight beams
      if (nightLights) {
        const g1 = ctx.createRadialGradient(20, 20, 8, width * 0.3, height * 0.4, width * 0.7);
        g1.addColorStop(0, "rgba(255,255,230,0.18)");
        g1.addColorStop(1, "rgba(255,255,255,0)");
        ctx.fillStyle = g1;
        ctx.fillRect(padX, padY, pw, ph);
      }

      // Pitch chalk lines
      ctx.strokeStyle = "rgba(255,255,255,0.78)";
      ctx.lineWidth = 2;
      ctx.strokeRect(padX, padY, pw, ph);
      ctx.beginPath();
      ctx.moveTo(width / 2, padY);
      ctx.lineTo(width / 2, height - padY);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(width / 2, height / 2, ph * 0.17, 0, Math.PI * 2);
      ctx.stroke();

      // Penalty boxes
      const boxW = pw * 0.15;
      const boxH = ph * 0.54;
      ctx.strokeRect(padX, height / 2 - boxH / 2, boxW, boxH);
      ctx.strokeRect(width - padX - boxW, height / 2 - boxH / 2, boxW, boxH);

      // Goal nets
      const goalH = ph * 0.28;
      ctx.fillStyle = "rgba(255,255,255,0.14)";
      ctx.strokeStyle = "#ffffff";
      ctx.fillRect(padX - 12, height / 2 - goalH / 2, 12, goalH);
      ctx.strokeRect(padX - 12, height / 2 - goalH / 2, 12, goalH);
      ctx.fillRect(width - padX, height / 2 - goalH / 2, 12, goalH);
      ctx.strokeRect(width - padX, height / 2 - goalH / 2, 12, goalH);
    }

    function drawFrame(frameState, t) {
      const targetBallX = Number(frameState.ballX ?? 50);
      const targetBallY = Number(frameState.ballY ?? 50);
      smoothBall.x += (targetBallX - smoothBall.x) * 0.24;
      smoothBall.y += (targetBallY - smoothBall.y) * 0.24;

      if (neonTrail) {
        trail.push({ x: smoothBall.x, y: smoothBall.y });
        if (trail.length > 14) trail.shift();
      }

      drawPitch(t);

      // Compute dynamic player positions around ball
      const homeBase = getFormationPoints(frameState.homeFormation || "4-3-3", false);
      const awayBase = getFormationPoints(frameState.awayFormation || "4-3-3", true);
      const ballBiasX = (smoothBall.x - 50) * 0.32;
      const ballBiasY = (smoothBall.y - 50) * 0.18;

      const drawTeam = (pts, color, isHome, pressBoost) => {
        pts.forEach(([bx, by], idx) => {
          let tx = bx;
          let ty = by;
          if (idx > 0) {
            const shiftFactor = isHome
              ? (frameState.possessionSide === "home" ? 0.9 : 0.45)
              : (frameState.possessionSide === "away" ? 0.9 : 0.45);
            tx = Math.max(8, Math.min(92, bx + ballBiasX * shiftFactor + Math.sin(t * 0.004 + idx) * (pressBoost ? 2.8 : 1.5)));
            ty = Math.max(8, Math.min(92, by + ballBiasY * 0.55 + Math.cos(t * 0.0035 + idx * 1.3) * 1.8));
          } else {
            tx = isHome ? 6 : 94;
            ty = Math.max(36, Math.min(64, 50 + (smoothBall.y - 50) * 0.24));
          }

          const x = px(tx);
          const y = py(ty);

          // Shadow
          ctx.fillStyle = "rgba(0,0,0,0.4)";
          ctx.beginPath();
          ctx.ellipse(x, y + 6, 6, 3, 0, 0, Math.PI * 2);
          ctx.fill();

          // Kit circle
          ctx.fillStyle = idx === 0 ? "#facc15" : color;
          ctx.strokeStyle = isHome && crimsonKit ? "#ffd166" : "#ffffff";
          ctx.lineWidth = 1.6;
          ctx.beginPath();
          ctx.arc(x, y, 6.5, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        });
      };

      drawTeam(homeBase, lastHomeColor, true, frameState.homePress);
      drawTeam(awayBase, lastAwayColor, false, frameState.awayPress);

      // Neon ball trail (cosmetic item)
      if (neonTrail && trail.length > 1) {
        for (let i = 0; i < trail.length; i++) {
          const pt = trail[i];
          const alpha = (i + 1) / trail.length * 0.55;
          ctx.fillStyle = `rgba(255, 36, 72, ${alpha})`;
          ctx.beginPath();
          ctx.arc(px(pt.x), py(pt.y), 2 + (i / trail.length) * 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Soccer ball
      const bx = px(smoothBall.x);
      const by = py(smoothBall.y);
      ctx.fillStyle = "rgba(0,0,0,0.45)";
      ctx.beginPath();
      ctx.ellipse(bx + 2, by + 5, 5, 2.5, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#111111";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.arc(bx, by, 5.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      if (goalFlash > 0) {
        ctx.fillStyle = `rgba(255, 20, 46, ${goalFlash * 0.35})`;
        ctx.fillRect(0, 0, width, height);
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 28px Arial";
        ctx.textAlign = "center";
        ctx.fillText("⚽ هدف!", width / 2, height / 2);
        goalFlash = Math.max(0, goalFlash - 0.03);
      }
    }

    return {
      render: drawFrame,
      triggerGoalFlash() {
        goalFlash = 1;
      },
    };
  }

  // =========================================================================
  // 1) MY AI ULTIMATE CLUB — Full Upgrade (Live 2D Match + Real Online PvP + Shop)
  // =========================================================================
  let localMatchSession = null;

  function computeClubStartersAndAvg() {
    const starters = (window.clubPlayers || []).filter((p) => p.status === "أساسي");
    const avg = starters.length
      ? Math.round(starters.reduce((a, p) => a + (p.rating || 75), 0) / starters.length)
      : 76;
    return { starters, avg };
  }

  function connectClubWs(onUpdate) {
    if (activeClubWs && activeClubWs.readyState === WebSocket.OPEN) {
      if (onUpdate) onUpdate();
      return activeClubWs;
    }
    if (pvpState.connecting) return activeClubWs;

    const token = localStorage.getItem("myai_session_token_v1") || "";
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${proto}//${location.host}/ws/club${token ? `?token=${encodeURIComponent(token)}` : ""}`;
    pvpState.connecting = true;
    pvpState.error = "";

    try {
      const ws = new WebSocket(wsUrl);
      activeClubWs = ws;

      ws.onopen = () => {
        pvpState.connected = true;
        pvpState.connecting = false;
        ws.send(JSON.stringify({ type: "list_rooms" }));
        if (onUpdate) onUpdate();
      };

      ws.onmessage = (evt) => {
        let data = {};
        try {
          data = JSON.parse(evt.data || "{}");
        } catch (_) {
          return;
        }
        if (data.type === "error") {
          pvpState.error = data.error || "حدث خطأ في الغرفة";
          say(pvpState.error);
          sfx("wrong");
        } else if (data.type === "connected" || data.type === "rooms_list") {
          pvpState.rooms = Array.isArray(data.rooms) ? data.rooms : [];
        } else if (data.type === "room_created" || data.type === "room_joined") {
          pvpState.room = data.room;
          pvpState.side = data.side;
          pvpState.prevGoals = {
            h: data.room?.match?.homeGoals || 0,
            a: data.room?.match?.awayGoals || 0,
          };
          sfx("whistle");
          window.renderClub();
          return;
        } else if (data.type === "left_room" || data.type === "room_closed") {
          pvpState.room = null;
          pvpState.side = null;
          if (data.rooms) pvpState.rooms = data.rooms;
          if (data.reason) say(data.reason);
          window.renderClub();
          return;
        } else if (data.type === "match_started") {
          pvpState.room = data.room;
          pvpState.prevGoals = { h: 0, a: 0 };
          sfx("whistle");
          window.renderClub();
          return;
        } else if (data.type === "match_state" || data.type === "room_updated" || data.type === "opponent_left") {
          pvpState.room = data.room;
          const m = data.room?.match;
          if (m && (m.homeGoals > pvpState.prevGoals.h || m.awayGoals > pvpState.prevGoals.a)) {
            pvpState.prevGoals = { h: m.homeGoals, a: m.awayGoals };
            sfx("goal");
            if (window._myaiPvpRenderer) window._myaiPvpRenderer.triggerGoalFlash();
          }
          if (data.type === "match_state") {
            updatePvpMatchHudOnly(data.room);
            return;
          }
        } else if (data.type === "emote") {
          pvpState.lastEmote = `${data.clubName}: ${data.emote}`;
          const el = document.getElementById("pvpEmoteBanner");
          if (el) el.textContent = pvpState.lastEmote;
          sfx("click");
          return;
        } else if (data.type === "match_finished") {
          pvpState.room = data.room;
          sfx("fanfare");
          if (typeof data.points === "number" && window.myaiSessionState?.user) {
            window.myaiSessionState.user.points = data.points;
            const ptEl = document.querySelector("header .points");
            if (ptEl) ptEl.textContent = "💎 " + Number(data.points).toLocaleString("en-US") + "　＋";
          }
          window.renderClub();
          return;
        }

        if (window.clubTab === "pvp" && document.getElementById("clubPvpMount")) {
          renderPvpInner(document.getElementById("clubPvpMount"));
        }
      };

      ws.onerror = () => {
        pvpState.connecting = false;
        pvpState.connected = false;
        pvpState.error = "تعذر الاتصال بخادم اللعب الجماعي اللحظي.";
      };

      ws.onclose = () => {
        pvpState.connected = false;
        pvpState.connecting = false;
      };
      return ws;
    } catch (_) {
      pvpState.connecting = false;
      pvpState.error = "المتصفح لم يتمكن من فتح اتصال WebSocket.";
      return null;
    }
  }

  function updatePvpMatchHudOnly(room) {
    if (!room) return;
    const scoreEl = document.getElementById("pvpLiveScore");
    const minEl = document.getElementById("pvpLiveMin");
    const feedEl = document.getElementById("pvpLiveFeed");
    const statsEl = document.getElementById("pvpLiveStats");
    const m = room.match || {};
    if (scoreEl) scoreEl.textContent = `${room.host?.clubName || "المضيف"} ${m.homeGoals ?? 0} - ${m.awayGoals ?? 0} ${room.away?.clubName || "الضيف"}`;
    if (minEl) minEl.textContent = `${m.minute || 0}′ · استحواذ ${m.homePossession ?? 50}%`;
    if (statsEl) {
      statsEl.textContent = `تسديدات: ${m.homeShots ?? 0}-${m.awayShots ?? 0} · على المرمى: ${m.homeShotsOn ?? 0}-${m.awayShotsOn ?? 0} · ركنيات: ${m.homeCorners ?? 0}-${m.awayCorners ?? 0}`;
    }
    if (feedEl && Array.isArray(m.events)) {
      feedEl.innerHTML = m.events.slice(-6).reverse().map((e) => `<div>${esc(e.text)}</div>`).join("");
    }
  }

  function sendPvp(payload) {
    if (!activeClubWs || activeClubWs.readyState !== WebSocket.OPEN) {
      connectClubWs(() => {
        if (activeClubWs && activeClubWs.readyState === WebSocket.OPEN) {
          activeClubWs.send(JSON.stringify(payload));
        }
      });
      return;
    }
    activeClubWs.send(JSON.stringify(payload));
  }

  window.myaiPvpCreateRoom = function () {
    const { avg } = computeClubStartersAndAvg();
    const clubName = window.clubState?.club || "MY AI UNITED";
    sendPvp({
      type: "create_room",
      clubName,
      rating: avg,
      formation: window.clubState?.formation || "4-3-3",
      style: window.clubState?.style || "متوازن",
    });
  };

  window.myaiPvpJoinRoom = function (codeOverride) {
    const code = (codeOverride || document.getElementById("pvpJoinCode")?.value || "").trim().toUpperCase();
    if (!code || code.length < 4) {
      say("أدخل رمز الغرفة المكون من 6 أحرف.");
      return;
    }
    const { avg } = computeClubStartersAndAvg();
    sendPvp({
      type: "join_room",
      code,
      clubName: window.clubState?.club || "RIVAL CLUB",
      rating: avg,
      formation: window.clubState?.formation || "4-3-3",
      style: window.clubState?.style || "متوازن",
    });
  };

  window.myaiPvpSetTactics = function (style, formation, pressBoost) {
    sendPvp({
      type: "set_tactics",
      style,
      formation,
      pressBoost: Boolean(pressBoost),
    });
    if (pressBoost) sfx("whistle");
    else sfx("click");
  };

  window.myaiPvpEmote = function (emote) {
    sendPvp({ type: "chat_emote", emote });
  };

  window.myaiPvpStartMatch = function () {
    sendPvp({ type: "start_match" });
  };

  window.myaiPvpRematch = function () {
    sendPvp({ type: "rematch" });
  };

  window.myaiPvpLeave = function () {
    sendPvp({ type: "leave_room" });
  };

  window.myaiPvpRefreshRooms = function () {
    sendPvp({ type: "list_rooms" });
    sfx("click");
  };

  function renderPvpInner(container) {
    if (!container) return;
    if (typeof navigator !== "undefined" && navigator.onLine === false) {
      container.innerHTML = `<div class="myai-pro-card"><h3>⚠️ اللعب الجماعي PvP يتطلب إنترنت</h3><p class="myai-v3-muted">وضع اللعب الجماعي يربط لاعبين حقيقيين عبر خادم MY AI. يمكنك اللعب الآن ضد الذكاء الاصطناعي في تبويب «مركز المباريات» أو الألعاب المحلية.</p></div>`;
      return;
    }

    const r = pvpState.room;
    if (!r) {
      const roomsHtml = (pvpState.rooms || [])
        .map(
          (rm) => `<div class="myai-list-item myai-pro-row">
            <div><b>${esc(rm.hostClub)}</b> <small class="myai-v3-muted">(${esc(rm.hostName)} · قوة ${rm.hostRating} · ${esc(rm.formation)})</small><br><span class="myai-code-pill">${esc(rm.code)}</span></div>
            <button type="button" class="primary" onclick="myaiPvpJoinRoom('${esc(rm.code)}')">انضمام الآن</button>
          </div>`,
        )
        .join("");

      container.innerHTML = `
        <div class="myai-pro-card">
          <div class="myai-pro-row">
            <h3>⚔️ ساحة المباريات المباشرة (لاعب ضد لاعب حقيقي)</h3>
            <span class="myai-badge ${pvpState.connected ? "ok" : "warn"}">${pvpState.connected ? "متصل بالخادم اللحظي" : "جاري الاتصال..."}</span>
          </div>
          <p class="myai-v3-muted">نظام غرف حقيقي عبر WebSocket — نعرض هنا الغرف التي أنشأها لاعبون حقيقيون فقط دون أي خصوم وهميين.</p>
          <div class="myai-pro-grid2" style="margin-top:10px">
            <button type="button" class="primary feature-action" onclick="myaiPvpCreateRoom()">🏟️ إنشاء غرفة ومشاركة الرمز</button>
            <button type="button" class="myai-v3-btn feature-action" onclick="myaiPvpRefreshRooms()">🔄 تحديث الغرف المفتوحة</button>
          </div>
          <div style="display:flex;gap:8px;margin-top:10px">
            <input id="pvpJoinCode" class="feature-field" style="margin:0;direction:ltr;text-align:center;text-transform:uppercase;font-weight:800" placeholder="أدخل رمز الغرفة (مثال: A7K9P2)">
            <button type="button" class="primary" onclick="myaiPvpJoinRoom()">دخول</button>
          </div>
        </div>
        <div class="myai-pro-card">
          <h3>🌐 الغرف المتاحة حاليًا (${(pvpState.rooms || []).length})</h3>
          <div class="myai-table-list">${roomsHtml || '<p class="myai-v3-muted">لا توجد غرف مفتوحة من لاعبين آخرين في هذه اللحظة. أنشئ غرفة وشارك رمزها مع صديق، أو العب في «مركز المباريات».</p>'}</div>
        </div>
      `;
      return;
    }

    const m = r.match || {};
    const mySlot = pvpState.side === "away" ? r.away : r.host;
    container.innerHTML = `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <div><b>غرفة:</b> <span class="myai-code-pill">${esc(r.code)}</span> <button type="button" class="myai-mini-btn" onclick="navigator.clipboard?.writeText('${esc(r.code)}');say('تم نسخ رمز الغرفة')">📋 نسخ</button></div>
          <button type="button" class="myai-mini-btn" onclick="myaiPvpLeave()">🚪 مغادرة</button>
        </div>
        <div class="myai-pro-grid2" style="margin-top:10px">
          <div class="myai-list-item">🏠 <b>${esc(r.host?.clubName)}</b><br><small>${esc(r.host?.userName)} · ⭐ ${r.host?.rating} · ${esc(r.host?.formation)} (${esc(r.host?.style)})</small></div>
          <div class="myai-list-item">${r.away ? `✈️ <b>${esc(r.away.clubName)}</b><br><small>${esc(r.away.userName)} · ⭐ ${r.away.rating} · ${esc(r.away.formation)} (${esc(r.away.style)})</small>` : "⏳ بانتظار انضمام اللاعب الثاني عبر الرمز..."}</div>
        </div>
      </div>

      ${
        r.away
          ? `<div class="myai-pro-card">
              <div class="myai-hud-bar">
                <span id="pvpLiveScore" style="font-weight:800">${esc(r.host?.clubName)} ${m.homeGoals ?? 0} - ${m.awayGoals ?? 0} ${esc(r.away?.clubName)}</span>
                <span id="pvpLiveMin" class="myai-badge ok">${m.minute || 0}′ · استحواذ ${m.homePossession ?? 50}%</span>
              </div>
              <div class="myai-canvas-wrap" style="margin-top:8px">
                <canvas id="pvpMatchCanvas" width="640" height="360"></canvas>
              </div>
              <div id="pvpEmoteBanner" class="myai-v3-muted" style="text-align:center;min-height:20px;margin:6px 0">${esc(pvpState.lastEmote || "")}</div>
              <div class="myai-tactic-strip">
                <select class="myai-mini-btn" onchange="myaiPvpSetTactics(this.value, '${esc(mySlot?.formation || "4-3-3")}', false)">
                  ${["متوازن", "استحواذ", "ضغط عالٍ", "مرتدات", "دفاع متأخر"].map((st) => `<option ${mySlot?.style === st ? "selected" : ""}>${st}</option>`).join("")}
                </select>
                <button type="button" class="myai-mini-btn primary-mini" onclick="myaiPvpSetTactics(null, null, true)">⚡ ضغط فوري</button>
                ${["هدف رائع! ⚽", "دفاع محكم! 🛡️", "مباراة قوية! 🔥"].map((em) => `<button type="button" class="myai-mini-btn" onclick="myaiPvpEmote('${esc(em)}')">${esc(em)}</button>`).join("")}
              </div>
              ${
                m.status === "waiting"
                  ? (pvpState.side === "home"
                      ? `<button type="button" class="primary feature-action" onclick="myaiPvpStartMatch()">▶ ابدأ المباراة الآن</button>`
                      : `<p class="myai-v3-muted" style="text-align:center;margin-top:8px">بانتظار ضغط منشئ الغرفة على «ابدأ المباراة»...</p>`)
                  : m.status === "finished"
                    ? `<button type="button" class="primary feature-action" onclick="myaiPvpRematch()">🔁 مباراة جديدة (Rematch)</button>`
                    : ""
              }
              <p id="pvpLiveStats" class="myai-v3-muted" style="margin-top:8px">تسديدات: ${m.homeShots ?? 0}-${m.awayShots ?? 0} · على المرمى: ${m.homeShotsOn ?? 0}-${m.awayShotsOn ?? 0} · ركنيات: ${m.homeCorners ?? 0}-${m.awayCorners ?? 0}</p>
              <div id="pvpLiveFeed" class="myai-table-list" style="max-height:140px">${(m.events || []).slice(-6).reverse().map((e) => `<div>${esc(e.text)}</div>`).join("")}</div>
            </div>`
          : ""
      }
    `;

    const pvpCanvas = document.getElementById("pvpMatchCanvas");
    if (pvpCanvas) {
      stopActiveCanvasLoop();
      const renderer = createStadiumRenderer(pvpCanvas);
      window._myaiPvpRenderer = renderer;
      let alive = true;
      const tick = (t) => {
        if (!alive || !document.getElementById("pvpMatchCanvas")) return;
        const curRoom = pvpState.room || r;
        const cm = curRoom.match || {};
        renderer.render(
          {
            ballX: cm.ballX ?? 50,
            ballY: cm.ballY ?? 50,
            possessionSide: cm.possessionSide || "home",
            homeFormation: curRoom.host?.formation || "4-3-3",
            awayFormation: curRoom.away?.formation || "4-3-3",
            homePress: curRoom.host?.pressBoostActive,
            awayPress: curRoom.away?.pressBoostActive,
          },
          t,
        );
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      activeLoopCancel = () => {
        alive = false;
      };
    }
  }

  function renderClubShopTab() {
    const items = window.myaiSessionState?.shopItems || [];
    const owned = window.myaiSessionState?.user?.ownedItems || [];
    const points = window.myaiSessionState?.user?.points ?? 0;
    if (!items.length) {
      return `<div class="myai-pro-card"><h3>🛒 متجر النادي والمزايا</h3><p class="myai-v3-muted">افتح تبويب النقاط في حسابك لتحميل عناصر المتجر الرسمية من الخادم.</p><button type="button" class="primary feature-action" onclick="myaiOpenAccountPro('points')">الذهاب إلى النقاط والمتجر</button></div>`;
    }
    return `
      <div class="myai-pro-card">
        <div class="myai-pro-row">
          <h3>🛒 متجر MY AI Virtual Shop (مزايا بصرية وصوتية غير ربحيّة)</h3>
          <span class="myai-badge ok">💎 ${Number(points).toLocaleString("en-US")} نقطة</span>
        </div>
        <p class="myai-v3-muted">عناصر تجميلية واحترافية لتخصيص تجربتك دون أي ميزة فوز تلقائي أو مراهنة.</p>
        <div class="myai-pro-grid2">
          ${items
            .map((it) => {
              const isOwned = owned.includes(it.id);
              return `<div class="myai-list-item">
                <div class="myai-pro-row"><b>${esc(it.icon)} ${esc(it.name)}</b><span class="myai-badge ${isOwned ? "ok" : ""}">${isOwned ? "مملوك ✓" : it.cost + " نقطة"}</span></div>
                <p class="myai-v3-muted" style="margin:6px 0">${esc(it.description)}</p>
                ${
                  isOwned
                    ? `<button type="button" class="myai-mini-btn" disabled>مُفعّل في حسابك</button>`
                    : `<button type="button" class="primary" style="width:100%" onclick="myaiBuyVirtualItem('${esc(it.id)}')">شراء بـ ${it.cost} نقطة</button>`
                }
              </div>`;
            })
            .join("")}
        </div>
      </div>
    `;
  }

  // Upgrade Ultimate Club: Preserve all 7 tabs + add Online PvP + Shop + Live 2D Match Canvas
  window.openUltimateClub = function () {
    if (typeof window.clubTab !== "undefined") window.clubTab = "team";
    window.renderClub();
  };

  window.renderClub = function () {
    stopActiveCanvasLoop();
    const players = window.clubPlayers || [];
    const starters = players.filter((p) => p.status === "أساسي");
    const squad = players.filter((p) => p.status !== "السوق");
    const state = window.clubState || { club: "MY AI UNITED", season: 1, week: 1, played: 0, wins: 0, draws: 0, losses: 0, points: 0, goalsFor: 0, goalsAgainst: 0, formation: "4-3-3", style: "متوازن", difficulty: "احترافي", history: [], sponsor: 250000, fanMood: 78 };
    const tab = window.clubTab || "team";
    const avg = starters.length ? Math.round(starters.reduce((a, p) => a + p.rating, 0) / starters.length) : 0;
    const money = (n) => Math.round(n).toLocaleString("en-US") + " ج.م";
    const tabBtn = (key, label) => `<button class="${tab === key ? "active" : ""}" onclick="clubTab='${key}';renderClub()">${label}</button>`;

    let body = `<div class="club-summary"><span>🏆 ${esc(state.club)}</span><span>💰 ${money(window.clubBudget || 0)}</span><span>⭐ القوة ${avg}</span><span>🏟️ موسم ${state.season} · جولة ${state.week}</span></div>
    <div class="club-tabs">${tabBtn("team", "الفريق")}${tabBtn("tactics", "التشكيلة والخطط")}${tabBtn("match", "مركز المباريات")}${tabBtn("pvp", "أونلاين PvP ⚔️")}${tabBtn("training", "التدريب")}${tabBtn("market", "الانتقالات")}${tabBtn("shop", "متجر النقاط 🛒")}${tabBtn("stats", "الإحصائيات")}${tabBtn("leagues", "الدوريات")}</div>`;

    if (tab === "team") {
      const academyBoost = hasOwnedItem("club_youth_academy") ? " · 🎓 أكاديمية الناشئين مفعّلة (+15% تدريب)" : "";
      body += `<div class="feature-result"><h3>إدارة النادي</h3><p>المدير الفني: أنت · الروح المعنوية ${state.fanMood}% · الرصيد المالي ${money(window.clubBudget || 0)}${academyBoost}</p><div class="club-grid"><div class="feature-option"><span class="ficon">👥</span><strong>${squad.length} لاعبًا</strong><small>قائمة الفريق</small></div><div class="feature-option"><span class="ficon">⭐</span><strong>${avg} / 100</strong><small>قوة التشكيلة الأساسية</small></div><div class="feature-option"><span class="ficon">🏆</span><strong>${state.points} نقطة</strong><small>${state.wins} فوز · ${state.draws} تعادل · ${state.losses} خسارة</small></div><div class="feature-option"><span class="ficon">💳</span><strong>${money(state.sponsor)}</strong><small>دخل الرعاية القادم</small></div></div></div>
      <div class="feature-result"><h3>قائمة اللاعبين</h3><p>الطاقات محاكاة تفاعلية محفوظة على جهازك ومربوطة بنسختك السحابية.</p><div class="club-grid">${squad.map((p) => window.clubPlayerCard(p)).join("")}</div></div><button class="feature-action" onclick="clubTab='market';renderClub()">فتح سوق الانتقالات</button>`;
    } else if (tab === "tactics") {
      body += `<div class="feature-result"><h3>التشكيلة الأساسية</h3><label>الخطة</label><select class="feature-field" id="clubFormation" onchange="setClubFormation(this.value)">${["4-3-3", "4-2-3-1", "4-4-2", "3-5-2", "5-3-2"].map((x) => `<option ${state.formation === x ? "selected" : ""}>${x}</option>`).join("")}</select><label>أسلوب اللعب</label><select class="feature-field" onchange="clubState.style=this.value;saveClub()"><option ${state.style === "متوازن" ? "selected" : ""}>متوازن</option><option ${state.style === "استحواذ" ? "selected" : ""}>استحواذ</option><option ${state.style === "ضغط عالٍ" ? "selected" : ""}>ضغط عالٍ</option><option ${state.style === "مرتدات" ? "selected" : ""}>مرتدات</option><option ${state.style === "دفاع متأخر" ? "selected" : ""}>دفاع متأخر</option></select><label>مستوى المنافسة</label><select class="feature-field" onchange="clubState.difficulty=this.value;saveClub()"><option ${state.difficulty === "مبتدئ" ? "selected" : ""}>مبتدئ</option><option ${state.difficulty === "احترافي" ? "selected" : ""}>احترافي</option><option ${state.difficulty === "نخبة" ? "selected" : ""}>نخبة</option></select><p>تقييم التشكيلة: ⭐ ${avg} · الانسجام: ${Math.min(99, Math.round(starters.reduce((a, p) => a + p.morale, 0) / (starters.length || 1)))}%</p><h3>اسحب اللاعبين لتغيير أماكنهم</h3><div class="pitch-editor" id="clubPitch" onpointerdown="pitchPointerDown(event)" onpointermove="pitchPointerMove(event)" onpointerup="pitchPointerUp(event)" onpointercancel="pitchPointerUp(event)"><div class="pitch-mid"></div><div class="pitch-circle"></div><div class="pitch-box-top"></div><div class="pitch-box-bottom"></div>${window.renderPitchPlayers(starters)}</div><div class="club-grid">${players.map((p) => `<div class="player-card"><strong>${esc(p.name)}</strong><small>${p.pos} · ${p.status}</small><button onclick="toggleStarter(${p.id})">${p.status === "أساسي" ? "إلى الاحتياط" : "إلى الأساسي"}</button></div>`).join("")}</div></div>`;
    } else if (tab === "match") {
      const rival = (window.rivalTeams || [])[(state.week - 1) % (window.rivalTeams?.length || 1)] || "المنافس";
      body += `<div class="feature-result"><h3>🎮 يوم المباراة — بث 2D تفاعلي</h3><p>الجولة ${state.week} · ${esc(state.club)} ضد ${esc(rival)} (${esc(state.difficulty)})</p><p>قوة فريقك ${avg} · اللياقة ${Math.round(squad.reduce((a, p) => a + p.fitness, 0) / (squad.length || 1))}%</p><div id="clubLiveArenaMount"></div><div class="myai-pro-grid2"><button class="primary feature-action" onclick="simulateClubMatch()">▶ ابدأ المباراة الحية (2D)</button><button class="feature-action" onclick="restClubTeam()">🛌 يوم راحة واستعادة اللياقة</button></div></div>${state.lastMatch ? window.matchReportHTML(state.lastMatch) : '<div class="feature-result">لم تلعب مباراة بعد. ابدأ أول مباراة لمشاهدة الملعب الحي والأحداث.</div>'}<div class="feature-result"><h3>جدول الموسم</h3><p>لعبت ${state.played} مباراة · سجلت ${state.goalsFor} · استقبلت ${state.goalsAgainst}</p><button onclick="advanceClubWeek()">إنهاء الجولة والتقدم</button></div>`;
    } else if (tab === "pvp") {
      body += `<div id="clubPvpMount"><p class="myai-v3-muted">⏳ جاري الاتصال بساحة اللعب الجماعي...</p></div>`;
    } else if (tab === "training") {
      body += `<div class="feature-result"><h3>مركز التدريب</h3><p>اختر نوع التدريب.${hasOwnedItem("club_youth_academy") ? " (🎓 مكافأة أكاديمية الناشئين مفعّلة)" : ""}</p><div class="club-grid"><button class="feature-option" onclick="trainClub('pace')"><span class="ficon">⚡</span><strong>السرعة</strong><small>رفع السرعة</small></button><button class="feature-option" onclick="trainClub('shoot')"><span class="ficon">🥅</span><strong>التسديد</strong><small>رفع الإنهاء</small></button><button class="feature-option" onclick="trainClub('pass')"><span class="ficon">🎯</span><strong>التمرير</strong><small>رفع الدقة</small></button><button class="feature-option" onclick="trainClub('def')"><span class="ficon">🛡️</span><strong>الدفاع</strong><small>رفع الافتكاك</small></button><button class="feature-option" onclick="trainClub('phys')"><span class="ficon">💪</span><strong>اللياقة</strong><small>رفع التحمل</small></button><button class="feature-option" onclick="trainClub('all')"><span class="ficon">🧠</span><strong>تدريب شامل</strong><small>تحسين متوازن</small></button></div><h3>اللاعبون</h3><div class="club-grid">${squad.map((p) => `<div class="player-card"><strong>${esc(p.name)}</strong><small>⭐ ${p.rating} · لياقة ${p.fitness}% · معنويات ${p.morale}%</small></div>`).join("")}</div></div>`;
    } else if (tab === "market") {
      const market = players.filter((p) => p.status === "السوق");
      body += `<div class="feature-result"><h3>سوق الانتقالات</h3><p>ميزانية الانتقالات: ${money(window.clubBudget || 0)}</p><div class="club-grid">${market.map((p) => window.clubPlayerCard(p, true)).join("") || "<p>لا يوجد لاعبون متاحون حاليًا.</p>"}</div><h3>بيع لاعب</h3><div class="club-grid">${squad.map((p) => `<div class="player-card"><strong>${esc(p.name)}</strong><small>قيمة تقديرية ${money(p.price)}</small><button onclick="sellClubPlayer(${p.id})">بيع اللاعب</button></div>`).join("")}</div></div>`;
    } else if (tab === "shop") {
      body += renderClubShopTab();
    } else if (tab === "stats") {
      const scorers = [...squad].sort((a, b) => b.goals - a.goals).slice(0, 5);
      body += `<div class="feature-result"><h3>إحصائيات الموسم</h3><div class="club-grid"><div class="feature-option"><strong>${state.played}</strong><small>مباريات</small></div><div class="feature-option"><strong>${state.wins}</strong><small>انتصارات</small></div><div class="feature-option"><strong>${state.goalsFor}</strong><small>أهداف مسجلة</small></div><div class="feature-option"><strong>${state.goalsAgainst}</strong><small>أهداف مستقبلة</small></div></div><h3>أفضل الهدافين</h3>${scorers.map((p) => `<p>${esc(p.name)} — ${p.goals} هدف · ${p.assists} أسيست</p>`).join("")}<h3>آخر النتائج</h3>${state.history.slice(-8).reverse().map((m) => `<p>${m.date}: ${esc(m.home)} ${m.hg} - ${m.ag} ${esc(m.away)}</p>`).join("") || "لا توجد نتائج بعد"}</div>`;
    } else {
      body += `<div class="feature-result"><h3>الدوريات والبطولات</h3><input class="feature-field" id="leagueSearch" placeholder="ابحث عن دوري أو دولة..." oninput="filterLeagueCards(this.value)"><div id="leagueCards" class="league-grid">${(window.leagueCatalog || []).map((l, i) => `<button class="league-card" onclick="selectLeague(${i})"><span>${l.flag}</span><b>${l.name}</b><small>${l.country}</small></button>`).join("")}</div><div id="leagueStatus" class="league-status">واجهة الدوريات جاهزة</div></div>`;
    }

    window.openFeature("MY AI ULTIMATE CLUB", "إدارة فريقك · محاكاة 2D حية · لعب جماعي أونلاين PvP", body);

    if (tab === "pvp") {
      const mount = document.getElementById("clubPvpMount");
      connectClubWs(() => {
        if (document.getElementById("clubPvpMount")) renderPvpInner(document.getElementById("clubPvpMount"));
      });
      renderPvpInner(mount);
    }
  };

  // Interactive Live 2D Animated Stadium Match against AI
  window.simulateClubMatch = function () {
    const players = window.clubPlayers || [];
    const starters = players.filter((p) => p.status === "أساسي");
    if (starters.length < 7) {
      say("تحتاج إلى 7 لاعبين أساسيين على الأقل");
      return;
    }
    const state = window.clubState;
    const mount = document.getElementById("clubLiveArenaMount");
    if (!mount) {
      window.clubTab = "match";
      window.renderClub();
    }
    const activeMount = document.getElementById("clubLiveArenaMount");
    if (!activeMount) return;

    stopActiveCanvasLoop();
    const rival = (window.rivalTeams || [])[(state.week - 1) % (window.rivalTeams?.length || 1)] || "فريق المنافس";
    const strength = Math.round(starters.reduce((a, p) => a + p.rating, 0) / starters.length);
    const fitness = starters.reduce((a, p) => a + p.fitness, 0) / starters.length;
    const difficultyBoost = state.difficulty === "نخبة" ? 7 : state.difficulty === "احترافي" ? 3 : 0;
    const oppStrength = Math.max(54, Math.min(91, 68 + Math.floor(Math.random() * 16) + difficultyBoost));
    const isHome = state.week % 2 === 1;

    localMatchSession = {
      minute: 0,
      ours: 0,
      theirs: 0,
      shots: 0,
      shotsOn: 0,
      corners: 0,
      possTicks: 1,
      totalTicks: 2,
      ballX: 50,
      ballY: 50,
      possessionSide: "home",
      events: [`0′ صفارة البداية! ${state.club} × ${rival}`],
      speed: 1,
      finished: false,
      style: state.style || "متوازن",
      timer: null,
    };

    activeMount.innerHTML = `
      <div class="myai-pro-card" style="margin:10px 0">
        <div class="myai-hud-bar">
          <span id="locScore">${esc(state.club)} 0 - 0 ${esc(rival)}</span>
          <span id="locMin" class="myai-badge ok">0′</span>
        </div>
        <div class="myai-canvas-wrap" style="margin-top:8px">
          <canvas id="localClubCanvas" width="640" height="360"></canvas>
        </div>
        <div class="myai-tactic-strip">
          <button type="button" class="myai-mini-btn" onclick="myaiLocalClubStyle('ضغط عالٍ')">🔥 ضغط عالٍ</button>
          <button type="button" class="myai-mini-btn" onclick="myaiLocalClubStyle('استحواذ')">🎯 استحواذ</button>
          <button type="button" class="myai-mini-btn" onclick="myaiLocalClubStyle('مرتدات')">⚡ مرتدات</button>
          <button type="button" class="myai-mini-btn primary-mini" onclick="myaiLocalClubSpeed()">⏩ سرعة 2x</button>
          <button type="button" class="myai-mini-btn" onclick="myaiLocalClubSkip()">⏭️ إنهاء الآن</button>
        </div>
        <div id="locFeed" class="myai-table-list" style="max-height:110px;margin-top:8px"></div>
      </div>
    `;

    const canvas = document.getElementById("localClubCanvas");
    const renderer = createStadiumRenderer(canvas);
    sfx("whistle");

    const stepSim = () => {
      const s = localMatchSession;
      if (!s || s.finished) return;
      s.minute = Math.min(90, s.minute + 2);
      const styleBonus = s.style === "ضغط عالٍ" ? 4 : s.style === "استحواذ" ? 3 : s.style === "مرتدات" ? 2 : 1;
      const possProb = Math.max(0.32, Math.min(0.68, 0.5 + (strength + styleBonus - oppStrength) * 0.012));
      if (Math.random() < 0.4) s.possessionSide = Math.random() < possProb ? "home" : "away";
      s.totalTicks += 1;
      if (s.possessionSide === "home") s.possTicks += 1;

      const tx = s.possessionSide === "home" ? 55 + Math.random() * 40 : 5 + Math.random() * 40;
      s.ballX = tx;
      s.ballY = 16 + Math.random() * 68;

      if (Math.random() < 0.28) {
        const edge = (strength + styleBonus + (fitness - 80) * 0.08 - oppStrength) * 0.008;
        if (s.possessionSide === "home") {
          s.shots++;
          const gProb = Math.max(0.11, Math.min(0.34, 0.19 + edge));
          if (Math.random() < gProb) {
            s.ours++;
            s.shotsOn++;
            s.ballX = 97;
            s.ballY = 50;
            const scorers = starters.filter((p) => ["مهاجم", "جناح", "صانع ألعاب"].some((k) => p.pos.includes(k)));
            const p = scorers[Math.floor(Math.random() * scorers.length)] || starters[0];
            p.goals++;
            const helper = starters.find((x) => x.id !== p.id);
            if (helper && Math.random() < 0.78) helper.assists++;
            s.events.push(`⚽ ${s.minute}′ هدف لـ ${p.name}${helper ? " · أسيست " + helper.name : ""}!`);
            sfx("goal");
            renderer.triggerGoalFlash();
          } else if (Math.random() < 0.45) {
            s.shotsOn++;
            s.events.push(`🧤 ${s.minute}′ تسديدة خطيرة من ${starters[Math.floor(Math.random() * starters.length)].name} يتصدى لها الحارس`);
            sfx("kick");
          } else {
            s.corners++;
          }
        } else {
          const oppProb = Math.max(0.08, Math.min(0.28, 0.16 - edge));
          if (Math.random() < oppProb) {
            s.theirs++;
            s.ballX = 3;
            s.ballY = 50;
            s.events.push(`⚽ ${s.minute}′ هدف للمنافس ${rival}`);
            sfx("wrong");
            renderer.triggerGoalFlash();
          }
        }
      }

      const scoreEl = document.getElementById("locScore");
      const minEl = document.getElementById("locMin");
      const feedEl = document.getElementById("locFeed");
      if (scoreEl) scoreEl.textContent = `${state.club} ${s.ours} - ${s.theirs} ${rival}`;
      if (minEl) minEl.textContent = `${s.minute}′ · استحواذ ${Math.round((s.possTicks / s.totalTicks) * 100)}%`;
      if (feedEl) feedEl.innerHTML = s.events.slice(-5).reverse().map((e) => `<div>${esc(e)}</div>`).join("");

      if (s.minute >= 90) {
        finishLocalClubMatch();
      }
    };

    const finishLocalClubMatch = () => {
      const s = localMatchSession;
      if (!s || s.finished) return;
      s.finished = true;
      if (s.timer) clearInterval(s.timer);
      sfx("whistle");

      const hg = isHome ? s.ours : s.theirs;
      const ag = isHome ? s.theirs : s.ours;
      starters.forEach((p) => {
        p.apps++;
        p.fitness = Math.max(45, p.fitness - (10 + Math.floor(Math.random() * 8)));
        p.morale = Math.max(35, Math.min(99, p.morale + (s.ours > s.theirs ? 5 : s.ours === s.theirs ? 1 : -4)));
      });
      state.played++;
      state.goalsFor += hg;
      state.goalsAgainst += ag;
      if (s.ours > s.theirs) {
        state.wins++;
        state.points += 3;
        window.clubBudget += 180000;
        state.fanMood = Math.min(99, state.fanMood + 4);
      } else if (s.ours === s.theirs) {
        state.draws++;
        state.points += 1;
        window.clubBudget += 90000;
      } else {
        state.losses++;
        state.fanMood = Math.max(30, state.fanMood - 3);
      }
      window.clubBudget += state.sponsor;
      const report = {
        home: isHome ? state.club : rival,
        away: isHome ? rival : state.club,
        hg,
        ag,
        events: s.events,
        poss: Math.round((s.possTicks / s.totalTicks) * 100),
        shots: s.shots,
        shotsOn: s.shotsOn,
        corners: s.corners,
        date: `الموسم ${state.season} · الجولة ${state.week}`,
        mode: `محاكاة 2D تفاعلية (${state.difficulty}) · تعمل أوفلاين وأونلاين`,
      };
      state.lastMatch = report;
      state.history.push({ home: report.home, away: report.away, hg, ag, date: report.date });
      state.week++;
      if (state.week > 19) {
        state.season++;
        state.week = 1;
        state.played = 0;
        state.wins = 0;
        state.draws = 0;
        state.losses = 0;
        state.points = 0;
        state.goalsFor = 0;
        state.goalsAgainst = 0;
        players.forEach((p) => {
          p.contract = Math.max(1, p.contract - 1);
          p.fitness = Math.min(100, p.fitness + 20);
        });
      }
      if (typeof window.saveClub === "function") window.saveClub();
      reportGameResult("ultimate_club_match", s.ours * 100 + s.shotsOn * 10, s.ours > s.theirs, state.difficulty);
      setTimeout(() => {
        if (window.clubTab === "match") window.renderClub();
      }, 900);
    };

    localMatchSession.finishNow = finishLocalClubMatch;
    localMatchSession.step = stepSim;
    localMatchSession.timer = setInterval(stepSim, 260);

    let alive = true;
    const rafTick = (t) => {
      if (!alive || !document.getElementById("localClubCanvas") || !localMatchSession) return;
      renderer.render(
        {
          ballX: localMatchSession.ballX,
          ballY: localMatchSession.ballY,
          possessionSide: localMatchSession.possessionSide,
          homeFormation: state.formation || "4-3-3",
          awayFormation: "4-3-3",
          homePress: localMatchSession.style === "ضغط عالٍ",
        },
        t,
      );
      requestAnimationFrame(rafTick);
    };
    requestAnimationFrame(rafTick);
    activeLoopCancel = () => {
      alive = false;
      if (localMatchSession?.timer) clearInterval(localMatchSession.timer);
    };
  };

  window.myaiLocalClubStyle = function (st) {
    if (!localMatchSession) return;
    localMatchSession.style = st;
    localMatchSession.events.push(`🔄 ${localMatchSession.minute}′ تغيير تكتيكي: ${st}`);
    sfx("click");
    say(`تم التبديل إلى أسلوب: ${st}`);
  };
  window.myaiLocalClubSpeed = function () {
    if (!localMatchSession || localMatchSession.finished) return;
    if (localMatchSession.timer) clearInterval(localMatchSession.timer);
    localMatchSession.speed = localMatchSession.speed === 1 ? 2 : 1;
    localMatchSession.timer = setInterval(localMatchSession.step, localMatchSession.speed === 2 ? 120 : 260);
    sfx("click");
  };
  window.myaiLocalClubSkip = function () {
    if (!localMatchSession || localMatchSession.finished) return;
    while (localMatchSession.minute < 90 && !localMatchSession.finished) {
      localMatchSession.step();
    }
  };

  // =========================================================================
  // 2) NEW 2D PHYSICS ARCADE GAME #1: Penalty & Free-Kick Physics Arena
  // =========================================================================
  window.myaiOpenPenaltyGame = function (difficulty = "متوسط") {
    stopActiveCanvasLoop();
    const diffs = ["سهل", "متوسط", "صعب", "أسطوري"];
    window.openFeature(
      "ساحة ركلات الجزاء والحرة 2D",
      "اسحب من الكرة وحدد الزاوية والقوة والالتفاف — فيزياء حقيقية وحارس ذكي",
      `<div class="myai-pro-card">
        <div class="myai-hud-bar">
          <span id="penScoreHud">الأهداف: 0 / 5</span>
          <span id="penRoundHud" class="myai-badge ok">جولة 1 · ${esc(difficulty)}</span>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
          ${diffs.map((d) => `<button type="button" class="myai-mini-btn ${d === difficulty ? "primary-mini" : ""}" onclick="myaiOpenPenaltyGame('${d}')">${d}</button>`).join("")}
        </div>
        <div class="myai-canvas-wrap">
          <canvas id="penaltyCanvas" width="640" height="400" style="touch-action:none"></canvas>
        </div>
        <p id="penHint" class="myai-v3-muted" style="text-align:center;margin-top:8px">اسحب إصبعك أو المؤشر من عند الكرة نحو المرمى ثم اترك للتسديد!</p>
      </div>`,
    );

    const canvas = document.getElementById("penaltyCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    const neon = hasOwnedItem("arcade_neon_trail");

    const aiSkill = difficulty === "أسطوري" ? 0.86 : difficulty === "صعب" ? 0.68 : difficulty === "متوسط" ? 0.5 : 0.3;
    let goals = 0;
    let round = 1;
    const totalRounds = 5;
    let scorePts = 0;
    let streak = 0;
    let finished = false;
    let phase = "aim"; // aim | flight | resolve
    let dragStart = null;
    let dragCur = null;
    let wallX = W / 2;
    let wallDir = 1;

    const goalRect = { x: 110, y: 42, w: 420, h: 120 };
    const keeper = { x: W / 2, y: 128, w: 46, h: 36, targetX: W / 2, vx: 0 };
    const ball = { x: W / 2, y: 332, z: 0, vx: 0, vy: 0, spin: 0, r: 12, trail: [] };

    const resetRound = () => {
      phase = "aim";
      ball.x = round >= 4 ? (round === 4 ? W * 0.35 : W * 0.65) : W / 2;
      ball.y = 335;
      ball.z = 0;
      ball.vx = 0;
      ball.vy = 0;
      ball.spin = 0;
      ball.trail = [];
      keeper.x = W / 2;
      keeper.targetX = W / 2;
      const hudS = document.getElementById("penScoreHud");
      const hudR = document.getElementById("penRoundHud");
      if (hudS) hudS.textContent = `الأهداف: ${goals} / ${totalRounds} · ${scorePts} نقطة`;
      if (hudR) hudR.textContent = `جولة ${round} (${round >= 4 ? "ركلة حرة + حائط" : "ركلة جزاء"}) · ${difficulty}`;
    };
    resetRound();

    const getPointer = (e) => {
      const r = canvas.getBoundingClientRect();
      return {
        x: ((e.clientX - r.left) / r.width) * W,
        y: ((e.clientY - r.top) / r.height) * H,
      };
    };

    canvas.onpointerdown = (e) => {
      if (phase !== "aim" || finished) return;
      canvas.setPointerCapture?.(e.pointerId);
      dragStart = { x: ball.x, y: ball.y };
      dragCur = getPointer(e);
    };
    canvas.onpointermove = (e) => {
      if (!dragStart || phase !== "aim") return;
      dragCur = getPointer(e);
    };
    canvas.onpointerup = () => {
      if (!dragStart || !dragCur || phase !== "aim") {
        dragStart = null;
        return;
      }
      const dx = dragCur.x - dragStart.x;
      const dy = dragCur.y - dragStart.y;
      if (dy > -25) {
        dragStart = null;
        dragCur = null;
        say("اسحب للأعلى باتجاه المرمى للتسديد!");
        return;
      }
      const speedScale = 0.085;
      ball.vx = Math.max(-13, Math.min(13, dx * speedScale));
      ball.vy = Math.max(-18, Math.min(-7, dy * speedScale));
      ball.spin = (dx * 0.0028);
      // AI keeper reaction & anticipation scaled by difficulty
      const predictedX = ball.x + ball.vx * 16;
      const guessBlend = aiSkill * predictedX + (1 - aiSkill) * (goalRect.x + Math.random() * goalRect.w);
      keeper.targetX = Math.max(goalRect.x + 28, Math.min(goalRect.x + goalRect.w - 28, guessBlend));
      phase = "flight";
      dragStart = null;
      dragCur = null;
      sfx("kick");
    };

    const advanceOrFinish = (msg, wasGoal) => {
      phase = "resolve";
      const hint = document.getElementById("penHint");
      if (hint) hint.textContent = msg;
      setTimeout(() => {
        if (!document.getElementById("penaltyCanvas")) return;
        if (round >= totalRounds) {
          finished = true;
          const won = goals >= 3;
          sfx(won ? "fanfare" : "wrong");
          reportGameResult("penalty_arena", scorePts + goals * 150, won, difficulty);
          if (hint) {
            hint.innerHTML = `<b>${won ? "🏆 انتهت الجولة بنجاح!" : "انتهت السلسلة!"}</b> سجلت ${goals} من ${totalRounds} (${scorePts} نقطة) <button type="button" class="primary" style="margin-right:8px" onclick="myaiOpenPenaltyGame('${esc(difficulty)}')">🔁 العب مجددًا</button>`;
          }
          const hudS = document.getElementById("penScoreHud");
          if (hudS) hudS.textContent = `النتيجة النهائية: ${goals}/${totalRounds} · ${scorePts} نقطة`;
        } else {
          round++;
          resetRound();
        }
      }, 950);
    };

    let alive = true;
    const tick = () => {
      if (!alive || !document.getElementById("penaltyCanvas")) return;

      // Move defender wall on free-kick rounds (4 and 5)
      if (round >= 4) {
        wallX += wallDir * (difficulty === "أسطوري" ? 2.1 : 1.3);
        if (wallX > W * 0.65 || wallX < W * 0.35) wallDir *= -1;
      }

      if (phase === "flight") {
        ball.vx += ball.spin;
        ball.x += ball.vx;
        ball.y += ball.vy;
        ball.vy *= 0.992;
        if (neon) {
          ball.trail.push({ x: ball.x, y: ball.y });
          if (ball.trail.length > 12) ball.trail.shift();
        }

        // Keeper movement toward target
        keeper.x += (keeper.targetX - keeper.x) * (0.09 + aiSkill * 0.14);

        // Defender wall collision on rounds 4-5
        if (round >= 4 && Math.abs(ball.y - 230) < 16 && Math.abs(ball.x - wallX) < 38) {
          ball.vy = Math.abs(ball.vy) * 0.6;
          ball.vx *= -0.7;
          streak = 0;
          sfx("bounce");
          advanceOrFinish("🛡️ اصطدمت الكرة بحائط الصد!", false);
        } else if (
          Math.abs(ball.y - keeper.y) < 22 &&
          Math.abs(ball.x - keeper.x) < keeper.w * 0.6
        ) {
          ball.vy = Math.abs(ball.vy) * 0.55;
          ball.vx += (ball.x - keeper.x) * 0.25;
          streak = 0;
          sfx("bounce");
          advanceOrFinish("🧤 تصدٍ رائع من حارس المرمى!", false);
        } else if (ball.y <= goalRect.y + 42) {
          // Post hit check
          const nearLeftPost = Math.abs(ball.x - goalRect.x) < 12;
          const nearRightPost = Math.abs(ball.x - (goalRect.x + goalRect.w)) < 12;
          if (nearLeftPost || nearRightPost) {
            ball.vy = Math.abs(ball.vy) * 0.7;
            ball.vx *= -0.8;
            streak = 0;
            sfx("post");
            advanceOrFinish("💥 في القائم!", false);
          } else if (ball.x > goalRect.x + 8 && ball.x < goalRect.x + goalRect.w - 8) {
            goals++;
            streak++;
            scorePts += 100 + streak * 25;
            sfx("goal");
            advanceOrFinish(`⚽ هدف رائع! (+${100 + streak * 25} نقطة)`, true);
          } else {
            streak = 0;
            sfx("wrong");
            advanceOrFinish("❌ خارج المرمى!", false);
          }
        } else if (ball.x < 10 || ball.x > W - 10 || ball.y < 5) {
          streak = 0;
          sfx("wrong");
          advanceOrFinish("❌ الكرة خارج الحدود!", false);
        }
      }

      // Draw scene
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, "#0a1019");
      grad.addColorStop(0.35, "#15572c");
      grad.addColorStop(1, "#0d3d1d");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      // Penalty box lines
      ctx.strokeStyle = "rgba(255,255,255,0.65)";
      ctx.lineWidth = 2;
      ctx.strokeRect(70, goalRect.y + 42, W - 140, 210);

      // Goal net & frame
      ctx.fillStyle = "rgba(255,255,255,0.1)";
      ctx.fillRect(goalRect.x, goalRect.y, goalRect.w, goalRect.h);
      ctx.strokeStyle = "rgba(255,255,255,0.22)";
      ctx.lineWidth = 1;
      for (let nx = goalRect.x + 18; nx < goalRect.x + goalRect.w; nx += 18) {
        ctx.beginPath();
        ctx.moveTo(nx, goalRect.y);
        ctx.lineTo(nx, goalRect.y + goalRect.h);
        ctx.stroke();
      }
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 5;
      ctx.strokeRect(goalRect.x, goalRect.y, goalRect.w, goalRect.h);

      // Defender wall
      if (round >= 4) {
        for (let i = -1; i <= 1; i++) {
          ctx.fillStyle = "#38bdf8";
          ctx.beginPath();
          ctx.arc(wallX + i * 24, 230, 11, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = "#fff";
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }
      }

      // Goalkeeper
      ctx.fillStyle = "#ff2b44";
      ctx.beginPath();
      ctx.roundRect(keeper.x - keeper.w / 2, keeper.y - keeper.h / 2, keeper.w, keeper.h, 9);
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = "#fff";
      ctx.font = "bold 11px Arial";
      ctx.textAlign = "center";
      ctx.fillText("GK", keeper.x, keeper.y + 4);

      // Aim vector preview
      if (phase === "aim" && dragStart && dragCur) {
        ctx.strokeStyle = "rgba(255, 55, 80, 0.9)";
        ctx.lineWidth = 3;
        ctx.setLineDash([7, 5]);
        ctx.beginPath();
        ctx.moveTo(ball.x, ball.y);
        ctx.lineTo(dragCur.x, dragCur.y);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Neon ball trail
      ball.trail.forEach((p, idx) => {
        ctx.fillStyle = `rgba(255,30,60,${((idx + 1) / ball.trail.length) * 0.5})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4 + idx * 0.5, 0, Math.PI * 2);
        ctx.fill();
      });

      // Ball
      ctx.fillStyle = "rgba(0,0,0,0.4)";
      ctx.beginPath();
      ctx.ellipse(ball.x, ball.y + 8, ball.r, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#181818";
      ctx.lineWidth = 2;
      ctx.stroke();

      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    activeLoopCancel = () => {
      alive = false;
    };
  };

  // =========================================================================
  // 3) NEW 2D PHYSICS ARCADE GAME #2: AI Pitch Striker 2D (60fps Air Pitch Duel)
  // =========================================================================
  window.myaiOpenStrikerGame = function (difficulty = "متوسط") {
    stopActiveCanvasLoop();
    const diffs = ["سهل", "متوسط", "صعب", "أسطوري"];
    window.openFeature(
      "AI Pitch Striker 2D",
      "حرك مهاجمك بإصبعك لتسجيل 5 أهداف في مرمى الخصم الذكي — فيزياء تصادم فورية",
      `<div class="myai-pro-card">
        <div class="myai-hud-bar">
          <span id="stkScore">أنت 0 - 0 الخصم</span>
          <span class="myai-badge ok">المستوى: ${esc(difficulty)} · هدف الفوز: 5</span>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:8px 0">
          ${diffs.map((d) => `<button type="button" class="myai-mini-btn ${d === difficulty ? "primary-mini" : ""}" onclick="myaiOpenStrikerGame('${d}')">${d}</button>`).join("")}
        </div>
        <div class="myai-canvas-wrap">
          <canvas id="strikerCanvas" width="600" height="440" style="touch-action:none"></canvas>
        </div>
        <p id="stkHint" class="myai-v3-muted" style="text-align:center;margin-top:8px">اسحب المضرب الأحمر في النصف السفلي لصد الكرة والتسديد نحو المرمى العلوي!</p>
      </div>`,
    );

    const canvas = document.getElementById("strikerCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    const goalW = 170;
    const goalL = (W - goalW) / 2;
    const goalR = goalL + goalW;
    const neon = hasOwnedItem("arcade_neon_trail");

    let myGoals = 0;
    let aiGoals = 0;
    let gameOver = false;
    const aiSpeed = difficulty === "أسطوري" ? 7.8 : difficulty === "صعب" ? 5.9 : difficulty === "متوسط" ? 4.4 : 3.0;

    const player = { x: W / 2, y: H - 64, vx: 0, vy: 0, r: 24 };
    const cpu = { x: W / 2, y: 64, vx: 0, vy: 0, r: 24 };
    const puck = { x: W / 2, y: H / 2, vx: 3.5, vy: 4.2, r: 14, trail: [] };

    const resetPuck = (dirY) => {
      puck.x = W / 2;
      puck.y = H / 2;
      puck.vx = (Math.random() - 0.5) * 6;
      puck.vy = dirY * 4.5;
      puck.trail = [];
    };

    const movePaddle = (e) => {
      if (gameOver) return;
      const r = canvas.getBoundingClientRect();
      const nx = Math.max(player.r + 8, Math.min(W - player.r - 8, ((e.clientX - r.left) / r.width) * W));
      const ny = Math.max(H / 2 + player.r + 4, Math.min(H - player.r - 8, ((e.clientY - r.top) / r.height) * H));
      player.vx = nx - player.x;
      player.vy = ny - player.y;
      player.x = nx;
      player.y = ny;
    };

    canvas.onpointerdown = (e) => {
      canvas.setPointerCapture?.(e.pointerId);
      movePaddle(e);
    };
    canvas.onpointermove = (e) => {
      if (e.buttons > 0 || e.pointerType === "touch") movePaddle(e);
    };

    const collideCircle = (p, paddle) => {
      const dx = p.x - paddle.x;
      const dy = p.y - paddle.y;
      const dist = Math.hypot(dx, dy);
      const minD = p.r + paddle.r;
      if (dist < minD && dist > 0.001) {
        const nx = dx / dist;
        const ny = dy / dist;
        p.x = paddle.x + nx * minD;
        p.y = paddle.y + ny * minD;
        const speed = Math.min(13, Math.max(5.5, Math.hypot(p.vx, p.vy) * 1.05 + Math.hypot(paddle.vx, paddle.vy) * 0.25));
        p.vx = nx * speed + paddle.vx * 0.18;
        p.vy = ny * speed + paddle.vy * 0.18;
        sfx("kick");
      }
    };

    let alive = true;
    const tick = () => {
      if (!alive || !document.getElementById("strikerCanvas")) return;

      if (!gameOver) {
        // AI striker steering
        const targetX = puck.y < H * 0.6 ? puck.x : W / 2;
        const targetY = puck.y < H * 0.45 ? Math.max(cpu.r + 12, puck.y - 16) : 72;
        const dx = targetX - cpu.x;
        const dy = targetY - cpu.y;
        const d = Math.hypot(dx, dy) || 1;
        const step = Math.min(aiSpeed, d);
        cpu.vx = (dx / d) * step;
        cpu.vy = (dy / d) * step;
        cpu.x = Math.max(cpu.r + 8, Math.min(W - cpu.r - 8, cpu.x + cpu.vx));
        cpu.y = Math.max(cpu.r + 8, Math.min(H / 2 - cpu.r - 4, cpu.y + cpu.vy));

        puck.x += puck.vx;
        puck.y += puck.vy;
        puck.vx *= 0.995;
        puck.vy *= 0.995;

        if (neon) {
          puck.trail.push({ x: puck.x, y: puck.y });
          if (puck.trail.length > 10) puck.trail.shift();
        }

        if (puck.x < puck.r + 6) {
          puck.x = puck.r + 6;
          puck.vx = Math.abs(puck.vx);
          sfx("bounce");
        } else if (puck.x > W - puck.r - 6) {
          puck.x = W - puck.r - 6;
          puck.vx = -Math.abs(puck.vx);
          sfx("bounce");
        }

        // Goals or top/bottom walls
        const inGoalX = puck.x > goalL + puck.r && puck.x < goalR - puck.r;
        if (puck.y < puck.r + 6) {
          if (inGoalX) {
            myGoals++;
            sfx("goal");
            const el = document.getElementById("stkScore");
            if (el) el.textContent = `أنت ${myGoals} - ${aiGoals} الخصم`;
            if (myGoals >= 5) {
              gameOver = true;
              sfx("fanfare");
              reportGameResult("pitch_striker", myGoals * 150 - aiGoals * 25, true, difficulty);
              const h = document.getElementById("stkHint");
              if (h) h.innerHTML = `🏆 <b>فزت بالمباراة (${myGoals}-${aiGoals})!</b> <button type="button" class="primary" onclick="myaiOpenStrikerGame('${esc(difficulty)}')">🔁 العب مجددًا</button>`;
            } else {
              resetPuck(1);
            }
          } else {
            puck.y = puck.r + 6;
            puck.vy = Math.abs(puck.vy);
            sfx("bounce");
          }
        } else if (puck.y > H - puck.r - 6) {
          if (inGoalX) {
            aiGoals++;
            sfx("wrong");
            const el = document.getElementById("stkScore");
            if (el) el.textContent = `أنت ${myGoals} - ${aiGoals} الخصم`;
            if (aiGoals >= 5) {
              gameOver = true;
              reportGameResult("pitch_striker", myGoals * 100, false, difficulty);
              const h = document.getElementById("stkHint");
              if (h) h.innerHTML = `انتهت المباراة (${myGoals}-${aiGoals})! <button type="button" class="primary" onclick="myaiOpenStrikerGame('${esc(difficulty)}')">🔁 أعد التحدي</button>`;
            } else {
              resetPuck(-1);
            }
          } else {
            puck.y = H - puck.r - 6;
            puck.vy = -Math.abs(puck.vy);
            sfx("bounce");
          }
        }

        collideCircle(puck, player);
        collideCircle(puck, cpu);
      }

      // Render pitch arena
      ctx.fillStyle = "#0e3b21";
      ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = "rgba(255,255,255,0.45)";
      ctx.lineWidth = 3;
      ctx.strokeRect(6, 6, W - 12, H - 12);
      ctx.beginPath();
      ctx.moveTo(6, H / 2);
      ctx.lineTo(W - 6, H / 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(W / 2, H / 2, 54, 0, Math.PI * 2);
      ctx.stroke();

      // Goal zones
      ctx.fillStyle = "rgba(255,20,46,0.22)";
      ctx.fillRect(goalL, 0, goalW, 12);
      ctx.fillRect(goalL, H - 12, goalW, 12);
      ctx.strokeStyle = "#ff475d";
      ctx.strokeRect(goalL, 2, goalW, 10);
      ctx.strokeRect(goalL, H - 12, goalW, 10);

      // Trail
      puck.trail.forEach((t, i) => {
        ctx.fillStyle = `rgba(255,35,68,${(i + 1) / puck.trail.length * 0.45})`;
        ctx.beginPath();
        ctx.arc(t.x, t.y, 4 + i * 0.8, 0, Math.PI * 2);
        ctx.fill();
      });

      // CPU & Player paddles
      const drawPaddle = (p, color) => {
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 3;
        ctx.stroke();
      };
      drawPaddle(cpu, "#0ea5e9");
      drawPaddle(player, "#ff142e");

      // Ball
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(puck.x, puck.y, puck.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#111";
      ctx.lineWidth = 2;
      ctx.stroke();

      player.vx *= 0.5;
      player.vy *= 0.5;

      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    activeLoopCancel = () => {
      alive = false;
    };
  };

  // =========================================================================
  // 4) UPGRADED EXISTING QUIZ, GUESS PLAYER, ULTIMATE TEAM & GAME CENTER HUB
  // =========================================================================
  const FOOTBALL_BANK = {
    "سهل": [
      { q: "ما عدد اللاعبين الأساسيين في فريق كرة القدم داخل الملعب؟", a: ["10 لاعبين", "11 لاعبًا", "12 لاعبًا"], c: 1 },
      { q: "كم دقيقة مدة المباراة الرسمية دون وقت بدل ضائع؟", a: ["80 دقيقة", "90 دقيقة", "100 دقيقة"], c: 1 },
      { q: "ماذا يشير رفع البطاقة الحمراء مباشرة؟", a: ["ضربة حرة فقط", "طرد اللاعب", "ركلة ركنية"], c: 1 },
      { q: "أي قارة تضم بطولة دوري أبطال أوروبا؟", a: ["أوروبا", "أمريكا الجنوبية", "آسيا"], c: 0 },
      { q: "كم ضربة ترجيح أساسية لكل فريق قبل الموت المفاجئ؟", a: ["3 ركلات", "5 ركلات", "6 ركلات"], c: 1 },
    ],
    "متوسط": [
      { q: "كم نقطة يحصل عليها الفريق عند تحقيق الفوز في الدوري؟", a: ["نقطة واحدة", "نقطتان", "3 نقاط"], c: 2 },
      { q: "أي منتخب تُوّج بلقب كأس العالم 2022؟", a: ["فرنسا", "الأرجنتين", "البرازيل"], c: 1 },
      { q: "ما عدد الأندية التي تبدأ عادة في دور المجموعات بدوري الأبطال النظام التقليدي؟", a: ["24 ناديًا", "32 ناديًا", "40 ناديًا"], c: 1 },
      { q: "في أي مركز يلعب حارس المرمى عادة بالرقم الشهير؟", a: ["الرقم 1", "الرقم 9", "الرقم 10"], c: 0 },
      { q: "أي نادٍ إسباني يلقب بالملكي؟", a: ["برشلونة", "ريال مدريد", "إشبيلية"], c: 1 },
    ],
    "احترافي": [
      { q: "متى يُحتسب التسلل على المهاجم؟", a: ["عند استقباله الكرة من رمية تماس", "إذا سبق الكرة وآخر ثاني مدافع لحظة التمرير", "عند وجوده في نصف ملعبه"], c: 1 },
      { q: "ما أقصى عدد للتبديلات المسموح بها في البطولات الرسمية حاليًا خلال 90 دقيقة؟", a: ["3 تبديلات", "5 تبديلات", "7 تبديلات"], c: 1 },
      { q: "من الأكثر تتويجًا بدوري أبطال أوروبا تاريخيًا؟", a: ["ريال مدريد", "ميلان", "بايرن ميونخ"], c: 0 },
      { q: "أي قاعدة تمنع إرجاع الكرة بالقدم للحارس ليلتقطها بيديه؟", a: ["قاعدة التمريرة الخلفية", "قاعدة خط التماس", "ركلة البداية"], c: 0 },
      { q: "ما اسم تقنية الفيديو المساعدة للحكم؟", a: ["VAR", "DRS", "GPS"], c: 0 },
    ],
  };

  window.myaiV3FootballQuiz = function (level = "متوسط") {
    stopActiveCanvasLoop();
    const questions = FOOTBALL_BANK[level] || FOOTBALL_BANK["متوسط"];
    let idx = 0;
    let score = 0;
    let streak = 0;
    let timerId = null;

    const renderQ = () => {
      clearInterval(timerId);
      if (idx >= questions.length) {
        const won = score >= 3;
        sfx(won ? "fanfare" : "wrong");
        reportGameResult("football_quiz", score * 100 + streak * 25, won, level);
        window.openFeature(
          "نتيجة تحدي الأسئلة الكروية",
          `المستوى: ${level}`,
          `<div class="myai-pro-card" style="text-align:center">
            <h3>${won ? "🏆 أداء ممتاز!" : "⚽ نهاية التحدي"}</h3>
            <p style="font-size:24px;font-weight:900">${score} / ${questions.length}</p>
            <button type="button" class="primary feature-action" onclick="myaiV3FootballQuiz('${esc(level)}')">إعادة اللعب</button>
          </div>`,
        );
        return;
      }

      let sec = 18;
      const q = questions[idx];
      window.openFeature(
        "⚽ أسئلة كروية تفاعلية",
        `السؤال ${idx + 1} من ${questions.length} · المستوى: ${level}`,
        `<div class="myai-pro-card">
          <div class="myai-hud-bar">
            <span>النقاط: ${score} · سلسلة: ${streak}</span>
            <span id="fqTimer" class="myai-badge">${sec} ث</span>
          </div>
          <div style="display:flex;gap:6px;margin:8px 0">
            ${["سهل", "متوسط", "احترافي"].map((l) => `<button type="button" class="myai-mini-btn ${l === level ? "primary-mini" : ""}" onclick="myaiV3FootballQuiz('${l}')">${l}</button>`).join("")}
          </div>
          <h3 style="margin:10px 0">${esc(q.q)}</h3>
          <div style="display:grid;gap:8px">${q.a.map((opt, i) => `<button type="button" class="myai-v3-tile" style="width:100%" onclick="window._fqAnswer(${i})">${esc(opt)}</button>`).join("")}</div>
        </div>`,
      );

      timerId = setInterval(() => {
        sec--;
        const el = document.getElementById("fqTimer");
        if (!el) {
          clearInterval(timerId);
          return;
        }
        el.textContent = sec + " ث";
        if (sec <= 0) {
          clearInterval(timerId);
          streak = 0;
          sfx("wrong");
          say("انتهى وقت السؤال!");
          idx++;
          renderQ();
        }
      }, 1000);

      window._fqAnswer = (picked) => {
        clearInterval(timerId);
        if (picked === q.c) {
          score++;
          streak++;
          sfx("correct");
          say("✅ إجابة صحيحة!");
        } else {
          streak = 0;
          sfx("wrong");
          say("❌ الإجابة الصحيحة: " + q.a[q.c]);
        }
        idx++;
        renderQ();
      };
    };
    renderQ();
  };

  const GUESS_PLAYERS_BANK = [
    { name: "محمد صلاح", hints: ["يلعب في الدوري الإنجليزي مع ليفربول", "جناح أيمن مصري سريع", "يلقب بالملك المصري ويحمل الرقم 11"], opts: ["محمد صلاح", "رياض محرز", "ساديو ماني", "أشرف حكيمي"] },
    { name: "ليونيل ميسي", hints: ["بطل كأس العالم 2022 مع الأرجنتين", "أحد أعظم لاعبي برشلونة عبر التاريخ", "توج بالكرة الذهبية 8 مرات"], opts: ["كريستيانو رونالدو", "ليونيل ميسي", "نيمار", "مودريتش"] },
    { name: "أشرف حكيمي", hints: ["ظهير أيمن مغربي سريع للغاية", "وصل مع المغرب لنصف نهائي مونديال 2022", "يلعب في باريس سان جيرمان"], opts: ["أشرف حكيمي", "مزراوي", "كانسيلو", "ترينت أرنولد"] },
    { name: "إيرلينغ هالاند", hints: ["مهاجم نرويجي هداف طويل القامة", "حطم رقم الأهداف في موسم واحد بالبريميرليغ", "يلعب في مانشستر سيتي"], opts: ["هاري كين", "إيرلينغ هالاند", "مبابي", "ليفاندوفسكي"] },
    { name: "كيليان مبابي", hints: ["سجل هاتريك في نهائي كأس العالم 2022", "نجم منتخب فرنسا الفائز بمونديال 2018", "يلعب في الدوري الإسباني مع ريال مدريد"], opts: ["كيليان مبابي", "فينيسيوس", "ديمبيلي", "غريزمان"] },
    { name: "لوكا مودريتش", hints: ["قائد منتخب كرواتيا ووصيف مونديال 2018", "مايسترو خط وسط ريال مدريد", "فاز بالكرة الذهبية عام 2018"], opts: ["توني كروس", "كيفين دي بروين", "لوكا مودريتش", "إنييستا"] },
  ];

  window.myaiV3GuessPlayer = function () {
    let idx = 0;
    let score = 0;
    let hintsShown = 1;

    const renderRound = () => {
      if (idx >= GUESS_PLAYERS_BANK.length) {
        const won = score >= 4;
        sfx(won ? "fanfare" : "wrong");
        reportGameResult("guess_player", score * 100, won, "متوسط");
        window.openFeature(
          "نتيجة تحدي خمن اللاعب",
          "اكتملت الجولة",
          `<div class="myai-pro-card" style="text-align:center">
            <h3>${won ? "🌟 خبير نجوم الكرة!" : "⚽ نهاية التحدي"}</h3>
            <p style="font-size:24px;font-weight:900">${score} / ${GUESS_PLAYERS_BANK.length}</p>
            <button type="button" class="primary feature-action" onclick="myaiV3GuessPlayer()">العب جولة جديدة</button>
          </div>`,
        );
        return;
      }
      const p = GUESS_PLAYERS_BANK[idx];
      window.openFeature(
        "🔍 خمن اللاعب",
        `اللاعب ${idx + 1} من ${GUESS_PLAYERS_BANK.length} · النقاط: ${score}`,
        `<div class="myai-pro-card">
          <h3>التلميحات المتاحة:</h3>
          <div class="myai-table-list">${p.hints.slice(0, hintsShown).map((h, i) => `<div class="myai-list-item">💡 تلميح ${i + 1}: ${esc(h)}</div>`).join("")}</div>
          ${hintsShown < p.hints.length ? `<button type="button" class="myai-mini-btn" style="margin-top:8px" onclick="window._gpHint()">كشف تلميح إضافي</button>` : ""}
          <div style="display:grid;gap:8px;margin-top:12px">
            ${p.opts.map((o) => `<button type="button" class="myai-v3-tile" style="width:100%" onclick="window._gpPick('${esc(o)}')">${esc(o)}</button>`).join("")}
          </div>
        </div>`,
      );
      window._gpHint = () => {
        hintsShown = Math.min(p.hints.length, hintsShown + 1);
        sfx("click");
        renderRound();
      };
      window._gpPick = (choice) => {
        if (choice === p.name) {
          score++;
          sfx("correct");
          say("✅ ممتاز! هو " + p.name);
        } else {
          sfx("wrong");
          say("❌ اللاعب الصحيح: " + p.name);
        }
        idx++;
        hintsShown = 1;
        renderRound();
      };
    };
    renderRound();
  };

  // Unified Game Center Hub (preserves Ultimate Club + Ultimate Team + Custom Games + New Physics Arcade)
  window.myaiOpenGames = function () {
    if (typeof window.myaiSetNavActive === "function") window.myaiSetNavActive(3);
    stopActiveCanvasLoop();
    const rawCustom = typeof window.myaiSafeParse === "function"
      ? window.myaiSafeParse(localStorage.getItem("myai_custom_games_v1"), [])
      : [];
    const customGames = Array.isArray(rawCustom) ? rawCustom : [];
    const records = getLocalRecords();
    const muted = window.MYAISound?.isMuted?.() || false;
    const playingMusic = window.MYAISound?.isMusicPlaying?.() || false;
    const dailyCap = window.myaiSessionState?.user?.dailyGamePointsCap ?? 150;
    const dailyEarned = window.myaiSessionState?.user?.dailyGamePoints ?? 0;

    const customRows = customGames
      .map(
        (g, i) => `<div class="game-slot"><span style="font-size:26px">🎮</span><b>${esc(g.name)}</b><small>لعبة مخصصة</small><button class="primary" style="margin-top:8px;padding:8px 12px" onclick="myaiLaunchGame(${i})">تشغيل</button></div>`,
      )
      .join("");

    window.openFeature(
      "مركز الألعاب التفاعلي MY AI",
      "لعبة كرة قدم 3D حقيقية + فيزياء 2D + إدارة أندية + PvP أونلاين — متزامنة مع نظام النقاط",
      `
        <div class="myai-pro-card">
          <div class="myai-pro-row">
            <div><b>نقاط الألعاب اليوم:</b> <span class="myai-badge ok">${dailyEarned} / ${dailyCap} نقطة</span></div>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <button type="button" class="myai-mini-btn" onclick="MYAISound?.toggleMute();myaiOpenGames()">${muted ? "🔇 الصوت مكتوم" : "🔊 المؤثرات مفعلة"}</button>
              <button type="button" class="myai-mini-btn" onclick="MYAISound?.toggleMusic();myaiOpenGames()">${playingMusic ? "🎵 إيقاف الموسيقى" : "🎶 موسيقى خلفية"}</button>
              <button type="button" class="myai-mini-btn primary-mini" onclick="myaiOpenAccountPro('points')">🛒 المتجر والنقاط</button>
            </div>
          </div>
        </div>

        <div class="feature-result" style="border-color:#facc15;background:linear-gradient(135deg,#2a050d,#110c10)">
          <div class="myai-pro-row">
            <h3>⚽ MY AI FOOTBALL · 3D STADIUM (جديد!)</h3>
            <span class="myai-badge ok">Three.js WebGL 3D</span>
          </div>
          <p>مباراة كرة قدم حقيقية ثلاثية الأبعاد (11 ضد 11) بملعب ثلاثي الأبعاد، فيزياء كرة واقعية، حارس يرتمي، 5 كاميرات، وتحكم باللمس ولوحة المفاتيح!</p>
          <div class="myai-pro-grid2">
            <button class="primary feature-action" onclick="myaiOpenFootball3D()">▶ العب MY AI FOOTBALL 3D الآن</button>
            <button class="myai-v3-btn feature-action" onclick="myaiOpenPlayersDatabase()">🌍 قاعدة بيانات اللاعبين والفرق</button>
          </div>
        </div>

        <div class="feature-result" style="border-color:#ff3349">
          <h3>⚽ MY AI ULTIMATE CLUB (الإصدار المطور)</h3>
          <p>ملعب بث 2D حي بـ 22 لاعبًا، تكتيك مباشر أثناء المباراة، ولعب جماعي حقيقي أونلاين PvP عبر الغرف!</p>
          <div class="myai-pro-grid2">
            <button class="primary feature-action" onclick="openUltimateClub()">دخول Ultimate Club</button>
            <button class="myai-v3-btn feature-action" onclick="clubTab='pvp';renderClub()">⚔️ لعب جماعي أونلاين PvP</button>
          </div>
        </div>

        <h3 style="margin-top:16px">🎯 ألعاب الفيزياء والحركة (2D Canvas · أوفلاين وأونلاين)</h3>
        <div class="game-library-grid">
          <button type="button" class="game-slot" onclick="myaiOpenPenaltyGame('متوسط')">
            <span style="font-size:28px">🥅</span>
            <b>ركلات الجزاء والحرة 2D</b>
            <small>فيزياء + حائط صد + حارس ذكي<br>أفضل رقم: ${records.penalty_arena?.highScore || 0}</small>
          </button>
          <button type="button" class="game-slot" onclick="myaiOpenStrikerGame('متوسط')">
            <span style="font-size:28px">⚡</span>
            <b>AI Pitch Striker 2D</b>
            <small>مبارزة 60 إطار/ثانية + خصم متدرج<br>انتصارات: ${records.pitch_striker?.wins || 0}</small>
          </button>
        </div>

        <h3 style="margin-top:16px">🧠 تحديات الذكاء والمعلومات الكروية</h3>
        <div class="game-library-grid">
          <button type="button" class="game-slot" onclick="myaiV3AIQuizStart()">
            <span style="font-size:28px">🤖</span>
            <b>تحدي Gemini الكروي</b>
            <small>أسئلة متجددة من Gemini AI</small>
          </button>
          <button type="button" class="game-slot" onclick="myaiV3OpenUltimateTeam()">
            <span style="font-size:28px">🃏</span>
            <b>MY AI Ultimate Team</b>
            <small>فتح حزم وبناء فريقك</small>
          </button>
          <button type="button" class="game-slot" onclick="myaiV3FootballQuiz('متوسط')">
            <span style="font-size:28px">⚽</span>
            <b>أسئلة كروية سريعة</b>
            <small>مؤقت + كومبو · أوفلاين وأونلاين</small>
          </button>
          <button type="button" class="game-slot" onclick="myaiV3GuessPlayer()">
            <span style="font-size:28px">🔍</span>
            <b>خمن اللاعب</b>
            <small>تلميحات متدرجة لـ 6 نجوم</small>
          </button>
        </div>

        <h3 style="margin-top:16px">مكتبة الألعاب المخصصة</h3>
        <div class="game-library-grid">${customRows || '<div class="game-slot"><span>＋</span><b>مساحة لعبة 1</b><small>جاهزة لإضافة لعبتك</small></div><div class="game-slot"><span>＋</span><b>مساحة لعبة 2</b><small>جاهزة لإضافة لعبتك</small></div>'}</div>
        <div class="feature-result">
          <h3>إضافة لعبة خارجية</h3>
          <input class="feature-field" id="myaiGameName" placeholder="اسم اللعبة">
          <input class="feature-field" id="myaiGameUrl" type="url" placeholder="رابط اللعبة https://...">
          <button class="primary feature-action" onclick="myaiAddGame()">حفظ اللعبة في مكتبتي</button>
        </div>
      `,
    );
  };

  window.myaiBuyVirtualItem = async function (itemId) {
    try {
      const data = await window.myaiApiFetch("/api/shop/buy", {
        method: "POST",
        body: JSON.stringify({ itemId }),
      });
      sfx("packOpen");
      say(`🎉 تم فتح: ${data.item?.name || "العنصر الجديد"}!`);
      if (document.getElementById("myaiProAccountBody")) {
        window.myaiAccountTabSwitch("points");
      } else if (window.clubTab === "shop") {
        window.renderClub();
      }
    } catch (err) {
      sfx("wrong");
      say(err.message);
    }
  };
})();
