import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';

interface TeamInfo {
  id: string;
  name: string;
  nameEn: string;
  league: string;
  country: string;
  primary: string;
  secondary: string;
  ovr: number;
  formation: string;
}

interface SquadMember {
  name: string;
  role: string;
  ovr: number;
  pac: number;
  sho: number;
  pas: number;
  dri: number;
  def: number;
  jerseyNo: number;
  skinHex: string;
  hairHex: string;
}

declare global {
  interface Window {
    MYAI_PLAYERS_DB?: {
      TEAMS: TeamInfo[];
      getTeamLineupForMatch: (teamId: string) => { team: TeamInfo; squad: SquadMember[] };
    };
    MYAISound?: {
      click?: () => void;
      kick?: () => void;
      bounce?: () => void;
      post?: () => void;
      whistle?: () => void;
      goal?: () => void;
      fanfare?: () => void;
      coin?: () => void;
    };
    myaiApiFetch?: (url: string, options?: RequestInit & { timeoutMs?: number }) => Promise<any>;
    notify?: (msg: string) => void;
    escapeHTML?: (s: string) => string;
    myaiOpenFootball3D?: (opts?: { homeTeamId?: string; awayTeamId?: string }) => void;
    closeFeature?: () => void;
  }
}

type DifficultyKey = 'سهل' | 'متوسط' | 'صعب' | 'أسطوري';
type QualityKey = 'low' | 'medium' | 'high';
type LightingKey = 'night' | 'day';
type FormationKey = '4-3-3' | '4-4-2' | '3-5-2';
type CameraModeKey = 'broadcast' | 'dynamic' | 'wide' | 'tele' | 'focus';

interface MatchConfig {
  homeTeamId: string;
  awayTeamId: string;
  formation: FormationKey;
  halfSeconds: number;
  difficulty: DifficultyKey;
  lighting: LightingKey;
  quality: QualityKey;
  hudSize: 'sm' | 'md' | 'lg';
  hudOpacity: number;
}

interface PlayerEntity {
  id: string;
  side: 'home' | 'away';
  idx: number;
  info: SquadMember;
  baseX: number;
  baseZ: number;
  x: number;
  z: number;
  vx: number;
  vz: number;
  facing: number;
  stamina: number;
  isGk: boolean;
  kickAnim: number;
  tackleCooldown: number;
  diveTimer: number;
  diveDir: number;
  stridePhase: number;
  group: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
}

const PITCH_W = 104;
const PITCH_D = 68;
const HALF_W = PITCH_W / 2;
const HALF_D = PITCH_D / 2;
const GOAL_W = 7.6;
const GOAL_HALF_W = GOAL_W / 2;
const GOAL_H = 2.6;
const GOAL_DEPTH = 2.3;
const BALL_R = 0.24;

const CAMERA_LABELS: Record<CameraModeKey, string> = {
  broadcast: 'بث تلفزيوني',
  dynamic: 'ديناميكية',
  wide: 'واسعة',
  tele: 'علوية',
  focus: 'تركيز اللاعب',
};
const CAMERA_ORDER: CameraModeKey[] = ['broadcast', 'dynamic', 'wide', 'tele', 'focus'];

const FORMATIONS: Record<FormationKey, Array<[number, number]>> = {
  '4-3-3': [
    [-49, 0],
    [-34, -22], [-37, -8], [-37, 8], [-34, 22],
    [-16, -15], [-21, 0], [-16, 15],
    [-4, -22], [-1, 0], [-4, 22],
  ],
  '4-4-2': [
    [-49, 0],
    [-34, -22], [-37, -8], [-37, 8], [-34, 22],
    [-14, -22], [-18, -7], [-18, 7], [-14, 22],
    [-2, -9], [-2, 9],
  ],
  '3-5-2': [
    [-49, 0],
    [-36, -16], [-38, 0], [-36, 16],
    [-16, -24], [-22, -9], [-15, 0], [-22, 9], [-16, 24],
    [-2, -9], [-2, 9],
  ],
};

function detectSoftwareGl(): boolean {
  try {
    const c = document.createElement('canvas');
    const gl = (c.getContext('webgl2') || c.getContext('webgl')) as WebGLRenderingContext | null;
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      const r = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || '');
      if (/SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(r)) return true;
    }
    return false;
  } catch {
    return true;
  }
}

function escHtml(v: unknown): string {
  if (typeof window.escapeHTML === 'function') return window.escapeHTML(String(v ?? ''));
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] || c));
}

function sfx(name: keyof NonNullable<Window['MYAISound']>): void {
  try {
    window.MYAISound?.[name]?.();
  } catch {
    // ignore audio errors
  }
}

function makePitchTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 680;
  const ctx = c.getContext('2d')!;

  // Crisp mowed grass stripes
  const stripes = 14;
  const sw = c.width / stripes;
  for (let i = 0; i < stripes; i++) {
    ctx.fillStyle = i % 2 === 0 ? '#185e2a' : '#1d6e32';
    ctx.fillRect(i * sw, 0, sw + 1, c.height);
  }

  // Subtle organic turf grain
  ctx.fillStyle = 'rgba(255,255,255,0.025)';
  for (let i = 0; i < 420; i++) {
    const rx = (i * 97) % c.width;
    const ry = (i * 53) % c.height;
    ctx.fillRect(rx, ry, 3, 2);
  }

  const m = 24;
  const pw = c.width - m * 2;
  const ph = c.height - m * 2;
  ctx.strokeStyle = 'rgba(255,255,255,0.88)';
  ctx.lineWidth = 4;

  // Outer touchline + goal lines
  ctx.strokeRect(m, m, pw, ph);

  // Halfway line & center circle
  ctx.beginPath();
  ctx.moveTo(c.width / 2, m);
  ctx.lineTo(c.width / 2, c.height - m);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(c.width / 2, c.height / 2, 86, 0, Math.PI * 2);
  ctx.stroke();

  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(c.width / 2, c.height / 2, 5, 0, Math.PI * 2);
  ctx.fill();

  // Left & Right penalty areas + 6-yard boxes
  const penW = pw * 0.16;
  const penH = ph * 0.58;
  const sixW = pw * 0.055;
  const sixH = ph * 0.27;
  ctx.strokeRect(m, c.height / 2 - penH / 2, penW, penH);
  ctx.strokeRect(m, c.height / 2 - sixH / 2, sixW, sixH);
  ctx.strokeRect(c.width - m - penW, c.height / 2 - penH / 2, penW, penH);
  ctx.strokeRect(c.width - m - sixW, c.height / 2 - sixH / 2, sixW, sixH);

  // Penalty arcs
  ctx.beginPath();
  ctx.arc(m + pw * 0.11, c.height / 2, 68, -0.7, 0.7);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(c.width - m - pw * 0.11, c.height / 2, 68, Math.PI - 0.7, Math.PI + 0.7);
  ctx.stroke();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function makeBallTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 128;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, c.width, c.height);
  ctx.fillStyle = '#111827';
  const cols = 6;
  const rows = 3;
  for (let r = 0; r < rows; r++) {
    for (let col = 0; col < cols; col++) {
      if ((r + col) % 2 === 0) {
        const cx = (col + 0.5) * (c.width / cols);
        const cy = (r + 0.5) * (c.height / rows);
        ctx.beginPath();
        for (let k = 0; k < 5; k++) {
          const ang = (k / 5) * Math.PI * 2 - Math.PI / 2;
          const x = cx + Math.cos(ang) * 14;
          const y = cy + Math.sin(ang) * 14;
          if (k === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

class Football3DEngine {
  private container: HTMLElement;
  private cfg: MatchConfig;
  private onMatchEnd: (summary: {
    homeName: string;
    awayName: string;
    homeGoals: number;
    awayGoals: number;
    possessionPct: number;
    shots: number;
    shotsOnTarget: number;
    passes: number;
    difficulty: DifficultyKey;
    durationSec: number;
  }) => void;
  private onExit: () => void;

  private isSoftwareGl: boolean;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private pmremGenerator!: THREE.PMREMGenerator;
  private envRenderTarget: THREE.WebGLRenderTarget | null = null;
  private disposables: Array<{ dispose: () => void }> = [];

  private homeTeam!: TeamInfo;
  private awayTeam!: TeamInfo;
  private players: PlayerEntity[] = [];
  private activeHomeIdx = 9;
  private activeAwayIdx = 9;
  private carrier: PlayerEntity | null = null;
  private lastTouchSide: 'home' | 'away' = 'home';

  private ballMesh!: THREE.Mesh;
  private ballShadow!: THREE.Mesh;
  private activeRing!: THREE.Mesh;
  private passRing!: THREE.Mesh;

  private ballPos = new THREE.Vector3(0, BALL_R, 0);
  private ballVel = new THREE.Vector3(0, 0, 0);
  private camPos = new THREE.Vector3(0, 26, 40);
  private camTarget = new THREE.Vector3(0, 0.8, 0);
  private _tmpDir = new THREE.Vector3();

  private half = 1;
  private matchClock = 0;
  private homeGoals = 0;
  private awayGoals = 0;
  private phase: 'kickoff' | 'playing' | 'goal' | 'halftime' | 'fulltime' = 'kickoff';
  private phaseTimer = 1.2;
  private paused = false;
  private destroyed = false;
  private cameraMode: CameraModeKey = 'broadcast';

  private homePossTime = 0;
  private awayPossTime = 0;
  private homeShots = 0;
  private homeShotsOnTarget = 0;
  private homePasses = 0;

  // Input state
  private keys = new Set<string>();
  private joyVec = { x: 0, z: 0, active: false };
  private joyPointerId: number | null = null;
  private sprintHeld = false;
  private pressHeld = false;
  private shootCharging = false;
  private shootCharge = 0;

  private rafId: number | null = null;
  private timerId: number | null = null;
  private lastTick = 0;

  // HUD DOM refs
  private scoreEl: HTMLElement | null = null;
  private clockEl: HTMLElement | null = null;
  private halfEl: HTMLElement | null = null;
  private playerLabelEl: HTMLElement | null = null;
  private staminaFillEl: HTMLElement | null = null;
  private bannerEl: HTMLElement | null = null;
  private shootFillEl: HTMLElement | null = null;
  private offenseBtnsEl: HTMLElement | null = null;
  private defenseBtnsEl: HTMLElement | null = null;

  constructor(
    container: HTMLElement,
    cfg: MatchConfig,
    onMatchEnd: Football3DEngine['onMatchEnd'],
    onExit: () => void,
  ) {
    this.container = container;
    this.cfg = cfg;
    this.onMatchEnd = onMatchEnd;
    this.onExit = onExit;
    this.isSoftwareGl = detectSoftwareGl();

    const db = window.MYAI_PLAYERS_DB;
    const homePack = db?.getTeamLineupForMatch(cfg.homeTeamId) || this.fallbackLineup('MY AI يونايتد', '#ff142e', '#111111');
    const awayPack = db?.getTeamLineupForMatch(cfg.awayTeamId) || this.fallbackLineup('ريال مدريد', '#f4f4f5', '#d4af37');
    this.homeTeam = homePack.team;
    this.awayTeam = awayPack.team;

    this.buildDomHud();
    this.initThree(homePack.squad, awayPack.squad);
    this.bindInputs();
    this.resetKickoff('home');
    sfx('whistle');

    this.lastTick = performance.now();
    this.scheduleLoop();
  }

  private fallbackLineup(name: string, primary: string, secondary: string) {
    const team: TeamInfo = { id: 'custom', name, nameEn: name, league: 'custom', country: 'MY AI', primary, secondary, ovr: 82, formation: '4-3-3' };
    const squad: SquadMember[] = Array.from({ length: 11 }, (_, i) => ({
      name: `${name} #${i + 1}`,
      role: i === 0 ? 'GK' : 'OUT',
      ovr: 80,
      pac: 80,
      sho: 78,
      pas: 79,
      dri: 79,
      def: 76,
      jerseyNo: i + 1,
      skinHex: '#cfa17d',
      hairHex: '#181414',
    }));
    return { team, squad };
  }

  private buildDomHud(): void {
    const scaleCls = this.cfg.hudSize === 'sm' ? 'hud-sm' : this.cfg.hudSize === 'lg' ? 'hud-lg' : 'hud-md';
    this.container.innerHTML = `
      <div class="myai-f3d-stage" id="myaiF3dCanvasHost"></div>

      <div class="myai-f3d-topbar">
        <div class="myai-f3d-scorecard">
          <span class="team-pill" style="border-color:${escHtml(this.homeTeam.primary)}">${escHtml(this.homeTeam.name)}</span>
          <strong id="f3dScoreText">0 - 0</strong>
          <span class="team-pill" style="border-color:${escHtml(this.awayTeam.primary)}">${escHtml(this.awayTeam.name)}</span>
          <span class="clock-pill"><b id="f3dHalfText">الشوط 1</b> · <span id="f3dClockText">00'</span></span>
        </div>
        <div class="myai-f3d-topactions">
          <button type="button" id="f3dCamBtn">🎥 ${CAMERA_LABELS[this.cameraMode]}</button>
          <button type="button" id="f3dPauseBtn">⏸ إيقاف</button>
          <button type="button" id="f3dExitBtn">✕ خروج</button>
        </div>
      </div>

      <div class="myai-f3d-playerbar">
        <span id="f3dPlayerLabel">${escHtml(this.homeTeam.name)} · #10</span>
        <div class="myai-f3d-stamina"><div id="f3dStaminaFill" style="width:100%"></div></div>
      </div>

      <div class="myai-f3d-banner" id="f3dBanner" style="display:none"></div>

      <div class="myai-f3d-controls ${scaleCls}" style="opacity:${(this.cfg.hudOpacity / 100).toFixed(2)}">
        <div class="myai-f3d-joy-zone" id="f3dJoyZone">
          <div class="myai-f3d-joy-base">
            <div class="myai-f3d-joy-knob" id="f3dJoyKnob"></div>
          </div>
        </div>

        <div class="myai-f3d-action-pad">
          <div id="f3dOffenseBtns" class="myai-f3d-btns-grid">
            <button type="button" class="f3d-btn f3d-shoot" id="f3dShootBtn">
              <span>⚡ تسديد</span>
              <div class="f3d-charge"><i id="f3dShootFill" style="width:0%"></i></div>
            </button>
            <button type="button" class="f3d-btn f3d-pass" id="f3dPassBtn">🎯 تمرير</button>
            <button type="button" class="f3d-btn f3d-lob" id="f3dLobBtn">🪽 بينية/رفع</button>
            <button type="button" class="f3d-btn f3d-sprint" id="f3dSprintBtn">🏃 سرعة</button>
          </div>
          <div id="f3dDefenseBtns" class="myai-f3d-btns-grid" style="display:none">
            <button type="button" class="f3d-btn f3d-tackle" id="f3dTackleBtn">🦵 افتكاك</button>
            <button type="button" class="f3d-btn f3d-press" id="f3dPressBtn">🛡️ ضغط</button>
            <button type="button" class="f3d-btn f3d-switch" id="f3dSwitchBtn">🔄 تبديل</button>
            <button type="button" class="f3d-btn f3d-sprint" id="f3dSprintDefBtn">🏃 سرعة</button>
          </div>
          <div class="myai-f3d-kbd-hint">⌨️ WASD / الأسهم للحركة · J تمرير · K تسديد · L بينية · Shift سرعة · Q تبديل</div>
        </div>
      </div>

      <div class="myai-f3d-pause" id="f3dPauseModal" style="display:none">
        <div class="myai-f3d-pause-card">
          <h3>⏸ المباراة متوقفة</h3>
          <p>${escHtml(this.homeTeam.name)} ${this.homeGoals} - ${this.awayGoals} ${escHtml(this.awayTeam.name)}</p>
          <button type="button" class="primary" id="f3dResumeBtn">▶ استكمال اللعب</button>
          <button type="button" class="myai-v3-btn" id="f3dCycleCamPause">🎥 تغيير الكاميرا</button>
          <button type="button" class="myai-v3-btn" id="f3dEndNowBtn">🏁 إنهاء المباراة الآن</button>
        </div>
      </div>
    `;

    this.scoreEl = document.getElementById('f3dScoreText');
    this.clockEl = document.getElementById('f3dClockText');
    this.halfEl = document.getElementById('f3dHalfText');
    this.playerLabelEl = document.getElementById('f3dPlayerLabel');
    this.staminaFillEl = document.getElementById('f3dStaminaFill');
    this.bannerEl = document.getElementById('f3dBanner');
    this.shootFillEl = document.getElementById('f3dShootFill');
    this.offenseBtnsEl = document.getElementById('f3dOffenseBtns');
    this.defenseBtnsEl = document.getElementById('f3dDefenseBtns');
  }

  private initThree(homeSquad: SquadMember[], awaySquad: SquadMember[]): void {
    const host = document.getElementById('myaiF3dCanvasHost') || this.container;
    const w = host.clientWidth || window.innerWidth;
    const h = host.clientHeight || window.innerHeight;

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl && this.cfg.quality !== 'low',
      powerPreference: 'high-performance',
    });
    const dpr = this.isSoftwareGl ? 1 : this.cfg.quality === 'high' ? Math.min(window.devicePixelRatio, 2) : Math.min(window.devicePixelRatio, 1.4);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(w, h);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = this.cfg.lighting === 'night' ? 1.15 : 1.05;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl && this.cfg.quality === 'high';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    const isNight = this.cfg.lighting === 'night';
    this.scene.background = new THREE.Color(isNight ? '#060911' : '#7cb5e8');
    this.scene.fog = new THREE.Fog(isNight ? '#070b14' : '#9bc9ef', 95, 220);

    this.camera = new THREE.PerspectiveCamera(46, w / h, 0.5, 280);
    this.camera.position.copy(this.camPos);

    this.pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    const roomEnv = new RoomEnvironment();
    this.envRenderTarget = this.pmremGenerator.fromScene(roomEnv, 0.04);
    this.scene.environment = this.envRenderTarget.texture;
    roomEnv.dispose();

    // Stadium Lights
    const hemi = new THREE.HemisphereLight(isNight ? '#b9ccff' : '#ffffff', isNight ? '#132419' : '#1b4724', isNight ? 0.85 : 1.15);
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(isNight ? '#e8f1ff' : '#fff7e6', isNight ? 1.55 : 2.1);
    sun.position.set(28, 52, 32);
    if (this.renderer.shadowMap.enabled) {
      sun.castShadow = true;
      sun.shadow.mapSize.set(1024, 1024);
      sun.shadow.camera.left = -60;
      sun.shadow.camera.right = 60;
      sun.shadow.camera.top = 42;
      sun.shadow.camera.bottom = -42;
    }
    this.scene.add(sun);

    this.buildStadium();
    this.buildGoals();
    this.buildBallAndMarkers();
    this.buildTeams(homeSquad, awaySquad);
  }

  private track<T extends { dispose: () => void }>(item: T): T {
    this.disposables.push(item);
    return item;
  }

  private buildStadium(): void {
    // Pitch Turf
    const pitchTex = this.track(makePitchTexture());
    const pitchGeo = this.track(new THREE.PlaneGeometry(PITCH_W, PITCH_D));
    const pitchMat = this.track(new THREE.MeshStandardMaterial({ map: pitchTex, roughness: 0.88, metalness: 0.02 }));
    const pitch = new THREE.Mesh(pitchGeo, pitchMat);
    pitch.rotation.x = -Math.PI / 2;
    pitch.receiveShadow = true;
    this.scene.add(pitch);

    // Outer Track Apron
    const apronGeo = this.track(new THREE.PlaneGeometry(PITCH_W + 28, PITCH_D + 26));
    const apronMat = this.track(new THREE.MeshStandardMaterial({ color: '#13181f', roughness: 0.92 }));
    const apron = new THREE.Mesh(apronGeo, apronMat);
    apron.rotation.x = -Math.PI / 2;
    apron.position.y = -0.02;
    apron.receiveShadow = true;
    this.scene.add(apron);

    // Crimson/Obsidian Perimeter Boards
    const boardMat = this.track(new THREE.MeshStandardMaterial({ color: '#1b0b10', emissive: '#9c0018', emissiveIntensity: 0.35, roughness: 0.5 }));
    const northGeo = this.track(new THREE.BoxGeometry(PITCH_W + 6, 1.2, 0.4));
    [-HALF_D - 2.6, HALF_D + 2.6].forEach((z) => {
      const b = new THREE.Mesh(northGeo, boardMat);
      b.position.set(0, 0.6, z);
      this.scene.add(b);
    });
    const eastGeo = this.track(new THREE.BoxGeometry(0.4, 1.2, PITCH_D + 5.6));
    [-HALF_W - 3.2, HALF_W + 3.2].forEach((x) => {
      const b = new THREE.Mesh(eastGeo, boardMat);
      b.position.set(x, 0.6, 0);
      this.scene.add(b);
    });

    // Stadium Stands
    const standMat = this.track(new THREE.MeshStandardMaterial({ color: '#171a21', roughness: 0.85 }));
    const standNGeo = this.track(new THREE.BoxGeometry(PITCH_W + 14, 9, 10));
    [-HALF_D - 10, HALF_D + 10].forEach((z) => {
      const s = new THREE.Mesh(standNGeo, standMat);
      s.position.set(0, 4.2, z);
      this.scene.add(s);
    });
    const standEGeo = this.track(new THREE.BoxGeometry(10, 9, PITCH_D + 12));
    [-HALF_W - 10, HALF_W + 10].forEach((x) => {
      const s = new THREE.Mesh(standEGeo, standMat);
      s.position.set(x, 4.2, 0);
      this.scene.add(s);
    });

    // Crowd (InstancedMesh for crisp mobile performance)
    const crowdCount = this.cfg.quality === 'low' ? 140 : 320;
    const crowdGeo = this.track(new THREE.BoxGeometry(0.95, 1.35, 0.95));
    const crowdMat = this.track(new THREE.MeshStandardMaterial({ roughness: 0.7 }));
    const crowd = new THREE.InstancedMesh(crowdGeo, crowdMat, crowdCount);
    const dummy = new THREE.Object3D();
    const palette = [new THREE.Color(this.homeTeam.primary), new THREE.Color('#ffffff'), new THREE.Color(this.awayTeam.primary), new THREE.Color('#ff263f')];
    for (let i = 0; i < crowdCount; i++) {
      const side = i % 4;
      const frac = ((i * 37) % 100) / 100 - 0.5;
      const row = (i % 4) * 1.4;
      if (side === 0) dummy.position.set(frac * PITCH_W, 2.8 + row * 1.1, -HALF_D - 6.5 - row);
      else if (side === 1) dummy.position.set(frac * PITCH_W, 2.8 + row * 1.1, HALF_D + 6.5 + row);
      else if (side === 2) dummy.position.set(-HALF_W - 6.5 - row, 2.8 + row * 1.1, frac * PITCH_D);
      else dummy.position.set(HALF_W + 6.5 + row, 2.8 + row * 1.1, frac * PITCH_D);
      dummy.updateMatrix();
      crowd.setMatrixAt(i, dummy.matrix);
      crowd.setColorAt(i, palette[i % palette.length]);
    }
    crowd.instanceMatrix.needsUpdate = true;
    if (crowd.instanceColor) crowd.instanceColor.needsUpdate = true;
    this.scene.add(crowd);

    // 4 Corner Floodlight Towers
    const poleGeo = this.track(new THREE.CylinderGeometry(0.45, 0.7, 26, 8));
    const poleMat = this.track(new THREE.MeshStandardMaterial({ color: '#3b4252', metalness: 0.6, roughness: 0.4 }));
    const headGeo = this.track(new THREE.BoxGeometry(4.5, 2.2, 1.1));
    const lampMat = this.track(new THREE.MeshStandardMaterial({ color: '#ffffff', emissive: '#fff4d6', emissiveIntensity: this.cfg.lighting === 'night' ? 1.8 : 0.3 }));
    [
      [-HALF_W - 9, -HALF_D - 8],
      [HALF_W + 9, -HALF_D - 8],
      [-HALF_W - 9, HALF_D + 8],
      [HALF_W + 9, HALF_D + 8],
    ].forEach(([tx, tz]) => {
      const tower = new THREE.Group();
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.y = 13;
      const head = new THREE.Mesh(headGeo, lampMat);
      head.position.y = 26;
      head.lookAt(-tx, 0, -tz);
      tower.add(pole, head);
      tower.position.set(tx, 0, tz);
      this.scene.add(tower);
    });
  }

  private buildGoals(): void {
    const postMat = this.track(new THREE.MeshStandardMaterial({ color: '#f8fafc', metalness: 0.55, roughness: 0.25 }));
    const netMat = this.track(
      new THREE.MeshStandardMaterial({
        color: '#e2e8f0',
        transparent: true,
        opacity: 0.32,
        side: THREE.DoubleSide,
        wireframe: true,
      }),
    );
    const postGeo = this.track(new THREE.CylinderGeometry(0.11, 0.11, GOAL_H, 10));
    const barGeo = this.track(new THREE.CylinderGeometry(0.11, 0.11, GOAL_W + 0.22, 10));
    const backNetGeo = this.track(new THREE.PlaneGeometry(GOAL_W, GOAL_H, 10, 4));
    const sideNetGeo = this.track(new THREE.PlaneGeometry(GOAL_DEPTH, GOAL_H, 4, 4));
    const topNetGeo = this.track(new THREE.PlaneGeometry(GOAL_W, GOAL_DEPTH, 10, 4));

    [-1, 1].forEach((dir) => {
      const gx = dir * HALF_W;
      const g = new THREE.Group();

      const p1 = new THREE.Mesh(postGeo, postMat);
      p1.position.set(0, GOAL_H / 2, -GOAL_HALF_W);
      const p2 = new THREE.Mesh(postGeo, postMat);
      p2.position.set(0, GOAL_H / 2, GOAL_HALF_W);
      const bar = new THREE.Mesh(barGeo, postMat);
      bar.rotation.x = Math.PI / 2;
      bar.position.set(0, GOAL_H, 0);

      const back = new THREE.Mesh(backNetGeo, netMat);
      back.rotation.y = Math.PI / 2;
      back.position.set(dir * GOAL_DEPTH, GOAL_H / 2, 0);

      const sideL = new THREE.Mesh(sideNetGeo, netMat);
      sideL.position.set(dir * (GOAL_DEPTH / 2), GOAL_H / 2, -GOAL_HALF_W);
      const sideR = new THREE.Mesh(sideNetGeo, netMat);
      sideR.position.set(dir * (GOAL_DEPTH / 2), GOAL_H / 2, GOAL_HALF_W);

      const top = new THREE.Mesh(topNetGeo, netMat);
      top.rotation.x = Math.PI / 2;
      top.rotation.z = Math.PI / 2;
      top.position.set(dir * (GOAL_DEPTH / 2), GOAL_H, 0);

      g.add(p1, p2, bar, back, sideL, sideR, top);
      g.position.set(gx, 0, 0);
      this.scene.add(g);
    });
  }

  private buildBallAndMarkers(): void {
    const ballGeo = this.track(new THREE.SphereGeometry(BALL_R, 18, 14));
    const ballTex = this.track(makeBallTexture());
    const ballMat = this.track(new THREE.MeshStandardMaterial({ map: ballTex, roughness: 0.35, metalness: 0.05 }));
    this.ballMesh = new THREE.Mesh(ballGeo, ballMat);
    this.ballMesh.castShadow = true;
    this.scene.add(this.ballMesh);

    const shadowGeo = this.track(new THREE.CircleGeometry(BALL_R * 1.15, 16));
    const shadowMat = this.track(new THREE.MeshBasicMaterial({ color: '#000000', transparent: true, opacity: 0.38 }));
    this.ballShadow = new THREE.Mesh(shadowGeo, shadowMat);
    this.ballShadow.rotation.x = -Math.PI / 2;
    this.ballShadow.position.y = 0.02;
    this.scene.add(this.ballShadow);

    const ringGeo = this.track(new THREE.RingGeometry(0.65, 0.88, 24));
    const ringMat = this.track(new THREE.MeshBasicMaterial({ color: '#ff263f', side: THREE.DoubleSide }));
    this.activeRing = new THREE.Mesh(ringGeo, ringMat);
    this.activeRing.rotation.x = -Math.PI / 2;
    this.activeRing.position.y = 0.03;
    this.scene.add(this.activeRing);

    const passGeo = this.track(new THREE.RingGeometry(0.55, 0.72, 20));
    const passMat = this.track(new THREE.MeshBasicMaterial({ color: '#facc15', transparent: true, opacity: 0.75, side: THREE.DoubleSide }));
    this.passRing = new THREE.Mesh(passGeo, passMat);
    this.passRing.rotation.x = -Math.PI / 2;
    this.passRing.position.y = 0.025;
    this.scene.add(this.passRing);
  }

  private buildTeams(homeSquad: SquadMember[], awaySquad: SquadMember[]): void {
    // Shared geometries across all 22 articulated players
    const legGeo = this.track(new THREE.BoxGeometry(0.19, 0.72, 0.21));
    const armGeo = this.track(new THREE.BoxGeometry(0.14, 0.62, 0.16));
    const torsoGeo = this.track(new THREE.BoxGeometry(0.52, 0.68, 0.28));
    const stripeGeo = this.track(new THREE.BoxGeometry(0.54, 0.16, 0.29));
    const shortsGeo = this.track(new THREE.BoxGeometry(0.50, 0.24, 0.29));
    const headGeo = this.track(new THREE.SphereGeometry(0.21, 12, 10));
    const hairGeo = this.track(new THREE.SphereGeometry(0.225, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.56));
    const bootGeo = this.track(new THREE.BoxGeometry(0.2, 0.12, 0.3));

    const makePlayerRig = (info: SquadMember, side: 'home' | 'away', idx: number, baseX: number, baseZ: number): PlayerEntity => {
      const team = side === 'home' ? this.homeTeam : this.awayTeam;
      const isGk = idx === 0;
      const jerseyHex = isGk ? (side === 'home' ? '#facc15' : '#22d3ee') : team.primary;
      const accentHex = team.secondary;

      const skinMat = this.track(new THREE.MeshStandardMaterial({ color: info.skinHex || '#cfa17d', roughness: 0.7 }));
      const hairMat = this.track(new THREE.MeshStandardMaterial({ color: info.hairHex || '#181414', roughness: 0.85 }));
      const jerseyMat = this.track(new THREE.MeshStandardMaterial({ color: jerseyHex, roughness: 0.65 }));
      const accentMat = this.track(new THREE.MeshStandardMaterial({ color: accentHex, roughness: 0.55 }));
      const shortsMat = this.track(new THREE.MeshStandardMaterial({ color: side === 'home' ? '#141418' : '#f1f5f9', roughness: 0.7 }));
      const bootMat = this.track(new THREE.MeshStandardMaterial({ color: '#111111', roughness: 0.5 }));

      const group = new THREE.Group();
      // Left leg pivot at hip y=0.76
      const leftLeg = new THREE.Group();
      leftLeg.position.set(-0.14, 0.76, 0);
      const lLegMesh = new THREE.Mesh(legGeo, skinMat);
      lLegMesh.position.y = -0.36;
      const lBoot = new THREE.Mesh(bootGeo, bootMat);
      lBoot.position.set(0, -0.7, 0.04);
      leftLeg.add(lLegMesh, lBoot);

      const rightLeg = new THREE.Group();
      rightLeg.position.set(0.14, 0.76, 0);
      const rLegMesh = new THREE.Mesh(legGeo, skinMat);
      rLegMesh.position.y = -0.36;
      const rBoot = new THREE.Mesh(bootGeo, bootMat);
      rBoot.position.set(0, -0.7, 0.04);
      rightLeg.add(rLegMesh, rBoot);

      const shorts = new THREE.Mesh(shortsGeo, shortsMat);
      shorts.position.y = 0.78;

      const torso = new THREE.Mesh(torsoGeo, jerseyMat);
      torso.position.y = 1.22;
      torso.castShadow = true;

      const stripe = new THREE.Mesh(stripeGeo, accentMat);
      stripe.position.y = 1.26;

      const leftArm = new THREE.Group();
      leftArm.position.set(-0.34, 1.48, 0);
      const lArmMesh = new THREE.Mesh(armGeo, jerseyMat);
      lArmMesh.position.y = -0.26;
      leftArm.add(lArmMesh);

      const rightArm = new THREE.Group();
      rightArm.position.set(0.34, 1.48, 0);
      const rArmMesh = new THREE.Mesh(armGeo, jerseyMat);
      rArmMesh.position.y = -0.26;
      rightArm.add(rArmMesh);

      const head = new THREE.Mesh(headGeo, skinMat);
      head.position.y = 1.76;
      head.castShadow = true;

      const hair = new THREE.Mesh(hairGeo, hairMat);
      hair.position.y = 1.78;

      group.add(leftLeg, rightLeg, shorts, torso, stripe, leftArm, rightArm, head, hair);
      this.scene.add(group);

      return {
        id: `${side}_${idx}`,
        side,
        idx,
        info,
        baseX,
        baseZ,
        x: baseX,
        z: baseZ,
        vx: 0,
        vz: 0,
        facing: side === 'home' ? Math.PI / 2 : -Math.PI / 2,
        stamina: 100,
        isGk,
        kickAnim: 0,
        tackleCooldown: 0,
        diveTimer: 0,
        diveDir: 0,
        stridePhase: idx * 0.7,
        group,
        leftLeg,
        rightLeg,
        leftArm,
        rightArm,
      };
    };

    const formPts = FORMATIONS[this.cfg.formation] || FORMATIONS['4-3-3'];
    formPts.forEach(([fx, fz], i) => {
      this.players.push(makePlayerRig(homeSquad[i] || homeSquad[0], 'home', i, fx, fz));
    });
    const awayPts = FORMATIONS['4-3-3'];
    awayPts.forEach(([fx, fz], i) => {
      this.players.push(makePlayerRig(awaySquad[i] || awaySquad[0], 'away', i, -fx, -fz));
    });
  }

  private resetKickoff(kickoffSide: 'home' | 'away'): void {
    this.ballPos.set(0, BALL_R, 0);
    this.ballVel.set(0, 0, 0);
    this.carrier = null;
    this.shootCharging = false;
    this.shootCharge = 0;

    this.players.forEach((p) => {
      const startX = p.side === 'home' ? Math.min(-1.5, p.baseX) : Math.max(1.5, p.baseX);
      p.x = p.idx === 9 && p.side === kickoffSide ? (kickoffSide === 'home' ? -0.9 : 0.9) : startX;
      p.z = p.idx === 9 && p.side === kickoffSide ? 0 : p.baseZ;
      p.vx = 0;
      p.vz = 0;
      p.diveTimer = 0;
      p.group.rotation.z = 0;
    });

    this.activeHomeIdx = 9;
    this.activeAwayIdx = 9;
    this.phase = 'kickoff';
    this.phaseTimer = 0.8;
  }

  private showBanner(text: string, durationMs = 2000): void {
    if (!this.bannerEl) return;
    this.bannerEl.textContent = text;
    this.bannerEl.style.display = 'block';
    window.setTimeout(() => {
      if (this.bannerEl && !this.destroyed) this.bannerEl.style.display = 'none';
    }, durationMs);
  }

  private getControlledHome(): PlayerEntity {
    return this.players.find((p) => p.side === 'home' && p.idx === this.activeHomeIdx) || this.players[9];
  }

  private findBestHomeTeammate(ctrl: PlayerEntity): PlayerEntity | null {
    const dirX = Math.sin(ctrl.facing);
    const dirZ = Math.cos(ctrl.facing);
    let best: PlayerEntity | null = null;
    let bestScore = -9999;

    for (const p of this.players) {
      if (p.side !== 'home' || p.id === ctrl.id) continue;
      const dx = p.x - ctrl.x;
      const dz = p.z - ctrl.z;
      const dist = Math.hypot(dx, dz);
      if (dist < 2 || dist > 56) continue;
      const dot = (dx * dirX + dz * dirZ) / dist;
      const sc = dot * 34 - dist * 0.45 + (p.x > ctrl.x ? 8 : 0);
      if (sc > bestScore) {
        bestScore = sc;
        best = p;
      }
    }
    return best;
  }

  private performPass(lob: boolean): void {
    const ctrl = this.getControlledHome();
    if (!this.carrier || this.carrier.side !== 'home') {
      this.switchNearestHomeDefender();
      return;
    }
    const target = this.findBestHomeTeammate(this.carrier);
    const passer = this.carrier;
    this.carrier = null;
    passer.kickAnim = 0.28;
    this.homePasses++;
    sfx('kick');

    let dx = Math.sin(passer.facing);
    let dz = Math.cos(passer.facing);
    let speed = lob ? 22 : 24;

    if (target) {
      const tx = target.x + (lob ? 5 : target.vx * 0.25);
      const tz = target.z + target.vz * 0.2;
      const dist = Math.hypot(tx - passer.x, tz - passer.z) || 1;
      dx = (tx - passer.x) / dist;
      dz = (tz - passer.z) / dist;
      speed = THREE.MathUtils.clamp(dist * (lob ? 0.95 : 1.15), 14, 31);
      this.activeHomeIdx = target.idx;
    }
    this.ballVel.set(dx * speed, lob ? 7.8 : 1.2, dz * speed);
  }

  private performShoot(charge01: number): void {
    if (!this.carrier || this.carrier.side !== 'home') {
      this.performTackle();
      return;
    }
    const shooter = this.carrier;
    this.carrier = null;
    shooter.kickAnim = 0.35;
    this.homeShots++;
    sfx('kick');

    const goalX = HALF_W;
    const aimZ = THREE.MathUtils.clamp(shooter.z * 0.35 + Math.cos(shooter.facing) * 3.8, -GOAL_HALF_W + 0.5, GOAL_HALF_W - 0.5);
    const dx = goalX - shooter.x;
    const dz = aimZ - shooter.z;
    const dist = Math.hypot(dx, dz) || 1;
    if (Math.abs(aimZ) < GOAL_HALF_W) this.homeShotsOnTarget++;

    const power = 25 + charge01 * 18;
    const loft = 2.6 + charge01 * 5.4;
    this.ballVel.set((dx / dist) * power, loft, (dz / dist) * power);
  }

  private performTackle(): void {
    const ctrl = this.getControlledHome();
    if (ctrl.tackleCooldown > 0) return;
    ctrl.tackleCooldown = 0.9;
    ctrl.kickAnim = 0.3;
    ctrl.vx += Math.sin(ctrl.facing) * 10;
    ctrl.vz += Math.cos(ctrl.facing) * 10;
    sfx('bounce');

    const dist = Math.hypot(this.ballPos.x - ctrl.x, this.ballPos.z - ctrl.z);
    if (dist < 2.2) {
      this.carrier = ctrl;
      this.lastTouchSide = 'home';
      sfx('kick');
    }
  }

  private switchNearestHomeDefender(): void {
    let bestIdx = this.activeHomeIdx;
    let bestD = Infinity;
    for (const p of this.players) {
      if (p.side !== 'home' || p.isGk) continue;
      const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
      if (d < bestD) {
        bestD = d;
        bestIdx = p.idx;
      }
    }
    this.activeHomeIdx = bestIdx;
    sfx('click');
  }

  private bindInputs(): void {
    const onResize = () => {
      if (this.destroyed) return;
      const host = document.getElementById('myaiF3dCanvasHost') || this.container;
      const w = host.clientWidth || window.innerWidth;
      const h = host.clientHeight || window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const onKeyDown = (e: KeyboardEvent) => {
      if (this.destroyed) return;
      const k = e.key.toLowerCase();
      this.keys.add(k);
      if (k === 'shift') this.sprintHeld = true;
      if (k === 'j') this.performPass(false);
      if (k === 'l') this.performPass(true);
      if (k === 'q') this.switchNearestHomeDefender();
      if (k === 'k' || e.code === 'Space') {
        if (!this.shootCharging) {
          this.shootCharging = true;
          this.shootCharge = 0.25;
        }
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      this.keys.delete(k);
      if (k === 'shift') this.sprintHeld = false;
      if ((k === 'k' || e.code === 'Space') && this.shootCharging) {
        this.performShoot(this.shootCharge);
        this.shootCharging = false;
        this.shootCharge = 0;
        if (this.shootFillEl) this.shootFillEl.style.width = '0%';
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    // Virtual Joystick
    const joyZone = document.getElementById('f3dJoyZone');
    const joyKnob = document.getElementById('f3dJoyKnob');
    const updateJoy = (clientX: number, clientY: number) => {
      if (!joyZone) return;
      const r = joyZone.getBoundingClientRect();
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const maxR = r.width * 0.36;
      const dx = clientX - cx;
      const dy = clientY - cy;
      const dist = Math.hypot(dx, dy);
      const clampD = Math.min(dist, maxR);
      const ang = Math.atan2(dy, dx);
      const nx = dist > 4 ? (Math.cos(ang) * clampD) / maxR : 0;
      const nz = dist > 4 ? (Math.sin(ang) * clampD) / maxR : 0;
      this.joyVec.x = nx;
      this.joyVec.z = nz;
      if (joyKnob) {
        joyKnob.style.transform = `translate(${nx * 28}px, ${nz * 28}px)`;
      }
    };

    const onJoyDown = (e: PointerEvent) => {
      e.preventDefault();
      this.joyPointerId = e.pointerId;
      this.joyVec.active = true;
      joyZone?.setPointerCapture?.(e.pointerId);
      updateJoy(e.clientX, e.clientY);
    };
    const onJoyMove = (e: PointerEvent) => {
      if (this.joyPointerId !== e.pointerId) return;
      updateJoy(e.clientX, e.clientY);
    };
    const onJoyUp = (e: PointerEvent) => {
      if (this.joyPointerId !== e.pointerId) return;
      this.joyPointerId = null;
      this.joyVec.active = false;
      this.joyVec.x = 0;
      this.joyVec.z = 0;
      if (joyKnob) joyKnob.style.transform = 'translate(0px, 0px)';
    };
    joyZone?.addEventListener('pointerdown', onJoyDown);
    joyZone?.addEventListener('pointermove', onJoyMove);
    joyZone?.addEventListener('pointerup', onJoyUp);
    joyZone?.addEventListener('pointercancel', onJoyUp);

    // Touch action buttons
    const shootBtn = document.getElementById('f3dShootBtn');
    shootBtn?.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      this.shootCharging = true;
      this.shootCharge = 0.28;
    });
    const releaseShoot = () => {
      if (!this.shootCharging) return;
      this.performShoot(this.shootCharge);
      this.shootCharging = false;
      this.shootCharge = 0;
      if (this.shootFillEl) this.shootFillEl.style.width = '0%';
    };
    shootBtn?.addEventListener('pointerup', releaseShoot);
    shootBtn?.addEventListener('pointercancel', releaseShoot);

    document.getElementById('f3dPassBtn')?.addEventListener('click', () => this.performPass(false));
    document.getElementById('f3dLobBtn')?.addEventListener('click', () => this.performPass(true));
    document.getElementById('f3dTackleBtn')?.addEventListener('click', () => this.performTackle());
    document.getElementById('f3dSwitchBtn')?.addEventListener('click', () => this.switchNearestHomeDefender());

    const pressBtn = document.getElementById('f3dPressBtn');
    pressBtn?.addEventListener('pointerdown', () => (this.pressHeld = true));
    pressBtn?.addEventListener('pointerup', () => (this.pressHeld = false));
    pressBtn?.addEventListener('pointercancel', () => (this.pressHeld = false));

    const bindSprint = (el: HTMLElement | null) => {
      el?.addEventListener('pointerdown', () => (this.sprintHeld = true));
      el?.addEventListener('pointerup', () => (this.sprintHeld = false));
      el?.addEventListener('pointercancel', () => (this.sprintHeld = false));
    };
    bindSprint(document.getElementById('f3dSprintBtn'));
    bindSprint(document.getElementById('f3dSprintDefBtn'));

    const cycleCam = () => {
      const nextIdx = (CAMERA_ORDER.indexOf(this.cameraMode) + 1) % CAMERA_ORDER.length;
      this.cameraMode = CAMERA_ORDER[nextIdx];
      const btn = document.getElementById('f3dCamBtn');
      if (btn) btn.textContent = `🎥 ${CAMERA_LABELS[this.cameraMode]}`;
      sfx('click');
    };
    document.getElementById('f3dCamBtn')?.addEventListener('click', cycleCam);
    document.getElementById('f3dCycleCamPause')?.addEventListener('click', cycleCam);

    const togglePause = () => {
      this.paused = !this.paused;
      const pm = document.getElementById('f3dPauseModal');
      if (pm) pm.style.display = this.paused ? 'flex' : 'none';
      sfx('click');
    };
    document.getElementById('f3dPauseBtn')?.addEventListener('click', togglePause);
    document.getElementById('f3dResumeBtn')?.addEventListener('click', togglePause);
    document.getElementById('f3dEndNowBtn')?.addEventListener('click', () => this.finishMatch());
    document.getElementById('f3dExitBtn')?.addEventListener('click', () => this.disposeAndExit());

    this.disposables.push({
      dispose: () => {
        window.removeEventListener('resize', onResize);
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
      },
    });
  }

  private scheduleLoop(): void {
    const step = (now: number) => {
      if (this.destroyed) return;
      const dt = Math.min(0.05, Math.max(0.005, (now - this.lastTick) / 1000));
      this.lastTick = now;

      if (!this.paused && this.phase !== 'fulltime') {
        this.update(dt);
      }
      this.render();

      if (this.isSoftwareGl) {
        this.timerId = window.setTimeout(() => {
          if (!this.destroyed) this.rafId = requestAnimationFrame(step);
        }, 16);
      } else {
        this.rafId = requestAnimationFrame(step);
      }
    };
    this.rafId = requestAnimationFrame(step);
  }

  private getDiffFactors() {
    switch (this.cfg.difficulty) {
      case 'سهل':
        return { aiSpeed: 0.72, aiReact: 0.55, gkReach: 0.65 };
      case 'صعب':
        return { aiSpeed: 1.04, aiReact: 0.92, gkReach: 0.96 };
      case 'أسطوري':
        return { aiSpeed: 1.15, aiReact: 1.08, gkReach: 1.12 };
      default:
        return { aiSpeed: 0.9, aiReact: 0.76, gkReach: 0.82 };
    }
  }

  private update(dt: number): void {
    if (this.shootCharging) {
      this.shootCharge = Math.min(1, this.shootCharge + dt * 1.45);
      if (this.shootFillEl) this.shootFillEl.style.width = `${Math.round(this.shootCharge * 100)}%`;
    }

    if (this.phase === 'kickoff' || this.phase === 'goal' || this.phase === 'halftime') {
      this.phaseTimer -= dt;
      if (this.phaseTimer <= 0) {
        if (this.phase === 'halftime') {
          this.half = 2;
          this.resetKickoff('away');
          this.phase = 'playing';
          this.showBanner('بداية الشوط الثاني!');
          sfx('whistle');
        } else {
          this.phase = 'playing';
        }
      }
      this.updateMeshes(dt);
      return;
    }

    // Advance match clock
    this.matchClock += dt;
    const totalHalfSec = this.cfg.halfSeconds;
    const matchMinute = Math.min(90, Math.floor(((this.half - 1) * totalHalfSec + this.matchClock) / (totalHalfSec * 2) * 90));
    if (this.clockEl) this.clockEl.textContent = `${String(matchMinute).padStart(2, '0')}'`;
    if (this.halfEl) this.halfEl.textContent = this.half === 1 ? 'الشوط 1' : 'الشوط 2';

    if (this.matchClock >= totalHalfSec) {
      this.matchClock = 0;
      if (this.half === 1) {
        this.phase = 'halftime';
        this.phaseTimer = 1.6;
        this.showBanner('نهاية الشوط الأول', 1500);
        sfx('whistle');
        return;
      } else {
        this.finishMatch();
        return;
      }
    }

    if (this.carrier) {
      if (this.carrier.side === 'home') this.homePossTime += dt;
      else this.awayPossTime += dt;
    }

    // Update offense vs defense touch pad visibility
    const homeHasBall = this.carrier?.side === 'home' || (!this.carrier && this.lastTouchSide === 'home');
    if (this.offenseBtnsEl && this.defenseBtnsEl) {
      this.offenseBtnsEl.style.display = homeHasBall ? 'grid' : 'none';
      this.defenseBtnsEl.style.display = homeHasBall ? 'none' : 'grid';
    }

    const diff = this.getDiffFactors();
    const ctrl = this.getControlledHome();

    // Update all players
    for (const p of this.players) {
      if (p.kickAnim > 0) p.kickAnim = Math.max(0, p.kickAnim - dt);
      if (p.tackleCooldown > 0) p.tackleCooldown = Math.max(0, p.tackleCooldown - dt);
      if (p.diveTimer > 0) p.diveTimer = Math.max(0, p.diveTimer - dt);

      const maxSpd = (5.8 + (p.info.pac / 100) * 3.8) * (p.side === 'away' ? diff.aiSpeed : 1);

      if (p.id === ctrl.id) {
        // User Input vector
        let ix = this.joyVec.x;
        let iz = this.joyVec.z;
        if (this.keys.has('w') || this.keys.has('arrowup')) iz -= 1;
        if (this.keys.has('s') || this.keys.has('arrowdown')) iz += 1;
        if (this.keys.has('a') || this.keys.has('arrowleft')) ix -= 1;
        if (this.keys.has('d') || this.keys.has('arrowright')) ix += 1;

        if (this.pressHeld && !this.carrier && Math.abs(ix) < 0.05 && Math.abs(iz) < 0.05) {
          const d = Math.hypot(this.ballPos.x - p.x, this.ballPos.z - p.z) || 1;
          ix = (this.ballPos.x - p.x) / d;
          iz = (this.ballPos.z - p.z) / d;
        }

        const mag = Math.hypot(ix, iz);
        if (mag > 0.05) {
          const sprinting = this.sprintHeld && p.stamina > 8;
          if (sprinting) p.stamina = Math.max(0, p.stamina - dt * 22);
          else p.stamina = Math.min(100, p.stamina + dt * 9);
          const spd = maxSpd * (sprinting ? 1.28 : 1) * Math.min(1, mag);
          p.vx = (ix / mag) * spd;
          p.vz = (iz / mag) * spd;
          p.facing = Math.atan2(p.vx, p.vz);
        } else {
          p.vx *= 0.8;
          p.vz *= 0.8;
          p.stamina = Math.min(100, p.stamina + dt * 14);
        }
      } else if (p.isGk) {
        // Goalkeeper tracks ball near goal line & dives on fast incoming shots
        const gkX = p.side === 'home' ? -HALF_W + 2.2 : HALF_W - 2.2;
        const targetZ = THREE.MathUtils.clamp(this.ballPos.z * 0.45, -GOAL_HALF_W + 0.5, GOAL_HALF_W - 0.5);
        p.vx = (gkX - p.x) * 3.5;
        p.vz = THREE.MathUtils.clamp((targetZ - p.z) * 4.2 * diff.gkReach, -7, 7);
        p.facing = p.side === 'home' ? Math.PI / 2 : -Math.PI / 2;

        // GK auto save & clear
        const distBall = Math.hypot(this.ballPos.x - p.x, this.ballPos.z - p.z);
        if (distBall < 1.55 && this.ballPos.y < GOAL_H + 0.3 && !this.carrier) {
          p.diveTimer = 0.45;
          p.diveDir = Math.sign(this.ballVel.z || (Math.random() - 0.5));
          sfx('bounce');
          // Clear or distribute to teammate
          const clearDir = p.side === 'home' ? 1 : -1;
          this.ballVel.set(clearDir * 21, 5.2, (Math.random() - 0.5) * 14);
          this.lastTouchSide = p.side;
        }
      } else {
        // AI Teammates & Opponents
        this.updateAiOutfield(p, maxSpd, diff);
      }

      p.x = THREE.MathUtils.clamp(p.x + p.vx * dt, -HALF_W - 1, HALF_W + 1);
      p.z = THREE.MathUtils.clamp(p.z + p.vz * dt, -HALF_D - 1, HALF_D + 1);
    }

    this.updateBallPhysics(dt);
    this.updateMeshes(dt);
  }

  private updateAiOutfield(p: PlayerEntity, maxSpd: number, diff: { aiReact: number }): void {
    const attackDir = p.side === 'home' ? 1 : -1;

    if (this.carrier === p) {
      // Away AI carries ball toward home goal (-HALF_W, 0)
      const goalX = -HALF_W;
      const dx = goalX - p.x;
      const dz = -p.z * 0.55;
      const distGoal = Math.hypot(dx, dz) || 1;
      p.vx = (dx / distGoal) * maxSpd * 0.92;
      p.vz = (dz / distGoal) * maxSpd * 0.92;
      p.facing = Math.atan2(p.vx, p.vz);

      // Shoot when within range
      if (p.x < -HALF_W + 25 && Math.random() < 0.04 * diff.aiReact) {
        this.carrier = null;
        p.kickAnim = 0.35;
        sfx('kick');
        const aimZ = (Math.random() - 0.5) * (GOAL_W * 0.72);
        const sdx = goalX - p.x;
        const sdz = aimZ - p.z;
        const sdist = Math.hypot(sdx, sdz) || 1;
        this.ballVel.set((sdx / sdist) * 29, 3.2, (sdz / sdist) * 29);
      } else if (Math.random() < 0.015 * diff.aiReact) {
        // AI pass forward to teammate
        const mate = this.players.find((m) => m.side === 'away' && m.id !== p.id && m.x < p.x - 4 && Math.hypot(m.x - p.x, m.z - p.z) < 32);
        if (mate) {
          this.carrier = null;
          p.kickAnim = 0.25;
          sfx('kick');
          const pd = Math.hypot(mate.x - p.x, mate.z - p.z) || 1;
          this.ballVel.set(((mate.x - p.x) / pd) * 22, 1.0, ((mate.z - p.z) / pd) * 22);
        }
      }
      return;
    }

    // Closest away player presses ball
    const isChaser =
      p.side === 'away' &&
      p.idx === this.activeAwayIdx;

    if (isChaser) {
      const dx = this.ballPos.x - p.x;
      const dz = this.ballPos.z - p.z;
      const d = Math.hypot(dx, dz) || 1;
      p.vx = (dx / d) * maxSpd * 0.95;
      p.vz = (dz / d) * maxSpd * 0.95;
      p.facing = Math.atan2(p.vx, p.vz);
      return;
    }

    // Positional support
    const ballPullX = this.ballPos.x * 0.36;
    const attackPush = this.carrier?.side === p.side ? attackDir * 10 : -attackDir * 4;
    const tx = THREE.MathUtils.clamp(p.baseX + ballPullX + attackPush, -HALF_W + 4, HALF_W - 4);
    const tz = THREE.MathUtils.clamp(p.baseZ + this.ballPos.z * 0.22, -HALF_D + 3, HALF_D - 3);
    const dx = tx - p.x;
    const dz = tz - p.z;
    const d = Math.hypot(dx, dz);
    if (d > 1.2) {
      p.vx = (dx / d) * maxSpd * 0.78;
      p.vz = (dz / d) * maxSpd * 0.78;
      p.facing = Math.atan2(p.vx, p.vz);
    } else {
      p.vx *= 0.8;
      p.vz *= 0.8;
    }
  }

  private updateBallPhysics(dt: number): void {
    // Pick nearest away chaser periodically
    let minAway = Infinity;
    for (const p of this.players) {
      if (p.side !== 'away' || p.isGk) continue;
      const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
      if (d < minAway) {
        minAway = d;
        this.activeAwayIdx = p.idx;
      }
    }

    if (this.carrier) {
      const c = this.carrier;
      this.ballPos.set(c.x + Math.sin(c.facing) * 0.65, BALL_R, c.z + Math.cos(c.facing) * 0.65);
      this.ballVel.set(c.vx, 0, c.vz);

      // Opponent steal check
      for (const opp of this.players) {
        if (opp.side === c.side || opp.isGk) continue;
        if (Math.hypot(opp.x - c.x, opp.z - c.z) < 1.05 && Math.random() < 0.08) {
          this.carrier = opp;
          this.lastTouchSide = opp.side;
          if (opp.side === 'home') this.activeHomeIdx = opp.idx;
          sfx('bounce');
          break;
        }
      }
      return;
    }

    // Free-flight 3D physics
    this.ballVel.y -= 22 * dt;
    this.ballPos.addScaledVector(this.ballVel, dt);

    if (this.ballPos.y <= BALL_R) {
      this.ballPos.y = BALL_R;
      if (Math.abs(this.ballVel.y) > 2.2) {
        this.ballVel.y = -this.ballVel.y * 0.56;
        sfx('bounce');
      } else {
        this.ballVel.y = 0;
      }
      // Grass drag
      this.ballVel.x *= Math.pow(0.24, dt);
      this.ballVel.z *= Math.pow(0.24, dt);
    } else {
      this.ballVel.x *= Math.pow(0.84, dt);
      this.ballVel.z *= Math.pow(0.84, dt);
    }

    // Goal & Post collisions
    for (const dir of [-1, 1]) {
      const gx = dir * HALF_W;
      // Check posts at z = +-GOAL_HALF_W
      for (const pz of [-GOAL_HALF_W, GOAL_HALF_W]) {
        const pd = Math.hypot(this.ballPos.x - gx, this.ballPos.z - pz);
        if (pd < BALL_R + 0.14 && this.ballPos.y < GOAL_H + 0.14) {
          this.ballVel.x = -this.ballVel.x * 0.72;
          this.ballVel.z += (this.ballPos.z - pz) * 4;
          sfx('post');
        }
      }
    }

    // Check Goal Scored
    if (Math.abs(this.ballPos.z) < GOAL_HALF_W - 0.12 && this.ballPos.y < GOAL_H) {
      if (this.ballPos.x > HALF_W + BALL_R * 0.5) {
        this.homeGoals++;
        this.onGoalScored('home');
        return;
      }
      if (this.ballPos.x < -HALF_W - BALL_R * 0.5) {
        this.awayGoals++;
        this.onGoalScored('away');
        return;
      }
    }

    // Touchlines & Endlines restart (smooth quick play)
    if (Math.abs(this.ballPos.z) > HALF_D + 0.8) {
      this.ballPos.z = Math.sign(this.ballPos.z) * (HALF_D - 1);
      this.ballVel.set(this.ballVel.x * 0.3, 0, -Math.sign(this.ballPos.z) * 5);
      sfx('whistle');
    } else if (Math.abs(this.ballPos.x) > HALF_W + 1.2 && Math.abs(this.ballPos.z) >= GOAL_HALF_W) {
      this.ballPos.x = Math.sign(this.ballPos.x) * (HALF_W - 5);
      this.ballPos.z = 0;
      this.ballVel.set(-Math.sign(this.ballPos.x) * 14, 3, (Math.random() - 0.5) * 6);
      sfx('whistle');
    }

    // Player ball pickup
    if (this.ballPos.y < 1.35) {
      for (const p of this.players) {
        if (p.isGk) continue;
        const d = Math.hypot(p.x - this.ballPos.x, p.z - this.ballPos.z);
        if (d < 1.15) {
          this.carrier = p;
          this.lastTouchSide = p.side;
          if (p.side === 'home') this.activeHomeIdx = p.idx;
          break;
        }
      }
    }
  }

  private onGoalScored(scoringSide: 'home' | 'away'): void {
    this.phase = 'goal';
    this.phaseTimer = 2.0;
    this.ballVel.multiplyScalar(0.25);
    if (this.scoreEl) this.scoreEl.textContent = `${this.homeGoals} - ${this.awayGoals}`;
    sfx('goal');
    this.showBanner(`⚽ جووول لصالح ${scoringSide === 'home' ? this.homeTeam.name : this.awayTeam.name}!`, 2100);
    window.setTimeout(() => {
      if (!this.destroyed && this.phase === 'goal') {
        this.resetKickoff(scoringSide === 'home' ? 'away' : 'home');
      }
    }, 1850);
  }

  private updateMeshes(dt: number): void {
    const ctrl = this.getControlledHome();
    if (this.playerLabelEl) this.playerLabelEl.textContent = `${ctrl.info.name} · #${ctrl.info.jerseyNo}`;
    if (this.staminaFillEl) this.staminaFillEl.style.width = `${Math.round(ctrl.stamina)}%`;

    for (const p of this.players) {
      p.group.position.set(p.x, 0, p.z);
      p.group.rotation.y = p.facing;

      const spd = Math.hypot(p.vx, p.vz);
      if (spd > 0.4) {
        p.stridePhase += dt * spd * 1.9;
        const swing = Math.sin(p.stridePhase) * 0.65;
        p.leftLeg.rotation.x = swing;
        p.rightLeg.rotation.x = p.kickAnim > 0 ? -1.1 : -swing;
        p.leftArm.rotation.x = -swing * 0.7;
        p.rightArm.rotation.x = swing * 0.7;
      } else {
        p.leftLeg.rotation.x = 0;
        p.rightLeg.rotation.x = p.kickAnim > 0 ? -1.0 : 0;
        p.leftArm.rotation.x = 0;
        p.rightArm.rotation.x = 0;
      }

      p.group.rotation.z = p.diveTimer > 0 ? p.diveDir * 0.85 : 0;
    }

    this.ballMesh.position.copy(this.ballPos);
    this.ballMesh.rotation.z -= this.ballVel.x * dt * 1.6;
    this.ballMesh.rotation.x += this.ballVel.z * dt * 1.6;
    this.ballShadow.position.set(this.ballPos.x, 0.02, this.ballPos.z);

    this.activeRing.position.set(ctrl.x, 0.03, ctrl.z);
    const mate = this.findBestHomeTeammate(ctrl);
    if (mate && this.carrier?.side === 'home') {
      this.passRing.visible = true;
      this.passRing.position.set(mate.x, 0.025, mate.z);
    } else {
      this.passRing.visible = false;
    }

    // Update Camera smooth damping
    const targetX = this.cameraMode === 'focus' ? ctrl.x : this.ballPos.x * 0.72;
    const targetZ = this.cameraMode === 'focus' ? ctrl.z : this.ballPos.z * 0.55;
    this._tmpDir.set(targetX, 0.9, targetZ);
    this.camTarget.x = THREE.MathUtils.damp(this.camTarget.x, this._tmpDir.x, 5.5, dt);
    this.camTarget.z = THREE.MathUtils.damp(this.camTarget.z, this._tmpDir.z, 5.5, dt);

    let desiredCamX = this.camTarget.x;
    let desiredCamY = 25;
    let desiredCamZ = 38 + this.camTarget.z * 0.4;
    if (this.cameraMode === 'wide') {
      desiredCamY = 38;
      desiredCamZ = 52;
      desiredCamX *= 0.45;
    } else if (this.cameraMode === 'tele') {
      desiredCamY = 44;
      desiredCamZ = 22;
      desiredCamX *= 0.6;
    } else if (this.cameraMode === 'dynamic') {
      desiredCamY = 20 + Math.abs(this.ballPos.x) * 0.08;
      desiredCamZ = 31 + this.camTarget.z * 0.5;
    } else if (this.cameraMode === 'focus') {
      desiredCamX = ctrl.x - 11;
      desiredCamY = 9;
      desiredCamZ = ctrl.z + 15;
    }

    this.camPos.x = THREE.MathUtils.damp(this.camPos.x, desiredCamX, 4.5, dt);
    this.camPos.y = THREE.MathUtils.damp(this.camPos.y, desiredCamY, 4.5, dt);
    this.camPos.z = THREE.MathUtils.damp(this.camPos.z, desiredCamZ, 4.5, dt);

    this.camera.position.copy(this.camPos);
    this.camera.lookAt(this.camTarget);
  }

  private render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  private finishMatch(): void {
    if (this.phase === 'fulltime') return;
    this.phase = 'fulltime';
    sfx('whistle');
    const totalPoss = Math.max(0.1, this.homePossTime + this.awayPossTime);
    const possessionPct = Math.round((this.homePossTime / totalPoss) * 100);
    const summary = {
      homeName: this.homeTeam.name,
      awayName: this.awayTeam.name,
      homeGoals: this.homeGoals,
      awayGoals: this.awayGoals,
      possessionPct,
      shots: this.homeShots,
      shotsOnTarget: this.homeShotsOnTarget,
      passes: this.homePasses,
      difficulty: this.cfg.difficulty,
      durationSec: Math.max(30, Math.round(this.homePossTime + this.awayPossTime)),
    };
    this.onMatchEnd(summary);
  }

  public dispose(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    if (this.timerId !== null) clearTimeout(this.timerId);
    this.disposables.forEach((d) => {
      try {
        d.dispose();
      } catch {
        // ignore
      }
    });
    this.envRenderTarget?.dispose();
    this.pmremGenerator?.dispose();
    this.renderer?.dispose();
    this.container.innerHTML = '';
  }

  private disposeAndExit(): void {
    this.dispose();
    this.onExit();
  }
}

let activeEngine: Football3DEngine | null = null;

function mountFootball3DOverlay(opts?: { homeTeamId?: string; awayTeamId?: string }): void {
  window.closeFeature?.();
  if (activeEngine) {
    activeEngine.dispose();
    activeEngine = null;
  }
  document.getElementById('myaiFootball3dOverlay')?.remove();

  const db = window.MYAI_PLAYERS_DB;
  const teams: TeamInfo[] = db?.TEAMS || [
    { id: 'myai_united', name: 'MY AI يونايتد', nameEn: 'MY AI United', league: 'local', country: 'MY AI', primary: '#ff142e', secondary: '#111111', ovr: 84, formation: '4-3-3' },
    { id: 'real_madrid', name: 'ريال مدريد', nameEn: 'Real Madrid', league: 'la_liga', country: 'إسبانيا', primary: '#f5f5f5', secondary: '#d4af37', ovr: 89, formation: '4-3-3' },
  ];

  const overlay = document.createElement('div');
  overlay.id = 'myaiFootball3dOverlay';
  overlay.className = 'myai-f3d-overlay';
  document.body.appendChild(overlay);
  document.body.style.overflow = 'hidden';

  const homeDefault = opts?.homeTeamId || 'liverpool';
  const awayDefault = opts?.awayTeamId || 'real_madrid';

  const closeAll = () => {
    activeEngine?.dispose();
    activeEngine = null;
    overlay.remove();
    document.body.style.overflow = '';
  };

  overlay.innerHTML = `
    <div class="myai-f3d-lobby">
      <div class="myai-f3d-lobby-head">
        <div>
          <h2>⚽ MY AI FOOTBALL · 3D STADIUM</h2>
          <p>مباراة كرة قدم حقيقية ثلاثية الأبعاد (11 ضد 11) بمحرك Three.js WebGL</p>
        </div>
        <button type="button" class="feature-close" id="f3dLobbyClose">×</button>
      </div>

      <div class="myai-pro-card">
        <div class="myai-pro-grid2">
          <div>
            <label>فريقك (Home)</label>
            <select id="f3dHomeTeam" class="feature-field">
              ${teams.map((t) => `<option value="${escHtml(t.id)}" ${t.id === homeDefault ? 'selected' : ''}>${escHtml(t.name)} (OVR ${t.ovr})</option>`).join('')}
            </select>
          </div>
          <div>
            <label>الخصم (Away)</label>
            <select id="f3dAwayTeam" class="feature-field">
              ${teams.map((t) => `<option value="${escHtml(t.id)}" ${t.id === awayDefault ? 'selected' : ''}>${escHtml(t.name)} (OVR ${t.ovr})</option>`).join('')}
            </select>
          </div>
          <div>
            <label>التشكيلة والرسوم التكتيكية</label>
            <select id="f3dFormation" class="feature-field">
              <option value="4-3-3">4-3-3 هجومية</option>
              <option value="4-4-2">4-4-2 متوازنة</option>
              <option value="3-5-2">3-5-2 سيطرة وسط</option>
            </select>
          </div>
          <div>
            <label>مستوى الذكاء الاصطناعي</label>
            <select id="f3dDifficulty" class="feature-field">
              <option value="سهل">سهل</option>
              <option value="متوسط" selected>متوسط</option>
              <option value="صعب">صعب</option>
              <option value="أسطوري">أسطوري</option>
            </select>
          </div>
          <div>
            <label>مدة الشوط الواحد</label>
            <select id="f3dHalfSec" class="feature-field">
              <option value="60">دقيقة واحدة (سريعة)</option>
              <option value="90" selected>دقيقة ونصف (قياسية)</option>
              <option value="120">دقيقتان</option>
              <option value="180">3 دقائق</option>
            </select>
          </div>
          <div>
            <label>أجواء الملعب والجرافيك</label>
            <select id="f3dLighting" class="feature-field">
              <option value="night" selected>ليلي بأضواء كاشفة ✨</option>
              <option value="day">نهاري مشرق ☀️</option>
            </select>
          </div>
          <div>
            <label>جودة الرسوميات</label>
            <select id="f3dQuality" class="feature-field">
              <option value="low">منخفضة (أسرع للهواتف الضعيفة)</option>
              <option value="medium" selected>متوسطة (متوازنة)</option>
              <option value="high">عالية (ظلال وتفاصيل أعلى)</option>
            </select>
          </div>
          <div>
            <label>تخصيص أزرار اللمس</label>
            <div style="display:flex;gap:6px">
              <select id="f3dHudSize" class="feature-field" style="flex:1">
                <option value="sm">صغيرة</option>
                <option value="md" selected>متوسطة</option>
                <option value="lg">كبيرة</option>
              </select>
              <select id="f3dHudOpacity" class="feature-field" style="flex:1">
                <option value="95">وضوح 95%</option>
                <option value="80" selected>شفافية 80%</option>
                <option value="60">شفافية 60%</option>
              </select>
            </div>
          </div>
        </div>
        <div class="myai-pro-grid2" style="margin-top:8px">
          <button type="button" class="primary" id="f3dStartBtn">⚽ انطلاق المباراة 3D الآن</button>
          <button type="button" class="myai-v3-btn" id="f3dFullscreenBtn">📱 ملء الشاشة (يفضل بالعرض Landscape)</button>
        </div>
      </div>
    </div>
  `;

  document.getElementById('f3dLobbyClose')?.addEventListener('click', closeAll);
  document.getElementById('f3dFullscreenBtn')?.addEventListener('click', () => {
    try {
      overlay.requestFullscreen?.().catch(() => {});
      (screen.orientation as any)?.lock?.('landscape').catch(() => {});
    } catch {
      // ignore orientation lock failure on unsupported browsers
    }
  });

  document.getElementById('f3dStartBtn')?.addEventListener('click', () => {
    const cfg: MatchConfig = {
      homeTeamId: (document.getElementById('f3dHomeTeam') as HTMLSelectElement)?.value || 'liverpool',
      awayTeamId: (document.getElementById('f3dAwayTeam') as HTMLSelectElement)?.value || 'real_madrid',
      formation: ((document.getElementById('f3dFormation') as HTMLSelectElement)?.value as FormationKey) || '4-3-3',
      difficulty: ((document.getElementById('f3dDifficulty') as HTMLSelectElement)?.value as DifficultyKey) || 'متوسط',
      halfSeconds: Number((document.getElementById('f3dHalfSec') as HTMLSelectElement)?.value || 90),
      lighting: ((document.getElementById('f3dLighting') as HTMLSelectElement)?.value as LightingKey) || 'night',
      quality: ((document.getElementById('f3dQuality') as HTMLSelectElement)?.value as QualityKey) || 'medium',
      hudSize: ((document.getElementById('f3dHudSize') as HTMLSelectElement)?.value as 'sm' | 'md' | 'lg') || 'md',
      hudOpacity: Number((document.getElementById('f3dHudOpacity') as HTMLSelectElement)?.value || 80),
    };

    sfx('click');
    activeEngine = new Football3DEngine(
      overlay,
      cfg,
      async (summary) => {
        activeEngine?.dispose();
        activeEngine = null;
        let rewardText = '';
        try {
          if (typeof window.myaiApiFetch === 'function' && navigator.onLine !== false) {
            const res = await window.myaiApiFetch('/api/football3d/complete', {
              method: 'POST',
              body: JSON.stringify({
                homeTeam: summary.homeName,
                awayTeam: summary.awayName,
                homeGoals: summary.homeGoals,
                awayGoals: summary.awayGoals,
                difficulty: summary.difficulty,
                possessionPct: summary.possessionPct,
                shots: summary.shots,
                shotsOnTarget: summary.shotsOnTarget,
                passes: summary.passes,
                durationSec: summary.durationSec,
              }),
            });
            if (res?.rewardAdded > 0) {
              sfx('coin');
              rewardText = `🎁 مكافأة المباراة: +${res.rewardAdded} نقطة!`;
            }
          }
        } catch {
          // offline or rate capped
        }
        const won = summary.homeGoals > summary.awayGoals;
        overlay.innerHTML = `
          <div class="myai-f3d-lobby">
            <div class="myai-pro-card" style="text-align:center">
              <h2>${won ? '🏆 فوز مستحق!' : summary.homeGoals === summary.awayGoals ? '🤝 تعادل مثير!' : '⚽ صافرة النهاية'}</h2>
              <p style="font-size:32px;font-weight:900;margin:10px 0">${escHtml(summary.homeName)} ${summary.homeGoals} - ${summary.awayGoals} ${escHtml(summary.awayName)}</p>
              ${rewardText ? `<p class="myai-badge ok">${rewardText}</p>` : ''}
              <div class="myai-v3-stat" style="margin:12px 0">
                <div><strong>${summary.possessionPct}%</strong>الاستحواذ</div>
                <div><strong>${summary.shots} (${summary.shotsOnTarget})</strong>التسديدات (على المرمى)</div>
                <div><strong>${summary.passes}</strong>التمريرات</div>
                <div><strong>${escHtml(summary.difficulty)}</strong>المستوى</div>
              </div>
              <div class="myai-pro-grid2">
                <button type="button" class="primary" id="f3dRematchBtn">🔁 مباراة جديدة</button>
                <button type="button" class="myai-v3-btn" id="f3dDoneCloseBtn">إغلاق والعودة</button>
              </div>
            </div>
          </div>
        `;
        document.getElementById('f3dRematchBtn')?.addEventListener('click', () => mountFootball3DOverlay({ homeTeamId: cfg.homeTeamId, awayTeamId: cfg.awayTeamId }));
        document.getElementById('f3dDoneCloseBtn')?.addEventListener('click', closeAll);
      },
      closeAll,
    );
  });
}

window.myaiOpenFootball3D = mountFootball3DOverlay;
