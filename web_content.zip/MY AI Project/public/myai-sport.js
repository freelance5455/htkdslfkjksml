/* Sport AI – Ultimate Sports System + AI Coach + AI Tracker */
(function () {
  "use strict";

  const REMINDER_KEY = "myai_sport_reminders_v1";
  let sportDashCache = null;
  let activeCoachPlan = null;
  let activeDrillTimer = null;
  let activeDrillState = null;

  function esc(v) {
    return typeof window.escapeHTML === "function"
      ? window.escapeHTML(String(v ?? ""))
      : String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function say(msg) {
    if (typeof window.notify === "function") window.notify(msg);
  }

  async function api(url, opts) {
    if (typeof window.myaiApiFetch === "function") {
      return window.myaiApiFetch(url, opts);
    }
    const res = await fetch(url, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || "خطأ في الاتصال");
    return data;
  }

  function stopDrillTimer() {
    if (activeDrillTimer) {
      clearInterval(activeDrillTimer);
      activeDrillTimer = null;
    }
  }

  const prevCloseFeature = window.closeFeature;
  window.closeFeature = function () {
    stopDrillTimer();
    if (typeof prevCloseFeature === "function") prevCloseFeature();
  };

  // Animated SVG Tactical Drill Diagrams (6 distinct realistic football pitch drills)
  function getDrillSvgDiagram(visualKey) {
    const key = String(visualKey || "dribble_cones");
    if (key === "wall_pass") {
      return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#0f3e20">
        <rect x="6" y="6" width="308" height="138" rx="8" fill="none" stroke="rgba(255,255,255,0.45)" stroke-width="2"/>
        <line x1="65" y1="110" x2="175" y2="42" stroke="#facc15" stroke-width="2" stroke-dasharray="5 5"/>
        <line x1="175" y1="42" x2="255" y2="106" stroke="#38bdf8" stroke-width="2" stroke-dasharray="5 5"/>
        <circle cx="65" cy="110" r="10" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="175" cy="42" r="10" fill="#38bdf8" stroke="#fff" stroke-width="2"/>
        <circle cx="255" cy="106" r="10" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="65" cy="110" r="5" fill="#fff">
          <animateMotion dur="2.4s" repeatCount="indefinite" path="M0,0 L110,-68 L190,-4 Z"/>
        </circle>
        <text x="160" y="138" text-anchor="middle" fill="#fff" font-size="11">تمرير واستلام 1-2 والحركة في المساحة</text>
      </svg>`;
    }
    if (key === "target_shoot") {
      return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#0f3e20">
        <rect x="95" y="10" width="130" height="32" fill="rgba(255,255,255,0.12)" stroke="#fff" stroke-width="2.5"/>
        <circle cx="114" cy="26" r="8" fill="#ff263f" opacity="0.85"/>
        <circle cx="206" cy="26" r="8" fill="#facc15" opacity="0.85"/>
        <path d="M160 120 Q138 72 114 26" fill="none" stroke="#ff5e73" stroke-width="2" stroke-dasharray="5 4"/>
        <circle cx="160" cy="120" r="10" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="160" cy="120" r="5.5" fill="#fff">
          <animateMotion dur="1.8s" repeatCount="indefinite" path="M0,0 Q-22,-48 -46,-94"/>
        </circle>
        <text x="160" y="142" text-anchor="middle" fill="#fff" font-size="11">توجيه التسديدة نحو الزاوية البعيدة</text>
      </svg>`;
    }
    if (key === "rondo_circle") {
      return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#0f3e20">
        <circle cx="160" cy="72" r="46" fill="none" stroke="rgba(255,255,255,0.4)" stroke-dasharray="4 4" stroke-width="2"/>
        <circle cx="160" cy="26" r="9" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="206" cy="72" r="9" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="160" cy="118" r="9" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="114" cy="72" r="9" fill="#ff263f" stroke="#fff" stroke-width="2"/>
        <circle cx="160" cy="72" r="9" fill="#38bdf8" stroke="#fff" stroke-width="2"/>
        <circle cx="160" cy="26" r="5" fill="#fff">
          <animateMotion dur="2.6s" repeatCount="indefinite" path="M0,0 L46,46 L0,92 L-46,46 Z"/>
        </circle>
        <text x="160" y="142" text-anchor="middle" fill="#fff" font-size="11">روندو الاستحواذ والتفكير السريع</text>
      </svg>`;
    }
    if (key === "sprint_shuttle") {
      return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#0f3e20">
        <line x1="40" y1="75" x2="280" y2="75" stroke="#facc15" stroke-width="2.5" stroke-dasharray="6 4"/>
        <polygon points="40,62 32,84 48,84" fill="#ff6e40"/>
        <polygon points="160,62 152,84 168,84" fill="#ff6e40"/>
        <polygon points="280,62 272,84 288,84" fill="#ff6e40"/>
        <circle cx="40" cy="75" r="10" fill="#ff263f" stroke="#fff" stroke-width="2">
          <animateMotion dur="2.2s" repeatCount="indefinite" path="M0,0 L240,0 L0,0"/>
        </circle>
        <text x="160" y="138" text-anchor="middle" fill="#fff" font-size="11">سباق السرعة والتغيير السريع للاتجاه</text>
      </svg>`;
    }
    if (key === "recovery_stretch") {
      return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#102935">
        <circle cx="160" cy="72" r="24" fill="rgba(46,204,113,0.22)" stroke="#2ecc71" stroke-width="2">
          <animate attributeName="r" values="20;42;20" dur="3.6s" repeatCount="indefinite"/>
        </circle>
        <text x="160" y="76" text-anchor="middle" fill="#baf7cf" font-size="12" font-weight="bold">تنفس واستشفاء</text>
        <text x="160" y="136" text-anchor="middle" fill="#fff" font-size="11">إطالات هادئة وتنفس عميق لاستعادة اللياقة</text>
      </svg>`;
    }
    return `<svg viewBox="0 0 320 150" style="width:100%;max-width:340px;display:block;margin:8px auto;border-radius:12px;border:1px solid rgba(255,65,88,0.4);background:#0f3e20">
      <polygon points="90,72 83,86 97,86" fill="#ff6e40"/>
      <polygon points="155,72 148,86 162,86" fill="#ff6e40"/>
      <polygon points="220,72 213,86 227,86" fill="#ff6e40"/>
      <path d="M40 76 Q65 44 90 76 T155 76 T220 76 T280 76" fill="none" stroke="#facc15" stroke-width="2" stroke-dasharray="4 4"/>
      <circle cx="40" cy="76" r="9" fill="#ff263f" stroke="#fff" stroke-width="2">
        <animateMotion dur="2.5s" repeatCount="indefinite" path="M0,0 Q25,-32 50,0 T115,0 T180,0 T240,0"/>
      </circle>
      <text x="160" y="138" text-anchor="middle" fill="#fff" font-size="11">مراوغة وتحكم بالكرة بين الأقماع</text>
    </svg>`;
  }

  async function loadDashboard() {
    try {
      const data = await api("/api/sport/dashboard", { method: "GET" });
      const dash = data?.dashboard || data;
      sportDashCache = dash;
      if (dash?.plan && !activeCoachPlan) activeCoachPlan = dash.plan;
      return dash;
    } catch (_) {
      return sportDashCache;
    }
  }

  // Override showSportMenu with the upgraded Ultimate Sport AI Hub (preserving existing tools!)
  window.showSportMenu = async function () {
    stopDrillTimer();
    const dash = await loadDashboard();
    const p = dash?.profile || { position: "مهاجم", level: "متوسط" };
    const summary = dash?.summary || {};
    const adherence = summary.adherencePct ?? 0;

    window.openFeature(
      "Sport AI · المدرب والمتابع الذكي",
      "نظام تدريب ذكي متكامل مع خطط حسب مركزك، متابعة التطور، وقاعدة بيانات اللاعبين.",
      `<div class="myai-pro-card" style="padding:11px">
        <div class="myai-pro-row">
          <div><b>مركزك:</b> <span class="myai-badge">${esc(p.position)}</span> · <span class="myai-badge">${esc(p.level)}</span></div>
          <div><span class="myai-badge ok">التمارين: ${summary.totalWorkouts || 0}</span> <span class="myai-badge">التزام: ${adherence}%</span></div>
        </div>
      </div>
      <div class="myai-v3-grid">
        <button class="myai-v3-tile" onclick="myaiOpenSportCoach()"><span style="font-size:25px">🧠</span><b>المدرب الذكي (Coach)</b><small>برنامج أسبوعي + تمارين مرسومة ومؤقت</small></button>
        <button class="myai-v3-tile" onclick="myaiOpenSportTracker()"><span style="font-size:25px">📈</span><b>المتابع الذكي (Tracker)</b><small>تقدم المهارات، الأهداف والتقارير</small></button>
        <button class="myai-v3-tile" onclick="myaiOpenPlayersDatabase()"><span style="font-size:25px">🌍</span><b>قاعدة بيانات اللاعبين</b><small>الأندية والمنتخبات والطاقات</small></button>
        <button class="myai-v3-tile" onclick="sportCompare()"><span style="font-size:25px">⚖️</span><b>مقارنة لاعبين</b><small>تحليل ومقارنة مباشرة بـ Gemini</small></button>
        <button class="myai-v3-tile" onclick="sportQuiz()"><span style="font-size:25px">⚽</span><b>أسئلة كروية ذكية</b><small>تحدي معلومات بالذكاء الاصطناعي</small></button>
        <button class="myai-v3-tile" onclick="showAssistantChat('Sport AI')"><span style="font-size:25px">💬</span><b>محادثة Sport AI</b><small>اسأل مدربك الشخصي في أي وقت</small></button>
      </div>
      <div id="sportArea"></div>`,
    );
  };

  window.myaiOpenSportCoach = async function () {
    stopDrillTimer();
    const dash = await loadDashboard();
    const p = dash?.profile || {
      position: "مهاجم",
      age: 18,
      level: "متوسط",
      weeklyDays: 4,
      goal: "تطوير الإنهاء والسرعة والتحكم",
    };

    const positions = ["حارس مرمى", "قلب دفاع", "ظهير أيمن", "ظهير أيسر", "وسط دفاعي", "وسط", "صانع ألعاب", "جناح", "مهاجم"];
    const levels = ["مبتدئ", "متوسط", "متقدم", "محترف"];

    window.openFeature(
      "🧠 المدرب الذكي · Sport AI Coach",
      "أنشئ برنامجًا تدريبيًا متكاملًا مخصصًا لمركزك وعمرك وهدفك، ونفّذ التمارين بالمؤقت لكسب الخبرة والنقاط.",
      `<div class="myai-pro-card">
        <h3>⚙️ ملف اللاعب التدريبي</h3>
        <div class="myai-pro-grid2">
          <div>
            <label>المركز في الملعب</label>
            <select id="scPos" class="feature-field">${positions.map((x) => `<option ${p.position === x ? "selected" : ""}>${x}</option>`).join("")}</select>
          </div>
          <div>
            <label>المستوى الحالي</label>
            <select id="scLevel" class="feature-field">${levels.map((x) => `<option ${p.level === x ? "selected" : ""}>${x}</option>`).join("")}</select>
          </div>
          <div>
            <label>العمر</label>
            <input id="scAge" type="number" min="8" max="60" class="feature-field" value="${Number(p.age || 18)}">
          </div>
          <div>
            <label>أيام التدريب بالأسبوع</label>
            <select id="scDays" class="feature-field">${[2, 3, 4, 5, 6].map((d) => `<option value="${d}" ${Number(p.weeklyDays || 4) === d ? "selected" : ""}>${d} أيام</option>`).join("")}</select>
          </div>
        </div>
        <label>هدفك الأساسي هذا الشهر</label>
        <input id="scGoal" class="feature-field" value="${esc(p.goal || "")}" placeholder="مثال: زيادة قوة التسديد والسرعة في المساحات الضيقة">
        <div class="myai-pro-grid2">
          <button type="button" class="primary" id="scGenBtn" onclick="myaiGenerateCoachPlan()">⚡ إنشاء / تحديث خطة الأسبوع بـ Gemini</button>
          <button type="button" class="myai-v3-btn" onclick="showSportMenu()">⬅️ العودة لـ Sport AI</button>
        </div>
      </div>
      <div id="scPlanContainer">${activeCoachPlan ? renderCoachPlanHTML(activeCoachPlan) : "<div class='myai-pro-card'><p class='myai-v3-muted'>اضغط على «إنشاء خطة الأسبوع بـ Gemini» لتوليد برنامج مخصص يشمل التمارين وأيام الراحة والاستشفاء.</p></div>"}</div>
      <div id="scDrillStage"></div>`,
    );
  };

  function renderCoachPlanHTML(plan) {
    const days = Array.isArray(plan?.days) ? plan.days : [];
    if (!days.length) return "";
    return `
      <div class="myai-pro-card">
        <h3>📅 برنامجك الأسبوعي (${esc(plan.adaptedForPosition || "")} · ${esc(plan.adaptedForLevel || "")})</h3>
        <p>${esc(plan.coachSummary || "")}</p>
        ${plan.nextStepAdvice ? `<p class="myai-v3-muted">💡 <b>الخطوة التالية:</b> ${esc(plan.nextStepAdvice)}</p>` : ""}
        <div style="display:grid;gap:9px;margin-top:10px">
          ${days
            .map((d, dayIdx) => {
              const drills = Array.isArray(d.drills) ? d.drills : [];
              return `<div class="myai-list-item">
                <div class="myai-pro-row">
                  <div><b>${esc(d.dayName || `اليوم ${dayIdx + 1}`)}</b> · ${esc(d.focus || "")}</div>
                  <span class="myai-badge ${d.isRest ? "ok" : ""}">${d.isRest ? "راحة واستشفاء 🛌" : `${drills.length} تمارين`}</span>
                </div>
                <div style="display:grid;gap:7px;margin-top:8px">
                  ${drills
                    .map(
                      (dr, drillIdx) => `<div style="padding:8px;border-radius:10px;background:rgba(255,255,255,0.03);border:1px solid rgba(255,65,88,0.2)">
                        <div class="myai-pro-row">
                          <b>${esc(dr.title)}</b>
                          <span class="myai-badge">${esc(dr.skill || "fitness")} · ${Number(dr.durationMin || 10)} د</span>
                        </div>
                        ${dr.setsReps ? `<small class="myai-v3-muted">التكرارات: ${esc(dr.setsReps)}</small>` : ""}
                        <p class="myai-v3-muted" style="margin:4px 0 6px">${esc(dr.steps || "")}</p>
                        <button type="button" class="myai-mini-btn primary-mini" onclick="myaiStartDrillSession(${dayIdx}, ${drillIdx})">▶ ابدأ التمرين مع الرسم والمؤقت</button>
                      </div>`,
                    )
                    .join("")}
                </div>
              </div>`;
            })
            .join("")}
        </div>
      </div>
    `;
  }

  window.myaiGenerateCoachPlan = async function () {
    const position = document.getElementById("scPos")?.value || "مهاجم";
    const level = document.getElementById("scLevel")?.value || "متوسط";
    const age = Number(document.getElementById("scAge")?.value || 18);
    const weeklyDays = Number(document.getElementById("scDays")?.value || 4);
    const goal = (document.getElementById("scGoal")?.value || "").trim() || "تطوير المهارات الأساسية";
    const btn = document.getElementById("scGenBtn");
    const box = document.getElementById("scPlanContainer");
    if (btn) btn.disabled = true;
    if (box) box.innerHTML = `<div class="myai-pro-card"><p class="myai-v3-muted">⏳ مدرب Gemini الذكي يصمم خطة الأسبوع وتمرينات كل مركز مع أيام الاستشفاء...</p></div>`;
    try {
      const data = await api("/api/sport/coach-plan", {
        method: "POST",
        timeoutMs: 60000,
        body: JSON.stringify({ position, age, level, weeklyDays, goal }),
      });
      activeCoachPlan = data.plan;
      if (data.dashboard) sportDashCache = data.dashboard;
      if (box) box.innerHTML = renderCoachPlanHTML(activeCoachPlan);
      window.MYAISound?.correct?.();
    } catch (err) {
      if (box) box.innerHTML = `<div class="myai-pro-card">⚠️ ${esc(err.message)}</div>`;
    } finally {
      if (btn) btn.disabled = false;
    }
  };

  window.myaiStartDrillSession = function (dayIdx, drillIdx = 0) {
    stopDrillTimer();
    const day = activeCoachPlan?.days?.[dayIdx];
    const drill = day?.drills?.[drillIdx];
    const stage = document.getElementById("scDrillStage");
    if (!day || !drill || !stage) return;
    const targetSec = Math.max(30, Math.min(1800, Number(drill.durationMin || 5) * 60));
    activeDrillState = {
      day,
      drill,
      targetSec,
      elapsedSec: 0,
      running: true,
    };

    const renderStage = () => {
      const rem = Math.max(0, activeDrillState.targetSec - activeDrillState.elapsedSec);
      const mins = String(Math.floor(rem / 60)).padStart(2, "0");
      const secs = String(rem % 60).padStart(2, "0");
      const canClaim = activeDrillState.elapsedSec >= 15;
      stage.innerHTML = `
        <div class="myai-pro-card" style="border-color:#ff3349">
          <div class="myai-pro-row">
            <h3>🏃 تمرين نشط: ${esc(drill.title)}</h3>
            <span class="myai-badge ${activeDrillState.running ? "ok" : "warn"}">${activeDrillState.running ? "يعمل الآن" : "متوقف مؤقتًا"}</span>
          </div>
          ${getDrillSvgDiagram(drill.diagramType)}
          <p class="myai-v3-muted">${esc(drill.steps || "")}</p>
          <div style="text-align:center;margin:10px 0">
            <div id="scDrillClock" style="font-size:34px;font-weight:900;font-variant-numeric:tabular-nums">${mins}:${secs}</div>
            <small id="scDrillElapsedNote" class="myai-v3-muted">الوقت الفعلي المنقضي: ${activeDrillState.elapsedSec} ثانية (يلزم 15 ثانية على الأقل لتوثيق التمرين)</small>
          </div>
          <div class="myai-pro-grid2">
            <button type="button" class="myai-v3-btn" onclick="myaiToggleDrillPause(this)">${activeDrillState.running ? "⏸ إيقاف مؤقت" : "▶ استئناف"}</button>
            <button type="button" class="primary" id="scDrillCompleteBtn" ${canClaim ? "" : "disabled"} onclick="myaiCompleteActiveDrill()">✅ إنهاء وتوثيق التمرين (+XP و +نقاط)</button>
          </div>
        </div>
      `;
    };

    renderStage();
    stage.scrollIntoView({ behavior: "smooth", block: "nearest" });

    activeDrillTimer = setInterval(() => {
      if (!activeDrillState || !activeDrillState.running) return;
      activeDrillState.elapsedSec += 1;
      const clock = document.getElementById("scDrillClock");
      const note = document.getElementById("scDrillElapsedNote");
      const btn = document.getElementById("scDrillCompleteBtn");
      if (!clock) {
        stopDrillTimer();
        return;
      }
      const rem = Math.max(0, activeDrillState.targetSec - activeDrillState.elapsedSec);
      clock.textContent = `${String(Math.floor(rem / 60)).padStart(2, "0")}:${String(rem % 60).padStart(2, "0")}`;
      if (note) {
        note.textContent = `الوقت الفعلي المنقضي: ${activeDrillState.elapsedSec} ثانية (يلزم 15 ثانية على الأقل لتوثيق التمرين)`;
      }
      if (btn && activeDrillState.elapsedSec >= 15) {
        btn.disabled = false;
      }
    }, 1000);
  };

  window.myaiToggleDrillPause = function (btnEl) {
    if (!activeDrillState) return;
    activeDrillState.running = !activeDrillState.running;
    const btn = btnEl && btnEl.nodeType === 1 ? btnEl : null;
    if (btn) btn.textContent = activeDrillState.running ? "⏸ إيقاف مؤقت" : "▶ استئناف";
  };

  window.myaiCompleteActiveDrill = async function () {
    if (!activeDrillState) return;
    if (activeDrillState.elapsedSec < 15) {
      say("نفّذ التمرين لـ 15 ثانية على الأقل قبل التسجيل");
      return;
    }
    const btn = document.getElementById("scDrillCompleteBtn");
    if (btn) btn.disabled = true;
    try {
      const dr = activeDrillState.drill;
      const res = await api("/api/sport/drill/complete", {
        method: "POST",
        body: JSON.stringify({
          title: dr.title,
          drillType: activeDrillState.day.focus || "مهارات",
          targetSkill: dr.skill || "fitness",
          durationMin: Math.max(1, Math.round(activeDrillState.elapsedSec / 60) || Number(dr.durationMin || 10)),
          elapsedSec: activeDrillState.elapsedSec,
        }),
      });
      stopDrillTimer();
      const added = Number(res.rewardAdded || 0);
      window.MYAISound?.coin?.();
      say(`🏅 ممتاز! تم تسجيل التمرين (+${added} نقطة وتطوير لمهارتك!)`);
      const stage = document.getElementById("scDrillStage");
      if (stage) {
        stage.innerHTML = `<div class="myai-pro-card"><span class="myai-badge ok">تم توثيق التمرين بنجاح ✓</span><p style="margin:8px 0 0">تم تحديث مستوى مهارتك وإضافة +${added} نقطة إلى حسابك.</p></div>`;
      }
      await loadDashboard();
    } catch (err) {
      say(err.message);
      if (btn) btn.disabled = false;
    }
  };

  // 2) Smart AI Tracker UI
  window.myaiOpenSportTracker = async function () {
    stopDrillTimer();
    const dash = await loadDashboard();
    const p = dash?.profile || {};
    const skills = dash?.skills || {};
    const summary = dash?.summary || {};
    const workouts = dash?.workouts || [];
    const goals = dash?.goals || [];
    const remindersOn = localStorage.getItem(REMINDER_KEY) === "1";

    const skillNames = [
      ["dribbling", "المراوغة"],
      ["passing", "التمرير"],
      ["shooting", "التسديد"],
      ["control", "التحكم واللمسة"],
      ["positioning", "التمركز"],
      ["fitness", "اللياقة البدنية"],
    ];

    window.openFeature(
      "📈 المتابع الذكي · Sport AI Tracker",
      "مراقبة شاملة لتدريباتك، نسبة التزامك، تطور مهاراتك، وتقارير Gemini الدورية.",
      `
      <div class="myai-pro-card">
        <div class="myai-v3-stat">
          <div><strong>${summary.adherencePct || 0}%</strong>الالتزام الأسبوعي (${summary.workoutsThisWeek || 0}/${p.weeklyDays || 4})</div>
          <div><strong>${summary.totalWorkouts || 0}</strong>إجمالي التمارين · ${summary.totalMinutes || 0} د</div>
          <div><strong>${summary.workoutsThisMonth || 0}</strong>تمارين آخر 30 يومًا</div>
          <div><strong>⭐ ${esc(summary.strongestSkill || "fitness")}</strong>أقوى مهارة حالية</div>
        </div>
        <div class="myai-pro-row" style="margin-top:10px">
          <button type="button" class="myai-mini-btn" onclick="myaiToggleSportReminder()">${remindersOn ? "🔔 التذكير الاختياري مفعّل" : "🔕 تفعيل تذكير التدريب"}</button>
          <button type="button" class="myai-mini-btn" onclick="showSportMenu()">⬅️ العودة لـ Sport AI</button>
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>📊 تطور المهارات (من 100)</h3>
        ${skillNames
          .map(([k, lbl]) => {
            const val = Math.max(0, Math.min(100, Number(skills[k] || 50)));
            return `<div style="margin:8px 0">
              <div class="myai-pro-row" style="font-size:12px"><b>${lbl}</b><span>${val} / 100</span></div>
              <div style="height:8px;border-radius:99px;background:#1a0d11;overflow:hidden;margin-top:4px;border:1px solid rgba(255,65,88,0.25)">
                <div style="width:${val}%;height:100%;background:linear-gradient(90deg,#ff3349,#facc15)"></div>
              </div>
            </div>`;
          })
          .join("")}
      </div>

      <div class="myai-pro-card">
        <h3>🎯 أهدافي التدريبية</h3>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:8px">
          <input id="stGoalTitle" class="feature-field" style="flex:1;min-width:160px;margin:0" placeholder="هدف جديد (مثال: 50 تسديدة دقيقة)">
          <input id="stGoalTarget" type="number" min="1" max="1000" value="10" class="feature-field" style="width:78px;margin:0">
          <button type="button" class="primary" onclick="myaiCreateSportGoal()">إضافة</button>
        </div>
        <div class="myai-table-list">
          ${
            goals
              .map((g) => {
                const cur = Number(g.current_value ?? g.current_val ?? 0);
                const tgt = Math.max(1, Number(g.target_value ?? g.target_val ?? 1));
                const pct = Math.min(100, Math.round((cur / tgt) * 100));
                return `<div class="myai-list-item">
                  <div class="myai-pro-row">
                    <b>${esc(g.title)}</b>
                    <span class="myai-badge ${g.completed ? "ok" : ""}">${cur}/${tgt} (${pct}%)</span>
                  </div>
                  ${!g.completed ? `<button type="button" class="myai-mini-btn" style="margin-top:6px" onclick="myaiAdvanceGoal('${esc(g.id)}')">+1 تقدم</button>` : ""}
                </div>`;
              })
              .join("") || `<p class="myai-v3-muted">أضف هدفك الأول لمتابعة التزامك.</p>`
          }
        </div>
      </div>

      <div class="myai-pro-card">
        <h3>🤖 تقرير المتابع الذكي (تشخيص Gemini)</h3>
        <div style="display:flex;gap:7px;flex-wrap:wrap">
          <button type="button" class="primary" onclick="myaiGenerateTrackerReport('يومي')">تقرير يومي</button>
          <button type="button" class="myai-v3-btn" onclick="myaiGenerateTrackerReport('أسبوعي')">تقرير أسبوعي</button>
          <button type="button" class="myai-v3-btn" onclick="myaiGenerateTrackerReport('شهري')">تقرير شهري</button>
        </div>
        <div id="stReportOut" style="margin-top:10px"></div>
      </div>

      <div class="myai-pro-card">
        <h3>📜 سجل التمارين المسجلة</h3>
        <div class="myai-table-list">
          ${
            workouts
              .map(
                (w) => `<div class="myai-list-item myai-pro-row">
                  <span>✅ ${esc(w.title || w.drill_title || "تمرين")} (${esc(w.target_skill || w.focus_skill || "fitness")})</span>
                  <small class="myai-v3-muted">${w.duration_min} د · ${new Date(w.completed_at || w.created_at || Date.now()).toLocaleDateString("ar-EG")}</small>
                </div>`,
              )
              .join("") || `<p class="myai-v3-muted">لم تسجل تمارين بعد. افتح «المدرب الذكي» وابدأ أول تمرين.</p>`
          }
        </div>
      </div>
      `,
    );
  };

  window.myaiCreateSportGoal = async function () {
    const title = (document.getElementById("stGoalTitle")?.value || "").trim();
    const targetValue = Number(document.getElementById("stGoalTarget")?.value || 10);
    if (!title) {
      say("اكتب اسم الهدف أولًا");
      return;
    }
    try {
      await api("/api/sport/goal", {
        method: "POST",
        body: JSON.stringify({ title, targetValue }),
      });
      say("تمت إضافة الهدف");
      window.myaiOpenSportTracker();
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiAdvanceGoal = async function (goalId) {
    try {
      const res = await api(`/api/sport/goal/${encodeURIComponent(goalId)}/progress`, {
        method: "POST",
        body: JSON.stringify({ delta: 1 }),
      });
      if (res.justCompleted) {
        window.MYAISound?.fanfare?.();
        say("🏆 أتممت هدفك التدريبي بنجاح!");
      }
      window.myaiOpenSportTracker();
    } catch (err) {
      say(err.message);
    }
  };

  window.myaiGenerateTrackerReport = async function (period) {
    const out = document.getElementById("stReportOut");
    if (out) out.innerHTML = `<p class="myai-v3-muted">⏳ Gemini يحلل مستواك وأرقامك لإصدار التقرير...</p>`;
    try {
      const data = await api("/api/sport/tracker-report", {
        method: "POST",
        timeoutMs: 55000,
        body: JSON.stringify({ period }),
      });
      if (out) {
        out.innerHTML = `<div class="feature-result"><p style="white-space:pre-wrap;margin:0">${esc(data.report || "")}</p></div>`;
      }
    } catch (err) {
      if (out) out.innerHTML = `<p class="myai-v3-muted">⚠️ ${esc(err.message)}</p>`;
    }
  };

  window.myaiToggleSportReminder = async function () {
    const cur = localStorage.getItem(REMINDER_KEY) === "1";
    const next = !cur;
    if (next && "Notification" in window && Notification.permission === "default") {
      try {
        await Notification.requestPermission();
      } catch (_) {}
    }
    localStorage.setItem(REMINDER_KEY, next ? "1" : "0");
    say(next ? "🔔 تم تفعيل التذكير الاختياري للتمرين" : "تم إيقاف التذكير");
    window.myaiOpenSportTracker();
  };
})();
