JAY FX TRADING PLAN & EARNING APP

TO OPEN: unzip folder and open index.html in a modern browser.
For installable PWA/offline caching, host this folder on an HTTPS website then open it in Chrome and choose Install app / Add to Home screen.

Included: Swahili Forex lessons, chart diagrams, fundamental analysis, risk calculator, consistency calculator, trading journal (local browser storage), prop firm payout planner, and the three user-supplied images.

This ZIP is not an Android APK. It is a web app/PWA package. No live market data, live signals, broker connection, or guaranteed earnings.
