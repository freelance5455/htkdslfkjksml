package com.tripulacaoia.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView gameWebView;
    public class AndroidAppBridge {
        @JavascriptInterface public void exitApp() { runOnUiThread(() -> finish()); }
    }
    @Override public void onBackPressed() {
        if (gameWebView != null) {
            gameWebView.evaluateJavascript("(function(){if(window.handleAndroidBack&&window.handleAndroidBack())return; if(window.confirm('Sair do Tripulação IA?')){if(window.AndroidApp)window.AndroidApp.exitApp();}})()", null);
        } else { super.onBackPressed(); }
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView web = new WebView(this);
        gameWebView = web;
        web.addJavascriptInterface(new AndroidAppBridge(), "AndroidApp");
        web.setBackgroundColor(0xFF07101A);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
}
