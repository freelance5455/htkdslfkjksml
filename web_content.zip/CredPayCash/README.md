# CredPayCash — Android APK project

This is a self-contained mobile-first HTML application with an `index.html` file. It calculates withdrawal and bill-payment charges, records transactions, stores data in browser/device local storage, and exports transaction statements as CSV.

## Requirements
- Node.js 20 or newer
- Android Studio (with Android SDK installed)
- Java JDK version supported by your installed Android Studio/Gradle

## Build the Android APK
Open a terminal in this project folder:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio opens the native project. Wait for Gradle sync to finish, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio will show the output location, commonly `android/app/build/outputs/apk/debug/app-debug.apk`.

For subsequent HTML changes, run:

```bash
npm run build
npx cap sync android
```

Then rebuild the APK in Android Studio.

## Run as a web app
```bash
npm install
npm run start
```
Open the local address printed by Vite.

## Financial calculation rules
- Withdrawal payout = amount − platform charge − bank transaction fee.
- Withdrawal profit = platform commission + bank transaction fee.
- Bill-payment profit = customer service charge + platform commission.
- The platform charge for bill payment is displayed separately and is not counted as profit.
- Dashboard profit totals use successful transactions; the statement includes every status.
- Failed transactions require a reason.

## Data storage warning
Records are stored in local storage on the current browser/app installation. Clearing app data or uninstalling the app may remove records. Export the CSV regularly for backup. This project does not connect to a bank, card processor, or payment platform; it is a calculator and record keeper only.

## Included files
- `index.html`: standalone HTML file at project root, per request
- `www/index.html`: web asset copied into the Android build
- `package.json`: npm scripts and dependencies
- `capacitor.config.json`: Android wrapper configuration
