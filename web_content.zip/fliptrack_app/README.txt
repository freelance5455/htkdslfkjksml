LEVELUP — OBJECTIF PC (version 2)

Suivi de ton objectif (6 417,50 € par défaut) avec la méthode d'achat-revente locale en espèces.

Nouveautés par rapport à la version 1 :
- Temps estimé : "rythme réel" (calculé sur tes 4 dernières semaines, après 2 semaines d'activité) et "scénario" réglable (gain % + plafond € par semaine).
- Capital total = cash + stock (au prix d'achat). Un achat ne fait plus baisser ton capital, seule la vente compte.
- Flips : date de vente, prix visé, alertes (plus d'un tiers du capital, stock de plus de 7 jours), bouton Vendre, marge et délai moyens.
- Revenus récurrents (ex. 20 € par mois), paliers modifiables, date visée avec le gain hebdomadaire nécessaire.
- Compteur des seuils des impôts (30 ventes / 2 000 € par an).
- Graphique avec légende, infobulle et tableau.
- Plus de boîtes de dialogue bloquantes : confirmation en deux clics.
- Sauvegarde : copier/coller du texte, ou export/import de fichier.

Lancement : ouvre index.html dans un navigateur. Pour l'installer comme application (PWA), héberge le dossier en HTTPS puis "Installer l'application".
Les données restent dans le localStorage de l'appareil : copie une sauvegarde de temps en temps.
APK : non compilé ici (il faut Android Studio et Capacitor).
