LEVELUP — OBJECTIF PC

Version prototype web mobile, utilisable hors ligne après premier chargement.

Fonctionnalités :
- Objectif par défaut : 6 417,50 €
- Suivi capital, progression et graphique
- Ajout, modification et suppression de flips (achat, frais, revente, statut)
- Suivi des revenus et dépenses
- Historique récent
- Sauvegarde locale, export/import JSON
- Interface mobile sombre, navigation Accueil / Flips / Argent / Réglages

Lancement rapide : ouvrez index.html dans un navigateur moderne.
Pour le mode installable PWA, hébergez le dossier en HTTPS puis utilisez « Installer l'application » dans le navigateur. Le service worker nécessite localhost ou HTTPS.

APK : cette livraison est le code source de l'application, pas encore un APK compilé. Pour produire un APK natif, envelopper le dossier avec Capacitor dans un environnement Android Studio / Android SDK, puis compiler un APK debug ou signé. Les outils Android ne sont pas disponibles dans l'environnement de génération actuel.

Données : stockées dans localStorage du navigateur. Exportez régulièrement une sauvegarde JSON. Ce prototype ne synchronise pas les données entre appareils.
