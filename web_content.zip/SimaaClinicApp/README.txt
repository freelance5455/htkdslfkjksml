طريقة بناء ملف APK:
1) ثبّت Android Studio (مجاناً من developer.android.com/studio) وافتح به المجلد SimaaClinicApp.
2) انتظر اكتمال Sync (يحتاج إنترنت مرة واحدة لتحميل الأدوات).
3) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
4) سيظهر إشعار Locate، وستجد الملف في: app/build/outputs/apk/debug/app-debug.apk
5) انقل الملف إلى الهاتف وثبّته (فعّل "التثبيت من مصادر غير معروفة" إذا طُلب).
بعد التثبيت يعمل التطبيق بدون إنترنت. خذ نسخة احتياطية دورية من تبويب "نسخ احتياطي".
