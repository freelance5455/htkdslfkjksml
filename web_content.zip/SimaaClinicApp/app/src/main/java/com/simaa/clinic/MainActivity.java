package com.simaa.clinic;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView wv; ValueCallback<Uri[]> cb; Uri camUri;

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    wv = new WebView(this);
    setContentView(wv);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    wv.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
    });
    wv.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> c, FileChooserParams p) {
        if (cb != null) cb.onReceiveValue(null);
        cb = c; camUri = null;
        String[] t = p.getAcceptTypes();
        String type = (t.length > 0 && t[0] != null && t[0].contains("/")) ? t[0] : "*/*";
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType(type);
        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
        Intent chooser = Intent.createChooser(pick, "اختر");
        if (type.startsWith("image")) {
          try {
            File d = new File(getCacheDir(), "imgs"); d.mkdirs();
            File f = File.createTempFile("rx", ".jpg", d);
            camUri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fp", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, camUri);
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cam});
          } catch (Exception e) { camUri = null; }
        }
        startActivityForResult(chooser, 1);
        return true;
      }
    });
    wv.addJavascriptInterface(new Object() {
      @JavascriptInterface public void save(String name, String data) {
        try {
          ContentValues v = new ContentValues();
          v.put(MediaStore.Downloads.DISPLAY_NAME, name);
          v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
          Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
          OutputStream o = getContentResolver().openOutputStream(u);
          o.write(data.getBytes("UTF-8")); o.close();
          toast("تم حفظ النسخة الاحتياطية في مجلد التنزيلات");
        } catch (Exception e) { toast("تعذر حفظ الملف"); }
      }
    }, "Android");
    wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

  @Override protected void onActivityResult(int rc, int res, Intent data) {
    super.onActivityResult(rc, res, data);
    if (rc != 1 || cb == null) return;
    Uri[] r = null;
    if (res == RESULT_OK) {
      if (data != null && data.getClipData() != null) {
        ClipData c = data.getClipData(); r = new Uri[c.getItemCount()];
        for (int i = 0; i < r.length; i++) r[i] = c.getItemAt(i).getUri();
      } else if (data != null && data.getData() != null) r = new Uri[]{data.getData()};
      else if (camUri != null) r = new Uri[]{camUri};
    }
    cb.onReceiveValue(r); cb = null;
  }

  @Override public void onBackPressed() { if (wv.canGoBack()) wv.goBack(); else super.onBackPressed(); }
}
