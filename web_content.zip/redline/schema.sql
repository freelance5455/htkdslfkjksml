CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE,name TEXT,role TEXT,salt TEXT,hash TEXT,verified INTEGER DEFAULT 0,otp TEXT,otp_exp INTEGER,otp_try INTEGER DEFAULT 0,created INTEGER,group_id TEXT,plan TEXT DEFAULT 'free');
CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY,owner_id TEXT,invite TEXT UNIQUE,plan TEXT DEFAULT 'free',created INTEGER);
CREATE TABLE IF NOT EXISTS fills(id TEXT PRIMARY KEY,user_id TEXT,liters REAL,amount REAL,fuel TEXT,station TEXT,date TEXT,payment TEXT,created INTEGER);
CREATE INDEX IF NOT EXISTS f_u ON fills(user_id);
CREATE INDEX IF NOT EXISTS u_g ON users(group_id);
CREATE TABLE IF NOT EXISTS push(endpoint TEXT PRIMARY KEY,user_id TEXT);
CREATE TABLE IF NOT EXISTS news(id TEXT PRIMARY KEY,group_id TEXT,title TEXT,body TEXT,created INTEGER);
CREATE TABLE IF NOT EXISTS prices(group_id TEXT,station TEXT,fuel TEXT,price REAL,updated INTEGER,PRIMARY KEY(group_id,station,fuel));
CREATE TABLE IF NOT EXISTS access_codes(code TEXT PRIMARY KEY,kind TEXT,plan TEXT,used_by TEXT,used_at INTEGER);
