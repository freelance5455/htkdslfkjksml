-- УВАГА: видаляє всі дані. Потрібен лише якщо ви розгортали стару версію (без груп).
DROP TABLE IF EXISTS users;DROP TABLE IF EXISTS groups;DROP TABLE IF EXISTS fills;DROP TABLE IF EXISTS push;DROP TABLE IF EXISTS news;DROP TABLE IF EXISTS prices;DROP TABLE IF EXISTS settings;
