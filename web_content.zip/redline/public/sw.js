self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open('v2').then(c=>c.add('/')))});
self.addEventListener('activate',e=>e.waitUntil(clients.claim()));
self.addEventListener('fetch',e=>{if(e.request.mode==='navigate')e.respondWith(fetch(e.request).catch(()=>caches.match('/')))});
self.addEventListener('push',e=>e.waitUntil((async()=>{let t='Нова заправка',b='Водій додав заправку';try{const r=await fetch('/api/latest');if(r.ok){const j=await r.json();t=j.title;b=j.body}}catch(_){}await self.registration.showNotification(t,{body:b,icon:'/icons/icon-192.png',badge:'/icons/icon-192.png',vibrate:[200,80,200,80,400],tag:'fill',renotify:true})})()));
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.matchAll({type:'window'}).then(l=>l.length?l[0].focus():clients.openWindow('/')))});
