-- Для бази, створеної раніше (версія з групами). Виконайте один раз:
ALTER TABLE users ADD COLUMN plan TEXT DEFAULT 'free';
CREATE TABLE IF NOT EXISTS access_codes(code TEXT PRIMARY KEY,kind TEXT,plan TEXT,used_by TEXT,used_at INTEGER);
