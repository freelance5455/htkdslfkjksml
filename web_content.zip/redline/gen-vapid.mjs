import { generateKeyPairSync } from 'node:crypto';
const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
const pub = publicKey.export({ format: 'jwk' });
const raw = Buffer.concat([Buffer.from([4]), Buffer.from(pub.x, 'base64url'), Buffer.from(pub.y, 'base64url')]).toString('base64url');
console.log('VAPID_PUBLIC (у wrangler.toml):\n' + raw + '\n');
console.log('VAPID_PRIVATE (команда wrangler secret put VAPID_PRIVATE, вставте рядок нижче):\n' + JSON.stringify(privateKey.export({ format: 'jwk' })));
