import { randomBytes } from 'node:crypto';
const [kind, plan, n = '5'] = process.argv.slice(2);
if (!['owner', 'driver'].includes(kind) || !['pro', 'promax'].includes(plan)) { console.error('Використання: node gen-codes.mjs <owner|driver> <pro|promax> [кількість] > codes.sql'); process.exit(1); }
const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', part = () => [...randomBytes(4)].map(b => A[b % 32]).join('');
const codes = Array.from({ length: +n }, () => (plan === 'pro' ? 'PRO' : 'MAX') + '-' + part() + '-' + part());
console.log(codes.map(c => `INSERT INTO access_codes(code,kind,plan) VALUES('${c}','${kind}','${plan}');`).join('\n'));
console.error('\nКоди (' + kind + ', ' + plan + '):\n' + codes.join('\n'));
