import HTML from './index.html';
const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const rnd = n => hex(crypto.getRandomValues(new Uint8Array(n)));
const J = (o, s = 200, h = {}) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json', ...h } });
const err = (m, s = 400) => J({ error: m }, s);
// Ліміт ВОДІЇВ у групі: Free до 15, Pro до 150, Pro Max без обмежень (null)
const PLANS = { free: { name: 'Free', limit: 15 }, pro: { name: 'Pro', limit: 150 }, promax: { name: 'Pro Max', limit: null } };
const PAY = ['Готівка', 'Картка', 'Паливна картка'];
const PAY_ICON = { 'Готівка': '💵', 'Картка': '💳', 'Паливна картка': '⛽' };
// Станції, де приймаються НЕ всі способи оплати. Якщо станції тут немає, там доступні всі три.
const STATION_PAY = { 'WOG': ['Готівка', 'Картка'] };
const TITLES = n => ['🔥 ' + n + ' на заправці', '⛽ ' + n + ' залив повний бак', '🏁 ' + n + ' підзарядився', '🚀 ' + n + ' заправився'];
const RANK = { free: 0, pro: 1, promax: 2 };
const PHRASES = ['Заряд отримано, дорога чекає! ⚡', 'Газ у підлогу! 🚀', 'Бак повний, дорога чекає 🛣️', 'Ще одна заправка в статистику 📈', 'Тримайте руль міцніше 🏁', 'Мотор гуде, все під контролем 🔥'];
const newCode = () => 'RL-' + [...crypto.getRandomValues(new Uint8Array(6))].map(b => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[b % 32]).join('');
const ownerList = env => String(env.OWNER_EMAILS || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);

async function hmac(k, m) {
  const key = await crypto.subtle.importKey('raw', enc.encode(k), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return hex(await crypto.subtle.sign('HMAC', key, enc.encode(m)));
}
async function pbk(pw, salt) {
  const key = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 100000 }, key, 256));
}
async function cookie(uid, env, remember) {
  const exp = Date.now() + (remember ? 365 : 1) * 864e5;
  return `s=${uid}.${exp}.${await hmac(env.SESSION_SECRET, uid + '.' + exp)}; Path=/; HttpOnly; Secure; SameSite=Lax` + (remember ? '; Max-Age=31536000' : '');
}
async function me(req, env) {
  const c = (req.headers.get('cookie') || '').match(/s=([^;]+)/);
  if (!c) return null;
  const [uid, exp, sig] = c[1].split('.');
  if (+exp < Date.now() || sig !== await hmac(env.SESSION_SECRET, uid + '.' + exp)) return null;
  return env.DB.prepare('SELECT id,email,name,role,group_id FROM users WHERE id=? AND verified=1').bind(uid).first();
}
async function mail(env, template_id, template_params) {
  const r = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ service_id: env.EMAILJS_SERVICE, template_id, user_id: env.EMAILJS_PUBLIC, accessToken: env.EMAILJS_PRIVATE, template_params })
  });
  return r.ok;
}
const hhmm = t => new Date(t).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Kyiv' });
const b64u = s => btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
async function vapid(env, endpoint) {
  const head = b64u(JSON.stringify({ typ: 'JWT', alg: 'ES256' }));
  const body = b64u(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: env.VAPID_SUBJECT }));
  const key = await crypto.subtle.importKey('jwk', JSON.parse(env.VAPID_PRIVATE), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const sig = new Uint8Array(await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, enc.encode(head + '.' + body)));
  return 'vapid t=' + head + '.' + body + '.' + b64u(String.fromCharCode(...sig)) + ', k=' + env.VAPID_PUBLIC;
}
async function pushAll(env, gid) {
  const { results } = await env.DB.prepare("SELECT p.endpoint FROM push p JOIN users u ON u.id=p.user_id WHERE u.group_id=? AND u.role='owner'").bind(gid).all();
  for (const r of results) {
    try {
      const res = await fetch(r.endpoint, { method: 'POST', headers: { Authorization: await vapid(env, r.endpoint), TTL: '86400', Urgency: 'high' } });
      if (res.status === 404 || res.status === 410) await env.DB.prepare('DELETE FROM push WHERE endpoint=?').bind(r.endpoint).run();
    } catch (e) {}
  }
}
async function planInfo(env, gid) {
  const g = await env.DB.prepare('SELECT plan FROM groups WHERE id=?').bind(gid).first();
  const plan = g && PLANS[g.plan] ? g.plan : 'free';
  const used = (await env.DB.prepare("SELECT COUNT(*) c FROM users WHERE group_id=? AND verified=1 AND role='driver'").bind(gid).first()).c;
  return { plan, name: PLANS[plan].name, limit: PLANS[plan].limit, used };
}
async function scan(env, buf) {
  let bin = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 8192) bin += String.fromCharCode(...u.subarray(i, i + 8192));
  const b64 = btoa(bin);
  const prompt = 'Фото чека або дисплея колонки АЗС. Поверни ТІЛЬКИ JSON: {"liters":число|null,"amount":число|null,"fuel":"А-92|А-95|А-95 Premium|ДП|ДП Premium|Газ"|null,"station":"WOG|OKKO|Укрнафта|SOCAR|Shell|БРСМ|UPG|Інша"|null,"payment":"Готівка|Картка|Паливна картка"|null,"date":"YYYY-MM-DD"|null}. Спосіб оплати бери з чека, якщо видно, інакше null. Літри це обсяг палива, сума це гривні.';
  const run = () => env.AI.run('@cf/meta/llama-3.2-11b-vision-instruct', {
    messages: [{ role: 'user', content: [{ type: 'text', text: prompt }, { type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + b64 } }] }],
    max_tokens: 200
  });
  let r;
  try { r = await run(); }
  catch (e) { await env.AI.run('@cf/meta/llama-3.2-11b-vision-instruct', { prompt: 'agree' }).catch(() => {}); r = await run(); }
  const t = typeof r.response === 'string' ? r.response : JSON.stringify(r.response || {});
  const m = t.match(/\{[\s\S]*\}/);
  return m ? JSON.parse(m[0]) : {};
}

export default {
  async fetch(req, env, ctx) {
    const u = new URL(req.url), p = u.pathname;
    if (p === '/') return new Response(HTML, { headers: { 'content-type': 'text/html;charset=utf-8' } });
    if (p === '/.well-known/assetlinks.json') return J([{ relation: ['delegate_permission/common.handle_all_urls'], target: { namespace: 'android_app', package_name: env.ANDROID_PACKAGE, sha256_cert_fingerprints: [env.ANDROID_SHA256] } }]);
    if (p === '/privacy') return new Response('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>REDLINE: конфіденційність</title><body style="font:16px/1.5 system-ui;max-width:640px;margin:24px auto;padding:0 16px"><h1>Політика конфіденційності REDLINE</h1><p>REDLINE використовується для обліку заправок у закритих групах водіїв. Ми зберігаємо ім’я, електронну пошту, хеш пароля, фотографії чеків і дані про заправки (літри, сума, тип пального, АЗС, спосіб оплати, дата).</p><p>Дані бачить лише власник групи та сам водій (свої записи). Ми не продаємо й не передаємо дані третім особам, окрім сервісів, потрібних для роботи: Cloudflare (зберігання й розпізнавання фото), EmailJS (листи з кодом) та OpenStreetMap (пошук заправок поруч).</p><p>Щоб видалити акаунт і дані, напишіть власнику групи або на ' + (ownerList(env)[0] || '') + '.</p></body>', { headers: { 'content-type': 'text/html;charset=utf-8' } });
    if (!p.startsWith('/api/')) return new Response('Not found', { status: 404 });
    const a = p.slice(5);

    try {
      if (a === 'register' && req.method === 'POST') {
        const { email, name, password, invite, groupPass, owner: wantOwner } = await req.json();
        const em = String(email || '').trim().toLowerCase();
        if (!/^\S+@\S+\.\S+$/.test(em) || !String(name || '').trim() || String(password || '').length < 6) return err('Вкажіть пошту, ім’я та пароль (від 6 символів)');
        const ex = await env.DB.prepare('SELECT id,verified,group_id FROM users WHERE email=?').bind(em).first();
        if (ex && ex.verified) return err('Ця пошта вже зареєстрована. Натисніть «Увійти»', 409);
        const id = ex ? ex.id : rnd(8);
        let role = 'driver', gid = null;
        if (wantOwner) {
          if (env.OPEN_SIGNUP !== '1' && !ownerList(env).includes(em)) return err('Створювати групу поки можуть лише запрошені власники', 403);
          role = 'owner';
          const gp = String(groupPass || '').trim().toUpperCase();
          if (gp.length < 4 || gp.length > 24) return err('Пароль групи: від 4 до 24 символів');
          const t = await env.DB.prepare('SELECT g.id,g.owner_id,u.verified v FROM groups g LEFT JOIN users u ON u.id=g.owner_id WHERE g.invite=?').bind(gp).first();
          if (t && t.owner_id !== id) { if (t.v) return err('Такий пароль групи вже зайнятий. Придумайте інший', 409); await env.DB.prepare('DELETE FROM groups WHERE id=?').bind(t.id).run(); }
          if (ex && ex.group_id) { gid = ex.group_id; await env.DB.prepare('UPDATE groups SET invite=? WHERE id=?').bind(gp, gid).run(); }
          else { gid = rnd(6); await env.DB.prepare("INSERT INTO groups(id,owner_id,invite,plan,created) VALUES(?,?,?,'free',?)").bind(gid, id, gp, Date.now()).run(); }
        } else {
          const g = await env.DB.prepare('SELECT g.id FROM groups g JOIN users o ON o.id=g.owner_id WHERE g.invite=? AND o.verified=1').bind(String(invite || '').trim().toUpperCase()).first();
          if (!g) return err('Невірний пароль групи. Уточніть його у власника', 403);
          gid = g.id;
          const pl = await planInfo(env, gid);
          if (pl.limit != null && pl.used >= pl.limit) return err('Ліміт водіїв групи вичерпано. Зверніться до власника', 402);
        }
        const salt = rnd(8), code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1000000).padStart(6, '0');
        const nm = name.trim(), ph = await pbk(password, salt), oh = await hmac(env.SESSION_SECRET, code), exp = Date.now() + 600000;
        await env.DB.prepare('INSERT INTO users(id,email,name,role,salt,hash,verified,otp,otp_exp,otp_try,created,group_id) VALUES(?,?,?,?,?,?,0,?,?,0,?,?) ON CONFLICT(email) DO UPDATE SET name=?,role=?,salt=?,hash=?,otp=?,otp_exp=?,otp_try=0,group_id=?')
          .bind(id, em, nm, role, salt, ph, oh, exp, Date.now(), gid, nm, role, salt, ph, oh, exp, gid).run();
        const sent = await mail(env, env.EMAILJS_TEMPLATE_OTP, { email: em, passcode: code, time: hhmm(exp) });
        return sent ? J({ ok: true }) : err('Не вдалося надіслати лист. Спробуйте ще раз', 502);
      }
      if (a === 'verify' && req.method === 'POST') {
        const { email, code, remember } = await req.json();
        const row = await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(String(email).trim().toLowerCase()).first();
        if (!row || !row.otp) return err('Спочатку зареєструйтесь');
        if (row.otp_try >= 5 || row.otp_exp < Date.now()) return err('Код прострочений. Зареєструйтесь ще раз');
        if (row.otp !== await hmac(env.SESSION_SECRET, String(code).trim())) {
          await env.DB.prepare('UPDATE users SET otp_try=otp_try+1 WHERE id=?').bind(row.id).run();
          return err('Невірний код');
        }
        let gid = row.group_id;
        if (row.role === 'driver') {
          const pl = await planInfo(env, gid);
          if (pl.limit != null && pl.used >= pl.limit) return err('Ліміт водіїв групи вичерпано. Зверніться до власника', 402);
        } else if (!gid) {
          gid = rnd(6);
          await env.DB.prepare("INSERT INTO groups(id,owner_id,invite,plan,created) VALUES(?,?,?,'free',?)").bind(gid, row.id, newCode(), Date.now()).run();
        }
        await env.DB.prepare('UPDATE users SET verified=1,otp=NULL,group_id=? WHERE id=?').bind(gid, row.id).run();
        return J({ id: row.id, name: row.name, role: row.role }, 200, { 'set-cookie': await cookie(row.id, env, remember) });
      }
      if (a === 'login' && req.method === 'POST') {
        const { email, password, remember } = await req.json();
        const row = await env.DB.prepare('SELECT * FROM users WHERE email=? AND verified=1').bind(String(email).trim().toLowerCase()).first();
        if (!row || row.hash !== await pbk(String(password), row.salt)) return err('Невірна пошта або пароль', 401);
        return J({ id: row.id, name: row.name, role: row.role }, 200, { 'set-cookie': await cookie(row.id, env, remember) });
      }
      if (a === 'logout') return J({ ok: true }, 200, { 'set-cookie': 's=; Path=/; Max-Age=0' });

      const user = await me(req, env);
      if (!user) return err('Потрібен вхід', 401);
      const owner = user.role === 'owner', gid = user.group_id;
      let m;

      if (a === 'me') return J(user);
      if (a === 'rules') return J({ stationPay: STATION_PAY, payments: PAY });
      if (a === 'vapid') return J({ key: env.VAPID_PUBLIC });
      if (a === 'scan' && req.method === 'POST') { try { return J(await scan(env, await req.arrayBuffer())); } catch (e) { return J({}); } }

      if (a === 'fill' && req.method === 'POST') {
        const f = await req.formData(), photo = f.get('photo');
        const liters = parseFloat(f.get('liters')), amount = parseFloat(f.get('amount')) || null;
        if (!photo || !(liters > 0) || liters > 1000) return err('Додайте фото та літри');
        if (photo.size > 4e6) return err('Фото завелике');
        const id = rnd(8), date = /^\d{4}-\d\d-\d\d$/.test(f.get('date') || '') ? f.get('date') : new Date().toISOString().slice(0, 10), fuel = f.get('fuel') || '', station = f.get('station') || '';
        const payment = f.get('payment') || '';
        if (!PAY.includes(payment)) return err('Оберіть, чим оплатили');
        if (!(STATION_PAY[station] || PAY).includes(payment)) return err('Тут ' + payment.toLowerCase() + ' не приймається');
        await env.BUCKET.put('f/' + id, photo.stream(), { httpMetadata: { contentType: 'image/jpeg' } });
        await env.DB.prepare('INSERT INTO fills(id,user_id,liters,amount,fuel,station,date,payment,created) VALUES(?,?,?,?,?,?,?,?,?)').bind(id, user.id, liters, amount, fuel, station, date, payment, Date.now()).run();
        const pr = amount && liters > 0 ? Math.round(amount / liters * 100) / 100 : 0;
        if (pr >= 20 && pr <= 150 && station && fuel) ctx.waitUntil(env.DB.prepare('INSERT INTO prices(group_id,station,fuel,price,updated) VALUES(?,?,?,?,?) ON CONFLICT(group_id,station,fuel) DO UPDATE SET price=?,updated=?').bind(gid, station, fuel, pr, Date.now(), pr, Date.now()).run());
        if (!owner) {
          const og = await env.DB.prepare("SELECT email FROM users WHERE group_id=? AND role='owner' LIMIT 1").bind(gid).first();
          if (og) ctx.waitUntil(mail(env, env.EMAILJS_TEMPLATE_FILL, { email: og.email, driver: user.name, time: hhmm(Date.now()), liters, amount: amount || '—', fuel: fuel || '—', station: station || '—', payment }));
          ctx.waitUntil(pushAll(env, gid));
        }
        return J({ id });
      }
      if (a === 'fills') {
        const fills = owner
          ? (await env.DB.prepare('SELECT f.* FROM fills f JOIN users u ON u.id=f.user_id WHERE u.group_id=? ORDER BY f.date DESC,f.created DESC LIMIT 1000').bind(gid).all()).results
          : (await env.DB.prepare('SELECT * FROM fills WHERE user_id=? ORDER BY date DESC,created DESC LIMIT 500').bind(user.id).all()).results;
        if (!owner) fills.forEach(r => { delete r.amount; });
        const users = owner ? (await env.DB.prepare('SELECT id,name,role,plan FROM users WHERE verified=1 AND group_id=? ORDER BY created').bind(gid).all()).results : [{ id: user.id, name: user.name, role: user.role }];
        return J({ users, fills });
      }
      const canSee = async id => { const f = await env.DB.prepare('SELECT f.user_id, u.group_id g FROM fills f JOIN users u ON u.id=f.user_id WHERE f.id=?').bind(id).first(); return f && (f.user_id === user.id || (owner && f.g === gid)); };
      if ((m = a.match(/^photo\/(\w+)$/))) {
        if (!await canSee(m[1])) return err('Немає доступу', 403);
        const o = await env.BUCKET.get('f/' + m[1]);
        return o ? new Response(o.body, { headers: { 'content-type': 'image/jpeg', 'cache-control': 'private, max-age=86400' } }) : err('Немає фото', 404);
      }
      if ((m = a.match(/^fill\/(\w+)$/)) && req.method === 'DELETE') {
        if (!await canSee(m[1])) return err('Немає доступу', 403);
        await env.DB.prepare('DELETE FROM fills WHERE id=?').bind(m[1]).run(); await env.BUCKET.delete('f/' + m[1]);
        return J({ ok: true });
      }
      if (a === 'csv' && owner) {
        if ((await planInfo(env, gid)).plan === 'free') return err('Експорт доступний у Pro. Введіть код доступу', 402);
        const rows = (await env.DB.prepare('SELECT f.date,u.name,f.station,f.fuel,f.liters,f.amount,f.payment FROM fills f JOIN users u ON u.id=f.user_id WHERE u.group_id=? ORDER BY f.date DESC').bind(gid).all()).results;
        const csv = '\ufeff' + 'Дата;Водій;АЗС;Пальне;Літри;Сума;Оплата\n' + rows.map(r => [r.date, r.name, r.station, r.fuel, r.liters, r.amount, r.payment].map(v => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(';')).join('\n');
        return new Response(csv, { headers: { 'content-type': 'text/csv;charset=utf-8', 'content-disposition': 'attachment; filename=redline.csv' } });
      }
      if (a === 'invite' && owner) return J({ code: (await env.DB.prepare('SELECT invite FROM groups WHERE id=?').bind(gid).first())?.invite || '' });
      if (a === 'invite/new' && req.method === 'POST' && owner) { const code = newCode(); await env.DB.prepare('UPDATE groups SET invite=? WHERE id=?').bind(code, gid).run(); return J({ code }); }
      if (a === 'invite/set' && req.method === 'POST' && owner) {
        const gp = String((await req.json()).code || '').trim().toUpperCase();
        if (gp.length < 4 || gp.length > 24) return err('Пароль групи: від 4 до 24 символів');
        const t = await env.DB.prepare('SELECT g.id,u.verified v FROM groups g LEFT JOIN users u ON u.id=g.owner_id WHERE g.invite=?').bind(gp).first();
        if (t && t.id !== gid) { if (t.v) return err('Такий пароль групи вже зайнятий. Придумайте інший', 409); await env.DB.prepare('DELETE FROM groups WHERE id=?').bind(t.id).run(); }
        await env.DB.prepare('UPDATE groups SET invite=? WHERE id=?').bind(gp, gid).run();
        return J({ code: gp });
      }
      if (a === 'plan' && req.method === 'GET') {
        const pi = await planInfo(env, gid);
        const my = owner ? pi.plan : ((await env.DB.prepare('SELECT plan FROM users WHERE id=?').bind(user.id).first())?.plan || 'free');
        return J({ ...pi, my });
      }
      if (a === 'redeem' && req.method === 'POST') {
        const code = String((await req.json()).code || '').trim().toUpperCase();
        const row = await env.DB.prepare('SELECT * FROM access_codes WHERE code=?').bind(code).first();
        if (!row || row.used_by) { await new Promise(r => setTimeout(r, 800)); return err('Невірний або вже використаний код', 404); }
        if (row.kind === 'owner' && !owner) return err('Цей код для власників групи', 403);
        if (row.kind === 'driver' && owner) return err('Цей код для водіїв', 403);
        const cur = owner ? (await planInfo(env, gid)).plan : ((await env.DB.prepare('SELECT plan FROM users WHERE id=?').bind(user.id).first())?.plan || 'free');
        if (RANK[row.plan] <= RANK[cur]) return err('У вас уже активний такий або вищий план');
        const mk = await env.DB.prepare('UPDATE access_codes SET used_by=?,used_at=? WHERE code=? AND used_by IS NULL').bind(user.id, Date.now(), code).run();
        if (!mk.meta.changes) return err('Код уже використано', 409);
        if (owner) await env.DB.prepare('UPDATE groups SET plan=? WHERE id=?').bind(row.plan, gid).run();
        else await env.DB.prepare('UPDATE users SET plan=? WHERE id=?').bind(row.plan, user.id).run();
        return J({ ok: true, plan: row.plan });
      }
      if (a === 'plan' && req.method === 'POST' && owner) {
        if (env.BILLING_TEST !== '1') return err('Оплата ще не підключена', 402);
        const { plan } = await req.json();
        if (!PLANS[plan]) return err('Невідомий план');
        await env.DB.prepare('UPDATE groups SET plan=? WHERE id=?').bind(plan, gid).run();
        return J(await planInfo(env, gid));
      }
      if (a === 'news' && req.method === 'GET') return J({ news: (await env.DB.prepare('SELECT id,title,body,created FROM news WHERE group_id=? ORDER BY created DESC LIMIT 50').bind(gid).all()).results });
      if (a === 'news' && req.method === 'POST' && owner) {
        const b = await req.json(), title = String(b.title || '').trim().slice(0, 120), body = String(b.body || '').trim().slice(0, 2000);
        if (!title) return err('Додайте заголовок');
        await env.DB.prepare('INSERT INTO news(id,group_id,title,body,created) VALUES(?,?,?,?,?)').bind(rnd(6), gid, title, body, Date.now()).run();
        return J({ ok: true });
      }
      if ((m = a.match(/^news\/(\w+)$/)) && req.method === 'DELETE' && owner) { await env.DB.prepare('DELETE FROM news WHERE id=? AND group_id=?').bind(m[1], gid).run(); return J({ ok: true }); }
      if (a === 'prices' && req.method === 'GET') return J({ prices: (await env.DB.prepare('SELECT station,fuel,price,updated FROM prices WHERE group_id=?').bind(gid).all()).results });
      if (a === 'prices' && req.method === 'POST' && owner) {
        const b = await req.json(), pr = Math.round(parseFloat(b.price) * 100) / 100;
        if (!(pr >= 5 && pr <= 300) || !b.station || !b.fuel) return err('Невірна ціна');
        await env.DB.prepare('INSERT INTO prices(group_id,station,fuel,price,updated) VALUES(?,?,?,?,?) ON CONFLICT(group_id,station,fuel) DO UPDATE SET price=?,updated=?').bind(gid, String(b.station), String(b.fuel), pr, Date.now(), pr, Date.now()).run();
        return J({ ok: true });
      }
      if (a === 'push' && req.method === 'POST' && owner) {
        const s = await req.json();
        if (!s.endpoint) return err('Немає підписки');
        await env.DB.prepare('INSERT OR REPLACE INTO push(endpoint,user_id) VALUES(?,?)').bind(s.endpoint, user.id).run();
        return J({ ok: true });
      }
      if (a === 'latest' && owner) {
        const r = await env.DB.prepare("SELECT f.liters,f.fuel,f.station,f.payment,u.name FROM fills f JOIN users u ON u.id=f.user_id WHERE u.group_id=? AND u.role='driver' ORDER BY f.created DESC LIMIT 1").bind(gid).first();
        if (!r) return J({ title: 'REDLINE', body: 'Нових заправок немає' });
        const body = ['⛽ ' + r.liters + ' л', r.fuel, r.station, r.payment ? (PAY_ICON[r.payment] || '') + ' ' + r.payment : ''].filter(Boolean).join(' · ');
        return J({ title: TITLES(r.name)[Math.floor(Date.now() / 1000) % 4], body: body + '\n' + PHRASES[Math.floor(Date.now() / 1000) % PHRASES.length] });
      }
      if (a === 'nearby') {
        const lat = +u.searchParams.get('lat'), lon = +u.searchParams.get('lon');
        if (!isFinite(lat) || !isFinite(lon)) return err('Немає координат');
        const q = '[out:json][timeout:12];(node(around:6000,' + lat + ',' + lon + ')[amenity=fuel];way(around:6000,' + lat + ',' + lon + ')[amenity=fuel];);out center 40;';
        const r = await fetch('https://overpass-api.de/api/interpreter', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded', 'user-agent': 'REDLINE/1.0' }, body: 'data=' + encodeURIComponent(q) });
        if (!r.ok) return err('Сервіс карт тимчасово недоступний', 502);
        const rad = x => x * Math.PI / 180, hav = (a1, o1, a2, o2) => { const h = Math.sin(rad(a2 - a1) / 2) ** 2 + Math.cos(rad(a1)) * Math.cos(rad(a2)) * Math.sin(rad(o2 - o1) / 2) ** 2; return 12742 * Math.asin(Math.sqrt(h)); };
        const list = ((await r.json()).elements || []).map(e => { const la = e.lat ?? e.center?.lat, lo = e.lon ?? e.center?.lon; return la == null ? null : { name: e.tags?.name || e.tags?.brand || 'Заправка', brand: e.tags?.brand || '', lat: la, lon: lo, km: hav(lat, lon, la, lo) }; }).filter(Boolean).sort((x, y) => x.km - y.km).slice(0, 10);
        return J({ list });
      }
      if (a === 'fuelnews') {
        const key = new Request('https://cache.redline/fuelnews2');
        let res = await caches.default.match(key);
        if (!res) {
          const feed = 'https://news.google.com/rss/search?q=' + encodeURIComponent('ціни на пальне бензин дизель') + '&hl=uk&gl=UA&ceid=UA:uk';
          const r = await fetch(feed, { headers: { 'user-agent': 'Mozilla/5.0 REDLINE' } });
          if (!r.ok) return J({ items: [] });
          const xml = await r.text();
          const dec = s => s.replace(/<!\[CDATA\[|\]\]>/g, '').replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim();
          const g = (s, t) => { const mm = s.match(new RegExp('<' + t + '[^>]*>([\\s\\S]*?)</' + t + '>')); return mm ? dec(mm[1]) : ''; };
          const items = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)].slice(0, 15).map(mm => {
            const s = mm[1], source = g(s, 'source'); let title = g(s, 'title');
            if (source && title.endsWith(' - ' + source)) title = title.slice(0, -(source.length + 3));
            const more = [...g(s, 'description').matchAll(/<a href="(https[^"]+)"[^>]*>([^<]+)<\/a>(?:&nbsp;|\s)*<font[^>]*>([^<]*)<\/font>/g)].map(x => ({ link: dec(x[1]), title: dec(x[2]), source: dec(x[3]) })).filter(x => x.title !== title).slice(0, 4);
            return { title, link: g(s, 'link'), source, t: Date.parse(g(s, 'pubDate')) || 0, more };
          }).filter(x => /^https:\/\//.test(x.link) && x.title);
          res = new Response(JSON.stringify({ items }), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=1800' } });
          ctx.waitUntil(caches.default.put(key, res.clone()));
        }
        return res;
      }
      return err('Не знайдено', 404);
    } catch (e) { console.error(e); return err('Помилка сервера', 500); }
  }
};
