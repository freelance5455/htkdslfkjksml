دانتيل - مشروع Android

هذا ملف مشروع Android Studio حقيقي، وليس ملف HTML فقط.
- افتح المجلد DantelProject في Android Studio.
- انتظر Gradle Sync.
- شغّل التطبيق على الهاتف أو اختر Build > Build APK(s).
- صورة الطفل موجودة داخل assets باسم logo.jpg وتظهر كشعار دائري في الصفحة الرئيسية.

ملاحظة: يحتاج Android Studio واتصال إنترنت أول مرة لتنزيل أدوات Gradle/Android المطلوبة.
