import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView meuWebView;
    private AdbConnectionManager adbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Vamos criar isso embaixo

        // 1. Conecta a janelinha que vai mostrar o HTML
        meuWebView = findViewById(R.id.webview);
        WebSettings config = meuWebView.getSettings();
        
        // Habilita JavaScript — ESSENCIAL para a comunicação
        config.setJavaScriptEnabled(true);
        config.setAllowFileAccess(true);

        // 2. Cria a PONTE entre HTML e Java
        meuWebView.addJavascriptInterface(new PonteComAndroid(), "Android");

        // 3. Carrega o seu arquivo HTML
        meuWebView.loadUrl("file:///android_asset/painel.html");
        meuWebView.setWebViewClient(new WebViewClient());

        // 4. Prepara o ADB (só uma vez)
        try {
            adbManager = (AdbConnectionManager) AdbConnectionManager.getInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 📌 AQUI FICA A PONTE — o HTML vai chamar essas funções!
    public class PonteComAndroid {
        
        @JavascriptInterface // ⚠️ ESSENCIAL — sem isso não funciona!
        public void abrirFreeFire() {
            // Isso roda DENTRO do app, não precisa de navegador!
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "Abrindo Free Fire...", Toast.LENGTH_SHORT).show();
                
                // ✅ Aqui você pode usar o método que já funciona no seu app
                // Por exemplo: getPackageManager().getLaunchIntentForPackage("com.dts.freefireth")
                Intent intent = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
                if (intent != null) startActivity(intent);
            });
        }

        @JavascriptInterface
        public void conectarADB() {
            runOnUiThread(() -> {
                Toast.makeText(MainActivity.this, "Conectando via ADB...", Toast.LENGTH_SHORT).show();
                // Aqui você pode chamar os métodos do seu AdbConnectionManager
            });
        }
    }
}
