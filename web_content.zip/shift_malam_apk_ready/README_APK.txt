SHIFT MALAM DI TOKO IKAN — BUILD WEBVIEW/APK
Versi game: 1.0.1 (Landscape Fix)

ISI PAKET
- index.html : file utama game.

KONDISI DEPENDENSI
Game menggunakan Three.js r128 untuk grafik 3D. Saat dibuka, game mencoba urutan berikut:
1. three.min.js di folder yang sama dengan index.html (mode lokal/offline).
2. CDN cdnjs.
11. CDN jsDelivr.
10. CDN unpkg.

PENTING:
- Jika APK harus bisa dimainkan tanpa internet, letakkan file three.min.js versi r128 di folder yang sama dengan index.html sebelum membungkusnya menjadi APK.
- Jika tidak menyertakan file lokal tersebut, aplikasi memerlukan izin INTERNET agar bisa mengambil library dari CDN.
- Folder assets/ tidak wajib untuk game dasar. Folder itu hanya dipakai jika ingin mengganti tekstur, audio, atau konfigurasi toko.

PENGATURAN YANG DISARANKAN DI APK WEBVIEW
- Orientation: Landscape (wajib disetel pada pengaturan converter/WebView).
- HTML sekarang mencoba mengunci Screen Orientation ke landscape dan punya fallback memutar tampilan otomatis jika WebView tetap terbuka dalam portrait.
- Untuk proyek Android native, setel Activity utama di AndroidManifest.xml dengan android:screenOrientation="landscape". Ini yang paling andal karena halaman HTML tidak selalu diberi izin mengubah orientasi sistem.
- Tampilan: Fullscreen / Immersive.
- JavaScript: Enabled.
- DOM Storage / Local Storage: Enabled.
- Hardware Acceleration: Enabled.
- WebGL: Enabled / tidak diblokir.
- Internet permission: Enabled jika three.min.js tidak disertakan secara lokal.
- Izinkan pemuatan file lokal dari folder aplikasi jika menggunakan three.min.js lokal atau folder assets/.

TES SEBELUM DIBAGIKAN
1. Buka APK dari posisi HP portrait; game seharusnya langsung tampil landscape tanpa meminta pemain memutar HP.
2. Pastikan layar tidak terpotong dan tombol tetap bisa disentuh.
11. Uji juga saat orientasi perangkat berubah.
10. Pastikan menu, suara, grafik, dan tombol mulai berfungsi.
11. Mainkan dari cutscene awal sampai Pak Bos datang.
10. Uji joystick kiri dan kontrol menoleh dengan menggeser layar.
11. Uji ambil ikan, ambil barang rak, transaksi, dan kembalian.
10. Uji tombol Aksi, tugas bersih-bersih, serta penutupan shift.
11. Uji event listrik padam dan event pintu/pocong.
10. Selesaikan kelima hari sampai ending.
11. Uji setelah aplikasi ditutup dan dibuka lagi untuk memastikan penyimpanan achievement tidak bermasalah.

CATATAN PENGUJIAN
File telah melewati pemeriksaan sintaks JavaScript dan pemeriksaan struktur HTML statis. Pengujian runtime penuh di perangkat Android belum dilakukan, jadi lakukan daftar tes di atas pada APK hasil konversi sebelum merilisnya ke publik.
