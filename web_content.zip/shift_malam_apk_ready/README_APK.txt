SHIFT MALAM DI TOKO IKAN — BUILD WEBVIEW/APK
Versi game: 1.0.0

ISI PAKET
- index.html : file utama game.

KONDISI DEPENDENSI
Game menggunakan Three.js r128 untuk grafik 3D. Saat dibuka, game mencoba urutan berikut:
1. three.min.js di folder yang sama dengan index.html (mode lokal/offline).
2. CDN cdnjs.
3. CDN jsDelivr.
4. CDN unpkg.

PENTING:
- Jika APK harus bisa dimainkan tanpa internet, letakkan file three.min.js versi r128 di folder yang sama dengan index.html sebelum membungkusnya menjadi APK.
- Jika tidak menyertakan file lokal tersebut, aplikasi memerlukan izin INTERNET agar bisa mengambil library dari CDN.
- Folder assets/ tidak wajib untuk game dasar. Folder itu hanya dipakai jika ingin mengganti tekstur, audio, atau konfigurasi toko.

PENGATURAN YANG DISARANKAN DI APK WEBVIEW
- Orientation: Landscape.
- Tampilan: Fullscreen / Immersive.
- JavaScript: Enabled.
- DOM Storage / Local Storage: Enabled.
- Hardware Acceleration: Enabled.
- WebGL: Enabled / tidak diblokir.
- Internet permission: Enabled jika three.min.js tidak disertakan secara lokal.
- Izinkan pemuatan file lokal dari folder aplikasi jika menggunakan three.min.js lokal atau folder assets/.

TES SEBELUM DIBAGIKAN
1. Buka APK di HP dalam mode landscape.
2. Pastikan menu, suara, grafik, dan tombol mulai berfungsi.
3. Mainkan dari cutscene awal sampai Pak Bos datang.
4. Uji joystick kiri dan kontrol menoleh dengan menggeser layar.
5. Uji ambil ikan, ambil barang rak, transaksi, dan kembalian.
6. Uji tombol Aksi, tugas bersih-bersih, serta penutupan shift.
7. Uji event listrik padam dan event pintu/pocong.
8. Selesaikan kelima hari sampai ending.
9. Uji setelah aplikasi ditutup dan dibuka lagi untuk memastikan penyimpanan achievement tidak bermasalah.

CATATAN PENGUJIAN
File telah melewati pemeriksaan sintaks JavaScript dan pemeriksaan struktur HTML statis. Pengujian runtime penuh di perangkat Android belum dilakukan, jadi lakukan daftar tes di atas pada APK hasil konversi sebelum merilisnya ke publik.
