import { readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
globalThis.crypto ??= webcrypto;
const dbx = new DatabaseSync(':memory:');
dbx.exec(readFileSync(new URL('../migrations/0001_initial.sql', import.meta.url), 'utf8'));
class Stmt {
  constructor(sql){this.sql=sql;this.args=[];}
  bind(...args){this.args=args;return this;}
  first(){return dbx.prepare(this.sql).get(...this.args) ?? null;}
  all(){return {results:dbx.prepare(this.sql).all(...this.args)};}
  run(){const r=dbx.prepare(this.sql).run(...this.args);return {success:true,meta:{changes:Number(r.changes)}};}
}
const DB={prepare(sql){return new Stmt(sql)}};
const ASSETS={async fetch(req){const p=new URL(req.url).pathname;return new Response('asset:'+p,{status:200,headers:{'content-type':'text/plain'}})}};
const src=readFileSync(new URL('../src/worker.js',import.meta.url),'utf8');
const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
const env={DB,ASSETS,ADMIN_KEY:'test-admin-secret'};
async function call(path,{method='GET',headers={},body}={}){const req=new Request('https://tawsila.test'+path,{method,headers:{...(body?{'content-type':'application/json'}:{}),...headers},body:body?JSON.stringify(body):undefined});const res=await worker.fetch(req,env);const ct=res.headers.get('content-type')||'';const data=ct.includes('json')?await res.json():await res.text();return {status:res.status,data};}
const admin={'x-admin-key':'test-admin-secret'};
let r=await call('/api/health');assert.equal(r.status,200);assert.equal(r.data.database,'connected');
r=await call('/admin');assert.equal(r.status,200);assert.equal(r.data,'asset:/admin.html');
r=await call('/api/admin/settings',{headers:admin});assert.equal(r.data.platformCommissionRate,10);
r=await call('/api/admin/settings',{method:'PUT',headers:admin,body:{platformCommissionRate:10}});assert.equal(r.status,200);
for(const [id,name] of [['el-khroub','الخروب']]){r=await call('/api/admin/zones/'+id,{method:'PUT',headers:admin,body:{deliveryFee:200,estimatedMinutes:35,enabled:true}});assert.equal(r.status,200);}
async function merchant(name,phone){let x=await call('/api/merchant/register',{method:'POST',body:{name,type:'متجر',owner:'مالك',phone,password:'password123'}});assert.equal(x.status,201);const all=(await call('/api/admin/merchants',{headers:admin})).data;const m=all.find(v=>v.phone===phone);assert.ok(m);x=await call('/api/admin/merchants/'+m.id,{method:'PATCH',headers:admin,body:{status:'active'}});assert.equal(x.status,200);x=await call('/api/merchant/login',{method:'POST',body:{phone,password:'password123'}});if(x.status!==200)console.log('LOGIN FAIL',x);assert.equal(x.status,200);return {merchant:m,token:x.data.token};}
const a=await merchant('تاجر ألف','0550000001');const b=await merchant('تاجر باء','0550000002');
let p1=await call('/api/merchant/products',{method:'POST',headers:{'x-merchant-token':a.token},body:{name:'منتج ألف',category:'عام',price:1000}});assert.equal(p1.status,201);
let p2=await call('/api/merchant/products',{method:'POST',headers:{'x-merchant-token':b.token},body:{name:'منتج باء',category:'عام',price:2000}});assert.equal(p2.status,201);
r=await call('/api/products');assert.equal(r.status,200);assert.equal(r.data.length,2);
r=await call('/api/orders',{method:'POST',body:{customer:{name:'زبون',phone:'0551234567',wilaya:'الخروب',address:'عنوان تجريبي'},items:[{productId:p1.data.product.id,quantity:2},{productId:p2.data.product.id,quantity:1}]}});
assert.equal(r.status,201);assert.equal(r.data.total,4000);assert.equal(r.data.deliveryFee,200);assert.equal(r.data.platformCommissionRate,10);
const orders=(await call('/api/admin/orders',{headers:admin})).data;const order=orders.find(o=>o.id===r.data.orderId);assert.ok(order);assert.equal(order.platformCommissionRate,10);assert.equal(order.platformCommission,400);assert.equal(order.merchantBreakdown.length,2);assert.equal(order.merchantBreakdown.reduce((s,x)=>s+x.commission,0),400);assert.equal(order.merchantBreakdown.reduce((s,x)=>s+x.merchantNet,0),3600);
const aOrders=await call('/api/merchant/orders',{headers:{'x-merchant-token':a.token}});assert.equal(aOrders.status,200);assert.equal(aOrders.data.length,1);assert.equal(aOrders.data[0].items.length,1);
r=await call('/api/admin/commission-summary',{headers:admin});assert.equal(r.data.total,400);
r=await call('/api/admin/settings',{method:'PUT',headers:admin,body:{platformCommissionRate:20}});assert.equal(r.status,200);
const historical=(await call('/api/admin/orders',{headers:admin})).data.find(o=>o.id===order.id);assert.equal(historical.platformCommissionRate,10);assert.equal(historical.platformCommission,400);
r=await call('/api/admin/orders/'+order.id,{method:'PATCH',headers:admin,body:{status:'delivered'}});assert.equal(r.status,200);
r=await call('/api/admin/commission-summary',{headers:admin});assert.equal(r.data.realized,400);
r=await call('/api/merchant/logout',{method:'POST',headers:{'x-merchant-token':a.token}});assert.equal(r.status,200);
r=await call('/api/merchant/products',{headers:{'x-merchant-token':a.token}});assert.equal(r.status,401);
r=await call('/api/admin/orders');assert.equal(r.status,401);
console.log('PASS: Worker integration tests (health, static routes, admin auth/settings/zones, merchant register/approval/login, products, multi-merchant order, commission excludes delivery, merchant isolation, order status, logout).');
