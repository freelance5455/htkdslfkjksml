const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { setTimeout: delay } = require('node:timers/promises');

const source = path.resolve(__dirname, '..');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tawsila-test-'));
const port = 31000 + Math.floor(Math.random() * 20000);
const adminKey = 'tawsila-test-admin-key-very-long';
let child;
const base = `http://127.0.0.1:${port}`;

async function call(route, method = 'GET', body, headers = {}) {
  const response = await fetch(base + route, {
    method,
    headers: { 'content-type': 'application/json', ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const raw = await response.text();
  let data;
  try { data = JSON.parse(raw); } catch { data = raw; }
  return { status: response.status, data, headers: response.headers };
}

async function main() {
  fs.cpSync(source, temp, { recursive: true, filter: (name) => !name.includes('node_modules') && !name.includes('.git') });
  for (const [file, value] of Object.entries({ 'merchants.json': [], 'orders.json': [], 'products.json': [], 'settings.json': { platformCommissionRate: 10 } })) fs.writeFileSync(path.join(temp, 'data', file), JSON.stringify(value, null, 2));
  child = spawn(process.execPath, ['server.js'], {
    cwd: temp,
    env: { ...process.env, NODE_ENV: 'test', PORT: String(port), ADMIN_KEY: adminKey, DATABASE_URL: '' },
    stdio: 'ignore',
  });

  let health;
  for (let i = 0; i < 50; i++) {
    try { health = await call('/api/health'); if (health.status === 200) break; } catch {}
    await delay(100);
  }
  assert.equal(health?.status, 200, 'health endpoint');
  assert.equal(health.headers.get('x-frame-options'), 'DENY', 'security headers');

  const admin = { 'x-admin-key': adminKey };
  let result = await call('/api/merchant/register', 'POST', {
    name: 'مطعم اختبار', type: 'مطعم', owner: 'مالك', phone: '0550000001', password: 'pass12345',
  });
  assert.equal(result.status, 201, 'merchant registration');

  const merchants = await call('/api/admin/merchants', 'GET', undefined, admin);
  assert.equal(merchants.status, 200);
  const merchant = merchants.data[0];
  result = await call(`/api/admin/merchants/${merchant.id}`, 'PATCH', { status: 'active' }, admin);
  assert.equal(result.status, 200, 'admin approval');

  result = await call('/api/merchant/login', 'POST', { phone: '0550000001', password: 'pass12345' });
  assert.equal(result.status, 200, 'merchant login');
  const token = result.data.token;
  const merchantHeaders = { 'x-merchant-token': token };

  result = await call('/api/merchant/products', 'POST', {
    name: 'وجبة اختبار', category: 'وجبات', price: 1000,
  }, merchantHeaders);
  assert.equal(result.status, 201, 'product creation');
  const product = result.data.product;

  result = await call('/api/admin/zones/el-khroub', 'PUT', {
    deliveryFee: 200, estimatedMinutes: 35, enabled: true,
  }, admin);
  assert.equal(result.status, 200, 'delivery zone setup');

  result = await call('/api/orders', 'POST', {
    customer: { name: 'زبون اختبار', phone: '0550000002', wilaya: 'الخروب', address: 'عنوان الاختبار' },
    items: [{ productId: product.id, quantity: 2 }],
  });
  assert.equal(result.status, 201, 'customer order');
  assert.equal(result.data.total, 2000);
  assert.equal(result.data.deliveryFee, 200);
  assert.equal(result.data.platformCommissionRate, 10);

  const merchantOrders = await call('/api/merchant/orders', 'GET', undefined, merchantHeaders);
  assert.equal(merchantOrders.data[0].merchantBreakdown[0].commission, 200);
  assert.equal(merchantOrders.data[0].merchantBreakdown[0].merchantNet, 1800);

  const summary = await call('/api/admin/commission-summary', 'GET', undefined, admin);
  assert.equal(summary.data.total, 200);
  result = await call('/api/admin/settings', 'PUT', { platformCommissionRate: 15 }, admin);
  assert.equal(result.status, 200);
  const orders = await call('/api/admin/orders', 'GET', undefined, admin);
  assert.equal(orders.data[0].platformCommissionRate, 10, 'historical commission rate is immutable');

  result = await call('/api/admin/settings', 'PUT', { platformCommissionRate: 99 }, admin);
  assert.equal(result.status, 400, 'invalid commission rejected');
  result = await call('/api/merchant/logout', 'POST', {}, merchantHeaders);
  assert.equal(result.status, 200, 'logout revokes session');
  result = await call('/api/merchant/me', 'GET', undefined, merchantHeaders);
  assert.equal(result.status, 401, 'revoked session is rejected');

  console.log('PASS: health/security headers, registration, approval, login, product, delivery zone, order, commission, merchant net, admin summary, historical rate, invalid rate, logout revocation.');
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => {
  if (child) child.kill('SIGTERM');
  fs.rmSync(temp, { recursive: true, force: true });
});
