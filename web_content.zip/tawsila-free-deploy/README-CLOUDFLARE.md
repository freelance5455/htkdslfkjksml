# Tawsila — Cloudflare Workers + D1

This package contains the Cloudflare Workers runtime (no Node HTTP server, filesystem access, PostgreSQL driver, or Node crypto dependency at runtime), the original Arabic storefront/admin/merchant pages, and a D1 migration.

## Included API

- Public: `GET /api/health`, `/api/products`, `/api/merchants`, `/api/zones`, `POST /api/orders`.
- Merchant: register, login, logout, profile, product create/update/list, order list/status update.
- Admin: list orders/merchants/zones, approve/suspend merchants, update delivery zones, update commission, commission summary, order status.
- Passwords use Web Crypto PBKDF2; merchant session tokens are random and only SHA-256 hashes are stored in D1.
- Platform commission defaults to 10%, is calculated for each merchant's product subtotal, excludes delivery fees, and the rate/amount are snapshotted on each order.

## Cloudflare setup (required before deploy)

1. In Cloudflare Dashboard, open **Workers & Pages → D1 SQL Database** and select the existing database `tawsila-constantine-25`.
2. Copy its **Database ID**. In this project open `wrangler.toml` and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with that exact ID. Do not change the binding name `DB` or database name.
3. In the Worker settings, confirm a D1 binding exists with **Variable name = `DB`** and **Database = `tawsila-constantine-25`**. The TOML binding declares the same mapping for Wrangler deployments; a local file cannot prove the Dashboard binding is already attached.
4. Set the admin key as a Worker secret named `ADMIN_KEY`. Never put the real key in source files or send it in chat.
5. Apply the migration once, then deploy:

```sh
npx wrangler d1 migrations apply tawsila-constantine-25 --remote
npx wrangler secret put ADMIN_KEY
npx wrangler deploy
```

If using the Cloudflare Dashboard deployment flow rather than Wrangler, upload the project through a Git-connected Worker build and configure the same D1 binding and `ADMIN_KEY` secret in Worker settings. Ensure the `migrations/0001_initial.sql` migration has been applied to the selected D1 database.

## Verify after deployment

Open `https://YOUR-WORKER-DOMAIN/api/health`. Expected JSON includes `"ok":true` and `"database":"connected"`. If it reports missing `DB`, correct the binding before using the storefront. Open `/`, `/admin`, and `/merchant` to verify the three pages.

## Local tests

The dependency-free integration test uses Node's built-in SQLite implementation as a D1-compatible test adapter:

```sh
node --check src/worker.js
node tests/worker.integration.mjs
```

It exercises the Worker handler against a real in-memory SQLite database and checks merchant registration/approval/login, product management, multi-merchant ordering, historical commission snapshots, delivery-fee exclusion, admin operations, session logout, and static page routing.

## Important limits / operational notes

- This repository has been tested locally against SQLite through a D1 API adapter, **not against a live Cloudflare account**. A live `/api/health` check is still required after binding and deployment.
- The original `server.js` remains for reference/legacy Node hosting only. Cloudflare uses `src/worker.js` and does not execute `server.js`.
- The original sample product records have no merchant owner, so they are not published in the marketplace. Register a merchant, approve it from `/admin`, then add products from `/merchant`.
- Configure actual delivery fees and estimated times for each municipality in `/admin`; areas with missing fees/times correctly reject orders.
- Protect the admin key. Add Cloudflare WAF/rate-limiting rules before public production launch. A global distributed rate limiter is not implemented in this Worker package.
- D1 and Workers free-plan limits apply; no service can guarantee zero downtime or unlimited free usage.
