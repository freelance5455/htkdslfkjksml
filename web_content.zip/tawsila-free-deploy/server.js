const http=require('node:http'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const ROOT=__dirname,PORT=Number(process.env.PORT||3000),ADMIN_KEY=process.env.ADMIN_KEY||(process.env.NODE_ENV==='production'?'':'change-this-admin-key');
const DATABASE_URL=process.env.DATABASE_URL||'';
let pool=null;const cache=new Map();const loginAttempts=new Map();
const PUBLIC=path.join(ROOT,'public'),DATA=path.join(ROOT,'data');
const PRODUCTS=path.join(DATA,'products.json'),ORDERS=path.join(DATA,'orders.json'),ZONES=path.join(DATA,'zones.json'),MERCHANTS=path.join(DATA,'merchants.json'),SETTINGS=path.join(DATA,'settings.json');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
function read(f,d){const key=path.basename(f);return cache.has(key)?cache.get(key):d}
async function write(f,d){const key=path.basename(f);if(pool){await pool.query('INSERT INTO tawsila_state(state_key,state_value) VALUES($1,$2::jsonb) ON CONFLICT(state_key) DO UPDATE SET state_value=EXCLUDED.state_value,updated_at=NOW()',[key,JSON.stringify(d)])}else{fs.writeFileSync(f,JSON.stringify(d,null,2),'utf8')}cache.set(key,d)}
async function initStorage(){for(const f of [PRODUCTS,ORDERS,ZONES,MERCHANTS,SETTINGS]){const key=path.basename(f);let val; if(pool){const r=await pool.query('SELECT state_value FROM tawsila_state WHERE state_key=$1',[key]);if(r.rowCount){val=r.rows[0].state_value}else{val=JSON.parse(fs.readFileSync(f,'utf8'));await pool.query('INSERT INTO tawsila_state(state_key,state_value) VALUES($1,$2::jsonb)',[key,JSON.stringify(val)])}}else{val=JSON.parse(fs.readFileSync(f,'utf8'))}cache.set(key,val)}if(pool)await pool.query(`CREATE TABLE IF NOT EXISTS tawsila_sessions(token_hash TEXT PRIMARY KEY,merchant_id TEXT NOT NULL,expires_at TIMESTAMPTZ NOT NULL); CREATE INDEX IF NOT EXISTS tawsila_sessions_expiry_idx ON tawsila_sessions(expires_at);`)}
async function createSession(token,merchantId){const tokenHash=crypto.createHash('sha256').update(token).digest('hex');if(pool)await pool.query("INSERT INTO tawsila_sessions(token_hash,merchant_id,expires_at) VALUES($1,$2,NOW()+INTERVAL '7 days')",[tokenHash,merchantId]);else localSessions.set(token,merchantId)}
const localSessions=new Map();
async function merchantFor(req){const token=req.headers['x-merchant-token'];if(!token)return null;let id;if(pool){const h=crypto.createHash('sha256').update(token).digest('hex'),r=await pool.query('SELECT merchant_id FROM tawsila_sessions WHERE token_hash=$1 AND expires_at>NOW()',[h]);id=r.rows[0]?.merchant_id}else id=localSessions.get(token);return id?read(MERCHANTS,[]).find(m=>m.id===id&&m.status==='active'):null}
function rateLimited(req,key,limit=8){const ip=(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').toString().split(',')[0].trim(),k=key+':'+ip,now=Date.now(),v=loginAttempts.get(k)||{count:0,start:now};if(now-v.start>15*60*1000){v.count=0;v.start=now}v.count++;loginAttempts.set(k,v);return v.count>limit}
function securityHeaders(res){res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'")}
function send(res,s,d){securityHeaders(res);res.writeHead(s,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(d))}
function getBody(req){return new Promise((resolve,reject)=>{let raw='';req.on('data',c=>{raw+=c;if(raw.length>1e6){reject(Error('الطلب كبير'));req.destroy()}});req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'))}catch{reject(Error('بيانات غير صالحة'))}});req.on('error',reject)})}
function clean(v,n=300){return typeof v==='string'?v.trim().slice(0,n):''}
function isAdmin(req){const got=Buffer.from(String(req.headers['x-admin-key']||'')),want=Buffer.from(ADMIN_KEY);return !!ADMIN_KEY&&got.length===want.length&&crypto.timingSafeEqual(got,want)}
function hashPassword(password,salt=crypto.randomBytes(16).toString('hex')){return {salt,hash:crypto.scryptSync(password,salt,64).toString('hex')}}
function verifyPassword(password,m){try{return crypto.timingSafeEqual(Buffer.from(hashPassword(password,m.passwordSalt).hash,'hex'),Buffer.from(m.passwordHash,'hex'))}catch{return false}}
function publicMerchant(m){return {id:m.id,name:m.name,type:m.type,phone:m.phone,status:m.status,createdAt:m.createdAt}}
function adminMerchant(m){return {...publicMerchant(m),owner:m.owner}}
function commissionRate(){const n=Number(read(SETTINGS,{platformCommissionRate:10}).platformCommissionRate);return Number.isFinite(n)&&n>=0&&n<=50?n:10;}
function money2(n){return Math.round((n+Number.EPSILON)*100)/100;}
function validProduct(b){const name=clean(b.name,100),category=clean(b.category,60),price=Number(b.price);if(!name||!category||!Number.isFinite(price)||price<1||price>10000000)throw Error('تحقق من اسم المنتج والتصنيف والسعر');return {name,category,price,description:clean(b.description,300),emoji:clean(b.emoji,8)||'📦'}}
const server=http.createServer(async(req,res)=>{
 try {
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,service:'tawsila'});
 if(req.method==='GET'&&url.pathname==='/api/products'){
  const merchants=read(MERCHANTS,[]),approved=new Map(merchants.filter(m=>m.status==='active').map(m=>[m.id,m.name]));
  return send(res,200,read(PRODUCTS,[]).filter(p=>p.active!==false&&p.merchantId&&approved.has(p.merchantId)).map(p=>({...p,merchantName:approved.get(p.merchantId)})));
 }
 if(req.method==='GET'&&url.pathname==='/api/merchants')return send(res,200,read(MERCHANTS,[]).filter(m=>m.status==='active').map(publicMerchant));
 if(req.method==='GET'&&url.pathname==='/api/zones')return send(res,200,read(ZONES,[]).filter(z=>z.enabled));
 if(req.method==='POST'&&url.pathname==='/api/merchant/register'){
  if(rateLimited(req,'register',5))return send(res,429,{error:'محاولات كثيرة. حاول بعد 15 دقيقة'});
  try{const b=await getBody(req),name=clean(b.name,100),type=clean(b.type,50),owner=clean(b.owner,80),phone=clean(b.phone,20),password=typeof b.password==='string'?b.password:'';
   if(!name||!type||!owner||!phone||password.length<8)return send(res,400,{error:'أكمل المعلومات، وكلمة السر لازم تكون 8 أحرف على الأقل'});
   if(!/^[0-9+()\-\s]{8,20}$/.test(phone))return send(res,400,{error:'رقم الهاتف غير صالح'});
   const merchants=read(MERCHANTS,[]);if(merchants.some(m=>m.phone===phone))return send(res,409,{error:'هذا الرقم مسجل من قبل'});
   const pw=hashPassword(password),m={id:'M-'+crypto.randomBytes(5).toString('hex'),name,type,owner,phone,passwordSalt:pw.salt,passwordHash:pw.hash,status:'pending',createdAt:new Date().toISOString()};merchants.push(m);await write(MERCHANTS,merchants);return send(res,201,{ok:true,message:'تم إرسال طلب التسجيل. انتظر موافقة الإدارة.'});
  }catch(e){return send(res,400,{error:e.message})}
 }
 if(req.method==='POST'&&url.pathname==='/api/merchant/login'){
  if(rateLimited(req,'merchant-login',8))return send(res,429,{error:'محاولات دخول كثيرة. حاول بعد 15 دقيقة'});
  try{const b=await getBody(req),phone=clean(b.phone,20),password=typeof b.password==='string'?b.password:'',m=read(MERCHANTS,[]).find(x=>x.phone===phone);
   if(!m||!verifyPassword(password,m))return send(res,401,{error:'رقم الهاتف أو كلمة السر غير صحيحة'});
   if(m.status!=='active')return send(res,403,{error:m.status==='pending'?'حسابك ينتظر موافقة الإدارة':'الحساب موقوف، تواصل مع الإدارة'});
   const token=crypto.randomBytes(32).toString('hex');await createSession(token,m.id);return send(res,200,{ok:true,token,merchant:publicMerchant(m)});
  }catch(e){return send(res,400,{error:e.message})}
 }
 if(url.pathname.startsWith('/api/merchant/')){
  const merchant=await merchantFor(req);if(!merchant)return send(res,401,{error:'سجل الدخول بحساب تاجر مفعل'});
  if(req.method==='POST'&&url.pathname==='/api/merchant/logout'){const token=req.headers['x-merchant-token'];if(pool){const h=crypto.createHash('sha256').update(token).digest('hex');await pool.query('DELETE FROM tawsila_sessions WHERE token_hash=$1',[h])}else localSessions.delete(token);return send(res,200,{ok:true})}
  if(req.method==='GET'&&url.pathname==='/api/merchant/me')return send(res,200,{merchant:publicMerchant(merchant)});
  if(req.method==='GET'&&url.pathname==='/api/merchant/products')return send(res,200,read(PRODUCTS,[]).filter(p=>p.merchantId===merchant.id));
  if(req.method==='POST'&&url.pathname==='/api/merchant/products'){
   try{const b=await getBody(req),v=validProduct(b),all=read(PRODUCTS,[]),p={id:'p-'+crypto.randomBytes(5).toString('hex'),...v,merchantId:merchant.id,active:true,createdAt:new Date().toISOString()};all.push(p);await write(PRODUCTS,all);return send(res,201,{ok:true,product:p})}catch(e){return send(res,400,{error:e.message})}
  }
  if(req.method==='PATCH'&&url.pathname.startsWith('/api/merchant/products/')){
   try{const id=decodeURIComponent(url.pathname.split('/').pop()),b=await getBody(req),all=read(PRODUCTS,[]),p=all.find(x=>x.id===id&&x.merchantId===merchant.id);if(!p)return send(res,404,{error:'المنتج غير موجود'});if(b.active===false){p.active=false}else{Object.assign(p,validProduct(b))}await write(PRODUCTS,all);return send(res,200,{ok:true,product:p})}catch(e){return send(res,400,{error:e.message})}
  }
  if(req.method==='GET'&&url.pathname==='/api/merchant/orders')return send(res,200,read(ORDERS,[]).filter(o=>o.items.some(i=>i.merchantId===merchant.id)).map(o=>{const ownItems=o.items.filter(i=>i.merchantId===merchant.id),ownFinance=(o.merchantBreakdown||[]).filter(m=>m.merchantId===merchant.id);return {...o,items:ownItems,total:money2(ownItems.reduce((sum,i)=>sum+i.lineTotal,0)),merchantBreakdown:ownFinance}}));
  if(req.method==='PATCH'&&url.pathname.startsWith('/api/merchant/orders/')){
   try{const id=decodeURIComponent(url.pathname.split('/').pop()),b=await getBody(req),allowed=['confirmed','preparing','on_the_way','delivered','cancelled'];if(!allowed.includes(b.status))return send(res,400,{error:'حالة غير صالحة'});const all=read(ORDERS,[]),o=all.find(x=>x.id===id&&x.items.some(i=>i.merchantId===merchant.id));if(!o)return send(res,404,{error:'الطلب غير موجود'});o.merchantStatuses=o.merchantStatuses||{};o.merchantStatuses[merchant.id]=b.status;await write(ORDERS,all);return send(res,200,{ok:true})}catch(e){return send(res,400,{error:e.message})}
  }
  return send(res,404,{error:'مسار التاجر غير موجود'});
 }
 if(req.method==='POST'&&url.pathname==='/api/orders'){
  try{const b=await getBody(req),c=b.customer||{},lines=Array.isArray(b.items)?b.items:[],customer={name:clean(c.name,80),phone:clean(c.phone,20),wilaya:clean(c.wilaya,60),address:clean(c.address,300)};
   if(!customer.name||!customer.phone||!customer.wilaya||!customer.address)return send(res,400,{error:'يرجى ملء معلومات التوصيل كاملة'});
   if(!/^[0-9+()\-\s]{8,20}$/.test(customer.phone))return send(res,400,{error:'رقم الهاتف غير صالح'});
   const zone=read(ZONES,[]).find(z=>z.name===customer.wilaya&&z.enabled);if(!zone)return send(res,400,{error:'التوصيل غير متاح في البلدية المختارة حالياً'});
   if(!lines.length||lines.length>50)return send(res,400,{error:'السلة فارغة أو غير صالحة'});
   const catalog=read(PRODUCTS,[]),merchants=read(MERCHANTS,[]),approved=new Set(merchants.filter(m=>m.status==='active').map(m=>m.id)),items=[];
   for(const line of lines){const product=catalog.find(p=>p.id===line.productId&&p.active!==false&&p.merchantId&&approved.has(p.merchantId)),quantity=Number(line.quantity);if(!product||!Number.isInteger(quantity)||quantity<1||quantity>30)return send(res,400,{error:'منتج أو كمية غير صالحة'});items.push({productId:product.id,merchantId:product.merchantId||null,merchantName:product.merchantId?merchants.find(m=>m.id===product.merchantId)?.name:'متجر تجريبي',name:product.name,unitPrice:product.price,quantity,lineTotal:product.price*quantity})}
   const total=items.reduce((s,x)=>s+x.lineTotal,0),rate=commissionRate(),byMerchant=new Map();
   for(const item of items){const entry=byMerchant.get(item.merchantId)||{merchantId:item.merchantId,merchantName:item.merchantName,subtotal:0};entry.subtotal+=item.lineTotal;byMerchant.set(item.merchantId,entry)}
   const merchantBreakdown=[...byMerchant.values()].map(m=>{const commission=money2(m.subtotal*rate/100);return {...m,commission,merchantNet:money2(m.subtotal-commission)}});
   const platformCommission=money2(merchantBreakdown.reduce((sum,m)=>sum+m.commission,0));
   const orders=read(ORDERS,[]),order={id:'TW-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(2).toString('hex').toUpperCase(),createdAt:new Date().toISOString(),status:'new',customer,deliveryFee:zone.deliveryFee,estimatedMinutes:zone.estimatedMinutes,notes:clean(b.notes,300),paymentMethod:'cash_on_delivery',items,total,platformCommissionRate:rate,platformCommission,merchantBreakdown};orders.unshift(order);await write(ORDERS,orders);return send(res,201,{ok:true,orderId:order.id,total,deliveryFee:zone.deliveryFee,platformCommissionRate:rate});
  }catch(e){return send(res,400,{error:e.message||'تعذر تسجيل الطلب'})}
 }
 if(url.pathname.startsWith('/api/admin/')){
  if(!isAdmin(req)){if(rateLimited(req,'admin-invalid',8))return send(res,429,{error:'محاولات إدارة كثيرة. حاول بعد 15 دقيقة'});return send(res,401,{error:'مفتاح الإدارة غير صحيح'});}
  if(req.method==='GET'&&url.pathname==='/api/admin/orders')return send(res,200,read(ORDERS,[]));
  if(req.method==='GET'&&url.pathname==='/api/admin/settings')return send(res,200,{platformCommissionRate:commissionRate()});
  if(req.method==='PUT'&&url.pathname==='/api/admin/settings'){try{const b=await getBody(req),rate=Number(b.platformCommissionRate);if(!Number.isFinite(rate)||rate<0||rate>50)return send(res,400,{error:'العمولة يجب أن تكون بين 0 و50 بالمئة'});const settings=read(SETTINGS,{});settings.platformCommissionRate=rate;await write(SETTINGS,settings);return send(res,200,{ok:true,platformCommissionRate:rate})}catch(e){return send(res,400,{error:e.message})}}
  if(req.method==='GET'&&url.pathname==='/api/admin/commission-summary'){const orders=read(ORDERS,[]);let total=0,realized=0,pending=0;for(const o of orders){const c=Number(o.platformCommission||0);total+=c;if(o.status==='delivered')realized+=c;else pending+=c;}return send(res,200,{rate:commissionRate(),total:money2(total),realized:money2(realized),pending:money2(pending),orders:orders.length})}
  if(req.method==='GET'&&url.pathname==='/api/admin/zones')return send(res,200,read(ZONES,[]));
  if(req.method==='GET'&&url.pathname==='/api/admin/merchants')return send(res,200,read(MERCHANTS,[]).map(adminMerchant));
  if(req.method==='PATCH'&&url.pathname.startsWith('/api/admin/merchants/')){try{const id=decodeURIComponent(url.pathname.split('/').pop()),b=await getBody(req),all=read(MERCHANTS,[]),m=all.find(x=>x.id===id);if(!m)return send(res,404,{error:'التاجر غير موجود'});if(!['active','pending','suspended'].includes(b.status))return send(res,400,{error:'حالة غير صالحة'});m.status=b.status;await write(MERCHANTS,all);return send(res,200,{ok:true,merchant:publicMerchant(m)})}catch(e){return send(res,400,{error:e.message})}}
  if(req.method==='PUT'&&url.pathname.startsWith('/api/admin/zones/')){try{const id=decodeURIComponent(url.pathname.split('/').pop()),b=await getBody(req),zones=read(ZONES,[]),z=zones.find(x=>x.id===id);if(!z)return send(res,404,{error:'البلدية غير موجودة'});const fee=b.deliveryFee===null?null:Number(b.deliveryFee),mins=b.estimatedMinutes===null?null:Number(b.estimatedMinutes);if(fee!==null&&(!Number.isFinite(fee)||fee<0||fee>10000))return send(res,400,{error:'رسوم التوصيل غير صالحة'});if(mins!==null&&(!Number.isInteger(mins)||mins<5||mins>600))return send(res,400,{error:'المدة غير صالحة'});z.deliveryFee=fee;z.estimatedMinutes=mins;z.enabled=b.enabled!==false;await write(ZONES,zones);return send(res,200,{ok:true,zone:z})}catch(e){return send(res,400,{error:e.message})}}
  if(req.method==='PATCH'&&url.pathname.startsWith('/api/admin/orders/')){try{const id=decodeURIComponent(url.pathname.split('/').pop()),b=await getBody(req),allowed=['new','confirmed','preparing','on_the_way','delivered','cancelled'];if(!allowed.includes(b.status))return send(res,400,{error:'حالة غير صالحة'});const orders=read(ORDERS,[]),o=orders.find(x=>x.id===id);if(!o)return send(res,404,{error:'الطلب غير موجود'});o.status=b.status;await write(ORDERS,orders);return send(res,200,{ok:true})}catch(e){return send(res,400,{error:e.message})}}
  return send(res,404,{error:'مسار إدارة غير موجود'});
 }
 if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html'||url.pathname==='/admin'||url.pathname==='/merchant')){const f=url.pathname==='/admin'?'admin.html':url.pathname==='/merchant'?'merchant.html':'index.html';securityHeaders(res);res.setHeader('Cache-Control','no-store');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return fs.createReadStream(path.join(PUBLIC,f)).pipe(res)}
 if(req.method==='GET'&&url.pathname.startsWith('/')){const target=path.resolve(PUBLIC,'.'+decodeURIComponent(url.pathname));if(!target.startsWith(PUBLIC+path.sep))return send(res,403,{error:'ممنوع'});fs.readFile(target,(e,d)=>{if(e){securityHeaders(res);res.writeHead(404);return res.end('Not found')}securityHeaders(res);res.setHeader('Cache-Control','no-cache');res.writeHead(200,{'Content-Type':MIME[path.extname(target)]||'application/octet-stream'});res.end(d)});return}
 send(res,404,{error:'المسار غير موجود'});
 } catch(err){console.error('Request failed:',err);if(!res.headersSent)send(res,500,{error:'حدث خطأ داخلي. حاول لاحقاً'});}
});
async function boot(){if(process.env.NODE_ENV==='production'&&!ADMIN_KEY)throw Error('ADMIN_KEY is required in production');if(process.env.NODE_ENV==='production'&&!DATABASE_URL)throw Error('DATABASE_URL is required in production');if(DATABASE_URL){const {Pool}=require('pg');pool=new Pool({connectionString:DATABASE_URL,ssl:process.env.PGSSLMODE==='disable'?false:{rejectUnauthorized:false},max:10,idleTimeoutMillis:30000,connectionTimeoutMillis:10000});await pool.query('CREATE TABLE IF NOT EXISTS tawsila_state(state_key TEXT PRIMARY KEY,state_value JSONB NOT NULL,updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())')}await initStorage();server.listen(PORT,'0.0.0.0',()=>console.log(`Tawsila running on port ${PORT}`));}
boot().catch(err=>{console.error('Startup failed:',err);process.exit(1)});
