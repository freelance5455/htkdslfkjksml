package com.yarlphoenix.accounts;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.webkit.*;import android.Manifest;import android.content.pm.PackageManager;import android.graphics.Color;
public class MainActivity extends Activity{
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(Color.BLACK);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setMediaPlaybackRequiresUserGesture(false);w.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){runOnUiThread(()->r.grant(r.getResources()));}});w.addJavascriptInterface(new Bridge(),"Android");setContentView(w);if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},50);w.loadUrl("file:///android_asset/index.html");}
 class Bridge{@JavascriptInterface public void dial(String n){Intent i=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+n));startActivity(i);}}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
