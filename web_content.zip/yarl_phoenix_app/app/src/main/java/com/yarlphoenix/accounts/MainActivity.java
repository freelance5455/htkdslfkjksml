package com.yarlphoenix.accounts;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.print.PrintAttributes;
import android.print.PrintManager;

public class MainActivity extends Activity {
    WebView w;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        w = new WebView(this);
        w.setBackgroundColor(Color.BLACK);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        w.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest r) {
                runOnUiThread(() -> r.grant(r.getResources()));
            }
        });
        w.addJavascriptInterface(new Bridge(), "Android");
        setContentView(w);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 50);
        w.loadUrl("file:///android_asset/index.html");
    }

    class Bridge {
        @JavascriptInterface public void dial(String n) {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + n)));
        }
        @JavascriptInterface public void shareText(String subject, String body) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            i.putExtra(Intent.EXTRA_TEXT, body);
            startActivity(Intent.createChooser(i, "பகிரவும்"));
        }
        @JavascriptInterface public void emailText(String subject, String body) {
            Intent i = new Intent(Intent.ACTION_SENDTO);
            i.setData(Uri.parse("mailto:"));
            i.putExtra(Intent.EXTRA_SUBJECT, subject);
            i.putExtra(Intent.EXTRA_TEXT, body);
            startActivity(i);
        }
        @JavascriptInterface public void whatsappText(String body) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, body);
            i.setPackage("com.whatsapp");
            try { startActivity(i); }
            catch (Exception e) { shareText("Yarl Phoenix Accounts Summary", body); }
        }
        @JavascriptInterface public void printPage(String jobName) {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                pm.print(jobName, w.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
            });
        }
    }

    @Override public void onBackPressed() {
        if (w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
