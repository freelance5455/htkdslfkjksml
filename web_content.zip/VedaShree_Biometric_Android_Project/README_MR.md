# वेदश्री — Offline Native Biometric Android wrapper

## काय तयार केले आहे
- अपलोड केलेली HTML फाइल `app/src/main/assets/www/index.html` मध्ये byte-for-byte कॉपी केली आहे.
- Android `BiometricPrompt` द्वारे `BIOMETRIC_STRONG` पडताळणी.
- यशस्वी पडताळणीपूर्वी WebView लपवलेला राहतो.
- अॅप पार्श्वभूमीत गेल्यावर पुढील foreground प्रवेशासाठी पुन्हा पडताळणी मागितली जाते.
- नेटवर्क permission दिलेली नाही; पॅकेज केलेली HTML फाइल ऑफलाइन उघडते.
- HTML गणना इंजिनमध्ये कोणताही बदल केलेला नाही.

## तयार APK आहे का?
नाही. हा Android Studio मध्ये उघडता येणारा **source project** आहे; APK तयार किंवा device-test केलेली नाही. या कार्यक्षेत्रात Android SDK/Gradle उपलब्ध नसल्यामुळे APK compile/verify करता आलेली नाही.

## बिल्ड करण्याची पद्धत
1. Android Studio मध्ये हा project folder उघडा.
2. Android SDK Platform 35 आणि JDK 17 उपलब्ध ठेवा.
3. Gradle sync पूर्ण होऊ द्या.
4. `Build > Build APK(s)` चालवा.
5. प्रत्यक्ष Android फोनवर fingerprint नोंदवून खालील चाचण्या करा.

## आवश्यक चाचण्या
- Fingerprint enrolled: app opens only after success.
- Wrong fingerprint / cancel: Panchang remains hidden.
- App background/foreground: authentication requested again.
- No fingerprint enrolled: setup message shown.
- Airplane mode: local Panchang loads.
- Rotate screen / reopen app: no calculation changes.

## सुरक्षा मर्यादा
- `BIOMETRIC_STRONG` वापरले आहे; Android च्या मते हा fingerprint किंवा इतर Class 3 biometrics असू शकतो. हा कोड “फक्त fingerprint hardware” ची हमी देत नाही.
- हा wrapper सामान्य वापरातील प्रवेश रोखतो; rooted/compromised device किंवा repackaged APK विरुद्ध संपूर्ण tamper-proof संरक्षणाची हमी नाही.
- HTML मध्ये आधीपासून बाह्य Google Fonts stylesheet आहे; नेटवर्क permission नसल्याने फॉन्ट डाउनलोड होणार नाही. बाकीचा स्थानिक HTML/data URI मजकूर पॅकेजमध्येच आहे.
- `INTERNET` permission नाही. कोणतीही ऑनलाइन सुविधा या wrapper मध्ये चालणार नाही.

## मूळ HTML अखंडता
`SHA-256` खाली दिलेला आहे. HTML asset आणि मूळ अपलोड यांचे hashes जुळणे अपेक्षित आहे.

- Original upload SHA-256: `6446ae27bf7422ccd8c94e1d20579e38a065658b6d21a8e69adbc198e1fe470b`
- Packaged asset SHA-256: `6446ae27bf7422ccd8c94e1d20579e38a065658b6d21a8e69adbc198e1fe470b`
