package in.vedashree.biometric

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : FragmentActivity() {
    private lateinit var webView: WebView
    private lateinit var gate: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var assetLoader: WebViewAssetLoader
    private var authenticating = false
    private var unlocked = false
    private var prompt: BiometricPrompt? = null

    private val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(android.graphics.Color.rgb(59, 6, 18))
        }

        gate = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(android.graphics.Color.rgb(59, 6, 18))
        }

        val title = TextView(this).apply {
            text = "🔐  वेदश्री वैदिक पंचांग"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(255, 200, 61))
        }
        statusText = TextView(this).apply {
            text = "पंचांग उघडण्यासाठी फिंगरप्रिंट पडताळणी आवश्यक आहे."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.rgb(255, 233, 176))
            setPadding(0, 24, 0, 24)
        }
        val retry = Button(this).apply {
            text = "फिंगरप्रिंट पुन्हा तपासा"
            setOnClickListener { authenticate() }
        }
        val settings = Button(this).apply {
            text = "फोनच्या सुरक्षा सेटिंग्ज"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "कृपया फोनच्या Settings मध्ये स्क्रीन लॉक/फिंगरप्रिंट सेट करा.", Toast.LENGTH_LONG).show()
                }
            }
        }
        gate.addView(title, matchWrap())
        gate.addView(statusText, matchWrap())
        gate.addView(retry, matchWrap())
        gate.addView(settings, matchWrap())

        webView = WebView(this).apply {
            visibility = View.GONE
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val url = request?.url ?: return null
                    return assetLoader.shouldInterceptRequest(url)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    // Only permit the packaged local app origin. Do not navigate out to websites.
                    return request.url.host != "appassets.androidplatform.net"
                }

                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    if (url == null) return true
                    return Uri.parse(url).host != "appassets.androidplatform.net"
                }
            }
            loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        }

        root.addView(gate, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlocked = true
                    gate.visibility = View.GONE
                    webView.visibility = View.VISIBLE
                }

                override fun onAuthenticationFailed() {
                    statusText.text = "फिंगरप्रिंट जुळला नाही. पुन्हा प्रयत्न करा."
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                    unlocked = false
                    webView.visibility = View.GONE
                    gate.visibility = View.VISIBLE
                    statusText.text = "पडताळणी झाली नाही: $errString"
                    if (errorCode == BiometricPrompt.ERROR_NO_BIOMETRICS ||
                        errorCode == BiometricPrompt.ERROR_HW_NOT_PRESENT ||
                        errorCode == BiometricPrompt.ERROR_HW_UNAVAILABLE) {
                        showBiometricSetupMessage()
                    }
                }
            }
        )
    }

    override fun onResume() {
        super.onResume()
        if (!authenticating) {
            unlocked = false
            webView.visibility = View.GONE
            gate.visibility = View.VISIBLE
            authenticate()
        }
    }

    override fun onPause() {
        // Hide the Panchang whenever the app leaves the foreground.
        // Do not cancel an in-flight system biometric prompt.
        if (!authenticating) {
            unlocked = false
            if (::webView.isInitialized) webView.visibility = View.GONE
            if (::gate.isInitialized) gate.visibility = View.VISIBLE
        }
        super.onPause()
    }

    private fun authenticate() {
        if (authenticating) return
        val manager = BiometricManager.from(this)
        when (manager.canAuthenticate(authenticators)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                authenticating = true
                statusText.text = "फिंगरप्रिंट पडताळणी सुरू आहे…"
                val info = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("वेदश्री वैदिक पंचांग")
                    .setSubtitle("पंचांग उघडण्यासाठी फिंगरप्रिंट वापरा")
                    .setDescription("तुमच्या फोनवर नोंदवलेला मजबूत बायोमेट्रिक आवश्यक आहे.")
                    .setAllowedAuthenticators(authenticators)
                    .setNegativeButtonText("रद्द करा")
                    .build()
                prompt?.authenticate(info)
            }
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                statusText.text = "फोनमध्ये फिंगरप्रिंट नोंदवलेला नाही. Settings मध्ये फिंगरप्रिंट सेट करा."
                showBiometricSetupMessage()
            }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
                statusText.text = "या फोनमध्ये समर्थित बायोमेट्रिक हार्डवेअर उपलब्ध नाही."
            else ->
                statusText.text = "फिंगरप्रिंट उपलब्ध नाही. फोनचे लॉक/सेन्सर तपासा आणि पुन्हा प्रयत्न करा."
        }
    }

    private fun showBiometricSetupMessage() {
        if (isFinishing) return
        AlertDialog.Builder(this)
            .setTitle("फिंगरप्रिंट सेटअप आवश्यक")
            .setMessage("वेदश्री उघडण्यासाठी फोनमध्ये समर्थित फिंगरप्रिंट नोंदवलेला असणे आवश्यक आहे. फोनच्या सुरक्षा सेटिंग्जमध्ये तो सेट करून पुन्हा प्रयत्न करा.")
            .setPositiveButton("सेटिंग्ज") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                } catch (_: Exception) { }
            }
            .setNegativeButton("बंद", null)
            .show()
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}
