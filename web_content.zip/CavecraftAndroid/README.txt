Cavecraft Android
=================

Projeto Android que empacota o arquivo Cavecraft.html em um WebView fullscreen.

Requisitos:
- Android Studio recente
- JDK 17
- Internet na primeira compilação para baixar dependências do Gradle

Como compilar:
1. Abra esta pasta no Android Studio.
2. Espere o Gradle sincronizar.
3. Use Build > Build APK(s).
4. O APK de debug será gerado em:
   app/build/outputs/apk/debug/app-debug.apk

O HTML original está em:
app/src/main/assets/Cavecraft.html

Observação:
O HTML usa Three.js por CDN, então o jogo precisa de internet para carregar a biblioteca quando for aberto.
