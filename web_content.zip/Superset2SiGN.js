/**
 * A comprehensive map to convert Superset ENG notation moves to SiGN notation.
 * @constant
 * @type {Map<string, string>}
 */
const supersetToSiGNMap = new Map([
    // Basic face turns
    ['R', 'R'], ['R\'', 'R\''], ['R2', 'R2'],
    ['L', 'L'], ['L\'', 'L\''], ['L2', 'L2'],
    ['U', 'U'], ['U\'', 'U\''], ['U2', 'U2'],
    ['D', 'D'], ['D\'', 'D\''], ['D2', 'D2'],
    ['F', 'F'], ['F\'', 'F\''], ['F2', 'F2'],
    ['B', 'B'], ['B\'', 'B\''], ['B2', 'B2'],

    // Wide moves (e.g., r, u)
    ['r', 'r'], ['r\'', 'r\''], ['r2', 'r2'],
    ['l', 'l'], ['l\'', 'l\''], ['l2', 'l2'],
    ['u', 'u'], ['u\'', 'u\''], ['u2', 'u2'],
    ['d', 'd'], ['d\'', 'd\''], ['d2', 'd2'],
    ['f', 'f'], ['f\'', 'f\''], ['f2', 'f2'],
    ['b', 'b'], ['b\'', 'b\''], ['b2', 'b2'],

    // Tier turns (Wide moves on 3x3)
    ['TR', 'r'], ['TR\'', 'r\''], ['TR2', 'r2'],
    ['TL', 'l'], ['TL\'', 'l\''], ['TL2', 'l2'],
    ['TU', 'u'], ['TU\'', 'u\''], ['TU2', 'u2'],
    ['TD', 'd'], ['TD\'', 'd\''], ['TD2', 'd2'],
    ['TF', 'f'], ['TF\'', 'f\''], ['TF2', 'f2'],
    ['TB', 'b'], ['TB\'', 'b\''], ['TB2', 'b2'],

    // Slice moves
    // M move: M is equivalent to L r' (left face turn, inner right turn) or r' L.
    // However, in SiGN, the 'M' notation is sometimes used. This provides a direct mapping.
    // If a literal translation to slice moves (e.g., r' L) is needed, this part can be expanded.
    ['M', 'M'], ['M\'', 'M\''], ['M2', 'M2'],
    ['E', 'E'], ['E\'', 'E\''], ['E2', 'E2'],
    ['S', 'S'], ['S\'', 'S\''], ['S2', 'S2'],

    // Full cube rotations
    ['x', 'x'], ['x\'', 'x\''], ['x2', 'x2'],
    ['y', 'y'], ['y\'', 'y\''], ['y2', 'y2'],
    ['z', 'z'], ['z\'', 'z\''], ['z2', 'z2'],
]);

/**
 * Converts a Rubik's cube algorithm from Superset ENG notation to SiGN notation.
 *
 * @param {string} supersetEngAlgorithm The algorithm string in Superset ENG notation.
 * @returns {string} The converted algorithm string in SiGN notation.
 * @throws {Error} If an unrecognized move is found in the input.
 */
function convertSupersetEngToSiGN(supersetEngAlgorithm) {
    if (!supersetEngAlgorithm) {
        return '';
    }

    // Split the algorithm into individual moves, considering a move is a letter followed by optional ' or 2.
    const moves = supersetEngAlgorithm.trim().split(/\s+/);
    const convertedMoves = [];

    for (const move of moves) {
        const siGNMove = supersetToSiGNMap.get(move);
        if (siGNMove !== undefined) {
            convertedMoves.push(siGNMove);
        } else {
            // Handle more complex patterns or throw an error for unsupported moves.
            throw new Error(`Unrecognized move: ${move}`);
        }
    }

    return convertedMoves.join(' ');
}

// --- Example usage ---

// An example algorithm with various move types
const supersetEngAlgorithm = "R U R' U' TR U2 TR' M E' S2 x y' z2";

try {
    const siGNAlgorithm = convertSupersetEngToSiGN(supersetEngAlgorithm);
    console.log("Superset ENG:", supersetEngAlgorithm);
    console.log("SiGN:", siGNAlgorithm);
} catch (e) {
    console.error(e.message);
}
