PRATIBIMB CRAFTS - ANDROID FILE PICKER FIX SOURCE PROJECT

Why the old APK's Choose Files button did nothing:
The HTML file input normally asks the Android WebView host to open a native file chooser. Many simple HTML-to-APK makers do not implement WebChromeClient.onShowFileChooser, so tapping the file input appears to do nothing. HTML changes alone cannot reliably fix a missing native WebView file-picker handler.

This Android Studio project includes that native handler. It opens Android's document picker, accepts multiple PDF files, and returns the selected files to the HTML app.

Build:
1. Extract this ZIP on a computer.
2. Open this folder in Android Studio (Open, select this folder).
3. Install Android SDK Platform 35 if prompted and allow Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on the phone. Test Step 1 by selecting one or more PDF files.

Important:
- This is source code, not a precompiled APK; it has not been compiled or device-tested in this environment.
- PDF.js and SheetJS are loaded from public CDNs by the HTML page, so an internet connection is needed when the app loads those libraries.
- Android system file picker grants access to the PDFs selected by the user. The app does not upload the PDFs.
- If you must continue using the same third-party HTML-to-APK maker, its own WebView must support the HTML file chooser. If it does not, the maker must add a native onShowFileChooser handler or you must use a wrapper that supports file picking.
