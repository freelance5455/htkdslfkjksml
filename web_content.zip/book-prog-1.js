/* JOSTECH — CHAPITRE COMPLET FORMAT LIVRE : PROG-1-1-1 */
registerLessonDetail(2, 1, "prog-1-1-1", {
  title: "Leçon 1 : Algorithmique, Variables, Types et Structures de Contrôle",
  duration: "50 min (Manuel universitaire complet)",
  objectives: [
    "Distinguer rigoureusement l'algorithme (modèle mathématique) du programme (traduction dans un langage).",
    "Comprendre la représentation des types primitifs en mémoire et le piège des nombres flottants.",
    "Maîtriser les opérateurs arithmétiques (notamment // et %), logiques et l'affectation.",
    "Appliquer le théorème de Böhm-Jacopini : Séquence, Sélection (if/elif/else) et Itération (for vs while)."
  ],
  prerequisites: ["Notions de RAM et système binaire (Discipline 01)."],
  sections: [
    {
      type: "definition",
      term: "Algorithme vs Programme",
      text: "Le mot « algorithme » vient du nom du mathématicien perse du IXe siècle Muhammad ibn Musa al-Khwârizmî. En informatique, un algorithme est une méthode abstraite, finie et non ambiguë permettant de résoudre une classe de problèmes à partir de données d'entrée.\n\nPour être scientifiquement valide, un algorithme doit posséder quatre propriétés :\n1) Finitude : il se termine toujours après un nombre fini d'étapes.\n2) Déterminisme : à chaque étape, l'action suivante est unique et sans ambiguïté.\n3) Effectivité : chaque opération est suffisamment élémentaire pour être exécutée mécaniquement.\n4) Généralité : il fonctionne pour n'importe quelle donnée d'entrée valide (pas un seul cas particulier).\n\nUn « programme » est ensuite la traduction concrète de cet algorithme dans la syntaxe d'un langage précis (Python, C, Java, JavaScript)."
    },
    {
      type: "theory",
      title: "1. Variables, Typage en RAM et Précision Flottante",
      text: "Dans un programme, une variable associe un identifiant lisible par l'humain (ex. moyenne_generale) à une zone de mémoire RAM contenant une valeur modifiable. Chaque valeur possède un « type » qui dicte la place occupée en octets et les opérations permises.",
      bullets: [
        "Entier (int) : nombres entiers positifs ou négatifs sans virgule (ex: 42, -10). En Python, leur taille est illimitée.",
        "Flottant (float) : nombres réels approchés selon la norme binaire IEEE 754 (ex: 15.75). Attention : certains nombres décimaux simples comme 0.1 n'ont pas d'écriture finie en binaire (tout comme 1/3 = 0.333... en décimal). Conséquence célèbre : en Python ou JS, 0.1 + 0.2 vaut 0.30000000000000004 !",
        "Chaîne de caractères (str) : suite ordonnée de caractères Unicode placée entre guillemets ('JOSTECH').",
        "Booléen (bool) : issu de l'algèbre de Boole, ne vaut que True (1) ou False (0)."
      ]
    },
    {
      type: "table",
      title: "2. Opérateurs essentiels et piège de l'affectation",
      headers: ["Symbole", "Signification", "Exemple et résultat"],
      rows: [
        ["=", "Affectation (range droite dans gauche)", "x = 5  (x reçoit 5)  |  x = x + 1 (x devient 6)"],
        ["==  et  !=", "Comparaison : égal à / différent de", "5 == 5 → True  |  5 != 3 → True"],
        ["/", "Division réelle (donne toujours un float)", "7 / 2 → 3.5"],
        ["//", "Division entière (quotient euclidien)", "7 // 2 → 3"],
        ["%", "Modulo (reste de la division euclidienne)", "7 % 2 → 1  (utile pour tester pair/impair !)"],
        ["**", "Puissance", "2 ** 10 → 1024"]
      ]
    },
    {
      type: "theory",
      title: "3. L'algorithme d'échange de deux variables et Böhm-Jacopini",
      text: "Supposons que A = 10 et B = 20, et que l'on veuille échanger leurs contenus. Écrire « A = B » puis « B = A » est FAUX, car la première ligne écrase 10 par 20 : les deux variables vaudront 20 ! Il faut obligatoirement utiliser une troisième variable temporaire : temp = A ; A = B ; B = temp (exactement comme transvaser deux verres de liquide à l'aide d'un troisième verre vide).\n\nEn 1966, Corrado Böhm et Giuseppe Jacopini démontrent un théorème fondamental : tout algorithme calculable peut s'écrire en combinant uniquement trois structures de contrôle : la Séquence (ligne après ligne), la Sélection (if/elif/else) et l'Itération (for/while)."
    },
    {
      type: "code",
      lang: "Python — Programme complet : Délibération universitaire",
      code: [
        "# Calcul de moyenne, validation et recherche du maximum",
        "etudiant = 'Mivumbi'",
        "notes = [14.5, 16.0, 9.5, 18.0, 12.0]",
        "",
        "somme = 0.0",
        "note_max = notes[0]  # On initialise le max avec le 1er élément",
        "",
        "for n in notes:",
        "    somme = somme + n",
        "    if n > note_max:",
        "        note_max = n",
        "",
        "moyenne = somme / len(notes)",
        "print(f'Étudiant : {etudiant} | Moyenne : {moyenne:.2f}/20 | Max : {note_max}')",
        "",
        "if moyenne >= 16:",
        "    mention = 'Très Bien'",
        "elif moyenne >= 14:",
        "    mention = 'Bien'",
        "elif moyenne >= 10:",
        "    mention = 'Admis (Passable / Assez Bien)'",
        "else:",
        "    mention = 'Ajourné (Rattrapage)'",
        "",
        "print('Décision :', mention)"
      ].join("\n")
    },
    {
      type: "example",
      title: "Choisir rigoureusement entre FOR et WHILE",
      text: "Utilisez la boucle FOR lorsque le nombre de tours est connu ou borné par une collection (ex. parcourir 30 étudiants). Utilisez la boucle WHILE (Tant que) lorsque la condition d'arrêt dépend d'un événement dynamique imprévisible : par exemple, demander un mot de passe TANT QUE l'utilisateur se trompe (avec un compteur max de 3 essais pour éviter la boucle infinie)."
    },
    {
      type: "warning",
      title: "Pièges fréquents des débutants",
      text: "1) Erreur Off-by-one (décalage d'un rang) : en Python, range(1, 5) génère 1, 2, 3, 4 (la borne de fin 5 est toujours exclue !).\n2) Boucle infinie avec WHILE : si vous écrivez « i = 1 ; while i <= 5: print(i) » en oubliant « i = i + 1 », le programme tourne à l'infini et bloque votre onglet.\n3) Mélanger les types : input() renvoie toujours du texte (str). Il faut convertir avec int(input()) ou float(input()) avant de faire des additions !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Trace manuelle d'exécution (Tableau d'état)",
      question: "Tracez la valeur exacte des variables a, b et s après chaque tour de boucle :\na = 1 ; b = 2 ; s = 0\nfor k in range(1, 4):\n    s = s + (a * b)\n    a = a + 1\n    b = b + 2\nQue valent a, b et s à la fin ?",
      solution: "range(1, 4) prend k = 1, 2, 3 :\n• Tour k=1 : s = 0 + (1×2) = 2 ; a = 2 ; b = 4.\n• Tour k=2 : s = 2 + (2×4) = 10 ; a = 3 ; b = 6.\n• Tour k=3 : s = 10 + (3×6) = 28 ; a = 4 ; b = 8.\nValeurs finales : a = 4, b = 8, s = 28."
    },
    {
      title: "Exercice 2 — Logique du Modulo (%) : Année bissextile",
      question: "Une année A est bissextile si elle est divisible par 4 ET non divisible par 100, OU si elle est divisible par 400. Écrivez en Python la condition booléenne complète qui teste si une variable annee est bissextile, et testez-la mentalement pour 2024 et 1900.",
      solution: "Condition Python :\nbissextile = (annee % 4 == 0 and annee % 100 != 0) or (annee % 400 == 0)\n• Pour 2024 : 2024 % 4 == 0 (Vrai) et 2024 % 100 != 0 (Vrai) → True (bissextile).\n• Pour 1900 : 1900 % 100 == 0 (donc 1re partie Fausse) et 1900 % 400 != 0 (2e partie Fausse) → False (non bissextile)."
    },
    {
      title: "Exercice 3 — Boucle WHILE avec sentinelle",
      question: "Écrivez un algorithme en Python qui lit des notes saisies par un enseignant jusqu'à ce qu'il tape -1 (valeur sentinelle d'arrêt), puis affiche le nombre de notes saisies et leur moyenne.",
      solution: "somme = 0.0\ncompteur = 0\nnote = float(input('Note (-1 pour finir) : '))\nwhile note != -1:\n    somme = somme + note\n    compteur = compteur + 1\n    note = float(input('Note (-1 pour finir) : '))\nif compteur > 0:\n    print('Nombre :', compteur, '| Moyenne :', somme / compteur)\nelse:\n    print('Aucune note saisie.')"
    }
  ],
  summary: "Tout algorithme valide repose sur la finitude, le déterminisme, l'effectivité et la généralité. En combinant variables typées, opérateurs (dont // et %) et les trois structures de Böhm-Jacopini (séquence, sélection, itération), on peut modéliser et résoudre n'importe quel problème calculable.",
  references: [
    "Cormen, T. et al. — Algorithmique (3e éd.), Dunod.",
    "Knuth, D. E. — The Art of Computer Programming, Vol. 1: Fundamental Algorithms.",
    "Swinnen, G. — Apprendre à programmer avec Python 3, Eyrolles."
  ]
});