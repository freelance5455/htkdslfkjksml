PHYSICS AI V4 - SMART OFFLINE FINAL PACKAGE

What is new:
- Offline reasoning layer that matches questions by meaning, keywords, topic descriptions, synonyms and approximate spelling.
- Common physics spelling mistakes are normalized before matching.
- Long natural-language descriptions can match several related physics concepts.
- Answers include a likely interpretation, current description, answer/explanation, key relationship, units and related concepts.
- Project Builder uses the same fuzzy matching to understand project descriptions and combine relevant physics knowledge.
- Library search also accepts approximate wording and spelling.
- Existing solver, converter, online research and full project builder are retained.

This is still a lightweight browser-based application. The offline reasoning is a rule-based knowledge synthesis system, not a large cloud AI model. Internet research remains optional.

Main files:
- index.html
- style.css
- physics-data.js
- app.js

PC:
- Open index.html, or use Launch_PhysicsAI.bat.
- For local-server mode, use Launch_Server.bat and open http://127.0.0.1:8000.
