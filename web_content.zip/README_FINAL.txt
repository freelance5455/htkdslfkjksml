VAISHNAV WORLD — PROFESSIONAL BLUE ACODE BUILD

Included:
- Devotee app: web/index.html
- Admin app: web/admin/index.html
- Firebase Realtime Database + Firebase Authentication
- Professional blue responsive UI
- Splash + name/mobile demo-code login
- Persistent account by mobile (hidden Firebase email/password credential)
- Japa 108-bead counter + history
- Sadhana Log + Statistics
- Weekly Challenge + points + combined leaderboard
- Courses + day-wise YouTube links + progress
- Hindi and Bengali daily quizzes, 10 questions, 59 sec/question, 3-2-1-START, combined leaderboard
- Vrindavan Yatra: multiple members in one application; each member can later log in with their own mobile and see their own status/seat/ticket link
- Katha/articles, calendar, YouTube, books, Prabhupada Today
- Daily Darshan with optional external image URL, share/comment
- Normal in-app notifications only
- Poster section removed
- No Firebase Storage/photo upload dependency
- No phone notification-bar / FCM system

IMPORTANT SETUP:
1. In Firebase Console enable Authentication > Sign-in method > Email/Password.
2. Create/use the Realtime Database and deploy firebase-rules.json.
3. Open web/index.html in Acode/your WebView wrapper.
4. Admin password in this prototype is 2011.
5. The admin password is client-side for prototype use; it is NOT secure production authentication.
6. The hidden account credential is a prototype convenience. For a public production app, replace it with a proper secure authentication/backend authorization design.
7. Daily Darshan uses an image URL instead of Firebase Storage upload.
8. This build intentionally has NO phone notification bar/FCM.


LOGIN FIX (DEVOTEE)
The Devotee login uses Firebase Anonymous Authentication plus a local demo 6-digit code.
The 6-digit code is NOT sent to Firebase as an AuthCredential, email password, phone OTP, or custom token.
Before testing, enable Firebase Console -> Authentication -> Sign-in method -> Anonymous.
The code is only a local demo verification step; it does not verify ownership of the mobile number.
