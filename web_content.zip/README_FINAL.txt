VAISHNAV WORLD — FINAL ENHANCED PROJECT

This project preserves the existing Devotee/Admin web app and packages it for an Android WebView + native Firebase Cloud Messaging setup.

FINAL FEATURES
- Existing Japa, Sadhana, Statistics, Challenge, Courses, Katha/Articles, Calendar, YouTube, Books, Prabhupada Today, Notifications and Admin publishing retained.
- No Yatra module added.
- No Gita reading module added to the Devotee app.
- No Firebase Storage dependency for Devotee content. Image upload remains limited to the existing Admin Daily Darshan workflow.
- Add Member: separate profile/data for You, Son, Daughter, Wife, Husband, Father, Mother, Brother, Sister or Other.
- App asks “Who is using the app?” and stores feature data by member.
- Daily Quiz: one completed attempt per member per calendar day; next day unlocks. Result shows selected language, score, correct/wrong and question-by-question answer review.
- Daily Shlok: the Devotee app reads exactly the shloka published by Admin at shlokaReading/YYYY-MM-DD. No hard-coded shlok list is used. After completion it stays locked until the next calendar day. Total reading days and streak are shown.
- Infinite XP levels: every 250 XP advances a level; levels continue beyond the named initial levels.
- Points: quiz score, japa mala, daily japa goal, shlok reading, course lessons and challenge tasks award XP/points through one-time point events.
- Japa daily goal: set today’s mala target; tomorrow has a new daily target.
- Monthly leaderboard: current month’s combined points are stored under monthlyLeaderboard/YYYY-MM and displayed highest-to-lowest.
- Admin publishing actions create notification records and pushQueue entries.
- Native Android FCM token registration and PushService included.
- Firebase Android package is com.bhaktiverse.app and google-services.json is included for that registered package.

FCM DEPLOYMENT
1. Build/install the Android project with Android Studio or a machine with Gradle/Android SDK.
2. Deploy the functions/ folder to the same Firebase project.
3. Deploy firebase-rules.json to Realtime Database.
4. The Android app registers its FCM token in Realtime Database. Admin publishes to pushQueue through its normal publishing actions. The Cloud Function sends FCM notifications.
5. Android 13+ notification permission is requested by the app.

IMPORTANT
- This environment does not contain Gradle/Android SDK, so the .apk binary was not compiled here. The Android project is configured and checked for JavaScript/JSON/build-file consistency.
