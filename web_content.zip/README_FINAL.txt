VAISHNAV WORLD — MERGED ADMIN + DEVOTEE + FCM PACKAGE

Base:
- Devotee app: previous Enhanced Members + Infinite Level + FCM build.
- Admin app: Vaishnav_World_Admin_Password_2011_No_Email_Final.
- Admin password remains: 2011. No email login added.
- Existing Admin sections are retained: Dashboard, Devotees, Yatra, Quiz Manager, Courses, Challenge, Katha/Articles, Calendar, YouTube, Book Store, Prabhupada Today, Notifications.
- Added missing publishing controls: Daily Darshan and Shlok Reading Challenge.
- Daily Darshan is the only Admin image-upload field. The image is stored as compressed data in Realtime Database; Firebase Storage is not required.
- Shlok Reading publishes date-keyed content at shlokaReading/YYYY-MM-DD so the Devotee app shows the matching day's shlok.
- Every Admin publish that creates an in-app notification also creates pushQueue/{id}; the included Firebase Cloud Function sends FCM to registered Android tokens.
- Devotee Android package: com.bhaktiverse.app and the provided google-services.json is included.

IMPORTANT FIREBASE STEPS:
1. In Firebase Realtime Database, deploy firebase-rules.json if you want this exact password-only Admin web app to read/write the shared data. These rules are development/open rules; they are NOT suitable for a public production database.
2. Deploy the functions/ folder to Firebase so sendPushFromQueue is active.
3. Build the Android project in android-app. Android 13+ notification permission is requested by the included app.
4. The Android app registers its FCM token under fcmTokens and the Cloud Function sends notifications from pushQueue.
5. Web Push/VAPID is not needed for the APK's native FCM notification path.

No claim is made that an APK binary was compiled here; this package contains the Android source/project and Firebase/FCM wiring.


FINAL FCM SETUP
1. Devotee Android app registers its FCM token under Realtime Database: fcmTokens/<encoded-token>.
2. Admin publish actions create an in-app notification and a pushQueue item.
3. Firebase Cloud Function functions/index.js listens to /pushQueue/{id} and sends FCM multicast notifications.
4. Deploy functions from the functions folder with Firebase CLI: firebase deploy --only functions.
5. Cloud Functions deployment may require a Firebase billing/Blaze plan depending on the Firebase account/project.
6. Android 13+ asks the user for notification permission. The user must allow notifications.
7. The supplied VAPID public key is for Web Push; native Android FCM uses google-services.json and does not require VAPID.
8. This source ZIP is not a compiled APK; build the devotee Android project and the separate admin-android-app project.


FCM/Darshan/Shlok/Birthday update: FCM token is saved to fcmTokens, admin Daily Darshan file chooser is enabled in Android WebView, Shlok supports Hindi/Bengali tabs and required user summary, login/member DOB is stored, birthday card and scheduled birthday push queue are included. Cloud Functions must be deployed for automatic server-side pushes/scheduled birthdays.


PATCHED BUILD NOTES — 30 Sep 2026
1. Daily Darshan has been removed from the devotee Home and Admin menus. Old Firebase dailyDarshan data is not deleted.
2. Yatra management/menu has been removed from Admin as well.
3. Japa Goal: fixed persistence. The selected 1–108 mala goal is merged from Firebase back into local state, so it remains after reload/app restart.
4. Japa XP: +10 XP per completed 108-bead mala and +20 XP once the daily goal is reached. XP updates the member level and monthly leaderboard.
5. Japa graph: date-wise actual japa is shown as one blue line. Each point uses the member's recorded beads; more japa rises, less japa falls. Last 30 recorded dates are shown.
6. Sadhana completion: +10 XP once per day when today's Sadhana is saved. Re-saving the same day does not award another Sadhana XP event.
7. Quiz completion: existing scoring awards +1 XP per correct answer and updates level/monthly leaderboard.
8. Shlok Reading Challenge: Hindi and Bengali choices are separate. The devotee sees the meaning for the selected language only; admin publishes both Hindi and Bengali fields. Completion gives +15 XP once per day and requires a written summary.
9. Weekly challenge tasks keep their configured XP values and are added to the same member XP/monthly leaderboard.
10. Native Android FCM token is stored at /fcmTokens and refreshed on token changes. Admin notification writes go to /pushQueue; the included Cloud Function sends notification messages to registered Android devices.
11. firebase.json and .firebaserc are included for the Firebase Functions source. Cloud Functions still must be deployed to the Firebase project before automatic Admin→phone push works. FCM delivery also requires the Android app to have notification permission enabled on Android 13+.
12. The source has not been compiled into an APK in this environment, so this ZIP should be treated as the patched source/build project, not as a verified APK.


PRO FEATURES ADDED (DEVOTEE APP)
- Achievement badge milestones for Japa, Quiz, Shlok, Sadhana and challenge days; each badge awards +5 XP once.
- Monthly calendar marks days with recorded devotional activity.
- Yearly personal summary with month-by-month Japa, Quiz, Shlok and Sadhana counts.
- Today's Japa, Quiz, Sadhana and Shlok leaderboards (based on records available in Realtime Database).
- 30-Day Bhakti Challenge tracker, one completion per day, +10 XP per day; per-member storage.
- These are source updates; build and test in Acode/WebView APK Maker and verify Firebase rules/data paths before release.


LATEST UPDATE: Meditation BGM gain increased approximately 2x (master gain 0.12 -> 0.24 and bell-note peak 0.055 -> 0.11); added today's Japa leaderboard card in the Japa section. Source changes mirrored into Android WebView assets. APK/device audio and Firebase leaderboard behavior still require on-device testing.
