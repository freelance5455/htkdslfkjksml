VAISHNAV WORLD — MERGED ADMIN + DEVOTEE + FCM PACKAGE

Base:
- Devotee app: previous Enhanced Members + Infinite Level + FCM build.
- Admin app: Vaishnav_World_Admin_Password_2011_No_Email_Final.
- Admin password remains: 2011. No email login added.
- Existing Admin sections are retained: Dashboard, Devotees, Yatra, Quiz Manager, Courses, Challenge, Katha/Articles, Calendar, YouTube, Book Store, Prabhupada Today, Notifications.
- Added missing publishing controls: Daily Darshan and Shlok Reading Challenge.
- Daily Darshan is the only Admin image-upload field. The image is stored as compressed data in Realtime Database; Firebase Storage is not required.
- Shlok Reading publishes date-keyed content at shlokaReading/YYYY-MM-DD so the Devotee app shows the matching day's shlok.
- Every Admin publish that creates an in-app notification also creates pushQueue/{id}; the included Firebase Cloud Function sends FCM to registered Android tokens.
- Devotee Android package: com.bhaktiverse.app and the provided google-services.json is included.

IMPORTANT FIREBASE STEPS:
1. In Firebase Realtime Database, deploy firebase-rules.json if you want this exact password-only Admin web app to read/write the shared data. These rules are development/open rules; they are NOT suitable for a public production database.
2. Deploy the functions/ folder to Firebase so sendPushFromQueue is active.
3. Build the Android project in android-app. Android 13+ notification permission is requested by the included app.
4. The Android app registers its FCM token under fcmTokens and the Cloud Function sends notifications from pushQueue.
5. Web Push/VAPID is not needed for the APK's native FCM notification path.

No claim is made that an APK binary was compiled here; this package contains the Android source/project and Firebase/FCM wiring.


FINAL FCM SETUP
1. Devotee Android app registers its FCM token under Realtime Database: fcmTokens/<encoded-token>.
2. Admin publish actions create an in-app notification and a pushQueue item.
3. Firebase Cloud Function functions/index.js listens to /pushQueue/{id} and sends FCM multicast notifications.
4. Deploy functions from the functions folder with Firebase CLI: firebase deploy --only functions.
5. Cloud Functions deployment may require a Firebase billing/Blaze plan depending on the Firebase account/project.
6. Android 13+ asks the user for notification permission. The user must allow notifications.
7. The supplied VAPID public key is for Web Push; native Android FCM uses google-services.json and does not require VAPID.
8. This source ZIP is not a compiled APK; build the devotee Android project and the separate admin-android-app project.


PERMISSION DENIED: Read README_PERMISSION_FIX.txt. Firebase rules must be published in Firebase Console; a ZIP cannot change remote rules automatically.
