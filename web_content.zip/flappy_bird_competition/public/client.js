const $=id=>document.getElementById(id);
let playerName=localStorage.flapName||"Player-"+Math.floor(100+Math.random()*900), ws=null, room=null, isHost=false, isPrivate=false, mode="solo", game=null, myId=null, lastPlayers=[];
$("profileTag").textContent="👤 "+playerName;
function show(id){["home","multi","lobby","game"].forEach(x=>$(x).classList.toggle("hidden",x!==id))}
function status(id,msg){$(id).textContent=msg}
function connect(){
 let url=$("serverInput").value.trim();
 if(!url){status("multiStatus","Enter the server address shown by the host.");return}
 try{ws?.close();ws=new WebSocket(url)}catch(e){status("multiStatus","Invalid server address.");return}
 status("connectionStatus","◌ Connecting…");
 ws.onopen=()=>{status("connectionStatus","● Connected");status("multiStatus","Connected. Create or join a room.");ws.send(JSON.stringify({type:"hello",name:playerName}))};
 ws.onclose=()=>{status("connectionStatus","● Disconnected");status("multiStatus","Server disconnected. Your current room may be unavailable.")};
 ws.onerror=()=>status("connectionStatus","Connection error");
 ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}handle(m)};
}
function send(type,data={}){if(ws?.readyState===1)ws.send(JSON.stringify({type,...data}))}
function handle(m){
 if(m.type==="hello"){myId=m.id}
 if(m.type==="rooms"){renderRooms(m.rooms)}
 if(m.type==="joined"){room=m.room;isHost=m.host;show("lobby");$("roomCode").textContent=room.id;$("roomPrivacy").textContent=room.private?"🔒 Private · Invite ID required":"🌐 Public room";renderPlayers(room.players);status("lobbyStatus",isHost?"You are host. Start when everyone is ready.":"Waiting for host to start.");$("startBtn").classList.toggle("hidden",!isHost)}
 if(m.type==="room"){room=m.room;renderPlayers(room.players)}
 if(m.type==="error"){status("multiStatus",m.message);status("lobbyStatus",m.message)}
 if(m.type==="start"){mode="multi";beginGame(m.seed,m.players)}
 if(m.type==="event"){if(!game)return;if(m.event==="score"){game.remote[m.id]=m.score;renderLive()}if(m.event==="dead"){game.remoteAlive[m.id]=false;renderLive()}if(m.event==="flap"&&m.id!==myId){game.remoteFlaps[m.id]=(game.remoteFlaps[m.id]||0)+1}}
 if(m.type==="result"){status("gameState",m.winner===myId?"🏆 You won!":m.winnerName+" wins!");$("rematchBtn").classList.remove("hidden")}
 if(m.type==="left"){room=m.room;if(room)renderPlayers(room.players)}
}
function renderRooms(rooms){$("roomList").innerHTML="";if(!rooms.length){$("roomList").innerHTML='<div class="small">No public rooms available.</div>';return}rooms.forEach(r=>{let d=document.createElement("div");d.className="player";d.innerHTML=`<span>${r.id} · ${r.count} players</span><button class="tab">Join</button>`;d.querySelector("button").onclick=()=>send("join",{roomId:r.id});$("roomList").append(d)})}
function renderPlayers(players){lastPlayers=players||[];$("playerCount").textContent="("+lastPlayers.length+")";$("lobbyPlayers").innerHTML="";lastPlayers.forEach(p=>{let d=document.createElement("div");d.className="player";d.innerHTML=`<span>${p.name}${p.id===myId?" (You)":""}</span><span class="pill">${p.host?"HOST":"READY"}</span>`;$("lobbyPlayers").append(d)})}
function renderLive(){let arr=[{id:myId,name:playerName,score:game?.score||0,alive:game?.alive??true},...lastPlayers.filter(p=>p.id!==myId).map(p=>({id:p.id,name:p.name,score:game.remote[p.id]||0,alive:game.remoteAlive[p.id]!==false}))];$("livePlayers").innerHTML="";arr.sort((a,b)=>b.score-a.score).forEach(p=>{let d=document.createElement("div");d.className="player";d.innerHTML=`<span>${p.name}</span><span>${p.alive?"🐤":"✖"} ${p.score}</span>`;$("livePlayers").append(d)})}
$("connectBtn").onclick=connect;$("multiBtn").onclick=()=>{show("multi");if(!$("serverInput").value){let h=location.hostname;if(h&&h!=="localhost")$("serverInput").value="ws://"+h+":3000"}};
$("backBtn").onclick=()=>show("home");$("refreshBtn").onclick=()=>send("list");
$("publicTab").onclick=()=>{isPrivate=false;$("privateToggle").checked=false;$("publicTab").classList.add("active");$("privateTab").classList.remove("active")};
$("privateTab").onclick=()=>{isPrivate=true;$("privateToggle").checked=true;$("privateTab").classList.add("active");$("publicTab").classList.remove("active")};
$("privateToggle").onchange=e=>{isPrivate=e.target.checked;$("privateTab").classList.toggle("active",isPrivate);$("publicTab").classList.toggle("active",!isPrivate)};
$("createBtn").onclick=()=>{if(ws?.readyState!==1){status("multiStatus","Connect to the local server first.");return}send("create",{private:isPrivate,name:playerName})};
$("joinBtn").onclick=()=>{let id=$("roomInput").value.trim().toUpperCase();if(!id)return status("multiStatus","Enter a Room ID.");if(ws?.readyState!==1)return status("multiStatus","Connect to the local server first.");send("join",{roomId:id})};
$("quickBtn").onclick=()=>{if(ws?.readyState!==1)return status("multiStatus","Connect to the local server first.");send("quick",{name:playerName})};
$("startBtn").onclick=()=>send("start");$("leaveBtn").onclick=()=>{send("leave");room=null;show("multi")};
$("copyBtn").onclick=()=>navigator.clipboard?.writeText(room?.id||"").then(()=>status("lobbyStatus","Room ID copied!")).catch(()=>status("lobbyStatus","Room ID: "+room.id));
$("nameBtn").onclick=()=>{let n=prompt("Choose your player name",playerName);if(n&&n.trim()){playerName=n.trim().slice(0,18);localStorage.flapName=playerName;$("profileTag").textContent="👤 "+playerName}};
$("howBtn").onclick=()=>alert("Tap / click / press Space to flap. Avoid the pipes and survive as long as you can. Multiplayer players race on the same pipe pattern; highest score wins.");
$("soloBtn").onclick=()=>{mode="solo";beginGame(Math.floor(Math.random()*1e9),[])};
$("exitGame").onclick=()=>{if(mode==="multi")send("leave");room=null;show("home")};
$("rematchBtn").onclick=()=>{if(mode==="multi")send("rematch");else beginGame(Math.random()*1e9,[])};
const canvas=$("gameCanvas"),ctx=canvas.getContext("2d");
function beginGame(seed,players){
 show("game");$("rematchBtn").classList.add("hidden");status("gameState","Tap / Space to flap");game={birdY:210,vel:0,pipes:[],score:0,alive:true,started:false,frame:0,seed:seed>>>0,remote:{},remoteAlive:{},remoteFlaps:{}};lastPlayers=players||[];renderLive();if(mode==="multi")send("ready");
}
function rand(){game.seed=(game.seed*1664525+1013904223)>>>0;return game.seed/4294967296}
function flap(){if(!game||!game.alive)return;if(!game.started)game.started=true;game.vel=-5.6;if(mode==="multi")send("event",{event:"flap"})}
canvas.addEventListener("pointerdown",e=>{e.preventDefault();flap()});
window.addEventListener("keydown",e=>{if(e.code==="Space"&&!$("game").classList.contains("hidden")){e.preventDefault();flap()}});
function draw(){
 if(!game){requestAnimationFrame(draw);return}let w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
 let sky=ctx.createLinearGradient(0,0,0,h);sky.addColorStop(0,"#74d7ed");sky.addColorStop(1,"#e0f7d7");ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
 ctx.fillStyle="#ffffff99";for(let i=0;i<4;i++){let x=(i*210-(game.frame*.35)%900+900)%900;ctx.beginPath();ctx.ellipse(x,75+(i%2)*60,42,13,0,0,7);ctx.ellipse(x+28,70+(i%2)*60,30,18,0,0,7);ctx.fill()}
 if(game.started&&game.alive){
  game.frame++;game.vel+=.28;game.birdY+=game.vel;
  if(game.frame%100===1){let gap=150,top=65+rand()*170;game.pipes.push({x:w+20,top,passed:false})}
  game.pipes.forEach(p=>{p.x-=3.2;if(!p.passed&&p.x<120){p.passed=true;game.score++;$("score").textContent=game.score;if(mode==="multi")send("event",{event:"score",score:game.score});renderLive()}});
  game.pipes=game.pipes.filter(p=>p.x>-70);
  let hit=game.birdY<0||game.birdY>h-45||game.pipes.some(p=>120+17>p.x&&120-17<p.x+58&&(game.birdY-14<p.top||game.birdY+14>p.top+150));
  if(hit){game.alive=false;status("gameState","Race finished · Score "+game.score);if(mode==="multi")send("event",{event:"dead",score:game.score});else $("rematchBtn").classList.remove("hidden")}
 }
 ctx.fillStyle="#74bd4e";game.pipes.forEach(p=>{ctx.fillRect(p.x,0,58,p.top);ctx.fillRect(p.x-5,p.top-18,68,18);ctx.fillRect(p.x,p.top+150,58,h-p.top-150);ctx.fillRect(p.x-5,p.top+150,68,18)});
 ctx.fillStyle="#78c84f";ctx.fillRect(0,h-35,w,35);ctx.fillStyle="#e9d68a";ctx.fillRect(0,h-40,w,7);
 ctx.save();ctx.translate(120,game.birdY);ctx.rotate(Math.max(-.45,Math.min(.7,game.vel*.07)));ctx.fillStyle="#ffd34e";ctx.beginPath();ctx.ellipse(0,0,19,15,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#e99a27";ctx.beginPath();ctx.moveTo(13,0);ctx.lineTo(31,6);ctx.lineTo(13,9);ctx.fill();ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(7,-6,6,0,7);ctx.fill();ctx.fillStyle="#17324d";ctx.beginPath();ctx.arc(9,-6,2.5,0,7);ctx.fill();ctx.restore();
 ctx.fillStyle="#fff";ctx.font="bold 28px system-ui";ctx.textAlign="center";ctx.fillText(game.score,w/2,45);
 if(!game.started){ctx.fillStyle="#17324dcc";ctx.fillRect(140,180,440,100);ctx.fillStyle="#fff";ctx.font="bold 23px system-ui";ctx.fillText("TAP TO FLAP",w/2,220);ctx.font="15px system-ui";ctx.fillText("Avoid the pipes · Beat the leaderboard",w/2,250)}
 if(!game.alive){ctx.fillStyle="#17324dcc";ctx.fillRect(140,170,440,110);ctx.fillStyle="#fff";ctx.font="bold 26px system-ui";ctx.fillText("FLIGHT OVER",w/2,215);ctx.font="16px system-ui";ctx.fillText("Your score: "+game.score,w/2,245)}
 requestAnimationFrame(draw)
}
requestAnimationFrame(draw);
