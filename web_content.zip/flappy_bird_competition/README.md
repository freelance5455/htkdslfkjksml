# Flap League — local multiplayer prototype

## Run the local server
1. Install Node.js on the computer that will host the room.
2. Open a terminal in this folder and run: `npm install`
3. Run: `npm start`
4. The host opens `http://localhost:3000`.
5. Friends on the same Wi-Fi open `http://HOST-LAN-IP:3000` (find the host computer's local IPv4 address).
6. In Multiplayer > Connection, connect to `ws://HOST-LAN-IP:3000` if it did not auto-fill.

## Modes
- Classic solo play
- Quick Play (joins an open public room or creates one)
- Create public room
- Create private room and share the 6-character Room ID
- Join by Room ID
- Up to 8 players per room

## Important multiplayer note
This is a local-network prototype. The Node.js server relays rooms, lobby state, synchronized match starts, scores and player eliminations. It is not a public internet matchmaking service. For friends outside the same network, deploy the server to a trusted host with secure WebSockets (WSS), authentication, rate limits and persistent matchmaking. Do not expose a home computer directly to the public internet.

## Project structure
- `public/index.html` — responsive UI and canvas game
- `public/client.js` — game and multiplayer client
- `server.js` — local room server
- `package.json` — dependency manifest
