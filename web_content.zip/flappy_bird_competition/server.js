const http=require("http"),fs=require("fs"),path=require("path"),crypto=require("crypto"),WebSocket=require("ws");
const PORT=process.env.PORT||3000,ROOT=path.join(__dirname,"public");
const rooms=new Map(),clients=new Map();
const server=http.createServer((req,res)=>{let p=req.url.split("?")[0];if(p==="/")p="/index.html";let f=path.join(ROOT,p);if(!f.startsWith(ROOT)){res.writeHead(403);return res.end()}fs.readFile(f,(e,b)=>{if(e){res.writeHead(404);return res.end("Not found")}let ext=path.extname(f);res.writeHead(200,{"Content-Type":ext===".js"?"text/javascript":"text/html","Cache-Control":"no-store"});res.end(b)})});
const wss=new WebSocket.Server({server});
function send(c,o){if(c&&c.readyState===1)c.send(JSON.stringify(o))}
function roomView(r){return {id:r.id,private:r.private,players:[...r.players.values()].map(p=>({id:p.id,name:p.name,host:p.id===r.host,ready:p.ready,score:p.score,alive:p.alive}))}}
function broadcast(r,o){for(const p of r.players.values())send(p.ws,o)}
function update(r){broadcast(r,{type:"room",room:roomView(r)})}
function leave(c){let r=rooms.get(c.room);if(!r)return;r.players.delete(c.id);c.room=null;if(!r.players.size){rooms.delete(r.id);return}if(r.host===c.id)r.host=r.players.keys().next().value;update(r);broadcast(r,{type:"left",room:roomView(r)})}
function join(c,r){if(c.room)leave(c);if(r.players.size>=8)return send(c,{type:"error",message:"Room is full (8 players max)."});r.players.set(c.id,{id:c.id,name:c.name||"Player",ws:c,ready:false,score:0,alive:true});c.room=r.id;send(c,{type:"joined",room:roomView(r),host:r.host===c.id});update(r)}
function roomId(){let id;do{id=crypto.randomBytes(3).toString("hex").toUpperCase()}while(rooms.has(id));return id}
function list(c){send(c,{type:"rooms",rooms:[...rooms.values()].filter(r=>!r.private&&!r.started).map(r=>({id:r.id,count:r.players.size}))})}
wss.on("connection",ws=>{let c={id:crypto.randomUUID(),ws,name:"Player",room:null};clients.set(c.id,c);send(c,{type:"hello",id:c.id});
ws.on("message",raw=>{let m;try{m=JSON.parse(raw)}catch{return}if(m.type==="hello"){c.name=String(m.name||"Player").slice(0,18);send(c,{type:"hello",id:c.id})}
if(m.type==="list")return list(c);
if(m.type==="create"){let id=roomId(),r={id,private:!!m.private,host:c.id,players:new Map(),started:false};rooms.set(id,r);join(c,r);listAll()}
if(m.type==="join"){let r=rooms.get(String(m.roomId||"").toUpperCase());if(!r)return send(c,{type:"error",message:"Room not found. Check the Room ID."});if(r.started)return send(c,{type:"error",message:"That competition has already started."});join(c,r);listAll()}
if(m.type==="quick"){let r=[...rooms.values()].find(x=>!x.private&&!x.started&&x.players.size<8);if(!r){let id=roomId();r={id,private:false,host:c.id,players:new Map(),started:false};rooms.set(id,r)}join(c,r);listAll()}
if(m.type==="leave"){leave(c);listAll()}
let r=rooms.get(c.room);if(!r)return;
if(m.type==="start"&&r.host===c.id){if(r.players.size<2)return send(c,{type:"error",message:"Need at least 2 players to start."});r.started=true;for(const p of r.players.values()){p.score=0;p.alive=true;p.ready=false}broadcast(r,{type:"start",seed:crypto.randomBytes(4).readUInt32BE(0),players:roomView(r).players});}
if(m.type==="ready"){let p=r.players.get(c.id);if(p)p.ready=true}
if(m.type==="event"){let p=r.players.get(c.id);if(!p)return;if(m.event==="score")p.score=Math.max(0,Math.min(9999,Number(m.score)||0));if(m.event==="dead"){p.score=Math.max(0,Number(m.score)||0);p.alive=false}broadcast(r,{type:"event",id:c.id,event:m.event,score:p.score});if([...r.players.values()].every(x=>!x.alive)){let winner=[...r.players.values()].sort((a,b)=>b.score-a.score)[0];broadcast(r,{type:"result",winner:winner.id,winnerName:winner.name,score:winner.score});r.started=false;}}
if(m.type==="rematch"&&r.host===c.id){r.started=false;for(const p of r.players.values()){p.alive=true;p.score=0;p.ready=false}broadcast(r,{type:"room",room:roomView(r)})}
});
ws.on("close",()=>{leave(c);clients.delete(c.id);listAll()});
});
function listAll(){for(const c of clients.values())list(c)}
server.listen(PORT,"0.0.0.0",()=>console.log(`Flap League server running on http://0.0.0.0:${PORT}`));
