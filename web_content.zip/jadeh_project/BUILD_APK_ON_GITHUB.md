# ساخت مستقیم APK

این پروژه برای ساخت APK اندروید با GitHub Actions آماده شده است.

## مراحل
1. کل محتویات این پوشه را داخل یک Repository جدید در GitHub آپلود کنید (پوشه `.github` هم باید آپلود شود).
2. وارد تب **Actions** شوید.
3. Workflow با نام **Build Android APK** را انتخاب کنید.
4. گزینه **Run workflow** را بزنید.
5. بعد از اتمام Build، از بخش **Artifacts** فایل `JADEH-405-GLX-Android-APK` را دانلود کنید.
6. ZIP دانلودشده را باز کنید و `JADEH-405-GLX-debug.apk` را روی گوشی نصب کنید.

این APK نسخه debug برای نصب و تست است و برای انتشار در Google Play امضای release جداگانه لازم دارد.
