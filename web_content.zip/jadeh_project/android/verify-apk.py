"""Verify a real Android artifact before advertising or staging a download."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile


root = Path(__file__).resolve().parents[1]
apk = root / "android/app/build/outputs/apk/debug/app-debug.apk"
web = root / "dist/index.html"
if not apk.is_file() or not web.is_file():
    raise SystemExit("Build the production HTML and Android APK first.")

with zipfile.ZipFile(apk) as archive:
    required = {"AndroidManifest.xml", "classes.dex", "resources.arsc", "assets/game/index.html"}
    if not required.issubset(set(archive.namelist())):
        raise SystemExit("The output is not a complete JADEH Android APK.")
    if archive.read("assets/game/index.html") != web.read_bytes():
        raise SystemExit("APK does not contain the current production game.")

sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
if not sdk:
    raise SystemExit("ANDROID_HOME or ANDROID_SDK_ROOT must point to the Android SDK.")
signer = Path(sdk) / "build-tools/35.0.0/apksigner"
if os.name == "nt":
    signer = signer.with_suffix(".bat")
verification = subprocess.run(
    [str(signer), "verify", "--verbose", "--print-certs", str(apk)],
    check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
)

output = root / "dist/downloads"
output.mkdir(parents=True, exist_ok=True)
filename = "JADEH-405-GLX-debug.apk"
destination = output / filename
shutil.copyfile(apk, destination)
digest = hashlib.sha256(destination.read_bytes()).hexdigest()
(output / (filename + ".sha256")).write_text(digest + "  " + filename + "\n", encoding="utf-8")
(output / "APK-SIGNATURE.txt").write_text(verification.stdout, encoding="utf-8")
(output / "android.json").write_text(json.dumps({
    "schema": 1,
    "available": True,
    "filename": filename,
    "version": "2.2.0-debug",
    "kind": "debug",
    "sizeBytes": destination.stat().st_size,
    "sha256": digest,
    "minAndroid": "8.0",
}, indent=2) + "\n", encoding="utf-8")
print("Verified APK staged:", destination)
print("SHA-256:", digest)