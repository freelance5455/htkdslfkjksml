# JADEH: Peugeot 405 GLX & Saipa 141

A mobile-first 3D driving game with a sport-tuned Peugeot 405 GLX and a graphite Saipa 141 liftback reconstructed from the supplied rear reference. The source uses React for the interface and Three.js for rendering. Both are bundled into the standalone HTML; no CDN or server is needed to play the production file.

## Open the Game

- Open `dist/index.html` directly in a modern browser with WebGL 2 enabled.
- Alternatively, choose **Play Offline** on the main menu to download `JADEH-405-GLX.html`.
- The HTML contains its JavaScript, CSS, fonts, and image textures. Audio is synthesized locally and starts after a user gesture.
- On Android, open the HTML with a browser rather than a file manager's text preview. Fullscreen and orientation locking depend on browser permissions; manual landscape rotation remains supported.

## Android APK

**No APK has been compiled or published in the editing environment.** The new Android button states this explicitly. A ZIP of Android source is not an installable APK.

- Open **Android** in the game footer for the actual download status and Persian instructions.
- **Download Android Project (ZIP)** exports the native source, build workflow, and current production HTML. It does not include signing secrets or local machine settings.
- Upload the extracted files, including `.github/`, to a GitHub repository and run **Actions > Build Android APK**.
- Only a successful native build produces **JADEH-405-GLX-debug.apk**, inside the **JADEH-405-GLX-Android-APK** artifact.
- The workflow checks the APK signature and checks that the packaged game exactly matches `dist/index.html` before staging it.
- This debug-signed package is for direct installation/testing, not a Play Store release. Keep a private, stable release signing key for distributable updates.
- The Android wrapper targets Android 8.0+, uses a local HTTPS WebView asset origin, requests no device permissions, supports landscape/immersive display, and forwards Back/background events to the game.
- The optional **JADEH-web-with-APK** artifact contains a website and its real APK download. Publish the whole artifact to enable the site's APK button; no fabricated URL is used before a package exists.

Full Persian instructions, tool versions, file locations, and signing limitations are in `android/README.md`. The Android Gradle project, workflow execution, and device lifecycle behavior are unverified here; only the web build can be executed with the available tools.

## Controls

| Action | Keyboard | Touch |
| --- | --- | --- |
| Accelerate | W / Up | Hold Gas |
| Brake | S / Down | Hold Brake |
| Steer | A / D or Left / Right | Hold Left / Right |
| Camera | C | Camera button |
| Cockpit / chase toggle | V | Inside / outside view button |
| Pause / Resume | P / Escape | Pause / Continue |
| Handbrake | Hold Space | Hold Handbrake / ترمز دستی |
| Neutral rev / gear hold | Hold X | Hold REV / کات‌آف |
| Horn | H | Keyboard only |
| Restart | R | Pause > Restart Drive |
| Fullscreen | F | Fullscreen button |

Multiple touch controls can be held simultaneously. Pointer capture, cancellation, window blur, and tab visibility changes clear held controls. Pausing freezes both the player and traffic.

## Cockpit & Clarity Update

- **Garage selection:** choose Peugeot 405 GLX or Saipa 141 SE. Selection, paint, and view preferences are saved. The 141 is a separate liftback mesh, not a resized Peugeot. Its three-section vertical rear lamps, recessed plate pocket, hatch lip, black bumpers, door mouldings, square mirrors, fuel flap, and small wheel covers follow the supplied rear reference.
- **Driver camera:** starts in the cockpit by default. Use V or the on-screen view button to switch directly to chase; C cycles chase, cockpit, wide chase, and bonnet. Settings can restore third-person starts.
- **Interior preview:** Garage > Explore the Cockpit shows the parked interior and offers a direct start from the driver's seat.
- **405 cabin:** open cabin space replaces the solid body volume. A classic GLX-style horizontal dashboard includes an instrument binnacle, rectangular vents, two-spoke wheel, radio, heater controls, glovebox, door cards, pedals, seats, centre console, and headliner. This is a procedural approximation of the classic dashboard, not a scan of a particular model year.
- **Live instruments:** speed and RPM needles, trip distance, steering, gear lever, and handbrake lever follow the simulation. The interior mirror renders actual traffic behind the car at a reduced update rate to limit mobile rendering cost.
- **Sharper rendering:** High is the new default. High allows up to 2.5x pixel density (including modest supersampling on 1x screens), 16x anisotropic filtering where supported, a sharper local shadow footprint, and a 2048x1024 generated lighting environment. Medium allows up to 1.65x density. Resolution is bounded by a physical-pixel budget; the actual buffer dimensions appear in the HUD.
- **No silent resolution drops:** adaptive resolution is a separate option and defaults off. Enable it on slower devices, or choose Medium/Low graphics.
- **Audio:** multiple locally synthesized combustion-cycle buffers crossfade across the RPM range instead of using continuous sawtooth engine oscillators. XU7 and M13 profiles have different resonances and pulse variations. The cockpit has filtered engine, wind, and road sound. Sport exhaust and the real torque-cutting limiter remain supported. These are synthesized sounds, not vehicle recordings.
- **Different handling:** the 405 retains its fictional 165 hp / 228 Nm game tune and 6800 RPM limit. The 141 uses a lighter 940 kg / 71 hp / 108 Nm profile with a 6100 RPM limiter, narrower collision bounds, and different grip/body roll. These are simulation profiles, not measured performance claims.

## Sport Update

- The player's 405 now uses a fictional 165 hp / 228 Nm sport tune, a faster throttle response, and quicker automatic shifts. These are game settings, not stock GLX specifications.
- The central speedometer is approximately one third smaller, with responsive sizes for portrait and landscape screens.
- Handbrake is a separate rear-wheel brake, with visibly locked rear wheels, reduced rear grip, controlled sliding, tire noise, and smoke. Release it to recover grip. Normal braking remains independent and overrides the accelerator.
- Hold **REV / X while stopped** to rev in neutral without driving forward. Releasing REV alone does not launch the car; use Gas to accelerate.
- **While already moving, hold REV / X together with Gas** to keep the current gear and reach the selected car's limiter. Release REV to return to automatic shifting.
- **Handbrake + Gas at rest** also opens the clutch for stationary revs. Releasing the handbrake while holding Gas reconnects the clutch smoothly.
- The limiter cuts actual drive torque and restores it below 6,490 RPM, with synchronized engine/exhaust interruption, restrained exhaust pops, and a steady HUD indicator.
- Sport exhaust is enabled by default. Its separate low-frequency harmonics, filtered saturation, overrun crackle, and limiter pops are synthesized locally. The quieter sound profile remains available through the Sport Exhaust switch in Settings.
- Vehicle detail now includes tire tread and sidewall lettering, valves, front brake discs/calipers, fuel flap seams, door locks, lamp divisions, plate screws, a hollow polished exhaust tip, patterned upholstery, rear seats, dashboard controls, and a rear-view mirror.
- The cabin steering wheel, handbrake lever, and dashboard needles animate from the driving simulation. Static details remain batched by material, and traffic keeps the lighter vehicle model.

## Features

- Reference-informed 405 GLX geometry: angular sedan proportions, wheel arches, black mouldings, rectangular lamps, silver wheel covers, window pillars, door gaps, handles, mirrors, Persian plates, boot lettering, seats, dashboard, and steering wheel.
- Sport-tuned five-speed transmission with throttle smoothing, a working rev limiter, speed-sensitive steering, lateral grip, damped body roll and pitch, ABS, a rear-wheel handbrake, and collisions.
- An endless Iranian-inspired highway with Persian signage, apartment textures, Alborz scenery, lane markings, surface imperfections, barriers, lights, and cypress trees.
- Traffic with variable cruise speeds, car-following acceleration, player avoidance, clearance-checked lane changes, and recycled gaps.
- Close-call scoring, chained multipliers, vehicle condition, drive results, and locally saved preferences and personal best.
- Clear or rainy weather and daylight, golden-hour, or night lighting. Three graphics presets adjust resolution, shadows, and scenery density.
- Procedural engine and sport-exhaust harmonics, RPM response, cutoff pulses, overrun crackle, shifts, road noise, braking, passing-traffic ambience, horn, and collision impacts.
- Pooled dust and tire smoke, rain streaks, paint and glass reflections, contact shadows, and speed-responsive camera effects.

## Implementation

- `src/App.tsx`: application state, keyboard and multi-touch input, preferences, and offline export.
- `src/sim/engine.ts`: render loop, bounded physics substeps, traffic AI, collisions, cameras, and effects.
- `src/sim/powertrain.ts`: sport tuning, clutch behavior, automatic gear changes, neutral revs, gear hold, and torque-cutting rev limiter.
- `src/sim/peugeot.ts`: custom reference-informed vehicle geometry and draw-call batching.
- `src/sim/saipa141.ts`: reference-informed Saipa 141 liftback model.
- `src/sim/cabin.ts`: model-specific cockpit geometry and live instruments.
- `src/sim/vehicles.ts`: vehicle dimensions, appearance, and drivetrain profiles.
- `src/sim/modelGeometry.ts`: shared mesh construction, material batching, and resource cleanup.
- `src/sim/highway.ts`: instanced highway scenery and recycled building/sign chunks.
- `src/sim/audio.ts`: local Web Audio synthesis.
- `src/sim/combustion.ts`: seeded four-cylinder combustion-loop generation.
- `src/ui/`: launch controls, instruments, dialogs, and SVG icons.
- `src/ui/driving.css`: compact instruments and mobile handbrake/rev controls.
- `dist/index.html`: generated standalone playable artifact.

## Scope and Verification

Both cars are original procedural reconstructions informed by references, not licensed production CAD models or meshes extracted from photos. One exterior photo cannot determine all interior details. The cabins approximate classic 405 and Pride-family layouts; exact trim/year matching would need additional interior reference photos and runtime visual comparison. The sound is synthesized, not a recording of a real XU7 or M13 engine. The route is inspired by Tehran-Karaj, not a surveyed road map. Physics are tuned for accessible highway driving rather than engineering-grade simulation.

The production build is verified and its output is inspected for external asset references. Runtime cockpit visibility, model fidelity, mirror rendering, audible sound quality, and physical Android frame rates have not been tested in this environment. No measured 0-100 time, photorealism, or stable device frame rate is claimed. Try Medium or enable adaptive resolution on constrained devices. The native APK is still unbuilt here.