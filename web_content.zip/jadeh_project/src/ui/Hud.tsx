import type { KeyboardEvent, MouseEvent, PointerEvent } from 'react';
import { CAMERA_NAMES, COCKPIT_CAMERA, type Controls, type Telemetry } from '../sim/types';
import { VEHICLES } from '../sim/vehicles';
import { Icon } from './Icon';
import './driving.css';

export function DrivingHud({ data, active, press, release, onCockpit }: { data: Telemetry; active: Controls; press: (id: number, control: keyof Controls) => void; release: (id: number) => void; onCockpit: () => void }) {
  const holdProps = (control: keyof Controls) => {
    const keyboardId = -(['gas', 'brake', 'left', 'right', 'handbrake', 'horn', 'rev'].indexOf(control) + 1);
    return {
      onPointerDown: (e: PointerEvent<HTMLButtonElement>) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); press(e.pointerId, control); },
      onPointerUp: (e: PointerEvent<HTMLButtonElement>) => { release(e.pointerId); },
      onPointerCancel: (e: PointerEvent<HTMLButtonElement>) => { release(e.pointerId); },
      onLostPointerCapture: (e: PointerEvent<HTMLButtonElement>) => { release(e.pointerId); },
      onKeyDown: (e: KeyboardEvent<HTMLButtonElement>) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); if (!e.repeat) press(keyboardId, control); } },
      onKeyUp: (e: KeyboardEvent<HTMLButtonElement>) => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); release(keyboardId); } },
      onBlur: () => release(keyboardId),
      onContextMenu: (e: MouseEvent<HTMLButtonElement>) => e.preventDefault(),
    };
  };
  const revColor = data.limiter ? '#ff9079' : data.rpm > data.redline - 800 ? '#ed705c' : '#efb366';
  const cockpit = data.camera === COCKPIT_CAMERA;
  const vehicle = VEHICLES[data.vehicleId];
  return <div className={`game-hud ${cockpit ? 'inside-cockpit' : ''}`}>
    <div className="drive-stats"><div><span className="eyebrow">DISTANCE</span><b>{data.distance.toFixed(2)}<small>KM</small></b></div><div><span className="eyebrow">DRIVE SCORE</span><b>{data.score.toLocaleString()}<small className="score-multiplier">{data.combo > 1 ? `x${data.combo}` : 'PTS'}</small></b></div></div>
    <div className="car-condition"><span>{vehicle.shortName} <em className="sport-designation">{data.vehicleId === 'peugeot405' ? 'SPORT' : 'SAIPA'}</em></span><div className="condition-track"><i style={{ width: `${100 - data.damage}%`, background: data.damage > 65 ? '#ed6b59' : undefined }} /></div><small>{Math.round(100 - data.damage)}% CONDITION</small>{data.handbrake && <span className="handbrake-indicator"><Icon name="handbrake" size={15} /><span lang="fa" dir="rtl">ترمز دستی</span></span>}</div>
    <button type="button" className="cockpit-toggle" onClick={onCockpit} aria-label="تغییر نمای داخل و بیرون کابین (V)" aria-pressed={cockpit}><Icon name="camera" size={17} /><span lang="fa">{cockpit ? 'نمای بیرون' : 'نمای داخل کابین'}</span><kbd>V</kbd></button>
    <div className="driving-controls">
      <div className="steering"><span className="control-label">FIND YOUR LINE</span><div className="steer-pair"><button aria-label="Steer left" aria-pressed={active.left} className={`steer-button ${active.left ? 'held' : ''}`} {...holdProps('left')}><Icon name="left" size={34} /><span>LEFT <kbd>A</kbd></span></button><button aria-label="Steer right" aria-pressed={active.right} className={`steer-button ${active.right ? 'held' : ''}`} {...holdProps('right')}><Icon name="right" size={34} /><span>RIGHT <kbd>D</kbd></span></button></div></div>
      <div className={`instrument instrument-compact ${data.limiter ? 'on-limiter' : ''}`} aria-label={`Speed ${Math.round(data.speed)} km/h, engine ${Math.round(data.rpm)} RPM${data.limiter ? ', rev limiter active' : ''}`}>
        <svg className="tach" viewBox="0 0 250 204" aria-hidden="true">
          <circle cx="125" cy="108" r="94" fill="none" stroke="rgba(220,225,220,.13)" strokeWidth="3" strokeDasharray="411 591" transform="rotate(145 125 108)" />
          <circle cx="125" cy="108" r="94" fill="none" stroke={revColor} strokeWidth="4" strokeDasharray={`${Math.min(data.rpm / data.redline, 1) * 411} 591`} transform="rotate(145 125 108)" strokeLinecap="round" />
          {[0, 1, 2, 3, 4, 5, 6].map(i => <line key={i} x1="125" y1="21" x2="125" y2="27" stroke={i > 4 ? '#b87158' : '#a5aca9'} strokeWidth="1.3" transform={`rotate(${-124 + i * 41} 125 108)`} />)}
        </svg>
        <div className="speed-readout">
          <span className="speed-value">{Math.round(data.speed).toString().padStart(2, '0')}</span><span className="speed-unit">KM/H</span>
          <div className="gear-readout"><span>{data.neutral ? 'REV' : data.gearHeld ? 'HOLD' : 'AUTO'}</span><b>{data.neutral ? 'N' : data.gear}</b><span className="rpm-value" style={{ color: data.limiter ? revColor : undefined }}>{(data.rpm / 1000).toFixed(1)} <small>RPM x1000</small></span></div>
        </div>
        <span className="camera-label">{data.limiter ? `CUT-OFF / ${data.redline} RPM` : data.neutral ? 'NEUTRAL / FREE REV' : data.gearHeld ? 'GEAR HOLD / RELEASE X TO SHIFT' : `${CAMERA_NAMES[data.camera]} CAMERA`}</span>
      </div>
      <div className="pedal-stack">
        <div className="aux-controls">
          <button type="button" aria-label="ترمز دستی / Handbrake (Space)" aria-pressed={active.handbrake} title="Hold to lock the rear wheels / ترمز دستی" className={`aux-button handbrake-button ${active.handbrake ? 'held' : ''}`} {...holdProps('handbrake')}><Icon name="handbrake" size={20} /><span className="aux-fa" lang="fa" dir="rtl">ترمز دستی</span><small>HANDBRAKE <kbd>SPACE</kbd></small></button>
          <button type="button" aria-label="کات‌آف / Rev and hold gear (X)" aria-pressed={active.rev} title="Hold for neutral revs at rest; hold with Gas to reach the limiter while moving." className={`aux-button rev-button ${active.rev ? 'held' : ''} ${data.limiter ? 'at-limit' : ''}`} {...holdProps('rev')}><Icon name="rev" size={20} /><span className="aux-fa" lang="fa" dir="rtl">کات‌آف</span><small>REV / HOLD <kbd>X</kbd></small></button>
        </div>
        <div className="pedals"><button aria-label="Brake" aria-pressed={active.brake} className={`pedal brake-pedal ${active.brake ? 'held' : ''}`} {...holdProps('brake')}><span className="pedal-grooves"><i /><i /><i /></span><span>BRAKE <kbd>S</kbd></span></button><button aria-label="Accelerate" aria-pressed={active.gas} className={`pedal gas-pedal ${active.gas ? 'held' : ''}`} {...holdProps('gas')}><span className="pedal-grooves"><i /><i /><i /><i /></span><span>GAS <kbd>W</kbd></span></button></div>
      </div>
    </div>
    {data.distance < 0.04 && !data.neutral && <div className="first-drive-hint"><Icon name="keyboard" size={17} /><span>Hold <kbd>W</kbd> or <b>GAS</b> to get moving.<small className="sport-hint" lang="fa" dir="rtl">کات‌آف درجا: نگه‌داشتن REV یا X</small></span></div>}
  </div>;
}