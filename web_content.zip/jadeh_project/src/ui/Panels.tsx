import { useEffect, useRef, type ReactNode } from 'react';
import { DEFAULTS, type Preferences, type Telemetry } from '../sim/types';
import { Icon, type IconName } from './Icon';

export function Dialog({ title, subtitle, children, onClose, wide = false }: { title: string; subtitle: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const close = useRef(onClose); close.current = onClose;
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); close.current(); }
      if (e.key !== 'Tab') return;
      const nodes = ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled), input:not(:disabled), a[href], [tabindex="0"]');
      if (!nodes?.length) return;
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === ref.current)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => { window.removeEventListener('keydown', onKey, true); previous?.focus(); };
  }, []);
  return <div className="modal-backdrop" onPointerDown={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className={`dialog ${wide ? 'dialog-wide' : ''}`} ref={ref} role="dialog" aria-modal="true" aria-labelledby="dialog-title" tabIndex={-1}>
      <header className="dialog-header"><div><span className="eyebrow">{subtitle}</span><h2 id="dialog-title">{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="Close dialog"><Icon name="close" /></button></header>
      {children}
    </div>
  </div>;
}

function Segment<T extends string>({ label, value, options, onChange }: { label: string; value: T; options: { value: T; label: string; icon?: IconName }[]; onChange: (v: T) => void }) {
  return <fieldset className="setting-field"><legend>{label}</legend><div className="segmented">{options.map(o => <button key={o.value} type="button" className={o.value === value ? 'selected' : ''} aria-pressed={o.value === value} onClick={() => onChange(o.value)}>{o.icon && <Icon name={o.icon} size={18} />}<span>{o.label}</span></button>)}</div></fieldset>;
}

export function SettingsPanel({ prefs, setPrefs, onClose }: { prefs: Preferences; setPrefs: (p: Preferences) => void; onClose: () => void }) {
  const change = <K extends keyof Preferences>(key: K, value: Preferences[K]) => setPrefs({ ...prefs, [key]: value });
  return <Dialog title="Make It Your Drive." subtitle="DRIVE SETTINGS" onClose={onClose}>
    <div className="dialog-body settings-body">
      <Segment label="GRAPHICS QUALITY" value={prefs.quality} onChange={v => change('quality', v)} options={[{ value: 'low', label: 'Low' }, { value: 'medium', label: 'Medium' }, { value: 'high', label: 'High' }]} />
      <p className="field-note">{prefs.quality === 'low' ? 'Native-scale rendering with lighter shadows for slower devices.' : prefs.quality === 'medium' ? 'Up to 1.65x pixel density, 8x texture filtering, and a live cabin mirror.' : 'Up to 2.5x pixel density, 16x texture filtering, and sharper shadows. Actual resolution depends on screen size and the pixel budget.'}</p>
      <div className="switch-row"><div><strong>وضوح تطبیقی / Adaptive resolution</strong><p>Allow resolution to drop only if the frame rate stays low. Off keeps the selected resolution.</p></div><button type="button" role="switch" aria-checked={prefs.adaptiveResolution} aria-label="Adaptive resolution / کاهش خودکار وضوح" className={`switch ${prefs.adaptiveResolution ? 'on' : ''}`} onClick={() => change('adaptiveResolution', !prefs.adaptiveResolution)}><span /></button></div>
      <div className="switch-row"><div><strong>شروع از داخل کابین</strong><p>Start in the driver's seat. V or the camera button switches your view.</p></div><button type="button" role="switch" aria-checked={prefs.startInCockpit} aria-label="Start in cockpit / شروع از داخل کابین" className={`switch ${prefs.startInCockpit ? 'on' : ''}`} onClick={() => change('startInCockpit', !prefs.startInCockpit)}><span /></button></div>
      <Segment label="TIME OF DAY" value={prefs.time} onChange={v => change('time', v)} options={[{ value: 'day', label: 'Daylight', icon: 'sun' }, { value: 'golden', label: 'Golden hour', icon: 'sunset' }, { value: 'night', label: 'Night', icon: 'moon' }]} />
      <Segment label="WEATHER" value={prefs.weather} onChange={v => change('weather', v)} options={[{ value: 'clear', label: 'Clear skies', icon: 'sun' }, { value: 'rain', label: 'Rain', icon: 'rain' }]} />
      <label className="range-label"><span>TRAFFIC DENSITY <b>{prefs.density < 0.45 ? 'Light' : prefs.density < 0.8 ? 'Lively' : 'Dense'}</b></span><input aria-label="Traffic density" type="range" min="0.2" max="1" step="0.05" value={prefs.density} onChange={e => change('density', Number(e.target.value))} /><span className="range-caption"><small>ROOM TO BREATHE</small><small>BUMPER TO BUMPER</small></span></label>
      <label className="range-label"><span>ENGINE & ROAD AUDIO <b>{prefs.muted ? 'Muted' : `${Math.round(prefs.volume * 100)}%`}</b></span><input aria-label="Engine and road volume" type="range" min="0" max="1" step="0.05" value={prefs.volume} onChange={e => setPrefs({ ...prefs, volume: Number(e.target.value), muted: false })} /></label>
      <div className="switch-row"><div><strong>Sport exhaust / اگزوز اسپرت</strong><p>Combustion-cycle sound, distinct XU7/M13 tones, and quieter cabin acoustics. Off selects the standard exhaust mix.</p></div><button type="button" role="switch" aria-checked={prefs.sportExhaust} aria-label="Sport exhaust / اگزوز اسپرت" className={`switch ${prefs.sportExhaust ? 'on' : ''}`} onClick={() => change('sportExhaust', !prefs.sportExhaust)}><span /></button></div>
      <div className="switch-row"><div><strong>ABS braking assist</strong><p>Stay in control under heavy braking.</p></div><button type="button" role="switch" aria-checked={prefs.abs} aria-label="ABS braking assist" className={`switch ${prefs.abs ? 'on' : ''}`} onClick={() => change('abs', !prefs.abs)}><span /></button></div>
      <div className="setting-info"><Icon name="check" size={16} /><span>Your preferences are saved on this device.</span></div>
    </div>
    <footer className="dialog-footer"><button className="text-button" onClick={() => setPrefs({ ...DEFAULTS })}>Reset defaults</button><button className="primary compact" onClick={onClose}>BACK TO THE ROAD <Icon name="arrow" size={17} /></button></footer>
  </Dialog>;
}

export function HelpPanel({ onClose }: { onClose: () => void }) {
  const rows: { title: string; description: string; keys: string[] }[] = [
    { title: 'Find your pace', description: 'Your chosen car shifts automatically. The sport-tuned 405 and lighter Saipa 141 have different engines and handling.', keys: ['W', 'S'] },
    { title: 'Find your gap', description: 'Steer smoothly between lanes. Arrow keys also work.', keys: ['A', 'D'] },
    { title: 'Handbrake / ترمز دستی', description: 'Hold Space or the handbrake button to lock the rear wheels. Steer for a slide; release to recover grip.', keys: ['Space'] },
    { title: 'Cut-off / کات‌آف', description: 'Hold X or REV at rest to rev in neutral. While moving, hold it with Gas to keep your gear. The 405 cuts at 6,800 RPM; the 141 at 6,100 RPM.', keys: ['X'] },
    { title: 'Inside the car / نمای داخلی', description: 'V switches directly between cockpit and chase. C cycles all four cameras. Live dashboard needles follow the actual engine and speed.', keys: ['V', 'C'] },
    { title: 'Take a moment', description: 'Pause the drive. Your traffic will wait for you.', keys: ['P', 'Esc'] },
  ];
  return <Dialog title="Get To Know The Road." subtitle="HOW TO PLAY" onClose={onClose} wide>
    <div className="dialog-body help-body">
      <p className="dialog-intro">Choose the Peugeot 405 GLX or the reference-inspired Saipa 141 in the Garage. Explore either cabin before starting your drive.</p>
      {rows.map(r => <div className="help-row" key={r.title}><div className="help-keys">{r.keys.map(k => <kbd key={k}>{k}</kbd>)}</div><div><h3>{r.title}</h3><p>{r.description}</p></div></div>)}
      <div className="mobile-explainer"><Icon name="phone" size={30} /><div><h3>Made for your thumbs.</h3><p>Gas, Brake, steering, Handbrake, and REV all support simultaneous touches. Handbrake + Gas at rest also lets you rev without moving. Landscape gives you the best view.</p></div></div>
      <p className="small-controls"><span><kbd>H</kbd> Horn</span><span><kbd>Space</kbd> Handbrake</span><span><kbd>X</kbd> Rev / gear hold</span><span><kbd>R</kbd> Restart</span><span><kbd>F</kbd> Fullscreen</span></p>
      <div className="help-score"><span className="eyebrow">THE ART OF THE GAP</span><p>Pass close without touching at over 60 km/h to earn a close-call bonus. Chain clean passes to build your multiplier. Rain reduces grip. Collisions cost vehicle condition.</p></div>
      <p className="field-note">A simulated, closed-world driving experience. Keep real roads safe.</p>
    </div><footer className="dialog-footer"><span className="field-note">Keyboard, mouse, and multi-touch.</span><button className="primary compact" onClick={onClose}>I'M READY <Icon name="check" size={17} /></button></footer>
  </Dialog>;
}

export function RoutePanel({ onClose, onDrive, carName }: { onClose: () => void; onDrive: () => void; carName: string }) {
  return <Dialog title="Tehran To Karaj." subtitle="ROUTE 01 / IRAN" onClose={onClose}>
    <div className="dialog-body route-body"><div className="route-map"><svg viewBox="0 0 350 160" aria-hidden="true"><path d="M0 30 350 80M0 100 350 130M65 0 93 160M270 0 240 160" stroke="#293332" fill="none" strokeWidth="16"/><path d="M55 125c45 0 48-65 92-65h72c28 0 29-31 67-31" fill="none" stroke="#ecab55" strokeWidth="4"/><circle cx="55" cy="125" r="6" fill="#f0b967"/><circle cx="286" cy="29" r="6" fill="#f0b967"/><text x="28" y="103" fill="#eee" fontSize="12">TEHRAN</text><text x="255" y="57" fill="#eee" fontSize="12">KARAJ</text></svg></div><p className="route-persian" lang="fa" dir="rtl">آزادراه تهران ـ کرج</p><p className="dialog-intro">Beneath the Alborz mountains, the city gives way to an open highway. An endless, procedurally built route inspired by Iran's busiest freeway.</p><dl className="route-facts"><div><dt>DRIVE</dt><dd>Endless free roam</dd></div><div><dt>ROAD</dt><dd>Three lanes, two-way traffic</dd></div><div><dt>YOUR CAR</dt><dd>{carName}</dd></div></dl></div>
    <footer className="dialog-footer"><button className="primary full" onClick={onDrive}><Icon name="play" /> DRIVE THIS ROUTE <Icon name="arrow" /></button></footer>
  </Dialog>;
}

export function PausePanel({ onResume, onRestart, onFinish, onMenu, telemetry }: { onResume: () => void; onRestart: () => void; onFinish: () => void; onMenu: () => void; telemetry: Telemetry }) {
  return <div className="pause-backdrop"><section className="pause-panel" role="dialog" aria-modal="true" aria-label="Drive paused"><span className="eyebrow">ENGINE IDLING. WORLD ON HOLD.</span><h2>Take A Breather.</h2><p>The road will be right here.</p><div className="pause-trip"><span>{telemetry.distance.toFixed(2)} <small>KM DRIVEN</small></span><span>{telemetry.score.toLocaleString()} <small>POINTS</small></span></div><button className="primary full" onClick={onResume}><Icon name="play" /> CONTINUE DRIVING <kbd>P</kbd></button><button className="secondary full" onClick={onRestart}><Icon name="reset" size={17} /> RESTART DRIVE</button><div className="pause-links"><button className="text-button" onClick={onMenu}>Main menu</button><button className="text-button" onClick={onFinish}>Finish & view results <Icon name="arrow" size={15} /></button></div></section></div>;
}

export function FinishPanel({ telemetry, best, onDrive, onMenu }: { telemetry: Telemetry; best: number; onDrive: () => void; onMenu: () => void }) {
  return <div className="pause-backdrop"><section className="pause-panel finish-panel"><Icon name="flag" size={30} /><span className="eyebrow">DRIVE COMPLETE</span><h2>One More Run?</h2><p>{telemetry.damage >= 100 ? 'Your car needs a little time in the workshop.' : 'Every drive has a story. That was yours.'}</p><div className="result-hero">{telemetry.score.toLocaleString()}<small>TOTAL POINTS</small></div><div className="result-details"><span>{telemetry.distance.toFixed(2)}<small>KILOMETERS</small></span><span>{telemetry.nearMisses}<small>CLOSE CALLS</small></span><span>{Math.floor(telemetry.seconds / 60)}:{String(Math.floor(telemetry.seconds % 60)).padStart(2, '0')}<small>DRIVE TIME</small></span></div><p className="best-note">PERSONAL BEST <strong>{best.toLocaleString()} POINTS</strong></p><button className="primary full" onClick={onDrive}><Icon name="play" /> DRIVE AGAIN <Icon name="arrow" /></button><button className="text-button centered" onClick={onMenu}>Back to main menu</button></section></div>;
}