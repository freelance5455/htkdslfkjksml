import { useEffect, useRef, useState } from 'react';
import { checkAndroidRelease, downloadAndroidApk, exportAndroidSource, type AndroidRelease } from '../platform/android';
import { Dialog } from './Panels';
import { Icon } from './Icon';
import './android.css';

export function AndroidPanel({ onClose, onOffline }: { onClose: () => void; onOffline: () => void }) {
  const [status, setStatus] = useState<'checking' | 'missing' | 'available' | 'failed'>('checking');
  const [release, setRelease] = useState<AndroidRelease | null>(null);
  const [busy, setBusy] = useState<'source' | 'apk' | null>(null);
  const [message, setMessage] = useState('');
  const [retry, setRetry] = useState(0);
  const alive = useRef(true), downloadController = useRef<AbortController | null>(null);

  useEffect(() => {
    alive.current = true;
    return () => { alive.current = false; downloadController.current?.abort(); };
  }, []);
  useEffect(() => {
    const controller = new AbortController();
    let current = true;
    setStatus('checking'); setRelease(null);
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    void checkAndroidRelease(controller.signal).then(data => {
      if (current) { setRelease(data); setStatus(data ? 'available' : 'missing'); }
    }).catch(() => { if (current) setStatus('failed'); }).finally(() => window.clearTimeout(timeout));
    return () => { current = false; window.clearTimeout(timeout); controller.abort(); };
  }, [retry]);

  const source = async () => {
    if (busy) return;
    setBusy('source'); setMessage('');
    try {
      await exportAndroidSource();
      if (alive.current) setMessage('دانلود پروژهٔ ZIP آغاز شد. این فایل قابل نصب نیست؛ راه ساخت APK داخل آن است.');
    } catch {
      if (alive.current) setMessage('خروجی آمادهٔ وب پیدا نشد. ابتدا بیلد وب را انجام دهید؛ سپس دوباره دریافت سورس را بزنید.');
    } finally { if (alive.current) setBusy(null); }
  };
  const apk = async () => {
    if (!release || busy) return;
    setBusy('apk'); setMessage('');
    const controller = new AbortController(); downloadController.current = controller;
    const timeout = window.setTimeout(() => controller.abort(), 90000);
    try {
      await downloadAndroidApk(release, controller.signal);
      if (alive.current) setMessage('دریافت فایل APK آغاز شد. برای نصب، فایل را از بخش دانلودهای گوشی باز کنید.');
    } catch {
      if (alive.current) setMessage('دریافت یا بررسی APK موفق نشد. فایل نصب معتبر در دسترس نیست؛ اتصال و انتشار فایل را بررسی کنید.');
    } finally { window.clearTimeout(timeout); if (alive.current) setBusy(null); }
  };

  return <Dialog title="نسخهٔ اندروید جاده" subtitle="ANDROID / PEUGEOT 405 GLX" onClose={onClose}>
    <div className="dialog-body android-panel" lang="fa" dir="rtl">
      <div className={`android-status status-${status}`} role="status">
        <Icon name={status === 'available' ? 'check' : 'phone'} size={26} />
        <div><h3>{status === 'checking' ? 'بررسی فایل نصب…' : status === 'available' ? 'APK آزمایشی منتشر شده' : status === 'failed' ? 'وضعیت فایل قابل بررسی نیست' : 'APK هنوز ساخته نشده'}</h3>
          <p>{status === 'available' ? 'نسخهٔ Debug برای نصب مستقیم؛ انتشار رسمی فروشگاهی نیست.' : status === 'checking' ? 'فقط فایل نصب منتشرشده برای دانلود ارائه می‌شود.' : 'سورس اندروید آمادهٔ ساخت است، اما فایل APK قابل نصب در این سایت در دسترس نیست.'}</p>
        </div>
      </div>
      {release && <>
        <dl className="android-facts"><div><dt>نسخه</dt><dd dir="ltr">{release.version}</dd></div><div><dt>اندروید</dt><dd>{release.minAndroid} و بالاتر</dd></div><div><dt>حجم دانلود</dt><dd dir="ltr">{(release.sizeBytes / 1048576).toFixed(1)} MB</dd></div></dl>
        <button className="primary full android-primary" onClick={() => void apk()} disabled={!!busy}><Icon name="download" size={18} />{busy === 'apk' ? 'بررسی و دریافت فایل…' : 'دانلود APK اندروید'}</button>
        <p className="android-note">قبل از نصب، WebView گوشی را به‌روز کنید. نصب نسخه‌های آزمایشی بعدی ممکن است به حذف نسخه قبلی نیاز داشته باشد؛ حذف برنامه، ذخیره‌های آن را پاک می‌کند.</p>
      </>}
      {!release && <p className="android-honest">فایل HTML یا ZIP جای APK نیست. برای فایل نصب، باید پروژه با ابزارهای اندروید ساخته و امضا شود. ساخت اندروید در این محیط انجام نشده است.</p>}
      <div className="android-source"><h3>مسیر ساخت APK واقعی</h3><p>پروژهٔ اندروید همراه آخرین نسخهٔ بازی را بگیرید و با ساخت خودکار GitHub خروجی نصب تولید کنید.</p>
        <ol className="android-steps"><li>فایل ZIP را استخراج و محتویاتش، از جمله پوشهٔ <bdi>.github</bdi>، را در مخزن GitHub خود قرار دهید.</li><li>از بخش <bdi>Actions</bdi>، گزینهٔ <bdi>Build Android APK</bdi> و سپس <bdi>Run workflow</bdi> را بزنید.</li><li>پس از ساخت موفق، از <bdi>Artifacts</bdi> بستهٔ <bdi>JADEH-405-GLX-Android-APK</bdi> را بگیرید و APK داخلش را نصب کنید.</li></ol>
        <button className={`${release ? 'secondary' : 'primary'} full android-primary`} onClick={() => void source()} disabled={!!busy}><Icon name="download" size={17} />{busy === 'source' ? 'بسته‌بندی پروژه…' : 'دریافت پروژهٔ اندروید (ZIP)'}</button>
        <p className="android-note">ZIP سورس است، نه فایل نصب. بازی کامل و راهنمای فارسی داخل آن قرار دارند. ساخت به اینترنت نیاز دارد؛ اجرای نسخهٔ ساخته‌شده آفلاین است.</p>
      </div>
      {message && <p className="android-message" role="status">{message}</p>}
    </div>
    <footer className="dialog-footer android-footer"><button className="text-button" onClick={onOffline} disabled={!!busy}>دریافت نسخهٔ HTML</button><button className="text-button" onClick={() => { setMessage(''); setRetry(v => v + 1); }} disabled={status === 'checking' || !!busy}><Icon name="reset" size={14} />بررسی دوبارهٔ APK</button></footer>
  </Dialog>;
}