import { VEHICLES, VEHICLE_LIST } from '../sim/vehicles';
import type { Preferences, VehicleId } from '../sim/types';
import { Icon } from './Icon';
import './garage.css';

export function Garage({ prefs, interior, onVehicle, onPaint, onView, onDrive, onMenu }: {
  prefs: Preferences; interior: boolean;
  onVehicle: (id: VehicleId) => void; onPaint: (paint: string) => void;
  onView: (inside: boolean) => void; onDrive: (cockpit?: boolean) => void; onMenu: () => void;
}) {
  const spec = VEHICLES[prefs.vehicleId];
  if (interior) return <div className="cabin-preview-ui">
    <div className="cabin-preview-title"><span className="eyebrow">DRIVER'S SEAT / نمای کابین</span><h2>{spec.name} <span>{spec.model.endsWith('GLX') ? 'GLX' : 'SE'}</span></h2><p lang="fa" dir="rtl">فرمان، عقربه‌ها و آینهٔ عقب داخل بازی فعال هستند.</p></div>
    <div className="cabin-preview-actions"><button className="secondary" onClick={() => onView(false)}><Icon name="back" size={16} /><span lang="fa">نمای بیرونی</span></button><button className="primary" onClick={() => onDrive(true)}><Icon name="play" size={18} /><span lang="fa">رانندگی از داخل کابین</span><Icon name="arrow" size={17} /></button></div>
  </div>;
  return <>
    <section className="garage-copy garage-expanded">
      <button className="back-link" onClick={onMenu}><Icon name="back" size={16} /> BACK TO THE ROAD</button>
      <div className="vehicle-picker" role="group" aria-label="انتخاب خودرو / Select your car">
        {VEHICLE_LIST.map((car, i) => <button key={car.id} aria-pressed={prefs.vehicleId === car.id} className={prefs.vehicleId === car.id ? 'chosen' : ''} onClick={() => onVehicle(car.id)}><span className="vehicle-index">0{i + 1}</span><span>{car.shortName}<small lang="fa">{car.id === 'saipa141' ? 'سایپا ۱۴۱' : 'پژو ۴۰۵'}</small></span>{prefs.vehicleId === car.id && <Icon name="check" size={14} />}</button>)}
      </div>
      <span className="eyebrow">{spec.maker} / {prefs.vehicleId === 'saipa141' ? 'REFERENCE COLLECTION' : 'SPORT TUNE'}</span>
      <h1>{prefs.vehicleId === 'saipa141' ? 'SAIPA' : 'PEUGEOT'}<br /><span>{spec.model}</span></h1>
      <p className="garage-fa" lang="fa">{spec.nameFa}</p>
      <p className="garage-description">{spec.description}</p>
      <dl className="car-specs"><div><dt>ENGINE</dt><dd>{spec.engine}</dd></div><div><dt>{prefs.vehicleId === 'peugeot405' ? 'SPORT POWER' : 'POWER'}</dt><dd>{spec.tune.powerHp} <small>HP</small></dd></div><div><dt>CUT-OFF</dt><dd>{(spec.tune.redline / 1000).toFixed(1)} <small>K RPM</small></dd></div></dl>
      <div className="paint-picker"><span className="eyebrow">PAINT FINISH <b>{spec.colors.find(c => c.value === prefs.color)?.name}</b></span><div>{spec.colors.map(c => <button key={c.value} className={`paint-swatch ${prefs.color === c.value ? 'selected' : ''}`} style={{ background: c.value }} title={c.name} aria-label={`Select ${c.name} paint`} aria-pressed={prefs.color === c.value} onClick={() => onPaint(c.value)}>{prefs.color === c.value && <Icon name="check" size={15} />}</button>)}</div></div>
      <button className="cabin-inspect-button" onClick={() => onView(true)}><Icon name="camera" size={17} /><span>EXPLORE THE COCKPIT <small lang="fa">مشاهدهٔ داخل کابین</small></span><Icon name="right" size={16} /></button>
      <button className="primary start-button" onClick={() => onDrive()}><Icon name="play" /> TAKE IT FOR A DRIVE <Icon name="arrow" /></button>
    </section>
    <div className="garage-caption"><span className="orbit-icon"><Icon name="reset" size={18} /></span><span>DRAG TO LOOK AROUND</span><small>{prefs.vehicleId === 'saipa141' ? 'SAIPA 141 / YOUR REFERENCE' : 'PEUGEOT 405 / GLX INTERIOR'}</small></div>
  </>;
}