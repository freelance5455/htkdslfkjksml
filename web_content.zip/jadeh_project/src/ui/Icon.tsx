import type { CSSProperties, ReactNode } from 'react';

export type IconName = 'play' | 'pause' | 'settings' | 'volume' | 'muted' | 'fullscreen' | 'sun' | 'sunset' | 'moon' | 'left' | 'right' | 'arrow' | 'close' | 'keyboard' | 'camera' | 'reset' | 'download' | 'road' | 'car' | 'rain' | 'check' | 'phone' | 'horn' | 'info' | 'back' | 'flag' | 'handbrake' | 'rev';

const paths: Record<IconName, ReactNode> = {
  play: <path d="m8 5 11 7-11 7Z" fill="currentColor" stroke="none" />,
  pause: <><path d="M8 5v14M16 5v14" strokeWidth="3" /></>,
  settings: <><path d="m9 3-.6 2.2-2 .9L4.3 5.5 2 9.4 3.5 11v2L2 14.6l2.3 3.9 2.1-.6 2 .9L9 21h6l.6-2.2 2-.9 2.1.6 2.3-3.9-1.5-1.6v-2L22 9.4l-2.3-3.9-2.1.6-2-.9L15 3Z" /><circle cx="12" cy="12" r="3.2" /></>,
  volume: <><path d="m11 4-6 5H2v6h3l6 5ZM15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14" /></>,
  muted: <><path d="m11 4-6 5H2v6h3l6 5ZM16 9l6 6m0-6-6 6" /></>,
  fullscreen: <path d="M9 3H3v6m12-6h6v6M3 15v6h6m12-6v6h-6" />,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5" /></>,
  sunset: <><path d="M3 18h18M5 22h14M7 15a5 5 0 0 1 10 0M12 2v4M2 11l3 1m14 0 3-1M5 5l2 2m10 0 2-2" /></>,
  moon: <path d="M20.8 14A9.1 9.1 0 0 1 10 3.2 9.2 9.2 0 1 0 20.8 14Z" />,
  left: <path d="m14.5 5-7 7 7 7" />,
  right: <path d="m9.5 5 7 7-7 7" />,
  arrow: <path d="M3 12h17m-6-6 6 6-6 6" />,
  back: <path d="M21 12H4m6-6-6 6 6 6" />,
  close: <path d="m6 6 12 12M6 18 18 6" />,
  keyboard: <><rect x="2" y="5" width="20" height="14" rx="2" /><path d="M6 9h.1M10 9h.1M14 9h.1M18 9h.1M6 12h.1M10 12h.1M14 12h.1M18 12h.1M7 16h10" strokeWidth="2" /></>,
  camera: <><path d="M8 5 6 8H3v12h18V8h-3l-2-3Z" /><circle cx="12" cy="13" r="3.5" /></>,
  reset: <><path d="M3 10a9 9 0 1 1 1 8M3 3v7h7" /></>,
  download: <path d="M12 2v13m-5-5 5 5 5-5M4 16v5h16v-5" />,
  road: <><path d="M7 3 2 21M17 3l5 18M12 3v3m0 4v4m0 4v3" /></>,
  car: <><path d="m4 10 2-6h12l2 6M3 10h18v8H3ZM5 18v3m14-3v3M6 14h2m8 0h2" /></>,
  rain: <><path d="M6 15a4 4 0 0 1 0-8 6 6 0 0 1 11-2 5 5 0 1 1 2 10M7 18l-1 3m7-3-1 3m7-3-1 3" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  phone: <><rect x="5" y="2" width="14" height="20" rx="2" /><path d="M10 18h4M2 7l-1 5 2 4m18-9 2 5-2 4" /></>,
  horn: <><path d="M7 9H3v6h4l8 5V4ZM19 8a6 6 0 0 1 0 8M7 15v6h4v-3" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v6m0-11v1" /></>,
  flag: <path d="M5 22V3h6l2 3h7v10h-7l-2-3H5" />,
  handbrake: <><circle cx="12" cy="12" r="6.5" /><path d="M10 16V8h3a2.3 2.3 0 0 1 0 4.6h-3M3 5a11 11 0 0 0 0 14M21 5a11 11 0 0 1 0 14" /></>,
  rev: <><path d="M4 18a9 9 0 1 1 16 0M12 13l5-7M5 12H3m9-9v2m7 7h2" /><circle cx="12" cy="14" r="1.5" /><path d="M9 20h6" /></>,
};

export function Icon({ name, size = 20, style }: { name: IconName; size?: number; style?: CSSProperties }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={style}>{paths[name]}</svg>;
}

export function Brand({ large = false }: { large?: boolean }) {
  return <span className={`brand ${large ? 'brand-large' : ''}`}><svg viewBox="0 0 36 40" fill="none" aria-hidden="true"><path d="m13 2-9 36h5L17 2h-4Zm11 0 8 36h-5L20 2h4Z" fill="currentColor"/><path d="M19 5v6m-1 5v8m-1 6v8" stroke="currentColor" strokeWidth="2"/></svg><span>JADEH<span className="brand-fa" lang="fa">جاده</span></span></span>;
}