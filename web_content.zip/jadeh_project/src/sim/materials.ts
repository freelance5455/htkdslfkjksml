import * as T from 'three';
import asphaltUrl from '../assets/asphalt.jpg';
import terrainUrl from '../assets/terrain.jpg';
import facadeUrl from '../assets/facade.jpg';
import facade2Url from '../assets/facade2.jpg';
import { random } from './types';

export function canvasTexture(w: number, h: number, paint: (ctx: CanvasRenderingContext2D) => void) {
  const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
  const context = canvas.getContext('2d');
  if (context) paint(context);
  const texture = new T.CanvasTexture(canvas);
  texture.colorSpace = T.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

export function textTexture(text: string, color = '#d5d8d5', background = 'transparent', w = 512, h = 128) {
  return canvasTexture(w, h, ctx => {
    if (background !== 'transparent') { ctx.fillStyle = background; ctx.fillRect(0, 0, w, h); }
    ctx.fillStyle = color; ctx.font = `600 ${h * 0.5}px Arial, Tahoma, sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, w / 2, h / 2);
  });
}

export function plateTexture(serial = '۴۰۵') {
  return canvasTexture(512, 128, c => {
    c.fillStyle = '#e7e9e1'; c.fillRect(0, 0, 512, 128);
    c.fillStyle = '#163563'; c.fillRect(4, 4, 56, 120);
    ['#308750', '#f4f4f4', '#b33230'].forEach((color, i) => { c.fillStyle = color; c.fillRect(14, 12 + i * 9, 34, 9); });
    c.fillStyle = '#fff'; c.font = '14px Arial'; c.fillText('I.R.', 19, 80); c.fillText('IRAN', 10, 104);
    c.fillStyle = '#182024'; c.font = 'bold 65px Tahoma, sans-serif'; c.textAlign = 'center';
    c.fillText(`۱۲ ب ${serial}`, 262, 89); c.font = '19px Tahoma'; c.fillText('ایران', 468, 28);
    c.font = 'bold 48px Tahoma'; c.fillText('۲۱', 468, 91);
    c.strokeStyle = '#303531'; c.lineWidth = 5; c.strokeRect(2, 2, 508, 124); c.fillRect(424, 2, 3, 124);
  });
}

export function lensTexture() {
  return canvasTexture(128, 128, c => {
    c.fillStyle = '#c8d0cb'; c.fillRect(0, 0, 128, 128);
    for (let i = 0; i < 128; i += 6) {
      c.fillStyle = 'rgba(255,255,255,.38)'; c.fillRect(i, 0, 2, 128);
      c.fillStyle = 'rgba(30,45,48,.24)'; c.fillRect(0, i, 128, 1);
    }
  });
}

export function upholsteryTexture() {
  const texture = canvasTexture(128, 128, c => {
    c.fillStyle = '#353b3a'; c.fillRect(0, 0, 128, 128);
    for (let y = 0; y < 128; y += 4) for (let x = 0; x < 128; x += 4) {
      c.fillStyle = (x + y) % 8 === 0 ? '#444b48' : '#293330';
      c.fillRect(x, y, 2, 3);
    }
    for (let y = 8; y < 128; y += 25) {
      c.fillStyle = '#606763'; c.fillRect(0, y, 128, 1);
    }
  });
  texture.wrapS = texture.wrapT = T.RepeatWrapping;
  texture.repeat.set(2, 3);
  return texture;
}

export function dashboardTexture() {
  return canvasTexture(512, 192, c => {
    c.fillStyle = '#111918'; c.fillRect(0, 0, 512, 192);
    const gauge = (x: number, label: string, step: number) => {
      c.strokeStyle = '#3b4541'; c.lineWidth = 3; c.beginPath(); c.arc(x, 101, 80, 0, Math.PI * 2); c.stroke();
      c.font = '11px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle';
      for (let i = 0; i <= 24; i++) {
        const a = Math.PI * 0.78 + i / 24 * Math.PI * 1.44;
        c.strokeStyle = i >= 21 ? '#db7453' : '#c4cabe'; c.lineWidth = i % 4 ? 1 : 2;
        c.beginPath(); c.moveTo(x + Math.cos(a) * 68, 101 + Math.sin(a) * 68);
        c.lineTo(x + Math.cos(a) * (i % 4 ? 64 : 59), 101 + Math.sin(a) * (i % 4 ? 64 : 59)); c.stroke();
        if (i % 4 === 0) { c.fillStyle = '#c9ceb9'; c.fillText(String(i / 4 * step), x + Math.cos(a) * 47, 101 + Math.sin(a) * 47); }
      }
      c.fillStyle = '#8fada0'; c.font = '10px Arial'; c.fillText(label, x, 131);
    };
    gauge(137, 'km/h', 40); gauge(372, 'RPM x1000', 1.2);
    c.fillStyle = '#34423a'; c.fillRect(98, 142, 78, 17);
    c.fillStyle = '#d3d3b5'; c.font = '12px monospace'; c.textAlign = 'center'; c.fillText('040505', 137, 154);
    c.fillStyle = '#bc644c'; c.fillRect(250, 76, 10, 7); c.fillStyle = '#a99952'; c.fillRect(250, 111, 10, 7);
  });
}

export function tyreSidewallTexture(size = '185/65 R14') {
  return canvasTexture(256, 256, c => {
    c.translate(128, 128); c.fillStyle = '#818681'; c.textAlign = 'center'; c.font = '600 11px Arial';
    const arcText = (text: string, start: number) => {
      [...text].forEach((letter, i) => { c.save(); c.rotate(start + i * 0.085); c.fillText(letter, 0, -103); c.restore(); });
    };
    arcText('RADIAL TUBELESS', -0.56); arcText(size, Math.PI - 0.37);
    c.strokeStyle = '#626963'; c.lineWidth = 1;
    [87, 117].forEach(r => { c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.stroke(); });
  });
}

export function signTexture(fa: string, en: string, direction = 'straight') {
  return canvasTexture(1024, 400, c => {
    c.fillStyle = '#164b73'; c.fillRect(0, 0, 1024, 400);
    c.strokeStyle = '#e0e8e2'; c.lineWidth = 9; c.strokeRect(14, 14, 996, 372);
    c.fillStyle = '#f5f6ea'; c.font = 'bold 94px Tahoma, sans-serif'; c.textAlign = 'center'; c.direction = 'rtl';
    c.fillText(fa, 555, 148); c.direction = 'ltr'; c.font = '44px Arial'; c.fillText(en.toUpperCase(), 555, 244);
    c.font = '32px Arial'; c.fillText(direction === 'exit' ? 'EXIT 12' : 'FREEWAY 2', 555, 327);
    c.lineWidth = 17; c.lineCap = 'square'; c.beginPath(); c.moveTo(145, 303); c.lineTo(145, 120);
    c.moveTo(99, 171); c.lineTo(145, 119); c.lineTo(191, 171); c.stroke();
  });
}

export function shadowTexture() {
  return canvasTexture(128, 128, c => {
    const g = c.createRadialGradient(64, 64, 15, 64, 64, 64);
    g.addColorStop(0, 'rgba(0,0,0,.7)'); g.addColorStop(0.5, 'rgba(0,0,0,.5)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    c.fillStyle = g; c.fillRect(0, 0, 128, 128);
  });
}

export function particleTexture() {
  return canvasTexture(64, 64, c => {
    const g = c.createRadialGradient(32, 32, 2, 32, 32, 32);
    g.addColorStop(0, 'rgba(255,255,255,.85)'); g.addColorStop(0.4, 'rgba(255,255,255,.4)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    c.fillStyle = g; c.fillRect(0, 0, 64, 64);
  });
}

export function environmentTexture(night = false) {
  const texture = canvasTexture(2048, 1024, c => {
    c.scale(2, 2);
    const sky = c.createLinearGradient(0, 0, 0, 512);
    sky.addColorStop(0, night ? '#080f21' : '#5a7b91');
    sky.addColorStop(0.47, night ? '#334255' : '#e3cfaf');
    sky.addColorStop(0.52, night ? '#26302c' : '#81745c');
    sky.addColorStop(1, night ? '#080a0e' : '#46433b');
    c.fillStyle = sky; c.fillRect(0, 0, 1024, 512);
    const glow = c.createRadialGradient(735, 200, 3, 735, 200, 120);
    glow.addColorStop(0, night ? '#dceaff' : '#fff4d6'); glow.addColorStop(0.2, night ? '#687289' : '#f4dfb7'); glow.addColorStop(1, 'rgba(225,192,149,0)');
    c.fillStyle = glow; c.fillRect(550, 70, 370, 260);
    for (let i = 0; i < 30; i++) {
      c.fillStyle = night ? 'rgba(140,160,185,.04)' : 'rgba(255,249,226,.12)';
      c.beginPath(); c.ellipse(random(i + 5) * 1024, 80 + random(i + 12) * 135, 25 + random(i) * 70, 3 + random(i + 70) * 8, 0, 0, Math.PI * 2); c.fill();
    }
  });
  texture.mapping = T.EquirectangularReflectionMapping;
  return texture;
}

export async function loadTextures() {
  const loader = new T.TextureLoader();
  const load = async (url: string, fallback: string) => {
    try { return await loader.loadAsync(url); }
    catch { return canvasTexture(64, 64, c => { c.fillStyle = fallback; c.fillRect(0, 0, 64, 64); }); }
  };
  const [road, dirt, facade, facade2] = await Promise.all([
    load(asphaltUrl, '#55544f'), load(terrainUrl, '#b9a78a'), load(facadeUrl, '#c6b7a1'), load(facade2Url, '#b3a18a'),
  ]);
  [road, dirt, facade, facade2].forEach(t => { t.colorSpace = T.SRGBColorSpace; t.anisotropy = 8; });
  road.wrapS = road.wrapT = T.RepeatWrapping; road.repeat.set(3, 70);
  dirt.wrapS = dirt.wrapT = T.RepeatWrapping; dirt.repeat.set(35, 100);
  return { road, dirt, facade, facade2 };
}