import type { VehicleId } from './types';

// Locally synthesized combustion cycles, not recordings. Ringing impulses replace a sawtooth buzz.
export function combustionLoop(context: AudioContext, referenceRpm: number, vehicle: VehicleId, exhaust = false) {
  const cycles = 12, seconds = cycles * 120 / referenceRpm;
  const buffer = context.createBuffer(1, Math.ceil(context.sampleRate * seconds), context.sampleRate);
  const samples = buffer.getChannelData(0), sampleRate = context.sampleRate;
  const pride = vehicle === 'saipa141';
  let seed = Math.round(referenceRpm) + (pride ? 719 : 401);
  const noise = () => { seed = (Math.imul(seed, 1664525) + 1013904223) | 0; return (seed >>> 0) / 4294967296 * 2 - 1; };
  const pulseSpacing = samples.length / (cycles * 4);
  const ringHz = exhaust ? pride ? 111 : 84 : pride ? 181 : 144;
  const strengths = pride ? [1, 0.94, 1.05, 0.97] : [1.04, 0.98, 1.00, 0.95];
  for (let pulse = 0; pulse < cycles * 4; pulse++) {
    const start = Math.round(pulse * pulseSpacing + noise() * pulseSpacing * 0.014);
    const strength = strengths[pulse % 4] * (1 + noise() * 0.055);
    const decay = exhaust ? 0.023 : 0.014;
    let filteredNoise = 0;
    for (let j = 0; j < Math.ceil(sampleRate * 0.072); j++) {
      const t = j / sampleRate;
      const envelope = (1 - Math.exp(-t * 4200)) * Math.exp(-t / decay);
      filteredNoise = filteredNoise * 0.64 + noise() * 0.36;
      const ring = Math.sin(2 * Math.PI * ringHz * t) + 0.31 * Math.sin(2 * Math.PI * ringHz * 2.7 * t + 0.2);
      const combustion = ring * envelope;
      const ignition = filteredNoise * Math.exp(-t / 0.0042) * (exhaust ? 0.38 : 0.67);
      const valve = Math.sin(2 * Math.PI * (pride ? 1210 : 960) * t) * Math.exp(-t / 0.0022) * 0.12;
      const index = ((start + j) % samples.length + samples.length) % samples.length;
      samples[index] += (combustion + ignition + (exhaust ? 0 : valve)) * strength;
    }
  }
  let mean = 0, peak = 0;
  for (const value of samples) mean += value;
  mean /= samples.length;
  for (let i = 0; i < samples.length; i++) { samples[i] -= mean; peak = Math.max(peak, Math.abs(samples[i])); }
  const gain = 0.82 / Math.max(peak, 0.01);
  for (let i = 0; i < samples.length; i++) samples[i] *= gain;
  return buffer;
}