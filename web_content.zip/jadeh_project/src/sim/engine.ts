import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { HighwayAudio } from './audio';
import { environmentTexture, loadTextures, particleTexture, shadowTexture } from './materials';
import { makePeugeot, trafficGeometry } from './peugeot';
import { makeSaipa141 } from './saipa141';
import type { VehicleModel } from './vehicleModel';
import { disposeModel } from './modelGeometry';
import { VEHICLES } from './vehicles';
import { SportPowertrain } from './powertrain';
import { Highway } from './highway';
import { CAMERA_NAMES, COCKPIT_CAMERA, clamp, damp, random, EMPTY_TELEMETRY, type Controls, type Mode, type Preferences, type Telemetry } from './types';

interface TrafficCar {
  id: number; kind: number; lane: number; target: number; x: number; s: number;
  speed: number; desired: number; dir: number; timer: number; brake: number; passed: boolean; yaw: number;
}
interface Particle { x: number; y: number; z: number; vx: number; vy: number; life: number; color: T.Color }
export interface EngineEvents {
  hud: (telemetry: Telemetry) => void;
  notice: (text: string, type: 'close' | 'hit' | 'info') => void;
  finish: (telemetry: Telemetry) => void;
  error: (message: string) => void;
}

const lanes = [-3.65, 0, 3.65], opposite = [-10, -13.6, -17.2];
const dummy = new T.Object3D();

export class DrivingEngine {
  readonly controls: Controls = { gas: false, brake: false, left: false, right: false, handbrake: false, horn: false, rev: false };
  mode: Mode = 'menu';
  ready = false;
  private renderer: T.WebGLRenderer;
  private scene = new T.Scene();
  private camera = new T.PerspectiveCamera(56, 1, 0.08, 1800);
  private sun = new T.DirectionalLight('#ffe4b4', 2.8);
  private ambient = new T.HemisphereLight('#d6e5ee', '#67604c', 2.0);
  private streetLights = [new T.PointLight('#ffcc8c', 48, 28, 1.8), new T.PointLight('#ffcc8c', 48, 28, 1.8)];
  private player: VehicleModel;
  private highway: Highway | null = null;
  private audio = new HighwayAudio();
  private powertrain = new SportPowertrain();
  private prefs: Preferences;
  private observer: ResizeObserver;
  private destroyed = false;
  private environment: T.WebGLRenderTarget | null = null;
  private skyTexture: T.Texture | null = null;
  private cars: TrafficCar[] = [];
  private trafficMeshes: T.InstancedMesh[] = [];
  private trafficBrakes: T.InstancedMesh;
  private trafficShadows: T.InstancedMesh;
  private headlight: T.SpotLight;
  private particles: Particle[] = [];
  private particleMesh: T.Points;
  private rain: T.LineSegments;
  private rainArray: Float32Array;
  private time = 0;
  private lastTime = 0;
  private hudTime = 0;
  private frameCount = 0;
  private fpsTime = 0;
  private fps = 60;
  private telemetry = { ...EMPTY_TELEMETRY };
  private speed = 0;
  private x = 0;
  private lateralSpeed = 0;
  private steer = 0;
  private throttle = 0;
  private brake = 0;
  private handbrakeAmount = 0;
  private driftYaw = 0;
  private nearbyTraffic = 0;
  private pitchVelocity = 0;
  private rollVelocity = 0;
  private distance = 0;
  private collisionCooldown = 0;
  private lastPass = -100;
  private cameraMode = 0;
  private garageAngle = 2.33;
  private wheelAngle = 0;
  private rearWheelAngle = 0;
  private effectCutPulses = 0;
  private smokeBudget = 0;
  private shake = 0;
  private camLook = new T.Vector3();
  private targetPosition = new T.Vector3();
  private reducedDpr = 1;
  private renderDirty = true;
  private garageInterior = false;
  private insideView = false;
  private mirrorTarget = new T.WebGLRenderTarget(384, 112, { depthBuffer: true });
  private mirrorCamera = new T.PerspectiveCamera(46, 384 / 112, 0.15, 175);
  private mirrorTime = 0;
  private lastOdometer = '';
  private bufferSize = new T.Vector2();
  private localEye = new T.Vector3();
  private localLook = new T.Vector3();
  private vehicleQuaternion = new T.Quaternion();
  private slowFrames = 0;

  constructor(private container: HTMLElement, prefs: Preferences, private events: EngineEvents) {
    this.prefs = { ...prefs };
    this.renderer = new T.WebGLRenderer({ antialias: true, powerPreference: 'high-performance', alpha: false, precision: 'highp' });
    this.renderer.outputColorSpace = T.SRGBColorSpace;
    this.renderer.toneMapping = T.ACESFilmicToneMapping;
    this.renderer.shadowMap.type = T.PCFSoftShadowMap;
    this.renderer.domElement.setAttribute('aria-label', 'Interactive Iranian driving simulator with Peugeot 405 and Saipa 141');
    this.container.appendChild(this.renderer.domElement);
    this.camera.position.set(0, 3.1, 8.5); this.camera.lookAt(0, 0.8, -9);
    this.scene.add(this.ambient, this.sun, this.sun.target, ...this.streetLights);
    this.sun.position.set(-32, 55, -65); this.sun.target.position.set(0, 0, -25);
    this.sun.shadow.camera.left = -25; this.sun.shadow.camera.right = 25;
    this.sun.shadow.camera.top = 37; this.sun.shadow.camera.bottom = -25;
    this.sun.shadow.camera.near = 1; this.sun.shadow.camera.far = 170;
    this.sun.shadow.normalBias = 0.025; this.sun.shadow.bias = -0.00015;
    this.player = prefs.vehicleId === 'saipa141' ? makeSaipa141(prefs.color) : makePeugeot(prefs.color);
    this.powertrain.configure(VEHICLES[prefs.vehicleId].tune); this.scene.add(this.player.root);
    this.mirrorTarget.texture.colorSpace = T.SRGBColorSpace;
    this.mirrorTarget.texture.repeat.set(-1, 1); this.mirrorTarget.texture.offset.x = 1;
    this.connectMirror();

    const trafficMaterial = new T.MeshStandardMaterial({ vertexColors: true, metalness: 0.28, roughness: 0.4, side: T.DoubleSide });
    ['#f2f0e6', '#a9b5b5', '#eadc31', '#333d44', '#537c8b', '#e4e1d8'].forEach((color, i) => {
      const mesh = new T.InstancedMesh(trafficGeometry(color, i === 4 || i === 5), trafficMaterial, 12);
      mesh.instanceMatrix.setUsage(T.DynamicDrawUsage); mesh.frustumCulled = false; mesh.castShadow = true; mesh.receiveShadow = true;
      mesh.count = 0; this.scene.add(mesh); this.trafficMeshes.push(mesh);
    });
    const brakeParts = [-1, 1].map(side => new T.BoxGeometry(0.32, 0.064, 0.025).translate(side * 0.595, 0, 0));
    const brakeGeometry = mergeGeometries(brakeParts, false)!; brakeParts.forEach(g => g.dispose());
    this.trafficBrakes = new T.InstancedMesh(brakeGeometry, new T.MeshBasicMaterial({ color: '#ff3425' }), 50);
    this.trafficBrakes.instanceMatrix.setUsage(T.DynamicDrawUsage); this.trafficBrakes.frustumCulled = false; this.scene.add(this.trafficBrakes);
    this.trafficShadows = new T.InstancedMesh(new T.PlaneGeometry(2.5, 5.6), new T.MeshBasicMaterial({ map: shadowTexture(), transparent: true, depthWrite: false, opacity: 0.45 }), 50);
    this.trafficShadows.instanceMatrix.setUsage(T.DynamicDrawUsage); this.trafficShadows.frustumCulled = false; this.scene.add(this.trafficShadows);

    this.headlight = new T.SpotLight('#ffedc5', 65, 55, 0.39, 0.72, 1.6);
    this.headlight.position.set(0, 0.8, -2); this.headlight.target.position.set(0, 0, -23);
    this.scene.add(this.headlight, this.headlight.target);
    const positions = new Float32Array(140 * 3), colors = new Float32Array(140 * 3);
    for (let i = 0; i < 140; i++) {
      positions[i * 3 + 1] = -100;
      this.particles.push({ x: 0, y: -100, z: 0, vx: 0, vy: 0, life: 0, color: new T.Color('#aaa392') });
    }
    const particleGeometry = new T.BufferGeometry(); particleGeometry.setAttribute('position', new T.BufferAttribute(positions, 3)); particleGeometry.setAttribute('color', new T.BufferAttribute(colors, 3));
    particleGeometry.setAttribute('life', new T.BufferAttribute(new Float32Array(140), 1));
    const particleMaterial = new T.PointsMaterial({ map: particleTexture(), size: 0.58, transparent: true, opacity: 0.42, depthWrite: false, vertexColors: true });
    particleMaterial.onBeforeCompile = shader => {
      shader.vertexShader = 'attribute float life; varying float particleLife;\n' + shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nparticleLife = life;');
      shader.fragmentShader = 'varying float particleLife;\n' + shader.fragmentShader.replace('#include <color_fragment>', '#include <color_fragment>\ndiffuseColor.a *= particleLife;');
    };
    this.particleMesh = new T.Points(particleGeometry, particleMaterial);
    this.particleMesh.frustumCulled = false; this.scene.add(this.particleMesh);
    this.rainArray = new Float32Array(600 * 6);
    for (let i = 0; i < 600; i++) {
      const k = i * 6, x = (random(i + 1) - 0.5) * 58, y = random(i + 800) * 25, z = random(i + 1600) * 75 - 58;
      this.rainArray.set([x, y, z, x - 0.05, y - 0.52, z + 0.13], k);
    }
    const rainGeometry = new T.BufferGeometry(); rainGeometry.setAttribute('position', new T.BufferAttribute(this.rainArray, 3));
    this.rain = new T.LineSegments(rainGeometry, new T.LineBasicMaterial({ color: '#adbac3', transparent: true, opacity: 0.34 })); this.rain.frustumCulled = false; this.scene.add(this.rain);
    this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(container);
    this.renderer.domElement.addEventListener('webglcontextlost', this.onContextLost);
    this.configure(prefs); this.resetTraffic(); this.resize();
  }

  async init() {
    const textures = await loadTextures();
    if (this.destroyed) { Object.values(textures).forEach(t => t.dispose()); return; }
    this.highway = new Highway(textures); this.scene.add(this.highway.root); this.highway.configure(this.prefs);
    this.highway.update(0, 0); this.renderTraffic();
    this.renderer.render(this.scene, this.camera);
    this.ready = true;
    this.renderer.setAnimationLoop(this.tick);
  }

  configure(prefs: Preferences) {
    this.renderDirty = true;
    const oldTime = this.prefs.time;
    const oldDensity = this.prefs.density;
    const oldQuality = this.prefs.quality;
    const changedVehicle = prefs.vehicleId !== this.prefs.vehicleId;
    const changedAdaptive = prefs.adaptiveResolution !== this.prefs.adaptiveResolution;
    this.prefs = { ...prefs };
    if (changedVehicle) {
      disposeModel(this.player.root);
      this.player = prefs.vehicleId === 'saipa141' ? makeSaipa141(prefs.color) : makePeugeot(prefs.color);
      this.scene.add(this.player.root); this.connectMirror();
      this.powertrain.configure(VEHICLES[prefs.vehicleId].tune);
      this.reset(); this.insideView = false;
      this.garageAngle = prefs.vehicleId === 'saipa141' ? -0.82 : 2.33;
    }
    this.audio.configure(prefs.volume, prefs.muted, prefs.sportExhaust, prefs.vehicleId);
    this.player.paint.color.set(prefs.color);
    this.sun.castShadow = prefs.quality !== 'low'; this.renderer.shadowMap.enabled = prefs.quality !== 'low';
    const mapSize = prefs.quality === 'high' ? 2048 : 1024;
    this.sun.shadow.mapSize.set(mapSize, mapSize);
    if (oldQuality !== prefs.quality) {
      this.sun.shadow.map?.dispose(); this.sun.shadow.map = null;
      this.mirrorTarget.setSize(prefs.quality === 'high' ? 512 : prefs.quality === 'medium' ? 384 : 192, prefs.quality === 'high' ? 150 : prefs.quality === 'medium' ? 112 : 56);
    }
    if (oldQuality !== prefs.quality || changedAdaptive) { this.reducedDpr = 1; this.slowFrames = 0; }
    if (!this.skyTexture || oldTime !== prefs.time) {
      this.environment?.dispose(); this.skyTexture?.dispose();
      this.skyTexture = environmentTexture(prefs.time === 'night');
      const generator = new T.PMREMGenerator(this.renderer);
      this.environment = generator.fromEquirectangular(this.skyTexture); generator.dispose();
      this.scene.background = this.skyTexture; this.scene.environment = this.environment.texture;
    }
    const night = prefs.time === 'night';
    this.scene.fog = new T.Fog(night ? '#0d1727' : prefs.weather === 'rain' ? '#8b9b9e' : prefs.time === 'day' ? '#abbac0' : '#c0b29a', night ? 32 : 80, night ? 260 : prefs.weather === 'rain' ? 310 : 710);
    this.sun.color.set(night ? '#7898d2' : prefs.time === 'day' ? '#fff3dc' : '#ffd9aa');
    this.sun.intensity = night ? 0.3 : prefs.weather === 'rain' ? 0.8 : 2.65;
    this.ambient.intensity = night ? 0.38 : 1.8;
    this.renderer.toneMappingExposure = night ? 0.83 : 1.08;
    this.scene.environmentIntensity = night ? 0.35 : 0.85;
    this.player.lightMaterial.emissiveIntensity = night ? 2.2 : 0.14;
    this.headlight.visible = night; this.rain.visible = prefs.weather === 'rain';
    this.player.cabin?.illumination.forEach(mat => { mat.emissiveIntensity = night ? 1.1 : 0.22; });
    this.streetLights.forEach((light, i) => { light.visible = night && (prefs.quality !== 'low' || i === 0); });
    this.highway?.configure(prefs);
    this.updateTextureClarity();
    if (oldDensity !== prefs.density) this.resetTraffic();
    this.resize();
  }

  private resize() {
    if (this.destroyed) return;
    const width = this.container.clientWidth || 1, height = this.container.clientHeight || 1;
    const high = this.prefs.quality === 'high';
    const cap = high ? 2.5 : this.prefs.quality === 'medium' ? 1.65 : 1;
    const maxPixels = high ? 7600000 : this.prefs.quality === 'medium' ? 4100000 : 2100000;
    const ratio = Math.min(Math.max(window.devicePixelRatio || 1, high ? 1.25 : 1), cap, Math.sqrt(maxPixels / (width * height)));
    this.renderer.setPixelRatio(ratio * (this.prefs.adaptiveResolution ? this.reducedDpr : 1));
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height; this.camera.updateProjectionMatrix();
    this.renderDirty = true;
  }

  private updateTextureClarity() {
    const level = Math.min(this.renderer.capabilities.getMaxAnisotropy(), this.prefs.quality === 'high' ? 16 : this.prefs.quality === 'medium' ? 8 : 2);
    const seen = new Set<T.Texture>();
    this.scene.traverse(o => {
      if (!(o instanceof T.Mesh)) return;
      for (const mat of Array.isArray(o.material) ? o.material : [o.material]) {
        for (const value of Object.values(mat)) {
          if (!(value instanceof T.Texture) || value.isRenderTargetTexture || seen.has(value)) continue;
          seen.add(value); if (value.anisotropy !== level) { value.anisotropy = level; value.needsUpdate = true; }
        }
      }
    });
  }

  private connectMirror() {
    if (this.player.cabin) { this.player.cabin.mirror.material.map = this.mirrorTarget.texture; this.player.cabin.mirror.material.color.set('#f0f0e7'); this.player.cabin.mirror.material.needsUpdate = true; }
  }

  async start(reset = true, cockpit?: boolean) {
    if (!this.ready) return;
    if (reset) this.reset();
    if (typeof cockpit === 'boolean') this.cameraMode = cockpit ? COCKPIT_CAMERA : 0;
    this.mode = 'playing'; this.lastTime = 0; this.garageInterior = false;
    this.updateCamera(1);
    this.events.hud(this.snapshot());
    try { await this.audio.start(); } catch { this.events.notice('Audio unavailable. The drive is still ready.', 'info'); }
  }
  pause() { this.mode = 'paused'; this.audio.pause(); this.clearControls(); this.renderDirty = true; }
  menu() { this.pause(); this.mode = 'menu'; this.player.root.visible = true; this.setInterior(false); }
  garage() {
    this.pause(); this.mode = 'garage'; this.garageInterior = false;
    this.garageAngle = this.prefs.vehicleId === 'saipa141' ? -0.82 : 2.33; this.setInterior(false);
    this.player.root.position.set(0, 0, 0); this.player.root.rotation.set(0, 0, 0); this.player.body.rotation.set(0, 0, 0);
    if (this.player.cabin) {
      this.player.cabin.steeringWheel.rotation.z = 0; this.player.cabin.handbrakeLever.rotation.x = 0.6;
      this.player.cabin.gaugeNeedles.forEach(needle => { needle.rotation.z = 2.27; });
    }
  }
  inspectInterior(interior: boolean) { this.garageInterior = interior; this.updateCamera(1); }
  orbit(delta: number) { if (this.mode === 'garage' && !this.garageInterior) this.garageAngle += delta * 0.008; }
  cycleCamera() {
    this.cameraMode = (this.cameraMode + 1) % CAMERA_NAMES.length;
    this.events.notice(this.cameraMode === COCKPIT_CAMERA ? 'COCKPIT / نمای داخل کابین' : `${CAMERA_NAMES[this.cameraMode]} CAMERA`, 'info');
    this.updateCamera(1); this.events.hud(this.snapshot());
  }
  toggleCockpit() { this.cameraMode = this.cameraMode === COCKPIT_CAMERA ? 0 : COCKPIT_CAMERA; this.updateCamera(1); this.events.hud(this.snapshot()); }
  clearControls() { for (const key of Object.keys(this.controls) as (keyof Controls)[]) this.controls[key] = false; }
  end() { this.mode = 'finished'; this.audio.pause(); this.clearControls(); this.renderDirty = true; this.events.finish(this.snapshot()); }
  reset() {
    this.speed = 0; this.x = 0; this.lateralSpeed = 0; this.steer = 0; this.distance = 0; this.throttle = 0; this.brake = 0;
    this.powertrain.reset(); this.audio.reset();
    this.handbrakeAmount = 0; this.driftYaw = 0; this.nearbyTraffic = 0; this.wheelAngle = 0; this.rearWheelAngle = 0;
    this.effectCutPulses = 0; this.smokeBudget = 0;
    this.telemetry = { ...EMPTY_TELEMETRY, rpm: VEHICLES[this.prefs.vehicleId].tune.idleRpm, vehicleId: this.prefs.vehicleId, redline: VEHICLES[this.prefs.vehicleId].tune.redline };
    this.cameraMode = this.prefs.startInCockpit ? COCKPIT_CAMERA : 0; this.shake = 0; this.collisionCooldown = 0; this.lastOdometer = '';
    this.pitchVelocity = 0; this.rollVelocity = 0; this.lastPass = -100;
    this.player.root.position.set(0, 0, 0); this.player.root.rotation.set(0, 0, 0); this.player.body.rotation.set(0, 0, 0);
    this.updateModelDetails();
    this.player.root.visible = true; this.particles.forEach(p => { p.life = 0; });
    this.camera.position.set(0, 3.0, 8.5); this.camLook.set(0, 0.8, -10); this.camera.lookAt(this.camLook);
    this.highway?.reset(); this.resetTraffic(); this.events.hud(this.snapshot());
  }
  snapshot(): Telemetry {
    this.renderer.getDrawingBufferSize(this.bufferSize);
    return { ...this.telemetry, vehicleId: this.prefs.vehicleId, redline: VEHICLES[this.prefs.vehicleId].tune.redline, speed: this.speed * 3.6, distance: this.distance / 1000, fps: this.fps, camera: this.cameraMode, renderWidth: this.bufferSize.x, renderHeight: this.bufferSize.y };
  }

  private resetTraffic() {
    this.cars.length = 0;
    const count = Math.round(10 + this.prefs.density * 25);
    for (let i = 0; i < count; i++) {
      const dir = i < Math.ceil(count * 0.73) ? 1 : -1;
      const lane = i % 3;
      this.cars.push({
        id: i, kind: i % 6, lane, target: lane, x: (dir > 0 ? lanes : opposite)[lane],
        s: this.distance + 34 + Math.floor(i / 3) * 35 + random(i + 4) * 12,
        speed: 12 + random(i + 20) * 10, desired: 17 + (2 - lane) * 2.8 + random(i + 33) * 7,
        dir, timer: 3 + random(i + 57) * 8, brake: 0, passed: false, yaw: dir > 0 ? 0 : Math.PI,
      });
    }
  }

  private tick = (now: number) => {
    if (this.destroyed || !this.ready) return;
    if (this.mode === 'menu' || document.hidden) { this.lastTime = now; return; }
    if (this.mode === 'paused' || this.mode === 'finished') {
      if (this.renderDirty) { this.renderer.render(this.scene, this.camera); this.renderDirty = false; }
      this.lastTime = now; return;
    }
    const dt = Math.min(this.lastTime ? (now - this.lastTime) / 1000 : 1 / 60, 0.05);
    this.lastTime = now; this.time += dt; this.fpsTime += dt; this.frameCount++;
    if (this.fpsTime >= 1) {
      this.fps = Math.round(this.frameCount / this.fpsTime); this.frameCount = 0; this.fpsTime = 0;
      if (this.fps < 29) this.slowFrames++; else this.slowFrames = 0;
      if (this.prefs.adaptiveResolution && this.slowFrames >= 3 && this.mode === 'playing' && this.reducedDpr > 0.75) { this.reducedDpr -= 0.05; this.slowFrames = 0; this.resize(); }
    }
    if (this.mode === 'playing') {
      // Bounded substeps keep steering, collisions, and traffic stable on slower mobile frames.
      const steps = Math.max(1, Math.ceil(dt / (1 / 90))), h = dt / steps;
      for (let i = 0; i < steps; i++) { if (this.mode !== 'playing') break; this.physics(h); this.updateTraffic(h); }
      this.updateEffects(dt);
      this.updateAudio();
    }
    this.highway?.update(this.distance, this.x);
    this.streetLights.forEach((light, i) => { light.position.set(5.22, 8.65, -30 - i * 40 + this.distance % 40); });
    this.renderTraffic(); this.updateCamera(dt);
    this.renderMirror(dt);
    this.renderer.render(this.scene, this.camera);
    this.hudTime += dt;
    if (this.hudTime > 0.1) { this.hudTime = 0; this.events.hud(this.snapshot()); }
  };

  private physics(dt: number) {
    const c = this.controls;
    const spec = VEHICLES[this.prefs.vehicleId];
    this.powertrain.step({ speed: this.speed, gas: c.gas, brake: c.brake, handbrake: c.handbrake, rev: c.rev }, dt);
    this.throttle = this.powertrain.throttle;
    this.brake = damp(this.brake, c.brake ? 1 : 0, 16, dt);
    this.handbrakeAmount = damp(this.handbrakeAmount, c.handbrake ? 1 : 0, c.handbrake ? 28 : 14, dt);
    this.steer = damp(this.steer, Number(c.right) - Number(c.left), 5.5, dt);
    this.telemetry.rpm = this.powertrain.rpm; this.telemetry.gear = this.powertrain.gear;
    this.telemetry.limiter = this.powertrain.limiter; this.telemetry.fuelCut = this.powertrain.fuelCut;
    this.telemetry.neutral = this.powertrain.freeRev; this.telemetry.gearHeld = this.powertrain.gearHeld;
    this.telemetry.handbrake = this.handbrakeAmount > 0.35;
    const grip = (this.prefs.weather === 'rain' ? 0.74 : 1) * spec.grip;
    const serviceBraking = this.brake * (this.prefs.abs ? spec.brake * grip : (spec.brake + 0.4) * grip);
    const parkingBraking = this.handbrakeAmount * 5.8 * grip;
    const braking = Math.max(serviceBraking, parkingBraking);
    const force = this.powertrain.driveForce * (this.speed < 10 ? grip : 1);
    const drag = 0.42 * this.speed * this.speed / spec.tune.mass;
    const engineBraking = this.powertrain.fuelCut && !this.powertrain.freeRev ? 0.8 : 0;
    const acceleration = force / spec.tune.mass - drag - (this.speed > 0.05 ? 0.19 + (1 - this.throttle) * 0.08 : 0) - braking - engineBraking;
    this.speed = clamp(this.speed + acceleration * dt, 0, spec.maxSpeed);
    const desiredLateral = this.steer * Math.min(7.0, this.speed * 0.165);
    const previousLateral = this.lateralSpeed;
    const rearGrip = grip * (1 - this.handbrakeAmount * 0.58);
    this.lateralSpeed += clamp((desiredLateral - this.lateralSpeed) * (5 - this.handbrakeAmount * 2), -8.8 * rearGrip, 8.8 * rearGrip) * dt;
    const slideTarget = -this.steer * this.handbrakeAmount * clamp(this.speed / 18, 0, 1) * 0.31;
    this.driftYaw = damp(this.driftYaw, slideTarget, c.handbrake ? 5 : 3.2, dt);
    this.lateralSpeed += -Math.sin(this.driftYaw) * this.speed * this.handbrakeAmount * 0.065 * dt;
    this.lateralSpeed = clamp(this.lateralSpeed, -7.8, 7.8);
    if (this.speed < 2) this.lateralSpeed = damp(this.lateralSpeed, 0, 12, dt);
    if (!this.prefs.abs && this.brake > 0.85) this.lateralSpeed *= 1 - dt * 2;
    this.x += this.lateralSpeed * dt;
    const lateralAcceleration = (this.lateralSpeed - previousLateral) / dt;
    this.distance += this.speed * dt; this.telemetry.seconds += dt;
    this.collisionCooldown = Math.max(0, this.collisionCooldown - dt);
    this.shake = Math.max(0, this.shake - dt * 1.9);
    if (this.x > 5.73 || this.x < -5.84) {
      const side = Math.sign(this.x); this.x = side > 0 ? 5.73 : -5.84; this.lateralSpeed = -side * 0.55;
      if (this.speed > 6 && this.collisionCooldown === 0) this.hit(0.3, 'Barrier contact');
    }
    this.player.root.position.set(this.x, 0.006, 0);
    this.player.root.rotation.y = damp(this.player.root.rotation.y, -Math.atan2(this.lateralSpeed, Math.max(this.speed, 5)) + this.driftYaw, 9, dt);
    const targetPitch = clamp(acceleration * 0.009, -0.045, 0.035);
    const targetRoll = clamp(lateralAcceleration * 0.007 * spec.bodyRoll, -0.045, 0.045);
    this.pitchVelocity += ((targetPitch - this.player.body.rotation.x) * 65 - this.pitchVelocity * 13) * dt;
    this.rollVelocity += ((targetRoll - this.player.body.rotation.z) * 68 - this.rollVelocity * 12) * dt;
    this.player.body.rotation.x += this.pitchVelocity * dt; this.player.body.rotation.z += this.rollVelocity * dt;
    this.wheelAngle -= this.speed / spec.tune.wheelRadius * dt;
    this.rearWheelAngle -= this.speed / spec.tune.wheelRadius * dt * (this.handbrakeAmount > 0.65 ? 0 : 1 - this.handbrakeAmount);
    this.player.wheels.forEach((w, i) => { w.rotation.y = i < 2 ? -this.steer * 0.24 : 0; w.children[0].rotation.x = i < 2 ? this.wheelAngle : this.rearWheelAngle; });
    this.updateModelDetails();
    this.player.brakeMaterial.emissiveIntensity = this.brake > 0.1 ? 2.8 : this.prefs.time === 'night' ? 0.65 : 0.15;
    this.headlight.position.x = this.x; this.headlight.target.position.x = this.x - Math.sin(this.player.root.rotation.y) * 20;
    if (this.telemetry.seconds - this.lastPass > 8) this.telemetry.combo = 1;
  }

  private updateModelDetails() {
    const cabin = this.player.cabin; if (!cabin) return;
    cabin.steeringWheel.rotation.z = -this.steer * 2.3 - this.driftYaw;
    cabin.handbrakeLever.rotation.x = this.handbrakeAmount * 0.63;
    cabin.gaugeNeedles[0].rotation.z = 2.27 - clamp(this.speed * 3.6 / (this.prefs.vehicleId === 'saipa141' ? 200 : 240), 0, 1) * 4.54;
    cabin.gaugeNeedles[1].rotation.z = 2.27 - clamp(this.telemetry.rpm / 8000, 0, 1) * 4.54;
    const gear = this.telemetry.neutral ? 0 : this.telemetry.gear;
    cabin.gearLever.rotation.x = gear === 0 ? 0 : gear % 2 ? -0.07 : 0.07;
    cabin.gearLever.rotation.z = gear < 3 ? 0.06 : gear > 4 ? -0.06 : 0;
    const reading = (this.distance / 1000).toFixed(2);
    if (reading !== this.lastOdometer) {
      const ctx = cabin.odometerCanvas.getContext('2d');
      if (ctx) { ctx.fillStyle = '#1a261c'; ctx.fillRect(0, 0, 256, 64); ctx.fillStyle = '#d2dab7'; ctx.font = '39px monospace'; ctx.textAlign = 'center'; ctx.fillText(reading.padStart(6, '0'), 128, 48); cabin.odometer.needsUpdate = true; }
      this.lastOdometer = reading;
    }
  }

  private updateTraffic(dt: number) {
    let nearby = 0;
    for (const car of this.cars) {
      let gap = 150, leaderSpeed = car.desired;
      for (const other of this.cars) {
        if (other === car || other.dir !== car.dir || Math.abs(other.x - car.x) > 1.65) continue;
        const d = (other.s - car.s) * car.dir - 4.5;
        if (d > 0 && d < gap) { gap = d; leaderSpeed = other.speed; }
      }
      const playerGap = (this.distance - car.s) * car.dir - 4.5;
      if (Math.abs(this.x - car.x) < 1.85 && playerGap > 0 && playerGap < gap) { gap = playerGap; leaderSpeed = this.speed * car.dir; }
      const safeGap = 5 + car.speed * 0.95 + car.speed * Math.max(car.speed - leaderSpeed, 0) / 5;
      const acceleration = clamp(1.65 * (1 - Math.pow(car.speed / car.desired, 4) - Math.pow(safeGap / Math.max(gap, 1), 2)), -7.8, 1.65);
      car.brake = acceleration < -0.7 ? 1 : 0;
      car.speed = Math.max(0, car.speed + acceleration * dt); car.s += car.speed * car.dir * dt; car.timer -= dt;
      if (car.timer < 0 && car.lane === car.target) {
        if (gap < 60 || random(car.id + Math.floor(this.distance)) > 0.84) {
          const options = [car.lane - 1, car.lane + 1].filter(l => l >= 0 && l < 3);
          for (const lane of options) {
            const targetX = (car.dir > 0 ? lanes : opposite)[lane];
            const safe = this.cars.every(o => o === car || o.dir !== car.dir || (Math.abs(o.x - targetX) > 1.8 && o.target !== lane) || Math.abs(o.s - car.s) > 12 + Math.max(car.speed, o.speed) * 1.0);
            const playerSafe = Math.abs(this.x - targetX) > 2 || Math.abs(car.s - this.distance) > 15 + this.speed * 0.6;
            if (safe && playerSafe) { car.target = lane; break; }
          }
        }
        car.timer = 4 + random(car.id + Math.floor(car.s)) * 9;
      }
      const tx = (car.dir > 0 ? lanes : opposite)[car.target], oldX = car.x;
      car.x = damp(car.x, tx, 0.95, dt);
      if (Math.abs(car.x - tx) < 0.05) { car.x = tx; car.lane = car.target; }
      car.yaw = (car.dir > 0 ? 0 : Math.PI) - Math.atan2((car.x - oldX) / dt, Math.max(car.speed, 4)) * car.dir;
      const relative = car.s - this.distance;
      const dx = Math.abs(car.x - this.x), dz = Math.abs(relative);
      nearby = Math.max(nearby, Math.exp(-Math.hypot(dx, dz) / 9));
      const vehicle = VEHICLES[this.prefs.vehicleId];
      if (this.collisionCooldown === 0 && dz < (vehicle.length + 4.49) * 0.475 && dx < (vehicle.width + 1.72) * 0.47 + Math.abs(this.player.root.rotation.y) * 0.9) {
        this.hit(clamp(Math.abs(this.speed - car.speed * car.dir) / 24, 0.18, 1), 'Collision');
        this.x = clamp(this.x + (this.x >= car.x ? 0.4 : -0.4), -5.8, 5.7);
      }
      if (!car.passed && car.dir > 0 && relative < -2.0) {
        car.passed = true;
        if (relative > -6 && dx > 1.69 && dx < 2.85 && this.speed > 16 && this.speed > car.speed + 1 && this.collisionCooldown === 0) {
          this.telemetry.nearMisses++; this.lastPass = this.telemetry.seconds;
          const bonus = 100 * this.telemetry.combo; this.telemetry.score += bonus;
          this.telemetry.combo = Math.min(5, this.telemetry.combo + 1);
          this.events.notice(`+${bonus}  CLOSE CALL`, 'close');
        }
      }
      if (relative < -85 || relative > 440) {
        car.s = this.distance + (car.dir > 0 ? 240 : 330) + random(car.id + Math.floor(this.distance)) * 105;
        car.passed = false;
        for (let tries = 0; tries < 4; tries++) {
          if (this.cars.some(o => o !== car && o.dir === car.dir && o.lane === car.lane && Math.abs(o.s - car.s) < 17)) car.s += 21;
        }
      }
    }
    this.nearbyTraffic = nearby;
  }

  private updateAudio() {
    const slip = this.handbrakeAmount * (Math.abs(this.lateralSpeed) + this.speed * 0.16) + (Math.abs(this.x) > 5.2 ? 2 : 0);
    this.audio.update({
      rpm: this.telemetry.rpm, throttle: this.throttle, speed: this.speed, brake: this.brake,
      slip, nearby: this.nearbyTraffic, horn: this.controls.horn, gear: this.telemetry.neutral ? 0 : this.telemetry.gear,
      rain: this.prefs.weather === 'rain', fuelCut: this.powertrain.fuelCut, cutPulses: this.powertrain.cutPulses,
      cabin: this.cameraMode === COCKPIT_CAMERA,
    });
  }

  private hit(intensity: number, label: string) {
    this.collisionCooldown = 1.25; this.shake = 0.6 * intensity;
    this.speed *= 0.5 + (1 - intensity) * 0.25; this.telemetry.combo = 1;
    this.telemetry.damage = clamp(this.telemetry.damage + 6 + intensity * 27, 0, 100);
    this.events.notice(label, 'hit'); this.audio.impact(intensity);
    this.emitParticles(16, true);
    if (this.telemetry.damage >= 100) this.end();
  }

  private renderTraffic() {
    const counts = [0, 0, 0, 0, 0, 0]; let brakes = 0;
    this.cars.forEach((car, index) => {
      const z = this.distance - car.s;
      dummy.position.set(car.x, 0.009, z); dummy.rotation.set(car.brake ? -0.007 : 0, car.yaw, 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix();
      this.trafficMeshes[car.kind].setMatrixAt(counts[car.kind]++, dummy.matrix);
      if (car.brake || this.prefs.time === 'night') {
        dummy.position.set(car.x, 0.793, z + car.dir * (car.kind > 3 ? 1.88 : 2.26)); dummy.scale.set(1, car.brake ? 1 : 0.6, 1); dummy.updateMatrix();
        this.trafficBrakes.setMatrixAt(brakes++, dummy.matrix);
      }
      dummy.position.set(car.x, 0.018, z); dummy.rotation.set(-Math.PI / 2, 0, 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix(); this.trafficShadows.setMatrixAt(index, dummy.matrix);
    });
    this.trafficMeshes.forEach((mesh, i) => { mesh.count = counts[i]; mesh.instanceMatrix.needsUpdate = true; });
    this.trafficBrakes.count = brakes; this.trafficBrakes.instanceMatrix.needsUpdate = true;
    this.trafficShadows.count = this.cars.length; this.trafficShadows.instanceMatrix.needsUpdate = true;
  }

  private emitParticles(count: number, collision = false, exhaust = false) {
    let emitted = 0;
    for (const p of this.particles) {
      if (p.life > 0) continue;
      const rearTire = Math.random() > 0.5 ? 0.81 : -0.81;
      p.x = this.x + (exhaust ? this.prefs.vehicleId === 'saipa141' ? 0.47 : -0.58 : collision ? (Math.random() - 0.5) * 1.5 : rearTire + (Math.random() - 0.5) * 0.13);
      p.y = exhaust ? 0.33 : 0.20; p.z = exhaust ? VEHICLES[this.prefs.vehicleId].length / 2 + 0.1 : collision ? -1.8 : 1.4;
      p.vx = (Math.random() - 0.5) * (exhaust ? 0.15 : collision ? 5 : 1.4);
      p.vy = exhaust ? 0.08 : 0.15 + Math.random() * (collision ? 1.4 : 0.5);
      p.life = exhaust ? 0.2 : 0.6 + Math.random() * 0.7;
      p.color.set(exhaust ? '#858d91' : collision ? '#d7a260' : Math.abs(this.x) > 5 ? '#c4b491' : '#bebfba');
      if (++emitted >= count) break;
    }
  }
  private updateEffects(dt: number) {
    if (this.speed > 5 && (Math.abs(this.x) > 5.15 || this.handbrakeAmount > 0.5 || (this.brake > 0.8 && !this.prefs.abs))) {
      this.smokeBudget += dt * (this.prefs.quality === 'low' ? 30 : 105);
      const count = Math.floor(this.smokeBudget);
      if (count > 0) { this.emitParticles(Math.min(count, 6)); this.smokeBudget -= count; }
    } else this.smokeBudget = 0;
    if (this.powertrain.cutPulses > this.effectCutPulses && this.prefs.sportExhaust) this.emitParticles(1, false, true);
    this.effectCutPulses = this.powertrain.cutPulses;
    const position = this.particleMesh.geometry.attributes.position, color = this.particleMesh.geometry.attributes.color, life = this.particleMesh.geometry.attributes.life;
    this.particles.forEach((p, i) => {
      p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += this.speed * dt;
      position.setXYZ(i, p.x, p.life > 0 ? p.y : -100, p.z);
      color.setXYZ(i, p.color.r, p.color.g, p.color.b);
      life.setX(i, clamp(p.life * 2, 0, 1));
    });
    position.needsUpdate = color.needsUpdate = life.needsUpdate = true;
    if (this.prefs.weather === 'rain') {
      for (let i = 0; i < 600; i++) {
        const k = i * 6; this.rainArray[k + 1] -= dt * 22;
        if (this.rainArray[k + 1] < 0) this.rainArray[k + 1] = 25;
        this.rainArray[k + 2] += dt * this.speed;
        if (this.rainArray[k + 2] > 18) this.rainArray[k + 2] -= 75;
        this.rainArray[k + 3] = this.rainArray[k] - 0.05; this.rainArray[k + 4] = this.rainArray[k + 1] - 0.55; this.rainArray[k + 5] = this.rainArray[k + 2] + 0.13;
      }
      this.rain.geometry.attributes.position.needsUpdate = true;
    }
  }

  private updateCamera(dt: number) {
    const cockpit = this.mode === 'garage' ? this.garageInterior : this.cameraMode === COCKPIT_CAMERA;
    this.setInterior(cockpit);
    this.camera.up.set(0, 1, 0);
    if (cockpit) {
      const eye = VEHICLES[this.prefs.vehicleId].eye;
      this.player.root.updateMatrixWorld(true);
      this.localEye.set(...eye);
      this.localLook.set(eye[0] + this.steer * 0.024, eye[1] - 0.34, eye[2] - 12);
      this.player.body.localToWorld(this.localEye); this.player.body.localToWorld(this.localLook);
      this.camera.position.copy(this.localEye); this.camLook.copy(this.localLook);
      this.player.body.getWorldQuaternion(this.vehicleQuaternion);
      this.camera.up.applyQuaternion(this.vehicleQuaternion);
      this.camera.near = 0.035;
      this.camera.fov = this.camera.aspect < 1 ? 72 : 62;
      this.camera.position.y += Math.sin(this.time * 57) * this.shake * 0.021;
    } else if (this.mode === 'garage') {
      this.garageAngle += dt * 0.07;
      this.targetPosition.set(Math.sin(this.garageAngle) * 6.5, 1.95, Math.cos(this.garageAngle) * 6.5);
      this.camera.position.lerp(this.targetPosition, 1 - Math.exp(-dt * 5));
      this.camLook.lerp(this.localLook.set(-0.76, 0.69, 0), 1 - Math.exp(-dt * 5));
      this.camera.fov = damp(this.camera.fov, 44, 4, dt); this.player.root.visible = true;
      this.camera.near = 0.08;
    } else {
      const bonnet = this.cameraMode === 3, wide = this.cameraMode === 2;
      this.player.root.visible = true;
      this.camera.near = 0.08;
      if (bonnet) {
        this.player.root.updateMatrixWorld(true);
        this.localEye.set(...VEHICLES[this.prefs.vehicleId].bonnet);
        this.player.body.localToWorld(this.localEye); this.camera.position.copy(this.localEye);
      } else {
        this.targetPosition.set(this.x * 0.82, wide ? 4.0 : 2.7, wide ? 11.4 : 7.7 + this.speed * 0.022);
        this.camera.position.lerp(this.targetPosition, 1 - Math.exp(-dt * 6.8));
      }
      this.camLook.lerp(this.localLook.set(this.x + this.lateralSpeed * 0.19, bonnet ? 1.0 : 0.72, -12), 1 - Math.exp(-dt * 8));
      this.camera.fov = damp(this.camera.fov, (bonnet ? 64 : 54) + this.speed * 0.12, 3, dt);
      this.camera.position.y += Math.sin(this.time * 72) * this.shake * 0.095;
    }
    this.camera.lookAt(this.camLook); this.camera.updateProjectionMatrix();
  }

  private setInterior(active: boolean) {
    if (this.insideView === active) return;
    this.insideView = active;
    for (const material of this.player.windows) {
      material.userData.exteriorOpacity ??= material.opacity;
      material.opacity = active ? 0.065 : material.userData.exteriorOpacity;
      material.envMapIntensity = active ? 0.24 : 1.15;
    }
    if (this.player.cabin) this.player.cabin.driverSeat.visible = !active;
    this.mirrorTime = 10;
  }

  private renderMirror(dt: number) {
    if (!this.insideView || !this.player.cabin) return;
    this.mirrorTime += dt;
    if (this.mirrorTime < (this.prefs.quality === 'low' ? 0.20 : 0.09)) return;
    this.mirrorTime = 0;
    const position = this.mode === 'garage' ? 0 : this.x;
    this.mirrorCamera.position.set(position, 1.17, 2.65);
    this.mirrorCamera.lookAt(position - Math.sin(this.player.root.rotation.y) * 30, 1.1, 45);
    const visible = this.player.root.visible, target = this.renderer.getRenderTarget(), autoShadow = this.renderer.shadowMap.autoUpdate;
    this.player.root.visible = false; this.renderer.shadowMap.autoUpdate = false;
    try { this.renderer.setRenderTarget(this.mirrorTarget); this.renderer.render(this.scene, this.mirrorCamera); }
    finally { this.renderer.setRenderTarget(target); this.player.root.visible = visible; this.renderer.shadowMap.autoUpdate = autoShadow; }
  }

  private onContextLost = (event: Event) => {
    event.preventDefault(); this.pause(); this.renderer.setAnimationLoop(null);
    this.events.error('The graphics context was interrupted. Reload the game, then choose Low graphics.');
  };
  dispose() {
    this.destroyed = true; this.ready = false; this.audio.dispose(); this.observer.disconnect();
    this.renderer.setAnimationLoop(null); this.renderer.domElement.removeEventListener('webglcontextlost', this.onContextLost);
    const geometries = new Set<T.BufferGeometry>(), materials = new Set<T.Material>(), textures = new Set<T.Texture>();
    this.scene.traverse(o => {
      if (o instanceof T.Mesh || o instanceof T.Points || o instanceof T.LineSegments) {
        geometries.add(o.geometry);
        (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => materials.add(m));
      }
    });
    materials.forEach(m => { Object.values(m).forEach(v => { if (v instanceof T.Texture) textures.add(v); }); m.dispose(); });
    textures.forEach(t => t.dispose()); geometries.forEach(g => g.dispose());
    this.environment?.dispose(); this.skyTexture?.dispose(); this.mirrorTarget.dispose(); this.scene.clear(); this.renderer.dispose(); this.renderer.domElement.remove();
  }
}