import type { VehicleId } from './types';

export interface EngineTune {
  powerHp: number; torqueNm: number; mass: number; idleRpm: number;
  redline: number; resumeRpm: number; wheelRadius: number; finalDrive: number;
  ratios: readonly number[];
}
export interface VehicleSpec {
  id: VehicleId;
  maker: string; name: string; shortName: string; nameFa: string; model: string;
  description: string; engine: string; tune: EngineTune;
  length: number; width: number; wheelbase: number; maxSpeed: number;
  brake: number; grip: number; bodyRoll: number;
  eye: [number, number, number]; bonnet: [number, number, number];
  colors: { value: string; name: string }[];
}

export const VEHICLES: Record<VehicleId, VehicleSpec> = {
  peugeot405: {
    id: 'peugeot405', maker: 'IRAN KHODRO', name: 'Peugeot 405', shortName: '405 GLX', model: '405 GLX',
    nameFa: 'پژو ۴۰۵ جی ال ایکس', engine: '1.8L XU7',
    description: 'The familiar GLX, rebuilt from the driver\'s seat. A classic horizontal dashboard, live analogue instruments, and the sport tune you know.',
    tune: { powerHp: 165, torqueNm: 228, mass: 1210, idleRpm: 880, redline: 6800, resumeRpm: 6490, wheelRadius: 0.307, finalDrive: 4.15, ratios: [3.45, 1.94, 1.34, 1, 0.78] },
    length: 4.49, width: 1.72, wheelbase: 2.69, maxSpeed: 63, brake: 8.8, grip: 1, bodyRoll: 1,
    eye: [-0.355, 1.255, 0.065], bonnet: [0, 1.055, -1.25],
    colors: [{ value: '#ecede8', name: 'Alpine white' }, { value: '#aeb8bc', name: 'Silver metallic' }, { value: '#303b40', name: 'Charcoal grey' }, { value: '#e4cf39', name: 'Tehran taxi yellow' }],
  },
  saipa141: {
    id: 'saipa141', maker: 'SAIPA', name: 'Saipa 141', shortName: '141 SE', model: '141 SE',
    nameFa: 'سایپا ۱۴۱ لیفت‌بک', engine: '1.3L M13',
    description: 'Your reference, a new drive. Graphite paint, the distinctive liftback rear, tall three-part lamps, black bumpers, and small silver wheel covers.',
    tune: { powerHp: 71, torqueNm: 108, mass: 940, idleRpm: 870, redline: 6100, resumeRpm: 5770, wheelRadius: 0.28, finalDrive: 4.16, ratios: [3.416, 1.894, 1.28, 0.971, 0.78] },
    length: 3.935, width: 1.605, wheelbase: 2.345, maxSpeed: 47, brake: 7.5, grip: 0.9, bodyRoll: 1.17,
    eye: [-0.325, 1.285, 0.015], bonnet: [0, 1.04, -1.13],
    colors: [{ value: '#555a59', name: 'Graphite / reference' }, { value: '#e7e9e5', name: 'Pearl white' }, { value: '#a5afb2', name: 'Silver grey' }, { value: '#263b45', name: 'Petroleum blue' }],
  },
};
export const VEHICLE_LIST = Object.values(VEHICLES);