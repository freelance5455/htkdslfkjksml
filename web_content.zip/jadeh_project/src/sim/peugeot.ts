import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { lensTexture, plateTexture, shadowTexture, textTexture, tyreSidewallTexture } from './materials';
import { box, surface, stroke, mergeStatic, type V3 } from './modelGeometry';
import { makeCabin } from './cabin';
import type { VehicleModel } from './vehicleModel';

export function makePeugeot(color = '#ecede8', detailed = true): VehicleModel {
  const root = new T.Group(), body = new T.Group(); root.add(body);
  const paint = new T.MeshPhysicalMaterial({ color, metalness: 0.34, roughness: 0.26, clearcoat: 0.9, clearcoatRoughness: 0.18, envMapIntensity: 1.05, side: T.DoubleSide });
  const rubber = new T.MeshStandardMaterial({ color: '#191e1f', roughness: 0.85 });
  const seam = new T.MeshStandardMaterial({ color: '#303638', roughness: 0.65 });
  const chrome = new T.MeshStandardMaterial({ color: '#b5bcb9', metalness: 0.82, roughness: 0.3 });
  const wheelCover = new T.MeshStandardMaterial({ color: '#babeb6', metalness: 0.53, roughness: 0.35 });
  const glass = new T.MeshPhysicalMaterial({ color: '#15242b', metalness: 0.46, roughness: 0.09, clearcoat: 1, envMapIntensity: 1.2, side: T.DoubleSide, transparent: detailed, opacity: detailed ? 0.83 : 1, depthWrite: !detailed });
  const lightMaterial = new T.MeshStandardMaterial({ color: '#e6e9d9', map: detailed ? lensTexture() : null, emissive: '#ffe8b1', emissiveIntensity: 0.12, roughness: 0.23, metalness: 0.32 });
  const reverseLens = new T.MeshStandardMaterial({ color: '#bcc4b9', roughness: 0.35, metalness: 0.15 });
  const brakeMaterial = new T.MeshStandardMaterial({ color: '#962329', emissive: '#ff3026', emissiveIntensity: 0.25, roughness: 0.3 });
  const amber = new T.MeshStandardMaterial({ color: '#d58b28', roughness: 0.32 });

  // Cross-section follows the 405 GLX: long bonnet, flat boot, low belt line, and open wheel arches.
  const shape = new T.Shape();
  shape.moveTo(2.2, 0.34); shape.lineTo(2.24, 0.76); shape.quadraticCurveTo(2.23, 0.93, 2.07, 0.965);
  shape.lineTo(1.18, 1.00); shape.lineTo(-0.9, 0.985); shape.lineTo(-1.91, 0.88);
  shape.quadraticCurveTo(-2.23, 0.85, -2.25, 0.75); shape.lineTo(-2.22, 0.35);
  shape.lineTo(-1.71, 0.35);
  shape.absarc(-1.35, 0.335, 0.362, Math.PI, 0, true);
  shape.lineTo(0.982, 0.35); shape.absarc(1.34, 0.335, 0.36, Math.PI, 0, true);
  shape.lineTo(2.2, 0.34); shape.closePath();
  const depth = detailed ? 0.035 : 1.67;
  const geometry = new T.ExtrudeGeometry(shape, { depth, bevelEnabled: true, bevelSegments: detailed ? 3 : 1, steps: 1, bevelSize: 0.017, bevelThickness: 0.012, curveSegments: 20 });
  geometry.translate(0, 0, -depth / 2); geometry.rotateY(-Math.PI / 2);
  if (detailed) {
    for (const side of [-1, 1]) {
      const panel = new T.Mesh(geometry.clone(), paint); panel.position.x = side * 0.8175; body.add(panel);
    }
    geometry.dispose();
    surface(body, [[-0.817, 0.985, -0.99], [0.817, 0.985, -0.99], [0.811, 0.88, -2.03], [-0.811, 0.88, -2.03]], paint);
    surface(body, [[-0.811, 0.88, -2.03], [0.811, 0.88, -2.03], [0.79, 0.829, -2.233], [-0.79, 0.829, -2.233]], paint);
    surface(body, [[-0.817, 0.999, 1.185], [-0.80, 0.951, 2.16], [0.80, 0.951, 2.16], [0.817, 0.999, 1.185]], paint);
    box(body, [1.61, 0.38, 0.036], [0, 0.648, -2.21], paint);
    box(body, [1.64, 0.435, 0.055], [0, 0.711, 2.185], paint);
  } else body.add(new T.Mesh(geometry, paint));

  // Cabin is separate geometry, not a painted solid box with windows pasted inside it.
  surface(body, [[-0.69, 1.40, -0.4], [0.69, 1.40, -0.4], [0.7, 1.415, 0.46], [-0.7, 1.415, 0.46]], paint);
  surface(body, [[-0.69, 1.405, -0.39], [-0.73, 1.36, -0.38], [-0.74, 1.365, 0.48], [-0.7, 1.415, 0.49]], paint);
  surface(body, [[0.69, 1.405, -0.39], [0.7, 1.415, 0.49], [0.74, 1.365, 0.48], [0.73, 1.36, -0.38]], paint);
  surface(body, [[-0.785, 0.992, -1.00], [0.785, 0.992, -1.00], [0.68, 1.39, -0.405], [-0.68, 1.39, -0.405]], glass);
  surface(body, [[-0.78, 1.015, 1.22], [-0.68, 1.395, 0.49], [0.68, 1.395, 0.49], [0.78, 1.015, 1.22]], glass);

  for (const side of [-1, 1]) {
    const s = side;
    surface(body, [[s * 0.808, 1.003, -0.94], [s * 0.725, 1.36, -0.34], [s * 0.735, 1.369, 0.1], [s * 0.811, 1.008, 0.1]], glass);
    surface(body, [[s * 0.811, 1.008, 0.175], [s * 0.735, 1.369, 0.175], [s * 0.736, 1.364, 0.43], [s * 0.807, 1.009, 1.02]], glass);
    surface(body, [[s * 0.811, 1.008, 0.106], [s * 0.735, 1.371, 0.106], [s * 0.735, 1.371, 0.173], [s * 0.811, 1.008, 0.173]], rubber);
    surface(body, [[s * 0.811, 1.01, 1.04], [s * 0.735, 1.37, 0.45], [s * 0.696, 1.40, 0.52], [s * 0.785, 1.015, 1.25]], paint);
    stroke(body, [s * 0.81, 0.993, -1.01], [s * 0.696, 1.40, -0.405], 0.034, paint);
    stroke(body, [s * 0.696, 1.40, -0.405], [s * 0.706, 1.409, 0.5], 0.022, paint);
    stroke(body, [s * 0.817, 0.99, -0.985], [s * 0.817, 1.009, 1.20], 0.015, rubber);
    box(body, [0.035, 0.075, 1.82], [s * 0.858, 0.65, -0.035], rubber);
    box(body, [0.035, 0.075, 0.49], [s * 0.85, 0.65, -1.955], rubber);
    box(body, [0.035, 0.075, 0.43], [s * 0.85, 0.65, 1.978], rubber);
    box(body, [0.014, 0.023, 1.85], [s * 0.873, 0.673, -0.05], seam);
    box(body, [0.024, 0.061, 0.18], [s * 0.853, 0.87, -0.11], rubber);
    box(body, [0.024, 0.061, 0.18], [s * 0.853, 0.883, 0.83], rubber);
    box(body, [0.031, 0.04, 0.065], [s * 0.855, 0.832, -1.07], amber);
    box(body, [0.12, 0.048, 0.1], [s * 0.867, 1.025, -0.805], rubber);
    box(body, [0.16, 0.103, 0.183], [s * 0.962, 1.054, -0.806], rubber, [0, s * 0.14, 0]);
    box(body, [0.127, 0.075, 0.012], [s * 0.969, 1.056, -0.71], chrome);
    if (detailed) {
      for (const z of [-0.99, 0.138, 1.135]) stroke(body, [s * 0.857, 0.95, z], [s * 0.857, 0.387, z - 0.02], 0.004, seam);
      stroke(body, [s * 0.857, 0.387, -0.99], [s * 0.857, 0.387, 0.98], 0.004, seam);
      stroke(body, [s * 0.835, 0.995, -0.96], [s * 0.815, 0.871, -2.015], 0.0035, seam);
      stroke(body, [s * 0.8, 1.01, 1.235], [s * 0.8, 0.977, 2.045], 0.0035, seam);
      stroke(body, [s * 0.841, 1.001, -1.0], [s * 0.841, 1.016, 1.13], 0.0055, chrome);
      stroke(body, [s * 0.728, 1.395, -0.35], [s * 0.735, 1.389, 0.45], 0.006, rubber);
      for (const z of [-0.15, 0.8]) {
        const lock = new T.Mesh(new T.CylinderGeometry(0.008, 0.008, 0.006, 10), chrome);
        lock.rotation.z = Math.PI / 2; lock.position.set(s * 0.869, 0.852, z); body.add(lock);
        box(body, [0.005, 0.014, 0.002], [s * 0.873, 0.852, z], seam);
      }
      box(body, [0.018, 0.052, 1.86], [s * 0.848, 0.347, -0.04], chrome);
      box(body, [0.13, 0.08, 0.055], [s * 0.922, 1.033, -0.755], rubber, [0, s * 0.18, 0]);
      // Front disc/caliper stays with the hub while the tire and wheel cover spin.
      const disc = new T.Mesh(new T.CylinderGeometry(0.196, 0.196, 0.018, 28), chrome);
      disc.rotation.z = Math.PI / 2; disc.position.set(s * 0.774, 0.319, -1.35); body.add(disc);
      box(body, [0.046, 0.113, 0.068], [s * 0.771, 0.342, -1.191], seam);
      // Thin wheel arch lips and lower sill catch the long afternoon reflection.
      for (const wz of [-1.35, 1.34]) {
        const arch = new T.Mesh(new T.TorusGeometry(0.367, 0.012, 4, 24, Math.PI), paint);
        arch.rotation.y = Math.PI / 2; arch.position.set(s * 0.853, 0.335, wz); body.add(arch);
      }
    }
  }
  box(body, [1.72, 0.13, 0.14], [0, 0.50, -2.22], rubber);
  box(body, [1.69, 0.095, 0.13], [0, 0.373, -2.205], paint);
  box(body, [1.73, 0.13, 0.14], [0, 0.52, 2.20], rubber);
  box(body, [1.65, 0.11, 0.12], [0, 0.39, 2.205], paint);
  box(body, [0.89, 0.08, 0.06], [0, 0.405, -2.283], rubber);
  for (const s of [-1, 1]) {
    box(body, [0.391, 0.165, 0.062], [s * 0.593, 0.758, -2.222], lightMaterial, [0, s * -0.08, 0]);
    box(body, [0.06, 0.148, 0.07], [s * 0.808, 0.754, -2.208], lightMaterial);
    box(body, [0.365, 0.156, 0.055], [s * 0.602, 0.825, 2.221], rubber);
    box(body, [0.343, 0.071, 0.066], [s * 0.602, 0.795, 2.237], brakeMaterial);
    box(body, [0.19, 0.060, 0.063], [s * 0.675, 0.863, 2.237], amber);
    box(body, [0.115, 0.06, 0.063], [s * 0.508, 0.863, 2.239], reverseLens);
    box(body, [0.05, 0.08, 0.035], [s * 0.53, 1.018, 0.98], brakeMaterial);
  }
  box(body, [0.7, 0.17, 0.05], [0, 0.75, -2.231], rubber);
  for (let i = 0; i < 4; i++) box(body, [0.678, 0.019, 0.01], [0, 0.69 + i * 0.037, -2.264], chrome);
  box(body, [0.075, 0.127, 0.012], [0, 0.75, -2.275], chrome);
  box(body, [0.048, 0.105, 0.014], [0, 0.75, -2.287], seam);
  stroke(body, [-0.015, 0.715, -2.298], [0.015, 0.781, -2.298], 0.007, chrome);

  if (detailed) {
    const fuelX = 0.858;
    const fuelOutline: V3[] = [[fuelX, 0.887, 1.525], [fuelX, 0.887, 1.73], [fuelX, 0.748, 1.73], [fuelX, 0.748, 1.525]];
    fuelOutline.forEach((point, i) => stroke(body, point, fuelOutline[(i + 1) % fuelOutline.length], 0.0037, seam));
    box(body, [0.008, 0.031, 0.015], [0.865, 0.816, 1.705], seam);
    stroke(body, [-0.78, 0.964, 2.107], [0.78, 0.964, 2.107], 0.004, seam);
    const bootLock = new T.Mesh(new T.CylinderGeometry(0.012, 0.012, 0.01, 12), chrome);
    bootLock.rotation.x = Math.PI / 2; bootLock.position.set(0, 0.879, 2.222); body.add(bootLock);
    for (const s of [-1, 1]) {
      box(body, [0.23, 0.039, 0.012], [s * 0.6, 0.484, 2.276], brakeMaterial);
      box(body, [0.014, 0.16, 0.008], [s * 0.548, 0.758, -2.26], chrome);
      box(body, [0.285, 0.006, 0.012], [s * 0.602, 0.812, 2.272], seam);
      box(body, [0.039, 0.012, 0.009], [s * 0.17, 0.727, 2.264], chrome);
      for (const z of [-0.93, -0.67]) {
        box(body, [0.038, 0.012, 0.025], [s * 0.02, 1.014, z], rubber);
      }
    }
    const plate = new T.MeshStandardMaterial({ map: plateTexture(), roughness: 0.6 });
    const rearPlate = new T.Mesh(new T.PlaneGeometry(0.43, 0.108), plate); rearPlate.position.set(0, 0.671, 2.252); body.add(rearPlate);
    const frontPlate = new T.Mesh(new T.PlaneGeometry(0.39, 0.097), plate); frontPlate.position.set(0, 0.49, -2.296); frontPlate.rotation.y = Math.PI; body.add(frontPlate);
    for (const z of [-2.3, 2.258]) for (const x of [-0.183, 0.183]) {
      const screw = new T.Mesh(new T.SphereGeometry(0.004, 6, 4), chrome); screw.position.set(x, z < 0 ? 0.49 : 0.671, z); body.add(screw);
    }
    for (const [label, x, width] of [['PEUGEOT', -0.55, 0.28], ['405 GLX', 0.55, 0.24]] as const) {
      const m = new T.Mesh(new T.PlaneGeometry(width, 0.047), new T.MeshStandardMaterial({ map: textTexture(label), transparent: true, metalness: 0.45, roughness: 0.45 }));
      m.position.set(x, 0.947, 2.195); body.add(m);
    }
    stroke(body, [-0.57, 1.01, -0.97], [-0.02, 1.06, -0.9], 0.008, rubber);
    stroke(body, [0.08, 1.01, -0.97], [0.57, 1.06, -0.9], 0.008, rubber);
    for (let i = 0; i < 8; i++) {
      const z = 0.58 + i * 0.073, y = 1.356 - i * 0.039;
      stroke(body, [-0.64, y, z + 0.018], [0.64, y, z + 0.018], 0.002, chrome);
    }
    const exhaust = new T.Mesh(new T.CylinderGeometry(0.044, 0.041, 0.29, 24, 1, true), chrome);
    exhaust.rotation.x = Math.PI / 2; exhaust.position.set(-0.58, 0.33, 2.25); body.add(exhaust);
    const innerPipe = new T.Mesh(new T.CylinderGeometry(0.034, 0.031, 0.235, 20, 1, true), rubber);
    innerPipe.rotation.x = Math.PI / 2; innerPipe.position.set(-0.58, 0.33, 2.242); body.add(innerPipe);
    const lip = new T.Mesh(new T.TorusGeometry(0.0387, 0.0046, 6, 24), chrome); lip.position.set(-0.58, 0.33, 2.396); body.add(lip);
    const darkBore = new T.Mesh(new T.CircleGeometry(0.033, 16), rubber); darkBore.position.set(-0.58, 0.33, 2.185); body.add(darkBore);
    box(body, [1.39, 0.18, 3.3], [0, 0.25, 0], rubber);
  }
  mergeStatic(body);
  const cabin = detailed ? makeCabin('peugeot405') : null;
  if (cabin) body.add(cabin.group);

  const wheels: T.Group[] = [];
  const sidewall = detailed ? new T.MeshStandardMaterial({ map: tyreSidewallTexture(), transparent: true, opacity: 0.52, depthWrite: false, roughness: 0.92 }) : null;
  for (const z of [-1.35, 1.34]) for (const s of [-1, 1]) {
    const wheel = new T.Group(), detail = new T.Group();
    const profile = [new T.Vector2(0.205, -0.083), new T.Vector2(0.27, -0.102), new T.Vector2(0.305, -0.075), new T.Vector2(0.313, -0.035), new T.Vector2(0.313, 0.035), new T.Vector2(0.305, 0.075), new T.Vector2(0.27, 0.102), new T.Vector2(0.205, 0.083)];
    const tyre = new T.Mesh(new T.LatheGeometry(profile, detailed ? 32 : 16), rubber); tyre.rotation.z = Math.PI / 2; detail.add(tyre);
    const cover = new T.Mesh(new T.CylinderGeometry(0.211, 0.216, 0.033, detailed ? 32 : 16), wheelCover);
    cover.rotation.z = Math.PI / 2; cover.position.x = s * 0.091; detail.add(cover);
    if (detailed) {
      for (let i = 0; i < 40; i++) {
        const a = i / 40 * Math.PI * 2;
        box(detail, [0.133, 0.004, 0.018], [0, Math.cos(a) * 0.313, Math.sin(a) * 0.313], seam, [a, 0, 0]);
      }
      const valve = new T.Mesh(new T.CylinderGeometry(0.0045, 0.0045, 0.022, 6), rubber);
      valve.rotation.z = Math.PI / 2; valve.position.set(s * 0.12, 0.136, 0.122); detail.add(valve);
      for (let i = 0; i < 12; i++) {
        const a = i / 12 * Math.PI * 2;
        const slot = box(detail, [0.008, 0.025, 0.04], [s * 0.111, Math.cos(a) * 0.179, Math.sin(a) * 0.179], seam, [a, 0, 0]);
        slot.rotation.x = -a;
      }
      for (let i = 0; i < 4; i++) {
        const a = i * Math.PI / 2;
        box(detail, [0.009, 0.021, 0.021], [s * 0.112, Math.cos(a) * 0.072, Math.sin(a) * 0.072], chrome);
      }
      for (const x of [-0.037, 0.037]) {
        const groove = new T.Mesh(new T.TorusGeometry(0.313, 0.003, 3, 32), seam); groove.rotation.y = Math.PI / 2; groove.position.x = x; detail.add(groove);
      }
      const hub = new T.Mesh(new T.CylinderGeometry(0.04, 0.04, 0.013, 16), chrome); hub.rotation.z = Math.PI / 2; hub.position.x = s * 0.113; detail.add(hub);
      if (sidewall) {
        const lettering = new T.Mesh(new T.CircleGeometry(0.287, 32), sidewall);
        lettering.rotation.y = s * Math.PI / 2; lettering.position.x = s * 0.103; detail.add(lettering);
      }
    }
    mergeStatic(detail); wheel.add(detail); wheel.position.set(s * 0.81, 0.319, z); root.add(wheel); wheels.push(wheel);
  }
  const shadow = new T.Mesh(new T.PlaneGeometry(2.6, 5.9), new T.MeshBasicMaterial({ map: shadowTexture(), transparent: true, depthWrite: false, opacity: 0.64 }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.016; root.add(shadow);
  return { root, body, wheels, paint, brakeMaterial, lightMaterial, windows: [glass], cabin };
}

export function trafficGeometry(color: string, compact = false) {
  const vehicle = makePeugeot(color, false);
  vehicle.root.updateMatrixWorld(true);
  const geometries: T.BufferGeometry[] = [];
  const materials = new Set<T.Material>();
  vehicle.root.traverse(o => {
    if (!(o instanceof T.Mesh) || o.material instanceof T.MeshBasicMaterial) return;
    const material = o.material as T.MeshStandardMaterial; materials.add(material);
    const g = (o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone()).applyMatrix4(o.matrixWorld);
    g.deleteAttribute('uv');
    const rgb = new Float32Array(g.attributes.position.count * 3);
    for (let i = 0; i < rgb.length; i += 3) { rgb[i] = material.color.r; rgb[i + 1] = material.color.g; rgb[i + 2] = material.color.b; }
    g.setAttribute('color', new T.BufferAttribute(rgb, 3));
    if (compact) g.scale(0.95, 0.98, 0.85);
    geometries.push(g);
  });
  const merged = mergeGeometries(geometries, false)!;
  geometries.forEach(g => g.dispose());
  vehicle.root.traverse(o => { if (o instanceof T.Mesh) o.geometry.dispose(); });
  materials.forEach(m => m.dispose());
  return merged;
}