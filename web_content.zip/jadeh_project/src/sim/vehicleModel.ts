import type * as T from 'three';
import type { CabinRig } from './cabin';
export interface VehicleModel {
  root: T.Group;
  body: T.Group;
  wheels: T.Group[];
  paint: T.MeshPhysicalMaterial;
  brakeMaterial: T.MeshStandardMaterial;
  lightMaterial: T.MeshStandardMaterial;
  windows: T.MeshPhysicalMaterial[];
  cabin: CabinRig | null;
}