import { clamp, damp } from './types';
import { VEHICLES, type EngineTune } from './vehicles';

// These are game-tuning values, not specifications for a stock XU7 engine.
export const SPORT_TUNE = VEHICLES.peugeot405.tune;

interface PowertrainInput {
  speed: number;
  gas: boolean;
  brake: boolean;
  handbrake: boolean;
  rev: boolean;
}

export class SportPowertrain {
  rpm: number = SPORT_TUNE.idleRpm;
  gear = 1;
  throttle = 0;
  driveForce = 0;
  fuelCut = false;
  limiter = false;
  cutPulses = 0;
  freeRev = false;
  gearHeld = false;
  private previousRev = false;
  private neutralSession = false;
  private cutTime = 0;
  private limiterHold = 0;
  private shiftTime = 0;
  private rejoinTime = 0;

  constructor(private tune: EngineTune = SPORT_TUNE) { this.reset(); }
  configure(tune: EngineTune) { this.tune = tune; this.reset(); }

  reset() {
    this.rpm = this.tune.idleRpm; this.gear = 1; this.throttle = 0; this.driveForce = 0;
    this.fuelCut = false; this.limiter = false; this.cutPulses = 0;
    this.freeRev = false; this.gearHeld = false; this.previousRev = false; this.neutralSession = false;
    this.cutTime = 0; this.limiterHold = 0; this.shiftTime = 0; this.rejoinTime = 0;
  }

  step(input: PowertrainInput, dt: number) {
    const tune = this.tune;
    const speed = Math.max(0, input.speed);
    dt = clamp(dt, 0, 0.05);
    if (dt === 0) return;

    // REV is a neutral rev at rest, or a gear hold while moving. Latch the mode until release.
    if (input.rev && !this.previousRev) this.neutralSession = speed < 1.5;
    if (!input.rev) this.neutralSession = false;
    this.previousRev = input.rev;
    const wasFree = this.freeRev;
    this.freeRev = (input.rev && this.neutralSession) || (input.handbrake && speed < 1.2);
    this.gearHeld = input.rev && !this.freeRev;
    if (this.freeRev && speed < 1.5) this.gear = 1;
    if (wasFree && !this.freeRev) this.rejoinTime = 0.32;
    this.rejoinTime = Math.max(0, this.rejoinTime - dt);
    this.shiftTime = Math.max(0, this.shiftTime - dt);

    const wantsThrottle = !input.brake && (input.gas || (input.rev && this.freeRev));
    this.throttle = damp(this.throttle, wantsThrottle ? 1 : 0, 14, dt);
    const wheelRpm = speed * 60 / (2 * Math.PI * tune.wheelRadius);
    let ratio = tune.ratios[this.gear - 1] * tune.finalDrive;
    let roadRpm = wheelRpm * ratio;
    if (!this.freeRev && !this.gearHeld && this.shiftTime === 0) {
      if (roadRpm > tune.redline * (0.64 + this.throttle * 0.257) && this.gear < tune.ratios.length) {
        this.gear++; this.shiftTime = 0.18;
      } else if ((roadRpm < 1800 || speed < 1) && this.gear > 1) {
        this.gear = speed < 1 ? 1 : this.gear - 1; this.shiftTime = 0.14;
      }
      ratio = tune.ratios[this.gear - 1] * tune.finalDrive;
      roadRpm = wheelRpm * ratio;
    }

    const targetRpm = this.freeRev
      ? tune.idleRpm + this.throttle * (tune.redline + 850 - tune.idleRpm)
      : Math.max(tune.idleRpm + this.throttle * 1100 * Math.exp(-speed / 4), roadRpm);
    this.limiterHold = Math.max(0, this.limiterHold - dt);

    // A hysteretic fuel cut actually removes drive torque, rather than only changing the gauge.
    if (this.fuelCut) {
      this.cutTime += dt;
      this.rpm = Math.max(tune.idleRpm, this.rpm - 5700 * dt);
      this.limiterHold = 0.2;
      if (this.cutTime >= 0.045 && this.rpm <= tune.resumeRpm) this.fuelCut = false;
    } else {
      this.rpm = damp(this.rpm, targetRpm, this.freeRev ? 7.8 : 17, dt);
      if (this.throttle > 0.12 && this.rpm >= tune.redline && this.shiftTime < 0.08) {
        this.fuelCut = true; this.cutTime = 0; this.cutPulses++; this.limiterHold = 0.2;
      }
    }
    if (!wantsThrottle && this.throttle < 0.08) { this.fuelCut = false; this.limiterHold = 0; }
    this.rpm = clamp(this.rpm, tune.idleRpm * 0.96, tune.redline + 25);
    this.limiter = this.fuelCut || this.limiterHold > 0;

    const torque = tune.torqueNm * (0.79 + 0.21 * Math.cos((this.rpm / tune.redline - 0.53) * 3.9));
    const clutch = this.freeRev ? 0 : 1 - this.rejoinTime / 0.32;
    const wheelForce = torque * ratio * 0.90 * this.throttle / tune.wheelRadius;
    const powerCap = tune.powerHp * 745.7 * 0.91 / Math.max(speed, 4.5);
    const tractionCap = tune.mass * 9.81 * 0.60;
    this.driveForce = Math.min(wheelForce, powerCap, tractionCap) * clutch;
    if (this.shiftTime > 0.06) this.driveForce *= 0.18;
    if (this.fuelCut || this.freeRev || !input.gas || input.brake) this.driveForce = 0;
  }
}