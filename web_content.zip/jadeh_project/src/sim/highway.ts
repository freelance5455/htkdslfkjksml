import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { canvasTexture, loadTextures, signTexture } from './materials';
import { random, type Preferences } from './types';
import mountainUrl from '../assets/alborz.jpg';

const dummy = new T.Object3D();
const roadLength = 960;

function addBox(group: T.Group, size: [number, number, number], position: [number, number, number], material: T.Material) {
  const mesh = new T.Mesh(new T.BoxGeometry(...size), material); mesh.position.set(...position); group.add(mesh); return mesh;
}
function mergedBoxes(items: { size: [number, number, number]; at: [number, number, number] }[]) {
  const geometries = items.map(({ size, at }) => { const g = new T.BoxGeometry(...size); return g.translate(...at); });
  const geometry = mergeGeometries(geometries, false)!; geometries.forEach(g => g.dispose()); return geometry;
}

export class Highway {
  readonly root = new T.Group();
  private chunks: { group: T.Group; s: number }[] = [];
  private laneMarks: T.InstancedMesh;
  private posts: T.InstancedMesh;
  private lamps: T.InstancedMesh;
  private bulbs: T.InstancedMesh;
  private trees: T.InstancedMesh;
  private trunks: T.InstancedMesh;
  private roadMap: T.Texture;
  private dirtMap: T.Texture;
  private roadMaterial: T.MeshStandardMaterial;
  private bulbMaterial: T.MeshStandardMaterial;
  private mountainMaterial: T.MeshBasicMaterial | null = null;
  private mountainTint = '#d4bfa6';
  private headlightGlow: T.Mesh[] = [];

  constructor(textures: Awaited<ReturnType<typeof loadTextures>>) {
    this.roadMap = textures.road; this.dirtMap = textures.dirt;
    this.roadMaterial = new T.MeshStandardMaterial({ map: textures.road, bumpMap: textures.road, bumpScale: 0.009, roughness: 0.86, color: '#a6a9aa' });
    const road = new T.Mesh(new T.PlaneGeometry(28, roadLength), this.roadMaterial);
    road.rotation.x = -Math.PI / 2; road.position.set(-6, 0, -420); road.receiveShadow = true; this.root.add(road);
    const ground = new T.Mesh(new T.PlaneGeometry(1500, 1600), new T.MeshStandardMaterial({ map: textures.dirt, roughness: 1, color: '#b1a48d' }));
    ground.rotation.x = -Math.PI / 2; ground.position.set(0, -0.035, -540); ground.receiveShadow = true; this.root.add(ground);

    const stripeMat = new T.MeshStandardMaterial({ color: '#deddd0', roughness: 0.85 });
    const yellow = new T.MeshStandardMaterial({ color: '#c7ae64', roughness: 0.9 });
    this.laneMarks = new T.InstancedMesh(new T.PlaneGeometry(0.12, 4.25), stripeMat, 384);
    this.laneMarks.instanceMatrix.setUsage(T.DynamicDrawUsage); this.root.add(this.laneMarks);
    for (const x of [-19.0, -7.8, -5.7, 5.7]) {
      const line = new T.Mesh(new T.PlaneGeometry(0.12, roadLength), x === -5.7 || x === -7.8 ? yellow : stripeMat);
      line.rotation.x = -Math.PI / 2; line.position.set(x, 0.017, -420); this.root.add(line);
    }

    const concrete = new T.MeshStandardMaterial({ color: '#c2bcae', roughness: 0.91 });
    const profile = new T.Shape(); profile.moveTo(-0.42, 0); profile.lineTo(0.42, 0); profile.lineTo(0.15, 0.47); profile.lineTo(0.15, 0.9); profile.lineTo(-0.15, 0.9); profile.lineTo(-0.15, 0.47); profile.closePath();
    const median = new T.Mesh(new T.ExtrudeGeometry(profile, { depth: roadLength, bevelEnabled: false }), concrete);
    median.position.set(-6.95, 0, -900); median.castShadow = true; median.receiveShadow = true; this.root.add(median);

    const metal = new T.MeshStandardMaterial({ color: '#8b9698', metalness: 0.52, roughness: 0.42 });
    for (const x of [6.65, -19.8]) {
      const rail = new T.Mesh(new T.BoxGeometry(0.09, 0.28, roadLength), metal); rail.position.set(x, 0.66, -420); rail.castShadow = true; this.root.add(rail);
      const lower = new T.Mesh(new T.BoxGeometry(0.065, 0.08, roadLength), metal); lower.position.set(x, 0.46, -420); this.root.add(lower);
    }
    this.posts = new T.InstancedMesh(new T.BoxGeometry(0.1, 0.82, 0.075), metal, 384); this.root.add(this.posts);
    const lampGeometry = mergedBoxes([
      { size: [0.11, 9.0, 0.11], at: [0, 4.5, 0] },
      { size: [2.3, 0.11, 0.1], at: [-1.07, 8.92, 0] },
      { size: [0.7, 0.11, 0.26], at: [-2.03, 8.85, 0] },
    ]);
    this.lamps = new T.InstancedMesh(lampGeometry, metal, 48); this.root.add(this.lamps);
    this.bulbMaterial = new T.MeshStandardMaterial({ color: '#eee6cf', emissive: '#ffe0a0', emissiveIntensity: 0.1 });
    this.bulbs = new T.InstancedMesh(new T.BoxGeometry(0.6, 0.03, 0.20), this.bulbMaterial, 48); this.root.add(this.bulbs);

    const treeGeometries = [0, 1, 2].map(i => {
      const g = new T.ConeGeometry(0.94 - i * 0.21, 3.0 - i * 0.44, 8); g.translate(i % 2 ? 0.08 : -0.07, 1.95 + i * 0.97, 0); return g;
    });
    const treeGeometry = mergeGeometries(treeGeometries, false)!; treeGeometries.forEach(g => g.dispose());
    this.trees = new T.InstancedMesh(treeGeometry, new T.MeshStandardMaterial({ color: '#475541', roughness: 0.94 }), 140);
    this.trunks = new T.InstancedMesh(new T.CylinderGeometry(0.07, 0.12, 2, 5), new T.MeshStandardMaterial({ color: '#71614a', roughness: 1 }), 140);
    this.trees.castShadow = true; this.root.add(this.trees, this.trunks);

    const materials = [textures.facade, textures.facade2].map(map => new T.MeshStandardMaterial({ map, color: '#ded6c3', roughness: 0.94 }));
    const roofMat = new T.MeshStandardMaterial({ color: '#a19580', roughness: 0.8 });
    const waterMat = new T.MeshStandardMaterial({ color: '#afb2a9', metalness: 0.3, roughness: 0.57 });
    for (let i = 0; i < 12; i++) {
      const chunk = new T.Group();
      for (let j = 0; j < 4; j++) {
        const seed = i * 17 + j * 4;
        const x = 19 + random(seed + 4) * 36, h = 9 + random(seed + 8) * 23, z = -j * 19;
        const width = 9 + random(seed) * 8, depth = 8 + random(seed + 2) * 9;
        const building = new T.Mesh(new T.BoxGeometry(width, h, depth), materials[j % 2]);
        building.position.set(x, h / 2 - 0.3, z); building.castShadow = true; building.receiveShadow = true; chunk.add(building);
        addBox(chunk, [width + 0.3, 0.22, depth + 0.3], [x, h - 0.22, z], roofMat);
        const tank = new T.Mesh(new T.CylinderGeometry(0.65, 0.65, 1.25, 8), waterMat); tank.position.set(x + 1.3, h + 0.5, z); chunk.add(tank);
        if (j % 2 === 0) {
          const dish = new T.Mesh(new T.SphereGeometry(0.49, 10, 5, 0, Math.PI * 2, 0, Math.PI * 0.42), waterMat);
          dish.rotation.x = -0.8; dish.position.set(x - 1.4, h + 0.37, z + 2); chunk.add(dish);
        }
      }
      if (i % 3 === 1) this.gantry(chunk, i);
      if (i % 4 === 0) this.speedSign(chunk);
      this.root.add(chunk); this.chunks.push({ group: chunk, s: i * 82 });
    }
    this.hills(textures.dirt);
    void new T.TextureLoader().loadAsync(mountainUrl).then(map => {
      if (!this.root.parent) { map.dispose(); return; }
      map.colorSpace = T.SRGBColorSpace;
      this.mountainMaterial = new T.MeshBasicMaterial({ map, fog: false, color: this.mountainTint });
      const mountains = new T.Mesh(new T.PlaneGeometry(2100, 750), this.mountainMaterial);
      mountains.position.set(-180, 240, -920); this.root.add(mountains);
    }).catch(() => { /* The procedural hills remain available if an image cannot be decoded. */ });

    const glowMap = canvasTexture(128, 128, c => {
      const g = c.createRadialGradient(64, 64, 4, 64, 64, 64); g.addColorStop(0, 'rgba(255,224,164,.6)'); g.addColorStop(1, 'rgba(255,224,164,0)');
      c.fillStyle = g; c.fillRect(0, 0, 128, 128);
    });
    for (const x of [-0.55, 0.55]) {
      const glow = new T.Mesh(new T.PlaneGeometry(4, 15), new T.MeshBasicMaterial({ map: glowMap, transparent: true, depthWrite: false, blending: T.AdditiveBlending, opacity: 0.25 }));
      glow.rotation.x = -Math.PI / 2; glow.position.set(x, 0.03, -8.5); this.root.add(glow); this.headlightGlow.push(glow);
    }
  }

  private gantry(group: T.Group, seed: number) {
    const metal = new T.MeshStandardMaterial({ color: '#9eaaa7', metalness: 0.4, roughness: 0.5 });
    addBox(group, [0.22, 8.6, 0.22], [7.5, 4.3, -43], metal);
    addBox(group, [0.22, 8.6, 0.22], [-6.4, 4.3, -43], metal);
    addBox(group, [14.3, 0.20, 0.2], [0.5, 8.45, -43], metal);
    const words = seed % 2 ? [['کرج', 'Karaj'], ['قزوین', 'Qazvin']] : [['تهران', 'Tehran'], ['آزادراه شمال', 'North Freeway']];
    for (let i = 0; i < 2; i++) {
      const sign = new T.Mesh(new T.PlaneGeometry(5.55, 2.15), new T.MeshStandardMaterial({ map: signTexture(words[i][0], words[i][1]), roughness: 0.62, emissive: '#829290', emissiveIntensity: 0.035 }));
      sign.position.set(-2.7 + i * 5.9, 7.18, -42.8); group.add(sign);
      addBox(group, [5.65, 2.24, 0.1], [-2.7 + i * 5.9, 7.18, -42.91], metal);
    }
  }

  private speedSign(group: T.Group) {
    const pole = new T.MeshStandardMaterial({ color: '#93958c', metalness: 0.4, roughness: 0.5 });
    addBox(group, [0.085, 3, 0.085], [8, 1.5, -60], pole);
    const texture = canvasTexture(256, 256, c => {
      c.fillStyle = '#eee9d7'; c.beginPath(); c.arc(128, 128, 117, 0, Math.PI * 2); c.fill(); c.strokeStyle = '#af3a32'; c.lineWidth = 21; c.stroke();
      c.fillStyle = '#253237'; c.font = 'bold 88px Tahoma'; c.textAlign = 'center'; c.fillText('۱۱۰', 128, 157);
    });
    const mesh = new T.Mesh(new T.PlaneGeometry(0.95, 0.95), new T.MeshStandardMaterial({ map: texture, transparent: true }));
    mesh.position.set(8, 2.8, -59.94); group.add(mesh);
  }

  private hills(map: T.Texture) {
    const geometry = new T.PlaneGeometry(1300, 1550, 100, 84); geometry.rotateX(-Math.PI / 2);
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i), z = positions.getZ(i);
      const edge = Math.max(0, Math.abs(x + 5) - 55);
      const texture = Math.sin(x * 0.022 + z * 0.012) * Math.cos(z * 0.018) * 0.35 + Math.sin(x * 0.069 + z * 0.028) * 0.10 + 0.57;
      positions.setY(i, edge * 0.22 * texture - 1.6);
    }
    geometry.computeVertexNormals();
    const mesh = new T.Mesh(geometry, new T.MeshStandardMaterial({ map, color: '#a99a7f', roughness: 1 }));
    mesh.position.z = -560; this.root.add(mesh);
  }

  configure(prefs: Preferences) {
    this.roadMaterial.roughness = prefs.weather === 'rain' ? 0.33 : 0.86;
    this.roadMaterial.metalness = prefs.weather === 'rain' ? 0.2 : 0.03;
    this.bulbMaterial.emissiveIntensity = prefs.time === 'night' ? 4 : 0.12;
    this.headlightGlow.forEach(m => { m.visible = prefs.time === 'night'; });
    this.mountainTint = prefs.time === 'night' ? '#202c40' : prefs.time === 'day' ? '#bec9c9' : '#d4bfa6';
    if (this.mountainMaterial) this.mountainMaterial.color.set(this.mountainTint);
    this.trees.count = prefs.quality === 'low' ? 65 : 140;
    this.chunks.forEach((c, i) => { c.group.visible = prefs.quality !== 'low' || i % 3 !== 0; });
  }

  reset() { this.chunks.forEach((chunk, i) => { chunk.s = i * 82; }); }
  update(distance: number, playerX: number) {
    this.roadMap.offset.y = (distance / (roadLength / 70)) % 1;
    this.dirtMap.offset.y = (distance / 16) % 1;
    let index = 0;
    for (const x of [-1.825, 1.825, -11.7, -15.3]) {
      for (let i = 0; i < 96; i++) {
        dummy.position.set(x, 0.013, 40 - i * 10 + distance % 10); dummy.rotation.set(-Math.PI / 2, 0, 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix();
        this.laneMarks.setMatrixAt(index++, dummy.matrix);
      }
    }
    this.laneMarks.instanceMatrix.needsUpdate = true;
    index = 0;
    for (const x of [6.65, -19.8]) for (let i = 0; i < 192; i++) {
      dummy.position.set(x, 0.41, 40 - i * 5 + distance % 5); dummy.rotation.set(0, 0, 0); dummy.updateMatrix(); this.posts.setMatrixAt(index++, dummy.matrix);
    }
    this.posts.instanceMatrix.needsUpdate = true;
    for (let i = 0; i < 48; i++) {
      const right = i % 2 === 0, z = 50 - Math.floor(i / 2) * 40 + distance % 40;
      dummy.position.set(right ? 7.25 : -20.5, 0, z); dummy.rotation.set(0, right ? 0 : Math.PI, 0); dummy.updateMatrix(); this.lamps.setMatrixAt(i, dummy.matrix);
      dummy.position.set(right ? 5.22 : -18.47, 8.765, z); dummy.updateMatrix(); this.bulbs.setMatrixAt(i, dummy.matrix);
    }
    this.lamps.instanceMatrix.needsUpdate = this.bulbs.instanceMatrix.needsUpdate = true;
    for (let i = 0; i < 140; i++) {
      const x = i % 2 ? -22 - random(i + 20) * 25 : 9 + random(i + 12) * 6;
      const z = 60 - (i * 7.01 - distance % 981.4 + 981.4) % 981.4;
      const scale = 0.7 + random(i + 2) * 0.8;
      dummy.position.set(x, 0, z); dummy.rotation.set(0, i, 0); dummy.scale.set(scale, scale, scale); dummy.updateMatrix(); this.trees.setMatrixAt(i, dummy.matrix);
      dummy.position.y = 0.8; dummy.updateMatrix(); this.trunks.setMatrixAt(i, dummy.matrix);
    }
    this.trees.instanceMatrix.needsUpdate = this.trunks.instanceMatrix.needsUpdate = true;
    for (const c of this.chunks) {
      while (c.s < distance - 170) c.s += 12 * 82;
      c.group.position.z = distance - c.s;
    }
    this.headlightGlow.forEach((m, i) => { m.position.x = playerX + (i ? 0.55 : -0.55); });
  }
}