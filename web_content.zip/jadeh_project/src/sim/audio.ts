import { clamp, type VehicleId } from './types';
import { VEHICLES } from './vehicles';
import { combustionLoop } from './combustion';

interface SoundState {
  rpm: number; throttle: number; speed: number; brake: number; slip: number;
  nearby: number; horn: boolean; gear: number; rain: boolean; fuelCut: boolean; cutPulses: number;
  cabin: boolean;
}
interface EngineLoop { source: AudioBufferSourceNode; gain: GainNode; referenceRpm: number }

export class HighwayAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ignition: GainNode | null = null;
  private engine: EngineLoop[] = [];
  private exhaust: EngineLoop[] = [];
  private engineGain: GainNode | null = null;
  private engineFilter: BiquadFilterNode | null = null;
  private exhaustGain: GainNode | null = null;
  private exhaustFilter: BiquadFilterNode | null = null;
  private roadGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private skidGain: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private hornGain: GainNode | null = null;
  private cabinFilter: BiquadFilterNode | null = null;
  private vehicleId: VehicleId = 'peugeot405';
  private popBuffer: AudioBuffer | null = null;
  private transients = new Set<AudioBufferSourceNode>();
  private running = false;
  private generation = 0;
  private volume = 0.55;
  private muted = false;
  private sport = true;
  private lastGear = 1;
  private lastCutPulses = 0;
  private lastThrottle = 0;
  private lastPop = -100;
  private lastOverrun = -100;

  async start() {
    const request = ++this.generation;
    if (!this.ctx) this.createGraph();
    const ctx = this.ctx!;
    await ctx.resume();
    if (this.ctx === ctx && request === this.generation) this.running = true;
  }

  private createGraph() {
    const ctx = new AudioContext(); this.ctx = ctx;
    this.master = ctx.createGain(); this.master.gain.value = 0;
    const compressor = ctx.createDynamicsCompressor(); compressor.threshold.value = -18;
    compressor.knee.value = 12; compressor.ratio.value = 5; compressor.attack.value = 0.006; compressor.release.value = 0.18;
    this.cabinFilter = ctx.createBiquadFilter(); this.cabinFilter.type = 'lowpass'; this.cabinFilter.frequency.value = 16000; this.cabinFilter.Q.value = 0.45;
    this.master.connect(this.cabinFilter); this.cabinFilter.connect(compressor); compressor.connect(ctx.destination);
    this.ignition = ctx.createGain(); this.ignition.connect(this.master);
    this.engineGain = ctx.createGain(); this.engineGain.gain.value = 0;
    this.engineFilter = ctx.createBiquadFilter(); this.engineFilter.type = 'lowpass'; this.engineFilter.frequency.value = 650;
    this.engineGain.connect(this.engineFilter); this.engineFilter.connect(this.ignition);

    const saturator = ctx.createWaveShaper(), curve = new Float32Array(2048);
    for (let i = 0; i < curve.length; i++) curve[i] = Math.tanh((i / (curve.length - 1) * 2 - 1) * 1.25) / Math.tanh(1.25);
    saturator.curve = curve; saturator.oversample = '2x';
    const rumbleFilter = ctx.createBiquadFilter(); rumbleFilter.type = 'highpass'; rumbleFilter.frequency.value = 36; rumbleFilter.Q.value = 0.45;
    this.exhaustFilter = ctx.createBiquadFilter(); this.exhaustFilter.type = 'lowpass'; this.exhaustFilter.frequency.value = 850; this.exhaustFilter.Q.value = 0.65;
    this.exhaustGain = ctx.createGain(); this.exhaustGain.gain.value = 0;
    this.exhaustGain.connect(saturator); saturator.connect(rumbleFilter); rumbleFilter.connect(this.exhaustFilter);
    this.exhaustFilter.connect(this.ignition);
    this.rebuildVoices();

    this.roadGain = this.noise('lowpass', 900);
    this.windGain = this.noise('highpass', 1500);
    this.skidGain = this.noise('bandpass', 1700);
    this.ambientGain = this.noise('bandpass', 340);
    this.hornGain = ctx.createGain(); this.hornGain.gain.value = 0; this.hornGain.connect(this.master);
    [392, 494].forEach(f => {
      const osc = ctx.createOscillator(); osc.type = 'sawtooth'; osc.frequency.value = f; osc.connect(this.hornGain!); osc.start();
    });
    this.popBuffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * 0.13), ctx.sampleRate);
    const samples = this.popBuffer.getChannelData(0);
    let filtered = 0;
    for (let i = 0; i < samples.length; i++) {
      const t = i / ctx.sampleRate;
      filtered = filtered * 0.54 + (Math.random() * 2 - 1) * 0.46;
      samples[i] = (filtered * 0.72 + Math.sin(t * 2 * Math.PI * 105) * 0.28) * Math.exp(-t * 45) * (1 - Math.exp(-t * 1500));
    }
  }

  private noise(type: BiquadFilterType, frequency: number) {
    const ctx = this.ctx!;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate), values = buffer.getChannelData(0);
    let smooth = 0;
    for (let i = 0; i < values.length; i++) { smooth = smooth * 0.2 + (Math.random() * 2 - 1) * 0.8; values[i] = smooth; }
    const source = ctx.createBufferSource(); source.buffer = buffer; source.loop = true;
    const filter = ctx.createBiquadFilter(); filter.type = type; filter.frequency.value = frequency; filter.Q.value = 0.5;
    const gain = ctx.createGain(); gain.gain.value = 0;
    source.connect(filter); filter.connect(gain); gain.connect(this.master!); source.start(); return gain;
  }

  private rebuildVoices() {
    if (!this.ctx || !this.engineGain || !this.exhaustGain) return;
    [...this.engine, ...this.exhaust].forEach(loop => { loop.source.stop(); loop.source.disconnect(); loop.gain.disconnect(); });
    this.engine.length = 0; this.exhaust.length = 0;
    const create = (rpm: number, output: GainNode, exhaust: boolean): EngineLoop => {
      const source = this.ctx!.createBufferSource(), gain = this.ctx!.createGain();
      source.buffer = combustionLoop(this.ctx!, rpm, this.vehicleId, exhaust);
      source.loop = true; source.playbackRate.value = VEHICLES[this.vehicleId].tune.idleRpm / rpm;
      gain.gain.value = 0; source.connect(gain); gain.connect(output); source.start(); return { source, gain, referenceRpm: rpm };
    };
    for (const rpm of [900, 2700, 5100]) this.engine.push(create(rpm, this.engineGain, false));
    for (const rpm of [1600, 4600]) this.exhaust.push(create(rpm, this.exhaustGain, true));
    this.reset();
  }

  configure(volume: number, muted: boolean, sport: boolean, vehicleId: VehicleId) {
    this.volume = clamp(volume, 0, 1); this.muted = muted; this.sport = sport;
    if (this.vehicleId !== vehicleId) { this.vehicleId = vehicleId; this.rebuildVoices(); }
    if (this.ctx) this.master?.gain.setTargetAtTime(this.running && !muted ? this.volume * 0.49 : 0, this.ctx.currentTime, 0.035);
    if (muted) this.stopTransients();
  }
  reset() {
    this.lastGear = 1; this.lastCutPulses = 0; this.lastThrottle = 0; this.lastPop = -100; this.lastOverrun = -100;
    this.stopTransients();
  }
  pause() {
    this.generation++; this.running = false; this.stopTransients();
    if (this.ctx) this.master?.gain.setTargetAtTime(0, this.ctx.currentTime, 0.025);
  }

  update(state: SoundState) {
    if (!this.ctx || !this.running) return;
    const { rpm, throttle, speed, brake, slip, nearby, horn, gear, rain, fuelCut, cutPulses, cabin } = state;
    const t = this.ctx.currentTime, revs = clamp(rpm / VEHICLES[this.vehicleId].tune.redline, 0, 1);
    this.master?.gain.setTargetAtTime(this.muted ? 0 : this.volume * 0.49, t, 0.045);
    this.ignition?.gain.setTargetAtTime(fuelCut ? 0.045 : 1, t, 0.003);
    const low = clamp((2800 - rpm) / 1900, 0, 1), high = clamp((rpm - 3000) / 2500, 0, 1), medium = Math.max(0, 1 - low - high);
    this.engine.forEach((loop, i) => {
      const flutter = Math.sin(t * 8.7) * 0.0014 * (1 - revs);
      loop.source.playbackRate.setTargetAtTime(rpm / loop.referenceRpm * (1 + flutter), t, 0.016);
      loop.gain.gain.setTargetAtTime(Math.sqrt([low, medium, high][i]), t, 0.055);
    });
    const exhaustHigh = clamp((rpm - 2600) / 2400, 0, 1);
    this.exhaust.forEach((loop, i) => {
      loop.source.playbackRate.setTargetAtTime(rpm / loop.referenceRpm, t, 0.014);
      loop.gain.gain.setTargetAtTime(Math.sqrt(i ? exhaustHigh : 1 - exhaustHigh), t, 0.05);
    });
    this.cabinFilter?.frequency.setTargetAtTime(cabin ? 2100 : 15500, t, 0.13);
    this.engineGain?.gain.setTargetAtTime((0.15 + throttle * 0.25 + revs * 0.06) * (cabin ? 0.89 : 1), t, 0.045);
    this.engineFilter?.frequency.setTargetAtTime(650 + throttle * 1600 + rpm * 0.15, t, 0.07);
    this.exhaustGain?.gain.setTargetAtTime((this.sport ? 0.07 + throttle * 0.21 + revs * 0.025 : 0.025 + throttle * 0.055) * (cabin ? 0.55 : 1), t, 0.06);
    this.exhaustFilter?.frequency.setTargetAtTime((this.sport ? 700 : 440) + rpm * 0.095 + throttle * 700, t, 0.05);
    this.roadGain?.gain.setTargetAtTime(clamp(speed / 50, 0, 1) * (rain ? 0.11 : 0.065) * (cabin ? 0.64 : 1), t, 0.1);
    this.windGain?.gain.setTargetAtTime(Math.pow(speed / 63, 2) * (cabin ? 0.025 : 0.07), t, 0.1);
    this.skidGain?.gain.setTargetAtTime(clamp(slip * 0.021 + (speed > 10 ? brake * 0.014 : 0), 0, 0.16), t, 0.025);
    this.ambientGain?.gain.setTargetAtTime(0.008 + nearby * 0.032, t, 0.15);
    this.hornGain?.gain.setTargetAtTime(horn ? 0.065 : 0, t, 0.015);

    // The physics pulse counter drives the exhaust; no independent fake limiter oscillator.
    if (cutPulses > this.lastCutPulses && t - this.lastPop > 0.065) { this.pop(cabin ? 0.24 : 0.45, t); this.lastPop = t; }
    this.lastCutPulses = cutPulses;
    if (this.lastThrottle > 0.42 && throttle <= 0.42 && rpm > 3300 && t - this.lastOverrun > 0.5) {
      this.pop(cabin ? 0.10 : 0.23, t + 0.025); this.pop(cabin ? 0.05 : 0.11, t + 0.11); this.lastOverrun = t;
    }
    if (gear !== this.lastGear) {
      this.impact(0.05, true);
      if (gear > 0 && this.lastGear > 0 && throttle > 0.6 && rpm > 3500) this.pop(0.18, t);
      this.lastGear = gear;
    }
    this.lastThrottle = throttle;
  }

  private pop(strength: number, when: number) {
    if (!this.ctx || !this.master || !this.popBuffer || !this.running || !this.sport || this.muted || this.volume === 0) return;
    if (this.transients.size >= 8) return;
    const source = this.ctx.createBufferSource(), gain = this.ctx.createGain();
    source.buffer = this.popBuffer; source.playbackRate.value = 0.85 + Math.random() * 0.3;
    gain.gain.value = strength * 0.24;
    source.connect(gain); gain.connect(this.master); this.transients.add(source);
    source.onended = () => { source.disconnect(); gain.disconnect(); this.transients.delete(source); };
    source.start(when);
  }

  impact(intensity: number, shift = false) {
    if (!this.ctx || !this.master || this.muted || !this.running) return;
    const ctx = this.ctx, buffer = ctx.createBuffer(1, Math.ceil(ctx.sampleRate * 0.45), ctx.sampleRate);
    const values = buffer.getChannelData(0);
    for (let i = 0; i < values.length; i++) values[i] = (Math.random() * 2 - 1) * Math.exp(-i / (shift ? 550 : 5000));
    const source = ctx.createBufferSource(); source.buffer = buffer;
    const filter = ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = shift ? 280 : 600;
    const gain = ctx.createGain(); gain.gain.value = intensity * (shift ? 0.35 : 0.8);
    source.connect(filter); filter.connect(gain); gain.connect(this.master); this.transients.add(source); source.start();
    source.onended = () => { source.disconnect(); filter.disconnect(); gain.disconnect(); this.transients.delete(source); };
  }
  private stopTransients() {
    for (const source of this.transients) { try { source.stop(); } catch { /* A one-shot may already have ended. */ } }
    this.transients.clear();
  }
  dispose() {
    this.generation++; this.running = false; this.stopTransients();
    void this.ctx?.close(); this.ctx = null; this.engine.length = 0; this.exhaust.length = 0; this.popBuffer = null;
  }
}