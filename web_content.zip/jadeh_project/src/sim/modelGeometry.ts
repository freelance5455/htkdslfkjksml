import * as T from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

export type V3 = [number, number, number];
export function box(group: T.Group, size: V3, pos: V3, material: T.Material, rotation?: V3) {
  const mesh = new T.Mesh(new T.BoxGeometry(...size), material);
  mesh.position.set(...pos); if (rotation) mesh.rotation.set(...rotation);
  group.add(mesh); return mesh;
}
export function roundedBox(group: T.Group, size: V3, pos: V3, material: T.Material, radius = 0.025) {
  const [w, h, d] = size, r = Math.min(radius, w / 3, h / 3, d / 3);
  const shape = new T.Shape();
  shape.moveTo(-w / 2 + r, -h / 2); shape.lineTo(w / 2 - r, -h / 2);
  shape.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + r); shape.lineTo(w / 2, h / 2 - r);
  shape.quadraticCurveTo(w / 2, h / 2, w / 2 - r, h / 2); shape.lineTo(-w / 2 + r, h / 2);
  shape.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - r); shape.lineTo(-w / 2, -h / 2 + r);
  shape.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + r, -h / 2);
  const geometry = new T.ExtrudeGeometry(shape, { depth: d - r, steps: 1, bevelEnabled: true, bevelSegments: 2, bevelSize: r * 0.3, bevelThickness: r * 0.5, curveSegments: 4 });
  geometry.translate(0, 0, -(d - r) / 2);
  const mesh = new T.Mesh(geometry, material); mesh.position.set(...pos); group.add(mesh); return mesh;
}
export function surface(group: T.Group, points: V3[], material: T.Material) {
  const geometry = new T.BufferGeometry();
  geometry.setAttribute('position', new T.Float32BufferAttribute(points.flat(), 3));
  geometry.setAttribute('uv', new T.Float32BufferAttribute(points.flatMap((_, i) => [i === 1 || i === 2 ? 1 : 0, i > 1 ? 1 : 0]), 2));
  const indices = []; for (let i = 1; i < points.length - 1; i++) indices.push(0, i, i + 1);
  geometry.setIndex(indices); geometry.computeVertexNormals();
  const mesh = new T.Mesh(geometry, material); group.add(mesh); return mesh;
}
export function stroke(group: T.Group, from: V3, to: V3, radius: number, material: T.Material) {
  const a = new T.Vector3(...from), b = new T.Vector3(...to), direction = b.clone().sub(a);
  const mesh = new T.Mesh(new T.CylinderGeometry(radius, radius, direction.length(), 6), material);
  mesh.position.copy(a.add(b).multiplyScalar(0.5));
  mesh.quaternion.setFromUnitVectors(new T.Vector3(0, 1, 0), direction.normalize()); group.add(mesh); return mesh;
}
// Batch only static meshes. Animated instruments and mirrors are added afterward.
export function mergeStatic(group: T.Group) {
  group.updateWorldMatrix(true, true);
  const inverse = group.matrixWorld.clone().invert();
  const buckets = new Map<T.Material, T.BufferGeometry[]>(), originals = new Set<T.BufferGeometry>();
  group.traverse(o => {
    if (!(o instanceof T.Mesh) || Array.isArray(o.material)) return;
    const geometry = (o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone());
    geometry.applyMatrix4(inverse.clone().multiply(o.matrixWorld));
    const list = buckets.get(o.material) || []; list.push(geometry); buckets.set(o.material, list); originals.add(o.geometry);
  });
  group.clear();
  buckets.forEach((geometries, material) => {
    const geometry = mergeGeometries(geometries, false); geometries.forEach(g => g.dispose());
    if (!geometry) throw new Error('Unable to batch vehicle geometry.');
    const mesh = new T.Mesh(geometry, material); mesh.castShadow = !material.transparent; mesh.receiveShadow = true; group.add(mesh);
  });
  originals.forEach(g => g.dispose());
}

export function disposeModel(root: T.Object3D) {
  const geometries = new Set<T.BufferGeometry>(), materials = new Set<T.Material>(), textures = new Set<T.Texture>();
  root.traverse(o => {
    if (!(o instanceof T.Mesh)) return;
    geometries.add(o.geometry); (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => materials.add(m));
  });
  materials.forEach(m => { Object.values(m).forEach(v => { if (v instanceof T.Texture && !v.isRenderTargetTexture) textures.add(v); }); m.dispose(); });
  geometries.forEach(g => g.dispose()); textures.forEach(t => t.dispose()); root.removeFromParent();
}