import * as T from 'three';
import { canvasTexture, textTexture, upholsteryTexture } from './materials';
import { box, roundedBox, stroke, mergeStatic } from './modelGeometry';
import type { VehicleId } from './types';

export interface CabinRig {
  group: T.Group;
  steeringWheel: T.Group;
  handbrakeLever: T.Group;
  gearLever: T.Group;
  gaugeNeedles: T.Group[];
  mirror: T.Mesh<T.PlaneGeometry, T.MeshBasicMaterial>;
  illumination: T.MeshStandardMaterial[];
  driverSeat: T.Group;
  odometer: T.CanvasTexture;
  odometerCanvas: HTMLCanvasElement;
}

function grainTexture() {
  const t = canvasTexture(256, 256, c => {
    c.fillStyle = '#888'; c.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 18000; i++) {
      c.fillStyle = i % 2 ? '#8e8e8e' : '#7c7c7c';
      c.fillRect((i * 67.73) % 256, (i * 173.71) % 256, 1, 1);
    }
  });
  t.colorSpace = T.NoColorSpace; t.wrapS = t.wrapT = T.RepeatWrapping; t.repeat.set(4, 2); return t;
}

function clusterTexture(pride: boolean) {
  return canvasTexture(1024, 384, c => {
    c.fillStyle = '#0b1110'; c.fillRect(0, 0, 1024, 384);
    const mainGauge = (cx: number, max: number, label: string, redFrom: number) => {
      c.strokeStyle = '#35413a'; c.lineWidth = 2; c.beginPath(); c.arc(cx, 192, 148, 0, Math.PI * 2); c.stroke();
      for (let tick = 0; tick <= 40; tick++) {
        const a = (140 + tick / 40 * 260) * Math.PI / 180;
        c.strokeStyle = tick / 40 >= redFrom ? '#d35236' : '#c3c8b3'; c.lineWidth = tick % 5 === 0 ? 3 : 1.4;
        c.beginPath(); c.moveTo(cx + Math.cos(a) * 137, 192 + Math.sin(a) * 137);
        c.lineTo(cx + Math.cos(a) * (tick % 5 === 0 ? 120 : 127), 192 + Math.sin(a) * (tick % 5 === 0 ? 120 : 127)); c.stroke();
        if (tick % 5 === 0) {
          c.fillStyle = '#d3d7bf'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = pride ? '23px Arial' : '22px Arial';
          c.fillText(String(Math.round(tick / 40 * max)), cx + Math.cos(a) * 97, 192 + Math.sin(a) * 97);
        }
      }
      c.fillStyle = '#b0bd9e'; c.font = '15px Arial'; c.fillText(label, cx, 260);
      c.fillStyle = '#525c49'; c.fillRect(cx - 51, 288, 102, 27);
      c.fillStyle = '#d0d4b8'; c.font = '19px monospace'; c.fillText(label === 'km/h' ? '040505' : 'X 1000', cx, 302);
    };
    mainGauge(335, 8, 'RPM', pride ? 0.75 : 0.85);
    mainGauge(677, pride ? 200 : 240, 'km/h', 2);
    for (const [x, top, bottom] of [[103, 'H', 'C'], [931, 'F', 'E']] as const) {
      c.strokeStyle = '#7c8b76'; c.lineWidth = 2; c.beginPath(); c.arc(x, 201, 63, -2.5, -0.65); c.stroke();
      c.fillStyle = '#c1c9ae'; c.font = '17px Arial'; c.fillText(top, x + 53, 148); c.fillText(bottom, x - 53, 162);
      c.strokeStyle = '#d9ae6b'; c.lineWidth = 3; c.beginPath(); c.moveTo(x, 201); c.lineTo(x + 4, 147); c.stroke();
    }
    c.font = '13px Arial'; c.fillStyle = '#536345'; c.fillText(pride ? 'SAIPA' : 'PEUGEOT', 512, 355);
    c.fillStyle = '#a58138'; c.fillRect(495, 167, 29, 13); c.fillStyle = '#984b38'; c.fillRect(495, 203, 29, 13);
    c.fillStyle = '#337056'; c.beginPath(); c.moveTo(88, 300); c.lineTo(111, 291); c.lineTo(111, 309); c.fill();
    c.beginPath(); c.moveTo(936, 300); c.lineTo(913, 291); c.lineTo(913, 309); c.fill();
  });
}

export function makeCabin(id: VehicleId): CabinRig {
  const pride = id === 'saipa141', width = pride ? 1.40 : 1.51;
  const group = new T.Group(), fixed = new T.Group(); group.add(fixed);
  const grain = grainTexture();
  const charcoal = new T.MeshStandardMaterial({ color: pride ? '#45494a' : '#303532', bumpMap: grain, bumpScale: 0.0016, roughness: 0.87 });
  const lower = new T.MeshStandardMaterial({ color: pride ? '#666a65' : '#44473f', roughness: 0.94, bumpMap: grain, bumpScale: 0.0012 });
  const black = new T.MeshStandardMaterial({ color: '#101714', roughness: 0.76 });
  const ventMat = new T.MeshStandardMaterial({ color: '#242f2a', roughness: 0.6 });
  const leather = new T.MeshStandardMaterial({ color: '#1d2520', roughness: 0.66, bumpMap: grain, bumpScale: 0.001 });
  const metal = new T.MeshStandardMaterial({ color: '#a7afa2', metalness: 0.72, roughness: 0.38 });
  const cloth = new T.MeshStandardMaterial({ color: pride ? '#bfc4bb' : '#a6afa4', map: upholsteryTexture(), roughness: 1 });
  const line = new T.MeshStandardMaterial({ color: '#787e6c', roughness: 0.95 });
  const clusterX = pride ? -0.315 : -0.355, clusterY = pride ? 1.02 : 1.017;
  const clusterW = pride ? 0.505 : 0.56, clusterH = 0.21, clusterZ = pride ? -0.535 : -0.607;

  // The GLX's broad horizontal dash, deep rectangular binnacle and square centre stack.
  roundedBox(fixed, [width, 0.13, 0.42], [0, 0.977, pride ? -0.75 : -0.84], charcoal, 0.04);
  roundedBox(fixed, [width - 0.12, 0.019, 0.84], [0, pride ? 1.42 : 1.385, 0.02], lower, 0.008);
  roundedBox(fixed, [width - 0.02, 0.19, 0.145], [0, 0.86, pride ? -0.563 : -0.628], lower, 0.015);
  roundedBox(fixed, [clusterW + 0.07, 0.255, 0.19], [clusterX, clusterY, clusterZ - 0.108], charcoal, pride ? 0.05 : 0.022);
  roundedBox(fixed, [clusterW + 0.025, 0.231, 0.02], [clusterX, clusterY, clusterZ - 0.011], black, 0.014);
  const face = clusterTexture(pride);
  const dialMat = new T.MeshStandardMaterial({ map: face, emissiveMap: face, emissive: '#c1d0a4', emissiveIntensity: 0.16, roughness: 0.83 });
  const dialMesh = new T.Mesh(new T.PlaneGeometry(clusterW, clusterH), dialMat);
  dialMesh.position.set(clusterX, clusterY, clusterZ + 0.003); fixed.add(dialMesh);
  roundedBox(fixed, [clusterW + 0.115, 0.025, 0.23], [clusterX, clusterY + 0.127, clusterZ - 0.06], charcoal, 0.009);

  const vent = (x: number, y: number, z: number, w: number, h: number) => {
    roundedBox(fixed, [w + 0.017, h + 0.017, 0.022], [x, y, z], charcoal, 0.008);
    box(fixed, [w, h, 0.012], [x, y, z + 0.015], black);
    for (let i = 0; i < 6; i++) box(fixed, [w - 0.011, 0.004, 0.014], [x, y - h * 0.42 + i * h * 0.168, z + 0.028], ventMat);
    box(fixed, [0.007, h - 0.014, 0.011], [x, y, z + 0.035], ventMat);
    box(fixed, [0.024, 0.007, 0.014], [x + w * 0.16, y, z + 0.037], black);
  };
  const centerX = 0.14, centerZ = pride ? -0.526 : -0.598;
  roundedBox(fixed, [0.325, 0.385, 0.15], [centerX, 0.825, centerZ - 0.04], charcoal, pride ? 0.045 : 0.01);
  vent(-width / 2 + 0.08, 0.979, centerZ + 0.011, 0.104, 0.07);
  vent(width / 2 - 0.093, 0.979, centerZ + 0.009, 0.12, 0.08);
  vent(centerX - 0.076, 0.991, centerZ + 0.02, 0.123, 0.067);
  vent(centerX + 0.077, 0.991, centerZ + 0.02, 0.123, 0.067);
  const labelMaterial = (text: string, color = '#aabfa5', background = '#19251e') => new T.MeshStandardMaterial({ map: textTexture(text, color, background), emissive: '#788368', emissiveIntensity: 0.09, roughness: 0.8 });
  const radio = new T.Mesh(new T.PlaneGeometry(0.21, 0.04), labelMaterial('FM  102.0', '#b5c988', '#16261b'));
  radio.position.set(centerX, 0.852, centerZ + 0.048); fixed.add(radio);
  for (let i = 0; i < 6; i++) box(fixed, [0.026, 0.012, 0.012], [centerX - 0.10 + i * 0.04, 0.818, centerZ + 0.051], black);
  for (let i = 0; i < 3; i++) {
    const knob = new T.Mesh(new T.CylinderGeometry(0.021, 0.022, 0.016, 24), black);
    knob.rotation.x = Math.PI / 2; knob.position.set(centerX - 0.084 + i * 0.084, 0.737, centerZ + 0.043); fixed.add(knob);
    box(fixed, [0.003, 0.009, 0.003], [centerX - 0.084 + i * 0.084, 0.748, centerZ + 0.053], line);
    const arc = new T.Mesh(new T.TorusGeometry(0.029, 0.0014, 3, 22, Math.PI * 1.4), line);
    arc.position.set(centerX - 0.084 + i * 0.084, 0.737, centerZ + 0.035); arc.rotation.z = -0.22; fixed.add(arc);
  }
  const hazard = new T.Mesh(new T.PlaneGeometry(0.025, 0.029), labelMaterial('△', '#d66349', '#222821'));
  hazard.position.set(centerX, 0.914, centerZ + 0.045); fixed.add(hazard);
  box(fixed, [0.114, 0.015, 0.012], [centerX - 0.084, 0.915, centerZ + 0.04], black);
  box(fixed, [0.091, 0.015, 0.012], [centerX + 0.085, 0.915, centerZ + 0.04], black);
  roundedBox(fixed, [0.45, 0.16, 0.037], [0.498, 0.893, centerZ - 0.01], lower, 0.015);
  box(fixed, [0.097, 0.015, 0.017], [0.475, 0.937, centerZ + 0.018], black);
  stroke(fixed, [0.312, 0.821, centerZ + 0.011], [0.705, 0.821, centerZ + 0.011], 0.0025, black);
  for (let i = 0; i < 12; i++) box(fixed, [0.059, 0.003, 0.004], [-0.59 + i * 0.11, 1.043, pride ? -0.872 : -0.958], black);

  roundedBox(fixed, [0.21, 0.13, 0.86], [0.015, 0.535, -0.09], charcoal, 0.03);
  box(fixed, [width - 0.10, 0.032, 1.91], [0, 0.354, 0.02], black);
  box(fixed, [0.57, 0.012, 0.52], [-0.36, 0.381, -0.60], leather);
  for (const [x, w] of [[-0.49, 0.054], [-0.345, 0.065], [-0.235, 0.042]]) {
    box(fixed, [w, 0.10, 0.021], [x, 0.462, -0.78], black, [-0.22, 0, 0]);
    for (let i = 0; i < 4; i++) box(fixed, [w - 0.008, 0.003, 0.004], [x, 0.433 + i * 0.019, -0.762], line);
  }
  for (const side of [-1, 1]) {
    const x = side * (width / 2 - 0.012);
    roundedBox(fixed, [0.048, 0.44, 0.95], [x, 0.714, -0.16], lower, 0.018);
    roundedBox(fixed, [0.075, 0.07, 0.49], [x - side * 0.036, 0.783, -0.06], charcoal, 0.015);
    box(fixed, [0.012, 0.048, 0.092], [x - side * 0.028, 0.892, -0.431], black);
    box(fixed, [0.013, 0.014, 0.059], [x - side * 0.038, 0.898, -0.435], metal);
    box(fixed, [0.018, 0.015, 0.055], [x - side * 0.077, 0.822, -0.193], black);
    stroke(fixed, [side * 0.773, 1.015, -0.962], [side * 0.685, 1.382, -0.402], pride ? 0.034 : 0.038, charcoal);
    stroke(fixed, [side * 0.70, 1.377, -0.4], [side * 0.70, 1.377, 0.48], 0.021, lower);
    box(fixed, [0.037, 0.032, 0.020], [side * 0.69, 1.383, 0.18], lower);
    stroke(fixed, [side * 0.69, 1.36, 0.155], [side * 0.69, 1.36, 0.295], 0.012, lower);
    roundedBox(fixed, [0.012, 0.088, 0.175], [x - side * 0.029, 0.568, -0.354], black, 0.003);
  }
  const seat = (x: number) => {
    const s = new T.Group();
    roundedBox(s, [0.47, 0.12, 0.52], [x, 0.602, 0.10], cloth, 0.035);
    const back = roundedBox(s, [0.45, 0.44, 0.14], [x, 0.88, 0.346], cloth, 0.025); back.rotation.x = -0.12;
    for (const side of [-1, 1]) roundedBox(s, [0.06, 0.41, 0.17], [x + side * 0.209, 0.88, 0.34], charcoal, 0.022);
    roundedBox(s, [0.258, 0.151, 0.089], [x, 1.189, 0.369], cloth, 0.026);
    for (const side of [-1, 1]) stroke(s, [x + side * 0.077, 1.085, 0.36], [x + side * 0.077, 1.161, 0.36], 0.005, metal);
    for (const dx of [-0.12, 0.12]) stroke(s, [x + dx, 0.672, -0.10], [x + dx, 0.672, 0.28], 0.0018, line);
    mergeStatic(s); return s;
  };
  const driverSeat = seat(pride ? -0.325 : -0.355); group.add(driverSeat, seat(0.35));
  roundedBox(fixed, [width - 0.2, 0.09, 0.43], [0, 0.595, 0.81], cloth, 0.04);
  const rearSeat = roundedBox(fixed, [width - 0.22, 0.4, 0.15], [0, 0.844, 1.04], cloth, 0.04); rearSeat.rotation.x = -0.11;
  for (const x of [-0.37, 0.37]) {
    roundedBox(fixed, [0.235, 0.133, 0.08], [x, 1.112, 1.077], cloth, 0.029);
    box(fixed, [0.038, 0.064, 0.02], [x, 0.664, 0.589], black);
  }
  roundedBox(fixed, [0.30, 0.039, 0.14], [-0.30, 1.389, -0.19], lower, 0.009);
  roundedBox(fixed, [0.30, 0.039, 0.14], [0.34, 1.389, -0.19], lower, 0.009);
  stroke(fixed, [0.025, 1.377, -0.375], [0.025, 1.321, -0.453], 0.007, black);
  roundedBox(fixed, [0.271, 0.089, 0.025], [0.025, 1.302, -0.463], black, 0.009);
  box(fixed, [0.032, 0.009, 0.012], [0.025, 1.251, -0.461], black);
  mergeStatic(fixed);

  const steeringMount = new T.Group(); steeringMount.position.set(clusterX, pride ? 0.97 : 0.962, pride ? -0.265 : -0.319); steeringMount.rotation.x = -0.27;
  const steeringWheel = new T.Group();
  const rim = new T.Mesh(new T.TorusGeometry(pride ? 0.164 : 0.177, 0.022, 10, 64), leather); steeringWheel.add(rim);
  roundedBox(steeringWheel, [pride ? 0.15 : 0.191, pride ? 0.093 : 0.096, 0.051], [0, -0.014, 0], charcoal, 0.018);
  for (const s of [-1, 1]) {
    const spoke = box(steeringWheel, [0.065, 0.044, 0.027], [s * 0.125, 0.002, -0.012], charcoal); spoke.rotation.z = s * 0.13;
  }
  if (pride) stroke(steeringWheel, [0, -0.022, -0.012], [0, -0.155, -0.012], 0.013, charcoal);
  const emblem = new T.Mesh(new T.PlaneGeometry(pride ? 0.042 : 0.035, 0.031), new T.MeshStandardMaterial({ map: textTexture(pride ? 'SAIPA' : 'P', '#bec2b5'), transparent: true, roughness: 0.5 }));
  emblem.position.set(0, -0.012, 0.028); steeringWheel.add(emblem);
  for (const s of [-1, 1]) stroke(fixed, [clusterX + s * 0.07, 0.975, -0.42], [clusterX + s * 0.214, 0.998, -0.451], 0.007, black);
  mergeStatic(steeringWheel); steeringMount.add(steeringWheel); group.add(steeringMount);

  const handbrakeLever = new T.Group();
  stroke(handbrakeLever, [0, 0, 0], [0, 0.018, -0.17], 0.011, metal);
  roundedBox(handbrakeLever, [0.035, 0.028, 0.12], [0, 0.024, -0.12], leather, 0.01);
  mergeStatic(handbrakeLever); handbrakeLever.position.set(0.025, 0.615, 0.255); group.add(handbrakeLever);
  const gearLever = new T.Group();
  const boot = new T.Mesh(new T.ConeGeometry(0.045, 0.079, 12), leather); boot.position.y = 0.03; gearLever.add(boot);
  stroke(gearLever, [0, 0.034, 0], [0, 0.155, 0], 0.008, black);
  const knob = new T.Mesh(new T.SphereGeometry(0.027, 24, 16), leather); knob.scale.set(0.87, 1, 1); knob.position.y = 0.151; gearLever.add(knob);
  const shiftPattern = new T.Mesh(new T.PlaneGeometry(0.023, 0.017), new T.MeshStandardMaterial({ map: textTexture('1 3 5', '#dfdfce'), transparent: true }));
  shiftPattern.position.set(0, 0.177, 0); shiftPattern.rotation.x = -Math.PI / 2; gearLever.add(shiftPattern);
  mergeStatic(gearLever); gearLever.position.set(0.015, 0.613, -0.19); group.add(gearLever);

  const gaugeNeedles: T.Group[] = [];
  for (const px of [677, 335]) {
    const needle = new T.Group();
    needle.position.set(clusterX + (px / 1024 - 0.5) * clusterW, clusterY, clusterZ + 0.011);
    const needleMat = new T.MeshBasicMaterial({ color: '#e9ac71', toneMapped: false });
    box(needle, [0.0019, 0.068, 0.0013], [0, 0.024, 0], needleMat);
    const cap = new T.Mesh(new T.CircleGeometry(0.006, 16), charcoal); cap.position.z = 0.001; needle.add(cap);
    group.add(needle); gaugeNeedles.push(needle);
  }
  const mirror = new T.Mesh(new T.PlaneGeometry(0.248, 0.07), new T.MeshBasicMaterial({ color: '#a6b3a5', toneMapped: false }));
  mirror.position.set(0.025, 1.302, -0.448); group.add(mirror);
  const odometer = canvasTexture(256, 64, c => { c.fillStyle = '#1a2b1b'; c.fillRect(0, 0, 256, 64); });
  const odometerMat = new T.MeshStandardMaterial({ map: odometer, emissiveMap: odometer, emissive: '#c7d1aa', emissiveIntensity: 0.3 });
  const trip = new T.Mesh(new T.PlaneGeometry(0.074, 0.019), odometerMat);
  trip.position.set(clusterX + (677 / 1024 - 0.5) * clusterW, clusterY - 0.061, clusterZ + 0.012); group.add(trip);
  return { group, steeringWheel, handbrakeLever, gearLever, gaugeNeedles, mirror, driverSeat, illumination: [dialMat, odometerMat], odometer, odometerCanvas: odometer.image as HTMLCanvasElement };
}