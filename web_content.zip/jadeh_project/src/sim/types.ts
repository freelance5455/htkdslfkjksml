export type Quality = 'low' | 'medium' | 'high';
export type TimeOfDay = 'golden' | 'day' | 'night';
export type Weather = 'clear' | 'rain';
export type Mode = 'menu' | 'garage' | 'playing' | 'paused' | 'finished';
export type VehicleId = 'peugeot405' | 'saipa141';
export const CAMERA_NAMES = ['CHASE', 'COCKPIT', 'WIDE CHASE', 'BONNET'] as const;
export const COCKPIT_CAMERA = 1;
export interface Preferences {
  quality: Quality;
  time: TimeOfDay;
  weather: Weather;
  density: number;
  volume: number;
  muted: boolean;
  color: string;
  abs: boolean;
  sportExhaust: boolean;
  vehicleId: VehicleId;
  adaptiveResolution: boolean;
  startInCockpit: boolean;
}
export interface Telemetry {
  speed: number;
  rpm: number;
  gear: number;
  distance: number;
  score: number;
  nearMisses: number;
  damage: number;
  seconds: number;
  combo: number;
  fps: number;
  camera: number;
  limiter: boolean;
  fuelCut: boolean;
  handbrake: boolean;
  neutral: boolean;
  gearHeld: boolean;
  vehicleId: VehicleId;
  redline: number;
  renderWidth: number;
  renderHeight: number;
}
export interface Controls {
  gas: boolean;
  brake: boolean;
  left: boolean;
  right: boolean;
  handbrake: boolean;
  horn: boolean;
  rev: boolean;
}
export const DEFAULTS: Preferences = {
  quality: 'high', time: 'golden', weather: 'clear', density: 0.7,
  volume: 0.55, muted: false, color: '#ecede8', abs: true, sportExhaust: true,
  vehicleId: 'peugeot405', adaptiveResolution: false, startInCockpit: true,
};
export const EMPTY_TELEMETRY: Telemetry = {
  speed: 0, rpm: 880, gear: 1, distance: 0, score: 0, nearMisses: 0,
  damage: 0, seconds: 0, combo: 1, fps: 60, camera: 0,
  limiter: false, fuelCut: false, handbrake: false, neutral: false, gearHeld: false,
  vehicleId: 'peugeot405', redline: 6800, renderWidth: 0, renderHeight: 0,
};
export const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x));
export const damp = (a: number, b: number, rate: number, dt: number) => a + (b - a) * (1 - Math.exp(-rate * dt));
export function random(seed: number) { const x = Math.sin(seed * 127.1 + 19.7) * 43758.5453; return x - Math.floor(x); }