import * as T from 'three';
import { makeCabin } from './cabin';
import { box, roundedBox, surface, stroke, mergeStatic, type V3 } from './modelGeometry';
import { lensTexture, plateTexture, shadowTexture, textTexture, tyreSidewallTexture } from './materials';
import type { VehicleModel } from './vehicleModel';

// Separate 141 liftback shell: short wheelbase, raised tail, three-section vertical rear lamps.
export function makeSaipa141(color = '#555a59'): VehicleModel {
  const root = new T.Group(), body = new T.Group(); root.add(body);
  const paint = new T.MeshPhysicalMaterial({ color, metalness: 0.5, roughness: 0.255, clearcoat: 0.9, clearcoatRoughness: 0.19, envMapIntensity: 1.05, side: T.DoubleSide });
  const trim = new T.MeshStandardMaterial({ color: '#222726', roughness: 0.85 });
  const dark = new T.MeshStandardMaterial({ color: '#111818', roughness: 0.8, side: T.DoubleSide });
  const seam = new T.MeshStandardMaterial({ color: '#343b39', roughness: 0.71, side: T.DoubleSide });
  const chrome = new T.MeshStandardMaterial({ color: '#b4bcb7', metalness: 0.72, roughness: 0.31 });
  const silver = new T.MeshStandardMaterial({ color: '#abb0aa', metalness: 0.36, roughness: 0.37 });
  const windows = new T.MeshPhysicalMaterial({ color: '#233637', metalness: 0.36, roughness: 0.1, clearcoat: 1, transparent: true, opacity: 0.70, depthWrite: false, side: T.DoubleSide });
  const lens = lensTexture();
  const lightMaterial = new T.MeshStandardMaterial({ map: lens, color: '#dce2d6', metalness: 0.15, roughness: 0.24, emissive: '#ffe8b0', emissiveIntensity: 0.15 });
  const brakeMaterial = new T.MeshStandardMaterial({ color: '#a62125', map: lens, emissive: '#ff2b18', emissiveIntensity: 0.17, roughness: 0.21, side: T.DoubleSide });
  const clearLamp = new T.MeshStandardMaterial({ map: lens, color: '#d5dbd0', metalness: 0.2, roughness: 0.28, side: T.DoubleSide });
  const orange = new T.MeshStandardMaterial({ color: '#bf5b23', roughness: 0.4 });

  const sideShape = new T.Shape();
  sideShape.moveTo(-1.94, 0.37); sideShape.lineTo(-1.968, 0.7);
  sideShape.quadraticCurveTo(-1.953, 0.84, -1.82, 0.89); sideShape.lineTo(-1.015, 0.98);
  sideShape.lineTo(0.23, 0.987); sideShape.lineTo(1.24, 1.015); sideShape.lineTo(1.66, 1.108);
  sideShape.quadraticCurveTo(1.94, 1.085, 1.965, 0.963); sideShape.lineTo(1.93, 0.367); sideShape.lineTo(1.492, 0.367);
  sideShape.absarc(1.1725, 0.299, 0.328, 0.21, Math.PI - 0.21, false);
  sideShape.lineTo(-0.845, 0.37); sideShape.absarc(-1.1725, 0.298, 0.328, 0.21, Math.PI - 0.21, false);
  sideShape.lineTo(-1.94, 0.37); sideShape.closePath();
  const sideGeometry = new T.ExtrudeGeometry(sideShape, { depth: 0.035, bevelEnabled: true, bevelSize: 0.014, bevelThickness: 0.01, bevelSegments: 3, curveSegments: 18 });
  sideGeometry.translate(0, 0, -0.0175); sideGeometry.rotateY(-Math.PI / 2);
  for (const s of [-1, 1]) {
    const side = new T.Mesh(sideGeometry.clone(), paint); side.position.x = s * 0.775; body.add(side);
  }
  sideGeometry.dispose();
  surface(body, [[-0.77, 0.977, -1.015], [0.77, 0.977, -1.015], [0.746, 0.877, -1.868], [-0.746, 0.877, -1.868]], paint);
  surface(body, [[-0.746, 0.877, -1.868], [0.746, 0.877, -1.868], [0.70, 0.818, -1.958], [-0.70, 0.818, -1.958]], paint);
  roundedBox(body, [1.55, 0.34, 0.089], [0, 0.664, -1.92], paint, 0.028);
  box(body, [1.42, 0.063, 2.92], [0, 0.29, -0.01], dark);
  surface(body, [[-0.663, 1.452, -0.381], [0.663, 1.452, -0.381], [0.657, 1.446, 0.534], [-0.657, 1.446, 0.534]], paint);
  surface(body, [[-0.755, 1.011, -0.982], [0.755, 1.011, -0.982], [0.643, 1.423, -0.408], [-0.643, 1.423, -0.408]], windows);
  surface(body, [[-0.665, 1.415, 0.558], [0.665, 1.415, 0.558], [0.682, 1.132, 1.575], [-0.682, 1.132, 1.575]], windows);
  surface(body, [[-0.683, 1.129, 1.60], [0.683, 1.129, 1.60], [0.728, 1.105, 1.917], [-0.728, 1.105, 1.917]], paint);
  roundedBox(body, [1.43, 0.033, 0.079], [0, 1.136, 1.699], trim, 0.013);

  for (const s of [-1, 1]) {
    const sx = (x: number) => s * x;
    stroke(body, [sx(0.773), 0.999, -0.984], [sx(0.662), 1.44, -0.393], 0.036, paint);
    stroke(body, [sx(0.675), 1.435, -0.395], [sx(0.666), 1.433, 0.551], 0.022, paint);
    stroke(body, [sx(0.771), 0.999, -0.991], [sx(0.786), 1.02, 1.169], 0.016, dark);
    stroke(body, [sx(0.686), 1.409, -0.33], [sx(0.681), 1.407, 0.52], 0.008, chrome);
    surface(body, [[sx(0.773), 1.012, -0.872], [sx(0.686), 1.403, -0.341], [sx(0.687), 1.399, 0.08], [sx(0.782), 1.018, 0.087]], windows);
    surface(body, [[sx(0.783), 1.018, 0.163], [sx(0.688), 1.40, 0.163], [sx(0.686), 1.393, 0.471], [sx(0.785), 1.02, 0.851]], windows);
    surface(body, [[sx(0.786), 1.022, 0.908], [sx(0.694), 1.37, 0.526], [sx(0.76), 1.04, 1.145]], windows);
    surface(body, [[sx(0.784), 1.014, 0.086], [sx(0.688), 1.414, 0.086], [sx(0.688), 1.413, 0.155], [sx(0.784), 1.018, 0.155]], dark);
    stroke(body, [sx(0.785), 1.024, 0.873], [sx(0.687), 1.397, 0.497], 0.016, dark);
    surface(body, [[sx(0.69), 1.438, 0.52], [sx(0.676), 1.436, 0.65], [sx(0.762), 1.115, 1.601], [sx(0.793), 1.019, 1.183]], paint);
    stroke(body, [sx(0.667), 1.442, 0.55], [sx(0.682), 1.142, 1.603], 0.017, dark);
    for (const z of [-0.895, 0.12, 1.151]) stroke(body, [sx(0.806), 0.987, z], [sx(0.807), 0.422, z - 0.02], 0.004, dark);
    stroke(body, [sx(0.81), 0.418, -0.895], [sx(0.81), 0.418, 0.842], 0.004, dark);
    roundedBox(body, [0.039, 0.069, 1.74], [sx(0.812), 0.619, -0.007], trim, 0.008);
    box(body, [0.012, 0.017, 0.804], [sx(0.839), 0.635, -0.472], chrome);
    box(body, [0.012, 0.017, 0.725], [sx(0.839), 0.635, 0.42], chrome);
    for (const z of [-0.191, 0.7]) {
      roundedBox(body, [0.025, 0.077, 0.145], [sx(0.803), 0.904, z], dark, 0.014);
      box(body, [0.032, 0.026, 0.099], [sx(0.816), 0.894, z], trim);
    }
    const sideLamp = new T.Mesh(new T.SphereGeometry(0.032, 14, 8), orange); sideLamp.scale.set(0.20, 0.57, 1); sideLamp.position.set(sx(0.805), 0.787, -1.293); body.add(sideLamp);
    box(body, [0.088, 0.039, 0.07], [sx(0.812), 1.022, -0.791], dark);
    roundedBox(body, [0.17, 0.126, 0.176], [sx(0.911), 1.064, -0.786], trim, 0.029);
    box(body, [0.124, 0.095, 0.013], [sx(0.926), 1.065, -0.69], chrome);
    for (const wz of [-1.1725, 1.1725]) {
      const arch = new T.Mesh(new T.TorusGeometry(0.332, 0.008, 5, 36, Math.PI), paint); arch.rotation.y = Math.PI / 2; arch.position.set(sx(0.806), 0.299, wz); body.add(arch);
      box(body, [0.08, 0.154, 0.029], [sx(0.753), 0.301, wz + 0.312], trim);
    }
    stroke(body, [sx(0.74), 0.884, -1.86], [sx(0.73), 0.974, -1.052], 0.003, dark);
  }
  roundedBox(body, [1.615, 0.242, 0.275], [0, 0.588, 1.88], trim, 0.058);
  roundedBox(body, [1.59, 0.205, 0.207], [0, 0.507, -1.903], trim, 0.045);
  stroke(body, [-0.758, 0.678, 2.027], [0.758, 0.678, 2.027], 0.009, dark);
  roundedBox(body, [1.435, 0.053, 0.03], [0, 0.742, 1.98], dark, 0.007);
  roundedBox(body, [0.70, 0.057, 0.014], [0, 0.587, -2.013], dark, 0.009);
  for (const s of [-1, 1]) {
    roundedBox(body, [0.299, 0.168, 0.048], [s * 0.547, 0.763, -1.973], lightMaterial, 0.024);
    box(body, [0.053, 0.145, 0.036], [s * 0.73, 0.759, -1.937], clearLamp);
  }
  roundedBox(body, [0.59, 0.143, 0.028], [0, 0.747, -1.984], dark, 0.026);
  for (let i = 0; i < 3; i++) box(body, [0.559, 0.012, 0.014], [0, 0.708 + i * 0.035, -2.008], chrome);
  roundedBox(body, [0.069, 0.056, 0.009], [0, 0.754, -2.022], silver, 0.018);

  // Rear hatch surround leaves a real recessed plate pocket under its horizontal handle.
  box(body, [0.434, 0.342, 0.067], [-0.568, 0.923, 1.92], paint);
  box(body, [0.434, 0.342, 0.067], [0.568, 0.923, 1.92], paint);
  roundedBox(body, [1.32, 0.098, 0.047], [0, 1.076, 1.939], paint, 0.025);
  box(body, [1.365, 0.105, 0.052], [0, 0.797, 1.938], paint);
  const recessPaint = new T.MeshStandardMaterial({ color: new T.Color(color).multiplyScalar(0.64), metalness: 0.4, roughness: 0.39 });
  roundedBox(body, [0.709, 0.216, 0.024], [0, 0.946, 1.914], recessPaint, 0.025);
  roundedBox(body, [0.75, 0.043, 0.051], [0, 1.059, 1.99], dark, 0.013);
  stroke(body, [-0.343, 0.842, 1.951], [0.343, 0.842, 1.951], 0.005, chrome);
  for (const s of [-1, 1]) {
    const x = (v: number) => s * v;
    const points: V3[] = [[x(0.506), 0.82, 1.987], [x(0.783), 0.824, 1.981], [x(0.746), 1.168, 1.934], [x(0.579), 1.183, 1.944]];
    surface(body, points, dark);
    surface(body, [[x(0.525), 0.835, 2.0], [x(0.769), 0.84, 1.996], [x(0.758), 0.928, 1.989], [x(0.547), 0.928, 1.994]], brakeMaterial);
    surface(body, [[x(0.549), 0.937, 1.998], [x(0.755), 0.937, 1.988], [x(0.747), 1.041, 1.972], [x(0.564), 1.044, 1.981]], clearLamp);
    surface(body, [[x(0.568), 1.05, 1.981], [x(0.745), 1.05, 1.97], [x(0.734), 1.152, 1.951], [x(0.59), 1.166, 1.96]], brakeMaterial);
    for (let i = 0; i < 6; i++) stroke(body, [x(0.559), 0.946 + i * 0.015, 2.0 - i * 0.002], [x(0.75), 0.946 + i * 0.015, 1.993 - i * 0.002], 0.0019, chrome);
    box(body, [0.003, 0.342, 0.005], [x(0.495), 0.926, 1.987], dark);
    const lampReflector = new T.Mesh(new T.SphereGeometry(0.043, 12, 10), brakeMaterial); lampReflector.scale.set(1, 0.77, 0.12); lampReflector.position.set(x(0.636), 0.877, 2.012); body.add(lampReflector);
  }
  for (const [label, x, width] of [['SAIPA', -0.408, 0.162], ['141 SE', 0.391, 0.174]] as const) {
    const badge = new T.Mesh(new T.PlaneGeometry(width, 0.036), new T.MeshStandardMaterial({ map: textTexture(label, '#cdd3d0'), transparent: true, metalness: 0.7, roughness: 0.24 }));
    badge.position.set(x, 1.099, 1.972); body.add(badge);
  }
  const hatchLock = new T.Mesh(new T.CylinderGeometry(0.011, 0.011, 0.008, 12), chrome); hatchLock.rotation.x = Math.PI / 2; hatchLock.position.set(0, 1.099, 1.973); body.add(hatchLock);
  const plate = new T.MeshStandardMaterial({ map: plateTexture('۱۴۱'), roughness: 0.6 });
  const rearPlate = new T.Mesh(new T.PlaneGeometry(0.392, 0.099), plate); rearPlate.position.set(0, 0.936, 1.939); body.add(rearPlate);
  const frontPlate = new T.Mesh(new T.PlaneGeometry(0.381, 0.098), plate); frontPlate.rotation.y = Math.PI; frontPlate.position.set(0, 0.516, -2.013); body.add(frontPlate);
  const fuel: V3[] = [[-0.81, 0.934, 1.18], [-0.81, 0.934, 1.367], [-0.81, 0.792, 1.367], [-0.81, 0.792, 1.18]];
  fuel.forEach((p, i) => stroke(body, p, fuel[(i + 1) % 4], 0.003, dark));
  const capLock = new T.Mesh(new T.SphereGeometry(0.008, 8, 8), chrome); capLock.scale.x = 0.3; capLock.position.set(-0.815, 0.85, 1.318); body.add(capLock);
  for (const s of [-1, 1]) stroke(body, [s * 0.57, 1.02, -0.978], [s * 0.07, 1.073, -0.914], 0.005, dark);
  for (let i = 0; i < 9; i++) {
    const z = 0.672 + i * 0.09, y = 1.389 - i * 0.025;
    stroke(body, [-0.603, y, z], [0.603, y, z], 0.0016, chrome);
  }
  box(body, [0.225, 0.027, 0.043], [0, 1.412, 0.738], brakeMaterial);
  const pipe = new T.Mesh(new T.CylinderGeometry(0.028, 0.028, 0.246, 16, 1, true), chrome); pipe.rotation.x = Math.PI / 2; pipe.position.set(0.47, 0.32, 1.90); body.add(pipe);
  mergeStatic(body);
  const cabin = makeCabin('saipa141'); body.add(cabin.group);

  const wheels: T.Group[] = [];
  const letteringMaterial = new T.MeshStandardMaterial({ map: tyreSidewallTexture('165/65 R13'), transparent: true, opacity: 0.42, depthWrite: false, roughness: 1 });
  for (const z of [-1.1725, 1.1725]) for (const side of [-1, 1]) {
    const wheel = new T.Group(), detail = new T.Group();
    const profile = [[0.177, -0.071], [0.248, -0.094], [0.279, -0.059], [0.283, -0.025], [0.283, 0.025], [0.279, 0.059], [0.248, 0.094], [0.177, 0.071]].map(([x, y]) => new T.Vector2(x, y));
    const tire = new T.Mesh(new T.LatheGeometry(profile, 40), dark); tire.rotation.z = Math.PI / 2; detail.add(tire);
    const rim = new T.Mesh(new T.CylinderGeometry(0.187, 0.187, 0.023, 40), silver); rim.rotation.z = Math.PI / 2; rim.position.x = side * 0.083; detail.add(rim);
    for (let i = 0; i < 5; i++) {
      const angle = i / 5 * Math.PI * 2;
      const opening = new T.Mesh(new T.SphereGeometry(0.035, 12, 8), trim); opening.scale.set(0.12, 1, 0.49);
      opening.rotation.x = angle; opening.position.set(side * 0.099, Math.cos(angle) * 0.15, Math.sin(angle) * 0.15); detail.add(opening);
      const spoke = box(detail, [0.009, 0.047, 0.141], [side * 0.106, Math.cos(angle) * 0.067, Math.sin(angle) * 0.067], silver, [angle + Math.PI / 2, 0, 0]);
      spoke.rotation.x = angle - Math.PI / 2;
    }
    const hub = new T.Mesh(new T.CylinderGeometry(0.056, 0.056, 0.011, 24), silver); hub.rotation.z = Math.PI / 2; hub.position.x = side * 0.111; detail.add(hub);
    for (let i = 0; i < 4; i++) {
      const angle = i * Math.PI / 2;
      const bolt = new T.Mesh(new T.SphereGeometry(0.009, 8, 6), chrome); bolt.position.set(side * 0.112, Math.cos(angle) * 0.053, Math.sin(angle) * 0.053); detail.add(bolt);
    }
    for (let i = 0; i < 44; i++) {
      const a = i / 44 * Math.PI * 2;
      box(detail, [0.114, 0.003, 0.015], [0, Math.cos(a) * 0.283, Math.sin(a) * 0.283], seam, [a, 0, 0]);
    }
    for (const x of [-0.029, 0.029]) {
      const groove = new T.Mesh(new T.TorusGeometry(0.283, 0.0025, 3, 40), seam); groove.rotation.y = Math.PI / 2; groove.position.x = x; detail.add(groove);
    }
    const lettering = new T.Mesh(new T.CircleGeometry(0.269, 40), letteringMaterial); lettering.rotation.y = side * Math.PI / 2; lettering.position.x = side * 0.097; detail.add(lettering);
    mergeStatic(detail); wheel.add(detail); wheel.position.set(side * 0.743, 0.289, z); root.add(wheel); wheels.push(wheel);
  }
  const shadow = new T.Mesh(new T.PlaneGeometry(2.28, 5.1), new T.MeshBasicMaterial({ map: shadowTexture(), transparent: true, depthWrite: false, opacity: 0.62 }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = 0.018; root.add(shadow);
  return { root, body, wheels, paint, brakeMaterial, lightMaterial, windows: [windows], cabin };
}