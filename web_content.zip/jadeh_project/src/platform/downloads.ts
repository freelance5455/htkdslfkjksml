export function saveDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export async function standaloneHtml(): Promise<string> {
  let html: string;
  const bundled = [...document.scripts].some(s => !s.src && (s.textContent?.length || 0) > 100000);
  if (bundled) {
    html = document.documentElement.outerHTML;
  } else {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch('/dist/index.html', { cache: 'no-store', signal: controller.signal });
      if (!response.ok) throw new Error('The production HTML is not available.');
      html = await response.text();
    } finally { window.clearTimeout(timeout); }
  }
  const doc = new DOMParser().parseFromString(html, 'text/html');
  if (!doc.querySelector('meta[name="jadeh-build"][content="405-glx-standalone"]')) throw new Error('Expected the standalone JADEH build.');
  doc.querySelector('#root')?.replaceChildren();
  doc.querySelectorAll('script').forEach(script => {
    const source = script.textContent || '';
    if (script.getAttribute('src') || (source.length < 15000 && source.includes('/@react-refresh'))) script.remove();
  });
  if (![...doc.scripts].some(s => (s.textContent?.length || 0) > 100000)) throw new Error('No embedded game bundle. Build the web project first.');
  return '<!doctype html>\n' + doc.documentElement.outerHTML;
}