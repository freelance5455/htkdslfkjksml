import { strToU8, unzipSync, zipSync } from 'fflate';
import { saveDownload, standaloneHtml } from './downloads';

declare global {
  interface Window {
    __JADEH_NATIVE_BACK__?: () => boolean;
  }
}

export function isNativeAndroid() {
  return location.hostname === 'appassets.androidplatform.net' && navigator.userAgent.includes('JADEH-ANDROID/');
}

// Explicit allowlist: never export local.properties, keystores, credentials, or generated files.
const nativeSources = import.meta.glob<string>([
  '../../android/settings.gradle',
  '../../android/build.gradle',
  '../../android/gradle.properties',
  '../../android/.gitignore',
  '../../android/README.md',
  '../../android/verify-apk.py',
  '../../android/app/build.gradle',
  '../../android/app/src/main/AndroidManifest.xml',
  '../../android/app/src/main/java/net/jadeh/driving/MainActivity.java',
  '../../android/app/src/main/res/values/strings.xml',
  '../../android/app/src/main/res/values/styles.xml',
  '../../android/app/src/main/res/drawable/ic_launcher_foreground.xml',
  '../../android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
  '../../.github/workflows/android-apk.yml',
], { eager: true, query: '?raw', import: 'default' });

export async function exportAndroidSource() {
  const html = await standaloneHtml();
  const files: Record<string, Uint8Array> = {};
  for (const [path, content] of Object.entries(nativeSources)) files[path.replace(/^\.\.\/\.\.\//, '')] = strToU8(content);
  if (!files['android/app/build.gradle'] || !files['.github/workflows/android-apk.yml']) throw new Error('The Android source template is incomplete.');
  files['dist/index.html'] = strToU8(html);
  files['START-HERE.txt'] = strToU8([
    'JADEH 405 GLX - ANDROID SOURCE, NOT AN APK',
    '',
    'Read android/README.md for Persian build and install instructions.',
    'This ZIP cannot be installed. Extract it and upload ALL files, including .github, to a GitHub repository.',
    'Run Actions > Build Android APK > Run workflow.',
    'Only a successful Android build produces the installable APK in the run Artifacts.',
    'dist/index.html is the complete offline game included for the native build.',
    'The Android project has not been compiled or tested on a device in the editing environment.',
  ].join('\n'));
  // No workers or external scripts are needed to package this small, offline project.
  await new Promise(resolve => window.setTimeout(resolve, 40));
  const zip = zipSync(files, { level: 1 });
  saveDownload(new Blob([new Uint8Array(zip).buffer], { type: 'application/zip' }), 'JADEH-Android-Source.zip');
}

export interface AndroidRelease {
  schema: 1;
  available: true;
  filename: 'JADEH-405-GLX-debug.apk';
  version: string;
  kind: 'debug';
  sizeBytes: number;
  sha256: string;
  minAndroid: string;
}

function releaseUrl(file: string) { return new URL(`downloads/${file}`, new URL('.', location.href)); }

export async function checkAndroidRelease(signal: AbortSignal): Promise<AndroidRelease | null> {
  if (!['https:', 'http:'].includes(location.protocol) || isNativeAndroid()) return null;
  const response = await fetch(releaseUrl('android.json'), { cache: 'no-store', signal });
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not read APK availability.');
  const text = await response.text();
  if (text.length > 10000 || text.trimStart().startsWith('<')) return null;
  const data = JSON.parse(text);
  if (data.available !== true) return null;
  if (data.schema !== 1 || data.kind !== 'debug' || data.filename !== 'JADEH-405-GLX-debug.apk'
    || typeof data.version !== 'string' || data.version.length > 40
    || typeof data.minAndroid !== 'string' || data.minAndroid.length > 10
    || !Number.isSafeInteger(data.sizeBytes) || data.sizeBytes < 100000 || data.sizeBytes > 100000000
    || typeof data.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(data.sha256)) {
    throw new Error('Invalid APK metadata.');
  }
  return data as AndroidRelease;
}

export async function downloadAndroidApk(release: AndroidRelease, signal: AbortSignal) {
  const response = await fetch(releaseUrl(release.filename), { cache: 'no-store', signal });
  if (!response.ok) throw new Error('The APK file is not published.');
  const data = new Uint8Array(await response.arrayBuffer());
  if (data.byteLength !== release.sizeBytes || data[0] !== 0x50 || data[1] !== 0x4b) throw new Error('Invalid APK download.');
  const names = new Set<string>();
  const manifest = unzipSync(data, { filter: file => {
    names.add(file.name);
    return file.name === 'AndroidManifest.xml' && file.originalSize <= 1000000;
  } })['AndroidManifest.xml'];
  if (!manifest || manifest[0] !== 3 || manifest[1] !== 0
    || !names.has('classes.dex') || !names.has('assets/game/index.html') || !names.has('resources.arsc')) {
    throw new Error('The file is not an Android game package.');
  }
  if (crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', new Uint8Array(data).buffer);
    const hash = [...new Uint8Array(digest)].map(b => b.toString(16).padStart(2, '0')).join('');
    if (hash !== release.sha256) throw new Error('APK checksum mismatch.');
  }
  if (signal.aborted) throw new DOMException('Cancelled', 'AbortError');
  saveDownload(new Blob([new Uint8Array(data).buffer], { type: 'application/vnd.android.package-archive' }), release.filename);
}