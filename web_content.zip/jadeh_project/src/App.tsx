import { useEffect, useRef, useState } from 'react';
import { DrivingEngine } from './sim/engine';
import { VEHICLES } from './sim/vehicles';
import { COCKPIT_CAMERA, DEFAULTS, EMPTY_TELEMETRY, type Controls, type Mode, type Preferences, type Telemetry, type VehicleId } from './sim/types';
import { Brand, Icon, type IconName } from './ui/Icon';
import { DrivingHud } from './ui/Hud';
import { FinishPanel, HelpPanel, PausePanel, RoutePanel, SettingsPanel } from './ui/Panels';
import { AndroidPanel } from './ui/AndroidPanel';
import { Garage } from './ui/Garage';
import { isNativeAndroid } from './platform/android';
import { saveDownload, standaloneHtml } from './platform/downloads';
import heroImage from './assets/405-highway.jpg';

const STORAGE = 'jadeh-405-preferences-v2';
const BEST = 'jadeh-405-best-v2';
const emptyControls = (): Controls => ({ gas: false, brake: false, left: false, right: false, handbrake: false, horn: false, rev: false });

function readPreferences(): Preferences {
  try {
    const p = JSON.parse(localStorage.getItem(STORAGE) || '{}');
    const vehicleId: VehicleId = p.vehicleId === 'saipa141' ? 'saipa141' : 'peugeot405';
    const spec = VEHICLES[vehicleId];
    return {
      quality: p.quality === 'low' ? 'low' : typeof p.adaptiveResolution === 'boolean' && ['medium', 'high'].includes(p.quality) ? p.quality : DEFAULTS.quality,
      time: ['day', 'golden', 'night'].includes(p.time) ? p.time : DEFAULTS.time,
      weather: p.weather === 'rain' ? 'rain' : 'clear',
      density: typeof p.density === 'number' && p.density >= 0.2 && p.density <= 1 ? p.density : DEFAULTS.density,
      volume: typeof p.volume === 'number' && p.volume >= 0 && p.volume <= 1 ? p.volume : DEFAULTS.volume,
      color: spec.colors.some(o => o.value === p.color) ? p.color : spec.colors[0].value,
      abs: typeof p.abs === 'boolean' ? p.abs : true, muted: typeof p.muted === 'boolean' ? p.muted : false,
      sportExhaust: typeof p.sportExhaust === 'boolean' ? p.sportExhaust : true,
      vehicleId,
      adaptiveResolution: typeof p.adaptiveResolution === 'boolean' ? p.adaptiveResolution : false,
      startInCockpit: typeof p.startInCockpit === 'boolean' ? p.startInCockpit : true,
    };
  } catch { return { ...DEFAULTS }; }
}

function ToolButton({ icon, title, onClick, active = false }: { icon: IconName; title: string; onClick: () => void; active?: boolean }) {
  return <button className={`icon-button ${active ? 'tool-active' : ''}`} onClick={onClick} title={title} aria-label={title}><Icon name={icon} /></button>;
}

export default function App() {
  const native = isNativeAndroid();
  const host = useRef<HTMLDivElement>(null), engine = useRef<DrivingEngine | null>(null);
  const [prefs, setPrefs] = useState<Preferences>(readPreferences);
  const [mode, setMode] = useState<Mode>('menu');
  const [garageInterior, setGarageInterior] = useState(false);
  const [modal, setModal] = useState<'settings' | 'help' | 'route' | 'android' | null>(null);
  const [ready, setReady] = useState(false), [error, setError] = useState('');
  const [telemetry, setTelemetry] = useState<Telemetry>({ ...EMPTY_TELEMETRY });
  const [active, setActive] = useState<Controls>(emptyControls);
  const [notice, setNotice] = useState<{ text: string; type: string; id: number } | null>(null);
  const [exporting, setExporting] = useState(false);
  const [best, setBest] = useState(() => { try { return Math.max(0, Number(localStorage.getItem(BEST)) || 0); } catch { return 0; } });
  const prefsRef = useRef(prefs), modeRef = useRef(mode), modalRef = useRef(modal);
  prefsRef.current = prefs; modeRef.current = mode; modalRef.current = modal;
  const pointers = useRef(new Map<number, keyof Controls>()), keys = useRef(new Set<string>());
  const resumeAfterModal = useRef(false);
  const fullscreenUntil = useRef(0);
  const drag = useRef<{ id: number; x: number } | null>(null);
  const notify = (text: string, type = 'info') => setNotice({ text, type, id: Date.now() });

  useEffect(() => {
    if (!host.current) return;
    let alive = true;
    try {
      const instance = new DrivingEngine(host.current, prefsRef.current, {
        hud: data => { if (alive) setTelemetry(data); },
        notice: (text, type) => { if (alive) setNotice({ text, type, id: Date.now() }); },
        finish: data => {
          if (!alive) return;
          setTelemetry(data); setMode('finished'); setActive(emptyControls());
          setBest(old => { const next = Math.max(old, data.score); try { localStorage.setItem(BEST, String(next)); } catch { /* Storage is optional in private browsing. */ } return next; });
        },
        error: message => { if (alive) { setError(message); setMode('paused'); } },
      });
      engine.current = instance;
      void instance.init().then(() => { if (alive) { instance.configure(prefsRef.current); setReady(true); } }).catch(() => {
        if (alive) setError('The 3D scene could not start. Try reloading in a modern Chrome browser with hardware acceleration enabled.');
      });
    } catch {
      setError('WebGL 2 is unavailable. Use a recent Chrome, Firefox, Edge, or Safari browser with hardware acceleration enabled.');
    }
    return () => { alive = false; engine.current?.dispose(); engine.current = null; };
  }, []);
  useEffect(() => {
    engine.current?.configure(prefs);
    try { localStorage.setItem(STORAGE, JSON.stringify(prefs)); } catch { /* File and private contexts can restrict storage. */ }
  }, [prefs]);
  useEffect(() => { if (!notice) return; const timer = window.setTimeout(() => setNotice(null), notice.type === 'info' ? 3400 : 1900); return () => window.clearTimeout(timer); }, [notice]);

  const syncControls = () => {
    const k = keys.current, p = [...pointers.current.values()];
    const controls: Controls = {
      gas: k.has('KeyW') || k.has('ArrowUp') || p.includes('gas'), brake: k.has('KeyS') || k.has('ArrowDown') || p.includes('brake'),
      left: k.has('KeyA') || k.has('ArrowLeft') || p.includes('left'), right: k.has('KeyD') || k.has('ArrowRight') || p.includes('right'),
      handbrake: k.has('Space') || p.includes('handbrake'), horn: k.has('KeyH') || p.includes('horn'),
      rev: k.has('KeyX') || p.includes('rev'),
    };
    if (engine.current) Object.assign(engine.current.controls, controls);
    setActive(controls);
  };
  const clearControls = () => { pointers.current.clear(); keys.current.clear(); engine.current?.clearControls(); setActive(emptyControls()); };
  const press = (id: number, control: keyof Controls) => { if (modeRef.current !== 'playing') return; pointers.current.set(id, control); syncControls(); };
  const release = (id: number) => { pointers.current.delete(id); syncControls(); };

  const fullscreen = async (quiet = false) => {
    if (native) return;
    try {
      fullscreenUntil.current = Date.now() + 1200;
      if (document.fullscreenElement) { await document.exitFullscreen(); return; }
      await document.documentElement.requestFullscreen();
      const orientation = screen.orientation as ScreenOrientation & { lock?: (type: string) => Promise<void> };
      if (matchMedia('(pointer: coarse)').matches) { try { await orientation.lock?.('landscape'); } catch { /* Respect manual rotation if locking is unavailable. */ } }
    } catch { if (!quiet) notify('Fullscreen is unavailable here. You can still drive in the browser.'); }
  };
  const beginDrive = (cockpit = prefs.startInCockpit) => {
    if (!ready || error) return;
    clearControls(); setModal(null); resumeAfterModal.current = false;
    setGarageInterior(false); setMode('playing'); void engine.current?.start(true, cockpit);
    if (!native && matchMedia('(pointer: coarse)').matches && !document.fullscreenElement) void fullscreen(true);
  };
  const startDrive = () => beginDrive();
  const pauseDrive = () => { clearControls(); engine.current?.pause(); setMode('paused'); };
  const resumeDrive = () => { if (!ready || error) return; clearControls(); setMode('playing'); void engine.current?.start(false); };
  const toMenu = () => { clearControls(); setModal(null); setGarageInterior(false); engine.current?.menu(); setMode('menu'); };
  const toGarage = () => { if (!ready || error) return; clearControls(); setGarageInterior(false); engine.current?.garage(); setMode('garage'); };
  const selectVehicle = (vehicleId: VehicleId) => { clearControls(); setPrefs(p => ({ ...p, vehicleId, color: vehicleId === p.vehicleId ? p.color : VEHICLES[vehicleId].colors[0].value })); };
  const previewInterior = (inside: boolean) => { setGarageInterior(inside); engine.current?.inspectInterior(inside); };
  const openModal = (next: 'settings' | 'help' | 'route' | 'android') => {
    resumeAfterModal.current = modeRef.current === 'playing';
    if (resumeAfterModal.current) pauseDrive();
    setModal(next);
  };
  const closeModal = () => { setModal(null); if (resumeAfterModal.current) { resumeAfterModal.current = false; resumeDrive(); } };
  const actions = useRef({ startDrive, pauseDrive, resumeDrive, fullscreen, toMenu, clearControls, closeModal });
  actions.current = { startDrive, pauseDrive, resumeDrive, fullscreen, toMenu, clearControls, closeModal };
  const inputSync = useRef(syncControls); inputSync.current = syncControls;

  useEffect(() => {
    const drivingKeys = ['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space', 'KeyH', 'KeyX'];
    const keyDown = (e: KeyboardEvent) => {
      if (modalRef.current || /INPUT|TEXTAREA|SELECT/.test((e.target as HTMLElement)?.tagName)) return;
      if (modeRef.current === 'playing' && drivingKeys.includes(e.code)) { e.preventDefault(); keys.current.add(e.code); inputSync.current(); return; }
      if (e.repeat) return;
      if (e.code === 'Enter' && ['menu', 'garage', 'finished'].includes(modeRef.current) && !/BUTTON|A/.test((e.target as HTMLElement)?.tagName)) { e.preventDefault(); actions.current.startDrive(); }
      if (e.code === 'KeyP' || e.code === 'Escape') {
        if (modeRef.current === 'playing') actions.current.pauseDrive();
        else if (modeRef.current === 'paused') actions.current.resumeDrive();
        else if (modeRef.current === 'garage') actions.current.toMenu();
      }
      if (e.code === 'KeyF') void actions.current.fullscreen();
      if (modeRef.current === 'playing' && e.code === 'KeyC') engine.current?.cycleCamera();
      if (modeRef.current === 'playing' && e.code === 'KeyV') engine.current?.toggleCockpit();
      if (modeRef.current === 'playing' && e.code === 'KeyR') actions.current.startDrive();
    };
    const keyUp = (e: KeyboardEvent) => { if (keys.current.delete(e.code)) inputSync.current(); };
    const blur = () => { actions.current.clearControls(); if (modeRef.current === 'playing' && Date.now() > fullscreenUntil.current) actions.current.pauseDrive(); };
    const visibility = () => { if (document.hidden) { actions.current.clearControls(); if (modeRef.current === 'playing') actions.current.pauseDrive(); } };
    window.addEventListener('keydown', keyDown); window.addEventListener('keyup', keyUp); window.addEventListener('blur', blur); document.addEventListener('visibilitychange', visibility);
    return () => { window.removeEventListener('keydown', keyDown); window.removeEventListener('keyup', keyUp); window.removeEventListener('blur', blur); document.removeEventListener('visibilitychange', visibility); };
  }, []);

  useEffect(() => {
    if (!native) return;
    const pauseFromAndroid = () => {
      actions.current.clearControls();
      if (modeRef.current === 'playing') actions.current.pauseDrive();
      resumeAfterModal.current = false;
    };
    const back = () => {
      if (modalRef.current) { actions.current.closeModal(); return true; }
      if (modeRef.current === 'playing') { actions.current.pauseDrive(); return true; }
      if (modeRef.current !== 'menu') { actions.current.toMenu(); return true; }
      return false;
    };
    window.__JADEH_NATIVE_BACK__ = back;
    window.addEventListener('jadeh:native-pause', pauseFromAndroid);
    return () => {
      if (window.__JADEH_NATIVE_BACK__ === back) delete window.__JADEH_NATIVE_BACK__;
      window.removeEventListener('jadeh:native-pause', pauseFromAndroid);
    };
  }, [native]);

  const downloadOffline = async () => {
    if (exporting) return; setExporting(true);
    try {
      const html = await standaloneHtml();
      saveDownload(new Blob([html], { type: 'text/html;charset=utf-8' }), 'JADEH-405-GLX.html');
      notify('Your single-file game is downloading. Open it in a browser to play offline.');
    } catch { notify('The offline game is the production file: dist/index.html. Build once, then open or download that file.'); }
    finally { setExporting(false); }
  };

  const isDriving = mode === 'playing' || mode === 'paused' || mode === 'finished';
  const vehicle = VEHICLES[prefs.vehicleId];
  const cockpitView = mode === 'garage' ? garageInterior : isDriving && telemetry.camera === COCKPIT_CAMERA;
  const timeName = prefs.time === 'golden' ? 'Golden hour' : prefs.time === 'night' ? 'Night drive' : 'Daylight';

  return <main className={`app mode-${mode} ambient-${prefs.time} ${cockpitView ? 'cockpit-view' : ''}`}>
    <div className="scene-host" ref={host} onPointerDown={e => { if (mode === 'garage') { e.currentTarget.setPointerCapture(e.pointerId); drag.current = { id: e.pointerId, x: e.clientX }; } }} onPointerMove={e => { if (drag.current?.id === e.pointerId) { engine.current?.orbit(e.clientX - drag.current.x); drag.current.x = e.clientX; } }} onPointerUp={() => { drag.current = null; }} onPointerCancel={() => { drag.current = null; }} />
    {mode === 'menu' && <div className="cinematic"><img src={heroImage} alt="White Peugeot 405 GLX on an Iranian highway beneath the Alborz mountains at golden hour" /><div className="cinematic-shade" /><div className="film-grain" /></div>}
    <div className={`screen-shade ${mode === 'garage' ? 'garage-shade' : ''}`} />

    <header className="topbar">
      <button className="brand-button" onClick={() => { if (mode === 'playing') pauseDrive(); else if (mode !== 'paused') toMenu(); }} aria-label="JADEH main menu"><Brand /></button>
      {!isDriving ? <nav className="main-nav" aria-label="Main navigation"><button className={mode === 'menu' ? 'active' : ''} onClick={toMenu}>DRIVE</button><button className={mode === 'garage' ? 'active' : ''} onClick={toGarage} disabled={!ready}>GARAGE</button><button onClick={() => openModal('help')}>HOW TO PLAY</button></nav> : <div className="live-route"><span className="live-dot" /><span>TEHRAN <span className="route-dash">/</span> KARAJ</span><small lang="fa">آزادراه تهران کرج</small></div>}
      <div className="toolbar">{mode === 'playing' && <ToolButton icon="camera" title="Change camera (C)" onClick={() => engine.current?.cycleCamera()} />}<ToolButton icon={prefs.muted ? 'muted' : 'volume'} title={prefs.muted ? 'Enable sound' : 'Mute sound'} onClick={() => setPrefs(p => ({ ...p, muted: !p.muted }))} />{!native && <ToolButton icon="fullscreen" title="Fullscreen (F)" onClick={() => void fullscreen()} />}<span className="toolbar-divider" /><ToolButton icon="settings" title="Drive settings" active={modal === 'settings'} onClick={() => openModal('settings')} />{mode === 'playing' && <ToolButton icon="pause" title="Pause drive (P)" onClick={pauseDrive} />}</div>
    </header>

    {mode === 'menu' && <>
      <section className="launch-copy"><div className="launch-eyebrow"><span /> AN IRANIAN DRIVING EXPERIENCE</div><h1>JADEH<span className="headline-dot">.</span></h1><h2>Your road. Your rules.</h2><p>An Iranian icon. An open highway.<br />Find your rhythm in the traffic.</p><button className="primary start-button" onClick={startDrive} disabled={!ready || !!error}><Icon name="play" size={24} /><span>{ready ? 'START DRIVING' : 'PREPARING YOUR DRIVE'}</span>{ready ? <kbd>ENTER</kbd> : <span className="loader" />}</button><span className="input-ready"><Icon name="keyboard" size={17} /> Keyboard & touch ready <span className="input-separator" /> No downloads. Just drive.</span></section>
      <div className="launch-bottom">
        <div className="drive-setup">
          <button className="setup-item vehicle-item" onClick={toGarage} disabled={!ready}><div className="setup-icon"><Icon name="car" size={27} /></div><div><span className="eyebrow">YOUR VEHICLE / 2 CAR GARAGE</span><h3>{vehicle.name} <span>{prefs.vehicleId === 'saipa141' ? 'SE' : 'GLX'}</span></h3><p>{prefs.vehicleId === 'saipa141' ? 'Your reference. Ready for the road.' : 'The original Iranian classic.'}</p></div><Icon name="right" size={17} /></button>
          <button className="setup-item route-item" onClick={() => openModal('route')}><div className="setup-icon"><Icon name="road" size={28} /></div><div><span className="eyebrow">ROUTE 01</span><h3>Tehran <span className="inline-arrow">/</span> Karaj</h3><p lang="fa">آزادراه تهران ـ کرج</p></div><Icon name="right" size={17} /></button>
          <button className="setup-item conditions-item" onClick={() => openModal('settings')}><div className="setup-icon amber"><Icon name={prefs.time === 'night' ? 'moon' : prefs.time === 'golden' ? 'sunset' : 'sun'} size={29} /></div><div><span className="eyebrow">DRIVE CONDITIONS</span><h3>{timeName}</h3><p>{prefs.weather === 'rain' ? 'Rainy skies' : 'Clear skies'}<span className="small-dot" />{prefs.density < 0.45 ? 'Light' : prefs.density < 0.8 ? 'Lively' : 'Dense'} traffic</p></div><Icon name="right" size={17} /></button>
        </div>
        <footer className="launch-footer">
          <span className="footer-motto"><span className="tiny-flag"><i /><i /><i /></span> BUILT FOR THE ROADS WE KNOW.</span>
          {native ? <span className="offline-button native-build-label"><Icon name="phone" size={14} /> ANDROID / OFFLINE</span> : <div className="download-options">
            <button className="offline-button" onClick={() => void downloadOffline()} disabled={exporting}><Icon name="download" size={14} />{exporting ? 'PACKAGING...' : 'PLAY OFFLINE'}<span>SINGLE HTML</span></button>
            <button className="offline-button" onClick={() => openModal('android')} aria-label="نسخه اندروید و وضعیت دانلود APK"><Icon name="phone" size={14} /> ANDROID <span>APK</span></button>
          </div>}
          <span className="edition">IRANIAN COLLECTION <span>/</span> V3.0</span>
        </footer>
      </div>
    </>}

    {mode === 'garage' && <Garage prefs={prefs} interior={garageInterior} onVehicle={selectVehicle} onPaint={color => setPrefs(p => ({ ...p, color }))} onView={previewInterior} onDrive={beginDrive} onMenu={toMenu} />}

    {mode === 'playing' && <><div className="speed-atmosphere" style={{ opacity: Math.max(0, (telemetry.speed - 105) / 200) }} /><DrivingHud data={telemetry} active={active} press={press} release={release} onCockpit={() => engine.current?.toggleCockpit()} /><div className="performance-readout">{telemetry.fps} FPS <span>/</span> {prefs.quality.toUpperCase()} <span className="render-resolution"> / {telemetry.renderWidth} x {telemetry.renderHeight}</span></div><div className="rotate-hint"><Icon name="phone" size={17} /> Rotate your phone for a wider view.</div></>}
    {mode === 'paused' && !modal && !error && <PausePanel onResume={resumeDrive} onRestart={startDrive} onFinish={() => engine.current?.end()} onMenu={toMenu} telemetry={telemetry} />}
    {mode === 'finished' && <FinishPanel telemetry={telemetry} best={best} onDrive={startDrive} onMenu={toMenu} />}
    {modal === 'settings' && <SettingsPanel prefs={prefs} setPrefs={setPrefs} onClose={closeModal} />}
    {modal === 'help' && <HelpPanel onClose={closeModal} />}
    {modal === 'route' && <RoutePanel onClose={closeModal} onDrive={startDrive} carName={`${vehicle.name} ${prefs.vehicleId === 'saipa141' ? 'SE' : 'GLX'}`} />}
    {modal === 'android' && <AndroidPanel onClose={closeModal} onOffline={() => void downloadOffline()} />}
    {notice && <div key={notice.id} role="status" className={`notice notice-${notice.type}`}>{notice.type === 'close' ? <span className="notice-kicker">CLEAN PASS. KEEP IT GOING.</span> : <Icon name={notice.type === 'hit' ? 'car' : 'info'} size={17} />}<span>{notice.text}</span></div>}
    {error && <div className="graphics-error" role="alert"><Icon name="info" size={24} /><div><strong>A quick pit stop.</strong><p>{error}</p></div><button className="secondary" onClick={() => { try { localStorage.setItem(STORAGE, JSON.stringify({ ...prefs, quality: 'low' })); } catch { /* Optional storage. */ } location.reload(); }}>RETRY WITH LOW GRAPHICS</button></div>}
  </main>;
}