# Apex Festival v1.5 — APK'ya dönüştürülmüş proje paketi

Proje Capacitor Android paketlemesine hazırlandı. APK dosyası henüz üretilmedi.
Telefon üzerinden bulutta derlemek için `app/ANDROID-APK-TELEFONDAN.md` dosyasındaki adımları uygula.
