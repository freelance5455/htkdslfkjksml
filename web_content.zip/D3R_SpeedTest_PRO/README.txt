D3R SpeedTest PRO 2.0
Funzioni: cronologia locale, grafico download, riconoscimento rete ove supportato,
test manuale, test automatico a intervalli, esportazione CSV.

Installazione:
- Carica i file su un hosting HTTPS.
- Apri index.html tramite il dominio HTTPS in Chrome Android.
- Menu Chrome > Installa app / Aggiungi a schermata Home.

Note:
- La cronologia è conservata nel browser sul dispositivo (localStorage).
- Il riconoscimento Wi-Fi/mobile dipende dal supporto del browser e del sistema:
  alcuni browser non espongono il tipo di rete.
- Il test automatico gira solo mentre la pagina/app resta aperta e attiva.
- Per le misurazioni serve Internet e accesso a speed.cloudflare.com.
- Il CSV si apre con Excel, LibreOffice o Fogli Google.
