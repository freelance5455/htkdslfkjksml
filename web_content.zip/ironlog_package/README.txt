IRONLOG — Android-ready workout tracker prototype

CONTENTS
- index.html: complete mobile-first workout tracker
- manifest.json: installable web-app manifest
- sw.js: offline cache service worker

FEATURES
- Preloaded Monday–Sunday split from the supplied routine, including Front Kick Mobility (Workout 1) and Round Kick Mobility (Workout 2)
- Edit workout names/focus and add/edit exercises
- Log sets, weight, reps and completed sets
- Automatic rest timer after checking off a set (90 seconds for strength days; mobility days use their prescribed 30/45/60/90-second intervals)
- Dead hang stopwatch, saved attempts and personal best
- Workout history, training volume, exercise strength chart, PR list, streak and calendar
- Bodyweight/waist measurements and locally stored progress photos
- JSON backup export/import

QUICK START
For a quick preview, open index.html in a modern browser. For install/offline features, serve this folder over HTTPS (or localhost), open it in Chrome on Android, then choose browser menu > Add to Home screen / Install app.

ANDROID APK NOTE
This package is a working installable web app, not a compiled APK. A signed APK requires an Android SDK/Gradle build environment and signing key. Those are not available in this build environment, so no APK is falsely represented as generated. The project can be wrapped in a native Android WebView/Capacitor shell and built in Android Studio.

DATA & PRIVACY
Training data is saved in local browser storage on the device. It is not synced to a cloud account. Export a JSON backup before clearing browser data or changing devices. Progress photos are stored locally as data URLs and can increase storage use.

WORKOUT 1 AND WORKOUT 2
Workout 1 is preloaded with Front Kick Mobility: Front Stretch Kicks, Back Stretch Kicks, Loaded Hip Flexor Lifts, Elevated Hamstring GM, Long Lunge Pulse and Front Split CRAC. Workout 2 is preloaded with Round Kick Mobility: High Chamber ISO, Outside Circle Kicks, Inside Circle Kicks, Lateral Stretch Kicks, Standing Hamstring Side Bend, Wall Ref. Horse Stance ISO, Kneeling Abducted Leg Extension and Side Split Pushups. The prescribed set counts, reps/holds and rest intervals are included in exercise names and initial set counts. All entries remain editable.
