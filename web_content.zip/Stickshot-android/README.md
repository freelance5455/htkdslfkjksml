# Stickshot (Android)

The Stickshot game wrapped as an Android app. It runs offline and has no ads.

## Get the APK (no Android Studio needed)

1. Make a free GitHub account and create a new repository (Add file > Upload files).
2. Upload everything in this folder. Check that the hidden `.github/workflows/build-apk.yml`
   file came along. If it did not, use Add file > Create new file, type
   `.github/workflows/build-apk.yml` as the name, and paste in the file contents.
3. Open the repository's **Actions** tab. The "Build APK" run starts by itself and takes
   about 3 to 5 minutes. If it does not start, pick "Build APK" and press **Run workflow**.
4. Open the finished run and download **Stickshot-APK** from Artifacts. Unzip it to get `Stickshot.apk`.

## Or build it in Android Studio

Open this folder in Android Studio, wait for the sync, then Build > Build APK(s).

## Installing on a phone

Send `Stickshot.apk` to the phone. Open it, and when Android asks, allow installs from that
app (Settings > Install unknown apps). Updates install over the old version because every
build uses the same signing key (`stickshot.jks`).

The game page is `app/src/main/assets/index.html`. The app only asks for internet access to
load the game's fonts when online.
