# Carreira de Craque v1.62.34 — Correção dos repórteres internacionais

- Corrigido o roteamento da imprensa para usar também a liga ativa e o país salvo na carreira, não apenas o nome da competição da partida.
- Sky Sports é usada em carreiras inglesas; MARCA em carreiras espanholas; GE permanece nas carreiras brasileiras.
- A identificação também considera os clubes participantes como proteção contra nomes de competição genéricos/incorretos.
- Coletivas antigas salvas com jornalistas do GE são reconstruídas automaticamente quando a emissora/jornalista não corresponde ao país da carreira.
- Cada emissora usa seu próprio grupo de jornalistas e veículos.
- Nenhuma alteração no motor de partidas, calendário, elencos ou escudos.
