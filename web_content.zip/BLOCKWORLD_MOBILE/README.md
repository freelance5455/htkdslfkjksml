# BLOCKWORLD Mobile

A touch-friendly browser prototype of an original voxel sandbox.

## Run on Android or iPhone
1. Extract this folder.
2. Put `index.html` on a web host that serves static files (or run a local web server on a computer on the same Wi-Fi).
3. Open the page in Chrome or Safari.
4. Use the on-screen arrows to move. Drag the right side to look around.

This prototype loads Three.js from jsDelivr, so an internet connection is required.
It is a browser version, not an Android APK. The original Ursina desktop project does not automatically run on Android.

## Controls
- Arrow pad: move
- Drag right side: look
- Jump: jump
- Break: break the block at the center of the screen and collect it
- Hotbar: choose dirt, stone, or wood
- Place: place the selected block
- Reset: return to starting position

## Notes
This is an early mobile prototype. It currently has a small generated world, basic touch movement, block breaking/placing, and a simple resource counter. It does not yet include persistent save files, crafting UI, multiplayer, or optimized chunk rendering.
