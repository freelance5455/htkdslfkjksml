# Lumi Owner Admin Console + EqualLearn Appearance Sync

This patch adds a separate, owner-only Lumi Admin Console. It does **not** use the EqualLearn admin role or EqualLearn admin account.

## What this adds

- `lumi-admin.html`: private owner console hosted on the separate Lumi Pages site.
- Separate Firebase Authentication identity from the `lumi-intelligence-cloud` Firebase project.
- Server-side owner allowlist using the Worker secret `LUMI_ADMIN_UID`.
- AI request dashboard: requests, input/output tokens, estimated Neurons, errors, daily chart, latest request log, CSV export.
- D1 usage log that records metadata only and automatically prunes events older than 90 days. It does not store prompts, AI answers, grades, or student records.
- Appearance Studio: preset palettes, individual colors, size, halo, sparkle and auto-outfit settings.
- A public read-only Worker appearance endpoint. EqualLearn Lumi checks that endpoint and gradually applies the latest saved look.

## Important usage note

The console shows **this EqualLearn Lumi Worker’s tracked usage**. It does not include AI requests from other Workers in the same Cloudflare account. Neurons are calculated from the model's returned token usage and Cloudflare's published GLM-4.7-Flash rates (5,500 input Neurons / million tokens and 36,400 output Neurons / million tokens). When token usage is not returned, the event is shown without a fabricated neuron count. Cloudflare's Workers AI dashboard remains the authoritative account-wide quota meter.

## A. Create a D1 database (Free plan)

1. Cloudflare Dashboard → **Workers & Pages** → **D1 SQL Database**.
2. Create a database named `lumi-admin-usage`.
3. Open its SQL Console and run all contents of `workers/lumi-worker/schema.sql`.
4. Copy the D1 database ID from its overview.
5. Open the existing `equallearn-lumi` Worker → **Settings → Bindings** → Add D1 database.
6. Binding name: `LUMI_DB`; select the `lumi-admin-usage` database; save.
7. Redeploy the Worker.

D1 has a Free plan. Current free allowance includes 5 million rows read/day, 100,000 rows written/day, and 5 GB account-wide storage; over-limit queries may be rejected rather than billed on Free. See Cloudflare's D1 pricing docs before expanding retention or usage:
https://developers.cloudflare.com/d1/platform/pricing/

## B. Update the existing Worker (do not create a second EqualLearn AI Worker)

1. Open `workers/lumi-worker/worker.js` from this patch.
2. In Cloudflare, open the existing `equallearn-lumi` Worker and replace its code with this file.
3. Preserve the existing EqualLearn variables already configured on the Worker:
   - `FIREBASE_PROJECT_ID` = your EqualLearn Firebase project ID (`equallearn-eb389`)
   - `FIREBASE_WEB_API_KEY` = your existing EqualLearn Firebase web API key
   - `WORKERS_AI_MODEL` = `@cf/zai-org/glm-4.7-flash`
   - `ALLOWED_ORIGINS` = your actual EqualLearn origin(s), plus `https://lumi-intelligence-cloud.pages.dev` (and local test origins if needed)
   - Preserve `FIREBASE_SERVICE_ACCOUNT_JSON` if your current support-ticket endpoints use it.
4. Add a Worker variable `LUMI_FIREBASE_WEB_API_KEY` with the Web API key from the `lumi-intelligence-cloud` Firebase project (the key in the Lumi Admin `firebase-config.js`).
5. Keep the `AI` Workers AI binding.
6. Add the `LUMI_DB` D1 binding described above.
7. Deploy.

Do not change the EqualLearn Firebase project variables to the Lumi Firebase project. The Worker uses two independent Firebase identities: EqualLearn users for chat role checks, and Lumi Firebase only for the private owner console.

## C. Publish the Lumi Admin site

1. Copy `lumi-admin.html` to the root of the **Lumi Personal AI Cloudflare Pages project**.
2. Copy `assets/css/lumi-admin.css` to the same Pages project's `assets/css/` folder.
3. Copy `assets/js/lumi-admin/` to `assets/js/lumi-admin/`.
4. Open `assets/js/lumi-admin/firebase-config.js` and replace `LUMI_WORKER_URL` with the exact existing URL, for example `https://equallearn-lumi.<your-subdomain>.workers.dev`.
5. Deploy the Lumi Pages site.
6. Add the final Lumi Pages domain to the Worker `ALLOWED_ORIGINS` variable. If using another custom domain, add that exact origin too.

The admin page URL will be:
`https://lumi-intelligence-cloud.pages.dev/lumi-admin.html`

## D. Create the separate Lumi owner account (not the EqualLearn admin account)

1. Open `https://lumi-intelligence-cloud.pages.dev/lumi-admin.html`.
2. Sign in using an existing account from the `lumi-intelligence-cloud` Firebase Authentication project, or use the first-time setup button to create your Lumi owner account with Email/Password. Google Sign-In is also supported.
3. The first-time setup screen shows your Firebase UID.
4. Copy it. In the `equallearn-lumi` Worker → Settings → Variables and Secrets, add a **Secret**:
   - Name: `LUMI_ADMIN_UID`
   - Value: your Lumi Firebase UID
5. Save and deploy the Worker, then refresh the Lumi Admin page.
6. Once `LUMI_ADMIN_UID` is set, the first-owner registration path is hidden. The Worker checks the Firebase ID token and exact UID on every `/admin/*` request. Other Lumi Firebase users and all EqualLearn admin accounts are denied.

Keep your Lumi account email, password, and Google login private. Do not share the owner UID secret configuration with other users.

## E. Sync Lumi appearance to EqualLearn

1. Replace the source file `assets/widgets/lumi.html` in your EqualLearn project with `equallearn/assets/widgets/lumi.html` from this patch.
2. If your deployment uses a generated `www/` folder, copy the mirror from `equallearn/www/assets/widgets/lumi.html` to the matching output path too, or rerun your normal build/copy process.
3. Keep your existing `assets/js/lumi-ai-config.js` unchanged. The updated widget uses the same `LUMI_AI_WORKER_URL` for chat and the public appearance-only sync endpoint. Do not overwrite it with a placeholder.
4. Deploy EqualLearn.
5. In Lumi Admin → Appearance Studio, choose a preset or custom colors, size, halo, sparkle and auto-outfit options. Click **Save & sync appearance**.

EqualLearn's widget reads the public, appearance-only `/appearance` endpoint at startup and every 45 seconds. The new appearance should normally reach an already-open EqualLearn page within 45 seconds; a page refresh forces an immediate first load. The endpoint contains only character styling settings, not owner data or AI usage.

## Admin API endpoints

- `GET /admin/setup-status` – tells the UI whether an owner UID has been configured; no private data.
- `GET /admin/overview` – owner-only usage aggregates and recent request metadata.
- `GET /admin/appearance` – owner-only appearance settings.
- `POST /admin/appearance` – owner-only save.
- `GET /appearance` – public read-only visual configuration for EqualLearn widget.

## Validation performed

The patch is checked for JavaScript syntax, HTML structure/IDs, CSS syntax, module paths, SQL syntax (where local SQLite is available), and ZIP integrity. Live Firebase sign-in, D1 binding, Worker deployment, and cross-site sync still require configuration in your Cloudflare/Firebase accounts.
