# Lumi Owner Admin — Login / CDN Fix

## What was happening

The browser could not download Firebase Auth modules from `www.gstatic.com` and fonts from `fonts.googleapis.com` (network timeouts). Since the Firebase imports were static, `admin.js` stopped before it could attach the login handlers. The old setup-status error handling could also mistake a Worker CORS/network error for an unconfigured owner and show the first-owner screen again.

## Changes included

- `admin.js` loads Firebase 13.4.0 modules with CDN fallback order: jsDelivr, esm.sh, then Firebase's official CDN.
- Firebase module load failures are displayed on the login screen.
- Worker fetch/CORS errors now show the exact browser origin that must be allowed.
- Setup-status network failures no longer masquerade as a missing owner UID.
- `firebase-config.js` now points to the confirmed Worker URL: `https://equallearn-lumi.jmhallig-a48.workers.dev`.
- Removed the Google Fonts network dependency and added a data-URI favicon.

## Replace files

From this package, copy/overwrite these files in your local Lumi Owner Admin project:

1. `assets/js/lumi-admin/admin.js`
2. `assets/js/lumi-admin/firebase-config.js`
3. `assets/css/lumi-admin.css`
4. `lumi-admin.html`

Do not change your Firebase project settings, `LUMI_ADMIN_UID`, D1 binding, Workers AI binding, or Worker code for this patch.

## Important: add the current local origin to Worker CORS

Your current browser address is `http://127.0.0.1:5501/lumi-admin.html`, so the origin is exactly:

`http://127.0.0.1:5501`

In Cloudflare → Workers & Pages → `equallearn-lumi` → Settings → Variables and Secrets → `ALLOWED_ORIGINS`, keep the existing origins and append both:

- `http://127.0.0.1:5501`
- `http://localhost:5501`

Origins must be comma-separated with no path. Save and deploy the Worker after editing this variable. Retain `https://lumi-intelligence-cloud.pages.dev` for the published Lumi Admin site.

## Test

1. Start Live Server at port 5501 as before.
2. Open `http://127.0.0.1:5501/lumi-admin.html`.
3. Open DevTools Console. It should report `[Lumi Admin] Firebase SDK loaded through jsDelivr.` or `esm.sh`.
4. Sign in using the separate Lumi Firebase owner account.
5. If Worker access is blocked, the login screen should now say which exact origin needs to be added to `ALLOWED_ORIGINS`.

If all three Firebase CDNs time out, this is still a network/firewall/DNS problem; the app will display that explicitly instead of silently failing.
