-- Lumi Admin usage and shared appearance settings.
-- Run this SQL once in the Cloudflare D1 console for the lumi-admin-usage database.

CREATE TABLE IF NOT EXISTS usage_events (
  id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  date_utc TEXT NOT NULL,
  app TEXT NOT NULL DEFAULT 'EqualLearn',
  user_role TEXT NOT NULL DEFAULT 'unknown',
  model TEXT NOT NULL,
  input_tokens INTEGER,
  output_tokens INTEGER,
  total_tokens INTEGER,
  estimated_neurons INTEGER,
  usage_basis TEXT NOT NULL DEFAULT 'unavailable',
  status TEXT NOT NULL,
  latency_ms INTEGER NOT NULL DEFAULT 0,
  error_code TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_lumi_usage_date ON usage_events(date_utc);
CREATE INDEX IF NOT EXISTS idx_lumi_usage_created ON usage_events(created_at);
CREATE INDEX IF NOT EXISTS idx_lumi_usage_role_date ON usage_events(user_role, date_utc);

CREATE TABLE IF NOT EXISTS lumi_settings (
  setting_key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

INSERT OR IGNORE INTO lumi_settings(setting_key, value_json, updated_at)
VALUES (
  'appearance',
  '{"preset":"Violet Dream","colors":{"shell":"#f2ecff","shellShade":"#c8b5ff","purple":"#8059df","purpleDark":"#432b91","cyan":"#7dd5ff","gold":"#f5d9a4","rocketShell":"#7652cf"},"scale":1,"showHalo":true,"showSparkles":true,"autoOutfit":false}',
  datetime('now')
);
