// This is the independent Lumi Firebase project, not EqualLearn's Firebase project.
export const LUMI_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBegreau9zNXHldHyMMEcYmKriGnDgAWJI",
  authDomain: "lumi-intelligence-cloud.firebaseapp.com",
  projectId: "lumi-intelligence-cloud",
  storageBucket: "lumi-intelligence-cloud.firebasestorage.app",
  messagingSenderId: "807758026564",
  appId: "1:807758026564:web:0626400b5699afca84e911"
};
export const LUMI_WORKER_URL = "https://equallearn-lumi.jmhallig-a48.workers.dev";
