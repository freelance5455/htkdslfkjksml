import { LUMI_FIREBASE_CONFIG, LUMI_WORKER_URL } from "./firebase-config.js";
import { initAppearancePreview, updateAppearancePreview } from "./preview.js";

const $ = id => document.getElementById(id);

// Google-hosted Firebase CDN requests timed out in the owner's browser.
// Try independent CDNs first, then fall back to Firebase's official CDN.
async function importWithTimeout(url, timeoutMs = 14000) {
  let timer;
  try {
    return await Promise.race([
      import(url),
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(`CDN timeout: ${new URL(url).host}`)), timeoutMs);
      })
    ]);
  } finally {
    clearTimeout(timer);
  }
}

async function loadFirebaseSdk() {
  const providers = [
    {
      name: "jsDelivr",
      app: "https://cdn.jsdelivr.net/npm/firebase@13.4.0/app/+esm",
      auth: "https://cdn.jsdelivr.net/npm/firebase@13.4.0/auth/+esm"
    },
    {
      name: "esm.sh",
      app: "https://esm.sh/firebase@13.4.0/app",
      auth: "https://esm.sh/firebase@13.4.0/auth"
    },
    {
      name: "Firebase official CDN",
      app: "https://www.gstatic.com/firebasejs/13.4.0/firebase-app.js",
      auth: "https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js"
    }
  ];
  const failures = [];
  for (const provider of providers) {
    try {
      const [appSdk, authSdk] = await Promise.all([
        importWithTimeout(provider.app),
        importWithTimeout(provider.auth)
      ]);
      const required = [
        [appSdk, "initializeApp"], [authSdk, "getAuth"],
        [authSdk, "onAuthStateChanged"], [authSdk, "signInWithEmailAndPassword"],
        [authSdk, "GoogleAuthProvider"]
      ];
      const missing = required.find(([module, name]) => typeof module[name] !== "function");
      if (missing) throw new Error(`Firebase SDK export missing: ${missing[1]}`);
      console.info(`[Lumi Admin] Firebase SDK loaded through ${provider.name}.`);
      return { ...appSdk, ...authSdk };
    } catch (error) {
      failures.push(`${provider.name}: ${error?.message || error}`);
      console.warn(`[Lumi Admin] ${provider.name} failed; trying next CDN.`, error);
    }
  }
  const message = "Hindi ma-load ang Firebase SDK. Na-timeout ang Google CDN at hindi rin maabot ang backup CDNs. Check internet/firewall, then refresh. Details: " + failures.join(" | ");
  const node = document.getElementById("authMessage");
  if (node) node.textContent = message;
  throw new Error(message);
}

const firebaseSdk = await loadFirebaseSdk();
const {
  initializeApp,
  getAuth, onAuthStateChanged, setPersistence, browserLocalPersistence,
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  GoogleAuthProvider, signInWithPopup, signOut
} = firebaseSdk;

const app = initializeApp(LUMI_FIREBASE_CONFIG, "lumi-owner-console");
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
await setPersistence(auth, browserLocalPersistence);
let currentUser = null;
let setupStatus = { ownerConfigured: false, d1Configured: false };
let latestOverview = null;
let currentAppearance = null;
let refreshTimer = null;
let updateCheckBusy = false;
let overviewRefreshBusy = false;
let latestUsageVersion = null;
let currentBehaviorSettings = {
  tone: "warm", language: "adaptive", responseLength: "balanced",
  customInstructions: "", knowledgeBase: [], history: [], updatedAt: null
};
let testConversation = [];

const DEFAULT_APPEARANCE = {
  preset: "Violet Dream",
  characterType: "humanoid",
  colors: { shell:"#f2ecff", shellShade:"#c8b5ff", purple:"#8059df", purpleDark:"#432b91", cyan:"#7dd5ff", gold:"#f5d9a4", rocketShell:"#7652cf" },
  scale: 1, showHalo: true, showSparkles: true, autoOutfit: false
};
const PRESETS = {
  "Violet Dream": {shell:"#f2ecff",shellShade:"#c8b5ff",purple:"#8059df",purpleDark:"#432b91",cyan:"#7dd5ff",gold:"#f5d9a4",rocketShell:"#7652cf"},
  "Rose Bloom": {shell:"#fff0f6",shellShade:"#ffc4dc",purple:"#ed79b5",purpleDark:"#8e3b78",cyan:"#91dcff",gold:"#ffd36f",rocketShell:"#d85d9b"},
  "Ocean Glow": {shell:"#eafaff",shellShade:"#a9e5f3",purple:"#42a6c7",purpleDark:"#245b82",cyan:"#70e6ff",gold:"#c4f1e5",rocketShell:"#328ebd"},
  "Mint Breeze": {shell:"#effff7",shellShade:"#b8ecd8",purple:"#58b997",purpleDark:"#276b58",cyan:"#8fe9d0",gold:"#f3d984",rocketShell:"#389878"},
  "Sunny Star": {shell:"#fffff0",shellShade:"#ffe7a1",purple:"#f2b94b",purpleDark:"#9a6721",cyan:"#8cdaff",gold:"#ffe18b",rocketShell:"#e39a24"}
};
const COLOR_INPUTS = {
  colorShell:"shell", colorShellShade:"shellShade", colorPurple:"purple",
  colorPurpleDark:"purpleDark", colorCyan:"cyan", colorGold:"gold", colorRocket:"rocketShell"
};
function apiUrl(path) {
  const base = String(LUMI_WORKER_URL || "").replace(/\/$/, "");
  if (!/^https:\/\//i.test(base) || base.includes("REPLACE-WITH-YOUR")) throw new Error("Set the correct LUMI_WORKER_URL in assets/js/lumi-admin/firebase-config.js first.");
  return `${base}${path}`;
}
async function getToken() {
  if (!currentUser) throw new Error("Please sign in with your separate Lumi account.");
  return currentUser.getIdToken();
}
async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (options.auth !== false) headers.Authorization = `Bearer ${await getToken()}`;
  let response;
  try {
    response = await fetch(apiUrl(path), { ...options, headers });
  } catch (cause) {
    const origin = window.location.origin;
    const error = new Error(`Cannot reach Lumi Worker from ${origin}. Check that ALLOWED_ORIGINS includes this exact origin, and verify your internet connection. (${cause?.message || "Network/CORS error"})`);
    error.cause = cause;
    throw error;
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Lumi Worker returned ${response.status}.`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
function setAuthMessage(message, isError = true) {
  $("authMessage").textContent = message;
  $("authMessage").style.color = isError ? "#ff9aa7" : "#8ee1bb";
}
function show(view) {
  ["authView", "setupView", "adminApp"].forEach(id => $(id).classList.toggle("hidden", id !== view));
}
async function checkSetupStatus() {
  // A failed request is a connection/CORS error, not proof that no owner exists.
  // Do not show the one-time owner registration screen on a network failure.
  setupStatus = await api("/admin/setup-status", { auth: false });
  $("firstOwnerBox").classList.toggle("hidden", setupStatus.ownerConfigured);
  return setupStatus;
}
function showOwnerSetup(uid) {
  $("ownerUid").textContent = uid;
  show("setupView");
}
async function initializeSignedInUser(user) {
  currentUser = user;
  try {
    await checkSetupStatus();
    if (!setupStatus.ownerConfigured) {
      showOwnerSetup(user.uid);
      return;
    }
    // The Worker is the authority. Never trust a browser-side email or role for admin access.
    await api("/admin/overview");
    $("ownerEmail").textContent = user.email || "Lumi owner";
    $("securityEmail").textContent = user.email || "—";
    $("securityUid").textContent = user.uid;
    $("footerYear").textContent = new Date().getFullYear();
    show("adminApp");
    await initAppearancePreview();
    await refreshWithAppearance();
    try { await loadLumiBrain(); } catch (error) { console.warn("Lumi Brain settings could not be loaded", error); }
    try { await runSystemDiagnostics({ silent: true }); } catch (error) { console.warn("Initial Lumi diagnostics failed", error); }
    startLiveUsageUpdates();
  } catch (error) {
    show("authView");
    setAuthMessage(error.message || "This account is not allowed to access Lumi Admin.");
    if (error.status === 403) {
      setAuthMessage("Access denied. Only the Firebase UID configured as LUMI_ADMIN_UID can use this console.");
    }
  }
}

$("loginForm").addEventListener("submit", async event => {
  event.preventDefault(); setAuthMessage("");
  try {
    await signInWithEmailAndPassword(auth, $("emailInput").value.trim(), $("passwordInput").value);
  } catch (error) { setAuthMessage(error.message); }
});
$("googleSignIn").addEventListener("click", async () => {
  setAuthMessage("");
  try { await signInWithPopup(auth, googleProvider); }
  catch (error) { setAuthMessage(error.message); }
});
$("createOwnerAccount").addEventListener("click", async () => {
  setAuthMessage("");
  const email = $("emailInput").value.trim();
  const password = $("passwordInput").value;
  if (!email || password.length < 6) return setAuthMessage("Enter your email and a password with at least 6 characters.");
  try { await createUserWithEmailAndPassword(auth, email, password); }
  catch (error) { setAuthMessage(error.message); }
});
$("copyOwnerUid").addEventListener("click", async () => {
  await navigator.clipboard.writeText($("ownerUid").textContent);
  $("copyOwnerUid").textContent = "Copied!";
});
$("setupSignOut").addEventListener("click", () => signOut(auth));
$("signOutButton").addEventListener("click", () => signOut(auth));
onAuthStateChanged(auth, async user => {
  currentUser = user;
  clearInterval(refreshTimer);
  if (!user) {
    try { await checkSetupStatus(); }
    catch (error) { setAuthMessage(error.message || "Cannot connect to Lumi Worker."); }
    show("authView");
    return;
  }
  await initializeSignedInUser(user);
});

// ---------- Navigation ----------
function navigate(page) {
  document.querySelectorAll(".page-section").forEach(section => section.classList.toggle("hidden", section.id !== `page-${page}`));
  document.querySelectorAll(".side-link[data-page]").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  const labels = { overview:"Overview", consumption:"AI Consumption", "ai-engine":"AI Engine", appearance:"Appearance Studio", brain:"Lumi Brain", "test-lab":"Test Lab", health:"System Health", security:"Access & Security" };
  $("breadcrumbPage").textContent = labels[page] || "Overview";
}
document.querySelectorAll(".side-link[data-page]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.goto)));

function formatNumber(value) { return Number(value || 0).toLocaleString("en-US"); }
function formatTime(iso) { if (!iso) return "—"; return new Date(iso).toLocaleString([], { hour:"2-digit", minute:"2-digit", month:"short", day:"numeric", timeZone:"UTC" }) + " UTC"; }
function showNotice(message, isError = false) {
  const node = $("globalNotice"); node.textContent = message; node.classList.remove("hidden", "error", "success"); node.classList.add(isError ? "error" : "success");
}
function hideNotice() { $("globalNotice").classList.add("hidden"); }
function renderChart(container, daily) {
  const node = $(container); node.replaceChildren();
  const dateMap = new Map((daily || []).map(row => [row.date_utc, row]));
  const days = [];
  for (let i = 6; i >= 0; i--) { const date = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10); days.push({ date, ...(dateMap.get(date) || {}) }); }
  const max = Math.max(100, ...days.map(row => Number(row.neurons || 0)));
  if (!days.some(row => Number(row.requests || 0))) {
    const empty = document.createElement("div"); empty.className = "chart-empty"; empty.textContent = "Usage data will appear after Lumi completes AI requests."; node.append(empty); return;
  }
  for (const row of days) {
    const column = document.createElement("div"); column.className = "chart-column";
    const amount = Number(row.neurons || 0);
    const count = document.createElement("b"); count.textContent = amount ? formatNumber(amount) : "0";
    const track = document.createElement("div"); track.className = "chart-track";
    const bar = document.createElement("i"); bar.className = "chart-bar"; bar.style.height = `${Math.max(amount ? 3 : 0, amount / max * 100)}%`; track.append(bar);
    const label = document.createElement("small"); label.textContent = new Date(`${row.date}T00:00:00Z`).toLocaleDateString([], { weekday:"short", timeZone:"UTC" });
    column.append(count, track, label); node.append(column);
  }
}
function appendRecent(targetId, records) {
  const target = $(targetId); target.replaceChildren();
  if (!records?.length) { const empty = document.createElement("div"); empty.className = "loading-row"; empty.textContent = "No AI requests have been recorded yet."; target.append(empty); return; }
  for (const record of records.slice(0, targetId === "recentOverview" ? 5 : records.length)) {
    const item = document.createElement("div"); item.className = "recent-item";
    const icon = document.createElement("div"); icon.className = "recent-icon"; icon.textContent = record.status === "success" ? "✦" : "!";
    const main = document.createElement("div"); main.className = "recent-main";
    const heading = document.createElement("b"); heading.textContent = `${record.app || "EqualLearn"} · ${record.user_role || "unknown"}`;
    const sub = document.createElement("small"); sub.textContent = `${formatTime(record.created_at)} · ${record.model || "Workers AI"}`;
    main.append(heading, sub);
    const stats = document.createElement("span"); stats.className = "recent-stat"; stats.textContent = record.estimated_neurons == null ? "— neurons" : `${formatNumber(record.estimated_neurons)} N`;
    const status = document.createElement("span"); status.className = `status-tag ${record.status === "success" ? "success" : "error"}`; status.textContent = record.status === "success" ? "Success" : "Error";
    item.append(icon, main, stats, status); target.append(item);
  }
}
function renderRoleBreakdown(rows) {
  const target = $("roleBreakdown"); target.replaceChildren();
  if (!rows?.length) { const empty = document.createElement("div"); empty.className = "loading-row"; empty.textContent = "No role-level usage recorded today."; target.append(empty); return; }
  const total = Math.max(1, rows.reduce((sum, row) => sum + Number(row.requests || 0), 0));
  for (const row of rows) {
    const item = document.createElement("div"); item.className = "role-usage-row";
    const head = document.createElement("div"); head.className = "role-usage-head";
    const name = document.createElement("b"); name.textContent = String(row.user_role || "unknown").replace(/^./, c => c.toUpperCase());
    const value = document.createElement("span"); value.textContent = `${formatNumber(row.requests)} requests · ${formatNumber(row.neurons)} estimated N`;
    head.append(name, value);
    const track = document.createElement("div"); track.className = "role-usage-track";
    const fill = document.createElement("i"); fill.style.width = `${Math.min(100, Number(row.requests || 0) / total * 100)}%`; track.append(fill);
    item.append(head, track); target.append(item);
  }
}
function renderTable(records) {
  const tbody = $("usageTable"); tbody.replaceChildren();
  const filter = $("logFilter").value;
  const visible = (records || []).filter(row => filter === "all" || (filter === "success" ? row.status === "success" : row.status !== "success"));
  if (!visible.length) { const tr = document.createElement("tr"), td = document.createElement("td"); td.colSpan = 7; td.className = "table-empty"; td.textContent = "No matching requests."; tr.append(td); tbody.append(tr); return; }
  for (const row of visible) {
    const tr = document.createElement("tr");
    const values = [formatTime(row.created_at), `${row.app || "EqualLearn"} / ${row.user_role || "unknown"}`, row.model || "—", `${formatNumber(row.input_tokens)} / ${formatNumber(row.output_tokens)}`, row.estimated_neurons == null ? "Not reported" : formatNumber(row.estimated_neurons), row.status === "success" ? "Success" : `Error${row.error_code ? ` · ${row.error_code}` : ""}`, row.latency_ms ? `${formatNumber(row.latency_ms)} ms` : "—"];
    values.forEach((value, index) => { const td = document.createElement("td"); td.textContent = value; if (index === 5) { const tag = document.createElement("span"); tag.className = `status-tag ${row.status === "success" ? "success" : "error"}`; tag.textContent = value; td.replaceChildren(tag); } tr.append(td); });
    tbody.append(tr);
  }
}
function usageVersion(record) {
  return record ? `${record.created_at || ""}:${record.id || ""}` : "empty";
}
function updateLiveIndicator(state = "live", message = "Live sync · checking every 10s") {
  const indicator = $("liveSyncIndicator");
  if (!indicator) return;
  indicator.classList.toggle("checking", state === "checking");
  indicator.classList.toggle("warning", state === "warning");
  const text = $("lastUpdated");
  if (text) text.textContent = message;
}
function markDashboardUpdated() {
  const now = new Date();
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  updateLiveIndicator("live", `Live · data updated ${time}`);
}
function markLiveCheck() {
  const now = new Date();
  const time = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  updateLiveIndicator("live", `Live · checked ${time}`);
}
async function refreshAll({ showMessage = false } = {}) {
  if (overviewRefreshBusy) return latestOverview;
  overviewRefreshBusy = true;
  updateLiveIndicator("checking", "Refreshing usage data…");
  try {
    hideNotice();
    const data = await api("/admin/overview"); latestOverview = data;
    latestUsageVersion = usageVersion(data.recent?.[0]);
    const today = data.today || {};
    $("todayNeurons").textContent = formatNumber(today.estimatedNeurons);
    $("remainingNeurons").textContent = today.trackedRemaining == null
      ? `Unavailable · ${formatNumber(today.untrackedRequests)} untracked request(s)`
      : formatNumber(today.trackedRemaining);
    $("neuronMeter").style.width = `${Math.min(100, Number(today.estimatedNeurons || 0) / 10000 * 100)}%`;
    $("todayRequests").textContent = formatNumber(today.requests);
    $("requestSub").textContent = `${formatNumber(today.successful)} successful · ${formatNumber(today.failed)} failed`;
    $("todayTokens").textContent = formatNumber(today.totalTokens);
    $("tokenSub").textContent = `${formatNumber(today.inputTokens)} input · ${formatNumber(today.outputTokens)} output`;
    const rate = today.requests ? Math.round(today.successful / today.requests * 100) : 0;
    $("successRate").textContent = today.requests ? `${rate}%` : "—";
    $("successSub").textContent = today.requests ? `${formatNumber(today.successful)} of ${formatNumber(today.requests)} requests succeeded` : "No requests recorded today";
    $("inputTokens").textContent = formatNumber(today.inputTokens);
    $("outputTokens").textContent = formatNumber(today.outputTokens);
    $("successCalls").textContent = formatNumber(today.successful);
    $("failedCalls").textContent = formatNumber(today.failed);
    $("activeModel").textContent = data.model || "—";
    $("bindingStatus").textContent = "Connected";
    $("dbStatus").textContent = data.d1Configured ? "Connected" : "Not configured";
    $("resetTime").textContent = data.resetAtUtc ? `${new Date(data.resetAtUtc).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit",timeZone:"Asia/Manila"})} Manila` : "00:00 UTC";
    $("chartTotal").textContent = `${formatNumber((data.daily || []).reduce((sum, row) => sum + Number(row.neurons || 0), 0))} this week`;
    renderChart("usageChart", data.daily); renderChart("usageChartLarge", data.daily);
    renderRoleBreakdown(data.byRole || []);
    appendRecent("recentOverview", data.recent || []); renderTable(data.recent || []);
    const date = new Date(); $("currentDate").textContent = date.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"});
    markDashboardUpdated();
    if (showMessage) showNotice("Usage dashboard refreshed. This is a Worker-only estimate, not the account-wide remaining quota. Check Cloudflare AI for the authoritative account total.");
    return data;
  } finally {
    overviewRefreshBusy = false;
  }
}
$("logFilter").addEventListener("change", () => renderTable(latestOverview?.recent || []));
$("exportCsv").addEventListener("click", () => {
  const rows = latestOverview?.recent || [];
  const columns = ["created_at","app","user_role","model","input_tokens","output_tokens","total_tokens","estimated_neurons","usage_basis","status","latency_ms","error_code"];
  const csv = [columns.join(","), ...rows.map(row => columns.map(key => `"${String(row[key] ?? "").replaceAll('"','""')}"`).join(","))].join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type:"text/csv;charset=utf-8" }));
  const link = document.createElement("a"); link.href = url; link.download = `lumi-ai-usage-${new Date().toISOString().slice(0,10)}.csv`; link.click(); URL.revokeObjectURL(url);
});

// ---------- Appearance Studio ----------
function collectAppearance() {
  const colors = {};
  for (const [id, key] of Object.entries(COLOR_INPUTS)) colors[key] = $(id).value;
  return { preset: document.querySelector(".preset-card.active")?.dataset.preset || "Custom", characterType: document.querySelector(".character-card.active")?.dataset.character || "humanoid", colors, scale: Number($("scaleRange").value), showHalo: $("showHalo").checked, showSparkles: $("showSparkles").checked, autoOutfit: $("autoOutfit").checked };
}
function setAppearanceControls(settings) {
  currentAppearance = structuredClone(settings || DEFAULT_APPEARANCE);
  for (const [id, key] of Object.entries(COLOR_INPUTS)) $(id).value = currentAppearance.colors[key] || DEFAULT_APPEARANCE.colors[key];
  currentAppearance.characterType = ["humanoid","orb","puppy","cube","bird","rover","cat","drone"].includes(currentAppearance.characterType) ? currentAppearance.characterType : "humanoid";
  document.querySelectorAll(".character-card").forEach(card => card.classList.toggle("active", card.dataset.character === currentAppearance.characterType));
  $("scaleRange").value = currentAppearance.scale ?? 1;
  $("scaleValue").textContent = `${Math.round(Number($("scaleRange").value) * 100)}%`;
  $("showHalo").checked = currentAppearance.showHalo !== false;
  $("showSparkles").checked = currentAppearance.showSparkles !== false;
  $("autoOutfit").checked = currentAppearance.autoOutfit === true;
  document.querySelectorAll(".preset-card").forEach(card => card.classList.toggle("active", card.dataset.preset === currentAppearance.preset));
  updateAppearancePreview(currentAppearance);
  $("previewName").textContent = currentAppearance.preset;
}
function applyPreset(name) {
  const colors = PRESETS[name];
  if (!colors && name !== "Custom") return;
  const settings = collectAppearance();
  settings.preset = name;
  if (colors) settings.colors = { ...colors };
  setAppearanceControls(settings);
}
document.querySelectorAll(".preset-card").forEach(card => card.addEventListener("click", () => applyPreset(card.dataset.preset)));
document.querySelectorAll(".character-card").forEach(card => card.addEventListener("click", () => {
  const settings = collectAppearance(); settings.characterType = card.dataset.character;
  setAppearanceControls(settings);
  $("previewName").textContent = `${card.querySelector("b")?.textContent || card.dataset.character} · ${settings.preset}`;
}));
Object.keys(COLOR_INPUTS).forEach(id => $(id).addEventListener("input", () => {
  const settings = collectAppearance(); settings.preset = "Custom";
  document.querySelectorAll(".preset-card").forEach(card => card.classList.toggle("active", card.dataset.preset === "Custom"));
  updateAppearancePreview(settings); $("previewName").textContent = "Custom appearance";
}));
["scaleRange","showHalo","showSparkles","autoOutfit"].forEach(id => $(id).addEventListener("input", () => {
  const settings = collectAppearance(); updateAppearancePreview(settings); $("scaleValue").textContent = `${Math.round(settings.scale * 100)}%`;
}));
async function loadAppearance() {
  const data = await api("/admin/appearance");
  setAppearanceControls(data.appearance || DEFAULT_APPEARANCE);
}
$("resetAppearance").addEventListener("click", () => setAppearanceControls(DEFAULT_APPEARANCE));
$("saveAppearance").addEventListener("click", async () => {
  const button = $("saveAppearance"); const status = $("appearanceStatus");
  button.disabled = true; button.textContent = "Saving…"; status.textContent = "";
  try {
    const settings = collectAppearance();
    const data = await api("/admin/appearance", { method:"POST", body:JSON.stringify({ appearance:settings }) });
    setAppearanceControls(data.appearance);
    status.textContent = "Saved! EqualLearn Lumi will pick up the new look on its next appearance sync.";
  } catch (error) { status.textContent = error.message; status.style.color = "#ff9aa7"; }
  finally { button.disabled = false; button.innerHTML = 'Save & sync appearance <span>→</span>'; }
});
let currentAiSettings = { enabled:true, autoPauseOnQuota:true, pausedUntilUtc:null, effectiveEnabled:true, state:"enabled" };
function updateAiSettingsUI(settings) {
  currentAiSettings = { ...currentAiSettings, ...(settings || {}) };
  const enabled = currentAiSettings.effectiveEnabled !== false;
  const toggle = $("aiEngineToggle");
  const autoPause = $("autoPauseOnQuotaToggle");
  if (toggle) toggle.checked = currentAiSettings.enabled !== false;
  if (autoPause) autoPause.checked = currentAiSettings.autoPauseOnQuota !== false;
  const badge = $("aiEngineStateBadge"), pageBadge = $("aiEnginePageBadge"), status = $("aiEngineStatusText");
  const quotaPaused = currentAiSettings.state === "quota_paused";
  const manualOff = currentAiSettings.enabled === false;
  const label = quotaPaused ? "Paused · free quota" : manualOff ? "AI is OFF" : "AI is ON";
  [badge,pageBadge].forEach(node => { if (!node) return; node.textContent = label; node.classList.toggle("off", !enabled); node.classList.toggle("on", enabled); });
  if (status) status.textContent = quotaPaused
    ? `Free allocation reached. Lumi will resume automatically at ${currentAiSettings.pausedUntilUtc ? new Date(currentAiSettings.pausedUntilUtc).toLocaleString() : "the next UTC reset"}.`
    : manualOff ? "AI inference is disabled by the owner. Built-in EqualLearn help and all 3D interactions remain available."
    : "AI is enabled. New eligible questions can use the configured Cloudflare Workers AI model.";
  const until = $("aiPauseUntil"); if (until) until.textContent = currentAiSettings.pausedUntilUtc && quotaPaused ? new Date(currentAiSettings.pausedUntilUtc).toLocaleString() : "Not paused";
  const title = $("aiEngineToggleTitle"); if (title) title.textContent = quotaPaused ? "Temporarily paused until daily reset" : manualOff ? "Enable Lumi AI" : "Lumi AI is enabled";
}
async function loadAiSettings() {
  const data = await api("/admin/ai-settings");
  updateAiSettingsUI(data.settings || {});
  return data.settings;
}
async function saveAiSettings(partial) {
  const data = await api("/admin/ai-settings", { method:"POST", body:JSON.stringify(partial) });
  updateAiSettingsUI(data.settings || {});
  return data.settings;
}
$("aiEngineToggle")?.addEventListener("change", async () => {
  const toggle = $("aiEngineToggle"); toggle.disabled = true;
  try {
    const saved = await saveAiSettings({ enabled:toggle.checked, autoPauseOnQuota:$("autoPauseOnQuotaToggle").checked });
    showNotice(saved.effectiveEnabled ? "Lumi AI is enabled. Workers AI requests are allowed." : "Lumi AI is now turned off. No new model inference calls will be made.");
  } catch (error) { toggle.checked = currentAiSettings.enabled !== false; showNotice(error.message, true); }
  finally { toggle.disabled = false; }
});
$("autoPauseOnQuotaToggle")?.addEventListener("change", async () => {
  const toggle = $("autoPauseOnQuotaToggle"); toggle.disabled = true;
  try { await saveAiSettings({ enabled:$("aiEngineToggle").checked, autoPauseOnQuota:toggle.checked }); showNotice(toggle.checked ? "Automatic daily-quota pause is enabled." : "Automatic daily-quota pause is disabled."); }
  catch (error) { toggle.checked = currentAiSettings.autoPauseOnQuota !== false; showNotice(error.message, true); }
  finally { toggle.disabled = false; }
});

// ---------- Lumi Brain: behavior and knowledge management ----------
const DEFAULT_BRAIN_SETTINGS = {
  tone: "warm", language: "adaptive", responseLength: "balanced",
  customInstructions: "", knowledgeBase: []
};
function brainNotice(message, isError = false) {
  const node = $("brainNotice");
  node.textContent = message;
  node.classList.remove("hidden", "error", "success");
  node.classList.add(isError ? "error" : "success");
}
function updateInstructionCount() {
  const value = $("behaviorInstructions").value || "";
  $("instructionCount").textContent = `${value.length} / 1800`;
}
function renderKnowledgeCards() {
  const list = $("knowledgeList");
  const entries = currentBehaviorSettings.knowledgeBase || [];
  $("knowledgeCount").textContent = `${entries.length} / 25`;
  list.replaceChildren();
  if (!entries.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No knowledge cards yet. Add verified facts or EqualLearn instructions above.";
    list.append(empty);
    return;
  }
  for (const entry of entries) {
    const card = document.createElement("article");
    card.className = `knowledge-card${entry.enabled === false ? " is-disabled" : ""}`;
    const copy = document.createElement("div");
    copy.className = "knowledge-card-copy";
    const title = document.createElement("b");
    title.textContent = entry.title;
    const content = document.createElement("p");
    content.textContent = entry.content;
    const tags = document.createElement("small");
    tags.textContent = (entry.keywords || []).join(" · ") || "No keywords";
    copy.append(title, content, tags);
    const actions = document.createElement("div");
    actions.className = "knowledge-card-actions";
    const status = document.createElement("span");
    status.className = `knowledge-state ${entry.enabled === false ? "off" : "on"}`;
    status.textContent = entry.enabled === false ? "Disabled" : "Enabled";
    const edit = document.createElement("button");
    edit.type = "button"; edit.className = "text-btn"; edit.textContent = "Edit";
    edit.dataset.knowledgeAction = "edit"; edit.dataset.knowledgeId = entry.id;
    const toggle = document.createElement("button");
    toggle.type = "button"; toggle.className = "text-btn"; toggle.textContent = entry.enabled === false ? "Enable" : "Disable";
    toggle.dataset.knowledgeAction = "toggle"; toggle.dataset.knowledgeId = entry.id;
    const remove = document.createElement("button");
    remove.type = "button"; remove.className = "text-btn danger-text"; remove.textContent = "Remove";
    remove.dataset.knowledgeAction = "remove"; remove.dataset.knowledgeId = entry.id;
    actions.append(status, edit, toggle, remove);
    card.append(copy, actions);
    list.append(card);
  }
}
function renderBrainHistory(history = []) {
  const list = $("brainHistory");
  list.replaceChildren();
  if (!history.length) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.textContent = "No previous saved versions yet. Each save will preserve the previous configuration here.";
    list.append(empty);
    return;
  }
  history.forEach(item => {
    const row = document.createElement("div");
    row.className = "brain-history-row";
    const meta = document.createElement("div");
    const title = document.createElement("b");
    title.textContent = item.label || "Previous configuration";
    const date = document.createElement("small");
    date.textContent = item.savedAt ? new Date(item.savedAt).toLocaleString() : "Previous version";
    meta.append(title, date);
    const restore = document.createElement("button");
    restore.type = "button"; restore.className = "secondary-btn";
    restore.textContent = "Restore version";
    restore.dataset.restoreBrain = item.id;
    row.append(meta, restore);
    list.append(row);
  });
}
function applyBrainSettings(settings = {}) {
  currentBehaviorSettings = {
    ...DEFAULT_BRAIN_SETTINGS,
    ...(settings || {}),
    knowledgeBase: Array.isArray(settings.knowledgeBase) ? settings.knowledgeBase : [],
    history: Array.isArray(settings.history) ? settings.history : []
  };
  $("behaviorTone").value = currentBehaviorSettings.tone || "warm";
  $("behaviorLanguage").value = currentBehaviorSettings.language || "adaptive";
  $("behaviorLength").value = currentBehaviorSettings.responseLength || "balanced";
  $("behaviorInstructions").value = currentBehaviorSettings.customInstructions || "";
  updateInstructionCount();
  renderKnowledgeCards();
  renderBrainHistory(currentBehaviorSettings.history);
  const saved = $("brainSaveStatus");
  saved.textContent = currentBehaviorSettings.updatedAt
    ? `Last saved ${new Date(currentBehaviorSettings.updatedAt).toLocaleString()}.`
    : "Using default Lumi behavior. Save to create your first version.";
}
async function loadLumiBrain() {
  const data = await api("/admin/behavior");
  applyBrainSettings({ ...(data.settings || DEFAULT_BRAIN_SETTINGS), history: data.history || [], updatedAt: data.updatedAt || null });
  return data;
}
function collectBrainSettings() {
  return {
    tone: $("behaviorTone").value,
    language: $("behaviorLanguage").value,
    responseLength: $("behaviorLength").value,
    customInstructions: $("behaviorInstructions").value.trim().slice(0, 1800),
    knowledgeBase: currentBehaviorSettings.knowledgeBase || []
  };
}
async function saveLumiBrain(settings = collectBrainSettings(), { restored = false } = {}) {
  const button = $("saveBrain");
  button.disabled = true;
  button.textContent = "Saving…";
  $("brainSaveStatus").textContent = "Saving behavior and knowledge to the Lumi Worker…";
  try {
    const data = await api("/admin/behavior", { method: "POST", body: JSON.stringify({ settings }) });
    applyBrainSettings({ ...(data.settings || settings), history: data.history || [], updatedAt: data.updatedAt || null });
    brainNotice(restored ? "Previous Lumi Brain version restored." : "Lumi Brain saved. New AI replies will use these preferences and matching knowledge cards.");
    return data;
  } catch (error) {
    $("brainSaveStatus").textContent = error.message;
    brainNotice(error.message, true);
    throw error;
  } finally {
    button.disabled = false;
    button.innerHTML = 'Save Lumi Brain <span>→</span>';
  }
}
$("behaviorInstructions")?.addEventListener("input", updateInstructionCount);
$("resetBrainDraft")?.addEventListener("click", () => {
  $("behaviorTone").value = DEFAULT_BRAIN_SETTINGS.tone;
  $("behaviorLanguage").value = DEFAULT_BRAIN_SETTINGS.language;
  $("behaviorLength").value = DEFAULT_BRAIN_SETTINGS.responseLength;
  $("behaviorInstructions").value = "";
  updateInstructionCount();
  brainNotice("Default preferences loaded as a draft. Save Lumi Brain to publish them.");
});
$("saveBrain")?.addEventListener("click", () => { void saveLumiBrain(); });
function clearKnowledgeForm() {
  $("knowledgeId").value = "";
  $("knowledgeTitle").value = "";
  $("knowledgeKeywords").value = "";
  $("knowledgeContent").value = "";
  $("knowledgeEnabled").checked = true;
  $("addKnowledge").textContent = "Add knowledge card";
  $("cancelKnowledgeEdit").classList.add("hidden");
}
$("knowledgeForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const title = $("knowledgeTitle").value.trim();
  const content = $("knowledgeContent").value.trim();
  if (!title || !content) return brainNotice("Add a title and reference content first.", true);
  const id = $("knowledgeId").value || `kb_${crypto.randomUUID()}`;
  const entry = {
    id, title,
    keywords: $("knowledgeKeywords").value.split(",").map(value => value.trim()).filter(Boolean).slice(0, 12),
    content: content.slice(0, 1400),
    enabled: $("knowledgeEnabled").checked
  };
  const rows = [...(currentBehaviorSettings.knowledgeBase || [])];
  const index = rows.findIndex(item => item.id === id);
  if (index >= 0) rows[index] = entry;
  else {
    if (rows.length >= 25) return brainNotice("The knowledge library is limited to 25 cards. Remove one before adding another.", true);
    rows.push(entry);
  }
  currentBehaviorSettings.knowledgeBase = rows;
  renderKnowledgeCards();
  clearKnowledgeForm();
  brainNotice("Knowledge card added to the draft. Click Save Lumi Brain to apply it.");
});
$("cancelKnowledgeEdit")?.addEventListener("click", clearKnowledgeForm);
$("knowledgeList")?.addEventListener("click", event => {
  const button = event.target.closest("button[data-knowledge-action]");
  if (!button) return;
  const rows = [...(currentBehaviorSettings.knowledgeBase || [])];
  const index = rows.findIndex(item => item.id === button.dataset.knowledgeId);
  if (index < 0) return;
  const item = rows[index];
  const action = button.dataset.knowledgeAction;
  if (action === "edit") {
    $("knowledgeId").value = item.id;
    $("knowledgeTitle").value = item.title;
    $("knowledgeKeywords").value = (item.keywords || []).join(", ");
    $("knowledgeContent").value = item.content;
    $("knowledgeEnabled").checked = item.enabled !== false;
    $("addKnowledge").textContent = "Update knowledge card";
    $("cancelKnowledgeEdit").classList.remove("hidden");
    $("knowledgeTitle").focus();
    return;
  }
  if (action === "toggle") rows[index] = { ...item, enabled: item.enabled === false };
  if (action === "remove") {
    if (!window.confirm(`Remove “${item.title}” from Lumi's draft knowledge library?`)) return;
    rows.splice(index, 1);
  }
  currentBehaviorSettings.knowledgeBase = rows;
  renderKnowledgeCards();
  brainNotice("Knowledge card changes are drafts. Save Lumi Brain to apply them.");
});
$("brainHistory")?.addEventListener("click", async event => {
  const button = event.target.closest("button[data-restore-brain]");
  if (!button) return;
  const version = currentBehaviorSettings.history.find(item => item.id === button.dataset.restoreBrain);
  if (!version) return;
  if (!window.confirm("Restore this saved Lumi Brain version? Your current settings will be kept in history.")) return;
  button.disabled = true;
  try {
    const data = await api("/admin/behavior", { method: "POST", body: JSON.stringify({ restoreId: button.dataset.restoreBrain }) });
    applyBrainSettings({ ...(data.settings || {}), history: data.history || [], updatedAt: data.updatedAt || null });
    brainNotice("Previous Lumi Brain version restored successfully.");
  } catch (error) { brainNotice(error.message, true); }
  finally { button.disabled = false; }
});

// ---------- Test Lab: owner-only simulated conversations ----------
function appendTestMessage(role, content) {
  const list = $("testChatMessages");
  const row = document.createElement("div");
  row.className = `test-message ${role === "user" ? "from-owner" : "from-lumi"}`;
  const label = document.createElement("small");
  label.textContent = role === "user" ? "YOU" : "LUMI";
  const body = document.createElement("p");
  body.textContent = content;
  row.append(label, body);
  list.append(row);
  list.scrollTop = list.scrollHeight;
}
function clearTestConversation() {
  testConversation = [];
  $("testChatMessages").innerHTML = '<div class="test-welcome"><div class="test-lumi-avatar">✦</div><div><b>Hi, I\'m Lumi.</b><p>Ask a question to preview my current behavior and knowledge settings.</p></div></div>';
  $("testUsage").textContent = "—";
  $("testLatency").textContent = "—";
  $("testKnowledgeMatches").textContent = "—";
  $("testChatStatus").textContent = "Test conversation cleared. Nothing was saved.";
}
$("clearTestChat")?.addEventListener("click", clearTestConversation);
$("testRole")?.addEventListener("change", () => { $("testRoleDisplay").textContent = $("testRole").selectedOptions[0]?.textContent || "Student"; });
document.querySelectorAll("[data-test-prompt]").forEach(button => button.addEventListener("click", () => {
  $("testChatInput").value = button.dataset.testPrompt || "";
  $("testChatInput").focus();
}));
$("testChatForm")?.addEventListener("submit", async event => {
  event.preventDefault();
  const input = $("testChatInput");
  const message = input.value.trim();
  if (!message) return;
  const role = $("testRole").value;
  const button = $("sendTestChat");
  input.value = "";
  appendTestMessage("user", message);
  button.disabled = true;
  button.textContent = "Thinking…";
  $("testChatStatus").textContent = "Sending a real Workers AI test request…";
  try {
    const data = await api("/admin/test-chat", {
      method: "POST",
      body: JSON.stringify({ message, role, history: testConversation.slice(-8), page: "Lumi Test Lab", title: "Owner response preview" })
    });
    appendTestMessage("assistant", data.answer || "No answer returned.");
    testConversation.push({ role: "user", content: message }, { role: "assistant", content: data.answer || "" });
    testConversation = testConversation.slice(-8);
    $("testModel").textContent = data.model || "—";
    $("testRoleDisplay").textContent = role.charAt(0).toUpperCase() + role.slice(1);
    $("testKnowledgeMatches").textContent = data.matchedKnowledge?.length ? data.matchedKnowledge.join(", ") : "None used";
    $("testLatency").textContent = `${Number(data.latencyMs || 0).toLocaleString()} ms`;
    const usage = data.usage || {};
    $("testUsage").textContent = usage.estimatedNeurons == null
      ? `${Number(usage.totalTokens || 0).toLocaleString()} tokens · estimate unavailable`
      : `${Number(usage.estimatedNeurons).toLocaleString()} estimated Neurons · ${Number(usage.totalTokens || 0).toLocaleString()} tokens`;
    $("testChatStatus").textContent = "Response received. The test conversation remains local to this tab.";
  } catch (error) {
    appendTestMessage("assistant", `Test failed: ${error.message}`);
    $("testChatStatus").textContent = "Test request failed. Check System Health and the AI Engine status.";
  } finally {
    button.disabled = false;
    button.innerHTML = 'Send <span>→</span>';
  }
});

// ---------- System Health ----------
function renderDiagnosticCard(title, ok, detail) {
  const card = document.createElement("article");
  card.className = "diagnostic-card";
  const top = document.createElement("div"); top.className = "diagnostic-card-top";
  const heading = document.createElement("b"); heading.textContent = title;
  const badge = document.createElement("span"); badge.className = `diagnostic-badge ${ok ? "ok" : "bad"}`; badge.textContent = ok ? "READY" : "CHECK";
  const text = document.createElement("p"); text.textContent = detail;
  top.append(heading, badge); card.append(top, text);
  return card;
}
async function runSystemDiagnostics({ silent = false } = {}) {
  const button = $("runDiagnostics");
  if (button) { button.disabled = true; button.textContent = "Checking…"; }
  try {
    const data = await api("/admin/diagnostics");
    const target = $("diagnosticsGrid");
    target.replaceChildren();
    target.append(
      renderDiagnosticCard("Lumi Worker", data.worker?.ok === true, "Owner-only diagnostics endpoint responded."),
      renderDiagnosticCard("Owner authorization", data.owner?.ok === true, data.owner?.uidSuffix ? `Verified owner identity · UID ending ${data.owner.uidSuffix}` : "Owner identity check"),
      renderDiagnosticCard("Workers AI binding", data.ai?.ok === true, data.ai?.model || "AI binding not configured"),
      renderDiagnosticCard("D1 database", data.database?.connected === true, data.database?.error || (data.database?.configured ? "D1 connection is responding." : "LUMI_DB binding is not configured.")),
      renderDiagnosticCard("Settings table", data.database?.settingsTable === true, data.database?.settingsTable ? "lumi_settings is readable." : "Could not read lumi_settings."),
      renderDiagnosticCard("Usage table", data.database?.usageTable === true, data.database?.usageTable ? "usage_events is readable." : "Could not read usage_events."),
      renderDiagnosticCard("AI engine", data.ai?.effectiveEnabled === true, data.ai?.state === "quota_paused" ? "Paused until the daily quota resets." : data.ai?.state === "manually_disabled" ? "AI inference is disabled by the owner." : "AI inference is enabled."),
      renderDiagnosticCard("Lumi Brain", Boolean(data.database?.settingsTable), `${Number(data.behavior?.knowledgeEntries || 0)} knowledge cards · ${data.behavior?.savedAt ? `updated ${new Date(data.behavior.savedAt).toLocaleString()}` : "using defaults"}`)
    );
    const allOk = data.ok === true;
    const summary = $("diagnosticsSummary");
    summary.textContent = allOk ? "All core services are responding." : "Some checks need attention. Review the cards below and open the Worker settings if a binding is missing.";
    summary.classList.remove("hidden", "error", "success");
    summary.classList.add(allOk ? "success" : "error");
    $("diagnosticsCheckedAt").textContent = `Last checked ${new Date(data.checkedAt || Date.now()).toLocaleString()}`;
    if (!silent) showNotice(allOk ? "Lumi system diagnostics passed." : "Lumi diagnostics found items that need attention.", !allOk);
    return data;
  } catch (error) {
    const summary = $("diagnosticsSummary");
    summary.textContent = error.message;
    summary.classList.remove("hidden", "success"); summary.classList.add("error");
    if (!silent) showNotice(error.message, true);
    throw error;
  } finally {
    if (button) { button.disabled = false; button.innerHTML = 'Run diagnostics <span>↻</span>'; }
  }
}
$("runDiagnostics")?.addEventListener("click", () => { void runSystemDiagnostics(); });

$("copySecurityUid").addEventListener("click", async () => { await navigator.clipboard.writeText(currentUser?.uid || ""); $("copySecurityUid").textContent = "Copied!"; });

// Load data/config after the owner has passed server-side authorization.
async function refreshWithAppearance({ showMessage = false } = {}) {
  await refreshAll({ showMessage });
  try { await loadAppearance(); } catch (error) { console.warn("Appearance settings could not be loaded", error); }
  try { await loadAiSettings(); } catch (error) { console.warn("AI engine settings could not be loaded", error); }
  try { await loadLumiBrain(); } catch (error) { console.warn("Lumi Brain settings could not be loaded", error); }
}

// Lightweight owner-only polling checks the newest D1 event every 10 seconds.
// The full analytics endpoint is called only when a new usage row is detected.
async function checkForNewUsage(forceRefresh = false) {
  if (!currentUser || document.hidden || updateCheckBusy || overviewRefreshBusy) return;
  updateCheckBusy = true;
  updateLiveIndicator("checking", "Checking for new AI activity…");
  try {
    const latest = await api("/admin/updates");
    try { await loadAiSettings(); } catch (settingsError) { console.warn("Lumi AI engine status check failed", settingsError); }
    const remoteVersion = String(latest.version || "empty");
    if (forceRefresh || (latestUsageVersion !== null && remoteVersion !== latestUsageVersion)) {
      await refreshAll();
      // If another request arrived during the overview query, the next short poll
      // will detect it because the overview's newest event version will differ.
    } else if (latestUsageVersion === null) {
      latestUsageVersion = remoteVersion;
      markLiveCheck();
    } else {
      markLiveCheck();
    }
  } catch (error) {
    updateLiveIndicator("warning", "Live sync · reconnecting");
    console.warn("Lumi Admin live usage check failed", error);
  } finally {
    updateCheckBusy = false;
  }
}
function startLiveUsageUpdates() {
  clearInterval(refreshTimer);
  updateLiveIndicator("live", "Live sync · every 10 seconds");
  refreshTimer = setInterval(() => { void checkForNewUsage(); }, 10000);
}
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) void checkForNewUsage(true);
});
window.addEventListener("focus", () => { void checkForNewUsage(true); });

$("refreshButton").onclick = async () => {
  const button = $("refreshButton");
  button.classList.add("is-refreshing");
  try {
    await refreshWithAppearance({ showMessage: true });
  } catch (error) {
    updateLiveIndicator("warning", "Live sync · refresh failed");
    showNotice(error.message, true);
  } finally {
    button.classList.remove("is-refreshing");
  }
};

