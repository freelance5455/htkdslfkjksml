let THREE = null;
let renderer = null, scene = null, camera = null, root = null, character = null;
let halo = null, orbit = null, sparks = [], parts = {};
let currentType = "humanoid", currentSettings = null, raf = 0, resizeObserver = null;
let dragging = false, lastX = 0, lastY = 0, rotationX = 0, rotationY = 0;
const canvasId = "appearancePreviewCanvas";

function makeMaterials(settings) {
  const c = settings?.colors || {};
  return {
    shell: new THREE.MeshPhysicalMaterial({color:c.shell || "#f2ecff",roughness:.25,metalness:.08,clearcoat:.9}),
    shade: new THREE.MeshPhysicalMaterial({color:c.shellShade || "#c8b5ff",roughness:.28,metalness:.12,clearcoat:.7}),
    accent: new THREE.MeshPhysicalMaterial({color:c.purple || "#8059df",roughness:.24,metalness:.2,clearcoat:1}),
    deep: new THREE.MeshPhysicalMaterial({color:c.purpleDark || "#432b91",roughness:.25,metalness:.25,clearcoat:1}),
    eye: new THREE.MeshStandardMaterial({color:c.cyan || "#7dd5ff",emissive:c.cyan || "#7dd5ff",emissiveIntensity:1.6,roughness:.2}),
    metal: new THREE.MeshStandardMaterial({color:c.gold || "#f5d9a4",metalness:.7,roughness:.25}),
    face: new THREE.MeshPhysicalMaterial({color:"#17132e",roughness:.18,metalness:.12,clearcoat:1}),
    white: new THREE.MeshStandardMaterial({color:"#ffffff",roughness:.2})
  };
}
function addMesh(group, geometry, material, pos=[0,0,0], scale=[1,1,1]) {
  const mesh = new THREE.Mesh(geometry, material); mesh.position.set(...pos); mesh.scale.set(...scale); mesh.castShadow=true; mesh.receiveShadow=true; group.add(mesh); return mesh;
}
function ball(group, material, pos, scale=[1,1,1], radius=.5) { return addMesh(group,new THREE.SphereGeometry(radius,32,24),material,pos,scale); }
function rod(group, material, a, b, radius=.07) {
  const start=new THREE.Vector3(...a), end=new THREE.Vector3(...b), delta=end.clone().sub(start);
  const mesh=addMesh(group,new THREE.CylinderGeometry(radius,radius,delta.length(),16),material,[0,0,0]);
  mesh.position.copy(start).add(end).multiplyScalar(.5); mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize()); return mesh;
}
function addEyes(group,m,posY=0,posZ=.56,spacing=.22,size=.095) {
  for (const x of [-spacing,spacing]) {
    ball(group,m.deep,[x,posY,posZ],[1.12,1.18,.55],size*1.65);
    ball(group,m.eye,[x,posY,posZ+.055],[.9,1.1,.6],size);
    ball(group,m.white,[x-.025,posY+.035,posZ+.09],[.45,.45,.35],size*.33);
  }
}
function roundedCube(group,mat,pos,scale) {
  const mesh=addMesh(group,new THREE.BoxGeometry(1,1,1),mat,pos,scale);
  return mesh;
}
function buildCharacter(type,m) {
  const g=new THREE.Group(); parts={};
  if(type==="humanoid") {
    ball(g,m.shell,[0,.15,0],[.75,.92,.55],.56);
    ball(g,m.shell,[0,.98,.02],[.78,.72,.62],.56);
    ball(g,m.face,[0,.94,.51],[.88,.55,.23],.52); addEyes(g,m,.98,.69,.22,.09);
    rod(g,m.accent,[0,1.43,0],[0,1.73,0],.045); ball(g,m.eye,[0,1.77,0],[1,1,1],.085);
    parts.leftArm=rod(g,m.shade,[-.52,.25,0],[-.8,-.35,.02],.09);
    parts.rightArm=rod(g,m.shade,[.52,.25,0],[.8,-.35,.02],.09);
    rod(g,m.deep,[-.24,-.45,0],[-.24,-1.0,0],.12); rod(g,m.deep,[.24,-.45,0],[.24,-1.0,0],.12);
    ball(g,m.metal,[0,.08,.51],[.28,.28,.14],.17);
  } else if(type==="orb") {
    ball(g,m.shell,[0,.1,0],[1.1,1.1,.9],.68);
    ball(g,m.shade,[0,.1,.68],[.88,.58,.26],.54);
    ball(g,m.face,[0,.1,.82],[.8,.48,.15],.52); addEyes(g,m,.12,.94,.24,.12);
    const ring=addMesh(g,new THREE.TorusGeometry(1.12,.035,12,72),m.accent,[0,.05,0],[1,1,.8]); ring.rotation.x=.65; parts.ring=ring;
    rod(g,m.metal,[0,.82,0],[0,1.15,0],.04); ball(g,m.eye,[0,1.2,0],[1,1,1],.09);
  } else if(type==="puppy") {
    ball(g,m.shell,[0,-.38,0],[.95,.55,.62],.6);
    ball(g,m.shell,[0,.35,.08],[.78,.76,.66],.58);
    ball(g,m.shade,[-.59,.55,0],[.38,.7,.22],.4); ball(g,m.shade,[.59,.55,0],[.38,.7,.22],.4);
    ball(g,m.face,[0,.15,.57],[.48,.32,.28],.38);
    addEyes(g,m,.42,.68,.22,.085); ball(g,m.deep,[0,.19,.83],[1.1,.8,.5],.105);
    for(const x of [-.56,.56])for(const z of [-.32,.32])rod(g,m.shade,[x*.7,-.58,z],[x*.85,-1.02,z],.085);
    const tail=addMesh(g,new THREE.TorusGeometry(.25,.075,12,28),m.accent,[.78,-.17,-.1]); tail.rotation.y=1.2; parts.tail=tail;
    ball(g,m.metal,[0,-.36,.62],[.18,.18,.08],.12);
  } else if(type==="cube") {
    roundedCube(g,m.shell,[0,.05,0],[1.45,1.42,1.05]);
    roundedCube(g,m.face,[0,.13,.55],[1.12,.62,.12]); addEyes(g,m,.18,.68,.23,.095);
    parts.cubeTop=addMesh(g,new THREE.BoxGeometry(.22,.28,.22),m.accent,[0,.91,0]);
    rod(g,m.shade,[-.74,.18,0],[-1.02,-.25,.02],.09); rod(g,m.shade,[.74,.18,0],[1.02,-.25,.02],.09);
    rod(g,m.deep,[-.35,-.65,0],[-.35,-1.02,0],.12); rod(g,m.deep,[.35,-.65,0],[.35,-1.02,0],.12);
    ball(g,m.metal,[0,-.36,.62],[.2,.2,.08],.12);
  } else if(type==="bird") {
    ball(g,m.shell,[0,-.1,0],[.74,.95,.62],.58); ball(g,m.shell,[0,.75,.05],[.57,.55,.5],.52);
    addEyes(g,m,.78,.5,.19,.08);
    const beak=addMesh(g,new THREE.ConeGeometry(.17,.34,5),m.metal,[0,.43,.69]); beak.rotation.x=Math.PI/2;
    const left=ball(g,m.accent,[-.7,-.1,0],[.72,.18,.42],.5), right=ball(g,m.accent,[.7,-.1,0],[.72,.18,.42],.5);
    parts.wings=[left,right]; rod(g,m.deep,[-.2,-.85,0],[-.2,-1.15,.05],.055); rod(g,m.deep,[.2,-.85,0],[.2,-1.15,.05],.055);
    ball(g,m.shade,[0,-.98,-.2],[.38,.18,.25],.24);
  } else if(type==="rover") {
    roundedCube(g,m.shell,[0,-.18,0],[1.8,.82,1.05]);
    ball(g,m.shell,[0,.52,.02],[.6,.53,.55],.5); ball(g,m.face,[0,.48,.49],[.82,.52,.18],.5); addEyes(g,m,.52,.65,.2,.085);
    rod(g,m.metal,[0,.95,-.05],[0,1.3,-.05],.045); ball(g,m.eye,[0,1.34,-.05],[1,1,1],.08);
    const wheels=[]; for(const x of [-.82,.82])for(const z of [-.32,.32]){const w=addMesh(g,new THREE.TorusGeometry(.27,.11,12,32),m.deep,[x,-.48,z]);w.rotation.y=Math.PI/2;wheels.push(w);} parts.wheels=wheels;
  } else if(type==="cat") {
    ball(g,m.shell,[0,-.35,0],[.78,.62,.58],.55); ball(g,m.shell,[0,.46,.06],[.72,.7,.58],.56);
    const ear1=addMesh(g,new THREE.ConeGeometry(.27,.62,4),m.shade,[-.47,1.05,.03]); ear1.rotation.z=-.24;
    const ear2=addMesh(g,new THREE.ConeGeometry(.27,.62,4),m.shade,[.47,1.05,.03]); ear2.rotation.z=.24;
    addEyes(g,m,.55,.58,.21,.085); ball(g,m.accent,[0,.19,.62],[.11,.08,.07],.10);
    const tail=addMesh(g,new THREE.TorusGeometry(.38,.07,12,32),m.accent,[.72,-.36,-.05]);tail.rotation.y=1.0;parts.tail=tail;
    rod(g,m.shade,[-.35,-.68,0],[-.4,-1.0,0],.09);rod(g,m.shade,[.35,-.68,0],[.4,-1.0,0],.09);
  } else if(type==="drone") {
    ball(g,m.shell,[0,.08,0],[.72,.55,.62],.56); ball(g,m.face,[0,.08,.53],[.8,.52,.2],.5); addEyes(g,m,.12,.68,.2,.09);
    const rotors=[]; for(const [x,z] of [[-.95,-.55],[.95,-.55],[-.95,.55],[.95,.55]]){
      rod(g,m.shade,[0,.18,0],[x,.24,z],.065);
      const rotor=new THREE.Group();rotor.position.set(x,.28,z);g.add(rotor);
      addMesh(rotor,new THREE.TorusGeometry(.32,.035,8,28),m.metal,[0,0,0]);
      rod(rotor,m.accent,[-.27,0,0],[.27,0,0],.035); rotors.push(rotor);
    } parts.rotors=rotors;
  }
  return g;
}

export async function initAppearancePreview() {
  const stage=document.getElementById("appearancePreview");
  const canvas=document.getElementById(canvasId);
  if(!stage||!canvas)return;
  try {
    THREE=await import("https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js");
    renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:"low-power"});
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
    renderer.outputColorSpace=THREE.SRGBColorSpace;
    renderer.setClearColor(0x000000,0);
    scene=new THREE.Scene();
    camera=new THREE.PerspectiveCamera(35,1,.1,50); camera.position.set(0,.2,5.4);
    scene.add(new THREE.HemisphereLight(0xf6efff,0x34304f,2.2));
    const key=new THREE.DirectionalLight(0xffffff,3); key.position.set(-3,5,6); scene.add(key);
    const fill=new THREE.PointLight(0x927aff,22,10); fill.position.set(2,1,3); scene.add(fill);
    root=new THREE.Group(); scene.add(root);
    halo=addMesh(root,new THREE.TorusGeometry(1.35,.018,10,80),new THREE.MeshBasicMaterial({color:0xbca7ff,transparent:true,opacity:.62}),[0,.05,-.45]); halo.rotation.set(.9,.1,-.2);
    orbit=addMesh(root,new THREE.TorusGeometry(1.55,.012,8,80),new THREE.MeshBasicMaterial({color:0x7dd5ff,transparent:true,opacity:.32}),[0,.05,-.5]); orbit.rotation.set(1.1,.2,.5);
    const sm=new THREE.MeshBasicMaterial({color:0xd8ceff}); sparks=[];
    for(let i=0;i<9;i++){const s=addMesh(root,new THREE.OctahedronGeometry(.045,0),sm,[Math.cos(i/9*Math.PI*2)*1.55,Math.sin(i/9*Math.PI*2)*1.1,-.1]);sparks.push({mesh:s,phase:i*.8,base:s.position.clone()});}
    character=new THREE.Group(); root.add(character);
    currentSettings={characterType:"humanoid",scale:1,showHalo:true,showSparkles:true,colors:{}};
    rebuildCharacter("humanoid");
    const resize=()=>{const w=Math.max(1,stage.clientWidth),h=Math.max(1,stage.clientHeight);renderer.setSize(w,h,false);camera.aspect=w/h;camera.position.z=h/w>1.2?6:5.4;camera.updateProjectionMatrix();};
    resizeObserver=new ResizeObserver(resize); resizeObserver.observe(stage); resize();
    canvas.addEventListener("pointerdown",e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture?.(e.pointerId);});
    canvas.addEventListener("pointermove",e=>{if(!dragging)return;rotationY+=(e.clientX-lastX)*.008;rotationX+=(e.clientY-lastY)*.006;lastX=e.clientX;lastY=e.clientY;});
    const finish=()=>dragging=false; canvas.addEventListener("pointerup",finish); canvas.addEventListener("pointercancel",finish);
    const clock=new THREE.Clock();
    const animate=()=>{raf=requestAnimationFrame(animate);const t=clock.getElapsedTime();if(character){character.rotation.y+=(rotationY-character.rotation.y)*.12;character.rotation.x+=(rotationX-character.rotation.x)*.12;character.position.y=Math.sin(t*1.5)*.055;character.rotation.z=Math.sin(t*.7)*.018;if(parts.tail)parts.tail.rotation.x=Math.sin(t*2)*.18;if(parts.wings){parts.wings[0].rotation.z=Math.sin(t*6)*.24;parts.wings[1].rotation.z=-Math.sin(t*6)*.24;}if(parts.rotors)parts.rotors.forEach(r=>r.rotation.y=t*8);}halo.rotation.z=t*.12;orbit.rotation.z=-t*.09;sparks.forEach(s=>{s.mesh.position.y=s.base.y+Math.sin(t*1.1+s.phase)*.08;s.mesh.rotation.y=t*.7+s.phase;});renderer.render(scene,camera);};
    animate();
    window.addEventListener("pagehide",()=>{cancelAnimationFrame(raf);resizeObserver?.disconnect();renderer?.dispose();},{once:true});
  } catch(error) {
    console.warn("3D appearance preview unavailable",error);
    stage.classList.add("preview-fallback");
    const note=document.createElement("div");note.className="preview-load-error";note.textContent="3D preview could not load. The saved appearance controls will still work.";stage.append(note);
  }
}
function rebuildCharacter(type) {
  if(!THREE||!character)return;
  while(character.children.length){const child=character.children[0];character.remove(child);child.traverse?.(o=>{if(o.geometry)o.geometry.dispose();if(o.material && !Array.isArray(o.material))o.material.dispose();});}
  const m=makeMaterials(currentSettings||{}); parts={};
  const model=buildCharacter(type,m); character.add(model); parts={...parts};
  // Keep material references grouped so edits recolor every part consistently.
  character.userData.materials=m;
  currentType=type;
}
export function updateAppearancePreview(settings) {
  if(!settings)return;
  currentSettings={...currentSettings,...settings,colors:{...(currentSettings?.colors||{}),...(settings.colors||{})}};
  const type=currentSettings.characterType||"humanoid";
  if(character&&type!==currentType)rebuildCharacter(type);
  if(character){
    character.scale.setScalar(Math.max(.75,Math.min(1.25,Number(currentSettings.scale)||1)));
    const c=currentSettings.colors||{},m=character.userData.materials||{};
    for(const [key,value] of Object.entries({shell:c.shell,shade:c.shellShade,accent:c.purple,deep:c.purpleDark,eye:c.cyan,metal:c.gold})) if(m[key]&&value)m[key].color.set(value);
  }
  if(halo)halo.visible=currentSettings.showHalo!==false;
  if(orbit)orbit.visible=currentSettings.showHalo!==false;
  sparks.forEach(s=>s.mesh.visible=currentSettings.showSparkles!==false);
  const rootEl=document.getElementById("appearancePreview");
  if(rootEl){rootEl.dataset.character=type;rootEl.style.setProperty("--preview-accent",currentSettings.colors?.purple||"#8059df");}
  const previewName=document.getElementById("previewName");
  if(previewName)previewName.textContent=`${type.charAt(0).toUpperCase()+type.slice(1)} · ${currentSettings.preset||"Custom"}`;
}
