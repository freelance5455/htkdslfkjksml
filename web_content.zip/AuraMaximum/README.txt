AURA MAXIMUM — proyecto Android inicial

Incluye una app Android horizontal con interfaz local, minijuegos Tetris y Flappy Night, accesos de búsqueda de emuladores, favoritos locales y atajos de YouTube/Spotify.

IMPORTANTE: este ZIP contiene el PROYECTO FUENTE, no un APK ya compilado. Para crear el APK, abre la carpeta en Android Studio/CodeAssist compatible con proyectos Gradle y compila la variante debug. Requiere Android SDK instalado y conexión para descargar el plugin Gradle la primera vez.

Compatibilidad: minSdk 23. El lanzador intenta abrir aplicaciones de emulación mediante sus identificadores habituales y, si no funciona, ofrece la búsqueda en Google Play. La disponibilidad depende de las apps instaladas y de la versión Android.

La música de YouTube se abre en YouTube; no se incrusta ni descarga contenido. Los juegos comerciales, ROMs y BIOS no se incluyen.
