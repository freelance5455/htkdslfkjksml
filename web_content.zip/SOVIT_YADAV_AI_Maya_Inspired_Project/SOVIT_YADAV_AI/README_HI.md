# SOVIT YADAV AI — Personal Assistant (HTML/CSS/JS)

यह Maya-inspired लेकिन original UI वाला browser prototype है। यह Maya ऐप का असली source code नहीं है। इसमें responsive dashboard, Gemini chat, browser voice, optional voice endpoint, image scan, local memories, journal, study helper, weather endpoint adapter, mood log और settings शामिल हैं।

## Files
- `index.html` — UI / screens
- `styles.css` — blue-white neumorphic design
- `app.js` — app logic, Gemini API, browser speech, local storage
- `manifest.webmanifest`, `sw.js` — basic PWA shell

## Android पर चलाने का आसान तरीका
1. ZIP को extract करें।
2. `index.html`, `styles.css`, `app.js`, `manifest.webmanifest`, `sw.js` एक ही folder में रखें।
3. सबसे भरोसेमंद तरीका: folder को किसी static web host पर HTTPS के साथ publish करें। HTTPS पर microphone और service worker बेहतर support करते हैं।
4. केवल फोन पर local test के लिए ऐसा editor/file manager इस्तेमाल करें जो HTML preview देता हो। `file://` से microphone, network/CORS या service worker सीमित हो सकते हैं।
5. Website खुलने पर Settings खोलें, Gemini API key डालें, model name verify करें, फिर Save Settings दबाएँ।
6. Chat, Study या Scan से test करें। Microphone permission पूछे तो अनुमति दें।

## Gemini API
यह app Google Generative Language API के `generateContent` endpoint को call करता है। Default model `gemini-2.5-flash` है; यदि आपके Google AI Studio project में model उपलब्ध न हो, Settings में ऐसा model name डालें जो आपके API key/account के लिए उपलब्ध हो।

## IMPORTANT: API key सुरक्षा
यह frontend-only demo है। API key browser storage में save होती है और browser devtools या device access रखने वाला व्यक्ति उसे देख सकता है। इसे public website पर production app की तरह deploy न करें और किसी दूसरे व्यक्ति को अपनी key न दें। बड़े/public project के लिए:
- Gemini call को अपने backend/serverless function के पीछे रखें।
- API key server environment variable में रखें।
- rate limits, authentication, abuse prevention और spending limits जोड़ें।
- client से सीधे secret keys न भेजें।

## Voice
- Speech recognition: `SpeechRecognition` / `webkitSpeechRecognition` जहाँ supported हो।
- Text-to-speech: browser `speechSynthesis`।
- Optional voice API fallback: Settings में endpoint डालें। इस starter का adapter JSON `{ "text": "...", "language": "hi-IN" }` POST करता है और response में `audio/*` bytes अपेक्षित करता है। आपके provider का format अलग हो तो `speakText()` को उसके documentation के अनुसार बदलें। Browser CORS भी allow होना चाहिए।
- यह voice adapter universal provider integration नहीं है। कोई भी voice API स्वतः compatible नहीं होगी।

## Weather
Settings में endpoint template डालें, जिसमें `{city}` और `{key}` placeholders हो सकते हैं। उदाहरण के तौर पर provider के documentation के अनुसार URL template बनाएं। अलग providers का JSON response अलग होता है; app common response fields पढ़ने की कोशिश करता है और बाकी response दिखाता है।

## Local data
Memories, journal, mood, chat history और goal उसी browser की `localStorage` में रहते हैं। वे अपने-आप cloud में sync नहीं होते। Shared device पर private notes save करने से बचें। Settings screen में export और clear options हैं।

## सीमाएँ
- Music button फिलहाल music suggestions के लिए chat खोलता है; यह paid music service या copyrighted audio stream नहीं चलाता।
- Scan के लिए image Gemini API को भेजी जाती है।
- Weather endpoint/API key अलग से चाहिए।
- Real-time expressive voice, background listening, interruptions, accounts, cloud sync और production-grade memory के लिए अतिरिक्त services/backend चाहिए।
- AI output गलत हो सकता है; शिक्षा, स्वास्थ्य, वित्त या सुरक्षा से जुड़े महत्वपूर्ण उत्तर verify करें।

Developer credit: Sovit Yadav
