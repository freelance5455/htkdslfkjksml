/* SOVIT YADAV AI — original Maya-inspired assistant prototype */
"use strict";

const $ = (id) => document.getElementById(id);
const STORAGE = {
  settings: "sovit_ai_settings_v1", memories: "sovit_ai_memories_v1",
  journal: "sovit_ai_journal_v1", moods: "sovit_ai_moods_v1",
  chat: "sovit_ai_chat_v1", goal: "sovit_ai_goal_v1"
};
let selectedImage = null;
let selectedMood = "";
let recognition = null;
let toastTimer = null;

function readStore(key, fallback) {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
}
function writeStore(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function getSettings() {
  return { apiKey:"", model:"gemini-2.5-flash", assistantName:"Maya-inspired AI",
    systemPrompt:"You are a helpful, warm, respectful personal AI assistant. Reply in the language the user uses, especially Hindi or English. Be clear, honest about uncertainty, and never claim you can do things you cannot do.",
    voiceEndpoint:"", voiceApiKey:"", weatherEndpoint:"", weatherKey:"",
    ...readStore(STORAGE.settings, {}) };
}
let settings = getSettings();

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function showNotice(message) { $("noticeText").textContent = message; $("notice").hidden = false; }
function hideNotice() { $("notice").hidden = true; }

function navigate(view) {
  const target = $("view-" + view);
  if (!target) return;
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el === target));
  document.querySelectorAll("[data-view].nav-item").forEach(el => el.classList.toggle("selected", el.dataset.view === view));
  window.scrollTo({ top: 0, behavior: "smooth" });
  if (view === "memory") renderMemories();
  if (view === "journal") renderJournal();
  if (view === "mood") renderMoods();
  if (view === "settings") fillSettings();
}
document.querySelectorAll("[data-view]").forEach(btn => btn.addEventListener("click", () => navigate(btn.dataset.view)));
$("menuBtn").addEventListener("click", () => {
  const options = ["home","chat","voice","scan","memory","journal","study","weather","mood","settings"];
  const choice = prompt("Kahan jaana hai?\n" + options.map((v,i)=>`${i+1}. ${v}`).join("\n"));
  const index = Number(choice) - 1;
  if (Number.isInteger(index) && options[index]) navigate(options[index]);
});
$("noticeBtn").addEventListener("click", () => showNotice("Microphone ke liye browser permission allow karein. Gemini ke liye Settings mein API key add karein."));
$("dismissNotice").addEventListener("click", hideNotice);

function initDate() {
  const now = new Date();
  $("todayDate").textContent = now.getDate();
  $("todayDay").textContent = now.toLocaleDateString("en-IN", { weekday:"short", month:"short" });
  $("todayYear").textContent = String(now.getFullYear());
  $("todayFull").textContent = now.toLocaleDateString("hi-IN", { weekday:"long", day:"numeric", month:"long", year:"numeric" });
  const hour = now.getHours();
  $("greetingText").textContent = hour < 12 ? "Suprabhat!" : hour < 17 ? "Namaste!" : "Shubh sandhya!";
  $("brandName").textContent = settings.assistantName || "Maya-inspired AI";
  $("apiStatus").textContent = settings.apiKey ? "Gemini API configured • personal mode" : "Gemini API key add karne ke liye Settings kholo";
  $("savedGoal").textContent = readStore(STORAGE.goal, "") ? "Aaj ka goal: " + readStore(STORAGE.goal, "") : "";
}
function fillSettings() {
  settings = getSettings();
  $("apiKey").value = settings.apiKey;
  $("modelName").value = settings.model;
  $("assistantName").value = settings.assistantName;
  $("systemPrompt").value = settings.systemPrompt;
  $("voiceEndpoint").value = settings.voiceEndpoint;
  $("voiceApiKey").value = settings.voiceApiKey;
  $("weatherEndpoint").value = settings.weatherEndpoint;
  $("weatherKey").value = settings.weatherKey;
}
function saveSettings() {
  settings = {
    apiKey: $("apiKey").value.trim(), model: $("modelName").value.trim() || "gemini-2.5-flash",
    assistantName: $("assistantName").value.trim() || "Maya-inspired AI",
    systemPrompt: $("systemPrompt").value.trim(), voiceEndpoint: $("voiceEndpoint").value.trim(),
    voiceApiKey: $("voiceApiKey").value.trim(), weatherEndpoint: $("weatherEndpoint").value.trim(),
    weatherKey: $("weatherKey").value.trim()
  };
  writeStore(STORAGE.settings, settings); initDate();
  $("settingsStatus").hidden = false; $("settingsStatus").textContent = "Settings is browser mein save ho gayi.";
  toast("Settings save ho gayi.");
}
$("saveSettingsBtn").addEventListener("click", saveSettings);

function getChatHistory() { return readStore(STORAGE.chat, []); }
function addMessage(role, text, persist = true) {
  const wrapper = document.createElement("div"); wrapper.className = "message " + (role === "user" ? "user" : "assistant");
  const avatar = document.createElement("span"); avatar.className = "message-avatar"; avatar.textContent = role === "user" ? "●" : "✦";
  const content = document.createElement("div"); const name = document.createElement("b"); name.textContent = role === "user" ? "Aap" : (settings.assistantName || "AI Assistant");
  const p = document.createElement("p"); p.textContent = text; content.append(name,p); wrapper.append(avatar,content); $("chatMessages").append(wrapper);
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
  if (persist) { const history = getChatHistory(); history.push({role, text, time:Date.now()}); writeStore(STORAGE.chat, history.slice(-80)); }
}
function renderChatHistory() {
  const history = getChatHistory();
  if (!history.length) return;
  $("chatMessages").innerHTML = "";
  history.forEach(m => addMessage(m.role, m.text, false));
}
function toGeminiHistory(history) {
  return history.filter(m => m.role === "user" || m.role === "assistant").slice(-16).map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.text }]
  }));
}
async function geminiGenerate(prompt, options = {}) {
  settings = getSettings();
  if (!settings.apiKey) throw new Error("Pehle Settings mein Gemini API key add karein.");
  const model = encodeURIComponent(settings.model || "gemini-2.5-flash");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(settings.apiKey)}`;
  const history = options.history || [];
  const contents = history.length ? toGeminiHistory(history) : [{ role:"user", parts:[{text:prompt}] }];
  if (history.length && prompt) contents.push({role:"user",parts:[{text:prompt}]});
  const body = { contents, systemInstruction:{parts:[{text:settings.systemPrompt || "You are a helpful assistant."}]},
    generationConfig:{temperature:0.7, maxOutputTokens:2048} };
  if (options.image) {
    const last = contents[contents.length - 1];
    last.parts.push({ inlineData:{mimeType:options.image.mimeType, data:options.image.base64} });
  }
  const response = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(body)});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) {
    const message = data?.error?.message || `Gemini request failed (${response.status})`;
    throw new Error(message);
  }
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("").trim();
  if (!text) throw new Error("AI se text response nahi mila. Model/API access check karein.");
  return text;
}
async function askGemini(prompt, options = {}) {
  return geminiGenerate(prompt, { ...options, history: options.history || [] });
}
function setBusy(button, busy, label) {
  if (!button.dataset.originalLabel) button.dataset.originalLabel = button.textContent;
  button.disabled = busy; button.textContent = busy ? label : button.dataset.originalLabel;
}
async function sendChat() {
  const input = $("chatInput"); const text = input.value.trim();
  if (!text && !selectedImage) return;
  const image = selectedImage; selectedImage = null; $("chatImage").value = ""; input.value = "";
  const prompt = text || "Is image ko describe aur analyze karo.";
  addMessage("user", image ? `${prompt}\n[Image attached]` : prompt);
  const button = $("sendBtn"); button.disabled = true; button.textContent = "…";
  try {
    const history = getChatHistory().slice(0,-1);
    let answer = await askGemini(prompt, {history, image});
    addMessage("assistant", answer);
  } catch (error) {
    addMessage("assistant", "Maaf kijiye, request complete nahi hui: " + error.message + "\nSettings mein API key, model aur internet connection check karein.");
  } finally { button.disabled = false; button.textContent = "➤"; }
}
$("sendBtn").addEventListener("click", sendChat);
$("chatInput").addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } });
$("clearChatBtn").addEventListener("click", () => {
  if (!confirm("Chat history clear kar dein?")) return;
  localStorage.removeItem(STORAGE.chat); $("chatMessages").innerHTML = "";
  addMessage("assistant","Chat clear ho gayi. Ab nayi baat shuru kar sakte hain.",false); toast("Chat history clear.");
});
$("chatImage").addEventListener("change", async e => {
  const file = e.target.files?.[0]; if (!file) return;
  if (!file.type.startsWith("image/")) { toast("Image file choose karein."); return; }
  try { selectedImage = await fileToGeminiImage(file); toast("Image attach ho gayi."); }
  catch (err) { toast(err.message); }
});
function fileToGeminiImage(file) {
  return new Promise((resolve,reject) => {
    if (file.size > 8 * 1024 * 1024) { reject(new Error("Image 8 MB se chhoti honi chahiye.")); return; }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Image read nahi ho paayi."));
    reader.onload = () => resolve({mimeType:file.type, base64:String(reader.result).split(",")[1]});
    reader.readAsDataURL(file);
  });
}

// Voice: browser SpeechRecognition first; configured provider endpoint as optional TTS fallback.
function getRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return null;
  const r = new SpeechRecognition(); r.lang = "hi-IN"; r.interimResults = true; r.continuous = false;
  return r;
}
async function startListening() {
  recognition = getRecognition();
  if (!recognition) {
    $("voiceStatus").textContent = "Browser speech recognition available nahi";
    showNotice("Is browser mein speech recognition support nahi hai. Aap text chat use karein ya supported Voice API integrate karein.");
    toast("Speech recognition unsupported."); return;
  }
  $("voiceStatus").textContent = "Sun raha hoon…"; $("voiceOrb").classList.add("listening");
  $("voiceTranscript").textContent = "Boliye…";
  recognition.onresult = async event => {
    const transcript = Array.from(event.results).map(r => r[0].transcript).join("");
    $("voiceTranscript").textContent = transcript;
    if (event.results[event.results.length - 1].isFinal) {
      $("voiceStatus").textContent = "Jawab tayyar kar raha hoon…";
      try {
        const answer = await askGemini(transcript);
        $("voiceReply").textContent = answer; $("voiceStatus").textContent = "Jawab ready";
        addMessage("user", transcript); addMessage("assistant", answer);
        await speakText(answer);
      } catch (err) { $("voiceStatus").textContent = "Request fail hui"; $("voiceReply").textContent = err.message; toast(err.message); }
      finally { $("voiceOrb").classList.remove("listening"); }
    }
  };
  recognition.onerror = e => { $("voiceStatus").textContent = "Voice error: " + e.error; $("voiceOrb").classList.remove("listening"); };
  recognition.onend = () => $("voiceOrb").classList.remove("listening");
  try { recognition.start(); } catch { $("voiceStatus").textContent = "Mic pehle se active hai."; }
}
async function speakText(text) {
  // Generic TTS adapter: expects a configured endpoint to return audio bytes (audio/*).
  if (settings.voiceEndpoint) {
    try {
      const response = await fetch(settings.voiceEndpoint, {
        method:"POST", headers:{"Content-Type":"application/json", ...(settings.voiceApiKey ? {"Authorization":"Bearer " + settings.voiceApiKey} : {})},
        body:JSON.stringify({text, language:"hi-IN"})
      });
      if (!response.ok) throw new Error("Voice API HTTP " + response.status);
      const blob = await response.blob();
      if (!blob.type.startsWith("audio/")) throw new Error("Voice endpoint ko audio/* response return karna chahiye.");
      const audio = new Audio(URL.createObjectURL(blob)); await audio.play(); return;
    } catch (err) { console.warn("Voice API fallback failed; using browser TTS", err); }
  }
  if (!("speechSynthesis" in window)) { toast("Text-to-Speech is browser mein supported nahi."); return; }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text); utterance.lang = "hi-IN"; utterance.rate = 1; utterance.pitch = 1.03;
  window.speechSynthesis.speak(utterance);
}
$("listenBtn").addEventListener("click", startListening);
$("stopSpeakBtn").addEventListener("click", () => { if (recognition) recognition.stop(); if ("speechSynthesis" in window) speechSynthesis.cancel(); $("voiceOrb").classList.remove("listening"); $("voiceStatus").textContent = "Ruk gaya"; });
$("voiceOrb").addEventListener("click", startListening);

// Image scan uses Gemini multimodal inlineData.
$("scanFile").addEventListener("change", async e => {
  const file = e.target.files?.[0]; if (!file) return;
  try {
    selectedImage = await fileToGeminiImage(file);
    $("scanPreview").src = URL.createObjectURL(file); $("scanPreview").hidden = false;
    toast("Image ready.");
  } catch (err) { toast(err.message); }
});
$("analyzeImageBtn").addEventListener("click", async () => {
  if (!selectedImage) { toast("Pehle image select karein."); return; }
  const question = $("scanQuestion").value.trim() || "Describe this image and explain the important details.";
  const btn = $("analyzeImageBtn"); setBusy(btn,true,"Analyze ho raha hai…"); $("scanResult").hidden = false; $("scanResult").textContent = "AI response ka intezar karein…";
  try { $("scanResult").textContent = await askGemini(question,{image:selectedImage}); }
  catch(err) { $("scanResult").textContent = "Error: " + err.message; }
  finally { setBusy(btn,false); }
});

// Memory CRUD
function renderMemories() {
  const list = $("memoryList"); list.innerHTML = ""; const memories = readStore(STORAGE.memories, []);
  if (!memories.length) { list.innerHTML = '<p class="tiny-note">Abhi koi yaad save nahi hai.</p>'; return; }
  memories.slice().reverse().forEach(item => {
    const card = makeEntry(item.text, item.time, "Yaad", () => {
      if (confirm("Is yaad ko delete kar dein?")) { writeStore(STORAGE.memories, memories.filter(x=>x.id!==item.id)); renderMemories(); }
    }); list.append(card);
  });
}
function makeEntry(text, time, title, onDelete) {
  const card = document.createElement("article"); card.className = "entry-card";
  const h = document.createElement("h3"); h.textContent = title || "Note";
  const p = document.createElement("p"); p.textContent = text;
  const meta = document.createElement("div"); meta.className = "entry-meta"; meta.textContent = new Date(time).toLocaleString();
  const actions = document.createElement("div"); actions.className = "entry-actions";
  const del = document.createElement("button"); del.textContent = "Delete"; del.addEventListener("click", onDelete);
  actions.append(del); card.append(h,p,meta,actions); return card;
}
$("saveMemoryBtn").addEventListener("click", () => {
  const text = $("memoryInput").value.trim(); if (!text) { toast("Pehle yaad likhein."); return; }
  const list = readStore(STORAGE.memories, []); list.push({id:crypto.randomUUID?.() || String(Date.now()),text,time:Date.now()});
  writeStore(STORAGE.memories,list); $("memoryInput").value = ""; renderMemories(); toast("Yaad save ho gayi.");
});
$("exportMemoryBtn").addEventListener("click", () => downloadJSON("sovit-ai-memories.json",readStore(STORAGE.memories,[])));

// Journal CRUD
function renderJournal() {
  const list = $("journalList"); list.innerHTML = ""; const entries = readStore(STORAGE.journal, []);
  if (!entries.length) { list.innerHTML = '<p class="tiny-note">Journal abhi khaali hai.</p>'; return; }
  entries.slice().reverse().forEach(item => {
    const card = makeEntry(item.text,item.time,item.title || "Journal entry",() => {
      if (confirm("Journal entry delete kar dein?")) { writeStore(STORAGE.journal,entries.filter(x=>x.id!==item.id)); renderJournal(); }
    }); list.append(card);
  });
}
$("saveJournalBtn").addEventListener("click", () => {
  const text = $("journalText").value.trim(); if (!text) { toast("Journal mein kuch likhein."); return; }
  const entries = readStore(STORAGE.journal,[]); entries.push({id:crypto.randomUUID?.() || String(Date.now()),title:$("journalTitle").value.trim(),text,time:Date.now()});
  writeStore(STORAGE.journal,entries); $("journalTitle").value=""; $("journalText").value=""; renderJournal(); toast("Journal save ho gaya.");
});

// Study helper
$("studyAskBtn").addEventListener("click", async () => {
  const q = $("studyQuestion").value.trim(); if (!q) { toast("Question ya topic likhein."); return; }
  const prompt = `You are a patient tutor. Level: ${$("studyLevel").value}. Subject: ${$("studySubject").value}. Explain step by step in simple Hindi, include an example, and end with a short recap. Student question: ${q}`;
  const btn = $("studyAskBtn"); setBusy(btn,true,"Samjha raha hoon…"); $("studyAnswer").hidden=false; $("studyAnswer").textContent="AI response loading…";
  try { $("studyAnswer").textContent = await askGemini(prompt); }
  catch(err) { $("studyAnswer").textContent = "Error: " + err.message; }
  finally { setBusy(btn,false); }
});

// Mood
document.querySelectorAll("[data-mood]").forEach(btn => btn.addEventListener("click", () => {
  selectedMood = btn.dataset.mood; document.querySelectorAll("[data-mood]").forEach(b=>b.style.outline = b===btn ? "3px solid #58aaff" : "none");
}));
function renderMoods() {
  const list=$("moodHistory"); list.innerHTML=""; const moods=readStore(STORAGE.moods,[]);
  if (!moods.length) { list.innerHTML='<p class="tiny-note">Abhi mood log nahi hai.</p>'; return; }
  moods.slice().reverse().slice(0,12).forEach(m=>list.append(makeEntry(m.note || "Koi note nahi",m.time,m.mood,()=>{writeStore(STORAGE.moods,moods.filter(x=>x.id!==m.id));renderMoods();})));
}
$("saveMoodBtn").addEventListener("click", () => {
  if (!selectedMood) { toast("Ek mood choose karein."); return; }
  const moods=readStore(STORAGE.moods,[]); moods.push({id:crypto.randomUUID?.()||String(Date.now()),mood:selectedMood,note:$("moodNote").value.trim(),time:Date.now()});
  writeStore(STORAGE.moods,moods); $("moodSummary").textContent=selectedMood; $("moodNote").value=""; renderMoods(); toast("Mood save ho gaya.");
});
$("saveGoalBtn").addEventListener("click", () => {
  const goal=$("todayGoal").value.trim(); writeStore(STORAGE.goal,goal); $("savedGoal").textContent=goal ? "Aaj ka goal: " + goal : "Goal clear kar diya."; toast("Goal save ho gaya.");
});

// Weather adapter: endpoint template must be supplied by user. Provider response shape may differ.
$("weatherBtn").addEventListener("click", async () => {
  const city=$("weatherCity").value.trim(); if(!city){toast("City name likhein.");return;}
  if(!settings.weatherEndpoint){toast("Settings mein Weather endpoint configure karein.");navigate("settings");return;}
  const url=settings.weatherEndpoint.replaceAll("{city}",encodeURIComponent(city)).replaceAll("{key}",encodeURIComponent(settings.weatherKey));
  const btn=$("weatherBtn");setBusy(btn,true,"Check ho raha hai…");$("weatherResult").hidden=false;
  try {
    const res=await fetch(url); const data=await res.json(); if(!res.ok)throw new Error(data.message||"Weather request fail");
    $("weatherResult").textContent=JSON.stringify(data,null,2);
    const temp=data?.main?.temp ?? data?.current?.temp_c ?? data?.temperature;
    const desc=data?.weather?.[0]?.description ?? data?.current?.condition?.text ?? data?.description;
    if(temp!==undefined)$("weatherTemp").textContent=Math.round(Number(temp))+"°";
    if(desc)$("weatherDesc").textContent=String(desc);
    $("weatherExtra").textContent=city;
  }catch(err){$("weatherResult").textContent="Weather error: "+err.message+"\nProvider ke endpoint aur response format ko check karein.";}
  finally{setBusy(btn,false);}
});

// Data export / wipe
function downloadJSON(filename,data) {
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download=filename; a.click(); URL.revokeObjectURL(url);
}
$("exportAllBtn").addEventListener("click", () => {
  downloadJSON("sovit-ai-backup.json",{
    exportedAt:new Date().toISOString(),
    memories:readStore(STORAGE.memories,[]),journal:readStore(STORAGE.journal,[]),
    moods:readStore(STORAGE.moods,[]),chat:readStore(STORAGE.chat,[]),
    goal:readStore(STORAGE.goal,""),settings:{...getSettings(),apiKey:"",voiceApiKey:"",weatherKey:""}
  });
});
$("clearDataBtn").addEventListener("click", () => {
  if(!confirm("Is browser se chat, memories, journal, moods aur goal permanently clear kar dein? Settings/API keys bhi remove karni hain?"))return;
  Object.values(STORAGE).forEach(key=>localStorage.removeItem(key)); settings=getSettings(); fillSettings(); $("chatMessages").innerHTML="";
  addMessage("assistant","Local data clear ho gaya. Nayi shuruaat kar sakte hain.",false); renderMemories();renderJournal();renderMoods();initDate();toast("Local data clear ho gaya.");
});

// Music tile is a shortcut to chat with a useful music prompt; actual playback stays in the device's music apps.
document.querySelectorAll(".quick-card").forEach(btn => {
  if (btn.textContent.includes("Gaane")) btn.addEventListener("click", () => {
    navigate("chat"); $("chatInput").value="Mere mood ke hisaab se gaane ya music genres suggest karo."; $("chatInput").focus();
  });
});
$("notice").hidden=true;
fillSettings(); initDate(); renderChatHistory();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
