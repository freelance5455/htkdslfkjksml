// ============================================================
// LECTURA — script.js (v28)
// ------------------------------------------------------------
// Nouveautés v28 :
//   - Description interactive dans la bibliothèque
//     (même système que le livre : clic mot par mot / phrase par phrase)
//   - Mode Phonétique : clic sur chaque mot → phonétique
//   - Mode Traduction : clic sur chaque phrase → traduction
//   - Reset : tout effacer
//   - Système 100% anglais
// ============================================================

// ---------- UTILS ----------
function getParam(name) {
    return new URLSearchParams(window.location.search).get(name);
}

async function loadJSON(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`Cannot load ${path}`);
    return res.json();
}

function tokenize(text) {
    return text.match(/[a-zA-ZÀ-ÿ0-9]+(?:['’‘\-][a-zA-ZÀ-ÿ0-9]+)*|\.\.\.|[.,;:!?…«»""''—–()“”]/g) || [];
}

function parsePhonetics(phoneticStr) {
    return phoneticStr.match(/\/[^/]*\//g) || [];
}

function isSingleTranslationLine(text) {
    return /^(INT|EXT)\./i.test(text.trim());
}

function buildSequence(tokens) {
    const sequence = [];
    let currentSegment = [];

    tokens.forEach(tok => {
        if (tok === '«' || tok === '»' || tok === "'" || tok === '’' || tok === '‘') {
            if (currentSegment.length > 0) {
                sequence.push({ type: 'segment', tokens: currentSegment });
                currentSegment = [];
            }
            sequence.push({ type: 'quote', text: tok });
        } else {
            currentSegment.push(tok);
            if (/^[.:!?]$/.test(tok)) {
                sequence.push({ type: 'segment', tokens: currentSegment });
                currentSegment = [];
            }
        }
    });

    if (currentSegment.length > 0) {
        sequence.push({ type: 'segment', tokens: currentSegment });
    }

    return sequence;
}

// ---------- BUILD INTERACTIVE ELEMENT (BOOK OR DESCRIPTION) ----------
function buildInteractiveElement(text, phonetic, translation, options = {}) {
    const {
        tag = 'p',
        className = 'reading-paragraph',
        isSingleTranslation = isSingleTranslationLine(text),
        dataset = {},
    } = options;

    const p = document.createElement(tag);
    p.className = className;

    // Appliquer les datasets
    Object.entries(dataset).forEach(([key, value]) => {
        p.dataset[key] = value;
    });

    const tokens = tokenize(text);
    const allPhonetics = parsePhonetics(phonetic);

    let sequence;
    let translations;

    if (isSingleTranslation) {
        const segmentsOnly = [];
        let currentSegment = [];

        tokens.forEach(tok => {
            if (tok === '«' || tok === '»' || tok === "'" || tok === '’' || tok === '‘') {
                if (currentSegment.length > 0) {
                    segmentsOnly.push({ type: 'segment', tokens: currentSegment });
                    currentSegment = [];
                }
                segmentsOnly.push({ type: 'quote', text: tok });
            } else {
                currentSegment.push(tok);
            }
        });
        if (currentSegment.length > 0) {
            segmentsOnly.push({ type: 'segment', tokens: currentSegment });
        }

        const allSegmentTokens = [];
        segmentsOnly.forEach(item => {
            if (item.type === 'segment') {
                allSegmentTokens.push(...item.tokens);
            }
        });

        sequence = [
            { type: 'segment', tokens: allSegmentTokens }
        ];
        translations = [translation.trim()];
    } else {
        sequence = buildSequence(tokens);
        translations = translation.split('||').map(t => t.trim());
    }

    let phoneticIndex = 0;
    let translationIndex = 0;

    sequence.forEach(item => {
        if (item.type === 'quote') {
            const spanQuote = document.createElement('span');
            spanQuote.className = 'punct quote';
            spanQuote.textContent = item.text;
            p.appendChild(spanQuote);

            if (item.text === '«' || item.text === "'" || item.text === '‘') {
                p.appendChild(document.createTextNode(' '));
            }
            return;
        }

        const spanSentence = document.createElement('span');
        spanSentence.className = 'sentence';
        spanSentence.dataset.translation = translations[translationIndex] || '';
        translationIndex++;

        item.tokens.forEach((token, tIdx) => {
            const isPunct = /^[.,;:!?…«»""''—–()“”]$/.test(token) || token === '...';

            if (isPunct) {
                const spanPunct = document.createElement('span');
                spanPunct.className = 'punct';
                spanPunct.textContent = token;
                spanSentence.appendChild(spanPunct);
            } else {
                const spanWord = document.createElement('span');
                spanWord.className = 'word';
                spanWord.dataset.phonetic = allPhonetics[phoneticIndex] || '';
                spanWord.textContent = token;
                spanSentence.appendChild(spanWord);
                phoneticIndex++;
            }

            if (tIdx < item.tokens.length - 1) {
                const nextToken = item.tokens[tIdx + 1];
                const isNextClosing = /^[.,;:!?…»)]$/.test(nextToken);
                if (!isNextClosing) {
                    spanSentence.appendChild(document.createTextNode(' '));
                }
            }
        });

        p.appendChild(spanSentence);
        p.appendChild(document.createTextNode(' '));
    });

    if (p.lastChild && p.lastChild.nodeType === Node.TEXT_NODE) {
        p.removeChild(p.lastChild);
    }

    return p;
}

// ---------- DESCRIPTION INTERACTIVE (LIBRARY) ----------
function buildInteractiveDescription(book) {
    return buildInteractiveElement(
        book.description || '',
        book.descriptionPhonetic || '',
        book.descriptionTranslation || book.description || '',
        {
            tag: 'p',
            className: 'book-desc',
            isSingleTranslation: false,
            dataset: { book: book.id }
        }
    );
}

// ---------- LISTENERS (DESCRIPTION) ----------
function attachDescriptionListeners(desc) {
    // Words
    desc.querySelectorAll('.word').forEach(w => {
        if (!w.dataset.original) {
            w.dataset.original = w.textContent;
        }
        w.removeEventListener('click', onDescWordClick);
        w.addEventListener('click', onDescWordClick);
    });

    // Sentences
    desc.querySelectorAll('.sentence').forEach(s => {
        s.removeEventListener('click', onDescSentenceClick);
        s.addEventListener('click', onDescSentenceClick);
    });
}

function onDescWordClick(e) {
    const el = e.currentTarget;
    const desc = el.closest('.book-desc');

    if (!desc || !desc.classList.contains('mode-phonetic')) return;

    e.stopPropagation();

    if (el.classList.contains('pt-active')) {
        el.textContent = el.dataset.original;
        el.classList.remove('pt-active');
    } else {
        el.textContent = el.dataset.phonetic || el.dataset.original;
        el.classList.add('pt-active');
    }
}

function onDescSentenceClick(e) {
    const el = e.currentTarget;
    const desc = el.closest('.book-desc');

    if (!desc || !desc.classList.contains('mode-translation')) return;

    e.stopPropagation();

    if (el.classList.contains('pt-active')) {
        el.innerHTML = el.dataset.originalHtml;
        // Réattacher les listeners aux mots restaurés
        el.querySelectorAll('.word').forEach(w => {
            if (!w.dataset.original) {
                w.dataset.original = w.textContent;
            }
            w.removeEventListener('click', onDescWordClick);
            w.addEventListener('click', onDescWordClick);
        });
        el.classList.remove('pt-active');
    } else {
        if (!el.dataset.originalHtml) {
            el.dataset.originalHtml = el.innerHTML;
        }
        el.innerHTML = `<span class="sentence-translation">${el.dataset.translation}</span>`;
        el.classList.add('pt-active');
    }
}

// ---------- LIBRARY PAGE ----------
async function initLibrary() {
    const grid = document.getElementById('book-grid');
    if (!grid) return;

    try {
        const config = await loadJSON('config.json');
        grid.innerHTML = '';

        config.books.forEach((book, index) => {
            const levelKey = `lectura_level_${book.id}`;
            const savedLevel = localStorage.getItem(levelKey);
            const activeLevel = savedLevel || null;

            let progress = null;
            if (activeLevel) {
                const progressKey = `lectura_progress_${book.id}_${activeLevel}`;
                progress = JSON.parse(localStorage.getItem(progressKey) || 'null');
            }

            let link = '#';
            let progressText = '';

            if (activeLevel) {
                link = `lecture.html?book=${book.id}&level=${activeLevel}&chapter=1`;
                if (progress) {
                    link = `lecture.html?book=${book.id}&level=${activeLevel}&chapter=${progress.chapter}&page=${progress.page}`;
                    progressText = `<p class="book-progress">📖 Resume: Chapter ${progress.chapter} · Page ${progress.page}</p>`;
                }
            }

            const card = document.createElement('div');
            card.className = 'book-card';

            const coverClass = `cover-${(index % 3) + 1}`;

            const levelButtons = book.levels.map(level => `
                <button class="level-btn ${level === activeLevel ? 'active' : ''}"
                        data-book="${book.id}"
                        data-level="${level}">
                    ${level}
                </button>
            `).join('');

            const levelBadge = activeLevel
                ? `<span class="book-level-badge">${activeLevel}</span>`
                : '';

            const startBtn = activeLevel
                ? `<a class="book-start-btn" href="${link}">📖 Start reading</a>`
                : `<span class="book-start-btn disabled">Choose a level to start</span>`;

            const descBtns = `
                <div class="desc-mode-bar">
                    <button class="desc-mode-btn" data-mode="phonetic" data-book="${book.id}">🔊 Phonetic</button>
                    <button class="desc-mode-btn" data-mode="translation" data-book="${book.id}">📖 Translation</button>
                    <button class="desc-mode-btn desc-mode-reset" data-mode="reset" data-book="${book.id}">✕</button>
                </div>
            `;

            card.innerHTML = `
                <div class="book-cover ${coverClass}">${book.cover}</div>
                <div class="book-info">
                    <div class="book-title-row">
                        <h2>${book.title}</h2>
                        ${levelBadge}
                    </div>
                    <button class="level-toggle" data-book="${book.id}">
                        <span class="level-toggle-text">Choose a level</span>
                        <span class="level-toggle-arrow">▾</span>
                    </button>
                    <div class="level-selector" data-book="${book.id}">
                        ${levelButtons}
                    </div>
                    <div class="book-desc-wrapper" data-book="${book.id}"></div>
                    ${descBtns}
                    ${startBtn}
                    ${progressText}
                </div>
            `;

            grid.appendChild(card);

            // ----- Construire la description interactive -----
            const wrapper = card.querySelector(`.book-desc-wrapper[data-book="${book.id}"]`);
            const descElement = buildInteractiveDescription(book);
            wrapper.appendChild(descElement);

            // ----- Attacher les listeners -----
            attachDescriptionListeners(descElement);
        });

        // ----- LEVEL TOGGLE -----
        document.querySelectorAll('.level-toggle').forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                const bookId = toggle.dataset.book;
                const card = toggle.closest('.book-card');
                const selector = card.querySelector(`.level-selector[data-book="${bookId}"]`);

                toggle.classList.toggle('open');
                selector.classList.toggle('open');
            });
        });

        // ----- LEVEL CHOICE -----
        document.querySelectorAll('.level-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                const bookId = btn.dataset.book;
                const level = btn.dataset.level;

                localStorage.setItem(`lectura_level_${bookId}`, level);

                const card = btn.closest('.book-card');
                card.querySelectorAll('.level-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const toggle = card.querySelector('.level-toggle');
                const selector = card.querySelector('.level-selector');
                if (toggle && selector) {
                    toggle.classList.remove('open');
                    selector.classList.remove('open');
                }

                const titleRow = card.querySelector('.book-title-row');
                let badge = titleRow.querySelector('.book-level-badge');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'book-level-badge';
                    titleRow.appendChild(badge);
                }
                badge.textContent = level;

                const startBtn = card.querySelector('.book-start-btn');
                const progressKey = `lectura_progress_${bookId}_${level}`;
                const progress = JSON.parse(localStorage.getItem(progressKey) || 'null');

                if (startBtn) {
                    startBtn.classList.remove('disabled');
                    if (progress) {
                        startBtn.href = `lecture.html?book=${bookId}&level=${level}&chapter=${progress.chapter}&page=${progress.page}`;
                    } else {
                        startBtn.href = `lecture.html?book=${bookId}&level=${level}&chapter=1`;
                    }
                    startBtn.textContent = '📖 Start reading';
                }

                const progressEl = card.querySelector('.book-progress');
                if (progressEl) {
                    if (progress) {
                        progressEl.textContent = `📖 Resume: Chapter ${progress.chapter} · Page ${progress.page}`;
                    } else {
                        progressEl.remove();
                    }
                }
            });
        });

        // ----- DESCRIPTION MODE (PHONETIC / TRANSLATION / RESET) -----
        document.querySelectorAll('.desc-mode-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                const bookId = btn.dataset.book;
                const mode = btn.dataset.mode;
                const card = btn.closest('.book-card');
                const desc = card.querySelector(`.book-desc-wrapper[data-book="${bookId}"] .book-desc`);

                if (!desc) return;

                if (mode === 'reset') {
                    // Reset : tout effacer
                    desc.querySelectorAll('.word.pt-active').forEach(w => {
                        w.textContent = w.dataset.original;
                        w.classList.remove('pt-active');
                    });
                    desc.querySelectorAll('.sentence.pt-active').forEach(s => {
                        if (s.dataset.originalHtml) {
                            s.innerHTML = s.dataset.originalHtml;
                        }
                        s.classList.remove('pt-active');
                    });
                    attachDescriptionListeners(desc);

                    card.querySelectorAll('.desc-mode-btn').forEach(b => b.classList.remove('active'));
                    desc.classList.remove('mode-phonetic', 'mode-translation');
                } else if (mode === 'phonetic') {
                    const isActive = desc.classList.toggle('mode-phonetic');
                    desc.classList.remove('mode-translation');
                    card.querySelectorAll('.desc-mode-btn[data-mode="translation"]').forEach(b => b.classList.remove('active'));

                    if (isActive) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                        desc.querySelectorAll('.word.pt-active').forEach(w => {
                            w.textContent = w.dataset.original;
                            w.classList.remove('pt-active');
                        });
                    }
                } else if (mode === 'translation') {
                    const isActive = desc.classList.toggle('mode-translation');
                    desc.classList.remove('mode-phonetic');
                    card.querySelectorAll('.desc-mode-btn[data-mode="phonetic"]').forEach(b => b.classList.remove('active'));

                    if (isActive) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                        desc.querySelectorAll('.sentence.pt-active').forEach(s => {
                            if (s.dataset.originalHtml) {
                                s.innerHTML = s.dataset.originalHtml;
                            }
                            s.classList.remove('pt-active');
                        });
                        attachDescriptionListeners(desc);
                    }
                }
            });
        });
    } catch (e) {
        grid.innerHTML = `<p>Loading error: ${e.message}</p>`;
    }
}

// ---------- READING PAGE ----------
async function initReading() {
    const container = document.getElementById('reading-container');
    if (!container) return;

    const bookId = getParam('book');
    const level = getParam('level') || 'A2';
    const chapterId = parseInt(getParam('chapter') || '1', 10);
    const pageParam = parseInt(getParam('page') || '1', 10);

    if (!bookId) {
        container.innerHTML = '<p class="loading-text">No book selected.</p>';
        return;
    }

    try {
        const config = await loadJSON('config.json');
        const bookMeta = config.books.find(b => b.id === bookId);
        if (!bookMeta) throw new Error('Book not found');

        const folderName = bookMeta.folder.split('/').pop();
        const filePath = `${bookMeta.folder}/${folderName}-${level}.json`;

        const book = await loadJSON(filePath);
        const chapter = book.chapters.find(c => c.id === chapterId);
        if (!chapter) throw new Error('Chapter not found');

        document.getElementById('reading-title').textContent = book.title;
        document.getElementById('reading-level').textContent = `Level ${level}`;

        renderChapter(chapter, book, pageParam);
        renderTOC(book, chapter);
        renderChapterNav(book, chapter);

        document.addEventListener('keydown', (e) => {
            const c = document.getElementById('reading-container');
            if (!c) return;
            if (e.key === 'ArrowRight') {
                e.preventDefault();
                c.scrollBy({ left: c.clientWidth, behavior: 'smooth' });
            }
            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                c.scrollBy({ left: -c.clientWidth, behavior: 'smooth' });
            }
        });
    } catch (e) {
        container.innerHTML = `<p class="loading-text">Error: ${e.message}</p>`;
    }
}

// ---------- CHAPTER RENDERING ----------
function renderChapter(chapter, book, pageParam = 1) {
    const container = document.getElementById('reading-container');
    container.innerHTML = '';

    chapter.pages.forEach((pageData, pIdx) => {
        const pageEl = document.createElement('section');
        pageEl.className = 'reading-page';

        const inner = document.createElement('div');
        inner.className = 'reading-page-inner';

        if (pIdx === 0) {
            const h1 = document.createElement('h1');
            h1.className = 'chapter-title-large';
            h1.textContent = `Chapter ${chapter.id}`;
            inner.appendChild(h1);

            const sub = document.createElement('p');
            sub.className = 'chapter-subtitle';
            sub.textContent = chapter.title;
            inner.appendChild(sub);
        } else {
            const h = document.createElement('div');
            h.className = 'chapter-title-small';
            h.textContent = `Chapter ${chapter.id} · ${chapter.title}`;
            inner.appendChild(h);
        }

        pageData.paragraphs.forEach(par => {
            const p = buildInteractiveElement(par.text, par.phonetic, par.translation, {
                tag: 'p',
                className: 'reading-paragraph',
                isSingleTranslation: isSingleTranslationLine(par.text),
            });
            inner.appendChild(p);
        });

        pageEl.appendChild(inner);
        container.appendChild(pageEl);
    });

    initPT();
    initPageTracking(chapter.pages.length, book.id, chapter.id);

    if (pageParam > 1) {
        requestAnimationFrame(() => {
            container.scrollTo({
                left: (pageParam - 1) * container.clientWidth,
                behavior: 'auto'
            });
        });
    }
}

// ---------- PAGE TRACKING ----------
function initPageTracking(totalPages, bookId, chapterId) {
    const container = document.getElementById('reading-container');
    const indicator = document.getElementById('page-indicator');
    if (!container || !indicator) return;

    function updateIndicator() {
        const scrollLeft = container.scrollLeft;
        const width = container.clientWidth;
        const current = Math.round(scrollLeft / width) + 1;
        indicator.textContent = `${current} / ${totalPages}`;
        indicator.style.display = totalPages > 1 ? 'block' : 'none';

        saveProgress(bookId, chapterId, current);
    }

    container.addEventListener('scroll', () => {
        if (container._scrollTimer) cancelAnimationFrame(container._scrollTimer);
        container._scrollTimer = requestAnimationFrame(updateIndicator);
    });

    window.addEventListener('resize', () => {
        setTimeout(updateIndicator, 100);
    });

    updateIndicator();
}

function saveProgress(bookId, chapterId, page) {
    const level = getParam('level') || 'A2';
    const key = `lectura_progress_${bookId}_${level}`;
    const progress = {
        chapter: parseInt(chapterId, 10),
        page: page
    };
    localStorage.setItem(key, JSON.stringify(progress));
}

// ---------- TABLE OF CONTENTS ----------
function renderTOC(book, currentChapter) {
    const level = getParam('level') || 'A2';

    document.getElementById('toc-cover').textContent = book.cover;
    document.getElementById('toc-book-title').textContent = book.title;
    document.getElementById('toc-book-meta').textContent = `Level ${level} · ${book.chapters.length} chapters`;

    const list = document.getElementById('toc-list');
    list.innerHTML = '';

    book.chapters.forEach(ch => {
        const li = document.createElement('li');
        li.className = 'toc-item' + (ch.id === currentChapter.id ? ' toc-active' : '');

        const a = document.createElement('a');
        a.href = `lecture.html?book=${book.id}&level=${level}&chapter=${ch.id}&page=1`;
        a.innerHTML = `
            <span class="toc-num">${ch.id}</span>
            <span class="toc-label">${ch.title}</span>
            <span class="toc-time">${ch.pages.length}p</span>
        `;

        const toggle = document.createElement('button');
        toggle.className = 'toc-page-toggle';
        toggle.innerHTML = '▸';
        toggle.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const grid = li.querySelector('.toc-page-grid');
            if (grid) {
                grid.classList.toggle('open');
                toggle.classList.toggle('open');
            }
        });

        const pageGrid = document.createElement('div');
        pageGrid.className = 'toc-page-grid';
        ch.pages.forEach((_, pIdx) => {
            const pageBtn = document.createElement('a');
            pageBtn.className = 'toc-page-btn';
            pageBtn.href = `lecture.html?book=${book.id}&level=${level}&chapter=${ch.id}&page=${pIdx + 1}`;
            pageBtn.textContent = pIdx + 1;
            pageGrid.appendChild(pageBtn);
        });

        li.appendChild(a);
        li.appendChild(toggle);
        li.appendChild(pageGrid);
        list.appendChild(li);
    });
}

function renderChapterNav(book, currentChapter) {
    const level = getParam('level') || 'A2';

    const footerInner = document.getElementById('chapter-footer-inner');
    footerInner.innerHTML = '';

    const prev = book.chapters.find(c => c.id === currentChapter.id - 1);
    const next = book.chapters.find(c => c.id === currentChapter.id + 1);

    if (prev) {
        const a = document.createElement('a');
        a.className = 'footer-btn';
        a.href = `lecture.html?book=${book.id}&level=${level}&chapter=${prev.id}&page=1`;
        a.innerHTML = `← <span>${prev.title}</span>`;
        footerInner.appendChild(a);
    } else {
        const span = document.createElement('span');
        span.className = 'footer-btn disabled';
        span.innerHTML = `← <span>—</span>`;
        footerInner.appendChild(span);
    }

    if (next) {
        const a = document.createElement('a');
        a.className = 'footer-btn';
        a.href = `lecture.html?book=${book.id}&level=${level}&chapter=${next.id}&page=1`;
        a.innerHTML = `<span>${next.title}</span> →`;
        footerInner.appendChild(a);
    } else {
        const span = document.createElement('span');
        span.className = 'footer-btn disabled';
        span.innerHTML = `<span>—</span> →`;
        footerInner.appendChild(span);
    }
}

// ---------- PT MODULE (READING) ----------
let ptMode = 'neutral';

function initPT() {
    document.querySelectorAll('.pt-mode-btn').forEach(btn => {
        btn.addEventListener('click', () => setMode(btn.dataset.mode));
    });

    document.querySelectorAll('.reading-paragraph .word').forEach(el => {
        if (!el.dataset.original) {
            el.dataset.original = el.textContent;
        }
        el.removeEventListener('click', onWordClick);
        el.addEventListener('click', onWordClick);
    });

    document.querySelectorAll('.reading-paragraph .sentence').forEach(el => {
        el.removeEventListener('click', onSentenceClick);
        el.addEventListener('click', onSentenceClick);
    });

    initTOC();
}

function onWordClick(e) {
    if (ptMode !== 'phonetic') return;
    e.stopPropagation();
    const el = e.currentTarget;
    if (el.classList.contains('pt-active')) {
        el.textContent = el.dataset.original;
        el.classList.remove('pt-active');
    } else {
        el.textContent = el.dataset.phonetic || el.dataset.original;
        el.classList.add('pt-active');
    }
}

function onSentenceClick(e) {
    if (ptMode !== 'translation') return;
    e.stopPropagation();
    const el = e.currentTarget;

    if (el.classList.contains('pt-active')) {
        el.innerHTML = el.dataset.originalHtml;
        el.querySelectorAll('.word').forEach(w => {
            if (!w.dataset.original) {
                w.dataset.original = w.textContent;
            }
            w.removeEventListener('click', onWordClick);
            w.addEventListener('click', onWordClick);
        });
        el.classList.remove('pt-active');
    } else {
        if (!el.dataset.originalHtml) {
            el.dataset.originalHtml = el.innerHTML;
        }
        el.innerHTML = `<span class="sentence-translation">${el.dataset.translation}</span>`;
        el.classList.add('pt-active');
    }
}

function setMode(mode) {
    if (mode === 'reset') {
        ptMode = 'neutral';
        resetAllActive();
    } else {
        ptMode = (ptMode === mode) ? 'neutral' : mode;
        resetAllActive();
    }

    document.querySelectorAll('.pt-mode-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.mode === ptMode);
    });

    document.body.classList.toggle('mode-phonetic', ptMode === 'phonetic');
    document.body.classList.toggle('mode-translation', ptMode === 'translation');
}

function resetAllActive() {
    document.querySelectorAll('.reading-paragraph .word.pt-active').forEach(el => {
        el.textContent = el.dataset.original;
        el.classList.remove('pt-active');
    });

    document.querySelectorAll('.reading-paragraph .sentence.pt-active').forEach(el => {
        if (el.dataset.originalHtml) {
            el.innerHTML = el.dataset.originalHtml;
            el.querySelectorAll('.word').forEach(w => {
                if (!w.dataset.original) {
                    w.dataset.original = w.textContent;
                }
                w.removeEventListener('click', onWordClick);
                w.addEventListener('click', onWordClick);
            });
        }
        el.classList.remove('pt-active');
    });
}

// ---------- TOC PANEL ----------
function initTOC() {
    const menuBtn = document.getElementById('menu-btn');
    const tocPanel = document.getElementById('toc-panel');
    const tocOverlay = document.getElementById('toc-overlay');
    const tocClose = document.getElementById('toc-close');
    const tocToggle = document.getElementById('toc-toggle-chapters');
    const tocList = document.getElementById('toc-list');

    if (!menuBtn) return;

    if (tocToggle && tocList) {
        tocToggle.addEventListener('click', () => {
            const isOpen = tocToggle.classList.contains('open');
            tocToggle.classList.toggle('open', !isOpen);
            tocList.classList.toggle('open', !isOpen);
        });
    }

    function openToc() {
        tocPanel.hidden = false;
        tocOverlay.hidden = false;
        requestAnimationFrame(() => {
            tocPanel.classList.add('open');
            tocOverlay.classList.add('visible');
        });
    }

    function closeToc() {
        tocPanel.classList.remove('open');
        tocOverlay.classList.remove('visible');
        setTimeout(() => {
            tocPanel.hidden = true;
            tocOverlay.hidden = true;
        }, 250);
    }

    menuBtn.addEventListener('click', openToc);
    tocClose.addEventListener('click', closeToc);
    tocOverlay.addEventListener('click', closeToc);
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && !tocPanel.hidden) closeToc();
    });
}

// ---------- INIT ----------
document.addEventListener('DOMContentLoaded', () => {
    initLibrary();
    initReading();
});