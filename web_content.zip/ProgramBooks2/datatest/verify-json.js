// ============================================================
// VERIFY-JSON.JS — Vérificateur d'alignement pour Lectura
// Version v27 — Aligné sur script.js v28
//
// Nouveautés v27 :
//   - Vérification de la description interactive dans config.json
//   - Vérifie descriptionPhonetic (1 par mot)
//   - Vérifie descriptionTranslation (1 par segment)
//   - Vérification de la structure multi-niveaux
//   - Vérifie le champ "level" dans chaque fichier
//   - Vérifie la cohérence entre niveaux
//   - Vérifie ≥ 30 pages par niveau
//
// Usage :
//   node verify-json.js                          → scan du dossier courant
//   node verify-json.js chemin/vers/dossier      → scan du dossier indiqué
//   node verify-json.js data                     → scan du dossier data/
// ============================================================

const fs = require('fs');
const path = require('path');

// ---------- RÉPLIQUES EXACTES DU SCRIPT.JS v28 ----------

function tokenize(text) {
    return text.match(/[a-zA-ZÀ-ÿ0-9]+(?:['’‘\-][a-zA-ZÀ-ÿ0-9]+)*|\.\.\.|[.,;:!?…«»""''—–()“”]/g) || [];
}

function parsePhonetics(phoneticStr) {
    return phoneticStr.match(/\/[^/]*\//g) || [];
}

function isSingleTranslationLine(text) {
    return /^(INT|EXT)\./i.test(text.trim());
}

function isDecorativePunct(tok) {
    if (tok === '...') return true;
    return /^[.,;:!?…«»""''—–()“”]$/.test(tok);
}

function isQuote(tok) {
    return tok === '«' || tok === '»' || tok === "'" || tok === '’' || tok === '‘';
}

function isSegmentSeparator(tok) {
    return /^[.:!?]$/.test(tok);
}

function buildSequence(tokens) {
    const sequence = [];
    let currentSegment = [];

    tokens.forEach(tok => {
        if (isQuote(tok)) {
            if (currentSegment.length > 0) {
                sequence.push({ type: 'segment', tokens: currentSegment });
                currentSegment = [];
            }
            sequence.push({ type: 'quote', text: tok });
        } else {
            currentSegment.push(tok);
            if (isSegmentSeparator(tok)) {
                sequence.push({ type: 'segment', tokens: currentSegment });
                currentSegment = [];
            }
        }
    });

    if (currentSegment.length > 0) {
        sequence.push({ type: 'segment', tokens: currentSegment });
    }

    return sequence;
}

function countExpectedSegments(text) {
    if (isSingleTranslationLine(text)) return 1;
    const tokens = tokenize(text);
    const sequence = buildSequence(tokens);
    return sequence.filter(item => item.type === 'segment').length;
}

function countWordsToPronounce(text) {
    const tokens = tokenize(text);
    return tokens.filter(tok => !isDecorativePunct(tok) && !isQuote(tok)).length;
}

function countTranslations(translation) {
    if (!translation) return 0;
    return translation.split('||').length;
}

// ---------- RECHERCHE RÉCURSIVE ----------
function findDataFiles(rootDir) {
    const found = [];

    function walk(dir) {
        let entries;
        try {
            entries = fs.readdirSync(dir, { withFileTypes: true });
        } catch (e) {
            return;
        }

        for (const entry of entries) {
            if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;

            const fullPath = path.join(dir, entry.name);

            if (entry.isDirectory()) {
                walk(fullPath);
            } else if (entry.isFile() && /^data-.*\.json$/i.test(entry.name)) {
                found.push(fullPath);
            }
        }
    }

    walk(rootDir);
    return found.sort();
}

// ---------- EXTRACTION DU NIVEAU ----------
function extractLevelFromPath(filePath) {
    const match = path.basename(filePath).match(/-([A-C][12])\.json$/i);
    return match ? match[1].toUpperCase() : null;
}

// ---------- VÉRIFICATION D'UN FICHIER ----------
function verifyFile(filePath, rootDir) {
    const relativePath = path.relative(rootDir, filePath) || path.basename(filePath);

    console.log(`\n══════════════════════════════════════════`);
    console.log(`📂 ${relativePath}`);
    console.log(`══════════════════════════════════════════\n`);

    const raw = fs.readFileSync(filePath, 'utf-8');

    let data;
    try {
        data = JSON.parse(raw);
    } catch (e) {
        console.error(`❌ JSON INVALIDE : ${e.message}`);
        return { file: relativePath, errors: 1, paragraphs: 0, pages: 0, level: null, fatal: true };
    }

    console.log(`✅ JSON valide (parse OK)\n`);

    let totalParagraphs = 0;
    let totalPages = 0;
    let totalErrors = 0;
    const errors = [];

    // Vérification du champ "level"
    const levelFromPath = extractLevelFromPath(filePath);
    if (!data.level) {
        errors.push({
            location: 'En-tête',
            type: 'CHAMP LEVEL MANQUANT',
            detail: `Le champ "level" est obligatoire (attendu : ${levelFromPath || '?'})`,
        });
        totalErrors++;
    } else if (levelFromPath && data.level !== levelFromPath) {
        errors.push({
            location: 'En-tête',
            type: 'LEVEL INCOHÉRENT',
            detail: `Champ level="${data.level}" mais nom de fichier indique "${levelFromPath}"`,
        });
        totalErrors++;
    }

    if (!data.chapters || !Array.isArray(data.chapters)) {
        console.error(`❌ Pas de "chapters" valide`);
        return { file: relativePath, errors: 1, paragraphs: 0, pages: 0, level: data.level, fatal: true };
    }

    data.chapters.forEach((chapter) => {
        if (!chapter.pages || !Array.isArray(chapter.pages)) return;

        chapter.pages.forEach((page, pIdx) => {
            totalPages++;
            if (!page.paragraphs || !Array.isArray(page.paragraphs)) return;

            page.paragraphs.forEach((par, parIdx) => {
                totalParagraphs++;
                const location = `Ch.${chapter.id} · P.${pIdx + 1} · §${parIdx + 1}`;

                // PHONÉTIQUE
                const wordsToPronounce = countWordsToPronounce(par.text || '');
                const phonetics = parsePhonetics(par.phonetic || '');

                if (wordsToPronounce !== phonetics.length) {
                    errors.push({
                        location,
                        type: 'PHONÉTIQUE',
                        detail: `${wordsToPronounce} mots vs ${phonetics.length} phonétiques`,
                        text: (par.text || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // SEGMENTS
                const expectedSegments = countExpectedSegments(par.text || '');
                const actualTranslations = countTranslations(par.translation);

                if (expectedSegments !== actualTranslations) {
                    errors.push({
                        location,
                        type: isSingleTranslationLine(par.text || '') ? 'INT./EXT.' : 'SEGMENTS',
                        detail: `${expectedSegments} segments vs ${actualTranslations} traductions`,
                        text: (par.text || '').substring(0, 100),
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // TRADUCTION VIDE
                if ((par.translation || '').split('||').some(t => t.trim() === '')) {
                    errors.push({
                        location,
                        type: 'TRADUCTION VIDE',
                        detail: `Contient un || vide`,
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // GUILLEMETS DANS TRADUCTION
                if (/[«»]/.test(par.translation || '')) {
                    errors.push({
                        location,
                        type: 'GUILLEMETS DANS TRADUCTION',
                        detail: `La traduction ne doit PAS contenir « ou »`,
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // GUILLEMETS DOUBLES
                if ((par.translation || '').includes('"')) {
                    errors.push({
                        location,
                        type: 'GUILLEMETS DOUBLES',
                        detail: `Contient des " dans translation`,
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // UNDEFINED
                if ((par.translation || '').includes('undefined')) {
                    errors.push({
                        location,
                        type: 'UNDEFINED',
                        detail: `La traduction contient "undefined"`,
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // PHONÉTIQUE DANS TRADUCTION
                if (/\/[^/]+\//.test(par.translation || '')) {
                    errors.push({
                        location,
                        type: 'PHONÉTIQUE DANS TRADUCTION',
                        detail: `La traduction ne doit PAS contenir /.../`,
                        translation: (par.translation || '').substring(0, 100),
                    });
                    totalErrors++;
                }

                // PHONÉTIQUE ABSENTE
                if (!par.phonetic || par.phonetic.trim() === '') {
                    if (wordsToPronounce > 0) {
                        errors.push({
                            location,
                            type: 'PHONÉTIQUE ABSENTE',
                            detail: `${wordsToPronounce} mots mais aucun phonetic`,
                            text: (par.text || '').substring(0, 100),
                        });
                        totalErrors++;
                    }
                }

                // TRADUCTION ABSENTE
                if (!par.translation || par.translation.trim() === '') {
                    if (expectedSegments > 0) {
                        errors.push({
                            location,
                            type: 'TRADUCTION ABSENTE',
                            detail: `${expectedSegments} segments mais aucune traduction`,
                            text: (par.text || '').substring(0, 100),
                        });
                        totalErrors++;
                    }
                }
            });
        });
    });

    // Vérification ≥ 30 pages
    if (totalPages < 30) {
        errors.push({
            location: 'Statistiques',
            type: 'PAGES INSUFFISANTES',
            detail: `${totalPages} pages (minimum requis : 30)`,
        });
        totalErrors++;
    }

    // Rapport
    console.log(`📊 RAPPORT`);
    console.log(`─────────────────────────────────────────`);
    console.log(`Niveau                : ${data.level || '?'}`);
    console.log(`Paragraphes vérifiés  : ${totalParagraphs}`);
    console.log(`Pages vérifiées       : ${totalPages}`);
    console.log(`Erreurs détectées     : ${totalErrors}\n`);

    if (errors.length === 0) {
        console.log(`🎉 AUCUNE ERREUR — ${relativePath} est aligné.`);
        return { file: relativePath, errors: 0, paragraphs: totalParagraphs, pages: totalPages, level: data.level };
    }

    const byType = {};
    errors.forEach(e => {
        byType[e.type] = byType[e.type] || [];
        byType[e.type].push(e);
    });

    Object.entries(byType).forEach(([type, list]) => {
        console.log(`\n❌ ${type} (${list.length})`);
        console.log(`─────────────────────────────────────────`);
        list.slice(0, 30).forEach(e => {
            console.log(`  📍 ${e.location}`);
            console.log(`     ${e.detail}`);
            if (e.text) console.log(`     TEXT: "${e.text}"`);
            if (e.translation) console.log(`     TRAD: "${e.translation}"`);
            console.log('');
        });
        if (list.length > 30) {
            console.log(`  ... et ${list.length - 30} autres.\n`);
        }
    });

    return { file: relativePath, errors: totalErrors, paragraphs: totalParagraphs, pages: totalPages, level: data.level };
}

// ---------- VÉRIFICATION DE LA DESCRIPTION INTERACTIVE (config.json) ----------
function verifyConfigFile(configPath) {
    console.log(`\n\n══════════════════════════════════════════`);
    console.log(`📋 VÉRIFICATION DE LA DESCRIPTION INTERACTIVE`);
    console.log(`══════════════════════════════════════════\n`);

    let config;
    try {
        const raw = fs.readFileSync(configPath, 'utf-8');
        config = JSON.parse(raw);
    } catch (e) {
        console.error(`❌ Impossible de lire ${configPath} : ${e.message}`);
        return { errors: 1 };
    }

    if (!config.books || !Array.isArray(config.books)) {
        console.error(`❌ Pas de "books" valide dans config.json`);
        return { errors: 1 };
    }

    let totalErrors = 0;

    config.books.forEach(book => {
        const bookErrors = [];
        const bookId = book.id || '(sans id)';

        // Vérifier la description
        if (!book.description) {
            bookErrors.push({
                type: 'DESCRIPTION MANQUANTE',
                detail: `Le champ "description" est obligatoire`,
            });
        }

        // Vérifier la phonétique
        if (book.descriptionPhonetic) {
            const words = countWordsToPronounce(book.description || '');
            const phonetics = parsePhonetics(book.descriptionPhonetic);

            if (words !== phonetics.length) {
                bookErrors.push({
                    type: 'PHONÉTIQUE DESCRIPTION',
                    detail: `${words} mots vs ${phonetics.length} phonétiques`,
                });
            }

            // Interdire les || dans descriptionPhonetic
            if (book.descriptionPhonetic.includes('||')) {
                bookErrors.push({
                    type: 'INTERDIT || DANS PHONÉTIQUE',
                    detail: `descriptionPhonetic ne doit PAS contenir ||`,
                });
            }
        } else {
            bookErrors.push({
                type: 'descriptionPhonetic MANQUANT',
                detail: `Le champ "descriptionPhonetic" est obligatoire`,
            });
        }

        // Vérifier la traduction
        if (book.descriptionTranslation) {
            const segments = countExpectedSegments(book.description || '');
            const translations = countTranslations(book.descriptionTranslation);

            if (segments !== translations) {
                bookErrors.push({
                    type: 'TRADUCTION DESCRIPTION',
                    detail: `${segments} segments vs ${translations} traductions`,
                });
            }

            // Interdire les guillemets dans la traduction
            if (/[«»]/.test(book.descriptionTranslation)) {
                bookErrors.push({
                    type: 'GUILLEMETS DANS DESCRIPTION',
                    detail: `descriptionTranslation ne doit PAS contenir « ou »`,
                });
            }

            // Interdire les phonétiques dans la traduction
            if (/\/[^/]+\//.test(book.descriptionTranslation)) {
                bookErrors.push({
                    type: 'PHONÉTIQUE DANS DESCRIPTION',
                    detail: `descriptionTranslation ne doit PAS contenir /.../`,
                });
            }
        } else {
            bookErrors.push({
                type: 'descriptionTranslation MANQUANT',
                detail: `Le champ "descriptionTranslation" est obligatoire`,
            });
        }

        // Afficher les erreurs du livre
        if (bookErrors.length > 0) {
            console.log(`❌ ${bookId}`);
            bookErrors.forEach(e => {
                console.log(`   • ${e.type}: ${e.detail}`);
            });
            totalErrors += bookErrors.length;
        } else {
            console.log(`✅ ${bookId} — Description interactive OK`);
        }
    });

    console.log('');
    return { errors: totalErrors };
}

// ---------- VÉRIFICATION CROSS-LEVEL ----------
function verifyCrossLevel(files, rootDir) {
    const books = {};

    files.forEach(filePath => {
        const baseName = path.basename(filePath, '.json');
        const match = baseName.match(/^(data-.+)-[A-C][12]$/i);
        if (!match) return;

        const bookId = match[1];
        if (!books[bookId]) books[bookId] = [];
        books[bookId].push(filePath);
    });

    const multiLevelBooks = Object.entries(books).filter(([_, list]) => list.length > 1);

    if (multiLevelBooks.length === 0) return;

    console.log(`\n\n══════════════════════════════════════════`);
    console.log(`📚 VÉRIFICATION DE LA COHÉRENCE ENTRE NIVEAUX`);
    console.log(`══════════════════════════════════════════\n`);

    multiLevelBooks.forEach(([bookId, filePaths]) => {
        console.log(`\n📖 ${bookId} (${filePaths.length} niveaux)`);

        const levels = {};
        filePaths.forEach(fp => {
            try {
                const data = JSON.parse(fs.readFileSync(fp, 'utf-8'));
                const level = extractLevelFromPath(fp);
                if (level) levels[level] = data;
            } catch (e) {
                // Ignoré
            }
        });

        const levelNames = Object.keys(levels).sort();
        console.log(`   Niveaux trouvés : ${levelNames.join(', ')}`);

        const chapterCounts = levelNames.map(l => levels[l].chapters?.length || 0);
        const allSame = chapterCounts.every(c => c === chapterCounts[0]);

        if (allSame) {
            console.log(`   ✅ Nombre de chapitres identique : ${chapterCounts[0]}`);
        } else {
            console.log(`   ⚠️  Nombre de chapitres différents : ${chapterCounts.join(' / ')}`);
        }

        console.log('');
    });
}

// ---------- POINT D'ENTRÉE ----------
const args = process.argv.slice(2);
const targetDir = args.length > 0 ? path.resolve(args[0]) : process.cwd();

if (!fs.existsSync(targetDir)) {
    console.error(`\n❌ Dossier introuvable : ${targetDir}\n`);
    process.exit(1);
}

const stats = fs.statSync(targetDir);
if (!stats.isDirectory()) {
    console.error(`\n❌ Ce n'est pas un dossier : ${targetDir}\n`);
    process.exit(1);
}

console.log(`\n🔍 Recherche des fichiers "data-*.json" dans :`);
console.log(`   ${targetDir}\n`);

const files = findDataFiles(targetDir);

if (files.length === 0) {
    console.log(`⚠️  Aucun fichier "data-*.json" trouvé dans ce dossier.`);
    process.exit(0);
}

console.log(`✅ ${files.length} fichier(s) trouvé(s) :`);
files.forEach(f => console.log(`   • ${path.relative(targetDir, f)}`));
console.log('');

// Vérification de chaque fichier
const results = [];
files.forEach(f => {
    const res = verifyFile(f, targetDir);
    results.push(res);
});

// Vérification de la description interactive
const configPath = path.join(targetDir, '..', 'config.json');
let configResult = { errors: 0 };
if (fs.existsSync(configPath)) {
    configResult = verifyConfigFile(configPath);
} else {
    console.log(`\n⚠️  config.json introuvable à ${configPath} — Vérification de la description ignorée.\n`);
}

// Vérification cross-level
verifyCrossLevel(files, targetDir);

// Résumé global
console.log(`\n\n══════════════════════════════════════════`);
console.log(`📋 RÉSUMÉ GLOBAL`);
console.log(`══════════════════════════════════════════\n`);

let totalErr = 0;
let totalPar = 0;
let totalPages = 0;

results.forEach(r => {
    totalErr += r.errors;
    totalPar += r.paragraphs;
    totalPages += r.pages || 0;
    const icon = r.errors === 0 ? '✅' : (r.fatal ? '💥' : '❌');
    const level = r.level ? `[${r.level}]` : '[??]';
    console.log(`  ${icon}  ${level} ${r.file.padEnd(45)} ${r.errors} erreur(s) / ${r.paragraphs} paragraphe(s) / ${r.pages || 0} page(s)`);
});

console.log(`\n  📊 TOTAL : ${totalErr} erreur(s) sur ${totalPar} paragraphe(s) et ${totalPages} page(s) vérifié(s)`);
console.log(`  📋 Description interactive : ${configResult.errors} erreur(s)\n`);

if (totalErr === 0 && configResult.errors === 0) {
    console.log(`🎉 TOUS LES FICHIERS SONT ALIGNÉS.\n`);
} else {
    console.log(`⚠️  Corrige les erreurs ci-dessus avant utilisation.\n`);
    process.exit(1);
}