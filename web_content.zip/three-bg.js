// Three.js 3D Background Logic
let scene, camera, renderer, aiCore, particles;
let isThinking = false;

function init3D() {
    const container = document.getElementById('canvas-container');
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
    camera.position.z = 5;

    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    // Outer Brain
    aiCore = new THREE.Mesh(
        new THREE.IcosahedronGeometry(1.5, 1),
        new THREE.MeshBasicMaterial({ color: 0x00e5ff, wireframe: true, transparent: true, opacity: 0.25 })
    );
    scene.add(aiCore);

    // Inner Core
    const innerCore = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.8, 2),
        new THREE.MeshBasicMaterial({ color: 0x0088aa, wireframe: true })
    );
    aiCore.add(innerCore);

    // Floating Data Particles
    const particleGeo = new THREE.BufferGeometry();
    const posArray = new Float32Array(500 * 3);
    for(let i=0; i<1500; i++) posArray[i] = (Math.random() - 0.5) * 10;
    particleGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    particles = new THREE.Points(particleGeo, new THREE.PointsMaterial({ size: 0.02, color: 0x00e5ff }));
    scene.add(particles);

    animate();
}

// यह फंक्शन main.js से कॉल होगा ताकि 3D का रंग बदले
export function triggerAIAnimation(known) {
    isThinking = true;
    aiCore.material.color.setHex(known ? 0x00ff00 : 0xff3300); // हरा (Green) अगर पता है, लाल (Red) अगर नहीं
    setTimeout(() => { 
        isThinking = false; 
        aiCore.material.color.setHex(0x00e5ff); // वापस नार्मल स्यान
    }, 2000);
}

function animate() {
    requestAnimationFrame(animate);
    let speed = isThinking ? 0.05 : 0.003;
    aiCore.rotation.x += speed; 
    aiCore.rotation.y += speed;
    particles.rotation.y -= 0.001; 
    particles.rotation.x += 0.001;
    renderer.render(scene, camera);
}

// Window resize fix for mobile
window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth/window.innerHeight; 
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});

init3D();
