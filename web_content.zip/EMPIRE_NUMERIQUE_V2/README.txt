EMPIRE NUMÉRIQUE V2 — LORD DÉMON YACKUZA

Version statique prête pour Netlify.

INSTALLATION :
1. Décompresser ce dossier.
2. Déposer le dossier sur Netlify (ou importer le ZIP).
3. Aucun serveur Node n'est nécessaire.

FONCTIONS :
- Fond par défaut Yackuza.
- Import d'une image comme fond.
- Import d'une vidéo comme fond.
- Mémorisation locale du fond via IndexedDB.
- Import et lecture d'une musique locale.
- Mémorisation locale de la musique.
- Dashboard Empire responsive desktop/mobile.
- Centre média et applications.
- Centre de signalement local, avec historique et copie du dossier.
- Aucun réglage d'opacité du site.
- Aucun backend, aucune clé secrète requise.

NOTE : les médias importés restent dans le navigateur/appareil qui les a importés. Ils ne sont pas envoyés sur Netlify.
