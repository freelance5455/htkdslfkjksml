ALBIN CHAOS 2010 — PHONE-ONLY PACKAGE

Use this as a WebView/HTML-to-APK project.

1. Upload the CONTENTS of the "www" folder to an HTML-to-APK builder.
2. Set:
   App name: Albin Chaos 2010
   Start file: index.html
   Orientation: Landscape
   Fullscreen: ON
   JavaScript: ON
   Local storage: ON
   File/media access: ON
3. Build APK.
4. Install the resulting APK.

The game itself is the exact current Albin-1 Edition HTML, with a small
mobile fullscreen/viewport layer added around it.

If a builder asks for a website URL instead of files, choose its
"local HTML / upload ZIP / upload project" option instead. Do not enter
a fake URL.
