# SchoolConnect — Clickable HTML Prototype

## Screen / navigation map

- Splash → Login
- Login → Home
- Home → Child Profile
- Home → Fees
- Home → Trips & Activities
- Home → New Request
- Home → Live Chat
- Home → Notifications
- Fees → Payment → Payment Success
- Fees → Payment History
- Requests → New Request → Request Details → Live Chat
- Notifications → related destination
- More → Profile / Payment History / Notifications / Live Chat
- Bottom navigation → Home / Fees / Requests / Chat / More
- Back buttons return to the previous logical parent screen.

## Prototype assumptions

- Mock parent: Shaimaa Kenawy
- Two children: Omar Kenawy and Laila Kenawy
- EGP currency
- No real backend, authentication, payment gateway, or chat service.
- Payment, chat, request submission and notifications are simulated locally.
- The parent avatar uses a CSS illustration with a hijab to match the requested visual direction.

## Run

Open `index.html` directly in a modern browser.

For local development, any static server can be used, for example:

python -m http.server 8080

Then open http://localhost:8080
