# ToraOS 15.0.7 — Projeto Android/WebView


Este é um esqueleto de projeto Android que embute o HTML do ToraOS 15.0.7 em uma WebView.

## O que está pronto
- HTML original do ToraOS em `app/src/main/assets/index.html`
- Manifesto Android e atividade Java de entrada
- Gradle de projeto configurado para Android Gradle Plugin 8.7.3, SDK 35
- Tela cheia, JavaScript, armazenamento DOM e reprodução de mídia habilitados

## O que ainda falta / limitações
- Não foi compilado em APK neste ambiente: Android SDK, Build Tools (`aapt`) e D8 não estão instalados.
- A WebView não instala APKs por si só. Um instalador nativo precisa ser implementado com fluxo PackageInstaller/URI e permissões do Android, com confirmação do usuário.
- Os dois APKs adicionais não foram incorporados aos assets: incluí-los no pacote não os instala e aumentaria o tamanho sem resolver a integração.
- Este projeto é um ponto de partida de compilação, não um APK pronto nem teste em aparelho.

## Compilar
Abra a pasta no Android Studio com SDK 35 instalado e sincronize o Gradle. Gere APK em Build > Build APK(s).
