#!/system/bin/sh
# ===========================================================================
# APEX TOUCH SENSITIVITY ENGINE v1.2.0
# Core: GPU Rendering Pipeline
# Target: REDMAGIC 11 Pro (Adreno 830)
# Method: 100% ADB Shell Compatible -- Zero Root
#
# Even with perfect touch detection, if the GPU takes too long to render
# the next frame, the touch feedback appears late on screen.
#
# LATENCY CHAIN:
#   FINGER > TOUCH CONTROLLER > INPUT SYSTEM > GPU RENDER > DISPLAY
#   Physical  960Hz (1.04ms)    Settings       THIS PHASE   6.9ms (144Hz)
#
# debug.* properties: Writable via ADB (setprop debug.*)
# Note: TRANSIENT -- reset on reboot. service.sh re-applies on boot.
# ===========================================================================

apply_gpu_rendering() {
    _log="$1"
    _bdir="$2"

    log ""
    log "-----------------------------------------------------------"
    log "  [APEX] PHASE 6: GPU RENDERING PIPELINE"
    log "-----------------------------------------------------------"
    log ""

    # debug.hwui.renderer = skiavk
    # Forces Skia with Vulkan. On Adreno 830, Vulkan draws have
    # ~15-20% less CPU overhead than OpenGL ES.
    # Gaming: Faster UI rendering = lower touch-to-pixel latency
    apply_prop "debug.hwui.renderer" "skiavk"

    # debug.egl.hw = 1
    # Forces hardware-accelerated EGL context.
    # Gaming: Guaranteed GPU acceleration for all rendering
    apply_prop "debug.egl.hw" "1"

    # debug.hwui.profile = false
    # Disables GPU profiling overlay.
    # Gaming: Removes profiling overhead
    apply_prop "debug.hwui.profile" "false"

    log ""
    log "  [APEX] Phase 6 complete (debug.* are transient, reset on reboot)"
}
