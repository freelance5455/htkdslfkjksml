
package com.manxz.floatinginjector

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast

class FloatingService : Service() {

    private lateinit var manager: WindowManager
    private var panel: View? = null

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun showPanel() {
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.rgb(15, 18, 27))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.rgb(47, 128, 255))
            }
        }

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "MANXZ  •  APPS"
            textSize = 16f
            setTextColor(Color.rgb(47, 128, 255))
        }

        val close = Button(this).apply {
            text = "X"
            setOnClickListener { stopSelf() }
        }

        header.addView(
            title,
            LinearLayout.LayoutParams(0, dp(45), 1f)
        )
        header.addView(close)
        root.addView(header)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val apps = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER),
            0
        ).distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy {
                it.loadLabel(packageManager).toString().lowercase()
            }

        apps.take(80).forEach { app ->
            val appName = app.loadLabel(packageManager).toString()
            val packageName = app.activityInfo.packageName

            val button = Button(this).apply {
                text = appName
                isAllCaps = false

                setOnClickListener {
                    val launch =
                        packageManager.getLaunchIntentForPackage(packageName)

                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        try {
                            startActivity(launch)
                        } catch (_: Exception) {
                            Toast.makeText(
                                this@FloatingService,
                                "Tidak dapat membuka aplikasi",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }

            list.addView(
                button,
                LinearLayout.LayoutParams(
                    -1,
                    dp(44)
                )
            )
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, dp(300)))

        val params = WindowManager.LayoutParams(
            dp(270),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(100)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    params.x =
                        startX + (event.rawX - touchX).toInt()
                    params.y =
                        startY + (event.rawY - touchY).toInt()

                    try {
                        manager.updateViewLayout(root, params)
                    } catch (_: Exception) {
                    }

                    true
                }

                else -> false
            }
        }

        panel = root

        try {
            manager.addView(root, params)
        } catch (_: Exception) {
            panel = null
            stopSelf()
        }
    }

    override fun onDestroy() {
        panel?.let {
            try {
                manager.removeView(it)
            } catch (_: Exception) {
            }
        }

        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
