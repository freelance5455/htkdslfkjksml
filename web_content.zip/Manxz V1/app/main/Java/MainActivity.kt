
package com.manxz.floatinginjector

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(15, 18, 27))
        }

        val title = TextView(this).apply {
            text = "MANXZ"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(47, 128, 255))
        }

        val subtitle = TextView(this).apply {
            text = "FLOATING INJECTOR"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        val permission = Button(this).apply {
            text = "IZINKAN FLOATING WINDOW"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
            }
        }

        val start = Button(this).apply {
            text = "AKTIFKAN PANEL"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(
                        Intent(
                            this@MainActivity,
                            FloatingService::class.java
                        )
                    )
                } else {
                    permission.performClick()
                }
            }
        }

        val stop = Button(this).apply {
            text = "MATIKAN PANEL"
            setOnClickListener {
                stopService(
                    Intent(
                        this@MainActivity,
                        FloatingService::class.java
                    )
                )
            }
        }

        layout.addView(title)
        layout.addView(subtitle)

        listOf(permission, start, stop).forEach {
            layout.addView(
                it,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        setContentView(layout)
    }
}
