const items=[["Ultra AI","✦"],["D.C. AI","◉"],["Translator AI","文"],["Gamer AI","🎮"],["Live Animation AI","✧"],["Audio Editor AI","♫"],["Code Creator AI","⌘"],["AI Photos","▧"],["AI Videos","▶"],["AI 3D Creator","◇"]];
let active="Ultra AI",ws;const $=x=>document.getElementById(x);
items.forEach(([n,i])=>{let b=document.createElement("button");b.className="module";b.innerHTML=`<span class="ico">${i}</span><strong>${n}</strong><small>Open workspace</small>`;b.onclick=()=>choose(n);$("modules").appendChild(b)});
function choose(n){active=n;$("agentName").textContent=n;add("Opened "+n,"bot")}
function add(t,r){let e=document.createElement("div");e.className="bubble "+r;e.textContent=t;$("messages").appendChild(e);$("messages").scrollTop=$("messages").scrollHeight}
function connect(){ws=new WebSocket("ws://127.0.0.1:5000/ws");ws.onopen=()=>$("status").textContent="● Connected";ws.onclose=()=>$("status").textContent="○ Offline";ws.onmessage=e=>add(JSON.parse(e.data).message||"No response","bot")}
function send(){let m=$("prompt").value.trim();if(!m)return;$("prompt").value="";add(m,"user");if(!ws||ws.readyState!==1){add("Pydroid 3 backend चालू नहीं है।","bot");return}ws.send(JSON.stringify({agent:active,message:m}))}
$("send").onclick=send;$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter")send()});$("quickToggle").onclick=()=>$("quick").classList.toggle("hidden");$("audioShortcut").onclick=()=>{choose("Audio Editor AI");$("quick").classList.add("hidden")};
$("login").onclick=async()=>{try{let r=await fetch("http://127.0.0.1:5000/private/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("password").value})});let d=await r.json();$("loginResult").textContent=r.ok?"Authenticated · "+d.owner:(d.detail||"Login failed")}catch(e){$("loginResult").textContent="Backend unavailable"}};
connect();
