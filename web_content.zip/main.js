window.__BIZCASHFLOW_MAIN_LOADED__=true;


const KEY='bizcashflow-offline-v14';
const money = n => new Intl.NumberFormat('en-KE',{style:'currency',currency:'KES',maximumFractionDigits:2}).format(Number(n)||0);
const id = () => Math.random().toString(36).slice(2,10);
const today = () => new Date().toISOString().slice(0,10);

const coaSeed = [
  ['1000','Assets','Current Assets','Cash','Asset'],['1010','Assets','Current Assets','Bank - Checking','Asset'],
  ['1020','Assets','Current Assets','Bank - Savings','Asset'],['1030','Assets','Current Assets','Petty Cash','Asset'],
  ['1100','Assets','Current Assets','Accounts Receivable','Asset'],['1110','Assets','Current Assets','Notes Receivable','Asset'],
  ['1120','Assets','Current Assets','Employee Advances','Asset'],['1200','Assets','Current Assets','Inventory','Asset'],
  ['1210','Assets','Current Assets','Raw Materials','Asset'],['1220','Assets','Current Assets','Work in Progress','Asset'],
  ['1230','Assets','Current Assets','Finished Goods','Asset'],['1240','Assets','Current Assets','Merchandise Inventory','Asset'],
  ['1300','Assets','Current Assets','Prepaid Expenses','Asset'],['1310','Assets','Current Assets','Prepaid Insurance','Asset'],
  ['1320','Assets','Current Assets','Prepaid Rent','Asset'],['1400','Assets','Current Assets','Short-term Investments','Asset'],
  ['1500','Assets','Non-current Assets','Land','Asset'],['1510','Assets','Non-current Assets','Buildings','Asset'],
  ['1520','Assets','Non-current Assets','Accumulated Depreciation - Buildings','Contra Asset'],
  ['1530','Assets','Non-current Assets','Equipment','Asset'],['1540','Assets','Non-current Assets','Accumulated Depreciation - Equipment','Contra Asset'],
  ['1550','Assets','Non-current Assets','Vehicles','Asset'],['1560','Assets','Non-current Assets','Accumulated Depreciation - Vehicles','Contra Asset'],
  ['1570','Assets','Non-current Assets','Furniture & Fixtures','Asset'],['1580','Assets','Non-current Assets','Computer Equipment','Asset'],
  ['1600','Assets','Non-current Assets','Intangible Assets','Asset'],['1610','Assets','Non-current Assets','Software','Asset'],
  ['1700','Assets','Other Assets','Security Deposits','Asset'],['1800','Assets','Other Assets','Deferred Tax Asset','Asset'],
  ['2000','Liabilities','Current Liabilities','Accounts Payable','Liability'],['2010','Liabilities','Current Liabilities','Notes Payable - Current','Liability'],
  ['2020','Liabilities','Current Liabilities','Accrued Expenses','Liability'],['2030','Liabilities','Current Liabilities','Salaries Payable','Liability'],
  ['2040','Liabilities','Current Liabilities','Tax Payable','Liability'],['2050','Liabilities','Current Liabilities','VAT/GST Payable','Liability'],
  ['2060','Liabilities','Current Liabilities','Customer Deposits','Liability'],['2100','Liabilities','Non-current Liabilities','Long-term Loan','Liability'],
  ['2110','Liabilities','Non-current Liabilities','Lease Liability','Liability'],['2120','Liabilities','Non-current Liabilities','Deferred Tax Liability','Liability'],
  ['3000','Equity','Equity','Owner Capital','Equity'],['3010','Equity','Equity','Owner Drawings','Equity'],
  ['3020','Equity','Equity','Retained Earnings','Equity'],['3030','Equity','Equity','Current Year Earnings','Equity'],
  ['4000','Income','Operating Revenue','Sales Revenue','Income'],['4010','Income','Operating Revenue','Service Revenue','Income'],
  ['4020','Income','Operating Revenue','Consulting Revenue','Income'],['4030','Income','Operating Revenue','Rental Income','Income'],
  ['4040','Income','Operating Revenue','Other Operating Income','Income'],['4100','Income','Other Income','Interest Income','Income'],
  ['4110','Income','Other Income','Gain on Asset Disposal','Income'],['4120','Income','Other Income','Foreign Exchange Gain','Income'],
  ['5000','Cost of Sales','Cost of Sales','Cost of Goods Sold','Expense'],['5010','Cost of Sales','Cost of Sales','Purchases','Expense'],
  ['5020','Cost of Sales','Cost of Sales','Purchase Returns','Income'],['5030','Cost of Sales','Cost of Sales','Freight In','Expense'],
  ['6000','Expense','Operating Expenses','Advertising & Marketing','Expense'],['6010','Expense','Operating Expenses','Bank Charges','Expense'],
  ['6020','Expense','Operating Expenses','Communication & Internet','Expense'],['6030','Expense','Operating Expenses','Electricity','Expense'],
  ['6040','Expense','Operating Expenses','Water','Expense'],['6050','Expense','Operating Expenses','Rent','Expense'],
  ['6060','Expense','Operating Expenses','Salaries & Wages','Expense'],['6070','Expense','Operating Expenses','Employee Benefits','Expense'],
  ['6080','Expense','Operating Expenses','Office Supplies','Expense'],['6090','Expense','Operating Expenses','Repairs & Maintenance','Expense'],
  ['6100','Expense','Operating Expenses','Insurance Expense','Expense'],['6110','Expense','Operating Expenses','Transport & Delivery','Expense'],
  ['6120','Expense','Operating Expenses','Travel & Accommodation','Expense'],['6130','Expense','Operating Expenses','Professional Fees','Expense'],
  ['6140','Expense','Operating Expenses','Legal Fees','Expense'],['6150','Expense','Operating Expenses','Accounting Fees','Expense'],
  ['6160','Expense','Operating Expenses','Software Subscriptions','Expense'],['6170','Expense','Operating Expenses','Depreciation Expense','Expense'],
  ['6180','Expense','Operating Expenses','Bad Debt Expense','Expense'],['6190','Expense','Operating Expenses','Training & Development','Expense'],
  ['6200','Expense','Operating Expenses','Fuel','Expense'],['6210','Expense','Operating Expenses','Vehicle Running Costs','Expense'],
  ['6220','Expense','Operating Expenses','Cleaning','Expense'],['6230','Expense','Operating Expenses','Security','Expense'],
  ['6240','Expense','Operating Expenses','Licenses & Permits','Expense'],['6250','Expense','Operating Expenses','Taxes & Duties','Expense'],
  ['6260','Expense','Operating Expenses','Foreign Exchange Loss','Expense'],['6270','Expense','Operating Expenses','Miscellaneous Expense','Expense'],
  ['7000','Expense','Finance Costs','Interest Expense','Expense'],['7010','Expense','Finance Costs','Loan Fees','Expense'],
  ['8000','Other','Suspense & Clearing','Suspense Account','Other'],['8010','Other','Suspense & Clearing','Cash Clearing','Other']
].map(([code,type,group,name,normal])=>({code,type,group,name,normal}));

const seed={
  coa: coaSeed,
  tx: [],
  products:[], customers:[], suppliers:[],
  theme:'light', mode:'small', user:null, loggedIn:false
};
let state=load();
function safeClone(v){return typeof structuredClone==='function'?structuredClone(v):JSON.parse(JSON.stringify(v))}
function load(){try{const saved=localStorage.getItem(KEY)||'{}';const raw=JSON.parse(saved);const x={...safeClone(seed),...(raw&&typeof raw==='object'?raw:{})};x.coa=Array.isArray(x.coa)&&x.coa.length?x.coa:safeClone(coaSeed);x.tx=Array.isArray(x.tx)?x.tx:[];x.products=Array.isArray(x.products)?x.products:[];x.customers=Array.isArray(x.customers)?x.customers:[];x.suppliers=Array.isArray(x.suppliers)?x.suppliers:[];x.invoices=Array.isArray(x.invoices)?x.invoices:[];x.bills=Array.isArray(x.bills)?x.bills:[];x.user=x.user&&typeof x.user==='object'?x.user:null;x.loggedIn=!!x.loggedIn;return x}catch(e){console.warn('BizCashFlow data reset to safe defaults',e);return safeClone(seed)}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function acct(code){return state.coa.find(a=>a.code===code)}
function label(code){const a=acct(code); return a?`${a.code} · ${a.name}`:code}
function post(kind,description,amount,from,to,date=today(),meta={}){
  amount=Number(amount)||0; if(!amount||!from||!to||from===to) return false;
  state.tx.push({id:id(),date,kind,description,amount:Number(amount),from,to,...meta}); save(); return true;
}
function rows(){
  const r=[];
  for(const t of state.tx){
    r.push({date:t.date,tx:t.id,kind:t.kind,description:t.description,account:t.from,debit:t.amount,credit:0});
    r.push({date:t.date,tx:t.id,kind:t.kind,description:t.description,account:t.to,debit:0,credit:t.amount});
  }
  return r;
}
function balance(code){
  return rows().filter(r=>r.account===code).reduce((s,r)=>s+r.debit-r.credit,0)
}
function totalDebit(){return state.tx.reduce((s,t)=>s+Number(t.amount||0),0)}
function totalCredit(){return totalDebit()}
function revenue(){return rows().filter(r=>acct(r.account)?.type==='Income').reduce((s,r)=>s+r.credit-r.debit,0)}
function expenses(){return operatingExpensesTotal()+cogsTotal()}
function salesTotal(){return state.tx.filter(t=>t.kind==='Sale').reduce((s,t)=>s+Number(t.amount||0),0)}
function purchasesTotal(){return state.tx.filter(t=>t.kind==='Purchase').reduce((s,t)=>s+Number(t.amount||0),0)}
function operatingExpensesTotal(){return state.tx.filter(t=>t.kind==='Expense').reduce((s,t)=>s+Number(t.amount||0),0)}
function cogsTotal(){return state.tx.filter(t=>t.kind==='COGS').reduce((s,t)=>s+Number(t.amount||0),0)}
function stockUnits(){return (state.products||[]).reduce((s,p)=>s+Number(p.qty||0),0)}
function stockValue(){return (state.products||[]).reduce((s,p)=>s+Number(p.qty||0)*Number(p.buy||0),0)}
function smallBusinessSales(){return salesTotal()}
function smallBusinessGrossProfit(){return salesTotal()-cogsTotal()}
function profit(){return revenue()-operatingExpensesTotal()-cogsTotal()}
function dashboardTotals(){return {sales:salesTotal(),purchases:purchasesTotal(),profit:profit(),stockValue:stockValue(),stockUnits:stockUnits(),expenses:operatingExpensesTotal(),cogs:cogsTotal()}}
function esc(x){return String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function accountOptions(selected=''){
  return state.coa.map(a=>`<option value="${a.code}" ${a.code===selected?'selected':''}>${esc(a.code+' · '+a.name)}</option>`).join('')
}
function smartAccountOptions(selected='4000'){ const blocked=new Set(['1000','1010','1020','1030','1100','2000']); return state.coa.filter(a=>!blocked.has(a.code)&&a.type!=='Other').map(a=>`<option value="${a.code}" ${a.code===selected?'selected':''}>${esc(a.code+' · '+a.name)}</option>`).join('') }
function renderLogin(){
  document.documentElement.dataset.theme=state.theme||'light';
  const app=document.querySelector('#app');
  app.innerHTML=`<div class="loginShell">
    <div class="loginGlow glowOne"></div><div class="loginGlow glowTwo"></div>
    <div class="loginCard">
      <div class="loginBrand"><div class="loginLogo animatedBrand"><img src="./assets/brand-logo.png" alt="BizCashFlow"></div><div><b>BizCashFlow</b><small>Pro Business Suite</small></div></div>
      <div class="loginWelcome"><span>✨ YOUR BUSINESS, BEAUTIFULLY CALCULATED</span><h1>${state.user?'Welcome back!':'Welcome to BizCashFlow'}</h1><p>${state.user?'Enter your password to continue.':'Create your business login once. BizCashFlow will welcome you by name every time you sign in.'}</p></div>
      <form onsubmit="event.preventDefault();loginSubmit()">
        ${state.user?`<div class="loggedUserPill"><span class="avatarBig">${esc((state.user.name||'U')[0].toUpperCase())}</span><div><b>${esc(state.user.name)}</b><small>Business owner</small></div></div>`:`<label>Your name<input id="loginName" autocomplete="name" placeholder="e.g. Walter" required></label>`}
        <label>Password<input id="loginPassword" type="password" autocomplete="current-password" placeholder="Enter your password" required></label>
        <button class="loginButton" type="submit">${state.user?'🔐 Sign in':'🚀 Create & enter'}</button>
      </form>
      <div class="loginOptions"><button type="button" onclick="toggleTheme()">${state.theme==='dark'?'☀️ Light screen':'🌙 Dark screen'}</button>${state.user?'<button type="button" onclick="resetLogin()">Change user</button>':''}</div>
      <small class="loginNote">This local version stores your login on this device. For a real online multi-user system, we will use secure server authentication.</small>
    </div>
  </div>`;
}
function loginSubmit(){
  const password=document.querySelector('#loginPassword')?.value||'';
  if(!password) return;
  if(!state.user){ const name=(document.querySelector('#loginName')?.value||'').trim(); if(!name){toast('Please enter your name');return;} if(password.length<4){toast('Use at least 4 characters for your password');return;} state.user={name,password}; state.loggedIn=true; save(); render(); toast(`Welcome, ${name}!`); return; }
  if(password!==state.user.password){toast('Incorrect password');return;}
  state.loggedIn=true; save(); render(); toast(`Welcome back, ${state.user.name}!`);
}
function logout(){state.loggedIn=false;save();render()}
function resetLogin(){if(confirm('Change the saved business user? Your accounting data will remain.')){state.user=null;state.loggedIn=false;save();render();}}
function render(){
  try {
  document.documentElement.dataset.theme=state.theme||'light';
  if(!state.user || !state.loggedIn){ renderLogin(); return; }
  const app=document.querySelector('#app');
  app.innerHTML=`<div class="shell">
    <aside class="sidebar">
      <div class="brand" onclick="go('dashboard')" role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' ')go('dashboard')"><div class="brandLogoWrap animatedBrand"><img src="./assets/brand-logo.png" alt="BizCashFlow"></div></div>
      <button class="dashboardNav ${current()==='dashboard'?'active':''}" onclick="go('dashboard')"><span>⌂</span><b>Dashboard</b></button>
      <div class="side-label refSideTitle">WORK MODES</div>
      <div class="modeNav refModes">${modeNav('small','Small Business','▣')}${modeNav('accounts','Accounting','▤')}</div>
      <div class="side-label refSideTitle quickTitle">QUICK ACTIONS</div>
      <div class="quickSideActions">
        <button onclick="go('small')"><span class="quickSideIcon green">＋</span><b>Add Transaction</b></button>
        <button onclick="go('inventory')"><span class="quickSideIcon orange">▣</span><b>Add Product / Stock</b></button>
        <button onclick="go('contacts')"><span class="quickSideIcon blue">♙</span><b>Add Customer / Supplier</b></button>
        <button onclick="go('reports')"><span class="quickSideIcon purple">▤</span><b>Reports</b></button>
      </div>
      <div class="divider refDivider"><span>BUSINESS MODULES</span></div>
      ${nav('sales','Sales & Invoices','↗')}
      ${nav('purchases','Purchases & Bills','↙')}
      ${nav('expenses','Expenses','−')}
      ${nav('inventory','Inventory','□')}
      ${nav('contacts','Customers & Suppliers','♙')}
      <div class="divider refDivider"><span>ACCOUNTING RECORDS</span></div>
      ${nav('transactions','Accounting Transaction Records','ϟ')}
      ${nav('accounts','Accounting','▤')}
      <div class="sideSuccess"><span>♛</span><div><b>Your success</b><small>is our priority!</small></div></div>
      <div class="spacer"></div>
      <div class="userbox"><div class="avatar">${esc((state.user?.name||'U')[0].toUpperCase())}</div><div><b>${esc(state.user?.name||'Business Owner')}</b><small>Smart accounting</small></div></div><button class="logoutBtn" onclick="logout()">⇥ Sign out</button>
      <button class="themeBtn" onclick="toggleTheme()">◐ <span>${state.theme==='dark'?'Light mode':'Dark mode'}</span></button>
    </aside>
    <main class="main">
      <header class="top refTop"><button class="mobileMenu" onclick="document.body.classList.toggle('menu')">☰</button><div class="crumb"><div class="topSearch">⌕ <input placeholder="Search anything..." oninput="window.globalSearch=this.value"></div></div><div class="topActions"><button class="topIcon" onclick="toggleTheme()">☀</button><button class="topIcon bell">♧<span>3</span></button><div class="topAvatar">${esc((state.user?.name||'U')[0].toUpperCase())}</div></div></header>
      <section class="content">${page()}</section>
    </main>
  </div>`;
  startGreetingClock();
  } catch (error) {
    console.error('BizCashFlow render error:', error);
    const app=document.querySelector('#app');
    if(app) app.innerHTML=`<div style="min-height:100vh;display:grid;place-items:center;padding:32px;font-family:system-ui;background:#f6f7fb;color:#17263b"><div style="max-width:720px;background:white;border-radius:24px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.12)"><h1>BizCashFlow needs a quick refresh</h1><p>The app caught an unexpected data/display error and protected your records.</p><button onclick="localStorage.removeItem('bizcashflow-offline-v14');location.reload()" style="padding:12px 18px;border:0;border-radius:12px;background:#17263b;color:white;cursor:pointer">Refresh safely</button></div></div>`;
  }
}
function nav(key,text,icon){return `<button class="nav ${current()===key?'active':''}" onclick="go('${key}')"><span>${icon}</span><b>${text}</b>${key==='small'?'<i>●</i>':''}</button>`}
function modeNav(key,text,icon){return `<button class="modeNavBtn ${current()===key?'active':''}" onclick="go('${key}')"><span>${icon}</span><b>${text}</b></button>`}
function current(){return location.hash.replace('#/','')||'dashboard'}
function go(k){location.hash='/'+k; render()}
function title(){return ({dashboard:'Dashboard',support:'Help & Support',small:'Small Business',sales:'Sales & Invoices',purchases:'Purchases & Bills',expenses:'Expenses',inventory:'Products & Inventory',contacts:'Customers & Suppliers',transactions:'Accounting Transaction Records',accounts:'Chart of Accounts',credits:'Credit Records',reports:'Financial Reports',export:'Export & Backup',settings:'Settings & Help'})[current()]||'Dashboard'}
function page(){
  switch(current()){
    case 'support': return supportPage();
    case 'small': return smallBusiness();
    case 'sales': return salesPage();
    case 'purchases': return purchasesPage();
    case 'expenses': return expensesPage();
    case 'inventory': return inventoryPage();
    case 'contacts': return contactsPage();
    case 'transactions': return transactions();
    case 'accounts': return accountingPage();
    case 'credits': return credits();
    case 'reports': return reports();
    case 'export': return exportPage();
    case 'settings': return settings();
    default:return dashboard();
  }
}
function timeGreeting(date=new Date()){
  const hour=date.getHours();
  if(hour<12)return 'Good morning';
  if(hour<18)return 'Good afternoon';
  return 'Good evening';
}
let greetingTimer=null;
function updateDashboardGreeting(){
  const el=document.querySelector('#dashboardGreeting');
  if(el)el.textContent=`${timeGreeting()}${state.user?.name?', '+state.user.name:''}! 👋`;
}
function startGreetingClock(){
  if(greetingTimer)clearInterval(greetingTimer);
  greetingTimer=setInterval(updateDashboardGreeting,60000);
  updateDashboardGreeting();
}

function dashboard(){
  const txs=(state.tx||[]).slice().reverse();
  const totals=dashboardTotals();
  const sales=totals.sales;
  const purchases=totals.purchases;
  const net=totals.profit;
  const stock=state.products||[];
  const currentStockValue=totals.stockValue;
  const recent=txs.slice(0,5);
  const demoRecent=recent;
  const stockItems=stock.slice(0,4);
  return `<div class="refDashboard functionalDashboard">
    <section class="refHero">
      <div class="heroText">
        <div class="refEyebrow">✨ SMART BUSINESS DASHBOARD</div>
        <h1 id="dashboardGreeting">${timeGreeting()}, ${esc(state.user?.name||'Walter')}! 👋</h1>
        <h2>Your business is growing, keep going!</h2>
        <p>Track your sales, stock, expenses and profits — all in one place.</p>
        <div class="refHeroBtns"><button class="refGreenBtn" onclick="go('small')">＋ &nbsp;Record Transaction</button><button class="refPurpleBtn" onclick="go('reports')">▣ &nbsp;View Reports</button></div>
      </div>
      <img class="heroRobot" src="./assets/hero-robot.png" alt="BizCashFlow mascot">
      <div class="coin coin1">🪙</div><div class="coin coin2">🪙</div><div class="coin coin3">🪙</div><div class="heroStars">✦　✧　✦</div>
      <div class="dreamText">Small steps<br><b>Big dreams!</b></div>
    </section>
    <section class="refMetrics">
      ${refMetric('🛢️','Total Sales',money(sales),'LIVE','green')}
      ${refMetric('🛒','Total Purchases',money(purchases),'LIVE','pink')}
      ${refMetric('🪙','Net Profit',money(net),net>=0?'LIVE':'LIVE','purple')}
      ${refMetric('📦','Stock Value',money(currentStockValue),'LIVE','yellow')}
    </section>
    <div class="liveTotalsStrip"><span>Revenue <b>${money(revenue())}</b></span><span>COGS <b>${money(cogsTotal())}</b></span><span>Operating expenses <b>${money(operatingExpensesTotal())}</b></span><span>Stock units <b>${totals.stockUnits.toLocaleString()}</b></span></div>
    <section class="refTwoCol">
      <div class="refPanel">
        <div class="refPanelTitle"><div><span class="roundIcon purple">⚡</span><div><h2>Quick Transaction</h2><p>Type what happened and let BizCashFlow do the rest!</p></div></div></div>
        <div class="quickInputWrap"><input id="dashQuickText" placeholder="e.g. Sukari sold 10  or  Rice bought 5"><button onclick="dashQuickEntry()">➜</button></div>
        <div class="quickPills"><button onclick="dashFill('sold')">＋ Sold</button><button onclick="dashFill('bought')">＋ Bought</button><button onclick="dashFill('expense')">＋ Expense</button><button onclick="dashFill('other')">＋ Other</button></div>
        <div class="cuteHint"><div class="shopEmoji">🏪</div><div><b>Type what happened, e.g. Sukari sold 10</b><small>The system will automatically detect, calculate and update everything!</small></div><span>✦</span></div>
      </div>
      <div class="refPanel">
        <div class="refPanelHead"><div><span class="roundIcon purple">▣</span><div><h2>Recent Transactions</h2></div></div><button class="refLink" onclick="go('transactions')">View All →</button></div>
        <div class="recentList">${demoRecent.map(recentRow).join('')}</div>
      </div>
    </section>
    <section class="refPanel stockPanel">
      <div class="refPanelHead"><div><span class="roundIcon blue">▣</span><div><h2>Stock Overview</h2></div></div><button class="refLink" onclick="go('inventory')">View All →</button></div>
      <div class="stockGrid">${stockItems.length?stockItems.map(stockCard).join(''):'<div class="empty">No stock yet. Add a product in Small Business to see live stock here.</div>'}</div>
    </section>
    <section class="refBottomCards">
      ${miniReport('📊','Reports','reports','purple')}${miniReport('↗','Profit & Loss','reports','cyan')}${miniReport('⚖','Balance Sheet','reports','blue')}${miniReport('🪙','Cash Flow','reports','gold')}
    </section>
  </div>`;
}
function refMetric(icon,labelText,value,trend,kind){return `<div class="refMetric ${kind}"><div class="metricEmoji">${icon}</div><div><small>${labelText}</small><strong>${value}</strong><span>${trend} <em>vs last week</em></span></div><div class="metricBars"><i></i><i></i><i></i><i></i></div></div>`}
function recentRow(t){const sale=t.kind==='Sale', purchase=t.kind==='Purchase'; const icon=sale?'🛍️':purchase?'🛒':'💼'; const tag=sale?'Sale':purchase?'Purchase':'Expense'; const cls=sale?'sale':purchase?'purchase':'expense'; return `<div class="recentRow"><div class="recentIcon ${cls}">${icon}</div><div class="recentInfo"><b>${esc(t.description||t.kind)}</b><small>${esc(t.kind)} • ${t.product?esc(t.product):'Operating'}</small></div><span class="recentTag ${cls}">${tag}</span><div class="recentAmount">${money(t.amount)}</div><button class="trashMini" onclick="deleteTransaction('${t.id}')">🗑</button></div>`}
function stockCard(p){const qty=Number(p.qty||0); const percent=Math.max(0,Math.min(100,qty>0?Math.min(100,qty*2):0)); return `<div class="stockCard"><div class="stockPic">${p.name.toLowerCase().includes('suk')?'🛍️':p.name.toLowerCase().includes('rice')?'🍚':p.name.toLowerCase().includes('unga')?'🌾':'🧴'}</div><b>${esc(p.name)}</b><small>Remaining: ${qty.toLocaleString()}</small><div class="stockBar"><span style="width:${percent}%"></span></div></div>`}
function miniReport(icon,labelText,target,kind){return `<button class="miniReport ${kind}" onclick="go('${target}')"><span>${icon}</span><b>${labelText}</b></button>`}
function dashFill(type){const el=document.querySelector('#dashQuickText');if(!el)return;el.value=type==='sold'?'Sukari sold 10':type==='bought'?'Rice bought 5':type==='expense'?'Rent expense 5000':'Sukari sold 10';el.focus()}
function dashQuickEntry(){const raw=(document.querySelector('#dashQuickText')?.value||'').trim();if(!raw)return toast('Open Small Business to record a sale or purchase');location.hash='/small';render();}
function card(a,b,c,d){return `<div class="metric ${d}"><div class="metricIcon">${c}</div><div><small>${a}</small><strong>${b}</strong></div><span class="metricSpark">✦</span></div>`}
function smallBusiness(){
  const products=state.products||[];
  const totals=dashboardTotals();
  const currentStockUnits=totals.stockUnits;
  const currentStockValue=totals.stockValue;
  const sales=totals.sales;
  const gross=smallBusinessGrossProfit();
  return `<div class="pageIntro simpleBusinessIntro"><div><span class="eyebrow">SMALL BUSINESS</span><h1>Run your shop without accounting words</h1><p>Set your products once. After that, just choose the product and enter the quantity sold or bought. BizCashFlow does the stock, money, sales and profit calculations for you.</p></div></div>
  <div class="smallShopGrid">
    <div class="panel setupShopCard">
      <div class="formTitle"><div><span class="spark">✦</span><h2>1. Set up your stock</h2></div><span class="autoBadge">ONCE</span></div>
      <p class="smallMuted">Tell BizCashFlow what you have in the shop and the prices. You don't need account codes.</p>
      <div class="shopSetupForm">
        <label>Product name<input id="sbProductName" placeholder="e.g. Sukari"></label>
        <label>Quantity in stock<input id="sbProductQty" type="number" min="0" step="1" placeholder="e.g. 50"></label>
        <label>Bought at per item (KSh)<input id="sbBuy" type="number" min="0" step="0.01" placeholder="e.g. 80"></label>
        <label>Sell at per item (KSh)<input id="sbSell" type="number" min="0" step="0.01" placeholder="e.g. 100"></label>
      </div>
      <button class="primary wide" onclick="saveShopProduct()">＋ Add product to my shop</button>
    </div>
    <div class="panel dailyShopCard">
      <div class="formTitle"><div><span class="spark">⚡</span><h2>2. Record today's activity</h2></div><span class="autoBadge">AUTOMATIC</span></div>
      <p class="smallMuted">No “Sukari sold 10” typing. Just pick the item and enter how many.</p>
      <div class="shopActionTabs"><button id="sbSoldTab" class="shopTab active" onclick="setShopAction('Sold')">🛍️ Sold today</button><button id="sbBoughtTab" class="shopTab" onclick="setShopAction('Bought')">📦 Bought today</button></div>
      <label class="bigLabel">Which product? <select id="sbProductSelect" onchange="updateShopActivityPreview()"><option value="">Choose a product</option>${products.map(p=>`<option value="${esc(p.name)}">${esc(p.name)} — ${Number(p.qty||0).toLocaleString()} left</option>`).join('')}</select></label>
      <label class="bigLabel">How many? <input id="sbQty" type="number" min="1" step="1" placeholder="e.g. 10" oninput="updateShopActivityPreview()"></label><label class="bigLabel"><span id="sbPriceLabel">Selling price per unit (KSh)</span><input id="sbUnitPrice" type="number" min="0" step="0.01" placeholder="Use product price" oninput="updateShopActivityPreview()"></label>
      <div id="sbActivityPreview" class="shopAutoResult">Choose a product and quantity — BizCashFlow will calculate everything here.</div>
      <button class="primary wide" onclick="recordShopMovement()">✓ Save today's activity</button>
    </div>
  </div>
  <div class="cards smallShopMetrics">${card('Items in shop',products.length,'▣','neutral')}${card('Stock remaining',currentStockUnits.toLocaleString(),'📦','positive')}${card('Money from sales',money(sales),'💰','positive')}${card('Gross profit',money(gross),'✦',gross>=0?'positive':'negative')}</div>
  <div class="panel shopProductsPanel"><div class="panelHead"><div><h2>My shop stock</h2><p>Everything below updates automatically when you sell or buy.</p></div></div>${products.length?`<div class="shopProductRows">${products.map(p=>shopProductRow(p)).join('')}</div>`:'<div class="empty">Add your first product above. Then daily work becomes just product + quantity.</div>'}</div>
  <div class="panel shopActivityPanel"><div class="panelHead"><div><h2>Today's activity & transaction history</h2><p>See quantity, price per unit, total sale, profit and stock remaining. Delete a transaction and every related total updates immediately.</p></div></div>${smallBusinessActivities()}</div>`;
}
function productLedgerStats(name){
  const product=String(name||'').trim().toLowerCase();
  const salesTx=state.tx.filter(t=>t.kind==='Sale' && String(t.product||'').trim().toLowerCase()===product);
  const cogsTx=state.tx.filter(t=>t.kind==='COGS' && String(t.product||'').trim().toLowerCase()===product);
  return {sold:salesTx.reduce((s,t)=>s+Number(t.qty||0),0),revenueValue:salesTx.reduce((s,t)=>s+Number(t.amount||0),0),gp:salesTx.reduce((s,t)=>s+Number(t.amount||0),0)-cogsTx.reduce((s,t)=>s+Number(t.amount||0),0)};
}
function shopProductRow(p){
  const qty=Number(p.qty||0), sell=Number(p.sell||0), buy=Number(p.buy||0), stats=productLedgerStats(p.name);
  const hasActivity=state.tx.some(t=>t.product===p.name && ['Sale','Purchase','COGS'].includes(t.kind));
  return `<div class="shopProductRow"><div class="shopProductEmoji">${p.name.toLowerCase().includes('suk')?'🛍️':p.name.toLowerCase().includes('rice')?'🍚':p.name.toLowerCase().includes('unga')?'🌾':'📦'}</div><div class="shopProductMain"><b>${esc(p.name)}</b><small>Buy ${money(buy)} · Sell ${money(sell)}</small></div><div><strong>${qty.toLocaleString()}</strong><small>remaining</small></div><div><strong>${stats.sold.toLocaleString()}</strong><small>sold</small></div><div><strong>${money(stats.revenueValue)}</strong><small>sales</small></div><div><strong>${money(stats.gp)}</strong><small>gross profit</small></div><div><button type="button" class="deleteBtn" onclick="deleteShopProduct('${esc(p.id)}')">Delete stock</button>${hasActivity?'<small class="deleteHint">History stays in records</small>':''}</div></div>`;
}
function shopAction(){return window.shopAction||'Sold'}
function setShopAction(action){window.shopAction=action; const a=document.querySelector('#sbSoldTab'), b=document.querySelector('#sbBoughtTab'), price=document.querySelector('#sbUnitPrice'); if(a)a.classList.toggle('active',action==='Sold'); if(b)b.classList.toggle('active',action==='Bought'); if(price)price.value=''; updateShopActivityPreview()}
function saveShopProduct(){
 const name=(document.querySelector('#sbProductName')?.value||'').trim(); const qty=Number(document.querySelector('#sbProductQty')?.value||0); const buy=Number(document.querySelector('#sbBuy')?.value||0); const sell=Number(document.querySelector('#sbSell')?.value||0);
 if(!name)return toast('Enter the product name'); if(qty<0||buy<0||sell<0)return toast('Use amounts of zero or more'); if(findShopProduct(name))return toast('That product is already in your shop');
 state.products=state.products||[]; state.products.push({id:id(),name,buy,sell,qty,initialQty:qty,unit:'units',soldQty:0,soldValue:0,grossProfit:0});
 if(qty>0&&buy>0)post('Opening Stock',`Opening stock: ${name}`,qty*buy,'1200','3000',today(),{product:name,qty});
 save(); toast(`${name} added. Your daily work is now just product + quantity.`); render();
}
function findShopProduct(name){return (state.products||[]).find(p=>p.name.toLowerCase()===String(name||'').trim().toLowerCase())}
function updateShopActivityPreview(){
 const el=document.querySelector('#sbActivityPreview'); if(!el)return; const p=findShopProduct(document.querySelector('#sbProductSelect')?.value); const qty=Number(document.querySelector('#sbQty')?.value||0); const action=shopAction();
 const priceInput=document.querySelector('#sbUnitPrice'); const priceLabel=document.querySelector('#sbPriceLabel');
 if(priceInput && p && !priceInput.value) priceInput.value=action==='Sold'?Number(p.sell||0):Number(p.buy||0);
 if(priceLabel) priceLabel.textContent=action==='Sold'?'Selling price per unit (KSh)':'Buying price per unit (KSh)';
 if(!p||!qty){el.innerHTML='<b>Automatic result</b><small>Choose a product, quantity and price per unit.</small>';return}
 const enteredPrice=Number(priceInput?.value); const unitPrice=Number.isFinite(enteredPrice)&&enteredPrice>=0?enteredPrice:(action==='Sold'?Number(p.sell||0):Number(p.buy||0));
 const unitCost=Number(p.buy||0);
 const remaining=Number(p.qty||0)+(action==='Bought'?qty:-qty);
 const amount=qty*unitPrice;
 const gross=qty*(unitPrice-unitCost);
 if(action==='Sold') el.innerHTML=`<div class="autoResultGrid activityPreviewGrid"><span>Quantity sold <b>${qty.toLocaleString()}</b></span><span>Sell price / unit <b>${money(unitPrice)}</b></span><span>Sales amount <b>${money(amount)}</b></span><span>Cost / unit <b>${money(unitCost)}</b></span><span>Profit <b>${money(gross)}</b></span><span>Remaining stock <b>${Math.max(0,remaining).toLocaleString()}</b></span></div>`;
 else el.innerHTML=`<div class="autoResultGrid activityPreviewGrid"><span>Quantity bought <b>${qty.toLocaleString()}</b></span><span>Buy price / unit <b>${money(unitPrice)}</b></span><span>Money spent <b>${money(amount)}</b></span><span>Stock after buying <b>${remaining.toLocaleString()}</b></span></div>`;
}
function recordShopMovement(){
 const p=findShopProduct(document.querySelector('#sbProductSelect')?.value); const qty=Number(document.querySelector('#sbQty')?.value||0); const action=shopAction();
 if(!p)return toast('Choose a product first'); if(!qty||qty<1)return toast('Enter the quantity');
 const priceInput=document.querySelector('#sbUnitPrice'); const enteredPrice=Number(priceInput?.value); const unitPrice=Number.isFinite(enteredPrice)&&enteredPrice>=0?enteredPrice:(action==='Sold'?Number(p.sell||0):Number(p.buy||0));
 const movementId=id();
 if(action==='Sold'){
   if(qty>Number(p.qty||0))return toast(`Not enough ${p.name}. Only ${p.qty} remaining.`);
   const revenueValue=qty*unitPrice, cogs=qty*Number(p.buy||0);
   const remainingAfter=Number(p.qty||0)-qty;
   post('Sale',`Sold ${p.name}`,revenueValue,'1000','4000',today(),{product:p.name,qty,movementId,unitSell:unitPrice,unitBuy:Number(p.buy||0),remainingAfter});
   if(cogs>0)post('COGS',`Cost of ${p.name} sold`,cogs,'5000','1200',today(),{product:p.name,qty,movementId,unitSell:unitPrice,unitBuy:Number(p.buy||0),remainingAfter});
   p.qty=remainingAfter; p.soldQty=Number(p.soldQty||0)+qty; p.soldValue=Number(p.soldValue||0)+revenueValue; p.grossProfit=Number(p.grossProfit||0)+(revenueValue-cogs);
 } else {
   const amount=qty*unitPrice; const remainingAfter=Number(p.qty||0)+qty;
   post('Purchase',`Bought ${p.name}`,amount,'1200','1000',today(),{product:p.name,qty,movementId,unitSell:Number(p.sell||0),unitBuy:unitPrice,remainingAfter}); p.qty=remainingAfter;
 }
 save(); toast(`${p.name}: ${action.toLowerCase()} ${qty} at ${money(unitPrice)} per unit. Stock, money and profit updated automatically.`); render();
}
function smallBusinessActivities(){
 const movements=[]; const seen=new Set();
 for(const t of state.tx.slice().reverse()){
   if(!['Sale','Purchase'].includes(t.kind) || !t.product || seen.has(t.movementId||t.id)) continue;
   const key=t.movementId||t.id; seen.add(key);
   const p=findShopProduct(t.product); const qty=Number(t.qty||0); const buy=Number(t.unitBuy??p?.buy??0); const sell=Number(t.unitSell??p?.sell??0);
   const sale=t.kind==='Sale'; const revenue=sale?Number(t.amount||0):0; const cost=sale?qty*buy:Number(t.amount||0); const gp=sale?revenue-cost:0;
   movements.push({id:key,kind:t.kind,date:t.date,product:t.product,qty,buy,sell,revenue,cost,gp,remaining:Number(t.remainingAfter??p?.qty??0)});
 }
 if(!movements.length) return '<div class="empty">No shop activity yet. Record a sale or purchase above.</div>';
 return `<div class="shopActivityTableWrap"><table class="shopActivityTable"><thead><tr><th>Date</th><th>Activity</th><th>Product</th><th>Qty</th><th>Price / unit</th><th>Sales / Spend</th><th>Cost / unit</th><th>Profit</th><th>Stock left</th><th>Action</th></tr></thead><tbody>${movements.map(m=>`<tr><td>${m.date}</td><td><span class="tag ${m.kind==='Sale'?'saleTag':'purchaseTag'}">${m.kind}</span></td><td><b>${esc(m.product)}</b></td><td>${m.qty.toLocaleString()}</td><td>${money(m.kind==='Sale'?m.sell:m.buy)}</td><td>${money(m.kind==='Sale'?m.revenue:m.cost)}</td><td>${m.kind==='Sale'?money(m.buy):'—'}</td><td>${m.kind==='Sale'?money(m.gp):'—'}</td><td>${m.remaining.toLocaleString()}</td><td><button class="deleteBtn" onclick="deleteShopMovement('${esc(m.id)}')">Delete</button></td></tr>`).join('')}</tbody></table></div>`;
}
function deleteShopMovement(movementId){
 let targets=state.tx.filter(t=>(t.movementId||t.id)===movementId && ['Sale','COGS','Purchase'].includes(t.kind));
 if(!targets.length)return toast('Transaction not found');
 const primary=targets.find(t=>t.kind==='Sale'||t.kind==='Purchase')||targets[0];
 // Older sales may not have a movementId. Pull their matching COGS entry into the same deletion.
 if(primary.kind==='Sale' && !primary.movementId){
   const related=state.tx.find(t=>t.kind==='COGS' && t.product===primary.product && t.date===primary.date && Number(t.qty||0)===Number(primary.qty||0));
   if(related) targets=[...targets,related];
 }
 if(!confirm(`Delete this ${primary.kind.toLowerCase()}?\n\n${primary.description} — ${money(primary.amount)}\nThe stock and all related totals will be reversed.`))return;
 const productName=primary.product, qty=Number(primary.qty||0), p=findShopProduct(productName);
 if(p && qty){
   if(primary.kind==='Sale'){
     p.qty=Number(p.qty||0)+qty;
     p.soldQty=Math.max(0,Number(p.soldQty||0)-qty);
     p.soldValue=Math.max(0,Number(p.soldValue||0)-Number(primary.amount||0));
     const cogs=targets.find(t=>t.kind==='COGS'); const cogsAmount=Number(cogs?.amount||qty*Number(p.buy||0));
     p.grossProfit=Number(p.grossProfit||0)- (Number(primary.amount||0)-cogsAmount);
   } else if(primary.kind==='Purchase') {
     const newQty=Number(p.qty||0)-qty;
     if(newQty<0)return toast(`Cannot delete this purchase because ${p.name} has already used some of that stock.`);
     p.qty=newQty;
   }
 }
 state.tx=state.tx.filter(t=>(t.movementId||t.id)!==movementId);
 save(); toast('Transaction deleted. Stock, sales, purchases and profit were recalculated.'); render();
}

function deleteShopProduct(productId){
 const p=(state.products||[]).find(x=>x.id===productId);
 if(!p)return toast('Stock item not found');
 const activityCount=state.tx.filter(t=>t.product===p.name && ['Sale','Purchase','COGS'].includes(t.kind)).length;
 const historyNote=activityCount?`\n\n${activityCount} related transaction${activityCount===1?'':'s'} will remain in Accounting Transaction Records as historical records.`:'';
 if(!confirm(`Delete ${p.name} from your shop stock?${historyNote}\n\nThe current stock item and its opening-stock entry will be removed. Dashboard stock totals will recalculate immediately.`))return;
 state.tx=state.tx.filter(t=>!(t.product===p.name && t.kind==='Opening Stock'));
 state.products=state.products.filter(x=>x.id!==productId);
 save(); toast(`${p.name} stock item deleted. Dashboard stock totals recalculated.`); render();
}

function addShopProduct(){
 go('small');
 setTimeout(()=>document.querySelector('#sbProductName')?.focus(),0);
}

function shopPreviewHtml(){
 const x=shopPreviewLogic(); if(!x.name)return `<div class="autoSummary"><span>READY</span><b>Type an item, what happened, and quantity.</b><small>Example: Sukari sold 10. Stock, cash, sales and reports update together.</small></div>`;
 if(!x.p)return `<div class="autoSummary warn"><span>NEW ITEM</span><b>${esc(x.name)} is not in the shop list yet.</b><small>Add it once using “Add item”, then daily entries can be one-line simple.</small></div>`;
 return `<div class="autoSummary"><span>AUTOMATIC RESULT</span><b>${esc(x.action)} ${esc(x.p.name)} × ${Number(x.qty).toLocaleString()} · ${money(x.value)}</b><small>Remaining stock ${Number(x.remaining||0).toLocaleString(undefined,{maximumFractionDigits:2})} · ${x.action==='Sold'?'Cash in + Sales Revenue + COGS':'Inventory increases + Cash out'}</small></div>`;
}
function mini(a,b,c,k){return `<button class="miniCard" onclick="toast('The ${a.toLowerCase()} workspace is ready for the next module.')"><span>${a}</span><strong>${b}</strong><small>${c} →</small></button>`}
function quickForm(compact){
 const types=[['Sale','Money received from a sale'],['Expense','Business expense paid now'],['Purchase','Stock or goods purchased'],['Receive Money','Money received into cash/bank'],['Pay Money','Money paid to a supplier or other account'],['Owner Capital','Owner puts money into the business'],['Owner Draw','Owner takes money out'],['Transfer','Move money between accounts'],['Credit Sale','Sale made on credit'],['Credit Purchase','Purchase made on credit']];
 return `<form class="quickForm" onsubmit="submitQuick(event)">
  <div class="formTitle"><div><span class="spark">✦</span><h2>${compact?'Quick transaction':'New transaction'}</h2></div><span class="autoBadge">AUTO POST</span></div>
  <label>What happened?<select id="qKind" onchange="updatePreview()">${types.map(x=>`<option value="${x[0]}">${x[0]} — ${x[1]}</option>`).join('')}</select></label>
  <div class="formGrid"><label>Account / category<select id="qTo" onchange="updatePreview()">${accountOptions('4000')}</select></label><label>Money account<select id="qFrom" onchange="updatePreview()">${accountOptions('1000')}</select></label></div>
  <label>Amount (KES)<input id="qAmount" type="number" min="0" step="0.01" placeholder="0.00" oninput="updatePreview()" required></label>
  <label>Description <input id="qDesc" placeholder="e.g. Sale of goods"></label>
  <div class="smartHint">💡 You can type/search an account. The system will still decide which side is debit and which side is credit.</div>
  <button class="primary wide">✓ Post transaction automatically</button>
 </form>`;
}
function previewLogic(){
 const kind=document.querySelector('#qKind')?.value||'Sale', amount=Number(document.querySelector('#qAmount')?.value)||0;
 let from=document.querySelector('#qFrom')?.value||'1000', to=document.querySelector('#qTo')?.value||'4000';
 if(kind==='Sale'){from='1000';to='4000'}
 if(kind==='Expense'){from=document.querySelector('#qFrom')?.value||'1000';to=document.querySelector('#qTo')?.value||'6080'}
 if(kind==='Purchase'){from=document.querySelector('#qFrom')?.value||'1000';to=document.querySelector('#qTo')?.value||'5010'}
 if(kind==='Owner Capital'){from=document.querySelector('#qFrom')?.value||'1000';to='3000'}
 if(kind==='Owner Draw'){from='3010';to=document.querySelector('#qFrom')?.value||'1000'}
 if(kind==='Credit Sale'){from='1100';to='4000'}
 if(kind==='Credit Purchase'){from='1200';to='2000'}
 if(kind==='Transfer'){to=document.querySelector('#qTo')?.value||'1010'}
 if(kind==='Receive Money'){from=document.querySelector('#qFrom')?.value||'1000';to=document.querySelector('#qTo')?.value||'4000'}
 if(kind==='Pay Money'){from=document.querySelector('#qTo')?.value||'6080';to=document.querySelector('#qFrom')?.value||'1000'}
 return {kind,amount,from,to};
}
function previewHtml(){const p=previewLogic();return `<div class="journalPreview"><div><span>DEBIT</span><b>${label(p.from)}</b><strong>${money(p.amount)}</strong></div><div class="swap">↕</div><div><span>CREDIT</span><b>${label(p.to)}</b><strong>${money(p.amount)}</strong></div></div>`}
function updatePreview(){const el=document.querySelector('#preview');if(el)el.innerHTML=previewHtml()}
function submitQuick(e){e.preventDefault();const p=previewLogic();if(!p.amount)return toast('Enter an amount first');const d=document.querySelector('#qDesc')?.value||p.kind;post(p.kind,d,p.amount,p.from,p.to);toast('Transaction posted — all reports recalculated');render()}
function transactions(){
 return `<div class="pageIntro"><div><span class="eyebrow">ACCOUNTING TRANSACTION RECORDS</span><h1>One source of truth</h1><p>Every simple transaction becomes balanced double-entry records automatically.</p></div><button class="primary" onclick="go('small')">＋ New transaction</button></div>
 <div class="cards">${card('Debits',money(totalDebit()),'D','neutral')}${card('Credits',money(totalCredit()),'C','neutral')}${card('Balanced','Yes','✓','positive')}${card('Entries',state.tx.length,'#','neutral')}</div>
 <div class="panel">${txTable(state.tx.slice().reverse(),true)}</div>`;
}
function deleteTransaction(txId){ const t=state.tx.find(x=>x.id===txId); if(!t)return; if(t.movementId)return deleteShopMovement(t.movementId); if(!confirm(`Remove this transaction?\n\n${t.description} — ${money(t.amount)}`))return; state.tx=state.tx.filter(x=>x.id!==txId); save(); toast('Transaction removed. All reports recalculated.'); render(); }
function txTable(list,full=false){if(!list.length)return '<div class="empty">No transactions yet.</div>';return `<div class="tableWrap"><table><thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Debit</th><th>Credit</th><th>Status</th>${full?'<th>Action</th>':''}</tr></thead><tbody>${list.map(t=>`<tr><td>${t.date}</td><td><span class="tag">${esc(t.kind)}</span></td><td>${esc(t.description)}</td><td>${money(t.amount)}</td><td>${money(t.amount)}</td><td><span class="status">Balanced</span></td>${full?`<td><button class="deleteBtn" onclick="deleteTransaction('${t.id}')">Remove</button></td>`:''}</tr>`).join('')}</tbody></table></div>`}
function accountingPage(){
 const q=(window.accountQuery||'').toLowerCase(), filter=window.accountFilter||'All';
 const list=state.coa.filter(a=>(filter==='All'||a.type===filter)&&(`${a.code} ${a.name} ${a.group} ${a.type}`.toLowerCase().includes(q)));
 return `<div class="pageIntro"><div><span class="eyebrow">ACCOUNTING MODE</span><h1>Choose the account — we detect the accounting</h1><p>No debit/credit typing. Pick the account for what happened and enter the amount. The normal accounting side and cash/inventory counterpart are selected automatically.</p></div></div>
 <div class="grid2">
  <div class="panel accountingEntry"><div class="formTitle"><div><span class="spark">✦</span><h2>Automatic accounting entry</h2></div><span class="autoBadge">SMART DEBIT / CREDIT</span></div>
   <label class="bigLabel">Account for what happened<select id="aAccount" onchange="updateAccountingPreview()">${smartAccountOptions('4000')}</select></label>
   <label class="bigLabel">Amount (KES)<input id="aAmount" type="number" min="0" step="0.01" placeholder="0.00" oninput="updateAccountingPreview()"></label>
   <div id="accountingPreview">${accountingPreviewHtml()}</div>
   <button class="primary wide" onclick="submitAccountingEntry()">✓ Post automatically</button>
  </div>
  <div class="panel"><h2>How it works</h2><div class="autoRules"><div><b>Income</b><span>Cash/Bank → Income</span></div><div><b>Expense</b><span>Expense → Cash/Bank</span></div><div><b>Asset / Inventory</b><span>Asset → Cash/Bank</span></div><div><b>Liability</b><span>Cash/Bank → Liability</span></div><div><b>Equity</b><span>Cash/Bank → Equity</span></div></div></div>
 </div>
 <div class="toolbar"><input placeholder="⌕ Search account, code or category..." value="${esc(window.accountQuery||'')}" oninput="window.accountQuery=this.value;render()"><div class="filters">${['All','Asset','Liability','Equity','Income','Expense','Cost of Sales'].map(f=>`<button class="${filter===f?'on':''}" onclick="window.accountFilter='${f}';render()">${f}</button>`).join('')}</div></div>
 <div class="accountGrid">${list.map(a=>`<div class="accountCard type-${a.type.replaceAll(' ','-')}"><div class="code">${a.code}</div><h3>${esc(a.name)}</h3><span class="pill">${a.type}</span><small>${esc(a.group)} · Balance ${money(balance(a.code))}</small></div>`).join('')}</div>`;
}
function autoCounterpart(a){
 if(!a)return '1000';
 if(a.type==='Income')return '1000';
 if(a.type==='Expense'||a.type==='Cost of Sales'||a.type==='Asset')return a.code==='1000'?'3000':'1000';
 if(a.type==='Liability'||a.type==='Equity')return '1000';
 return '1000';
}
function accountingPreviewLogic(){
 const code=document.querySelector('#aAccount')?.value||'4000', amount=Number(document.querySelector('#aAmount')?.value)||0, a=acct(code), c=acct(autoCounterpart(a));
 const selectedIsDebit=a&&['Asset','Expense','Cost of Sales'].includes(a.type);
 return {a,c,amount,selectedIsDebit};
}
function accountingPreviewHtml(){
 const x=accountingPreviewLogic(); if(!x.a)return '';
 const debit=x.selectedIsDebit?x.a:x.c, credit=x.selectedIsDebit?x.c:x.a;
 return `<div class="journalPreview"><div><span>DEBIT — automatic</span><b>${label(debit.code)}</b><strong>${money(x.amount)}</strong></div><div class="swap">↕</div><div><span>CREDIT — automatic</span><b>${label(credit.code)}</b><strong>${money(x.amount)}</strong></div></div>`;
}
function updateAccountingPreview(){const el=document.querySelector('#accountingPreview');if(el)el.innerHTML=accountingPreviewHtml()}
function submitAccountingEntry(){
 const x=accountingPreviewLogic(); if(!x.amount)return toast('Enter an amount first');
 const debit=x.selectedIsDebit?x.a:x.c, credit=x.selectedIsDebit?x.c:x.a;
 if(debit.code===credit.code)return toast('Choose a different account');
 post('Accounting',x.a.name,x.amount,debit.code,credit.code);toast('Posted. Debit, credit and all reports recalculated automatically.');render();
}


function supportPage(){
 const phone='254797030315';
 const wa=`https://wa.me/${phone}?text=${encodeURIComponent('Hello BizCashFlow Support, I need help with my account.')}`;
 const tel=`tel:+${phone}`;
 const sms=`sms:+${phone}`;
 return `<div class="pageIntro"><div><span class="eyebrow">HELP & SUPPORT</span><h1>We are here to help 💬</h1><p>If a customer has a question, they can contact BizCashFlow directly. Normal accounting use remains offline.</p></div></div>
 <div class="supportGrid">
   <div class="supportHero panel"><div class="supportMascot">💬</div><div><h2>Need help?</h2><p>Chat with BizCashFlow support on WhatsApp, send an SMS, or call.</p><div class="supportButtons"><a class="supportBtn whatsapp" href="${wa}" target="_blank" rel="noopener">💬 WhatsApp</a><a class="supportBtn" href="${tel}">📞 Call 0797030315</a><a class="supportBtn" href="${sms}">✉️ Text</a></div></div></div>
   <div class="panel"><h2>Admin & user management</h2><p class="smallMuted">BizCashFlow is being built offline-first. Each customer's phone keeps working without internet.</p><div class="adminStatus"><span>Offline accounting</span><b>ON</b></div><div class="adminStatus"><span>Optional cloud sync</span><b class="soon">READY FOR FINAL APP</b></div><p class="smallMuted">When optional internet sync is added, your secure Admin Portal will let you see registered users, app activity, support requests and device sync status. Users will not need internet for normal sales, stock or accounting.</p></div>
 </div>`;
}

function credits(){return `<div class="pageIntro"><div><span class="eyebrow">CREDIT RECORDS</span><h1>Customers & suppliers</h1><p>Credit transactions automatically use Accounts Receivable or Accounts Payable.</p></div></div><div class="grid2"><div class="panel"><h2>Customer credit</h2><p>Credit Sales debit Accounts Receivable and credit Sales Revenue.</p><button class="primary" onclick="go('small')">Create credit sale</button></div><div class="panel"><h2>Supplier credit</h2><p>Credit Purchases debit Inventory/Purchases and credit Accounts Payable.</p><button class="primary" onclick="go('small')">Create credit purchase</button></div></div>`}
function reports(){
 const rev=revenue(), exp=expenses(), prof=profit();
 const bs=state.coa.filter(a=>['Asset','Liability','Equity'].includes(a.type));
 return `<div class="pageIntro"><div><span class="eyebrow">FINANCIAL REPORTS</span><h1>Everything recalculates automatically</h1><p>Reports are derived from the same transaction ledger — no duplicate figures to maintain.</p></div></div>
 <div class="cards">${card('Revenue',money(rev),'↗','positive')}${card('Expenses',money(exp),'↘','negative')}${card('Net profit',money(prof),'◆',prof>=0?'positive':'negative')}${card('Balance check',money(totalDebit()-totalCredit()),'=',totalDebit()===totalCredit()?'positive':'negative')}</div>
 <div class="grid2"><div class="panel"><h2>Profit & Loss</h2><div class="reportRows"><div><span>Income</span><b>${money(rev)}</b></div><div><span>Cost & expenses</span><b>${money(exp)}</b></div><div class="total"><span>Net profit</span><b>${money(prof)}</b></div></div></div>
 <div class="panel"><h2>Trial Balance</h2>${trialTable()}</div></div>
 <div class="panel"><h2>Balance Sheet</h2><div class="reportRows">${bs.map(a=>`<div><span>${a.code} · ${a.name}</span><b>${money(balance(a.code))}</b></div>`).join('')}<div class="total"><span>Assets = Liabilities + Equity (check)</span><b>${money(state.coa.filter(a=>a.type==='Asset').reduce((s,a)=>s+balance(a.code),0)-state.coa.filter(a=>['Liability','Equity'].includes(a.type)).reduce((s,a)=>s+(-balance(a.code)),0))}</b></div></div></div>`;
}
function trialTable(){const list=state.coa.map(a=>({a,d:rows().filter(r=>r.account===a.code).reduce((s,r)=>s+r.debit,0),c:rows().filter(r=>r.account===a.code).reduce((s,r)=>s+r.credit,0)})).filter(x=>x.d||x.c);return `<div class="tableWrap"><table><thead><tr><th>Account</th><th>Debit</th><th>Credit</th></tr></thead><tbody>${list.map(x=>`<tr><td>${x.a.code} · ${x.a.name}</td><td>${money(x.d)}</td><td>${money(x.c)}</td></tr>`).join('')}</tbody></table></div>`}
function exportPage(){return `<div class="pageIntro"><div><span class="eyebrow">DATA</span><h1>Export & Backup</h1><p>Keep your business data portable.</p></div></div><div class="grid2"><div class="panel"><h2>Download backup</h2><p>Exports accounts, transactions and business lists as JSON.</p><button class="primary" onclick="downloadBackup()">⇩ Download backup</button></div><div class="panel"><h2>Reset demo data</h2><p>Start a clean company from the standard chart of accounts.</p><button class="danger" onclick="resetData()">Reset data</button></div></div>`}
function settings(){return `<div class="pageIntro"><div><span class="eyebrow">SETTINGS</span><h1>Make it yours</h1><p>Smart defaults, motion and a comfortable light/dark workspace.</p></div></div><div class="grid2"><div class="panel"><h2>Appearance</h2><div class="setting"><span>Dark mode</span><button class="toggle ${state.theme==='dark'?'on':''}" onclick="toggleTheme()">●</button></div><div class="setting"><span>Animations</span><button class="toggle on"><span>●</span></button></div></div><div class="panel"><h2>Accounting behavior</h2><div class="setting"><span>Automatic double-entry posting</span><b class="status">ON</b></div><div class="setting"><span>Automatic report recalculation</span><b class="status">ON</b></div><div class="setting"><span>Standard chart of accounts</span><b class="status">READY</b></div></div></div>`}

function salesPage(){
 return `<div class="pageIntro"><div><span class="eyebrow">SALES</span><h1>Sales & Invoices</h1><p>Enter a sale once. Cash or Accounts Receivable and Sales Revenue are posted automatically.</p></div><button class="primary" onclick="newSale()">＋ New sale</button></div>
 <div class="cards">${card('Invoices',state.invoices?.length||0,'#','neutral')}${card('Sales revenue',money(revenue()),'↗','positive')}${card('Receivables',money(balance('1100')),'AR','neutral')}${card('Cash',money(balance('1000')),'K','positive')}</div>
 <div class="panel"><div class="panelHead"><div><h2>Sales register</h2><p>Paid sales use Cash; credit sales use Accounts Receivable.</p></div></div>${state.invoices?.length?invoiceTable(state.invoices):'<div class="empty">No invoices yet. Create your first sale.</div>'}</div>`;
}
function newSale(){
 const customer=prompt('Customer name (optional)')||'Walk-in customer';
 const description=prompt('What was sold?')||'Sale';
 const amount=Number(prompt('Amount (KES)')||0); if(!amount)return;
 const credit=confirm('Is this a credit sale? OK = credit, Cancel = paid now');
 const debit=credit?'1100':'1000';
 post('Sale: '+description,'Sale',amount,debit,'4000',today(),{customer});
 state.invoices=state.invoices||[];
 state.invoices.push({id:'INV-'+String(state.invoices.length+1).padStart(4,'0'),date:today(),customer,description,amount,status:credit?'Credit':'Paid'});
 save(); toast('Sale posted and invoice created'); render();
}
function invoiceTable(list){
 return `<div class="tableWrap"><table><thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Description</th><th>Amount</th><th>Status</th></tr></thead><tbody>
 ${list.slice().reverse().map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${x.date}</td><td>${esc(x.customer)}</td><td>${esc(x.description)}</td><td>${money(x.amount)}</td><td><span class="status">${esc(x.status)}</span></td></tr>`).join('')}
 </tbody></table></div>`;
}
function purchasesPage(){
 return `<div class="pageIntro"><div><span class="eyebrow">PURCHASES</span><h1>Purchases & Bills</h1><p>Record a purchase once. Purchases/Inventory and Cash or Accounts Payable are posted automatically.</p></div><button class="primary" onclick="newPurchase()">＋ New purchase</button></div>
 <div class="cards">${card('Bills',state.bills?.length||0,'#','neutral')}${card('Purchases',money(balance('5010')),'P','neutral')}${card('Payables',money(-balance('2000')),'AP','negative')}${card('Inventory',money(balance('1200')),'I','positive')}</div>
 <div class="panel">${state.bills?.length?billTable(state.bills):'<div class="empty">No purchases yet. Create your first purchase.</div>'}</div>`;
}
function newPurchase(){
 const supplier=prompt('Supplier name (optional)')||'Cash supplier';
 const description=prompt('What did you purchase?')||'Purchase';
 const amount=Number(prompt('Amount (KES)')||0); if(!amount)return;
 const credit=confirm('Bought on supplier credit? OK = credit, Cancel = paid now');
 post('Purchase: '+description,'Purchase',amount,'5010',credit?'2000':'1000',today(),{supplier});
 state.bills=state.bills||[];
 state.bills.push({id:'BILL-'+String(state.bills.length+1).padStart(4,'0'),date:today(),supplier,description,amount,status:credit?'Credit':'Paid'});
 save(); toast('Purchase posted and bill created'); render();
}
function billTable(list){
 return `<div class="tableWrap"><table><thead><tr><th>Bill</th><th>Date</th><th>Supplier</th><th>Description</th><th>Amount</th><th>Status</th></tr></thead><tbody>
 ${list.slice().reverse().map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${x.date}</td><td>${esc(x.supplier)}</td><td>${esc(x.description)}</td><td>${money(x.amount)}</td><td><span class="status">${esc(x.status)}</span></td></tr>`).join('')}
 </tbody></table></div>`;
}
function expensesPage(){
 const expenseAccounts=state.coa.filter(a=>a.type==='Expense');
 return `<div class="pageIntro"><div><span class="eyebrow">EXPENSES</span><h1>Expense capture</h1><p>Pick the expense category, type the amount and the system creates the debit and cash credit automatically.</p></div><button class="primary" onclick="newExpense()">＋ New expense</button></div>
 <div class="panel"><div class="panelHead"><div><h2>Quick expense categories</h2><p>No need to type account codes.</p></div></div><div class="chips">${expenseAccounts.map(a=>`<button onclick="postExpense('${a.code}')">${esc(a.name)}</button>`).join('')}</div></div>`;
}
function postExpense(code){
 const amount=Number(prompt(`Amount for ${state.coa.find(a=>a.code===code).name} (KES)`)||0); if(!amount)return;
 post(state.coa.find(a=>a.code===code).name,'Expense',amount,code,'1000');
 toast('Expense posted and reports recalculated'); render();
}
function newExpense(){
 const name=prompt('Expense category, e.g. Fuel, Rent, Office Supplies')||'Miscellaneous Expense';
 const found=state.coa.find(a=>a.name.toLowerCase()===name.toLowerCase())||state.coa.find(a=>a.code==='6270');
 const amount=Number(prompt('Amount (KES)')||0); if(!amount)return;
 post(found.name,'Expense',amount,found.code,'1000'); toast('Expense posted automatically'); render();
}
function inventoryPage(){
 state.products=state.products||[];
 const units=state.products.reduce((s,p)=>s+Number(p.qty||0),0);
 const value=state.products.reduce((s,p)=>s+Number(p.qty||0)*Number(p.buy||0),0);
 return `<div class="pageIntro"><div><span class="eyebrow">PRODUCTS & INVENTORY</span><h1>Products and stock</h1><p>Keep buying price, selling price and quantities together. Use products in your operating workflow.</p></div><button class="primary" onclick="addProduct()">＋ New product</button></div>
 <div class="cards">${card('Products',state.products.length,'#','neutral')}${card('Stock units',units,'□','neutral')}${card('Stock value',money(value),'◆','positive')}${card('Inventory account',money(balance('1200')),'I','positive')}</div>
 <div class="panel">${state.products.length?`<div class="productGrid">${state.products.map(p=>`<div class="productCard"><span>${esc(p.unit||'pieces')}</span><h3>${esc(p.name)}</h3><p>Buy ${money(p.buy)} · Sell ${money(p.sell)}</p><b>${p.qty} in stock</b></div>`).join('')}</div>`:'<div class="empty">No products yet. Add your first product.</div>'}</div>`;
}
function addProduct(){addShopProduct()}
function contactsPage(){
 state.customers=state.customers||[]; state.suppliers=state.suppliers||[];
 return `<div class="pageIntro"><div><span class="eyebrow">BUSINESS CONTACTS</span><h1>Customers & Suppliers</h1><p>Credit sales connect to Accounts Receivable; credit purchases connect to Accounts Payable.</p></div></div>
 <div class="grid2"><div class="panel"><div class="panelHead"><h2>Customers</h2><button class="link" onclick="addContact('customer')">＋ Add</button></div>${contactList(state.customers,'customer')}</div>
 <div class="panel"><div class="panelHead"><h2>Suppliers</h2><button class="link" onclick="addContact('supplier')">＋ Add</button></div>${contactList(state.suppliers,'supplier')}</div></div>`;
}
function contactList(list,type){
 if(!list.length)return '<div class="empty">No contacts yet.</div>';
 return list.map(x=>`<div class="contactRow"><span>${esc((x.name||'?')[0].toUpperCase())}</span><div><b>${esc(x.name)}</b><small>${esc(x.phone||'')} · ${type}</small></div></div>`).join('');
}
function addContact(type){
 const name=prompt((type==='customer'?'Customer':'Supplier')+' name'); if(!name)return;
 const phone=prompt('Phone (optional)')||'';
 state[type==='customer'?'customers':'suppliers']=state[type==='customer'?'customers':'suppliers']||[];
 state[type==='customer'?'customers':'suppliers'].push({id:id(),name,phone}); save(); toast('Contact saved'); render();
}

function setMode(m){state.mode=m;save();render()}
function toggleTheme(){state.theme=state.theme==='dark'?'light':'dark';save();render()}

function addAccount(){const name=prompt('Account name');if(!name)return;const code=prompt('Account code (e.g. 9990)');if(!code)return;const type=prompt('Type: Asset, Liability, Equity, Income, Expense')||'Expense';state.coa.push({code,name,type,group:'Custom',normal:type==='Asset'||type==='Expense'?'Debit':'Credit'});save();render()}
function resetData(){if(confirm('Reset all demo data?')){state={...safeClone(seed),coa:safeClone(coaSeed)};save();render()}}
function downloadBackup(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='bizcashflow-backup.json';a.click();URL.revokeObjectURL(a.href)}
function toast(msg){let x=document.querySelector('.toast');if(x)x.remove();x=document.createElement('div');x.className='toast';x.textContent=msg;document.body.appendChild(x);setTimeout(()=>x.remove(),2600)}
window.go=go;window.render=render;window.dashFill=dashFill;window.dashQuickEntry=dashQuickEntry;window.saveShopProduct=saveShopProduct;window.recordShopMovement=recordShopMovement;window.loginSubmit=loginSubmit;window.logout=logout;window.resetLogin=resetLogin;window.toggleTheme=toggleTheme;window.updatePreview=updatePreview;window.submitQuick=submitQuick;window.setMode=setMode;window.addAccount=addAccount;window.resetData=resetData;window.downloadBackup=downloadBackup;window.toast=toast;window.deleteTransaction=deleteTransaction;
window.deleteShopProduct=deleteShopProduct;window.newSale=newSale;window.newPurchase=newPurchase;window.newExpense=newExpense;window.postExpense=postExpense;window.addProduct=addProduct;window.addContact=addContact;window.setShopAction=setShopAction;window.updateShopPreview=updateShopActivityPreview;window.submitShopEntry=recordShopMovement;window.addShopProduct=addShopProduct;window.updateAccountingPreview=updateAccountingPreview;window.submitAccountingEntry=submitAccountingEntry;
window.addEventListener('error',e=>{console.error(e.error||e.message); const app=document.querySelector('#app'); if(app && !app.innerHTML.trim()) app.innerHTML=`<div style="min-height:100vh;display:grid;place-items:center;padding:30px;background:#f5f7fb;font-family:system-ui"><div style="max-width:650px;background:#fff;border-radius:24px;padding:30px;box-shadow:0 20px 60px rgba(0,0,0,.12)"><h1>BizCashFlow could not start</h1><p>Please close this tab, stop the terminal with Ctrl+C, and start the new BizCashFlow version again.</p><button onclick="location.reload()" style="padding:12px 18px;border:0;border-radius:12px;background:#17263b;color:#fff">Refresh</button></div></div>`;});
window.addEventListener('unhandledrejection',e=>console.error(e.reason));
window.addEventListener('hashchange',render); if(!location.hash)location.hash='/dashboard'; try{render()}catch(e){console.error(e); const app=document.querySelector('#app'); if(app) app.innerHTML=`<div style="padding:40px;font-family:system-ui"><h1>BizCashFlow needs a refresh</h1><p>The app hit a startup error. Please restart the new version.</p></div>`;}
