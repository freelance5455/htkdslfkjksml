import { initializeApp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-app.js";
import { getDatabase, ref, push, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.4.0/firebase-database.js";

// Import modules
import { localKnowledge } from "./knowledge.js";
import { triggerAIAnimation } from "./three-bg.js";

// Firebase Configuration (आपका दिया हुआ)
const firebaseConfig = {
    apiKey: "AIzaSyAn9uKVXXk4KnoxNpRcC3A4DRjzNRLdKNk",
    projectId: "mycontrolapp-aryan",
    storageBucket: "mycontrolapp-aryan.firebasestorage.app",
    appId: "1:982887245160:android:81f0f2f1429c8d9e5522dd",
    databaseURL: "https://mycontrolapp-aryan-default-rtdb.firebaseio.com"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// --- STATE MANAGEMENT ---
let currentUser = "Guest";
let isWaitingForAnswer = false;
let pendingQuestion = "";

// --- DOM ELEMENTS ---
const authScreen = document.getElementById('auth-screen');
const chatUI = document.getElementById('chat-ui');
const chatBox = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

// --- AUTHENTICATION LOGIC ---
function switchAuth(type) {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('signup-form').style.display = 'none';
    document.getElementById('google-form').style.display = 'none';
    document.getElementById(`${type}-form`).style.display = 'block';
}

function doLogin(email = "User") {
    currentUser = email;
    authScreen.style.display = 'none';
    chatUI.style.display = 'flex';
    
    setTimeout(() => {
        appendMessage(`सिस्टम ऑनलाइन है। वेलकम <strong>${currentUser}</strong>। मैं <strong>S sanskar ai</strong> हूँ। मैं आपकी कैसे मदद कर सकता हूँ?`, 'ai');
        triggerAIAnimation(true);
    }, 500);
}

// Event Listeners for Auth Buttons
document.getElementById('btn-show-google').addEventListener('click', () => switchAuth('google'));
document.getElementById('link-to-signup').addEventListener('click', () => switchAuth('signup'));
document.getElementById('link-to-login').addEventListener('click', () => switchAuth('login'));
document.getElementById('link-google-cancel').addEventListener('click', () => switchAuth('login'));
document.getElementById('btn-login-manual').addEventListener('click', () => doLogin(document.getElementById('login-user').value || "User"));
document.getElementById('btn-signup-manual').addEventListener('click', () => doLogin("New User"));

// Handle mock Google Emails clicks
document.querySelectorAll('.email-item').forEach(item => {
    item.addEventListener('click', (e) => {
        doLogin(e.target.getAttribute('data-email'));
    });
});

// --- CHAT & LEARNING LOGIC ---
function appendMessage(text, sender) {
    const wrapper = document.createElement('div');
    wrapper.className = `msg-wrapper ${sender}`;
    const msgDiv = document.createElement('div');
    msgDiv.className = `msg ${sender}-msg`;
    msgDiv.innerHTML = text;
    wrapper.appendChild(msgDiv);
    chatBox.appendChild(wrapper);
    chatBox.scrollTop = chatBox.scrollHeight;
}

async function handleSend() {
    const text = userInput.value.trim();
    if (!text) return;
    
    appendMessage(text, 'user');
    userInput.value = '';

    // अगर AI यूज़र से जवाब का इंतज़ार कर रहा है (Learning Mode)
    if (isWaitingForAnswer) {
        // तुरंत मेमोरी में सेव करें
        localKnowledge.push({ keywords: [pendingQuestion.toLowerCase()], reply: text });
        
        // Firebase में सेव करें
        try {
            await push(ref(db, 'ssanskar_ai_trained_knowledge'), {
                question: pendingQuestion, 
                learned_answer: text, 
                trainer_email: currentUser, 
                timestamp: serverTimestamp()
            });
        } catch (e) { console.error(e); }
        
        setTimeout(() => {
            triggerAIAnimation(true);
            appendMessage(`धन्यवाद! मैंने इसे सीख लिया है। अब मुझे पता है कि <strong>"${pendingQuestion}"</strong> का जवाब क्या है। अगली बार मैं खुद बता दूंगा!`, 'ai');
        }, 600);
        
        isWaitingForAnswer = false; 
        pendingQuestion = "";
        return;
    }

    // अगर नॉर्मल सवाल है, तो Knowledge Base में ढूँढें
    let aiResponse = null;
    let lowerInput = text.toLowerCase();
    
    for (let data of localKnowledge) {
        for (let key of data.keywords) {
            if (lowerInput.includes(key)) {
                aiResponse = data.reply;
                break;
            }
        }
        if(aiResponse) break;
    }

    setTimeout(async () => {
        if (aiResponse) {
            // जवाब पता है
            appendMessage(aiResponse, 'ai');
            triggerAIAnimation(true);
        } else {
            // जवाब नहीं पता - Training Request
            triggerAIAnimation(false);
            isWaitingForAnswer = true;
            pendingQuestion = text;
            
            appendMessage(`भाई, मैं <strong>S sanskar ai</strong> हूँ। मैं अभी सीख रहा हूँ और मैं किसी भी चीज़ का फेक जवाब नहीं दे सकता। <br><span class="train-text">प्लीज़ इसका जवाब मेरे को बताओ, मैं खुद को ट्रेन कर रहा हूँ ताकि मैं इसका जवाब सीख पाऊं...</span>`, 'ai');
            
            // Unanswered सवाल को Firebase में डालें
            try {
                await push(ref(db, 'ssanskar_ai_learning_data'), { 
                    question: text, 
                    asked_by: currentUser, 
                    status: "waiting_for_user_answer",
                    timestamp: serverTimestamp()
                });
            } catch (e) { console.error(e); }
        }
    }, 600);
}

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSend(); });
