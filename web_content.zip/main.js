import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";

const game = document.querySelector("#game");
const roundEl = document.querySelector("#round");
const statusEl = document.querySelector("#status");
const countdownEl = document.querySelector("#countdown");
const messagePanel = document.querySelector("#messagePanel");
const messageTitle = document.querySelector("#messageTitle");
const messageScore = document.querySelector("#messageScore");
const nextRoundBtn = document.querySelector("#nextRound");
const weaponControl = document.querySelector("#weaponControl");
const knob = weaponControl.querySelector(".knob");
const shootBtn = document.querySelector("#shoot");

const menuPanel = document.querySelector("#menuPanel");
const offlineBtn = document.querySelector("#offlineBtn");
const onlineBtn = document.querySelector("#onlineBtn");
const difficultyBtn = document.querySelector("#difficultyBtn");
const onlinePanel = document.querySelector("#onlinePanel");
const backMenuBtn = document.querySelector("#backMenuBtn");
const toast = document.querySelector("#toast");
let gameStarted=false;
let gameMode="offline";

function showToast(text){
  if(!toast) return;
  toast.textContent=text;
  toast.style.opacity="1";
  clearTimeout(showToast.timer);
  showToast.timer=setTimeout(()=>toast.style.opacity="0",1000);
}

offlineBtn?.addEventListener("click",()=>{
  gameMode="offline";
  gameStarted=true;
  onlinePanel.style.display="none";
  menuPanel.classList.add("hidden");
  ensureAudio();
  startRound();
});

onlineBtn?.addEventListener("click",()=>{
  onlinePanel.style.display="block";
});

backMenuBtn?.addEventListener("click",()=>{
  onlinePanel.style.display="none";
});

difficultyBtn?.addEventListener("click",()=>{
  const modes=["EASY","MEDIUM","HARD"];
  const i=(modes.indexOf(cpuDifficulty)+1)%modes.length;
  cpuDifficulty=modes[i];
  difficultyBtn.textContent=`DIFFICULTY: ${cpuDifficulty}`;
  showToast(`CPU ${cpuDifficulty}`);
});


const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8b5a43);
scene.fog = new THREE.FogExp2(0x8b604d, 0.012);

const camera = new THREE.PerspectiveCamera(68, innerWidth/innerHeight, 0.05, 300);
camera.position.set(0, 1.68, 7.5);
camera.rotation.order = "YXZ";

const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.7));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
game.appendChild(renderer.domElement);

const clock = new THREE.Clock();

const hemi = new THREE.HemisphereLight(0xffd8ad, 0x3c3028, 2.0);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffbd72, 3.0);
sun.position.set(-35, 45, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(1024,1024);
sun.shadow.camera.left=-45; sun.shadow.camera.right=45;
sun.shadow.camera.top=45; sun.shadow.camera.bottom=-45;
scene.add(sun);

const mats = {
  dirt:new THREE.MeshStandardMaterial({color:0x765033,roughness:1}),
  wood:new THREE.MeshStandardMaterial({color:0x5a301d,roughness:.9}),
  wood2:new THREE.MeshStandardMaterial({color:0x8a5130,roughness:.85}),
  roof:new THREE.MeshStandardMaterial({color:0x34251e,roughness:1}),
  sign:new THREE.MeshStandardMaterial({color:0x9b6a35,roughness:.8}),
  metal:new THREE.MeshStandardMaterial({color:0x24272a,metalness:.8,roughness:.28}),
  leather:new THREE.MeshStandardMaterial({color:0x3c2115,roughness:.9}),
  skin:new THREE.MeshStandardMaterial({color:0x9b5f43,roughness:.8}),
  cloth:new THREE.MeshStandardMaterial({color:0x25252a,roughness:.9}),
  outlaw:new THREE.MeshStandardMaterial({color:0x090a0c,roughness:.82}),
  coat:new THREE.MeshStandardMaterial({color:0x121315,roughness:.9}),
  gold:new THREE.MeshStandardMaterial({color:0xb8862f,metalness:.65,roughness:.3}),
  mountain:new THREE.MeshStandardMaterial({color:0x4b3b3a,roughness:1}),
};

function box(name,x,y,z,sx,sy,sz,mat=mats.wood2){
  const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat);
  m.name=name;m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;
}
function cyl(name,x,y,z,r,h,mat,segments=12){
  const m=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,segments),mat);
  m.name=name;m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;
}
function addBuilding(x,z,w,d,h,label){
  box("building",x,h/2,z,w,h,d,mats.wood);
  for(let i=-2;i<=2;i++){
    const px=x+i*w/6;
    box("plank",px,h/2,z-d/2-.015,w/8,h*.95,.04,mats.wood2);
  }
  const roof=new THREE.Mesh(new THREE.ConeGeometry(Math.max(w,d)*.75,1.8,4),mats.roof);
  roof.rotation.y=Math.PI/4;roof.position.set(x,h+.9,z);roof.castShadow=true;scene.add(roof);
  const sign=box("sign",x,h*.68,z-d/2-.07,w*.46,.65,.12,mats.sign);
  sign.rotation.y=0;
}
function addFence(x,z,len,rot=0){
  const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot;
  for(let i=0;i<=Math.floor(len/2);i++){
    const p=new THREE.Mesh(new THREE.BoxGeometry(.16,1.05,.16),mats.wood2);
    p.position.set(-len/2+i*2,.53,0);p.castShadow=true;g.add(p);
  }
  for(const y of [.35,.75]){
    const rail=new THREE.Mesh(new THREE.BoxGeometry(len,.13,.13),mats.wood2);
    rail.position.y=y;rail.castShadow=true;g.add(rail);
  }
  scene.add(g);
}
function makeMountain(x,z,sx,sy,sz){
  const m=new THREE.Mesh(new THREE.ConeGeometry(1,1,6),mats.mountain);
  m.scale.set(sx,sy,sz);m.position.set(x,sy/2-.2,z);m.rotation.y=.3;m.receiveShadow=true;scene.add(m);
}
function makeBarrel(x,z){
  const b=cyl("barrel",x,.48,z,.48,.95,mats.wood2,14);
  for(let y of [.18,.48,.78]){
    const r=cyl("ring",x,y,z,.5,.045,mats.metal,14);
    r.rotation.z=Math.PI/2;
  }
}
function makeCrate(x,z){
  const c=box("crate",x,.4,z,.8,.8,.8,mats.wood2);
  const a=box("crateX",x,.405,z,.88,.06,.06,mats.wood);
  a.rotation.y=.785;
  const b=a.clone();b.rotation.y=-.785;scene.add(b);
}

function buildWorld(){
  box("ground",0,-.08,0,110,.16,110,mats.dirt);
  addBuilding(-13,-8,11,7,6,"SALOON");
  addBuilding(13,-10,10,7,6,"STORE");
  addBuilding(-14,10,9,7,5.5,"SHERIFF");
  addBuilding(13,9,11,7,6,"HOTEL");
  addFence(-5,0,13,.12);
  addFence(5,-1,13,-.12);
  addFence(-18,2,8,Math.PI/2);
  addFence(18,2,8,Math.PI/2);
  for(const [x,z] of [[-8,-2],[-10,4],[8,1],[10,-4],[-18,-3],[18,-5]]) makeBarrel(x,z);
  for(const [x,z] of [[-6,5],[6,5],[-20,0],[20,0]]) makeCrate(x,z);
  for(let i=0;i<10;i++){
    const x=(Math.random()-.5)*80,z=-28-Math.random()*24;
    makeMountain(x,z,5+Math.random()*9,8+Math.random()*12,4+Math.random()*5);
  }
}
buildWorld();

// Dust particles
const dustGeo=new THREE.BufferGeometry();
const dustCount=220;
const pos=new Float32Array(dustCount*3);
for(let i=0;i<dustCount;i++){
  pos[i*3]=(Math.random()-.5)*55;
  pos[i*3+1]=.15+Math.random()*4;
  pos[i*3+2]=(Math.random()-.5)*45;
}
dustGeo.setAttribute("position",new THREE.BufferAttribute(pos,3));
const dustMat=new THREE.PointsMaterial({color:0xd4aa7b,size:.055,transparent:true,opacity:.38,depthWrite:false});
scene.add(new THREE.Points(dustGeo,dustMat));

function createRevolver(){
  const g=new THREE.Group();
  const barrel=new THREE.Mesh(new THREE.CylinderGeometry(.055,.065,.65,12),mats.metal);
  barrel.rotation.z=Math.PI/2;barrel.position.set(.02,.08,-.28);g.add(barrel);
  const body=new THREE.Mesh(new THREE.BoxGeometry(.26,.18,.42),mats.metal);
  body.position.set(.02,.08,.05);g.add(body);
  const cylr=new THREE.Mesh(new THREE.CylinderGeometry(.115,.115,.18,12),mats.metal);
  cylr.rotation.z=Math.PI/2;cylr.position.set(.02,.03,-.06);g.add(cylr);
  const grip=new THREE.Mesh(new THREE.BoxGeometry(.16,.48,.19),mats.leather);
  grip.rotation.z=-.25;grip.position.set(.02,-.18,.18);g.add(grip);
  const hammer=new THREE.Mesh(new THREE.BoxGeometry(.12,.14,.09),mats.metal);
  hammer.position.set(.02,.22,.15);g.add(hammer);
  g.traverse(o=>{if(o.isMesh)o.castShadow=true});
  return g;
}
function createHand(side){
  const g=new THREE.Group();
  const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.10,.48,4,8),mats.skin);
  arm.rotation.z=side*.3;arm.position.y=-.25;g.add(arm);
  const palm=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),mats.skin);
  palm.scale.set(.8,1.15,.65);palm.position.y=.02;g.add(palm);
  g.traverse(o=>{if(o.isMesh)o.castShadow=true});
  return g;
}

const weaponRig=new THREE.Group();
camera.add(weaponRig);scene.add(camera);
const revolver=createRevolver();
const rightHand=createHand(1), leftHand=createHand(-1);
weaponRig.add(revolver,rightHand,leftHand);
rightHand.position.set(.24,-.05,.05);
leftHand.position.set(-.10,-.08,.05);
revolver.position.set(.05,-.02,-.02);
const playerMuzzle=new THREE.Object3D();playerMuzzle.position.set(0,0,-.65);revolver.add(playerMuzzle);weaponRig.muzzle=playerMuzzle;
weaponRig.position.set(.35,-.48,-.95);
weaponRig.rotation.set(-.1,.05,.02);

function createOpponent(){
  const root=new THREE.Group();
  root.position.set(0,0,-10);
  scene.add(root);
  const parts={};
  function part(name,geo,mat,x,y,z){
    const m=new THREE.Mesh(geo,mat);m.name=name;m.position.set(x,y,z);m.castShadow=true;m.userData.hitRegion=name;root.add(m);parts[name]=m;return m;
  }
  // The Black Outlaw: layered black Western coat, scarf, hat, belt and boots.
  part("torso",new THREE.CapsuleGeometry(.38,.85,5,10),mats.coat,0,1.2,0);
  const shirt=new THREE.Mesh(new THREE.BoxGeometry(.30,.68,.32),mats.outlaw);shirt.position.set(0,1.42,-.18);shirt.castShadow=true;root.add(shirt);
  const coatTail=new THREE.Mesh(new THREE.BoxGeometry(.68,.72,.16),mats.outlaw);coatTail.position.set(0,.82,.18);coatTail.castShadow=true;root.add(coatTail);
  const scarf=new THREE.Mesh(new THREE.CylinderGeometry(.27,.27,.20,16),mats.outlaw);scarf.position.set(0,1.83,0);scarf.castShadow=true;root.add(scarf);
  part("head",new THREE.SphereGeometry(.28,12,10),mats.skin,0,2.35,0);
  const hat=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.13,16),mats.outlaw);hat.position.set(0,2.62,0);hat.castShadow=true;root.add(hat);
  const crown=new THREE.Mesh(new THREE.CylinderGeometry(.28,.22,.35,12),mats.outlaw);crown.position.set(0,2.82,0);crown.castShadow=true;root.add(crown);
  const band=new THREE.Mesh(new THREE.CylinderGeometry(.285,.285,.045,16),mats.gold);band.position.set(0,2.70,0);band.castShadow=true;root.add(band);
  part("leftArm",new THREE.CapsuleGeometry(.12,.65,4,8),mats.coat,-.48,1.28,0);
  part("rightArm",new THREE.CapsuleGeometry(.12,.65,4,8),mats.coat,.48,1.28,0);
  part("leftLeg",new THREE.CapsuleGeometry(.15,.9,4,8),mats.outlaw,-.18,.48,0);
  part("rightLeg",new THREE.CapsuleGeometry(.15,.9,4,8),mats.outlaw,.18,.48,0);
  const belt=new THREE.Mesh(new THREE.BoxGeometry(.78,.10,.12),mats.leather);belt.position.set(0,.96,-.28);belt.castShadow=true;root.add(belt);
  const buckle=new THREE.Mesh(new THREE.BoxGeometry(.13,.13,.035),mats.gold);buckle.position.set(0,.96,-.35);buckle.castShadow=true;root.add(buckle);
  const gun=createRevolver();gun.scale.set(.55,.55,.55);gun.position.set(.58,1.05,-.12);gun.rotation.y=-.1;root.add(gun);
  const muzzle=new THREE.Object3D();muzzle.position.set(0,0,-.58);gun.add(muzzle);gun.muzzle=muzzle;
  return {root,parts,gun};
}
const opponent=createOpponent();

let round=1, playerWins=0, cpuWins=0;
let phase="countdown", countdown=3, countdownTimer=0;
let drawAmount=0, recoil=0, muzzleFlash=0;
let canShoot=false, roundOver=false, cpuTimer=0;
let cpuDifficulty="MEDIUM";

// --- Enhanced Phase 1 feedback/audio ---
let audioCtx=null;
function ensureAudio(){
  if(audioCtx) return;
  try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){}
}
function tone(freq=440,duration=.07,type="square",gain=.035){
  if(!audioCtx)return;
  try{
    const o=audioCtx.createOscillator(), g=audioCtx.createGain();
    o.type=type; o.frequency.value=freq;
    g.gain.setValueAtTime(gain,audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+duration);
    o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration);
  }catch(e){}
}
function soundShot(){ tone(92,.045,"sawtooth",.07); setTimeout(()=>tone(58,.055,"square",.045),18); }
function soundHit(){ tone(180,.08,"triangle",.045); }
function soundDraw(){ tone(260,.035,"triangle",.025); }
function vibrate(pattern){
  try{ if(hapticsEnabled && navigator.vibrate) navigator.vibrate(pattern); }catch(e){}
}

const cpuConfig={EASY:{reaction:1.15,accuracy:.55},MEDIUM:{reaction:.72,accuracy:.75},HARD:{reaction:.42,accuracy:.9}};
let cpuDraw=0;
let screenKick=0;
let dustBursts=[];

function burstDust(x,y,z){
  const n=28;
  const g=new THREE.BufferGeometry();
  const a=new Float32Array(n*3);
  const v=[];
  for(let i=0;i<n;i++){
    a[i*3]=x+(Math.random()-.5)*.55;
    a[i*3+1]=Math.max(.03,y)+Math.random()*.12;
    a[i*3+2]=z+(Math.random()-.5)*.55;
    v.push({x:(Math.random()-.5)*1.2,y:.35+Math.random()*1.1,z:(Math.random()-.5)*1.2});
  }
  g.setAttribute("position",new THREE.BufferAttribute(a,3));
  const m=new THREE.PointsMaterial({color:0xc9a27b,size:.10,transparent:true,opacity:.7,depthWrite:false});
  const pts=new THREE.Points(g,m);scene.add(pts);
  dustBursts.push({pts,v,life:0});
}

let yaw=0,pitch=0;
let aimPointerId=null,lastAimX=0,lastAimY=0;
let weaponPointerId=null;
let targetDraw=0;
let audioCtx=null;

let hapticsEnabled=true;
function haptic(kind){
  if(!hapticsEnabled || !("vibrate" in navigator)) return;
  const patterns={shot:45,hit:85,loss:[100,45,100],win:30};
  navigator.vibrate(patterns[kind] ?? 30);
}
function ensureAudio(){
  if(!audioCtx) audioCtx=new (window.AudioContext||window.webkitAudioContext)();
  if(audioCtx.state==="suspended") audioCtx.resume();
}
function tone(freq,dur,type="sine",gain=.035){
  try{ensureAudio();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=gain;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+dur);o.stop(audioCtx.currentTime+dur)}catch{}
}
function gunSound(){tone(90,.08,"sawtooth",.08);setTimeout(()=>tone(55,.12,"square",.035),25)}
function impactSound(){tone(150,.09,"triangle",.05)}

function updateWeapon(){
  drawAmount += (targetDraw-drawAmount)*Math.min(1,0.16);
  const t=drawAmount;
  const idleX=Math.sin(performance.now()*.0022)*.008;
  const idleY=Math.sin(performance.now()*.0014)*.012;
  weaponRig.position.x=.35+idleX;
  weaponRig.position.y=-.48+(.68*t)+idleY;
  weaponRig.position.z=-.95-(.18*t);
  weaponRig.rotation.x=-.1-(.04*t);
  weaponRig.rotation.y=.05;
  weaponRig.rotation.z=.02+Math.sin(performance.now()*.0018)*.008;
  if(recoil>0){
    weaponRig.position.y+=recoil*.12;
    weaponRig.position.z+=recoil*.24;
    weaponRig.rotation.x-=recoil*.2;
    recoil=Math.max(0,recoil-.075);
  }
  knob.style.transform=`translateY(${(1-t)*32-12}%)`;
}

function firePlayer(){
  ensureAudio(); soundShot(); vibrate(45);
  if(!gameStarted || !canShoot || drawAmount<.5 || roundOver || phase!=="duel") return;
  canShoot=false;
  recoil=1;muzzleFlash=.12;screenKick=.35;haptic("shot");gunSound();
  const muzzleWorld=new THREE.Vector3();
  weaponRig.muzzle.getWorldPosition(muzzleWorld);
  burstDust(muzzleWorld.x,muzzleWorld.y,muzzleWorld.z);
  const origin=muzzleWorld.clone();
  const direction=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion).normalize();
  const ray=new THREE.Raycaster(origin,direction,0,80);
  const targets=Object.values(opponent.parts);
  const hits=ray.intersectObjects(targets,false);
  if(hits.length){
    const region=hits[0].object.userData.hitRegion;
    resolveHit(region,true);
  } else {
    statusEl.textContent="MISS";
    setTimeout(()=>{if(!roundOver)statusEl.textContent="DUEL";},350);
    cpuCanFireSoon();
  }
}
function resolveHit(region,playerShot){
  if(roundOver)return;
  impactSound();
  if(playerShot){
    if(region==="leftArm"||region==="rightArm"){
      opponent.root.rotation.z=region==="leftArm" ? -.22:.22;
      opponent.gun.visible=false;
      statusEl.textContent="ARM HIT";
      setTimeout(()=>endRound(true),360);
    } else {
      statusEl.textContent=region==="head"?"HEAD HIT":"BODY HIT";
      opponent.root.userData.falling=true;
      opponent.gun.visible=false;
      setTimeout(()=>{
        burstDust(opponent.root.position.x,0,opponent.root.position.z);
        endRound(true);
      },500);
    }
  } else {
    haptic("hit");
    statusEl.textContent="YOU WERE HIT";
    screenKick=.8;
    setTimeout(()=>endRound(false),300);
  }
}
function endRound(playerWon){
  if(roundOver)return;
  roundOver=true;canShoot=false;targetDraw=0;
  if(playerWon){playerWins++;haptic("win");messageTitle.textContent="ROUND WON";}
  else{cpuWins++;haptic("loss");messageTitle.textContent="ROUND LOST";}
  messageScore.textContent=`${playerWins} - ${cpuWins}`;
  messagePanel.classList.remove("hidden");
  if(playerWins>=2 || cpuWins>=2){
    messageTitle.textContent=playerWins>=2 ? "YOU WIN THE MATCH" : "DEFEATED";
    nextRoundBtn.textContent="NEW MATCH";
  }else{
    nextRoundBtn.textContent="NEXT ROUND";
  }
}
function resetOpponent(){
  opponent.root.position.set(0,0,-10);
  opponent.root.rotation.set(0,0,0);
  opponent.root.userData.falling=false;
  opponent.gun.visible=true;
  opponent.gun.position.set(.58,1.05,-.12);
  opponent.gun.rotation.set(0,-.1,0);
  cpuDraw=0;
}
function startRound(){
  roundOver=false;phase="countdown";countdown=3;countdownTimer=0;targetDraw=0;drawAmount=0;canShoot=false;cpuTimer=0;
  resetOpponent();
  yaw=0;pitch=0;camera.rotation.set(0,0,0);
  roundEl.textContent=`ROUND ${round} / 3`;
  statusEl.textContent="GET READY";
  countdownEl.textContent="3";
  shootBtn.disabled=true;shootBtn.classList.add("disabled");
}
function beginDuel(){
  phase="duel";canShoot=true;countdownEl.textContent="DRAW!";statusEl.textContent="DUEL";
  shootBtn.disabled=false;shootBtn.classList.remove("disabled");cpuTimer=cpuConfig[cpuDifficulty].reaction;
}
function cpuCanFireSoon(){ cpuTimer=Math.min(cpuTimer,cpuConfig[cpuDifficulty].reaction*.55); }
function cpuFire(){
  ensureAudio(); soundShot(); vibrate(55);
  if(roundOver||phase!=="duel")return;
  const cfg=cpuConfig[cpuDifficulty];
  cpuDraw=1;
  opponent.gun.position.y=1.35;
  opponent.gun.position.z=-.28;
  opponent.gun.rotation.x=-.18;
  tone(180,.08,"triangle",.025);
  const origin=new THREE.Vector3();
  opponent.gun.muzzle.getWorldPosition(origin);
  const playerPos=camera.getWorldPosition(new THREE.Vector3());
  let direction=playerPos.clone().sub(origin).normalize();
  if(Math.random()>cfg.accuracy){
    direction.x+=(Math.random()-.5)*.22;
    direction.y+=(Math.random()-.5)*.18;
    direction.normalize();
  }
  const ray=new THREE.Raycaster(origin,direction,0,80);
  // CPU only checks a generous player center volume for this prototype.
  const playerCenter=new THREE.Vector3(0,1.45,7.5);
  const toCenter=playerCenter.clone().sub(origin);
  const angle=direction.angleTo(toCenter.normalize());
  if(angle<.075){
    screenKick=.65;
    resolveHit("torso",false);
  }else{
    screenKick=.25;
    statusEl.textContent="CPU MISS";
    setTimeout(()=>{if(!roundOver)statusEl.textContent="DUEL";},300);
  }
}

weaponControl.addEventListener("pointerdown",e=>{
  if(!gameStarted)return;
  weaponPointerId=e.pointerId;weaponControl.setPointerCapture(e.pointerId);
});
weaponControl.addEventListener("pointermove",e=>{
  if(e.pointerId!==weaponPointerId)return;
  const r=weaponControl.getBoundingClientRect();
  const cy=r.top+r.height/2;
  const v=THREE.MathUtils.clamp((cy-e.clientY)/(r.height*.42),-1,1);
  targetDraw=(v+1)/2;
  if(phase!=="duel")targetDraw=0;
});
["pointerup","pointercancel","lostpointercapture"].forEach(ev=>weaponControl.addEventListener(ev,()=>weaponPointerId=null));

renderer.domElement.addEventListener("pointerdown",e=>{
  if(!gameStarted || e.clientX<innerWidth*.30 || e.clientX>innerWidth*.70) return;
  aimPointerId=e.pointerId;lastAimX=e.clientX;lastAimY=e.clientY;renderer.domElement.setPointerCapture(e.pointerId);
});
renderer.domElement.addEventListener("pointermove",e=>{
  if(e.pointerId!==aimPointerId)return;
  const dx=e.clientX-lastAimX,dy=e.clientY-lastAimY;
  lastAimX=e.clientX;lastAimY=e.clientY;
  yaw-=dx*.0032;pitch-=dy*.0028;
  pitch=THREE.MathUtils.clamp(pitch,-.9,.9);
  camera.rotation.y=yaw;camera.rotation.x=pitch;
});
["pointerup","pointercancel","lostpointercapture"].forEach(ev=>renderer.domElement.addEventListener(ev,()=>aimPointerId=null));

shootBtn.addEventListener("pointerdown",e=>{e.preventDefault();ensureAudio();firePlayer()});
nextRoundBtn.addEventListener("click",()=>{
  if(playerWins>=2||cpuWins>=2){
    playerWins=0;cpuWins=0;round=1;messagePanel.classList.add("hidden");startRound();
  }else{
    round++;messagePanel.classList.add("hidden");startRound();
  }
});

function animateOpponent(dt){
  if(opponent.root.userData.falling){
    opponent.root.rotation.x=Math.min(Math.PI*.48,opponent.root.rotation.x+dt*2.5);
    opponent.root.rotation.z=Math.sin(performance.now()*.004)*.08;
    opponent.root.position.y=Math.max(-.75,opponent.root.position.y-dt*1.55);
    return;
  }
  opponent.root.position.y=Math.sin(performance.now()*.0015)*.015;
  opponent.root.rotation.z=Math.sin(performance.now()*.0012)*.012;
}
function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(.05,clock.getDelta());
  if(phase==="countdown"){
    countdownTimer+=dt;
    if(countdownTimer>=1){
      countdownTimer=0;countdown--;
      if(countdown>0){countdownEl.textContent=countdown;tone(220+countdown*80,.08,"triangle",.04);}
      else{beginDuel();tone(620,.14,"square",.05);}
    }
  }
  if(phase==="duel"&&!roundOver){
    cpuTimer-=dt;
    if(cpuTimer<=0){cpuFire();cpuTimer=999;}
  }
  if(muzzleFlash>0)muzzleFlash-=dt;
  updateWeapon();
  animateOpponent(dt);

  // Short-lived cinematic camera response and procedural dust bursts.
  if(screenKick>0){
    camera.position.x += (Math.random()-.5)*screenKick*.018;
    camera.position.y += (Math.random()-.5)*screenKick*.014;
    screenKick=Math.max(0,screenKick-dt*2.8);
  }
  for(let i=dustBursts.length-1;i>=0;i--){
    const d=dustBursts[i]; d.life+=dt;
    const arr=d.pts.geometry.attributes.position.array;
    for(let j=0;j<d.v.length;j++){
      arr[j*3]+=d.v[j].x*dt;
      arr[j*3+1]+=d.v[j].y*dt;
      arr[j*3+2]+=d.v[j].z*dt;
      d.v[j].y-=.75*dt;
    }
    d.pts.geometry.attributes.position.needsUpdate=true;
    d.pts.material.opacity=Math.max(0,.7-d.life*1.5);
    if(d.life>.48){scene.remove(d.pts);d.pts.geometry.dispose();d.pts.material.dispose();dustBursts.splice(i,1);}
  }

  renderer.render(scene,camera);
}
phase="menu";menuPanel.classList.remove("hidden");animate();

addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight);
});

// Real networking is intentionally not simulated. This interface is the future
// integration point for an authoritative 1v1 server.
const onlineSession = {
  connected:false, roomId:null, localPlayerId:null, transport:null,
  connect(){ showToast("ONLINE 1v1 • SERVER REQUIRED"); },
  disconnect(){ this.connected=false; this.roomId=null; this.localPlayerId=null; }
};
