const createClient = window.supabase?.createClient || (() => ({
  auth: {
    getSession: async () => ({ data: { session: null } }),
    signInWithPassword: async () => ({ error: new Error('Supabase indisponível neste modo.') }),
    signUp: async () => ({ error: new Error('Supabase indisponível neste modo.') }),
    signOut: async () => ({})
  },
  from: () => ({
    select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: null }), order: () => ({ limit: async () => ({ data: [] }) }) }), order: () => ({ limit: async () => ({ data: [] }) }), limit: async () => ({ data: [] }) }),
    update: () => ({ eq: () => ({ eq: async () => ({}) }) })
  })
}));

const SUPABASE_URL = "https://shzrgbgrbxssdsnmlrdo.supabase.co";
const SUPABASE_KEY = "sb_publishable_pIsVYvB_wUdyB1gvM1jwdQ_-EZ6V_7w";
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const state = {
  user:null, player:null, page:"home", modal:null, toast:"",
  events:[], mail:[], friends:[], inventory:[],
  mode:"BR Ranqueada", season:"Temporada 1",
  guest:false
};

const modes = [
 ["BR Ranqueada","100 jogadores • competitivo","ranked"],
 ["CS Ranqueado","4v4 • competitivo","ranked"],
 ["4v4","4 contra 4","casual"],
 ["Mapa Aberto","até 10 jogadores","casual"],
 ["Treinamento","pratique contra bots","offline"],
 ["Ilha do Rolê","explore e socialize","casual"],
 ["Salas Personalizadas","crie sua sala","room"],
 ["Salas Competitivas","formato competitivo","room"],
 ["Guerra de Guildas","somente jogadores reais","gg"]
];

const chars = [
 ["Ravik","Combate","assets/ravik.png"],["Nyra","Mobilidade","assets/nyra.png"],
 ["Kairo","Defesa","assets/kairo.png"],["Drex","Rastreamento","assets/drex.png"],
 ["Vexa","Proteção","assets/vexa.png"],["Arkon","Precisão","assets/arkon.png"],
 ["Zyra","Movimento","assets/zyra.png"],["Nox","Furtividade","assets/nox.png"]
];

const fallback = (name)=>`<div class="avatar">${(name||"N")[0].toUpperCase()}</div>`;
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));}
function toast(t){state.toast=t; render(); setTimeout(()=>{state.toast="";render()},2200)}
async function load(){
  const {data:{session}}=await supabase.auth.getSession();
  state.user=session?.user||null;
  if(state.user){
    const {data}=await supabase.from("players").select("*").eq("id",state.user.id).maybeSingle();
    state.player=data||{id:state.user.id,player_id:"NEX-"+state.user.id.slice(0,8).toUpperCase(),nick:state.user.email?.split("@")[0]||"Jogador",level:1,xp:0};
    await Promise.all([
      supabase.from("events").select("*").eq("active",true).order("created_at",{ascending:false}).limit(10).then(r=>state.events=r.data||[]),
      supabase.from("mail").select("*").eq("player_id",state.user.id).order("created_at",{ascending:false}).limit(20).then(r=>state.mail=r.data||[]),
      supabase.from("inventory").select("*").eq("player_id",state.user.id).limit(100).then(r=>state.inventory=r.data||[])
    ]);
  }
  render();
}
function loginScreen(){
 return `<div class="auth"><div class="brand">NEX<span>FIRE</span></div><p>NEXHOST PROJECT</p>
 <div class="authbox"><h2>Entrar no NEXFIRE</h2><input id="email" placeholder="E-mail"><input id="pass" type="password" placeholder="Senha">
 <button class="primary" onclick="window.doLogin()">ENTRAR</button><button onclick="window.doSignup()">CRIAR CONTA</button>
 <div class="or">ou</div><button onclick="window.doGuest()">ENTRAR COMO CONVIDADO</button><small>Conta e progresso ficam vinculados ao NEXHOST ID.</small></div></div>`;
}
function shell(){
 const p=state.player||{nick:"Convidado",level:1,player_id:"NEX-GUEST",xp:0};
 return `<div class="app"><header><div class="mini-logo" onclick="window.go('home')">NEX<span>FIRE</span></div>
 <div class="profile-mini" onclick="window.go('profile')">${fallback(p.nick)}<span>${esc(p.nick)}<small>Nível ${p.level}</small></span></div>
 <div class="wallet">💎 <b>${p.diamonds??0}</b> &nbsp; ◈ <b>${p.tokens??0}</b></div>
 <button class="icon" onclick="window.go('settings')">⚙</button></header>
 <aside>${nav("home","⌂","Início")}${nav("matches","⚔","Partidas")}${nav("rank","🏆","Ranqueadas")}${nav("vault","▣","Cofre")}${nav("shop","◈","Loja")}${nav("royale","✦","MENU ROYALE")}${nav("pass","🎫","Passe de Elite")}${nav("events","◇","Eventos")}${nav("mail","✉","Mail")}${nav("friends","♧","Amigos")}</aside>
 <main>${page()}</main>${state.toast?`<div class="toast">${esc(state.toast)}</div>`:""}${state.modal?modal():''}</div>`;
}
function nav(id,icon,label){return `<button class="${state.page===id?'sel':''}" onclick="window.go('${id}')"><i>${icon}</i><span>${label}</span></button>`}
function page(){
 switch(state.page){
  case "matches":return matches();
  case "rank":return rank();
  case "vault":return vault();
  case "shop":return shop();
  case "royale":return royale();
  case "pass":return pass();
  case "events":return events();
  case "mail":return mail();
  case "friends":return friends();
  case "profile":return profile();
  case "settings":return settings();
  default:return home();
 }
}
function home(){
 return `<section class="hero"><div><label>SEASON 01</label><h1>NEXFIRE</h1><p>Uma nova era começa aqui.</p><button class="primary big" onclick="window.go('matches')">COMEÇAR</button></div><div class="hero-char"><div class="orb"></div><div class="char">NEX</div></div></section>
 <section class="grid4"><div class="card"><b>Ranqueada</b><strong>Bronze I</strong><small>0 RP</small></div><div class="card"><b>Próxima GG</b><strong>Sábado 17:00</strong><small>Somente jogadores reais</small></div><div class="card"><b>Eventos</b><strong>${state.events.length}</strong><small>ativos</small></div><div class="card"><b>Mail</b><strong>${state.mail.filter(x=>!x.read).length}</strong><small>não lidos</small></div></section>
 <h2>Atalhos</h2><div class="tiles"><button onclick="window.go('shop')">LOJA</button><button onclick="window.go('royale')">MENU ROYALE</button><button onclick="window.go('vault')">COFRE</button><button onclick="window.go('events')">EVENTOS</button></div>`;
}
function matches(){
 return `<section class="pagehead"><div><h1>PARTIDAS</h1><p>Escolha um modo.</p></div><div class="tabs"><button class="sel">MODO OFICIAL</button><button>OFICINA DE CRIAÇÃO</button></div></section>
 <div class="modegrid">${modes.map(m=>`<article class="mode ${m[2]}"><div class="modeart">${m[0][0]}</div><div><h3>${m[0]}</h3><p>${m[1]}</p>${m[0]==="Guerra de Guildas"?`<small class="schedule">SÁB 15:00 aparece • 17:00–22:00<br>DOM 16:00 aparece • 18:00–22:00</small>`:""}<button class="primary" onclick="window.startMode('${esc(m[0])}')">${m[0]==="Treinamento"?"JOGAR":"SELECIONAR"}</button></div></article>`).join("")}</div>`;
}
function rank(){return `<section class="rankhero"><label>${state.season}</label><h1>BRONZE I</h1><div class="rankbar"><span style="width:32%"></span></div><p>320 / 1000 RP</p><div class="rankcards"><div><b>Próximo</b><strong>BRONZE II</strong></div><div><b>CS</b><strong>BRONZE I</strong></div><div><b>Temporada</b><strong>01</strong></div></div></section><div class="card table"><h2>Recompensas da temporada</h2><p>Suba de rank para desbloquear recompensas enviadas ao Mail.</p></div>`}
function vault(){return `<section class="pagehead"><h1>COFRE</h1><p>Personalização e itens da sua conta.</p></section><div class="tabs"><button class="sel">PERSONALIZAÇÃO</button><button>ROUPAS</button><button>EMOTES</button><button>BANNERS</button></div><div class="itemgrid">${["Banner NEX","Foto NEX","Título: Fundador","Emblema NEXHOST","Emote de Entrada","Animação Aurora","Skin Gelo NEX","Passe 01"].map((x,i)=>`<div class="item"><div class="itempic">${i+1}</div><b>${x}</b><small>${i<3?"Equipado":"Disponível"}</small><button onclick="window.equip('${x}')">EQUIPAR</button></div>`).join("")}</div>`}
function shop(){return `<section class="pagehead"><h1>LOJA</h1><p>Compra direta com moeda virtual.</p></section><div class="itemgrid">${["Skin Ravik","Banner Eclipse","Emote Impacto","Animação Neon","Aura NEX","Mochila NEX","Foto Eclipse","Título Veterano"].map((x,i)=>`<div class="item"><div class="itempic">${i+10}</div><b>${x}</b><strong>${[199,299,89,499,799,149,99,349][i]} 💎</strong><button class="primary" onclick="window.buy('${x}',${[199,299,89,499,799,149,99,349][i]})">COMPRAR</button></div>`).join("")}</div>`}
function royale(){return `<section class="royale"><label>MENU ROYALE</label><h1>GIRO NEX</h1><p>Gire usando apenas diamantes virtuais.</p><div class="royalebox"><div class="prize">✦</div><div class="guarantee"><b>GARANTIA 75%</b><span>0 / 900 💎</span><div class="rankbar"><span style="width:0%"></span></div></div><button class="primary big" onclick="window.spin()">GIRAR • 9 💎</button></div></section>`}
function pass(){return `<section class="pass"><label>PASSE DE ELITE</label><h1>TEMPORADA 01</h1><div class="passline">${[1,2,3,4,5,6,7,8].map(i=>`<div><b>${i*10}</b><span>✦</span><small>RECOMPENSA</small></div>`).join("")}</div><button class="primary" onclick="window.toast('Passe demonstrativo — catálogo configurável pelo ADM')">VER RECOMPENSAS</button></section>`}
function events(){return `<section class="pagehead"><h1>EVENTOS</h1><p>Conteúdo publicado pelo NEXHUB ADM.</p></section>${state.events.length?`<div class="eventgrid">${state.events.map(e=>`<article class="event"><div class="eventimg">${esc((e.title||"EVENTO").slice(0,1))}</div><h3>${esc(e.title)}</h3><p>${esc(e.description||"Evento ativo")}</p><button onclick="window.toast('Evento aberto')">SAIBA MAIS</button></article>`).join("")}</div>`:`<div class="empty">Nenhum evento ativo no momento.</div>`}`}
function mail(){return `<section class="pagehead"><h1>MAIL</h1><p>Recompensas não entram direto no inventário: resgate pelo Mail.</p></section><div class="mail">${state.mail.length?state.mail.map(m=>`<article class="${m.read?'':'unread'}"><div>✉</div><section><b>${esc(m.title)}</b><small>${new Date(m.created_at).toLocaleString("pt-BR")}</small><p>${esc(m.message)}</p></section><button onclick="window.redeem('${m.id}')">${m.redeemed?"RESGATADO":"RESGATAR"}</button></article>`).join(""):`<div class="empty">Sua caixa de entrada está vazia.</div>`}</div>`}
function friends(){return `<section class="pagehead"><h1>AMIGOS</h1><p>Equipe, convites e contatos.</p></section><div class="card"><input id="friendId" placeholder="NEX-ID do jogador"><button class="primary" onclick="window.addFriend()">ENVIAR CONVITE</button></div><div class="empty">Nenhum amigo carregado.</div>`}
function profile(){let p=state.player||{};return `<section class="profile"><div class="profiletop">${fallback(p.nick)}<div><h1>${esc(p.nick)}</h1><p>${esc(p.player_id)}</p><span>Nível ${p.level||1} • ${state.season}</span></div></div><div class="stats"><div><b>0</b><small>Vitórias</small></div><div><b>0</b><small>Abates</small></div><div><b>0</b><small>Partidas</small></div><div><b>Bronze I</b><small>Rank</small></div></div><div class="card"><h2>Emblemas</h2><p>Os emblemas de Criador, ADM/Moderador e Dono são controlados pelo NEXHUB ADM.</p></div></section>`}
function settings(){return `<section class="pagehead"><h1>CONFIGURAÇÕES</h1></section><div class="settings">${["Sensibilidade","HUD","Gráficos","Sons","Vibrações","Controles","Notificações","Privacidade","Acessibilidade","Conta"].map(x=>`<button onclick="window.toast('${x}: configuração pronta para sincronização')"><b>${x}</b><span>›</span></button>`).join("")}</div><button onclick="window.logout()">SAIR DA CONTA</button>`}
function modal(){return `<div class="overlay" onclick="window.closeModal()"><div class="modal" onclick="event.stopPropagation()">${state.modal}</div></div>`}
function render(){document.querySelector("#app").innerHTML=state.user||state.guest?shell():loginScreen();}
window.go=(p)=>{state.page=p;render()};
window.closeModal=()=>{state.modal=null;render()};
window.toast=toast;
window.doLogin=async()=>{let email=document.querySelector("#email").value,pass=document.querySelector("#pass").value;if(!email||!pass)return toast("Preencha e-mail e senha");let r=await supabase.auth.signInWithPassword({email,password:pass});if(r.error)return toast(r.error.message);await load()};
window.doSignup=async()=>{let email=document.querySelector("#email").value,pass=document.querySelector("#pass").value;if(pass.length<6)return toast("A senha precisa ter 6 caracteres");let r=await supabase.auth.signUp({email,password:pass});if(r.error)return toast(r.error.message);toast("Conta criada. Confirme o e-mail se solicitado.");await load()};
window.doGuest=()=>{state.guest=true;state.player={nick:"Convidado",level:1,player_id:"NEX-GUEST"};render()};
window.logout=async()=>{await supabase.auth.signOut();state.user=null;state.guest=false;state.player=null;render()};
window.startMode=(m)=>{state.mode=m;if(m==="Treinamento"){state.modal=`<h2>Treinamento</h2><p>Partida local contra bots. Nenhum matchmaking real é usado.</p><div class="arena"><div class="player-dot">N</div><div class="bot b1">B</div><div class="bot b2">B</div><div class="bot b3">B</div></div><button class="primary" onclick="window.closeModal()">SAIR DA PARTIDA</button>`;render();return} if(m==="Guerra de Guildas"){toast("GG só abre nos horários configurados e nunca preenche com bots");return}toast(`${m} selecionado`)};
window.buy=async(name,price)=>{if(!state.user)return toast("Entre em uma conta para comprar");toast(`Compra preparada: ${name} por ${price} 💎`)};
window.spin=()=>toast("Giro preparado — transação real deve passar por função segura do backend");
window.redeem=async(id)=>{if(!state.user)return;await supabase.from("mail").update({read:true,redeemed:true}).eq("id",id).eq("player_id",state.user.id);toast("Recompensa resgatada");await load()};
window.addFriend=()=>toast("Convite preparado");
window.equip=(x)=>toast(`${x} equipado`);
load();
