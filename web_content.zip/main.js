import {
  auth,
  database,
  storage,
  ref,
  set,
  get,
  push,
  remove,
  onAuthStateChanged,
  storageRef,
  uploadBytes,
  getDownloadURL
} from "./firebase/firebase.js";

const projectContainer = document.getElementById("prjcontaner");
const historyContainer = document.getElementById("cnt");
const createPanel = document.getElementById("createp");
const createProjectButton = document.getElementById("createprj");
const createButton = document.getElementById("create");
const historyButton = document.getElementById("hisB");
const historyPanel = document.getElementById("his");
const previewPanel = document.getElementById("vidpreview");
const previewVideo = previewPanel?.querySelector("video");
const videoLink = document.getElementById("vidlink");
const searchInput = document.getElementById("search");
const typeFilter = document.getElementById("toc");

let currentUser = null;
let projects = [];

function escapeHtml(value = "") {
  return String(value).replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;"
  }[char]));
}

function showError(message) {
  console.error(message);
  alert(message);
}

function renderProjects() {
  const search = searchInput.value.trim().toLowerCase();
  const type = typeFilter.value;

  projectContainer.innerHTML = "";
  historyContainer.innerHTML = "";

  const filtered = projects.filter((project) => {
    const matchesSearch = !search ||
      project.name.toLowerCase().includes(search) ||
      project.creator.toLowerCase().includes(search);
    const matchesType = !type || project.type === type;
    return matchesSearch && matchesType;
  });

  if (!filtered.length) {
    projectContainer.innerHTML = '<p class="empty-state">No projects found.</p>';
  }

  for (const project of filtered) {
    const card = document.createElement("div");
    card.className = "prj";
    card.dataset.id = project.id;
    card.innerHTML = `
      <div class="tb">
        <p class="title">${escapeHtml(project.name)} (${escapeHtml(project.creator)}) {${escapeHtml(project.type)}}</p>
      </div>
      <img src="${escapeHtml(project.img)}" alt="${escapeHtml(project.name)}" loading="lazy">
      <div class="bb">
        <button type="button" class="like-btn"><span class="material-symbols-outlined">thumb_up</span></button>
        <button type="button" class="dislike-btn"><span class="material-symbols-outlined">thumb_down</span></button>
        <button type="button" class="flag-btn"><span class="material-symbols-outlined">flag</span></button>
      </div>
    `;

    card.querySelector("img").addEventListener("click", () => openPreview(project));
    projectContainer.appendChild(card);
  }

  const mine = projects.filter((project) => project.creatorUid === currentUser.uid);
  for (const project of mine) {
    const row = document.createElement("div");
    row.className = "prjj";
    row.innerHTML = `
      <p>${escapeHtml(project.name)}</p>
      <button type="button" class="deletbtn" title="Delete project">
        <span class="material-symbols-outlined">delete</span>
      </button>
      <a href="${escapeHtml(project.vid)}" download="${escapeHtml(project.name)}.mp4">
        <button type="button"><span class="material-symbols-outlined">download</span></button>
      </a>
    `;

    row.querySelector(".deletbtn").addEventListener("click", async () => {
      if (!confirm(`Delete ${project.name}?`)) return;
      try {
        await remove(ref(database, `prjs/${project.id}`));
        projects = projects.filter((item) => item.id !== project.id);
        renderProjects();
      } catch (error) {
        showError(`Could not delete project: ${error.message}`);
      }
    });

    historyContainer.appendChild(row);
  }
}

function openPreview(project) {
  if (!previewVideo || !videoLink) return;
  previewVideo.src = project.vid;
  videoLink.href = project.vid;
  videoLink.download = `${project.name}.mp4`;
  previewPanel.style.display = "block";
  previewVideo.load();
}

async function loadProjects() {
  const snapshot = await get(ref(database, "prjs"));
  projects = [];

  if (snapshot.exists()) {
    snapshot.forEach((childSnapshot) => {
      const data = childSnapshot.val();
      if (!data || !data.name || !data.creatorUid || !data.img || !data.vid) return;
      projects.push({ id: childSnapshot.key, ...data });
    });
  }

  renderProjects();
}

async function uploadFile(file, folder, uid) {
  if (!file) throw new Error("Please select both an image and a video.");

  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${folder}/${uid}/${crypto.randomUUID()}-${safeName}`;
  const fileRef = storageRef(storage, path);
  await uploadBytes(fileRef, file, { contentType: file.type });
  return getDownloadURL(fileRef);
}

async function createProject() {
  const nameInput = document.getElementById("prjname");
  const typeInput = document.getElementById("prjtype");
  const imageInput = document.getElementById("cpimage");
  const videoInput = document.getElementById("cpvideo");

  const name = nameInput.value.trim();
  const type = typeInput.value;
  const image = imageInput.files[0];
  const video = videoInput.files[0];

  if (!name || !image || !video) {
    showError("Enter a project name and select an image and video.");
    return;
  }

  createButton.disabled = true;
  createButton.textContent = "Uploading...";

  try {
    const [imageUrl, videoUrl] = await Promise.all([
      uploadFile(image, "project-images", currentUser.uid),
      uploadFile(video, "project-videos", currentUser.uid)
    ]);

    const projectRef = push(ref(database, "prjs"));
    await set(projectRef, {
      name,
      type,
      img: imageUrl,
      vid: videoUrl,
      creator: localStorage.getItem("username") || currentUser.email || "User",
      creatorUid: currentUser.uid,
      createdAt: Date.now()
    });

    nameInput.value = "";
    imageInput.value = "";
    videoInput.value = "";
    createPanel.style.display = "none";
    await loadProjects();
  } catch (error) {
    console.error(error);
    showError(`Could not create project: ${error.message}`);
  } finally {
    createButton.disabled = false;
    createButton.textContent = "create";
  }
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.replace("./index.html");
    return;
  }

  currentUser = user;

  try {
    const profile = await get(ref(database, `users/${user.uid}`));
    if (profile.exists()) {
      localStorage.setItem("username", profile.val().username || "");
    }
    await loadProjects();
  } catch (error) {
    showError(`Firebase could not load your data: ${error.message}`);
  }
});

createProjectButton?.addEventListener("click", (event) => {
  event.preventDefault();
  createPanel.style.display = createPanel.style.display === "block" ? "none" : "block";
});

createButton?.addEventListener("click", (event) => {
  event.preventDefault();
  createProject();
});

historyButton?.addEventListener("click", (event) => {
  event.preventDefault();
  historyPanel.style.display = historyPanel.style.display === "block" ? "none" : "block";
});

searchInput?.addEventListener("input", renderProjects);
typeFilter?.addEventListener("change", renderProjects);
