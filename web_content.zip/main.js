const createprj = document.getElementById('createprj');
const createp = document.getElementById('createp');
const create = document.getElementById('create');
const hisB = document.getElementById('hisB');
const his = document.getElementById('his');
const cnt = document.getElementById('cnt');
const uploadedTab = document.getElementById('uploadedTab');
const downloadsTab = document.getElementById('downloadsTab');
const imageInput = document.getElementById('cpimage');
const videoInput = document.getElementById('cpvideo');

const DB_NAME = 'BetterClipsHistory';
const DB_VERSION = 1;
const STORE = 'media';

let historyMode = 'uploaded';
let selectedUpload = null;
let objectUrls = [];

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function addHistoryItem(item) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add(item);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

async function getHistory(type) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).getAll();
    request.onsuccess = () => {
      const items = request.result.filter(item => item.type === type);
      items.sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    request.onerror = () => reject(request.error);
  });
}

async function deleteHistoryItem(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString([], {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'
  });
}

function makeDownload(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name || 'better-clips-download';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function downloadHistoryItem(item) {
  makeDownload(item.blob, item.name);

  await addHistoryItem({
    type: 'download',
    name: item.name,
    mime: item.mime,
    blob: item.blob,
    createdAt: Date.now()
  });

  if (historyMode === 'downloads') renderHistory();
}

async function renderHistory() {
  cnt.innerHTML = '';
  objectUrls.forEach(url => URL.revokeObjectURL(url));
  objectUrls = [];

  const items = await getHistory(historyMode);

  if (!items.length) {
    cnt.innerHTML = '<div class="empty-history">Nothing here yet</div>';
    return;
  }

  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';

    const left = document.createElement('div');
    left.className = 'history-info';

    const preview = document.createElement('div');
    preview.className = 'history-preview';

    const url = URL.createObjectURL(item.blob);
    objectUrls.push(url);

    if (item.mime && item.mime.startsWith('video/')) {
      const video = document.createElement('video');
      video.src = url;
      video.muted = true;
      video.playsInline = true;
      video.preload = 'metadata';
      preview.appendChild(video);
    } else {
      const img = document.createElement('img');
      img.src = url;
      preview.appendChild(img);
    }

    const text = document.createElement('div');
    text.innerHTML = `<p>${escapeHtml(item.name)}</p><small>${formatDate(item.createdAt)}</small>`;
    left.append(preview, text);

    const actions = document.createElement('div');
    actions.className = 'history-actions';

    const dl = document.createElement('button');
    dl.innerHTML = '<span class="material-symbols-outlined">download</span>';
    dl.title = 'Download';
    dl.onclick = () => downloadHistoryItem(item);

    const del = document.createElement('button');
    del.innerHTML = '<span class="material-symbols-outlined">delete</span>';
    del.title = 'Delete';
    del.onclick = async () => {
      await deleteHistoryItem(item.id);
      renderHistory();
    };

    actions.append(dl, del);
    row.append(left, actions);
    cnt.appendChild(row);
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[char]));
}

async function handleUpload(file) {
  if (!file) return;

  selectedUpload = file;

  await addHistoryItem({
    type: 'uploaded',
    name: file.name,
    mime: file.type || 'application/octet-stream',
    blob: file,
    createdAt: Date.now()
  });

  if (file.type.startsWith('image/')) {
    imageInput.closest('button').classList.add('selected-upload');
  } else if (file.type.startsWith('video/')) {
    videoInput.closest('button').classList.add('selected-upload');
  }

  if (his.style.display === 'block' && historyMode === 'uploaded') renderHistory();
}

function setupReactionButtons(project) {
  const like = project.querySelector('.like-btn');
  const dislike = project.querySelector('.dislike-btn');
  if (!like || !dislike) return;

  like.onclick = (e) => {
    e.preventDefault();
    const active = like.classList.toggle('active');
    dislike.classList.remove('active');
    like.setAttribute('aria-pressed', active ? 'true' : 'false');
    dislike.setAttribute('aria-pressed', 'false');
  };

  dislike.onclick = (e) => {
    e.preventDefault();
    const active = dislike.classList.toggle('active');
    like.classList.remove('active');
    dislike.setAttribute('aria-pressed', active ? 'true' : 'false');
    like.setAttribute('aria-pressed', 'false');
  };
}

// Make the original project card use the same working like/dislike buttons.
const originalProject = document.querySelector('.container .prj');
if (originalProject) setupReactionButtons(originalProject);

createprj.onclick = (e) => {
  e.preventDefault();
  e.stopPropagation();
  createp.style.display = 'block';
};

create.onclick = (e) => {
  e.preventDefault();

  const name = document.getElementById('prjname').value.trim();
  const type = document.getElementById('prjtype').value;

  if (!name) return;

  const project = document.createElement('div');
  project.className = 'prj';
  project.innerHTML = `
    <div class="tb">
      <span class="project-type"></span>
      <p class="title"></p>
    </div>
    <img>
    <div class="bb">
      <button class="like-btn" aria-label="Like"><span class="material-symbols-outlined">thumb_up</span></button>
      <button class="dislike-btn" aria-label="Dislike"><span class="material-symbols-outlined">thumb_down</span></button>
      <button class="project-download" aria-label="Download"><span class="material-symbols-outlined">download</span></button>
    </div>
  `;

  project.querySelector('.title').textContent = name;
  project.querySelector('.project-type').textContent = type;
  project.dataset.type = type;

  setupReactionButtons(project);

  const projectImg = project.querySelector('img');
  if (selectedUpload && selectedUpload.type.startsWith('image/')) {
    projectImg.src = URL.createObjectURL(selectedUpload);
  } else {
    projectImg.src = 'image.jpeg';
  }

  project.querySelector('.project-download').onclick = async () => {
    const blob = await fetch(projectImg.src).then(response => response.blob());
    await downloadHistoryItem({
      name: `${name}.jpg`,
      mime: blob.type || 'image/jpeg',
      blob
    });
  };

  document.querySelector('.container').appendChild(project);
  createp.style.display = 'none';
  document.getElementById('prjname').value = '';
  imageInput.value = '';
  videoInput.value = '';
  selectedUpload = null;
  document.querySelectorAll('.selected-upload').forEach(button => button.classList.remove('selected-upload'));
};

imageInput.addEventListener('change', () => handleUpload(imageInput.files[0]));
videoInput.addEventListener('change', () => handleUpload(videoInput.files[0]));

hisB.onclick = (e) => {
  e.preventDefault();
  e.stopPropagation();
  his.style.display = 'block';
  historyMode = 'uploaded';
  updateHistoryTabs();
  renderHistory();
};

document.addEventListener('click', (e) => {
  if (his.style.display === 'block' && !his.contains(e.target) && e.target !== hisB && !hisB.contains(e.target)) {
    his.style.display = 'none';
  }

  if (createp.style.display === 'block' && !createp.contains(e.target) && e.target !== createprj && !createprj.contains(e.target)) {
    createp.style.display = 'none';
  }
});

uploadedTab.onclick = (e) => {
  e.preventDefault();
  historyMode = 'uploaded';
  updateHistoryTabs();
  renderHistory();
};

downloadsTab.onclick = (e) => {
  e.preventDefault();
  historyMode = 'download';
  updateHistoryTabs();
  renderHistory();
};

function updateHistoryTabs() {
  uploadedTab.classList.toggle('active', historyMode === 'uploaded');
  downloadsTab.classList.toggle('active', historyMode === 'download');
}

const search = document.getElementById('search');
search.addEventListener('keydown', function (e) {
  if (e.key === 'Enter') searchfor(search.value);
});

function searchfor(s) {
  const projects = document.querySelectorAll('.container .prj');
  const words = s.toLowerCase().split(' ').filter(Boolean);

  projects.forEach(prj => {
    const title = prj.querySelector('.title');
    const text = title ? title.textContent.toLowerCase() : '';
    const hasWord = !words.length || words.some(word => text.includes(word));
    prj.style.display = hasWord ? '' : 'none';
  });
}
