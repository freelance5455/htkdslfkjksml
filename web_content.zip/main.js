'use strict';
/* ============================================================
   Onboarding, inicialização, service worker
   ============================================================ */
const OB_GOALS = ['hypertrophy','weightloss','conditioning','health'];
const OB_EXPS = ['beginner','intermediate','advanced'];
const OB = { lang:'auto', name:'', goal:'hypertrophy', days:3, exp:'beginner', tpl:'fullbody', tplTouched:false };
function suggestTemplate(days){ return days <= 3 ? 'fullbody' : (days === 4 ? 'upperlower' : 'abc'); }

/* Monta a rotina a partir do modelo; nomes no idioma ATIVO no momento da criação */
function buildRoutine(tplId, daysPerWeek, goal){
  const tpl = TEMPLATES[tplId], pattern = PLAN_PATTERN[Math.min(7, Math.max(1, daysPerWeek))];
  const mkEx = (id, sets, reps, rest)=>({ id:U.uid('ex'), key:'ex_' + id, name:t('ex.' + id), muscle:CATALOG[id][0], equipment:CATALOG[id][1], sets, reps, load:'', rest, notes:'' });
  const cardioExtra = (goal === 'weightloss' || goal === 'conditioning') && tplId !== 'cardio' && tplId !== 'scratch';
  return pattern.map((dow, i)=>{
    const base = { id:U.uid('day'), dow, name:fmtWeekdayShort(dow).slice(0,6), color:DAY_COLORS[i % DAY_COLORS.length], note:'', exercises:[] };
    if(tplId === 'scratch' || !tpl.list.length) return Object.assign(base, { title:t('day.generic', { n:i + 1 }) });
    const w = tpl.list[i % tpl.list.length];
    base.title = t(w.title);
    base.exercises = w.ex.map(e=>mkEx(e[0], e[1], e[2], e[3]));
    if(cardioExtra) base.exercises.push(mkEx('treadmill', 1, '15', 0));
    return base;
  });
}
function finishOnboarding(){
  const d = State.data;
  d.profile.name = OB.name.trim().slice(0,30); d.profile.goal = OB.goal; d.profile.experience = OB.exp; d.profile.onboarded = true;
  d.settings.weeklyGoal = OB.days; d.settings.language = OB.lang; d.settings.installedAt = Date.now();
  d.days = buildRoutine(OB.tpl, OB.days, OB.goal);
  pickInitialDay(); persistData(); rebuildGamification(); syncOnboarding(); State.currentView = 'train'; switchView('train');
}
function chipGroup(label, items, current, onPick, labelId){
  const wrap = h('div', { class:'field' }); wrap.appendChild(h('label', { id:labelId, text:label }));
  const row = h('div', { class:'chips', role:'radiogroup', 'aria-labelledby':labelId });
  items.forEach(it=>{ const on = String(it[0]) === String(current); row.appendChild(h('button', { class:'chip-btn' + (on ? ' on' : ''), type:'button', role:'radio', 'aria-checked':String(on), text:it[1], onclick:()=>onPick(it[0]) })); });
  wrap.appendChild(row); return wrap;
}
function renderOnboarding(){
  const root = $('#onbInner'), prevScroll = $('#onboarding').scrollTop; U.clear(root);
  root.appendChild(h('h1', { class:'onb-title', id:'onbTitle', text:t('onb.welcome', { app:APP_NAME }) }));
  root.appendChild(h('p', { class:'onb-sub', text:t('onb.sub') }));
  root.appendChild(chipGroup(t('pref.language'), [['auto', t('pref.langAuto')], ['pt-BR', t('lang.pt')], ['en', t('lang.en')]], OB.lang, v=>{ OB.lang = v; S().language = v; applyLanguage(); renderOnboarding(); }, 'ob-l-lang'));
  const iName = h('input', { id:'ob-name', type:'text', maxlength:'30', autocomplete:'off', value:OB.name, placeholder:t('prof.namePh') });
  iName.addEventListener('input', ()=>{ OB.name = iName.value; });
  root.appendChild(fieldEl(t('prof.name'), iName));
  root.appendChild(chipGroup(t('onb.goal'), OB_GOALS.map(g=>[g, t('goal.' + g)]), OB.goal, v=>{ OB.goal = v; renderOnboarding(); }, 'ob-l-goal'));
  if(OB.goal === 'weightloss' || OB.goal === 'conditioning') root.appendChild(h('div', { class:'field-hint', style:{ marginTop:'-8px' }, text:t('onb.cardioHint') }));
  root.appendChild(chipGroup(t('onb.days'), [1,2,3,4,5,6,7].map(n=>[n, String(n)]), OB.days, v=>{ OB.days = Number(v); if(!OB.tplTouched) OB.tpl = suggestTemplate(OB.days); renderOnboarding(); }, 'ob-l-days'));
  root.appendChild(chipGroup(t('onb.exp'), OB_EXPS.map(g=>[g, t('exp.' + g)]), OB.exp, v=>{ OB.exp = v; renderOnboarding(); }, 'ob-l-exp'));
  const tf = h('div', { class:'field' }); tf.appendChild(h('label', { id:'ob-l-tpl', text:t('onb.template') }));
  const list = h('div', { class:'tpl-list', role:'radiogroup', 'aria-labelledby':'ob-l-tpl' });
  TEMPLATE_ORDER.forEach(id=>{
    const on = OB.tpl === id;
    const b = h('button', { class:'tpl-card' + (on ? ' on' : ''), type:'button', role:'radio', 'aria-checked':String(on), onclick:()=>{ OB.tpl = id; OB.tplTouched = true; renderOnboarding(); } });
    b.appendChild(h('div', { class:'tpl-name', text:t('tpl.' + id + '.name') })); b.appendChild(h('div', { class:'tpl-desc', text:t('tpl.' + id + '.desc') })); list.appendChild(b);
  });
  tf.appendChild(list); root.appendChild(tf);
  root.appendChild(h('button', { class:'btn btn-primary btn-block onb-go', type:'button', text:t('onb.start'), onclick:finishOnboarding }));
  root.appendChild(h('button', { class:'btn btn-ghost btn-block', type:'button', text:t('onb.restore'), onclick:()=>$('#fileImport').click() }));
  root.appendChild(h('div', { class:'note-text', text:t('about.privacy') }));
  $('#onboarding').scrollTop = prevScroll;
}
let obRendered = false;
function syncOnboarding(){
  const need = !State.data.profile.onboarded, ob = $('#onboarding');
  ob.hidden = !need; document.body.classList.toggle('onb-open', need);
  ['appRoot','bottomNav'].forEach(id=>{ const n = $('#' + id); if(n){ if(need) n.setAttribute('inert',''); else n.removeAttribute('inert'); } });
  if(need){ if(!obRendered){ OB.lang = S().language; obRendered = true; } renderOnboarding(); const f = $('#ob-name'); if(f && !ob.dataset.focused){ ob.dataset.focused = '1'; } }
  else obRendered = false;
}

/* ---------- Sessão fantasma ---------- */
function checkGhostSession(){
  if(!State.active || Date.now() - State.active.startedAt <= GHOST_SESSION_MS) return;
  Modals.open({ title:t('ghost.title'), dismissable:false, build(body, foot){
    body.appendChild(h('p', { class:'dlg-msg', text:t('ghost.msg', { h:Math.floor((Date.now() - State.active.startedAt) / 3600000) }) }));
    foot.appendChild(h('button', { class:'btn btn-danger', type:'button', text:t('ghost.discard'), onclick:()=>{ State.active = null; persistActive(); closeRestTimer(); syncWakeLock(); Modals.close(); renderAll(); } }));
    foot.appendChild(h('button', { class:'btn btn-primary', type:'button', text:t('ghost.continue'), onclick:()=>Modals.close() }));
  }});
}
/* ---------- Avisos de sequência (tom motivador, sem culpa) ---------- */
function checkStreakNotices(){
  if(!gamOn() || !State.game || !State.data.profile.onboarded) return;
  const g = State.game.streak, st = State.data.gamification.streak, today = U.dayKey(Date.now());
  let changed = false;
  if(g.frozenDays.length){
    const last = g.frozenDays[g.frozenDays.length-1];
    if((!st.noticedFreeze || last > st.noticedFreeze) && U.daysBetween(last, today) <= 3){ showToast(t('streak.freezeUsed'), 'success'); }
    if(!st.noticedFreeze || last > st.noticedFreeze){ st.noticedFreeze = last; changed = true; }
  }
  if(g.lastBreak && (!st.noticedBreak || g.lastBreak.at > st.noticedBreak)){
    if(U.daysBetween(g.lastBreak.at, today) <= 3) setTimeout(()=>showToast(t('streak.broken', { lost:g.lastBreak.lost, best:g.best }), 'warn'), 3200);
    st.noticedBreak = g.lastBreak.at; changed = true;
  }
  if(changed) persistData();
}
function reevaluateLanguage(){
  if(S().language !== 'auto') return;
  const before = I18N.lang; applyLanguage();
  if(I18N.lang !== before) renderAll();
}

/* ---------- Inicialização ---------- */
function boot(){
  applyLanguage(); initModals(); initRestTimer();
  document.querySelectorAll('.nav-btn').forEach(b=>b.addEventListener('click', ()=>switchView(b.dataset.view)));
  $('#settingsBtn').addEventListener('click', ()=>switchView('settings'));
  $('#streakBtn').addEventListener('click', openStreakSheet);
  $('#editDayBtn').addEventListener('click', ()=>openDayModal(false));
  $('#addExerciseBtn').addEventListener('click', ()=>openExerciseModal(null));
  $('#undoBtn').addEventListener('click', doUndo);
  $('#fileImport').addEventListener('change', async e=>{ const f = e.target.files[0]; if(f) await importBackupFile(f); e.target.value = ''; });
  if(!Storage.available) showToast(t('toast.noStorage'), 'warn');
  pickInitialDay();
  const rest = Storage.loadRest();
  if(rest && typeof rest.endAt === 'number'){ State.rest.endAt = rest.endAt; State.rest.pausedRemaining = rest.pausedRemaining; State.rest.totalMs = rest.totalMs || 90000; ensureRestTick(); }
  rebuildGamification();
  renderAll(); renderRestTimer(); syncWakeLock(); syncOnboarding();
  if(State.data.profile.onboarded){
    checkGhostSession(); checkStreakNotices();
    try{
      if(new URLSearchParams(location.search).get('action') === 'start'){
        history.replaceState(null, '', location.pathname);
        const d = currentDay(); if(d && d.exercises.length && !State.active && !Modals.cur) doStartSession(d);
      }
    }catch(e){}
  }
  document.addEventListener('visibilitychange', ()=>{ syncWakeLock(); if(document.visibilityState === 'visible'){ reevaluateLanguage(); renderRestTimer(); } });
  window.addEventListener('languagechange', reevaluateLanguage);
  let deferred = null;
  window.addEventListener('beforeinstallprompt', e=>{ e.preventDefault(); deferred = e; const b = $('#installBtn'); b.hidden = false; });
  $('#installBtn').addEventListener('click', async ()=>{ if(!deferred) return; deferred.prompt(); try{ await deferred.userChoice; }catch(_){} deferred = null; $('#installBtn').hidden = true; });
  window.addEventListener('appinstalled', ()=>{ $('#installBtn').hidden = true; });
  if('serviceWorker' in navigator && /^https?:$/.test(location.protocol)){
    const had = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('./sw.js').catch(()=>{});
    navigator.serviceWorker.addEventListener('controllerchange', ()=>{ if(had) showToast(t('sw.updated'), 'success'); });
  }
}
boot();
