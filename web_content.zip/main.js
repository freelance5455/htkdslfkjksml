import { UIManager } from './ui/uimanager.js';
import { MainMenu } from './ui/mainmenu.js';
import { SettingsMenu } from './ui/settingsmenu.js';

document.addEventListener('DOMContentLoaded', () => {
    console.log("🚀 Инициализация модулей игры...");

    // 1. Инициализация UIManager
    const ui = new UIManager();

    // 2. Инициализация Настроек
    const settings = new SettingsMenu(ui);

    // 3. Инициализация Главного Меню
    const mainMenu = new MainMenu(ui, (matchParams) => {
        console.log("⚔️ Старт боя с параметрами:", matchParams);
        startBattleSimulation(ui, matchParams);
    });

    // Имитация загрузки
    simulateLoading(ui);
});

function simulateLoading(ui) {
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        ui.updateLoadingProgress(progress);

        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                ui.hideLoadingScreen();
                ui.showScreen('mainMenu');
            }, 300);
        }
    }, 100);
}

function startBattleSimulation(ui, params) {
    let hp = 100;
    let ammo = 30;

    ui.updateHP(hp);
    ui.updateAmmo(`${ammo} / 90`);

    const shootBtn = document.getElementById('btn-shoot');
    if (shootBtn) {
        shootBtn.onclick = () => {
            if (ammo > 0) {
                ammo--;
                ui.updateAmmo(`${ammo} / 90`);
                
                const dmg = Math.floor(Math.random() * 40) + 20;
                const isHeadshot = dmg > 45;
                const x = window.innerWidth / 2 + (Math.random() * 100 - 50);
                const y = window.innerHeight / 2 + (Math.random() * 100 - 50);
                
                ui.showDamagePopup(dmg, isHeadshot, x, y);

                if (Math.random() > 0.6) {
                    ui.addKillFeed("Player", "Deagle", isHeadshot ? "HEADSHOT" : "CHEST", "Zombie");
                }
            }
        };
    }

    document.getElementById('btn-pause')?.addEventListener('click', () => {
        ui.screens.pauseMenu.style.display = 'flex';
    });

    document.getElementById('btn-resume')?.addEventListener('click', () => {
        ui.screens.pauseMenu.style.display = 'none';
    });

    document.getElementById('btn-pause-mainmenu')?.addEventListener('click', () => {
        ui.screens.pauseMenu.style.display = 'none';
        ui.setInGameUIActive(false);
        ui.showScreen('mainMenu');
    });
}
