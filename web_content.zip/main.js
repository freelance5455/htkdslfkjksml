const canvas = document.getElementById('canvas');
canvas.style.touchAction = 'none';

function safeLog(...args) { try { console.log(...args); } catch(e) {} }

// Register Service Worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(err => safeLog('SW registration failed:', err));
  });
}

window.Module = Object.assign(window.Module || {}, {
  canvas,
  locateFile: (path) => (path.endsWith('.wasm') ? '/sm64.wasm' : path),
  print: (text) => safeLog(text),
  printErr: (text) => safeLog('ERR:', text),
  setStatus: (text) => {}
});

// Auto-focus logic
canvas.tabIndex = 0;
const focusCanvas = () => canvas.focus();
document.addEventListener('touchstart', focusCanvas, { passive: true });
document.addEventListener('mousedown', focusCanvas);

/* Audio Muffling and Effects */
let selectAudioBuffer = null;
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
const masterGain = audioCtx.createGain();
const lowpassFilter = audioCtx.createBiquadFilter();
lowpassFilter.type = 'lowpass';
lowpassFilter.frequency.value = 22000; // Start fully open
masterGain.connect(lowpassFilter).connect(audioCtx.destination);

async function loadSelectSound() {
  try {
    const response = await fetch('/Select.wav');
    const arrayBuffer = await response.arrayBuffer();
    selectAudioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
  } catch (e) {
    safeLog("Error loading select sound:", e);
  }
}
loadSelectSound();

function playSelectSound() {
  if (selectAudioBuffer && audioCtx.state === 'running') {
    const source = audioCtx.createBufferSource();
    source.buffer = selectAudioBuffer;
    source.connect(audioCtx.destination);
    source.start(0);
  }
}

// Hook into SDL2's AudioContext if possible to apply global filtering
function applyMuffle(enabled) {
  const targetFreq = enabled ? 400 : 22000;
  lowpassFilter.frequency.setTargetAtTime(targetFreq, audioCtx.currentTime, 0.1);
  
  // Try to find Emscripten's context
  try {
    if (window.Module?.SDL2?.audioContext) {
      const sdlCtx = window.Module.SDL2.audioContext;
      // Note: Injected filters are hard in standard Emscripten setups without source access,
      // so we rely on the browser's global gain/muffle if we can route it, 
      // otherwise we just adjust master volume of the SDL context.
      if (enabled) sdlCtx.suspend(); else sdlCtx.resume(); 
      // suspending works as a fallback, but let's try volume
      if (window.Module.SDL2.audioContext.gainNode) {
        window.Module.SDL2.audioContext.gainNode.gain.setTargetAtTime(enabled ? 0.3 : 1.0, audioCtx.currentTime, 0.2);
      }
    }
  } catch(e) {}
}

/* Key Dispatching */
const KEY_MAP = {
  'ArrowUp': 38, 'ArrowDown': 40, 'ArrowLeft': 37, 'ArrowRight': 39,
  'KeyX': 88, 'KeyC': 67, 'Space': 32, 'Enter': 13
};

function dispatchKey(code, type = 'keydown') {
  const keyCode = KEY_MAP[code] || 0;
  const eventInit = { 
    code: code,
    key: code,
    keyCode: keyCode,
    which: keyCode,
    bubbles: true,
    cancelable: true,
    view: window,
    repeat: false
  };
  
  const ev = new KeyboardEvent(type, eventInit);
  // Dispatch to multiple targets to ensure the Emscripten engine catches it
  window.dispatchEvent(ev);
  document.dispatchEvent(ev);
  canvas.dispatchEvent(ev);
}

/* Control Modes Handling */
const controlModeSelect = document.getElementById('control-mode-select');
const appContainer = document.getElementById('app');

function setControlMode(mode) {
  appContainer.classList.remove('theme-playstation', 'theme-xbox', 'theme-switch');
  if (mode !== 'default') {
    appContainer.classList.add(`theme-${mode}`);
  }
  localStorage.setItem('sm64_control_mode', mode);
}

/* Settings Modal Logic */
const settingsBtn = document.getElementById('settings-btn');
const settingsModal = document.getElementById('settings-modal');
const closeSettingsBtn = document.getElementById('close-settings');

settingsBtn.addEventListener('click', () => {
  playSelectSound();
  settingsModal.classList.add('active');
  document.body.classList.add('modal-open');
  applyMuffle(true);
});

closeSettingsBtn.addEventListener('click', () => {
  settingsModal.classList.remove('active');
  document.body.classList.remove('modal-open');
  applyMuffle(false);
});

/* Mod Info Modal Logic */
const modInfoBtn = document.getElementById('mod-info-btn');
const modInfoModal = document.getElementById('mod-info-modal');
const closeModInfoBtn = document.getElementById('close-mod-info');
const fileTags = document.querySelectorAll('.file-tag');
const explanationBox = document.getElementById('file-explanation');
const explTitle = document.getElementById('expl-title');
const explText = document.getElementById('expl-text');

const FILE_TYPE_INFO = {
  js: {
    title: "JavaScript (.js)",
    text: "Dynamic scripts that modify game logic, physics, or add new UI elements. These mods execute directly within the engine's environment."
  },
  bin: {
    title: "Binary (.bin)",
    text: "Compiled game data. Usually contains custom level geometry, model data, or modified gameplay code blocks used by the engine's virtual filesystem."
  },
  dat: {
    title: "Data (.dat)",
    text: "General resource or configuration files. Often used by complex mods to store specific asset pointers or mod-specific settings."
  },
  txt: {
    title: "Text (.txt)",
    text: "Simple configuration, documentation, or manifest files. Can be used for read-me instructions or to define how other mod files should be loaded."
  }
};

modInfoBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  playSelectSound();
  modInfoModal.classList.add('active');
});

closeModInfoBtn.addEventListener('click', () => {
  modInfoModal.classList.remove('active');
  explanationBox.classList.add('hidden');
});

fileTags.forEach(tag => {
  tag.addEventListener('click', () => {
    playSelectSound();
    const type = tag.getAttribute('data-type');
    const info = FILE_TYPE_INFO[type];
    
    if (info) {
      explTitle.textContent = info.title;
      explText.textContent = info.text;
      explanationBox.classList.remove('hidden');
      
      // Update active state
      fileTags.forEach(t => t.classList.remove('active'));
      tag.classList.add('active');
    }
  });
});

// Close sub-modals when clicking outside content
window.addEventListener('click', (e) => {
  if (e.target === modInfoModal) {
    modInfoModal.classList.remove('active');
    explanationBox.classList.add('hidden');
  }
});

/* Mod Management Logic */
const importModBtn = document.getElementById('import-mod-btn');
const modFileInput = document.getElementById('mod-file-input');
const modListContainer = document.getElementById('mod-list');

async function refreshModList() {
  if (!window.websim?.datastore) return;
  const mods = await websim.datastore.get('sm64_mods') || [];
  if (!Array.isArray(mods)) return;
  modListContainer.innerHTML = mods.length === 0 ? '<div style="opacity:0.5; text-align:center; padding:10px;">No mods imported</div>' : '';
  
  mods.forEach((mod, index) => {
    if (!mod) return;
    const item = document.createElement('div');
    item.className = 'mod-item';
    item.innerHTML = `
      <span class="mod-name">${mod.name || 'Unknown Mod'}</span>
      <span class="remove-mod" data-index="${index}">&times;</span>
    `;
    item.querySelector('.remove-mod').addEventListener('click', async (e) => {
      if (!window.websim?.datastore) return;
      const idx = parseInt(e.target.dataset.index);
      const currentMods = await websim.datastore.get('sm64_mods') || [];
      currentMods.splice(idx, 1);
      await websim.datastore.set('sm64_mods', currentMods);
      refreshModList();
    });
    modListContainer.appendChild(item);
  });
}

async function handleModUpload(file) {
  const reader = new FileReader();
  reader.onload = async (e) => {
    const content = e.target.result;
    const uint8 = new Uint8Array(content);
    const fileName = file.name;

    // Load into Emscripten FS immediately if available
    if (window.Module?.FS) {
      try {
        window.Module.FS.writeFile('/' + fileName, uint8);
        safeLog(`Mod file ${fileName} written to FS.`);
      } catch (err) {
        safeLog(`Error writing ${fileName} to FS:`, err);
      }
    }

    // Special handling for JS mods: inject into document
    if (fileName.endsWith('.js')) {
      const script = document.createElement('script');
      script.textContent = new TextDecoder().decode(uint8);
      document.body.appendChild(script);
      safeLog(`JS Mod ${fileName} executed.`);
    }

    // Persist mod for future sessions
    let binary = '';
    const len = uint8.byteLength;
    for (let i = 0; i < len; i++) binary += String.fromCharCode(uint8[i]);
    const base64Content = btoa(binary);

    if (!window.websim?.datastore) return;
    const currentMods = await websim.datastore.get('sm64_mods') || [];
    const existingIdx = currentMods.findIndex(m => m && m.name === fileName);
    if (existingIdx > -1) {
      currentMods[existingIdx].content = base64Content;
    } else {
      currentMods.push({ name: fileName, content: base64Content });
    }
    await websim.datastore.set('sm64_mods', currentMods);
    refreshModList();
  };
  reader.readAsArrayBuffer(file);
}

importModBtn.addEventListener('click', () => {
  playSelectSound();
  modFileInput.click();
});

modFileInput.addEventListener('change', (e) => {
  if (e.target.files.length > 0) {
    handleModUpload(e.target.files[0]);
  }
});

const scanControllersBtn = document.getElementById('scan-controllers-btn');
scanControllersBtn.addEventListener('click', async () => {
  playSelectSound();
  const originalText = scanControllersBtn.textContent;
  scanControllersBtn.textContent = "Searching...";
  scanControllersBtn.disabled = true;

  try {
    if (navigator.bluetooth) {
      // Trigger the native Bluetooth picker to help users find and pair their controllers
      await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service']
      }).catch(e => safeLog("Bluetooth scan cancelled or failed:", e));
    } else {
      // Manual check fallback for non-Bluetooth browsers
      checkExistingGamepads();
    }
  } catch (err) {
    safeLog("Scan error:", err);
  } finally {
    // Re-verify existing connections immediately
    setTimeout(() => {
      checkExistingGamepads();
      scanControllersBtn.textContent = originalText;
      scanControllersBtn.disabled = false;
    }, 2000);
  }
});

const resetSettingsBtn = document.getElementById('reset-settings');
resetSettingsBtn.addEventListener('click', () => {
  playSelectSound();
  // Reset values
  controlModeSelect.value = 'default';
  setControlMode('default');
  
  hapticEnabled = true;
  hapticToggle.checked = true;
  
  joystickOpacitySlider.value = '0.8';
  joystickBase.style.opacity = '0.8';
  
  controlsSizeSlider.value = '1';
  actionButtonsContainer.style.transform = 'scale(1)';
  joystickBase.style.transform = 'scale(1)';
  
  // Clear persisted settings
  localStorage.removeItem('sm64_control_mode');
  localStorage.removeItem('sm64_haptic');
  localStorage.removeItem('sm64_joystick_opacity');
  localStorage.removeItem('sm64_controls_size');
});

controlModeSelect.addEventListener('change', (e) => {
  if (psSessionActive) endPsSession();
  setControlMode(e.target.value);
});

/* Extra Settings */
const hapticToggle = document.getElementById('haptic-toggle');
const joystickOpacitySlider = document.getElementById('joystick-opacity-slider');
const controlsSizeSlider = document.getElementById('controls-size-slider');
const actionButtonsContainer = document.getElementById('action-buttons-container');
const joystickBase = document.getElementById('joystick-base');

let hapticEnabled = true;

hapticToggle.addEventListener('change', (e) => {
  hapticEnabled = e.target.checked;
  localStorage.setItem('sm64_haptic', hapticEnabled);
});

joystickOpacitySlider.addEventListener('input', (e) => {
  joystickBase.style.opacity = e.target.value;
  localStorage.setItem('sm64_joystick_opacity', e.target.value);
});

controlsSizeSlider.addEventListener('input', (e) => {
  const scale = e.target.value;
  actionButtonsContainer.style.transform = `scale(${scale})`;
  joystickBase.style.transform = `scale(${scale})`;
  localStorage.setItem('sm64_controls_size', scale);
});

/* Joystick Logic */
const joystickZone = document.getElementById('joystick-zone');
const joystickHandle = document.getElementById('joystick-handle');
let activeJoystickKeys = new Set();
let joystickActive = false;
let joystickTouchId = null;
let startX = 0, startY = 0;
const MAX_RADIUS = 60;
const DEADZONE = 10;

const clearJoystickKeys = () => {
  activeJoystickKeys.forEach(k => dispatchKey(k, 'keyup'));
  activeJoystickKeys.clear();
};

const updateJoystickUI = (dx, dy) => {
  const dist = Math.sqrt(dx * dx + dy * dy);
  const ratio = dist > MAX_RADIUS ? MAX_RADIUS / dist : 1;
  const ux = dx * ratio, uy = dy * ratio;
  joystickHandle.style.transform = `translate(calc(-50% + ${ux}px), calc(-50% + ${uy}px))`;
  
  const newKeys = new Set();
  if (dist > DEADZONE) {
    const angle = Math.atan2(dy, dx);
    const cos = Math.cos(angle), sin = Math.sin(angle);
    if (cos > 0.38) newKeys.add('ArrowRight');
    if (cos < -0.38) newKeys.add('ArrowLeft');
    if (sin > 0.38) newKeys.add('ArrowDown');
    if (sin < -0.38) newKeys.add('ArrowUp');
  }

  activeJoystickKeys.forEach(k => { if (!newKeys.has(k)) dispatchKey(k, 'keyup'); });
  newKeys.forEach(k => { if (!activeJoystickKeys.has(k)) dispatchKey(k, 'keydown'); });
  activeJoystickKeys = newKeys;
};

const handleJoystickStart = (e) => {
  if (joystickActive) return;
  const touch = e.changedTouches ? e.changedTouches[0] : e;
  if (e.changedTouches) joystickTouchId = touch.identifier;
  joystickActive = true;
  const rect = joystickBase.getBoundingClientRect();
  startX = rect.left + rect.width / 2;
  startY = rect.top + rect.height / 2;
  updateJoystickUI(touch.clientX - startX, touch.clientY - startY);
};

const handleJoystickMove = (e) => {
  if (!joystickActive) return;
  let touch = e.changedTouches ? Array.from(e.changedTouches).find(t => t.identifier === joystickTouchId) : e;
  if (touch) updateJoystickUI(touch.clientX - startX, touch.clientY - startY);
};

const handleJoystickEnd = (e) => {
  if (!joystickActive) return;
  if (e.changedTouches && !Array.from(e.changedTouches).some(t => t.identifier === joystickTouchId)) return;
  joystickActive = false;
  joystickTouchId = null;
  updateJoystickUI(0, 0); 
  clearJoystickKeys();
};

joystickZone.addEventListener('touchstart', handleJoystickStart, { passive: false });
window.addEventListener('touchmove', handleJoystickMove, { passive: false });
window.addEventListener('touchend', handleJoystickEnd);
joystickZone.addEventListener('mousedown', handleJoystickStart);
window.addEventListener('mousemove', handleJoystickMove);
window.addEventListener('mouseup', handleJoystickEnd);

/* Button Handling */
const triggerHaptic = () => {
  if (hapticEnabled && navigator.vibrate) navigator.vibrate(10);
};

document.querySelectorAll('.action-btn').forEach(btn => {
  const key = btn.getAttribute('data-key');
  const start = (e) => {
    e.preventDefault();
    dispatchKey(key, 'keydown');
    btn.classList.add('active');
    triggerHaptic();
  };
  const end = (e) => {
    e.preventDefault();
    dispatchKey(key, 'keyup');
    btn.classList.remove('active');
  };
  btn.addEventListener('touchstart', start, { passive: false });
  btn.addEventListener('touchend', end, { passive: false });
  btn.addEventListener('mousedown', start);
  btn.addEventListener('mouseup', end);
});

/* Fullscreen & Mute */
const fsBtn = document.getElementById('fs-btn');
fsBtn.addEventListener('click', () => {
  playSelectSound();
  if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => {});
  else document.exitFullscreen();
});

const muteBtn = document.getElementById('mute-btn');
let isMuted = false;
muteBtn.addEventListener('click', () => {
  isMuted = !isMuted;
  muteBtn.classList.toggle('muted', isMuted);
  playSelectSound();
  try {
    if (Module?.SDL2?.audioContext) {
      if (isMuted) Module.SDL2.audioContext.suspend();
      else Module.SDL2.audioContext.resume();
    }
  } catch (e) {}
});

/* Persisted Settings Load */
window.addEventListener('DOMContentLoaded', () => {
  const savedMode = localStorage.getItem('sm64_control_mode') || 'default';
  controlModeSelect.value = savedMode;
  setControlMode(savedMode);

  const haptic = localStorage.getItem('sm64_haptic');
  hapticEnabled = haptic !== 'false';
  hapticToggle.checked = hapticEnabled;

  const opac = localStorage.getItem('sm64_joystick_opacity') || '0.8';
  joystickOpacitySlider.value = opac;
  joystickBase.style.opacity = opac;

  const size = localStorage.getItem('sm64_controls_size') || '1';
  controlsSizeSlider.value = size;
  actionButtonsContainer.style.transform = `scale(${size})`;
  joystickBase.style.transform = `scale(${size})`;
});

/* Cloud Save Logic */
const SAVE_FILE_NAME = 'sm64_save_file';
async function syncToCloud() {
  if (!window.Module?.FS || !window.websim?.datastore) return;
  try {
    if (typeof Module._save_game === 'function') Module._save_game();
    let exists = false;
    try { Module.FS.stat('/' + SAVE_FILE_NAME); exists = true; } catch(e) {}
    if (exists) {
      const data = Module.FS.readFile('/' + SAVE_FILE_NAME);
      let binary = '';
      for (let i = 0; i < data.length; i++) binary += String.fromCharCode(data[i]);
      const base64Data = btoa(binary);
      await websim.datastore.set('sm64_cloud_save', { content: base64Data, timestamp: Date.now() });
    }
  } catch (err) {}
}

async function loadFromCloud() {
  if (!window.websim?.datastore || !window.Module?.FS) return false;
  try {
    const saved = await websim.datastore.get('sm64_cloud_save');
    if (saved && saved.content) {
      const binaryString = atob(saved.content);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
      Module.FS.writeFile('/' + SAVE_FILE_NAME, bytes);
      return true;
    }
  } catch (err) {}
  return false;
}

async function loadPersistentMods() {
  if (!window.websim?.datastore) return;
  try {
    const mods = await websim.datastore.get('sm64_mods') || [];
    if (!Array.isArray(mods)) return;
    for (const mod of mods) {
      if (!mod || !mod.content) continue;
      try {
        const binaryString = atob(mod.content);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
        
        if (window.Module?.FS) {
          window.Module.FS.writeFile('/' + (mod.name || 'mod'), bytes);
        }

        if (mod.name && mod.name.endsWith('.js')) {
          const script = document.createElement('script');
          script.textContent = new TextDecoder().decode(bytes);
          document.body.appendChild(script);
        }
      } catch (err) {
        safeLog(`Failed to load persistent mod ${mod.name}:`, err);
      }
    }
  } catch (err) {
    safeLog("Error loading persistent mods:", err);
  }
}

Module.onRuntimeInitialized = async function() {
  try {
    await loadFromCloud();
    await loadPersistentMods();
    refreshModList();
    setInterval(syncToCloud, 15000);
  } catch (err) {
    safeLog("Initialization error:", err);
  }
};

/* Controller Support (Gamepad API) */
const gamepadStates = new Map();
let psSessionActive = false;
let psControllerIndex = null;
let psToastShown = false;

const psToast = document.getElementById('ps-toast');
const psConnectBtn = document.getElementById('ps-connect-btn');
const psDismissBtn = document.getElementById('ps-dismiss-btn');
const endSessionBtn = document.getElementById('end-session-btn');

function isPsController(id) {
  const lowerId = id.toLowerCase();
  // Standard PS identifiers including mobile Bluetooth variants (iOS/Android)
  return lowerId.includes('dualshock') || 
         lowerId.includes('dualsense') || 
         lowerId.includes('playstation') || 
         lowerId.includes('sony') || 
         lowerId.includes('wireless controller') ||
         lowerId.includes('054c'); // Sony Vendor ID
}

function showPsToast() {
  if (psToastShown) return;
  psToast.classList.remove('hidden');
  psToast.classList.add('show');
  psToastShown = true;
}

function hidePsToast() {
  psToast.classList.remove('show');
  psToast.classList.add('hidden');
}

function startPsSession() {
  psSessionActive = true;
  hidePsToast();
  controlModeSelect.value = 'playstation';
  setControlMode('playstation');
  endSessionBtn.classList.remove('hidden');
  endSessionBtn.classList.add('show');
}

function endPsSession() {
  psSessionActive = false;
  endSessionBtn.classList.remove('show');
  endSessionBtn.classList.add('hidden');
  controlModeSelect.value = 'default';
  setControlMode('default');
}

psConnectBtn.addEventListener('click', () => {
  playSelectSound();
  startPsSession();
});

psDismissBtn.addEventListener('click', () => {
  playSelectSound();
  hidePsToast();
});

endSessionBtn.addEventListener('click', () => {
  playSelectSound();
  endPsSession();
});

function handleGamepad(gp) {
  if (!gp) return;
  let state = gamepadStates.get(gp.index);
  if (!state) {
    state = { buttons: {}, axes: [0, 0], dpadUpPrev: false };
    gamepadStates.set(gp.index, state);
  }

  // Internal system: Detect if this is a PS controller via Bluetooth/Wireless
  if (isPsController(gp.id) && !psSessionActive && !psToastShown) {
    psControllerIndex = gp.index;
    showPsToast();
  }

  // Joystick mapping (Axes 0, 1)
  const axesX = Math.abs(gp.axes[0]) > 0.1 ? gp.axes[0] : 0;
  const axesY = Math.abs(gp.axes[1]) > 0.1 ? gp.axes[1] : 0;

  if (axesX !== state.axes[0] || axesY !== state.axes[1]) {
    if (Math.abs(axesX) > 0.2 || Math.abs(axesY) > 0.2) {
      updateJoystickUI(axesX * MAX_RADIUS, axesY * MAX_RADIUS);
    } else if (activeJoystickKeys.size > 0) {
      clearJoystickKeys();
      updateJoystickUI(0, 0);
    }
    state.axes = [axesX, axesY];
  }

  // Button mapping based on selected mode
  // Standard Gamepad Mapping: 0: Bottom, 1: Right, 2: Left, 3: Top, 9: Start
  const mode = (psSessionActive && gp.index === psControllerIndex) ? 'playstation' : controlModeSelect.value;
  const buttons = gp.buttons;

  const map = {
    // A -> Jump (X), B -> Attack (C), Z -> Crouch (Space), Start -> Enter
    default: { A: 0, B: 1, Z: 6, Start: 9 },
    playstation: { A: 0, B: 2, Z: 3, Start: 9 }, // X (0) = Jump, Square (2) = Attack, Triangle (3) = Crouch, Options (9) = Start
    xbox: { A: 0, B: 2, Z: 3, Start: 9 }, // A (0) = Jump, X (2) = Attack, Y (3) = Crouch, Menu (9) = Start
    switch: { A: 1, B: 0, Z: 3, Start: 9 } // A (1) = Jump, B (0) = Attack, X (3) = Crouch, Plus (9) = Start
  };

  const currentMap = map[mode] || map.default;

  const processBtn = (btnIdx, key) => {
    const isPressed = !!buttons[btnIdx]?.pressed;
    if (isPressed !== state.buttons[btnIdx]) {
      dispatchKey(key, isPressed ? 'keydown' : 'keyup');
      state.buttons[btnIdx] = isPressed;

      const uiBtn = document.querySelector(`.action-btn[data-key="${key}"]`);
      if (uiBtn) {
        if (isPressed) uiBtn.classList.add('active');
        else uiBtn.classList.remove('active');
      }
    }
  };

  processBtn(currentMap.A, 'KeyX');
  processBtn(currentMap.B, 'KeyC');
  processBtn(currentMap.Z, 'Space');
  processBtn(currentMap.Start, 'Enter');

  // End session via D-pad Up (button 12) on the active PS controller
  if (psSessionActive && gp.index === psControllerIndex) {
    const dpadUp = !!buttons[12]?.pressed;
    if (dpadUp && !state.dpadUpPrev) {
      endPsSession();
    }
    state.dpadUpPrev = dpadUp;
  }
}

let gamepadLoopRunning = false;
function gamepadLoop() {
  if (gamepadLoopRunning) return;
  gamepadLoopRunning = true;
  
  function step() {
    // In many browsers, you MUST call getGamepads in the loop to get updated state
    const gamepads = (navigator.getGamepads ? navigator.getGamepads() : []);
    let anyActive = false;
    
    for (let i = 0; i < gamepads.length; i++) {
      const gp = gamepads[i];
      if (gp && gp.connected) {
        handleGamepad(gp);
        anyActive = true;
      }
    }
    
    // Add a visual indicator if a gamepad is actively connected
    if (anyActive) {
      document.body.classList.add('gamepad-active');
    } else {
      document.body.classList.remove('gamepad-active');
    }
    
    requestAnimationFrame(step);
  }
  step();
}

window.addEventListener("gamepadconnected", (e) => {
  safeLog("Gamepad connected:", e.gamepad.id);
  // Re-check for PS controller every time a new one connects
  if (isPsController(e.gamepad.id) && !psSessionActive && !psToastShown) {
    psControllerIndex = e.gamepad.index;
    showPsToast();
  }
  gamepadLoop();
});

window.addEventListener("gamepaddisconnected", (e) => {
  safeLog("Gamepad disconnected:", e.gamepad.index);
  if (e.gamepad.index === psControllerIndex) {
    psControllerIndex = null;
    hidePsToast();
    psToastShown = false;
    if (psSessionActive) endPsSession();
  }
  gamepadStates.delete(e.gamepad.index);
});

// Internal system: Bluetooth device polling and initial detection
async function checkBluetoothAvailability() {
  if (navigator.bluetooth && navigator.bluetooth.getAvailability) {
    const available = await navigator.bluetooth.getAvailability();
    if (available) safeLog("Bluetooth is active and available for controller scanning.");
  }
}

// Check for already connected PlayStation controllers on load
const checkExistingGamepads = () => {
  const gamepads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const gp of gamepads) {
    if (gp && isPsController(gp.id) && !psSessionActive && !psToastShown) {
      psControllerIndex = gp.index;
      showPsToast();
      break;
    }
  }
};

checkBluetoothAvailability();
setTimeout(checkExistingGamepads, 1000); // Small delay to let gamepads initialize
gamepadLoop();