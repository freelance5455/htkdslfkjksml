const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const http = require('http');

// Port fixe de l'interface : http://localhost:8765/index.html
// (a declarer dans Google Cloud si vous utilisez la connexion Google / Drive).
const PORT = 8765;
const URL_APP = 'http://localhost:' + PORT + '/index.html';

// Google refuse la connexion dans un navigateur "Electron" : on retire la mention.
app.userAgentFallback = app.userAgentFallback
  .replace(/\sElectron\/\S+/, '')
  .replace(/\s[\w.-]+\/\d[\w.-]*(?=\sChrome)/, '');

let win = null;
const syncServer = require('./syncserver.js')(path.join(app.getPath('userData'), 'serveur-sync.json'));
const cfgFile = () => path.join(app.getPath('userData'), 'gc-config.json');
const readCfg = () => { try { return JSON.parse(fs.readFileSync(cfgFile(), 'utf8')); } catch (e) { return {}; } };
const writeCfg = o => { try { fs.writeFileSync(cfgFile(), JSON.stringify(Object.assign(readCfg(), o))); } catch (e) {} };

function startServer() {
  return new Promise(resolve => {
    const srv = http.createServer((req, res) => {
      const p = req.url.split('?')[0].split('#')[0];
      if (p === '/' || p === '/index.html') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        fs.createReadStream(path.join(__dirname, 'index.html')).pipe(res);
      } else { res.writeHead(404); res.end(); }
    });
    srv.on('error', () => resolve(false));
    srv.listen(PORT, '127.0.0.1', () => resolve(true));
  });
}

function registerIpc() {
  // --- synchronisation : le client appelle le serveur du reseau local ---
  ipcMain.handle('gc:sync', async (e, url, payload) => {
    const r = await fetch(String(url).replace(/\/+$/, '') + '/api/sync', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000)
    });
    if (r.status === 401) return { error: 'token' };
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  });
  ipcMain.handle('gc:serverStart', async (e, port, token) => {
    const r = await syncServer.start(port, token);
    if (r.ok) writeCfg({ srvPort: parseInt(port, 10), srvToken: String(token), srvOn: true });
    return r;
  });
  ipcMain.handle('gc:serverStop', async () => { writeCfg({ srvOn: false }); return syncServer.stop(); });
  ipcMain.handle('gc:serverStatus', () => {
    const s = syncServer.status(), c = readCfg();
    if (!s.running) { s.port = c.srvPort || 8787; s.token = c.srvToken || ''; }
    return s;
  });
  // --- sauvegarde automatique dans Documents ---
  ipcMain.handle('gc:saveBackup', (e, o) => {
    try {
      const d = path.join(app.getPath('documents'), 'GESTION COLLEGE', 'Sauvegarde');
      fs.mkdirSync(d, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
      const reason = String((o && o.reason) || 'auto').replace(/[^\w-]/g, '_');
      const f = path.join(d, 'sauvegarde_' + stamp + '_' + reason + '.json');
      fs.writeFileSync(f, (o && o.json) || '');
      // garde les 60 dernieres
      const all = fs.readdirSync(d).filter(n => n.startsWith('sauvegarde_')).sort();
      all.slice(0, Math.max(0, all.length - 60)).forEach(n => { try { fs.unlinkSync(path.join(d, n)); } catch (x) {} });
      return { ok: true, path: f };
    } catch (x) { return { ok: false, error: String(x.message) }; }
  });
  // --- divers ---
  ipcMain.handle('gc:version', () => app.getVersion());
  ipcMain.handle('gc:updateGet', () => ({ url: readCfg().updUrl || '', packaged: app.isPackaged }));
  ipcMain.handle('gc:updateSet', (e, u) => { if (!/^https?:\/\//i.test(String(u || ''))) return false; writeCfg({ updUrl: String(u) }); return true; });
  ipcMain.handle('gc:updateCheck', () => ({ ok: false, reason: 'Mise a jour automatique non incluse dans cette version : reinstallez le nouveau .exe.' }));
  ipcMain.handle('gc:fsGet', () => !!(win && win.isFullScreen()));
  ipcMain.handle('gc:fsSet', (e, v) => { if (win) win.setFullScreen(!!v); return !!v; });
  ipcMain.handle('gc:fsToggle', () => { if (win) win.setFullScreen(!win.isFullScreen()); return !!(win && win.isFullScreen()); });
}

async function createWindow() {
  win = new BrowserWindow({
    width: 1366, height: 820, show: false, icon: path.join(__dirname, 'build', 'icon.png'), autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, preload: path.join(__dirname, 'preload.js') }
  });
  win.maximize();
  win.once('ready-to-show', () => win.show());
  win.on('enter-full-screen', () => win.webContents.send('gc:fs', true));
  win.on('leave-full-screen', () => win.webContents.send('gc:fs', false));
  win.on('closed', () => { win = null; });
  win.webContents.setWindowOpenHandler(() => ({ action: 'allow' }));
  const ok = await startServer();
  if (ok) win.loadURL(URL_APP);
  else win.loadFile(path.join(__dirname, 'index.html')); // secours (sans connexion Google)
}

app.whenReady().then(async () => {
  require('./fichiers.js')();
  registerIpc();
  Menu.setApplicationMenu(null);
  const c = readCfg();
  if (c.srvOn && c.srvPort && c.srvToken) await syncServer.start(c.srvPort, c.srvToken); // redemarre le serveur si actif a la fermeture
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
