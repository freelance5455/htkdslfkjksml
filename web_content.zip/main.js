import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { SHIPS, buildShip, disposeShip, animateShip } from './ships.js';
import { SynthAudio, TRACKS } from './audio.js';

// =====================================================================
// Constants
// =====================================================================
const W = 38;                 // half width of flight corridor
const CL = 140;               // chunk length
const VIEW = 720;             // generate this far ahead
const BASE_Y = 2.0;           // cruise altitude
const GRAV = 44;
const REGION_LEN = 3000;
const PHB = { x: 1.25, y: 0.45, z: 1.6 }; // player half-box

const BIOMES = [
  { name: 'SOLAR FLATS', ground: 0x2a1c24, grid: 0xff7a2a, obs: [0xbfb4aa, 0xa89c92, 0xcfc5bb, 0x948a82], edge: 0xff8a3a, fog: 0x4a2430, skyTop: 0x1d1448, skyMid: 0xff7e4a, skyBot: 0x3a1828, sun: 0xffb36b, mount: 0x24121e, hemiS: 0xffc9a0, hemiG: 0x3a2030, track: 'solar' },
  { name: 'AZURE OCEAN', ocean: true, ground: 0x06202e, grid: 0x2ad8ff, obs: [0x2a4a5a], edge: 0x5af0ff, fog: 0x1a3a58, skyTop: 0x0a1640, skyMid: 0xff9a6a, skyBot: 0x10304a, sun: 0xffc890, mount: 0x0c2236, hemiS: 0xbfe8ff, hemiG: 0x0a2a3a, track: 'tides' },
  { name: 'NEON GRID', ground: 0x0c0820, grid: 0xff2bd6, obs: [0x2a1a50, 0x342060, 0x22164a, 0x3c2470], edge: 0x34f5ff, fog: 0x200c3c, skyTop: 0x06021c, skyMid: 0xd02890, skyBot: 0x160830, sun: 0xff70d8, mount: 0x10062a, hemiS: 0xff9ae8, hemiG: 0x1a0c3a, track: 'neon' },
  { name: 'CRYSTAL VOID', ground: 0x08202a, grid: 0x3cf2ff, obs: [0x8cc4d8, 0x74b0c8, 0xa4d6e6, 0x5c98b0], edge: 0x7af7ff, fog: 0x0c3040, skyTop: 0x030e20, skyMid: 0x40b8d0, skyBot: 0x062028, sun: 0xe0fcff, mount: 0x061a24, hemiS: 0xb0f4ff, hemiG: 0x0a2a34, track: 'crystal' },
  { name: 'CRIMSON STORM', ground: 0x1c080c, grid: 0xff2a3a, obs: [0x3a1a1e, 0x4a2026, 0x2e1418, 0x5a262c], edge: 0xff4a2f, fog: 0x380c10, skyTop: 0x0e0306, skyMid: 0xe03a1e, skyBot: 0x24080a, sun: 0xff7a40, mount: 0x180508, hemiS: 0xff9a7a, hemiG: 0x2a0a0e, track: 'crimson' },
  { name: 'AURORA RIFT', ground: 0x081a14, grid: 0x5bff9a, obs: [0x223a36, 0x2c4a44, 0x1a302c, 0x36584f], edge: 0xa07bff, fog: 0x10282a, skyTop: 0x060c22, skyMid: 0x34d090, skyBot: 0x0a2020, sun: 0xd0ffe0, mount: 0x081612, hemiS: 0xb8ffd8, hemiG: 0x0c2420, track: 'aurora' },
];

const POWERS = {
  jump: { label: 'JUMP', key: 'J', color: '#5bff9a', hex: 0x5bff9a },
  shield: { label: 'SHIELD', key: 'S', color: '#4db8ff', hex: 0x4db8ff, dur: 14 },
  phase: { label: 'PHASE', key: 'P', color: '#c06bff', hex: 0xc06bff, dur: 6 },
  magnet: { label: 'MAGNET', key: 'M', color: '#ff4fd8', hex: 0xff4fd8, dur: 10 },
  overdrive: { label: 'OVERDRIVE', key: 'O', color: '#ff5a2a', hex: 0xff5a2a, dur: 5 },
  slowmo: { label: 'CHRONO', key: 'C', color: '#ffe066', hex: 0xffe066, dur: 6 },
};
const POWER_KEYS = Object.keys(POWERS);

const UPGRADES = [
  { id: 'solar', name: 'SOLAR CELLS', desc: '−8% energy drain per level', max: 5, cost: l => 150 + l * 160 },
  { id: 'jump', name: 'JUMP CAPACITOR', desc: '+1 jump charge at launch', max: 3, cost: l => 220 + l * 260 },
  { id: 'shield', name: 'AEGIS EMITTER', desc: 'Launch shielded; shields last longer', max: 3, cost: l => 300 + l * 300 },
  { id: 'magnet', name: 'FLUX MAGNET', desc: 'Wider pickup radius', max: 4, cost: l => 160 + l * 180 },
];

// One-time-use supernatural abilities (bought in the hangar, consumed on use)
const ABILITIES = [
  { id: 'nova', name: 'SOLAR NOVA', key: '1', glyph: '✹', color: '#ffb030', hex: 0xffb030, cost: 350, desc: 'Release a wave of solar fire that vaporises every building within 10 km.' },
  { id: 'warp', name: 'HYPER WARP', key: '2', glyph: '➤', color: '#7a8bff', hex: 0x7a8bff, cost: 400, desc: 'Fold space and leap 1.5 km ahead, untouchable on arrival.' },
  { id: 'sunheart', name: 'SUN HEART', key: '3', glyph: '☀', color: '#ffe066', hex: 0xffe066, cost: 250, desc: 'Refill your solar core instantly. No drain for 12 seconds.' },
  { id: 'ghost', name: 'GHOST FORM', key: '4', glyph: '◌', color: '#c06bff', hex: 0xc06bff, cost: 200, desc: 'Become a spirit and pass through everything for 12 seconds.' },
  { id: 'rebirth', name: 'PHOENIX REBIRTH', key: '—', glyph: '♆', color: '#ff5a3a', hex: 0xff5a3a, cost: 600, auto: true, desc: 'Passive. When you crash or the sun sets, rise again with a full core.' },
];

// =====================================================================
// Global state (saved to a tiny server-side record, ~1 KB)
// =====================================================================
const G = {
  mode: 'loading', // loading | title | hangar | run | paused | crashing | sunset | gameover
  credits: 400,
  best: 0,
  shipIdx: 0,
  owned: SHIPS.map(s => s.cost === 0),
  upg: { solar: 0, jump: 0, shield: 0, magnet: 0 },
  abil: { nova: 1, warp: 0, sunheart: 1, ghost: 0, rebirth: 0 },
  settings: { music: 0.55, sfx: 0.7, track: 'auto', muted: false },
  debug: false,
  time: 0,
  timeScale: 1,
};

// ---------------- save / load ----------------
const SAVE = { api: null, ok: false, timer: null, status: 'local' };
{
  const raw = window.__API_BASE__ || '';
  const local = ['localhost', '127.0.0.1', '[::1]'].includes(location.hostname);
  if (raw && !raw.startsWith('__PORT_')) SAVE.api = raw.replace(/\/$/, '');
  else if (local) SAVE.api = 'http://localhost:8000';
}
function serialize() {
  return {
    v: 1, credits: Math.floor(G.credits), best: Math.floor(G.best), ship: SHIPS[G.shipIdx].id,
    owned: SHIPS.filter((s, i) => G.owned[i]).map(s => s.id), upg: G.upg, abil: G.abil, settings: G.settings,
  };
}
function applySave(d) {
  if (!d || typeof d !== 'object') return;
  if (Number.isFinite(d.credits)) G.credits = Math.max(0, d.credits);
  if (Number.isFinite(d.best)) G.best = d.best;
  if (Array.isArray(d.owned)) G.owned = SHIPS.map(s => s.cost === 0 || d.owned.includes(s.id));
  const si = SHIPS.findIndex(s => s.id === d.ship);
  if (si >= 0 && G.owned[si]) G.shipIdx = si;
  if (d.upg) for (const k in G.upg) if (Number.isFinite(d.upg[k])) G.upg[k] = d.upg[k];
  if (d.abil) for (const k in G.abil) if (Number.isFinite(d.abil[k])) G.abil[k] = d.abil[k];
  if (d.settings) Object.assign(G.settings, d.settings);
}
async function loadProgress() {
  if (!SAVE.api) return;
  try {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 6000);
    const r = await fetch(SAVE.api + '/api/save', { credentials: 'same-origin', signal: ctl.signal });
    clearTimeout(to);
    if (r.ok) { const j = await r.json(); if (j && j.data) applySave(j.data); SAVE.ok = true; SAVE.status = 'synced'; }
  } catch (e) { SAVE.status = 'offline'; }
}
function saveProgress(now = false) {
  clearTimeout(SAVE.timer);
  const go = () => {
    if (!SAVE.api) return;
    fetch(SAVE.api + '/api/save', {
      method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(serialize()),
    }).then(r => { SAVE.status = r.ok ? 'synced' : 'offline'; updateSaveBadge(); }).catch(() => { SAVE.status = 'offline'; updateSaveBadge(); });
  };
  if (now) go(); else SAVE.timer = setTimeout(go, 600);
}
function updateSaveBadge() {
  const el = document.getElementById('save-badge');
  if (!el) return;
  el.textContent = SAVE.status === 'synced' ? 'PROGRESS SAVED' : SAVE.status === 'offline' ? 'SAVE OFFLINE' : 'LOCAL SESSION';
  el.className = 'save-badge ' + SAVE.status;
}

const audio = new SynthAudio();
const _init = audio.init.bind(audio);
audio.init = () => {
  const fresh = !audio.ctx;
  _init();
  if (fresh && audio.ctx) { audio.setMusicVolume(G.settings.music); audio.setSfxVolume(G.settings.sfx); audio.setMuted(!!G.settings.muted); }
};
const $ = id => document.getElementById(id);
const rand = (a, b) => a + Math.random() * (b - a);
const randi = (a, b) => Math.floor(rand(a, b + 1));
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const isTouch = matchMedia('(pointer: coarse)').matches;

// =====================================================================
// Renderer & post
// =====================================================================
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, isTouch ? 1.5 : 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.95;
renderer.info.autoReset = false;
$('app').appendChild(renderer.domElement);

const pmrem = new THREE.PMREMGenerator(renderer);
const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;

const scene = new THREE.Scene();
scene.environment = envTex;
const camera = new THREE.PerspectiveCamera(70, innerWidth / innerHeight, 0.1, 4000);
scene.fog = new THREE.Fog(0x4a2430, 160, 680);

const composer = new EffectComposer(renderer);
const renderPass = new RenderPass(scene, camera);
composer.addPass(renderPass);
const bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), 0.55, 0.45, 0.92);
composer.addPass(bloom);
composer.addPass(new OutputPass());
const fxPass = new ShaderPass({
  uniforms: {
    tDiffuse: { value: null }, aberr: { value: 0.0 }, vig: { value: 0.55 },
    tint: { value: new THREE.Color(0x0a1440) }, tintAmt: { value: 0 }, time: { value: 0 },
  },
  vertexShader: `varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }`,
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform float aberr, vig, tintAmt, time; uniform vec3 tint; varying vec2 vUv;
    void main(){
      vec2 c = vUv - 0.5; float r = dot(c,c);
      vec2 off = c * aberr * (0.4 + r * 3.0);
      vec3 col;
      col.r = texture2D(tDiffuse, vUv + off).r;
      col.g = texture2D(tDiffuse, vUv).g;
      col.b = texture2D(tDiffuse, vUv - off).b;
      col *= 1.0 - vig * smoothstep(0.08, 0.7, r * 1.4);
      col = mix(col, tint, tintAmt * smoothstep(0.02, 0.45, r));
      float n = fract(sin(dot(vUv * (time + 1.0), vec2(12.9898, 78.233))) * 43758.5453);
      col += (n - 0.5) * 0.025;
      gl_FragColor = vec4(col, 1.0);
    }`,
});
composer.addPass(fxPass);

// =====================================================================
// Shared textures
// =====================================================================
function canvasTex(size, draw, srgb = true) {
  const c = document.createElement('canvas');
  c.width = c.height = size;
  draw(c.getContext('2d'), size);
  const t = new THREE.CanvasTexture(c);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = renderer.capabilities.getMaxAnisotropy();
  return t;
}
const gridTex = canvasTex(256, (x, s) => {
  x.fillStyle = '#3a3a44'; x.fillRect(0, 0, s, s);
  x.fillStyle = '#ffffff';
  x.fillRect(0, 0, s, 3); x.fillRect(0, 0, 3, s);
  x.globalAlpha = 0.25; x.fillRect(0, s / 2, s, 1); x.fillRect(s / 2, 0, 1, s);
});
gridTex.wrapS = gridTex.wrapT = THREE.RepeatWrapping;
const gridEm = canvasTex(256, (x, s) => {
  x.fillStyle = '#000'; x.fillRect(0, 0, s, s);
  x.fillStyle = '#fff';
  x.fillRect(0, 0, s, 3); x.fillRect(0, 0, 3, s);
  x.globalAlpha = 0.15; x.fillRect(0, s / 2, s, 1); x.fillRect(s / 2, 0, 1, s);
});
gridEm.wrapS = gridEm.wrapT = THREE.RepeatWrapping;
const edgeMap = canvasTex(128, (x, s) => {
  const g = x.createLinearGradient(0, 0, 0, s);
  g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#c8c8c8');
  x.fillStyle = g; x.fillRect(0, 0, s, s);
  x.fillStyle = 'rgba(0,0,0,0.12)';
  for (let i = 12; i < s; i += 24) x.fillRect(0, i, s, 2);
});
const edgeEm = canvasTex(128, (x, s) => {
  x.fillStyle = '#000'; x.fillRect(0, 0, s, s);
  x.strokeStyle = '#fff'; x.lineWidth = 3; x.strokeRect(1.5, 1.5, s - 3, s - 3);
  x.fillStyle = '#fff'; x.fillRect(0, s * 0.82, s, 2);
});
const glowSprite = canvasTex(64, (x, s) => {
  const g = x.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.6)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, s, s);
});
const padTex = canvasTex(128, (x, s) => {
  x.fillStyle = '#000'; x.fillRect(0, 0, s, s);
  x.strokeStyle = '#fff'; x.lineWidth = 10; x.lineCap = 'round';
  for (let i = 0; i < 3; i++) {
    const y = 30 + i * 34;
    x.beginPath(); x.moveTo(24, y + 22); x.lineTo(64, y - 4); x.lineTo(104, y + 22); x.stroke();
  }
  x.lineWidth = 4; x.strokeRect(4, 4, s - 8, s - 8);
});

// =====================================================================
// Environment: sky, sun, ground, mountains, lights
// =====================================================================
const sunDir = new THREE.Vector3(0.2, 0.3, -1).normalize();
const skyMat = new THREE.ShaderMaterial({
  side: THREE.BackSide, depthWrite: false, fog: false,
  uniforms: {
    top: { value: new THREE.Color() }, mid: { value: new THREE.Color() }, bot: { value: new THREE.Color() },
    sunCol: { value: new THREE.Color() }, sunDir: { value: sunDir }, night: { value: 0 }, time: { value: 0 },
  },
  vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix*modelViewMatrix*vec4(position,1.0); gl_Position = p.xyww; }`,
  fragmentShader: `
    uniform vec3 top, mid, bot, sunCol, sunDir; uniform float night, time; varying vec3 vDir;
    float hash(vec3 p){ p = fract(p*0.3183099 + 0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
    void main(){
      vec3 d = normalize(vDir); float h = d.y;
      vec3 col = h > 0.0 ? mix(mid, top, pow(clamp(h*1.6,0.0,1.0), 0.6)) : mix(mid, bot, clamp(-h*6.0,0.0,1.0));
      vec3 sd = normalize(sunDir);
      float s = max(dot(d, sd), 0.0);
      col += sunCol * (pow(s, 6.0) * 0.22 + pow(s, 48.0) * 0.45);
      float disk = smoothstep(0.9968, 0.9975, s);
      // sun bands (retro stripes in lower half of disk)
      float rel = (d.y - sd.y) * 220.0;
      float band = step(0.0, rel) + step(0.35, fract(rel * 0.18 + time * 0.2)) * step(rel, 0.0);
      vec3 diskCol = mix(sunCol * 1.9, vec3(1.0, 0.25, 0.12) * 1.4, clamp((sd.y - d.y) * 30.0 + 0.5, 0.0, 1.0));
      col = mix(col, diskCol, disk * clamp(band, 0.0, 1.0));
      // horizon glow
      col += sunCol * 0.18 * exp(-abs(h) * 18.0) * (0.4 + 0.6 * pow(max(dot(normalize(vec3(d.x,0.0,d.z)), normalize(vec3(sd.x,0.0,sd.z))),0.0), 3.0));
      // stars
      vec3 sp = floor(d * 380.0);
      float st = step(0.9975, hash(sp)) * smoothstep(0.04, 0.35, h) * night;
      st *= 0.6 + 0.4 * sin(time * 3.0 + hash(sp + 1.0) * 30.0);
      col += vec3(st) * 2.2;
      gl_FragColor = vec4(col, 1.0);
    }`,
});
const sky = new THREE.Mesh(new THREE.SphereGeometry(3000, 32, 16), skyMat);
sky.frustumCulled = false;
scene.add(sky);

const hemi = new THREE.HemisphereLight(0xffc9a0, 0x3a2030, 0.9);
scene.add(hemi);
const sunLight = new THREE.DirectionalLight(0xffb36b, 3.0);
sunLight.castShadow = true;
sunLight.shadow.mapSize.set(2048, 2048);
const sc = sunLight.shadow.camera;
sc.left = -70; sc.right = 70; sc.top = 110; sc.bottom = -110; sc.near = 1; sc.far = 600;
sunLight.shadow.bias = -0.0006;
sunLight.shadow.normalBias = 0.06;
scene.add(sunLight, sunLight.target);

const groundMat = new THREE.MeshStandardMaterial({ color: 0x2a1c24, map: gridTex, emissive: 0xff7a2a, emissiveMap: gridEm, emissiveIntensity: 1.3, roughness: 0.55, metalness: 0.35 });
gridTex.repeat.set(160, 160); gridEm.repeat.set(160, 160);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(1600, 1600).rotateX(-Math.PI / 2), groundMat);
ground.receiveShadow = true;
scene.add(ground);

// ocean surface: one long plane that covers each ocean zone exactly, so coasts look natural
function makeWaterNormals(size) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const x = c.getContext('2d');
  const h = new Float32Array(size * size);
  const waves = Array.from({ length: 7 }, () => ({ kx: randi(1, 6), ky: randi(1, 6) * (Math.random() < 0.5 ? -1 : 1), p: Math.random() * 6, a: rand(0.4, 1) }));
  for (let j = 0; j < size; j++) for (let i = 0; i < size; i++) {
    let v = 0; for (const w of waves) v += Math.sin((i * w.kx + j * w.ky) / size * Math.PI * 2 + w.p) * w.a;
    h[j * size + i] = v;
  }
  const img = x.createImageData(size, size);
  for (let j = 0; j < size; j++) for (let i = 0; i < size; i++) {
    const dx = h[j * size + (i + 1) % size] - h[j * size + (i - 1 + size) % size];
    const dy = h[((j + 1) % size) * size + i] - h[((j - 1 + size) % size) * size + i];
    const o = (j * size + i) * 4;
    img.data[o] = 128 + dx * 22; img.data[o + 1] = 128 + dy * 22; img.data[o + 2] = 255; img.data[o + 3] = 255;
  }
  x.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}
const waterNormals = makeWaterNormals(128);
waterNormals.repeat.set(40, 80);
const waterMat = new THREE.MeshStandardMaterial({
  color: 0x0a3550, metalness: 0.1, roughness: 0.55, normalMap: waterNormals, normalScale: new THREE.Vector2(1.2, 1.2),
  emissive: 0x052638, emissiveIntensity: 0.7, envMapIntensity: 0.25,

});
const water = new THREE.Mesh(new THREE.PlaneGeometry(1800, 3000).rotateX(-Math.PI / 2), waterMat);
water.position.y = 0.15;
water.visible = false;
scene.add(water);
// glowing shoreline strips at each end of the ocean
const shoreMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x5af0ff).multiplyScalar(2), transparent: true, opacity: 0.85 });
const shoreA = new THREE.Mesh(new THREE.PlaneGeometry(1800, 3).rotateX(-Math.PI / 2), shoreMat);
const shoreB = shoreA.clone();
shoreA.position.y = shoreB.position.y = 0.2;
water.add(shoreA, shoreB);
shoreA.position.z = 1500; shoreB.position.z = -1500;
const buoyGeo = new THREE.SphereGeometry(0.6, 10, 8);
const buoyMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x5af0ff).multiplyScalar(2.4) });

// distant mountain ring
function makeMountains() {
  const N = 160, R = 1300;
  const pos = [];
  let prev = null;
  for (let i = 0; i <= N; i++) {
    const a = (i / N) * Math.PI * 2;
    const h = 30 + Math.abs(Math.sin(i * 0.7) * 60) + Math.random() * 90 + (i % 7 === 0 ? 120 : 0);
    const p = [Math.cos(a) * R, h, Math.sin(a) * R];
    const b = [Math.cos(a) * R, -20, Math.sin(a) * R];
    if (prev) pos.push(...prev[1], ...prev[0], ...p, ...prev[1], ...p, ...b);
    prev = [p, b];
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  return new THREE.Mesh(g, new THREE.MeshBasicMaterial({ color: 0x24121e, fog: false, side: THREE.DoubleSide }));
}
const mountains = makeMountains();
scene.add(mountains);

// =====================================================================
// Biome materials
// =====================================================================
const boxGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
const obsMats = BIOMES.map(b => new THREE.MeshStandardMaterial({
  color: 0xffffff, map: edgeMap, emissive: b.edge, emissiveMap: edgeEm, emissiveIntensity: 1.8,
  roughness: 0.45, metalness: 0.4, envMapIntensity: 0.5,
}));
const pylonMats = BIOMES.map(b => new THREE.MeshBasicMaterial({ color: new THREE.Color(b.grid).multiplyScalar(2.5) }));
const padMat = new THREE.MeshBasicMaterial({ map: padTex, color: new THREE.Color(0x5bff9a).multiplyScalar(2.2), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
const portalMats = BIOMES.map(b => new THREE.MeshBasicMaterial({ color: new THREE.Color(b.grid).multiplyScalar(3), transparent: true, opacity: 0.95 }));

// pickup assets
const sunGeo = new THREE.IcosahedronGeometry(0.9, 0);
const sunMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffc040).multiplyScalar(3.2) });
const prismGeo = new THREE.OctahedronGeometry(0.62, 0).scale(1, 1.7, 1);
const prismMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0x4ff0ff).multiplyScalar(2.6) });
const coreGeo = new THREE.DodecahedronGeometry(0.75, 0);
const ringGeo = new THREE.TorusGeometry(1.35, 0.08, 6, 32);
const powerMats = Object.fromEntries(POWER_KEYS.map(k => [k, new THREE.MeshBasicMaterial({ color: new THREE.Color(POWERS[k].hex).multiplyScalar(3) })]));
const haloMats = {};
function haloMat(hex) {
  if (!haloMats[hex]) haloMats[hex] = new THREE.SpriteMaterial({ map: glowSprite, color: hex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.85 });
  return haloMats[hex];
}

// =====================================================================
// Chunks (procedural world)
// =====================================================================
let chunks = [];
let nextChunkZ = 0;
let chunkIndex = 0;

function regionAt(dist) { return Math.floor(Math.max(0, dist) / REGION_LEN); }
function biomeAt(dist) { return regionAt(dist) % BIOMES.length; }
function difficultyAt(dist) { return clamp(dist / 26000, 0, 1); }

function newChunk(z0) {
  const dist = -z0;
  const bi = biomeAt(dist + CL * 0.5);
  return { z0, z1: z0 - CL, bi, boxes: [], movers: [], pickups: [], pads: [], group: new THREE.Group(), mesh: null };
}

function addBox(c, x, y0, z, w, h, d, opts = {}) {
  const b = {
    minx: x - w / 2, maxx: x + w / 2, miny: y0, maxy: y0 + h, minz: z - d / 2, maxz: z + d / 2,
    solid: opts.solid !== false, dead: false, nm: false, idx: -1, color: opts.color,
  };
  c.boxes.push(b);
  return b;
}

function boxClear(c, x, y, z, r) {
  for (const b of c.boxes) {
    if (x > b.minx - r && x < b.maxx + r && z > b.minz - r && z < b.maxz + r && y > b.miny - r && y < b.maxy + r) return false;
  }
  return true;
}

function addPickup(c, type, x, y, z) {
  if (!boxClear(c, x, y, z, 1.6)) return null;
  let obj;
  if (type === 'sun') {
    obj = new THREE.Group();
    const m = new THREE.Mesh(sunGeo, sunMat); obj.add(m);
    const s = new THREE.Sprite(haloMat(0xffa030)); s.scale.set(6, 6, 1); obj.add(s);
  } else if (type === 'prism') {
    obj = new THREE.Mesh(prismGeo, prismMat);
  } else {
    obj = new THREE.Group();
    obj.add(new THREE.Mesh(coreGeo, powerMats[type]));
    const r = new THREE.Mesh(ringGeo, powerMats[type]); obj.add(r);
    const r2 = new THREE.Mesh(ringGeo, powerMats[type]); r2.rotation.y = Math.PI / 2; r2.scale.setScalar(0.8); obj.add(r2);
    const s = new THREE.Sprite(haloMat(POWERS[type].hex)); s.scale.set(7, 7, 1); obj.add(s);
  }
  obj.position.set(x, y, z);
  c.group.add(obj);
  const p = { type, obj, x, y, z, taken: false, phase: Math.random() * 6 };
  c.pickups.push(p);
  return p;
}

function addPad(c, x, z, w = 9) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 7).rotateX(-Math.PI / 2), padMat);
  m.position.set(x, 0.06, z);
  c.group.add(m);
  c.pads.push({ minx: x - w / 2, maxx: x + w / 2, minz: z - 3.5, maxz: z + 3.5, mesh: m });
}

function addMover(c, kind, x, z, w, h, d, amp, speed, phase) {
  const mesh = new THREE.Mesh(boxGeo, obsMats[c.bi]);
  mesh.scale.set(w, h, d);
  mesh.castShadow = true; mesh.receiveShadow = true;
  c.group.add(mesh);
  const box = addBox(c, x, 0, z, w, h, d, { mover: true });
  box.isMover = true;
  const m = { kind, mesh, box, x, z, w, h, d, amp, speed, phase };
  c.movers.push(m);
  updateMover(m, 0);
  return m;
}

function updateMover(m, t) {
  const s = Math.sin(t * m.speed + m.phase);
  let x = m.x, y = 0;
  if (m.kind === 'slide') x = clamp(m.x + s * m.amp, -W, W);
  else y = (s * 0.5 + 0.5) * m.amp; // piston lifts
  m.mesh.position.set(x, y, m.z);
  const b = m.box;
  b.minx = x - m.w / 2; b.maxx = x + m.w / 2; b.miny = y; b.maxy = y + m.h;
}

function prismLine(c, x, z, n, dx = 0, spacing = 6, y = BASE_Y + 0.3, wave = 0) {
  for (let i = 0; i < n; i++) addPickup(c, 'prism', clamp(x + dx * i + Math.sin(i * 0.8) * wave, -W + 2, W - 2), y, z - i * spacing);
}

const PATTERNS = {
  runway(c) {
    prismLine(c, rand(-10, 10), c.z0 - 40, 10, 0, 7, BASE_Y + 0.3, 6);
  },
  field(c, d) {
    const n = Math.floor(5 + d * 7);
    for (let i = 0; i < n; i++) {
      const w = rand(2.4, 6), dd = rand(2.4, 6);
      addBox(c, rand(-W, W), 0, rand(c.z1 + 6, c.z0 - 6), w, rand(5, 30), dd);
    }
    prismLine(c, rand(-25, 25), c.z0 - rand(10, 40), 7, rand(-1, 1), 7);
  },
  towers(c, d) {
    // giant monoliths + small rubble
    for (let i = 0; i < 2 + d * 2; i++) addBox(c, rand(-W + 4, W - 4), 0, rand(c.z1 + 10, c.z0 - 10), rand(5, 9), rand(30, 70), rand(5, 9));
    for (let i = 0; i < 4; i++) addBox(c, rand(-W, W), 0, rand(c.z1, c.z0), rand(1, 2.5), rand(2, 6), rand(1, 2.5));
    prismLine(c, rand(-20, 20), c.z0 - 20, 8, 0, 9, BASE_Y + 0.3, 8);
  },
  wall(c, d) {
    const gap = lerp(22, 13, d);
    const z = c.z0 - CL * 0.55;
    const gx = rand(-W + gap, W - gap);
    addBox(c, (-W - 6 + gx - gap / 2) / 2, 0, z, (gx - gap / 2) - (-W - 6), rand(12, 22), 3);
    addBox(c, (gx + gap / 2 + W + 6) / 2, 0, z, (W + 6) - (gx + gap / 2), rand(12, 22), 3);
    prismLine(c, gx, z + 30, 6, 0, 6);
    addPickup(c, 'sun', gx, BASE_Y + 0.4, z - 4);
    for (let i = 0; i < 2; i++) addBox(c, rand(-W, W), 0, rand(c.z1 + 4, z - 14), rand(2, 4), rand(6, 18), rand(2, 4));
  },
  jumpwall(c) {
    // low wall across everything, launch pads before it
    const z = c.z0 - CL * 0.6;
    addBox(c, 0, 0, z, W * 2 + 14, 3.4, 2.5);
    for (let x = -W + 6; x <= W - 6; x += rand(14, 20)) addPad(c, x, z + 26);
    prismLine(c, rand(-20, 20), z + 4, 5, 0, 4, 6.5);
    for (let i = 0; i < 2; i++) addBox(c, rand(-W, W), 0, rand(c.z1 + 4, z - 20), rand(2, 4), rand(8, 20), rand(2, 4));
  },
  arches(c, d) {
    for (let row = 0; row < 2; row++) {
      const z = c.z0 - 30 - row * 60;
      const off = row % 2 ? 6 : 0;
      const spacing = lerp(15, 12, d);
      for (let x = -W - 4 + off; x <= W + 4; x += spacing) addBox(c, x, 0, z, 2, 9, 2);
      addBox(c, 0, 9, z, W * 2 + 10, 2.2, 2.4);
    }
    prismLine(c, rand(-15, 15), c.z0 - 15, 14, 0, 8, BASE_Y + 0.3, 3);
  },
  slalom(c, d) {
    const gap = lerp(26, 16, d);
    for (let i = 0; i < 2; i++) {
      const z = c.z0 - 30 - i * 60;
      const left = (i + chunkIndex) % 2 === 0;
      if (left) addBox(c, (-W - 6 + (W - gap)) / 2, 0, z, (W - gap) + W + 6, rand(10, 18), 3);
      else addBox(c, ((-W + gap) + W + 6) / 2, 0, z, (W + 6) - (-W + gap), rand(10, 18), 3);
      const gx = left ? W - gap / 2 : -W + gap / 2;
      addPickup(c, i === 1 ? 'sun' : 'prism', gx, BASE_Y + 0.3, z);
    }
  },
  canyon(c, d) {
    const cx = rand(-16, 16), hw = lerp(11, 8, d);
    addBox(c, cx - hw - 6, 0, (c.z0 + c.z1) / 2 - 10, 12, rand(14, 26), CL - 30);
    addBox(c, cx + hw + 6, 0, (c.z0 + c.z1) / 2 - 10, 12, rand(14, 26), CL - 30);
    prismLine(c, cx, c.z0 - 18, 14, 0, 7, BASE_Y + 0.3, hw * 0.5);
    addPickup(c, 'sun', cx, BASE_Y + 0.3, c.z1 + 12);
    for (let i = 0; i < 2; i++) {
      const x = rand(-W, W);
      if (Math.abs(x - cx) > hw + 14) addBox(c, x, 0, rand(c.z1, c.z0), rand(3, 6), rand(6, 22), rand(3, 6));
    }
  },
  movers(c, d) {
    const n = 2 + Math.floor(d * 3);
    for (let i = 0; i < n; i++) {
      const z = c.z0 - 15 - i * (CL - 30) / n;
      addMover(c, 'slide', rand(-20, 20), z, rand(6, 12), rand(8, 16), rand(3, 5), rand(10, 24), rand(0.8, 1.6) * (1 + d * 0.5), rand(0, 6));
    }
    prismLine(c, rand(-15, 15), c.z0 - 10, 10, 0, 11);
  },
  pistons(c, d) {
    const z = c.z0 - 60;
    for (let x = -W; x <= W; x += 15) addMover(c, 'piston', x, z, 9, 12, 6, 9, 2.0 + d, x * 0.15);
    prismLine(c, rand(-10, 10), c.z0 - 15, 6, 0, 7);
  },
  breather(c) {
    for (let i = 0; i < 4; i++) {
      const s = Math.random() < 0.5 ? -1 : 1;
      addBox(c, s * rand(24, W), 0, rand(c.z1, c.z0), rand(3, 7), rand(10, 40), rand(3, 7));
    }
    prismLine(c, 0, c.z0 - 10, 18, 0, 7, BASE_Y + 0.3, 14);
    addPickup(c, 'sun', rand(-10, 10), BASE_Y + 0.3, c.z0 - 70);
  },
};
PATTERNS.ocean = function (c) {
  // open water: no buildings, just light to chase
  const kind = randi(0, 3);
  if (kind === 0) prismLine(c, rand(-25, 25), c.z0 - 10, 16, 0, 8, BASE_Y + 0.3, 16);
  else if (kind === 1) { for (let i = 0; i < 14; i++) addPickup(c, 'prism', Math.sin(i * 0.6) * 22, BASE_Y + 0.3 + Math.max(0, Math.sin(i * 0.45)) * 5, c.z0 - 8 - i * 9); }
  else if (kind === 2) { const x0 = rand(-20, 20); for (let i = 0; i < 12; i++) addPickup(c, 'prism', x0 + Math.cos(i * 0.9) * 6, BASE_Y + 0.3, c.z0 - 10 - i * 10); }
  else { prismLine(c, -20, c.z0 - 15, 8, 0, 9); prismLine(c, 20, c.z0 - 55, 8, 0, 9); }
  addPickup(c, 'sun', rand(-25, 25), BASE_Y + 0.4, c.z0 - rand(20, 60));
  if (Math.random() < 0.6) addPickup(c, 'sun', rand(-25, 25), BASE_Y + 0.4, c.z0 - rand(80, 125));
  // glowing buoys bobbing on the swell (decoration)
  for (let i = 0; i < 3; i++) {
    const b = new THREE.Mesh(buoyGeo, buoyMat);
    b.position.set((Math.random() < 0.5 ? -1 : 1) * rand(12, W + 20), 0.2, rand(c.z1, c.z0));
    b.userData.ph = Math.random() * 6;
    c.group.add(b); c.buoys = c.buoys || []; c.buoys.push(b);
  }
};
const PATTERN_WEIGHTS = [
  ['field', 3], ['towers', 2], ['wall', 2], ['jumpwall', 1.2], ['arches', 1.3], ['slalom', 1.6],
  ['canyon', 1.3], ['movers', 1.3], ['pistons', 0.9], ['breather', 2.6],
];
function choosePattern(d) {
  const tot = PATTERN_WEIGHTS.reduce((a, [, w]) => a + w, 0);
  let r = Math.random() * tot;
  for (const [k, w] of PATTERN_WEIGHTS) { r -= w; if (r <= 0) return k; }
  return 'field';
}

function generateChunk() {
  const c = newChunk(nextChunkZ);
  const dist = -c.z0;
  const d = difficultyAt(dist);
  // region portal inside this chunk?
  const nextBoundary = (regionAt(dist) + 1) * REGION_LEN;
  const hasPortal = nextBoundary < -c.z1 && nextBoundary >= dist;
  let pattern;
  const nextBi = (regionAt(dist) + 1) % BIOMES.length;
  if (chunkIndex < 2) pattern = 'runway';
  else if (BIOMES[c.bi].ocean || (hasPortal && BIOMES[nextBi].ocean)) pattern = 'ocean';
  else if (hasPortal) pattern = 'breather';
  else if (run.lastPattern !== 'breather' && run.lastPattern !== 'runway' && Math.random() < 0.22) pattern = 'breather';
  else pattern = choosePattern(d);
  if (pattern === run.lastPattern && pattern !== 'field' && pattern !== 'runway' && pattern !== 'ocean' && !hasPortal) pattern = choosePattern(d);
  run.lastPattern = pattern;
  PATTERNS[pattern](c, d);
  c.pattern = pattern;

  // sun cells & power-ups scattered
  if (Math.random() < 0.5) addPickup(c, 'sun', rand(-W + 4, W - 4), BASE_Y + 0.4, rand(c.z1 + 10, c.z0 - 10));
  if (chunkIndex > 1 && Math.random() < 0.3) {
    const type = pick(['jump', 'jump', 'shield', 'phase', 'magnet', 'overdrive', 'overdrive', 'slowmo']);
    addPickup(c, type, rand(-W + 6, W - 6), BASE_Y + 0.6, rand(c.z1 + 15, c.z0 - 15));
  }

  // boundary pylons (visual)
  {
    const py = new THREE.InstancedMesh(boxGeo, pylonMats[c.bi], 8);
    const pm = new THREE.Matrix4();
    let k = 0;
    for (let z = c.z0; z > c.z1 && k < 8; z -= 35) {
      for (const s of [-1, 1]) { pm.makeScale(0.5, 14, 0.5); pm.setPosition(s * (W + 4), 0, z); py.setMatrixAt(k++, pm); }
    }
    py.count = k;
    c.group.add(py);
    c.pylons = py;
  }
  // portal ring
  if (hasPortal) {
    const nb = (regionAt(dist) + 1) % BIOMES.length;
    const pz = -nextBoundary;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(W + 6, 1.4, 8, 64), portalMats[nb]);
    ring.position.set(0, 0, pz);
    c.group.add(ring);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(W + 12, 0.5, 6, 64), portalMats[nb]);
    ring2.position.set(0, 0, pz - 6);
    c.group.add(ring2);
    c.portal = { ring, ring2 };
  }

  // build instanced mesh for static boxes
  const statics = c.boxes.filter(b => !b.isMover);
  if (statics.length) {
    const im = new THREE.InstancedMesh(boxGeo, obsMats[c.bi], statics.length);
    const mtx = new THREE.Matrix4(), col = new THREE.Color();
    const pal = BIOMES[c.bi].obs;
    statics.forEach((b, i) => {
      mtx.makeScale(b.maxx - b.minx, b.maxy - b.miny, b.maxz - b.minz);
      mtx.setPosition((b.minx + b.maxx) / 2, b.miny, (b.minz + b.maxz) / 2);
      im.setMatrixAt(i, mtx);
      im.setColorAt(i, col.setHex(pick(pal)));
      b.idx = i;
    });
    im.castShadow = true; im.receiveShadow = true;
    im.instanceMatrix.needsUpdate = true;
    c.mesh = im;
    c.group.add(im);
  }
  scene.add(c.group);
  chunks.push(c);
  nextChunkZ = c.z1;
  chunkIndex++;
}

function disposeChunk(c) {
  scene.remove(c.group);
  if (c.mesh) c.mesh.dispose();
  if (c.pylons) c.pylons.dispose();
  c.group.traverse(o => {
    if (o.isMesh && o.geometry !== boxGeo && o.geometry !== sunGeo && o.geometry !== prismGeo && o.geometry !== coreGeo && o.geometry !== ringGeo) o.geometry.dispose();
  });
}

function resetWorld() {
  for (const c of chunks) disposeChunk(c);
  chunks = [];
  nextChunkZ = 20;
  chunkIndex = 0;
}

// =====================================================================
// FX: particles, debris, trails, speed lines, shield
// =====================================================================
const PMAX = 900;
const pPos = new Float32Array(PMAX * 3), pCol = new Float32Array(PMAX * 3);
const parts = [];
for (let i = 0; i < PMAX; i++) { parts.push({ life: 0, max: 1, x: 0, y: -999, z: 0, vx: 0, vy: 0, vz: 0, r: 1, g: 1, b: 1, drag: 0.96, grav: 0 }); pPos[i * 3 + 1] = -999; }
const pGeo = new THREE.BufferGeometry();
pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
const pMesh = new THREE.Points(pGeo, new THREE.PointsMaterial({ size: 0.9, map: glowSprite, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
pMesh.frustumCulled = false;
scene.add(pMesh);
let pCursor = 0;
function emit(x, y, z, n, color, speed = 10, life = 1, opts = {}) {
  const c = new THREE.Color(color);
  for (let i = 0; i < n; i++) {
    const p = parts[pCursor]; pCursor = (pCursor + 1) % PMAX;
    const th = Math.random() * Math.PI * 2, ph = Math.acos(rand(-1, 1));
    const s = speed * rand(0.3, 1);
    p.x = x; p.y = y; p.z = z;
    p.vx = Math.sin(ph) * Math.cos(th) * s + (opts.vx || 0);
    p.vy = Math.cos(ph) * s * (opts.flat ? 0.3 : 1) + (opts.vy || 0);
    p.vz = Math.sin(ph) * Math.sin(th) * s + (opts.vz || 0);
    p.life = p.max = life * rand(0.5, 1);
    const k = opts.bright || 2;
    p.r = c.r * k; p.g = c.g * k; p.b = c.b * k;
    p.drag = opts.drag ?? 0.95; p.grav = opts.grav ?? 0;
  }
}
function updateParticles(dt) {
  for (let i = 0; i < PMAX; i++) {
    const p = parts[i];
    if (p.life <= 0) { pPos[i * 3 + 1] = -999; continue; }
    p.life -= dt;
    const dr = Math.pow(p.drag, dt * 60);
    p.vx *= dr; p.vy = p.vy * dr - p.grav * dt; p.vz *= dr;
    p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
    const f = Math.max(0, p.life / p.max);
    pPos[i * 3] = p.x; pPos[i * 3 + 1] = p.y; pPos[i * 3 + 2] = p.z;
    pCol[i * 3] = p.r * f; pCol[i * 3 + 1] = p.g * f; pCol[i * 3 + 2] = p.b * f;
  }
  pGeo.attributes.position.needsUpdate = true;
  pGeo.attributes.color.needsUpdate = true;
}

const DMAX = 160;
const debrisMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xff8a3a, emissiveIntensity: 2, roughness: 0.4, metalness: 0.5 });
const debris = new THREE.InstancedMesh(new THREE.TetrahedronGeometry(0.6, 0), debrisMat, DMAX);
debris.frustumCulled = false;
debris.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
const dItems = [];
const _m4 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler(), _s = new THREE.Vector3(), _v = new THREE.Vector3();
for (let i = 0; i < DMAX; i++) { dItems.push({ life: 0, p: new THREE.Vector3(), v: new THREE.Vector3(), r: new THREE.Vector3(), w: new THREE.Vector3(), s: 1 }); debris.setMatrixAt(i, _m4.makeScale(0, 0, 0)); }
scene.add(debris);
let dCursor = 0;
function emitDebris(x, y, z, n, speed, scale = 1, color = null) {
  for (let i = 0; i < n; i++) {
    const d = dItems[dCursor];
    if (color) debris.setColorAt(dCursor, new THREE.Color(color));
    dCursor = (dCursor + 1) % DMAX;
    d.life = rand(1.2, 2.4);
    d.p.set(x + rand(-1, 1), y + rand(-1, 1), z + rand(-1, 1));
    d.v.set(rand(-1, 1), rand(0.2, 1.4), rand(-1, 1)).normalize().multiplyScalar(speed * rand(0.4, 1));
    d.r.set(rand(0, 6), rand(0, 6), rand(0, 6));
    d.w.set(rand(-10, 10), rand(-10, 10), rand(-10, 10));
    d.s = scale * rand(0.4, 1.4);
  }
  if (debris.instanceColor) debris.instanceColor.needsUpdate = true;
}
function updateDebris(dt) {
  for (let i = 0; i < DMAX; i++) {
    const d = dItems[i];
    if (d.life <= 0) { debris.setMatrixAt(i, _m4.makeScale(0, 0, 0)); continue; }
    d.life -= dt;
    d.v.y -= 30 * dt;
    d.p.addScaledVector(d.v, dt);
    if (d.p.y < 0.2) { d.p.y = 0.2; d.v.y *= -0.4; d.v.x *= 0.7; d.v.z *= 0.7; }
    d.r.addScaledVector(d.w, dt);
    const s = d.s * Math.min(1, d.life * 2);
    _q.setFromEuler(_e.set(d.r.x, d.r.y, d.r.z));
    debris.setMatrixAt(i, _m4.compose(d.p, _q, _s.set(s, s, s)));
  }
  debris.instanceMatrix.needsUpdate = true;
}

class Trail {
  constructor(n, width, color) {
    this.n = n; this.width = width; this.color = new THREE.Color(color);
    this.pts = [];
    const pos = new Float32Array(n * 2 * 3), col = new Float32Array(n * 2 * 3);
    const idx = [];
    for (let i = 0; i < n - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    this.geo.setIndex(idx);
    this.mesh = new THREE.Mesh(this.geo, new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
    this.mesh.frustumCulled = false;
  }
  reset(p) { this.pts = []; for (let i = 0; i < this.n; i++) this.pts.push(p.clone()); }
  push(p, intensity = 1) {
    const last = this.pts.pop() || new THREE.Vector3();
    last.copy(p);
    this.pts.unshift(last);
    const pos = this.geo.attributes.position.array, col = this.geo.attributes.color.array;
    for (let i = 0; i < this.n; i++) {
      const q = this.pts[i] || p;
      const f = 1 - i / (this.n - 1);
      const w = this.width * (0.2 + 0.8 * f);
      pos[i * 6] = q.x - w; pos[i * 6 + 1] = q.y; pos[i * 6 + 2] = q.z;
      pos[i * 6 + 3] = q.x + w; pos[i * 6 + 4] = q.y; pos[i * 6 + 5] = q.z;
      const k = f * f * intensity * 0.9;
      col[i * 6] = col[i * 6 + 3] = this.color.r * k;
      col[i * 6 + 1] = col[i * 6 + 4] = this.color.g * k;
      col[i * 6 + 2] = col[i * 6 + 5] = this.color.b * k;
    }
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
  }
}

// speed lines
const SL = 140;
const slPos = new Float32Array(SL * 6);
const slData = [];
for (let i = 0; i < SL; i++) slData.push({ x: 0, y: 0, z: 0 });
const slGeo = new THREE.BufferGeometry();
slGeo.setAttribute('position', new THREE.BufferAttribute(slPos, 3));
const slMat = new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.0, blending: THREE.AdditiveBlending, depthWrite: false });
const speedLines = new THREE.LineSegments(slGeo, slMat);
speedLines.frustumCulled = false;
scene.add(speedLines);
function resetSpeedLine(d, far = true) {
  const a = Math.random() * Math.PI * 2, r = rand(5, 26);
  d.x = Math.cos(a) * r; d.y = Math.abs(Math.sin(a) * r) * 0.7 + rand(-1, 4); d.z = far ? rand(-160, -40) : rand(-160, 5);
}
slData.forEach(d => resetSpeedLine(d, false));

// shield bubble
const shieldMat = new THREE.ShaderMaterial({
  transparent: true, blending: THREE.AdditiveBlending, depthWrite: false,
  uniforms: { color: { value: new THREE.Color(0x4db8ff) }, time: { value: 0 }, amt: { value: 1 } },
  vertexShader: `varying vec3 vN; varying vec3 vV; varying vec3 vP; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); vP = position; gl_Position = projectionMatrix*mv; }`,
  fragmentShader: `uniform vec3 color; uniform float time, amt; varying vec3 vN; varying vec3 vV; varying vec3 vP;
    void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 3.0); float hex = step(0.94, fract(vP.y*4.0 + time*1.5)) * 0.5; gl_FragColor = vec4(color * (f * 0.9 + hex * f) * amt, 1.0); }`,
});
const shieldMesh = new THREE.Mesh(new THREE.SphereGeometry(3.3, 32, 16), shieldMat);
shieldMesh.scale.set(1.25, 0.6, 1.2);
shieldMesh.visible = false;

// overdrive aura
const auraMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff5a2a).multiplyScalar(1.2), transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
const aura = new THREE.Mesh(new THREE.ConeGeometry(3.2, 10, 24, 1, true).rotateX(-Math.PI / 2).translate(0, 0, -1), auraMat);
aura.visible = false;

// =====================================================================
// Player
// =====================================================================
const playerRoot = new THREE.Group(); // position
const playerTilt = new THREE.Group(); // roll / pitch
playerRoot.add(playerTilt);
playerRoot.add(shieldMesh);
playerRoot.add(aura);
scene.add(playerRoot);
let shipModel = null;
let trails = [];
const engineSprites = [];

function mountShip(idx, root = playerTilt) {
  if (shipModel) { root.remove(shipModel); disposeShip(shipModel); }
  for (const t of trails) scene.remove(t.mesh);
  trails = [];
  for (const s of engineSprites) s.removeFromParent();
  engineSprites.length = 0;
  const def = SHIPS[idx];
  shipModel = buildShip(def);
  shipModel.scale.setScalar(0.8);
  root.add(shipModel);
  for (const tip of shipModel.userData.tips) {
    const t = new Trail(28, 0.07, def.accent); trails.push(t); scene.add(t.mesh); t.local = tip;
  }
  for (const e of shipModel.userData.engines) {
    const t = new Trail(12, 0.16, def.glow); trails.push(t); scene.add(t.mesh); t.local = e; t.engine = true;
    const s = new THREE.Sprite(haloMat(def.glow)); s.scale.set(1.4, 1.4, 1); s.position.copy(e); shipModel.add(s); engineSprites.push(s);
  }
}

const run = {};
function resetRun(auto = false) {
  const def = SHIPS[G.shipIdx];
  Object.assign(run, {
    auto, time: 0, x: 0, y: BASE_Y, z: 0, vx: 0, vy: 0, dashV: 0, dashT: 0, dashCd: 0, roll: 0, pitch: 0, rollSpin: 0,
    speed: def.speed, energy: 1, inShadow: false, shadowT: 0,
    score: 0, mult: 1, peakMult: 1, prisms: 0, nearMiss: 0, smashed: 0,
    jumps: def.jumps + G.upg.jump, powers: {}, invuln: 0, region: 0,
    crashT: 0, reason: '', lastPattern: '', shake: 0, fovKick: 0, flash: 0, warnT: 0, steer: 0,
  });
  if (def.phaseStart) run.powers.phase = def.phaseStart;
  if (G.upg.shield > 0) run.powers.shield = POWERS.shield.dur + G.upg.shield * 4;
  if (def.shieldStart) run.powers.shield = Math.max(run.powers.shield || 0, def.shieldStart + G.upg.shield * 4);
  run.shieldHits = def.shieldHits || 1;
  run.free = { nova: def.freeNova || 0, rebirth: def.freeRebirth || 0 };
  run.abilUsed = 0; run.noDrain = 0; run.novaT = -1; run.warpT = -1; run.overWater = false;
  lastAbilKey = '';
  resetWorld();
  while (nextChunkZ > -VIEW) generateChunk();
  playerRoot.position.set(0, BASE_Y, 0);
  playerRoot.visible = true;
  for (const t of trails) t.reset(new THREE.Vector3(0, BASE_Y, 0));
  applyBiome(0, true);
  camPos.set(0, BASE_Y + 3.5, 10);
}

// =====================================================================
// Biome application (sky / fog / ground)
// =====================================================================
const cur = {
  ground: new THREE.Color(), grid: new THREE.Color(), fog: new THREE.Color(), skyTop: new THREE.Color(), skyMid: new THREE.Color(),
  skyBot: new THREE.Color(), sun: new THREE.Color(), mount: new THREE.Color(), hemiS: new THREE.Color(), hemiG: new THREE.Color(),
};
const target = {};
for (const k in cur) target[k] = new THREE.Color();
function applyBiome(bi, instant) {
  const b = BIOMES[bi];
  for (const k in cur) { target[k].setHex(b[k]); if (instant) cur[k].setHex(b[k]); }
}
const _tmpC = new THREE.Color();
function updateAtmosphere(dt, energy) {
  const t = 1 - Math.exp(-dt * 1.5);
  for (const k in cur) cur[k].lerp(target[k], t);
  const night = clamp(1 - energy * 1.4, 0, 1);
  const dim = 1 - night * 0.55;
  skyMat.uniforms.top.value.copy(cur.skyTop).multiplyScalar(dim);
  skyMat.uniforms.mid.value.copy(cur.skyMid).multiplyScalar(lerp(1, 0.5, night));
  skyMat.uniforms.bot.value.copy(cur.skyBot).multiplyScalar(dim);
  skyMat.uniforms.sunCol.value.copy(cur.sun).lerp(_tmpC.setHex(0xff3a1a), night * 0.6);
  skyMat.uniforms.night.value = night;
  scene.fog.color.copy(cur.fog).multiplyScalar(lerp(1, 0.55, night));
  groundMat.color.copy(cur.ground);
  groundMat.emissive.copy(cur.grid);
  mountains.material.color.copy(cur.mount).multiplyScalar(lerp(1, 0.6, night));
  hemi.color.copy(cur.hemiS); hemi.groundColor.copy(cur.hemiG);
  hemi.intensity = lerp(0.7, 0.35, night);
  sunLight.color.copy(skyMat.uniforms.sunCol.value);
  sunLight.intensity = lerp(2.6, 1.3, night);
}

function setSunElevation(energy, px, pz) {
  const e = lerp(0.07, 0.42, clamp(energy, 0, 1));
  sunDir.set(Math.sin(0.28) * Math.cos(e), Math.sin(e), -Math.cos(0.28) * Math.cos(e)).normalize();
  const cx = px, cz = pz - 70;
  sunLight.target.position.set(cx, 0, cz);
  sunLight.position.set(cx + sunDir.x * 300, sunDir.y * 300, cz + sunDir.z * 300);
}

// ray from point toward the sun, does it hit any box?
function rayBox(ox, oy, oz, dx, dy, dz, b) {
  let tmin = 0, tmax = 400, t1, t2, t;
  t1 = (b.minx - ox) / dx; t2 = (b.maxx - ox) / dx; if (t1 > t2) { t = t1; t1 = t2; t2 = t; }
  tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2); if (tmin > tmax) return false;
  t1 = (b.miny - oy) / dy; t2 = (b.maxy - oy) / dy; if (t1 > t2) { t = t1; t1 = t2; t2 = t; }
  tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2); if (tmin > tmax) return false;
  t1 = (b.minz - oz) / dz; t2 = (b.maxz - oz) / dz; if (t1 > t2) { t = t1; t1 = t2; t2 = t; }
  tmin = Math.max(tmin, t1); tmax = Math.min(tmax, t2);
  return tmin <= tmax;
}
function computeShadow(x, y, z) {
  for (const c of chunks) {
    if (c.z1 > z + 2 || c.z0 < z - 420) continue;
    for (const b of c.boxes) {
      if (b.dead || b.maxz > z + 2) continue;
      if (rayBox(x, y + 0.3, z, sunDir.x, sunDir.y, sunDir.z, b)) return true;
    }
  }
  return false;
}

// =====================================================================
// Input
// =====================================================================
const keys = {};
const holds = new Map(); // pointerId -> -1 | 1 (hold left / right half of screen)
addEventListener('keydown', e => {
  if (e.repeat) { keys[e.code] = true; return; }
  keys[e.code] = true;
  const k = e.code;
  if ($('settings').classList.contains('show')) { if (k === 'Escape' || k === 'Enter') openSettings(false); return; }
  if (G.mode === 'run' && !run.auto) {
    if (k === 'Space' || k === 'KeyW' || k === 'ArrowUp') { doJump(); e.preventDefault(); }
    if (k === 'ShiftLeft' || k === 'ShiftRight' || k === 'KeyS' || k === 'ArrowDown') doDash();
    if (k === 'KeyQ') doDash(-1);
    if (k === 'KeyE') doDash(1);
    if (k === 'KeyP' || k === 'Escape') setPause(true);
    const ab = ABILITIES.find(a => !a.auto && 'Digit' + a.key === k);
    if (ab) useAbility(ab.id);
  } else if (G.mode === 'paused') {
    if (k === 'KeyP' || k === 'Escape' || k === 'Enter') setPause(false);
  } else if (G.mode === 'gameover') {
    if (k === 'Enter' || k === 'Space' || k === 'KeyR') startRun();
    if (k === 'KeyH') showHangar();
  } else if (G.mode === 'title') {
    if (k === 'Enter') showHangar();
    if (k === 'Space') startRun();
  } else if (G.mode === 'hangar') {
    if (k === 'ArrowLeft' || k === 'KeyA') selectShip((G.shipIdx + SHIPS.length - 1) % SHIPS.length);
    if (k === 'ArrowRight' || k === 'KeyD') selectShip((G.shipIdx + 1) % SHIPS.length);
    if (k === 'Enter' || k === 'Space') { e.preventDefault(); tryLaunch(); }
    if (k === 'Escape') showTitle();
  }
  if (k === 'KeyM') toggleMute();
  if (k === 'Backquote') { G.debug = !G.debug; $('debug').style.display = G.debug ? '' : 'none'; }
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(k)) e.preventDefault();
});
addEventListener('keyup', e => { keys[e.code] = false; });
// ---- stop all sound and pause whenever the game isn't in view ----
function leaveGame(reason) {
  for (const k in keys) keys[k] = false;
  if (typeof clearHolds === 'function') clearHolds();
  if (G.mode === 'run' && !run.auto) setPause(true);
  audio.holdOn(reason);
}
addEventListener('blur', () => leaveGame('blur'));
addEventListener('focus', () => audio.holdOff('blur'));
document.addEventListener('visibilitychange', () => {
  if (document.hidden) leaveGame('hidden'); else audio.holdOff('hidden');
});
addEventListener('pagehide', () => { leaveGame('hidden'); saveProgress(true); audio.shutdown(); });
document.addEventListener('freeze', () => leaveGame('hidden'));
// any tap brings sound back (e.g. after a phone call interrupted audio)
addEventListener('pointerdown', () => { audio.holdOff('blur'); if (audio.ctx) audio.tryResume(); }, true);
addEventListener('keydown', () => { audio.holdOff('blur'); }, true);

const cvs = renderer.domElement;
function holdSide(x) { return x < innerWidth / 2 ? -1 : 1; }
function refreshSteerPads() {
  let l = false, r = false;
  for (const v of holds.values()) { if (v < 0) l = true; else r = true; }
  $('t-left').classList.toggle('on', l);
  $('t-right').classList.toggle('on', r);
}
cvs.addEventListener('pointerdown', e => {
  if (G.mode !== 'run' || run.auto) return;
  holds.set(e.pointerId, holdSide(e.clientX));
  refreshSteerPads();
});
for (const id of ['t-left', 't-right']) {
  $(id).addEventListener('pointerdown', e => { e.preventDefault(); if (G.mode !== 'run') return; holds.set(e.pointerId, id === 't-left' ? -1 : 1); refreshSteerPads(); });
}
addEventListener('pointermove', e => {
  // sliding a held finger across the middle switches direction
  if (!holds.has(e.pointerId)) return;
  const side = holdSide(e.clientX);
  if (holds.get(e.pointerId) !== side) { holds.set(e.pointerId, side); refreshSteerPads(); }
});
const endPointer = e => { if (holds.delete(e.pointerId)) refreshSteerPads(); };
addEventListener('pointerup', endPointer);
addEventListener('pointercancel', endPointer);
function clearHolds() { holds.clear(); refreshSteerPads(); }
$('t-jump').addEventListener('pointerdown', e => { e.stopPropagation(); e.preventDefault(); doJump(); });
$('t-dash').addEventListener('pointerdown', e => { e.stopPropagation(); e.preventDefault(); doDash(); });
$('abil-bar').addEventListener('pointerdown', e => {
  const b = e.target.closest('[data-abil]');
  if (!b) return;
  e.stopPropagation(); e.preventDefault();
  useAbility(b.dataset.abil);
});

function steerInput() {
  let s = 0;
  if (keys.KeyA || keys.ArrowLeft) s -= 1;
  if (keys.KeyD || keys.ArrowRight) s += 1;
  if (holds.size) { let h = 0; for (const v of holds.values()) h += v; s = clamp(h, -1, 1); }
  // gamepad
  const gp = navigator.getGamepads ? navigator.getGamepads()[0] : null;
  if (gp) {
    if (Math.abs(gp.axes[0]) > 0.15) s = gp.axes[0];
    if (gp.buttons[0]?.pressed && !run._gpA) doJump();
    if ((gp.buttons[2]?.pressed || gp.buttons[1]?.pressed) && !run._gpX) doDash();
    run._gpA = gp.buttons[0]?.pressed; run._gpX = gp.buttons[2]?.pressed || gp.buttons[1]?.pressed;
  }
  return s;
}

function doJump(force = false) {
  if (G.mode !== 'run' && !(run.auto && force)) return;
  if (!force && run.jumps <= 0) { audio.deny(); return; }
  if (!force) run.jumps--;
  const def = SHIPS[G.shipIdx];
  run.vy = def.jumpPower;
  if (!run.auto) audio.jump();
  emit(run.x, run.y - 0.5, run.z + 1, 40, 0x5bff9a, 14, 0.6, { flat: true });
  run.fovKick = Math.max(run.fovKick, 4);
}

function doDash(dir) {
  if (G.mode !== 'run' || run.dashCd > 0) return;
  const d = dir ?? (Math.sign(run.steer) || Math.sign(run.vx) || 1);
  run.dashV = d * 75;
  run.dashT = 0.35;
  run.dashCd = SHIPS[G.shipIdx].dashCd;
  run.rollSpin = d * Math.PI * 2;
  audio.dash();
  emit(run.x, run.y, run.z + 1, 30, SHIPS[G.shipIdx].accent, 8, 0.5);
}

// =====================================================================
// Autopilot (title attract mode)
// =====================================================================
function autopilot() {
  let bestX = run.x, bestScore = -1e9;
  for (let x = -W + 3; x <= W - 3; x += 2.5) {
    let clear = 140;
    for (const c of chunks) {
      if (c.z0 < run.z - 140 || c.z1 > run.z) continue;
      for (const b of c.boxes) {
        if (b.dead || b.maxz > run.z || b.miny > run.y + 1 || b.maxy < run.y - 1) continue;
        if (x + 2.5 > b.minx && x - 2.5 < b.maxx) { const dz = run.z - b.maxz; if (dz < clear) clear = dz; }
      }
    }
    const sc = Math.min(clear, 90) - Math.abs(x - run.x) * 0.35;
    if (sc > bestScore) { bestScore = sc; bestX = x; }
  }
  return clamp((bestX - run.x) / 6, -1, 1);
}

// =====================================================================
// Game logic
// =====================================================================
const popupsEl = $('popups');
function popup(text, color = '#fff', size = 22) {
  if (run.auto) return;
  const el = document.createElement('div');
  el.className = 'pop';
  el.textContent = text;
  el.style.color = color;
  el.style.fontSize = size + 'px';
  el.style.marginLeft = rand(-80, 80) + 'px';
  popupsEl.appendChild(el);
  setTimeout(() => el.remove(), 1100);
}
let bannerTimer = null;
function banner(small, big) {
  $('banner-small').textContent = small;
  $('banner-big').textContent = big;
  $('banner').classList.add('on');
  clearTimeout(bannerTimer);
  bannerTimer = setTimeout(() => $('banner').classList.remove('on'), 2600);
}

function collect(p) {
  p.taken = true;
  p.obj.visible = false;
  const def = SHIPS[G.shipIdx];
  if (p.type === 'sun') {
    const amt = 0.085 * (def.sunBonus || 1);
    run.energy = Math.min(1, run.energy + amt);
    emit(p.x, p.y, p.z, 30, 0xffb040, 9, 0.7);
    audio.sun();
    popup('+SOLAR', '#ffd27a');
    run.score += 50 * run.mult;
  } else if (p.type === 'prism') {
    run.mult = Math.min(30, run.mult + 1);
    run.peakMult = Math.max(run.peakMult, run.mult);
    run.prisms++;
    emit(p.x, p.y, p.z, 14, 0x4ff0ff, 7, 0.5);
    audio.prism(run.mult);
    const m = $('h-mult'); m.classList.add('bump'); setTimeout(() => m.classList.remove('bump'), 120);
  } else {
    const P = POWERS[p.type];
    emit(p.x, p.y, p.z, 50, P.hex, 14, 0.9);
    audio.power();
    run.flash = 0.25;
    if (p.type === 'jump') { run.jumps = Math.min(run.jumps + 2, 9); popup('+2 JUMPS', P.color, 26); }
    else {
      let dur = P.dur;
      if (p.type === 'phase' && def.phaseMult) dur *= def.phaseMult;
      if (p.type === 'overdrive' && def.overMult) dur *= def.overMult;
      if (p.type === 'shield') dur += G.upg.shield * 4;
      run.powers[p.type] = dur;
      popup(P.label, P.color, 30);
    }
  }
}

function smash(c, b) {
  b.dead = true;
  if (c.mesh && b.idx >= 0) { c.mesh.setMatrixAt(b.idx, _m4.makeScale(0, 0, 0)); c.mesh.instanceMatrix.needsUpdate = true; }
  for (const m of c.movers) if (m.box === b) m.mesh.visible = false;
  const cx = clamp(run.x, b.minx, b.maxx), cy = clamp(run.y, b.miny, b.maxy);
  emitDebris(cx, cy, b.maxz, 18, 30, 1.3, BIOMES[c.bi].obs[0]);
  emit(cx, cy, b.maxz, 60, BIOMES[c.bi].edge, 22, 0.8);
  audio.smash();
  run.shake = Math.max(run.shake, 0.6);
  run.smashed++;
  run.score += 250 * run.mult;
  popup('SMASH +' + (250 * run.mult), '#ff8a3a', 26);
}

function crash(reason) {
  if (run.auto) { resetRun(true); return; }
  G.mode = 'crashing';
  run.reason = reason;
  run.crashT = 0;
  audio.crash();
  audio.setEngine(0, 0);
  emitDebris(run.x, run.y, run.z, 60, 34, 1.4, SHIPS[G.shipIdx].hull);
  emit(run.x, run.y, run.z, 200, 0xffa040, 30, 1.4, { bright: 3 });
  emit(run.x, run.y, run.z, 80, SHIPS[G.shipIdx].accent, 18, 1.2);
  playerRoot.visible = false;
  run.shake = 1.6;
  run.flash = 0.8;
  G.timeScale = 0.3;
}

function hasPower(k) { return (run.powers[k] || 0) > 0; }

// =====================================================================
// Supernatural abilities
// =====================================================================
function abilCount(id) { return (G.abil[id] || 0) + (run.free ? run.free[id] || 0 : 0); }
function consumeAbil(id) {
  if (run.free && run.free[id] > 0) run.free[id]--;
  else { G.abil[id]--; saveProgress(); }
  run.abilUsed++;
}
function useAbility(id) {
  if (G.mode !== 'run' || run.auto) return;
  const A = ABILITIES.find(a => a.id === id);
  if (!A || A.auto) return;
  if (abilCount(id) <= 0) { audio.deny(); popup('NO ' + A.name + ' LEFT — BUY IN HANGAR', '#a39cab', 16); return; }
  consumeAbil(id);
  const R = run;
  run.flash = 0.6;
  if (id === 'nova') {
    audio.nova();
    novaBlast();
    banner('SUPERNATURAL', 'SOLAR NOVA');
  } else if (id === 'warp') {
    audio.warp();
    R.warpT = 0;
    R.invuln = 2.5;
    R.powers.phase = Math.max(R.powers.phase || 0, 2.5);
    banner('SUPERNATURAL', 'HYPER WARP');
  } else if (id === 'sunheart') {
    audio.sunheart();
    R.energy = 1; R.noDrain = 12;
    emit(R.x, R.y, R.z, 120, 0xffe066, 18, 1.0);
    banner('SUPERNATURAL', 'SUN HEART');
  } else if (id === 'ghost') {
    audio.ghost();
    R.powers.phase = Math.max(R.powers.phase || 0, 12);
    banner('SUPERNATURAL', 'GHOST FORM');
  }
  lastAbilKey = '';
}
function tryRebirth() {
  if (run.auto || abilCount('rebirth') <= 0) return false;
  consumeAbil('rebirth');
  const R = run;
  R.energy = 1; R.invuln = 3; R.powers.phase = Math.max(R.powers.phase || 0, 3);
  R.flash = 1; R.shake = 1;
  audio.rebirth();
  emit(R.x, R.y, R.z, 220, 0xff5a3a, 26, 1.4, { bright: 3 });
  emit(R.x, R.y, R.z, 120, 0xffd27a, 14, 1.6);
  banner('PHOENIX', 'REBIRTH');
  lastAbilKey = '';
  return true;
}
// 10 km solar nova: every building in range explodes (10 km = 600 world units here, beyond the horizon)
const NOVA_R = 600;
const novaMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffb030).multiplyScalar(2.4), transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false });
const novaSphere = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24), novaMat);
const novaRing = new THREE.Mesh(new THREE.RingGeometry(0.92, 1, 96).rotateX(-Math.PI / 2), novaMat);
novaSphere.visible = novaRing.visible = false;
scene.add(novaSphere, novaRing);
function novaBlast() {
  const R = run;
  R.novaT = 0; R.novaX = R.x; R.novaZ = R.z; R.novaHit = 0;
  R.shake = 1.4;
  emit(R.x, R.y, R.z, 260, 0xffb030, 40, 1.4, { bright: 3 });
}
function updateNova(dt) {
  const R = run;
  if (R.novaT < 0) { novaSphere.visible = novaRing.visible = false; return; }
  R.novaT += dt;
  const t = R.novaT / 1.6;
  const rad = Math.pow(Math.min(t, 1), 0.6) * NOVA_R;
  novaSphere.visible = novaRing.visible = true;
  novaSphere.position.set(R.novaX, 0, R.novaZ); novaSphere.scale.setScalar(Math.max(1, rad));
  novaRing.position.set(R.novaX, 0.4, R.novaZ); novaRing.scale.setScalar(Math.max(1, rad));
  novaMat.opacity = 0.55 * (1 - Math.min(t, 1));
  // destroy everything the shockwave front has reached
  let debrisBudget = 6;
  for (const c of chunks) {
    for (const b of c.boxes) {
      if (b.dead) continue;
      const cx = (b.minx + b.maxx) / 2, cz = (b.minz + b.maxz) / 2;
      const d = Math.hypot(cx - R.novaX, cz - R.novaZ);
      if (d < rad) {
        b.dead = true;
        if (c.mesh && b.idx >= 0) { c.mesh.setMatrixAt(b.idx, _m4.makeScale(0, 0, 0)); c.mesh.instanceMatrix.needsUpdate = true; }
        for (const m of c.movers) if (m.box === b) m.mesh.visible = false;
        R.novaHit++;
        if (d < 260 && debrisBudget-- > 0) {
          emitDebris(cx, (b.miny + b.maxy) / 2, cz, 10, 26, 1.6, BIOMES[c.bi].obs[0]);
          emit(cx, (b.miny + b.maxy) / 2, cz, 30, 0xffb030, 22, 0.9);
        }
      }
    }
  }
  if (t >= 1) {
    R.novaT = -1;
    if (R.novaHit) { R.score += R.novaHit * 50 * R.mult; popup('VAPORISED ' + R.novaHit + ' +' + (R.novaHit * 50 * R.mult).toLocaleString(), '#ffb030', 26); }
  }
}
function updateWarp(dt) {
  const R = run;
  if (R.warpT < 0) return;
  const before = R.warpT;
  R.warpT += dt;
  // accelerate through 1500 units over ~1.1s
  const total = 1500, dur = 1.1;
  const f = k => k <= 0 ? 0 : k >= 1 ? 1 : (1 - Math.cos(k * Math.PI)) / 2;
  const dz = (f(R.warpT / dur) - f(before / dur)) * total;
  R.z -= dz;
  R.score += dz * R.mult * 0.5;
  R.fovKick = Math.max(R.fovKick, 30 * Math.sin(Math.min(1, R.warpT / dur) * Math.PI));
  if (R.warpT >= dur) { R.warpT = -1; R.invuln = Math.max(R.invuln, 1.5); }
}

function update(dt) {
  G.time += dt;
  const def = SHIPS[G.shipIdx];
  if (G.mode === 'run' || G.mode === 'title' && run.auto) updateFlight(dt, def);
  else if (G.mode === 'crashing') {
    run.crashT += dt / Math.max(G.timeScale, 0.01);
    G.timeScale = lerp(G.timeScale, 1, dt * 0.5);
    if (run.crashT > 1.8) endRun();
  } else if (G.mode === 'sunset') {
    run.crashT += dt;
    run.speed = Math.max(0, run.speed - 60 * dt);
    run.z -= run.speed * dt;
    run.vy -= 8 * dt;
    run.y = Math.max(0.6, run.y + run.vy * dt);
    playerRoot.position.set(run.x, run.y, run.z);
    playerTilt.rotation.z = lerp(playerTilt.rotation.z, 0.4, dt);
    playerTilt.rotation.x = lerp(playerTilt.rotation.x, -0.15, dt);
    if (run.crashT > 2.6) endRun();
  }
  updateParticles(dt);
  updateDebris(dt);
  // movers anim (always)
  for (const c of chunks) for (const m of c.movers) if (!m.box.dead) updateMover(m, G.time);
}

function updateFlight(dt, def) {
  const R = run;
  R.time += dt;
  // ---- powers tick
  for (const k in R.powers) { R.powers[k] -= dt; if (R.powers[k] <= 0) { delete R.powers[k]; if (!R.auto) popup(POWERS[k].label + ' OFFLINE', '#a39cab', 16); } }
  const over = hasPower('overdrive'), phase = hasPower('phase'), slow = hasPower('slowmo');
  G.timeScale = slow ? 0.6 : 1;
  updateNova(dt);
  updateWarp(dt);

  // ---- speed
  const dist = -R.z;
  const targetSpeed = (def.speed + Math.min(75, dist * 0.0045)) * (over ? 1.65 : 1);
  R.speed = lerp(R.speed, targetSpeed, 1 - Math.exp(-dt * (over ? 3 : 1.2)));
  R.z -= R.speed * dt;

  // ---- steering
  const steer = R.auto ? autopilot() : steerInput();
  R.steer = steer;
  const handling = def.handling * (1 + Math.min(0.5, dist / 20000));
  R.vx = lerp(R.vx, steer * handling, 1 - Math.exp(-dt * 7));
  R.dashV *= Math.exp(-dt * 7);
  R.dashT -= dt; R.dashCd = Math.max(0, R.dashCd - dt);
  R.x += (R.vx + R.dashV) * dt;
  if (R.x < -W) { R.x = -W; R.vx = Math.max(0, R.vx); R.dashV = 0; }
  if (R.x > W) { R.x = W; R.vx = Math.min(0, R.vx); R.dashV = 0; }

  // ---- vertical
  R.vy -= GRAV * dt;
  R.y += R.vy * dt;
  if (R.y <= BASE_Y) { if (R.vy < -12 && !R.auto) emit(R.x, 0.3, R.z, 20, 0xffffff, 8, 0.4, { flat: true }); R.y = BASE_Y; R.vy = 0; }

  // ---- jump pads
  for (const c of chunks) {
    if (c.z1 > R.z + 5 || c.z0 < R.z - 5) continue;
    for (const p of c.pads) {
      if (R.y < BASE_Y + 0.6 && R.x > p.minx && R.x < p.maxx && R.z > p.minz && R.z < p.maxz) { doJump(true); R.vy = Math.max(R.vy, 19); }
    }
  }

  // ---- chunks stream
  while (nextChunkZ > R.z - VIEW) generateChunk();
  while (chunks.length && chunks[0].z1 > R.z + 60) disposeChunk(chunks.shift());

  // ---- region change
  const reg = regionAt(dist);
  if (reg !== R.region) {
    R.region = reg;
    applyBiome(reg % BIOMES.length, false);
    if (!R.auto) {
      banner('ZONE ' + (reg + 1), BIOMES[reg % BIOMES.length].name);
      pickMusic();
      audio.portal();
      R.flash = 0.5;
      R.energy = Math.min(1, R.energy + 0.25);
      R.score += 1000 * R.mult;
      popup('ZONE CLEAR +SOLAR', '#ffd27a', 26);
    }
  }

  // ---- collisions
  const px0 = R.x - PHB.x, px1 = R.x + PHB.x, py0 = R.y - PHB.y, py1 = R.y + PHB.y, pz0 = R.z - PHB.z, pz1 = R.z + PHB.z;
  const NM = 1.6;
  for (const c of chunks) {
    if (c.z1 > pz1 + 2 || c.z0 < pz0 - 2) continue;
    for (const b of c.boxes) {
      if (b.dead || !b.solid) continue;
      if (b.maxz < pz0 - 0.5 || b.minz > pz1 + 0.5) continue;
      const hit = px1 > b.minx && px0 < b.maxx && py1 > b.miny && py0 < b.maxy && pz1 > b.minz && pz0 < b.maxz;
      if (hit) {
        if (over) { smash(c, b); continue; }
        if (phase || R.invuln > 0) continue;
        if (def.dashSmash && R.dashT > 0) { smash(c, b); continue; }
        if (hasPower('shield')) {
          R.shieldHits--;
          R.invuln = 0.8;
          audio.shieldHit();
          smash(c, b);
          if (R.shieldHits <= 0) { delete R.powers.shield; R.shieldHits = def.shieldHits || 1; popup('SHIELD BROKEN', '#4db8ff', 24); }
          else popup('SHIELD HOLDING', '#4db8ff', 22);
          continue;
        }
        if (tryRebirth()) continue;
        crash('HULL BREACH');
        return;
      } else if (!b.nm && !phase && !over && py1 > b.miny && py0 < b.maxy && pz1 > b.minz && pz0 < b.maxz &&
        px1 + NM > b.minx && px0 - NM < b.maxx) {
        b.nm = true;
        R.nearMiss++;
        R.energy = Math.min(1, R.energy + 0.015 * (def.nearBonus || 1));
        R.score += 100 * R.mult;
        R.shake = Math.max(R.shake, 0.25);
        R.fovKick = Math.max(R.fovKick, 3);
        if (!R.auto) { audio.near(); popup('NEAR MISS +' + 100 * R.mult, '#4ff0ff', 20); }
        emit(R.x + (R.x < b.minx ? PHB.x : -PHB.x), R.y, R.z, 16, 0x4ff0ff, 10, 0.4);
      }
    }
  }
  R.invuln = Math.max(0, R.invuln - dt);

  // ---- pickups
  const magR = (hasPower('magnet') ? 18 : 0) + (def.magnetBase || 0) + G.upg.magnet * 1.5;
  for (const c of chunks) {
    if (c.z1 > R.z + 6 || c.z0 < R.z - 60) continue;
    for (const p of c.pickups) {
      if (p.taken) continue;
      const dx = p.x - R.x, dy = p.y - R.y, dz = p.z - R.z;
      const d2 = dx * dx + dy * dy + dz * dz;
      if (magR > 0 && d2 < (magR + 2) * (magR + 2) && p.z < R.z + 2) {
        const k = 1 - Math.exp(-dt * 10);
        p.x -= dx * k; p.y -= dy * k; p.z -= dz * k * 0.5;
        p.obj.position.set(p.x, p.y, p.z);
      }
      if (d2 < 2.4 * 2.4 + (hasPower('magnet') ? 4 : 0)) collect(p);
    }
  }

  // ---- energy & shadow
  R.inShadow = computeShadow(R.x, R.y, R.z);
  if (!R.auto) {
    const eff = def.solar * (1 - G.upg.solar * 0.08);
    let drain = 0.02 * eff + (R.inShadow && !def.shadowImmune ? 0.1 * eff : 0);
    if (over) drain *= 0.3;
    if (R.noDrain > 0) { R.noDrain -= dt; drain = 0; }
    R.energy -= drain * dt;
    if (R.inShadow && !def.shadowImmune) { R.shadowT += dt; R.warnT -= dt; if (R.warnT <= 0) { audio.warn(); R.warnT = 0.4; } } else R.shadowT = 0;
    if (R.energy <= 0 && tryRebirth()) R.energy = 1;
    if (R.energy <= 0) {
      R.energy = 0;
      G.mode = 'sunset';
      R.reason = 'THE SUN HAS SET';
      R.crashT = 0;
      audio.sunset();
      audio.setEngine(0, 0);
      return;
    }
    R.score += R.speed * dt * R.mult;
  } else R.energy = 0.75 + Math.sin(G.time * 0.2) * 0.2;

  // ---- ship pose
  const targetRoll = -(R.vx + R.dashV * 0.3) / def.handling * 0.42;
  R.roll = lerp(R.roll, targetRoll, 1 - Math.exp(-dt * 8));
  if (R.rollSpin !== 0) {
    const step = Math.sign(R.rollSpin) * Math.min(Math.abs(R.rollSpin), dt * 20);
    R.rollSpin -= step;
    R.rollAcc = (R.rollAcc || 0) + step;
  } else R.rollAcc = 0;
  R.pitch = lerp(R.pitch, clamp(R.vy * 0.025, -0.35, 0.45), 1 - Math.exp(-dt * 6));
  playerRoot.position.set(R.x, R.y + Math.sin(G.time * 3) * 0.06, R.z);
  playerTilt.rotation.set(R.pitch, -R.vx / def.handling * 0.12, R.roll - (R.rollAcc || 0), 'YXZ');
}

// =====================================================================
// Visual update each frame (camera, ship fx, hud)
// =====================================================================
const camPos = new THREE.Vector3(0, 5, 10);
const camLook = new THREE.Vector3();
const _wp = new THREE.Vector3();
function updateVisuals(dt, rdt) {
  const R = run;
  const def = SHIPS[G.shipIdx];
  const flying = G.mode === 'run' || G.mode === 'title' || G.mode === 'paused';
  // atmosphere & sun
  setSunElevation(R.energy, R.x, R.z);
  updateAtmosphere(rdt, R.energy);
  skyMat.uniforms.time.value = G.time;
  ground.position.set(Math.round(R.x / 10) * 10, 0, Math.round(R.z / 10) * 10);
  mountains.position.set(R.x, 0, R.z);
  {
    // find an ocean zone overlapping the view
    const dist = -R.z; let found = -1;
    for (const r of [regionAt(dist), regionAt(dist) + 1, regionAt(dist) - 1]) if (r >= 0 && BIOMES[r % BIOMES.length].ocean) { found = r; break; }
    if (found >= 0) {
      const z0 = found * REGION_LEN, z1 = z0 + REGION_LEN;
      water.visible = dist > z0 - VIEW - 200 && dist < z1 + 200;
      water.position.set(R.x, 0.15, -(z0 + z1) / 2);
      waterNormals.offset.set(G.time * 0.01, -G.time * 0.03);
      run.overWater = dist > z0 && dist < z1;
    } else { water.visible = false; run.overWater = false; }
    for (const c of chunks) if (c.buoys) for (const b of c.buoys) b.position.y = 0.3 + Math.sin(G.time * 1.6 + b.userData.ph) * 0.25;
    if (run.overWater && G.mode === 'run' && R.y < BASE_Y + 1.2 && Math.random() < 0.5) {
      const side = Math.random() < 0.5 ? -1 : 1;
      emit(R.x + side * rand(1.5, 2.6), 0.3, R.z + 0.5, 1, 0x6fcfff, 3, 0.35, { vz: R.speed * 0.2, vy: 2.5, grav: 10, bright: 0.8, vx: side * 3 });
    }
  }

  // camera
  const sp = clamp((R.speed - 70) / 110, 0, 1);
  const pb = camera.aspect < 1 ? (1 - camera.aspect) * 5 : 0;
  const tgt = _wp.set(R.x * 0.85, R.y + 3.0 + sp * 0.4 + pb * 0.4, R.z + 9.5 + pb - sp * 1.2);
  if (G.mode === 'crashing' || G.mode === 'sunset') {
    tgt.set(R.x + 6, R.y + 6, R.z + 16);
  }
  const cz = camPos.z;
  camPos.lerp(tgt, 1 - Math.exp(-rdt * (G.mode === 'crashing' || G.mode === 'sunset' ? 1.5 : 7)));
  if (G.mode !== 'crashing' && G.mode !== 'sunset') camPos.z = tgt.z; void cz;
  camera.position.copy(camPos);
  R.shake = Math.max(0, (R.shake || 0) - rdt * 2.2);
  if (R.shake > 0) camera.position.add(_v.set(rand(-1, 1), rand(-1, 1), 0).multiplyScalar(R.shake * 0.5));
  camLook.set(R.x * 0.92, R.y + 0.6, R.z - 22);
  camera.lookAt(camLook);
  camera.rotation.z += -R.roll * 0.12;
  R.fovKick = Math.max(0, (R.fovKick || 0) - rdt * 6);
  const over = hasPower('overdrive');
  const portrait = camera.aspect < 1 ? (1 - camera.aspect) * 30 : 0;
  camera.fov = lerp(camera.fov, 68 + portrait + sp * 14 + R.fovKick + (over ? 12 : 0), 1 - Math.exp(-rdt * 4));
  camera.updateProjectionMatrix();
  sky.position.copy(camera.position);

  // ship fx
  if (shipModel && playerRoot.visible) {
    animateShip(shipModel, G.time, rdt);
    const fl = 1 + sp * 0.8 + (over ? 1.4 : 0) + Math.sin(G.time * 50) * 0.12;
    for (const f of shipModel.userData.flames) f.scale.set(1, 1, fl);
    for (const s of engineSprites) s.scale.setScalar(1.2 + sp * 0.6 + (over ? 1.4 : 0) + Math.random() * 0.2);
    const ph = hasPower('phase');
    for (const m of shipModel.userData.allMats) {
      const want = ph || R.invuln > 0;
      if (m.transparent !== want) { m.transparent = want; m.needsUpdate = true; }
      m.opacity = want ? 0.22 + Math.sin(G.time * 30) * 0.1 : 1;
    }
    playerRoot.updateMatrixWorld(true);
    for (const t of trails) {
      _wp.copy(t.local).applyMatrix4(shipModel.matrixWorld);
      t.push(_wp, t.engine ? (0.8 + sp + (over ? 1.5 : 0)) : (0.5 + Math.abs(R.vx) / def.handling * 0.9 + (ph ? 1 : 0)));
    }
    shieldMesh.visible = hasPower('shield');
    shieldMat.uniforms.time.value = G.time;
    shieldMat.uniforms.amt.value = (R.powers.shield || 0) < 2 ? (Math.sin(G.time * 20) > 0 ? 1 : 0.3) : 1;
    aura.visible = over;
    if (over) { aura.scale.set(1, 1, 1 + Math.sin(G.time * 40) * 0.1); if (!R.auto) emit(R.x + rand(-2, 2), R.y + rand(-0.5, 0.5), R.z - 3, 3, 0xff5a2a, 4, 0.4, { vz: R.speed * 0.6 }); }
  } else {
    shieldMesh.visible = false; aura.visible = false;
  }

  // pickups anim
  for (const c of chunks) {
    for (const p of c.pickups) {
      if (p.taken) continue;
      p.obj.rotation.y += rdt * 2.4;
      if (p.type === 'prism') p.obj.position.y = p.y + Math.sin(G.time * 3 + p.phase) * 0.25;
      else if (p.type !== 'sun') { p.obj.children[1].rotation.x += rdt * 3; p.obj.position.y = p.y + Math.sin(G.time * 2 + p.phase) * 0.35; }
    }
    if (c.portal) { c.portal.ring.rotation.z += rdt * 0.5; c.portal.ring2.rotation.z -= rdt * 0.3; }
  }

  // speed lines
  const slSpeed = (G.mode === 'run' || G.mode === 'title') ? R.speed : 0;
  slMat.opacity = lerp(slMat.opacity, flying ? 0.08 + sp * 0.35 + (over ? 0.4 : 0) : 0, rdt * 4);
  const len = 2 + sp * 10 + (over ? 10 : 0);
  for (let i = 0; i < SL; i++) {
    const d = slData[i];
    d.z += slSpeed * 1.3 * dt;
    if (d.z > 8) resetSpeedLine(d);
    const o = i * 6;
    slPos[o] = camera.position.x + d.x; slPos[o + 1] = camera.position.y + d.y - 3; slPos[o + 2] = camera.position.z + d.z;
    slPos[o + 3] = slPos[o]; slPos[o + 4] = slPos[o + 1]; slPos[o + 5] = slPos[o + 2] - len;
  }
  slGeo.attributes.position.needsUpdate = true;

  // post fx
  fxPass.uniforms.time.value = G.time % 100;
  const shadowAmt = R.inShadow && !R.auto && G.mode === 'run' ? 0.5 : 0;
  fxPass.uniforms.tintAmt.value = lerp(fxPass.uniforms.tintAmt.value, shadowAmt + (R.energy < 0.2 && !R.auto ? 0.25 : 0), rdt * 6);
  fxPass.uniforms.tint.value.setHex(R.energy < 0.2 && !R.inShadow ? 0x400810 : 0x081040);
  fxPass.uniforms.aberr.value = lerp(fxPass.uniforms.aberr.value, 0.002 + sp * 0.004 + (over ? 0.012 : 0) + R.shake * 0.006, rdt * 6);
  bloom.strength = 0.55 + (over ? 0.3 : 0);
  R.flash = Math.max(0, (R.flash || 0) - rdt * 2.5);
  $('flash').style.opacity = R.flash * 0.6;

  // audio
  if (G.mode === 'run') audio.setEngine(1, sp + (over ? 0.5 : 0));
}

// HUD
const hud = {
  score: $('h-score'), mult: $('h-mult'), energy: $('h-energy'), shadow: $('h-shadow'), dist: $('h-dist'), speed: $('h-speed'),
  zone: $('h-zone'), jumps: $('h-jumps'), dash: $('h-dash'), powers: $('h-powers'),
};
let lastJumps = -1, lastPowersKey = '', lastAbilKey = '';
function renderAbilBar() {
  const key = ABILITIES.map(a => abilCount(a.id)).join(',');
  if (key === lastAbilKey) return;
  lastAbilKey = key;
  $('abil-bar').innerHTML = ABILITIES.map(a => {
    const n = abilCount(a.id);
    return `<button class="abil ${n ? '' : 'empty'} ${a.auto ? 'passive' : ''}" data-abil="${a.id}" style="--c:${a.color}" aria-label="${a.name}">
      <span class="ag">${a.glyph}</span><span class="an">${n}</span>${a.auto ? '' : `<kbd>${a.key}</kbd>`}</button>`;
  }).join('');
}
function updateHUD() {
  const R = run;
  hud.score.textContent = Math.floor(R.score).toLocaleString();
  hud.mult.textContent = '×' + R.mult;
  hud.energy.style.width = (R.energy * 100).toFixed(1) + '%';
  hud.energy.classList.toggle('low', R.energy < 0.2);
  hud.shadow.classList.toggle('on', R.inShadow && G.mode === 'run');
  hud.dist.textContent = Math.floor(-R.z).toLocaleString();
  hud.speed.textContent = Math.floor(R.speed * 12);
  hud.zone.textContent = BIOMES[R.region % BIOMES.length].name;
  if (R.jumps !== lastJumps) {
    lastJumps = R.jumps;
    const n = Math.max(R.jumps, 3);
    hud.jumps.innerHTML = Array.from({ length: Math.min(n, 9) }, (_, i) => `<i class="${i < R.jumps ? 'on' : ''}"></i>`).join('');
  }
  renderAbilBar();
  const cd = SHIPS[G.shipIdx].dashCd;
  hud.dash.style.width = ((1 - R.dashCd / cd) * 100) + '%';
  const keysActive = Object.keys(R.powers);
  const key = keysActive.join(',');
  if (key !== lastPowersKey) {
    lastPowersKey = key;
    hud.powers.innerHTML = keysActive.map(k => `<div class="pw" data-k="${k}" style="--c:${POWERS[k].color}"><div class="ring"><b>${POWERS[k].key}</b></div><span>${POWERS[k].label}</span></div>`).join('');
  }
  for (const el of hud.powers.children) {
    const k = el.dataset.k;
    let max = POWERS[k].dur;
    el.querySelector('.ring').style.setProperty('--p', clamp((R.powers[k] || 0) / max * 100, 0, 100));
  }
}

// =====================================================================
// Hangar scene
// =====================================================================
const hScene = new THREE.Scene();
hScene.environment = envTex;
hScene.background = new THREE.Color(0x07060c);
hScene.fog = new THREE.Fog(0x07060c, 14, 40);
const hCam = new THREE.PerspectiveCamera(40, innerWidth / innerHeight, 0.1, 200);
hScene.add(new THREE.HemisphereLight(0xffd0b0, 0x201028, 0.45));
const key = new THREE.SpotLight(0xffd8b8, 45, 40, 0.6, 0.5, 1.5);
key.position.set(5, 9, 6); key.castShadow = true; key.shadow.mapSize.set(1024, 1024);
hScene.add(key, key.target);
const rim = new THREE.SpotLight(0x4ff0ff, 35, 40, 0.7, 0.6, 1.5);
rim.position.set(-6, 4, -7);
hScene.add(rim, rim.target);
const floor = new THREE.Mesh(new THREE.CircleGeometry(30, 64).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x0c0a12, roughness: 0.25, metalness: 0.8, map: gridTex.clone() }));
floor.material.map.repeat.set(12, 12); floor.material.map.needsUpdate = true;
floor.receiveShadow = true;
hScene.add(floor);
const plat = new THREE.Mesh(new THREE.CylinderGeometry(4.2, 4.6, 0.4, 64), new THREE.MeshStandardMaterial({ color: 0x16131e, roughness: 0.3, metalness: 0.9 }));
plat.position.y = 0.2; plat.receiveShadow = true; hScene.add(plat);
const platRing = new THREE.Mesh(new THREE.TorusGeometry(4.3, 0.05, 8, 96).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff8a2a).multiplyScalar(1.6) }));
platRing.position.y = 0.42; hScene.add(platRing);
const platRing2 = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.025, 8, 96).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(0x4ff0ff).multiplyScalar(1.3) }));
platRing2.position.y = 0.42; hScene.add(platRing2);
for (let i = 0; i < 14; i++) {
  const a = (i / 14) * Math.PI * 2;
  const s = new THREE.Mesh(new THREE.BoxGeometry(0.12, 9, 0.12), new THREE.MeshBasicMaterial({ color: new THREE.Color(i % 2 ? 0xff8a2a : 0x4ff0ff).multiplyScalar(1.2) }));
  s.position.set(Math.cos(a) * 15, 4.5, Math.sin(a) * 15);
  hScene.add(s);
}
const hShipHolder = new THREE.Group();
hShipHolder.position.y = 1.6;
hScene.add(hShipHolder);
let hShip = null, hRot = 0.6, hDragging = false, hLastX = 0, hVel = 0.4;
function setHangarShip(idx) {
  if (hShip) { hShipHolder.remove(hShip); disposeShip(hShip); }
  hShip = buildShip(SHIPS[idx]);
  hShip.traverse(o => { if (o.isMesh) o.castShadow = true; });
  hShipHolder.add(hShip);
  hShipHolder.scale.setScalar(0.01);
  platRing.material.color.set(SHIPS[idx].accent).multiplyScalar(1.6);
  rim.color.set(SHIPS[idx].accent);
}
const hd = $('hg-drag');
hd.addEventListener('pointerdown', e => { if (e.target.closest('button')) return; hDragging = true; hLastX = e.clientX; hd.setPointerCapture(e.pointerId); });
hd.addEventListener('pointermove', e => { if (!hDragging) return; const dx = e.clientX - hLastX; hLastX = e.clientX; hRot += dx * 0.01; hVel = dx * 0.6; });
hd.addEventListener('pointerup', () => { hDragging = false; });
function updateHangar(dt) {
  if (!hDragging) { hVel = lerp(hVel, 0.35, dt * 1.5); hRot += hVel * dt; }
  hShipHolder.rotation.y = hRot;
  hShipHolder.position.y = 1.6 + Math.sin(G.time * 1.4) * 0.12;
  hShipHolder.rotation.z = Math.sin(G.time * 0.9) * 0.05;
  const s = hShipHolder.scale.x; hShipHolder.scale.setScalar(lerp(s, 1, 1 - Math.exp(-dt * 8)));
  if (hShip) animateShip(hShip, G.time, dt);
  platRing2.rotation.y += dt * 0.4;
  const wide = innerWidth > 1000;
  const narrow = innerWidth < 640;
  hCam.position.set(0, narrow ? 6.5 : 5.2, narrow ? 21 : 16);
  hCam.lookAt(0, wide ? 1.2 : (narrow ? 0.2 : 0.8), 0);
  hCam.fov = narrow ? 46 : 40; hCam.updateProjectionMatrix();
}

// =====================================================================
// UI: screens
// =====================================================================
const screens = ['loading', 'title', 'hangar', 'pause', 'gameover'];
function showScreen(name) {
  for (const s of screens) $(s).classList.toggle('show', s === name);
  const inRun = name === null;
  $('hud').classList.toggle('hidden', !inRun && name !== 'pause');
  $('touch').classList.toggle('hidden', !(inRun && isTouch));
  document.body.classList.toggle('touch-mode', isTouch);
  if (!inRun) clearHolds();
}

function showTitle() {
  G.mode = 'title';
  audio.intensity = 0;
  mountShip(G.shipIdx);
  resetRun(true);
  usingHangar(false);
  showScreen('title');
  pickMusic();
}

function usingHangar(on) {
  renderPass.scene = on ? hScene : scene;
  renderPass.camera = on ? hCam : camera;
  bloom.strength = on ? 0.32 : 0.55;
  bloom.threshold = on ? 0.95 : 0.92;
  fxPass.uniforms.tintAmt.value = 0;
}

function showHangar() {
  audio.init();
  audio.intensity = 0;
  audio.setEngine(0, 0);
  G.mode = 'hangar';
  usingHangar(true);
  showScreen('hangar');
  renderShipList();
  selectShip(G.shipIdx, true);
  setHgTab(hgTab);
  updateSaveBadge();
  pickMusic();
}

function statRow(label, v, txt) {
  return `<div class="stat-row"><span>${label}</span><div class="bar"><i style="width:${Math.round(clamp(v, 0.05, 1) * 100)}%"></i></div><b>${txt}</b></div>`;
}
function renderShipList() {
  $('ship-list').innerHTML = SHIPS.map((s, i) => {
    const owned = G.owned[i];
    const c = '#' + new THREE.Color(s.accent).getHexString();
    return `<button class="ship-card ${i === G.shipIdx ? 'sel' : ''} ${owned ? '' : 'locked'}" data-ship="${i}">
      <span class="ship-swatch" style="background:linear-gradient(135deg,${c},#${new THREE.Color(s.hull).getHexString()})"></span>
      <span><div class="nm">${s.name}</div><div class="sub ${owned ? '' : 'cost'}">${owned ? s.tag : '◆ ' + s.cost.toLocaleString() + ' credits'}</div></span>
    </button>`;
  }).join('');
  $('hg-credits').textContent = G.credits.toLocaleString();
}
function selectShip(i, silent) {
  if (!silent) audio.hover();
  G.shipIdx = i;
  if (G.owned[i]) saveProgress();
  const s = SHIPS[i];
  setHangarShip(i);
  $('ship-name').textContent = s.name;
  $('ship-tag').textContent = s.tag;
  $('ship-stats').innerHTML =
    statRow('SPEED', (s.speed - 60) / 50, Math.round(s.speed * 12)) +
    statRow('HANDLING', (s.handling - 20) / 32, s.handling) +
    statRow('SOLAR EFF.', (1.3 - s.solar) / 0.65, Math.round((2 - s.solar) * 50) + '%') +
    statRow('JUMPS', s.jumps / 4, s.jumps) +
    statRow('DASH', (1.6 - s.dashCd) / 1.1, s.dashCd + 's');
  $('ship-perk').textContent = s.perk;
  renderShipList();
  renderUpgrades();
  const btn = $('btn-launch');
  if (G.owned[i]) { btn.textContent = 'LAUNCH'; btn.disabled = false; }
  else { btn.textContent = `UNLOCK ◆ ${s.cost.toLocaleString()}`; btn.disabled = G.credits < s.cost; }
}
let hgTab = 'upgrades';
function renderAbilShop() {
  $('abil-shop').innerHTML = ABILITIES.map(a => {
    const n = G.abil[a.id] || 0;
    return `<div class="upg abil-row" style="--c:${a.color}"><div class="un"><span class="aglyph">${a.glyph}</span>${a.name} <span class="own">×${n}</span></div><div class="ud">${a.desc}</div>
      <div class="pips">${a.auto ? '<em>Passive · triggers automatically</em>' : `<em>Key ${a.key} or tap in flight · one use</em>`}</div>
      <button class="btn small" data-buyabil="${a.id}" ${G.credits < a.cost ? 'disabled' : ''}>◆ ${a.cost}</button></div>`;
  }).join('');
}
function setHgTab(t) {
  hgTab = t;
  for (const b of document.querySelectorAll('[data-tab]')) b.classList.toggle('on', b.dataset.tab === t);
  $('upgrades').classList.toggle('hidden', t !== 'upgrades');
  $('abil-shop').classList.toggle('hidden', t !== 'abilities');
}
function renderUpgrades() {
  renderAbilShop();
  $('upgrades').innerHTML = UPGRADES.map(u => {
    const l = G.upg[u.id];
    const maxed = l >= u.max;
    const cost = u.cost(l);
    return `<div class="upg"><div class="un">${u.name}</div><div class="ud">${u.desc}</div>
      <div class="pips">${Array.from({ length: u.max }, (_, i) => `<i class="${i < l ? 'on' : ''}"></i>`).join('')}</div>
      <button class="btn small" data-upg="${u.id}" ${maxed || G.credits < cost ? 'disabled' : ''}>${maxed ? 'MAX' : '◆ ' + cost}</button></div>`;
  }).join('');
}
function tryLaunch() {
  const i = G.shipIdx;
  if (!G.owned[i]) {
    if (G.credits >= SHIPS[i].cost) {
      G.credits -= SHIPS[i].cost; G.owned[i] = true; audio.buy(); selectShip(i, true); saveProgress(true);
      popup('UNLOCKED ' + SHIPS[i].name, '#5bff9a', 26);
    } else audio.deny();
    return;
  }
  startRun();
}

function startRun() {
  audio.init();
  audio.click();
  mountShip(G.shipIdx);
  resetRun(false);
  usingHangar(false);
  G.mode = 'run';
  G.timeScale = 1;
  audio.intensity = 1;
  lastJumps = -1; lastPowersKey = '';
  popupsEl.innerHTML = '';
  showScreen(null);
  banner('ZONE 1', BIOMES[0].name);
  pickMusic();
  clearHolds();
}

function setPause(on) {
  if (on && G.mode === 'run') { G.mode = 'paused'; showScreen('pause'); audio.setEngine(0, 0); audio.intensity = 0; }
  else if (!on && G.mode === 'paused') { G.mode = 'run'; showScreen(null); audio.intensity = 1; }
}

function toggleMute() {
  audio.setMuted(!audio.muted);
  G.settings.muted = audio.muted;
  renderSettings();
  saveProgress();
}

// ---------------- music & settings ----------------
function pickMusic() {
  const inRun = ['run', 'paused', 'crashing', 'sunset'].includes(G.mode) && !run.auto;
  let id = G.settings.track;
  if (id === 'auto') id = inRun ? BIOMES[(run.region || 0) % BIOMES.length].track : 'lounge';
  audio.setTrack(id);
}
let trackToastT = null;
audio.onTrack = name => {
  const el = $('now-playing'); if (el) el.textContent = name;
  const t = $('track-toast');
  if (t && G.mode === 'run') { t.textContent = '♪ ' + name; t.classList.add('on'); clearTimeout(trackToastT); trackToastT = setTimeout(() => t.classList.remove('on'), 2600); }
};
function renderSettings() {
  $('set-music').value = Math.round(G.settings.music * 100);
  $('set-sfx').value = Math.round(G.settings.sfx * 100);
  $('set-music-v').textContent = Math.round(G.settings.music * 100);
  $('set-sfx-v').textContent = Math.round(G.settings.sfx * 100);
  $('btn-mute2').textContent = 'SOUND: ' + (audio.muted ? 'OFF' : 'ON');
  $('now-playing').textContent = audio.track.name;
  const opts = [{ id: 'auto', name: 'AUTO · CHANGES WITH ZONE' }, ...TRACKS];
  $('track-list').innerHTML = opts.map(t => `<button class="trk ${G.settings.track === t.id ? 'on' : ''}" data-track="${t.id}">${t.name}</button>`).join('');
}
function openSettings(on) {
  $('settings').classList.toggle('show', on);
  if (on) renderSettings();
}
$('set-music').addEventListener('input', e => { G.settings.music = e.target.value / 100; audio.setMusicVolume(G.settings.music); $('set-music-v').textContent = e.target.value; saveProgress(); });
$('set-sfx').addEventListener('input', e => { G.settings.sfx = e.target.value / 100; audio.setSfxVolume(G.settings.sfx); $('set-sfx-v').textContent = e.target.value; saveProgress(); });
$('set-sfx').addEventListener('change', () => audio.prism(6));

function endRun() {
  G.mode = 'gameover';
  G.timeScale = 1;
  audio.intensity = 0;
  audio.setEngine(0, 0);
  const R = run;
  const dist = Math.floor(-R.z);
  const earned = Math.floor(R.score / 60 + R.prisms * 2 + dist / 30);
  G.credits += earned;
  const isBest = R.score > G.best;
  G.best = Math.max(G.best, R.score);
  saveProgress(true);
  pickMusic();
  $('go-reason').textContent = R.reason;
  $('go-score').textContent = Math.floor(R.score).toLocaleString();
  $('go-best').textContent = isBest ? 'NEW BEST RUN' : 'BEST ' + Math.floor(G.best).toLocaleString();
  $('go-best').classList.toggle('new', isBest);
  $('go-dist').textContent = dist.toLocaleString();
  $('go-mult').textContent = '×' + R.peakMult;
  $('go-prisms').textContent = R.prisms;
  $('go-near').textContent = R.nearMiss;
  $('go-zone').textContent = BIOMES[R.region % BIOMES.length].name;
  $('go-credits').textContent = '+' + earned.toLocaleString();
  showScreen('gameover');
}

document.addEventListener('click', e => {
  const b = e.target.closest('[data-act],[data-ship],[data-upg],[data-buyabil],[data-tab],[data-track]');
  if (!b) return;
  audio.init();
  if (b.dataset.ship !== undefined) { selectShip(+b.dataset.ship); return; }
  if (b.dataset.tab) { audio.click(); setHgTab(b.dataset.tab); return; }
  if (b.dataset.track) { audio.click(); G.settings.track = b.dataset.track; pickMusic(); renderSettings(); saveProgress(); return; }
  if (b.dataset.buyabil) {
    const a = ABILITIES.find(x => x.id === b.dataset.buyabil);
    if (G.credits >= a.cost) { G.credits -= a.cost; G.abil[a.id] = (G.abil[a.id] || 0) + 1; audio.buy(); renderShipList(); renderUpgrades(); saveProgress(true); }
    else audio.deny();
    return;
  }
  if (b.dataset.upg) {
    const u = UPGRADES.find(x => x.id === b.dataset.upg);
    const l = G.upg[u.id], cost = u.cost(l);
    if (l < u.max && G.credits >= cost) { G.credits -= cost; G.upg[u.id]++; audio.buy(); selectShip(G.shipIdx, true); saveProgress(true); }
    else audio.deny();
    return;
  }
  const a = b.dataset.act;
  audio.click();
  if (a === 'hangar') showHangar();
  else if (a === 'quick') startRun();
  else if (a === 'title') showTitle();
  else if (a === 'launch') tryLaunch();
  else if (a === 'prev') selectShip((G.shipIdx + SHIPS.length - 1) % SHIPS.length);
  else if (a === 'next') selectShip((G.shipIdx + 1) % SHIPS.length);
  else if (a === 'pause') setPause(true);
  else if (a === 'resume') setPause(false);
  else if (a === 'restart') startRun();
  else if (a === 'mute') toggleMute();
  else if (a === 'settings') openSettings(true);
  else if (a === 'close-settings') openSettings(false);
  else if (a === 'next-track') { const list = TRACKS.filter(t => !t.menuOnly || G.mode !== 'run'); const cur = list.findIndex(t => t.id === audio.track.id); G.settings.track = list[(cur + 1) % list.length].id; pickMusic(); renderSettings(); saveProgress(); }
});
document.addEventListener('mouseover', e => { if (e.target.closest && e.target.closest('.btn, .ship-card') && audio.ctx) { /* subtle */ } });

// =====================================================================
// Loop
// =====================================================================
const clock = new THREE.Clock();
let manual = false;
let fpsFrames = 0, fpsLast = performance.now(), fps = 60;
function frame(rawDt, draw = true) {
  const rdt = Math.min(rawDt, 0.05);
  const dt = rdt * G.timeScale;
  if (G.mode === 'hangar') {
    G.time += rdt;
    updateHangar(rdt);
  } else if (G.mode !== 'paused' && G.mode !== 'loading' && G.mode !== 'gameover') {
    update(dt);
    updateVisuals(dt, rdt);
  } else if (G.mode === 'gameover') {
    G.time += rdt;
    updateParticles(rdt); updateDebris(rdt);
    updateVisuals(0, rdt);
  }
  if (G.mode === 'run' || G.mode === 'crashing' || G.mode === 'sunset' || G.mode === 'paused') updateHUD();
  if (!draw) return;
  renderer.info.reset();
  composer.render(rdt);
}
function loop() {
  requestAnimationFrame(loop);
  audio.tick();
  const d = clock.getDelta();
  if (manual) return;
  frame(d);
  fpsFrames++;
  const now = performance.now();
  if (now - fpsLast > 500) {
    fps = fpsFrames * 1000 / (now - fpsLast); fpsFrames = 0; fpsLast = now;
    if (G.debug) $('debug').textContent = `FPS ${fps.toFixed(0)} · draw ${renderer.info.render.calls} · tri ${(renderer.info.render.triangles / 1000).toFixed(0)}k`;
  }
}

function onResize() {
  const w = innerWidth, h = innerHeight;
  renderer.setSize(w, h);
  composer.setSize(w, h);
  bloom.setSize(w, h);
  camera.aspect = w / h; camera.updateProjectionMatrix();
  hCam.aspect = w / h; hCam.updateProjectionMatrix();
}
addEventListener('resize', onResize);
addEventListener('orientationchange', () => { onResize(); setTimeout(onResize, 300); setTimeout(onResize, 800); });
if (window.visualViewport) visualViewport.addEventListener('resize', onResize);

// testing hooks
window.advanceTime = ms => {
  manual = true;
  const steps = Math.max(1, Math.round(ms / (1000 / 60)));
  for (let i = 0; i < steps; i++) frame(1 / 60, i === steps - 1);
};
window.resumeRealtime = () => { manual = false; clock.getDelta(); };
window.render_game_to_text = () => {
  const R = run;
  const ahead = [];
  for (const c of chunks) for (const b of c.boxes) {
    if (b.dead || !b.solid || b.maxz > R.z || b.minz < R.z - 60) continue;
    ahead.push({ x0: +b.minx.toFixed(1), x1: +b.maxx.toFixed(1), y1: +b.maxy.toFixed(1), z: +(R.z - b.maxz).toFixed(1) });
  }
  ahead.sort((a, b) => a.z - b.z);
  return JSON.stringify({
    note: 'x lateral (+right), y up, z forward is negative; obstacle z = distance ahead',
    mode: G.mode, ship: SHIPS[G.shipIdx].name, credits: G.credits,
    player: { x: +R.x.toFixed(2), y: +R.y.toFixed(2), z: +R.z.toFixed(1), speed: +R.speed.toFixed(1) },
    energy: +R.energy.toFixed(3), inShadow: R.inShadow, score: Math.floor(R.score), mult: R.mult, jumps: R.jumps,
    powers: Object.fromEntries(Object.entries(R.powers).map(([k, v]) => [k, +v.toFixed(1)])),
    region: R.region, zone: BIOMES[R.region % BIOMES.length].name, nearMiss: R.nearMiss, prisms: R.prisms,
    obstaclesAhead: ahead.slice(0, 8), chunks: chunks.length,
  });
};
window.__game = { chunks: () => chunks, audioTrack: () => audio.track.name, THREE, camera, playerRoot, get ship() { return shipModel; }, G, run, setAuto: v => { run.auto = v; }, startRun, showHangar, crash, collectPower: k => { run.powers[k] = POWERS[k].dur; } };

// =====================================================================
// Boot
// =====================================================================
async function boot() {
  try { await document.fonts.ready; } catch (e) { /* ignore */ }
  await loadProgress();
  audio.muted = !!G.settings.muted; audio.musicVol = G.settings.music; audio.sfxVol = G.settings.sfx;
  mountShip(G.shipIdx);
  resetRun(true);
  G.mode = 'title';
  // warm up shaders
  renderer.compile(scene, camera);
  setHangarShip(G.shipIdx);
  renderer.compile(hScene, hCam);
  showScreen('title');
  loop();
}
boot();
