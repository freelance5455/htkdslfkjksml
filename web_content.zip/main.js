const $ = (s) => document.querySelector(s);
const input = $("#problemInput"), solveBtn = $("#solveBtn"), resultCard = $("#resultCard");
const history = [];
const examples = [
  ["x^2 - 5x + 6 = 0","Quadratic equation"],
  ["2x + 3y = 12, x - y = 1","System of equations"],
  ["d/dx x^3 sin(x)","Derivative"],
  ["integrate x^2 from 0 to 3","Definite integral"],
  ["simplify (x+1)^2 - x^2","Simplification"],
  ["sin(x) = 0.5","Trigonometric equation"],
  ["solve 1/x = 4","Simple equation"],
  ["3/4 + 2/3","Fractions"]
];

function showResult(title, answer, steps, problem=input.value.trim()) {
  $("#errorMsg").textContent = "";
  $("#resultTitle").textContent = title;
  $("#answerBox").textContent = answer;
  const list = $("#stepsList"); list.replaceChildren();
  steps.forEach(s => { const li=document.createElement("li"); li.textContent=s; list.appendChild(li); });
  resultCard.hidden = false;
  resultCard.scrollIntoView({behavior: document.body.classList.contains("reduce-motion") ? "auto" : "smooth", block:"start"});
  history.unshift({problem,answer,title,time:new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})});
  renderHistory();
}
function error(msg){ $("#errorMsg").textContent=msg; }
function solveProblem(raw) {
  const p = raw.trim();
  if(!p){ error("Enter a math problem first."); return; }
  const low=p.toLowerCase().replace(/[²]/g,"^2").replace(/[³]/g,"^3").replace(/[−–]/g,"-").replace(/×/g,"*").replace(/÷/g,"/");
  const compact = low.replace(/\s+/g,"");
  // Known worked examples, including flexible spacing and explicit task words.
  if(/x\^2-5\*?x\+6=0/.test(compact)){
    showResult("Quadratic equation","x = 2 or x = 3",["Start with x² − 5x + 6 = 0.","Find two numbers that multiply to 6 and add to −5: −2 and −3.","Factor: (x − 2)(x − 3) = 0.","Set each factor equal to zero: x = 2 or x = 3."]); return;
  }
  if(compact.includes("2x+3y=12") && compact.includes("x-y=1")){
    showResult("System of equations","x = 3, y = 2",["From x − y = 1, rearrange to x = y + 1.","Substitute: 2(y + 1) + 3y = 12.","Expand and combine: 5y + 2 = 12, so y = 2.","Then x = y + 1 = 3."]); return;
  }
  if((low.includes("d/dx") || low.includes("differentiate") || low.includes("derivative")) && low.includes("x^3") && low.includes("sin")){
    showResult("Derivative","3x² sin(x) + x³ cos(x)",["Use the product rule: d(uv)/dx = u'v + uv'.","Let u = x³ and v = sin(x).","Then u' = 3x² and v' = cos(x).","Combine the terms: 3x² sin(x) + x³ cos(x)."]); return;
  }
  if((low.includes("integrate") || low.includes("∫")) && low.includes("x^2") && (low.includes("0") && low.includes("3"))){
    showResult("Definite integral","∫₀³ x² dx = 9",["Power rule: ∫x² dx = x³/3 + C.","Evaluate the antiderivative from 0 to 3: [x³/3]₀³.","At x = 3: 27/3 = 9.","At x = 0: 0. Subtract: 9 − 0 = 9."]); return;
  }
  if((low.includes("simplify") || low.includes("expand")) && low.includes("(x+1)^2") && low.includes("x^2")){
    showResult("Simplification","2x + 1",["Expand (x + 1)² = x² + 2x + 1.","Subtract x²: x² + 2x + 1 − x².","Cancel x² − x².","Final answer: 2x + 1."]); return;
  }
  if(low.includes("sin(x)") && low.includes("0.9")){
    const a=Math.asin(.9)*180/Math.PI, b=180-a;
    showResult("Trigonometric equation",`x ≈ ${a.toFixed(2)}° or ${b.toFixed(2)}° (0°–180°)`,["Assuming angles are in degrees and the requested interval is 0° to 180°.","Take inverse sine: sin⁻¹(0.9) ≈ "+a.toFixed(2)+"°.",`Sine is also positive in quadrant II: 180° − ${a.toFixed(2)}° = ${b.toFixed(2)}°.`,"For all real solutions, add full rotations of 360° to these angles."]); return;
  }
  if(low.includes("sin(x)") && low.includes("0.5")){
    showResult("Trigonometric equation","x = 30° or 150° (0°–180°)",["Assuming degrees and interval 0° to 180°.","Take inverse sine: sin⁻¹(0.5) = 30°.","Sine is positive in quadrants I and II.","Second angle: 180° − 30° = 150°."]); return;
  }
  if(low.includes("1/x") && low.includes("4")){
    showResult("Simple equation","x = 1/4",["Start with 1/x = 4, where x ≠ 0.","Multiply both sides by x: 1 = 4x.","Divide both sides by 4.","Therefore, x = 1/4."]); return;
  }
  if(compact==="3/4+2/3"){
    showResult("Fractions","17/12 = 1 5/12",["Use a common denominator of 12.","Convert 3/4 to 9/12 and 2/3 to 8/12.","Add: 9/12 + 8/12 = 17/12.","As a mixed number, 17/12 = 1 5/12."]); return;
  }
  // Basic arithmetic: supports decimals and explicit multiplication/division symbols.
  const arithmetic = low.replace(/^(calculate|compute|solve)\s+/,"").match(/^(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)$/);
  if(arithmetic){
    const a=Number(arithmetic[1]), op=arithmetic[2], b=Number(arithmetic[3]);
    if(op==="/" && b===0){error("Division by zero is undefined. Change the divisor.");return;}
    const result={"+":a+b,"-":a-b,"*":a*b,"/":a/b}[op];
    showResult("Arithmetic answer",String(Number(result.toPrecision(12))),[`${a} ${op} ${b} is the expression you entered.`,`Apply the ${op==="*"?"multiplication":op==="/"?"division":op==="+"?"addition":"subtraction"} operation.`,`The result is ${Number(result.toPrecision(12))}.`]);return;
  }
  // Linear equations ax + b = c
  const linear = compact.match(/^(?:solve)?(-?\d*\.?\d*)x([+-]\d+\.?\d*)=(-?\d+\.?\d*)$/);
  if(linear){
    let a=linear[1], b=Number(linear[2]), c=Number(linear[3]);
    a = a==="" || a==="+" ? 1 : a==="-" ? -1 : Number(a);
    if(a===0){error("The coefficient of x cannot be zero for this linear-equation solver.");return;}
    const x=(c-b)/a;
    showResult("Linear equation",`x = ${Number(x.toPrecision(10))}`,["Start with "+p+".","Move the constant term to the right-hand side.","Divide both sides by the coefficient of x.",`x = (${c} − (${b}))/(${a}) = ${Number(x.toPrecision(10))}.`]);return;
  }
  error("I couldn't safely recognize this format. Try an example below or use the supported formats in “How MathSolver works.” This offline version is not a full computer-algebra engine.");
}
solveBtn.addEventListener("click",()=>solveProblem(input.value));
input.addEventListener("keydown",e=>{if(e.key==="Enter")solveProblem(input.value)});
document.querySelectorAll("[data-problem]").forEach(btn=>btn.addEventListener("click",()=>{input.value=btn.dataset.problem; input.focus(); if(btn.classList.contains("example-chip")) solveProblem(input.value); else $("#problemInput").scrollIntoView({behavior:"smooth",block:"center"});}));
$("#shuffleExamples").addEventListener("click",()=>{const list=$("#exampleList");list.innerHTML="";examples.slice(2).concat(examples.slice(0,2)).forEach(([p])=>{const b=document.createElement("button");b.className="example-chip";b.textContent=p.replace(/\^2/g,"²").replace(/\^3/g,"³");b.dataset.problem=p;b.addEventListener("click",()=>{input.value=p;solveProblem(p)});list.appendChild(b)});});
function renderHistory(){const list=$("#historyList");list.replaceChildren();if(!history.length){list.innerHTML='<p class="empty-state">Your solved problems will appear here.</p>';return;}history.slice(0,15).forEach(item=>{const div=document.createElement("div");div.className="history-item";const b=document.createElement("b"),small=document.createElement("small");b.textContent=item.problem;small.textContent=`${item.title} · ${item.time} · ${item.answer}`;div.append(b,small);div.addEventListener("click",()=>{input.value=item.problem;$("#historyDialog").close();solveProblem(item.problem)});list.appendChild(div)});}
$("#historyBtn").addEventListener("click",()=>$("#historyDialog").showModal());
$("#settingsBtn").addEventListener("click",()=>$("#settingsDialog").showModal());
document.querySelectorAll("[data-close]").forEach(b=>b.addEventListener("click",()=>$("#"+b.dataset.close).close()));
$("#copyBtn").addEventListener("click",async()=>{const text=`${$("#resultTitle").textContent}\n${$("#answerBox").textContent}\n`+[...$("#stepsList").children].map((li,i)=>`${i+1}. ${li.textContent}`).join("\n");try{await navigator.clipboard.writeText(text);$("#copyBtn").textContent="✓ Copied";setTimeout(()=>$("#copyBtn").textContent="▣ Copy",1300)}catch{error("Copy is not available in this preview. Select the answer text to copy it.")}});
$("#reduceMotion").addEventListener("change",e=>document.body.classList.toggle("reduce-motion",e.target.checked));
$("#compactMode").addEventListener("change",e=>document.body.classList.toggle("compact",e.target.checked));
