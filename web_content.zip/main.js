import { database, set, ref, get, remove } from './firebase/firebase.js';

document.addEventListener('DOMContentLoaded', () => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const container = $('#prjcontaner');
  const projectTemplate = $('#prj');
  const createButton = $('#create');
  const createPanel = $('#createp');
  const createPanelButton = $('#createprj');
  const historyButton = $('#hisB');
  const historyPanel = $('#his');
  const historyContainer = $('#cnt');
  const historyTemplate = $('#prjj');
  const preview = $('#vidpreview');
  const searchInput = $('#search');
  const typeFilter = $('#toc');

  if (!container || !projectTemplate) {
    console.error('Project list elements are missing from main.html.');
    return;
  }

  // Keep the existing HTML templates, but do not show the templates themselves.
  projectTemplate.style.display = 'none';
  if (historyTemplate) historyTemplate.style.display = 'none';

  const username = localStorage.getItem('username') || 'Unknown user';
  const projectCards = new Map();

  if (createPanelButton && createPanel) {
    createPanelButton.addEventListener('click', event => {
      event.preventDefault();
      createPanel.style.display = 'block';
    });
  }

  if (historyButton && historyPanel) {
    historyButton.addEventListener('click', event => {
      event.preventDefault();
      historyPanel.style.display = 'block';
    });
  }

  function showPreview(videoUrl) {
    if (!preview || !videoUrl) return;
    const video = $('video', preview);
    const downloadLink = $('#vidlink');
    if (video) {
      video.src = videoUrl;
      video.load();
    }
    if (downloadLink) downloadLink.href = videoUrl;
    preview.style.display = 'block';
  }

  function renderProject(project) {
    if (!project || !project.name || projectCards.has(project.name)) return;
    const card = projectTemplate.cloneNode(true);
    card.removeAttribute('id');
    card.style.display = '';
    card.dataset.projectName = project.name;

    const title = $('p', card);
    const image = $('img', card);
    const link = $('a', card);
    if (title) title.textContent = `${project.name} (${project.creator || 'Unknown'}) {${project.type || 'single'}}`;
    if (image) {
      image.src = project.img || '';
      image.alt = project.name;
      image.addEventListener('click', () => showPreview(project.vid));
    }
    if (link) {
      link.href = project.vid || '#';
      link.addEventListener('click', event => {
        if (!project.vid) event.preventDefault();
      });
    }

    container.appendChild(card);
    projectCards.set(project.name, card);

    if (project.creator === username && historyContainer && historyTemplate) {
      const historyItem = historyTemplate.cloneNode(true);
      historyItem.removeAttribute('id');
      historyItem.style.display = '';
      const historyTitle = $('p', historyItem);
      const historyLink = $('a', historyItem);
      if (historyTitle) historyTitle.textContent = project.name;
      if (historyLink) {
        historyLink.href = project.vid || '#';
        historyLink.setAttribute('download', `${project.name}.mp4`);
      }
      const deleteButton = $('.deletbtn', historyItem);
      if (deleteButton) {
        deleteButton.addEventListener('click', async event => {
          event.preventDefault();
          if (!window.confirm(`Delete "${project.name}"?`)) return;
          try {
            await remove(ref(database, `prjs/${project.name}`));
            card.remove();
            historyItem.remove();
            projectCards.delete(project.name);
          } catch (error) {
            console.error('Could not delete project:', error);
            alert('Could not delete this project. Please try again.');
          }
        });
      }
      historyContainer.appendChild(historyItem);
    }
  }

  async function loadProjects() {
    try {
      const snapshot = await get(ref(database, 'prjs'));
      if (!snapshot.exists()) return;
      snapshot.forEach(childSnapshot => {
        const project = childSnapshot.val();
        if (project && typeof project === 'object') {
          renderProject({ ...project, name: project.name || childSnapshot.key });
        } else {
          remove(childSnapshot.ref).catch(error => console.error('Could not remove invalid project:', error));
        }
      });
      applyFilters();
    } catch (error) {
      console.error('Could not load projects:', error);
      alert('Projects could not be loaded. Check your Firebase configuration and database rules.');
    }
  }

  function applyFilters() {
    const query = (searchInput?.value || '').trim().toLowerCase();
    const selectedType = (typeFilter?.value || '').toLowerCase();
    for (const [name, card] of projectCards) {
      const text = ($('p', card)?.textContent || name).toLowerCase();
      const projectType = (text.match(/\{([^}]+)\}/)?.[1] || '').toLowerCase();
      card.style.display = (!query || text.includes(query)) &&
        (!selectedType || projectType === selectedType) ? '' : 'none';
    }
  }

  if (searchInput) searchInput.addEventListener('input', applyFilters);
  if (typeFilter) typeFilter.addEventListener('change', applyFilters);

  function fileToDataUrl(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error || new Error('Could not read file.'));
      reader.readAsDataURL(file);
    });
  }

  if (createButton && createPanel) {
    createButton.addEventListener('click', async event => {
      event.preventDefault();
      const nameInput = $('#prjname', createPanel);
      const imageInput = $('#cpimage', createPanel);
      const videoInput = $('#cpvideo', createPanel);
      const typeInput = $('select', createPanel);
      const name = nameInput?.value.trim();
      const imageFile = imageInput?.files?.[0];
      const videoFile = videoInput?.files?.[0];

      if (!name || !imageFile || !videoFile) {
        alert('Enter a project name and select both an image and a video.');
        return;
      }
      if (name.includes('/') || name === '.' || name === '..') {
        alert('Please choose a project name without slashes.');
        return;
      }
      if (projectCards.has(name)) {
        alert('A project with that name is already displayed. Please choose another name.');
        return;
      }

      createButton.disabled = true;
      try {
        const [imageData, videoData] = await Promise.all([
          fileToDataUrl(imageFile),
          fileToDataUrl(videoFile)
        ]);
        const project = {
          name,
          type: typeInput?.value || 'single',
          img: imageData,
          vid: videoData,
          creator: username,
          createdAt: Date.now()
        };
        await set(ref(database, `prjs/${name}`), project);
        renderProject(project);
        applyFilters();
        if (nameInput) nameInput.value = '';
        if (imageInput) imageInput.value = '';
        if (videoInput) videoInput.value = '';
        createPanel.style.display = 'none';
      } catch (error) {
        console.error('Could not create project:', error);
        alert('Project could not be saved. The video/image may be too large for Firebase Realtime Database.');
      } finally {
        createButton.disabled = false;
      }
    });
  }

  loadProjects();
});
