const PAKISTAN_TIME_ZONE = 'Asia/Karachi';

export function localDateKey(date = new Date()) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    throw new TypeError('localDateKey expects a valid Date.');
  }
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: PAKISTAN_TIME_ZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(date);
  const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}

export function currentMonthRange(date = new Date()) {
  const month = localDateKey(date).slice(0, 7);
  return { from: `${month}-01`, to: localDateKey(date) };
}

export function pakistanDateOptions(options = {}) {
  return { ...options, timeZone: PAKISTAN_TIME_ZONE };
}
