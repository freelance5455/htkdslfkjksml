# Smart Life Alarm — Android app (v11)

The whole app runs on the phone. No sign-in, no server — every alarm, reminder, Day Plan,
setting and history entry is saved only on the phone.

What the phone app adds on top of the web app:
- Alarms ring even when the app is closed or the phone is locked (Android alarm clock, full-screen alarm screen, Stop / Snooze).
- The reminder is read aloud by the phone's natural (Google) voice, in Hindi or English, until you stop it.
- Optional "Read phone notifications aloud" (Settings → Alerts): like TalkBack, every new notification from any app is spoken, even with the app closed.
- Alarms come back after a restart, an app update, or a time / time-zone change.
- Backup and history CSV files are saved into the phone's Downloads folder.

## Option A — get the APK without installing anything (GitHub)
1. Create a new GitHub repository and upload everything in this folder (including the hidden `.github` folder).
2. Open the **Actions** tab → **Build APK** → **Run workflow**.
3. After ~5 minutes open the finished run and download **SmartLifeAlarm-apk**. Unzip it and copy the `.apk` to your phone, then tap it to install (allow "Install unknown apps" once).

## Option B — Android Studio
1. Install Android Studio (it brings Java and the Android SDK).
2. Open the `android` folder in Android Studio and wait for "Gradle sync" to finish.
3. Press **Run ▶** with your phone connected (USB debugging on), or use **Build → Build APK(s)**.

## First start on the phone
Open **Settings → Alerts → Notifications → Fix** and follow the steps until it says
"Background alarms ready ✓":
1. Allow notifications.
2. Allow "Alarms & reminders" (exact alarms) if asked.
3. Allow full-screen alarms (Android 14+).
4. Set battery to "Unrestricted" so the phone never stops an alarm.
Then tap **Test** — lock the phone and the test alarm rings in 5 seconds.

## Updating the app screen
The app screen is `www/index.html`, built from the web project with `bun run build:local`
(file `dist-local/index.html`). Copy it to `www/index.html`, then run `npx cap sync android`
(Option A does this automatically).
