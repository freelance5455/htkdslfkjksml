package com.webcreatorhub.smartlifealarm;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

/** Bridge used by the app (block "v10" in src/legacy/app.ts). */
@CapacitorPlugin(
    name = "SmartAlarm",
    permissions = { @Permission(alias = "notifications", strings = { Manifest.permission.POST_NOTIFICATIONS }) }
)
public class SmartAlarmPlugin extends Plugin {
    private static WeakReference<SmartAlarmPlugin> instance = new WeakReference<>(null);

    @Override
    public void load() {
        instance = new WeakReference<>(this);
        AlarmScheduler.rescheduleAll(getContext());
    }

    /** Tell the open app that the phone changed something (an alarm rang / was stopped / snoozed). */
    static void emit() {
        SmartAlarmPlugin p = instance.get();
        if (p != null) p.notifyListeners("alarmEvent", new JSObject());
    }

    private JSObject status() {
        Context c = getContext();
        String pkg = c.getPackageName();
        JSObject o = new JSObject();
        o.put("notifications", NotificationManagerCompat.from(c).areNotificationsEnabled());
        boolean full = true;
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            full = nm == null || nm.canUseFullScreenIntent();
        }
        o.put("fullScreen", full);
        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            exact = am == null || am.canScheduleExactAlarms();
        }
        o.put("exact", exact);
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        o.put("battery", pm == null || pm.isIgnoringBatteryOptimizations(pkg));
        o.put("reader", NotificationManagerCompat.getEnabledListenerPackages(c).contains(pkg));
        o.put("readerOn", AlarmStore.opt(c, "reader", false));
        o.put("sdk", Build.VERSION.SDK_INT);
        return o;
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        call.resolve(status());
    }

    @PluginMethod
    public void requestSetup(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 33 && getPermissionState("notifications") != PermissionState.GRANTED) {
            requestPermissionForAlias("notifications", call, "permDone");
        } else {
            call.resolve(status());
        }
    }

    @PermissionCallback
    private void permDone(PluginCall call) {
        call.resolve(status());
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Context c = getContext();
        String pkg = c.getPackageName();
        String type = call.getString("type", "app");
        Intent i;
        switch (type == null ? "app" : type) {
            case "notifications":
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                break;
            case "fullscreen":
                i = Build.VERSION.SDK_INT >= 34
                    ? new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + pkg))
                    : new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
                break;
            case "exact":
                i = Build.VERSION.SDK_INT >= 31
                    ? new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + pkg))
                    : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                break;
            case "battery":
                i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg));
                break;
            case "reader":
                if (Build.VERSION.SDK_INT >= 30) {
                    i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                        .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, new ComponentName(c, NotifyReaderService.class).flattenToString());
                } else {
                    i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                }
                break;
            default:
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception e) {
            try {
                Intent fb = "reader".equals(type)
                    ? new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                    : "battery".equals(type)
                        ? new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                c.startActivity(fb.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
            }
        }
        call.resolve(status());
    }

    @PluginMethod
    public void test(PluginCall call) {
        AlarmScheduler.armTest(getContext(), call.getInt("seconds", 5));
        call.resolve();
    }

    @PluginMethod
    public void sync(PluginCall call) {
        Context c = getContext();
        JSObject r = new JSObject();
        // Events from the phone must reach the app first, or old app data would undo them.
        if (AlarmStore.hasEvents(c)) {
            r.put("pending", true);
            call.resolve(r);
            return;
        }
        JSArray list = call.getArray("alarms", new JSArray());
        JSONArray clean = new JSONArray();
        for (int i = 0; i < list.length(); i++) {
            JSONObject a = list.optJSONObject(i);
            if (a != null && a.has("id")) clean.put(a);
        }
        AlarmStore.setAlarms(c, clean);
        AlarmStore.setOpt(c, "vibrate", call.getBoolean("vibrate", true));
        AlarmStore.setOpt(c, "ramp", call.getBoolean("ramp", true));
        AlarmStore.setOpt(c, "speak", call.getBoolean("speak", true));
        AlarmStore.setOpt(c, "h24", call.getBoolean("h24", false));
        String lang = call.getString("lang");
        if (lang != null) AlarmStore.setStr(c, "lang", lang);
        r.put("pending", false);
        r.put("scheduled", AlarmScheduler.rescheduleAll(c));
        call.resolve(r);
    }

    @PluginMethod
    public void drainEvents(PluginCall call) {
        JSObject r = new JSObject();
        r.put("events", AlarmStore.takeEvents(getContext()));
        call.resolve(r);
    }

    @PluginMethod
    public void setReader(PluginCall call) {
        Context c = getContext();
        AlarmStore.setOpt(c, "reader", call.getBoolean("on", false));
        String lang = call.getString("lang");
        if (lang != null) {
            AlarmStore.setStr(c, "reader_lang", lang);
            AlarmStore.setStr(c, "lang", lang.startsWith("hi") ? "hi" : "en");
        }
        call.resolve(status());
    }

    /** Saves a backup / CSV file into the phone's Downloads folder. */
    @PluginMethod
    public void saveFile(PluginCall call) {
        String name = call.getString("name", "smart-life-alarm.txt");
        String text = call.getString("text", "");
        String mime = call.getString("mime", "text/plain");
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        Context c = getContext();
        JSObject r = new JSObject();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = c.getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime.split(";")[0]);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("no uri");
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) throw new Exception("no stream");
                    os.write(bytes);
                }
                r.put("uri", uri.toString());
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null || (!dir.exists() && !dir.mkdirs())) dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                File f = new File(dir, name);
                try (FileOutputStream os = new FileOutputStream(f)) {
                    os.write(bytes);
                }
                r.put("uri", f.getAbsolutePath());
            }
            r.put("ok", true);
        } catch (Exception e) {
            r.put("ok", false);
            r.put("error", String.valueOf(e.getMessage()));
        }
        call.resolve(r);
    }
}
