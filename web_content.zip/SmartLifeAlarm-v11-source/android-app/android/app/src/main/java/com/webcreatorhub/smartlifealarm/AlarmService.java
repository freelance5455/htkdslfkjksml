package com.webcreatorhub.smartlifealarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import java.util.ArrayDeque;
import org.json.JSONException;
import org.json.JSONObject;

/** Rings one alarm at a time: sound, vibration, the reminder read aloud, and a lock-screen alarm screen. */
public class AlarmService extends Service implements TextToSpeech.OnInitListener {
    static final String ACTION_RING = "com.webcreatorhub.smartlifealarm.SVC_RING";
    static final String ACTION_STOP = "com.webcreatorhub.smartlifealarm.SVC_STOP";
    static final String ACTION_SNOOZE = "com.webcreatorhub.smartlifealarm.SVC_SNOOZE";
    static final String ACTION_DONE_BROADCAST = "com.webcreatorhub.smartlifealarm.ALARM_ENDED";
    static final String CHANNEL = "sla_alarm_ring";
    static final int NOTIF_ID = 4101;
    static final long MISS_AFTER_MS = 10 * 60 * 1000L;

    /** What is ringing now (read by the lock-screen activity). */
    static volatile String curId, curTask, curTime;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private MediaPlayer player;
    private Vibrator vib;
    private TextToSpeech tts;
    private boolean ttsReady;
    private PowerManager.WakeLock wl;
    private String ringing;
    private JSONObject ringAlarm;
    private float vol = 1f;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, this);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SmartLifeAlarm:ring");
            wl.setReferenceCounted(false);
        }
    }

    @Override
    public void onInit(int status) {
        ttsReady = status == TextToSpeech.SUCCESS;
        if (ttsReady) {
            tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { h.post(() -> setVolume(0.25f)); }
                @Override public void onDone(String id) { h.post(AlarmService.this::afterSpeech); }
                @Override public void onError(String id) { h.post(AlarmService.this::afterSpeech); }
            });
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        // Always go foreground first — Android requires it within a few seconds.
        startForegroundCompat(buildNotification());
        if (ACTION_RING.equals(action)) {
            String id = intent.getStringExtra("id");
            if (id != null) {
                if (ringing == null) startRinging(id);
                else if (!id.equals(ringing) && !queue.contains(id)) queue.add(id);
            }
        } else if (ACTION_STOP.equals(action)) {
            finish("done", 0);
        } else if (ACTION_SNOOZE.equals(action)) {
            finish("snooze", intent.getIntExtra("min", 5));
        }
        if (ringing == null && queue.isEmpty()) stopSelfSafe();
        return START_NOT_STICKY;
    }

    private void startRinging(String id) {
        boolean test = AlarmScheduler.TEST_ID.equals(id);
        JSONObject a = test ? testAlarm() : AlarmStore.alarm(this, id);
        if (a == null) {
            next();
            return;
        }
        long now = System.currentTimeMillis();
        ringing = id;
        ringAlarm = a;
        boolean h24 = AlarmStore.opt(this, "h24", false);
        curId = id;
        curTask = a.optString("task", "Alarm");
        curTime = AlarmStore.formatTime(a.optString("t", ""), h24);
        if (!test) {
            // Same rule as the app: remember this ring, clear the snooze, switch a one-time alarm off.
            try {
                String snz = a.optString("snz", "");
                a.put("last", snz.length() == 16 ? snz : AlarmStore.ymd(now) + " " + a.optString("t"));
                a.put("snz", "");
                if ((a.optInt("days", 0) & 127) == 0) a.put("en", false);
            } catch (JSONException ignored) {
            }
            AlarmStore.putAlarm(this, a);
            AlarmStore.addEvent(this, id, "fired", now, 0);
            AlarmScheduler.rescheduleAll(this);
            SmartAlarmPlugin.emit();
        }
        if (wl != null) wl.acquire(MISS_AFTER_MS + 60000);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        playSound();
        startVibration();
        h.postDelayed(this::speak, 2500);
        h.postDelayed(missTimeout, MISS_AFTER_MS);
        // Show the alarm screen right away when allowed (the full-screen notification covers a locked phone).
        try {
            startActivity(new Intent(this, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION));
        } catch (Exception ignored) {
        }
    }

    private final Runnable missTimeout = () -> finish("missed", 0);

    private JSONObject testAlarm() {
        JSONObject o = new JSONObject();
        try {
            boolean hi = "hi".equals(AlarmStore.str(this, "lang", "en"));
            java.util.Calendar c = java.util.Calendar.getInstance();
            o.put("id", AlarmScheduler.TEST_ID);
            o.put("t", String.format(java.util.Locale.US, "%02d:%02d", c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE)));
            o.put("task", hi ? "टेस्ट अलार्म — आपके अलार्म ठीक से काम कर रहे हैं" : "Test alarm — your alarms are working");
            o.put("lang", hi ? "hi-IN" : "en-IN");
            o.put("vo", true);
        } catch (JSONException ignored) {
        }
        return o;
    }

    private void finish(String action, int snoozeMin) {
        String id = ringing;
        if (id == null) {
            stopSelfSafe();
            return;
        }
        long now = System.currentTimeMillis();
        if (!AlarmScheduler.TEST_ID.equals(id)) {
            JSONObject a = AlarmStore.alarm(this, id);
            if (a != null) {
                try {
                    if ("done".equals(action)) a.put("done", AlarmStore.ymd(now));
                    if ("snooze".equals(action)) {
                        int m = Math.max(1, Math.min(120, snoozeMin));
                        a.put("snz", AlarmStore.ymdhm(now + m * 60000L));
                        a.put("en", true);
                    }
                } catch (JSONException ignored) {
                }
                AlarmStore.putAlarm(this, a);
            }
            AlarmStore.addEvent(this, id, action, now, "snooze".equals(action) ? snoozeMin : 0);
            AlarmScheduler.rescheduleAll(this);
            SmartAlarmPlugin.emit();
        }
        stopRinging();
        sendBroadcast(new Intent(ACTION_DONE_BROADCAST).setPackage(getPackageName()));
        next();
    }

    private void next() {
        String n = queue.poll();
        if (n != null) startRinging(n);
        else stopSelfSafe();
    }

    private void stopRinging() {
        h.removeCallbacksAndMessages(null);
        ringing = null;
        ringAlarm = null;
        curId = null;
        try {
            if (tts != null) tts.stop();
        } catch (Exception ignored) {
        }
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
        if (vib != null) vib.cancel();
        if (wl != null && wl.isHeld()) wl.release();
    }

    private void stopSelfSafe() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    // ---------- sound ----------
    private void playSound() {
        Uri u = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            player.setDataSource(this, u);
            player.setLooping(true);
            player.prepare();
            boolean ramp = AlarmStore.opt(this, "ramp", true);
            vol = ramp ? 0.15f : 1f;
            player.setVolume(vol, vol);
            player.start();
            if (ramp) h.postDelayed(rampUp, 2000);
        } catch (Exception e) {
            player = null;
        }
    }

    private final Runnable rampUp = new Runnable() {
        @Override
        public void run() {
            if (player == null) return;
            vol = Math.min(1f, vol + 0.045f); // ~40 s to full volume
            setVolume(duck);
            if (vol < 1f) h.postDelayed(this, 2000);
        }
    };

    /** duck = 0.25 while the reminder is being read, 1 otherwise. */
    private float duck = 1f;

    private void setVolume(float d) {
        duck = d;
        if (player != null) {
            float v = vol * duck;
            player.setVolume(v, v);
        }
    }

    private void startVibration() {
        if (!AlarmStore.opt(this, "vibrate", true)) return;
        vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vib == null || !vib.hasVibrator()) return;
        long[] pat = {0, 600, 400, 600, 1200};
        if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pat, 0));
        else vib.vibrate(pat, 0);
    }

    // ---------- voice ----------
    private void speak() {
        if (ringing == null || ringAlarm == null) return;
        if (!AlarmStore.opt(this, "speak", true) || !ringAlarm.optBoolean("vo", true)) return;
        if (!ttsReady) {
            h.postDelayed(this::speak, 1000);
            return;
        }
        VoicePick.apply(tts, ringAlarm.optString("lang", "hi-IN"));
        tts.setSpeechRate(0.95f);
        tts.speak(ringAlarm.optString("task", ""), TextToSpeech.QUEUE_FLUSH, null, "sla-" + ringing);
    }

    private void afterSpeech() {
        setVolume(1f);
        if (ringing != null) h.postDelayed(this::speak, 4000); // keep reading it until stopped, like the app
    }

    // ---------- notification ----------
    private void ensureChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Ringing alarms", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Shows the alarm screen and Stop / Snooze buttons");
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setBypassDnd(true);
        nm.createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        ensureChannel();
        boolean hi = "hi".equals(AlarmStore.str(this, "lang", "en"));
        Intent full = new Intent(this, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
        PendingIntent fullPi = PendingIntent.getActivity(this, 11, full, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 12, new Intent(this, AlarmService.class).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent snz = PendingIntent.getService(this, 13, new Intent(this, AlarmService.class).setAction(ACTION_SNOOZE).putExtra("min", 5), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String title = curId != null ? (curTime + " · Smart Life Alarm") : "Smart Life Alarm";
        String text = curId != null ? curTask : (hi ? "अलार्म शुरू हो रहा है…" : "Starting alarm…");
        return new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setFullScreenIntent(fullPi, true)
                .setContentIntent(fullPi)
                .addAction(0, hi ? "रोकें" : "Stop", stop)
                .addAction(0, hi ? "5 मिनट स्नूज़" : "Snooze 5 min", snz)
                .build();
    }

    private void startForegroundCompat(Notification n) {
        int type = Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK : 0;
        ServiceCompat.startForeground(this, NOTIF_ID, n, type);
    }

    @Override
    public void onDestroy() {
        stopRinging();
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    static void control(Context c, String action, int min) {
        Intent i = new Intent(c, AlarmService.class).setAction(action).putExtra("min", min);
        try {
            c.startService(i);
        } catch (Exception e) {
            androidx.core.content.ContextCompat.startForegroundService(c, i);
        }
    }
}
