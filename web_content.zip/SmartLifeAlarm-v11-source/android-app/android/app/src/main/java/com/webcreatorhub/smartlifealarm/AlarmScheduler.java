package com.webcreatorhub.smartlifealarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Hands every enabled alarm to Android's own alarm clock, so it rings even when the app is closed. */
final class AlarmScheduler {
    static final String ACTION_RING = "com.webcreatorhub.smartlifealarm.RING";
    static final String TEST_ID = "__test__";

    private AlarmScheduler() {}

    /** Next ring time in ms, or -1. Same rules as the web app: snooze first, then weekdays or the one-time date. */
    static long next(JSONObject a, long now) {
        if (a == null || !a.optBoolean("en", false)) return -1;
        String snz = a.optString("snz", "");
        if (snz.length() == 16) {
            long z = parse(snz);
            if (z > now) return z;
        }
        String t = a.optString("t", "");
        if (!t.matches("\\d{2}:\\d{2}")) return -1;
        int h = Integer.parseInt(t.substring(0, 2)), m = Integer.parseInt(t.substring(3, 5));
        int days = a.optInt("days", 0) & 127;
        String last = a.optString("last", "");
        if (days > 0) {
            for (int i = 0; i < 8; i++) {
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(now);
                c.add(Calendar.DAY_OF_YEAR, i);
                c.set(Calendar.HOUR_OF_DAY, h);
                c.set(Calendar.MINUTE, m);
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                int dow = c.get(Calendar.DAY_OF_WEEK) - 1; // Sunday = 0, like the app
                long ms = c.getTimeInMillis();
                if (((days >> dow) & 1) == 1 && ms > now && !AlarmStore.ymdhm(ms).equals(last)) return ms;
            }
            return -1;
        }
        String date = a.optString("date", "");
        if (date.length() != 10) return -1;
        long ms = parse(date + " " + t);
        return ms > now ? ms : -1;
    }

    private static long parse(String ymdhm) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(ymdhm).getTime();
        } catch (Exception e) {
            return -1;
        }
    }

    static PendingIntent ringIntent(Context c, String id, int flags) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(ACTION_RING).putExtra("id", id);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Re-arm everything (after a change, a ring, a reboot or a time-zone change). Returns how many are armed. */
    static synchronized int rescheduleAll(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return 0;
        long now = System.currentTimeMillis();
        JSONArray list = AlarmStore.alarms(c);
        Set<String> armed = new HashSet<>();
        for (int i = 0; i < list.length(); i++) {
            JSONObject a = list.optJSONObject(i);
            if (a == null) continue;
            String id = a.optString("id");
            long at = next(a, now);
            if (at <= 0) continue;
            arm(c, am, id, at);
            armed.add(id);
        }
        for (String old : AlarmStore.scheduledIds(c)) {
            if (!armed.contains(old) && !TEST_ID.equals(old)) {
                PendingIntent pi = ringIntent(c, old, PendingIntent.FLAG_NO_CREATE);
                if (pi != null) {
                    am.cancel(pi);
                    pi.cancel();
                }
            }
        }
        AlarmStore.setScheduledIds(c, armed);
        return armed.size();
    }

    static void arm(Context c, AlarmManager am, String id, long at) {
        PendingIntent pi = ringIntent(c, id, PendingIntent.FLAG_UPDATE_CURRENT);
        Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent show = PendingIntent.getActivity(c, 7, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    static void armTest(Context c, int seconds) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) arm(c, am, TEST_ID, System.currentTimeMillis() + Math.max(3, seconds) * 1000L);
    }
}
