package com.webcreatorhub.smartlifealarm;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // The phone-side alarm plugin must be registered before the bridge starts.
        registerPlugin(SmartAlarmPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
