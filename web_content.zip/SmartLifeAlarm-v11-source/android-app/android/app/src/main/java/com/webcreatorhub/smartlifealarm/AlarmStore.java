package com.webcreatorhub.smartlifealarm;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Everything the phone needs to ring alarms while the app is closed. Saved on the phone only. */
final class AlarmStore {
    private static final String PREFS = "sla_native";

    private AlarmStore() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static synchronized JSONArray alarms(Context c) {
        try {
            return new JSONArray(p(c).getString("alarms", "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    static synchronized void setAlarms(Context c, JSONArray list) {
        p(c).edit().putString("alarms", list.toString()).apply();
    }

    static synchronized JSONObject alarm(Context c, String id) {
        JSONArray a = alarms(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    static synchronized void putAlarm(Context c, JSONObject alarm) {
        JSONArray a = alarms(c), out = new JSONArray();
        boolean found = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            if (alarm.optString("id").equals(o.optString("id"))) {
                out.put(alarm);
                found = true;
            } else out.put(o);
        }
        if (!found) out.put(alarm);
        setAlarms(c, out);
    }

    // ---- events the app reads back (fired / done / snooze / missed) ----
    static synchronized void addEvent(Context c, String id, String action, long at, int snooze) {
        try {
            JSONArray ev = new JSONArray(p(c).getString("events", "[]"));
            JSONObject o = new JSONObject();
            o.put("id", id);
            o.put("action", action);
            o.put("at", at);
            if (snooze > 0) o.put("snooze", snooze);
            ev.put(o);
            p(c).edit().putString("events", ev.toString()).commit();
        } catch (JSONException ignored) {
        }
    }

    static synchronized boolean hasEvents(Context c) {
        return !"[]".equals(p(c).getString("events", "[]"));
    }

    static synchronized JSONArray takeEvents(Context c) {
        JSONArray ev;
        try {
            ev = new JSONArray(p(c).getString("events", "[]"));
        } catch (JSONException e) {
            ev = new JSONArray();
        }
        p(c).edit().putString("events", "[]").commit();
        return ev;
    }

    // ---- options ----
    static boolean opt(Context c, String k, boolean def) {
        return p(c).getBoolean("opt_" + k, def);
    }

    static void setOpt(Context c, String k, boolean v) {
        p(c).edit().putBoolean("opt_" + k, v).apply();
    }

    static String str(Context c, String k, String def) {
        return p(c).getString("str_" + k, def);
    }

    static void setStr(Context c, String k, String v) {
        p(c).edit().putString("str_" + k, v).apply();
    }

    static java.util.Set<String> scheduledIds(Context c) {
        return new java.util.HashSet<>(p(c).getStringSet("scheduled", new java.util.HashSet<>()));
    }

    static void setScheduledIds(Context c, java.util.Set<String> ids) {
        p(c).edit().putStringSet("scheduled", ids).apply();
    }

    // ---- small helpers ----
    static String ymd(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ms));
    }

    static String ymdhm(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(ms));
    }

    /** "20:05" → "8:05 PM" (12-hour) or "20:05" (24-hour), same rule as the app. */
    static String formatTime(String hhmm, boolean h24) {
        try {
            String[] s = hhmm.split(":");
            int h = Integer.parseInt(s[0]), m = Integer.parseInt(s[1]);
            if (h24) return String.format(Locale.US, "%02d:%02d", h, m);
            int hh = h % 12 == 0 ? 12 : h % 12;
            return String.format(Locale.US, "%d:%02d %s", hh, m, h < 12 ? "AM" : "PM");
        } catch (Exception e) {
            return hhmm;
        }
    }
}
