package com.webcreatorhub.smartlifealarm;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.content.ContextCompat;

/** Full-screen alarm screen that also appears on a locked phone. */
public class AlarmActivity extends Activity {
    private final BroadcastReceiver ended = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (AlarmService.curId == null) finish();
            else render();
        }
    };
    private TextView time, task;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km != null) km.requestDismissKeyguard(this, null);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        boolean hi = "hi".equals(AlarmStore.str(this, "lang", "en"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(40), dp(28), dp(40));
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {Color.parseColor("#232a22"), Color.parseColor("#0e110e")});
        root.setBackground(bg);

        TextView brand = text("Smart Life Alarm", 15, "#b99b65", false);
        brand.setLetterSpacing(0.12f);
        time = text("", 64, "#f2ead8", true);
        task = text("", 26, "#eee8da", false);
        task.setPadding(0, dp(14), 0, dp(36));

        Button stop = button(hi ? "रोकें" : "STOP", "#b99b65", "#161711", 22);
        stop.setOnClickListener(v -> act(AlarmService.ACTION_STOP, 0));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button s5 = button(hi ? "5 मिनट स्नूज़" : "Snooze 5 min", "#2c2b20", "#e9dcbc", 16);
        Button s10 = button(hi ? "10 मिनट स्नूज़" : "Snooze 10 min", "#2c2b20", "#e9dcbc", 16);
        s5.setOnClickListener(v -> act(AlarmService.ACTION_SNOOZE, 5));
        s10.setOnClickListener(v -> act(AlarmService.ACTION_SNOOZE, 10));
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(56), 1f);
        half.setMargins(dp(6), dp(14), dp(6), 0);
        row.addView(s5, half);
        row.addView(s10, half);

        root.addView(brand);
        root.addView(time);
        root.addView(task);
        root.addView(stop, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68)));
        root.addView(row, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        render();
        ContextCompat.registerReceiver(this, ended, new IntentFilter(AlarmService.ACTION_DONE_BROADCAST), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (AlarmService.curId == null) finish();
        else render();
    }

    private void render() {
        time.setText(AlarmService.curTime != null ? AlarmService.curTime : "");
        task.setText(AlarmService.curTask != null ? AlarmService.curTask : "");
    }

    private void act(String action, int min) {
        AlarmService.control(this, action, min);
        finish();
    }

    @Override
    public void onBackPressed() {
        // Back does not silence the alarm by accident; use Stop or Snooze.
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(ended);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView text(String s, int sp, String color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.SERIF, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    private Button button(String s, String bg, String fg, int sp) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTextColor(Color.parseColor(fg));
        b.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(bg));
        d.setCornerRadius(dp(14));
        d.setStroke(dp(1), Color.parseColor("#6a5f42"));
        b.setBackground(d);
        b.setStateListAnimator(null);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        return b;
    }
}
