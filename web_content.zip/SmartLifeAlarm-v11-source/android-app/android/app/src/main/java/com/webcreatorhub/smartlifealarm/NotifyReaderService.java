package com.webcreatorhub.smartlifealarm;

import android.app.Notification;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.speech.tts.TextToSpeech;

/**
 * TalkBack-style reader: when switched on in Settings, every new notification on the phone
 * (WhatsApp, SMS, calls missed, other apps) is read aloud — even when Smart Life Alarm is closed.
 * Android keeps this service running in the background once "Notification access" is allowed.
 */
public class NotifyReaderService extends NotificationListenerService implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private boolean ready;
    private String lastKey = "";
    private long lastAt;

    @Override
    public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, this);
    }

    @Override
    public void onInit(int status) {
        ready = status == TextToSpeech.SUCCESS;
        if (ready) {
            tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!ready || sbn == null || !AlarmStore.opt(this, "reader", false)) return;
        if (getPackageName().equals(sbn.getPackageName())) return; // our own alarms already speak
        Notification n = sbn.getNotification();
        if (n == null || sbn.isOngoing()) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        if (am != null && (am.getMode() == AudioManager.MODE_IN_CALL || am.getMode() == AudioManager.MODE_IN_COMMUNICATION)) return;
        Bundle e = n.extras;
        if (e == null) return;
        CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence body = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        if (body == null) body = e.getCharSequence(Notification.EXTRA_TEXT);
        String t = title == null ? "" : title.toString().trim();
        String b = body == null ? "" : body.toString().trim();
        if (t.isEmpty() && b.isEmpty()) return;
        String key = sbn.getPackageName() + "|" + t + "|" + b;
        long now = System.currentTimeMillis();
        if (key.equals(lastKey) && now - lastAt < 8000) return; // the same update posted twice
        lastKey = key;
        lastAt = now;
        String app = appName(sbn.getPackageName());
        boolean hi = AlarmStore.str(this, "reader_lang", "en-IN").startsWith("hi");
        String say = (hi ? app + " से नोटिफ़िकेशन. " : "Notification from " + app + ". ") + t + (b.isEmpty() ? "" : ". " + b);
        if (say.length() > 420) say = say.substring(0, 420);
        VoicePick.apply(tts, AlarmStore.str(this, "reader_lang", "en-IN"));
        tts.speak(say, TextToSpeech.QUEUE_ADD, null, "rd-" + now);
    }

    private String appName(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return pkg;
        }
    }

    @Override
    public void onDestroy() {
        try {
            if (tts != null) tts.shutdown();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }
}
