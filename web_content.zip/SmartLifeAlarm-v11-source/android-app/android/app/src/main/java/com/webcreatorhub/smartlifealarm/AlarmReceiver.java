package com.webcreatorhub.smartlifealarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

/** Android calls this at the alarm time; it starts the ringing service. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        if (id == null) return;
        Intent s = new Intent(context, AlarmService.class).setAction(AlarmService.ACTION_RING).putExtra("id", id);
        try {
            ContextCompat.startForegroundService(context, s);
        } catch (Exception e) {
            // Last resort: record it so the app shows it as missed.
            AlarmStore.addEvent(context, id, "missed", System.currentTimeMillis(), 0);
        }
    }
}
