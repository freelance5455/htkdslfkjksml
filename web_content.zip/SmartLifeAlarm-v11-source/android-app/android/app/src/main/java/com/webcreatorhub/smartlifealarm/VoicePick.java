package com.webcreatorhub.smartlifealarm;

import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Locale;
import java.util.Set;

/** Picks the most natural installed voice (Google's neural voices when available) for a language. */
final class VoicePick {
    private VoicePick() {}

    static void apply(TextToSpeech tts, String lang) {
        if (tts == null) return;
        Locale want = Locale.forLanguageTag(lang == null || lang.isEmpty() ? "hi-IN" : lang);
        try {
            int r = tts.setLanguage(want);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(new Locale(want.getLanguage()));
            }
            Set<Voice> voices = tts.getVoices();
            if (voices == null) return;
            Voice best = null;
            int bestScore = -1;
            for (Voice v : voices) {
                Locale l = v.getLocale();
                if (l == null || !l.getLanguage().equals(want.getLanguage())) continue;
                if (v.getFeatures() != null && v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)) continue;
                int score = v.getQuality();
                if (want.getCountry().equals(l.getCountry())) score += 50;
                if (!v.isNetworkConnectionRequired()) score += 30; // works offline
                if (score > bestScore) {
                    bestScore = score;
                    best = v;
                }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception ignored) {
        }
    }
}
