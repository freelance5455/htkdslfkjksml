/* Stand-alone entry for Smart Life Alarm: no server, no hosting. Built into one self-contained
 * index.html (bun run build:local) that opens straight from the phone or computer, and that the
 * Android app uses as its screen. */
import "@/legacy/app.css";
import { MARKUP } from "@/legacy/markup";
import { THEME_IDS } from "@/lib/themes-core";
import { CLOCK_STYLE_IDS, CLOCK_THEME_IDS } from "@/lib/clock-core";
import { boot } from "@/legacy/app";

// Apply the saved theme, clock look and 12/24-hour format before the app draws.
try {
  const s = JSON.parse(localStorage.getItem("sla_settings") || "{}") || {};
  const d = document.documentElement;
  if ((THEME_IDS as readonly string[]).indexOf(s.theme) > 0) d.setAttribute("data-theme", s.theme);
  if ((CLOCK_THEME_IDS as readonly string[]).indexOf(s.ck) > 0) d.setAttribute("data-ck", s.ck);
  if ((CLOCK_STYLE_IDS as readonly string[]).indexOf(s.cks) > 0) d.setAttribute("data-cks", s.cks);
  if (s.h24) d.classList.add("h24");
} catch {
  /* first run */
}

const root = document.getElementById("sla-root");
if (root) root.innerHTML = MARKUP;
boot();
