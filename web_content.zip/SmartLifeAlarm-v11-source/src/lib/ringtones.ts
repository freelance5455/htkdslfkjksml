// Original alarm tones synthesised live with the Web Audio API (no recorded or licensed audio).
export type Voice = "bell" | "harp" | "marimba" | "soft" | "pad";
type Note = [time: number, midi: number, dur: number, vel: number];
export type Ringtone = { id: string; name: string; hi: string; desc: string; voice: Voice; cycle: number; notes: Note[] };

export const LIST: Ringtone[] = [
  {
    id: "sunrise",
    name: "Sunrise Chime",
    hi: "सूर्योदय चाइम",
    desc: "Warm rising chimes",
    voice: "bell",
    cycle: 3.4,
    notes: [
      [0, 72, 1.6, 0.7],
      [0.38, 76, 1.6, 0.7],
      [0.76, 79, 1.6, 0.72],
      [1.14, 84, 2.2, 0.8],
    ],
  },
  {
    id: "bells",
    name: "Morning Bells",
    hi: "सुबह की घंटियाँ",
    desc: "Two soft bells",
    voice: "bell",
    cycle: 3.6,
    notes: [
      [0, 79, 2.4, 0.75],
      [0.62, 74, 2.4, 0.65],
      [1.8, 79, 2.4, 0.75],
      [2.42, 83, 2.6, 0.6],
    ],
  },
  {
    id: "harp",
    name: "Calm Harp",
    hi: "शांत हार्प",
    desc: "Gentle plucked arpeggio",
    voice: "harp",
    cycle: 3.2,
    notes: [
      [0, 69, 1.8, 0.6],
      [0.26, 72, 1.8, 0.6],
      [0.52, 76, 1.8, 0.62],
      [0.78, 81, 2, 0.66],
      [1.04, 76, 1.8, 0.55],
      [1.3, 72, 2.2, 0.5],
    ],
  },
  {
    id: "marimba",
    name: "Gentle Marimba",
    hi: "मृदु मरिम्बा",
    desc: "Light wooden melody",
    voice: "marimba",
    cycle: 3,
    notes: [
      [0, 77, 0.6, 0.7],
      [0.18, 81, 0.6, 0.7],
      [0.36, 84, 0.6, 0.72],
      [0.54, 81, 0.6, 0.6],
      [1.2, 77, 0.6, 0.7],
      [1.38, 81, 0.6, 0.7],
      [1.56, 84, 0.6, 0.72],
      [1.74, 89, 0.9, 0.62],
    ],
  },
  {
    id: "dawn",
    name: "Soft Dawn",
    hi: "कोमल सुबह",
    desc: "Slow ambient chord",
    voice: "pad",
    cycle: 4.8,
    notes: [
      [0, 60, 4.2, 0.5],
      [0, 67, 4.2, 0.42],
      [0, 72, 4.2, 0.36],
      [2.4, 76, 2.2, 0.32],
    ],
  },
  {
    id: "pulse",
    name: "Classic Soft Pulse",
    hi: "क्लासिक हल्की पल्स",
    desc: "Clear but gentle beeps",
    voice: "soft",
    cycle: 1.5,
    notes: [
      [0, 76, 0.14, 0.6],
      [0.24, 76, 0.14, 0.6],
    ],
  },
];

export const DEFAULT_ID = "sunrise";
export const has = (id: string) => LIST.some((r) => r.id === id);
export const get = (id: string): Ringtone => LIST.find((r) => r.id === id) ?? (LIST[0] as Ringtone);
export const nameOf = (id: string, hi = false) => {
  const r = get(id);
  return hi ? r.hi : r.name;
};

const freq = (m: number) => 440 * Math.pow(2, (m - 69) / 12);

function env(ac: BaseAudioContext, t: number, attack: number, peak: number, decay: number) {
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), t + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  return g;
}

function osc(ac: BaseAudioContext, type: OscillatorType, f: number, t: number, stop: number, dest: AudioNode, gain: GainNode) {
  const o = ac.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f, t);
  o.connect(gain);
  gain.connect(dest);
  o.start(t);
  o.stop(stop);
}

export function playNote(ac: BaseAudioContext, dest: AudioNode, voice: Voice, t: number, midi: number, dur: number, vel: number) {
  const f = freq(midi);
  if (voice === "bell") {
    const parts: [number, number][] = [
      [1, 1],
      [2, 0.42],
      [3, 0.2],
      [4.2, 0.12],
      [5.4, 0.06],
    ];
    parts.forEach(([m, a], i) => {
      const d = dur / (1 + i * 0.6);
      osc(ac, "sine", f * m, t, t + d + 0.05, dest, env(ac, t, 0.006, vel * a * 0.5, d));
    });
  } else if (voice === "harp") {
    const lp = ac.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(2600, t);
    lp.connect(dest);
    osc(ac, "triangle", f, t, t + dur + 0.05, lp, env(ac, t, 0.004, vel * 0.5, dur));
    osc(ac, "sine", f * 2, t, t + dur * 0.5, lp, env(ac, t, 0.004, vel * 0.12, dur * 0.45));
  } else if (voice === "marimba") {
    osc(ac, "sine", f, t, t + dur + 0.05, dest, env(ac, t, 0.003, vel * 0.55, dur));
    osc(ac, "sine", f * 4, t, t + 0.15, dest, env(ac, t, 0.002, vel * 0.1, 0.1));
  } else if (voice === "pad") {
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vel * 0.32, t + dur * 0.35);
    g.gain.linearRampToValueAtTime(0.0001, t + dur);
    osc(ac, "sine", f, t, t + dur + 0.05, dest, g);
    const g2 = ac.createGain();
    g2.gain.setValueAtTime(0.0001, t);
    g2.gain.linearRampToValueAtTime(vel * 0.08, t + dur * 0.4);
    g2.gain.linearRampToValueAtTime(0.0001, t + dur);
    osc(ac, "triangle", f * 1.003, t, t + dur + 0.05, dest, g2);
  } else {
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vel * 0.4, t + 0.02);
    g.gain.setValueAtTime(vel * 0.4, t + dur);
    g.gain.linearRampToValueAtTime(0.0001, t + dur + 0.06);
    osc(ac, "sine", f, t, t + dur + 0.1, dest, g);
  }
}

export type PlayOptions = { ramp?: boolean; rampSeconds?: number; startGain?: number; maxGain?: number; maxDuration?: number; onEnd?: (() => void) | undefined };
export type ToneHandle = { pause(): void; volume: number; readonly playing: boolean };

/** Gradual volume: start quiet and rise linearly to the comfortable maximum. */
export function rampGainAt(elapsed: number, o: { startGain: number; maxGain: number; rampSeconds: number }) {
  if (elapsed <= 0) return o.startGain;
  if (elapsed >= o.rampSeconds) return o.maxGain;
  return o.startGain + ((o.maxGain - o.startGain) * elapsed) / o.rampSeconds;
}

export function play(ac: AudioContext, id: string, opts: PlayOptions = {}): ToneHandle {
  const rt = get(id);
  const ramp = opts.ramp !== false;
  const maxGain = opts.maxGain ?? 0.6;
  const startGain = ramp ? (opts.startGain ?? 0.07) : maxGain;
  const rampSeconds = opts.rampSeconds ?? 40;
  const comp = ac.createDynamicsCompressor();
  comp.threshold.value = -14;
  comp.ratio.value = 3;
  const level = ac.createGain();
  const duck = ac.createGain();
  const t0 = ac.currentTime + 0.08;
  level.gain.setValueAtTime(startGain, t0);
  if (ramp) level.gain.linearRampToValueAtTime(maxGain, t0 + rampSeconds);
  duck.gain.value = 1;
  duck.connect(level);
  level.connect(comp);
  comp.connect(ac.destination);
  let next = t0;
  let playing = true;
  const endAt = opts.maxDuration ? t0 + opts.maxDuration : Infinity;
  const schedule = () => {
    if (!playing) return;
    while (next < ac.currentTime + 1.2 && next < endAt) {
      for (const [t, m, d, v] of rt.notes) if (next + t < endAt) playNote(ac, duck, rt.voice, next + t, m, d, v);
      next += rt.cycle;
    }
    if (next >= endAt && ac.currentTime > endAt + 1.5) stop(true);
  };
  const timer = setInterval(schedule, 250);
  schedule();
  function stop(natural = false) {
    if (!playing) return;
    playing = false;
    clearInterval(timer);
    const now = ac.currentTime;
    try {
      level.gain.cancelScheduledValues(now);
      level.gain.setValueAtTime(level.gain.value, now);
      level.gain.linearRampToValueAtTime(0.0001, now + 0.2);
    } catch {
      /* ignore */
    }
    setTimeout(() => {
      try {
        comp.disconnect();
      } catch {
        /* ignore */
      }
    }, 400);
    if (natural || opts.onEnd) opts.onEnd?.();
  }
  return {
    pause: () => stop(false),
    get playing() {
      return playing;
    },
    get volume() {
      return duck.gain.value;
    },
    set volume(v: number) {
      try {
        duck.gain.setTargetAtTime(Math.max(0, Math.min(1, v)), ac.currentTime, 0.08);
      } catch {
        /* ignore */
      }
    },
  };
}

/** Short preview in Settings: soft start and a quick rise so the gradual volume is audible. */
export function preview(ac: AudioContext, id: string, onEnd?: () => void): ToneHandle {
  try {
    void ac.resume();
  } catch {
    /* ignore */
  }
  const rt = get(id);
  const len = Math.max(6, rt.cycle * 2);
  return play(ac, id, { ramp: true, startGain: 0.12, maxGain: 0.5, rampSeconds: len * 0.7, maxDuration: len, onEnd });
}
