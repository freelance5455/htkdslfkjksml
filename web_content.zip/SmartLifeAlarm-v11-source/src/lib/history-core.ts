// Pure rules for the activity History: record shape, privacy filtering, grouping, filtering and CSV.
export type HistCat = "alarm" | "calendar" | "dayplan" | "account" | "settings" | "data";
export const HIST_CATS: HistCat[] = ["alarm", "calendar", "dayplan", "account", "settings", "data"];
export type HistDetails = Record<string, string | number | boolean>;
export type HistRec = { id: string; ts: number; cat: HistCat; act: string; d: HistDetails; st: string };

export const MAX_HISTORY = 2000;

const SENSITIVE_KEY = /pass|pwd|token|secret|api.?key|access.?key|auth|session|cookie|email|phone|otp|credential/i;
const EMAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const JWT = /\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b/g;
const LONG_TOKEN = /\b[A-Za-z0-9_\-]{32,}\b/g;

/** Strip anything that could be a credential or personal contact detail before it is stored. */
export function sanitizeDetails(d: Record<string, unknown> | undefined | null): HistDetails {
  const out: HistDetails = {};
  if (!d) return out;
  for (const [k, v] of Object.entries(d)) {
    if (v === undefined || v === null || v === "") continue;
    if (SENSITIVE_KEY.test(k)) continue;
    if (typeof v === "number" || typeof v === "boolean") {
      out[k] = v;
      continue;
    }
    if (typeof v !== "string") continue;
    let s = v.replace(JWT, "[hidden]").replace(EMAIL, "[hidden]").replace(LONG_TOKEN, "[hidden]");
    if (s.length > 160) s = s.slice(0, 157) + "…";
    out[k] = s;
  }
  return out;
}

export function makeRecord(
  cat: HistCat,
  act: string,
  details: Record<string, unknown> | undefined,
  status: string,
  now = Date.now(),
  rand = Math.random,
): HistRec {
  return {
    id: now.toString(36) + "-" + Math.floor(rand() * 1e9).toString(36),
    ts: now,
    cat,
    act,
    d: sanitizeDetails(details),
    st: String(status || "").slice(0, 40),
  };
}

/** Newest first, capped so storage stays small. */
export function addRecord(list: HistRec[], rec: HistRec, max = MAX_HISTORY): HistRec[] {
  const next = [rec, ...list.filter((r) => r.id !== rec.id)];
  next.sort((a, b) => b.ts - a.ts);
  return next.length > max ? next.slice(0, max) : next;
}

const startOfDay = (ts: number) => {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

export type Bucket = "today" | "yesterday" | "earlier";
/** Bucket by the user's local calendar day. */
export function dayBucket(ts: number, now = Date.now()): Bucket {
  const today = startOfDay(now);
  const y = new Date(today);
  y.setDate(y.getDate() - 1);
  if (ts >= today) return "today";
  if (ts >= y.getTime()) return "yesterday";
  return "earlier";
}

export type HistFilter = { q?: string; cat?: HistCat | "all"; range?: "all" | "today" | "yesterday" | "7d" | "30d" | "date"; date?: string };

const ymdLocal = (ts: number) => {
  const d = new Date(ts);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
};

export function filterHistory(list: HistRec[], f: HistFilter, textOf: (r: HistRec) => string, now = Date.now()): HistRec[] {
  const q = (f.q || "").trim().toLowerCase();
  const today = startOfDay(now);
  return list.filter((r) => {
    if (f.cat && f.cat !== "all" && r.cat !== f.cat) return false;
    switch (f.range) {
      case "today":
        if (dayBucket(r.ts, now) !== "today") return false;
        break;
      case "yesterday":
        if (dayBucket(r.ts, now) !== "yesterday") return false;
        break;
      case "7d":
        if (r.ts < today - 6 * 86400000) return false;
        break;
      case "30d":
        if (r.ts < today - 29 * 86400000) return false;
        break;
      case "date":
        if (f.date && ymdLocal(r.ts) !== f.date) return false;
        break;
    }
    if (q && !textOf(r).toLowerCase().includes(q)) return false;
    return true;
  });
}

export function groupHistory(list: HistRec[], now = Date.now()): { bucket: Bucket; items: HistRec[] }[] {
  const order: Bucket[] = ["today", "yesterday", "earlier"];
  const sorted = [...list].sort((a, b) => b.ts - a.ts);
  return order
    .map((bucket) => ({ bucket, items: sorted.filter((r) => dayBucket(r.ts, now) === bucket) }))
    .filter((g) => g.items.length > 0);
}

/** One CSV cell: quoted, and protected from spreadsheet formula injection. */
export function csvCell(v: unknown): string {
  let s = String(v ?? "");
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}

export function toCSV(
  list: HistRec[],
  fmt: { activity: (r: HistRec) => string; category: (r: HistRec) => string; details: (r: HistRec) => string; status: (r: HistRec) => string },
  tz = Intl.DateTimeFormat().resolvedOptions().timeZone,
): string {
  const head = ["Date", "Time", "Time zone", "Category", "Activity", "Details", "Status"].map(csvCell).join(",");
  const rows = [...list]
    .sort((a, b) => b.ts - a.ts)
    .map((r) => {
      const d = new Date(r.ts);
      return [
        ymdLocal(r.ts),
        d.toLocaleTimeString("en-GB", { hour12: false }),
        tz,
        fmt.category(r),
        fmt.activity(r),
        fmt.details(r),
        fmt.status(r),
      ]
        .map(csvCell)
        .join(",");
    });
  return "\ufeff" + [head, ...rows].join("\r\n");
}

/** Activity names in English and Hindi, keyed by `${category}.${activity}`. */
export const ACT_LABELS: Record<string, [string, string]> = {
  "alarm.created": ["Alarm created", "अलार्म बनाया गया"],
  "alarm.edited": ["Alarm edited", "अलार्म बदला गया"],
  "alarm.deleted": ["Alarm deleted", "अलार्म हटाया गया"],
  "alarm.enabled": ["Alarm turned on", "अलार्म चालू किया"],
  "alarm.disabled": ["Alarm turned off", "अलार्म बंद किया"],
  "alarm.ringing": ["Alarm ringing", "अलार्म बज रहा था"],
  "alarm.completed": ["Alarm completed", "अलार्म पूरा हुआ"],
  "alarm.dismissed": ["Alarm dismissed", "अलार्म बंद किया गया"],
  "alarm.snoozed": ["Alarm snoozed", "अलार्म स्नूज़ हुआ"],
  "alarm.missed": ["Alarm missed", "अलार्म छूट गया"],
  "calendar.created": ["Calendar reminder created", "कैलेंडर रिमाइंडर बनाया"],
  "calendar.edited": ["Calendar reminder edited", "कैलेंडर रिमाइंडर बदला"],
  "calendar.deleted": ["Calendar reminder deleted", "कैलेंडर रिमाइंडर हटाया"],
  "calendar.done": ["Calendar reminder marked done", "कैलेंडर रिमाइंडर पूरा किया"],
  "calendar.undone": ["Calendar reminder marked not done", "कैलेंडर रिमाइंडर फिर से बाकी"],
  "calendar.highlighted": ["Calendar date highlighted", "कैलेंडर में तारीख हाइलाइट की"],
  "calendar.highlight_edited": ["Date highlight changed", "तारीख की हाइलाइट बदली"],
  "calendar.unhighlighted": ["Date highlight removed", "तारीख की हाइलाइट हटाई"],
  "dayplan.timetable_created": ["Timetable created", "टाइमटेबल बनाया गया"],
  "dayplan.timetable_deleted": ["Timetable deleted", "टाइमटेबल हटाया गया"],
  "dayplan.block_created": ["Day Plan block added", "दिन की योजना में ब्लॉक जोड़ा"],
  "dayplan.block_edited": ["Day Plan block edited", "दिन की योजना का ब्लॉक बदला"],
  "dayplan.block_deleted": ["Day Plan block deleted", "दिन की योजना का ब्लॉक हटाया"],
  "dayplan.block_done": ["Day Plan block completed", "ब्लॉक पूरा किया"],
  "dayplan.block_undone": ["Day Plan block reopened", "ब्लॉक फिर से बाकी"],
  "dayplan.alarms_synced": ["Day Plan alarms synced", "दिन की योजना के अलार्म सिंक"],
  "account.login": ["Signed in", "साइन इन किया"],
  "account.logout": ["Signed out", "साइन आउट किया"],
  "account.restored": ["Cloud backup restored", "क्लाउड बैकअप वापस आया"],
  "settings.language": ["Language changed", "भाषा बदली गई"],
  "settings.theme": ["Theme changed", "थीम बदली गई"],
  "settings.time_format": ["Time format changed", "समय का फ़ॉर्मैट बदला"],
  "settings.ringtone": ["Default ringtone changed", "डिफ़ॉल्ट रिंगटोन बदली"],
  "settings.vibration": ["Vibration setting changed", "वाइब्रेशन सेटिंग बदली"],
  "settings.ramp": ["Gradual volume setting changed", "धीरे-धीरे आवाज़ सेटिंग बदली"],
  "settings.notifications": ["Notification permission changed", "नोटिफ़िकेशन अनुमति बदली"],
  "data.reset": ["Data reset", "डेटा रीसेट"],
  "data.backup_exported": ["Backup file downloaded", "बैकअप फ़ाइल डाउनलोड"],
  "data.backup_restored": ["Backup file restored", "बैकअप फ़ाइल रीस्टोर"],
  "data.history_cleared": ["History cleared", "इतिहास साफ़ किया"],
};

export const CAT_LABELS: Record<HistCat, [string, string, string]> = {
  alarm: ["⏰", "Alarms", "अलार्म"],
  calendar: ["📅", "Calendar", "कैलेंडर"],
  dayplan: ["🗓️", "Day Plan", "दिन की योजना"],
  account: ["👤", "Account", "अकाउंट"],
  settings: ["⚙️", "Settings", "सेटिंग्स"],
  data: ["🗂️", "Data", "डेटा"],
};

export function activityLabel(r: HistRec, hi = false): string {
  const l = ACT_LABELS[r.cat + "." + r.act];
  return l ? l[hi ? 1 : 0] : r.act;
}
