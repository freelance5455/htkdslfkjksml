import { describe, expect, it } from "vitest";
import { DEFAULT_ID, LIST, has, rampGainAt } from "./ringtones";

describe("ringtones", () => {
  it("offers several choices with a soothing default", () => {
    expect(LIST.length).toBeGreaterThanOrEqual(5);
    expect(has(DEFAULT_ID)).toBe(true);
  });
  it("volume rises gradually from quiet to the comfortable maximum", () => {
    const o = { startGain: 0.07, maxGain: 0.6, rampSeconds: 40 };
    expect(rampGainAt(0, o)).toBeCloseTo(0.07);
    expect(rampGainAt(20, o)).toBeCloseTo(0.335);
    expect(rampGainAt(60, o)).toBeCloseTo(0.6);
  });
});
