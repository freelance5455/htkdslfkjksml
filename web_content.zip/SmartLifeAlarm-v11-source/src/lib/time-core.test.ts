import { describe, expect, it } from "vitest";
import { composeTime, formatTime, meridiem, setMeridiem, snoozeUntil } from "./time-core";

describe("clock time format", () => {
  it("shows AM/PM in 12-hour mode", () => {
    expect(formatTime("20:05")).toBe("8:05 PM");
    expect(formatTime("00:00")).toBe("12:00 AM");
    expect(formatTime("12:30")).toBe("12:30 PM");
    expect(formatTime("07:09", false)).toBe("7:09 AM");
  });

  it("shows plain 24-hour time without AM/PM in 24-hour mode", () => {
    expect(formatTime("20:05", true)).toBe("20:05");
    expect(formatTime("7:09", true)).toBe("07:09");
    expect(formatTime("00:00", true)).toBe("00:00");
  });
});

describe("AM/PM switch", () => {
  it("knows which half of the day a time is in", () => {
    expect(meridiem("11:59")).toBe("AM");
    expect(meridiem("12:00")).toBe("PM");
    expect(meridiem("bad")).toBeNull();
  });

  it("flips the same clock time between morning and evening", () => {
    expect(setMeridiem("07:30", "PM")).toBe("19:30");
    expect(setMeridiem("19:30", "AM")).toBe("07:30");
    expect(setMeridiem("12:15", "AM")).toBe("00:15");
    expect(setMeridiem("00:15", "PM")).toBe("12:15");
    expect(setMeridiem("19:30", "PM")).toBe("19:30");
  });

  it("starts from 12 o'clock when the field is empty", () => {
    expect(setMeridiem("", "AM")).toBe("00:00");
    expect(setMeridiem("", "PM")).toBe("12:00");
  });
});

describe("v11 time picker and snooze", () => {
  it("turns 12-hour picker choices into the right 24-hour time", () => {
    expect(composeTime(12, 0, false, false)).toBe("00:00"); // 12:00 AM is midnight
    expect(composeTime(12, 30, false, true)).toBe("12:30"); // 12:30 PM is noon
    expect(composeTime(8, 5, false, true)).toBe("20:05");
    expect(composeTime(8, 5, false, false)).toBe("08:05");
  });

  it("uses the hour as-is in 24-hour mode", () => {
    expect(composeTime(23, 59, true, false)).toBe("23:59");
    expect(composeTime(0, 7, true, true)).toBe("00:07");
  });

  it("puts a snooze that passes midnight on the next day", () => {
    const at = new Date(2026, 10, 15, 23, 58).getTime();
    expect(snoozeUntil(at, 5)).toBe("2026-11-16 00:03");
    expect(snoozeUntil(new Date(2026, 10, 15, 7, 0).getTime(), 10)).toBe("2026-11-15 07:10");
  });
});
