// Pure rules for calendar date highlights: one highlight per local date (YYYY-MM-DD).
export type MarkColor = "gold" | "sage" | "claret" | "slate" | "plum";
export type Mark = { c: MarkColor; n: string; ts: number };
export type Marks = Record<string, Mark>;

/** Colour id → [English name, Hindi name]. The order is the order shown in the picker. */
export const MARK_COLORS: Record<MarkColor, [string, string]> = {
  gold: ["Gold", "सुनहरा"],
  sage: ["Sage", "हरा"],
  claret: ["Claret", "लाल"],
  slate: ["Slate", "नीला"],
  plum: ["Plum", "बैंगनी"],
};
export const MARK_COLOR_IDS = Object.keys(MARK_COLORS) as MarkColor[];
export const DEFAULT_MARK_COLOR: MarkColor = "gold";
export const MAX_LABEL = 40;

const DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;

/** True only for a real calendar date written as YYYY-MM-DD. */
export function isDateKey(k: unknown): k is string {
  if (typeof k !== "string") return false;
  const m = DATE_RE.exec(k);
  if (!m) return false;
  const y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
  if (mo < 1 || mo > 12 || d < 1) return false;
  return d <= new Date(Date.UTC(y, mo, 0)).getUTCDate();
}

/** Clean user input: trims and caps the label, falls back to the default colour. Returns null if unusable. */
export function normalizeMark(input: unknown, now = Date.now()): Mark | null {
  if (!input || typeof input !== "object") return null;
  const o = input as Record<string, unknown>;
  const rawC = o["c"] as MarkColor;
  const c = MARK_COLOR_IDS.includes(rawC) ? rawC : DEFAULT_MARK_COLOR;
  const rawN = o["n"], rawTs = o["ts"];
  const n = typeof rawN === "string" ? rawN.replace(/\s+/g, " ").trim().slice(0, MAX_LABEL) : "";
  const ts = typeof rawTs === "number" && isFinite(rawTs) ? rawTs : now;
  return { c, n, ts };
}

/** Returns a new map with the date highlighted (replacing any earlier highlight on that date). */
export function setMark(marks: Marks, date: string, input: { c?: string; n?: string }, now = Date.now()): Marks {
  if (!isDateKey(date)) return marks;
  const m = normalizeMark({ ...input, ts: now }, now);
  if (!m) return marks;
  return { ...marks, [date]: m };
}

/** Returns a new map without the date's highlight. */
export function removeMark(marks: Marks, date: string): Marks {
  if (!(date in marks)) return marks;
  const next = { ...marks };
  delete next[date];
  return next;
}

/** Highlights inside one month (month is 0-based), sorted by date. */
export function marksInMonth(marks: Marks, year: number, month: number): [string, Mark][] {
  const prefix = `${year}-${String(month + 1).padStart(2, "0")}-`;
  return Object.entries(marks)
    .filter(([k]) => k.startsWith(prefix))
    .sort(([a], [b]) => a.localeCompare(b));
}

/** Parse stored data, keeping only valid dates and highlights. */
export function loadMarks(raw: unknown): Marks {
  const out: Marks = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return out;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (!isDateKey(k)) continue;
    const m = normalizeMark(v);
    if (m) out[k] = m;
  }
  return out;
}
