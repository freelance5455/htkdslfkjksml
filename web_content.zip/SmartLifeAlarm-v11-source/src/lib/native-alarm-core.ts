/** Rules for the Android shell: which alarms are sent to the phone's own alarm system, and how
 * events from the phone (alarm rang / stopped / snoozed while the app was closed) change app data.
 * Pure functions so they can be tested without a phone. */

export type WebAlarm = {
  id: number | string;
  t: string; // "HH:MM" 24-hour
  days?: number; // bit i = weekday i (0 = Sunday); 0/undefined = one-time
  date?: string; // "YYYY-MM-DD" for one-time alarms
  en?: boolean;
  snz?: string | null; // "YYYY-MM-DD HH:MM" while snoozed
  task?: string;
  lang?: string;
  vo?: boolean | undefined;
  done?: string;
  last?: string;
  cal?: boolean;
  pid?: number | string;
};

export type NativeAlarm = {
  id: string;
  t: string;
  days: number;
  date: string;
  en: boolean;
  snz: string;
  task: string;
  lang: string;
  vo: boolean;
};

export type NativeEvent = {
  id: string;
  action: "fired" | "done" | "snooze" | "missed";
  at: number; // epoch ms when it happened on the phone
  snooze?: number; // minutes, for action "snooze"
};

export type HistoryLog = {
  cat: "alarm" | "calendar";
  act: string;
  data: Record<string, unknown>;
  status: string;
};

const pad = (n: number) => String(n).padStart(2, "0");

export const ymd = (ms: number) => {
  const d = new Date(ms);
  return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
};
const hm = (ms: number) => {
  const d = new Date(ms);
  return pad(d.getHours()) + ":" + pad(d.getMinutes());
};

const validTime = (t: unknown): t is string => {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(t ?? ""));
  return !!m && Number(m[1]) <= 23 && Number(m[2]) <= 59;
};

/** The list the phone's alarm system needs. Invalid records are skipped instead of crashing the sync. */
export function toNativeAlarms(list: WebAlarm[]): NativeAlarm[] {
  const out: NativeAlarm[] = [];
  for (const a of Array.isArray(list) ? list : []) {
    if (!a || a.id === undefined || a.id === null || !validTime(a.t)) continue;
    out.push({
      id: String(a.id),
      t: a.t.length === 4 ? "0" + a.t : a.t,
      days: Number(a.days) > 0 ? Number(a.days) & 127 : 0,
      date: /^\d{4}-\d{2}-\d{2}$/.test(String(a.date ?? "")) ? String(a.date) : "",
      en: !!a.en,
      snz: /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(String(a.snz ?? "")) ? String(a.snz) : "",
      task: String(a.task ?? "").slice(0, 300),
      lang: a.lang === "en-US" || a.lang === "hi-IN" ? a.lang : String(a.lang || "hi-IN"),
      vo: a.vo !== false,
    });
  }
  return out;
}

/** Apply one phone event to the matching alarm (mutates it, like the app's own end()/start()).
 * Returns what to write to History, and a planner id to tick off when the alarm was completed. */
export function applyNativeEvent(
  alarms: WebAlarm[],
  ev: NativeEvent,
): { known: boolean; log?: HistoryLog; planId?: number | string | undefined } {
  const a = (Array.isArray(alarms) ? alarms : []).find((x) => String(x.id) === String(ev?.id));
  if (!a) return { known: false };
  const cat = a.cal ? "calendar" : "alarm";
  const data = { task: a.task, time: a.t } as Record<string, unknown>;
  switch (ev.action) {
    case "fired":
      a.last = a.snz || ymd(ev.at) + " " + a.t;
      a.snz = null;
      if (!a.days) a.en = false;
      return { known: true, log: { cat: "alarm", act: "ringing", data, status: "Ringing" } };
    case "done":
      a.done = ymd(ev.at);
      return {
        known: true,
        planId: a.pid,
        log: { cat, act: "completed", data, status: "Completed" },
      };
    case "snooze": {
      const mins = Math.max(1, Math.min(120, Math.round(Number(ev.snooze) || 5)));
      const when = ev.at + mins * 60000;
      a.snz = ymd(when) + " " + hm(when);
      a.en = true;
      return {
        known: true,
        log: { cat, act: "snoozed", data: { ...data, snooze: mins }, status: "Snoozed" },
      };
    }
    case "missed":
      return { known: true, log: { cat, act: "missed", data, status: "Missed" } };
    default:
      return { known: true };
  }
}
