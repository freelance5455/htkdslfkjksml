/** Clock display rules for Smart Life Alarm: 12-hour (AM/PM) or 24-hour, plus the AM/PM switch used in time fields. */
export type Meridiem = "AM" | "PM";

const pad = (n: number) => String(n).padStart(2, "0");

/** Split "HH:MM" into numbers; returns null for anything that is not a real 24-hour time. */
export function parseTime(hhmm: string): { h: number; m: number } | null {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(hhmm ?? ""));
  if (!m) return null;
  const h = Number(m[1]);
  const min = Number(m[2]);
  if (h > 23 || min > 59) return null;
  return { h, m: min };
}

/** "20:05" → "8:05 PM" in 12-hour mode, "20:05" in 24-hour mode. */
export function formatTime(hhmm: string, h24 = false): string {
  const t = parseTime(hhmm);
  if (!t) return String(hhmm ?? "");
  if (h24) return pad(t.h) + ":" + pad(t.m);
  return (t.h % 12 || 12) + ":" + pad(t.m) + " " + (t.h < 12 ? "AM" : "PM");
}

export function meridiem(hhmm: string): Meridiem | null {
  const t = parseTime(hhmm);
  return t ? (t.h < 12 ? "AM" : "PM") : null;
}

/** Move a time into the morning or evening half without changing the clock face: 07:30 → PM → 19:30. */
export function setMeridiem(hhmm: string, to: Meridiem): string {
  const t = parseTime(hhmm) ?? { h: 12, m: 0 };
  let h = t.h % 12;
  if (to === "PM") h += 12;
  return pad(h) + ":" + pad(t.m);
}

/** Time picker (hour list + minute list + AM/PM) → "HH:MM". In 12-hour mode the hour list shows 1–12. */
export function composeTime(hour: number, minute: number, h24: boolean, pm: boolean): string {
  const m = Math.max(0, Math.min(59, Math.floor(minute)));
  let h = Math.floor(hour);
  if (h24) h = Math.max(0, Math.min(23, h));
  else h = (Math.max(1, Math.min(12, h)) % 12) + (pm ? 12 : 0);
  return pad(h) + ":" + pad(m);
}

/** "YYYY-MM-DD HH:MM" for a snooze that ends `mins` minutes after `nowMs` — on the right date, even past midnight. */
export function snoozeUntil(nowMs: number, mins: number): string {
  const d = new Date(nowMs + mins * 60000);
  return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());
}
