import { describe, expect, it } from "vitest";
import { isDateKey, loadMarks, marksInMonth, normalizeMark, removeMark, setMark, MAX_LABEL } from "./marks-core";

describe("calendar date highlights", () => {
  it("accepts only real calendar dates", () => {
    expect(isDateKey("2026-02-28")).toBe(true);
    expect(isDateKey("2026-02-29")).toBe(false);
    expect(isDateKey("2028-02-29")).toBe(true);
    expect(isDateKey("2026-13-01")).toBe(false);
    expect(isDateKey("13/11/2026")).toBe(false);
  });

  it("highlights a date with the chosen colour and a trimmed label", () => {
    const m = setMark({}, "2026-11-14", { c: "claret", n: "  Maa ka   birthday " }, 1000);
    expect(m["2026-11-14"]).toEqual({ c: "claret", n: "Maa ka birthday", ts: 1000 });
  });

  it("falls back to gold for an unknown colour and caps the label length", () => {
    const m = normalizeMark({ c: "neon", n: "x".repeat(100) }, 5)!;
    expect(m.c).toBe("gold");
    expect(m.n.length).toBe(MAX_LABEL);
  });

  it("keeps one highlight per date: highlighting again replaces it", () => {
    let m = setMark({}, "2026-11-14", { c: "gold" }, 1);
    m = setMark(m, "2026-11-14", { c: "sage", n: "Exam" }, 2);
    expect(Object.keys(m)).toEqual(["2026-11-14"]);
    expect(m["2026-11-14"]?.c).toBe("sage");
  });

  it("removes a highlight without touching other dates", () => {
    const m = setMark(setMark({}, "2026-11-14", { c: "gold" }), "2026-11-20", { c: "plum" });
    const r = removeMark(m, "2026-11-14");
    expect(Object.keys(r)).toEqual(["2026-11-20"]);
    expect(Object.keys(m)).toHaveLength(2);
  });

  it("ignores invalid dates", () => {
    expect(setMark({}, "2026-11-31", { c: "gold" })).toEqual({});
  });

  it("lists a month's highlights in date order", () => {
    let m = setMark({}, "2026-11-20", { c: "gold" });
    m = setMark(m, "2026-11-03", { c: "sage" });
    m = setMark(m, "2026-12-01", { c: "slate" });
    expect(marksInMonth(m, 2026, 10).map(([k]) => k)).toEqual(["2026-11-03", "2026-11-20"]);
  });

  it("drops corrupt stored entries when loading", () => {
    const m = loadMarks({ "2026-11-14": { c: "gold", n: "ok", ts: 1 }, bad: { c: "gold" }, "2026-11-15": "x" });
    expect(Object.keys(m)).toEqual(["2026-11-14"]);
  });
});
