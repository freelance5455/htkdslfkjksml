/** App themes. Colours live in src/legacy/app.css under [data-theme=<id>]; this list is the source of truth for ids and names. */
export type ThemeInfo = {
  en: string;
  hi: string;
  descEn: string;
  descHi: string;
  /** Browser/status-bar colour for <meta name="theme-color">. */
  color: string;
  tagEn?: string;
  tagHi?: string;
};

export const THEME_IDS = [
  "ivory", "night", "rose", "ocean", "sapphire", "maroon", "aurora",
  "saffron", "emerald", "sakura", "neon", "diwali",
  "mocha", "frost", "sunset", "rajasthan", "cosmos",
] as const;
export type ThemeId = (typeof THEME_IDS)[number];
export const DEFAULT_THEME: ThemeId = "ivory";

export const THEMES: Record<ThemeId, ThemeInfo> = {
  ivory: { en: "Classic Ivory", hi: "क्लासिक आइवरी", descEn: "Warm paper tones with olive and brass", descHi: "गर्म कागज़ी रंग, ऑलिव और पीतल", color: "#f1e9d8" },
  night: { en: "Olive Night", hi: "ऑलिव नाइट", descEn: "Deep olive surfaces with soft gold", descHi: "गहरा ऑलिव रंग, हल्का सुनहरा", color: "#111411" },
  rose: { en: "Rose Garden", hi: "रोज़ गार्डन", descEn: "Soft blush pages with deep rose and copper", descHi: "हल्का गुलाबी रंग, गहरा गुलाब और तांबा", color: "#f7e8e6", tagEn: "New", tagHi: "नया" },
  ocean: { en: "Ocean Breeze", hi: "ओशन ब्रीज़", descEn: "Cool sea-glass teal with a coral glow", descHi: "ठंडा समुद्री नीला-हरा, कोरल चमक के साथ", color: "#e6f1f1", tagEn: "Fresh", tagHi: "ताज़ा" },
  sapphire: { en: "Midnight Sapphire", hi: "मिडनाइट सफ़ायर", descEn: "Deep navy night sky with twinkling stars", descHi: "गहरा नीला रात का आसमान, टिमटिमाते तारे", color: "#0a1020", tagEn: "Live stars", tagHi: "चमकते तारे" },
  maroon: { en: "Royal Maroon", hi: "रॉयल मैरून", descEn: "Rich wine red with a palace-gold finish", descHi: "गहरा मैरून, शाही सुनहरी चमक", color: "#1d0b10", tagEn: "Royal", tagHi: "शाही" },
  aurora: { en: "Aurora Glow", hi: "ऑरोरा ग्लो", descEn: "Moving northern lights behind frosted glass", descHi: "चलती उत्तरी रोशनी और काँच जैसा लुक", color: "#05070d", tagEn: "Signature · Animated", tagHi: "सबसे ख़ास · एनिमेटेड" },
  saffron: { en: "Saffron Sunrise", hi: "केसरिया सूर्योदय", descEn: "Warm saffron and marigold with a rising sun", descHi: "केसरिया और गेंदे जैसा रंग, उगता सूरज", color: "#fbeedd", tagEn: "Sunrise", tagHi: "सूर्योदय" },
  emerald: { en: "Emerald Forest", hi: "एमरल्ड फ़ॉरेस्ट", descEn: "Deep forest green with drifting fireflies", descHi: "गहरा जंगल-हरा रंग, उड़ते जुगनू", color: "#0a1812", tagEn: "Fireflies", tagHi: "जुगनू" },
  sakura: { en: "Sakura Bloom", hi: "सकुरा ब्लूम", descEn: "Cherry-blossom pink with falling petals", descHi: "चेरी फूलों जैसा गुलाबी, गिरती पंखुड़ियाँ", color: "#fdf0f3", tagEn: "Falling petals", tagHi: "गिरती पंखुड़ियाँ" },
  neon: { en: "Neon City", hi: "नियॉन सिटी", descEn: "Glowing neon lights on a moving cyber grid", descHi: "चमकती नियॉन रोशनी, चलती साइबर ग्रिड", color: "#07060d", tagEn: "Glow · Animated", tagHi: "चमक · एनिमेटेड" },
  diwali: { en: "Diwali Utsav", hi: "दीवाली उत्सव", descEn: "Golden diya sparks, a turning rangoli and shimmering gold", descHi: "सुनहरी दीया चिंगारियाँ, घूमती रंगोली और चमकता सोना", color: "#140a1f", tagEn: "Grand · Best", tagHi: "सबसे भव्य" },
  mocha: { en: "Coffee Mocha", hi: "कॉफ़ी मोका", descEn: "Creamy latte pages with espresso and caramel", descHi: "क्रीमी लाटे रंग, एस्प्रेसो और कैरामेल", color: "#f3e8dc", tagEn: "New · Cozy", tagHi: "नया · सुकून" },
  frost: { en: "Arctic Frost", hi: "आर्कटिक फ़्रॉस्ट", descEn: "Icy white and glacier blue with drifting snow", descHi: "बर्फ़ीला सफ़ेद और ग्लेशियर नीला, गिरती बर्फ़", color: "#e9f1f8", tagEn: "New · Snow", tagHi: "नया · बर्फ़" },
  sunset: { en: "Sunset Lagoon", hi: "सनसेट लैगून", descEn: "Glowing orange-pink sunset over a dark lagoon", descHi: "गहरे पानी पर चमकता नारंगी-गुलाबी सूर्यास्त", color: "#1b0f1c", tagEn: "New · Glow", tagHi: "नया · चमक" },
  rajasthan: { en: "Royal Rajasthan", hi: "रॉयल राजस्थान", descEn: "Desert sand, terracotta and Jaipur blue pottery", descHi: "रेगिस्तानी रेत, टेराकोटा और जयपुर ब्लू पॉटरी", color: "#f4e3c6", tagEn: "New · Desi", tagHi: "नया · देसी" },
  cosmos: { en: "Galaxy Cosmos", hi: "गैलेक्सी कॉसमॉस", descEn: "Deep space, a swirling nebula and shooting stars", descHi: "गहरा अंतरिक्ष, घूमता नेबुला और टूटते तारे", color: "#070516", tagEn: "New · Animated", tagHi: "नया · एनिमेटेड" },
};

export const isTheme = (id: unknown): id is ThemeId => typeof id === "string" && (THEME_IDS as readonly string[]).includes(id);

/** Unknown or missing ids (old backups, typos) fall back to the default theme. */
export const resolveTheme = (id: unknown): ThemeId => (isTheme(id) ? id : DEFAULT_THEME);
