import { describe, expect, it } from "vitest";
import { applyNativeEvent, toNativeAlarms, type WebAlarm } from "./native-alarm-core";

const base = (o: Partial<WebAlarm> = {}): WebAlarm => ({
  id: 1,
  t: "07:30",
  days: 0,
  date: "2026-11-16",
  en: true,
  task: "Wake up",
  lang: "hi-IN",
  ...o,
});
const at = (s: string) => new Date(s).getTime(); // local time

describe("toNativeAlarms", () => {
  it("keeps valid alarms and skips broken ones", () => {
    const r = toNativeAlarms([base(), { id: 2, t: "25:99" } as WebAlarm, null as never, { t: "08:00" } as WebAlarm]);
    expect(r).toHaveLength(1);
    expect(r[0]).toMatchObject({ id: "1", t: "07:30", days: 0, en: true, vo: true, snz: "" });
  });
  it("pads single-digit hours and defaults voice on", () => {
    expect(toNativeAlarms([base({ t: "7:05", vo: undefined })])[0]).toMatchObject({ t: "07:05", vo: true });
    expect(toNativeAlarms([base({ vo: false })])[0]?.vo).toBe(false);
  });
  it("passes weekday masks and snooze strings, drops malformed ones", () => {
    const r = toNativeAlarms([base({ days: 62, snz: "2026-11-16 07:35" }), base({ id: 3, snz: "soon" })]);
    expect(r[0]).toMatchObject({ days: 62, snz: "2026-11-16 07:35" });
    expect(r[1]?.snz).toBe("");
  });
});

describe("applyNativeEvent", () => {
  it("ignores events for alarms that no longer exist", () => {
    expect(applyNativeEvent([base()], { id: "99", action: "done", at: 0 }).known).toBe(false);
  });
  it("fired: one-time alarm switches itself off, repeating one stays on", () => {
    const one = base();
    const rep = base({ id: 2, days: 127 });
    applyNativeEvent([one, rep], { id: "1", action: "fired", at: at("2026-11-16T07:30:05") });
    applyNativeEvent([one, rep], { id: "2", action: "fired", at: at("2026-11-16T07:30:05") });
    expect(one.en).toBe(false);
    expect(one.last).toBe("2026-11-16 07:30");
    expect(rep.en).toBe(true);
  });
  it("fired after a snooze uses the snooze key and clears it", () => {
    const a = base({ days: 127, snz: "2026-11-16 07:35" });
    applyNativeEvent([a], { id: "1", action: "fired", at: at("2026-11-16T07:35:01") });
    expect(a.last).toBe("2026-11-16 07:35");
    expect(a.snz).toBeNull();
  });
  it("done: marks today done and reports the planner link", () => {
    const a = base({ pid: 55, cal: true });
    const r = applyNativeEvent([a], { id: "1", action: "done", at: at("2026-11-16T07:31:00") });
    expect(a.done).toBe("2026-11-16");
    expect(r.planId).toBe(55);
    expect(r.log).toMatchObject({ cat: "calendar", status: "Completed" });
  });
  it("snooze: sets a new time and re-enables a one-time alarm", () => {
    const a = base({ en: false });
    const r = applyNativeEvent([a], { id: "1", action: "snooze", at: at("2026-11-16T07:58:00"), snooze: 5 });
    expect(a.snz).toBe("2026-11-16 08:03");
    expect(a.en).toBe(true);
    expect(r.log?.data["snooze"]).toBe(5);
  });
  it("snooze past midnight rolls over to the next date", () => {
    const a = base();
    applyNativeEvent([a], { id: "1", action: "snooze", at: at("2026-11-16T23:57:00"), snooze: 10 });
    expect(a.snz).toBe("2026-11-17 00:07");
  });
  it("missed only logs", () => {
    const a = base();
    const r = applyNativeEvent([a], { id: "1", action: "missed", at: 0 });
    expect(r.log?.status).toBe("Missed");
    expect(a.done).toBeUndefined();
  });
});
