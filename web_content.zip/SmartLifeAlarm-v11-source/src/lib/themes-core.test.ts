import { describe, expect, it } from "vitest";
import { resolveTheme, THEME_IDS, THEMES } from "./themes-core";

describe("app themes", () => {
  it("offers the two classic themes plus fifteen newer ones (v11 adds five)", () => {
    expect(THEME_IDS).toEqual([
      "ivory", "night", "rose", "ocean", "sapphire", "maroon", "aurora",
      "saffron", "emerald", "sakura", "neon", "diwali",
      "mocha", "frost", "sunset", "rajasthan", "cosmos",
    ]);
    expect(THEME_IDS.length).toBe(17);
  });

  it("gives every theme an English and Hindi name", () => {
    for (const id of THEME_IDS) {
      expect(THEMES[id].en.length).toBeGreaterThan(0);
      expect(THEMES[id].hi.length).toBeGreaterThan(0);
    }
  });

  it("keeps a saved theme and falls back to Classic Ivory for unknown ones", () => {
    expect(resolveTheme("aurora")).toBe("aurora");
    expect(resolveTheme("night")).toBe("night");
    expect(resolveTheme("purple")).toBe("ivory");
    expect(resolveTheme(undefined)).toBe("ivory");
  });
});
