import { describe, expect, it } from "vitest";
import {
  CLOCK_STYLE_IDS, CLOCK_THEME_IDS, CLOCK_THEMES, CLOCK_STYLES, clockSVG, handAngles, orbitFractions,
  resolveClockStyle, resolveClockTheme, toHindiDigits, ledCount,
} from "./clock-core";

describe("clock themes and styles", () => {
  it("offers fifteen clock colour themes plus 'match app theme'", () => {
    expect(CLOCK_THEME_IDS[0]).toBe("auto");
    expect(CLOCK_THEME_IDS.filter((id) => id !== "auto").length).toBe(15);
  });

  it("offers ten clock styles (five added in v11)", () => {
    expect(CLOCK_STYLE_IDS.length).toBe(10);
    expect(CLOCK_STYLE_IDS.slice(5)).toEqual(["romanfull", "railway", "diver", "dots", "digital"]);
  });

  it("draws the new styles", () => {
    expect(clockSVG("romanfull")).toContain(">VII<");
    expect(clockSVG("digital").match(/class="dg-seg"/g)?.length).toBe(60);
    expect(clockSVG("digital")).not.toContain("ck-hh");
    expect(clockSVG("railway")).toContain("rw-pop");
    expect(clockSVG("diver")).toContain(">30<");
  });

  it("lights one more LED every second", () => {
    expect(ledCount(0)).toBe(1);
    expect(ledCount(59)).toBe(60);
  });

  it("names every clock theme and style in English and Hindi", () => {
    for (const id of CLOCK_THEME_IDS) expect(CLOCK_THEMES[id].en && CLOCK_THEMES[id].hi).toBeTruthy();
    for (const id of CLOCK_STYLE_IDS) expect(CLOCK_STYLES[id].en && CLOCK_STYLES[id].hi).toBeTruthy();
  });

  it("keeps saved choices and falls back for unknown ones", () => {
    expect(resolveClockTheme("prism")).toBe("prism");
    expect(resolveClockTheme("purple")).toBe("auto");
    expect(resolveClockStyle("orbit")).toBe("orbit");
    expect(resolveClockStyle(undefined)).toBe("roman");
  });

  it("points the hands correctly", () => {
    expect(handAngles(3, 0, 0)).toEqual({ hour: 90, minute: 0, second: 0 });
    expect(handAngles(15, 30, 30)).toEqual({ hour: 105.25, minute: 183, second: 180 });
  });

  it("fills the orbit rings by time", () => {
    expect(orbitFractions(18, 30, 15)).toEqual({ hour: 0.5416666666666666, minute: 30.25 / 60, second: 0.25 });
  });

  it("writes Hindi numerals for the Hindi style", () => {
    expect(toHindiDigits(12)).toBe("१२");
    expect(clockSVG("hindi")).toContain(">९<");
    expect(clockSVG("roman")).toContain(">XII<");
    expect(clockSVG("minimal")).not.toContain("<text");
  });
});
