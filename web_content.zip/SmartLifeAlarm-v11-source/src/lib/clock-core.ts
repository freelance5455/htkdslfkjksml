/**
 * Clock looks for the big clock on the home screen.
 * - Clock themes = colours of the clock face (CSS tokens under [data-ck=<id>] in src/legacy/app.css).
 * - Clock styles = how the face is drawn (numerals, ticks, hands or rings), built here as SVG.
 */
export type ClockInfo = { en: string; hi: string; descEn: string; descHi: string; tagEn?: string; tagHi?: string };

/** "auto" follows the app theme; the other fifteen are fixed clock colour sets (v11 adds one per new app theme). */
export const CLOCK_THEME_IDS = [
  "auto", "gold", "silver", "rosegold", "onyx", "ocean", "emerald", "ruby", "marble", "neon", "prism",
  "mocha", "frost", "sunset", "jaipur", "nebula",
] as const;
export type ClockThemeId = (typeof CLOCK_THEME_IDS)[number];
export const DEFAULT_CLOCK_THEME: ClockThemeId = "auto";

export const CLOCK_THEMES: Record<ClockThemeId, ClockInfo> = {
  auto: { en: "Match app theme", hi: "ऐप थीम जैसा", descEn: "Uses the colours of your app theme", descHi: "आपकी ऐप थीम के रंग" },
  gold: { en: "Royal Gold", hi: "रॉयल गोल्ड", descEn: "Black face with polished gold", descHi: "काला डायल, चमकता सोना" },
  silver: { en: "Steel Silver", hi: "स्टील सिल्वर", descEn: "Brushed steel with a red second hand", descHi: "स्टील डायल, लाल सेकंड सुई" },
  rosegold: { en: "Rose Gold", hi: "रोज़ गोल्ड", descEn: "Blush face with rose-gold hands", descHi: "हल्का गुलाबी डायल, रोज़-गोल्ड सुइयाँ" },
  onyx: { en: "Midnight Onyx", hi: "मिडनाइट ओनिक्स", descEn: "Deep black with bright white and orange", descHi: "गहरा काला, सफ़ेद और नारंगी" },
  ocean: { en: "Deep Ocean", hi: "डीप ओशन", descEn: "Diver-watch blue with aqua markers", descHi: "गहरा समुद्री नीला, एक्वा निशान" },
  emerald: { en: "Emerald Crown", hi: "एमरल्ड क्राउन", descEn: "Rich green dial with gold accents", descHi: "गहरा हरा डायल, सुनहरे निशान" },
  ruby: { en: "Ruby Flame", hi: "रूबी फ़्लेम", descEn: "Glowing ruby red with cream hands", descHi: "चमकता लाल डायल, क्रीम सुइयाँ" },
  marble: { en: "White Marble", hi: "व्हाइट मार्बल", descEn: "Veined marble with black and gold", descHi: "संगमरमर डायल, काला और सुनहरा", tagEn: "Luxury", tagHi: "लग्ज़री" },
  neon: { en: "Neon Pulse", hi: "नियॉन पल्स", descEn: "Glowing cyan and pink light", descHi: "चमकती नीली और गुलाबी रोशनी", tagEn: "Glow", tagHi: "चमक" },
  prism: { en: "Rainbow Prism", hi: "रेनबो प्रिज़्म", descEn: "A turning rainbow ring that shifts colour", descHi: "घूमती इंद्रधनुषी रिंग, बदलते रंग", tagEn: "Animated", tagHi: "एनिमेटेड" },
  mocha: { en: "Espresso Bronze", hi: "एस्प्रेसो ब्रॉन्ज़", descEn: "Dark chocolate dial with warm bronze", descHi: "गहरा चॉकलेटी डायल, गर्म कांस्य रंग", tagEn: "New", tagHi: "नया" },
  frost: { en: "Ice Crystal", hi: "आइस क्रिस्टल", descEn: "Frosted white-blue glass with steel hands", descHi: "बर्फ़ीला सफ़ेद-नीला काँच, स्टील सुइयाँ", tagEn: "New", tagHi: "नया" },
  sunset: { en: "Sunset Glow", hi: "सनसेट ग्लो", descEn: "Orange-to-pink sky with a glowing sun hand", descHi: "नारंगी से गुलाबी आसमान, चमकती सुई", tagEn: "New", tagHi: "नया" },
  jaipur: { en: "Jaipur Blue", hi: "जयपुर ब्लू", descEn: "Blue-pottery dial with terracotta numbers", descHi: "ब्लू पॉटरी डायल, टेराकोटा अंक", tagEn: "Desi", tagHi: "देसी" },
  nebula: { en: "Nebula Stars", hi: "नेबुला स्टार्स", descEn: "Deep space with twinkling star dust", descHi: "गहरा अंतरिक्ष, टिमटिमाती तारों की धूल", tagEn: "Animated", tagHi: "एनिमेटेड" },
};

export const CLOCK_STYLE_IDS = [
  "roman", "arabic", "hindi", "minimal", "orbit",
  "romanfull", "railway", "diver", "dots", "digital",
] as const;
export type ClockStyleId = (typeof CLOCK_STYLE_IDS)[number];
export const DEFAULT_CLOCK_STYLE: ClockStyleId = "roman";

export const CLOCK_STYLES: Record<ClockStyleId, ClockInfo> = {
  roman: { en: "Roman Classic", hi: "रोमन क्लासिक", descEn: "XII · III · VI · IX with fine ticks", descHi: "XII · III · VI · IX, बारीक निशान" },
  arabic: { en: "Modern Numbers", hi: "मॉडर्न नंबर", descEn: "All twelve numbers, clean and clear", descHi: "सभी बारह अंक, साफ़ और स्पष्ट" },
  hindi: { en: "Hindi Numerals", hi: "हिंदी अंक", descEn: "१ to १२ in Devanagari numerals", descHi: "१ से १२ तक देवनागरी अंक", tagEn: "Desi", tagHi: "देसी" },
  minimal: { en: "Minimal", hi: "मिनिमल", descEn: "No numbers, bold markers, slim hands", descHi: "अंक नहीं, मोटे निशान, पतली सुइयाँ" },
  orbit: { en: "Digital Orbit", hi: "डिजिटल ऑर्बिट", descEn: "Hour, minute and second rings with digital time", descHi: "घंटे, मिनट, सेकंड की रिंग और डिजिटल समय", tagEn: "Live rings", tagHi: "चलती रिंग" },
  romanfull: { en: "Royal Roman", hi: "रॉयल रोमन", descEn: "All twelve Roman numerals, palace style", descHi: "सभी बारह रोमन अंक, महल जैसा", tagEn: "New", tagHi: "नया" },
  railway: { en: "Station Clock", hi: "स्टेशन घड़ी", descEn: "Bold bars and a red lollipop second hand", descHi: "मोटे निशान और लाल गोल सेकंड सुई", tagEn: "New", tagHi: "नया" },
  diver: { en: "Diver Pro", hi: "डाइवर प्रो", descEn: "Sports bezel with 15 · 30 · 45 and glowing dots", descHi: "स्पोर्ट्स बेज़ल, 15 · 30 · 45 और चमकते बिंदु", tagEn: "New", tagHi: "नया" },
  dots: { en: "Pearl Dots", hi: "पर्ल डॉट्स", descEn: "Soft pearl dots instead of numbers", descHi: "अंकों की जगह मोती जैसे बिंदु", tagEn: "New", tagHi: "नया" },
  digital: { en: "Digital LED", hi: "डिजिटल LED", descEn: "Big digital time with a 60-light seconds ring", descHi: "बड़ा डिजिटल समय, 60 लाइट वाली सेकंड रिंग", tagEn: "Live", tagHi: "लाइव" },
};

const inList = <T extends string>(list: readonly T[], id: unknown): id is T =>
  typeof id === "string" && (list as readonly string[]).includes(id);
export const isClockTheme = (id: unknown): id is ClockThemeId => inList(CLOCK_THEME_IDS, id);
export const isClockStyle = (id: unknown): id is ClockStyleId => inList(CLOCK_STYLE_IDS, id);
/** Missing or unknown ids (old backups) fall back to the defaults. */
export const resolveClockTheme = (id: unknown): ClockThemeId => (isClockTheme(id) ? id : DEFAULT_CLOCK_THEME);
export const resolveClockStyle = (id: unknown): ClockStyleId => (isClockStyle(id) ? id : DEFAULT_CLOCK_STYLE);

/** Hand angles in degrees, clockwise from 12. */
export function handAngles(h: number, m: number, s: number) {
  return { hour: ((h % 12) + m / 60 + s / 3600) * 30, minute: (m + s / 60) * 6, second: s * 6 };
}

/** Fill fractions (0–1) for the Digital Orbit rings. */
export function orbitFractions(h: number, m: number, s: number) {
  return { hour: ((h % 12) + m / 60) / 12, minute: (m + s / 60) / 60, second: s / 60 };
}

const HINDI_DIGITS = "०१२३४५६७८९";
export const toHindiDigits = (n: number) => String(n).replace(/\d/g, (d) => HINDI_DIGITS.charAt(Number(d)));

/** Circumference of each orbit ring (radius 100 / 84 / 68). */
export const ORBIT_R = { second: 100, minute: 84, hour: 68 } as const;
const circ = (r: number) => 2 * Math.PI * r;

const C = 120;
const pt = (a: number, r: number): [number, number] => [+(C + Math.sin(a) * r).toFixed(2), +(C - Math.cos(a) * r).toFixed(2)];

/** Numerals / markers layer for a style. */
const ROMAN = ["XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI"];

function faceLayer(style: ClockStyleId): string {
  if (style === "digital") {
    const segs = [...Array(60)].map((_, i) => {
      const a = (i * Math.PI) / 30, [x1, y1] = pt(a, i % 5 ? 96 : 92), [x2, y2] = pt(a, 104);
      return `<line class="dg-seg" data-i="${i}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${i % 5 ? 3 : 4.5}"/>`;
    }).join("");
    return `<g class="dg-ring" stroke-linecap="round">${segs}</g>
<text class="ck-dig dg-dig" x="120" y="132" text-anchor="middle"></text><text class="ck-ap" x="120" y="160" text-anchor="middle"></text><text class="ck-sc" x="120" y="86" text-anchor="middle"></text>`;
  }
  if (style === "romanfull") {
    const ticks = [...Array(60)].map((_, i) => {
      const a = (i * Math.PI) / 30, big = i % 5 === 0, [x1, y1] = pt(a, big ? 96 : 100), [x2, y2] = pt(a, 104);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${big ? 2.4 : 0.9}" stroke-opacity="${big ? 0.9 : 0.4}"/>`;
    }).join("");
    const nums = ROMAN.map((r, i) => {
      const a = (i * Math.PI) / 6, [x, y] = pt(a, 80);
      const deg = i * 30;
      return `<text x="${x}" y="${(y + 5).toFixed(2)}" transform="rotate(${deg > 90 && deg < 270 ? deg + 180 : deg} ${x} ${y})">${r}</text>`;
    }).join("");
    return `<circle class="ck-inner" cx="120" cy="120" r="66"/><g class="ck-ticks">${ticks}</g><g class="ck-num ck-num-romanfull" text-anchor="middle">${nums}</g>`;
  }
  if (style === "railway") {
    const ticks = [...Array(60)].map((_, i) => {
      const a = (i * Math.PI) / 30, big = i % 5 === 0, [x1, y1] = pt(a, big ? 76 : 96), [x2, y2] = pt(a, 104);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${big ? 7 : 2.4}" stroke-linecap="butt"/>`;
    }).join("");
    return `<g class="ck-ticks">${ticks}</g>`;
  }
  if (style === "diver") {
    const bez = [...Array(60)].map((_, i) => {
      if (i % 5) return "";
      const a = (i * Math.PI) / 30;
      if (i === 0) { const [x1, y1] = pt(a - 0.07, 106), [x2, y2] = pt(a + 0.07, 106), [x3, y3] = pt(a, 94); return `<polygon class="dv-tri" points="${x1},${y1} ${x2},${y2} ${x3},${y3}"/>`; }
      if (i % 15 === 0) { const [x, y] = pt(a, 100); return `<text class="dv-n" x="${x}" y="${(y + 4.5).toFixed(2)}">${i}</text>`; }
      const [x, y] = pt(a, 100); return `<circle class="dv-d" cx="${x}" cy="${y}" r="1.8"/>`;
    }).join("");
    const lume = [...Array(12)].map((_, i) => {
      const a = (i * Math.PI) / 6;
      if (i % 3 === 0 && i) { const [x1, y1] = pt(a, 70), [x2, y2] = pt(a, 86); return `<line class="dv-bar" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="8" stroke-linecap="round"/>`; }
      if (i === 0) { const [x1, y1] = pt(a - 0.09, 86), [x2, y2] = pt(a + 0.09, 86), [x3, y3] = pt(a, 68); return `<polygon class="dv-lume" points="${x1},${y1} ${x2},${y2} ${x3},${y3}"/>`; }
      const [x, y] = pt(a, 79); return `<circle class="dv-lume" cx="${x}" cy="${y}" r="5.5"/>`;
    }).join("");
    return `<circle class="dv-bezel" cx="120" cy="120" r="100" stroke-width="14"/><g class="dv-marks" text-anchor="middle">${bez}</g><g class="dv-lumes">${lume}</g>`;
  }
  if (style === "dots") {
    const dots = [...Array(60)].map((_, i) => {
      const a = (i * Math.PI) / 30, [x, y] = pt(a, i % 5 ? 98 : 92);
      const r = i % 15 === 0 ? 6 : i % 5 === 0 ? 4 : 1.3;
      return `<circle class="${i % 5 ? "pd-s" : "pd-b"}" cx="${x}" cy="${y}" r="${r}"/>`;
    }).join("");
    return `<g class="ck-pearls">${dots}</g>`;
  }
  if (style === "orbit") {
    const ring = (k: keyof typeof ORBIT_R, w: number) => {
      const r = ORBIT_R[k], c = +circ(r).toFixed(2);
      return `<circle class="ob-tr" cx="120" cy="120" r="${r}" stroke-width="${w}"/><circle class="ob ob-${k}" cx="120" cy="120" r="${r}" stroke-width="${w}" stroke-dasharray="${c}" stroke-dashoffset="${c}" transform="rotate(-90 120 120)"/>`;
    };
    const dots = [...Array(12)].map((_, i) => { const [x, y] = pt((i * Math.PI) / 6, 111); return `<circle cx="${x}" cy="${y}" r="${i % 3 ? 1.2 : 2.2}"/>`; }).join("");
    return `<g class="ck-dots">${dots}</g>${ring("second", 6)}${ring("minute", 9)}${ring("hour", 11)}
<text class="ck-dig" x="120" y="124" text-anchor="middle"></text><text class="ck-ap" x="120" y="146" text-anchor="middle"></text><text class="ck-sc" x="120" y="92" text-anchor="middle"></text>`;
  }
  const ticks = [...Array(60)].map((_, i) => {
    const a = (i * Math.PI) / 30, big = i % 5 === 0;
    if (style === "minimal") {
      if (!big) return "";
      const q = i % 15 === 0, [x1, y1] = pt(a, q ? 84 : 90), [x2, y2] = pt(a, 104);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${q ? 6 : 3.5}"/>`;
    }
    const [x1, y1] = pt(a, big ? 93 : 98), [x2, y2] = pt(a, 104);
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke-width="${big ? 3 : 1}" stroke-opacity="${big ? 0.9 : 0.35}"/>`;
  }).join("");
  let nums = "";
  if (style === "roman") {
    nums = `<text x="120" y="68">XII</text><text x="180" y="126">III</text><text x="120" y="188">VI</text><text x="60" y="126">IX</text>`;
  } else if (style === "arabic" || style === "hindi") {
    nums = [...Array(12)].map((_, i) => {
      const n = i + 1, [x, y] = pt((n * Math.PI) / 6, 78);
      return `<text x="${x}" y="${(y + 6.5).toFixed(2)}">${style === "hindi" ? toHindiDigits(n) : n}</text>`;
    }).join("");
  }
  return `<g class="ck-ticks">${ticks}</g>${nums ? `<g class="ck-num ck-num-${style}" text-anchor="middle">${nums}</g>` : ""}`;
}

function handsLayer(style: ClockStyleId): string {
  if (style === "orbit" || style === "digital") return "";
  if (style === "railway") {
    return `<g class="ck-hands"><line class="ck-hh" stroke-width="10" x1="120" x2="120" y1="146" y2="70"/><line class="ck-mh" stroke-width="7" x1="120" x2="120" y1="150" y2="38"/><line class="ck-sh" stroke-width="2.4" x1="120" x2="120" y1="160" y2="62"/><circle class="ck-od rw-pop" cx="120" cy="58" r="8"/></g><circle class="ck-cap" cx="120" cy="120" r="5"/>`;
  }
  if (style === "diver") {
    return `<g class="ck-hands"><line class="ck-hh" stroke-linecap="round" stroke-width="9" x1="120" x2="120" y1="128" y2="74"/><line class="ck-mh" stroke-linecap="round" stroke-width="6" x1="120" x2="120" y1="132" y2="42"/><line class="ck-sh" stroke-linecap="round" stroke-width="2" x1="120" x2="120" y1="142" y2="34"/><circle class="ck-od" cx="120" cy="58" r="5"/></g><circle class="ck-cap" cx="120" cy="120" r="7"/><circle class="ck-cap2" cx="120" cy="120" r="2.6"/>`;
  }
  const slim = style === "minimal";
  return `<g class="ck-hands"><line class="ck-hh" stroke-linecap="round" stroke-width="${slim ? 4 : 6}" x1="120" x2="120" y1="${slim ? 128 : 120}" y2="${slim ? 70 : 76}"/><line class="ck-mh" stroke-linecap="round" stroke-width="${slim ? 2.6 : 4}" x1="120" x2="120" y1="${slim ? 130 : 120}" y2="${slim ? 40 : 52}"/><line class="ck-sh" stroke-linecap="round" stroke-width="${slim ? 1.2 : 2}" x1="120" x2="120" y1="${slim ? 138 : 132}" y2="${slim ? 32 : 40}"/>${slim ? "" : `<circle class="ck-od" cx="120" cy="12" r="4"/>`}</g><circle class="ck-cap" cx="120" cy="120" r="${slim ? 4.5 : 7}"/>${slim ? "" : `<circle class="ck-cap2" cx="120" cy="120" r="2.4"/>`}`;
}

/** Full clock SVG for a style. Colours come from CSS; `cls` adds classes on the <svg>. */
export function clockSVG(style: ClockStyleId, cls = ""): string {
  return `<svg class="ck ck-${style}${cls ? " " + cls : ""}" data-cks="${style}" viewBox="0 0 240 240" aria-hidden="true"><circle class="ck-bz" cx="120" cy="120" r="116"/><circle class="ring ck-ring" cx="120" cy="120" r="109"/>${faceLayer(style)}${handsLayer(style)}</svg>`;
}

/** Styles that show the time as digits instead of hands (the big digital line under the clock is then hidden). */
export const DIGITAL_STYLES: readonly ClockStyleId[] = ["orbit", "digital"];

/** Which of the 60 seconds lights are on for the Digital LED style (0 → only the first). */
export const ledCount = (s: number) => Math.max(0, Math.min(60, Math.floor(s) + 1));

/** Ring offsets for the orbit style, given the time. */
export function orbitOffsets(h: number, m: number, s: number) {
  const f = orbitFractions(h, m, s);
  const off = (k: keyof typeof ORBIT_R) => +(circ(ORBIT_R[k]) * (1 - f[k])).toFixed(2);
  return { hour: off("hour"), minute: off("minute"), second: off("second") };
}
