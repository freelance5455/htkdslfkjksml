import { describe, expect, it } from "vitest";
import { addRecord, csvCell, dayBucket, filterHistory, groupHistory, makeRecord, sanitizeDetails, toCSV, activityLabel } from "./history-core";

const at = (y: number, m: number, d: number, h = 10) => new Date(y, m - 1, d, h, 0, 0).getTime();
const NOW = at(2026, 11, 13, 12);

describe("history rules", () => {
  it("never stores passwords, tokens, keys or email addresses", () => {
    const d = sanitizeDetails({
      task: "Call mom",
      password: "hunter2",
      access_token: "abc",
      apiKey: "k",
      email: "a@b.com",
      note: "mail me at rudra@example.com token eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcdefghijklmnop",
    });
    expect(d).toEqual({ task: "Call mom", note: "mail me at [hidden] token [hidden]" });
  });

  it("each record has a name, exact time, category, details and status", () => {
    const r = makeRecord("alarm", "created", { task: "Walk", time: "06:30" }, "Created", NOW, () => 0.5);
    expect(r).toMatchObject({ ts: NOW, cat: "alarm", act: "created", st: "Created", d: { task: "Walk", time: "06:30" } });
    expect(activityLabel(r)).toBe("Alarm created");
  });

  it("groups into Today, Yesterday and Earlier by local day", () => {
    expect(dayBucket(at(2026, 11, 13, 0), NOW)).toBe("today");
    expect(dayBucket(at(2026, 11, 12, 23), NOW)).toBe("yesterday");
    expect(dayBucket(at(2026, 11, 11, 23), NOW)).toBe("earlier");
    const list = [makeRecord("alarm", "created", {}, "Created", at(2026, 11, 1)), makeRecord("alarm", "deleted", {}, "Deleted", at(2026, 11, 13, 9))];
    expect(groupHistory(list, NOW).map((g) => g.bucket)).toEqual(["today", "earlier"]);
  });

  it("filters by activity type, date and search text", () => {
    const list = [
      makeRecord("alarm", "created", { task: "Walk" }, "Created", at(2026, 11, 13)),
      makeRecord("settings", "language", {}, "Changed", at(2026, 11, 12)),
      makeRecord("dayplan", "block_created", { title: "Gym" }, "Created", at(2026, 11, 5)),
    ];
    const text = (r: { d: Record<string, unknown> }) => JSON.stringify(r.d);
    expect(filterHistory(list, { cat: "settings" }, text, NOW)).toHaveLength(1);
    expect(filterHistory(list, { range: "yesterday" }, text, NOW)[0]?.cat).toBe("settings");
    expect(filterHistory(list, { range: "date", date: "2026-11-05" }, text, NOW)[0]?.cat).toBe("dayplan");
    expect(filterHistory(list, { q: "gym" }, text, NOW)).toHaveLength(1);
  });

  it("keeps newest first and caps the list", () => {
    let list = [makeRecord("alarm", "created", {}, "Created", 1)];
    list = addRecord(list, makeRecord("alarm", "deleted", {}, "Deleted", 2), 1);
    expect(list.map((r) => r.act)).toEqual(["deleted"]);
  });

  it("CSV export escapes quotes and blocks spreadsheet formulas", () => {
    expect(csvCell('He said "hi"')).toBe('"He said ""hi"""');
    expect(csvCell("=HYPERLINK(1)")).toBe("\"'=HYPERLINK(1)\"");
    const csv = toCSV([makeRecord("alarm", "created", { task: "Walk" }, "Created", NOW)], {
      activity: (r) => activityLabel(r),
      category: () => "Alarms",
      details: () => "“Walk”",
      status: (r) => r.st,
    }, "Asia/Kolkata");
    expect(csv.split("\r\n")[0]).toContain('"Date","Time","Time zone"');
    expect(csv).toContain('"Asia/Kolkata","Alarms","Alarm created","“Walk”","Created"');
  });
});
