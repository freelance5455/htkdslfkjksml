import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

import appCss from "@/legacy/app.css?url";
import { MARKUP } from "@/legacy/markup";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Life Alarm — voice alarms, calendar & Day Plan" },
      {
        name: "description",
        content:
          "Smart Life Alarm: voice alarms, calendar reminders, Day Plan timetable, live weather and activity history — all saved on your own device.",
      },
      { property: "og:title", content: "Smart Life Alarm" },
      {
        property: "og:description",
        content: "Voice alarms, calendar reminders, Day Plan and live weather in one calm app that works offline.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    let alive = true;
    // The app logic is browser-only; load it after the markup is on the page.
    void import("@/legacy/app").then((m) => {
      if (alive) m.boot();
    });
    return () => {
      alive = false;
    };
  }, []);
  return <div id="sla-root" suppressHydrationWarning dangerouslySetInnerHTML={{ __html: MARKUP }} />;
}
