// @ts-nocheck
/* Smart Life Alarm app logic, ported from the v5 single-file app (index.html) and extended up to v11.
 * Runs only in the browser, once, after the static markup from ./markup.ts is on the page.
 * v11: fully local — no sign-in, no server. Every record lives on this device (localStorage + IndexedDB). */
import * as RT from "@/lib/ringtones";
import * as HC from "@/lib/history-core";
import * as MKC from "@/lib/marks-core";
import { ic, icFor } from "./icons";
import * as TC from "@/lib/time-core";
import * as TH from "@/lib/themes-core";
import * as CK from "@/lib/clock-core";
import * as NA from "@/lib/native-alarm-core";
import { Capacitor, registerPlugin } from "@capacitor/core";

let booted = false;
export function boot() {
if (booted) return;
booted = true;
/* ===== v6: shared hooks, settings and history stores ===== */
const X={};
const lsg=(k,f=null)=>{try{const v=localStorage.getItem(k);return v===null?f:v}catch(e){return f}};
const lss=(k,v)=>{try{localStorage.setItem(k,v);return true}catch(e){return false}};
const lsd=k=>{try{localStorage.removeItem(k)}catch(e){}};
const defSet=()=>({ringtone:RT.DEFAULT_ID,vibrate:true,ramp:true,theme:TH.DEFAULT_THEME,h24:false,ck:CK.DEFAULT_CLOCK_THEME,cks:CK.DEFAULT_CLOCK_STYLE,spk:true,rd:false});
let SET=defSet();try{SET=Object.assign(defSet(),JSON.parse(lsg("sla_settings","{}"))||{})}catch(e){}
if(!RT.has(SET.ringtone))SET.ringtone=RT.DEFAULT_ID;
X.settings=()=>SET;
/* v7/v8: themes (list + names in @/lib/themes-core, colours in app.css [data-theme=id]) */
const curTheme=()=>TH.resolveTheme(SET.theme);
let thAnimT=null;
const applyTheme=(animate)=>{const t=curTheme(),de=document.documentElement;if(animate){de.classList.add("th-anim");clearTimeout(thAnimT);thAnimT=setTimeout(()=>de.classList.remove("th-anim"),700)}de.dataset.theme=t;const m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",TH.THEMES[t].color)};applyTheme();
/* v8: 12-hour (AM/PM) or 24-hour clock */
const applyClock=()=>document.documentElement.classList.toggle("h24",!!SET.h24);applyClock();
/* v9: clock theme (colours) + clock style (face) for the big clock; lists in @/lib/clock-core */
const curCk=()=>CK.resolveClockTheme(SET.ck),curCks=()=>CK.resolveClockStyle(SET.cks);
const applyCk=()=>{const de=document.documentElement;de.dataset.ck=curCk();de.dataset.cks=curCks();const w=document.getElementById("ckw");if(w&&w.dataset.cks!==curCks()){w.dataset.cks=curCks();w.innerHTML=CK.clockSVG(curCks());paintClock(w.firstChild,new Date())}};
/* v7: calendar date highlights, one per date */
let MK={};try{MK=MKC.loadMarks(JSON.parse(lsg("sla_marks","{}")))}catch(e){MK={}}
const saveMK=()=>{lss("sla_marks",JSON.stringify(MK));X.changed&&X.changed()};
const saveSet=()=>{lss("sla_settings",JSON.stringify(SET));X.changed&&X.changed();X.nsync&&X.nsync()};
let HIST=[];try{const h=JSON.parse(lsg("sla_hist","[]"));if(Array.isArray(h))HIST=h.filter(r=>r&&r.id&&r.ts)}catch(e){}
const saveH=()=>{if(!lss("sla_hist",JSON.stringify(HIST))){HIST=HIST.slice(0,500);lss("sla_hist",JSON.stringify(HIST))}X.changed&&X.changed()};
X.log=(cat,act,d,st,ts)=>{try{HIST=HC.addRecord(HIST,HC.makeRecord(cat,act,d,st,ts||Date.now()));saveH();X.onHist&&X.onHist()}catch(e){console.warn("history",e)}};
const T=(en,hi)=>X.H&&X.H()?hi:en;
const escH=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));


const $=s=>document.querySelector(s),D=["S","M","T","W","T","F","S"],p2=n=>String(n).padStart(2,"0");

/* Festival helpers (data assigned when LifeMate block runs) */
/* FESTIVALS loaded in LifeMate block */
function festFor(k){ return (window.FESTIVALS || FESTIVALS || []).filter(f => f.date === k); }
function renderFestCard(k){
  const box = $("#fest-card"); if(!box) return;
  const list = festFor(k);
  if(!list.length){
    box.innerHTML = '<div class="fest-empty">' + (typeof H==="function" && H() ? "इस दिन कोई प्रमुख त्योहार नहीं।" : "No major festival on this date.") + '</div>';
    box.classList.add("show"); return;
  }
  const td = typeof today === "function" ? today() : new Date().toISOString().slice(0,10);
  const daysUntil = d => { const a = new Date(td+"T00:00:00"), b = new Date(d+"T00:00:00"); return Math.round((b-a)/86400000); };
  box.innerHTML = list.map(f => {
    const du = daysUntil(f.date);
    const hi = typeof H === "function" && H();
    const when = du === 0 ? (hi ? "आज" : "Today") : du > 0 ? (hi ? du + " दिन बाद" : "in " + du + " days") : (hi ? (-du) + " दिन पहले" : (-du) + " days ago");
    return '<div class="fest-item" style="--fc:'+f.color+'"><div class="fi-name">'+(hi?f.hi:f.en)+'</div><div class="fi-meta">'+f.date+' · '+f.cat+' · '+when+'</div><div class="fi-desc">'+(hi?f.desc_hi:f.desc_en)+'</div><div class="fi-trad">'+(hi?"परंपरा: ":"Traditions: ")+(hi?f.trad_hi:f.trad_en)+'</div></div>';
  }).join("");
  box.classList.add("show");
}

/* PWA install + offline app shell. Browser alarms still require the page to remain active. */
let installPrompt=null;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("#install").hidden=false});$("#install").onclick=async()=>{if(!installPrompt){toast("Browser menu se Add to Home screen chunein");return}installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("#install").hidden=true};if("serviceWorker" in navigator && import.meta.env.PROD && !import.meta.env.VITE_LOCAL_BUILD && location.protocol==="https:" && window.self===window.top){navigator.serviceWorker.register("/sw.js").catch(()=>{})}

/* v11: save a text file. Browsers download it; the Android app writes it to the phone's Downloads folder. */
X.download=async(name,text,mime)=>{if(X.saveNative){try{const r=await X.saveNative(name,text,mime);if(r)return true}catch(e){console.warn("native save",e)}}try{const u=URL.createObjectURL(new Blob([text],{type:mime||"text/plain"})),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1500);return true}catch(e){return false}};
X.notify=async a=>{try{if(typeof Notification==="undefined"||Notification.permission!=="granted")return;const opt={body:(fmt(a.t)+" · "+a.task),tag:"sla-"+a.id,requireInteraction:true,renotify:true,vibrate:[400,200,400],icon:"icon.svg",badge:"icon.svg"};const reg=navigator.serviceWorker&&await navigator.serviceWorker.getRegistration().catch(()=>null);if(reg&&reg.showNotification){await reg.showNotification("⏰ Smart Life Alarm",opt);return}new Notification("⏰ Smart Life Alarm",opt)}catch(e){}};
const toast=t=>{const d=document.createElement("div");d.className="toast";d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2700)};
const PRE=[["🪥","Brush karne ka time ho gaya hai"],["💧","Paani peene ka time ho gaya hai"],["💊","Dawai khane ka time ho gaya hai"],["🏋️","Exercise ka time ho gaya hai"],["📚","Padhai ka time ho gaya hai"],["🍽️","Khana khane ka time ho gaya hai"]];
const ICON=t=>{t=t.toLowerCase();return/brush|teeth|daant/.test(t)?"🪥":/water|paani|pani/.test(t)?"💧":/med|dawa|tablet|pill/.test(t)?"💊":/gym|exercise|workout|yoga/.test(t)?"🏋️":/study|padh|read/.test(t)?"📚":/meet|call/.test(t)?"📅":/khana|lunch|dinner|food|breakfast/.test(t)?"🍽️":/sleep|sone/.test(t)?"😴":"🔔"};
const COL=["#8a6d3b","#5f7247","#8f3b3b","#4f6a82","#6e5470","#9a7a3a"];
let A=[],eid=null,eDays=0,eLang="hi-IN",ring=null,loopT=null,beepT=null,ac=null,song=null,prev=null,tones=[];
try{A=JSON.parse(localStorage.getItem("sla2")||"[]")}catch(e){}
const save=()=>{try{localStorage.setItem("sla2",JSON.stringify(A))}catch(e){}X.changed&&X.changed();X.nsync&&X.nsync()};
const today=()=>{const d=new Date();return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())};
/* audio unlock (browsers need one tap before sound) */
const SIL="data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=",SA=new Audio();SA.loop=true;
const wake=async()=>{try{if(navigator.wakeLock)await navigator.wakeLock.request("screen")}catch(e){}};
addEventListener("pointerdown",()=>{try{ac=ac||new AudioContext();ac.resume()}catch(e){}try{SA.src=SIL;SA.muted=true;SA.play().then(()=>{SA.pause();SA.muted=false}).catch(()=>{SA.muted=false})}catch(e){}try{speechSynthesis.speak(new SpeechSynthesisUtterance(""))}catch(e){}wake()},{once:true});
document.addEventListener("visibilitychange",()=>{if(!document.hidden){wake();render();rPlan()}});
/* IndexedDB songs */
const db=new Promise(r=>{try{const q=indexedDB.open("sla",1);q.onupgradeneeded=()=>q.result.createObjectStore("tones",{keyPath:"id"});q.onsuccess=()=>r(q.result);q.onerror=()=>r(null)}catch(e){r(null)}});
const tx=async(m,f)=>{try{const d=await db;if(!d)return null;return await new Promise(r=>{const t=d.transaction("tones",m),s=t.objectStore("tones"),q=f(s);t.oncomplete=()=>r(q&&q.result===undefined?true:q.result);t.onerror=t.onabort=()=>r(null)})}catch(e){return null}};
const loadTones=async()=>{const st=(await tx("readonly",s=>s.getAll()))||[];const L=Array.isArray(st)?st:[];tones=[...L,...tones.filter(t=>!L.some(x=>x.id==t.id))];fillTones()};
function fillTones(sel){const el=$("#tn"),v=String(sel||el.value||"beep"),hi=!!(X.H&&X.H());el.innerHTML=`<option value="beep">🔔 ${hi?"डिफ़ॉल्ट":"Default"} (${RT.nameOf(SET.ringtone,hi)})</option>`+RT.LIST.map(r=>`<option value="rt:${r.id}">🎼 ${hi?r.hi:r.name}</option>`).join("")+tones.map(t=>`<option value="${t.id}">🎵 ${t.name.replace(/</g,"")}</option>`).join("");el.value=v=="beep"||(v.startsWith("rt:")&&RT.has(v.slice(3)))||tones.some(t=>t.id==v)?v:"beep"}
$("#fl").onchange=e=>{const fs=[...e.target.files];let last;for(const f of fs){last=String(Date.now()+Math.floor(Math.random()*1e5));const t={id:last,name:f.name.replace(/\.[^.]+$/,""),blob:f};tones.push(t);tx("readwrite",s=>s.put(t)).then(r=>{if(r===null)$("#fs").textContent+=" ⚠️ Browser save block hai: song sirf tab tak chalega jab tak ye tab khula hai."})}fillTones(last);$("#fs").textContent=fs.length?"✓ Song add hua: "+fs[0].name+(fs.length>1?" +"+(fs.length-1):""):"";e.target.value=""};
$("#tx").onclick=async()=>{const v=$("#tn").value;if(v!="beep"){tones=tones.filter(t=>t.id!=v);await tx("readwrite",s=>s.delete(v));fillTones("beep");toast("Song hata diya")}};
$("#tp").onclick=()=>{if(prev){prev.pause();prev=null;$("#tp").textContent="▶";return}const v=$("#tn").value;if(v=="beep"||String(v).startsWith("rt:")){try{ac=ac||new AudioContext()}catch(e){toast("Sound not supported");return}prev=RT.preview(ac,v=="beep"?SET.ringtone:v.slice(3),()=>{prev=null;$("#tp").textContent="▶"});$("#tp").textContent="⏸";return}const t=tones.find(x=>x.id==v);if(!t)return;prev=new Audio(URL.createObjectURL(t.blob));prev.onended=()=>{prev=null;$("#tp").textContent="▶"};prev.play().catch(()=>toast("Song play nahi hua"));$("#tp").textContent="⏸"};
/* clock */
function paintClock(svg,n){if(!svg||!svg.querySelector)return;const h=n.getHours(),m=n.getMinutes(),s=n.getSeconds(),q=c=>svg.querySelector(c);
 if(svg.dataset.cks==="digital"){const c=CK.ledCount(s);if(svg._led!==c){svg._led=c;svg.querySelectorAll(".dg-seg").forEach((e,i)=>e.classList.toggle("on",i<c))}
  const t=fmt(p2(h)+":"+p2(m)),mm=/^(.*) (AM|PM)$/.exec(t);q(".ck-dig").textContent=mm?mm[1]:t;q(".ck-ap").textContent=mm?mm[2]:n.toLocaleDateString(X.H&&X.H()?"hi-IN":"en",{weekday:"short"}).toUpperCase();q(".ck-sc").textContent=p2(s);return}
 if(svg.dataset.cks==="orbit"){const o=CK.orbitOffsets(h,m,s);for(const k of ["hour","minute","second"]){const e=q(".ob-"+k);if(e){if(k==="second"&&s===0){e.style.transition="none";requestAnimationFrame(()=>{e.style.transition=""})}e.setAttribute("stroke-dashoffset",o[k])}}
  const t=fmt(p2(h)+":"+p2(m)),mm=/^(.*) (AM|PM)$/.exec(t);q(".ck-dig").textContent=mm?mm[1]:t;q(".ck-ap").textContent=mm?mm[2]:n.toLocaleDateString(X.H&&X.H()?"hi-IN":"en",{weekday:"short"}).toUpperCase();q(".ck-sc").textContent=p2(s);return}
 const a=CK.handAngles(h,m,s),r=(c,d)=>{const e=q(c);if(e)e.setAttribute("transform",`rotate(${d} 120 120)`)};r(".ck-hh",a.hour);r(".ck-mh",a.minute);r(".ck-sh",a.second);r(".ck-od",a.second)}
const paintClocks=n=>{paintClock($("#ckw svg"),n);const t=$("#thm");if(t&&t.classList.contains("o"))t.querySelectorAll("svg.ck").forEach(v=>paintClock(v,n))};
applyCk();
function nextT(a){const n=new Date(),[h,m]=a.t.split(":").map(Number);
 if(a.snz){const z=new Date(a.snz.replace(" ","T")+":00");if(z>n)return z}
 if(!a.days){const t=new Date(a.date+"T"+a.t);return t>n?t:null}
 for(let i=0;i<8;i++){const d=new Date(n);d.setDate(n.getDate()+i);d.setHours(h,m,0,0);if(a.days>>d.getDay()&1&&d>n)return d}return null}
function fmt(t){return TC.formatTime(t,!!SET.h24)}
const sm=t=>fmt(t).replace(/ (AM|PM)$/,"<small>$1</small>");
function render(){const td=today();let nx=null;
 A.forEach(a=>{if(a.en){const t=nextT(a);if(t&&(!nx||t<nx.t))nx={t,a}}});
 $("#nx").textContent=nx?(m=>m>=1440?Math.floor(m/1440)+"d":m>=60?Math.floor(m/60)+"h "+m%60+"m":m+" min")(Math.max(0,Math.round((nx.t-Date.now())/60000))):"None";
 const isT=a=>a.done===td||(a.en&&nextT(a)&&nextT(a).toDateString()===new Date().toDateString());
 const tl=A.filter(isT),rest=A.filter(a=>!isT(a));$("#td").textContent=tl.length;$("#dn").textContent=A.filter(a=>a.done===td).length;
 const tn=a=>{const hi=!!(X.H&&X.H());if(a.tone&&String(a.tone).startsWith("rt:"))return RT.nameOf(a.tone.slice(3),hi);const t=a.tone&&a.tone!="beep"&&tones.find(t=>t.id==a.tone);return t?t.name.replace(/</g,""):RT.nameOf(SET.ringtone,hi)};
 const card=a=>`<div class="g al" style="--c:${COL[Math.floor(a.id)%6]}"><div class="ic">${icFor(ICON(a.task))}</div><div class="t" data-e="${a.id}"><div class="tm">${sm(a.t)}</div><div class="tk">${a.task.replace(/</g,"&lt;")}</div>
 <span class="chip">${a.days?(a.days==127?"Every day":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].filter((_,i)=>a.days>>i&1).join(" ")):a.date}</span><span class="chip">${a.lang=="hi-IN"?"हिंदी":"English"}</span><span class="chip">${tn(a)}</span>${a.done===td?'<span class="chip">✓ Done</span>':""}</div>
 <div class="sw ${a.en?"on":""}" data-t="${a.id}"></div><button class="ib" data-d="${a.id}" aria-label="Delete">${ic("trash")}</button></div>`;
 $("#list").innerHTML=(tl.length?"<h2>Today</h2>"+tl.map(card).join(""):"")+(rest.length?`<h2>${tl.length?"Other reminders":"All reminders"}</h2>`+rest.map(card).join(""):"")+(A.length?"":'<p class="mu" style="text-align:center;margin-top:34px">Abhi koi reminder nahi.<br>Neeche + dabakar banayein</p>')}
const DUE_MS=10*60*1000; /* v11: catch-up window, so a queued or slept-through alarm still rings */
function due(a,n){let T;if(a.snz)T=new Date(a.snz.replace(" ","T")+":00");else{if(!(a.days?a.days>>n.getDay()&1:a.date===today()))return false;T=new Date(today()+"T"+a.t+":00")}const d=n-T;return d>=0&&d<DUE_MS}
const key=a=>a.snz||today()+" "+a.t;
function tick(){const n=new Date(),h=n.getHours();paintClocks(n);
 $("#dt").textContent=fmt(p2(h)+":"+p2(n.getMinutes()));$("#dd").textContent=n.toLocaleDateString(undefined,{weekday:"long",day:"numeric",month:"long",year:"numeric"});
 $("#gr").textContent=h<12?T("Good morning","सुप्रभात"):h<17?T("Good afternoon","नमस्कार"):h<21?T("Good evening","शुभ संध्या"):T("Good night","शुभ रात्रि");
 if(!ring&&!X.nativeRing)for(const a of A){if(a.en&&due(a,n)&&a.last!==key(a)){a.last=key(a);a.snz=null;if(!a.days)a.en=false;save();start(a);break}}
 const mk=n.getHours()*60+n.getMinutes();if(mk!==tick.m||!tick.l){tick.m=mk;render();rPlan()}tick.l=1}
function beep(){try{ac=ac||new AudioContext();ac.resume();const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=880;g.gain.value=.18;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+.25)}catch(e){}}
const duck=v=>{if(song)song.volume=v};
const pickVoice=lang=>{try{const L=speechSynthesis.getVoices().filter(v=>v.lang.replace("_","-").toLowerCase().startsWith(String(lang||"hi-IN").slice(0,2).toLowerCase()));const ex=L.filter(v=>v.lang.replace("_","-").toLowerCase()===String(lang).toLowerCase());const pool=ex.length?ex:L;return pool.find(v=>/natural|neural|google|online/i.test(v.name))||pool[0]||null}catch(e){return null}};
function say(a){if(!a||a.vo===false||SET.spk===false)return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(a.task);u.lang=a.lang||"hi-IN";u.rate=.95;const v=pickVoice(u.lang);if(v)u.voice=v;
 const again=()=>{duck(.9);if(ring)loopT=setTimeout(()=>say(ring),4000)};u.onstart=()=>duck(.25);u.onend=again;u.onerror=again;speechSynthesis.speak(u)}catch(e){}}
async function start(a){ring=a;X.log("alarm","ringing",{task:a.task,time:a.t},"Ringing");$("#rt").textContent=fmt(a.t);$("#rk").textContent=a.task;$("#ri").innerHTML=icFor(ICON(a.task),"ico ri-ic");$("#rg").classList.add("s");
 const t=tones.find(x=>x.id==a.tone);let ok=false;
 if(t){try{SA.src=URL.createObjectURL(t.blob);SA.muted=false;SA.volume=.9;await SA.play();song=SA;ok=true}catch(e){song=null}}
 if(!ok){const rid=String(a.tone||"").startsWith("rt:")&&RT.has(a.tone.slice(3))?a.tone.slice(3):SET.ringtone;try{ac=ac||new AudioContext();ac.resume().catch(()=>{});song=RT.play(ac,rid,{ramp:SET.ramp!==false})}catch(e){song=null;beep();beepT=setInterval(beep,1500)}}X.ringAudioCheck&&X.ringAudioCheck();
 setTimeout(()=>ring===a&&say(a),2500);X.vibStart&&X.vibStart();
 X.notify&&X.notify(a)
 setTimeout(()=>ring===a&&end(false,0,"missed"),600000)}
function end(done,snz,why){const a=ring;ring=null;clearInterval(beepT);clearTimeout(loopT);X.vibStop&&X.vibStop();if(song){song.pause();song=null}try{speechSynthesis.cancel()}catch(e){}$("#rg").classList.remove("s");
 if(a){X.log(a.cal?"calendar":"alarm",done?"completed":snz?"snoozed":why==="missed"?"missed":"dismissed",{task:a.task,time:a.t,snooze:snz||undefined},done?"Completed":snz?"Snoozed":why==="missed"?"Missed":"Dismissed");if(done){a.done=today();const b=a.pid&&P.find(x=>x.id==a.pid);if(b){b.done=today();saveP()}}
  if(snz){const d=new Date(Date.now()+snz*60000);a.snz=TC.snoozeUntil(Date.now(),snz);a.en=true;toast("😴 "+snz+" min baad dobara")}save();render();rPlan()}}
$("#stop").onclick=()=>end(true);document.querySelectorAll("[data-m]").forEach(b=>b.onclick=()=>end(false,+b.dataset.m));
function open(a){eid=a?a.id:null;$("#et").textContent=a?"Edit Reminder":"New Reminder";$("#tk").value=a?a.task:"";const n=new Date(Date.now()+5*60000);
 $("#tm").value=a?a.t:p2(n.getHours())+":"+p2(n.getMinutes());$("#dte").value=a?a.date:n.getFullYear()+"-"+p2(n.getMonth()+1)+"-"+p2(n.getDate());eDays=a?a.days:0;eLang=a?a.lang:"hi-IN";fillTones(a?a.tone:"rt:"+SET.ringtone);paint();$("#ed").classList.add("s")}
$("#pre").innerHTML=PRE.map((p,i)=>`<button class="q" data-p="${i}">${p[0]}</button>`).join("");
$("#pre").onclick=e=>{const i=e.target.dataset.p;if(i!=null)$("#tk").value=PRE[i][1]};
function paint(){$("#dy").innerHTML=D.map((d,i)=>`<button class="${eDays>>i&1?"on":""}" data-i="${i}">${d}</button>`).join("");$("#dte").style.display=eDays?"none":"";document.querySelectorAll(".ch").forEach(c=>c.classList.toggle("on",c.dataset.l===eLang))}
$("#dy").onclick=e=>{const i=e.target.dataset.i;if(i!=null){eDays^=1<<i;paint()}};
document.querySelectorAll(".ch").forEach(c=>c.onclick=()=>{eLang=c.dataset.l;paint()});
$("#add").onclick=()=>{tab=="pl"?popen():open();try{Notification.requestPermission()}catch(e){}};
const close=()=>{$("#ed").classList.remove("s");if(prev){prev.pause();prev=null;$("#tp").textContent="▶"}};
$("#cn").onclick=close;$("#ts").onclick=()=>say({task:$("#tk").value||"Test",lang:eLang});
$("#sv").onclick=()=>{const task=$("#tk").value.trim();if(!task){toast("Pehle task likho ✍️");return}const old=A.find(x=>x.id===eid),a={id:eid||Date.now(),task,t:$("#tm").value,date:$("#dte").value,days:eDays,lang:eLang,tone:$("#tn").value,en:true,pid:old&&old.pid,desc:old&&old.desc,cat:old&&old.cat,vo:old&&old.vo,dd:old&&old.dd,cal:old&&old.cal};
 if(!a.t){toast("Time chuno ⏰");return}
 if(!a.days&&!nextT(a)){toast("Future date/time chuno 📅");return}
 if(a.days&&due(a,new Date()))a.last=key(a);
 const i=A.findIndex(x=>x.id===eid);i>=0?A[i]=a:A.push(a);X.log("alarm",i>=0?"edited":"created",{task:a.task,time:a.t,repeat:a.days,date:a.days?undefined:a.date},i>=0?"Updated":"Created");A.sort((x,y)=>x.t.localeCompare(y.t));save();close();render();toast("✓ Alarm save ho gaya")};
$("#list").onclick=e=>{const t=e.target.closest("[data-t],[data-d],[data-e]");if(!t)return;
 if(t.dataset.t){const a=A.find(x=>x.id==t.dataset.t);a.en=!a.en;a.snz=null;if(a.en&&!a.days&&!nextT(a)){a.en=false;toast("Time nikal chuka hai – edit karein")}if(a.en&&a.days&&due(a,new Date()))a.last=key(a);X.log(a.cal?"calendar":"alarm",a.en?"enabled":"disabled",{task:a.task,time:a.t},a.en?"On":"Off");save();render()}
 else if(t.dataset.d){const del=A.find(x=>x.id==t.dataset.d);A=A.filter(x=>x.id!=t.dataset.d);if(del)X.log(del.cal?"calendar":"alarm","deleted",{task:del.task,time:del.t},"Deleted");save();render()}else open(A.find(x=>x.id==t.dataset.e))};
/* ===== Day Plan ===== */
let P=[],tab="al",pid=null,pic="📚";try{P=JSON.parse(localStorage.getItem("sla_p")||"[]")}catch(e){}
const saveP=()=>{try{localStorage.setItem("sla_p",JSON.stringify(P))}catch(e){}X.changed&&X.changed()};
/* Export/import reminder and planner data. Uploaded audio files are stored separately and are not included. */
$("#backup").onclick=async()=>{const payload={app:"SmartLifeAlarm",version:2,exportedAt:new Date().toISOString(),alarms:A,planner:P,marks:MK,settings:SET,history:HIST,lang:lsg("sla_lang"),city:lsg("sla_city")};X.log("data","backup_exported",{count:A.length+P.length},"Exported");const ok=await X.download("smart-life-alarm-backup-"+today()+".json",JSON.stringify(payload,null,2),"application/json");toast(ok?(X.native?T("✓ Backup saved in Downloads","✓ बैकअप Downloads में सेव हुआ"):T("Backup file is downloading","बैकअप फ़ाइल डाउनलोड हो रही है")):T("Could not save the backup","बैकअप सेव नहीं हुआ"))};
$("#restoreFile").onchange=async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{const d=JSON.parse(await f.text());if(d.app!=="SmartLifeAlarm"||!Array.isArray(d.alarms)||!Array.isArray(d.planner))throw new Error("Invalid backup");if(!confirm("Current alarms aur planner ko backup se replace karein?"))return;A=d.alarms;P=d.planner;if(d.marks&&typeof d.marks==="object"){MK=MKC.loadMarks(d.marks);saveMK()}if(d.settings&&typeof d.settings==="object"){SET=Object.assign(defSet(),d.settings);if(!RT.has(SET.ringtone))SET.ringtone=RT.DEFAULT_ID;saveSet();applyTheme();applyClock();applyCk()}if(Array.isArray(d.history)){HIST=d.history.filter(r=>r&&r.id&&r.ts).slice(0,HC.MAX_HISTORY);saveH()}if(typeof d.city==="string")lss("sla_city",d.city);if((d.lang==="en"||d.lang==="hi")&&X.applyLang)X.applyLang(d.lang);X.refreshTimes&&X.refreshTimes();X.log("data","backup_restored",{count:A.length+P.length},"Restored");save();saveP();render();rPlan();toast("Backup restore ho gaya ✓")}catch(err){toast("Backup file valid nahi hai") }finally{e.target.value=""}};$("#backup").insertAdjacentElement("afterend",(()=>{const b=document.createElement("button");b.className="mini";b.textContent="⬆ Restore";b.type="button";b.onclick=()=>$("#restoreFile").click();return b})());
const hm=m=>{m=((m%1440)+1440)%1440;return p2(Math.floor(m/60))+":"+p2(m%60)},mn=t=>{const[h,m]=t.split(":").map(Number);return h*60+m};
const dur=(s,e)=>{const d=e-s,h=Math.floor(d/60),m=d%60;return(h?h+"h ":"")+(m?m+"m":"")};
const esc=s=>s.replace(/[<>&]/g,c=>({"<":"&lt;",">":"&gt;","&":"&amp;"}[c]));
const IC=["🌅","💧","🪥","🏋️","🧘","🍳","📚","💻","🍽️","🚶","📺","🎮","📝","😴"];
const TPL={st:[["Uthna + paani","💧",15],["Brush & fresh","🪥",30],["Exercise / Yoga","🧘",45],["Breakfast","🍳",30],["Padhai – Session 1","📚",120],["Break","🎮",20],["Padhai – Session 2","📚",90],["Lunch","🍽️",45],["Rest / Nap","😴",30],["Padhai – Session 3","📚",0,1],["Evening walk","🚶",40],["Dinner","🍽️",40],["Revision","📝",45],["Relax / Family","📺",40],["Plan tomorrow","📝",15],["Sleep","😴",0]],
wk:[["Uthna + paani","💧",15],["Brush & fresh","🪥",30],["Exercise / Yoga","🧘",40],["Breakfast","🍳",30],["Ready / Commute","🚶",45],["Deep Work","💻",150],["Break","🎮",15],["Work – Session 2","💻",120],["Lunch","🍽️",45],["Work – Session 3","💻",0,1],["Commute / Walk","🚶",45],["Dinner","🍽️",40],["Hobby / Family","📺",60],["Plan tomorrow","📝",15],["Sleep","😴",0]],
ft:[["Uthna + paani","💧",10],["Brush & fresh","🪥",20],["Workout","🏋️",60],["Protein breakfast","🍳",30],["Work / Study","💻",0,1],["Lunch","🍽️",40],["Walk","🚶",20],["Evening workout / Yoga","🧘",50],["Dinner","🍽️",40],["Stretch & relax","📺",30],["Sleep","😴",0]]};
function gen(w,sl,k,al){if(sl<=w)sl+=1440;const tp=TPL[k],fixed=tp.reduce((a,x)=>a+(x[3]?0:x[2]),0),flex=Math.max(30,sl-w-fixed);let t=w;
 return tp.map((x,i)=>{const last=i==tp.length-1,d=x[3]?flex:x[2],s=last?sl:t;let e=last?w+1440:t+d;while(e<=s)e+=1440;t+=d;return{id:Date.now()+i,s,e,title:x[0],ic:x[1],al,done:null}})}
function syncPlan(show){A=A.filter(a=>!a.pid||P.some(b=>b.id==a.pid&&b.al));
 P.filter(b=>b.al).forEach(b=>{const t=hm(b.s),task=b.title+" ka time ho gaya hai",a=A.find(x=>x.pid==b.id);
  if(a){a.t=t;a.task=task}else A.push({id:Date.now()+Math.floor(Math.random()*1e6),pid:b.id,task,t,date:today(),days:127,lang:"hi-IN",tone:"beep",en:true,last:(due({days:127,t},new Date())?today()+" "+t:undefined)})});
 A.sort((x,y)=>x.t.localeCompare(y.t));save();render();if(show)toast("✓ "+P.filter(b=>b.al).length+" alarms sync ho gaye (roz repeat)")}
function rPlan(){const n=new Date(),now=n.getHours()*60+n.getMinutes(),td=today(),L=[...P].sort((a,b)=>a.s-b.s),dn=L.filter(b=>b.done===td).length;
 const cur=L.find(b=>now>=b.s&&now<b.e)||L.find(b=>now+1440>=b.s&&now+1440<b.e),nx=L.find(b=>b.s>now),pct=L.length?Math.round(dn/L.length*100):0;
 $("#plan").innerHTML=`<div class="g pc"><div class="pr" style="--v:${pct*3.6}deg"><b class="gt">${pct}%</b></div><div><div class="mu">ABHI</div><div class="pn">${cur?cur.ic+" "+esc(cur.title):"Free time"}</div><div class="mu">Next: ${nx?nx.ic+" "+esc(nx.title)+" • "+fmt(hm(nx.s)):"—"}</div><div class="mu">${dn}/${L.length} done aaj</div></div></div><div class="row" style="justify-content:flex-start"><button class="glow" id="gen">Auto-make my day</button><button class="sn" id="sya">${T("Sync alarms","अलार्म सिंक करें")}</button></div>`+
 (L.length?`<div class="tl">`+L.map((b,i)=>`<div class="tb ${b===cur?"act":""} ${b.done===td?"dn":""}" style="--c:${COL[i%6]}"><div class="dot">${b.ic}</div><div class="g bc" data-pe="${b.id}"><div class="mu">${fmt(hm(b.s))} – ${fmt(hm(b.e))} · ${dur(b.s,b.e)}${b.al?" · "+T("Alarm","अलार्म"):""}</div><div class="pt">${esc(b.title)}</div></div><div class="ck ${b.done===td?"on":""}" data-pk="${b.id}">✓</div><button class="ib" data-pd="${b.id}" aria-label="Delete">${ic("trash")}</button></div>`).join("")+`</div>`:`<p class="mu" style="text-align:center;margin-top:34px">${T("Your timetable is empty.","आपका टाइमटेबल खाली है।")}<br>${T("Tap “Auto-make my day” to begin.","शुरू करने के लिए “मेरा दिन ऑटो बनाएँ” दबाएँ।")}</p>`)}
$("#plan").onclick=e=>{const g=id=>P.find(b=>b.id==id),t=e.target.closest("[data-pk],[data-pd],[data-pe],#gen,#sya");if(!t)return;
 if(t.id=="gen")$("#gn").classList.add("s");else if(t.id=="sya"){syncPlan(true);X.log("dayplan","alarms_synced",{count:P.filter(b=>b.al).length},"Synced")}
 else if(t.dataset.pk){const b=g(t.dataset.pk);b.done=b.done===today()?null:today();X.log("dayplan",b.done?"block_done":"block_undone",{title:b.title},b.done?"Done":"Not done");saveP();rPlan()}
 else if(t.dataset.pd){const db=g(t.dataset.pd);P=P.filter(b=>b.id!=t.dataset.pd);if(db)X.log("dayplan","block_deleted",{title:db.title,start:hm(db.s),end:hm(db.e)},"Deleted");saveP();syncPlan();rPlan()}else popen(g(t.dataset.pe))};
$("#pic").innerHTML=IC.map(i=>`<button class="q" data-i="${i}">${i}</button>`).join("");
const pcp=()=>document.querySelectorAll("#pic .q").forEach(q=>q.classList.toggle("on",q.dataset.i==pic));
$("#pic").onclick=e=>{if(e.target.dataset.i){pic=e.target.dataset.i;pcp()}};
function popen(b){pid=b?b.id:null;const n=new Date(),s0=Math.ceil((n.getHours()*60+n.getMinutes()+1)/30)*30;$("#pti").value=b?b.title:"";$("#ps").value=hm(b?b.s:s0);$("#pen").value=hm(b?b.e:s0+60);pic=b?b.ic:"📚";$("#pal").checked=b?b.al:true;pcp();$("#pe").classList.add("s")}
$("#pcn").onclick=()=>$("#pe").classList.remove("s");
$("#psv").onclick=()=>{const title=$("#pti").value.trim();if(!title){toast("Naam likho ✍️");return}if(!$("#ps").value||!$("#pen").value){toast("Time chuno ⏰");return}const s=mn($("#ps").value);let e=mn($("#pen").value);if(e<=s)e+=1440;const i=P.findIndex(x=>x.id===pid),b={id:pid||Date.now(),s,e,title,ic:pic,al:$("#pal").checked,done:i>=0?P[i].done:null};i>=0?P[i]=b:P.push(b);X.log("dayplan",i>=0?"block_edited":"block_created",{title:b.title,start:hm(b.s),end:hm(b.e)},i>=0?"Updated":"Created");saveP();syncPlan();$("#pe").classList.remove("s");rPlan();toast("✓ Block save ho gaya")};
$("#gcn").onclick=()=>$("#gn").classList.remove("s");
$("#gok").onclick=()=>{if(!$("#gw").value||!$("#gs").value){toast("Dono time chuno ⏰");return}const had=P.length;P=gen(mn($("#gw").value),mn($("#gs").value),$("#gk").value,$("#gal").checked);X.log("dayplan","timetable_created",{routine:$("#gk").value,start:$("#gw").value,end:$("#gs").value,blocks:P.length,note:had?"Replaced previous plan":undefined},"Generated");saveP();syncPlan();$("#gn").classList.remove("s");rPlan();toast("✨ Timetable ban gaya")};
document.querySelectorAll(".dk [data-tab]").forEach(b=>b.onclick=()=>{tab=b.dataset.tab;$("#alv").hidden=tab!="al";$("#plan").hidden=tab!="pl";$("#weatherView").hidden=tab!="we";$("#add").hidden=tab==="we";document.querySelectorAll(".dk [data-tab]").forEach(x=>x.classList.toggle("on",x===b));if(tab==="pl")rPlan();if(tab==="we")X.loadWeatherView&&X.loadWeatherView();scrollTo(0,0)});
/* reset */
$("#rs").onclick=()=>$("#rm").classList.add("s");$("#rx").onclick=()=>$("#rm").classList.remove("s");
$("#rm").onclick=async e=>{const r=e.target.dataset.r;if(!r)return;if(ring)end(false);X.log(r=="pl"?"dayplan":"data",r=="pl"?"timetable_deleted":"reset",{scope:r},r=="pl"?"Deleted":"Reset");
 if(r=="al"){A=[];P.forEach(b=>b.al=false);saveP();save()}
 else if(r=="pl"){P=[];saveP();A=A.filter(a=>!a.pid);save()}
 else{A=[];P=[];tones=[];MK={};saveMK();saveP();save();try{const d=await db;if(d)d.transaction("tones","readwrite").objectStore("tones").clear()}catch(x){}fillTones()}
 $("#rm").classList.remove("s");render();rPlan();toast("✨ Reset ho gaya")};
/* stars */
(()=>{const c=$("#stars"),x=c.getContext("2d");let S=[];const rs=()=>{c.width=innerWidth;c.height=innerHeight;S=[...Array(80)].map(()=>({x:Math.random()*c.width,y:Math.random()*c.height,r:Math.random()*1.4+.3,p:Math.random()*6}))};rs();addEventListener("resize",rs);
 (function f(t){x.clearRect(0,0,c.width,c.height);x.fillStyle="#fff";S.forEach(s=>{x.globalAlpha=.2+.6*Math.abs(Math.sin(t/1600+s.p));x.beginPath();x.arc(s.x,s.y,s.r,0,7);x.fill()});requestAnimationFrame(f)})(0)})();
/* ===== v10: Android app. Alarms are handed to the phone's own alarm system, so they ring (sound, voice, lock-screen)
   even when the app is closed. In a normal browser this block does nothing and the old in-page alarm is used. ===== */
(()=>{
 let NP=null;
 try{if(Capacitor.isNativePlatform())NP=registerPlugin("SmartAlarm")}catch(e){}
 if(!NP)return;
 X.native=true;X.nst={notifications:false,fullScreen:true,battery:false,reader:false};
 document.documentElement.classList.add("native");
 /* v11: files (backup / CSV) go to the phone's Downloads folder */
 X.saveNative=async(name,text,mime)=>{const r=await NP.saveFile({name,text,mime:mime||"text/plain"});return !!(r&&r.ok)};
 /* v11: TalkBack-style reader for every phone notification (needs Notification access) */
 X.nativeReader=async on=>{try{if(on){const st=await NP.getStatus();if(!st.reader){toast(T("Turn on “Smart Life Alarm” here, then come back","यहाँ “Smart Life Alarm” चालू करें, फिर वापस आएँ"));await NP.openSettings({type:"reader"})}}SET.rd=on;saveSet();await NP.setReader({on,lang:X.getLG&&X.getLG()==="hi"?"hi-IN":"en-IN"});X.log("settings","reader",{to:on?"On":"Off"},"Changed")}catch(e){console.warn("reader",e)}await refresh()};
 let ready=false,syncing=false,again=false,st=null;
 const refresh=async()=>{try{X.nst=await NP.getStatus()}catch(e){}try{X.renderSettings&&X.renderSettings()}catch(e){}};
 const drain=async()=>{let n=0;try{const r=await NP.drainEvents();for(const ev of (r&&r.events)||[]){const o=NA.applyNativeEvent(A,ev);if(!o.known)continue;n++;if(o.log)X.log(o.log.cat,o.log.act,o.log.data,o.log.status,ev.at);if(o.planId){const b=P.find(x=>x.id==o.planId);if(b){b.done=NA.ymd(ev.at);saveP()}}}}catch(e){console.warn("native events",e)}if(n){save();render();rPlan()}return n};
 const sync=async()=>{if(!ready)return;if(syncing){again=true;return}syncing=true;try{do{again=false;const r=await NP.sync({alarms:NA.toNativeAlarms(A),vibrate:!!SET.vibrate,ramp:SET.ramp!==false,speak:SET.spk!==false,h24:!!SET.h24,lang:X.getLG&&X.getLG()==="hi"?"hi":"en"});if(r&&r.pending){await drain();again=true}else X.nativeRing=true}while(again)}catch(e){console.warn("native sync",e)}syncing=false};
 X.nsync=()=>{clearTimeout(st);st=setTimeout(sync,300)};
 X.nativeFix=async()=>{const s=X.nst||{};try{
  if(!s.notifications){X.nst=await NP.requestSetup();if(!X.nst.notifications)await NP.openSettings({type:"notifications"})}
  else if(s.exact===false)await NP.openSettings({type:"exact"});
  else if(!s.fullScreen)await NP.openSettings({type:"fullscreen"});
  else if(!s.battery)await NP.openSettings({type:"battery"});
  else{await NP.test({seconds:5});toast(T("Test alarm in 5 seconds — lock your phone and wait","5 सेकंड में टेस्ट अलार्म — फ़ोन लॉक करके इंतज़ार करें"))}
 }catch(e){console.warn("native fix",e)}refresh()};
 try{NP.addListener("alarmEvent",()=>{drain().then(()=>sync())})}catch(e){}
 document.addEventListener("visibilitychange",()=>{if(!document.hidden){drain().then(()=>sync());refresh()}});
 (async()=>{await refresh();await drain();ready=true;sync();try{await NP.setReader({on:!!SET.rd,lang:X.getLG&&X.getLG()==="hi"?"hi-IN":"en-IN"})}catch(e){}if(!X.nst.notifications){try{X.nst=await NP.requestSetup()}catch(e){}refresh()}})();
})();
loadTones().then(()=>{setInterval(tick,1000);tick()});

/* menu + information */
(()=>{const dr=$("#dr"),bk=$("#bk"),mn=$("#mn"),inf=$("#inf");
const cm=o=>{dr.classList.toggle("o",o);bk.classList.toggle("o",o);mn.classList.toggle("o",o);mn.setAttribute("aria-expanded",String(o));dr.setAttribute("aria-hidden",String(!o))};
mn.onclick=()=>cm(!dr.classList.contains("o"));bk.onclick=()=>cm(false);
$("#mi").onclick=()=>{cm(false);inf.classList.add("s")};
$("#icl").onclick=()=>inf.classList.remove("s");inf.onclick=e=>{if(e.target===inf)inf.classList.remove("s")};
dr.addEventListener("click",e=>{if(e.target.closest("#mx button"))setTimeout(()=>cm(false),150)});
addEventListener("keydown",e=>{if(e.key==="Escape"){cm(false);inf.classList.remove("s")}})})();

/* ===== splash (v11: no sign-in screen — the app works fully on this device) ===== */
(()=>{const s=$("#spl");try{localStorage.setItem("sla_wel","local")}catch(e){}setTimeout(()=>{s.classList.add("x");setTimeout(()=>s.remove(),700)},1800)})();
/* ===== calendar (uses the same alarm list A) ===== */
(()=>{const CAT={p:["🏠","Personal","#4f6a82"],w:["💼","Work","#6e5470"],h:["💊","Health","#8f3b3b"],s:["📚","Study","#9a7a3a"],e:["🎉","Event","#5f7247"]},
MN=["January","February","March","April","May","June","July","August","September","October","November","December"],
cal=$("#cal"),ymd=(y,m,d)=>y+"-"+p2(m+1)+"-"+p2(d),esc=x=>String(x||"").replace(/[<&]/g,c=>c=="<"?"&lt;":"&amp;"),
catOf=a=>CAT[a.cat]?a.cat:(i=>i=="💊"||i=="🏋️"?"h":i=="📚"?"s":i=="📅"?"w":"p")(ICON(a.task)),
evs=d=>{const w=new Date(d+"T00:00:00").getDay();return A.filter(a=>a.days?(a.days>>w&1)&&(a.date||"")<=d:a.date===d).sort((x,y)=>x.t.localeCompare(y.t))},
isDone=(a,d)=>a.done===d||(a.dd||[]).includes(d),fd=k=>new Date(k+"T00:00:00").toLocaleDateString(undefined,{weekday:"short",day:"numeric",month:"short"}),
rp=a=>a.days?(a.days==127?"Every day":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].filter((_,i)=>a.days>>i&1).join(" ")):"One-time",
set=(el,h,f)=>{if(f||el._h!==h){el.innerHTML=h;el._h=h}},find=id=>A.find(x=>String(x.id)===String(id));
let vy,vm,sel=today(),ce=null,cc="p",cdays=0;
const item=k=>a=>{const c=CAT[catOf(a)],dn=isDone(a,k);return`<div class="g ci${dn?" dn":""}" style="--c:${c[2]}"><button class="ck${dn?" on":""}" data-ck="${a.id}" data-dk="${k}" aria-label="Mark done">✓</button><div class="t" data-ce="${a.id}"><div class="pt">${esc(a.task)}</div><div class="mu">${fmt(a.t)} · <span class="cdot" style="--c:${c[2]}"></span>${c[1]} · ${rp(a)}</div>${a.desc?`<div class="ds">${esc(a.desc)}</div>`:""}</div><button class="ib" data-ce="${a.id}" aria-label="Edit">${ic("edit")}</button><button class="ib" data-cdl="${a.id}" aria-label="Delete">${ic("trash")}</button></div>`};
const up=([k,a])=>{const c=CAT[catOf(a)],dn=isDone(a,k);return`<div class="g ci${dn?" dn":""}" data-ce="${a.id}" style="--c:${c[2]}"><div class="ic" style="--c:${c[2]};width:44px;height:44px">${ic("calendar")}</div><div class="t"><div class="pt">${esc(a.task)}</div><div class="mu">${fmt(a.t)} · ${fd(k)}</div></div><span class="chip">${dn?"✓ Completed":a.en?"Pending":"Off"}</span></div>`};
function calRender(dir){if(!cal.classList.contains("o"))return;$("#cmt").textContent=MN[vm]+" "+vy;
 const first=new Date(vy,vm,1).getDay(),n=new Date(vy,vm+1,0).getDate(),td=today();let h="";
 for(let i=0;i<first;i++)h+="<i></i>";
 for(let d=1;d<=n;d++){const k=ymd(vy,vm,d),cs=[...new Set(evs(k).map(catOf))].slice(0,3),ff=festFor(k);const mk=MK[k];h+=`<button class="dc${k==td?" td":""}${k==sel?" sl":""}${ff.length?" fest":""}${mk?" mk mk-"+mk.c:""}" data-k="${k}"${mk?` aria-label="${d} — ${escH(mk.n||T("Highlighted","हाइलाइट"))}"`:""}><b>${d}</b><u>${cs.map(c=>`<s style="--c:${CAT[c][2]}"></s>`).join("")}${ff.map(f=>`<s class="fs" style="--c:${f.color}"></s>`).join("")}</u></button>`}
 const g=$("#cg");set(g,h,dir);if(dir){g.classList.remove("a1","a2");void g.offsetWidth;g.classList.add(dir>0?"a1":"a2")}
 $("#cdt").textContent=new Date(sel+"T00:00:00").toLocaleDateString(undefined,{weekday:"long",day:"numeric",month:"long"});
 const m0=MK[sel];$("#chl").innerHTML=m0?`<div class="chl-on mk-${m0.c}"><span class="chl-sw"></span><span class="chl-t"><b>${escH(m0.n)||T("Highlighted date","हाइलाइट की गई तारीख")}</b><small>${escH(MKC.MARK_COLORS[m0.c][X.H&&X.H()?1:0])}</small></span><button type="button" class="sn" data-hl="1">${T("Change","बदलें")}</button></div>`:`<button type="button" class="chl-add" data-hl="1">${ic("mark")}<span>${T("Highlight this date","इस तारीख को हाइलाइट करें")}</span></button>`;
 const ML=MKC.marksInMonth(MK,vy,vm);set($("#cml"),ML.length?`<div class="cml-h">${T("Highlighted this month","इस महीने की हाइलाइट")}</div>`+ML.map(([k,m])=>`<button type="button" class="cml-i mk-${m.c}${k==sel?" on":""}" data-k="${k}"><span class="chl-sw"></span><b>${+k.slice(8)}</b><span>${escH(m.n)||T("Highlighted","हाइलाइट")}</span></button>`).join(""):"");
 const E=evs(sel);set($("#cd"),E.length?E.map(item(sel)).join(""):'<p class="mu" style="text-align:center;margin:16px 0">Is din koi reminder nahi.<br>Neeche + se add karein</p>');
 const U=[];for(let i=0;i<60&&U.length<8;i++){const d=new Date();d.setDate(d.getDate()+i);const k=ymd(d.getFullYear(),d.getMonth(),d.getDate());evs(k).forEach(a=>U.push([k,a]))}
 set($("#cu"),U.length?U.slice(0,8).map(up).join(""):'<p class="mu" style="text-align:center">Koi upcoming reminder nahi.</p>')}
const R0=render;render=function(){R0.apply(this,arguments);try{calRender()}catch(e){}};
const go=d=>{vm+=d;if(vm<0){vm=11;vy--}if(vm>11){vm=0;vy++}calRender(d)};
$("#cbtn").onclick=()=>{const n=new Date();vy=n.getFullYear();vm=n.getMonth();sel=today();cal.classList.add("o");cal.setAttribute("aria-hidden","false");calRender(1);try{renderFestCard(sel)}catch(e){}};
$("#cb").onclick=()=>{cal.classList.remove("o");cal.setAttribute("aria-hidden","true")};
$("#cp").onclick=()=>go(-1);$("#cx").onclick=()=>go(1);
function cpaint(){$("#ccat").innerHTML=Object.entries(CAT).map(([k,c])=>`<button type="button" class="q${k==cc?" on":""}" data-c="${k}"><span class="cdot" style="--c:${c[2]}"></span>${c[1]}</button>`).join("");$("#cdy").innerHTML=D.map((d,i)=>`<button type="button" class="${cdays>>i&1?"on":""}" data-i="${i}">${d}</button>`).join("")}
function cform(a,date){ce=a?a.id:null;$("#cet").textContent=a?"Edit Reminder":"New Reminder";cc=a?catOf(a):"p";cdays=a?a.days:0;const n=new Date();
 $("#ctt").value=a?a.task:"";$("#cds").value=a&&a.desc||"";$("#cdd").value=a?a.date:date;$("#ctm").value=a?a.t:p2(n.getHours())+":"+p2(n.getMinutes());$("#cvo").checked=!a||a.vo!==false;$("#cvl").value=a?a.lang:"hi-IN";cpaint();$("#ce").classList.add("s")}
$("#ccat").onclick=e=>{const k=e.target.dataset.c;if(k){cc=k;cpaint()}};$("#cdy").onclick=e=>{const i=e.target.dataset.i;if(i!=null){cdays^=1<<i;cpaint()}};
$("#ccn").onclick=()=>$("#ce").classList.remove("s");
$("#cf").onclick=()=>{cform(null,sel);try{Notification.requestPermission()}catch(e){}};
$("#csv").onclick=()=>{const task=$("#ctt").value.trim(),t=$("#ctm").value,date=$("#cdd").value;if(!task){toast("Pehle title likho ✍️");return}if(!t){toast("Time chuno ⏰");return}if(!date){toast("Date chuno 📅");return}
 const old=find(ce),a=Object.assign({},old||{},{id:old?old.id:Date.now(),task,desc:$("#cds").value.trim(),cat:cc,t,date,days:cdays,lang:$("#cvl").value,vo:$("#cvo").checked,tone:(old&&old.tone)||("rt:"+SET.ringtone),en:true,cal:1,last:null,snz:null});
 if(!a.days&&!nextT(a)){toast("Future date/time chuno 📅");return}
 if(old)A[A.indexOf(old)]=a;else A.push(a);X.log("calendar",old?"edited":"created",{task:a.task,time:a.t,date:a.date,repeat:a.days},old?"Updated":"Created");save();sel=date;vy=+date.slice(0,4);vm=+date.slice(5,7)-1;$("#ce").classList.remove("s");render();calRender(1);toast(old?"Reminder + alarm update ✓":"Reminder + alarm save ✓")};
const hls=$("#hls");let hlC=MKC.DEFAULT_MARK_COLOR;
const hlPaint=()=>{$("#hlsC").innerHTML=MKC.MARK_COLOR_IDS.map(c=>`<button type="button" role="radio" aria-checked="${c===hlC}" class="hl-c mk-${c}${c===hlC?" on":""}" data-hc="${c}"><span class="chl-sw"></span>${escH(MKC.MARK_COLORS[c][X.H&&X.H()?1:0])}</button>`).join("")};
const hlOpen=()=>{const m=MK[sel];hlC=m?m.c:MKC.DEFAULT_MARK_COLOR;$("#hlsT").textContent=m?T("Edit highlight","हाइलाइट बदलें"):T("Highlight date","तारीख हाइलाइट करें");$("#hlsD").textContent=new Date(sel+"T00:00:00").toLocaleDateString(X.H&&X.H()?"hi-IN":undefined,{weekday:"long",day:"numeric",month:"long",year:"numeric"});$("#hlsNL").textContent=T("Label (optional)","नाम (वैकल्पिक)");$("#hlsN").placeholder=T("e.g. Birthday, Exam, Trip","जैसे जन्मदिन, परीक्षा, यात्रा");$("#hlsN").value=m?m.n:"";$("#hlsR").hidden=!m;$("#hlsR").textContent=T("Remove","हटाएँ");$("#hlsX").textContent=T("Cancel","रद्द करें");$("#hlsS").textContent=T("Save","सेव करें");hlPaint();hls.classList.add("s")};
$("#hlsC").onclick=e=>{const b=e.target.closest("[data-hc]");if(b){hlC=b.dataset.hc;hlPaint()}};
$("#hlsX").onclick=()=>hls.classList.remove("s");hls.onclick=e=>{if(e.target===hls)hls.classList.remove("s")};
$("#hlsS").onclick=()=>{const was=MK[sel];MK=MKC.setMark(MK,sel,{c:hlC,n:$("#hlsN").value});const m=MK[sel];if(!m)return;saveMK();X.log("calendar",was?"highlight_edited":"highlighted",{title:m.n||undefined,date:sel,to:MKC.MARK_COLORS[m.c][0]},was?"Updated":"Highlighted");hls.classList.remove("s");calRender();toast(was?T("Highlight updated","हाइलाइट बदली"):T("Date highlighted","तारीख हाइलाइट हुई"))};
$("#hlsR").onclick=()=>{const was=MK[sel];if(!was)return;MK=MKC.removeMark(MK,sel);saveMK();X.log("calendar","unhighlighted",{title:was.n||undefined,date:sel},"Removed");hls.classList.remove("s");calRender();toast(T("Highlight removed","हाइलाइट हटाई"))};
X.calRender=()=>{try{calRender()}catch(e){}};
cal.addEventListener("click",e=>{const q=s=>e.target.closest(s);let b;
 if(q("[data-hl]")){hlOpen();return}
 if(b=q("[data-k]")){sel=b.dataset.k;calRender();return}
 if(b=q("[data-ck]")){const a=find(b.dataset.ck),k=b.dataset.dk;if(!a)return;let dd=a.dd||[];if(isDone(a,k)){dd=dd.filter(x=>x!=k);if(a.done===k)a.done=null}else{dd.push(k);if(k==today())a.done=k}a.dd=dd;X.log("calendar",isDone(a,k)?"done":"undone",{task:a.task,date:k},isDone(a,k)?"Done":"Not done");save();render();return}
 if(b=q("[data-cdl]")){const a=find(b.dataset.cdl);if(a&&confirm("Ye reminder aur uska alarm delete karein?")){A.splice(A.indexOf(a),1);X.log("calendar","deleted",{task:a.task,time:a.t,date:a.date},"Deleted");save();render();toast("Reminder + alarm delete ho gaya")}return}
 if(b=q("[data-ce]")){const a=find(b.dataset.ce);if(a)cform(a)}});
})();

/* ===== v3: language (en/hi), LifeMate AI, login, particles ===== */
(()=>{const E=`Alarms||अलार्म
Day Plan||दिन की योजना
Login||लॉगिन
Weather||मौसम
NEXT||अगला
TODAY||आज
DONE||पूरा
None||कोई नहीं
Today||आज
Other reminders||अन्य रिमाइंडर
All reminders||सभी रिमाइंडर
Every day||हर दिन
One-time||एक बार
Abhi koi reminder nahi.|No reminders yet.|अभी कोई रिमाइंडर नहीं।
Neeche + dabakar banayein|Tap + to create one|+ दबाकर बनाएँ
New Reminder||नया रिमाइंडर
Edit Reminder||रिमाइंडर बदलें
Repeat (none = one-time)||दोहराएँ (कोई नहीं = एक बार)
Voice||आवाज़
Alarm tone||अलार्म टोन
Phone se song chuno|Choose a song from phone|फ़ोन से गाना चुनें
Cancel||रद्द करें
Test||टेस्ट
Save||सेव करें
Close||बंद करें
Brush karne ka time ho gaya hai|Time to brush your teeth|ब्रश करने का समय हो गया है
Time Block||टाइम ब्लॉक
Kya karna hai? (e.g. Gym)|What to do? (e.g. Gym)|क्या करना है? (जैसे जिम)
Start → End||शुरू → खत्म
Start par alarm + voice|Alarm + voice at start|शुरू पर अलार्म + आवाज़
Auto-make my day||मेरा दिन ऑटो बनाएँ
Uthne ka time|Wake-up time|उठने का समय
Sone ka time|Bedtime|सोने का समय
Routine type||रूटीन का प्रकार
Student||विद्यार्थी
Working||नौकरीपेशा
Fitness||फिटनेस
Har block par alarm|Alarm on every block|हर ब्लॉक पर अलार्म
Create||बनाएँ
Reset||रीसेट
Reset karein?|Reset?|रीसेट करें?
Kya reset karna hai chuno|Choose what to reset|चुनें क्या रीसेट करना है
Sirf Alarms|Alarms only|सिर्फ़ अलार्म
Sirf Day Plan|Day Plan only|सिर्फ़ दिन की योजना
Sab kuch (songs bhi)|Everything (songs too)|सब कुछ (गाने भी)
STOP||रोकें
Snooze 5 min||5 मिनट स्नूज़
Snooze 10 min||10 मिनट स्नूज़
Alarm ke liye ye tab khula & screen on rakhein.|Keep this tab open & screen on for alarms.|अलार्म के लिए यह टैब खुला और स्क्रीन ऑन रखें।
Menu||मेन्यू
Information||जानकारी
Help||मदद
Language||भाषा
History||इतिहास
Settings||सेटिंग्स
Theme||थीम
Account||अकाउंट
⬇ Backup||⬇ बैकअप
⬆ Restore||⬆ रीस्टोर
＋ Install||＋ इंस्टॉल
Smart Calendar||स्मार्ट कैलेंडर
Dates, reminders & upcoming events||तारीखें, रिमाइंडर और आने वाले इवेंट
Upcoming Reminders||आने वाले रिमाइंडर
Is din koi reminder nahi.|No reminders on this day.|इस दिन कोई रिमाइंडर नहीं।
Neeche + se add karein|Tap + to add one|+ से जोड़ें
Koi upcoming reminder nahi.|No upcoming reminders.|कोई आने वाला रिमाइंडर नहीं।
Reminder title||रिमाइंडर का शीर्षक
Description (optional)||विवरण (वैकल्पिक)
Voice announcement||आवाज़ में घोषणा
Pending||बाकी
✓ Completed||✓ पूरा
Off||बंद
✓ Done||✓ पूरा
Personal||निजी
Work||काम
Health||स्वास्थ्य
Study||पढ़ाई
Event||इवेंट
Sunday||रविवार
Monday||सोमवार
Tuesday||मंगलवार
Wednesday||बुधवार
Thursday||गुरुवार
Friday||शुक्रवार
Saturday||शनिवार
Sun||रवि
Mon||सोम
Tue||मंगल
Wed||बुध
Thu||गुरु
Fri||शुक्र
Sat||शनि
January||जनवरी
February||फ़रवरी
March||मार्च
April||अप्रैल
May||मई
June||जून
July||जुलाई
August||अगस्त
September||सितंबर
October||अक्तूबर
November||नवंबर
December||दिसंबर
Jan||जन
Feb||फ़र
Mar||मार्च
Apr||अप्रै
Jun||जून
Jul||जुल
Aug||अग
Sep||सित
Oct||अक्तू
Nov||नव
Dec||दिस
ABOUT SMART LIFE ALARM||स्मार्ट लाइफ अलार्म के बारे में
Smart Life Alarm is a smart and personalized reminder application designed to make daily life easier and more organized.||स्मार्ट लाइफ अलार्म एक स्मार्ट और पर्सनलाइज़्ड रिमाइंडर ऐप है, जो रोज़मर्रा की ज़िंदगी को आसान और व्यवस्थित बनाने के लिए बनाया गया है।
Created by Rudra.||निर्माता: रुद्र।
Developed under WebCreatorHub.||WebCreatorHub के अंतर्गत विकसित।
PRIVACY FIRST||प्राइवेसी सबसे पहले
Your privacy matters to us. This application does not request unnecessary permissions. Only necessary notification permission is requested for delivering reminders and notifications.||आपकी प्राइवेसी हमारे लिए मायने रखती है। यह ऐप अनावश्यक अनुमतियाँ नहीं माँगता। रिमाइंडर और नोटिफ़िकेशन भेजने के लिए केवल ज़रूरी नोटिफ़िकेशन अनुमति माँगी जाती है।
Stay organized. Stay productive. Make every moment count.||व्यवस्थित रहें। उत्पादक रहें। हर पल को खास बनाएँ।
Make every moment count||हर पल को खास बनाएँ
Welcome to Smart Life Alarm||स्मार्ट लाइफ अलार्म में आपका स्वागत है
Smart reminders, voice alerts and a calendar for your day.||स्मार्ट रिमाइंडर, वॉइस अलर्ट और आपके दिन के लिए कैलेंडर।
Continue with Google||Google से जारी रखें
Skip for Now||अभी छोड़ें
Welcome Back!||वापसी पर स्वागत है!
Sign in to make your daily routine smarter.||अपनी दिनचर्या को स्मार्ट बनाने के लिए साइन इन करें।
or||या
Email||ईमेल
Password||पासवर्ड
Sign in||साइन इन
Email login is a visual preview.||ईमेल लॉगिन अभी केवल प्रीव्यू है।
You can use the app without logging in.||आप बिना लॉगिन किए भी ऐप इस्तेमाल कर सकते हैं।
Your smart life assistant||आपका स्मार्ट लाइफ असिस्टेंट
Hi! I’m LifeMate AI||नमस्ते! मैं LifeMate AI हूँ
Ask me about weather, alarms, festivals or anything else.||मुझसे मौसम, अलार्म, त्योहार या कुछ भी पूछें।
Weather Assistant||मौसम असिस्टेंट
Current weather · Temperature · Rain · Forecast||मौजूदा मौसम · तापमान · बारिश · पूर्वानुमान
Alarm Assistant||अलार्म असिस्टेंट
Alarm tips · Reminders · Date & time · Routine||अलार्म सुझाव · रिमाइंडर · तारीख़ और समय · रूटीन
Festival Assistant||त्योहार असिस्टेंट
Indian festivals · Dates · Holidays · Traditions||भारतीय त्योहार · तारीखें · छुट्टियाँ · परंपराएँ
General Assistant||जनरल असिस्टेंट
Questions · Productivity · App help||सवाल · प्रोडक्टिविटी · ऐप मदद
What’s the weather today?||आज मौसम कैसा है?
Which festival is coming next?||अगला त्योहार कौन सा है?
Help me plan my day.||मेरा दिन प्लान करने में मदद करो।
Tell me about my alarms.||मेरे अलार्म के बारे में बताओ।
Ask LifeMate AI…||LifeMate AI से पूछें…
Preview mode: sample responses. Real AI coming soon.||प्रीव्यू मोड: सैंपल जवाब। असली AI जल्द आएगा।
Voice input coming soon||वॉइस इनपुट जल्द आएगा
Google sign-in is coming soon (preview only).||Google साइन-इन जल्द आएगा (सिर्फ़ प्रीव्यू)।
Email login is coming soon (preview only).||ईमेल लॉगिन जल्द आएगा (सिर्फ़ प्रीव्यू)।`.split("\n").map(l=>l.split("|")),PL="Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sun,Mon,Tue,Wed,Thu,Fri,Sat,January,February,March,April,May,June,July,August,September,October,November,December,Jan,Feb,Mar,Apr,Jun,Jul,Aug,Sep,Oct,Nov,Dec,Every day,One-time,Personal,Work,Health,Study,Event".split(","),SK=/^(SCRIPT|STYLE|TEXTAREA)$/;
let LG="en";try{LG=localStorage.getItem("sla_lang")||"en"}catch(e){}
let M,PR,PM;const H=()=>LG=="hi";
const esc=x=>x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
function build(){const i=H()?2:1;M=new Map(E.map(e=>[e[0],e[i]||e[0]]));PM=new Map(PL.map(k=>[k,M.get(k)]));PR=new RegExp("(?<![A-Za-z])("+[...PL].sort((a,b)=>b.length-a.length).map(esc).join("|")+")(?![A-Za-z])","g")}
const tr=v=>{const t=v.trim();return M.has(t)?v.replace(t,M.get(t)):v.replace(PR,m=>PM.get(m))};
function tn(n){const p=n.parentElement;if(!p||SK.test(p.tagName)||p.closest(".tk,.pt,.pn,.ds,.bb,.notr"))return;const v=n.nodeValue,s=n.__t!==undefined&&v===n.__t?n.__o:v,o=tr(s);n.__o=s;n.__t=o;if(o!==v)n.nodeValue=o}
const walk=r=>{const w=document.createTreeWalker(r,4);while(w.nextNode())tn(w.currentNode)};
const ph=()=>document.querySelectorAll("[placeholder]").forEach(e=>{e.dataset.po=e.dataset.po||e.placeholder;e.placeholder=M.get(e.dataset.po)||e.dataset.po});
function applyLang(l){LG=l;try{localStorage.setItem("sla_lang",l)}catch(e){}build();document.documentElement.lang=l;walk(document.body);ph();if(typeof weatherCopy==="function")weatherCopy();X.onLang&&X.onLang();
 document.querySelectorAll(".wd span").forEach((x,i)=>x.textContent=(H()?["र","सो","मं","बु","गु","शु","श"]:["S","M","T","W","T","F","S"])[i]);
 document.querySelectorAll(".lc").forEach(c=>c.classList.toggle("on",c.dataset.lg==l))}
new MutationObserver(ms=>{for(const m of ms){if(m.type=="characterData")tn(m.target);else m.addedNodes.forEach(x=>{if(x.nodeType==3)tn(x);else if(x.nodeType==1)walk(x)})}}).observe(document.body,{childList:true,subtree:true,characterData:true});
/* language modal */
$("#ml").onclick=()=>{$("#mn").click();$("#lm").classList.add("s")};$("#lmc").onclick=()=>$("#lm").classList.remove("s");$("#lm").onclick=e=>{if(e.target.id=="lm")$("#lm").classList.remove("s");const c=e.target.closest(".lc");if(c){const was=LG;applyLang(c.dataset.lg);if(was!==LG){X.log("settings","language",{from:was=="hi"?"हिंदी":"English",to:LG=="hi"?"हिंदी":"English"},"Changed");X.changed&&X.changed()}setTimeout(()=>$("#lm").classList.remove("s"),350)}};
const sc=(el,o)=>{el.classList.toggle("o",o);el.setAttribute("aria-hidden",String(!o))};


/* ========== LifeMate AI — Advanced (v4) ==========
 * Real weather via Open-Meteo (no key). Festival data verified.
 * Modular AI: set AI_ENDPOINT to your secure backend proxy that holds the API key.
 * Never put secret keys in this frontend file.
 */
const safeStoreGet = (key, fallback="") => { try { return localStorage.getItem(key) ?? fallback; } catch (_) { return fallback; } };
const AI_ENDPOINT = safeStoreGet("sla_ai_endpoint", "").trim(); // secure backend proxy URL; never put API keys here
const AI_TIMEOUT_MS = 25000;
var FESTIVALS = [{"id": "ms26", "date": "2026-01-14", "en": "Makar Sankranti", "hi": "मकर संक्रांति", "cat": "hindu", "color": "#a7802f", "desc_en": "Harvest festival marking the Sun's entry into Capricorn (Uttarayan). People take holy baths, exchange til-gud, fly kites and give charity.", "desc_hi": "सूर्य के मकर राशि में प्रवेश (उत्तरायण) का पर्व। पवित्र स्नान, तिल-गुड़, पतंगबाज़ी और दान का दिन।", "trad_en": "Til-gud, khichdi, kite flying, Ganga snan.", "trad_hi": "तिल-गुड़, खिचड़ी, पतंगबाज़ी, गंगा स्नान।"}, {"id": "vp26", "date": "2026-01-23", "en": "Vasant Panchami", "hi": "वसंत पंचमी", "cat": "hindu", "color": "#a7802f", "desc_en": "Spring festival dedicated to Goddess Saraswati, deity of knowledge, music and arts.", "desc_hi": "ज्ञान, संगीत और कला की देवी सरस्वती को समर्पित वसंत का पर्व।", "trad_en": "Saraswati Puja, yellow attire.", "trad_hi": "सरस्वती पूजा, पीले वस्त्र।"}, {"id": "msv26", "date": "2026-02-15", "en": "Maha Shivaratri", "hi": "महा शिवरात्रि", "cat": "hindu", "color": "#6e5470", "desc_en": "Great Night of Shiva. Devotees fast, stay awake and offer bilva leaves and milk.", "desc_hi": "भगवान शिव की महा रात्रि। व्रत, जागरण, बिल्व पत्र और दूध का अर्पण।", "trad_en": "Night vigil, fasting, temple visits.", "trad_hi": "रात्रि जागरण, व्रत, मंदिर दर्शन।"}, {"id": "holi26", "date": "2026-03-04", "en": "Holi", "hi": "होली", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Festival of colours celebrating victory of good over evil and arrival of spring.", "desc_hi": "रंगों का पर्व, बुराई पर अच्छाई की विजय और वसंत का स्वागत।", "trad_en": "Colours, gujiya, Holika Dahan.", "trad_hi": "रंग, गुजिया, होलिका दहन।"}, {"id": "rn26", "date": "2026-03-26", "en": "Ram Navami", "hi": "राम नवमी", "cat": "hindu", "color": "#4f6a82", "desc_en": "Birth anniversary of Lord Rama. Observed with fasting, kirtan and Ramayana readings.", "desc_hi": "भगवान राम का जन्मदिन। व्रत, कीर्तन और रामायण पाठ।", "trad_en": "Temple visits, Ramayana path.", "trad_hi": "मंदिर दर्शन, रामायण पाठ।"}, {"id": "mj26", "date": "2026-03-31", "en": "Mahavir Jayanti", "hi": "महावीर जयंती", "cat": "jain", "color": "#5f7247", "desc_en": "Birth of Lord Mahavira, 24th Tirthankara of Jainism.", "desc_hi": "जैन धर्म के २४वें तीर्थंकर भगवान महावीर का जन्मदिन।", "trad_en": "Processions, charity, non-violence.", "trad_hi": "शोभायात्रा, दान, अहिंसा।"}, {"id": "bp26", "date": "2026-05-01", "en": "Buddha Purnima", "hi": "बुद्ध पूर्णिमा", "cat": "buddhist", "color": "#56708a", "desc_en": "Birth, enlightenment and Mahaparinirvana of Gautama Buddha.", "desc_hi": "गौतम बुद्ध का जन्म, ज्ञान और महापरिनिर्वाण।", "trad_en": "Meditation, charity, lamps.", "trad_hi": "ध्यान, दान, दीप।"}, {"id": "gp26", "date": "2026-07-10", "en": "Guru Purnima", "hi": "गुरु पूर्णिमा", "cat": "hindu", "color": "#a7802f", "desc_en": "Day to honour spiritual and academic teachers (gurus).", "desc_hi": "गुरुजनों के सम्मान का दिन।", "trad_en": "Guru dakshina, satsang.", "trad_hi": "गुरु दक्षिणा, सत्संग।"}, {"id": "rb26", "date": "2026-08-28", "en": "Raksha Bandhan", "hi": "रक्षा बंधन", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Celebrates the bond between brothers and sisters; sisters tie rakhi.", "desc_hi": "भाई-बहन के स्नेह का पर्व; बहन राखी बाँधती है।", "trad_en": "Rakhi, sweets, gifts.", "trad_hi": "राखी, मिठाई, उपहार।"}, {"id": "jm26", "date": "2026-09-04", "en": "Janmashtami", "hi": "जन्माष्टमी", "cat": "hindu", "color": "#6e5470", "desc_en": "Birth of Lord Krishna at midnight. Fasting, bhajans and childhood re-enactments.", "desc_hi": "भगवान कृष्ण का मध्यरात्रि जन्म। व्रत, भजन और बाल लीला।", "trad_en": "Midnight aarti, dahi-handi.", "trad_hi": "मध्यरात्रि आरती, दही-हांडी।"}, {"id": "gc26", "date": "2026-09-14", "en": "Ganesh Chaturthi", "hi": "गणेश चतुर्थी", "cat": "hindu", "color": "#a7802f", "desc_en": "Birth of Lord Ganesha. Clay idols are installed, worshipped and immersed.", "desc_hi": "विघ्नहर्ता गणेश का जन्म। मूर्ति स्थापना, पूजा और विसर्जन।", "trad_en": "Ganesh idol, modak, visarjan.", "trad_hi": "गणेश मूर्ति, मोदक, विसर्जन।"}, {"id": "nav26", "date": "2026-10-11", "en": "Navratri Begins", "hi": "नवरात्रि आरंभ", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Nine nights of Goddess Durga worship (Garba, Durga Puja).", "desc_hi": "देवी दुर्गा की नौ रात्रियाँ (गरबा, दुर्गा पूजा)।", "trad_en": "Ghatasthapana, garba, fasting.", "trad_hi": "घटस्थापना, गरबा, व्रत।"}, {"id": "dus26", "date": "2026-10-20", "en": "Dussehra", "hi": "दशहरा", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Victory of Rama over Ravana; culmination of Navratri.", "desc_hi": "राम द्वारा रावण पर विजय; नवरात्रि का समापन।", "trad_en": "Ramlila, Ravana dahan.", "trad_hi": "रामलीला, रावण दहन।"}, {"id": "kc26", "date": "2026-10-29", "en": "Karwa Chauth", "hi": "करवा चौथ", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Married women fast from sunrise to moonrise for husbands' well-being.", "desc_hi": "विवाहित महिलाएँ सूर्योदय से चंद्रोदय तक पति की दीर्घायु के लिए व्रत रखती हैं।", "trad_en": "Nirjala fast, moon sighting.", "trad_hi": "निर्जला व्रत, चंद्र दर्शन।"}, {"id": "diwali26", "date": "2026-11-08", "en": "Diwali", "hi": "दिवाली", "cat": "hindu", "color": "#a7802f", "desc_en": "Festival of Lights. Lakshmi Puja, diyas and celebration of Rama's return to Ayodhya.", "desc_hi": "दीपों का पर्व। लक्ष्मी पूजा, दीये और राम के अयोध्या आगमन का उत्सव।", "trad_en": "Diyas, Lakshmi Puja, sweets, rangoli.", "trad_hi": "दीये, लक्ष्मी पूजा, मिठाई, रंगोली।"}, {"id": "chhath26", "date": "2026-11-15", "en": "Chhath Puja", "hi": "छठ पूजा", "cat": "hindu", "color": "#a7802f", "desc_en": "Four-day thanksgiving to Surya and Chhathi Maiya (Bihar, Jharkhand, eastern UP).", "desc_hi": "सूर्य देव और छठी मैया को समर्पित चार दिवसीय अर्घ्य।", "trad_en": "Nahay-Khay, Sandhya & Usha Arghya.", "trad_hi": "नहाय-खाय, संध्या व उषा अर्घ्य।"}, {"id": "gn26", "date": "2026-11-24", "en": "Guru Nanak Jayanti", "hi": "गुरु नानक जयंती", "cat": "sikh", "color": "#4f6a82", "desc_en": "Birth anniversary (Prakash Purab) of Guru Nanak Dev Ji on Kartik Purnima.", "desc_hi": "गुरु नानक देव जी का प्रकाश पर्व (कार्तिक पूर्णिमा)।", "trad_en": "Akhand Path, Nagar Kirtan, langar.", "trad_hi": "अखंड पाठ, नगर कीर्तन, लंगर।"}, {"id": "xmas26", "date": "2026-12-25", "en": "Christmas", "hi": "क्रिसमस", "cat": "christian", "color": "#5f7247", "desc_en": "Celebration of the birth of Jesus Christ.", "desc_hi": "ईसा मसीह के जन्म का उत्सव।", "trad_en": "Church services, carols, gifts.", "trad_hi": "चर्च सेवा, कैरोल, उपहार।"}, {"id": "ms27", "date": "2027-01-14", "en": "Makar Sankranti", "hi": "मकर संक्रांति", "cat": "hindu", "color": "#a7802f", "desc_en": "Harvest festival marking the Sun's entry into Capricorn.", "desc_hi": "सूर्य के मकर राशि में प्रवेश का पर्व।", "trad_en": "Til-gud, kite flying.", "trad_hi": "तिल-गुड़, पतंगबाज़ी।"}, {"id": "rd27", "date": "2027-01-26", "en": "Republic Day", "hi": "गणतंत्र दिवस", "cat": "national", "color": "#4f6a82", "desc_en": "India's Republic Day — Constitution came into effect on 26 January 1950.", "desc_hi": "भारत का गणतंत्र दिवस — २६ जनवरी १९५० को संविधान लागू।", "trad_en": "Parade, flag hoisting.", "trad_hi": "परेड, ध्वजारोहण।"}, {"id": "vp27", "date": "2027-02-11", "en": "Vasant Panchami", "hi": "वसंत पंचमी", "cat": "hindu", "color": "#a7802f", "desc_en": "Spring festival dedicated to Goddess Saraswati.", "desc_hi": "सरस्वती देवी को समर्पित वसंत पर्व।", "trad_en": "Saraswati Puja.", "trad_hi": "सरस्वती पूजा।"}, {"id": "msv27", "date": "2027-03-06", "en": "Maha Shivaratri", "hi": "महा शिवरात्रि", "cat": "hindu", "color": "#6e5470", "desc_en": "Great Night of Shiva.", "desc_hi": "भगवान शिव की महा रात्रि।", "trad_en": "Fasting, night vigil.", "trad_hi": "व्रत, जागरण।"}, {"id": "holi27", "date": "2027-03-22", "en": "Holi", "hi": "होली", "cat": "hindu", "color": "#9c4a5e", "desc_en": "Festival of colours.", "desc_hi": "रंगों का पर्व।", "trad_en": "Colours, Holika Dahan.", "trad_hi": "रंग, होलिका दहन।"}, {"id": "diwali27", "date": "2027-10-29", "en": "Diwali", "hi": "दिवाली", "cat": "hindu", "color": "#a7802f", "desc_en": "Festival of Lights — Lakshmi Puja and diyas.", "desc_hi": "दीपों का पर्व — लक्ष्मी पूजा और दीये।", "trad_en": "Diyas, Lakshmi Puja.", "trad_hi": "दीये, लक्ष्मी पूजा।"}, {"id": "gn27", "date": "2027-11-14", "en": "Guru Nanak Jayanti", "hi": "गुरु नानक जयंती", "cat": "sikh", "color": "#4f6a82", "desc_en": "Birth anniversary of Guru Nanak Dev Ji.", "desc_hi": "गुरु नानक देव जी का प्रकाश पर्व।", "trad_en": "Akhand Path, langar.", "trad_hi": "अखंड पाठ, लंगर।"}, {"id": "xmas27", "date": "2027-12-25", "en": "Christmas", "hi": "क्रिसमस", "cat": "christian", "color": "#5f7247", "desc_en": "Celebration of the birth of Jesus Christ.", "desc_hi": "ईसा मसीह के जन्म का उत्सव।", "trad_en": "Church, carols, gifts.", "trad_hi": "चर्च, कैरोल, उपहार।"}];

window.FESTIVALS = FESTIVALS; /* data ready for calendar */ const _festByDate = (() => {
  const m = new Map();
  for (const f of FESTIVALS) {
    if (!m.has(f.date)) m.set(f.date, []);
    m.get(f.date).push(f);
  }
  return m;
})();
const festName = f => H() ? f.hi : f.en;
const festDesc = f => H() ? f.desc_hi : f.desc_en;
const festTrad = f => H() ? f.trad_hi : f.trad_en;
const daysUntil = d => {
  const a = new Date(today() + "T00:00:00"), b = new Date(d + "T00:00:00");
  return Math.round((b - a) / 86400000);
};

/* Weather — Open-Meteo (genuine, free, no key) */
let weatherCache = null, weatherCacheKey = "", weatherCity = safeStoreGet("sla_city", "");
async function fetchWeather(city) {
  const requestedCity = (city || weatherCity || "New Delhi").trim();
  const cacheKey = requestedCity.toLocaleLowerCase();
  if (weatherCache && weatherCacheKey === cacheKey && Date.now() - weatherCache.at < 5 * 60 * 1000) return weatherCache;
  try {
    let lat, lon, name = requestedCity;
    if (requestedCity && requestedCity.toLowerCase() !== "new delhi") {
      const gRes = await fetch("https://geocoding-api.open-meteo.com/v1/search?name=" + encodeURIComponent(requestedCity) + "&count=1&language=" + (H()?"hi":"en") + "&format=json", {signal: AbortSignal.timeout(8000)});
      if (!gRes.ok) throw new Error("geocoding_http_" + gRes.status);
      const g = await gRes.json();
      if (!g.results || !g.results[0]) throw new Error("city");
      lat = g.results[0].latitude; lon = g.results[0].longitude;
      name = g.results[0].name + (g.results[0].admin1 ? ", " + g.results[0].admin1 : "");
    } else {
      // default Delhi if no city
      lat = 28.6139; lon = 77.2090; name = "New Delhi";
    }
    const wRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=4`, {signal: AbortSignal.timeout(10000)});
    if (!wRes.ok) throw new Error("weather_http_" + wRes.status);
    const w = await wRes.json();
    if (!w.current || !w.daily) throw new Error("weather_payload_invalid");
    weatherCache = {name, lat, lon, cur: w.current, daily: w.daily, at: Date.now()};
    weatherCacheKey = cacheKey;
    if (city) { weatherCity = name; try { localStorage.setItem("sla_city", city); } catch(e){} }
    return weatherCache;
  } catch (e) {
    console.warn("Weather fetch failed", e);
    return null;
  }
}
const WMO = {
  0:["Clear sky","साफ आसमान"],1:["Mainly clear","मुख्यतः साफ"],2:["Partly cloudy","आंशिक बादल"],3:["Overcast","घने बादल"],
  45:["Fog","कोहरा"],48:["Rime fog","पाले वाला कोहरा"],51:["Light drizzle","हल्की बूंदाबांदी"],53:["Drizzle","बूंदाबांदी"],55:["Dense drizzle","तेज़ बूंदाबांदी"],
  56:["Freezing drizzle","जमने वाली बूंदाबांदी"],57:["Freezing drizzle","जमने वाली बूंदाबांदी"],
  61:["Slight rain","हल्की बारिश"],63:["Moderate rain","मध्यम बारिश"],65:["Heavy rain","तेज बारिश"],66:["Freezing rain","जमने वाली बारिश"],67:["Freezing rain","जमने वाली बारिश"],
  71:["Slight snow","हल्की बर्फ"],73:["Snow","बर्फबारी"],75:["Heavy snow","भारी बर्फबारी"],77:["Snow grains","बर्फ के कण"],
  80:["Rain showers","बारिश की बौछारें"],81:["Heavy showers","तेज़ बौछारें"],82:["Violent showers","बहुत तेज़ बौछारें"],85:["Snow showers","बर्फ की बौछारें"],86:["Snow showers","बर्फ की बौछारें"],
  95:["Thunderstorm","आंधी-तूफान"],96:["Thunderstorm with hail","ओलों के साथ तूफ़ान"],99:["Thunderstorm with hail","ओलों के साथ तूफ़ान"]
};
function formatWeather(w) {
  if (!w) return H() ? "⚠️ मौसम डेटा अभी उपलब्ध नहीं। शहर का नाम लिखकर फिर पूछें (जैसे: दिल्ली मौसम)।" : "⚠️ Weather data unavailable. Ask again with a city name (e.g. weather in Mumbai).";
  const c = w.cur, code = c.weather_code, lab = (WMO[code] || WMO[0])[H()?1:0];
  const hi = H();
  let s = hi
    ? `🌤️ ${w.name}\n🌡️ अभी: ${Math.round(c.temperature_2m)}°C · ${lab}\n💧 नमी: ${c.relative_humidity_2m}%\n🌧️ बारिश संभावना: ${c.precipitation_probability ?? "—"}%\n💨 हवा: ${Math.round(c.wind_speed_10m)} km/h`
    : `🌤️ ${w.name}\n🌡️ Now: ${Math.round(c.temperature_2m)}°C · ${lab}\n💧 Humidity: ${c.relative_humidity_2m}%\n🌧️ Rain chance: ${c.precipitation_probability ?? "—"}%\n💨 Wind: ${Math.round(c.wind_speed_10m)} km/h`;
  if (w.daily && w.daily.time) {
    s += hi ? "\n\n📅 अगले दिन:" : "\n\n📅 Next days:";
    for (let i = 0; i < Math.min(3, w.daily.time.length); i++) {
      const d = w.daily.time[i], mx = Math.round(w.daily.temperature_2m_max[i]), mn = Math.round(w.daily.temperature_2m_min[i]);
      const pr = w.daily.precipitation_probability_max[i];
      const lab2 = (WMO[w.daily.weather_code[i]] || WMO[0])[hi?1:0];
      s += `\n• ${d.slice(5)}: ${mn}–${mx}°C, ${lab2}${pr!=null?", "+pr+"% rain":""}`;
    }
  }
  return s;
}

/* Weather tab — v11: Open-Meteo straight from the phone (free, no key, no server of our own). */
const WX_TTL=10*60*1000;
const wxCacheGet=k=>{try{const c=JSON.parse(localStorage.getItem("sla_wx_cache")||"{}")[k];return c&&c.r&&c.r.v===2&&Date.now()-c.at<WX_TTL?c.r:null}catch(e){return null}};
const wxCachePut=(k,r)=>{try{const c=JSON.parse(localStorage.getItem("sla_wx_cache")||"{}");c[k]={at:Date.now(),r};Object.keys(c).sort((a,b)=>c[b].at-c[a].at).slice(8).forEach(x=>delete c[x]);localStorage.setItem("sla_wx_cache",JSON.stringify(c))}catch(e){}};
const WX_CITY_RE=/^[\p{L}\p{M}0-9 .,'()-]+$/u;
const WXERR={
 not_found:["City not found. Check the spelling and try again.","शहर नहीं मिला। नाम जाँचें और फिर कोशिश करें।"],
 network:["Could not reach the weather service. Check your internet connection and try again.","मौसम सेवा से कनेक्ट नहीं हो सका। इंटरनेट जाँचें और फिर कोशिश करें।"],
 bad_input:["Please enter a valid city name (letters, spaces and commas only).","कृपया सही शहर का नाम लिखें।"],
 unknown:["The weather service returned an unexpected error. Please try again.","मौसम सेवा से अनपेक्षित त्रुटि मिली। फिर कोशिश करें।"]};
const WXI=c=>c===0?"☀️":c<=2?"🌤️":c===3?"☁️":c<=48?"🌫️":c<=57?"🌦️":c<=67?"🌧️":c<=77?"❄️":c<=82?"🌧️":c<=86?"🌨️":"⛈️";
const WDIR=d=>d==null?"":["N","NE","E","SE","S","SW","W","NW"][Math.round(((d%360)+360)%360/45)%8];
const wxLab=(code,hi)=>(WMO[code]||WMO[code-1]||WMO[code+1]||["—","—"])[hi?1:0];
let wxBusy=false;
function weatherCopy(){const hi=H();$("#weatherEyebrow").textContent=hi?"आपके शहर का मौसम":"LOCAL FORECAST";$("#weatherTitle").textContent=hi?"मौसम":"Weather";$("#weatherSubtitle").textContent=hi?"अभी का मौसम और पूर्वानुमान":"Current conditions and forecast";$("#weatherCity").placeholder=hi?"शहर का नाम लिखें, जैसे लखनऊ":"Enter city, e.g. Lucknow";$("#weatherGo").textContent=hi?"मौसम देखें":"Show weather";$("#weatherNote").textContent=hi?"मौसम डेटा Open-Meteo से। पूर्वानुमान बदल सकता है।":"Weather data from Open-Meteo. Forecasts may change.";}
const wxN=(v,u)=>v===null||v===undefined||Number.isNaN(v)?"—":(Math.round(v*10)/10)+(u||"");
async function wxFetch(q){
 const g=await fetch("https://geocoding-api.open-meteo.com/v1/search?name="+encodeURIComponent(q)+"&count=1&language="+(H()?"hi":"en")+"&format=json",{signal:AbortSignal.timeout(9000)});
 if(!g.ok)throw new Error("network");const gj=await g.json();const L=gj&&gj.results&&gj.results[0];if(!L)return{ok:false,code:"not_found"};
 const w=await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${L.latitude}&longitude=${L.longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,sunrise,sunset&timezone=auto&forecast_days=5`,{signal:AbortSignal.timeout(10000)});
 if(!w.ok)throw new Error("network");const d=await w.json();if(!d.current||!d.daily)return{ok:false,code:"unknown"};
 const c=d.current,D=d.daily;
 return{ok:true,v:2,fetchedAt:Date.now(),location:{name:L.name,region:L.admin1||"",country:L.country||"",localtime:String(c.time||"").replace("T"," ")},
  current:{code:c.weather_code,temperature:c.temperature_2m,feelslike:c.apparent_temperature,humidity:c.relative_humidity_2m,wind_speed:c.wind_speed_10m,wind_dir:WDIR(c.wind_direction_10m),pressure:c.pressure_msl,precip:c.precipitation,uv_index:D.uv_index_max&&D.uv_index_max[0],rain:D.precipitation_probability_max&&D.precipitation_probability_max[0],sunrise:D.sunrise&&D.sunrise[0],sunset:D.sunset&&D.sunset[0]},
  forecast:(D.time||[]).map((t,i)=>({date:t,code:D.weather_code[i],mintemp:D.temperature_2m_min[i],maxtemp:D.temperature_2m_max[i],rain:D.precipitation_probability_max?D.precipitation_probability_max[i]:null}))}}
function wxRender(r){const hi=H(),c=r.current,L=r.location,e=escH;
 const m=(ic,lab,val)=>`<div class="wx-m"><span>${ic} ${lab}</span><b>${val}</b></div>`;
 const fdate=d=>{try{return new Date(d+"T12:00:00").toLocaleDateString(hi?"hi-IN":undefined,{weekday:"short",day:"numeric",month:"short"})}catch(_){return d}};
 const tOnly=iso=>{const t=/T(\d\d:\d\d)/.exec(String(iso||""));return t?fmt(t[1]):"—"};
 const fc=r.forecast&&r.forecast.length?`<div class="wx-fc g"><div class="eyebrow">${hi?"पूर्वानुमान":"FORECAST"}</div>`+r.forecast.map(d=>`<div class="wx-day"><b>${e(fdate(d.date))}</b><span>${WXI(d.code)} ${e(wxLab(d.code,hi))}${d.rain!=null?" · "+d.rain+"%":""}</span><em>${wxN(d.mintemp,"°")} / ${wxN(d.maxtemp,"°C")}</em></div>`).join("")+`</div>`:"";
 const lt=/ (\d\d:\d\d)/.exec(L.localtime||"");
 return `<div class="wx-now g"><div class="wx-top"><div><div class="eyebrow">${hi?"अभी":"NOW"}${lt?" · "+e(fmt(lt[1])):""}</div><div class="wx-city">${e(L.name)}</div><div class="mu">${e([L.region,L.country].filter(Boolean).join(", "))}</div></div><span class="wx-ic wx-emo" aria-hidden="true">${WXI(c.code)}</span></div>
 <div class="wx-temp"><b>${wxN(c.temperature,"°")}</b><div><div class="wx-desc">${e(wxLab(c.code,hi))}</div><div class="mu">${hi?"महसूस":"Feels like"} ${wxN(c.feelslike,"°C")}</div></div></div>
 <div class="wx-grid">${m("💧",hi?"नमी":"Humidity",wxN(c.humidity,"%"))}${m("💨",hi?"हवा":"Wind",wxN(c.wind_speed," km/h")+(c.wind_dir?" "+e(c.wind_dir):""))}${m("🌧",hi?"बारिश संभावना":"Rain chance",wxN(c.rain,"%"))}${m("🌡",hi?"दबाव":"Pressure",wxN(c.pressure," hPa"))}${m("☀",hi?"UV सूचकांक":"UV index",wxN(c.uv_index))}${m("🌅",hi?"सूर्योदय / सूर्यास्त":"Sunrise / sunset",tOnly(c.sunrise)+" · "+tOnly(c.sunset))}</div>
 <div class="wx-obs mu">${hi?"अपडेट":"Updated"} ${new Date(r.fetchedAt).toLocaleTimeString(hi?"hi-IN":"en-IN",{hour:"numeric",minute:"2-digit",hour12:!SET.h24})}</div></div>`+fc}
async function loadWeatherView(city){weatherCopy();const status=$("#weatherStatus"),result=$("#weatherResult"),btn=$("#weatherGo");
 const q=String(city||weatherCity||"").trim();
 const err=code=>{const m=WXERR[code]||WXERR.unknown;status.className="weather-status error";status.textContent="⚠️ "+m[H()?1:0];result.hidden=true};
 const show=r=>{weatherCity=r.location.name;try{localStorage.setItem("sla_city",q)}catch(_){}status.className="weather-status ok";status.textContent=(H()?"मौसम अपडेट: ":"Weather updated: ")+r.location.name;result.className="weather-result rich notr";result.innerHTML=wxRender(r);result.hidden=false;$("#weatherCity").value=q};
 if(!q){status.className="weather-status";status.textContent=H()?"मौसम देखने के लिए शहर का नाम लिखें।":"Enter a city to see the latest weather.";result.hidden=true;return}
 if(!WX_CITY_RE.test(q)||q.length>80){err("bad_input");return}
 if(wxBusy)return;
 const key=q.toLocaleLowerCase()+"|"+(H()?"hi":"en"),cached=wxCacheGet(key);if(cached){show(cached);return}
 wxBusy=true;status.className="weather-status loading";status.textContent=H()?"मौसम की जानकारी लोड हो रही है…":"Loading the latest weather…";result.hidden=true;btn.disabled=true;
 try{if(navigator.onLine===false){err("network");return}
  const r=await wxFetch(q);
  if(!r||!r.ok){err(r&&r.code||"unknown");return}
  wxCachePut(key,r);show(r)}
 catch(e){console.warn("Weather request failed",e);err("network")}
 finally{wxBusy=false;btn.disabled=false}}
X.loadWeatherView=loadWeatherView;
$("#weatherForm").addEventListener("submit",e=>{e.preventDefault();const city=$("#weatherCity").value.trim();if(!city){$("#weatherStatus").className="weather-status error";$("#weatherStatus").textContent=H()?"कृपया शहर का नाम लिखें।":"Please enter a city name.";return;}loadWeatherView(city)});


/* Conversation memory (session) */
const chatHistory = [];
const MAX_HISTORY = 12;

function localSmartReply(q) {
  const low = q.toLowerCase();
  const hi = H();
  // Weather
  if (/weather|mausam|temperature|rain|barish|forecast|मौसम|बारिश|तापमान|humidity|नमी/i.test(q)) {
    const cityMatch = q.match(/(?:in|at|for|में|का|की)\s+([A-Za-z\u0900-\u097F\s]{2,30})/i) || q.match(/^([A-Za-z\u0900-\u097F\s]{2,20})\s+(?:weather|mausam|मौसम)/i);
    const city = cityMatch ? cityMatch[1].trim() : weatherCity;
    return {async: true, run: async () => {
      const w = await fetchWeather(city || weatherCity || "Delhi");
      return formatWeather(w);
    }};
  }
  // Festivals
  if (/festival|tyohar|diwali|holi|eid|त्योहार|दिवाली|होली|navratri|dussehra|janmashtami|ganesh|chhath|guru nanak|christmas|shivaratri|sankranti/i.test(q)) {
    const upcoming = FESTIVALS.filter(f => f.date >= today()).slice(0, 5);
    if (!upcoming.length) return hi ? "अभी सूची में आगामी प्रमुख त्योहार नहीं।" : "No upcoming major festivals in the list.";
    let s = hi ? "🎉 आगामी प्रमुख त्योहार:\n" : "🎉 Upcoming major festivals:\n";
    for (const f of upcoming) {
      const du = daysUntil(f.date);
      s += `• ${festName(f)} — ${f.date}` + (du === 0 ? (hi?" (आज!)":" (today!)") : du > 0 ? (hi?` (${du} दिन बाद)`:` (in ${du} days)`) : "") + "\n";
    }
    s += hi ? "\nकिसी तारीख पर कैलेंडर में टैप करें विस्तृत जानकारी के लिए।" : "\nTap a date on the Smart Calendar for full details.";
    return s;
  }
  // Alarms / reminders
  if (/alarm|reminder|अलार्म|रिमाइंडर|अगला अलार्म|next alarm/i.test(q)) {
    const on = A.filter(a => a.en !== false);
    const nx = on.map(a => [nextT(a), a]).filter(x => x[0]).sort((x,y) => x[0]-y[0])[0];
    let s = hi
      ? `⏰ आपके पास ${A.length} अलार्म हैं (${on.length} चालू)।`
      : `⏰ You have ${A.length} alarm(s), ${on.length} active.`;
    if (nx) {
      const rem = Math.max(0, Math.round((nx[0] - Date.now())/60000));
      s += hi
        ? `\nअगला: “${nx[1].task}” — ${fmt(nx[1].t)} (${rem} मिनट में)`
        : `\nNext: “${nx[1].task}” at ${fmt(nx[1].t)} (in ${rem} min)`;
    } else s += hi ? "\nकोई आने वाला अलार्म नहीं।" : "\nNo upcoming alarms.";
    s += hi
      ? "\n\nसुझाव: दवाई, पानी और व्यायाम के लिए दोहराने वाले अलार्म लगाएँ। नया अलार्म + बटन से बनाएँ।"
      : "\n\nTip: set repeating alarms for medicine, water and exercise. Use the + button to create one.";
    return s;
  }
  // Date / time
  if (/time|date|samay|तारीख|समय|आज|today|abhi|अभी|day of week|weekday/i.test(q)) {
    const d = new Date(), l = hi ? "hi-IN" : "en-IN";
    return (hi ? "🕒 अभी: " : "🕒 Now: ") + d.toLocaleString(l, {weekday:"long", day:"numeric", month:"long", year:"numeric", hour:"numeric", minute:"2-digit", hour12:!SET.h24});
  }
  // Plan / routine
  if (/plan|routine|day|दिन|रूटीन|प्लान|schedule|सुझाव/i.test(q)) {
    return hi
      ? "🗓️ सुझाया गया दिन:\n"+fmt("06:30")+" उठना और पानी 💧\n"+fmt("07:00")+" व्यायाम 🏋️\n"+fmt("09:00")+" फोकस काम 💼\n"+fmt("13:00")+" खाना 🍽️\n"+fmt("18:00")+" पढ़ाई/शौक 📚\n"+fmt("22:30")+" सोना 😴\n\nDay Plan में ‘मेरा दिन ऑटो बनाएँ’ से अलार्म बना सकते हैं। पुष्टि के बाद ही अलार्म जुड़ेंगे।"
      : "🗓️ Suggested day:\n"+fmt("06:30")+" Wake up & water 💧\n"+fmt("07:00")+" Exercise 🏋️\n"+fmt("09:00")+" Focus work 💼\n"+fmt("13:00")+" Lunch 🍽️\n"+fmt("18:00")+" Study / hobby 📚\n"+fmt("22:30")+" Sleep 😴\n\nUse ‘Auto-make my day’ in Day Plan. Alarms are only created after you confirm.";
  }
  // Help
  if (/help|how|use|app|मदद|कैसे|guide/i.test(q)) {
    return hi
      ? "ℹ️ Smart Life Alarm कैसे उपयोग करें:\n• + से नया अलार्म\n• Smart Calendar से तारीख व त्योहार\n• Day Plan से रूटीन\n• ☰ मेन्यू → Language / Information\n• LifeMate से मौसम, त्योहार, अलार्म पूछें"
      : "ℹ️ How to use Smart Life Alarm:\n• + for new alarm\n• Smart Calendar for dates & festivals\n• Day Plan for routines\n• ☰ menu → Language / Information\n• Ask LifeMate about weather, festivals, alarms";
  }
  // Productivity tip
  if (/tip|productiv|focus|प्रोडक्टिविटी|टिप|motivat/i.test(q)) {
    return hi
      ? "💡 टिप: दिन के 3 सबसे ज़रूरी काम चुनें, हर एक के लिए अलार्म लगाएँ, और 25 मिनट फोकस + 5 मिनट ब्रेक (पोमोडोरो) आज़माएँ।"
      : "💡 Tip: pick your 3 most important tasks, set an alarm for each, and try 25 min focus + 5 min break (Pomodoro).";
  }
  // Greeting
  if (/^(hi|hello|hey|namaste|नमस्ते|हेलो|good morning|good evening|सुप्रभात)/i.test(q.trim())) {
    return hi
      ? "नमस्ते! 👋 मैं LifeMate हूँ — आपका स्मार्ट सहायक। मौसम, त्योहार, अलार्म या दिन की योजना पूछ सकते हैं।"
      : "Hello! 👋 I'm LifeMate — your smart assistant. Ask me about weather, festivals, alarms or your day plan.";
  }
  // Default — honest about capabilities
  if (AI_ENDPOINT) {
    return {async: true, run: async () => callRemoteAI(q)};
  }
  return hi
    ? "🤖 मैं मौसम (लाइव), त्योहार, अलार्म, तारीख और दिन योजना पर मदद कर सकता हूँ।\n\nसामान्य ज्ञान के लिए असली LLM जोड़ने हेतु README में AI_ENDPOINT सेट करें (API कुंजी सर्वर पर रखें)।\n\nकुछ आज़माएँ: “दिल्ली मौसम”, “अगला त्योहार”, “मेरे अलार्म”।"
    : "🤖 I can help with live weather, festivals, alarms, date/time and day planning.\n\nFor full general AI, set AI_ENDPOINT (see README) so the API key stays on your server.\n\nTry: “weather in Mumbai”, “next festival”, “my alarms”.";
}

async function callRemoteAI(q) {
  if (!AI_ENDPOINT) throw new Error("AI endpoint is not configured");
  let endpoint;
  try { endpoint = new URL(AI_ENDPOINT, location.href); }
  catch (_) { throw new Error("AI endpoint URL is invalid"); }
  if (endpoint.protocol !== "https:" && endpoint.hostname !== "localhost" && endpoint.hostname !== "127.0.0.1") {
    throw new Error("AI endpoint must use HTTPS");
  }
  const ctrl = new AbortController();
  const to = setTimeout(() => ctrl.abort(), AI_TIMEOUT_MS);
  try {
    const messages = chatHistory.slice(-MAX_HISTORY).map(m => ({role: m.role, content: m.text}));
    messages.push({role: "user", content: q});
    const res = await fetch(endpoint.href, {
      method: "POST",
      headers: {"Content-Type": "application/json", "Accept": "application/json"},
      body: JSON.stringify({messages, lang: LG}),
      signal: ctrl.signal
    });
    if (!res.ok) throw new Error("AI server returned HTTP " + res.status);
    const data = await res.json();
    const reply = data.reply || data.content || data.message || data.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) throw new Error("AI server returned an empty reply");
    return reply.trim();
  } catch (e) {
    console.warn("AI endpoint error", e);
    if (e.name === "AbortError") return H()
      ? "⚠️ AI जवाब देने में अधिक समय ले रहा है। कृपया फिर कोशिश करें।"
      : "⚠️ The AI request timed out. Please try again.";
    return H()
      ? "⚠️ AI सर्वर से जवाब नहीं मिला। इंटरनेट और सर्वर सेटिंग जाँचें, फिर दोबारा कोशिश करें।"
      : "⚠️ Could not reach the AI server. Check your internet and server settings, then try again.";
  } finally { clearTimeout(to); }
}

const hp = $("#hp"), ms = $("#msgs"), inp = $("#hi"), hs = $("#hsc");
$("#mhp").onclick = () => { $("#mn").click(); sc(hp, true); };
$("#hbk").onclick = () => sc(hp, false);

function scrollChat() { hs.scrollTo({top: hs.scrollHeight, behavior: "smooth"}); }

function addBubble(text, who, opts = {}) {
  const d = document.createElement("div");
  d.className = "bb " + who;
  if (who === "a") {
    d.innerHTML = '<span class="mo"></span><div class="tx"></div>';
    const tx = d.querySelector(".tx");
    if (opts.typing) {
      tx.className = "tx dots";
      tx.innerHTML = "<i></i><i></i><i></i>";
    } else {
      tx.textContent = text;
    }
  } else {
    d.textContent = text;
  }
  ms.appendChild(d);
  scrollChat();
  return d;
}

let aiBusy = false;
async function send(q) {
  q = (q || "").trim();
  if (!q || aiBusy) return;
  aiBusy = true;
  const sendBtn = $("#hsd");
  if (sendBtn) sendBtn.disabled = true;
  if (inp) inp.disabled = true;
  hp.classList.add("chat");
  addBubble(q, "u");
  chatHistory.push({role: "user", text: q});
  const a = addBubble("", "a", {typing: true});
  const tx = a.querySelector(".tx");
  try {
    const reply = localSmartReply(q);
    const answer = reply && typeof reply === "object" && reply.async ? await reply.run() : reply;
    const output = String(answer || (H() ? "अभी जवाब उपलब्ध नहीं है।" : "No reply was returned."));
    tx.className = "tx";
    tx.textContent = "";
    // Chunked rendering avoids a long interval per character and keeps scrolling smooth.
    const chunk = Math.max(8, Math.ceil(output.length / 45));
    for (let i = 0; i < output.length; i += chunk) {
      tx.textContent = output.slice(0, i + chunk);
      scrollChat();
      if (i + chunk < output.length) await new Promise(resolve => setTimeout(resolve, 12));
    }
    chatHistory.push({role: "assistant", text: output});
    if (chatHistory.length > MAX_HISTORY * 2) chatHistory.splice(0, chatHistory.length - MAX_HISTORY * 2);
  } catch (e) {
    console.error("LifeMate send failed", e);
    tx.className = "tx";
    tx.textContent = H() ? "⚠️ कुछ गलत हो गया। कृपया दोबारा कोशिश करें।" : "⚠️ Something went wrong. Please try again.";
  } finally {
    aiBusy = false;
    if (sendBtn) sendBtn.disabled = false;
    if (inp) inp.disabled = false;
    scrollChat();
  }
}

$("#hsd").onclick = () => { send(inp.value); inp.value = ""; };
inp.onkeydown = e => { if (e.key === "Enter") { send(inp.value); inp.value = ""; } };
hs.addEventListener("click", e => {
  const g = e.target.closest(".sg"), c = e.target.closest(".cat");
  if (g) send(g.textContent);
  if (c) send(H() ? c.dataset.h : c.dataset.q);
});
let voiceRecognition = null;
$("#hmic").onclick = () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) { toast(H() ? "इस ब्राउज़र में वॉइस इनपुट उपलब्ध नहीं है" : "Voice input is not supported in this browser"); return; }
  if (voiceRecognition) { try { voiceRecognition.stop(); } catch (_) {} voiceRecognition = null; return; }
  const b = $("#hmic");
  const rec = new SpeechRecognition(); voiceRecognition = rec;
  rec.lang = H() ? "hi-IN" : "en-IN"; rec.interimResults = false; rec.maxAlternatives = 1;
  b.classList.add("rec");
  rec.onresult = e => { const said = e.results?.[0]?.[0]?.transcript || ""; if (said) { inp.value = said; inp.focus(); } };
  rec.onerror = () => toast(H() ? "आवाज़ समझ नहीं आई। दोबारा कोशिश करें।" : "Could not recognize speech. Please try again.");
  rec.onend = () => { b.classList.remove("rec"); if (voiceRecognition === rec) voiceRecognition = null; };
  try { rec.start(); toast(H() ? "अब बोलें…" : "Listening…"); }
  catch (_) { b.classList.remove("rec"); voiceRecognition = null; toast(H() ? "माइक शुरू नहीं हो सका" : "Could not start microphone"); }
};

// New chat / clear
(function(){
  const tools = document.createElement("div");
  tools.className = "ai-tools";
  tools.innerHTML = '<button type="button" class="mini" id="ai-clear">Clear</button><button type="button" class="mini" id="ai-copy">Copy last</button>';
  const head = hp.querySelector(".ht") || hp.querySelector("header") || hp.firstElementChild;
  if (head) head.appendChild(tools);
  else hp.insertBefore(tools, hs);
  $("#ai-clear").onclick = () => { ms.innerHTML = ""; chatHistory.length = 0; hp.classList.remove("chat"); toast(H()?"चैट साफ़":"Chat cleared"); };
  $("#ai-copy").onclick = () => {
    const last = [...ms.querySelectorAll(".bb.a .tx")].pop();
    if (last && last.textContent) {
      navigator.clipboard.writeText(last.textContent).then(() => toast(H()?"कॉपी हुआ":"Copied")).catch(() => toast("Copy failed"));
    }
  };
})();

/* splash particles */
const pt=$("#pts");if(pt)pt.innerHTML=[...Array(34)].map((_,i)=>`<i style="left:${Math.random()*100}%;--s:${2+Math.random()*4}px;--c:#b8934a;--t:${4+Math.random()*4}s;--d:${-Math.random()*6}s;--x:${(Math.random()*80-40)|0}px"></i>`).join("");
X.H=H;X.applyLang=applyLang;X.getLG=()=>LG;X.sc=sc;
build();applyLang(LG)})();

document.addEventListener("click",e=>{const dc=e.target.closest(".dc[data-k]");if(dc){const k=dc.dataset.k;if(k){try{renderFestCard(k)}catch(err){}}}});

/* ===== v6: vibration, autoplay help, Settings, History, Cloud backup ===== */
(()=>{
const H=()=>!!(X.H&&X.H());
const canVib=typeof navigator!=="undefined"&&"vibrate" in navigator;
let vibT=null;
X.vibStart=()=>{if(!SET.vibrate||!canVib)return;const v=()=>{try{if(navigator.userActivation&&!navigator.userActivation.hasBeenActive)return;navigator.vibrate([500,300,500])}catch(e){}};v();clearInterval(vibT);vibT=setInterval(v,2600)};
X.vibStop=()=>{clearInterval(vibT);vibT=null;try{canVib&&navigator.vibrate(0)}catch(e){}};
const rgS=$("#rgSound");
X.ringAudioCheck=()=>{setTimeout(()=>{if(!ring)return;const blocked=!ac||ac.state!=="running";rgS.hidden=!blocked;rgS.textContent=T("Tap to play alarm sound","अलार्म की आवाज़ के लिए टैप करें")},500)};
rgS.onclick=()=>{try{ac=ac||new AudioContext();ac.resume()}catch(e){}try{if(song===SA)SA.play().catch(()=>{})}catch(e){}rgS.hidden=true};
const R1=end;end=function(){rgS.hidden=true;return R1.apply(this,arguments)};
/* ---------- v8: re-draw every visible time after the 12h/24h switch ---------- */
X.refreshTimes=()=>{try{render();rPlan()}catch(e){}try{X.apAll&&X.apAll()}catch(e){}X.calRender&&X.calRender();try{if(hist.classList.contains("o"))renderHist()}catch(e){}try{fillTones()}catch(e){}tick.l=0;X.renderThemes&&X.renderThemes()};
/* ---------- v11: one time picker for every time field — hour · minute · AM/PM (or 24-hour) ----------
   The phone's own time box shows AM/PM or 24-hour by the phone's language, not by the app setting, so the
   app's 12/24-hour choice and the AM/PM switch could disagree. The native input now only stores the value. */
const tpHours=()=>SET.h24?[...Array(24)].map((_,h)=>[String(h),p2(h)]):[...Array(12)].map((_,i)=>[String(i+1),String(i+1)]);
const tpFill=(w)=>{const mode=SET.h24?"24":"12",hs=w.querySelector(".tw-h");if(hs.dataset.mode===mode)return;hs.dataset.mode=mode;hs.innerHTML='<option value="" disabled>--</option>'+tpHours().map(([v,l])=>`<option value="${v}">${l}</option>`).join("")};
const apSync=inp=>{const w=inp.closest(".tw");if(!w)return;tpFill(w);const t=TC.parseTime(inp.value),hs=w.querySelector(".tw-h"),ms=w.querySelector(".tw-m");
 if(t){hs.value=String(SET.h24?t.h:(t.h%12||12));ms.value=p2(t.m)}else{hs.value="";ms.value=""}
 const m=TC.meridiem(inp.value);w.querySelectorAll("[data-ap]").forEach(b=>{const on=b.dataset.ap===m;b.classList.toggle("on",on);b.setAttribute("aria-checked",String(on))})};
const apAll=()=>document.querySelectorAll(".tw input[type=time]").forEach(apSync);
X.apAll=apAll;
const apSet=(inp,v)=>{if(inp.value===v){apSync(inp);return}inp.value=v;inp.dispatchEvent(new Event("input",{bubbles:true}));inp.dispatchEvent(new Event("change",{bubbles:true}));apSync(inp)};
const apWrap=(sel,stack)=>{const inp=$(sel);if(!inp||inp.closest(".tw"))return;const w=document.createElement("span");w.className="tw"+(stack?" stack":"");inp.replaceWith(w);inp.classList.add("tw-src");inp.tabIndex=-1;inp.setAttribute("aria-hidden","true");
 const pk=document.createElement("span");pk.className="tw-pk notr";pk.innerHTML=`<select class="tw-h" aria-label="Hour"></select><b aria-hidden="true">:</b><select class="tw-m" aria-label="Minute"><option value="" disabled>--</option>${[...Array(60)].map((_,m)=>`<option value="${p2(m)}">${p2(m)}</option>`).join("")}</select>`;
 w.appendChild(inp);w.appendChild(pk);
 const s=document.createElement("span");s.className="seg apm notr";s.setAttribute("role","radiogroup");s.setAttribute("aria-label","AM / PM");s.innerHTML='<button type="button" role="radio" data-ap="AM">AM</button><button type="button" role="radio" data-ap="PM">PM</button>';w.appendChild(s);
 const hs=pk.querySelector(".tw-h"),ms=pk.querySelector(".tw-m");
 const fromPicker=()=>{const cur=TC.parseTime(inp.value)||{h:new Date().getHours(),m:0};const h=hs.value===""?(SET.h24?cur.h:(cur.h%12||12)):Number(hs.value);const m=ms.value===""?cur.m:Number(ms.value);
  apSet(inp,TC.composeTime(h,m,!!SET.h24,cur.h>=12))};
 hs.onchange=fromPicker;ms.onchange=fromPicker;
 s.onclick=e=>{const b=e.target.closest("[data-ap]");if(!b)return;apSet(inp,TC.setMeridiem(inp.value||(b.dataset.ap==="AM"?"07:00":"19:00"),b.dataset.ap))};
 inp.addEventListener("input",()=>apSync(inp));inp.addEventListener("change",()=>apSync(inp));apSync(inp)};
apWrap("#tm");apWrap("#gw");apWrap("#gs");apWrap("#ps",1);apWrap("#pen",1);apWrap("#ctm",1);
["#ed","#ce","#pe","#gn"].forEach(id=>{const o=$(id);if(o)new MutationObserver(apAll).observe(o,{attributes:true,attributeFilter:["class"]})});

/* ---------- Settings ---------- */
const sett=$("#sett");let pv=null,pvId=null;
const stopPv=()=>{if(pv){try{pv.pause()}catch(e){}}pv=null;pvId=null};
const ntfState=()=>{try{return typeof Notification==="undefined"?"unsupported":Notification.permission}catch(e){return"unsupported"}};
function renderSettings(){
 $("#stTitle").textContent=T("Settings","सेटिंग्स");
 $("#stH0").textContent=T("Appearance","रूप-रंग");
 const ct=curTheme(),cti=TH.THEMES[ct];
 $("#thList").innerHTML=`<div class="set-row"><div class="set-txt"><b>${T("Time format","समय का फ़ॉर्मैट")}</b><small>${SET.h24?T("24-hour · e.g. 20:30","24 घंटे · जैसे 20:30"):T("12-hour with AM/PM · e.g. 8:30 PM","AM/PM के साथ 12 घंटे · जैसे 8:30 PM")}</small></div><div class="seg" role="radiogroup" aria-label="${T("Time format","समय का फ़ॉर्मैट")}"><button type="button" role="radio" aria-checked="${!SET.h24}" class="${SET.h24?"":"on"}" data-tf="12">AM/PM</button><button type="button" role="radio" aria-checked="${!!SET.h24}" class="${SET.h24?"on":""}" data-tf="24">24h</button></div></div>
 <button type="button" class="set-row set-link" data-openth="1"><div class="set-txt"><b>${T("Theme","थीम")}</b><small>${escH(H()?cti.hi:cti.en)} · ${TH.THEME_IDS.length} ${T("themes","थीम")}</small></div><span class="set-end"><span class="th-sw" data-theme="${ct}" aria-hidden="true"><i></i><i></i><i></i></span><em aria-hidden="true">›</em></span></button>
 <button type="button" class="set-row set-link" data-openck="1"><div class="set-txt"><b>${T("Clock theme & style","घड़ी थीम और स्टाइल")}</b><small>${escH(nm(CK.CLOCK_THEMES[curCk()]))} · ${escH(nm(CK.CLOCK_STYLES[curCks()]))}</small></div><span class="set-end"><span class="ckw ck-mini" aria-hidden="true">${CK.clockSVG(curCks())}</span><em aria-hidden="true">›</em></span></button>`;
 paintClock($("#thList .ck-mini svg"),new Date());
 $("#stH1").textContent=T("Alarm sound","अलार्म की आवाज़");$("#stH2").textContent=T("Alerts","अलर्ट");$("#stH3").textContent=T("Backup","बैकअप");
 $("#stRtNote").textContent=T("Your choice is used for new alarms and any alarm set to “Default”.","आपकी पसंद नए अलार्म और “डिफ़ॉल्ट” वाले सभी अलार्म में इस्तेमाल होगी।");
 $("#rtList").innerHTML=RT.LIST.map(r=>`<div class="rt-row${r.id===SET.ringtone?" on":""}"><button type="button" class="rt-pick" data-rtsel="${r.id}" aria-pressed="${r.id===SET.ringtone}"><span class="rt-radio"></span><span class="rt-txt"><b>${escH(H()?r.hi:r.name)}</b><small>${escH(r.desc)}</small></span></button><button type="button" class="rt-play${pvId===r.id?" on":""}" data-rtplay="${r.id}" aria-label="${T("Preview","सुनें")} ${escH(r.name)}">${pvId===r.id?"■":"▶"}</button></div>`).join("");
 $("#setRampL").textContent=T("Gradually increase volume","धीरे-धीरे आवाज़ बढ़ाएँ");$("#setRampN").textContent=T("Starts softly and rises over about 40 seconds","धीमी शुरुआत, लगभग 40 सेकंड में आवाज़ बढ़ती है");
 $("#setRamp").classList.toggle("on",!!SET.ramp);
 $("#setVibL").textContent=T("Vibration","वाइब्रेशन");$("#setVibN").textContent=canVib?T("Vibrate while an alarm rings","अलार्म बजते समय वाइब्रेट करें"):T("Not supported on this device or browser","इस डिवाइस/ब्राउज़र में उपलब्ध नहीं");
 $("#setVib").classList.toggle("on",!!SET.vibrate&&canVib);$("#setVib").classList.toggle("dis",!canVib);
 const run=ac&&ac.state==="running";$("#sndL").textContent=T("Sound in this browser","इस ब्राउज़र में आवाज़");
 $("#sndN").textContent=run?T("Enabled ✓ — alarms can play sound while this app is open.","चालू ✓ — ऐप खुला रहने पर अलार्म बज सकते हैं।"):T("Browsers block sound until you tap once. Tap “Enable” after opening the app.","टैप करने तक ब्राउज़र आवाज़ रोकते हैं। ऐप खोलकर “चालू करें” दबाएँ।");
 $("#sndB").textContent=run?T("Test","टेस्ट"):T("Enable","चालू करें");
 const n=ntfState();$("#ntfL").textContent=T("Notifications","नोटिफ़िकेशन");
 $("#ntfN").textContent=n==="granted"?T("Allowed ✓","अनुमति है ✓"):n==="denied"?T("Blocked — allow notifications in your browser settings.","ब्लॉक है — ब्राउज़र सेटिंग्स में अनुमति दें।"):n==="unsupported"?T("Not supported in this browser","इस ब्राउज़र में उपलब्ध नहीं"):T("Show a notification when an alarm rings","अलार्म बजने पर नोटिफ़िकेशन दिखाएँ");
 $("#ntfB").hidden=n!=="default";$("#ntfB").textContent=T("Allow","अनुमति दें");
 if(X.native){const s=X.nst||{},ok=s.notifications&&s.exact!==false&&s.fullScreen&&s.battery;$("#ntfN").textContent=ok?T("Background alarms ready ✓ — they ring even when the app is closed.","बैकग्राउंड अलार्म तैयार ✓ — ऐप बंद होने पर भी बजेंगे।"):!s.notifications?T("Allow notifications so alarms can ring when the app is closed.","ऐप बंद होने पर अलार्म बजाने के लिए नोटिफ़िकेशन की अनुमति दें।"):s.exact===false?T("Allow “Alarms & reminders” so every alarm rings on the exact minute.","“Alarms & reminders” की अनुमति दें ताकि हर अलार्म सही मिनट पर बजे।"):!s.fullScreen?T("Allow full-screen alarms so the alarm screen can appear on a locked phone.","लॉक स्क्रीन पर अलार्म स्क्रीन दिखाने के लिए फ़ुल-स्क्रीन अनुमति दें।"):T("Last step: set battery to “Unrestricted” so your phone does not stop the alarm.","आख़िरी चरण: बैटरी को “Unrestricted” करें ताकि फ़ोन अलार्म न रोके।");$("#ntfB").hidden=false;$("#ntfB").textContent=ok?T("Test","टेस्ट"):T("Fix","ठीक करें")}
 $("#setSpkL").textContent=T("Read reminders aloud","रिमाइंडर बोलकर सुनाएँ");$("#setSpkN").textContent=T("A natural voice reads every alarm and reminder when it rings","हर अलार्म और रिमाइंडर बजने पर आवाज़ उसे पढ़कर सुनाती है");$("#setSpk").classList.toggle("on",SET.spk!==false);
 $("#rdRow").hidden=!X.native;$("#setRdL").textContent=T("Read phone notifications aloud","फ़ोन के नोटिफ़िकेशन बोलकर सुनाएँ");
 if(X.native){const s=X.nst||{};$("#setRdN").textContent=SET.rd&&!s.reader?T("Turn on “Smart Life Alarm” in Notification access to start","शुरू करने के लिए Notification access में “Smart Life Alarm” चालू करें"):T("Like TalkBack: every new notification on your phone is read out, even when the app is closed","TalkBack की तरह: फ़ोन का हर नया नोटिफ़िकेशन पढ़कर सुनाया जाता है, ऐप बंद होने पर भी");$("#setRd").classList.toggle("on",!!SET.rd&&!!s.reader)}
 $("#stH3").textContent=T("Backup","बैकअप");$("#setLocL").textContent=T("Saved on this phone","इसी फ़ोन पर सेव");
 $("#setLocN").textContent=T("All alarms, reminders, Day Plan, settings and history stay only on this device — no account, no internet needed. Keep a backup file to move to a new phone.","सभी अलार्म, रिमाइंडर, दिन की योजना, सेटिंग्स और इतिहास केवल इसी डिवाइस पर रहते हैं — न अकाउंट, न इंटरनेट की ज़रूरत। नए फ़ोन पर ले जाने के लिए बैकअप फ़ाइल रखें।");
 $("#setBk").textContent=T("⬇ Backup file","⬇ बैकअप फ़ाइल");$("#setRs").textContent=T("⬆ Restore","⬆ रीस्टोर");
 $("#rgNote").hidden=!!X.native;
}
/* ---------- Themes page (menu → Theme, or Settings → Theme): App theme · Clock theme · Clock style ---------- */
const thm=$("#thm");let thTab="app";
const nm=t=>H()?t.hi:t.en;
const tagOf=t=>H()?t.tagHi:t.tagEn;
const cardTx=(t,on)=>`<span class="thc-t"><span class="rt-radio"></span><span class="thc-tx"><b>${escH(nm(t))}</b><small>${escH(H()?t.descHi:t.descEn)}</small></span></span>`;
function renderThemes(){
 const cur=curTheme();
 $("#thmTitle").textContent=T("Themes","थीम");
 const tabs=[["app",T("App theme","ऐप थीम")],["ck",T("Clock theme","घड़ी थीम")],["cks",T("Clock style","घड़ी स्टाइल")]];
 $("#thmTabs").innerHTML=tabs.map(([id,l])=>`<button type="button" role="tab" aria-selected="${thTab===id}" class="${thTab===id?"on":""}" data-thtab="${id}">${l}</button>`).join("");
 const live=$("#thmLive");
 if(thTab==="app"){
  live.innerHTML="";live.hidden=true;
  $("#thmLead").textContent=T("Choose a look for the whole app. It changes instantly and is saved on this device.","पूरे ऐप का लुक चुनें। यह तुरंत बदलता है और इसी डिवाइस पर सेव होता है।");
  $("#thmGrid").className="thm-grid";
  $("#thmGrid").innerHTML=TH.THEME_IDS.map((id,i)=>{const t=TH.THEMES[id],on=id===cur,tag=tagOf(t);return`<button type="button" class="thc${on?" on":""}" data-thsel="${id}" aria-pressed="${on}" style="--i:${i}">
  <span class="thp" data-theme="${id}" aria-hidden="true"><span class="thp-hd"><span class="thp-dial"><i></i><i></i></span><span class="thp-tm">${escH(fmt("07:30")).replace(/ (AM|PM)$/,"<small>$1</small>")}</span></span><span class="thp-c"><b></b><s></s></span><span class="thp-c"><b></b><s></s></span><span class="thp-fab">+</span>${tag?`<span class="thp-tag">${escH(tag)}</span>`:""}</span>
  ${cardTx(t,on)}</button>`}).join("");return}
 const ck=curCk(),cks=curCks();
 live.hidden=false;
 live.innerHTML=`<div class="thm-live g"><span class="ckw ck-live" aria-hidden="true">${CK.clockSVG(cks)}</span><span class="thm-live-tx"><small>${T("Your clock","आपकी घड़ी")}</small><b>${escH(nm(CK.CLOCK_THEMES[ck]))}</b><em>${escH(nm(CK.CLOCK_STYLES[cks]))}</em></span></div>`;
 $("#thmGrid").className="thm-grid ck-grid";
 if(thTab==="ck"){
  $("#thmLead").textContent=T("Pick the colours of the big clock on your home screen. "+(CK.CLOCK_THEME_IDS.length-1)+" clock themes, or let it follow your app theme.","होम स्क्रीन की बड़ी घड़ी के रंग चुनें। "+(CK.CLOCK_THEME_IDS.length-1)+" घड़ी थीम, या ऐप थीम जैसा रखें।");
  $("#thmGrid").innerHTML=CK.CLOCK_THEME_IDS.map((id,i)=>{const t=CK.CLOCK_THEMES[id],on=id===ck,tag=tagOf(t);return`<button type="button" class="thc ckc${on?" on":""}" data-cksel="${id}" aria-pressed="${on}" style="--i:${i}"><span class="ckc-box" aria-hidden="true"><span class="ckw" data-ck="${id}">${CK.clockSVG(cks)}</span>${id==="auto"?`<span class="thp-tag ck-tag">${T("Default","डिफ़ॉल्ट")}</span>`:tag?`<span class="thp-tag ck-tag">${escH(tag)}</span>`:`<span class="ck-no">${i}</span>`}</span>${cardTx(t,on)}</button>`}).join("")}
 else{
  $("#thmLead").textContent=T("Pick how the clock face is drawn: numbers, markers or live rings.","घड़ी का चेहरा कैसा दिखे चुनें: अंक, निशान या चलती रिंग।");
  $("#thmGrid").innerHTML=CK.CLOCK_STYLE_IDS.map((id,i)=>{const t=CK.CLOCK_STYLES[id],on=id===cks,tag=tagOf(t);return`<button type="button" class="thc ckc${on?" on":""}" data-ckssel="${id}" aria-pressed="${on}" style="--i:${i}"><span class="ckc-box" aria-hidden="true"><span class="ckw">${CK.clockSVG(id)}</span>${tag?`<span class="thp-tag ck-tag">${escH(tag)}</span>`:""}</span>${cardTx(t,on)}</button>`}).join("")}
 const n=new Date();thm.querySelectorAll("svg.ck").forEach(v=>paintClock(v,n))}
const setTheme=id=>{const cur=curTheme();if(!TH.isTheme(id)||id===cur)return;SET.theme=id;saveSet();applyTheme(true);X.log("settings","theme",{from:TH.THEMES[cur].en,to:TH.THEMES[id].en},"Changed");toast(T("✓ Theme: ","✓ थीम: ")+nm(TH.THEMES[id]))};
const setCk=id=>{const cur=curCk();if(!CK.isClockTheme(id)||id===cur)return;SET.ck=id;saveSet();applyCk();X.log("settings","clock_theme",{from:CK.CLOCK_THEMES[cur].en,to:CK.CLOCK_THEMES[id].en},"Changed");toast(T("✓ Clock theme: ","✓ घड़ी थीम: ")+nm(CK.CLOCK_THEMES[id]))};
const setCks=id=>{const cur=curCks();if(!CK.isClockStyle(id)||id===cur)return;SET.cks=id;saveSet();applyCk();X.log("settings","clock_style",{from:CK.CLOCK_STYLES[cur].en,to:CK.CLOCK_STYLES[id].en},"Changed");toast(T("✓ Clock style: ","✓ घड़ी स्टाइल: ")+nm(CK.CLOCK_STYLES[id]))};
const openThemes=tab=>{thTab=tab||"app";renderThemes();X.sc(thm,true);const c=thm.querySelector(".cs");if(c)c.scrollTop=0};
X.renderThemes=()=>{if(thm.classList.contains("o"))renderThemes()};
$("#mtheme").onclick=()=>{$("#mn").click();openThemes("app")};
$("#thmbk").onclick=()=>{X.sc(thm,false);if(sett.classList.contains("o"))renderSettings()};
thm.addEventListener("click",e=>{let b;
 if(b=e.target.closest("[data-thtab]")){if(thTab!==b.dataset.thtab){thTab=b.dataset.thtab;renderThemes()}return}
 if(b=e.target.closest("[data-thsel]")){setTheme(b.dataset.thsel);renderThemes();return}
 if(b=e.target.closest("[data-cksel]")){setCk(b.dataset.cksel);renderThemes();return}
 if(b=e.target.closest("[data-ckssel]")){setCks(b.dataset.ckssel);renderThemes()}});
const openSettings=()=>{renderSettings();X.sc(sett,true)};
$("#mset").onclick=()=>{$("#mn").click();openSettings()};
$("#stbk").onclick=()=>{stopPv();renderSettings();X.sc(sett,false)};
sett.addEventListener("click",e=>{const q=s=>e.target.closest(s);let b;
 if(q("[data-openth]")){openThemes("app");return}
 if(q("[data-openck]")){openThemes("ck");return}
 if(b=q("[data-tf]")){const h24=b.dataset.tf==="24";if(h24!==!!SET.h24){SET.h24=h24;saveSet();applyClock();X.log("settings","time_format",{from:h24?"12-hour (AM/PM)":"24-hour",to:h24?"24-hour":"12-hour (AM/PM)"},"Changed");X.refreshTimes();toast(h24?T("✓ 24-hour time","✓ 24 घंटे का समय"):T("✓ 12-hour time with AM/PM","✓ AM/PM के साथ 12 घंटे का समय"))}renderSettings();return}
 if(b=q("[data-rtsel]")){const id=b.dataset.rtsel;if(id!==SET.ringtone){const from=RT.nameOf(SET.ringtone);SET.ringtone=id;saveSet();X.log("settings","ringtone",{from,to:RT.nameOf(id)},"Changed");fillTones();render();toast(T("✓ Default ringtone: ","✓ डिफ़ॉल्ट रिंगटोन: ")+RT.nameOf(id,H()))}renderSettings();return}
 if(b=q("[data-rtplay]")){const id=b.dataset.rtplay;const was=pvId;stopPv();if(was!==id){try{ac=ac||new AudioContext()}catch(err){toast(T("Sound is not supported in this browser","इस ब्राउज़र में आवाज़ उपलब्ध नहीं"));return}pvId=id;pv=RT.preview(ac,id,()=>{if(pvId===id){pv=null;pvId=null;renderSettings()}})}renderSettings();return}
 if(q("#setRamp")){SET.ramp=!SET.ramp;saveSet();X.log("settings","ramp",{from:SET.ramp?"Off":"On",to:SET.ramp?"On":"Off"},"Changed");renderSettings();return}
 if(q("#setVib")){if(!canVib){toast(T("Vibration is not supported here","यहाँ वाइब्रेशन उपलब्ध नहीं"));return}SET.vibrate=!SET.vibrate;saveSet();X.log("settings","vibration",{from:SET.vibrate?"Off":"On",to:SET.vibrate?"On":"Off"},"Changed");if(SET.vibrate)try{navigator.vibrate(200)}catch(err){}renderSettings();return}
 if(q("#sndB")){try{ac=ac||new AudioContext();ac.resume().then(()=>{RT.playNote(ac,ac.destination,"bell",ac.currentTime+.05,79,1.2,.35);renderSettings()})}catch(err){toast(T("Sound is not supported in this browser","इस ब्राउज़र में आवाज़ उपलब्ध नहीं"))}return}
 if(q("#ntfB")){if(X.native){X.nativeFix();return}try{Notification.requestPermission().then(p=>{X.log("settings","notifications",{to:p==="granted"?"Allowed":p==="denied"?"Blocked":"Not decided"},"Changed");renderSettings()})}catch(err){}return}
 if(q("#setSpk")){SET.spk=SET.spk===false;saveSet();X.log("settings","voice",{from:SET.spk?"Off":"On",to:SET.spk?"On":"Off"},"Changed");renderSettings();return}
 if(q("#setRd")){if(!X.native)return;X.nativeReader&&X.nativeReader(!SET.rd).then(renderSettings);return}
 if(q("#setBk")){$("#backup").click();return}
 if(q("#setRs")){$("#restoreFile").click();return}
});

/* ---------- History ---------- */
const hist=$("#hist"),HF={q:"",cat:"all",range:"all",date:""};
const catLabel=c=>{const l=HC.CAT_LABELS[c];return l?l[H()?2:1]:c};
const catIcon=c=>ic({alarm:"alarm",calendar:"calendar",dayplan:"plan",account:"user",settings:"settings",data:"folder"}[c]||"history");
const ST={Created:["Created","बनाया"],Updated:["Updated","बदला"],Deleted:["Deleted","हटाया"],On:["On","चालू"],Off:["Off","बंद"],Ringing:["Ringing","बज रहा"],Completed:["Completed","पूरा"],Dismissed:["Dismissed","बंद किया"],Snoozed:["Snoozed","स्नूज़"],Missed:["Missed","छूटा"],Done:["Done","पूरा"],"Not done":["Not done","बाकी"],Success:["Success","सफल"],Changed:["Changed","बदला"],Generated:["Generated","बनाया"],Synced:["Synced","सिंक"],Exported:["Exported","एक्सपोर्ट"],Restored:["Restored","रीस्टोर"],Reset:["Reset","रीसेट"],Highlighted:["Highlighted","हाइलाइट"],Removed:["Removed","हटाया"]};
const stLabel=s=>ST[s]?ST[s][H()?1:0]:s;
const stClass=s=>({Created:"ok",Completed:"ok",Done:"ok",Success:"ok",Synced:"ok",Restored:"ok",Generated:"ok",Deleted:"bad",Missed:"bad",Reset:"bad",Ringing:"warn",Snoozed:"warn",Off:"muted",Dismissed:"muted","Not done":"muted"})[s]||"info";
const DAYN=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],DAYH=["रवि","सोम","मंगल","बुध","गुरु","शुक्र","शनि"];
const rep=b=>!b?"":b==127?T("Every day","हर दिन"):(H()?DAYH:DAYN).filter((_,i)=>b>>i&1).join(" ");
const fdt=d=>{try{return new Date(d+"T00:00:00").toLocaleDateString(H()?"hi-IN":undefined,{day:"numeric",month:"short",year:"numeric"})}catch(e){return d}};
const SCOPE={al:["Alarms only","सिर्फ़ अलार्म"],pl:["Day Plan","दिन की योजना"],all:["Everything","सब कुछ"]};
const ROUT={st:["Student","विद्यार्थी"],wk:["Working","नौकरीपेशा"],ft:["Fitness","फिटनेस"]};
function detailText(r){const d=r.d||{},p=[];
 if(d.task)p.push("“"+d.task+"”");if(d.title)p.push("“"+d.title+"”");
 if(d.time&&/^\d\d:\d\d$/.test(d.time))p.push(fmt(d.time));
 if(d.start&&d.end&&/^\d\d:\d\d$/.test(d.start))p.push(fmt(d.start)+" – "+fmt(d.end));
 if(d.repeat)p.push(rep(d.repeat));else if(d.date)p.push(fdt(d.date));
 if(d.snooze)p.push(T(d.snooze+" min",d.snooze+" मिनट"));
 if(d.from&&d.to)p.push(d.from+" → "+d.to);else if(d.to)p.push(d.to);
 if(d.routine&&ROUT[d.routine])p.push(ROUT[d.routine][H()?1:0]);
 if(d.blocks!==undefined)p.push(d.blocks+" "+T("blocks","ब्लॉक"));
 if(d.count!==undefined)p.push(d.count+" "+T("items","आइटम"));
 if(d.scope&&SCOPE[d.scope])p.push(SCOPE[d.scope][H()?1:0]);
 if(d.method)p.push(d.method);if(d.note)p.push(d.note);
 return p.join(" · ")}
const textOf=r=>[HC.activityLabel(r,false),HC.activityLabel(r,true),detailText(r),catLabel(r.cat),r.st,stLabel(r.st)].join(" ");
const tmFmt=(ts,withDate)=>new Date(ts).toLocaleString(H()?"hi-IN":"en-IN",withDate?{day:"numeric",month:"short",year:"numeric",hour:"numeric",minute:"2-digit",second:"2-digit",hour12:!SET.h24}:{hour:"numeric",minute:"2-digit",second:"2-digit",hour12:!SET.h24});
const tz=(()=>{try{return Intl.DateTimeFormat().resolvedOptions().timeZone||""}catch(e){return""}})();
function histCopy(){
 $("#hsTitle").textContent=T("History","इतिहास");$("#htz").textContent=T("Times shown in your time zone","समय आपके टाइम ज़ोन में")+(tz?" · "+tz:"");
 $("#hq").placeholder=T("Search history","इतिहास खोजें");
 $("#hcat").innerHTML=`<option value="all">${T("All activity","सभी गतिविधियाँ")}</option>`+HC.HIST_CATS.map(c=>`<option value="${c}">${escH(catLabel(c))}</option>`).join("");$("#hcat").value=HF.cat;
 $("#hrange").innerHTML=[["all","All dates","सभी तारीखें"],["today","Today","आज"],["yesterday","Yesterday","कल"],["7d","Last 7 days","पिछले 7 दिन"],["30d","Last 30 days","पिछले 30 दिन"],["date","Pick a date…","तारीख चुनें…"]].map(o=>`<option value="${o[0]}">${H()?o[2]:o[1]}</option>`).join("");$("#hrange").value=HF.range;
 $("#hcsv").textContent=T("⬇ Export CSV","⬇ CSV एक्सपोर्ट");$("#hclr").textContent=T("Clear all","सब साफ़ करें");
 $("#hcmT").textContent=T("Clear all history?","पूरा इतिहास साफ़ करें?");$("#hcmP").textContent=T("This permanently removes every history record on this device. Alarms and other data are not affected.","इससे इस डिवाइस से सभी इतिहास रिकॉर्ड हमेशा के लिए हट जाएँगे। अलार्म और बाकी डेटा पर असर नहीं होगा।");
 $("#hcmN").textContent=T("Cancel","रद्द करें");$("#hcmY").textContent=T("Clear history","इतिहास साफ़ करें")}
function renderHist(){if(!hist.classList.contains("o"))return;
 $("#hdate").hidden=HF.range!=="date";
 const list=HC.filterHistory(HIST,HF,textOf);
 $("#hcount").textContent=HIST.length?(list.length===HIST.length?HIST.length+" "+T("records","रिकॉर्ड"):list.length+" / "+HIST.length+" "+T("records","रिकॉर्ड")):"";
 $("#hcsv").disabled=!list.length;$("#hclr").disabled=!HIST.length;
 if(!HIST.length){$("#hlist").innerHTML=`<div class="hist-empty"><div class="hist-empty-ic">${ic("history")}</div><b>${T("No activity yet","अभी कोई गतिविधि नहीं")}</b><p class="mu">${T("Alarms, reminders, Day Plan changes and settings changes will appear here with the exact date and time.","अलार्म, रिमाइंडर, दिन की योजना और सेटिंग्स के बदलाव सही तारीख और समय के साथ यहाँ दिखेंगे।")}</p></div>`;return}
 if(!list.length){$("#hlist").innerHTML=`<div class="hist-empty"><div class="hist-empty-ic">${ic("compass")}</div><b>${T("No matching activity","कोई मेल खाती गतिविधि नहीं")}</b><p class="mu">${T("Try a different search or filter.","दूसरी खोज या फ़िल्टर आज़माएँ।")}</p><button type="button" class="sn" id="hreset">${T("Clear filters","फ़िल्टर हटाएँ")}</button></div>`;return}
 const GN={today:T("Today","आज"),yesterday:T("Yesterday","कल"),earlier:T("Earlier","पहले")};
 $("#hlist").innerHTML=HC.groupHistory(list).map(g=>`<h2>${GN[g.bucket]}</h2>`+g.items.map(r=>{const dt=detailText(r);return`<div class="g hist-item"><div class="hist-ic">${catIcon(r.cat)}</div><div class="t"><div class="hist-top"><b class="hist-name">${escH(HC.activityLabel(r,H()))}</b><span class="hist-st ${stClass(r.st)}">${escH(stLabel(r.st))}</span></div>${dt?`<div class="hist-det">${escH(dt)}</div>`:""}<div class="hist-meta"><time datetime="${new Date(r.ts).toISOString()}">${escH(tmFmt(r.ts,g.bucket==="earlier"))}</time> · ${escH(catLabel(r.cat))}</div></div><button type="button" class="ib hist-del" data-hdel="${escH(r.id)}" aria-label="${T("Delete record","रिकॉर्ड हटाएँ")}">${ic("trash")}</button></div>`}).join("")).join("")}
X.onHist=()=>renderHist();
const openHistory=()=>{histCopy();X.sc(hist,true);renderHist();hist.querySelector(".cs").scrollTop=0};
$("#mhist").onclick=()=>{$("#mn").click();openHistory()};
$("#hsbk").onclick=()=>X.sc(hist,false);
let hqT=null;$("#hq").addEventListener("input",e=>{clearTimeout(hqT);hqT=setTimeout(()=>{HF.q=e.target.value;renderHist()},120)});
$("#hcat").onchange=e=>{HF.cat=e.target.value;renderHist()};
$("#hrange").onchange=e=>{HF.range=e.target.value;if(HF.range==="date"&&!HF.date){HF.date=today();$("#hdate").value=HF.date}renderHist()};
$("#hdate").onchange=e=>{HF.date=e.target.value;renderHist()};
hist.addEventListener("click",e=>{const d=e.target.closest("[data-hdel]");if(d){HIST=HIST.filter(r=>r.id!==d.dataset.hdel);saveH();renderHist();toast(T("Record deleted","रिकॉर्ड हटाया गया"));return}
 if(e.target.closest("#hreset")){HF.q="";HF.cat="all";HF.range="all";HF.date="";$("#hq").value="";histCopy();renderHist()}});
$("#hcsv").onclick=()=>{const list=HC.filterHistory(HIST,HF,textOf);if(!list.length)return;const csv=HC.toCSV(list,{activity:r=>HC.activityLabel(r,H()),category:r=>catLabel(r.cat),details:detailText,status:r=>stLabel(r.st)},tz);X.download("smart-life-alarm-history-"+today()+".csv",csv,"text/csv;charset=utf-8").then(ok=>toast(ok?T("History exported","इतिहास एक्सपोर्ट हुआ"):T("Could not save the file","फ़ाइल सेव नहीं हुई")))};
const hcm=$("#hcm");$("#hclr").onclick=()=>{if(HIST.length)hcm.classList.add("s")};$("#hcmN").onclick=()=>hcm.classList.remove("s");hcm.onclick=e=>{if(e.target===hcm)hcm.classList.remove("s")};
$("#hcmY").onclick=()=>{HIST=[];saveH();hcm.classList.remove("s");renderHist();toast(T("History cleared","इतिहास साफ़ हुआ"))};

/* ---------- v11: local-only storage. No account and no server: every change is already saved on this device. ---------- */
X.changed=()=>{};
$("#lgb").onclick=()=>openSettings();
X.onLang=()=>{X.nsync&&X.nsync();try{fillTones()}catch(e){}if(sett.classList.contains("o"))renderSettings();X.renderThemes();if(hist.classList.contains("o")){histCopy();renderHist()}};
X.renderSettings=()=>{if(sett.classList.contains("o"))renderSettings()};
})();

}
