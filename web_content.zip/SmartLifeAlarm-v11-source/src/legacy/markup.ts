// Static markup for the Smart Life Alarm app (ported from v5). {{ic:name}} placeholders become line icons.
import RAW from "./markup.html?raw";
import { fillIcons } from "./icons";

export const MARKUP = fillIcons(RAW);
