# Smart Life Alarm (v11 — fully local)

Voice alarms, Smart Calendar, Day Plan, weather, LifeMate helper, history, 17 app themes,
15 clock themes and 10 clock styles. No sign-in and no server: everything is saved on the device.

## Use it without any hosting
Open `SmartLifeAlarm.html` (in the download zip) — or build it yourself:

```sh
bun install          # or: npm install
bun run build:local  # → dist-local/index.html (one self-contained file)
```

Copy that single file to your phone or computer and open it in Chrome. Data stays in that browser
(back it up with Menu → ⬇ Backup). Alarms in a browser ring only while the page is open; for alarms
that ring with the app closed, use the Android app.

## Android app
See `android-app/README.md` (GitHub "Build APK" button, or Android Studio).

## Develop
```sh
bun run dev     # web preview
bun run test    # rules: themes, clocks, AM/PM, snooze, history, calendar marks, phone alarms
```
