// Builds the stand-alone app: one index.html with every script and style inside it (dist-local/).
// Opens without hosting (double-click / file manager) and is the screen of the Android app.
import { fileURLToPath, URL } from "node:url";
import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

export default defineConfig({
  root: fileURLToPath(new URL("./local", import.meta.url)),
  base: "./",
  publicDir: false,
  define: { "import.meta.env.VITE_LOCAL_BUILD": JSON.stringify("1") },
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  plugins: [viteSingleFile()],
  build: {
    outDir: fileURLToPath(new URL("./dist-local", import.meta.url)),
    emptyOutDir: true,
    target: "es2020",
  },
});
