<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules (Smart Life Alarm)
- The app UI is the ported v5 single-file app: markup in `src/legacy/markup.html` (imported raw by `markup.ts`), styles in `src/legacy/app.css`, logic in `src/legacy/app.ts` (booted once from `src/routes/index.tsx` and from `local/main.ts`). Why: preserves every existing feature and the user's design exactly; extend it rather than rewriting in React.
- New UI text in `src/legacy/*` must be bilingual (English/Hindi) via the existing `T(en, hi)` helper or the translation table.
- Pure rules live in `src/lib/*-core.ts` with tests next to them. Why: the browser glue is untyped; rules must stay testable.
- Local-only: no sign-in, no backend, no server functions. All data lives in localStorage (`sla2`, `sla_p`, `sla_hist`, `sla_settings`, `sla_marks`, `sla_lang`, `sla_city`) and IndexedDB (`sla` → uploaded songs). Moving devices uses the Backup/Restore JSON file. Why: the user wants the app to run without hosting and keep data on the phone.
- Weather is fetched in the browser from Open-Meteo (no key). Why: no server is allowed.
- Files the app writes (backup JSON, history CSV) go through `X.download`, which uses the Android plugin's `saveFile` inside the app. Why: WebView ignores `<a download>`.
- Tailwind preflight is intentionally not imported in `src/styles.css`. Why: the legacy stylesheet was designed without a CSS reset.
- The service worker registers only on https production builds, outside iframes. Why: it must never cache the dev preview.
- Themes: ids and names live in `src/lib/themes-core.ts`; colours are full token sets in `src/legacy/app.css` under `[data-theme=<id>]`. Per-theme clock colours for "auto" go BEFORE the `[data-ck=gold]` block so a chosen clock theme still wins. The pre-paint script in `__root.tsx` is built from the id lists. Why: every theme block is self-contained and previews render any theme by setting `data-theme`.
- Clock format (12-hour AM/PM or 24-hour) is `SET.h24`; all display goes through `formatTime`, and every time field uses the app's own hour/minute/AM-PM picker (`apWrap` in app.ts, `composeTime` in time-core) with the native input only holding the value. Why: the phone's time box follows the phone language, not the app setting.
- App chrome icons come from `src/legacy/icons.ts` (`{{ic:name}}` placeholders in markup, `ic()` in logic).
- Clock faces: theme/style ids, names and the SVG builder live in `src/lib/clock-core.ts` (`SET.ck`, `SET.cks`, `auto` follows the app theme); face colours are `[data-ck=<id>]` token blocks and layouts `[data-cks=<id>]` in `src/legacy/app.css`. Digital styles (`DIGITAL_STYLES`) hide the line of digits under the clock.
- Android app: built from `android-app/` (Capacitor 7, webDir = `dist-local`). Alarms are mirrored to the phone's AlarmManager through the `SmartAlarm` plugin (Java in `android-app/native/`, bridge block `v10` in `src/legacy/app.ts`, rules in `src/lib/native-alarm-core.ts`). Events from the phone are drained BEFORE any sync; when `X.nativeRing` is true the in-page ringing is skipped. The plugin also speaks reminders (TextToSpeech) and, when enabled, reads every phone notification aloud through a NotificationListenerService. Why: the in-page `tick()` cannot ring when the app is closed.
- Standalone web build: `bun run build:local` → `dist-local/index.html` (one self-contained file). Why: the user wants to open the app without any hosting.
