MR,KHORASANI v1.4.7-ENHANCED — بسته آماده ZIP TO APK

صفحه شروع (Start Page): index.html
آیکن (Icon): icon.png
جهت: راست به چپ (RTL) / عمودی (Portrait)

تنظیمات پیشنهادی در نرم‌افزار Zip-to-APK:
- App Name: MR,KHORASANI
- Package Name: com.mrkhorasani.accounting
- Version: 1.4.7
- Orientation: Portrait
- Enable JavaScript: Yes
- Allow File Access / Storage Permission: Yes (برای ذخیره PDF و اکسل و ورود فایل)
- Enable Zoom: Optional

رمز فعال‌سازی دستگاه (اولین اجرا روی هر گوشی):
0371317037

دکمه‌های مهم داخل برنامه:
- پشتیبان‌گیری (بالای صفحه)
- ثبت عملیات +
- ورود اکسل از حافظه گوشی (در صفحات اشخاص و کالا)
- بستن روز (فقط مدیر عامل و مدیر مالی)

ذخیره فایل‌ها:
برنامه سعی می‌کند فایل‌ها را در پوشه Download/MR-KHORASANI ذخیره کند.
اگر پل Android.saveFile پشتیبانی شود، ذخیره مستقیم انجام می‌شود؛ در غیر این صورت دانلود مرورگر/WebView فعال می‌شود.

قالب‌های اکسل در پوشه templates قرار دارند.
