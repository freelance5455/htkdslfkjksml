MR-KHORASANI — نسخه مستقل برای Zip to APK

صفحه شروع: index.html
این نسخه یک فایل HTML مستقل است و برای اجرا هیچ فایل CSS/JS خارجی لازم ندارد.
