const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let currentCommentCard = null;
let userVideos = [];
let totalLikes = 0;

function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1900)}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id===page));$$(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.page===page));if(page==="profilePage")updateProfile();if(page==="searchPage")$("#searchInput").focus()}
$$(".nav-btn,.nav-create").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
$("#searchOpen").addEventListener("click",()=>go("searchPage"));

function wireCard(card){
  const like=card.querySelector(".like-btn");
  like?.addEventListener("click",()=>{const on=like.classList.toggle("liked");like.firstChild.textContent=on?"♥":"♡";like.querySelector("small").textContent=on?"1":"0";totalLikes+=on?1:-1;});
  card.querySelector(".comment-btn")?.addEventListener("click",()=>{currentCommentCard=card;$("#commentsList").innerHTML='<p class="muted">Пока нет комментариев.</p>';$("#commentsDialog").showModal()});
  card.querySelector(".share-btn")?.addEventListener("click",async()=>{try{if(navigator.share)await navigator.share({title:"MyTikTok",text:"Посмотри это видео в MyTikTok"});else{await navigator.clipboard.writeText(location.href);toast("Ссылка скопирована")}}catch(e){}});
}
$$(".video-card").forEach(wireCard);
$("#closeComments").addEventListener("click",()=>$("#commentsDialog").close());
$("#commentForm").addEventListener("submit",e=>{e.preventDefault();const val=$("#commentInput").value.trim();if(!val)return;const list=$("#commentsList");if(list.querySelector(".muted"))list.innerHTML="";const row=document.createElement("div");row.className="comment";const b=document.createElement("b");b.textContent="@mytiktok_user";row.append(b,document.createTextNode(val));list.append(row);$("#commentInput").value="";});

$("#videoInput").addEventListener("change",e=>{
  const file=e.target.files[0];if(!file)return;
  if(!file.type.startsWith("video/")){toast("Выбери видеофайл");return}
  const url=URL.createObjectURL(file);const card=document.createElement("article");card.className="video-card";card.dataset.id="user"+Date.now();
  const video=document.createElement("video");video.className="uploaded-video";video.src=url;video.controls=true;video.playsInline=true;video.loop=true;
  const overlay=document.createElement("div");overlay.className="video-overlay";
  const creator=document.createElement("div");creator.className="creator";const name=document.createElement("b");name.textContent="@mytiktok_user";const desc=document.createElement("span");desc.textContent=$("#captionInput").value.trim()||file.name;const tag=document.createElement("p");tag.textContent="#моёВидео";creator.append(name,desc,tag);
  const actions=document.createElement("div");actions.className="video-actions";actions.innerHTML='<button class="like-btn">♡<small>0</small></button><button class="comment-btn">●<small>Коммент.</small></button><button class="share-btn">↗<small>Поделиться</small></button>';
  overlay.append(creator,actions);card.append(video,overlay);$("#feed").prepend(card);wireCard(card);userVideos.push({url,name:file.name});$("#captionInput").value="";e.target.value="";toast("Видео добавлено в ленту");go("feedPage");
});
function updateProfile(){$("#postCount").textContent=userVideos.length;$("#likeCount").textContent=Math.max(0,totalLikes);$("#profileGrid").innerHTML="";userVideos.forEach(v=>{const tile=document.createElement("div");tile.textContent="▶";$("#profileGrid").append(tile)})}
$("#editProfile").addEventListener("click",()=>{const name=prompt("Как тебя называть?","mytiktok_user");if(name)$("#profilePage .profile-head p").textContent="@"+name.replace(/^@/,"")});
$("#searchInput").addEventListener("input",e=>{const q=e.target.value.trim().toLowerCase();const results=$("#searchResults");results.innerHTML="";if(!q){results.textContent="Введи запрос, чтобы найти видео в этой ленте.";return}const cards=$$(".video-card").filter(c=>c.textContent.toLowerCase().includes(q));if(!cards.length){results.textContent="Ничего не найдено в текущей ленте.";return}cards.forEach(c=>{const item=document.createElement("div");item.className="search-result";item.textContent=c.querySelector(".creator")?.textContent||"Видео";item.addEventListener("click",()=>go("feedPage"));results.append(item)})});
