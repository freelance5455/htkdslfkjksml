const CACHE_NAME = 'alarm-simulator-v17-shell-v2';
const SHELL = ['./index.html','./style.css','./script.js','./manifest.webmanifest','./alarm-icon.svg'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('alarm-simulator-v17-') && k !== CACHE_NAME).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => { if (response.ok && new URL(event.request.url).origin === self.location.origin) caches.open(CACHE_NAME).then(cache => cache.put(event.request, response.clone())); return response; })));
});
self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (_) { data = { title: 'Тривога!', body: event.data ? event.data.text() : 'Нове сповіщення' }; }
  const title = data.title || 'Тривога!';
  const options = { body: data.body || '', icon: './alarm-icon.svg', badge: './alarm-icon.svg', tag: data.tag || ('alarm-push-' + Date.now()), renotify: true, vibrate: data.vibrate || [250,150,250,150,500], data: { url: data.url || './index.html', eventId: data.eventId || null } };
  event.waitUntil(self.registration.showNotification(title, options));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  const target = new URL(event.notification.data?.url || './index.html', self.location.scope).href;
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const client of list) if ('focus' in client) { client.navigate?.(target); return client.focus(); }
    if (self.clients.openWindow) return self.clients.openWindow(target);
  }));
});
