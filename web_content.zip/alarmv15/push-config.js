/* Configure only after deploying the companion push-server.
 * Set endpoint to your HTTPS server base URL and publicKey to its VAPID public key.
 * Leaving endpoint empty keeps the app in local-notification mode.
 */
window.PUSH_CONFIG = { endpoint: '', publicKey: '' };
