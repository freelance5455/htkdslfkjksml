import { MINUTE } from './data.js';
import { CRT } from './strategy.js';
export function validateParams(p) {
  const required = ['balance', 'risk', 'lots', 'point', 'pointValue', 'spread', 'slippage', 'commission', 'minStop', 'maxStop', 'minLot', 'lotStep', 'pivot', 'atr', 'tolerance', 'buffer', 'hold'];
  if (!p || typeof p !== 'object') throw new Error('Settings must be a numeric configuration.');
  for (const key of required) if (!Number.isFinite(p[key])) throw new Error(`Missing or invalid numeric setting: ${key}.`);
  for (const key of ['balance', 'risk', 'lots', 'point', 'pointValue', 'minLot', 'lotStep', 'buffer', 'hold']) if (!(p[key] > 0)) throw new Error(`${key} must be greater than zero.`);
  for (const key of ['spread', 'slippage', 'commission', 'minStop', 'maxStop', 'tolerance']) if (p[key] < 0) throw new Error(`${key} must not be negative.`);
  if (p.risk > 100) throw new Error('Risk cap must not exceed 100%.');
  if (!Number.isInteger(p.pivot) || p.pivot < 1 || p.pivot > 20) throw new Error('Pivot window must be an integer from 1 to 20.');
  if (!Number.isInteger(p.atr) || p.atr < 2 || p.atr > 100) throw new Error('ATR period must be an integer from 2 to 100.');
  if (!Number.isInteger(p.hold) || p.hold > 10080) throw new Error('Holding limit must be whole minutes from 1 to 10080.');
  if (p.lots < p.minLot - 1e-10 || Math.abs(p.lots / p.lotStep - Math.round(p.lots / p.lotStep)) > 1e-7) throw new Error('Lots must be at least the minimum and an exact multiple of the lot step.');
  if (p.lots > 100 || p.point > 1000000 || p.pointValue > 1e12 || p.balance > 1e15) throw new Error('Instrument or capital settings exceed supported numerical bounds.');
  return p;
}
export function netAt(basket, bid, p) {
  const direction = basket.side === 'BUY' ? 1 : -1;
  const exit = basket.side === 'BUY' ? bid - p.slippage * p.point : bid + (p.spread + p.slippage) * p.point;
  const gross = direction * (exit - basket.entry) / p.point * p.pointValue * p.lots * 3;
  const fees = p.commission * p.lots * 3 * 2;
  return { exit, gross, fees, net: gross - fees };
}
export function createBasket(signal, bar, balance, p) {
  const buy = signal.side === 'BUY';
  const reference = buy ? bar.open : bar.open + p.spread * p.point;
  // A structural stop already crossed at the entry open invalidates the setup.
  // Do not silently move that stop to rescue the trade when applying broker limits.
  if (!['BUY', 'SELL'].includes(signal.side) || !Number.isFinite(signal.stop) || signal.stop <= 0 || (buy ? reference <= signal.stop : reference >= signal.stop)) return { rejected: 'invalid stop after entry gap' };
  const entry = bar.open + (buy ? p.spread + p.slippage : -p.slippage) * p.point;
  const stopRaw = buy ? Math.min(signal.stop, reference - p.minStop * p.point) : Math.max(signal.stop, reference + p.minStop * p.point);
  const stop = (buy ? Math.floor(stopRaw / p.point + 1e-9) : Math.ceil(stopRaw / p.point - 1e-9)) * p.point;
  const distance = buy ? entry - stop : stop - entry;
  if (!Number.isFinite(distance) || distance <= 0 || stop <= 0 || entry <= 0 || (buy ? bar.open <= stop : bar.open + p.spread * p.point >= stop)) return { rejected: 'invalid stop after entry gap' };
  if (p.maxStop > 0 && distance / p.point > p.maxStop + 1e-7) return { rejected: 'maximum stop distance' };
  const basket = { side: signal.side, entry, stop, entryTime: bar.t - MINUTE, signalTime: signal.signalTime, level: signal.level, legs: 3, lots: p.lots };
  const stopBid = buy ? stop : stop - p.spread * p.point;
  const risk = -netAt(basket, stopBid, p).net;
  if (!Number.isFinite(risk) || risk > balance * p.risk / 100 || balance <= 0) return { rejected: 'basket risk cap', estimatedRisk: risk };
  return { basket: { ...basket, estimatedRisk: risk } };
}
export function stopEvent(basket, bar, p) {
  const buy = basket.side === 'BUY'; const spread = p.spread * p.point;
  if (buy ? bar.open <= basket.stop : bar.open + spread >= basket.stop) return { bid: bar.open, time: bar.t - MINUTE, reason: 'Stop gap' };
  if (buy ? bar.low <= basket.stop : bar.high + spread >= basket.stop) return { bid: buy ? basket.stop : basket.stop - spread, time: bar.t, reason: 'Stop loss' };
  return null;
}
export async function backtest(bars, p, options = {}) {
  validateParams(p);
  if (!Array.isArray(bars) || !bars.length) throw new Error('Load at least one completed M1 candle.');
  const events = []; let eventCount = 0;
  const log = (t, event, detail) => { events.push({ t, event, detail }); eventCount++; if (events.length > 600) events.shift(); };
  const strategy = options.strategyFactory ? options.strategyFactory(p, log) : new CRT(p, log);
  const trades = []; const curve = [{ t: bars[0].t - MINUTE, equity: p.balance }];
  const skips = { risk: 0, stop: 0, gap: 0, lastBar: 0 };
  let balance = p.balance; let peak = balance; let drawdown = 0; let drawdownCash = 0;
  let basket = null; let pending = null;
  const close = (event) => {
    const settlement = netAt(basket, event.bid, p);
    balance += settlement.net;
    trades.push({ ...basket, ...settlement, exitTime: event.time, reason: event.reason, balance, holdMinutes: (event.time - basket.entryTime) / MINUTE });
    log(event.time, 'CRT basket close', `reason=${event.reason} | net=${settlement.net.toFixed(2)} | balance=${balance.toFixed(2)}`);
    basket = null;
  };
  for (let i = 0; i < bars.length; i++) {
    if (options.cancelled?.()) throw new Error('Run cancelled. Previous completed results were kept.');
    const bar = bars[i]; let exited = false;
    if (pending) {
      if (bar.t - MINUTE !== pending.signalTime) { skips.gap++; log(bar.t, 'CRT entry skipped', 'Missing next contiguous M1 open'); }
      else {
        const fill = createBasket(pending, bar, balance, p);
        if (fill.rejected) {
          if (fill.rejected === 'basket risk cap') skips.risk++; else skips.stop++;
          log(bar.t - MINUTE, 'CRT entry skipped', fill.rejected);
        } else {
          basket = fill.basket;
          log(basket.entryTime, 'CRT basket opened', `${basket.side} | legs=3 | lots/leg=${p.lots} | execution=${basket.entry.toFixed(8)} | stop=${basket.stop.toFixed(8)}`);
        }
      }
      pending = null;
    }
    if (basket) {
      const stop = stopEvent(basket, bar, p);
      const openTime = bar.t - MINUTE;
      // A gap-stop takes priority; an already expired basket closes at the first available open.
      if (stop?.reason === 'Stop gap') { close(stop); exited = true; }
      else if (openTime - basket.entryTime >= p.hold * MINUTE) { close({ bid: bar.open, time: openTime, reason: 'Time limit' }); exited = true; }
      else if (stop) { close(stop); exited = true; }
      else {
        const mark = netAt(basket, bar.close, p);
        const age = (bar.t - basket.entryTime) / MINUTE;
        if (mark.net > 0 || age >= p.hold) { close({ bid: bar.close, time: bar.t, reason: mark.net > 0 ? 'Positive basket' : 'Time limit' }); exited = true; }
      }
    }
    strategy.update(bar);
    if (!basket && !exited) pending = strategy.signal(bar);
    if (i === bars.length - 1) {
      if (pending) { skips.lastBar++; pending = null; }
      if (basket) close({ bid: bar.close, time: bar.t, reason: 'End of data' });
    }
    const equity = basket ? balance + netAt(basket, bar.close, p).net : balance;
    if (!Number.isFinite(equity)) throw new Error('Numerical overflow: reduce instrument or sizing settings.');
    peak = Math.max(peak, equity);
    drawdownCash = Math.max(drawdownCash, peak - equity);
    drawdown = Math.max(drawdown, peak > 0 ? (peak - equity) / peak * 100 : 0);
    curve.push({ t: bar.t, equity });
    if (i % 2000 === 0) { options.progress?.(i / bars.length); await new Promise(resolve => setTimeout(resolve, 0)); }
  }
  const wins = trades.filter(t => t.net > 0); const losses = trades.filter(t => t.net < 0);
  const grossWins = wins.reduce((n, t) => n + t.net, 0); const grossLosses = -losses.reduce((n, t) => n + t.net, 0);
  return { balance, net: balance - p.balance, returnPercent: (balance / p.balance - 1) * 100, drawdown, drawdownCash, winRate: trades.length ? wins.length / trades.length * 100 : null, profitFactor: grossLosses > 0 ? grossWins / grossLosses : grossWins > 0 ? 'Infinity' : null, trades, curve, events, eventCount, skips, stats: strategy.stats, params: { ...p }, start: bars[0].t - MINUTE, end: bars[bars.length - 1].t, barCount: bars.length };
}
