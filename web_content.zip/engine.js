/* محرك لغة ACCE - نسخة المتصفح 4.0 */
(function(root){
"use strict";
class ACCEEngine{
 constructor(opts={}){this.maxSteps=opts.maxSteps||20000;this.steps=0;this.vars={};this.out=[];this.stopped=false;}
 emit(v){this.out.push(String(v));}
 val(s){s=String(s??"").trim();if(Object.prototype.hasOwnProperty.call(this.vars,s))return this.vars[s];if(/^-?(?:\d+\.?\d*|\.\d+)$/.test(s))return Number(s);if(s==="صحيح"||s==="نعم")return true;if(s==="خطأ"||s==="لا")return false;if((s[0]==='"'&&s.at(-1)==='"')||(s[0]==="'"&&s.at(-1)==="'"))return s.slice(1,-1);return s;}
 num(s,line){const n=Number(this.val(s));if(!Number.isFinite(n))throw Error("السطر "+line+": القيمة ليست رقمًا: "+s);return n;}
 cond(s){for(const op of [">=","<=","==","!=",">","<"]){let i=s.indexOf(op);if(i>=0){let a=this.val(s.slice(0,i)),b=this.val(s.slice(i+op.length));switch(op){case">=":return a>=b;case"<=":return a<=b;case"==":return a==b;case"!=":return a!=b;case">":return a>b;case"<":return a<b;}}}return !!this.val(s);}
 execute(src){this.vars={};this.out=[];this.steps=0;this.stopped=false;let lines=String(src).replace(/\r/g,"").split("\n");try{this.range(lines,0,lines.length);}catch(e){this.emit("❌ "+e.message);}return this.out.join("\n");}
 endBlock(lines,start){let depth=0;for(let i=start;i<lines.length;i++){let t=lines[i].trim();if(t.startsWith("لو\\")||t.startsWith("كرر\\" )||t.startsWith("طالما\\"))depth++;if(t==="نهاية"){if(depth===0)return i;depth--;}}throw Error("كتلة غير مغلقة عند السطر "+(start+1));}
 range(lines,from,to){for(let i=from;i<to;i++){if(this.stopped)return;if(++this.steps>this.maxSteps)throw Error("تم تجاوز حد التنفيذ");let line=lines[i].trim();if(!line||line.startsWith("#"))continue;
 if(line.startsWith("لو\\")){let end=this.endBlock(lines,i+1),elseAt=-1,depth=0;for(let j=i+1;j<end;j++){let t=lines[j].trim();if(t.startsWith("لو\\"))depth++;if(t==="نهاية")depth--;if(t==="وإلا"&&depth===0){elseAt=j;break;}}if(this.cond(line.slice(3)))this.range(lines,i+1,elseAt<0?end:elseAt);else if(elseAt>=0)this.range(lines,elseAt+1,end);i=end;continue;}
 if(line.startsWith("كرر\\")){let count=Math.max(0,Math.min(10000,Math.floor(this.num(line.split("\\")[1],i+1)))),end=this.endBlock(lines,i+1);for(let n=0;n<count;n++)this.range(lines,i+1,end);i=end;continue;}
 if(line.startsWith("طالما\\")){let end=this.endBlock(lines,i+1),guard=0;while(this.cond(line.slice(6))){if(++guard>10000)throw Error("حلقة طالما تجاوزت الحد");this.range(lines,i+1,end);}i=end;continue;}
 this.line(line,i+1);
 }}
 line(line,n){let p=line.split("\\"),cmd=p[0],a=p.slice(1);if(cmd==="اطبع"||cmd==="اكتب")this.emit(a.map(x=>this.val(x)).join(" "));
 else if(cmd==="خزن"||cmd==="اجعل"){if(a.length<2)throw Error("السطر "+n+": استخدم خزن\\الاسم\\القيمة");this.vars[a[0]]=this.val(a.slice(1).join("\\"));}
 else if(["اجمع","اطرح","اضرب","اقسم","باقي"].includes(cmd)){if(a.length<2)throw Error("السطر "+n+": العملية تحتاج رقمين");let x=this.num(a[0],n),y=this.num(a[1],n);if((cmd==="اقسم"||cmd==="باقي")&&y===0)throw Error("السطر "+n+": لا يمكن القسمة على صفر");this.emit(cmd==="اجمع"?x+y:cmd==="اطرح"?x-y:cmd==="اضرب"?x*y:cmd==="اقسم"?x/y:x%y);}
 else if(cmd==="زود"||cmd==="انقص"){if(!a[0]||!(a[0] in this.vars))throw Error("السطر "+n+": المتغير غير موجود");this.vars[a[0]]=this.num(a[0],n)+(cmd==="زود"?1:-1)*(a[1]?this.num(a[1],n):1);}
 else if(cmd==="اقرأ"){let name=a[0];let raw=prompt("أدخل قيمة "+name);if(raw===null)raw="";let v=raw.trim();this.vars[name]=v!==""&&Number.isFinite(Number(v))?Number(v):v;}
 else if(cmd==="اعرض_المتغيرات")Object.keys(this.vars).forEach(k=>this.emit(k+" = "+this.vars[k]));
 else if(cmd==="امسح")this.out=[];
 else if(cmd==="توقف")this.stopped=true;
 else throw Error("السطر "+n+": أمر غير معروف: "+cmd);
 }
}
root.ACCEEngine=ACCEEngine;
})(typeof window!=="undefined"?window:globalThis);