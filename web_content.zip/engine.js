/* ACCE language engine - 3.0 alpha */
(function (root) {
  "use strict";

  class ACCEError extends Error {
    constructor(message, line) {
      super(message);
      this.name = "ACCEError";
      this.line = line || 0;
    }
  }

  class ACCEEngine {
    constructor(options = {}) {
      this.maxSteps = options.maxSteps || 20000;
      this.output = [];
      this.variables = Object.create(null);
      this.functions = Object.create(null);
      this.steps = 0;
      this.stopped = false;
    }

    emit(value) { this.output.push(String(value)); }
    tick(line) {
      this.steps++;
      if (this.steps > this.maxSteps) throw new ACCEError("تجاوز البرنامج الحد الأقصى للتنفيذ", line);
    }

    split(line) {
      // Backslash is the official ACCE argument separator.
      return line.split("\\").map(x => x.trim());
    }

    value(raw, line) {
      const s = String(raw ?? "").trim();
      if (Object.prototype.hasOwnProperty.call(this.variables, s)) return this.variables[s];
      if (/^-?(?:\d+\.?\d*|\.\d+)$/.test(s)) return Number(s);
      if (s === "صحيح" || s === "نعم") return true;
      if (s === "خطأ" || s === "لا") return false;
      if (s.startsWith('"') && s.endsWith('"')) return s.slice(1, -1);
      if (s.startsWith("'") && s.endsWith("'")) return s.slice(1, -1);
      return s;
    }

    numeric(raw, line) {
      const n = Number(this.value(raw, line));
      if (!Number.isFinite(n)) throw new ACCEError("القيمة ليست رقمًا: " + raw, line);
      return n;
    }

    condition(expr, line) {
      const ops = [">=", "<=", "==", "!=", ">", "<"];
      for (const op of ops) {
        const at = expr.indexOf(op);
        if (at > -1) {
          const left = this.value(expr.slice(0, at), line);
          const right = this.value(expr.slice(at + op.length), line);
          switch (op) {
            case ">=": return left >= right;
            case "<=": return left <= right;
            case "==": return left == right; // ACCE loose value comparison
            case "!=": return left != right;
            case ">": return left > right;
            case "<": return left < right;
          }
        }
      }
      return Boolean(this.value(expr, line));
    }

    findBlock(lines, start, opening, closing) {
      let depth = 0;
      for (let i = start; i < lines.length; i++) {
        const t = lines[i].trim();
        if (t.startsWith(opening)) depth++;
        if (t === closing || t.startsWith(closing + " ")) {
          depth--;
          if (depth === 0) return i;
        }
      }
      throw new ACCEError("لم يتم إغلاق الكتلة: " + opening, start + 1);
    }

    execute(source) {
      this.output = [];
      this.variables = Object.create(null);
      this.functions = Object.create(null);
      this.steps = 0;
      this.stopped = false;
      const lines = String(source).replace(/\r/g, "").split("\n");
      try { this.executeRange(lines, 0, lines.length); }
      catch (e) {
        const prefix = e.line ? "السطر " + e.line + ": " : "";
        this.emit("❌ " + prefix + e.message);
      }
      return this.output.join("\n");
    }

    executeRange(lines, from, to) {
      for (let i = from; i < to; i++) {
        if (this.stopped) break;
        this.tick(i + 1);
        const raw = lines[i];
        const line = raw.trim();
        if (!line || line.startsWith("#") || line.startsWith("//")) continue;

        if (line.startsWith("لو\\") || line.startsWith("لو ")) {
          const expr = line.startsWith("لو\\") ? line.slice(3) : line.slice(3).replace(/:$/, "");
          const end = this.findBlock(lines, i, "لو", "نهاية");
          let elseAt = -1, depth = 0;
          for (let j = i + 1; j < end; j++) {
            const t = lines[j].trim();
            if (t.startsWith("لو\\") || t.startsWith("لو ")) depth++;
            if (t === "نهاية") depth--;
            if (t === "وإلا" && depth === 0) { elseAt = j; break; }
          }
          if (this.condition(expr, i + 1)) this.executeRange(lines, i + 1, elseAt < 0 ? end : elseAt);
          else if (elseAt >= 0) this.executeRange(lines, elseAt + 1, end);
          i = end;
          continue;
        }

        if (line.startsWith("كرر\\")) {
          const count = Math.max(0, Math.min(10000, Math.floor(this.numeric(line.split("\\")[1], i + 1))));
          const end = this.findBlock(lines, i, "كرر", "نهاية");
          for (let n = 0; n < count && !this.stopped; n++) this.executeRange(lines, i + 1, end);
          i = end;
          continue;
        }

        if (line.startsWith("طالما\\")) {
          const expr = line.slice("طالما\\".length);
          const end = this.findBlock(lines, i, "طالما", "نهاية");
          let guard = 0;
          while (this.condition(expr, i + 1) && !this.stopped) {
            if (++guard > 10000) throw new ACCEError("حلقة طالما تجاوزت 10000 دورة", i + 1);
            this.executeRange(lines, i + 1, end);
          }
          i = end;
          continue;
        }

        this.executeLine(line, i + 1);
      }
    }

    executeLine(line, lineNo) {
      const p = this.split(line);
      const cmd = p[0];
      const a = p.slice(1);
      const joined = a.join("\\");

      if (cmd === "اطبع" || cmd === "اكتب") {
        this.emit(a.map(x => this.value(x, lineNo)).join(" "));
      } else if (cmd === "خزن" || cmd === "اجعل") {
        if (a.length < 2) throw new ACCEError("استخدم: خزن\\الاسم\\القيمة", lineNo);
        this.variables[a[0]] = this.value(joined.slice(a[0].length + 1), lineNo);
      } else if (cmd === "اجمع" || cmd === "اطرح" || cmd === "اضرب" || cmd === "اقسم" || cmd === "باقي") {
        if (a.length < 2) throw new ACCEError("الأمر يحتاج قيمتين", lineNo);
        const x = this.numeric(a[0], lineNo), y = this.numeric(a[1], lineNo);
        if ((cmd === "اقسم" || cmd === "باقي") && y === 0) throw new ACCEError("لا يمكن القسمة على صفر", lineNo);
        const result = cmd === "اجمع" ? x + y : cmd === "اطرح" ? x - y : cmd === "اضرب" ? x * y : cmd === "اقسم" ? x / y : x % y;
        this.emit(result);
      } else if (cmd === "زود" || cmd === "انقص") {
        if (!a[0] || !Object.prototype.hasOwnProperty.call(this.variables, a[0])) throw new ACCEError("المتغير غير موجود", lineNo);
        const amount = a[1] ? this.numeric(a[1], lineNo) : 1;
        this.variables[a[0]] = this.numeric(a[0], lineNo) + (cmd === "زود" ? amount : -amount);
      } else if (cmd === "امسح") {
        this.output = [];
      } else if (cmd === "اعرض_المتغيرات") {
        Object.keys(this.variables).forEach(k => this.emit(k + " = " + this.variables[k]));
      } else if (cmd === "توقف") {
        this.stopped = true;
      } else if (cmd === "استورد") {
        this.emit("ملاحظة: الاستيراد البرمجي سيُضاف في إصدار لاحق.");
      } else {
        throw new ACCEError("أمر غير معروف: " + cmd, lineNo);
      }
    }
  }

  root.ACCEEngine = ACCEEngine;
  if (typeof module !== "undefined" && module.exports) module.exports = ACCEEngine;
})(typeof globalThis !== "undefined" ? globalThis : this);
