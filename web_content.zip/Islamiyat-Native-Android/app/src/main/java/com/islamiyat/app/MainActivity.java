package com.islamiyat.app;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.webkit.*;import java.util.*;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);web=findViewById(R.id.web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(this),"Android");web.loadUrl("file:///android_asset/index.html");
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},20);
  PrayerScheduler.scheduleNextDays(this,7);
 }
 public static class Bridge { Context c; Bridge(Context c){this.c=c;} @JavascriptInterface public void setAdhanVoice(String v){c.getSharedPreferences("adhan",0).edit().putString("voice",v).apply();} @JavascriptInterface public void setAdhanEnabled(boolean v){c.getSharedPreferences("adhan",0).edit().putBoolean("enabled",v).apply();} }
}
