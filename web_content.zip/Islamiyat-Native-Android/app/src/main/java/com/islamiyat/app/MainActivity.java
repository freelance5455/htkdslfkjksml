package com.islamiyat.app;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.os.*;import android.webkit.*;

public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);web=findViewById(R.id.web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Bridge(this),"Android");web.loadUrl("file:///android_asset/index.html");
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},20);
  PrayerScheduler.scheduleNextDays(this,7);
  android.content.SharedPreferences d=getSharedPreferences("dhikr",0); if(d.getBoolean("enabled",true)) ReminderScheduler.schedule(this,"dhikr",d.getInt("minutes",5));
  android.content.SharedPreferences ssp=getSharedPreferences("salawat",0); if(ssp.getBoolean("enabled",false)) ReminderScheduler.schedule(this,"salawat",ssp.getInt("minutes",5));
 }
 public static class Bridge {
  Context c; Bridge(Context c){this.c=c;}
  @JavascriptInterface public void setAdhanVoice(String v){c.getSharedPreferences("adhan",0).edit().putString("voice",v).apply();}
  @JavascriptInterface public void setAdhanEnabled(boolean v){c.getSharedPreferences("adhan",0).edit().putBoolean("enabled",v).apply();}
  @JavascriptInterface public void setDhikrSettings(boolean enabled,int minutes,boolean ignored){minutes=Math.max(1,Math.min(minutes,15));android.content.SharedPreferences.Editor e=c.getSharedPreferences("dhikr",0).edit().putBoolean("enabled",enabled).putInt("minutes",minutes);e.apply();if(enabled)ReminderScheduler.schedule(c,"dhikr",minutes);else ReminderScheduler.cancel(c,"dhikr");}
  @JavascriptInterface public void setSalawatSettings(boolean enabled,int minutes){minutes=Math.max(1,Math.min(minutes,15));android.content.SharedPreferences.Editor e=c.getSharedPreferences("salawat",0).edit().putBoolean("enabled",enabled).putInt("minutes",minutes);e.apply();if(enabled)ReminderScheduler.schedule(c,"salawat",minutes);else ReminderScheduler.cancel(c,"salawat");}
 }
}
