package com.islamiyat.app;
import android.content.*;import android.os.*;
public class PrayerAlarmReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ if("PLAY_ADHAN".equals(i.getAction())){Intent s=new Intent(c,AdhanService.class);s.setAction("PLAY");s.putExtra("prayer",i.getStringExtra("prayer"));if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}}}
