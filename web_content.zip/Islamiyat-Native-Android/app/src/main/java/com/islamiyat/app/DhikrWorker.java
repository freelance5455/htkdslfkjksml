package com.islamiyat.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import java.util.Locale;

public class DhikrWorker extends Worker {
    private static final String CHANNEL = "dhikr_channel";
    private static final String[] DHIKR = {
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ",
            "لَا إِلَهَ إِلَّا اللَّهُ", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
            "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "حَسْبِيَ اللَّهُ وَنِعْمَ الْوَكِيلُ",
            "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ ﷺ", "سُبْحَانَ اللَّهِ الْعَظِيمِ",
            "رَبِّ اغْفِرْ لِي وَارْحَمْنِي"
    };
    public DhikrWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        Context c=getApplicationContext();
        if(!c.getSharedPreferences("dhikr",0).getBoolean("enabled",true)) return Result.success();
        int index=c.getSharedPreferences("dhikr",0).getInt("index",0);
        String text=DHIKR[index % DHIKR.length];
        c.getSharedPreferences("dhikr",0).edit().putInt("index",index+1).apply();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"تذكيرات الأذكار",NotificationManager.IMPORTANCE_HIGH));
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL)
                .setSmallIcon(com.islamiyat.app.R.drawable.ic_launcher_foreground)
                .setContentTitle("🤲 ذكر جديد")
                .setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH);
        nm.notify(7001,text.hashCode(),b.build());
        if(c.getSharedPreferences("dhikr",0).getBoolean("salatVoice",false)) speak(c,"اللهم صل وسلم على نبينا محمد ﷺ");
        return Result.success();
    }
    private void speak(Context c,String text){
        TextToSpeech tts=new TextToSpeech(c,status->{
            if(status==TextToSpeech.SUCCESS){ tts.setLanguage(new Locale("ar")); tts.setSpeechRate(0.9f); tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"salat_voice"); }
        });
    }
}
