package com.islamiyat.app;
import android.app.*;import android.content.*;import android.media.*;import android.os.*;import androidx.core.app.NotificationCompat;

public class AdhanService extends Service { MediaPlayer player; static final String CH="adhan"; @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CH,"الأذان",NotificationManager.IMPORTANCE_HIGH));}
 @Override public int onStartCommand(Intent in,int flags,int id){String prayer=in.getStringExtra("prayer");startForeground(1001,notification(prayer));if(!getSharedPreferences("adhan",0).getBoolean("enabled",true)){stopSelf();return START_NOT_STICKY;}String voice=getSharedPreferences("adhan",0).getString("voice","a9");String url="https://cdn.aladhan.com/audio/adhans/"+voice+".mp3";try{player=new MediaPlayer();player.setAudioStreamType(AudioManager.STREAM_MUSIC);player.setDataSource(url);player.setOnPreparedListener(MediaPlayer::start);player.setOnCompletionListener(mp->{mp.release();stopSelf();});player.setOnErrorListener((mp,w,e)->{mp.release();stopSelf();return true;});player.prepareAsync();}catch(Exception e){stopSelf();}return START_NOT_STICKY;}
 Notification notification(String p){return new NotificationCompat.Builder(this,CH).setSmallIcon(android.R.drawable.ic_lock_silent_mode_off).setContentTitle("حان وقت الصلاة 🕌").setContentText(ar(p)).setOngoing(false).setPriority(NotificationCompat.PRIORITY_HIGH).build();}
 String ar(String p){if("Fajr".equals(p))return"الفجر";if("Dhuhr".equals(p))return"الظهر";if("Asr".equals(p))return"العصر";if("Maghrib".equals(p))return"المغرب";return"العشاء";}
 @Override public void onDestroy(){if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();}super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
