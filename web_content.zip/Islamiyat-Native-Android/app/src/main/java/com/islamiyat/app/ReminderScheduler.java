package com.islamiyat.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderScheduler {
    private static final int DHIKR_REQ = 9101;
    private static final int SALAWAT_REQ = 9102;
    public static void schedule(Context c, String type, int minutes) {
        minutes = Math.max(1, Math.min(minutes, 15));
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(c, ReminderReceiver.class).putExtra("type", type).putExtra("minutes", minutes);
        int req = type.equals("salawat") ? SALAWAT_REQ : DHIKR_REQ;
        PendingIntent pi = PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        long at = System.currentTimeMillis() + minutes * 60_000L;
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
    }
    public static void cancel(Context c, String type) {
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c, ReminderReceiver.class).putExtra("type",type);
        int req=type.equals("salawat")?SALAWAT_REQ:DHIKR_REQ;
        PendingIntent pi=PendingIntent.getBroadcast(c,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        am.cancel(pi);
    }
}
