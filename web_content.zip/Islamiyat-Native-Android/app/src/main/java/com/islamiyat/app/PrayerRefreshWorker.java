package com.islamiyat.app;
import android.content.*;import androidx.annotation.NonNull;import androidx.work.*;
public class PrayerRefreshWorker extends Worker { public PrayerRefreshWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);} @NonNull @Override public Result doWork(){PrayerScheduler.scheduleNextDays(getApplicationContext(),7);return Result.success();}}
