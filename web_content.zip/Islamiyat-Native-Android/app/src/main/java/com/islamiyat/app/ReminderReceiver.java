package com.islamiyat.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import java.util.*;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_DHIKR="dhikr_channel";
    private static final String CHANNEL_SALAWAT="salawat_channel";
    private static final String[] DHIKR={
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ","الْحَمْدُ لِلَّهِ","اللَّهُ أَكْبَرُ",
        "لَا إِلَهَ إِلَّا اللَّهُ","أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
        "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ","حَسْبِيَ اللَّهُ وَنِعْمَ الْوَكِيلُ",
        "سُبْحَانَ اللَّهِ الْعَظِيمِ","رَبِّ اغْفِرْ لِي وَارْحَمْنِي"
    };
    @Override public void onReceive(Context c, Intent in){
        String type=in.getStringExtra("type");
        if(type==null) type="dhikr";
        android.content.SharedPreferences sp=c.getSharedPreferences(type.equals("salawat")?"salawat":"dhikr",0);
        if(!sp.getBoolean("enabled",false)) return;
        String text;
        int idx=sp.getInt("index",0);
        if(type.equals("salawat")) text="اللهم صل وسلم وبارك على نبينا محمد ﷺ";
        else { text=DHIKR[idx%DHIKR.length]; sp.edit().putInt("index",idx+1).apply(); }
        String channel=type.equals("salawat")?CHANNEL_SALAWAT:CHANNEL_DHIKR;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,type.equals("salawat")?"الصلاة على النبي ﷺ":"تذكيرات الأذكار",NotificationManager.IMPORTANCE_HIGH));
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,channel).setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(type.equals("salawat")?"❤️ الصلاة على النبي ﷺ":"🤲 ذكر جديد")
            .setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH);
        nm.notify(type.equals("salawat")?7002:7001,(int)System.currentTimeMillis(),b.build());
        int minutes=Math.max(1,Math.min(in.getIntExtra("minutes",5),15));
        ReminderScheduler.schedule(c,type,minutes);
    }
}
