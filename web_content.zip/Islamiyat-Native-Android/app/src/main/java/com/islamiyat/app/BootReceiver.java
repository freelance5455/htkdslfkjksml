package com.islamiyat.app;
import android.content.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){
 WorkManager.getInstance(c).enqueueUniquePeriodicWork("prayer_refresh",ExistingPeriodicWorkPolicy.UPDATE,new PeriodicWorkRequest.Builder(PrayerRefreshWorker.class,24,TimeUnit.HOURS).build());
 android.content.SharedPreferences d=c.getSharedPreferences("dhikr",0); if(d.getBoolean("enabled",true)) ReminderScheduler.schedule(c,"dhikr",d.getInt("minutes",5));
 android.content.SharedPreferences s=c.getSharedPreferences("salawat",0); if(s.getBoolean("enabled",false)) ReminderScheduler.schedule(c,"salawat",s.getInt("minutes",5));
 WorkManager.getInstance(c).enqueue(new OneTimeWorkRequest.Builder(PrayerRefreshWorker.class).build()); }}
