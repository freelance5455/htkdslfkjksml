package com.islamiyat.app;
import android.content.*;import androidx.work.*;import java.util.concurrent.TimeUnit;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ WorkManager.getInstance(c).enqueueUniquePeriodicWork("prayer_refresh",ExistingPeriodicWorkPolicy.UPDATE,new PeriodicWorkRequest.Builder(PrayerRefreshWorker.class,24,TimeUnit.HOURS).build()); WorkManager.getInstance(c).enqueue(new OneTimeWorkRequest.Builder(PrayerRefreshWorker.class).build()); }}
