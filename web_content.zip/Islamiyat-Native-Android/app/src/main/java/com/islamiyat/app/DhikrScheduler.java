package com.islamiyat.app;
import android.content.Context;
/** Legacy compatibility wrapper. Minute-accurate reminders are handled by ReminderScheduler. */
public class DhikrScheduler {
 public static void schedule(Context c,int minutes){ ReminderScheduler.schedule(c,"dhikr",minutes); }
 public static void cancel(Context c){ ReminderScheduler.cancel(c,"dhikr"); }
}
