# Bilal Rider Pro — Android Studio project

Premium black & metallic-gold personal hisab app starter.

## Included
- First-run account setup (name + password) and login/lock screen
- Offline local records using browser localStorage
- Opening/current balance, income, expenses, date/category/notes
- Separate bike/petrol entry (amount, optional litres/km) and rider earnings
- Recent transactions, record filtering, daily summaries
- Receipt preview and generated PNG image
- Android native Gallery save and Android share sheet (WhatsApp can be selected)
- JSON backup and restore
- Responsive black-and-gold dashboard

## Build
Open this folder in Android Studio (recent version with Android Gradle Plugin 8.6.1 support), allow Gradle sync, then Build > Build APK(s).

This ZIP contains Android Studio source code, not a prebuilt APK. Build and test it on a real Android phone before relying on it.

## Important limitations
- Records are stored locally on this device. Export JSON backups regularly before clearing app data or changing phones.
- Login is a convenience lock, not bank-grade security; financial records are stored locally and are not encrypted.
- Image sharing opens Android's system share sheet; choose WhatsApp if installed. It cannot force a WhatsApp send without the user's confirmation.
- This project was generated as a starter and has not been compiled or device-tested in this environment.
