# Bilal Rider Pro — Android Studio project

Premium black & metallic-gold personal hisab app.

## This update
- Multi-user account creation and login; each account's financial records are stored separately on this device.
- AndroidX BiometricPrompt fingerprint/device credential unlock. Enable it when creating an account or in Settings.
- Login screen centered vertically.
- Cash in hand, bank balance, and total available balance page (manually entered; no bank connection).
- Daily income/expense, bike/petrol, rider earnings, reports, receipt PNG, share sheet and per-account JSON backup.

## Build
Open in Android Studio, sync Gradle, then Build > Build APK(s).

## Important
This is a local/offline starter project and has not been compiled or tested on a physical phone in this environment. Accounts do not sync across phones. Local WebView records are not encrypted, so this is not a hardened security boundary. Back up each account separately. Fingerprint requires a supported Android device with biometric/device screen lock configured.
