# Internal label distribution workflow — staff only

This document is for Imposed Entertainment staff. Do not expose distributor-specific operational details in artist-facing screens, messages, or downloads.

The artist portal is for metadata, assets, submission, feedback, and status tracking. Distributor operations are handled internally by the label.

## Staff workflow
1. Review artist submissions and request changes where necessary.
2. Use the internal handoff sheet and downloaded assets to enter release details into the label's distributor account.
3. Verify track metadata, artist roles, audio, artwork, rights, dates, copyright lines, stores and territories.
4. Submit the release to the distributor's moderation process.
5. Update the portal status to indicate that distribution processing has begun.
6. Mark the release live only after confirming availability on the intended stores.

## Upload requirements
Check the distributor's current official specifications before each submission. The portal's local checks are intended as guidance and do not guarantee acceptance.
