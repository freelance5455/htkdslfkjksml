
import {initializeApp} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import {getAuth,signInWithEmailAndPassword,onAuthStateChanged,signOut} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import {getDatabase,ref,onValue,get,set,update,remove,push} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

const cfg={
  apiKey:"AIzaSyCrpuoLwacJTLiEuF7dIAM5S7zdcRzZ9n0",
  authDomain:"data-x-pro-fd590.firebaseapp.com",
  databaseURL:"https://data-x-pro-fd590-default-rtdb.firebaseio.com",
  projectId:"data-x-pro-fd590",
  storageBucket:"data-x-pro-fd590.firebasestorage.app",
  messagingSenderId:"392251029137",
  appId:"1:392251029137:android:d87145cdd1fb5861e43130"
};
let app,auth,db;
try{app=initializeApp(cfg);auth=getAuth(app);db=getDatabase(app)}catch(e){document.body.innerHTML=`<main style="padding:24px;color:#fff;font-family:system-ui"><h2>Admin could not start</h2><p>Firebase configuration could not be loaded. Check the Firebase configuration and reload.</p></main>`;throw e}
const ADMIN="IIKepLhzyXMoKlxNOmidZ7FmIUq1";
const $=id=>document.getElementById(id);
const show=e=>e?.classList.remove("hidden"), hide=e=>e?.classList.add("hidden");
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
const safeKey=s=>String(s??"").replace(/[^A-Za-z0-9_-]/g,"");
const maskEmail=e=>{const s=String(e||"");const [a,b]=s.split("@");return a?(a.slice(0,2)+"•••"+(b?"@"+b:"")):"—"};
const maskMobile=m=>{const s=String(m||"");return s.length>4?"••••••"+s.slice(-4):"••••"};
const money=n=>"₹"+Number(n||0).toFixed(2);
function fmtDT(ms){ const n=Number(ms); if(!Number.isFinite(n)||n<=0)return "—"; return new Date(n).toLocaleString(undefined,{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true}); }
function random(n=9){ const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; let out=""; const a=new Uint32Array(n); crypto.getRandomValues(a); for(let i=0;i<n;i++) out+=chars[a[i]%chars.length]; return out; }
function keyLifetime(policy){ const value=Math.max(1,Number(policy?.keyLifetimeValue)||24); const unit=policy?.keyLifetimeUnit||"hours"; return unit==="seconds"?value*1000:unit==="minutes"?value*60*1000:value*60*60*1000; }
function keyLifetimeLabel(policy){ const value=Math.max(1,Number(policy?.keyLifetimeValue)||24); const unit=policy?.keyLifetimeUnit||"hours"; const label=unit==="seconds"?"second":unit==="minutes"?"minute":"hour"; return `${value} ${label}${value===1?"":"s"}`; }
async function ensureAdminSession(){
  const u=auth.currentUser;
  if(!u) throw new Error("Admin session is not signed in.");
  if(u.uid!==ADMIN) throw new Error("Authorised admin UID mismatch: "+u.uid);
  await u.getIdToken(true);
  return u;
}
async function safeRemove(path){
  await ensureAdminSession();
  // Use RTDB remove() for an explicit server-side delete.
  await remove(ref(db,path));
}
async function firebaseAdminSelfTest(){
  if(auth.currentUser?.uid!==ADMIN) throw new Error("Admin authorisation required");
  const token=await auth.currentUser.getIdToken(true);
  if(!token) throw new Error("Admin token unavailable");
  return {uid:auth.currentUser.uid,admin:true};
}
window.toast=(text,type="ok")=>{let t=document.querySelector(".lux-toast");if(!t){t=document.createElement("div");t.className="lux-toast";document.body.appendChild(t)}t.textContent=text;t.classList.toggle("bad",type==="bad");requestAnimationFrame(()=>t.classList.add("show"));clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove("show"),1800)};
async function withRefresh(btn,fn){
  if(!btn||btn.dataset.busy==="1")return;
  btn.dataset.busy="1";btn.classList.add("is-refreshing");
  const old=btn.innerHTML;btn.innerHTML='<span class="spin">↻</span> Refreshing';
  const started=performance.now();
  try{await fn()}catch(e){window.toast("Refresh failed: "+(e?.code||e?.message||"Unknown error"),"bad")}
  finally{
    const wait=Math.max(0,2000-(performance.now()-started));
    setTimeout(()=>{btn.innerHTML=old;btn.classList.remove("is-refreshing");btn.dataset.busy="0"},wait);
  }
}
function setActionBusy(btn,busy,label){if(!btn)return;if(busy){btn.dataset.oldText=btn.innerHTML;btn.disabled=true;btn.innerHTML='<span class="spin">◌</span> '+(label||"Working") }else{btn.disabled=false;btn.innerHTML=btn.dataset.oldText||btn.innerHTML}}
function authMessage(e){const c=e?.code||"";if(["auth/invalid-credential","auth/wrong-password","auth/user-not-found","auth/invalid-email"].includes(c))return "Wrong email or password.";if(c==="auth/too-many-requests")return "Too many attempts. Please try again later.";if(c==="auth/network-request-failed")return "Network error. Check your internet connection.";return "Something went wrong. Please try again."}
async function audit(action,extra={}){try{await push(ref(db,"auditLogs"),{action,at:Date.now(),...extra})}catch(e){console.warn("Audit write failed",e)}}
async function deleteUserProfile(uid){
 if(auth.currentUser?.uid!==ADMIN)throw new Error("Admin authorisation required");
 const now=Date.now();
 const updates={};
 updates[`users/${uid}`]=null;
 updates[`deletedUsers/${uid}`]={deletedAt:now,deletedBy:auth.currentUser?.uid||ADMIN};
 await update(ref(db),updates);
 try{await audit("Deleted user profile",{uid})}catch{}
}

let adminUiOpening=false;
async function openAdminUi(){
  if(adminUiOpening)return;
  const u=auth.currentUser;
  if(!u || u.uid!==ADMIN)return;
  adminUiOpening=true;
  hide($("auth"));show($("logout"));hide($("dash"));
  const gate=document.createElement("div");gate.className="access-granted";gate.innerHTML='<div class="grant-icon">✓</div><div class="grant-kicker">SECURITY VERIFIED</div><h2>AUTHORISED GRANTED</h2><p>Admin identity verified successfully.</p>';document.body.appendChild(gate);
  setTimeout(()=>{gate.classList.add("leave");setTimeout(()=>{gate.remove();show($("dash"));loadDashboard();adminUiOpening=false},260)},420);
}
$("login").addEventListener("click",async()=>{
  const email=$("email").value.trim(),pass=$("pass").value,btn=$("login"),state=$("loginState");
  $("msg").className="msg"; $("msg").textContent="";
  if(!email||!pass){$("msg").className="msg error";$("msg").textContent="Enter admin email and password.";return}
  btn.disabled=true;btn.textContent="Authenticating…";state.textContent="● VERIFYING AUTHORISATION";
  try{
    const credential=await signInWithEmailAndPassword(auth,email,pass);
    if(credential.user.uid!==ADMIN){await signOut(auth);throw Object.assign(new Error("Only authorised admin login is allowed."),{code:"auth/not-admin"})}
    state.textContent="● AUTHORISATION VERIFIED";
    await openAdminUi();
  }catch(e){$("msg").className="msg error";$("msg").textContent=e?.code==="auth/not-admin"?"Only authorised admin login is allowed.":authMessage(e);state.textContent="● ADMIN ACCESS DENIED"}
  finally{btn.disabled=false;btn.textContent="Secure Admin Login"}
});
$("pass").addEventListener("keydown",e=>{if(e.key==="Enter")$("login").click()});
$("logout").addEventListener("click",async()=>{try{await signOut(auth);$("msg").className="msg";$("msg").textContent=""}catch(e){window.toast("Logout failed. Try again.","bad")}});

onAuthStateChanged(auth,async u=>{
  if(u?.uid===ADMIN){
    $("loginState").textContent="● AUTHORISATION VERIFIED";
    openAdminUi();
  }else if(u){
    await signOut(auth).catch(()=>{});show($("auth"));hide($("dash"));hide($("logout"));$("msg").className="msg error";$("msg").textContent="Only authorised admin login is allowed.";$("loginState").textContent="● ADMIN ACCESS REQUIRED";
  }else{show($("auth"));hide($("dash"));hide($("logout"));$("loginState").textContent="● ADMIN-ONLY ACCESS"}
});

document.querySelectorAll("[data-p]").forEach(btn=>{
  btn.addEventListener("click",()=>openPage(btn.dataset.p,btn));
});

async function loadDashboard(){
  if(dashboardLiveTimer){clearTimeout(dashboardLiveTimer);dashboardLiveTimer=null;}
  const renderToken=++dashboardRenderToken;
  try{await ensureAdminSession();
    const [u,w,a,settingsSnap]=await Promise.all([get(ref(db,"users")),get(ref(db,"withdrawals")),get(ref(db,"activationKeys")),get(ref(db,"settings"))]);
    if(renderToken!==dashboardRenderToken || activeSection) return;
    const userMap=u.val()||{};
    const users=Object.keys(userMap).length;
    const withdrawals=Object.values(w.val()||{});
    const keys=Object.values(a.val()||{});
    const settings=settingsSnap.val()||{};
    const showTotalBalance=settings.showTotalBalance!==false;
    const showPendingWithdrawalBalance=settings.showPendingWithdrawalBalance!==false;
    const pendingRows=withdrawals.filter(x=>String(x.status||"PENDING").toUpperCase()==="PENDING");
    const pending=pendingRows.length;
    // Financial dashboard values are read-only aggregates of stored records.
    // Total Balance intentionally uses users/*/balance only, so pending withdrawal
    // amounts are never silently added a second time.
    const totalBalance=Object.values(userMap).reduce((sum,user)=>{
      const n=Number(user?.balance);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const pendingWithdrawalBalance=pendingRows.reduce((sum,item)=>{
      const n=Number(item?.amount);
      return sum+(Number.isFinite(n)?n:0);
    },0);
    const now=Date.now();
    const active=keys.filter(x=>{
      const status=String(x.status||"ACTIVE").toUpperCase();
      const exp=Number(x.expiresAt||0);
      return status==="ACTIVE" && (!exp || exp>now);
    }).length;
    const liveUsers=Object.values(u.val()||{}).filter(x=>x?.online===true || (x?.lastSeenAt && now-Number(x.lastSeenAt)<5*60*1000)).length;
    const expired=keys.filter(x=>String(x.status||"").toUpperCase()==="EXPIRED" || ((x.expiresAt||0)>0 && Number(x.expiresAt)<=now)).length;
    $("page").innerHTML=`<div class="section-head dashboard-head"><div><span class="eyebrow">PRIVATE ADMIN SPACE</span><h2>Control Center</h2><p class="muted">Secure controls for DATA X PRO. Sensitive identifiers are hidden from the dashboard.</p></div>
      <div class="dashboard-tools"><button class="secondary" id="refreshDashboard">↻ Refresh</button><div class="hero-orb">✦</div></div></div>
    <div class="admin-command-banner">
      <span class="admin-command-icon">♛</span>
      <div><small>PRIVATE CONTROL</small><strong>ADMIN-ONLY ACCESS</strong><em>Protected command environment · Sensitive identifiers hidden</em></div>
      <span class="admin-command-status"><i></i>SECURE</span>
    </div>
    <div class="live-control-grid premium-live-grid">
      <article class="live-control-card live-user-card"><span class="live-dot"></span><small>LIVE USERS</small><b id="liveUsersCount">${liveUsers}</b><em>online / recently active</em></article>
      <article class="live-control-card live-key-card"><span class="live-dot"></span><small>ACTIVE KEYS</small><b id="activeKeysCount">${active}</b><em>currently valid</em></article>
      <article class="live-control-card live-expired-card"><span class="live-dot"></span><small>EXPIRED KEYS</small><b id="expiredKeysCount">${expired}</b><em>past expiry</em></article>
      <article class="live-control-card live-withdrawal-card"><span class="live-dot"></span><small>PENDING WITHDRAWALS</small><b id="pendingWithdrawalsCount">${pending}</b><em>awaiting review</em></article>
      <article class="live-control-card live-total-card"><span class="live-dot"></span><small>TOTAL USERS</small><b id="totalUsersCount">${users}</b><em>registered accounts</em></article>
      ${showTotalBalance?`<article class="live-control-card live-balance-card financial-control-card"><span class="live-dot"></span><div class="financial-label"><small>TOTAL BALANCE</small><span class="financial-lock">LIVE</span></div><b id="totalBalanceValue">${money(totalBalance)}</b><em>sum of all users' stored balance</em></article>`:""}
      ${showPendingWithdrawalBalance?`<article class="live-control-card live-pending-balance-card financial-control-card"><span class="live-dot"></span><div class="financial-label"><small>PENDING WITHDRAWAL BALANCE</small><span class="financial-lock">QUEUE</span></div><b id="pendingWithdrawalBalanceValue">${money(pendingWithdrawalBalance)}</b><em>sum of pending withdrawal amounts</em></article>`:""}
    </div>
    <div class="financial-integrity-strip"><span>◈</span><div><strong>FINANCIAL SNAPSHOT</strong><small>Read-only aggregation · source: users/{uid}/balance + pending withdrawal amounts</small></div><time>${esc(fmtDT(Date.now()))}</time></div>`;
    const rd=$("refreshDashboard"); if(rd) rd.onclick=()=>withRefresh(rd,loadDashboard);
    const refreshSeconds=Math.max(5,Math.min(120,Number(settings.controlCenterRefreshSeconds)||10));
    dashboardLiveTimer=setTimeout(()=>{if(!activeSection) loadDashboard();},refreshSeconds*1000);
  }catch(e){if(renderToken===dashboardRenderToken && !activeSection)$("page").innerHTML=`<div class="notice error">Dashboard error: ${esc(e.message)}</div>`}
}

let sectionTransitionTimer=0;
let sectionOriginEl=null;
let sectionOriginRect=null;
let sectionMotionToken=0;
let dashboardRenderToken=0;
let activeSection=false;
let keyCountdownTimer=null;
let dashboardLiveTimer=null;

function rectNow(el){
  if(!el || !el.isConnected) return null;
  const r=el.getBoundingClientRect();
  if(!r.width || !r.height) return null;
  return {left:r.left,top:r.top,width:r.width,height:r.height};
}
function makeTransitionCard(el){
  // Blank shared-element shell: never clone the source text/content.
  // Cloning content and then non-uniformly scaling it is what creates the
  // "merged/warped" look on mobile. The shell is only a visual surface.
  const card=document.createElement("div");
  card.className="section-motion-card";
  card.setAttribute("aria-hidden","true");
  return card;
}
function placeMotionCard(card,r){
  card.style.left=r.left+"px";
  card.style.top=r.top+"px";
  card.style.width=r.width+"px";
  card.style.height=r.height+"px";
}
function animateMotionCard(card,from,to,duration,reverse=false){
  const dx=from.left-to.left, dy=from.top-to.top;
  const sx=from.width/to.width, sy=from.height/to.height;
  return card.animate([
    {transform:`translate3d(${dx}px,${dy}px,0) scale(${sx},${sy})`,opacity:reverse?1:.98},
    {transform:"translate3d(0,0,0) scale(1,1)",opacity:1}
  ],{duration,easing:"cubic-bezier(.22,1,.36,1)",fill:"forwards"}).finished;
}
function getPageTargetRect(){
  const mobile=window.matchMedia?.("(max-width:650px)")?.matches;
  const left=window.innerWidth*(mobile?.025:.03);
  const right=window.innerWidth*(mobile?.025:.03);
  const top=mobile?74:96;
  const bottom=mobile?10:18;
  return {left,top,width:Math.max(1,window.innerWidth-left-right),height:Math.max(1,window.innerHeight-top-bottom)};
}
function cleanupMotionCard(card){
  try{card?.getAnimations().forEach(a=>a.cancel())}catch{}
  card?.remove();
}
function nextFrame(){return new Promise(r=>requestAnimationFrame(()=>r()));}

async function enterFullSection(source){
  const dash=$("dash"), page=$("page");
  if(!dash || !page)return;
  clearTimeout(sectionTransitionTimer);
  sectionMotionToken++;
  const token=sectionMotionToken;
  sectionOriginEl=source||null;
  sectionOriginRect=rectNow(sectionOriginEl);

  // Freeze the old dashboard BEFORE changing #page. This prevents the
  // dashboard's Control Center text from ever being painted underneath the
  // transition shell.
  dash.classList.add("section-open","section-nav-lock");
  page.classList.add("section-prep");
  void page.offsetWidth;
  const target=getPageTargetRect();
  const shell=sectionOriginRect?makeTransitionCard(source):null;
  if(shell){
    document.body.appendChild(shell);
    placeMotionCard(shell,sectionOriginRect);
  }

  // Let the browser paint the starting frame before doing any animation.
  await nextFrame();
  if(token!==sectionMotionToken){cleanupMotionCard(shell);return}

  if(shell&&target){
    try{await animateMotionCard(shell,sectionOriginRect,target,430)}catch{}
  }
  if(token!==sectionMotionToken){cleanupMotionCard(shell);return}

  page.classList.remove("section-prep");
  page.classList.add("section-enter-content");
  sectionTransitionTimer=setTimeout(()=>page.classList.remove("section-enter-content"),340);
  cleanupMotionCard(shell);
  window.scrollTo({top:0,left:0,behavior:"auto"});
}

async function exitFullSection(){
  const dash=$("dash"), page=$("page");
  if(!dash || !page)return;
  clearTimeout(sectionTransitionTimer);
  sectionMotionToken++;
  const token=sectionMotionToken;
  const sourceRect=sectionOriginRect;
  const from=getPageTargetRect();

  page.classList.remove("section-enter-content");
  page.classList.add("section-closing");
  await nextFrame();
  if(token!==sectionMotionToken)return false;

  const shell=sourceRect?makeTransitionCard(sectionOriginEl):null;
  if(shell&&from){
    document.body.appendChild(shell);
    placeMotionCard(shell,sourceRect);
    try{
      const dx=from.left-sourceRect.left,dy=from.top-sourceRect.top;
      const sx=from.width/sourceRect.width,sy=from.height/sourceRect.height;
      await shell.animate([
        {transform:`translate3d(${dx}px,${dy}px,0) scale(${sx},${sy})`,opacity:1},
        {transform:"translate3d(0,0,0) scale(1,1)",opacity:1}
      ],{duration:400,easing:"cubic-bezier(.7,0,.84,1)",fill:"forwards"}).finished;
    }catch{}
    cleanupMotionCard(shell);
  }
  if(token!==sectionMotionToken)return false;

  dash.classList.remove("section-open","section-nav-lock");
  page.classList.remove("section-closing","section-leave","section-prep");
  sectionOriginEl=null;
  sectionOriginRect=null;
  activeSection=false;
  return true;
}
function addSectionBackButton(){
  const page=$("page");
  if(!page || page.querySelector("[data-back-dashboard],.section-back"))return;
  const head=page.querySelector(".section-head");
  if(!head)return;
  const b=document.createElement("button");
  b.type="button";b.className="secondary section-back";b.dataset.backDashboard="1";
  b.innerHTML="<span>←</span> Dashboard";
  b.addEventListener("click",async()=>{if(b.dataset.busy==="1")return;b.dataset.busy="1";activeSection=false;dashboardRenderToken++;await exitFullSection();await loadDashboard()});
  head.insertBefore(b,head.firstChild);
}
function openPage(p,source){
  const el=$("page");
  if(p==="dashboard"){activeSection=false;dashboardRenderToken++;return exitFullSection().then(()=>loadDashboard());}
  activeSection=true;
  dashboardRenderToken++;
  enterFullSection(source);
  if(p==="users"){ const r=openUsers(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="keys"){ const r=openKeys(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="withdrawals"){ const r=openWithdrawals(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="support"){ const r=openSupport(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="notifications"){ const r=openNotifications(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="settings"){ const r=openSettings(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="audit"){ const r=openAudit(el); setTimeout(addSectionBackButton,0); return r; }
  if(p==="security"){ const r=openSecurity(el); setTimeout(addSectionBackButton,0); return r; }
  loadDashboard();
}

function openUsers(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">USER CONTROL</span><h2>Users</h2><p class="muted">Edit, level-control, block/unblock and remove user profiles.</p></div><button class="secondary" id="refreshUsers">↻ Refresh</button></div>
  <div class="glassbar"><input id="userSearch" placeholder="Search by name, masked email or mobile ending"></div><div id="usersList">Loading…</div>`;
  $("refreshUsers").onclick=()=>withRefresh($("refreshUsers"),loadUsers);
  $("userSearch").oninput=()=>renderUsers(window.__users||{});
  loadUsers();
}
async function loadUsers(){await ensureAdminSession();
  try{const s=await get(ref(db,"users"));window.__users=s.val()||{};renderUsers(window.__users)}
  catch(e){$("usersList").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}
}
function renderUsers(data){
  const q=($("userSearch")?.value||"").toLowerCase();
  const entries=Object.entries(data).filter(([uid,u])=>{
    const hay=[u.name,maskEmail(u.email),maskMobile(u.mobile),String(u.level??0),u.status].join(" ").toLowerCase();
    return !q||hay.includes(q);
  });
  $("usersList").innerHTML=entries.length?entries.map(([uid,u])=>{
    const status=String(u.status||"ACTIVE"),level=Number(u.level||0);
    return `<article class="user-card">
      <div class="user-main">
        <div class="avatar">${esc((u.name||"U").slice(0,1).toUpperCase())}</div>
        <div><b>${esc(u.name||"Unnamed")}</b><div class="muted">${esc(maskEmail(u.email))} · ${esc(maskMobile(u.mobile))}</div></div>
        <div class="user-level">LEVEL ${level}</div><div class="user-status ${status==="BLOCKED"?"blocked":""}">${esc(status)}</div>
      </div>
      <div class="user-actions">
        <button data-act="edit" data-uid="${esc(uid)}">✎ Edit</button>
        <button data-act="level" data-uid="${esc(uid)}">◆ Level</button>
        <button data-act="${status==="BLOCKED"?"unblock":"block"}" data-uid="${esc(uid)}">${status==="BLOCKED"?"✓ Unblock":"⛔ Block"}</button>
        <button class="danger" data-act="delete" data-uid="${esc(uid)}">⌫ Delete</button>
      </div>
    </article>`;
  }).join(""):`<div class="notice">No users found.</div>`;
  $("usersList").querySelectorAll("[data-act]").forEach(b=>b.onclick=()=>userAction(b.dataset.act,b.dataset.uid));
}
async function userAction(action,uid){
  const u=window.__users?.[uid]; if(!u)return;
  try{
    if(action==="edit")return openUserEditor(uid);
    if(action==="level") return openLevelEditor(uid);
    if(action==="block"||action==="unblock"){
      const status=action==="block"?"BLOCKED":"ACTIVE";
      await update(ref(db,`users/${uid}`),{status,blockedAt:status==="BLOCKED"?Date.now():null,updatedAt:Date.now()});
      await audit(status==="BLOCKED"?"Blocked user":"Unblocked user",{uid});window.toast(status==="BLOCKED"?"User blocked":"User unblocked");return loadUsers();
    }
    if(action==="delete"){
      if(!confirm("Delete this user's DATA X PRO profile? The profile will disappear from the database."))return;
      await deleteUserProfile(uid);window.toast("User deleted. The profile is now marked deleted.");return loadUsers();
    }
  }catch(e){window.toast("Action failed: "+e.message,"bad")}
}
async function openLevelEditor(uid){
  const u=window.__users?.[uid]; if(!u)return;
  const modal=document.createElement("div");modal.className="modal-backdrop";
  modal.innerHTML=`<div class="editor-modal level-modal"><div class="section-head"><div><span class="eyebrow">LEVEL CONTROL</span><h2>Set User Level</h2><p class="muted">Choose an exact level from 0 to 5.</p></div><button class="secondary" data-close>×</button></div><div class="level-picker">${[0,1,2,3,4,5].map(n=>`<button class="level-option ${Number(u.level||0)===n?'selected':''}" data-level="${n}"><span>LEVEL ${n}</span><small>${['Bronze','Silver','Gold','Platinum','Diamond','Master'][n]}</small></button>`).join('')}</div><div class="editor-footer"><button class="secondary" data-close>Cancel</button><button data-save>Save Level</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>modal.remove());
  let selected=Number(u.level||0);
  modal.querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>{selected=Number(b.dataset.level);modal.querySelectorAll('[data-level]').forEach(x=>x.classList.remove('selected'));b.classList.add('selected')});
  modal.querySelector('[data-save]').onclick=async()=>{try{await update(ref(db,`users/${uid}`),{level:selected,updatedAt:Date.now()});await audit('Set exact user level',{uid,level:selected});modal.remove();window.toast('Level saved');await loadUsers()}catch(e){window.toast('Level save failed: '+e.message,'bad')}};
}

async function openUserEditor(uid){
  const s=await get(ref(db,`users/${uid}`));if(!s.exists())return window.toast("User not found","bad");
  const u=s.val()||{};
  const modal=document.createElement("div");modal.className="modal-backdrop";
  modal.innerHTML=`<div class="editor-modal">
    <div class="section-head"><div><span class="eyebrow">PRIVATE PROFILE</span><h2>Edit User</h2><p class="muted">Internal ID is hidden from the interface.</p></div><button class="secondary" data-close>×</button></div>
    <div class="editor-grid">
      <label>Name<input id="eName" value="${esc(u.name||"")}"></label>
      <label>Mobile<input id="eMobile" value="${esc(u.mobile||"")}"></label>
      <label>Email<input id="eEmail" value="${esc(u.email||"")}"></label>
      <label>Exact Level<select id="eLevel">${[0,1,2,3,4,5].map(n=>`<option value="${n}" ${Number(u.level||0)===n?"selected":""}>Level ${n}</option>`).join("")}</select></label>
      <label>Status<select id="eStatus"><option ${u.status!=="BLOCKED"?"selected":""}>ACTIVE</option><option ${u.status==="BLOCKED"?"selected":""}>BLOCKED</option></select></label>
      <label>Balance<input id="eBalance" type="number" step="0.01" value="${Number(u.balance||0)}"></label>
    </div>
    <div class="notice">Changes are written to Firebase and an admin audit entry is created.</div>
    <div class="editor-footer"><button class="danger" data-delete>Delete profile</button><button data-save>Save changes</button></div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector("[data-close]").onclick=()=>modal.remove();
  modal.querySelector("[data-delete]").onclick=async()=>{modal.remove();await userAction("delete",uid)};
  modal.querySelector("[data-save]").onclick=async()=>{
    try{
      await update(ref(db,`users/${uid}`),{
        name:$("eName").value.trim(),mobile:$("eMobile").value.trim(),email:$("eEmail").value.trim(),
        level:Number($("eLevel").value),status:$("eStatus").value,balance:Number($("eBalance").value)||0,updatedAt:Date.now()
      });
      await audit("Edited user profile",{uid});modal.remove();window.toast("Changes saved");loadUsers();
    }catch(e){window.toast("Save failed: "+e.message,"bad")}
  };
}

function openKeys(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">SECURE KEY CENTER</span><h2>Key Command</h2><p class="muted">Exact key lifecycle, second-level expiry, binding and permanent admin deletion.</p></div><div class="toolbar"><button class="secondary" id="refreshKeys">↻ Refresh</button><button class="secondary" id="cleanKeys">🧹 Clean expired</button></div></div>
  <div class="god-eyes card"><div><span class="eyebrow">GOD EYES · LIVE KEY WATCH</span><h3>Key Command Vision</h3><p class="muted">Live expiry telemetry updates every second from the stored expiry timestamp.</p></div><div class="eyes-stats"><div><small>ACTIVE</small><b id="eyesActive">—</b></div><div><small>EXPIRING &lt; 1H</small><b id="eyesSoon">—</b></div><div><small>EXPIRED</small><b id="eyesExpired">—</b></div><div><small>NEXT EXPIRY</small><b id="eyesNext">—</b></div></div></div><div class="key-grid">${[["ACTIVATION","🔥","Activation","ADX-"],["WITHDRAWAL","💳","Withdrawal","A_WD_"],["BRONZE","🥉","Bronze","BRONZE_"],["SILVER","🥈","Silver","SILVER_"],["GOLD","🥇","Gold","GOLD_"],["PLATINUM","💎","Platinum","PLATINUM_"],["DIAMOND","💠","Diamond","DIAMOND_"],["MASTER","👑","Master","MASTER_"]].map(x=>`<button class="keytype" data-keytype="${x[0]}"><span class="icon">${x[1]}</span><b>${x[2]}</b><small>${x[3]}…</small></button>`).join("")}</div>
  <div id="keyGenerator"></div>
  <div class="glassbar"><input id="keySearch" placeholder="Search key, username, number or status"><select id="keyFilter"><option>ALL</option><option>ACTIVE</option><option>USED</option><option>EXPIRED</option><option>REVOKED</option></select></div>
  <div class="key-head card"><span>Key</span><span>Created</span><span>Expiry</span><span>Status</span><span>Number</span><span>Username</span><span>Action</span></div><div id="keysList">Loading…</div>`;
  document.querySelectorAll("[data-keytype]").forEach(b=>b.onclick=()=>openKeyGenerator(b.dataset.keytype));
  $("refreshKeys").onclick=()=>withRefresh($("refreshKeys"),loadKeys);$("cleanKeys").onclick=cleanExpiredKeys;$('keySearch').oninput=loadKeys;$('keyFilter').onchange=loadKeys;loadKeys();
}
async function getKeyPolicy(){const s=await get(ref(db,"settings"));return s.val()||{keyLifetimeValue:24,keyLifetimeUnit:"hours"}}
function openKeyGenerator(type){
  const names={ACTIVATION:"Activation",WITHDRAWAL:"Withdrawal",BRONZE:"Bronze",SILVER:"Silver",GOLD:"Gold",PLATINUM:"Platinum",DIAMOND:"Diamond",MASTER:"Master"};
  $("keyGenerator").innerHTML=`<div class="card generator"><div class="section-head"><div><span class="eyebrow">ISSUE CREDENTIAL</span><h3>${names[type]} Key</h3><p id="keyPolicyText" class="muted">Loading policy…</p></div></div><div class="toolbar"><label class="qty-label">Quantity<input id="keyQty" type="number" min="1" max="100" value="1"></label><button id="generateKey">Generate Secure Key</button></div><div id="generated"></div></div>`;
  getKeyPolicy().then(v=>$("keyPolicyText").textContent=`Validity: ${keyLifetimeLabel(v)} from the exact creation time · one-time binding`);$("generateKey").onclick=()=>generateKeys(type);
}
async function generateKeys(type){
  const policy=await getKeyPolicy();
  if(policy.freezeKeyIssuance===true){window.toast("Key issuance is frozen in Settings","bad");return;}
  if(policy.adminReadOnly===true){window.toast("Admin is in read-only mode","bad");return;}
  const prefix={ACTIVATION:"ADX-",WITHDRAWAL:"A_WD_",BRONZE:"BRONZE_",SILVER:"SILVER_",GOLD:"GOLD_",PLATINUM:"PLATINUM_",DIAMOND:"DIAMOND_",MASTER:"MASTER_"}[type];
  const path=type==="ACTIVATION"?"activationKeys":"levelKeys";const qty=Math.max(1,Math.min(100,Number($("keyQty").value)||1)),out=[];
  try{const life=keyLifetime(policy);for(let i=0;i<qty;i++){const key=prefix+random(9),now=Date.now(),expiresAt=now+life;await set(ref(db,`${path}/${key}`),{key,type,status:"ACTIVE",createdAt:now,expiresAt,expiresIn:keyLifetimeLabel(policy),boundDeviceId:null,usedBy:null,usedAt:null,usedNumber:null,username:null,number:null});out.push({key,createdAt:now,expiresAt});}
    $("generated").innerHTML=`<div class="notice success key-issued">✓ ${qty} key${qty===1?"":"s"} generated and added to the Key Ledger.</div>`;await audit("Generated keys",{type,quantity:qty,lifetimeMs:life});await loadKeys();
  }catch(e){$("generated").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}
}
function updateKeyCountdowns(){
  const now=Date.now();
  let active=0,soon=0,expired=0,next=Infinity;
  document.querySelectorAll(".time-left[data-expiry]").forEach(el=>{
    const exp=Number(el.dataset.expiry||0), left=exp-now;
    if(left<=0){expired++;el.textContent="EXPIRED";el.classList.add("expired");return;}
    active++; if(left<=3600000)soon++; if(exp<next)next=exp;
    const total=Math.floor(left/1000),d=Math.floor(total/86400),h=Math.floor(total%86400/3600),m=Math.floor(total%3600/60),s=total%60;
    el.textContent=(d?d+"d ":"")+String(h).padStart(2,"0")+"h "+String(m).padStart(2,"0")+"m "+String(s).padStart(2,"0")+"s";
    el.classList.remove("expired");
  });
  if($("eyesActive")) $("eyesActive").textContent=active;
  if($("eyesSoon")) $("eyesSoon").textContent=soon;
  if($("eyesExpired")) $("eyesExpired").textContent=expired;
  if($("eyesNext")) $("eyesNext").textContent=next===Infinity?"—":(next-now<=3600000?Math.max(0,Math.floor((next-now)/1000))+"s":"in "+fmtDT(next));
}
function startKeyCountdown(){clearInterval(keyCountdownTimer);updateKeyCountdowns();keyCountdownTimer=setInterval(updateKeyCountdowns,1000);}

async function loadKeys(){await ensureAdminSession();
  try{
    const [a,l,u]=await Promise.all([get(ref(db,"activationKeys")),get(ref(db,"levelKeys")),get(ref(db,"users"))]);const users=u.val()||{},rows=[];for(const [id,v] of Object.entries(a.val()||{}))rows.push({id,path:"activationKeys",...v});for(const [id,v] of Object.entries(l.val()||{}))rows.push({id,path:"levelKeys",...v});
    const now=Date.now(),q=($("keySearch")?.value||"").toLowerCase(),f=$("keyFilter")?.value||"ALL";rows.forEach(k=>{k._status=k.status==="ACTIVE"&&Number(k.expiresAt||0)<=now?"EXPIRED":(k.status||"ACTIVE");const usr=users[k.usedBy]||{};k._username=k.username||usr.username||usr.name||"—";k._number=k.number||k.usedNumber||usr.mobile||usr.number||"—"});
    const filtered=rows.filter(k=>(f==="ALL"||k._status===f)&&(!q||[k.key,k._status,k._username,k._number].some(v=>String(v||"").toLowerCase().includes(q)))).sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));
    $("keysList").innerHTML=filtered.slice(0,300).map(k=>`<article class="card key-row key-table"><div><code>${esc(k.key)}</code><small>${esc(k.type||"")}</small></div><div>${esc(fmtDT(k.createdAt))}</div><div><span>${esc(fmtDT(k.expiresAt))}</span><small class="time-left" data-expiry="${Number(k.expiresAt||0)}">${k._status==="ACTIVE"?"calculating…":"—"}</small></div><div><span class="status-pill ${String(k._status).toLowerCase()}">${esc(k._status)}</span></div><div>${esc(k._number)}</div><div>${esc(k._username)}</div><div class="toolbar"><button data-copy="${esc(k.key)}">Copy</button>${k._status==="ACTIVE"?`<button class="secondary" data-revoke="${esc(k.path)}|${esc(k.id)}">Revoke</button>`:""}<button class="danger" data-delete="${esc(k.path)}|${esc(k.id)}">Delete</button></div></article>`).join("")||`<div class="notice">No matching keys.</div>`;
    startKeyCountdown();
    $("keysList").querySelectorAll("[data-copy]").forEach(b=>b.onclick=async()=>{try{await navigator.clipboard.writeText(b.dataset.copy);window.toast("Copied")}catch{window.toast("Copy unavailable","bad")}});
    $("keysList").querySelectorAll("[data-revoke]").forEach(b=>b.onclick=async()=>{const [path,id]=b.dataset.revoke.split("|");setActionBusy(b,true,"Revoking");try{await update(ref(db,`${path}/${id}`),{status:"REVOKED",revokedAt:Date.now()});await audit("Revoked key",{id});window.toast("Key revoked");await loadKeys()}catch(e){window.toast("Revoke failed: "+e.message,"bad")}finally{setActionBusy(b,false)}});
    // Delegated delete handler: reliable for repeated key generation/deletion and does not depend on browser confirm().
    if(!$('keysList').dataset.deleteBound){
      $('keysList').dataset.deleteBound='1';
      $('keysList').addEventListener('click',async ev=>{
        const b=ev.target.closest('[data-delete]');
        if(!b || !$('keysList').contains(b)) return;
        ev.preventDefault(); ev.stopPropagation();
        const raw=b.dataset.delete||''; const cut=raw.indexOf('|');
        if(cut<1) return window.toast('Invalid key reference','bad');
        const path=raw.slice(0,cut), id=raw.slice(cut+1);
        setActionBusy(b,true,'Deleting');
        try{
          await safeRemove(`${path}/${id}`);
          try{await audit('Deleted key',{id,path})}catch{}
          window.toast('Key deleted permanently');
          await loadKeys();
        }catch(e){
          console.error('Key delete failed',e);
          const msg=e?.code==='PERMISSION_DENIED'?'Firebase denied this admin delete.':(e?.code==='NETWORK_ERROR'?'Network error while deleting.':'Key delete failed: '+(e?.code||e?.message||'Unknown error'));
          window.toast(msg,'bad');
        }finally{setActionBusy(b,false)}
      });
    }
  }catch(e){$("keysList").innerHTML=`<div class="notice error">Key load failed: ${esc(e.message)}</div>`}
}
async function cleanExpiredKeys(){try{const [a,l]=await Promise.all([get(ref(db,"activationKeys")),get(ref(db,"levelKeys"))]);let n=0,now=Date.now();for(const [id,v] of Object.entries(a.val()||{}))if(v.status==="ACTIVE"&&Number(v.expiresAt||0)<=now){await safeRemove(`activationKeys/${id}`);n++}for(const [id,v] of Object.entries(l.val()||{}))if(v.status==="ACTIVE"&&Number(v.expiresAt||0)<=now){await safeRemove(`levelKeys/${id}`);n++}await audit("Cleaned expired keys",{count:n});window.toast(`${n} expired key(s) removed`);await loadKeys()}catch(e){window.toast("Clean expired failed: "+e.message,"bad")}}

function openWithdrawals(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">PAYOUT CONTROL</span><h2>Withdrawals</h2><p class="muted">Review genuine withdrawal requests and keep an auditable decision trail.</p></div><button class="secondary" id="refreshWd">↻ Refresh</button></div><div id="wdList">Loading…</div>`;
  $("refreshWd").onclick=()=>withRefresh($("refreshWd"),loadWithdrawalsOnce); loadWithdrawalsOnce();
}
async function loadWithdrawalsOnce(){await ensureAdminSession();
 try{const s=await get(ref(db,"withdrawals"));const entries=Object.entries(s.val()||{}).reverse();$("wdList").innerHTML=entries.length?entries.map(([id,w])=>`<article class="card key-row"><div><b>${money(w.amount)}</b><div class="muted">${esc(w.method||"")} · ${esc(w.status||"PENDING")}</div></div><div class="toolbar">${w.status==="PENDING"?`<button data-wd="${id}|APPROVED">Approve</button><button class="danger" data-wd="${id}|REJECTED">Reject</button>`:""}</div></article>`).join(""):"<div class='notice'>No withdrawal requests.</div>";$("wdList").querySelectorAll("[data-wd]").forEach(b=>b.onclick=async()=>{const [id,status]=b.dataset.wd.split("|");const settingsSnap=await get(ref(db,"settings"));const st=settingsSnap.val()||{};if(st.freezeWithdrawals===true){window.toast("Withdrawal approvals are currently frozen in Settings","bad");return;}if(status==="APPROVED"&&Number(st.dailyWithdrawalLimitPerUser)>0){const requester=w.uid||w.userId||w.user?.uid||w.username||null;if(requester){const start=new Date();start.setHours(0,0,0,0);const today=Object.values((await get(ref(db,"withdrawals"))).val()||{}).filter(x=>(x.uid||x.userId||x.user?.uid||x.username)===requester&&Number(x.createdAt||x.requestedAt||0)>=start.getTime()&&String(x.status||"").toUpperCase()==="APPROVED").reduce((sum,x)=>sum+Number(x.amount||0),0);if(today+Number(w.amount||0)>Number(st.dailyWithdrawalLimitPerUser)){window.toast(`Daily withdrawal limit ₹${st.dailyWithdrawalLimitPerUser} would be exceeded for this user`,"bad");return;}}}try{await update(ref(db,`withdrawals/${id}`),{status,reviewedAt:Date.now()});await audit(`${status} withdrawal`,{id});window.toast(status);loadWithdrawalsOnce()}catch(e){window.toast("Action failed: "+e.message,"bad")}})}catch(e){$("wdList").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}
}

function openSupport(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">PRIVATE INBOX</span><h2>Support Center</h2><p class="muted">Active chats can be removed from the inbox. A permanent archive remains available to admin.</p></div><div class="toolbar"><button class="secondary" id="refreshSupport">↻ Refresh</button><button class="secondary" id="showSupportArchive">Permanent Archive</button></div></div><div id="supportList">Loading…</div><div id="supportArchive" class="hidden"></div>`;
  const render=(data)=>{
    const cards=Object.entries(data||{}).reverse();
    $("supportList").innerHTML=cards.length?cards.map(([uid,msgs])=>`<article class="card support-card"><div class="row"><div><b>Conversation</b><div class="muted mono">${esc(uid)}</div></div><button class="danger tiny" data-delete-support="${esc(uid)}">Delete Inbox</button></div>${Object.entries(msgs||{}).map(([mid,m])=>`<div class="chat ${m.from==="admin"?"mine":""}"><span>${esc(m.text||"")}</span><small>${m.createdAt?new Date(m.createdAt).toLocaleString():""}</small></div>`).join("")}<div class="reply-row"><input data-reply="${esc(uid)}" placeholder="Reply privately"><button data-send="${esc(uid)}">Send</button></div></article>`).join(""):"<div class='notice'>No active support messages.</div>";
    $("supportList").querySelectorAll("[data-send]").forEach(b=>b.onclick=async()=>{
      const uid=b.dataset.send,input=document.querySelector(`[data-reply="${CSS.escape(uid)}"]`),text=input?.value.trim();if(!text)return;
      setActionBusy(b,true,"Sending");try{const msgRef=push(ref(db,`support/${uid}`));const payload={from:"admin",text,createdAt:Date.now(),messageId:msgRef.key};await set(ref(db,`support/${uid}/${msgRef.key}`),payload);try{await set(ref(db,`supportArchive/${uid}/${msgRef.key}`),{...payload,archivedAt:Date.now(),archivedBy:ADMIN});}catch(archiveErr){window.toast("Message sent • Archive needs its Firebase rule","ok")}await audit("Replied to support",{uid,messageId:msgRef.key});input.value="";window.toast("Reply sent");loadSupportOnce()}catch(e){window.toast("Reply failed: "+(e?.code||e?.message||"Unknown error")+" — publish V23 Firebase Rules","bad")}finally{setActionBusy(b,false)}
    });
    $("supportList").querySelectorAll("[data-delete-support]").forEach(b=>b.onclick=async()=>{
      const uid=b.dataset.deleteSupport;if(!confirm("Remove this conversation from the active inbox? The permanent archive will remain."))return;
      setActionBusy(b,true,"Deleting");try{await safeRemove(`support/${uid}`);try{await audit("Deleted support inbox conversation",{uid})}catch{}window.toast("Conversation deleted from active inbox");await loadSupportOnce()}catch(e){window.toast(e?.code==="PERMISSION_DENIED"?"Delete denied by Firebase Rules. Verify the published admin UID.":"Delete failed: "+(e?.code||e?.message||"Unknown error"),"bad")}finally{setActionBusy(b,false)}});
  };
  const renderArchive=(data)=>{
    const cards=Object.entries(data||{}).reverse();
    $("supportArchive").innerHTML=`<div class="card archive-card"><div class="section-head"><div><span class="eyebrow">IMMUTABLE HISTORY</span><h3>Permanent Support Archive</h3><p class="muted">Archived support messages are retained for admin records and are not removed when an active inbox conversation is deleted.</p></div><button class="secondary" id="hideSupportArchive">Hide</button></div>${cards.length?cards.map(([uid,msgs])=>`<div class="archive-thread"><div class="row"><b>User ${esc(uid)}</b><span class="pill">PERMANENT</span></div>${Object.values(msgs||{}).map(m=>`<div class="chat ${m.from==="admin"?"mine":""}"><span>${esc(m.text||"")}</span><small>${m.createdAt?new Date(m.createdAt).toLocaleString():""}</small></div>`).join("")}</div>`).join(""):"<div class='notice'>No archived support messages.</div>"}</div>`;
    $("hideSupportArchive").onclick=()=>$("supportArchive").classList.add("hidden");
  };
  window.loadSupportOnce=async()=>{
    let activeVal=null,archiveVal=null;
    try{ const active=await get(ref(db,"support")); activeVal=active.val(); render(activeVal); }
    catch(e){ $("supportList").innerHTML=`<div class="notice error">Support load failed: ${esc(e.message)}<br><small>Firebase Rules must allow the authorised admin UID to read/write <b>support</b>.</small></div>`; return; }
    try{ const archive=await get(ref(db,"supportArchive")); archiveVal=archive.val(); renderArchive(archiveVal); }
    catch(e){ $("supportArchive").innerHTML=`<div class="card archive-card"><div class="notice error">Archive load failed: ${esc(e.message)}<br><small>Publish the V23 Firebase Rules to enable the permanent admin archive.</small></div></div>`; }
  };
  $("refreshSupport").onclick=()=>withRefresh($("refreshSupport"),loadSupportOnce);
  $("showSupportArchive").onclick=()=>$("supportArchive").classList.remove("hidden");
  loadSupportOnce();
}

function openNotifications(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">BROADCAST</span><h2>Notifications</h2></div></div><div class="card form-card"><input id="nt" placeholder="Title"><textarea id="nb" placeholder="Message"></textarea><button id="sendN">Send to all users</button><div id="nm" class="msg"></div></div>`;
  $("sendN").onclick=async()=>{const title=$("nt").value.trim(),body=$("nb").value.trim();if(!title||!body)return $("nm").textContent="Title and message are required.";try{await push(ref(db,"notifications/all"),{title,body,createdAt:Date.now()});await audit("Sent broadcast notification");$("nm").className="msg success";$("nm").textContent="Notification sent."}catch(e){$("nm").className="msg error";$("nm").textContent=e.message}};
}

function applyAppearanceSettings(v={}){
  const root=document.documentElement;
  const themes={emerald:['#52f2a3','#8c78ff'],violet:['#b89cff','#6f62ff'],ice:['#8fe8ff','#718cff'],amber:['#ffd58a','#b88a5a']};
  const pair=themes[v.accentTheme||'emerald']||themes.emerald;
  root.style.setProperty('--accent',pair[0]);root.style.setProperty('--accent2',pair[1]);
  const blur={soft:12,balanced:20,rich:28}[v.glassIntensity||'balanced']||20;
  root.style.setProperty('--glass-blur',blur+'px');
  const fonts={cinzel:"Cinzel",playfair:"Playfair Display",cormorant:"Cormorant Garamond",dmserif:"DM Serif Display",libre:"Libre Baskerville",lora:"Lora",merriweather:"Merriweather",montserrat:"Montserrat",poppins:"Poppins",manrope:"Manrope",space:"Space Grotesk",outfit:"Outfit",sora:"Sora",jakarta:"Plus Jakarta Sans",raleway:"Raleway",josefin:"Josefin Sans",bebas:"Bebas Neue",rubik:"Rubik"};
  root.style.setProperty('--font-all',`"${fonts[v.fontFamily||'manrope']||fonts.manrope}",system-ui,sans-serif`);
  root.dataset.motion=v.motionMode||'full';root.dataset.density=v.dashDensity||'comfortable';
  root.dataset.liveBadges=v.liveBadges===false?'off':'on';
  root.dataset.glass=v.glassIntensity||'balanced';
}

function openSettings(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">GLOBAL CONFIG</span><h2>Settings</h2><p class="muted">A premium command layer for app limits, presentation, performance, notifications and admin safety.</p></div><button class="secondary" id="refreshSettings">↻ Refresh</button></div>
  <div class="settings-grid">
   <div class="card form-card feature-card"><div class="setting-section"><h3>💳 Withdrawal</h3><p class="setting-hint">Configure the genuine withdrawal threshold and the methods shown to users.</p><label>Minimum withdrawal<input id="min" type="number" step="1" value="899"></label><label>Withdrawal method label<input id="wdLabel" placeholder="UPI + Bank"></label></div>
   <div class="setting-section"><h3>📣 Communication</h3><p class="setting-hint">Control support destination and the message shown across the user app.</p><label>Telegram destination<input id="tg" placeholder="Admin-configured Telegram destination"></label><label>Support email<input id="supportEmail"></label><label>Announcement<input id="announcement"></label></div>
   <div class="setting-section"><h3>⚙️ App state</h3><p class="setting-hint">Operational controls. Maintenance mode should only be used when needed.</p><label>Maintenance<select id="mm"><option value="false">OFF</option><option value="true">ON</option></select></label><label>Maintenance message<input id="maintenanceMessage" placeholder="We'll be back shortly."></label><label>App announcement enabled<select id="announceOn"><option value="true">ON</option><option value="false">OFF</option></select></label></div>
   <div class="setting-section"><h3>🔑 Key policy</h3><p class="setting-hint">Keep key issuance predictable and auditable.</p><label>Key expiry value<input id="keyLife" type="number" min="1" max="168" value="24"></label><label>Key expiry unit<select id="keyUnit"><option value="seconds">Seconds</option><option value="minutes">Minutes</option><option value="hours" selected>Hours</option></select></label><label>One-time redemption<select id="oneTime"><option value="true">ENFORCED</option><option value="false">OFF</option></select></label><label>Default user level<select id="defaultLevel">${[0,1,2,3,4,5].map(n=>`<option value="${n}">Level ${n}</option>`).join("")}</select></label><label>Max keys per generation<input id="maxKeys" type="number" min="1" max="100" value="25"></label></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>✨ Luxury Appearance</h3><p class="setting-hint">These preferences are stored in Firebase so the admin UI can keep the same presentation after reload.</p><label>Accent theme<select id="accentTheme"><option value="emerald">Emerald Glass</option><option value="violet">Royal Violet</option><option value="ice">Ice Blue</option><option value="amber">Champagne Amber</option></select></label><label>Global UI font<select id="fontFamily">${[{v:"cinzel",n:"Cinzel — Luxury"},{v:"playfair",n:"Playfair Display"},{v:"cormorant",n:"Cormorant Garamond"},{v:"dmserif",n:"DM Serif Display"},{v:"libre",n:"Libre Baskerville"},{v:"lora",n:"Lora"},{v:"merriweather",n:"Merriweather"},{v:"montserrat",n:"Montserrat"},{v:"poppins",n:"Poppins"},{v:"manrope",n:"Manrope"},{v:"space",n:"Space Grotesk"},{v:"outfit",n:"Outfit"},{v:"sora",n:"Sora"},{v:"jakarta",n:"Plus Jakarta Sans"},{v:"raleway",n:"Raleway"},{v:"josefin",n:"Josefin Sans"},{v:"bebas",n:"Bebas Neue"},{v:"rubik",n:"Rubik"}].map(x=>`<option value="${x.v}">${x.n}</option>`).join("")}</select><small class="field-help">Applies across the complete admin UI.</small></label><label>Glass intensity<select id="glassIntensity"><option value="soft">Soft</option><option value="balanced" selected>Balanced</option><option value="rich">Rich</option></select></label><label>Dashboard density<select id="dashDensity"><option value="comfortable" selected>Comfortable</option><option value="compact">Compact</option></select></label><label>Motion<select id="motionMode"><option value="full" selected>Full luxury</option><option value="reduced">Reduced</option></select></label></div></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>⚡ Performance & Behaviour</h3><p class="setting-hint">Tune background refresh and safety prompts without changing Firebase data.</p><label>Auto-refresh interval<select id="autoRefresh"><option value="0">OFF</option><option value="15">15 seconds</option><option value="30" selected>30 seconds</option><option value="60">60 seconds</option></select></label><label>Default landing page<select id="landingPage"><option value="dashboard">Dashboard</option><option value="users">Users</option><option value="keys">Keys</option><option value="withdrawals">Withdrawals</option><option value="settings">Settings</option></select></label><label>Destructive-action confirmation<select id="confirmDanger"><option value="true" selected>ON</option><option value="false">OFF</option></select></label><label>Live dashboard badges<select id="liveBadges"><option value="true" selected>ON</option><option value="false">OFF</option></select></label></div></div>
   <div class="card form-card feature-card"><div class="setting-section"><h3>🛡️ Admin Safety</h3><p class="setting-hint">Local-session controls and export tools. These do not weaken Firebase authentication.</p><div class="settings-toggle-row"><div class="settings-badge">● ADMIN UID LOCKED</div><div class="settings-badge">● AUDIT READY</div></div><label>Session reminder<select id="sessionReminder"><option value="15">15 minutes</option><option value="30" selected>30 minutes</option><option value="60">60 minutes</option></select></label><label>Audit detail<select id="auditDetail"><option value="standard" selected>Standard</option><option value="verbose">Verbose</option><option value="critical">Critical only</option></select></label><label>Show sensitive admin hints<select id="sensitiveHints"><option value="true">ON</option><option value="false">OFF</option></select></label><div class="settings-actions"><button class="secondary" id="resetUiState">Reset local UI</button><button class="secondary" id="exportSettings">Export config</button></div></div></div>
   <div class="card form-card feature-card command-card"><div class="setting-section"><h3>🎛️ Global Feature Control</h3><p class="setting-hint">Master switches for user-facing modules. Turning a switch off should be treated as an operational policy, not a data edit.</p><div class="control-grid"><label class="switch-line"><span>Registration</span><select id="registrationEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Sell Data</span><select id="sellDataEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Withdrawals</span><select id="withdrawalsEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Support Chat</span><select id="supportEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Notifications</span><select id="notificationsEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label><label class="switch-line"><span>Level Upgrades</span><select id="upgradesEnabled"><option value="true">ENABLED</option><option value="false">PAUSED</option></select></label></div></div></div>
   <div class="card form-card feature-card command-card"><div class="setting-section"><h3>👑 Emergency Command Deck</h3><p class="setting-hint">High-impact operational switches for legitimate administration. These are logged and reversible.</p><div class="control-grid"><label class="switch-line"><span>Freeze key issuance</span><select id="freezeKeyIssuance"><option value="false">OFF</option><option value="true">FROZEN</option></select></label><label class="switch-line"><span>Freeze withdrawal approvals</span><select id="freezeWithdrawals"><option value="false">OFF</option><option value="true">FROZEN</option></select></label><label class="switch-line"><span>Admin read-only mode</span><select id="adminReadOnly"><option value="false">OFF</option><option value="true">READ ONLY</option></select></label><label class="switch-line"><span>Auto-expire sweep</span><select id="autoExpireSweep"><option value="false">OFF</option><option value="true">ON</option></select></label><label class="switch-line"><span>Strict action audit</span><select id="strictActionAudit"><option value="true">ON</option><option value="false">OFF</option></select></label><label class="switch-line"><span>Require action note</span><select id="requireActionNote"><option value="false">OFF</option><option value="true">ON</option></select></label></div></div></div>
   <div class="card form-card feature-card financial-settings-card"><div class="setting-section"><h3>💎 Control Center · Financial Telemetry</h3><p class="setting-hint">Dedicated controls for the live financial cards. Values are calculated from genuine Firebase records; this panel does not create or edit balances.</p><label>Total Balance card<select id="showTotalBalance"><option value="true">SHOW</option><option value="false">HIDE</option></select></label><label>Pending Withdrawal Balance card<select id="showPendingWithdrawalBalance"><option value="true">SHOW</option><option value="false">HIDE</option></select></label><label>Control Center refresh<select id="controlCenterRefresh"><option value="5">5 seconds</option><option value="10" selected>10 seconds</option><option value="15">15 seconds</option><option value="30">30 seconds</option><option value="60">60 seconds</option></select></label><div class="financial-source-note"><span>✓</span><div><strong>Calculation source locked</strong><small>Total Balance = Σ users/*/balance<br>Pending Withdrawal Balance = Σ pending withdrawals.amount<br>Pending withdrawal amounts are kept separate to avoid double-counting.</small></div></div></div></div>
   <div class="card form-card feature-card command-card"><div class="setting-section"><h3>🧠 Governance & Limits</h3><p class="setting-hint">Central policy values for future client/backend enforcement. Keep them transparent and auditable.</p><label>Daily withdrawal limit per user (₹)<input id="dailyWithdrawalLimit" type="number" min="0" step="1" value="0"><small class="field-help">0 = unlimited. Approval checks the user's withdrawals for the current calendar day.</small></label><label>Daily data activity cap (MB)<input id="dailyDataCap" type="number" min="0" step="1" value="0"></label><label>Max pending withdrawals per user<input id="maxPendingWithdrawals" type="number" min="1" max="20" value="1"></label><label>Transaction correction window (hours)<input id="correctionWindow" type="number" min="0" max="720" value="24"></label><label>Privacy mode<select id="privacyMode"><option value="standard" selected>Standard</option><option value="strict">Strict</option></select></label></div></div>
  </div>
  <div class="card form-card"><h3>💎 Level rates (₹ / MB)</h3>${["Bronze","Silver","Gold","Platinum","Diamond","Master"].map((n,i)=>`<label>${n}<input id="rate${i}" type="number" step="0.001"></label>`).join("")}<div class="settings-actions"><button id="saveSettings">Save all settings</button><button class="secondary" id="resetSettings">Reset defaults</button></div><div id="sm" class="msg"></div></div>`;
  async function fill(){
    await ensureAdminSession();
    const s=await get(ref(db,"settings"));const v=s.val()||{};
    $('min').value=v.minWithdrawal??899;$('wdLabel').value=v.withdrawalMethodLabel||"UPI + Bank";$('tg').value=v.telegramDestination||"";$('mm').value=String(!!v.maintenanceMode);$('supportEmail').value=v.supportEmail||"";$('announcement').value=v.announcement||"";$('maintenanceMessage').value=v.maintenanceMessage||"We'll be back shortly.";$('announceOn').value=String(v.announcementEnabled!==false);
    $('keyLife').value=v.keyLifetimeValue??v.keyLifetimeHours??24;$('keyUnit').value=v.keyLifetimeUnit||'hours';$('oneTime').value=String(v.oneTimeRedemption!==false);$('defaultLevel').value=String(v.defaultUserLevel??0);$('maxKeys').value=v.maxKeysPerGeneration??25;
    const defaults=[.005,.015,.04,.08,.15,.30],r=v.rates||{};["Bronze","Silver","Gold","Platinum","Diamond","Master"].forEach((n,i)=>$('rate'+i).value=r[n]??defaults[i]);
    $('accentTheme').value=v.accentTheme||'emerald';$('fontFamily').value=v.fontFamily||'manrope';$('glassIntensity').value=v.glassIntensity||'balanced';$('dashDensity').value=v.dashDensity||'comfortable';$('motionMode').value=v.motionMode||'full';$('autoRefresh').value=String(v.autoRefreshSeconds??30);$('landingPage').value=v.landingPage||'dashboard';$('confirmDanger').value=String(v.confirmDanger!==false);$('liveBadges').value=String(v.liveBadges!==false);$('sessionReminder').value=String(v.sessionReminderMinutes??30);$('auditDetail').value=v.auditDetail||'standard';$('sensitiveHints').value=String(v.sensitiveHints!==false);$('registrationEnabled').value=String(v.registrationEnabled!==false);$('sellDataEnabled').value=String(v.sellDataEnabled!==false);$('withdrawalsEnabled').value=String(v.withdrawalsEnabled!==false);$('supportEnabled').value=String(v.supportEnabled!==false);$('notificationsEnabled').value=String(v.notificationsEnabled!==false);$('upgradesEnabled').value=String(v.upgradesEnabled!==false);$('showTotalBalance').value=String(v.showTotalBalance!==false);$('showPendingWithdrawalBalance').value=String(v.showPendingWithdrawalBalance!==false);$('controlCenterRefresh').value=String(v.controlCenterRefreshSeconds??10);$('dailyWithdrawalLimit').value=v.dailyWithdrawalLimitPerUser??0;$('dailyDataCap').value=v.dailyDataCapMB??0;$('maxPendingWithdrawals').value=v.maxPendingWithdrawalsPerUser??1;$('correctionWindow').value=v.transactionCorrectionWindowHours??24;$('privacyMode').value=v.privacyMode||'standard';$('freezeKeyIssuance').value=String(v.freezeKeyIssuance===true);$('freezeWithdrawals').value=String(v.freezeWithdrawals===true);$('adminReadOnly').value=String(v.adminReadOnly===true);$('autoExpireSweep').value=String(v.autoExpireSweep===true);$('strictActionAudit').value=String(v.strictActionAudit!==false);$('requireActionNote').value=String(v.requireActionNote===true);
    applyAppearanceSettings(v);
  }
  fill();$('refreshSettings').onclick=()=>withRefresh($('refreshSettings'),fill);
  const syncKeyLifeLimit=()=>{$('keyLife').max=$('keyUnit').value==='seconds'?86400:($('keyUnit').value==='minutes'?1440:168);if(Number($('keyLife').value)>Number($('keyLife').max))$('keyLife').value=$('keyLife').max;};$('keyUnit').addEventListener('change',syncKeyLifeLimit);syncKeyLifeLimit();
  ['accentTheme','fontFamily','glassIntensity','dashDensity','motionMode','liveBadges'].forEach(id=>$(id)?.addEventListener('change',()=>{applyAppearanceSettings({accentTheme:$('accentTheme').value,fontFamily:$('fontFamily').value,glassIntensity:$('glassIntensity').value,dashDensity:$('dashDensity').value,motionMode:$('motionMode').value,liveBadges:$('liveBadges').value==='true'})}));
  $('saveSettings').onclick=async()=>{
    const names=["Bronze","Silver","Gold","Platinum","Diamond","Master"],rates={};names.forEach((n,i)=>rates[n]=Number($('rate'+i).value)||0);
    const payload={minWithdrawal:Number($('min').value)||899,withdrawalMethodLabel:$('wdLabel').value.trim(),telegramDestination:$('tg').value.trim(),maintenanceMode:$('mm').value==='true',supportEmail:$('supportEmail').value.trim(),announcement:$('announcement').value.trim(),maintenanceMessage:$('maintenanceMessage').value.trim(),announcementEnabled:$('announceOn').value==='true',keyLifetimeValue:Math.max(1,Math.min($('keyUnit').value==='seconds'?86400:($('keyUnit').value==='minutes'?1440:168),Number($('keyLife').value)||24)),keyLifetimeUnit:$('keyUnit').value,keyLifetimeHours:$('keyUnit').value==='hours'?Math.max(1,Math.min(168,Number($('keyLife').value)||24)):1,oneTimeRedemption:$('oneTime').value==='true',defaultUserLevel:Math.max(0,Math.min(5,Number($('defaultLevel').value)||0)),maxKeysPerGeneration:Math.max(1,Math.min(100,Number($('maxKeys').value)||25)),rates,
      accentTheme:$('accentTheme').value,fontFamily:$('fontFamily').value,glassIntensity:$('glassIntensity').value,dashDensity:$('dashDensity').value,motionMode:$('motionMode').value,autoRefreshSeconds:Number($('autoRefresh').value)||0,landingPage:$('landingPage').value,confirmDanger:$('confirmDanger').value==='true',liveBadges:$('liveBadges').value==='true',sessionReminderMinutes:Number($('sessionReminder').value)||30,auditDetail:$('auditDetail').value,sensitiveHints:$('sensitiveHints').value==='true',registrationEnabled:$('registrationEnabled').value==='true',sellDataEnabled:$('sellDataEnabled').value==='true',withdrawalsEnabled:$('withdrawalsEnabled').value==='true',supportEnabled:$('supportEnabled').value==='true',notificationsEnabled:$('notificationsEnabled').value==='true',upgradesEnabled:$('upgradesEnabled').value==='true',dailyWithdrawalLimitPerUser:Math.max(0,Number($('dailyWithdrawalLimit').value)||0),dailyDataCapMB:Math.max(0,Number($('dailyDataCap').value)||0),maxPendingWithdrawalsPerUser:Math.max(1,Math.min(20,Number($('maxPendingWithdrawals').value)||1)),transactionCorrectionWindowHours:Math.max(0,Math.min(720,Number($('correctionWindow').value)||24)),privacyMode:$('privacyMode').value,freezeKeyIssuance:$('freezeKeyIssuance').value==='true',freezeWithdrawals:$('freezeWithdrawals').value==='true',adminReadOnly:$('adminReadOnly').value==='true',autoExpireSweep:$('autoExpireSweep').value==='true',strictActionAudit:$('strictActionAudit').value==='true',requireActionNote:$('requireActionNote').value==='true',showTotalBalance:$('showTotalBalance').value==='true',showPendingWithdrawalBalance:$('showPendingWithdrawalBalance').value==='true',controlCenterRefreshSeconds:Math.max(5,Math.min(60,Number($('controlCenterRefresh').value)||10)),updatedAt:Date.now()};
    try{await update(ref(db,"settings"),payload);applyAppearanceSettings(payload);await audit("Updated app settings",{sections:"global,appearance,performance,safety"});$('sm').className='msg success';$('sm').textContent='✓ All settings saved successfully.'}catch(e){$('sm').className='msg error';$('sm').textContent='Save failed: '+e.message}
  };
  $('resetSettings').onclick=async()=>{if(!confirm('Reset settings to safe defaults?'))return;const defaults={minWithdrawal:899,withdrawalMethodLabel:'UPI + Bank',telegramDestination:'',maintenanceMode:false,supportEmail:'',announcement:'',maintenanceMessage:"We'll be back shortly.",announcementEnabled:true,keyLifetimeValue:24,keyLifetimeUnit:'hours',keyLifetimeHours:24,oneTimeRedemption:true,defaultUserLevel:0,maxKeysPerGeneration:25,rates:{Bronze:.005,Silver:.015,Gold:.04,Platinum:.08,Diamond:.15,Master:.30},accentTheme:'emerald',glassIntensity:'balanced',dashDensity:'comfortable',motionMode:'full',autoRefreshSeconds:30,landingPage:'dashboard',confirmDanger:true,liveBadges:true,sessionReminderMinutes:30,auditDetail:'standard',sensitiveHints:true,registrationEnabled:true,sellDataEnabled:true,withdrawalsEnabled:true,supportEnabled:true,notificationsEnabled:true,upgradesEnabled:true,dailyWithdrawalLimitPerUser:0,dailyDataCapMB:0,maxPendingWithdrawalsPerUser:1,transactionCorrectionWindowHours:24,privacyMode:'standard',freezeKeyIssuance:false,freezeWithdrawals:false,adminReadOnly:false,autoExpireSweep:false,strictActionAudit:true,requireActionNote:false,showTotalBalance:true,showPendingWithdrawalBalance:true,controlCenterRefreshSeconds:10,updatedAt:Date.now()};try{await update(ref(db,'settings'),defaults);await audit('Reset app settings to defaults');await fill();$('sm').className='msg success';$('sm').textContent='✓ Defaults restored.'}catch(e){$('sm').className='msg error';$('sm').textContent='Reset failed: '+e.message}};
  $('exportSettings').onclick=async()=>{try{const s=await get(ref(db,'settings'));const blob=new Blob([JSON.stringify(s.val()||{},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='ADI_X_DATA_settings.json';a.click();URL.revokeObjectURL(url);window.toast('Config exported')}catch(e){window.toast('Export failed: '+e.message,'bad')}};
  $('resetUiState').onclick=()=>{try{sessionStorage.clear();localStorage.removeItem('adi_x_data_ui');window.toast('Local UI state reset')}catch(e){window.toast('Nothing to reset','bad')}};
}

function openSecurity(el){
  el.innerHTML=`<div class="security-back-wrap"><button type="button" class="secondary section-back" id="securityBack"><span>←</span> Dashboard</button></div><div class="section-head"><div><span class="eyebrow">ADVANCED COMMAND</span><h2>Security Center</h2><p class="muted">Admin-only diagnostics for Firebase access and local session state.</p></div></div>
  <div class="security-command-strip"><span class="lux-command-badge">● ADMIN VERIFIED</span><span class="lux-command-badge">● RTDB PRIVATE</span><span class="lux-command-badge">● DESTRUCTIVE ACTIONS PROTECTED</span></div><div class="settings-grid">
   <div id="securityDiagnostics"></div>
   <div class="card form-card"><h3>🛡️ Access</h3><div class="notice success">Admin UID verified by the authenticated session.</div><div class="mono">Expected admin: ${esc(ADMIN)}<br>Signed-in UID: ${esc(auth.currentUser?.uid||"—")}</div></div>
   <div class="card form-card"><h3>⚡ Database Health</h3><div id="healthResult" class="notice">Running safe read test…</div><button id="healthTest">Run test again</button></div>
   <div class="card form-card"><h3>🧹 Session Tools</h3><p class="muted">Clear only this browser's temporary UI state. Firebase records are not changed.</p><button class="secondary" id="clearUi">Reset local UI state</button></div>
  </div>`;
  $("securityBack").onclick=async()=>{if($('securityBack').dataset.busy==='1')return;$('securityBack').dataset.busy='1';activeSection=false;dashboardRenderToken++;await exitFullSection();await loadDashboard()};
  async function test(){const box=$("healthResult");box.textContent="Testing…";try{await get(ref(db,"settings"));box.className="notice success";box.textContent="✓ Firebase read access is working."}catch(e){box.className="notice error";box.textContent="Firebase test failed: "+e.message}}
  showSecurityDiagnostics();$("healthTest").onclick=test;$("clearUi").onclick=()=>{try{sessionStorage.clear();localStorage.removeItem("adi_x_data_ui");window.toast("Local UI state reset")}catch(e){window.toast("Nothing to reset","bad")}};test();
}

function openAudit(el){
  el.innerHTML=`<div class="section-head"><div><span class="eyebrow">SECURITY TRAIL</span><h2>Audit Log</h2><p class="muted">Review admin activity. Logs can be removed only after confirmation.</p></div><div class="toolbar"><button class="secondary" id="refreshAudit">↻ Refresh</button><button class="danger" id="deleteAudit">Delete Logs</button></div></div><div id="auditList">Loading…</div>`;
  $("refreshAudit").onclick=()=>withRefresh($("refreshAudit"),loadAuditOnce);$("deleteAudit").onclick=deleteAllAudit;loadAuditOnce();
}
async function loadAuditOnce(){await ensureAdminSession();try{const s=await get(ref(db,"auditLogs"));const rows=Object.entries(s.val()||{}).reverse();$("auditList").innerHTML=rows.slice(0,300).map(([id,a])=>`<article class="row audit-row"><span>${esc(a.action||"Action")}</span><span class="muted">${a.at?new Date(a.at).toLocaleString():""}</span><button class="danger tiny" data-audit-delete="${esc(id)}">×</button></article>`).join("")||"<div class='notice'>No entries.</div>";$("auditList").querySelectorAll('[data-audit-delete]').forEach(b=>b.onclick=async()=>{if(!confirm('Delete this audit entry permanently?'))return;try{await safeRemove(`auditLogs/${b.dataset.auditDelete}`);window.toast('Audit entry deleted permanently');await loadAuditOnce()}catch(e){window.toast('Delete failed: '+e.message,'bad')}})}catch(e){$("auditList").innerHTML=`<div class="notice error">${esc(e.message)}</div>`}}
async function deleteAllAudit(){if(!confirm('Delete ALL audit logs permanently? This cannot be undone.'))return;try{await safeRemove('auditLogs');window.toast('All audit logs deleted permanently');await loadAuditOnce()}catch(e){window.toast(e?.code==='PERMISSION_DENIED'?'Delete blocked by deployed Firebase Rules.':'Delete failed: '+e.message,'bad')}}

window.addEventListener("unhandledrejection",e=>{console.error(e.reason);window.toast(e?.reason?.code||"Something went wrong. Please try again.","bad")});
