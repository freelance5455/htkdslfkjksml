ADI X DATA V43 — BOOT/STARTUP FIXED

Based on V41 ERROR FIXED. Preserves V41 dashboard, live telemetry, navigation,
GOD EYES, Luxury Appearance, Governance & Limits, security and Firebase logic.

Fix:
- Removed the broken bootWatch function call that executed before the DOM helper `$` was initialized.
- Removed the old startup warning overlay/script entirely.
- Firebase initialization can no longer fail because of the boot-warning cleanup code.
- Existing `active` dashboard count fix is preserved.
- No Firebase Rules changes are required for this frontend fix.
