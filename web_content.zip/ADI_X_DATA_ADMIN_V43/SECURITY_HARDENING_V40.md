# ADI X DATA V40 — Security Model

V40 keeps the Firebase client configuration in the frontend because Firebase web configuration is not a secret. No Firebase service-account private key, private signing key, or backend credential is shipped in this package.

## Protected boundaries
- Firebase Authentication is required before admin operations.
- The authenticated UID is checked against the authorised admin UID in the client UI.
- Sensitive operations should also be enforced by Firebase Rules / trusted backend code; client checks are not a security boundary by themselves.
- Key expiry is represented by an expiry timestamp and must be re-checked server-side when keys are redeemed.
- Withdrawal approval limits must be enforced in trusted backend/transaction logic for production financial integrity.
- Audit records should be append-only or protected by server-side authorization; client-side audit logging is not tamper-proof.

## What this package does not claim
No browser/HTML/JavaScript package can honestly guarantee that a determined professional cannot inspect or reverse engineer it. Frontend code must be treated as public. Secrets belong on a trusted backend or managed secret/KMS service.

## Production hardening
1. Publish restrictive Realtime Database Rules using the authorised admin UID / custom claims.
2. Enable Firebase App Check for supported clients.
3. Move high-impact writes (key issuance/redeem, withdrawal approval, balance changes, corrections) into trusted Cloud Functions or another authenticated backend.
4. Never ship service-account JSON or private keys in the APK, ZIP, browser bundle, or repository.
5. Rotate credentials if a secret is ever exposed.
6. Keep audit logs protected from ordinary client writes and deletions.
