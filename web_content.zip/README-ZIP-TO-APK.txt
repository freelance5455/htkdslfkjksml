MR,KHORASANI 2.8.4 - ZIP TO APK PACKAGE

1. Import the complete ZIP into your ZIP-to-APK builder.
2. Set the start page / entry file to index.html at the archive root.
3. Keep all files in the archive root; do not rename JavaScript or image files.
4. This is a web bundle for a WebView wrapper, not a signed APK.
5. If the builder remains at Build, check its own build log and Android SDK/Gradle availability.
