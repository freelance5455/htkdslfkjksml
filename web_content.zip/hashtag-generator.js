
import { createAHMADAiChat } from "./ai.js";

// عناصر مولّد الهاشتاغات
const topicInput = document.getElementById("hashtagTopic");
const platformSelect = document.getElementById("hashtagPlatform");
const countSelect = document.getElementById("hashtagCount");

const generateBtn = document.getElementById("generateHashtagsBtn");
const statusBox = document.getElementById("hashtagStatus");
const resultBox = document.getElementById("hashtagResult");
const outputBox = document.getElementById("hashtagOutput");
const copyBtn = document.getElementById("copyHashtagsBtn");

// إنشاء الهاشتاغات
generateBtn?.addEventListener("click", async () => {
  const topic = topicInput?.value.trim();
  const platform = platformSelect?.value;
  const count = Number(countSelect?.value);

  if (!topic) {
    statusBox.hidden = false;
    statusBox.textContent = "يرجى كتابة موضوع المحتوى أولاً.";
    return;
  }

  if (!platform || ![10, 20, 30].includes(count)) {
    statusBox.hidden = false;
    statusBox.textContent = "يرجى التأكد من اختيار المنصة والعدد.";
    return;
  }

  generateBtn.disabled = true;
  generateBtn.textContent = "⏳ جارٍ إنشاء الهاشتاغات...";

  statusBox.hidden = false;
  statusBox.textContent = "يعمل الذكاء الاصطناعي على اقتراح الهاشتاغات...";
  resultBox.hidden = true;

  try {
    const hashtagChat = createAHMADAiChat();

    const prompt = `
أنت خبير متخصص في التسويق الرقمي وتحليل الهاشتاغات.

موضوع المحتوى:
${topic}

المنصة المستهدفة:
${platform}

العدد المطلوب:
${count} هاشتاغاً بالضبط.

المطلوب:
- أنشئ هاشتاغات مرتبطة مباشرة بالموضوع.
- نوّع بين الهاشتاغات العامة والمتخصصة.
- اختر كلمات مناسبة للمنصة المستهدفة.
- استخدم العربية والإنجليزية عندما يكون ذلك مناسباً.
- تجنب التكرار والهاشتاغات غير المرتبطة بالموضوع.
- اكتب كل هاشتاغ في سطر مستقل.
- لا تضف مقدمة أو شرحاً أو أرقاماً.
- أعد الهاشتاغات فقط.
`;

    const result = await hashtagChat.send(prompt);

    if (!result || !result.trim()) {
      throw new Error("لم يتم إنشاء الهاشتاغات.");
    }

    outputBox.textContent = result.trim();
    resultBox.hidden = false;

    statusBox.textContent = "تم إنشاء الهاشتاغات بنجاح.";

  } catch (error) {
    console.error("Hashtag Generator Error:", error);

    statusBox.textContent =
      "تعذر إنشاء الهاشتاغات. تحقق من الاتصال بالإنترنت وحاول مجدداً.";

  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = "✨ إنشاء الهاشتاغات";
  }
});

// نسخ جميع الهاشتاغات
copyBtn?.addEventListener("click", async () => {
  const text = outputBox?.textContent || "";

  if (!text.trim()) return;

  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = "✓ تم النسخ";

  } catch (error) {
    const temporaryInput = document.createElement("textarea");

    temporaryInput.value = text;
    temporaryInput.style.position = "fixed";
    temporaryInput.style.opacity = "0";

    document.body.appendChild(temporaryInput);
    temporaryInput.select();

    const copied = document.execCommand("copy");
    temporaryInput.remove();

    copyBtn.textContent = copied ? "✓ تم النسخ" : "تعذر النسخ";
  }

  setTimeout(() => {
    copyBtn.textContent = "نسخ جميع الهاشتاغات";
  }, 2000);
});
