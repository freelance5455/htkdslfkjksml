TN CELL 78 — PROYEK APLIKASI ANDROID

Isi:
- Aplikasi WebView Android yang memuat aplikasi kasir/stok offline.
- File HTML tersimpan di app/src/main/assets/index.html.
- Tidak memerlukan izin internet.

PENTING:
Berkas ZIP ini adalah proyek sumber Android Studio, bukan file APK yang langsung bisa dipasang.
Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle, sehingga APK belum bisa dikompilasi di sini.

Cara membuat APK:
1. Pindahkan ZIP ke komputer yang memiliki Android Studio dan Android SDK.
2. Ekstrak ZIP.
3. Buka folder TNCell78_Android_Project lewat Android Studio.
4. Tunggu Gradle Sync selesai dan pasang Android SDK Platform 35 jika diminta.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya muncul di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, buka berkasnya, lalu izinkan instalasi dari sumber tersebut jika Android meminta.

Data:
- Data disimpan secara lokal pada penyimpanan WebView aplikasi.
- Jangan menghapus data aplikasi sebelum mengekspor cadangan dari menu Cadangan Data.
- Uji pencatatan dan pemulihan cadangan dengan data percobaan sebelum dipakai untuk pembukuan nyata.
