// empty-cat.js - القطة المحققة (انميشن svg) بتظهر مكان البحث لمن الكتابة غلط ومافي نتيجة
// بتشتغل في صفحة الثيمات وصفحة اللغات (اي عنصر فيهو data-empty-cat بنحط فيهو القطة)
// الالوان: الابيض (فرو القطة) بيتبع الثيم عن طريق --surface-strong | الوردي ثابت ما بيتغير
// الحركة: الذيل بيتمايل - الراس بتميل - العيون بتتابع العدسة وبترمش - العدسة بتتحرك بتفتش
(function () {
  var F = 'var(--surface-strong,#fff)';   // لون الفرو (بيتغير مع الثيم)
  var S = 'var(--muted,#7b8190)';         // لون الحدود (بيتغير مع الثيم برضو)
  var P1 = '#ff8fbf', P2 = '#ff5e9f', P3 = '#ffb3d3';   // درجات الوردي الثابتة
  var G1 = '#4a9a5b', G2 = '#3b8250', G3 = '#2f6f40', G4 = '#6dbb7c';   // درجات الاخضر (زي المحقق)

  var CAT = [
    '<svg class="qc-cat" viewBox="0 0 230 230" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true">',
    // ===== حركات القطة (CSS جوه الـsvg) =====
    '<style>',
    '.qc-tail{transform-origin:62px 200px;animation:qcTail 2.4s ease-in-out infinite alternate}',
    '.qc-body{transform-origin:100px 205px;animation:qcBreath 2.6s ease-in-out infinite alternate}',
    '.qc-head{transform-origin:100px 135px;animation:qcHead 3.2s ease-in-out infinite}',
    '.qc-look{animation:qcLook 3.2s ease-in-out infinite}',
    '.qc-blink{transform-box:fill-box;transform-origin:center;animation:qcBlink 4s infinite}',
    '.qc-glass{transform-origin:126px 150px;animation:qcScan 3.2s ease-in-out infinite}',
    '@keyframes qcTail{from{transform:rotate(-7deg)}to{transform:rotate(9deg)}}',
    '@keyframes qcBreath{from{transform:scaleY(1)}to{transform:scaleY(1.025)}}',
    '@keyframes qcHead{0%,100%{transform:rotate(-1.5deg)}50%{transform:rotate(1.5deg)}}',
    '@keyframes qcLook{0%,100%{transform:translateX(-2.5px)}50%{transform:translateX(2.5px)}}',
    '@keyframes qcBlink{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}',
    '@keyframes qcScan{0%,100%{transform:rotate(-9deg)}50%{transform:rotate(7deg)}}',
    '@media (prefers-reduced-motion:reduce){.qc-cat *{animation:none!important}}',
    '</style>',
    // ===== ظل تحت القطة =====
    '<ellipse cx="100" cy="222" rx="58" ry="6" fill="rgba(0,0,0,.08)"/>',
    // ===== الذيل (ابيض بخطوط وردي) =====
    '<g class="qc-tail" fill="none" stroke-linecap="round">',
    '<path d="M62 205 C15 205 8 150 32 132" stroke="' + S + '" stroke-width="18"/>',
    '<path d="M62 205 C15 205 8 150 32 132" stroke="' + F + '" stroke-width="13"/>',
    '<path d="M62 205 C15 205 8 150 32 132" stroke="' + P1 + '" stroke-width="13" stroke-linecap="butt" stroke-dasharray="5 15" stroke-dashoffset="-6"/>',
    '</g>',
    // ===== الجسم: معطف المحقق الاخضر =====
    '<g class="qc-body">',
    '<path d="M58 205 Q54 150 78 132 L122 132 Q146 150 142 205 Z" fill="' + G1 + '" stroke="' + G3 + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<path d="M100 150 L100 205" stroke="' + G3 + '" stroke-width="2"/>',
    '<circle cx="93" cy="168" r="3" fill="' + G3 + '"/><circle cx="93" cy="186" r="3" fill="' + G3 + '"/>',
    '<path d="M80 132 L100 156 L88 168 L70 146 Z" fill="' + G2 + '" stroke="' + G3 + '" stroke-width="2" stroke-linejoin="round"/>',
    '<path d="M120 132 L100 156 L112 168 L130 146 Z" fill="' + G2 + '" stroke="' + G3 + '" stroke-width="2" stroke-linejoin="round"/>',
    '</g>',
    // ===== الرجلين (ابيض + وسادة وردي) =====
    '<ellipse cx="84" cy="208" rx="14" ry="8" fill="' + F + '" stroke="' + S + '" stroke-width="2.5"/>',
    '<ellipse cx="116" cy="208" rx="14" ry="8" fill="' + F + '" stroke="' + S + '" stroke-width="2.5"/>',
    '<circle cx="84" cy="209" r="3" fill="' + P1 + '"/><circle cx="116" cy="209" r="3" fill="' + P1 + '"/>',
    // ===== الايد اليسار (نازلة) =====
    '<path d="M64 150 Q50 176 56 194 L76 192 Q74 172 80 154 Z" fill="' + G1 + '" stroke="' + G3 + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<ellipse cx="66" cy="196" rx="10" ry="7.5" fill="' + F + '" stroke="' + S + '" stroke-width="2.5"/>',
    // ===== الراس: اذان + وش + طاقية =====
    '<g class="qc-head">',
    '<path d="M56 86 L48 44 L82 62 Z" fill="' + F + '" stroke="' + S + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<path d="M58 78 L55 54 L74 65 Z" fill="' + P1 + '"/>',
    '<path d="M144 86 L152 44 L118 62 Z" fill="' + F + '" stroke="' + S + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<path d="M142 78 L145 54 L126 65 Z" fill="' + P1 + '"/>',
    '<ellipse cx="100" cy="98" rx="48" ry="40" fill="' + F + '" stroke="' + S + '" stroke-width="2.5"/>',
    '<ellipse cx="122" cy="94" rx="16" ry="15" fill="' + P3 + '"/>',          // بقعة وردي حوالين العين
    '<circle cx="70" cy="112" r="7" fill="' + P1 + '" opacity=".55"/><circle cx="130" cy="112" r="7" fill="' + P1 + '" opacity=".55"/>',
    '<g class="qc-look"><g class="qc-blink">',
    '<ellipse cx="80" cy="100" rx="7" ry="9" fill="#2b2b3a"/><circle cx="82.5" cy="96.5" r="2.6" fill="#fff"/>',
    '<ellipse cx="120" cy="100" rx="7" ry="9" fill="#2b2b3a"/><circle cx="122.5" cy="96.5" r="2.6" fill="#fff"/>',
    '</g></g>',
    '<path d="M96 110 L104 110 L100 115 Z" fill="' + P2 + '" stroke="' + P2 + '" stroke-width="1.5" stroke-linejoin="round"/>',
    '<path d="M100 115 Q96 121 91 118 M100 115 Q104 121 109 118" fill="none" stroke="#7a3b57" stroke-width="1.8" stroke-linecap="round"/>',
    '<g stroke="' + S + '" stroke-width="1.6" stroke-linecap="round"><path d="M62 110 L38 104 M62 116 L38 119 M138 110 L162 104 M138 116 L162 119"/></g>',
    // الطاقية (طاقية محقق خضراء بتربيطة وردي)
    '<path d="M68 76 C66 40 90 28 100 28 C110 28 134 40 132 76 Q100 84 68 76 Z" fill="' + G1 + '" stroke="' + G3 + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<g fill="none" stroke="' + G4 + '" stroke-width="1.5" stroke-linecap="round"><path d="M100 31 L100 80 M84 35 Q82 58 82 79 M116 35 Q118 58 118 79 M70 56 Q100 62 130 56"/></g>',
    '<path d="M74 76 Q100 104 126 76 Q100 88 74 76 Z" fill="' + G2 + '" stroke="' + G3 + '" stroke-width="2" stroke-linejoin="round"/>',
    '<path d="M100 28 C88 12 78 26 100 28 C122 26 112 12 100 28 Z" fill="' + P1 + '" stroke="' + P2 + '" stroke-width="1.5" stroke-linejoin="round"/>',
    '<circle cx="100" cy="28" r="3.5" fill="' + P2 + '"/>',
    '</g>',
    // ===== الايد اليمين + العدسة (بتتحرك بتفتش) =====
    '<g class="qc-glass">',
    '<path d="M120 144 L150 124 L162 138 L132 162 Z" fill="' + G1 + '" stroke="' + G3 + '" stroke-width="2.5" stroke-linejoin="round"/>',
    '<path d="M169 109 L158 130" stroke="#6b4a2b" stroke-width="6" stroke-linecap="round"/>',
    '<ellipse cx="157" cy="131" rx="10" ry="8" fill="' + F + '" stroke="' + S + '" stroke-width="2.5"/>',
    '<circle cx="176" cy="90" r="20" fill="rgba(160,215,255,.35)" stroke="#d9a441" stroke-width="5"/>',
    '<path d="M165 82 Q168 74 176 72" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity=".85"/>',
    '</g>',
    '</svg>'
  ].join('');

  [].forEach.call(document.querySelectorAll('[data-empty-cat]'), function (el) { el.innerHTML = CAT; });
})();
