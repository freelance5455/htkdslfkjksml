// i18n.js - الترجمة اليدوية للغات الاساسية الخمس: عربي / انجليزي / فرنسي / تركي / اسباني
// الاستخدام في الـHTML:
//   data-i18n="key"        => يستبدل النص
//   data-i18n-ph="key"     => يستبدل الـplaceholder
//   data-i18n-html="key"   => نص فيه {b} يتبدل باسم التطبيق Qulife ملوّن
// باقي اللغات (92 لغة) موجودة في صفحة اللغات بس "قريباً" - ما اتحذفت.
(function () {
  var D = {
    en: {
      'app.welcome': 'Welcome to {b}', 'app.tagline': 'Choose your style, live your Qulife.', 'app.start': 'Get started', 'app.alert': 'Welcome to Qulife!',
      'common.apply': 'Apply', 'common.selected': 'Selected', 'common.choose': 'Choose your style',
      'th.title': 'Themes', 'th.sub': 'Pick a look', 'th.live': 'LIVE PREVIEW', 'th.light': 'Light mode', 'th.dark': 'Dark mode',
      'th.text': 'Text', 'th.button': 'Button', 'th.accent': 'Accent', 'th.search': 'Search color',
      'f.all': 'All', 'f.light': 'Light', 'f.dark': 'Dark', 'f.mine': 'Mine',
      'sec.orig': 'Qulife originals', 'sec.mine': 'My styles', 'sec.colors': 'Color collection', 'sec.none': 'No custom styles yet',
      'empty.t': 'No theme found', 'empty.s': 'Try another color',
      'sheet.title': 'Make your own', 'sheet.name': 'Style name', 'sheet.save': 'Save style', 'sheet.auto': 'text adjusts automatically',
      'custom': 'Custom', 'custom.s': 'Make your color', 'scr.style': 'Your style', 'scr.start': 'Start', 'mine.tag': 'Custom',
      'lg.title': 'Language', 'lg.sub': 'Choose your language', 'lg.search': 'Search language', 'lg.avail': 'Available now', 'lg.more': 'More languages',
      'lg.soon': 'Soon', 'lg.toast': 'Coming soon! We are working on this language.', 'lg.empty': 'No language found', 'lg.emptys': 'Try another language',
      'lg.current': 'Current language', 'lg.apply': 'Apply language',
      'c.Qulife': 'Qulife', 'c.Qulife Dark': 'Qulife Dark'
    },
    ar: {
      'app.welcome': 'مرحباً بك في {b}', 'app.tagline': 'اختر أسلوبك، وعِش حياتك مع Qulife.', 'app.start': 'ابدأ الآن', 'app.alert': 'أهلاً بك في Qulife!',
      'common.apply': 'تطبيق', 'common.selected': 'المختار', 'common.choose': 'اختر أسلوبك',
      'th.title': 'الثيمات', 'th.sub': 'اختر مظهرك', 'th.live': 'معاينة مباشرة', 'th.light': 'الوضع الفاتح', 'th.dark': 'الوضع الداكن',
      'th.text': 'النص', 'th.button': 'الزر', 'th.accent': 'اللون', 'th.search': 'ابحث عن لون',
      'f.all': 'الكل', 'f.light': 'فاتح', 'f.dark': 'داكن', 'f.mine': 'ثيماتي',
      'sec.orig': 'ثيمات Qulife الأصلية', 'sec.mine': 'أنماطي', 'sec.colors': 'مجموعة الألوان', 'sec.none': 'لا توجد أنماط مخصصة بعد',
      'empty.t': 'لم يتم العثور على ثيم', 'empty.s': 'جرّب لوناً آخر',
      'sheet.title': 'اصنع ثيمك', 'sheet.name': 'اسم النمط', 'sheet.save': 'حفظ النمط', 'sheet.auto': 'النصوص تُضبط تلقائياً',
      'custom': 'مخصص', 'custom.s': 'اصنع لونك', 'scr.style': 'أسلوبك', 'scr.start': 'ابدأ', 'mine.tag': 'مخصص',
      'lg.title': 'اللغة', 'lg.sub': 'اختر لغتك', 'lg.search': 'ابحث عن لغة', 'lg.avail': 'متاحة الآن', 'lg.more': 'المزيد من اللغات',
      'lg.soon': 'قريباً', 'lg.toast': 'قريباً! نعمل على هذه اللغة.', 'lg.empty': 'لم يتم العثور على لغة', 'lg.emptys': 'جرّب لغة أخرى',
      'lg.current': 'اللغة الحالية', 'lg.apply': 'تطبيق اللغة',
      'c.Qulife': 'Qulife', 'c.Qulife Dark': 'Qulife الداكن',
      'c.Pink': 'الوردي', 'c.Blue': 'الأزرق', 'c.Purple': 'البنفسجي', 'c.Green': 'الأخضر', 'c.Orange': 'البرتقالي', 'c.Red': 'الأحمر',
      'c.Teal': 'الفيروزي', 'c.Cyan': 'السماوي', 'c.Yellow': 'الأصفر', 'c.Dark': 'الأسود الداكن', 'c.Rose': 'الوردي الداكن', 'c.Indigo': 'النيلي',
      'c.Violet': 'البنفسجي الفاتح', 'c.Fuchsia': 'الفوشيا', 'c.Lime': 'الليموني', 'c.Emerald': 'الزمردي', 'c.Amber': 'الكهرماني', 'c.Brown': 'البني',
      'c.Gray': 'الرمادي', 'c.Sky': 'السماوي الفاتح', 'c.Navy': 'الكحلي', 'c.Mint': 'النعناعي', 'c.Peach': 'الخوخي', 'c.Lavender': 'اللافندر',
      'c.Coral': 'المرجاني', 'c.Olive': 'الزيتوني', 'c.Gold': 'الذهبي', 'c.Silver': 'الفضي', 'c.Midnight': 'منتصف الليل', 'c.Sunset': 'الغروب',
      'c.Ocean': 'المحيط', 'c.Forest': 'الغابة', 'c.Cherry': 'الكرزي', 'c.Grape': 'العنبي'
    },
    fr: {
      'app.welcome': 'Bienvenue sur {b}', 'app.tagline': 'Choisis ton style, vis ta Qulife.', 'app.start': 'Commencer', 'app.alert': 'Bienvenue sur Qulife !',
      'common.apply': 'Appliquer', 'common.selected': 'Sélectionné', 'common.choose': 'Choisis ton style',
      'th.title': 'Thèmes', 'th.sub': 'Choisis ton style', 'th.live': 'APERÇU EN DIRECT', 'th.light': 'Mode clair', 'th.dark': 'Mode sombre',
      'th.text': 'Texte', 'th.button': 'Bouton', 'th.accent': 'Accent', 'th.search': 'Rechercher une couleur',
      'f.all': 'Tout', 'f.light': 'Clair', 'f.dark': 'Sombre', 'f.mine': 'Les miens',
      'sec.orig': 'Originaux Qulife', 'sec.mine': 'Mes styles', 'sec.colors': 'Collection de couleurs', 'sec.none': 'Aucun style perso pour le moment',
      'empty.t': 'Aucun thème trouvé', 'empty.s': 'Essaie une autre couleur',
      'sheet.title': 'Crée le tien', 'sheet.name': 'Nom du style', 'sheet.save': 'Enregistrer le style', 'sheet.auto': 'le texte s’ajuste automatiquement',
      'custom': 'Perso', 'custom.s': 'Crée ta couleur', 'scr.style': 'Ton style', 'scr.start': 'Go', 'mine.tag': 'Perso',
      'lg.title': 'Langue', 'lg.sub': 'Choisis ta langue', 'lg.search': 'Rechercher une langue', 'lg.avail': 'Disponibles', 'lg.more': 'Plus de langues',
      'lg.soon': 'Bientôt', 'lg.toast': 'Bientôt disponible ! Nous travaillons sur cette langue.', 'lg.empty': 'Aucune langue trouvée', 'lg.emptys': 'Essaie une autre langue',
      'lg.current': 'Langue actuelle', 'lg.apply': 'Appliquer la langue',
      'c.Qulife': 'Qulife', 'c.Qulife Dark': 'Qulife Sombre',
      'c.Pink': 'Rose', 'c.Blue': 'Bleu', 'c.Purple': 'Violet', 'c.Green': 'Vert', 'c.Orange': 'Orange', 'c.Red': 'Rouge',
      'c.Teal': 'Sarcelle', 'c.Cyan': 'Cyan', 'c.Yellow': 'Jaune', 'c.Dark': 'Noir', 'c.Rose': 'Rose vif', 'c.Indigo': 'Indigo',
      'c.Violet': 'Violet clair', 'c.Fuchsia': 'Fuchsia', 'c.Lime': 'Citron vert', 'c.Emerald': 'Émeraude', 'c.Amber': 'Ambre', 'c.Brown': 'Marron',
      'c.Gray': 'Gris', 'c.Sky': 'Ciel', 'c.Navy': 'Bleu marine', 'c.Mint': 'Menthe', 'c.Peach': 'Pêche', 'c.Lavender': 'Lavande',
      'c.Coral': 'Corail', 'c.Olive': 'Olive', 'c.Gold': 'Or', 'c.Silver': 'Argent', 'c.Midnight': 'Minuit', 'c.Sunset': 'Coucher de soleil',
      'c.Ocean': 'Océan', 'c.Forest': 'Forêt', 'c.Cherry': 'Cerise', 'c.Grape': 'Raisin'
    },
    tr: {
      'app.welcome': '{b} dünyasına hoş geldin', 'app.tagline': 'Tarzını seç, hayatını Qulife ile yaşa.', 'app.start': 'Başla', 'app.alert': 'Qulife dünyasına hoş geldin!',
      'common.apply': 'Uygula', 'common.selected': 'Seçili', 'common.choose': 'Tarzını seç',
      'th.title': 'Temalar', 'th.sub': 'Görünümünü seç', 'th.live': 'CANLI ÖNİZLEME', 'th.light': 'Açık mod', 'th.dark': 'Koyu mod',
      'th.text': 'Metin', 'th.button': 'Düğme', 'th.accent': 'Vurgu', 'th.search': 'Renk ara',
      'f.all': 'Tümü', 'f.light': 'Açık', 'f.dark': 'Koyu', 'f.mine': 'Benimkiler',
      'sec.orig': 'Qulife orijinalleri', 'sec.mine': 'Stillerim', 'sec.colors': 'Renk koleksiyonu', 'sec.none': 'Henüz özel stil yok',
      'empty.t': 'Tema bulunamadı', 'empty.s': 'Başka bir renk dene',
      'sheet.title': 'Kendi temanı yap', 'sheet.name': 'Stil adı', 'sheet.save': 'Stili kaydet', 'sheet.auto': 'metin otomatik ayarlanır',
      'custom': 'Özel', 'custom.s': 'Kendi rengini yap', 'scr.style': 'Tarzın', 'scr.start': 'Başla', 'mine.tag': 'Özel',
      'lg.title': 'Dil', 'lg.sub': 'Dilini seç', 'lg.search': 'Dil ara', 'lg.avail': 'Şimdi kullanılabilir', 'lg.more': 'Daha fazla dil',
      'lg.soon': 'Yakında', 'lg.toast': 'Yakında! Bu dil üzerinde çalışıyoruz.', 'lg.empty': 'Dil bulunamadı', 'lg.emptys': 'Başka bir dil dene',
      'lg.current': 'Geçerli dil', 'lg.apply': 'Dili uygula',
      'c.Qulife': 'Qulife', 'c.Qulife Dark': 'Qulife Koyu',
      'c.Pink': 'Pembe', 'c.Blue': 'Mavi', 'c.Purple': 'Mor', 'c.Green': 'Yeşil', 'c.Orange': 'Turuncu', 'c.Red': 'Kırmızı',
      'c.Teal': 'Petrol yeşili', 'c.Cyan': 'Camgöbeği', 'c.Yellow': 'Sarı', 'c.Dark': 'Siyah', 'c.Rose': 'Gül kırmızısı', 'c.Indigo': 'Çivit',
      'c.Violet': 'Eflatun', 'c.Fuchsia': 'Fuşya', 'c.Lime': 'Limon yeşili', 'c.Emerald': 'Zümrüt', 'c.Amber': 'Kehribar', 'c.Brown': 'Kahverengi',
      'c.Gray': 'Gri', 'c.Sky': 'Gökyüzü', 'c.Navy': 'Lacivert', 'c.Mint': 'Nane', 'c.Peach': 'Şeftali', 'c.Lavender': 'Lavanta',
      'c.Coral': 'Mercan', 'c.Olive': 'Zeytin', 'c.Gold': 'Altın', 'c.Silver': 'Gümüş', 'c.Midnight': 'Gece yarısı', 'c.Sunset': 'Gün batımı',
      'c.Ocean': 'Okyanus', 'c.Forest': 'Orman', 'c.Cherry': 'Kiraz', 'c.Grape': 'Üzüm'
    },
    es: {
      'app.welcome': 'Bienvenido a {b}', 'app.tagline': 'Elige tu estilo, vive tu Qulife.', 'app.start': 'Empezar', 'app.alert': '¡Bienvenido a Qulife!',
      'common.apply': 'Aplicar', 'common.selected': 'Seleccionado', 'common.choose': 'Elige tu estilo',
      'th.title': 'Temas', 'th.sub': 'Elige tu estilo', 'th.live': 'VISTA PREVIA', 'th.light': 'Modo claro', 'th.dark': 'Modo oscuro',
      'th.text': 'Texto', 'th.button': 'Botón', 'th.accent': 'Acento', 'th.search': 'Buscar color',
      'f.all': 'Todos', 'f.light': 'Claro', 'f.dark': 'Oscuro', 'f.mine': 'Míos',
      'sec.orig': 'Originales de Qulife', 'sec.mine': 'Mis estilos', 'sec.colors': 'Colección de colores', 'sec.none': 'Aún no hay estilos propios',
      'empty.t': 'No se encontró ningún tema', 'empty.s': 'Prueba otro color',
      'sheet.title': 'Crea el tuyo', 'sheet.name': 'Nombre del estilo', 'sheet.save': 'Guardar estilo', 'sheet.auto': 'el texto se ajusta solo',
      'custom': 'Propio', 'custom.s': 'Crea tu color', 'scr.style': 'Tu estilo', 'scr.start': 'Inicio', 'mine.tag': 'Propio',
      'lg.title': 'Idioma', 'lg.sub': 'Elige tu idioma', 'lg.search': 'Buscar idioma', 'lg.avail': 'Disponibles ahora', 'lg.more': 'Más idiomas',
      'lg.soon': 'Pronto', 'lg.toast': '¡Próximamente! Estamos trabajando en este idioma.', 'lg.empty': 'No se encontró el idioma', 'lg.emptys': 'Prueba otro idioma',
      'lg.current': 'Idioma actual', 'lg.apply': 'Aplicar idioma',
      'c.Qulife': 'Qulife', 'c.Qulife Dark': 'Qulife Oscuro',
      'c.Pink': 'Rosa', 'c.Blue': 'Azul', 'c.Purple': 'Morado', 'c.Green': 'Verde', 'c.Orange': 'Naranja', 'c.Red': 'Rojo',
      'c.Teal': 'Verde azulado', 'c.Cyan': 'Cian', 'c.Yellow': 'Amarillo', 'c.Dark': 'Negro', 'c.Rose': 'Rosa intenso', 'c.Indigo': 'Índigo',
      'c.Violet': 'Violeta', 'c.Fuchsia': 'Fucsia', 'c.Lime': 'Lima', 'c.Emerald': 'Esmeralda', 'c.Amber': 'Ámbar', 'c.Brown': 'Marrón',
      'c.Gray': 'Gris', 'c.Sky': 'Celeste', 'c.Navy': 'Azul marino', 'c.Mint': 'Menta', 'c.Peach': 'Melocotón', 'c.Lavender': 'Lavanda',
      'c.Coral': 'Coral', 'c.Olive': 'Oliva', 'c.Gold': 'Oro', 'c.Silver': 'Plata', 'c.Midnight': 'Medianoche', 'c.Sunset': 'Atardecer',
      'c.Ocean': 'Océano', 'c.Forest': 'Bosque', 'c.Cherry': 'Cereza', 'c.Grape': 'Uva'
    }
  };
  // الاسماء الانجليزية للالوان = نفس الاسم
  ['Pink','Blue','Purple','Green','Orange','Red','Teal','Cyan','Yellow','Dark','Rose','Indigo','Violet','Fuchsia','Lime','Emerald','Amber','Brown','Gray','Sky','Navy','Mint','Peach','Lavender','Coral','Olive','Gold','Silver','Midnight','Sunset','Ocean','Forest','Cherry','Grape']
    .forEach(function (n) { D.en['c.' + n] = n; });

  var SUPPORTED = ['ar', 'en', 'fr', 'tr', 'es'];
  var RTL = { ar: 1 };
  // قيم قديمة كانت متخزنة (اسم اللغة بدل الكود)
  var LEGACY = { arabic: 'ar', english: 'en', french: 'fr', turkish: 'tr', spanish: 'es' };

  var lang = 'en';
  function norm(c) { c = String(c || '').toLowerCase(); return LEGACY[c] || c; }
  function t(key, fb) { var d = D[lang] || D.en; return d[key] != null ? d[key] : (D.en[key] != null ? D.en[key] : (fb != null ? fb : key)); }

  function apply(root) {
    root = root || document;
    var brand = '<span class="brand">Qulife</span>';
    [].forEach.call(root.querySelectorAll('[data-i18n]'), function (el) { el.textContent = t(el.getAttribute('data-i18n')); });
    [].forEach.call(root.querySelectorAll('[data-i18n-ph]'), function (el) { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph'))); });
    [].forEach.call(root.querySelectorAll('[data-i18n-html]'), function (el) { el.innerHTML = t(el.getAttribute('data-i18n-html')).replace('{b}', brand); });
  }
  function set(code, persist) {
    code = norm(code);
    if (SUPPORTED.indexOf(code) < 0) return false;
    lang = code;
    var root = document.documentElement;
    root.lang = code; root.dir = RTL[code] ? 'rtl' : 'ltr';
    apply(document);
    if (persist) { try { localStorage.setItem('qulife_language_code', code); } catch (e) {} }
    try { window.dispatchEvent(new CustomEvent('qulife-lang', { detail: code })); } catch (e) {}
    return true;
  }

  window.QulifeI18n = { t: t, set: set, apply: apply, supported: SUPPORTED, get lang() { return lang; } };

  // تشغيل: اللغة المحفوظة (او الانجليزي)
  var saved = 'en';
  try { saved = localStorage.getItem('qulife_language_code') || 'en'; } catch (e) {}
  set(saved, false);
  document.addEventListener('DOMContentLoaded', function () { apply(document); });
  // الصفحة الفرعية (iframe) تاخد اللغة من الرئيسية لو التخزين مقفول
  window.addEventListener('message', function (e) {
    if (e.data && e.data.qulife === 'init' && e.data.lang) set(e.data.lang, false);
  });
})();
