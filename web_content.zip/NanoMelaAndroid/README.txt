NANO & MELA — proyecto Android

Este proyecto envuelve tu HTML original en una app Android usando WebView.
Nombre visible: Nano & Mela
Paquete: com.nanomela.app
Icono: la imagen de los pingüinos que enviaste.

CÓMO GENERAR EL APK
1. Instala Android Studio en una computadora.
2. Abre Android Studio y selecciona Open.
3. Elige la carpeta NanoMelaAndroid (la carpeta que contiene settings.gradle).
4. Acepta la instalación del Android SDK 35 y la sincronización de Gradle.
5. En el menú Build, elige Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio generará el APK en app/build/outputs/apk/debug/app-debug.apk.

El HTML se carga desde los recursos locales de la app. La fuente Pixelify Sans se solicita
a Google Fonts, por lo que esa fuente requiere conexión a internet; el resto del HTML
está incluido dentro de la aplicación.
