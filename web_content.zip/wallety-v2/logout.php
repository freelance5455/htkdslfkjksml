<?php
require_once __DIR__ . '/includes/bootstrap.php';

// Logout must be a POST with a valid CSRF token so other sites can't log users out.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string) $_POST['csrf'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}
redirect('index.php');
