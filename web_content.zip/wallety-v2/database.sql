-- Wallety schema (MySQL 5.7+ / MariaDB 10+)
-- Safe to run on an existing database: every statement is CREATE TABLE IF NOT EXISTS.
--   Fresh install : create the database, select it, then import this file.
--   Existing site : import this file to add anything that is missing (e.g. user_settings).
-- No demo user is created on purpose — register one through the app.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS users (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50)  NOT NULL UNIQUE,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_settings (
    user_id  INT UNSIGNED NOT NULL PRIMARY KEY,
    lang     VARCHAR(5)   NOT NULL DEFAULT 'en',
    currency VARCHAR(3)   NOT NULL DEFAULT 'USD',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
    id      INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    name    VARCHAR(50)  NOT NULL,
    type    ENUM('income','expense') NOT NULL DEFAULT 'expense',
    color   VARCHAR(7)   NOT NULL DEFAULT '#2563eb',
    KEY idx_cat_user (user_id, name),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS transactions (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    category_id INT UNSIGNED NULL,
    title       VARCHAR(150) NOT NULL,
    type        ENUM('income','expense') NOT NULL,
    amount      DECIMAL(12,2) NOT NULL,
    trans_date  DATE NOT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_tx_user_date (user_id, trans_date),
    FOREIGN KEY (user_id)     REFERENCES users(id)      ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS accounts (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    name       VARCHAR(80)  NOT NULL,
    type       VARCHAR(20)  NOT NULL DEFAULT 'Bank',
    balance    DECIMAL(12,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_acc_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS debts (
    id          INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id     INT UNSIGNED NOT NULL,
    person_name VARCHAR(100) NOT NULL,
    amount      DECIMAL(12,2) NOT NULL,
    type        ENUM('borrowed','lent') NOT NULL DEFAULT 'borrowed',
    status      ENUM('unpaid','paid')   NOT NULL DEFAULT 'unpaid',
    due_date    DATE NULL,
    note        TEXT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_debt_user (user_id, status),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS goals (
    id             INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL,
    title          VARCHAR(120) NOT NULL,
    target_amount  DECIMAL(12,2) NOT NULL,
    current_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    deadline       DATE NULL,
    status         ENUM('active','completed') NOT NULL DEFAULT 'active',
    created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_goal_user (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reminders (
    id            INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    title         VARCHAR(150) NOT NULL,
    reminder_date DATE NOT NULL,
    note          TEXT NULL,
    status        ENUM('pending','done') NOT NULL DEFAULT 'pending',
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_rem_user (user_id, reminder_date),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------------
-- Upgrading an OLD database whose tables already exist? The app expects these columns.
-- Run only the lines for columns you are missing (check with: SHOW COLUMNS FROM <table>;)
--   ALTER TABLE transactions ADD COLUMN title VARCHAR(150) NOT NULL DEFAULT '' AFTER category_id;
--   ALTER TABLE categories   MODIFY type ENUM('income','expense') NOT NULL DEFAULT 'expense';
-- ---------------------------------------------------------------------------------
