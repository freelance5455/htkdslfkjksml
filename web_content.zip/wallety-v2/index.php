<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (!empty($_SESSION['user_id'])) {
    redirect('dashboard.php');
}

$error = '';
$login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $login = clean_str($_POST['login'] ?? '', 100);
    $password = (string) ($_POST['password'] ?? '');

    // Basic brute-force throttle: 5 failures => 60 second lock for this session.
    if (($_SESSION['login_lock'] ?? 0) > time()) {
        $error = t('err_throttle');
    } elseif ($login === '' || $password === '') {
        $error = t('err_login_empty');
    } else {
        $st = db()->prepare('SELECT id, username, password FROM users WHERE username = ? OR email = ? LIMIT 1');
        $st->execute([$login, $login]);
        $user = $st->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if (password_needs_rehash($user['password'], PASSWORD_DEFAULT)) {
                db()->prepare('UPDATE users SET password = ? WHERE id = ?')
                    ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
            }
            unset($_SESSION['login_fails'], $_SESSION['login_lock']);
            login_user($user);
            redirect('dashboard.php');
        }
        $_SESSION['login_fails'] = ($_SESSION['login_fails'] ?? 0) + 1;
        if ($_SESSION['login_fails'] >= 5) {
            $_SESSION['login_lock'] = time() + 60;
            $_SESSION['login_fails'] = 0;
        }
        $error = t('err_login_invalid');
    }
}

auth_header(t('sign_in'));
?>
<h2><?= e(t('sign_in')) ?></h2>
<p class="muted"><?= e(t('sign_in_sub')) ?></p>
<?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
<form method="post" autocomplete="on">
    <?= csrf_field() ?>
    <div class="field">
        <label for="login"><?= e(t('username_or_email')) ?></label>
        <input type="text" id="login" name="login" value="<?= e($login) ?>" required autofocus autocomplete="username">
    </div>
    <div class="field">
        <label for="password"><?= e(t('password')) ?></label>
        <input type="password" id="password" name="password" required autocomplete="current-password">
    </div>
    <button type="submit" class="btn btn-primary btn-block"><?= e(t('sign_in')) ?></button>
</form>
<p class="auth-alt"><?= e(t('new_here')) ?> <a href="register.php"><?= e(t('create_account')) ?></a></p>
<?php auth_footer(); ?>
