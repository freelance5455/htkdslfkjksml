<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        db()->prepare('DELETE FROM reminders WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        flash('success', t('deleted'));
    } elseif ($action === 'toggle') {
        db()->prepare("UPDATE reminders SET status = IF(status = 'done', 'pending', 'done') WHERE id = ? AND user_id = ?")->execute([$id, $uid]);
    } elseif ($action === 'save') {
        $title = clean_str($_POST['title'] ?? '', 150);
        $date = $_POST['reminder_date'] ?? '';
        $note = clean_str($_POST['note'] ?? '', 500);
        if ($title === '' || !valid_date($date)) {
            flash('error', t('err_fill'));
        } else {
            db()->prepare("INSERT INTO reminders (user_id, title, reminder_date, note, status) VALUES (?, ?, ?, ?, 'pending')")
                ->execute([$uid, $title, $date, $note]);
            flash('success', t('added'));
        }
    }
    redirect('reminders.php');
}

$st = db()->prepare("SELECT * FROM reminders WHERE user_id = ? ORDER BY status = 'done', reminder_date, id");
$st->execute([$uid]);
$reminders = $st->fetchAll();

$today = date('Y-m-d');
$pending = $dueToday = $overdue = 0;
foreach ($reminders as $r) {
    if ($r['status'] !== 'done') {
        $pending++;
        if ($r['reminder_date'] === $today) { $dueToday++; }
        if ($r['reminder_date'] < $today) { $overdue++; }
    }
}

page_header('reminders');
page_title(t('reminders'), t('reminders_sub'));
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('pending')) ?><span class="stat-ic"><?= icon('bell') ?></span></div>
        <div class="stat-val"><?= $pending ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('due_today')) ?><span class="stat-ic amber"><?= icon('bell') ?></span></div>
        <div class="stat-val <?= $dueToday ? 'neg' : '' ?>"><?= $dueToday ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('overdue')) ?><span class="stat-ic red"><?= icon('bell') ?></span></div>
        <div class="stat-val <?= $overdue ? 'neg' : '' ?>"><?= $overdue ?></div>
    </div>
</section>

<section class="grid split">
    <div class="card">
        <div class="card-head"><h2><?= e(t('add_reminder')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <div class="field"><label for="title"><?= e(t('title')) ?></label>
                <input type="text" id="title" name="title" maxlength="150" required></div>
            <div class="field"><label for="date"><?= e(t('date')) ?></label>
                <input type="date" id="date" name="reminder_date" required value="<?= e($today) ?>"></div>
            <div class="field"><label for="note"><?= e(t('note')) ?></label>
                <textarea id="note" name="note" maxlength="500"></textarea></div>
            <button class="btn btn-primary btn-block" type="submit"><?= e(t('add_reminder')) ?></button>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('reminders')) ?></h2></div>
        <?php if (!$reminders): ?>
            <?php empty_state(t('no_reminders')); ?>
        <?php else: ?>
            <div class="list">
                <?php foreach ($reminders as $r):
                    $done = $r['status'] === 'done';
                    $late = !$done && $r['reminder_date'] < $today; ?>
                    <div class="item <?= $done ? 'done' : '' ?>">
                        <div>
                            <h4><?= e($r['title']) ?></h4>
                            <span class="muted"><span class="num"><?= e($r['reminder_date']) ?></span>
                                <?= $late ? badge(t('overdue'), 'red') : ($r['reminder_date'] === $today && !$done ? badge(t('today'), 'amber') : '') ?>
                                <?= $done ? badge(t('done'), 'gray') : '' ?></span>
                            <?php if ($r['note']): ?><span class="sub muted" style="display:block;font-size:13px"><?= e($r['note']) ?></span><?php endif; ?>
                        </div>
                        <div style="display:flex;gap:4px">
                            <?= action_button('toggle', (int) $r['id'], $done ? t('mark_pending') : t('mark_done'), $done ? '' : 'check', 'btn') ?>
                            <?= delete_button((int) $r['id']) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php page_footer();
