<?php
require_once __DIR__ . '/includes/bootstrap.php';

if (!empty($_SESSION['user_id'])) {
    redirect('dashboard.php');
}

$error = '';
$f = ['username' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $f['username'] = clean_str($_POST['username'] ?? '', 30);
    $f['email'] = clean_str($_POST['email'] ?? '', 100);
    $password = (string) ($_POST['password'] ?? '');   // never trim passwords
    $confirm = (string) ($_POST['confirm_password'] ?? '');

    if ($f['username'] === '' || $f['email'] === '' || $password === '') {
        $error = t('err_fill');
    } elseif (!preg_match('/^[\p{L}\p{N}_.\-]{3,30}$/u', $f['username'])) {
        $error = t('err_username');
    } elseif (!filter_var($f['email'], FILTER_VALIDATE_EMAIL)) {
        $error = t('err_email');
    } elseif (mb_strlen($password) < 8) {
        $error = t('err_password_len');
    } elseif ($password !== $confirm) {
        $error = t('err_password_match');
    } else {
        $st = db()->prepare('SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1');
        $st->execute([$f['email'], $f['username']]);
        if ($st->fetch()) {
            $error = t('err_exists');
        } else {
            db()->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)')
                ->execute([$f['username'], $f['email'], password_hash($password, PASSWORD_DEFAULT)]);
            $uid = (int) db()->lastInsertId();
            // Keep the language the visitor was already browsing in.
            save_prefs($uid, $lang, 'USD');
            login_user(['id' => $uid, 'username' => $f['username']]);
            flash('success', t('welcome_msg', $f['username']));
            redirect('dashboard.php');
        }
    }
}

auth_header(t('create_account'));
?>
<h2><?= e(t('create_account')) ?></h2>
<p class="muted"><?= e(t('register_sub')) ?></p>
<?php if ($error): ?><div class="flash flash-error"><?= e($error) ?></div><?php endif; ?>
<form method="post" autocomplete="on">
    <?= csrf_field() ?>
    <div class="field">
        <label for="username"><?= e(t('username')) ?></label>
        <input type="text" id="username" name="username" value="<?= e($f['username']) ?>" required minlength="3" maxlength="30" autocomplete="username">
    </div>
    <div class="field">
        <label for="email"><?= e(t('email')) ?></label>
        <input type="email" id="email" name="email" value="<?= e($f['email']) ?>" required autocomplete="email">
    </div>
    <div class="form-row">
        <div class="field">
            <label for="password"><?= e(t('password')) ?></label>
            <input type="password" id="password" name="password" required minlength="8" autocomplete="new-password">
        </div>
        <div class="field">
            <label for="confirm_password"><?= e(t('confirm_password')) ?></label>
            <input type="password" id="confirm_password" name="confirm_password" required minlength="8" autocomplete="new-password">
        </div>
    </div>
    <p class="muted" style="margin:-4px 0 16px;font-size:13px"><?= e(t('password_hint')) ?></p>
    <button type="submit" class="btn btn-primary btn-block"><?= e(t('create_account')) ?></button>
</form>
<p class="auth-alt"><?= e(t('have_account')) ?> <a href="index.php"><?= e(t('sign_in')) ?></a></p>
<?php auth_footer(); ?>
