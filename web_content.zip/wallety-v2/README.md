# Wallety

A personal finance manager: transactions, accounts, debts, savings goals, reminders and monthly reports.
PHP 7.4+ · MySQL/MariaDB · vanilla JS + Chart.js · English / Français / العربية (RTL) · light & dark theme.

## Setup

1. Create a MySQL database and import `database.sql` (safe to re-run on an existing database).
2. Copy `config/config.sample.php` to `config/config.local.php` and enter your database details.
   (Or set `WALLETY_DB_HOST`, `WALLETY_DB_PORT`, `WALLETY_DB_NAME`, `WALLETY_DB_USER`, `WALLETY_DB_PASS`.)
3. Open the site and click **Create account**. There is no default/demo user.

XAMPP: put the folder in `htdocs/wallety`, then visit `http://localhost/wallety/`.
InfinityFree: upload the contents to `htdocs/`, import `database.sql` in phpMyAdmin, create `config/config.local.php` there.

## Upgrading from the previous version

Delete these old files before uploading the new ones: `db.php`, `lang.php`, `iii.php`, `TODO.md`,
`config/database.php`, `includes/functions.php`, `includes/languages.php`, `includes/navbar.php`,
`includes/style.php`. Then import `database.sql` (adds the missing `user_settings` table). Existing
users and data keep working — passwords are already hashed with `password_hash`.

## Project layout

```
index.php  register.php  logout.php          authentication
dashboard.php  transactions.php  accounts.php  debts.php  goals.php  reminders.php  reports.php  settings.php
includes/bootstrap.php   session, config, PDO, CSRF, i18n, helpers (every page loads this first)
includes/layout.php      app shell, auth shell, icons, UI helpers
includes/data.php        shared report queries
languages/{en,fr,ar}.php translations (English is the fallback for missing keys)
assets/css/style.css     the single stylesheet (design tokens at the top)
assets/js/app.js         theme toggle, mobile nav, delete confirmations, chart helpers
```

Adding a language: copy `languages/en.php`, translate it, add the code to `SUPPORTED_LANGS` in
`includes/bootstrap.php` and to the language pickers in `includes/layout.php` and `settings.php`.

## Security notes

- All queries use prepared statements; all output is escaped with `e()`.
- Every state-changing action is a POST protected by a CSRF token (deletes are no longer GET links).
- Sessions are regenerated on login, cookies are HttpOnly + SameSite=Lax, login attempts are throttled.
- Database credentials live only in `config/config.local.php` (git-ignored) or environment variables.
- `.htaccess` files block direct access to `config/`, `includes/`, `languages/`, `.sql` and `.md` files (Apache).
- Serve the site over HTTPS in production.
