<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

const ACCOUNT_TYPES = ['Cash', 'Bank', 'Savings', 'Wallet', 'Other'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        db()->prepare('DELETE FROM accounts WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        flash('success', t('deleted'));
    } elseif ($action === 'save') {
        $name = clean_str($_POST['name'] ?? '', 80);
        $type = in_array($_POST['type'] ?? '', ACCOUNT_TYPES, true) ? $_POST['type'] : 'Other';
        $balance = to_amount($_POST['balance'] ?? 0);

        if ($name === '' || abs($balance) > 99999999.99) {
            flash('error', t('err_fill'));
            redirect('accounts.php' . ($id ? '?edit=' . $id : ''));
        }
        if ($id) {
            db()->prepare('UPDATE accounts SET name = ?, type = ?, balance = ? WHERE id = ? AND user_id = ?')->execute([$name, $type, $balance, $id, $uid]);
            flash('success', t('updated'));
        } else {
            db()->prepare('INSERT INTO accounts (user_id, name, type, balance) VALUES (?, ?, ?, ?)')->execute([$uid, $name, $type, $balance]);
            flash('success', t('added'));
        }
    }
    redirect('accounts.php');
}

$st = db()->prepare('SELECT * FROM accounts WHERE user_id = ? ORDER BY id DESC');
$st->execute([$uid]);
$accounts = $st->fetchAll();
$total = array_sum(array_column($accounts, 'balance'));

$edit = null;
if (isset($_GET['edit'])) {
    foreach ($accounts as $a) {
        if ((int) $a['id'] === (int) $_GET['edit']) { $edit = $a; }
    }
}

page_header('accounts');
page_title(t('accounts'), t('accounts_sub'));
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('total_balance')) ?><span class="stat-ic"><?= icon('wallet') ?></span></div>
        <div class="stat-val num <?= $total < 0 ? 'neg' : '' ?>"><?= e(money($total)) ?></div>
        <div class="stat-note"><?= e(t('across_accounts')) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('accounts')) ?><span class="stat-ic amber"><?= icon('coins') ?></span></div>
        <div class="stat-val"><?= count($accounts) ?></div>
    </div>
</section>

<section class="grid split">
    <div class="card">
        <div class="card-head"><h2><?= e($edit ? t('edit_account') : t('add_account')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
            <div class="field"><label for="name"><?= e(t('name')) ?></label>
                <input type="text" id="name" name="name" maxlength="80" required value="<?= e($edit['name'] ?? '') ?>"></div>
            <div class="field"><label for="type"><?= e(t('type')) ?></label>
                <select id="type" name="type">
                    <?php foreach (ACCOUNT_TYPES as $ty): ?>
                        <option value="<?= e($ty) ?>" <?= ($edit['type'] ?? 'Bank') === $ty ? 'selected' : '' ?>><?= e(t('acc_' . strtolower($ty))) ?></option>
                    <?php endforeach; ?>
                </select></div>
            <div class="field"><label for="balance"><?= e(t('balance')) ?></label>
                <input type="number" id="balance" name="balance" step="0.01" required value="<?= e($edit['balance'] ?? '0') ?>"></div>
            <button class="btn btn-primary btn-block" type="submit"><?= e($edit ? t('save_changes') : t('add_account')) ?></button>
            <?php if ($edit): ?><a class="btn btn-ghost btn-block" style="margin-top:8px" href="accounts.php"><?= e(t('cancel')) ?></a><?php endif; ?>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('accounts')) ?></h2></div>
        <?php if (!$accounts): ?>
            <?php empty_state(t('no_accounts')); ?>
        <?php else: ?>
            <div class="list">
                <?php foreach ($accounts as $a): ?>
                    <div class="item">
                        <div><h4><?= e($a['name']) ?></h4><span class="muted"><?= e(t('acc_' . strtolower($a['type']))) ?></span></div>
                        <div style="display:flex;align-items:center;gap:8px">
                            <strong class="num <?= $a['balance'] < 0 ? 'neg' : '' ?>"><?= e(money($a['balance'])) ?></strong>
                            <a class="btn btn-sm btn-ghost" href="accounts.php?edit=<?= (int) $a['id'] ?>" title="<?= e(t('edit')) ?>" aria-label="<?= e(t('edit')) ?>"><?= icon('pencil') ?></a>
                            <?= delete_button((int) $a['id']) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php page_footer();
