<?php
// Copy this file to config/config.local.php and fill in your real values.
// config.local.php is git-ignored — never commit credentials.
// (Alternatively set WALLETY_DB_HOST / _PORT / _NAME / _USER / _PASS environment variables.)
return [
    'db_host' => 'localhost',
    'db_port' => 3306,
    'db_name' => 'wallety',
    'db_user' => 'root',
    'db_pass' => '',
    'debug'   => false,   // true shows full errors on screen: local development only
];
