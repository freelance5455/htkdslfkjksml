<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        db()->prepare('DELETE FROM debts WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        flash('success', t('deleted'));
    } elseif ($action === 'toggle') {
        db()->prepare("UPDATE debts SET status = IF(status = 'paid', 'unpaid', 'paid') WHERE id = ? AND user_id = ?")->execute([$id, $uid]);
    } elseif ($action === 'save') {
        $person = clean_str($_POST['person_name'] ?? '', 100);
        $amount = to_amount($_POST['amount'] ?? 0);
        $type = in_array($_POST['type'] ?? '', ['borrowed', 'lent'], true) ? $_POST['type'] : 'borrowed';
        $due = valid_date($_POST['due_date'] ?? '') ? $_POST['due_date'] : null;
        $note = clean_str($_POST['note'] ?? '', 500);

        if ($person === '' || $amount <= 0 || $amount > 99999999.99) {
            flash('error', t('err_fill'));
        } else {
            db()->prepare("INSERT INTO debts (user_id, person_name, amount, type, status, due_date, note) VALUES (?, ?, ?, ?, 'unpaid', ?, ?)")
                ->execute([$uid, $person, $amount, $type, $due, $note]);
            flash('success', t('added'));
        }
    }
    redirect('debts.php');
}

$st = db()->prepare("SELECT * FROM debts WHERE user_id = ? ORDER BY status = 'paid', due_date IS NULL, due_date, id DESC");
$st->execute([$uid]);
$debts = $st->fetchAll();

$owe = $owed = 0.0;
foreach ($debts as $d) {
    if ($d['status'] === 'unpaid') {
        if ($d['type'] === 'borrowed') { $owe += $d['amount']; } else { $owed += $d['amount']; }
    }
}
$today = date('Y-m-d');

page_header('debts');
page_title(t('debts'), t('debts_sub'));
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('i_owe')) ?><span class="stat-ic red"><?= icon('trend-dn') ?></span></div>
        <div class="stat-val num neg"><?= e(money($owe)) ?></div>
        <div class="stat-note"><?= e(t('unpaid')) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('owed_to_me')) ?><span class="stat-ic green"><?= icon('trend-up') ?></span></div>
        <div class="stat-val num pos"><?= e(money($owed)) ?></div>
        <div class="stat-note"><?= e(t('unpaid')) ?></div>
    </div>
</section>

<section class="grid split">
    <div class="card">
        <div class="card-head"><h2><?= e(t('add_debt')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <div class="field">
                <span class="label"><?= e(t('type')) ?></span>
                <div class="seg">
                    <label><input type="radio" name="type" value="borrowed" checked><span><?= e(t('borrowed')) ?></span></label>
                    <label><input type="radio" name="type" value="lent"><span><?= e(t('lent')) ?></span></label>
                </div>
            </div>
            <div class="field"><label for="person"><?= e(t('person')) ?></label>
                <input type="text" id="person" name="person_name" maxlength="100" required></div>
            <div class="form-row">
                <div class="field"><label for="amount"><?= e(t('amount')) ?></label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required></div>
                <div class="field"><label for="due"><?= e(t('due_date')) ?></label>
                    <input type="date" id="due" name="due_date"></div>
            </div>
            <div class="field"><label for="note"><?= e(t('note')) ?></label>
                <textarea id="note" name="note" maxlength="500"></textarea></div>
            <button class="btn btn-primary btn-block" type="submit"><?= e(t('add_debt')) ?></button>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('debts')) ?></h2></div>
        <?php if (!$debts): ?>
            <?php empty_state(t('no_debts')); ?>
        <?php else: ?>
            <div class="list">
                <?php foreach ($debts as $d):
                    $paid = $d['status'] === 'paid';
                    $overdue = !$paid && $d['due_date'] && $d['due_date'] < $today; ?>
                    <div class="item <?= $paid ? 'done' : '' ?>">
                        <div>
                            <h4><?= e($d['person_name']) ?></h4>
                            <span class="muted">
                                <?= badge(t($d['type']), $d['type'] === 'lent' ? 'green' : 'red') ?>
                                <?php if ($paid): echo badge(t('paid'), 'gray'); elseif ($overdue): echo badge(t('overdue'), 'red'); endif; ?>
                                <?= $d['due_date'] ? ' ' . e(t('due')) . ' <span class="num">' . e($d['due_date']) . '</span>' : '' ?>
                            </span>
                            <?php if ($d['note']): ?><span class="sub muted" style="display:block;font-size:13px"><?= e($d['note']) ?></span><?php endif; ?>
                        </div>
                        <div style="display:flex;align-items:center;gap:6px">
                            <strong class="num"><?= e(money($d['amount'])) ?></strong>
                            <?= action_button('toggle', (int) $d['id'], $paid ? t('mark_unpaid') : t('mark_paid'), $paid ? '' : 'check', 'btn') ?>
                            <?= delete_button((int) $d['id']) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php page_footer();
