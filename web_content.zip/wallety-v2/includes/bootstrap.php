<?php
/**
 * Wallety bootstrap: session, config, database, i18n, security helpers.
 * Every page starts with: require_once __DIR__ . '/includes/bootstrap.php';
 */

define('ROOT', dirname(__DIR__));
const SUPPORTED_LANGS = ['en', 'fr', 'ar'];
const CURRENCIES = ['USD' => '$', 'EUR' => '€', 'GBP' => '£', 'DZD' => 'DA', 'MAD' => 'MAD', 'TND' => 'DT'];

/* ---------- Session & security headers ---------- */
if (session_status() === PHP_SESSION_NONE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    ini_set('session.use_strict_mode', '1');
    session_set_cookie_params(['path' => '/', 'secure' => $secure, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

/* ---------- Config (config.local.php or WALLETY_* env vars; never committed) ---------- */
function config(string $key, $default = null)
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = ['db_host' => 'localhost', 'db_port' => 3306, 'db_name' => 'wallety',
                'db_user' => 'root', 'db_pass' => '', 'debug' => false];
        $file = ROOT . '/config/config.local.php';
        if (is_file($file)) {
            $cfg = array_merge($cfg, (array) require $file);
        }
        $env = ['db_host' => 'WALLETY_DB_HOST', 'db_port' => 'WALLETY_DB_PORT', 'db_name' => 'WALLETY_DB_NAME',
                'db_user' => 'WALLETY_DB_USER', 'db_pass' => 'WALLETY_DB_PASS'];
        foreach ($env as $k => $name) {
            $v = getenv($name);
            if ($v !== false && $v !== '') {
                $cfg[$k] = $v;
            }
        }
    }
    return $cfg[$key] ?? $default;
}

/* ---------- Database ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', config('db_host'), (int) config('db_port'), config('db_name')),
                config('db_user'),
                config('db_pass'),
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]
            );
        } catch (PDOException $e) {
            fail_gracefully($e);
        }
    }
    return $pdo;
}

function fail_gracefully(Throwable $e): void
{
    error_log('Wallety error: ' . $e->getMessage());
    http_response_code(500);
    echo config('debug') ? '<pre>' . htmlspecialchars((string) $e) . '</pre>' : 'Something went wrong. Please try again later.';
    exit;
}
set_exception_handler('fail_gracefully');

/* ---------- Small helpers ---------- */
function e($v): string
{
    return htmlspecialchars((string) ($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = [$type, $msg];
}

function flash_render(): string
{
    $out = '';
    foreach ($_SESSION['flash'] ?? [] as [$type, $msg]) {
        $out .= '<div class="flash flash-' . e($type) . '" role="status">' . e($msg) . '</div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

function clean_str($v, int $max): string
{
    return mb_substr(trim((string) $v), 0, $max);
}

function to_amount($v): float
{
    return round((float) str_replace(',', '.', trim((string) $v)), 2);
}

function valid_date($s): bool
{
    $d = is_string($s) ? DateTime::createFromFormat('Y-m-d', $s) : false;
    return $d && $d->format('Y-m-d') === $s;
}

function money($n, bool $signed = false): string
{
    $n = (float) $n;
    $cur = $_SESSION['currency'] ?? 'USD';
    $sym = CURRENCIES[$cur] ?? $cur;
    $num = number_format(abs($n), 2);
    $txt = in_array($sym, ['$', '£', '€'], true) ? $sym . $num : $num . ' ' . $sym;
    if ($n < 0) {
        return '−' . $txt;
    }
    return ($signed && $n > 0 ? '+' : '') . $txt;
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

/** Call at the top of every POST handler. */
function csrf_verify(): void
{
    $ok = isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string) $_POST['csrf']);
    if (!$ok) {
        flash('error', t('err_csrf'));
        redirect(basename($_SERVER['SCRIPT_NAME']));
    }
}

/* ---------- Auth & preferences ---------- */
function require_login(): int
{
    if (empty($_SESSION['user_id'])) {
        redirect('index.php');
    }
    return (int) $_SESSION['user_id'];
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['username'] = $user['username'];
    $st = db()->prepare('SELECT lang, currency FROM user_settings WHERE user_id = ?');
    $st->execute([$user['id']]);
    if ($p = $st->fetch()) {
        if (in_array($p['lang'], SUPPORTED_LANGS, true)) {
            $_SESSION['lang'] = $p['lang'];
        }
        $_SESSION['currency'] = isset(CURRENCIES[$p['currency']]) ? $p['currency'] : 'USD';
    } else {
        $_SESSION['currency'] = $_SESSION['currency'] ?? 'USD';
    }
}

function save_prefs(int $uid, string $lang, string $currency): void
{
    $st = db()->prepare(
        'INSERT INTO user_settings (user_id, lang, currency) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE lang = VALUES(lang), currency = VALUES(currency)'
    );
    $st->execute([$uid, $lang, $currency]);
    $_SESSION['lang'] = $lang;
    $_SESSION['currency'] = $currency;
}

/* ---------- i18n ---------- */
if (isset($_GET['lang']) && in_array($_GET['lang'], SUPPORTED_LANGS, true)) {
    $_SESSION['lang'] = $_GET['lang'];
    if (!empty($_SESSION['user_id'])) {
        save_prefs((int) $_SESSION['user_id'], $_GET['lang'], $_SESSION['currency'] ?? 'USD');
    }
    $rest = $_GET;
    unset($rest['lang']);
    redirect(basename($_SERVER['SCRIPT_NAME']) . ($rest ? '?' . http_build_query($rest) : ''));
}

$lang = in_array($_SESSION['lang'] ?? 'en', SUPPORTED_LANGS, true) ? $_SESSION['lang'] : 'en';
$L_EN = require ROOT . '/languages/en.php';
$L = $lang === 'en' ? $L_EN : array_merge($L_EN, require ROOT . "/languages/$lang.php");
$is_rtl = $lang === 'ar';

function t(string $key, ...$args): string
{
    global $L;
    $s = $L[$key] ?? $key;
    return $args ? vsprintf($s, $args) : (string) $s;
}

function months(): array
{
    global $L;
    return $L['months_short'];
}

function month_label(string $ym): string
{
    return months()[(int) substr($ym, 5, 2) - 1] . ' ' . substr($ym, 0, 4);
}

require_once __DIR__ . '/data.php';
require_once __DIR__ . '/layout.php';
