<?php
/** Shared queries used by the dashboard and reports. */

function valid_month($s): bool
{
    return is_string($s) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $s) === 1;
}

/** @return array{0:string,1:string} first day of the month, first day of the next month */
function month_range(string $ym): array
{
    $start = DateTimeImmutable::createFromFormat('!Y-m', $ym);
    return [$start->format('Y-m-d'), $start->modify('+1 month')->format('Y-m-d')];
}

function totals(int $uid, ?string $from = null, ?string $to = null): array
{
    $sql = "SELECT COALESCE(SUM(CASE WHEN type = 'income' THEN amount END), 0) AS income,
                   COALESCE(SUM(CASE WHEN type = 'expense' THEN amount END), 0) AS expense
            FROM transactions WHERE user_id = ?";
    $p = [$uid];
    if ($from) { $sql .= ' AND trans_date >= ?'; $p[] = $from; }
    if ($to)   { $sql .= ' AND trans_date < ?';  $p[] = $to; }
    $st = db()->prepare($sql);
    $st->execute($p);
    $r = $st->fetch();
    $inc = (float) $r['income'];
    $exp = (float) $r['expense'];
    return ['income' => $inc, 'expense' => $exp, 'net' => $inc - $exp];
}

function category_breakdown(int $uid, string $from, string $to): array
{
    $st = db()->prepare(
        "SELECT c.name, SUM(t.amount) AS total
         FROM transactions t LEFT JOIN categories c ON c.id = t.category_id
         WHERE t.user_id = ? AND t.type = 'expense' AND t.trans_date >= ? AND t.trans_date < ?
         GROUP BY c.id, c.name ORDER BY total DESC"
    );
    $st->execute([$uid, $from, $to]);
    $rows = [];
    foreach ($st->fetchAll() as $r) {
        $rows[] = ['name' => $r['name'] ?? t('uncategorized'), 'total' => (float) $r['total']];
    }
    return $rows;
}

/** Last $n calendar months ending at $endYm (oldest first), zero-filled so charts have no gaps. */
function monthly_series(int $uid, int $n = 6, ?string $endYm = null): array
{
    $end = DateTimeImmutable::createFromFormat('!Y-m', $endYm ?: date('Y-m'));
    $start = $end->modify('-' . ($n - 1) . ' months');
    $series = [];
    for ($i = 0; $i < $n; $i++) {
        $ym = $start->modify("+$i months")->format('Y-m');
        $series[$ym] = ['ym' => $ym, 'income' => 0.0, 'expense' => 0.0];
    }
    $st = db()->prepare(
        "SELECT DATE_FORMAT(trans_date, '%Y-%m') AS ym, type, SUM(amount) AS total
         FROM transactions WHERE user_id = ? AND trans_date >= ? AND trans_date < ?
         GROUP BY ym, type"
    );
    $st->execute([$uid, $start->format('Y-m-d'), $end->modify('+1 month')->format('Y-m-d')]);
    foreach ($st->fetchAll() as $r) {
        if (isset($series[$r['ym']])) {
            $series[$r['ym']][$r['type']] = (float) $r['total'];
        }
    }
    return array_values($series);
}

function recent_transactions(int $uid, int $limit = 6): array
{
    $st = db()->prepare(
        'SELECT t.id, t.title, t.type, t.amount, t.trans_date, c.name AS category
         FROM transactions t LEFT JOIN categories c ON c.id = t.category_id
         WHERE t.user_id = ? ORDER BY t.trans_date DESC, t.id DESC LIMIT ' . (int) $limit
    );
    $st->execute([$uid]);
    return $st->fetchAll();
}
