<?php
/** Shared HTML layout + small UI helpers. */

function icon(string $name): string
{
    static $paths = [
        'grid'     => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/>',
        'swap'     => '<path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>',
        'wallet'   => '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
        'coins'    => '<path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
        'target'   => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
        'bell'     => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
        'chart'    => '<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
        'sliders'  => '<path d="M21 4h-7"/><path d="M10 4H3"/><path d="M21 12h-9"/><path d="M8 12H3"/><path d="M21 20h-5"/><path d="M12 20H3"/><path d="M14 2v4"/><path d="M8 10v4"/><path d="M16 18v4"/>',
        'logout'   => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'menu'     => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'moon'     => '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
        'sun'      => '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
        'plus'     => '<path d="M5 12h14M12 5v14"/>',
        'trash'    => '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
        'pencil'   => '<path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
        'check'    => '<path d="M20 6 9 17l-5-5"/>',
        'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
        'trend-up' => '<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
        'trend-dn' => '<path d="m22 17-8.5-8.5-5 5L2 7"/><path d="M16 17h6v-6"/>',
        'piggy'    => '<path d="M19 5c-1.5 0-2.8 1.4-3 2-3.5-1.5-11-.3-11 5 0 1.8 0 3 2 4.5V20h4v-2h3v2h4v-4c1-.5 1.7-1 2-2h2v-4h-2c0-1-.5-1.5-1-2V5Z"/><path d="M2 9v1c0 1.1.9 2 2 2h1"/>',
    ];
    return '<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . ($paths[$name] ?? '') . '</svg>';
}

function nav_items(): array
{
    return [
        'dashboard'    => ['dashboard.php', 'grid'],
        'transactions' => ['transactions.php', 'swap'],
        'accounts'     => ['accounts.php', 'wallet'],
        'debts'        => ['debts.php', 'coins'],
        'goals'        => ['goals.php', 'target'],
        'reminders'    => ['reminders.php', 'bell'],
        'reports'      => ['reports.php', 'chart'],
        'settings'     => ['settings.php', 'sliders'],
    ];
}

function lang_switcher(): string
{
    global $lang;
    $out = '<div class="lang-switch" role="group" aria-label="' . e(t('language')) . '">';
    foreach (SUPPORTED_LANGS as $code) {
        $url = '?' . http_build_query(array_merge($_GET, ['lang' => $code]));
        $out .= '<a href="' . e($url) . '" class="' . ($code === $lang ? 'on' : '') . '" hreflang="' . $code . '">' . strtoupper($code) . '</a>';
    }
    return $out . '</div>';
}

function theme_toggle(): string
{
    return '<button type="button" class="icon-btn" id="themeToggle" aria-label="' . e(t('toggle_theme')) . '">'
        . '<span class="only-light">' . icon('moon') . '</span><span class="only-dark">' . icon('sun') . '</span></button>';
}

function html_head(string $title): void
{
    global $lang, $is_rtl;
    ?>
<!DOCTYPE html>
<html lang="<?= e($lang) ?>" dir="<?= $is_rtl ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · Wallety</title>
    <meta name="color-scheme" content="light dark">
    <meta name="theme-color" content="#2563eb">
    <link rel="manifest" href="manifest.webmanifest">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32.png">
    <link rel="apple-touch-icon" href="assets/icons/apple-touch-icon.png">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="Wallety">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <script>(function(){var t;try{t=localStorage.getItem('wallety-theme')}catch(e){}if(!t){t=window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'}document.documentElement.dataset.theme=t})();</script>
    <link rel="stylesheet" href="assets/css/style.css?v=2">
</head>
<?php
}

/** Opens the authenticated app shell. $current is a nav key. */
function page_header(string $current): void
{
    html_head(t($current));
    $name = $_SESSION['username'] ?? '';
    ?>
<body class="app">
<div class="overlay" data-nav-toggle></div>
<aside class="sidebar" id="sidebar">
    <a class="brand" href="dashboard.php"><span class="brand-mark">W</span><span><strong>Wallety</strong><small><?= e(t('tagline')) ?></small></span></a>
    <nav class="nav" aria-label="Main">
        <?php foreach (nav_items() as $key => [$file, $ic]): ?>
            <a href="<?= e($file) ?>" class="nav-link<?= $key === $current ? ' active' : '' ?>"<?= $key === $current ? ' aria-current="page"' : '' ?>><?= icon($ic) ?><span><?= e(t($key)) ?></span></a>
        <?php endforeach; ?>
    </nav>
    <div class="sidebar-foot">
        <div class="user-chip"><span class="avatar"><?= e(mb_strtoupper(mb_substr($name, 0, 1))) ?></span><span class="user-name"><?= e($name) ?></span></div>
        <form method="post" action="logout.php"><?= csrf_field() ?><button class="nav-link" type="submit"><?= icon('logout') ?><span><?= e(t('logout')) ?></span></button></form>
    </div>
</aside>
<div class="main">
    <header class="topbar">
        <button type="button" class="icon-btn menu-btn" data-nav-toggle aria-label="Menu"><?= icon('menu') ?></button>
        <div class="topbar-actions"><?= lang_switcher() ?><?= theme_toggle() ?></div>
    </header>
    <main class="content">
        <?= flash_render() ?>
<?php
}

/** Closes the app shell. Options: charts (bool), js (inline script string). */
function page_footer(array $o = []): void
{
    ?>
    </main>
    <footer class="footer">Wallety · <?= e(t('developed_by')) ?> Hamitouche Safia Asma</footer>
</div>
<?php if (!empty($o['charts'])): ?><script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script><?php endif; ?>
<script src="assets/js/app.js?v=2"></script>
<?php if (!empty($o['js'])): ?><script><?= $o['js'] ?></script><?php endif; ?>
</body>
</html>
<?php
}

/** Split-screen layout for login / register. */
function auth_header(string $title): void
{
    html_head($title);
    ?>
<body class="auth">
<section class="auth-brand">
    <a class="brand" href="index.php"><span class="brand-mark">W</span><span><strong>Wallety</strong><small><?= e(t('tagline')) ?></small></span></a>
    <div>
        <h1><?= e(t('auth_headline')) ?></h1>
        <p><?= e(t('auth_sub')) ?></p>
        <ul class="auth-points">
            <li><?= icon('check') ?><?= e(t('auth_p1')) ?></li>
            <li><?= icon('check') ?><?= e(t('auth_p2')) ?></li>
            <li><?= icon('check') ?><?= e(t('auth_p3')) ?></li>
        </ul>
    </div>
    <small class="auth-credit"><?= e(t('developed_by')) ?> Hamitouche Safia Asma</small>
</section>
<section class="auth-form">
    <div class="auth-tools"><?= lang_switcher() ?><?= theme_toggle() ?></div>
    <div class="auth-card">
        <?= flash_render() ?>
<?php
}

function auth_footer(): void
{
    ?>
    </div>
</section>
<script src="assets/js/app.js?v=2"></script>
</body>
</html>
<?php
}

/* ---------- Small UI helpers ---------- */

function page_title(string $title, string $sub = '', string $actions = ''): void
{
    echo '<div class="page-head"><div><h1>' . e($title) . '</h1>'
        . ($sub !== '' ? '<p class="muted">' . e($sub) . '</p>' : '')
        . '</div>' . ($actions !== '' ? '<div class="page-actions">' . $actions . '</div>' : '') . '</div>';
}

/** A POST button (with CSRF + optional confirm) for row actions like delete/toggle. */
function action_button(string $action, int $id, string $label, string $icon = '', string $class = 'btn-ghost', string $confirm = ''): string
{
    return '<form method="post" class="inline"' . ($confirm !== '' ? ' data-confirm="' . e($confirm) . '"' : '') . '>'
        . csrf_field()
        . '<input type="hidden" name="id" value="' . $id . '">'
        . '<button type="submit" name="action" value="' . e($action) . '" class="btn btn-sm ' . e($class) . '" title="' . e($label) . '" aria-label="' . e($label) . '">'
        . ($icon !== '' ? icon($icon) : '') . ($icon === '' ? e($label) : '') . '</button></form>';
}

function delete_button(int $id): string
{
    return action_button('delete', $id, t('delete'), 'trash', 'btn-ghost btn-danger-text', t('confirm_delete'));
}

function badge(string $text, string $tone = 'gray'): string
{
    return '<span class="badge b-' . e($tone) . '">' . e($text) . '</span>';
}

function empty_state(string $text, string $cta = ''): void
{
    echo '<div class="empty"><p>' . e($text) . '</p>' . $cta . '</div>';
}

/** Query string for links, merging overrides into the current GET params (drops empty values). */
function qs(array $override = []): string
{
    $p = array_filter(array_merge($_GET, $override), fn($v) => $v !== '' && $v !== null);
    return $p ? '?' . http_build_query($p) : '?';
}
