<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        db()->prepare('DELETE FROM goals WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        flash('success', t('deleted'));
    } elseif ($action === 'complete') {
        db()->prepare("UPDATE goals SET status = 'completed' WHERE id = ? AND user_id = ?")->execute([$id, $uid]);
    } elseif ($action === 'contribute') {
        $amt = to_amount($_POST['amount'] ?? 0);
        if ($amt > 0 && $amt <= 99999999.99) {
            // status must come first: MySQL evaluates SET assignments left to right,
            // so current_amount would already include $amt if it were assigned before.
            db()->prepare("UPDATE goals SET status = IF(current_amount + ? >= target_amount, 'completed', status),
                           current_amount = current_amount + ? WHERE id = ? AND user_id = ?")
                ->execute([$amt, $amt, $id, $uid]);
            flash('success', t('updated'));
        } else {
            flash('error', t('err_fill'));
        }
    } elseif ($action === 'save') {
        $title = clean_str($_POST['title'] ?? '', 120);
        $target = to_amount($_POST['target_amount'] ?? 0);
        $saved = max(0, to_amount($_POST['current_amount'] ?? 0));
        $deadline = valid_date($_POST['deadline'] ?? '') ? $_POST['deadline'] : null;

        if ($title === '' || $target <= 0 || $target > 99999999.99) {
            flash('error', t('err_fill'));
        } else {
            db()->prepare('INSERT INTO goals (user_id, title, target_amount, current_amount, deadline, status) VALUES (?, ?, ?, ?, ?, ?)')
                ->execute([$uid, $title, $target, $saved, $deadline, $saved >= $target ? 'completed' : 'active']);
            flash('success', t('added'));
        }
    }
    redirect('goals.php');
}

$st = db()->prepare("SELECT * FROM goals WHERE user_id = ? ORDER BY status = 'completed', id DESC");
$st->execute([$uid]);
$goals = $st->fetchAll();
$target = array_sum(array_column($goals, 'target_amount'));
$saved = array_sum(array_column($goals, 'current_amount'));

page_header('goals');
page_title(t('goals'), t('goals_sub'));
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('total_target')) ?><span class="stat-ic"><?= icon('target') ?></span></div>
        <div class="stat-val num"><?= e(money($target)) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('total_saved')) ?><span class="stat-ic green"><?= icon('piggy') ?></span></div>
        <div class="stat-val num pos"><?= e(money($saved)) ?></div>
    </div>
</section>

<section class="grid split">
    <div class="card">
        <div class="card-head"><h2><?= e(t('add_goal')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <div class="field"><label for="title"><?= e(t('title')) ?></label>
                <input type="text" id="title" name="title" maxlength="120" required></div>
            <div class="form-row">
                <div class="field"><label for="target"><?= e(t('target_amount')) ?></label>
                    <input type="number" id="target" name="target_amount" step="0.01" min="0.01" required></div>
                <div class="field"><label for="saved"><?= e(t('already_saved')) ?></label>
                    <input type="number" id="saved" name="current_amount" step="0.01" min="0" value="0"></div>
            </div>
            <div class="field"><label for="deadline"><?= e(t('deadline')) ?></label>
                <input type="date" id="deadline" name="deadline"></div>
            <button class="btn btn-primary btn-block" type="submit"><?= e(t('add_goal')) ?></button>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('goals')) ?></h2></div>
        <?php if (!$goals): ?>
            <?php empty_state(t('no_goals')); ?>
        <?php else: ?>
            <div class="list">
                <?php foreach ($goals as $g):
                    $done = $g['status'] === 'completed';
                    $pct = $g['target_amount'] > 0 ? min(100, (int) floor($g['current_amount'] / $g['target_amount'] * 100)) : 0; ?>
                    <div class="item" style="display:block">
                        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap">
                            <div>
                                <h4><?= e($g['title']) ?> <?= $done ? badge(t('completed'), 'green') : '' ?></h4>
                                <span class="muted num"><?= e(money($g['current_amount'])) ?> / <?= e(money($g['target_amount'])) ?>
                                    <?= $g['deadline'] ? ' · ' . e(t('deadline')) . ' ' . e($g['deadline']) : '' ?></span>
                            </div>
                            <strong class="num"><?= $pct ?>%</strong>
                        </div>
                        <div class="progress <?= $done ? 'ok' : '' ?>" style="margin:12px 0" role="progressbar" aria-valuenow="<?= $pct ?>" aria-valuemin="0" aria-valuemax="100"><i style="width:<?= $pct ?>%"></i></div>
                        <div style="display:flex;gap:8px;justify-content:space-between;flex-wrap:wrap">
                            <?php if (!$done): ?>
                                <form method="post" style="display:flex;gap:6px">
                                    <?= csrf_field() ?><input type="hidden" name="action" value="contribute"><input type="hidden" name="id" value="<?= (int) $g['id'] ?>">
                                    <input type="number" name="amount" step="0.01" min="0.01" required placeholder="<?= e(t('amount')) ?>" style="width:120px" aria-label="<?= e(t('amount')) ?>">
                                    <button class="btn btn-sm" type="submit"><?= icon('plus') ?><?= e(t('add_funds')) ?></button>
                                </form>
                            <?php else: ?><span></span><?php endif; ?>
                            <span>
                                <?= !$done ? action_button('complete', (int) $g['id'], t('mark_done'), 'check') : '' ?>
                                <?= delete_button((int) $g['id']) ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php page_footer();
