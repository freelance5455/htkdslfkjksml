<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

/** Returns the id of the user's category with this name, creating it if needed. */
function find_or_create_category(int $uid, string $name, string $type): int
{
    $st = db()->prepare('SELECT id FROM categories WHERE user_id = ? AND name = ? LIMIT 1');
    $st->execute([$uid, $name]);
    if ($id = $st->fetchColumn()) {
        return (int) $id;
    }
    db()->prepare('INSERT INTO categories (user_id, name, type) VALUES (?, ?, ?)')->execute([$uid, $name, $type]);
    return (int) db()->lastInsertId();
}

/* ---------- Actions (POST) ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);

    if ($action === 'delete') {
        db()->prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        flash('success', t('deleted'));
        redirect('transactions.php');
    }

    if ($action === 'save') {
        $title = clean_str($_POST['title'] ?? '', 150);
        $cat = clean_str($_POST['category'] ?? '', 50);
        $type = $_POST['type'] ?? '';
        $amount = to_amount($_POST['amount'] ?? 0);
        $date = $_POST['trans_date'] ?? '';

        if ($title === '' || !in_array($type, ['income', 'expense'], true) || $amount <= 0 || $amount > 99999999.99 || !valid_date($date)) {
            flash('error', t('err_fill'));
            redirect('transactions.php' . ($id ? '?edit=' . $id : ''));
        }
        $cid = $cat !== '' ? find_or_create_category($uid, $cat, $type) : null;

        if ($id) {
            db()->prepare('UPDATE transactions SET title = ?, category_id = ?, type = ?, amount = ?, trans_date = ? WHERE id = ? AND user_id = ?')
                ->execute([$title, $cid, $type, $amount, $date, $id, $uid]);
            flash('success', t('updated'));
        } else {
            db()->prepare('INSERT INTO transactions (user_id, title, category_id, type, amount, trans_date) VALUES (?, ?, ?, ?, ?, ?)')
                ->execute([$uid, $title, $cid, $type, $amount, $date]);
            flash('success', t('added'));
        }
        redirect('transactions.php');
    }
    redirect('transactions.php');
}

/* ---------- Filters ---------- */
$typeF = in_array($_GET['type'] ?? '', ['income', 'expense'], true) ? $_GET['type'] : '';
$monthF = valid_month($_GET['month'] ?? '') ? $_GET['month'] : '';
$q = clean_str($_GET['q'] ?? '', 100);

$where = 't.user_id = ?';
$params = [$uid];
if ($typeF) { $where .= ' AND t.type = ?'; $params[] = $typeF; }
if ($monthF) {
    [$from, $to] = month_range($monthF);
    $where .= ' AND t.trans_date >= ? AND t.trans_date < ?';
    array_push($params, $from, $to);
}
if ($q !== '') {
    $like = '%' . addcslashes($q, '%_\\') . '%';
    $where .= ' AND (t.title LIKE ? OR c.name LIKE ?)';
    array_push($params, $like, $like);
}
$base = "FROM transactions t LEFT JOIN categories c ON c.id = t.category_id WHERE $where";

/* ---------- CSV export (respects current filters) ---------- */
if (isset($_GET['export'])) {
    $st = db()->prepare("SELECT t.trans_date, t.title, c.name AS category, t.type, t.amount $base ORDER BY t.trans_date DESC, t.id DESC");
    $st->execute($params);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="wallety-transactions-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel reads accents/Arabic correctly
    fputcsv($out, ['date', 'title', 'category', 'type', 'amount']);
    foreach ($st as $r) {
        $row = [$r['trans_date'], $r['title'], $r['category'] ?? '', $r['type'], $r['amount']];
        // Neutralise spreadsheet formula injection
        $row = array_map(fn($v) => preg_match('/^[=+\-@\t\r]/', (string) $v) && !is_numeric($v) ? "'" . $v : $v, $row);
        fputcsv($out, $row);
    }
    exit;
}

/* ---------- Data ---------- */
$st = db()->prepare("SELECT COUNT(*) AS n,
    COALESCE(SUM(CASE WHEN t.type='income' THEN t.amount END),0) AS inc,
    COALESCE(SUM(CASE WHEN t.type='expense' THEN t.amount END),0) AS exp $base");
$st->execute($params);
$sum = $st->fetch();
$perPage = 20;
$pages = max(1, (int) ceil($sum['n'] / $perPage));
$page = min($pages, max(1, (int) ($_GET['page'] ?? 1)));

$st = db()->prepare("SELECT t.id, t.title, t.type, t.amount, t.trans_date, c.name AS category $base
                     ORDER BY t.trans_date DESC, t.id DESC LIMIT $perPage OFFSET " . (($page - 1) * $perPage));
$st->execute($params);
$rows = $st->fetchAll();

$edit = null;
if (isset($_GET['edit'])) {
    $st = db()->prepare('SELECT t.*, c.name AS category FROM transactions t LEFT JOIN categories c ON c.id = t.category_id WHERE t.id = ? AND t.user_id = ?');
    $st->execute([(int) $_GET['edit'], $uid]);
    $edit = $st->fetch() ?: null;
}
$st = db()->prepare('SELECT name FROM categories WHERE user_id = ? ORDER BY name');
$st->execute([$uid]);
$catNames = $st->fetchAll(PDO::FETCH_COLUMN);

$curType = $edit['type'] ?? 'expense';
$filtered = $typeF || $monthF || $q !== '';

page_header('transactions');
page_title(t('transactions'), t('transactions_sub'),
    '<a class="btn" href="' . e(qs(['export' => 1, 'page' => null])) . '">' . icon('download') . e(t('export_csv')) . '</a>');
?>
<section class="grid split">
    <div class="card">
        <div class="card-head"><h2><?= e($edit ? t('edit_transaction') : t('add_transaction')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= (int) ($edit['id'] ?? 0) ?>">
            <div class="field">
                <span class="label"><?= e(t('type')) ?></span>
                <div class="seg">
                    <label><input type="radio" name="type" value="expense" <?= $curType === 'expense' ? 'checked' : '' ?>><span><?= e(t('expense')) ?></span></label>
                    <label><input type="radio" name="type" value="income" <?= $curType === 'income' ? 'checked' : '' ?>><span><?= e(t('income')) ?></span></label>
                </div>
            </div>
            <div class="field">
                <label for="title"><?= e(t('title')) ?></label>
                <input type="text" id="title" name="title" maxlength="150" required value="<?= e($edit['title'] ?? '') ?>">
            </div>
            <div class="field">
                <label for="category"><?= e(t('category')) ?></label>
                <input type="text" id="category" name="category" maxlength="50" list="cats" value="<?= e($edit['category'] ?? '') ?>">
                <datalist id="cats"><?php foreach ($catNames as $n): ?><option value="<?= e($n) ?>"><?php endforeach; ?></datalist>
            </div>
            <div class="form-row">
                <div class="field">
                    <label for="amount"><?= e(t('amount')) ?></label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" required value="<?= e($edit['amount'] ?? '') ?>">
                </div>
                <div class="field">
                    <label for="trans_date"><?= e(t('date')) ?></label>
                    <input type="date" id="trans_date" name="trans_date" required value="<?= e($edit['trans_date'] ?? date('Y-m-d')) ?>">
                </div>
            </div>
            <button class="btn btn-primary btn-block" type="submit"><?= e($edit ? t('save_changes') : t('add_transaction')) ?></button>
            <?php if ($edit): ?><a class="btn btn-ghost btn-block" style="margin-top:8px" href="transactions.php"><?= e(t('cancel')) ?></a><?php endif; ?>
        </form>
    </div>

    <div class="card">
        <form class="filters" method="get">
            <input type="text" name="q" value="<?= e($q) ?>" placeholder="<?= e(t('search')) ?>…" aria-label="<?= e(t('search')) ?>">
            <select name="type" aria-label="<?= e(t('type')) ?>">
                <option value=""><?= e(t('all_types')) ?></option>
                <option value="income" <?= $typeF === 'income' ? 'selected' : '' ?>><?= e(t('income')) ?></option>
                <option value="expense" <?= $typeF === 'expense' ? 'selected' : '' ?>><?= e(t('expense')) ?></option>
            </select>
            <input type="month" name="month" value="<?= e($monthF) ?>" aria-label="<?= e(t('month')) ?>">
            <button class="btn btn-primary btn-sm" type="submit"><?= e(t('filter')) ?></button>
            <?php if ($filtered): ?><a class="btn btn-ghost btn-sm" href="transactions.php"><?= e(t('clear')) ?></a><?php endif; ?>
        </form>

        <div class="card-head">
            <h2><?= e(t('n_transactions', $sum['n'])) ?></h2>
            <span class="muted num"><span class="pos"><?= e(money($sum['inc'])) ?></span> · <span class="neg"><?= e(money($sum['exp'])) ?></span></span>
        </div>

        <?php if (!$rows): ?>
            <?php empty_state($filtered ? t('no_results') : t('no_transactions')); ?>
        <?php else: ?>
            <div class="table-wrap"><table>
                <thead><tr><th><?= e(t('date')) ?></th><th><?= e(t('title')) ?></th><th class="end"><?= e(t('amount')) ?></th><th></th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): $inc = $r['type'] === 'income'; ?>
                    <tr>
                        <td class="num"><?= e($r['trans_date']) ?></td>
                        <td><?= e($r['title']) ?><span class="sub"><?= e($r['category'] ?? t('uncategorized')) ?></span></td>
                        <td class="end num <?= $inc ? 'pos' : 'neg' ?>"><?= e(money($inc ? $r['amount'] : -$r['amount'], true)) ?></td>
                        <td><div class="row-actions">
                            <a class="btn btn-sm btn-ghost" href="transactions.php?edit=<?= (int) $r['id'] ?>" title="<?= e(t('edit')) ?>" aria-label="<?= e(t('edit')) ?>"><?= icon('pencil') ?></a>
                            <?= delete_button((int) $r['id']) ?>
                        </div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>

            <?php if ($pages > 1): ?>
                <nav class="pager" aria-label="Pagination">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <?= $i === $page ? '<span class="on">' . $i . '</span>' : '<a href="' . e(qs(['page' => $i, 'edit' => null])) . '">' . $i . '</a>' ?>
                    <?php endfor; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php page_footer();
