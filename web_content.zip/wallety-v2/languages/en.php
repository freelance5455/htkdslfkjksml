<?php
// English is the fallback language: any key missing from fr.php / ar.php falls back to this file.
// Strings with %s are filled via t('key', $value). Use %% for a literal percent sign.
return [
    'tagline' => 'Smart money manager',
    'developed_by' => 'Developed by',
    'toggle_theme' => 'Toggle dark mode',
    'months_short' => ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],

    // Navigation
    'dashboard' => 'Dashboard', 'transactions' => 'Transactions', 'accounts' => 'Accounts', 'debts' => 'Debts',
    'goals' => 'Goals', 'reminders' => 'Reminders', 'reports' => 'Reports', 'settings' => 'Settings', 'logout' => 'Log out',

    // Auth
    'sign_in' => 'Sign in', 'sign_in_sub' => 'Enter your details to access your account.',
    'create_account' => 'Create account', 'register_sub' => 'It takes less than a minute.',
    'username' => 'Username', 'username_or_email' => 'Username or email', 'email' => 'Email', 'password' => 'Password',
    'confirm_password' => 'Confirm password', 'password_hint' => 'At least 8 characters.',
    'new_here' => 'New to Wallety?', 'have_account' => 'Already have an account?',
    'welcome_msg' => 'Welcome to Wallety, %s!',
    'auth_headline' => 'Manage money with clarity and confidence.',
    'auth_sub' => 'Spending, accounts, goals and debts in one clean workspace.',
    'auth_p1' => 'Track income and expenses in seconds', 'auth_p2' => 'See where your money goes with clear reports',
    'auth_p3' => 'Set savings goals and never miss a payment',

    // Errors & feedback
    'err_csrf' => 'Your session expired. Please try again.', 'err_fill' => 'Please fill in all fields correctly.',
    'err_login_empty' => 'Please enter your username/email and password.', 'err_login_invalid' => 'Invalid username/email or password.',
    'err_throttle' => 'Too many attempts. Please wait a minute and try again.',
    'err_username' => 'Username must be 3–30 characters (letters, numbers, . _ -).', 'err_email' => 'Please enter a valid email address.',
    'err_password_len' => 'Password must be at least 8 characters.', 'err_password_match' => 'Passwords do not match.',
    'err_password_wrong' => 'Incorrect password.', 'err_exists' => 'That username or email is already taken.',
    'err_generic' => 'Something went wrong. Please try again.',
    'added' => 'Added successfully.', 'updated' => 'Saved successfully.', 'deleted' => 'Deleted.',
    'confirm_delete' => 'Delete this item? This cannot be undone.',

    // Common
    'add' => 'Add', 'edit' => 'Edit', 'delete' => 'Delete', 'cancel' => 'Cancel', 'save_changes' => 'Save changes',
    'search' => 'Search', 'filter' => 'Filter', 'clear' => 'Clear', 'view_all' => 'View all',
    'title' => 'Title', 'name' => 'Name', 'type' => 'Type', 'amount' => 'Amount', 'date' => 'Date', 'note' => 'Note',
    'category' => 'Category', 'balance' => 'Balance', 'month' => 'Month', 'uncategorized' => 'Uncategorized',
    'income' => 'Income', 'expense' => 'Expense', 'net' => 'Net', 'all_types' => 'All types', 'all_time' => 'All time',
    'this_month' => 'This month', 'today' => 'Today', 'done' => 'Done', 'paid' => 'Paid', 'unpaid' => 'Unpaid',
    'pending' => 'Pending', 'completed' => 'Completed', 'overdue' => 'Overdue', 'due' => 'due',

    // Dashboard
    'welcome_back' => 'Welcome back, %s', 'financial_summary' => "Here's your financial summary.",
    'total_balance' => 'Total balance', 'income_this_month' => 'Income this month', 'expenses_this_month' => 'Expenses this month',
    'savings_rate' => 'Savings rate', 'vs_last_month' => '%s vs last month', 'no_prev_data' => 'No data for last month',
    'recent_transactions' => 'Recent transactions', 'spending_by_category' => 'Spending by category',
    'no_expenses_month' => 'No expenses recorded this month.',

    // Transactions
    'transactions_sub' => 'Add and manage your income and expenses.', 'add_transaction' => 'Add transaction',
    'edit_transaction' => 'Edit transaction', 'add_first_transaction' => 'Add your first transaction',
    'no_transactions' => 'No transactions yet.', 'no_results' => 'No transactions match your filters.',
    'n_transactions' => '%s transactions', 'export_csv' => 'Export CSV',

    // Accounts
    'accounts_sub' => 'Cash, bank accounts, savings and wallets in one place.', 'add_account' => 'Add account',
    'edit_account' => 'Edit account', 'no_accounts' => 'No accounts yet.', 'across_accounts' => 'Across all your accounts',
    'acc_cash' => 'Cash', 'acc_bank' => 'Bank', 'acc_savings' => 'Savings', 'acc_wallet' => 'Wallet', 'acc_other' => 'Other',

    // Debts
    'debts_sub' => 'Track money you owe and money owed to you.', 'add_debt' => 'Add debt', 'no_debts' => 'No debts recorded.',
    'i_owe' => 'I owe', 'owed_to_me' => 'Owed to me', 'borrowed' => 'Borrowed', 'lent' => 'Lent', 'person' => 'Person',
    'due_date' => 'Due date', 'mark_paid' => 'Mark as paid', 'mark_unpaid' => 'Mark as unpaid',

    // Goals
    'goals_sub' => 'Set savings goals and track your progress.', 'add_goal' => 'Add goal', 'no_goals' => 'No goals yet. Set your first one!',
    'total_target' => 'Total target', 'total_saved' => 'Total saved', 'target_amount' => 'Target amount',
    'already_saved' => 'Already saved', 'deadline' => 'Deadline', 'add_funds' => 'Add funds', 'mark_done' => 'Mark as done',

    // Reminders
    'reminders_sub' => 'Never miss a bill, subscription or payment.', 'add_reminder' => 'Add reminder',
    'no_reminders' => 'No reminders yet.', 'due_today' => 'Due today', 'mark_pending' => 'Mark as pending',

    // Reports
    'reports_sub' => 'Understand where your money comes from and where it goes.', 'monthly_summary' => 'Monthly summary',
    'last_6_months' => 'Last 6 months', 'smart_insights' => 'Smart insights', 'budget_health' => 'Budget health',
    'insight_no_income' => 'No income recorded this month.', 'insight_great' => 'Great! You saved %s%% of your income.',
    'insight_ok' => 'You saved %s%% of your income. Aim for 20%% or more.', 'insight_over' => 'You spent more than you earned this month.',
    'next_month_prediction' => 'Next month forecast', 'forecast_text' => 'Expected spending, based on recent months:',
    'not_enough_data' => 'Not enough history yet.', 'top_category' => 'Top spending category',
    'low_balance_alert' => 'Low balance alert', 'category_details' => 'Category details',
    'prev_month_net' => 'Previous month: %s',

    // Settings
    'manage_settings' => 'Manage your profile, preferences and security.', 'profile' => 'Profile', 'preferences' => 'Preferences',
    'language' => 'Language', 'currency' => 'Currency', 'currency_hint' => 'Changes how amounts are displayed; it does not convert values.',
    'change_password' => 'Change password', 'current_password' => 'Current password', 'new_password' => 'New password',
    'password_changed' => 'Password changed.', 'danger' => 'Danger zone',
    'delete_warning' => 'Permanently delete all your transactions, accounts, debts, goals and reminders. Your login stays active.',
    'confirm_with_password' => 'Confirm with your password', 'delete_all' => 'Delete all my data',
    'confirm_wipe' => 'Delete ALL your financial data? This cannot be undone.', 'data_deleted' => 'All your financial data has been deleted.',
];
