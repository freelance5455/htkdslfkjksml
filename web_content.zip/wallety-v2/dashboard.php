<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

$all = totals($uid);
[$from, $to] = month_range(date('Y-m'));
$month = totals($uid, $from, $to);
[$pFrom, $pTo] = month_range(date('Y-m', strtotime('first day of last month')));
$prev = totals($uid, $pFrom, $pTo);
$recent = recent_transactions($uid, 6);
$cats = category_breakdown($uid, $from, $to);

$saveRate = $month['income'] > 0 ? round(($month['income'] - $month['expense']) / $month['income'] * 100) : null;

/** "+12% vs last month" style note */
function delta_note(float $now, float $before): string
{
    if ($before <= 0) {
        return t('no_prev_data');
    }
    $d = round(($now - $before) / $before * 100);
    return t('vs_last_month', ($d > 0 ? '+' : '') . $d . '%');
}

page_header('dashboard');
page_title(
    t('welcome_back', $_SESSION['username']),
    t('financial_summary'),
    '<a class="btn btn-primary" href="transactions.php">' . icon('plus') . e(t('add_transaction')) . '</a>'
);
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('total_balance')) ?><span class="stat-ic"><?= icon('wallet') ?></span></div>
        <div class="stat-val num <?= $all['net'] < 0 ? 'neg' : '' ?>"><?= e(money($all['net'])) ?></div>
        <div class="stat-note"><?= e(t('all_time')) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('income_this_month')) ?><span class="stat-ic green"><?= icon('trend-up') ?></span></div>
        <div class="stat-val num pos"><?= e(money($month['income'])) ?></div>
        <div class="stat-note"><?= e(delta_note($month['income'], $prev['income'])) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('expenses_this_month')) ?><span class="stat-ic red"><?= icon('trend-dn') ?></span></div>
        <div class="stat-val num neg"><?= e(money($month['expense'])) ?></div>
        <div class="stat-note"><?= e(delta_note($month['expense'], $prev['expense'])) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('savings_rate')) ?><span class="stat-ic amber"><?= icon('piggy') ?></span></div>
        <div class="stat-val num"><?= $saveRate === null ? '—' : e($saveRate . '%') ?></div>
        <div class="stat-note"><?= e(t('this_month')) ?></div>
    </div>
</section>

<section class="grid cols-wide">
    <div class="card">
        <div class="card-head"><h2><?= e(t('recent_transactions')) ?></h2><a href="transactions.php"><?= e(t('view_all')) ?> →</a></div>
        <?php if (!$recent): ?>
            <?php empty_state(t('no_transactions'), '<a class="btn btn-primary btn-sm" href="transactions.php">' . e(t('add_first_transaction')) . '</a>'); ?>
        <?php else: ?>
            <div class="table-wrap"><table>
                <thead><tr><th><?= e(t('title')) ?></th><th><?= e(t('date')) ?></th><th class="end"><?= e(t('amount')) ?></th></tr></thead>
                <tbody>
                <?php foreach ($recent as $r): $inc = $r['type'] === 'income'; ?>
                    <tr>
                        <td><?= e($r['title']) ?><span class="sub"><?= e($r['category'] ?? t('uncategorized')) ?></span></td>
                        <td class="num"><?= e($r['trans_date']) ?></td>
                        <td class="end num <?= $inc ? 'pos' : 'neg' ?>"><?= e(money($inc ? $r['amount'] : -$r['amount'], true)) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('spending_by_category')) ?></h2><span class="muted"><?= e(t('this_month')) ?></span></div>
        <?php if (!$cats): ?>
            <?php empty_state(t('no_expenses_month')); ?>
        <?php else: ?>
            <div class="chart"><canvas id="catChart" role="img" aria-label="<?= e(t('spending_by_category')) ?>"></canvas></div>
        <?php endif; ?>
    </div>
</section>
<?php
page_footer([
    'charts' => (bool) $cats,
    'js' => $cats ? 'wDoughnut("catChart",' . json_encode(array_column($cats, 'name'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE)
        . ',' . json_encode(array_column($cats, 'total')) . ');' : '',
]);
