(function () {
    'use strict';
    var root = document.documentElement;

    /* Register the service worker (enables install-to-home-screen + offline page) */
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('sw.js').catch(function () { /* unsupported / blocked */ });
        });
    }

    /* Theme toggle (preference kept in localStorage; initial value is set inline in <head> to avoid a flash) */
    var toggle = document.getElementById('themeToggle');
    if (toggle) {
        toggle.addEventListener('click', function () {
            var next = root.dataset.theme === 'dark' ? 'light' : 'dark';
            root.dataset.theme = next;
            try { localStorage.setItem('wallety-theme', next); } catch (e) { /* private mode */ }
        });
    }

    /* Mobile sidebar */
    document.querySelectorAll('[data-nav-toggle]').forEach(function (el) {
        el.addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') document.body.classList.remove('nav-open');
    });

    /* Confirm before submitting forms that carry data-confirm (deletes etc.) */
    document.addEventListener('submit', function (e) {
        var msg = e.target.getAttribute && e.target.getAttribute('data-confirm');
        if (msg && !window.confirm(msg)) e.preventDefault();
    });

    /* Chart helpers (only active on pages that load Chart.js) */
    var PALETTE = ['#2563eb', '#06b6d4', '#8b5cf6', '#f59e0b', '#ec4899', '#10b981', '#ef4444', '#64748b'];

    function css(name) { return getComputedStyle(root).getPropertyValue(name).trim(); }

    function setup() {
        Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
        Chart.defaults.color = css('--muted');
        Chart.defaults.borderColor = css('--border');
    }

    window.wBar = function (id, labels, series) {
        var el = document.getElementById(id);
        if (!el || typeof Chart === 'undefined') return;
        setup();
        new Chart(el, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: series.map(function (s) {
                    return { label: s.label, data: s.data, backgroundColor: s.color, borderRadius: 6, maxBarThickness: 28 };
                })
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } },
                scales: { x: { grid: { display: false } }, y: { beginAtZero: true } }
            }
        });
    };

    window.wDoughnut = function (id, labels, data) {
        var el = document.getElementById(id);
        if (!el || typeof Chart === 'undefined') return;
        setup();
        new Chart(el, {
            type: 'doughnut',
            data: { labels: labels, datasets: [{ data: data, backgroundColor: PALETTE, borderColor: css('--surface'), borderWidth: 3 }] },
            options: {
                responsive: true, maintainAspectRatio: false, cutout: '64%',
                plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } }
            }
        });
    };
})();
