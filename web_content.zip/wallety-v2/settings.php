<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

$st = db()->prepare('SELECT username, email, password FROM users WHERE id = ?');
$st->execute([$uid]);
$user = $st->fetch();
if (!$user) {            // account vanished (e.g. deleted in DB) – end the session
    $_SESSION = [];
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'profile') {
        $name = clean_str($_POST['username'] ?? '', 30);
        $email = clean_str($_POST['email'] ?? '', 100);
        if (!preg_match('/^[\p{L}\p{N}_.\-]{3,30}$/u', $name)) {
            flash('error', t('err_username'));
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', t('err_email'));
        } else {
            $st = db()->prepare('SELECT id FROM users WHERE (username = ? OR email = ?) AND id <> ? LIMIT 1');
            $st->execute([$name, $email, $uid]);
            if ($st->fetch()) {
                flash('error', t('err_exists'));
            } else {
                db()->prepare('UPDATE users SET username = ?, email = ? WHERE id = ?')->execute([$name, $email, $uid]);
                $_SESSION['username'] = $name;
                flash('success', t('updated'));
            }
        }
    } elseif ($action === 'password') {
        $curPw = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        if (!password_verify($curPw, $user['password'])) {
            flash('error', t('err_password_wrong'));
        } elseif (mb_strlen($new) < 8) {
            flash('error', t('err_password_len'));
        } elseif ($new !== (string) ($_POST['confirm_password'] ?? '')) {
            flash('error', t('err_password_match'));
        } else {
            db()->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
            session_regenerate_id(true);
            flash('success', t('password_changed'));
        }
    } elseif ($action === 'prefs') {
        $l = in_array($_POST['lang'] ?? '', SUPPORTED_LANGS, true) ? $_POST['lang'] : 'en';
        $c = isset(CURRENCIES[$_POST['currency'] ?? '']) ? $_POST['currency'] : 'USD';
        save_prefs($uid, $l, $c);
        flash('success', t('updated'));
        redirect('settings.php');
    } elseif ($action === 'wipe') {
        if (!password_verify((string) ($_POST['confirm_pw'] ?? ''), $user['password'])) {
            flash('error', t('err_password_wrong'));
        } else {
            try {
                db()->beginTransaction();
                foreach (['transactions', 'categories', 'accounts', 'debts', 'goals', 'reminders'] as $table) {
                    db()->prepare("DELETE FROM $table WHERE user_id = ?")->execute([$uid]);
                }
                db()->commit();
                flash('success', t('data_deleted'));
            } catch (Throwable $e) {
                if (db()->inTransaction()) { db()->rollBack(); }
                error_log('Wallety wipe failed: ' . $e->getMessage());
                flash('error', t('err_generic'));
            }
        }
    }
    redirect('settings.php');
}

$curCur = $_SESSION['currency'] ?? 'USD';

page_header('settings');
page_title(t('settings'), t('manage_settings'));
?>
<section class="grid cols-2">
    <div class="card">
        <div class="card-head"><h2><?= e(t('profile')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="profile">
            <div class="field"><label for="username"><?= e(t('username')) ?></label>
                <input type="text" id="username" name="username" value="<?= e($user['username']) ?>" required maxlength="30"></div>
            <div class="field"><label for="email"><?= e(t('email')) ?></label>
                <input type="email" id="email" name="email" value="<?= e($user['email']) ?>" required></div>
            <button class="btn btn-primary" type="submit"><?= e(t('save_changes')) ?></button>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('preferences')) ?></h2></div>
        <form method="post">
            <?= csrf_field() ?><input type="hidden" name="action" value="prefs">
            <div class="field"><label for="lang"><?= e(t('language')) ?></label>
                <select id="lang" name="lang">
                    <option value="en" <?= $lang === 'en' ? 'selected' : '' ?>>English</option>
                    <option value="fr" <?= $lang === 'fr' ? 'selected' : '' ?>>Français</option>
                    <option value="ar" <?= $lang === 'ar' ? 'selected' : '' ?>>العربية</option>
                </select></div>
            <div class="field"><label for="currency"><?= e(t('currency')) ?></label>
                <select id="currency" name="currency">
                    <?php foreach (CURRENCIES as $code => $sym): ?>
                        <option value="<?= e($code) ?>" <?= $curCur === $code ? 'selected' : '' ?>><?= e($code . ' (' . $sym . ')') ?></option>
                    <?php endforeach; ?>
                </select>
                <small><?= e(t('currency_hint')) ?></small></div>
            <button class="btn btn-primary" type="submit"><?= e(t('save_changes')) ?></button>
        </form>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('change_password')) ?></h2></div>
        <form method="post" autocomplete="off">
            <?= csrf_field() ?><input type="hidden" name="action" value="password">
            <div class="field"><label for="cp"><?= e(t('current_password')) ?></label>
                <input type="password" id="cp" name="current_password" required autocomplete="current-password"></div>
            <div class="form-row">
                <div class="field"><label for="np"><?= e(t('new_password')) ?></label>
                    <input type="password" id="np" name="new_password" required minlength="8" autocomplete="new-password"></div>
                <div class="field"><label for="cn"><?= e(t('confirm_password')) ?></label>
                    <input type="password" id="cn" name="confirm_password" required minlength="8" autocomplete="new-password"></div>
            </div>
            <button class="btn btn-primary" type="submit"><?= e(t('change_password')) ?></button>
        </form>
    </div>

    <div class="card danger-zone">
        <div class="card-head"><h2><?= e(t('danger')) ?></h2></div>
        <p class="muted" style="margin-bottom:14px"><?= e(t('delete_warning')) ?></p>
        <form method="post" data-confirm="<?= e(t('confirm_wipe')) ?>">
            <?= csrf_field() ?><input type="hidden" name="action" value="wipe">
            <div class="field"><label for="cpw"><?= e(t('confirm_with_password')) ?></label>
                <input type="password" id="cpw" name="confirm_pw" required autocomplete="current-password"></div>
            <button class="btn btn-danger" type="submit"><?= icon('trash') ?><?= e(t('delete_all')) ?></button>
        </form>
    </div>
</section>
<?php page_footer();
