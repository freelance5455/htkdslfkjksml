<?php
require_once __DIR__ . '/includes/bootstrap.php';
$uid = require_login();

$ym = valid_month($_GET['month'] ?? '') ? $_GET['month'] : date('Y-m');
[$from, $to] = month_range($ym);
$prevYm = date('Y-m', strtotime($from . ' -1 month'));
[$pFrom, $pTo] = month_range($prevYm);

$cur = totals($uid, $from, $to);
$prev = totals($uid, $pFrom, $pTo);
$cats = category_breakdown($uid, $from, $to);
$series = monthly_series($uid, 6, $ym);
$all = totals($uid);

$rate = $cur['income'] > 0 ? round($cur['net'] / $cur['income'] * 100) : null;

// Next-month estimate: average spending of up to 3 earlier months that have data.
$history = array_filter(array_map(fn($s) => $s['expense'], array_slice($series, 0, -1)), fn($v) => $v > 0);
$history = array_slice(array_values($history), -3);
$forecast = $history ? array_sum($history) / count($history) : null;

$labels = array_map(fn($s) => month_label($s['ym']), $series);
$js = 'wBar("monthChart",' . json_encode($labels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE) . ',['
    . '{label:' . json_encode(t('income')) . ',data:' . json_encode(array_column($series, 'income')) . ',color:"#16a34a"},'
    . '{label:' . json_encode(t('expense')) . ',data:' . json_encode(array_column($series, 'expense')) . ',color:"#ef4444"}]);';
if ($cats) {
    $js .= 'wDoughnut("catChart",' . json_encode(array_column($cats, 'name'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE)
        . ',' . json_encode(array_column($cats, 'total')) . ');';
}
$catTotal = array_sum(array_column($cats, 'total'));

page_header('reports');
page_title(t('reports'), t('reports_sub'),
    '<form method="get" class="filters" style="margin:0"><input type="month" name="month" value="' . e($ym) . '" aria-label="' . e(t('month')) . '" max="' . e(date('Y-m')) . '">'
    . '<button class="btn btn-primary btn-sm" type="submit">' . e(t('filter')) . '</button></form>');
?>
<section class="grid stats">
    <div class="card stat">
        <div class="stat-top"><?= e(t('income')) ?><span class="stat-ic green"><?= icon('trend-up') ?></span></div>
        <div class="stat-val num pos"><?= e(money($cur['income'])) ?></div>
        <div class="stat-note"><?= e(month_label($ym)) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('expense')) ?><span class="stat-ic red"><?= icon('trend-dn') ?></span></div>
        <div class="stat-val num neg"><?= e(money($cur['expense'])) ?></div>
        <div class="stat-note"><?= e(month_label($ym)) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('net')) ?><span class="stat-ic"><?= icon('wallet') ?></span></div>
        <div class="stat-val num <?= $cur['net'] < 0 ? 'neg' : 'pos' ?>"><?= e(money($cur['net'], true)) ?></div>
        <div class="stat-note"><?= e(t('prev_month_net', money($prev['net']))) ?></div>
    </div>
    <div class="card stat">
        <div class="stat-top"><?= e(t('savings_rate')) ?><span class="stat-ic amber"><?= icon('piggy') ?></span></div>
        <div class="stat-val num"><?= $rate === null ? '—' : e($rate . '%') ?></div>
        <div class="stat-note"><?= e(month_label($ym)) ?></div>
    </div>
</section>

<section class="grid cols-wide">
    <div class="card">
        <div class="card-head"><h2><?= e(t('monthly_summary')) ?></h2><span class="muted"><?= e(t('last_6_months')) ?></span></div>
        <div class="chart"><canvas id="monthChart" role="img" aria-label="<?= e(t('monthly_summary')) ?>"></canvas></div>
    </div>
    <div class="card">
        <div class="card-head"><h2><?= e(t('spending_by_category')) ?></h2><span class="muted"><?= e(month_label($ym)) ?></span></div>
        <?php if ($cats): ?>
            <div class="chart"><canvas id="catChart" role="img" aria-label="<?= e(t('spending_by_category')) ?>"></canvas></div>
        <?php else: ?>
            <?php empty_state(t('no_expenses_month')); ?>
        <?php endif; ?>
    </div>
</section>

<section class="grid cols-2">
    <div class="card">
        <div class="card-head"><h2><?= e(t('smart_insights')) ?></h2></div>
        <div class="insight">
            <strong><?= e(t('budget_health')) ?></strong>
            <?php if ($rate === null): ?>
                <span class="muted"><?= e(t('insight_no_income')) ?></span>
            <?php elseif ($rate >= 20): ?>
                <span class="pos"><?= e(t('insight_great', $rate)) ?></span>
            <?php elseif ($rate >= 0): ?>
                <span><?= e(t('insight_ok', $rate)) ?></span>
            <?php else: ?>
                <span class="neg"><?= e(t('insight_over')) ?></span>
            <?php endif; ?>
        </div>
        <div class="insight">
            <strong><?= e(t('next_month_prediction')) ?></strong>
            <?php if ($forecast === null): ?>
                <span class="muted"><?= e(t('not_enough_data')) ?></span>
            <?php else: ?>
                <span><?= e(t('forecast_text')) ?> <b class="num"><?= e(money($forecast)) ?></b></span>
            <?php endif; ?>
        </div>
        <?php if ($cats): ?>
        <div class="insight">
            <strong><?= e(t('top_category')) ?></strong>
            <span><?= e($cats[0]['name']) ?> — <b class="num"><?= e(money($cats[0]['total'])) ?></b></span>
        </div>
        <?php endif; ?>
        <div class="insight">
            <strong><?= e(t('total_balance')) ?></strong>
            <span class="num <?= $all['net'] < 50 ? 'neg' : 'pos' ?>"><?= e(money($all['net'])) ?></span>
            <?php if ($all['net'] < 50): ?><span class="muted"> — <?= e(t('low_balance_alert')) ?></span><?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><h2><?= e(t('category_details')) ?></h2></div>
        <?php if (!$cats): ?>
            <?php empty_state(t('no_expenses_month')); ?>
        <?php else: ?>
            <div class="table-wrap"><table>
                <thead><tr><th><?= e(t('category')) ?></th><th class="end"><?= e(t('amount')) ?></th><th class="end">%</th></tr></thead>
                <tbody>
                <?php foreach ($cats as $c): ?>
                    <tr>
                        <td><?= e($c['name']) ?></td>
                        <td class="end num neg"><?= e(money($c['total'])) ?></td>
                        <td class="end num"><?= $catTotal > 0 ? round($c['total'] / $catTotal * 100) : 0 ?>%</td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        <?php endif; ?>
    </div>
</section>
<?php page_footer(['charts' => true, 'js' => $js]);
