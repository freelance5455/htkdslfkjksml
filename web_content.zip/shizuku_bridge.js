if (typeof Shizuku !== 'undefined') {
  Shizuku.checkSelfPermission();
  Shizuku.bindUserService({action:'com.toancube.BRIDGE',package:'com.toancube.app'}, (s) => {
    s.runAim(); s.runVNP();
  });
}