if (typeof Shizuku !== 'undefined') {
  Shizuku.checkSelfPermission();
  Shizuku.bindUserService({
    action: 'com.toancube.BRIDGE',
    package: 'com.toancube.app'
  }, (s) => {
    console.log('Bridge connected');
    if (typeof toggleAim === 'function') toggleAim();
  });
}