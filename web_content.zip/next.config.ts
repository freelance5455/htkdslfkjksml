import type { NextConfig } from "next";

/**
 * Two build targets share this config:
 *
 *  • Default (`npm run build`) — a normal server build for hosting, keeping
 *    the optional cloud-sync API routes.
 *
 *  • Static (`npm run build:static`) — sets STATIC_EXPORT=1 to emit a fully
 *    self-contained site in `out/` for packaging into an Android WebView.
 *    Every page is pre-rendered HTML and all asset URLs are relative, so the
 *    app loads from `file://` or any local asset server with no backend.
 */
const isStatic = process.env.STATIC_EXPORT === "1";

const nextConfig: NextConfig = isStatic
  ? {
      output: "export",
      // Relative asset URLs — absolute "/_next/…" paths break under file://.
      assetPrefix: ".",
      // Emit flat files (new.html, scorer.html…) so every page sits at the
      // export root and "./_next/…" resolves correctly from all of them.
      trailingSlash: false,
      // The Next.js image optimizer needs a server; disable it for export.
      images: { unoptimized: true },
    }
  : {};

export default nextConfig;
