import type { NextConfig } from "next";

// STATIC_EXPORT=1 npm run build  →  emits a pure static bundle in ./out
// (index.html + relative ./_next assets) with zero Node.js server code,
// ready for Android WebView / Capacitor APK wrapping or any static host.
const isStaticExport = process.env.STATIC_EXPORT === "1";

const nextConfig: NextConfig = isStaticExport
  ? {
      output: "export",
      assetPrefix: "./",
      images: { unoptimized: true },
      trailingSlash: true,
    }
  : {};

export default nextConfig;
