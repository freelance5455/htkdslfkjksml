import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    return {
      // The storefront + admin are plain HTML/CSS/JS files in /public.
      beforeFiles: [
        { source: "/", destination: "/index.html" },
        { source: "/admin", destination: "/admin.html" },
      ],
      afterFiles: [],
      fallback: [],
    };
  },
};

export default nextConfig;
