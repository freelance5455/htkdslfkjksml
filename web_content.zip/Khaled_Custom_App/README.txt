Khaled — النسخة الشخصية

بيانات الدخول:
Username: khaled
Password: khaled

التشغيل:
1. فك ضغط Khaled_Custom_App.zip.
2. اترك index.html و khaled_profile.png داخل نفس المجلد.
3. افتح index.html بمتصفح Chrome على أندرويد.

تم وضع صورتك كصورة ملف شخصي وتغيير عنوان Regedit FIXA إلى Khaled.
ملاحظة: تسجيل الدخول تجريبي محلي وليس حماية حقيقية، والمفاتيح تغيّر حالتها داخل الواجهة فقط ولا تعدّل ملفات اللعبة.
