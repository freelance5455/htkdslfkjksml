package com.wnt.cheats

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import android.text.InputType
import java.security.SecureRandom

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 8, 12)
    private val panel = Color.rgb(35, 20, 27)
    private val red = Color.rgb(235, 35, 52)
    private val ownerKey = "NOVAX-OWNER-2026-7F3A-9K2M"
    private val generatorKey = "a4636812-8995-4b9d-af02-82d182a88c97"
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var tab = "Otimização"
    private var unlocked = false
    private var generatorUnlocked = false
    private var precisionUnlocked = false
    private var overlayView: TextView? = null
    private var overlayWindow: WindowManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(16,16,16,16) }
        setContentView(root)
        renderLogin()
    }

    private fun txt(s:String, size:Float=14f, color:Int=Color.WHITE)=TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(4,8,4,8) }
    private fun btn(s:String, action:()->Unit)=Button(this).apply { text=s; setOnClickListener { action() } }
    private fun card()=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(14,10,14,10) }
    private fun addCard(c:View, parent:LinearLayout=body) { val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12; parent.addView(c,lp) }

    private fun renderLogin() {
        root.removeAllViews()
        root.addView(txt("novaX",34f,red).apply { typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setPadding(0,30,0,0) })
        root.addView(txt("PAINEL DE FERRAMENTAS",12f,0xFFD8AAB2.toInt()).apply { gravity=Gravity.CENTER; setPadding(0,0,0,30) })
        val c=card()
        c.addView(txt("Entrar no novaX",21f)); c.addView(txt("Digite sua chave permanente de acesso ao painel." ,13f,0xFFC8B9BE.toInt()))
        val key=EditText(this).apply { hint="Sua key de acesso"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFFBBAAB0.toInt()); inputType=InputType.TYPE_CLASS_TEXT }
        c.addView(key)
        c.addView(btn("ENTRAR NO PAINEL") { if(key.text.toString().trim()==ownerKey) { unlocked=true; renderMain() } else Toast.makeText(this,"Key inválida",Toast.LENGTH_SHORT).show() })
        c.addView(txt("Acesso do proprietário • versão local",11f,0xFFBBAAB0.toInt()))
        addCard(c,root)
        root.addView(txt("A otimização usa ações permitidas pelo Android. Não promete FPS extra nem modifica o Free Fire.",12f,0xFFBBAAB0.toInt()))
    }

    private fun renderMain() {
        root.removeAllViews()
        root.addView(txt("novaX",28f,red).apply { typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER })
        root.addView(txt("Otimização • Precison • Gerador",12f,0xFFD8AAB2.toInt()).apply { gravity=Gravity.CENTER })
        val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("Otimização","Precison","Gerador","Sobre").forEach { t -> tabs.addView(Button(this).apply { text=t; textSize=10f; setOnClickListener { tab=t; renderTab() } },LinearLayout.LayoutParams(0,-2,1f)) }
        root.addView(tabs)
        val scroll=ScrollView(this); body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,12,0,0) }; scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        renderTab()
    }

    private fun renderTab() {
        body.removeAllViews()
        when(tab) {
            "Otimização" -> {
                addCard(card().apply {
                    addView(txt("OTIMIZAÇÃO FLUTUANTE",18f)); addView(txt("Abra um botão flutuante com atalhos reais para configurações do Android. O sistema não permite que um app comum encerre à força todos os outros apps ou aumente o limite de FPS do jogo." ,13f,0xFFD2C3C8.toInt()))
                    addView(btn("ATIVAR BOTÃO FLUTUANTE") { enableOverlay() })
                    addView(btn("Verificar Shizuku") { val ok=try { rikka.shizuku.Shizuku.pingBinder() } catch (_:Exception) { false }; Toast.makeText(this@MainActivity,if(ok) "Shizuku conectado" else "Abra Shizuku e autorize o novaX",Toast.LENGTH_LONG).show() })
                    addView(btn("Abrir configurações de bateria") { openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) })
                    addView(btn("Abrir informações dos aplicativos") { openSettings(Intent(Settings.ACTION_APPLICATION_SETTINGS)) })
                    addView(btn("Abrir configurações de tela") { openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS)) })
                    addView(btn("Abrir uso de dados / internet") { openSettings(Intent(Settings.ACTION_DATA_USAGE_SETTINGS)) })
                })
            }
            "Precison" -> addCard(card().apply {
                addView(txt("PRECISON • PERFIL DE MIRA",18f)); addView(txt("Perfil de recomendações sem hack ou injeção no Free Fire." ,13f,0xFFD2C3C8.toInt()))
                addView(btn(if(precisionUnlocked) "Perfil ativado nesta sessão" else "Ativar recomendações") { precisionUnlocked=true; renderTab() })
                if(precisionUnlocked) addView(txt("• Teste sensibilidade em passos pequenos.\n• Use a maior taxa de atualização disponível.\n• Feche gravação de tela e downloads antes de jogar.\n• Prefira conexão estável e aproxime-se do roteador.\n• Nenhum perfil consegue garantir menos ping ou mudar fisicamente o touch."))
                addView(btn("Configurações de tela") { openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS)) })
            })
            "Gerador" -> addCard(card().apply {
                addView(txt("GERADOR PERSONALIZADO",18f)); addView(txt("Acesso anunciado: R$ 30. A chave do comprador é uma validação local, não comprova pagamento online." ,13f,0xFFD2C3C8.toInt()))
                val key=EditText(this@MainActivity).apply { hint="Digite a key comprada"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFFBBAAB0.toInt()) }; addView(key)
                addView(btn("VALIDAR KEY DO GERADOR") { if(key.text.toString().trim()==generatorKey) { generatorUnlocked=true; renderTab() } else Toast.makeText(this@MainActivity,"Key do gerador inválida",Toast.LENGTH_SHORT).show() })
                if(generatorUnlocked) {
                    val name=EditText(this@MainActivity).apply { hint="Nome personalizado do comprador"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(0xFFBBAAB0.toInt()) }
                    val length=EditText(this@MainActivity).apply { hint="Tamanho (8 a 32)"; inputType=InputType.TYPE_CLASS_NUMBER; setText("16"); setTextColor(Color.WHITE) }
                    addView(name); addView(length)
                    addView(btn("GERAR SENHA") { val n=(length.text.toString().toIntOrNull()?:16).coerceIn(8,32); val chars="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#%*+-_"; val r=SecureRandom(); val pass=(1..n).map{chars[r.nextInt(chars.length)]}.joinToString(""); val result="novaX | ${name.text.toString().ifBlank { "Comprador" }}\nSenha gerada: $pass"; val clip=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; clip.setPrimaryClip(ClipData.newPlainText("Senha novaX",pass)); AlertDialog.Builder(this@MainActivity).setTitle("Senha gerada").setMessage(result).setPositiveButton("OK",null).show() })
                }
            })
            else -> addCard(card().apply { addView(txt("novaX • v1.1",18f)); addView(txt("Painel Android com atalhos de sistema e sobreposição opcional. A key do proprietário está embutida no código e pode ser extraída do APK; não é autenticação segura para distribuição comercial." ,13f,0xFFD2C3C8.toInt())) })
        }
    }

    private fun openSettings(intent:Intent) { try { startActivity(intent) } catch (_:Exception) { Toast.makeText(this,"Essa configuração não está disponível neste Android",Toast.LENGTH_SHORT).show() } }

    private fun enableOverlay() {
        if(Build.VERSION.SDK_INT>=23 && !Settings.canDrawOverlays(this)) {
            val i=Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")); startActivity(i)
            Toast.makeText(this,"Autorize 'Exibir sobre outros apps' e toque novamente no botão",Toast.LENGTH_LONG).show(); return
        }
        if(overlayView!=null) { Toast.makeText(this,"Botão flutuante já está ativo",Toast.LENGTH_SHORT).show(); return }
        try {
            val wm=getSystemService(WINDOW_SERVICE) as WindowManager; overlayWindow=wm
            val v=TextView(this).apply { text="novaX ⚡"; textSize=14f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setBackgroundColor(red); setPadding(18,14,18,14); gravity=Gravity.CENTER; setOnClickListener { showOverlayMenu() } }
            val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
            val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=12; y=180 }
            wm.addView(v,lp); overlayView=v
            Toast.makeText(this,"Botão novaX flutuante ativado",Toast.LENGTH_SHORT).show()
        } catch(e:Exception) { Toast.makeText(this,"Não foi possível criar a sobreposição: ${e.message}",Toast.LENGTH_LONG).show() }
    }

    private fun showOverlayMenu() {
        val options=arrayOf("Bateria","Aplicativos","Tela","Internet","Remover botão flutuante")
        AlertDialog.Builder(this).setTitle("novaX • Otimização").setItems(options) { _,which -> when(which) {
            0 -> openSettings(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            1 -> openSettings(Intent(Settings.ACTION_APPLICATION_SETTINGS))
            2 -> openSettings(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            3 -> openSettings(Intent(Settings.ACTION_DATA_USAGE_SETTINGS))
            4 -> removeOverlay()
        } }.show()
    }
    private fun removeOverlay() { try { overlayView?.let { overlayWindow?.removeView(it) } } catch (_:Exception) {}; overlayView=null; overlayWindow=null }
    override fun onDestroy() { removeOverlay(); super.onDestroy() }
}
