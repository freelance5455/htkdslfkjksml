# novaX Android project v1.1

Projeto-fonte Android/Kotlin destinado a Android 12 e dispositivos como Moto G22. Inclui tela local de acesso do proprietário, aba de gerador com a chave de demonstração fornecida, perfil Precison de recomendações e botão flutuante de atalhos para configurações do Android.

## Key permanente local do proprietário
`NOVAX-OWNER-2026-7F3A-9K2M`

## Key informada para o gerador
`a4636812-8995-4b9d-af02-82d182a88c97`

**Limitações importantes:** as keys são verificadas localmente e podem ser extraídas do APK; não são adequadas para validar pagamentos nem proteger um produto comercial. Para venda real, use validação em servidor e keys individuais. A sobreposição flutuante requer autorização Android em “Exibir sobre outros apps” e fornece atalhos reais para configurações, não uma promessa de FPS maior. O app não força parada de outros apps, não injeta código no Free Fire e não modifica o jogo.

Para gerar APK, abra a pasta no Android Studio e compile com Android SDK/Gradle compatíveis. Este ambiente não possui Gradle instalado, então o APK não foi compilado/testado aqui.
