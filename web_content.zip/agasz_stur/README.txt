AGASZ STUR — WEB APP + ANDROID WRAPPER SOURCE

Isi:
- Website responsif dan PWA, bisa di-host di Netlify / Vercel / GitHub Pages.
- Data harga, tabungan, dan transaksi disimpan lokal di browser/perangkat (localStorage).
- Link setiap komponen membuka tautan Shopee yang diberikan.
- Bisa dipasang dari Chrome Android: buka website -> menu titik tiga -> Install app / Tambahkan ke layar utama.

Untuk APK Android:
1. Install Node.js dan Android Studio.
2. Buat proyek Capacitor:
   npm create @capacitor/app
3. Salin index.html, style.css, app.js, manifest.webmanifest, sw.js ke folder www proyek Capacitor.
4. Jalankan:
   npm install @capacitor/android
   npx cap add android
   npx cap sync android
   npx cap open android
5. Di Android Studio pilih Build > Generate Signed Bundle / APK > APK.

Catatan penting:
- APK belum dikompilasi/ditandatangani karena membutuhkan Android SDK, konfigurasi package ID, dan signing key milik pemilik aplikasi.
- Harga belum diisi karena harga Shopee dapat berubah dan belum dikonfirmasi. Masukkan harga aktual di kolom setiap komponen.
- Ini tahap 1: aplikasi tracker tabungan dan arus kas lokal, belum memiliki akun cloud/sinkronisasi antarperangkat.


UPDATE CHECKLIST GARASI:
- Centang "Tandai sudah dibeli" pada komponen yang sudah kamu beli.
- Gunakan filter SEMUA / BELUM / SUDAH untuk menyaring daftar.
- Progres GARASI CHECKPOINT akan menghitung jumlah komponen yang sudah dibeli.
- Status checklist tersimpan otomatis di browser/perangkat yang digunakan.
