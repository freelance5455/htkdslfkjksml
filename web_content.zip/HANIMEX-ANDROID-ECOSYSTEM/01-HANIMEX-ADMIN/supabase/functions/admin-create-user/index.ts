import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":Deno.env.get("APP_ORIGIN")??"https://supportsales.netlify.app","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});
 if(req.method!=="POST")return new Response("Method not allowed",{status:405,headers:cors});
 const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
 const auth=req.headers.get("Authorization")??"";const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
 const {data:{user:actor},error:authError}=await userClient.auth.getUser();if(authError||!actor)return new Response("Unauthorized",{status:401,headers:cors});
 const admin=createClient(url,service);const {data:profile}=await admin.from("hanimex_profiles").select("role,is_active").eq("user_id",actor.id).maybeSingle();
 if(!profile||profile.role!=="admin"||!profile.is_active)return new Response("Forbidden",{status:403,headers:cors});
 const b=await req.json().catch(()=>null);if(!b||typeof b.email!=="string"||typeof b.password!=="string"||typeof b.display_name!=="string"||typeof b.department_id!=="string")return new Response("Invalid input",{status:400,headers:cors});
 if(b.password.length<12||b.password.length>128)return new Response("Password must be 12-128 characters",{status:400,headers:cors});
 const {data:created,error:createError}=await admin.auth.admin.createUser({email:b.email,password:b.password,email_confirm:false,user_metadata:{name:b.display_name}});if(createError||!created.user)return new Response("Could not create account",{status:400,headers:cors});
 const {error:profileError}=await admin.from("hanimex_profiles").update({username:String(b.username??"").toLowerCase(),display_name:b.display_name,role:"staff",department_id:b.department_id,permissions:b.permissions??{},phone:String(b.phone??""),is_active:true,must_change_password:true}).eq("user_id",created.user.id);
 if(profileError){await admin.auth.admin.deleteUser(created.user.id);return new Response("Could not configure employee profile",{status:500,headers:cors});}
 await admin.from("hanimex_audit_log").insert({actor_id:actor.id,action:"employee_created",entity_type:"profile",entity_id:created.user.id,details:{department_id:b.department_id}});
 return Response.json({user_id:created.user.id,status:"created"},{headers:cors});
});
