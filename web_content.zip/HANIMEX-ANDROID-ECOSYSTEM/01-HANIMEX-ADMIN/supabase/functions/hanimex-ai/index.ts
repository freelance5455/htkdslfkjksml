import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":Deno.env.get("APP_ORIGIN")??"https://supportsales.netlify.app","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Vary":"Origin"};
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:cors});if(req.method!=="POST")return new Response("Method not allowed",{status:405,headers:cors});
 const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,key=Deno.env.get("OPENAI_API_KEY");if(!key)return new Response("AI service is not configured",{status:503,headers:cors});
 const auth=req.headers.get("Authorization")??"";const client=createClient(url,anon,{global:{headers:{Authorization:auth}}});const {data:{user},error}=await client.auth.getUser();if(error||!user)return new Response("Unauthorized",{status:401,headers:cors});
 const {data:allowed}=await client.rpc("hanimex_has_permission",{p_permission:"ai.use"});if(!allowed)return new Response("Forbidden",{status:403,headers:cors});
 const b=await req.json().catch(()=>null),input=typeof b?.input==="string"?b.input.slice(0,12000):"";if(!input)return new Response("Missing input",{status:400,headers:cors});
 const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model:Deno.env.get("OPENAI_MODEL")??"gpt-5-mini",input:[{role:"user",content:input}],max_output_tokens:1200})});if(!r.ok)return new Response("AI provider request failed",{status:502,headers:cors});
 const d=await r.json(),output=(d.output??[]).flatMap((x:any)=>x.content??[]).filter((x:any)=>x.type==="output_text").map((x:any)=>x.text).join("\n");return Response.json({output},{headers:cors});
});
