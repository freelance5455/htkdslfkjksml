import { mkdir, copyFile } from 'node:fs/promises';
import { dirname } from 'node:path';
const files = [
  ['node_modules/xlsx/dist/xlsx.full.min.js', 'www/vendor/xlsx.full.min.js'],
  ['node_modules/mammoth/mammoth.browser.min.js', 'www/vendor/mammoth.browser.min.js'],
  ['node_modules/pdfjs-dist/legacy/build/pdf.min.js', 'www/vendor/pdf.min.js'],
  ['node_modules/pdfjs-dist/legacy/build/pdf.worker.min.js', 'www/vendor/pdf.worker.min.js'],
  ['node_modules/jszip/dist/jszip.min.js', 'www/vendor/jszip.min.js']
];
for (const [src, dst] of files) {
  await mkdir(dirname(dst), { recursive: true });
  await copyFile(src, dst);
  console.log(`Copied ${src} -> ${dst}`);
}
