# HANIMEX Android — تعليمات رفع وبناء APK

هذه حزمة **مصدر تطبيق Android مبني على Capacitor** وتضم واجهة HANIMEX وملفات إعداد المشروع وسير عمل GitHub Actions لبناء APK تلقائياً. هذه ليست APK جاهزة للتثبيت بعد.

## مهم قبل الرفع

لا ترفع ملف ZIP نفسه إلى المستودع إذا كنت تريد تشغيل البناء التلقائي. فك ضغط الملف أولاً، ثم ارفع **محتويات مجلد `HANIMEX-APK-Project`** إلى جذر المستودع `-HANIMEX-Android` مع الحفاظ على مجلد `.github/workflows`.

## البناء التلقائي

بعد رفع الملفات إلى فرع `main`:
1. افتح تبويب **Actions** في GitHub.
2. اختر **Build HANIMEX Android APK**.
3. عند أول رفع، يبدأ البناء تلقائياً. ويمكنك لاحقاً الضغط على **Run workflow**.
4. افتح عملية البناء الناجحة ثم قسم **Artifacts**.
5. نزّل `HANIMEX-Android-APK`، وفك ضغطه لتحصل على `app-debug.apk`.

## البناء اليدوي على كمبيوتر

المتطلبات: Node.js 22، Java 21، Android SDK.

```bash
npm install
npx cap add android
npm run android:sync
cd android
./gradlew assembleDebug
```

الناتج:
`android/app/build/outputs/apk/debug/app-debug.apk`

## حدود النسخة الحالية

- تتضمن واجهة الويب المضمنة في `www/index.html` وتغليف Android عبر Capacitor.
- حفظ بيانات الواجهة المحلية يعتمد على تخزين الجهاز؛ لا يعني ذلك وجود مزامنة سحابية بين الأجهزة.
- ربط Supabase/OAuth ومفاتيح الخدمات الخارجية لا يُفعّل تلقائياً بهذه الحزمة. لا تضع مفاتيح سرية داخل التطبيق.
- APK لا يصبح جاهزاً إلا بعد نجاح GitHub Actions أو البناء اليدوي واختباره على جهاز Android.
