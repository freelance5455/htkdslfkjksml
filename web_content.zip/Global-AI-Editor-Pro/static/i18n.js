'use strict';
/* ===================================================================
   Translations (fa / en) + language switching (RTL / LTR)
   =================================================================== */
const I18N = {
  fa: {
    app_title: 'استودیو ادیتور', app_sub: 'عکس و ویدیو',
    nav_photo: 'ادیتور عکس', nav_video: 'ادیتور ویدیو', lang_btn: 'English',
    empty_title: 'یک عکس را اینجا بکشید یا باز کنید', empty_sub: 'یا یک بوم خالی بسازید',
    empty_open: 'باز کردن عکس', empty_new: 'بوم جدید',
    v_empty_title: 'ویدیو یا عکس اضافه کنید', v_empty_sub: 'فایل‌ها را بکشید و رها کنید یا دکمه را بزنید', v_empty_add: 'افزودن ویدیو / عکس',
    tl_video: 'ویدیو', tl_text: 'متن', tl_music: 'موزیک',

    nav_ai: 'هوش مصنوعی',
    ai_img_title: '✦ استودیوی تصویر', ai_img_sub: 'با توضیح متنی، تصویر بساز و مستقیم در ادیتور عکس باز کن.',
    ai_prompt: 'تصویر را توصیف کن', ai_prompt_ph: 'ویلای مدرن آرام کنار دریاچه در غروب طلایی…',
    ai_size: 'قالب تصویر', ai_size_sq: 'مربع · ۱۰۲۴ × ۱۰۲۴', ai_size_land: 'افقی · ۱۵۳۶ × ۱۰۲۴', ai_size_port: 'عمودی · ۱۰۲۴ × ۱۵۳۶',
    ai_img_btn: 'تولید تصویر',
    ai_aud_title: '♫ استودیوی صدا', ai_aud_sub: 'متن را به صدای گفتاری تبدیل کن و روی خط زمان ویدیو بگذار.',
    ai_text: 'متن برای خواندن', ai_text_ph: 'متنی که می‌خواهی شنیده شود…', ai_voice: 'صدا', ai_style: 'سبک بیان (اختیاری)', ai_style_ph: 'گرم، آرام و واضح…',
    ai_aud_btn: 'تولید صدا',
    ai_working: 'در حال انجام… ممکن است کمی طول بکشد.', ai_done: 'انجام شد!', ai_failed: 'درخواست ناموفق بود: ',
    ai_prompt_req: 'لطفاً ابتدا تصویر را توصیف کن.', ai_text_req: 'لطفاً ابتدا متن را وارد کن.',
    ai_checking: 'در حال بررسی تنظیمات سرور…', ai_configured: 'سرور فعال است و کلید هوش مصنوعی تنظیم شده.',
    ai_not_configured: 'سرور فعال است، اما کلید API تنظیم نشده. مقدار OPENAI_API_KEY را در فایل .env سرور وارد کن.',
    ai_offline: 'اتصال به سرور برقرار نشد. سرور را اجرا و صفحه را دوباره بارگذاری کن.',
    ai_file_mode: 'این بخش به سرور نیاز دارد. برنامه را با uvicorn اجرا کن و از آدرس http://127.0.0.1:8000 باز کن (ادیتورهای عکس و ویدیو بدون سرور هم کار می‌کنند).',
    ai_hist_title: 'فعالیت‌های اخیر', ai_hist_sub: 'آخرین درخواست‌های ثبت‌شده در سرور.', ai_refresh: 'به‌روزرسانی سابقه',
    ai_no_hist: 'هنوز فعالیتی ثبت نشده.', ai_hist_fail: 'دریافت سابقه ناموفق بود.', ai_kind_image: 'تصویر', ai_kind_audio: 'صدا',
    ai_to_photo: 'ارسال به ادیتور عکس', ai_to_video: 'ارسال به ادیتور ویدیو', ai_download: 'دریافت فایل',
    ai_sent_photo: 'تصویر به ادیتور عکس اضافه شد.', ai_sent_video: 'به ادیتور ویدیو اضافه شد.',
    ai_footer: 'نسخه آغازین • کلید API فقط روی سرور می‌ماند • پیش از انتشار عمومی، ورود امن، پرداخت و محدودیت مصرف اضافه شود.',
    flat_need: 'برای ادغام، حداقل دو لایه لازم است.', v_select_first: 'ابتدا یک مورد را روی خط زمان انتخاب کنید.',
    act_undo: 'بازگشت (Ctrl+Z)', act_redo: 'جلو (Ctrl+Y)', act_new: 'جدید', act_open: 'باز کردن', act_export: 'خروجی', act_save: 'ذخیره',
    act_zoomout: 'کوچک‌نمایی', act_zoomin: 'بزرگ‌نمایی', act_fit: 'اندازه صفحه',
    act_rotl: 'چرخش ۹۰° به چپ', act_rotr: 'چرخش ۹۰° به راست', act_fliph: 'قرینه افقی', act_flipv: 'قرینه عمودی',
    act_resize: 'تغییر اندازه تصویر', act_flatten: 'ادغام همه لایه‌ها',
    act_apply: 'اعمال', act_cancel: 'انصراف', act_create: 'ساختن', act_autobg: 'حذف خودکار پس‌زمینه',

    tool_move: 'جابه‌جایی', tool_hand: 'دست', tool_crop: 'برش', tool_brush: 'قلم', tool_eraser: 'پاک‌کن',
    tool_magic: 'پاک‌کن پس‌زمینه', tool_text: 'متن', tool_mask: 'ماسک',
    hint_move: 'لایه را بکشید. گوشه‌ها برای تغییر اندازه، دایره بالا برای چرخش (با Shift گام ۱۵ درجه).',
    hint_hand: 'برای جابه‌جایی در تصویر بکشید. با Ctrl و چرخ ماوس زوم کنید.',
    hint_text: 'روی تصویر کلیک کنید تا متن اضافه شود. روی متن موجود کلیک کنید تا ویرایش شود.',
    opt_color: 'رنگ', opt_size: 'اندازه', opt_hard: 'سختی', opt_flow: 'شدت', opt_maskmode: 'حالت ماسک',
    mask_hide: 'پنهان کردن', mask_reveal: 'نمایش دادن', opt_tol: 'حساسیت', opt_soft: 'نرمی لبه', opt_contig: 'فقط ناحیه متصل',
    opt_ratio: 'نسبت', crop_free: 'آزاد',

    tab_layers: 'لایه‌ها', tab_adjust: 'تنظیمات', tab_filters: 'فیلترها', tab_props: 'ویژگی‌ها',
    lay_add: 'لایه خالی', lay_addimg: 'افزودن عکس', lay_dup: 'تکثیر', lay_up: 'بالا بردن', lay_down: 'پایین بردن', lay_del: 'حذف',
    lay_vis: 'نمایش / پنهان', lay_rename: 'نام لایه:', lay_empty: 'لایه‌ای وجود ندارد.',
    layer_n: 'لایه {n}', layer_copy: 'کپی', layer_flat: 'ادغام‌شده', badge_mask: 'ماسک', badge_fx: 'فیلتر',
    select_layer_first: 'ابتدا یک لایه را انتخاب کنید.', need_layer: 'ابتدا یک لایه را انتخاب کنید.', need_doc: 'ابتدا یک عکس باز کنید یا بوم جدید بسازید.',
    layer_hidden: 'این لایه پنهان است.', rasterized: 'لایه متنی به تصویر تبدیل شد.', adj_baked: 'تنظیمات رنگ روی لایه اعمال شد.',
    magic_empty: 'این نقطه شفاف است.', bg_removed: 'پس‌زمینه حذف شد. اگر کامل نبود، حساسیت را بالا ببرید یا با ابزار کلیک کنید.',

    adj_brightness: 'روشنایی', adj_contrast: 'کنتراست', adj_saturation: 'اشباع رنگ', adj_hue: 'چرخش رنگ', adj_temperature: 'دما (سرد/گرم)',
    adj_sepia: 'سپیا', adj_fade: 'محو', adj_vignette: 'حاشیه تیره', adj_blur: 'محو کردن (بلر)', adj_sharpen: 'وضوح',
    adj_reset: 'بازنشانی', adj_apply: 'اعمال دائمی', adj_note: 'تنظیمات روی لایه انتخاب‌شده اعمال می‌شود و قابل برگشت است تا زمانی که «اعمال دائمی» نزنید.',
    flt_none: 'بدون فیلتر', flt_vivid: 'پرانرژی', flt_bw: 'سیاه‌وسفید', flt_noir: 'نوآر', flt_sepia: 'سپیا', flt_cool: 'سرد',
    flt_warm: 'گرم', flt_fade: 'محو', flt_dramatic: 'دراماتیک', flt_vintage: 'قدیمی', flt_soft: 'نرم',

    sec_layer: 'لایه', prop_opacity: 'شفافیت', prop_blend: 'حالت ترکیب', prop_scale: 'اندازه', prop_rotate: 'چرخش',
    prop_center: 'وسط', prop_fit: 'جا شدن', prop_fill: 'پر کردن',
    sec_mask: 'ماسک لایه', mask_add: 'افزودن ماسک', mask_paint: 'نقاشی روی ماسک', mask_invert: 'معکوس', mask_apply: 'اعمال ماسک', mask_del: 'حذف ماسک',
    sec_text: 'متن', txt_content: 'محتوا', txt_font: 'فونت', txt_size: 'اندازه', txt_color: 'رنگ', txt_bold: 'ضخیم', txt_italic: 'کج', txt_shadow: 'سایه',
    txt_align: 'چینش', al_left: 'چپ', al_center: 'وسط', al_right: 'راست', txt_dir: 'جهت متن', dir_auto: 'خودکار', dir_rtl: 'راست‌به‌چپ', dir_ltr: 'چپ‌به‌راست',
    txt_stroke: 'ضخامت دورخط', txt_strokecolor: 'رنگ دورخط', txt_bg: 'پس‌زمینه متن', txt_raster: 'تبدیل به تصویر',
    text_sample: 'متن نمونه',

    blend_source_over: 'عادی', 'blend_source-over': 'عادی', blend_multiply: 'ضرب', blend_screen: 'صفحه', blend_overlay: 'روکش', blend_darken: 'تیره‌تر',
    blend_lighten: 'روشن‌تر', 'blend_color-dodge': 'رنگ روشن', 'blend_color-burn': 'رنگ تیره', 'blend_hard-light': 'نور سخت',
    'blend_soft-light': 'نور نرم', blend_difference: 'تفاضل', blend_exclusion: 'حذف', blend_hue: 'فام', blend_saturation: 'اشباع',
    blend_color: 'رنگ', blend_luminosity: 'درخشندگی',

    dlg_width: 'عرض (پیکسل)', dlg_height: 'ارتفاع (پیکسل)', dlg_preset: 'اندازه آماده', dlg_bg: 'پس‌زمینه',
    bg_white: 'سفید', bg_black: 'سیاه', bg_transparent: 'شفاف', bg_color: 'رنگ دلخواه',
    confirm_new: 'کار فعلی از بین می‌رود. ادامه می‌دهید؟',
    exp_quality: 'کیفیت', exp_format: 'قالب', exp_name: 'نام فایل', err_export: 'ساخت فایل ناموفق بود.', exp_fallback: 'مرورگر این قالب را پشتیبانی نمی‌کند؛ با قالب PNG ذخیره شد.',
    err_image: 'این فایل به‌عنوان تصویر خوانده نشد.', img_downscaled: 'تصویر بسیار بزرگ بود و برای پایداری به حداکثر {n} پیکسل کوچک شد.',

    v_add_media: 'ویدیو / عکس', v_add_music: 'موزیک', v_add_text: 'متن', v_split: 'برش در نشانگر (S)', v_delete: 'حذف', v_export: 'خروجی ویدیو',
    v_play: 'پخش / توقف (فاصله)', v_to_start: 'رفتن به ابتدا', v_tl_zoom: 'زوم خط زمان',
    v_err_media: 'فایل «{name}» باز نشد. قالب آن توسط مرورگر پشتیبانی نمی‌شود.',
    v_need_clip: 'ابتدا ویدیو یا عکسی به خط زمان اضافه کنید.', v_split_edge: 'نشانگر را داخل کلیپ و دور از لبه‌ها قرار دهید.',
    v_project: 'تنظیمات پروژه', v_res: 'ابعاد خروجی', v_fps: 'فریم بر ثانیه', v_format: 'قالب خروجی', v_quality: 'کیفیت',
    q_low: 'کم (حجم کمتر)', q_med: 'متوسط', q_high: 'بالا',
    v_export_note: 'خروجی به‌صورت زنده و هم‌زمان با پخش ساخته می‌شود؛ پس مدت ساخت برابر مدت ویدیوست. در طول ساخت این زبانه را باز نگه دارید.',
    v_tip: 'نکته: برای ویرایش، کلیپ‌ها را روی خط زمان انتخاب کنید. لبه‌های کلیپ را برای کوتاه کردن بکشید، و کلیپ را برای جابه‌جایی ترتیب بکشید.',
    v_photo_clip: 'عکس', v_video_clip: 'ویدیو', v_text_clip: 'متن روی ویدیو', v_music_clip: 'موزیک',
    v_move_left: 'یک جا به عقب', v_move_right: 'یک جا به جلو', v_duration: 'مدت نمایش (ثانیه)', v_trim_in: 'شروع (ثانیه)', v_trim_out: 'پایان (ثانیه)',
    v_set_in: 'شروع از نشانگر', v_set_out: 'پایان در نشانگر', v_speed: 'سرعت', v_volume: 'صدا', v_fade_in: 'محو شدن در شروع', v_fade_out: 'محو شدن در پایان',
    v_filters: 'فیلتر رنگ', v_filter_all: 'اعمال روی همه کلیپ‌ها', v_done: 'انجام شد.', v_no_gl: 'مرورگر شما WebGL ندارد؛ فیلتر رنگ در ویدیو کار نمی‌کند.',
    v_text_fade: 'ظاهر و محو نرم', v_pos_x: 'موقعیت افقی', v_pos_y: 'موقعیت عمودی', v_t_start: 'شروع (ثانیه)', v_t_end: 'پایان (ثانیه)',
    v_text_drag: 'می‌توانید متن را مستقیم روی پیش‌نمایش بکشید.', v_m_start: 'شروع روی خط زمان (ثانیه)',
    v_export_sum: 'خروجی {fmt} با ابعاد {w}×{h}، {fps} فریم بر ثانیه، مدت {dur}.', v_export_start: 'شروع ساخت',
    v_exporting: 'در حال ساخت ویدیو…', v_keep_visible: 'این زبانه را باز و قابل‌مشاهده نگه دارید، وگرنه مرورگر ساخت را کند می‌کند.',
    v_no_rec: 'مرورگر شما ضبط ویدیو را پشتیبانی نمی‌کند. از Chrome، Edge یا Firefox نسخه جدید استفاده کنید.',
    v_export_cancelled: 'ساخت ویدیو لغو شد.', v_export_fail: 'ویدیویی ساخته نشد.',
    v_webm_fallback: 'مرورگر شما MP4 را پشتیبانی نمی‌کند؛ ویدیو با قالب WebM ذخیره شد (با VLC و اکثر مرورگرها پخش می‌شود).',
    v_export_done: 'ویدیو با قالب {ext} ساخته و ذخیره شد.'
  },
  en: {
    app_title: 'Editor Studio', app_sub: 'Photo & Video',
    nav_photo: 'Photo editor', nav_video: 'Video editor', lang_btn: 'فارسی',
    empty_title: 'Drop a photo here or open one', empty_sub: 'or create a blank canvas',
    empty_open: 'Open photo', empty_new: 'New canvas',
    v_empty_title: 'Add videos or photos', v_empty_sub: 'Drag and drop files or press the button', v_empty_add: 'Add video / photo',
    tl_video: 'Video', tl_text: 'Text', tl_music: 'Music',

    nav_ai: 'AI studio',
    ai_img_title: '✦ Image studio', ai_img_sub: 'Turn a detailed prompt into an image and open it directly in the photo editor.',
    ai_prompt: 'Describe your image', ai_prompt_ph: 'A calm modern villa beside a lake at golden hour…',
    ai_size: 'Image format', ai_size_sq: 'Square · 1024 × 1024', ai_size_land: 'Landscape · 1536 × 1024', ai_size_port: 'Portrait · 1024 × 1536',
    ai_img_btn: 'Generate image',
    ai_aud_title: '♫ Voice studio', ai_aud_sub: 'Convert text into speech and drop it on the video timeline.',
    ai_text: 'Text to speak', ai_text_ph: 'Write or paste the text you want to hear…', ai_voice: 'Voice', ai_style: 'Speaking style (optional)', ai_style_ph: 'Warm, calm, clear…',
    ai_aud_btn: 'Generate voice',
    ai_working: 'Working… this may take a little while.', ai_done: 'Done!', ai_failed: 'Request failed: ',
    ai_prompt_req: 'Please describe the image first.', ai_text_req: 'Please enter text first.',
    ai_checking: 'Checking backend configuration…', ai_configured: 'Backend is online and an AI API key is configured.',
    ai_not_configured: 'Backend is online, but no AI API key is configured. Add OPENAI_API_KEY to the server .env file.',
    ai_offline: 'Could not reach the backend. Start the server and reload this page.',
    ai_file_mode: 'This tab needs the server. Run the app with uvicorn and open http://127.0.0.1:8000 (the photo and video editors also work without the server).',
    ai_hist_title: 'Recent activity', ai_hist_sub: 'Recent generation jobs saved by this server.', ai_refresh: 'Refresh history',
    ai_no_hist: 'No activity yet.', ai_hist_fail: 'Could not load history.', ai_kind_image: 'Image', ai_kind_audio: 'Audio',
    ai_to_photo: 'Send to photo editor', ai_to_video: 'Send to video editor', ai_download: 'Download',
    ai_sent_photo: 'Image added to the photo editor.', ai_sent_video: 'Added to the video editor.',
    ai_footer: 'Starter release • API keys stay on the server • Add authentication, billing and rate limits before public launch.',
    flat_need: 'Flattening needs at least two layers.', v_select_first: 'Select an item on the timeline first.',
    act_undo: 'Undo (Ctrl+Z)', act_redo: 'Redo (Ctrl+Y)', act_new: 'New', act_open: 'Open', act_export: 'Export', act_save: 'Save',
    act_zoomout: 'Zoom out', act_zoomin: 'Zoom in', act_fit: 'Fit to screen',
    act_rotl: 'Rotate 90° left', act_rotr: 'Rotate 90° right', act_fliph: 'Flip horizontal', act_flipv: 'Flip vertical',
    act_resize: 'Resize image', act_flatten: 'Flatten all layers',
    act_apply: 'Apply', act_cancel: 'Cancel', act_create: 'Create', act_autobg: 'Auto remove background',

    tool_move: 'Move', tool_hand: 'Hand', tool_crop: 'Crop', tool_brush: 'Brush', tool_eraser: 'Eraser',
    tool_magic: 'Background eraser', tool_text: 'Text', tool_mask: 'Mask',
    hint_move: 'Drag a layer. Corners resize, the top circle rotates (hold Shift for 15° steps).',
    hint_hand: 'Drag to pan the image. Ctrl + mouse wheel zooms.',
    hint_text: 'Click the image to add text. Click existing text to edit it.',
    opt_color: 'Color', opt_size: 'Size', opt_hard: 'Hardness', opt_flow: 'Flow', opt_maskmode: 'Mask mode',
    mask_hide: 'Hide', mask_reveal: 'Reveal', opt_tol: 'Tolerance', opt_soft: 'Edge softness', opt_contig: 'Contiguous only',
    opt_ratio: 'Ratio', crop_free: 'Free',

    tab_layers: 'Layers', tab_adjust: 'Adjust', tab_filters: 'Filters', tab_props: 'Properties',
    lay_add: 'Blank layer', lay_addimg: 'Add image', lay_dup: 'Duplicate', lay_up: 'Move up', lay_down: 'Move down', lay_del: 'Delete',
    lay_vis: 'Show / hide', lay_rename: 'Layer name:', lay_empty: 'No layers yet.',
    layer_n: 'Layer {n}', layer_copy: 'copy', layer_flat: 'Flattened', badge_mask: 'mask', badge_fx: 'fx',
    select_layer_first: 'Select a layer first.', need_layer: 'Select a layer first.', need_doc: 'Open a photo or create a new canvas first.',
    layer_hidden: 'This layer is hidden.', rasterized: 'Text layer converted to an image.', adj_baked: 'Color adjustments were applied to the layer.',
    magic_empty: 'That spot is transparent.', bg_removed: 'Background removed. If it is not complete, raise the tolerance or click with the tool.',

    adj_brightness: 'Brightness', adj_contrast: 'Contrast', adj_saturation: 'Saturation', adj_hue: 'Hue', adj_temperature: 'Temperature',
    adj_sepia: 'Sepia', adj_fade: 'Fade', adj_vignette: 'Vignette', adj_blur: 'Blur', adj_sharpen: 'Sharpen',
    adj_reset: 'Reset', adj_apply: 'Apply permanently', adj_note: 'Adjustments affect the selected layer and stay editable until you press “Apply permanently”.',
    flt_none: 'None', flt_vivid: 'Vivid', flt_bw: 'Black & white', flt_noir: 'Noir', flt_sepia: 'Sepia', flt_cool: 'Cool',
    flt_warm: 'Warm', flt_fade: 'Faded', flt_dramatic: 'Dramatic', flt_vintage: 'Vintage', flt_soft: 'Soft',

    sec_layer: 'Layer', prop_opacity: 'Opacity', prop_blend: 'Blend mode', prop_scale: 'Scale', prop_rotate: 'Rotation',
    prop_center: 'Center', prop_fit: 'Fit', prop_fill: 'Fill',
    sec_mask: 'Layer mask', mask_add: 'Add mask', mask_paint: 'Paint on mask', mask_invert: 'Invert', mask_apply: 'Apply mask', mask_del: 'Delete mask',
    sec_text: 'Text', txt_content: 'Content', txt_font: 'Font', txt_size: 'Size', txt_color: 'Color', txt_bold: 'Bold', txt_italic: 'Italic', txt_shadow: 'Shadow',
    txt_align: 'Align', al_left: 'Left', al_center: 'Center', al_right: 'Right', txt_dir: 'Direction', dir_auto: 'Auto', dir_rtl: 'Right-to-left', dir_ltr: 'Left-to-right',
    txt_stroke: 'Outline width', txt_strokecolor: 'Outline color', txt_bg: 'Text background', txt_raster: 'Convert to image',
    text_sample: 'Sample text',

    'blend_source-over': 'Normal', blend_multiply: 'Multiply', blend_screen: 'Screen', blend_overlay: 'Overlay', blend_darken: 'Darken',
    blend_lighten: 'Lighten', 'blend_color-dodge': 'Color dodge', 'blend_color-burn': 'Color burn', 'blend_hard-light': 'Hard light',
    'blend_soft-light': 'Soft light', blend_difference: 'Difference', blend_exclusion: 'Exclusion', blend_hue: 'Hue', blend_saturation: 'Saturation',
    blend_color: 'Color', blend_luminosity: 'Luminosity',

    dlg_width: 'Width (px)', dlg_height: 'Height (px)', dlg_preset: 'Preset size', dlg_bg: 'Background',
    bg_white: 'White', bg_black: 'Black', bg_transparent: 'Transparent', bg_color: 'Custom color',
    confirm_new: 'Your current work will be lost. Continue?',
    exp_quality: 'Quality', exp_format: 'Format', exp_name: 'File name', err_export: 'Could not create the file.', exp_fallback: 'Your browser does not support that format; saved as PNG instead.',
    err_image: 'This file could not be read as an image.', img_downscaled: 'The image was very large and was reduced to at most {n} px for stability.',

    v_add_media: 'Video / photo', v_add_music: 'Music', v_add_text: 'Text', v_split: 'Split at playhead (S)', v_delete: 'Delete', v_export: 'Export video',
    v_play: 'Play / pause (Space)', v_to_start: 'Go to start', v_tl_zoom: 'Timeline zoom',
    v_err_media: 'Could not open “{name}”. Your browser does not support this format.',
    v_need_clip: 'Add a video or photo to the timeline first.', v_split_edge: 'Place the playhead inside a clip, away from its edges.',
    v_project: 'Project settings', v_res: 'Output size', v_fps: 'Frames per second', v_format: 'Output format', v_quality: 'Quality',
    q_low: 'Low (smaller file)', q_med: 'Medium', q_high: 'High',
    v_export_note: 'Export is recorded live while the video plays, so it takes as long as the video itself. Keep this tab open while it runs.',
    v_tip: 'Tip: select clips on the timeline. Drag a clip’s edges to trim it, and drag the clip itself to reorder.',
    v_photo_clip: 'Photo', v_video_clip: 'Video', v_text_clip: 'Text overlay', v_music_clip: 'Music',
    v_move_left: 'Move earlier', v_move_right: 'Move later', v_duration: 'Duration (s)', v_trim_in: 'Start (s)', v_trim_out: 'End (s)',
    v_set_in: 'Start at playhead', v_set_out: 'End at playhead', v_speed: 'Speed', v_volume: 'Volume', v_fade_in: 'Fade in', v_fade_out: 'Fade out',
    v_filters: 'Color filter', v_filter_all: 'Apply to all clips', v_done: 'Done.', v_no_gl: 'Your browser has no WebGL; color filters will not work on video.',
    v_text_fade: 'Soft fade in/out', v_pos_x: 'Horizontal position', v_pos_y: 'Vertical position', v_t_start: 'Start (s)', v_t_end: 'End (s)',
    v_text_drag: 'You can drag the text directly on the preview.', v_m_start: 'Start on timeline (s)',
    v_export_sum: '{fmt} export, {w}×{h}, {fps} fps, length {dur}.', v_export_start: 'Start export',
    v_exporting: 'Rendering video…', v_keep_visible: 'Keep this tab open and visible, otherwise the browser throttles rendering.',
    v_no_rec: 'Your browser does not support video recording. Use a recent Chrome, Edge or Firefox.',
    v_export_cancelled: 'Export cancelled.', v_export_fail: 'No video was produced.',
    v_webm_fallback: 'Your browser does not support MP4; the video was saved as WebM (plays in VLC and most browsers).',
    v_export_done: 'Video created and saved as {ext}.'
  }
};

let LANG = 'fa';
try { const s = localStorage.getItem('studio.lang'); if (s === 'fa' || s === 'en') LANG = s; } catch (e) { /* storage blocked */ }

function t(key, params) {
  let s = (I18N[LANG] && I18N[LANG][key]);
  if (s === undefined) s = I18N.en[key];
  if (s === undefined) return key;
  if (params) for (const k in params) s = s.split('{' + k + '}').join(String(params[k]));
  return s;
}
function applyDir() {
  const html = document.documentElement;
  html.lang = LANG;
  html.dir = LANG === 'fa' ? 'rtl' : 'ltr';
  document.title = t('app_title') + ' — ' + t('app_sub');
  $$('[data-i]').forEach(n => { n.textContent = t(n.getAttribute('data-i')); });
}
function setLang(l) {
  LANG = l;
  try { localStorage.setItem('studio.lang', l); } catch (e) { /* ignore */ }
  applyDir();
}
