'use strict';
/* ===================================================================
   Video editor: timeline (trim / split / reorder / merge / speed),
   music tracks, text overlays, colour filters (WebGL), real-time
   export to MP4 / WebM through MediaRecorder. No external libraries.
   =================================================================== */
const Video = (function () {
  const V = {
    media: {}, clips: [], music: [], texts: [],
    out: { w: 1280, h: 720, fps: 30 }, format: 'mp4', quality: 'med',
    sel: null, tm: 0, playing: false, lastNow: 0, pps: 60,
    history: [], redo: [], histKey: '', histTime: 0
  };
  const EX = { active: false, cancelled: false, rec: null, chunks: [], onEnd: null, mime: null, ui: null };

  let cv, cg, root, emptyBox, seekInp, timeLbl, playBtn, undoBtn, redoBtn, inspector, tlScroll, tlInner, tlRuler, laneV, laneT, laneM, tlHead, visFiles, musicFiles, visible = false;
  let AC = null, bus = null, spk = null, recDest = null;

  const FONTS = [
    ['Tahoma', 'Tahoma, "Segoe UI", sans-serif'], ['Arial', 'Arial, Helvetica, sans-serif'], ['Segoe UI', '"Segoe UI", Tahoma, sans-serif'],
    ['Noto Naskh Arabic', '"Noto Naskh Arabic", "Traditional Arabic", serif'], ['Times New Roman', '"Times New Roman", Times, serif'],
    ['Georgia', 'Georgia, serif'], ['Verdana', 'Verdana, sans-serif'], ['Impact', 'Impact, "Arial Black", sans-serif']
  ];
  const SIZES = [
    ['1920 × 1080 (16:9)', 1920, 1080], ['1280 × 720 (16:9)', 1280, 720], ['854 × 480 (16:9)', 854, 480],
    ['1080 × 1920 (9:16)', 1080, 1920], ['720 × 1280 (9:16)', 720, 1280],
    ['1080 × 1080 (1:1)', 1080, 1080], ['1080 × 1350 (4:5)', 1080, 1350]
  ];
  const ADJ = [['brightness', -100, 100], ['contrast', -100, 100], ['saturation', -100, 100], ['hue', -180, 180],
    ['temperature', -100, 100], ['sepia', 0, 100], ['fade', 0, 100], ['vignette', 0, 100]];
  const PRESETS = [
    { id: 'none', v: {} }, { id: 'vivid', v: { saturation: 35, contrast: 12, brightness: 3 } },
    { id: 'bw', v: { saturation: -100, contrast: 15 } }, { id: 'noir', v: { saturation: -100, contrast: 40, brightness: -8, vignette: 40 } },
    { id: 'sepia', v: { sepia: 80, contrast: 5 } }, { id: 'cool', v: { temperature: -35, saturation: 8 } },
    { id: 'warm', v: { temperature: 35, saturation: 10 } }, { id: 'fade', v: { fade: 45, saturation: -10, contrast: -8 } },
    { id: 'dramatic', v: { contrast: 35, saturation: -15, brightness: -5, vignette: 35 } },
    { id: 'vintage', v: { sepia: 35, fade: 30, temperature: 15, vignette: 30, contrast: -5 } }
  ];
  const defAdj = () => ({ brightness: 0, contrast: 0, saturation: 0, hue: 0, temperature: 0, sepia: 0, fade: 0, vignette: 0 });
  const adjIsDefault = a => { for (const k in a) if (a[k] !== 0) return false; return true; };

  /* ============================ model ============================ */
  const clipLen = c => Math.max(0.05, (c.out - c.in) / c.speed);
  function layout() {
    let s = 0;
    return V.clips.map((c, i) => { const len = clipLen(c); const o = { c: c, i: i, start: s, len: len, end: s + len }; s += len; return o; });
  }
  const total = () => V.clips.reduce((a, c) => a + clipLen(c), 0);
  function activeIn(lay, tm) {
    if (!lay.length) return null;
    for (let i = 0; i < lay.length; i++) if (tm >= lay[i].start && tm < lay[i].end) return lay[i];
    return lay[lay.length - 1];
  }
  const clipById = id => V.clips.find(c => c.id === id) || null;
  const musicById = id => V.music.find(c => c.id === id) || null;
  const textById = id => V.texts.find(c => c.id === id) || null;
  function selected() {
    if (!V.sel) return null;
    const o = V.sel.type === 'clip' ? clipById(V.sel.id) : V.sel.type === 'music' ? musicById(V.sel.id) : textById(V.sel.id);
    return o ? { type: V.sel.type, o: o } : null;
  }
  function fadeAt(fi, fo, lt, len) {
    let f = 1;
    if (fi > 0 && lt < fi) f = lt / fi;
    if (fo > 0 && len - lt < fo) f = Math.min(f, (len - lt) / fo);
    return clamp(f, 0, 1);
  }

  /* ---------- history ---------- */
  function snap() {
    return JSON.stringify({ clips: V.clips, music: V.music, texts: V.texts.map(x => { const c = Object.assign({}, x); delete c._bb; return c; }), out: V.out, sel: V.sel });
  }
  function pushHistory(key) {
    const now = Date.now();
    if (key && key === V.histKey && now - V.histTime < 900) { V.histTime = now; return; }
    V.history.push(snap());
    if (V.history.length > 60) V.history.shift();
    V.redo.length = 0; V.histKey = key || ''; V.histTime = now;
    updateUndo();
  }
  function restore(s) {
    const o = JSON.parse(s);
    V.clips = o.clips; V.music = o.music; V.texts = o.texts; V.out = o.out; V.sel = o.sel; V.histKey = '';
    applyOut(); V.tm = clamp(V.tm, 0, total());
    renderAll(); seek(V.tm);
  }
  function undo() { if (!V.history.length || EX.active) return; V.redo.push(snap()); restore(V.history.pop()); updateUndo(); }
  function redo() { if (!V.redo.length || EX.active) return; V.history.push(snap()); restore(V.redo.pop()); updateUndo(); }
  function updateUndo() { if (undoBtn) undoBtn.disabled = !V.history.length; if (redoBtn) redoBtn.disabled = !V.redo.length; }

  /* ============================ audio graph ============================ */
  function ensureAudio() {
    if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    AC = new Ctx();
    bus = AC.createGain(); spk = AC.createGain(); recDest = AC.createMediaStreamDestination();
    bus.connect(spk); spk.connect(AC.destination); bus.connect(recDest);
    Object.keys(V.media).forEach(k => connectMedia(V.media[k]));
  }
  function connectMedia(m) {
    if (!AC || m.kind === 'image' || m.node) return;
    try {
      const src = AC.createMediaElementSource(m.el);
      m.node = AC.createGain(); src.connect(m.node); m.node.connect(bus);
    } catch (e) { m.node = null; }
  }
  function setGain(m, v) {
    if (m.node) m.node.gain.value = v; else m.el.volume = clamp(v, 0, 1);
  }

  /* ============================ WebGL renderer ============================ */
  const GLR = {
    ok: false, canvas: null, gl: null, prog: null, loc: {}, tex: null,
    init: function () {
      try {
        this.canvas = document.createElement('canvas');
        this.canvas.width = V.out.w; this.canvas.height = V.out.h;
        const gl = this.canvas.getContext('webgl', { preserveDrawingBuffer: true, premultipliedAlpha: false, antialias: false });
        if (!gl) return;
        const vs = 'attribute vec2 a; uniform vec4 uR; varying vec2 v; void main(){ vec2 p = vec2(mix(uR.x,uR.z,a.x), mix(uR.y,uR.w,a.y)); v = vec2(a.x, 1.0-a.y); gl_Position = vec4(p,0.0,1.0); }';
        const fs = 'precision mediump float; varying vec2 v; uniform sampler2D tx;' +
          'uniform float uBri,uCon,uSat,uTmp,uSep,uFade,uVig,uMul; uniform mat3 uHue;' +
          'void main(){ vec3 c = texture2D(tx,v).rgb; c += uBri; c = (c-0.5)*uCon+0.5; c.r += uTmp; c.b -= uTmp;' +
          'float g = dot(c, vec3(0.299,0.587,0.114)); c = vec3(g) + (c-vec3(g))*uSat; c = uHue*c;' +
          'vec3 s = vec3(dot(c,vec3(0.393,0.769,0.189)), dot(c,vec3(0.349,0.686,0.168)), dot(c,vec3(0.272,0.534,0.131)));' +
          'c = mix(c,s,uSep); c = vec3(uFade) + c*(1.0-uFade);' +
          'vec2 q = (v-0.5)*2.0; float d = length(q)/1.4142; float sm = smoothstep(0.35,1.0,d); c *= 1.0 - uVig*sm;' +
          'gl_FragColor = vec4(clamp(c*uMul,0.0,1.0),1.0); }';
        const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
        const p = gl.createProgram();
        gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
        gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('link');
        gl.useProgram(p);
        const buf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
        const a = gl.getAttribLocation(p, 'a');
        gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
        ['uR', 'uBri', 'uCon', 'uSat', 'uTmp', 'uSep', 'uFade', 'uVig', 'uMul', 'uHue', 'tx'].forEach(n => { this.loc[n] = gl.getUniformLocation(p, n); });
        this.tex = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.tex);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.uniform1i(this.loc.tx, 0);
        gl.clearColor(0, 0, 0, 1);
        this.gl = gl; this.prog = p; this.ok = true;
      } catch (e) { this.ok = false; }
    },
    resize: function (w, ht) {
      if (!this.canvas) return;
      this.canvas.width = w; this.canvas.height = ht;
      if (this.gl) this.gl.viewport(0, 0, w, ht);
    },
    draw: function (src, sw, sh, adj, fade) {
      const gl = this.gl, L = this.loc, W = V.out.w, H = V.out.h;
      const k = Math.min(W / sw, H / sh), dw = sw * k, dh = sh * k, x0 = (W - dw) / 2, y0 = (H - dh) / 2;
      gl.viewport(0, 0, W, H);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
      gl.uniform4f(L.uR, x0 / W * 2 - 1, 1 - (y0 + dh) / H * 2, (x0 + dw) / W * 2 - 1, 1 - y0 / H * 2);
      const cc = adj.contrast * 2.55, cf = (259 * (cc + 255)) / (255 * (259 - cc));
      const hr = adj.hue * Math.PI / 180, co = Math.cos(hr), si = Math.sin(hr);
      const m0 = 0.213 + co * 0.787 - si * 0.213, m1 = 0.715 - co * 0.715 - si * 0.715, m2 = 0.072 - co * 0.072 + si * 0.928;
      const m3 = 0.213 - co * 0.213 + si * 0.143, m4 = 0.715 + co * 0.285 + si * 0.140, m5 = 0.072 - co * 0.072 - si * 0.283;
      const m6 = 0.213 - co * 0.213 - si * 0.787, m7 = 0.715 - co * 0.715 + si * 0.715, m8 = 0.072 + co * 0.928 + si * 0.072;
      gl.uniform1f(L.uBri, adj.brightness / 100);
      gl.uniform1f(L.uCon, cf);
      gl.uniform1f(L.uSat, 1 + adj.saturation / 100);
      gl.uniform1f(L.uTmp, adj.temperature * 0.5 / 255);
      gl.uniform1f(L.uSep, adj.sepia / 100);
      gl.uniform1f(L.uFade, adj.fade / 100 * 70 / 255);
      gl.uniform1f(L.uVig, adj.vignette / 100);
      gl.uniform1f(L.uMul, fade);
      gl.uniformMatrix3fv(L.uHue, false, new Float32Array([m0, m3, m6, m1, m4, m7, m2, m5, m8]));
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
  };

  /* ============================ drawing ============================ */
  function applyOut() {
    if (!cv) return;
    if (cv.width !== V.out.w || cv.height !== V.out.h) { cv.width = V.out.w; cv.height = V.out.h; }
    GLR.resize(V.out.w, V.out.h);
  }
  function drawText(g, tx, W, H, alpha) {
    const px = H * tx.size / 100;
    const font = (tx.italic ? 'italic ' : '') + (tx.bold ? 'bold ' : '') + px + 'px ' + tx.font;
    g.save();
    g.globalAlpha = alpha;
    g.font = font; g.textBaseline = 'middle'; g.textAlign = 'center';
    const rtl = /[֐-ࣿיִ-﷿ﹰ-﻿]/.test(tx.text);
    g.direction = rtl ? 'rtl' : 'ltr';
    const lines = String(tx.text || '').split('\n');
    let maxW = 1;
    lines.forEach(ln => { maxW = Math.max(maxW, g.measureText(ln).width); });
    const lh = px * 1.3, bw = maxW + px * 0.7, bh = lh * lines.length + px * 0.3;
    const cxp = tx.x * W, cyp = tx.y * H;
    tx._bb = { x: cxp - bw / 2, y: cyp - bh / 2, w: bw, h: bh };
    if (tx.bg) { g.fillStyle = rgba(tx.bg, 0.6); g.fillRect(cxp - bw / 2, cyp - bh / 2, bw, bh); }
    g.lineJoin = 'round';
    lines.forEach((ln, i) => {
      const y = cyp - bh / 2 + px * 0.15 + lh * i + lh / 2;
      if (tx.shadow) { g.shadowColor = 'rgba(0,0,0,0.7)'; g.shadowBlur = px * 0.12; g.shadowOffsetX = px * 0.04; g.shadowOffsetY = px * 0.04; }
      if (tx.strokeW > 0) { g.strokeStyle = tx.strokeColor; g.lineWidth = tx.strokeW * H / 720 * 2; g.strokeText(ln, cxp, y); }
      g.shadowColor = 'transparent';
      g.fillStyle = tx.color; g.fillText(ln, cxp, y);
    });
    g.restore();
  }
  function drawFrame(tm) {
    if (!cg) return;
    const W = V.out.w, H = V.out.h;
    cg.globalAlpha = 1;
    cg.fillStyle = '#000'; cg.fillRect(0, 0, W, H);
    const a = activeIn(layout(), tm);
    if (a) {
      const c = a.c, m = V.media[c.mid];
      const lt = clamp(tm - a.start, 0, a.len);
      const ready = m && (m.kind === 'image' || m.el.readyState >= 2);
      if (ready) {
        const fade = fadeAt(c.fadeIn, c.fadeOut, lt, a.len);
        const sw = m.kind === 'image' ? m.el.width : m.el.videoWidth, sh = m.kind === 'image' ? m.el.height : m.el.videoHeight;
        if (sw && sh) {
          let done = false;
          if (GLR.ok) { try { GLR.draw(m.el, sw, sh, c.adj, fade); cg.drawImage(GLR.canvas, 0, 0); done = true; } catch (e) { done = false; } }
          if (!done) {
            const k = Math.min(W / sw, H / sh), dw = sw * k, dh = sh * k;
            cg.drawImage(m.el, (W - dw) / 2, (H - dh) / 2, dw, dh);
            if (fade < 1) { cg.fillStyle = 'rgba(0,0,0,' + (1 - fade) + ')'; cg.fillRect(0, 0, W, H); }
          }
        }
      }
    }
    V.texts.forEach(tx => {
      if (tm >= tx.start && tm <= tx.end) {
        let al = 1;
        if (tx.anim === 'fade') al = clamp(Math.min((tm - tx.start) / 0.3, (tx.end - tm) / 0.3), 0, 1);
        drawText(cg, tx, W, H, al);
      } else tx._bb = null;
    });
  }

  /* ============================ playback ============================ */
  function seekEl(el, tm) {
    return new Promise(res => {
      if (Math.abs(el.currentTime - tm) < 0.002 && el.readyState >= 2) { res(); return; }
      const to = setTimeout(done, 2500);
      function done() { clearTimeout(to); el.removeEventListener('seeked', done); res(); }
      el.addEventListener('seeked', done);
      try { el.currentTime = tm; } catch (e) { done(); }
    });
  }
  function pauseAllMedia() {
    Object.keys(V.media).forEach(k => { const m = V.media[k]; if (m.kind !== 'image' && !m.el.paused) m.el.pause(); });
  }
  function syncMedia(tm, playing) {
    const lay = layout(), a = activeIn(lay, tm), activeEls = new Set();
    if (a) {
      const c = a.c, m = V.media[c.mid];
      if (m && m.kind === 'video') {
        activeEls.add(m.el);
        const lt = clamp(tm - a.start, 0, a.len), target = c.in + lt * c.speed, rate = clamp(c.speed, 0.0625, 16);
        if (m.el.playbackRate !== rate) m.el.playbackRate = rate;
        if (playing) {
          if (m.el.paused || m.el.ended) { m.el.currentTime = target; const pr = m.el.play(); if (pr && pr.catch) pr.catch(() => { }); }
          else if (!m.el.seeking && Math.abs(m.el.currentTime - target) > 0.3) m.el.currentTime = target;
        } else {
          if (!m.el.paused) m.el.pause();
          if (!m.el.seeking && Math.abs(m.el.currentTime - target) > 0.01) m.el.currentTime = target;
        }
        setGain(m, c.vol * fadeAt(c.fadeIn, c.fadeOut, lt, a.len));
      }
      if (playing) {
        const nx = lay[a.i + 1];
        if (nx && nx.start - tm < 1.0) {
          const m2 = V.media[nx.c.mid];
          if (m2 && m2.kind === 'video' && m2.el !== (m && m.el) && !m2.el.seeking && Math.abs(m2.el.currentTime - nx.c.in) > 0.05) m2.el.currentTime = nx.c.in;
        }
      }
    }
    Object.keys(V.media).forEach(k => {
      const m = V.media[k];
      if (m.kind === 'video' && !activeEls.has(m.el) && !m.el.paused) m.el.pause();
    });
    V.music.forEach(mu => {
      const m = V.media[mu.mid];
      if (!m) return;
      const len = mu.out - mu.in, lt = tm - mu.start;
      if (lt >= 0 && lt < len) {
        const target = mu.in + lt;
        setGain(m, mu.vol * fadeAt(mu.fadeIn, mu.fadeOut, lt, len));
        if (playing) {
          if (m.el.paused) { m.el.currentTime = target; const pr = m.el.play(); if (pr && pr.catch) pr.catch(() => { }); }
          else if (!m.el.seeking && Math.abs(m.el.currentTime - target) > 0.3) m.el.currentTime = target;
        } else if (!m.el.paused) m.el.pause();
      } else if (!m.el.paused) m.el.pause();
    });
  }
  function seek(tm) {
    V.tm = clamp(tm, 0, total());
    syncMedia(V.tm, false);
    drawFrame(V.tm);
    updateTransport();
  }
  function play() {
    if (EX.active) return;
    if (!V.clips.length) { toast(t('v_need_clip')); return; }
    ensureAudio();
    if (V.tm >= total() - 0.02) V.tm = 0;
    V.playing = true; V.lastNow = performance.now();
    updateTransport();
    requestAnimationFrame(tick);
  }
  function pause() {
    V.playing = false;
    pauseAllMedia();
    updateTransport();
  }
  function tick(now) {
    if (!V.playing) return;
    const raw = Math.max(0, (now - V.lastNow) / 1000);
    V.lastNow = now;
    V.tm += EX.active ? raw : Math.min(raw, 0.25);
    const tot = total();
    if (V.tm >= tot) {
      V.tm = tot;
      syncMedia(V.tm, false); drawFrame(V.tm);
      V.playing = false; pauseAllMedia(); updateTransport();
      if (EX.active && EX.onEnd) EX.onEnd();
      return;
    }
    syncMedia(V.tm, true); drawFrame(V.tm);
    updateTransport();
    if (EX.active) updateExportUI();
    requestAnimationFrame(tick);
  }
  function updateTransport() {
    if (!cv) return;
    const tot = total();
    if (seekInp) { seekInp.max = String(Math.max(tot, 0.01)); seekInp.value = String(V.tm); }
    if (timeLbl) timeLbl.textContent = fmtTime(V.tm) + ' / ' + fmtTime(tot);
    if (playBtn) { playBtn.textContent = ''; playBtn.appendChild(icon(V.playing ? 'pause' : 'play', 22)); }
    if (tlHead) {
      const x = V.tm * V.pps;
      tlHead.style.left = x + 'px';
      if (V.playing && tlScroll) {
        if (x > tlScroll.scrollLeft + tlScroll.clientWidth - 40) tlScroll.scrollLeft = x - 40;
        else if (x < tlScroll.scrollLeft) tlScroll.scrollLeft = Math.max(0, x - 40);
      }
    }
  }

  /* ============================ media loading ============================ */
  function loadElement(file, tag) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const el = document.createElement(tag);
      el.preload = 'auto'; el.setAttribute('playsinline', '');
      let finished = false;
      const end = ok => {
        if (finished) return; finished = true;
        clearTimeout(to);
        el.onloadedmetadata = null; el.onerror = null;
        if (ok) resolve({ el: el, url: url }); else { URL.revokeObjectURL(url); reject(new Error('load')); }
      };
      const to = setTimeout(() => end(false), 20000);
      el.onloadedmetadata = () => end(true);
      el.onerror = () => end(false);
      el.src = url;
    });
  }
  async function fixDuration(el) {
    if (isFinite(el.duration) && el.duration > 0) return el.duration;
    await new Promise(res => {
      const to = setTimeout(res, 4000);
      el.addEventListener('durationchange', function f() { if (isFinite(el.duration)) { el.removeEventListener('durationchange', f); clearTimeout(to); res(); } });
      el.currentTime = 1e7;
    });
    const d = isFinite(el.duration) ? el.duration : 0;
    try { el.currentTime = 0; } catch (e) { /* ignore */ }
    return d;
  }
  async function makeThumb(el, kind) {
    const c = makeCanvas(160, 90), g = c.getContext('2d');
    g.fillStyle = '#111'; g.fillRect(0, 0, 160, 90);
    let w, ht;
    if (kind === 'image') { w = el.width; ht = el.height; }
    else { await seekEl(el, Math.min(0.3, (el.duration || 1) / 2)); w = el.videoWidth; ht = el.videoHeight; }
    if (w && ht) {
      const k = Math.max(160 / w, 90 / ht);
      try { g.drawImage(el, (160 - w * k) / 2, (90 - ht * k) / 2, w * k, ht * k); } catch (e) { /* ignore */ }
    }
    if (kind === 'video') { try { el.currentTime = 0; } catch (e) { /* ignore */ } }
    return c.toDataURL('image/jpeg', 0.6);
  }
  function bindVideoEvents(el) {
    const redraw = () => { if (!V.playing && !EX.active && visible) drawFrame(V.tm); };
    el.addEventListener('seeked', redraw);
    el.addEventListener('loadeddata', redraw);
  }
  async function addVisualFiles(files) {
    ensureAudio();
    let n = 0;
    for (const f of Array.from(files || [])) {
      const isVid = f.type && f.type.indexOf('video/') === 0, isImg = f.type && f.type.indexOf('image/') === 0;
      if (!isVid && !isImg) continue;
      try {
        const mid = uid();
        let m;
        if (isVid) {
          const r = await loadElement(f, 'video');
          const dur = await fixDuration(r.el);
          if (!dur || !r.el.videoWidth) { URL.revokeObjectURL(r.url); throw new Error('novideo'); }
          m = { id: mid, kind: 'video', name: f.name, url: r.url, el: r.el, dur: dur, node: null };
          bindVideoEvents(r.el);
          m.thumb = await makeThumb(r.el, 'video');
          V.media[mid] = m; connectMedia(m);
        } else {
          const r = await fileToCanvas(f, 2560);
          m = { id: mid, kind: 'image', name: f.name, el: r.canvas, dur: 0, node: null };
          m.thumb = await makeThumb(r.canvas, 'image');
          V.media[mid] = m;
        }
        const clip = { id: uid(), mid: mid, in: 0, out: m.kind === 'image' ? 5 : m.dur, speed: 1, vol: 1, fadeIn: 0, fadeOut: 0, adj: defAdj() };
        pushHistory();
        V.clips.push(clip);
        V.sel = { type: 'clip', id: clip.id };
        n++;
      } catch (e) { toast(t('v_err_media', { name: f.name })); }
    }
    if (n) { if (V.clips.length === n) V.out = fitOutTo(V.clips[0]); applyOut(); renderAll(); seek(V.tm); }
  }
  function fitOutTo(clip) {
    const m = V.media[clip.mid];
    const w = m.kind === 'image' ? m.el.width : m.el.videoWidth, ht = m.kind === 'image' ? m.el.height : m.el.videoHeight;
    if (!w || !ht) return V.out;
    const port = ht > w * 1.2, sq = Math.abs(w - ht) < Math.min(w, ht) * 0.1;
    const s = sq ? SIZES[5] : port ? SIZES[3] : SIZES[1];
    return { w: s[1], h: s[2], fps: V.out.fps };
  }
  async function addMusicFiles(files) {
    ensureAudio();
    for (const f of Array.from(files || [])) {
      if (!f.type || f.type.indexOf('audio/') !== 0) continue;
      try {
        const r = await loadElement(f, 'audio');
        const dur = await fixDuration(r.el);
        if (!dur) { URL.revokeObjectURL(r.url); throw new Error('noaudio'); }
        pushHistory();
        const mid = uid();
        const m = { id: mid, kind: 'audio', name: f.name, url: r.url, el: r.el, dur: dur, node: null };
        V.media[mid] = m; connectMedia(m);
        const mu = { id: uid(), mid: mid, in: 0, out: dur, start: 0, vol: 1, fadeIn: 0, fadeOut: 0 };
        V.music.push(mu);
        V.sel = { type: 'music', id: mu.id };
      } catch (e) { toast(t('v_err_media', { name: f.name })); }
    }
    renderAll(); seek(V.tm);
  }

  /* ============================ editing ops ============================ */
  function splitAtPlayhead() {
    const lay = layout(), a = activeIn(lay, V.tm);
    if (!a) { toast(t('v_need_clip')); return; }
    const lt = V.tm - a.start;
    if (lt < 0.1 || a.len - lt < 0.1) { toast(t('v_split_edge')); return; }
    pushHistory();
    const c = a.c, m = V.media[c.mid], srcT = c.in + lt * c.speed;
    const c2 = JSON.parse(JSON.stringify(c));
    c2.id = uid(); c2.in = srcT; c2.fadeIn = 0;
    c.out = srcT; c.fadeOut = 0;
    if (m.kind === 'image') { c2.in = 0; c2.out = c.out; }
    if (m.kind === 'image') { c.out = lt; c2.out = a.len - lt; c2.in = 0; }
    V.clips.splice(a.i + 1, 0, c2);
    V.sel = { type: 'clip', id: c2.id };
    renderAll(); seek(V.tm);
  }
  function deleteSelected() {
    const s = selected();
    if (!s) { toast(t('v_select_first')); return; }
    pushHistory();
    if (s.type === 'clip') V.clips = V.clips.filter(c => c !== s.o);
    else if (s.type === 'music') V.music = V.music.filter(c => c !== s.o);
    else V.texts = V.texts.filter(c => c !== s.o);
    V.sel = null; V.tm = clamp(V.tm, 0, total());
    renderAll(); seek(V.tm);
  }
  function dupSelected() {
    const s = selected();
    if (!s) { toast(t('v_select_first')); return; }
    pushHistory();
    const c = JSON.parse(JSON.stringify(s.o)); delete c._bb; c.id = uid();
    if (s.type === 'clip') { V.clips.splice(V.clips.indexOf(s.o) + 1, 0, c); }
    else if (s.type === 'text') { c.start += 0.5; c.end += 0.5; c.y = Math.min(0.95, c.y + 0.08); V.texts.push(c); }
    V.sel = { type: s.type, id: c.id };
    renderAll(); seek(V.tm);
  }
  function moveClip(dir) {
    const s = selected();
    if (!s || s.type !== 'clip') return;
    const i = V.clips.indexOf(s.o), j = i + dir;
    if (j < 0 || j >= V.clips.length) return;
    pushHistory();
    V.clips[i] = V.clips[j]; V.clips[j] = s.o;
    renderAll(); seek(V.tm);
  }
  function addText() {
    pushHistory();
    const st = V.tm, tot = total();
    const tx = {
      id: uid(), text: t('text_sample'), start: st, end: st + (tot > st + 1 ? Math.min(3, tot - st) : 3), x: 0.5, y: 0.82, size: 7,
      color: '#ffffff', font: FONTS[0][1], bold: true, italic: false, strokeW: 3, strokeColor: '#000000', bg: '', shadow: true, anim: 'fade'
    };
    V.texts.push(tx); V.sel = { type: 'text', id: tx.id };
    renderAll(); seek(V.tm);
  }
  function srcTimeAtPlayhead(c) {
    const a = layout().find(o => o.c === c);
    return a ? c.in + clamp(V.tm - a.start, 0, a.len) * c.speed : c.in;
  }

  /* ============================ timeline UI ============================ */
  function trackDrag(e, onMove, onEnd) {
    e.preventDefault(); e.stopPropagation();
    const x0 = e.clientX;
    const mv = ev => onMove(ev.clientX - x0, ev);
    const up = ev => {
      window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); window.removeEventListener('pointercancel', up);
      if (onEnd) onEnd(ev.clientX - x0, ev);
    };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up); window.addEventListener('pointercancel', up);
  }
  // drags fire pointermove far faster than the screen refreshes: coalesce to one rebuild per frame
  let tlQ = false;
  function scheduleTimeline() { if (tlQ) return; tlQ = true; requestAnimationFrame(() => { tlQ = false; renderTimeline(); }); }
  function renderTimeline() {
    if (!tlInner) return;
    const lay = layout(), tot = total(), pps = V.pps;
    let maxEnd = Math.max(tot, 10);
    V.music.forEach(mu => { maxEnd = Math.max(maxEnd, mu.start + mu.out - mu.in); });
    V.texts.forEach(tx => { maxEnd = Math.max(maxEnd, tx.end); });
    tlInner.style.width = Math.ceil(maxEnd * pps + 260) + 'px';
    tlRuler.textContent = '';
    const steps = [0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600];
    const step = steps.find(s => s * pps >= 70) || 600;
    for (let s = 0; s <= maxEnd + step; s += step) {
      tlRuler.appendChild(mk('span', { class: 'tick', style: { left: s * pps + 'px' }, text: Math.floor(s / 60) + ':' + (Math.floor(s % 60) < 10 ? '0' : '') + Math.floor(s % 60) }));
    }
    laneV.textContent = ''; laneT.textContent = ''; laneM.textContent = '';
    laneV.style.minWidth = laneT.style.minWidth = laneM.style.minWidth = '100%';

    lay.forEach(it => {
      const m = V.media[it.c.mid];
      const isSel = V.sel && V.sel.type === 'clip' && V.sel.id === it.c.id;
      const blk = mk('div', {
        class: 'blk clip' + (isSel ? ' sel' : '') + (m.kind === 'image' ? ' img' : ''),
        style: { left: it.start * pps + 'px', width: Math.max(8, it.len * pps) + 'px', backgroundImage: m.thumb ? 'url(' + m.thumb + ')' : '' }
      });
      blk.appendChild(mk('span', { class: 'bl', text: m.name + ' · ' + it.len.toFixed(1) + 's' }));
      const hl = mk('i', { class: 'hd l' }), hr = mk('i', { class: 'hd r' });
      if (m.kind !== 'image') blk.appendChild(hl);
      blk.appendChild(hr);
      blk.addEventListener('pointerdown', e => {
        V.sel = { type: 'clip', id: it.c.id }; renderInspector();
        let moved = false;
        trackDrag(e, dx => {
          if (Math.abs(dx) > 4) moved = true;
          if (moved) { blk.classList.add('drag'); blk.style.transform = 'translateX(' + dx + 'px)'; }
        }, dx => {
          if (!moved) { renderTimeline(); return; }
          const centre = (it.start + it.len / 2) * pps + dx;
          const others = lay.filter(o => o !== it);
          const ni = others.filter(o => (o.start + o.len / 2) * pps < centre).length;
          if (ni !== it.i) { pushHistory(); V.clips.splice(it.i, 1); V.clips.splice(ni, 0, it.c); }
          renderAll(); seek(V.tm);
        });
      });
      hr.addEventListener('pointerdown', e => {
        V.sel = { type: 'clip', id: it.c.id };
        const c = it.c, out0 = c.out;
        let pushed = false;
        trackDrag(e, dx => {
          if (!pushed) { pushHistory(); pushed = true; }
          const d = dx / pps * c.speed;
          c.out = m.kind === 'image' ? clamp(out0 + d, 0.5, 600) : clamp(out0 + d, c.in + 0.1 * c.speed, m.dur);
          scheduleTimeline();
        }, () => { renderAll(); seek(V.tm); });
      });
      hl.addEventListener('pointerdown', e => {
        V.sel = { type: 'clip', id: it.c.id };
        const c = it.c, in0 = c.in;
        let pushed = false;
        trackDrag(e, dx => {
          if (!pushed) { pushHistory(); pushed = true; }
          c.in = clamp(in0 + dx / pps * c.speed, 0, c.out - 0.1 * c.speed);
          scheduleTimeline();
        }, () => { renderAll(); seek(V.tm); });
      });
      laneV.appendChild(blk);
    });

    V.texts.forEach(tx => {
      const isSel = V.sel && V.sel.type === 'text' && V.sel.id === tx.id;
      const blk = mk('div', { class: 'blk txt' + (isSel ? ' sel' : ''), style: { left: tx.start * pps + 'px', width: Math.max(8, (tx.end - tx.start) * pps) + 'px' } });
      blk.appendChild(mk('span', { class: 'bl', text: tx.text.replace(/\s+/g, ' ') }));
      const hl = mk('i', { class: 'hd l' }), hr = mk('i', { class: 'hd r' });
      blk.append(hl, hr);
      blk.addEventListener('pointerdown', e => {
        V.sel = { type: 'text', id: tx.id }; renderInspector();
        const s0 = tx.start, e0 = tx.end; let pushed = false;
        trackDrag(e, dx => {
          if (Math.abs(dx) > 3 && !pushed) { pushHistory(); pushed = true; }
          if (!pushed) return;
          const d = Math.max(-s0, dx / pps);
          tx.start = s0 + d; tx.end = e0 + d; scheduleTimeline();
        }, () => { renderAll(); seek(V.tm); });
      });
      hl.addEventListener('pointerdown', e => {
        V.sel = { type: 'text', id: tx.id };
        const s0 = tx.start; let pushed = false;
        trackDrag(e, dx => { if (!pushed) { pushHistory(); pushed = true; } tx.start = clamp(s0 + dx / pps, 0, tx.end - 0.2); scheduleTimeline(); }, () => { renderAll(); seek(V.tm); });
      });
      hr.addEventListener('pointerdown', e => {
        V.sel = { type: 'text', id: tx.id };
        const e0 = tx.end; let pushed = false;
        trackDrag(e, dx => { if (!pushed) { pushHistory(); pushed = true; } tx.end = Math.max(tx.start + 0.2, e0 + dx / pps); scheduleTimeline(); }, () => { renderAll(); seek(V.tm); });
      });
      laneT.appendChild(blk);
    });

    V.music.forEach(mu => {
      const m = V.media[mu.mid];
      const isSel = V.sel && V.sel.type === 'music' && V.sel.id === mu.id;
      const len = mu.out - mu.in;
      const blk = mk('div', { class: 'blk mus' + (isSel ? ' sel' : ''), style: { left: mu.start * pps + 'px', width: Math.max(8, len * pps) + 'px' } });
      blk.appendChild(mk('span', { class: 'bl', text: m.name }));
      const hl = mk('i', { class: 'hd l' }), hr = mk('i', { class: 'hd r' });
      blk.append(hl, hr);
      blk.addEventListener('pointerdown', e => {
        V.sel = { type: 'music', id: mu.id }; renderInspector();
        const s0 = mu.start; let pushed = false;
        trackDrag(e, dx => {
          if (Math.abs(dx) > 3 && !pushed) { pushHistory(); pushed = true; }
          if (!pushed) return;
          mu.start = Math.max(0, s0 + dx / pps); scheduleTimeline();
        }, () => { renderAll(); seek(V.tm); });
      });
      hl.addEventListener('pointerdown', e => {
        V.sel = { type: 'music', id: mu.id };
        const in0 = mu.in, s0 = mu.start; let pushed = false;
        trackDrag(e, dx => {
          if (!pushed) { pushHistory(); pushed = true; }
          let d = dx / pps;
          d = clamp(d, -Math.min(in0, s0), mu.out - in0 - 0.2);
          mu.in = in0 + d; mu.start = s0 + d; scheduleTimeline();
        }, () => { renderAll(); seek(V.tm); });
      });
      hr.addEventListener('pointerdown', e => {
        V.sel = { type: 'music', id: mu.id };
        const o0 = mu.out; let pushed = false;
        trackDrag(e, dx => { if (!pushed) { pushHistory(); pushed = true; } mu.out = clamp(o0 + dx / pps, mu.in + 0.2, m.dur); scheduleTimeline(); }, () => { renderAll(); seek(V.tm); });
      });
      laneM.appendChild(blk);
    });
    updateTransport();
  }
  function timeFromEvent(e) {
    const r = tlInner.getBoundingClientRect();
    return Math.max(0, (e.clientX - r.left) / V.pps);
  }

  /* ============================ inspector ============================ */
  function renderAll() { renderTimeline(); renderInspector(); updateEmpty(); updateUndo(); updateTransport(); }
  function updateEmpty() { if (emptyBox) emptyBox.hidden = V.clips.length > 0; }
  function redrawNow() { drawFrame(V.tm); }

  function renderInspector() {
    if (!inspector) return;
    inspector.textContent = '';
    const s = selected();
    if (!s) { inspectorProject(); return; }
    if (s.type === 'clip') inspectorClip(s.o); else if (s.type === 'text') inspectorText(s.o); else inspectorMusic(s.o);
  }
  function inspectorProject() {
    const box = inspector;
    box.appendChild(mk('h4', { text: t('v_project') }));
    const cur = SIZES.findIndex(s => s[1] === V.out.w && s[2] === V.out.h);
    box.appendChild(ctlSelect(t('v_res'), SIZES.map((s, i) => ({ v: String(i), label: s[0] })), String(cur < 0 ? 1 : cur), v => {
      const s = SIZES[parseInt(v, 10)]; pushHistory(); V.out = { w: s[1], h: s[2], fps: V.out.fps }; applyOut(); seek(V.tm);
    }));
    box.appendChild(ctlSelect(t('v_fps'), [{ v: '24', label: '24' }, { v: '30', label: '30' }, { v: '60', label: '60' }], String(V.out.fps), v => { V.out.fps = parseInt(v, 10); }));
    box.appendChild(ctlSelect(t('v_format'), [{ v: 'mp4', label: 'MP4' }, { v: 'webm', label: 'WebM' }], V.format, v => { V.format = v; }));
    box.appendChild(ctlSelect(t('v_quality'), [{ v: 'low', label: t('q_low') }, { v: 'med', label: t('q_med') }, { v: 'high', label: t('q_high') }], V.quality, v => { V.quality = v; }));
    box.appendChild(mk('p', { class: 'hint', text: t('v_export_note') }));
    box.appendChild(mk('p', { class: 'hint', text: t('v_tip') }));
  }
  function headerFor(titleKey, o) {
    const box = inspector;
    box.appendChild(mk('h4', { text: t(titleKey) }));
    box.appendChild(ctlButtons([
      ibtn('trash', 'v_delete', deleteSelected, 'danger'),
      ibtn('copy', 'lay_dup', dupSelected)
    ]));
  }
  function inspectorClip(c) {
    const box = inspector, m = V.media[c.mid], isImg = m.kind === 'image';
    box.appendChild(mk('h4', { text: t(isImg ? 'v_photo_clip' : 'v_video_clip') + ' — ' + m.name }));
    box.appendChild(ctlButtons([
      tbtn('v_split', splitAtPlayhead, 'split'),
      mk('span', { dir: 'ltr', style: { display: 'inline-flex' } }, ibtn('left', 'v_move_left', () => moveClip(-1)), ibtn('right', 'v_move_right', () => moveClip(1))),
      ibtn('copy', 'lay_dup', dupSelected), ibtn('trash', 'v_delete', deleteSelected, 'danger')
    ]));
    if (isImg) {
      box.appendChild(ctlNumber(t('v_duration'), +c.out.toFixed(2), 0.5, 600, 0.1, v => { pushHistory(); c.out = v; renderAll(); seek(V.tm); }));
    } else {
      box.appendChild(ctlNumber(t('v_trim_in'), +c.in.toFixed(2), 0, +(c.out - 0.1).toFixed(2), 0.1, v => { pushHistory(); c.in = Math.min(v, c.out - 0.1); renderAll(); seek(V.tm); }));
      box.appendChild(ctlNumber(t('v_trim_out'), +c.out.toFixed(2), 0.1, +m.dur.toFixed(2), 0.1, v => { pushHistory(); c.out = Math.max(v, c.in + 0.1); renderAll(); seek(V.tm); }));
      box.appendChild(ctlButtons([
        tbtn('v_set_in', () => { pushHistory(); c.in = clamp(srcTimeAtPlayhead(c), 0, c.out - 0.1); renderAll(); seek(V.tm); }),
        tbtn('v_set_out', () => { pushHistory(); c.out = clamp(srcTimeAtPlayhead(c), c.in + 0.1, m.dur); renderAll(); seek(V.tm); })
      ]));
      const spd = ctlRange(t('v_speed'), 0.25, 4, 0.05, c.speed, v => { pushHistory('spd' + c.id); c.speed = v; renderTimeline(); seek(clamp(V.tm, 0, total())); }, v => v.toFixed(2) + '×');
      box.appendChild(spd);
      box.appendChild(ctlButtons([0.5, 1, 1.5, 2].map(v => mk('button', { class: 'btn', type: 'button', text: v + '×', onclick: () => { pushHistory(); c.speed = v; spd.setValue(v); renderAll(); seek(V.tm); } }))));
      box.appendChild(ctlRange(t('v_volume'), 0, 200, 1, Math.round(c.vol * 100), v => { pushHistory('vol' + c.id); c.vol = v / 100; setGain(m, c.vol); }, v => v + '%'));
    }
    box.appendChild(ctlRange(t('v_fade_in'), 0, 3, 0.1, c.fadeIn, v => { pushHistory('fi' + c.id); c.fadeIn = v; redrawNow(); }, v => v.toFixed(1) + 's'));
    box.appendChild(ctlRange(t('v_fade_out'), 0, 3, 0.1, c.fadeOut, v => { pushHistory('fo' + c.id); c.fadeOut = v; redrawNow(); }, v => v.toFixed(1) + 's'));
    box.appendChild(mk('h4', { text: t('v_filters') }));
    const sliders = {};
    const grid = mk('div', { class: 'pgrid' });
    PRESETS.forEach(p => grid.appendChild(mk('button', {
      class: 'btn sm', type: 'button', text: t('flt_' + p.id),
      onclick: () => { pushHistory(); c.adj = Object.assign(defAdj(), p.v); ADJ.forEach(a => sliders[a[0]].setValue(c.adj[a[0]])); redrawNow(); }
    })));
    box.appendChild(grid);
    ADJ.forEach(a => {
      sliders[a[0]] = ctlRange(t('adj_' + a[0]), a[1], a[2], 1, c.adj[a[0]], v => { pushHistory('adj' + c.id); c.adj[a[0]] = v; redrawNow(); }, v => String(v));
      box.appendChild(sliders[a[0]]);
    });
    box.appendChild(ctlButtons([
      tbtn('v_filter_all', () => { pushHistory(); V.clips.forEach(o => { o.adj = Object.assign({}, c.adj); }); redrawNow(); toast(t('v_done')); }),
      tbtn('adj_reset', () => { pushHistory(); c.adj = defAdj(); renderInspector(); redrawNow(); })
    ]));
    if (!GLR.ok) box.appendChild(mk('p', { class: 'hint warn', text: t('v_no_gl') }));
  }
  function inspectorText(tx) {
    const box = inspector;
    box.appendChild(mk('h4', { text: t('v_text_clip') }));
    box.appendChild(ctlButtons([ibtn('copy', 'lay_dup', dupSelected), ibtn('trash', 'v_delete', deleteSelected, 'danger')]));
    const upd = fn => v => { pushHistory('tx' + tx.id); fn(v); redrawNow(); renderTimeline(); };
    box.appendChild(ctlText(t('txt_content'), tx.text, upd(v => { tx.text = v; }), true));
    box.appendChild(ctlSelect(t('txt_font'), FONTS.map(f => ({ v: f[1], label: f[0] })), tx.font, upd(v => { tx.font = v; })));
    box.appendChild(ctlRange(t('txt_size'), 2, 30, 0.5, tx.size, upd(v => { tx.size = v; }), v => v + '%'));
    box.appendChild(ctlColor(t('txt_color'), tx.color, upd(v => { tx.color = v; })));
    box.appendChild(ctlButtons([
      mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.bold, onchange: e => upd(v => { tx.bold = v; })(e.target.checked) }), mk('span', { text: t('txt_bold') })),
      mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.italic, onchange: e => upd(v => { tx.italic = v; })(e.target.checked) }), mk('span', { text: t('txt_italic') })),
      mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.shadow, onchange: e => upd(v => { tx.shadow = v; })(e.target.checked) }), mk('span', { text: t('txt_shadow') }))
    ]));
    box.appendChild(ctlRange(t('txt_stroke'), 0, 20, 1, tx.strokeW, upd(v => { tx.strokeW = v; }), v => v + 'px'));
    box.appendChild(ctlColor(t('txt_strokecolor'), tx.strokeColor, upd(v => { tx.strokeColor = v; })));
    box.appendChild(ctlCheck(t('txt_bg'), !!tx.bg, upd(v => { tx.bg = v ? '#000000' : ''; })));
    box.appendChild(ctlCheck(t('v_text_fade'), tx.anim === 'fade', upd(v => { tx.anim = v ? 'fade' : 'none'; })));
    box.appendChild(ctlRange(t('v_pos_x'), 0, 100, 1, Math.round(tx.x * 100), upd(v => { tx.x = v / 100; }), v => v + '%'));
    box.appendChild(ctlRange(t('v_pos_y'), 0, 100, 1, Math.round(tx.y * 100), upd(v => { tx.y = v / 100; }), v => v + '%'));
    box.appendChild(ctlNumber(t('v_t_start'), +tx.start.toFixed(2), 0, 36000, 0.1, v => { pushHistory(); tx.start = Math.min(v, tx.end - 0.2); renderAll(); seek(V.tm); }));
    box.appendChild(ctlNumber(t('v_t_end'), +tx.end.toFixed(2), 0.2, 36000, 0.1, v => { pushHistory(); tx.end = Math.max(v, tx.start + 0.2); renderAll(); seek(V.tm); }));
    box.appendChild(mk('p', { class: 'hint', text: t('v_text_drag') }));
  }
  function inspectorMusic(mu) {
    const box = inspector, m = V.media[mu.mid];
    box.appendChild(mk('h4', { text: t('v_music_clip') + ' — ' + m.name }));
    box.appendChild(ctlButtons([ibtn('trash', 'v_delete', deleteSelected, 'danger')]));
    box.appendChild(ctlRange(t('v_volume'), 0, 200, 1, Math.round(mu.vol * 100), v => { pushHistory('mv' + mu.id); mu.vol = v / 100; setGain(m, mu.vol); }, v => v + '%'));
    box.appendChild(ctlRange(t('v_fade_in'), 0, 10, 0.1, mu.fadeIn, v => { pushHistory('mfi' + mu.id); mu.fadeIn = v; }, v => v.toFixed(1) + 's'));
    box.appendChild(ctlRange(t('v_fade_out'), 0, 10, 0.1, mu.fadeOut, v => { pushHistory('mfo' + mu.id); mu.fadeOut = v; }, v => v.toFixed(1) + 's'));
    box.appendChild(ctlNumber(t('v_m_start'), +mu.start.toFixed(2), 0, 36000, 0.1, v => { pushHistory(); mu.start = v; renderAll(); seek(V.tm); }));
    box.appendChild(ctlNumber(t('v_trim_in'), +mu.in.toFixed(2), 0, +(mu.out - 0.2).toFixed(2), 0.1, v => { pushHistory(); mu.in = Math.min(v, mu.out - 0.2); renderAll(); seek(V.tm); }));
    box.appendChild(ctlNumber(t('v_trim_out'), +mu.out.toFixed(2), 0.2, +m.dur.toFixed(2), 0.1, v => { pushHistory(); mu.out = Math.max(v, mu.in + 0.2); renderAll(); seek(V.tm); }));
  }

  /* ============================ export ============================ */
  function pickMime(pref) {
    const mp4 = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4;codecs=h264,aac', 'video/mp4'];
    const webm = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    const list = pref === 'mp4' ? mp4.concat(webm) : webm.concat(mp4);
    for (const x of list) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported(x)) {
        const isMp4 = x.indexOf('video/mp4') === 0;
        return { type: x, base: isMp4 ? 'video/mp4' : 'video/webm', ext: isMp4 ? 'mp4' : 'webm', fellBack: (pref === 'mp4') !== isMp4 };
      }
    }
    return null;
  }
  function bitrate() {
    const mul = V.quality === 'low' ? 0.6 : V.quality === 'high' ? 1.8 : 1;
    return Math.round(clamp(V.out.w * V.out.h * V.out.fps * 0.07 * mul, 1e6, 25e6));
  }
  function openExportDialog() {
    if (!V.clips.length) { toast(t('v_need_clip')); return; }
    if (EX.active) return;
    openModal(t('v_export'), mk('div', { class: 'form' },
      mk('p', { text: t('v_export_sum', { w: V.out.w, h: V.out.h, fps: V.out.fps, fmt: V.format.toUpperCase(), dur: fmtTime(total()) }) }),
      mk('p', { class: 'hint', text: t('v_export_note') })), [
      { label: t('act_cancel') },
      { label: t('v_export_start'), primary: true, onClick: () => { setTimeout(startExport, 50); } }
    ]);
  }
  function updateExportUI() {
    if (!EX.ui) return;
    const p = clamp(V.tm / Math.max(total(), 0.01), 0, 1);
    EX.ui.bar.style.width = (p * 100).toFixed(1) + '%';
    EX.ui.txt.textContent = Math.round(p * 100) + '%  ·  ' + fmtTime(V.tm) + ' / ' + fmtTime(total());
  }
  async function startExport() {
    if (EX.active || !V.clips.length) return;
    if (!window.MediaRecorder || !cv.captureStream) { toast(t('v_no_rec'), 6000); return; }
    const mime = pickMime(V.format);
    if (!mime) { toast(t('v_no_rec'), 6000); return; }
    ensureAudio();
    if (AC && AC.state === 'suspended') { try { await AC.resume(); } catch (e) { /* ignore */ } }
    pause();
    const bar = mk('div', { class: 'bar' }), fill = mk('i', {}), txt = mk('p', { class: 'hint', text: '0%' });
    bar.appendChild(fill);
    const body = mk('div', { class: 'form' }, mk('p', { text: t('v_exporting') }), bar, txt, mk('p', { class: 'hint', text: t('v_keep_visible') }));
    const dlg = openModal(t('v_export'), body, [{ label: t('act_cancel'), onClick: () => { cancelExport(); } }], { locked: true });
    EX.ui = { dlg: dlg, bar: fill, txt: txt };
    EX.active = true; EX.cancelled = false; EX.chunks = []; EX.mime = mime;
    V.tm = 0;
    syncMedia(0, false);
    const a0 = activeIn(layout(), 0);
    if (a0) { const m0 = V.media[a0.c.mid]; if (m0.kind === 'video') await seekEl(m0.el, a0.c.in); }
    drawFrame(0);
    const stream = cv.captureStream(V.out.fps);
    if (recDest) { const at = recDest.stream.getAudioTracks()[0]; if (at) stream.addTrack(at); }
    let rec;
    try {
      rec = new MediaRecorder(stream, { mimeType: mime.type, videoBitsPerSecond: bitrate(), audioBitsPerSecond: 192000 });
    } catch (e) { endExportUI(); toast(t('v_no_rec'), 6000); return; }
    EX.rec = rec;
    rec.ondataavailable = ev => { if (ev.data && ev.data.size) EX.chunks.push(ev.data); };
    rec.onstop = () => finishExport();
    if (spk) spk.gain.value = 0;
    EX.onEnd = () => setTimeout(() => { if (rec.state !== 'inactive') rec.stop(); }, 500);
    rec.start(500);
    V.playing = true; V.lastNow = performance.now();
    requestAnimationFrame(tick);
  }
  function cancelExport() {
    if (!EX.active) return;
    EX.cancelled = true;
    V.playing = false; pauseAllMedia();
    if (EX.rec && EX.rec.state !== 'inactive') { try { EX.rec.stop(); } catch (e) { endExportUI(); } } else endExportUI();
  }
  function endExportUI() {
    if (spk) spk.gain.value = 1;
    EX.active = false; EX.onEnd = null; EX.rec = null;
    if (EX.ui && EX.ui.dlg && EX.ui.dlg.open) EX.ui.dlg.close();
    EX.ui = null;
    V.playing = false; pauseAllMedia();
    seek(Math.min(V.tm, total()));
  }
  function finishExport() {
    const cancelled = EX.cancelled, chunks = EX.chunks, mime = EX.mime;
    endExportUI();
    if (cancelled) { toast(t('v_export_cancelled')); return; }
    if (!chunks.length) { toast(t('v_export_fail')); return; }
    const blob = new Blob(chunks, { type: mime.base });
    const d = new Date(), p2 = n => (n < 10 ? '0' : '') + n;
    downloadBlob(blob, 'video-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.' + mime.ext);
    toast(V.format === 'mp4' && mime.ext !== 'mp4' ? t('v_webm_fallback') : t('v_export_done', { ext: mime.ext.toUpperCase() }), 6000);
  }

  /* ============================ preview interaction ============================ */
  function previewPoint(e) {
    const r = cv.getBoundingClientRect();
    return { x: (e.clientX - r.left) * V.out.w / r.width, y: (e.clientY - r.top) * V.out.h / r.height };
  }
  function onPreviewDown(e) {
    if (EX.active) return;
    const p = previewPoint(e);
    for (let i = V.texts.length - 1; i >= 0; i--) {
      const tx = V.texts[i], b = tx._bb;
      if (b && p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h) {
        V.sel = { type: 'text', id: tx.id }; renderAll();
        const x0 = tx.x, y0 = tx.y; let pushed = false;
        const px0 = e.clientX, py0 = e.clientY, r = cv.getBoundingClientRect();
        trackDrag(e, (dx, ev) => {
          if (!pushed && (Math.abs(dx) > 2 || Math.abs(ev.clientY - py0) > 2)) { pushHistory(); pushed = true; }
          if (!pushed) return;
          tx.x = clamp(x0 + (ev.clientX - px0) / r.width, 0, 1); tx.y = clamp(y0 + (ev.clientY - py0) / r.height, 0, 1);
          drawFrame(V.tm);
        }, () => { renderInspector(); });
        return;
      }
    }
  }

  /* ============================ build UI ============================ */
  function buildToolbar() {
    const bar = $('#vBar');
    bar.textContent = '';
    undoBtn = ibtn('undo', 'act_undo', undo); redoBtn = ibtn('redo', 'act_redo', redo);
    const zoom = mk('input', { type: 'range', min: 10, max: 300, step: 5, value: V.pps, class: 'tlzoom', title: t('v_tl_zoom'), oninput: e => { V.pps = parseInt(e.target.value, 10); scheduleTimeline(); } });
    bar.append(
      tbtn('v_add_media', () => visFiles.click(), 'film'),
      tbtn('v_add_music', () => musicFiles.click(), 'music'),
      tbtn('v_add_text', addText, 'text'),
      mk('i', { class: 'sep' }),
      tbtn('v_split', splitAtPlayhead, 'split'),
      ibtn('trash', 'v_delete', deleteSelected, 'danger'),
      undoBtn, redoBtn,
      mk('i', { class: 'sep' }),
      mk('span', { class: 'zl', text: t('v_tl_zoom') }), zoom,
      mk('span', { class: 'grow' }),
      tbtn('v_export', openExportDialog, 'save', 'primary'));
    updateUndo();
  }
  function buildTransport() {
    const tr = $('#vTransport');
    tr.textContent = '';
    playBtn = mk('button', { class: 'ib big', type: 'button', title: t('v_play'), 'aria-label': t('v_play'), onclick: () => { if (V.playing) pause(); else play(); } });
    seekInp = mk('input', {
      type: 'range', min: 0, max: 1, step: 0.01, value: 0, class: 'seek', dir: 'ltr',
      oninput: e => { if (V.playing) pause(); seek(parseFloat(e.target.value)); }
    });
    timeLbl = mk('span', { class: 'tm', dir: 'ltr', text: '0:00.0 / 0:00.0' });
    tr.append(ibtn('skipback', 'v_to_start', () => { pause(); seek(0); }), playBtn, seekInp, timeLbl);
    updateTransport();
  }
  function init() {
    root = $('#videoApp'); cv = $('#vCanvas'); emptyBox = $('#vEmpty'); inspector = $('#vInspector');
    tlScroll = $('#tlScroll'); tlInner = $('#tlInner'); tlRuler = $('#tlRuler'); laneV = $('#laneV'); laneT = $('#laneT'); laneM = $('#laneM'); tlHead = $('#tlHead');
    visFiles = $('#vFiles'); musicFiles = $('#vMusic');
    cg = cv.getContext('2d');
    GLR.init(); applyOut();
    visFiles.addEventListener('change', () => { addVisualFiles(visFiles.files); visFiles.value = ''; });
    musicFiles.addEventListener('change', () => { addMusicFiles(musicFiles.files); musicFiles.value = ''; });
    $('#vEmptyAdd').addEventListener('click', () => visFiles.click());
    cv.addEventListener('pointerdown', onPreviewDown);
    tlRuler.addEventListener('pointerdown', e => {
      if (V.playing) pause();
      seek(timeFromEvent(e));
      trackDrag(e, (dx, ev) => seek(timeFromEvent(ev)));
    });
    [laneV, laneT, laneM].forEach(l => l.addEventListener('pointerdown', e => {
      if (e.target === l) { V.sel = null; renderInspector(); renderTimeline(); }
    }));
    tlScroll.addEventListener('wheel', e => {
      if (e.ctrlKey || e.metaKey) { e.preventDefault(); V.pps = clamp(Math.round(V.pps * (e.deltaY < 0 ? 1.15 : 1 / 1.15)), 10, 300); const z = $('.tlzoom'); if (z) z.value = V.pps; renderTimeline(); }
    }, { passive: false });
    const sec = $('#videoApp');
    ['dragenter', 'dragover'].forEach(n => sec.addEventListener(n, e => { e.preventDefault(); }));
    sec.addEventListener('drop', e => {
      e.preventDefault();
      const fl = Array.from(e.dataTransfer.files || []);
      const aud = fl.filter(f => f.type.indexOf('audio/') === 0), vis = fl.filter(f => f.type.indexOf('audio/') !== 0);
      if (vis.length) addVisualFiles(vis);
      if (aud.length) addMusicFiles(aud);
    });
    document.addEventListener('visibilitychange', () => { if (document.hidden && EX.active) toast(t('v_keep_visible'), 5000); });
    relang();
  }
  function relang() {
    if (!cv) return;
    buildToolbar(); buildTransport(); renderAll();
    $$('[data-vl]').forEach(n => { n.textContent = t(n.getAttribute('data-vl')); });
  }
  function show(v) {
    visible = v;
    if (v) { applyOut(); renderAll(); seek(V.tm); } else { if (V.playing && !EX.active) pause(); }
  }
  function onKey(e) {
    if (!visible) return false;
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || tag === 'BUTTON') return false;
    if (document.querySelector('dialog[open]')) return false;
    const k = keyOf(e);
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return true; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); return true; }
    if (e.ctrlKey || e.metaKey || e.altKey) return false;
    if (k === ' ') { e.preventDefault(); if (V.playing) pause(); else play(); return true; }
    if (k === 's') { splitAtPlayhead(); return true; }
    if (k === 'delete' || k === 'backspace') { deleteSelected(); return true; }
    if (k === 'arrowleft') { pause(); seek(V.tm - (e.shiftKey ? 1 : 0.1)); return true; }
    if (k === 'arrowright') { pause(); seek(V.tm + (e.shiftKey ? 1 : 0.1)); return true; }
    return false;
  }

  return {
    init: init, relang: relang, show: show, onKey: onKey, addVisualFiles: addVisualFiles, addMusicFiles: addMusicFiles,
    _V: V, _api: { addVisualFiles, addMusicFiles, splitAtPlayhead, seek, play, pause, startExport, addText, deleteSelected, undo, redo, total, layout, renderAll, GLR, EX }
  };
})();
