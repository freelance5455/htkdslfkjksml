'use strict';
/* Bootstrap: mode switching, language switching, keyboard routing */
const StudioApp = (function () {
  let mode = 'photo';
  const MODES = { photo: ['#photoApp', '#navPhoto'], video: ['#videoApp', '#navVideo'], ai: ['#aiApp', '#navAi'] };

  function setMode(m) {
    if (!MODES[m]) return;
    mode = m;
    Object.keys(MODES).forEach(k => {
      $(MODES[k][0]).hidden = k !== m;
      $(MODES[k][1]).classList.toggle('active', k === m);
    });
    Photo.show(m === 'photo');
    Video.show(m === 'video');
    AI.show(m === 'ai');
  }

  function relangAll() {
    applyDir();
    Photo.relang();
    Video.relang();
    AI.relang();
  }

  function boot() {
    applyDir();
    Photo.init();
    Video.init();
    AI.init();
    Object.keys(MODES).forEach(k => $(MODES[k][1]).addEventListener('click', () => setMode(k)));
    $('#langBtn').addEventListener('click', () => { setLang(LANG === 'fa' ? 'en' : 'fa'); relangAll(); });
    $('#pEmptyOpen').addEventListener('click', () => $('#pFile').click());
    $('#pEmptyNew').addEventListener('click', () => {
      // reuse the toolbar "New" dialog
      const b = $('#pActions .btn');
      if (b) b.click();
    });
    document.addEventListener('keydown', e => {
      if (mode === 'photo') Photo.onKey(e); else if (mode === 'video') Video.onKey(e);
    });
    window.addEventListener('beforeunload', e => {
      if (Photo._S.layers.length || Video._V.clips.length) { e.preventDefault(); e.returnValue = ''; }
    });
    setMode('photo');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
  return { setMode: setMode };
})();
