'use strict';
/* ===================================================================
   AI studio tab: talks to the FastAPI backend (same origin).
   Image generation -> photo editor layer. Speech -> video timeline.
   The rest of the editor works without the backend.
   =================================================================== */
const AI = (function () {
  const S = { cfg: null, busy: { img: false, aud: false }, img: null, aud: null, imgUrl: '', audUrl: '', size: '1024x1024', voice: 'alloy', prompt: '', text: '', style: '' };
  let root, visible = false;
  const refs = {};

  const isFile = () => location.protocol === 'file:';
  function b64ToBlob(b64, mime) {
    const bin = atob(b64), n = bin.length, arr = new Uint8Array(n);
    for (let i = 0; i < n; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime });
  }
  async function call(path, body) {
    const r = await fetch(path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
    let d = null;
    try { d = await r.json(); } catch (e) { /* non-JSON error page */ }
    if (!r.ok) {
      let msg = d && d.detail;
      if (Array.isArray(msg)) msg = msg.map(x => x.msg).join('; ');
      throw new Error(msg || ('HTTP ' + r.status));
    }
    return d;
  }
  function setStatus(id, msg, err) {
    const el = refs[id];
    if (!el) return;
    el.textContent = msg || '';
    el.classList.toggle('error', !!err);
  }

  async function checkConfig() {
    if (!refs.notice) return;
    if (isFile()) { S.cfg = { ok: false }; refs.notice.textContent = t('ai_file_mode'); return; }
    refs.notice.textContent = t('ai_checking');
    try {
      const d = await call('api/config');
      S.cfg = { ok: true, ai: !!d.ai_configured };
      refs.notice.textContent = d.ai_configured ? t('ai_configured') : t('ai_not_configured');
    } catch (e) {
      S.cfg = { ok: false };
      refs.notice.textContent = t('ai_offline');
    }
  }

  /* ---------- send results to the editors ---------- */
  function toFile(blob, name) { return new File([blob], name, { type: blob.type }); }
  async function sendImage(blob, name) {
    StudioApp.setMode('photo');
    await Photo.openFiles([toFile(blob, name || 'ai-image.png')]);
    toast(t('ai_sent_photo'));
  }
  async function sendAudio(blob, name) {
    StudioApp.setMode('video');
    await Video.addMusicFiles([toFile(blob, name || 'ai-voice.mp3')]);
    toast(t('ai_sent_video'));
  }
  async function sendImageToVideo(blob, name) {
    StudioApp.setMode('video');
    await Video.addVisualFiles([toFile(blob, name || 'ai-image.png')]);
    toast(t('ai_sent_video'));
  }
  async function fetchBlob(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.blob();
  }

  /* ---------- generation ---------- */
  async function genImage() {
    const prompt = S.prompt.trim();
    if (!prompt) { setStatus('imgStatus', t('ai_prompt_req'), true); return; }
    if (S.busy.img) return;
    S.busy.img = true; refs.imgBtn.disabled = true;
    setStatus('imgStatus', t('ai_working'));
    try {
      const d = await call('api/generate-image', { prompt: prompt, size: S.size });
      S.img = b64ToBlob(d.image_data, d.mime_type || 'image/png');
      if (S.imgUrl) URL.revokeObjectURL(S.imgUrl);
      S.imgUrl = URL.createObjectURL(S.img);
      refs.imgPrev.src = S.imgUrl; refs.imgPrev.hidden = false; refs.imgActs.hidden = false;
      setStatus('imgStatus', t('ai_done'));
      loadHistory();
    } catch (e) {
      setStatus('imgStatus', t('ai_failed') + e.message, true);
    } finally { S.busy.img = false; refs.imgBtn.disabled = false; }
  }
  async function genAudio() {
    const text = S.text.trim();
    if (!text) { setStatus('audStatus', t('ai_text_req'), true); return; }
    if (S.busy.aud) return;
    S.busy.aud = true; refs.audBtn.disabled = true;
    setStatus('audStatus', t('ai_working'));
    try {
      const d = await call('api/generate-audio', { text: text, voice: S.voice, instructions: S.style.trim() || null });
      S.aud = b64ToBlob(d.audio_data, d.mime_type || 'audio/mpeg');
      if (S.audUrl) URL.revokeObjectURL(S.audUrl);
      S.audUrl = URL.createObjectURL(S.aud);
      refs.audPlay.src = S.audUrl; refs.audPlay.hidden = false; refs.audActs.hidden = false;
      setStatus('audStatus', t('ai_done'));
      loadHistory();
    } catch (e) {
      setStatus('audStatus', t('ai_failed') + e.message, true);
    } finally { S.busy.aud = false; refs.audBtn.disabled = false; }
  }

  /* ---------- history ---------- */
  async function loadHistory() {
    const box = refs.hist;
    if (!box) return;
    if (isFile() || !(S.cfg && S.cfg.ok)) { box.textContent = ''; return; }
    try {
      const d = await call('api/history?limit=10');
      box.textContent = '';
      if (!d.items.length) { box.appendChild(mk('p', { class: 'hint', text: t('ai_no_hist') })); return; }
      d.items.forEach(item => {
        const kind = item.kind === 'image' ? t('ai_kind_image') : t('ai_kind_audio');
        let when = item.created_at;
        try { when = new Date(item.created_at).toLocaleString(LANG === 'fa' ? 'fa-IR' : 'en-US'); } catch (e) { /* keep raw */ }
        const row = mk('div', { class: 'hitem' },
          mk('b', { text: kind + ' · ' + item.status }), mk('span', { class: 'tag', text: when }),
          mk('p', { class: 'hint', text: item.prompt }));
        if (item.error_message) row.appendChild(mk('p', { class: 'hint warn', text: item.error_message }));
        if (item.file_name) {
          const url = 'api/files/' + encodeURIComponent(item.file_name);
          const acts = mk('div', { class: 'btnrow' });
          acts.appendChild(mk('a', { class: 'btn sm', href: url, download: item.file_name, text: t('ai_download') }));
          acts.appendChild(tbtn(item.kind === 'image' ? 'ai_to_photo' : 'ai_to_video', async () => {
            try {
              const b = await fetchBlob(url);
              if (item.kind === 'image') await sendImage(b, item.file_name); else await sendAudio(b, item.file_name);
            } catch (e) { toast(t('ai_failed') + e.message); }
          }, null, 'sm'));
          row.appendChild(acts);
        }
        box.appendChild(row);
      });
    } catch (e) { box.textContent = t('ai_hist_fail'); }
  }

  /* ---------- UI ---------- */
  function dlLink(getBlob, name, key) {
    return mk('button', { class: 'btn', type: 'button', onclick: () => { const b = getBlob(); if (b) downloadBlob(b, name); }, text: t(key) });
  }
  function build() {
    root.textContent = '';
    const sizes = [{ v: '1024x1024', label: t('ai_size_sq') }, { v: '1536x1024', label: t('ai_size_land') }, { v: '1024x1536', label: t('ai_size_port') }];
    const voices = ['alloy', 'ash', 'coral', 'echo', 'fable', 'onyx', 'nova', 'sage', 'shimmer'].map(v => ({ v: v, label: v.charAt(0).toUpperCase() + v.slice(1) }));

    refs.notice = mk('div', { class: 'notice', text: t('ai_checking') });

    /* image card */
    const pr = ctlText(t('ai_prompt'), S.prompt, v => { S.prompt = v; }, true);
    pr.input.maxLength = 4000; pr.input.placeholder = t('ai_prompt_ph');
    refs.imgBtn = tbtn('ai_img_btn', genImage, 'wand', 'primary');
    refs.imgStatus = mk('div', { class: 'status', role: 'status' });
    refs.imgPrev = mk('img', { class: 'aiprev', alt: '', hidden: true });
    refs.imgActs = mk('div', { class: 'btnrow', hidden: true },
      tbtn('ai_to_photo', () => { if (S.img) sendImage(S.img); }, 'image', 'primary'),
      tbtn('ai_to_video', () => { if (S.img) sendImageToVideo(S.img); }, 'film'),
      dlLink(() => S.img, 'ai-image.png', 'ai_download'));
    if (S.imgUrl) { refs.imgPrev.src = S.imgUrl; refs.imgPrev.hidden = false; refs.imgActs.hidden = false; }
    const imgCard = mk('article', { class: 'card' },
      mk('h3', { text: t('ai_img_title') }), mk('p', { class: 'hint', text: t('ai_img_sub') }),
      pr, ctlSelect(t('ai_size'), sizes, S.size, v => { S.size = v; }),
      mk('div', { class: 'btnrow' }, refs.imgBtn), refs.imgStatus, refs.imgPrev, refs.imgActs);

    /* voice card */
    const tx = ctlText(t('ai_text'), S.text, v => { S.text = v; }, true);
    tx.input.maxLength = 5000; tx.input.placeholder = t('ai_text_ph');
    const st = ctlText(t('ai_style'), S.style, v => { S.style = v; }, false);
    st.input.maxLength = 1000; st.input.placeholder = t('ai_style_ph');
    refs.audBtn = tbtn('ai_aud_btn', genAudio, 'music', 'primary');
    refs.audStatus = mk('div', { class: 'status', role: 'status' });
    refs.audPlay = mk('audio', { controls: true, hidden: true, class: 'aiaudio' });
    refs.audActs = mk('div', { class: 'btnrow', hidden: true },
      tbtn('ai_to_video', () => { if (S.aud) sendAudio(S.aud); }, 'film', 'primary'),
      dlLink(() => S.aud, 'ai-voice.mp3', 'ai_download'));
    if (S.audUrl) { refs.audPlay.src = S.audUrl; refs.audPlay.hidden = false; refs.audActs.hidden = false; }
    const audCard = mk('article', { class: 'card' },
      mk('h3', { text: t('ai_aud_title') }), mk('p', { class: 'hint', text: t('ai_aud_sub') }),
      tx, ctlSelect(t('ai_voice'), voices, S.voice, v => { S.voice = v; }), st,
      mk('div', { class: 'btnrow' }, refs.audBtn), refs.audStatus, refs.audPlay, refs.audActs);

    refs.hist = mk('div', { class: 'hlist' });
    const histCard = mk('article', { class: 'card wide' },
      mk('h3', { text: t('ai_hist_title') }), mk('p', { class: 'hint', text: t('ai_hist_sub') }),
      mk('div', { class: 'btnrow' }, tbtn('ai_refresh', loadHistory)), refs.hist);

    root.append(mk('div', { class: 'aiwrap' }, refs.notice, mk('div', { class: 'aigrid' }, imgCard, audCard), histCard, mk('p', { class: 'hint ctr', text: t('ai_footer') })));
  }

  function init() { root = $('#aiApp'); build(); }
  function relang() { if (!root) return; build(); if (visible) { checkConfig().then(loadHistory); } }
  function show(v) { visible = v; if (v) checkConfig().then(loadHistory); }
  return { init: init, relang: relang, show: show };
})();
