'use strict';
/* ===================================================================
   Shared helpers: DOM builder, icons, controls, modal, files
   =================================================================== */
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

function appendKid(parent, k) {
  if (k === null || k === undefined || k === false) return;
  if (Array.isArray(k)) { k.forEach(x => appendKid(parent, x)); return; }
  if (k instanceof Node) { parent.appendChild(k); return; }
  parent.appendChild(document.createTextNode(String(k)));
}

/* mk(tag, attrs, ...children) */
function mk(tag, attrs) {
  const node = document.createElement(tag);
  let value;
  if (attrs) {
    for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
      else if (k === 'text') node.textContent = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'value') value = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'hidden') node[k] = true;
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    }
  }
  for (let i = 2; i < arguments.length; i++) appendKid(node, arguments[i]);
  if (value !== undefined) node.value = value;
  return node;
}

/* ---------- icons (24px stroke icons) ---------- */
const ICONS = {
  move: '<path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/>',
  hand: '<path d="M8 13V6a1.5 1.5 0 0 1 3 0v5M11 11V4.5a1.5 1.5 0 0 1 3 0V11M14 11V6a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-1a6 6 0 0 1-5-3l-2-4a1.5 1.5 0 0 1 2.5-1.5L8 14"/>',
  crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14M2 6h14a2 2 0 0 1 2 2v14"/>',
  brush: '<path d="M3 21c3 0 5-1 5-4a3 3 0 0 0-3-3c-3 0-2 4-2 7zM9 15L20 4a2 2 0 0 0-3-3L7 12"/>',
  eraser: '<path d="M20 20H9L3.5 14.5a2 2 0 0 1 0-3L12 3a2 2 0 0 1 3 0l5 5a2 2 0 0 1 0 3L11 20"/>',
  wand: '<path d="M5 19L17 7M14 4l1-2 1 2 2 1-2 1-1 2-1-2-2-1zM19 11l.7-1.4L21 9l-1.3-.6L19 7l-.7 1.4L17 9l1.3.6z"/>',
  text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  mask: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="12" r="5"/>',
  undo: '<path d="M3 7v6h6M3 13a9 9 0 1 0 3-7"/>',
  redo: '<path d="M21 7v6h-6M21 13a9 9 0 1 1-3-7"/>',
  open: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  save: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
  newdoc: '<path d="M6 2h8l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zM14 2v5h5M12 11v6M9 14h6"/>',
  zin: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M11 8v6M8 11h6"/>',
  zout: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5M8 11h6"/>',
  fit: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  rotl: '<path d="M3 4v6h6M3 10a9 9 0 1 1 2 6"/>',
  rotr: '<path d="M21 4v6h-6M21 10a9 9 0 1 0-2 6"/>',
  fliph: '<path d="M12 3v18M8 7L3 12l5 5zM16 7l5 5-5 5z"/>',
  flipv: '<path d="M3 12h18M7 8l5-5 5 5zM7 16l5 5 5-5z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
  up: '<path d="M6 15l6-6 6 6"/>',
  down: '<path d="M6 9l6 6 6-6"/>',
  left: '<path d="M15 6l-6 6 6 6"/>',
  right: '<path d="M9 6l6 6-6 6"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 7.5C3.7 9.3 2 12 2 12s4 7 10 7c1.6 0 3-.4 4.3-1M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  play: '<path d="M7 4l13 8-13 8z" fill="currentColor"/>',
  pause: '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
  split: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M8.1 8.1L20 20M20 4L8.1 15.9"/>',
  music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  film: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 4v16M17 4v16M3 9h4M3 15h4M17 9h4M17 15h4"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5M3 17l9 5 9-5"/>',
  skipback: '<path d="M6 5v14M19 5L9 12l10 7z"/>',
  resize: '<path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/>',
  flatten: '<path d="M3 8l9-5 9 5-9 5zM3 16l9 5 9-5"/>',
  check: '<path d="M5 12l5 5 9-10"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>'
};

function icon(name, size) {
  const s = document.createElement('span');
  s.className = 'ic';
  const z = size || 20;
  s.innerHTML = '<svg viewBox="0 0 24 24" width="' + z + '" height="' + z + '" fill="none" stroke="currentColor" ' +
    'stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  return s;
}

/* icon button with tooltip (i18n key) */
function ibtn(iconName, titleKey, onClick, extraClass) {
  const b = mk('button', { class: 'ib ' + (extraClass || ''), type: 'button', title: t(titleKey), 'aria-label': t(titleKey), onclick: onClick });
  b.appendChild(icon(iconName, 20));
  return b;
}
/* text button (optionally with icon) */
function tbtn(labelKey, onClick, iconName, extraClass) {
  const b = mk('button', { class: 'btn ' + (extraClass || ''), type: 'button', onclick: onClick });
  if (iconName) b.appendChild(icon(iconName, 18));
  b.appendChild(mk('span', { text: t(labelKey) }));
  return b;
}

/* ---------- small helpers ---------- */
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
let _uid = 1;
const uid = () => 'i' + (_uid++);

function makeCanvas(w, hgt) {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(hgt));
  return c;
}
function cloneCanvas(src) {
  const c = makeCanvas(src.width, src.height);
  c.getContext('2d').drawImage(src, 0, 0);
  return c;
}

function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  sec = Math.round(sec * 10) / 10;
  const m = Math.floor(sec / 60);
  const s = sec - m * 60;
  return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1);
}

/* layout-independent key: works on Persian keyboards too */
function keyOf(e) {
  const c = e.code || '';
  if (/^Key[A-Z]$/.test(c)) return c.slice(3).toLowerCase();
  if (c === 'Digit0') return '0';
  if (c === 'BracketLeft') return '[';
  if (c === 'BracketRight') return ']';
  return String(e.key || '').toLowerCase();
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { a.remove(); URL.revokeObjectURL(url); }, 15000);
}

function stripExt(name) { return String(name || 'file').replace(/\.[^.]+$/, '') || 'file'; }

function hexToRgb(hex) {
  let s = String(hex || '#000000').replace('#', '');
  if (s.length === 3) s = s.split('').map(ch => ch + ch).join('');
  const n = parseInt(s, 16);
  if (isNaN(n)) return [0, 0, 0];
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
function rgba(hex, a) { const c = hexToRgb(hex); return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }

/* image file -> canvas (EXIF orientation is honoured by the browser) */
function fileToCanvas(file, maxSide) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const w = img.naturalWidth, hh = img.naturalHeight;
      if (!w || !hh) { URL.revokeObjectURL(url); reject(new Error('empty')); return; }
      const k = Math.min(1, maxSide / Math.max(w, hh));
      const c = makeCanvas(w * k, hh * k);
      const g = c.getContext('2d');
      g.imageSmoothingQuality = 'high';
      g.drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      resolve({ canvas: c, scaled: k < 1, ow: w, oh: hh });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('decode')); };
    img.src = url;
  });
}

/* ---------- toast ---------- */
let _toastTimer = 0;
function toast(msg, ms) {
  const box = $('#toast');
  if (!box) return;
  box.textContent = msg;
  box.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => box.classList.remove('show'), ms || 3200);
}

/* ---------- controls ---------- */
function ctlRange(label, min, max, step, value, onInput, fmt) {
  const out = mk('output', { text: fmt ? fmt(value) : String(value) });
  const inp = mk('input', {
    type: 'range', min: min, max: max, step: step, value: value,
    oninput: () => { const v = parseFloat(inp.value); out.textContent = fmt ? fmt(v) : String(v); onInput(v); }
  });
  const row = mk('label', { class: 'ctl' }, mk('span', { class: 'cl', text: label }), inp, out);
  row.setValue = v => { inp.value = v; out.textContent = fmt ? fmt(parseFloat(inp.value)) : inp.value; };
  return row;
}
function ctlCheck(label, checked, onChange) {
  const inp = mk('input', { type: 'checkbox', checked: !!checked, onchange: () => onChange(inp.checked) });
  return mk('label', { class: 'ctl chk' }, inp, mk('span', { text: label }));
}
function ctlColor(label, value, onInput) {
  const inp = mk('input', { type: 'color', value: value, oninput: () => onInput(inp.value) });
  return mk('label', { class: 'ctl clr' }, mk('span', { class: 'cl', text: label }), inp);
}
function ctlSelect(label, options, value, onChange) {
  const sel = mk('select', { onchange: () => onChange(sel.value) },
    options.map(o => mk('option', { value: o.v, text: o.label })));
  sel.value = value;
  return mk('label', { class: 'ctl sel' }, mk('span', { class: 'cl', text: label }), sel);
}
function ctlNumber(label, value, min, max, step, onChange) {
  const inp = mk('input', {
    type: 'number', min: min, max: max, step: step, value: value,
    onchange: () => {
      let v = parseFloat(inp.value);
      if (isNaN(v)) v = value;
      v = clamp(v, min, max);
      inp.value = v;
      onChange(v);
    }
  });
  const row = mk('label', { class: 'ctl num' }, mk('span', { class: 'cl', text: label }), inp);
  row.setValue = v => { inp.value = v; };
  return row;
}
function ctlText(label, value, onInput, multiline) {
  const inp = multiline
    ? mk('textarea', { rows: 3, oninput: () => onInput(inp.value) })
    : mk('input', { type: 'text', oninput: () => onInput(inp.value) });
  inp.value = value;
  const row = mk('label', { class: 'ctl txt' }, mk('span', { class: 'cl', text: label }), inp);
  row.input = inp;
  return row;
}
function ctlButtons(list) {
  return mk('div', { class: 'btnrow' }, list);
}

/* ---------- modal ---------- */
function openModal(title, body, actions, opts) {
  opts = opts || {};
  const dlg = mk('dialog', { class: 'modal' });
  const head = mk('div', { class: 'mh' }, mk('b', { text: title }));
  if (!opts.locked) head.appendChild(mk('button', { class: 'x', type: 'button', 'aria-label': 'close', onclick: () => dlg.close(), text: '✕' }));
  const foot = mk('div', { class: 'mf' });
  (actions || []).forEach(a => {
    foot.appendChild(mk('button', {
      class: a.primary ? 'btn primary' : 'btn', type: 'button',
      onclick: () => { if (a.onClick && a.onClick(dlg) === false) return; dlg.close(); }
    }, a.label));
  });
  dlg.append(head, mk('div', { class: 'mb' }, body), foot);
  dlg.addEventListener('close', () => dlg.remove());
  if (opts.locked) dlg.addEventListener('cancel', e => e.preventDefault());
  document.body.appendChild(dlg);
  dlg.showModal();
  return dlg;
}
