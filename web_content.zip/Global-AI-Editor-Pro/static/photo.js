'use strict';
/* ===================================================================
   Photo editor: layers, masks, adjustments & filters, crop / rotate /
   flip / resize, text, brush, eraser, magic background eraser.
   Plain canvas, no external libraries.
   =================================================================== */
const Photo = (function () {
  const MAXSIDE = 4096;
  const PAD = 40;                 // overlay margin (css px) around the document so edge handles stay clickable
  const MAXDOC = 8000;
  let nextId = 1;

  const S = {
    w: 0, h: 0, bg: null, layers: [], sel: null,
    tool: 'move', zoom: 1, autoFit: true, pane: 'layers',
    history: [], redo: [], histKey: '', histTime: 0,
    brush: { size: 40, hardness: 60, flow: 100, color: '#ff3b30' },
    eraser: { size: 50, hardness: 60, flow: 100 },
    maskb: { size: 50, hardness: 60, flow: 100, mode: 'hide' },
    magic: { tol: 28, soft: 25, contiguous: true },
    textDef: {
      font: 'Tahoma, "Segoe UI", sans-serif', size: 96, color: '#ffffff', bold: true, italic: false,
      align: 'center', strokeW: 0, strokeColor: '#000000', bg: '', shadow: false, dir: 'auto'
    },
    crop: null, cropRatio: 0, cursor: null, docName: 'image', layerCount: 0
  };

  let cv, cx, ov, ox, stage, wrap, emptyBox, fileInput, zoomLabel;
  let actionsBar, toolsBar, optsBar, tabsBar;
  const panes = {};
  let undoBtn, redoBtn;
  let dpr = 1, renderQ = false, drag = null, thumbCache = null, visible = true;

  const FONTS = [
    ['Tahoma', 'Tahoma, "Segoe UI", sans-serif'],
    ['Arial', 'Arial, Helvetica, sans-serif'],
    ['Segoe UI', '"Segoe UI", Tahoma, sans-serif'],
    ['Noto Naskh Arabic', '"Noto Naskh Arabic", "Traditional Arabic", serif'],
    ['Times New Roman', '"Times New Roman", Times, serif'],
    ['Georgia', 'Georgia, serif'],
    ['Verdana', 'Verdana, sans-serif'],
    ['Courier New', '"Courier New", monospace'],
    ['Impact', 'Impact, "Arial Black", sans-serif'],
    ['Comic Sans', '"Comic Sans MS", cursive']
  ];
  const BLENDS = ['source-over', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge',
    'color-burn', 'hard-light', 'soft-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'];
  const TOOLS = [
    { id: 'move', icon: 'move', key: 'v' }, { id: 'hand', icon: 'hand', key: 'h' }, { id: 'crop', icon: 'crop', key: 'c' },
    { id: 'brush', icon: 'brush', key: 'b' }, { id: 'eraser', icon: 'eraser', key: 'e' },
    { id: 'magic', icon: 'wand', key: 'w' }, { id: 'text', icon: 'text', key: 't' }, { id: 'mask', icon: 'mask', key: 'm' }
  ];
  const ADJ = [
    ['brightness', -100, 100, 1], ['contrast', -100, 100, 1], ['saturation', -100, 100, 1], ['hue', -180, 180, 1],
    ['temperature', -100, 100, 1], ['sepia', 0, 100, 1], ['fade', 0, 100, 1], ['vignette', 0, 100, 1],
    ['blur', 0, 20, 0.5], ['sharpen', 0, 100, 1]
  ];
  const PRESETS = [
    { id: 'none', v: {} },
    { id: 'vivid', v: { saturation: 35, contrast: 12, brightness: 3 } },
    { id: 'bw', v: { saturation: -100, contrast: 15 } },
    { id: 'noir', v: { saturation: -100, contrast: 40, brightness: -8, vignette: 40 } },
    { id: 'sepia', v: { sepia: 80, contrast: 5 } },
    { id: 'cool', v: { temperature: -35, saturation: 8 } },
    { id: 'warm', v: { temperature: 35, saturation: 10 } },
    { id: 'fade', v: { fade: 45, saturation: -10, contrast: -8 } },
    { id: 'dramatic', v: { contrast: 35, saturation: -15, brightness: -5, vignette: 35, sharpen: 30 } },
    { id: 'vintage', v: { sepia: 35, fade: 30, temperature: 15, vignette: 30, contrast: -5 } },
    { id: 'soft', v: { contrast: -12, brightness: 8, fade: 12, blur: 1 } }
  ];

  /* ============================ model ============================ */
  const defAdj = () => ({ brightness: 0, contrast: 0, saturation: 0, hue: 0, temperature: 0, sepia: 0, fade: 0, vignette: 0, blur: 0, sharpen: 0 });
  function adjIsDefault(a) { for (const k in a) if (a[k] !== 0) return false; return true; }
  const selLayer = () => S.layers.find(l => l.id === S.sel) || null;
  const isPaintTool = () => S.tool === 'brush' || S.tool === 'eraser' || S.tool === 'mask';

  function makeLayer(type, canvas, name) {
    return {
      id: nextId++, type: type, name: name, canvas: canvas, mask: null,
      cx: S.w / 2, cy: S.h / 2, sx: 1, sy: 1, rot: 0, opacity: 1, visible: true, blend: 'source-over',
      adj: defAdj(), text: null, fx: null, fxQ: 1, fxDirty: false, fxTimer: 0, fxPrev: false
    };
  }
  function snapLayer(l) {
    const c = Object.assign({}, l);
    c.adj = Object.assign({}, l.adj);
    c.text = l.text ? Object.assign({}, l.text) : null;
    c._mc = null; c.fx = null; c.fxQ = 1; c.fxDirty = !adjIsDefault(l.adj); c.fxTimer = 0; c.fxPrev = false;
    return c;
  }
  function snapshot() {
    return { w: S.w, h: S.h, bg: S.bg, sel: S.sel, layers: S.layers.map(snapLayer) };
  }
  function pushHistory(key) {
    const now = Date.now();
    if (key && key === S.histKey && now - S.histTime < 900) { S.histTime = now; return; }
    S.history.push(snapshot());
    if (S.history.length > 40) S.history.shift();
    S.redo.length = 0;
    S.histKey = key || ''; S.histTime = now;
    updateUndoButtons();
  }
  function restore(snap) {
    S.w = snap.w; S.h = snap.h; S.bg = snap.bg;
    S.layers = snap.layers.map(snapLayer);
    S.sel = S.layers.some(l => l.id === snap.sel) ? snap.sel : (S.layers.length ? S.layers[S.layers.length - 1].id : null);
    S.crop = null; S.histKey = '';
    S.layers.forEach(l => { if (!adjIsDefault(l.adj)) scheduleFx(l); });
    resizeStage(); requestRender(); refreshAll();
  }
  function undo() {
    if (!S.history.length) return;
    S.redo.push(snapshot());
    restore(S.history.pop());
    updateUndoButtons();
  }
  function redo() {
    if (!S.redo.length) return;
    S.history.push(snapshot());
    restore(S.redo.pop());
    updateUndoButtons();
  }
  function updateUndoButtons() {
    if (undoBtn) undoBtn.disabled = !S.history.length;
    if (redoBtn) redoBtn.disabled = !S.redo.length;
  }
  /* before modifying a layer's pixels in place: keep the old canvas for history */
  function cowCanvas(l) { l.canvas = cloneCanvas(l.canvas); l.fx = null; }
  function cowMask(l) { l.mask = cloneCanvas(l.mask); }

  /* ============================ pixels / fx ============================ */
  function boxH(src, dst, w, ht, r) {
    const div = 2 * r + 1;
    for (let y = 0; y < ht; y++) {
      const row = y * w * 4;
      for (let ch = 0; ch < 4; ch++) {
        let sum = 0;
        for (let k = -r; k <= r; k++) sum += src[row + Math.min(w - 1, Math.max(0, k)) * 4 + ch];
        for (let x = 0; x < w; x++) {
          dst[row + x * 4 + ch] = sum / div;
          sum += src[row + Math.min(w - 1, x + r + 1) * 4 + ch] - src[row + Math.max(0, x - r) * 4 + ch];
        }
      }
    }
  }
  function boxV(src, dst, w, ht, r) {
    const div = 2 * r + 1, stride = w * 4;
    for (let x = 0; x < w; x++) {
      for (let ch = 0; ch < 4; ch++) {
        const col = x * 4 + ch;
        let sum = 0;
        for (let k = -r; k <= r; k++) sum += src[Math.min(ht - 1, Math.max(0, k)) * stride + col];
        for (let y = 0; y < ht; y++) {
          dst[y * stride + col] = sum / div;
          sum += src[Math.min(ht - 1, y + r + 1) * stride + col] - src[Math.max(0, y - r) * stride + col];
        }
      }
    }
  }
  function blurRGBA(d, w, ht, r) {
    const n = w * ht * 4;
    const a = new Uint8ClampedArray(n), b = new Uint8ClampedArray(n), o = new Uint8ClampedArray(n);
    for (let i = 0; i < n; i += 4) {
      const al = d[i + 3];
      if (al === 255) { a[i] = d[i]; a[i + 1] = d[i + 1]; a[i + 2] = d[i + 2]; a[i + 3] = 255; }
      else if (al) { const f = al / 255; a[i] = d[i] * f; a[i + 1] = d[i + 1] * f; a[i + 2] = d[i + 2] * f; a[i + 3] = al; }
    }
    for (let pass = 0; pass < 3; pass++) { boxH(a, b, w, ht, r); boxV(b, a, w, ht, r); }
    for (let i = 0; i < n; i += 4) {
      const al = a[i + 3];
      if (!al) continue;
      if (al === 255) { o[i] = a[i]; o[i + 1] = a[i + 1]; o[i + 2] = a[i + 2]; o[i + 3] = 255; }
      else { const f = 255 / al; o[i] = a[i] * f; o[i + 1] = a[i + 1] * f; o[i + 2] = a[i + 2] * f; o[i + 3] = al; }
    }
    return o;
  }
  function colourPass(d, adj) {
    const bri = adj.brightness * 2.55;
    const cc = adj.contrast * 2.55, cf = (259 * (cc + 255)) / (255 * (259 - cc));
    const sat = 1 + adj.saturation / 100, tmp = adj.temperature * 0.5, sep = adj.sepia / 100;
    const lift = adj.fade / 100 * 70, fk = 1 - lift / 255;
    const hr = adj.hue * Math.PI / 180, co = Math.cos(hr), si = Math.sin(hr);
    const m0 = 0.213 + co * 0.787 - si * 0.213, m1 = 0.715 - co * 0.715 - si * 0.715, m2 = 0.072 - co * 0.072 + si * 0.928;
    const m3 = 0.213 - co * 0.213 + si * 0.143, m4 = 0.715 + co * 0.285 + si * 0.140, m5 = 0.072 - co * 0.072 - si * 0.283;
    const m6 = 0.213 - co * 0.213 - si * 0.787, m7 = 0.715 - co * 0.715 + si * 0.715, m8 = 0.072 + co * 0.928 + si * 0.072;
    const doHue = adj.hue !== 0;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue;
      let r = d[i] + bri, g = d[i + 1] + bri, b = d[i + 2] + bri;
      if (cc) { r = (r - 128) * cf + 128; g = (g - 128) * cf + 128; b = (b - 128) * cf + 128; }
      if (tmp) { r += tmp; b -= tmp; }
      if (sat !== 1) { const gr = 0.299 * r + 0.587 * g + 0.114 * b; r = gr + (r - gr) * sat; g = gr + (g - gr) * sat; b = gr + (b - gr) * sat; }
      if (doHue) { const nr = m0 * r + m1 * g + m2 * b, ng = m3 * r + m4 * g + m5 * b, nb = m6 * r + m7 * g + m8 * b; r = nr; g = ng; b = nb; }
      if (sep) {
        const sr = 0.393 * r + 0.769 * g + 0.189 * b, sg = 0.349 * r + 0.686 * g + 0.168 * b, sb = 0.272 * r + 0.534 * g + 0.131 * b;
        r += (sr - r) * sep; g += (sg - g) * sep; b += (sb - b) * sep;
      }
      if (lift) { r = lift + r * fk; g = lift + g * fk; b = lift + b * fk; }
      d[i] = r; d[i + 1] = g; d[i + 2] = b;
    }
  }
  function applyAdj(src, adj, q) {
    const w = Math.max(1, Math.round(src.width * q)), ht = Math.max(1, Math.round(src.height * q));
    const c = makeCanvas(w, ht);
    const g = c.getContext('2d', { willReadFrequently: true });
    g.imageSmoothingQuality = 'high';
    g.drawImage(src, 0, 0, w, ht);
    if (adjIsDefault(adj)) return c;
    let d = g.getImageData(0, 0, w, ht).data;
    colourPass(d, adj);
    if (adj.blur * q >= 0.4) d = blurRGBA(d, w, ht, Math.max(1, Math.round(adj.blur * q * 0.8)));
    if (adj.sharpen > 0) {
      const amt = adj.sharpen / 100 * 1.5;
      const bl = blurRGBA(d, w, ht, Math.max(1, Math.round(1.5 * Math.max(q, 0.5))));
      for (let i = 0; i < d.length; i += 4) {
        if (!d[i + 3]) continue;
        d[i] = d[i] + (d[i] - bl[i]) * amt;
        d[i + 1] = d[i + 1] + (d[i + 1] - bl[i + 1]) * amt;
        d[i + 2] = d[i + 2] + (d[i + 2] - bl[i + 2]) * amt;
      }
    }
    if (adj.vignette > 0) {
      const v = adj.vignette / 100;
      for (let y = 0; y < ht; y++) {
        const ny = (y / ht - 0.5) * 2;
        for (let x = 0; x < w; x++) {
          const nx = (x / w - 0.5) * 2;
          let dist = Math.sqrt(nx * nx + ny * ny) / 1.4142;
          let s = (dist - 0.35) / 0.65; s = s < 0 ? 0 : s > 1 ? 1 : s; s = s * s * (3 - 2 * s);
          const f = 1 - v * s, i = (y * w + x) * 4;
          d[i] *= f; d[i + 1] *= f; d[i + 2] *= f;
        }
      }
    }
    g.putImageData(new ImageData(d, w, ht), 0, 0);
    return c;
  }
  function scheduleFx(l) {
    if (adjIsDefault(l.adj)) {
      l.fx = null; l.fxDirty = false; clearTimeout(l.fxTimer); requestRender(); return;
    }
    l.fxDirty = true;
    const q = Math.min(1, 900 / Math.max(l.canvas.width, l.canvas.height));
    if (!l.fxPrev) {
      l.fxPrev = true;
      requestAnimationFrame(() => {
        l.fxPrev = false;
        if (!adjIsDefault(l.adj)) { l.fx = applyAdj(l.canvas, l.adj, q); l.fxQ = q; requestRender(); }
      });
    }
    clearTimeout(l.fxTimer);
    l.fxTimer = setTimeout(() => {
      if (adjIsDefault(l.adj)) return;
      l.fx = applyAdj(l.canvas, l.adj, 1); l.fxQ = 1; l.fxDirty = false;
      requestRender(); refreshLayers();
    }, 300);
  }
  function bakeAdj(l) {
    if (adjIsDefault(l.adj)) return;
    if (l.type === 'text') { l.type = 'image'; l.text = null; }
    l.canvas = applyAdj(l.canvas, l.adj, 1);
    l.adj = defAdj(); l.fx = null; l.fxDirty = false; clearTimeout(l.fxTimer);
  }

  /* ============================ geometry ============================ */
  function toLocal(l, x, y) {
    const dx = x - l.cx, dy = y - l.cy, co = Math.cos(-l.rot), si = Math.sin(-l.rot);
    const rx = dx * co - dy * si, ry = dx * si + dy * co;
    return { x: rx / l.sx + l.canvas.width / 2, y: ry / l.sy + l.canvas.height / 2 };
  }
  function toDoc(l, lx, ly) {
    const px = lx * l.sx, py = ly * l.sy, co = Math.cos(l.rot), si = Math.sin(l.rot);
    return { x: l.cx + px * co - py * si, y: l.cy + px * si + py * co };
  }
  function layerCorners(l) {
    const hw = l.canvas.width / 2, hh = l.canvas.height / 2;
    return [toDoc(l, -hw, -hh), toDoc(l, hw, -hh), toDoc(l, hw, hh), toDoc(l, -hw, hh)];
  }
  function insideLayer(l, p) {
    const q = toLocal(l, p.x, p.y);
    return q.x >= 0 && q.y >= 0 && q.x < l.canvas.width && q.y < l.canvas.height;
  }
  function alphaAt(l, p) {
    const q = toLocal(l, p.x, p.y);
    const x = Math.floor(q.x), y = Math.floor(q.y);
    if (x < 0 || y < 0 || x >= l.canvas.width || y >= l.canvas.height) return 0;
    return l.canvas.getContext('2d').getImageData(x, y, 1, 1).data[3];
  }
  function hitLayer(p) {
    for (let i = S.layers.length - 1; i >= 0; i--) {
      const l = S.layers[i];
      if (!l.visible) continue;
      if (insideLayer(l, p) && (l.type === 'text' || alphaAt(l, p) > 8)) return l;
    }
    for (let i = S.layers.length - 1; i >= 0; i--) {
      const l = S.layers[i];
      if (l.visible && insideLayer(l, p)) return l;
    }
    return null;
  }

  /* ============================ rendering ============================ */
  function layerSource(l, final) {
    let src = l.canvas;
    if (!adjIsDefault(l.adj)) {
      if (final && (l.fxDirty || l.fxQ !== 1 || !l.fx)) { l.fx = applyAdj(l.canvas, l.adj, 1); l.fxQ = 1; l.fxDirty = false; }
      if (l.fx) src = l.fx;
    }
    if (l.mask) {
      // reuse one scratch canvas per layer instead of allocating a new one every frame
      let m = l._mc;
      if (!m || m.width !== l.canvas.width || m.height !== l.canvas.height) m = l._mc = makeCanvas(l.canvas.width, l.canvas.height);
      const g = m.getContext('2d');
      g.globalCompositeOperation = 'source-over';
      g.clearRect(0, 0, m.width, m.height);
      g.drawImage(src, 0, 0, m.width, m.height);
      g.globalCompositeOperation = 'destination-in';
      g.drawImage(l.mask, 0, 0);
      src = m;
    }
    return src;
  }
  function drawLayer(g, l, final) {
    if (!l.visible) return;
    const src = layerSource(l, final);
    const w = l.canvas.width, ht = l.canvas.height;
    g.save();
    g.globalAlpha = l.opacity;
    g.globalCompositeOperation = l.blend;
    g.translate(l.cx, l.cy); g.rotate(l.rot); g.scale(l.sx, l.sy);
    g.imageSmoothingQuality = 'high';
    g.drawImage(src, -w / 2, -ht / 2, w, ht);
    g.restore();
  }
  function renderLayers(g, final) { S.layers.forEach(l => drawLayer(g, l, final)); }
  function renderDoc(g, final) {
    g.clearRect(0, 0, S.w, S.h);
    if (S.bg) { g.fillStyle = S.bg; g.fillRect(0, 0, S.w, S.h); }
    renderLayers(g, final);
  }
  function requestRender() {
    if (renderQ) return;
    renderQ = true;
    requestAnimationFrame(() => { renderQ = false; render(); });
  }
  function render() {
    if (!S.w) return;
    if (cv.width !== S.w || cv.height !== S.h) { cv.width = S.w; cv.height = S.h; }
    renderDoc(cx, false);
    drawOverlay();
  }
  function resizeStage() {
    emptyBox.hidden = !!S.w;
    wrap.hidden = !S.w;
    if (actionsBar) actionsBar.classList.toggle('nodoc', !S.w);
    if (!S.w) return;
    dpr = window.devicePixelRatio || 1;
    const cw = Math.max(1, Math.round(S.w * S.zoom)), ch = Math.max(1, Math.round(S.h * S.zoom));
    wrap.style.width = cw + 'px'; wrap.style.height = ch + 'px';
    cv.style.width = cw + 'px'; cv.style.height = ch + 'px';
    ov.style.inset = 'auto'; ov.style.left = -PAD + 'px'; ov.style.top = -PAD + 'px';
    ov.style.width = (cw + 2 * PAD) + 'px'; ov.style.height = (ch + 2 * PAD) + 'px';
    ov.width = Math.round((cw + 2 * PAD) * dpr); ov.height = Math.round((ch + 2 * PAD) * dpr);
    if (zoomLabel) zoomLabel.textContent = Math.round(S.zoom * 100) + '%';
  }
  function setZoom(z) {
    if (!S.w) return;
    const oldW = wrap.offsetWidth || 1, oldH = wrap.offsetHeight || 1;
    const fx = (stage.scrollLeft + stage.clientWidth / 2) / oldW, fy = (stage.scrollTop + stage.clientHeight / 2) / oldH;
    S.zoom = clamp(z, 0.02, 8);
    S.autoFit = false;
    resizeStage();
    stage.scrollLeft = fx * wrap.offsetWidth - stage.clientWidth / 2;
    stage.scrollTop = fy * wrap.offsetHeight - stage.clientHeight / 2;
    requestRender();
  }
  function fitZoom() {
    if (!S.w) return;
    const aw = stage.clientWidth - 100, ah = stage.clientHeight - 100;
    if (aw < 50 || ah < 50) return;
    S.zoom = clamp(Math.min(aw / S.w, ah / S.h), 0.02, 4);
    S.autoFit = true;
    resizeStage(); requestRender();
  }

  /* ---------- overlay (handles, crop, cursor) ---------- */
  const css2scr = () => S.zoom * dpr;
  function drawOverlay() {
    if (!ov) return;
    ox.setTransform(1, 0, 0, 1, 0, 0);
    ox.clearRect(0, 0, ov.width, ov.height);
    if (!S.w) return;
    ox.translate(PAD * dpr, PAD * dpr);
    const l = selLayer();
    if (S.tool === 'move' && l && l.visible) drawHandles(l);
    else if (S.tool === 'crop' && S.crop) drawCrop();
    else if (isPaintTool() && S.cursor && !drag) drawBrushCursor();
    else if (isPaintTool() && S.cursor && drag && drag.mode === 'paint') drawBrushCursor();
  }
  function handlePoints(l) {
    const k = S.zoom;                       // css px per doc px
    const c = layerCorners(l).map(p => ({ x: p.x * k, y: p.y * k }));
    const centre = { x: l.cx * k, y: l.cy * k };
    const top = { x: (c[0].x + c[1].x) / 2, y: (c[0].y + c[1].y) / 2 };
    let dx = top.x - centre.x, dy = top.y - centre.y;
    const len = Math.hypot(dx, dy) || 1;
    dx /= len; dy /= len;
    const rot = {
      x: clamp(top.x + dx * 30, 10, Math.max(10, S.w * S.zoom - 10)),
      y: clamp(top.y + dy * 30, 10, Math.max(10, S.h * S.zoom - 10))
    };
    return { corners: c, rot: rot, top: top, centre: centre };
  }
  function drawHandles(l) {
    const hp = handlePoints(l), s = dpr;
    ox.lineWidth = 1.5 * s; ox.strokeStyle = '#4da3ff'; ox.fillStyle = '#ffffff';
    ox.beginPath();
    hp.corners.forEach((p, i) => { if (i) ox.lineTo(p.x * s, p.y * s); else ox.moveTo(p.x * s, p.y * s); });
    ox.closePath(); ox.stroke();
    ox.beginPath(); ox.moveTo(hp.top.x * s, hp.top.y * s); ox.lineTo(hp.rot.x * s, hp.rot.y * s); ox.stroke();
    ox.beginPath(); ox.arc(hp.rot.x * s, hp.rot.y * s, 6 * s, 0, Math.PI * 2); ox.fill(); ox.stroke();
    hp.corners.forEach(p => { ox.fillRect(p.x * s - 5 * s, p.y * s - 5 * s, 10 * s, 10 * s); ox.strokeRect(p.x * s - 5 * s, p.y * s - 5 * s, 10 * s, 10 * s); });
  }
  function hitHandle(l, p) {
    const hp = handlePoints(l), px = p.x * S.zoom, py = p.y * S.zoom;
    if (Math.hypot(px - hp.rot.x, py - hp.rot.y) <= 12) return 'rotate';
    for (let i = 0; i < 4; i++) if (Math.abs(px - hp.corners[i].x) <= 11 && Math.abs(py - hp.corners[i].y) <= 11) return 'scale';
    return null;
  }
  function cropHandles() {
    const c = S.crop, k = S.zoom;
    const x0 = c.x * k, y0 = c.y * k, x1 = (c.x + c.w) * k, y1 = (c.y + c.h) * k, mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
    const all = [['nw', x0, y0], ['ne', x1, y0], ['se', x1, y1], ['sw', x0, y1], ['n', mx, y0], ['s', mx, y1], ['w', x0, my], ['e', x1, my]];
    return S.cropRatio ? all.slice(0, 4) : all;
  }
  function drawCrop() {
    const c = S.crop, k = css2scr(), s = dpr;
    ox.fillStyle = 'rgba(0,0,0,0.55)';
    const DW = S.w * k, DH = S.h * k;   // document rectangle in overlay pixels
    ox.fillRect(0, 0, DW, c.y * k);
    ox.fillRect(0, (c.y + c.h) * k, DW, DH - (c.y + c.h) * k);
    ox.fillRect(0, c.y * k, c.x * k, c.h * k);
    ox.fillRect((c.x + c.w) * k, c.y * k, DW - (c.x + c.w) * k, c.h * k);
    ox.strokeStyle = '#ffffff'; ox.lineWidth = 1.5 * s;
    ox.strokeRect(c.x * k, c.y * k, c.w * k, c.h * k);
    ox.lineWidth = 1 * s; ox.strokeStyle = 'rgba(255,255,255,0.45)';
    ox.beginPath();
    for (let i = 1; i < 3; i++) {
      ox.moveTo((c.x + c.w * i / 3) * k, c.y * k); ox.lineTo((c.x + c.w * i / 3) * k, (c.y + c.h) * k);
      ox.moveTo(c.x * k, (c.y + c.h * i / 3) * k); ox.lineTo((c.x + c.w) * k, (c.y + c.h * i / 3) * k);
    }
    ox.stroke();
    ox.fillStyle = '#ffffff';
    cropHandles().forEach(h2 => ox.fillRect(h2[1] * s - 5 * s, h2[2] * s - 5 * s, 10 * s, 10 * s));
  }
  function hitCropHandle(p) {
    const px = p.x * S.zoom, py = p.y * S.zoom;
    const list = cropHandles();
    for (let i = 0; i < list.length; i++) if (Math.abs(px - list[i][1]) <= 12 && Math.abs(py - list[i][2]) <= 12) return list[i][0];
    return null;
  }
  function drawBrushCursor() {
    const cfg = S.tool === 'brush' ? S.brush : S.tool === 'eraser' ? S.eraser : S.maskb;
    const k = css2scr();
    ox.lineWidth = dpr; ox.strokeStyle = '#ffffff'; ox.setLineDash([]);
    ox.beginPath(); ox.arc(S.cursor.x * k, S.cursor.y * k, Math.max(2, cfg.size * k / 2), 0, Math.PI * 2); ox.stroke();
    ox.strokeStyle = 'rgba(0,0,0,0.6)';
    ox.beginPath(); ox.arc(S.cursor.x * k, S.cursor.y * k, Math.max(2, cfg.size * k / 2) + dpr, 0, Math.PI * 2); ox.stroke();
  }

  /* ============================ painting ============================ */
  const stampCache = new Map();
  function getStamp(size, hardness, color) {
    const d = Math.max(2, Math.round(size));
    const key = d + '|' + hardness + '|' + color;
    let s = stampCache.get(key);
    if (s) return s;
    s = makeCanvas(d, d);
    const g = s.getContext('2d'), r = d / 2;
    const grad = g.createRadialGradient(r, r, 0, r, r, r);
    const hd = Math.min(0.99, Math.max(0, hardness / 100));
    grad.addColorStop(0, rgba(color, 1)); grad.addColorStop(hd, rgba(color, 1)); grad.addColorStop(1, rgba(color, 0));
    g.fillStyle = grad; g.fillRect(0, 0, d, d);
    if (stampCache.size > 60) stampCache.clear();
    stampCache.set(key, s);
    return s;
  }
  function stampAt(g, st, x, y, size, alpha, erase) {
    g.globalAlpha = alpha;
    g.globalCompositeOperation = erase ? 'destination-out' : 'source-over';
    g.drawImage(st, x - size / 2, y - size / 2, size, size);
  }
  function stampPath(from, to, step, pd) {
    const dx = to.x - from.x, dy = to.y - from.y, dist = Math.hypot(dx, dy);
    if (dist < step) return from;
    const ux = dx / dist, uy = dy / dist;
    let pos = 0, cur = from;
    while (pos + step <= dist) {
      pos += step;
      cur = { x: from.x + ux * pos, y: from.y + uy * pos };
      pd(cur);
    }
    return cur;
  }

  /* make the layer safe to paint on; returns false when not possible */
  function preparePaint(l, target) {
    if (!l) { toast(t('need_layer')); return false; }
    if (!l.visible) { toast(t('layer_hidden')); return false; }
    pushHistory();
    if (l.type === 'text') { l.type = 'image'; l.text = null; toast(t('rasterized')); }
    if (!adjIsDefault(l.adj)) { bakeAdj(l); toast(t('adj_baked')); }
    if (target === 'mask') {
      if (!l.mask) l.mask = fullMask(l); else cowMask(l);
    } else cowCanvas(l);
    return true;
  }
  function fullMask(l) {
    const m = makeCanvas(l.canvas.width, l.canvas.height);
    const g = m.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, m.width, m.height);
    return m;
  }

  /* ============================ magic erase ============================ */
  function floodErase(l, ref, seedIdx, global) {
    const w = l.canvas.width, ht = l.canvas.height;
    const g = l.canvas.getContext('2d', { willReadFrequently: true });
    const img = g.getImageData(0, 0, w, ht), d = img.data;
    const tolD = S.magic.tol * 2.2, maxD = tolD + S.magic.soft * 0.6;
    const n = w * ht;
    const dist = (i) => {
      const o = i * 4;
      if (d[o + 3] === 0) return 0;
      const dr = d[o] - ref[0], dg = d[o + 1] - ref[1], db = d[o + 2] - ref[2];
      return Math.sqrt(dr * dr + dg * dg + db * db);
    };
    const apply = (i, dd) => {
      const o = i * 4 + 3;
      if (dd <= tolD) d[o] = 0;
      else if (maxD > tolD) d[o] = Math.round(d[o] * (dd - tolD) / (maxD - tolD));
    };
    if (global) {
      for (let i = 0; i < n; i++) { const dd = dist(i); if (dd <= maxD) apply(i, dd); }
    } else {
      const visited = new Uint8Array(n), stack = new Uint32Array(n);
      let sp = 0;
      seedIdx.forEach(i => { if (!visited[i] && dist(i) <= maxD) { visited[i] = 1; stack[sp++] = i; } });
      while (sp) {
        const i = stack[--sp], x = i % w, y = (i - x) / w;
        const dd = dist(i);
        apply(i, dd);
        if (x > 0) { const j = i - 1; if (!visited[j] && dist(j) <= maxD) { visited[j] = 1; stack[sp++] = j; } }
        if (x < w - 1) { const j = i + 1; if (!visited[j] && dist(j) <= maxD) { visited[j] = 1; stack[sp++] = j; } }
        if (y > 0) { const j = i - w; if (!visited[j] && dist(j) <= maxD) { visited[j] = 1; stack[sp++] = j; } }
        if (y < ht - 1) { const j = i + w; if (!visited[j] && dist(j) <= maxD) { visited[j] = 1; stack[sp++] = j; } }
      }
    }
    g.putImageData(img, 0, 0);
  }
  function magicAt(p) {
    const l = selLayer();
    if (!l || !l.visible) { toast(t('need_layer')); return; }
    if (!insideLayer(l, p)) return;
    if (!preparePaint(l, 'canvas')) return;
    const q = toLocal(l, p.x, p.y);
    const x = clamp(Math.floor(q.x), 0, l.canvas.width - 1), y = clamp(Math.floor(q.y), 0, l.canvas.height - 1);
    const px = l.canvas.getContext('2d', { willReadFrequently: true }).getImageData(x, y, 1, 1).data;
    if (px[3] === 0) { S.history.pop(); updateUndoButtons(); toast(t('magic_empty')); return; }
    floodErase(l, [px[0], px[1], px[2]], [y * l.canvas.width + x], !S.magic.contiguous);
    thumbCache = null; requestRender(); refreshLayers();
  }
  function autoRemoveBg() {
    const l = selLayer();
    if (!l || !l.visible) { toast(t('need_layer')); return; }
    if (!preparePaint(l, 'canvas')) return;
    const w = l.canvas.width, ht = l.canvas.height;
    const g = l.canvas.getContext('2d', { willReadFrequently: true });
    const d = g.getImageData(0, 0, w, ht).data;
    const blk = Math.max(1, Math.min(4, Math.floor(Math.min(w, ht) / 4)));
    let sr = 0, sg = 0, sb = 0, cnt = 0;
    [[0, 0], [w - blk, 0], [0, ht - blk], [w - blk, ht - blk]].forEach(c => {
      for (let yy = 0; yy < blk; yy++) for (let xx = 0; xx < blk; xx++) {
        const o = ((c[1] + yy) * w + c[0] + xx) * 4;
        if (d[o + 3] > 0) { sr += d[o]; sg += d[o + 1]; sb += d[o + 2]; cnt++; }
      }
    });
    if (!cnt) { S.history.pop(); updateUndoButtons(); toast(t('magic_empty')); return; }
    const ref = [sr / cnt, sg / cnt, sb / cnt];
    const seeds = [];
    for (let x = 0; x < w; x++) { seeds.push(x); seeds.push((ht - 1) * w + x); }
    for (let y = 1; y < ht - 1; y++) { seeds.push(y * w); seeds.push(y * w + w - 1); }
    floodErase(l, ref, seeds, false);
    thumbCache = null; requestRender(); refreshLayers();
    toast(t('bg_removed'));
  }

  /* ============================ text layers ============================ */
  function isRtlText(s) { return /[֐-ࣿיִ-﷿ﹰ-﻿]/.test(s); }
  function renderTextCanvas(tx) {
    const lines = String(tx.text || ' ').split('\n');
    const font = (tx.italic ? 'italic ' : '') + (tx.bold ? 'bold ' : '') + tx.size + 'px ' + tx.font;
    const m = makeCanvas(8, 8).getContext('2d');
    m.font = font;
    const rtl = tx.dir === 'rtl' || (tx.dir === 'auto' && isRtlText(tx.text));
    let maxW = 1;
    lines.forEach(ln => { maxW = Math.max(maxW, m.measureText(ln).width); });
    const lh = tx.size * 1.35;
    const pad = Math.ceil(tx.size * 0.25 + tx.strokeW + (tx.shadow ? tx.size * 0.12 : 0) + 6);
    const w = Math.ceil(maxW) + pad * 2, ht = Math.ceil(lh * lines.length) + pad * 2;
    const c = makeCanvas(Math.min(w, 8000), Math.min(ht, 8000));
    const g = c.getContext('2d');
    if (tx.bg) { g.fillStyle = tx.bg; g.fillRect(0, 0, c.width, c.height); }
    g.font = font; g.textBaseline = 'middle'; g.direction = rtl ? 'rtl' : 'ltr';
    g.textAlign = tx.align;
    const x = tx.align === 'left' ? pad : tx.align === 'right' ? c.width - pad : c.width / 2;
    g.lineJoin = 'round';
    lines.forEach((ln, i) => {
      const y = pad + lh * i + lh / 2;
      if (tx.shadow) { g.shadowColor = 'rgba(0,0,0,0.65)'; g.shadowBlur = tx.size * 0.1; g.shadowOffsetX = tx.size * 0.04; g.shadowOffsetY = tx.size * 0.04; }
      if (tx.strokeW > 0) { g.strokeStyle = tx.strokeColor; g.lineWidth = tx.strokeW * 2; g.strokeText(ln, x, y); }
      g.shadowColor = 'transparent';
      g.fillStyle = tx.color; g.fillText(ln, x, y);
    });
    return c;
  }
  function addTextLayer(p) {
    pushHistory();
    const tx = Object.assign({}, S.textDef, { text: t('text_sample') });
    const l = makeLayer('text', renderTextCanvas(tx), tx.text);
    l.text = tx; l.cx = clamp(p.x, 0, S.w); l.cy = clamp(p.y, 0, S.h);
    S.layers.push(l); S.sel = l.id;
    thumbCache = null; refreshAll(); setPane('props', true); requestRender();
  }
  function updateText(l) {
    if (!l || !l.text) return;
    l.canvas = renderTextCanvas(l.text);
    l.name = (l.text.text || '').replace(/\s+/g, ' ').slice(0, 20) || t('text_sample');
    if (!adjIsDefault(l.adj)) scheduleFx(l);
    thumbCache = null; requestRender();
  }

  /* ============================ doc operations ============================ */
  function newDoc(w, ht, bg) {
    S.history = []; S.redo = []; S.layers = []; S.sel = null; S.crop = null; S.histKey = '';
    S.w = clamp(Math.round(w), 16, MAXDOC); S.h = clamp(Math.round(ht), 16, MAXDOC); S.bg = bg || null;
    S.docName = 'design'; S.layerCount = 0;
    thumbCache = null;
    resizeStage(); fitZoom(); refreshAll(); updateUndoButtons();
  }
  function addImageLayer(canvas, name) {
    if (!S.w) {
      S.w = canvas.width; S.h = canvas.height; S.bg = null; S.docName = name;
      resizeStage(); fitZoom();
    } else pushHistory();
    const l = makeLayer('image', canvas, name);
    const k = Math.min(1, S.w / canvas.width, S.h / canvas.height);
    l.sx = l.sy = k;
    S.layers.push(l); S.sel = l.id;
    thumbCache = null; refreshAll(); requestRender();
  }
  async function openFiles(files) {
    let n = 0;
    for (const f of Array.from(files || [])) {
      if (!f.type || f.type.indexOf('image/') !== 0) continue;
      try {
        const r = await fileToCanvas(f, MAXSIDE);
        addImageLayer(r.canvas, stripExt(f.name));
        n++;
        if (r.scaled) toast(t('img_downscaled', { n: MAXSIDE }));
      } catch (e) { toast(t('err_image')); }
    }
    if (!n && files && files.length) toast(t('err_image'));
  }
  function applyCrop() {
    if (!S.crop || !S.w) return;
    const c = S.crop;
    const x = Math.round(c.x), y = Math.round(c.y), w = Math.max(1, Math.round(c.w)), ht = Math.max(1, Math.round(c.h));
    pushHistory();
    S.layers.forEach(l => { l.cx -= x; l.cy -= y; });
    S.w = w; S.h = ht; S.crop = null;
    setTool('move'); resizeStage(); fitZoom(); refreshAll();
  }
  function cropRect(ratio) {
    // largest centred rectangle inside the document with the given ratio (0 = free)
    if (!ratio) return { x: 0, y: 0, w: S.w, h: S.h };
    let w = S.w, ht = w / ratio;
    if (ht > S.h) { ht = S.h; w = ht * ratio; }
    return { x: (S.w - w) / 2, y: (S.h - ht) / 2, w: w, h: ht };
  }
  function needDoc() {
    if (S.w) return false;
    toast(t('need_doc'));
    return true;
  }
  function rotateDoc(cw) {
    if (needDoc()) return;
    pushHistory();
    const W = S.w, H = S.h;
    S.layers.forEach(l => {
      const x = l.cx, y = l.cy;
      if (cw) { l.cx = H - y; l.cy = x; l.rot += Math.PI / 2; } else { l.cx = y; l.cy = W - x; l.rot -= Math.PI / 2; }
    });
    S.w = H; S.h = W; S.crop = null;
    if (S.tool === 'crop') S.crop = cropRect(S.cropRatio);
    resizeStage(); fitZoom(); requestRender();
  }
  function flipDoc(axis) {
    if (needDoc()) return;
    pushHistory();
    S.layers.forEach(l => {
      if (axis === 'h') { l.cx = S.w - l.cx; l.sx = -l.sx; } else { l.cy = S.h - l.cy; l.sy = -l.sy; }
      l.rot = -l.rot;
    });
    requestRender();
  }
  function resizeDoc(newW) {
    const k = newW / S.w;
    pushHistory();
    S.layers.forEach(l => { l.cx *= k; l.cy *= k; l.sx *= k; l.sy *= k; });
    S.w = Math.round(S.w * k); S.h = Math.round(S.h * k); S.crop = null;
    resizeStage(); fitZoom(); requestRender();
  }
  function flatten() {
    if (needDoc()) return;
    if (S.layers.length < 2) { toast(t('flat_need')); return; }
    pushHistory();
    const c = makeCanvas(S.w, S.h), g = c.getContext('2d');
    renderLayers(g, true);
    const l = makeLayer('image', c, t('layer_flat'));
    S.layers = [l]; S.sel = l.id;
    thumbCache = null; refreshAll(); requestRender();
  }

  /* ============================ pointer handling ============================ */
  function evDoc(e) {
    const r = cv.getBoundingClientRect();   // exact document rectangle (the overlay is larger)
    return { x: (e.clientX - r.left) * S.w / r.width, y: (e.clientY - r.top) * S.h / r.height };
  }
  function onDown(e) {
    if (!S.w || e.button > 0) return;
    ov.setPointerCapture(e.pointerId);
    const p = evDoc(e);
    S.cursor = p;
    const tool = S.tool;
    if (tool === 'move') {
      const l = selLayer();
      if (l && l.visible) {
        const hd = hitHandle(l, p);
        if (hd === 'rotate') { drag = { mode: 'rotate', l: l, a0: Math.atan2(p.y - l.cy, p.x - l.cx), r0: l.rot, pushed: false }; return; }
        if (hd === 'scale') { drag = { mode: 'scale', l: l, d0: Math.hypot(p.x - l.cx, p.y - l.cy) || 1, sx0: l.sx, sy0: l.sy, pushed: false }; return; }
      }
      const hit = hitLayer(p);
      if (hit) {
        if (hit.id !== S.sel) { S.sel = hit.id; refreshAll(); }
        drag = { mode: 'move', l: hit, lx: p.x, ly: p.y, pushed: false };
      }
    } else if (tool === 'hand') {
      drag = { mode: 'pan', x: e.clientX, y: e.clientY };
    } else if (isPaintTool()) {
      const l = selLayer();
      const target = tool === 'mask' ? 'mask' : 'canvas';
      if (!preparePaint(l, target)) return;
      const cfg = tool === 'brush' ? S.brush : tool === 'eraser' ? S.eraser : S.maskb;
      const erase = tool === 'eraser' || (tool === 'mask' && S.maskb.mode === 'hide');
      const color = tool === 'brush' ? S.brush.color : (tool === 'mask' && S.maskb.mode === 'reveal') ? '#ffffff' : '#000000';
      const sizeLocal = Math.max(1, cfg.size / Math.abs(l.sx));
      const st = getStamp(sizeLocal, cfg.hardness, color);
      const tg = (target === 'mask' ? l.mask : l.canvas).getContext('2d');
      const q = toLocal(l, p.x, p.y);
      stampAt(tg, st, q.x, q.y, sizeLocal, cfg.flow / 100, erase);
      drag = { mode: 'paint', l: l, tg: tg, st: st, size: sizeLocal, alpha: cfg.flow / 100, erase: erase, last: q };
      requestRender();
    } else if (tool === 'magic') {
      magicAt(p);
    } else if (tool === 'text') {
      let hit = null;
      for (let i = S.layers.length - 1; i >= 0; i--) {
        const l = S.layers[i];
        if (l.type === 'text' && l.visible && insideLayer(l, p)) { hit = l; break; }
      }
      if (hit) { S.sel = hit.id; refreshAll(); setPane('props', true); }
      else addTextLayer(p);
    } else if (tool === 'crop') {
      if (!S.crop) S.crop = cropRect(S.cropRatio);
      const hd = hitCropHandle(p), c = S.crop;
      if (hd) drag = { mode: 'crop-resize', hd: hd };
      else if (p.x >= c.x && p.x <= c.x + c.w && p.y >= c.y && p.y <= c.y + c.h) drag = { mode: 'crop-move', lx: p.x, ly: p.y };
      else if (!S.cropRatio) { S.crop = { x: clamp(p.x, 0, S.w), y: clamp(p.y, 0, S.h), w: 1, h: 1 }; drag = { mode: 'crop-new', ax: S.crop.x, ay: S.crop.y }; }
      drawOverlay();
    }
  }
  function onMove(e) {
    if (!S.w) return;
    const p = evDoc(e);
    S.cursor = p;
    if (!drag) { if (isPaintTool()) drawOverlay(); return; }
    const l = drag.l;
    switch (drag.mode) {
      case 'move':
        if (!drag.pushed) { pushHistory(); drag.pushed = true; }
        l.cx += p.x - drag.lx; l.cy += p.y - drag.ly; drag.lx = p.x; drag.ly = p.y;
        requestRender(); break;
      case 'scale': {
        if (!drag.pushed) { pushHistory(); drag.pushed = true; }
        let k = (Math.hypot(p.x - l.cx, p.y - l.cy) || 1) / drag.d0;
        const minK = 0.02 / Math.max(Math.abs(drag.sx0), 0.0001);
        k = Math.max(k, minK);
        l.sx = drag.sx0 * k; l.sy = drag.sy0 * k;
        requestRender(); break;
      }
      case 'rotate': {
        if (!drag.pushed) { pushHistory(); drag.pushed = true; }
        let r = drag.r0 + (Math.atan2(p.y - l.cy, p.x - l.cx) - drag.a0);
        if (e.shiftKey) r = Math.round(r / (Math.PI / 12)) * (Math.PI / 12);
        l.rot = r;
        requestRender(); break;
      }
      case 'pan':
        stage.scrollLeft -= e.clientX - drag.x; stage.scrollTop -= e.clientY - drag.y;
        drag.x = e.clientX; drag.y = e.clientY; break;
      case 'paint': {
        const q = toLocal(l, p.x, p.y);
        const step = Math.max(1, drag.size * 0.12);
        drag.last = stampPath(drag.last, q, step, pt => stampAt(drag.tg, drag.st, pt.x, pt.y, drag.size, drag.alpha, drag.erase));
        requestRender(); break;
      }
      case 'crop-move': {
        const c = S.crop;
        c.x = clamp(c.x + p.x - drag.lx, 0, S.w - c.w); c.y = clamp(c.y + p.y - drag.ly, 0, S.h - c.h);
        drag.lx = p.x; drag.ly = p.y; drawOverlay(); updateCropInfo(); break;
      }
      case 'crop-new': {
        const x0 = Math.min(drag.ax, p.x), y0 = Math.min(drag.ay, p.y);
        S.crop = { x: clamp(x0, 0, S.w), y: clamp(y0, 0, S.h), w: Math.max(1, Math.min(Math.abs(p.x - drag.ax), S.w - x0)), h: Math.max(1, Math.min(Math.abs(p.y - drag.ay), S.h - y0)) };
        drawOverlay(); updateCropInfo(); break;
      }
      case 'crop-resize': resizeCrop(drag.hd, p); drawOverlay(); updateCropInfo(); break;
    }
  }
  function resizeCrop(hd, p) {
    const c = S.crop, MIN = 8;
    let x0 = c.x, y0 = c.y, x1 = c.x + c.w, y1 = c.y + c.h;
    if (hd.indexOf('w') >= 0) x0 = clamp(p.x, 0, x1 - MIN);
    if (hd.indexOf('e') >= 0) x1 = clamp(p.x, x0 + MIN, S.w);
    if (hd.indexOf('n') >= 0) y0 = clamp(p.y, 0, y1 - MIN);
    if (hd.indexOf('s') >= 0) y1 = clamp(p.y, y0 + MIN, S.h);
    if (S.cropRatio) {
      const r = S.cropRatio;
      let w = x1 - x0, ht = w / r;
      const north = hd.indexOf('n') >= 0, west = hd.indexOf('w') >= 0;
      const maxH = north ? y1 : S.h - y0;
      if (ht > maxH) { ht = maxH; w = ht * r; }
      if (west) x0 = x1 - w; else x1 = x0 + w;
      if (north) y0 = y1 - ht; else y1 = y0 + ht;
    }
    S.crop = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  }
  function onUp() {
    if (!drag) return;
    const was = drag.mode;
    drag = null;
    if (was === 'paint' || was === 'move' || was === 'scale' || was === 'rotate') { thumbCache = null; refreshLayers(); if (S.pane === 'props' && was !== 'paint') buildProps(); }
    drawOverlay();
  }
  function cursorFor(tool) {
    return tool === 'hand' ? 'grab' : tool === 'text' ? 'text' : (tool === 'magic' || tool === 'crop') ? 'crosshair' : isPaintTool() ? 'none' : 'default';
  }

  /* ============================ UI: actions / tools ============================ */
  function setTool(id) {
    if (S.tool === 'crop' && id !== 'crop') S.crop = null;
    S.tool = id;
    if (id === 'crop' && S.w) S.crop = cropRect(S.cropRatio);
    if (ov) ov.style.cursor = cursorFor(id);
    buildTools(); buildOpts(); drawOverlay();
  }
  function buildActions() {
    actionsBar.textContent = '';
    actionsBar.classList.toggle('nodoc', !S.w);
    undoBtn = ibtn('undo', 'act_undo', undo);
    redoBtn = ibtn('redo', 'act_redo', redo);
    zoomLabel = mk('span', { class: 'zl', text: S.w ? Math.round(S.zoom * 100) + '%' : '100%' });
    actionsBar.append(
      tbtn('act_new', openNewDialog, 'newdoc'),
      tbtn('act_open', () => fileInput.click(), 'open'),
      tbtn('act_export', openExportDialog, 'save', 'primary'),
      mk('i', { class: 'sep' }),
      undoBtn, redoBtn,
      mk('i', { class: 'sep' }),
      ibtn('zout', 'act_zoomout', () => { if (!needDoc()) setZoom(S.zoom / 1.25); }), zoomLabel,
      ibtn('zin', 'act_zoomin', () => { if (!needDoc()) setZoom(S.zoom * 1.25); }), ibtn('fit', 'act_fit', () => { if (!needDoc()) fitZoom(); }),
      mk('i', { class: 'sep' }),
      ibtn('rotl', 'act_rotl', () => rotateDoc(false)), ibtn('rotr', 'act_rotr', () => rotateDoc(true)),
      ibtn('fliph', 'act_fliph', () => flipDoc('h')), ibtn('flipv', 'act_flipv', () => flipDoc('v')),
      ibtn('resize', 'act_resize', openResizeDialog), ibtn('flatten', 'act_flatten', flatten)
    );
    updateUndoButtons();
  }
  function buildTools() {
    toolsBar.textContent = '';
    TOOLS.forEach(td => {
      const b = mk('button', {
        class: 'tb' + (S.tool === td.id ? ' active' : ''), type: 'button',
        title: t('tool_' + td.id) + ' (' + td.key.toUpperCase() + ')', 'aria-label': t('tool_' + td.id),
        onclick: () => { setTool(td.id); if (!S.w) toast(t('need_doc')); }
      });
      b.appendChild(icon(td.icon, 22));
      toolsBar.appendChild(b);
    });
  }
  function updateCropInfo() {
    const el = $('#cropInfo');
    if (el && S.crop) el.textContent = Math.round(S.crop.w) + ' × ' + Math.round(S.crop.h);
  }
  function buildOpts() {
    optsBar.textContent = '';
    const tl = S.tool;
    const add = (...n) => optsBar.append(...n);
    const fmtPx = v => v + 'px', fmtPc = v => v + '%';
    if (tl === 'move') add(mk('span', { class: 'hint', text: t('hint_move') }));
    else if (tl === 'hand') add(mk('span', { class: 'hint', text: t('hint_hand') }));
    else if (tl === 'brush') add(
      ctlColor(t('opt_color'), S.brush.color, v => { S.brush.color = v; }),
      ctlRange(t('opt_size'), 1, 400, 1, S.brush.size, v => { S.brush.size = v; }, fmtPx),
      ctlRange(t('opt_hard'), 0, 100, 1, S.brush.hardness, v => { S.brush.hardness = v; }, fmtPc),
      ctlRange(t('opt_flow'), 1, 100, 1, S.brush.flow, v => { S.brush.flow = v; }, fmtPc));
    else if (tl === 'eraser') add(
      ctlRange(t('opt_size'), 1, 400, 1, S.eraser.size, v => { S.eraser.size = v; }, fmtPx),
      ctlRange(t('opt_hard'), 0, 100, 1, S.eraser.hardness, v => { S.eraser.hardness = v; }, fmtPc),
      ctlRange(t('opt_flow'), 1, 100, 1, S.eraser.flow, v => { S.eraser.flow = v; }, fmtPc));
    else if (tl === 'mask') add(
      ctlSelect(t('opt_maskmode'), [{ v: 'hide', label: t('mask_hide') }, { v: 'reveal', label: t('mask_reveal') }], S.maskb.mode, v => { S.maskb.mode = v; }),
      ctlRange(t('opt_size'), 1, 400, 1, S.maskb.size, v => { S.maskb.size = v; }, fmtPx),
      ctlRange(t('opt_hard'), 0, 100, 1, S.maskb.hardness, v => { S.maskb.hardness = v; }, fmtPc),
      ctlRange(t('opt_flow'), 1, 100, 1, S.maskb.flow, v => { S.maskb.flow = v; }, fmtPc));
    else if (tl === 'magic') add(
      ctlRange(t('opt_tol'), 1, 100, 1, S.magic.tol, v => { S.magic.tol = v; }, fmtPc),
      ctlRange(t('opt_soft'), 0, 100, 1, S.magic.soft, v => { S.magic.soft = v; }, fmtPc),
      ctlCheck(t('opt_contig'), S.magic.contiguous, v => { S.magic.contiguous = v; }),
      tbtn('act_autobg', autoRemoveBg, 'wand'));
    else if (tl === 'text') add(mk('span', { class: 'hint', text: t('hint_text') }));
    else if (tl === 'crop') {
      const ratios = [['0', t('crop_free')], ['1', '1:1'], ['1.3333333', '4:3'], ['1.5', '3:2'], ['1.7777778', '16:9'], ['0.75', '3:4'], ['0.5625', '9:16']];
      add(
        ctlSelect(t('opt_ratio'), ratios.map(r => ({ v: r[0], label: r[1] })), String(ratios.find(r => Math.abs(parseFloat(r[0]) - S.cropRatio) < 0.001)?.[0] || '0'), v => {
          S.cropRatio = parseFloat(v);
          if (S.w) { S.crop = cropRect(S.cropRatio); drawOverlay(); updateCropInfo(); }
        }),
        mk('b', { id: 'cropInfo', class: 'ci', text: S.crop ? Math.round(S.crop.w) + ' × ' + Math.round(S.crop.h) : '' }),
        tbtn('act_apply', applyCrop, 'check', 'primary'),
        tbtn('act_cancel', () => setTool('move'), 'x'));
    }
  }

  /* ============================ UI: panes ============================ */
  const PANE_IDS = ['layers', 'adjust', 'filters', 'props'];
  function setPane(id, rebuild) {
    S.pane = id;
    buildTabs();
    PANE_IDS.forEach(k => { panes[k].hidden = k !== id; });
    if (rebuild !== false) buildPane(id);
  }
  function buildTabs() {
    tabsBar.textContent = '';
    PANE_IDS.forEach(k => tabsBar.appendChild(mk('button', {
      class: 'tab' + (S.pane === k ? ' active' : ''), type: 'button', onclick: () => setPane(k), text: t('tab_' + k)
    })));
  }
  function buildPane(id) {
    if (id === 'layers') buildLayers(); else if (id === 'adjust') buildAdjust();
    else if (id === 'filters') buildFilters(); else buildProps();
  }
  function refreshAll() { buildLayers(); if (S.pane !== 'layers') buildPane(S.pane); updateUndoButtons(); }
  function refreshLayers() { if (S.pane === 'layers') buildLayers(); }

  function drawThumb(l, c) {
    const g = c.getContext('2d');
    g.clearRect(0, 0, c.width, c.height);
    const k = Math.min(c.width / l.canvas.width, c.height / l.canvas.height);
    const w = l.canvas.width * k, ht = l.canvas.height * k;
    g.drawImage(l.canvas, (c.width - w) / 2, (c.height - ht) / 2, w, ht);
  }
  function addBlankLayer() {
    if (!S.w) { toast(t('need_doc')); return; }
    pushHistory();
    S.layerCount++;
    const l = makeLayer('draw', makeCanvas(S.w, S.h), t('layer_n', { n: S.layerCount }));
    S.layers.push(l); S.sel = l.id;
    thumbCache = null; refreshAll(); requestRender();
  }
  function noLayer() { toast(t(S.w ? 'need_layer' : 'need_doc')); }
  function dupLayer() {
    const l = selLayer(); if (!l) { noLayer(); return; }
    pushHistory();
    const c = snapLayer(l);
    c.id = nextId++; c.canvas = cloneCanvas(l.canvas); c.mask = l.mask ? cloneCanvas(l.mask) : null;
    c.name = l.name + ' ' + t('layer_copy'); c.cx += 24; c.cy += 24;
    S.layers.splice(layerIndex(l.id) + 1, 0, c); S.sel = c.id;
    if (!adjIsDefault(c.adj)) scheduleFx(c);
    thumbCache = null; refreshAll(); requestRender();
  }
  function delLayer() {
    const l = selLayer(); if (!l) { noLayer(); return; }
    pushHistory();
    const i = layerIndex(l.id);
    S.layers.splice(i, 1);
    S.sel = S.layers.length ? S.layers[Math.min(i, S.layers.length - 1)].id : null;
    thumbCache = null; refreshAll(); requestRender();
  }
  function layerIndex(id) { return S.layers.findIndex(l => l.id === id); }
  function moveLayer(dir) {
    const l = selLayer(); if (!l) { noLayer(); return; }
    const i = layerIndex(l.id), j = i + dir;
    if (j < 0 || j >= S.layers.length) return;
    pushHistory();
    S.layers[i] = S.layers[j]; S.layers[j] = l;
    refreshAll(); requestRender();
  }
  function selectLayer(id) { S.sel = id; refreshAll(); drawOverlay(); }
  function buildLayers() {
    const box = panes.layers;
    box.textContent = '';
    box.appendChild(mk('div', { class: 'btnrow tight' },
      ibtn('plus', 'lay_add', addBlankLayer), ibtn('image', 'lay_addimg', () => fileInput.click()),
      ibtn('copy', 'lay_dup', dupLayer), ibtn('up', 'lay_up', () => moveLayer(1)), ibtn('down', 'lay_down', () => moveLayer(-1)),
      ibtn('trash', 'lay_del', delLayer, 'danger')));
    if (!S.layers.length) { box.appendChild(mk('p', { class: 'hint', text: S.w ? t('lay_empty') : t('need_doc') })); return; }
    const list = mk('div', { class: 'llist' });
    for (let i = S.layers.length - 1; i >= 0; i--) {
      const l = S.layers[i];
      const th = mk('canvas', { class: 'th', width: 40, height: 40 });
      drawThumb(l, th);
      const eye = mk('button', {
        class: 'eye', type: 'button', title: t('lay_vis'),
        onclick: ev => { ev.stopPropagation(); pushHistory(); l.visible = !l.visible; buildLayers(); requestRender(); }
      });
      eye.appendChild(icon(l.visible ? 'eye' : 'eyeoff', 18));
      const badges = [];
      if (l.mask) badges.push(mk('em', { text: t('badge_mask') }));
      if (!adjIsDefault(l.adj)) badges.push(mk('em', { text: t('badge_fx') }));
      list.appendChild(mk('div', {
        class: 'lrow' + (l.id === S.sel ? ' sel' : '') + (l.visible ? '' : ' off'),
        onclick: () => selectLayer(l.id),
        ondblclick: () => {
          const nm = prompt(t('lay_rename'), l.name);
          if (nm !== null && nm.trim()) { pushHistory(); l.name = nm.trim().slice(0, 40); buildLayers(); }
        }
      }, eye, th, mk('span', { class: 'ln', text: l.name }), badges));
    }
    box.appendChild(list);
  }
  function buildAdjust() {
    const box = panes.adjust;
    box.textContent = '';
    const l = selLayer();
    if (!l) { box.appendChild(mk('p', { class: 'hint', text: t('select_layer_first') })); return; }
    ADJ.forEach(a => {
      const key = a[0];
      box.appendChild(ctlRange(t('adj_' + key), a[1], a[2], a[3], l.adj[key], v => {
        const cur = selLayer(); if (!cur) return;
        pushHistory('adj' + cur.id);
        cur.adj[key] = v; scheduleFx(cur); requestRender();
      }, v => String(v)));
    });
    box.appendChild(ctlButtons([
      tbtn('adj_reset', () => { const cur = selLayer(); if (!cur) return; pushHistory(); cur.adj = defAdj(); scheduleFx(cur); buildAdjust(); refreshLayers(); }),
      tbtn('adj_apply', () => { const cur = selLayer(); if (!cur) return; pushHistory(); bakeAdj(cur); thumbCache = null; buildAdjust(); refreshLayers(); requestRender(); }, 'check', 'primary')
    ]));
    box.appendChild(mk('p', { class: 'hint', text: t('adj_note') }));
  }
  function presetThumbs(l) {
    if (thumbCache && thumbCache.src === l.canvas) return thumbCache.items;
    const k = 84 / Math.max(l.canvas.width, l.canvas.height);
    const base = makeCanvas(l.canvas.width * Math.min(1, k), l.canvas.height * Math.min(1, k));
    base.getContext('2d').drawImage(l.canvas, 0, 0, base.width, base.height);
    const items = PRESETS.map(p => applyAdj(base, Object.assign(defAdj(), p.v), 1));
    thumbCache = { src: l.canvas, items: items };
    return items;
  }
  function buildFilters() {
    const box = panes.filters;
    box.textContent = '';
    const l = selLayer();
    if (!l) { box.appendChild(mk('p', { class: 'hint', text: t('select_layer_first') })); return; }
    const items = presetThumbs(l);
    const grid = mk('div', { class: 'fgrid' });
    PRESETS.forEach((p, i) => {
      grid.appendChild(mk('button', {
        class: 'fbtn', type: 'button',
        onclick: () => {
          const cur = selLayer(); if (!cur) return;
          pushHistory(); cur.adj = Object.assign(defAdj(), p.v); scheduleFx(cur); refreshLayers(); requestRender();
        }
      }, items[i], mk('span', { text: t('flt_' + p.id) })));
    });
    box.appendChild(grid);
  }
  function buildProps() {
    const box = panes.props;
    box.textContent = '';
    const l = selLayer();
    if (!l) { box.appendChild(mk('p', { class: 'hint', text: t('select_layer_first') })); return; }
    const hist = (key, fn) => v => { const cur = selLayer(); if (!cur) return; pushHistory(key + cur.id); fn(cur, v); requestRender(); };
    box.appendChild(mk('h4', { text: t('sec_layer') }));
    box.appendChild(ctlRange(t('prop_opacity'), 0, 100, 1, Math.round(l.opacity * 100), hist('op', (c, v) => { c.opacity = v / 100; }), v => v + '%'));
    box.appendChild(ctlSelect(t('prop_blend'), BLENDS.map(b => ({ v: b, label: t('blend_' + b) })), l.blend, v => { pushHistory(); l.blend = v; requestRender(); }));
    box.appendChild(ctlRange(t('prop_scale'), 2, 500, 1, Math.round(Math.abs(l.sx) * 100), hist('sc', (c, v) => {
      c.sx = (c.sx < 0 ? -1 : 1) * v / 100; c.sy = (c.sy < 0 ? -1 : 1) * v / 100;
    }), v => v + '%'));
    let deg = l.rot * 180 / Math.PI;
    deg = ((deg % 360) + 540) % 360 - 180;
    box.appendChild(ctlRange(t('prop_rotate'), -180, 180, 1, Math.round(deg), hist('rt', (c, v) => { c.rot = v * Math.PI / 180; }), v => v + '°'));
    box.appendChild(ctlButtons([
      tbtn('prop_center', () => { pushHistory(); l.cx = S.w / 2; l.cy = S.h / 2; requestRender(); }),
      tbtn('prop_fit', () => { pushHistory(); l.sx = (l.sx < 0 ? -1 : 1) * Math.min(S.w / l.canvas.width, S.h / l.canvas.height); l.sy = (l.sy < 0 ? -1 : 1) * Math.abs(l.sx); l.cx = S.w / 2; l.cy = S.h / 2; buildProps(); requestRender(); }),
      tbtn('prop_fill', () => { pushHistory(); const k = Math.max(S.w / l.canvas.width, S.h / l.canvas.height); l.sx = (l.sx < 0 ? -1 : 1) * k; l.sy = (l.sy < 0 ? -1 : 1) * k; l.cx = S.w / 2; l.cy = S.h / 2; buildProps(); requestRender(); }),
      ibtn('fliph', 'act_fliph', () => { pushHistory(); l.sx = -l.sx; requestRender(); }),
      ibtn('flipv', 'act_flipv', () => { pushHistory(); l.sy = -l.sy; requestRender(); })
    ]));

    /* mask */
    box.appendChild(mk('h4', { text: t('sec_mask') }));
    if (!l.mask) {
      box.appendChild(ctlButtons([tbtn('mask_add', () => {
        if (l.type === 'text') { pushHistory(); l.type = 'image'; l.text = null; toast(t('rasterized')); } else pushHistory();
        l.mask = fullMask(l); setTool('mask'); refreshAll(); requestRender();
      }, 'mask')]));
    } else {
      box.appendChild(ctlButtons([
        tbtn('mask_paint', () => setTool('mask'), 'brush'),
        tbtn('mask_invert', () => {
          pushHistory();
          const m = cloneCanvas(l.mask), g = m.getContext('2d', { willReadFrequently: true });
          const im = g.getImageData(0, 0, m.width, m.height), d = im.data;
          for (let i = 3; i < d.length; i += 4) d[i] = 255 - d[i];
          g.putImageData(im, 0, 0); l.mask = m; requestRender(); refreshLayers();
        }),
        tbtn('mask_apply', () => {
          pushHistory();
          if (l.type === 'text') { l.type = 'image'; l.text = null; }
          bakeAdj(l);
          const c = cloneCanvas(l.canvas), g = c.getContext('2d');
          g.globalCompositeOperation = 'destination-in'; g.drawImage(l.mask, 0, 0);
          l.canvas = c; l.mask = null; thumbCache = null; buildProps(); requestRender(); refreshLayers();
        }),
        tbtn('mask_del', () => { pushHistory(); l.mask = null; buildProps(); requestRender(); refreshLayers(); }, 'trash', 'danger')
      ]));
    }

    /* text */
    if (l.type === 'text' && l.text) {
      const tx = l.text;
      const upd = fn => v => { pushHistory('tx' + l.id); fn(v); Object.assign(S.textDef, { font: tx.font, size: tx.size, color: tx.color, bold: tx.bold, italic: tx.italic, align: tx.align, strokeW: tx.strokeW, strokeColor: tx.strokeColor, bg: tx.bg, shadow: tx.shadow, dir: tx.dir }); updateText(l); refreshLayers(); };
      box.appendChild(mk('h4', { text: t('sec_text') }));
      const ta = ctlText(t('txt_content'), tx.text, upd(v => { tx.text = v; }), true);
      box.appendChild(ta);
      box.appendChild(ctlSelect(t('txt_font'), FONTS.map(f => ({ v: f[1], label: f[0] })), tx.font, upd(v => { tx.font = v; })));
      box.appendChild(ctlRange(t('txt_size'), 8, 600, 1, tx.size, upd(v => { tx.size = v; }), v => v + 'px'));
      box.appendChild(ctlColor(t('txt_color'), tx.color, upd(v => { tx.color = v; })));
      box.appendChild(ctlButtons([
        mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.bold, onchange: e => upd(v => { tx.bold = v; })(e.target.checked) }), mk('span', { text: t('txt_bold') })),
        mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.italic, onchange: e => upd(v => { tx.italic = v; })(e.target.checked) }), mk('span', { text: t('txt_italic') })),
        mk('label', { class: 'ctl chk' }, mk('input', { type: 'checkbox', checked: tx.shadow, onchange: e => upd(v => { tx.shadow = v; })(e.target.checked) }), mk('span', { text: t('txt_shadow') }))
      ]));
      box.appendChild(ctlSelect(t('txt_align'), [{ v: 'left', label: t('al_left') }, { v: 'center', label: t('al_center') }, { v: 'right', label: t('al_right') }], tx.align, upd(v => { tx.align = v; })));
      box.appendChild(ctlSelect(t('txt_dir'), [{ v: 'auto', label: t('dir_auto') }, { v: 'rtl', label: t('dir_rtl') }, { v: 'ltr', label: t('dir_ltr') }], tx.dir, upd(v => { tx.dir = v; })));
      box.appendChild(ctlRange(t('txt_stroke'), 0, 40, 1, tx.strokeW, upd(v => { tx.strokeW = v; }), v => v + 'px'));
      box.appendChild(ctlColor(t('txt_strokecolor'), tx.strokeColor, upd(v => { tx.strokeColor = v; })));
      box.appendChild(ctlCheck(t('txt_bg'), !!tx.bg, upd(v => { tx.bg = v ? '#000000' : ''; })));
      box.appendChild(ctlButtons([tbtn('txt_raster', () => { pushHistory(); l.type = 'image'; l.text = null; buildProps(); refreshLayers(); }, 'layers')]));
    }
  }

  /* ============================ dialogs ============================ */
  function openNewDialog() {
    const sizes = [['1080 × 1080', 1080, 1080], ['1080 × 1350', 1080, 1350], ['1080 × 1920', 1080, 1920], ['1920 × 1080', 1920, 1080],
      ['1280 × 720', 1280, 720], ['2480 × 3508 (A4)', 2480, 3508], ['3000 × 2000', 3000, 2000]];
    let w = 1080, ht = 1080, bgMode = 'white', bgColor = '#ffffff';
    const wi = ctlNumber(t('dlg_width'), w, 16, MAXDOC, 1, v => { w = v; });
    const hi = ctlNumber(t('dlg_height'), ht, 16, MAXDOC, 1, v => { ht = v; });
    const sizeSel = ctlSelect(t('dlg_preset'), sizes.map((s, i) => ({ v: String(i), label: s[0] })), '0', v => {
      const s = sizes[parseInt(v, 10)]; w = s[1]; ht = s[2]; wi.setValue(w); hi.setValue(ht);
    });
    const bgSel = ctlSelect(t('dlg_bg'), [{ v: 'white', label: t('bg_white') }, { v: 'black', label: t('bg_black') }, { v: 'transparent', label: t('bg_transparent') }, { v: 'color', label: t('bg_color') }], bgMode, v => { bgMode = v; });
    const bgCol = ctlColor(t('bg_color'), bgColor, v => { bgColor = v; bgMode = 'color'; bgSel.querySelector('select').value = 'color'; });
    openModal(t('act_new'), mk('div', { class: 'form' }, sizeSel, wi, hi, bgSel, bgCol), [
      { label: t('act_cancel') },
      {
        label: t('act_create'), primary: true, onClick: () => {
          if (S.layers.length && !confirm(t('confirm_new'))) return false;
          const bg = bgMode === 'white' ? '#ffffff' : bgMode === 'black' ? '#000000' : bgMode === 'color' ? bgColor : null;
          newDoc(w, ht, bg);
        }
      }
    ]);
  }
  function openResizeDialog() {
    if (!S.w) { toast(t('need_doc')); return; }
    let nw = S.w;
    const info = mk('p', { class: 'hint', text: S.w + ' × ' + S.h });
    const wi = ctlNumber(t('dlg_width'), S.w, 16, MAXDOC, 1, v => { nw = v; info.textContent = Math.round(S.w) + ' × ' + Math.round(S.h) + '  →  ' + Math.round(v) + ' × ' + Math.round(S.h * v / S.w); });
    openModal(t('act_resize'), mk('div', { class: 'form' }, wi, info), [
      { label: t('act_cancel') },
      { label: t('act_apply'), primary: true, onClick: () => { if (Math.abs(nw - S.w) >= 1) resizeDoc(nw); } }
    ]);
  }
  function openExportDialog() {
    if (!S.w) { toast(t('need_doc')); return; }
    let fmt = 'png', q = 0.92, name = S.docName || 'image';
    const qRow = ctlRange(t('exp_quality'), 40, 100, 1, 92, v => { q = v / 100; }, v => v + '%');
    qRow.hidden = true;
    const fSel = ctlSelect(t('exp_format'), [{ v: 'png', label: 'PNG' }, { v: 'jpeg', label: 'JPEG' }, { v: 'webp', label: 'WebP' }], fmt, v => { fmt = v; qRow.hidden = v === 'png'; });
    const nm = ctlText(t('exp_name'), name, v => { name = v; });
    openModal(t('act_export'), mk('div', { class: 'form' }, mk('p', { class: 'hint', text: S.w + ' × ' + S.h + ' px' }), fSel, qRow, nm), [
      { label: t('act_cancel') },
      {
        label: t('act_save'), primary: true, onClick: () => {
          const mime = 'image/' + fmt;
          const c = makeCanvas(S.w, S.h), g = c.getContext('2d');
          if (fmt === 'jpeg') { g.fillStyle = '#ffffff'; g.fillRect(0, 0, c.width, c.height); }
          renderDoc(g, true);
          c.toBlob(b => {
            if (!b) { toast(t('err_export')); return; }
            let ext = fmt === 'jpeg' ? 'jpg' : fmt;
            if (b.type && b.type !== mime) { ext = 'png'; toast(t('exp_fallback')); }
            downloadBlob(b, (name || 'image').replace(/[\\/:*?"<>|]+/g, '_') + '.' + ext);
          }, mime, q);
        }
      }
    ]);
  }

  /* ============================ init ============================ */
  function init() {
    cv = $('#pCanvas'); ov = $('#pOverlay'); stage = $('#pStage'); wrap = $('#pWrap'); emptyBox = $('#pEmpty'); fileInput = $('#pFile');
    cx = cv.getContext('2d'); ox = ov.getContext('2d');
    actionsBar = $('#pActions'); toolsBar = $('#pTools'); optsBar = $('#pOpts'); tabsBar = $('#pTabs');
    PANE_IDS.forEach(k => { panes[k] = $('#pane-' + k); });
    dpr = window.devicePixelRatio || 1;

    ov.addEventListener('pointerdown', onDown);
    ov.addEventListener('pointermove', onMove);
    ov.addEventListener('pointerup', onUp);
    ov.addEventListener('pointercancel', onUp);
    ov.addEventListener('pointerleave', () => { if (!drag) { S.cursor = null; drawOverlay(); } });
    ov.addEventListener('dblclick', e => {
      if (S.tool !== 'move' || !S.w) return;
      const hit = hitLayer(evDoc(e));
      if (hit && hit.type === 'text') { S.sel = hit.id; refreshAll(); setPane('props', true); }
    });
    stage.addEventListener('wheel', e => {
      if (e.ctrlKey || e.metaKey) { e.preventDefault(); setZoom(S.zoom * (e.deltaY < 0 ? 1.1 : 1 / 1.1)); }
    }, { passive: false });
    ['dragenter', 'dragover'].forEach(n => stage.addEventListener(n, e => { e.preventDefault(); stage.classList.add('drop'); }));
    ['dragleave', 'drop'].forEach(n => stage.addEventListener(n, () => stage.classList.remove('drop')));
    stage.addEventListener('drop', e => { e.preventDefault(); if (e.dataTransfer && e.dataTransfer.files.length) openFiles(e.dataTransfer.files); });
    fileInput.addEventListener('change', () => { openFiles(fileInput.files); fileInput.value = ''; });
    window.addEventListener('resize', () => { if (visible && S.w && S.autoFit) fitZoom(); else if (visible && S.w) resizeStage(); });
    document.addEventListener('paste', e => {
      if (!visible) return;
      const files = e.clipboardData && e.clipboardData.files;
      if (files && files.length) { openFiles(files); }
    });
    ov.style.cursor = cursorFor(S.tool);
    relang();
    setPane('layers');
    resizeStage();
  }
  function relang() {
    buildActions(); buildTools(); buildOpts(); buildTabs(); buildPane(S.pane);
    $$('[data-pane-empty]').forEach(n => { n.textContent = t('empty_title'); });
  }
  function show(v) {
    visible = v;
    if (v && S.w) { if (S.autoFit) fitZoom(); else resizeStage(); requestRender(); }
  }
  function onKey(e) {
    if (!visible) return false;
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return false;
    if (document.querySelector('dialog[open]')) return false;
    const k = keyOf(e);
    if ((e.ctrlKey || e.metaKey) && k === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return true; }
    if ((e.ctrlKey || e.metaKey) && k === 'y') { e.preventDefault(); redo(); return true; }
    if ((e.ctrlKey || e.metaKey) && k === '0') { e.preventDefault(); fitZoom(); return true; }
    if (e.ctrlKey || e.metaKey || e.altKey) return false;
    const td = TOOLS.find(x => x.key === k);
    if (td) { setTool(td.id); return true; }
    if (k === 'delete' || k === 'backspace') { delLayer(); return true; }
    if (k === '[' || k === ']') {
      if (isPaintTool()) {
        const cfg = S.tool === 'brush' ? S.brush : S.tool === 'eraser' ? S.eraser : S.maskb;
        cfg.size = clamp(Math.round(cfg.size * (k === ']' ? 1.15 : 1 / 1.15)), 1, 400);
        buildOpts(); return true;
      }
    }
    return false;
  }

  return {
    init: init, relang: relang, show: show, onKey: onKey, openFiles: openFiles,
    _S: S, _api: { newDoc, addImageLayer, addBlankLayer, undo, redo, rotateDoc, flipDoc, resizeDoc, flatten, applyCrop, cropRect, autoRemoveBg, setTool, renderDoc, applyAdj, defAdj, scheduleFx, makeLayer, updateText, renderTextCanvas, pushHistory, requestRender, selectLayer, fitZoom, setZoom, buildProps, refreshAll }
  };
})();
