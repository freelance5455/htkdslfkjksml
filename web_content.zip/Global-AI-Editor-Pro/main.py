import os
import re
import json
import base64
import asyncio
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import aiohttp
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "history.sqlite3"

APP_NAME = os.getenv("APP_NAME", "Global AI Editor")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
IMAGE_MODEL = os.getenv("IMAGE_MODEL", "gpt-image-1")
TTS_MODEL = os.getenv("TTS_MODEL", "gpt-4o-mini-tts")
DEFAULT_TTS_VOICE = os.getenv("DEFAULT_TTS_VOICE", "alloy")
MAX_PROMPT_LENGTH = int(os.getenv("MAX_PROMPT_LENGTH", "4000"))
MAX_TEXT_LENGTH = int(os.getenv("MAX_TEXT_LENGTH", "5000"))
MAX_OUTPUT_TOKENS = 0  # reserved for future text-generation features
MAX_DOWNLOAD_BYTES = 25 * 1024 * 1024
APP_USER = os.getenv("APP_USER", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
SAFE_FILE_RE = re.compile(r"[0-9a-f\-]{36}\.(png|mp3)")

app = FastAPI(title=APP_NAME, version="0.3.0")

allowed_origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

if not APP_PASSWORD:
    print("WARNING: APP_PASSWORD is not set - anyone who can reach this server can spend your API key. "
          "Set APP_PASSWORD in .env before exposing it beyond your own computer.")

@app.middleware("http")
async def basic_auth(request: Request, call_next):
    """Optional HTTP Basic auth for everything except /api/health (enabled when APP_PASSWORD is set)."""
    if not APP_PASSWORD or request.url.path == "/api/health":
        return await call_next(request)
    header = request.headers.get("authorization", "")
    if header.lower().startswith("basic "):
        try:
            user, _, pwd = base64.b64decode(header[6:]).decode("utf-8").partition(":")
        except Exception:
            user, pwd = "", ""
        if secrets.compare_digest(user.encode(), APP_USER.encode()) and secrets.compare_digest(pwd.encode(), APP_PASSWORD.encode()):
            return await call_next(request)
    return Response("Authentication required", status_code=401, headers={"WWW-Authenticate": 'Basic realm="Editor", charset="UTF-8"'})

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                prompt TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                file_name TEXT,
                mime_type TEXT,
                error_message TEXT
            )
        """)

init_db()

class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=MAX_PROMPT_LENGTH)
    size: str = Field(default="1024x1024", pattern=r"^(1024x1024|1536x1024|1024x1536)$")

class AudioRequest(BaseModel):
    text: str = Field(min_length=1, max_length=MAX_TEXT_LENGTH)
    voice: str = Field(default=DEFAULT_TTS_VOICE, pattern=r"^(alloy|ash|coral|echo|fable|onyx|nova|sage|shimmer)$")
    instructions: Optional[str] = Field(default=None, max_length=1000)

def record_job(job_id, kind, prompt, status, file_name=None, mime_type=None, error_message=None):
    with db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO jobs(id,kind,prompt,status,created_at,file_name,mime_type,error_message) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, kind, prompt, status, datetime.now(timezone.utc).isoformat(), file_name, mime_type, error_message)
        )

async def provider_request(endpoint: str, payload: dict, timeout_seconds: int = 180):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=503, detail="AI provider is not configured. Add OPENAI_API_KEY to your .env file.")
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(f"{OPENAI_BASE_URL}{endpoint}", headers=headers, json=payload) as resp:
            if resp.status >= 400:
                body = await resp.text()
                # Avoid returning headers or secrets; provider messages can still aid debugging.
                raise HTTPException(status_code=502, detail=f"AI provider returned HTTP {resp.status}: {body[:700]}")
            return await resp.read(), resp.headers.get("Content-Type", "")

async def download_bytes(url: str, timeout_seconds: int = 60) -> bytes:
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url) as resp:
            if resp.status >= 400:
                raise HTTPException(status_code=502, detail=f"Could not download generated image (HTTP {resp.status}).")
            if not resp.headers.get("Content-Type", "").startswith("image/"):
                raise HTTPException(status_code=502, detail="Generated image URL did not return an image.")
            if resp.content_length and resp.content_length > MAX_DOWNLOAD_BYTES:
                raise HTTPException(status_code=502, detail="Generated image is too large.")
            data = await resp.content.read(MAX_DOWNLOAD_BYTES + 1)
            if len(data) > MAX_DOWNLOAD_BYTES:
                raise HTTPException(status_code=502, detail="Generated image is too large.")
            return data

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": APP_NAME,
        "version": app.version,
        "ai_configured": bool(OPENAI_API_KEY),
        "storage": "sqlite",
    }

@app.get("/api/config")
def public_config():
    return {"app_name": APP_NAME, "ai_configured": bool(OPENAI_API_KEY), "image_model": IMAGE_MODEL, "tts_model": TTS_MODEL}

@app.post("/api/generate-image")
async def generate_image(req: ImageRequest):
    prompt = req.prompt.strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="Prompt cannot be empty.")
    job_id = str(uuid.uuid4())
    record_job(job_id, "image", prompt, "processing")
    try:
        payload = {"model": IMAGE_MODEL, "prompt": prompt, "size": req.size, "n": 1}
        if IMAGE_MODEL.startswith("dall-e"):
            # gpt-image-* models always return b64_json and reject this parameter.
            payload["response_format"] = "b64_json"
        raw, _ = await provider_request("/images/generations", payload)
        data = json.loads(raw.decode("utf-8"))
        item = (data.get("data") or [{}])[0]
        b64 = item.get("b64_json")
        if not b64 and item.get("url"):
            b64 = base64.b64encode(await download_bytes(item["url"])).decode("utf-8")
        if not b64:
            raise HTTPException(status_code=502, detail="Provider response did not contain image data.")
        image_bytes = base64.b64decode(b64)
        file_name = f"{job_id}.png"
        (DATA_DIR / file_name).write_bytes(image_bytes)
        record_job(job_id, "image", prompt, "completed", file_name, "image/png")
        return {"status": "success", "job_id": job_id, "image_data": b64, "mime_type": "image/png"}
    except asyncio.CancelledError:
        record_job(job_id, "image", prompt, "failed", error_message="Request cancelled")
        raise
    except HTTPException as e:
        record_job(job_id, "image", prompt, "failed", error_message=str(e.detail))
        raise
    except Exception:
        record_job(job_id, "image", prompt, "failed", error_message="Unexpected provider response")
        raise HTTPException(status_code=502, detail="Image generation failed. Check provider settings and server logs.")

@app.post("/api/generate-audio")
async def generate_audio(req: AudioRequest):
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Text cannot be empty.")
    job_id = str(uuid.uuid4())
    record_job(job_id, "audio", text[:1000], "processing")
    payload = {"model": TTS_MODEL, "voice": req.voice, "input": text, "response_format": "mp3"}
    instructions = (req.instructions or "").strip()
    if instructions:
        payload["instructions"] = instructions
    try:
        audio_bytes, _ = await provider_request("/audio/speech", payload, timeout_seconds=180)
        file_name = f"{job_id}.mp3"
        (DATA_DIR / file_name).write_bytes(audio_bytes)
        record_job(job_id, "audio", text[:1000], "completed", file_name, "audio/mpeg")
        return {"status": "success", "job_id": job_id, "audio_data": base64.b64encode(audio_bytes).decode("utf-8"), "mime_type": "audio/mpeg"}
    except asyncio.CancelledError:
        record_job(job_id, "audio", text[:1000], "failed", error_message="Request cancelled")
        raise
    except HTTPException as e:
        record_job(job_id, "audio", text[:1000], "failed", error_message=str(e.detail))
        raise
    except Exception:
        record_job(job_id, "audio", text[:1000], "failed", error_message="Unexpected provider response")
        raise HTTPException(status_code=502, detail="Audio generation failed. Check provider settings and server logs.")

@app.get("/api/history")
def history(limit: int = 20):
    limit = max(1, min(limit, 100))
    with db() as conn:
        rows = conn.execute(
            "SELECT id,kind,prompt,status,created_at,file_name,mime_type,error_message FROM jobs ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return {"items": [dict(row) for row in rows]}

@app.get("/api/files/{file_name}")
def get_file(file_name: str):
    # Only permit a flat filename generated by this application.
    if not SAFE_FILE_RE.fullmatch(file_name):
        raise HTTPException(status_code=400, detail="Invalid file name.")
    path = DATA_DIR / file_name
    if not path.is_file():
        raise HTTPException(status_code=404, detail="File not found.")
    media_type = "audio/mpeg" if file_name.endswith(".mp3") else "image/png"
    return FileResponse(path, media_type=media_type, filename=file_name)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
# Must stay LAST: serves the photo/video/AI editor (index.html and its assets) from "/".
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="editor")
