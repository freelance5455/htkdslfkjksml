import os
import re
import json
import base64
import asyncio
import secrets
import sqlite3
import time
import uuid
import logging
from collections import defaultdict, deque
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import aiohttp
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "history.sqlite3"

APP_NAME = os.getenv("APP_NAME", "Global AI Editor")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
IMAGE_MODEL = os.getenv("IMAGE_MODEL", "gpt-image-1")
TTS_MODEL = os.getenv("TTS_MODEL", "gpt-4o-mini-tts")
DEFAULT_TTS_VOICE = os.getenv("DEFAULT_TTS_VOICE", "alloy")
MAX_PROMPT_LENGTH = int(os.getenv("MAX_PROMPT_LENGTH", "4000"))
MAX_TEXT_LENGTH = int(os.getenv("MAX_TEXT_LENGTH", "5000"))
MAX_OUTPUT_TOKENS = 0  # reserved for future text-generation features
MAX_DOWNLOAD_BYTES = 25 * 1024 * 1024
APP_USER = os.getenv("APP_USER", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
SAFE_FILE_RE = re.compile(r"[0-9a-f\-]{36}\.(png|mp3)")

# --- production hardening settings (all optional, see .env.example) ---
def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default

RATE_LIMIT_PER_MIN = _int_env("RATE_LIMIT_PER_MIN", 10)       # generate requests per client IP per minute (0 = off)
MAX_CONCURRENT_JOBS = max(1, _int_env("MAX_CONCURRENT_JOBS", 3))
FILE_RETENTION_DAYS = _int_env("FILE_RETENTION_DAYS", 30)      # 0 = keep forever
MAX_BODY_BYTES = _int_env("MAX_BODY_BYTES", 64 * 1024)
ENABLE_DOCS = os.getenv("ENABLE_DOCS", "").lower() in ("1", "true", "yes")
HTTPS_HEADERS = os.getenv("HTTPS_HEADERS", "").lower() in ("1", "true", "yes")   # set when served behind HTTPS (adds HSTS)
ALLOWED_HOSTS = [x.strip() for x in os.getenv("ALLOWED_HOSTS", "").split(",") if x.strip()]

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO").upper(), format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("editor")

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
       "img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' data: blob:; "
       "font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")

JOB_SEM = asyncio.Semaphore(MAX_CONCURRENT_JOBS)
_hits = defaultdict(deque)        # client ip -> timestamps of recent generate calls
_auth_fail = defaultdict(deque)   # client ip -> timestamps of recent failed logins

def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"

def _too_many(bucket, key: str, limit: int, window: float) -> bool:
    now = time.monotonic()
    q = bucket[key]
    while q and now - q[0] > window:
        q.popleft()
    if len(bucket) > 5000:        # keep memory bounded
        for k in [k for k, v in bucket.items() if not v or now - v[-1] > window]:
            bucket.pop(k, None)
    return len(q) >= limit

def limit_generate(request: Request):
    """Dependency: per-IP rate limit for the (paid) generate endpoints."""
    if RATE_LIMIT_PER_MIN <= 0:
        return
    ip = _client_ip(request)
    if _too_many(_hits, ip, RATE_LIMIT_PER_MIN, 60.0):
        raise HTTPException(status_code=429, detail="Too many requests. Please wait a minute.")
    _hits[ip].append(time.monotonic())

@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def cleanup_old_files() -> int:
    """Delete generated files (and their history rows) older than FILE_RETENTION_DAYS."""
    if FILE_RETENTION_DAYS <= 0:
        return 0
    cutoff = datetime.now(timezone.utc) - timedelta(days=FILE_RETENTION_DAYS)
    removed = 0
    with db() as conn:
        rows = conn.execute("SELECT id,file_name FROM jobs WHERE created_at < ?", (cutoff.isoformat(),)).fetchall()
        for r in rows:
            fn = r["file_name"]
            if fn and SAFE_FILE_RE.fullmatch(fn):
                try:
                    (DATA_DIR / fn).unlink(missing_ok=True)
                except OSError:
                    log.warning("could not delete %s", fn)
            conn.execute("DELETE FROM jobs WHERE id=?", (r["id"],))
            removed += 1
    return removed

async def _cleanup_loop():
    while True:
        try:
            n = await asyncio.to_thread(cleanup_old_files)
            if n:
                log.info("retention cleanup removed %d old jobs", n)
        except Exception:
            log.exception("retention cleanup failed")
        await asyncio.sleep(6 * 3600)

@asynccontextmanager
async def lifespan(app_: FastAPI):
    # a crash or restart can leave jobs stuck in "processing": mark them failed
    with db() as conn:
        conn.execute("UPDATE jobs SET status='failed', error_message='Interrupted by server restart' WHERE status='processing'")
    task = asyncio.create_task(_cleanup_loop())
    try:
        yield
    finally:
        task.cancel()

app = FastAPI(
    title=APP_NAME, version="0.4.0", lifespan=lifespan,
    docs_url="/docs" if ENABLE_DOCS else None,
    redoc_url="/redoc" if ENABLE_DOCS else None,
    openapi_url="/openapi.json" if ENABLE_DOCS else None,
)

allowed_origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type", "Authorization"],
)

if not APP_PASSWORD:
    print("WARNING: APP_PASSWORD is not set - anyone who can reach this server can spend your API key. "
          "Set APP_PASSWORD in .env before exposing it beyond your own computer.")

@app.middleware("http")
async def basic_auth(request: Request, call_next):
    """Optional HTTP Basic auth for everything except /api/health (enabled when APP_PASSWORD is set)."""
    if not APP_PASSWORD or request.url.path == "/api/health":
        return await call_next(request)
    ip = _client_ip(request)
    if _too_many(_auth_fail, ip, 10, 300.0):
        return Response("Too many failed attempts. Try again in a few minutes.", status_code=429, headers={"Retry-After": "300"})
    header = request.headers.get("authorization", "")
    if header.lower().startswith("basic "):
        try:
            user, _, pwd = base64.b64decode(header[6:]).decode("utf-8").partition(":")
        except Exception:
            user, pwd = "", ""
        if secrets.compare_digest(user.encode(), APP_USER.encode()) and secrets.compare_digest(pwd.encode(), APP_PASSWORD.encode()):
            return await call_next(request)
        _auth_fail[ip].append(time.monotonic())
    return Response("Authentication required", status_code=401, headers={"WWW-Authenticate": 'Basic realm="Editor", charset="UTF-8"'})

@app.middleware("http")
async def limit_body(request: Request, call_next):
    """Reject oversized request bodies early (all JSON bodies here are tiny)."""
    cl = request.headers.get("content-length")
    if cl and cl.isdigit() and int(cl) > MAX_BODY_BYTES:
        return JSONResponse({"detail": "Request body too large."}, status_code=413)
    return await call_next(request)

@app.middleware("http")
async def security_headers(request: Request, call_next):
    """Outermost middleware: adds security + cache headers to every response (including 401/413/429)."""
    response = await call_next(request)
    h = response.headers
    h["Content-Security-Policy"] = CSP
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if HTTPS_HEADERS:
        h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if request.url.path.startswith("/api/"):
        h["Cache-Control"] = "no-store"
    elif "cache-control" not in h:
        h["Cache-Control"] = "no-cache"      # always revalidate the editor files so updates reach users
    return response

app.add_middleware(GZipMiddleware, minimum_size=1024)
if ALLOWED_HOSTS:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=ALLOWED_HOSTS)

def init_db():
    with db() as conn:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                kind TEXT NOT NULL,
                prompt TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                file_name TEXT,
                mime_type TEXT,
                error_message TEXT
            )
        """)

init_db()

class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=MAX_PROMPT_LENGTH)
    size: str = Field(default="1024x1024", pattern=r"^(1024x1024|1536x1024|1024x1536)$")

class AudioRequest(BaseModel):
    text: str = Field(min_length=1, max_length=MAX_TEXT_LENGTH)
    voice: str = Field(default=DEFAULT_TTS_VOICE, pattern=r"^(alloy|ash|coral|echo|fable|onyx|nova|sage|shimmer)$")
    instructions: Optional[str] = Field(default=None, max_length=1000)

def record_job(job_id, kind, prompt, status, file_name=None, mime_type=None, error_message=None):
    with db() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO jobs(id,kind,prompt,status,created_at,file_name,mime_type,error_message) VALUES(?,?,?,?,?,?,?,?)",
            (job_id, kind, prompt, status, datetime.now(timezone.utc).isoformat(), file_name, mime_type, error_message)
        )

async def provider_request(endpoint: str, payload: dict, timeout_seconds: int = 180):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=503, detail="AI provider is not configured. Add OPENAI_API_KEY to your .env file.")
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    headers = {"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"}
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(f"{OPENAI_BASE_URL}{endpoint}", headers=headers, json=payload) as resp:
            if resp.status >= 400:
                body = await resp.text()
                log.warning("provider %s -> HTTP %s: %s", endpoint, resp.status, body[:700])
                # the full body stays in the server log; the browser only gets a short hint
                raise HTTPException(status_code=502, detail=f"AI provider returned HTTP {resp.status}: {body[:300]}")
            return await resp.read(), resp.headers.get("Content-Type", "")

async def download_bytes(url: str, timeout_seconds: int = 60) -> bytes:
    timeout = aiohttp.ClientTimeout(total=timeout_seconds)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url) as resp:
            if resp.status >= 400:
                raise HTTPException(status_code=502, detail=f"Could not download generated image (HTTP {resp.status}).")
            if not resp.headers.get("Content-Type", "").startswith("image/"):
                raise HTTPException(status_code=502, detail="Generated image URL did not return an image.")
            if resp.content_length and resp.content_length > MAX_DOWNLOAD_BYTES:
                raise HTTPException(status_code=502, detail="Generated image is too large.")
            data = await resp.content.read(MAX_DOWNLOAD_BYTES + 1)
            if len(data) > MAX_DOWNLOAD_BYTES:
                raise HTTPException(status_code=502, detail="Generated image is too large.")
            return data

@app.get("/api/health")
def health():
    return {
        "ok": True,
        "app": APP_NAME,
        "version": app.version,
        "ai_configured": bool(OPENAI_API_KEY),
        "storage": "sqlite",
    }

@app.get("/api/config")
def public_config():
    return {"app_name": APP_NAME, "ai_configured": bool(OPENAI_API_KEY), "image_model": IMAGE_MODEL, "tts_model": TTS_MODEL}

@app.post("/api/generate-image", dependencies=[Depends(limit_generate)])
async def generate_image(req: ImageRequest):
    prompt = req.prompt.strip()
    if not prompt:
        raise HTTPException(status_code=400, detail="Prompt cannot be empty.")
    if JOB_SEM.locked():
        raise HTTPException(status_code=429, detail="The server is busy generating other requests. Try again shortly.")
    job_id = str(uuid.uuid4())
    record_job(job_id, "image", prompt, "processing")
    try:
        payload = {"model": IMAGE_MODEL, "prompt": prompt, "size": req.size, "n": 1}
        if IMAGE_MODEL.startswith("dall-e"):
            # gpt-image-* models always return b64_json and reject this parameter.
            payload["response_format"] = "b64_json"
        async with JOB_SEM:
            raw, _ = await provider_request("/images/generations", payload)
        data = json.loads(raw.decode("utf-8"))
        item = (data.get("data") or [{}])[0]
        b64 = item.get("b64_json")
        if not b64 and item.get("url"):
            b64 = base64.b64encode(await download_bytes(item["url"])).decode("utf-8")
        if not b64:
            raise HTTPException(status_code=502, detail="Provider response did not contain image data.")
        image_bytes = base64.b64decode(b64)
        file_name = f"{job_id}.png"
        await asyncio.to_thread((DATA_DIR / file_name).write_bytes, image_bytes)
        record_job(job_id, "image", prompt, "completed", file_name, "image/png")
        return {"status": "success", "job_id": job_id, "image_data": b64, "mime_type": "image/png"}
    except asyncio.CancelledError:
        record_job(job_id, "image", prompt, "failed", error_message="Request cancelled")
        raise
    except HTTPException as e:
        record_job(job_id, "image", prompt, "failed", error_message=str(e.detail))
        raise
    except Exception:
        log.exception("image generation failed (job %s)", job_id)
        record_job(job_id, "image", prompt, "failed", error_message="Unexpected provider response")
        raise HTTPException(status_code=502, detail="Image generation failed. Check provider settings and server logs.")

@app.post("/api/generate-audio", dependencies=[Depends(limit_generate)])
async def generate_audio(req: AudioRequest):
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Text cannot be empty.")
    if JOB_SEM.locked():
        raise HTTPException(status_code=429, detail="The server is busy generating other requests. Try again shortly.")
    job_id = str(uuid.uuid4())
    record_job(job_id, "audio", text[:1000], "processing")
    payload = {"model": TTS_MODEL, "voice": req.voice, "input": text, "response_format": "mp3"}
    instructions = (req.instructions or "").strip()
    if instructions:
        payload["instructions"] = instructions
    try:
        async with JOB_SEM:
            audio_bytes, _ = await provider_request("/audio/speech", payload, timeout_seconds=180)
        file_name = f"{job_id}.mp3"
        await asyncio.to_thread((DATA_DIR / file_name).write_bytes, audio_bytes)
        record_job(job_id, "audio", text[:1000], "completed", file_name, "audio/mpeg")
        return {"status": "success", "job_id": job_id, "audio_data": base64.b64encode(audio_bytes).decode("utf-8"), "mime_type": "audio/mpeg"}
    except asyncio.CancelledError:
        record_job(job_id, "audio", text[:1000], "failed", error_message="Request cancelled")
        raise
    except HTTPException as e:
        record_job(job_id, "audio", text[:1000], "failed", error_message=str(e.detail))
        raise
    except Exception:
        log.exception("audio generation failed (job %s)", job_id)
        record_job(job_id, "audio", text[:1000], "failed", error_message="Unexpected provider response")
        raise HTTPException(status_code=502, detail="Audio generation failed. Check provider settings and server logs.")

@app.get("/api/history")
def history(limit: int = 20):
    limit = max(1, min(limit, 100))
    with db() as conn:
        rows = conn.execute(
            "SELECT id,kind,prompt,status,created_at,file_name,mime_type,error_message FROM jobs ORDER BY created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
    return {"items": [dict(row) for row in rows]}

@app.get("/api/files/{file_name}")
def get_file(file_name: str):
    # Only permit a flat filename generated by this application.
    if not SAFE_FILE_RE.fullmatch(file_name):
        raise HTTPException(status_code=400, detail="Invalid file name.")
    path = DATA_DIR / file_name
    if not path.is_file():
        raise HTTPException(status_code=404, detail="File not found.")
    media_type = "audio/mpeg" if file_name.endswith(".mp3") else "image/png"
    return FileResponse(path, media_type=media_type, filename=file_name)

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
# Must stay LAST: serves the photo/video/AI editor (index.html and its assets) from "/".
app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="editor")
