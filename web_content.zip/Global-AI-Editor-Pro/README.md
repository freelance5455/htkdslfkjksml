# Global AI Editor Pro — Starter v0.2

A more complete starter project with a FastAPI backend, responsive web UI, English/Persian interface, image generation, text-to-speech, SQLite job history, Docker files, environment configuration, and health/config endpoints.

## Important reality check

This is a **starter implementation**, not a production-ready SaaS. It uses an OpenAI API key stored on the server. You must confirm your account's API access, model availability, pricing, and supported parameters before use. Provider API usage is billed separately from a ChatGPT subscription.

Not included yet: user accounts, password recovery/OTP, subscription checkout, per-user usage quotas, rate limiting, team workspaces, admin panel, object storage, automated backups, monitoring, or a production reverse proxy/TLS setup. Do not expose this service publicly until these are implemented and security-reviewed.

## Run on a computer or server

1. Install Python 3.11+.
2. Copy `.env.example` to `.env`.
3. Put your API key into `OPENAI_API_KEY` in `.env`. Never paste the key into the HTML or share it.
4. Install dependencies and start:
   ```bash
   pip install -r requirements.txt
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```
5. Visit `http://127.0.0.1:8000`. Health check: `http://127.0.0.1:8000/api/health`.

## Docker

```bash
cp .env.example .env
# Edit .env and set OPENAI_API_KEY
docker compose up --build -d
```

## API routes

- `GET /api/health` — server status and whether the key is configured
- `GET /api/config` — public UI configuration (does not expose the key)
- `POST /api/generate-image` — JSON: `{"prompt":"...", "size":"1024x1024"}`
- `POST /api/generate-audio` — JSON: `{"text":"...", "voice":"alloy", "instructions":"..."}`
- `GET /api/history?limit=10` — recent jobs
- `GET /api/files/{file_name}` — retrieve a generated file

## Before public launch (priority order)

1. Add authentication and per-account data isolation.
2. Add per-user quotas, rate limiting, request size limits, and cost monitoring.
3. Add a real subscription/payment provider and server-side entitlement checks.
4. Move generated files to private object storage with expiring download URLs.
5. Add migrations, backup/restore tests, logs/metrics, HTTPS and a reverse proxy.
6. Add tests for provider failures, oversized requests, concurrency, and cross-user access.
7. Verify model availability and API request fields against current provider documentation.
