CONTROLE MOTOBOY - Projeto Android

Pacote mantido para atualização: com.meumotoboy.app
Versão: 3.0 (versionCode 3)
Aplicativo offline: interface HTML incluída em app/src/main/assets/index.html.

Abra este projeto em Android Studio ou use um serviço de conversão de projeto Android para APK que aceite projetos Gradle.
