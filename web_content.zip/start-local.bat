@echo off
title EduMentor AI - Phone & Local Runner
cd /d "%~dp0"
echo ===================================================
echo       Starting EduMentor AI (Phone & Desktop)
echo ===================================================
echo.
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo Please install Node.js from: https://nodejs.org/
    echo.
    pause
    exit /b
)

if not exist "node_modules\" (
    echo [INFO] Installing packages (first run only)...
    call npm install
)

echo.
echo [INFO] Starting EduMentor AI...
echo ---------------------------------------------------
echo To open on your PHONE:
echo   1. Make sure your phone is on the same Wi-Fi.
echo   2. Look at the "Network:" address printed below.
echo   3. Type that address into Safari or Chrome on your phone!
echo ---------------------------------------------------
echo.
call npm run dev
pause
