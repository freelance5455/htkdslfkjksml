# v1.6.5 Build Notes

Local default login accounts are seeded and hashed on first successful local login.

The Android layer supports system file picking (`ACTION_OPEN_DOCUMENT`) and system save-as selection (`ACTION_CREATE_DOCUMENT`). v1.6.5 exposes these through the in-app File & Report Center.

CI builds an installable signed Debug APK plus an unsigned Release APK.

The source package does not contain a Gradle wrapper; CI installs Gradle 9.4.1 and Android API 36.
