PINKVENTORY FIXED

Perbaikan utama:
- Beranda, Inventaris, dan Laporan memakai sumber data lokal yang sama.
- Migrasi storage v3 -> v4 agar data lama yang kosong tidak membuat Beranda kosong.
- Data contoh otomatis tersedia jika storage kosong.
- Tombol Kamera memakai input kamera Android (capture=environment), lebih kompatibel untuk APK/WebView.
- Galeri tetap memakai pemilih foto Android.
- Foto disimpan bersama data barang di localStorage.
- Tambah/edit/hapus/simpan tetap sinkron.

IZIN ANDROID:
Saat menekan Kamera, izinkan akses Kamera jika Android meminta izin.
Jika pernah memilih Tolak, buka Pengaturan > Aplikasi > Pinkventory > Izin > Kamera > Izinkan.

CATATAN:
File ini adalah source HTML yang sudah diperbaiki. Jika APK dibuat dengan WebView, gunakan file index.html ini sebagai asset pengganti.
