package com.genjutsu.app

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val ORIGIN = "https://$HOST"
        private const val START_URL = "$ORIGIN/assets/index.html"
        private const val MIN_SPLASH_MS = 1200L
        private const val MAX_SPLASH_MS = 6000L

        // Lets the page's "export backup" (blob + <a download>) save into Downloads.
        private const val DOWNLOAD_SHIM = """
(function () {
  var blobs = new Map();
  var origCreate = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (o) {
    var u = origCreate(o);
    try { if (o instanceof Blob) blobs.set(u, o); } catch (e) {}
    return u;
  };
  var origClick = HTMLAnchorElement.prototype.click;
  function handle(a) {
    var href = a.href || '';
    if (!a.hasAttribute('download') || href.indexOf('blob:') !== 0) return false;
    var blob = blobs.get(href);
    var p = blob ? Promise.resolve(blob) : fetch(href).then(function (r) { return r.blob(); });
    p.then(function (b) {
      var fr = new FileReader();
      fr.onload = function () {
        var s = String(fr.result);
        var i = s.indexOf(',');
        GenjutsuBridge.postMessage(JSON.stringify({
          name: a.getAttribute('download') || 'download',
          mime: b.type || 'application/octet-stream',
          data: s.substring(i + 1)
        }));
      };
      fr.readAsDataURL(b);
    });
    return true;
  }
  HTMLAnchorElement.prototype.click = function () {
    if (!handle(this)) origClick.call(this);
  };
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (a && handle(a)) e.preventDefault();
  }, true);
})();
"""
    }

    private lateinit var outer: FrameLayout
    private lateinit var holder: FrameLayout
    private var webView: WebView? = null
    private var splash: ImageView? = null
    private var splashHiding = false
    private var pageReady = false
    private var startedAt = 0L
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val handler = Handler(Looper.getMainLooper())

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
            fileCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Native keep-screen-on: automatically released when the app leaves the foreground.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        startedAt = SystemClock.uptimeMillis()

        outer = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0A0A0D")) }
        holder = FrameLayout(this)
        outer.addView(holder, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        // Keep content clear of the notch / navigation bar and move it above the keyboard.
        ViewCompat.setOnApplyWindowInsetsListener(outer) { _, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            holder.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        setContentView(outer)

        setupWebView()
        if (savedInstanceState == null) showSplash() else pageReady = true
        hideStatusBar()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val w = webView
                if (w != null && w.canGoBack()) w.goBack() else confirmExit()
            }
        })
    }

    // ---------- Splash ----------
    private fun showSplash() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.splash_image)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(getColor(R.color.splash_bg))
        }
        splash = iv
        outer.addView(iv, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        // Failsafe so the splash can never get stuck.
        handler.postDelayed({ pageReady = true; hideSplashSoon() }, MAX_SPLASH_MS)
    }

    private fun hideSplashSoon() {
        val s = splash ?: return
        if (!pageReady || splashHiding) return
        splashHiding = true
        val wait = (MIN_SPLASH_MS - (SystemClock.uptimeMillis() - startedAt)).coerceAtLeast(0L)
        handler.postDelayed({
            s.animate().alpha(0f).setDuration(250).withEndAction {
                outer.removeView(s)
                splash = null
            }.start()
        }, wait)
    }

    // ---------- System UI ----------
    private fun hideStatusBar() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.hide(WindowInsetsCompat.Type.statusBars())
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideStatusBar()
    }

    // ---------- WebView ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val w = WebView(this)
        webView = w
        holder.addView(w, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        w.setBackgroundColor(Color.TRANSPARENT)
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            cacheMode = WebSettings.LOAD_DEFAULT
            textZoom = 100
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(
                w, "GenjutsuBridge", setOf(ORIGIN)
            ) { _, message: WebMessageCompat, _, _, _ ->
                message.data?.let { saveDownload(it) }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(w, DOWNLOAD_SHIM, setOf(ORIGIN))
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == HOST) return false
                if (u.scheme == "http" || u.scheme == "https" || u.scheme == "mailto") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, u))
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(this@MainActivity, "Link open nahi ho paya", Toast.LENGTH_SHORT).show()
                    }
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageReady = true
                syncBackground()
                hideSplashSoon()
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                holder.removeView(view)
                view.destroy()
                webView = null
                recreate()
                return true
            }
        }

        w.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView, callback: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    true
                }
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name).setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsPrompt(
                view: WebView, url: String?, message: String?, defaultValue: String?, result: JsPromptResult
            ): Boolean {
                val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.app_name).setMessage(message).setView(input)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        w.loadUrl(START_URL)
    }

    /** Match the strip behind the notch to the page's current theme colour. */
    private fun syncBackground() {
        webView?.evaluateJavascript(
            "(function(){return getComputedStyle(document.body).backgroundColor})()"
        ) { v ->
            val s = v ?: return@evaluateJavascript
            if (s.contains("rgba(0, 0, 0, 0)")) return@evaluateJavascript
            val n = Regex("\\d+").findAll(s).map { it.value.toInt() }.toList()
            if (n.size >= 3) outer.setBackgroundColor(Color.rgb(n[0], n[1], n[2]))
        }
    }

    private fun saveDownload(json: String) {
        try {
            val o = JSONObject(json)
            val name = o.getString("name").replace(Regex("[\\\\/:*?\"<>|]"), "_")
            val mime = o.optString("mime", "application/octet-stream")
            val bytes = Base64.decode(o.getString("data"), Base64.DEFAULT)
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("insert failed")
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            Toast.makeText(this, "Downloads mein save hua: $name", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "File save nahi ho payi", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setTitle(R.string.app_name)
            .setMessage("App band karni hai?")
            .setPositiveButton("Haan") { _, _ -> finish() }
            .setNegativeButton("Nahi", null)
            .show()
    }

    // ---------- Lifecycle ----------
    override fun onResume() {
        super.onResume()
        webView?.onResume()
        syncBackground()
    }

    override fun onPause() {
        webView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        webView?.let {
            holder.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        webView = null
        super.onDestroy()
    }
}
