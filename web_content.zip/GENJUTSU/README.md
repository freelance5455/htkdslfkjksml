# GENJUTSU 🗿 — Android project

CA Foundation Tracker (v28) ko native Android WebView app mein wrap kiya gaya hai.
Package: `com.genjutsu.app` · minSdk 29 (Android 10) · targetSdk 35 · Portrait only.

## Build (Android Studio)
1. Android Studio (Ladybug ya naya) install karo.
2. `File → Open` → is `GENJUTSU` folder ko select karo. Pehli sync mein Gradle 8.9 aur SDK 35 khud download hoga (internet chahiye).
   Agar "gradle-wrapper.jar missing" aaye to Android Studio ke Terminal mein `gradle wrapper --gradle-version 8.9` chalao, ya bas sync hone do.
3. **Debug APK:** `Build → Build Bundle(s) / APK(s) → Build APK(s)`
   Output: `app/build/outputs/apk/debug/app-debug.apk`

## Release APK (signed)
1. Keystore banao (ek baar, safe jagah rakho, kabhi share mat karo):
   ```
   keytool -genkeypair -v -keystore genjutsu-release.jks -alias genjutsu -keyalg RSA -keysize 2048 -validity 10000
   ```
2. `keystore.properties.example` ko `keystore.properties` naam se copy karke apni values bharo (file `.gitignore` mein hai).
3. `Build → Generate Signed App Bundle / APK → APK → release`, ya terminal: `./gradlew assembleRelease`
   Output: `app/build/outputs/apk/release/app-release.apk`
Bina keystore ke release APK unsigned banega aur install nahi hoga.

## Kya-kya hai
- Splash: Android 12+ system splash (same blue background) → turant full-screen splash image, page load hone par fade-out (min ~1.2s).
- Launcher icon: adaptive icon (Spider-Man "keep your dream alive" image).
- Status bar hidden (swipe karne par temporarily aati hai), notch/navigation bar ke peeche content nahi jata, keyboard ke upar layout adjust hota hai.
- Keep Screen On: `FLAG_KEEP_SCREEN_ON` (app band/minimize hote hi apne aap release).
- Back button: pehle WebView history, warna "App band karni hai?" confirm dialog.
- HTML poori tarah app ke andar (`assets/index.html`), offline chalti hai; data `localStorage` mein persist hota hai.
- `confirm()` / `alert()` dialogs (Reset, Import) native dialogs se kaam karte hain.
- Import backup: file picker kaam karta hai. Export backup: `Downloads` folder mein save hota hai (koi storage permission nahi).
- External links (Instagram) browser mein khulte hain.
- Permissions: sirf `INTERNET` (Google Fonts ke liye).
- HTML mein ek hi change: About me mein Instagram text ab `ig.optimus.pz` dikhta hai (link same).

## Zaroori baatein
- **Purana data:** browser mein jo data hai wo app mein automatically nahi aayega (alag storage). Browser version mein *Export*, phir app mein *Import* karo.
- **Fonts:** Inter / JetBrains Mono / Fraunces Google Fonts se aate hain. Pehli baar online khulne par cache ho jaate hain; bilkul pehli baar offline khola to system font dikhega. Fully offline fonts ke liye font files `assets/` mein daal ke `index.html` ka `<link>` badalna hoga.
- App mein data Android backup mein include nahi hai (`allowBackup=false`); isliye time-time par Export lete raho.

## Testing status
Ye project yahan build ya device par run NAHI kiya gaya (is environment mein Android SDK/internet nahi tha). Isliye koi feature "tested" claim nahi hai. Pehle debug APK banake phone par check karo.
