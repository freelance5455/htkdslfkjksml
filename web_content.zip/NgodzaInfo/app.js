/* NgodzaInfo offline vault prototype.
   Records are encrypted with Web Crypto (AES-GCM); the key is derived from a
   user passphrase using PBKDF2. This is not a substitute for Android Keystore
   integration and independent security review. */
const $ = (id) => document.getElementById(id);
const DB_KEY = "ngodzainfo_v1";
const META_KEY = "ngodzainfo_meta_v1";
const encoder = new TextEncoder();
const decoder = new TextDecoder();
let masterKey = null;
let activeKind = "Profile";
let records = [];
let editId = null;

function b64(bytes) {
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary);
}
function unb64(value) {
  const binary = atob(value);
  return Uint8Array.from(binary, c => c.charCodeAt(0));
}
function randomBytes(length) {
  return crypto.getRandomValues(new Uint8Array(length));
}
async function deriveKey(passphrase, salt) {
  const material = await crypto.subtle.importKey("raw", encoder.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    {name:"PBKDF2", salt, iterations:310000, hash:"SHA-256"},
    material, {name:"AES-GCM", length:256}, false, ["encrypt","decrypt"]
  );
}
async function encryptObject(value, key) {
  const iv = randomBytes(12);
  const ciphertext = await crypto.subtle.encrypt({name:"AES-GCM", iv}, key, encoder.encode(JSON.stringify(value)));
  return {iv:b64(iv), data:b64(new Uint8Array(ciphertext))};
}
async function decryptObject(blob, key) {
  const plain = await crypto.subtle.decrypt({name:"AES-GCM", iv:unb64(blob.iv)}, key, unb64(blob.data));
  return JSON.parse(decoder.decode(plain));
}
function saveBlob(blob) {
  // Only ciphertext and crypto parameters are persisted, never record plaintext.
  localStorage.setItem(DB_KEY, JSON.stringify(blob));
}
function showOnly(id) {
  ["setupScreen","unlockScreen","vaultScreen"].forEach(x => $(x).classList.toggle("hidden", x !== id));
}
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.remove("hidden");
  setTimeout(() => $("toast").classList.add("hidden"), 2400);
}
function metadata() {
  try { return JSON.parse(localStorage.getItem(META_KEY) || "null"); } catch { return null; }
}
async function initialize() {
  if (!window.crypto?.subtle || !window.crypto?.getRandomValues) {
    showOnly("setupScreen");
    $("setupScreen").querySelector("h2").textContent = "Secure crypto unavailable";
    $("setupScreen").querySelector(".muted").textContent = "This preview needs a secure Web Crypto context. Do not enter personal information here. Package it in a properly configured Android WebView first.";
    $("setupForm").classList.add("hidden");
    return;
  }
  showOnly(metadata() ? "unlockScreen" : "setupScreen");
}
$("setupForm").addEventListener("submit", async e => {
  e.preventDefault();
  const p = $("newPass").value, c = $("confirmPass").value;
  if (p.length < 12) return toast("Use at least 12 characters.");
  if (p !== c) return toast("Passphrases do not match.");
  try {
    const salt = randomBytes(16);
    masterKey = await deriveKey(p, salt);
    const check = await encryptObject({check:"NgodzaInfo vault verified"}, masterKey);
    localStorage.setItem(META_KEY, JSON.stringify({salt:b64(salt), check}));
    records = [];
    saveBlob(await encryptObject(records, masterKey));
    $("newPass").value = ""; $("confirmPass").value = "";
    showOnly("vaultScreen"); renderRecords(); toast("Encrypted vault created.");
  } catch (err) { toast("Secure storage could not start in this browser."); }
});
$("unlockForm").addEventListener("submit", async e => {
  e.preventDefault();
  const p = $("passphrase").value;
  const meta = metadata();
  if (!meta) return initialize();
  try {
    masterKey = await deriveKey(p, unb64(meta.salt));
    const check = await decryptObject(meta.check, masterKey);
    if (check.check !== "NgodzaInfo vault verified") throw new Error("Bad key");
    const blob = JSON.parse(localStorage.getItem(DB_KEY) || "null");
    records = blob ? await decryptObject(blob, masterKey) : [];
    $("passphrase").value = ""; $("unlockError").classList.add("hidden");
    showOnly("vaultScreen"); renderRecords(); toast("Vault unlocked.");
  } catch {
    masterKey = null;
    $("unlockError").classList.remove("hidden");
  }
});
function switchKind(kind) {
  activeKind = kind;
  document.querySelectorAll(".module").forEach(b => b.classList.toggle("active", b.dataset.kind === kind));
  $("moduleTitle").textContent = kind;
  $("moduleEyebrow").textContent = ({Profile:"PERSONAL RECORDS",Contacts:"PEOPLE & CONTACTS",Documents:"DOCUMENT INDEX",Notes:"PRIVATE NOTES"})[kind];
  renderRecords();
}
document.querySelectorAll(".module").forEach(b => b.addEventListener("click", () => switchKind(b.dataset.kind)));
function renderRecords() {
  const list = $("recordList");
  list.replaceChildren();
  const shown = records.filter(r => r.kind === activeKind);
  $("emptyState").classList.toggle("hidden", shown.length > 0);
  $("recordCount").textContent = `${records.length} record${records.length === 1 ? "" : "s"}`;
  const symbols = {Profile:"◈",Contacts:"⌁",Documents:"▤",Notes:"✎"};
  shown.forEach(record => {
    const item = document.createElement("article"); item.className = "record-item";
    const symbol = document.createElement("div"); symbol.className = "record-symbol"; symbol.textContent = symbols[record.kind] || "•";
    const copy = document.createElement("div"); copy.className = "record-copy";
    const title = document.createElement("strong"); title.textContent = record.title;
    const body = document.createElement("p"); body.textContent = record.details;
    copy.append(title, body);
    const del = document.createElement("button"); del.className = "delete-record"; del.type = "button"; del.textContent = "×"; del.setAttribute("aria-label","Delete record");
    del.addEventListener("click", async () => {
      if (!confirm("Delete this record permanently?")) return;
      records = records.filter(r => r.id !== record.id);
      await persistRecords(); renderRecords(); toast("Record deleted.");
    });
    item.append(symbol, copy, del); list.append(item);
  });
}
$("addButton").addEventListener("click", () => {
  editId = null; $("recordForm").reset(); $("formTitle").textContent = `New ${activeKind.toLowerCase()} record`;
  $("recordDialog").showModal();
});
$("closeDialog").addEventListener("click", () => $("recordDialog").close());
$("recordForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!masterKey) return toast("Unlock the vault first.");
  const title = $("recordName").value.trim(), details = $("recordDetails").value.trim();
  if (!title || !details) return;
  records.push({id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+Math.random(),kind:activeKind,title,details,createdAt:new Date().toISOString()});
  try {
    await persistRecords(); $("recordDialog").close(); renderRecords(); toast("Record encrypted and saved.");
  } catch { toast("Could not save encrypted record."); }
});
async function persistRecords() {
  const blob = await encryptObject(records, masterKey);
  saveBlob(blob);
}
$("lockButton").addEventListener("click", () => {
  masterKey = null; records = [];
  $("recordList").replaceChildren();
  showOnly("unlockScreen");
  toast("Vault locked.");
});
document.addEventListener("visibilitychange", () => {
  // A real native app should lock on background and use Android lifecycle hooks.
  if (document.hidden && masterKey) {
    masterKey = null; records = [];
    $("recordList").replaceChildren();
    showOnly("unlockScreen");
  }
});
initialize();
