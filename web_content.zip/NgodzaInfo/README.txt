# NgodzaInfo starter project

A mobile-first, offline-oriented HTML/CSS/JavaScript prototype for a personal information vault.

## Files
- `index.html` — app structure
- `style.css` — futuristic dark/cyan interface
- `app.js` — encrypted-record prototype using Web Crypto AES-GCM and PBKDF2

## Important security notes
- This is a starter prototype, not a security-audited password manager.
- Do not enter real sensitive information until it has been packaged, tested, and reviewed.
- It stores encrypted records in browser localStorage. The passphrase-derived key is held in memory while unlocked.
- It does NOT integrate Android Keystore, biometric authentication, native encrypted file storage, or a hardened WebView yet.
- Some WebView/file origins may not expose `crypto.subtle`. If the app reports that secure crypto is unavailable, stop and do not enter personal data.
- Losing the master passphrase means losing access to the encrypted records.
- The CSS currently imports Google Fonts, so the visual font may fall back offline. For a fully offline build, remove the `@import` line in `style.css` or bundle font files locally.
- No cloud or network calls are made by the JavaScript app logic.

## Preview
Open `index.html` in a browser that supports Web Crypto in a secure context. If crypto is unavailable, the app intentionally disables vault setup.

## Next production steps
1. Package the files in an Android WebView with local assets only.
2. Disable cleartext traffic and unnecessary WebView capabilities.
3. Use a native Android Keystore-backed encryption key and secure storage, or a well-reviewed native vault architecture.
4. Test app-background locking, backups, reinstall behavior, and device compatibility.
5. Conduct a security review before using real records.
