# Process AI Mastery — mobile study companion

## Included
- `index.html`: mobile-first interactive app with all 95 lessons and YouTube search links
- searchable lesson library and completed/not-completed filters
- progress bar and local checklist saved in browser storage
- eight roadmap phases, core resource links, five portfolio projects, skill matrix, first-week plan
- `manifest.json` and `sw.js` for installable PWA hosting

## Important APK note
This package is a lightweight web app/PWA project, **not a compiled Android APK**. A real APK requires Android build tooling and signing. This environment does not have the Android SDK/Gradle toolchain available, so I am not pretending this ZIP is an APK.

## Easiest way to use on Android
1. Extract this ZIP.
2. Open `index.html` in Chrome or another modern browser. The lesson links work online; progress is stored by that browser.
3. For the full installable-app experience, host these files over HTTPS (for example, with GitHub Pages), open the hosted URL in Chrome on Android, then use the browser menu → **Add to Home screen** or **Install app**.
4. For a real APK, use Android Studio to create a small WebView wrapper around the hosted app or package the web app with a PWA-to-APK tool. Review permissions and sign the APK before installing.

## Notes
- Video URLs are targeted YouTube search links, so available results may change.
- Do not use experimental AI models directly on live plant control. Test offline and in simulation, and obtain qualified engineering review.
