# EDLASER 報價管理 Android 專案（單機版）

這是將 EDLASER 單機報價管理網頁包進 Android WebView 的 Android Studio 專案。報價資料存於 App 內 WebView 的本機儲存空間，不含登入、Firebase 或雲端同步。

## 已納入功能
- 新增、編輯、搜尋、複製、刪除報價
- 品項、數量、單價、折扣、營業稅及總額計算
- PDF 匯出：產生 PDF 後呼叫 Android 系統「建立檔案」選擇器，可選擇儲存位置
- JPG 匯出：產生 JPG 後呼叫 Android 系統「建立檔案」選擇器，可選擇儲存位置
- 公司資訊列印於報價單：Email、電話、地址、統編
- 公司印章上傳：支援 JPG／PNG／WEBP，壓縮後儲存在本機並顯示於報價單；JSON 備份亦包含印章
- JSON 備份另存到手機、從手機選檔匯入
- JPG 匯出（使用 html2canvas CDN，因此需要網路）
- 本機修改紀錄

## 目前狀態
這份是可建置的 Android Studio 專案原始碼，並非已編譯的 APK。產生 APK 需要 Android SDK／Gradle 建置環境；目前提供的執行環境沒有這些工具，故無法在此直接編譯並實機驗證安裝檔。

## 用 Android Studio 建置
1. 在電腦安裝 Android Studio（含 Android SDK 35、JDK 17）。
2. 解壓縮專案 ZIP，Android Studio 選 **Open**，開啟 `edlaser-android-apk` 資料夾。
3. 等待 Gradle Sync 完成。
4. 選單 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
5. Debug APK 預期輸出位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 不想在電腦安裝 Android Studio
專案含 `.github/workflows/build-apk.yml`。把整個專案上傳到自己的 GitHub repository，進入 **Actions → Build EDLASER APK → Run workflow**；工作完成後下載名為 `EDLASER-Quotation-debug-apk` 的 Artifact，裡面會有 `app-debug.apk`。

## 安裝到 Android 手機
將 `app-debug.apk` 傳到手機並開啟，依 Android 提示允許安裝此來源的應用程式。這是測試用 Debug APK；正式對外發佈前應建立自己的簽署金鑰並產生 Release APK。

## 資料安全提醒
- 報價資料只存在這台手機的 App 資料中，不會自動同步其他裝置。
- 移除 App 或清除 App 儲存資料可能造成資料遺失，請定期匯出 JSON 備份。
- PDF／JPG 轉檔元件需網路載入；匯出時 Android App 會開啟系統檔案儲存選擇器。公司印章與報價資料仍只存於本機。


## 本次匯出修正（v1.2.0 source patch）
- Android APK 內的 PDF/JPG 匯出改為原生 WebView 本機渲染，不依賴 html2pdf.js/html2canvas CDN。
- 產生檔案後使用 Android 系統「建立文件」儲存視窗，使用者可選擇 Downloads 或其他可用位置。
- PDF 使用 Android PdfDocument 產生；JPG 以 WebView 畫面轉成 JPEG。
- 請重新建置並安裝新版 APK 才會套用修正；既有已安裝 APK 不會自動更新。
- 目前提供的是原始碼專案，尚未在此環境編譯或實機驗證。
