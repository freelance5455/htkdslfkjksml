package com.edlaser.quotation;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import android.view.View;
import android.graphics.Color;
import java.io.ByteArrayOutputStream;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.os.ParcelFileDescriptor;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.content.ContentResolver;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int SAVE_FILE_REQUEST = 1002;
    private String pendingContent = "";
    private String pendingMime = "application/json";
    private String pendingFilename = "EDLASER_backup.json";
    private boolean pendingBinary = false;
    private byte[] pendingBytes = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        webView.addJavascriptInterface(new AppBridge(), "AndroidApp");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { filePathCallback = null; Toast.makeText(MainActivity.this, "無法開啟檔案選擇器", Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface public void saveTextFile(String filename, String content, String mime) {
            runOnUiThread(() -> {
                pendingFilename = filename == null ? "EDLASER_backup.json" : filename;
                pendingContent = content == null ? "" : content;
                pendingMime = mime == null ? "application/json" : mime.split(";")[0];
                pendingBinary = false;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                startActivityForResult(intent, SAVE_FILE_REQUEST);
            });
        }
        @JavascriptInterface public void saveDataUrl(String filename, String dataUrl) {
            runOnUiThread(() -> {
                try {
                    int comma = dataUrl.indexOf(',');
                    String header = comma > 0 ? dataUrl.substring(0, comma) : "data:application/octet-stream;base64";
                    String base64 = comma > 0 ? dataUrl.substring(comma + 1) : dataUrl;
                    String mime = "application/octet-stream";
                    java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("data:([^;]+)").matcher(header);
                    if (matcher.find()) mime = matcher.group(1);
                    pendingFilename = filename == null ? "EDLASER_export" : filename;
                    pendingContent = base64;
                    pendingMime = mime;
                    pendingBinary = true;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingMime);
                    intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                    startActivityForResult(intent, SAVE_FILE_REQUEST);
                } catch (Exception e) { Toast.makeText(MainActivity.this, "匯出檔案失敗：" + e.getMessage(), Toast.LENGTH_SHORT).show(); }
            });
        }
        @JavascriptInterface public void saveHtmlAsPdf(String filename, String html) {
            runOnUiThread(() -> renderHtmlToFile(filename, html, "application/pdf"));
        }
        @JavascriptInterface public void saveHtmlAsJpg(String filename, String html) {
            runOnUiThread(() -> renderHtmlToFile(filename, html, "image/jpeg"));
        }
        @JavascriptInterface public void printHtml(String title, String html) {
            runOnUiThread(() -> {
                WebView printView = new WebView(MainActivity.this);
                printView.getSettings().setJavaScriptEnabled(false);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        String jobName = (title == null || title.isEmpty()) ? "EDLASER 報價單" : title;
                        pm.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
                    }
                });
                String doc = "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font-family:sans-serif;padding:16px;color:#111}table{border-collapse:collapse;width:100%;margin-top:16px}th,td{border:1px solid #bbb;padding:7px;font-size:12px}th{background:#eee}.note{padding:10px;background:#f5f5f5}@page{size:A4;margin:12mm}</style></head><body>" + html + "</body></html>";
                printView.loadDataWithBaseURL("file:///android_asset/", doc, "text/html", "UTF-8", null);
            });
        }
    }

    private void renderHtmlToFile(String filename, String html, String mime) {
        WebView renderView = new WebView(this);
        renderView.getSettings().setJavaScriptEnabled(false);
        renderView.setBackgroundColor(Color.WHITE);
        renderView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.post(() -> {
                    try {
                        float density = view.getResources().getDisplayMetrics().density;
                        int cssWidth = mime.equals("image/jpeg") ? 1000 : 794;
                        int width = Math.max(1, Math.round(cssWidth * density));
                        int contentHeight = Math.max(view.getContentHeight(), 900);
                        int measuredHeight = Math.max((int)(contentHeight * density), view.getMeasuredHeight());
                        view.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                        measuredHeight = Math.max(measuredHeight, view.getMeasuredHeight());
                        view.layout(0, 0, width, measuredHeight);
                        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                        if (mime.equals("application/pdf")) {
                            android.graphics.pdf.PdfDocument pdf = new android.graphics.pdf.PdfDocument();
                            int pageWidth = 595, pageHeight = 842;
                            float scale = pageWidth / (float) width;
                            int pageContentHeight = Math.max(1, (int)(pageHeight / scale));
                            int pages = Math.max(1, (int)Math.ceil(measuredHeight / (double)pageContentHeight));
                            for (int i = 0; i < pages; i++) {
                                android.graphics.pdf.PdfDocument.PageInfo info = new android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, i + 1).create();
                                android.graphics.pdf.PdfDocument.Page page = pdf.startPage(info);
                                android.graphics.Canvas canvas = page.getCanvas();
                                canvas.drawColor(Color.WHITE);
                                canvas.save(); canvas.clipRect(0, 0, pageWidth, pageHeight);
                                canvas.scale(scale, scale); canvas.translate(0, -i * pageContentHeight);
                                view.draw(canvas); canvas.restore(); pdf.finishPage(page);
                            }
                            pdf.writeTo(bytes); pdf.close();
                        } else {
                            int outputWidth = 1200;
                            int outputHeight = Math.max(1, Math.min(12000, Math.round(measuredHeight * (outputWidth / (float) width))));
                            Bitmap bitmap = Bitmap.createBitmap(outputWidth, outputHeight, Bitmap.Config.ARGB_8888);
                            android.graphics.Canvas canvas = new android.graphics.Canvas(bitmap); canvas.drawColor(Color.WHITE);
                            float imageScale = outputWidth / (float) width; canvas.scale(imageScale, imageScale); view.draw(canvas);
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 94, bytes); bitmap.recycle();
                        }
                        pendingFilename = (filename == null || filename.isEmpty()) ? (mime.equals("application/pdf") ? "EDLASER_報價單.pdf" : "EDLASER_報價單.jpg") : filename;
                        pendingMime = mime; pendingBytes = bytes.toByteArray(); pendingBinary = false; pendingContent = "";
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType(mime); intent.putExtra(Intent.EXTRA_TITLE, pendingFilename);
                        startActivityForResult(intent, SAVE_FILE_REQUEST);
                    } catch (Exception e) { Toast.makeText(MainActivity.this, "產生檔案失敗：" + e.getMessage(), Toast.LENGTH_LONG).show(); }
                    finally { view.destroy(); }
                });
            }
        });
        String style = "<meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><style>html,body{margin:0;padding:0;background:#fff;color:#111;font-family:sans-serif}body{padding:24px;box-sizing:border-box}table{border-collapse:collapse;width:100%;margin-top:16px}th,td{border:1px solid #bbb;padding:7px;font-size:12px;vertical-align:top}th{background:#eee}.note{padding:10px;background:#f5f5f5}.money{text-align:right}@page{size:A4;margin:12mm}</style>";
        String doc = "<!doctype html><html><head>" + style + "</head><body>" + (html == null ? "" : html) + "</body></html>";
        renderView.loadDataWithBaseURL("file:///android_asset/", doc, "text/html", "UTF-8", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
                filePathCallback.onReceiveValue(results); filePathCallback = null;
            }
        } else if (requestCode == SAVE_FILE_REQUEST && resultCode == RESULT_CANCELED) {
            pendingBytes = null; pendingContent = "";
            Toast.makeText(this, "已取消儲存", Toast.LENGTH_SHORT).show();
        } else if (requestCode == SAVE_FILE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                if (out != null) {
                    if (pendingBytes != null) { out.write(pendingBytes); pendingBytes = null; }
                    else if (pendingBinary) out.write(android.util.Base64.decode(pendingContent, android.util.Base64.DEFAULT));
                    else out.write(pendingContent.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    out.flush(); Toast.makeText(this, "檔案已儲存到你選擇的位置", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) { Toast.makeText(this, "儲存失敗：" + e.getMessage(), Toast.LENGTH_LONG).show(); }
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setMessage("確定要離開 EDLASER 報價管理？").setNegativeButton("取消", (d,w)->{}).setPositiveButton("離開", (d,w)->finish()).show();
    }
}
