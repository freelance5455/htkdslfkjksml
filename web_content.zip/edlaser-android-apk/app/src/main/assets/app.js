/* EDLASER local-only quotation app. Data is stored in this browser/device; no cloud sync. */
'use strict';
const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat('zh-TW',{style:'currency',currency:'TWD',maximumFractionDigits:0}).format(Number(n)||0);
const QUOTES_KEY='edlaser_local_quotes_v1', AUDIT_KEY='edlaser_local_audit_v1', SEAL_KEY='edlaser_company_seal_v1';
const COMPANY={name:'EDLASER',email:'edlaser20220315@gmail.com',phone:'0911562871',address:'台南市仁德區太子路266號',taxId:'85079983'};
let companySeal=localStorage.getItem(SEAL_KEY)||'';
let quotes=read(QUOTES_KEY,[]), audit=read(AUDIT_KEY,[]), editingId=null, baseVersion=0, items=[];
function read(k,fallback){try{const v=JSON.parse(localStorage.getItem(k));return Array.isArray(v)?v:fallback}catch{return fallback}}
function writeAll(){localStorage.setItem(QUOTES_KEY,JSON.stringify(quotes));localStorage.setItem(AUDIT_KEY,JSON.stringify(audit));$('storageStatus').textContent='本機儲存完成 · '+new Date().toLocaleString('zh-TW')}
function log(action,q){audit.unshift({action,quoteId:q?.id||'',customer:q?.customer||'',at:Date.now()});audit=audit.slice(0,200);writeAll();renderAudit()}
function show(id,on=true){$(id).classList.toggle('hidden',!on)}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function dateNow(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function newQuote(){
  editingId=null;baseVersion=0;items=[{name:'',spec:'',qty:1,unit:'式',price:0}];
  fill({id:'Q'+dateNow().replaceAll('-','')+'-'+Math.random().toString(36).slice(2,5).toUpperCase(),date:dateNow(),expiry:'',customer:'',contact:'',phone:'',customerEmail:'',payment:'',leadtime:'',notes:'',discount:0,taxMode:'5'});
  $('editorTitle').textContent='新增報價單';$('versionPill').textContent='新文件';renderItems();show('editor');show('previewSection',false);window.scrollTo({top:0,behavior:'smooth'});
}
function fill(q){$('qid').value=q.id||'';$('qdate').value=q.date||'';$('qexpiry').value=q.expiry||'';$('customer').value=q.customer||'';$('contact').value=q.contact||'';$('phone').value=q.phone||'';$('customerEmail').value=q.customerEmail||'';$('payment').value=q.payment||'';$('leadtime').value=q.leadtime||'';$('notes').value=q.notes||'';$('discount').value=q.discount||0;$('taxMode').value=q.taxMode??'5'}
function renderItems(){
  $('items').innerHTML='';
  items.forEach((it,i)=>{
    const d=document.createElement('div');d.className='item';
    d.innerHTML=`<div class="row"><div><label>品名</label><input data-i="${i}" data-k="name" placeholder="產品／服務名稱" value="${esc(it.name)}"></div><div><label>規格／說明</label><input data-i="${i}" data-k="spec" placeholder="規格" value="${esc(it.spec)}"></div></div><div class="row"><div><label>數量</label><input data-i="${i}" data-k="qty" type="number" min="0" step="any" value="${Number(it.qty)||0}"></div><div><label>單位</label><input data-i="${i}" data-k="unit" value="${esc(it.unit||'式')}"></div><div><label>單價（元）</label><input data-i="${i}" data-k="price" type="number" min="0" value="${Number(it.price)||0}"></div></div><div class="topline"><span class="small">小計：${money((Number(it.qty)||0)*(Number(it.price)||0))}</span><button class="danger" data-remove="${i}">刪除</button></div>`;
    $('items').appendChild(d);
  });
  $('items').querySelectorAll('input').forEach(el=>el.oninput=()=>{items[+el.dataset.i][el.dataset.k]=['qty','price'].includes(el.dataset.k)?Number(el.value):el.value;calc()});
  $('items').querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{items.splice(+b.dataset.remove,1);renderItems()});
  calc();
}
function calc(){
  const subtotal=items.reduce((s,i)=>s+(Number(i.qty)||0)*(Number(i.price)||0),0),discount=Math.min(subtotal,Number($('discount').value)||0),base=subtotal-discount;
  let tax=0,total=base;if($('taxMode').value==='5'){tax=Math.round(base*.05);total=base+tax}else if($('taxMode').value==='included'){tax=Math.round(base*5/105)}
  $('totals').textContent=`未稅小計 ${money(base)}　稅額 ${money(tax)}　總計 ${money(total)}`;
  return {subtotal,discount,base,tax,total};
}
function payload(){return {id:$('qid').value.trim(),date:$('qdate').value,expiry:$('qexpiry').value,customer:$('customer').value.trim(),contact:$('contact').value.trim(),phone:$('phone').value.trim(),customerEmail:$('customerEmail').value.trim(),items:items.map(i=>({...i,qty:Number(i.qty)||0,price:Number(i.price)||0})),discount:Number($('discount').value)||0,taxMode:$('taxMode').value,payment:$('payment').value,leadtime:$('leadtime').value,notes:$('notes').value,...calc(),updatedAt:Date.now(),version:baseVersion+1}}
function save(){
  const q=payload();if(!q.customer)return alert('請填寫客戶／公司名稱。');if(!q.items.length)return alert('請至少新增一個報價項目。');
  if(!q.id)return alert('請填寫報價單號。');
  const duplicate=quotes.find(x=>x.id===q.id&&x.id!==editingId);if(duplicate)return alert('報價單號已存在，請更換報價單號。');
  const old=quotes.find(x=>x.id===editingId);q.createdAt=old?.createdAt||Date.now();q.updatedAt=Date.now();q.version=old?(old.version||1)+1:1;
  if(old){const idx=quotes.findIndex(x=>x.id===editingId);quotes[idx]=q}else quotes.unshift(q);
  writeAll();log(old?'修改報價':'建立報價',q);editingId=q.id;baseVersion=q.version;$('versionPill').textContent='版本 '+baseVersion;renderQuotes();alert('報價單已儲存在這台裝置。');
}
function renderQuotes(){
  const term=($('search').value||'').toLowerCase();const list=quotes.filter(q=>(q.id+' '+q.customer+' '+q.contact).toLowerCase().includes(term));
  $('count').textContent=list.length+' 份';
  $('quoteList').innerHTML=list.map(q=>`<div class="quote"><div class="topline"><h3>${esc(q.customer||'未命名客戶')}</h3><span class="pill">v${q.version||1}</span></div><p>${esc(q.id)} · ${esc(q.date||'')}</p><div class="topline"><strong>${money(q.total)}</strong><div class="toolbar"><button data-open="${esc(q.id)}">編輯</button><button class="secondary" data-copy="${esc(q.id)}">複製</button><button class="danger" data-delete="${esc(q.id)}">刪除</button></div></div><p>最後修改：${new Date(q.updatedAt||q.createdAt||Date.now()).toLocaleString('zh-TW')}</p></div>`).join('')||'<p class="status">目前沒有報價單，請按「新增報價」。</p>';
  $('quoteList').querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>openQuote(b.dataset.open));
  $('quoteList').querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copyQuote(b.dataset.copy));
  $('quoteList').querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteQuote(b.dataset.delete));
}
function openQuote(id){
  const q=quotes.find(x=>x.id===id);if(!q)return alert('找不到報價單');
  editingId=id;baseVersion=q.version||1;items=(q.items||[]).map(i=>({...i}));fill(q);$('editorTitle').textContent='編輯報價單';$('versionPill').textContent='版本 '+baseVersion;renderItems();show('editor');show('previewSection',false);window.scrollTo({top:0,behavior:'smooth'});
}
function copyQuote(id){
  const q=quotes.find(x=>x.id===id);if(!q)return;
  editingId=null;baseVersion=0;items=(q.items||[]).map(i=>({...i}));
  fill({...q,id:'Q'+dateNow().replaceAll('-','')+'-'+Math.random().toString(36).slice(2,5).toUpperCase(),date:dateNow()});
  $('editorTitle').textContent='複製報價單';$('versionPill').textContent='新文件';renderItems();show('editor');window.scrollTo({top:0,behavior:'smooth'});
}
function deleteQuote(id){const q=quotes.find(x=>x.id===id);if(!q)return;if(!confirm(`確定刪除「${q.customer}」的報價單 ${q.id}？此操作無法復原，建議先匯出備份。`))return;quotes=quotes.filter(x=>x.id!==id);writeAll();log('刪除報價',q);renderQuotes();if(editingId===id)show('editor',false)}
function renderAudit(){
  $('auditList').innerHTML=audit.slice(0,40).map(x=>`<div class="audit"><b>${esc(x.action)}</b><br>${esc(x.quoteId)} ${esc(x.customer)}<br><span class="small">${new Date(x.at).toLocaleString('zh-TW')}</span></div>`).join('')||'尚無紀錄';
}
function renderPaper(){
  const q=payload();
  const sealHtml=companySeal?`<div style="text-align:right;margin-top:8px"><div style="font-size:11px;color:#555;margin-bottom:4px">公司簽章</div><img src="${companySeal}" alt="公司印章" style="max-width:130px;max-height:90px;object-fit:contain"></div>`:`<div style="text-align:right;margin-top:12px"><b>公司簽章：</b>________________</div>`;
  $('paper').innerHTML=`<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:18px;border-bottom:2px solid #174b3b;padding-bottom:12px;margin-bottom:14px"><div><h2 style="margin:0 0 6px">${COMPANY.name}｜報價單</h2><div style="font-size:11px;line-height:1.8;color:#333">Email：${COMPANY.email}<br>電話：${COMPANY.phone}<br>地址：${COMPANY.address}<br>統一編號：${COMPANY.taxId}</div></div><div style="text-align:right;min-width:150px"><b>報價單號：</b>${esc(q.id)}<br><b>報價日期：</b>${esc(q.date)}<br><b>有效期限：</b>${esc(q.expiry||'未指定')}</div></div><div style="display:flex;justify-content:space-between;gap:20px"><div><b>客戶：</b>${esc(q.customer)}<br><b>聯絡人：</b>${esc(q.contact)}<br><b>電話：</b>${esc(q.phone)}<br><b>Email：</b>${esc(q.customerEmail)}</div></div><table><thead><tr><th>品名</th><th>規格／說明</th><th>數量</th><th>單位</th><th class="money">單價</th><th class="money">小計</th></tr></thead><tbody>${q.items.map(i=>`<tr><td>${esc(i.name)}</td><td>${esc(i.spec)}</td><td>${i.qty}</td><td>${esc(i.unit)}</td><td class="money">${money(i.price)}</td><td class="money">${money(i.qty*i.price)}</td></tr>`).join('')}</tbody></table><div style="text-align:right;line-height:1.9;margin-top:12px">小計：${money(q.subtotal)}<br>折扣：-${money(q.discount)}<br>稅額：${money(q.tax)}<h2>總計：${money(q.total)}</h2></div><hr><p><b>付款條件：</b>${esc(q.payment||'未指定')}</p><p><b>預計工期：</b>${esc(q.leadtime||'未指定')}</p><div class="note"><b>備註與條款</b><br>${esc(q.notes).replaceAll('\n','<br>')}</div><div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-top:26px"><div style="font-size:12px">客戶簽章：____________________<br><br>日期：________________</div><div>${sealHtml}</div></div><p style="font-size:10px;color:#66756c;margin-top:18px">本報價單由 EDLASER 報價管理系統產生。</p>`;
  show('previewSection');$('previewSection').scrollIntoView({behavior:'smooth'});
}
function safeFilename(s){return String(s||'EDLASER_報價單').replace(/[\\/:*?"<>|]/g,'_')}
function saveDataUrl(filename,dataUrl,mime){
  if(window.AndroidApp&&typeof window.AndroidApp.saveDataUrl==='function'){window.AndroidApp.saveDataUrl(filename,dataUrl);return true;}
  try{const parts=dataUrl.split(',');const binary=atob(parts[1]);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);const blob=new Blob([bytes],{type:mime||parts[0].match(/data:([^;]+)/)?.[1]||'application/octet-stream'});downloadBlob(filename,blob);return true}catch(e){console.error(e);return false}
}
function loadScript(src){return new Promise((resolve,reject)=>{const existing=[...document.scripts].find(x=>x.src===src);if(existing){if(existing.dataset.loaded==='1')return resolve();existing.addEventListener('load',resolve,{once:true});existing.addEventListener('error',reject,{once:true});return}const script=document.createElement('script');script.src=src;script.onload=()=>{script.dataset.loaded='1';resolve()};script.onerror=reject;document.head.appendChild(script)})}
async function exportPdf(){
  renderPaper();
  const name=safeFilename(($('qid').value||'EDLASER_報價單')+'_報價單.pdf');
  try{
    await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js');
    const dataUrl=await window.html2pdf().set({margin:[10,10,12,10],filename:name,image:{type:'jpeg',quality:0.98},html2canvas:{scale:2,useCORS:true,backgroundColor:'#ffffff',logging:false},jsPDF:{unit:'mm',format:'a4',orientation:'portrait'}}).from($('paper')).outputPdf('datauristring');
    if(!saveDataUrl(name,dataUrl,'application/pdf'))throw new Error('無法建立 PDF 檔');
    if(!window.AndroidApp)alert('PDF 已開始下載，請到手機「下載」資料夾查看。');
  }catch(e){console.error(e);if(window.AndroidApp&&typeof window.AndroidApp.printHtml==='function'){window.AndroidApp.printHtml(name,$('paper').innerHTML);alert('目前無法直接產生 PDF 檔，已開啟 Android 列印介面；請選擇「另存為 PDF」。')}else alert('PDF 匯出失敗。請確認網路連線後再試；若是在瀏覽器中，請允許下載檔案。')}
}
async function exportJpg(){
  renderPaper();
  try{
    await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
    const canvas=await window.html2canvas($('paper'),{scale:2,backgroundColor:'#ffffff',useCORS:true,logging:false});
    const dataUrl=canvas.toDataURL('image/jpeg',.96);const name=safeFilename(($('qid').value||'EDLASER_報價單')+'_報價單.jpg');
    if(!saveDataUrl(name,dataUrl,'image/jpeg'))throw new Error('無法建立 JPG 檔');
    if(!window.AndroidApp)alert('JPG 已開始下載，請到手機「下載」資料夾查看。');
  }catch(e){console.error(e);alert('JPG 匯出失敗。請確認網路連線，並確認印章圖片格式正確後再試。')}
}
function downloadBlob(name,blob){
  if(window.AndroidApp&&typeof window.AndroidApp.saveTextFile==='function'&&blob.type!=='image/jpeg'&&blob.type!=='application/pdf'){
    blob.text().then(text=>window.AndroidApp.saveTextFile(name,text,blob.type||'application/json'));return;
  }
  const a=document.createElement('a');const url=URL.createObjectURL(blob);a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000)
}
function backup(){const data={format:'EDLASER_LOCAL_QUOTATION_BACKUP',version:1,exportedAt:new Date().toISOString(),quotes,audit,companySeal};downloadBlob('EDLASER_報價備份_'+dateNow()+'.json',new Blob([JSON.stringify(data,null,2)],{type:'application/json;charset=utf-8'}))}
function handleSealFile(file){
  if(!file)return;if(!/^image\/(jpeg|png|webp)$/.test(file.type)){alert('請上傳 JPG、PNG 或 WEBP 圖片。');return;}
  const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{const max=700,scale=Math.min(1,max/Math.max(img.width,img.height)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0,canvas.width,canvas.height);companySeal=canvas.toDataURL('image/png');try{localStorage.setItem(SEAL_KEY,companySeal);updateSealPreview();alert('公司印章已儲存在本機，匯出報價單時會一併顯示。')}catch(e){alert('印章圖片太大，無法儲存。請改用較小的圖片。')}};img.onerror=()=>alert('無法讀取這張圖片。');img.src=reader.result};reader.readAsDataURL(file)
}
function updateSealPreview(){if(companySeal){$('sealPreview').src=companySeal;show('sealPreviewWrap',true)}else{ $('sealPreview').removeAttribute('src');show('sealPreviewWrap',false)}}
function importBackup(file){
  const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(reader.result);if(data.format!=='EDLASER_LOCAL_QUOTATION_BACKUP'||!Array.isArray(data.quotes))throw new Error('備份格式不正確');if(!confirm(`將匯入 ${data.quotes.length} 份報價。相同報價單號將以備份內容取代，是否繼續？`))return;
    const map=new Map(quotes.map(q=>[q.id,q]));data.quotes.forEach(q=>map.set(q.id,q));quotes=Array.from(map.values());if(typeof data.companySeal==='string'&&data.companySeal.startsWith('data:image/')){companySeal=data.companySeal;localStorage.setItem(SEAL_KEY,companySeal);updateSealPreview()}audit=[...(Array.isArray(data.audit)?data.audit:[]),{action:'匯入備份',quoteId:'',customer:'',at:Date.now()},...audit].slice(0,200);writeAll();renderQuotes();renderAudit();alert('備份匯入完成。');
  }catch(e){alert('匯入失敗：'+e.message)}};reader.readAsText(file)
}
$('newBtn').onclick=newQuote;$('addItemBtn').onclick=()=>{items.push({name:'',spec:'',qty:1,unit:'式',price:0});renderItems()};
$('cancelBtn').onclick=()=>show('editor',false);$('closePreview').onclick=()=>{show('previewSection',false);show('editor',true)};
$('discount').oninput=calc;$('taxMode').onchange=calc;$('search').oninput=renderQuotes;$('saveBtn').onclick=save;$('pdfBtn').onclick=exportPdf;$('jpgBtn').onclick=exportJpg;
$('backupBtn').onclick=backup;$('importBtn').onclick=()=>$('importFile').click();$('importFile').onchange=e=>{const f=e.target.files?.[0];if(f)importBackup(f);e.target.value=''};$('sealFile').onchange=e=>{handleSealFile(e.target.files?.[0]);e.target.value=''};$('removeSealBtn').onclick=()=>{if(!companySeal)return;if(confirm('確定移除已儲存的公司印章？')){companySeal='';localStorage.removeItem(SEAL_KEY);updateSealPreview()}};updateSealPreview();
window.addEventListener('storage',e=>{if(e.key===QUOTES_KEY){quotes=read(QUOTES_KEY,[]);renderQuotes()}if(e.key===AUDIT_KEY){audit=read(AUDIT_KEY,[]);renderAudit()}});
renderQuotes();renderAudit();$('storageStatus').textContent=`本機儲存 · 已有 ${quotes.length} 份報價 · ${new Date().toLocaleString('zh-TW')}`;
