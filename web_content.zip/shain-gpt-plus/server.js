import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, 'public');

// Tiny .env loader to keep this starter dependency-free.
try {
  const envText = await readFile(path.join(__dirname, '.env'), 'utf8');
  for (const line of envText.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (match && !(match[1] in process.env)) {
      let value = match[2];
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
      process.env[match[1]] = value;
    }
  }
} catch { /* .env is optional; hosting environment variables are also supported. */ }

const PORT = Number(process.env.PORT || 3000);
const AI_API_KEY = process.env.AI_API_KEY || '';
const AI_MODEL = process.env.AI_MODEL || 'gpt-4o-mini';
const AI_BASE_URL = (process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon'
};
const rateBuckets = new Map();

function send(res, status, data, extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    ...extraHeaders
  });
  res.end(JSON.stringify(data));
}

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'microphone=(self), camera=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
}

function allowRequest(ip) {
  const now = Date.now();
  const windowMs = 60_000;
  const maxRequests = 12;
  let entry = rateBuckets.get(ip);
  if (!entry || now - entry.start > windowMs) {
    entry = { start: now, count: 0 };
    rateBuckets.set(ip, entry);
  }
  entry.count += 1;
  // Bound memory use in this small starter server.
  if (rateBuckets.size > 2_000) {
    for (const [key, value] of rateBuckets) if (now - value.start > windowMs) rateBuckets.delete(key);
  }
  return entry.count <= maxRequests;
}

async function readJson(req, maxBytes = 100_000) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (Buffer.byteLength(body) > maxBytes) throw Object.assign(new Error('Request too large.'), { statusCode: 413 });
  }
  try { return JSON.parse(body || '{}'); }
  catch { throw Object.assign(new Error('Invalid JSON.'), { statusCode: 400 }); }
}

const systemPrompt = `You are SHAIN GPT PLUS, a capable, friendly, respectful AI assistant. Reply naturally and helpfully, like a thoughtful conversational assistant. By default, reply in the user's language. Understand Bengali written in English letters (Romanized Bengali), Bengali script, Hindi, English, and any other languages you can support. If a preferred response language is specified, use it. Be honest about uncertainty, never invent sources, and do not claim to be human or to have human feelings. Explain complex things clearly and match the user's requested level of detail.`;

async function handleChat(req, res) {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
  if (!allowRequest(ip)) return send(res, 429, { error: 'Too many requests. Please wait a moment and try again.' });
  if (!AI_API_KEY || AI_API_KEY === 'replace_with_your_private_api_key') {
    return send(res, 503, { error: 'AI is not connected yet. Add your private AI API key to the server .env file, then restart the app.' });
  }

  let data;
  try { data = await readJson(req); }
  catch (error) { return send(res, error.statusCode || 400, { error: error.message || 'Could not read request.' }); }

  if (!Array.isArray(data.messages) || data.messages.length === 0 || data.messages.length > 30) {
    return send(res, 400, { error: 'Send between 1 and 30 chat messages.' });
  }
  const allowedRoles = new Set(['user', 'assistant']);
  const messages = [];
  for (const item of data.messages) {
    if (!item || !allowedRoles.has(item.role) || typeof item.content !== 'string' || item.content.length > 12_000) {
      return send(res, 400, { error: 'A message is invalid or too long.' });
    }
    messages.push({ role: item.role, content: item.content });
  }

  const langMap = {
    auto: 'Automatically detect the language and reply in the same language as the user.',
    Bengali: 'Reply in Bengali using Bengali script, unless the user explicitly requests another language.',
    English: 'Reply in English.', Hindi: 'Reply in Hindi.', 'Romanized Bengali': 'Reply in Bengali written with English letters (Romanized Bengali).'
  };
  const languageInstruction = langMap[data.language] || langMap.auto;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 60_000);

  try {
    const response = await fetch(`${AI_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${AI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: AI_MODEL,
        messages: [{ role: 'system', content: `${systemPrompt}\n\nLanguage preference: ${languageInstruction}` }, ...messages],
        temperature: 0.7,
        max_tokens: 1000
      }),
      signal: controller.signal
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      // Avoid returning provider diagnostics or secrets to the user.
      console.error(`AI provider returned HTTP ${response.status}.`);
      return send(res, response.status === 429 ? 429 : 502, { error: response.status === 429 ? 'The AI service is busy or its usage limit was reached. Please try again later.' : 'The AI service could not complete this reply. Check your model/API configuration and try again.' });
    }
    const answer = result?.choices?.[0]?.message?.content;
    if (typeof answer !== 'string' || !answer.trim()) return send(res, 502, { error: 'The AI returned an empty response. Please try again.' });
    return send(res, 200, { reply: answer.trim(), model: AI_MODEL });
  } catch (error) {
    const isTimeout = error?.name === 'AbortError';
    console.error(isTimeout ? 'AI provider request timed out.' : 'AI provider request failed.');
    return send(res, 502, { error: isTimeout ? 'The AI took too long to reply. Please try again.' : 'Could not reach the AI service. Check your internet connection and server configuration.' });
  } finally {
    clearTimeout(timeout);
  }
}

async function serveStatic(req, res, pathname) {
  let safePath;
  try { safePath = decodeURIComponent(pathname); } catch { safePath = '/'; }
  if (safePath === '/') safePath = '/index.html';
  const full = path.resolve(publicDir, `.${safePath}`);
  if (!full.startsWith(path.resolve(publicDir) + path.sep)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  try {
    const info = await stat(full);
    if (!info.isFile()) throw new Error('Not a file');
    const content = await readFile(full);
    securityHeaders(res);
    res.setHeader('Content-Type', MIME[path.extname(full)] || 'application/octet-stream');
    res.setHeader('Cache-Control', path.basename(full) === 'service-worker.js' ? 'no-cache' : 'public, max-age=300');
    res.writeHead(200); res.end(content);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Not found');
  }
}

const server = http.createServer(async (req, res) => {
  securityHeaders(res);
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/api/health') {
    return send(res, 200, { ok: true, aiConfigured: Boolean(AI_API_KEY && AI_API_KEY !== 'replace_with_your_private_api_key'), model: AI_MODEL });
  }
  if (req.method === 'POST' && url.pathname === '/api/chat') return handleChat(req, res);
  if (url.pathname.startsWith('/api/')) return send(res, 404, { error: 'API route not found.' });
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end('Method not allowed'); }
  return serveStatic(req, res, url.pathname);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`SHAIN GPT PLUS is running at http://localhost:${PORT}`);
  console.log(AI_API_KEY ? `AI configured with model: ${AI_MODEL}` : 'AI not configured: add AI_API_KEY to .env to enable live AI replies.');
});
