# SHAIN GPT PLUS

An installable, mobile-first AI chat app starter. It includes a polished chat UI, on-device conversation history, language preference, browser voice input/output where supported, a PWA install manifest, and a small Node.js backend that connects to an OpenAI-compatible Chat Completions API without exposing the API key to the browser.

## Important: connect a real AI model

The app's chat interface is ready, but live AI replies require a private API key from a compatible provider and a model that your account can access. No key is included in this project.

1. Install **Node.js 18 or newer**.
2. Copy `.env.example` to `.env`.
3. Open `.env` and set `AI_API_KEY` to your private key. Set `AI_MODEL` and `AI_BASE_URL` to a model/provider you can use.
4. Keep `.env` private. Never upload it to GitHub or paste your secret key into `public/app.js`.
5. Run `npm start` in this folder.
6. Open `http://localhost:3000` in your browser.

This starter uses an OpenAI-compatible `POST /chat/completions` endpoint. If your provider uses a different API format, update `server.js` to match its official documentation.

## Use on Android

For a quick local test, run the server on a computer and open the app from that computer in Chrome. For installation on your own Android phone as an app-like PWA, deploy this project to an HTTPS host, open its URL in Chrome on Android, then choose **Install app** or **Add to Home screen** from the browser menu.

PWA installation and offline shell caching do not mean the AI itself works offline: live answers still need an internet connection and configured backend.

## Deploy to a cloud host

You can deploy the whole project as a Node web service on a compatible host. Set `AI_API_KEY`, `AI_MODEL`, and optionally `AI_BASE_URL` as **server-side environment variables** in that host's dashboard. Do not expose secrets to the client. The service listens on the provided `PORT` environment variable.

## What's included

- Responsive dark-mode interface with custom SHAIN GPT PLUS brain/cloud branding.
- New conversations and chat history saved in this browser's local storage.
- Language preference: Auto, Bengali, Romanized Bengali (Banglish), English, or Hindi.
- Actual server-side AI request path (`/api/chat`) with input validation, timeout, and basic per-process rate limiting.
- Voice input when browser speech recognition is supported and permitted; read-aloud via browser speech synthesis.
- Copy responses, share app link, install prompt, and PWA app shell.

## Starter limitations to understand

- Conversations are saved in the current browser/device only; there is no user account or multi-device cloud sync yet.
- The in-memory rate limit is only a small starter safeguard, not enough by itself for a public production service. Add authentication, abuse monitoring, robust rate limiting, and request-cost limits before public launch.
- The app does not claim end-to-end encryption.
- Voice recognition depends on the browser/device and may send audio to the browser's speech service.
- Image upload, document analysis, group chat, and subscriptions are not included in this first starter.
- Configure HTTPS before public use. Use a provider/model combination that supports the Chat Completions-compatible endpoint implemented in `server.js`.

## Build a native Android package later

This delivered version is an installable web app starter rather than a compiled APK. Once hosted over HTTPS, it can be wrapped for Android using a Trusted Web Activity or a Capacitor-based Android project, then built into an APK/AAB using Android tooling. The backend and AI key must still be deployed securely for real AI replies.
