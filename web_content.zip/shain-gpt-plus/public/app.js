const $ = (selector) => document.querySelector(selector);
const els = {
  sidebar: $('#sidebar'), scrim: $('#scrim'), menuBtn: $('#menuBtn'), closeSidebar: $('#closeSidebar'), newChatBtn: $('#newChatBtn'), historyList: $('#historyList'), cloudStatus: $('#cloudStatus'),
  chatScroll: $('#chatScroll'), welcomeView: $('#welcomeView'), messages: $('#messages'), chatForm: $('#chatForm'), input: $('#messageInput'), sendBtn: $('#sendBtn'), voiceBtn: $('#voiceBtn'), language: $('#languageSelect'), installBtn: $('#installBtn'), shareBtn: $('#shareBtn'), toast: $('#toast')
};
const STORAGE_KEY = 'shain-gpt-plus-conversations-v1';
let chats = loadChats();
let currentId = chats[0]?.id || null;
let sending = false;
let recognition = null;
let installPrompt = null;
let toastTimer;

function loadChats() {
  try { const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); return Array.isArray(saved) ? saved : []; }
  catch { return []; }
}
function saveChats() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(chats.slice(0, 60))); }
  catch { notify('Could not save chat history on this device.'); }
}
function makeId() { return globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`; }
function currentChat() { return chats.find(chat => chat.id === currentId) || null; }
function notify(message) {
  els.toast.textContent = message; els.toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => els.toast.classList.remove('show'), 3000);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function formatAssistantText(text) {
  // Escape first, then apply a deliberately small, safe Markdown subset.
  let safe = escapeHtml(text);
  const codeBlocks = [];
  safe = safe.replace(/```([\w+-]*)\n?([\s\S]*?)```/g, (_, language, code) => {
    const index = codeBlocks.push(`<pre><code>${code.trim()}</code></pre>`) - 1;
    return `%%%CODEBLOCK${index}%%%`;
  });
  safe = safe.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  safe = safe.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  safe = safe.replace(/(^|\n)\- (.+)/g, '$1• $2');
  safe = safe.split(/\n{2,}/).map(part => part.trim() ? `<p>${part.replace(/\n/g, '<br>')}</p>` : '').join('');
  safe = safe.replace(/%%%CODEBLOCK(\d+)%%%/g, (_, i) => codeBlocks[Number(i)] || '');
  return safe;
}
function addMessageToDOM(message) {
  const row = document.createElement('article');
  row.className = `message ${message.role}`;
  if (message.role === 'user') {
    row.innerHTML = `<div class="message-body"></div><div class="message-avatar" aria-hidden="true">S</div>`;
    row.querySelector('.message-body').textContent = message.content;
  } else {
    row.innerHTML = `<div class="message-avatar"><img src="/assets/icon.svg" alt="AI"></div><div class="message-body"><div class="message-content"></div><div class="message-actions"><button type="button" data-action="copy">Copy</button><button type="button" data-action="speak">🔊 Listen</button></div></div>`;
    row.querySelector('.message-content').innerHTML = formatAssistantText(message.content);
    row.querySelector('[data-action="copy"]').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(message.content); notify('Reply copied.'); }
      catch { notify('Copy is unavailable in this browser.'); }
    });
    row.querySelector('[data-action="speak"]').addEventListener('click', () => speak(message.content));
  }
  els.messages.appendChild(row);
}
function renderHistory() {
  els.historyList.replaceChildren();
  if (!chats.length) {
    const empty = document.createElement('div'); empty.className = 'history-empty'; empty.textContent = 'Your conversations will appear here.'; els.historyList.appendChild(empty); return;
  }
  chats.forEach(chat => {
    const item = document.createElement('div'); item.className = `history-item${chat.id === currentId ? ' active' : ''}`;
    const symbol = document.createElement('span'); symbol.className = 'history-symbol'; symbol.textContent = '◷';
    const title = document.createElement('button'); title.type = 'button'; title.className = 'history-title'; title.textContent = chat.title || 'New conversation'; title.addEventListener('click', () => openChat(chat.id));
    const del = document.createElement('button'); del.type = 'button'; del.className = 'history-delete'; del.setAttribute('aria-label', 'Delete conversation'); del.title = 'Delete conversation'; del.textContent = '×';
    del.addEventListener('click', (event) => { event.stopPropagation(); deleteChat(chat.id); });
    item.append(symbol, title, del); els.historyList.appendChild(item);
  });
}
function renderChat() {
  const chat = currentChat();
  els.messages.replaceChildren();
  const hasMessages = !!chat && chat.messages.length > 0;
  els.welcomeView.hidden = hasMessages;
  els.messages.hidden = !hasMessages;
  if (chat) chat.messages.forEach(addMessageToDOM);
  renderHistory(); scrollToBottom();
}
function scrollToBottom() { requestAnimationFrame(() => { els.chatScroll.scrollTop = els.chatScroll.scrollHeight; }); }
function newChat() {
  if (sending) { notify('Wait for the current answer to finish first.'); return; }
  const chat = { id: makeId(), title: 'New conversation', messages: [], updatedAt: Date.now() };
  chats.unshift(chat); currentId = chat.id; saveChats(); renderChat(); closeMenu(); els.input.focus();
}
function openChat(id) {
  if (sending) return notify('Wait for the current answer to finish first.');
  currentId = id; renderChat(); closeMenu();
}
function deleteChat(id) {
  if (!confirm('Delete this conversation from this device?')) return;
  chats = chats.filter(chat => chat.id !== id);
  if (currentId === id) currentId = chats[0]?.id || null;
  saveChats(); renderChat(); notify('Conversation deleted from this device.');
}
function setLoading(loading) {
  sending = loading; els.sendBtn.disabled = loading; els.input.disabled = loading;
  els.sendBtn.innerHTML = loading ? '<span style="font-size:13px">…</span>' : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5M6 11l6-6 6 6"/></svg>';
}
function showTyping() {
  const row = document.createElement('article'); row.className = 'message assistant'; row.id = 'typingRow';
  row.innerHTML = '<div class="message-avatar"><img src="/assets/icon.svg" alt="AI"></div><div class="message-body"><div class="typing-row"><span>SHAIN is thinking</span><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div></div>';
  els.messages.appendChild(row); scrollToBottom();
}
function hideTyping() { $('#typingRow')?.remove(); }
async function sendMessage(rawText) {
  const content = rawText.trim();
  if (!content || sending) return;
  if (!currentChat()) {
    const chat = { id: makeId(), title: 'New conversation', messages: [], updatedAt: Date.now() };
    chats.unshift(chat); currentId = chat.id;
  }
  const chat = currentChat();
  chat.messages.push({ role: 'user', content, at: Date.now() });
  if (chat.title === 'New conversation') chat.title = content.length > 38 ? `${content.slice(0, 38).trim()}…` : content;
  chat.updatedAt = Date.now();
  if (chats[0]?.id !== chat.id) chats = [chat, ...chats.filter(item => item.id !== chat.id)];
  saveChats(); renderChat(); els.input.value = ''; autoSize(); setLoading(true); showTyping();
  try {
    const response = await fetch('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: chat.messages.slice(-24).map(({ role, content }) => ({ role, content })), language: els.language.value }),
      signal: AbortSignal.timeout ? AbortSignal.timeout(65000) : undefined
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Request failed (${response.status}).`);
    if (typeof data.reply !== 'string' || !data.reply.trim()) throw new Error('The AI returned an empty reply. Please try again.');
    chat.messages.push({ role: 'assistant', content: data.reply.trim(), at: Date.now() });
    chat.updatedAt = Date.now(); saveChats();
  } catch (error) {
    const message = error?.name === 'TimeoutError' ? 'The request took too long. Please try again.' : (error?.message || 'Could not connect to the AI service.');
    const hasServer = await fetch('/api/health').then(res => res.ok).catch(() => false);
    if (!hasServer) {
      chat.messages.push({ role: 'assistant', content: 'I could not connect to the app server. Please start SHAIN GPT PLUS with `npm start`, then open it at http://localhost:3000.' });
    } else {
      chat.messages.push({ role: 'assistant', content: `**Setup needed**\n\n${message}\n\nThe app's chat screen is ready, but a working AI API key must be configured on the server before I can answer for real.` });
    }
    saveChats();
  } finally {
    hideTyping(); setLoading(false); renderChat(); els.input.focus();
  }
}
function autoSize() { els.input.style.height = 'auto'; els.input.style.height = `${Math.min(els.input.scrollHeight, 140)}px`; }
function closeMenu() { els.sidebar.classList.remove('open'); els.scrim.classList.remove('visible'); }
function openMenu() { els.sidebar.classList.add('open'); els.scrim.classList.add('visible'); }
function speak(text) {
  if (!('speechSynthesis' in window)) return notify('Text-to-speech is not supported in this browser.');
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text.replace(/```[\s\S]*?```/g, ' code block '));
  const language = els.language.value;
  utterance.lang = language === 'Bengali' ? 'bn-IN' : language === 'Hindi' ? 'hi-IN' : language === 'English' ? 'en-IN' : 'en-IN';
  window.speechSynthesis.speak(utterance);
}
async function checkHealth() {
  const label = els.cloudStatus.querySelector('small');
  try {
    const response = await fetch('/api/health', { cache: 'no-store' });
    const data = await response.json();
    if (data.aiConfigured) { els.cloudStatus.classList.add('connected'); label.textContent = 'AI service connected'; }
    else { els.cloudStatus.classList.remove('connected'); label.textContent = 'Needs API key setup'; }
  } catch { label.textContent = 'Start app server to connect'; }
}

els.chatForm.addEventListener('submit', event => { event.preventDefault(); sendMessage(els.input.value); });
els.input.addEventListener('input', autoSize);
els.input.addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); els.chatForm.requestSubmit(); } });
els.newChatBtn.addEventListener('click', newChat);
els.menuBtn.addEventListener('click', openMenu);
els.closeSidebar.addEventListener('click', closeMenu);
els.scrim.addEventListener('click', closeMenu);
$('#suggestions').addEventListener('click', event => { const button = event.target.closest('[data-prompt]'); if (button) sendMessage(button.dataset.prompt); });
$('#profileButton').addEventListener('click', () => notify('This starter keeps chats on this device. Account sync can be added with an authentication backend.'));
els.shareBtn.addEventListener('click', async () => {
  const shareData = { title: 'SHAIN GPT PLUS', text: 'Try SHAIN GPT PLUS — your intelligent AI companion.', url: location.href };
  if (navigator.share) { try { await navigator.share(shareData); } catch {} }
  else { try { await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`); notify('Share link copied.'); } catch { notify('Open this app URL to share it.'); } }
});
els.voiceBtn.addEventListener('click', () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) return notify('Voice input is not supported here. Try Chrome on Android.');
  if (recognition) { recognition.stop(); recognition = null; els.voiceBtn.classList.remove('recording'); return; }
  recognition = new SpeechRecognition(); recognition.lang = els.language.value === 'Bengali' ? 'bn-IN' : els.language.value === 'Hindi' ? 'hi-IN' : 'en-IN'; recognition.interimResults = true; recognition.continuous = false;
  recognition.onstart = () => { els.voiceBtn.classList.add('recording'); notify('Listening… speak now.'); };
  recognition.onresult = event => { let transcript = ''; for (let i = event.resultIndex; i < event.results.length; i++) transcript += event.results[i][0].transcript; els.input.value = transcript; autoSize(); };
  recognition.onerror = event => notify(event.error === 'not-allowed' ? 'Allow microphone access to use voice input.' : 'Voice input stopped. You can type your message instead.');
  recognition.onend = () => { recognition = null; els.voiceBtn.classList.remove('recording'); };
  try { recognition.start(); } catch { recognition = null; notify('Could not start voice input.'); }
});
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; els.installBtn.hidden = false; });
els.installBtn.addEventListener('click', async () => { if (!installPrompt) return notify('Use your browser menu and choose “Install app” or “Add to Home Screen”.'); installPrompt.prompt(); await installPrompt.userChoice; installPrompt = null; els.installBtn.hidden = true; });
document.addEventListener('keydown', event => { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); newChat(); } if (event.key === 'Escape') closeMenu(); });

// Keep the most recent conversation selected on first open.
if (!currentId && chats.length) currentId = chats[0].id;
renderChat(); checkHealth();
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
