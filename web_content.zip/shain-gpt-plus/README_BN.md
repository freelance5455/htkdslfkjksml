# SHAIN GPT PLUS — বাংলা সেটআপ

এটি SHAIN GPT PLUS-এর প্রথম কাজের স্টার্টার ভার্সন। এতে আছে আধুনিক চ্যাট স্ক্রিন, নতুন চ্যাট, এই ব্রাউজারে চ্যাট হিস্ট্রি, বাংলা/বাংলিশ/English/Hindi ভাষা বেছে নেওয়া, এবং ব্রাউজার সমর্থন করলে ভয়েস ইনপুট ও উত্তর শুনে নেওয়ার সুবিধা।

## জরুরি কথা

**আসল AI উত্তর চালু করতে একটি AI provider-এর API key এবং একটি চালু server দরকার।** কোনো API key এই প্রজেক্টে রাখা হয়নি। API key কখনো `public/app.js`-এ লিখবে না।

## চালু করার নিয়ম

1. কম্পিউটারে Node.js 18 বা তার নতুন ভার্সন ইনস্টল করো।
2. এই ফোল্ডারে `.env.example` ফাইলটি কপি করে `.env` নামে রাখো।
3. `.env` খুলে `AI_API_KEY`-তে তোমার গোপন API key বসাও। `AI_MODEL`-এ তোমার অ্যাকাউন্টে উপলব্ধ model-এর নাম দাও।
4. টার্মিনাল/কমান্ড প্রম্পটে এই ফোল্ডারে গিয়ে `npm start` চালাও।
5. ব্রাউজারে `http://localhost:3000` খোলো।

Windows-এ `start-windows.bat`-ও চালাতে পারো। macOS/Linux-এ `./start-macos-linux.sh` চালানো যায়।

## Android ফোনে অ্যাপের মতো ইনস্টল

প্রথমে প্রজেক্টটি HTTPS-সহ একটি web host-এ deploy করতে হবে। তারপর Android Chrome-এ সেই URL খোলো, browser menu-তে গিয়ে **Install app** বা **Add to Home screen** বেছে নাও। এতে ফোনের home screen-এ অ্যাপের আইকন যোগ হবে।

এই সংস্করণটি installable web app (PWA), তৈরি করা APK নয়। AI কাজ করার জন্য cloud backend চালু থাকতে হবে। শুধু ওয়েব ফাইল ইনস্টল করলেই AI নিজে নিজে কাজ করবে না।

## কী এখনো যোগ করা হয়নি

অ্যাকাউন্ট/একাধিক ডিভাইসে sync, group chat, image বা document analysis, এবং subscription এই প্রথম সংস্করণে নেই। এটি public launch করার আগে authentication, শক্তিশালী rate limiting, billing limits ও privacy review দরকার।
