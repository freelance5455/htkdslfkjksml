@echo off
cd /d "%~dp0"
if not exist .env (
  copy .env.example .env >nul
  echo Created .env from .env.example.
  echo Open .env and add your private AI_API_KEY before expecting live AI answers.
)
node server.js
pause
