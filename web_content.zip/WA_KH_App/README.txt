WA KH - Freight Calculator (ZIP source)

Included:
- index.html: a simple offline-capable freight calculator page.
- Supports Pashto, Dari, and English.
- Calculates freight = tonnage x rate per ton.
- 5% commission = 5% of freight and is added to the grand total.
- Toll plazas: select 0-10; one fee is applied to every plaza.
- Grand total = freight + 5% commission + total toll fees.
- 2% commission is displayed separately and is NOT added or subtracted.
- Stores saved calculations in the browser on the same device.
- CSV export for saved calculations.

How to try it:
1. Extract this ZIP on your Android phone.
2. Open index.html in a browser if your file manager allows it.
3. If local storage does not work when opened as a local file, host the folder on a static web host or use a local HTML viewer/browser.
4. This ZIP is the app's web-source prototype, not an Android APK and not a Kodular project file. It has not been compiled into an APK.
