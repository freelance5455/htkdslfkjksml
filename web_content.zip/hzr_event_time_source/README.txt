HZR Event Time — Prototype v1.7

Contents
- index.html: browser-based prototype
- logo-red-black.png: red/black app logo
- logo-black-gold.png: secondary logo

How to run
Open index.html in a modern browser. On first launch, create an admin name and password (minimum 8 characters). Data is stored locally in that browser's localStorage.

v1.6 fixes and features
- Added Event Search to the home dashboard.
- Search matches full or partial event names without case sensitivity for English text.
- Leaving the search field empty lists all saved events, including past, upcoming, ongoing, completed, and cancelled events.
- Results are sorted by start date, newest first; events without a start date appear after dated events.
- Search results show the event date, status, and location, and the Open Event button navigates to that event.
- Added an explicit no-results message and an accessible search label.

v1.7 maintenance
- Updated this README to document the v1.6 Event Search feature and the current package version.

v1.4 fixes
- Fixed the home-dashboard Event Gallery shortcut so it always opens the all-events gallery instead of accidentally reusing the previously selected event.
- Added validation to reject same-day events whose end time is earlier than their start time.
- Added media-source allowlisting for rendered event logos, gallery media, and exam question images, preventing unsupported or malformed data URLs from being embedded as active media.

v1.0 fixes
- Corrected Bengali/English home-dashboard tile labels so each language displays consistently.
- Translated the first-launch welcome heading in both supported languages.
- Event creation/editing screen now shows the correct title for the selected action.
- Preserved an explicitly configured pass mark of 0 when editing a subject instead of silently changing it to 33.
- Retained the v0.9 data-safety fixes: failed event/member deletion rollback, backup admin validation, backup array normalization, and safe setting defaults.

Validation performed
- JavaScript syntax check with Node.js.
- Static regression assertions for the v1.4 fixes
- Fixed the home-dashboard Event Gallery shortcut so it always opens the all-events gallery instead of accidentally reusing the previously selected event.
- Added validation to reject same-day events whose end time is earlier than their start time.
- Added media-source allowlisting for rendered event logos, gallery media, and exam question images, preventing unsupported or malformed data URLs from being embedded as active media.

v1.0 fixes and earlier backup/rollback safeguards.
- ZIP integrity test with unzip -t.
- A full interactive end-to-end test on a real Android device/browser has NOT been completed; this cannot be certified 100% bug-free from static checks alone.

Important limitations
- This is a local browser prototype, not an Android APK.
- Data does not automatically sync between devices/admins.
- Password hashing and localStorage are prototype-level only, not production-grade account security or a secure production database.
- localStorage may have limited capacity, especially for media; export backups regularly and do not keep the only copy of important records here.
- Reminder/notification support is limited in this prototype.


Version 1.3 additional fixes:
- Completed events are excluded from upcoming-event cards.
- Member IDs/names are trimmed before saving and duplicate checking.
- Logo/question/gallery uploads reject unsupported MIME types before saving.
- Unregistering a member from a subject removes that member's stale result from that subject.
- Backup restore rejects unsafe/malformed event, member, subject, and media IDs.


Version 1.3 review notes:
- Rejects blank/whitespace-only event and subject names.
- Validates budget and expense as finite, non-negative numbers before save.
- Tightens backup validation for top-level media, activity entries, subject registrations/results, and question image data.
- JavaScript syntax and ZIP integrity were checked; real-device end-to-end testing is still required.


Version 1.4 additional fix:
- Removed duplicate navigation click handling. Navigation is now handled once by the delegated click listener, avoiding redundant re-renders when switching views.


Version 1.5 additional fix:
- Backup restore now validates the actual media type and data URL for top-level and per-event media entries, not just their IDs. Invalid or malformed media records are rejected before replacing current data.

Version 1.5 validation:
- JavaScript syntax check with Node.js.
- Regression checks for event/member/subject/backup validation and media data validation.
- ZIP integrity test.
- Full browser/device end-to-end testing remains outstanding.


v1.6 feature addition:
- Added an Event Search tile to the home dashboard.
- Search matches full or partial event names without filtering by event date or status, so past, current, upcoming, completed, and cancelled events can all be found.
- Results are sorted newest start date first and show date, status, location, and an Open Event action.
- Search is case-insensitive and updates as the user types; an empty query lists all events.

v1.6 validation:
- JavaScript syntax check with Node.js.
- Static checks for search navigation, live name filtering, inclusion of all event statuses, result ordering, safe HTML escaping, and empty/no-match states.
- ZIP integrity check with unzip -t.
- Full real-device/browser end-to-end testing has not been completed.
