(()=>{
 const gate=document.getElementById('pinGate'),form=document.getElementById('pinForm'),input=document.getElementById('pinInput'),msg=document.getElementById('pinMessage'),submit=document.getElementById('pinSubmit'),error=document.getElementById('pinError');
 const key='smartTakaPersonalPin';
 let stored=localStorage.getItem(key);
 if(stored){msg.textContent='আপনার ব্যক্তিগত অ্যাপ খুলতে PIN দিন।';submit.textContent='অ্যাপ খুলুন';input.minLength=4;}
 else {msg.textContent='প্রথমবার ব্যবহারের জন্য ৪–৮ সংখ্যার একটি PIN তৈরি করুন। এটি এই ফোনের এই অ্যাপেই রাখা হবে।';submit.textContent='PIN তৈরি করুন';}
 form.addEventListener('submit',e=>{e.preventDefault();const pin=input.value.trim();error.textContent='';if(!/^\d{4,8}$/.test(pin)){error.textContent='৪ থেকে ৮ সংখ্যার PIN দিন।';return;}
 if(!stored){localStorage.setItem(key,pin);stored=pin;gate.hidden=true;input.value='';return;}
 if(pin===stored){gate.hidden=true;input.value='';}else{error.textContent='PIN সঠিক নয়। আবার চেষ্টা করুন।';input.value='';input.focus();}
 });
 // Lock again when the app is backgrounded and reopened.
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'&&stored){gate.hidden=false;input.value='';error.textContent='';msg.textContent='আপনার ব্যক্তিগত অ্যাপ খুলতে PIN দিন।';submit.textContent='অ্যাপ খুলুন';}});
})();
