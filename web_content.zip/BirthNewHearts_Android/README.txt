BIRTH: NEW HEARTS - Android project (Android Studio)

1) Install Android Studio (Hedgehog or newer) - it includes JDK 17 and the SDK.
2) File > Open > choose this folder. Wait for Gradle sync (needs internet the first time).
3) Build > Build Bundle(s) / APK(s) > Build APK(s)
   The APK is created at app/build/outputs/apk/debug/app-debug.apk
   Or press Run with a phone connected (USB debugging) or an emulator.

Offline play: download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
and save it as app/src/main/assets/three.min.js (same folder as index.html).
Without it the game downloads three.js from the internet when it starts.

The game itself is app/src/main/assets/index.html (you can edit it).
Screen orientation: landscape (change android:screenOrientation in AndroidManifest.xml).

--- v5 ---
* Improved animation: walk cycle, breathing, blinking, body lean/lunge on attacks, swaying cape/hair/scarf,
  glowing weapon trails, additive-glow particles/beams/pillars/rings, crescent slashes, enemy auras + squash,
  hit-stop on heavy hits, pop-up damage numbers, vignette + low-HP pulse, animated arena floor.
* Each hero has a unique passive: ERYON Dawn Rhythm, LUNEA Starlit Orbit, KAEL Void Hunger.
* 6 new learnable skills (buy from Zia in Dawn City): Phantom Legion, Dawn Parry, Comet Chain,
  Moon Sanctuary, Void Rift, Soul Reap. Keys 1-7 cast skills.

--- v6 ---
* Sound: all sound effects are generated in code (no audio files, works offline): attacks, skills, limit, transform,
  hits, pickups, UI, and monster voices (growl/windup/strike/hurt/death for every enemy type, boss roar).
  Speaker button (top right) mutes everything.
* Character voices (device text-to-speech, English; subtitle always shown):
  Transform: ERYON "Give me strength!" / LUNEA "I can do it!" / KAEL "Let's go!"
  Limit: "Dawn breaks!" / "Starlight, guide me!" / "Into the void!"
  Low HP: "I won't give up!" / "Stay with me!" / "Not yet!"
  If the phone has no English TTS voice installed, a synthesized shout plays instead of speech.
* Stability: auto-pause + save when the app/tab goes to background, Back button opens menu (exit from title),
  crash-recovery if the WebView process dies, NaN/overflow guards, effect/shot caps, automatic quality drop on slow
  devices, stuck-input fixes, safer save loading, old-WebView syntax compatibility, error banner auto-hides.

--- v7 ---
* 3D look added on top of the original art (shapes/colors/animation unchanged): depth extrusion + top-left light /
  bottom-right shade on heroes, NPCs, enemies, rocks; arena floor shown as a thick 3D slab; beveled 3D buttons,
  joystick and menu panel.
* Menu button "مظهر ثلاثي الأبعاد" turns it on/off (saved). It switches off automatically when quality drops on slow devices.

--- v8 ---
* Monster animation: elastic rise-from-ground spawn with rune portal + light pillar (staggered), walk hop / lean,
  attack anticipation squash then stretch/lunge, hit wobble, spinning flash dissolve on death with shards.
  Per-type details: Shadow mist tendrils, Void Beast spikes, Caster orbiting runes, Wisp comet tail,
  Crawler glowing eyes, Golem embers + crystal glints.
* Bosses redrawn: winged, hooded, floating clawed hands, orbiting shards, pulsing heart core.
  Boss health bar at top. Boss death = chained explosions then final flash.
* FINAL BOSS (chapter 30) "Unknown Entity - Final Form": bigger, crowned with a triple wing set, 3 phases
  (66% summons shadows, 33% crimson rage with faster attacks), new Nova bullet-ring attack with warning spokes.
* Stage transitions: STAGE CLEAR card -> iris wipe -> opening iris + chapter title card (red WARNING card for bosses);
  VICTORY card after the final boss.

--- v9 ---
* Companions: the two heroes you are not controlling now fight beside you automatically.
  LUNEA stays at range (star bolts, heals the weakest ally, 3-star volley), ERYON (Dawn Wave) and KAEL (Void pull)
  fight in melee. Enemies can target and hurt them (shown by small HP bars). A fallen ally leaves the fight until
  the next chapter. Switching hero swaps who is controlled and who is the AI.

--- v10 ---
* New look: dawn-glass main menu (animated sunrise glow, three hero hearts, gold logo, big START button, tile grid),
  chamfered-corner buttons everywhere (menu, skills, action buttons, round HUD buttons), redesigned joystick and control bar,
  glass sub-menus with a compact logo.

--- v11 ---
* Arena size and design: the arena now grows with each world (radius 440 -> 720; Dawn City stays 440).
  Obstacles, terrain zones and the player start position scale with the arena size.
* Per-world ground decor (animated): waves, glowing grass tufts, rune tiles, twinkling stars, ice cracks,
  sand ripples, dawn light tiles, glowing lava cracks. Outer spokes on large arenas, glowing rim gems,
  and 4 glowing pylons around the edge. Decor is skipped automatically on slow devices (low quality mode).

--- v12 ---
* Character bodies redrawn with curves instead of boxes: tapered torso (shoulders > waist > hips), rounded shoulders,
  tapered arms with round hands, tapered legs with rounded boots, oval eyes, rounded belt/collar/hair accents.
  Applies to all three heroes, NPCs and transformed forms.

--- v13 ---
* Skill buttons redesigned: round elemental buttons (fire/ice/thunder/heal/void/light/blood/earth colors) with an icon per skill,
  energy-cost badge, key number (1-7), skill name, circular cooldown ring + seconds counter, glow pulse when ready,
  greyed out when energy is low, flash on cast. 2 columns once you have more than 4 skills.
* LIMIT button pulses when ready. ATTACK button is now a true circle.

Browser version: open BirthNewHearts_Browser.html (in this folder) in any browser. It is a copy of app/src/main/assets/index.html.
If you edit the game, edit app/src/main/assets/index.html (used by the APK) and copy it over BirthNewHearts_Browser.html.

Build the APK without a computer (GitHub Actions): upload this whole folder (including the hidden .github folder) to a new GitHub repository,
open the Actions tab > "Build APK" > wait for the green check > download the artifact "BirthNewHearts-apk" (a zip containing app-debug.apk).

--- v14 ---
* Wide-screen (landscape) mode: the app is locked to sensorLandscape (works in both landscape directions).
  The arena fills the whole screen; joystick (left) and DASH/ATTACK/SWITCH/LIMIT (right) float over it; skill buttons sit
  above the joystick in rows of two; messages show at the top center. Main menu is split into buttons + logo.
  In a browser the same layout applies whenever the window is wider than tall.

--- v15 ---
* Movement feel: the hero now accelerates and slows down smoothly (short ease-in / ease-out) instead of instant start/stop.
* Walk animation: stride is driven by the real speed (feet no longer slide), knees bend on each step (thigh + shin),
  smooth blend between idle breathing and walking, body bob / lean / arm swing scale with speed, forward lean while dashing.
  Companions use the same walk cycle.

--- v16 ---
* New systems (original designs, inspired by classic action-RPG mechanics):
  - REACTION command: a perfect dash right before an enemy hits (JUST DODGE) opens a 2.4s window; the pulsing REACTION button
    teleports you to the target for a 5-hit counter flurry (+MP, +HP). Bosses under 25% HP offer a 7-hit FINISH reaction. Key: F.
  - SUMMON (key E, 80 energy, 35s cooldown): the Spirit of Dawn orbits you for 12s, shoots enemies and slowly heals you.
  - ATTRACTION (key R, 70 energy, 25s cooldown): Dusk Carousel - 5s of six spinning light blades that damage and push enemies and erase enemy shots.
  - FLOW dash: dashing through enemies now damages and briefly stuns them and gives a little energy.
  - Energy RECHARGE mode: when energy hits 0 the hero recharges quickly to 45 before skills can be used again.
* Controls: landscape layout redesigned - joystick left; ATTACK / DASH / LIMIT / SWITCH / SUMMON / ATTRACT around the right thumb;
  skill buttons in a row next to them (no longer on top of the joystick).
* Move any button: Main menu > "تعديل أماكن الأزرار" then drag buttons anywhere. Saved separately for landscape and portrait. "إعادة الضبط" resets.

--- v17 ---
* Dawn City (مدينة الفجر) is bigger: arena radius 440 -> 616 (x1.4). Buildings, NPCs and the start position are spread out
  to match, and 3 new houses fill the extra space. Change the factor with "const TS=1.4" in index.html.

--- v18: "DAYS" mode (inspired by 358/2 Days mechanics, original content) ---
* Mission mode (main menu > وضع المهام, or Captain Sarin in Dawn City): 30 missions (DAY 1-30), unlocked in order.
  Objectives: defeat all / defeat the boss / defeat all before time runs out / defeat N Heartless in waves / survive until the timer ends.
  A mission HUD shows objective, timer, chain and hits taken.
* Mission rating S/A/B/C/D from time, hits taken, HP left and best kill chain. Rewards: Munny, EXP (the lead hero gets full EXP,
  the other two 40%), materials and new panels. First clear gives a bonus. Best rank/time is saved per mission.
* Panel system (main menu > نظام اللوحات): every hero has a panel board (7x6). Slots unlock from the centre as the hero levels up
  (EXP comes from missions). Tap a panel then tap the board; tap a placed panel to pick it up; rotate with the button.
  Panels: Power, Health, Armor, Speed, Energy Regen, Munny Boost, EXP Boost, Second Chance (survive one lethal hit),
  Potion / Ether (items, button ITEM or key I) and Skill panels (a skill only works while its panel is on the board, max 7).
  Adjacent panels of the same type give a chain bonus (x1.15 per neighbour, up to x1.45).
* Shop & synthesis (main menu > المتجر والتركيب, or Pipo in Dawn City): buy Lv1 panels with Munny; synthesize Lv2/Lv3 panels from
  materials dropped by Heartless (bosses drop Crystal Hearts). Skills bought from Zia now become skill panels.
* Progress is saved automatically (localStorage key bnh_days_v1). Story mode is unchanged.

--- v19: TRUE 3D MODE (third-person, "Days"-style camera) ---
* The whole game now renders in real 3D with a built-in renderer (no external library, works fully offline in the APK and in browsers).
  Heroes, companions, NPCs, enemies, bosses, houses, fountain and rocks are low-poly 3D models with lighting, shadows and
  depth sorting; the arena is a floating island. All fx (slashes, rings, beams, pillars, particles, damage numbers) are 3D.
* Third-person camera behind/above the hero. It automatically turns toward the nearest enemy (lock-on reticle) and zooms out for bosses.
  Rotate the camera yourself: drag on an empty part of the screen (touch) or press Z / X (or [ ]).
* Movement is camera-relative (push the stick "up" = run away from the camera).
* Menu button "مظهر ثلاثي الأبعاد" switches between full 3D and the old 2D view (saved). If 3D ever fails 3 times it falls back to 2D by itself.
* Gameplay, missions, panels, shop, saves are unchanged (same save keys).

--- v20: new hero bodies + behind-the-hero camera ---
* Camera: now a low, close third-person chase camera right behind the hero (pitch 0.64 -> 0.2, distance 390 -> 250, look-at point raised to the upper body).
  It also swings behind the hero's running direction automatically (and in Dawn City too). Manual rotation (drag / Z X) still works.
* Heroes redesigned with new original body shapes (different proportions, outfits and silhouettes):
  ERYON - sturdy athletic build, short jacket with gold belt, puffy sleeves, chunky boots, headband.
  LUNEA - slim and graceful, flared layered skirt, wide flared cuffs, tall boots, hair ribbon.
  KAEL  - tall and broad, long coat to the knees, high collar, armored shoulders, long swept hair.

--- v21: new organic character bodies ---
* Heroes are no longer built from boxes/cylinders and balls. A new "loft" mesh renderer builds smooth low-poly bodies:
  shaped torso (waist/chest/shoulders), tapered legs with knees and boots with pointed toes, arms with sleeves/cuffs/gauntlets and fists,
  a head with a jawline, glowing eyes, and faceted blade-shaped hair strands (spikes, long locks, ribbons, ponytail).
* Outfits: ERYON jacket + shorts + headband, LUNEA layered flared skirt + flared cuffs + ribbon, KAEL long coat + armored shoulders + high collar.


--- v22: PERFORMANCE (smooth play on weak phones, e.g. Redmi A5 3GB) ---
* Auto device tier: on Android phones with <=4GB RAM / few cores / HD screens the game starts in "low" mode:
  canvas resolution capped to 1x (instead of 2x = 4x fewer pixels), 30 FPS frame limiter (steady pacing instead of 20-60 FPS jitter),
  smaller character/enemy meshes, fewer particles, no ground decor, cheaper HUD text.
* Adaptive resolution: if the phone still can't hold 30 FPS the render scale drops step by step (down to 0.62x), then an
  ultra-light tier switches on, then the cap goes to 24 FPS. (The old version checked once and only lowered the DPR.)
* Menu button "الأداء: تلقائي / توفير (سلس) / جودة عالية" cycles Auto / Power-saver / High quality (saved).
* Less garbage collection: shaded colours are cached (no new strings per polygon), faces of a body part are drawn in batches,
  background gradient + vignette are pre-rendered once, DOM button text is only touched when it changes.
* CSS: looping box-shadow / filter animations on buttons are disabled in low mode (they forced a repaint every frame).
* Audio: fewer simultaneous sound nodes in low mode.
* Android: WebView hardware layer, no window-background overdraw, zoom / text-zoom off, largeHeap.


--- v23: imported 3D character models (Eryon / Lunea / Kael) ---
* The three heroes now use the models from "Birth_NewHearts_3D_From_Image" (original files in models_src/: .glb / .obj / .png).
  The textures are baked into per-triangle colours (80-colour palette) and each mesh is split into rigged parts, so they animate:
  walk cycle (legs + knees, arms swing), lean / lunge on attacks, the right arm follows the weapon swing (sword / staff stay in the hand),
  hair / cloak / coat panels sway with movement. Weapons, glow, slash trails, transform auras are unchanged.
* 3 levels of detail (about 2800 / 1300 / 600 triangles): the controlled hero uses the highest on "high quality", companions one level lower,
  and the low-end (Redmi A5 style) power-saver tiers use the lighter levels automatically.
* Menu button "نماذج الأبطال" turns the new models on/off (saved); off = the old procedural bodies. NPCs (Sarin, Pipo, Zia...) keep the old bodies.
* To rebuild the data after changing the models: python3 tools/build_models.py models_src models_data.js  (needs numpy, Pillow, scipy, scikit-learn),
  then paste the result into the <script> block that starts with "window.HMDL=" in index.html.
