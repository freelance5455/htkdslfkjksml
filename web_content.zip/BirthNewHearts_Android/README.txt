BIRTH: NEW HEARTS - Android project (Android Studio)

1) Install Android Studio (Hedgehog or newer) - it includes JDK 17 and the SDK.
2) File > Open > choose this folder. Wait for Gradle sync (needs internet the first time).
3) Build > Build Bundle(s) / APK(s) > Build APK(s)
   The APK is created at app/build/outputs/apk/debug/app-debug.apk
   Or press Run with a phone connected (USB debugging) or an emulator.

Offline play: download https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
and save it as app/src/main/assets/three.min.js (same folder as index.html).
Without it the game downloads three.js from the internet when it starts.

The game itself is app/src/main/assets/index.html (you can edit it).
Screen orientation: portrait (change android:screenOrientation in AndroidManifest.xml).

--- v5 ---
* Improved animation: walk cycle, breathing, blinking, body lean/lunge on attacks, swaying cape/hair/scarf,
  glowing weapon trails, additive-glow particles/beams/pillars/rings, crescent slashes, enemy auras + squash,
  hit-stop on heavy hits, pop-up damage numbers, vignette + low-HP pulse, animated arena floor.
* Each hero has a unique passive: ERYON Dawn Rhythm, LUNEA Starlit Orbit, KAEL Void Hunger.
* 6 new learnable skills (buy from Zia in Dawn City): Phantom Legion, Dawn Parry, Comet Chain,
  Moon Sanctuary, Void Rift, Soul Reap. Keys 1-7 cast skills.

--- v6 ---
* Sound: all sound effects are generated in code (no audio files, works offline): attacks, skills, limit, transform,
  hits, pickups, UI, and monster voices (growl/windup/strike/hurt/death for every enemy type, boss roar).
  Speaker button (top right) mutes everything.
* Character voices (device text-to-speech, English; subtitle always shown):
  Transform: ERYON "Give me strength!" / LUNEA "I can do it!" / KAEL "Let's go!"
  Limit: "Dawn breaks!" / "Starlight, guide me!" / "Into the void!"
  Low HP: "I won't give up!" / "Stay with me!" / "Not yet!"
  If the phone has no English TTS voice installed, a synthesized shout plays instead of speech.
* Stability: auto-pause + save when the app/tab goes to background, Back button opens menu (exit from title),
  crash-recovery if the WebView process dies, NaN/overflow guards, effect/shot caps, automatic quality drop on slow
  devices, stuck-input fixes, safer save loading, old-WebView syntax compatibility, error banner auto-hides.

--- v7 ---
* 3D look added on top of the original art (shapes/colors/animation unchanged): depth extrusion + top-left light /
  bottom-right shade on heroes, NPCs, enemies, rocks; arena floor shown as a thick 3D slab; beveled 3D buttons,
  joystick and menu panel.
* Menu button "مظهر ثلاثي الأبعاد" turns it on/off (saved). It switches off automatically when quality drops on slow devices.

--- v8 ---
* Monster animation: elastic rise-from-ground spawn with rune portal + light pillar (staggered), walk hop / lean,
  attack anticipation squash then stretch/lunge, hit wobble, spinning flash dissolve on death with shards.
  Per-type details: Shadow mist tendrils, Void Beast spikes, Caster orbiting runes, Wisp comet tail,
  Crawler glowing eyes, Golem embers + crystal glints.
* Bosses redrawn: winged, hooded, floating clawed hands, orbiting shards, pulsing heart core.
  Boss health bar at top. Boss death = chained explosions then final flash.
* FINAL BOSS (chapter 30) "Unknown Entity - Final Form": bigger, crowned with a triple wing set, 3 phases
  (66% summons shadows, 33% crimson rage with faster attacks), new Nova bullet-ring attack with warning spokes.
* Stage transitions: STAGE CLEAR card -> iris wipe -> opening iris + chapter title card (red WARNING card for bosses);
  VICTORY card after the final boss.

--- v9 ---
* Companions: the two heroes you are not controlling now fight beside you automatically.
  LUNEA stays at range (star bolts, heals the weakest ally, 3-star volley), ERYON (Dawn Wave) and KAEL (Void pull)
  fight in melee. Enemies can target and hurt them (shown by small HP bars). A fallen ally leaves the fight until
  the next chapter. Switching hero swaps who is controlled and who is the AI.

--- v10 ---
* New look: dawn-glass main menu (animated sunrise glow, three hero hearts, gold logo, big START button, tile grid),
  chamfered-corner buttons everywhere (menu, skills, action buttons, round HUD buttons), redesigned joystick and control bar,
  glass sub-menus with a compact logo.

--- v11 ---
* Arena size and design: the arena now grows with each world (radius 440 -> 720; Dawn City stays 440).
  Obstacles, terrain zones and the player start position scale with the arena size.
* Per-world ground decor (animated): waves, glowing grass tufts, rune tiles, twinkling stars, ice cracks,
  sand ripples, dawn light tiles, glowing lava cracks. Outer spokes on large arenas, glowing rim gems,
  and 4 glowing pylons around the edge. Decor is skipped automatically on slow devices (low quality mode).

--- v12 ---
* Character bodies redrawn with curves instead of boxes: tapered torso (shoulders > waist > hips), rounded shoulders,
  tapered arms with round hands, tapered legs with rounded boots, oval eyes, rounded belt/collar/hair accents.
  Applies to all three heroes, NPCs and transformed forms.

--- v13 ---
* Skill buttons redesigned: round elemental buttons (fire/ice/thunder/heal/void/light/blood/earth colors) with an icon per skill,
  energy-cost badge, key number (1-7), skill name, circular cooldown ring + seconds counter, glow pulse when ready,
  greyed out when energy is low, flash on cast. 2 columns once you have more than 4 skills.
* LIMIT button pulses when ready. ATTACK button is now a true circle.

Browser version: open BirthNewHearts_Browser.html (in this folder) in any browser. It is a copy of app/src/main/assets/index.html.
If you edit the game, edit app/src/main/assets/index.html (used by the APK) and copy it over BirthNewHearts_Browser.html.
