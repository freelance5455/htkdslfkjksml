#!/usr/bin/env python3
"""Converts Eryon/Lunea/Kael textured OBJ models into a compact rigged low-poly data blob (models_data.js).
Usage: build_models.py <models_dir> <out.js>   (models_dir contains X_textured.obj / .png)"""
import sys, json, base64, heapq
import numpy as np
from PIL import Image
import scipy.sparse as sp, scipy.sparse.csgraph as cg
from sklearn.cluster import KMeans

HEIGHT = {'Eryon': 71.0, 'Lunea': 73.0, 'Kael': 78.0}   # in-game height (world units)
LODFR = [0.72, 0.33, 0.15]                              # face fraction of the welded mesh for LOD0/1/2
NPAL = 80
GAIN = {'Eryon': 1.35, 'Lunea': 1.08, 'Kael': 1.5}

def load(path):
    V = []; T = []; N = []; F = []
    for l in open(path):
        p = l.split()
        if not p: continue
        if p[0] == 'v': V.append([float(x) for x in p[1:4]])
        elif p[0] == 'vt': T.append([float(x) for x in p[1:3]])
        elif p[0] == 'vn': N.append([float(x) for x in p[1:4]])
        elif p[0] == 'f': F.append([[int(i) - 1 for i in q.split('/')] for q in p[1:4]])
    F = np.array(F)                                     # (m,3,3) v/vt/vn
    return np.array(V), np.array(T), np.array(N), F

def sample_colors(img, uv):                              # uv (m,3,2)
    h, w, _ = img.shape
    ws = [(1/3, 1/3, 1/3), (.6, .2, .2), (.2, .6, .2), (.2, .2, .6)]
    acc = 0
    for wt in ws:
        p = (uv * np.array(wt)[None, :, None]).sum(1)
        x = np.clip((p[:, 0] * w).astype(int), 0, w - 1)
        y = np.clip(((1 - p[:, 1]) * h).astype(int), 0, h - 1)
        acc = acc + img[y, x].astype(float)
    return acc / len(ws)

def qem_decimate(P, F, target):
    """edge-collapse (to an existing endpoint) of one component. P (n,3) F (m,3). returns kept face index list + new face verts."""
    F = [tuple(f) for f in F]
    alive = [True] * len(F)
    nv = len(P)
    vf = [set() for _ in range(nv)]
    for i, f in enumerate(F):
        for v in f: vf[v].add(i)
    def fnorm(f, Pp=P):
        a, b, c = Pp[f[0]], Pp[f[1]], Pp[f[2]]
        n = np.cross(b - a, c - a); l = np.linalg.norm(n); return n / l if l > 1e-12 else n * 0, l / 2
    Q = np.zeros((nv, 4, 4))
    ecount = {}
    for f in F:
        for k in range(3):
            e = tuple(sorted((f[k], f[(k + 1) % 3]))); ecount[e] = ecount.get(e, 0) + 1
    for i, f in enumerate(F):
        n, ar = fnorm(f)
        if ar == 0: continue
        d = -n @ P[f[0]]; pl = np.append(n, d); q = np.outer(pl, pl) * ar
        for v in f: Q[v] += q
        for k in range(3):
            a, b = f[k], f[(k + 1) % 3]
            if ecount[tuple(sorted((a, b)))] == 1:      # boundary: constraint plane
                e = P[b] - P[a]; bn = np.cross(e, n); bl = np.linalg.norm(bn)
                if bl < 1e-12: continue
                bn /= bl; pl2 = np.append(bn, -bn @ P[a]); q2 = np.outer(pl2, pl2) * 50 * (np.linalg.norm(e) ** 2) * 0.5
                Q[a] += q2; Q[b] += q2
    ver = [0] * nv
    def cost(a, b):
        Qs = Q[a] + Q[b]; best = None
        for keep, drop in ((a, b), (b, a)):
            v = np.append(P[keep], 1.0); c = v @ Qs @ v
            if best is None or c < best[0]: best = (c, keep, drop)
        return best
    heap = []
    def push(a, b):
        c, keep, drop = cost(a, b); heapq.heappush(heap, (c, ver[a] + ver[b], a, b, keep, drop))
    edges = set()
    for f in F:
        for k in range(3): edges.add(tuple(sorted((f[k], f[(k + 1) % 3]))))
    for a, b in edges: push(a, b)
    nalive = len(F)
    while nalive > target and heap:
        c, vs, a, b, keep, drop = heapq.heappop(heap)
        if not (vf[a] and vf[b]) or vs != ver[a] + ver[b]: continue
        # check that drop still adjacent to keep
        shared = vf[keep] & vf[drop]
        if not shared: continue
        # flip check
        bad = False
        for fi in vf[drop] - shared:
            f = F[fi]; nf = tuple(keep if v == drop else v for v in f)
            n0, a0 = fnorm(f); n1, a1 = fnorm(nf)
            if a1 < 1e-9 or n0 @ n1 < 0.35: bad = True; break
        if bad: continue
        for fi in shared: alive[fi] = False; nalive -= 1
        for fi in vf[drop] - shared:
            F[fi] = tuple(keep if v == drop else v for v in F[fi]); vf[keep].add(fi)
        for fi in shared:
            for v in F[fi]: vf[v].discard(fi)
        vf[drop] = set()
        Q[keep] += Q[drop]; ver[keep] += 1
        nb = set()
        for fi in vf[keep]:
            for v in F[fi]:
                if v != keep: nb.add(v)
        for v in nb: ver[v] += 0; push(keep, v)
    return [i for i in range(len(F)) if alive[i]], F

def build(name, mdir):
    V0, T0, N0, F0 = load(f'{mdir}/{name}_textured.obj')
    img = np.asarray(Image.open(f'{mdir}/{name}_textured.png').convert('RGB'))
    Pf = V0[F0[:, :, 0]]; uv = T0[F0[:, :, 1]]; vn = N0[F0[:, :, 2]].mean(1)
    col = sample_colors(img, uv) * GAIN[name]
    key = np.round(Pf.reshape(-1, 3) * 2000).astype(np.int64)
    u, inv = np.unique(key, axis=0, return_inverse=True); inv = inv.ravel()
    P = u / 2000.0; F = inv.reshape(-1, 3)
    ok = (F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])
    # orient by vertex normals
    a, b, c = P[F[:, 0]], P[F[:, 1]], P[F[:, 2]]
    fn = np.cross(b - a, c - a)
    fl = (fn * vn).sum(1) < 0
    F[fl] = F[fl][:, ::-1]
    F = F[ok]; col = col[ok]
    # components
    r = np.concatenate([F[:, 0], F[:, 1], F[:, 2]]); cc = np.concatenate([F[:, 1], F[:, 2], F[:, 0]])
    g = sp.coo_matrix((np.ones(len(r)), (r, cc)), shape=(len(P), len(P)))
    k, lab = cg.connected_components(g, directed=False)
    fcomp = lab[F[:, 0]]
    comps = []
    for ci in np.unique(fcomp):
        m = fcomp == ci
        vs = np.unique(F[m]); vv = P[vs]
        comps.append(dict(id=int(ci), faces=np.where(m)[0], verts=vs, bmin=vv.min(0), bmax=vv.max(0), cen=vv.mean(0)))
    # ---- classification (model coords: x lateral (right hand = -x), y up, z front)
    for c in comps:
        mn, mx, ce = c['bmin'], c['bmax'], c['cen']
        zext = mx[2] - mn[2]; h = mx[1] - mn[1]
        side = 1 if ce[0] < 0 else -1         # +1 = right (game +z)
        c['side'] = side
        flat = zext < 0.1 and h > 0.3
        back = ce[2] < -0.05 and h > 0.25
        if flat or back: c['bone'] = 'sway'
        elif mn[1] < 0.6 and abs(ce[0]) > 0.0 and ce[1] < 0.95 and mx[1] > 0.1 and (mx[1] - mn[1] > 0.05) and not (mn[1] > 0.75):
            c['bone'] = 'shin' if ce[1] < 0.3 else 'thigh'
        elif abs(ce[0]) >= 0.09 and 0.75 <= ce[1] <= 1.45 and mn[1] >= 0.75: c['bone'] = 'arm'
        else: c['bone'] = 'root'
    k_ = HEIGHT[name] / (V0[:, 1].max())
    def G(p): p = np.atleast_2d(p); return np.stack([p[:, 2], p[:, 1], -p[:, 0]], 1) * k_
    rig = {}
    legs = [c for c in comps if c['bone'] in ('thigh', 'shin')]
    hipY = max(c['bmax'][1] for c in legs if c['bone'] == 'thigh') - 0.05
    kneeY = max(c['bmax'][1] for c in legs if c['bone'] == 'shin')
    rig['hipY'] = hipY * k_; rig['kneeY'] = kneeY * k_
    for s, nm in ((1, 'R'), (-1, 'L')):
        th = [c for c in legs if c['side'] == s and c['bone'] == 'thigh']
        rig['hip' + nm] = float(np.mean([c['cen'][0] for c in th]) * -k_) if th else s * 4.0   # game z
        arms = [c for c in comps if c['bone'] == 'arm' and c['side'] == s]
        top = max(arms, key=lambda c: c['cen'][1]); low = min(arms, key=lambda c: c['cen'][1])
        sh = G(top['cen'])[0]; hd = G(low['cen'])[0]
        rig['sh' + nm] = [float(x) for x in sh]; rig['hand' + nm] = [float(x) for x in hd]
    # sway comps
    sway = [c for c in comps if c['bone'] == 'sway']
    BONE = {'root': 0, 'arm': 1, 'thigh': 3, 'shin': 5}
    # palette
    km = KMeans(NPAL, n_init=3, random_state=1).fit(col)
    pal = np.clip(km.cluster_centers_, 0, 255).astype(int)
    fpal = km.labels_
    # decimation per comp for the 3 LODs
    vlist = []            # global vertex array (game local)
    vbone = []; vw = []
    lod_faces = [[], [], []]; lod_col = [[], [], []]
    swinfo = []
    for c in comps:
        vs = c['verts']; remap = {int(v): i for i, v in enumerate(vs)}
        base = len(vlist)
        pts = G(P[vs])
        bn = BONE.get(c['bone'], 0)
        if c['bone'] in ('arm', 'thigh', 'shin'): bn = BONE[c['bone']] + (0 if c['side'] == 1 else 1)
        if c['bone'] == 'sway':
            bn = 7 + len(swinfo)
            top = c['bmax'][1]; hh = max(0.05, c['bmax'][1] - c['bmin'][1])
            piv = G(np.array([c['cen'][0], top, c['cen'][2]]))[0]
            swinfo.append([float(x) for x in piv] + [float(hh * k_)])
            w = (top - P[vs][:, 1]) / hh
            vw.extend(np.clip(w, 0, 1) ** 1.2 * 255)
        else: vw.extend([0] * len(vs))
        vlist.extend(pts.tolist()); vbone.extend([bn] * len(vs))
        lf = np.array([[remap[int(x)] for x in F[i]] for i in c['faces']])
        cur = list(range(len(lf)))
        curF = [tuple(f) for f in lf]
        n0 = len(lf)
        zext = c['bmax'][2] - c['bmin'][2]
        ds = 1 if (c['bone'] == 'sway' and (zext < 0.1)) else 0
        for li, fr in enumerate(LODFR):
            tgt = max(6, int(round(n0 * fr)))
            if len(cur) > tgt and n0 > 12:
                keepidx, newF = qem_decimate(pts, np.array([curF[i] for i in cur]) if False else np.array([curF[i] for i in cur]), tgt)
                cur2 = [cur[i] for i in keepidx]
                curF2 = list(curF)
                for ii, i in enumerate(cur): curF2[i] = tuple(newF[ii])
                cur = cur2; curF = curF2
            for i in cur:
                f = curF[i]
                lod_faces[li].append([f[0] + base, f[1] + base, f[2] + base])
                lod_col[li].append(int(fpal[c['faces'][i]]) | (128 if ds else 0))
    V = np.array(vlist)
    out = dict(k=k_, nv=len(V))
    out['V'] = base64.b64encode(np.round(V * 64).astype('<i2').tobytes()).decode()
    out['B'] = base64.b64encode(np.array(vbone, dtype='u1').tobytes()).decode()
    out['W'] = base64.b64encode(np.round(np.array(vw)).astype('u1').tobytes()).decode()
    out['F'] = [base64.b64encode(np.array(f, dtype='<u2').tobytes()).decode() for f in lod_faces]
    out['K'] = [base64.b64encode(np.array(c_, dtype='u1').tobytes()).decode() for c_ in lod_col]
    out['nf'] = [len(f) for f in lod_faces]
    out['P'] = ''.join('%02x%02x%02x' % tuple(p) for p in pal)
    out['rig'] = rig; out['sw'] = swinfo
    dbg = [(c['id'], c['bone'], c['side'], len(c['faces'])) for c in comps]
    return out, comps, P, F, fpal, pal, dbg

if __name__ == '__main__':
    mdir, outp = sys.argv[1], sys.argv[2]
    res = {}
    for n in ['Eryon', 'Lunea', 'Kael']:
        o, comps, P, F, fpal, pal, dbg = build(n, mdir)
        res[n.lower()] = o
        print(n, 'verts', o['nv'], 'faces/LOD', o['nf'], 'bytes', len(json.dumps(o)))
        print('  rig', json.dumps(o['rig']))
        print('  bones:', {b: sum(1 for d in dbg if d[1] == b) for b in set(d[1] for d in dbg)}, 'sway', len(o['sw']))
    open(outp, 'w').write('window.HMDL=' + json.dumps(res, separators=(',', ':')) + ';')
    print('written', outp)
