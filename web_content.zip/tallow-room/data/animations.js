/* animations.js — ANIMATION MANIFEST (rig-driven, procedural).
   Every clip is data: id, duration, loop, priority, interruptibility, keyframes over rig parameters,
   animation events and sound events. There are no sprite sheets in this build: hands, Dealer and weapon are
   vector rigs drawn on canvas (see art.js), so "asset" is the rig name and frame fields are not applicable.
   Coordinates: x is relative to the screen centre line, y is absolute in a 720-unit-high logical space.
   Hand params (prefix l/r): x y r(otation) c(url) i(ndex curl) t(humb curl) s(cale).
   Item params: io (open) il (flame/lit) ic (charge/ember) irot (spin) isc (scale).                       */
(function (G) {
  'use strict';
  const D = G.GameData;
  const AD = {};

  /* ------------------------------------------------------------------ rig defaults */
  const handDefaults = (lx, ly, rx, ry, s, lr, rr, c) => ({
    lx, ly, lr, lc: c, li: c, lt: c, ls: s, rx, ry, rr, rc: c, ri: c, rt: c, rs: s
  });
  const itemDefaults = { io: 0, il: 0, ic: 0, irot: 0, isc: 1 };
  AD.defaults = {
    player: Object.assign(handDefaults(-250, 652, 250, 652, 1, 0.14, -0.14, 0.3), { trem: 0, tap: 0, brt: 1 }, itemDefaults),
    dealer: Object.assign(handDefaults(-170, 470, 170, 470, 0.8, -0.2, 0.2, 0.4), {
      trem: 0, tap: 0, brt: 1, lean: 0, leanX: 0, shr: 0, hx: 0, hy: 0, hr: 0, lookX: 0, lookY: 0.15,
      eyeO: 1, bL: 0, bR: 0, mC: 0.35, mO: 0, talk: 0, glitch: 0, shk: 0
    }, itemDefaults),
    gun: { gox: 0, goy: 0, gang: 0, gfore: 1, gsc: 1, gbrk: 0, gkick: 0 }
  };
  const KNOWN = {};
  for (const k of Object.keys(AD.defaults)) for (const p of Object.keys(AD.defaults[k])) KNOWN[p] = 1;

  /* ------------------------------------------------------------------ builders */
  const K = (t, p, e) => ({ t, p, e });
  function H(side, o) {
    const r = {};
    if (o.i === undefined && o.c !== undefined) o = Object.assign({}, o, { i: o.c });
    for (const k of ['x', 'y', 'r', 'c', 'i', 't', 's']) if (o[k] !== undefined) r[side + k] = o[k];
    return r;
  }
  const L = (o) => H('l', o), R = (o) => H('r', o);
  const HB = (l, r, extra) => Object.assign({}, L(l), R(r), extra || {});
  const clips = {};
  /* C(id, actor, dur, opts, keys, ev, sfx) */
  function C(id, actor, dur, opts, keys, ev, sfx) {
    clips[id] = {
      id, actor, dur, loop: !!opts.loop, pri: opts.pri === undefined ? 2 : opts.pri,
      interruptible: opts.int === undefined ? !!opts.loop : opts.int,
      rig: opts.rig || (actor + ' rig'), states: opts.states || ['any'], after: opts.after || null,
      keys, events: (ev || []).map((e) => ({ t: e[0], name: e[1] })), sfx: (sfx || []).map((s) => ({ t: s[0], name: s[1], vol: s[2] === undefined ? 1 : s[2] }))
    };
  }

  /* ------------------------------------------------------------------ PLAYER HANDS (28 required states) */
  const PL = { x: -250, y: 652, r: 0.14, c: 0.3, i: 0.25, t: 0.3, s: 1 };
  const PRr = { x: 250, y: 652, r: -0.14, c: 0.3, i: 0.25, t: 0.3, s: 1 };
  const P_REST = HB(PL, PRr, { brt: 1, tap: 0, trem: 0 });
  const P_CLEAN = { io: 0, il: 0, ic: 0, irot: 0, isc: 1 };
  C('hand_idle', 'player', 3.2, { loop: true, pri: 0 }, [K(0.7, P_REST, 'inout'), K(3.2, { brt: 1 })]);
  C('hand_breathe', 'player', 3.6, { loop: true, pri: 0 }, [K(0.8, HB(Object.assign({}, PL, { y: 644 }), Object.assign({}, PRr, { y: 644 }), { brt: 2.4, tap: 0, trem: 0 }), 'inout'), K(3.6, { brt: 2.4 })]);
  C('hand_fingers', 'player', 3.2, { loop: true, pri: 0 }, [
    K(0.7, R({ c: 0.6, i: 0.1, t: 0.5 }), 'inout'), K(1.5, R({ c: 0.2, i: 0.55, t: 0.2 }), 'inout'),
    K(2.3, Object.assign(R({ c: 0.35, i: 0.3, t: 0.3 }), L({ c: 0.65, i: 0.2, t: 0.5 })), 'inout'), K(3.2, L({ c: 0.3, i: 0.25, t: 0.3 }), 'inout')], [], [[1.0, 'cloth', 0.25]]);
  C('hand_tap', 'player', 1.6, { loop: true, pri: 0 }, [
    K(0.4, Object.assign(R({ x: 215, y: 640, c: 0.25, i: 0.2, t: 0.3 }), { tap: 1, trem: 0 }), 'inout'), K(1.6, { tap: 1 })], [], [[0.55, 'table_tap', 0.28], [1.0, 'table_tap', 0.28], [1.45, 'table_tap', 0.28]]);
  C('hand_look_table', 'player', 1.7, { pri: 1, int: true }, [
    K(0.5, HB({ x: -205, y: 625, r: 0.2, c: 0.15, t: 0.1, s: 1.02 }, { x: 125, y: 600, r: -0.5, c: 0.92, i: 0.0, t: 0.6, s: 1.04 })),
    K(1.2, { rr: -0.55 }, 'inout'), K(1.7, P_REST, 'inout')], [[0.7, 'gesture_table']], [[0.15, 'cloth', 0.3]]);
  C('hand_reach', 'player', 0.55, { pri: 2 }, [K(0.5, R({ x: 60, y: 540, r: -0.1, c: 0.05, i: 0.05, t: 0.1, s: 1.05 }), 'out')], [[0.5, 'reach_done']], [[0.1, 'cloth', 0.5]]);
  C('hand_grab', 'player', 0.3, { pri: 2 }, [K(0.28, R({ c: 0.92, i: 0.92, t: 0.8 }), 'in')], [[0.2, 'grabbed']], [[0.15, 'pickup', 0.8]]);
  C('hand_hold', 'player', 0.5, { pri: 2 }, [K(0.5, HB({ x: -190, y: 620, r: 0.2, c: 0.3, s: 1 }, { x: 95, y: 470, r: -0.15, c: 0.82, i: 0.82, t: 0.7, s: 1.15 }), 'inout')]);
  C('hand_inspect', 'player', 1.5, { pri: 2 }, [K(0.5, Object.assign(R({ x: 50, y: 420, r: 0.5, s: 1.3 }), { irot: 0.7 }), 'inout'), K(1.05, Object.assign(R({ x: 75, r: -0.4 }), { irot: -0.5 }), 'inout'), K(1.5, Object.assign(R({ x: 95, y: 470, r: -0.15, s: 1.15 }), { irot: 0 }), 'inout')], [[0.5, 'inspect_started'], [1.3, 'inspect_finished']], [[0.2, 'cloth', 0.3]]);
  C('hand_rotate', 'player', 1.0, { pri: 2 }, [K(0.15, R({ x: 60, y: 450, s: 1.25 }), 'out'), K(1.0, { irot: 6.2832 }, 'inout')], [], [[0.2, 'cloth', 0.3]]);
  C('hand_use', 'player', 0.9, { pri: 2 }, [K(0.3, R({ y: 450, s: 1.22 }), 'out'), K(0.9, R({ y: 470, s: 1.15 }), 'inout')], [[0.3, 'use_apply']], [[0.3, 'cloth', 0.4]]);
  C('hand_putdown', 'player', 0.75, { pri: 2 }, [K(0.45, R({ x: 150, y: 585, r: -0.2, c: 0.8, s: 1.05 }), 'inout'), K(0.75, R({ c: 0.1, i: 0.1, t: 0.1 }), 'out')], [[0.45, 'released']], [[0.45, 'place', 0.8]]);
  C('hand_drop', 'player', 0.55, { pri: 3 }, [K(0.2, R({ x: 130, y: 560, c: 0, i: 0, t: 0 }), 'in'), K(0.55, R({ y: 600, c: 0.2 }), 'out')], [[0.2, 'released']], [[0.3, 'bounce_small', 0.8]]);
  C('hand_reach_weapon', 'player', 0.65, { pri: 2 }, [K(0.6, Object.assign(R({ x: -34, y: 538, r: -0.2, c: 0.1, i: 0.1, t: 0.1, s: 1.05 }), L({ x: -250, y: 645, r: 0.14, c: 0.3 })), 'out')], [[0.6, 'reach_done']], [[0.1, 'cloth', 0.5]]);
  C('hand_hold_weapon', 'player', 0.5, { pri: 2 }, [K(0.45, HB({ x: -120, y: 565, r: 0.5, c: 0.8, i: 0.8, t: 0.7, s: 1.06 }, { x: -20, y: 532, r: -0.1, c: 0.95, i: 0.9, t: 0.9, s: 1.08 }), 'inout')], [[0.4, 'weapon_held']], [[0.2, 'gun_pickup', 0.9]]);
  C('hand_raise_weapon', 'player', 0.8, { pri: 2 }, [K(0.75, HB({ x: -35, y: 455, r: 0.3, c: 0.85, i: 0.85, t: 0.7, s: 1.1 }, { x: 70, y: 478, r: -0.1, c: 0.95, i: 0.9, t: 0.9, s: 1.12 }), 'inout')], [[0.7, 'weapon_raised']], [[0.1, 'cloth', 0.6]]);
  C('hand_lower_weapon', 'player', 0.7, { pri: 2 }, [K(0.65, HB({ x: -120, y: 565, r: 0.5, c: 0.8, s: 1.06 }, { x: -20, y: 532, r: -0.1, c: 0.95, i: 0.9, s: 1.08 }), 'inout')], [[0.65, 'weapon_lowered']], [[0.1, 'cloth', 0.6]]);
  C('hand_inspect_weapon', 'player', 1.7, { pri: 2 }, [K(0.5, HB({ x: -60, y: 500, r: 0.6, c: 0.85, s: 1.1 }, { x: 40, y: 500, r: 0.1, c: 0.95, s: 1.12 }), 'inout'), K(1.1, HB({ x: -20, y: 470, r: 0.2 }, { x: 70, y: 455, r: -0.3 }), 'inout'), K(1.7, HB({ x: -120, y: 565, r: 0.5, c: 0.8, s: 1.06 }, { x: -20, y: 532, r: -0.1, c: 0.95, s: 1.08 }), 'inout')], [[0.5, 'inspect_started'], [1.6, 'inspect_finished']], [[0.8, 'metal_clink', 0.5]]);
  C('hand_fire', 'player', 0.12, { pri: 3, int: false }, [K(0.1, R({ x: 72, y: 470, r: -0.05, c: 1, i: 1, t: 1 }), 'in')], [[0.08, 'trigger']]);
  C('hand_recoil', 'player', 0.3, { pri: 3 }, [K(0.12, HB({ x: -40, y: 500, r: 0.5, s: 1.2 }, { x: 62, y: 525, r: 0.4, s: 1.2 }), 'out'), K(0.3, { rc: 0.9 }, 'inout')], [[0.12, 'recoil_peak']]);
  C('hand_recover', 'player', 0.7, { pri: 2 }, [K(0.65, HB({ x: -35, y: 455, r: 0.3, c: 0.85, s: 1.1 }, { x: 70, y: 478, r: -0.1, c: 0.95, s: 1.12 }), 'inout')], [[0.65, 'recovered']]);
  C('hand_tremble', 'player', 1.6, { loop: true, pri: 1 }, [K(0.35, { trem: 1 }, 'inout'), K(1.6, { trem: 1.2 }, 'inout')]);
  C('hand_hesitate', 'player', 1.1, { pri: 3, int: true }, [K(0.5, HB({ x: -45, y: 480, r: 0.35 }, { x: 62, y: 506, r: -0.05 }, { trem: 1.3 }), 'inout'), K(1.1, HB({ x: -35, y: 455, r: 0.3 }, { x: 70, y: 478, r: -0.1 }, { trem: 1 }), 'inout')], [], [[0.1, 'cloth', 0.4]]);
  C('hand_startle', 'player', 0.65, { pri: 3 }, [K(0.12, HB({ x: -205, y: 555, r: 0.3, c: 0.9, s: 1.12 }, { x: 205, y: 555, r: -0.3, c: 0.9, s: 1.12 }, { trem: 1.4 }), 'out'), K(0.65, HB({ x: -235, y: 625, r: 0.15, c: 0.5, s: 1 }, { x: 235, y: 625, r: -0.15, c: 0.5, s: 1 }, { trem: 0.6 }), 'inout')], [[0.12, 'startled']], [[0.05, 'cloth', 0.8]]);
  C('hand_frustrate', 'player', 1.4, { pri: 3 }, [K(0.3, HB({ x: -220, y: 610, c: 1 }, { x: 220, y: 610, c: 1 }), 'in'), K(0.55, HB({ y: 590 }, { y: 590 }), 'in'), K(0.7, HB({ y: 628 }, { y: 628 }), 'in'), K(1.4, HB({ x: -240, y: 645, c: 0.55 }, { x: 240, y: 645, c: 0.55 }), 'inout')], [[0.7, 'slam']], [[0.7, 'table_thud', 0.9], [0.1, 'cloth', 0.5]]);
  C('hand_victory', 'player', 1.7, { pri: 3 }, [K(0.8, HB({ x: -175, y: 440, r: -0.3, c: 0.0, s: 1.1 }, { x: 175, y: 440, r: 0.3, c: 0.0, s: 1.1 }), 'out'), K(1.1, HB({ c: 0.95 }, { c: 0.95 }), 'in'), K(1.7, HB({ y: 460 }, { y: 460 }), 'inout')], [[1.1, 'victory']], [[0.1, 'cloth', 0.7]]);
  C('hand_defeat', 'player', 1.9, { pri: 3 }, [K(1.2, HB({ x: -232, y: 712, r: 0.4, c: 0.1, s: 1 }, { x: 232, y: 712, r: -0.4, c: 0.1, s: 1 }, { trem: 0 }), 'inout'), K(1.9, { brt: 0.4 }, 'inout')], [[1.15, 'defeat']], [[1.15, 'table_thud', 0.7]]);
  C('hand_rest', 'player', 0.8, { pri: 2, int: true }, [K(0.75, Object.assign({}, P_REST, P_CLEAN), 'inout')], [[0.75, 'at_rest']], [[0.1, 'cloth', 0.25]]);

  /* ------------------------------------------------------------------ DEALER */
  const D_REST_L = { x: -170, y: 470, r: -0.2, c: 0.4, i: 0.4, t: 0.3, s: 0.8 };
  const D_REST_R = { x: 170, y: 470, r: 0.2, c: 0.4, i: 0.4, t: 0.3, s: 0.8 };
  const D_BODY0 = { lean: 0, leanX: 0, shr: 0, hx: 0, hy: 0, hr: 0, lookX: 0, lookY: 0.15, shk: 0, glitch: 0, talk: 0, trem: 0, tap: 0, brt: 1 };
  const D_REST = Object.assign(HB(D_REST_L, D_REST_R), D_BODY0);
  const FACE = {
    stare: { eyeO: 1.1, bL: 0, bR: 0, mC: 0.0, mO: 0 },
    smile: { eyeO: 0.85, bL: -0.3, bR: -0.3, mC: 1, mO: 0.12 },
    confusion: { eyeO: 1.05, bL: 0.5, bR: -0.4, mC: -0.15, mO: 0.05 },
    amusement: { eyeO: 0.8, bL: -0.4, bR: -0.4, mC: 1, mO: 0.4 },
    frustration: { eyeO: 0.8, bL: 0.6, bR: 0.6, mC: -0.5, mO: 0.15 },
    anger: { eyeO: 0.65, bL: 1, bR: 1, mC: -0.9, mO: 0.55 },
    surprise: { eyeO: 1.4, bL: -0.6, bR: -0.6, mC: 0, mO: 0.8 },
    suspicion: { eyeO: 0.55, bL: 0.55, bR: -0.1, mC: 0.1, mO: 0 },
    disappointment: { eyeO: 0.9, bL: -0.5, bR: -0.5, mC: -0.7, mO: 0 },
    victory: { eyeO: 1.2, bL: -0.5, bR: -0.5, mC: 1, mO: 0.7 },
    defeat: { eyeO: 1.3, bL: -0.8, bR: -0.8, mC: -1, mO: 0.6 },
    neutral: { eyeO: 1, bL: 0, bR: 0, mC: 0.35, mO: 0 }
  };
  AD.faces = FACE;
  for (const n of Object.keys(FACE)) C('face_' + n, 'dealer', 0.45, { pri: 1, int: true }, [K(0.4, FACE[n], 'inout')]);

  C('d_idle', 'dealer', 4, { loop: true, pri: 0 }, [K(0.9, D_REST, 'inout'), K(4, { brt: 1 })]);
  C('d_breathe', 'dealer', 3.4, { loop: true, pri: 0 }, [K(1.7, { shr: 0.6, brt: 1.8 }, 'inout'), K(3.4, { shr: 0, brt: 1.8 }, 'inout')]);
  C('d_shoulder', 'dealer', 1.7, { pri: 1, int: true }, [K(0.6, { shr: 1.2, hr: 0.04 }, 'out'), K(1.7, { shr: 0, hr: 0 }, 'inout')], [], [[0.1, 'cloth', 0.25]]);
  C('d_tilt', 'dealer', 2.4, { pri: 1, int: true }, [K(0.9, { hr: 0.16, hx: 5 }, 'inout'), K(1.5, { hr: -0.08, hx: -3 }, 'inout'), K(2.4, { hr: 0, hx: 0 }, 'inout')], [], [[0.3, 'creak', 0.18]]);
  C('d_look_player', 'dealer', 0.7, { pri: 1, int: true }, [K(0.6, { lookX: 0, lookY: 0.4, hy: 0, hr: 0 }, 'inout')]);
  C('d_look_table', 'dealer', 0.8, { pri: 1, int: true }, [K(0.7, { lookY: -0.9, hy: 8, hr: 0.03 }, 'inout')]);
  C('d_tap', 'dealer', 1.4, { loop: true, pri: 0 }, [K(0.4, Object.assign(R({ x: 170, y: 470, r: 0.2, c: 0.3, i: 0.3, t: 0.3, s: 0.8 }), { tap: 1 }), 'inout'), K(1.4, { tap: 1 })], [], [[0.45, 'table_tap', 0.2], [0.85, 'table_tap', 0.2], [1.25, 'table_tap', 0.2]]);
  C('d_rest_hands', 'dealer', 0.9, { pri: 1, int: true }, [K(0.8, Object.assign(HB(D_REST_L, D_REST_R), { tap: 0, trem: 0 }), 'inout')]);
  C('d_lean_fwd', 'dealer', 1.3, { pri: 1, int: true }, [K(1.1, { lean: 42, lookY: 0.4, hy: 0 }, 'inout')], [], [[0.2, 'cloth', 0.3], [0.5, 'creak', 0.25]]);
  C('d_lean_back', 'dealer', 1.3, { pri: 1, int: true }, [K(1.1, { lean: -22, lookY: 0.3 }, 'inout')], [], [[0.2, 'cloth', 0.3]]);
  C('d_twitch', 'dealer', 0.55, { pri: 1, int: true }, [K(0.08, { hr: 0.24, hx: 9 }, 'out'), K(0.3, { hr: 0.24, hx: 9 }), K(0.55, { hr: 0, hx: 0 }, 'inout')], [], [[0.05, 'creak', 0.3]]);
  C('d_still', 'dealer', 3.6, { pri: 1, int: true }, [K(0.5, Object.assign({ brt: 0.15, tap: 0, lookY: 0.32, shk: 0 }, FACE.stare), 'inout'), K(3.6, { brt: 0.15 })]);
  C('d_speak', 'dealer', 1.4, { pri: 1, int: true }, [K(0.1, { talk: 1 }, 'out'), K(1.3, { talk: 1 }), K(1.4, { talk: 0 }, 'inout')]);
  clips.d_speak.voice = true;
  C('d_whisper', 'dealer', 1.8, { pri: 1, int: true }, [K(0.3, { lean: 22, talk: 0.45, hy: 6, lookY: 0.2 }, 'inout'), K(1.5, { talk: 0.45 }), K(1.8, { lean: 0, talk: 0, hy: 0 }, 'inout')]);
  C('d_laugh', 'dealer', 2.1, { pri: 3, int: true }, [K(0.2, { shk: 1, mO: 1, mC: 1, hr: -0.14, hy: -12, eyeO: 0.7 }, 'out'), K(1.7, { shk: 1 }), K(2.1, { shk: 0, mO: 0.15, hr: 0, hy: 0, eyeO: 0.9 }, 'inout')], [[0.2, 'laugh_start']]);
  C('d_gesture', 'dealer', 1.5, { pri: 2, int: true }, [K(0.5, HB({ x: -95, y: 400, r: 0.3, c: 0, t: 0, s: 0.9 }, { x: 95, y: 400, r: -0.3, c: 0, t: 0, s: 0.9 }), 'out'), K(1.5, HB(D_REST_L, D_REST_R), 'inout')], [], [[0.1, 'cloth', 0.3]]);
  C('d_taunt', 'dealer', 1.9, { pri: 2, int: true }, [K(0.4, Object.assign(R({ x: 125, y: 385, r: 0, c: 0.95, i: 0, t: 0.7, s: 0.95 }), { hy: -4 }), 'out'), K(0.7, { rr: 0.35 }, 'inout'), K(1.0, { rr: -0.35 }, 'inout'), K(1.3, { rr: 0.3 }, 'inout'), K(1.9, Object.assign(HB(D_REST_L, D_REST_R), { hy: 0 }), 'inout')], [], [[0.15, 'cloth', 0.3]]);
  C('d_point', 'dealer', 1.4, { pri: 2, int: true }, [K(0.45, Object.assign(R({ x: 65, y: 505, r: -0.1, c: 0.95, i: 0, t: 0.8, s: 1.25 }), { lean: 20, lookY: 0.4 }), 'out'), K(1.0, { rr: -0.05 }), K(1.4, Object.assign(HB(D_REST_L, D_REST_R), { lean: 0 }), 'inout')], [], [[0.1, 'cloth', 0.3]]);
  C('d_shake_head', 'dealer', 1.3, { pri: 1, int: true }, [K(0.15, { hx: 14, hr: 0.06 }, 'out'), K(0.4, { hx: -14, hr: -0.06 }, 'inout'), K(0.65, { hx: 10, hr: 0.04 }, 'inout'), K(0.9, { hx: -8, hr: -0.04 }, 'inout'), K(1.3, { hx: 0, hr: 0 }, 'inout')]);
  C('d_look_away', 'dealer', 1.1, { pri: 1, int: true }, [K(0.9, { lookX: 1, hr: 0.08, hx: 12, lookY: 0 }, 'inout')]);
  C('d_look_direct', 'dealer', 0.8, { pri: 1, int: true }, [K(0.7, { lookX: 0, lookY: 0.4, hx: 0, hr: 0, hy: 0 }, 'inout')]);
  C('d_reach', 'dealer', 0.75, { pri: 2 }, [K(0.7, Object.assign(R({ x: 0, y: 470, c: 0.05, i: 0.05, t: 0.1, s: 0.9 }), { lean: 14, lookY: -0.4 }), 'inout')], [[0.7, 'reach_done']], [[0.1, 'cloth', 0.4]]);
  C('d_pickup', 'dealer', 0.4, { pri: 2 }, [K(0.35, R({ c: 0.92, i: 0.92, t: 0.8 }), 'in')], [[0.25, 'grabbed']], [[0.2, 'pickup', 0.8]]);
  C('d_hold', 'dealer', 0.6, { pri: 2 }, [K(0.55, Object.assign(R({ x: 70, y: 340, r: -0.3, c: 0.85, i: 0.85, t: 0.75, s: 0.95 }), { lean: 0, lookY: 0.2 }), 'inout')]);
  C('d_inspect_item', 'dealer', 1.5, { pri: 2 }, [K(0.6, Object.assign(R({ x: 55, y: 320, r: -0.8 }), { irot: 0.8, eyeO: 0.7, bL: 0.5, bR: 0.2 }), 'inout'), K(1.1, Object.assign(R({ x: 70, y: 335, r: 0.2 }), { irot: -0.4 }), 'inout'), K(1.5, Object.assign(R({ r: -0.3 }), { irot: 0, eyeO: 1, bL: 0, bR: 0 }), 'inout')], [[0.6, 'inspect_started'], [1.4, 'inspect_finished']], [[0.3, 'cloth', 0.25]]);
  C('d_use_item', 'dealer', 0.9, { pri: 2 }, [K(0.3, R({ y: 322, s: 1.02 }), 'out'), K(0.9, R({ y: 338, s: 0.95 }), 'inout')], [[0.3, 'use_apply']], [[0.3, 'cloth', 0.3]]);
  C('d_putdown', 'dealer', 0.8, { pri: 2 }, [K(0.5, R({ x: 80, y: 430, r: 0, c: 0.8, s: 0.85 }), 'inout'), K(0.8, R({ c: 0.1, i: 0.1, t: 0.1 }), 'out')], [[0.5, 'released']], [[0.5, 'place', 0.7]]);
  C('d_table_interact', 'dealer', 1.1, { pri: 2, int: true }, [K(0.35, R({ x: 175, y: 415, r: 0.1, c: 0.9, i: 0.9, t: 0.5, s: 0.85 }), 'out'), K(0.5, R({ y: 450 }), 'in'), K(0.62, R({ y: 418 }), 'out'), K(0.75, R({ y: 452 }), 'in'), K(1.1, HB(D_REST_L, D_REST_R), 'inout')], [[0.5, 'knock']], [[0.5, 'table_tap', 0.5], [0.75, 'table_tap', 0.5]]);
  C('d_handle_gun', 'dealer', 1.0, { pri: 2 }, [K(0.9, Object.assign(HB({ x: -95, y: 505, r: -0.3, c: 0.8, s: 0.95 }, { x: -12, y: 490, r: 0.2, c: 0.95, i: 0.9, t: 0.9, s: 0.98 }), { lean: 16, lookY: -0.3 }), 'inout')], [[0.85, 'weapon_held']], [[0.55, 'gun_pickup', 0.9]]);
  C('d_round_transition', 'dealer', 2.2, { pri: 2, int: true }, [K(1.0, Object.assign(HB({ x: -60, y: 420, r: 0.4, c: 0.5 }, { x: 60, y: 420, r: -0.4, c: 0.5 }), { lean: -18, lookY: 0.3 }), 'inout'), K(1.7, FACE.disappointment, 'inout'), K(2.2, Object.assign(HB(D_REST_L, D_REST_R), { lean: 0 }, FACE.neutral), 'inout')], [], [[0.2, 'whoosh', 0.35]]);
  C('d_unexpected_laugh', 'dealer', 1.4, { pri: 3, int: true }, [K(0.1, { shk: 0.8, mO: 0.8, mC: 1, hr: -0.1, eyeO: 0.75 }, 'out'), K(1.0, { shk: 0.8 }), K(1.4, { shk: 0, mO: 0.1, hr: 0, eyeO: 1 }, 'inout')], [[0.1, 'laugh_start']]);
  C('d_sudden_head', 'dealer', 0.5, { pri: 1, int: true }, [K(0.07, { hx: 18, hy: -6, hr: 0.18, lookX: -0.8 }, 'out'), K(0.3, { hx: 18, hy: -6, hr: 0.18 }), K(0.5, { hx: 0, hy: 0, hr: 0, lookX: 0 }, 'inout')], [], [[0.04, 'creak', 0.35]]);
  C('d_long_stare', 'dealer', 4.0, { pri: 1, int: true }, [K(0.5, Object.assign({ lookX: 0, lookY: 0.42, brt: 0.3, tap: 0, hx: 0, hr: 0 }, FACE.stare, { eyeO: 1.25 }), 'inout'), K(4.0, { brt: 0.3 })]);
  C('d_glitch', 'dealer', 0.9, { pri: 3, int: true }, [K(0.05, { glitch: 1, shk: 0.5 }), K(0.3, { glitch: 0.4 }), K(0.5, { glitch: 1 }), K(0.9, { glitch: 0, shk: 0 }, 'inout')], [[0.05, 'glitch_start']], [[0.05, 'glitch', 0.8]]);
  C('d_rare_idle', 'dealer', 3.4, { pri: 1, int: true }, [K(1.5, { hr: 0.38, hx: 12, mC: 1, mO: 0.1, lookY: 0.4 }, 'inout'), K(2.4, { hr: 0.38 }), K(3.4, { hr: 0, hx: 0, mC: 0.35, mO: 0 }, 'inout')], [], [[0.6, 'creak', 0.3]]);
  C('d_victory', 'dealer', 2.8, { pri: 3 }, [K(0.9, Object.assign(HB({ x: -235, y: 335, r: -0.5, c: 0, s: 1 }, { x: 235, y: 335, r: 0.5, c: 0, s: 1 }), { lean: -10, hr: -0.2, hy: -10 }, FACE.victory), 'out'), K(1.3, { shk: 1 }), K(2.8, { shk: 0 }, 'inout')], [[0.9, 'victory']], [[0.2, 'whoosh', 0.5]]);
  C('d_defeat', 'dealer', 3.2, { pri: 3 }, [K(0.5, { glitch: 0.8, shk: 0.8 }), K(1.2, Object.assign({ glitch: 0, shk: 0, lean: 34, hy: 30, hr: 0.3, lookY: -1 }, FACE.defeat), 'inout'), K(2.4, Object.assign(HB({ x: -170, y: 470, r: -0.4, c: 0.1 }, { x: 170, y: 470, r: 0.4, c: 0.1 }), { lean: 60, hy: 50 }), 'inout'), K(3.2, { lean: 64 }, 'inout')], [[0.5, 'defeat']], [[0.5, 'glitch', 0.9], [2.3, 'table_thud', 0.8]]);
  C('d_end', 'dealer', 4.2, { pri: 4 }, [K(2.4, Object.assign({ lean: 95, lookY: 0.45, hy: -10 }, FACE.victory, { eyeO: 1.35 }), 'inout'), K(3.2, { glitch: 0.6 }), K(4.2, { glitch: 0.2 }, 'inout')], [[2.4, 'end_close_up']], [[0.2, 'creak', 0.5]]);
  C('d_hit_react', 'dealer', 0.9, { pri: 3 }, [K(0.1, Object.assign(HB({ x: -160, y: 400, r: -0.5, c: 0.9 }, { x: 160, y: 400, r: 0.5, c: 0.9 }), { hr: -0.32, hy: -22, lean: -30, shk: 1 }, FACE.surprise), 'out'), K(0.9, Object.assign(HB(D_REST_L, D_REST_R), { hr: 0, hy: 0, lean: 0, shk: 0 }, FACE.anger), 'inout')], [[0.1, 'hit_peak']], [[0.1, 'impact_hit', 0.9]]);

  /* ------------------------------------------------------------------ WEAPON ("the Caster") */
  const G0 = { gox: 0, goy: 0, gang: 0, gfore: 1, gsc: 1, gbrk: 0, gkick: 0 };
  C('gun_rest', 'gun', 0.6, { pri: 1, int: true }, [K(0.55, G0, 'inout')]);
  C('gun_table_idle', 'gun', 5, { loop: true, pri: 0 }, [K(2.5, { gang: 0.012, goy: 0.6, gox: 0, gfore: 1, gsc: 1, gbrk: 0, gkick: 0 }, 'inout'), K(5, { gang: -0.008, goy: -0.4 }, 'inout')]);
  C('gun_enter', 'gun', 0.5, { pri: 2 }, [K(0.45, { gox: 10, goy: -6, gang: -0.45, gfore: 0.95, gsc: 1.03 }, 'out')], [[0.45, 'entered']], [[0.1, 'gun_pickup', 0.6]]);
  C('gun_held', 'gun', 0.5, { pri: 2 }, [K(0.45, { gox: 20, goy: -10, gang: -0.55, gfore: 0.85, gsc: 1.05, gbrk: 0, gkick: 0 }, 'inout')]);
  C('gun_idle', 'gun', 2.4, { loop: true, pri: 0 }, [K(1.2, { gang: -0.51, goy: -12 }, 'inout'), K(2.4, { gang: -0.59, goy: -8 }, 'inout')]);
  C('gun_inspect', 'gun', 1.8, { pri: 2 }, [K(0.5, { gang: 0.5, gfore: 0.95, gsc: 1.1 }, 'inout'), K(1.1, { gang: -1.1, gfore: 0.8 }, 'inout'), K(1.8, { gang: -0.55, gfore: 0.85, gsc: 1.05 }, 'inout')], [[1.1, 'chamber_glint']], [[0.5, 'metal_clink', 0.5]]);
  C('gun_raise_dealer', 'gun', 0.8, { pri: 2 }, [K(0.75, { gox: 6, goy: -36, gang: -1.5, gfore: 0.48, gsc: 1.08 }, 'inout')], [[0.7, 'aimed']], [[0.35, 'gun_cock', 0.7]]);
  C('gun_raise_self', 'gun', 0.9, { pri: 2 }, [K(0.85, { gox: -6, goy: -120, gang: 1.52, gfore: 0.14, gsc: 1.7 }, 'inout')], [[0.8, 'aimed']], [[0.4, 'gun_cock', 0.7]]);
  C('gun_lower', 'gun', 0.7, { pri: 2 }, [K(0.65, { gox: 20, goy: -10, gang: -0.55, gfore: 0.85, gsc: 1.05 }, 'inout')]);
  C('gun_dealer_take', 'gun', 0.85, { pri: 2 }, [K(0.8, { gox: 60, goy: -120, gang: 1.0, gfore: 0.7, gsc: 1.0 }, 'inout')], [[0.8, 'weapon_held']], [[0.1, 'gun_pickup', 0.8]]);
  C('gun_dealer_aim_player', 'gun', 0.9, { pri: 2 }, [K(0.85, { gox: 20, goy: -140, gang: 1.5, gfore: 0.16, gsc: 1.5 }, 'inout')], [[0.8, 'aimed']], [[0.4, 'gun_cock', 0.7]]);
  C('gun_dealer_aim_self', 'gun', 0.9, { pri: 2 }, [K(0.85, { gox: 40, goy: -190, gang: -1.5, gfore: 0.3, gsc: 1.1 }, 'inout')], [[0.8, 'aimed']], [[0.4, 'gun_cock', 0.7]]);
  C('gun_fire', 'gun', 0.12, { pri: 3 }, [K(0.1, { gkick: 1 }, 'out')], [[0.02, 'muzzle_flash']]);
  C('gun_recoil', 'gun', 0.35, { pri: 3 }, [K(0.1, { gkick: 1, gang: -0.35 }, 'out'), K(0.35, { gkick: 0, gang: 0 }, 'inout')]);
  C('gun_recover', 'gun', 0.55, { pri: 2 }, [K(0.5, { gkick: 0 }, 'inout')]);
  C('gun_reload', 'gun', 2.2, { pri: 2 }, [K(0.4, { gox: 10, goy: -20, gang: -0.2, gfore: 0.9 }, 'inout'), K(0.7, { gbrk: 1 }, 'out'), K(1.6, { gbrk: 1 }), K(1.95, { gbrk: 0 }, 'in'), K(2.2, { gang: 0, gox: 0, goy: 0, gfore: 1 }, 'inout')], [[0.8, 'load_shell'], [1.05, 'load_shell'], [1.3, 'load_shell']], [[0.65, 'gun_breech_open', 0.8], [0.8, 'gun_load_shell', 0.6], [1.05, 'gun_load_shell', 0.6], [1.3, 'gun_load_shell', 0.6], [1.9, 'gun_breech_close', 0.9]]);
  C('gun_return', 'gun', 0.7, { pri: 2 }, [K(0.6, G0, 'inout')], [[0.6, 'at_rest']]);
  C('gun_victory', 'gun', 0.8, { pri: 2 }, [K(0.7, { gang: -0.9, gox: 0, goy: -20 }, 'inout')]);
  C('gun_defeat', 'gun', 0.8, { pri: 2 }, [K(0.7, { gang: 0.3, goy: 10, gfore: 1 }, 'inout')]);

  AD.clips = clips;

  /* ------------------------------------------------------------------ ITEM SEQUENCES (built per holder) */
  AD.anchors = {
    p: {
      hold: { x: 95, y: 470, s: 1.15, r: -0.15 }, face: { x: 5, y: 400, s: 1.5 }, mouth: { x: 5, y: 686, s: 1.3 },
      gun: { x: -70, y: 505, s: 1.12 }
    },
    d: {
      hold: { x: 70, y: 385, s: 0.95, r: -0.3 }, face: { x: 24, y: 300, s: 1.0 }, mouth: { x: 6, y: 318, s: 0.95 },
      gun: { x: -70, y: 505, s: 0.98 }
    }
  };
  /* Builds the item-specific USE clip. target (optional) = {x,y,s} of an item to burn (lighter). */
  AD.itemUse = function (id, who, target) {
    const A = AD.anchors[who];
    const h = A.hold, f = A.face, m = A.mouth, g = A.gun;
    const hp = (a, o) => R(Object.assign({ x: a.x, y: a.y, s: a.s, r: a.r || 0, c: 0.85, i: 0.85, t: 0.75 }, o || {}));
    const mix = (a, b) => Object.assign({}, a, b);
    let dur = 3, keys = [], ev = [], sfx = [];
    switch (id) {
      case 'magnifier':
        dur = 3.4;
        keys = [K(0.5, mix(hp(h, { r: -0.1 }), { irot: 0 }), 'inout'), K(1.3, mix(hp(f, { r: 0.1 }), { irot: 0.5 }), 'inout'), K(2.4, { irot: -0.35 }, 'inout'), K(2.9, hp(f, { r: 0 }), 'inout'), K(3.4, mix(hp(h), { irot: 0 }), 'inout')];
        ev = [[1.2, 'zoom_on'], [1.5, 'effect'], [2.8, 'zoom_off']]; sfx = [[0.5, 'lens_hum', 0.5], [1.25, 'glass_tink', 0.6]]; break;
      case 'handcuffs':
        dur = 2.6;
        keys = [K(0.4, mix(hp(h, { r: 0.3 }), { irot: 0.2 }), 'inout'), K(0.9, { io: 1 }, 'out'), K(1.6, mix(hp(h, { y: h.y - 14, r: 0.1 }), { io: 0 }), 'in'), K(2.6, hp(h), 'inout')];
        ev = [[1.6, 'effect']]; sfx = [[0.3, 'metal_clink', 0.7], [0.9, 'cuff_open', 0.9], [1.6, 'cuff_close', 1]]; break;
      case 'cigarette':
        dur = 4.4;
        keys = [K(0.6, hp(m, { r: -0.5 }), 'inout'), K(1.2, { il: 1 }, 'out'), K(1.9, { il: 0, ic: 1 }, 'inout'), K(2.6, hp(m, { r: -0.4, y: m.y + (who === 'p' ? 4 : 8) }), 'inout'), K(3.3, hp(m, { r: -0.5 }), 'inout'), K(4.0, mix(hp(h), { ic: 0.6 }), 'inout'), K(4.4, { ic: 0 })];
        ev = [[1.3, 'smoke_light'], [2.0, 'effect'], [2.6, 'smoke'], [3.3, 'smoke']]; sfx = [[0.6, 'cloth', 0.3], [1.15, 'lighter_flick', 0.8], [1.2, 'cig_light', 0.7], [2.6, 'smoke_exhale', 0.8], [3.3, 'smoke_exhale', 0.6]]; break;
      case 'battery':
        dur = 3.2;
        keys = [K(0.5, mix(hp(h, { r: 0.2 }), { irot: 0.8 }), 'inout'), K(1.3, mix(hp(g, { x: g.x + 18, y: g.y - 26, r: 1.35 }), { irot: 0 }), 'inout'), K(1.7, { ic: 1 }, 'in'), K(2.0, { isc: 0.0 }, 'in'), K(2.9, hp(h, { c: 0.3, i: 0.3 }), 'inout')];
        ev = [[1.75, 'insert'], [1.9, 'effect']]; sfx = [[0.4, 'metal_clink', 0.4], [1.7, 'battery_insert', 1], [1.85, 'zap', 0.6]]; break;
      case 'medicine':
        dur = 3.6;
        keys = [K(0.5, mix(hp(h, { r: 0.2 }), { irot: 0.5 }), 'inout'), K(1.1, { io: 1 }, 'out'), K(1.8, { irot: 2.1 }, 'inout'), K(2.4, mix(hp(m, { r: 0.4 }), { irot: 2.2 }), 'inout'), K(2.9, { ic: 1 }, 'out'), K(3.6, mix(hp(h, { c: 0.4 }), { irot: 0, io: 0.6, ic: 0.4 }), 'inout')];
        ev = [[0.6, 'rattle'], [2.6, 'effect']]; sfx = [[0.4, 'pill_rattle', 0.6], [1.1, 'bottle_open', 0.9], [1.8, 'pill_rattle', 0.9], [2.65, 'gulp', 0.7]]; break;
      case 'can':
        dur = 4.0;
        keys = [K(0.5, hp(h, { r: 0.1 }), 'inout'), K(1.1, { irot: 6.283 }, 'inout'), K(1.7, { io: 1 }, 'out'), K(2.6, mix(hp(m, { r: 0.5 }), { irot: 6.283 + 0.45 }), 'inout'), K(3.2, { isc: 0.62 }, 'in'), K(4.0, mix(hp(h, { c: 0.4 }), { irot: 6.283 }), 'inout')];
        ev = [[1.7, 'fizz'], [2.9, 'effect']]; sfx = [[0.4, 'metal_clink', 0.4], [1.7, 'can_open', 1], [2.0, 'can_fizz', 0.6], [2.7, 'gulp', 0.8], [3.2, 'can_crush', 0.9]]; break;
      case 'lighter': {
        const T = target || { x: g.x, y: g.y - 20, s: g.s };
        dur = 4.6;
        keys = [K(0.5, hp(h, { r: 0.1 }), 'inout'), K(1.0, { io: 1 }, 'out'), K(1.5, { il: 1 }, 'out'), K(2.4, hp({ x: T.x, y: T.y + 20, s: T.s * (who === 'p' ? 0.95 : 1) }, { r: 0.05 }), 'inout'), K(3.4, { il: 1 }), K(3.7, { il: 0 }, 'inout'), K(4.0, { io: 0 }, 'in'), K(4.6, hp(h), 'inout')];
        ev = [[1.5, 'flame_on'], [2.5, 'effect'], [3.7, 'flame_off']]; sfx = [[0.3, 'metal_clink', 0.3], [1.0, 'lighter_open', 0.9], [1.5, 'lighter_flick', 1], [1.55, 'flame_whoosh', 0.5], [2.5, 'burn', 0.9], [3.7, 'puff', 0.5], [4.0, 'lighter_close', 0.9]]; break;
      }
      case 'scrambler':
        dur = 3.0;
        keys = [K(0.5, mix(hp(h, { r: 0.1 }), { irot: 0 }), 'inout'), K(1.0, { ic: 1 }, 'out'), K(1.6, { irot: 1.2 }, 'inout'), K(2.0, hp(h, { r: 0.18 }), 'in'), K(2.15, hp(h, { r: -0.14 }), 'in'), K(2.3, hp(h, { r: 0.1 }), 'in'), K(3.0, mix(hp(h), { ic: 0.3 }), 'inout')];
        ev = [[2.05, 'effect']]; sfx = [[0.4, 'cloth', 0.3], [1.0, 'device_beep', 0.8], [1.6, 'device_dial', 0.8], [2.05, 'glitch', 0.8], [2.1, 'zap', 0.5]]; break;
      case 'coin':
        dur = 2.8;
        keys = [K(0.4, hp(h, { r: 0.0, c: 0.5, i: 0.4 }), 'inout'), K(0.85, mix(hp({ x: h.x, y: h.y - 90, s: h.s }, { c: 0.3 }), { irot: 12.566 }), 'out'), K(1.5, mix(hp(h, { c: 0.7 }), { irot: 25.133 }), 'in'), K(2.3, hp(h), 'inout')];
        ev = [[1.55, 'effect']]; sfx = [[0.8, 'coin_flip', 0.9], [1.5, 'coin_catch', 1]]; break;
      case 'knife':
        dur = 2.8;
        keys = [K(0.5, mix(hp(h, { r: 0.2 }), { irot: 0.3 }), 'inout'), K(1.15, mix(hp(h, { y: h.y - 46, r: -0.4 }), { irot: -0.5 }), 'inout'), K(1.5, mix(hp(h, { y: h.y + 34, r: 0.45 }), { irot: 0.9 }), 'in'), K(2.1, mix(hp(h, { r: 0.1 }), { irot: 0.2 }), 'inout'), K(2.8, mix(hp(h), { irot: 0 }), 'inout')];
        ev = [[1.52, 'effect']]; sfx = [[0.4, 'metal_clink', 0.4], [1.4, 'blade_swish', 0.9], [1.55, 'stab', 1]]; break;
      case 'blank':
        dur = 3.0;
        keys = [K(0.5, mix(hp(h, { r: 0.2 }), { irot: 0.6 }), 'inout'), K(1.3, mix(hp(g, { x: g.x + 18, y: g.y - 26, r: 1.35 }), { irot: 0 }), 'inout'), K(1.75, { ic: 1 }, 'in'), K(2.05, { isc: 0.0 }, 'in'), K(2.8, hp(h, { c: 0.3, i: 0.3 }), 'inout'), K(3.0, hp(h, { c: 0.3, i: 0.3 }), 'inout')];
        ev = [[1.9, 'effect']]; sfx = [[0.4, 'metal_clink', 0.4], [1.8, 'blank_click', 1]]; break;
      case 'spray':
        dur = 3.4;
        keys = [K(0.5, mix(hp(h, { r: 0.1 }), { irot: -0.1 }), 'inout'), K(1.1, mix(hp(g, { x: g.x - 30, y: g.y - 70, r: 0.9 }), { irot: 0.4 }), 'inout'), K(1.3, { il: 1 }, 'out'), K(2.4, { il: 1 }), K(2.6, { il: 0 }, 'out'), K(3.4, mix(hp(h), { irot: 0 }), 'inout')];
        ev = [[1.35, 'effect']]; sfx = [[0.4, 'metal_clink', 0.4], [1.3, 'spray_hiss', 0.9]]; break;
      case 'rope':
        dur = 2.6;
        keys = [K(0.5, hp(h, { r: 0.1 }), 'inout'), K(1.1, mix(hp(g, { x: g.x + 40, y: g.y - 30, r: 0.6 }), { irot: 0.4 }), 'out'), K(1.55, mix(hp(h, { r: -0.2 }), { irot: 0 }), 'in'), K(2.6, hp(h), 'inout')];
        ev = [[1.55, 'effect']]; sfx = [[0.4, 'cloth', 0.3], [1.1, 'rope_whip', 0.9]]; break;
      default:
        dur = 1.5; keys = [K(0.5, hp(h), 'inout'), K(1.5, hp(h), 'inout')];
    }
    return {
      id: who + '_use_' + id, actor: who === 'p' ? 'player' : 'dealer', dur, loop: false, pri: 2, interruptible: false, rig: 'item/' + id,
      states: [who === 'p' ? 'playerTurn' : 'dealerTurn'], after: null, keys,
      events: ev.map((e) => ({ t: e[0], name: e[1] })), sfx: sfx.map((s) => ({ t: s[0], name: s[1], vol: s[2] === undefined ? 1 : s[2] }))
    };
  };

  /* helper clip builders used by the director for slot-dependent motion */
  AD.moveHands = function (id, dur, poses, opts) {
    opts = opts || {};
    const p = Object.assign({}, poses.l ? L(poses.l) : {}, poses.r ? R(poses.r) : {}, poses.extra || {});
    return { id, actor: 'dyn', dur, loop: false, pri: opts.pri === undefined ? 2 : opts.pri, interruptible: !!opts.int, keys: [K(dur, p, opts.ease || 'inout')], events: opts.ev || [], sfx: opts.sfx || [], after: null, states: ['any'], rig: 'dynamic' };
  };
  AD.speak = function (dur, whisper) {
    return { id: 'd_speak_dyn', voice: true, actor: 'dealer', dur: dur + 0.2, loop: false, pri: 1, interruptible: true, rig: 'dealer rig', states: ['any'], after: null, events: [], sfx: [],
      keys: [K(0.1, { talk: whisper ? 0.45 : 1 }, 'out'), K(dur + 0.05, { talk: whisper ? 0.45 : 1 }), K(dur + 0.2, { talk: 0 }, 'inout')] };
  };
  AD.K = K; AD.L = L; AD.R = R; AD.HB = HB;

  /* sfx names the director/renderer plays directly (not through clips) — needed for manifest completeness */
  AD.directorSfx = ['ui_click', 'ui_back', 'gun_fire', 'gun_dry', 'heartbeat', 'round_start', 'stinger', 'win_sting', 'lose_sting', 'table_thud', 'whoosh', 'zap', 'device_beep',
    'shell_drop', 'burn', 'smoke_exhale', 'item_land', 'toast', 'shell_reveal', 'creak', 'tick'];

  AD.allSfxRefs = function () {
    const set = new Set(AD.directorSfx);
    const add = (c) => c.sfx.forEach((s) => set.add(s.name));
    Object.values(clips).forEach(add);
    for (const id of D.itemOrder) for (const who of ['p', 'd']) add(AD.itemUse(id, who));
    return Array.from(set);
  };

  const EASES = ['lin', 'in', 'out', 'inout', 'back', 'snap', 'cubic', undefined];
  AD.validate = function () {
    const errors = []; let sfxN = 0, evN = 0, count = 0;
    const all = Object.values(clips);
    for (const id of D.itemOrder) for (const who of ['p', 'd']) all.push(AD.itemUse(id, who));
    for (const c of all) {
      count++;
      const tag = c.id;
      if (!(c.dur > 0 && c.dur <= 20)) errors.push(tag + ': bad duration');
      if (!Number.isInteger(c.pri) || c.pri < 0 || c.pri > 4) errors.push(tag + ': bad priority');
      if (!c.keys || !c.keys.length) errors.push(tag + ': no keys');
      let last = -1;
      for (const k of c.keys || []) {
        if (!(k.t >= 0.05 && k.t <= c.dur + 1e-6)) errors.push(tag + ': key time ' + k.t + ' outside (0.05..dur) — a key at t=0 would snap');
        if (k.t < last) errors.push(tag + ': keys not sorted');
        last = k.t;
        if (!EASES.includes(k.e)) errors.push(tag + ': unknown ease ' + k.e);
        for (const p of Object.keys(k.p)) {
          if (!KNOWN[p]) errors.push(tag + ': unknown rig param ' + p);
          if (typeof k.p[p] !== 'number' || !isFinite(k.p[p])) errors.push(tag + ': non-numeric ' + p);
        }
      }
      if (c.loop && c.dur < 0.5) errors.push(tag + ': loop too short');
      for (const e of c.events) { evN++; if (!(e.t >= 0 && e.t <= c.dur)) errors.push(tag + ': event ' + e.name + ' outside clip'); }
      for (const s of c.sfx) { sfxN++; if (!(s.t >= 0 && s.t <= c.dur)) errors.push(tag + ': sfx ' + s.name + ' outside clip'); }
    }
    return { errors, clips: count, sfx: sfxN, events: evN };
  };

  /* data for JSON export */
  AD.exportManifest = function () {
    const out = { version: D.version, note: 'Rig-driven procedural animation manifest. Frame fields are not applicable (no sprite sheets).', defaults: AD.defaults, anchors: AD.anchors, faces: AD.faces, clips: {}, itemUseClips: {} };
    for (const id of Object.keys(clips)) out.clips[id] = clips[id];
    for (const id of D.itemOrder) { out.itemUseClips['p_use_' + id] = AD.itemUse(id, 'p'); out.itemUseClips['d_use_' + id] = AD.itemUse(id, 'd'); }
    return out;
  };

  G.AnimData = AD;
  if (typeof module !== 'undefined' && module.exports) module.exports = AD;
})(typeof window !== 'undefined' ? window : globalThis);
