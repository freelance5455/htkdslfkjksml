/* accessibility.js — text size, reduced motion, language direction, focus trapping for dialogs, screen-reader announcements. */
(function (G) {
  'use strict';
  const Ax = { trap: null };
  Ax.apply = function (s) {
    const h = document.documentElement;
    h.dataset.text = String(s.textSize);
    h.classList.toggle('reduced', !!s.reduced);
    h.lang = s.lang; h.dir = s.lang === 'ar' ? 'rtl' : 'ltr';
  };
  Ax.announce = function (text) {
    let el = document.getElementById('sr-live');
    if (!el) { el = document.createElement('div'); el.id = 'sr-live'; el.setAttribute('aria-live', 'assertive'); el.style.cssText = 'position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);'; document.body.appendChild(el); }
    el.textContent = ''; setTimeout(() => { el.textContent = text; }, 30);
  };
  /* keep keyboard focus inside the topmost open dialog and restore it afterwards */
  Ax.open = function (modal) {
    modal._prev = document.activeElement; Ax.trap = modal;
    const f = modal.querySelector('button:not([disabled]), input'); if (f) setTimeout(() => { try { f.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }, 30);
  };
  Ax.close = function (modal) { if (Ax.trap === modal) Ax.trap = null; try { if (modal._prev && modal._prev.focus) modal._prev.focus({ preventScroll: true }); } catch (e) { /* ignore */ } };
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || !Ax.trap || Ax.trap.classList.contains('hidden')) return;
    const f = Array.from(Ax.trap.querySelectorAll('button:not([disabled]), input')).filter((x) => x.offsetParent !== null);
    if (!f.length) return; const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); }
  });
  G.Access = Ax;
})(typeof window !== 'undefined' ? window : globalThis);
