/* main.js — boot, main loop (requestAnimationFrame + delta time + 30/60 fps cap), settings application,
   lifecycle (visibility/pagehide), global error handling, manifest self-check, debug/test hooks. */
(function (G) {
  'use strict';
  const U = G.U, Save = G.Save, Au = G.AudioMgr, R = G.Renderer, Anim = G.Anim, Show = G.Show, T = G.Turns, UI = G.UI;
  const Main = { last: 0, acc: 0, running: false, errors: [], fpsSamples: [], frameMs: [] };

  Main.applySettings = function (s) {
    T.settings = s; Show.settings = s; U.lang = s.lang;
    Au.applySettings(s); R.applySettings(s); G.Access.apply(s); Anim.reduced = s.reduced;
    if (UI.applyLang) UI.applyLang();
  };

  function fatal(msg) { try { document.getElementById('fatalMsg').textContent = msg; document.getElementById('fatal').classList.remove('hidden'); document.getElementById('loading').classList.add('hidden'); } catch (e) { /* ignore */ } }
  window.addEventListener('error', (e) => { Main.errors.push(String(e.message)); console.error('[error]', e.message); });
  window.addEventListener('unhandledrejection', (e) => { if (e.reason && e.reason.cancelled) { e.preventDefault(); return; } Main.errors.push(String(e.reason)); console.error('[rejection]', e.reason); });

  /* manifest sanity check at boot: refuses to run with a broken animation/audio table, says exactly what is wrong */
  Main.selfCheck = function () {
    const rep = G.AnimData.validate(), missing = G.AnimData.allSfxRefs().filter((n) => !Au.SFX[n]);
    const problems = rep.errors.concat(missing.map((m) => 'missing sfx: ' + m));
    if (problems.length) throw new Error('Asset manifest problems:\n' + problems.slice(0, 12).join('\n'));
    return rep;
  };

  Main.tick = function (now) {
    requestAnimationFrame(Main.tick);
    if (!Main.last) Main.last = now; let dt = (now - Main.last) / 1000;
    const cap = T.settings && T.settings.fps === 30 ? 1 / 30 : 0;
    if (cap && dt < cap - 0.004) return;
    Main.last = now; dt = Math.min(dt, 0.1);
    Main.frameMs.push(dt * 1000); if (Main.frameMs.length > 240) Main.frameMs.shift();
    if (document.hidden) return;
    if (T.paused) { Main.acc += dt; if (Main.acc > 0.1) { Main.acc = 0; R.frame(0); } return; }
    Anim.update(dt); Show.update(dt); Au.update(dt); R.frame(dt); UI.placeSubtitles();
  };

  Main.boot = function () {
    try {
      Main.selfCheck();
      const canvas = document.getElementById('stage');
      T.meta = Save.sanitizeMeta(Save.loadMeta()); T.settings = Save.loadSettings();
      Anim.init(); R.init(canvas); G.Input.init(canvas); UI.init();
      Main.applySettings(T.settings);
      if (G.MenuArt) G.MenuArt.wire(); Show.menuScene(); UI.showMenu();
      if (Save.corruptFlag) { Save.corruptFlag = false; UI.toast(U.t('toast.corrupt'), 'info'); }
      document.getElementById('loading').classList.add('hidden');
      Main.running = true; requestAnimationFrame(Main.tick);
      UI.checkOrientation();
    } catch (e) { console.error(e); fatal(String(e && e.stack || e)); }
  };

  /* lifecycle: backgrounding pauses the game and silences audio; returning leaves it paused */
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { Save.flushRun(); if (T.active && !T.paused) { UI.openPause(); } Au.suspend(); }
    else { Au.resume(); Main.last = 0; }
  });
  window.addEventListener('pagehide', () => { try { Save.flushRun(); Save.saveMeta(T.meta); } catch (e) { /* ignore */ } });
  window.addEventListener('blur', () => { /* audio keeps its own state; pausing happens on visibility */ });

  /* ---- hooks for automated tests / debugging (read-only helpers, no cheats exposed in the UI) ---- */
  G.__tallow = { Main, get state() { return T.st; }, get view() { return Show.view; }, stats() { return { frames: R.stats.frames, avgDrawMs: R.stats.drawMs / Math.max(1, R.stats.frames), anim: { started: Anim.started, blocked: G.Anim.blocked } }; } };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', Main.boot); else Main.boot();
  G.Main = Main;
})(typeof window !== 'undefined' ? window : globalThis);
