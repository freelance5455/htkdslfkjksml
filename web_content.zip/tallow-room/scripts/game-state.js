/* game-state.js — AUTHORITATIVE rules engine. Pure data in, events out.
   No rendering, no audio, no timing. Presentation layers only *narrate* the events returned here. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, R = U.Rand;
  const E = {};
  E.SLOTS = D.config.slots;
  const opp = (w) => (w === 'p' ? 'd' : 'p');
  E.opp = opp;

  const blank = (max) => ({ hp: max, max, items: new Array(E.SLOTS).fill(null), cuffed: false, charged: false });
  const firstEmpty = (arr) => arr.findIndex((x) => !x);

  E.newGame = function (diff, seed) {
    if (!D.difficulties[diff]) diff = 'normal';
    return {
      v: 1, r: (seed === undefined ? (Date.now() & 0x7fffffff) : seed) | 0, diff,
      round: 0, phase: 'between', turn: 'p',
      p: blank(3), d: blank(3),
      chamber: [], loaded: { e: 0, a: 0 }, pub: { e: 0, a: 0 }, peek: { who: null, type: null },
      stats: { dmgTaken: 0, itemsUsed: 0, usedIds: {}, shotsSelf: 0, ashStreak: 0, bestStreak: 0, roundsWon: 0, roundItems: 0, roundDmg: 0 }
    };
  };

  E.startRound = function (st) {
    const cfg = D.config, df = D.difficulties[st.diff];
    st.round++;
    const base = cfg.hpByRound[st.round - 1];
    st.p = blank(base + df.playerHp);
    st.d = blank(base + df.dealerHp);
    st.phase = 'play'; st.turn = 'p'; st.peek = { who: null, type: null };
    st.stats.roundItems = 0; st.stats.roundDmg = 0;
    const ev = [{ t: 'roundStart', round: st.round, pmax: st.p.max, dmax: st.d.max }];
    E.reload(st, ev);
    return ev;
  };

  E.reload = function (st, ev) {
    const cfg = D.config, ri = st.round - 1, df = D.difficulties[st.diff];
    const n = R.int(st, cfg.chamberMin[ri], cfg.chamberMax[ri]);
    let e = Math.round(n * (0.4 + R.next(st) * 0.2));
    e = U.clamp(e, 1, n - 1);
    const a = n - e;
    const ch = [];
    for (let i = 0; i < e; i++) ch.push('e');
    for (let i = 0; i < a; i++) ch.push('a');
    R.shuffle(st, ch);
    st.chamber = ch; st.loaded = { e, a }; st.pub = { e, a }; st.peek = { who: null, type: null };
    const added = [];
    for (const who of ['p', 'd']) {
      const cnt = cfg.itemsPerReload[ri] + (who === 'd' ? df.dealerItems : 0);
      for (let i = 0; i < cnt; i++) {
        const slot = firstEmpty(st[who].items);
        if (slot < 0) break;
        const id = R.weighted(st, D.itemWeights());
        st[who].items[slot] = { id, uses: D.items[id].uses };
        added.push({ who, slot, id });
      }
    }
    ev.push({ t: 'reload', e, a, total: n, added });
  };

  E.canUse = function (st, who, idx) {
    const me = st[who], op = st[opp(who)];
    const it = me.items[idx];
    if (!it) return { ok: false, reason: 'toast.slotEmpty' };
    if (it.id === 'cigarette' && me.hp >= me.max) return { ok: false, reason: 'toast.pulseFull' };
    if (it.id === 'handcuffs' && op.cuffed) return { ok: false, reason: 'toast.cuffed' };
    if (it.id === 'battery' && me.charged) return { ok: false, reason: 'toast.charged' };
    if (it.id === 'lighter' && !op.items.some((x) => x)) return { ok: false, reason: 'toast.noTargets' };
    return { ok: true };
  };

  /* effect helpers — each mutates state and returns a descriptive fx object */
  const FX = {
    peek(st, who) { st.peek = { who, type: st.chamber[0] }; return { k: 'peek', type: st.chamber[0] }; },
    cuff(st, who) { st[opp(who)].cuffed = true; return { k: 'cuff' }; },
    heal(st, who) { const me = st[who], b = me.hp; me.hp = Math.min(me.max, me.hp + 1); return { k: 'heal', amt: me.hp - b, hp: me.hp }; },
    scramble(st) { R.shuffle(st, st.chamber); st.peek = { who: null, type: null }; return { k: 'scramble' }; }
  };

  function useItem(st, who, idx, ev) {
    const me = st[who], op = st[opp(who)];
    const it = me.items[idx], id = it.id;
    const e = { t: 'item', who, idx, id, consumed: true, fx: null, usesLeft: 0 };
    if (who === 'p') { st.stats.itemsUsed++; st.stats.roundItems++; st.stats.usedIds[id] = 1; }
    switch (id) {
      case 'magnifier': e.fx = FX.peek(st, who); break;
      case 'handcuffs': e.fx = FX.cuff(st, who); break;
      case 'cigarette': e.fx = FX.heal(st, who); break;
      case 'battery': me.charged = true; e.fx = { k: 'charge' }; break;
      case 'medicine': {
        const good = R.next(st) < 0.5, b = me.hp;
        if (good) me.hp = Math.min(me.max, me.hp + 2); else if (me.hp > 1) me.hp -= 1;
        e.fx = { k: 'pills', good, amt: me.hp - b, hp: me.hp };
        break;
      }
      case 'can': {
        const type = st.chamber.shift();
        st.pub[type]--; st.peek = { who: null, type: null };
        e.fx = { k: 'eject', type, empty: st.chamber.length === 0 };
        break;
      }
      case 'lighter': {
        const targets = [];
        op.items.forEach((x, i) => { if (x) targets.push(i); });
        const ti = R.pick(st, targets);
        e.fx = { k: 'burn', slot: ti, id: op.items[ti].id, target: opp(who) };
        op.items[ti] = null;
        it.uses--; e.consumed = it.uses <= 0; e.usesLeft = it.uses;
        break;
      }
      case 'scrambler': e.fx = FX.scramble(st); break;
      case 'coin': {
        const opts = ['peek'];
        if (!op.cuffed) opts.push('cuff');
        if (me.hp < me.max) opts.push('heal');
        if (st.chamber.length > 1) opts.push('scramble');
        const kind = R.pick(st, opts);
        e.fx = { k: 'coin', inner: FX[kind](st, who) };
        break;
      }
    }
    if (e.consumed) me.items[idx] = null;
    ev.push(e);
    if (id === 'can' && e.fx.empty) E.reload(st, ev);
  }

  function shoot(st, who, target, ev) {
    const me = st[who];
    const type = st.chamber.shift();
    st.pub[type]--;
    const victimId = target === 'self' ? who : opp(who);
    const victim = st[victimId];
    let dmg = 0;
    if (type === 'e') { dmg = me.charged ? 2 : 1; victim.hp = Math.max(0, victim.hp - dmg); }
    const charged = me.charged;
    me.charged = false; st.peek = { who: null, type: null };
    const e = { t: 'shot', who, target, victim: victimId, type, dmg, hp: victim.hp, charged, keep: false, empty: st.chamber.length === 0 };
    if (victimId === 'p' && dmg) { st.stats.dmgTaken += dmg; st.stats.roundDmg += dmg; }
    if (who === 'p' && target === 'self') {
      st.stats.shotsSelf++;
      if (type === 'a') { st.stats.ashStreak++; st.stats.bestStreak = Math.max(st.stats.bestStreak, st.stats.ashStreak); } else st.stats.ashStreak = 0;
    }
    ev.push(e);
    if (victim.hp <= 0) {
      const winner = opp(victimId);
      ev.push({ t: 'death', who: victimId });
      st.peek = { who: null, type: null };
      if (winner === 'p') {
        st.stats.roundsWon++;
        st.phase = st.round >= D.config.rounds ? 'won' : 'between';
      } else st.phase = 'lost';
      ev.push({ t: 'roundEnd', winner, phase: st.phase, round: st.round, hpLeft: st.p.hp, items: st.stats.roundItems, dmg: st.stats.roundDmg });
      return;
    }
    let next;
    if (target === 'self' && type === 'a') { next = who; e.keep = true; }
    else {
      next = opp(who);
      if (st[next].cuffed) { st[next].cuffed = false; ev.push({ t: 'skip', who: next }); next = who; }
    }
    st.turn = next;
    if (st.chamber.length === 0) E.reload(st, ev);
    ev.push({ t: 'turn', who: st.turn });
  }

  E.apply = function (st, who, action) {
    const ev = [];
    if (st.phase !== 'play') return { ok: false, reason: 'phase', ev };
    if (st.turn !== who) return { ok: false, reason: 'toast.notTurn', ev };
    if (!action) return { ok: false, reason: 'badAction', ev };
    if (action.type === 'item') {
      const c = E.canUse(st, who, action.idx);
      if (!c.ok) return { ok: false, reason: c.reason, ev };
      useItem(st, who, action.idx, ev);
    } else if (action.type === 'shoot' && (action.target === 'self' || action.target === 'opp')) {
      if (!st.chamber.length) return { ok: false, reason: 'empty', ev };
      shoot(st, who, action.target, ev);
    } else return { ok: false, reason: 'badAction', ev };
    return { ok: true, ev };
  };

  /* What `who` is allowed to know (public counts + their own peek). Used by the Dealer AI. */
  E.infoFor = function (st, who) {
    return { ember: st.pub.e, ash: st.pub.a, total: st.chamber.length, peek: st.peek.who === who ? st.peek.type : null };
  };

  E.validate = function (st) {
    try {
      if (!st || st.v !== 1 || typeof st.r !== 'number') return false;
      if (!D.difficulties[st.diff]) return false;
      if (!['p', 'd'].includes(st.turn) || !['play', 'between', 'won', 'lost'].includes(st.phase)) return false;
      if (!(st.round >= 0 && st.round <= D.config.rounds)) return false;
      for (const w of ['p', 'd']) {
        const s = st[w];
        if (!s || !(s.hp >= 0 && s.hp <= s.max && s.max <= 12) || !Array.isArray(s.items) || s.items.length !== E.SLOTS) return false;
        for (const it of s.items) if (it && (!D.items[it.id] || !(it.uses >= 1 && it.uses <= 5))) return false;
      }
      if (!Array.isArray(st.chamber) || st.chamber.some((c) => c !== 'e' && c !== 'a')) return false;
      if (st.phase === 'play' && st.chamber.length === 0) return false;
      if (!st.pub || !st.stats) return false;
      return true;
    } catch (e) { return false; }
  };

  G.Engine = E;
  if (typeof module !== 'undefined' && module.exports) module.exports = E;
})(typeof window !== 'undefined' ? window : globalThis);
