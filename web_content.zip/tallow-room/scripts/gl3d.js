/* gl3d.js — a small self-contained WebGL1 engine (no external libraries): mat4 maths, procedural geometry,
   Blinn-Phong lighting with up to 5 point lights, one shadow-mapped spot light (PCF), exponential fog,
   procedural surface kinds (wood, concrete, CRT static, skin, cloth), additive glow sprites.
   Used by stage3d.js. Props are generated at runtime; the table, shotgun and character come from data/models.js (the supplied GLB files, converted by tools/build-models.js). Supports per-vertex colour and 4-joint skinning. */
(function (G) {
  'use strict';
  const GL = { ok: false, gl: null, stats: { draws: 0, tris: 0 }, shadowSize: 1024 };
  const sin = Math.sin, cos = Math.cos, sqrt = Math.sqrt, PI = Math.PI;

  /* ------------------------------------------------------------------ mat4 (column-major) */
  const M = GL.M = {
    id() { return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]); },
    mul(a, b, o) {
      o = o || new Float32Array(16);
      for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      return o;
    },
    persp(fovy, asp, n, f) { const t = 1 / Math.tan(fovy / 2), o = new Float32Array(16); o[0] = t / asp; o[5] = t; o[10] = (f + n) / (n - f); o[11] = -1; o[14] = 2 * f * n / (n - f); return o; },
    ortho(l, r, b, t, n, f) { const o = M.id(); o[0] = 2 / (r - l); o[5] = 2 / (t - b); o[10] = -2 / (f - n); o[12] = -(r + l) / (r - l); o[13] = -(t + b) / (t - b); o[14] = -(f + n) / (f - n); return o; },
    look(e, t, up) {
      let zx = e[0] - t[0], zy = e[1] - t[1], zz = e[2] - t[2], l = sqrt(zx * zx + zy * zy + zz * zz) || 1; zx /= l; zy /= l; zz /= l;
      let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx; l = sqrt(xx * xx + xy * xy + xz * xz) || 1; xx /= l; xy /= l; xz /= l;
      const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
      return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0, -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1]);
    },
    /* translate * Ry * Rx * Rz * scale */
    trs(px, py, pz, ry, rx, rz, sx, sy, sz, o) {
      o = o || new Float32Array(16); sx = sx === undefined ? 1 : sx; sy = sy === undefined ? sx : sy; sz = sz === undefined ? sx : sz;
      const cy = cos(ry || 0), sy_ = sin(ry || 0), cx = cos(rx || 0), sx_ = sin(rx || 0), cz = cos(rz || 0), sz_ = sin(rz || 0);
      // R = Ry*Rx*Rz
      const r00 = cy * cz + sy_ * sx_ * sz_, r01 = -cy * sz_ + sy_ * sx_ * cz, r02 = sy_ * cx;
      const r10 = cx * sz_, r11 = cx * cz, r12 = -sx_;
      const r20 = -sy_ * cz + cy * sx_ * sz_, r21 = sy_ * sz_ + cy * sx_ * cz, r22 = cy * cx;
      o[0] = r00 * sx; o[1] = r10 * sx; o[2] = r20 * sx; o[3] = 0; o[4] = r01 * sy; o[5] = r11 * sy; o[6] = r21 * sy; o[7] = 0; o[8] = r02 * sz; o[9] = r12 * sz; o[10] = r22 * sz; o[11] = 0;
      o[12] = px; o[13] = py; o[14] = pz; o[15] = 1; return o;
    },
    /* orient local +Y along (dx,dy,dz) with origin at p; returns matrix (uniform radius scale r, length scale l) */
    along(p, d, r, l, o) {
      o = o || new Float32Array(16);
      let yx = d[0], yy = d[1], yz = d[2]; const L = sqrt(yx * yx + yy * yy + yz * yz) || 1; yx /= L; yy /= L; yz /= L;
      let ax = 0, ay = 0, az = 1; if (Math.abs(yz) > 0.92) { ax = 1; az = 0; }
      let xx = yy * az - yz * ay, xy = yz * ax - yx * az, xz = yx * ay - yy * ax; const xl = sqrt(xx * xx + xy * xy + xz * xz) || 1; xx /= xl; xy /= xl; xz /= xl;
      const zx = xy * yz - xz * yy, zy = xz * yx - xx * yz, zz = xx * yy - xy * yx;
      o[0] = xx * r; o[1] = xy * r; o[2] = xz * r; o[3] = 0; o[4] = yx * l; o[5] = yy * l; o[6] = yz * l; o[7] = 0; o[8] = zx * r; o[9] = zy * r; o[10] = zz * r; o[11] = 0; o[12] = p[0]; o[13] = p[1]; o[14] = p[2]; o[15] = 1; return o;
    },
    normalMat(m, o) { // inverse-transpose of the upper 3x3
      o = o || new Float32Array(9);
      const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10];
      const A = e * i - f * h, B = f * g - d * i, C = d * h - e * g, det = a * A + b * B + c * C || 1, id = 1 / det;
      o[0] = A * id; o[1] = B * id; o[2] = C * id; o[3] = (c * h - b * i) * id; o[4] = (a * i - c * g) * id; o[5] = (b * g - a * h) * id; o[6] = (b * f - c * e) * id; o[7] = (c * d - a * f) * id; o[8] = (a * e - b * d) * id;
      return o;
    }
  };
  /* sRGB hex -> linear rgb array */
  GL.rgb = function (hex, k) { const n = parseInt(hex.slice(1), 16), f = (v) => Math.pow(v / 255, 2.2) * (k === undefined ? 1 : k); return [f((n >> 16) & 255), f((n >> 8) & 255), f(n & 255)]; };

  /* ------------------------------------------------------------------ geometry builders -> {p,n,i} */
  const Geo = GL.Geo = {
    box(w, h, d) {
      const x = w / 2, y = h / 2, z = d / 2, p = [], n = [], i = [];
      const faces = [[[0, 0, 1], [-x, -y, z], [x, -y, z], [x, y, z], [-x, y, z]], [[0, 0, -1], [x, -y, -z], [-x, -y, -z], [-x, y, -z], [x, y, -z]], [[1, 0, 0], [x, -y, z], [x, -y, -z], [x, y, -z], [x, y, z]],
        [[-1, 0, 0], [-x, -y, -z], [-x, -y, z], [-x, y, z], [-x, y, -z]], [[0, 1, 0], [-x, y, z], [x, y, z], [x, y, -z], [-x, y, -z]], [[0, -1, 0], [-x, -y, -z], [x, -y, -z], [x, -y, z], [-x, -y, z]]];
      faces.forEach((f, k) => { for (let j = 1; j < 5; j++) { p.push(...f[j]); n.push(...f[0]); } i.push(k * 4, k * 4 + 1, k * 4 + 2, k * 4, k * 4 + 2, k * 4 + 3); });
      return { p, n, i };
    },
    /* surface of revolution around Y. prof: [[radius, y], ...] bottom -> top. smooth normals from the profile */
    lathe(prof, seg) {
      seg = seg || 20; const p = [], n = [], i = [], np = prof.length;
      for (let a = 0; a <= seg; a++) {
        const t = a / seg * PI * 2, ct = cos(t), st = sin(t);
        for (let k = 0; k < np; k++) {
          const q = prof[k], pr = prof[Math.max(0, k - 1)], nx = prof[Math.min(np - 1, k + 1)];
          let dr = nx[0] - pr[0], dy = nx[1] - pr[1]; const l = sqrt(dr * dr + dy * dy) || 1; dr /= l; dy /= l;
          // outward normal of the profile tangent (dr,dy): (dy,-dr)
          p.push(q[0] * ct, q[1], q[0] * st); n.push(dy * ct, -dr, dy * st);
        }
      }
      for (let a = 0; a < seg; a++) for (let k = 0; k < np - 1; k++) { const b = a * np + k, c = (a + 1) * np + k; i.push(b, c, b + 1, c, c + 1, b + 1); }
      return { p, n, i };
    },
    cyl(rt, rb, h, seg) { return Geo.lathe([[0.0001, 0], [rb, 0], [rb, 0.0001], [rt, h - 0.0001], [rt, h], [0.0001, h]].map((q, k) => k === 1 || k === 2 || k === 3 || k === 4 ? q : q), seg || 16); },
    sphere(r, seg, rings) { rings = rings || 10; const pr = []; for (let k = 0; k <= rings; k++) { const a = -PI / 2 + k / rings * PI; pr.push([Math.max(0.0001, cos(a) * r), sin(a) * r]); } return Geo.lathe(pr, seg || 16); },
    /* capsule along +Y from 0..len with radius r */
    capsule(r, len, seg) { const pr = [], hs = 5; for (let k = 0; k <= hs; k++) { const a = -PI / 2 + k / hs * PI / 2; pr.push([Math.max(0.0001, cos(a) * r), sin(a) * r]); } for (let k = 0; k <= hs; k++) { const a = k / hs * PI / 2; pr.push([Math.max(0.0001, cos(a) * r), len + sin(a) * r]); } return Geo.lathe(pr, seg || 10); },
    torus(R, r, seg, seg2) {
      seg = seg || 20; seg2 = seg2 || 10; const p = [], n = [], i = [];
      for (let a = 0; a <= seg; a++) for (let b = 0; b <= seg2; b++) { const u = a / seg * PI * 2, v = b / seg2 * PI * 2, cx = cos(u) * (R + r * cos(v)), cz = sin(u) * (R + r * cos(v)); p.push(cx, r * sin(v), cz); n.push(cos(u) * cos(v), sin(v), sin(u) * cos(v)); }
      for (let a = 0; a < seg; a++) for (let b = 0; b < seg2; b++) { const q = a * (seg2 + 1) + b, w = (a + 1) * (seg2 + 1) + b; i.push(q, w, q + 1, w, w + 1, q + 1); }
      return { p, n, i };
    },
    cone(r, h, seg) { return Geo.lathe([[r, 0], [0.0001, h]], seg || 20); },
    merge(list) { const o = { p: [], n: [], i: [] }; for (const g of list) { const off = o.p.length / 3; o.p.push(...g.p); o.n.push(...g.n); for (const k of g.i) o.i.push(k + off); } return o; },
    /* apply a matrix to a geometry (bake) */
    bake(g, m) { const nm = M.normalMat(m), p = [], n = []; for (let k = 0; k < g.p.length; k += 3) { const x = g.p[k], y = g.p[k + 1], z = g.p[k + 2]; p.push(m[0] * x + m[4] * y + m[8] * z + m[12], m[1] * x + m[5] * y + m[9] * z + m[13], m[2] * x + m[6] * y + m[10] * z + m[14]); const a = g.n[k], b = g.n[k + 1], c = g.n[k + 2]; let nx = nm[0] * a + nm[3] * b + nm[6] * c, ny = nm[1] * a + nm[4] * b + nm[7] * c, nz = nm[2] * a + nm[5] * b + nm[8] * c; const l = sqrt(nx * nx + ny * ny + nz * nz) || 1; n.push(nx / l, ny / l, nz / l); } return { p, n, i: g.i }; }
  };

  /* ------------------------------------------------------------------ shaders */
  const SKIN = `attribute vec4 aJ; attribute vec4 aW; uniform vec4 uJ[${'NJ'}]; uniform float uSkin;
vec3 skinV(vec3 p, float pt){ vec3 r=vec3(0.0); vec4 q=vec4(p,pt);
  for(int k=0;k<4;k++){ float w=aW[k]; if(w<=0.0) continue; int b=int(aJ[k]+0.5)*3; r+=w*vec3(dot(uJ[b],q),dot(uJ[b+1],q),dot(uJ[b+2],q)); }
  return r; }`;
  const VS = SKIN + `attribute vec3 aP; attribute vec3 aN; attribute vec3 aC; uniform mat4 uM; uniform mat4 uVP; uniform mat3 uNM; uniform mat4 uLVP;
varying vec3 vW; varying vec3 vN; varying vec4 vL; varying vec3 vO; varying vec3 vC;
void main(){ vec3 p=aP, n=aN; if(uSkin>0.5){ p=skinV(aP,1.0); n=skinV(aN,0.0); }
  vec4 w=uM*vec4(p,1.0); vW=w.xyz; vO=aP; vC=aC; vN=normalize(uNM*n); vL=uLVP*w; gl_Position=uVP*w; }`;
  const FS = `precision highp float;
varying vec3 vW; varying vec3 vN; varying vec4 vL; varying vec3 vO; varying vec3 vC;
uniform vec3 uCol; uniform vec3 uEm; uniform vec3 uCam; uniform float uSpec; uniform float uShin; uniform float uKind; uniform float uTime; uniform float uAlpha; uniform float uRim;
uniform vec4 uLP[5]; uniform vec3 uLC[5]; uniform vec3 uAmb; uniform vec3 uSpotDir; uniform float uSpotCos; uniform sampler2D uSh; uniform float uShOn; uniform vec3 uFog; uniform float uFogD; uniform float uLamp;
float h21(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f); return mix(mix(h21(i),h21(i+vec2(1,0)),f.x),mix(h21(i+vec2(0,1)),h21(i+vec2(1,1)),f.x),f.y); }
float unpack(vec4 c){ return dot(c, vec4(1.0, 1.0/255.0, 1.0/65025.0, 1.0/16581375.0)); }
float shadowAt(vec3 n, vec3 l){
  if(uShOn<0.5) return 1.0;
  vec3 pr=vL.xyz/vL.w*0.5+0.5; if(pr.x<0.0||pr.x>1.0||pr.y<0.0||pr.y>1.0||pr.z>1.0) return 1.0;
  float bias=0.0035+0.004*(1.0-max(dot(n,l),0.0)); float s=0.0; float px=1.0/${'SHSIZE'}.0;
  for(int i=0;i<5;i++){ vec2 o=i==0?vec2(0.0):i==1?vec2(1.5,0.0):i==2?vec2(-1.5,0.0):i==3?vec2(0.0,1.5):vec2(0.0,-1.5); float d=unpack(texture2D(uSh,pr.xy+o*px)); s+= (pr.z-bias>d)?0.0:1.0; }
  return s/5.0;
}
void main(){
  if(uKind>6.5){ gl_FragColor=vec4(uEm,1.0); return; }
  vec3 N=normalize(vN); vec3 V=normalize(uCam-vW);
  vec3 base=uCol*vC; vec3 em=uEm; float spec=uSpec; float shin=uShin; float rim=uRim;
  if(uKind>0.5&&uKind<1.5){ // wood
    float g=vn(vec2(vW.x*3.0,vW.z*46.0))*0.6+vn(vec2(vW.x*18.0,vW.z*9.0))*0.4; float plank=step(0.5,fract(vW.z*2.3)); float seam=smoothstep(0.0,0.02,abs(fract(vW.z*2.3)-0.0))*smoothstep(0.0,0.02,abs(fract(vW.z*2.3)-1.0));
    base*=0.55+g*0.9; base*=0.85+0.15*plank; base*=0.5+0.5*seam; spec*=0.4+g*0.6;
    float stain=smoothstep(0.62,0.85,vn(vW.xz*3.2+7.0)); base=mix(base,base*vec3(0.35,0.2,0.2),stain*0.7);
  } else if(uKind>1.5&&uKind<2.5){ // concrete / wall
    float n1=vn(vW.xy*5.0+vW.zz*3.0)*0.5+vn(vW.xy*21.0+vW.zz*9.0)*0.3+vn(vW.xy*80.0)*0.2; base*=0.5+n1*0.9;
    float seamv=smoothstep(0.0,0.03,abs(fract(vW.x*1.1)-0.5)); base*=0.7+0.3*seamv;
    float drip=smoothstep(0.7,0.95,vn(vec2(vW.x*7.0,vW.y*0.8+3.0))); base=mix(base,base*vec3(0.5,0.2,0.2),drip*0.5);
  } else if(uKind>2.5&&uKind<3.5){ // CRT static
    float st=h21(floor(vO.xy*90.0)+floor(uTime*18.0)); float sc=0.75+0.25*sin(vO.y*300.0+uTime*20.0); float roll=smoothstep(0.0,0.2,fract(vO.y*0.8-uTime*0.35));
    float lvl=(st*0.7+0.15)*sc; em=vec3(0.75,0.12,0.1)*lvl*(0.5+0.8*roll)*uEm.r; base*=0.2; spec=0.6; shin=60.0;
  } else if(uKind>3.5&&uKind<4.5){ // skin
    float pore=vn(vW.xz*70.0+vW.yy*70.0); base*=0.9+pore*0.2; rim=max(rim,0.35);
  } else if(uKind>4.5&&uKind<5.5){ // cloth
    float w=sin(vW.x*260.0)*sin(vW.z*260.0+vW.y*90.0); base*=0.88+0.12*w+0.06*vn(vW.xy*30.0); spec*=0.4;
  } else if(uKind>5.5&&uKind<6.5){ // wax mask
    float v=vn(vO.xy*7.0+vO.zz*3.0); base*=0.9+v*0.14; float crack=smoothstep(0.47,0.5,abs(vn(vO.xy*6.0+3.0)-0.5)); base*=0.9+0.1*crack; rim=max(rim,0.28);
  }
  vec3 col=base*uAmb+em;
  for(int i=0;i<5;i++){
    vec3 lp=uLP[i].xyz; float rad=uLP[i].w; if(rad<=0.0) continue;
    vec3 L=lp-vW; float d=length(L); L/=d; float att=clamp(1.0-d/rad,0.0,1.0); att*=att;
    float ndl=max(dot(N,L),0.0); float sh=1.0;
    if(i==0){ float cs=dot(-L,uSpotDir); att*=smoothstep(uSpotCos,uSpotCos+0.22,cs); sh=shadowAt(N,L); }
    vec3 H=normalize(L+V); float sp=spec*pow(max(dot(N,H),0.0),shin);
    col+=(base*ndl+vec3(sp))*uLC[i]*att*sh;
    if(rim>0.0){ float fr=pow(1.0-max(dot(N,V),0.0),2.5); col+=uLC[i]*vec3(1.0,0.25,0.18)*fr*rim*att*0.6; }
  }
  float dist=length(uCam-vW); float f=1.0-exp(-dist*uFogD); col=mix(col,uFog,clamp(f,0.0,1.0));
  col=pow(max(col,vec3(0.0)),vec3(1.0/2.2));
  gl_FragColor=vec4(col,uAlpha);
}`;
  const VS_D = SKIN + `attribute vec3 aP; uniform mat4 uM; uniform mat4 uLVP; varying vec2 vz; void main(){ vec3 q=aP; if(uSkin>0.5) q=skinV(aP,1.0); vec4 p=uLVP*uM*vec4(q,1.0); vz=p.zw; gl_Position=p; }`;
  const FS_D = `precision highp float; varying vec2 vz;
vec4 pack(float d){ vec4 e=fract(d*vec4(1.0,255.0,65025.0,16581375.0)); e-=e.yzww*vec4(1.0/255.0,1.0/255.0,1.0/255.0,0.0); return e; }
void main(){ float d=vz.x/vz.y*0.5+0.5; gl_FragColor=pack(clamp(d,0.0,0.99999)); }`;
  const VS_S = `attribute vec2 aQ; uniform vec3 uC; uniform float uS; uniform vec3 uR; uniform vec3 uU; uniform mat4 uVP; varying vec2 vq;
void main(){ vq=aQ; vec3 w=uC+(uR*aQ.x+uU*aQ.y)*uS; gl_Position=uVP*vec4(w,1.0); }`;
  const FS_S = `precision mediump float; varying vec2 vq; uniform vec4 uCol; uniform float uSoft;
void main(){ float d=length(vq); float a=pow(clamp(1.0-d,0.0,1.0),uSoft); gl_FragColor=vec4(uCol.rgb*a*uCol.a,a*uCol.a); }`;

  function compile(gl, vs, fs) {
    const mk = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); if (!gl.getShaderParameter(o, gl.COMPILE_STATUS)) throw new Error('shader: ' + gl.getShaderInfoLog(o)); return o; };
    const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('link: ' + gl.getProgramInfoLog(p));
    const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < n; i++) { const inf = gl.getActiveUniform(p, i), nm = inf.name.replace(/\[0\]$/, ''); u[nm] = gl.getUniformLocation(p, inf.name); }
    return { p, u, a: (nme) => gl.getAttribLocation(p, nme) };
  }

  /* ------------------------------------------------------------------ init */
  const NJ = 32; // skinning joints (3 vec4 rows each = 96 vec4, well inside the 128 vec4 minimum of WebGL1)
  let shFrame = 0, shValid = false; // the shadow map is refreshed every 2nd frame (the lamp is static; moving shadows lag by one frame)
  let gl, prog, progD, progS, quadBuf, shTex, shFbo, shDepth, curShadowSize = 0;
  const lists = { op: [], tr: [], add: [], sp: [] };
  GL.init = function (canvas) {
    try {
      gl = canvas.getContext('webgl', { alpha: false, antialias: false, powerPreference: 'high-performance', preserveDrawingBuffer: false, failIfMajorPerformanceCaveat: false }) || null;
      if (!gl) return false;
      GL.gl = gl; GL.canvas = canvas;
      GL.maxJoints = NJ; prog = compile(gl, VS.replace('NJ', NJ * 3), FS.replace('SHSIZE', '1024')); progD = compile(gl, VS_D.replace('NJ', NJ * 3), FS_D); progS = compile(gl, VS_S, FS_S);
      quadBuf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1]), gl.STATIC_DRAW);
      GL.setShadowSize(1024); GL.ok = true;
      canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); GL.ok = false; GL.lost = true; });
      return true;
    } catch (e) { console.warn('[gl3d] init failed:', e && e.message); GL.ok = false; return false; }
  };
  GL.setShadowSize = function (sz) {
    if (!gl || sz === curShadowSize) return; curShadowSize = sz;
    if (!sz) return;
    if (!shTex) { shTex = gl.createTexture(); shFbo = gl.createFramebuffer(); shDepth = gl.createRenderbuffer(); }
    gl.bindTexture(gl.TEXTURE_2D, shTex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, sz, sz, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindRenderbuffer(gl.RENDERBUFFER, shDepth); gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, sz, sz);
    gl.bindFramebuffer(gl.FRAMEBUFFER, shFbo); gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, shTex, 0); gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, shDepth);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    // the shader's pixel size must match; recompile only the constant
    prog = compile(gl, VS.replace('NJ', NJ * 3), FS.replace('SHSIZE', String(sz)));
  };

  /* ------------------------------------------------------------------ meshes */
  GL.mesh = function (geo) {
    const n = geo.p.length / 3, skin = !!geo.j, stride = skin ? 44 : 36, buf = new ArrayBuffer(n * stride), f = new Float32Array(buf), u8 = new Uint8Array(buf), fs = stride / 4;
    for (let k = 0; k < n; k++) {
      const o = k * fs; f[o] = geo.p[k * 3]; f[o + 1] = geo.p[k * 3 + 1]; f[o + 2] = geo.p[k * 3 + 2]; f[o + 3] = geo.n[k * 3]; f[o + 4] = geo.n[k * 3 + 1]; f[o + 5] = geo.n[k * 3 + 2];
      f[o + 6] = geo.c ? geo.c[k * 3] : 1; f[o + 7] = geo.c ? geo.c[k * 3 + 1] : 1; f[o + 8] = geo.c ? geo.c[k * 3 + 2] : 1;
      if (skin) for (let q = 0; q < 4; q++) { u8[k * stride + 36 + q] = geo.j[k * 4 + q]; u8[k * stride + 40 + q] = geo.w[k * 4 + q]; }
    }
    const vb = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, buf, gl.STATIC_DRAW);
    const ib = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(geo.i), gl.STATIC_DRAW);
    return { vb, ib, count: geo.i.length, off: 0, skin, stride, nv: n };
  };
  /* a draw range of an existing mesh (same buffers) */
  GL.sub = function (mesh, start, count) { return Object.assign({}, mesh, { off: start, count }); };
  GL.dispose = function (mesh) { if (!mesh || mesh.sub) return; gl.deleteBuffer(mesh.vb); gl.deleteBuffer(mesh.ib); };
  GL.material = function (o) { return Object.assign({ c: [0.5, 0.5, 0.5], em: [0, 0, 0], spec: 0.2, shin: 24, kind: 0, alpha: 1, rim: 0, cast: true }, o); };

  /* ------------------------------------------------------------------ frame API */
  let frame = null;
  GL.begin = function (f) { frame = f; lists.op.length = 0; lists.tr.length = 0; lists.add.length = 0; lists.sp.length = 0; };
  const matPool = []; let matN = 0;
  GL.draw = function (mesh, m, mat, jt) { const mm = new Float32Array(m); (mat.alpha < 1 ? lists.tr : lists.op).push({ mesh, m: mm, mat, jt: jt || null }); };
  GL.drawAdd = function (mesh, m, mat) { lists.add.push({ mesh, m: new Float32Array(m), mat }); };
  GL.sprite = function (x, y, z, size, r, g, b, a, soft) { lists.sp.push({ x, y, z, size, r, g, b, a, soft: soft || 2 }); };

  const aLoc = new Map(); // attribute locations are looked up once per program
  function loc(prg, name) { let m = aLoc.get(prg); if (!m) { m = {}; aLoc.set(prg, m); } if (m[name] === undefined) m[name] = prg.a(name); return m[name]; }
  function bindMesh(prg, mesh, full) {
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.ib); const st = mesh.stride;
    const ap = loc(prg, 'aP'); gl.enableVertexAttribArray(ap); gl.vertexAttribPointer(ap, 3, gl.FLOAT, false, st, 0);
    if (full) { const an = loc(prg, 'aN'); if (an >= 0) { gl.enableVertexAttribArray(an); gl.vertexAttribPointer(an, 3, gl.FLOAT, false, st, 12); } const ac = loc(prg, 'aC'); if (ac >= 0) { gl.enableVertexAttribArray(ac); gl.vertexAttribPointer(ac, 3, gl.FLOAT, false, st, 24); } }
    const aj = loc(prg, 'aJ'), aw = loc(prg, 'aW');
    if (mesh.skin) { if (aj >= 0) { gl.enableVertexAttribArray(aj); gl.vertexAttribPointer(aj, 4, gl.UNSIGNED_BYTE, false, st, 36); } if (aw >= 0) { gl.enableVertexAttribArray(aw); gl.vertexAttribPointer(aw, 4, gl.UNSIGNED_BYTE, true, st, 40); } }
    else { if (aj >= 0) gl.disableVertexAttribArray(aj); if (aw >= 0) gl.disableVertexAttribArray(aw); }
  }
  const nm3 = new Float32Array(9);
  GL.end = function () {
    const f = frame, W = GL.canvas.width, H = GL.canvas.height; GL.stats.draws = 0; GL.stats.tris = 0;
    const lvp = M.mul(f.lightProj, f.lightView); const useSh = f.shadows && curShadowSize > 0; shFrame++; const doShadowPass = useSh && (shFrame % 2 === 0 || !shValid);
    // ---- shadow pass
    if (doShadowPass) { shValid = true;
      gl.bindFramebuffer(gl.FRAMEBUFFER, shFbo); gl.viewport(0, 0, curShadowSize, curShadowSize); gl.clearColor(1, 1, 1, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST); gl.disable(gl.BLEND); gl.disable(gl.CULL_FACE);
      gl.useProgram(progD.p); gl.uniformMatrix4fv(progD.u.uLVP, false, lvp);
      for (const o of lists.op) { if (!o.mat.cast) continue; bindMesh(progD, o.mesh, false); gl.uniformMatrix4fv(progD.u.uM, false, o.m); gl.uniform1f(progD.u.uSkin, o.jt ? 1 : 0); if (o.jt) gl.uniform4fv(progD.u.uJ, o.jt); gl.drawElements(gl.TRIANGLES, o.mesh.count, gl.UNSIGNED_SHORT, o.mesh.off * 2); GL.stats.draws++; GL.stats.tris += o.mesh.count / 3; }
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    }
    // ---- main pass
    gl.viewport(0, 0, W, H); gl.clearColor(f.fog[0] * 0.5, f.fog[1] * 0.5, f.fog[2] * 0.5, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND);
    gl.useProgram(prog.p); const u = prog.u, vp = M.mul(f.proj, f.view);
    gl.uniformMatrix4fv(u.uVP, false, vp); gl.uniformMatrix4fv(u.uLVP, false, lvp); gl.uniform3fv(u.uCam, f.eye); gl.uniform1f(u.uTime, f.time);
    gl.uniform3fv(u.uAmb, f.amb); gl.uniform3fv(u.uFog, f.fog); gl.uniform1f(u.uFogD, f.fogD); gl.uniform3fv(u.uSpotDir, f.spotDir); gl.uniform1f(u.uSpotCos, f.spotCos);
    const lp = new Float32Array(20), lc = new Float32Array(15);
    for (let i = 0; i < 5; i++) { const L = f.lights[i]; if (L) { lp.set([L.x, L.y, L.z, L.r], i * 4); lc.set(L.c, i * 3); } }
    gl.uniform4fv(u.uLP, lp); gl.uniform3fv(u.uLC, lc);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, shTex || null); gl.uniform1i(u.uSh, 0); gl.uniform1f(u.uShOn, useSh ? 1 : 0);
    const drawList = (list) => {
      for (const o of list) {
        const m = o.mat; bindMesh(prog, o.mesh, true);
        gl.uniformMatrix4fv(u.uM, false, o.m); gl.uniformMatrix3fv(u.uNM, false, M.normalMat(o.m, nm3));
        gl.uniform3fv(u.uCol, m.c); gl.uniform3fv(u.uEm, m.em); gl.uniform1f(u.uSpec, m.spec); gl.uniform1f(u.uShin, m.shin); gl.uniform1f(u.uKind, m.kind); gl.uniform1f(u.uAlpha, m.alpha); gl.uniform1f(u.uRim, m.rim);
        gl.uniform1f(u.uSkin, o.jt ? 1 : 0); if (o.jt) gl.uniform4fv(u.uJ, o.jt);
        gl.drawElements(gl.TRIANGLES, o.mesh.count, gl.UNSIGNED_SHORT, o.mesh.off * 2); GL.stats.draws++; GL.stats.tris += o.mesh.count / 3;
      }
    };
    drawList(lists.op);
    if (lists.tr.length) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); drawList(lists.tr); gl.depthMask(true); }
    // additive meshes (light shafts) + glow sprites
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); gl.depthMask(false);
    if (lists.add.length) drawList(lists.add);
    if (lists.sp.length) {
      gl.useProgram(progS.p); const su = progS.u; gl.uniformMatrix4fv(su.uVP, false, vp);
      const iv = f.view; const right = [iv[0], iv[4], iv[8]], up = [iv[1], iv[5], iv[9]];
      gl.uniform3fv(su.uR, right); gl.uniform3fv(su.uU, up);
      gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf); const aq = progS.a('aQ'); gl.enableVertexAttribArray(aq); gl.vertexAttribPointer(aq, 2, gl.FLOAT, false, 0, 0);
      for (const s of lists.sp) { gl.uniform3f(su.uC, s.x, s.y, s.z); gl.uniform1f(su.uS, s.size); gl.uniform4f(su.uCol, s.r, s.g, s.b, s.a); gl.uniform1f(su.uSoft, s.soft); gl.drawArrays(gl.TRIANGLES, 0, 6); GL.stats.draws++; }
    }
    gl.depthMask(true); gl.disable(gl.BLEND);
  };

  G.GL3D = GL;
  if (typeof module !== 'undefined' && module.exports) module.exports = GL;
})(typeof window !== 'undefined' ? window : globalThis);
