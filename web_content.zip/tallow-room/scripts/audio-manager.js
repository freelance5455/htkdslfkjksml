/* audio-manager.js — fully synthesised audio (Web Audio API). No audio files are shipped:
   every sound effect, the ambience bed, the generative music and the Dealer's voice are generated at runtime.
   Buses: master -> compressor -> out;  music / ambience / sfx / voice -> master. Reverb send for guns & voice. */
(function (G) {
  'use strict';
  const U = G.U;
  const A = { SFX: {}, ready: false, unlocked: false, paused: false, vol: { master: 0.8, music: 0.6, ambience: 0.7, sfx: 0.9, voice: 0.9 }, stats: { played: 0, dropped: 0, throttled: 0 } };
  let ctx = null, bus = {}, noiseBuf = null, verbIn = null, lastPlayed = {}, live = 0;

  /* ------------------------------------------------------------ synth kit (works on any BaseAudioContext) */
  function makeNoise(c) {
    const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
    let seed = 12345;
    for (let i = 0; i < len; i++) { seed = (seed * 1664525 + 1013904223) | 0; d[i] = ((seed >>> 8) / 8388608) - 1; }
    return b;
  }
  function Kit(c, dest, nbuf, verb) {
    const k = { c, dest, verb };
    k.tone = function (type, f0, f1, t, dur, vol, o) {
      o = o || {}; f0 = Math.min(f0, 18000); f1 = Math.min(f1, 18000);
      const os = c.createOscillator(), g = c.createGain();
      os.type = type; os.frequency.setValueAtTime(f0, t);
      if (f1 && f1 !== f0) os.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
      if (o.detune) os.detune.value = o.detune;
      const a = o.a || 0.004;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
      g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + 0.01, dur));
      os.connect(g);
      let n = g;
      if (o.f) { const fl = c.createBiquadFilter(); fl.type = o.ft || 'lowpass'; fl.frequency.value = o.f; fl.Q.value = o.q || 0.7; g.connect(fl); n = fl; }
      n.connect(o.dest || dest);
      if (o.verb && verb) { const s = c.createGain(); s.gain.value = o.verb; n.connect(s); s.connect(verb); }
      os.start(t); os.stop(t + dur + 0.05);
      return os;
    };
    k.noise = function (t, dur, vol, o) {
      o = o || {};
      const s = c.createBufferSource(); s.buffer = nbuf;
      if (o.rate) s.playbackRate.value = o.rate;
      const g = c.createGain();
      const a = o.a || 0.004;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
      if (o.hold) g.gain.setValueAtTime(Math.max(0.0002, vol), t + o.hold);
      g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(a + 0.01, dur));
      const fl = c.createBiquadFilter(); fl.type = o.ft || 'bandpass'; fl.Q.value = o.q || 0.8;
      fl.frequency.setValueAtTime(o.f0 || 2000, t);
      if (o.f1) fl.frequency.exponentialRampToValueAtTime(Math.max(20, o.f1), t + dur);
      s.connect(fl); fl.connect(g); g.connect(o.dest || dest);
      if (o.verb && verb) { const v = c.createGain(); v.gain.value = o.verb; g.connect(v); v.connect(verb); }
      s.start(t, Math.random() * 1.4, Math.min(1.9, dur + 0.05));
      return s;
    };
    k.click = (t, vol, f) => k.tone('square', f || 1800, (f || 1800) * 0.5, t, 0.012, vol, { a: 0.001, f: 4000 });
    k.thump = (t, vol, f, dur) => { k.tone('sine', f || 90, (f || 90) * 0.45, t, dur || 0.16, vol, { a: 0.002 }); k.noise(t, 0.05, vol * 0.5, { ft: 'lowpass', f0: 500, q: 0.5 }); };
    k.ring = (f, t, dur, vol, o) => { // metallic partials
      [1, 2.76, 5.4, 8.9].forEach((m, i) => k.tone('sine', f * m, f * m * 0.995, t, dur / (1 + i * 0.7), vol / (1 + i * 1.3), Object.assign({ a: 0.001 }, o || {})));
    };
    return k;
  }

  /* ------------------------------------------------------------ sound effects table (name -> synth) */
  const S = A.SFX;
  S.ui_click = (k, t, v) => { k.click(t, 0.22 * v, 1500); k.tone('sine', 520, 420, t, 0.06, 0.12 * v, { a: 0.002 }); };
  S.ui_back = (k, t, v) => { k.click(t, 0.2 * v, 900); k.tone('sine', 380, 260, t, 0.08, 0.12 * v, { a: 0.002 }); };
  S.toast = (k, t, v) => { k.tone('sine', 740, 740, t, 0.18, 0.08 * v, { a: 0.01, verb: 0.3 }); k.tone('sine', 988, 988, t + 0.06, 0.2, 0.06 * v, { a: 0.01, verb: 0.3 }); };
  S.tick = (k, t, v) => k.click(t, 0.15 * v, 2600);
  S.cloth = (k, t, v) => k.noise(t, 0.28, 0.1 * v, { ft: 'bandpass', f0: 1100, f1: 500, q: 0.4, a: 0.06 });
  S.table_tap = (k, t, v) => { k.tone('sine', 220, 120, t, 0.07, 0.35 * v, { a: 0.001 }); k.noise(t, 0.03, 0.12 * v, { ft: 'bandpass', f0: 1500, q: 1 }); };
  S.table_thud = (k, t, v) => { k.thump(t, 0.6 * v, 70, 0.3); k.noise(t, 0.12, 0.2 * v, { ft: 'lowpass', f0: 700, q: 0.4 }); };
  S.pickup = (k, t, v) => { k.noise(t, 0.12, 0.14 * v, { ft: 'bandpass', f0: 2200, f1: 900, q: 1 }); k.tone('sine', 300, 360, t, 0.06, 0.1 * v); };
  S.place = (k, t, v) => { k.tone('sine', 190, 110, t, 0.09, 0.28 * v, { a: 0.001 }); k.noise(t, 0.04, 0.1 * v, { ft: 'bandpass', f0: 1800, q: 1 }); };
  S.bounce_small = (k, t, v) => { for (let i = 0; i < 3; i++) k.tone('triangle', 1300 - i * 180, 900 - i * 120, t + i * 0.07 * (1 + i * 0.4), 0.05, 0.12 * v / (1 + i), { a: 0.001 }); };
  S.item_land = (k, t, v) => { k.thump(t, 0.28 * v, 130, 0.1); k.ring(1900, t, 0.08, 0.05 * v); };
  S.whoosh = (k, t, v) => k.noise(t, 0.5, 0.2 * v, { ft: 'bandpass', f0: 300, f1: 2600, q: 0.7, a: 0.2, verb: 0.2 });
  S.creak = (k, t, v) => { k.tone('sawtooth', 150, 190, t, 0.28, 0.05 * v, { a: 0.1, f: 600, q: 6 }); k.tone('sawtooth', 190, 120, t + 0.28, 0.27, 0.04 * v, { a: 0.02, f: 600, q: 6 }); };
  S.metal_clink = (k, t, v) => k.ring(2300 + Math.random() * 400, t, 0.25, 0.14 * v, { verb: 0.2 });
  S.glass_tink = (k, t, v) => { k.ring(3400, t, 0.4, 0.12 * v, { verb: 0.3 }); k.tone('sine', 5200, 5200, t, 0.3, 0.04 * v, { a: 0.001 }); };
  S.lens_hum = (k, t, v) => { k.tone('sine', 220, 330, t, 1.2, 0.1 * v, { a: 0.3, verb: 0.4 }); k.tone('sine', 223, 335, t, 1.2, 0.08 * v, { a: 0.3 }); k.noise(t, 1.2, 0.04 * v, { ft: 'bandpass', f0: 3000, q: 8, a: 0.4 }); };
  S.cuff_open = (k, t, v) => { for (let i = 0; i < 5; i++) k.click(t + i * 0.045, 0.2 * v, 1400 + i * 120); k.ring(1900, t + 0.2, 0.2, 0.08 * v); };
  S.cuff_close = (k, t, v) => { for (let i = 0; i < 4; i++) k.click(t + i * 0.035, 0.22 * v, 1500 + i * 150); k.ring(1200, t + 0.15, 0.4, 0.2 * v, { verb: 0.25 }); k.thump(t + 0.15, 0.2 * v, 120, 0.1); };
  S.cig_light = (k, t, v) => { k.noise(t, 0.6, 0.12 * v, { ft: 'highpass', f0: 3000, q: 0.5, a: 0.02 }); k.noise(t + 0.1, 0.9, 0.05 * v, { ft: 'bandpass', f0: 5000, q: 2 }); };
  S.lighter_open = (k, t, v) => { k.click(t, 0.3 * v, 1100); k.ring(2600, t + 0.01, 0.35, 0.12 * v, { verb: 0.2 }); };
  S.lighter_flick = (k, t, v) => { k.noise(t, 0.07, 0.3 * v, { ft: 'highpass', f0: 2500, q: 0.7, a: 0.001 }); k.click(t, 0.3 * v, 2500); k.noise(t + 0.05, 0.12, 0.12 * v, { ft: 'bandpass', f0: 1500, q: 1 }); };
  S.lighter_close = (k, t, v) => { k.click(t, 0.3 * v, 800); k.ring(2200, t, 0.2, 0.1 * v); };
  S.flame_whoosh = (k, t, v) => k.noise(t, 0.35, 0.14 * v, { ft: 'bandpass', f0: 500, f1: 1200, q: 0.5, a: 0.04 });
  S.puff = (k, t, v) => k.noise(t, 0.25, 0.1 * v, { ft: 'lowpass', f0: 1800, f1: 400, q: 0.5, a: 0.01 });
  S.burn = (k, t, v) => { k.noise(t, 1.1, 0.2 * v, { ft: 'bandpass', f0: 3500, f1: 1200, q: 0.8, a: 0.05 }); for (let i = 0; i < 12; i++) k.click(t + Math.random() * 1.0, 0.08 * v, 1800 + Math.random() * 2000); };
  S.smoke_exhale = (k, t, v) => k.noise(t, 1.4, 0.14 * v, { ft: 'bandpass', f0: 1800, f1: 700, q: 0.4, a: 0.35, verb: 0.2 });
  S.battery_insert = (k, t, v) => { k.click(t, 0.3 * v, 900); k.thump(t + 0.02, 0.35 * v, 150, 0.1); k.ring(1500, t + 0.04, 0.3, 0.12 * v); k.tone('sine', 2200, 2200, t + 0.1, 0.07, 0.06 * v); };
  S.zap = (k, t, v) => { k.noise(t, 0.3, 0.24 * v, { ft: 'highpass', f0: 2500, f1: 7000, q: 1, a: 0.001, verb: 0.2 }); k.tone('sawtooth', 1800, 120, t, 0.22, 0.12 * v, { a: 0.002, f: 3000 }); for (let i = 0; i < 6; i++) k.click(t + i * 0.03, 0.14 * v, 2000 + Math.random() * 2500); };
  S.pill_rattle = (k, t, v) => { for (let i = 0; i < 9; i++) k.tone('triangle', 2500 + Math.random() * 1500, 1800, t + i * 0.055 + Math.random() * 0.02, 0.03, 0.09 * v, { a: 0.001 }); };
  S.bottle_open = (k, t, v) => { k.tone('square', 500, 380, t, 0.05, 0.12 * v, { a: 0.001, f: 1500 }); k.noise(t, 0.12, 0.1 * v, { ft: 'bandpass', f0: 1200, q: 1 }); k.thump(t + 0.06, 0.15 * v, 260, 0.08); };
  S.gulp = (k, t, v) => { k.tone('sine', 140, 90, t, 0.14, 0.2 * v, { a: 0.02 }); k.tone('sine', 120, 70, t + 0.2, 0.14, 0.18 * v, { a: 0.02 }); k.noise(t, 0.35, 0.05 * v, { ft: 'lowpass', f0: 900, q: 0.5 }); };
  S.can_open = (k, t, v) => { k.click(t, 0.3 * v, 1800); k.noise(t + 0.03, 0.5, 0.22 * v, { ft: 'highpass', f0: 4000, f1: 2500, q: 0.7, a: 0.005 }); k.ring(1700, t, 0.12, 0.06 * v); };
  S.can_fizz = (k, t, v) => k.noise(t, 1.0, 0.09 * v, { ft: 'highpass', f0: 5500, q: 0.5, a: 0.05 });
  S.can_crush = (k, t, v) => { for (let i = 0; i < 6; i++) k.tone('square', 600 + Math.random() * 1400, 300, t + i * 0.035, 0.05, 0.1 * v, { a: 0.001, f: 3000 }); k.noise(t, 0.3, 0.2 * v, { ft: 'bandpass', f0: 1800, q: 0.6 }); };
  S.device_beep = (k, t, v) => { k.tone('square', 1320, 1320, t, 0.09, 0.07 * v, { a: 0.003, f: 2800 }); k.tone('square', 1760, 1760, t + 0.12, 0.09, 0.07 * v, { a: 0.003, f: 2800 }); };
  S.device_dial = (k, t, v) => { for (let i = 0; i < 12; i++) k.click(t + i * 0.045, 0.14 * v, 1000 + i * 90); };
  S.glitch = (k, t, v) => { for (let i = 0; i < 7; i++) k.tone('square', 200 + Math.random() * 3000, 100 + Math.random() * 500, t + i * 0.04, 0.05, 0.08 * v, { a: 0.001, f: 4000 }); k.noise(t, 0.3, 0.14 * v, { ft: 'bandpass', f0: 4000, f1: 800, q: 3, a: 0.001 }); };
  S.coin_flip = (k, t, v) => { k.ring(3200, t, 0.9, 0.1 * v, { verb: 0.25 }); k.tone('sine', 3180, 3260, t, 0.9, 0.03 * v, { a: 0.02 }); k.noise(t, 0.08, 0.05 * v, { ft: 'highpass', f0: 3000 }); };
  S.coin_catch = (k, t, v) => { k.ring(2600, t, 0.3, 0.1 * v); k.click(t, 0.2 * v, 1600); };
  S.gun_pickup = (k, t, v) => { k.thump(t, 0.3 * v, 110, 0.12); k.noise(t, 0.2, 0.1 * v, { ft: 'bandpass', f0: 900, q: 1 }); k.ring(800, t + 0.02, 0.25, 0.05 * v); };
  S.gun_cock = (k, t, v) => { k.click(t, 0.4 * v, 700); k.thump(t + 0.01, 0.4 * v, 140, 0.08); k.ring(1100, t + 0.02, 0.35, 0.12 * v, { verb: 0.3 }); k.click(t + 0.14, 0.45 * v, 1000); k.thump(t + 0.15, 0.3 * v, 100, 0.1); };
  S.gun_breech_open = (k, t, v) => { k.click(t, 0.3 * v, 600); k.ring(700, t + 0.02, 0.4, 0.12 * v, { verb: 0.3 }); k.noise(t, 0.2, 0.08 * v, { ft: 'bandpass', f0: 700, q: 2 }); };
  S.gun_breech_close = (k, t, v) => { k.thump(t, 0.4 * v, 120, 0.1); k.click(t, 0.4 * v, 900); k.ring(900, t + 0.01, 0.4, 0.14 * v, { verb: 0.3 }); };
  S.gun_load_shell = (k, t, v) => { k.click(t, 0.25 * v, 1400); k.tone('triangle', 900, 600, t, 0.05, 0.14 * v); k.thump(t + 0.04, 0.12 * v, 200, 0.06); };
  S.gun_fire = (k, t, v) => {
    k.noise(t, 0.09, 0.6 * v, { ft: 'lowpass', f0: 9000, f1: 1500, q: 0.5, a: 0.001 });
    k.noise(t, 0.6, 0.35 * v, { ft: 'lowpass', f0: 3000, f1: 200, q: 0.5, a: 0.002, verb: 0.9 });
    k.tone('sine', 150, 28, t, 0.55, 0.55 * v, { a: 0.001 });
    k.tone('sawtooth', 380, 60, t, 0.12, 0.25 * v, { a: 0.001, f: 1800 });
    k.noise(t + 0.08, 1.6, 0.2 * v, { ft: 'lowpass', f0: 900, f1: 120, q: 0.4, a: 0.1, verb: 1.0 });
    k.ring(3000, t + 0.12, 0.3, 0.05 * v, { verb: 0.6 });
  };
  S.gun_dry = (k, t, v) => { k.click(t, 0.4 * v, 800); k.thump(t, 0.3 * v, 100, 0.1); k.noise(t + 0.02, 0.25, 0.14 * v, { ft: 'lowpass', f0: 1200, f1: 300, q: 0.5, a: 0.01, verb: 0.3 }); };
  S.shell_drop = (k, t, v) => { for (let i = 0; i < 3; i++) k.tone('triangle', 2200 - i * 300, 1500 - i * 200, t + i * 0.09 * (1 + i * 0.3), 0.06, 0.16 * v / (1 + i * 0.5), { a: 0.001 }); k.thump(t, 0.1 * v, 200, 0.05); };
  S.shell_reveal = (k, t, v) => { k.ring(1400, t, 0.35, 0.1 * v, { verb: 0.3 }); k.tone('sine', 220, 110, t, 0.4, 0.1 * v, { a: 0.02 }); };
  S.impact_hit = (k, t, v) => { k.thump(t, 0.8 * v, 80, 0.35); k.noise(t, 0.3, 0.3 * v, { ft: 'lowpass', f0: 2200, f1: 300, q: 0.5, a: 0.001, verb: 0.4 }); k.tone('sawtooth', 220, 50, t, 0.3, 0.15 * v, { f: 600, a: 0.002 }); };
  S.heartbeat = (k, t, v) => { k.thump(t, 0.7 * v, 62, 0.18); k.thump(t + 0.26, 0.5 * v, 55, 0.18); };
  S.round_start = (k, t, v) => { k.tone('sine', 55, 55, t, 2.4, 0.4 * v, { a: 0.9, verb: 0.5 }); k.tone('sawtooth', 110, 112, t, 2.4, 0.07 * v, { a: 1.0, f: 400, verb: 0.5 }); k.noise(t, 2.2, 0.14 * v, { ft: 'bandpass', f0: 200, f1: 1600, q: 0.6, a: 1.2, verb: 0.5 }); k.thump(t + 2.2, 0.7 * v, 50, 0.5); };
  S.stinger = (k, t, v) => { k.tone('sawtooth', 70, 66, t, 1.6, 0.18 * v, { a: 0.01, f: 500, verb: 0.7 }); k.ring(466, t, 1.6, 0.14 * v, { verb: 0.8 }); k.ring(493, t, 1.6, 0.1 * v, { verb: 0.8 }); k.thump(t, 0.5 * v, 55, 0.5); };
  S.win_sting = (k, t, v) => { [196, 247, 294, 392].forEach((f, i) => k.tone('sine', f, f, t + i * 0.22, 2.2, 0.1 * v, { a: 0.05, verb: 0.8 })); k.tone('sine', 98, 98, t, 3, 0.2 * v, { a: 0.2, verb: 0.5 }); };
  S.lose_sting = (k, t, v) => { [147, 139, 131, 98].forEach((f, i) => k.tone('sawtooth', f, f * 0.97, t + i * 0.35, 2.2, 0.07 * v, { a: 0.1, f: 500, verb: 0.9 })); k.thump(t + 1.2, 0.8 * v, 45, 0.9); k.noise(t, 3, 0.1 * v, { ft: 'lowpass', f0: 600, f1: 80, q: 0.5, a: 0.3, verb: 0.8 }); };

  A.requiredSfx = Object.keys(S);

  /* ------------------------------------------------------------ context & buses */
  function impulse(c, secs) {
    const len = Math.floor(c.sampleRate * secs), b = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); let s = 777 + ch * 91; for (let i = 0; i < len; i++) { s = (s * 1664525 + 1013904223) | 0; d[i] = (((s >>> 8) / 8388608) - 1) * Math.pow(1 - i / len, 2.6); } }
    return b;
  }
  A.init = function () {
    if (ctx) return true;
    const AC = G.AudioContext || G.webkitAudioContext;
    if (!AC) return false;
    try {
      ctx = new AC({ latencyHint: 'interactive' });
      noiseBuf = makeNoise(ctx);
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 5; comp.attack.value = 0.004; comp.release.value = 0.2;
      const master = ctx.createGain(); master.connect(comp); comp.connect(ctx.destination);
      bus.master = master; bus.comp = comp;
      for (const n of ['music', 'ambience', 'sfx', 'voice']) { const g = ctx.createGain(); g.connect(master); bus[n] = g; }
      const conv = ctx.createConvolver(); conv.buffer = impulse(ctx, 2.4);
      const vg = ctx.createGain(); vg.gain.value = 0.55; verbIn = ctx.createGain(); verbIn.connect(conv); conv.connect(vg);
      vg.connect(bus.sfx);
      const vgm = ctx.createGain(); vgm.gain.value = 0.7; conv.connect(vgm); vgm.connect(bus.music); // light shared tail for music
      bus.duck = ctx.createGain(); bus.duck.connect(master);
      A.applyVolumes();
      A.ready = true;
    } catch (e) { console.warn('[audio] init failed', e); ctx = null; return false; }
    return true;
  };
  A.unlock = function () {
    if (!A.init()) return;
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    if (!A.unlocked) { A.unlocked = true; startAmbience(); startMusic(); }
  };
  A.applyVolumes = function () {
    if (!ctx) return;
    const t = ctx.currentTime, V = A.vol, set = (n, v) => { try { bus[n].gain.cancelScheduledValues(t); bus[n].gain.setTargetAtTime(v, t, 0.05); } catch (e) { /* ignore */ } };
    set('master', V.master); set('music', V.music * 0.7); set('ambience', V.ambience * (A.paused ? 0.35 : 1)); set('sfx', V.sfx); set('voice', V.voice);
  };
  A.applySettings = function (s) {
    A.vol.master = s.master; A.vol.music = s.music; A.vol.ambience = s.ambience; A.vol.sfx = s.sfx; A.vol.voice = s.voice;
    A.applyVolumes();
  };
  A.setPaused = function (p) {
    A.paused = p; A.applyVolumes();
    if (ctx) { if (p && A.unlocked) { try { bus.music.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.1); } catch (e) { /* ignore */ } } }
  };
  A.suspend = function () { if (ctx && ctx.state === 'running') ctx.suspend().catch(() => {}); };
  A.resume = function () { if (ctx && A.unlocked && ctx.state === 'suspended') ctx.resume().catch(() => {}); };

  /* ------------------------------------------------------------ playback */
  A.sfx = function (name, o) {
    o = o || {};
    A.stats.played++;
    if (!ctx || !A.unlocked || ctx.state !== 'running') { A.stats.dropped++; return false; }
    const fn = S[name];
    if (!fn) { if (!A._warned) A._warned = {}; if (!A._warned[name]) { A._warned[name] = 1; console.warn('[audio] missing sfx', name); } A.stats.dropped++; return false; }
    const now = ctx.currentTime;
    if (lastPlayed[name] !== undefined && now - lastPlayed[name] < (o.minGap || 0.035)) { A.stats.throttled++; return false; } // duplicate guard
    lastPlayed[name] = now;
    if (live > 36) { A.stats.dropped++; return false; } // polyphony cap
    live++; setTimeout(() => { live--; }, 700);
    let dest = bus.sfx;
    if (o.pan !== undefined && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = U.clamp(o.pan, -1, 1); p.connect(bus.sfx); dest = p; }
    const k = Kit(ctx, dest, noiseBuf, verbIn);
    try { fn(k, now + (o.delay || 0), (o.vol === undefined ? 1 : o.vol)); } catch (e) { console.warn('[audio] sfx error', name, e); return false; }
    return true;
  };

  /* Render one sfx offline (for the in-browser audio self-test). Returns {peak, rms, dur}. */
  A.renderTest = async function (name) {
    const OC = G.OfflineAudioContext || G.webkitOfflineAudioContext;
    const oc = new OC(1, 44100 * 4, 44100);
    const nb = makeNoise(oc);
    const out = oc.createGain(); out.connect(oc.destination);
    const conv = oc.createConvolver(); conv.buffer = impulse(oc, 1.5); const vin = oc.createGain(); vin.connect(conv); conv.connect(out);
    S[name](Kit(oc, out, nb, vin), 0.02, 1);
    const buf = await oc.startRendering(); const d = buf.getChannelData(0);
    let peak = 0, sum = 0, last = 0;
    for (let i = 0; i < d.length; i++) { const a = Math.abs(d[i]); if (a > peak) peak = a; sum += d[i] * d[i]; if (a > 0.003) last = i; }
    return { name, peak, rms: Math.sqrt(sum / d.length), dur: last / 44100 };
  };

  /* ------------------------------------------------------------ ambience bed */
  const amb = { nodes: [], next: 0, t: 0, buzz: null };
  function startAmbience() {
    const c = ctx, out = bus.ambience;
    const mk = (type, f, vol, filt) => { const o = c.createOscillator(), g = c.createGain(); o.type = type; o.frequency.value = f; g.gain.value = vol; o.connect(g); if (filt) { const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = filt; g.connect(fl); fl.connect(out); } else g.connect(out); o.start(); return { o, g }; };
    amb.nodes.push(mk('sine', 48, 0.16), mk('sine', 96.4, 0.07), mk('sawtooth', 50.2, 0.03, 220)); // industrial hum
    const buzz = mk('sawtooth', 100, 0.012, 1400); amb.buzz = buzz; amb.nodes.push(buzz);   // mains buzz
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 0.07; lg.gain.value = 0.03; lfo.connect(lg); lg.connect(amb.nodes[0].g.gain); lfo.start();
    const room = c.createBufferSource(); room.buffer = noiseBuf; room.loop = true;
    const rf = c.createBiquadFilter(); rf.type = 'lowpass'; rf.frequency.value = 380; const rg = c.createGain(); rg.gain.value = 0.05; room.connect(rf); rf.connect(rg); rg.connect(out); room.start(); // room tone
  }
  A.buzzSpike = function (amt) { if (!ctx || !amb.buzz) return; const t = ctx.currentTime, g = amb.buzz.g.gain; g.cancelScheduledValues(t); g.setValueAtTime(0.012, t); g.linearRampToValueAtTime(0.012 + 0.06 * (amt || 1), t + 0.02); g.linearRampToValueAtTime(0.012, t + 0.25); };

  /* ------------------------------------------------------------ generative music */
  const mus = { tension: 0.2, next: 0, drone: null, pulse: null, mode: 'menu', beat: 0 };
  const SCALE = [0, 1, 3, 5, 7, 8, 10]; // phrygian — sparse unsettling notes
  function startMusic() {
    const c = ctx, out = bus.music;
    const pad = (f, vol) => { const o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter(); o.type = 'sawtooth'; o2.type = 'sawtooth'; o.frequency.value = f; o2.frequency.value = f * 1.004; fl.type = 'lowpass'; fl.frequency.value = 260; fl.Q.value = 2; g.gain.value = vol; o.connect(fl); o2.connect(fl); fl.connect(g); g.connect(out); o.start(); o2.start();
      const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = 0.05 + Math.random() * 0.05; lg.gain.value = 120; l.connect(lg); lg.connect(fl.frequency); l.start(); return { g, fl }; };
    mus.drone = [pad(36.7, 0.1), pad(55, 0.06), pad(73.4, 0.03)];
    mus.high = (function () { const o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = 622; g.gain.value = 0; o.connect(g); g.connect(out); o.start(); const l = c.createOscillator(), lg = c.createGain(); l.frequency.value = 0.13; lg.gain.value = 6; l.connect(lg); lg.connect(o.frequency); l.start(); return g; })();
    mus.t = 0;
  }
  A.setTension = function (x) { mus.tension = U.clamp(x, 0, 1); };
  A.setMusicMode = function (m) { mus.mode = m; };
  A.stinger = function (kind) { A.sfx(kind === 'win' ? 'win_sting' : kind === 'lose' ? 'lose_sting' : kind === 'round' ? 'round_start' : 'stinger'); };

  /* per-frame (game-time) update: sparse notes, tension pulse, ambience events */
  A.update = function (dt) {
    if (!ctx || !A.unlocked || A.paused || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    mus.t += dt; amb.t += dt;
    try {
      const tn = mus.tension;
      mus.drone[1].g.gain.setTargetAtTime(0.03 + tn * 0.1, t, 0.8);
      mus.drone[2].g.gain.setTargetAtTime(0.01 + tn * 0.06, t, 0.8);
      mus.drone[0].fl.frequency.setTargetAtTime(220 + tn * 320, t, 1.5);
      mus.high.gain.setTargetAtTime(Math.max(0, tn - 0.55) * 0.05, t, 1.2);
      bus.music.gain.setTargetAtTime(A.vol.music * 0.7, t, 0.3);
    } catch (e) { /* ignore */ }
    if (mus.t > mus.next) { // sparse note with long reverb tail, then silence
      const k = Kit(ctx, bus.music, noiseBuf, verbIn);
      const deg = SCALE[Math.floor(Math.random() * SCALE.length)], f = 146.8 * Math.pow(2, (deg + (Math.random() < 0.3 ? 12 : 0)) / 12);
      k.tone('sine', f, f, t, 4.5, 0.06, { a: 0.6, verb: 1.4 }); k.tone('sine', f * 2.005, f * 2.005, t, 3, 0.015, { a: 0.4, verb: 1.2 });
      mus.next = mus.t + 6 + Math.random() * 12 * (1.4 - mus.tension) + (Math.random() < 0.25 ? 10 : 0); // carefully timed silences
    }
    mus.beat -= dt;
    if (mus.tension > 0.45 && mus.beat <= 0) { A.sfx('heartbeat', { vol: 0.25 + mus.tension * 0.35, minGap: 0.2 }); mus.beat = 1.25 - mus.tension * 0.55; }
    if (amb.t > amb.next) { // metallic creaks, distant impacts, electrical blips, distant machinery
      const r = Math.random(), k = Kit(ctx, bus.ambience, noiseBuf, verbIn);
      if (r < 0.35) A.sfx('creak', { vol: 0.4, pan: Math.random() * 2 - 1 });
      else if (r < 0.6) { k.thump(t, 0.18, 52 + Math.random() * 20, 0.5); k.noise(t, 0.6, 0.05, { ft: 'lowpass', f0: 400, q: 0.5, verb: 1.2 }); }
      else if (r < 0.8) A.buzzSpike(0.6);
      else { k.tone('square', 62, 58, t, 1.6, 0.012, { a: 0.4, f: 300 }); k.noise(t, 1.6, 0.025, { ft: 'bandpass', f0: 500, q: 3, a: 0.5 }); }
      amb.next = amb.t + 5 + Math.random() * 14;
    }
  };

  /* ------------------------------------------------------------ Dealer voice (formant synthesis) */
  const VOWELS = [[700, 1100], [500, 1700], [300, 2300], [450, 800], [320, 800], [600, 1000]];
  function lineSeed(text) { let h = 2166136261; for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  A.voiceDuration = function (text, mood) {
    const n = Math.max(1, text.replace(/[^\p{L}\p{N}]/gu, '').length);
    if (mood === 'laugh') return 1.5;
    return U.clamp(n * (mood === 'whisper' ? 0.085 : 0.07) + 0.45, 0.9, 4.2);
  };
  /* returns duration in seconds. mood: normal|whisper|laugh|murmur|glitch */
  A.speak = function (text, mood) {
    mood = mood || 'normal';
    const dur = A.voiceDuration(text, mood);
    if (!ctx || !A.unlocked || ctx.state !== 'running') return dur;
    const c = ctx, t0 = c.currentTime + 0.03;
    let h = lineSeed(text + mood); const rnd = () => { h = (Math.imul(h, 1664525) + 1013904223) >>> 0; return h / 4294967296; };
    const out = c.createGain(); out.gain.value = 1;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = mood === 'whisper' ? 5000 : 2600; out.connect(lp);
    const shaper = c.createWaveShaper(); const curve = new Float32Array(256); const amt = mood === 'glitch' ? 40 : 14;
    for (let i = 0; i < 256; i++) { const x = i / 128 - 1; curve[i] = Math.tanh(x * amt * 0.15) * 0.9 + (mood === 'glitch' ? Math.sin(x * 12) * 0.2 : 0); }
    shaper.curve = curve; lp.connect(shaper);
    const dry = c.createGain(); dry.gain.value = 0.9; shaper.connect(dry); dry.connect(bus.voice);
    const send = c.createGain(); send.gain.value = 0.7; shaper.connect(send); send.connect(verbIn);
    // duck music + ambience while the Dealer speaks
    try { const tt = c.currentTime; bus.music.gain.setTargetAtTime(A.vol.music * 0.7 * 0.45, tt, 0.05); setTimeout(() => { if (ctx) bus.music.gain.setTargetAtTime(A.vol.music * 0.7, ctx.currentTime, 0.4); }, dur * 1000 + 100); } catch (e) { /* ignore */ }
    const base = mood === 'whisper' ? 0 : 58 + rnd() * 22;
    const kit = Kit(c, out, noiseBuf, null);
    if (mood === 'laugh') {
      let t = t0, n = 5 + Math.floor(rnd() * 3), gap = 0.12;
      for (let i = 0; i < n; i++) {
        const f = (95 - i * 6) * (0.95 + rnd() * 0.1);
        voiced(c, out, t, 0.11, f, f * 0.8, VOWELS[0], 0.55 - i * 0.05, rnd);
        kit.noise(t, 0.07, 0.05, { ft: 'bandpass', f0: 1800, q: 1, dest: out }); // breath
        t += gap; gap *= 1.12;
      }
      return dur;
    }
    const clean = text.replace(/[^\p{L}\p{N}\s]/gu, ' ').trim().split(/\s+/);
    const perChar = (dur - 0.45) / Math.max(1, clean.join('').length);
    let t = t0 + 0.05, pitch = base;
    for (const w of clean) {
      const syl = Math.max(1, Math.round(w.length / 2.6));
      for (let s = 0; s < syl; s++) {
        const v = VOWELS[Math.floor(rnd() * VOWELS.length)], d = Math.max(0.07, perChar * (w.length / syl) * 0.9);
        pitch = U.clamp(pitch + (rnd() - 0.5) * 14, mood === 'murmur' ? 50 : 48, 95);
        if (mood === 'whisper') {
          const nz = c.createBufferSource(); nz.buffer = noiseBuf; const g = c.createGain(), f1 = c.createBiquadFilter(), f2 = c.createBiquadFilter();
          f1.type = f2.type = 'bandpass'; f1.frequency.value = v[0] * 2.2; f2.frequency.value = v[1] * 1.6; f1.Q.value = f2.Q.value = 5;
          g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.5, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
          nz.connect(f1); nz.connect(f2); f1.connect(g); f2.connect(g); g.connect(out); nz.start(t, rnd() * 1.4, d + 0.05);
        } else voiced(c, out, t, d, pitch * (1.05 - s * 0.04), pitch * (0.9 + rnd() * 0.15), v, mood === 'murmur' ? 0.35 : 0.5, rnd);
        t += d + 0.012;
      }
      t += 0.05 + (rnd() < 0.25 ? 0.12 + rnd() * 0.2 : 0); // unnatural pauses
    }
    if (mood !== 'whisper') kit.noise(t0 - 0.02, 0.18, 0.05, { ft: 'bandpass', f0: 1200, q: 0.7, dest: out }); // intake breath
    return dur;
  };
  function voiced(c, out, t, d, f0, f1, vow, vol, rnd) {
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.03, d * 0.3)); g.gain.setValueAtTime(vol, t + d * 0.7); g.gain.exponentialRampToValueAtTime(0.0001, t + d); g.connect(out);
    const f1b = c.createBiquadFilter(), f2b = c.createBiquadFilter(), f3 = c.createBiquadFilter();
    f1b.type = f2b.type = f3.type = 'bandpass'; f1b.frequency.value = vow[0] * 0.8; f2b.frequency.value = vow[1] * 0.7; f3.frequency.value = 2400; f1b.Q.value = 6; f2b.Q.value = 7; f3.Q.value = 4;
    [[f1b, 1], [f2b, 0.7], [f3, 0.25]].forEach(([f, gain]) => { const m = c.createGain(); m.gain.value = gain; f.connect(m); m.connect(g); });
    for (const [mult, type, amp, det] of [[1, 'sawtooth', 0.8, 0], [0.5, 'sawtooth', 0.7, 9], [1.006, 'square', 0.3, -7]]) {
      const o = c.createOscillator(), og = c.createGain(); o.type = type; o.detune.value = det;
      o.frequency.setValueAtTime(f0 * mult, t); o.frequency.exponentialRampToValueAtTime(Math.max(30, f1 * mult), t + d);
      const vib = c.createOscillator(), vg = c.createGain(); vib.frequency.value = 5 + rnd() * 3; vg.gain.value = f0 * 0.015; vib.connect(vg); vg.connect(o.frequency); vib.start(t); vib.stop(t + d + 0.05);
      og.gain.value = amp; o.connect(og); og.connect(f1b); og.connect(f2b); og.connect(f3); o.start(t); o.stop(t + d + 0.05);
    }
  }

  G.AudioMgr = A;
  if (typeof module !== 'undefined' && module.exports) module.exports = A;
})(typeof window !== 'undefined' ? window : globalThis);
