/* util.js — math, easing, seeded RNG (serialisable), i18n helper. */
(function (G) {
  'use strict';
  const U = {};
  U.TAU = Math.PI * 2;
  U.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  U.lerp = (a, b, t) => a + (b - a) * t;
  U.rnd = (a, b) => a + Math.random() * (b - a); // visual-only randomness (never gameplay)

  U.ease = {
    lin: (t) => t,
    in: (t) => t * t,
    out: (t) => 1 - (1 - t) * (1 - t),
    inout: (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
    back: (t) => { const c = 1.70158, d = c + 1; return 1 + d * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); },
    snap: (t) => (t >= 1 ? 1 : 0),
    cubic: (t) => 1 - Math.pow(1 - t, 3)
  };

  /* Gameplay RNG: mulberry32 whose whole state is one int stored in game state (st.r),
     so runs are reproducible from a seed and resumable from a save. */
  U.Rand = {
    next(st) {
      st.r = (st.r + 0x6D2B79F5) | 0;
      let t = Math.imul(st.r ^ (st.r >>> 15), 1 | st.r);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    },
    int(st, a, b) { return a + Math.floor(U.Rand.next(st) * (b - a + 1)); },
    pick(st, arr) { return arr[Math.floor(U.Rand.next(st) * arr.length)]; },
    shuffle(st, arr) {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(U.Rand.next(st) * (i + 1));
        const x = arr[i]; arr[i] = arr[j]; arr[j] = x;
      }
      return arr;
    },
    weighted(st, entries) {
      let tot = 0; for (const e of entries) tot += e[1];
      let r = U.Rand.next(st) * tot;
      for (const e of entries) { r -= e[1]; if (r <= 0) return e[0]; }
      return entries[entries.length - 1][0];
    }
  };

  U.lang = 'en';
  U.t = function (key, params) {
    const S = G.GameData.strings;
    let s = (S[U.lang] && S[U.lang][key]);
    if (s === undefined) s = S.en[key];
    if (s === undefined) s = key;
    if (params) s = s.replace(/\{(\w+)\}/g, (m, k) => (params[k] !== undefined ? params[k] : m));
    return s;
  };
  U.line = function (cat, params, lang, r) { // dealer dialogue variants; same r gives the same variant in any language
    const L = G.GameData.lines, lg = lang || U.lang;
    const arr = (L[lg] && L[lg][cat]) || L.en[cat] || [cat];
    const s = arr[Math.floor((r === undefined ? Math.random() : r) * arr.length) % arr.length];
    return params ? s.replace(/\{(\w+)\}/g, (m, k) => (params[k] !== undefined ? params[k] : m)) : s;
  };

  G.U = U;
})(typeof window !== 'undefined' ? window : globalThis);
