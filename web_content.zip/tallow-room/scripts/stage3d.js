/* stage3d.js — the 3D world. It does NOT own any game logic: it reads the same rig values the 2D renderer used
   (Anim.player/dealer/gun .p, Renderer.scene, Physics bodies) and places real 3D meshes in a real 3D room.
   The animation clips keep working unchanged because logical screen coordinates are mapped into the 3D world by
   casting a ray through the camera (Cam.ray) onto the table / dealer planes, so every effect that was positioned
   in logical coordinates stays aligned with the 3D objects (Cam.project is the exact inverse). */
(function (G) {
  'use strict';
  const GL = G.GL3D, M = GL.M, Geo = GL.Geo, rgb = GL.rgb, sin = Math.sin, cos = Math.cos, PI = Math.PI, sqrt = Math.sqrt;
  const S = { active: false, ready: false, h: null };

  /* ------------------------------------------------------------------ camera + mapping logical <-> world */
  const FOC = 900;                       // focal length in logical pixels (logical canvas is 1280x720)
  const TABLE_Y = 0.9;
  const Cam = S.Cam = { eye: [0, 1.5, 1.78], tgt: [0, 0.86, -0.75], f: [0, 0, -1], r: [1, 0, 0], u: [0, 1, 0] };
  function camBasis() {
    const e = Cam.eye, t = Cam.tgt; let fx = t[0] - e[0], fy = t[1] - e[1], fz = t[2] - e[2]; const l = sqrt(fx * fx + fy * fy + fz * fz); fx /= l; fy /= l; fz /= l;
    let rx = fy * 0 - fz * 1, ry = fz * 0 - fx * 0, rz = fx * 1 - fy * 0; // f x up(0,1,0)
    rx = -fz; ry = 0; rz = fx; const rl = sqrt(rx * rx + rz * rz); rx /= rl; rz /= rl;
    const ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
    Cam.f = [fx, fy, fz]; Cam.r = [rx, ry, rz]; Cam.u = [ux, uy, uz];
  }
  Cam.ray = function (lx, ly) {
    const x = (lx - 640) / FOC, y = -(ly - 360) / FOC, f = Cam.f, r = Cam.r, u = Cam.u;
    let dx = f[0] + r[0] * x + u[0] * y, dy = f[1] + r[1] * x + u[1] * y, dz = f[2] + r[2] * x + u[2] * y; const l = sqrt(dx * dx + dy * dy + dz * dz);
    return [dx / l, dy / l, dz / l];
  };
  Cam.onY = function (lx, ly, h) { const d = Cam.ray(lx, ly), e = Cam.eye, t = (h - e[1]) / d[1]; return [e[0] + d[0] * t, h, e[2] + d[2] * t, t]; };
  Cam.onZ = function (lx, ly, z) { const d = Cam.ray(lx, ly), e = Cam.eye, t = (z - e[2]) / d[2]; return [e[0] + d[0] * t, e[1] + d[1] * t, z, t]; };
  Cam.project = function (p) {
    const e = Cam.eye, vx = p[0] - e[0], vy = p[1] - e[1], vz = p[2] - e[2], f = Cam.f, r = Cam.r, u = Cam.u;
    const zc = vx * f[0] + vy * f[1] + vz * f[2]; if (zc <= 0.01) return { x: 640, y: 360, z: zc };
    return { x: 640 + (vx * r[0] + vy * r[1] + vz * r[2]) / zc * FOC, y: 360 - (vx * u[0] + vy * u[1] + vz * u[2]) / zc * FOC, z: zc };
  };
  /* world size (m) of one logical pixel at distance d */
  const pxw = (d) => d / FOC;

  /* ------------------------------------------------------------------ meshes + materials */
  const Me = {}, Ma = {};
  function buildAssets() {
    const mk = (g) => GL.mesh(g);
    Me.box = mk(Geo.box(1, 1, 1)); Me.sph = mk(Geo.sphere(1, 14, 9)); Me.sphL = mk(Geo.sphere(1, 8, 5)); Me.cyl = mk(Geo.cyl(1, 1, 1, 14)); Me.cylL = mk(Geo.cyl(1, 1, 1, 8)); Me.cone = mk(Geo.cone(1, 1, 18));
    Me.tor = mk(Geo.torus(1, 0.14, 24, 8)); Me.torT = mk(Geo.torus(1, 0.3, 16, 8)); Me.disc = mk(Geo.cyl(1, 1, 0.04, 20));
    Me.can = mk(Geo.lathe([[0.0001, 0], [0.8, 0], [0.86, 0.04], [1, 0.1], [1, 0.9], [0.9, 0.96], [0.84, 1], [0.0001, 1]], 18));
    Me.bottle = mk(Geo.lathe([[0.0001, 0], [0.92, 0], [1, 0.06], [1, 0.74], [0.84, 0.82], [0.5, 0.86], [0.46, 1], [0.0001, 1]], 16));
    Me.shell = mk(Geo.lathe([[0.0001, 0], [0.98, 0], [1, 0.05], [1, 1], [0.0001, 1]], 12));
    Me.skull = mk(Geo.sphere(1, 22, 14));
    const c = GL.rgb, m = GL.material;
    Ma.wood = m({ c: c('#6a3a22'), kind: 1, spec: 0.3, shin: 28 }); Ma.floor = m({ c: c('#3a2c28'), kind: 2, spec: 0.1, shin: 10 }); Ma.wall = m({ c: c('#4a2220'), kind: 2, spec: 0.05, shin: 8 });
    Ma.dark = m({ c: c('#1a1514'), spec: 0.4, shin: 30 }); Ma.metal = m({ c: c('#4a4846'), spec: 0.9, shin: 70 }); Ma.steel = m({ c: c('#b4b2ad'), spec: 1.0, shin: 90 }); Ma.brass = m({ c: c('#b6903e'), spec: 0.9, shin: 60 });
    Ma.gun = m({ c: c('#2c2b2d'), spec: 0.9, shin: 60 }); Ma.gunWood = m({ c: c('#7a4524'), spec: 0.45, shin: 40 });
    Ma.skinP = m({ c: c('#d9a58f'), kind: 4, spec: 0.3, shin: 26, rim: 0.2 }); Ma.skinD = m({ c: c('#c6b8a8'), kind: 4, spec: 0.25, shin: 22, rim: 0.2 });
    Ma.sleeveP = m({ c: c('#241b1a'), kind: 5, spec: 0.1, shin: 8 }); Ma.coat = m({ c: c('#1d1413'), kind: 5, spec: 0.12, shin: 10 }); Ma.cuff = m({ c: c('#8c1219'), spec: 0.3, shin: 20 });
    Ma.wax = m({ c: c('#e3d8bf'), kind: 6, spec: 0.45, shin: 34 }); Ma.black = m({ c: [0.005, 0.003, 0.003], spec: 0.05, shin: 8 }); Ma.tooth = m({ c: c('#e9e2cc'), spec: 0.5, shin: 36 });
    Ma.red = m({ c: c('#a3141b'), spec: 0.5, shin: 34 }); Ma.shellA = m({ c: c('#77746f'), spec: 0.4, shin: 30 }); Ma.paper = m({ c: c('#e6dcc6'), spec: 0.1, shin: 8 });
    Ma.glass = m({ c: c('#b9d4d0'), spec: 1, shin: 100, alpha: 0.28 }); Ma.amber = m({ c: c('#b0621e'), spec: 0.6, shin: 40, alpha: 0.9 });
    Ma.white = m({ c: c('#e8e2d8'), spec: 0.5, shin: 30 }); Ma.rope = m({ c: c('#8a5a2c'), kind: 5, spec: 0.1, shin: 8 }); Ma.canRed = m({ c: c('#7a1218'), spec: 0.8, shin: 60 }); Ma.canDark = m({ c: c('#1a1520'), spec: 0.8, shin: 60 });
    Ma.candle = m({ c: c('#eadfc6'), spec: 0.3, shin: 20 }); Ma.tvBody = m({ c: c('#241915'), spec: 0.4, shin: 30 });
    Ma.tv = m({ c: c('#101010'), kind: 3, em: [1, 0, 0], spec: 0.6 }); Ma.blood = m({ c: c('#4a0508'), spec: 0.9, shin: 80, alpha: 0.92, cast: false });
    Ma.glowFlame = m({ c: [0, 0, 0], em: [1.6, 0.8, 0.25] });
    Me.decal = mk(Geo.cyl(1, 1, 0.003, 14));
    MD.ok = false;
    if (G.MODELS && G.Rg) { try { buildModels(); } catch (e) { console.warn('[stage3d] GLB models failed, using the built-in primitives:', e && e.message); MD.ok = false; } }
  }
  /* ------------------------------------------------------------------ the three supplied GLB assets (decoded from data/models.js) */
  const MD = { ok: false };
  const TS = TABLE_Y / 1.66, TZ = 0.40, GSC = 0.26;      // table scale (top surface -> TABLE_Y), table centre z, gun scale
  function buildModels() {
    const MO = G.MODELS, Rg = G.Rg;
    MD.table = GL.mesh(Rg.decode(MO.table)); MD.tableMeta = MO.table.meta;
    const g = Rg.decode(MO.gun), gm = GL.mesh(g); MD.gun = {}; for (const gr of g.groups) MD.gun[gr.name] = GL.sub(gm, gr.start, gr.count); MD.gunMeta = MO.gun.meta;
    MD.dealer = GL.mesh(Rg.decode(MO.dealer)); MD.dMeta = MO.dealer.meta; MD.rig = new Rg.Rig(MD.dMeta.rig, GL.maxJoints);
    Ma.glbTable = GL.material({ c: [1.25, 1.15, 1.1], kind: 1, spec: 0.28, shin: 26 }); Ma.glbGun = GL.material({ c: [1.5, 1.5, 1.5], spec: 0.85, shin: 55 }); Ma.glbChar = GL.material({ c: [1.6, 1.6, 1.6], spec: 0.22, shin: 18, rim: 0.22 });
    const tm = MD.tableMeta; S.table = { x0: tm.top.x[0] * TS, x1: tm.top.x[1] * TS, z0: tm.top.z[0] * TS + TZ, z1: tm.top.z[1] * TS + TZ, y: tm.top.y * TS };
    G.Physics.clampFn = tableClamp;
    MD.ok = true;
  }
  /* keeps loose bodies on the GLB table top: converts the body to world space, limits it to the top surface, converts back */
  function tableClamp(b, k) {
    const T = S.table; if (!T) return false; const p = Cam.onY(640 + b.x, b.y, TABLE_Y), rw = (k.r || 8) * pxw(p[3]) * 0.6; let hit = false, x = p[0], z = p[2];
    if (x < T.x0 + rw) { x = T.x0 + rw; hit = true; b.vx = Math.abs(b.vx) * 0.45; } if (x > T.x1 - rw) { x = T.x1 - rw; hit = true; b.vx = -Math.abs(b.vx) * 0.45; }
    if (z < T.z0 + rw) { z = T.z0 + rw; hit = true; b.vy = Math.abs(b.vy) * 0.45; } if (z > T.z1 - rw) { z = T.z1 - rw; hit = true; b.vy = -Math.abs(b.vy) * 0.45; }
    if (hit) { const q = Cam.project([x, TABLE_Y, z]); b.x = q.x - 640; b.y = q.y; }
    return hit;
  }

  /* ------------------------------------------------------------------ small helpers */
  const tmpM = new Float32Array(16);
  function D(parent, mesh, mat, px, py, pz, ry, rx, rz, sx, sy, sz) { const l = M.trs(px, py, pz, ry, rx, rz, sx, sy, sz, tmpM); GL.draw(mesh, parent ? M.mul(parent, l) : l, mat); }
  function DA(parent, mesh, mat, px, py, pz, ry, rx, rz, sx, sy, sz) { const l = M.trs(px, py, pz, ry, rx, rz, sx, sy, sz, tmpM); GL.drawAdd(mesh, parent ? M.mul(parent, l) : l, mat); }
  const L = (a, b, t) => a + (b - a) * t;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function seg(a, b, r, mesh, mat) { // cylinder from a to b with radius r (mesh = unit cylinder along +Y 0..1)
    const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], len = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
    GL.draw(mesh, M.along(a, d, r, len), mat);
  }
  let TIME = 0;

  /* ------------------------------------------------------------------ room, table, lamp */
  const ROOM = { zFar: 0, zD: 0, zWall: 0 };
  function setupGeometryAnchors() {
    ROOM.zFar = Cam.onY(640, 396, TABLE_Y)[2]; ROOM.zD = ROOM.zFar - 0.5; ROOM.zWall = ROOM.zD - 1.5;
  }
  const BLOOD = [];
  S.bloodAt = function (who, n) { // persistent decals on the table (cleared each round)
    const p = who === 'p' ? Cam.onY(640 + (Math.random() - 0.5) * 300, 600, TABLE_Y) : Cam.onY(640 + (Math.random() - 0.5) * 240, 430, TABLE_Y);
    for (let i = 0; i < (n || 4); i++) BLOOD.push({ x: p[0] + (Math.random() - 0.5) * 0.35, z: p[2] + (Math.random() - 0.5) * 0.25, r: 0.015 + Math.random() * 0.05, sx: 0.8 + Math.random() * 0.8 });
    while (BLOOD.length > 40) BLOOD.shift();
  };
  S.clearBlood = function () { BLOOD.length = 0; };
  function drawRoom(R, Sc) {
    const zc = (ROOM.zFar + 1.6) / 2, zW = ROOM.zWall;
    // floor, ceiling, walls (big boxes)
    D(null, Me.box, Ma.floor, 0, -0.05, zc - 1.2, 0, 0, 0, 9, 0.1, 9);
    D(null, Me.box, Ma.wall, 0, 1.8, zW - 0.05, 0, 0, 0, 9, 4.2, 0.1);
    D(null, Me.box, Ma.wall, -3.4, 1.8, zc - 1.2, 0, 0, 0, 0.1, 4.2, 9); D(null, Me.box, Ma.wall, 3.4, 1.8, zc - 1.2, 0, 0, 0, 0.1, 4.2, 9);
    D(null, Me.box, Ma.floor, 0, 3.55, zc - 1.2, 0, 0, 0, 9, 0.1, 9);
    // ceiling pipes
    for (const [y, x, r] of [[3.35, -1.2, 0.09], [3.38, 0.9, 0.06], [3.3, 2.3, 0.12]]) D(null, Me.cyl, Ma.metal, x, y, zW + 2.5, 0, PI / 2, 0, r, 6, r);
    // speaker stack (left) with woofers
    for (let i = 0; i < 2; i++) { const y = 0.95 + i * 0.72; D(null, Me.box, Ma.dark, -2.15, y, zW + 0.35, 0.18, 0, 0, 0.9, 0.66, 0.5); D(null, Me.cyl, Ma.metal, -2.0, y, zW + 0.62, 0.18, PI / 2, 0, 0.24, 0.05, 0.24); D(null, Me.cyl, Ma.black, -2.0, y, zW + 0.66, 0.18, PI / 2, 0, 0.15, 0.04, 0.15); }
    // door (left) + wall panel with indicator lights
    D(null, Me.box, Ma.black, -2.9, 1.1, zW + 1.7, PI / 2 * 0.0, 0, 0, 0.08, 2.2, 1.0);
    if (Sc.doorLight > 0) DA(null, Me.box, GL.material({ c: [0, 0, 0], em: [1.8 * Sc.doorLight, 1.2 * Sc.doorLight, 0.7 * Sc.doorLight] }), -2.85, 1.1, zW + 1.7, 0, 0, 0, 0.02, 2.1, 0.9);
    D(null, Me.box, Ma.metal, 1.5, 1.95, zW + 0.02, 0, 0, 0, 0.5, 0.7, 0.05);
    for (let i = 0; i < 3; i++) D(null, Me.sphL, GL.material({ c: [0.2, 0, 0], em: [1.5 * (0.5 + 0.5 * sin(TIME * 2 + i * 2)), 0.05, 0.03] }), 1.5, 1.8 + i * 0.14, zW + 0.07, 0, 0, 0, 0.03, 0.03, 0.03);
    // shelf + two CRT televisions (right)
    D(null, Me.box, Ma.wood, 2.1, 1.2, zW + 0.7, 0, 0, 0, 1.4, 0.05, 0.7); D(null, Me.box, Ma.wood, 2.1, 2.15, zW + 0.7, 0, 0, 0, 1.0, 0.05, 0.6);
    const tvs = [[2.2, 1.2 + 0.03, 0.62, 0.5], [2.15, 2.15 + 0.03, 0.46, 0.38]];
    tvs.forEach((t, i) => { const [x, y, w, h] = t, z = zW + 0.7; D(null, Me.box, Ma.tvBody, x, y + h / 2, z, -0.16, 0, 0, w, h, 0.46);
      const mat = GL.material({ c: [0.02, 0.02, 0.02], em: [0.8 + (Sc.tvGlitch || 0) * 1.2, 0, 0], kind: 3, spec: 0.6 });
      const ml = M.trs(x, y + h / 2, z + 0.235, -0.16, 0, 0, 1, 1, 1); const m2 = M.mul(ml, M.trs(0, 0, 0, 0, 0, 0, w * 0.82, h * 0.8, 0.02)); GL.draw(Me.box, m2, mat); });
    // hanging cables
    for (let i = 0; i < 4; i++) { const x = -1.6 + i * 0.9; seg([x, 3.5, zW + 0.4], [x + 0.2, 2.6 - (i % 2) * 0.3, zW + 0.5], 0.012, Me.cylL, Ma.black); }
  }
  function drawTable(R, Sc) {
    if (MD.ok) D(null, MD.table, Ma.glbTable, 0, 0, TZ, 0, 0, 0, TS, TS, TS);
    else {
    const zNear = 1.7, zFar = ROOM.zFar, len = zNear - zFar, zc = (zNear + zFar) / 2;
    D(null, Me.box, Ma.wood, 0, TABLE_Y - 0.04, zc, 0, 0, 0, 2.5, 0.08, len);
    D(null, Me.box, Ma.dark, 0, TABLE_Y - 0.09, zc, 0, 0, 0, 2.58, 0.04, len + 0.08);
    for (const sx of [-1, 1]) for (const sz of [zFar + 0.1, zNear - 0.1]) D(null, Me.box, Ma.dark, sx * 1.12, TABLE_Y / 2 - 0.1, sz, 0, 0, 0, 0.12, TABLE_Y - 0.12, 0.12);
    }
    // painted slot outlines (thin dashed rectangles = flat boxes)
    for (const who of ['p', 'd']) for (let i = 0; i < 6; i++) { const w = R.slotWorld(who, i), p = Cam.onY(w.x, w.y, TABLE_Y + 0.002), s = who === 'p' ? 0.2 : 0.17;
      for (const [dx, dz, sx, sz] of [[0, -s / 2, s, 0.006], [0, s / 2, s, 0.006], [-s / 2, 0, 0.006, s], [s / 2, 0, 0.006, s]]) D(null, Me.box, GL.material({ c: rgb('#8a5a4a', 0.45), cast: false }), p[0] + dx, p[1], p[2] + dz, 0, 0, 0, sx, 0.002, sz); }
    // ash tray + blood decals
    const at = Cam.onY(1010, 540, TABLE_Y); D(null, Me.cyl, Ma.metal, at[0], TABLE_Y, at[2], 0, 0, 0, 0.13, 0.025, 0.13); D(null, Me.cyl, Ma.dark, at[0], TABLE_Y + 0.012, at[2], 0, 0, 0, 0.1, 0.02, 0.1);
    for (const b of BLOOD) D(null, Me.decal, Ma.blood, b.x, TABLE_Y + 0.003, b.z, 0, 0, 0, b.r * b.sx, 1, b.r);
  }

  /* ------------------------------------------------------------------ hands (palm + 5 fingers with curl) */
  /* h: {x,y,z world wrist, yaw, curl(c), idx(i), thumb(t), s scale, side(+1 left/-1 right), skin, sleeve, sleeveMat} */
  function drawHand(h) {
    const s = h.s, skin = h.skin, f = h.curl, ix = h.idx, th = h.thumb, side = h.side;
    const base = h.base || M.trs(h.x, h.y, h.z, h.yaw, h.pitch || 0, h.roll || 0, s, s, s);
    const pw = 0.092, pl = 0.1, pth = 0.03;
    D(base, Me.box, skin, 0, 0, -pl / 2, 0, 0, 0, pw, pth, pl);                // palm
    D(base, Me.sphL, skin, 0, 0, 0.002, 0, 0, 0, pw * 0.52, pth * 0.62, 0.04);  // heel of the hand
    // four fingers
    const xs = [-0.036, -0.012, 0.012, 0.036].map((x) => x * -side * 0 + x * 1);
    const lens = [[0.045, 0.032, 0.026], [0.05, 0.036, 0.028], [0.046, 0.034, 0.026], [0.036, 0.026, 0.02]];
    for (let k = 0; k < 4; k++) {
      // finger order across the hand: with side=+1 (left hand, thumb on the right) the index finger is on the right
      const fx = (side > 0 ? 1 : -1) * (-xs[k]) * -1; const idxFinger = side > 0 ? 3 - k : k; // 0 = index
      const curl = idxFinger === 0 ? ix : f, x = (side > 0 ? xs[3 - idxFinger] : xs[idxFinger]) * 1;
      let px = x, py = 0, pz = -pl, a = 0; const r0 = 0.0125 - idxFinger * 0.0006;
      for (let j = 0; j < 3; j++) {
        a += curl * (j === 0 ? 1.1 : 1.35) + 0.04; const dy = -sin(a), dz = -cos(a), len = lens[idxFinger][j];
        const A = [px, py, pz], B = [px, py + dy * len, pz + dz * len]; segLocal(base, A, B, r0 * (1 - j * 0.13), skin, true);
        px = B[0]; py = B[1]; pz = B[2];
      }
    }
    // thumb: from the side of the palm, rotating towards the fingers with t
    { const sx = side * 0.046; let px = sx, py = -0.004, pz = -0.025, ang = 0.7 - th * 0.75; const tl = [0.04, 0.032];
      for (let j = 0; j < 2; j++) { const dx = -side * sin(ang) * 0.9, dz = -cos(ang); const len = tl[j]; const A = [px, py, pz], B = [px + dx * len * 0.6 - side * 0.0, py - th * 0.01, pz + dz * len]; segLocal(base, A, B, 0.0135 - j * 0.0015, skin, true); px = B[0]; py = B[1]; pz = B[2]; ang -= th * 0.5; } }
    // wrist cuff
    D(base, Me.cyl, h.cuffMat || Ma.cuff, 0, 0, 0.01, 0, PI / 2, 0, 0.05, 0.014, 0.05);
    // forearm / sleeve is drawn by the caller
  }
  function segLocal(base, A, B, r, mat, joint) { // cylinder in local space of base
    const a = [A[0], A[1], A[2]], b = [B[0], B[1], B[2]];
    const d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], len = sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]) || 0.001;
    const m = M.along(a, d, r, len); GL.draw(Me.cylL, M.mul(base, m), mat);
    if (joint) { const jm = M.trs(b[0], b[1], b[2], 0, 0, 0, r, r, r); GL.draw(Me.sphL, M.mul(base, jm), mat); }
  }

  /* ------------------------------------------------------------------ the Caster (fictional stylised shotgun) */
  function gunMatrix(gs, holder) {
    const held = holder === 'p' || holder === 'd';
    S.gunRoll += ((held ? 0 : -PI / 2) - S.gunRoll) * (1 - Math.exp(-(S.dt || 0.016) * 9));          // lying on its side <-> upright in the hands
    const roll = S.gunRoll, k = 1 - roll / (-PI / 2), lift = clamp((gs.sc - 1) * 0.9, -0.1, 0.5);
    const yLie = TABLE_Y + 0.165 * GSC + 0.002, yUp = Math.max(TABLE_Y + 0.14, TABLE_Y + 0.16 + lift), y = yLie + (yUp - yLie) * k, pos = Cam.onY(gs.x, gs.y, y);
    const base = M.trs(pos[0], pos[1], pos[2], -gs.ang, 0, k * (lift > 0.05 ? 0.1 : 0), 1, 1, 1);
    return M.mul(base, M.trs(-(gs.kick || 0) * 0.05, 0, 0, 0, roll, 0, GSC, GSC, GSC));
  }
  const xf = (m, p) => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]];
  const xd = (m, v) => { const o = [m[0] * v[0] + m[4] * v[1] + m[8] * v[2], m[1] * v[0] + m[5] * v[1] + m[9] * v[2], m[2] * v[0] + m[6] * v[1] + m[10] * v[2]]; const l = Math.hypot(o[0], o[1], o[2]) || 1; return [o[0] / l, o[1] / l, o[2] / l]; };
  function drawGun(gs, Gm) {
    if (!MD.ok) return legacyGun(gs, Gm);
    const fore = (gs.fore === undefined ? 1 : gs.fore), slide = (1 - fore) * 0.12 / GSC;
    GL.draw(MD.gun.body, Gm, Ma.glbGun); GL.draw(MD.gun.fore, M.mul(Gm, M.trs(-slide, 0, 0, 0, 0, 0, 1, 1, 1)), Ma.glbGun);
    if (gs.charge > 0.01) D(Gm, Me.box, GL.material({ c: [0, 0, 0], em: [0.2, 0.7 * gs.charge, 1.4 * gs.charge], cast: false }), -0.28, 0.412, 0, 0, 0, 0, 0.5, 0.012, 0.12);
    const mz = xf(Gm, MD.gunMeta.muzzle), q = Cam.project(mz); S.gunInfo = { M: Gm, muzzle: mz, muzzleL: { x: q.x, y: q.y }, eject: xf(Gm, MD.gunMeta.ejection) };
    return Gm;
  }
  function legacyGun(gs, Gm0) {
    const gp = G.Anim.gun.p, R = S.R, Sc = R.scene;
    const lift = clamp((gs.sc - 1) * 0.9, -0.1, 0.5), pos = Cam.onY(gs.x, gs.y, TABLE_Y + 0.06 + lift);
    const yaw = -gs.ang, kick = gs.kick || 0;
    const base = M.trs(pos[0], pos[1], pos[2], yaw, clamp(-gs.ang * 0 + (lift > 0.05 ? 0.1 : 0), -1, 1) , 0, 1, 1, 1);
    const W = (px) => px * 0.0016;
    const recoil = -kick * 0.05;
    const Gm = M.mul(base, M.trs(recoil, 0, 0, 0, 0, 0, 1, 1, 1));
    const fore = (gs.fore === undefined ? 1 : gs.fore), slide = (1 - fore) * 0.12 + 0.0;
    D(Gm, Me.cyl, Ma.gun, W(20), 0.016, 0, 0, 0, -PI / 2, 0.016, W(300), 0.016);
    D(Gm, Me.cyl, Ma.gun, W(20), -0.012, 0, 0, 0, -PI / 2, 0.017, W(255), 0.017);
    D(Gm, Me.box, Ma.gun, W(10), 0.002, 0, 0, 0, 0, W(120), 0.075, 0.062);
    D(Gm, Me.box, Ma.brass, W(18), 0.04, 0, 0, 0, 0, W(36), 0.008, 0.07);
    D(Gm, Me.box, Ma.gunWood, W(-110), -0.01, 0, 0, 0, 0.18, W(170), 0.085, 0.05);
    D(Gm, Me.box, Ma.gunWood, W(-185), -0.035, 0, 0, 0, 0.12, W(46), 0.11, 0.056);
    D(Gm, Me.box, Ma.gunWood, W(110) - slide, -0.012, 0, 0, 0, 0, W(120), 0.06, 0.068);
    D(Gm, Me.sphL, Ma.brass, W(318), 0.016, 0, 0, 0, 0, 0.008, 0.008, 0.008);
    if (gs.charge > 0.01) D(Gm, Me.box, GL.material({ c: [0, 0, 0], em: [0.2, 0.7 * gs.charge, 1.4 * gs.charge] }), W(12), 0.045, 0, 0, 0, 0, W(60), 0.008, 0.02);
    return Gm;
  }
  /* wrist target + hand axes for a hand holding a gun socket. local = point on the gun's surface (gun space), pLocal = palm normal
     (pointing into the gun), fLocal = direction the straight fingers point. halfL/halfT = palm half length/thickness (world). */
  function gripTarget(Gm, local, fLocal, pLocal, halfL, halfT) {
    const F = xf(Gm, local), f = xd(Gm, fLocal), pn = xd(Gm, pLocal);
    return { w: [F[0] - pn[0] * halfT - f[0] * halfL, F[1] - pn[1] * halfT - f[1] * halfL, F[2] - pn[2] * halfT - f[2] * halfL], f, p: pn };
  }
  /* ------------------------------------------------------------------ the dealer: the supplied hooded-skull model, skinned to a real skeleton */
  const DS = { s: 0.47, o: [0, 0, 0], hp: [0, 1.5, 0], hp0: [0, 1.5, 0], headR: 0.27, d: null };
  function dealerSetup(R, Sc) {
    const d = G.Anim.dealer.p, t = R.t, zD = ROOM.zD;
    const hp0 = Cam.onZ(640, 214, zD), headR0 = pxw(hp0[3]) * 92;
    DS.s = headR0 * 1.02 / 0.54 * 0.95; DS.o = [0, hp0[1] - DS.s * 2.93, zD]; DS.hp0 = hp0; DS.d = d;
    const jit = d.glitch > 0.2 ? (Math.random() - 0.5) * 0.05 * d.glitch : 0, shk = d.shk ? (Math.random() - 0.5) * 0.01 * d.shk : 0;
    const lean = (d.lean || 0) * 0.0035, breath = sin(t * 0.9 * (d.brt || 1)) * 0.006;
    const hp = Cam.onZ(640 + (d.hx || 0) + (d.leanX || 0), 214 + (d.hy || 0) - (d.lean || 0) * 0.3, zD), headR = pxw(hp[3]) * 92;
    hp[0] += jit + shk; hp[1] += breath; hp[2] += lean * 20; DS.hp = hp; DS.headR = headR;
    S.dealerHead = { p: hp, r: headR }; R.dealerAnchor = (function () { const q = Cam.project([hp[0], hp[1] - headR * 1.25, hp[2]]); return { x: q.x, y: q.y, r: headR / pxw(hp[3]) }; })();
    return DS;
  }
  S.gunLocalToLogical = function (lx, ly) { if (!MD.ok || !S.gunInfo) return null; const q = Cam.project(xf(S.gunInfo.M, [lx * 0.0016 / GSC, 0.3, ly * 0.0016 / GSC])); return { x: q.x, y: q.y }; };
  const DEAL_SIDE = { l: 'R', r: 'L' };     // the dealer faces the player: his anatomical right hand is on the screen-left
  function dealerPose(R, Sc, hands) {
    const Rg = G.Rg, Q = Rg.Q, V = Rg.v, rig = MD.rig, d = DS.d, s = DS.s, o = DS.o, t = R.t;
    const toM = (w) => [(w[0] - o[0]) / s, (w[1] - o[1]) / s, (w[2] - o[2]) / s], toW = (m) => [m[0] * s + o[0], m[1] * s + o[1], m[2] * s + o[2]];
    rig.reset();
    const ax = (a) => Q.axis(1, 0, 0, a), br = sin(t * 0.9 * (d.brt || 1)) * 0.012;
    const yaw = (d.lookX || 0) * -0.25 + (d.hx || 0) * -0.0006, pitch = ((d.lookY || 0) - 0.15) * 0.35 + (d.hy || 0) * 0.0012, roll = d.hr || 0;
    const hq = (k) => Q.mul(Q.mul(Q.axis(0, 1, 0, yaw * k), ax(pitch * k)), Q.axis(0, 0, 1, roll * k));
    rig.set('neck', hq(0.35)); rig.set('head', hq(0.65));
    const open = clamp((d.mO || 0) + (d.talk ? d.talk * (0.35 + 0.35 * sin(t * 16) * sin(t * 7.3)) : 0), 0, 1.2); rig.set('jaw', ax(open * 0.45));
    // lean the torso over the table until both hands can reach; the head stays where the animation puts it (neck/head counter-rotate)
    const hpM = toM(DS.hp), headJ = [hpM[0], hpM[1] - 0.35, hpM[2] - 0.1];
    let lean = 0, worst = 0;
    const setTrunk = (L) => {
      rig.rootT = [0, 0, 0]; rig.set('spine', ax(L * 0.5)); rig.set('chest', Q.mul(ax(L * 0.5), ax(br)));
      rig.set('neck', Q.mul(ax(-L * 0.35), hq(0.35))); rig.set('head', Q.mul(ax(-L * 0.45), hq(0.65))); rig.fk();
      const h0 = rig.pos('head'); rig.rootT = [headJ[0] - h0[0], headJ[1] - h0[1], headJ[2] - h0[2]]; rig.fk();
    };
    for (let it = 0; it < 6; it++) {
      setTrunk(lean); worst = 0;
      for (const lg of ['l', 'r']) { const an = DEAL_SIDE[lg], Lr = rig.len['arm_' + an], T = toM(hands[lg].w); worst = Math.max(worst, V.len(V.sub(T, rig.pos('upperarm_' + an))) - (Lr[0] + Lr[1]) * 0.97); }
      if (worst < 0.02) break; lean = Math.min(0.95, lean + worst * 0.7);
    }
    const out = {}, Q0 = Q.fromBasis([0, 0, 1], [0, 1, 0], [-1, 0, 0]);
    for (const lg of ['l', 'r']) {
      const an = DEAL_SIDE[lg], h = hands[lg], T = toM(h.w), Sh = rig.pos('upperarm_' + an), sg = an === 'L' ? 1 : -1;
      const ik = rig.ikArm(an, T, [Sh[0] + sg * 0.9, Sh[1] - 0.8, Sh[2] - 0.5]);
      const back = [-h.p[0], -h.p[1], -h.p[2]], Qt = Q.fromBasis(h.f, back, V.cross(h.f, back)); rig.handWorld(an, Q.mul(Qt, Q.inv(Q0)));
      rig.fingers(an, h.c, h.i, h.t); out[lg] = { reached: ik.reached, wrist: toW(ik.wrist) };
    }
    rig.fk();
    // eyes + candles (positions follow the skeleton)
    const hd = rig.idx.head, eye = (m) => { const rel = V.sub(m, rig.rest[hd]), q = rig.Wq[hd], r = Q.rot(q, rel); return toW(V.add(rig.Wp[hd], r)); };
    out.eyes = [eye(MD.dMeta.eyeL), eye(MD.dMeta.eyeR)]; out.head = toW(rig.pos('head'));
    out.shoulders = [toW(V.add(rig.pos('upperarm_R'), [-0.12, 0.3, 0])), toW(V.add(rig.pos('upperarm_L'), [0.12, 0.3, 0]))];
    out.lean = lean; return out;
  }
  function drawDealerGLB(R, Sc, pose) {
    const d = DS.d, t = R.t, s = DS.s, o = DS.o;
    GL.draw(MD.dealer, M.trs(o[0], o[1], o[2], 0, 0, 0, s, s, s), Ma.glbChar, MD.rig.skin());
    const eo = clamp(d.eyeO === undefined ? 1 : d.eyeO, 0, 1.2), glow = 0.35 + 0.65 * eo, hr = DS.headR;
    for (const e of pose.eyes) { GL.sprite(e[0], e[1], e[2] + 0.02, hr * 0.5, 1, 0.1, 0.08, 0.42 * glow, 2.2); GL.sprite(e[0], e[1], e[2] + 0.03, hr * 0.14, 1, 0.55, 0.4, 0.9 * glow, 1.5); }
    const fl = [0.92 + 0.16 * sin(t * 9) + Sc.dealerFlameBoost * 0.2, 0.9 + 0.18 * sin(t * 7.3 + 2)];
    S.candles = [];
    pose.shoulders.forEach((c, k) => { D(null, Me.cyl, Ma.candle, c[0], c[1], c[2], 0, 0, 0, 0.026, 0.15, 0.026); D(null, Me.sphL, Ma.glowFlame, c[0], c[1] + 0.17, c[2], 0, 0, 0, 0.011, 0.024 * fl[k], 0.011);
      GL.sprite(c[0], c[1] + 0.175, c[2], 0.12 * fl[k], 1, 0.55, 0.2, 0.55, 2); S.candles.push({ x: c[0], y: c[1] + 0.2, z: c[2], k: fl[k] }); });
  }

  /* ------------------------------------------------------------------ items (13) */
  /* draws one item with its local origin at its base-centre, +Y up. p: {io,il,ic,irot,t,isc} */
  function drawItemModel(id, base, p) {
    const io = p.io || 0, il = p.il || 0, ic = p.ic || 0, t = p.t || 0;
    switch (id) {
      case 'magnifier':
        D(base, Me.cyl, Ma.gunWood, 0, 0, 0, 0, 0, 0, 0.012, 0.15, 0.012); D(base, Me.cyl, Ma.brass, 0, 0.14, 0, 0, 0, 0, 0.016, 0.03, 0.016);
        D(base, Me.tor, Ma.brass, 0, 0.255, 0, 0, PI / 2, 0, 0.1, 0.1, 0.1); D(base, Me.cyl, Ma.glass, 0, 0.255, 0, 0, PI / 2, 0, 0.092, 1, 0.092); break;
      case 'handcuffs': {
        const open = io; D(base, Me.tor, Ma.steel, -0.06, 0.01, 0, 0, 0, 0, 0.045, 0.045, 0.045);
        D(base, Me.tor, Ma.steel, 0.07 + open * 0.02, 0.01 + open * 0.01, -open * 0.03, open * 0.5, 0, 0, 0.045, 0.045, 0.045);
        D(base, Me.box, Ma.metal, -0.005, 0.012, 0, 0, 0, 0, 0.04, 0.016, 0.02); D(base, Me.cyl, Ma.steel, 0.012, 0.012, 0, 0, 0, PI / 2, 0.006, 0.05, 0.006); break; }
      case 'cigarette': {
        D(base, Me.cyl, Ma.paper, 0, 0, 0, 0, 0, PI / 2, 0.0045, 0.08, 0.0045); D(base, Me.cyl, GL.material({ c: GL.rgb('#c98a3c'), spec: 0.2 }), 0.067, 0, 0, 0, 0, PI / 2, 0.0047, 0.026, 0.0047);
        const glow = Math.max(il * 0.5, ic); if (glow > 0.02) { D(base, Me.sphL, GL.material({ c: [0, 0, 0], em: [2.2 * glow, 0.6 * glow, 0.1] }), -0.002, 0.0, 0, 0, 0, 0, 0.006, 0.006, 0.006); GL.sprite(base[12], base[13] + 0.01, base[14], 0.05, 1, 0.45, 0.15, 0.5 * glow, 2); } break; }
      case 'battery':
        D(base, Me.cyl, Ma.dark, 0, 0, 0, 0, 0, 0, 0.026, 0.12, 0.026); D(base, Me.cyl, Ma.red, 0, 0.04, 0, 0, 0, 0, 0.0268, 0.04, 0.0268); D(base, Me.cyl, Ma.brass, 0, 0.12, 0, 0, 0, 0, 0.011, 0.014, 0.011);
        if (ic > 0.02) { GL.sprite(base[12], base[13] + 0.06, base[14], 0.14 * ic + 0.03, 0.4, 0.6, 1, 0.8 * ic, 2); D(base, Me.cyl, GL.material({ c: [0, 0, 0], em: [0.2 * ic, 0.5 * ic, 1.6 * ic] }), 0, 0.0, 0, 0, 0, 0, 0.028, 0.12, 0.028); } break;
      case 'medicine': {
        D(base, Me.bottle, Ma.amber, 0, 0, 0, 0, 0, 0, 0.04, 0.13, 0.04); D(base, Me.cyl, Ma.paper, 0, 0.035, 0, 0, 0, 0, 0.0412, 0.055, 0.0412);
        D(base, Me.box, Ma.red, 0, 0.065, 0.0415, 0, 0, 0, 0.026, 0.008, 0.002); D(base, Me.box, Ma.red, 0, 0.065, 0.0415, 0, 0, 0, 0.008, 0.026, 0.002);
        const open2 = io; D(base, Me.cyl, Ma.white, open2 * 0.06, 0.13 + open2 * 0.05, 0, 0, 0, -open2 * 0.9, 0.022, 0.022, 0.022); break; }
      case 'can': {
        D(base, Me.can, Ma.canDark, 0, 0, 0, 0, 0, 0, 0.034, 0.12, 0.034); D(base, Me.cyl, Ma.canRed, 0, 0.04, 0, 0, 0, 0, 0.0346, 0.05, 0.0346);
        D(base, Me.box, Ma.white, 0, 0.065, 0.0348, 0, 0, 0, 0.02, 0.02, 0.002);
        D(base, Me.disc, Ma.steel, io * 0.014, 0.122, 0, 0, 0, io * 0.8, 0.012, 0.3, 0.012); break; }
      case 'lighter': {
        D(base, Me.box, Ma.metal, 0, 0.03, 0, 0, 0, 0, 0.034, 0.06, 0.016);
        D(base, Me.box, Ma.steel, 0, 0.075 + io * 0.015, 0, 0, io * 0.0, -io * 1.6, 0.034, 0.018, 0.016);
        if (il > 0.02) { const fl = (0.8 + 0.2 * sin(t * 30)) * il; GL.sprite(base[12], base[13] + 0.1, base[14], 0.065 * fl, 1, 0.65, 0.22, 0.95, 1.6); GL.sprite(base[12], base[13] + 0.092, base[14], 0.03, 1, 0.9, 0.6, 1, 2); } break; }
      case 'scrambler':
        D(base, Me.box, Ma.metal, 0, 0.03, 0, 0, 0, 0, 0.1, 0.06, 0.07); D(base, Me.box, GL.material({ c: [0, 0.02, 0.01], em: [0.05, 0.7 + 0.3 * sin(t * 6 + ic * 9), 0.2] }), -0.02, 0.062, 0.0, 0, 0, 0, 0.05, 0.004, 0.03);
        D(base, Me.cyl, Ma.red, 0.032, 0.066, 0, 0, 0, 0, 0.014, 0.012, 0.014); D(base, Me.cyl, Ma.brass, -0.036, 0.066, 0.02, 0, 0, 0, 0.008, 0.01, 0.008); break;
      case 'coin':
        D(base, Me.cyl, Ma.brass, 0, 0, 0, 0, 0, 0, 0.032, 0.006, 0.032); D(base, Me.cyl, GL.material({ c: GL.rgb('#8a6a28'), spec: 0.9, shin: 50 }), 0, 0.0055, 0, 0, 0, 0, 0.022, 0.001, 0.022); break;
      case 'knife':
        D(base, Me.box, Ma.gunWood, -0.045, 0.0, 0, 0, 0, 0, 0.09, 0.022, 0.016); D(base, Me.box, Ma.brass, 0.0, 0.0, 0, 0, 0, 0, 0.008, 0.028, 0.02);
        D(base, Me.box, Ma.steel, 0.07, 0.0, 0, 0, 0, 0, 0.13, 0.022, 0.006); D(base, Me.cone, Ma.steel, 0.157, 0.0, 0, 0, 0, -PI / 2, 0.011, 0.04, 0.003); break;
      case 'blank':
        D(base, Me.shell, Ma.shellA, 0, 0, 0, 0, 0, 0, 0.026, 0.12, 0.026); D(base, Me.shell, Ma.brass, 0, 0, 0, 0, 0, 0, 0.0268, 0.03, 0.0268); D(base, Me.cyl, GL.material({ c: GL.rgb('#5a3a70'), spec: 0.4 }), 0, 0.075, 0, 0, 0, 0, 0.0272, 0.012, 0.0272); break;
      case 'spray': {
        D(base, Me.can, Ma.canDark, 0, 0, 0, 0, 0, 0, 0.028, 0.15, 0.028); D(base, Me.cyl, Ma.canRed, 0, 0.05, 0, 0, 0, 0, 0.0286, 0.06, 0.0286);
        D(base, Me.cyl, Ma.white, 0, 0.15, 0, 0, 0, 0, 0.018, 0.02, 0.018); D(base, Me.box, Ma.white, 0.012 * (1 + io), 0.172, 0, 0, 0, 0, 0.024, 0.012, 0.014);
        if (il > 0.02) for (let i = 0; i < 4; i++) GL.sprite(base[12] + 0.05 + i * 0.04, base[13] + 0.18 + i * 0.015, base[14], 0.04 + i * 0.03, 0.9, 0.7, 0.9, 0.18 * il, 1.2); break; }
      case 'rope':
        for (let i = 0; i < 3; i++) D(base, Me.tor, Ma.rope, 0, 0.012 + i * 0.016, 0, i * 0.5, PI / 2, 0, 0.06 - i * 0.004, 0.06 - i * 0.004, 0.06 - i * 0.004); D(base, Me.cyl, Ma.rope, 0.05, 0.018, 0.03, 0, 0, PI / 2 - 0.5, 0.008, 0.07, 0.008); break;
      default: D(base, Me.box, Ma.metal, 0, 0.03, 0, 0, 0, 0, 0.05, 0.06, 0.05);
    }
  }
  /* how each item lies on the table: [lift (height of centre above surface), rx tilt] */
  const REST = { magnifier: [0.012, PI / 2, 0.0], handcuffs: [0, 0, 0], cigarette: [0.005, 0, 0], battery: [0.026, PI / 2, 0], medicine: [0, 0, 0], can: [0, 0, 0], lighter: [0, 0, 0], scrambler: [0, 0, 0], coin: [0, 0, 0], knife: [0.012, 0, 0], blank: [0.026, PI / 2, 0], spray: [0.028, PI / 2, 0], rope: [0, 0, 0] };
  const LIE = { magnifier: 1, battery: 1, blank: 1, spray: 1 }; // lie flat on the table when idle

  /* ------------------------------------------------------------------ dealer (skull-mask host) */
  function drawDealer(R, Sc, st) {
    const A = G.Anim, dl = A.dealer, d = dl.p, t = R.t;
    const zD = ROOM.zD;
    const jit = d.glitch > 0.2 ? (Math.random() - 0.5) * 0.05 * d.glitch : 0, shk = d.shk ? (Math.random() - 0.5) * 0.01 * d.shk : 0;
    const lean = (d.lean || 0) * 0.0035, breath = sin(t * 0.9 * (d.brt || 1)) * 0.006;
    const hp = Cam.onZ(640 + (d.hx || 0) * 1.0 + (d.leanX || 0), 214 + (d.hy || 0) - (d.lean || 0) * 0.3, zD), headR = pxw(hp[3]) * 92;
    hp[0] += jit + shk; hp[1] += breath; hp[2] += lean * 20;
    S.dealerHead = { p: hp, r: headR }; R.dealerAnchor = (function () { const q = Cam.project([hp[0], hp[1] - headR * 1.25, hp[2]]); return { x: q.x, y: q.y, r: headR / pxw(hp[3]) }; })();
    const sy = Cam.onZ(640, 346 - (d.shr || 0) * 5, zD)[1];
    // coat / torso
    const tor = M.trs(hp[0] * 0.5 + jit, sy - 0.4, zD - 0.02, 0, 0, 0, 1, 1, 1);
    D(tor, Me.sph, Ma.coat, 0, 0.12, 0, 0, 0, 0, headR * 1.85, 0.62, headR * 0.95); D(tor, Me.box, Ma.coat, 0, -0.35, 0, 0, 0, 0, headR * 3.2, 0.7, headR * 1.4);
    D(tor, Me.box, Ma.white, 0, 0.34, headR * 0.82, 0, 0, 0, headR * 0.55, 0.38, 0.02); D(tor, Me.cone, Ma.red, 0, 0.18, headR * 0.86, 0, PI, 0, 0.05, 0.4, 0.014); D(tor, Me.box, Ma.black, 0, 0.55, headR * 0.5, 0, 0, 0, headR * 1.0, 0.07, 0.07);
    // hood + head
    const hood = M.trs(hp[0], hp[1] + headR * 0.05, hp[2] - headR * 0.25, 0, 0, d.hr || 0, 1, 1, 1);
    D(hood, Me.sph, Ma.coat, 0, headR * 0.1, -headR * 0.2, 0, 0, 0, headR * 1.22, headR * 1.38, headR * 1.12); D(hood, Me.cyl, Ma.coat, 0, -headR * 1.4, 0, 0, 0, 0, headR * 0.62, headR * 0.75, headR * 0.6);
    const hd = M.trs(hp[0], hp[1], hp[2], (d.lookX || 0) * -0.25 + (d.hx || 0) * -0.0006, (d.lookY - 0.15) * 0.35 + (d.hy || 0) * 0.0012, (d.hr || 0), 1, 1, 1);
    const hr = headR;
    D(hd, Me.skull, Ma.wax, 0, 0.12 * hr, 0, 0, 0, 0, hr * 0.86, hr * 1.02, hr * 0.9);                  // cranium
    D(hd, Me.sph, Ma.wax, -hr * 0.46, -0.28 * hr, hr * 0.5, 0, 0, 0, hr * 0.2, hr * 0.14, hr * 0.18);   // cheekbones
    D(hd, Me.sph, Ma.wax, hr * 0.46, -0.28 * hr, hr * 0.5, 0, 0, 0, hr * 0.2, hr * 0.14, hr * 0.18);
    // eye sockets + glowing pupils
    const eo = clamp(d.eyeO === undefined ? 1 : d.eyeO, 0, 1.2), glow = 0.35 + 0.65 * eo;
    for (const sx of [-1, 1]) {
      D(hd, Me.sph, Ma.black, sx * hr * 0.34, hr * 0.2, hr * 0.7, 0, 0, 0, hr * 0.25, hr * 0.27 * (0.45 + 0.55 * clamp(eo, 0, 1)), hr * 0.14);
      const px = sx * hr * 0.34 + (d.lookX || 0) * hr * 0.06, py = hr * 0.2 + ((d.lookY || 0) - 0.15) * -hr * 0.05;
      D(hd, Me.sphL, GL.material({ c: [0, 0, 0], em: [3.2 * glow, 0.15 * glow, 0.12 * glow] }), px, py, hr * 0.8, 0, 0, 0, hr * 0.075, hr * 0.075 * clamp(eo, 0.2, 1), hr * 0.04);
      GL.sprite(hp[0] + (hd[0] * sx * hr * 0.34 + hd[8] * hr * 0.8) * 1, hp[1] + hr * 0.2, hp[2] + hr * 0.82, hr * 0.5, 1, 0.1, 0.08, 0.35 * glow, 2.2);
      // brows
      const br = sx < 0 ? (d.bL || 0) : (d.bR || 0); D(hd, Me.cylL, Ma.black, sx * hr * 0.36, hr * 0.5 + br * hr * 0.06, hr * 0.74, 0, 0, PI / 2 + sx * 0.25 * (0.6 + br * 0.5), hr * 0.03, hr * 0.28, hr * 0.03);
    }
    // nose cavity
    D(hd, Me.cone, Ma.black, 0, -hr * 0.12, hr * 0.84, 0, PI / 2, PI, hr * 0.07, hr * 0.13, hr * 0.03);
    // upper teeth + jaw (hinged) — wide unsettling grin that opens when talking
    const open = clamp((d.mO || 0) + (d.talk ? d.talk * (0.35 + 0.35 * sin(t * 16) * sin(t * 7.3)) : 0), 0, 1.2), grin = d.mC === undefined ? 0.35 : d.mC;
    for (let i = -6; i <= 6; i++) { const x = i * hr * 0.1, curve = (i * i) * hr * 0.0018 * (0.4 + grin); D(hd, Me.box, Ma.tooth, x, -hr * 0.42 + curve * 0.6, hr * (0.77 - Math.abs(i) * 0.04), 0, 0, 0, hr * 0.075, hr * 0.15, hr * 0.045); }
    const jawPivot = M.mul(hd, M.trs(0, -hr * 0.4, hr * 0.12, 0, open * 0.45, 0, 1, 1, 1));
    D(jawPivot, Me.sph, Ma.wax, 0, -hr * 0.32, hr * 0.28, 0, 0, 0, hr * 0.62, hr * 0.28, hr * 0.5); D(jawPivot, Me.box, Ma.black, 0, -hr * 0.08, hr * 0.5, 0, 0, 0, hr * 0.92, hr * 0.05, hr * 0.05);
    for (let i = -6; i <= 6; i++) { const x = i * hr * 0.1; D(jawPivot, Me.box, Ma.tooth, x, -hr * 0.12 - (i * i) * hr * 0.0012, hr * (0.58 - Math.abs(i) * 0.034), 0, 0, 0, hr * 0.07, hr * 0.12, hr * 0.04); }
    D(hd, Me.box, Ma.black, 0, -hr * 0.46, hr * 0.7, 0, 0, 0, hr * 0.9, hr * 0.03 + open * hr * 0.12, hr * 0.06);  // mouth cavity shadow
    // candle on each shoulder + flame light
    const fl = [0.92 + 0.16 * sin(t * 9) + Sc.dealerFlameBoost * 0.2, 0.9 + 0.18 * sin(t * 7.3 + 2)];
    S.candles = [];
    [-1, 1].forEach((sx, k) => { const c = [sx * hr * 1.9, sy + 0.02, zD + 0.05]; D(null, Me.cyl, Ma.candle, c[0], c[1], c[2], 0, 0, 0, 0.026, 0.15, 0.026); D(null, Me.sphL, Ma.glowFlame, c[0], c[1] + 0.17, c[2], 0, 0, 0, 0.011, 0.024 * fl[k], 0.011);
      GL.sprite(c[0], c[1] + 0.175, c[2], 0.12 * fl[k], 1, 0.55, 0.2, 0.55, 2); S.candles.push({ x: c[0], y: c[1] + 0.2, z: c[2], k: fl[k] }); });
    return { d, sy, zD, hr };
  }

  /* ------------------------------------------------------------------ player/dealer arms + hands, held items */
  function skinHand(who) { return who === 'p' ? Ma.skinP : Ma.skinD; }
  function handWorld(h, who, plane) { // returns world wrist pos for a logical hand
    const lift = (who === 'p' ? 0.035 : 0.03) + clamp(((h.s || 1) - (who === 'p' ? 1 : 0.8)) * (who === 'p' ? 0.5 : 0.6), -0.05, 0.35);
    return Cam.onY(h.x, h.y, TABLE_Y + lift);
  }
  function drawHandsFor(who, R, Sc, ctx) { return MD.ok ? drawHandsGLB(who, R, Sc, ctx) : drawHandsOld(who, R, Sc, ctx); }
  function drawHandsOld(who, R, Sc, ctx) {
    const { handScreen, trem, gunState, CX } = ctx, A = G.Anim, actor = who === 'p' ? A.player : A.dealer, p = actor.p, holder = Sc.gunHolder, held = Sc.held[who];
    let Lh = handScreen(actor, 'l'), Rh = handScreen(actor, 'r'); Lh.rot = who === 'p' ? Lh.r : Math.PI + Lh.r; Rh.rot = who === 'p' ? Rh.r : Math.PI + Rh.r;
    let gs = null;
    if (holder === who) {
      gs = gunState(); const a = gs.ang, Art = G.Art, grip = Art.gunPoint(gs, 8, 14), fore = Art.gunPoint(gs, 150, 10);
      const sc = who === 'p' ? Math.max(0.8, gs.sc * 0.85) * 1.05 : 0.92;
      Rh.x = grip.x; Rh.y = grip.y; Rh.rot = a + 0.1; Rh.c = 0.9; Rh.i = 0.85; Rh.t = 0.9; Rh.s = sc; Lh.x = fore.x; Lh.y = fore.y; Lh.rot = a - 0.15; Lh.c = 0.85; Lh.i = 0.85; Lh.t = 0.8; Lh.s = sc;
    }
    R.handWrist[who] = { lx: Lh.x - CX, ly: Lh.y, lr: who === 'p' ? Lh.rot : Lh.rot - Math.PI, rx: Rh.x - CX, ry: Rh.y, rr: who === 'p' ? Rh.rot : Rh.rot - Math.PI };
    if (holder === who && gs) { S.gunPlaced = true; drawGun(gs, null); }
    const out = {};
    for (const [side, H, k] of [['l', Lh, 0], ['r', Rh, 1]]) {
      const tr = trem(p, k), hx = H.x + tr[0], hy = H.y + tr[1] + (who === 'p' && holder !== 'p' ? sin(R.t * 0.9 * p.brt) * 3 : 0);
      const w = handWorld({ x: hx, y: hy, s: H.s }, who), fwdYaw = -H.rot;
      const scale = who === 'p' ? 1.12 * (0.9 + H.s * 0.12) : 1.05 * (0.9 + H.s * 0.2);
      const hand = { x: w[0], y: w[1], z: w[2], yaw: fwdYaw, curl: clamp(H.c, 0, 1), idx: clamp(H.i, 0, 1), thumb: clamp(H.t, 0, 1), s: scale, side: who === 'p' ? (side === 'l' ? 1 : -1) : (side === 'l' ? -1 : 1), skin: skinHand(who), pitch: who === 'p' ? 0 : 0 };
      // forearm
      if (who === 'p') { const sh = [w[0] * 0.55 + (side === 'l' ? -0.22 : 0.22), TABLE_Y - 0.28, Cam.eye[2] + 0.55]; const dir = [sh[0] - w[0], sh[1] - w[1], sh[2] - w[2]]; const wr = [w[0] - Math.sin(fwdYaw) * 0.0 + (-Math.sin(fwdYaw)) * -0.0, w[1], w[2]];
        seg([w[0], w[1], w[2] + 0.0], [w[0] + dir[0] * 0.2, w[1] + dir[1] * 0.2, w[2] + dir[2] * 0.2], 0.043 * scale, Me.cyl, Ma.sleeveP); seg([w[0] + dir[0] * 0.2, w[1] + dir[1] * 0.2, w[2] + dir[2] * 0.2], sh, 0.058 * scale, Me.cyl, Ma.sleeveP); }
      else { const shd = S.dealerShoulder[side], elbowHint = [side === 'l' ? -0.18 : 0.18, -0.12, 0.1]; const a = shd, b = w, l1 = 0.4, l2 = 0.42;
        let dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2], dist = sqrt(dx * dx + dy * dy + dz * dz), reach = Math.min(dist, l1 + l2 - 0.01);
        const ca = (l1 * l1 + reach * reach - l2 * l2) / (2 * l1 * reach), ang = Math.acos(clamp(ca, -1, 1)); const ux = dx / dist, uy = dy / dist, uz = dz / dist;
        let hx_ = elbowHint[0], hy_ = elbowHint[1], hz_ = elbowHint[2]; const dd = hx_ * ux + hy_ * uy + hz_ * uz; hx_ -= ux * dd; hy_ -= uy * dd; hz_ -= uz * dd; const hl = sqrt(hx_ * hx_ + hy_ * hy_ + hz_ * hz_) || 1; hx_ /= hl; hy_ /= hl; hz_ /= hl;
        const el = [a[0] + ux * l1 * cos(ang) + hx_ * l1 * sin(ang), a[1] + uy * l1 * cos(ang) + hy_ * l1 * sin(ang), a[2] + uz * l1 * cos(ang) + hz_ * l1 * sin(ang)];
        const wr = [a[0] + ux * reach, a[1] + uy * reach, a[2] + uz * reach]; // wrist actually reached
        seg(a, el, 0.05, Me.cyl, Ma.coat); seg(el, [w[0], w[1], w[2]], 0.04, Me.cyl, Ma.coat); D(null, Me.sph, Ma.coat, el[0], el[1], el[2], 0, 0, 0, 0.052, 0.052, 0.052); D(null, Me.sph, Ma.coat, a[0], a[1], a[2], 0, 0, 0, 0.065, 0.065, 0.065); }
      drawHand(hand);
      out[side] = { hand, w };
      if (side === 'r' && held && held.kind === 'item') {
        const f = [Math.sin(H.rot), 0, -cos(H.rot)], dist = who === 'p' ? 0.06 : -0.03;
        const ip = [w[0] + f[0] * dist, w[1] + 0.07 * (who === 'p' ? 1 : 0.8), w[2] + f[2] * dist];
        const ds = who === 'p' ? 1.05 : 1.0, isc = actor.p.isc === undefined ? 1 : actor.p.isc;
        const rz = -((H.rot * 0.3) + (actor.p.irot || 0)), base = M.trs(ip[0], ip[1], ip[2], 0, who === 'p' ? 0.55 : -0.2, rz, ds * Math.max(0.001, isc), ds * (held.id === 'can' ? (1 + (1 - isc) * 0.2) : 1) * Math.max(0.001, isc), ds * Math.max(0.001, isc));
        drawItemModel(held.id, base, { io: actor.p.io, il: actor.p.il, ic: actor.p.ic, t: R.t });
        const q = Cam.project([ip[0], ip[1] + 0.05, ip[2]]); if (who === 'p') R.heldPos = { x: q.x, y: q.y }; else R.heldPosD = { x: q.x, y: q.y };
      }
    }
    if (Sc.cuffs[who]) for (const sd of ['l', 'r']) { const w = out[sd].w; D(null, Me.tor, Ma.steel, w[0], w[1] + 0.005, w[2] + 0.0, 0, 0, 0, 0.065, 0.065, 0.065); }
    if (Sc.cuffs[who]) { const a = out.l.w, b = out.r.w; seg([a[0], a[1] - 0.01, a[2]], [b[0], b[1] - 0.01, b[2]], 0.004, Me.cylL, Ma.steel); }
    return out;
  }

  /* hands + arms + gun for one side of the table when the supplied GLB models are active */
  function drawHandsGLB(who, R, Sc, ctx) {
    const { handScreen, trem, gunState, CX } = ctx, A = G.Anim, actor = who === 'p' ? A.player : A.dealer, p = actor.p, holder = Sc.gunHolder, held = Sc.held[who];
    const Lh = handScreen(actor, 'l'), Rh = handScreen(actor, 'r'), Hs = { l: Lh, r: Rh }, hands = {};
    for (const [side, k] of [['l', 0], ['r', 1]]) {
      const H = Hs[side], tr = trem(p, k), hx = H.x + tr[0], hy = H.y + tr[1] + (who === 'p' && holder !== 'p' ? sin(R.t * 0.9 * p.brt) * 3 : 0), rot = who === 'p' ? H.r : PI + H.r;
      hands[side] = { w: handWorld({ x: hx, y: hy, s: H.s }, who), f: [sin(rot), 0, -cos(rot)], p: [0, -1, 0], c: clamp(H.c, 0, 1), i: clamp(H.i, 0, 1), t: clamp(H.t, 0, 1), rot, H, sc: who === 'p' ? 1.12 * (0.9 + H.s * 0.12) : 1.05 * (0.9 + H.s * 0.2), grip: false };
    }
    // gun in hands: the right hand wraps the pistol grip, the left hand cups the fore-end (sockets measured from the model)
    let gs = null, Gm = null; const gm = MD.gunMeta, gripL = who === 'p' ? 'r' : 'l', supL = who === 'p' ? 'l' : 'r';
    const palm = (h) => who === 'p' ? [0.05 * h.sc, 0.015 * h.sc] : [0.10 * DS.s, 0.11 * DS.s];
    if (holder === who) {
      gs = gunState(); Gm = gunMatrix(gs, holder);
      const hr = hands[gripL], hl = hands[supL], pr = palm(hr), pl = palm(hl);
      const rearX = gm.grip[0] - gm.gripSize[0] / 2, gr = gripTarget(Gm, [rearX, gm.grip[1], 0], [0, 0, 1], [1, 0, 0], pr[0], pr[1]);
      const sp = gripTarget(Gm, [gm.fore[0], gm.fore[1] - gm.foreSize[1] / 2, 0], [0, 0, 1], [0, 1, 0], pl[0], pl[1]);
      Object.assign(hr, gr, { c: 0.92, i: 0.88, t: 0.9, grip: true }); Object.assign(hl, sp, { c: 0.85, i: 0.8, t: 0.7, grip: true });
    }
    let reach = null;
    if (who === 'd') {
      reach = dealerPose(R, Sc, hands);
      if (gs && holder === 'd') {       // hands lead: if an arm cannot reach, the gun comes to the hand instead of the hand leaving the gun
        const e = reach[gripL], T = hands[gripL].w, dl = [e.wrist[0] - T[0], e.wrist[1] - T[1], e.wrist[2] - T[2]];
        if (Math.hypot(...dl) > 0.004) { Gm = M.mul(M.trs(dl[0], dl[1], dl[2], 0, 0, 0, 1, 1, 1), Gm); for (const sl of ['l', 'r']) { const h = hands[sl]; if (h.grip) h.w = [h.w[0] + dl[0], h.w[1] + dl[1], h.w[2] + dl[2]]; } reach = dealerPose(R, Sc, hands); }
      }
      drawDealerGLB(R, Sc, reach);
    }
    if (gs && Gm) { S.gunPlaced = true; drawGun(gs, Gm); }
    R.handWrist[who] = { lx: hands.l.H.x - CX, ly: hands.l.H.y, lr: who === 'p' ? hands.l.H.r : hands.l.H.r, rx: hands.r.H.x - CX, ry: hands.r.H.y, rr: who === 'p' ? hands.r.H.r : hands.r.H.r };
    const out = {};
    for (const side of ['l', 'r']) {
      const h = hands[side], H = h.H; let w = h.w;
      if (who === 'd') w = reach[side].wrist;
      else {
        const scale = h.sc, handSide = side === 'l' ? 1 : -1, fwd = h.f, pn = h.p;
        const ex = Rg().v.cross(pn, fwd), pos = w;
        const base = [ex[0] * scale, ex[1] * scale, ex[2] * scale, 0, -pn[0] * scale, -pn[1] * scale, -pn[2] * scale, 0, -fwd[0] * scale, -fwd[1] * scale, -fwd[2] * scale, 0, pos[0], pos[1], pos[2], 1];
        // arm: shoulder -> elbow -> wrist, two-bone IK; the elbow leans outwards and down
        const sh = [w[0] * 0.55 + (side === 'l' ? -0.24 : 0.24), TABLE_Y - 0.3, Cam.eye[2] + 0.5], dx = w[0] - sh[0], dy = w[1] - sh[1], dz = w[2] - sh[2], dist = sqrt(dx * dx + dy * dy + dz * dz);
        const L = Math.max(0.36, dist * 0.53), dn = [dx / dist, dy / dist, dz / dist], pole = [side === 'l' ? -0.7 : 0.7, -0.7, 0.1]; const dd = pole[0] * dn[0] + pole[1] * dn[1] + pole[2] * dn[2];
        let hv = [pole[0] - dn[0] * dd, pole[1] - dn[1] * dd, pole[2] - dn[2] * dd]; const hl = Math.hypot(...hv) || 1; hv = hv.map((v) => v / hl);
        const half = dist / 2, off = Math.sqrt(Math.max(0, L * L - half * half)), el = [sh[0] + dn[0] * half + hv[0] * off, sh[1] + dn[1] * half + hv[1] * off, sh[2] + dn[2] * half + hv[2] * off];
        seg(sh, el, 0.058 * scale, Me.cyl, Ma.sleeveP); seg(el, w, 0.045 * scale, Me.cyl, Ma.sleeveP); D(null, Me.sph, Ma.sleeveP, el[0], el[1], el[2], 0, 0, 0, 0.056 * scale, 0.056 * scale, 0.056 * scale);
        drawHand({ x: w[0], y: w[1], z: w[2], s: scale, curl: h.c, idx: h.i, thumb: h.t, side: handSide, skin: skinHand(who), base, yaw: 0 });
      }
      out[side] = { w };
      if (side === 'r' && held && held.kind === 'item') {
        const f = h.f, dist = who === 'p' ? 0.06 : -0.03, ip = [w[0] + f[0] * dist, w[1] + 0.07 * (who === 'p' ? 1 : 0.8), w[2] + f[2] * dist];
        const ds = who === 'p' ? 1.05 : 1.0, isc = actor.p.isc === undefined ? 1 : actor.p.isc, rz = -((h.rot * 0.3) + (actor.p.irot || 0));
        const base = M.trs(ip[0], ip[1], ip[2], 0, who === 'p' ? 0.55 : -0.2, rz, ds * Math.max(0.001, isc), ds * (held.id === 'can' ? (1 + (1 - isc) * 0.2) : 1) * Math.max(0.001, isc), ds * Math.max(0.001, isc));
        drawItemModel(held.id, base, { io: actor.p.io, il: actor.p.il, ic: actor.p.ic, t: R.t });
        const q = Cam.project([ip[0], ip[1] + 0.05, ip[2]]); if (who === 'p') R.heldPos = { x: q.x, y: q.y }; else R.heldPosD = { x: q.x, y: q.y };
      }
    }
    { const ql = Cam.project(out.l.w), qr = Cam.project(out.r.w); R.handWrist[who] = { lx: ql.x - CX, ly: ql.y, lr: R.handWrist[who].lr, rx: qr.x - CX, ry: qr.y, rr: R.handWrist[who].rr }; }
    if (Sc.cuffs[who]) for (const sd of ['l', 'r']) { const w = out[sd].w; D(null, Me.tor, Ma.steel, w[0], w[1] + 0.005, w[2], 0, 0, 0, 0.065, 0.065, 0.065); }
    if (Sc.cuffs[who]) { const a = out.l.w, b = out.r.w; seg([a[0], a[1] - 0.01, a[2]], [b[0], b[1] - 0.01, b[2]], 0.004, Me.cylL, Ma.steel); }
    return out;
  }
  const Rg = () => G.Rg;

  /* ------------------------------------------------------------------ table items, shells + bodies */
  function drawSlotItems(who, R, Sc) {
    const arr = Sc.items[who];
    for (let i = 0; i < 6; i++) {
      const it = arr[i]; if (!it || it.hidden || it.delay > 0) continue;
      const w = R.slotWorld(who, i), sel = Sc.selected && Sc.selected.who === who && Sc.selected.idx === i;
      const rest = REST[it.id] || [0, 0, 0], pos = Cam.onY(w.x, w.y, TABLE_Y), zpx = pxw(pos[3]);
      const hgt = it.z * zpx * 0.9;     // falling in (z in logical px)
      let yaw = (i * 1.7 + (who === 'p' ? 0.3 : 2.1)) % 1.0 - 0.5; if (who === 'd') yaw += PI;
      const bob = sel ? 0.012 + sin(R.t * 4) * 0.004 : 0, sc = it.alpha === undefined ? 1 : Math.max(0.01, it.alpha);
      const lying = LIE[it.id] ? 1 : 0;
      let base;
      if (lying) base = M.trs(pos[0], TABLE_Y + rest[0] + hgt + bob, pos[2], yaw, 0, PI / 2, sc, sc, sc);       // laid on its side
      else if (it.id === 'cigarette' || it.id === 'knife' || it.id === 'handcuffs' || it.id === 'rope' || it.id === 'coin' || it.id === 'scrambler') base = M.trs(pos[0], TABLE_Y + rest[0] + hgt + bob + 0.002, pos[2], yaw, 0, 0, sc, sc, sc);
      else base = M.trs(pos[0], TABLE_Y + hgt + bob, pos[2], yaw, 0, 0, sc, sc, sc);
      if (it.burn > 0) { GL.sprite(pos[0], TABLE_Y + 0.06, pos[2], 0.25 * Math.min(1, it.burn), 1, 0.45, 0.12, 0.7 * Math.min(1, it.burn), 1.6); }
      if (sel) GL.sprite(pos[0], TABLE_Y + 0.01, pos[2], 0.2, 1, 0.25, 0.15, 0.55, 1.4);
      drawItemModel(it.id, base, { t: R.t, ic: it.burn > 0 ? 0.6 : 0 });
    }
  }
  function drawBodies(R, Sc) {
    for (const b0 of G.Physics.bodies) {
      const li = G.Physics.lerped(b0), b = Object.assign(Object.create(b0), { x: li.x, y: li.y, z: li.z, rot: li.rot });
      const k = b.kind, p = Cam.onY(640 + b.x, b.y, TABLE_Y), zpx = pxw(p[3]), hgt = Math.max(0, b.z || 0) * zpx * 0.9;
      if (b.off && b.z < -300) continue; const f = b.fade === undefined ? 1 : b.fade; if (f <= 0.02) continue;
      const yaw = -(b.rot || 0);
      if (k === 'shell_e' || k === 'shell_a') { const em = k === 'shell_e'; const m = M.trs(p[0], TABLE_Y + 0.012 + hgt, p[2], yaw, 0, PI / 2, 1, 1, 1);
        D(m, Me.shell, em ? Ma.red : Ma.shellA, 0, -0.04, 0, 0, 0, 0, 0.0125, 0.075, 0.0125); D(m, Me.shell, em ? Ma.brass : Ma.metal, 0, -0.04, 0, 0, 0, 0, 0.0132, 0.022, 0.0132); }
      else if (k === 'coin') { const m = M.trs(p[0], TABLE_Y + 0.02 + hgt, p[2], 0, 0, (b.rot || 0) * 1.0, 1, 1, 1); drawItemModel('coin', m, {}); }
      else if (k === 'can') { const m = M.trs(p[0], TABLE_Y + 0.034 + hgt, p[2], yaw, 0, PI / 2, 0.8, 0.5, 0.8); drawItemModel('can', m, { io: 1 }); }
      else if (k === 'bottle') { const m = M.trs(p[0], TABLE_Y + 0.04 + hgt, p[2], yaw, 0, PI / 2, 0.9, 0.9, 0.9); drawItemModel('medicine', m, { io: 1 }); }
      else if (k === 'cell') { const m = M.trs(p[0], TABLE_Y + 0.026 + hgt, p[2], yaw, 0, PI / 2, 1, 1, 1); drawItemModel('battery', m, {}); }
      else if (k === 'butt') { const m = M.trs(p[0], TABLE_Y + 0.006 + hgt, p[2], yaw, 0, 0, 1, 1, 1); D(m, Me.cyl, Ma.paper, 0, 0, 0, 0, 0, PI / 2, 0.0045, 0.03, 0.0045); D(m, Me.cyl, GL.material({ c: GL.rgb('#c98a3c') }), 0.02, 0, 0, 0, 0, PI / 2, 0.0047, 0.014, 0.0047); }
      else if (k === 'pill') { const m = M.trs(p[0], TABLE_Y + 0.004 + hgt, p[2], yaw, 0, 0, 1, 1, 1); D(m, Me.cylL, Ma.white, 0, 0, 0, 0, 0, PI / 2, 0.006, 0.016, 0.006); }
    }
  }

  /* ------------------------------------------------------------------ frame */
  const lightProj = M.ortho(-2.3, 2.3, -2.3, 2.3, 0.4, 4.5);
  S.init = function (canvas, R) {
    if (!GL.init(canvas)) return false;
    try { buildAssets(); camBasis(); setupGeometryAnchors(); S.R = R; S.ready = true; S.dealerShoulder = { l: [0, 1, 0], r: [0, 1, 0] }; return true; } catch (e) { console.warn('[stage3d] init failed:', e && e.message); S.ready = false; return false; }
  };
  S.setQuality = function (q) { GL.setShadowSize(q === 'low' ? 0 : q === 'medium' ? 512 : 1024); S.shadows = q !== 'low'; };

  S.render = function (R, ctx, dt) {
    const Sc = R.scene, v = R.view; TIME = R.t; S.dt = dt; if (S.gunRoll === undefined) S.gunRoll = -PI / 2;
    // camera (slow breathing sway, shake, menu drift)
    const shake = R.shakeAmp * R.shakeScale, sway = R.reduced ? 0 : 1;
    R.lookX = (R.lookX || 0) * (R.lookHold ? 1 : Math.exp(-dt * 2.5)); R.lookY = (R.lookY || 0) * (R.lookHold ? 1 : Math.exp(-dt * 2.5));
    // the camera follows the look input through a critically damped filter and shakes with smooth noise (no per-frame random jitter)
    const kf = 1 - Math.exp(-dt * 16); S.lx = (S.lx === undefined ? R.lookX : S.lx + (R.lookX - S.lx) * kf); S.ly = (S.ly === undefined ? R.lookY : S.ly + (R.lookY - S.ly) * kf);
    const nz = (a, b) => (sin(R.t * a) + sin(R.t * b + 1.3)) * 0.5, shx = nz(41, 67) * shake * 0.06, shy = nz(53, 79) * shake * 0.05;
    Cam.eye = [S.lx * 0.55 + sin(R.t * 0.31) * 0.012 * sway + shx + (Sc.mode === 'menu' ? sin(R.t * 0.13) * 0.08 * sway : 0), 1.5 + S.ly * 0.25 + cos(R.t * 0.23) * 0.008 * sway + shy, 1.78 - R.punch * 0.05];
    Cam.tgt = [Cam.eye[0] * 0.2 - S.lx * 0.4, 0.86 + S.ly * 0.1, -0.75]; camBasis(); setupGeometryAnchors();
    const asp = v.pw / v.ph, fovy = 2 * Math.atan((v.ph / (2 * v.fs)) / FOC) / Math.max(0.2, Sc.zoom);
    const proj = M.persp(fovy, asp, 0.1, 30), view = M.look(Cam.eye, Cam.tgt, [0, 1, 0]);
    const zc = (ROOM.zFar + 1.4) / 2, lampY = 2.5, lamp = R.lamp;
    const lightView = M.look([0, lampY, zc], [0, 0, zc], [0, 0, -1]);
    const fd = { proj, view, eye: Cam.eye, lightProj, lightView, shadows: S.shadows, time: R.t, fog: [0.03, 0.012, 0.014], fogD: 0.11, amb: [0.02, 0.012, 0.014], spotDir: [0, -1, 0], spotCos: 0.62, lights: [] };
    GL.begin(fd); const lights = fd.lights;
    lights.push({ x: 0, y: lampY, z: zc, r: 6.2, c: [1.5 * lamp, 0.8 * lamp, 0.5 * lamp] });
    drawRoom(R, Sc);
    // shoulders for dealer arms need the dealer drawn first
    const d = G.Anim.dealer.p, zD = ROOM.zD;
    S.dealerShoulder.l = Cam.onZ(640 - 186 * (1 + (d.lean || 0) * 0.0035) + (d.leanX || 0), 346 - (d.shr || 0) * 5, zD).slice(0, 3); S.dealerShoulder.r = Cam.onZ(640 + 186 * (1 + (d.lean || 0) * 0.0035) + (d.leanX || 0), 346 - (d.shr || 0) * 5, zD).slice(0, 3);
    if (MD.ok) dealerSetup(R, Sc); else drawDealer(R, Sc);
    drawTable(R, Sc);
    // light shafts from the lamp
    if (R.q !== 'low' && (R.auto || 1) > 0.7) for (let i = 0; i < 3; i++) { const k = (0.32 - i * 0.09) * lamp; DA(null, Me.cone, GL.material({ c: [0, 0, 0], em: [0.05 * k, 0.022 * k, 0.012 * k], kind: 7 }), 0, TABLE_Y, zc, 0, 0, 0, 1.2 - i * 0.28, lampY - TABLE_Y, 1.2 - i * 0.28); }
    GL.sprite(0, lampY - 0.02, zc, 0.4 * lamp, 1, 0.65, 0.45, 0.6 * lamp, 2.4); D(null, Me.cone, Ma.dark, 0, lampY + 0.02, zc, 0, 0, 0, 0.32, 0.22, 0.32); D(null, Me.cyl, Ma.dark, 0, lampY + 0.2, zc, 0, 0, 0, 0.012, 1.0, 0.012);
    drawSlotItems('d', R, Sc);
    if (Sc.gunHolder === 'table') { S.gunPlaced = true; const g0 = ctx.gunState(); drawGun(g0, MD.ok ? gunMatrix(g0, 'table') : null); }
    drawBodies(R, Sc);
    drawHandsFor('d', R, Sc, ctx);
    drawSlotItems('p', R, Sc);
    drawHandsFor('p', R, Sc, ctx);
    // glow + dynamic lights
    for (const c of (S.candles || [])) lights.push({ x: c.x, y: c.y, z: c.z + 0.1, r: 2.6, c: [1.3 * c.k, 0.6 * c.k, 0.25 * c.k] });
    lights.push({ x: 2.1, y: 1.5, z: ROOM.zWall + 0.9, r: 4, c: [0.9 + (Sc.tvGlitch || 0), 0.1, 0.08] });
    if (Sc.flashObj) { const k = 1 - Sc.flashObj.t / 0.16, mp = R.muzzlePos(), p = Cam.onY(mp.x, mp.y, TABLE_Y + 0.15); lights.push({ x: p[0], y: p[1] + 0.1, z: p[2], r: 3.5, c: [5 * k, 2.6 * k, 0.9 * k] }); GL.sprite(p[0], p[1], p[2], 0.45 * (0.6 + k), 1, 0.85, 0.5, k, 1.6); }
    if (Sc.redWash > 0) lights.push({ x: 0, y: 2.2, z: 0.5, r: 8, c: [2.2 * Sc.redWash, 0.0, 0.0] });
    GL.end();
  };
  G.Stage3D = S;
  if (typeof module !== 'undefined' && module.exports) module.exports = S;
})(typeof window !== 'undefined' ? window : globalThis);
