/* art.js — all artwork is original and drawn procedurally with Canvas 2D (no external image files).
   Rigs: hands + sleeves, the Dealer ("the Wick-Keeper": wax mask, shoulder candles), the Caster weapon, nine items,
   the room and table backgrounds, particle sprites and UI icons. Every function draws in logical 1280x720 space. */
(function (G) {
  'use strict';
  const U = G.U, TAU = Math.PI * 2;
  const A = { CX: 640 };
  const sin = Math.sin, cos = Math.cos, PI = Math.PI;

  /* deterministic pseudo-random for static art */
  function rng(seed) { let s = seed | 0; return function () { s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const rr = (c, x, y, w, h, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); };
  const lg = (c, x0, y0, x1, y1, stops) => { const g = c.createLinearGradient(x0, y0, x1, y1); stops.forEach((s) => g.addColorStop(s[0], s[1])); return g; };
  const rg = (c, x, y, r0, r1, stops) => { const g = c.createRadialGradient(x, y, r0, x, y, r1); stops.forEach((s) => g.addColorStop(s[0], s[1])); return g; };
  A.rr = rr; A.lg = lg; A.rg = rg;

  A.SKIN_P = { base: '#b98674', shade: '#7c4e44', line: '#1d0d0c', hi: '#e2b19c', nail: 'rgba(255,225,215,0.35)' };
  A.SKIN_D = { base: '#d3c7b0', shade: '#8f856f', line: '#120a08', hi: '#f1e8d6', nail: 'rgba(20,10,10,0.85)' };

  /* ------------------------------------------------------------------ slots */
  A.slot = function (who, i) {
    const bx = -300 + 120 * i;
    return who === 'p' ? { x: bx, y: 578, s: 1 } : { x: bx * 0.75, y: 410, s: 0.72 };
  };
  A.GUN_BASE = { x: -70, y: 505 };

  /* ------------------------------------------------------------------ hand */
  A.drawHand = function (c, o) {
    const sk = o.skin, L = o.len || 1, side = o.side || 1;
    const curl = U.clamp(o.c, 0, 1), ic = U.clamp(o.i, 0, 1), tc = U.clamp(o.t, 0, 1);
    c.save(); c.translate(o.x, o.y); c.rotate(o.rot); c.scale(o.s, o.s);
    c.lineCap = 'round'; c.lineJoin = 'round';
    const finger = (bx, by, ang, len, wid, cu, k) => {
      const eff = len * L * (1 - 0.56 * cu), tx = bx + sin(ang) * eff, ty = by - cos(ang) * eff;
      c.strokeStyle = sk.line; c.lineWidth = wid + 3.6; c.beginPath(); c.moveTo(bx, by); c.lineTo(tx, ty); c.stroke();
      c.strokeStyle = sk.base; c.lineWidth = wid; c.beginPath(); c.moveTo(bx, by); c.lineTo(tx, ty); c.stroke();
      c.strokeStyle = sk.shade; c.globalAlpha = 0.5; c.lineWidth = wid * 0.38; c.beginPath(); c.moveTo(bx + wid * 0.28, by); c.lineTo(tx + wid * 0.28, ty); c.stroke();
      c.strokeStyle = sk.hi; c.globalAlpha = 0.35; c.lineWidth = wid * 0.22; c.beginPath(); c.moveTo(bx - wid * 0.25, by - 4); c.lineTo(tx - wid * 0.25, ty + 2); c.stroke(); c.globalAlpha = 1;
      if (cu > 0.45) { c.fillStyle = sk.shade; c.globalAlpha = 0.45; c.beginPath(); c.arc(tx, ty, wid * 0.42, 0, TAU); c.fill(); c.globalAlpha = 1; } // knuckle fold
      else { c.fillStyle = sk.nail; c.beginPath(); c.ellipse(tx - sin(ang) * wid * 0.25, ty + cos(ang) * wid * 0.25, wid * 0.32, wid * 0.4, ang, 0, TAU); c.fill(); }
      // joint creases
      c.strokeStyle = sk.line; c.globalAlpha = 0.35; c.lineWidth = 1.2; const mx = (bx + tx) / 2, my = (by + ty) / 2; c.beginPath(); c.moveTo(mx - wid * 0.4, my); c.lineTo(mx + wid * 0.4, my); c.stroke(); c.globalAlpha = 1;
    };
    // thumb (behind palm when curled)
    const thumb = () => {
      const a = side * (0.95 - 0.75 * tc), bx = side * 27, by = -20, len = 40 * L * (1 - 0.3 * tc), tx = bx + sin(a) * len, ty = by - cos(a) * len;
      c.strokeStyle = sk.line; c.lineWidth = 17; c.beginPath(); c.moveTo(bx, by); c.lineTo(tx, ty); c.stroke();
      c.strokeStyle = sk.base; c.lineWidth = 13.4; c.beginPath(); c.moveTo(bx, by); c.lineTo(tx, ty); c.stroke();
      c.fillStyle = sk.nail; c.beginPath(); c.ellipse(tx, ty, 4.6, 5.6, a, 0, TAU); c.fill();
    };
    thumb();
    // palm / back of hand
    c.beginPath(); c.moveTo(-25, 8); c.bezierCurveTo(-36, -14, -35, -48, -31, -70); c.lineTo(31, -70); c.bezierCurveTo(35, -48, 36, -14, 25, 8); c.closePath();
    c.fillStyle = lg(c, -30, -70, 30, 8, [[0, sk.hi], [0.35, sk.base], [1, sk.shade]]); c.fill(); c.strokeStyle = sk.line; c.lineWidth = 2.6; c.stroke();
    c.strokeStyle = sk.shade; c.globalAlpha = 0.45; c.lineWidth = 1.6;
    for (const x of [-16, -3, 10]) { c.beginPath(); c.moveTo(x * 0.7, 2); c.quadraticCurveTo(x, -34, x * 1.25, -64); c.stroke(); }
    c.globalAlpha = 1;
    // fingers: index, middle, ring, pinky
    const bases = [-21.5, -7.5, 7, 21], lens = [47, 55, 50, 39], wids = [13.4, 14, 13, 11.6];
    const sx = side;
    for (let k = 0; k < 4; k++) {
      const idx = side > 0 ? 3 - k : k; // index is on the thumb side
      let cu = idx === 0 ? ic : (idx === 1 ? (ic * 0.4 + curl * 0.6) : curl);
      if (o.tapAmp && (idx === 0 || idx === 1)) cu = U.clamp(cu + o.tapAmp * Math.max(0, sin(o.tapT * 13 + idx * 1.3)) * 0.55, 0, 1);
      const ang = (k - 1.5) * 0.115 * (1 - curl * 0.75);
      finger(bases[k], -68, ang, lens[idx], wids[idx], cu, k);
    }
    if (curl > 0.6) { // knuckle ridge when fisted
      c.strokeStyle = sk.hi; c.globalAlpha = 0.3; c.lineWidth = 2; c.beginPath(); c.moveTo(-28, -68); c.quadraticCurveTo(0, -78, 28, -68); c.stroke(); c.globalAlpha = 1;
    }
    c.restore();
  };

  /* first-person forearm + sleeve (wrist at hand origin, extending down in local space) */
  A.drawSleeve = function (c, o) {
    c.save(); c.translate(o.x, o.y); c.rotate(o.srot === undefined ? o.rot : o.srot); c.scale(o.s, o.s);
    c.beginPath(); c.moveTo(-23, 0); c.lineTo(23, 0); c.lineTo(26, 34); c.lineTo(-26, 34); c.closePath();
    c.fillStyle = lg(c, -23, 0, 23, 0, [[0, A.SKIN_P.hi], [0.4, A.SKIN_P.base], [1, A.SKIN_P.shade]]); c.fill(); c.strokeStyle = A.SKIN_P.line; c.lineWidth = 2.4; c.stroke();
    c.beginPath(); c.moveTo(-32, 24); c.lineTo(32, 24); c.lineTo(40, 70); c.lineTo(-40, 70); c.closePath();
    c.fillStyle = lg(c, -40, 0, 40, 0, [[0, '#33251f'], [0.45, '#1f1613'], [1, '#0e0809']]); c.fill(); c.strokeStyle = '#050202'; c.lineWidth = 2.5; c.stroke();
    c.strokeStyle = 'rgba(140,25,25,0.55)'; c.lineWidth = 3; c.beginPath(); c.moveTo(-33, 28); c.lineTo(33, 28); c.stroke(); // cuff trim
    c.beginPath(); c.moveTo(-40, 66); c.lineTo(40, 66); c.lineTo(86, 520); c.lineTo(-86, 520); c.closePath();
    c.fillStyle = lg(c, -80, 0, 80, 0, [[0, '#2c1f1a'], [0.35, '#1b1311'], [0.75, '#0f0a0a'], [1, '#080505']]); c.fill(); c.strokeStyle = '#050202'; c.stroke();
    c.strokeStyle = 'rgba(255,120,80,0.10)'; c.lineWidth = 6; c.beginPath(); c.moveTo(-26, 80); c.lineTo(-52, 400); c.stroke(); // rim light
    c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2; for (const k of [-12, 14, 30]) { c.beginPath(); c.moveTo(k, 90); c.quadraticCurveTo(k * 1.1 + 4, 220, k * 1.8, 420); c.stroke(); } // folds
    c.restore();
  };

  /* Dealer arm: a curved sleeve from the shoulder to the cuff, which is drawn in the hand's own frame. */
  A.drawDealerArm = function (c, sx, sy, wx, wy, theta, side, hs) {
    const fx = sin(theta), fy = -cos(theta), cx = wx - fx * 26 * hs, cy = wy - fy * 26 * hs; // cuff end (behind the hand)
    const mx = (sx + cx) / 2 + side * 34, my = (sy + cy) / 2 + 6;
    c.lineCap = 'round'; c.lineJoin = 'round';
    c.strokeStyle = '#050202'; c.lineWidth = 54; c.beginPath(); c.moveTo(sx, sy); c.quadraticCurveTo(mx, my, cx, cy); c.stroke();
    c.strokeStyle = lg(c, sx - 30, 0, sx + 30, 0, [[0, '#2a1e19'], [1, '#150e0c']]); c.lineWidth = 46; c.stroke();
    c.strokeStyle = 'rgba(255,110,70,0.12)'; c.lineWidth = 5; c.beginPath(); c.moveTo(sx - side * 12, sy + 8); c.quadraticCurveTo(mx - side * 8, my - 4, cx - side * 6, cy); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.4)'; c.lineWidth = 2; c.beginPath(); c.moveTo(sx + side * 8, sy + 24); c.quadraticCurveTo(mx + side * 4, my + 6, cx + side * 5, cy); c.stroke();
    c.save(); c.translate(wx, wy); c.rotate(theta); c.scale(hs, hs);
    c.fillStyle = A.SKIN_D.base; c.strokeStyle = A.SKIN_D.line; c.lineWidth = 2; rr(c, -15, 0, 30, 20, 6); c.fill(); c.stroke();
    c.fillStyle = '#2a1c18'; rr(c, -25, 16, 50, 24, 5); c.fill(); c.strokeStyle = '#050202'; c.stroke();
    c.strokeStyle = 'rgba(150,30,30,0.6)'; c.lineWidth = 3; c.beginPath(); c.moveTo(-24, 22); c.lineTo(24, 22); c.stroke();
    c.restore();
  };

  /* ------------------------------------------------------------------ the Dealer */
  const DRIPS = [[-68, 60, 7], [-48, 95, 9], [-22, 40, 6], [18, 52, 7], [46, 110, 10], [66, 70, 8], [-78, 120, 6]];
  A.drawDealerBody = function (c, d, t, opts) {
    opts = opts || {};
    const lean = d.lean || 0, sc = 1 + lean * 0.0035;
    c.save();
    c.translate(0, 560); c.scale(sc, sc); c.translate(d.leanX || 0, -560);
    const brt = 1 + sin(t * 0.9 * (d.brt || 1)) * 0.008, shr = (d.shr || 0) * 5 + sin(t * 0.9 * (d.brt || 1)) * 2;
    const shk = (d.shk || 0) * (sin(t * 60) * 3);
    c.translate(shk, 0);
    // torso
    c.beginPath(); c.moveTo(-70, 300 - shr); c.bezierCurveTo(-140, 312 - shr, -215, 322 - shr, -246, 392); c.lineTo(-262, 600); c.lineTo(262, 600); c.lineTo(246, 392); c.bezierCurveTo(215, 322 - shr, 140, 312 - shr, 70, 300 - shr); c.closePath();
    c.fillStyle = lg(c, 0, 300, 0, 600, [[0, '#1c1311'], [0.35, '#120c0b'], [1, '#060303']]); c.fill(); c.strokeStyle = '#040202'; c.lineWidth = 3; c.stroke();
    c.save(); c.scale(1, brt);
    // lapels + shirt + cravat
    c.fillStyle = '#0b0707'; c.beginPath(); c.moveTo(-70, 302); c.lineTo(0, 470); c.lineTo(-30, 600); c.lineTo(-120, 600); c.lineTo(-150, 380); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(70, 302); c.lineTo(0, 470); c.lineTo(30, 600); c.lineTo(120, 600); c.lineTo(150, 380); c.closePath(); c.fill();
    c.fillStyle = '#c9bfa8'; c.beginPath(); c.moveTo(-46, 300); c.lineTo(46, 300); c.lineTo(10, 470); c.lineTo(-10, 470); c.closePath(); c.fill();
    c.fillStyle = '#6e0f14'; c.beginPath(); c.moveTo(-26, 312); c.lineTo(26, 312); c.lineTo(34, 360); c.lineTo(6, 420); c.lineTo(-6, 420); c.lineTo(-34, 360); c.closePath(); c.fill(); c.strokeStyle = '#2a0508'; c.lineWidth = 2; c.stroke();
    c.strokeStyle = 'rgba(255,140,100,0.25)'; c.lineWidth = 2; c.beginPath(); c.moveTo(-70, 306); c.bezierCurveTo(-140, 316, -214, 326, -244, 396); c.stroke(); c.beginPath(); c.moveTo(70, 306); c.bezierCurveTo(140, 316, 214, 326, 244, 396); c.stroke(); // lamp rim
    // wax stains running down the coat
    c.fillStyle = 'rgba(224,212,186,0.82)';
    for (const [x, y, w, l] of [[-190, 336, 11, 70], [-210, 350, 7, 40], [188, 338, 12, 90], [212, 356, 7, 46], [-120, 318, 6, 30]]) { c.beginPath(); c.moveTo(x - w / 2, y - shr); c.lineTo(x + w / 2, y - shr); c.lineTo(x + w / 2, y + l - shr); c.arc(x, y + l - shr, w / 2, 0, PI); c.closePath(); c.fill(); }
    c.restore();
    // shoulder candles
    for (const side of [-1, 1]) {
      const bx = side * 190, by = 338 - shr, w = 25, h = 78 + side * 6;
      c.fillStyle = lg(c, bx - w / 2, 0, bx + w / 2, 0, [[0, '#a99d86'], [0.4, '#eadfc7'], [1, '#8d826c']]);
      rr(c, bx - w / 2, by - h, w, h, 5); c.fill(); c.strokeStyle = '#2b2118'; c.lineWidth = 2; c.stroke();
      c.fillStyle = '#e8dcc3'; c.beginPath(); c.ellipse(bx, by - h, w / 2, 5, 0, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = '#d8ccb0'; c.beginPath(); c.moveTo(bx - 5, by - h); c.lineTo(bx - 5, by - h + 30); c.arc(bx - 1, by - h + 30, 4, PI, 0, true); c.lineTo(bx + 3, by - h); c.fill(); // drip
      const fl = (opts.flame && opts.flame[side > 0 ? 1 : 0]) || 1, fy = by - h - 3;
      c.strokeStyle = '#000'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(bx, fy); c.lineTo(bx, fy - 6); c.stroke();
      c.save(); c.globalCompositeOperation = 'lighter';
      c.fillStyle = rg(c, bx, fy - 12, 1, 44 * fl, [[0, 'rgba(255,150,70,0.5)'], [1, 'rgba(255,80,20,0)']]); c.beginPath(); c.arc(bx, fy - 12, 44 * fl, 0, TAU); c.fill(); c.restore();
      c.fillStyle = rg(c, bx, fy - 12, 1, 14, [[0, '#fff6d0'], [0.4, '#ffb347'], [1, 'rgba(255,60,10,0)']]);
      c.beginPath(); c.moveTo(bx, fy - 4); c.bezierCurveTo(bx - 9, fy - 12, bx - 4 * fl, fy - 22 * fl, bx + 0.5 * sin(t * 9 + side), fy - 30 * fl); c.bezierCurveTo(bx + 4 * fl, fy - 22 * fl, bx + 9, fy - 12, bx, fy - 4); c.fill();
    }
    // neck
    c.fillStyle = lg(c, -30, 0, 30, 0, [[0, '#968a74'], [0.5, '#c9bda5'], [1, '#7a705c']]); rr(c, -29, 258, 58, 56, 12); c.fill(); c.strokeStyle = '#120a08'; c.lineWidth = 2; c.stroke();
    // head
    c.save();
    c.translate((d.hx || 0), 214 + (d.hy || 0)); c.rotate(d.hr || 0);
    A.drawHead(c, d, t, opts);
    c.restore();
    c.restore();
  };

  A.drawHead = function (c, d, t, opts) {
    const g = d.glitch || 0;
    // skull
    c.beginPath(); c.moveTo(0, -112); c.bezierCurveTo(70, -112, 92, -60, 86, -8); c.bezierCurveTo(82, 44, 62, 84, 30, 110); c.bezierCurveTo(14, 118, -14, 118, -30, 110); c.bezierCurveTo(-62, 84, -82, 44, -86, -8); c.bezierCurveTo(-92, -60, -70, -112, 0, -112); c.closePath();
    c.fillStyle = rg(c, -20, -50, 8, 150, [[0, '#f3ead7'], [0.45, '#d8ccb4'], [1, '#8d8068']]); c.fill();
    c.strokeStyle = '#150b09'; c.lineWidth = 3; c.stroke();
    // dripped wax
    c.fillStyle = 'rgba(243,235,215,0.9)';
    for (const [x, l, w] of DRIPS) { c.beginPath(); c.moveTo(x - w / 2, -100 + Math.abs(x) * 0.25); c.lineTo(x + w / 2, -100 + Math.abs(x) * 0.25); c.lineTo(x + w / 2, -60 + l * 0.6); c.arc(x, -60 + l * 0.6, w / 2, 0, PI); c.closePath(); c.fill(); }
    // cheek hollows + forehead shading (lit from above/front)
    c.fillStyle = rg(c, -48, 42, 2, 40, [[0, 'rgba(40,18,14,0.55)'], [1, 'rgba(40,18,14,0)']]); c.beginPath(); c.arc(-48, 42, 40, 0, TAU); c.fill();
    c.fillStyle = rg(c, 48, 42, 2, 40, [[0, 'rgba(40,18,14,0.55)'], [1, 'rgba(40,18,14,0)']]); c.beginPath(); c.arc(48, 42, 40, 0, TAU); c.fill();
    c.fillStyle = lg(c, 0, 40, 0, 118, [[0, 'rgba(90,10,12,0)'], [1, 'rgba(90,10,12,0.35)']]); c.beginPath(); c.ellipse(0, 40, 78, 80, 0, 0, TAU); c.fill();
    // eyes
    const eo = U.clamp(d.eyeO === undefined ? 1 : d.eyeO, 0.2, 1.5), lx = (d.lookX || 0) * 8, ly = -(d.lookY === undefined ? 0.15 : d.lookY) * 7;
    for (const s of [-1, 1]) {
      const ex = s * 36, ey = -12;
      c.fillStyle = '#080304'; c.beginPath(); c.ellipse(ex, ey, 22, 25 * Math.min(1, eo), 0, 0, TAU); c.fill();
      c.strokeStyle = 'rgba(0,0,0,0.6)'; c.lineWidth = 6; c.beginPath(); c.ellipse(ex, ey, 24, 27 * Math.min(1, eo), 0, 0, TAU); c.stroke();
      const ix = ex + lx * (s * 0.0 + 1), iy = ey + ly;
      c.save(); c.globalCompositeOperation = 'lighter';
      c.fillStyle = rg(c, ix, iy, 0.5, 15 * (0.9 + 0.12 * sin(t * 3 + s)), [[0, 'rgba(255,210,170,1)'], [0.25, 'rgba(255,70,50,0.95)'], [1, 'rgba(160,10,10,0)']]); c.beginPath(); c.arc(ix, iy, 15, 0, TAU); c.fill(); c.restore();
      c.fillStyle = '#1b0405'; c.beginPath(); c.arc(ix, iy, 3 * eo, 0, TAU); c.fill();
      if (eo > 1.2) { c.strokeStyle = 'rgba(255,255,255,0.15)'; c.lineWidth = 1.5; c.beginPath(); c.arc(ix, iy, 9, 0, TAU); c.stroke(); }
      // eyelid (wax) closing from top when eyeO < 1
      if (eo < 1) { c.fillStyle = '#cdbfa5'; c.beginPath(); c.ellipse(ex, ey - 25 * eo + (25 * (1 - eo)) * -0.2, 24, 25 * (1 - eo) + 1, 0, PI, TAU); c.fill(); }
      // brow
      const b = s < 0 ? (d.bL || 0) : (d.bR || 0), inner = 11 * b, outer = -5 * b;
      c.strokeStyle = '#150808'; c.lineWidth = 7; c.lineCap = 'round';
      c.beginPath(); c.moveTo(ex + s * 27, ey - 38 + outer); c.quadraticCurveTo(ex, ey - 48 + inner * 0.3, ex - s * 25, ey - 38 + inner); c.stroke();
    }
    // nose: melted slits
    c.fillStyle = '#3a1c18'; c.beginPath(); c.ellipse(-8, 22, 3.4, 6.5, 0.3, 0, TAU); c.fill(); c.beginPath(); c.ellipse(8, 22, 3.4, 6.5, -0.3, 0, TAU); c.fill();
    c.strokeStyle = 'rgba(70,40,30,0.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -4); c.quadraticCurveTo(-5, 10, -3, 20); c.stroke();
    // mouth: wide stitched grin
    const mC = d.mC === undefined ? 0.35 : d.mC, talk = d.talk || 0, mo = U.clamp((d.mO || 0) + talk * (0.18 + 0.4 * Math.abs(sin(t * 13))), 0, 1);
    const my = 66, w = 52, end = my - mC * 12, ctrl = my + mC * 30, open = mo * 30;
    c.beginPath(); c.moveTo(-w, end); c.quadraticCurveTo(0, ctrl, w, end);
    c.quadraticCurveTo(0, ctrl + 6 + open * 1.3, -w, end); c.closePath();
    c.fillStyle = '#120405'; c.fill(); c.strokeStyle = '#1a0807'; c.lineWidth = 2.6; c.stroke();
    if (open > 2 || mC > 0.2) { // teeth: jagged little pegs along the upper lip
      c.fillStyle = '#e8dfc9'; const n = 11;
      for (let i = 0; i < n; i++) { const u = (i + 0.5) / n, x = -w + u * 2 * w, yb = (1 - u) * (1 - u) * end + 2 * (1 - u) * u * ctrl + u * u * end; c.beginPath(); c.moveTo(x - 3.4, yb + 1); c.lineTo(x + 3.4, yb + 1); c.lineTo(x, yb + 7 + open * 0.2 + (i % 2) * 2.5); c.closePath(); c.fill(); }
    }
    c.strokeStyle = 'rgba(25,8,8,0.9)'; c.lineWidth = 2; // stitches at the corners
    for (const s of [-1, 1]) for (let k = 0; k < 4; k++) { const x = s * (w + 2 + k * 6), y = end - mC * 2 * (k + 1) * 0 + (k - 1.5) * 1.5; c.beginPath(); c.moveTo(x, y - 8 + k * 0.5); c.lineTo(x - s * 3, y + 9); c.stroke(); }
    // ears/jaw edge highlight
    c.strokeStyle = 'rgba(255,200,170,0.18)'; c.lineWidth = 3; c.beginPath(); c.moveTo(-70, -60); c.bezierCurveTo(-60, -100, -20, -108, 0, -108); c.stroke();
    if (g > 0.05) { // glitch: displaced slices + colour fringes
      c.save(); c.globalCompositeOperation = 'lighter'; c.globalAlpha = 0.55 * g;
      for (let i = 0; i < 4; i++) { const y = -110 + Math.random() * 220, h = 6 + Math.random() * 22; c.fillStyle = i % 2 ? 'rgba(255,40,40,0.5)' : 'rgba(40,255,230,0.35)'; c.fillRect(-90 + (Math.random() - 0.5) * 50 * g, y, 180, h); }
      c.restore();
    }
  };

  /* ------------------------------------------------------------------ items */
  const OUT = '#0b0506';
  A.drawItem = function (c, id, o) {
    c.save(); c.translate(o.x, o.y);
    c.rotate((o.rot || 0) + (o.irot || 0));
    const isc = o.isc === undefined ? 1 : o.isc;
    if (id === 'can') c.scale(o.s * isc, o.s * (1 + (1 - isc) * 0.2)); else c.scale(o.s * isc, o.s * isc);
    if (o.alpha !== undefined) c.globalAlpha = o.alpha;
    c.lineJoin = 'round'; c.lineCap = 'round';
    const io = o.io || 0, il = o.il || 0, ic = o.ic || 0, t = o.t || 0;
    switch (id) {
      case 'magnifier': {
        c.fillStyle = lg(c, -6, 0, 6, 0, [[0, '#4a2b1b'], [0.5, '#7a4a2c'], [1, '#2c180f']]); rr(c, -6, 6, 12, 36, 5); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.5; c.stroke();
        c.fillStyle = '#b08a3a'; rr(c, -7.5, 2, 15, 9, 3); c.fill(); c.stroke();
        c.beginPath(); c.arc(0, -16, 24, 0, TAU); c.strokeStyle = OUT; c.lineWidth = 9; c.stroke(); c.strokeStyle = lg(c, -20, -36, 20, 4, [[0, '#e5c36a'], [0.5, '#a07c2e'], [1, '#5e4515']]); c.lineWidth = 6; c.stroke();
        c.beginPath(); c.arc(0, -16, 21, 0, TAU); c.fillStyle = rg(c, -6, -22, 2, 24, [[0, 'rgba(255,235,220,0.55)'], [1, 'rgba(150,100,100,0.25)']]); c.fill();
        c.strokeStyle = 'rgba(255,255,255,0.55)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-4, -30); c.lineTo(3, -18); c.lineTo(-2, -6); c.moveTo(3, -18); c.lineTo(14, -14); c.stroke();
        c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 2.2; c.beginPath(); c.arc(0, -16, 15, 3.6, 4.6); c.stroke();
        break;
      }
      case 'handcuffs': {
        const ring = (x, open) => {
          c.strokeStyle = OUT; c.lineWidth = 9.5; c.beginPath(); if (open) c.arc(x, 0, 14, 0.9, TAU - 0.9 + 0.0); else c.arc(x, 0, 14, 0, TAU); c.stroke();
          c.strokeStyle = lg(c, x - 14, -14, x + 14, 14, [[0, '#d2d0cc'], [0.5, '#8a8884'], [1, '#4b4946']]); c.lineWidth = 6; c.stroke();
        };
        c.strokeStyle = OUT; c.lineWidth = 6; c.beginPath(); c.moveTo(-8, 0); c.lineTo(8, 0); c.stroke(); c.strokeStyle = '#908e8a'; c.lineWidth = 3; c.stroke();
        for (const x of [-4, 0, 4]) { c.strokeStyle = '#6d6b67'; c.lineWidth = 2; c.beginPath(); c.ellipse(x, 0, 3.4, 2.2, 0, 0, TAU); c.stroke(); }
        ring(-24, false);
        c.save(); c.translate(io * 6, -io * 8); c.rotate(-io * 0.3); ring(24, io > 0.3); c.restore();
        c.fillStyle = '#5b5955'; rr(c, -14, -6, 10, 12, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2; c.stroke(); c.fillStyle = '#16100e'; c.beginPath(); c.arc(-9, 0, 2, 0, TAU); c.fill();
        break;
      }
      case 'cigarette': {
        const len = 58;
        c.fillStyle = lg(c, 0, -5, 0, 5, [[0, '#f5efe4'], [1, '#bdb4a4']]); rr(c, -len / 2, -4.5, len * 0.78, 9, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke();
        c.fillStyle = lg(c, 0, -5, 0, 5, [[0, '#d99a4a'], [1, '#8a5a24']]); rr(c, len / 2 - len * 0.22, -4.5, len * 0.22, 9, 3); c.fill(); c.stroke();
        c.fillStyle = '#6b6560'; rr(c, -len / 2 - 2, -4, 6, 8, 2); c.fill();
        if (ic > 0.02) { c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = rg(c, -len / 2 - 2, 0, 1, 16 * ic + 3, [[0, 'rgba(255,200,120,0.95)'], [0.4, 'rgba(255,80,30,0.7)'], [1, 'rgba(255,40,10,0)']]); c.beginPath(); c.arc(-len / 2 - 2, 0, 16 * ic + 3, 0, TAU); c.fill(); c.restore(); }
        break;
      }
      case 'battery': {
        c.fillStyle = '#9a8338'; rr(c, -5, -34, 10, 8, 2); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke();
        c.fillStyle = lg(c, -13, 0, 13, 0, [[0, '#55504b'], [0.4, '#2c2926'], [1, '#161312']]); rr(c, -13, -28, 26, 58, 5); c.fill(); c.stroke();
        c.fillStyle = '#8c1319'; c.fillRect(-13, -4, 26, 14); c.strokeStyle = OUT; c.strokeRect(-13, -4, 26, 14);
        c.fillStyle = '#e8dccb'; c.fillRect(-2, -1, 4, 8); c.fillRect(-5, 1, 10, 4);
        c.strokeStyle = 'rgba(255,255,255,0.15)'; c.lineWidth = 2; c.beginPath(); c.moveTo(-9, -24); c.lineTo(-9, 26); c.stroke();
        if (ic > 0.02) { c.save(); c.globalCompositeOperation = 'lighter'; c.strokeStyle = 'rgba(200,225,255,' + (0.5 * ic) + ')'; c.lineWidth = 2; for (let i = 0; i < 4; i++) { c.beginPath(); let y = -30; c.moveTo(-14 + i * 9, y); for (let k = 0; k < 6; k++) c.lineTo(-14 + i * 9 + (Math.random() - 0.5) * 12, y += 10); c.stroke(); } c.restore(); }
        break;
      }
      case 'medicine': {
        c.save();
        c.fillStyle = lg(c, -17, 0, 17, 0, [[0, '#e0903a'], [0.5, '#a5571a'], [1, '#5c2d0c']]); rr(c, -17, -14, 34, 46, 7); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.4; c.stroke();
        c.fillStyle = '#e7dfce'; rr(c, -17, 0, 34, 20, 2); c.fill(); c.strokeStyle = '#2a1a10'; c.lineWidth = 1.4; c.stroke();
        c.fillStyle = '#9b1218'; c.fillRect(-2, 4, 4, 12); c.fillRect(-6, 8, 12, 4);
        c.fillStyle = lg(c, -10, 0, 10, 0, [[0, '#8a8174'], [1, '#52493e']]); rr(c, -9, -24, 18, 11, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke();
        c.restore();
        c.save(); c.translate(io * 22, -io * 18 - 32 + 32 * (1 - io) * 0); c.rotate(io * 0.9);
        if (io > 0.05) { c.translate(0, -26 + 0); c.fillStyle = lg(c, -10, 0, 10, 0, [[0, '#e8e0d2'], [1, '#9c9384']]); rr(c, -11, -6, 22, 12, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.2; c.stroke(); }
        c.restore();
        if (ic > 0.05) { c.fillStyle = '#e9e0cf'; for (const [x, y, r] of [[-14, -30, 0.5], [16, -34, -0.6]]) { c.save(); c.translate(x, y); c.rotate(r); c.globalAlpha *= ic; rr(c, -7, -3.5, 14, 7, 3.5); c.fill(); c.strokeStyle = OUT; c.lineWidth = 1.4; c.stroke(); c.restore(); } }
        break;
      }
      case 'can': {
        c.fillStyle = lg(c, -17, 0, 17, 0, [[0, '#8e8d89'], [0.25, '#e7e5df'], [0.55, '#b0aea8'], [1, '#575551']]); rr(c, -17, -30, 34, 62, 6); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.6; c.stroke();
        c.fillStyle = '#a2151b'; c.fillRect(-17, -12, 34, 22); c.strokeStyle = OUT; c.lineWidth = 1.6; c.strokeRect(-17, -12, 34, 22);
        c.fillStyle = '#f4ead2'; c.beginPath(); c.moveTo(0, -9); c.bezierCurveTo(-6, -2, -3, 4, 0, 8); c.bezierCurveTo(3, 4, 6, -2, 0, -9); c.fill(); // flame emblem
        c.fillStyle = '#7a7873'; c.beginPath(); c.ellipse(0, -30, 17, 5, 0, 0, TAU); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2; c.stroke();
        c.save(); c.translate(3, -31); c.rotate(-io * 1.1); c.fillStyle = '#c9c7c0'; rr(c, -7, -3.5, 13, 7, 3); c.fill(); c.stroke(); c.restore();
        if (io > 0.3) { c.fillStyle = '#0a0506'; c.beginPath(); c.ellipse(-6, -30, 5, 2.5, 0, 0, TAU); c.fill(); }
        break;
      }
      case 'lighter': {
        c.fillStyle = lg(c, -12, 0, 12, 0, [[0, '#7a5a1d'], [0.4, '#e2bf62'], [1, '#6b4d17']]); rr(c, -12, -8, 24, 40, 4); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.5; c.stroke();
        c.strokeStyle = 'rgba(70,45,10,0.7)'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(-12, 12); c.lineTo(12, 12); c.moveTo(-12, 20); c.lineTo(12, 20); c.stroke();
        c.fillStyle = '#524a40'; c.beginPath(); c.arc(4, -11, 4.5, 0, TAU); c.fill(); c.stroke();
        c.save(); c.translate(-12, -8); c.rotate(-io * 2.2); c.fillStyle = lg(c, 0, -14, 24, 0, [[0, '#f0cf78'], [1, '#8c6b22']]); rr(c, 0, -14, 24, 14, 4); c.fill(); c.strokeStyle = OUT; c.stroke(); c.restore();
        if (il > 0.02) {
          const f = il * (0.9 + 0.2 * sin(t * 17) + 0.1 * sin(t * 31)), fy = -16;
          c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = rg(c, 2, fy - 8, 1, 46 * f, [[0, 'rgba(255,170,80,0.55)'], [1, 'rgba(255,70,20,0)']]); c.beginPath(); c.arc(2, fy - 8, 46 * f, 0, TAU); c.fill(); c.restore();
          c.fillStyle = rg(c, 2, fy - 8, 1, 17 * f, [[0, '#fffbe6'], [0.35, '#ffc65c'], [0.8, '#ff6a1c'], [1, 'rgba(255,60,10,0)']]);
          c.beginPath(); c.moveTo(2, fy + 2); c.bezierCurveTo(-8, fy - 5, -3, fy - 18 * f, 2 + sin(t * 11) * 1.5, fy - 28 * f); c.bezierCurveTo(7, fy - 18 * f, 12, fy - 5, 2, fy + 2); c.fill();
        }
        break;
      }
      case 'knife': {
        c.fillStyle = lg(c, -30, 0, 30, 0, [[0, '#6b3a1c'], [1, '#3a1d0d']]); rr(c, -34, 6, 30, 12, 4); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.4; c.stroke();
        c.fillStyle = '#b08a3a'; rr(c, -6, 2, 6, 20, 2); c.fill(); c.stroke();
        c.fillStyle = lg(c, 0, 0, 0, 20, [[0, '#e8e6e2'], [1, '#8d8b87']]); c.beginPath(); c.moveTo(0, 4); c.lineTo(44, 8); c.lineTo(52, 12); c.lineTo(0, 20); c.closePath(); c.fill(); c.stroke();
        c.strokeStyle = 'rgba(255,255,255,0.5)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(4, 8); c.lineTo(44, 10.5); c.stroke();
        break;
      }
      case 'blank': {
        c.save(); c.rotate(-0.5);
        c.fillStyle = lg(c, -14, 0, 14, 0, [[0, '#8d8a85'], [1, '#4b4945']]); rr(c, -13, -34, 26, 62, 5); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.4; c.stroke();
        c.fillStyle = '#c9a24a'; rr(c, -13, 16, 26, 14, 4); c.fill(); c.stroke(); c.fillStyle = '#6a4a88'; c.fillRect(-13, -4, 26, 8);
        c.restore(); break;
      }
      case 'spray': {
        c.fillStyle = lg(c, -14, 0, 14, 0, [[0, '#4a4350'], [0.5, '#1d1822'], [1, '#0d0a10']]); rr(c, -14, -22, 28, 58, 6); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.4; c.stroke();
        c.fillStyle = '#8c1319'; c.fillRect(-14, -4, 28, 16); c.fillStyle = '#e8dccb'; c.beginPath(); c.arc(0, 4, 5, 0, TAU); c.fill();
        c.fillStyle = '#d8d4cc'; rr(c, -7, -32, 14, 11, 3); c.fill(); c.stroke(); c.fillRect(-2, -38, 12, 6); c.strokeRect(-2, -38, 12, 6);
        if (il > 0.05) { c.fillStyle = 'rgba(230,200,240,' + 0.35 * il + ')'; for (let i = 0; i < 5; i++) { c.beginPath(); c.arc(16 + i * 10, -36 - i * 4, 5 + i * 3, 0, TAU); c.fill(); } }
        break;
      }
      case 'rope': {
        c.strokeStyle = OUT; c.lineWidth = 9; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(0, 4 - i * 5, 30 - i * 3, 14 - i * 2, 0, 0, TAU); c.stroke(); }
        c.strokeStyle = '#9a6a38'; c.lineWidth = 5.5; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(0, 4 - i * 5, 30 - i * 3, 14 - i * 2, 0, 0, TAU); c.stroke(); }
        c.strokeStyle = '#d6a96a'; c.lineWidth = 1.4; for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(0, 3 - i * 5, 30 - i * 3, 14 - i * 2, 0, 3.4, 5.6); c.stroke(); }
        break;
      }
      case 'scrambler': {
        c.strokeStyle = '#2b2a28'; c.lineWidth = 3; c.beginPath(); c.moveTo(20, -18); c.lineTo(30, -42); c.stroke(); c.fillStyle = '#a21a1f'; c.beginPath(); c.arc(30, -43, 3.5, 0, TAU); c.fill();
        c.fillStyle = lg(c, 0, -20, 0, 20, [[0, '#2b2724'], [1, '#0f0c0b']]); rr(c, -30, -20, 60, 40, 5); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.6; c.stroke();
        c.fillStyle = '#6a1015'; c.fillRect(-30, 12, 60, 4);
        const lit = ic > 0.05; c.fillStyle = lit ? '#14281a' : '#0a0d0a'; rr(c, -23, -13, 30, 22, 2); c.fill(); c.strokeStyle = '#000'; c.lineWidth = 1.6; c.stroke();
        if (lit) { c.save(); c.beginPath(); rr(c, -23, -13, 30, 22, 2); c.clip(); for (let y = -13; y < 9; y += 2.4) { c.fillStyle = 'rgba(120,255,150,' + (0.12 + 0.5 * Math.random() * ic) + ')'; c.fillRect(-23, y, 30, 1.4); } c.restore(); }
        for (const [x, y] of [[17, -6], [17, 3]]) { c.fillStyle = '#4c4742'; c.beginPath(); c.arc(x, y, 4.2, 0, TAU); c.fill(); c.strokeStyle = OUT; c.lineWidth = 1.6; c.stroke(); c.strokeStyle = '#d8d0c0'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + cos(x + ic * 3) * 3.2, y + sin(y + ic * 3) * 3.2); c.stroke(); }
        c.fillStyle = (lit && sin(t * 9) > 0) || !lit && sin(t * 2) > 0.7 ? '#ff4b3a' : '#4a1210'; c.beginPath(); c.arc(-24, 14, 2, 0, TAU); c.fill();
        break;
      }
      case 'coin': {
        const sq = Math.abs(cos(o.irot ? 0 : 0)); // squash is applied through irot rotation elsewhere; here draw a face-on coin with edge thickness
        c.fillStyle = rg(c, -6, -6, 2, 24, [[0, '#e0c070'], [0.5, '#a07c34'], [1, '#5a4116']]); c.beginPath(); c.arc(0, 0, 19, 0, TAU); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.6; c.stroke();
        c.strokeStyle = 'rgba(60,40,10,0.7)'; c.lineWidth = 1.6; c.beginPath(); c.arc(0, 0, 15.5, 0, TAU); c.stroke();
        c.fillStyle = '#080405'; c.beginPath(); c.arc(0, 0, 6.5, 0, TAU); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2; c.stroke(); // the hollow
        c.strokeStyle = 'rgba(255,240,190,0.35)'; c.lineWidth = 2; c.beginPath(); c.arc(0, 0, 17, 3.7, 4.7); c.stroke();
        c.fillStyle = 'rgba(60,40,10,0.6)'; for (let i = 0; i < 6; i++) { const a = i * TAU / 6; c.beginPath(); c.arc(cos(a) * 11, sin(a) * 11, 1.2, 0, TAU); c.fill(); }
        break;
      }
      default: { c.fillStyle = '#666'; c.fillRect(-15, -15, 30, 30); }
    }
    c.restore();
  };

  /* ------------------------------------------------------------------ the Caster (weapon) */
  A.drawGun = function (c, o) {
    const L = 300, fore = U.clamp(o.fore, 0.08, 1.2), sc = o.sc || 1, kick = o.kick || 0, brk = o.brk || 0, ch = o.charge || 0;
    c.save(); c.translate(o.x, o.y); c.rotate(o.ang - kick * 0.08); c.scale(sc * fore, sc); c.translate(-kick * 22 / Math.max(fore, 0.3), 0);
    c.lineJoin = 'round';
    // stock
    c.beginPath(); c.moveTo(-130, 10); c.bezierCurveTo(-125, -14, -80, -24, -10, -22); c.lineTo(-6, 12); c.bezierCurveTo(-60, 16, -100, 20, -130, 10); c.closePath();
    c.fillStyle = lg(c, -130, -24, -130, 20, [[0, '#6a3b22'], [0.5, '#4a2615'], [1, '#2a140b']]); c.fill(); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
    c.strokeStyle = 'rgba(20,8,4,0.55)'; c.lineWidth = 1.2; for (let i = 0; i < 5; i++) { c.beginPath(); c.moveTo(-122 + i * 3, 6 - i * 2); c.quadraticCurveTo(-70, -8 - i * 2, -14, -16 + i * 2); c.stroke(); }
    c.fillStyle = '#9a7d36'; rr(c, -134, -2, 7, 20, 2); c.fill(); c.stroke(); // butt plate
    // trigger guard + trigger
    c.strokeStyle = '#201512'; c.lineWidth = 4; c.beginPath(); c.moveTo(-6, 12); c.quadraticCurveTo(14, 36, 40, 12); c.stroke(); c.strokeStyle = '#7a756d'; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#585049'; c.beginPath(); c.moveTo(8, 12); c.lineTo(14, 12); c.lineTo(11, 26); c.closePath(); c.fill();
    // barrel assembly (hinges open at breech)
    c.save(); c.translate(44, -12); c.rotate(-brk * 0.32); c.translate(-44, 12);
    c.fillStyle = lg(c, 0, -22, 0, 8, [[0, '#7c7771'], [0.3, '#4b4742'], [1, '#1c1a18']]); rr(c, 40, -26, L - 40, 14, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2.6; c.stroke();
    c.fillStyle = lg(c, 0, -12, 0, 8, [[0, '#55514c'], [1, '#161412']]); rr(c, 40, -13, L - 100, 14, 3); c.fill(); c.stroke();
    c.fillStyle = '#9a7d36'; for (const x of [90, 170, L - 14]) { c.fillRect(x, -27, 7, 16); c.strokeRect(x, -27, 7, 16); }
    c.fillStyle = '#2b2623'; c.fillRect(L - 4, -29, 10, 20);
    c.strokeStyle = 'rgba(255,255,255,0.18)'; c.lineWidth = 2; c.beginPath(); c.moveTo(48, -23); c.lineTo(L - 10, -23); c.stroke();
    c.restore();
    if (brk > 0.2) { c.fillStyle = '#a3141b'; rr(c, 30, -22, 10, 26 * brk, 2); c.fill(); c.strokeStyle = OUT; c.lineWidth = 1.5; c.stroke(); c.fillStyle = '#d9b45a'; c.fillRect(30, -22, 10, 4); }
    // receiver
    c.fillStyle = lg(c, 0, -26, 0, 14, [[0, '#6b6359'], [0.4, '#3a342e'], [1, '#17130f']]); rr(c, -14, -26, 62, 40, 5); c.fill(); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
    c.fillStyle = '#b08a3a'; rr(c, 14, -20, 22, 26, 3); c.fill(); c.strokeStyle = OUT; c.lineWidth = 2; c.stroke();
    c.fillStyle = '#6a0f14'; c.beginPath(); c.arc(25, -7, 5, 0, TAU); c.fill(); c.stroke();
    // forend (the pump)
    c.fillStyle = lg(c, 0, -2, 0, 16, [[0, '#6a3b22'], [1, '#2a140b']]); rr(c, 118, -2, 96, 20, 6); c.fill(); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 1.5; for (let x = 128; x < 206; x += 9) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, 16); c.stroke(); }
    c.fillStyle = lg(c, 0, 0, 0, 8, [[0, '#59544e'], [1, '#1c1a18']]); rr(c, 60, 4, 150, 9, 3); c.fill(); c.stroke(); // magazine tube
    if (ch > 0.02) { // battery charge: pale arcs along the barrel
      c.save(); c.globalCompositeOperation = 'lighter'; c.strokeStyle = 'rgba(190,225,255,' + (0.35 + 0.5 * ch) + ')'; c.lineWidth = 2.2;
      for (let k = 0; k < 3; k++) { c.beginPath(); let x = 46; c.moveTo(x, -18); while (x < L - 10) { x += 16 + Math.random() * 14; c.lineTo(x, -18 + (Math.random() - 0.5) * 12); } c.stroke(); }
      c.fillStyle = rg(c, 150, -16, 1, 110, [[0, 'rgba(170,210,255,' + (0.18 * ch) + ')'], [1, 'rgba(170,210,255,0)']]); c.beginPath(); c.arc(150, -16, 110, 0, TAU); c.fill(); c.restore();
    }
    c.restore();
    // muzzle seen head-on when the weapon points at the viewer
    const dirY = sin(o.ang);
    if (fore < 0.6 && dirY > 0.3) {
      const mx = o.x + cos(o.ang) * (L - 2) * fore * sc, my = o.y + sin(o.ang) * (L - 2) * fore * sc, a = U.clamp((0.6 - fore) / 0.4, 0, 1), r = 20 * sc;
      c.save(); c.globalAlpha = a;
      c.fillStyle = lg(c, mx - r, my - r, mx + r, my + r, [[0, '#8f8a82'], [1, '#2a2724']]); c.beginPath(); c.arc(mx, my, r, 0, TAU); c.fill(); c.strokeStyle = OUT; c.lineWidth = 3; c.stroke();
      c.fillStyle = '#030102'; c.beginPath(); c.arc(mx, my, r * 0.66, 0, TAU); c.fill();
      c.fillStyle = rg(c, mx, my, 1, r * 0.62, [[0, 'rgba(255,70,40,' + (0.25 + (o.dread || 0) * 0.3) + ')'], [1, 'rgba(0,0,0,0)']]); c.beginPath(); c.arc(mx, my, r * 0.62, 0, TAU); c.fill();
      c.restore();
    }
    return { mx: o.x + cos(o.ang) * (L + 8) * fore * sc, my: o.y + sin(o.ang) * (L + 8) * fore * sc };
  };
  /* gun-local point -> world (used to anchor hands) */
  A.gunPoint = function (o, lx, ly) {
    const fore = U.clamp(o.fore, 0.08, 1.2), sc = o.sc || 1, a = o.ang - (o.kick || 0) * 0.08, px = (lx - (o.kick || 0) * 22 / Math.max(fore, 0.3)) * sc * fore, py = ly * sc;
    return { x: o.x + px * cos(a) - py * sin(a), y: o.y + px * sin(a) + py * cos(a) };
  };

  /* ------------------------------------------------------------------ sprites for particles */
  A.sprites = {};
  A.buildSprites = function () {
    const mk = (n, f) => { const k = document.createElement('canvas'); k.width = k.height = n; f(k.getContext('2d'), n); return k; };
    A.sprites.soft = mk(64, (c, n) => { c.fillStyle = rg(c, n / 2, n / 2, 0, n / 2, [[0, 'rgba(255,255,255,1)'], [0.4, 'rgba(255,255,255,0.45)'], [1, 'rgba(255,255,255,0)']]); c.fillRect(0, 0, n, n); });
    A.sprites.smoke = mk(96, (c, n) => { const r = rng(5); for (let i = 0; i < 14; i++) { const x = n / 2 + (r() - 0.5) * 30, y = n / 2 + (r() - 0.5) * 30; c.fillStyle = rg(c, x, y, 0, 24 + r() * 8, [[0, 'rgba(215,205,200,0.34)'], [1, 'rgba(215,205,200,0)']]); c.beginPath(); c.arc(x, y, 34, 0, TAU); c.fill(); } });
    A.sprites.spark = mk(32, (c, n) => { c.fillStyle = rg(c, n / 2, n / 2, 0, n / 2, [[0, 'rgba(255,255,230,1)'], [0.3, 'rgba(255,170,60,0.9)'], [1, 'rgba(255,60,10,0)']]); c.fillRect(0, 0, n, n); });
    A.sprites.noise = [0, 1, 2].map((s) => mk(64, (c, n) => { const r = rng(900 + s), im = c.createImageData(n, n); for (let i = 0; i < n * n; i++) { const v = (r() * 255) | 0; im.data[i * 4] = v; im.data[i * 4 + 1] = v; im.data[i * 4 + 2] = v; im.data[i * 4 + 3] = 255; } c.putImageData(im, 0, 0); }));
    A.sprites.grain = mk(128, (c, n) => { const r = rng(77), im = c.createImageData(n, n); for (let i = 0; i < n * n; i++) { const v = (r() * 255) | 0; im.data[i * 4] = v; im.data[i * 4 + 1] = v * 0.8; im.data[i * 4 + 2] = v * 0.8; im.data[i * 4 + 3] = 255; } c.putImageData(im, 0, 0); });
    A.sprites.scan = mk(4, (c, n) => { c.fillStyle = 'rgba(0,0,0,0.45)'; c.fillRect(0, 0, n, 1); c.fillStyle = 'rgba(0,0,0,0.0)'; c.fillRect(0, 1, n, 3); });
  };

  /* ------------------------------------------------------------------ icons for the HTML UI (cached) */
  const iconCache = {};
  A.icon = function (id, size) {
    const key = id + size; if (iconCache[key]) return iconCache[key];
    const k = document.createElement('canvas'); k.width = k.height = size; const c = k.getContext('2d');
    A.drawItem(c, id, { x: size / 2, y: size / 2 + (id === 'cigarette' || id === 'handcuffs' || id === 'scrambler' || id === 'coin' ? 0 : 2), s: size / 96, rot: id === 'cigarette' ? -0.5 : 0, t: 0, ic: id === 'scrambler' ? 0.6 : 0 });
    iconCache[key] = k.toDataURL('image/png'); return iconCache[key];
  };
  A.silhouette = function (size) {
    const k = document.createElement('canvas'); k.width = k.height = size; const c = k.getContext('2d');
    c.fillStyle = 'rgba(255,255,255,0.08)'; c.beginPath(); c.arc(size / 2, size / 2, size * 0.28, 0, TAU); c.fill(); c.fillStyle = 'rgba(255,255,255,0.25)'; c.font = 'bold ' + size * 0.4 + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('?', size / 2, size / 2 + 2);
    return k.toDataURL('image/png');
  };

  /* ------------------------------------------------------------------ static room + table (cached by renderer) */
  A.tvRects = [];
  A.drawRoom = function (c, W, H, ox, oy) { // c has the logical transform applied; area to cover: [-ox..W+ox] x [-oy..H+oy]
    const r = rng(2024), x0 = -ox, y0 = -oy, ww = W + ox * 2, hh = H + oy * 2;
    c.fillStyle = lg(c, 0, y0, 0, 420, [[0, '#2a0d0f'], [0.5, '#1a090a'], [1, '#0d0506']]); c.fillRect(x0, y0, ww, hh);
    // concrete blotches + speckle
    for (let i = 0; i < 70; i++) { const x = x0 + r() * ww, y = y0 + r() * 440, rad = 40 + r() * 140; c.fillStyle = rg(c, x, y, 0, rad, [[0, 'rgba(' + (60 + r() * 40 | 0) + ',20,20,' + (0.05 + r() * 0.08) + ')'], [1, 'rgba(0,0,0,0)']]); c.beginPath(); c.arc(x, y, rad, 0, TAU); c.fill(); }
    c.fillStyle = 'rgba(0,0,0,0.25)'; for (let i = 0; i < 700; i++) c.fillRect(x0 + r() * ww, y0 + r() * 440, 1 + r() * 2, 1 + r() * 2);
    // corrugated panel seams
    c.strokeStyle = 'rgba(0,0,0,0.45)'; c.lineWidth = 2; for (let x = x0 - (x0 % 110); x < W + ox; x += 110) { c.beginPath(); c.moveTo(x, y0); c.lineTo(x, 420); c.stroke(); c.strokeStyle = 'rgba(255,120,90,0.04)'; c.beginPath(); c.moveTo(x + 3, y0); c.lineTo(x + 3, 420); c.stroke(); c.strokeStyle = 'rgba(0,0,0,0.45)'; }
    // pipes along the ceiling
    for (const [y, th] of [[44, 26], [88, 16]]) { c.fillStyle = lg(c, 0, y - th / 2, 0, y + th / 2, [[0, '#4a2a26'], [0.35, '#2d1715'], [1, '#100808']]); c.fillRect(x0, y - th / 2, ww, th); c.strokeStyle = '#050202'; c.lineWidth = 2; c.strokeRect(x0, y - th / 2, ww, th); for (let x = x0 + 80; x < W + ox; x += 230) { c.fillStyle = '#1a0d0b'; c.fillRect(x, y - th / 2 - 3, 12, th + 6); } }
    // left: speaker stack
    for (let i = 0; i < 2; i++) { const sx = 40, sy = 160 + i * 120; c.fillStyle = '#120a09'; rr(c, sx, sy, 170, 112, 6); c.fill(); c.strokeStyle = '#040202'; c.lineWidth = 3; c.stroke(); c.fillStyle = '#080404'; c.beginPath(); c.arc(sx + 85, sy + 56, 40, 0, TAU); c.fill(); c.strokeStyle = '#2a1613'; c.lineWidth = 3; c.stroke(); c.beginPath(); c.arc(sx + 85, sy + 56, 18, 0, TAU); c.stroke(); c.fillStyle = '#1d0e0c'; c.beginPath(); c.arc(sx + 85, sy + 56, 8, 0, TAU); c.fill(); }
    // right: shelf with two CRTs
    c.fillStyle = '#251410'; c.fillRect(1000, 262, 250, 12); c.strokeStyle = '#050202'; c.lineWidth = 2; c.strokeRect(1000, 262, 250, 12);
    c.fillStyle = '#251410'; c.fillRect(1040, 150, 200, 10); c.strokeRect(1040, 150, 200, 10);
    A.tvRects = [];
    const tv = (x, y, w, h) => { c.fillStyle = lg(c, x, y, x + w, y + h, [[0, '#2a2420'], [1, '#100c0a']]); rr(c, x, y, w, h, 8); c.fill(); c.strokeStyle = '#030101'; c.lineWidth = 3; c.stroke(); c.fillStyle = '#050505'; rr(c, x + 10, y + 10, w * 0.74, h - 22, 10); c.fill(); A.tvRects.push({ x: x + 10, y: y + 10, w: w * 0.74, h: h - 22, r: 10 }); c.fillStyle = '#3a1512'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(x + w - 17, y + 20 + k * 18, 6, 0, TAU); c.fill(); } };
    tv(1020, 168, 170, 94); tv(1060, 50 + 0, 160, 100 - 0 + 0);
    // door (dark) far left edge, used by the victory ending
    c.fillStyle = '#060303'; c.fillRect(-170, 120, 190, 300); c.strokeStyle = '#2a1512'; c.lineWidth = 6; c.strokeRect(-170, 120, 190, 300);
    // fuse box + LEDs
    c.fillStyle = '#1a0f0d'; rr(c, 240, 130, 90, 120, 5); c.fill(); c.strokeStyle = '#050202'; c.lineWidth = 3; c.stroke(); for (let i = 0; i < 5; i++) { c.fillStyle = i % 2 ? '#2a0c0c' : '#5b1411'; c.beginPath(); c.arc(262 + (i % 2) * 36, 154 + Math.floor(i / 2) * 36, 5, 0, TAU); c.fill(); }
    // cables
    c.strokeStyle = '#050202'; c.lineWidth = 5; for (const [x1, x2, sag] of [[330, 760, 70], [500, 980, 100], [150, 330, 50]]) { c.beginPath(); c.moveTo(x1, 94); c.quadraticCurveTo((x1 + x2) / 2, 94 + sag, x2, 100); c.stroke(); }
    // dark floor/ground fade behind table
    c.fillStyle = lg(c, 0, 340, 0, 420, [[0, 'rgba(0,0,0,0)'], [1, 'rgba(0,0,0,0.65)']]); c.fillRect(x0, 340, ww, 100);
    // hanging lamp (cord + shade). The light is drawn live.
    c.strokeStyle = '#050202'; c.lineWidth = 3; c.beginPath(); c.moveTo(640, y0); c.lineTo(640, 62); c.stroke();
    c.fillStyle = lg(c, 560, 0, 720, 0, [[0, '#2a0d0d'], [0.5, '#5a1a18'], [1, '#1a0707']]); c.beginPath(); c.moveTo(610, 64); c.lineTo(670, 64); c.lineTo(722, 118); c.lineTo(558, 118); c.closePath(); c.fill(); c.strokeStyle = '#050202'; c.lineWidth = 3; c.stroke();
    c.fillStyle = '#ffd9a0'; c.beginPath(); c.ellipse(640, 118, 58, 7, 0, 0, TAU); c.fill();
  };

  A.drawTable = function (c, W, H, ox, oy) {
    const r = rng(31), yFar = 392, x0 = -ox, y1 = H + oy;
    const lx = 150, rx = 1130; // far edge corners; near edge extends beyond the screen
    const vp = { x: 640, y: -900 };
    const proj = (x, y) => { const t = (y - yFar) / (y1 - yFar), xl = lx - (lx - (x0 - 200)) * t, xr = rx + ((W + ox + 200) - rx) * t; return [xl, xr]; };
    const [nl, nr] = proj(0, y1);
    c.save();
    c.beginPath(); c.moveTo(lx, yFar); c.lineTo(rx, yFar); c.lineTo(nr, y1); c.lineTo(nl, y1); c.closePath(); c.clip();
    c.fillStyle = lg(c, 0, yFar, 0, y1, [[0, '#3d2118'], [0.4, '#2e1912'], [1, '#1c0f0a']]); c.fillRect(x0 - 300, yFar - 10, W + ox * 2 + 600, y1 - yFar + 20);
    // planks converging toward the vanishing point
    c.strokeStyle = 'rgba(0,0,0,0.5)'; c.lineWidth = 2.5;
    for (let i = -9; i <= 9; i++) { const xf = 640 + i * 62; c.beginPath(); c.moveTo(xf, yFar); c.lineTo(640 + (xf - 640) * 3.2, y1); c.stroke(); c.strokeStyle = 'rgba(255,140,100,0.05)'; c.beginPath(); c.moveTo(xf + 3, yFar); c.lineTo(640 + (xf - 640) * 3.2 + 8, y1); c.stroke(); c.strokeStyle = 'rgba(0,0,0,0.5)'; }
    // grain, scratches, stains
    for (let i = 0; i < 260; i++) { const y = yFar + r() * (y1 - yFar), x = x0 + r() * (W + ox * 2), len = 30 + r() * 140; c.strokeStyle = 'rgba(' + (r() < 0.5 ? '10,4,2' : '200,140,110') + ',' + (0.04 + r() * 0.07) + ')'; c.lineWidth = 1; c.beginPath(); c.moveTo(x, y); c.lineTo(x + len, y + (r() - 0.5) * 4); c.stroke(); }
    for (let i = 0; i < 40; i++) { const x = r() * W, y = yFar + 20 + r() * 330; c.strokeStyle = 'rgba(230,190,160,' + (0.08 + r() * 0.12) + ')'; c.lineWidth = 1; c.beginPath(); c.moveTo(x, y); c.lineTo(x + (r() - 0.5) * 90, y + (r() - 0.5) * 50); c.stroke(); }
    for (let i = 0; i < 18; i++) { const x = r() * W, y = yFar + r() * 330, rad = 20 + r() * 60; c.fillStyle = rg(c, x, y, 0, rad, [[0, 'rgba(10,3,2,' + (0.25 + r() * 0.25) + ')'], [1, 'rgba(10,3,2,0)']]); c.beginPath(); c.arc(x, y, rad, 0, TAU); c.fill(); }
    // ring stains + burn marks
    for (const [x, y, rad] of [[960, 520, 24], [330, 470, 20], [1030, 450, 18]]) { c.strokeStyle = 'rgba(8,3,2,0.5)'; c.lineWidth = 3; c.beginPath(); c.ellipse(x, y, rad, rad * 0.45, 0, 0, TAU); c.stroke(); }
    c.fillStyle = 'rgba(0,0,0,0.5)'; c.beginPath(); c.ellipse(700, 470, 22, 8, 0.2, 0, TAU); c.fill();
    // chalk slot outlines (faint)
    c.strokeStyle = 'rgba(225,205,185,0.16)'; c.lineWidth = 2; c.setLineDash([9, 7]);
    for (let i = 0; i < 6; i++) { for (const who of ['p', 'd']) { const s = A.slot(who, i), w = who === 'p' ? 96 : 70, h = who === 'p' ? 92 : 56; rr(c, 640 + s.x - w / 2, s.y - h / 2, w, h, 7); c.stroke(); } }
    c.setLineDash([]);
    // centre mark
    c.strokeStyle = 'rgba(225,205,185,0.12)'; c.beginPath(); c.moveTo(450, 490); c.lineTo(830, 490); c.stroke();
    c.restore();
    // far edge highlight + lip
    c.strokeStyle = 'rgba(255,150,110,0.35)'; c.lineWidth = 3; c.beginPath(); c.moveTo(lx, yFar); c.lineTo(rx, yFar); c.stroke();
    c.strokeStyle = 'rgba(0,0,0,0.7)'; c.lineWidth = 6; c.beginPath(); c.moveTo(lx, yFar - 3); c.lineTo(rx, yFar - 3); c.stroke();
    // ashtray (right) — static prop
    c.fillStyle = lg(c, 0, 0, 0, 1, [[0, '#0b0606'], [1, '#0b0606']]); c.beginPath(); c.ellipse(1010, 482, 54, 19, 0, 0, TAU); c.fillStyle = '#2b2420'; c.fill(); c.strokeStyle = '#050202'; c.lineWidth = 2.5; c.stroke();
    c.fillStyle = '#17110f'; c.beginPath(); c.ellipse(1010, 481, 44, 14, 0, 0, TAU); c.fill();
    c.fillStyle = 'rgba(120,115,110,0.8)'; for (let i = 0; i < 7; i++) { c.beginPath(); c.ellipse(990 + r() * 40, 478 + r() * 8, 6, 2, r() * 3, 0, TAU); c.fill(); }
    c.fillStyle = '#e7dfd0'; for (const [x, y, a] of [[1020, 478, 0.3], [996, 484, -0.5]]) { c.save(); c.translate(x, y); c.rotate(a); c.fillRect(-7, -1.5, 14, 3); c.fillStyle = '#b8864a'; c.fillRect(4, -1.5, 3, 3); c.fillStyle = '#e7dfd0'; c.restore(); }
  };

  G.Art = A;
  if (typeof module !== 'undefined' && module.exports) module.exports = A;
})(typeof window !== 'undefined' ? window : globalThis);
