/* animation-controller.js — keyframe clip player / state machine for the player's hands, the Dealer and the weapon.
   Channels per actor: main (body/hands), face (face_* clips), voice (talk). Priorities, interruptibility,
   queueing, events, sfx events, speed, pause, completion promises, missing-clip fallbacks, ambient idle scheduler. */
(function (G) {
  'use strict';
  const U = G.U, AD = G.AnimData;
  const EASE = U.ease;
  const AN = { warned: {}, blocked: 0, started: 0, finished: 0 };

  function Actor(name, defaults) {
    this.name = name; this.defaults = defaults; this.p = Object.assign({}, defaults);
    this.ch = { main: null, face: null, voice: null };
    this.queue = []; this.paused = false; this.speed = 1; this.time = 0;
    this.onEvent = null; this.onSfx = null;
    this.ambient = { on: false, next: 0, token: 0, running: false };
    this.idleClip = null; this.idleTable = null;
  }
  const chanOf = (clip) => (clip.id.indexOf('face_') === 0 ? 'face' : clip.voice ? 'voice' : 'main');

  function buildTracks(clip, p) {
    const tracks = {};
    for (const k of clip.keys) for (const n in k.p) { (tracks[n] || (tracks[n] = [{ t: 0, v: p[n] === undefined ? 0 : p[n], e: 'lin' }])).push({ t: k.t, v: k.p[n], e: k.e || 'inout' }); }
    return tracks;
  }
  function evalTrack(tr, t) {
    if (t >= tr[tr.length - 1].t) return tr[tr.length - 1].v;
    for (let i = 1; i < tr.length; i++) {
      if (t <= tr[i].t) {
        const a = tr[i - 1], b = tr[i], span = b.t - a.t, u = span <= 1e-6 ? 1 : (t - a.t) / span;
        return a.v + (b.v - a.v) * (EASE[b.e] || EASE.inout)(U.clamp(u, 0, 1));
      }
    }
    return tr[tr.length - 1].v;
  }

  Actor.prototype.resolveClip = function (c) {
    if (typeof c === 'string') {
      const cl = AD.clips[c];
      if (!cl) { if (!AN.warned[c]) { AN.warned[c] = 1; console.warn('[anim] missing clip, using fallback:', c); } return null; }
      return cl;
    }
    return c;
  };

  /* play(clip, {force, queue, speed}) -> Promise<boolean> (true = completed, false = interrupted/blocked/missing) */
  Actor.prototype.play = function (clipOrId, o) {
    o = o || {};
    const clip = this.resolveClip(clipOrId);
    if (!clip || !clip.keys || !clip.keys.length) return Promise.resolve(false);
    const chn = chanOf(clip), cur = this.ch[chn];
    if (cur) {
      if (o.queue) return new Promise((res) => { this.queue.push({ clip, o, res }); });
      if (!o.force && !cur.clip.interruptible && cur.clip.pri >= clip.pri) { AN.blocked++; return Promise.resolve(false); } // never break an important action
      if (!o.force && cur.clip.interruptible === false && clip.pri < cur.clip.pri) { AN.blocked++; return Promise.resolve(false); }
      this._end(chn, false);
    }
    return new Promise((res) => {
      AN.started++;
      this.ch[chn] = { clip, t: 0, tracks: buildTracks(clip, this.p), res, speed: (o.speed || 1), fired: -1, firedS: -1, loops: 0, guard: 0 };
    });
  };
  Actor.prototype._end = function (chn, completed) {
    const c = this.ch[chn]; if (!c) return;
    this.ch[chn] = null; AN.finished++;
    if (c.res) c.res(completed);
    if (completed && chn === 'main' && this.queue.length) {
      const n = this.queue.shift(); this.play(n.clip, n.o).then(n.res);
    }
  };
  Actor.prototype.busy = function () { const m = this.ch.main; return !!(m && !m.clip.loop && !m.clip.interruptible); };
  Actor.prototype.playing = function () { const m = this.ch.main; return m ? m.clip.id : null; };
  Actor.prototype.stop = function (chn) { this._end(chn || 'main', false); };
  Actor.prototype.reset = function (keepAmbient) {
    for (const k of ['main', 'face', 'voice']) { const c = this.ch[k]; this.ch[k] = null; if (c && c.res) c.res(false); }
    this.queue.length = 0;
    this.p = Object.assign({}, this.defaults);
    this.ambient.token++; this.ambient.running = false; if (this.ambient.hold) { const h = this.ambient.hold; this.ambient.hold = null; h.res(); }
    if (!keepAmbient) this.ambient.on = false;
  };
  Actor.prototype.setIdle = function (clipId) { this.idleClip = clipId; };

  Actor.prototype.update = function (dtRaw) {
    if (this.paused) return;
    const dt = Math.min(dtRaw, 0.1) * this.speed; this.time += dt;
    for (const chn of ['main', 'face', 'voice']) {
      const c = this.ch[chn]; if (!c) continue;
      const clip = c.clip, prev = c.t; c.t += dt * c.speed;
      for (let i = 0; i < clip.events.length; i++) { const e = clip.events[i]; if (e.t > prev - 1e-9 && e.t <= Math.min(c.t, clip.dur) && !(e.t === prev && c.loops === 0 && prev !== 0 && false)) { if (this.onEvent && e.t >= prev) this.onEvent(this.name, e.name, clip); } }
      for (let i = 0; i < clip.sfx.length; i++) { const s = clip.sfx[i]; if (s.t >= prev && s.t < Math.min(c.t, clip.dur + 1e-6)) { if (this.onSfx) this.onSfx(this.name, s.name, s.vol, clip); } }
      const tt = Math.min(c.t, clip.dur);
      for (const n in c.tracks) this.p[n] = evalTrack(c.tracks[n], tt);
      if (c.t >= clip.dur) {
        if (clip.loop) { c.t -= clip.dur; c.loops++; c.tracks = buildTracks(clip, this.p); if (++c.guard > 100000) this._end(chn, true); }
        else this._end(chn, true);
      }
    }
    const h = this.ambient.hold;
    if (h) { if (this.ambient.token !== h.tok || this.time >= h.until) { this.ambient.hold = null; h.res(); } }
    /* ambient idle: when nothing else drives the main channel, keep the actor alive */
    if (!this.ch.main && !this.queue.length && this.idleClip) this.play(this.idleClip);
    if (this.ambient.on && this.idleTable && !this.ambient.running && (!this.ch.main || this.ch.main.clip.loop)) {
      this.ambient.next -= dt;
      if (this.ambient.next <= 0) this._runAmbient();
    }
  };

  Actor.prototype._runAmbient = function () {
    const amb = this.ambient, tok = ++amb.token; amb.running = true;
    const e = this.idleTable(this); // {seq:[[clip, holdSeconds]], gap:[min,max]}
    if (!e) { amb.running = false; amb.next = 3; return; }
    const self = this;
    (async function () {
      for (const step of e.seq) {
        if (amb.token !== tok || !amb.on) break;
        const ok = await self.play(step[0]);
        if (!ok || amb.token !== tok) break;
        if (step[1]) { // hold the pose for game-time seconds (pauses with the game; aborts if superseded)
          await new Promise((res) => { amb.hold = { until: self.time + step[1], res, tok }; });
          if (amb.token !== tok) break;
        }
      }
      if (amb.token === tok) { amb.running = false; amb.next = e.gap[0] + Math.random() * (e.gap[1] - e.gap[0]); }
    })();
  };

  /* ---------- ambient tables ---------- */
  function playerIdle(a) {
    const r = Math.random(), tn = AN.tension || 0;
    if (r < 0.28) return { seq: [['hand_fingers', 0]], gap: [2.5, 6] };
    if (r < 0.5) return { seq: [['hand_tap', 0]], gap: [3, 7] };
    if (r < 0.72) return { seq: [['hand_breathe', 0]], gap: [3, 6] };
    if (r < 0.86 && !AN.reduced) return { seq: [['hand_look_table', 0]], gap: [5, 10] };
    return { seq: [[tn > 0.5 ? 'hand_tremble' : 'hand_fingers', 0]], gap: [3, 6] };
  }
  function dealerIdle(a) {
    const r = Math.random(), calm = AN.reduced;
    const faces = ['face_stare', 'face_smile', 'face_suspicion', 'face_confusion', 'face_amusement', 'face_neutral'];
    if (r < 0.17) return { seq: [['d_shoulder', 0]], gap: [1.5, 4] };
    if (r < 0.32) return { seq: [['d_tilt', 0]], gap: [2, 5] };
    if (r < 0.42) return { seq: [['d_look_table', 1.6], ['d_look_player', 0]], gap: [2, 5] };
    if (r < 0.5) return { seq: [['d_tap', 2.2]], gap: [3, 6] };
    if (r < 0.58) return { seq: [['d_rest_hands', 0]], gap: [2, 4] };
    if (r < 0.66) return { seq: [['face_' + faces[Math.floor(Math.random() * faces.length)].slice(5), 2.4], ['face_neutral', 0]], gap: [2, 5] };
    if (r < 0.74) return { seq: [['d_lean_fwd', 3.0], ['d_lean_back', 0.2]], gap: [4, 9] };
    if (r < 0.8) return { seq: [['d_lean_back', 2.4], ['d_idle', 0]], gap: [4, 9] };
    if (r < 0.86) return { seq: [['d_still', 0]], gap: [2, 4] };
    if (calm) return { seq: [['d_breathe', 0]], gap: [2, 5] };
    if (r < 0.9) return { seq: [['d_twitch', 0]], gap: [5, 12] };
    if (r < 0.93) return { seq: [['d_sudden_head', 0]], gap: [8, 16] };
    if (r < 0.95) return { seq: [['d_long_stare', 0]], gap: [8, 16] };
    if (r < 0.97) return { seq: [['d_rare_idle', 0]], gap: [12, 24] };
    if (r < 0.985) return { seq: [['d_glitch', 0]], gap: [14, 28] };
    return { seq: [['d_unexpected_laugh', 0]], gap: [16, 34] };
  }

  AN.actors = {};
  AN.init = function () {
    const D = AD.defaults;
    AN.player = AN.actors.player = new Actor('player', D.player);
    AN.dealer = AN.actors.dealer = new Actor('dealer', D.dealer);
    AN.gun = AN.actors.gun = new Actor('gun', D.gun);
    AN.player.setIdle('hand_idle'); AN.dealer.setIdle('d_idle'); AN.gun.setIdle('gun_table_idle');
    AN.player.idleTable = playerIdle; AN.dealer.idleTable = dealerIdle;
    AN.player.ambient.next = 3; AN.dealer.ambient.next = 2;
    for (const k in AN.actors) { AN.actors[k].onEvent = (n, e, c) => AN.onEvent && AN.onEvent(n, e, c); AN.actors[k].onSfx = (n, s, v, c) => AN.onSfx && AN.onSfx(n, s, v, c); }
    AN.gun.play('gun_table_idle');
  };
  AN.update = function (dt) { for (const k in AN.actors) AN.actors[k].update(dt); };
  AN.setPaused = function (p) { for (const k in AN.actors) AN.actors[k].paused = p; };
  AN.resetAll = function () { for (const k in AN.actors) AN.actors[k].reset(); AN.gun.play('gun_table_idle'); AN.player.ambient.on = true; AN.dealer.ambient.on = true; };
  AN.setSpeed = function (s) { for (const k in AN.actors) AN.actors[k].speed = s; };

  G.Anim = AN;
  if (typeof module !== 'undefined' && module.exports) module.exports = AN;
})(typeof window !== 'undefined' ? window : globalThis);
