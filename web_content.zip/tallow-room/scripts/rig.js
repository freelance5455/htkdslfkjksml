/* rig.js — model decoding + a real skeleton for the skinned character: forward kinematics, skin matrices and two-bone IK.
   The skeleton itself (joint positions + hierarchy) and the per-vertex weights are authored by tools/build-models.js and shipped in
   data/models.js (the supplied GLB has no armature). Everything here works in the character's own model space; the draw call's model
   matrix places/scales it in the world. */
(function (G) {
  'use strict';
  const Rg = {};
  /* ---------------- base64 -> typed arrays ---------------- */
  function bytes(b64) {
    if (typeof atob === 'function') { const s = atob(b64), u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }
    return new Uint8Array(Buffer.from(b64, 'base64'));
  }
  Rg.decode = function (m) {
    const p = bytes(m.p), f = new Float32Array(p.buffer, p.byteOffset, p.byteLength / 4), n = bytes(m.n), c = bytes(m.c), ix = bytes(m.i);
    const geo = { p: f, n: Float32Array.from(new Int8Array(n.buffer, n.byteOffset, n.byteLength), (v) => v / 127), c: Float32Array.from(c, (v) => v / 255), i: new Uint16Array(ix.buffer.slice(ix.byteOffset, ix.byteOffset + ix.byteLength)), groups: m.groups };
    if (m.j) { geo.j = bytes(m.j); geo.w = bytes(m.w); }
    return geo;
  };
  /* ---------------- quaternions [x,y,z,w] ---------------- */
  const Q = Rg.Q = {
    id: () => [0, 0, 0, 1],
    mul(a, b) { return [a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1], a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0], a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3], a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2]]; },
    inv(a) { return [-a[0], -a[1], -a[2], a[3]]; },
    axis(x, y, z, ang) { const s = Math.sin(ang / 2), l = Math.hypot(x, y, z) || 1; return [x / l * s, y / l * s, z / l * s, Math.cos(ang / 2)]; },
    rot(q, v) { const x = q[0], y = q[1], z = q[2], w = q[3]; const tx = 2 * (y * v[2] - z * v[1]), ty = 2 * (z * v[0] - x * v[2]), tz = 2 * (x * v[1] - y * v[0]); return [v[0] + w * tx + (y * tz - z * ty), v[1] + w * ty + (z * tx - x * tz), v[2] + w * tz + (x * ty - y * tx)]; },
    fromTo(a, b) { // shortest rotation taking unit a to unit b
      const d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
      if (d > 0.999999) return [0, 0, 0, 1];
      if (d < -0.999999) { let ax = Math.abs(a[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0]; const c = [a[1] * ax[2] - a[2] * ax[1], a[2] * ax[0] - a[0] * ax[2], a[0] * ax[1] - a[1] * ax[0]]; return Q.axis(c[0], c[1], c[2], Math.PI); }
      const c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; const q = [c[0], c[1], c[2], 1 + d]; const l = Math.hypot(q[0], q[1], q[2], q[3]); return [q[0] / l, q[1] / l, q[2] / l, q[3] / l];
    },
    fromBasis(ex, ey, ez) { // rotation matrix with columns ex,ey,ez -> quaternion
      const m00 = ex[0], m10 = ex[1], m20 = ex[2], m01 = ey[0], m11 = ey[1], m21 = ey[2], m02 = ez[0], m12 = ez[1], m22 = ez[2], tr = m00 + m11 + m22; let x, y, z, w;
      if (tr > 0) { const s = Math.sqrt(tr + 1) * 2; w = s / 4; x = (m21 - m12) / s; y = (m02 - m20) / s; z = (m10 - m01) / s; }
      else if (m00 > m11 && m00 > m22) { const s = Math.sqrt(1 + m00 - m11 - m22) * 2; w = (m21 - m12) / s; x = s / 4; y = (m01 + m10) / s; z = (m02 + m20) / s; }
      else if (m11 > m22) { const s = Math.sqrt(1 + m11 - m00 - m22) * 2; w = (m02 - m20) / s; x = (m01 + m10) / s; y = s / 4; z = (m12 + m21) / s; }
      else { const s = Math.sqrt(1 + m22 - m00 - m11) * 2; w = (m10 - m01) / s; x = (m02 + m20) / s; y = (m12 + m21) / s; z = s / 4; }
      const l = Math.hypot(x, y, z, w); return [x / l, y / l, z / l, w / l];
    },
    slerp(a, b, t) { let d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]; let bb = b; if (d < 0) { d = -d; bb = [-b[0], -b[1], -b[2], -b[3]]; } if (d > 0.9995) { const r = [a[0] + (bb[0] - a[0]) * t, a[1] + (bb[1] - a[1]) * t, a[2] + (bb[2] - a[2]) * t, a[3] + (bb[3] - a[3]) * t]; const l = Math.hypot(...r); return r.map((v) => v / l); } const th = Math.acos(d), s = Math.sin(th), w1 = Math.sin((1 - t) * th) / s, w2 = Math.sin(t * th) / s; return [a[0] * w1 + bb[0] * w2, a[1] * w1 + bb[1] * w2, a[2] * w1 + bb[2] * w2, a[3] * w1 + bb[3] * w2]; },
    mat3(q) { const [x, y, z, w] = q; return [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]; } // row-major
  };
  const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]], add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]], mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
  const len = (a) => Math.hypot(a[0], a[1], a[2]), nrm = (a) => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }, dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  Rg.v = { sub, add, mul, len, nrm, dot, cross };

  /* ---------------- skeleton ---------------- */
  function Rig(def, maxJoints) {
    this.n = def.bones.length; if (this.n > maxJoints) throw new Error('rig has more joints than the shader supports');
    this.names = def.bones.map((b) => b.n); this.idx = {}; this.names.forEach((n, i) => { this.idx[n] = i; });
    this.par = def.bones.map((b) => b.p); this.rest = def.bones.map((b) => b.t.slice());
    this.loc = this.rest.map((r, i) => (this.par[i] < 0 ? r.slice() : sub(r, this.rest[this.par[i]])));   // rest offset to the parent joint
    this.q = this.names.map(() => [0, 0, 0, 1]);                       // local rotations (identity = rest pose)
    this.rootT = [0, 0, 0]; this.Wq = this.q.map(() => [0, 0, 0, 1]); this.Wp = this.rest.map((r) => r.slice());
    this.maxJoints = maxJoints; this.out = new Float32Array(maxJoints * 12);
    this.len = {}; for (const s of ['L', 'R']) { this.len['arm_' + s] = [len(sub(this.rest[this.idx['forearm_' + s]], this.rest[this.idx['upperarm_' + s]])), len(sub(this.rest[this.idx['hand_' + s]], this.rest[this.idx['forearm_' + s]]))]; }
  }
  Rig.prototype.reset = function () { for (let i = 0; i < this.n; i++) this.q[i] = [0, 0, 0, 1]; this.rootT = [0, 0, 0]; };
  Rig.prototype.set = function (name, q) { this.q[this.idx[name]] = q; };
  Rig.prototype.fk = function () {
    for (let i = 0; i < this.n; i++) {
      const p = this.par[i];
      if (p < 0) { this.Wq[i] = this.q[i].slice(); this.Wp[i] = add(this.rest[i], this.rootT); }
      else { this.Wq[i] = Q.mul(this.Wq[p], this.q[i]); this.Wp[i] = add(this.Wp[p], Q.rot(this.Wq[p], this.loc[i])); }
    }
  };
  Rig.prototype.pos = function (name) { return this.Wp[this.idx[name]]; };
  /* two-bone IK for an arm (model space). target = wrist world position, pole = a point the elbow should lean towards.
     Returns {reached, stretch} and leaves local rotations of upperarm + forearm set. Call fk() first (trunk must be posed). */
  Rig.prototype.ikArm = function (side, target, pole) {
    const iu = this.idx['upperarm_' + side], iff = this.idx['forearm_' + side], ih = this.idx['hand_' + side], pc = this.par[iu];
    const [L1, L2] = this.len['arm_' + side]; const S = add(this.Wp[pc], Q.rot(this.Wq[pc], this.loc[iu]));
    let d = sub(target, S), dist = len(d); const reach = L1 + L2 - 0.002, minR = Math.abs(L1 - L2) + 0.02; const ok = dist <= reach && dist >= minR;
    const dn = nrm(d); dist = Math.min(reach, Math.max(minR, dist));
    const cosA = (L1 * L1 + dist * dist - L2 * L2) / (2 * L1 * dist), ang = Math.acos(Math.max(-1, Math.min(1, cosA)));
    let h = sub(pole, S); h = sub(h, mul(dn, dot(h, dn))); h = nrm(h);                        // pole direction perpendicular to the S->T line
    const E = add(S, add(mul(dn, L1 * Math.cos(ang)), mul(h, L1 * Math.sin(ang))));
    const W = add(S, mul(dn, dist));
    // upper arm: rotate its rest direction (as carried by the already-posed parent) onto S->E
    const d1 = this.loc[iff], dir1 = Q.rot(this.Wq[pc], d1), Rw1 = Q.mul(Q.fromTo(nrm(dir1), nrm(sub(E, S))), this.Wq[pc]);
    this.q[iu] = Q.mul(Q.inv(this.Wq[pc]), Rw1); this.Wq[iu] = Rw1; this.Wp[iu] = S;
    const d2 = this.loc[ih], dir2 = Q.rot(Rw1, d2), Rw2 = Q.mul(Q.fromTo(nrm(dir2), nrm(sub(W, E))), Rw1);
    this.q[iff] = Q.mul(Q.inv(Rw1), Rw2); this.Wq[iff] = Rw2; this.Wp[iff] = E;
    return { reached: ok, elbow: E, wrist: W, shoulder: S };
  };
  /* sets a hand's world orientation (after ikArm) */
  Rig.prototype.handWorld = function (side, qw) { const ih = this.idx['hand_' + side], iff = this.idx['forearm_' + side]; this.q[ih] = Q.mul(Q.inv(this.Wq[iff]), qw); };
  /* finger curl: curl (4 fingers), index (finger0), thumb in 0..1 */
  Rig.prototype.fingers = function (side, curl, index, thumb) {
    for (let f = 0; f < 4; f++) { const c = (f === 0 ? index : curl); this.q[this.idx[`finger${f}_${side}`]] = Q.axis(1, 0, 0, 0.12 + c * 1.45 + (f === 3 ? 0.08 : 0)); }
    const sg = side === 'L' ? 1 : -1; this.q[this.idx['thumb_' + side]] = Q.mul(Q.axis(0, 1, 0, sg * -thumb * 0.7), Q.axis(1, 0, 0, 0.08 + thumb * 0.55));
  };
  /* joint matrices for the skinning shader: 3 rows (vec4) per joint = world * inverseBind */
  Rig.prototype.skin = function () {
    const o = this.out;
    for (let i = 0; i < this.n; i++) { const R = Q.mat3(this.Wq[i]), r = this.rest[i], p = this.Wp[i];
      for (let k = 0; k < 3; k++) { const b = i * 12 + k * 4; o[b] = R[k * 3]; o[b + 1] = R[k * 3 + 1]; o[b + 2] = R[k * 3 + 2]; o[b + 3] = p[k] - (R[k * 3] * r[0] + R[k * 3 + 1] * r[1] + R[k * 3 + 2] * r[2]); } }
    return new Float32Array(o);   // GL.draw keeps the reference until the frame ends
  };
  Rg.Rig = Rig;
  G.Rg = Rg;
  if (typeof module !== 'undefined' && module.exports) module.exports = Rg;
})(typeof window !== 'undefined' ? window : globalThis);
