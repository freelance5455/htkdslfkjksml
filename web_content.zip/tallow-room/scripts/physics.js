/* physics.js — lightweight table physics for loose objects (shells, coin, crushed can, cigarette butt, pills).
   Pseudo-3D: (x, y) lie on the table plane, z is height. Gravity, bouncing, friction, settling, table-edge
   collision, circle-circle separation, optional "falls off the table". Authoritative gameplay never reads this. */
(function (G) {
  'use strict';
  const U = G.U;
  const P = { bodies: [], GRAV: 2200, bounds: { x0: -430, x1: 430, y0: 405, y1: 700 }, onBounce: null, onSettle: null, maxBodies: 48 };
  const KIND = { // radius, restitution, friction(1/s), spin damping
    shell_e: { r: 9, rest: 0.42, fr: 4.5, mass: 1.2, w: 'shell_drop' }, shell_a: { r: 9, rest: 0.42, fr: 4.5, mass: 1.2, w: 'shell_drop' },
    coin: { r: 10, rest: 0.55, fr: 2.2, mass: 0.6, w: 'bounce_small' }, can: { r: 15, rest: 0.3, fr: 3.5, mass: 1.5, w: 'bounce_small', fall: true },
    butt: { r: 6, rest: 0.2, fr: 6, mass: 0.2, w: null }, pill: { r: 4, rest: 0.6, fr: 3, mass: 0.1, w: 'bounce_small' }, bottle: { r: 14, rest: 0.25, fr: 3, mass: 1.4, w: 'bounce_small', fall: true },
    cell: { r: 10, rest: 0.3, fr: 4, mass: 0.9, w: 'bounce_small' }
  };
  P.kinds = KIND;

  P.spawn = function (kind, x, y, z, vx, vy, vz, rot, vr, extra) {
    if (P.bodies.length >= P.maxBodies) P.bodies.shift();
    const k = KIND[kind] || KIND.pill;
    const b = Object.assign({ kind, x, y, z: z || 0, vx: vx || 0, vy: vy || 0, vz: vz || 0, rot: rot || 0, vr: vr || 0, r: k.r, age: 0, settled: false, fade: 1, life: 0, bounces: 0 }, extra || {});
    P.bodies.push(b); return b;
  };
  P.clear = function () { P.bodies.length = 0; };
  /* fixed-timestep simulation (120 Hz) with render interpolation. Every fixed step is split into sub-steps so that no body moves more
     than half its radius per sub-step (continuous collision for the table edges and for body-body contact: no tunnelling). */
  const FIXED = 1 / 120; let acc = 0;
  P.alpha = 1; P.stats = { steps: 0, substeps: 0, maxSub: 0 };
  P.clampFn = null;     // optional (b, kind) => true when it moved the body: world-space table-top limits supplied by the 3D stage
  P.step = function (dt) {
    dt = Math.min(dt, 0.1); acc += dt; let n = 0;
    while (acc >= FIXED && n < 12) { for (const b of P.bodies) { b.px = b.x; b.py = b.y; b.pz = b.z; b.prot = b.rot; } fixed(FIXED); acc -= FIXED; n++; P.stats.steps++; }
    if (acc > FIXED * 12) acc = 0;
    P.alpha = acc / FIXED;
  };
  P.lerped = function (b) { const a = b.px === undefined ? 1 : P.alpha; return { x: b.px === undefined ? b.x : b.px + (b.x - b.px) * a, y: b.py === undefined ? b.y : b.py + (b.y - b.py) * a, z: b.pz === undefined ? b.z : b.pz + (b.z - b.pz) * a, rot: b.prot === undefined ? b.rot : b.prot + (b.rot - b.prot) * a }; };
  function fixed(dt0) {
    const list = P.bodies; let fastest = 0;
    for (const b of list) if (!b.settled && !b.off) fastest = Math.max(fastest, Math.hypot(b.vx, b.vy), Math.abs(b.vz));
    let minR = 99; for (const b of list) minR = Math.min(minR, b.r);
    const sub = Math.max(1, Math.min(8, Math.ceil(fastest * dt0 / Math.max(2, minR * 0.5)))); P.stats.substeps += sub; P.stats.maxSub = Math.max(P.stats.maxSub, sub);
    for (let q = 0; q < sub; q++) sstep(dt0 / sub);
  }
  function sstep(dt) {
    const B = P.bounds, list = P.bodies;
    for (let i = list.length - 1; i >= 0; i--) {
      const b = list[i], k = KIND[b.kind] || KIND.pill;
      b.age += dt;
      if (b.dying) { b.fade -= dt * 1.5; if (b.fade <= 0) { list.splice(i, 1); continue; } }
      if (b.settled) continue;
      b.vz -= P.GRAV * dt; b.z += b.vz * dt;
      if (b.z <= 0 && !b.off) {
        b.z = 0;
        if (Math.abs(b.vz) > 90) { b.vz = -b.vz * k.rest; b.bounces++; b.vx *= 0.85; b.vy *= 0.85; b.vr *= 0.8; if (P.onBounce && k.w && b.bounces <= 2) P.onBounce(b, k.w, Math.min(1, Math.abs(b.vz) / 500)); }
        else b.vz = 0;
      }
      b.x += b.vx * dt; b.y += b.vy * dt; b.rot += b.vr * dt;
      if (b.z <= 0 && !b.off) { const f = Math.exp(-k.fr * dt); b.vx *= f; b.vy *= f; b.vr *= Math.exp(-3 * dt); }
      if (!b.off) { // table edges
        if (b.x < B.x0) { if (k.fall && b.x < B.x0 - 30) b.off = true; else { b.x = B.x0; b.vx = Math.abs(b.vx) * 0.45; } }
        if (b.x > B.x1) { if (k.fall && b.x > B.x1 + 30) b.off = true; else { b.x = B.x1; b.vx = -Math.abs(b.vx) * 0.45; } }
        if (b.y < B.y0) { b.y = B.y0; b.vy = Math.abs(b.vy) * 0.45; }
        if (b.y > B.y1) { if (k.fall && b.y > B.y1 + 20) b.off = true; else { b.y = B.y1; b.vy = -Math.abs(b.vy) * 0.45; } }
        if (!b.off && P.clampFn) P.clampFn(b, k);
      } else { if (b.z < -600) { list.splice(i, 1); continue; } }
      if (!b.off && b.z <= 0 && b.vx * b.vx + b.vy * b.vy < 36 && Math.abs(b.vr) < 0.5) { b.settled = true; b.vx = b.vy = b.vr = 0; if (P.onSettle) P.onSettle(b); }
    }
    for (let i = 0; i < list.length; i++) { // separation + momentum exchange weighted by mass (table plane only)
      const a = list[i]; if (a.off) continue;
      for (let j = i + 1; j < list.length; j++) {
        const c = list[j]; if (c.off || Math.abs(a.z - c.z) > 14) continue;
        const dx = c.x - a.x, dy = c.y - a.y, rr = a.r + c.r, d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ov = rr - d, ma = (KIND[a.kind] || KIND.pill).mass || 1, mc = (KIND[c.kind] || KIND.pill).mass || 1, wa = a.settled ? 0 : mc / (ma + mc), wc = c.settled ? 0 : ma / (ma + mc), ws = (wa + wc) || 1;
          a.x -= nx * ov * wa / ws; a.y -= ny * ov * wa / ws; c.x += nx * ov * wc / ws; c.y += ny * ov * wc / ws;
          const va = a.vx * nx + a.vy * ny, vc = c.vx * nx + c.vy * ny, diff = va - vc;
          if (diff > 0) { const J = diff * 0.6 * (2 * ma * mc / (ma + mc)); a.vx -= J / ma * nx; a.vy -= J / ma * ny; c.vx += J / mc * nx; c.vy += J / mc * ny; a.settled = c.settled = false; }
        }
      }
    }
  }
  P.fadeAll = function () { for (const b of P.bodies) b.dying = true; };
  G.Physics = P;
  if (typeof module !== 'undefined' && module.exports) module.exports = P;
})(typeof window !== 'undefined' ? window : globalThis);
