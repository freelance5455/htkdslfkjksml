/* physics.js — lightweight table physics for loose objects (shells, coin, crushed can, cigarette butt, pills).
   Pseudo-3D: (x, y) lie on the table plane, z is height. Gravity, bouncing, friction, settling, table-edge
   collision, circle-circle separation, optional "falls off the table". Authoritative gameplay never reads this. */
(function (G) {
  'use strict';
  const U = G.U;
  const P = { bodies: [], GRAV: 2200, bounds: { x0: -430, x1: 430, y0: 405, y1: 700 }, onBounce: null, onSettle: null, maxBodies: 48 };
  const KIND = { // radius, restitution, friction(1/s), spin damping
    shell_e: { r: 9, rest: 0.42, fr: 4.5, w: 'shell_drop' }, shell_a: { r: 9, rest: 0.42, fr: 4.5, w: 'shell_drop' },
    coin: { r: 10, rest: 0.55, fr: 2.2, w: 'bounce_small' }, can: { r: 15, rest: 0.3, fr: 3.5, w: 'bounce_small', fall: true },
    butt: { r: 6, rest: 0.2, fr: 6, w: null }, pill: { r: 4, rest: 0.6, fr: 3, w: 'bounce_small' }, bottle: { r: 14, rest: 0.25, fr: 3, w: 'bounce_small', fall: true },
    cell: { r: 10, rest: 0.3, fr: 4, w: 'bounce_small' }
  };
  P.kinds = KIND;

  P.spawn = function (kind, x, y, z, vx, vy, vz, rot, vr, extra) {
    if (P.bodies.length >= P.maxBodies) P.bodies.shift();
    const k = KIND[kind] || KIND.pill;
    const b = Object.assign({ kind, x, y, z: z || 0, vx: vx || 0, vy: vy || 0, vz: vz || 0, rot: rot || 0, vr: vr || 0, r: k.r, age: 0, settled: false, fade: 1, life: 0, bounces: 0 }, extra || {});
    P.bodies.push(b); return b;
  };
  P.clear = function () { P.bodies.length = 0; };
  P.step = function (dt) {
    dt = Math.min(dt, 0.033);
    const B = P.bounds, list = P.bodies;
    for (let i = list.length - 1; i >= 0; i--) {
      const b = list[i], k = KIND[b.kind] || KIND.pill;
      b.age += dt;
      if (b.dying) { b.fade -= dt * 1.5; if (b.fade <= 0) { list.splice(i, 1); continue; } }
      if (b.settled) continue;
      b.vz -= P.GRAV * dt; b.z += b.vz * dt;
      if (b.z <= 0 && !b.off) {
        b.z = 0;
        if (Math.abs(b.vz) > 90) { b.vz = -b.vz * k.rest; b.bounces++; b.vx *= 0.85; b.vy *= 0.85; b.vr *= 0.8; if (P.onBounce && k.w && b.bounces <= 2) P.onBounce(b, k.w, Math.min(1, Math.abs(b.vz) / 500)); }
        else b.vz = 0;
      }
      b.x += b.vx * dt; b.y += b.vy * dt; b.rot += b.vr * dt;
      if (b.z <= 0 && !b.off) { const f = Math.exp(-k.fr * dt); b.vx *= f; b.vy *= f; b.vr *= Math.exp(-3 * dt); }
      if (!b.off) { // table edges
        if (b.x < B.x0) { if (k.fall && b.x < B.x0 - 30) b.off = true; else { b.x = B.x0; b.vx = Math.abs(b.vx) * 0.45; } }
        if (b.x > B.x1) { if (k.fall && b.x > B.x1 + 30) b.off = true; else { b.x = B.x1; b.vx = -Math.abs(b.vx) * 0.45; } }
        if (b.y < B.y0) { b.y = B.y0; b.vy = Math.abs(b.vy) * 0.45; }
        if (b.y > B.y1) { if (k.fall && b.y > B.y1 + 20) b.off = true; else { b.y = B.y1; b.vy = -Math.abs(b.vy) * 0.45; } }
      } else { if (b.z < -600) { list.splice(i, 1); continue; } }
      if (!b.off && b.z <= 0 && b.vx * b.vx + b.vy * b.vy < 36 && Math.abs(b.vr) < 0.5) { b.settled = true; b.vx = b.vy = b.vr = 0; if (P.onSettle) P.onSettle(b); }
    }
    for (let i = 0; i < list.length; i++) { // separation + simple momentum exchange (table plane only)
      const a = list[i]; if (a.off) continue;
      for (let j = i + 1; j < list.length; j++) {
        const c = list[j]; if (c.off || Math.abs(a.z - c.z) > 14) continue;
        const dx = c.x - a.x, dy = c.y - a.y, rr = a.r + c.r, d2 = dx * dx + dy * dy;
        if (d2 < rr * rr && d2 > 0.01) {
          const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ov = rr - d;
          a.x -= nx * ov * 0.5; a.y -= ny * ov * 0.5; c.x += nx * ov * 0.5; c.y += ny * ov * 0.5;
          const va = a.vx * nx + a.vy * ny, vc = c.vx * nx + c.vy * ny, diff = va - vc;
          if (diff > 0) { a.vx -= diff * nx * 0.6; a.vy -= diff * ny * 0.6; c.vx += diff * nx * 0.6; c.vy += diff * ny * 0.6; a.settled = c.settled = false; }
        }
      }
    }
  };
  P.fadeAll = function () { for (const b of P.bodies) b.dying = true; };
  G.Physics = P;
  if (typeof module !== 'undefined' && module.exports) module.exports = P;
})(typeof window !== 'undefined' ? window : globalThis);
