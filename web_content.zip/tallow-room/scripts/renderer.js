/* renderer.js — frame composition on a single 2D canvas. Reads animation rigs (Anim.*.p), the Scene object
   (items on the table, who holds what, effects) and physics bodies. No gameplay logic lives here. */
(function (G) {
  'use strict';
  const U = G.U, Art = G.Art, TAU = Math.PI * 2, sin = Math.sin, cos = Math.cos;
  const R = {
    W: 1280, H: 720, CX: 640, t: 0, q: 'medium', effects: true, reduced: false, shakeScale: 1, fps: 60,
    view: { pw: 1280, ph: 720, fs: 1, ox: 0, oy: 0, pr: 1, cw: 1280, ch: 720 },
    shakeAmp: 0, punch: 0, flickerT: 0, nextFlicker: 6, lamp: 1, stats: { frames: 0, drawMs: 0 }
  };

  const Scene = R.scene = {
    mode: 'menu', gunHolder: 'table', held: { p: null, d: null }, items: { p: [], d: [] }, cuffs: { p: false, d: false },
    selected: null, lens: null, charge: 0, flash: 0, flashCol: '255,200,150', hurt: 0, fade: 0, redWash: 0, blackout: 0, doorLight: 0,
    lampBase: 1, lowPulse: 0, camX: 0, zoom: 1, flashObj: null, dread: 0, dealerFlameBoost: 0, tvGlitch: 0
  };

  /* ---------------------------------------------------------------- setup */
  let cv, glc, c, bg, tbl, vig, hurtG, pGrain, pScan, margin = 0;
  const parts = []; const MAXP = 260;
  for (let i = 0; i < MAXP; i++) parts.push({ a: false });
  const dust = [];
  R.init = function (canvas) {
    cv = canvas; c = cv.getContext('2d', { alpha: true });
    glc = document.getElementById('gl3d'); R.use3d = !!(glc && G.Stage3D && G.Stage3D.init(glc, R)); R.gl3dOk = R.use3d;
    Art.buildSprites();
    for (let i = 0; i < 50; i++) dust.push({ x: 380 + Math.random() * 520, y: 120 + Math.random() * 520, vx: (Math.random() - 0.5) * 6, vy: -2 - Math.random() * 6, s: 0.6 + Math.random() * 1.6, p: Math.random() * 7 });
    R.resize();
  };
  R.applySettings = function (s) {
    R.q = s.quality; R.res = s.res || 1; R.sens = s.sens === undefined ? 1 : s.sens; R.want3d = s.three !== false; R.use3d = !!(R.gl3dOk && R.want3d); if (glc) glc.style.display = R.use3d ? 'block' : 'none'; if (R.gl3dOk) G.Stage3D.setQuality(R.q); R.effects = s.effects; R.reduced = s.reduced; R.shakeScale = s.reduced ? 0 : s.shake; R.fps = s.fps;
    R.resize();
  };
  R.resize = function () {
    if (!cv) return;
    const cw = Math.max(1, cv.clientWidth || G.innerWidth), ch = Math.max(1, cv.clientHeight || G.innerHeight);
    const qf = (R.q === 'low' ? 0.55 : R.q === 'medium' ? 0.8 : 1) * (R.res || 1), dpr = Math.min(G.devicePixelRatio || 1, 2);
    let pr = qf * dpr; const cap = R.q === 'low' ? 0.6e6 : R.q === 'medium' ? 1.2e6 : 2.0e6; pr *= R.auto || 1;
    if (cw * ch * pr * pr > cap) pr = Math.sqrt(cap / (cw * ch));
    pr = Math.max(0.35, pr);
    const pw = Math.round(cw * pr), ph = Math.round(ch * pr);
    if (cv.width !== pw || cv.height !== ph) { cv.width = pw; cv.height = ph; }
    if (glc && R.gl3dOk && (glc.width !== pw || glc.height !== ph)) { glc.width = pw; glc.height = ph; }
    const fs = Math.min(pw / R.W, ph / R.H), ox = (pw - R.W * fs) / 2, oy = (ph - R.H * fs) / 2;
    Object.assign(R.view, { pw, ph, fs, ox, oy, pr, cw, ch });
    margin = Math.ceil(190 * fs);
    buildCaches();
  };
  function layer(w, h) { const k = document.createElement('canvas'); k.width = w; k.height = h; return k; }
  function buildCaches() {
    const v = R.view, mw = v.pw + margin * 2, mh = v.ph + margin * 2;
    const logicalOverX = (mw / v.fs - R.W) / 2 + 2, logicalOverY = (mh / v.fs - R.H) / 2 + 2;
    bg = layer(mw, mh); let g = bg.getContext('2d'); g.setTransform(v.fs, 0, 0, v.fs, v.ox + margin, v.oy + margin); Art.drawRoom(g, R.W, R.H, logicalOverX, logicalOverY);
    tbl = layer(mw, mh); g = tbl.getContext('2d'); g.setTransform(v.fs, 0, 0, v.fs, v.ox + margin, v.oy + margin); Art.drawTable(g, R.W, R.H, logicalOverX, logicalOverY);
    vig = layer(v.pw, v.ph); g = vig.getContext('2d');
    const gr = g.createRadialGradient(v.pw / 2, v.ph * 0.46, Math.min(v.pw, v.ph) * 0.28, v.pw / 2, v.ph * 0.5, Math.hypot(v.pw, v.ph) * 0.62);
    gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.6, 'rgba(8,0,2,0.45)'); gr.addColorStop(1, 'rgba(0,0,0,0.9)'); g.fillStyle = gr; g.fillRect(0, 0, v.pw, v.ph);
    hurtG = layer(v.pw, v.ph); g = hurtG.getContext('2d');
    const hg = g.createRadialGradient(v.pw / 2, v.ph / 2, Math.min(v.pw, v.ph) * 0.2, v.pw / 2, v.ph / 2, Math.hypot(v.pw, v.ph) * 0.55);
    hg.addColorStop(0, 'rgba(160,0,10,0)'); hg.addColorStop(1, 'rgba(180,0,12,0.95)'); g.fillStyle = hg; g.fillRect(0, 0, v.pw, v.ph);
    pGrain = c.createPattern(Art.sprites.grain, 'repeat'); pScan = c.createPattern(Art.sprites.scan, 'repeat');
  }
  R.toLogical = function (clientX, clientY) {
    const v = R.view, O = G.Orient, rot = !!(O && O.forced);
    const r = rot ? { left: 0, top: 0, width: cv.clientWidth || 1, height: cv.clientHeight || 1 } : cv.getBoundingClientRect();
    const q = O ? O.toApp(clientX, clientY) : { x: clientX, y: clientY};
    const px = (q.x - r.left) / r.width * v.pw, py = (q.y - r.top) / r.height * v.ph;
    return { x: (px - v.ox) / v.fs - Scene.camX, y: (py - v.oy) / v.fs };
  };

  /* ---------------------------------------------------------------- particles */
  R.spawn = function (o) {
    for (let i = 0; i < MAXP; i++) { const p = parts[i]; if (!p.a) { Object.assign(p, { a: true, kind: 'smoke', x: 0, y: 0, vx: 0, vy: 0, ay: 0, life: 1, max: 1, size: 20, grow: 0, rot: 0, vr: 0, alpha: 1, add: false, drag: 0 }, o); p.max = p.life; return p; } }
    return null;
  };
  const rq = () => (R.q === 'low' ? 0.4 : R.q === 'medium' ? 0.75 : 1);
  R.smoke = function (x, y, n, o) { o = o || {}; n = Math.ceil(n * rq() * (R.effects ? 1 : 0.5)); for (let i = 0; i < n; i++) R.spawn({ kind: 'smoke', x: x + (Math.random() - 0.5) * 8, y, vx: (o.vx || 0) + (Math.random() - 0.5) * 14, vy: (o.vy || -22) - Math.random() * 14, size: (o.size || 18) * (0.7 + Math.random() * 0.6), grow: o.grow || 22, life: (o.life || 2.4) * (0.7 + Math.random() * 0.6), alpha: o.alpha || 0.5, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 0.6, drag: 0.6 }); };
  R.sparks = function (x, y, n, o) { o = o || {}; n = Math.ceil(n * rq()); for (let i = 0; i < n; i++) { const a = (o.dir === undefined ? Math.random() * TAU : o.dir + (Math.random() - 0.5) * (o.spread || 1.2)), sp = (o.speed || 240) * (0.4 + Math.random()); R.spawn({ kind: 'spark', x, y, vx: cos(a) * sp, vy: sin(a) * sp, ay: o.g === undefined ? 520 : o.g, size: (o.size || 9) * (0.5 + Math.random()), life: (o.life || 0.6) * (0.5 + Math.random() * 0.7), add: true, alpha: 1, drag: 0.8 }); } };
  R.chips = function (x, y, n, col) { n = Math.ceil(n * rq()); for (let i = 0; i < n; i++) { const a = Math.random() * TAU, sp = 90 + Math.random() * 280; R.spawn({ kind: 'chip', x, y, vx: cos(a) * sp, vy: sin(a) * sp - 80, ay: 900, size: 3 + Math.random() * 5, life: 0.9 + Math.random() * 0.5, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 20, col: col || '#e8dfca', alpha: 1 }); } };
  R.fizz = function (x, y, n) { for (let i = 0; i < n * rq(); i++) R.spawn({ kind: 'spark', x: x + (Math.random() - 0.5) * 12, y, vx: (Math.random() - 0.5) * 50, vy: -60 - Math.random() * 90, ay: 120, size: 2 + Math.random() * 3, life: 0.5 + Math.random() * 0.5, add: true, alpha: 0.7 }); };
  R.burnFx = function (x, y) { R.sparks(x, y, 18, { dir: -Math.PI / 2, spread: 1.6, speed: 160, g: 80, size: 8, life: 1.1 }); R.smoke(x, y, 5, { size: 14, life: 2.2, alpha: 0.4 }); };
  R.muzzle = function (x, y, ang, big) { Scene.flashObj = { x, y, ang, t: 0, big: big ? 1 : 0.4 }; };
  R.shake = function (a) { R.shakeAmp = Math.max(R.shakeAmp, a); };
  R.punchZoom = function (a) { R.punch = Math.max(R.punch, a); };
  R.flash = function (col, amt) { Scene.flash = Math.max(Scene.flash, amt); Scene.flashCol = col || '255,200,150'; };
  R.flicker = function (dur) { R.flickerT = Math.max(R.flickerT, dur || 0.5); };

  /* ---------------------------------------------------------------- scene helpers (used by the presentation layer) */
  R.slotWorld = function (who, i) { const s = Art.slot(who, i); return { x: R.CX + s.x, y: s.y, s: s.s }; };
  R.clearItems = function () { Scene.items.p = new Array(6).fill(null); Scene.items.d = new Array(6).fill(null); if (G.Stage3D && G.Stage3D.clearBlood) G.Stage3D.clearBlood(); };
  R.setItem = function (who, i, id, uses, drop) { Scene.items[who][i] = { id, uses, z: drop ? 240 + Math.random() * 60 : 0, vz: 0, hidden: false, alpha: 1, burn: 0, landed: !drop, bob: Math.random() * 6, born: R.t, delay: 0 }; };
  R.onItemLand = null;
  R.handWrist = {};

  /* ---------------------------------------------------------------- per-frame update of visuals */
  function updateVisuals(dt) {
    R.t += dt; const t = R.t;
    for (const who of ['p', 'd']) for (const it of Scene.items[who]) {
      if (!it) continue;
      if (it.delay > 0) { it.delay -= dt; continue; }
      if (it.z > 0 || it.vz !== 0) {
        it.vz -= 2600 * dt; it.z += it.vz * dt;
        if (it.z <= 0) { it.z = 0; if (Math.abs(it.vz) > 140) { it.vz = -it.vz * 0.32; if (!it.landed) { it.landed = true; if (R.onItemLand) R.onItemLand(who, it); } } else it.vz = 0; }
      }
      if (it.burn > 0) { it.burn += dt * 0.9; if (Math.random() < 0.5) { const p = Scene.items[who].indexOf(it), w = R.slotWorld(who, p); R.sparks(w.x, w.y - 10, 1, { dir: -1.57, speed: 90, g: 30, size: 7, life: 0.8 }); R.smoke(w.x, w.y - 18, 1, { size: 8, life: 1.2, alpha: 0.35, vy: -30 }); } }
    }
    for (const p of parts) {
      if (!p.a) continue;
      p.life -= dt; if (p.life <= 0) { p.a = false; continue; }
      if (p.drag) { const f = Math.exp(-p.drag * dt); p.vx *= f; p.vy = p.vy * f; }
      p.vy += p.ay * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; p.size += p.grow * dt;
    }
    if (Scene.flashObj) { Scene.flashObj.t += dt; if (Scene.flashObj.t > 0.16) Scene.flashObj = null; }
    Scene.flash = Math.max(0, Scene.flash - dt * 3.2); Scene.hurt = Math.max(0, Scene.hurt - dt * 0.9);
    R.shakeAmp *= Math.exp(-dt * 7); R.punch *= Math.exp(-dt * 6);
    if (Scene.lens) { Scene.lens.t += dt; }
    // lamp
    R.nextFlicker -= dt;
    if (R.nextFlicker <= 0) { if (R.effects && !R.reduced) R.flicker(0.25 + Math.random() * 0.25); R.nextFlicker = 7 + Math.random() * 16; }
    let l = Scene.lampBase * (0.95 + 0.04 * sin(t * 41) * sin(t * 13) + 0.015 * sin(t * 3.1));
    if (R.flickerT > 0) { R.flickerT -= dt; if (!R.reduced || R.flickerT > 0) l *= (Math.random() < 0.38 ? 0.28 : 1); if (R.reduced) l = Scene.lampBase * 0.85; }
    l *= 1 - Scene.blackout;
    R.lamp += (l - R.lamp) * Math.min(1, dt * 30);
    Scene.zoom += ((Scene.mode === 'menu' ? 1.04 : 1) - Scene.zoom) * Math.min(1, dt * 1.2);
  }

  /* ---------------------------------------------------------------- drawing blocks */
  const CXc = R.CX;
  function drawTVs(g) {
    for (let i = 0; i < Art.tvRects.length; i++) {
      const r = Art.tvRects[i]; g.save(); g.beginPath(); Art.rr(g, r.x, r.y, r.w, r.h, r.r); g.clip();
      const k = Art.sprites.noise[(Math.floor(R.t * (R.q === 'low' ? 4 : 12)) + i) % 3];
      g.globalAlpha = 0.32 + Scene.tvGlitch * 0.4; g.imageSmoothingEnabled = false; g.drawImage(k, r.x, r.y, r.w, r.h);
      g.globalAlpha = 0.5; g.fillStyle = 'rgba(120,10,10,0.45)'; g.fillRect(r.x, r.y, r.w, r.h);
      const by = r.y + ((R.t * (30 + i * 12)) % (r.h + 30)) - 15; g.fillStyle = 'rgba(255,190,180,0.14)'; g.fillRect(r.x, by, r.w, 12);
      g.globalAlpha = 1; g.restore();
      g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = Art.rg(g, r.x + r.w / 2, r.y + r.h / 2, 5, r.w * 1.1, [[0, 'rgba(255,60,50,0.07)'], [1, 'rgba(255,60,50,0)']]); g.beginPath(); g.arc(r.x + r.w / 2, r.y + r.h / 2, r.w * 1.1, 0, TAU); g.fill(); g.restore();
    }
  }
  function drawLamp(g) {
    const l = R.lamp; if (l <= 0.01) return;
    g.save(); g.globalCompositeOperation = 'lighter';
    if (R.q !== 'low') { g.fillStyle = Art.lg(g, 0, 118, 0, 620, [[0, 'rgba(255,120,80,' + 0.22 * l + ')'], [1, 'rgba(255,70,40,0)']]); g.beginPath(); g.moveTo(584, 118); g.lineTo(696, 118); g.lineTo(980, 640); g.lineTo(300, 640); g.closePath(); g.fill(); }
    g.fillStyle = Art.rg(g, 640, 118, 1, 120, [[0, 'rgba(255,200,160,' + 0.8 * l + ')'], [1, 'rgba(255,100,60,0)']]); g.beginPath(); g.arc(640, 118, 120, 0, TAU); g.fill();
    g.restore();
  }
  function drawTableLight(g) {
    const l = R.lamp; g.save(); g.globalCompositeOperation = 'lighter';
    g.fillStyle = Art.rg(g, 640, 520, 20, 470, [[0, 'rgba(255,110,70,' + 0.2 * l + ')'], [1, 'rgba(255,60,30,0)']]); g.save(); g.translate(640, 520); g.scale(1.4, 0.7); g.translate(-640, -520); g.beginPath(); g.arc(640, 520, 470, 0, TAU); g.fill(); g.restore();
    g.restore();
  }
  function drawDust(g, dt) {
    const n = R.q === 'low' ? 0 : R.q === 'medium' ? 22 : 50; if (!n || !R.effects) return;
    g.save(); g.globalCompositeOperation = 'lighter';
    for (let i = 0; i < n; i++) { const d = dust[i]; if (!R.reduced) { d.x += (d.vx + sin(R.t * 0.4 + d.p) * 5) * dt; d.y += d.vy * dt; } if (d.y < 100) { d.y = 640; d.x = 380 + Math.random() * 520; }
      const a = 0.25 * R.lamp * (0.5 + 0.5 * sin(R.t + d.p)); g.fillStyle = 'rgba(255,170,130,' + a + ')'; g.fillRect(d.x, d.y, d.s, d.s); }
    g.restore();
  }
  function dealerPt(d, x, y) { const sc = 1 + (d.lean || 0) * 0.0035; return { x: CXc + sc * (x + (d.leanX || 0)), y: 560 + sc * (y - 560) }; }

  function shadow(g, x, y, w, h, a) { g.fillStyle = 'rgba(0,0,0,' + (a || 0.35) + ')'; g.beginPath(); g.ellipse(x, y, w, h, 0, 0, TAU); g.fill(); }

  function drawSlotItems(g, who) {
    const arr = Scene.items[who];
    for (let i = 0; i < 6; i++) {
      const it = arr[i]; if (!it || it.hidden || it.delay > 0) continue;
      const w = R.slotWorld(who, i), sc = w.s, bob = Scene.selected && Scene.selected.who === who && Scene.selected.idx === i ? sin(R.t * 4) * 2 - 4 : 0;
      shadow(g, w.x, w.y + 20 * sc, (28 - Math.min(it.z, 100) * 0.1) * sc, 8 * sc, 0.4 * (1 - Math.min(1, it.z / 200)));
      if (Scene.selected && Scene.selected.who === who && Scene.selected.idx === i) {
        g.save(); g.globalCompositeOperation = 'lighter'; g.strokeStyle = 'rgba(255,90,60,0.75)'; g.lineWidth = 3 * sc; g.beginPath(); g.ellipse(w.x, w.y + 18 * sc, 40 * sc, 13 * sc, 0, 0, TAU); g.stroke();
        g.fillStyle = Art.rg(g, w.x, w.y, 4, 70 * sc, [[0, 'rgba(255,80,50,0.25)'], [1, 'rgba(255,80,50,0)']]); g.beginPath(); g.arc(w.x, w.y, 70 * sc, 0, TAU); g.fill(); g.restore();
      }
      Art.drawItem(g, it.id, { x: w.x, y: w.y - it.z + bob, s: sc * 0.92, rot: it.id === 'cigarette' ? -0.4 : (it.id === 'handcuffs' ? 0 : 0), t: R.t, alpha: it.alpha, ic: it.burn > 0 ? 0.6 : 0 });
      if (it.burn > 0) { g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = Art.rg(g, w.x, w.y - 8, 2, 50 * sc, [[0, 'rgba(255,140,50,' + Math.min(0.9, it.burn) + ')'], [1, 'rgba(255,40,10,0)']]); g.beginPath(); g.arc(w.x, w.y - 8, 50 * sc, 0, TAU); g.fill(); g.restore(); }
      if (it.uses > 1) { g.fillStyle = '#e8dcc0'; g.font = 'bold ' + 13 * sc + 'px sans-serif'; g.textAlign = 'center'; g.fillText('x' + it.uses, w.x + 26 * sc, w.y + 22 * sc); }
    }
  }

  function shellDraw(g, kind, x, y, rot, z, fade) {
    g.save(); g.translate(x, y - z); g.rotate(rot); g.globalAlpha = fade;
    const ember = kind === 'shell_e';
    g.fillStyle = ember ? '#b3171d' : '#7c7a76'; Art.rr(g, -13, -4.8, 21, 9.6, 3); g.fill(); g.strokeStyle = '#0a0405'; g.lineWidth = 1.8; g.stroke();
    g.fillStyle = ember ? '#c9a24a' : '#2d2b29'; Art.rr(g, 7, -5.2, 7, 10.4, 2); g.fill(); g.stroke();
    g.fillStyle = 'rgba(255,255,255,0.28)'; g.fillRect(-11, -3.4, 17, 1.8);
    g.restore();
  }
  function drawBodies(g) {
    for (const b of G.Physics.bodies) {
      const x = CXc + b.x, y = b.y, k = b.kind;
      if (b.off && b.z < -300) continue;
      shadow(g, x, y + 4, b.r * 1.2, b.r * 0.45, 0.35 * Math.max(0, 1 - Math.max(0, b.z) / 220) * b.fade);
      if (k === 'shell_e' || k === 'shell_a') shellDraw(g, k, x, y, b.rot, Math.max(0, b.z), b.fade);
      else if (k === 'coin') { g.save(); g.translate(x, y - Math.max(0, b.z)); g.scale(1, Math.max(0.12, Math.abs(cos(b.rot * 1.0)))); Art.drawItem(g, 'coin', { x: 0, y: 0, s: 0.6, rot: 0, alpha: b.fade }); g.restore(); }
      else if (k === 'can') Art.drawItem(g, 'can', { x, y: y - Math.max(0, b.z), s: 0.72, rot: b.rot, isc: 0.6, alpha: b.fade });
      else if (k === 'bottle') Art.drawItem(g, 'medicine', { x, y: y - Math.max(0, b.z), s: 0.7, rot: b.rot, io: 1, alpha: b.fade });
      else if (k === 'cell') Art.drawItem(g, 'battery', { x, y: y - Math.max(0, b.z), s: 0.5, rot: b.rot, alpha: b.fade });
      else if (k === 'butt') { g.save(); g.translate(x, y - b.z); g.rotate(b.rot); g.globalAlpha = b.fade; g.fillStyle = '#d8d0c0'; g.fillRect(-7, -2, 14, 4); g.fillStyle = '#a8763a'; g.fillRect(3, -2, 4, 4); g.fillStyle = '#5a544e'; g.fillRect(-8, -2, 3, 4); g.restore(); }
      else if (k === 'pill') { g.save(); g.translate(x, y - Math.max(0, b.z)); g.rotate(b.rot); g.globalAlpha = b.fade; g.fillStyle = '#e8e0cf'; Art.rr(g, -5, -2.4, 10, 4.8, 2.4); g.fill(); g.strokeStyle = '#2a1a10'; g.lineWidth = 1; g.stroke(); g.restore(); }
    }
  }

  function handScreen(actor, side) { const p = actor.p; return side === 'l' ? { x: CXc + p.lx, y: p.ly, r: p.lr, c: p.lc, i: p.li, t: p.lt, s: p.ls } : { x: CXc + p.rx, y: p.ry, r: p.rr, c: p.rc, i: p.ri, t: p.rt, s: p.rs }; }
  function trem(p, k) { return p.trem ? [(Math.sin(R.t * 53 + k * 3) + Math.sin(R.t * 37 + k)) * 1.6 * p.trem, (Math.sin(R.t * 47 + k * 2) + Math.cos(R.t * 31 + k)) * 1.6 * p.trem] : [0, 0]; }
  const FOCUS = { l: { x: -230, y: 900 }, r: { x: 230, y: 900 } };

  function gunState() {
    const gp = G.Anim.gun.p, B = Art.GUN_BASE;
    return { x: CXc + B.x + gp.gox, y: B.y + gp.goy, ang: gp.gang, fore: gp.gfore, sc: gp.gsc, brk: gp.gbrk, kick: gp.gkick, charge: Scene.charge, dread: Scene.dread };
  }

  R.gunState = function () { return gunState(); };
  R.gunPoint = function (lx, ly) { if (R.use3d) { const q = G.Stage3D.gunLocalToLogical(lx, ly); if (q) return q; } return Art.gunPoint(gunState(), lx, ly); };
  R.muzzlePos = function () { const gs = gunState(); if (R.use3d && G.Stage3D.gunInfo && G.Stage3D.gunInfo.muzzleL) { const m = G.Stage3D.gunInfo.muzzleL; return { x: m.x, y: m.y, ang: gs.ang }; } const p = Art.gunPoint(gs, 306, -18); return { x: p.x, y: p.y, ang: gs.ang }; };

  function drawPlayerHands(g) {
    const A = G.Anim, pl = A.player, p = pl.p, holder = Scene.gunHolder, held = Scene.held.p;
    const breath = sin(R.t * 0.9 * p.brt) * 3 * (p.brt > 1.5 ? 1.5 : 1);
    let L = handScreen(pl, 'l'), Rr = handScreen(pl, 'r'); L.rot = L.r; Rr.rot = Rr.r;
    let gs = null;
    if (holder === 'p') {
      gs = gunState(); const a = gs.ang;
      const grip = Art.gunPoint(gs, 8, 14), fore = Art.gunPoint(gs, 150, 10);
      Rr.x = grip.x; Rr.y = grip.y; Rr.rot = a + 0.1; Rr.c = 0.9; Rr.i = 0.85; Rr.t = 0.9; Rr.s = 1.05 * Math.max(0.8, gs.sc * 0.85);
      L.x = fore.x; L.y = fore.y; L.rot = a - 0.15; L.c = 0.85; L.i = 0.85; L.t = 0.8; L.s = Rr.s;
    }
    // remember where the hands really are (for seamless detaching)
    R.handWrist.p = { lx: L.x - CXc, ly: L.y, lr: L.rot, rx: Rr.x - CXc, ry: Rr.y, rr: Rr.rot };
    if (holder === 'p' && gs) Art.drawGun(g, gs);
    for (const [side, H, k] of [['l', L, 0], ['r', Rr, 1]]) {
      const tr = trem(p, k), hx = H.x + tr[0], hy = H.y + tr[1] + breath * (holder === 'p' ? 0 : 1);
      const dir = FOCUS[side], tx = CXc + dir.x - hx, ty = dir.y - hy, srot = Math.atan2(-tx, ty);
      Art.drawSleeve(g, { x: hx, y: hy, rot: H.rot, srot: U.clamp(srot, -0.9, 0.9), s: H.s });
      Art.drawHand(g, { x: hx, y: hy, rot: H.rot, s: H.s, c: H.c, i: H.i, t: H.t, side: side === 'l' ? 1 : -1, skin: Art.SKIN_P, tapAmp: side === 'r' ? p.tap : 0, tapT: R.t });
      if (Scene.cuffs.p) { /* drawn below */ }
      if (side === 'r' && held && held.kind === 'item') {
        const f = { x: sin(H.rot), y: -cos(H.rot) }, d = 56 * H.s;
        const iy = hy + f.y * d, ix = hx + f.x * d;
        Art.drawItem(g, held.id, { x: ix, y: iy, s: 1.0 * H.s * (p.isc === 0 ? 0 : 1) , rot: H.rot * 0.5, irot: p.irot, io: p.io, il: p.il, ic: p.ic, isc: p.isc, t: R.t });
        R.heldPos = { x: ix, y: iy };
      }
    }
    if (Scene.cuffs.p) drawCuffs(g, L, Rr, 1);
  }
  function drawCuffs(g, a, b, dir) {
    for (const H of [a, b]) { g.save(); g.translate(H.x, H.y + 8 * dir); g.strokeStyle = '#0b0506'; g.lineWidth = 9; g.beginPath(); g.ellipse(0, 0, 30 * H.s, 10 * H.s, 0, 0, TAU); g.stroke(); g.strokeStyle = '#a7a5a1'; g.lineWidth = 5; g.stroke(); g.restore(); }
    g.strokeStyle = '#0b0506'; g.lineWidth = 6; g.beginPath(); g.moveTo(a.x + 22, a.y + 10 * dir); g.quadraticCurveTo((a.x + b.x) / 2, Math.max(a.y, b.y) + 40 * dir, b.x - 22, b.y + 10 * dir); g.stroke(); g.strokeStyle = '#8c8a86'; g.lineWidth = 3; g.setLineDash([7, 4]); g.stroke(); g.setLineDash([]);
  }

  function drawDealer(g) {
    const A = G.Anim, dl = A.dealer, d = dl.p, holder = Scene.gunHolder, held = Scene.held.d;
    const fl = [0.92 + 0.16 * sin(R.t * 9) + Scene.dealerFlameBoost * 0.2, 0.9 + 0.18 * sin(R.t * 7.3 + 2)];
    g.save();
    if (d.glitch > 0.2) g.translate((Math.random() - 0.5) * 14 * d.glitch, 0);
    g.translate(CXc, 0); Art.drawDealerBody(g, d, R.t, { flame: fl }); g.restore();
    // candle light on the face
    g.save(); g.globalCompositeOperation = 'lighter'; const hp = dealerPt(d, d.hx || 0, 214 + (d.hy || 0));
    g.fillStyle = Art.rg(g, hp.x, hp.y + 10, 5, 200, [[0, 'rgba(255,140,90,' + 0.16 * (fl[0] + fl[1]) * 0.5 + ')'], [1, 'rgba(255,100,60,0)']]); g.beginPath(); g.arc(hp.x, hp.y + 10, 200, 0, TAU); g.fill(); g.restore();
    return { d, holder, held };
  }
  function drawDealerHands(g, st) {
    const { d, holder, held } = st, dl = G.Anim.dealer;
    let L = handScreen(dl, 'l'), Rr = handScreen(dl, 'r');
    L.rot = Math.PI + L.r; Rr.rot = Math.PI + Rr.r;
    let gs = null;
    if (holder === 'd') {
      gs = gunState(); const a = gs.ang;
      const grip = Art.gunPoint(gs, 8, 14), fore = Art.gunPoint(gs, 150, 10);
      Rr.x = grip.x; Rr.y = grip.y; Rr.rot = a + 0.1 + Math.PI * 0; Rr.c = 0.9; Rr.i = 0.85; Rr.t = 0.9; Rr.s = 0.92;
      L.x = fore.x; L.y = fore.y; L.rot = a - 0.15; L.c = 0.85; L.i = 0.85; L.t = 0.8; L.s = 0.92;
    }
    R.handWrist.d = { lx: L.x - CXc, ly: L.y, lr: L.rot - Math.PI, rx: Rr.x - CXc, ry: Rr.y, rr: Rr.rot - Math.PI };
    const sh = { l: dealerPt(d, -186, 346 - (d.shr || 0) * 5), r: dealerPt(d, 186, 346 - (d.shr || 0) * 5) };
    const DS = 0.78; // the Dealer is farther away than the player's hands
    for (const [side, H, k] of [['l', L, 0], ['r', Rr, 1]]) {
      const tr = trem(d, k), hx = H.x + tr[0], hy = H.y + tr[1] + (d.tap && side === 'r' ? Math.max(0, sin(R.t * 13)) * -3 * d.tap : 0);
      Art.drawDealerArm(g, sh[side].x, sh[side].y, hx, hy, H.rot, side === 'l' ? -1 : 1, H.s * DS);
    }
    if (holder === 'd' && gs) Art.drawGun(g, gs);
    for (const [side, H, k] of [['l', L, 0], ['r', Rr, 1]]) {
      const tr = trem(d, k), hx = H.x + tr[0], hy = H.y + tr[1] + (d.tap && side === 'r' ? Math.max(0, sin(R.t * 13)) * -3 * d.tap : 0);
      Art.drawHand(g, { x: hx, y: hy, rot: H.rot, s: H.s * DS, c: H.c, i: H.i, t: H.t, side: side === 'l' ? -1 : 1, skin: Art.SKIN_D, len: 1.12, tapAmp: side === 'r' ? d.tap : 0, tapT: R.t });
      if (side === 'r' && held && held.kind === 'item') {
        const f = { x: sin(H.rot), y: -cos(H.rot) }, dd = -34 * H.s * DS, ix = hx + f.x * dd, iy = hy + f.y * dd;
        Art.drawItem(g, held.id, { x: ix, y: iy, s: 0.95 * H.s * DS * 1.15, rot: (H.rot - Math.PI) * 0.4, irot: d.irot, io: d.io, il: d.il, ic: d.ic, isc: d.isc, t: R.t });
        R.heldPosD = { x: ix, y: iy };
      }
    }
    if (Scene.cuffs.d) drawCuffs(g, L, Rr, -1);
  }

  function drawFlash(g) {
    const f = Scene.flashObj; if (!f) return;
    const k = 1 - f.t / 0.16, s = (60 + 70 * f.big) * (0.6 + k * 0.6);
    g.save(); g.translate(f.x, f.y); g.rotate(f.ang); g.globalCompositeOperation = 'lighter';
    g.fillStyle = Art.rg(g, 0, 0, 2, s * 2.2, [[0, 'rgba(255,235,190,' + k + ')'], [0.3, 'rgba(255,140,50,' + 0.6 * k + ')'], [1, 'rgba(255,60,20,0)']]); g.beginPath(); g.arc(0, 0, s * 2.2, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,245,215,' + k + ')'; g.beginPath(); for (let i = 0; i < 16; i++) { const a = i * TAU / 16, r = (i % 2 ? s * 0.45 : s * (0.9 + 0.5 * ((i * 7) % 3) / 3)); g.lineTo(cos(a) * r, sin(a) * r); } g.closePath(); g.fill();
    g.restore();
  }
  function drawParticles(g) {
    for (const p of parts) {
      if (!p.a) continue; const k = p.life / p.max;
      if (p.kind === 'smoke') { g.globalAlpha = p.alpha * k * Math.min(1, (1 - k) * 6) * 0.8; g.save(); g.translate(p.x, p.y); g.rotate(p.rot); g.drawImage(Art.sprites.smoke, -p.size, -p.size, p.size * 2, p.size * 2); g.restore(); }
      else if (p.kind === 'spark') { g.globalCompositeOperation = 'lighter'; g.globalAlpha = k * p.alpha; g.drawImage(Art.sprites.spark, p.x - p.size, p.y - p.size, p.size * 2, p.size * 2); g.globalCompositeOperation = 'source-over'; }
      else if (p.kind === 'chip') { g.globalAlpha = Math.min(1, k * 2); g.save(); g.translate(p.x, p.y); g.rotate(p.rot); g.fillStyle = p.col; g.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66); g.restore(); }
    }
    g.globalAlpha = 1;
  }
  function drawLens(g) {
    const L = Scene.lens; if (!L) return;
    const a = Math.min(1, L.t * 4) * (L.out ? Math.max(0, 1 - (L.t - L.outAt) * 4) : 1); if (a <= 0.01) return;
    const cx = 640, cy = 330, r = 168 * (0.9 + 0.1 * Math.min(1, L.t * 5));
    g.save(); g.globalAlpha = a; g.fillStyle = 'rgba(0,0,0,0.62)'; g.beginPath(); g.rect(-1000, -600, 3300, 2000); g.arc(cx, cy, r, 0, TAU, true); g.fill();
    g.save(); g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.clip();
    g.fillStyle = Art.rg(g, cx, cy, 5, r, [[0, '#2a1512'], [1, '#080303']]); g.fillRect(cx - r, cy - r, r * 2, r * 2);
    // chamber end: steel ring and the shell base
    g.fillStyle = Art.lg(g, cx - 120, cy - 120, cx + 120, cy + 120, [[0, '#7d776f'], [1, '#2b2825']]); g.beginPath(); g.arc(cx, cy, 108, 0, TAU); g.fill(); g.strokeStyle = '#0a0506'; g.lineWidth = 5; g.stroke();
    const em = L.type === 'e';
    g.fillStyle = em ? '#a3141b' : '#6f6d69'; g.beginPath(); g.arc(cx, cy, 78, 0, TAU); g.fill(); g.stroke();
    g.fillStyle = em ? '#c9a24a' : '#2a2826'; g.beginPath(); g.arc(cx, cy, 44, 0, TAU); g.fill(); g.stroke();
    g.fillStyle = em ? '#7a0c12' : '#161412'; g.beginPath(); g.arc(cx, cy, 14, 0, TAU); g.fill();
    if (em) { g.globalCompositeOperation = 'lighter'; g.fillStyle = Art.rg(g, cx, cy, 6, 150, [[0, 'rgba(255,90,40,' + (0.45 + 0.15 * sin(L.t * 8)) + ')'], [1, 'rgba(255,60,20,0)']]); g.beginPath(); g.arc(cx, cy, 150, 0, TAU); g.fill(); g.globalCompositeOperation = 'source-over'; }
    g.restore();
    g.strokeStyle = '#b08a3a'; g.lineWidth = 12; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.stroke(); g.strokeStyle = '#0a0506'; g.lineWidth = 3; g.stroke();
    g.strokeStyle = 'rgba(255,255,255,0.35)'; g.lineWidth = 4; g.beginPath(); g.arc(cx, cy, r - 14, 3.7, 4.5); g.stroke();
    g.fillStyle = em ? '#ff6a4a' : '#c9c4bb'; g.font = 'bold 30px sans-serif'; g.textAlign = 'center'; g.fillText(em ? G.U.t('toast.ember') : G.U.t('toast.ash'), cx, cy + r + 40);
    g.restore();
  }

  function post2d(v) {
    // post (screen space)
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.drawImage(vig, 0, 0);
    if (Scene.doorLight > 0) { c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = Art.lg(c, 0, 0, v.pw * 0.8, 0, [[0, 'rgba(255,230,180,' + 0.75 * Scene.doorLight + ')'], [1, 'rgba(255,200,140,0)']]); c.fillRect(0, 0, v.pw, v.ph); c.restore(); }
    if (Scene.redWash > 0) { c.fillStyle = 'rgba(120,0,6,' + Scene.redWash * 0.55 + ')'; c.fillRect(0, 0, v.pw, v.ph); }
    const low = Scene.lowPulse ? (0.5 + 0.5 * sin(R.t * 7)) * 0.4 * Scene.lowPulse : 0;
    if (Scene.hurt > 0 || low > 0) { c.globalAlpha = Math.min(1, Scene.hurt + low); c.drawImage(hurtG, 0, 0); c.globalAlpha = 1; }
    if (Scene.flash > 0) { c.fillStyle = 'rgba(' + Scene.flashCol + ',' + Math.min(0.85, Scene.flash) + ')'; c.fillRect(0, 0, v.pw, v.ph); }
    if (R.effects && R.q === 'high') {
      c.save(); c.globalAlpha = R.q === 'high' ? 0.07 : 0.05; c.translate((Math.random() * 128) | 0, (Math.random() * 128) | 0); c.fillStyle = pGrain; c.fillRect(-128, -128, v.pw + 256, v.ph + 256); c.restore();
      if (R.q === 'high') { c.save(); c.globalAlpha = 0.25; c.scale(1, Math.max(1, v.pr)); c.fillStyle = pScan; c.fillRect(0, 0, v.pw, v.ph / Math.max(1, v.pr)); c.restore(); }
      if (!R.reduced) { const by = ((R.t * 90) % (v.ph + 80)) - 40; c.fillStyle = 'rgba(255,160,150,0.025)'; c.fillRect(0, by, v.pw, 28 * v.pr); }
    }
    if (Scene.fade > 0) { c.fillStyle = 'rgba(0,0,0,' + Scene.fade + ')'; c.fillRect(0, 0, v.pw, v.ph); }
  }
  function frame3d(dt, v) {
    G.Stage3D.render(R, INT, dt);
    c.save(); c.translate(v.ox, v.oy); c.scale(v.fs, v.fs);
    drawParticles(c); drawLens(c);
    c.restore();
    post2d(v);
  }
  const INT = { handScreen, trem, gunState, CX: CXc };
  /* ---------------------------------------------------------------- frame */
  /* resolution governor: if frames take too long the render resolution drops smoothly; when there is headroom it climbs back */
  R.auto = 1; let gov = { ema: 1 / 60, slow: 0, fast: 0 };
  function governor(dt) {
    if (dt <= 0 || dt > 0.25 || !R.use3d) return;
    gov.ema += (dt - gov.ema) * 0.08; const target = 1 / 50;
    if (gov.ema > target * 1.12) { gov.slow += dt; gov.fast = 0; } else if (gov.ema < 1 / 57) { gov.fast += dt; gov.slow = 0; } else { gov.slow = gov.fast = 0; }
    if (gov.slow > 0.8 && R.auto > 0.5) { R.auto = Math.max(0.5, R.auto * 0.86); gov.slow = 0; R.resize(); }
    else if (gov.fast > 5 && R.auto < 1) { R.auto = Math.min(1, R.auto * 1.07); gov.fast = 0; R.resize(); }
  }
  R.frame = function (dt) {
    if (R.menuCover && Scene.mode === 'menu') { R.stats.frames++; return; }   // the image menu covers the 3D view: nothing to draw
    const t0 = performance.now(); if (!(G.Main && G.Main.paused)) governor(dt);
    updateVisuals(dt); G.Physics.step(dt);
    const v = R.view, A = G.Anim;
    c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over';
    if (R.use3d && G.Stage3D.ready && G.GL3D.ok) { c.clearRect(0, 0, v.pw, v.ph); frame3d(dt, v); R.stats.frames++; R.stats.drawMs += performance.now() - t0; return; }
    c.fillStyle = '#000'; c.fillRect(0, 0, v.pw, v.ph);
    const amp = R.shakeAmp * R.shakeScale * 14 * v.fs, shx = (Math.random() - 0.5) * amp, shy = (Math.random() - 0.5) * amp;
    const sway = R.reduced ? 0 : 1, zoom = Scene.zoom * (1 + R.punch * 0.03 * R.shakeScale) + (Scene.mode === 'menu' && !R.reduced ? sin(R.t * 0.15) * 0.01 : 0);
    c.translate(v.pw / 2 + shx + sin(R.t * 0.31) * 3 * sway * v.fs, v.ph / 2 + shy + cos(R.t * 0.23) * 2 * sway * v.fs);
    c.rotate(sin(R.t * 0.2) * 0.0035 * sway + (shx * 0.0004)); c.scale(zoom, zoom); c.translate(-v.pw / 2, -v.ph / 2);
    c.drawImage(bg, -margin + Scene.camX * v.fs, -margin);
    c.save(); c.translate(v.ox + Scene.camX * v.fs, v.oy); c.scale(v.fs, v.fs);
    drawTVs(c); drawLamp(c); drawDust(c, dt);
    const dst = drawDealer(c);
    c.setTransform(1, 0, 0, 1, 0, 0); c.restore(); c.save();
    // re-apply camera for cached table (same screen-space transform as bg)
    c.drawImage(tbl, -margin + Scene.camX * v.fs, -margin);
    c.translate(v.ox + Scene.camX * v.fs, v.oy); c.scale(v.fs, v.fs);
    drawTableLight(c);
    drawSlotItems(c, 'd');
    if (Scene.gunHolder === 'table') Art.drawGun(c, gunState());
    drawBodies(c);
    drawDealerHands(c, dst);
    drawSlotItems(c, 'p');
    drawPlayerHands(c);
    drawFlash(c); drawParticles(c); drawLens(c);
    c.restore();
    post2d(v);
    R.stats.frames++; R.stats.drawMs += performance.now() - t0;
  };

  G.Renderer = R;
  if (typeof module !== 'undefined' && module.exports) module.exports = R;
})(typeof window !== 'undefined' ? window : globalThis);
