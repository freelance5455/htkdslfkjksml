/* ui-controller.js — every HTML screen: menu, difficulty, settings, pause, HUD, item card, inventory, archive,
   achievements, credits, endings, tutorial, confirm, toasts, subtitles, banner, rotate prompt. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, E = G.Engine, Au = G.AudioMgr, Save = G.Save, R = G.Renderer, Art = G.Art;
  const $ = (id) => document.getElementById(id);
  const UI = { modalStack: [], prev: {}, settingsFrom: 'menu', selSlot: -1 };
  const T = () => G.Turns, S = () => G.Show;

  /* ------------------------------------------------------------ modal handling */
  UI.open = function (id) {
    const m = $(id); if (!m) return; m.classList.remove('hidden'); UI.modalStack.push(id); G.Access.open(m);
    if (G.Input) G.Input.enabled = false;
  };
  UI.close = function (id) {
    const m = $(id); if (!m) return; m.classList.add('hidden'); UI.modalStack = UI.modalStack.filter((x) => x !== id); G.Access.close(m);
    if (!UI.modalStack.length && G.Input) G.Input.enabled = true;
  };
  UI.closeAll = function () { for (const id of UI.modalStack.slice()) UI.close(id); };
  UI.confirm = function (key, onYes) {
    $('confMsg').textContent = U.t(key); UI.open('mConfirm');
    $('confYes').onclick = () => { UI.close('mConfirm'); onYes(); }; $('confNo').onclick = () => UI.close('mConfirm');
  };

  /* ------------------------------------------------------------ language */
  UI.applyLang = function () {
    document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = U.t(el.dataset.i18n); el.hidden = el.dataset.i18n.indexOf('logo') === 0 && !el.textContent; });
    document.querySelectorAll('[data-aria]').forEach((el) => el.setAttribute('aria-label', U.t(el.dataset.aria)));
    $('credBody').textContent = U.t('credits.body'); document.title = U.t('title');
    UI.buildDiff(); UI.refreshHud(); UI.updateActions();
    if (R && R.scene && R.scene.mode === 'menu') R.scene.camX = U.lang === 'ar' ? -135 : 135;
  };

  /* ------------------------------------------------------------ menu */
  UI.showMenu = function () {
    $('menu').classList.remove('hidden'); $('hud').classList.add('hidden'); UI.closeAll(); UI.closeInventory(true); UI.hideItemCard();
    $('mContinue').disabled = !Save.hasRun();
    R.scene.mode = 'menu'; R.scene.camX = U.lang === 'ar' ? -135 : 135; $('subtitles').innerHTML = ''; $('toasts').innerHTML = '';
    if (G.Input) G.Input.enabled = true;
  };
  UI.showGame = function () {
    $('menu').classList.add('hidden'); $('hud').classList.remove('hidden'); UI.closeAll(); R.scene.mode = 'game'; R.scene.camX = 0;
    UI.setAim(null); UI.refreshHud(); UI.updateActions(); UI.checkOrientation();
  };

  UI.buildDiff = function () {
    const box = $('diffList'); box.innerHTML = '';
    for (const id of Object.keys(D.difficulties)) {
      const df = D.difficulties[id], locked = df.locked && !G.Turns.meta.unlocked.nightmare;
      const b = document.createElement('button'); b.className = 'dbtn' + (locked ? ' locked' : '') + (G.Turns.meta.lastDiff === id ? ' last' : '');
      b.innerHTML = '<b>' + U.t('diff.' + id) + '</b><small>' + (locked ? U.t('diff.locked') : U.t('diff.' + id + 'D')) + '</small>';
      b.disabled = !!locked; b.onclick = () => { UI.close('mDiff'); UI.startNew(id); };
      box.appendChild(b);
    }
  };
  UI.startNew = function (diff) {
    const go = () => G.Turns.newGame(diff);
    if (!G.Turns.meta.tutorial) { UI.showTutorial(() => { G.Turns.meta.tutorial = true; Save.saveMeta(G.Turns.meta); go(); }); } else go();
  };
  UI.openDiff = function () { UI.buildDiff(); UI.closeAll(); UI.open('mDiff'); };

  /* ------------------------------------------------------------ settings */
  const SCHEMA = [
    ['set.audioGroup', [['master', 'range', 'set.master'], ['music', 'range', 'set.music'], ['ambience', 'range', 'set.ambience'], ['sfx', 'range', 'set.sfx'], ['voice', 'range', 'set.voice']]],
    ['set.videoGroup', [['quality', 'seg', 'set.quality', [['low', 'set.low'], ['medium', 'set.medium'], ['high', 'set.high']]], ['fps', 'seg', 'set.fps', [[30, 'set.fps30'], [60, 'set.fps60']]],
      ['shake', 'range', 'set.shake'], ['effects', 'tog', 'set.effects'], ['touch', 'range', 'set.touch', null, [0.8, 1.8]], ['haptics', 'tog', 'set.haptics']]],
    ['set.accGroup', [['subtitles', 'tog', 'set.subtitles'], ['textSize', 'seg', 'set.textSize', [[0, 'set.small'], [1, 'set.medium'], [2, 'set.large']]], ['lang', 'seg', 'set.language', [['en', 'English'], ['ar', 'العربية']]], ['reduced', 'tog', 'set.reduced']]]
  ];
  UI.buildSettings = function () {
    const body = $('setBody'); body.innerHTML = ''; const s = G.Turns.settings;
    for (const [gk, rows] of SCHEMA) {
      const g = document.createElement('div'); g.className = 'sgroup'; g.textContent = U.t(gk); body.appendChild(g);
      for (const [key, type, label, opts, rng] of rows) {
        const row = document.createElement('div'); row.className = 'srow'; const lab = document.createElement('label'); lab.textContent = U.t(label); row.appendChild(lab);
        let ctl;
        if (type === 'range') {
          ctl = document.createElement('input'); ctl.type = 'range'; const [mn, mx] = rng || [0, 1]; ctl.min = mn; ctl.max = mx; ctl.step = 0.01; ctl.value = s[key]; ctl.id = 'set_' + key; lab.htmlFor = ctl.id;
          const paint = () => ctl.style.setProperty('--v', ((ctl.value - mn) / (mx - mn) * 100) + '%'); paint();
          ctl.oninput = () => { paint(); UI.setSetting(key, parseFloat(ctl.value), true); };
          ctl.onchange = () => { Au.sfx('tick', { vol: 0.8 }); if (key === 'sfx') Au.sfx('metal_clink', { vol: 0.8 }); if (key === 'voice') Au.speak('Test', 'normal'); if (key === 'shake') R.shake(1); };
        } else if (type === 'tog') {
          ctl = document.createElement('button'); ctl.className = 'tog'; ctl.setAttribute('role', 'switch'); ctl.setAttribute('aria-checked', s[key] ? 'true' : 'false'); ctl.setAttribute('aria-label', U.t(label));
          ctl.onclick = () => { const v = ctl.getAttribute('aria-checked') !== 'true'; ctl.setAttribute('aria-checked', v ? 'true' : 'false'); UI.setSetting(key, v); if (key === 'haptics' && v) { try { navigator.vibrate && navigator.vibrate(40); } catch (e) { /* ignore */ } } };
        } else {
          ctl = document.createElement('div'); ctl.className = 'seg'; ctl.setAttribute('role', 'radiogroup'); ctl.setAttribute('aria-label', U.t(label));
          for (const [val, lk] of opts) { const b = document.createElement('button'); b.textContent = lk.indexOf('.') > 0 ? U.t(lk) : lk; b.setAttribute('role', 'radio'); b.className = s[key] === val ? 'on' : ''; b.setAttribute('aria-checked', s[key] === val ? 'true' : 'false');
            b.onclick = () => { UI.setSetting(key, val); ctl.querySelectorAll('button').forEach((x) => { x.className = ''; x.setAttribute('aria-checked', 'false'); }); b.className = 'on'; b.setAttribute('aria-checked', 'true'); }; ctl.appendChild(b); }
        }
        row.appendChild(ctl); body.appendChild(row);
      }
    }
  };
  UI.setSetting = function (key, val, live) {
    const t = G.Turns; t.settings[key] = val; t.settings = Save.sanitizeSettings(t.settings); Save.saveSettings(t.settings);
    G.Main.applySettings(t.settings);
    if (key === 'lang') { UI.applyLang(); UI.buildSettings(); }
  };
  UI.openSettings = function (from) {
    UI.settingsFrom = from || 'menu'; UI.buildSettings(); UI.open('mSet');
    $('setBack').onclick = () => { UI.close('mSet'); if (UI.settingsFrom === 'pause') UI.open('mPause'); };
    $('setReset').onclick = () => { const t = G.Turns; t.settings = Save.defaultSettings(); Save.saveSettings(t.settings); G.Main.applySettings(t.settings); UI.applyLang(); UI.buildSettings(); };
  };

  /* ------------------------------------------------------------ pause */
  UI.openPause = function () {
    if (!G.Turns.active) return; G.Turns.pause(); UI.open('mPause');
    $('pResume').onclick = () => UI.resumeGame();
    $('pRound').onclick = () => UI.confirm('confirm.restartRound', () => { UI.closeAll(); G.Turns.retryRound(); });
    $('pGame').onclick = () => UI.confirm('confirm.restartGame', () => { UI.closeAll(); G.Turns.restartGame(); });
    $('pSet').onclick = () => { UI.close('mPause'); UI.openSettings('pause'); };
    $('pMenu').onclick = () => UI.confirm('confirm.menu', () => { UI.closeAll(); G.Turns.toMenu(); });
  };
  UI.resumeGame = function () { UI.close('mPause'); G.Turns.resume(); };

  /* ------------------------------------------------------------ HUD */
  const bolts = { p: 0, d: 0, pp: -1, dp: -1 };
  function setBolts(el, hp, max, prev) {
    if (el.childElementCount !== max) { el.innerHTML = ''; for (let i = 0; i < max; i++) { const b = document.createElement('span'); b.className = 'bolt'; b.innerHTML = '<svg viewBox="0 0 20 26"><path d="M12 1 2 14h6l-2 11 12-15h-7z"/></svg>'; el.appendChild(b); } }
    for (let i = 0; i < max; i++) { const b = el.children[i]; const lost = i >= hp; if (lost && !b.classList.contains('lost') && prev >= 0) { b.classList.add('hit'); setTimeout(() => b.classList.remove('hit'), 520); } b.classList.toggle('lost', lost); }
    el.setAttribute('aria-label', U.t('hud.pulse') + ': ' + hp + '/' + max);
  }
  UI.refreshHud = function () {
    const v = S() && S().view, st = T() && T().st; if (!v || !st || !T().active) return;
    setBolts($('pBolts'), v.pHp, v.pMax, bolts.pp); setBolts($('dBolts'), v.dHp, v.dMax, bolts.dp); bolts.pp = v.pHp; bolts.dp = v.dHp;
    $('roundLbl').textContent = U.t('hud.round', { n: Math.max(1, v.round), m: D.config.rounds });
    const tl = $('turnLbl'); tl.className = 'turnlbl' + (v.turn === 'p' ? ' you' : v.turn === 'd' ? ' dlr' : '');
    tl.textContent = v.turn === 'p' ? U.t('hud.yourTurn') : v.turn === 'd' ? U.t('hud.dealerTurn') : '';
    $('cE').textContent = v.pubE; $('cA').textContent = v.pubA;
    $('chamber').setAttribute('aria-label', U.t('hud.chamber') + ': ' + v.pubE + ' ' + U.t('hud.embers') + ', ' + v.pubA + ' ' + U.t('hud.ash'));
    const pk = $('peekHint'); if (v.peek) { pk.className = 'peek ' + (v.peek === 'e' ? 'ember' : 'ash'); pk.textContent = U.t(v.peek === 'e' ? 'hud.peekEmber' : 'hud.peekAsh'); } else pk.className = 'peek hidden';
    const chips = []; if (v.cuffed.p) chips.push(U.t('status.boundYou')); if (v.cuffed.d) chips.push(U.t('status.boundDealer')); if (v.charged.p || v.charged.d) chips.push(U.t('status.charged'));
    $('status').innerHTML = chips.map((c) => '<span class="status">' + c + '</span>').join('');
    const n = st.p.items.filter(Boolean).length; $('btnInv').dataset.count = '(' + n + ')';
    if (!$('inventory').classList.contains('hidden')) UI.renderInventory();
  };
  UI.setPrompt = function (key) { $('prompt').textContent = key ? U.t(key) : ''; };
  UI.setAim = function (t) { UI.aim = t; UI.updateActions(); };
  UI.updateActions = function () {
    const T_ = T(); if (!T_) return; const can = T_.canAct(), aim = T_.aim;
    const set = (id, show, en) => { const b = $(id); b.classList.toggle('hidden', !show); b.disabled = !en; b.classList.toggle('off', !en); };
    set('btnAimD', aim !== 'opp', can); set('btnAimS', aim !== 'self', can); set('btnFire', !!aim, can && !!aim); set('btnLower', !!aim, can && !!aim);
    set('btnInspectGun', !aim, can); set('btnInv', true, can);
    if (!can) { UI.hideItemCard(); }
    if (T_.active && T_.st && T_.st.phase === 'play' && !T_.busy && !T_.paused && T_.st.turn === 'p') UI.setPrompt(aim ? 'hud.promptAimed' : 'hud.promptTurn'); else if (T_.busy || (T_.st && T_.st.turn === 'd')) UI.setPrompt(null);
  };

  /* ------------------------------------------------------------ item card + inventory */
  const itemInfo = (it) => ({ name: U.t('item.' + it.id), desc: U.t('item.' + it.id + '.d'), uses: it.uses > 1 ? U.t('item.uses', { n: it.uses }) : '' });
  UI.showItemCard = function (idx) {
    const st = T().st; const it = st && st.p.items[idx]; if (!it) return; UI.selSlot = idx;
    const inf = itemInfo(it); $('icImg').src = Art.icon(it.id, 96); $('icName').textContent = inf.name; $('icDesc').textContent = inf.desc; $('icUses').textContent = inf.uses;
    $('itemCard').classList.remove('hidden'); R.scene.selected = { who: 'p', idx };
    const ok = E.canUse(st, 'p', idx).ok; $('icUse').classList.toggle('off', !ok);
    $('icUse').onclick = () => { T().playerUse(idx); }; $('icInspect').onclick = () => { T().playerInspect(idx); };
    Au.sfx('tick', { vol: 0.8 });
  };
  UI.hideItemCard = function () { $('itemCard').classList.add('hidden'); if (R.scene) R.scene.selected = null; UI.selSlot = -1; };
  UI.renderInventory = function () {
    const st = T().st, grid = $('invGrid'); if (!st) return; grid.innerHTML = '';
    for (let i = 0; i < 6; i++) {
      const it = st.p.items[i], b = document.createElement('button'); b.className = 'islot' + (!it ? ' empty' : '') + (UI.selSlot === i ? ' sel' : '') + (it && !E.canUse(st, 'p', i).ok ? ' na' : '');
      if (it) { b.innerHTML = '<img alt="' + U.t('item.' + it.id) + '" src="' + Art.icon(it.id, 96) + '">' + (it.uses > 1 ? '<span class="q">x' + it.uses + '</span>' : ''); b.onclick = () => { UI.selSlot = i; UI.renderInventory(); Au.sfx('tick', { vol: 0.8 }); }; }
      else { b.disabled = true; b.setAttribute('aria-label', U.t('toast.slotEmpty')); }
      grid.appendChild(b);
    }
    const it = st.p.items[UI.selSlot];
    if (it) { const inf = itemInfo(it); $('invImg').src = Art.icon(it.id, 96); $('invImg').style.visibility = 'visible'; $('invName').textContent = inf.name; $('invDesc').textContent = inf.desc; $('invUses').textContent = inf.uses; $('invUse').disabled = false; $('invInspect').disabled = false; $('invUse').classList.toggle('off', !E.canUse(st, 'p', UI.selSlot).ok); }
    else { $('invImg').style.visibility = 'hidden'; $('invName').textContent = ''; $('invDesc').textContent = U.t('hud.promptTurn'); $('invUses').textContent = ''; $('invUse').disabled = true; $('invInspect').disabled = true; }
  };
  UI.openInventory = function () {
    if (!T().canAct()) { UI.toast(U.t(T().busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; }
    UI.hideItemCard(); const st = T().st; UI.selSlot = Math.max(0, st.p.items.findIndex(Boolean));
    const p = $('inventory'); p.classList.remove('hidden', 'closing'); UI.renderInventory(); if (G.Input) G.Input.enabled = false; G.Access.open(p); UI.invOpen = true;
  };
  UI.closeInventory = function (instant) {
    const p = $('inventory'); if (p.classList.contains('hidden')) return; UI.invOpen = false;
    const done = () => { p.classList.add('hidden'); p.classList.remove('closing'); if (!UI.modalStack.length && G.Input) G.Input.enabled = true; G.Access.close(p); };
    if (instant) done(); else { p.classList.add('closing'); setTimeout(done, 200); }
  };

  /* ------------------------------------------------------------ archive / achievements */
  UI.openArchive = function () {
    const g = $('archGrid'); g.innerHTML = ''; const m = G.Turns.meta;
    for (const id of D.itemOrder) {
      const known = !!m.discovered[id], c = document.createElement('div'); c.className = 'acard' + (known ? '' : ' unk');
      c.innerHTML = '<img alt="" src="' + (known ? Art.icon(id, 96) : Art.silhouette(96)) + '"><b>' + (known ? U.t('item.' + id) : '???') + '</b><span>' + (known ? U.t('item.' + id + '.d') : U.t('arch.unknown')) + '</span>';
      g.appendChild(c);
    }
    UI.open('mArchive');
  };
  const ACH_ICON = { first_light: '🕯', out_of_room: '🚪', untouched: '✦', thread: '≈', ash_walker: '☁', pack_rat: '❖', bare_hands: '✋', nightmare: '☠' };
  UI.openAch = function () {
    const l = $('achList'); l.innerHTML = ''; const m = G.Turns.meta;
    for (const id of D.achievements) { const d = document.createElement('div'); d.className = 'ach' + (m.ach[id] ? ' done' : ''); d.innerHTML = '<div class="ai">' + ACH_ICON[id] + '</div><div><b>' + U.t('ach.' + id) + '</b><span>' + U.t('ach.' + id + '.d') + '</span></div><div class="ck">' + (m.ach[id] ? '✓' : '') + '</div>'; l.appendChild(d); }
    UI.open('mAch');
  };

  /* ------------------------------------------------------------ endings */
  UI.showEnding = function (kind, data) {
    const card = document.querySelector('#mEnd .endcard'), box = $('endBtns'); box.innerHTML = ''; card.className = 'card endcard' + (kind === 'victory' ? ' victory' : '');
    const btn = (label, cls, fn) => { const b = document.createElement('button'); b.className = 'abtn ' + cls; b.textContent = U.t(label); b.onclick = fn; box.appendChild(b); return b; };
    const nm = $('endName'), un = $('endUnlock'); nm.textContent = ''; un.classList.add('hidden');
    if (kind === 'round') {
      $('endTitle').textContent = U.t('end.roundDone'); $('endSub').textContent = U.t('end.roundDoneS');
      btn('end.next', 'primary', () => { UI.close('mEnd'); T().nextRound(); }); btn('end.menu', '', () => { UI.close('mEnd'); T().toMenu(); });
    } else if (kind === 'victory') {
      $('endTitle').textContent = U.t('end.victory'); $('endSub').textContent = U.t('end.victoryS'); nm.textContent = U.t('end.ending', { n: U.t(data.untouched ? 'ending.untouched' : 'ending.survivor') });
      if (data.unlocked) { un.textContent = U.t('end.unlocked') + ' — ' + U.t('diff.nightmare'); un.classList.remove('hidden'); UI.toast(U.t('toast.unlock'), 'good'); }
      btn('end.replay', 'primary', () => { UI.close('mEnd'); T().toMenu(); UI.openDiff(); }); btn('end.credits', '', () => { UI.open('mCredits'); }); btn('end.menu', '', () => { UI.close('mEnd'); T().toMenu(); });
    } else {
      $('endTitle').textContent = U.t('end.defeat'); $('endSub').textContent = U.t('end.defeatS'); nm.textContent = U.t('end.ending', { n: U.t('ending.defeat') });
      btn('end.retry', 'primary', () => { UI.close('mEnd'); T().retryRound(); }); btn('end.replay', '', () => { UI.close('mEnd'); T().restartGame(); }); btn('end.menu', '', () => { UI.close('mEnd'); T().toMenu(); });
    }
    UI.open('mEnd'); UI.hideItemCard(); UI.closeInventory(true);
  };

  /* ------------------------------------------------------------ tutorial */
  UI.showTutorial = function (done) {
    let i = 1; const step = $('tutStep'), dots = $('tutDots'), next = $('tutNext');
    const render = () => { step.textContent = U.t('tut.' + i); dots.innerHTML = [1, 2, 3, 4].map((k) => '<i class="' + (k === i ? 'on' : '') + '"></i>').join(''); next.querySelector('span').textContent = U.t(i === 4 ? 'tut.go' : 'tut.next'); };
    const fin = () => { UI.close('mTut'); done && done(); };
    next.onclick = () => { if (i < 4) { i++; render(); } else fin(); }; $('tutSkip').onclick = fin;
    render(); UI.open('mTut');
  };

  /* ------------------------------------------------------------ transient messages */
  UI.toast = function (msg, kind) {
    const box = $('toasts'); const t = document.createElement('div'); t.className = 'toast ' + (kind || 'info'); t.textContent = msg; box.appendChild(t);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 2600);
  };
  UI.subtitle = function (text, dur, mood) {
    if (!G.Turns.settings || !G.Turns.settings.subtitles) return;
    const box = $('subtitles'); const d = document.createElement('div'); d.className = 'sub' + (mood === 'whisper' ? ' whisper' : ''); d.innerHTML = '<b>' + U.t('dealer.sub') + '</b>'; d.appendChild(document.createTextNode(text));
    box.innerHTML = ''; box.appendChild(d); clearTimeout(UI._subT); UI._subT = setTimeout(() => { if (d.parentNode) d.remove(); }, Math.max(1500, (dur || 2) * 1000));
  };
  UI.banner = function (title, sub) {
    const b = $('banner'); const n = b.cloneNode(true); n.classList.remove('hidden'); n.querySelector('#bTitle').textContent = title; n.querySelector('#bSub').textContent = sub && sub !== 'sub' ? sub : ''; if (sub === 'sub') { n.querySelector('#bTitle').style.fontSize = 'clamp(1.6rem,5vw,3rem)'; }
    b.parentNode.replaceChild(n, b); setTimeout(() => n.classList.add('hidden'), 2500);
  };

  /* ------------------------------------------------------------ orientation prompt */
  UI.checkOrientation = function () {
    const portrait = window.innerHeight > window.innerWidth * 1.05, rot = $('rotate'), t = T();
    if (portrait && t && t.active) { if (rot.classList.contains('hidden')) { rot.classList.remove('hidden'); UI._autoPaused = t.pause(true); } }
    else if (!rot.classList.contains('hidden')) { rot.classList.add('hidden'); if (UI._autoPaused && !UI.modalStack.includes('mPause')) t.resume(); UI._autoPaused = false; }
  };

  /* ------------------------------------------------------------ wiring */
  UI.init = function () {
    document.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { Au.unlock(); if (!b.classList.contains('tog')) Au.sfx(b.id === 'setBack' || b.hasAttribute('data-close') || b.id === 'confNo' ? 'ui_back' : 'ui_click', { vol: 0.8 }); } }, true);
    document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => { const m = b.closest('.modal'); if (m) UI.close(m.id); }));
    $('mNew').onclick = () => { if (Save.hasRun()) UI.confirm('confirm.newgame', () => { UI.close('mConfirm'); UI.openDiff(); }); else UI.openDiff(); };
    $('mContinue').onclick = () => { T().continueGame(); };
    $('mSettings').onclick = () => UI.openSettings('menu'); $('mArchive').onclick = UI.openArchive; $('mAch').onclick = UI.openAch;
    $('mCredits').onclick = () => UI.open('mCredits'); $('mLeave').onclick = () => UI.open('mLeave');
    $('mFull').onclick = () => { try { const d = document; if (!d.fullscreenElement) { (d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen).call(d.documentElement).then(() => { try { screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* ignore */ } }).catch(() => {}); } else d.exitFullscreen(); } catch (e) { /* unsupported */ } };
    $('btnPause').onclick = () => UI.openPause(); $('btnHelp').onclick = () => { if (!T().active) return; T().pause(); UI.showTutorial(() => { T().resume(); }); };
    $('btnInv').onclick = UI.openInventory; $('invClose').onclick = () => UI.closeInventory();
    $('invUse').onclick = () => { const i = UI.selSlot; UI.closeInventory(true); T().playerUse(i); };
    $('invInspect').onclick = () => { const i = UI.selSlot; UI.closeInventory(true); T().playerInspect(i); };
    $('icClose').onclick = () => UI.hideItemCard();
    $('btnAimD').onclick = () => T().playerAim('opp'); $('btnAimS').onclick = () => T().playerAim('self');
    $('btnFire').onclick = () => T().playerFire(); $('btnLower').onclick = () => T().playerLower(); $('btnInspectGun').onclick = () => T().playerInspectGun();
    G.Input.onTap = (hit) => {
      if (!T().active) return;
      if (!hit) { UI.hideItemCard(); return; }
      if (hit.kind === 'slot') { if (!T().canAct()) { UI.toast(U.t(T().busy ? 'toast.busy' : 'toast.notTurn'), 'info'); return; } UI.showItemCard(hit.idx); }
      else if (hit.kind === 'dealer' || hit.kind === 'gun') { if (T().canAct()) T().playerAim('opp'); }
    };
    G.Input.onKey = (e) => {
      const k = e.key; const t = T();
      if (k === 'Escape') { if (UI.invOpen) UI.closeInventory(); else if (UI.modalStack.includes('mPause')) UI.resumeGame(); else if (UI.modalStack.length) UI.close(UI.modalStack[UI.modalStack.length - 1]); else if (t.active) UI.openPause(); return; }
      if (!t.active || UI.modalStack.length || UI.invOpen) return;
      if (k >= '1' && k <= '6' && t.canAct()) UI.showItemCard(parseInt(k, 10) - 1);
      else if (k === 'a' || k === 'A') t.playerAim('opp'); else if (k === 's' || k === 'S') t.playerAim('self'); else if (k === 'Enter' || k === ' ') t.playerFire(); else if (k === 'l' || k === 'L') t.playerLower();
      else if (k === 'i' || k === 'I') UI.openInventory();
    };
    window.addEventListener('resize', () => { R.resize(); UI.checkOrientation(); }); window.addEventListener('orientationchange', () => setTimeout(() => { R.resize(); UI.checkOrientation(); }, 150));
  };

  G.UI = UI;
})(typeof window !== 'undefined' ? window : globalThis);
