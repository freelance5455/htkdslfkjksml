/* save-manager.js — settings, meta-progress (achievements, endings, archive) and run snapshots.
   Uses localStorage with full error handling; falls back to in-memory if storage is blocked.
   Limitations: localStorage is per-origin/per-browser, can be cleared by the user or by private-mode
   browsing, and is not synced between devices. No personal data is stored. */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData;
  const KEY = { settings: 'tallow.settings.v1', meta: 'tallow.meta.v1', run: 'tallow.run.v1' };
  const S = { mem: {}, corruptFlag: false };

  let ls = null;
  try { ls = G.localStorage; const k = '__tallow_probe'; ls.setItem(k, '1'); ls.removeItem(k); } catch (e) { ls = null; }
  S.available = !!ls;

  S.read = function (key) {
    let raw = null;
    try { raw = ls ? ls.getItem(key) : (S.mem[key] === undefined ? null : S.mem[key]); } catch (e) { raw = S.mem[key] === undefined ? null : S.mem[key]; }
    if (raw === null) return null;
    try { return JSON.parse(raw); } catch (e) { S.corruptFlag = true; S.remove(key); return null; }
  };
  S.write = function (key, obj) {
    let s;
    try { s = JSON.stringify(obj); } catch (e) { return false; }
    S.mem[key] = s;
    try { if (ls) ls.setItem(key, s); return !!ls; } catch (e) { return false; }
  };
  S.remove = function (key) { delete S.mem[key]; try { if (ls) ls.removeItem(key); } catch (e) { /* ignore */ } };

  /* ---------- settings ---------- */
  S.defaultSettings = function () {
    const nav = G.navigator || {};
    const weak = (nav.hardwareConcurrency && nav.hardwareConcurrency <= 4) || (nav.deviceMemory && nav.deviceMemory <= 2);
    let reduced = false;
    try { reduced = !!(G.matchMedia && G.matchMedia('(prefers-reduced-motion: reduce)').matches); } catch (e) { /* ignore */ }
    return {
      master: 0.8, music: 0.6, ambience: 0.7, sfx: 0.9, voice: 0.9,
      quality: weak ? 'low' : 'medium', fps: 60, shake: 1, effects: true, subtitles: true,
      textSize: 1, lang: (nav.language || 'en').toLowerCase().startsWith('ar') ? 'ar' : 'en',
      reduced, haptics: true, touch: 1.2
    };
  };
  const range = (v, a, b, d) => (typeof v === 'number' && isFinite(v) ? U.clamp(v, a, b) : d);
  S.sanitizeSettings = function (raw) {
    const d = S.defaultSettings();
    if (!raw || typeof raw !== 'object') return d;
    return {
      master: range(raw.master, 0, 1, d.master), music: range(raw.music, 0, 1, d.music), ambience: range(raw.ambience, 0, 1, d.ambience),
      sfx: range(raw.sfx, 0, 1, d.sfx), voice: range(raw.voice, 0, 1, d.voice),
      quality: ['low', 'medium', 'high'].includes(raw.quality) ? raw.quality : d.quality,
      fps: raw.fps === 30 ? 30 : 60, shake: range(raw.shake, 0, 1, d.shake),
      effects: typeof raw.effects === 'boolean' ? raw.effects : d.effects,
      subtitles: typeof raw.subtitles === 'boolean' ? raw.subtitles : d.subtitles,
      textSize: [0, 1, 2].includes(raw.textSize) ? raw.textSize : d.textSize,
      lang: raw.lang === 'ar' ? 'ar' : 'en',
      reduced: typeof raw.reduced === 'boolean' ? raw.reduced : d.reduced,
      haptics: typeof raw.haptics === 'boolean' ? raw.haptics : d.haptics,
      touch: range(raw.touch, 0.8, 1.8, d.touch)
    };
  };
  S.loadSettings = function () { return S.sanitizeSettings(S.read(KEY.settings)); };
  S.saveSettings = function (s) { return S.write(KEY.settings, s); };

  /* ---------- meta progress ---------- */
  S.defaultMeta = function () {
    return { ach: {}, endings: {}, discovered: {}, unlocked: { nightmare: false }, stats: { games: 0, wins: 0, rounds: 0 }, tutorial: false, lastDiff: 'normal' };
  };
  S.sanitizeMeta = function (raw) {
    const d = S.defaultMeta();
    if (!raw || typeof raw !== 'object') return d;
    const pick = (o, keys) => { const r = {}; if (o && typeof o === 'object') for (const k of keys) if (o[k]) r[k] = 1; return r; };
    d.ach = pick(raw.ach, D.achievements);
    d.endings = pick(raw.endings, D.endings);
    d.discovered = pick(raw.discovered, D.itemOrder);
    d.unlocked.nightmare = !!(raw.unlocked && raw.unlocked.nightmare);
    if (raw.stats) for (const k of ['games', 'wins', 'rounds']) d.stats[k] = range(raw.stats[k], 0, 1e6, 0);
    d.tutorial = !!raw.tutorial;
    d.lastDiff = D.difficulties[raw.lastDiff] ? raw.lastDiff : 'normal';
    return d;
  };
  S.loadMeta = function () { return S.sanitizeMeta(S.read(KEY.meta)); };
  S.saveMeta = function (m) { return S.write(KEY.meta, m); };

  /* ---------- run snapshot (resume) ---------- */
  let pending = null, timer = null;
  S.queueRun = function (state) {
    try { pending = JSON.stringify({ v: 1, t: Date.now(), state }); } catch (e) { return; }
    if (timer) return;
    // Deferred so saving never lands inside an animation frame.
    timer = setTimeout(() => { timer = null; S.flushRun(); }, 60);
  };
  S.flushRun = function () {
    if (pending === null) return true;
    const s = pending; pending = null; S.mem[KEY.run] = s;
    try { if (ls) ls.setItem(KEY.run, s); return true; } catch (e) { return false; }
  };
  S.loadRun = function () {
    const raw = S.read(KEY.run);
    if (!raw) return null;
    if (!raw.state || !G.Engine.validate(raw.state) || raw.state.phase === 'lost' || raw.state.phase === 'won') {
      S.corruptFlag = S.corruptFlag || !G.Engine.validate(raw.state);
      S.remove(KEY.run); return null;
    }
    return raw.state;
  };
  S.hasRun = function () { return !!S.loadRun(); };
  S.clearRun = function () { pending = null; S.remove(KEY.run); };

  G.Save = S;
  if (typeof module !== 'undefined' && module.exports) module.exports = S;
})(typeof window !== 'undefined' ? window : globalThis);
