/* input-manager.js — unified touch/mouse/keyboard input. Single primary pointer, tap-slop detection, hotspot hit-testing in
   logical space, pinch/zoom/double-tap suppression, context-menu suppression, keyboard shortcuts for desktop testing. */
(function (G) {
  'use strict';
  const In = { enabled: true, down: null, onTap: null, onKey: null, taps: 0 };
  In.init = function (canvas) {
    const R = G.Renderer;
    canvas.addEventListener('pointerdown', (e) => {
      if (e.isPrimary === false || !In.enabled) return;
      try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
      if (G.AudioMgr) G.AudioMgr.unlock();
      In.down = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now() };
      e.preventDefault();
    }, { passive: false });
    canvas.addEventListener('pointermove', (e) => { // drag to look around (3D view); tiny movements stay taps
      const d = In.down; if (!d || d.id !== e.pointerId || !In.enabled || !R.use3d) return;
      const set = (G.Turns && G.Turns.settings) || {}, dx = e.clientX - d.x, dy = e.clientY - d.y, slop = Math.max(14, Math.min(window.innerWidth, window.innerHeight) * 0.03);
      if (dx * dx + dy * dy < slop * slop && !d.drag) return;
      d.drag = true; R.lookHold = true; const k = (set.sens === undefined ? 1 : set.sens) * 1.4;
      R.lookX = Math.max(-0.35, Math.min(0.35, dx / window.innerWidth * k)); R.lookY = Math.max(-0.3, Math.min(0.3, -dy / window.innerHeight * k));
    });
    canvas.addEventListener('pointerup', (e) => {
      R.lookHold = false;
      const d = In.down; In.down = null; if (!d || d.id !== e.pointerId || !In.enabled) return;
      if (d.drag) return;
      const dx = e.clientX - d.x, dy = e.clientY - d.y, slop = Math.max(14, Math.min(window.innerWidth, window.innerHeight) * 0.03);
      if (dx * dx + dy * dy > slop * slop || performance.now() - d.t > 900) return;
      const p = R.toLogical(e.clientX, e.clientY);
      const T = G.Turns, set = T.settings || {};
      const hits = G.Show.hotspots(T.active && !T.paused, set.touch);
      let best = null, bd = 1e9;
      for (const h of hits) { const dd = Math.hypot(h.x - p.x, h.y - p.y); if (dd <= h.r && (h.kind === 'slot' ? dd - 1000 : dd) < bd) { best = h; bd = h.kind === 'slot' ? dd - 1000 : dd; } }
      In.taps++;
      if (In.onTap) In.onTap(best, p);
    });
    canvas.addEventListener('pointercancel', () => { In.down = null; R.lookHold = false; });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    // no accidental zoom (iOS gestures, double-tap, ctrl+wheel)
    for (const ev of ['gesturestart', 'gesturechange', 'gestureend']) document.addEventListener(ev, (e) => e.preventDefault());
    document.addEventListener('dblclick', (e) => e.preventDefault());
    document.addEventListener('touchmove', (e) => { if (e.touches && e.touches.length > 1) e.preventDefault(); }, { passive: false });
    document.addEventListener('wheel', (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });
    window.addEventListener('keydown', (e) => { if (In.onKey && !e.repeat) In.onKey(e); });
  };
  G.Input = In;
})(typeof window !== 'undefined' ? window : globalThis);
