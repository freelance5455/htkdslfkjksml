/* orientation.js — landscape-only enforcement (loaded first, before any game script).
   Layers, strongest first:
   1. Native lock:   web manifest (orientation: landscape) + Screen Orientation API lock('landscape'), retried on load,
                     on the first touch (together with immersive fullscreen) and whenever fullscreen / visibility changes.
   2. Hard fallback: if the browser refuses to lock (iOS Safari, Chrome outside fullscreen, in-app browsers) and the device
                     is physically held upright, the whole #app is rotated 90° so the game is STILL drawn in landscape.
                     No "please rotate" screen is ever shown; touch coordinates are mapped back (Orient.toApp).
   Also publishes the *effective* landscape size / safe-area insets for the rest of the code (Orient.size()). */
(function (G) {
  'use strict';
  const doc = G.document, de = doc.documentElement;
  const Orient = { forced: false, userExit: false, locked: false };

  Orient.size = function () { // effective (landscape) layout size in CSS px
    const w = G.innerWidth, h = G.innerHeight;
    return Orient.forced ? { w: h, h: w } : { w, h };
  };

  /* viewport (client) coordinates -> coordinates inside #app's own landscape frame */
  Orient.toApp = function (x, y) {
    return Orient.forced ? { x: y, y: G.innerWidth - x } : { x, y };
  };
  /* a client-space delta (drag) -> app-space delta */
  Orient.deltaToApp = function (dx, dy) { return Orient.forced ? { x: dy, y: -dx } : { x: dx, y: dy }; };

  /* ---------------------------------------------------------------- native lock */
  Orient.lock = function () {
    try {
      const so = G.screen && G.screen.orientation;
      if (so && so.lock) { const p = so.lock('landscape'); if (p && p.then) p.then(() => { Orient.locked = true; Orient.update(); }, () => { Orient.locked = false; }); return; }
    } catch (e) { /* unsupported -> CSS fallback below */ }
    try { const s = G.screen, f = s && (s.lockOrientation || s.mozLockOrientation || s.msLockOrientation); if (f) f.call(s, 'landscape'); } catch (e) { /* ignore */ }
  };

  const isFs = () => !!(doc.fullscreenElement || doc.webkitFullscreenElement);
  Orient.enterFullscreen = function () {
    const el = de, req = el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen; if (!req) { Orient.lock(); return; }
    let p; try { p = req.call(el, { navigationUI: 'hide' }); } catch (e) { try { p = req.call(el); } catch (e2) { /* ignore */ } }
    const after = () => { Orient.lock(); setTimeout(Orient.update, 120); };
    if (p && p.then) p.then(after, () => Orient.lock()); else after();
  };
  Orient.exitFullscreen = function () { const x = doc.exitFullscreen || doc.webkitExitFullscreen; try { if (x) x.call(doc); } catch (e) { /* ignore */ } };
  Orient.toggleFullscreen = function () { // used by the menu / settings buttons
    if (isFs()) { Orient.userExit = true; Orient.exitFullscreen(); } else { Orient.userExit = false; Orient.enterFullscreen(); }
  };

  /* first touch on a phone/tablet: go immersive-fullscreen + lock landscape (browsers only allow this from a user gesture) */
  const touchy = () => (G.matchMedia && G.matchMedia('(pointer: coarse)').matches) || 'ontouchstart' in G;
  function gesture() { if (touchy() && !isFs() && !Orient.userExit) Orient.enterFullscreen(); else if (!Orient.locked) Orient.lock(); }
  for (const ev of ['pointerup', 'touchend', 'click', 'keydown']) doc.addEventListener(ev, gesture, { capture: true, passive: true });
  doc.addEventListener('fullscreenchange', () => { if (isFs()) Orient.lock(); setTimeout(Orient.update, 100); });
  doc.addEventListener('webkitfullscreenchange', () => { if (isFs()) Orient.lock(); setTimeout(Orient.update, 100); });
  doc.addEventListener('visibilitychange', () => { if (!doc.hidden) { Orient.lock(); setTimeout(Orient.update, 100); } });

  /* ---------------------------------------------------------------- hard fallback: rotate the app frame */
  let probe = null;
  function insets() { // real safe-area insets in viewport terms
    if (!probe) { probe = doc.createElement('div'); probe.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)'; doc.body.appendChild(probe); }
    const cs = G.getComputedStyle(probe); return { t: parseFloat(cs.paddingTop) || 0, r: parseFloat(cs.paddingRight) || 0, b: parseFloat(cs.paddingBottom) || 0, l: parseFloat(cs.paddingLeft) || 0 };
  }
  Orient.update = function () {
    const app = doc.getElementById('app'); if (!app) return;
    const W = G.innerWidth, H = G.innerHeight, portrait = H > W, st = app.style;
    Orient.forced = portrait;
    de.classList.toggle('force-landscape', portrait);
    if (portrait) {
      const ins = insets();
      // app frame is H wide x W tall, turned 90° clockwise so its top edge sits at the phone's right-hand side
      st.width = H + 'px'; st.height = W + 'px'; st.left = '0'; st.top = '0'; st.right = 'auto'; st.bottom = 'auto'; st.transformOrigin = '0 0'; st.transform = 'translate(' + W + 'px,0) rotate(90deg)';
      st.setProperty('--vw', (H / 100) + 'px'); st.setProperty('--vh', (W / 100) + 'px');
      st.setProperty('--sat', ins.r + 'px'); st.setProperty('--sar', ins.b + 'px'); st.setProperty('--sab', ins.l + 'px'); st.setProperty('--sal', ins.t + 'px');
    } else {
      for (const p of ['width', 'height', 'left', 'top', 'right', 'bottom', 'transformOrigin', 'transform']) st[p] = '';
      for (const p of ['--vw', '--vh', '--sat', '--sar', '--sab', '--sal']) st.removeProperty(p);
    }
  };

  G.addEventListener('resize', Orient.update);
  G.addEventListener('orientationchange', () => { Orient.lock(); setTimeout(Orient.update, 60); setTimeout(Orient.update, 300); });
  try { if (G.screen && G.screen.orientation && G.screen.orientation.addEventListener) G.screen.orientation.addEventListener('change', () => setTimeout(Orient.update, 60)); } catch (e) { /* ignore */ }
  if (G.visualViewport) G.visualViewport.addEventListener('resize', Orient.update);

  Orient.lock(); Orient.update();
  G.Orient = Orient;
})(typeof window !== 'undefined' ? window : globalThis);
