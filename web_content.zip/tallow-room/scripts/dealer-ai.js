/* dealer-ai.js — decision logic only. Reads *resolved* game state (never animation state).
   The Dealer knows: public shell counts, his own peeks, both inventories (items are on the table). */
(function (G) {
  'use strict';
  const U = G.U, D = G.GameData, E = G.Engine, R = U.Rand;
  const AI = {};

  AI.decide = function (st, who) {
    who = who || 'd';
    const df = D.difficulties[st.diff], s = df.skill;
    const me = st[who], op = st[E.opp(who)], info = E.infoFor(st, who);
    const rnd = () => R.next(st);
    const pe = info.peek, total = info.total;
    const pEmber = pe ? (pe === 'e' ? 1 : 0) : (total ? info.ember / total : 0);
    const find = (id) => {
      const i = me.items.findIndex((x) => x && x.id === id);
      return i >= 0 && E.canUse(st, who, i).ok ? i : -1;
    };
    const act = (i) => ({ type: 'item', idx: i });
    let i;

    // Weaker difficulties sometimes skip the clever play entirely.
    if (rnd() < 0.35 + 0.65 * s) {
      if (me.hp < me.max && (i = find('cigarette')) >= 0) return act(i);
      if (me.hp <= me.max - 2 && me.hp > 1 && (i = find('medicine')) >= 0 && rnd() < s) return act(i);
      if (pe === null && total > 1 && (i = find('magnifier')) >= 0) return act(i);
      if (!op.cuffed && pEmber >= 0.5 && (i = find('handcuffs')) >= 0) return act(i);
      if (!me.charged && pEmber >= 0.5 && (pe === 'e' || rnd() < 0.5) && (i = find('battery')) >= 0) return act(i);
      if (pe === null && total > 1 && pEmber > 0.34 && pEmber < 0.67 && (i = find('can')) >= 0) return act(i);
      if (op.items.some((x) => x) && rnd() < 0.7 && (i = find('lighter')) >= 0) return act(i);
      if (pe === null && total > 2 && rnd() < 0.25 * s + 0.1 && (i = find('scrambler')) >= 0) return act(i);
      if (rnd() < 0.6 && (i = find('coin')) >= 0) return act(i);
    }

    let target;
    if (pe === 'e') target = 'opp';
    else if (pe === 'a') target = 'self';        // known ash: free extra turn
    else if (pEmber === 0) target = 'self';
    else if (pEmber === 1) target = 'opp';
    else target = pEmber >= 0.5 ? 'opp' : 'self';
    if (rnd() > 0.5 + 0.5 * s) target = rnd() < 0.5 ? 'opp' : 'self'; // mistakes at low skill
    return { type: 'shoot', target };
  };

  G.DealerAI = AI;
  if (typeof module !== 'undefined' && module.exports) module.exports = AI;
})(typeof window !== 'undefined' ? window : globalThis);
