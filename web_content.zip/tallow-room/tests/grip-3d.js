/* renders the gun held by the player and by the dealer (software WebGL) and prints grip/IK measurements */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = []; await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium' })); } catch (e) {} });
  p.on('console', m => { if (m.type() !== 'log') logs.push(m.type() + ': ' + m.text()); }); p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300);
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); }); await p.waitForTimeout(500);
  for (const who of ['p', 'd']) {
    await p.evaluate((w) => { clearInterval(window.__gh); window.__gh = setInterval(() => { window.Renderer.scene.gunHolder = w; }, 8); }, who); await p.waitForTimeout(1800);
    const m = await p.evaluate(() => { const S = window.Stage3D, gi = S.gunInfo; return JSON.stringify({ gunRoll: S.gunRoll.toFixed(2), muzzle: gi.muzzle.map(v => +v.toFixed(2)), wrist: window.Renderer.handWrist }); });
    console.log(who, m); await p.screenshot({ path: '/tmp/claude-0/shots/grip_' + who + '.png', timeout: 120000 });
  }
  console.log(logs.slice(0, 10).join('\n') || 'no console warnings/errors');
  await b.close();
})();
