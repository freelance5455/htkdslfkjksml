const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const out = []; const ok = (n, c, x) => { out.push((c ? 'PASS ' : 'FAIL ') + n + (x ? ' ' + x : '')); };
  const mk = async (vp, init, br) => { const ctx = await (br || b).newContext({ viewport: vp, hasTouch: true, isMobile: true }); const p = await ctx.newPage(); p.errs = [];
    p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') p.errs.push(m.text()); }); p.on('pageerror', e => p.errs.push('PAGEERROR ' + e.message));
    if (init) await p.addInitScript(init); else await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ three: false })); } catch (e) {} }); await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(1000); return p; };
  const ev = (p, f, a) => p.evaluate(f, a); const click = (p, id) => ev(p, i => document.getElementById(i).click(), id);
  const vis = (p, id) => ev(p, i => { const e = document.getElementById(i); return !!e && !e.classList.contains('hidden') && e.offsetParent !== null; }, id);
  const start = async p => { await click(p, 'mNew'); await p.waitForTimeout(300); await ev(p, () => document.querySelector('#diffList button').click()); await p.waitForTimeout(800); for (let i = 0; i < 8 && await vis(p, 'mTut'); i++) { await click(p, 'tutNext'); await p.waitForTimeout(200); } await p.waitForTimeout(2500); };
  // 1 main + save/resume + pause + settings
  let p = await mk({ width: 915, height: 412 });
  ok('continue disabled with no save', await ev(p, () => document.getElementById('mContinue').disabled));
  await start(p);
  ok('game active', await ev(p, () => !!window.__tallow.state && window.__tallow.state.phase === 'play'), await ev(p, () => window.__tallow.state && window.__tallow.state.phase));
  const snap = await ev(p, () => JSON.stringify({ r: window.__tallow.state.round, e: window.__tallow.state.p.hp }));
  await click(p, 'btnPause'); await p.waitForTimeout(400); ok('pause opens', await vis(p, 'mPause'));
  const f1 = await ev(p, () => window.__tallow.stats().frames); await p.waitForTimeout(500); await p.screenshot({ path: '/tmp/claude-0/shots/pause.png', timeout: 120000 });
  await click(p, 'pSet'); await p.waitForTimeout(400); ok('settings opens from pause', await vis(p, 'mSet'));
  await p.screenshot({ path: '/tmp/claude-0/shots/settings.png', timeout: 120000 });
  const nset = await ev(p, () => document.querySelectorAll('#setBody input, #setBody button, #setBody select').length); ok('settings has controls', nset > 12, nset);
  await ev(p, () => { const r = document.querySelector("#setBody input[type=range]"); if (!r) return; r.value = r.max; r.dispatchEvent(new Event('input', { bubbles: true })); r.dispatchEvent(new Event('change', { bubbles: true })); });
  await click(p, 'setBack'); await p.waitForTimeout(300);
  await click(p, 'pMenu'); await p.waitForTimeout(300); if (await vis(p, 'mConfirm')) await click(p, 'confYes'); await p.waitForTimeout(800);
  ok('menu after leave', await vis(p, 'menu'));
  ok('continue enabled after save', await ev(p, () => !document.getElementById('mContinue').disabled));
  await p.reload(); await p.waitForTimeout(1000);
  ok('continue persists after reload', await ev(p, () => !document.getElementById('mContinue').disabled));
  await click(p, 'mContinue'); await p.waitForFunction(() => window.__tallow && window.__tallow.state, null, { timeout: 60000 }); await p.waitForTimeout(500);
  const snap2 = await ev(p, () => JSON.stringify({ r: window.__tallow.state.round, e: window.__tallow.state.p.hp }));
  ok('resume restores state', snap === snap2, snap + ' vs ' + snap2);
  // panels
  await click(p, 'pMenu').catch(() => {});
  ok('no errors main', p.errs.length === 0, p.errs.slice(0, 3).join(' | '));
  // 2 menu screens
  p = await mk({ width: 915, height: 412 });
  for (const [btn, mod] of [['bArchive', 'mArchive'], ['bAch', 'mAch'], ['bCredits', 'mCredits'], ['mSettings', 'mSet']]) { await click(p, btn); await p.waitForTimeout(350); ok('open ' + mod, await vis(p, mod)); await p.screenshot({ path: `/tmp/claude-0/shots/${mod}.png`, timeout: 120000 }); await ev(p, () => { const m = Array.from(document.querySelectorAll('.modal:not(.hidden)')).pop(); const bk = m && m.querySelector('[data-close], .back, #setBack'); if (bk) bk.click(); }); await p.waitForTimeout(300); }
  // arabic
  await ev(p, () => { const s = JSON.parse(localStorage.getItem('tallow.settings.v1') || '{}'); }); 
  ok('no errors menus', p.errs.length === 0, p.errs.slice(0, 3).join(' | '));
  // 3 portrait
  p = await mk({ width: 915, height: 412 }); await start(p); await p.setViewportSize({ width: 412, height: 915 }); await p.waitForTimeout(800); ok('portrait rotate overlay + auto-pause', await vis(p, 'rotate') && await ev(p, () => window.Turns.paused)); await p.setViewportSize({ width: 915, height: 412 }); await p.waitForTimeout(800); ok('landscape resumes', !(await vis(p, 'rotate')) && !(await ev(p, () => window.Turns.paused))); await p.screenshot({ path: '/tmp/claude-0/shots/portrait.png', timeout: 120000 });
  // 4 low quality + 30fps + reduced
  p = await mk({ width: 915, height: 412 }, () => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'low', fps: 30, reduced: true, lang: 'ar', three: false })); } catch (e) {} });
  await start(p); await p.waitForTimeout(1000);
  const dir = await ev(p, () => document.documentElement.dir + '/' + document.documentElement.lang); await p.screenshot({ path: '/tmp/claude-0/shots/ar_low.png', timeout: 120000 });
  await p.waitForTimeout(2000); const fm = await ev(p, () => { const a = window.__tallow.Main.frameMs.slice(-40); return Math.min.apply(null, a); });
  ok('30fps cap: min frame interval >= 30ms', fm >= 30, 'min=' + fm.toFixed(1) + 'ms dir=' + dir + ' reducedClass=' + await ev(p, () => document.documentElement.classList.contains('reduced')));
  ok('no errors low/ar', p.errs.length === 0, p.errs.slice(0, 3).join(' | '));
  // 6 shop + tabs + new items
  p = await mk({ width: 915, height: 412 }, () => { try { localStorage.setItem('tallow.meta.v1', JSON.stringify({ coins: 200, stock: {} })); localStorage.setItem('tallow.settings.v1', JSON.stringify({ three: false })); } catch (e) {} });
  await click(p, 'bShop'); await p.waitForTimeout(300); ok('shop opens', await vis(p, 'mShop'));
  const cards = await ev(p, () => document.querySelectorAll('#shopGrid .acard').length); ok('shop lists every item', cards === 13, cards);
  await ev(p, () => document.querySelector('#shopGrid .buy').click()); await p.waitForTimeout(300);
  ok('buying spends Wax and adds stock', await ev(p, () => window.Turns.meta.coins < 200 && Object.keys(window.Turns.meta.stock).length === 1));
  await ev(p, () => document.querySelector('#mShop [data-close]').click()); await start(p);
  const bonus = await ev(p, () => window.__tallow.state.p.items.filter(Boolean).length); ok('new game consumes owned stock into the first deal', await ev(p, () => Object.keys(window.Turns.meta.stock).length === 0), 'items=' + bonus);
  await click(p, 'btnPause'); await p.waitForTimeout(300); await click(p, 'pSet'); await p.waitForTimeout(300);
  ok('settings has 4 tabs', await ev(p, () => document.querySelectorAll('#setBody .tabs button').length === 4));
  await ev(p, () => document.querySelectorAll('#setBody .tabs button')[3].click()); await p.waitForTimeout(200);
  ok('controls tab has sensitivity slider', await ev(p, () => !!document.getElementById('set_sens')));
  await ev(p, () => { const r = document.getElementById('set_sens'); r.value = 1.7; r.dispatchEvent(new Event('input', { bubbles: true })); }); ok('sensitivity setting is stored', await ev(p, () => window.Turns.settings.sens > 1.6));
  ok('no errors shop/tabs', p.errs.length === 0, p.errs.slice(0, 3).join(' | '));
  // 7 real 3D render (software WebGL)
  const b3 = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  p = await mk({ width: 915, height: 412 }, () => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ three: true, quality: 'low' })); } catch (e) {} }, b3);
  await p.waitForTimeout(2500); await start(p); await p.waitForTimeout(3000);
  const g3 = await ev(p, () => ({ ok: window.GL3D.ok, use: window.Renderer.use3d, draws: window.GL3D.stats.draws, tris: window.GL3D.stats.tris }));
  ok('WebGL 3D scene renders (draws>100, tris>10k)', g3.ok && g3.use && g3.draws > 100 && g3.tris > 10000, JSON.stringify(g3));
  const cam = await ev(p, () => { const C = window.Stage3D.Cam, q = C.project(C.onY(700, 560, 0.9)); return Math.abs(q.x - 700) < 1 && Math.abs(q.y - 560) < 1; }); ok('camera ray/project round-trip is exact', cam);
  await start(p); await ev(p, () => window.UI.subtitle('Test line', 6, 'normal')); await p.waitForTimeout(600);
  const sub = await ev(p, () => { const b = document.getElementById('subtitles').getBoundingClientRect(), a = window.Renderer.dealerAnchor, v = window.Renderer.view; return { top: b.top, ay: (v.oy + a.y * v.fs) * v.cw / v.pw, h: window.innerHeight }; });
  ok('subtitle sits directly under the Dealer head', sub.top >= sub.ay - 2 && sub.top <= sub.ay + 40, JSON.stringify(sub));
  ok('no errors 3D', p.errs.length === 0, p.errs.slice(0, 3).join(' | '));
  // 5 audio render test
  p = await mk({ width: 915, height: 412 });
  const names = await ev(p, () => Object.keys(window.AudioMgr.SFX)); const bad = [];
  for (const n of names) { const r = await ev(p, async n => { try { return await window.AudioMgr.renderTest(n); } catch (e) { return { err: String(e) }; } }, n); if (!r || r.err || !(r.peak > 0.005) || r.peak > 1.5 || !isFinite(r.rms)) bad.push(n + ':' + JSON.stringify(r)); }
  ok('all ' + names.length + ' sfx render audible & finite', bad.length === 0, bad.slice(0, 5).join(' '));
  console.log(out.join('\n')); await b3.close(); await b.close();
})();
