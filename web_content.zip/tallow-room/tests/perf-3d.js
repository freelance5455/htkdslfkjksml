/* leak + budget check for the 3D layer: GL object creation must stop after start-up; reports draws/tris/frame time (software GL, so times are only relative) */
const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const errs = [];
  await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ quality: 'medium' })); } catch (e) {} window.__gl = { buf: 0, tex: 0, fbo: 0, prog: 0 };
    const P = WebGLRenderingContext.prototype; for (const [fn, k] of [['createBuffer', 'buf'], ['createTexture', 'tex'], ['createFramebuffer', 'fbo'], ['createProgram', 'prog']]) { const o = P[fn]; P[fn] = function () { window.__gl[k]++; return o.apply(this, arguments); }; } });
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errs.push(m.text()); }); p.on('pageerror', e => errs.push('PAGEERROR ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(2500);
  await p.evaluate(() => document.getElementById('mNew').click()); await p.waitForTimeout(300); await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(2500);
  await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find(x => /skip/i.test(x.textContent) && x.offsetParent); if (b) b.click(); });
  const a1 = await p.evaluate(() => JSON.stringify(window.__gl)); await p.waitForTimeout(6000);
  const a2 = await p.evaluate(() => JSON.stringify(window.__gl));
  await p.waitForTimeout(8000);
  const au = await p.evaluate(() => { const A = AudioMgr; A.sfx('gun_fire'); A.sfx('gun_fire', { delay: 0.2 }); const sp = A.speak('Welcome back. The chair remembers you.', 'normal'); return JSON.stringify({ state: A.ctxState && A.ctxState(), baked: A.bakedCount(), total: Object.keys(A.SFX).length, dur: sp }); });
  await p.waitForTimeout(1500); const au2 = await p.evaluate(() => JSON.stringify({ voiceCached: AudioMgr.voiceCached(), played: AudioMgr.stats, bakedUses: AudioMgr.stats.baked }));
  console.log('audio', au, au2);
  await p.waitForFunction(() => AudioMgr.bakedCount() >= 59, null, { timeout: 60000 }).catch(() => {}); const w0 = await p.evaluate(() => [Renderer.stats.frames, Renderer.stats.drawMs]); await p.waitForTimeout(4000); const w1 = await p.evaluate(() => [Renderer.stats.frames, Renderer.stats.drawMs]); console.log('steady-state CPU ms/frame (software GL, after audio baking):', ((w1[1] - w0[1]) / Math.max(1, w1[0] - w0[0])).toFixed(1), 'frames in 4 s:', w1[0] - w0[0]);
  const st = await p.evaluate(() => JSON.stringify({ draws: GL3D.stats.draws, tris: GL3D.stats.tris, frames: Renderer.stats.frames, ms: (Renderer.stats.drawMs / Math.max(1, Renderer.stats.frames)).toFixed(1), bodies: Physics.bodies.length, auto: Renderer.auto, px: Renderer.view.pw + 'x' + Renderer.view.ph, maxUniformVec: GL3D.gl.getParameter(GL3D.gl.MAX_VERTEX_UNIFORM_VECTORS) }));
  console.log('GL objects after start-up:', a1, ' 6 s later:', a2, a1 === a2 ? 'PASS no growth' : 'FAIL growth'); console.log('stats', st); console.log(errs.length ? 'ERRORS ' + errs.slice(0, 5).join('\n') : 'PASS no console errors/warnings');
  await b.close(); process.exit(a1 === a2 && !errs.length ? 0 : 1);
})();
