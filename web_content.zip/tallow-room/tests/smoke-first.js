const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  const p = await ctx.newPage();
  const logs = [];
  p.on('console', m => logs.push(m.type() + ': ' + m.text()));
  p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  await p.goto('file://' + process.cwd() + '/index.html');
  await p.waitForTimeout(2500);
  await p.screenshot({ path: '/tmp/claude-0/shots/menu.png' });
  console.log(logs.join('\n') || 'no console output');
  await b.close();
})();
