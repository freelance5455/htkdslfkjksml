/* Node test-suite for the pure-logic layer (rules engine, AI, save validation, animation manifest, audio manifest).
   Run:  node tests/logic.test.js */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..');
const ctx = { console, setTimeout, clearTimeout, Date, Math, JSON };
ctx.window = ctx; vm.createContext(ctx);
function load(rel) { vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel }); }
['scripts/util.js', 'data/game-data.js', 'scripts/game-state.js', 'scripts/dealer-ai.js', 'scripts/save-manager.js'].forEach(load);
const optional = ['data/animations.js', 'scripts/audio-manager.js'];
optional.forEach((f) => { if (fs.existsSync(path.join(root, f))) { try { load(f); } catch (e) { console.log('LOAD FAIL', f, e.message); process.exitCode = 1; } } });

const { Engine: E, DealerAI: AI, GameData: D, U } = ctx;
let pass = 0, fail = 0;
function ok(c, m) { if (c) { pass++; } else { fail++; console.log('  FAIL:', m); } }
function section(n) { console.log('\n# ' + n); }

section('Engine: determinism');
{
  const a = E.newGame('normal', 1234), b = E.newGame('normal', 1234);
  E.startRound(a); E.startRound(b);
  ok(JSON.stringify(a) === JSON.stringify(b), 'same seed gives identical round setup');
  const c = E.newGame('normal', 99); E.startRound(c);
  ok(JSON.stringify(a.chamber) !== JSON.stringify(c.chamber) || a.p.items.map(x => x && x.id).join() !== c.p.items.map(x => x && x.id).join(), 'different seed differs');
}

section('Engine: rules');
{
  const st = E.newGame('normal', 5); E.startRound(st);
  ok(st.phase === 'play' && st.turn === 'p', 'round starts on player turn');
  ok(st.chamber.length >= 3 && st.loaded.e >= 1 && st.loaded.a >= 1, 'chamber has both shell types');
  ok(st.p.items.filter(Boolean).length === 2, 'round 1 deals 2 items');
  // not your turn
  ok(!E.apply(st, 'd', { type: 'shoot', target: 'opp' }).ok, 'dealer cannot act on player turn');
  // fake chamber to test shot rules
  st.chamber = ['a', 'e', 'e']; st.pub = { e: 2, a: 1 };
  let r = E.apply(st, 'p', { type: 'shoot', target: 'self' });
  ok(r.ok && st.turn === 'p', 'self-shot with ash keeps the turn');
  r = E.apply(st, 'p', { type: 'shoot', target: 'self' });
  ok(r.ok && st.p.hp === st.p.max - 1 && st.turn === 'd', 'self-shot with ember hurts and passes turn');
  st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 };
  r = E.apply(st, 'd', { type: 'shoot', target: 'opp' });
  ok(st.p.hp === st.p.max - 2 && st.turn === 'p', 'dealer hits player and passes turn');
  // cuffs
  st.d.cuffed = true; st.chamber = ['a', 'e']; st.pub = { e: 1, a: 1 };
  r = E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(r.ev.some(e => e.t === 'skip') && st.turn === 'p' && !st.d.cuffed, 'cuffed dealer loses exactly one turn');
  // charge doubles
  st.p.hp = st.p.max; st.d.hp = st.d.max; st.p.charged = true; st.chamber = ['e', 'a']; st.pub = { e: 1, a: 1 };
  E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(st.d.hp === st.d.max - 2 && !st.p.charged, 'charged ember deals 2 and charge is consumed');
  // reload when empty
  st.turn = 'p'; st.chamber = ['a']; st.pub = { e: 0, a: 1 };
  r = E.apply(st, 'p', { type: 'shoot', target: 'opp' });
  ok(r.ev.some(e => e.t === 'reload') && st.chamber.length > 0, 'empty chamber triggers reload');
  // kill
  const k = E.newGame('normal', 7); E.startRound(k); k.d.hp = 1; k.chamber = ['e', 'a']; k.pub = { e: 1, a: 1 };
  r = E.apply(k, 'p', { type: 'shoot', target: 'opp' });
  ok(k.phase === 'between' && r.ev.some(e => e.t === 'roundEnd' && e.winner === 'p'), 'killing dealer ends round (between)');
  ok(!E.apply(k, 'p', { type: 'shoot', target: 'opp' }).ok, 'no actions after round end');
}

section('Engine: items');
{
  const mk = (id, mut) => { const s = E.newGame('normal', 11); E.startRound(s); s.p.items = new Array(6).fill(null); s.d.items = new Array(6).fill(null); s.p.items[0] = { id, uses: D.items[id].uses }; if (mut) mut(s); return s; };
  let s = mk('magnifier', s => { s.chamber = ['e', 'a']; s.pub = { e: 1, a: 1 }; });
  let r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.peek.who === 'p' && s.peek.type === 'e' && !s.p.items[0], 'magnifier peeks and is consumed');
  ok(E.infoFor(s, 'p').peek === 'e' && E.infoFor(s, 'd').peek === null, 'peek knowledge is private');
  s = mk('cigarette'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'cigarette refused at full pulse');
  s = mk('cigarette', s => { s.p.hp = 1; }); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.p.hp === 2, 'cigarette heals 1');
  s = mk('handcuffs'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.d.cuffed, 'handcuffs bind dealer');
  s = mk('handcuffs', s => { s.d.cuffed = true; }); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'cannot cuff twice');
  s = mk('battery'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.p.charged, 'battery charges');
  s = mk('can', s => { s.chamber = ['a', 'e']; s.pub = { e: 1, a: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.chamber.length === 1 && s.pub.a === 0 && r.ev[0].fx.type === 'a', 'can ejects and reveals current shell');
  s = mk('can', s => { s.chamber = ['a']; s.pub = { e: 0, a: 1 }; }); r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ev.some(e => e.t === 'reload'), 'can that empties the chamber reloads');
  s = mk('lighter'); ok(!E.apply(s, 'p', { type: 'item', idx: 0 }).ok, 'lighter needs a target');
  s = mk('lighter', s => { s.d.items[2] = { id: 'coin', uses: 1 }; s.d.items[4] = { id: 'can', uses: 1 }; });
  r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.d.items.filter(Boolean).length === 1 && s.p.items[0] && s.p.items[0].uses === 1, 'lighter burns one item and keeps 1 charge');
  r = E.apply(s, 'p', { type: 'item', idx: 0 });
  ok(r.ok && s.d.items.filter(Boolean).length === 0 && !s.p.items[0], 'lighter consumed after second use');
  s = mk('medicine', s => { s.p.hp = 1; });
  for (let i = 0; i < 20; i++) { const t = mk('medicine', s => { s.p.hp = 1; s.r = i * 77; }); E.apply(t, 'p', { type: 'item', idx: 0 }); if (t.p.hp < 1) ok(false, 'medicine killed player'); }
  ok(true, 'medicine never fatal (20 seeds)');
  s = mk('scrambler', s => { s.chamber = ['e', 'a', 'e', 'a', 'e']; s.pub = { e: 3, a: 2 }; s.peek = { who: 'p', type: 'e' }; });
  r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && s.peek.who === null && s.chamber.filter(c => c === 'e').length === 3, 'scrambler keeps counts, clears peek');
  s = mk('coin'); r = E.apply(s, 'p', { type: 'item', idx: 0 }); ok(r.ok && r.ev[0].fx.k === 'coin' && r.ev[0].fx.inner, 'coin produces an inner effect');
}

section('Engine: validate / serialisation');
{
  const st = E.newGame('hard', 3); E.startRound(st);
  ok(E.validate(JSON.parse(JSON.stringify(st))), 'valid state survives JSON round-trip');
  const bad = JSON.parse(JSON.stringify(st)); bad.p.hp = 99; ok(!E.validate(bad), 'rejects hp > max');
  const bad2 = JSON.parse(JSON.stringify(st)); bad2.p.items[0] = { id: 'nope', uses: 1 }; ok(!E.validate(bad2), 'rejects unknown item');
  ok(!E.validate(null) && !E.validate({}) && !E.validate('x'), 'rejects junk');
  const bad3 = JSON.parse(JSON.stringify(st)); bad3.chamber = ['x']; ok(!E.validate(bad3), 'rejects bad chamber');
}

section('Simulation: full games Dealer-AI vs scripted player (all difficulties)');
{
  const playerPolicy = (st) => {
    const i = st.p.items.findIndex((x, k) => x && E.canUse(st, 'p', k).ok);
    if (i >= 0 && U.Rand.next(st) < 0.6) return { type: 'item', idx: i };
    const info = E.infoFor(st, 'p'); const pe = info.ember / Math.max(1, info.total);
    return { type: 'shoot', target: pe >= 0.5 ? 'opp' : 'self' };
  };
  const results = {};
  let stuck = 0, actions = 0;
  for (const diff of ['easy', 'normal', 'hard', 'nightmare']) {
    results[diff] = { w: 0, l: 0 };
    for (let seed = 1; seed <= 150; seed++) {
      const st = E.newGame(diff, seed);
      let guard = 0;
      while (st.phase !== 'won' && st.phase !== 'lost' && guard < 5000) {
        if (st.phase === 'between') { E.startRound(st); continue; }
        guard++;
        const who = st.turn;
        const act = who === 'p' ? playerPolicy(st) : AI.decide(st);
        const r = E.apply(st, who, act);
        actions++;
        if (!r.ok) { ok(false, `illegal action by ${who}: ${JSON.stringify(act)} -> ${r.reason}`); break; }
        if (!E.validate(st) && st.phase === 'play') { ok(false, 'state invalid mid-game'); break; }
      }
      if (guard >= 5000) { stuck++; }
      results[diff][st.phase === 'won' ? 'w' : 'l']++;
    }
  }
  ok(stuck === 0, 'no game failed to terminate (' + actions + ' actions simulated)');
  console.log('  player win/loss vs dealer (150 seeds each):', JSON.stringify(results));
  ok(results.easy.w >= results.nightmare.w, 'easy is not harder than nightmare for the player');
  // Fairness: identical AI on both seats, single round, normal difficulty (no bonuses). Player moves first.
  let pw = 0, N = 600;
  for (let seed = 1; seed <= N; seed++) {
    const st = E.newGame('normal', 1000 + seed); E.startRound(st); let g = 0;
    while (st.phase === 'play' && g < 3000) { g++; const who = st.turn; const r = E.apply(st, who, AI.decide(st, who)); if (!r.ok) { ok(false, 'mirror illegal ' + r.reason); break; } }
    if (st.phase === 'between') pw++;
  }
  console.log('  mirror single round (normal): first seat wins', pw, '/', N);
  ok(pw > N * 0.4 && pw < N * 0.65, 'round-1 mirror match within 40-65% (no crippling seat bias)');
}

section('Save-manager sanitising');
{
  const S = ctx.Save;
  const s = S.sanitizeSettings({ master: 5, quality: 'ultra', fps: 144, textSize: 9, lang: 'xx', shake: 'a' });
  ok(s.master === 1 && s.quality !== 'ultra' && s.fps === 60 && s.textSize === 1 && s.lang === 'en', 'settings clamped/defaulted');
  ok(S.sanitizeMeta('garbage').stats.games === 0, 'meta tolerates garbage');
  S.write('tallow.run.v1', 'not json{'); ctx.Save.mem['tallow.run.v1'] = 'not json{';
  ok(S.loadRun() === null && S.corruptFlag, 'corrupt run save is discarded and flagged');
  const st = E.newGame('normal', 2); E.startRound(st); S.queueRun(st); S.flushRun();
  ok(E.validate(S.loadRun()), 'valid run saved and loaded');
}

section('Animation manifest');
if (ctx.AnimData) {
  const rep = ctx.AnimData.validate();
  rep.errors.forEach(e => console.log('  ERR', e));
  ok(rep.errors.length === 0, 'manifest validates (' + rep.clips + ' clips, ' + rep.sfx + ' sfx refs, ' + rep.events + ' events)');
  const need = ['hand_idle','hand_breathe','hand_fingers','hand_tap','hand_look_table','hand_reach','hand_grab','hand_hold','hand_inspect','hand_rotate','hand_use','hand_putdown','hand_drop','hand_reach_weapon','hand_hold_weapon','hand_raise_weapon','hand_lower_weapon','hand_inspect_weapon','hand_fire','hand_recoil','hand_recover','hand_tremble','hand_hesitate','hand_startle','hand_frustrate','hand_victory','hand_defeat','hand_rest'];
  ok(need.every(n => ctx.AnimData.clips[n]), 'all 28 required player-hand states exist');
  for (const id of D.itemOrder) for (const who of ['p', 'd']) ok(!!ctx.AnimData.itemUse(id, who), `item clip builds for ${id}/${who}`);
} else console.log('  (animations.js not present yet)');

section('Audio manifest');
if (ctx.AudioMgr && ctx.AudioMgr.SFX && ctx.AnimData) {
  const names = ctx.AnimData.allSfxRefs();
  const missing = names.filter(n => !ctx.AudioMgr.SFX[n]);
  ok(missing.length === 0, 'every sfx referenced by animations exists in synth table' + (missing.length ? ' — missing: ' + missing.join(',') : ''));
  const used = new Set(names);
  ctx.AudioMgr.requiredSfx.forEach(n => ok(!!ctx.AudioMgr.SFX[n], 'required sfx ' + n));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
