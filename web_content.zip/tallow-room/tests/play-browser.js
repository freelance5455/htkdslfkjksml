const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', ...(process.env.THREE === '1' ? ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] : [])] });
  const ctx = await b.newContext({ viewport: { width: 915, height: 412 }, deviceScaleFactor: 1, hasTouch: true, isMobile: true });
  const p = await ctx.newPage(); const logs = [];
  p.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + m.text()); });
  p.on('pageerror', e => logs.push('PAGEERROR: ' + e.message));
  if (process.env.THREE !== '1') await p.addInitScript(() => { try { localStorage.setItem('tallow.settings.v1', JSON.stringify({ three: false })); } catch (e) {} });
  await p.goto('file://' + process.cwd() + '/index.html'); await p.waitForTimeout(1200);
  const shot = n => p.screenshot({ path: `/tmp/claude-0/shots/${n}.png`, timeout: 120000 });
  const vis = async id => p.evaluate(i => { const e = document.getElementById(i); return !!e && !e.classList.contains('hidden') && e.offsetParent !== null; }, id);
  const click = async id => { await p.evaluate(i => document.getElementById(i).click(), id); };
  await click('mNew'); await p.waitForTimeout(400); await shot('diff');
  await p.evaluate(() => document.querySelector('#diffList button').click()); await p.waitForTimeout(800);
  for (let i = 0; i < 8 && await vis('mTut'); i++) { await click('tutNext'); await p.waitForTimeout(250); }
  await p.waitForTimeout(500); await shot('t0');
  const log = [];
  let items = 0, shots = 0, endSeen = false;
  for (let step = 0; step < 400 && !endSeen; step++) {
    await p.waitForTimeout(700);
    const s = await p.evaluate(() => { const t = window.__tallow, st = t.state; if (!st) return null; return { turn: st.turn, ph: st.phase, over: st.over, hp: [st.p && st.p.hp, st.d && st.d.hp], rd: st.round, inv: st.p && st.p.items ? st.p.items.length : null }; });
    if (await vis('mEnd')) { endSeen = true; await shot('end'); break; }
    if (await vis('banner')) { await p.waitForTimeout(1500); continue; }
    if (await vis('actions') && await vis('btnAimD')) {
      // use item sometimes
      if (step % 5 === 0 && await vis('btnInv')) { await click('btnInv'); await p.waitForTimeout(300); const slot = await p.evaluate(() => { const b = document.querySelector('#invGrid button:not([disabled])'); if (b) b.click(); return !!b; }); if (slot) { await p.waitForTimeout(200); if (await vis('invUse') && await p.$eval('#invUse', e => !e.disabled)) { await click('invUse'); items++; await p.waitForTimeout(3500); if (step < 12) await shot('itemuse'); } } if (await vis('inventory')) await click('invClose'); await p.waitForTimeout(300); continue; }
      await click(step % 3 === 0 ? 'btnAimS' : 'btnAimD'); await p.waitForTimeout(1500); if (shots === 0) await shot('aim');
      if (await vis('btnFire')) { await click('btnFire'); shots++; await p.waitForTimeout(600); if (shots === 1) await shot('fire'); }
    } else if (await vis('btnFire')) { await click('btnFire'); shots++; }
    if (step % 10 === 0) log.push(JSON.stringify(s));
  }
  console.log('steps log', log.slice(0, 6).join(' | '));
  console.log('items used', items, 'shots', shots, 'endSeen', endSeen);
  console.log(JSON.stringify(await p.evaluate(() => window.__tallow.stats())));
  console.log(logs.join('\n') || 'no console errors');
  await b.close();
})();
