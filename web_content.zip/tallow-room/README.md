# THE TALLOW ROOM — mobile horror table game (HTML5 / Canvas / Web Audio)

A turn-based, tension-driven duel against **the Dealer**, a wax-masked host who has loaded a stylized fictional
"Caster" with secret shells (Embers = damage, Ash = blank). Original characters, art, UI, text and sound — nothing is
copied from any other game. Inspired only by the *genre* of tense turn-based table duels.

## Run it
- **Desktop / phone browser:** open `index.html` (works from `file://`, no server, no build step, no external assets).
- **Local server (optional):** `python3 -m http.server 8080` then open `http://localhost:8080`.
- Best in **landscape**. In portrait the game auto-pauses and shows a rotate prompt.
- Audio starts after the first tap (browser autoplay rule).

## How to play
Each round the Caster is loaded; the counts of Embers/Ash are shown, the order is secret.
On your turn: **Aim at Dealer** or **Aim at Self**, then **Fire**; or use an item (**Items**), inspect the Caster (🔍).
Shooting yourself with Ash gives you an extra turn; with an Ember you lose a pulse. Reduce the Dealer's pulses to 0 in each of
3 rounds. Items (9): Magnifier, Handcuffs, Cigarette, Battery, Medicine, Drink can, Lighter, Scrambler, Coin.
Difficulties: Easy / Normal / Hard / Nightmare (unlocked after a win). Tap items on the table or use the Items panel.

## Features (all implemented and exercised by the tests below)
- 28 first-person hand states, 51 Dealer clips (idle/face/speech/interaction/special), 19 Caster clips — keyframe clips with
  priorities, interruptibility, events, SFX hooks, pause, fallbacks, manifest validation at boot.
- Dealer item use with full animations; Dealer AI with 4 difficulties.
- Lightweight physics (shells, coin, can, cigarette butt, pill, bottle, cell).
- Fully synthesized audio: SFX (54), ambience, generative music, formant-synth Dealer voice (+ subtitles); independent master/music/ambience/effects volume.
- Menu, HUD, inventory, pause, settings (quality low/medium/high, 30/60 fps, reduced motion, shake, text size, touch size, subtitles, language EN/Arabic with RTL), item archive, achievements (8), endings, save & resume, progression.

## Project layout
```
index.html            all screens
styles/               main, menu, gameplay, settings CSS
scripts/              util, game-state (rules engine), dealer-ai, save-manager, audio-manager, animation-controller,
                      physics, art (procedural drawing), renderer, gameplay (presentation director), turn-system,
                      input-manager, accessibility, ui-controller, main
data/                 game-data.js, animations.js (source of truth) + generated *.json manifests
tools/export-manifests.js   regenerates and validates data/*.json
tests/                logic.test.js (node), play-browser.js, features-browser.js (Playwright)
assets/, audio/       placeholders only (README.txt): art and audio are generated procedurally at runtime
```
Rules engine (`Engine`) is deterministic/seeded and independent from the presentation (`Show`), which only narrates events.

## Android (Samsung) packaging
1. **Quickest:** host the folder on any static HTTPS host and "Add to Home screen" in Chrome (fullscreen via the menu button).
2. **WebView app:** Android Studio → Empty Activity. Copy this folder into `app/src/main/assets/tallow/`. In the Activity:
   `webView.settings.javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false;`
   then `webView.loadUrl("file:///android_asset/tallow/index.html")`. Set `android:screenOrientation="sensorLandscape"`,
   use immersive fullscreen flags, and keep `android:hardwareAccelerated="true"`.
   (A WebView/Capacitor build was **not** produced or tested here — instructions only.)
3. **Capacitor:** `npm i @capacitor/core @capacitor/cli @capacitor/android`, `npx cap init`, set `webDir` to this folder, `npx cap add android`, `npx cap sync`.

## Storage notes
Settings, progress and the in-progress run use `localStorage` (key prefix `tallow.`), falling back to memory if blocked. Clearing
site data or private mode loses saves. Corrupt saves are detected and reset with a notice.

## Replacing placeholder art/audio
All art lives in `scripts/art.js` and all sound in the `SFX` table of `scripts/audio-manager.js`. To use file assets, load images/audio
in those modules and keep the same names; run `node tools/export-manifests.js` to revalidate.

## Test report (what was actually run)
- `node tests/logic.test.js` — 116 assertions pass (determinism, every item, rule validation, 600 simulated games, save sanitizing, manifests).
- `node tests/play-browser.js` (headless Chromium, 915x412 touch) — a full game played through UI to an ending, no console errors; avg draw ≈1.5 ms/frame in headless software rendering.
- `node tests/features-browser.js` — 20 checks pass: pause, settings, save→leave→reload→continue state restore, archive/achievements/credits/settings screens, portrait auto-pause + resume, low quality + 30 fps cap (min frame interval 33 ms) + reduced motion + Arabic/RTL, and an offline render of all 54 SFX (audible, finite, non-clipping).

## Honest limitations
- **Not tested on a real Android device** or real speakers/headphones; performance numbers are from headless desktop Chromium. Audio was verified numerically (offline render), **not by ear**; voice quality is a stylized formant synth, not speech.
- The Dealer's arms are simple stylized shapes; art is procedural vector drawing, not hand-painted AAA assets. Animation is keyframed procedural rigs, not skeletal/mocap.
- Not every item/ending path was visually inspected frame-by-frame; unattended bot play covered ordinary flows, and logic simulations covered rules.
- Arabic text is machine-written and not reviewed by a native speaker.
- Achievements/endings beyond those reached in tests were verified by logic only.
