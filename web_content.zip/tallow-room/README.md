# THE TALLOW ROOM — mobile horror table game (HTML5 / Canvas / Web Audio)

A turn-based, tension-driven duel against **the Dealer**, a wax-masked host who has loaded a stylized fictional
"Caster" with secret shells (Embers = damage, Ash = blank). Original characters, art, UI, text and sound — nothing is
copied from any other game. Inspired only by the *genre* of tense turn-based table duels.

## Run it
- **Desktop / phone browser:** open `index.html` (works from `file://`, no server, no build step, no external assets).
- **Local server (optional):** `python3 -m http.server 8080` then open `http://localhost:8080`.
- **Landscape only.** Manifest + Screen Orientation lock (`scripts/orientation.js`); if the browser refuses to lock, the whole game frame is rotated 90° so it is still drawn in landscape (no rotate prompt, never portrait). First touch on a phone enters immersive fullscreen.
- Audio starts after the first tap (browser autoplay rule).

## How to play
Each round the Caster is loaded; the counts of Embers/Ash are shown, the order is secret.
On your turn: **Aim at Dealer** or **Aim at Self**, then **Fire**; or use an item (**Items**), inspect the Caster (🔍).
Shooting yourself with Ash gives you an extra turn; with an Ember you lose a pulse. Reduce the Dealer's pulses to 0 in each of
3 rounds. Items (13): Magnifier, Handcuffs, Cigarette, Battery, Medicine, Drink can, Lighter, Scrambler, Coin, Rusted Blade (1 damage, cannot kill), Dead Casing (next shell becomes Ash), Pest Spray (wipes opponent charge/knowledge), Coarse Rope (steal an item).
Difficulties: Easy / Normal / Hard / Nightmare (unlocked after a win). Tap items on the table or use the Items panel.

## Features (all implemented and exercised by the tests below)
- **Real 3D (v2):** a self-written WebGL engine (`scripts/gl3d.js`, `scripts/stage3d.js`; no external libraries) draws a 3D room, table, the Caster, 13 item models, the skull-masked Dealer and 3D hands/arms, with point lights, a shadow-mapped lamp, fog, procedural wood/concrete/cloth/skin/wax surfaces, light shafts and glow sprites. The existing animation clips drive the 3D objects (screen coordinates are ray-cast into the world). If WebGL is unavailable or '3D view' is off, the original 2D renderer is used automatically.
- 13 items: magnifier, handcuffs, cigarette, battery, medicine, drink can, lighter, scrambler, coin + new knife, blank, insect spray, rope (each with use animation, sound, 3D model, Dealer AI use).
- Shop (menu): earn Wax by winning rounds, buy items; up to two owned items join your side at the start of a new game.
- Settings tabs Gameplay / Audio / Video / Controls (3D view, quality, resolution scale, FPS, fullscreen, touch size, look sensitivity, subtitle language); drag the room to look around.
- Dealer subtitles appear directly under the Dealer's chin and follow the 3D head; subtitle language can differ from the UI language.
- 28 first-person hand states, 51 Dealer clips (idle/face/speech/interaction/special), 19 Caster clips — keyframe clips with
  priorities, interruptibility, events, SFX hooks, pause, fallbacks, manifest validation at boot.
- Dealer item use with full animations; Dealer AI with 4 difficulties.
- Lightweight physics (shells, coin, can, cigarette butt, pill, bottle, cell).
- Fully synthesized audio: SFX (54), ambience, generative music, formant-synth Dealer voice (+ subtitles); independent master/music/ambience/effects volume.
- Menu, HUD, inventory, pause, settings (quality low/medium/high, 30/60 fps, reduced motion, shake, text size, touch size, subtitles, language EN/Arabic with RTL), item archive, achievements (8), endings, save & resume, progression.

## Project layout
```
index.html            all screens
styles/               main, menu, gameplay, settings CSS
scripts/              util, game-state (rules engine), dealer-ai, save-manager, audio-manager, animation-controller,
                      physics, art (procedural drawing), renderer, gameplay (presentation director), turn-system,
                      input-manager, accessibility, ui-controller, main
data/                 game-data.js, animations.js (source of truth) + generated *.json manifests
tools/export-manifests.js   regenerates and validates data/*.json
tests/                logic.test.js (node), play-browser.js, features-browser.js (Playwright)
assets/, audio/       placeholders only (README.txt): art and audio are generated procedurally at runtime
```
Rules engine (`Engine`) is deterministic/seeded and independent from the presentation (`Show`), which only narrates events.

## Android (Samsung) packaging
1. **Quickest:** host the folder on any static HTTPS host and "Add to Home screen" in Chrome (fullscreen via the menu button).
2. **WebView app:** Android Studio → Empty Activity. Copy this folder into `app/src/main/assets/tallow/`. In the Activity:
   `webView.settings.javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false;`
   then `webView.loadUrl("file:///android_asset/tallow/index.html")`. Set `android:screenOrientation="landscape"` (a ready template is in `android/`),
   use immersive fullscreen flags, and keep `android:hardwareAccelerated="true"`.
   (A WebView/Capacitor build was **not** produced or tested here — instructions only.)
3. **Capacitor:** `npm i @capacitor/core @capacitor/cli @capacitor/android`, `npx cap init`, set `webDir` to this folder, `npx cap add android`, `npx cap sync`.

## Storage notes
Settings, progress and the in-progress run use `localStorage` (key prefix `tallow.`), falling back to memory if blocked. Clearing
site data or private mode loses saves. Corrupt saves are detected and reset with a notice.

## v3 — your GLB assets, real skeleton, physics (this update)
The three supplied files are **the actual game assets** now (converted by `tools/build-models.js` into `data/models.js`, base64, so the game still runs from `file://`; re-run `node tools/build-models.js <folder-with-the-glbs>` to rebuild).
- **`old_rustic_game_table_3d.glb`** → the table (50 parts, vertex-colour wood/iron look kept; a subtle procedural grain is added on top). Scaled uniformly so its top surface is exactly the game's table height; the old slab/legs are gone. Loose bodies (shells, coin, can…) are clamped to this table's measured top rectangle.
- **`decorative_shotgun_3d_animated.glb`** → the Caster. Split into body + fore-end (the fore-end slides when racked). Measured sockets: pistol-grip rear face, fore-end underside, muzzle, ejection port. It lies on its side on the table (resting on its flat side, no floating) and turns upright when held.
- **`hooded_skull_character_3d.glb`** → the Dealer. **The file contains no skeleton, no skin and no usable animation** (80 rigid mesh parts, vertex colours, one turntable rotation). So I authored a real 29-joint skeleton (root, pelvis, spine, chest, neck, head, jaw, 2×[upper arm, forearm, hand, 4 fingers, thumb, upper leg, lower leg, foot]) with joint positions measured from the model's own parts, and computed 4-joint skin weights per vertex (8,628 vertices; blends at shoulders, elbows, wrists, neck, jaw, trunk, knees). Skinning runs on the GPU (3×vec4 joint matrices).
- **Weapon holding:** right hand wraps the grip (palm on the grip's rear face, fingers curled), left hand cups the fore-end from below. Wrist targets come from the gun's measured sockets every frame (not from hand positions copied onto the gun). Arms use two-bone IK with an elbow pole (Dealer: real skeleton IK; player: first-person arm chain). If the Dealer cannot reach, his torso leans over the table (head stays put); if still out of reach the gun is brought to the hand, so the hand never leaves the grip.
- **Dealer animation:** head look/tilt, jaw (talking), breathing, finger curl, lean-in, arm IK – all driven by the existing animation channels. Glowing eyes are additive sprites in the sockets.
- **Physics:** fixed 120 Hz timestep with render interpolation, adaptive sub-stepping (no body moves more than half its radius per sub-step → no tunnelling), per-kind mass/restitution/friction, mass-weighted contacts, rest/sleep state, table-top clamp in world space.
- **Also:** smoothed camera (critically-damped look, smooth-noise shake instead of per-frame random), smaller HUD/menu/banner typography, GL resource-leak check.
- New tests: `tests/logic.test.js` (163 assertions: physics determinism across 30/60/144 fps, no tunnelling, rest pose = original mesh, IK reach/bone-length/clamp, weights normalised), `tests/grip-3d.js` (renders both holders), `tests/perf-3d.js` (no GL object growth, no console errors).

## v3.1 — smoothness (lag + choppy sound)
- **Sound:** all 59 sound effects are rendered once (offline, in the background after the first tap) into small cached buffers; playing one is a single node instead of dozens of live oscillators/filters. The Dealer's voice is rendered off the main thread the first time a line is spoken, then cached. Audio buffer hint is `balanced` (no under-runs when a frame runs long), reverb tail shortened (cheaper convolution), polyphony cap 24.
- **Frame rate:** automatic resolution governor (drops render scale smoothly when frames exceed ~22 ms, recovers when there is headroom), lower pixel budgets per quality tier, shadow map refreshed every 2nd frame, 5-tap instead of 9-tap shadow filter, cheaper wood shader, light shafts and film grain only when there is headroom/High quality.
- Measured: JS+submit cost per frame is ~3.6 ms; GL objects stop growing after start-up; 163 logic tests and 32 browser checks pass. **Not measured on a real phone GPU** (the sandbox only has software WebGL), so the governor thresholds are untuned guesses until you try it on the Samsung.

## v3.2 — image main menu + menu song
- The main menu is now your artwork (`assets/menu-art.jpg`) with invisible, keyboard-focusable hot-spots over its six buttons (Continue / Settings / Shop / Item archive / Achievements / Leave). Because the labels are part of the picture they are Arabic only; screen-reader labels follow the selected language. A small row at the bottom keeps **New Game** (difficulty choice), Credits, Fullscreen and a music on/off button, since the artwork has no buttons for them.
- Animation: a canvas layer draws ~22 shotgun shells that fall (three depth layers, motion-blurred foreground ones), bounce once on the wet floor with sparks and a reflection, then fade; plus drifting fog, rising embers, a slow "breathing" zoom of the artwork and pulsing red glow on the buttons. (The shells already printed in the picture stay still; the new ones are drawn on top.) Reduced-motion setting → fewer shells, no breathing.
- Music: the audio track of your video was extracted to `assets/menu-music.mp3` (2.4 MB, 2:52, loops). It plays on the menu only; **pressing Continue fades it out (0.45 s) and starts the game** (the in-game generative music is silent while the song plays and returns afterwards). Continue resumes your saved run; with no save it starts a new game on the last-used difficulty (first time: the short tutorial first). Returning to the menu restarts the song.
- Browsers/WebViews block sound until the first touch, so a "tap anywhere for sound" hint shows and the first tap starts the song. In an Android WebView app call `settings.setMediaPlaybackRequiresUserGesture(false)` to let it start by itself.
- Fixed a real bug found on the way: four menu buttons shared ids with their modals (`mShop`, `mArchive`, `mAch`, `mCredits`, `mLeave`), so those dialogs could be addressed through the wrong element and the old test passed vacuously. Buttons are now `bShop`/`bArchive`/`bAch`/`bCredits`/`bLeave`, and a test asserts all ids in `index.html` are unique.
- While the image menu is showing, the 3D scene is not rendered (saves battery).

## Replacing placeholder art/audio
All art lives in `scripts/art.js` and all sound in the `SFX` table of `scripts/audio-manager.js`. To use file assets, load images/audio
in those modules and keep the same names; run `node tools/export-manifests.js` to revalidate.

## Test report (what was actually run)
- `node tests/logic.test.js` — 138 assertions pass (incl. new items) (determinism, every item, rule validation, 600 simulated games, save sanitizing, manifests).
- `node tests/play-browser.js` (headless Chromium, 915x412 touch) — a full game played through UI to an ending, no console errors; avg draw ≈1.5 ms/frame in headless software rendering.
- `node tests/features-browser.js` — 20 checks pass: pause, settings, save→leave→reload→continue state restore, archive/achievements/credits/settings screens, portrait auto-pause + resume, low quality + 30 fps cap (min frame interval 33 ms) + reduced motion + Arabic/RTL, and an offline render of all 54 SFX (audible, finite, non-clipping).

- v2 browser tests: `tests/features-browser.js` also checks the shop (13 cards, buy, stock consumed at game start), settings tabs, sensitivity, the 3D scene rendering under software WebGL (307 draw calls / 22k triangles on Low), exact camera ray/project round-trip, subtitle placement under the Dealer, and 59 SFX renders. `tests/play-browser.js` completed full games in both 2D mode and (once, before the new items) 3D mode.

## Honest limitations
- **GLB assets are stylised low-poly trimesh exports** (vertex colours only, no textures/PBR, no normals — normals are generated with a crease angle). The character's hands are big blocky parts: each finger is ONE rigid bone (curls as a unit, no knuckle bending), so the grip is a convincing wrap but not a anatomically exact one. The supplied files' only animation is a turntable spin and is intentionally unused; the character has no authored clips, so idle/lean/grip poses are procedural on the authored skeleton. The Dealer's brows are not animated (the model's brow ridge is a fixed part); expression comes from head tilt, jaw and eye glow. Dealer legs/feet are skinned but hidden behind the table. No LOD system. Remaining props (13 items, room) are still primitive-built and **3D is low-poly procedural art, not AAA/PBR.** Models are built from primitives (boxes, spheres, lathes); hands and Dealer arms are blocky, textures are generated in shaders, there is no skeletal mocap, no LOD system, no real PBR materials. Frame rate on real Android GPUs is **unmeasured** (only headless software WebGL was used, which is far slower); use Quality Low / Resolution scale / 2D fallback if needed.
- The Dealer and logo are **original** designs, deliberately not copies of Buckshot Roulette's characters or branding.
- Not done / partial vs. the overhaul brief: no wall blood splatter (table decals only), cinematic scene transitions are fades/flashes, spatial audio is stereo panning only, achievement-unlock effects are toasts, the 'Resolution' option is a render-scale slider, and 3D item/hand poses were tuned by eye on a handful of screenshots, so odd poses may remain in rarely seen animations.
- **Not tested on a real Android device** or real speakers/headphones; performance numbers are from headless desktop Chromium. Audio was verified numerically (offline render), **not by ear**; voice quality is a stylized formant synth, not speech.
- The Dealer's arms are simple stylized shapes; art is procedural vector drawing, not hand-painted AAA assets. Animation is keyframed procedural rigs, not skeletal/mocap.
- Not every item/ending path was visually inspected frame-by-frame; unattended bot play covered ordinary flows, and logic simulations covered rules.
- Arabic text is machine-written and not reviewed by a native speaker.
- Achievements/endings beyond those reached in tests were verified by logic only.
