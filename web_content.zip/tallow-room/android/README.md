# Android wrapper (landscape-locked WebView) — NOT built or tested here
1. Android Studio → Empty Views Activity, package `com.tallowroom.game`.
2. Copy this folder's `AndroidManifest.xml`, `MainActivity.kt`, `res/values/themes.xml` over the generated ones.
3. Copy the game folder (index.html, scripts/, styles/, data/, assets/…) to `app/src/main/assets/tallow/`.
4. Build. The manifest sets `android:screenOrientation="landscape"`; `configChanges` keeps the WebView alive; immersive flags hide the bars.
