const medicalDatabase = [

  {
    id: 1,
    term: "Anatomy",
    pronunciation: "uh-NAT-uh-mee",
    pashto: "اناتومي",
    definition: "The study of the structure of the body.",
    pashtoDefinition: "د بدن د جوړښت د مطالعې علم."
  },

  {
    id: 2,
    term: "Physiology",
    pronunciation: "fiz-ee-OL-uh-jee",
    pashto: "فیزیولوژي",
    definition: "The study of how the body functions.",
    pashtoDefinition: "د بدن د دندو او فعالیتونو د مطالعې علم."
  },

  {
    id: 3,
    term: "Cell",
    pronunciation: "sel",
    pashto: "حجره",
    definition: "The basic structural and functional unit of life.",
    pashtoDefinition: "د ژوند اساسي جوړښتي او وظیفوي واحد."
  },

  {
    id: 4,
    term: "Tissue",
    pronunciation: "TISH-oo",
    pashto: "نسج",
    definition: "A group of similar cells performing a specific function.",
    pashtoDefinition: "د ورته حجرو یوه ډله چې ځانګړې دنده ترسره کوي."
  },

  {
    id: 5,
    term: "Organ",
    pronunciation: "OR-gun",
    pashto: "عضوه",
    definition: "A body structure that performs a specific function.",
    pashtoDefinition: "د بدن هغه جوړښت چې ځانګړې دنده ترسره کوي."
  },

  {
    id: 6,
    term: "Heart",
    pronunciation: "hart",
    pashto: "زړه",
    definition: "A muscular organ that pumps blood through the body.",
    pashtoDefinition: "عضلاتي عضوه ده چې وینه د بدن په ټول سیستم کې پمپ کوي."
  },

  {
    id: 7,
    term: "Blood",
    pronunciation: "blud",
    pashto: "وینه",
    definition: "A fluid connective tissue that circulates through the body.",
    pashtoDefinition: "مایع نښلوونکی نسج دی چې د بدن په داخل کې جریان کوي."
  },

  {
    id: 8,
    term: "Artery",
    pronunciation: "AR-ter-ee",
    pashto: "شریان",
    definition: "A blood vessel that carries blood away from the heart.",
    pashtoDefinition: "هغه وینه وړونکی رګ چې وینه له زړه څخه بهر وړي."
  },

  {
    id: 9,
    term: "Vein",
    pronunciation: "vayn",
    pashto: "ورید",
    definition: "A blood vessel that carries blood toward the heart.",
    pashtoDefinition: "هغه وینه وړونکی رګ چې وینه زړه ته راولي."
  },

  {
    id: 10,
    term: "Capillary",
    pronunciation: "KAP-uh-lair-ee",
    pashto: "شعري رګ",
    definition: "A very small blood vessel connecting arteries and veins.",
    pashtoDefinition: "یو ډېر نری وینه وړونکی رګ چې شریانونه او وریدونه سره نښلوي."
  },

  {
    id: 11,
    term: "Brain",
    pronunciation: "brayn",
    pashto: "ماغزه",
    definition: "The main organ of the central nervous system.",
    pashtoDefinition: "د مرکزي عصبي سیستم اصلي عضوه."
  },

  {
    id: 12,
    term: "Nerve",
    pronunciation: "nurv",
    pashto: "عصب",
    definition: "A structure that carries signals between the brain and body.",
    pashtoDefinition: "هغه جوړښت چې د مغز او بدن ترمنځ عصبي پیغامونه انتقالوي."
  },

  {
    id: 13,
    term: "Neuron",
    pronunciation: "NOOR-on",
    pashto: "عصبي حجره",
    definition: "A specialized cell that transmits nerve signals.",
    pashtoDefinition: "ځانګړې حجره ده چې عصبي پیغامونه انتقالوي."
  },

  {
    id: 14,
    term: "Lung",
    pronunciation: "lung",
    pashto: "سږی",
    definition: "An organ responsible for gas exchange and breathing.",
    pashtoDefinition: "هغه عضوه چې د تنفس او د ګازونو د تبادلې دنده ترسره کوي."
  },

  {
    id: 15,
    term: "Liver",
    pronunciation: "LIV-er",
    pashto: "ځیګر",
    definition: "A large organ involved in metabolism and detoxification.",
    pashtoDefinition: "لویه عضوه ده چې په میتابولیزم او د زهري موادو په له منځه وړلو کې برخه لري."
  },

  {
    id: 16,
    term: "Kidney",
    pronunciation: "KID-nee",
    pashto: "پښتورګی",
    definition: "An organ that filters blood and produces urine.",
    pashtoDefinition: "هغه عضوه چې وینه تصفیه کوي او ادرار جوړوي."
  },

  {
    id: 17,
    term: "Stomach",
    pronunciation: "STUM-uk",
    pashto: "معده",
    definition: "An organ that stores and digests food.",
    pashtoDefinition: "هغه عضوه چې خواړه ساتي او هضموي."
  },

  {
    id: 18,
    term: "Intestine",
    pronunciation: "in-TES-tin",
    pashto: "کولمې",
    definition: "The digestive tract where digestion and absorption occur.",
    pashtoDefinition: "د هاضمې هغه برخه چې هضم او جذب پکې ترسره کېږي."
  },

  {
    id: 19,
    term: "Muscle",
    pronunciation: "MUS-uhl",
    pashto: "عضله",
    definition: "Body tissue that produces movement.",
    pashtoDefinition: "د بدن هغه نسج چې حرکت رامنځته کوي."
  },

  {
    id: 20,
    term: "Bone",
    pronunciation: "bohn",
    pashto: "هډوکی",
    definition: "A hard connective tissue forming the skeleton.",
    pashtoDefinition: "سخت نښلوونکی نسج چې اسکلیټ جوړوي."
  },

  {
    id: 21,
    term: "Joint",
    pronunciation: "joynt",
    pashto: "مفصل",
    definition: "A place where two or more bones meet.",
    pashtoDefinition: "هغه ځای چې دوه یا څو هډوکي سره یوځای کېږي."
  },

  {
    id: 22,
    term: "Skin",
    pronunciation: "skin",
    pashto: "پوستکی",
    definition: "The outer covering of the body.",
    pashtoDefinition: "د بدن بهرنۍ پوښښ."
  },

  {
    id: 23,
    term: "Inflammation",
    pronunciation: "in-fluh-MAY-shun",
    pashto: "التهاب",
    definition: "A protective response of body tissues to injury or infection.",
    pashtoDefinition: "د ټپ یا انتان په وړاندې د بدن د نسجونو دفاعي غبرګون."
  },

  {
    id: 24,
    term: "Infection",
    pronunciation: "in-FEK-shun",
    pashto: "انتان",
    definition: "The invasion and multiplication of harmful microorganisms.",
    pashtoDefinition: "د زیان رسوونکو مایکروارګانیزمونو داخلېدل او زیاتېدل."
  },

  {
    id: 25,
    term: "Disease",
    pronunciation: "dih-ZEEZ",
    pashto: "ناروغي",
    definition: "A condition that affects normal body function.",
    pashtoDefinition: "هغه حالت چې د بدن نورمال فعالیت اغېزمنوي."
  },

  {
    id: 26,
    term: "Diagnosis",
    pronunciation: "dy-ug-NOH-sis",
    pashto: "تشخیص",
    definition: "The identification of a disease or condition.",
    pashtoDefinition: "د ناروغۍ یا روغتیايي حالت پېژندنه."
  },

  {
    id: 27,
    term: "Treatment",
    pronunciation: "TREET-ment",
    pashto: "درملنه",
    definition: "Medical care given to manage or cure a disease.",
    pashtoDefinition: "هغه طبي پاملرنه چې د ناروغۍ د کنټرول یا درملنې لپاره ورکول کېږي."
  },

  {
    id: 28,
    term: "Symptom",
    pronunciation: "SIMP-tum",
    pashto: "عرضه",
    definition: "A problem or feeling reported by a patient.",
    pashtoDefinition: "هغه ستونزه یا احساس چې ناروغ یې بیانوي."
  },

  {
    id: 29,
    term: "Sign",
    pronunciation: "sayn",
    pashto: "نښه",
    definition: "An observable indication of a disease or condition.",
    pashtoDefinition: "هغه څرګنده نښه چې د ناروغۍ یا حالت شتون ښيي."
  },

  {
    id: 30,
    term: "Fever",
    pronunciation: "FEE-ver",
    pashto: "تبه",
    definition: "An elevation of body temperature above normal.",
    pashtoDefinition: "د بدن د حرارت درجه له نورمال څخه لوړېدل."
  },

  {
    id: 31,
    term: "Pain",
    pronunciation: "payn",
    pashto: "درد",
    definition: "An unpleasant sensory and emotional experience.",
    pashtoDefinition: "ناخوښ حسي او عاطفي تجربه."
  },

  {
    id: 32,
    term: "Edema",
    pronunciation: "ih-DEE-muh",
    pashto: "پړسوب",
    definition: "Abnormal accumulation of fluid in body tissues.",
    pashtoDefinition: "په نسجونو کې د مایع غیرنورمال راټولېدل."
  },

  {
    id: 33,
    term: "Anemia",
    pronunciation: "uh-NEE-mee-uh",
    pashto: "کمخوني",
    definition: "A condition involving a reduced number of red blood cells or hemoglobin.",
    pashtoDefinition: "هغه حالت چې د سرو وینې حجرو یا هیموګلوبین کموالی پکې وي."
  },

  {
    id: 34,
    term: "Hypertension",
    pronunciation: "hy-per-TEN-shun",
    pashto: "د وینې لوړ فشار",
    definition: "Persistently elevated blood pressure.",
    pashtoDefinition: "د وینې د فشار دوامداره لوړوالی."
  },

  {
    id: 35,
    term: "Hypotension",
    pronunciation: "hy-poh-TEN-shun",
    pashto: "د وینې ټیټ فشار",
    definition: "Blood pressure that is lower than normal.",
    pashtoDefinition: "د وینې فشار له نورمال څخه ټیټوالی."
  },

  {
    id: 36,
    term: "Fracture",
    pronunciation: "FRAK-cher",
    pashto: "د هډوکي ماتېدنه",
    definition: "A break or crack in a bone.",
    pashtoDefinition: "په هډوکي کې ماتېدنه یا درز."
  },

  {
    id: 37,
    term: "Hemorrhage",
    pronunciation: "HEM-uh-rij",
    pashto: "وینه بهېدنه",
    definition: "Excessive bleeding from a damaged blood vessel.",
    pashtoDefinition: "له زیانمن شوي وینه وړونکي رګ څخه ډېره وینه بهېدنه."
  },

  {
    id: 38,
    term: "Respiration",
    pronunciation: "res-puh-RAY-shun",
    pashto: "تنفس",
    definition: "The process of breathing and gas exchange.",
    pashtoDefinition: "د تنفس او د ګازونو د تبادلې پروسه."
  },

  {
    id: 39,
    term: "Digestion",
    pronunciation: "dy-JES-chun",
    pashto: "هضم",
    definition: "The process of breaking food into absorbable substances.",
    pashtoDefinition: "د خوړو د داسې موادو په توګه ماتول چې بدن یې جذبولی شي."
  },

  {
    id: 40,
    term: "Metabolism",
    pronunciation: "meh-TAB-uh-liz-um",
    pashto: "میتابولیزم",
    definition: "The chemical processes occurring in living organisms.",
    pashtoDefinition: "په ژوندي موجوداتو کې ترسره کېدونکي کیمیاوي پروسې."
  }

];