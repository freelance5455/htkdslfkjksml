const medicalTerms =
  Array.isArray(medicalDatabase)
    ? medicalDatabase
    : [];


const $ = id =>
  document.getElementById(id);


const $$ = selector =>
  document.querySelectorAll(selector);


const FAVORITES_KEY =
  "mohasselTerminologyFavorites";


let favorites =
  JSON.parse(
    localStorage.getItem(FAVORITES_KEY) || "[]"
  );


/* ===============================
   ESCAPE HTML
================================ */

function escapeHTML(value) {

  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");

}


/* ===============================
   NORMALIZE
================================ */

function normalizeText(text) {

  return String(text || "")
    .toLowerCase()
    .trim();

}


/* ===============================
   PAGE NAVIGATION
================================ */

function showPage(pageId) {

  $$(".page").forEach(page => {

    page.classList.remove("active");

  });


  const page =
    $(pageId);

  if (page) {

    page.classList.add("active");

    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });

  }


  closeMenu();


  if (pageId === "termsPage") {

    renderTerms(medicalTerms);

  }


  if (pageId === "favoritesPage") {

    renderFavorites();

  }

}


/* ===============================
   MENU
================================ */

function openMenu() {

  $("sideMenu")
    .classList.add("open");

  $("overlay")
    .classList.add("show");

}


function closeMenu() {

  $("sideMenu")
    .classList.remove("open");

  $("overlay")
    .classList.remove("show");

}


$("menuBtn").addEventListener(
  "click",
  openMenu
);


$("overlay").addEventListener(
  "click",
  closeMenu
);


/* ===============================
   ALL NAVIGATION BUTTONS
================================ */

$$("[data-page]").forEach(button => {

  button.addEventListener(
    "click",
    () => {

      showPage(
        button.dataset.page
      );

    }
  );

});


/* ===============================
   FAVORITES
================================ */

function saveFavorites() {

  localStorage.setItem(
    FAVORITES_KEY,
    JSON.stringify(favorites)
  );

  updateStats();

}


function toggleFavorite(id) {

  id = String(id);

  if (favorites.includes(id)) {

    favorites =
      favorites.filter(
        item => item !== id
      );

  } else {

    favorites.push(id);

  }

  saveFavorites();

  renderTerms(
    medicalTerms
  );

  renderFavorites();

  renderSearchResults(
    lastSearchResults,
    lastSearchQuery
  );

}


/* ===============================
   CARD
================================ */

function createTermCard(item, index = 0) {

  const isFavorite =
    favorites.includes(
      String(item.id)
    );


  const card =
    document.createElement("article");


  card.className =
    "term-card search-result-card";


  card.style.animationDelay =
    `${index * 0.05}s`;


  card.innerHTML = `

    <div class="term-card-content">

      <h3>
        ${escapeHTML(item.term)}
      </h3>

      <div class="term-pashto">
        ${escapeHTML(item.pashto)}
      </div>

      <div class="term-definition">
        ${escapeHTML(item.pashtoDefinition)}
      </div>

    </div>

    <div class="term-card-actions">

      <button
        class="detail-btn"
        data-detail="${item.id}">

        تفصیل

      </button>


      <button
        class="favorite-btn ${isFavorite ? "active" : ""}"
        data-favorite="${item.id}">

        ${isFavorite ? "له خوښو لرې کول" : "خوښې ته"}

      </button>

    </div>

  `;


  return card;

}


/* ===============================
   RENDER TERMS
================================ */

function renderTerms(items) {

  const container =
    $("termsResults");

  if (!container) return;


  container.innerHTML = "";


  if (!items.length) {

    container.innerHTML = `
      <div class="empty-state">
        هېڅ اصطلاح ونه موندل شوه.
      </div>
    `;

    return;

  }


  items.forEach(
    (item, index) => {

      container.appendChild(
        createTermCard(
          item,
          index
        )
      );

    }
  );

}


/* ===============================
   RECENT
================================ */

function renderRecent() {

  const container =
    $("recentTerms");

  if (!container) return;


  container.innerHTML = "";


  medicalTerms
    .slice(-6)
    .reverse()
    .forEach(
      (item, index) => {

        container.appendChild(
          createTermCard(
            item,
            index
          )
        );

      }
    );

}


/* ===============================
   FAVORITES
================================ */

function renderFavorites() {

  const container =
    $("favoritesResults");

  if (!container) return;


  const items =
    medicalTerms.filter(
      item =>
        favorites.includes(
          String(item.id)
        )
    );


  container.innerHTML = "";


  if (!items.length) {

    container.innerHTML = `
      <div class="empty-state">

        <h3>
          لا تر اوسه کومه اصطلاح نه ده خوښه کړې.
        </h3>

        <p>
          د طبي اصطلاحاتو له پاڼې څخه اصطلاح
          خپلې خوښې ته اضافه کړه.
        </p>

      </div>
    `;

    return;

  }


  items.forEach(
    (item, index) => {

      container.appendChild(
        createTermCard(
          item,
          index
        )
      );

    }
  );

}


/* ===============================
   STATS
================================ */

function updateStats() {

  $("totalTerms").textContent =
    medicalTerms.length;


  $("totalFavorites").textContent =
    favorites.length;

}


/* ===============================
   LEVENSHTEIN
================================ */

function levenshtein(a, b) {

  const matrix = [];


  for (
    let i = 0;
    i <= b.length;
    i++
  ) {

    matrix[i] = [i];

  }


  for (
    let j = 0;
    j <= a.length;
    j++
  ) {

    matrix[0][j] = j;

  }


  for (
    let i = 1;
    i <= b.length;
    i++
  ) {

    for (
      let j = 1;
      j <= a.length;
      j++
    ) {

      matrix[i][j] =
        b[i - 1] === a[j - 1]

          ? matrix[i - 1][j - 1]

          : Math.min(

              matrix[i - 1][j] + 1,

              matrix[i][j - 1] + 1,

              matrix[i - 1][j - 1] + 1

            );

    }

  }


  return matrix[b.length][a.length];

}


/* ===============================
   SEARCH
================================ */

let lastSearchResults = [];

let lastSearchQuery = "";


function searchTerms(
  query,
  type = "term"
) {

  const text =
    normalizeText(query);


  if (!text) {

    return [];

  }


  let results;


  if (type === "definition") {

    results =
      medicalTerms.filter(item => {

        const data =
          normalizeText(
            `${item.definition}
             ${item.pashtoDefinition}`
          );

        return data.includes(text);

      });

  } else {

    results =
      medicalTerms.filter(item => {

        const data =
          normalizeText(
            `${item.term}
             ${item.pashto}
             ${item.pronunciation}`
          );

        return data.includes(text);

      });

  }


  /* Smart similar search */

  if (
    results.length === 0 &&
    type === "term"
  ) {

    results =
      medicalTerms
        .map(item => {

          const source =
            normalizeText(
              `${item.term} ${item.pashto}`
            );


          return {

            item,

            distance:
              levenshtein(
                text,
                source
              )

          };

        })

        .sort(
          (a, b) =>
            a.distance -
            b.distance
        )

        .slice(0, 8)

        .filter(
          x => x.distance <= 6
        )

        .map(
          x => x.item
        );

  }


  return results;

}


/* ===============================
   OPEN SEARCH RESULT PAGE
================================ */

function openSearchResultsPage(
  query,
  type = "term"
) {

  const results =
    searchTerms(
      query,
      type
    );


  lastSearchResults =
    results;

  lastSearchQuery =
    query;


  renderSearchResults(
    results,
    query
  );


  showPage(
    "searchResultsPage"
  );

}


/* ===============================
   RENDER SEARCH RESULTS
================================ */

function renderSearchResults(
  results,
  query
) {

  const container =
    $("searchResultsList");


  const info =
    $("searchResultInfo");


  if (!container) return;


  container.innerHTML = "";


  if (!results.length) {

    info.textContent =
      `د "${query}" لپاره پایله ونه موندل شوه.`;


    container.innerHTML = `

      <div class="empty-state">

        <h3>
          نتیجه ونه موندل شوه
        </h3>

        <p>
          مهرباني وکړئ د اصطلاح املا بیا وګورئ.
        </p>

      </div>

    `;

    return;

  }


  info.textContent =
    `د "${query}" لپاره ${results.length} پایلې وموندل شوې.`;


  results.forEach(
    (item, index) => {

      container.appendChild(
        createTermCard(
          item,
          index
        )
      );

    }
  );

}


/* ===============================
   SEARCH BUTTONS
================================ */

function connectSearch(
  inputId,
  buttonId,
  type
) {

  const input =
    $(inputId);

  const button =
    $(buttonId);


  if (!input || !button) return;


  function performSearch() {

    openSearchResultsPage(
      input.value,
      type
    );

  }


  button.addEventListener(
    "click",
    performSearch
  );


  input.addEventListener(
    "keydown",
    event => {

      if (
        event.key === "Enter"
      ) {

        performSearch();

      }

    }
  );

}


connectSearch(
  "homeTermSearch",
  "homeTermSearchBtn",
  "term"
);


connectSearch(
  "homeDefinitionSearch",
  "homeDefinitionSearchBtn",
  "definition"
);


connectSearch(
  "termSearch",
  "termSearchBtn",
  "term"
);


connectSearch(
  "definitionSearch",
  "definitionSearchBtn",
  "definition"
);


/* ===============================
   BACK
================================ */

$("backFromSearch")
  .addEventListener(
    "click",
    () => {

      showPage(
        "homePage"
      );

    }
  );


/* ===============================
   CARD EVENTS
================================ */

document.addEventListener(
  "click",
  event => {

    const favorite =
      event.target.closest(
        "[data-favorite]"
      );


    if (favorite) {

      toggleFavorite(
        favorite.dataset.favorite
      );

      return;

    }


    const detail =
      event.target.closest(
        "[data-detail]"
      );


    if (detail) {

      openTermModal(
        detail.dataset.detail
      );

    }

  }
);


/* ===============================
   MODAL
================================ */

function openTermModal(id) {

  const item =
    medicalTerms.find(
      x =>
        String(x.id) ===
        String(id)
    );


  if (!item) return;


  $("modalBody").innerHTML = `

    <h2>
      ${escapeHTML(item.term)}
    </h2>

    <p>
      <strong>
        پښتو:
      </strong>

      ${escapeHTML(item.pashto)}
    </p>

    <p>
      <strong>
        تلفظ:
      </strong>

      ${escapeHTML(item.pronunciation)}
    </p>

    <p>
      <strong>
        English Definition:
      </strong>

      ${escapeHTML(item.definition)}
    </p>

    <p>
      <strong>
        پښتو تعریف:
      </strong>

      ${escapeHTML(item.pashtoDefinition)}
    </p>

  `;


  $("termModal")
    .classList.add("show");

}


$("closeModal")
  .addEventListener(
    "click",
    () => {

      $("termModal")
        .classList.remove("show");

    }
  );


$("termModal")
  .addEventListener(
    "click",
    event => {

      if (
        event.target ===
        $("termModal")
      ) {

        $("termModal")
          .classList.remove("show");

      }

    }
  );


/* ===============================
   LOADER
================================ */

window.addEventListener(
  "load",
  () => {

    setTimeout(
      () => {

        $("loader")
          .classList.add("hide");

      },
      700
    );

  }
);


/* ===============================
   START
================================ */

renderRecent();

renderTerms(
  medicalTerms
);

renderFavorites();

updateStats();