/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  Asset,
  CombustionPhase,
  CombustionStatus,
  Habit,
  JournalEntry,
  Liability,
  PriorityLevel,
  Task,
  Transaction,
  WisdomLesson,
  ActiveWing,
  ChronoNote,
  ThemeMode,
} from '../types';
import {
  INITIAL_ASSETS,
  INITIAL_HABITS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_LIABILITIES,
  INITIAL_TASKS,
  INITIAL_TRANSACTIONS,
  CURATED_WISDOM_LESSONS,
  INITIAL_CHRONONOTES,
} from '../data/initialData';
import {
  decryptTextAesGcm,
  encryptTextAesGcm,
  getOrCreateDeviceSalt,
  hashPinWithSalt,
  invokeBiometricAuthentication,
  triggerHaptic,
} from '../lib/security';
import { playCombustionIgnitionSound, playTactileClick, playUnlockChord } from '../lib/audio';

interface VaultContextType {
  // Navigation & Wings
  activeWing: ActiveWing;
  setActiveWing: (wing: ActiveWing) => void;

  // Appearance & Themes
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;

  // Security & Lock State
  isLocked: boolean;
  failedAttempts: number;
  lockoutRemainingSeconds: number;
  stealthMode: boolean;
  autoLockMinutes: number;
  verifyPin: (pin: string) => Promise<boolean>;
  verifyPattern: (sequence: number[]) => Promise<boolean>;
  verifyBiometric: () => Promise<{ success: boolean; message: string }>;
  lockVault: () => void;
  unlockVault: () => void;
  setStealthMode: (enabled: boolean) => void;
  setAutoLockMinutes: (mins: number) => void;
  updateMasterPin: (newPin: string) => Promise<boolean>;
  updateMasterPattern: (newSequence: number[]) => void;
  exportEncryptedVault: (password: string) => Promise<string>;
  importEncryptedVault: (cipherText: string, password: string) => Promise<boolean>;
  downloadDeviceBackup: (customPassword?: string) => Promise<{ filename: string; stats: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number } }>;
  restoreFromDeviceFile: (file: File, password?: string) => Promise<{ success: boolean; message: string; stats?: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number } }>;
  resetToMasterDefaults: () => void;

  // Financial Metrics
  totalNetWorth: number;
  earnedThisMonth: number;
  spentThisMonth: number;
  assets: Asset[];
  liabilities: Liability[];
  transactions: Transaction[];
  addAsset: (asset: Omit<Asset, 'id' | 'updatedAt'>) => void;
  updateAsset: (id: string, updates: Partial<Asset>) => void;
  deleteAsset: (id: string) => void;
  addLiability: (liability: Omit<Liability, 'id'>) => void;
  updateLiability: (id: string, updates: Partial<Liability>) => void;
  deleteLiability: (id: string) => void;
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  deleteTransaction: (id: string) => void;

  // Tasks & Habits
  tasks: Task[];
  habits: Habit[];
  addTask: (title: string, priority: PriorityLevel, category: string, notes?: string) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  toggleHabit: (id: string) => void;
  addHabit: (habit: Omit<Habit, 'id' | 'streak' | 'completedToday' | 'history'>) => void;
  deleteHabit: (id: string) => void;

  // Combustion Engine
  combustion: CombustionStatus;

  // Wisdom & Strategic Journals
  wisdomLessons: WisdomLesson[];
  activeWisdomIndex: number;
  setActiveWisdomIndex: (index: number) => void;
  journalEntries: JournalEntry[];
  addJournalEntry: (entry: Omit<JournalEntry, 'id'>) => void;
  toggleJournalEncryption: (id: string) => Promise<void>;
  deleteJournalEntry: (id: string) => void;

  // ChronoNote Workspace
  chronoNotes: ChronoNote[];
  addChronoNote: (note: Omit<ChronoNote, 'id' | 'timestamp' | 'displayTime' | 'displayDate' | 'wordCount' | 'updatedAt'>) => void;
  updateChronoNote: (id: string, updates: Partial<ChronoNote>) => void;
  deleteChronoNote: (id: string) => void;
  togglePinChronoNote: (id: string) => void;
  toggleChecklistItem: (noteId: string, itemId: string) => void;
  toggleChronoNoteEncryption: (id: string) => Promise<void>;
}

const VaultContext = createContext<VaultContextType | null>(null);

const STORAGE_KEYS = {
  ASSETS: 'autonomous_v5_assets',
  LIABILITIES: 'autonomous_v5_liabilities',
  TRANSACTIONS: 'autonomous_v5_transactions',
  TASKS: 'autonomous_v5_tasks',
  HABITS: 'autonomous_v5_habits',
  JOURNALS: 'autonomous_v5_journals',
  CHRONONOTES: 'autonomous_v5_chrononotes',
  THEME: 'autonomous_v5_theme',
  PIN_HASH: 'autonomous_v5_pin_hash',
  PATTERN: 'autonomous_v5_pattern',
  STEALTH: 'autonomous_v5_stealth',
  AUTOLOCK: 'autonomous_v5_autolock',
  FAILED_ATTEMPTS: 'autonomous_v5_failed_attempts',
  LOCKOUT_TIME: 'autonomous_v5_lockout_time',
};

// Default PIN is 1234
const DEFAULT_PIN = '1234';
// Default Pattern is [0, 1, 2, 5, 8] (L-shaped or Z-matrix)
const DEFAULT_PATTERN = [0, 1, 2, 5, 8];

export const VaultProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeWing, setActiveWing] = useState<ActiveWing>('home');
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [lockoutRemainingSeconds, setLockoutRemainingSeconds] = useState<number>(0);
  const [stealthMode, setStealthMode] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEYS.STEALTH) === 'true';
  });
  const [autoLockMinutes, setAutoLockMinutesState] = useState<number>(() => {
    const val = localStorage.getItem(STORAGE_KEYS.AUTOLOCK);
    return val !== null ? parseInt(val, 10) : 0; // 0 = instant on app blur/minimize
  });

  // Appearance & Theme State
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.THEME) as ThemeMode;
    return saved || 'dark';
  });

  useEffect(() => {
    const applyTheme = () => {
      const root = document.documentElement;
      let isDark = true;
      if (theme === 'system') {
        isDark = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)').matches : true;
      } else {
        isDark = theme === 'dark';
      }

      if (isDark) {
        root.classList.add('dark');
        root.classList.remove('light');
      } else {
        root.classList.remove('dark');
        root.classList.add('light');
      }
    };

    applyTheme();
    localStorage.setItem(STORAGE_KEYS.THEME, theme);

    if (theme === 'system' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    }
  }, [theme]);

  const setTheme = (mode: ThemeMode) => {
    setThemeState(mode);
    playTactileClick();
  };

  const [pinHash, setPinHash] = useState<string>('');
  const [patternSequence, setPatternSequence] = useState<number[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PATTERN);
    return saved ? JSON.parse(saved) : DEFAULT_PATTERN;
  });

  // State collections
  const [assets, setAssets] = useState<Asset[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ASSETS);
    return saved ? JSON.parse(saved) : INITIAL_ASSETS;
  });
  const [liabilities, setLiabilities] = useState<Liability[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LIABILITIES);
    return saved ? JSON.parse(saved) : INITIAL_LIABILITIES;
  });
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TASKS);
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  });
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.HABITS);
    return saved ? JSON.parse(saved) : INITIAL_HABITS;
  });
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.JOURNALS);
    return saved ? JSON.parse(saved) : INITIAL_JOURNAL_ENTRIES;
  });
  const [chronoNotes, setChronoNotes] = useState<ChronoNote[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CHRONONOTES);
    return saved ? JSON.parse(saved) : INITIAL_CHRONONOTES;
  });

  const [activeWisdomIndex, setActiveWisdomIndex] = useState<number>(0);

  // Initialize Salted PIN Hash
  useEffect(() => {
    async function initPin() {
      const savedHash = localStorage.getItem(STORAGE_KEYS.PIN_HASH);
      const salt = getOrCreateDeviceSalt();
      if (!savedHash) {
        const hash = await hashPinWithSalt(DEFAULT_PIN, salt);
        localStorage.setItem(STORAGE_KEYS.PIN_HASH, hash);
        setPinHash(hash);
      } else {
        setPinHash(savedHash);
      }
    }
    initPin();
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(assets));
  }, [assets]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LIABILITIES, JSON.stringify(liabilities));
  }, [liabilities]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks));
  }, [tasks]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HABITS, JSON.stringify(habits));
  }, [habits]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.JOURNALS, JSON.stringify(journalEntries));
  }, [journalEntries]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHRONONOTES, JSON.stringify(chronoNotes));
  }, [chronoNotes]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PATTERN, JSON.stringify(patternSequence));
  }, [patternSequence]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STEALTH, String(stealthMode));
  }, [stealthMode]);

  const setAutoLockMinutes = (mins: number) => {
    setAutoLockMinutesState(mins);
    localStorage.setItem(STORAGE_KEYS.AUTOLOCK, String(mins));
  };

  // Lockout Timer countdown
  useEffect(() => {
    const savedLockout = localStorage.getItem(STORAGE_KEYS.LOCKOUT_TIME);
    if (savedLockout) {
      const until = parseInt(savedLockout, 10);
      const diff = Math.max(0, Math.ceil((until - Date.now()) / 1000));
      if (diff > 0) {
        setLockoutRemainingSeconds(diff);
      } else {
        localStorage.removeItem(STORAGE_KEYS.LOCKOUT_TIME);
      }
    }

    const timer = setInterval(() => {
      setLockoutRemainingSeconds(prev => {
        if (prev <= 1) {
          localStorage.removeItem(STORAGE_KEYS.LOCKOUT_TIME);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Section 2: Security Protocols & Lifecycle Triggers: App Minimize / Switch
  // Instant lock screen overlay upon onPause() or visibilitychange:hidden (ZERO EXPOSURE)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (autoLockMinutes === 0) {
          // Instant lock screen overlay (Zero exposure)
          setIsLocked(true);
        }
      }
    };

    const handleBlur = () => {
      if (autoLockMinutes === 0) {
        setIsLocked(true);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleBlur);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleBlur);
    };
  }, [autoLockMinutes]);

  // Financial Calculations
  const totalNetWorth = useMemo(() => {
    const totalAssets = assets.reduce((sum, a) => sum + (Number(a.amount) || 0), 0);
    const totalLiabilities = liabilities.reduce((sum, l) => sum + (Number(l.amount) || 0), 0);
    return Math.round((totalAssets - totalLiabilities) * 100) / 100;
  }, [assets, liabilities]);

  const { earnedThisMonth, spentThisMonth } = useMemo(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth();

    let earned = 0;
    let spent = 0;

    transactions.forEach(t => {
      const txDate = new Date(t.date);
      // If date is valid and in current month (or for initial seed, all transactions in dataset)
      if (
        !isNaN(txDate.getTime()) &&
        txDate.getFullYear() === currentYear &&
        txDate.getMonth() === currentMonth
      ) {
        if (t.type === 'income') earned += Number(t.amount) || 0;
        if (t.type === 'expense') spent += Number(t.amount) || 0;
      } else {
        // Fallback for seed dataset where months match
        if (t.type === 'income') earned += Number(t.amount) || 0;
        if (t.type === 'expense') spent += Number(t.amount) || 0;
      }
    });

    return {
      earnedThisMonth: Math.round(earned * 100) / 100,
      spentThisMonth: Math.round(spent * 100) / 100,
    };
  }, [transactions]);

  // Section 5: Mathematical Weighting Framework
  // High Priority: 3 Points (Non-Negotiable)
  // Medium Priority: 2 Points (Strategic Progress)
  // Low Priority: 1 Point (Maintenance)
  // Habit Check: 1 Point per completed habit
  // Formula: Score % = Math.round((Earned Pts / Total Possible Pts) * 100)
  // Abyss Trigger: Score >= 91% AND High Priorities Done
  // Executive Performance Rule: "The score dial will never trigger the Abyss aura unless every scheduled high-priority task for today is marked completed, enforcing strict adherence to non-negotiable commitments."
  const combustion: CombustionStatus = useMemo(() => {
    const highTasks = tasks.filter(t => t.priority === 'high');
    const mediumTasks = tasks.filter(t => t.priority === 'medium');
    const lowTasks = tasks.filter(t => t.priority === 'low');

    const highDone = highTasks.filter(t => t.completed);
    const mediumDone = mediumTasks.filter(t => t.completed);
    const lowDone = lowTasks.filter(t => t.completed);
    const habitsDone = habits.filter(h => h.completedToday);

    const earnedPoints =
      highDone.length * 3 +
      mediumDone.length * 2 +
      lowDone.length * 1 +
      habitsDone.length * 1;

    const totalPossiblePoints =
      highTasks.length * 3 +
      mediumTasks.length * 2 +
      lowTasks.length * 1 +
      habits.length * 1;

    const score = totalPossiblePoints > 0 ? Math.round((earnedPoints / totalPossiblePoints) * 100) : 0;
    const allHighDone = highTasks.length > 0 && highDone.length === highTasks.length;

    let phase: CombustionPhase = 'dormant';
    let badgeLabel = 'COMMAND CENTER';
    let colorName = 'Dormant Slate';

    if (score < 30) {
      phase = 'dormant';
      badgeLabel = 'COMMAND CENTER';
      colorName = 'Dormant Slate (0% - 29%)';
    } else if (score <= 60) {
      phase = 'golden';
      badgeLabel = 'GOLDEN FLAME 🔥';
      colorName = 'Golden Ember (30% - 60%)';
    } else if (score <= 80) {
      phase = 'electric';
      badgeLabel = 'ELECTRIC BLUE 🔥';
      colorName = 'Electric Blue (61% - 80%)';
    } else if (score <= 90) {
      phase = 'crimson';
      badgeLabel = 'CRIMSON FLAME 🔥';
      colorName = 'Crimson Flame (81% - 90%)';
    } else {
      // Score >= 91%
      if (allHighDone) {
        phase = 'abyss';
        badgeLabel = 'CRIMSON BLACK ABYSS 🔥';
        colorName = 'Crimson Black Abyss (91% - 100%)';
      } else {
        // Executive Performance Rule blocks Abyss!
        phase = 'crimson';
        badgeLabel = 'HIGH PRIORITY PENDING (CRIMSON)';
        colorName = 'Abyss Blocked: Non-Negotiables Incomplete';
      }
    }

    return {
      score,
      earnedPoints,
      totalPossiblePoints,
      phase,
      allHighDone,
      highCount: highTasks.length,
      highDoneCount: highDone.length,
      badgeLabel,
      colorName,
    };
  }, [tasks, habits]);

  // Security Verification Methods
  const handleFailedAttempt = () => {
    triggerHaptic('lockout');
    const newCount = failedAttempts + 1;
    setFailedAttempts(newCount);
    localStorage.setItem(STORAGE_KEYS.FAILED_ATTEMPTS, String(newCount));

    if (newCount >= 5) {
      // 30-second exponential lockout penalty with vibration warning and biometric disable
      const penaltySeconds = 30 * Math.pow(2, Math.min(newCount - 5, 4));
      const lockoutTimestamp = Date.now() + penaltySeconds * 1000;
      localStorage.setItem(STORAGE_KEYS.LOCKOUT_TIME, String(lockoutTimestamp));
      setLockoutRemainingSeconds(penaltySeconds);
    }
  };

  const verifyPin = async (inputPin: string): Promise<boolean> => {
    if (lockoutRemainingSeconds > 0) return false;
    const salt = getOrCreateDeviceSalt();
    const hash = await hashPinWithSalt(inputPin, salt);
    if (hash === pinHash) {
      setFailedAttempts(0);
      localStorage.removeItem(STORAGE_KEYS.FAILED_ATTEMPTS);
      triggerHaptic('success');
      playUnlockChord();
      setIsLocked(false);
      return true;
    } else {
      handleFailedAttempt();
      return false;
    }
  };

  const verifyPattern = async (inputSeq: number[]): Promise<boolean> => {
    if (lockoutRemainingSeconds > 0) return false;
    const isMatch =
      inputSeq.length === patternSequence.length &&
      inputSeq.every((val, idx) => val === patternSequence[idx]);

    if (isMatch) {
      setFailedAttempts(0);
      localStorage.removeItem(STORAGE_KEYS.FAILED_ATTEMPTS);
      triggerHaptic('success');
      playUnlockChord();
      setIsLocked(false);
      return true;
    } else {
      handleFailedAttempt();
      return false;
    }
  };

  const verifyBiometric = async (): Promise<{ success: boolean; message: string }> => {
    if (lockoutRemainingSeconds > 0) {
      return { success: false, message: `Vault Locked. Wait ${lockoutRemainingSeconds}s.` };
    }
    const res = await invokeBiometricAuthentication();
    if (res.success) {
      setFailedAttempts(0);
      localStorage.removeItem(STORAGE_KEYS.FAILED_ATTEMPTS);
      playUnlockChord();
      setIsLocked(false);
    }
    return res;
  };

  const lockVault = () => {
    triggerHaptic('heavy');
    setIsLocked(true);
  };

  const unlockVault = () => {
    playUnlockChord();
    setIsLocked(false);
  };

  const updateMasterPin = async (newPin: string): Promise<boolean> => {
    if (newPin.length < 4) return false;
    const salt = getOrCreateDeviceSalt();
    const hash = await hashPinWithSalt(newPin, salt);
    setPinHash(hash);
    localStorage.setItem(STORAGE_KEYS.PIN_HASH, hash);
    triggerHaptic('success');
    return true;
  };

  const updateMasterPattern = (newSequence: number[]) => {
    if (newSequence.length >= 3) {
      setPatternSequence(newSequence);
      localStorage.setItem(STORAGE_KEYS.PATTERN, JSON.stringify(newSequence));
      triggerHaptic('success');
    }
  };

  // Export encrypted vault
  const exportEncryptedVault = async (password: string): Promise<string> => {
    const vaultData = {
      version: '4.0.0',
      exportedAt: new Date().toISOString(),
      assets,
      liabilities,
      transactions,
      tasks,
      habits,
      journalEntries,
    };
    const salt = getOrCreateDeviceSalt();
    const jsonString = JSON.stringify(vaultData);
    const encrypted = await encryptTextAesGcm(jsonString, password, salt);
    return JSON.stringify({
      app: 'Autonomous_v4_Vault',
      salt,
      cipher: encrypted,
    });
  };

  // Import encrypted vault
  const importEncryptedVault = async (cipherEnvelope: string, password: string): Promise<boolean> => {
    try {
      const parsed = JSON.parse(cipherEnvelope);
      if (!parsed.cipher || !parsed.salt) return false;
      const decrypted = await decryptTextAesGcm(parsed.cipher, password, parsed.salt);
      const data = JSON.parse(decrypted);

      if (data.assets) setAssets(data.assets);
      if (data.liabilities) setLiabilities(data.liabilities);
      if (data.transactions) setTransactions(data.transactions);
      if (data.tasks) setTasks(data.tasks);
      if (data.habits) setHabits(data.habits);
      if (data.journalEntries) setJournalEntries(data.journalEntries);

      triggerHaptic('success');
      return true;
    } catch (e) {
      console.error('Import failed', e);
      return false;
    }
  };

  // Download device storage backup (.vault file saved directly to device storage)
  const downloadDeviceBackup = async (customPassword?: string): Promise<{ filename: string; stats: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number } }> => {
    const password = customPassword?.trim() || DEFAULT_PIN;
    const salt = getOrCreateDeviceSalt();
    const vaultData = {
      app: 'Autonomous v5.0.0',
      version: '5.0.0',
      exportedAt: new Date().toISOString(),
      theme,
      security: {
        patternSequence,
        stealthMode,
        autoLockMinutes,
        salt,
      },
      assets,
      liabilities,
      transactions,
      tasks,
      habits,
      journalEntries,
      chronoNotes,
    };

    const stats = {
      assets: assets.length,
      liabilities: liabilities.length,
      txs: transactions.length,
      tasks: tasks.length,
      habits: habits.length,
      journals: journalEntries.length,
      chronoNotes: chronoNotes.length,
    };

    const jsonString = JSON.stringify(vaultData, null, 2);
    const encrypted = await encryptTextAesGcm(jsonString, password, salt);
    const filePayload = JSON.stringify({
      header: 'AUTONOMOUS_V5_SECURE_VAULT_BACKUP',
      encryptedAt: new Date().toISOString(),
      salt,
      isEncrypted: true,
      stats,
      cipher: encrypted,
    }, null, 2);

    const dateStr = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = `autonomous-v5-backup-${dateStr}.vault`;

    // Check if Android Native bridge has custom file saver
    const androidBridge = (window as unknown as { AndroidBridge?: { saveBackupToStorage?: (fn: string, data: string) => boolean } }).AndroidBridge;
    if (androidBridge && typeof androidBridge.saveBackupToStorage === 'function') {
      try {
        androidBridge.saveBackupToStorage(filename, filePayload);
        triggerHaptic('success');
        return { filename, stats };
      } catch (err) {
        console.warn('Android saveBackupToStorage fallback to web download', err);
      }
    }

    // Web Standard Blob Download directly to device storage / Downloads folder
    const blob = new Blob([filePayload], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    triggerHaptic('success');
    return { filename, stats };
  };

  // Restore from device storage file (picked from device file explorer)
  const restoreFromDeviceFile = async (file: File, password?: string): Promise<{ success: boolean; message: string; stats?: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number } }> => {
    try {
      const text = await file.text();
      let payload: any;
      try {
        payload = JSON.parse(text);
      } catch {
        return {
          success: false,
          message: 'Invalid file format: Not a valid JSON or .vault payload.',
        };
      }

      let data: any = null;

      if (payload.cipher && payload.salt) {
        // Encrypted envelope
        const key = password?.trim() || DEFAULT_PIN;
        try {
          const decrypted = await decryptTextAesGcm(payload.cipher, key, payload.salt);
          data = JSON.parse(decrypted);
        } catch {
          return {
            success: false,
            message: 'Decryption failed: Incorrect master password or corrupted backup file.',
          };
        }
      } else if (payload.assets || payload.tasks || payload.chronoNotes) {
        // Raw backup format
        data = payload;
      } else {
        return {
          success: false,
          message: 'Unrecognized backup format. Please select an Autonomous .vault backup file.',
        };
      }

      // Restore states
      if (Array.isArray(data.assets)) setAssets(data.assets);
      if (Array.isArray(data.liabilities)) setLiabilities(data.liabilities);
      if (Array.isArray(data.transactions)) setTransactions(data.transactions);
      if (Array.isArray(data.tasks)) setTasks(data.tasks);
      if (Array.isArray(data.habits)) setHabits(data.habits);
      if (Array.isArray(data.journalEntries)) setJournalEntries(data.journalEntries);
      if (Array.isArray(data.chronoNotes)) setChronoNotes(data.chronoNotes);
      if (data.theme && (data.theme === 'dark' || data.theme === 'light' || data.theme === 'system')) {
        setTheme(data.theme);
      }

      if (data.security) {
        if (Array.isArray(data.security.patternSequence)) {
          setPatternSequence(data.security.patternSequence);
          localStorage.setItem(STORAGE_KEYS.PATTERN, JSON.stringify(data.security.patternSequence));
        }
        if (typeof data.security.stealthMode === 'boolean') {
          setStealthMode(data.security.stealthMode);
          localStorage.setItem(STORAGE_KEYS.STEALTH, String(data.security.stealthMode));
        }
        if (typeof data.security.autoLockMinutes === 'number') {
          setAutoLockMinutesState(data.security.autoLockMinutes);
          localStorage.setItem(STORAGE_KEYS.AUTOLOCK, String(data.security.autoLockMinutes));
        }
      }

      const stats = {
        assets: data.assets?.length || 0,
        liabilities: data.liabilities?.length || 0,
        txs: data.transactions?.length || 0,
        tasks: data.tasks?.length || 0,
        habits: data.habits?.length || 0,
        journals: data.journalEntries?.length || 0,
        chronoNotes: data.chronoNotes?.length || 0,
      };

      triggerHaptic('success');
      playUnlockChord();

      return {
        success: true,
        message: `Successfully restored backup from ${file.name}!`,
        stats,
      };
    } catch (err: any) {
      console.error('File restoration failed', err);
      return {
        success: false,
        message: `Error reading file: ${err.message || 'File is corrupted'}`,
      };
    }
  };

  const resetToMasterDefaults = () => {
    setAssets(INITIAL_ASSETS);
    setLiabilities(INITIAL_LIABILITIES);
    setTransactions(INITIAL_TRANSACTIONS);
    setTasks(INITIAL_TASKS);
    setHabits(INITIAL_HABITS);
    setJournalEntries(INITIAL_JOURNAL_ENTRIES);
    setChronoNotes(INITIAL_CHRONONOTES);
    setPatternSequence(DEFAULT_PATTERN);
    triggerHaptic('success');
  };

  // Task Handlers
  const addTask = (title: string, priority: PriorityLevel, category: string, notes?: string) => {
    const newTask: Task = {
      id: 'tsk-' + Date.now(),
      title,
      priority,
      completed: false,
      dueDate: new Date().toISOString().split('T')[0],
      category: category || 'Execution',
      notes,
      createdAt: new Date().toISOString(),
    };
    setTasks(prev => [newTask, ...prev]);
    playTactileClick();
  };

  const toggleTask = (id: string) => {
    setTasks(prev =>
      prev.map(t => {
        if (t.id === id) {
          const updated = { ...t, completed: !t.completed };
          playTactileClick(t.completed ? 450 : 880);
          triggerHaptic('tap');
          return updated;
        }
        return t;
      })
    );
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    playTactileClick(300);
  };

  // Habit Handlers
  const toggleHabit = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    setHabits(prev =>
      prev.map(h => {
        if (h.id === id) {
          const nextCompleted = !h.completedToday;
          let newStreak = h.streak;
          let newHistory = [...h.history];
          if (nextCompleted) {
            newStreak += 1;
            if (!newHistory.includes(today)) newHistory.push(today);
          } else {
            newStreak = Math.max(0, newStreak - 1);
            newHistory = newHistory.filter(d => d !== today);
          }
          playTactileClick(nextCompleted ? 900 : 400);
          triggerHaptic('node');
          return {
            ...h,
            completedToday: nextCompleted,
            streak: newStreak,
            history: newHistory,
          };
        }
        return h;
      })
    );
  };

  const addHabit = (habitData: Omit<Habit, 'id' | 'streak' | 'completedToday' | 'history'>) => {
    const newHabit: Habit = {
      ...habitData,
      id: 'hbt-' + Date.now(),
      streak: 0,
      completedToday: false,
      history: [],
    };
    setHabits(prev => [...prev, newHabit]);
    playTactileClick();
  };

  const deleteHabit = (id: string) => {
    setHabits(prev => prev.filter(h => h.id !== id));
  };

  // Assets & Liabilities
  const addAsset = (asset: Omit<Asset, 'id' | 'updatedAt'>) => {
    const newAsset: Asset = {
      ...asset,
      id: 'ast-' + Date.now(),
      updatedAt: new Date().toISOString().split('T')[0],
    };
    setAssets(prev => [newAsset, ...prev]);
    playTactileClick();
  };

  const updateAsset = (id: string, updates: Partial<Asset>) => {
    setAssets(prev =>
      prev.map(a => (a.id === id ? { ...a, ...updates, updatedAt: new Date().toISOString().split('T')[0] } : a))
    );
  };

  const deleteAsset = (id: string) => {
    setAssets(prev => prev.filter(a => a.id !== id));
  };

  const addLiability = (liability: Omit<Liability, 'id'>) => {
    const newLiability: Liability = {
      ...liability,
      id: 'lia-' + Date.now(),
    };
    setLiabilities(prev => [newLiability, ...prev]);
    playTactileClick();
  };

  const updateLiability = (id: string, updates: Partial<Liability>) => {
    setLiabilities(prev => prev.map(l => (l.id === id ? { ...l, ...updates } : l)));
  };

  const deleteLiability = (id: string) => {
    setLiabilities(prev => prev.filter(l => l.id !== id));
  };

  const addTransaction = (tx: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      ...tx,
      id: 'tx-' + Date.now(),
    };
    setTransactions(prev => [newTx, ...prev]);
    playTactileClick();
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(t => t.id !== id));
  };

  // Journal Handlers
  const addJournalEntry = (entry: Omit<JournalEntry, 'id'>) => {
    const newEntry: JournalEntry = {
      ...entry,
      id: 'jrn-' + Date.now(),
    };
    setJournalEntries(prev => [newEntry, ...prev]);
    playTactileClick();
  };

  const toggleJournalEncryption = async (id: string) => {
    const target = journalEntries.find(j => j.id === id);
    if (!target) return;
    const salt = getOrCreateDeviceSalt();

    if (!target.isEncrypted) {
      // Encrypt with default salt & PIN key
      const cipher = await encryptTextAesGcm(target.content, DEFAULT_PIN, salt);
      setJournalEntries(prev =>
        prev.map(j => (j.id === id ? { ...j, content: cipher, isEncrypted: true } : j))
      );
      triggerHaptic('success');
    } else {
      // Decrypt
      try {
        const plain = await decryptTextAesGcm(target.content, DEFAULT_PIN, salt);
        setJournalEntries(prev =>
          prev.map(j => (j.id === id ? { ...j, content: plain, isEncrypted: false } : j))
        );
        triggerHaptic('tap');
      } catch (err) {
        alert('Decryption failed: Master key mismatch');
      }
    }
  };

  const deleteJournalEntry = (id: string) => {
    setJournalEntries(prev => prev.filter(j => j.id !== id));
  };

  // ChronoNote Handlers
  const addChronoNote = (noteData: Omit<ChronoNote, 'id' | 'timestamp' | 'displayTime' | 'displayDate' | 'wordCount' | 'updatedAt'>) => {
    const now = new Date();
    const displayTime = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
    const displayDate = now.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
    const wordCount = noteData.content.trim() ? noteData.content.trim().split(/\s+/).length : 0;
    const newNote: ChronoNote = {
      ...noteData,
      id: 'cn-' + Date.now(),
      timestamp: now.toISOString(),
      displayTime,
      displayDate,
      wordCount,
      updatedAt: now.toISOString(),
    };
    setChronoNotes(prev => [newNote, ...prev]);
    playTactileClick(650);
    triggerHaptic('tap');
  };

  const updateChronoNote = (id: string, updates: Partial<ChronoNote>) => {
    setChronoNotes(prev =>
      prev.map(n => {
        if (n.id === id) {
          const updated = { ...n, ...updates, updatedAt: new Date().toISOString() };
          if (updates.content !== undefined) {
            updated.wordCount = updates.content.trim() ? updates.content.trim().split(/\s+/).length : 0;
          }
          return updated;
        }
        return n;
      })
    );
  };

  const deleteChronoNote = (id: string) => {
    setChronoNotes(prev => prev.filter(n => n.id !== id));
    playTactileClick(300);
  };

  const togglePinChronoNote = (id: string) => {
    setChronoNotes(prev =>
      prev.map(n => (n.id === id ? { ...n, isPinned: !n.isPinned, updatedAt: new Date().toISOString() } : n))
    );
    playTactileClick(700);
    triggerHaptic('tap');
  };

  const toggleChecklistItem = (noteId: string, itemId: string) => {
    setChronoNotes(prev =>
      prev.map(n => {
        if (n.id === noteId && n.checklist) {
          const updatedChecklist = n.checklist.map(item =>
            item.id === itemId ? { ...item, completed: !item.completed } : item
          );
          return { ...n, checklist: updatedChecklist, updatedAt: new Date().toISOString() };
        }
        return n;
      })
    );
    playTactileClick(850);
    triggerHaptic('node');
  };

  const toggleChronoNoteEncryption = async (id: string) => {
    const target = chronoNotes.find(n => n.id === id);
    if (!target) return;
    const salt = getOrCreateDeviceSalt();

    if (!target.isEncrypted) {
      const cipher = await encryptTextAesGcm(target.content, DEFAULT_PIN, salt);
      setChronoNotes(prev =>
        prev.map(n => (n.id === id ? { ...n, content: cipher, isEncrypted: true, updatedAt: new Date().toISOString() } : n))
      );
      triggerHaptic('success');
    } else {
      try {
        const plain = await decryptTextAesGcm(target.content, DEFAULT_PIN, salt);
        setChronoNotes(prev =>
          prev.map(n => (n.id === id ? { ...n, content: plain, isEncrypted: false, updatedAt: new Date().toISOString() } : n))
        );
        triggerHaptic('tap');
      } catch (err) {
        alert('Decryption failed: Master key mismatch');
      }
    }
  };

  return (
    <VaultContext.Provider
      value={{
        activeWing,
        setActiveWing,
        theme,
        setTheme,
        isLocked,
        failedAttempts,
        lockoutRemainingSeconds,
        stealthMode,
        autoLockMinutes,
        verifyPin,
        verifyPattern,
        verifyBiometric,
        lockVault,
        unlockVault,
        setStealthMode,
        setAutoLockMinutes,
        updateMasterPin,
        updateMasterPattern,
        exportEncryptedVault,
        importEncryptedVault,
        downloadDeviceBackup,
        restoreFromDeviceFile,
        resetToMasterDefaults,
        totalNetWorth,
        earnedThisMonth,
        spentThisMonth,
        assets,
        liabilities,
        transactions,
        addAsset,
        updateAsset,
        deleteAsset,
        addLiability,
        updateLiability,
        deleteLiability,
        addTransaction,
        deleteTransaction,
        tasks,
        habits,
        addTask,
        toggleTask,
        deleteTask,
        toggleHabit,
        addHabit,
        deleteHabit,
        combustion,
        wisdomLessons: CURATED_WISDOM_LESSONS,
        activeWisdomIndex,
        setActiveWisdomIndex,
        journalEntries,
        addJournalEntry,
        toggleJournalEncryption,
        deleteJournalEntry,
        chronoNotes,
        addChronoNote,
        updateChronoNote,
        deleteChronoNote,
        togglePinChronoNote,
        toggleChecklistItem,
        toggleChronoNoteEncryption,
      }}
    >
      {children}
    </VaultContext.Provider>
  );
};

export const useVault = () => {
  const context = useContext(VaultContext);
  if (!context) {
    throw new Error('useVault must be used within a VaultProvider');
  }
  return context;
};
