/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { useVault } from '../../context/VaultContext';
import { ChronoNote, ChronoNoteCategory } from '../../types';
import {
  BookOpen,
  Pin,
  Lock,
  Unlock,
  Trash2,
  Plus,
  Search,
  CheckSquare,
  Square,
  Tag,
  Clock,
  Sparkles,
  FileText,
  Copy,
  Check,
  Share2,
  Calendar,
  Layers,
  Flame,
} from 'lucide-react';

type CategoryFilter = ChronoNoteCategory | 'all';

const CATEGORIES: { id: CategoryFilter; label: string; color: string }[] = [
  { id: 'all', label: 'All Notes', color: 'border-slate-500/40 text-slate-200' },
  { id: 'Executive', label: 'Executive', color: 'border-rose-500/50 text-rose-300' },
  { id: 'Architecture', label: 'Architecture', color: 'border-cyan-500/50 text-cyan-300' },
  { id: 'Strategic', label: 'Strategic', color: 'border-amber-500/50 text-amber-300' },
  { id: 'Sprint', label: 'Sprint', color: 'border-emerald-500/50 text-emerald-300' },
  { id: 'Tactical', label: 'Tactical', color: 'border-blue-500/50 text-blue-300' },
  { id: 'Personal', label: 'Personal', color: 'border-purple-500/50 text-purple-300' },
];

export const ChronoNoteWorkspace: React.FC = () => {
  const {
    chronoNotes,
    addChronoNote,
    deleteChronoNote,
    togglePinChronoNote,
    toggleChecklistItem,
    toggleChronoNoteEncryption,
  } = useVault();

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('all');
  const [showCaptureModal, setShowCaptureModal] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New Note Form State
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<ChronoNoteCategory>('Executive');
  const [newContent, setNewContent] = useState('');
  const [newTagsStr, setNewTagsStr] = useState('');
  const [newChecklistText, setNewChecklistText] = useState('');
  const [isEncryptedFlag, setIsEncryptedFlag] = useState(false);

  // Filtered Notes (pinned first, then chronological descending)
  const filteredNotes = useMemo(() => {
    return chronoNotes
      .filter(note => {
        const matchesCategory =
          selectedCategory === 'all' || note.category === selectedCategory;
        const matchesSearch =
          searchQuery.trim() === '' ||
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      });
  }, [chronoNotes, selectedCategory, searchQuery]);

  // Handle Quick Note Submission
  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() && !newContent.trim()) return;

    // Parse tags: split by comma or spaces
    const tags = newTagsStr
      .split(/[\s,]+/)
      .map(t => t.trim().replace(/^#/, ''))
      .filter(t => t.length > 0)
      .map(t => `#${t}`);

    // Parse checklist lines
    const checklistLines = newChecklistText
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0);

    const checklist = checklistLines.length > 0
      ? checklistLines.map((line, idx) => ({
          id: `item-${Date.now()}-${idx}`,
          text: line.replace(/^-\s*(\[[ xX]\])?\s*/, ''),
          completed: /^-\s*\[[xX]\]/.test(line),
        }))
      : undefined;

    addChronoNote({
      title: newTitle.trim() || 'Untitled Strategic Entry',
      content: newContent.trim(),
      category: newCategory,
      tags,
      isPinned: false,
      isEncrypted: isEncryptedFlag,
      checklist,
    });

    // Reset Form
    setNewTitle('');
    setNewContent('');
    setNewTagsStr('');
    setNewChecklistText('');
    setIsEncryptedFlag(false);
    setShowCaptureModal(false);
  };

  const handleCopyNote = (note: ChronoNote) => {
    const text = `# ${note.title}\n[${note.displayDate} • ${note.displayTime}] [${note.category}]\n\n${note.content}\n\n${
      note.checklist ? note.checklist.map(c => `- [${c.completed ? 'x' : ' '}] ${c.text}`).join('\n') : ''
    }\n\nTags: ${note.tags.join(' ')}`;
    navigator.clipboard.writeText(text);
    setCopiedId(note.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Workspace Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-rose-950/60 via-neutral-900/80 to-black border border-rose-900/40 p-5 sm:p-6 shadow-xl backdrop-blur-xl">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30">
                <BookOpen className="w-4 h-4" />
              </span>
              <span className="text-xs font-mono uppercase tracking-wider text-rose-400 font-bold">
                CHRONONOTE WORKSPACE • AUTONOMOUS v5.0.0
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white font-display">
              Chronological Intelligence & Strategic Notes
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Real-time timeline note engine with military-grade offline persistence, zero-knowledge AES-GCM encryption, interactive checklists, and instantaneous categorization.
            </p>
          </div>

          {/* Quick Capture Button */}
          <button
            type="button"
            onClick={() => setShowCaptureModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-rose-900/40 border border-rose-400/30 transition-all hover:scale-[1.02] active:scale-[0.98] shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>New ChronoNote</span>
          </button>
        </div>

        {/* Ambient glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Control Bar: Search & Category Chips */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by keywords, tags (#sprint), or content..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-neutral-900/90 border border-white/10 text-slate-100 placeholder-slate-500 text-xs sm:text-sm focus:outline-none focus:border-rose-500 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-200"
              >
                Clear
              </button>
            )}
          </div>

          <div className="text-xs font-mono text-slate-400 self-center shrink-0">
            {filteredNotes.length} {filteredNotes.length === 1 ? 'entry' : 'entries'} logged
          </div>
        </div>

        {/* Category Horizontal Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar">
          {CATEGORIES.map(cat => {
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-all border ${
                  active
                    ? 'bg-rose-950/80 text-rose-200 border-rose-500 shadow-sm'
                    : 'bg-neutral-900/70 text-slate-400 hover:text-slate-200 border-white/5 hover:border-white/20'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Notes Stream / Feed */}
      {filteredNotes.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-2xl bg-neutral-900/40 border border-dashed border-white/10">
          <BookOpen className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-300">No ChronoNotes found</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            {searchQuery
              ? `No entries match "${searchQuery}". Try a different keyword or reset filters.`
              : 'Create your first strategic note or timeline entry using the button above.'}
          </p>
          <button
            type="button"
            onClick={() => setShowCaptureModal(true)}
            className="mt-4 px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-medium transition-all"
          >
            Create Note Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredNotes.map(note => (
            <div
              key={note.id}
              className={`group relative flex flex-col justify-between rounded-xl bg-neutral-900/90 border transition-all duration-200 hover:shadow-xl ${
                note.isPinned
                  ? 'border-rose-500/60 bg-gradient-to-b from-rose-950/20 to-neutral-900/90 shadow-[0_0_15px_rgba(225,29,72,0.1)]'
                  : 'border-white/10 hover:border-white/25'
              }`}
            >
              {/* Card Header */}
              <div className="p-4 pb-2 border-b border-white/5">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400 mb-1">
                      <Clock className="w-3 h-3 text-emerald-400" />
                      <span>{note.displayDate}</span>
                      <span>•</span>
                      <span>{note.displayTime}</span>
                    </div>
                    <h3 className="text-sm font-bold text-white group-hover:text-rose-200 transition-colors truncate">
                      {note.title}
                    </h3>
                  </div>

                  {/* Top Right Action Icons */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => togglePinChronoNote(note.id)}
                      title={note.isPinned ? 'Unpin note' : 'Pin to top'}
                      className={`p-1.5 rounded-md text-xs transition-colors ${
                        note.isPinned
                          ? 'text-rose-400 bg-rose-950/60 border border-rose-800/60'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      <Pin className={`w-3.5 h-3.5 ${note.isPinned ? 'fill-rose-400' : ''}`} />
                    </button>
                    <button
                      type="button"
                      onClick={() => toggleChronoNoteEncryption(note.id)}
                      title={note.isEncrypted ? 'Decrypt with Master Key' : 'Encrypt with AES-GCM'}
                      className={`p-1.5 rounded-md text-xs transition-colors ${
                        note.isEncrypted
                          ? 'text-amber-400 bg-amber-950/50 border border-amber-800/50'
                          : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
                      }`}
                    >
                      {note.isEncrypted ? (
                        <Lock className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <Unlock className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Badges: Category & Word Count */}
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-slate-300 font-semibold">
                    {note.category}
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">
                    {note.wordCount} {note.wordCount === 1 ? 'word' : 'words'}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-4 flex-1 space-y-3">
                {note.isEncrypted ? (
                  <div className="p-3 rounded-lg bg-black/50 border border-amber-900/40 text-amber-400/80 font-mono text-xs break-all leading-relaxed">
                    <div className="flex items-center gap-1.5 font-bold mb-1 text-amber-300">
                      <Lock className="w-3 h-3" />
                      <span>AES-GCM 256-BIT ENCRYPTED</span>
                    </div>
                    {note.content.substring(0, 90)}...
                  </div>
                ) : (
                  <p className="text-xs text-slate-300 whitespace-pre-wrap leading-relaxed line-clamp-6">
                    {note.content}
                  </p>
                )}

                {/* Checklists if any */}
                {note.checklist && note.checklist.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-white/5">
                    <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">
                      Execution Milestones:
                    </span>
                    <div className="space-y-1">
                      {note.checklist.map(item => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => toggleChecklistItem(note.id, item.id)}
                          className="flex items-center gap-2 text-left w-full group/item text-xs text-slate-300 hover:text-white transition-colors"
                        >
                          {item.completed ? (
                            <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          ) : (
                            <Square className="w-3.5 h-3.5 text-slate-500 group-hover/item:text-slate-300 shrink-0" />
                          )}
                          <span
                            className={item.completed ? 'line-through text-slate-500' : ''}
                          >
                            {item.text}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Tags */}
                {note.tags.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1 pt-2">
                    {note.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-rose-950/40 text-rose-300 border border-rose-900/40"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Card Footer */}
              <div className="p-3 bg-black/40 border-t border-white/5 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => handleCopyNote(note)}
                  className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 transition-colors"
                  title="Copy note markdown"
                >
                  {copiedId === note.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-[10px] text-emerald-400 font-mono">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="text-[10px] font-mono">Copy</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (confirm(`Delete ChronoNote "${note.title}"?`)) {
                      deleteChronoNote(note.id);
                    }
                  }}
                  className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                  title="Delete note"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Quick Capture Modal Overlay */}
      {showCaptureModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-xl rounded-2xl bg-neutral-950 border border-white/20 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-rose-500" />
                <h2 className="text-base font-bold text-white font-display">
                  New ChronoNote Entry
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowCaptureModal(false)}
                className="text-slate-400 hover:text-white text-xs font-mono p-1 rounded-md hover:bg-white/10"
              >
                ✕ Esc
              </button>
            </div>

            <form onSubmit={handleCreateNote} className="space-y-4">
              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Title / Subject
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Master Operational Sprint Directive"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Category Wing
                  </label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as ChronoNoteCategory)}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-500"
                  >
                    <option value="Executive">Executive</option>
                    <option value="Architecture">Architecture</option>
                    <option value="Strategic">Strategic</option>
                    <option value="Sprint">Sprint</option>
                    <option value="Tactical">Tactical</option>
                    <option value="Personal">Personal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Tags (space or comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="#security #release #v5"
                    value={newTagsStr}
                    onChange={e => setNewTagsStr(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Note Content / Directive
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Record strategic thinking, system architecture updates, or executive logs..."
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white text-sm focus:outline-none focus:border-rose-500 font-sans leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Actionable Checklist Items (One per line, optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Verify APK signing keys&#10;Audit offline storage bridge&#10;Deploy release to production"
                  value={newChecklistText}
                  onChange={e => setNewChecklistText(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-neutral-900 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                  <input
                    type="checkbox"
                    checked={isEncryptedFlag}
                    onChange={e => setIsEncryptedFlag(e.target.checked)}
                    className="rounded bg-neutral-800 border-white/20 text-rose-500 focus:ring-0"
                  />
                  <span>Encrypt with Master AES-GCM Key</span>
                </label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowCaptureModal(false)}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-lg shadow-rose-900/40 transition-all"
                  >
                    Save ChronoNote
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
