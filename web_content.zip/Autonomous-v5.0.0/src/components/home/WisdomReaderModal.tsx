/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { WisdomLesson } from '../../types';
import { BookOpen, X, Sparkles, CheckCircle2, ArrowRight } from 'lucide-react';

interface WisdomReaderModalProps {
  lesson: WisdomLesson | null;
  onClose: () => void;
  onNextLesson: () => void;
  onPrevLesson: () => void;
}

export const WisdomReaderModal: React.FC<WisdomReaderModalProps> = ({
  lesson,
  onClose,
  onNextLesson,
  onPrevLesson,
}) => {
  if (!lesson) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-[#0e0e16] border border-white/10 shadow-2xl p-6 sm:p-8 my-8 text-left">
        {/* Header Bar */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-950/60 border border-amber-600/40 flex items-center justify-center text-amber-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-amber-400 font-bold">
                Executive Book Brief
              </div>
              <div className="text-base font-bold text-white tracking-tight">
                {lesson.bookTitle}
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Book & Author Header */}
        <div className="mb-6">
          <div className="text-xs font-mono text-slate-400 mb-1">
            Author: <span className="text-slate-200 font-medium">{lesson.author}</span> • {lesson.chapterOrLaw}
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
            "{lesson.headline}"
          </h2>
        </div>

        {/* Core Principle Card */}
        <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-600/30 mb-6">
          <div className="flex items-center gap-2 text-xs font-mono text-amber-400 font-semibold mb-1">
            <Sparkles className="w-4 h-4" />
            <span>CORE DOCTRINE:</span>
          </div>
          <div className="text-sm font-semibold text-amber-200">
            {lesson.corePrinciple}
          </div>
        </div>

        {/* Detailed Strategic Insight */}
        <div className="space-y-4 mb-6">
          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-1 font-semibold">
              Strategic Insight & Mechanism
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed bg-black/30 p-4 rounded-xl border border-white/5">
              {lesson.strategicInsight}
            </p>
          </div>

          <div>
            <h4 className="text-xs font-mono uppercase tracking-wider text-rose-400 mb-1 font-semibold flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Immediate Executive Action</span>
            </h4>
            <div className="text-sm text-rose-100 bg-rose-950/30 p-4 rounded-xl border border-rose-800/40 font-medium">
              {lesson.executiveAction}
            </div>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mb-6">
          {lesson.tags.map(tag => (
            <span
              key={tag}
              className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-white/5 text-slate-400 border border-white/5"
            >
              #{tag}
            </span>
          ))}
        </div>

        {/* Footer Navigation */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-between">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onPrevLesson}
              className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300 transition-colors"
            >
              ← Previous Book
            </button>
            <button
              type="button"
              onClick={onNextLesson}
              className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300 transition-colors flex items-center gap-1"
            >
              <span>Next Book</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-900 to-rose-700 hover:from-rose-800 hover:to-rose-600 text-xs font-medium text-white transition-all shadow-md"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
