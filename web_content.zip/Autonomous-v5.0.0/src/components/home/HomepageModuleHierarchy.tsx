/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { ActiveWing, Task } from '../../types';
import { CombustionFlameDial } from './CombustionFlameDial';
import { WisdomReaderModal } from './WisdomReaderModal';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  CheckSquare,
  Compass,
  Wallet,
  Activity,
  BookOpen,
  ArrowRight,
  Flame,
  CheckCircle2,
  Circle,
  Plus,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

export const HomepageModuleHierarchy: React.FC = () => {
  const {
    totalNetWorth,
    earnedThisMonth,
    spentThisMonth,
    setActiveWing,
    combustion,
    wisdomLessons,
    activeWisdomIndex,
    setActiveWisdomIndex,
    tasks,
    toggleTask,
    habits,
    toggleHabit,
    addTransaction,
    addTask,
  } = useVault();

  const [isReaderOpen, setIsReaderOpen] = useState<boolean>(false);
  const [simulatedScore, setSimulatedScore] = useState<number | null>(null);
  const [showQuickTxModal, setShowQuickTxModal] = useState<boolean>(false);
  const [quickTxType, setQuickTxType] = useState<'income' | 'expense'>('expense');
  const [quickTxAmount, setQuickTxAmount] = useState<string>('');
  const [quickTxTitle, setQuickTxTitle] = useState<string>('');
  const [quickTxCat, setQuickTxCat] = useState<string>('Ops');

  // Active wisdom lesson
  const currentLesson = wisdomLessons[activeWisdomIndex % wisdomLessons.length];

  // Top 3 Non-Negotiable Priorities (High Priority tasks for today)
  const highPriorityTasks = tasks.filter(t => t.priority === 'high');
  const top3NonNegotiables = highPriorityTasks.slice(0, 3);

  // Quick Transaction submission
  const handleCreateTx = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(quickTxAmount);
    if (isNaN(amt) || amt <= 0 || !quickTxTitle.trim()) return;

    addTransaction({
      type: quickTxType,
      title: quickTxTitle.trim(),
      amount: amt,
      category: quickTxCat,
      date: new Date().toISOString().split('T')[0],
      account: 'Primary Operating Liquidity',
    });

    setQuickTxAmount('');
    setQuickTxTitle('');
    setShowQuickTxModal(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* ======================================================== */}
      {/* 1st: INCOME & EXPENSE STATUS DASHBOARD (TOP PINNED) */}
      {/* ======================================================== */}
      <section className="relative rounded-2xl border border-amber-500/20 bg-gradient-to-b from-[#14120e] via-[#0c0b10] to-[#0a0a0f] p-5 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 font-mono text-xs font-bold flex items-center justify-center border border-amber-500/40">
              1
            </span>
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400">
              1st: Income & Expense Status Dashboard
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-950/80 text-amber-300 border border-amber-600/40">
              TOP PINNED
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setQuickTxType('expense');
                setShowQuickTxModal(true);
              }}
              className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300 border border-white/5 flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5 text-rose-400" />
              <span>Log Cashflow</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveWing('wealth')}
              className="px-2.5 py-1 rounded-lg bg-amber-950/40 hover:bg-amber-900/50 text-xs font-mono text-amber-300 border border-amber-700/40 flex items-center gap-1 transition-colors"
            >
              <span>Ledger</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-400 italic mb-4">
          Primary cash position banner. Immediately answers: <span className="text-slate-300 not-italic font-medium">How much capital do I have?</span> and <span className="text-slate-300 not-italic font-medium">How much did I spend this month?</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          {/* Card 1: Total Net Worth */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/5 flex flex-col justify-between">
            <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Total Net Worth</span>
              <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="mt-2 text-2xl sm:text-3xl font-black font-mono tracking-tight text-white">
              ${totalNetWorth.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="mt-2 text-[10px] font-mono text-emerald-400 flex items-center gap-1">
              <span>Liquid Assets & Sovereign Holdings</span>
            </div>
          </div>

          {/* Card 2: Earned This Month */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/5 flex flex-col justify-between">
            <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Earned This Month</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="mt-2 text-2xl sm:text-3xl font-black font-mono tracking-tight text-emerald-400">
              +${earnedThisMonth.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="mt-2 text-[10px] font-mono text-slate-500">
              Retainer, Dividends & Cash Yield
            </div>
          </div>

          {/* Card 3: Spent This Month */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/5 flex flex-col justify-between">
            <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Spent This Month</span>
              <TrendingDown className="w-4 h-4 text-rose-400" />
            </div>
            <div className="mt-2 text-2xl sm:text-3xl font-black font-mono tracking-tight text-rose-400">
              -${spentThisMonth.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="mt-2 text-[10px] font-mono text-slate-500">
              Fixed Ops, Infrastructure & Burn
            </div>
          </div>
        </div>
      </section>

      {/* ======================================================== */}
      {/* 2nd: THE 4 NAVIGATION ACTION BUTTONS (DIRECT ROUTING) */}
      {/* ======================================================== */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center border border-cyan-500/40">
            2
          </span>
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-cyan-400">
            2nd: The Strategic Navigation Action Buttons
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/80 text-cyan-300 border border-cyan-600/40">
            DIRECT ROUTING
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Ergonomic shortcut grid providing instant access across the five primary wings without touching bottom navigation tabs:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {/* Button 1: ChronoNote */}
          <button
            type="button"
            onClick={() => setActiveWing('chrononote')}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-[#1c0f16] to-[#0d070b] border border-rose-500/30 hover:border-rose-400/70 transition-all text-left shadow-md hover:shadow-rose-950/50 hover:translate-y-[-2px]"
          >
            <div className="w-9 h-9 rounded-lg bg-rose-950/80 border border-rose-600/40 text-rose-300 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <BookOpen className="w-4 h-4" />
            </div>
            <div className="text-sm font-bold text-white group-hover:text-rose-200 transition-colors flex items-center justify-between">
              <span>ChronoNote</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Timeline & Milestones
            </div>
          </button>

          {/* Button 2: Divine Duty */}
          <button
            type="button"
            onClick={() => setActiveWing('duty')}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-[#12111d] to-[#090812] border border-blue-500/20 hover:border-blue-400/60 transition-all text-left shadow-md hover:shadow-blue-950/50 hover:translate-y-[-2px]"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-950/60 border border-blue-600/30 text-blue-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <CheckSquare className="w-4 h-4" />
            </div>
            <div className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors flex items-center justify-between">
              <span>1. Divine Duty</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Tasks & Habits
            </div>
          </button>

          {/* Button 3: Divine Horizon */}
          <button
            type="button"
            onClick={() => setActiveWing('horizon')}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-[#161019] to-[#0a0710] border border-purple-500/20 hover:border-purple-400/60 transition-all text-left shadow-md hover:shadow-purple-950/50 hover:translate-y-[-2px]"
          >
            <div className="w-9 h-9 rounded-lg bg-purple-950/60 border border-purple-600/30 text-purple-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Compass className="w-4 h-4" />
            </div>
            <div className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors flex items-center justify-between">
              <span>2. Divine Horizon</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Timeline & Journal
            </div>
          </button>

          {/* Button 4: Apex Wealth */}
          <button
            type="button"
            onClick={() => setActiveWing('wealth')}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-[#0c1613] to-[#060e0c] border border-emerald-500/20 hover:border-emerald-400/60 transition-all text-left shadow-md hover:shadow-emerald-950/50 hover:translate-y-[-2px]"
          >
            <div className="w-9 h-9 rounded-lg bg-emerald-950/60 border border-emerald-600/30 text-emerald-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Wallet className="w-4 h-4" />
            </div>
            <div className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors flex items-center justify-between">
              <span>3. Apex Wealth</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Ledger & Assets
            </div>
          </button>

          {/* Button 5: Apex Pulse */}
          <button
            type="button"
            onClick={() => setActiveWing('pulse')}
            className="group relative p-4 rounded-xl bg-gradient-to-br from-[#1c0f14] to-[#0e070a] border border-rose-500/20 hover:border-rose-400/60 transition-all text-left shadow-md hover:shadow-rose-950/50 hover:translate-y-[-2px]"
          >
            <div className="w-9 h-9 rounded-lg bg-rose-950/60 border border-rose-600/30 text-rose-400 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
              <Activity className="w-4 h-4" />
            </div>
            <div className="text-sm font-bold text-white group-hover:text-rose-300 transition-colors flex items-center justify-between">
              <span>4. Apex Pulse</span>
              <ArrowRight className="w-3.5 h-3.5 opacity-40 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="text-xs font-mono text-slate-400 mt-1">
              Expense Velocity
            </div>
          </button>
        </div>
      </section>

      {/* ======================================================== */}
      {/* 3rd: THE SCORING & COMBUSTION DASHBOARD (BLAZING FIRE) */}
      {/* ======================================================== */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 font-mono text-xs font-bold flex items-center justify-center border border-rose-500/40">
            3
          </span>
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-rose-400">
            3rd: The Scoring & Combustion Dashboard
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950/80 text-rose-300 border border-rose-600/40">
            BLAZING FIRE
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Displays today's execution ratio, habit streak count, and the dynamic multi-tier flame dial that transforms from Golden Flame through Electric Blue, Crimson, and Crimson Black Abyss.
        </p>

        {/* Dynamic Combustion Flame Dial Component */}
        <CombustionFlameDial
          combustion={combustion}
          simulatedScore={simulatedScore}
          onSimulateChange={setSimulatedScore}
        />
      </section>

      {/* ======================================================== */}
      {/* 4th: DAILY BOOK WISDOM LESSON & PRIORITIES (WISDOM FOCUS) */}
      {/* ======================================================== */}
      <section className="space-y-3">
        <div className="flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold flex items-center justify-center border border-emerald-500/40">
            4
          </span>
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-emerald-400">
            4th: Daily Book Wisdom Lesson & Priorities
          </span>
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-600/40">
            WISDOM FOCUS
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Curated daily lesson card (Atomic Habits, Rich Dad, 48 Laws) with one-tap full reader, followed immediately by the active Top 3 Non-Negotiable Priorities lock checklist.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Daily Lesson Card (5 cols) */}
          <div className="lg:col-span-5 rounded-2xl border border-amber-600/30 bg-gradient-to-br from-[#16120e] via-[#0d0c11] to-[#08080c] p-5 flex flex-col justify-between shadow-lg">
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-amber-950/70 text-amber-300 border border-amber-700/40">
                  {currentLesson.bookTitle}
                </span>
                <span className="text-[10px] font-mono text-slate-400">
                  {currentLesson.author}
                </span>
              </div>

              <div className="text-xs font-mono text-slate-400 mb-2">
                {currentLesson.chapterOrLaw}
              </div>

              <h3 className="text-base font-bold text-white tracking-tight leading-snug mb-3">
                "{currentLesson.headline}"
              </h3>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 mb-4">
                <div className="text-[10px] font-mono text-amber-400 font-semibold uppercase mb-1">
                  Core Law & Principle
                </div>
                <div className="text-xs text-slate-200">
                  {currentLesson.corePrinciple}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-white/5 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsReaderOpen(true)}
                className="w-full py-2.5 px-3 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-600/50 text-amber-200 text-xs font-semibold flex items-center justify-center gap-2 transition-all shadow-sm"
              >
                <BookOpen className="w-4 h-4" />
                <span>One-Tap Full Reader</span>
              </button>
            </div>
          </div>

          {/* Top 3 Non-Negotiable Priorities Lock Checklist (7 cols) */}
          <div className="lg:col-span-7 rounded-2xl border border-rose-950/60 bg-gradient-to-br from-[#140c11] via-[#0c090e] to-[#070609] p-5 flex flex-col justify-between shadow-lg">
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
                  <span className="text-xs font-mono font-bold uppercase tracking-wider text-rose-300">
                    Active Top 3 Non-Negotiable Priorities
                  </span>
                </div>
                <span className="text-[10px] font-mono text-rose-400 font-bold bg-rose-950/80 px-2 py-0.5 rounded border border-rose-800/40">
                  3 PTS EACH • ABYSS GATEWAY
                </span>
              </div>

              <p className="text-[11px] text-slate-400 mb-3">
                Strict binary execution gates. Abyss aura will remain physically locked until all high priorities are checked.
              </p>

              <div className="space-y-2.5">
                {top3NonNegotiables.length > 0 ? (
                  top3NonNegotiables.map((task, index) => (
                    <div
                      key={task.id}
                      onClick={() => toggleTask(task.id)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all flex items-start gap-3 select-none ${
                        task.completed
                          ? 'bg-rose-950/20 border-rose-900/40 text-slate-400'
                          : 'bg-black/50 border-rose-600/30 hover:border-rose-500/70 text-slate-100 shadow-sm'
                      }`}
                    >
                      <button
                        type="button"
                        className="mt-0.5 text-rose-400 hover:text-rose-300 shrink-0 transition-colors"
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-5 h-5 text-rose-500" />
                        ) : (
                          <Circle className="w-5 h-5 text-slate-600 hover:text-rose-400" />
                        )}
                      </button>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-rose-950 text-rose-400 font-bold border border-rose-800/40">
                            #0{index + 1}
                          </span>
                          <span className={`text-xs font-semibold leading-snug ${task.completed ? 'line-through text-slate-500' : 'text-slate-100'}`}>
                            {task.title}
                          </span>
                        </div>
                        {task.notes && (
                          <div className="text-[11px] text-slate-400 mt-1 truncate">
                            {task.notes}
                          </div>
                        )}
                      </div>

                      <div className="text-[10px] font-mono text-rose-400 font-bold shrink-0">
                        +3 PTS
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 rounded-xl bg-black/30 border border-white/5 text-center text-xs text-slate-500 font-mono">
                    No High-Priority tasks scheduled today.
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 mt-4 border-t border-white/5 flex items-center justify-between">
              <span className="text-[11px] font-mono text-slate-400">
                Gate Status: {combustion.allHighDone ? (
                  <span className="text-emerald-400 font-bold">ALL HIGH PRIORITIES SECURED</span>
                ) : (
                  <span className="text-rose-400 font-bold">{combustion.highDoneCount}/{combustion.highCount} Completed</span>
                )}
              </span>

              <button
                type="button"
                onClick={() => setActiveWing('duty')}
                className="px-3 py-1.5 rounded-lg bg-rose-950/50 hover:bg-rose-900/60 text-xs font-mono text-rose-200 border border-rose-700/40 flex items-center gap-1 transition-colors"
              >
                <span>Full Duty Wing</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Reader Modal */}
      <WisdomReaderModal
        lesson={isReaderOpen ? currentLesson : null}
        onClose={() => setIsReaderOpen(false)}
        onNextLesson={() => setActiveWisdomIndex(activeWisdomIndex + 1)}
        onPrevLesson={() => setActiveWisdomIndex(Math.max(0, activeWisdomIndex - 1))}
      />

      {/* Quick Cashflow Modal */}
      {showQuickTxModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#11111a] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-sm font-bold text-white mb-3">Record Cashflow Event</h3>
            <form onSubmit={handleCreateTx} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setQuickTxType('income')}
                  className={`py-1.5 rounded-lg text-xs font-mono font-semibold ${
                    quickTxType === 'income'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-600'
                      : 'bg-white/5 text-slate-400'
                  }`}
                >
                  + Income (Earned)
                </button>
                <button
                  type="button"
                  onClick={() => setQuickTxType('expense')}
                  className={`py-1.5 rounded-lg text-xs font-mono font-semibold ${
                    quickTxType === 'expense'
                      ? 'bg-rose-950 text-rose-300 border border-rose-600'
                      : 'bg-white/5 text-slate-400'
                  }`}
                >
                  - Expense (Spent)
                </button>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AWS Cloud Server or Retainer"
                  value={quickTxTitle}
                  onChange={e => setQuickTxTitle(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={quickTxAmount}
                    onChange={e => setQuickTxAmount(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Category</label>
                  <select
                    value={quickTxCat}
                    onChange={e => setQuickTxCat(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="Consulting">Consulting</option>
                    <option value="Investments">Investments</option>
                    <option value="Ops">Operations & Cloud</option>
                    <option value="Housing">Housing</option>
                    <option value="Discretionary">Discretionary</option>
                    <option value="Debt Service">Debt Service</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowQuickTxModal(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-xs text-white font-medium shadow-md"
                >
                  Commit to Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
