/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CombustionPhase, CombustionStatus } from '../../types';
import { Flame, ShieldAlert, Zap, AlertCircle } from 'lucide-react';

interface CombustionFlameDialProps {
  combustion: CombustionStatus;
  simulatedScore?: number | null;
  onSimulateChange?: (val: number | null) => void;
}

export const CombustionFlameDial: React.FC<CombustionFlameDialProps> = ({
  combustion,
  simulatedScore,
  onSimulateChange,
}) => {
  const effectiveScore = simulatedScore !== null && simulatedScore !== undefined ? simulatedScore : combustion.score;

  // Compute phase based on effectiveScore and rule
  let phase: CombustionPhase = 'dormant';
  let badgeLabel = 'COMMAND CENTER';
  let subtitle = 'Minimal combustion. Complete daily priorities to ignite.';

  if (effectiveScore < 30) {
    phase = 'dormant';
    badgeLabel = 'COMMAND CENTER';
    subtitle = 'Neutral translucent slate glass border, standard typography.';
  } else if (effectiveScore <= 60) {
    phase = 'golden';
    badgeLabel = 'GOLDEN FLAME 🔥';
    subtitle = 'Warm campfire gold/amber glow with flickering yellow core.';
  } else if (effectiveScore <= 80) {
    phase = 'electric';
    badgeLabel = 'ELECTRIC BLUE 🔥';
    subtitle = 'Cobalt lightning aura with high-frequency cyan flicker.';
  } else if (effectiveScore <= 90) {
    phase = 'crimson';
    badgeLabel = 'CRIMSON FLAME 🔥';
    subtitle = 'Intense scarlet radiance and blood-red outer rim.';
  } else {
    // >= 91%
    if (combustion.allHighDone || simulatedScore !== null) {
      phase = 'abyss';
      badgeLabel = 'CRIMSON BLACK ABYSS 🔥';
      subtitle = 'Obsidian outer flame smoke fusion with glowing blood core.';
    } else {
      phase = 'crimson';
      badgeLabel = 'CRIMSON (ABYSS LOCKED)';
      subtitle = 'Executive Rule: Complete all High Priorities to unlock Abyss.';
    }
  }

  // Circular progress calculation
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (effectiveScore / 100) * circumference;

  // Determine styles by phase
  const getFlameStyles = () => {
    switch (phase) {
      case 'abyss':
        return {
          containerClass: 'border-rose-600/80 shadow-[0_0_50px_rgba(225,29,72,0.65),inset_0_0_35px_rgba(159,18,57,0.7)] animate-abyss-pulse bg-[#0a0507]',
          strokeColor: '#f43f5e',
          glowFilter: 'url(#abyssGlow)',
          badgeClass: 'bg-[#180408] text-rose-200 border-rose-500 shadow-[0_0_15px_rgba(244,63,94,0.6)]',
          textColor: 'text-rose-400',
        };
      case 'crimson':
        return {
          containerClass: 'border-rose-500/70 shadow-[0_0_35px_rgba(225,29,72,0.45)] bg-[#11080c]',
          strokeColor: '#f43f5e',
          glowFilter: 'url(#crimsonGlow)',
          badgeClass: 'bg-rose-950/80 text-rose-200 border-rose-700/60 shadow-[0_0_12px_rgba(225,29,72,0.4)]',
          textColor: 'text-rose-400',
        };
      case 'electric':
        return {
          containerClass: 'border-cyan-400/70 shadow-[0_0_35px_rgba(6,182,212,0.5)] animate-electric-flicker bg-[#040e14]',
          strokeColor: '#06b6d4',
          glowFilter: 'url(#electricGlow)',
          badgeClass: 'bg-cyan-950/80 text-cyan-200 border-cyan-500/60 shadow-[0_0_12px_rgba(6,182,212,0.4)]',
          textColor: 'text-cyan-400',
        };
      case 'golden':
        return {
          containerClass: 'border-amber-400/60 shadow-[0_0_30px_rgba(245,158,11,0.45)] animate-golden-glow bg-[#120e06]',
          strokeColor: '#f59e0b',
          glowFilter: 'url(#goldenGlow)',
          badgeClass: 'bg-amber-950/80 text-amber-200 border-amber-600/60 shadow-[0_0_10px_rgba(245,158,11,0.35)]',
          textColor: 'text-amber-400',
        };
      case 'dormant':
      default:
        return {
          containerClass: 'border-white/10 bg-[#0d0d14]',
          strokeColor: '#475569',
          glowFilter: 'none',
          badgeClass: 'bg-white/5 text-slate-400 border-white/10',
          textColor: 'text-slate-300',
        };
    }
  };

  const currentStyle = getFlameStyles();

  return (
    <div className={`relative rounded-2xl border p-5 sm:p-6 transition-all duration-700 ${currentStyle.containerClass}`}>
      {/* Background radial smoke aura for Crimson Black Abyss */}
      {phase === 'abyss' && (
        <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
          <div className="absolute -inset-10 bg-[radial-gradient(circle_at_center,rgba(225,29,72,0.25)_0%,rgba(0,0,0,0.85)_70%)] animate-abyss-smoke opacity-80" />
        </div>
      )}

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left: Dynamic SVG Dial */}
        <div className="relative w-44 h-44 flex items-center justify-center shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
            <defs>
              <filter id="abyssGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="6" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="crimsonGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="electricGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="goldenGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Background Track */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              className="text-white/5"
              strokeWidth="10"
              stroke="currentColor"
              fill="transparent"
            />

            {/* Glowing Active Track */}
            <circle
              cx="80"
              cy="80"
              r={radius}
              stroke={currentStyle.strokeColor}
              strokeWidth="10"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              style={{
                transition: 'stroke-dashoffset 0.8s ease-out, stroke 0.6s ease',
                filter: currentStyle.glowFilter,
              }}
            />
          </svg>

          {/* Center Dial Content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
            <div className="flex items-center justify-center mb-0.5">
              <Flame
                className={`w-6 h-6 ${
                  phase === 'abyss'
                    ? 'text-rose-400 drop-shadow-[0_0_12px_#f43f5e] animate-bounce'
                    : phase === 'crimson'
                    ? 'text-rose-500'
                    : phase === 'electric'
                    ? 'text-cyan-400'
                    : phase === 'golden'
                    ? 'text-amber-400'
                    : 'text-slate-500'
                }`}
              />
            </div>
            <div className="text-3xl font-black font-mono tracking-tight text-white">
              {effectiveScore}%
            </div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              {combustion.earnedPoints} / {combustion.totalPossiblePoints} PTS
            </div>
          </div>
        </div>

        {/* Center / Right: Combustion Physics & Status Info */}
        <div className="flex-1 w-full space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold uppercase tracking-wider border ${currentStyle.badgeClass}`}>
                {badgeLabel}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Tier: {phase.toUpperCase()}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span>Non-Negotiables:</span>
              <span
                className={`font-bold px-2 py-0.5 rounded ${
                  combustion.allHighDone
                    ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-700/50'
                    : 'bg-rose-950/70 text-rose-300 border border-rose-800/50'
                }`}
              >
                {combustion.highDoneCount}/{combustion.highCount} SECURED
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            {subtitle}
          </p>

          {/* Mathematical Weighting Framework (Section 5) Legend */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-white/5 text-[11px] font-mono">
            <div className="p-2 rounded-lg bg-black/40 border border-white/5">
              <div className="text-rose-400 font-bold">High: 3 Pts</div>
              <div className="text-[10px] text-slate-400">Non-Negotiable</div>
            </div>
            <div className="p-2 rounded-lg bg-black/40 border border-white/5">
              <div className="text-cyan-400 font-bold">Medium: 2 Pts</div>
              <div className="text-[10px] text-slate-400">Strategic Progress</div>
            </div>
            <div className="p-2 rounded-lg bg-black/40 border border-white/5">
              <div className="text-amber-400 font-bold">Low: 1 Pt</div>
              <div className="text-[10px] text-slate-400">Maintenance</div>
            </div>
            <div className="p-2 rounded-lg bg-black/40 border border-white/5">
              <div className="text-emerald-400 font-bold">Habit: 1 Pt</div>
              <div className="text-[10px] text-slate-400">Daily Execution</div>
            </div>
          </div>

          {/* Executive Performance Rule warning if score is high but non-negotiables missing */}
          {effectiveScore >= 91 && !combustion.allHighDone && simulatedScore === null && (
            <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-800/80 flex items-start gap-2 text-xs text-rose-200">
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Executive Performance Rule:</span> The Abyss aura will not ignite until every scheduled High-Priority task is completed (currently {combustion.highDoneCount}/{combustion.highCount}).
              </div>
            </div>
          )}

          {/* Interactive Tier Testing Slider */}
          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-white/5">
            <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-rose-400" />
              <span>Simulate Flame Tiers:</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onSimulateChange?.(null)}
                className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                  simulatedScore === null
                    ? 'bg-rose-950 text-rose-300 border border-rose-700/60'
                    : 'bg-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                Live ({combustion.score}%)
              </button>
              {[15, 45, 75, 88, 96].map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => onSimulateChange?.(val)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                    simulatedScore === val
                      ? 'bg-rose-900 text-rose-200 border border-rose-600'
                      : 'bg-white/5 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {val}%
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
