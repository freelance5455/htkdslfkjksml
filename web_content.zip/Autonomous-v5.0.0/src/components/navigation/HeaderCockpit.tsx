/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { ActiveWing, ThemeMode } from '../../types';
import {
  Lock,
  Smartphone,
  Sliders,
  Flame,
  CheckSquare,
  Compass,
  Wallet,
  Activity,
  Home,
  BookOpen,
  Sun,
  Moon,
  Monitor,
  Download,
} from 'lucide-react';

interface HeaderCockpitProps {
  onOpenSettings: () => void;
  onOpenAndroidBridge: () => void;
}

export const HeaderCockpit: React.FC<HeaderCockpitProps> = ({
  onOpenSettings,
  onOpenAndroidBridge,
}) => {
  const { activeWing, setActiveWing, lockVault, combustion, theme, setTheme } = useVault();
  const [deviceDateTime, setDeviceDateTime] = useState<string>('');

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      const datePart = now.toLocaleDateString(undefined, {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      });
      const timePart = now.toLocaleTimeString(undefined, {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      });
      setDeviceDateTime(`${datePart} • ${timePart}`);
    };
    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const wingButtons: { id: ActiveWing; label: string; icon: React.ReactNode }[] = [
    { id: 'home', label: 'Cockpit', icon: <Home className="w-3.5 h-3.5" /> },
    { id: 'chrononote', label: 'ChronoNote', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'duty', label: 'Divine Duty', icon: <CheckSquare className="w-3.5 h-3.5" /> },
    { id: 'horizon', label: 'Divine Horizon', icon: <Compass className="w-3.5 h-3.5" /> },
    { id: 'wealth', label: 'Apex Wealth', icon: <Wallet className="w-3.5 h-3.5" /> },
    { id: 'pulse', label: 'Apex Pulse', icon: <Activity className="w-3.5 h-3.5" /> },
  ];

  const cycleTheme = () => {
    const next: ThemeMode = theme === 'dark' ? 'light' : theme === 'light' ? 'system' : 'dark';
    setTheme(next);
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#07070a]/95 text-slate-100 backdrop-blur-xl transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5">
        <div className="flex items-center justify-between gap-3">
          {/* Brand & Live Device Clock */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setActiveWing('home')}
              className="flex items-center gap-2.5 text-left group"
              title="Return to Autonomous Cockpit"
            >
              <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-rose-950 via-neutral-900 to-black border border-rose-600/40 flex items-center justify-center shadow-[0_0_15px_rgba(225,29,72,0.3)] group-hover:border-rose-400 transition-all shrink-0">
                <Flame className="w-4 h-4 text-rose-500 group-hover:scale-110 transition-transform" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-black tracking-wider text-white font-display">
                    AUTONOMOUS
                  </span>
                  <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-rose-950/80 text-rose-300 border border-rose-700/50 font-bold">
                    v5.0.0
                  </span>
                </div>
                {/* Live Device Date & Time directly beneath logo & name */}
                <div className="text-[10px] font-mono text-emerald-400 tracking-tight flex items-center gap-1.5 truncate">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  <span className="truncate">{deviceDateTime || 'Device Clock Live'}</span>
                </div>
              </div>
            </button>
          </div>

          {/* Quick Wings Switcher for Desktop / Tablet */}
          <nav className="hidden lg:flex items-center gap-1 p-1 rounded-xl bg-black/50 border border-white/10">
            {wingButtons.map(item => {
              const active = activeWing === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveWing(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    active
                      ? 'bg-rose-950/90 text-rose-200 border border-rose-700/60 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Combustion Badge Indicator */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/60 border border-white/10 text-[11px] font-mono">
              <span className="text-slate-400">Score:</span>
              <span
                className={`font-bold ${
                  combustion.phase === 'abyss'
                    ? 'text-rose-400 shadow-[0_0_8px_#f43f5e]'
                    : combustion.phase === 'crimson'
                    ? 'text-rose-400'
                    : combustion.phase === 'electric'
                    ? 'text-cyan-400'
                    : combustion.phase === 'golden'
                    ? 'text-amber-400'
                    : 'text-slate-400'
                }`}
              >
                {combustion.score}%
              </span>
            </div>

            {/* Theme Toggle (Dark / Light / System) */}
            <button
              type="button"
              onClick={cycleTheme}
              title={`Theme: ${theme.toUpperCase()} (Click to change)`}
              className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-xs font-mono transition-colors"
            >
              {theme === 'dark' && <Moon className="w-3.5 h-3.5 text-cyan-400" />}
              {theme === 'light' && <Sun className="w-3.5 h-3.5 text-amber-400" />}
              {theme === 'system' && <Monitor className="w-3.5 h-3.5 text-emerald-400" />}
              <span className="hidden md:inline uppercase text-[10px]">{theme}</span>
            </button>

            {/* Downloads & APK Modal */}
            <button
              type="button"
              onClick={onOpenAndroidBridge}
              title="Autonomous v5.0.0 Downloads: Complete App ZIP, Android Studio Project & Release APK"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-600/50 text-emerald-300 text-xs font-mono transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline font-semibold">Downloads & APK</span>
            </button>

            {/* Vault Settings */}
            <button
              type="button"
              onClick={onOpenSettings}
              title="Security, Themes & Local Backup"
              className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 transition-colors"
            >
              <Sliders className="w-4 h-4" />
            </button>

            {/* Instant Zero-Exposure Lock */}
            <button
              type="button"
              onClick={lockVault}
              title="Instant Vault Lock (ZERO EXPOSURE)"
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-rose-950/80 hover:bg-rose-900 border border-rose-700/60 text-rose-200 text-xs font-medium transition-all shadow-sm"
            >
              <Lock className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">Lock</span>
            </button>
          </div>
        </div>

        {/* Mobile Wing Scrollable Bar */}
        <div className="flex lg:hidden items-center gap-1 overflow-x-auto py-2 mt-1 border-t border-white/10 no-scrollbar">
          {wingButtons.map(item => {
            const active = activeWing === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveWing(item.id)}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all ${
                  active
                    ? 'bg-rose-950/90 text-rose-200 border border-rose-700/60'
                    : 'text-slate-400 hover:text-slate-200 bg-white/5'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
