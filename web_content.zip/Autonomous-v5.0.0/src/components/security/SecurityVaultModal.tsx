/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { playPatternNodeSound, playTactileClick } from '../../lib/audio';
import { triggerHaptic } from '../../lib/security';
import { Fingerprint, Grid3X3, KeyRound, ShieldAlert, ShieldCheck, Eye, EyeOff, AlertTriangle, Lock } from 'lucide-react';

export const SecurityVaultModal: React.FC = () => {
  const {
    isLocked,
    verifyPin,
    verifyPattern,
    verifyBiometric,
    failedAttempts,
    lockoutRemainingSeconds,
    stealthMode,
    setStealthMode,
  } = useVault();

  const [activeTab, setActiveTab] = useState<'biometric' | 'pattern' | 'pin'>('biometric');
  const [pinInput, setPinInput] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // Pattern Canvas State
  const [patternNodes, setPatternNodes] = useState<number[]>([]);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const matrixContainerRef = useRef<HTMLDivElement>(null);

  // Clear errors when switching tabs
  useEffect(() => {
    setErrorMsg('');
    setPinInput('');
    setPatternNodes([]);
  }, [activeTab]);

  if (!isLocked) return null;

  const isLockedOut = lockoutRemainingSeconds > 0;

  // PIN Handlers
  const handlePinDigit = (digit: string) => {
    if (isLockedOut) return;
    if (pinInput.length >= 6) return;
    playTactileClick(700 + pinInput.length * 50);
    triggerHaptic('tap');
    const nextPin = pinInput + digit;
    setPinInput(nextPin);
    setErrorMsg('');

    // If 4 digits, attempt automatic verification
    if (nextPin.length >= 4) {
      setTimeout(() => {
        executePinVerification(nextPin);
      }, 150);
    }
  };

  const handlePinBackspace = () => {
    playTactileClick(400);
    triggerHaptic('tap');
    setPinInput(prev => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handlePinClear = () => {
    playTactileClick(350);
    setPinInput('');
    setErrorMsg('');
  };

  const executePinVerification = async (pinToTest: string) => {
    setIsVerifying(true);
    const valid = await verifyPin(pinToTest);
    setIsVerifying(false);
    if (!valid) {
      setPinInput('');
      setErrorMsg('ACCESS DENIED: Master Salted Hash Mismatch');
    }
  };

  // Pattern Handlers
  const handleNodeSelect = (index: number) => {
    if (isLockedOut) return;
    if (patternNodes.includes(index)) return;
    playPatternNodeSound(index);
    triggerHaptic('node');
    const newSeq = [...patternNodes, index];
    setPatternNodes(newSeq);
  };

  const finishPattern = async () => {
    setIsDrawing(false);
    if (patternNodes.length < 3) {
      setPatternNodes([]);
      setErrorMsg('Connect at least 3 nodes');
      return;
    }
    setIsVerifying(true);
    const valid = await verifyPattern(patternNodes);
    setIsVerifying(false);
    if (!valid) {
      setPatternNodes([]);
      setErrorMsg('ACCESS DENIED: Pattern Trajectory Invalid');
    }
  };

  // Biometric Handler
  const handleBiometricClick = async () => {
    if (isLockedOut) return;
    setIsVerifying(true);
    setErrorMsg('');
    const res = await verifyBiometric();
    setIsVerifying(false);
    if (!res.success) {
      setErrorMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#050507]/95 backdrop-blur-2xl px-4 py-6 selection:bg-rose-900">
      {/* Background ambient crimson radial */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(225,29,72,0.12)_0%,transparent_75%)] pointer-events-none" />

      <div className="relative w-full max-w-md rounded-2xl border border-rose-950/60 bg-[#0d0d13]/90 p-6 md:p-8 shadow-[0_0_60px_rgba(0,0,0,0.9)] overflow-hidden">
        {/* Top Header Badge */}
        <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-950/60 border border-rose-700/40 flex items-center justify-center text-rose-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[11px] font-mono tracking-widest text-rose-500 uppercase font-semibold">
                Autonomous v4.0.0
              </div>
              <div className="text-sm font-bold text-slate-100 tracking-tight">
                Triple-Guard Security Vault
              </div>
            </div>
          </div>
          <div className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 uppercase">
            FLAG_SECURE
          </div>
        </div>

        {/* Lockout Banner */}
        {isLockedOut ? (
          <div className="mb-6 p-4 rounded-xl bg-rose-950/40 border border-rose-600/50 text-center animate-pulse">
            <AlertTriangle className="w-6 h-6 text-rose-400 mx-auto mb-1.5" />
            <div className="text-sm font-bold text-rose-200">EXECUTIVE LOCKOUT ENGAGED</div>
            <div className="text-xs text-rose-300/80 mt-1">
              5 Failed verification attempts detected. Brute-force block active.
            </div>
            <div className="text-2xl font-mono font-bold text-rose-400 mt-2">
              {lockoutRemainingSeconds}s
            </div>
          </div>
        ) : null}

        {/* Auth Mode Tabs */}
        <div className="grid grid-cols-3 gap-1.5 p-1 rounded-xl bg-black/40 border border-white/5 mb-6">
          <button
            type="button"
            onClick={() => setActiveTab('biometric')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'biometric'
                ? 'bg-rose-950/70 text-rose-200 border border-rose-700/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Fingerprint className="w-3.5 h-3.5" />
            <span>Biometric</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pattern')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'pattern'
                ? 'bg-rose-950/70 text-rose-200 border border-rose-700/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Grid3X3 className="w-3.5 h-3.5" />
            <span>Pattern 3×3</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('pin')}
            className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-medium transition-all ${
              activeTab === 'pin'
                ? 'bg-rose-950/70 text-rose-200 border border-rose-700/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>Crypt PIN</span>
          </button>
        </div>

        {/* GUARD 1: BIOMETRIC SENSOR */}
        {activeTab === 'biometric' && (
          <div className="flex flex-col items-center text-center py-4">
            <div className="relative mb-6">
              <div className="absolute inset-0 rounded-full bg-rose-600/20 blur-xl animate-pulse" />
              <button
                type="button"
                disabled={isLockedOut || isVerifying}
                onClick={handleBiometricClick}
                className="relative w-28 h-28 rounded-full border-2 border-rose-500/60 bg-gradient-to-b from-[#181119] to-[#0c080e] flex flex-col items-center justify-center shadow-[0_0_35px_rgba(225,29,72,0.3)] hover:border-rose-400 hover:scale-105 active:scale-95 transition-all group disabled:opacity-40 disabled:pointer-events-none"
              >
                <Fingerprint className="w-14 h-14 text-rose-400 group-hover:text-rose-300 transition-colors" />
                <span className="text-[10px] font-mono font-medium text-rose-300/80 mt-1">TOUCH SCAN</span>
              </button>
            </div>

            <div className="text-xs font-medium text-slate-300">
              Android BiometricPrompt / Web Hardware Key
            </div>
            <p className="text-[11px] text-slate-500 max-w-xs mt-1">
              Direct hardware biometric verification bridge with zero snapshot exposure.
            </p>

            <button
              type="button"
              onClick={handleBiometricClick}
              disabled={isLockedOut || isVerifying}
              className="mt-6 w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-900/60 to-rose-700/50 hover:from-rose-800 hover:to-rose-600 text-rose-100 font-medium text-xs border border-rose-600/40 shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-40"
            >
              <Fingerprint className="w-4 h-4" />
              {isVerifying ? 'Authenticating Sensor...' : 'Authenticate Biometric Gateway'}
            </button>
          </div>
        )}

        {/* GUARD 2: 3x3 PATTERN MATRIX */}
        {activeTab === 'pattern' && (
          <div className="flex flex-col items-center py-2">
            <div className="flex items-center justify-between w-full mb-3 px-2">
              <span className="text-[11px] font-mono text-slate-400">
                Connect sequence ({patternNodes.length} nodes)
              </span>
              <button
                type="button"
                onClick={() => setStealthMode(!stealthMode)}
                className="flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-rose-400 transition-colors"
                title="Toggle Stealth Mode: Hides connecting lines"
              >
                {stealthMode ? <EyeOff className="w-3.5 h-3.5 text-rose-400" /> : <Eye className="w-3.5 h-3.5" />}
                <span>Stealth {stealthMode ? 'ON' : 'OFF'}</span>
              </button>
            </div>

            {/* 3x3 Obsidian Canvas Matrix */}
            <div
              ref={matrixContainerRef}
              className="relative w-64 h-64 rounded-2xl bg-[#09090e] border border-white/5 p-4 flex flex-col justify-between select-none touch-none shadow-inner"
              onPointerUp={finishPattern}
            >
              {/* Matrix Grid */}
              <div className="grid grid-cols-3 gap-6 h-full w-full">
                {Array.from({ length: 9 }).map((_, idx) => {
                  const isSelected = patternNodes.includes(idx);
                  return (
                    <button
                      key={idx}
                      type="button"
                      onPointerDown={() => {
                        setIsDrawing(true);
                        handleNodeSelect(idx);
                      }}
                      onPointerEnter={() => {
                        if (isDrawing) handleNodeSelect(idx);
                      }}
                      disabled={isLockedOut}
                      className={`relative flex items-center justify-center rounded-full transition-all ${
                        isSelected
                          ? 'border border-rose-500 shadow-[0_0_15px_rgba(225,29,72,0.8)]'
                          : 'hover:border-white/20'
                      }`}
                    >
                      {/* Outer Aura Ring */}
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                          isSelected ? 'bg-rose-950/80 scale-110' : 'bg-white/5'
                        }`}
                      >
                        {/* Core Dot */}
                        <div
                          className={`w-3.5 h-3.5 rounded-full transition-all ${
                            isSelected
                              ? 'bg-rose-500 shadow-[0_0_10px_#f43f5e]'
                              : 'bg-slate-600'
                          }`}
                        />
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Clear & Submit buttons */}
            <div className="flex gap-2 w-full mt-4">
              <button
                type="button"
                onClick={() => setPatternNodes([])}
                className="flex-1 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-mono transition-colors"
              >
                Clear Matrix
              </button>
              <button
                type="button"
                onClick={finishPattern}
                disabled={patternNodes.length < 3 || isLockedOut}
                className="flex-1 py-2 rounded-lg bg-rose-900/70 hover:bg-rose-800 text-rose-100 text-xs font-medium border border-rose-600/40 transition-colors disabled:opacity-40"
              >
                Validate Pattern
              </button>
            </div>

            <div className="text-[10px] text-slate-500 font-mono mt-2">
              Default Pattern: Top row (0-1-2) then down (5-8)
            </div>
          </div>
        )}

        {/* GUARD 3: CRYPTOGRAPHIC PIN (SALTED HASH) */}
        {activeTab === 'pin' && (
          <div className="flex flex-col items-center">
            {/* PIN Masked Display */}
            <div className="flex items-center justify-center gap-3 py-3 mb-4 w-full">
              {Array.from({ length: 6 }).map((_, i) => {
                const filled = i < pinInput.length;
                return (
                  <div
                    key={i}
                    className={`w-3.5 h-3.5 rounded-full transition-all ${
                      filled
                        ? 'bg-rose-500 shadow-[0_0_12px_#f43f5e] scale-110'
                        : 'border border-slate-700 bg-black/40'
                    }`}
                  />
                );
              })}
            </div>

            {/* Tactical Keypad */}
            <div className="grid grid-cols-3 gap-2.5 w-full max-w-[260px]">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(d => (
                <button
                  key={d}
                  type="button"
                  disabled={isLockedOut}
                  onClick={() => handlePinDigit(d)}
                  className="h-12 rounded-xl bg-white/5 hover:bg-rose-950/50 hover:border-rose-700/40 border border-white/5 text-lg font-mono font-semibold text-slate-100 flex items-center justify-center active:scale-95 transition-all disabled:opacity-30"
                >
                  {d}
                </button>
              ))}
              <button
                type="button"
                disabled={isLockedOut}
                onClick={handlePinClear}
                className="h-12 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-400 flex items-center justify-center active:scale-95 transition-all disabled:opacity-30"
              >
                CLR
              </button>
              <button
                type="button"
                disabled={isLockedOut}
                onClick={() => handlePinDigit('0')}
                className="h-12 rounded-xl bg-white/5 hover:bg-rose-950/50 hover:border-rose-700/40 border border-white/5 text-lg font-mono font-semibold text-slate-100 flex items-center justify-center active:scale-95 transition-all disabled:opacity-30"
              >
                0
              </button>
              <button
                type="button"
                disabled={isLockedOut}
                onClick={handlePinBackspace}
                className="h-12 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-400 flex items-center justify-center active:scale-95 transition-all disabled:opacity-30"
              >
                DEL
              </button>
            </div>

            <div className="text-[10px] text-slate-500 font-mono mt-3">
              Default Master Key: <span className="text-rose-400 font-bold">1234</span> (SHA-256 + Salt)
            </div>
          </div>
        )}

        {/* Error message */}
        {errorMsg && (
          <div className="mt-4 p-2.5 rounded-lg bg-rose-950/50 border border-rose-800/60 text-center text-xs font-mono text-rose-300 flex items-center justify-center gap-1.5 animate-shake">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Security Footer Details */}
        <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500/80" />
            <span>AES-GCM / SHA-256 Vault</span>
          </div>
          <div>Attempts: {failedAttempts}/5</div>
        </div>
      </div>
    </div>
  );
};
