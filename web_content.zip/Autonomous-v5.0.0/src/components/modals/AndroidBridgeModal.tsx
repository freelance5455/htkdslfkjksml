/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Smartphone,
  Shield,
  Code,
  Download,
  Copy,
  Check,
  X,
  CheckCircle2,
  FileText,
  AlertTriangle,
  Terminal,
  ExternalLink,
  Info,
} from 'lucide-react';

import {
  downloadAutonomousApk,
  downloadAndroidProjectZip,
  downloadCompleteAppZip,
} from '../../lib/downloadZip';

interface AndroidBridgeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidBridgeModal: React.FC<AndroidBridgeModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeCodeTab, setActiveCodeTab] = useState<'main' | 'manifest' | 'gradle' | 'workflow'>('main');
  const [copied, setCopied] = useState<string | null>(null);
  const [isApkDownloading, setIsApkDownloading] = useState(false);
  const [isZipDownloading, setIsZipDownloading] = useState(false);
  const [isCompleteZipDownloading, setIsCompleteZipDownloading] = useState(false);
  const [apkDownloaded, setApkDownloaded] = useState(false);
  const [zipDownloaded, setZipDownloaded] = useState(false);
  const [completeZipDownloaded, setCompleteZipDownloaded] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleDownloadCompleteZip = async () => {
    setIsCompleteZipDownloading(true);
    setCompleteZipDownloaded(false);
    try {
      const ok = await downloadCompleteAppZip();
      if (ok) {
        setCompleteZipDownloaded(true);
        setTimeout(() => setCompleteZipDownloaded(false), 5000);
      }
    } finally {
      setIsCompleteZipDownloading(false);
    }
  };

  const handleDownloadApk = async () => {
    setIsApkDownloading(true);
    setApkDownloaded(false);
    try {
      const ok = await downloadAutonomousApk();
      if (ok) {
        setApkDownloaded(true);
        setTimeout(() => setApkDownloaded(false), 5000);
      }
    } finally {
      setIsApkDownloading(false);
    }
  };

  const handleDownloadZip = async () => {
    setIsZipDownloading(true);
    setZipDownloaded(false);
    try {
      const ok = await downloadAndroidProjectZip();
      if (ok) {
        setZipDownloaded(true);
        setTimeout(() => setZipDownloaded(false), 5000);
      }
    } finally {
      setIsZipDownloading(false);
    }
  };

  const codeSnippets = {
    main: `package com.autonomous.v2;

import android.app.Activity;
import android.content.DialogInterface;
import android.hardware.biometrics.BiometricPrompt;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private CancellationSignal cancellationSignal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // FLAG_SECURE: Prevents screenshots and recents snapshot leak (Zero Exposure)
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        configureWebView();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null) {
                    String host = url.getHost();
                    if ("appassets.androidplatform.net".equals(host) || "localhost".equals(host)) {
                        String path = url.getPath();
                        if (path != null) {
                            try {
                                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                                if (cleanPath.startsWith("web/")) {
                                    cleanPath = cleanPath.substring(4);
                                } else if (cleanPath.startsWith("assets/")) {
                                    cleanPath = cleanPath.substring(7);
                                }
                                if (cleanPath.isEmpty() || cleanPath.equals("index.html")) {
                                    cleanPath = "index.html";
                                }
                                InputStream is = getAssets().open("www/" + cleanPath);
                                String mimeType = "text/html";
                                if (cleanPath.endsWith(".js")) mimeType = "application/javascript";
                                else if (cleanPath.endsWith(".css")) mimeType = "text/css";
                                else if (cleanPath.endsWith(".svg")) mimeType = "image/svg+xml";
                                else if (cleanPath.endsWith(".png")) mimeType = "image/png";
                                else if (cleanPath.endsWith(".json")) mimeType = "application/json";
                                return new WebResourceResponse(mimeType, "UTF-8", is);
                            } catch (Exception ignored) {}
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Fail-safe offline fallback for appassets.androidplatform.net
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net")) {
                    view.loadUrl("file:///android_asset/www/index.html");
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        // Robust startup: direct local file load guarantees 100% offline instant launch
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean authenticateUser() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                runOnUiThread(() -> {
                    try {
                        cancellationSignal = new CancellationSignal();
                        BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle("Autonomous v5.0.0 Hardware Biometrics")
                            .setSubtitle("Authenticate executive credentials to open vault")
                            .setDescription("Biometric authentication for Autonomous Sovereign Vault")
                            .setNegativeButton("Use Master PIN", getMainExecutor(), (dialog, which) -> {
                                webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('Use PIN');", null);
                            })
                            .build();

                        prompt.authenticate(cancellationSignal, getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                super.onAuthenticationSucceeded(result);
                                webView.evaluateJavascript("window.onBiometricSuccess && window.onBiometricSuccess();", null);
                            }

                            @Override
                            public void onAuthenticationError(int errorCode, CharSequence errString) {
                                super.onAuthenticationError(errorCode, errString);
                                webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('" + errString + "');", null);
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                return true;
            }
            return false;
        }

        @JavascriptInterface
        public boolean saveBackupToStorage(String filename, String data) {
            try {
                File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, filename);
                FileWriter writer = new FileWriter(file);
                writer.write(data);
                writer.flush();
                writer.close();

                MediaScannerConnection.scanFile(
                    MainActivity.this,
                    new String[]{file.getAbsolutePath()},
                    null, null
                );
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }
}`,
    manifest: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.autonomous.v2"
    android:versionCode="5"
    android:versionName="5.0.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />

    <!-- Biometric, Storage & Vibration Defenses -->
    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="false"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Autonomous.Fullscreen">
        
        <activity
            android:name="com.autonomous.v2.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout"
            android:theme="@style/Theme.Autonomous.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
    gradle: `plugins {
    id 'com.android.application'
}

android {
    namespace 'com.autonomous.v2'
    compileSdk 34

    defaultConfig {
        applicationId "com.autonomous.v2"
        minSdk 24
        targetSdk 34
        versionCode 5
        versionName "5.0.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.biometric:biometric:1.1.0'
    implementation 'androidx.webkit:webkit:1.9.0'
}`,
    workflow: `name: Build Autonomous v5.0.0 APK

on:
  push:
    branches: [ "main" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v4

    - name: Set up JDK 17 (Temurin)
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'

    - name: Set up Android SDK
      uses: android-actions/setup-android@v3

    - name: Build Standalone Debug APK
      run: |
        gradle wrapper --gradle-version 8.2
        ./gradlew assembleDebug --stacktrace

    - name: Upload APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: Autonomous-v5.0.0-APK
        path: app/build/outputs/apk/debug/app-debug.apk`,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl bg-[#0b0c12] border border-cyan-500/30 p-5 sm:p-6 shadow-2xl my-auto text-slate-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.3)]">
              <Smartphone className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-bold">
                AUTONOMOUS v5.0.0 • ANDROID RELEASE PACKAGING
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                Signed APK & Android Native Bridge
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-5 max-h-[75vh] overflow-y-auto pr-1 no-scrollbar">
          {/* ========================================================= */}
          {/* 1. PRIMARY DOWNLOAD CENTER (COMPLETE APP, ANDROID & APK) */}
          {/* ========================================================= */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-neutral-900 to-black border border-cyan-500/50 shadow-xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <div className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <span>Autonomous v5.0.0 Artifact Deliverables</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-700/60 font-bold">
                    OFFICIAL RELEASE
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Download the complete application source repository (<code className="text-cyan-300">.zip</code>), the standalone Android Studio project (<code className="text-cyan-300">.zip</code>), or the signed native Android installer (<code className="text-cyan-300">.apk</code>).
                </p>
              </div>
            </div>

            {/* Action Buttons Grid - 3 Primary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              {/* BUTTON 1: DOWNLOAD COMPLETE APP ZIP */}
              <button
                type="button"
                disabled={isCompleteZipDownloading}
                onClick={handleDownloadCompleteZip}
                className="p-4 rounded-xl bg-gradient-to-r from-emerald-800 to-emerald-700 hover:from-emerald-700 hover:to-emerald-600 text-white font-semibold text-xs font-mono flex flex-col justify-between gap-2 shadow-lg shadow-emerald-950/50 border border-emerald-400/40 transition-all active:scale-[0.98] text-left"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-white" />
                    <span className="text-sm font-bold">Complete App ZIP</span>
                  </div>
                  <Download className="w-4 h-4" />
                </div>
                <div className="text-[11px] text-emerald-200/90 font-mono">
                  Autonomous-v5.0.0-Complete-App.zip (3.20 MB)
                </div>
                <div className="text-[10px] text-emerald-300/80">
                  {completeZipDownloaded ? '✓ Downloaded to device' : 'Entire repo: React 19, Android, scripts & specs'}
                </div>
              </button>

              {/* BUTTON 2: DOWNLOAD ANDROID STUDIO PROJECT ZIP */}
              <button
                type="button"
                disabled={isZipDownloading}
                onClick={handleDownloadZip}
                className="p-4 rounded-xl bg-gradient-to-r from-cyan-700 to-cyan-600 hover:from-cyan-600 hover:to-cyan-500 text-white font-semibold text-xs font-mono flex flex-col justify-between gap-2 shadow-lg shadow-cyan-950/50 border border-cyan-400/40 transition-all active:scale-[0.98] text-left"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4 text-white" />
                    <span className="text-sm font-bold">Android Project ZIP</span>
                  </div>
                  <Download className="w-4 h-4" />
                </div>
                <div className="text-[11px] text-cyan-200/90 font-mono">
                  Autonomous-v5.0.0-Android-Project.zip (863 KB)
                </div>
                <div className="text-[10px] text-cyan-300/80">
                  {zipDownloaded ? '✓ Downloaded to device' : 'Standalone Gradle & Android Studio project'}
                </div>
              </button>

              {/* BUTTON 3: DOWNLOAD APK */}
              <button
                type="button"
                disabled={isApkDownloading}
                onClick={handleDownloadApk}
                className="p-4 rounded-xl bg-gradient-to-r from-rose-700 to-rose-600 hover:from-rose-600 hover:to-rose-500 text-white font-semibold text-xs font-mono flex flex-col justify-between gap-2 shadow-lg shadow-rose-950/50 border border-rose-400/40 transition-all active:scale-[0.98] text-left"
              >
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-white" />
                    <span className="text-sm font-bold">Release APK</span>
                  </div>
                  <Download className="w-4 h-4" />
                </div>
                <div className="text-[11px] text-rose-200/90 font-mono">
                  Autonomous-v5.0.0.apk (4.09 MB)
                </div>
                <div className="text-[10px] text-rose-300/80">
                  {apkDownloaded ? '✓ Downloaded to device' : 'Signed installable package for any Android device'}
                </div>
              </button>
            </div>

            {/* Direct Link Fallbacks */}
            <div className="p-3 rounded-xl bg-black/60 border border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
              <span className="text-slate-400 text-[11px]">Direct Browser Links:</span>
              <div className="flex flex-wrap items-center gap-3">
                <a
                  href="/download/Autonomous-v5.0.0-Complete-App.zip"
                  download="Autonomous-v5.0.0-Complete-App.zip"
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-400 hover:underline flex items-center gap-1 text-[11px]"
                >
                  <span>Complete-App.zip</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-slate-600">•</span>
                <a
                  href="/download/Autonomous-v5.0.0-Android-Project.zip"
                  download="Autonomous-v5.0.0-Android-Project.zip"
                  target="_blank"
                  rel="noreferrer"
                  className="text-cyan-400 hover:underline flex items-center gap-1 text-[11px]"
                >
                  <span>Android-Project.zip</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span className="text-slate-600">•</span>
                <a
                  href="/download/Autonomous-v5.0.0.apk"
                  download="Autonomous-v5.0.0.apk"
                  target="_blank"
                  rel="noreferrer"
                  className="text-rose-400 hover:underline flex items-center gap-1 text-[11px]"
                >
                  <span>Autonomous-v5.0.0.apk</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 2. DIRECT INSTALL FROM GOOGLE CHROME (INSTANT PWA/WEBAPK) */}
          {/* ========================================================= */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-950/30 via-neutral-900 to-black border border-amber-500/40 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono font-bold text-amber-300 uppercase flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>Direct Installation From Google Chrome (Android & Desktop)</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-700/60 font-mono">
                PWA / WebAPK Ready
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Autonomous v5.0.0 is an installable Progressive Web Application with an active offline Service Worker and standalone web manifest. You can install it directly from Chrome without downloading separate files:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300 pt-1">
              <div className="p-3 rounded-xl bg-black/60 border border-white/10 space-y-1.5">
                <div className="font-bold text-amber-400 flex items-center gap-1">
                  <span>📱 On Chrome for Android:</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400">
                  <li>Open this web address in <strong className="text-white">Google Chrome</strong>.</li>
                  <li>Tap the three dots menu (<strong className="text-white">⋮</strong>) in the top-right corner.</li>
                  <li>Select <strong className="text-white">Install app</strong> or <strong className="text-white">Add to Home screen</strong>.</li>
                  <li>Chrome compiles a native WebAPK icon that launches full-screen and works 100% offline.</li>
                </ol>
              </div>

              <div className="p-3 rounded-xl bg-black/60 border border-white/10 space-y-1.5">
                <div className="font-bold text-amber-400 flex items-center gap-1">
                  <span>💻 On Chrome for Desktop (Mac / Windows / Linux):</span>
                </div>
                <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400">
                  <li>Look for the <strong className="text-white">Install Autonomous</strong> icon inside the Chrome URL address bar.</li>
                  <li>Or click the three dots (<strong className="text-white">⋮</strong>) &gt; <strong className="text-white">Save and share</strong> &gt; <strong className="text-white">Install Autonomous</strong>.</li>
                  <li>Autonomous opens in its own frameless desktop window.</li>
                </ol>
              </div>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-black/70 border border-white/10 font-mono text-xs">
              <span className="text-slate-400 text-[11px] truncate mr-2">
                URL: {typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-qrn5exzgaf5nvpi2ymcvom-953503017585.asia-east1.run.app'}
              </span>
              <button
                type="button"
                onClick={() =>
                  copyToClipboard(
                    typeof window !== 'undefined'
                      ? window.location.origin
                      : 'https://ais-pre-qrn5exzgaf5nvpi2ymcvom-953503017585.asia-east1.run.app',
                    'app-url'
                  )
                }
                className="px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-slate-200 text-[10px] shrink-0 flex items-center gap-1"
              >
                {copied === 'app-url' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copied === 'app-url' ? 'Copied URL!' : 'Copy URL'}</span>
              </button>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 3. APK SIGNING & INTEGRITY SPECIFICATION */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-3">
            <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Artifact Cryptographic Integrity (SHA-256)</span>
            </div>

            <div className="space-y-2 text-xs font-mono text-slate-300">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Signature Type:</span>
                <span className="text-emerald-400 font-bold">Standard Android Test/Debug Signature (v2 & v3 schemes)</span>
              </div>
              <div className="flex flex-col py-1 border-b border-white/5 gap-1">
                <span className="text-slate-400">Complete App ZIP (3.20 MB) SHA-256:</span>
                <div className="p-1.5 rounded bg-black/70 border border-white/10 text-[10px] text-emerald-300 break-all select-all">
                  ae5a1b764d40407f3e40dba6902f462ecf73254568963cb65aa5975f3874b902
                </div>
              </div>
              <div className="flex flex-col py-1 border-b border-white/5 gap-1">
                <span className="text-slate-400">Android Studio Project ZIP (863 KB) SHA-256:</span>
                <div className="p-1.5 rounded bg-black/70 border border-white/10 text-[10px] text-cyan-300 break-all select-all">
                  952be91e542a1b5b620c1ed199ae5739df8f0ecb74cc84f41d98413b26830b77
                </div>
              </div>
              <div className="flex flex-col py-1 border-b border-white/5 gap-1">
                <span className="text-slate-400">Release APK (4.09 MB) SHA-256:</span>
                <div className="p-1.5 rounded bg-black/70 border border-white/10 text-[10px] text-rose-300 break-all select-all">
                  955b36d06006a6fecf4ddea6cdc13c380286a386161c3f60f72412433828a516
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 3. INSTALLATION INSTRUCTIONS (UNKNOWN SOURCES & ADB) */}
          {/* ========================================================= */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
            <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <div className="text-rose-400 font-bold font-mono text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>Device Sideloading (Unknown Sources)</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-400">
                <li>Download the <strong className="text-white">Autonomous-v5.0.0.apk</strong> to your device.</li>
                <li>Tap the downloaded file in your browser or Files app.</li>
                <li>If prompted with "Install unknown apps", tap <strong className="text-white">Settings</strong> and toggle <strong className="text-white">Allow from this source</strong>.</li>
                <li>Tap <strong className="text-white">Install</strong>. If Google Play Protect warns about an unrecognized developer, tap <strong className="text-white">More details &gt; Install anyway</strong>.</li>
              </ol>
            </div>

            <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <div className="text-cyan-400 font-bold font-mono text-xs flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5" />
                <span>ADB Terminal Installation</span>
              </div>
              <p className="text-[11px] text-slate-400">
                To install directly over USB debugging via Android Debug Bridge:
              </p>
              <div className="p-2 rounded-lg bg-black/70 border border-white/10 text-[11px] font-mono text-cyan-300 select-all">
                adb install -r Autonomous-v5.0.0.apk
              </div>
              <p className="text-[10px] text-slate-500">
                The <code className="text-slate-400">-r</code> flag reinstalls preserving local SQLite / localStorage data across versions.
              </p>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 4. WEBVIEW ASSET LOADER FIX VERIFICATION */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
            <div className="text-xs font-mono font-bold text-emerald-400 uppercase flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>WebView Asset Loader Fix Verification</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              In previous builds, requests to <code className="text-rose-400">https://appassets.androidplatform.net/web/index.html</code> failed if the path handler was strictly mounted to <code className="text-slate-400">/assets/</code>. In Autonomous v5.0.0:
            </p>
            <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-400 font-mono">
              <li>Mounted dual path handlers for both <code className="text-cyan-300">/assets/</code> and <code className="text-cyan-300">/web/</code> in <code className="text-slate-200">MainActivity.java</code>.</li>
              <li>Added custom <code className="text-slate-200">shouldInterceptRequest</code> resolver serving all bundle assets (<code className="text-slate-300">.js, .css, .json, .svg, .html</code>) with explicit UTF-8 MIME types.</li>
              <li>Added fail-safe <code className="text-slate-200">onReceivedError</code> fallback directly to <code className="text-emerald-400">file:///android_asset/www/index.html</code>.</li>
            </ul>
          </div>

          {/* ========================================================= */}
          {/* 5. CODE INSPECTOR TABS */}
          {/* ========================================================= */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 bg-black/40 p-1 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('main')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'main'
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  MainActivity.java
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('manifest')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'manifest'
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  AndroidManifest.xml
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('gradle')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'gradle'
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  build.gradle
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('workflow')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                    activeCodeTab === 'workflow'
                      ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  build.yml
                </button>
              </div>

              <button
                type="button"
                onClick={() => copyToClipboard(codeSnippets[activeCodeTab], activeCodeTab)}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-300 border border-white/10 transition-colors"
              >
                {copied === activeCodeTab ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            <div className="relative rounded-xl bg-black/70 border border-white/10 p-4 max-h-60 overflow-y-auto font-mono text-xs text-slate-300 leading-relaxed no-scrollbar">
              <pre className="whitespace-pre">{codeSnippets[activeCodeTab]}</pre>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-between">
          <div className="text-[11px] font-mono text-slate-500">
            Autonomous v5.0.0 • Build Verified
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-mono text-white transition-colors"
          >
            Close Dialog
          </button>
        </div>
      </div>
    </div>
  );
};
