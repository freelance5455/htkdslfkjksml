/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { ThemeMode } from '../../types';
import {
  Shield,
  KeyRound,
  Grid3X3,
  Download,
  Upload,
  RefreshCw,
  X,
  Eye,
  EyeOff,
  Clock,
  CheckCircle2,
  HardDrive,
  FileCheck,
  Smartphone,
  AlertCircle,
  Sun,
  Moon,
  Monitor,
  Info,
  BookOpen,
} from 'lucide-react';

interface SecuritySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SecuritySettingsModal: React.FC<SecuritySettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    theme,
    setTheme,
    stealthMode,
    setStealthMode,
    autoLockMinutes,
    setAutoLockMinutes,
    updateMasterPin,
    updateMasterPattern,
    downloadDeviceBackup,
    restoreFromDeviceFile,
    resetToMasterDefaults,
  } = useVault();

  // PIN Form
  const [newPin, setNewPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [pinMsg, setPinMsg] = useState<string>('');

  // Device Storage Backup & Restore
  const [backupPassword, setBackupPassword] = useState<string>('');
  const [isBackingUp, setIsBackingUp] = useState<boolean>(false);
  const [backupSuccess, setBackupSuccess] = useState<{
    filename: string;
    stats: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number };
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [restorePassword, setRestorePassword] = useState<string>('');
  const [isRestoring, setIsRestoring] = useState<boolean>(false);
  const [restoreResult, setRestoreResult] = useState<{
    success: boolean;
    message: string;
    stats?: { assets: number; liabilities: number; txs: number; tasks: number; habits: number; journals: number; chronoNotes: number };
  } | null>(null);

  // Recording new pattern state
  const [isRecordingPattern, setIsRecordingPattern] = useState<boolean>(false);
  const [recordedPattern, setRecordedPattern] = useState<number[]>([]);

  if (!isOpen) return null;

  const handleSavePin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPin.length < 4) {
      setPinMsg('PIN must be at least 4 digits');
      return;
    }
    if (newPin !== confirmPin) {
      setPinMsg('PINs do not match');
      return;
    }
    const success = await updateMasterPin(newPin);
    if (success) {
      setPinMsg('Master PIN updated & hashed with device salt!');
      setNewPin('');
      setConfirmPin('');
    }
  };

  const handleDeviceBackup = async () => {
    setIsBackingUp(true);
    setBackupSuccess(null);
    try {
      const res = await downloadDeviceBackup(backupPassword);
      setBackupSuccess(res);
    } catch (err: any) {
      alert(`Backup failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setSelectedFile(e.target.files[0]);
      setRestoreResult(null);
    }
  };

  const handleExecuteRestore = async () => {
    if (!selectedFile) return;
    setIsRestoring(true);
    setRestoreResult(null);
    try {
      const res = await restoreFromDeviceFile(selectedFile, restorePassword);
      setRestoreResult(res);
      if (res.success) {
        setSelectedFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    } catch (err: any) {
      setRestoreResult({
        success: false,
        message: err.message || 'Restoration failed',
      });
    } finally {
      setIsRestoring(false);
    }
  };

  const handleSaveRecordedPattern = () => {
    if (recordedPattern.length >= 3) {
      updateMasterPattern(recordedPattern);
      setIsRecordingPattern(false);
      setRecordedPattern([]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-[#0c0c12] border border-white/15 p-5 sm:p-6 shadow-2xl my-auto text-slate-100">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-950/80 border border-rose-600/40 text-rose-400 flex items-center justify-center shadow-[0_0_15px_rgba(225,29,72,0.3)]">
              <Shield className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase tracking-wider text-rose-400 font-bold">
                AUTONOMOUS v5.0.0 CONFIGURATION
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white font-display">
                Settings, Security & Storage
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-5 max-h-[75vh] overflow-y-auto pr-1 no-scrollbar">
          {/* ========================================================= */}
          {/* 1. APPEARANCE & THEME MODE */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-1.5">
                  <Sun className="w-3.5 h-3.5 text-amber-400" />
                  <span>Appearance & Theme Mode</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Choose Dark, Light, or follow your Android / system preference
                </div>
              </div>

              <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => setTheme('dark')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                    theme === 'dark'
                      ? 'bg-rose-950 text-rose-300 border border-rose-700/60 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5" />
                  <span>Dark</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTheme('light')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                    theme === 'light'
                      ? 'bg-amber-950/80 text-amber-200 border border-amber-600/60 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>Light</span>
                </button>

                <button
                  type="button"
                  onClick={() => setTheme('system')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                    theme === 'system'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>System</span>
                </button>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 2. PRIMARY SECTION: DEVICE STORAGE BACKUP & RESTORE */}
          {/* ========================================================= */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#141d18] via-[#0d1410] to-[#070b09] border border-emerald-500/40 shadow-xl space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-mono font-bold text-white uppercase flex items-center gap-2">
                  <HardDrive className="w-4 h-4 text-emerald-400" />
                  <span>Device Storage Backup & Restore</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-bold">
                    APK & LOCAL STORAGE
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  Back up your entire net worth ledger, ChronoNotes, tasks, habits, and encrypted journals directly into your device storage. When you reinstall the app or set it up on another device later, use the restore button below to recover all data.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* BACK-UP BOX */}
              <div className="p-4 rounded-xl bg-black/60 border border-emerald-500/20 flex flex-col justify-between space-y-3">
                <div>
                  <div className="text-xs font-mono font-bold text-emerald-300 uppercase flex items-center gap-1.5 mb-1">
                    <Download className="w-3.5 h-3.5" />
                    <span>1. Back-Up to Device</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Saves timestamped <code className="text-emerald-400 font-mono">.vault</code> file to your device storage.
                  </p>
                </div>

                <div className="space-y-2">
                  <div>
                    <label className="text-[10px] font-mono uppercase text-slate-400">
                      Encryption Key (Optional)
                    </label>
                    <input
                      type="password"
                      placeholder="Leave blank for Master PIN (1234)"
                      value={backupPassword}
                      onChange={e => setBackupPassword(e.target.value)}
                      className="w-full px-2.5 py-1.5 mt-1 rounded-lg bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500 font-mono"
                    />
                  </div>

                  <button
                    type="button"
                    disabled={isBackingUp}
                    onClick={handleDeviceBackup}
                    className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-800 to-emerald-600 hover:from-emerald-700 hover:to-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-50"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isBackingUp ? 'Generating File...' : 'Back-Up to Device Storage'}</span>
                  </button>
                </div>

                {backupSuccess && (
                  <div className="p-2.5 rounded-lg bg-emerald-950/70 border border-emerald-600/60 text-[11px] font-mono text-emerald-200 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Saved to device storage:</span>
                    </div>
                    <div className="truncate text-white font-bold">{backupSuccess.filename}</div>
                    <div className="text-[10px] text-emerald-400">
                      Backed up: {backupSuccess.stats.chronoNotes} ChronoNotes, {backupSuccess.stats.assets} Assets, {backupSuccess.stats.tasks} Tasks, {backupSuccess.stats.habits} Habits
                    </div>
                  </div>
                )}
              </div>

              {/* RESTORE BOX */}
              <div className="p-4 rounded-xl bg-black/60 border border-cyan-500/20 flex flex-col justify-between space-y-3">
                <div>
                  <div className="text-xs font-mono font-bold text-cyan-300 uppercase flex items-center gap-1.5 mb-1">
                    <Upload className="w-3.5 h-3.5" />
                    <span>2. Restore from Device</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Select a previously saved <code className="text-cyan-400 font-mono">.vault</code> file to reload all data.
                  </p>
                </div>

                <div className="space-y-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".vault,.json"
                    onChange={handleFileChange}
                    className="hidden"
                  />

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full py-2 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-slate-200 text-xs font-mono flex items-center justify-center gap-2 transition-colors"
                  >
                    <FileCheck className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="truncate">
                      {selectedFile ? selectedFile.name : 'Choose File from Storage'}
                    </span>
                  </button>

                  <div>
                    <label className="text-[10px] font-mono uppercase text-slate-400">
                      Backup Password (if custom)
                    </label>
                    <input
                      type="password"
                      placeholder="Blank uses Master PIN (1234)"
                      value={restorePassword}
                      onChange={e => setRestorePassword(e.target.value)}
                      className="w-full px-2.5 py-1.5 mt-1 rounded-lg bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>

                  <button
                    type="button"
                    disabled={!selectedFile || isRestoring}
                    onClick={handleExecuteRestore}
                    className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-800 to-cyan-600 hover:from-cyan-700 hover:to-cyan-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{isRestoring ? 'Decrypting & Restoring...' : 'Restore All Data'}</span>
                  </button>
                </div>

                {restoreResult && (
                  <div
                    className={`p-2.5 rounded-lg border text-[11px] font-mono space-y-1 ${
                      restoreResult.success
                        ? 'bg-emerald-950/70 border-emerald-600/60 text-emerald-200'
                        : 'bg-rose-950/70 border-rose-600/60 text-rose-200'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold">
                      {restoreResult.success ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                      )}
                      <span>{restoreResult.message}</span>
                    </div>
                    {restoreResult.stats && (
                      <div className="text-[10px] text-emerald-400">
                        Restored: {restoreResult.stats.chronoNotes} ChronoNotes, {restoreResult.stats.assets} Assets, {restoreResult.stats.tasks} Tasks
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 3. LIFECYCLE TRIGGERS & AUTO-LOCK */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-rose-400" />
                  <span>Auto-Lock & Lifecycle Trigger</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Defense standard: ZERO EXPOSURE upon app minimize/switch
                </div>
              </div>

              <select
                value={autoLockMinutes}
                onChange={e => setAutoLockMinutes(parseInt(e.target.value, 10))}
                className="px-3 py-1.5 rounded-lg bg-black/60 border border-white/10 text-xs font-mono text-white focus:outline-none focus:border-rose-500"
              >
                <option value={0}>Instant (Zero Exposure)</option>
                <option value={1}>1 Minute Inactivity</option>
                <option value={5}>5 Minutes Inactivity</option>
                <option value={15}>15 Minutes Inactivity</option>
              </select>
            </div>

            {/* Stealth Mode */}
            <div className="pt-3 border-t border-white/5 flex items-center justify-between">
              <div>
                <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-1.5">
                  {stealthMode ? <EyeOff className="w-3.5 h-3.5 text-rose-400" /> : <Eye className="w-3.5 h-3.5 text-slate-400" />}
                  <span>Pattern Stealth Mode</span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Zero finger trails during tactile 3x3 pattern matrix unlock
                </div>
              </div>

              <button
                type="button"
                onClick={() => setStealthMode(!stealthMode)}
                className={`px-3 py-1 rounded-lg text-xs font-mono font-semibold transition-all ${
                  stealthMode
                    ? 'bg-rose-950 text-rose-300 border border-rose-600'
                    : 'bg-white/5 text-slate-400 border border-white/10'
                }`}
              >
                {stealthMode ? 'ACTIVE' : 'DISABLED'}
              </button>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 4. MASTER PIN UPDATE */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
            <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-rose-400" />
              <span>Update Cryptographic Master PIN (SHA-256)</span>
            </div>

            <form onSubmit={handleSavePin} className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="password"
                  placeholder="New PIN (4-6 digits)"
                  value={newPin}
                  onChange={e => setNewPin(e.target.value)}
                  maxLength={6}
                  className="px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-rose-500 font-mono"
                />
                <input
                  type="password"
                  placeholder="Confirm PIN"
                  value={confirmPin}
                  onChange={e => setConfirmPin(e.target.value)}
                  maxLength={6}
                  className="px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-rose-500 font-mono"
                />
              </div>

              {pinMsg && (
                <div className="text-[11px] font-mono text-rose-300">
                  {pinMsg}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-slate-200 border border-white/10 transition-colors"
              >
                Commit New Master PIN
              </button>
            </form>
          </div>

          {/* ========================================================= */}
          {/* 5. PATTERN MATRIX RE-RECORD */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono font-bold text-white uppercase flex items-center gap-1.5">
                <Grid3X3 className="w-3.5 h-3.5 text-rose-400" />
                <span>Re-Record 3×3 Tactile Pattern</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsRecordingPattern(!isRecordingPattern);
                  setRecordedPattern([]);
                }}
                className="text-xs font-mono text-rose-400 hover:underline"
              >
                {isRecordingPattern ? 'Cancel' : 'Record Pattern'}
              </button>
            </div>

            {isRecordingPattern && (
              <div className="p-3 rounded-xl bg-[#09090e] border border-rose-950 text-center space-y-3">
                <div className="text-[11px] text-slate-400 font-mono">
                  Tap nodes in your new desired sequence: [{recordedPattern.join(' → ')}]
                </div>
                <div className="grid grid-cols-3 gap-3 w-40 mx-auto">
                  {Array.from({ length: 9 }).map((_, idx) => {
                    const sel = recordedPattern.includes(idx);
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => {
                          if (!recordedPattern.includes(idx)) {
                            setRecordedPattern(prev => [...prev, idx]);
                          }
                        }}
                        className={`w-10 h-10 rounded-full border flex items-center justify-center font-mono text-xs transition-all ${
                          sel
                            ? 'bg-rose-900 border-rose-500 text-white shadow-[0_0_10px_#f43f5e]'
                            : 'bg-black/60 border-white/10 text-slate-400 hover:border-white/30'
                        }`}
                      >
                        {idx}
                      </button>
                    );
                  })}
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRecordedPattern([])}
                    className="flex-1 py-1.5 rounded-lg bg-white/5 text-[11px] font-mono text-slate-400"
                  >
                    Clear
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveRecordedPattern}
                    disabled={recordedPattern.length < 3}
                    className="flex-1 py-1.5 rounded-lg bg-rose-900 text-[11px] font-mono text-white disabled:opacity-40"
                  >
                    Save Pattern
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* 6. ABOUT AUTONOMOUS v5.0.0 */}
          {/* ========================================================= */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-white uppercase">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>About Autonomous v5.0.0</span>
            </div>
            <div className="text-xs text-slate-300 space-y-1">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Application Name:</span>
                <span className="font-bold text-white">Autonomous</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Release Version:</span>
                <span className="font-mono text-rose-400 font-bold">5.0.0 (versionCode 5)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Core Engines:</span>
                <span className="text-slate-200">Cockpit • ChronoNote • AES-GCM Vault</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Android Build:</span>
                <span className="text-emerald-400 font-mono">Native Asset Loader • Offline First</span>
              </div>
            </div>
          </div>

          {/* Baseline Reset */}
          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={() => {
                if (confirm('Reset ledger, ChronoNotes, tasks, habits, and balance sheet to Autonomous v5.0.0 initial baseline?')) {
                  resetToMasterDefaults();
                  onClose();
                }
              }}
              className="flex items-center gap-1.5 text-xs font-mono text-slate-500 hover:text-rose-400 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset to Master Baseline</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-mono text-white transition-colors"
            >
              Close Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
