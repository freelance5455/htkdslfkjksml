/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { PriorityLevel } from '../../types';
import {
  CheckSquare,
  Plus,
  Flame,
  CheckCircle2,
  Circle,
  Trash2,
  Calendar,
  Sparkles,
  Zap,
  Filter,
} from 'lucide-react';

export const DivineDutyWing: React.FC = () => {
  const {
    tasks,
    addTask,
    toggleTask,
    deleteTask,
    habits,
    toggleHabit,
    addHabit,
    deleteHabit,
    combustion,
  } = useVault();

  const [activeTab, setActiveTab] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [showAddTask, setShowAddTask] = useState<boolean>(false);
  const [showAddHabit, setShowAddHabit] = useState<boolean>(false);

  // New task form state
  const [taskTitle, setTaskTitle] = useState<string>('');
  const [taskPriority, setTaskPriority] = useState<PriorityLevel>('high');
  const [taskCategory, setTaskCategory] = useState<string>('Executive Duty');
  const [taskNotes, setTaskNotes] = useState<string>('');

  // New habit form state
  const [habitTitle, setHabitTitle] = useState<string>('');
  const [habitSlot, setHabitSlot] = useState<'morning' | 'afternoon' | 'evening'>('morning');
  const [habitCategory, setHabitCategory] = useState<string>('Physiology');

  const filteredTasks = tasks.filter(t => {
    if (activeTab === 'all') return true;
    return t.priority === activeTab;
  });

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    addTask(taskTitle.trim(), taskPriority, taskCategory, taskNotes.trim() || undefined);
    setTaskTitle('');
    setTaskNotes('');
    setShowAddTask(false);
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitTitle.trim()) return;
    addHabit({
      title: habitTitle.trim(),
      category: habitCategory,
      frequency: 'daily',
      slot: habitSlot,
    });
    setHabitTitle('');
    setShowAddHabit(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="rounded-2xl border border-blue-500/20 bg-gradient-to-r from-[#111124] via-[#0b0b14] to-[#07070d] p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-lg bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <CheckSquare className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Divine Duty: Tasks & Habits
            </h1>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Mathematical combustion weighting: High (3 pts Non-Negotiable), Medium (2 pts Strategic), Low (1 pt Maintenance), Habit (1 pt).
          </p>
        </div>

        {/* Live Combustion Summary Badge */}
        <div className="flex items-center gap-3 bg-black/50 p-3 rounded-xl border border-white/5">
          <div className="text-right">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Current Combustion</div>
            <div className="text-lg font-mono font-bold text-rose-400">
              {combustion.score}% ({combustion.earnedPoints}/{combustion.totalPossiblePoints} PTS)
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-950/60 border border-rose-600/40 flex items-center justify-center text-rose-400">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
        </div>
      </div>

      {/* Two Column Layout: Tasks (Left) and Habits (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Tasks Ledger (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/40 border border-white/5">
              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                  activeTab === 'all'
                    ? 'bg-blue-950 text-blue-300 border border-blue-700/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({tasks.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('high')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                  activeTab === 'high'
                    ? 'bg-rose-950 text-rose-300 border border-rose-700/50'
                    : 'text-slate-400 hover:text-rose-400'
                }`}
              >
                High (3pts)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('medium')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                  activeTab === 'medium'
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-700/50'
                    : 'text-slate-400 hover:text-cyan-400'
                }`}
              >
                Med (2pts)
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('low')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-colors ${
                  activeTab === 'low'
                    ? 'bg-amber-950 text-amber-300 border border-amber-700/50'
                    : 'text-slate-400 hover:text-amber-400'
                }`}
              >
                Low (1pt)
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowAddTask(true)}
              className="px-3 py-1.5 rounded-xl bg-blue-900/60 hover:bg-blue-800 border border-blue-600/40 text-blue-100 text-xs font-medium flex items-center gap-1.5 transition-all shadow-md"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Task</span>
            </button>
          </div>

          {/* Task List */}
          <div className="space-y-2.5">
            {filteredTasks.length > 0 ? (
              filteredTasks.map(task => {
                const priorityBadge =
                  task.priority === 'high' ? (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-700/50 font-bold">
                      HIGH • 3 PTS
                    </span>
                  ) : task.priority === 'medium' ? (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/50 font-bold">
                      MED • 2 PTS
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-700/50 font-bold">
                      LOW • 1 PT
                    </span>
                  );

                return (
                  <div
                    key={task.id}
                    className={`p-3.5 rounded-xl border transition-all flex items-start gap-3 group ${
                      task.completed
                        ? 'bg-black/30 border-white/5 opacity-70'
                        : 'bg-[#0f0f18] border-white/10 hover:border-blue-500/40 shadow-sm'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleTask(task.id)}
                      className="mt-0.5 text-slate-500 hover:text-blue-400 transition-colors shrink-0"
                    >
                      {task.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      ) : (
                        <Circle className="w-5 h-5 text-slate-600 group-hover:text-blue-400" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0" onClick={() => toggleTask(task.id)}>
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        {priorityBadge}
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400">
                          {task.category}
                        </span>
                      </div>
                      <div
                        className={`text-sm font-semibold leading-snug cursor-pointer ${
                          task.completed ? 'line-through text-slate-500' : 'text-slate-100'
                        }`}
                      >
                        {task.title}
                      </div>
                      {task.notes && (
                        <div className="text-xs text-slate-400 mt-1">
                          {task.notes}
                        </div>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => deleteTask(task.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg hover:bg-rose-950/50 text-slate-500 hover:text-rose-400 transition-all shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })
            ) : (
              <div className="p-8 rounded-2xl bg-black/20 border border-white/5 text-center text-xs font-mono text-slate-500">
                No tasks in this category. Click "Add Task" to initiate duty.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Daily Habit Protocols (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                Daily Habit Protocols
              </h3>
            </div>

            <button
              type="button"
              onClick={() => setShowAddHabit(true)}
              className="px-2.5 py-1 rounded-lg bg-emerald-950/50 hover:bg-emerald-900 border border-emerald-600/40 text-emerald-300 text-xs font-mono flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Habit</span>
            </button>
          </div>

          <div className="space-y-3">
            {habits.map(habit => (
              <div
                key={habit.id}
                className={`p-4 rounded-xl border transition-all ${
                  habit.completedToday
                    ? 'bg-emerald-950/20 border-emerald-600/40 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                    : 'bg-[#0d0f12] border-white/5 hover:border-emerald-500/30'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/40 font-bold uppercase">
                        {habit.slot}
                      </span>
                      <span className="text-[10px] font-mono text-slate-400">
                        {habit.category}
                      </span>
                    </div>
                    <div className="text-sm font-bold text-white">
                      {habit.title}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => deleteHabit(habit.id)}
                    className="p-1 text-slate-600 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/5">
                  <div className="flex items-center gap-1.5 text-xs font-mono">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-amber-300 font-bold">{habit.streak} DAY STREAK</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleHabit(habit.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 ${
                      habit.completedToday
                        ? 'bg-emerald-900/80 text-emerald-100 border border-emerald-500 shadow-sm'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
                    }`}
                  >
                    {habit.completedToday ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                        <span>Completed (+1 Pt)</span>
                      </>
                    ) : (
                      <>
                        <Circle className="w-3.5 h-3.5 text-slate-500" />
                        <span>Check In (+1 Pt)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Task Modal */}
      {showAddTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#11111a] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Schedule Divine Duty Task</h3>
            <form onSubmit={handleCreateTask} className="space-y-3.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Task Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Execute Treasury Bond Rebalancing"
                  value={taskTitle}
                  onChange={e => setTaskTitle(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setTaskPriority('high')}
                  className={`py-2 rounded-xl text-xs font-mono font-bold flex flex-col items-center justify-center border transition-all ${
                    taskPriority === 'high'
                      ? 'bg-rose-950/80 text-rose-200 border-rose-500 shadow-sm'
                      : 'bg-white/5 text-slate-400 border-white/5'
                  }`}
                >
                  <span>HIGH</span>
                  <span className="text-[10px] text-rose-400">3 Pts (Abyss)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTaskPriority('medium')}
                  className={`py-2 rounded-xl text-xs font-mono font-bold flex flex-col items-center justify-center border transition-all ${
                    taskPriority === 'medium'
                      ? 'bg-cyan-950/80 text-cyan-200 border-cyan-500 shadow-sm'
                      : 'bg-white/5 text-slate-400 border-white/5'
                  }`}
                >
                  <span>MED</span>
                  <span className="text-[10px] text-cyan-400">2 Pts</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTaskPriority('low')}
                  className={`py-2 rounded-xl text-xs font-mono font-bold flex flex-col items-center justify-center border transition-all ${
                    taskPriority === 'low'
                      ? 'bg-amber-950/80 text-amber-200 border-amber-500 shadow-sm'
                      : 'bg-white/5 text-slate-400 border-white/5'
                  }`}
                >
                  <span>LOW</span>
                  <span className="text-[10px] text-amber-400">1 Pt</span>
                </button>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Category</label>
                <input
                  type="text"
                  placeholder="e.g. Capital, Security, Strategy"
                  value={taskCategory}
                  onChange={e => setTaskCategory(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Strategic Notes</label>
                <textarea
                  rows={2}
                  placeholder="Operational context or non-negotiable standards..."
                  value={taskNotes}
                  onChange={e => setTaskNotes(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-blue-500 resize-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTask(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-xs text-white font-medium shadow-md"
                >
                  Commit Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Habit Modal */}
      {showAddHabit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#11111a] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Establish Habit Protocol</h3>
            <form onSubmit={handleCreateHabit} className="space-y-3.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Habit Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 20-min Sunlight & Electrolyte Protocol"
                  value={habitTitle}
                  onChange={e => setHabitTitle(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Execution Slot</label>
                <select
                  value={habitSlot}
                  onChange={e => setHabitSlot(e.target.value as any)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="morning">Morning</option>
                  <option value="afternoon">Afternoon</option>
                  <option value="evening">Evening</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Domain Category</label>
                <input
                  type="text"
                  placeholder="e.g. Physiology, Executive, Mindset"
                  value={habitCategory}
                  onChange={e => setHabitCategory(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddHabit(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-xs text-white font-medium shadow-md"
                >
                  Lock Protocol
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
