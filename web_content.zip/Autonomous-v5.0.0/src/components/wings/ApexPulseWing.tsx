/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { TransactionType } from '../../types';
import {
  Activity,
  Plus,
  Trash2,
  TrendingDown,
  TrendingUp,
  Flame,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
  Calendar,
  CheckCircle,
} from 'lucide-react';

export const ApexPulseWing: React.FC = () => {
  const {
    transactions,
    addTransaction,
    deleteTransaction,
    earnedThisMonth,
    spentThisMonth,
  } = useVault();

  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // New transaction form
  const [title, setTitle] = useState<string>('');
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState<string>('Ops');
  const [account, setAccount] = useState<string>('Primary Operating Liquidity');

  const netCashflow = earnedThisMonth - spentThisMonth;
  const daysInMonth = 30;
  const currentDay = 24;
  const dailyBurnVelocity = currentDay > 0 ? (spentThisMonth / currentDay).toFixed(2) : '0';
  const safeDailyTarget = (1500 / daysInMonth).toFixed(2); // $50/day safe ceiling

  const filteredTxs = transactions.filter(t => {
    if (filterType === 'all') return true;
    return t.type === filterType;
  });

  // Calculate category totals for expenses
  const expenseCategories = transactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + (Number(t.amount) || 0);
      return acc;
    }, {} as Record<string, number>);

  const handleCreateTx = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!title.trim() || isNaN(amt) || amt <= 0) return;

    addTransaction({
      title: title.trim(),
      type,
      amount: amt,
      category,
      account,
      date: new Date().toISOString().split('T')[0],
    });

    setTitle('');
    setAmount('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="rounded-2xl border border-rose-500/20 bg-gradient-to-r from-[#1c0c14] via-[#10070c] to-[#070406] p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-lg bg-rose-950/80 border border-rose-500/40 flex items-center justify-center text-rose-400">
              <Activity className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Apex Pulse: Expense Trends & Cash Velocity
            </h1>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Real-time cashflow burn rate, daily spending velocity, category allocations, and capital velocity tracking.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="px-3.5 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 border border-rose-600/40 text-rose-100 text-xs font-medium flex items-center justify-center gap-2 shadow-md transition-all self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Record Event</span>
        </button>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center justify-between">
            <span>Spent This Month</span>
            <TrendingDown className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-rose-400 mt-1">
            -${spentThisMonth.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            Ceiling: $1,500.00 / Month
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center justify-between">
            <span>Earned This Month</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">
            +${earnedThisMonth.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] font-mono text-emerald-500/90 mt-1">
            Retainers & Yield Distributions
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Net Surplus / Delta</div>
          <div className="text-2xl font-mono font-bold text-white mt-1">
            {netCashflow >= 0 ? `+$${netCashflow.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : `-$${Math.abs(netCashflow).toLocaleString('en-US', { minimumFractionDigits: 2 })}`}
          </div>
          <div className="text-[10px] font-mono text-emerald-400 mt-1">
            {earnedThisMonth > 0 ? ((netCashflow / earnedThisMonth) * 100).toFixed(1) : 0}% Savings Rate
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Daily Burn Velocity</div>
          <div className="text-2xl font-mono font-bold text-cyan-400 mt-1">
            ${dailyBurnVelocity} <span className="text-xs text-slate-400 font-normal">/ day</span>
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            Under Safe Cap (${safeDailyTarget}/day)
          </div>
        </div>
      </div>

      {/* Two Column Layout: Categories & Velocity (Left) + Transactions Ledger (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Category Allocation & Burn Meter (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl border border-white/10 bg-[#120a0e]/80 backdrop-blur-md shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Monthly Category Allocation
            </h3>

            <div className="space-y-3">
              {Object.entries(expenseCategories).map(([cat, amt]) => {
                const pct = spentThisMonth > 0 ? ((amt / spentThisMonth) * 100).toFixed(1) : '0';
                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-slate-300 font-medium">{cat}</span>
                      <span className="text-slate-400">
                        ${amt.toFixed(2)} ({pct}%)
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-rose-700 to-rose-500 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-5 rounded-2xl border border-white/10 bg-[#10080c]/80 backdrop-blur-md shadow-lg">
            <h4 className="text-xs font-mono uppercase text-rose-400 font-semibold mb-2">
              Capital Retention Discipline
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              Autonomous v4.0.0 enforces low operational burn to ensure liquid reserves compound uninterrupted. Maintain fixed expenses under 35% of monthly baseline income.
            </p>
          </div>
        </div>

        {/* Right Column: Ledger Table (7 cols) */}
        <div className="lg:col-span-7 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              Cashflow Activity Log
            </h3>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-black/40 border border-white/5">
              <button
                type="button"
                onClick={() => setFilterType('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                  filterType === 'all'
                    ? 'bg-rose-950 text-rose-300 border border-rose-700/50'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setFilterType('income')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                  filterType === 'income'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                    : 'text-slate-400 hover:text-emerald-400'
                }`}
              >
                Incomes
              </button>
              <button
                type="button"
                onClick={() => setFilterType('expense')}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                  filterType === 'expense'
                    ? 'bg-rose-950 text-rose-300 border border-rose-700/50'
                    : 'text-slate-400 hover:text-rose-400'
                }`}
              >
                Expenses
              </button>
            </div>
          </div>

          <div className="space-y-2">
            {filteredTxs.map(tx => (
              <div
                key={tx.id}
                className="p-3.5 rounded-xl border border-white/10 bg-[#0e0a10]/80 hover:border-rose-500/30 transition-all flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border ${
                      tx.type === 'income'
                        ? 'bg-emerald-950/70 border-emerald-600/40 text-emerald-400'
                        : 'bg-rose-950/70 border-rose-600/40 text-rose-400'
                    }`}
                  >
                    {tx.type === 'income' ? (
                      <ArrowUpRight className="w-4 h-4" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white truncate">
                      {tx.title}
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{tx.date}</span>
                      <span>•</span>
                      <span>{tx.category}</span>
                      <span>•</span>
                      <span>{tx.account}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div
                    className={`text-sm sm:text-base font-mono font-bold ${
                      tx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {tx.type === 'income' ? '+' : '-'}${tx.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </div>

                  <button
                    type="button"
                    onClick={() => deleteTransaction(tx.id)}
                    className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-500 hover:text-rose-400 transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Add Transaction Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#140b10] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Record Financial Event</h3>
            <form onSubmit={handleCreateTx} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setType('income')}
                  className={`py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                    type === 'income'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-500 shadow-sm'
                      : 'bg-white/5 text-slate-400'
                  }`}
                >
                  + Income (Earned)
                </button>
                <button
                  type="button"
                  onClick={() => setType('expense')}
                  className={`py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                    type === 'expense'
                      ? 'bg-rose-950 text-rose-300 border border-rose-500 shadow-sm'
                      : 'bg-white/5 text-slate-400'
                  }`}
                >
                  - Expense (Spent)
                </button>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Description</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Server hosting, retainer, equipment"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="Ops">Operations & Hosting</option>
                    <option value="Housing">Housing & Space</option>
                    <option value="Discretionary">Discretionary / Health</option>
                    <option value="Consulting">Consulting / Retainer</option>
                    <option value="Investments">Investments / Dividends</option>
                    <option value="Debt Service">Debt Service</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Account</label>
                <input
                  type="text"
                  value={account}
                  onChange={e => setAccount(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-xs text-white font-medium shadow-md"
                >
                  Save Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
