/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { JournalEntry } from '../../types';
import {
  Compass,
  Plus,
  Lock,
  Unlock,
  Trash2,
  Calendar,
  Sparkles,
  Tag,
  Search,
  ShieldCheck,
  Star,
} from 'lucide-react';

export const DivineHorizonWing: React.FC = () => {
  const {
    journalEntries,
    addJournalEntry,
    toggleJournalEncryption,
    deleteJournalEntry,
  } = useVault();

  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showAddEntry, setShowAddEntry] = useState<boolean>(false);

  // New entry form state
  const [title, setTitle] = useState<string>('');
  const [category, setCategory] = useState<JournalEntry['category']>('Strategic Pivot');
  const [content, setContent] = useState<string>('');
  const [impactScore, setImpactScore] = useState<number>(5);
  const [tagInput, setTagInput] = useState<string>('Strategy, Sovereignty');

  const filteredEntries = journalEntries.filter(entry => {
    const matchesSearch =
      entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesCat = selectedCategory === 'All' || entry.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const handleCreateEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const tags = tagInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    addJournalEntry({
      title: title.trim(),
      category,
      content: content.trim(),
      date: new Date().toISOString().split('T')[0],
      impactScore,
      tags,
      isEncrypted: false,
    });

    setTitle('');
    setContent('');
    setShowAddEntry(false);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="rounded-2xl border border-purple-500/20 bg-gradient-to-r from-[#170e24] via-[#0d0914] to-[#08060d] p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-lg bg-purple-950/80 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <Compass className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Divine Horizon: Timeline Log & Strategic Life Journal
            </h1>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Chronological executive log & encrypted reflections. All storage keys protected by AES-GCM / SHA-256 vault cipher.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setShowAddEntry(true)}
          className="px-3.5 py-2 rounded-xl bg-purple-900/60 hover:bg-purple-800 border border-purple-600/40 text-purple-100 text-xs font-medium flex items-center justify-center gap-2 transition-all shadow-md self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Write Strategic Entry</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search entries or #tags..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 no-scrollbar">
          {['All', 'Strategic Pivot', 'Execution Review', 'Capital Allocation', 'Mindset'].map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-purple-950 text-purple-300 border border-purple-700/50'
                  : 'text-slate-400 hover:text-slate-200 bg-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Timeline Entries */}
      <div className="space-y-4">
        {filteredEntries.length > 0 ? (
          filteredEntries.map((entry, index) => (
            <div
              key={entry.id}
              className="relative p-5 rounded-2xl border border-white/10 bg-[#0f0c16]/80 backdrop-blur-md shadow-lg transition-all hover:border-purple-500/40"
            >
              {/* Header Info */}
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-700/40 font-bold uppercase">
                    {entry.category}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] font-mono text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{entry.date}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Star Rating */}
                  <div className="flex items-center text-amber-400">
                    {Array.from({ length: entry.impactScore }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-current" />
                    ))}
                  </div>

                  {/* Encryption Status Button */}
                  <button
                    type="button"
                    onClick={() => toggleJournalEncryption(entry.id)}
                    title={entry.isEncrypted ? 'Decrypt with Master Key' : 'Encrypt with AES-GCM'}
                    className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                      entry.isEncrypted
                        ? 'bg-rose-950 text-rose-300 border border-rose-700/50'
                        : 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                    }`}
                  >
                    {entry.isEncrypted ? (
                      <>
                        <Lock className="w-3 h-3 text-rose-400" />
                        <span>AES-GCM CIPHER</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3 h-3 text-emerald-400" />
                        <span>PLAINTEXT</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => deleteJournalEntry(entry.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Title */}
              <h3 className="text-base font-bold text-white mb-2 tracking-tight">
                {entry.title}
              </h3>

              {/* Content Body */}
              <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 text-xs text-slate-300 leading-relaxed font-sans mb-3">
                {entry.isEncrypted ? (
                  <div className="font-mono text-rose-400/90 break-all select-none">
                    [ENCRYPTED BLOB]: {entry.content.substring(0, 120)}... (Tap AES-GCM button above to decrypt)
                  </div>
                ) : (
                  entry.content
                )}
              </div>

              {/* Tags */}
              <div className="flex flex-wrap items-center gap-1.5">
                <Tag className="w-3 h-3 text-slate-500" />
                {entry.tags.map(t => (
                  <span
                    key={t}
                    className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-slate-400"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="p-8 rounded-2xl bg-black/20 border border-white/5 text-center text-xs font-mono text-slate-500">
            No journal entries matching filter. Write an entry to document your strategic journey.
          </div>
        )}
      </div>

      {/* Add Entry Modal */}
      {showAddEntry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#130f1a] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Log Strategic Horizon Entry</h3>
            <form onSubmit={handleCreateEntry} className="space-y-3.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Entry Headline</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Asymmetric Execution Protocol Review"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Domain Category</label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="Strategic Pivot">Strategic Pivot</option>
                    <option value="Execution Review">Execution Review</option>
                    <option value="Capital Allocation">Capital Allocation</option>
                    <option value="Mindset">Mindset</option>
                    <option value="Vulnerability">Vulnerability</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Impact Score (1-5)</label>
                  <select
                    value={impactScore}
                    onChange={e => setImpactScore(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value={5}>5 - Paradigm Shift</option>
                    <option value={4}>4 - High Strategic Value</option>
                    <option value={3}>3 - Core Operational</option>
                    <option value={2}>2 - Incremental Note</option>
                    <option value={1}>1 - Minor Observation</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Confidential Reflection</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Document strategic decisions, psychological friction, capital moves, or lessons learned..."
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500 resize-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Tags (comma-separated)</label>
                <input
                  type="text"
                  placeholder="e.g. Capital, Leverage, Stoicism"
                  value={tagInput}
                  onChange={e => setTagInput(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddEntry(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-purple-900 hover:bg-purple-800 text-xs text-white font-medium shadow-md"
                >
                  Store Entry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
