/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useVault } from '../../context/VaultContext';
import { Asset, AssetCategory, Liability, LiabilityCategory } from '../../types';
import {
  Wallet,
  Plus,
  Trash2,
  TrendingUp,
  ShieldAlert,
  PieChart,
  Landmark,
  CreditCard,
  Coins,
  Building,
  DollarSign,
  ArrowUpRight,
} from 'lucide-react';

export const ApexWealthWing: React.FC = () => {
  const {
    totalNetWorth,
    spentThisMonth,
    assets,
    addAsset,
    deleteAsset,
    liabilities,
    addLiability,
    deleteLiability,
  } = useVault();

  const [activeTab, setActiveTab] = useState<'all' | 'assets' | 'liabilities'>('all');
  const [showAddAsset, setShowAddAsset] = useState<boolean>(false);
  const [showAddLiability, setShowAddLiability] = useState<boolean>(false);

  // New Asset Form
  const [assetName, setAssetName] = useState<string>('');
  const [assetCategory, setAssetCategory] = useState<AssetCategory>('liquid_cash');
  const [assetAmount, setAssetAmount] = useState<string>('');
  const [assetInst, setAssetInst] = useState<string>('Tier-1 Treasury Trust');

  // New Liability Form
  const [liaName, setLiaName] = useState<string>('');
  const [liaCategory, setLiaCategory] = useState<LiabilityCategory>('credit_line');
  const [liaAmount, setLiaAmount] = useState<string>('');
  const [liaApr, setLiaApr] = useState<string>('0');
  const [liaMin, setLiaMin] = useState<string>('100');
  const [liaDue, setLiaDue] = useState<string>('2026-11-15');
  const [liaInst, setLiaInst] = useState<string>('Amex Business Platinum');

  const totalAssets = assets.reduce((sum, a) => sum + (Number(a.amount) || 0), 0);
  const totalLiabilities = liabilities.reduce((sum, l) => sum + (Number(l.amount) || 0), 0);

  // Liquid Reserves
  const liquidCash = assets
    .filter(a => a.category === 'liquid_cash')
    .reduce((sum, a) => sum + (Number(a.amount) || 0), 0);

  // Runway in months = Liquid Cash / monthly burn (if spentThisMonth > 0)
  const runwayMonths = spentThisMonth > 0 ? (liquidCash / spentThisMonth).toFixed(1) : '∞';

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(assetAmount);
    if (!assetName.trim() || isNaN(amt)) return;
    addAsset({
      name: assetName.trim(),
      category: assetCategory,
      amount: amt,
      institution: assetInst.trim() || 'Private Ledger',
      currency: 'USD',
    });
    setAssetName('');
    setAssetAmount('');
    setShowAddAsset(false);
  };

  const handleCreateLiability = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(liaAmount);
    if (!liaName.trim() || isNaN(amt)) return;
    addLiability({
      name: liaName.trim(),
      category: liaCategory,
      amount: amt,
      apr: parseFloat(liaApr) || 0,
      minimumPayment: parseFloat(liaMin) || 0,
      dueDate: liaDue,
      institution: liaInst.trim() || 'Credit Facility',
    });
    setLiaName('');
    setLiaAmount('');
    setShowAddLiability(false);
  };

  const getAssetCategoryIcon = (cat: AssetCategory) => {
    switch (cat) {
      case 'liquid_cash':
        return <Landmark className="w-4 h-4 text-emerald-400" />;
      case 'crypto':
        return <Coins className="w-4 h-4 text-amber-400" />;
      case 'stocks_portfolio':
        return <TrendingUp className="w-4 h-4 text-cyan-400" />;
      case 'real_estate':
        return <Building className="w-4 h-4 text-purple-400" />;
      default:
        return <Wallet className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="rounded-2xl border border-emerald-500/20 bg-gradient-to-r from-[#0c1813] via-[#08100d] to-[#050907] p-5 sm:p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <div className="w-7 h-7 rounded-lg bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Wallet className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Apex Wealth: Ledger & Assets
            </h1>
          </div>
          <p className="text-xs text-slate-400 max-w-xl">
            Confidential net worth balance sheet, liquid capital reserves, debt liabilities, and solvency runway calculation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddAsset(true)}
            className="px-3 py-1.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 border border-emerald-600/40 text-emerald-200 text-xs font-mono flex items-center gap-1.5 shadow-md transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Asset</span>
          </button>
          <button
            type="button"
            onClick={() => setShowAddLiability(true)}
            className="px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900 border border-rose-700/40 text-rose-200 text-xs font-mono flex items-center gap-1.5 shadow-md transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Debt</span>
          </button>
        </div>
      </div>

      {/* Top Solvency Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Total Net Worth</div>
          <div className="text-2xl font-mono font-bold text-white mt-1">
            ${totalNetWorth.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] font-mono text-emerald-400 mt-1">
            Assets minus Liabilities
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Gross Assets</div>
          <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">
            ${totalAssets.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            {assets.length} Ledger Positions
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Total Liabilities</div>
          <div className="text-2xl font-mono font-bold text-rose-400 mt-1">
            ${totalLiabilities.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            Debt-to-Asset: {totalAssets > 0 ? ((totalLiabilities / totalAssets) * 100).toFixed(1) : 0}%
          </div>
        </div>

        <div className="p-4 rounded-xl bg-black/50 border border-white/5">
          <div className="text-[10px] font-mono uppercase text-slate-400">Liquid Runway</div>
          <div className="text-2xl font-mono font-bold text-cyan-400 mt-1">
            {runwayMonths} Mo
          </div>
          <div className="text-[10px] font-mono text-slate-500 mt-1">
            ${liquidCash.toLocaleString()} Liquid vs ${spentThisMonth}/mo burn
          </div>
        </div>
      </div>

      {/* Two Column Layout: Assets (Left) and Liabilities (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Assets Ledger (7 cols) */}
        <div className="lg:col-span-7 space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Landmark className="w-4 h-4 text-emerald-400" />
              <span>Capital Reserves & Assets (${totalAssets.toLocaleString()})</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40 font-bold">
              UNENCUMBERED
            </span>
          </div>

          <div className="space-y-2.5">
            {assets.map(asset => (
              <div
                key={asset.id}
                className="p-3.5 rounded-xl border border-white/10 bg-[#0d1410]/70 hover:border-emerald-500/40 transition-all flex items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-emerald-950/80 border border-emerald-600/30 flex items-center justify-center shrink-0">
                    {getAssetCategoryIcon(asset.category)}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-white truncate">
                      {asset.name}
                    </div>
                    <div className="text-xs font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{asset.institution}</span>
                      <span>•</span>
                      <span className="uppercase text-[10px] text-emerald-400/90">{asset.category.replace('_', ' ')}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="text-right">
                    <div className="text-sm sm:text-base font-mono font-bold text-white">
                      ${asset.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500">
                      {totalAssets > 0 ? ((asset.amount / totalAssets) * 100).toFixed(1) : 0}% of gross
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => deleteAsset(asset.id)}
                    className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-500 hover:text-rose-400 transition-opacity"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Liabilities & Debt (5 cols) */}
        <div className="lg:col-span-5 space-y-3.5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-rose-400" />
              <span>Debt & Liabilities (${totalLiabilities.toLocaleString()})</span>
            </h3>
            <span className="text-[10px] font-mono text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/40 font-bold">
              SERVICED
            </span>
          </div>

          <div className="space-y-2.5">
            {liabilities.length > 0 ? (
              liabilities.map(lia => (
                <div
                  key={lia.id}
                  className="p-3.5 rounded-xl border border-white/10 bg-[#160d0f]/70 hover:border-rose-500/40 transition-all flex items-center justify-between gap-3 group"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-bold text-white truncate">
                      {lia.name}
                    </div>
                    <div className="text-xs font-mono text-slate-400 flex items-center gap-2 mt-0.5">
                      <span>{lia.institution}</span>
                      <span>•</span>
                      <span className="text-rose-400 font-semibold">{lia.apr}% APR</span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 mt-1">
                      Min: ${lia.minimumPayment} • Due: {lia.dueDate}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-sm sm:text-base font-mono font-bold text-rose-400">
                        -${lia.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => deleteLiability(lia.id)}
                      className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-500 hover:text-rose-400 transition-opacity"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 rounded-xl bg-black/20 border border-white/5 text-center text-xs font-mono text-slate-500">
                Zero debt liabilities logged. 100% sovereign asset stance.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Asset Modal */}
      {showAddAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#0f1411] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Record Asset Position</h3>
            <form onSubmit={handleCreateAsset} className="space-y-3.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Asset Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Treasury Yield Fund"
                  value={assetName}
                  onChange={e => setAssetName(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Category</label>
                <select
                  value={assetCategory}
                  onChange={e => setAssetCategory(e.target.value as any)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="liquid_cash">Liquid Cash Reserve</option>
                  <option value="stocks_portfolio">Sovereign Stocks & Indices</option>
                  <option value="crypto">Bitcoin & Crypto Cold Storage</option>
                  <option value="real_estate">Real Estate & Land</option>
                  <option value="private_equity">Private Equity</option>
                  <option value="precious_metals">Physical Precious Metals</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Valuation Amount ($)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="0.00"
                  value={assetAmount}
                  onChange={e => setAssetAmount(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Custodial Institution</label>
                <input
                  type="text"
                  placeholder="e.g. Mercury, Vanguard, Hardware Vault"
                  value={assetInst}
                  onChange={e => setAssetInst(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddAsset(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-emerald-900 hover:bg-emerald-800 text-xs text-white font-medium shadow-md"
                >
                  Commit Asset
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Liability Modal */}
      {showAddLiability && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#170e10] border border-white/10 p-6 shadow-2xl">
            <h3 className="text-base font-bold text-white mb-4">Record Liability / Debt</h3>
            <form onSubmit={handleCreateLiability} className="space-y-3.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Liability Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Equipment Credit Line"
                  value={liaName}
                  onChange={e => setLiaName(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Category</label>
                <select
                  value={liaCategory}
                  onChange={e => setLiaCategory(e.target.value as any)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                >
                  <option value="credit_line">Revolving Credit Line</option>
                  <option value="business_debt">Business Financing</option>
                  <option value="mortgage">Mortgage / Property Debt</option>
                  <option value="personal_loan">Personal Loan</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="0.00"
                    value={liaAmount}
                    onChange={e => setLiaAmount(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono uppercase text-slate-400">APR %</label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="0.0"
                    value={liaApr}
                    onChange={e => setLiaApr(e.target.value)}
                    className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400">Lender / Facility</label>
                <input
                  type="text"
                  placeholder="e.g. Amex Business, Silicon Valley"
                  value={liaInst}
                  onChange={e => setLiaInst(e.target.value)}
                  className="w-full px-3 py-2 mt-1 rounded-xl bg-black/50 border border-white/10 text-xs text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddLiability(false)}
                  className="flex-1 py-2 rounded-xl bg-white/5 text-xs text-slate-300 font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-xs text-white font-medium shadow-md"
                >
                  Record Debt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
