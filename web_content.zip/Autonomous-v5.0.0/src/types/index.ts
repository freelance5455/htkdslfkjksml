/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PriorityLevel = 'high' | 'medium' | 'low';

export interface Task {
  id: string;
  title: string;
  priority: PriorityLevel; // high = 3 pts, medium = 2 pts, low = 1 pt
  completed: boolean;
  dueDate: string; // YYYY-MM-DD
  category: string;
  notes?: string;
  createdAt: string;
}

export interface Habit {
  id: string;
  title: string;
  category: string;
  streak: number;
  completedToday: boolean;
  frequency: 'daily' | 'weekdays' | 'custom';
  slot: 'morning' | 'afternoon' | 'evening';
  history: string[]; // array of ISO dates YYYY-MM-DD
}

export type AssetCategory =
  | 'liquid_cash'
  | 'crypto'
  | 'stocks_portfolio'
  | 'real_estate'
  | 'private_equity'
  | 'precious_metals';

export interface Asset {
  id: string;
  name: string;
  category: AssetCategory;
  amount: number;
  institution: string;
  currency: string;
  updatedAt: string;
}

export type LiabilityCategory =
  | 'credit_line'
  | 'mortgage'
  | 'business_debt'
  | 'personal_loan';

export interface Liability {
  id: string;
  name: string;
  category: LiabilityCategory;
  amount: number;
  apr: number;
  minimumPayment: number;
  dueDate: string;
  institution: string;
}

export type TransactionType = 'income' | 'expense';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  amount: number;
  category: string;
  date: string; // YYYY-MM-DD
  account: string;
  notes?: string;
}

export interface JournalEntry {
  id: string;
  title: string;
  date: string;
  category: 'Strategic Pivot' | 'Execution Review' | 'Capital Allocation' | 'Mindset' | 'Vulnerability';
  content: string; // May be encrypted with AES-GCM
  isEncrypted: boolean;
  impactScore: number; // 1 to 5
  tags: string[];
}

export interface WisdomLesson {
  id: string;
  bookTitle: string;
  author: string;
  chapterOrLaw: string;
  headline: string;
  corePrinciple: string;
  strategicInsight: string;
  executiveAction: string;
  tags: string[];
}

export type CombustionPhase =
  | 'dormant'
  | 'golden'
  | 'electric'
  | 'crimson'
  | 'abyss';

export interface CombustionStatus {
  score: number; // 0 - 100
  earnedPoints: number;
  totalPossiblePoints: number;
  phase: CombustionPhase;
  allHighDone: boolean;
  highCount: number;
  highDoneCount: number;
  badgeLabel: string;
  colorName: string;
}

export type ActiveWing = 'home' | 'duty' | 'chrononote' | 'horizon' | 'wealth' | 'pulse';

export type ThemeMode = 'dark' | 'light' | 'system';

export interface ChronoNoteChecklistItem {
  id: string;
  text: string;
  completed: boolean;
}

export type ChronoNoteCategory =
  | 'Executive Strategic'
  | 'Decision Log'
  | 'Financial Advisory'
  | 'Deep Work Sprint'
  | 'Personal Protocol'
  | 'Meeting Debrief'
  | 'Executive'
  | 'Architecture'
  | 'Strategic'
  | 'Sprint'
  | 'Tactical'
  | 'Personal';

export interface ChronoNote {
  id: string;
  title: string;
  content: string;
  category: ChronoNoteCategory;
  timestamp: string; // ISO
  displayTime: string; // e.g. "04:55 AM"
  displayDate: string; // e.g. "Oct 24, 2026"
  isPinned: boolean;
  isEncrypted: boolean;
  priority?: PriorityLevel;
  tags: string[];
  checklist?: ChronoNoteChecklistItem[];
  clarityScore?: number; // 1 - 5
  wordCount: number;
  updatedAt: string;
}

export interface SecurityConfig {
  pinHash: string; // SHA-256 salted hash
  salt: string;
  patternSequence: number[]; // e.g. [0, 1, 2, 5, 8]
  stealthMode: boolean; // hide line trail during pattern drawing
  autoLockMinutes: number; // 0 = instant on tab blur, 1, 5, 15
  biometricsEnabled: boolean;
  failedAttempts: number;
  lockedOutUntil: number | null; // timestamp ms
  lastActive: number;
  theme: ThemeMode;
}
