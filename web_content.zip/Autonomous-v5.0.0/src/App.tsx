/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { VaultProvider, useVault } from './context/VaultContext';
import { HeaderCockpit } from './components/navigation/HeaderCockpit';
import { HomepageModuleHierarchy } from './components/home/HomepageModuleHierarchy';
import { ChronoNoteWorkspace } from './components/chrononote/ChronoNoteWorkspace';
import { DivineDutyWing } from './components/wings/DivineDutyWing';
import { DivineHorizonWing } from './components/wings/DivineHorizonWing';
import { ApexWealthWing } from './components/wings/ApexWealthWing';
import { ApexPulseWing } from './components/wings/ApexPulseWing';
import { SecurityVaultModal } from './components/security/SecurityVaultModal';
import { SecuritySettingsModal } from './components/modals/SecuritySettingsModal';
import { AndroidBridgeModal } from './components/modals/AndroidBridgeModal';
import {
  Home,
  BookOpen,
  CheckSquare,
  Compass,
  Wallet,
  Activity,
  Lock,
  ArrowLeft,
} from 'lucide-react';

const CockpitContent: React.FC = () => {
  const { activeWing, setActiveWing, lockVault } = useVault();
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isAndroidBridgeOpen, setIsAndroidBridgeOpen] = useState<boolean>(false);

  return (
    <div className="min-h-screen bg-[#07070a] text-slate-100 flex flex-col font-sans selection:bg-rose-900 selection:text-white relative">
      {/* Triple-Guard Vault Modal (Appears upon lock, resume, switch) */}
      <SecurityVaultModal />

      {/* Top Header Cockpit with Autonomous v5.0.0 and Live Device Clock */}
      <HeaderCockpit
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAndroidBridge={() => setIsAndroidBridgeOpen(true)}
      />

      {/* Main Dynamic Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-5 pb-24 sm:pb-14">
        {activeWing === 'home' && <HomepageModuleHierarchy />}
        {activeWing === 'chrononote' && <ChronoNoteWorkspace />}
        {activeWing === 'duty' && <DivineDutyWing />}
        {activeWing === 'horizon' && <DivineHorizonWing />}
        {activeWing === 'wealth' && <ApexWealthWing />}
        {activeWing === 'pulse' && <ApexPulseWing />}
      </main>

      {/* Functioning Bottom-Right Back Button to return to Cockpit */}
      {activeWing !== 'home' && (
        <button
          type="button"
          onClick={() => setActiveWing('home')}
          className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-40 flex items-center gap-2 px-4 py-2.5 rounded-full bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs sm:text-sm shadow-2xl shadow-rose-950 border border-rose-400/50 backdrop-blur-md transition-all hover:scale-105 active:scale-95 group"
          title="Return to Autonomous Cockpit"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
          <span>Back to Cockpit</span>
        </button>
      )}

      {/* Modals */}
      <SecuritySettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      <AndroidBridgeModal
        isOpen={isAndroidBridgeOpen}
        onClose={() => setIsAndroidBridgeOpen(false)}
      />

      {/* Bottom Tactical Floating Navigation Bar on Mobile */}
      <div className="fixed bottom-0 inset-x-0 z-30 lg:hidden border-t border-white/10 bg-[#09090e]/95 backdrop-blur-2xl px-2 sm:px-4 py-2">
        <div className="flex items-center justify-around max-w-md mx-auto">
          <button
            type="button"
            onClick={() => setActiveWing('home')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'home' ? 'text-rose-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Home className="w-4 h-4" />
            <span className="text-[9px] font-mono">Cockpit</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveWing('chrononote')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'chrononote' ? 'text-rose-300 font-bold' : 'text-slate-400'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span className="text-[9px] font-mono">Notes</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveWing('duty')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'duty' ? 'text-blue-400 font-bold' : 'text-slate-400'
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span className="text-[9px] font-mono">Duty</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveWing('horizon')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'horizon' ? 'text-purple-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span className="text-[9px] font-mono">Horizon</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveWing('wealth')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'wealth' ? 'text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span className="text-[9px] font-mono">Wealth</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveWing('pulse')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg transition-colors ${
              activeWing === 'pulse' ? 'text-rose-400 font-bold' : 'text-slate-400'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span className="text-[9px] font-mono">Pulse</span>
          </button>

          <button
            type="button"
            onClick={lockVault}
            className="flex flex-col items-center gap-1 py-1 px-1.5 rounded-lg text-rose-400 hover:text-rose-300 transition-colors"
          >
            <Lock className="w-4 h-4" />
            <span className="text-[9px] font-mono">Lock</span>
          </button>
        </div>
      </div>

      {/* Footer Branding Bar */}
      <footer className="border-t border-white/5 py-4 px-6 text-center text-xs font-mono text-slate-500 bg-[#060608]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-slate-300 font-bold">AUTONOMOUS v5.0.0</span>
            <span>• CONFIDENTIAL ASSET PROTECTION</span>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-emerald-500/80">AES-GCM / SHA-256 VAULT</span>
            <span>•</span>
            <span className="text-cyan-400/80">CHRONONOTE INTELLIGENCE WORKSPACE</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <VaultProvider>
      <CockpitContent />
    </VaultProvider>
  );
}
