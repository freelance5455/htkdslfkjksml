/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export function triggerBrowserDownload(url: string, filename: string): void {
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  link.setAttribute('target', '_blank');
  link.setAttribute('rel', 'noopener noreferrer');
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();
  setTimeout(() => {
    try {
      document.body.removeChild(link);
    } catch {
      // Ignored if already removed
    }
  }, 3000);
}

export async function downloadFile(filename: string): Promise<boolean> {
  const targetPath = `/download/${filename}`;
  try {
    const response = await fetch(targetPath);
    if (response.ok) {
      const blob = await response.blob();
      const objectUrl = URL.createObjectURL(blob);
      triggerBrowserDownload(objectUrl, filename);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 10000);
      return true;
    }
  } catch (err) {
    console.warn(`Fetch download failed for ${filename}, using direct link:`, err);
  }

  // Direct native anchor fallback
  try {
    triggerBrowserDownload(targetPath, filename);
    return true;
  } catch (e) {
    console.error(`Download failed for ${filename}:`, e);
    return false;
  }
}

export async function downloadCompleteAppZip(): Promise<boolean> {
  return downloadFile('Autonomous-v5.0.0-Complete-App.zip');
}

export async function downloadAndroidProjectZip(): Promise<boolean> {
  return downloadFile('Autonomous-v5.0.0-Android-Project.zip');
}

export async function downloadAutonomousApk(): Promise<boolean> {
  return downloadFile('Autonomous-v5.0.0.apk');
}
