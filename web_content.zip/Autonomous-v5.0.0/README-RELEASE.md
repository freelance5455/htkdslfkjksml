# Autonomous v5.0.0 — Complete Application Source & Distribution

Official release package for Autonomous v5.0.0.

## Contents
1. `src/` — React 19, TypeScript, Tailwind CSS, ChronoNote Workspace & Triple Guard Vault Cockpit.
2. `public/` — Offline Service Worker, Web App Manifest, PWA icons and assets.
3. `android_project/` — Standalone Android Studio container project (Gradle 8.2, compileSdk 34, AndroidX Biometrics & WebKit).
4. `scripts/` — Automated APK builder (`build_apk.py`), Android packager (`package_android.py`), and Complete app packager.
5. Configuration files: `package.json`, `tsconfig.json`, `vite.config.ts`, `metadata.json`, `index.html`.

## Quick Start (Web)
```bash
npm install
npm run dev
# Open in Google Chrome at http://localhost:3000
```

## Quick Start (Android APK Build)
```bash
python3 scripts/build_apk.py
# Or open the 'android_project' folder in Android Studio and run 'assembleRelease'
```

## Chrome PWA Installation
Open the web app in Google Chrome on Desktop or Android.
Click the Chrome menu (⋮) -> 'Install Autonomous' or 'Add to Home screen'.
