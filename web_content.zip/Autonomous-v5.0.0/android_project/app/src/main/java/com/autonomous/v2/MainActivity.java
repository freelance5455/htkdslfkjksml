package com.autonomous.v2;

import android.os.Bundle;
import android.os.Environment;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // FLAG_SECURE: Prevents screenshots and recents snapshot leak (Zero Exposure)
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        configureWebView();
        setupBiometrics();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/web/", new WebViewAssetLoader.PathHandler() {
                @Override
                public WebResourceResponse handle(String path) {
                    try {
                        String assetPath = "www/" + path;
                        InputStream is = getAssets().open(assetPath);
                        String mimeType = "text/html";
                        if (path.endsWith(".js")) mimeType = "application/javascript";
                        else if (path.endsWith(".css")) mimeType = "text/css";
                        else if (path.endsWith(".svg")) mimeType = "image/svg+xml";
                        else if (path.endsWith(".png")) mimeType = "image/png";
                        else if (path.endsWith(".json")) mimeType = "application/json";
                        return new WebResourceResponse(mimeType, "UTF-8", is);
                    } catch (Exception e) {
                        return null;
                    }
                }
            })
            .build();

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null && "appassets.androidplatform.net".equals(url.getHost())) {
                    WebResourceResponse response = assetLoader.shouldInterceptRequest(url);
                    if (response != null) return response;

                    String path = url.getPath();
                    if (path != null) {
                        try {
                            String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                            if (cleanPath.startsWith("web/")) {
                                cleanPath = cleanPath.substring(4);
                            }
                            if (cleanPath.isEmpty() || cleanPath.equals("index.html")) {
                                cleanPath = "index.html";
                            }
                            InputStream is = getAssets().open("www/" + cleanPath);
                            String mimeType = "text/html";
                            if (cleanPath.endsWith(".js")) mimeType = "application/javascript";
                            else if (cleanPath.endsWith(".css")) mimeType = "text/css";
                            return new WebResourceResponse(mimeType, "UTF-8", is);
                        } catch (Exception ignored) {}
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Fail-safe offline fallback
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net")) {
                    view.loadUrl("file:///android_asset/www/index.html");
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        // Load direct local asset package for 100% offline instant startup
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void setupBiometrics() {
        Executor executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(MainActivity.this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    webView.evaluateJavascript("window.onBiometricSuccess && window.onBiometricSuccess();", null);
                }

                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('" + errString + "');", null);
                }
            });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autonomous v5.0.0 Hardware Biometrics")
            .setSubtitle("Authenticate executive credentials to open vault")
            .setNegativeButtonText("Use Cryptographic PIN")
            .build();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean authenticateUser() {
            runOnUiThread(() -> biometricPrompt.authenticate(promptInfo));
            return true;
        }

        @JavascriptInterface
        public boolean saveBackupToStorage(String filename, String data) {
            try {
                File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, filename);
                FileWriter writer = new FileWriter(file);
                writer.write(data);
                writer.flush();
                writer.close();

                MediaScannerConnection.scanFile(
                    MainActivity.this,
                    new String[]{file.getAbsolutePath()},
                    null, null
                );
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }
}
