import os
import zipfile

def package_complete_app():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    out_dir = os.path.join(root_dir, "public", "download")
    os.makedirs(out_dir, exist_ok=True)
    zip_path = os.path.join(out_dir, "Autonomous-v5.0.0-Complete-App.zip")

    # Exclusions
    exclude_dirs = {
        "node_modules",
        ".git",
        ".aistudio",
        "dist",
        "__pycache__",
        ".cache",
        ".gradle",
        "build"
    }
    exclude_extensions = {".pyc", ".idsig"}

    print(f"Packaging complete Autonomous v5.0.0 app from: {root_dir}")
    
    file_count = 0
    total_uncompressed_bytes = 0

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        # Also add a README.md specifically explaining the contents
        readme_content = """# Autonomous v5.0.0 — Complete Application Source & Distribution

Official release package for Autonomous v5.0.0.

## Contents
1. `src/` — React 19, TypeScript, Tailwind CSS, ChronoNote Workspace & Triple Guard Vault Cockpit.
2. `public/` — Offline Service Worker, Web App Manifest, PWA icons and assets.
3. `android_project/` — Standalone Android Studio container project (Gradle 8.2, compileSdk 34, AndroidX Biometrics & WebKit).
4. `scripts/` — Automated APK builder (`build_apk.py`), Android packager (`package_android.py`), and Complete app packager.
5. Configuration files: `package.json`, `tsconfig.json`, `vite.config.ts`, `metadata.json`, `index.html`.

## Quick Start (Web)
```bash
npm install
npm run dev
# Open in Google Chrome at http://localhost:3000
```

## Quick Start (Android APK Build)
```bash
python3 scripts/build_apk.py
# Or open the 'android_project' folder in Android Studio and run 'assembleRelease'
```

## Chrome PWA Installation
Open the web app in Google Chrome on Desktop or Android.
Click the Chrome menu (⋮) -> 'Install Autonomous' or 'Add to Home screen'.
"""
        zipf.writestr("Autonomous-v5.0.0/README-RELEASE.md", readme_content)

        for current_root, dirs, files in os.walk(root_dir):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".")]

            rel_root = os.path.relpath(current_root, root_dir)
            if rel_root == ".":
                rel_root = ""

            for file in files:
                if file.startswith("."):
                    continue
                ext = os.path.splitext(file)[1].lower()
                if ext in exclude_extensions:
                    continue
                
                # Avoid nesting the destination zip or giant zips into the archive
                if "public/download" in rel_root and (file.endswith(".zip") or file.endswith(".apk")):
                    continue

                full_path = os.path.join(current_root, file)
                archive_path = os.path.join("Autonomous-v5.0.0", rel_root, file)
                
                zipf.write(full_path, arcname=archive_path)
                file_count += 1
                total_uncompressed_bytes += os.path.getsize(full_path)

    zip_size = os.path.getsize(zip_path)
    print(f"Success! Packaged {file_count} files ({total_uncompressed_bytes:,} uncompressed bytes)")
    print(f"Created: {zip_path} ({zip_size:,} bytes / {zip_size / 1024 / 1024:.2f} MB)")

if __name__ == "__main__":
    package_complete_app()
