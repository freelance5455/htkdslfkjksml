import os
import shutil
import zipfile

def create_android_project():
    root = "android_project"
    if os.path.exists(root):
        shutil.rmtree(root)

    os.makedirs(f"{root}/.github/workflows", exist_ok=True)
    os.makedirs(f"{root}/app/src/main/java/com/autonomous/v2", exist_ok=True)
    os.makedirs(f"{root}/app/src/main/res/values", exist_ok=True)
    os.makedirs(f"{root}/app/src/main/res/layout", exist_ok=True)
    os.makedirs(f"{root}/app/src/main/assets/www", exist_ok=True)
    os.makedirs("public/download", exist_ok=True)

    # 1. settings.gradle
    with open(f"{root}/settings.gradle", "w") as f:
        f.write("""pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "Autonomous"
include ':app'
""")

    # 2. build.gradle (root)
    with open(f"{root}/build.gradle", "w") as f:
        f.write("""plugins {
    id 'com.android.application' version '8.2.2' apply false
}
""")

    # 3. app/build.gradle
    with open(f"{root}/app/build.gradle", "w") as f:
        f.write("""plugins {
    id 'com.android.application'
}

android {
    namespace 'com.autonomous.v2'
    compileSdk 34

    defaultConfig {
        applicationId "com.autonomous.v2"
        minSdk 24
        targetSdk 34
        versionCode 5
        versionName "5.0.0"
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.biometric:biometric:1.1.0'
    implementation 'androidx.webkit:webkit:1.9.0'
}
""")

    # 4. app/src/main/AndroidManifest.xml
    with open(f"{root}/app/src/main/AndroidManifest.xml", "w") as f:
        f.write("""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.autonomous.v2"
    android:versionCode="5"
    android:versionName="5.0.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />

    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="false"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Autonomous.Fullscreen">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout"
            android:theme="@style/Theme.Autonomous.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""")

    # 5. MainActivity.java (With Fixed WebViewAssetLoader and Fallback)
    with open(f"{root}/app/src/main/java/com/autonomous/v2/MainActivity.java", "w") as f:
        f.write("""package com.autonomous.v2;

import android.os.Bundle;
import android.os.Environment;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private BiometricPrompt biometricPrompt;
    private BiometricPrompt.PromptInfo promptInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // FLAG_SECURE: Prevents screenshots and recents snapshot leak (Zero Exposure)
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        configureWebView();
        setupBiometrics();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/web/", new WebViewAssetLoader.PathHandler() {
                @Override
                public WebResourceResponse handle(String path) {
                    try {
                        String assetPath = "www/" + path;
                        InputStream is = getAssets().open(assetPath);
                        String mimeType = "text/html";
                        if (path.endsWith(".js")) mimeType = "application/javascript";
                        else if (path.endsWith(".css")) mimeType = "text/css";
                        else if (path.endsWith(".svg")) mimeType = "image/svg+xml";
                        else if (path.endsWith(".png")) mimeType = "image/png";
                        else if (path.endsWith(".json")) mimeType = "application/json";
                        return new WebResourceResponse(mimeType, "UTF-8", is);
                    } catch (Exception e) {
                        return null;
                    }
                }
            })
            .build();

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null && "appassets.androidplatform.net".equals(url.getHost())) {
                    WebResourceResponse response = assetLoader.shouldInterceptRequest(url);
                    if (response != null) return response;

                    String path = url.getPath();
                    if (path != null) {
                        try {
                            String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                            if (cleanPath.startsWith("web/")) {
                                cleanPath = cleanPath.substring(4);
                            }
                            if (cleanPath.isEmpty() || cleanPath.equals("index.html")) {
                                cleanPath = "index.html";
                            }
                            InputStream is = getAssets().open("www/" + cleanPath);
                            String mimeType = "text/html";
                            if (cleanPath.endsWith(".js")) mimeType = "application/javascript";
                            else if (cleanPath.endsWith(".css")) mimeType = "text/css";
                            return new WebResourceResponse(mimeType, "UTF-8", is);
                        } catch (Exception ignored) {}
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Fail-safe offline fallback
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net")) {
                    view.loadUrl("file:///android_asset/www/index.html");
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        // Load direct local asset package for 100% offline instant startup
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void setupBiometrics() {
        Executor executor = ContextCompat.getMainExecutor(this);
        biometricPrompt = new BiometricPrompt(MainActivity.this, executor,
            new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    webView.evaluateJavascript("window.onBiometricSuccess && window.onBiometricSuccess();", null);
                }

                @Override
                public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                    webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('" + errString + "');", null);
                }
            });

        promptInfo = new BiometricPrompt.PromptInfo.Builder()
            .setTitle("Autonomous v5.0.0 Hardware Biometrics")
            .setSubtitle("Authenticate executive credentials to open vault")
            .setNegativeButtonText("Use Cryptographic PIN")
            .build();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean authenticateUser() {
            runOnUiThread(() -> biometricPrompt.authenticate(promptInfo));
            return true;
        }

        @JavascriptInterface
        public boolean saveBackupToStorage(String filename, String data) {
            try {
                File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, filename);
                FileWriter writer = new FileWriter(file);
                writer.write(data);
                writer.flush();
                writer.close();

                MediaScannerConnection.scanFile(
                    MainActivity.this,
                    new String[]{file.getAbsolutePath()},
                    null, null
                );
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }
}
""")

    # 6. Layout & Resources
    with open(f"{root}/app/src/main/res/layout/activity_main.xml", "w") as f:
        f.write("""<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#07070a">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>
""")

    with open(f"{root}/app/src/main/res/values/strings.xml", "w") as f:
        f.write("""<resources>
    <string name="app_name">Autonomous</string>
</resources>
""")

    with open(f"{root}/app/src/main/res/values/styles.xml", "w") as f:
        f.write("""<resources>
    <style name="Theme.Autonomous.Fullscreen" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowActionBar">false</item>
        <item name="android:windowFullscreen">true</item>
        <item name="android:windowContentOverlay">@null</item>
        <item name="android:windowBackground">#07070a</item>
        <item name="android:navigationBarColor">#07070a</item>
        <item name="android:statusBarColor">#07070a</item>
    </style>
</resources>
""")

    # 7. CI/CD Workflow (.github/workflows/build.yml)
    with open(f"{root}/.github/workflows/build.yml", "w") as f:
        f.write("""name: Build Autonomous v5.0.0 APK

on:
  push:
    branches: [ "main" ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v4

    - name: Set up JDK 17 (Temurin)
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'

    - name: Set up Android SDK
      uses: android-actions/setup-android@v3

    - name: Build Standalone Debug APK
      run: |
        gradle wrapper --gradle-version 8.2
        ./gradlew assembleDebug --stacktrace

    - name: Upload Standalone APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: Autonomous-v5.0.0-APK
        path: app/build/outputs/apk/debug/app-debug.apk
""")

    # 8. Copy compiled web app assets from dist into assets/www
    dist_dir = "dist"
    target_www = f"{root}/app/src/main/assets/www"
    if os.path.exists(dist_dir):
        for item in os.listdir(dist_dir):
            if item == "download":
                continue # Skip downloads recursion
            s = os.path.join(dist_dir, item)
            d = os.path.join(target_www, item)
            if os.path.isdir(s):
                shutil.copytree(s, d, dirs_exist_ok=True)
            else:
                shutil.copy2(s, d)

    # 9. Create zip archive
    zip_path = "public/download/Autonomous-v5.0.0-Android-Project.zip"
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root_dir, dirs, files in os.walk(root):
            for file in files:
                full_path = os.path.join(root_dir, file)
                rel_path = os.path.relpath(full_path, root)
                zipf.write(full_path, arcname=f"Autonomous-v5.0.0/{rel_path}")

    print(f"Archive successfully generated at {zip_path} ({os.path.getsize(zip_path)} bytes)")

if __name__ == "__main__":
    create_android_project()
