#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
import zipfile

def run(cmd, cwd=None):
    print(f"RUN: {cmd}")
    res = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if res.returncode != 0:
        print(f"FAILED (code {res.returncode}):\n{res.stderr}\n{res.stdout}")
        sys.exit(1)
    if res.stdout.strip():
        print(res.stdout)
    return res.stdout

def build_autonomous_apk():
    build_dir = "/tmp/apk_build"
    if os.path.exists(build_dir):
        shutil.rmtree(build_dir)
    os.makedirs(build_dir, exist_ok=True)

    android_sdk = "/opt/android-sdk"
    android_jar = f"{android_sdk}/platforms/android-34/android.jar"
    build_tools = f"{android_sdk}/build-tools/34.0.0"
    aapt2 = f"{build_tools}/aapt2"
    d8 = f"{build_tools}/d8"
    zipalign = f"{build_tools}/zipalign"
    apksigner = f"{build_tools}/apksigner"

    # Step 1: Ensure dist exists and copy to web assets
    print("--- Step 1: Preparing web assets ---")
    if not os.path.exists("dist/index.html"):
        run("npm run build")

    assets_www = os.path.join(build_dir, "assets/www")
    os.makedirs(assets_www, exist_ok=True)
    shutil.copytree("dist", assets_www, dirs_exist_ok=True)

    # Step 2: Prepare resources
    print("--- Step 2: Preparing Android resources ---")
    res_dir = os.path.join(build_dir, "res")
    values_dir = os.path.join(res_dir, "values")
    layout_dir = os.path.join(res_dir, "layout")
    os.makedirs(values_dir, exist_ok=True)
    os.makedirs(layout_dir, exist_ok=True)

    with open(os.path.join(values_dir, "strings.xml"), "w") as f:
        f.write("""<resources>
    <string name="app_name">Autonomous</string>
</resources>
""")

    with open(os.path.join(values_dir, "styles.xml"), "w") as f:
        f.write("""<resources>
    <style name="Theme.Autonomous.Fullscreen" parent="@android:style/Theme.NoTitleBar.Fullscreen">
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowFullscreen">true</item>
        <item name="android:windowBackground">#07070a</item>
        <item name="android:navigationBarColor">#07070a</item>
        <item name="android:statusBarColor">#07070a</item>
    </style>
</resources>
""")

    with open(os.path.join(layout_dir, "activity_main.xml"), "w") as f:
        f.write("""<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#07070a">

    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>
""")

    # Step 3: Prepare AndroidManifest.xml
    manifest_file = os.path.join(build_dir, "AndroidManifest.xml")
    with open(manifest_file, "w") as f:
        f.write("""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.autonomous.v2"
    android:versionCode="5"
    android:versionName="5.0.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />

    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="false"
        android:label="@string/app_name"
        android:theme="@style/Theme.Autonomous.Fullscreen">
        
        <activity
            android:name="com.autonomous.v2.MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout"
            android:theme="@style/Theme.Autonomous.Fullscreen">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
""")

    # Step 4: Compile Resources with aapt2
    print("--- Step 4: Compiling Resources with aapt2 ---")
    compiled_res = os.path.join(build_dir, "compiled_res.zip")
    run(f"{aapt2} compile --dir {res_dir} -o {compiled_res}")

    # Step 5: Link Resources with aapt2
    print("--- Step 5: Linking Resources with aapt2 ---")
    gen_dir = os.path.join(build_dir, "gen")
    os.makedirs(gen_dir, exist_ok=True)
    unaligned_apk = os.path.join(build_dir, "unaligned.apk")

    run(f"{aapt2} link -I {android_jar} --manifest {manifest_file} {compiled_res} "
        f"-o {unaligned_apk} --java {gen_dir} -A {build_dir}/assets --auto-add-overlay")

    # Step 6: Prepare Java Source code
    print("--- Step 6: Preparing Java Source code ---")
    src_dir = os.path.join(build_dir, "src/com/autonomous/v2")
    os.makedirs(src_dir, exist_ok=True)
    java_file = os.path.join(src_dir, "MainActivity.java")

    with open(java_file, "w") as f:
        f.write("""package com.autonomous.v2;

import android.app.Activity;
import android.content.DialogInterface;
import android.hardware.biometrics.BiometricPrompt;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.util.concurrent.Executor;

public class MainActivity extends Activity {
    private WebView webView;
    private CancellationSignal cancellationSignal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // FLAG_SECURE: Prevents screenshots and recents snapshot leak (Zero Exposure)
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        );

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);
        configureWebView();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (url != null) {
                    String host = url.getHost();
                    if ("appassets.androidplatform.net".equals(host) || "localhost".equals(host)) {
                        String path = url.getPath();
                        if (path != null) {
                            try {
                                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                                if (cleanPath.startsWith("web/")) {
                                    cleanPath = cleanPath.substring(4);
                                } else if (cleanPath.startsWith("assets/")) {
                                    cleanPath = cleanPath.substring(7);
                                }
                                if (cleanPath.isEmpty() || cleanPath.equals("index.html")) {
                                    cleanPath = "index.html";
                                }
                                InputStream is = getAssets().open("www/" + cleanPath);
                                String mimeType = "text/html";
                                if (cleanPath.endsWith(".js")) mimeType = "application/javascript";
                                else if (cleanPath.endsWith(".css")) mimeType = "text/css";
                                else if (cleanPath.endsWith(".svg")) mimeType = "image/svg+xml";
                                else if (cleanPath.endsWith(".png")) mimeType = "image/png";
                                else if (cleanPath.endsWith(".json")) mimeType = "application/json";
                                return new WebResourceResponse(mimeType, "UTF-8", is);
                            } catch (Exception ignored) {}
                        }
                    }
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                // Fail-safe offline fallback for any appassets.androidplatform.net error
                if (failingUrl != null && failingUrl.contains("appassets.androidplatform.net")) {
                    view.loadUrl("file:///android_asset/www/index.html");
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        // Robust startup: direct local file load guarantees 100% offline instant launch
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean authenticateUser() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                runOnUiThread(() -> {
                    try {
                        cancellationSignal = new CancellationSignal();
                        BiometricPrompt prompt = new BiometricPrompt.Builder(MainActivity.this)
                            .setTitle("Autonomous v5.0.0 Hardware Biometrics")
                            .setSubtitle("Authenticate executive credentials to open vault")
                            .setDescription("Biometric authentication for Autonomous Sovereign Vault")
                            .setNegativeButton("Use Master PIN", getMainExecutor(), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('Use PIN');", null);
                                }
                            })
                            .build();

                        prompt.authenticate(cancellationSignal, getMainExecutor(), new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                super.onAuthenticationSucceeded(result);
                                webView.evaluateJavascript("window.onBiometricSuccess && window.onBiometricSuccess();", null);
                            }

                            @Override
                            public void onAuthenticationError(int errorCode, CharSequence errString) {
                                super.onAuthenticationError(errorCode, errString);
                                webView.evaluateJavascript("window.onBiometricFailed && window.onBiometricFailed('" + errString + "');", null);
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                return true;
            }
            return false;
        }

        @JavascriptInterface
        public boolean saveBackupToStorage(String filename, String data) {
            try {
                File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloadDir.exists()) downloadDir.mkdirs();
                File file = new File(downloadDir, filename);
                FileWriter writer = new FileWriter(file);
                writer.write(data);
                writer.flush();
                writer.close();

                MediaScannerConnection.scanFile(
                    MainActivity.this,
                    new String[]{file.getAbsolutePath()},
                    null, null
                );
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }
}
""")

    # Step 7: Compile Java classes
    print("--- Step 7: Compiling Java Classes with javac ---")
    classes_dir = os.path.join(build_dir, "classes")
    os.makedirs(classes_dir, exist_ok=True)
    r_java = os.path.join(gen_dir, "com/autonomous/v2/R.java")
    run(f"javac -source 17 -target 17 -cp {android_jar} -d {classes_dir} {r_java} {java_file}")

    # Step 8: Dex classes with d8
    print("--- Step 8: Dexing classes with d8 ---")
    run(f"{d8} --output {build_dir} --lib {android_jar} {classes_dir}/com/autonomous/v2/*.class")

    # Step 9: Add classes.dex into unaligned apk
    print("--- Step 9: Adding classes.dex to APK with zipfile ---")
    with zipfile.ZipFile(unaligned_apk, 'a', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write(os.path.join(build_dir, "classes.dex"), arcname="classes.dex")

    # Step 10: Zipalign APK
    print("--- Step 10: Zipaligning APK ---")
    aligned_apk = os.path.join(build_dir, "aligned.apk")
    run(f"{zipalign} -p -f -v 4 {unaligned_apk} {aligned_apk}")

    # Step 11: Sign APK with debug keystore
    print("--- Step 11: Signing APK with apksigner ---")
    keystore_path = os.path.join(build_dir, "debug.keystore")
    if not os.path.exists(keystore_path):
        run(f'keytool -genkey -v -keystore {keystore_path} -storepass android -alias androiddebugkey '
            f'-keypass android -keyalg RSA -keysize 2048 -validity 10000 '
            f'-dname "CN=Android Debug,O=Android,C=US"')

    final_apk = "public/download/Autonomous-v5.0.0.apk"
    os.makedirs("public/download", exist_ok=True)
    run(f"{apksigner} sign --ks {keystore_path} --ks-pass pass:android --key-pass pass:android "
        f"--out {final_apk} {aligned_apk}")

    # Verify signature
    run(f"{apksigner} verify --verbose {final_apk}")

    size_bytes = os.path.getsize(final_apk)
    size_mb = size_bytes / (1024 * 1024)
    print(f"SUCCESS! Signed APK generated: {final_apk} ({size_bytes} bytes / {size_mb:.2f} MB)")

if __name__ == "__main__":
    build_autonomous_apk()
