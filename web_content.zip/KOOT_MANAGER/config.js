// ضع بيانات مشروع Supabase هنا بعد إنشائه. لا تضع service_role key أبداً في التطبيق.
window.KOOT_SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.KOOT_SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
