const initialPlayers=[
 ["ياسين بونو","حارس",84,"🧤"],["رامي بن سبعيني","دفاع",78,"🛡️"],["عيسى ماندي","دفاع",76,"🛡️"],["محمد أمين توغاي","دفاع",74,"🛡️"],["يوسف عطال","دفاع",75,"🛡️"],["إسماعيل بن ناصر","وسط",82,"⚙️"],["حسام عوار","وسط",79,"⚙️"],["نبيل بن طالب","وسط",77,"⚙️"],["رياض محرز","هجوم",85,"⚡"],["بغداد بونجاح","هجوم",80,"⚡"],["يوسف بلايلي","هجوم",81,"⚡"]
];
let state=JSON.parse(localStorage.getItem("koot-save")||"null")||{coins:1200,wins:0,played:0,fitness:92,morale:80,power:68,style:"balanced",players:initialPlayers};
const $=id=>document.getElementById(id);
function save(){localStorage.setItem("koot-save",JSON.stringify(state));render()}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2200)}
function render(){
 $("coins").textContent=state.coins;$("wins").textContent=state.wins;$("played").textContent=state.played;$("fitness").textContent=state.fitness+"%";$("morale").textContent=state.morale+"%";$("teamPower").textContent=state.power;$("style").value=state.style;
 $("players").innerHTML=state.players.map(p=>`<div class="player"><div class="avatar">${p[3]}</div><div class="player-info"><b>${p[0]}</b><small>${p[1]} · أساسي</small></div><div class="rating">${p[2]}</div></div>`).join("");
 $("squadCount").textContent=state.players.length+" لاعباً";
}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));btn.classList.add("active");$(btn.dataset.tab).classList.add("active")}));
$("style").addEventListener("change",e=>{state.style=e.target.value;const hints={balanced:"خطة متوازنة بين الدفاع والهجوم.",attack:"ضغط هجومي أكبر مع مخاطرة دفاعية.",defense:"تنظيم دفاعي محكم والاعتماد على المرتدات.",possession:"التركيز على الاستحواذ والتمرير."};$("styleHint").textContent=hints[state.style]});
$("saveTactics").onclick=()=>{save();toast("تم حفظ الخطة التكتيكية")};
document.querySelectorAll("[data-training]").forEach(btn=>btn.onclick=()=>{
 const type=btn.dataset.training,cost={fitness:100,shooting:150,chemistry:120}[type];
 if(state.coins<cost){toast("رصيدك غير كافٍ");return}
 state.coins-=cost;
 if(type==="fitness")state.fitness=Math.min(100,state.fitness+12);
 if(type==="shooting")state.power+=2;
 if(type==="chemistry")state.morale=Math.min(100,state.morale+10);
 save();toast("تم التدريب بنجاح!");
});
$("playMatch").onclick=()=>{
 const tacticBonus=state.style==="attack"?5:state.style==="possession"?3:state.style==="defense"?1:2;
 const score=Math.random()*100+state.power+tacticBonus+(state.fitness-70)*.25;
 const opponent=65+Math.random()*25;
 const goals=score>opponent+25?3:score>opponent+8?2:score>opponent-8?1:0;
 const against=score<opponent-25?3:score<opponent-8?2:score<opponent+8?1:0;
 state.played++;if(goals>against){state.wins++;state.coins+=180;state.morale=Math.min(100,state.morale+5)}else{state.coins+=60;state.morale=Math.max(40,state.morale-3)}
 state.fitness=Math.max(55,state.fitness-8);save();
 $("matchResult").innerHTML=`<div style="font-size:40px">🏆</div><span class="eyebrow">نتيجة المباراة التجريبية</span><h2>اتحاد العاصمة <span class="score">${goals} - ${against}</span> مولودية وهران</h2><p>${goals>against?"فوز رائع! حصلت على 180 قطعة نقدية.":goals===against?"تعادل جيد. حصلت على 60 قطعة نقدية.":"خسارة هذه المرة. حصلت على 60 قطعة نقدية."}</p><button class="primary" onclick="document.getElementById('modal').classList.remove('show')">متابعة</button>`;
 $("modal").classList.add("show");
};
$("closeModal").onclick=()=>$("modal").classList.remove("show");
render();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));


// ---- Online multiplayer (Supabase) ----
let sb=null, currentUser=null, myClub=null, realtimeChannels=[];
const configured=()=>window.KOOT_SUPABASE_URL && window.KOOT_SUPABASE_ANON_KEY && !window.KOOT_SUPABASE_URL.includes('YOUR-PROJECT') && !window.KOOT_SUPABASE_ANON_KEY.includes('YOUR_SUPABASE');
function onlineMsg(message){toast(message)}
function setOnlineState(label){$('connectionState').textContent=label}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function setupOnline(){
 if(!configured() || !window.supabase?.createClient){$('backendNotice').hidden=false;return}
 $('backendNotice').hidden=true;
 sb=window.supabase.createClient(window.KOOT_SUPABASE_URL,window.KOOT_SUPABASE_ANON_KEY);
 sb.auth.getSession().then(({data})=>{if(data.session) onSignedIn(data.session.user);else setOnlineState('غير متصل')});
 sb.auth.onAuthStateChange((_event,session)=>{if(session) onSignedIn(session.user);else resetOnline()});
 $('signIn').onclick=()=>authAction('signin');$('signUp').onclick=()=>authAction('signup');$('signOut').onclick=async()=>{await sb.auth.signOut();onlineMsg('تم تسجيل الخروج')};
 $('createClub').onclick=createClub;
 loadOnlineData();
}
async function authAction(mode){
 const email=$('email').value.trim(),password=$('password').value;
 if(!email||password.length<6){onlineMsg('أدخل بريداً صحيحاً وكلمة مرور من 6 أحرف على الأقل');return}
 setOnlineState('جارٍ الاتصال…');
 const result=mode==='signup'?await sb.auth.signUp({email,password}):await sb.auth.signInWithPassword({email,password});
 if(result.error){setOnlineState('خطأ');onlineMsg(result.error.message);return}
 if(mode==='signup'&&!result.data.session)onlineMsg('تحقق من بريدك الإلكتروني لتأكيد الحساب، ثم سجّل الدخول');
 else if(result.data.user)onSignedIn(result.data.user);
}
async function onSignedIn(user){
 currentUser=user;setOnlineState('متصل');$('authBox').hidden=true;$('onlineDashboard').hidden=false;
 const {data:club}=await sb.from('clubs').select('*').eq('owner_id',user.id).maybeSingle();
 myClub=club;
 $('clubBox').hidden=!!club;
 if(club){$('myClub').innerHTML=`<div class="club-row"><div><b>${esc(club.name)}</b><small>قوة ${club.power} · ${club.wins} فوز · ${club.played} مباراة</small></div><span class="status-pill">🪙 ${club.coins}</span></div>`}
 await loadOnlineData();subscribeOnline();
}
function resetOnline(){currentUser=null;myClub=null;$('authBox').hidden=false;$('clubBox').hidden=true;$('onlineDashboard').hidden=true;setOnlineState('غير متصل');realtimeChannels.forEach(c=>sb?.removeChannel(c));realtimeChannels=[]}
async function createClub(){
 const manager=$('managerName').value.trim(),name=$('clubName').value.trim();
 if(manager.length<3||name.length<3){onlineMsg('اكتب اسم مدرب واسم نادٍ (3 أحرف على الأقل)');return}
 let r=await sb.rpc('create_koot_profile',{p_username:manager});if(r.error){onlineMsg(r.error.message);return}
 r=await sb.rpc('create_koot_club',{p_name:name});if(r.error){onlineMsg(r.error.message);return}
 onlineMsg('تم إنشاء ناديك بنجاح');await onSignedIn(currentUser);
}
async function loadOnlineData(){if(!sb||!currentUser)return;
 const [clubsRes,challengeRes,profileRes]=await Promise.all([
  sb.from('clubs').select('id,owner_id,name,power,wins,played,coins,created_at').order('wins',{ascending:false}).limit(50),
  sb.from('challenges').select('*').order('created_at',{ascending:false}).limit(50),
  sb.from('profiles').select('id,username')
 ]);
 if(clubsRes.error||challengeRes.error){onlineMsg((clubsRes.error||challengeRes.error).message);return}
 const clubs=clubsRes.data||[],profiles=profileRes.data||[],pmap=Object.fromEntries(profiles.map(p=>[p.id,p.username]));
 myClub=clubs.find(c=>c.owner_id===currentUser.id)||myClub;
 if(!myClub){$('clubBox').hidden=false;$('onlineDashboard').hidden=false;return}
 $('clubBox').hidden=true;$('onlineDashboard').hidden=false;
 $('myClub').innerHTML=`<div class="club-row"><div><b>${esc(myClub.name)}</b><small>قوة ${myClub.power} · ${myClub.wins} فوز · ${myClub.played} مباراة</small></div><span class="status-pill">🪙 ${myClub.coins}</span></div>`;
 const opponents=clubs.filter(c=>c.id!==myClub.id);
 $('opponents').innerHTML=opponents.length?opponents.map(c=>`<div class="online-item"><b>${esc(c.name)}</b><small>المدرب: ${esc(pmap[c.owner_id]||'مدرب')} · القوة ${c.power} · ${c.wins} فوز</small><button class="secondary" onclick="sendChallenge('${c.id}')">تحدي النادي</button></div>`).join(''):'<p class="hint">لا توجد أندية أخرى بعد. ادعُ صديقاً لإنشاء نادٍ.</p>';
 const byId=Object.fromEntries(clubs.map(c=>[c.id,c]));
 $('challenges').innerHTML=(challengeRes.data||[]).filter(x=>x.challenger_club_id===myClub.id||x.challenged_club_id===myClub.id).map(x=>{
  const incoming=x.challenged_club_id===myClub.id,other=byId[incoming?x.challenger_club_id:x.challenged_club_id];
  let actions='';if(incoming&&x.status==='pending')actions=`<div class="challenge-actions"><button class="primary" onclick="respondChallenge('${x.id}',true)">قبول</button><button class="secondary" onclick="respondChallenge('${x.id}',false)">رفض</button></div>`;
  if(x.status==='accepted')actions=`<div class="challenge-actions"><button class="primary" onclick="playOnlineMatch('${x.id}')">بدء المباراة</button></div>`;
  const result=x.status==='completed'?` · النتيجة ${incoming?x.challenged_goals+' - '+x.challenger_goals:x.challenger_goals+' - '+x.challenged_goals}`:'';
  return `<div class="online-item"><b>${incoming?'تحدٍ من ':'تحديك ضد '}${esc(other?.name||'نادي')}</b><small>الحالة: ${statusArabic(x.status)}${result}</small>${actions}</div>`;
 }).join('')||'<p class="hint">لا توجد تحديات حالياً.</p>';
 $('leaderboard').innerHTML=clubs.map((c,i)=>`<div class="online-item club-row"><div><b>${i+1}. ${esc(c.name)}</b><small>قوة ${c.power} · لعب ${c.played}</small></div><span class="status-pill">${c.wins} فوز</span></div>`).join('');
}
function statusArabic(s){return ({pending:'بانتظار الرد',accepted:'مقبول - بانتظار اللعب',completed:'انتهت',declined:'مرفوض'})[s]||s}
async function sendChallenge(id){const {error}=await sb.rpc('send_koot_challenge',{p_target_club:id});if(error)onlineMsg(error.message);else{onlineMsg('تم إرسال التحدي');loadOnlineData()}}
async function respondChallenge(id,accept){const {error}=await sb.rpc('respond_koot_challenge',{p_challenge:id,p_accept:accept});if(error)onlineMsg(error.message);else{onlineMsg(accept?'قبلت التحدي!':'تم رفض التحدي');loadOnlineData()}}
async function playOnlineMatch(id){const {data,error}=await sb.rpc('play_koot_match',{p_challenge:id});if(error){onlineMsg(error.message);return}const d=data;$('matchResult').innerHTML=`<div style="font-size:40px">⚽</div><span class="eyebrow">نتيجة المباراة عبر الإنترنت</span><h2>${esc(d.challenger)} <span class="score">${d.challenger_goals} - ${d.challenged_goals}</span> ${esc(d.challenged)}</h2><p>تم حفظ النتيجة على الخادم وتحديث ترتيب الناديين.</p><button class="primary" onclick="document.getElementById('modal').classList.remove('show')">متابعة</button>`;$('modal').classList.add('show');await loadOnlineData()}
function subscribeOnline(){if(!sb||!currentUser)return;realtimeChannels.forEach(c=>sb.removeChannel(c));realtimeChannels=[];const ch=sb.channel('koot-live-'+currentUser.id).on('postgres_changes',{event:'*',schema:'public',table:'challenges'},()=>loadOnlineData()).on('postgres_changes',{event:'*',schema:'public',table:'clubs'},()=>loadOnlineData()).subscribe();realtimeChannels.push(ch)}
window.sendChallenge=sendChallenge;window.respondChallenge=respondChallenge;window.playOnlineMatch=playOnlineMatch;
setupOnline();
