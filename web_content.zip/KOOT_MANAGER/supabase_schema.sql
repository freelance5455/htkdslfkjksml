-- KOOT MANAGER multiplayer backend
-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 20),
  created_at timestamptz not null default now()
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 3 and 30),
  power integer not null default 68 check (power between 1 and 150),
  coins integer not null default 1200 check (coins >= 0),
  wins integer not null default 0,
  played integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.challenges (
  id uuid primary key default gen_random_uuid(),
  challenger_club_id uuid not null references public.clubs(id) on delete cascade,
  challenged_club_id uuid not null references public.clubs(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','completed','declined')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  challenger_goals integer,
  challenged_goals integer,
  check (challenger_club_id <> challenged_club_id)
);

create index if not exists challenges_inbox_idx on public.challenges(challenged_club_id,status,created_at desc);
create index if not exists challenges_outbox_idx on public.challenges(challenger_club_id,status,created_at desc);

alter table public.profiles enable row level security;
alter table public.clubs enable row level security;
alter table public.challenges enable row level security;

drop policy if exists "Profiles visible to signed-in users" on public.profiles;
create policy "Profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "Clubs visible to signed-in users" on public.clubs;
create policy "Clubs visible to signed-in users" on public.clubs for select to authenticated using (true);
-- Club writes happen only through trusted database functions below.

drop policy if exists "Challenge participants can view" on public.challenges;
create policy "Challenge participants can view" on public.challenges for select to authenticated using (
 exists(select 1 from public.clubs c where c.id = challenger_club_id and c.owner_id = auth.uid()) or
 exists(select 1 from public.clubs c where c.id = challenged_club_id and c.owner_id = auth.uid())
);

create or replace function public.create_koot_profile(p_username text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid := auth.uid(); v_username text := trim(p_username);
begin
 if v_id is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
 if char_length(v_username) < 3 or char_length(v_username) > 20 then raise exception 'اسم المدرب يجب أن يكون بين 3 و20 حرفاً'; end if;
 insert into profiles(id,username) values(v_id,v_username) on conflict(id) do update set username=excluded.username;
 return jsonb_build_object('ok',true);
end; $$;

create or replace function public.create_koot_club(p_name text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid := auth.uid(); v_club public.clubs;
begin
 if v_id is null then raise exception 'يجب تسجيل الدخول أولاً'; end if;
 if not exists(select 1 from profiles where id=v_id) then raise exception 'أنشئ ملف المدرب أولاً'; end if;
 if char_length(trim(p_name)) < 3 or char_length(trim(p_name)) > 30 then raise exception 'اسم النادي يجب أن يكون بين 3 و30 حرفاً'; end if;
 insert into clubs(owner_id,name) values(v_id,trim(p_name)) on conflict(owner_id) do update set name=excluded.name returning * into v_club;
 return jsonb_build_object('club_id',v_club.id,'name',v_club.name,'power',v_club.power,'coins',v_club.coins);
end; $$;

create or replace function public.send_koot_challenge(p_target_club uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_my_club uuid; v_challenge uuid;
begin
 select id into v_my_club from clubs where owner_id=auth.uid();
 if v_my_club is null then raise exception 'أنشئ ناديك أولاً'; end if;
 if p_target_club=v_my_club then raise exception 'لا يمكنك تحدي ناديك'; end if;
 if not exists(select 1 from clubs where id=p_target_club) then raise exception 'النادي غير موجود'; end if;
 insert into challenges(challenger_club_id,challenged_club_id) values(v_my_club,p_target_club) returning id into v_challenge;
 return v_challenge;
end; $$;

create or replace function public.respond_koot_challenge(p_challenge uuid,p_accept boolean)
returns void language plpgsql security definer set search_path = public as $$
declare v_row challenges;
begin
 select * into v_row from challenges where id=p_challenge for update;
 if not found then raise exception 'التحدي غير موجود'; end if;
 if not exists(select 1 from clubs where id=v_row.challenged_club_id and owner_id=auth.uid()) then raise exception 'هذا التحدي ليس موجهاً إليك'; end if;
 if v_row.status <> 'pending' then raise exception 'تمت معالجة هذا التحدي مسبقاً'; end if;
 update challenges set status=case when p_accept then 'accepted' else 'declined' end where id=p_challenge;
end; $$;

create or replace function public.play_koot_match(p_challenge uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_row challenges; v_a clubs; v_b clubs; v_ga integer; v_gb integer;
begin
 select * into v_row from challenges where id=p_challenge for update;
 if not found then raise exception 'المباراة غير موجودة'; end if;
 if v_row.status <> 'accepted' then raise exception 'يجب قبول التحدي أولاً'; end if;
 if not exists(select 1 from clubs where id in (v_row.challenger_club_id,v_row.challenged_club_id) and owner_id=auth.uid()) then raise exception 'لست طرفاً في هذه المباراة'; end if;
 select * into v_a from clubs where id=v_row.challenger_club_id for update;
 select * into v_b from clubs where id=v_row.challenged_club_id for update;
 -- Server-side match simulation; clients cannot submit or edit the score.
 v_ga := greatest(0,least(5,round((v_a.power/28.0) + random()*2.2 - 1.1)::integer));
 v_gb := greatest(0,least(5,round((v_b.power/28.0) + random()*2.2 - 1.1)::integer));
 update clubs set played=played+1, wins=wins+case when v_ga>v_gb then 1 else 0 end,
   coins=coins+case when v_ga>v_gb then 180 else 60 end where id=v_a.id;
 update clubs set played=played+1, wins=wins+case when v_gb>v_ga then 1 else 0 end,
   coins=coins+case when v_gb>v_ga then 180 else 60 end where id=v_b.id;
 update challenges set status='completed',challenger_goals=v_ga,challenged_goals=v_gb,resolved_at=now() where id=p_challenge;
 return jsonb_build_object('challenger',v_a.name,'challenged',v_b.name,'challenger_goals',v_ga,'challenged_goals',v_gb);
end; $$;

revoke all on function public.create_koot_profile(text) from public;
revoke all on function public.create_koot_club(text) from public;
revoke all on function public.send_koot_challenge(uuid) from public;
revoke all on function public.respond_koot_challenge(uuid,boolean) from public;
revoke all on function public.play_koot_match(uuid) from public;
grant execute on function public.create_koot_profile(text) to authenticated;
grant execute on function public.create_koot_club(text) to authenticated;
grant execute on function public.send_koot_challenge(uuid) to authenticated;
grant execute on function public.respond_koot_challenge(uuid,boolean) to authenticated;
grant execute on function public.play_koot_match(uuid) to authenticated;
grant select on public.profiles, public.clubs, public.challenges to authenticated;

-- Realtime: add tables only if they are not already in the publication.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='clubs') then
    alter publication supabase_realtime add table public.clubs;
  end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='challenges') then
    alter publication supabase_realtime add table public.challenges;
  end if;
end $$;
