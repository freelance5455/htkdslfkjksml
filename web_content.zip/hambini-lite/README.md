# Hambini Lite

Hambini Lite — o‘zbek tilidagi, mobil operator xizmatlari uchun tayyorlangan demo web-ilova.

## Funksiyalar
- Telefon raqami orqali demo profil yaratish
- Balansni ko‘rish va virtual to‘ldirish
- Demo tariflar va paketlar
- Internet, daqiqa va SMS qoldiqlari
- Amallar tarixi
- Profil ismini va bildirishnoma sozlamasini o‘zgartirish
- Ma’lumotlarni brauzer `localStorage` xotirasida saqlash
- Mobil ekranga mos dizayn

## Muhim
Bu loyiha rasmiy Beeline ilovasi emas. Operator tizimiga ulanmaydi. Balans, tariflar, paketlar va tranzaksiyalar demo ma’lumotlaridir. Haqiqiy xizmatlar uchun operator ruxsati, API va xavfsiz backend kerak.

## GitHub orqali ishga tushirish
1. GitHub’da `hambini-lite` nomli repository yarating.
2. Ushbu papkadagi `index.html`, `style.css`, `app.js`, `manifest.json` va `README.md` fayllarini repository’ga yuklang.
3. Repository’da **Settings → Pages** bo‘limiga kiring.
4. **Deploy from a branch** ni tanlang.
5. Branch sifatida `main`, folder sifatida `/ (root)` ni tanlab **Save** bosing.
6. Bir necha daqiqadan keyin GitHub Pages bergan manzilni oching.

## Acode orqali tahrirlash
Fayllarni telefoningizga yuklab oling va Acode’da loyiha papkasini oching. `index.html` ni brauzerda tekshiring. O‘zgarishlarni GitHub repository’ga yuklang.

## Keyingi bosqichlar
- Haqiqiy autentifikatsiya va backend
- Ruxsat etilgan operator API integratsiyasi
- Serverda saqlanadigan profil
- PWA uchun service worker va ikonlar
- Android APK uchun WebView yoki Capacitor loyihasi
