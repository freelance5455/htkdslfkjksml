Chibi Teto Playtime — Android app project

This wraps the offline Chibi Teto Playtime mini-game in an Android WebView.
The HTML and embedded Teto image are included in app/src/main/assets/index.html.
The app requests no internet permission and is designed to run offline.

To build an APK:
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync (Android SDK Platform 35 and Android Gradle Plugin 8.7.3 are used).
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Find the APK under app/build/outputs/apk/debug/.

This ZIP contains source code, not a ready-to-install APK. Building requires Android Studio/Android SDK.
