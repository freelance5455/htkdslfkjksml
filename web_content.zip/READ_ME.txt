GURU COIN FRONTEND

1. Extract this ZIP on your Android phone.
2. Open GURU_COIN_Full_Frontend.html using Chrome.
3. This is a frontend demo only, not an APK and not a deployed cryptocurrency.
