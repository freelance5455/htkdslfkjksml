CIVIL CALCULATOR — READY PACKAGE

This is an offline HTML app. It needs no internet for calculations.

PHONE USE:
1. Copy Civil_Calculator.html to your Android phone.
2. Open it with Chrome or another browser.
3. If Chrome shows "Add to Home screen", choose it.
4. If that option does not appear for a local file, do NOT worry: open the file directly from Files whenever needed. The calculator itself is offline.

IMPORTANT:
This package is not a signed Android APK. A true APK must be compiled and signed by an Android build environment. Do not install APKs from unknown sources.
