# Bendahara RT — Android APK Project

HTML aplikasi ditanam langsung di `app/src/main/assets/index.html`.

## Build di Android Studio
1. Buka folder `BENDAHARA_RT_ANDROID_PROJECT`.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build APK(s)**.
4. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Untuk APK rilis: **Build > Generate Signed Bundle / APK**.

## Online + Offline
- HTML/UI utama berada di dalam APK, sehingga dapat dibuka tanpa hosting.
- Permission INTERNET tetap tersedia untuk Firebase/CDN/fungsi online saat internet tersedia.
- Data lokal/localStorage tetap dapat dipakai saat offline selama fitur tersebut memang tidak membutuhkan server.

## Catatan
Versi HTML saat ini masih memuat pdf.js dan Tesseract.js dari CDN. Karena itu fungsi PDF/OCR yang membutuhkan library tersebut memerlukan internet kecuali library tersebut nanti dibundel ke `assets`.
