# COD Assistant (Android, Kotlin + WebView)

UI = web prototype in `app/src/main/assets/index.html`.
Kotlin side = `NativeBridge.kt` (real device data and actions) + `OverlayService.kt` (floating panel).

## Build
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder, wait for Gradle sync.
3. Run on a phone (USB debugging) or Build > Build APK(s).

## What is real now (via NativeBridge)
- Battery level, charging, battery temperature, thermal status (Android 10+)
- RAM total/free, internal storage free, display refresh rate, model, Android version
- Do Not Disturb state (read only) and a shortcut to its settings screen
- Wi-Fi vs cellular detection; TCP connect time to 1.1.1.1:443 (not the game server)
- Real notifications (asks POST_NOTIFICATIONS only when you tap the test), vibrate, share
- Optional floating panel (asks "display over other apps" only when you tap it)

## Not available (shown as "در دسترس نیست" / "در دست توسعه")
- CPU usage and CPU temperature, FPS inside the game, touch sampling rate
- Screen recording / screenshot shortcut, home-screen widget, background reminders (WorkManager)

## Before publishing
- Change applicationId and app name (avoid the Call of Duty trademark; add an "unofficial" notice).
- FOREGROUND_SERVICE_SPECIAL_USE and SYSTEM_ALERT_WINDOW need a Play Console declaration.
- Write a privacy policy. Add Play Billing (or Bazaar/Myket billing) for Pro/Premium.
- This project was written without a compiler available; expect to fix small build errors on first sync.
