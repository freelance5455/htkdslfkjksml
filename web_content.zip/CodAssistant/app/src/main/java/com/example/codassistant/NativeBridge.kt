package com.example.codassistant

import android.Manifest
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Display
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Real device data and actions for the web UI.
 * Everything returned here comes from official Android APIs.
 * Values that Android does not expose are returned as JSON null (the UI shows "در دسترس نیست").
 */
class NativeBridge(private val act: AppCompatActivity) {

    private val ctx: Context = act.applicationContext
    private val channelId = "cod_assistant"

    // ---------- Status ----------
    @JavascriptInterface
    fun getStatus(): String {
        val o = JSONObject()

        // Battery (sticky broadcast, no permission needed)
        val bi = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        o.put("battery", if (level >= 0 && scale > 0) level * 100.0 / scale else JSONObject.NULL)
        o.put("charging", (bi?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0)
        val t = bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        o.put("battTemp", if (t != Int.MIN_VALUE) t / 10.0 else JSONObject.NULL)

        // Memory
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        o.put("ramTotalGB", mi.totalMem / 1073741824.0)
        o.put("ramFreeMB", mi.availMem / 1048576.0)
        o.put("ramUsedPct", if (mi.totalMem > 0) 100.0 - mi.availMem * 100.0 / mi.totalMem else JSONObject.NULL)

        // Internal storage
        val sf = StatFs(Environment.getDataDirectory().path)
        o.put("storeFreeGB", sf.availableBytes / 1073741824.0)
        o.put("storeTotalGB", sf.totalBytes / 1073741824.0)

        // Thermal status (Android 10+)
        if (Build.VERSION.SDK_INT >= 29) {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            val names = mapOf(
                PowerManager.THERMAL_STATUS_NONE to "عادی",
                PowerManager.THERMAL_STATUS_LIGHT to "کمی گرم",
                PowerManager.THERMAL_STATUS_MODERATE to "گرم",
                PowerManager.THERMAL_STATUS_SEVERE to "خیلی گرم",
                PowerManager.THERMAL_STATUS_CRITICAL to "بحرانی",
                PowerManager.THERMAL_STATUS_EMERGENCY to "اضطراری",
                PowerManager.THERMAL_STATUS_SHUTDOWN to "خاموشی"
            )
            o.put("thermal", names[pm.currentThermalStatus] ?: JSONObject.NULL)
        } else o.put("thermal", JSONObject.NULL)

        // Display refresh rate (independent of FPS)
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        o.put("refresh", dm.getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: JSONObject.NULL)

        // Do Not Disturb state (read only)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        o.put("dnd", nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL)

        // Network type
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        o.put(
            "net", when {
                caps == null -> "none"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                else -> "other"
            }
        )

        o.put("model", Build.MODEL ?: "")
        o.put("android", Build.VERSION.RELEASE ?: "")
        return o.toString()
    }

    // ---------- Network ----------
    /** TCP connect time in ms to host:port (no DNS when an IP is given). -1 on failure. */
    @JavascriptInterface
    fun pingOnce(host: String, port: Int, timeoutMs: Int): Int = try {
        Socket().use { s ->
            val t0 = System.nanoTime()
            s.connect(InetSocketAddress(host, port), timeoutMs)
            ((System.nanoTime() - t0) / 1_000_000).toInt()
        }
    } catch (e: Exception) {
        -1
    }

    // ---------- Notifications ----------
    @JavascriptInterface
    fun notifGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    @JavascriptInterface
    fun requestNotif() {
        if (Build.VERSION.SDK_INT >= 33 && !notifGranted()) {
            act.runOnUiThread {
                act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    @JavascriptInterface
    fun notify(title: String, body: String) {
        if (!notifGranted()) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "COD Assistant", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val n = Notification.Builder(ctx, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }

    // ---------- Small actions ----------
    @JavascriptInterface
    fun vibrate(ms: Int) {
        val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (v.hasVibrator()) v.vibrate(VibrationEffect.createOneShot(ms.toLong().coerceIn(10, 1000), VibrationEffect.DEFAULT_AMPLITUDE))
    }

    @JavascriptInterface
    fun share(text: String) {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            act.startActivity(Intent.createChooser(i, null))
        }
    }

    /** Opens the system screen where the user may grant Do Not Disturb access. The app never changes DND by itself. */
    @JavascriptInterface
    fun openDnd() {
        act.runOnUiThread {
            act.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    // ---------- Floating panel ----------
    @JavascriptInterface
    fun overlayAllowed(): Boolean = Settings.canDrawOverlays(ctx)

    @JavascriptInterface
    fun requestOverlay() {
        act.runOnUiThread {
            act.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }
    }

    @JavascriptInterface
    fun startOverlay(cfgJson: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        act.runOnUiThread {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, OverlayService::class.java).putExtra("cfg", cfgJson)
            )
        }
    }

    @JavascriptInterface
    fun stopOverlay() {
        act.runOnUiThread { ctx.stopService(Intent(ctx, OverlayService::class.java)) }
    }

    // ---------- Crosshair overlay ----------
    @JavascriptInterface
    fun startCrosshair(cfgJson: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        act.runOnUiThread {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, CrosshairService::class.java).putExtra("cfg", cfgJson)
            )
        }
    }

    @JavascriptInterface
    fun stopCrosshair() {
        act.runOnUiThread { ctx.stopService(Intent(ctx, CrosshairService::class.java)) }
    }
}
