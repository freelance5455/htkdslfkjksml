package com.example.codassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import org.json.JSONObject

/**
 * Static crosshair drawn above other apps.
 * It is NOT touchable: every touch goes straight through to the game.
 * It never reads the game, never aims, never injects input.
 */
class CrosshairService : Service() {

    private var wm: WindowManager? = null
    private var view: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        removeView()
        build(JSONObject(intent?.getStringExtra("cfg") ?: "{}"))
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("cod_overlay", "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "cod_overlay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("COD Assistant")
            .setContentText("Crosshair is on")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
    }

    private fun build(cfg: JSONObject) {
        val dm = resources.displayMetrics
        val kind = cfg.optInt("style", 0)
        val color = try { Color.parseColor(cfg.optString("col", "#39ff88")) } catch (e: Exception) { Color.GREEN }
        val factor = cfg.optDouble("size", 1.0).toFloat().coerceIn(0.5f, 2f)
        val px = (64 * dm.density * factor).toInt()

        val v = CrosshairView(this, kind, color)
        v.alpha = (cfg.optDouble("op", 1.0).toFloat()).coerceIn(0.2f, 1f)

        val lp = WindowManager.LayoutParams(
            px, px,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = (dm.widthPixels * cfg.optDouble("dx", 0.0) / 100).toInt()
            y = (dm.heightPixels * cfg.optDouble("dy", 0.0) / 100).toInt()
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm?.addView(v, lp)
        view = v
    }

    private fun removeView() {
        view?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        view = null
    }

    override fun onDestroy() {
        removeView()
        super.onDestroy()
    }
}

class CrosshairView(ctx: Context, private val kind: Int, private val col: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = col
        strokeWidth = 3f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val c = w / 2f
        when (kind) {
            0 -> { // cross with a gap in the middle
                val gap = w * 0.08f
                val len = w * 0.36f
                canvas.drawLine(c, c - len, c, c - gap, paint)
                canvas.drawLine(c, c + gap, c, c + len, paint)
                canvas.drawLine(c - len, c, c - gap, c, paint)
                canvas.drawLine(c + gap, c, c + len, c, paint)
            }
            1 -> { // dot
                paint.style = Paint.Style.FILL
                canvas.drawCircle(c, c, w * 0.07f, paint)
                paint.style = Paint.Style.STROKE
            }
            2 -> { // circle with a center dot
                canvas.drawCircle(c, c, w * 0.28f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(c, c, w * 0.04f, paint)
                paint.style = Paint.Style.STROKE
            }
            else -> { // chevron
                val p = Path()
                p.moveTo(c - w * 0.22f, c + w * 0.14f)
                p.lineTo(c, c - w * 0.14f)
                p.lineTo(c + w * 0.22f, c + w * 0.14f)
                canvas.drawPath(p, paint)
            }
        }
    }
}
