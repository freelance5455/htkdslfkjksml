package com.example.codassistant

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lightweight floating panel. It only shows battery, elapsed time, clock and free RAM.
 * It never touches the game, never injects touches and updates once per second.
 */
class OverlayService : Service() {

    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val startedAt = System.currentTimeMillis()
    private var items = JSONObject()
    private var lastX = 0f
    private var lastY = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        removePanel()
        build(JSONObject(intent?.getStringExtra("cfg") ?: "{}"))
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("cod_overlay", "Floating panel", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "cod_overlay")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("COD Assistant")
            .setContentText("Floating panel is on")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun build(cfg: JSONObject) {
        items = cfg.optJSONObject("it") ?: JSONObject()
        val locked = cfg.optBoolean("lock", false)
        val size = cfg.optInt("size", 100)
        val op = cfg.optInt("op", 90)
        val color = try { Color.parseColor(cfg.optString("col", "#e8ff1a")) } catch (e: Exception) { Color.YELLOW }
        val dm = resources.displayMetrics

        val view = TextView(this).apply {
            setTextColor(color)
            textSize = 12f * size / 100f
            setPadding(18, 12, 18, 12)
            alpha = op / 100f
            background = GradientDrawable().apply {
                setColor(Color.argb(220, 10, 10, 12))
                setStroke(2, color)
                cornerRadius = 10f
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels * cfg.optDouble("x", 55.0) / 100).toInt()
            y = (dm.heightPixels * cfg.optDouble("y", 8.0) / 100).toInt()
        }

        if (!locked) {
            view.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { lastX = e.rawX; lastY = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x += (e.rawX - lastX).toInt()
                        lp.y += (e.rawY - lastY).toInt()
                        lastX = e.rawX; lastY = e.rawY
                        wm?.updateViewLayout(view, lp)
                    }
                }
                true
            }
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm?.addView(view, lp)
        tv = view
        tick()
    }

    private val ticker = Runnable { tick() }

    private fun tick() {
        val v = tv ?: return
        val lines = ArrayList<String>()
        if (items.optBoolean("bat", true)) {
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val s = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (l >= 0 && s > 0) lines.add("Battery ${l * 100 / s}%")
        }
        if (items.optBoolean("timer", true)) {
            val sec = (System.currentTimeMillis() - startedAt) / 1000
            lines.add(String.format(Locale.US, "Time %02d:%02d:%02d", sec / 3600, sec / 60 % 60, sec % 60))
        }
        if (items.optBoolean("clock", false)) {
            lines.add(SimpleDateFormat("HH:mm", Locale.US).format(Date()))
        }
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi)
        lines.add("RAM free ${(mi.availMem * 100 / mi.totalMem)}%")
        v.text = lines.joinToString("\n")
        handler.postDelayed(ticker, 1000)
    }

    private fun removePanel() {
        handler.removeCallbacks(ticker)
        tv?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        tv = null
    }

    override fun onDestroy() {
        removePanel()
        super.onDestroy()
    }
}
