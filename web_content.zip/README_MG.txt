PAGE PRO+ — PROJET ANDROID APK

Ity dia projet Android natao hamokarana APK amin'ny GitHub Actions.
Tsy APK efa vita izy ity.

ZAVA-DEHIBE:
- Mila apetraka aloha ny serveur Page Pro+ amin'ny Render.
- Rehefa mahazo adiresy https://...onrender.com ianao dia ovay ny PAGEPRO_URL.
- Ao amin'ny GitHub repository: Settings > Secrets and variables > Actions > Variables > New repository variable
  Name: PAGEPRO_URL
  Value: adiresy HTTPS an'ilay serveur Render.
- Avy eo mandehana amin'ny Actions > Build Page Pro+ APK > Run workflow.
- Rehefa vita, sokafy ny run farany > Artifacts > Page-Pro-Plus-APK ary alao ny app-debug.apk.

Tsy asiana mot de passe na kaody miafina ao amin'ny GitHub.
