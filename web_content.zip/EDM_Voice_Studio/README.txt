EDM Voice Studio — Android-friendly ZIP

HOW TO USE
1. Extract this ZIP on your Android phone.
2. Open index.html in Chrome (or another modern browser).
3. Tap the upload area and select your song file.
4. Select a preset and adjust Pitch, Echo, Bass and Reverb.
5. Tap “Style लगाकर WAV बनाएँ”, wait, then download the WAV.

IMPORTANT
- This is a standalone browser app; no backend folder, Python, or server is required.
- Processing happens locally in the browser.
- It applies audio effects; it does not use AI to generate a new melody, isolate vocals, or clone a singer.
- WAV export can use significant memory. If processing fails, try a shorter/smaller audio file.
- Browser audio format support varies. MP3 and WAV are usually the safest inputs.
