MY EXPENSES — PERSONAL EXPENSE TRACKER

Included:
- Add expense: amount, date, category, description
- Add/delete categories
- Monthly total and category summary
- All-time summary
- Expense history with delete
- Local-only storage
- JSON backup export/import
- Minimal mobile-friendly design

QUICK START
1. Unzip this folder.
2. Open index.html in Chrome/Edge on a phone or computer.
3. Start adding expenses.

IMPORTANT
The app stores data in the browser on the device. Export a backup from the Backup section occasionally.

INSTALL AS AN APP
For a true installable home-screen app, the files need to be served over HTTPS. If you put this folder on any static HTTPS host, open the site in Chrome and use “Add to Home screen” / “Install app”.
