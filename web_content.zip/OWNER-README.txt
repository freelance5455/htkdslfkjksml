OWNER TOOL (sirf aapke liye - kisi ko mat dena)

1. owner.html ko apne phone/laptop ke browser mein kholo (double click).
2. 'const SECRET=' ki value badlo - bilkul wahi jo inventory app ke index.html mein hai.
3. User ka Device Code daalo -> GET ACTIVATION PIN -> PIN user ko batao.
4. Recover account (app delete / password bhool gaya): user ka PURANA device code daalo -> RECOVERY PIN do (3 din chalta hai).
   Code yaad na ho to neeche Issued list mein naam ya number se search karo.
5. Activation list isi browser mein save hoti hai (same browser use karo).
