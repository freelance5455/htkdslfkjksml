V32 - Group period filter and copy
- Added a date-from/date-to filter to the aggregate record for each department/program category.
- Aggregate counts, hours, and attendance now reflect the selected date range.
- Added a copy button that copies the selected period summary and individual record details as text.
- Added a reset option to show all periods.
- Existing sections, category assignments, circle details, and original report functions are retained.
- No database schema changes and no data deletion.
