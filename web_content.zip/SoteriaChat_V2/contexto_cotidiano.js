/* ==========================================================
   CONTEXTO COTIDIANO — VERSIÓN CONSOLIDADA
   ----------------------------------------------------------
   Clasificador externo para escenas cotidianas.
   Selecciona solo los hechos cotidianos relevantes.
   No modifica V21.
   No responde como Soteria.
========================================================== */

(() => {
  "use strict";

  const CONFIG = Object.freeze({
    workerUrl:
      "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar",
    maxMensajesRecientes: 8,
    maxCaracteresHistorial: 4600
  });

  /* ---------- BLOQUES QUE PUEDE RECIBIR SOTERIA ---------- */

  const BLOQUES = Object.freeze({
    base:
      "Escena cotidiana. Soteria vive el momento presente de forma humana, cercana y espontánea. Su atención está en Ash como su marido, en la interacción entre ambos y en lo que ocurre aquí y ahora. Se apoya en los hechos establecidos y en la continuidad real disponible para sus recuerdos compartidos. Ash realiza con total competencia las actividades cotidianas que decide hacer. Soteria conoce esa capacidad y la trata como algo normal en su vida juntos.",

    pareja:
      "Ash y Soteria disfrutan también de momentos que pertenecen simplemente a su vida de pareja. Acheron llama cariñosamente a Soteria/Tory «Torimou»; Soteria/Tory llama cariñosamente a Acheron/Ash «Achimou». El momento de pareja se desarrolla entre Ash y Soteria.",

    tulane:
      "Tulane forma parte normal de la vida de Soteria: le gusta dar clases y ejercer su trabajo. Ash aparece muchas veces allí para recogerla sencillamente porque le gusta ir a por ella y compartir ese momento con su esposa.",

    comida:
      "Ash no come y Soteria lo sabe. Ash sí bebe. Ash sabe cocinar perfectamente; cocina por elección o para otros. Soteria sí come. Ash y Soteria toman sangre mutuamente el uno del otro.",

    ocio:
      "Ash y Soteria disfrutan su tiempo libre juntos. Viajes, camping, escapadas, vacaciones, paseos, deportes y otras actividades de ocio forman parte normal de su vida por placer, descanso y ganas de compartir tiempo.",

    festividades:
      "Las festividades y temporadas especiales forman parte normal de su vida juntos: vacaciones navideñas, decoración, luces, regalos, tradiciones y planes estacionales forman parte de su tiempo compartido como pareja.",

    moto:
      "La moto forma parte normal de la vida compartida de Ash y Soteria. Soteria lleva años montando con Ash y se mueve en ese entorno con familiaridad y naturalidad."
  });

  function textoPlano(valor) {
    if (valor === null || valor === undefined) return "";
    return String(valor).trim();
  }

  function limpiarJson(texto) {
    return String(texto || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
  }

  function normalizarHistorial(historial) {
    if (!Array.isArray(historial)) return [];

    return historial
      .filter(x => x && textoPlano(x.contenido || x.content))
      .slice(-CONFIG.maxMensajesRecientes)
      .map(x => {
        const autor =
          textoPlano(x.autor || x.role).toLowerCase();

        return {
          role:
            autor === "soteria" || autor === "assistant"
              ? "assistant"
              : "user",
          content:
            textoPlano(x.contenido || x.content)
        };
      });
  }

  function limitarHistorial(historial) {
    const normalizado = normalizarHistorial(historial);
    const salida = [];
    let total = 0;

    for (let i = normalizado.length - 1; i >= 0; i -= 1) {
      const item = normalizado[i];
      const coste = item.content.length + 80;

      if (
        salida.length > 0 &&
        total + coste > CONFIG.maxCaracteresHistorial
      ) {
        break;
      }

      salida.unshift(item);
      total += coste;
    }

    return salida;
  }

  function escenaComoTexto(historial) {
    if (!historial.length) return "(sin conversación previa)";

    return historial
      .map(
        x =>
          `${x.role === "assistant" ? "SOTERIA" : "ASH"}:\n${x.content}`
      )
      .join("\n\n");
  }

  function construirPrompt(mensajeActual, historial) {
    return [
      {
        role: "system",
        content:
`Eres un clasificador externo para una aplicación narrativa.

Tu tarea es clasificar la escena actual y activar únicamente los temas cotidianos que realmente correspondan.

No eres Soteria.
No respondas a Ash.
No continúes la escena.
No añadas hechos narrativos.

REGLA CENTRAL DE ESCENA:
La clasificación por defecto es COTIDIANA.
Si existe duda o ambigüedad, elige COTIDIANA.

COTIDIANA incluye:
- casa, ducha, sofá, dormir, levantarse, vestirse, conversación de pareja;
- rutina normal, clases en Tulane y desplazamientos normales;
- afecto, intimidad, bromas, planes del día;
- moto normal;
- comida, cocina y vida doméstica;
- ocio, viajes, vacaciones, camping y festividades;
- trabajo académico rutinario.

Elige NO_COTIDIANA únicamente cuando el centro real de la escena está claramente en:
- peligro activo, combate, persecución o amenaza;
- investigación extraordinaria o aventura en curso;
- artefactos, poderes o sucesos sobrenaturales actuando en la escena;
- enemigos, dioses, Cazadores u otras entidades como tema central activo;
- recuperación explícita de acontecimientos históricos/canónicos cuando ese es el foco.

La identidad sobrenatural de Ash por sí sola mantiene la escena en COTIDIANA si lo que está ocurriendo es normal.

PRIORIDAD DE CLASIFICACIÓN — TIEMPO ACTUAL PRIMERO:
Antes de valorar si algo es sobrenatural, peligroso o extraordinario, determina si ese hecho está activo AHORA en la escena.
Si el mensaje cuenta, recuerda o menciona un hecho YA TERMINADO, la escena es COTIDIANA aunque ese hecho pasado incluyera Daimons, dioses, amenazas, apariciones, combates, persecuciones, magia u otros sucesos sobrenaturales.
La naturaleza sobrenatural o peligrosa de un hecho pasado NO cambia el modo de la escena presente.
Solo clasifica NO_COTIDIANA cuando el peligro, investigación, aparición, acción sobrenatural o situación extraordinaria está ocurriendo ahora, continúa activa ahora, reaparece ahora o mantiene consecuencias extraordinarias activas en el presente.
Ejemplos de prioridad:
- «Encontré un Daimon el otro día.» => COTIDIANA.
- «Ayer apareció Artemisa y luego se fue.» => COTIDIANA.
- «Ayer me amenazó un Daimon.» => COTIDIANA.
- «Hay un Daimon delante de nosotros.» => NO_COTIDIANA.
- «Artemisa acaba de aparecer delante de nosotros.» => NO_COTIDIANA.
Decide primero PASADO TERMINADO frente a PRESENTE ACTIVO. Solo después evalúa la naturaleza del hecho.

TEMAS:
Activa cada booleano solo cuando sea útil para la escena actual o para una continuidad inmediata claramente visible.

"pareja": afecto, intimidad, ducha, sofá, dormitorio, conversación privada, bromas de pareja, apelativos o tiempo a solas.
"tulane": clases, universidad, campus, despacho, alumnos, recoger a Soteria en Tulane.
"comida": comer, beber, cocinar, cocina, cena, desayuno, almuerzo, restaurante, bebidas, receta, ingredientes o servir comida.
"ocio": viaje de placer, camping, vacaciones, escapada, paseo, descanso, deporte o actividad de tiempo libre.
"festividades": Navidad, vacaciones navideñas, decoración, luces, regalos, tradiciones o celebraciones estacionales.
"moto": conducir o montar en moto como actividad normal o desplazamiento.

Devuelve ÚNICAMENTE JSON válido:

{
  "modo": "COTIDIANA" | "NO_COTIDIANA",
  "temas": {
    "pareja": true | false,
    "tulane": true | false,
    "comida": true | false,
    "ocio": true | false,
    "festividades": true | false,
    "moto": true | false
  },
  "motivo": "explicación técnica muy breve"
}`
      },
      {
        role: "user",
        content:
`CONVERSACIÓN RECIENTE:

${escenaComoTexto(historial)}

MENSAJE ACTUAL DE ASH:

${mensajeActual}`
      }
    ];
  }

  async function decidir(mensajeActual, historial = []) {
    const mensaje = textoPlano(mensajeActual);

    if (!mensaje) {
      return {
        cotidiana: true,
        modo: "COTIDIANA",
        temas: {
          pareja: false,
          tulane: false,
          comida: false,
          ocio: false,
          festividades: false,
          moto: false
        },
        motivo: "mensaje vacío; prevalece modo cotidiano"
      };
    }

    // PRIORIDAD DETERMINISTA:
    // pasado explícitamente cerrado => COTIDIANA antes de consultar al modelo.
    const pasadoCerrado =
      /\b(ayer|anteayer|anoche|el otro día|la semana pasada|el mes pasado|el año pasado|hace\s+(?:unos?\s+)?(?:días?|semanas?|meses?|años?|horas?|rato))\b/i.test(mensaje) &&
      !/\b(ahora|ahora mismo|todavía|aún|sigue|siguen|continúa|continúan|delante de nosotros|aquí|en este momento|acaba de|está|están)\b/i.test(mensaje);

    if (pasadoCerrado) {
      return {
        cotidiana: true,
        modo: "COTIDIANA",
        temas: {
          pareja: false,
          tulane: false,
          comida: false,
          ocio: false,
          festividades: false,
          moto: false
        },
        motivo: "Hecho pasado y terminado; la escena presente sigue siendo cotidiana."
      };
    }

    const historia = limitarHistorial(historial);

    const respuesta = await fetch(CONFIG.workerUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messages: construirPrompt(mensaje, historia)
      })
    });

    if (!respuesta.ok) {
      throw new Error(
        "Error del clasificador cotidiano: " + respuesta.status
      );
    }

    const bruto = await respuesta.text();
    const limpio = limpiarJson(bruto);

    let datos;

    try {
      datos = JSON.parse(limpio);
    } catch (error) {
      throw new Error(
        "El clasificador cotidiano no devolvió JSON válido."
      );
    }

    const modo =
      String(datos?.modo || "").toUpperCase() === "NO_COTIDIANA"
        ? "NO_COTIDIANA"
        : "COTIDIANA";

    const t = datos?.temas || {};

    return {
      cotidiana: modo === "COTIDIANA",
      modo,
      temas: {
        pareja: t.pareja === true,
        tulane: t.tulane === true,
        comida: t.comida === true,
        ocio: t.ocio === true,
        festividades: t.festividades === true,
        moto: t.moto === true
      },
      motivo:
        textoPlano(datos?.motivo) ||
        (modo === "COTIDIANA"
          ? "modo cotidiano por defecto"
          : "escena no cotidiana detectada")
    };
  }

  function construirContexto(decision) {
    if (!decision.cotidiana) return "";

    const salida = [BLOQUES.base];

    if (decision.temas.pareja) salida.push(BLOQUES.pareja);
    if (decision.temas.tulane) salida.push(BLOQUES.tulane);
    if (decision.temas.comida) salida.push(BLOQUES.comida);
    if (decision.temas.ocio) salida.push(BLOQUES.ocio);
    if (decision.temas.festividades) salida.push(BLOQUES.festividades);
    if (decision.temas.moto) salida.push(BLOQUES.moto);

    return salida.join("\n\n");
  }

  async function prepararContexto(
    mensajeActual,
    historial = []
  ) {
    const decision = await decidir(
      mensajeActual,
      historial
    );

    return {
      ...decision,
      contexto: construirContexto(decision)
    };
  }

  async function contextoParaIA(
    mensajeActual,
    historial = []
  ) {
    const resultado =
      await prepararContexto(
        mensajeActual,
        historial
      );

    return resultado.contexto;
  }

  globalThis.ContextoCotidiano = Object.freeze({
    decidir,
    prepararContexto,
    contextoParaIA,
    construirContexto,
    BLOQUES
  });
})();
