/* ==========================================================
   BUSCADOR ACHERON — RECUPERACIÓN NARRATIVA LOCAL
   ----------------------------------------------------------
   - No modifica ACHERON_INTEGRAL.md.
   - No crea fichas, escenas ni categorías temáticas.
   - Divide el libro SOLO en memoria para poder recuperarlo.
   - Usa metadatos objetivos: posición, líneas y encabezados.
   - Devuelve contexto continuo alrededor de cada resultado.

   Requiere, en este orden:
   1) Libro_Acheron/acheron_integral_runtime.js
   2) lector_acheron.js
   3) este archivo
========================================================== */

(() => {
  "use strict";

  const CONFIG = Object.freeze({
    objetivoCaracteresChunk: 2400,
    maximoCaracteresChunk: 3200,
    solapamientoParrafos: 2,
    contextoResultado: 2600,
    maxResultados: 3,
    maxContextoIA: 8500,
    maxCandidatosSemanticos: 28,
    caracteresExtractoCandidato: 850,
    distanciaMinRelacion: 22000,
    maxSeleccionSemanticaRelacion: 7,
    workerUrl:
      "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar"
  });

  const STOPWORDS = new Set([
    "a","al","algo","algun","alguna","algunas","alguno","algunos",
    "ante","antes","aquel","aquella","aquellas","aquello","aquellos",
    "aqui","asi","aunque","bajo","bien","cada","casi","como","con",
    "contra","cual","cuando","de","del","desde","donde","dos","durante",
    "e","el","ella","ellas","ello","ellos","en","entre","era","erais",
    "eran","eras","eres","es","esa","esas","ese","eso","esos","esta",
    "estaba","estaban","estado","estamos","estan","estar","estas","este",
    "esto","estos","fue","fuera","fueron","ha","hace","hacia","han",
    "hasta","hay","la","las","le","les","lo","los","mas","me","mi",
    "mientras","mis","muy","nada","ni","no","nos","o","otra","otras",
    "otro","otros","para","pero","poco","por","porque","que","quien",
    "quienes","se","sea","ser","si","sin","sobre","solo","son","su",
    "sus","tambien","te","tenia","tiene","tienen","todo","todos","tu",
    "tus","un","una","unas","uno","unos","ya","yo"
  ]);

  const ALIAS = Object.freeze({
    ash: ["acheron"],
    acheron: ["ash"],
    tory: ["soteria"],
    sota: ["soteria"],
    soteria: ["tory", "sota"]
  });

  let estado = {
    listo: false,
    construyendo: null,
    texto: "",
    textoNormalizado: "",
    lineStarts: [],
    encabezados: [],
    parrafos: [],
    chunks: [],
    indice: new Map(),
    df: new Map(),
    longitudMedia: 0,
    entidadesProbables: new Set()
  };

  function raizGlobal() {
    return typeof window !== "undefined" ? window : globalThis;
  }

  function quitarMarcasMarkdown(texto) {
    return String(texto || "")
      .replace(/^#{1,6}\s+/gm, "")
      .replace(/[*_`~]/g, "")
      .replace(/\[(.*?)\]\(.*?\)/g, "$1");
  }

  function normalizar(texto) {
    return quitarMarcasMarkdown(texto)
      .toLocaleLowerCase("es")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^\p{L}\p{N}'’-]+/gu, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function raizSuave(token) {
    let t = token;

    if (t.length < 6) return t;

    const sufijos = [
      "amientos","imientos","aciones","adores","adoras",
      "mente","acion","idades","idad","iendo","ando",
      "ados","adas","idos","idas","amiento","imiento"
    ];

    for (const sufijo of sufijos) {
      if (t.length - sufijo.length >= 4 && t.endsWith(sufijo)) {
        return t.slice(0, -sufijo.length);
      }
    }

    if (t.length > 7 && t.endsWith("es")) return t.slice(0, -2);
    if (t.length > 6 && t.endsWith("s")) return t.slice(0, -1);

    return t;
  }

  function tokenizar(texto, incluirStopwords = false) {
    const limpio = normalizar(texto);
    if (!limpio) return [];

    const salida = [];
    const vistos = new Set();

    for (const token of limpio.split(" ")) {
      if (token.length < 2) continue;
      if (!incluirStopwords && STOPWORDS.has(token)) continue;

      if (!vistos.has(token)) {
        salida.push(token);
        vistos.add(token);
      }

      const r = raizSuave(token);
      const claveRaiz = "~" + r;

      if (
        r !== token &&
        r.length >= 4 &&
        !vistos.has(claveRaiz)
      ) {
        salida.push(claveRaiz);
        vistos.add(claveRaiz);
      }

      const alias = ALIAS[token];
      if (alias) {
        for (const a of alias) {
          if (!vistos.has(a)) {
            salida.push(a);
            vistos.add(a);
          }
        }
      }
    }

    return salida;
  }

  function posicionesLineas(texto) {
    const starts = [0];

    for (let i = 0; i < texto.length; i += 1) {
      if (texto.charCodeAt(i) === 10) {
        starts.push(i + 1);
      }
    }

    return starts;
  }

  function lineaDesdePosicion(pos) {
    const a = estado.lineStarts;
    let izq = 0;
    let der = a.length - 1;

    while (izq <= der) {
      const medio = (izq + der) >> 1;

      if (a[medio] <= pos) {
        izq = medio + 1;
      } else {
        der = medio - 1;
      }
    }

    return der + 1;
  }

  function construirEncabezados(texto) {
    const encabezados = [];
    const patron = /^(#{1,6})\s+(.+?)\s*$/gm;
    let m;

    while ((m = patron.exec(texto)) !== null) {
      encabezados.push({
        nivel: m[1].length,
        titulo: m[2].trim(),
        inicio: m.index,
        fin: m.index + m[0].length,
        linea: lineaDesdePosicion(m.index)
      });
    }

    return encabezados;
  }

  function rutaEncabezadosEn(posicion) {
    const ruta = new Array(6).fill(null);

    for (const h of estado.encabezados) {
      if (h.inicio > posicion) break;

      ruta[h.nivel - 1] = h.titulo;

      for (let n = h.nivel; n < ruta.length; n += 1) {
        ruta[n] = null;
      }
    }

    return ruta
      .filter(Boolean)
      .map((titulo, i) => ({
        nivel: i + 1,
        titulo
      }));
  }

  function construirParrafos(texto) {
    const bloques = [];
    const patron = /(?:^|\n{2,})([^\n][\s\S]*?)(?=\n{2,}|$)/g;
    let m;

    while ((m = patron.exec(texto)) !== null) {
      const contenido = m[1];
      const offsetDentro = m[0].lastIndexOf(contenido);
      const inicio = m.index + Math.max(0, offsetDentro);
      const fin = inicio + contenido.length;

      if (/^#{1,6}\s+/.test(contenido.trim())) {
        continue;
      }

      bloques.push({
        inicio,
        fin,
        lineaInicio: lineaDesdePosicion(inicio),
        lineaFin: lineaDesdePosicion(fin),
        texto: contenido.trim()
      });
    }

    return bloques;
  }

  function construirChunks() {
    const p = estado.parrafos;
    const chunks = [];

    let i = 0;

    while (i < p.length) {
      const inicioIndice = i;
      let finIndice = i;
      let longitud = 0;

      while (finIndice < p.length) {
        const siguiente = p[finIndice].texto.length + 2;

        if (
          finIndice > inicioIndice &&
          longitud >= CONFIG.objetivoCaracteresChunk &&
          longitud + siguiente > CONFIG.maximoCaracteresChunk
        ) {
          break;
        }

        longitud += siguiente;
        finIndice += 1;

        if (
          longitud >= CONFIG.objetivoCaracteresChunk &&
          finIndice - inicioIndice >= 2
        ) {
          break;
        }
      }

      const primero = p[inicioIndice];
      const ultimo = p[finIndice - 1];

      const inicio = primero.inicio;
      const fin = ultimo.fin;
      const textoChunk = estado.texto.slice(inicio, fin).trim();
      const ruta = rutaEncabezadosEn(inicio);

      chunks.push({
        id: chunks.length,
        inicio,
        fin,
        lineaInicio: primero.lineaInicio,
        lineaFin: ultimo.lineaFin,
        ruta,
        tituloRuta: ruta.map(x => x.titulo).join(" > "),
        texto: textoChunk,
        normalizado: normalizar(textoChunk),
        longitudTokens: 0
      });

      if (finIndice >= p.length) break;

      const retroceso = Math.min(
        CONFIG.solapamientoParrafos,
        Math.max(0, finIndice - inicioIndice - 1)
      );

      i = Math.max(inicioIndice + 1, finIndice - retroceso);
    }

    return chunks;
  }

  function indexarChunks() {
    const indice = new Map();
    const df = new Map();
    let sumaLongitudes = 0;

    for (const chunk of estado.chunks) {
      const tokensCrudos = normalizar(
        chunk.tituloRuta + " " + chunk.texto
      ).split(" ");

      const frecuencias = new Map();
      let cuenta = 0;

      for (const tokenOriginal of tokensCrudos) {
        if (!tokenOriginal || tokenOriginal.length < 2) continue;

        const token = tokenOriginal;
        const esStop = STOPWORDS.has(token);

        if (!esStop) {
          frecuencias.set(
            token,
            (frecuencias.get(token) || 0) + 1
          );
          cuenta += 1;
        }

        const r = raizSuave(token);
        if (
          !esStop &&
          r !== token &&
          r.length >= 4
        ) {
          const clave = "~" + r;
          frecuencias.set(
            clave,
            (frecuencias.get(clave) || 0) + 0.55
          );
        }

        const alias = ALIAS[token];
        if (alias) {
          for (const a of alias) {
            frecuencias.set(
              a,
              (frecuencias.get(a) || 0) + 0.35
            );
          }
        }
      }

      chunk.longitudTokens = Math.max(1, cuenta);
      sumaLongitudes += chunk.longitudTokens;

      for (const [token, tf] of frecuencias) {
        if (!indice.has(token)) {
          indice.set(token, new Map());
        }

        indice.get(token).set(chunk.id, tf);
        df.set(token, (df.get(token) || 0) + 1);
      }
    }

    estado.indice = indice;
    estado.df = df;
    estado.longitudMedia =
      estado.chunks.length
        ? sumaLongitudes / estado.chunks.length
        : 1;
  }

  async function inicializar() {
    if (estado.listo) return obtenerResumen();

    if (estado.construyendo) {
      return estado.construyendo;
    }

    estado.construyendo = (async () => {
      const raiz = raizGlobal();

      if (!raiz.LectorAcheron) {
        throw new Error(
          "No está cargado lector_acheron.js."
        );
      }

      if (!raiz.AcheronFuenteIntegral) {
        throw new Error(
          "No está cargado acheron_integral_runtime.js."
        );
      }

      await raiz.LectorAcheron.cargar();

      const texto = String(
        raiz.AcheronFuenteIntegral.texto || ""
      ).replace(/\r\n?/g, "\n");

      if (!texto.trim()) {
        throw new Error("La fuente integral está vacía.");
      }

      estado.texto = texto;
      estado.textoNormalizado = normalizar(texto);
      estado.lineStarts = posicionesLineas(texto);
      estado.encabezados = construirEncabezados(texto);
      estado.parrafos = construirParrafos(texto);
      estado.entidadesProbables =
        construirEntidadesProbables(texto);
      estado.chunks = construirChunks();

      indexarChunks();

      estado.listo = true;
      estado.construyendo = null;

      return obtenerResumen();
    })();

    try {
      return await estado.construyendo;
    } catch (error) {
      estado.construyendo = null;
      throw error;
    }
  }

  function obtenerResumen() {
    return {
      listo: estado.listo,
      caracteres: estado.texto.length,
      parrafos: estado.parrafos.length,
      fragmentosTecnicos: estado.chunks.length,
      encabezados: estado.encabezados.length,
      entidadesProbables:
        estado.entidadesProbables.size,
      longitudMediaTokens:
        Math.round(estado.longitudMedia)
    };
  }

  function asegurarListo() {
    if (!estado.listo) {
      throw new Error(
        "BuscadorAcheron todavía no está inicializado."
      );
    }
  }

  function idf(token) {
    const n = estado.chunks.length;
    const d = estado.df.get(token) || 0;

    return Math.log(
      1 + (n - d + 0.5) / (d + 0.5)
    );
  }

  function terminosConsulta(consulta, pistas = []) {
    const texto = [
      String(consulta || ""),
      ...(
        Array.isArray(pistas)
          ? pistas.map(String)
          : []
      )
    ].join(" ");

    return tokenizar(texto);
  }

  function ngramasSignificativos(consulta) {
    const tokens = normalizar(consulta)
      .split(" ")
      .filter(
        t =>
          t.length >= 3 &&
          !STOPWORDS.has(t)
      );

    const ngramas = [];

    for (let n = 3; n >= 2; n -= 1) {
      for (let i = 0; i <= tokens.length - n; i += 1) {
        ngramas.push(tokens.slice(i, i + n).join(" "));
      }
    }

    return ngramas;
  }


  function construirEntidadesProbables(texto) {
    const capitalizadas = new Map();
    const totales = new Map();

    const patronCapital =
      /\b[\p{Lu}ÁÉÍÓÚÜÑ][\p{Ll}áéíóúüñ]{2,}\b/gu;

    let m;

    while ((m = patronCapital.exec(texto)) !== null) {
      const token = normalizar(m[0]);

      if (
        !token ||
        token.length < 3 ||
        STOPWORDS.has(token)
      ) {
        continue;
      }

      capitalizadas.set(
        token,
        (capitalizadas.get(token) || 0) + 1
      );
    }

    const tokensTotales =
      normalizar(texto).split(" ");

    for (const token of tokensTotales) {
      if (
        !token ||
        token.length < 3 ||
        STOPWORDS.has(token)
      ) {
        continue;
      }

      totales.set(
        token,
        (totales.get(token) || 0) + 1
      );
    }

    const salida = new Set();

    for (const [token, vecesCap] of capitalizadas) {
      const vecesTotal =
        totales.get(token) || vecesCap;

      const proporcion =
        vecesCap / Math.max(1, vecesTotal);

      if (
        vecesCap >= 2 &&
        (
          proporcion >= 0.55 ||
          vecesCap >= 20
        )
      ) {
        salida.add(token);
      }
    }

    for (const [token, alias] of Object.entries(ALIAS)) {
      salida.add(token);
      alias.forEach(a => salida.add(a));
    }

    return salida;
  }

  function gruposEntidadConsulta(consulta) {
    const palabras =
      String(consulta || "")
        .match(/\p{L}[\p{L}'’-]*/gu) || [];

    const grupos = [];

    for (const original of palabras) {
      const token = normalizar(original);

      if (
        !token ||
        token.length < 3 ||
        STOPWORDS.has(token)
      ) {
        continue;
      }

      if (!estado.entidadesProbables.has(token)) {
        continue;
      }

      const variantes = new Set([token]);

      const alias = ALIAS[token] || [];
      alias.forEach(a => variantes.add(a));

      for (const [clave, valores] of Object.entries(ALIAS)) {
        if (valores.includes(token)) {
          variantes.add(clave);
          valores.forEach(v => variantes.add(v));
        }
      }

      let fusionado = false;

      for (const existente of grupos) {
        if (
          [...variantes].some(v =>
            existente.variantes.has(v)
          )
        ) {
          variantes.forEach(v =>
            existente.variantes.add(v)
          );
          fusionado = true;
          break;
        }
      }

      if (!fusionado) {
        grupos.push({
          etiqueta: original,
          variantes
        });
      }
    }

    return grupos;
  }

  function grupoPresenteEnChunk(chunk, grupo) {
    for (const variante of grupo.variantes) {
      if (
        chunk.normalizado.includes(variante)
      ) {
        return true;
      }
    }

    return false;
  }

  function contarEntidadesPresentes(chunk, grupos) {
    let cuenta = 0;

    for (const grupo of grupos) {
      if (grupoPresenteEnChunk(chunk, grupo)) {
        cuenta += 1;
      }
    }

    return cuenta;
  }

  function metricasEntidadesChunk(chunk, grupos) {
    if (!grupos.length) {
      return {
        presentes: 0,
        menciones: 0,
        distanciaMinima: Infinity
      };
    }

    const texto =
      chunk.texto.toLocaleLowerCase("es");

    const posicionesPorGrupo =
      grupos.map(grupo => {
        const posiciones = [];

        for (const variante of grupo.variantes) {
          posiciones.push(
            ...posicionesPalabra(
              texto,
              variante
            )
          );
        }

        posiciones.sort((a, b) => a - b);
        return posiciones;
      });

    const presentes =
      posicionesPorGrupo.filter(
        posiciones => posiciones.length > 0
      ).length;

    const menciones =
      posicionesPorGrupo.reduce(
        (suma, posiciones) =>
          suma + posiciones.length,
        0
      );

    let distanciaMinima = Infinity;

    if (
      posicionesPorGrupo.length >= 2 &&
      posicionesPorGrupo[0].length &&
      posicionesPorGrupo[1].length
    ) {
      for (const a of posicionesPorGrupo[0]) {
        for (const b of posicionesPorGrupo[1]) {
          distanciaMinima =
            Math.min(
              distanciaMinima,
              Math.abs(a - b)
            );
        }
      }
    }

    return {
      presentes,
      menciones,
      distanciaMinima
    };
  }

  function posicionesPalabra(textoMinusculas, palabra) {
    const salida = [];
    let desde = 0;

    while (desde < textoMinusculas.length) {
      const i = textoMinusculas.indexOf(palabra, desde);
      if (i === -1) break;

      const antes =
        i === 0 ? " " : textoMinusculas[i - 1];

      const despues =
        i + palabra.length >= textoMinusculas.length
          ? " "
          : textoMinusculas[i + palabra.length];

      const esLetraAntes = /\p{L}|\p{N}/u.test(antes);
      const esLetraDespues = /\p{L}|\p{N}/u.test(despues);

      if (!esLetraAntes && !esLetraDespues) {
        salida.push(i);
      }

      desde = i + Math.max(1, palabra.length);
    }

    return salida;
  }

  function focoPorEntidades(chunk, grupos) {
    if (!grupos.length) return null;

    const texto = chunk.texto.toLocaleLowerCase("es");

    const posicionesPorGrupo = grupos.map(grupo => {
      const posiciones = [];

      for (const variante of grupo.variantes) {
        posiciones.push(
          ...posicionesPalabra(texto, variante)
        );
      }

      posiciones.sort((a, b) => a - b);
      return posiciones;
    });

    if (
      posicionesPorGrupo.length >= 2 &&
      posicionesPorGrupo[0].length &&
      posicionesPorGrupo[1].length
    ) {
      let mejor = null;

      for (const a of posicionesPorGrupo[0]) {
        for (const b of posicionesPorGrupo[1]) {
          const distancia = Math.abs(a - b);

          if (!mejor || distancia < mejor.distancia) {
            mejor = {
              distancia,
              posicion: Math.round((a + b) / 2)
            };
          }
        }
      }

      if (mejor) return mejor.posicion;
    }

    const todas =
      posicionesPorGrupo
        .flat()
        .sort((a, b) => a - b);

    if (!todas.length) return null;

    return todas[Math.floor(todas.length / 2)];
  }

  function focoPorConsulta(chunk, consulta) {
    const texto =
      chunk.texto.toLocaleLowerCase("es");

    const tokens =
      tokenizar(consulta)
        .filter(t => !t.startsWith("~"))
        .filter(t => t.length >= 3);

    const posiciones = [];

    for (const token of tokens) {
      posiciones.push(
        ...posicionesPalabra(texto, token)
      );
    }

    if (!posiciones.length) {
      return Math.floor(chunk.texto.length / 2);
    }

    posiciones.sort((a, b) => a - b);
    return posiciones[Math.floor(posiciones.length / 2)];
  }

  function puntuar(
    consulta,
    pistas = [],
    gruposEntidades = []
  ) {
    const terminos = terminosConsulta(consulta, pistas);

    if (!terminos.length) {
      return [];
    }

    const candidatos = new Map();
    const k1 = 1.35;
    const b = 0.72;

    for (const token of terminos) {
      const postings = estado.indice.get(token);
      if (!postings) continue;

      const pesoRaiz =
        token.startsWith("~") ? 0.55 : 1;

      const pesoIdf =
        idf(token) * pesoRaiz;

      for (const [chunkId, tf] of postings) {
        const chunk = estado.chunks[chunkId];

        const bm25 =
          pesoIdf *
          (
            (tf * (k1 + 1)) /
            (
              tf +
              k1 *
              (
                1 - b +
                b *
                (
                  chunk.longitudTokens /
                  estado.longitudMedia
                )
              )
            )
          );

        candidatos.set(
          chunkId,
          (candidatos.get(chunkId) || 0) + bm25
        );
      }
    }

    const ngramas =
      ngramasSignificativos(consulta);

    const salida = [];

    for (const [chunkId, base] of candidatos) {
      const chunk = estado.chunks[chunkId];
      let score = base;

      const tituloNorm =
        normalizar(chunk.tituloRuta);

      for (const token of terminos) {
        const limpio =
          token.replace(/^~/, "");

        if (
          limpio.length >= 3 &&
          tituloNorm.includes(limpio)
        ) {
          score += idf(token) * 0.9;
        }
      }

      for (const ng of ngramas) {
        if (chunk.normalizado.includes(ng)) {
          score += 2.8 + ng.split(" ").length;
        }
      }

      const consultaNorm =
        normalizar(consulta);

      if (
        consultaNorm.length >= 12 &&
        chunk.normalizado.includes(consultaNorm)
      ) {
        score += 12;
      }

      const metricasEntidades =
        metricasEntidadesChunk(
          chunk,
          gruposEntidades
        );

      const entidadesCoincidentes =
        metricasEntidades.presentes;

      if (gruposEntidades.length >= 2) {
        if (
          entidadesCoincidentes ===
          gruposEntidades.length
        ) {
          score +=
            10 +
            gruposEntidades.length * 3.2;

          const d =
            metricasEntidades.distanciaMinima;

          if (d <= 120) {
            score += 7;
          } else if (d <= 300) {
            score += 5;
          } else if (d <= 700) {
            score += 3;
          } else if (d <= 1500) {
            score += 1.2;
          }

          score +=
            Math.min(
              3,
              Math.max(
                0,
                metricasEntidades.menciones -
                gruposEntidades.length
              ) * 0.35
            );

        } else {
          const proporcion =
            entidadesCoincidentes /
            gruposEntidades.length;

          score *=
            proporcion === 0
              ? 0.12
              : 0.30 + proporcion * 0.25;
        }
      }

      salida.push({
        chunkId,
        score,
        entidadesCoincidentes,
        entidadesTotales:
          gruposEntidades.length,
        distanciaEntidades:
          metricasEntidades.distanciaMinima,
        mencionesEntidades:
          metricasEntidades.menciones
      });
    }

    salida.sort((a, b) => b.score - a.score);
    return salida;
  }

  function solapamiento(a, b) {
    const inicio = Math.max(a.inicio, b.inicio);
    const fin = Math.min(a.fin, b.fin);

    if (fin <= inicio) return 0;

    const inter = fin - inicio;
    const menor =
      Math.min(
        a.fin - a.inicio,
        b.fin - b.inicio
      );

    return menor > 0 ? inter / menor : 0;
  }

  function detectarIntencionConsulta(
    consulta,
    gruposEntidades
  ) {
    const q = normalizar(consulta);

    if (gruposEntidades.length >= 2) {
      if (
        /\brelacion\b/.test(q) ||
        /\bvinculo\b/.test(q) ||
        /\bhistoria entre\b/.test(q) ||
        /\bcomo fue\b/.test(q)
      ) {
        return "relacion";
      }

      if (
        /\bconocio\b/.test(q) ||
        /\bconocer\b/.test(q) ||
        /\bconocieron\b/.test(q) ||
        /\bprimera vez\b/.test(q) ||
        /\bprimer encuentro\b/.test(q)
      ) {
        return "origen";
      }

      if (
        /\bcomo termino\b/.test(q) ||
        /\bcomo acabo\b/.test(q) ||
        /\bultima vez\b/.test(q) ||
        /\bse separaron\b/.test(q)
      ) {
        return "cierre";
      }
    }

    return "general";
  }

  function esNarrativo(chunk) {
    return chunk.ruta.some(item => {
      const t =
        normalizar(item.titulo);

      return (
        t === "parte i" ||
        t === "parte ii" ||
        t === "epilogo"
      );
    });
  }

  function centroChunk(chunk) {
    return (chunk.inicio + chunk.fin) / 2;
  }

  function seleccionarRelacion(
    puntuados,
    limite
  ) {
    if (!puntuados.length) return [];

    const mejorScore =
      puntuados[0].score || 1;

    const fuertes =
      puntuados.filter(item => {
        const chunk =
          estado.chunks[item.chunkId];

        return (
          esNarrativo(chunk) &&
          item.entidadesTotales >= 2 &&
          item.entidadesCoincidentes ===
            item.entidadesTotales &&
          item.distanciaEntidades <= 500 &&
          item.score >= mejorScore * 0.70
        );
      });

    if (fuertes.length < 3) {
      return seleccionarDiversos(
        puntuados,
        limite
      );
    }

    const porPosicion =
      [...fuertes].sort(
        (a, b) =>
          centroChunk(
            estado.chunks[a.chunkId]
          ) -
          centroChunk(
            estado.chunks[b.chunkId]
          )
      );

    const temprano =
      porPosicion[0];

    const tardio =
      porPosicion[porPosicion.length - 1];

    const centroTemprano =
      centroChunk(
        estado.chunks[temprano.chunkId]
      );

    const centroTardio =
      centroChunk(
        estado.chunks[tardio.chunkId]
      );

    const margen =
      Math.max(
        18000,
        (centroTardio - centroTemprano) * 0.10
      );

    const intermedios =
      fuertes
        .filter(item => {
          if (
            item.chunkId === temprano.chunkId ||
            item.chunkId === tardio.chunkId
          ) {
            return false;
          }

          const c =
            centroChunk(
              estado.chunks[item.chunkId]
            );

          return (
            c > centroTemprano + margen &&
            c < centroTardio - margen
          );
        })
        .sort((a, b) => b.score - a.score);

    const elegidos = [temprano];

    if (intermedios[0]) {
      elegidos.push(intermedios[0]);
    }

    elegidos.push(tardio);

    if (elegidos.length < limite) {
      const usados =
        new Set(
          elegidos.map(x => x.chunkId)
        );

      const extra =
        seleccionarDiversos(
          puntuados.filter(
            x => !usados.has(x.chunkId)
          ),
          limite - elegidos.length
        );

      elegidos.push(...extra);
    }

    return elegidos
      .slice(0, limite)
      .sort(
        (a, b) =>
          centroChunk(
            estado.chunks[a.chunkId]
          ) -
          centroChunk(
            estado.chunks[b.chunkId]
          )
      );
  }

  function seleccionarOrigen(
    puntuados,
    limite
  ) {
    const completosNarrativos =
      puntuados
        .filter(item => {
          const chunk =
            estado.chunks[item.chunkId];

          return (
            esNarrativo(chunk) &&
            (
              item.entidadesTotales < 2 ||
              item.entidadesCoincidentes ===
                item.entidadesTotales
            )
          );
        })
        .sort(
          (a, b) =>
            centroChunk(
              estado.chunks[a.chunkId]
            ) -
            centroChunk(
              estado.chunks[b.chunkId]
            )
        );

    const primero =
      completosNarrativos[0];

    if (!primero) {
      return seleccionarDiversos(
        puntuados,
        limite
      );
    }

    const resto =
      seleccionarDiversos(
        puntuados.filter(
          x => x.chunkId !== primero.chunkId
        ),
        Math.max(0, limite - 1)
      );

    return [primero, ...resto]
      .slice(0, limite);
  }

  function seleccionarCierre(
    puntuados,
    limite
  ) {
    const completosNarrativos =
      puntuados
        .filter(item => {
          const chunk =
            estado.chunks[item.chunkId];

          return (
            esNarrativo(chunk) &&
            (
              item.entidadesTotales < 2 ||
              item.entidadesCoincidentes ===
                item.entidadesTotales
            )
          );
        })
        .sort(
          (a, b) =>
            centroChunk(
              estado.chunks[b.chunkId]
            ) -
            centroChunk(
              estado.chunks[a.chunkId]
            )
        );

    const ultimo =
      completosNarrativos[0];

    if (!ultimo) {
      return seleccionarDiversos(
        puntuados,
        limite
      );
    }

    const resto =
      seleccionarDiversos(
        puntuados.filter(
          x => x.chunkId !== ultimo.chunkId
        ),
        Math.max(0, limite - 1)
      );

    return [ultimo, ...resto]
      .slice(0, limite);
  }

  function seleccionarDiversos(
    puntuados,
    limite
  ) {
    const elegidos = [];
    const candidatos =
      puntuados.slice(0, 120);

    while (
      elegidos.length < limite &&
      candidatos.length
    ) {
      let mejorIndice = -1;
      let mejorValor = -Infinity;

      for (let i = 0; i < candidatos.length; i += 1) {
        const item = candidatos[i];
        const chunk =
          estado.chunks[item.chunkId];

        let invalido = false;
        let bonusDiversidad = 0;

        for (const e of elegidos) {
          const otro =
            estado.chunks[e.chunkId];

          if (
            solapamiento(chunk, otro) > 0.55
          ) {
            invalido = true;
            break;
          }

          const centroA =
            (chunk.inicio + chunk.fin) / 2;

          const centroB =
            (otro.inicio + otro.fin) / 2;

          const distancia =
            Math.abs(centroA - centroB);

          if (distancia < 9000) {
            invalido = true;
            break;
          }

          bonusDiversidad +=
            Math.min(
              1.8,
              Math.log1p(distancia / 30000) * 0.7
            );

          if (
            chunk.tituloRuta ===
            otro.tituloRuta
          ) {
            bonusDiversidad -= 0.9;
          }
        }

        if (invalido) continue;

        const valor =
          item.score + bonusDiversidad;

        if (valor > mejorValor) {
          mejorValor = valor;
          mejorIndice = i;
        }
      }

      if (mejorIndice === -1) break;

      elegidos.push(
        candidatos.splice(mejorIndice, 1)[0]
      );
    }

    return elegidos;
  }

  function ajustarInicioParrafo(pos) {
    const desde =
      Math.max(0, pos - 450);

    const trozo =
      estado.texto.slice(desde, pos);

    const corte =
      trozo.lastIndexOf("\n\n");

    return corte === -1
      ? pos
      : desde + corte + 2;
  }

  function ajustarFinParrafo(pos) {
    const hasta =
      Math.min(
        estado.texto.length,
        pos + 450
      );

    const trozo =
      estado.texto.slice(pos, hasta);

    const corte =
      trozo.indexOf("\n\n");

    return corte === -1
      ? pos
      : pos + corte;
  }

  function recortarAlrededor(
    inicio,
    fin,
    foco,
    maxCaracteres
  ) {
    if (fin - inicio <= maxCaracteres) {
      return { inicio, fin };
    }

    const antes =
      Math.floor(maxCaracteres * 0.42);

    const despues =
      maxCaracteres - antes;

    let nuevoInicio =
      Math.max(inicio, foco - antes);

    let nuevoFin =
      Math.min(fin, foco + despues);

    nuevoInicio =
      ajustarInicioParrafo(nuevoInicio);

    nuevoFin =
      ajustarFinParrafo(nuevoFin);

    if (
      nuevoFin <= nuevoInicio ||
      nuevoFin - nuevoInicio >
      maxCaracteres + 350
    ) {
      nuevoInicio =
        Math.max(inicio, foco - antes);

      nuevoFin =
        Math.min(
          fin,
          nuevoInicio + maxCaracteres
        );
    }

    return {
      inicio: nuevoInicio,
      fin: nuevoFin
    };
  }

  function focoPorFraseConsulta(
    chunk,
    consulta
  ) {
    const tokens =
      normalizar(consulta)
        .split(" ")
        .filter(Boolean);

    const texto =
      normalizar(chunk.texto);

    for (let n = 4; n >= 2; n -= 1) {
      for (let i = 0; i <= tokens.length - n; i += 1) {
        const frase =
          tokens.slice(i, i + n).join(" ");

        if (frase.length < 7) continue;

        const pos =
          texto.indexOf(frase);

        if (pos !== -1) {
          return (
            pos +
            Math.floor(frase.length / 2)
          );
        }
      }
    }

    return null;
  }

  function contextoContinuo(
    chunk,
    consulta,
    gruposEntidades
  ) {
    let focoRel =
      focoPorFraseConsulta(
        chunk,
        consulta
      );

    if (focoRel === null) {
      focoRel =
        focoPorEntidades(
          chunk,
          gruposEntidades
        );
    }

    if (focoRel === null) {
      focoRel =
        focoPorConsulta(
          chunk,
          consulta
        );
    }

    const focoAbs =
      chunk.inicio + focoRel;

    const margen =
      Math.floor(
        CONFIG.contextoResultado * 0.8
      );

    let inicioBruto =
      Math.max(
        0,
        focoAbs - margen
      );

    let finBruto =
      Math.min(
        estado.texto.length,
        focoAbs + margen
      );

    inicioBruto =
      ajustarInicioParrafo(inicioBruto);

    finBruto =
      ajustarFinParrafo(finBruto);

    const recortado =
      recortarAlrededor(
        inicioBruto,
        finBruto,
        focoAbs,
        CONFIG.contextoResultado
      );

    return {
      inicio: recortado.inicio,
      fin: recortado.fin,
      lineaInicio:
        lineaDesdePosicion(recortado.inicio),
      lineaFin:
        lineaDesdePosicion(recortado.fin),
      texto:
        estado.texto
          .slice(
            recortado.inicio,
            recortado.fin
          )
          .trim()
    };
  }

  function buscar(
    consulta,
    opciones = {}
  ) {
    asegurarListo();

    const q =
      String(consulta || "").trim();

    if (!q) {
      return {
        consulta: q,
        resultados: []
      };
    }

    const limiteSolicitado =
      Number(opciones.limite) ||
      CONFIG.maxResultados;

    const limite =
      Math.max(
        1,
        Math.min(
          limiteSolicitado,
          CONFIG.maxResultados,
          6
        )
      );

    const pistas =
      Array.isArray(opciones.pistas)
        ? opciones.pistas
        : [];

    const gruposEntidades =
      gruposEntidadConsulta(q);

    const puntuados =
      puntuar(
        q,
        pistas,
        gruposEntidades
      );

    let pool = puntuados;

    if (gruposEntidades.length >= 2) {
      const completos =
        puntuados.filter(
          item =>
            item.entidadesCoincidentes ===
            gruposEntidades.length
        );

      if (completos.length >= limite) {
        pool = completos;
      } else if (completos.length > 0) {
        const ids =
          new Set(
            completos.map(x => x.chunkId)
          );

        pool = [
          ...completos,
          ...puntuados.filter(
            x => !ids.has(x.chunkId)
          )
        ];
      }
    }

    const intencion =
      detectarIntencionConsulta(
        q,
        gruposEntidades
      );

    let diversos;

    if (intencion === "relacion") {
      diversos =
        seleccionarRelacion(
          pool,
          limite
        );
    } else if (intencion === "origen") {
      diversos =
        seleccionarOrigen(
          pool,
          limite
        );
    } else if (intencion === "cierre") {
      diversos =
        seleccionarCierre(
          pool,
          limite
        );
    } else {
      diversos =
        seleccionarDiversos(
          pool,
          limite
        );
    }

    const resultados =
      diversos.map((item, indice) => {
        const chunk =
          estado.chunks[item.chunkId];

        const contexto =
          contextoContinuo(
            chunk,
            q,
            gruposEntidades
          );

        return {
          orden: indice + 1,
          puntuacion:
            Math.round(
              item.score * 1000
            ) / 1000,
          entidadesCoincidentes:
            item.entidadesCoincidentes,
          entidadesTotales:
            item.entidadesTotales,
          ruta:
            chunk.ruta.map(
              x => x.titulo
            ),
          encabezado:
            chunk.tituloRuta ||
            "ACHERON",
          lineaFragmentoInicio:
            chunk.lineaInicio,
          lineaFragmentoFin:
            chunk.lineaFin,
          lineaContextoInicio:
            contexto.lineaInicio,
          lineaContextoFin:
            contexto.lineaFin,
          posicionInicio:
            contexto.inicio,
          posicionFin:
            contexto.fin,
          texto:
            contexto.texto
        };
      });

    return {
      consulta: q,
      pistas,
      intencion,
      entidadesDetectadas:
        gruposEntidades.map(
          grupo => ({
            etiqueta: grupo.etiqueta,
            variantes:
              [...grupo.variantes]
          })
        ),
      totalCandidatos:
        puntuados.length,
      resultados
    };
  }

  function recortarTextoParaPresupuesto(
    texto,
    limite
  ) {
    const t = String(texto || "");

    if (t.length <= limite) {
      return t;
    }

    const corte =
      t.lastIndexOf(
        "\n\n",
        Math.max(0, limite - 120)
      );

    const fin =
      corte > limite * 0.55
        ? corte
        : limite;

    return (
      t.slice(0, fin).trimEnd() +
      "\n[pasaje recortado por límite de contexto]"
    );
  }

  function formatearParaIA(
    busqueda,
    maxCaracteres = CONFIG.maxContextoIA
  ) {
    if (
      !busqueda ||
      !Array.isArray(busqueda.resultados) ||
      busqueda.resultados.length === 0
    ) {
      return "";
    }

    const cabecera =
`FUENTE CANÓNICA: ACHERON — LIBRO INTEGRAL
Los pasajes siguientes proceden del libro completo y conservan su contexto narrativo.
Úsalos como fuente. No inventes hechos que no estén respaldados por estos pasajes.

CONSULTA DE RECUPERACIÓN:
${busqueda.consulta}
`;

    const resultados =
      busqueda.resultados;

    const reservaMeta =
      resultados.length * 150;

    const disponible =
      Math.max(
        1200,
        maxCaracteres -
        cabecera.length -
        reservaMeta
      );

    const porPasaje =
      Math.max(
        1200,
        Math.floor(
          disponible /
          resultados.length
        )
      );

    const bloques =
      resultados.map(r => {
        const texto =
          recortarTextoParaPresupuesto(
            r.texto,
            porPasaje
          );

        return (
`
--- PASAJE ${r.orden} ---
Ubicación: ${r.encabezado}
Líneas aproximadas: ${r.lineaContextoInicio}-${r.lineaContextoFin}

${texto}
`
        );
      });

    return (
      cabecera +
      bloques.join("")
    )
      .slice(0, maxCaracteres)
      .trim();
  }


  function agregarCandidatoUnico(
    mapa,
    item
  ) {
    if (
      item &&
      !mapa.has(item.chunkId)
    ) {
      mapa.set(item.chunkId, item);
    }
  }

  function muestrearPorPosicion(
    items,
    cantidad
  ) {
    if (!items.length || cantidad <= 0) {
      return [];
    }

    if (items.length <= cantidad) {
      return [...items];
    }

    const ordenados =
      [...items].sort(
        (a, b) =>
          centroChunk(
            estado.chunks[a.chunkId]
          ) -
          centroChunk(
            estado.chunks[b.chunkId]
          )
      );

    const salida = [];

    for (let i = 0; i < cantidad; i += 1) {
      const proporcion =
        cantidad === 1
          ? 0.5
          : i / (cantidad - 1);

      const indice =
        Math.round(
          proporcion *
          (ordenados.length - 1)
        );

      salida.push(ordenados[indice]);
    }

    return salida;
  }

  function prepararCandidatosSemanticos(
    consulta,
    opciones = {}
  ) {
    asegurarListo();

    const q =
      String(consulta || "").trim();

    const grupos =
      gruposEntidadConsulta(q);

    const puntuados =
      puntuar(q, [], grupos);

    const maxCandidatos =
      Math.max(
        10,
        Math.min(
          Number(opciones.maxCandidatos) ||
          CONFIG.maxCandidatosSemanticos,
          32
        )
      );

    const mapa = new Map();

    const intencion =
      detectarIntencionConsulta(
        q,
        grupos
      );

    let completos = [];

    if (grupos.length >= 2) {
      completos =
        puntuados.filter(item => {
          const chunk =
            estado.chunks[item.chunkId];

          return (
            esNarrativo(chunk) &&
            item.entidadesCoincidentes ===
              grupos.length
          );
        });

      if (
        intencion === "origen" &&
        completos.length
      ) {
        [...completos]
          .sort(
            (a, b) =>
              centroChunk(
                estado.chunks[a.chunkId]
              ) -
              centroChunk(
                estado.chunks[b.chunkId]
              )
          )
          .slice(0, 6)
          .forEach(item =>
            agregarCandidatoUnico(
              mapa,
              item
            )
          );
      }

      if (
        intencion === "cierre" &&
        completos.length
      ) {
        [...completos]
          .sort(
            (a, b) =>
              centroChunk(
                estado.chunks[b.chunkId]
              ) -
              centroChunk(
                estado.chunks[a.chunkId]
              )
          )
          .slice(0, 6)
          .forEach(item =>
            agregarCandidatoUnico(
              mapa,
              item
            )
          );
      }

      if (
        intencion === "relacion" &&
        completos.length
      ) {
        const fuertes =
          completos.filter(
            item =>
              item.score >=
              (completos[0]?.score || 1) *
              0.58
          );

        const baseRelacion =
          fuertes.length
            ? fuertes
            : completos;

        const porPosicion =
          [...baseRelacion].sort(
            (a, b) =>
              centroChunk(
                estado.chunks[a.chunkId]
              ) -
              centroChunk(
                estado.chunks[b.chunkId]
              )
          );

        porPosicion
          .slice(0, 4)
          .forEach(item =>
            agregarCandidatoUnico(
              mapa,
              item
            )
          );

        porPosicion
          .slice(-5)
          .forEach(item =>
            agregarCandidatoUnico(
              mapa,
              item
            )
          );

        const parteII =
          porPosicion.filter(item => {
            const chunk =
              estado.chunks[item.chunkId];

            return chunk.ruta.some(
              r =>
                normalizar(r.titulo) ===
                "parte ii"
            );
          });

        parteII
          .slice(-5)
          .forEach(item =>
            agregarCandidatoUnico(
              mapa,
              item
            )
          );

        muestrearPorPosicion(
          baseRelacion,
          6
        ).forEach(item =>
          agregarCandidatoUnico(
            mapa,
            item
          )
        );
      }
    }

    puntuados
      .slice(0, 18)
      .forEach(item =>
        agregarCandidatoUnico(
          mapa,
          item
        )
      );

    if (grupos.length >= 2) {
      completos
        .slice(0, 10)
        .forEach(item =>
          agregarCandidatoUnico(
            mapa,
            item
          )
        );

      muestrearPorPosicion(
        completos,
        8
      ).forEach(item =>
        agregarCandidatoUnico(
          mapa,
          item
        )
      );
    }

    const elegidos =
      [...mapa.values()]
        .slice(0, maxCandidatos);

    return {
      consulta: q,
      intencion,
      gruposEntidades: grupos,
      puntuados,
      candidatos:
        elegidos.map((item, indice) => {
          const chunk =
            estado.chunks[item.chunkId];

          const contexto =
            contextoContinuo(
              chunk,
              q,
              grupos
            );

          let extracto =
            contexto.texto;

          if (
            extracto.length >
            CONFIG.caracteresExtractoCandidato
          ) {
            const focoRel =
              focoPorFraseConsulta(
                chunk,
                q
              ) ??
              focoPorEntidades(
                chunk,
                grupos
              ) ??
              focoPorConsulta(
                chunk,
                q
              );

            const focoAbsContexto =
              Math.max(
                0,
                Math.min(
                  extracto.length,
                  (
                    chunk.inicio +
                    focoRel
                  ) -
                  contexto.inicio
                )
              );

            const antes =
              Math.floor(
                CONFIG.caracteresExtractoCandidato *
                0.42
              );

            let inicio =
              Math.max(
                0,
                focoAbsContexto - antes
              );

            let fin =
              Math.min(
                extracto.length,
                inicio +
                CONFIG.caracteresExtractoCandidato
              );

            if (
              fin - inicio <
              CONFIG.caracteresExtractoCandidato &&
              fin === extracto.length
            ) {
              inicio =
                Math.max(
                  0,
                  fin -
                  CONFIG.caracteresExtractoCandidato
                );
            }

            extracto =
              extracto
                .slice(inicio, fin)
                .trim();
          }

          return {
            id: indice + 1,
            chunkId: item.chunkId,
            puntuacionLocal:
              Math.round(
                item.score * 1000
              ) / 1000,
            encabezado:
              chunk.tituloRuta ||
              "ACHERON",
            lineaInicio:
              contexto.lineaInicio,
            lineaFin:
              contexto.lineaFin,
            extracto
          };
        })
    };
  }

  function promptSelectorSemantico(
    consulta,
    candidatos,
    limite,
    intencion = "general"
  ) {
    const bloques =
      candidatos.map(c =>
`[ID ${c.id}]
Ubicación: ${c.encabezado}
Líneas: ${c.lineaInicio}-${c.lineaFin}
Extracto:
${c.extracto}`
      ).join("\n\n");

    const esRelacion =
      intencion === "relacion";

    const maxElegibles =
      esRelacion
        ? Math.min(
            candidatos.length,
            Math.max(
              limite * 2,
              CONFIG.maxSeleccionSemanticaRelacion
            )
          )
        : limite;

    const criterioRelacion =
      esRelacion
        ? `
- Esta consulta pide una trayectoria o relación amplia.
- Ordena los IDs por utilidad real para responderla.
- Siempre que existan alternativas buenas, incluye momentos de etapas distintas del libro (fechas, capítulos o posiciones narrativas distintas).
- Evita gastar varias plazas en escenas contiguas del mismo momento si otra etapa aporta información relevante.
- Puedes devolver hasta ${maxElegibles} IDs para que una segunda capa elimine redundancias.`
        : "";

    return {
      maxElegibles,
      system:
`Eres un selector interno de pasajes de un libro.
NO respondas la pregunta del usuario.
NO inventes hechos y NO uses conocimiento externo.
Tu única tarea es elegir, entre los candidatos proporcionados, los pasajes que mejor permitan responder la consulta.

Criterios:
- Prioriza apoyo directo a la consulta, no mera coincidencia de nombres.
- Evita pasajes redundantes.
- Si pregunta por un acontecimiento concreto, prioriza el pasaje donde realmente ocurre.${criterioRelacion}
- Puedes elegir entre 1 y ${maxElegibles} IDs.
- Devuelve los IDs en orden de utilidad, del mejor al menos importante.
- Devuelve únicamente JSON válido, sin markdown ni explicaciones.

Formato exacto:
{"seleccion":[1,2,3]}`,
      user:
`CONSULTA:
${consulta}

CANDIDATOS:
${bloques}`
    };
  }

  function parsearSeleccionSemantica(
    texto,
    candidatos,
    limite
  ) {
    const limpio =
      String(texto || "")
        .trim()
        .replace(
          /^```(?:json)?\s*/i,
          ""
        )
        .replace(
          /\s*```$/i,
          ""
        );

    const datos =
      JSON.parse(limpio);

    const idsValidos =
      new Set(
        candidatos.map(c => c.id)
      );

    const seleccion = [];

    for (
      const id of
      Array.isArray(datos.seleccion)
        ? datos.seleccion
        : []
    ) {
      const n = Number(id);

      if (
        Number.isInteger(n) &&
        idsValidos.has(n) &&
        !seleccion.includes(n)
      ) {
        seleccion.push(n);
      }

      if (seleccion.length >= limite) {
        break;
      }
    }

    return seleccion;
  }

  function distanciaEntreItems(a, b) {
    const ca =
      estado.chunks[a.chunkId];

    const cb =
      estado.chunks[b.chunkId];

    return Math.abs(
      centroChunk(ca) -
      centroChunk(cb)
    );
  }

  function aplicarDiversidadNarrativa(
    preparacion,
    itemsSemanticos,
    limite
  ) {
    if (
      preparacion.intencion !== "relacion" ||
      limite <= 1
    ) {
      return itemsSemanticos.slice(0, limite);
    }

    const elegidos = [];

    function intentarAgregar(item) {
      if (!item) return false;

      if (
        elegidos.some(
          e => e.chunkId === item.chunkId
        )
      ) {
        return false;
      }

      const demasiadoCerca =
        elegidos.some(
          e =>
            distanciaEntreItems(e, item) <
            CONFIG.distanciaMinRelacion
        );

      if (demasiadoCerca) {
        return false;
      }

      elegidos.push(item);
      return true;
    }

    /* Primero respetamos el orden semántico, pero quitando
       escenas demasiado próximas entre sí. */
    for (const item of itemsSemanticos) {
      intentarAgregar(item);

      if (elegidos.length >= limite) {
        return elegidos;
      }
    }

    /* Si el selector eligió varias escenas del mismo tramo,
       rellenamos con la selección local de trayectoria,
       que busca zonas temprana/intermedia/tardía. */
    const trayectoria =
      seleccionarRelacion(
        preparacion.puntuados,
        Math.max(limite, 3)
      );

    for (const item of trayectoria) {
      intentarAgregar(item);

      if (elegidos.length >= limite) {
        return elegidos;
      }
    }

    /* Último respaldo: candidatos semánticos/locales diversos. */
    const usados =
      new Set(
        elegidos.map(x => x.chunkId)
      );

    const extras =
      seleccionarDiversos(
        preparacion.puntuados.filter(
          x => !usados.has(x.chunkId)
        ),
        limite * 2
      );

    for (const item of extras) {
      intentarAgregar(item);

      if (elegidos.length >= limite) {
        break;
      }
    }

    return elegidos.slice(0, limite);
  }

  function construirResultadoDesdeSeleccion(
    preparacion,
    ids,
    limite
  ) {
    const mapa =
      new Map(
        preparacion.candidatos.map(
          c => [c.id, c]
        )
      );

    const itemsSemanticos = [];

    for (const id of ids) {
      const c = mapa.get(id);
      if (!c) continue;

      const item =
        preparacion.puntuados.find(
          x => x.chunkId === c.chunkId
        );

      if (
        item &&
        !itemsSemanticos.some(
          x => x.chunkId === item.chunkId
        )
      ) {
        itemsSemanticos.push(item);
      }
    }

    let elegidos =
      aplicarDiversidadNarrativa(
        preparacion,
        itemsSemanticos,
        limite
      );

    if (
      preparacion.intencion !== "relacion" &&
      elegidos.length < limite
    ) {
      const usados =
        new Set(
          elegidos.map(x => x.chunkId)
        );

      const extras =
        seleccionarDiversos(
          preparacion.puntuados.filter(
            x => !usados.has(x.chunkId)
          ),
          limite - elegidos.length
        );

      elegidos.push(...extras);
    }

    const resultados =
      elegidos
        .slice(0, limite)
        .map((item, indice) => {
          const chunk =
            estado.chunks[item.chunkId];

          const contexto =
            contextoContinuo(
              chunk,
              preparacion.consulta,
              preparacion.gruposEntidades
            );

          return {
            orden: indice + 1,
            puntuacion:
              Math.round(
                item.score * 1000
              ) / 1000,
            encabezado:
              chunk.tituloRuta ||
              "ACHERON",
            lineaContextoInicio:
              contexto.lineaInicio,
            lineaContextoFin:
              contexto.lineaFin,
            posicionInicio:
              contexto.inicio,
            posicionFin:
              contexto.fin,
            texto:
              contexto.texto
          };
        });

    return {
      consulta:
        preparacion.consulta,
      modo:
        "semantico",
      intencion:
        preparacion.intencion,
      diversidadNarrativa:
        preparacion.intencion === "relacion",
      resultados
    };
  }

  async function buscarSemanticoAsync(
    consulta,
    opciones = {}
  ) {
    await inicializar();

    const limite =
      Math.max(
        1,
        Math.min(
          Number(opciones.limite) ||
          CONFIG.maxResultados,
          CONFIG.maxResultados
        )
      );

    const preparacion =
      prepararCandidatosSemanticos(
        consulta,
        opciones
      );

    if (!preparacion.candidatos.length) {
      return {
        consulta:
          String(consulta || "").trim(),
        modo:
          "semantico",
        resultados: []
      };
    }

    const prompt =
      promptSelectorSemantico(
        preparacion.consulta,
        preparacion.candidatos,
        limite,
        preparacion.intencion
      );

    try {
      const respuesta =
        await fetch(
          opciones.url ||
          CONFIG.workerUrl,
          {
            method: "POST",
            headers: {
              "Content-Type":
                "application/json"
            },
            body: JSON.stringify({
              messages: [
                {
                  role: "system",
                  content: prompt.system
                },
                {
                  role: "user",
                  content: prompt.user
                }
              ]
            })
          }
        );

      if (!respuesta.ok) {
        throw new Error(
          "Error " +
          respuesta.status +
          " del selector semántico."
        );
      }

      const texto =
        await respuesta.text();

      const ids =
        parsearSeleccionSemantica(
          texto,
          preparacion.candidatos,
          prompt.maxElegibles
        );

      if (!ids.length) {
        throw new Error(
          "El selector no devolvió IDs válidos."
        );
      }

      const resultado =
        construirResultadoDesdeSeleccion(
          preparacion,
          ids,
          limite
        );

      resultado.seleccionSemantica =
        ids;

      return resultado;

    } catch (error) {
      console.error(
        "Fallo del selector semántico; " +
        "se usa recuperación local:",
        error
      );

      const local =
        buscar(
          consulta,
          { limite }
        );

      local.modo =
        "local_fallback";

      local.errorSemantico =
        error.message;

      return local;
    }
  }

  async function buscarAsync(
    consulta,
    opciones = {}
  ) {
    await inicializar();
    return buscar(consulta, opciones);
  }

  const api = Object.freeze({
    inicializar,
    estaListo: () => estado.listo,
    obtenerResumen,
    buscar,
    buscarAsync,
    buscarSemanticoAsync,
    prepararCandidatosSemanticos,
    formatearParaIA
  });

  raizGlobal().BuscadorAcheron = api;
})();
