/* =========================
<   VARIABLES
========================= */

const imagenPortada = document.getElementById("imagenPortada");
const cambiarPortada = document.getElementById("cambiarPortada");
const selectorPortada = document.getElementById("selectorPortada");

const cambiarFondo = document.getElementById("cambiarFondo");
const selectorFondo = document.getElementById("selectorFondo");

const avatarSoteria = document.getElementById("avatarSoteria");
const selectorAvatarSoteria =
  document.getElementById("selectorAvatarSoteria");

const avatarAcheron = document.getElementById("avatarAcheron");
const selectorAvatarAcheron =
  document.getElementById("selectorAvatarAcheron");

const formulario = document.getElementById("formulario");
const mensaje = document.getElementById("mensaje");
const mensajes = document.getElementById("mensajes");

const menuBtn = document.getElementById("menuBtn");
const menu = document.getElementById("menu");
const nuevaHistoria = document.getElementById("nuevaHistoria");

const nuevaConversacion =
  document.getElementById("nuevaConversacion");

const verConversaciones =
  document.getElementById("verConversaciones");
  const panelConversaciones =
  document.getElementById("panelConversaciones");

const cerrarConversaciones =
  document.getElementById("cerrarConversaciones");

const listaConversaciones =
  document.getElementById("listaConversaciones");
const ajustes =
  document.getElementById("ajustes");

const panelAjustes =
  document.getElementById("panelAjustes");

const cerrarAjustes =
  document.getElementById("cerrarAjustes");


/* =========================
   RECUERDOS
========================= */

const abrirRecuerdos =
  document.getElementById("abrirRecuerdos");

const panelRecuerdos =
  document.getElementById("panelRecuerdos");

const cerrarRecuerdos =
  document.getElementById("cerrarRecuerdos");

const volverAjustes =
  document.getElementById("volverAjustes");

const nuevoRecuerdo =
  document.getElementById("nuevoRecuerdo");

const guardarRecuerdo =
  document.getElementById("guardarRecuerdo");

const listaRecuerdos =
  document.getElementById("listaRecuerdos");


/* =========================
   PERSONAJES
========================= */

const abrirPersonajes =
  document.getElementById("abrirPersonajes");

const panelPersonajes =
  document.getElementById("panelPersonajes");

const cerrarPersonajes =
  document.getElementById("cerrarPersonajes");

const volverAjustesPersonajes =
  document.getElementById("volverAjustesPersonajes");

const nombrePersonaje =
  document.getElementById("nombrePersonaje");

const nuevaFichaPersonaje =
  document.getElementById("nuevaFichaPersonaje");

const guardarPersonaje =
  document.getElementById("guardarPersonaje");

const listaPersonajes =
  document.getElementById("listaPersonajes");


/* =========================
   REFUERZO DE EMERGENCIA
========================= */

const abrirEmergencia =
  document.getElementById("abrirEmergencia");

const panelEmergencia =
  document.getElementById("panelEmergencia");

const cerrarEmergencia =
  document.getElementById("cerrarEmergencia");

const volverAjustesEmergencia =
  document.getElementById(
    "volverAjustesEmergencia"
  );

const promptEmergencia =
  document.getElementById("promptEmergencia");

const estadoEmergencia =
  document.getElementById("estadoEmergencia");

const guardarEmergencia =
  document.getElementById("guardarEmergencia");

const alternarEmergencia =
  document.getElementById("alternarEmergencia");

const borrarEmergencia =
  document.getElementById("borrarEmergencia");
const CLAVE_PORTADA = "soteria_portada";
const CLAVE_FONDO = "soteria_fondo_chat";
const CLAVE_AVATAR_SOTERIA = "avatar_soteria";
const CLAVE_AVATAR_ACHERON = "avatar_acheron";

/* =========================
   HISTORIAL DEL CHAT
========================= */

const DB_NOMBRE = "soteria_chat_db";
const DB_VERSION = 5;

const ALMACEN_MENSAJES = "mensajes";
const ALMACEN_MEMORIA = "memoria";
const ALMACEN_PERSONAJES = "personajes";
const ALMACEN_CONVERSACIONES = "conversaciones";

const CLAVE_CONVERSACION_ACTIVA =
  "soteria_conversacion_activa";

let conversacionActivaId =
  localStorage.getItem(
    CLAVE_CONVERSACION_ACTIVA
  );

function abrirBaseDeDatos() {
  return new Promise((resolve, reject) => {
    const solicitud = indexedDB.open(
      DB_NOMBRE,
      DB_VERSION
    );

    solicitud.onupgradeneeded = () => {
      const db = solicitud.result;

      if (
        !db.objectStoreNames.contains(
          ALMACEN_MENSAJES
        )
      ) {
        db.createObjectStore(
          ALMACEN_MENSAJES,
          {
            keyPath: "id",
            autoIncrement: true
          }
        );
      }

      if (
        !db.objectStoreNames.contains(
          ALMACEN_MEMORIA
        )
      ) {
        db.createObjectStore(
          ALMACEN_MEMORIA,
          {
            keyPath: "id",
            autoIncrement: true
          }
        );
      }

      if (
        !db.objectStoreNames.contains(
          ALMACEN_PERSONAJES
        )
      ) {
        db.createObjectStore(
          ALMACEN_PERSONAJES,
          {
            keyPath: "id",
            autoIncrement: true
          }
        );
      }
      if (
  !db.objectStoreNames.contains(
    ALMACEN_CONVERSACIONES
  )
) {
  db.createObjectStore(
    ALMACEN_CONVERSACIONES,
    {
      keyPath: "id"
    }
  );
}
    };

    solicitud.onsuccess = () => {
      resolve(solicitud.result);
    };

    solicitud.onerror = () => {
      reject(solicitud.error);
    };
  });
}

async function guardarEntradaChat(entrada) {
  await asegurarConversacionActiva();

  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MENSAJES,
      "readwrite"
    );

    const entradaConConversacion = {
      ...entrada,
      conversacionId: conversacionActivaId
    };

    const solicitud = transaccion
      .objectStore(ALMACEN_MENSAJES)
      .add(entradaConConversacion);

    let idCreado = null;

    solicitud.onsuccess = () => {
      idCreado = solicitud.result;
    };

    transaccion.oncomplete = () => {
      db.close();
      resolve(idCreado);
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}

async function cargarEntradasChat() {
  await asegurarConversacionActiva();

  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MENSAJES,
      "readwrite"
    );

    const almacen =
      transaccion.objectStore(
        ALMACEN_MENSAJES
      );

    const solicitud =
      almacen.getAll();

    let entradasConversacion = [];

    solicitud.onsuccess = () => {
      const todas =
        solicitud.result || [];

      /*
         ADOPTAR EL HISTORIAL ANTIGUO

         Los mensajes creados antes del sistema
         de conversaciones no tienen conversacionId.
         Los asociamos a la conversación inicial
         para no perderlos.
      */

      todas.forEach((entrada) => {
        if (!entrada.conversacionId) {
          entrada.conversacionId =
            conversacionActivaId;

          almacen.put(entrada);
        }
      });

      entradasConversacion =
        todas.filter((entrada) => {
          return (
            entrada.conversacionId ===
            conversacionActivaId
          );
        });
    };

    transaccion.oncomplete = () => {
      db.close();
      resolve(entradasConversacion);
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}

async function borrarHistorialChat() {
  await asegurarConversacionActiva();

  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MENSAJES,
      "readwrite"
    );

    const almacen =
      transaccion.objectStore(
        ALMACEN_MENSAJES
      );

    const solicitud =
      almacen.openCursor();

    solicitud.onsuccess = (evento) => {
      const cursor =
        evento.target.result;

      if (!cursor) return;

      const entrada =
        cursor.value;

      if (
        entrada.conversacionId ===
        conversacionActivaId
      ) {
        cursor.delete();
      }

      cursor.continue();
    };

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}
async function asegurarConversacionActiva() {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_CONVERSACIONES,
      "readwrite"
    );

    const almacen = transaccion.objectStore(
      ALMACEN_CONVERSACIONES
    );

    if (!conversacionActivaId) {
      conversacionActivaId =
        "conv_" + Date.now();

      localStorage.setItem(
        CLAVE_CONVERSACION_ACTIVA,
        conversacionActivaId
      );

      almacen.add({
        id: conversacionActivaId,
        titulo: "Conversación inicial",
        creada: Date.now()
      });
    }

    transaccion.oncomplete = () => {
      db.close();
      resolve(conversacionActivaId);
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}
  async function borrarEntradaChat(id) {
  if (id === undefined || id === null) {
    return;
  }

  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MENSAJES,
      "readwrite"
    );

    const almacen =
      transaccion.objectStore(
        ALMACEN_MENSAJES
      );

    almacen.delete(id);

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
  }

/* =========================
   RECUERDOS
========================= */

async function guardarRecuerdoEnDB(texto) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MEMORIA,
      "readwrite"
    );

    transaccion
      .objectStore(ALMACEN_MEMORIA)
      .add({
        contenido: texto,
        fecha: Date.now()
      });

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


async function cargarRecuerdosDB() {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MEMORIA,
      "readonly"
    );

    const solicitud = transaccion
      .objectStore(ALMACEN_MEMORIA)
      .getAll();

    solicitud.onsuccess = () => {
      db.close();
      resolve(solicitud.result);
    };

    solicitud.onerror = () => {
      db.close();
      reject(solicitud.error);
    };
  });
}


async function borrarRecuerdoDB(id) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MEMORIA,
      "readwrite"
    );

    transaccion
      .objectStore(ALMACEN_MEMORIA)
      .delete(id);

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


async function editarRecuerdoDB(id, nuevoTexto) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_MEMORIA,
      "readwrite"
    );

    const almacen =
      transaccion.objectStore(
        ALMACEN_MEMORIA
      );

    const solicitud =
      almacen.get(id);

    solicitud.onsuccess = () => {
      const recuerdo =
        solicitud.result;

      if (!recuerdo) return;

      recuerdo.contenido =
        nuevoTexto;

      recuerdo.fechaEdicion =
        Date.now();

      almacen.put(recuerdo);
    };

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


async function mostrarRecuerdosGuardados() {
  listaRecuerdos.innerHTML = "";

  let recuerdos = [];

  try {
    recuerdos =
      await cargarRecuerdosDB();
  } catch (error) {
    console.error(
      "No se pudieron cargar los recuerdos:",
      error
    );

    return;
  }

  const carpeta =
    document.createElement("button");

  carpeta.type = "button";
  carpeta.className = "carpeta-recuerdos";

  const lista =
    document.createElement("div");

  lista.className = "contenido-carpeta-recuerdos";

  const estabaAbierta =
    listaRecuerdos.dataset.abierta === "true";

  lista.hidden = !estabaAbierta;

  carpeta.textContent =
    estabaAbierta
      ? `📂 Recuerdos guardados (${recuerdos.length}) ▲`
      : `📁 Recuerdos guardados (${recuerdos.length}) ▼`;

  carpeta.addEventListener(
    "click",
    () => {
      const abrir = lista.hidden;

      lista.hidden = !abrir;

      listaRecuerdos.dataset.abierta =
        abrir ? "true" : "false";

      carpeta.textContent =
        abrir
          ? `📂 Recuerdos guardados (${recuerdos.length}) ▲`
          : `📁 Recuerdos guardados (${recuerdos.length}) ▼`;
    }
  );

  listaRecuerdos.appendChild(carpeta);
  listaRecuerdos.appendChild(lista);

  recuerdos
    .sort((a, b) => b.fecha - a.fecha)
    .forEach((recuerdo) => {
      const tarjeta =
        document.createElement("div");

      tarjeta.className =
        "tarjeta-recuerdo";

      const texto =
        document.createElement("div");

      texto.className =
        "texto-recuerdo-guardado";

      texto.textContent =
        recuerdo.contenido;

      const acciones =
        document.createElement("div");

      acciones.className =
        "acciones-recuerdo";

      const editar =
        document.createElement("button");

      editar.type = "button";
      editar.textContent = "✏️ Editar";

      editar.addEventListener(
        "click",
        async () => {
          const nuevoTexto =
            prompt(
              "Editar recuerdo:",
              recuerdo.contenido
            );

          if (
            nuevoTexto === null ||
            !nuevoTexto.trim()
          ) {
            return;
          }

          await editarRecuerdoDB(
            recuerdo.id,
            nuevoTexto.trim()
          );

          await mostrarRecuerdosGuardados();
        }
      );

      const borrar =
        document.createElement("button");

      borrar.type = "button";
      borrar.textContent = "🗑️ Borrar";

      borrar.addEventListener(
        "click",
        async () => {
          const confirmar =
            confirm(
              "¿Quieres borrar este recuerdo?"
            );

          if (!confirmar) return;

          await borrarRecuerdoDB(
            recuerdo.id
          );

          await mostrarRecuerdosGuardados();
        }
      );

      acciones.appendChild(editar);
      acciones.appendChild(borrar);

      tarjeta.appendChild(texto);
      tarjeta.appendChild(acciones);

      lista.appendChild(tarjeta);
    });
}
/* =========================
   PERSONAJES
========================= */

let personajeEditandoId = null;


/* =========================
   GUARDAR PERSONAJE
========================= */

async function guardarPersonajeEnDB(nombre, ficha) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_PERSONAJES,
      "readwrite"
    );

    transaccion
      .objectStore(ALMACEN_PERSONAJES)
      .add({
        nombre: nombre,
        ficha: ficha,
        fecha: Date.now()
      });

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


/* =========================
   CARGAR PERSONAJES
========================= */

async function cargarPersonajesDB() {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_PERSONAJES,
      "readonly"
    );

    const solicitud = transaccion
      .objectStore(ALMACEN_PERSONAJES)
      .getAll();

    solicitud.onsuccess = () => {
      db.close();
      resolve(solicitud.result);
    };

    solicitud.onerror = () => {
      db.close();
      reject(solicitud.error);
    };
  });
}


/* =========================
   BORRAR PERSONAJE
========================= */

async function borrarPersonajeDB(id) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_PERSONAJES,
      "readwrite"
    );

    transaccion
      .objectStore(ALMACEN_PERSONAJES)
      .delete(id);

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


/* =========================
   ACTUALIZAR PERSONAJE
========================= */

async function editarPersonajeDB(
  id,
  nuevoNombre,
  nuevaFicha
) {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_PERSONAJES,
      "readwrite"
    );

    const almacen =
      transaccion.objectStore(
        ALMACEN_PERSONAJES
      );
const solicitud = almacen.get(id);
    solicitud.onsuccess = () => {
  const personaje = solicitud.result;

  if (!personaje) return;

  personaje.nombre = nuevoNombre;
  personaje.ficha = nuevaFicha;
  personaje.fechaEdicion = Date.now();

  almacen.put(personaje);
};

    transaccion.oncomplete = () => {
      db.close();
      resolve();
    };

    transaccion.onerror = () => {
      db.close();
      reject(transaccion.error);
    };
  });
}


/* =========================
   MOSTRAR PERSONAJES
========================= */

async function mostrarPersonajesGuardados() {
  listaPersonajes.innerHTML = "";

  let personajes = [];

  try {
    personajes =
      await cargarPersonajesDB();
  } catch (error) {
    console.error(
      "No se pudieron cargar los personajes:",
      error
    );

    return;
  }

  const carpeta =
    document.createElement("button");

  carpeta.type = "button";
  carpeta.className = "carpeta-personajes";

  const lista =
    document.createElement("div");

  lista.className =
    "contenido-carpeta-personajes";

  const estabaAbierta =
    listaPersonajes.dataset.abierta === "true";

  lista.hidden = !estabaAbierta;

  carpeta.textContent =
    estabaAbierta
      ? `📂 Personajes guardados (${personajes.length}) ▲`
      : `📁 Personajes guardados (${personajes.length}) ▼`;

  carpeta.addEventListener(
    "click",
    () => {
      const abrir = lista.hidden;

      lista.hidden = !abrir;

      listaPersonajes.dataset.abierta =
        abrir ? "true" : "false";

      carpeta.textContent =
        abrir
          ? `📂 Personajes guardados (${personajes.length}) ▲`
          : `📁 Personajes guardados (${personajes.length}) ▼`;
    }
  );

  listaPersonajes.appendChild(carpeta);
  listaPersonajes.appendChild(lista);

  personajes
    .sort((a, b) => {
      return a.nombre.localeCompare(
        b.nombre,
        "es"
      );
    })
    .forEach((personaje) => {
      const tarjeta =
        document.createElement("div");

      tarjeta.className =
        "tarjeta-recuerdo";


      /* NOMBRE */

      const nombre =
        document.createElement("div");

      nombre.className =
        "texto-recuerdo-guardado";

      nombre.textContent =
        personaje.nombre;


      /* FICHA */

      const ficha =
        document.createElement("div");

      ficha.className =
        "texto-recuerdo-guardado";

      ficha.textContent =
        personaje.ficha;

      ficha.style.whiteSpace = "pre-wrap";


      /* BOTONES */

      const acciones =
        document.createElement("div");

      acciones.className =
        "acciones-recuerdo";


      /* EDITAR */

      const editar =
        document.createElement("button");

      editar.type = "button";
      editar.textContent = "✏️ Editar";

      editar.addEventListener(
        "click",
        () => {
          personajeEditandoId =
            personaje.id;

          nombrePersonaje.value =
            personaje.nombre;

          nuevaFichaPersonaje.value =
            personaje.ficha;

          guardarPersonaje.textContent =
            "Guardar cambios";

          nombrePersonaje.focus();

          panelPersonajes.scrollTop = 0;
        }
      );


      /* BORRAR */

      const borrar =
        document.createElement("button");

      borrar.type = "button";
      borrar.textContent = "🗑️ Borrar";

      borrar.addEventListener(
        "click",
        async () => {
          const confirmar =
            confirm(
              `¿Quieres borrar a ${personaje.nombre}?`
            );

          if (!confirmar) return;

          await borrarPersonajeDB(
            personaje.id
          );

          if (
            personajeEditandoId ===
            personaje.id
          ) {
            personajeEditandoId = null;

            nombrePersonaje.value = "";
            nuevaFichaPersonaje.value = "";

            guardarPersonaje.textContent =
              "Guardar personaje";
          }

          await mostrarPersonajesGuardados();
        }
      );

      acciones.appendChild(editar);
      acciones.appendChild(borrar);


      /* ACORDEÓN INDIVIDUAL */

      ficha.style.display = "none";
      acciones.style.display = "none";

      nombre.style.cursor = "pointer";

      nombre.addEventListener(
        "click",
        () => {
          const cerrado =
            ficha.style.display === "none";

          ficha.style.display =
            cerrado ? "block" : "none";

          acciones.style.display =
            cerrado ? "flex" : "none";
        }
      );


      /* MONTAR TARJETA */

      tarjeta.appendChild(nombre);
      tarjeta.appendChild(ficha);
      tarjeta.appendChild(acciones);

      lista.appendChild(tarjeta);
    });
}
/* =========================
   PORTADA
========================= */

const portadaGuardada =
  localStorage.getItem(CLAVE_PORTADA);

if (portadaGuardada) {
  imagenPortada.src = portadaGuardada;
}

cambiarPortada.addEventListener("click", () => {
  selectorPortada.click();
  menu.classList.add("oculto");
});

selectorPortada.addEventListener("change", () => {
  const archivo = selectorPortada.files[0];

  if (!archivo) return;

  const lector = new FileReader();

  lector.onload = () => {
    imagenPortada.src = lector.result;

    localStorage.setItem(
      CLAVE_PORTADA,
      lector.result
    );

    selectorPortada.value = "";
  };

  lector.readAsDataURL(archivo);
});


/* =========================
   FONDO DEL CHAT
========================= */

function aplicarFondoChat(origen) {
  mensajes.style.backgroundImage =
    `linear-gradient(
      rgba(15, 17, 25, 0.35),
      rgba(15, 17, 25, 0.35)
    ), url("${origen}")`;

  mensajes.style.backgroundSize = "cover";
  mensajes.style.backgroundPosition = "center";
  mensajes.style.backgroundRepeat = "no-repeat";
}

const fondoGuardado =
  localStorage.getItem(CLAVE_FONDO);

if (fondoGuardado) {
  aplicarFondoChat(fondoGuardado);
}

cambiarFondo.addEventListener("click", () => {
  selectorFondo.click();
});

selectorFondo.addEventListener("change", () => {
  const archivo = selectorFondo.files[0];

  if (!archivo) return;

  if (!archivo.type.startsWith("image/")) {
    alert("El archivo elegido no es una imagen.");
    selectorFondo.value = "";
    return;
  }

  const lector = new FileReader();

  lector.onload = () => {
    aplicarFondoChat(lector.result);

    localStorage.setItem(
      CLAVE_FONDO,
      lector.result
    );

    selectorFondo.value = "";
  };

  lector.readAsDataURL(archivo);
});


/* =========================
   AVATAR DE SOTERIA
========================= */

avatarSoteria.addEventListener("click", () => {
  selectorAvatarSoteria.click();
  menu.classList.add("oculto");
});

selectorAvatarSoteria.addEventListener(
  "change",
  () => {
    const archivo =
      selectorAvatarSoteria.files[0];

    if (!archivo) return;

    const lector = new FileReader();

    lector.onload = async () => {
      localStorage.setItem(
        CLAVE_AVATAR_SOTERIA,
        lector.result
      );

      selectorAvatarSoteria.value = "";

      await cargarHistorialCompleto();
    };

    lector.readAsDataURL(archivo);
  }
);


/* =========================
   AVATAR DE ACHERON
========================= */

avatarAcheron.addEventListener("click", () => {
  selectorAvatarAcheron.click();
  menu.classList.add("oculto");
});

selectorAvatarAcheron.addEventListener(
  "change",
  () => {
    const archivo =
      selectorAvatarAcheron.files[0];

    if (!archivo) return;

    const lector = new FileReader();

    lector.onload = async () => {
      localStorage.setItem(
        CLAVE_AVATAR_ACHERON,
        lector.result
      );

      selectorAvatarAcheron.value = "";

      await cargarHistorialCompleto();
    };

    lector.readAsDataURL(archivo);
  }
);


/* =========================
   MENÚ
========================= */

menuBtn.addEventListener("click", () => {
  menu.classList.toggle("oculto");
});
verConversaciones.addEventListener("click", async () => {
  try {
    await mostrarConversacionesGuardadas();

    menu.classList.add("oculto");
    panelConversaciones.classList.remove("oculto");
  } catch (error) {
    console.error(
      "No se pudieron cargar las conversaciones:",
      error
    );

    alert(
      "No se han podido cargar las conversaciones."
    );
  }
});

cerrarConversaciones.addEventListener("click", () => {
  panelConversaciones.classList.add("oculto");
});
nuevaHistoria.addEventListener(
  "click",
  async () => {
    const confirmar = confirm(
      "¿Quieres limpiar todo el chat?"
    );

    if (!confirmar) return;

    try {
      await borrarHistorialChat();

      mensajes.innerHTML = "";
      menu.classList.add("oculto");
    } catch (error) {
      console.error(error);

      alert(
        "No se ha podido limpiar el chat."
      );
    }
  }
);
/* =========================
   LISTAR CONVERSACIONES
========================= */

async function mostrarConversacionesGuardadas() {
  const db = await abrirBaseDeDatos();

  return new Promise((resolve, reject) => {
    const transaccion = db.transaction(
      ALMACEN_CONVERSACIONES,
      "readonly"
    );

    const solicitud = transaccion
      .objectStore(ALMACEN_CONVERSACIONES)
      .getAll();

    solicitud.onsuccess = () => {
      const conversaciones =
        solicitud.result || [];

      listaConversaciones.innerHTML = "";

      conversaciones.sort((a, b) => {
  if (a.titulo === "Conversación principal") return -1;
  if (b.titulo === "Conversación principal") return 1;

  const numeroA =
    parseInt(a.titulo.match(/\d+/)?.[0]) || 0;

  const numeroB =
    parseInt(b.titulo.match(/\d+/)?.[0]) || 0;

  return numeroA - numeroB;
});

      conversaciones.forEach(
        (conversacion) => {

          const fila =
            document.createElement("div");

          fila.className =
            "fila-conversacion";


          /* ABRIR CONVERSACIÓN */

          const elemento =
            document.createElement("button");

          elemento.type = "button";
          elemento.className =
            "conversacion-item";

          elemento.textContent =
            conversacion.titulo ||
            "Conversación";

          elemento.addEventListener(
            "click",
            async () => {
              conversacionActivaId =
                conversacion.id;

              localStorage.setItem(
                CLAVE_CONVERSACION_ACTIVA,
                conversacionActivaId
              );

              panelConversaciones
                .classList.add("oculto");

              await cargarHistorialCompleto();
            }
          );


          /* ELIMINAR CONVERSACIÓN */

          const eliminar =
            document.createElement("button");

          eliminar.type = "button";
          eliminar.className =
            "eliminar-conversacion";

          eliminar.textContent = "🗑️";

          eliminar.addEventListener(
            "click",
            async () => {
              const confirmar = confirm(
                "¿Quieres eliminar esta conversación?"
              );

              if (!confirmar) return;

              try {
                const dbBorrar =
                  await abrirBaseDeDatos();

                await new Promise(
                  (resolveBorrar, rejectBorrar) => {
                    const transaccionBorrar =
                      dbBorrar.transaction(
                        [
                          ALMACEN_CONVERSACIONES,
                          ALMACEN_MENSAJES
                        ],
                        "readwrite"
                      );

                    transaccionBorrar
                      .objectStore(
                        ALMACEN_CONVERSACIONES
                      )
                      .delete(conversacion.id);

                    const almacenMensajes =
                      transaccionBorrar.objectStore(
                        ALMACEN_MENSAJES
                      );

                    const cursor =
                      almacenMensajes.openCursor();

                    cursor.onsuccess =
                      (evento) => {
                        const actual =
                          evento.target.result;

                        if (!actual) return;

                        if (
                          actual.value
                            .conversacionId ===
                          conversacion.id
                        ) {
                          actual.delete();
                        }

                        actual.continue();
                      };

                    transaccionBorrar.oncomplete =
                      () => {
                        dbBorrar.close();
                        resolveBorrar();
                      };

                    transaccionBorrar.onerror =
                      () => {
                        dbBorrar.close();
                        rejectBorrar(
                          transaccionBorrar.error
                        );
                      };
                  }
                );

                if (
                  conversacionActivaId ===
                  conversacion.id
                ) {
                  conversacionActivaId = null;

                  localStorage.removeItem(
                    CLAVE_CONVERSACION_ACTIVA
                  );

                  mensajes.innerHTML = "";
                }

                await mostrarConversacionesGuardadas();

              } catch (error) {
                console.error(
                  "No se pudo eliminar la conversación:",
                  error
                );

                alert(
                  "No se ha podido eliminar la conversación."
                );
              }
            }
          );


          fila.appendChild(elemento);
          fila.appendChild(eliminar);

          listaConversaciones.appendChild(
            fila
          );
        }
      );

      db.close();
      resolve();
    };

    solicitud.onerror = () => {
      db.close();
      reject(solicitud.error);
    };
  });
}
/* =========================
   NUEVA CONVERSACIÓN
========================= */


                      nuevaConversacion.addEventListener(
  "click",
  async () => {
    try {
      const db =
        await abrirBaseDeDatos();

      const numeroConversacion =
        await new Promise(
          (resolve, reject) => {
            const transaccion =
              db.transaction(
                ALMACEN_CONVERSACIONES,
                "readonly"
              );

            const solicitud =
              transaccion
                .objectStore(
                  ALMACEN_CONVERSACIONES
                )
                .getAll();

            solicitud.onsuccess = () => {
              const conversaciones =
                solicitud.result || [];

              let mayorNumero = 1;

              conversaciones.forEach(
                (conversacion) => {
                  const titulo =
                    conversacion.titulo || "";

                  const coincidencia =
                    titulo.match(
                      /^Conversación (\d+)$/
                    );

                  if (coincidencia) {
                    const numero =
                      Number(coincidencia[1]);

                    if (
                      numero > mayorNumero
                    ) {
                      mayorNumero = numero;
                    }
                  }
                }
              );

              resolve(
                mayorNumero + 1
              );
            };

            solicitud.onerror = () => {
              reject(
                solicitud.error
              );
            };
          }
        );

      conversacionActivaId =
        "conv_" + Date.now();

      localStorage.setItem(
        CLAVE_CONVERSACION_ACTIVA,
        conversacionActivaId
      );

      await new Promise(
        (resolve, reject) => {
          const transaccion =
            db.transaction(
              ALMACEN_CONVERSACIONES,
              "readwrite"
            );

          transaccion
            .objectStore(
              ALMACEN_CONVERSACIONES
            )
            .add({
              id: conversacionActivaId,
              titulo:
                "Conversación " +
                numeroConversacion,
              creada: Date.now()
            });

          transaccion.oncomplete = () => {
            db.close();
            resolve();
          };

          transaccion.onerror = () => {
            db.close();
            reject(
              transaccion.error
            );
          };
        }
      );

      mensajes.innerHTML = "";

      menu.classList.add(
        "oculto"
      );

    } catch (error) {
      console.error(
        "No se pudo crear la conversación:",
        error
      );

      alert(
        "No se ha podido crear la conversación."
      );
    }
  }
);
/* =========================
   AJUSTES, RECUERDOS Y PERSONAJES
========================= */

ajustes.addEventListener("click", () => {
  menu.classList.add("oculto");
  panelAjustes.classList.remove("oculto");
});

cerrarAjustes.addEventListener("click", () => {
  panelAjustes.classList.add("oculto");
});


/* =========================
   RECUERDOS
========================= */

abrirRecuerdos.addEventListener(
  "click",
  async () => {
    panelAjustes.classList.add("oculto");
    panelRecuerdos.classList.remove("oculto");

    await mostrarRecuerdosGuardados();
  }
);

cerrarRecuerdos.addEventListener(
  "click",
  () => {
    panelRecuerdos.classList.add("oculto");
  }
);

volverAjustes.addEventListener(
  "click",
  () => {
    panelRecuerdos.classList.add("oculto");
    panelAjustes.classList.remove("oculto");
  }
);

guardarRecuerdo.addEventListener(
  "click",
  async () => {
    const texto = nuevoRecuerdo.value.trim();

    if (!texto) {
      alert("Escribe primero un recuerdo.");
      return;
    }

    try {
      await guardarRecuerdoEnDB(texto);

      nuevoRecuerdo.value = "";

      await mostrarRecuerdosGuardados();
    } catch (error) {
      console.error(
        "No se pudo guardar el recuerdo:",
        error
      );

      alert(
        "No se ha podido guardar el recuerdo."
      );
    }
  }
);


/* =========================
   PERSONAJES
========================= */

abrirPersonajes.addEventListener(
  "click",
  async () => {
    panelAjustes.classList.add("oculto");
    panelPersonajes.classList.remove("oculto");

    await mostrarPersonajesGuardados();
  }
);

cerrarPersonajes.addEventListener(
  "click",
  () => {
    panelPersonajes.classList.add("oculto");
  }
);

volverAjustesPersonajes.addEventListener(
  "click",
  () => {
    panelPersonajes.classList.add("oculto");
    panelAjustes.classList.remove("oculto");
  }
);

guardarPersonaje.addEventListener(
  "click",
  async () => {
    const nombre =
      nombrePersonaje.value.trim();

    const ficha =
      nuevaFichaPersonaje.value.trim();

    if (!nombre) {
      alert(
        "Escribe el nombre del personaje."
      );
      return;
    }

    if (!ficha) {
      alert(
        "Escribe la ficha del personaje."
      );
      return;
    }

    try {
      if (personajeEditandoId !== null) {
        alert(ficha);
        await editarPersonajeDB(
          personajeEditandoId,
          nombre,
          ficha
        );

        personajeEditandoId = null;

        guardarPersonaje.textContent =
          "Guardar personaje";

      } else {
        await guardarPersonajeEnDB(
          nombre,
          ficha
        );
      }

      nombrePersonaje.value = "";
      nuevaFichaPersonaje.value = "";

      await mostrarPersonajesGuardados();

    } catch (error) {
      console.error(
        "No se pudo guardar el personaje:",
        error
      );

      alert(
        "No se ha podido guardar el personaje."
      );
    }
  }
);

/* ========================
     HORA DE ESCENA
======================== */

const CLAVE_HORA_ESCENA = "soteria_hora_escena";
const CLAVE_HORA_ESCENA_REFERENCIA_REAL =
  "soteria_hora_escena_referencia_real";
const CLAVE_CITA_PENDIENTE =
  "soteria_cita_pendiente";

const MARGEN_CITA_MS =
  30 * 60 * 1000;
  function interpretarHoraEscena(texto) {
  const meses = {
    enero: 0,
    febrero: 1,
    marzo: 2,
    abril: 3,
    mayo: 4,
    junio: 5,
    julio: 6,
    agosto: 7,
    septiembre: 8,
    setiembre: 8,
    octubre: 9,
    noviembre: 10,
    diciembre: 11
  
  };

  const limpio = texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  const coincidencia = limpio.match(
    /(\d{1,2})\s+de\s+([a-z]+)\s+(?:de\s+)?(\d{4})[.,]?\s+(\d{1,2}):(\d{2})\s*(am|pm)?/
  );

  if (!coincidencia) return null;

  const dia = Number(coincidencia[1]);
  const mes = meses[coincidencia[2]];
  const anio = Number(coincidencia[3]);
  let hora = Number(coincidencia[4]);
  const minuto = Number(coincidencia[5]);
  const periodo = coincidencia[6];

  if (mes === undefined) return null;

  if (periodo === "pm" && hora < 12) hora += 12;
  if (periodo === "am" && hora === 12) hora = 0;

  return Date.UTC(anio, mes, dia, hora, minuto);
  }
function obtenerHoraActualEscenaMs() {
  const horaGuardada =
    localStorage.getItem(CLAVE_HORA_ESCENA);

  const referenciaReal = Number(
    localStorage.getItem(
      CLAVE_HORA_ESCENA_REFERENCIA_REAL
    )
  );

  if (!horaGuardada || !referenciaReal) {
    return null;
  }

  const horaBase =
    interpretarHoraEscena(horaGuardada);

  if (horaBase === null) {
    return null;
  }

  return horaBase +
    (Date.now() - referenciaReal);
}
function obtenerEstadoCitaPendiente() {
  const guardada =
    localStorage.getItem(CLAVE_CITA_PENDIENTE);

  if (!guardada) {
    return null;
  }

  try {
    const cita = JSON.parse(guardada);

    if (!cita || !cita.momento) {
      return null;
    }

    const momentoCita =
      Date.parse(cita.momento + ":00Z");

    if (!Number.isFinite(momentoCita)) {
      return null;
    }

    const ahoraEscena =
      obtenerHoraActualEscenaMs();

    if (ahoraEscena === null) {
      return null;
    }

    return {
      cita: cita,
      momentoCita: momentoCita,
      ahoraEscena: ahoraEscena,
      retrasoMs: ahoraEscena - momentoCita,
      vencida:
        ahoraEscena >=
        momentoCita + MARGEN_CITA_MS
    };

  } catch (error) {
    console.error(
      "No se pudo leer la cita pendiente:",
      error
    );

    return null;
  }
}
function registrarPresenciaAshEnCita() {
  const estadoCita =
    obtenerEstadoCitaPendiente();

  if (!estadoCita) {
    return;
  }

  if (
    estadoCita.retrasoMs >= 0 &&
    estadoCita.retrasoMs < MARGEN_CITA_MS
  ) {
    localStorage.removeItem(
      CLAVE_CITA_PENDIENTE
    );
  }
}
function actualizarEstadoHoraEscena() {
  const hora = localStorage.getItem(CLAVE_HORA_ESCENA);
const referenciaReal = Number(
  localStorage.getItem(CLAVE_HORA_ESCENA_REFERENCIA_REAL)
);

const tiempoTranscurrido =
  referenciaReal ? Date.now() - referenciaReal : 0;
 const horaEscenaBase =
  hora ? interpretarHoraEscena(hora) : null;

const horaEscenaActual =
  horaEscenaBase !== null
    ? horaEscenaBase + tiempoTranscurrido
    : null;
  
  if (hora) {
    const minutosPasados =
  Math.floor(tiempoTranscurrido / 60000);

const horasPasadas =
  Math.floor(minutosPasados / 60);

const minutosRestantes =
  minutosPasados % 60;

const textoTranscurrido =
  horasPasadas > 0
    ? `${horasPasadas} h ${minutosRestantes} min`
    : `${minutosPasados} min`;
    const horaActualEscenaTexto =
  horaEscenaActual !== null
    ? new Date(horaEscenaActual).toLocaleTimeString(
        "es-ES",
        {
          timeZone: "UTC",
          hour: "2-digit",
          minute: "2-digit"
        }
      )
    : "";

estadoHoraEscena.textContent =
  "🕰️ Hora de escena: " + hora +
  "\n⏱️ Hora actual: " + horaActualEscenaTexto +
  "\n⏳ Tiempo transcurrido: " + textoTranscurrido;
  } else {
    estadoHoraEscena.textContent =
      "Hora de escena no establecida";
  }
}

abrirHoraEscena.addEventListener(
  "click",
  () => {
    panelAjustes.classList.add("oculto");
    panelHoraEscena.classList.remove("oculto");

    const horaGuardada =
      localStorage.getItem(CLAVE_HORA_ESCENA);

    horaEscena.value = horaGuardada || "";

    actualizarEstadoHoraEscena();
  }
);

cerrarHoraEscena.addEventListener(
  "click",
  () => {
    panelHoraEscena.classList.add("oculto");
  }
);

volverAjustesHora.addEventListener(
  "click",
  () => {
    panelHoraEscena.classList.add("oculto");
    panelAjustes.classList.remove("oculto");
  }
);

guardarHoraEscena.addEventListener(
  "click",
  () => {
    const momento = horaEscena.value.trim();

    if (!momento) {
      alert("Escribe el día y la hora de la escena.");
      return;
    }

    localStorage.setItem(
      CLAVE_HORA_ESCENA,
      momento
    );
localStorage.setItem(
  CLAVE_HORA_ESCENA_REFERENCIA_REAL,
  Date.now().toString()
);
    actualizarEstadoHoraEscena();
    const pruebaCita =
  obtenerEstadoCitaPendiente();

    alert("Día y hora de escena guardados.");
  }
);

borrarHoraEscena.addEventListener(
  "click",
  () => {
    localStorage.removeItem(CLAVE_HORA_ESCENA);
localStorage.removeItem(
  CLAVE_HORA_ESCENA_REFERENCIA_REAL
);
    horaEscena.value = "";

    actualizarEstadoHoraEscena();
  }
);

actualizarEstadoHoraEscena();

/* =========================
   AGENDA DE SOTERIA
   Modulo independiente y persistente.
========================= */

const CLAVE_AGENDA_SOTERIA = "soteria_agenda_v1";

function cargarAgendaSoteria() {
  try {
    const datos = JSON.parse(
      localStorage.getItem(CLAVE_AGENDA_SOTERIA) || "[]"
    );
    return Array.isArray(datos) ? datos : [];
  } catch (error) {
    console.error("No se pudo leer la Agenda de Soteria:", error);
    return [];
  }
}

function guardarAgendaSoteria(agenda) {
  localStorage.setItem(
    CLAVE_AGENDA_SOTERIA,
    JSON.stringify(Array.isArray(agenda) ? agenda : [])
  );
}

function fechaUTCPartes(ms) {
  const d = new Date(ms);
  return {
    anio: d.getUTCFullYear(),
    mes: d.getUTCMonth() + 1,
    dia: d.getUTCDate(),
    semana: d.getUTCDay()
  };
}

function claveFechaUTC(ms) {
  const p = fechaUTCPartes(ms);
  return `${p.anio}-${String(p.mes).padStart(2, "0")}-${String(p.dia).padStart(2, "0")}`;
}

function entradaAgendaCorrespondeHoy(entrada, ahoraMs) {
  if (!entrada || !entrada.tipo || !entrada.texto) return false;

  const hoy = fechaUTCPartes(ahoraMs);
  const hoyClave = claveFechaUTC(ahoraMs);

  if (entrada.tipo === "fecha") {
    return entrada.fecha === hoyClave;
  }

  if (entrada.tipo === "periodo") {
    return Boolean(
      entrada.desde && entrada.hasta &&
      hoyClave >= entrada.desde && hoyClave <= entrada.hasta
    );
  }

  if (entrada.tipo === "semanal") {
    return Array.isArray(entrada.dias) &&
      entrada.dias.includes(hoy.semana);
  }

  if (entrada.tipo === "anual") {
    return Number(entrada.mes) === hoy.mes &&
      Number(entrada.dia) === hoy.dia;
  }

  return false;
}

function describirEntradaAgenda(entrada) {
  const hora = entrada.hora ? ` · ${entrada.hora}` : "";

  if (entrada.tipo === "fecha") {
    return `${entrada.fecha}${hora} — ${entrada.texto}`;
  }

  if (entrada.tipo === "periodo") {
    return `${entrada.desde} a ${entrada.hasta}${hora} — ${entrada.texto}`;
  }

  if (entrada.tipo === "semanal") {
    const nombres = ["domingo", "lunes", "martes", "miércoles", "jueves", "viernes", "sábado"];
    const dias = (entrada.dias || []).map(d => nombres[d]).join(", ");
    return `${dias}${hora} — ${entrada.texto}`;
  }

  if (entrada.tipo === "anual") {
    return `${String(entrada.dia).padStart(2, "0")}/${String(entrada.mes).padStart(2, "0")} cada año${hora} — ${entrada.texto}`;
  }

  return entrada.texto;
}

function obtenerContextoAgendaSoteria(ahoraMs) {
  if (!Number.isFinite(ahoraMs)) return "";

  const relevantes = cargarAgendaSoteria()
    .filter(entrada => entradaAgendaCorrespondeHoy(entrada, ahoraMs));

  if (relevantes.length === 0) return "";

  return `\n\nAGENDA ACTUAL DE SOTERIA:\n${relevantes
    .map(entrada => `- ${describirEntradaAgenda(entrada)}`)
    .join("\n")}\n\nEstos son planes o compromisos que Soteria ya conoce. Forman parte normal de su día. Úsalos con naturalidad cuando sean relevantes, sin tratarlos como una notificación ni mencionar una agenda técnica. No inventes detalles secretos que la entrada no revele.\n`;
}

function crearInterfazAgendaSoteria() {
  if (!panelAjustes || document.getElementById("abrirAgendaSoteria")) return;

  const estilo = document.createElement("style");
  estilo.textContent = `
    #panelAgendaSoteria { position: fixed; inset: 0; z-index: 10000; overflow-y: auto; background: rgba(18,18,22,.98); color: #fff; padding: 18px; box-sizing: border-box; }
    #panelAgendaSoteria.oculto { display: none !important; }
    #panelAgendaSoteria .agenda-caja { max-width: 720px; margin: 0 auto; }
    #panelAgendaSoteria h2 { margin: 8px 0 16px; }
    #panelAgendaSoteria label { display: block; margin: 12px 0 5px; font-weight: 600; }
    #panelAgendaSoteria input, #panelAgendaSoteria select, #panelAgendaSoteria textarea { width: 100%; box-sizing: border-box; font: inherit; padding: 10px; border-radius: 8px; border: 1px solid #777; background: #fff; color: #111; }
    #panelAgendaSoteria textarea { min-height: 105px; resize: vertical; }
    #panelAgendaSoteria button, #abrirAgendaSoteria { font: inherit; min-height: 42px; padding: 9px 13px; border-radius: 8px; cursor: pointer; }
    #panelAgendaSoteria .agenda-acciones { display: flex; gap: 8px; flex-wrap: wrap; margin: 14px 0; }
    #panelAgendaSoteria .agenda-dias { display: flex; flex-wrap: wrap; gap: 8px 12px; }
    #panelAgendaSoteria .agenda-dias label { display: inline-flex; align-items: center; gap: 5px; margin: 4px 0; font-weight: 400; }
    #panelAgendaSoteria .agenda-dias input { width: auto; }
    #panelAgendaSoteria .agenda-item { border: 1px solid #666; border-radius: 10px; padding: 12px; margin: 10px 0; background: rgba(255,255,255,.06); }
    #panelAgendaSoteria .agenda-item p { white-space: pre-wrap; margin: 8px 0; }
    #panelAgendaSoteria .agenda-meta { opacity: .8; font-size: .92em; }
    #panelAgendaSoteria .agenda-fila { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    @media (max-width: 520px) { #panelAgendaSoteria .agenda-fila { grid-template-columns: 1fr; } }
  `;
  document.head.appendChild(estilo);

  const boton = document.createElement("button");
  boton.type = "button";
  boton.id = "abrirAgendaSoteria";
  boton.textContent = "📅 Agenda";
  const botonHoraEscena = document.getElementById("abrirHoraEscena");
  if (botonHoraEscena) {
    boton.className = botonHoraEscena.className;
    botonHoraEscena.insertAdjacentElement("afterend", boton);
  } else {
    panelAjustes.appendChild(boton);
  }

  const panel = document.createElement("div");
  panel.id = "panelAgendaSoteria";
  panel.className = "oculto";
  panel.innerHTML = `
    <div class="agenda-caja">
      <div class="agenda-acciones">
        <button type="button" id="volverAgendaSoteria">← Ajustes</button>
        <button type="button" id="cerrarAgendaSoteria">Cerrar</button>
      </div>
      <h2>📅 Agenda de Soteria</h2>

      <label for="agendaTipo">Tipo de entrada</label>
      <select id="agendaTipo">
        <option value="fecha">Fecha concreta</option>
        <option value="periodo">Periodo / varios días</option>
        <option value="semanal">Días de la semana</option>
        <option value="anual">Cada año (sin año)</option>
      </select>

      <div id="agendaCamposFecha">
        <label for="agendaFecha">Fecha</label>
        <input id="agendaFecha" type="date">
      </div>

      <div id="agendaCamposPeriodo" class="oculto">
        <div class="agenda-fila">
          <div><label for="agendaDesde">Desde</label><input id="agendaDesde" type="date"></div>
          <div><label for="agendaHasta">Hasta</label><input id="agendaHasta" type="date"></div>
        </div>
      </div>

      <div id="agendaCamposSemanal" class="oculto">
        <label>Días</label>
        <div class="agenda-dias">
          <label><input type="checkbox" value="1">Lun</label>
          <label><input type="checkbox" value="2">Mar</label>
          <label><input type="checkbox" value="3">Mié</label>
          <label><input type="checkbox" value="4">Jue</label>
          <label><input type="checkbox" value="5">Vie</label>
          <label><input type="checkbox" value="6">Sáb</label>
          <label><input type="checkbox" value="0">Dom</label>
        </div>
      </div>

      <div id="agendaCamposAnual" class="oculto">
        <div class="agenda-fila">
          <div><label for="agendaDia">Día</label><input id="agendaDia" type="number" min="1" max="31" inputmode="numeric"></div>
          <div><label for="agendaMes">Mes</label>
            <select id="agendaMes">
              <option value="1">Enero</option><option value="2">Febrero</option><option value="3">Marzo</option><option value="4">Abril</option>
              <option value="5">Mayo</option><option value="6">Junio</option><option value="7">Julio</option><option value="8">Agosto</option>
              <option value="9">Septiembre</option><option value="10">Octubre</option><option value="11">Noviembre</option><option value="12">Diciembre</option>
            </select>
          </div>
        </div>
      </div>

      <label>Hora (opcional)</label>
      <div class="agenda-fila">
        <select id="agendaHoraH" aria-label="Hora">
          <option value="">-- hora --</option>
          ${Array.from({length:24}, (_,i) => `<option value="${String(i).padStart(2,"0")}">${String(i).padStart(2,"0")}</option>`).join("")}
        </select>
        <select id="agendaHoraM" aria-label="Minutos">
          <option value="">-- min --</option>
          ${Array.from({length:60}, (_,i) => `<option value="${String(i).padStart(2,"0")}">${String(i).padStart(2,"0")}</option>`).join("")}
        </select>
      </div>

      <label for="agendaTexto">Plan / situación que Soteria conoce</label>
      <textarea id="agendaTexto" placeholder="Ej.: Ash le avisó de que a las 20:00 tiene preparada una sorpresa. Soteria sabe que habrá una sorpresa, pero no cuál es."></textarea>

      <div class="agenda-acciones">
        <button type="button" id="guardarAgendaEntrada">Guardar entrada</button>
        <button type="button" id="cancelarEdicionAgenda" class="oculto">Cancelar edición</button>
      </div>
      <div id="listaAgendaSoteria"></div>
    </div>`;
  document.body.appendChild(panel);

  const tipo = panel.querySelector("#agendaTipo");
  const camposFecha = panel.querySelector("#agendaCamposFecha");
  const camposPeriodo = panel.querySelector("#agendaCamposPeriodo");
  const camposSemanal = panel.querySelector("#agendaCamposSemanal");
  const camposAnual = panel.querySelector("#agendaCamposAnual");
  const texto = panel.querySelector("#agendaTexto");
  const horaH = panel.querySelector("#agendaHoraH");
  const horaM = panel.querySelector("#agendaHoraM");
  const guardar = panel.querySelector("#guardarAgendaEntrada");
  const cancelar = panel.querySelector("#cancelarEdicionAgenda");
  const lista = panel.querySelector("#listaAgendaSoteria");
  let editandoId = null;

  function mostrarCampos() {
    [camposFecha, camposPeriodo, camposSemanal, camposAnual]
      .forEach(n => n.classList.add("oculto"));
    ({ fecha: camposFecha, periodo: camposPeriodo, semanal: camposSemanal, anual: camposAnual })[tipo.value]
      .classList.remove("oculto");
  }

  function limpiarFormulario() {
    editandoId = null;
    tipo.value = "fecha";
    panel.querySelector("#agendaFecha").value = "";
    panel.querySelector("#agendaDesde").value = "";
    panel.querySelector("#agendaHasta").value = "";
    panel.querySelectorAll("#agendaCamposSemanal input[type=checkbox]").forEach(c => c.checked = false);
    panel.querySelector("#agendaDia").value = "";
    panel.querySelector("#agendaMes").value = "1";
    horaH.value = "";
    horaM.value = "";
    texto.value = "";
    guardar.textContent = "Guardar entrada";
    cancelar.classList.add("oculto");
    mostrarCampos();
  }

  function leerFormulario() {
    const entrada = {
      id: editandoId || `agenda_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      tipo: tipo.value,
      hora: (horaH.value !== "" && horaM.value !== "") ? `${horaH.value}:${horaM.value}` : "",
      texto: texto.value.trim()
    };

    if ((horaH.value === "") !== (horaM.value === "")) throw new Error("Elige hora y minutos, o deja ambos vacíos.");
    if (!entrada.texto) throw new Error("Escribe el plan o situación.");

    if (entrada.tipo === "fecha") {
      entrada.fecha = panel.querySelector("#agendaFecha").value;
      if (!entrada.fecha) throw new Error("Elige una fecha.");
    } else if (entrada.tipo === "periodo") {
      entrada.desde = panel.querySelector("#agendaDesde").value;
      entrada.hasta = panel.querySelector("#agendaHasta").value;
      if (!entrada.desde || !entrada.hasta) throw new Error("Elige las dos fechas del periodo.");
      if (entrada.hasta < entrada.desde) throw new Error("La fecha final no puede ser anterior a la inicial.");
    } else if (entrada.tipo === "semanal") {
      entrada.dias = Array.from(panel.querySelectorAll("#agendaCamposSemanal input:checked"), c => Number(c.value));
      if (entrada.dias.length === 0) throw new Error("Elige al menos un día de la semana.");
    } else if (entrada.tipo === "anual") {
      entrada.dia = Number(panel.querySelector("#agendaDia").value);
      entrada.mes = Number(panel.querySelector("#agendaMes").value);
      if (!entrada.dia || entrada.dia < 1 || entrada.dia > 31) throw new Error("Escribe un día válido.");
    }

    return entrada;
  }

  function editarEntrada(entrada) {
    limpiarFormulario();
    editandoId = entrada.id;
    tipo.value = entrada.tipo;
    const partesHora = (entrada.hora || "").split(":");
    horaH.value = partesHora.length === 2 ? partesHora[0] : "";
    horaM.value = partesHora.length === 2 ? partesHora[1] : "";
    texto.value = entrada.texto || "";
    if (entrada.tipo === "fecha") panel.querySelector("#agendaFecha").value = entrada.fecha || "";
    if (entrada.tipo === "periodo") {
      panel.querySelector("#agendaDesde").value = entrada.desde || "";
      panel.querySelector("#agendaHasta").value = entrada.hasta || "";
    }
    if (entrada.tipo === "semanal") {
      panel.querySelectorAll("#agendaCamposSemanal input[type=checkbox]").forEach(c => c.checked = (entrada.dias || []).includes(Number(c.value)));
    }
    if (entrada.tipo === "anual") {
      panel.querySelector("#agendaDia").value = entrada.dia || "";
      panel.querySelector("#agendaMes").value = String(entrada.mes || 1);
    }
    guardar.textContent = "Guardar cambios";
    cancelar.classList.remove("oculto");
    mostrarCampos();
    panel.scrollTop = 0;
    texto.focus();
  }

  function renderLista() {
    const agenda = cargarAgendaSoteria();
    lista.innerHTML = "";
    if (agenda.length === 0) {
      const vacio = document.createElement("p");
      vacio.textContent = "No hay entradas programadas.";
      lista.appendChild(vacio);
      return;
    }

    agenda.forEach(entrada => {
      const item = document.createElement("div");
      item.className = "agenda-item";
      const meta = document.createElement("div");
      meta.className = "agenda-meta";
      meta.textContent = describirEntradaAgenda({ ...entrada, texto: "" }).replace(/\s—\s*$/, "");
      const p = document.createElement("p");
      p.textContent = entrada.texto;
      const acciones = document.createElement("div");
      acciones.className = "agenda-acciones";
      const editar = document.createElement("button");
      editar.type = "button";
      editar.textContent = "Editar";
      editar.addEventListener("click", () => editarEntrada(entrada));
      const borrar = document.createElement("button");
      borrar.type = "button";
      borrar.textContent = "🗑️ Borrar entrada";
      borrar.addEventListener("click", () => {
        if (!confirm("¿Borrar esta entrada de la Agenda?")) return;
        guardarAgendaSoteria(cargarAgendaSoteria().filter(e => e.id !== entrada.id));
        if (editandoId === entrada.id) limpiarFormulario();
        renderLista();
      });
      acciones.append(editar, borrar);
      item.append(meta, p, acciones);
      lista.appendChild(item);
    });
  }

  tipo.addEventListener("change", mostrarCampos);
  guardar.addEventListener("click", () => {
    try {
      const entrada = leerFormulario();
      const agenda = cargarAgendaSoteria();
      const indice = agenda.findIndex(e => e.id === entrada.id);
      if (indice >= 0) agenda[indice] = entrada;
      else agenda.push(entrada);
      guardarAgendaSoteria(agenda);
      limpiarFormulario();
      renderLista();
    } catch (error) {
      alert(error.message || "No se ha podido guardar la entrada.");
    }
  });
  cancelar.addEventListener("click", limpiarFormulario);
  boton.addEventListener("click", () => {
    panelAjustes.classList.add("oculto");
    panel.classList.remove("oculto");
    renderLista();
  });
  panel.querySelector("#volverAgendaSoteria").addEventListener("click", () => {
    panel.classList.add("oculto");
    panelAjustes.classList.remove("oculto");
  });
  panel.querySelector("#cerrarAgendaSoteria").addEventListener("click", () => panel.classList.add("oculto"));

  mostrarCampos();
  renderLista();
}

crearInterfazAgendaSoteria();

/* =========================
   REFUERZO DE EMERGENCIA
========================= */

const CLAVE_PROMPT_EMERGENCIA =
  "soteria_prompt_emergencia";

const CLAVE_EMERGENCIA_ACTIVA =
  "soteria_emergencia_activa";


function actualizarEstadoEmergencia() {
  const activa =
    localStorage.getItem(
      CLAVE_EMERGENCIA_ACTIVA
    ) === "true";

  if (activa) {
    estadoEmergencia.textContent =
      "🚨 Refuerzo activado";

    alternarEmergencia.textContent =
      "⛔ Desactivar refuerzo";
  } else {
    estadoEmergencia.textContent =
      "Refuerzo desactivado";

    alternarEmergencia.textContent =
      "🚨 Activar refuerzo";
  }
}


function cargarPromptEmergencia() {
  promptEmergencia.value =
    localStorage.getItem(
      CLAVE_PROMPT_EMERGENCIA
    ) || "";

  actualizarEstadoEmergencia();
}


/* ABRIR */

abrirEmergencia.addEventListener(
  "click",
  () => {
    panelAjustes.classList.add("oculto");
    panelEmergencia.classList.remove("oculto");

    cargarPromptEmergencia();
  }
);


/* CERRAR */

cerrarEmergencia.addEventListener(
  "click",
  () => {
    panelEmergencia.classList.add("oculto");
  }
);


/* VOLVER A AJUSTES */

volverAjustesEmergencia.addEventListener(
  "click",
  () => {
    panelEmergencia.classList.add("oculto");
    panelAjustes.classList.remove("oculto");
  }
);


/* GUARDAR */

guardarEmergencia.addEventListener(
  "click",
  () => {
    const texto =
      promptEmergencia.value.trim();

    if (!texto) {
      alert(
        "Escribe un prompt de emergencia antes de guardarlo."
      );

      return;
    }

    localStorage.setItem(
      CLAVE_PROMPT_EMERGENCIA,
      texto
    );

    actualizarEstadoEmergencia();

    alert(
      "Refuerzo de emergencia guardado o actualizado."
    );
  }
);


/* ACTIVAR / DESACTIVAR */

alternarEmergencia.addEventListener(
  "click",
  () => {
    const texto =
      promptEmergencia.value.trim();

    const activa =
      localStorage.getItem(
        CLAVE_EMERGENCIA_ACTIVA
      ) === "true";

    if (!activa) {
      if (!texto) {
        alert(
          "Primero escribe y guarda un prompt de emergencia."
        );

        return;
      }

      localStorage.setItem(
        CLAVE_PROMPT_EMERGENCIA,
        texto
      );

      localStorage.setItem(
        CLAVE_EMERGENCIA_ACTIVA,
        "true"
      );
    } else {
      localStorage.setItem(
        CLAVE_EMERGENCIA_ACTIVA,
        "false"
      );
    }

    actualizarEstadoEmergencia();
  }
);


/* BORRAR */

borrarEmergencia.addEventListener(
  "click",
  () => {

    localStorage.removeItem(
      CLAVE_PROMPT_EMERGENCIA
    );

    localStorage.setItem(
      CLAVE_EMERGENCIA_ACTIVA,
      "false"
    );

    promptEmergencia.value = "";

    actualizarEstadoEmergencia();
  }
);
/* =========================
   CONEXIÓN CON DEEPSEEK
========================= */
const CONTEXTO_SOTERIA = `
Interpreta a Soteria Eleni Athena Kafieri, Tory o Sota.
Soteria es antropóloga, arqueóloga y profesora en Tulane, nacida en Grecia 1981.
Experta en todos los campos de historia antigua.
Habla en primera persona y responde y narra tambien en primera persona desde su propia experiencia.
Es alegre, divertida cuando es necesario. Una mujer valiente cuando se requiere.
En casa es como cualquier mujer, limpia, cose, ve la television, hace tareas domesticas o juega con el movil.
El interlocutor es Acheron Parthenopaeus  (Ash), su marido (matrimonio 9 de enero 2010), y sus palabras y acciones llegan desde el mensaje del usuario.
Soteria acepta las correcciones de Ash.
Dentro de casa Ash es Ash nadie más.
Ash, no necesita comer, pero si bebe cualquier liquido. Soteria l9 sabe.
Soteria conserva su personalidad y su criterio propio.
A Acheron le gusta traerle obsequios, porque le hace feliz y la ama sin necesidad de nada especial o motivo y Soteria los acepta con naturalidad, no pone incomodo a Ash con preguntas
sabe que son regalos para hacerla sonreir .
Acheron  usa un apodo cariñoso para Soteria la llama cariñosamente"Torimou". Soteria tambien tiene un apodo  cariñoso para Acheron lo llama " morritos" o "Achimou".
Formato: las acciones visibles se escriben entre asteriscos .... Los pensamientos privados de Soteria y de Acheron se escriben entre paréntesis (…) y expresan únicamente lo que el personaje siente, desea, teme, imagina, recuerda o piensa espontáneamente en ese momento; no los convierte en diálogo ni los presenta como información para Ash o para Soteria.
Soteria siente curiosidad por el trabajo de Ash, pero intenta no sobrepadar los limites preguntando.
Cuado Acheton aparecece de repente no hay motivos ocultos, aparece por lo que el mismo indica.
`;

async function detectarCompromisoTemporal(texto) {
  const url =
    "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar";

  const horaGuardada =
    localStorage.getItem(CLAVE_HORA_ESCENA);

  const referenciaReal = Number(
    localStorage.getItem(
      CLAVE_HORA_ESCENA_REFERENCIA_REAL
    )
  );

  let horaActualEscena = horaGuardada || "";

  if (horaGuardada && referenciaReal) {
    const baseEscena =
      interpretarHoraEscena(horaGuardada);

    if (baseEscena !== null) {
      const ahoraEscena = new Date(
        baseEscena +
        (Date.now() - referenciaReal)
      );

      horaActualEscena =
        ahoraEscena.toLocaleString(
          "es-ES",
          {
            timeZone: "UTC",
            weekday: "long",
            day: "numeric",
            month: "long",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
          }
        );
    }
  }
  let historialCita = [];

try {
  const entradasCita =
    await cargarEntradasChat();

  historialCita = entradasCita
    .filter(entrada =>
      entrada &&
      entrada.tipo === "texto" &&
      entrada.contenido
    )
    .slice(-12)
    .map(entrada => ({
      role:
        entrada.autor === "soteria"
          ? "assistant"
          : "user",
      content: String(entrada.contenido)
    }));

  const ultimoCita =
    historialCita[historialCita.length - 1];

  if (
    ultimoCita &&
    ultimoCita.role === "user" &&
    ultimoCita.content === texto
  ) {
    historialCita.pop();
  }

} catch (error) {
  console.error(
    "No se pudo cargar contexto para la cita:",
    error
  );
}

  const messages = [
  {
    role: "system",
    content: `
La hora actual de la escena es:
${horaActualEscena || "no establecida"}

Lee la conversación reciente y el mensaje actual de Ash.

Si Ash propone una hora futura, esa hora se considera una cita con Soteria.

La acción o plan asociado a esa hora puede estar explicado
en mensajes anteriores de la misma conversación.
Por ejemplo, Ash puede haber explicado primero qué harán
y después limitarse a indicar la hora.

Interpreta expresiones naturales como hoy, mañana,
esta tarde, esta noche o dentro de cierto tiempo
usando la hora actual de la escena.

Una mención de la hora actual, una pregunta sobre qué hora es
o una hora que no sea propuesta por Ash para algo futuro
no crea una cita.

Devuelve únicamente JSON válido:

{
  "momento": "YYYY-MM-DDTHH:MM" | null,
  "cita": string | null
}

"momento" es la fecha y hora futura propuesta por Ash.

"cita" describe brevemente lo que Soteria puede esperar
que ocurra, usando la conversación reciente cuando haga falta.

Si Ash no propone una hora futura, devuelve:

{
  "momento": null,
  "cita": null
}

No añadas explicaciones fuera del JSON.
`
  },

  ...historialCita,

  {
    role: "user",
    content: texto
  }
];

  try {
    const respuesta = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messages: messages
      })
    });

    if (!respuesta.ok) {
      throw new Error(
        "Error " + respuesta.status
      );
    }

    const salida =
      (await respuesta.text()).trim();

    const limpia = salida
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "");

    return JSON.parse(limpia);

  } catch (error) {
    console.error(
      "Error al detectar compromiso temporal:",
      error
    );

    return null;
  }
}

async function responderIA(texto) {
  const url =
    "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar";

  try {
    /* =========================
       CARGAR MEMORIA RECIENTE
    ========================= */

    let entradas = [];

    try {
      entradas = await cargarEntradasChat();
    } catch (error) {
      console.error(
        "No se pudo cargar la memoria reciente:",
        error
      );
    }

    let historialReciente = entradas
      .filter((entrada) => {
        return (
          entrada &&
          entrada.tipo === "texto" &&
          entrada.contenido
        );
      })
      .slice(-100)
      .map((entrada) => {
        return {
          role:
            entrada.autor === "soteria"
              ? "assistant"
              : "user",

          content: String(entrada.contenido)
        };
      });


    /* =========================
       CARGAR RECUERDOS
       PERMANENTES
    ========================= */

    let recuerdos = [];

    try {
      recuerdos = await cargarRecuerdosDB();
    } catch (error) {
      console.error(
        "No se pudieron cargar los recuerdos:",
        error
      );
    }

    const memoriaPermanente = recuerdos
      .filter((recuerdo) => {
        return (
          recuerdo &&
          recuerdo.contenido
        );
      })
      .map((recuerdo) => {
        return "- " + recuerdo.contenido;
      })
      .join("\n");


    /* =========================
       CARGAR AGENDA
       PERMANENTE
    ========================= */

    let agenda = [];

    try {
      agenda = cargarAgendaSoteria();
    } catch (error) {
      console.error(
        "No se pudo cargar la agenda:",
        error
      );
    }

    const agendaPermanente = agenda
      .filter((entrada) => {
        return (
          entrada &&
          entrada.texto
        );
      })
      .map((entrada) => {
        return "- " + describirEntradaAgenda(entrada);
      })
      .join("\n");


    /* =========================
       EVITAR DUPLICAR
       EL MENSAJE ACTUAL DE ASH
    ========================= */

    const ultimo =
      historialReciente[
        historialReciente.length - 1
      ];

    if (
      ultimo &&
      ultimo.role === "user" &&
      ultimo.content === texto
    ) {
      historialReciente.pop();
    }


    /* =========================
       CONTEXTO DE RECUERDOS
    ========================= */

    let contextoRecuerdos = "";

    if (memoriaPermanente) {
      contextoRecuerdos = `

RECUERDOS CONOCIDOS:

${memoriaPermanente}

Los recuerdos son información conocida, no inventada.

`;
    }


    /* =========================
       CONTEXTO DE AGENDA
    ========================= */

    let contextoAgenda = "";

    if (agendaPermanente) {
      contextoAgenda = `

AGENDA CONOCIDA:

${agendaPermanente}

La agenda es información conocida, no inventada.

`;
    }
    
        /* =========================
       CONVERSACIÓN PARA DEEPSEEK
    ========================= */
const horaEscenaGuardada =
  localStorage.getItem(CLAVE_HORA_ESCENA);

const referenciaHoraEscenaIA = Number(
  localStorage.getItem(CLAVE_HORA_ESCENA_REFERENCIA_REAL)
);

let horaEscenaParaIA = horaEscenaGuardada;

if (horaEscenaGuardada && referenciaHoraEscenaIA) {
  const baseEscena =
    interpretarHoraEscena(horaEscenaGuardada);

  if (baseEscena !== null) {
    const ahoraEscena = new Date(
      baseEscena +
      (Date.now() - referenciaHoraEscenaIA)
    );
const lugarEscena =
  (
    horaEscenaGuardada.match(
      /\d{1,2}:\d{2}\s*(?:am|pm)?\s*,?\s*(.*)$/i
    )?.[1] || ""
  ).trim();
    horaEscenaParaIA =
      ahoraEscena.toLocaleString(
        "es-ES",
        {
          timeZone: "UTC",
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }
        ) + (lugarEscena ? ", " + lugarEscena : "");
  }
}

    const contextoHoraEscena =
  localStorage.getItem(CLAVE_HORA_ESCENA)
    ? `
DÍA Y HORA ACTUALES DE LA ESCENA:
${horaEscenaParaIA}

- Este es el día y la hora actuales y válidos dentro de la escena.
- Si Ash pregunta qué día es o qué hora es, responde usando estos datos.
- Úsalos para saber si es mañana, tarde o noche y para interpretar hoy, mañana y ayer.
- No inventes otro día ni otra hora.
- No sustituyas estos datos por la fecha o la hora reales.
`
    : "";


/* =========================
   FICHAS DE PERSONAJES
========================= */

let contextoPersonajes = "";

try {
  const personajesGuardados =
    await cargarPersonajesDB();

  if (
    Array.isArray(personajesGuardados) &&
    personajesGuardados.length > 0
  ) {
    contextoPersonajes =
      `

FICHAS DE PERSONAJES:
${personajesGuardados
  .map(personaje =>
    `${personaje.nombre}:
${personaje.ficha}`
  )
  .join("\n\n")}
`;
  }
} catch (error) {
  console.error(
    "Error al cargar fichas para Soteria:",
    error
  );
}


/* =========================
   BIBLIOTECA DARK-HUNTER
========================= */

const contextoBibliotecaDarkHunter =
  typeof contextoDarkHunterParaIA === "function"
    ? contextoDarkHunterParaIA(texto)
    : "";


/* =========================
   LIBRO INTEGRAL ACHERON
========================= */

let contextoAcheron = "";

try {
  if (
    typeof ContextoAcheron !== "undefined" &&
    ContextoAcheron &&
    typeof ContextoAcheron.prepararContexto === "function"
  ) {
    const resultadoAcheron =
      await ContextoAcheron.prepararContexto(
        texto,
        historialReciente,
        {
          limite: 3
        }
      );

    contextoAcheron =
      resultadoAcheron &&
      typeof resultadoAcheron.contexto === "string"
        ? resultadoAcheron.contexto
        : "";
  }
} catch (error) {
  console.error(
    "Error al preparar contexto de Acheron:",
    error
  );
}


const messages = [
  {
    role: "system",
    content:
      CONTEXTO_SOTERIA +
      contextoRecuerdos +
      contextoPersonajes +
      contextoHoraEscena +
      contextoAgenda +
      (
        contextoBibliotecaDarkHunter
          ? `

${contextoBibliotecaDarkHunter}
`
          : ""
      ) +
      (
        contextoAcheron
          ? `

${contextoAcheron}
`
          : ""
      ) +
      (
        localStorage.getItem(
          CLAVE_EMERGENCIA_ACTIVA
        ) === "true"
          ? `

REFUERZO TEMPORAL DE EMERGENCIA:
${localStorage.getItem(
  CLAVE_PROMPT_EMERGENCIA
) || ""}
`
          : ""
      ) +
      `
CONTINUIDAD DE LA ESCENA:
Continúa desde el presente de la escena. Los hechos establecidos, la ubicación actual y la conversación reciente forman la realidad de la escena. En situaciones cotidianas, la interacción cotidiana es suficiente y se desarrolla con naturalidad. El conocimiento disponible guía el comportamiento de Soteria y aparece en la conversación cuando el tema actual lo requiere.
`
  },

  ...historialReciente,

  {
    role: "user",
    content: texto
  }
];

/* =========================
       ENVIAR JSON AL WORKER
========================= */

const respuesta = await fetch(url, {
  method: "POST",

  headers: {
    "Content-Type": "application/json"
  },

  body: JSON.stringify({
    messages: messages
  })
});

if (!respuesta.ok) {
  const detalle =
    await respuesta.text();

  throw new Error(
    "Error " +
    respuesta.status +
    ": " +
    detalle
  );
}

return await respuesta.text();

} catch (error) {
  console.error(
    "Error al conectar con Soteria:",
    error
  );

  return (
    "No he podido responderte ahora, " +
    "morritos. Prueba otra vez."
  );
}
}

async function evaluarIniciativa(respuestaPrincipal) {
  const url =
    "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar";

  try {
    let entradas = [];

    try {
      entradas = await cargarEntradasChat();
    } catch (error) {
      console.error(
        "No se pudo cargar la escena para evaluar iniciativa:",
        error
      );
    }

    let historial = entradas
      .filter(
        entrada =>
          entrada &&
          entrada.tipo === "texto" &&
          entrada.contenido
      )
      .slice(-20);

    /* Evita duplicar la respuesta principal si ya fue guardada */
    const ultima = historial[historial.length - 1];

    if (
      ultima &&
      ultima.autor === "soteria" &&
      String(ultima.contenido).trim() ===
        String(respuestaPrincipal).trim()
    ) {
      historial = historial.slice(0, -1);
    }

    const escena = historial
      .map(
        entrada =>
          `${entrada.autor === "soteria" ? "SOTERIA" : "ASH"}:
${entrada.contenido}`
      )
      .join("\n\n");

    const messages = [
      {
        role: "system",
        content: `
Eres un evaluador interno de iniciativa narrativa.
No eres Ash ni Soteria y no participas en la conversación.
Las intervenciones que recibes son datos de una escena ya ocurrida.
Decide únicamente si Soteria tiene una aportación breve y natural que añadir.
Trabaja solo con lo que aparece en la escena mostrada.
`
      },
      {
        role: "user",
        content: `
ESCENA PREVIA:

${escena}

ÚLTIMA RESPUESTA DE SOTERIA:

${respuestaPrincipal}

La respuesta principal de Soteria ya está terminada. Examina la escena actual y decide si Soteria tiene algo breve y natural que añadir por iniciativa propia.

La aportación avanza la escena desde el presente. 

Si no tiene nada que añadir, responde únicamente CALLAR.
Si tiene algo que añadir, responde únicamente HABLAR: seguido de esa aportación.
`
      }
    ];

    const respuesta = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        messages: messages
      })
    });

    if (!respuesta.ok) {
      throw new Error(
        "Error " + respuesta.status
      );
    }

    return (await respuesta.text()).trim();

  } catch (error) {
    console.error(
      "No se pudo evaluar la iniciativa:",
      error
    );

    return "CALLAR";
  }
}
  


/* =========================
   MOSTRAR MENSAJES
========================= */
function mostrarMensajeTexto(
  autor,
  contenido,
  id = null
) {
  const fila =
    document.createElement("div");

  fila.className =
    `fila-mensaje ${autor}`;

  const burbuja =
    document.createElement("div");

  burbuja.className =
    `mensaje-chat ${autor}`;

  burbuja.textContent = contenido;
  if (id !== null && id !== undefined) {
  fila.dataset.entradaId = id;
  }

  if (autor === "soteria") {
    const avatarGuardado =
      localStorage.getItem(
        CLAVE_AVATAR_SOTERIA
      );

    if (avatarGuardado) {
      const imagenAvatar =
        document.createElement("img");

      imagenAvatar.className =
        "avatar-chat";

      imagenAvatar.src =
        avatarGuardado;

      fila.appendChild(imagenAvatar);
    }

    fila.appendChild(burbuja);
    if (id !== null && id !== undefined) {
  const botonBorrar =
    document.createElement("button");

  botonBorrar.type = "button";
  botonBorrar.className =
    "boton-borrar-mensaje";
  botonBorrar.textContent = "🗑️";
  botonBorrar.title =
    "Borrar esta respuesta";

  botonBorrar.addEventListener(
  "click",
  async () => {
    try {
      const idBorrar =
        Number(fila.dataset.entradaId);

      /* BORRAR RESPUESTA ANTIGUA */

      await borrarEntradaChat(idBorrar);

      fila.remove();

      /* SOTERIA ESTÁ ESCRIBIENDO */

      const escribiendo =
        document.createElement("div");

      escribiendo.className =
        "mensaje-chat soteria escribiendo";

      escribiendo.textContent =
        "Soteria está escribiendo...";

      mensajes.appendChild(escribiendo);

      mensajes.scrollTop =
        mensajes.scrollHeight;


      /* GENERAR UNA NUEVA RESPUESTA
         DESDE EL PUNTO ACTUAL */

      const nuevaRespuesta =
  await responderIA(
    
    "Continúa desde el punto actual de la conversación. " +
    "La respuesta anterior de Soteria ha sido descartada. " +
    "No reinicies la escena, no vuelvas a saludar y no retrocedas a un turno anterior."
  );

      escribiendo.remove();


      /* GUARDAR RESPUESTA NUEVA */

      const nuevoIdSoteria =
        await guardarEntradaChat({
          tipo: "texto",
          autor: "soteria",
          contenido: nuevaRespuesta,
          fecha: Date.now()
        });


      /* MOSTRAR RESPUESTA NUEVA */

      mostrarMensajeTexto(
  "soteria",
  nuevaRespuesta,
  nuevoIdSoteria
);

      mensajes.scrollTop =
        mensajes.scrollHeight;

    } catch (error) {
      console.error(
        "No se pudo regenerar la respuesta:",
        error
  
      );
    }
  }
);

  fila.appendChild(botonBorrar);
    }
  } else {
    fila.appendChild(burbuja);

    const avatarGuardado =
      localStorage.getItem(
        CLAVE_AVATAR_ACHERON
      );

    if (avatarGuardado) {
      const imagenAvatar =
        document.createElement("img");

      imagenAvatar.className =
        "avatar-chat";

      imagenAvatar.src =
        avatarGuardado;

      fila.appendChild(imagenAvatar);
    }
  }

  mensajes.appendChild(fila);
}


/* =========================
   MENSAJES DE TEXTO
========================= */

/* ENTER = NUEVA LÍNEA */

mensaje.addEventListener(
  "keydown",
  (evento) => {
    if (evento.key === "Enter") {
      evento.preventDefault();

      const inicio =
        mensaje.selectionStart;

      const final =
        mensaje.selectionEnd;

      const textoActual =
        mensaje.value;

      mensaje.value =
        textoActual.slice(0, inicio) +
        "\n" +
        textoActual.slice(final);

      mensaje.selectionStart =
        mensaje.selectionEnd =
          inicio + 1;
    }
  }
);


/* =========================
   BOTÓN ENVIAR = ENVÍA EL MENSAJE
========================= */

formulario.addEventListener(
  "submit",
  async (evento) => {
    evento.preventDefault();

    const texto = mensaje.value.trim();

    if (!texto) return;

    try {
  const idAcheron = await guardarEntradaChat({
    tipo: "texto",
    autor: "acheron",
    contenido: texto,
    fecha: Date.now()
  });

  mostrarMensajeTexto(
    "acheron",
    texto,
    idAcheron
  );
} catch (error) {
  console.error(
    "No se guardó el mensaje de Acheron:",
    error
  );

  mostrarMensajeTexto(
    "acheron",
    texto
  );
    }

    mensaje.value = "";
    registrarPresenciaAshEnCita();
    
const citaDetectada =
  await detectarCompromisoTemporal(texto);

if (
  citaDetectada &&
  citaDetectada.momento
) {
  localStorage.setItem(
    "soteria_cita_pendiente",
    JSON.stringify({
      momento: citaDetectada.momento,
      cita: citaDetectada.cita
    })
  );
}

    /* =========================
       PRIMERA RESPUESTA DE SOTERIA
    ========================= */

    const escribiendo =
      document.createElement("div");

    escribiendo.className =
      "mensaje-chat soteria escribiendo";

    escribiendo.textContent =
      "Soteria está escribiendo...";

    mensajes.appendChild(escribiendo);

    mensajes.scrollTop =
      mensajes.scrollHeight;

    const respuesta =
  await responderIA(texto);

 escribiendo.remove();

    try {
  const idSoteria = await guardarEntradaChat({
    tipo: "texto",
    autor: "soteria",
    contenido: respuesta,
    fecha: Date.now()
  });

  mostrarMensajeTexto(
    "soteria",
    respuesta,
    idSoteria
  );
} catch (error) {
  console.error(
    "No se guardó el mensaje de Soteria:",
    error
  );

  mostrarMensajeTexto(
    "soteria",
    respuesta
  );
    }

    mensajes.scrollTop =
      mensajes.scrollHeight;


    /* =========================
       POSIBLE INICIATIVA DE SOTERIA
    ========================= */

  try {
  /* Iniciativa automática desactivada temporalmente: una sola burbuja por respuesta. */
  const decision = "CALLAR";

  const decisionLimpia =
    String(decision).trim();

  if (
        decisionLimpia
          .toUpperCase()
          .startsWith("HABLAR:")
      ) {
        const segundoMensaje =
          decisionLimpia
            .slice(
              decisionLimpia.indexOf(":") + 1
            )
            .trim();

        if (segundoMensaje) {

          /*
             Pequeña pausa para que el segundo
             mensaje parezca espontáneo y no
             parte de la misma respuesta.
          */

          await new Promise((resolve) => {
            setTimeout(resolve, 1800);
          });

          const escribiendoOtraVez =
            document.createElement("div");

          escribiendoOtraVez.className =
            "mensaje-chat soteria escribiendo";

          escribiendoOtraVez.textContent =
            "Soteria está escribiendo...";

          mensajes.appendChild(
            escribiendoOtraVez
          );

          mensajes.scrollTop =
            mensajes.scrollHeight;

          await new Promise((resolve) => {
            setTimeout(resolve, 900);
          });

          escribiendoOtraVez.remove();

          mostrarMensajeTexto(
            "soteria",
            segundoMensaje
          );

          try {
            await guardarEntradaChat({
              tipo: "texto",
              autor: "soteria",
              contenido: segundoMensaje,
              fecha: Date.now()
            });
          } catch (error) {
            console.error(
              "No se guardó la iniciativa de Soteria:",
              error
            );
          }

          mensajes.scrollTop =
            mensajes.scrollHeight;
        }
      }

    } catch (error) {
      /*
         Si falla solamente la iniciativa,
         NO afecta al chat normal.
      */

      console.error(
        "No se pudo comprobar la iniciativa de Soteria:",
        error
      );
    }
  }
);
      
/* =========================
   CARGAR HISTORIAL
========================= */

async function cargarHistorialCompleto() {
  try {
    const entradas =
      await cargarEntradasChat();

    mensajes.innerHTML = "";

    entradas.forEach((entrada) => {
      if (entrada.tipo === "texto") {
        mostrarMensajeTexto(
          entrada.autor,
          entrada.contenido,
          entrada.id
        );
      }
    });

    mensajes.scrollTop =
      mensajes.scrollHeight;
  } catch (error) {
    console.error(
      "No se pudo cargar el historial:",
      error
    );
  }
}
/* =========================================
   REGRESO DESPUÉS DE UNA AUSENCIA
========================================= */

async function comprobarRegresoTrasAusencia() {
  try {
    const entradas = await cargarEntradasChat();

    if (!entradas || entradas.length === 0) return;

    const ultimaEntrada =
      entradas[entradas.length - 1];

    if (!ultimaEntrada.fecha) return;

    const ahora = Date.now();
    const tiempoAusente =
      ahora - ultimaEntrada.fecha;

    // 6 horas
    const SEIS_HORAS =
      6 * 60 * 60 * 1000;

    if (tiempoAusente < SEIS_HORAS) return;

    const decision = await responderIA(`
Ha pasado tiempo desde la última conversación, pero eso no implica que Ash se haya marchado del lugar. Mantén la ubicación y situación anteriores salvo que el historial indique explícitamente que Ash se fue.

Ten en cuenta cómo terminó realmente la conversación, lo último que ocurrió
entre vosotros y el tiempo que ha pasado si era despues de media noche , ahora es de dia.

Han pasado varias horas desde la última intervención.
Ten en cuenta la hora actual de la escena y deja que el tiempo haya avanzado con naturalidad.
La última intervención fue de ${
  ultimaEntrada.autor === "soteria" ? "Soteria" : "Ash"
}.
Si fue de Soteria, esas palabras eran tuyas: continúa desde ellas y no respondas a tus propias palabras como si fueran de Ash.

Decide tú misma si Soteria tiene algún motivo natural para tomar la iniciativa
ahora que Ash ha regresado.

No se te indica cómo debes sentirte ni cómo debes reaccionar.
Puedes hablar, actuar, preguntar, bromear, enfadarte, mostrar afecto,
ignorar el asunto o reaccionar de cualquier otra forma coherente contigo
y con lo ocurrido.

Si decides no iniciar nada en este momento, responde únicamente:

NO_INICIATIVA
`);

    if (!decision) return;

    const respuesta = decision.trim();

    if (respuesta === "NO_INICIATIVA") return;

    mostrarMensajeTexto(
      "soteria",
      respuesta
    );

    await guardarEntradaChat({
      tipo: "texto",
      autor: "soteria",
      contenido: respuesta,
      fecha: Date.now()
    });

    mensajes.scrollTop =
      mensajes.scrollHeight;

  } catch (error) {
    console.error(
      "No se pudo comprobar el regreso tras la ausencia:",
      error
    );
  }
}
async function comprobarCitaPendiente() {
  try {
    const estadoCita =
      obtenerEstadoCitaPendiente();

    if (
      !estadoCita ||
      !estadoCita.vencida
    ) {
      return;
    }

    const cita = estadoCita.cita;

    const horaCita =
      new Date(
        estadoCita.momentoCita
      ).toLocaleString(
        "es-ES",
        {
          timeZone: "UTC",
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }
      );

    const horaAhora =
      new Date(
        estadoCita.ahoraEscena
      ).toLocaleString(
        "es-ES",
        {
          timeZone: "UTC",
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit"
        }
      );

    const decision =
      await responderIA(`
Había una cita pendiente entre Ash y Soteria.

Lo acordado:
${cita.cita || "Ash había quedado con Soteria."}

Hora acordada:
${horaCita}

Hora actual de la escena:
${horaAhora}

Han pasado más de 30 minutos desde la hora acordada
y Ash no ha hecho presencia.

Decide tú misma si Soteria quiere decir o hacer algo ahora.
No se te indica cómo debes sentirte ni qué debes hacer.
Puedes reaccionar de la forma que resulte natural
o continuar con lo que estabas haciendo, o continuar con lo que estabas haciendo, en el lugar y la escena del momento.

Mantén la continuidad de la escena.
No crees recuerdos ni acontecimientos anteriores
para justificar tu reacción.

Si decides no iniciar nada en este momento, responde únicamente:

NO_INICIATIVA
`);

    if (!decision) return;

    const respuesta =
      decision.trim();

    localStorage.removeItem(
      CLAVE_CITA_PENDIENTE
    );

    if (
      respuesta === "NO_INICIATIVA"
    ) {
      return;
    }

    mostrarMensajeTexto(
      "soteria",
      respuesta
    );

    await guardarEntradaChat({
      tipo: "texto",
      autor: "soteria",
      contenido: respuesta,
      fecha: Date.now()
    });

    mensajes.scrollTop =
      mensajes.scrollHeight;

  } catch (error) {
    console.error(
      "No se pudo comprobar la cita pendiente:",
      error
    );
  }
}

/* =========================================
   ENCHUFE DEL DESPERTADOR
========================================= */

window.addEventListener(
  "DOMContentLoaded",
  () => {
    setTimeout(async () => {
      await comprobarCitaPendiente();
      await comprobarRegresoTrasAusencia();
    }, 1500);

    setInterval(() => {
      comprobarCitaPendiente();
    }, 60 * 1000);
  }
);

cargarHistorialCompleto();
