/* ==========================================================
   CONTEXTO ACHERON — PUENTE DE RELEVANCIA
   ----------------------------------------------------------
   Decide CUÁNDO consultar el libro Acheron y QUÉ buscar.
   NO modifica V21.
   NO responde como Soteria.
   NO inventa hechos.
   Si el libro no es pertinente, devuelve contexto vacío.

   Requiere:
   - Libro_Acheron/acheron_integral_runtime.js
   - lector_acheron.js
   - buscador_acheron.js
========================================================== */

(() => {
  "use strict";

  const CONFIG = Object.freeze({
    workerUrl:
      "https://soteria-deepseek-worker.acheron-parthenopoeus.workers.dev/buscar",
    maxMensajesRecientes: 8,
    maxCaracteresContextoReciente: 4200,
    maxContextoFinal: 8500
  });

  function raizGlobal() {
    return typeof window !== "undefined" ? window : globalThis;
  }

  function limpiarBloquesJson(texto) {
    return String(texto || "")
      .trim()
      .replace(/^```(?:json)?\s*/i, "")
      .replace(/\s*```$/i, "")
      .trim();
  }

  function textoPlano(valor) {
    if (valor === null || valor === undefined) return "";
    return String(valor).trim();
  }

  function normalizarHistorial(historial) {
    if (!Array.isArray(historial)) return [];

    return historial
      .filter(x => x && textoPlano(x.contenido || x.content))
      .slice(-CONFIG.maxMensajesRecientes)
      .map(x => {
        const autor =
          textoPlano(x.autor || x.role).toLowerCase();

        let role = "user";

        if (
          autor === "soteria" ||
          autor === "assistant"
        ) {
          role = "assistant";
        }

        return {
          role,
          content:
            textoPlano(x.contenido || x.content)
        };
      });
  }

  function limitarHistorial(historial) {
    const normalizado =
      normalizarHistorial(historial);

    let total = 0;
    const salida = [];

    for (
      let i = normalizado.length - 1;
      i >= 0;
      i -= 1
    ) {
      const item = normalizado[i];
      const coste = item.content.length + 80;

      if (
        salida.length > 0 &&
        total + coste >
        CONFIG.maxCaracteresContextoReciente
      ) {
        break;
      }

      salida.unshift(item);
      total += coste;
    }

    return salida;
  }

  function formatoEscena(historial) {
    if (!historial.length) {
      return "(sin conversación previa)";
    }

    return historial
      .map(
        x =>
          `${x.role === "assistant" ? "SOTERIA" : "ASH"}:\n${x.content}`
      )
      .join("\n\n");
  }

  function promptDecision(
    mensajeActual,
    historial
  ) {
    const escena =
      formatoEscena(historial);

    return [
      {
        role: "system",
        content:
`Eres un clasificador interno para una aplicación narrativa.

Tu única tarea es decidir si el LIBRO CANÓNICO "ACHERON" debe consultarse para ayudar a Soteria a responder el mensaje actual de Ash.

NO eres Soteria.
NO respondas a Ash.
NO uses conocimiento externo.
NO inventes hechos del libro.
Solo decides relevancia y, si procede, redactas una consulta de recuperación.

Consulta el libro cuando el mensaje actual o la conversación reciente:
- pregunta por hechos, relaciones, diálogos, recuerdos o acontecimientos narrados en ACHERON;
- alude indirectamente a un hecho del libro y hace falta recuperar el contexto;
- compara el presente con un acontecimiento del libro;
- usa pronombres o referencias como "eso", "después", "cuando pasó aquello" y la conversación reciente deja claro que se refiere a ACHERON.

NO consultes el libro cuando:
- sea conversación cotidiana sin relación con el libro;
- sea una acción presente normal;
- la información necesaria ya esté explícita en el mensaje actual y no haga falta recuperar un hecho del libro;
- el tema sea de otra biblioteca o lore no contenido necesariamente en ACHERON.

Si consultas, la "consulta" debe expresar el hecho que realmente hay que encontrar en el libro, no copiar mecánicamente el último mensaje.
Puede usar nombres, relación, acción, lugar o consecuencia que aparezcan en la conversación reciente.

Devuelve ÚNICAMENTE JSON válido:

{
  "consultar": true | false,
  "consulta": string | null,
  "motivo": string
}

"motivo" debe ser muy breve y técnico.
Si consultar=false, consulta debe ser null.`
      },
      {
        role: "user",
        content:
`CONVERSACIÓN RECIENTE:

${escena}

MENSAJE ACTUAL DE ASH:

${mensajeActual}`
      }
    ];
  }

  async function decidir(
    mensajeActual,
    historial = []
  ) {
    const mensaje =
      textoPlano(mensajeActual);

    if (!mensaje) {
      return {
        consultar: false,
        consulta: null,
        motivo: "mensaje vacío"
      };
    }

    const historia =
      limitarHistorial(historial);

    const messages =
      promptDecision(
        mensaje,
        historia
      );

    const respuesta =
      await fetch(
        CONFIG.workerUrl,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            messages
          })
        }
      );

    if (!respuesta.ok) {
      throw new Error(
        "Error del clasificador Acheron: " +
        respuesta.status
      );
    }

    const bruto =
      await respuesta.text();

    const limpio =
      limpiarBloquesJson(bruto);

    let datos;

    try {
      datos = JSON.parse(limpio);
    } catch (error) {
      throw new Error(
        "El clasificador no devolvió JSON válido."
      );
    }

    const consultar =
      datos &&
      datos.consultar === true;

    const consulta =
      consultar
        ? textoPlano(datos.consulta)
        : null;

    if (
      consultar &&
      !consulta
    ) {
      throw new Error(
        "El clasificador pidió consultar Acheron pero no formuló una consulta."
      );
    }

    return {
      consultar,
      consulta,
      motivo:
        textoPlano(datos.motivo) ||
        (
          consultar
            ? "relevancia detectada"
            : "sin relevancia"
        )
    };
  }

  async function prepararContexto(
    mensajeActual,
    historial = [],
    opciones = {}
  ) {
    const raiz =
      raizGlobal();

    if (!raiz.BuscadorAcheron) {
      throw new Error(
        "No está cargado buscador_acheron.js."
      );
    }

    const decision =
      await decidir(
        mensajeActual,
        historial
      );

    if (!decision.consultar) {
      return {
        consultar: false,
        consulta: null,
        motivo: decision.motivo,
        busqueda: null,
        contexto: ""
      };
    }

    const limite =
      Math.max(
        1,
        Math.min(
          Number(opciones.limite) || 3,
          5
        )
      );

    const busqueda =
      await raiz.BuscadorAcheron
        .buscarSemanticoAsync(
          decision.consulta,
          {
            limite
          }
        );

    const contexto =
      raiz.BuscadorAcheron
        .formatearParaIA(
          busqueda,
          Number(opciones.maxCaracteres) ||
            CONFIG.maxContextoFinal
        );

    return {
      consultar: true,
      consulta: decision.consulta,
      motivo: decision.motivo,
      busqueda,
      contexto
    };
  }

  async function contextoParaIA(
    mensajeActual,
    historial = [],
    opciones = {}
  ) {
    const resultado =
      await prepararContexto(
        mensajeActual,
        historial,
        opciones
      );

    return resultado.contexto || "";
  }

  const api = Object.freeze({
    decidir,
    prepararContexto,
    contextoParaIA
  });

  raizGlobal().ContextoAcheron = api;
})();
