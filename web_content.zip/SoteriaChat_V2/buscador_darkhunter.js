/* Buscador local de la Biblioteca Dark-Hunter.
   Búsqueda por entidades primero.
   Máximo 2 resultados y 1800 caracteres totales por consulta.
*/

const DH_STOPWORDS = new Set([
  "a","al","algo","ante","como","con","contra","cual","cuando","de","del","desde",
  "donde","el","ella","ellos","en","entre","era","es","esa","ese","eso","esta",
  "este","esto","fue","ha","hay","la","las","le","les","lo","los","mas","me",
  "mi","muy","no","o","para","pero","por","que","se","si","sin","sobre",
  "su","sus","te","tiene","tu","un","una","unos","unas","y","ya",
  "hoy","ayer","manana","ahora","aqui","ahi","alli","quien","quienes",
  "recuerdas","recuerda","conoces","conoce","encontre","encontrado","encontré",
  "dijo","dice","dime","cuentame","cuéntame","morenaza","morritos"
]);

/* Nombres del mundo personal actual.
   No deben forzarse contra el manual, porque pueden chocar con personajes antiguos.
   Ejemplo: Theron sin "Kafieri" se deja a Recuerdos/Fichas.
*/
const DH_PERSONALES = new Set([
  "bas","sebastos",
  "theri",
  "beth","bethania","bethany"
]);

function dhNormalizar(s){
  return (s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-z0-9ñ\s'-]/g," ")
    .replace(/\s+/g," ")
    .trim();
}

function dhPalabras(s){
  return dhNormalizar(s)
    .split(" ")
    .filter(Boolean);
}
function dhEntidadesMencionadas(consulta){
  const frase = dhNormalizar(consulta);

  if(!frase) return [];

  const encontradas = [];

  function apareceTermino(termino){
    termino = dhNormalizar(termino);

    if(!termino) return false;

    const palabras = dhPalabras(termino);

    return palabras.every(p => {
      if(dhTienePalabra(frase, p)) return true;

      /* Singular/plural sencillo:
         Arcadio <-> Arcadios
         Daimon  <-> Daimons
      */
      if(p.endsWith("s")){
        const singular = p.slice(0,-1);
        if(dhTienePalabra(frase, singular)) return true;
      } else {
        if(dhTienePalabra(frase, p + "s")) return true;
      }

      return false;
    });
  }

  for(const item of DARK_HUNTER_LIBRARY){
    const titulo = dhNormalizar(item.title);

    /* 1. Nombre o título de la ficha */
    if(titulo && apareceTermino(titulo)){
      encontradas.push({
        ...item,
        score: 3000
      });
      continue;
    }

    /*
      2. Categorías escritas dentro del texto.
      Ejemplo:
      Arcadios:
      Katagarios:
      Daimons:
      Demonios Puros:
    */
    const textoOriginal = item.text || "";

    const categorias =
      [...textoOriginal.matchAll(
  /(?:^|[.:\n])\s*([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚáéíóúÑñ'-]*(?:\s+[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚáéíóúÑñ'-]*){0,3})\s*:/g
      )];

    for(const match of categorias){
      const categoria = match[1];

      if(apareceTermino(categoria)){
        encontradas.push({
          ...item,
          score: 2500
        });
        break;
      }
    }
  }

  return encontradas
    .sort((a,b) =>
      b.score - a.score ||
      a.page - b.page
    )
    .filter((item,index,array) =>
      array.findIndex(x => x.id === item.id) === index
    )
    .slice(0,2);
}
function dhTienePalabra(texto, palabra){
  const seguro = palabra.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  return new RegExp(`(?:^|\\s)${seguro}(?:$|\\s)`).test(texto);
}

function dhTerminos(consulta){
  const normal = dhNormalizar(consulta);
  const palabras = normal.split(" ").filter(Boolean);

  const mencionaTheronKafieri =
    normal.includes("theron kafieri") ||
    normal.includes("kafieri theron");

  return [...new Set(
    palabras.filter(w=>{
      if(w.length <= 2) return false;
      if(DH_STOPWORDS.has(w)) return false;

      if(w === "theron" && !mencionaTheronKafieri){
        return false;
      }

      if(DH_PERSONALES.has(w)){
        return false;
      }

      return true;
    })
  )];
}

function dhEsEntradaPobre(item){
  const titulo = dhNormalizar(item.title);
  const texto = dhNormalizar(item.text);

  if(!texto) return true;

  const casiSoloTitulo =
    texto === titulo ||
    texto.length <= titulo.length + 25;

  return casiSoloTitulo && texto.length < 140;
}

function dhPuntuacionFicha(item, terminos){
  const titulo = dhNormalizar(item.title);
  const texto = dhNormalizar(item.text);

  if(!titulo || !texto) return -Infinity;

  const todosEnTitulo =
    terminos.every(t=>dhTienePalabra(titulo,t));

  if(!todosEnTitulo) return -Infinity;

  let score = 700;

  const palabrasTitulo = dhPalabras(titulo);

  if(palabrasTitulo.length <= terminos.length + 2) score += 260;
  if(palabrasTitulo.length <= terminos.length + 5) score += 120;

  for(const t of terminos){
    if(dhTienePalabra(titulo,t)) score += 100;
    if(dhTienePalabra(texto,t)) score += 20;
  }

  if(texto.length >= 180) score += 160;
  if(texto.length >= 350) score += 80;

  if(dhEsEntradaPobre(item)) score -= 500;

  return score;
}

function dhMejorFichaDirecta(terminos){
  if(!terminos.length) return null;

  let mejor = null;

  for(const item of DARK_HUNTER_LIBRARY){
    const score = dhPuntuacionFicha(item,terminos);

    if(
      Number.isFinite(score) &&
      (!mejor ||
       score > mejor.score ||
       (score === mejor.score && item.page < mejor.page))
    ){
      mejor = {...item,score};
    }
  }

  return mejor;
}

function dhEntidadesDirectas(terminos){
  const encontrados = [];
  const usados = new Set();

  /* Primero intenta grupos de 3 y 2 palabras.
     Así "Fury Kattalakis" se trata como una entidad,
     pero "Acheron y Artemisa" puede resolverse por separado.
  */
  for(const tam of [3,2]){
    for(let i=0;i<=terminos.length-tam;i++){
      const indices = [];
      const grupo = [];

      for(let j=0;j<tam;j++){
        const idx = i+j;
        if(usados.has(idx)) break;
        indices.push(idx);
        grupo.push(terminos[idx]);
      }

      if(grupo.length !== tam) continue;

      const ficha = dhMejorFichaDirecta(grupo);

      if(ficha){
        encontrados.push(ficha);
        indices.forEach(idx=>usados.add(idx));

        if(encontrados.length >= 2){
          return encontrados;
        }
      }
    }
  }

  /* Después busca nombres individuales que aparezcan en títulos. */
  for(let i=0;i<terminos.length;i++){
    if(usados.has(i)) continue;

    const ficha = dhMejorFichaDirecta([terminos[i]]);

    if(
      ficha &&
      ficha.score >= 750 &&
      !encontrados.some(x=>x.id===ficha.id)
    ){
      encontrados.push(ficha);
      usados.add(i);

      if(encontrados.length >= 2){
        break;
      }
    }
  }

  return encontrados;
}

function dhPuntuacionGeneral(item,terminos,frase){
  const texto = dhNormalizar(item.text);
  const titulo = dhNormalizar(item.title);
  const seccion = dhNormalizar(item.section);

  let score = 0;

  if(frase && frase.length > 3){
    if(titulo === frase) score += 500;
    else if(titulo.includes(frase)) score += 320;

    if(texto.includes(frase)) score += 110;
  }

  for(const t of terminos){
    if(dhTienePalabra(titulo,t)) score += 150;
    if(dhTienePalabra(seccion,t)) score += 25;

    const seguro = t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
    const n = (texto.match(new RegExp(`\\b${seguro}\\b`,"g")) || []).length;
    score += Math.min(n,8) * 18;
  }

  if(
    terminos.length > 1 &&
    terminos.every(t=>
      dhTienePalabra(texto,t) ||
      dhTienePalabra(titulo,t)
    )
  ){
    score += 120;
  }

  if(item.text && item.text.length >= 180) score += 35;
  if(dhEsEntradaPobre(item)) score -= 220;

  return score;
}

function buscarDarkHunter(
  consulta,
  maxResultados=2,
  maxCaracteres=1800
){
  const frase = dhNormalizar(consulta);
  const terminos = dhTerminos(consulta);
const entidades = dhEntidadesMencionadas(consulta);
  if(!frase) return [];

  const directos = dhEntidadesDirectas(terminos);

  let candidatos = [];

  if(entidades.length){
  candidatos = entidades;
} else if(directos.length){
  candidatos = directos;
} else {
    candidatos = DARK_HUNTER_LIBRARY
      .map(item=>({
        ...item,
        score: dhPuntuacionGeneral(item,terminos,frase)
      }))
      .filter(x=>x.score >= 140)
      .sort((a,b)=>
        b.score-a.score ||
        a.page-b.page
      );
  }

  const salida = [];
  let usados = 0;

  for(const r of candidatos){
    if(salida.length >= maxResultados) break;
    if(salida.some(x=>x.id===r.id)) continue;

    let texto = (r.text || "").trim();

    if(!texto) continue;

    const restante = maxCaracteres-usados;

    if(restante <= 120) break;

    if(texto.length > restante){
      texto =
        texto.slice(0,restante-1)
          .trimEnd() + "…";
    }

    salida.push({
      id:r.id,
      section:r.section,
      page:r.page,
      title:r.title,
      text:texto,
      score:r.score
    });

    usados += texto.length;
  }

  return salida;
}
function contextoDarkHunterParaIA(consulta){
  const rs = buscarDarkHunter(
    consulta,
    2,
    1800
  )

  if(!rs.length) return "";

  return (
  "[BIBLIOTECA DARK-HUNTER]\n" +
  "Para datos del universo de la saga, prioriza estos fragmentos sobre suposiciones o conocimiento general. " +
  "Los Recuerdos y los hechos personales presentes en el contexto tienen prioridad cuando describan vuestra historia personal o actual. " +
  "Si estos fragmentos no bastan para responder un dato de la saga, no lo completes por suposición.\n\n" +
  rs.map(r =>
    `Sección: ${r.section} | pág. ${r.page}\n${r.text}`
  ).join("\n\n")
  );
}