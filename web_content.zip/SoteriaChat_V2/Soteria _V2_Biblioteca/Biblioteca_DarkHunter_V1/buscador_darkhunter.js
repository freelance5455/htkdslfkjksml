/* Buscador local de la Biblioteca Dark-Hunter.
   Máximo 2 resultados y 1800 caracteres totales por consulta. */

const DH_STOPWORDS = new Set([
  "a","al","algo","ante","como","con","contra","cual","cuando","de","del","desde",
  "donde","el","ella","ellos","en","entre","era","es","esa","ese","eso","esta",
  "este","esto","fue","ha","hay","la","las","le","les","lo","los","mas","me",
  "mi","muy","no","o","para","pero","por","que","se","si","sin","sobre",
  "su","sus","te","tiene","tu","un","una","unos","unas","y","ya"
]);

function dhNormalizar(s){
  return (s||"").toLowerCase().normalize("NFD")
    .replace(/[\u0300-\u036f]/g,"")
    .replace(/[^a-z0-9ñ\s'-]/g," ")
    .replace(/\s+/g," ").trim();
}

function dhTerminos(q){
  return [...new Set(dhNormalizar(q).split(" ")
    .filter(w=>w.length>2 && !DH_STOPWORDS.has(w)))];
}

function buscarDarkHunter(consulta,maxResultados=2,maxCaracteres=1800){
  const frase=dhNormalizar(consulta);
  const terminos=dhTerminos(consulta);
  if(!frase || !terminos.length) return [];

  const puntuados=DARK_HUNTER_LIBRARY.map(item=>{
    const texto=dhNormalizar(item.text);
    const titulo=dhNormalizar(item.title);
    const seccion=dhNormalizar(item.section);
    let score=0;

    // Una entrada cuyo título contiene todos los términos es casi siempre la ficha correcta.
    if(terminos.every(t=>titulo.includes(t))) score+=420;
    if(titulo===frase) score+=300;
    if(titulo.includes(frase)) score+=220;
    if(texto.includes(frase)) score+=80;

    for(const t of terminos){
      if(titulo.includes(t)) score+=90;
      if(seccion.includes(t)) score+=20;

      const seguro=t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
      const n=(texto.match(new RegExp(`\\b${seguro}\\b`,"g"))||[]).length;
      score+=Math.min(n,8)*10;
    }

    if(terminos.every(t=>texto.includes(t)||titulo.includes(t))) score+=70;
    return {...item,score};
  }).filter(x=>x.score>0)
    .sort((a,b)=>b.score-a.score || a.page-b.page);

  const salida=[];
  let usados=0;
  for(const r of puntuados){
    if(salida.length>=maxResultados) break;
    if(salida.some(x=>x.id===r.id)) continue;

    let texto=r.text.trim();
    const restante=maxCaracteres-usados;
    if(restante<=120) break;
    if(texto.length>restante)
      texto=texto.slice(0,restante-1).trimEnd()+"…";

    salida.push({
      id:r.id,section:r.section,page:r.page,title:r.title,text:texto,score:r.score
    });
    usados+=texto.length;
  }
  return salida;
}

function contextoDarkHunterParaIA(consulta){
  const rs=buscarDarkHunter(consulta,2,1800);
  if(!rs.length) return "";
  return "[BIBLIOTECA DARK-HUNTER]\n"+
    rs.map(r=>`Sección: ${r.section} | pág. ${r.page}\n${r.text}`).join("\n\n");
}
