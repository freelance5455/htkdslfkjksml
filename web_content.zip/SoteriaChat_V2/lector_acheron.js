/* ==========================================================
   LECTOR ACHERON — CAPA INDEPENDIENTE
   ----------------------------------------------------------
   Lee el libro maestro sin modificarlo.
   NO es el buscador definitivo.
   NO clasifica escenas, personajes ni temas.

   Orden de carga:
   1) Puente JS generado desde el libro maestro.
   2) Como respaldo, intenta leer el .md por HTTP.
========================================================== */

(() => {
  "use strict";

  const RUTA_LIBRO_PREDETERMINADA =
    "Libro_Acheron/ACHERON_INTEGRAL.md";

  let estado = crearEstadoVacio();

  function crearEstadoVacio() {
    return {
      cargado: false,
      ruta: "",
      texto: "",
      lineas: [],
      encabezados: [],
      cargadoEn: null
    };
  }

  function normalizarSaltos(texto) {
    return String(texto || "")
      .replace(/^\uFEFF/, "")
      .replace(/\r\n?/g, "\n");
  }

  function construirEncabezados(texto) {
    const lineas = texto.split("\n");
    const encabezados = [];
    let posicion = 0;

    for (let i = 0; i < lineas.length; i += 1) {
      const linea = lineas[i];
      const coincidencia = linea.match(/^(#{1,6})\s+(.+?)\s*$/);

      if (coincidencia) {
        encabezados.push({
          nivel: coincidencia[1].length,
          titulo: coincidencia[2],
          linea: i + 1,
          inicio: posicion,
          finEncabezado: posicion + linea.length
        });
      }

      posicion += linea.length + 1;
    }

    for (let i = 0; i < encabezados.length; i += 1) {
      const actual = encabezados[i];
      let fin = texto.length;

      for (let j = i + 1; j < encabezados.length; j += 1) {
        if (encabezados[j].nivel <= actual.nivel) {
          fin = encabezados[j].inicio;
          break;
        }
      }

      actual.finSeccion = fin;
    }

    return encabezados;
  }

  function validarLibro(texto, encabezados) {
    const primero = encabezados[0];

    if (!texto.trim()) {
      throw new Error("El archivo del libro está vacío.");
    }

    if (
      !primero ||
      primero.nivel !== 1 ||
      primero.titulo.trim().toUpperCase() !== "ACHERON"
    ) {
      throw new Error(
        "El archivo no parece ser ACHERON_INTEGRAL.md: " +
        "falta el encabezado principal '# ACHERON'."
      );
    }

    const tieneParteI = encabezados.some(
      h => h.titulo.trim().toLowerCase() === "parte i"
    );

    const tieneParteII = encabezados.some(
      h => h.titulo.trim().toLowerCase() === "parte ii"
    );

    if (!tieneParteI || !tieneParteII) {
      throw new Error(
        "El libro se cargó, pero no se reconocieron Parte I y Parte II."
      );
    }
  }

  function cargarTexto(texto, origen = "texto proporcionado") {
    const limpio = normalizarSaltos(texto);
    const encabezados = construirEncabezados(limpio);

    validarLibro(limpio, encabezados);

    estado = {
      cargado: true,
      ruta: origen,
      texto: limpio,
      lineas: limpio.split("\n"),
      encabezados,
      cargadoEn: new Date()
    };

    return obtenerResumen();
  }

  function cargarDesdePuente() {
    const raiz =
      typeof window !== "undefined" ? window : globalThis;

    const fuente = raiz.AcheronFuenteIntegral;

    if (
      !fuente ||
      typeof fuente.texto !== "string" ||
      !fuente.texto.trim()
    ) {
      return null;
    }

    return cargarTexto(
      fuente.texto,
      "puente JS: Libro_Acheron/acheron_integral_runtime.js"
    );
  }

  async function cargarPorHttp(
    ruta = RUTA_LIBRO_PREDETERMINADA,
    tiempoMaximoMs = 6000
  ) {
    const controlador =
      typeof AbortController !== "undefined"
        ? new AbortController()
        : null;

    let temporizador = null;

    if (controlador) {
      temporizador = setTimeout(
        () => controlador.abort(),
        tiempoMaximoMs
      );
    }

    try {
      const respuesta = await fetch(ruta, {
        method: "GET",
        cache: "no-store",
        signal: controlador ? controlador.signal : undefined
      });

      if (!respuesta.ok) {
        throw new Error(
          "HTTP " + respuesta.status + " al pedir '" + ruta + "'."
        );
      }

      const texto = await respuesta.text();
      return cargarTexto(texto, ruta);

    } finally {
      if (temporizador) {
        clearTimeout(temporizador);
      }
    }
  }

  async function cargar(ruta = RUTA_LIBRO_PREDETERMINADA) {
    const desdePuente = cargarDesdePuente();

    if (desdePuente) {
      return desdePuente;
    }

    try {
      return await cargarPorHttp(ruta);
    } catch (error) {
      throw new Error(
        "No se pudo cargar Acheron automáticamente. " +
        "No se encontró el puente JS y también falló la lectura del .md. " +
        "Detalle: " + error.message
      );
    }
  }

  function exigirLibro() {
    if (!estado.cargado) {
      throw new Error(
        "El libro aún no está cargado. Ejecuta LectorAcheron.cargar() primero."
      );
    }
  }

  function obtenerResumen() {
    exigirLibro();

    const capitulos = estado.encabezados.filter(
      h => /^CAPÍTULO\s+/i.test(h.titulo.trim())
    );

    const porNivel = {};
    estado.encabezados.forEach(h => {
      porNivel[h.nivel] = (porNivel[h.nivel] || 0) + 1;
    });

    return {
      ruta: estado.ruta,
      caracteres: estado.texto.length,
      lineas: estado.lineas.length,
      encabezados: estado.encabezados.length,
      encabezadosPorNivel: porNivel,
      capitulosParteII: capitulos.length,
      cargadoEn: estado.cargadoEn
    };
  }

  function obtenerIndiceEstructural() {
    exigirLibro();

    return estado.encabezados.map((h, indice) => ({
      indice,
      nivel: h.nivel,
      titulo: h.titulo,
      linea: h.linea
    }));
  }

  function buscarEncabezadosExactos(titulo) {
    exigirLibro();

    const objetivo =
      String(titulo || "").trim().toLocaleLowerCase("es");

    return estado.encabezados
      .map((h, indice) => ({ ...h, indice }))
      .filter(
        h => h.titulo.trim().toLocaleLowerCase("es") === objetivo
      );
  }

  function extraerSeccionPorIndice(indiceEncabezado, opciones = {}) {
    exigirLibro();

    const h = estado.encabezados[indiceEncabezado];
    if (!h) return null;

    const incluirEncabezado =
      opciones.incluirEncabezado !== false;

    const desde =
      incluirEncabezado ? h.inicio : h.finEncabezado;

    return {
      titulo: h.titulo,
      nivel: h.nivel,
      linea: h.linea,
      texto: estado.texto
        .slice(desde, h.finSeccion)
        .trim()
    };
  }

  function obtenerSeccion(titulo, ocurrencia = 1, opciones = {}) {
    const coincidencias =
      buscarEncabezadosExactos(titulo);

    const posicion =
      Math.max(1, Number(ocurrencia) || 1) - 1;

    const elegido = coincidencias[posicion];

    if (!elegido) return null;

    return extraerSeccionPorIndice(
      elegido.indice,
      opciones
    );
  }

  function obtenerCapituloParteII(numero, opciones = {}) {
    exigirLibro();

    const capitulos = estado.encabezados
      .map((h, indice) => ({ ...h, indice }))
      .filter(
        h => /^CAPÍTULO\s+/i.test(h.titulo.trim())
      );

    const n = Number(numero);

    if (
      !Number.isInteger(n) ||
      n < 1 ||
      n > capitulos.length
    ) {
      return null;
    }

    return extraerSeccionPorIndice(
      capitulos[n - 1].indice,
      opciones
    );
  }

  function localizarFraseLiteral(
    frase,
    caracteresAntes = 900,
    caracteresDespues = 1500
  ) {
    exigirLibro();

    const aguja = String(frase || "").trim();
    if (!aguja) return null;

    const textoMinusculas =
      estado.texto.toLocaleLowerCase("es");

    const agujaMinusculas =
      aguja.toLocaleLowerCase("es");

    const posicion =
      textoMinusculas.indexOf(agujaMinusculas);

    if (posicion === -1) return null;

    const inicio =
      Math.max(0, posicion - caracteresAntes);

    const fin =
      Math.min(
        estado.texto.length,
        posicion + aguja.length + caracteresDespues
      );

    const linea =
      estado.texto
        .slice(0, posicion)
        .split("\n").length;

    return {
      frase: estado.texto.slice(
        posicion,
        posicion + aguja.length
      ),
      posicion,
      linea,
      texto: estado.texto
        .slice(inicio, fin)
        .trim()
    };
  }

  function estaCargado() {
    return estado.cargado;
  }

  function obtenerRutaPredeterminada() {
    return RUTA_LIBRO_PREDETERMINADA;
  }

  const api = Object.freeze({
    cargar,
    cargarTexto,
    cargarDesdePuente,
    estaCargado,
    obtenerRutaPredeterminada,
    obtenerResumen,
    obtenerIndiceEstructural,
    buscarEncabezadosExactos,
    obtenerSeccion,
    obtenerCapituloParteII,
    localizarFraseLiteral
  });

  const raiz =
    typeof window !== "undefined" ? window : globalThis;

  raiz.LectorAcheron = api;
})();
