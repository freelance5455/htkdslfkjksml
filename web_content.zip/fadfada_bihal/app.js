const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let mode="solve", chats=JSON.parse(localStorage.getItem("fb_chats")||"[]"), current=[];
const replies={
 general:{solve:["أفهم أن الموضوع يشغلك. خلّنا نفككه بهدوء: ما أكثر جزء يسبب لك القلق الآن؟","شكراً لأنك شاركتني. جرّب كتابة الخيارات المتاحة أمامك، ثم نرتبها حسب الأسهل والأكثر فائدة. ما أول خطوة صغيرة تقدر تسويها اليوم؟"],listen:["أنا أسمعك، خذ وقتك واكتب كل اللي في خاطرك بدون ترتيب أو أحكام. وش صار معك؟"]},
 work:{solve:["واضح أن موضوع العمل ضاغط عليك. خلّنا نحدد المشكلة: هل هي مع المدير، ضغط المهام، بيئة العمل، أو البحث عن فرصة أفضل؟","خلّنا نحول الموضوع لخطة عملية. اكتب لي المسمى الوظيفي الذي تستهدفه، وما أهم عائق تواجهه حالياً؟"],listen:["أحياناً العمل يأخذ من طاقتنا كثير. أنا هنا أسمعك؛ احكِ لي وش صار في العمل اليوم."]},
 family:{solve:["العلاقات الأسرية تحتاج هدوء وفهم للطرفين. ما الذي حدث تحديداً، وما النتيجة التي تتمنى الوصول لها؟","قد يساعد أن تختار وقتاً هادئاً وتتكلم عن شعورك دون اتهام. ما العبارة التي تتمنى أن يفهمها الطرف الآخر؟"],listen:["خذ راحتك، الأمور الأسرية قد تكون حساسة. احكِ لي بالقدر الذي ترتاح له، وأنا أسمعك."]},
 money:{solve:["الضغوط المالية تصبح أوضح عندما نكتب الأرقام. هل المشكلة في الدخل، الالتزامات، الديون، أم عدم انتظام المصروف؟","نقدر نبدأ بميزانية بسيطة: الدخل الشهري، المصاريف الضرورية، والالتزامات. ما أكبر بند يضغط عليك؟"],listen:["أعرف أن الحديث عن المال قد يكون متعباً. اكتب ما يقلقك، ولن نحكم عليك."]},
 stress:{solve:["يبدو أنك تمر بضغط. خذ نفساً بطيئاً، وحاول تسمية الشيء الذي يثقل عليك الآن. هل هو موقف محدد أم تراكم أمور؟","خلّنا نختار خطوة بسيطة الآن: ابتعد دقائق عن مصدر التوتر، اشرب ماء، ثم اكتب ما تستطيع التحكم فيه وما لا تستطيع. ما أكثر فكرة تتكرر عندك؟"],listen:["أنا معك وأسمعك. لا تحتاج أن ترتب كلامك أو تجد حلاً الآن؛ اكتب ما تشعر به كما هو."]}
};
function save(){localStorage.setItem("fb_chats",JSON.stringify(chats))}
function show(page){$$(".screen").forEach(x=>x.classList.toggle("active",x.id===page));$$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===page));if(page==="history")renderHistory();if(page==="chat")setTimeout(()=>$("#entry").focus(),100)}
function add(text,who){let el=document.createElement("div");el.className="bubble "+who;el.textContent=text;$("#messages").append(el);$("#messages").scrollTop=$("#messages").scrollHeight;current.push({text,who})}
function begin(){current=[];$("#messages").innerHTML="";add("أهلاً بك 🌿 خذ راحتك، أنا هنا للاستماع. ما الذي يشغل بالك اليوم؟","bot");show("chat")}
function send(){let v=$("#entry").value.trim();if(!v)return;add(v,"user");$("#entry").value="";let t=$("#topic").value;let pool=replies[t][mode];let answer=pool[Math.floor(Math.random()*pool.length)];setTimeout(()=>{add(answer,"bot");chats.unshift({date:new Date().toLocaleString("ar-SA"),topic:$("#topic option:checked").textContent,preview:v.slice(0,65),messages:current.slice()});chats=chats.slice(0,30);save()},450)}
$("#send").onclick=send;$("#entry").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("#startChat").onclick=begin;$$('[data-mode="ai"]').forEach(b=>b.onclick=begin);
$$(".tile").forEach(b=>b.onclick=()=>{let m=b.dataset.mode;if(m==="ai")begin();else if(m==="history")show("history");else if(m==="plans")alert("هذه نسخة تجريبية مجانية. الاشتراكات والدفع غير مفعّلين.");else alert("ميزة البحث عن صاحب خبرة ستضاف في إصدار لاحق.")});
$$(".nav").forEach(b=>b.onclick=()=>{if(b.dataset.page==="chat"&&!$("#chat").classList.contains("active"))begin();else show(b.dataset.page)});
$("#historyBtn").onclick=()=>show("history");$("#historyBack").onclick=()=>show("home");$("#backHome").onclick=()=>show("home");$("#newFromHistory").onclick=begin;
$$(".mode").forEach(b=>b.onclick=()=>{mode=b.dataset.kind;$$(".mode").forEach(x=>x.classList.toggle("selected",x===b))});
$("#clearChat").onclick=()=>{if(confirm("هل تريد مسح المحادثة الحالية؟"))begin()};
function renderHistory(){let box=$("#historyList");box.innerHTML="";if(!chats.length){box.innerHTML='<div class="card" style="padding:25px;text-align:center;color:#718096">لا توجد محادثات محفوظة حتى الآن.</div>';return}chats.forEach(c=>{let b=document.createElement("button");b.className="history-item";b.innerHTML=`<b>${c.topic}</b><br><small>${c.date}</small><p>${c.preview}</p>`;b.onclick=()=>{current=c.messages||[];$("#messages").innerHTML="";current.forEach(m=>add(m.text,m.who));show("chat")};box.append(b)})}
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
