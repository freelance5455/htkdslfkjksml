AKS Travel Manager
==================

Android / Windows: extract this ZIP and open index.html in a modern browser.

Features:
- Travel booking records
- Optional toll plaza fee per booking: choose Yes to add a toll amount to the customer total, or No to exclude it
- Toll amount is shown separately on the A4 payment receipt and added to total due only when enabled
- AKS Travel logo and A4 payment receipt with watermark
- Vehicle servicing and reminders
- Local backup export and restore

Important:
- Data is stored locally in the browser on this device. It does not automatically sync between devices.
- Export a backup regularly before updating or clearing browser data.
- Test with dummy data before entering real customer details.
- Toll is excluded by default. For a booking that should include toll, select “हाँ — टोल शामिल करें” and enter the amount.
