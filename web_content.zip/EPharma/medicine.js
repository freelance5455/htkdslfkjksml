document.addEventListener("DOMContentLoaded", function () {
    // Kunin ang mga HTML elements
    const medicineFormPanel = document.getElementById("medicineFormPanel");
    const medicineForm = document.getElementById("medicineForm");
    const showFormBtn = document.getElementById("showFormBtn");
    const cancelBtn = document.getElementById("cancelBtn");
    const searchInput = document.getElementById("searchInput");
    const medicineTable = document.getElementById("medicineTable");
    const message = document.getElementById("message");
    const emptyMessage = document.getElementById("emptyMessage");

    // Summary cards
    const totalCount = document.getElementById("totalCount");
    const lowCount = document.getElementById("lowCount");
    const expiredCount = document.getElementById("expiredCount");
    const soonCount = document.getElementById("soonCount");

    // Form inputs
    const medicineId = document.getElementById("medicineId");
    const medicineName = document.getElementById("medicineName");
    const category = document.getElementById("category");
    const price = document.getElementById("price");
    const quantity = document.getElementById("quantity");
    const threshold = document.getElementById("threshold");
    const expiryDate = document.getElementById("expiryDate");

    // Kunin ang saved medicines sa browser
    let medicines = [];

    try {
        const savedMedicines = localStorage.getItem("ePharmaMedicines");
        medicines = savedMedicines ? JSON.parse(savedMedicines) : [];

        if (!Array.isArray(medicines)) {
            medicines = [];
        }
    } catch (error) {
        medicines = [];
    }

    // I-save ang medicines sa browser
    function saveMedicines() {
        try {
            localStorage.setItem(
                "ePharmaMedicines",
                JSON.stringify(medicines)
            );
            return true;
        } catch (error) {
            showMessage("Unable to save data in this browser.", "error");
            return false;
        }
    }

    // Magpakita ng message
    function showMessage(text, type = "success") {
        message.textContent = text;
        message.className = type;
        message.style.display = "block";

        setTimeout(function () {
            message.style.display = "none";
        }, 3000);
    }

    // Ipakita ang form
    showFormBtn.addEventListener("click", function () {
        medicineForm.reset();
        medicineId.value = "";
        medicineFormPanel.style.display = "block";
        medicineName.focus();
    });

    // Itago ang form
    cancelBtn.addEventListener("click", function () {
        medicineForm.reset();
        medicineId.value = "";
        medicineFormPanel.style.display = "none";
    });

    // I-check ang status ng medicine
    function getMedicineStatus(medicine) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const expiry = new Date(medicine.expiryDate + "T00:00:00");
        const daysUntilExpiry = Math.ceil(
            (expiry - today) / (1000 * 60 * 60 * 24)
        );

        if (daysUntilExpiry < 0) {
            return {
                text: "Expired",
                className: "status-expired"
            };
        }

        if (daysUntilExpiry <= 30) {
            return {
                text: "Expiring Soon",
                className: "status-soon"
            };
        }

        if (Number(medicine.quantity) <= Number(medicine.threshold)) {
            return {
                text: "Low Stock",
                className: "status-low"
            };
        }

        return {
            text: "In Stock",
            className: "status-ok"
        };
    }

    // Gumawa ng safe HTML text para maiwasan ang HTML injection
    function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, function (character) {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };
            return entities[character];
        });
    }

    // Ipakita ang medicine inventory sa table
    function renderMedicines() {
        const searchText = searchInput.value.trim().toLowerCase();

        const filteredMedicines = medicines.filter(function (medicine) {
            return (
                medicine.name.toLowerCase().includes(searchText) ||
                medicine.category.toLowerCase().includes(searchText)
            );
        });

        medicineTable.innerHTML = "";

        filteredMedicines.forEach(function (medicine) {
            const status = getMedicineStatus(medicine);
            const row = document.createElement("tr");

        const nameCell = document.createElement("td");
nameCell.textContent = medicine.name;

const categoryCell = document.createElement("td");
categoryCell.textContent = medicine.category;

const priceCell = document.createElement("td");
priceCell.textContent = "₱" + Number(medicine.price).toFixed(2);

const quantityCell = document.createElement("td");
quantityCell.textContent = medicine.quantity;

const expiryCell = document.createElement("td");
expiryCell.textContent = medicine.expiryDate;

const statusCell = document.createElement("td");
const statusSpan = document.createElement("span");
statusSpan.className = status.className;
statusSpan.textContent = status.text;
statusCell.appendChild(statusSpan);

const actionCell = document.createElement("td");

const editButton = document.createElement("button");
editButton.type = "button";
editButton.className = "action-btn edit-btn";
editButton.dataset.action = "edit";
editButton.dataset.id = medicine.id;
editButton.textContent = "Edit";

const deleteButton = document.createElement("button");
deleteButton.type = "button";
deleteButton.className = "action-btn delete-btn";
deleteButton.dataset.action = "delete";
deleteButton.dataset.id = medicine.id;
deleteButton.textContent = "Delete";

actionCell.appendChild(editButton);
actionCell.appendChild(deleteButton);

row.appendChild(nameCell);
row.appendChild(categoryCell);
row.appendChild(priceCell);
row.appendChild(quantityCell);
row.appendChild(expiryCell);
row.appendChild(statusCell);
row.appendChild(actionCell);

medicineTable.appendChild(row);
;

            medicineTable.appendChild(row);
        });

        // Ipakita kung walang search result
        emptyMessage.style.display =
            filteredMedicines.length === 0 ? "block" : "none";

        // I-update ang summary cards
        updateSummary();
    }

    // I-update ang total, low stock, expired at expiring soon
    function updateSummary() {
        totalCount.textContent = medicines.length;

        lowCount.textContent = medicines.filter(function (medicine) {
            return (
                Number(medicine.quantity) <= Number(medicine.threshold) &&
                getMedicineStatus(medicine).text !== "Expired"
            );
        }).length;

        expiredCount.textContent = medicines.filter(function (medicine) {
            return getMedicineStatus(medicine).text === "Expired";
        }).length;

        soonCount.textContent = medicines.filter(function (medicine) {
            return getMedicineStatus(medicine).text === "Expiring Soon";
        }).length;
    }

    // Mag-add o mag-update ng medicine
    medicineForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const name = medicineName.value.trim();
        const medicineCategory = category.value.trim();
        const medicinePrice = Number(price.value);
        const medicineQuantity = Number(quantity.value);
        const medicineThreshold = Number(threshold.value);
        const medicineExpiry = expiryDate.value;

        // Validation
        if (
            !name ||
            !medicineCategory ||
            !medicineExpiry ||
            price.value.trim() === "" ||
            quantity.value.trim() === "" ||
            threshold.value.trim() === ""
        ) {
            showMessage("Please fill in all fields.", "error");
            return;
        }

        if (
            !Number.isFinite(medicinePrice) ||
            !Number.isFinite(medicineQuantity) ||
            !Number.isFinite(medicineThreshold) ||
            medicinePrice < 0 ||
            medicineQuantity < 0 ||
            medicineThreshold < 0 ||
            !Number.isInteger(medicineQuantity) ||
            !Number.isInteger(medicineThreshold)
        ) {
            showMessage(
                "Enter a valid price, quantity, and stock threshold.",
                "error"
            );
            return;
        }
        const existingMedicine = medicines.find(function (medicine) {
            return String(medicine.id) === String(medicineId.value);
        });

        if (medicineId.value && !existingMedicine) {
            showMessage("Medicine record not found.", "error");
            return;
        }

        const medicineData = {
            id: medicineId.value || String(Date.now()),
            name: name,
            category: medicineCategory,
            price: medicinePrice,
            quantity: medicineQuantity,
            threshold: medicineThreshold,
            expiryDate: medicineExpiry
        };

        if (medicineId.value) {
            // Update existing medicine
            medicines = medicines.map(function (medicine) {
                return String(medicine.id) === String(medicineId.value)
                    ? medicineData
                    : medicine;
            });
        } else {
            // Add new medicine
            medicines.push(medicineData);
        }

        if (!saveMedicines()) {
            return;
        }

        renderMedicines();
        medicineForm.reset();
        medicineId.value = "";
        medicineFormPanel.style.display = "none";

        showMessage(
            existingMedicine
                ? "Medicine updated successfully!"
                : "Medicine added successfully!"
        );
    });

    // Edit at Delete buttons
    medicineTable.addEventListener("click", function (event) {
        const button = event.target.closest("button[data-action]");

        if (!button) return;

        const id = button.dataset.id;
        const action = button.dataset.action;

        const medicine = medicines.find(function (item) {
            return String(item.id) === String(id);
        });

        if (!medicine) return;

        if (action === "edit") {
            medicineId.value = medicine.id;
            medicineName.value = medicine.name;
            category.value = medicine.category;
            price.value = medicine.price;
            quantity.value = medicine.quantity;
            threshold.value = medicine.threshold;
            expiryDate.value = medicine.expiryDate;

            medicineFormPanel.style.display = "block";
            medicineName.focus();
        }

        if (action === "delete") {
            const confirmed = confirm(
                "Are you sure you want to delete " +
                medicine.name +
                "?"
            );

            if (!confirmed) return;

            const previousMedicines = medicines;

            medicines = medicines.filter(function (item) {
                return String(item.id) !== String(id);
            });

            if (!saveMedicines()) {
                medicines = previousMedicines;
                return;
            }

            renderMedicines();
            showMessage("Medicine deleted successfully!");
        }
    });

    // Search medicines habang nagta-type
    searchInput.addEventListener("input", renderMedicines);

    // Initial display
    renderMedicines();
});
