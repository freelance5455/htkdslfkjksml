document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");

    console.log("Login form:", loginForm);

    if (!loginForm) {
        alert("Hindi makita ang loginForm!");
        return;
    }

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const username = document.getElementById("username");
        const password = document.getElementById("password");

        if (!username || !password) {
            alert("Hindi makita ang username o password input!");
            return;
        }

        console.log("Login button submitted!");

        if (
            username.value.trim() === "admin" &&
            password.value === "admin123"
        ) {
          
            window.location.href = "./dashboard.html";
        } else {
            alert("Mali ang username o password.");
        }
    });
});