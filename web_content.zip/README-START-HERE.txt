RESTAURANT DZ — UPDATED CATEGORY IMAGE + DAILY ORDERS CHART

Contents:
- index.html: updated application.
- assets/category-all.webp: generated professional food image for the "الكل" category.
- RESTAURANT-DZ-SUPABASE-FINAL.sql: same database script included in the previous package.
- videos/: existing tutorial files.

Deployment:
Upload/extract the FULL ZIP contents to the same hosting project, preserving the assets/ and videos/ folders.
Do not upload only index.html; the category image is stored in assets/category-all.webp.

Changes:
1) The "الكل" category now uses the bundled local WebP image, including after Supabase categories load.
2) Owner statistics chart now shows the number of orders per day for the latest seven calendar days, using orders.created_at. Demo preview orders are distributed across the week only while sandbox preview mode is active.
3) The sales and estimated-profit cards remain unchanged.

No database schema or SQL changes are required for these two UI changes.
