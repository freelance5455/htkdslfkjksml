from pathlib import Path
p=Path('/tmp/dlfix/index.html'); s=p.read_text()
s=s.replace('                    <a href="customers.html" onclick="closeSiteMenu()" class="block px-4 py-3 rounded-xl hover:bg-indigo-50 font-semibold">👥 Customer Logs</a>\n','')
s=s.replace('            <div class="mt-8 bg-white p-6 rounded-3xl shadow-sm border flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div><h3 class="text-xl font-bold">Customer Logs</h3><p class="text-sm text-slate-500">View active logs and customers added today on a separate page.</p></div><a href="customers.html" class="inline-block text-center bg-indigo-600 text-white px-5 py-3 rounded-xl font-bold">Open Customer Logs →</a></div>','')
needle='            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">'
insert='''            <div class="bg-white border shadow-sm rounded-2xl p-4 mb-6">\n                <h3 class="font-black text-lg mb-3">☰ Admin Menu</h3>\n                <div class="flex flex-wrap gap-2">\n                    <a href="products.html" class="bg-slate-100 hover:bg-indigo-50 px-4 py-2 rounded-xl text-sm font-bold">📦 Products & Categories</a>\n                    <a href="customers.html" class="bg-purple-600 text-white px-4 py-2 rounded-xl text-sm font-bold">👥 Customer Logs</a>\n                    <a href="results.html" class="bg-slate-100 hover:bg-indigo-50 px-4 py-2 rounded-xl text-sm font-bold">🏆 Past Results</a>\n                </div>\n                <p class="text-xs text-slate-500 mt-2">Customer Logs includes Active Customers, Added Today (active and inactive), and All Logs.</p>\n            </div>\n\n'''
s=s.replace(needle,insert+needle); p.write_text(s)
c=Path('/tmp/dlfix/customers.html'); s=c.read_text()
s=s.replace('<th class="p-3">Status</th></tr>', '<th class="p-3">Status</th><th class="p-3">Action</th></tr>')
s=s.replace('colspan="11"', 'colspan="12"')
old='''<td class="p-3"><span class="rounded-full px-2 py-1 text-xs font-bold ${isActive(c)?'bg-green-100 text-green-700':'bg-slate-100 text-slate-600'}">${isActive(c)?'Active':'Inactive'}</span></td></tr>'''
new='''<td class="p-3"><span class="rounded-full px-2 py-1 text-xs font-bold ${isActive(c)?'bg-green-100 text-green-700':'bg-slate-100 text-slate-600'}">${isActive(c)?'Active':'Inactive'}</span></td><td class="p-3"><button onclick="deleteCustomer('${safe(c.id)}')" class="bg-red-600 hover:bg-red-700 text-white rounded-lg px-3 py-2 text-xs font-bold">Delete</button></td></tr>'''
assert old in s, 'row pattern missing'
s=s.replace(old,new)
s=s.replace('function render(){',"async function deleteCustomer(id){if(!confirm('Delete this customer log? This cannot be undone.'))return;try{await db.collection('customers').doc(id).delete();document.getElementById('status').textContent='Customer log deleted successfully.';}catch(e){alert('Could not delete customer log: '+e.message);}}\nfunction render(){")
c.write_text(s)
