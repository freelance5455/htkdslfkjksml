create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Qais Workspace',
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'employee' check (role in ('owner','employee')),
  active boolean not null default true,
  joined_at timestamptz not null default now(),
  primary key(workspace_id,user_id)
);
create table if not exists public.workspace_join_codes (
  code text primary key,
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.workspace_data (
  workspace_id uuid primary key references public.workspaces(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.workspace_join_codes enable row level security;
alter table public.workspace_data enable row level security;

create or replace function public.is_workspace_member(p_workspace uuid)
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.workspace_members where workspace_id=p_workspace and user_id=auth.uid() and active);
$$;
create or replace function public.is_workspace_owner(p_workspace uuid)
returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.workspace_members where workspace_id=p_workspace and user_id=auth.uid() and role='owner' and active);
$$;

create policy "members read workspaces" on public.workspaces for select using (public.is_workspace_member(id));
create policy "members read members" on public.workspace_members for select using (public.is_workspace_member(workspace_id));
create policy "members read data" on public.workspace_data for select using (public.is_workspace_member(workspace_id));
create policy "members write data" on public.workspace_data for insert with check (public.is_workspace_member(workspace_id));
create policy "members update data" on public.workspace_data for update using (public.is_workspace_member(workspace_id)) with check (public.is_workspace_member(workspace_id));

create or replace function public.ensure_my_workspace()
returns jsonb language plpgsql security definer set search_path=public as $$
declare w record; m record;
begin
 select wm.workspace_id, wm.role, ws.name into m from workspace_members wm join workspaces ws on ws.id=wm.workspace_id where wm.user_id=auth.uid() and wm.active limit 1;
 if m.workspace_id is null then
   insert into workspaces(owner_id) values(auth.uid()) returning * into w;
   insert into workspace_members(workspace_id,user_id,role) values(w.id,auth.uid(),'owner');
   insert into workspace_data(workspace_id,data) values(w.id,'{"docs":[],"sheets":[],"contacts":[],"notes":[],"vault":{"pin":"","text":""},"settings":{"name":"Qais Workspace"}}'::jsonb);
   return jsonb_build_object('workspace_id',w.id,'role','owner','workspace_name',w.name);
 end if;
 return jsonb_build_object('workspace_id',m.workspace_id,'role',m.role,'workspace_name',m.name);
end; $$;

create or replace function public.create_workspace_join_code(p_workspace_id uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare c text;
begin
 if not public.is_workspace_owner(p_workspace_id) then raise exception 'فقط مدیر اصلی اجازه ساخت کد دارد'; end if;
 c := 'QWS-' || upper(substr(encode(gen_random_bytes(5),'hex'),1,6));
 insert into workspace_join_codes(code,workspace_id) values(c,p_workspace_id);
 return jsonb_build_object('code',c);
end; $$;

create or replace function public.join_workspace_by_code(p_code text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare c record; w record;
begin
 select * into c from workspace_join_codes where code=upper(trim(p_code)) and active limit 1;
 if c.code is null then raise exception 'کد ورود معتبر نیست'; end if;
 select * into w from workspaces where id=c.workspace_id;
 insert into workspace_members(workspace_id,user_id,role,active) values(c.workspace_id,auth.uid(),'employee',true)
 on conflict (workspace_id,user_id) do update set active=true,role='employee';
 return jsonb_build_object('workspace_id',w.id,'role','employee','workspace_name',w.name);
end; $$;

create or replace function public.list_workspace_members(p_workspace_id uuid)
returns table(user_id uuid,email text,role text,active boolean)
language sql security definer set search_path=public as $$
 select wm.user_id, coalesce(au.email,''), wm.role, wm.active from workspace_members wm join auth.users au on au.id=wm.user_id where wm.workspace_id=p_workspace_id and public.is_workspace_member(p_workspace_id) order by wm.role desc, au.email;
$$;

create or replace function public.remove_workspace_member(p_workspace_id uuid,p_user_id uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
 if not public.is_workspace_owner(p_workspace_id) then raise exception 'فقط مدیر اصلی اجازه حذف دارد'; end if;
 if p_user_id=auth.uid() then raise exception 'مدیر اصلی را نمی‌توان حذف کرد'; end if;
 update workspace_members set active=false where workspace_id=p_workspace_id and user_id=p_user_id;
end; $$;
