// اجرا: node tools/get-map.mjs   (یک‌بار، با اینترنت)
// نقشهٔ کشورهای جهان (Natural Earth از طریق world-atlas) را در پوشهٔ data ذخیره می‌کند تا بازی آفلاین هم کار کند.
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
const src = {
  low:  'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json',
  high: 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json'
};
const out = {};
for (const [k, url] of Object.entries(src)) {
  console.log('دریافت', url);
  const r = await fetch(url);
  if (!r.ok) throw new Error(url + ' -> ' + r.status);
  const text = await r.text();
  fs.writeFileSync(path.join(dir, `countries-${k === 'low' ? '110m' : '50m'}.json`), text);
  out[k] = JSON.parse(text);
}
fs.writeFileSync(path.join(dir, 'world-data.js'), 'window.WORLD_TOPO = ' + JSON.stringify(out) + ';\n');
console.log('تمام شد. حالا index.html را باز کنید (بدون نیاز به اینترنت).');
