# اجرا: python3 tools/get-map.py   (یک‌بار، با اینترنت)
import json, os, urllib.request
d = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data')
src = {'low': ('110m', 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json'),
       'high': ('50m', 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json')}
out = {}
for k, (n, url) in src.items():
    print('دریافت', url)
    txt = urllib.request.urlopen(url, timeout=60).read().decode('utf-8')
    open(os.path.join(d, f'countries-{n}.json'), 'w', encoding='utf-8').write(txt)
    out[k] = json.loads(txt)
open(os.path.join(d, 'world-data.js'), 'w', encoding='utf-8').write('window.WORLD_TOPO = ' + json.dumps(out) + ';\n')
print('تمام شد.')
