#!/bin/sh
cd "$(dirname "$0")"
(node serve.mjs || python3 -m http.server 8080)
