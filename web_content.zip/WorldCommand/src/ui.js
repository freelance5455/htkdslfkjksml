/* فرمان جهان — رابط کاربری v2 */
(function (WC) {
  const $ = id => document.getElementById(id);
  const fa = WC.fa, U = WC.UNITS, T = WC.TYPES, SH = WC.SHIPS, ST = WC.SHIP_TYPES, BL = WC.BUILDINGS;
  const UI = WC.UI = { sel: -1, selFleet: -1, frac: 0.75, ffrac: 1, orderMode: true, mode: 'menu', menuPick: -1, diff: 'normal', qty: 1 };
  const R = WC.R, g = () => WC.game;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt1 = v => (Math.round(v * 10) / 10).toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]).replace('.', '٫');
  const pips = (v, max) => '<span class="pips">' + Array.from({ length: max }, (_, i) => `<i class="${i < v ? 'f' : ''}"></i>`).join('') + '</span>';
  const dot = n => `<span class="badge" style="background:${n.css.fill};width:16px;height:16px"></span>`;
  const RES = { oil: 'نفت', mine: 'معدن', farm: 'کشاورزی', none: '—' };

  UI.toast = function (msg, kind) {
    const d = document.createElement('div'); d.className = 'toast ' + (kind || ''); d.textContent = msg;
    const box = $('toasts'); box.appendChild(d); while (box.children.length > 4) box.firstChild.remove(); setTimeout(() => d.remove(), 4200);
  };
  let modalOnClose = null;
  UI.openModal = function (html, mount) { $('modal-body').innerHTML = html; $('modal').hidden = false; if (mount) mount($('modal-body')); };
  UI.closeModal = function () { $('modal').hidden = true; $('modal-body').innerHTML = ''; UI.openKind = null; if (modalOnClose) { const f = modalOnClose; modalOnClose = null; f(); } };
  UI.modalOpen = () => !$('modal').hidden;
  function confirmBox(msg, yes, no, cls) {
    return new Promise(res => {
      UI.openModal(`<div class="center"><p style="font-size:16px;line-height:2;margin:14px 0 20px">${msg}</p><div class="row2" style="justify-content:center"><button class="btn ${cls || ''}" data-r="1">${yes}</button><button class="btn sec" data-r="0">${no}</button></div></div>`,
        el => el.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { const v = b.dataset.r === '1'; modalOnClose = null; UI.closeModal(); res(v); }));
      modalOnClose = () => res(false);
    });
  }
  UI.confirm = confirmBox;

  function relTag(a, b) {
    const G = WC.G, r = g().rel(a, b);
    if (r.state === 'war') return '<span class="tag war">در جنگ</span>';
    if (r.state === 'ally') return '<span class="tag ally">متحد</span>';
    if (G.turn < r.truce) return '<span class="tag truce">آتش‌بس</span>';
    return '<span class="tag peace">صلح</span>';
  }

  // ---------- نوار بالا ----------
  UI.refreshHud = function () {
    const G = WC.G; if (!G || G.player < 0) return;
    const n = G.nations[G.player], b = g().budget(n.id);
    $('h-badge').style.background = n.css.fill; $('h-name').textContent = n.name;
    $('h-money').textContent = fa(n.money); $('h-income').textContent = (b.net >= 0 ? '+' : '') + fa(b.net); $('h-income').style.color = b.net >= 0 ? 'var(--peace)' : 'var(--war)';
    $('h-prov').textContent = fa(g().ownedProvs(n.id).length) + ' / ' + fa(G.provinces.length);
    $('h-power').textContent = WC.compactFa(g().natPower(n.id)); $('h-turn').textContent = fa(G.turn);
    $('offer-dot').hidden = G.offers.length === 0; $('endturn').disabled = G.busy || G.over;
  };

  // ---------- انتخاب ----------
  UI.select = function (id, quiet) { UI.sel = id; UI.selFleet = -1; R.selected = id; R.selFleet = -1; R.pathPreview = null; UI.computeTargets(); UI.renderPanel(); if (id >= 0 && !quiet) WC.audio.play('click'); };
  UI.selectFleet = function (id) { UI.selFleet = id; R.selFleet = id; UI.sel = -1; R.selected = -1; R.targets.clear(); R.linksFor = -1; R.pathPreview = null; UI.renderPanel(); WC.audio.play('click'); };
  UI.computeTargets = function () {
    R.targets.clear(); R.linksFor = -1;
    const G = WC.G; if (!G || G.player < 0 || UI.sel < 0 || !UI.orderMode) return;
    const p = G.provinces[UI.sel];
    if (p.owner !== G.player || p.acted || G.busy || g().totalUnits(p.units) < 1) return;
    R.linksFor = p.id;
    p.neighbors.forEach(l => {
      const q = G.provinces[l.to]; let kind;
      if (q.owner === G.player || g().allied(G.player, q.owner)) kind = 'move'; else if (g().atWar(G.player, q.owner)) kind = 'attack'; else kind = 'war';
      if (l.sea && (!p.port || p.ships.trans < 1)) kind = 'blocked';
      R.targets.set(q.id, kind);
    });
  };

  function garrison(p, exact) {
    return '<div class="gar">' + T.map(t => { let v = p.units[t]; if (!exact && v >= 10) v = Math.round(v / 5) * 5; return `<span><i style="background:${U[t].color}"></i>${U[t].fa}</span><span class="n">${!exact && p.units[t] >= 10 ? '≈' : ''}${fa(v)}</span>`; }).join('') + '</div>';
  }
  function generalLine(p) {
    if (!p.general) return '';
    return `<div class="kv"><span>فرمانده</span><b>${esc(g().rankName(p.general))} ${esc(p.general.name)} ${'★'.repeat(p.general.skill)}</b></div>`;
  }

  UI.renderPanel = function () {
    const G = WC.G, el = $('panel');
    if (!G || G.player < 0) { el.hidden = true; return; }
    if (UI.selFleet >= 0) return renderFleet(el);
    if (UI.sel < 0) { el.hidden = true; return; }
    const p = G.provinces[UI.sel], c = G.countries[p.c], o = G.nations[p.owner], me = G.player, mine = p.owner === me, my = G.nations[me];
    const yld = g().provYield(p, o), inc = Math.round(g().provIncome(p));
    let h = `<h3>${esc(p.name)}${p.isCap ? ' <span class="cap">★ پایتخت</span>' : ''}</h3><div class="sub">${dot(o)}<span>${mine ? 'قلمرو شما' : esc(o.name)}</span>${mine ? '' : relTag(me, p.owner)}${p.owner !== p.c ? `<span class="mute">· ${esc(c.fa)}</span>` : ''}</div>`;
    h += `<div class="row2" style="margin-bottom:8px"><button class="btn sm sec" data-act="nation" data-id="${p.owner}">اطلاعات کشور و رهبر</button></div>`;
    h += `<div class="kv"><span>اقتصاد</span>${pips(p.eco, 10)}</div><div class="kv"><span>درآمد استان</span><b>+${fa(inc)}</b></div>`;
    h += `<div class="kv"><span>منبع اصلی</span><b>${RES[p.resType]}</b></div>`;
    if (p.owner !== p.c) h += `<div class="kv"><span>بهره‌وری (ادغام)</span><b>${fa(Math.round(g().occF(p) * 100))}٪</b></div>`;
    if (p.blockade > 0) h += '<div class="note" style="color:#f08a76">⚓ بندر در محاصرهٔ دریایی است</div>';
    if (p.irr > 0) h += `<div class="note" style="color:#ffd24a">☢ آلوده به پرتو اتمی (${fa(p.irr)} نوبت)</div>`;
    h += '<h4>نیروهای زمینی</h4>' + garrison(p, mine) + generalLine(p);
    if (p.port && (g().shipCount(p.ships) > 0 || mine)) h += '<h4>ناوگان در بندر</h4><div class="gar">' + ST.map(t => `<span>${SH[t].fa}</span><span class="n">${fa(p.ships[t])}</span>`).join('') + '</div>';
    if (mine) {
      const room = g().prodCap(p) - p.rec;
      h += `<h4>سربازگیری <small class="mute">(ظرفیت: ${fa(room)})</small></h4><div class="row2">${[1, 5, 10].map(q => `<button class="chip ${UI.qty === q ? 'on' : ''}" data-qty="${q}">×${fa(q)}</button>`).join('')}</div><div class="rec">` +
        T.map(t => `<button data-rec="${t}" ${my.money < U[t].cost || room <= 0 ? 'disabled' : ''}><b>${U[t].fa}</b><small>${fa(U[t].cost)} 💰 · حمله ${fmt1(U[t].atk)}</small></button>`).join('') + '</div>';
      if (p.port) {
        const sroom = g().shipCap(p) - p.srec;
        h += `<h4>بندر و کشتی‌سازی <small class="mute">(ظرفیت: ${fa(sroom)})</small></h4><div class="rec">` +
          ST.map(t => `<button data-ship="${t}" ${my.money < SH[t].cost || sroom <= 0 ? 'disabled' : ''}><b>${SH[t].fa}</b><small>${fa(SH[t].cost)} 💰${SH[t].cap ? ' · ظرفیت ' + fa(SH[t].cap) : ' · حمله ' + fmt1(SH[t].atk)}</small></button>`).join('') + '</div>';
        if (g().warCount(p.ships) > 0) h += `<div class="row2" style="margin-top:8px"><button class="chip ${UI.ffrac === 0.5 ? 'on' : ''}" data-ffrac="0.5">نصف ناوگان</button><button class="chip ${UI.ffrac === 1 ? 'on' : ''}" data-ffrac="1">همهٔ ناوگان</button><button class="btn sm" data-act="sendfleet">اعزام ناوگان به دریا</button></div>`;
      }
      h += '<h4>ساخت‌وساز</h4>';
      Object.keys(BL).forEach(k => {
        if (k === 'port' && !p.port) return; const b = BL[k], lvl = p.bld[k], cost = b.cost * (lvl + 1), full = lvl >= b.max;
        h += `<div class="bl"><div><b>${b.fa}</b> ${pips(lvl, b.max)}<small>${b.desc}</small></div><button class="btn sm sec" data-bld="${k}" ${full || p.built || my.money < cost ? 'disabled' : ''}>${full ? 'کامل' : fa(cost) + ' 💰'}</button></div>`;
      });
      h += '<h4>فرمان</h4>';
      if (p.acted) h += '<div class="note">این استان در این نوبت فرمان داده است.</div>';
      else if (g().totalUnits(p.units) < 1) h += '<div class="note">نیرویی ندارید؛ سربازگیری کنید.</div>';
      else {
        h += `<div class="row2">${[0.25, 0.5, 0.75, 1].map(f => `<button class="chip ${UI.frac === f ? 'on' : ''}" data-frac="${f}">${fa(f * 100)}٪</button>`).join('')}</div>`;
        h += `<div class="orderbar">${UI.orderMode ? 'روی استان درخشان نقشه بزنید: قرمز = حمله، سبز = انتقال، نارنجی = نیازمند اعلان جنگ. عبور از دریا ناو ترابری می‌خواهد.' : 'حالت فرمان خاموش است.'}</div><div class="row2" style="margin-top:8px"><button class="btn sm sec" data-act="toggle-order">${UI.orderMode ? 'خاموش‌کردن حالت فرمان' : 'روشن‌کردن حالت فرمان'}</button></div>`;
      }
    } else {
      h += '<h4>دیپلماسی</h4><div class="row2">';
      const r = g().rel(me, p.owner);
      if (r.state === 'war') h += `<button class="btn sm sec" data-dip="peace" data-id="${p.owner}">درخواست آتش‌بس</button>`;
      else if (r.state === 'ally') h += `<button class="btn sm sec" data-dip="break" data-id="${p.owner}">لغو اتحاد</button>`;
      else h += `<button class="btn sm sec" data-dip="ally" data-id="${p.owner}">پیشنهاد اتحاد</button><button class="btn sm danger" data-dip="war" data-id="${p.owner}" ${G.turn < r.truce ? 'disabled' : ''}>اعلان جنگ</button>`;
      h += '</div>';
      if (r.state === 'war' && my.tech.nuke) h += `<h4>سلاح راهبردی</h4><button class="btn sm danger" data-act="nuke" ${my.nukeCd > 0 || my.money < g().NUKE_COST ? 'disabled' : ''}>حملهٔ اتمی (${fa(g().NUKE_COST)} 💰)</button><div class="note">${my.nukeCd > 0 ? 'آماده‌سازی: ' + fa(my.nukeCd) + ' نوبت' : 'نیروها ۸۰٪ نابود می‌شوند و جهان خشمگین می‌شود.'}</div>`;
      if (r.state !== 'ally') h += '<div class="note">برای حمله، یکی از استان‌های همسایهٔ خودتان را انتخاب کنید.</div>';
    }
    el.innerHTML = h; el.hidden = false;
  };

  function renderFleet(el) {
    const G = WC.G, f = G.fleets.find(x => x.id === UI.selFleet);
    if (!f) { UI.selFleet = -1; R.selFleet = -1; el.hidden = true; return; }
    const mine = f.owner === G.player, o = G.nations[f.owner];
    let h = `<h3>ناوگان ${esc(o.name)}</h3><div class="sub">${dot(o)}<span>${mine ? 'ناوگان شما' : esc(o.name)}</span>${mine ? '' : relTag(G.player, f.owner)}</div>`;
    h += '<h4>ترکیب</h4><div class="gar">' + ST.map(t => `<span>${SH[t].fa}</span><span class="n">${fa(f.ships[t])}</span>`).join('') + '</div>';
    h += `<div class="kv"><span>قدرت دریایی</span><b>${fa(g().shipPower(f.ships))}</b></div>`;
    if (mine) {
      if (f.path) h += `<div class="note">در مسیر · حدود ${fa(Math.ceil((f.path.length - f.pi) / g().FLEET_SPEED))} نوبت تا مقصد${f.dockTo >= 0 ? ' (پهلوگیری)' : ''}</div>`;
      h += '<div class="orderbar">برای حرکت، روی دریا بزنید. روی بندر خودی = پهلوگیری، روی بندر دشمن در جنگ = محاصره و گلوله‌باران. ناوگان در حرکتش با کشتی‌های دشمن می‌جنگد و کشتی‌های تجاری را شکار می‌کند.</div>';
      h += '<div class="row2" style="margin-top:8px"><button class="btn sm" data-act="fleet-home">بازگشت به نزدیک‌ترین بندر</button><button class="btn sm sec" data-act="fleet-stop">توقف</button></div>';
    }
    el.innerHTML = h; el.hidden = false;
  }

  $('panel').addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return; const G = WC.G, d = b.dataset;
    if (d.qty) { UI.qty = +d.qty; UI.renderPanel(); return; }
    if (d.frac) { UI.frac = +d.frac; WC.audio.play('click'); UI.renderPanel(); return; }
    if (d.ffrac) { UI.ffrac = +d.ffrac; UI.renderPanel(); return; }
    if (d.rec) { const r = g().recruit(UI.sel, d.rec, UI.qty); if (!r.ok) { UI.toast(r.msg, 'bad'); WC.audio.play('error'); } UI.computeTargets(); return; }
    if (d.ship) { const r = g().buildShip(UI.sel, d.ship, UI.qty); if (!r.ok) { UI.toast(r.msg, 'bad'); WC.audio.play('error'); } return; }
    if (d.bld) { const r = g().build(UI.sel, d.bld); if (!r.ok) { UI.toast(r.msg, 'bad'); WC.audio.play('error'); } else WC.audio.play('research'); return; }
    if (d.act === 'toggle-order') { UI.orderMode = !UI.orderMode; UI.computeTargets(); UI.renderPanel(); return; }
    if (d.act === 'nation') { UI.showNation(+d.id); return; }
    if (d.act === 'sendfleet') {
      const r = g().sendFleet(UI.sel, UI.ffrac, true);
      if (!r.ok) { UI.toast(r.msg, 'bad'); return; }
      UI.toast('ناوگان آمادهٔ حرکت است؛ روی دریا یا بندر مقصد بزنید.', 'good'); WC.audio.play('move'); UI.selectFleet(r.fleet.id); return;
    }
    if (d.act === 'fleet-home' || d.act === 'fleet-stop') {
      const f = G.fleets.find(x => x.id === UI.selFleet); if (!f) return;
      if (d.act === 'fleet-stop') { f.path = null; f.pi = 0; f.dockTo = -1; R.pathPreview = null; UI.renderPanel(); return; }
      const ports = g().ownedProvs(G.player).filter(p => p.port).sort((a, b2) => g().cellDist(a.port.cell, g().fleetCell(f)) - g().cellDist(b2.port.cell, g().fleetCell(f)));
      if (!ports.length) { UI.toast('بندری ندارید.', 'bad'); return; }
      const r = g().fleetMove(f.id, { prov: ports[0].id }); UI.toast(r.ok ? 'بازگشت به ' + ports[0].name : r.msg, r.ok ? 'good' : 'bad'); UI.renderPanel(); return;
    }
    if (d.act === 'nuke') {
      if (await confirmBox('حملهٔ اتمی به ' + esc(G.provinces[UI.sel].name) + '؟<br><small class="mute">تمام جهان علیه شما خواهد شد.</small>', 'شلیک', 'انصراف', 'danger')) { const r = g().nuke(UI.sel); if (!r.ok) UI.toast(r.msg, 'bad'); }
      return;
    }
    if (d.dip) dipAction(d.dip, +d.id);
  });

  async function dipAction(kind, id) {
    const G = WC.G, me = G.player;
    if (kind === 'war') {
      if (!await confirmBox('به ' + esc(G.nations[id].name) + ' اعلان جنگ می‌کنید؟<br><small class="mute">متحدان آن‌ها ممکن است به جنگ بپیوندند.</small>', 'اعلان جنگ', 'انصراف', 'danger')) return;
      const r = g().declareWar(me, id); if (!r.ok) UI.toast(r.msg, 'bad');
    } else if (kind === 'break') g().breakAlliance(me, id);
    else { const r = g().propose(kind, id); UI.toast(r.msg, r.ok ? 'good' : 'bad'); WC.audio.play(r.ok ? 'peace' : 'error'); }
    UI.computeTargets(); UI.renderPanel(); UI.refreshHud();
    if (UI.openKind === 'diplo' && UI.modalOpen()) UI.showDiplo();
  }

  // ---------- کلیک روی نقشه ----------
  UI.onMapClick = async function (h) {
    WC.audio.init();
    if (UI.mode === 'menu') { if (h && h.prov) UI.menuSelect(h.prov.c, true); return; }
    const G = WC.G; if (!G || G.busy || UI.modalOpen()) return;
    if (h && h.right) { UI.select(-1); return; }
    if (h.fleet) { if (h.fleet.owner === G.player) UI.selectFleet(h.fleet.id); else UI.toast('ناوگان ' + G.nations[h.fleet.owner].name, ''); return; }
    // دستور به ناوگان
    if (UI.selFleet >= 0) {
      const f = G.fleets.find(x => x.id === UI.selFleet);
      if (f) {
        let r;
        if (h.prov && h.prov.port) r = g().fleetMove(f.id, { prov: h.prov.id });
        else if (h.cell) r = g().fleetMove(f.id, { cell: h.cell });
        else if (h.prov && !h.prov.port) { UI.select(h.prov.id); return; }
        if (r) { if (r.ok) { UI.toast('دستور حرکت صادر شد (' + fa(r.eta) + ' نوبت)', 'good'); WC.audio.play('move'); R.pathPreview = f.path; UI.renderPanel(); } else { UI.toast(r.msg, 'bad'); WC.audio.play('error'); } return; }
      }
    }
    if (!h.prov) { UI.select(-1); return; }
    if (UI.sel >= 0 && UI.orderMode && R.targets.has(h.prov.id)) { await doOrder(UI.sel, h.prov.id, R.targets.get(h.prov.id)); return; }
    UI.select(h.prov.id);
  };
  async function doOrder(srcId, dstId, kind) {
    const G = WC.G, src = G.provinces[srcId], dst = G.provinces[dstId];
    if (kind === 'blocked') { UI.toast('برای عبور از دریا ناو ترابری در بندر این استان لازم است.', 'bad'); WC.audio.play('error'); return; }
    if (kind === 'war') {
      const r = g().rel(G.player, dst.owner);
      if (r.state === 'ally') { UI.toast('با ' + G.nations[dst.owner].name + ' متحد هستید.', 'bad'); return; }
      if (G.turn < r.truce) { UI.toast('آتش‌بس تا نوبت ' + fa(r.truce) + ' برقرار است.', 'bad'); WC.audio.play('error'); return; }
      if (!await confirmBox('به ' + esc(G.nations[dst.owner].name) + ' اعلان جنگ می‌کنید و ' + esc(dst.name) + ' را می‌زنید؟', 'اعلان جنگ و حمله', 'انصراف', 'danger')) return;
      const w = g().declareWar(G.player, dst.owner); if (!w.ok) { UI.toast(w.msg, 'bad'); return; }
    } else if (kind === 'move') {
      if (!await confirmBox(`انتقال ${fa(UI.frac * 100)}٪ نیروها از ${esc(src.name)} به ${esc(dst.name)}؟`, 'انتقال', 'فقط انتخاب')) { UI.select(dstId); return; }
    }
    const res = g().order(srcId, dstId, UI.frac, 'player');
    if (!res.ok) { UI.toast(res.msg, 'bad'); WC.audio.play('error'); }
    UI.computeTargets(); UI.renderPanel(); UI.refreshHud();
  }

  UI.onHover = function (p, x, y) {
    const tt = $('tooltip'), G = WC.G;
    if (!p || !G) { tt.hidden = true; return; }
    const o = G.nations[p.owner], c = G.countries[p.c];
    let h = `<b>${esc(p.name)}</b>`; if (p.owner !== p.c) h += ` <small class="mute">(${esc(c.fa)})</small>`;
    h += `<br><small class="mute">${esc(o.name)}</small> · قدرت: ${fa(g().unitPower(p.units))}`;
    if (G.player >= 0 && p.owner !== G.player) h += `<br>${relTag(G.player, p.owner)}`;
    tt.innerHTML = h; tt.hidden = false; tt.style.left = Math.min(window.innerWidth - 250, x + 16) + 'px'; tt.style.top = Math.min(window.innerHeight - 90, y + 16) + 'px';
  };

  // ---------- منوی شروع ----------
  UI.showMenu = function () {
    UI.mode = 'menu'; ['hud', 'panel', 'endturn', 'zoom'].forEach(i => $(i).hidden = true); $('menu').hidden = false; R.targets.clear(); R.linksFor = -1; R.pathPreview = null;
    WC.newGame(WC.countries, WC.provs, -1, UI.diff); UI.fillMenuList('');
    const first = WC.countries.find(c => c.name === 'Iran') || WC.countries[0]; UI.menuSelect(first.id, true);
  };
  UI.fillMenuList = function (q) {
    const ul = $('m-list'), G = WC.G; q = q.trim().toLowerCase();
    const list = WC.countries.filter(c => !q || c.fa.includes(q) || c.name.toLowerCase().includes(q)).sort((a, b) => (b.mil * 2 + b.econ) - (a.mil * 2 + a.econ) || a.fa.localeCompare(b.fa, 'fa'));
    ul.innerHTML = list.map(c => `<li data-id="${c.id}" class="${c.id === UI.menuPick ? 'on' : ''}" tabindex="0">${dot(G.nations[c.id])}<span>${esc(c.fa)}</span><span class="pw">${'★'.repeat(Math.max(1, Math.round((c.mil + c.econ) / 4)))}</span></li>`).join('');
  };
  UI.menuSelect = function (cid, fly) {
    UI.menuPick = cid; const c = WC.countries[cid], G = WC.G, n = G.nations[cid];
    R.selected = c.provs[0];
    $('m-list').querySelectorAll('li').forEach(li => li.classList.toggle('on', +li.dataset.id === cid));
    const on = $('m-list').querySelector('li.on'); if (on) on.scrollIntoView({ block: 'nearest' });
    if (fly) R.focusCountry(c, 0.55);
    const ports = c.provs.filter(pid => WC.provs[pid].port).length, ps = g().ownedProvs(cid);
    const tot = {}; T.forEach(t => tot[t] = ps.reduce((a, p) => a + p.units[t], 0)); const ships = ps.reduce((a, p) => a + g().shipCount(p.ships), 0);
    const diffs = Object.entries(g().DIFF).map(([k, v]) => `<button data-diff="${k}" class="${UI.diff === k ? 'on' : ''}">${v.label}</button>`).join('');
    $('m-card').innerHTML = `<h2>${esc(c.fa)}</h2><div class="en">${esc(c.name)}</div>
      <div class="grid">
        <div class="cell"><small>قدرت نظامی</small>${pips(c.mil, 10)}</div><div class="cell"><small>اقتصاد</small>${pips(c.econ, 10)}</div>
        <div class="cell"><small>حکومت</small><b>${WC.GOVS[n.gov].fa}</b></div><div class="cell"><small>${esc(n.leader.title)}</small><b>${esc(n.leader.name)}</b></div>
        <div class="cell"><small>استان‌ها / بنادر</small><b>${fa(c.provs.length)} / ${fa(ports)}</b></div><div class="cell"><small>درآمد هر نوبت</small><b>+${fa(g().natIncome(cid))}</b></div>
      </div>
      <div class="hint">نیروی آغازین: ${T.filter(t => tot[t] > 0).map(t => U[t].fa + ' ' + fa(tot[t])).join('، ')}${ships ? '، ناوگان ' + fa(ships) : ''}</div>
      <div class="hint" style="margin-top:8px">سطح دشواری</div><div class="seg">${diffs}</div>
      <div class="row"><button class="btn" id="m-start">شروع نبرد</button>${g().hasSave() ? '<button class="btn sec" id="m-continue">ادامهٔ بازی</button>' : ''}<button class="btn sec" id="m-help">راهنما</button></div>`;
  };
  $('m-list').addEventListener('click', e => { const li = e.target.closest('li'); if (li) { WC.audio.init(); UI.menuSelect(+li.dataset.id, true); } });
  $('m-search').addEventListener('input', e => UI.fillMenuList(e.target.value));
  $('m-card').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return; WC.audio.init(); WC.audio.play('click');
    if (b.dataset.diff) { UI.diff = b.dataset.diff; UI.menuSelect(UI.menuPick, false); }
    else if (b.id === 'm-start') UI.startGame(UI.menuPick); else if (b.id === 'm-continue') UI.continueGame(); else if (b.id === 'm-help') UI.showHelp();
  });
  UI.enterGameMode = function () { UI.mode = 'game'; $('menu').hidden = true; ['hud', 'endturn', 'zoom'].forEach(i => $(i).hidden = false); UI.sel = -1; UI.selFleet = -1; R.selected = -1; UI.refreshHud(); };
  UI.startGame = function (cid) {
    UI.goFullscreen();
    g().clearSave(); WC.newGame(WC.countries, WC.provs, cid, UI.diff); UI.enterGameMode();
    const n = WC.G.nations[cid]; UI.select(n.capital, true); R.focusCountry(WC.countries[cid], 0.8);
    WC.audio.play('turn'); UI.toast(`${n.leader.title} ${n.leader.name}، فرماندهی با شماست!`, 'big'); g().save();
  };
  UI.continueGame = function () {
    UI.goFullscreen();
    if (!g().load(WC.countries, WC.provs)) { UI.toast('ذخیره‌ای سازگار با این نقشه پیدا نشد.', 'bad'); return; }
    UI.enterGameMode(); const G = WC.G; UI.select(G.nations[G.player].capital, true); R.focusCountry(G.countries[G.player], 0.8); UI.toast('بازی بارگذاری شد — نوبت ' + fa(G.turn), 'big');
  };

  // ---------- پنجره‌ها ----------
  UI.showNation = function (nid) {
    UI.openKind = 'nation'; const G = WC.G, n = G.nations[nid], gv = WC.GOVS[n.gov], tr = WC.TRAITS[n.leader.trait], mine = nid === G.player;
    const gens = g().ownedProvs(nid).filter(p => p.general).sort((a, b) => b.general.skill - a.general.skill).slice(0, 6);
    const modTxt = Object.entries(gv.mods).map(([k, v]) => ({ atk: 'حمله', def: 'دفاع', inc: 'درآمد', trade: 'تجارت', tax: 'مالیات', recruit: 'سربازگیری' }[k] + ' ' + (v > 0 ? '+' : '−') + fa(Math.abs(v) * 100) + '٪')).join('، ');
    let h = `<h2>${esc(n.name)}</h2><div class="leader"><div class="portrait" style="background:${n.css.fill}">${['monarchy', 'absmon', 'emirate'].includes(n.gov) ? '♛' : '★'}</div><div><b style="font-size:17px">${esc(n.leader.title)} ${esc(n.leader.name)}</b><br><span class="tag ally">${tr.fa}</span> <small class="mute">${tr.desc}</small></div></div>`;
    h += `<div class="kv"><span>نظام حکومتی</span><b>${gv.fa}</b></div><div class="note">${modTxt}</div>`;
    h += `<div class="kv"><span>ثبات سیاسی</span><b>${fa(n.stab)}٪</b></div><div class="kv"><span>پایتخت</span><b>${esc(G.provinces[n.capital].name)}</b></div><div class="kv"><span>استان‌ها</span><b>${fa(g().ownedProvs(nid).length)}</b></div><div class="kv"><span>قدرت</span><b>${fa(g().natPower(nid))}</b></div>`;
    h += '<h4 style="margin-top:14px;color:var(--brass);font-size:13px">فرماندهان ارتش</h4>' + (gens.length ? gens.map(p => `<div class="item"><span style="width:20px;color:#ffd24a">${'★'.repeat(p.general.skill)}</span><div class="grow"><b>${esc(g().rankName(p.general))} ${esc(p.general.name)}</b><small>${esc(p.name)} · قدرت ${fa(g().unitPower(p.units))}</small></div></div>`).join('') : '<div class="hint">فرماندهٔ شناخته‌شده‌ای نیست.</div>');
    h += '<div class="note" style="margin-top:12px">نام رهبران و فرماندهان ساختگی است و برای بازی تولید شده.</div>';
    UI.openModal(h);
  };
  UI.showEcon = function () {
    UI.openKind = 'econ'; const G = WC.G, n = G.nations[G.player], b = g().budget(n.id), tax = ['کم', 'متعادل', 'سنگین'];
    const row = (k, v, cls) => `<div class="kv"><span>${k}</span><b class="${cls || ''}">${v >= 0 ? '' : '−'}${fa(Math.abs(v))}</b></div>`;
    let h = `<h2>اقتصاد و بودجه</h2><div class="kv"><span>خزانه</span><b>${fa(n.money)} 💰</b></div>`;
    h += '<h4 class="sec">درآمدها</h4>' + row('مالیات و جمعیت', b.tax) + row('صنعت و تولید', b.ind) + row('نفت، معدن و کشاورزی', b.res) + row('تجارت و بنادر', b.trade);
    h += `<div class="kv"><span>ضریب حکومت و رهبر</span><b>×${fmt1(b.mult)}</b></div>` + row('کشتی‌های تجاری این دور', b.ships, 'good');
    h += '<h4 class="sec">هزینه‌ها</h4>' + row('نگهداری ارتش', -b.army) + row('نگهداری ناوگان', -b.navy) + row('اداره کشور (فساد)', -b.admin) + row('نگهداری ساختمان‌ها', -b.bld);
    h += `<div class="kv big"><span>خالص هر نوبت</span><b class="${b.net >= 0 ? 'good' : 'bad'}">${b.net >= 0 ? '+' : '−'}${fa(Math.abs(b.net))}</b></div>`;
    h += `<h4 class="sec">سیاست مالیاتی</h4><div class="seg">${tax.map((t, i) => `<button data-tax="${i}" class="${n.tax === i ? 'on' : ''}">${t}</button>`).join('')}</div><div class="note">مالیات سنگین درآمد را بالا می‌برد ولی ثبات سیاسی را می‌کاهد (اکنون ${fa(n.stab)}٪). ثبات پایین درآمد را کم می‌کند.</div>`;
    h += '<div class="note">استان‌های فتح‌شده در ابتدا فقط بخشی از درآمد را می‌دهند و کم‌کم ادغام می‌شوند. محاصرهٔ بندر، تجارت را قطع می‌کند.</div>';
    UI.openModal(h, el => el.onclick = e => { const b2 = e.target.closest('button[data-tax]'); if (!b2) return; g().setTax(+b2.dataset.tax); UI.showEcon(); UI.refreshHud(); });
  };
  UI.showDiplo = function () {
    UI.openKind = 'diplo'; const G = WC.G, me = G.player, mine = new Set(g().neighborNations(me));
    const list = G.nations.filter(n => n.alive && n.id !== me).sort((a, b) => (mine.has(b.id) - mine.has(a.id)) || g().natPower(b.id) - g().natPower(a.id)), q = (UI.dq || '').toLowerCase();
    let h = '<h2>دیپلماسی</h2>';
    if (G.offers.length) h += '<div class="list" style="margin-bottom:14px">' + G.offers.map((o, i) => `<div class="item">${dot(G.nations[o.from])}<div class="grow"><b>${esc(G.nations[o.from].name)}</b><small>${o.type === 'peace' ? 'پیشنهاد آتش‌بس' : 'پیشنهاد اتحاد'}</small></div><div class="acts"><button class="btn sm" data-offer="${i}" data-ok="1">بپذیر</button><button class="btn sm sec" data-offer="${i}" data-ok="0">رد</button></div></div>`).join('') + '</div>';
    h += '<input class="search" id="dq" placeholder="جستجوی کشور…" value="' + esc(UI.dq || '') + '"><div class="list">';
    list.filter(n => !q || n.name.includes(q) || n.en.toLowerCase().includes(q)).slice(0, 60).forEach(n => {
      const r = g().rel(me, n.id); let acts = '';
      if (r.state === 'war') acts = `<button class="btn sm sec" data-dip="peace" data-id="${n.id}">آتش‌بس</button>`; else if (r.state === 'ally') acts = `<button class="btn sm sec" data-dip="break" data-id="${n.id}">لغو اتحاد</button>`;
      else acts = `<button class="btn sm sec" data-dip="ally" data-id="${n.id}">اتحاد</button><button class="btn sm danger" data-dip="war" data-id="${n.id}" ${G.turn < r.truce ? 'disabled' : ''}>جنگ</button>`;
      h += `<div class="item">${dot(n)}<div class="grow"><b>${esc(n.name)}</b> ${relTag(me, n.id)}<small>${esc(n.leader.title)} ${esc(n.leader.name)} · ${WC.GOVS[n.gov].fa} · قدرت ${fa(g().natPower(n.id))}</small></div><div class="acts">${acts}</div></div>`;
    });
    h += '</div>';
    UI.openModal(h, el => {
      el.querySelector('#dq').addEventListener('input', e => { UI.dq = e.target.value; const pos = e.target.selectionStart; UI.showDiplo(); const s2 = $('dq'); s2.focus(); s2.setSelectionRange(pos, pos); });
      el.onclick = e => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.offer !== undefined) { g().answerOffer(+b.dataset.offer, b.dataset.ok === '1'); WC.audio.play(b.dataset.ok === '1' ? 'peace' : 'click'); UI.showDiplo(); UI.refreshHud(); } else if (b.dataset.dip) dipAction(b.dataset.dip, +b.dataset.id); };
    });
  };
  UI.showTech = function () {
    UI.openKind = 'tech'; const G = WC.G, n = G.nations[G.player], MAX = g().TECH_MAX;
    const row = (k, name, desc) => { const lvl = n.tech[k], c = g().techCost(n, lvl); return `<div class="tech"><b>${name} ${pips(lvl, MAX)}</b><button class="btn sm" data-tech="${k}" ${lvl >= MAX || n.money < c ? 'disabled' : ''}>${lvl >= MAX ? 'کامل' : fa(c) + ' 💰'}</button><small>${desc}</small></div>`; };
    let h = `<h2>فناوری و پژوهش</h2><div class="kv"><span>خزانه</span><b>${fa(n.money)} 💰</b></div>`;
    h += row('atk', 'تسلیحات تهاجمی', 'هر سطح: ۱۲٪ قدرت حملهٔ زمینی و دریایی') + row('def', 'دفاع و استحکامات', 'هر سطح: ۱۲٪ قدرت دفاعی') + row('eco', 'صنعت و اقتصاد', 'هر سطح: ۱۰٪ درآمد بیشتر');
    h += `<div class="tech"><b>برنامهٔ اتمی ${n.tech.nuke ? '<span class="tag ally">فعال</span>' : ''}</b><button class="btn sm danger" data-tech="nuke" ${n.tech.nuke || n.money < g().NUKE_TECH_COST ? 'disabled' : ''}>${n.tech.nuke ? 'در اختیار' : fa(g().NUKE_TECH_COST) + ' 💰'}</button><small>امکان حملهٔ اتمی به کشورهای در جنگ. پیامد جهانی دارد.</small></div>`;
    UI.openModal(h, el => el.onclick = e => { const b = e.target.closest('button[data-tech]'); if (!b) return; const r = g().research(G.player, b.dataset.tech); if (r.ok) { WC.audio.play('research'); UI.showTech(); UI.refreshHud(); } else { UI.toast(r.msg, 'bad'); WC.audio.play('error'); } });
  };
  UI.showRank = function () {
    UI.openKind = 'rank'; const G = WC.G, rows = G.nations.filter(n => n.alive).map(n => ({ n, p: g().ownedProvs(n.id).length, pw: g().natPower(n.id) })).sort((a, b) => b.p - a.p || b.pw - a.pw);
    const idx = rows.findIndex(r => r.n.id === G.player), tot = G.provinces.length;
    let h = `<h2>رده‌بندی جهان</h2><div class="hint" style="margin-bottom:8px">پیروزی: کنترل ۶۰٪ استان‌ها (${fa(Math.ceil(tot * 0.6))} از ${fa(tot)}). شما: رتبهٔ ${fa(idx + 1)}، ${fa(rows[idx] ? rows[idx].p : 0)} استان.</div><div class="list">`;
    rows.slice(0, 15).forEach((r, i) => h += `<div class="item" ${r.n.id === G.player ? 'style="background:rgba(217,180,90,.12)"' : ''}><b style="width:26px">${fa(i + 1)}</b>${dot(r.n)}<div class="grow"><b>${esc(r.n.name)}</b><small>${fa(r.p)} استان · قدرت ${fa(r.pw)} · ${esc(r.n.leader.name)}</small></div></div>`);
    UI.openModal(h + '</div>');
  };
  UI.showLog = function () { UI.openKind = 'log'; const G = WC.G; UI.openModal('<h2>گزارش نبرد</h2>' + (G.log.length ? G.log.slice(0, 80).map(l => `<div class="logline ${l.kind}"><small>${fa(l.turn)}</small>${esc(l.msg)}</div>`).join('') : '<div class="hint">هنوز رویدادی نیست.</div>')); };
  UI.showMenuModal = function () {
    UI.openKind = 'menu'; const q = localStorage.getItem('wc_quality') === 'high';
    UI.openModal(`<h2>منو</h2><div class="list">
      <div class="item"><div class="grow">افکت‌های صوتی</div><button class="btn sm ${WC.audio.sfx ? '' : 'sec'}" data-m="sfx">${WC.audio.sfx ? 'روشن' : 'خاموش'}</button></div>
      <div class="item"><div class="grow">موسیقی</div><button class="btn sm ${WC.audio.music ? '' : 'sec'}" data-m="music">${WC.audio.music ? 'روشن' : 'خاموش'}</button></div>
      <div class="item"><div class="grow">تمام‌صفحه و افقی<small>روی گوشی بهتر است</small></div><button class="btn sm sec" data-m="full">فعال</button></div>
      <div class="item"><div class="grow">کیفیت نقشه<small>«دقیق» کشورهای کوچک بیشتری دارد</small></div><button class="btn sm sec" data-m="quality">${q ? 'دقیق (۵۰m)' : 'استاندارد (۱۱۰m)'}</button></div>
      <div class="item"><div class="grow">ذخیرهٔ بازی<small>هر نوبت خودکار ذخیره می‌شود</small></div><button class="btn sm" data-m="save">ذخیره</button></div>
      <div class="item"><div class="grow">راهنمای بازی</div><button class="btn sm sec" data-m="help">نمایش</button></div>
      <div class="item"><div class="grow">بازگشت به منوی اصلی</div><button class="btn sm danger" data-m="home">خروج</button></div></div>`,
      el => el.onclick = e => {
        const b = e.target.closest('button[data-m]'); if (!b) return; const m = b.dataset.m;
        if (m === 'sfx') { WC.audio.setSfx(!WC.audio.sfx); UI.showMenuModal(); } else if (m === 'music') { WC.audio.init(); WC.audio.setMusic(!WC.audio.music); UI.showMenuModal(); }
        else if (m === 'full') { UI.goFullscreen(); UI.closeModal(); } else if (m === 'quality') { localStorage.setItem('wc_quality', q ? 'low' : 'high'); location.reload(); }
        else if (m === 'save') { g().save(); UI.toast('ذخیره شد.', 'good'); } else if (m === 'help') UI.showHelp(); else if (m === 'home') { UI.closeModal(); g().save(); UI.showMenu(); }
      });
  };
  UI.goFullscreen = function () {
    const el = document.documentElement, lock = () => { try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} };
    try {
      if (document.fullscreenElement) { lock(); return; }
      const rq = el.requestFullscreen ? el.requestFullscreen() : el.webkitRequestFullscreen ? el.webkitRequestFullscreen() : null;
      if (rq && rq.then) rq.then(lock).catch(lock); else lock();
    } catch (e) { lock(); }
  };
  UI.showHelp = function () {
    UI.openKind = 'help';
    UI.openModal(`<h2>راهنمای بازی</h2><div class="hint" style="font-size:13.5px;line-height:2.1">
      <b class="k">هدف:</b> با فتح استان‌ها، ۶۰٪ استان‌های جهان را زیر پرچم خود درآورید. هر کشوری که فتح شود به خاک شما می‌پیوندد و نامش از نقشه محو می‌شود.<br>
      <b class="k">استان‌ها:</b> هر کشور چند استان دارد؛ هر استان درآمد، تولید و ارتش خودش را دارد. پایتخت با ★ مشخص است.<br>
      <b class="k">فرمان:</b> استان خودتان را انتخاب کنید، درصد نیرو را بگذارید و روی همسایهٔ درخشان بزنید. قرمز حمله، سبز انتقال، نارنجی نیازمند اعلان جنگ. هر استان در هر نوبت یک فرمان می‌پذیرد.<br>
      <b class="k">دریا:</b> برای حمله یا انتقال از دریا ناو ترابری لازم است. ناوگان جنگی را از بندر به دریا بفرستید، با کشتی‌های دشمن بجنگد، بنادر را محاصره کند و کشتی‌های تجاری دشمن را شکار کند. کشتی‌های تجاری شما درآمد می‌آورند.<br>
      <b class="k">اقتصاد:</b> مالیات، صنعت، منابع (نفت و معدن) و تجارت درآمد می‌سازند؛ ارتش، ناوگان و اداره کشور هزینه دارند. ساختمان‌ها را ارتقا دهید و مالیات را تنظیم کنید.<br>
      <b class="k">رهبران و فرماندهان:</b> هر کشور حکومت و رهبری با ویژگی خاص دارد. فرماندهان ارتش با پیروزی ترفیع می‌گیرند و قدرت حمله و دفاع را بالا می‌برند.<br>
      <b class="k">میانبرها:</b> فاصله = پایان نوبت، Esc = لغو، + و − = زوم.
    </div>`);
  };
  UI.showEnd = function (win) {
    const G = WC.G;
    UI.openModal(`<div class="center"><div class="end-title" style="color:${win ? 'var(--brass2)' : 'var(--war)'}">${win ? 'جهان از آنِ شماست' : 'شکست خوردید'}</div>
      <p class="hint" style="font-size:14px">${win ? 'بیش از ۶۰٪ استان‌ها زیر پرچم شما هستند.' : 'همهٔ استان‌های شما سقوط کرد.'}<br>نوبت ${fa(G.turn)} · نبردها ${fa(G.stats.battles)} · فتوحات ${fa(G.stats.captured)} · کشتی‌های غرق‌شده ${fa(G.stats.sunk)}</p>
      <div class="row2" style="justify-content:center;margin-top:16px">${win ? '<button class="btn" data-e="go">ادامهٔ بازی</button>' : ''}<button class="btn sec" data-e="home">منوی اصلی</button></div></div>`,
      el => el.onclick = e => { const b = e.target.closest('button[data-e]'); if (!b) return; if (b.dataset.e === 'home') { g().clearSave(); UI.closeModal(); UI.showMenu(); } else UI.closeModal(); });
    WC.audio.play(win ? 'win' : 'lose');
  };

  // ---------- رویدادهای عمومی ----------
  document.querySelector('.hud-btns').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return; WC.audio.init(); WC.audio.play('click');
    ({ diplo: UI.showDiplo, econ: UI.showEcon, tech: UI.showTech, rank: UI.showRank, log: UI.showLog, menu: UI.showMenuModal })[b.dataset.act]();
  });
  $('h-name').addEventListener('click', () => { if (WC.G && WC.G.player >= 0) UI.showNation(WC.G.player); });
  $('modal').addEventListener('click', e => { if (e.target === $('modal') || e.target.closest('[data-close]')) UI.closeModal(); });
  $('endturn').addEventListener('click', () => { WC.audio.init(); WC.audio.play('click'); UI.select(UI.sel, true); g().endTurn(); });
  $('zoom').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.z === 'in') R.zoomBy(1.35); else if (b.dataset.z === 'out') R.zoomBy(1 / 1.35); else if (WC.G && WC.G.player >= 0) R.focusCountry(WC.G.countries[WC.G.player], 0.8);
  });
  document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') { if (e.key === 'Escape') e.target.blur(); return; }
    if (e.key === 'Escape') { if (UI.modalOpen()) UI.closeModal(); else UI.select(-1); }
    else if (UI.mode === 'game' && !UI.modalOpen() && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); if (!WC.G.busy) { UI.select(UI.sel, true); g().endTurn(); } }
    else if (e.key === '+' || e.key === '=') R.zoomBy(1.25); else if (e.key === '-') R.zoomBy(0.8);
  });
  R.onClick = h => UI.onMapClick(h); R.onHover = (p, x, y) => UI.onHover(p, x, y);
})(window.WC);
