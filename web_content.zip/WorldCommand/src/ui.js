/* فرمان جهان — رابط کاربری */
(function (WC) {
  const $ = id => document.getElementById(id);
  const fa = WC.fa, U = WC.UNITS, T = WC.TYPES;
  const UI = WC.UI = { sel: -1, frac: 0.75, orderMode: true, mode: 'menu', menuPick: -1, diff: 'normal' };
  const R = WC.R;
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const g = () => WC.game;
  const fmt1 = v => (Math.round(v * 10) / 10).toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]).replace('.', '٫');

  // ---------- پیام‌ها ----------
  UI.toast = function (msg, kind) {
    const d = document.createElement('div'); d.className = 'toast ' + (kind || ''); d.textContent = msg;
    const box = $('toasts'); box.appendChild(d); while (box.children.length > 4) box.firstChild.remove();
    setTimeout(() => d.remove(), 4200);
  };

  // ---------- پنجره ----------
  let modalOnClose = null;
  UI.openModal = function (html, mount) {
    $('modal-body').innerHTML = html; $('modal').hidden = false;
    if (mount) mount($('modal-body'));
  };
  UI.closeModal = function () { $('modal').hidden = true; $('modal-body').innerHTML = ''; if (modalOnClose) { const f = modalOnClose; modalOnClose = null; f(); } };
  UI.modalOpen = () => !$('modal').hidden;
  function confirmBox(msg, yes, no, yesCls) {
    return new Promise(res => {
      UI.openModal(`<div class="center"><p style="font-size:16px;line-height:2;margin:14px 0 20px">${msg}</p><div class="row2" style="justify-content:center"><button class="btn ${yesCls || ''}" data-r="1">${yes}</button><button class="btn sec" data-r="0">${no}</button></div></div>`,
        el => el.querySelectorAll('[data-r]').forEach(b => b.onclick = () => { const v = b.dataset.r === '1'; modalOnClose = null; UI.closeModal(); res(v); }));
      modalOnClose = () => res(false);
    });
  }
  UI.confirm = confirmBox;

  // ---------- برچسب رابطه ----------
  function relTag(a, b) {
    const G = WC.G, r = g().rel(a, b);
    if (r.state === 'war') return '<span class="tag war">در جنگ</span>';
    if (r.state === 'ally') return '<span class="tag ally">متحد</span>';
    if (G.turn < r.truce) return '<span class="tag truce">آتش‌بس</span>';
    return '<span class="tag peace">صلح</span>';
  }
  const dot = n => `<span class="badge" style="background:${n.css.fill};width:16px;height:16px"></span>`;

  // ---------- نوار بالا ----------
  UI.refreshHud = function () {
    const G = WC.G; if (!G || G.player < 0) return;
    const n = G.nations[G.player];
    $('h-badge').style.background = n.css.fill; $('h-name').textContent = n.name;
    $('h-money').textContent = fa(n.money); $('h-income').textContent = '+' + fa(g().natIncome(n.id));
    const mine = g().ownedProvs(n.id).length;
    $('h-prov').textContent = fa(mine) + ' / ' + fa(G.provinces.length);
    $('h-power').textContent = WC.compactFa(g().natPower(n.id));
    $('h-turn').textContent = fa(G.turn);
    $('offer-dot').hidden = G.offers.length === 0;
    $('endturn').disabled = G.busy || G.over;
  };

  // ---------- انتخاب ----------
  UI.select = function (id) {
    UI.sel = id; R.selected = id;
    UI.computeTargets(); UI.renderPanel();
    if (id >= 0) WC.audio.play('click');
  };
  UI.computeTargets = function () {
    R.targets.clear(); R.linksFor = -1;
    const G = WC.G; if (!G || G.player < 0 || UI.sel < 0 || !UI.orderMode) return;
    const p = G.provinces[UI.sel];
    if (p.owner !== G.player || p.acted || G.busy || g().totalUnits(p.units) < 1) return;
    R.linksFor = p.id;
    p.neighbors.forEach(l => {
      const q = G.provinces[l.to]; let kind;
      if (q.owner === G.player || g().allied(G.player, q.owner)) kind = 'move';
      else if (g().atWar(G.player, q.owner)) kind = 'attack';
      else kind = 'war';
      if (l.sea && p.units.nav < 1) kind = 'blocked';
      R.targets.set(q.id, kind);
    });
  };

  function garrisonHtml(p, exact) {
    return '<div class="gar">' + T.map(t => {
      let v = p.units[t]; if (!exact && v >= 10) v = Math.round(v / 5) * 5;
      return `<span><i style="background:${U[t].color}"></i>${U[t].fa}</span><span class="n">${exact ? '' : (p.units[t] >= 10 ? '≈' : '')}${fa(v)}</span>`;
    }).join('') + '</div>';
  }
  const pips = (v, max) => '<span class="pips">' + Array.from({ length: max }, (_, i) => `<i class="${i < v ? 'f' : ''}"></i>`).join('') + '</span>';

  UI.renderPanel = function () {
    const G = WC.G, el = $('panel');
    if (!G || G.player < 0 || UI.sel < 0) { el.hidden = true; return; }
    const p = G.provinces[UI.sel], o = G.nations[p.owner], me = G.player, mine = p.owner === me;
    let h = `<h3>${esc(p.fa)}</h3><div class="sub">${dot(o)}<span>${mine ? 'قلمرو شما' : esc(o.name)}</span>${mine ? '' : relTag(me, p.owner)}</div>`;
    h += `<div class="kv"><span>اقتصاد</span>${pips(p.econ, 10)}</div><div class="kv"><span>درآمد استان</span><b>+${fa(g().provIncome(p))}</b></div><div class="kv"><span>قدرت نظامی</span><b>${fa(g().unitPower(p.units))}</b></div>`;
    if (p.irr > 0) h += `<div class="note" style="color:#ffd24a">☢ آلوده به پرتو اتمی (${fa(p.irr)} نوبت)</div>`;
    h += '<h4>نیروها</h4>' + garrisonHtml(p, mine);
    if (mine) {
      const n = G.nations[me], room = g().prodCap(p) - p.rec;
      h += `<h4>سربازگیری <small style="color:var(--mute)">(ظرفیت این نوبت: ${fa(room)})</small></h4><div class="row2" id="qty">${[1, 5, 10].map(q => `<button class="chip ${(UI.qty || 1) === q ? 'on' : ''}" data-qty="${q}">×${fa(q)}</button>`).join('')}</div><div class="rec">` +
        T.map(t => { const dis = n.money < U[t].cost || room <= 0 || (t === 'nav' && !(p.coastal && p.hasSea)); return `<button data-rec="${t}" ${dis ? 'disabled' : ''}><b>${U[t].fa}</b><small>${fa(U[t].cost)} 💰 · حمله ${fmt1(U[t].atk)}</small></button>`; }).join('') + '</div>';
      h += '<h4>فرمان</h4>';
      if (p.acted) h += '<div class="note">این استان در این نوبت فرمان داده است.</div>';
      else if (g().totalUnits(p.units) < 1) h += '<div class="note">نیرویی ندارید؛ سربازگیری کنید.</div>';
      else {
        h += `<div class="row2" id="fr">${[0.25, 0.5, 0.75, 1].map(f => `<button class="chip ${UI.frac === f ? 'on' : ''}" data-frac="${f}">${fa(f * 100)}٪ نیرو</button>`).join('')}</div>`;
        h += `<div class="orderbar">${UI.orderMode ? 'روی یکی از استان‌های درخشان نقشه بزنید: قرمز = حمله، سبز = انتقال، نارنجی = نیازمند اعلان جنگ.' : 'حالت فرمان خاموش است.'}</div><div class="row2" style="margin-top:8px"><button class="btn sm sec" data-act="toggle-order">${UI.orderMode ? 'خاموش‌کردن حالت فرمان' : 'روشن‌کردن حالت فرمان'}</button></div>`;
      }
    } else {
      h += '<h4>دیپلماسی</h4><div class="row2">';
      const r = g().rel(me, p.owner);
      if (r.state === 'war') h += `<button class="btn sm sec" data-dip="peace" data-id="${p.owner}">درخواست آتش‌بس</button>`;
      else if (r.state === 'ally') h += `<button class="btn sm sec" data-dip="break" data-id="${p.owner}">لغو اتحاد</button>`;
      else h += `<button class="btn sm sec" data-dip="ally" data-id="${p.owner}">پیشنهاد اتحاد</button><button class="btn sm danger" data-dip="war" data-id="${p.owner}" ${G.turn < r.truce ? 'disabled' : ''}>اعلان جنگ</button>`;
      h += '</div>';
      const my = G.nations[me];
      if (r.state === 'war' && my.tech.nuke) h += `<h4>سلاح راهبردی</h4><button class="btn sm danger" data-act="nuke" ${my.nukeCd > 0 || my.money < g().NUKE_COST ? 'disabled' : ''}>حملهٔ اتمی (${fa(g().NUKE_COST)} 💰)</button><div class="note">${my.nukeCd > 0 ? 'آماده‌سازی: ' + fa(my.nukeCd) + ' نوبت' : 'نیروها ۸۰٪ نابود می‌شوند و جهان خشمگین می‌شود.'}</div>`;
      if (r.state !== 'ally') h += '<div class="note">برای حمله، یکی از استان‌های خودتان را که همسایهٔ این کشور است انتخاب کنید.</div>';
    }
    el.innerHTML = h; el.hidden = false;
  };

  $('panel').addEventListener('click', async e => {
    const b = e.target.closest('button'); if (!b) return;
    const G = WC.G, d = b.dataset;
    if (d.qty) { UI.qty = +d.qty; UI.renderPanel(); return; }
    if (d.frac) { UI.frac = +d.frac; WC.audio.play('click'); UI.renderPanel(); return; }
    if (d.rec) {
      const res = g().recruit(UI.sel, d.rec, UI.qty || 1);
      if (!res.ok) { UI.toast(res.msg, 'bad'); WC.audio.play('error'); }
      return;
    }
    if (d.act === 'toggle-order') { UI.orderMode = !UI.orderMode; UI.computeTargets(); UI.renderPanel(); return; }
    if (d.act === 'nuke') {
      if (await confirmBox('حملهٔ اتمی به ' + esc(G.provinces[UI.sel].fa) + '؟<br><small style="color:var(--mute)">تمام جهان علیه شما خواهد شد.</small>', 'شلیک', 'انصراف', 'danger')) {
        const r = g().nuke(UI.sel); if (!r.ok) UI.toast(r.msg, 'bad');
      }
      return;
    }
    if (d.dip) dipAction(d.dip, +d.id);
  });

  async function dipAction(kind, id) {
    const G = WC.G, me = G.player;
    if (kind === 'war') {
      if (!await confirmBox('به ' + esc(G.nations[id].name) + ' اعلان جنگ می‌کنید؟<br><small style="color:var(--mute)">متحدان آن‌ها ممکن است به جنگ بپیوندند.</small>', 'اعلان جنگ', 'انصراف', 'danger')) return;
      const r = g().declareWar(me, id); if (!r.ok) UI.toast(r.msg, 'bad');
    } else if (kind === 'break') { g().breakAlliance(me, id); }
    else { const r = g().propose(kind, id); UI.toast(r.msg, r.ok ? 'good' : 'bad'); if (r.ok) WC.audio.play('peace'); else WC.audio.play('error'); }
    UI.computeTargets(); UI.renderPanel(); UI.refreshHud();
    if (UI.openKind === 'diplo' && UI.modalOpen()) UI.showDiplo();
  }

  // ---------- کلیک روی نقشه ----------
  UI.onMapClick = async function (p) {
    WC.audio.init();
    if (UI.mode === 'menu') { if (p) UI.menuSelect(p.id, true); return; }
    const G = WC.G; if (!G || G.busy || UI.modalOpen()) return;
    if (!p) { UI.select(-1); return; }
    if (UI.sel >= 0 && UI.orderMode && R.targets.has(p.id)) { await doOrder(UI.sel, p.id, R.targets.get(p.id)); return; }
    UI.select(p.id);
  };
  async function doOrder(srcId, dstId, kind) {
    const G = WC.G, src = G.provinces[srcId], dst = G.provinces[dstId];
    if (kind === 'blocked') { UI.toast('برای عبور از دریا حداقل یک ناو در این استان لازم است.', 'bad'); WC.audio.play('error'); return; }
    if (kind === 'war') {
      const r = g().rel(G.player, dst.owner);
      if (r.state === 'ally') { UI.toast('با ' + G.nations[dst.owner].name + ' متحد هستید.', 'bad'); return; }
      if (G.turn < r.truce) { UI.toast('آتش‌بس تا نوبت ' + fa(r.truce) + ' برقرار است.', 'bad'); WC.audio.play('error'); return; }
      if (!await confirmBox('به ' + esc(G.nations[dst.owner].name) + ' اعلان جنگ می‌کنید و ' + esc(dst.fa) + ' را می‌زنید؟', 'اعلان جنگ و حمله', 'انصراف', 'danger')) return;
      const w = g().declareWar(G.player, dst.owner); if (!w.ok) { UI.toast(w.msg, 'bad'); return; }
    } else if (kind === 'move') {
      const ok = await confirmBox(`انتقال ${fa(UI.frac * 100)}٪ نیروها از ${esc(src.fa)} به ${esc(dst.fa)}؟`, 'انتقال', 'فقط انتخاب');
      if (!ok) { UI.select(dstId); return; }
    }
    const res = g().order(srcId, dstId, UI.frac, 'player');
    if (!res.ok) { UI.toast(res.msg, 'bad'); WC.audio.play('error'); }
    UI.computeTargets(); UI.renderPanel(); UI.refreshHud();
  }

  // ---------- راهنمای شناور ----------
  UI.onHover = function (p, x, y) {
    const tt = $('tooltip');
    if (!p || UI.mode === 'menu' && false) { tt.hidden = true; return; }
    const G = WC.G; if (!G) { tt.hidden = true; return; }
    const o = G.nations[p.owner];
    let h = `<b>${esc(p.fa)}</b>`;
    if (p.owner !== p.id) h += ` <small style="color:var(--mute)">(تحت کنترل ${esc(o.name)})</small>`;
    h += `<br>قدرت: ${fa(g().unitPower(p.units))}`;
    if (G.player >= 0 && p.owner !== G.player) h += `<br>${relTag(G.player, p.owner)}`;
    tt.innerHTML = h; tt.hidden = false;
    tt.style.left = Math.min(window.innerWidth - 250, x + 16) + 'px'; tt.style.top = Math.min(window.innerHeight - 90, y + 16) + 'px';
  };

  // ---------- منوی شروع ----------
  UI.showMenu = function () {
    UI.mode = 'menu';
    ['hud', 'panel', 'endturn', 'zoom'].forEach(i => $(i).hidden = true);
    $('menu').hidden = false; R.targets.clear(); R.linksFor = -1;
    WC.newGame(WC.provs, -1, UI.diff);
    UI.fillMenuList('');
    const first = WC.provs.find(p => p.name === 'Iran') || WC.provs[0];
    UI.menuSelect(first.id, true);
  };
  UI.fillMenuList = function (q) {
    const ul = $('m-list'); q = q.trim().toLowerCase();
    const list = WC.provs.filter(p => !q || p.fa.includes(q) || p.name.toLowerCase().includes(q)).sort((a, b) => (b.mil * 2 + b.econ) - (a.mil * 2 + a.econ) || a.fa.localeCompare(b.fa, 'fa'));
    ul.innerHTML = list.map(p => `<li data-id="${p.id}" class="${p.id === UI.menuPick ? 'on' : ''}" tabindex="0">${dot(WC.G.nations[p.id])}<span>${esc(p.fa)}</span><span class="pw">${'★'.repeat(Math.max(1, Math.round((p.mil + p.econ) / 4)))}</span></li>`).join('');
  };
  UI.menuSelect = function (id, fly) {
    UI.menuPick = id; R.selected = id;
    const p = WC.provs[id], G = WC.G;
    $('m-list').querySelectorAll('li').forEach(li => li.classList.toggle('on', +li.dataset.id === id));
    const on = $('m-list').querySelector('li.on'); if (on) on.scrollIntoView({ block: 'nearest' });
    if (fly) { R.menuDrift = 0; R.focusProvince(p, 0.55); }
    const neigh = p.neighbors.filter(l => !l.sea).length, sea = p.neighbors.filter(l => l.sea).length;
    const u = G.provinces[id].units;
    const diffs = Object.entries(g().DIFF).map(([k, v]) => `<button data-diff="${k}" class="${UI.diff === k ? 'on' : ''}">${v.label}</button>`).join('');
    $('m-card').innerHTML = `<h2>${esc(p.fa)}</h2><div class="en">${esc(p.name)}</div>
      <div class="grid">
        <div class="cell"><small>قدرت نظامی</small>${pips(p.mil, 10)}</div>
        <div class="cell"><small>اقتصاد</small>${pips(p.econ, 10)}</div>
        <div class="cell"><small>همسایگان زمینی / دریایی</small><b>${fa(neigh)} / ${fa(sea)}</b></div>
        <div class="cell"><small>درآمد هر نوبت</small><b>+${fa(g().natIncome(id))}</b></div>
      </div>
      <div class="hint">نیروی آغازین: ${T.filter(t => u[t] > 0).map(t => U[t].fa + ' ' + fa(u[t])).join('، ')}</div>
      <div class="hint" style="margin-top:10px">سطح دشواری</div><div class="seg">${diffs}</div>
      <div class="row"><button class="btn" id="m-start">شروع نبرد</button>${g().hasSave() ? '<button class="btn sec" id="m-continue">ادامهٔ بازی</button>' : ''}<button class="btn sec" id="m-help">راهنما</button></div>`;
  };
  $('m-list').addEventListener('click', e => { const li = e.target.closest('li'); if (li) { WC.audio.init(); UI.menuSelect(+li.dataset.id, true); } });
  $('m-search').addEventListener('input', e => UI.fillMenuList(e.target.value));
  $('m-card').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    WC.audio.init(); WC.audio.play('click');
    if (b.dataset.diff) { UI.diff = b.dataset.diff; UI.menuSelect(UI.menuPick, false); }
    else if (b.id === 'm-start') UI.startGame(UI.menuPick);
    else if (b.id === 'm-continue') UI.continueGame();
    else if (b.id === 'm-help') UI.showHelp();
  });

  UI.enterGameMode = function () {
    UI.mode = 'game'; R.menuDrift = 0;
    $('menu').hidden = true; ['hud', 'endturn', 'zoom'].forEach(i => $(i).hidden = false);
    UI.sel = -1; R.selected = -1; UI.refreshHud();
  };
  UI.startGame = function (id) {
    g().clearSave();
    WC.newGame(WC.provs, id, UI.diff);
    UI.enterGameMode(); UI.select(id);
    R.focusProvince(WC.provs[id], 0.8);
    WC.audio.play('turn'); UI.toast('فرماندهی را بر عهده گرفتید. نیروها را سازمان دهید!', 'big');
    g().save();
  };
  UI.continueGame = function () {
    if (!g().load(WC.provs)) { UI.toast('ذخیره‌ای سازگار با این نقشه پیدا نشد.', 'bad'); return; }
    UI.enterGameMode(); const G = WC.G; UI.select(G.player); R.focusProvince(G.provinces[G.player], 0.8);
    UI.toast('بازی بارگذاری شد — نوبت ' + fa(G.turn), 'big');
  };

  // ---------- پنجره‌های بازی ----------
  UI.showDiplo = function () {
    UI.openKind = 'diplo';
    const G = WC.G, me = G.player, mine = new Set(g().neighborNations(me));
    const list = G.nations.filter(n => n.alive && n.id !== me).sort((a, b) => (mine.has(b.id) - mine.has(a.id)) || g().natPower(b.id) - g().natPower(a.id));
    const q = (UI.dq || '').toLowerCase();
    let h = '<h2>دیپلماسی</h2>';
    if (G.offers.length) {
      h += '<div class="list" style="margin-bottom:14px">' + G.offers.map((o, i) => `<div class="item">${dot(G.nations[o.from])}<div class="grow"><b>${esc(G.nations[o.from].name)}</b><small>${o.type === 'peace' ? 'پیشنهاد آتش‌بس' : 'پیشنهاد اتحاد'}</small></div><div class="acts"><button class="btn sm" data-offer="${i}" data-ok="1">بپذیر</button><button class="btn sm sec" data-offer="${i}" data-ok="0">رد</button></div></div>`).join('') + '</div>';
    }
    h += '<input class="search" id="dq" placeholder="جستجوی کشور…" value="' + esc(UI.dq || '') + '"><div class="list">';
    list.filter(n => !q || n.name.includes(q) || n.en.toLowerCase().includes(q)).slice(0, 60).forEach(n => {
      const r = g().rel(me, n.id); let acts = '';
      if (r.state === 'war') acts = `<button class="btn sm sec" data-dip="peace" data-id="${n.id}">آتش‌بس</button>`;
      else if (r.state === 'ally') acts = `<button class="btn sm sec" data-dip="break" data-id="${n.id}">لغو اتحاد</button>`;
      else acts = `<button class="btn sm sec" data-dip="ally" data-id="${n.id}">اتحاد</button><button class="btn sm danger" data-dip="war" data-id="${n.id}" ${G.turn < r.truce ? 'disabled' : ''}>جنگ</button>`;
      h += `<div class="item">${dot(n)}<div class="grow"><b>${esc(n.name)}</b> ${relTag(me, n.id)}<small>${mine.has(n.id) ? 'همسایه · ' : ''}قدرت ${fa(g().natPower(n.id))} · ${fa(g().ownedProvs(n.id).length)} استان</small></div><div class="acts">${acts}</div></div>`;
    });
    h += '</div>';
    UI.openModal(h, el => {
      const s = el.querySelector('#dq'); s.addEventListener('input', e => { UI.dq = e.target.value; const pos = e.target.selectionStart; UI.showDiplo(); const s2 = $('dq'); s2.focus(); s2.setSelectionRange(pos, pos); });
      el.onclick = e => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.dataset.offer !== undefined) { g().answerOffer(+b.dataset.offer, b.dataset.ok === '1'); WC.audio.play(b.dataset.ok === '1' ? 'peace' : 'click'); UI.showDiplo(); UI.refreshHud(); }
        else if (b.dataset.dip) dipAction(b.dataset.dip, +b.dataset.id);
      };
    });
  };
  UI.showTech = function () {
    UI.openKind = 'tech';
    const G = WC.G, n = G.nations[G.player], MAX = g().TECH_MAX;
    const row = (k, name, desc) => {
      const lvl = n.tech[k], c = g().techCost(lvl);
      return `<div class="tech"><b>${name} ${pips(lvl, MAX)}</b><button class="btn sm" data-tech="${k}" ${lvl >= MAX || n.money < c ? 'disabled' : ''}>${lvl >= MAX ? 'کامل' : fa(c) + ' 💰'}</button><small>${desc}</small></div>`;
    };
    let h = `<h2>فناوری و پژوهش</h2><div class="kv"><span>خزانه</span><b>${fa(n.money)} 💰</b></div>`;
    h += row('atk', 'تسلیحات تهاجمی', 'هر سطح: ۱۲٪ قدرت حملهٔ بیشتر') + row('def', 'دفاع و استحکامات', 'هر سطح: ۱۲٪ قدرت دفاعی بیشتر') + row('eco', 'صنعت و اقتصاد', 'هر سطح: ۱۰٪ درآمد بیشتر');
    h += `<div class="tech"><b>برنامهٔ اتمی ${n.tech.nuke ? '<span class="tag ally">فعال</span>' : ''}</b><button class="btn sm danger" data-tech="nuke" ${n.tech.nuke || n.money < g().NUKE_TECH_COST ? 'disabled' : ''}>${n.tech.nuke ? 'در اختیار' : fa(g().NUKE_TECH_COST) + ' 💰'}</button><small>امکان حملهٔ اتمی به کشورهای در جنگ. پیامد جهانی دارد.</small></div>`;
    UI.openModal(h, el => el.onclick = e => {
      const b = e.target.closest('button[data-tech]'); if (!b) return;
      const r = g().research(G.player, b.dataset.tech); if (r.ok) { WC.audio.play('research'); UI.showTech(); UI.refreshHud(); } else { UI.toast(r.msg, 'bad'); WC.audio.play('error'); }
    });
  };
  UI.showRank = function () {
    UI.openKind = 'rank';
    const G = WC.G, rows = G.nations.filter(n => n.alive).map(n => ({ n, p: g().ownedProvs(n.id).length, pw: g().natPower(n.id) })).sort((a, b) => b.p - a.p || b.pw - a.pw);
    const idx = rows.findIndex(r => r.n.id === G.player), tot = G.provinces.length;
    let h = `<h2>رده‌بندی جهان</h2><div class="hint" style="margin-bottom:8px">پیروزی: کنترل ۶۰٪ استان‌ها (${fa(Math.ceil(tot * 0.6))} از ${fa(tot)}). شما: رتبهٔ ${fa(idx + 1)}، ${fa(rows[idx] ? rows[idx].p : 0)} استان.</div><div class="list">`;
    rows.slice(0, 15).forEach((r, i) => h += `<div class="item" ${r.n.id === G.player ? 'style="background:rgba(217,180,90,.12)"' : ''}><b style="width:26px">${fa(i + 1)}</b>${dot(r.n)}<div class="grow"><b>${esc(r.n.name)}</b><small>${fa(r.p)} استان · قدرت ${fa(r.pw)}</small></div></div>`);
    h += '</div>';
    UI.openModal(h);
  };
  UI.showLog = function () {
    UI.openKind = 'log';
    const G = WC.G;
    UI.openModal('<h2>گزارش نبرد</h2>' + (G.log.length ? G.log.slice(0, 80).map(l => `<div class="logline ${l.kind}"><small>${fa(l.turn)}</small>${esc(l.msg)}</div>`).join('') : '<div class="hint">هنوز رویدادی نیست.</div>'));
  };
  UI.showMenuModal = function () {
    UI.openKind = 'menu';
    const q = localStorage.getItem('wc_quality') === 'high';
    UI.openModal(`<h2>منو</h2><div class="list">
      <div class="item"><div class="grow">افکت‌های صوتی</div><button class="btn sm ${WC.audio.sfx ? '' : 'sec'}" data-m="sfx">${WC.audio.sfx ? 'روشن' : 'خاموش'}</button></div>
      <div class="item"><div class="grow">موسیقی</div><button class="btn sm ${WC.audio.music ? '' : 'sec'}" data-m="music">${WC.audio.music ? 'روشن' : 'خاموش'}</button></div>
      <div class="item"><div class="grow">کیفیت نقشه<small>«دقیق» کشورهای کوچک بیشتری دارد (کندتر روی گوشی)</small></div><button class="btn sm sec" data-m="quality">${q ? 'دقیق (۵۰m)' : 'استاندارد (۱۱۰m)'}</button></div>
      <div class="item"><div class="grow">ذخیرهٔ بازی<small>بازی هر نوبت خودکار ذخیره می‌شود</small></div><button class="btn sm" data-m="save">ذخیره</button></div>
      <div class="item"><div class="grow">راهنمای بازی</div><button class="btn sm sec" data-m="help">نمایش</button></div>
      <div class="item"><div class="grow">بازگشت به منوی اصلی</div><button class="btn sm danger" data-m="home">خروج</button></div></div>`,
      el => el.onclick = async e => {
        const b = e.target.closest('button[data-m]'); if (!b) return; const m = b.dataset.m;
        if (m === 'sfx') { WC.audio.setSfx(!WC.audio.sfx); UI.showMenuModal(); }
        else if (m === 'music') { WC.audio.init(); WC.audio.setMusic(!WC.audio.music); UI.showMenuModal(); }
        else if (m === 'quality') { localStorage.setItem('wc_quality', q ? 'low' : 'high'); location.reload(); }
        else if (m === 'save') { g().save(); UI.toast('ذخیره شد.', 'good'); }
        else if (m === 'help') UI.showHelp();
        else if (m === 'home') { UI.closeModal(); g().save(); UI.showMenu(); }
      });
  };
  UI.showHelp = function () {
    UI.openKind = 'help';
    UI.openModal(`<h2>راهنمای بازی</h2><div class="hint" style="font-size:13.5px;line-height:2.1">
      <b style="color:var(--brass2)">هدف:</b> با فتح کشورها، ۶۰٪ استان‌های جهان را زیر پرچم خود درآورید.<br>
      <b style="color:var(--brass2)">هر کشور یک استان است.</b> روی کشوری بزنید تا نیروها و وضعیتش را ببینید.<br>
      <b style="color:var(--brass2)">سربازگیری:</b> از پنل کشور خودتان با پول خزانه، پیاده، تانک، توپخانه، هوایی و ناو بخرید. ظرفیت تولید هر نوبت محدود است.<br>
      <b style="color:var(--brass2)">فرمان:</b> کشور خودتان را انتخاب کنید، درصد نیرو را مشخص کنید و روی همسایهٔ درخشان بزنید. قرمز حمله، سبز انتقال و نارنجی یعنی ابتدا باید اعلان جنگ کنید. هر استان در هر نوبت یک فرمان می‌پذیرد و نیروهای تازه‌رسیده در همان نوبت جابه‌جا نمی‌شوند.<br>
      <b style="color:var(--brass2)">دریا:</b> خط‌چین‌ها مسیر دریایی‌اند؛ برای عبور از آن‌ها ناو لازم است (هر ناو ۲۰ نیروی زمینی می‌برد).<br>
      <b style="color:var(--brass2)">دیپلماسی:</b> اعلان جنگ، آتش‌بس و اتحاد. متحدان ممکن است به کمک بیایند.<br>
      <b style="color:var(--brass2)">فناوری:</b> حمله، دفاع و اقتصاد را ارتقا دهید. برنامهٔ اتمی هم هست، ولی بهایش سنگین است.<br>
      <b style="color:var(--brass2)">میانبرها:</b> فاصله = پایان نوبت، Esc = لغو، + و − = زوم، کشیدن = جابه‌جایی نقشه.
    </div>`);
  };
  UI.showEnd = function (win) {
    const G = WC.G;
    UI.openModal(`<div class="center"><div class="end-title" style="color:${win ? 'var(--brass2)' : 'var(--war)'}">${win ? 'جهان از آنِ شماست' : 'شکست خوردید'}</div>
      <p class="hint" style="font-size:14px">${win ? 'بیش از ۶۰٪ استان‌ها زیر پرچم شما هستند.' : 'همهٔ استان‌های شما سقوط کرد.'}<br>نوبت ${fa(G.turn)} · نبردها ${fa(G.stats.battles)} · فتوحات ${fa(G.stats.captured)}</p>
      <div class="row2" style="justify-content:center;margin-top:16px">${win ? '<button class="btn" data-e="go">ادامهٔ بازی</button>' : ''}<button class="btn sec" data-e="home">منوی اصلی</button></div></div>`,
      el => el.onclick = e => { const b = e.target.closest('button[data-e]'); if (!b) return; if (b.dataset.e === 'home') { g().clearSave(); UI.closeModal(); UI.showMenu(); } else UI.closeModal(); });
    WC.audio.play(win ? 'win' : 'lose');
  };

  // ---------- اتصال رویدادهای عمومی ----------
  document.querySelector('.hud-btns').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return; WC.audio.init(); WC.audio.play('click');
    ({ diplo: UI.showDiplo, tech: UI.showTech, rank: UI.showRank, log: UI.showLog, menu: UI.showMenuModal })[b.dataset.act]();
  });
  $('modal').addEventListener('click', e => { if (e.target === $('modal') || e.target.closest('[data-close]')) UI.closeModal(); });
  $('endturn').addEventListener('click', () => { WC.audio.init(); WC.audio.play('click'); UI.select(UI.sel); g().endTurn(); });
  $('zoom').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.z === 'in') R.zoomBy(1.35); else if (b.dataset.z === 'out') R.zoomBy(1 / 1.35);
    else if (WC.G && WC.G.player >= 0) R.focusProvince(WC.G.provinces[WC.G.player], 0.8);
  });
  document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') { if (e.key === 'Escape') e.target.blur(); return; }
    if (e.key === 'Escape') { if (UI.modalOpen()) UI.closeModal(); else UI.select(-1); }
    else if (UI.mode === 'game' && !UI.modalOpen() && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); if (!WC.G.busy) { UI.select(UI.sel); g().endTurn(); } }
    else if (e.key === '+' || e.key === '=') R.zoomBy(1.25); else if (e.key === '-') R.zoomBy(0.8);
  });
  R.onClick = p => UI.onMapClick(p);
  R.onHover = (p, x, y) => UI.onHover(p, x, y);
})(window.WC);
