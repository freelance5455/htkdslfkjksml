/* فرمان جهان — راه‌اندازی و اتصال رویدادها */
(function (WC) {
  const $ = id => document.getElementById(id);
  const R = WC.R, UI = WC.UI, fa = WC.fa;
  let lastSfx = 0;
  const sfx = n => { const t = performance.now(); if (t - lastSfx > 90) { lastSfx = t; WC.audio.play(n); } };
  const rgb = c => c.css.hi;

  WC.on('state', () => { UI.refreshHud(); UI.computeTargets(); if (!(UI.mode === 'game' && UI.modalOpen())) UI.renderPanel(); });
  WC.on('busy', b => { $('busy').hidden = !b; $('endturn').disabled = b; if (b) { R.targets.clear(); R.linksFor = -1; } else UI.computeTargets(); });
  WC.on('recruit', () => WC.audio.play('recruit'));
  WC.on('turn', d => { UI.toast('نوبت ' + fa(d.turn), 'big'); WC.audio.play('turn'); if (UI.sel >= 0) UI.select(UI.sel, true); else if (UI.selFleet >= 0) UI.renderPanel(); });
  WC.on('offer', () => { UI.refreshHud(); const o = WC.G.offers[WC.G.offers.length - 1]; if (o) UI.toast(WC.G.nations[o.from].name + (o.type === 'peace' ? ' پیشنهاد آتش‌بس داد.' : ' پیشنهاد اتحاد داد.'), 'good'); });
  WC.on('war', d => {
    const G = WC.G; if (G.player < 0) return;
    if (d.b === G.player) { UI.toast(G.nations[d.a].name + ' به شما اعلان جنگ کرد!', 'bad'); WC.audio.play('war'); }
    else if (d.a === G.player) WC.audio.play('war');
    else if (WC.game.allied(G.player, d.a) || WC.game.allied(G.player, d.b)) UI.toast(G.nations[d.a].name + ' به ' + G.nations[d.b].name + ' اعلان جنگ کرد.', '');
  });
  WC.on('peace', d => { const G = WC.G; if (G.player >= 0 && (d.a === G.player || d.b === G.player)) { UI.toast('آتش‌بس برقرار شد.', 'good'); WC.audio.play('peace'); } });
  WC.on('ally', d => { const G = WC.G; if (G.player >= 0 && (d.a === G.player || d.b === G.player)) { UI.toast('اتحاد بسته شد.', 'good'); WC.audio.play('peace'); } });
  WC.on('fall', d => { if (WC.G.player >= 0) UI.toast(WC.G.nations[d.id].name + ' سقوط کرد و به ' + WC.G.nations[d.by].name + ' پیوست.', 'big'); });
  WC.on('build', () => WC.audio.play('recruit'));
  WC.on('move', d => {
    const G = WC.G; if (G.player < 0 || d.src.owner !== G.player && !WC.game.allied(G.player, d.src.owner)) return;
    if (!d.sea) R.addMarch([d.src.seed.x, d.src.seed.y], [d.dst.seed.x, d.dst.seed.y], G.nations[d.src.owner].css.hi, WC.game.unitPower(d.dst.units));
    WC.audio.play('move');
  });
  WC.on('convoy', d => { R.addConvoy(d.path, WC.G.nations[d.owner].css.hi, d.sunk); if (d.sunk) setTimeout(() => sfx('attack'), 1500); });
  WC.on('attack', d => {
    const G = WC.G, A = G.nations[d.attacker], D = G.nations[d.defender], me = G.player, involved = d.attacker === me || d.defender === me;
    const boom = () => { R.boom(d.dst.seed.x, d.dst.seed.y, d.captured); if (involved || d.captured) sfx('attack'); if (d.captured) R.captureRipple(d.dst.seed.x, d.dst.seed.y, '255,255,255'); };
    if (d.sea) setTimeout(boom, 2000);
    else R.addMarch([d.src.seed.x, d.src.seed.y], [d.dst.seed.x, d.dst.seed.y], A.css.hi, 40 + WC.game.totalUnits(d.atkLoss) * 2, boom);
    const nm = d.dst.name, same = D.name === d.dst.name;
    if (d.captured) {
      WC.game.log(`${A.name} ${nm} را ${same ? 'فتح کرد' : 'از ' + D.name + ' گرفت'} (تلفات: ${fa(d.aL)} در برابر ${fa(d.dL)}).`, d.attacker === me ? 'peace' : d.defender === me ? 'war' : '');
      if (d.attacker === me) { UI.toast(`${nm} فتح شد! تلفات شما ${fa(d.aL)}، دشمن ${fa(d.dL)}`, 'good'); setTimeout(() => WC.audio.play('capture'), 500); }
      else if (d.defender === me) { UI.toast(`${nm} سقوط کرد!`, 'bad'); setTimeout(() => WC.audio.play('lose'), 500); }
    } else {
      WC.game.log(`${A.name} به ${nm} حمله کرد ولی دفع شد (تلفات: ${fa(d.aL)} در برابر ${fa(d.dL)}).`, involved ? 'war' : '');
      if (d.attacker === me) UI.toast(`حمله به ${nm} دفع شد. تلفات شما ${fa(d.aL)}، دشمن ${fa(d.dL)}`, 'bad');
      else if (d.defender === me) UI.toast(`حملهٔ ${A.name} به ${nm} را دفع کردید.`, 'good');
    }
  });
  WC.on('navalBattle', d => { R.boom(d.x, d.y, false, '120,200,255'); const G = WC.G; if (d.a === G.player || d.b === G.player) { sfx('attack'); UI.toast('نبرد دریایی!', 'big'); } else sfx('move'); });
  WC.on('bombard', d => { R.boom(d.x, d.y, false); sfx('attack'); });
  WC.on('nuke', d => { R.nuke(d.target.seed.x, d.target.seed.y); WC.audio.play('nuke'); UI.toast('انفجار اتمی در ' + d.target.name + '!', 'big'); });
  WC.on('victory', () => setTimeout(() => UI.showEnd(true), 900));
  WC.on('defeat', () => setTimeout(() => UI.showEnd(false), 900));

  async function boot() {
    const ld = $('loading'), err = $('ld-err'); err.hidden = true; $('ld-msg').hidden = false; ld.hidden = false;
    const quality = (function () { try { return localStorage.getItem('wc_quality') === 'high' ? 'high' : 'low'; } catch (e) { return 'low'; } })();
    try {
      const feats = await WC.geo.loadWorld(quality, m => $('ld-msg').textContent = m);
      $('ld-msg').textContent = 'ساخت جهان، استان‌ها و بنادر…'; await new Promise(r => setTimeout(r, 40));
      const w = WC.geo.build(feats); WC.countries = w.countries; WC.provs = w.provs;
      R.setWorld(w.countries, w.provs); WC.newGame(w.countries, w.provs, -1, 'normal');
      ld.hidden = true; UI.showMenu(); window.__WC_READY = true;
    } catch (e) { console.error(e); $('ld-msg').hidden = true; err.hidden = false; }
  }
  $('ld-retry').addEventListener('click', boot);
  // افقی‌سازی روی گوشی با اولین لمس
  let triedFull = false;
  document.addEventListener('pointerdown', e => { if (!triedFull && e.pointerType === 'touch' && window.innerWidth < 1000) { triedFull = true; UI.goFullscreen(); } }, { once: false });
  R.init($('map')); boot();
})(window.WC);
