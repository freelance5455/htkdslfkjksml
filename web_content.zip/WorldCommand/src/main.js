/* فرمان جهان — راه‌اندازی و اتصال رویدادها */
(function (WC) {
  const $ = id => document.getElementById(id);
  const R = WC.R, UI = WC.UI, fa = WC.fa;
  let lastSfx = 0;
  const sfx = n => { const t = performance.now(); if (t - lastSfx > 90) { lastSfx = t; WC.audio.play(n); } };

  // ---------- رویدادهای بازی ← جلوه‌ها ----------
  WC.on('state', () => { UI.refreshHud(); UI.computeTargets(); UI.renderPanel(); });
  WC.on('busy', b => { $('busy').hidden = !b; $('endturn').disabled = b; if (b) { R.targets.clear(); R.linksFor = -1; } else UI.computeTargets(); });
  WC.on('recruit', () => { WC.audio.play('recruit'); });
  WC.on('research', () => {});
  WC.on('turn', d => { UI.toast('نوبت ' + fa(d.turn), 'big'); WC.audio.play('turn'); if (UI.sel >= 0) UI.select(UI.sel); });
  WC.on('offer', () => { UI.refreshHud(); const o = WC.G.offers[WC.G.offers.length - 1]; if (o) UI.toast(WC.G.nations[o.from].name + (o.type === 'peace' ? ' پیشنهاد آتش‌بس داد.' : ' پیشنهاد اتحاد داد.'), 'good'); });
  WC.on('war', d => {
    const G = WC.G; if (G.player < 0) return;
    if (d.b === G.player) { UI.toast(G.nations[d.a].name + ' به شما اعلان جنگ کرد!', 'bad'); WC.audio.play('war'); }
    else if (d.a === G.player) WC.audio.play('war');
    else if (WC.game.allied(G.player, d.a) || WC.game.allied(G.player, d.b)) UI.toast(G.nations[d.a].name + ' به ' + G.nations[d.b].name + ' اعلان جنگ کرد.', '');
  });
  WC.on('peace', d => { const G = WC.G; if (G.player >= 0 && (d.a === G.player || d.b === G.player)) { UI.toast('آتش‌بس برقرار شد.', 'good'); WC.audio.play('peace'); } });
  WC.on('ally', d => { const G = WC.G; if (G.player >= 0 && (d.a === G.player || d.b === G.player)) { UI.toast('اتحاد بسته شد.', 'good'); WC.audio.play('peace'); } });
  WC.on('fall', d => { if (WC.G.player >= 0) UI.toast(WC.G.nations[d.id].name + ' سقوط کرد.', 'big'); });
  WC.on('move', d => {
    const G = WC.G; if (G.player < 0) return;
    const mine = d.src.owner === G.player;
    if (!mine) return;
    R.addArrow([d.src.anchor.x, d.src.anchor.y], [d.dst.anchor.x, d.dst.anchor.y], G.nations[d.src.owner].css.hi, 'move');
    WC.audio.play('move');
  });
  WC.on('attack', d => {
    const G = WC.G, A = G.nations[d.attacker], D = G.nations[d.defender], me = G.player;
    const involved = d.attacker === me || d.defender === me;
    const col = A.css.hi;
    const sum = x => Object.values(x).reduce((a, b) => a + b, 0);
    R.addArrow([d.src.anchor.x, d.src.anchor.y], [d.dst.anchor.x, d.dst.anchor.y], col, 'attack', () => {
      R.boom(d.dst.anchor.x, d.dst.anchor.y, d.captured);
      if (involved || d.captured) sfx('attack');
      if (d.captured) R.captureRipple(d.dst.anchor.x, d.dst.anchor.y, '255,255,255');
    });
    const dName = d.dst.fa;
    if (d.captured) {
      WC.game.log(`${A.name} ${dName} را ${D.name === dName ? 'فتح کرد' : 'از ' + D.name + ' گرفت'} (تلفات: ${fa(d.aL)} در برابر ${fa(d.dL)}).`, d.attacker === me ? 'peace' : d.defender === me ? 'war' : '');
      if (d.attacker === me) { UI.toast(`${dName} فتح شد! تلفات شما ${fa(d.aL)}، دشمن ${fa(d.dL)}`, 'good'); setTimeout(() => WC.audio.play('capture'), 500); }
      else if (d.defender === me) { UI.toast(`${dName} سقوط کرد!`, 'bad'); setTimeout(() => WC.audio.play('lose'), 500); }
    } else {
      WC.game.log(`${A.name} به ${dName} حمله کرد ولی دفع شد (تلفات: ${fa(d.aL)} در برابر ${fa(d.dL)}).`, involved ? 'war' : '');
      if (d.attacker === me) UI.toast(`حمله به ${dName} دفع شد. تلفات شما ${fa(d.aL)}، دشمن ${fa(d.dL)}`, 'bad');
      else if (d.defender === me) UI.toast(`حملهٔ ${A.name} به ${dName} را دفع کردید.`, 'good');
    }
  });
  WC.on('nuke', d => {
    R.nuke(d.target.anchor.x, d.target.anchor.y); WC.audio.play('nuke');
    UI.toast('انفجار اتمی در ' + d.target.fa + '!', 'big');
  });
  WC.on('victory', () => setTimeout(() => UI.showEnd(true), 900));
  WC.on('defeat', () => setTimeout(() => UI.showEnd(false), 900));

  // ---------- بارگذاری نقشه ----------
  async function boot() {
    const ld = $('loading'), err = $('ld-err');
    err.hidden = true; $('ld-msg').hidden = false; ld.hidden = false;
    const quality = (function () { try { return localStorage.getItem('wc_quality') === 'high' ? 'high' : 'low'; } catch (e) { return 'low'; } })();
    try {
      const feats = await WC.geo.loadWorld(quality, m => $('ld-msg').textContent = m);
      $('ld-msg').textContent = 'ساخت جهان…';
      await new Promise(r => setTimeout(r, 30));
      WC.provs = WC.geo.buildProvinces(feats);
      R.setProvinces(WC.provs);
      WC.newGame(WC.provs, -1, 'normal');
      ld.hidden = true;
      UI.showMenu();
      R.menuDrift = 0;
      window.__WC_READY = true;
    } catch (e) {
      console.error(e);
      $('ld-msg').hidden = true; err.hidden = false;
    }
  }
  $('ld-retry').addEventListener('click', boot);
  R.init($('map'));
  boot();
})(window.WC);
