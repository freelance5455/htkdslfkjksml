/* فرمان جهان — قوانین بازی v2: استان‌ها، اقتصاد، ژنرال‌ها، ناوگان، دیپلماسی و هوش مصنوعی */
(function (WC) {
  const TYPES = WC.TYPES, U = WC.UNITS, SH = WC.SHIPS, ST = WC.SHIP_TYPES, GOVS = WC.GOVS, TR = WC.TRAITS, W = 2000;
  let G = null;
  const L = {};
  WC.on = (e, f) => { (L[e] = L[e] || []).push(f); };
  WC.emit = (e, d) => { (L[e] || []).forEach(f => { try { f(d); } catch (err) { console.error(err); } }); };
  const rnd = Math.random, sleep = ms => new Promise(r => setTimeout(r, ms));
  const rr = x => { const f = Math.floor(x); return f + (rnd() < x - f ? 1 : 0); };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const emptyU = () => ({ inf: 0, tank: 0, art: 0, air: 0 });
  const emptyS = () => ({ boat: 0, frig: 0, dest: 0, trans: 0 });
  const DIFF = {
    easy:   { aggr: 0.03, income: 0.85, thr: 1.8, fort: 1.0, label: 'سرباز' },
    normal: { aggr: 0.06, income: 1.0,  thr: 1.35, fort: 1.0, label: 'سرهنگ' },
    hard:   { aggr: 0.10, income: 1.2,  thr: 1.05, fort: 1.1, label: 'ژنرال' }
  };
  const TECH_MAX = 5, NUKE_TECH_COST = 800, NUKE_COST = 250;
  const techCost = (n, lvl) => Math.round(100 * (lvl + 1) * (1 - (TR[n.leader.trait].res || 0)));
  const UPKEEP = { inf: 0.12, tank: 0.45, art: 0.35, air: 0.55 }, SUPKEEP = { boat: 0.25, frig: 0.6, dest: 1.4, trans: 0.5 };
  const FLEET_SPEED = 14, TRADER_SPEED = 16;
  const PALETTE = [[205,60,46],[2,60,48],[135,42,40],[282,42,48],[168,52,38],[24,68,50],[332,52,50],[96,46,40],[240,46,56],[186,58,40],[350,44,38],[62,50,40],[312,38,40],[150,48,32],[14,48,38],[222,34,42],[110,34,30],[262,48,40]];

  const unitPower = u => { let s = 0; for (const t of TYPES) s += (u[t] || 0) * U[t].pw; return s; };
  const totalUnits = u => { let s = 0; for (const t of TYPES) s += (u[t] || 0); return s; };
  const shipPower = s => { let v = 0; for (const t of ST) v += (s[t] || 0) * SH[t].pw; return v; };
  const shipCount = s => ST.reduce((a, t) => a + (s[t] || 0), 0);
  const warCount = s => (s.boat || 0) + (s.frig || 0) + (s.dest || 0);
  const relKey = (a, b) => a < b ? a + '_' + b : b + '_' + a;
  const cssColor = c => {
    const f = (h, s, l, a) => a == null ? `hsl(${h.toFixed(0)},${s}%,${l}%)` : `hsla(${h.toFixed(0)},${s}%,${l}%,${a})`;
    return { fill: f(c.h, c.s, c.l), hi: f(c.h, Math.min(95, c.s + 6), Math.min(82, c.l + 16)), dk: f(c.h, c.s, Math.max(10, c.l - 20)), glow: f(c.h, c.s, Math.min(85, c.l + 25), 0.55), hex: f(c.h, c.s, c.l) };
  };
  const inv = (x, y) => { const v = -y / (1.25 * WC.geo.K); return [x / W * 360 - 180, (Math.atan(Math.exp(v)) - Math.PI / 4) / 0.4 * 180 / Math.PI]; };

  // ---------- راه‌اندازی ----------
  WC.newGame = function (countries, provs, playerId, diff) {
    G = WC.G = { countries, provinces: provs, nations: [], rel: {}, turn: 1, player: playerId, diff: DIFF[diff] ? diff : 'normal', log: [], offers: [], busy: false, won: false, over: false, outrage: 0, stats: { battles: 0, captured: 0, lost: 0, sunk: 0 }, fleets: [], traders: [], nextId: 1, sail: null, _own: null, pcache: new Map() };
    initProvinces(); initNations(); initColors(); initForces();
    if (playerId >= 0) log(`فرماندهی ${G.nations[playerId].name} را بر عهده گرفتید. جهان در انتظار است.`, 'big');
    WC.emit('state');
    return G;
  };

  function initProvinces() {
    const cs = G.countries, ps = G.provinces;
    const big = new Set(cs.slice().sort((a, b) => b.area - a.area).slice(0, 22).map(c => c.id));
    cs.forEach(c => {
      const st = WC.STATS[c.name];
      if (st) { c.mil = st[0]; c.econ = st[1]; }
      else { c.mil = 1 + Math.floor(WC.hash(c.name + 'm') * 2.99) + (big.has(c.id) ? 1 : 0); c.econ = 1 + Math.floor(WC.hash(c.name + 'e') * 2.99) + (big.has(c.id) ? 1 : 0); }
      const k = c.provs.length;
      const ws = c.provs.map((pid, i) => Math.pow(Math.max(0.05, ps[pid].share * k), 0.7) * (i === 0 ? 1.5 : 1) * (0.85 + 0.3 * WC.hash(c.name + i)));
      const sum = ws.reduce((a, b) => a + b, 0), target = Math.pow(k, 0.8);
      c.provs.forEach((pid, i) => {
        const p = ps[pid], w = ws[i] / sum * target;
        p.w = w; p.pop = (1.5 + c.econ * 0.5) * w; p.ind = (0.5 + c.econ * 0.55) * w * (i === 0 ? 1.2 : 1);
        p.trade = (p.coastal ? 0.8 + 0.35 * c.econ : 0.3 + 0.1 * c.econ) * w;
        const h = WC.hash(c.name + 'r' + i);
        p.resType = 'none'; p.res = 0;
        if (WC.OIL.has(c.name) && h < 0.5) { p.resType = 'oil'; p.res = (0.8 + 0.25 * c.econ) * w; }
        else if (WC.MINE.has(c.name) && h < 0.45) { p.resType = 'mine'; p.res = (0.8 + 0.2 * c.econ) * w; }
        else if (WC.FARM.has(c.name) || h < 0.3) { p.resType = 'farm'; p.res = (0.6 + 0.12 * c.econ) * w; }
        p.eco = clamp(Math.round(c.econ * Math.min(1.4, 0.6 + 0.5 * w)), 1, 10);
        p.owner = c.id; p.units = emptyU(); p.ships = emptyS(); p.general = null; p.acted = false; p.occ = 99; p.irr = 0; p.rec = 0; p.srec = 0; p.built = false; p.blockade = 0;
        p.bld = { factory: c.econ >= 7 && w > 0.9 ? 1 : 0, market: i === 0 && c.econ >= 4 ? 1 : 0, port: p.coastal ? 1 : 0, fort: 0, barracks: 0 };
      });
    });
    G._own = null;
  }
  function initNations() {
    G.countries.forEach(c => {
      const gov = WC.govOf(c.name), ll = inv(c.anchor.x, c.anchor.y), cult = WC.cultureOf(c.name, ll[0], ll[1]);
      const keys = Object.keys(TR);
      const n = {
        id: c.id, name: c.fa, en: c.name, money: 80 + c.econ * 20, tech: { atk: 0, def: 0, eco: 0, nuke: false }, alive: true, isPlayer: c.id === G.player, nukeCd: 0,
        gov, culture: cult, tax: 1, stab: 72, capital: c.provs[0], tradeEarned: 0, budget: null,
        leader: { title: WC.leaderTitle(gov, c.name), name: WC.randName(cult, c.name + 'L0'), trait: keys[Math.floor(WC.hash(c.name + 'trait') * keys.length)], since: 1 }
      };
      G.nations.push(n);
    });
  }
  function initColors() {
    const cs = G.countries, order = cs.map(c => c.id).sort((a, b) => cs[b].nb.size - cs[a].nb.size), used = new Array(PALETTE.length).fill(0), pick = new Array(cs.length).fill(-1);
    order.forEach(id => {
      const bad = new Set();
      cs[id].nb.forEach(o => { if (pick[o] >= 0) bad.add(pick[o]); cs[o].nb.forEach(o2 => { if (pick[o2] >= 0 && cs[id].nb.size < 6) bad.add(pick[o2]); }); });
      let best = -1, bu = 1e9;
      PALETTE.forEach((_, i) => { if (!bad.has(i) && used[i] < bu) { bu = used[i]; best = i; } });
      if (best < 0) { cs[id].nb.forEach(o => { }); const nb1 = new Set(); cs[id].nb.forEach(o => { if (pick[o] >= 0) nb1.add(pick[o]); }); PALETTE.forEach((_, i) => { if (!nb1.has(i) && used[i] < bu) { bu = used[i]; best = i; } }); }
      if (best < 0) best = id % PALETTE.length;
      pick[id] = best; used[best]++;
    });
    G.nations.forEach(n => { const q = PALETTE[pick[n.id]]; n.color = n.isPlayer ? { h: 44, s: 80, l: 54 } : { h: q[0], s: q[1], l: q[2] }; n.css = cssColor(n.color); });
  }
  function initForces() {
    G.countries.forEach(c => {
      const m = Math.pow(c.mil, 1.5), tot = { inf: Math.round(2 * m) + 2, tank: c.mil >= 3 ? Math.round(0.35 * m) : 0, art: c.mil >= 2 ? Math.round(0.3 * m) : 0, air: c.mil >= 4 ? Math.round(0.25 * m) : 0 };
      const ps = c.provs.map(i => G.provinces[i]), wsum = ps.reduce((a, p) => a + p.w, 0);
      TYPES.forEach(t => { let left = tot[t]; ps.forEach((p, i) => { const v = i === ps.length - 1 ? left : Math.min(left, Math.round(tot[t] * p.w / wsum)); p.units[t] = v; left -= v; }); });
      const ports = ps.filter(p => p.port).sort((a, b) => b.w - a.w).slice(0, 3);
      if (ports.length && c.mil >= 2) {
        const tt = { boat: Math.round(c.mil * 0.6), frig: Math.max(0, Math.round((c.mil - 2) * 0.7)), dest: c.mil >= 5 ? Math.round((c.mil - 4) * 0.6) : 0, trans: Math.ceil(c.mil * 0.35) };
        ST.forEach(t => { for (let i = 0; i < tt[t]; i++) ports[i % ports.length].ships[t]++; });
      }
      ps.forEach(ensureGeneral);
    });
  }

  // ---------- ابزارها ----------
  const nat = id => G.nations[id], prov = id => G.provinces[id];
  const rel = (a, b) => G.rel[relKey(a, b)] || (G.rel[relKey(a, b)] = { state: 'peace', since: 0, truce: 0 });
  const atWar = (a, b) => a !== b && rel(a, b).state === 'war';
  const allied = (a, b) => a !== b && rel(a, b).state === 'ally';
  function ownedProvs(id) { if (!G._own) { G._own = G.nations.map(() => []); G.provinces.forEach(p => G._own[p.owner].push(p)); } return G._own[id]; }
  function setOwner(p, o) { p.owner = o; G._own = null; }
  const natPower = id => ownedProvs(id).reduce((s, p) => s + unitPower(p.units) + shipPower(p.ships), 0) + G.fleets.reduce((s, f) => s + (f.owner === id ? shipPower(f.ships) : 0), 0);
  const wars = id => G.nations.filter(n => n.alive && atWar(id, n.id));
  function log(msg, kind) { if (!msg) return; G.log.unshift({ turn: G.turn, msg, kind: kind || '' }); if (G.log.length > 250) G.log.length = 250; WC.emit('log', { msg, kind }); }
  function neighborNations(id) { const s = new Set(); ownedProvs(id).forEach(p => p.neighbors.forEach(l => { const o = prov(l.to).owner; if (o !== id) s.add(o); })); return [...s]; }
  const linkBetween = (a, b) => prov(a).neighbors.find(l => l.to === b) || null;
  const gm = n => GOVS[n.gov].mods, tt = n => TR[n.leader.trait];
  const rankName = g => WC.RANKS[g.skill] || 'سرهنگ';

  function ensureGeneral(p) {
    if (p.general || unitPower(p.units) < 25) return;
    const n = nat(p.owner);
    p.general = { name: WC.randName(n.culture, n.en + p.id + G.turn + (G.nextId++)), skill: 1 + Math.floor(rnd() * 3), xp: 0 };
  }

  // ---------- اقتصاد ----------
  const occF = p => p.owner === p.c ? 1 : Math.min(1, 0.45 + 0.11 * p.occ);
  function provYield(p, n) {
    const g = gm(n), taxMul = [0.75, 1, 1.3][n.tax] * (1 + (g.tax || 0)), occ = occF(p);
    const m = occ * (p.irr > 0 ? 0.4 : 1) * (1 + 0.1 * n.tech.eco);
    const resv = p.resType === 'oil' ? p.res * 5.5 : p.resType === 'mine' ? p.res * 4.5 : p.resType === 'farm' ? p.res * 3 : 0;
    let trade = p.trade * 1.4 * (1 + 0.25 * p.bld.market) * (1 + 0.12 * p.bld.port) * (1 + (g.trade || 0));
    if (p.blockade > 0) trade *= 0.2;
    return { tax: p.pop * 2.0 * taxMul * m, ind: p.ind * 1.6 * (1 + 0.3 * p.bld.factory) * m, res: resv * m, trade: trade * m };
  }
  function budget(id) {
    const n = nat(id), ps = ownedProvs(id), b = { tax: 0, ind: 0, res: 0, trade: 0, army: 0, navy: 0, admin: 0, bld: 0, ships: n.tradeEarned || 0 };
    ps.forEach(p => {
      const y = provYield(p, n); b.tax += y.tax; b.ind += y.ind; b.res += y.res; b.trade += y.trade;
      TYPES.forEach(t => b.army += p.units[t] * UPKEEP[t]); ST.forEach(t => b.navy += p.ships[t] * SUPKEEP[t]);
      b.bld += Object.values(p.bld).reduce((a, v) => a + v, 0) * 0.4;
    });
    G.fleets.forEach(f => { if (f.owner === id) ST.forEach(t => b.navy += f.ships[t] * SUPKEEP[t]); });
    b.admin = 0.9 * Math.pow(ps.length, 1.15);
    let mult = 1 + (gm(n).inc || 0) + (tt(n).inc || 0) + (n.isPlayer ? 0 : DIFF[G.diff].income - 1);
    if (n.stab < 15) mult *= 0.7; else if (n.stab < 35) mult *= 0.85;
    b.mult = mult;
    b.gross = (b.tax + b.ind + b.res + b.trade) * mult;
    b.cost = b.army + b.navy + b.admin + b.bld;
    b.net = b.gross - b.cost;
    return b;
  }
  const natIncome = id => Math.round(budget(id).net);
  const provIncome = p => { const n = nat(p.owner), y = provYield(p, n); return Math.round((y.tax + y.ind + y.res + y.trade) * budget.mult0(n)); };
  budget.mult0 = n => 1 + (gm(n).inc || 0) + (tt(n).inc || 0) + (n.isPlayer ? 0 : DIFF[G.diff].income - 1);
  const prodCap = p => Math.round((4 + Math.round(p.pop * 1.2) + 4 * p.bld.barracks) * (1 + (gm(nat(p.owner)).recruit || 0) + (tt(nat(p.owner)).recruit || 0)));
  const shipCap = p => p.port ? 2 + 3 * p.bld.port : 0;

  // ---------- نبرد زمینی ----------
  const genMul = p => p.general ? 1 + 0.06 * p.general.skill : 1;
  const aMulOf = (p, sea) => { const n = nat(p.owner); return (1 + 0.12 * n.tech.atk) * (1 + (gm(n).atk || 0) + (tt(n).atk || 0)) * genMul(p) * (sea ? 0.85 : 1); };
  const dMulOf = p => { const n = nat(p.owner); return (1 + 0.12 * n.tech.def) * (1 + (gm(n).def || 0) + (tt(n).def || 0)) * genMul(p) * fortOf(p); };
  function fortOf(p) { const n = nat(p.owner); return (1.25 + 0.1 * p.bld.fort + (p.isCap && p.owner === p.c ? 0.12 : 0)) * (n.isPlayer ? 1 : DIFF[G.diff].fort); }
  const attL = u => { let s = 0; for (const t of TYPES) s += (u[t] || 0) * U[t].atk; return s; };
  const defL = u => { let s = 0; for (const t of TYPES) s += (u[t] || 0) * U[t].def; return s; };
  const shipAtk = s => ST.reduce((a, t) => a + (s[t] || 0) * SH[t].atk, 0), shipDef = s => ST.reduce((a, t) => a + (s[t] || 0) * SH[t].def, 0);
  function simulate(sent, defU, aMul, dMul, bombard, shipDefPow) {
    const a = Object.assign({}, sent), d = Object.assign({}, defU), aT = Object.assign({}, a), dT = Object.assign({}, d);
    for (let r = 0; r < 4; r++) {
      const aP = (attL(a) * aMul + bombard) * (0.85 + rnd() * 0.3), dP = (defL(d) * dMul + shipDefPow) * (0.85 + rnd() * 0.3);
      if (aP <= 0.01 || dP <= 0.01) break;
      const fD = Math.min(1, 0.5 * aP / dP), fA = Math.min(1, 0.5 * dP / aP);
      for (const t of TYPES) { d[t] *= (1 - fD); a[t] *= (1 - fA); }
      if (totalUnits(d) < 0.6 || totalUnits(a) < 0.6) break;
    }
    const aE = {}, dE = {}; for (const t of TYPES) { aE[t] = rr(a[t]); dE[t] = rr(d[t]); }
    return { aEnd: aE, dEnd: dE, aStart: aT, dStart: dT };
  }
  function navalSim(a0, d0, aMul, dMul) {
    const a = Object.assign({}, a0), d = Object.assign({}, d0);
    for (let r = 0; r < 4; r++) {
      const aP = shipAtk(a) * aMul * (0.85 + rnd() * 0.3), dP = Math.max(0.01, shipDef(d) * dMul) * (0.85 + rnd() * 0.3);
      if (aP <= 0.01) break;
      const fD = Math.min(1, 0.5 * aP / dP), fA = Math.min(1, 0.5 * Math.max(shipAtk(d) * dMul, 0.01) * (0.85 + rnd() * 0.3) / Math.max(0.01, shipDef(a) * aMul));
      for (const t of ST) { d[t] *= (1 - fD); a[t] *= (1 - Math.min(1, fA)); }
      if (shipCount(d) < 0.6 || shipCount(a) < 0.6) break;
    }
    const A = {}, D = {}; ST.forEach(t => { A[t] = rr(a[t]); D[t] = rr(d[t]); });
    return { A, D };
  }
  const navMul = (n, off) => (1 + 0.12 * (off ? n.tech.atk : n.tech.def)) * (1 + (off ? (gm(n).atk || 0) + (tt(n).atk || 0) : (gm(n).def || 0) + (tt(n).def || 0)));
  function seaPath(src, dst) {
    const a = src.port && src.port.cell, b = dst.port ? dst.port.cell : WC.geo.SEA.near(dst.seed.x, dst.seed.y, 8);
    if (!a || !b) return null;
    const key = a.join(',') + '|' + b.join(','); if (G.pcache.has(key)) return G.pcache.get(key);
    const p = WC.geo.SEA.path(a, b); G.pcache.set(key, p); return p;
  }
  const cellDist = (a, b) => { const gw = WC.geo.SEA.gw; let dx = Math.abs(a[0] - b[0]) % gw; dx = Math.min(dx, gw - dx); return Math.hypot(dx, a[1] - b[1]); };
  const fleetCell = f => f.path ? f.path[Math.min(f.path.length - 1, Math.round(f.pi))] : f.cell;

  function order(srcId, dstId, frac, who) {
    const src = prov(srcId), dst = prov(dstId), link = linkBetween(srcId, dstId);
    if (!link) return { ok: false, msg: 'این دو استان به هم راه ندارند.' };
    if (src.acted) return { ok: false, msg: 'این استان در این نوبت فرمان داده است.' };
    const A = nat(src.owner), friendly = dst.owner === src.owner || allied(src.owner, dst.owner), sea = link.sea;
    if (!friendly && !atWar(src.owner, dst.owner)) return { ok: false, msg: 'با این کشور در جنگ نیستید.', needWar: dst.owner };
    const sent = emptyU();
    for (const t of TYPES) sent[t] = frac >= 0.999 ? src.units[t] : Math.floor(src.units[t] * frac + 1e-9);
    let path = null, escort = 0;
    if (sea) {
      if (!src.port || src.ships.trans < 1) return { ok: false, msg: 'برای عبور از دریا ناو ترابری در بندر این استان لازم است.' };
      path = seaPath(src, dst); if (!path) return { ok: false, msg: 'مسیر دریایی پیدا نشد.' };
      const cap = src.ships.trans * SH.trans.cap, land = sent.inf + sent.tank + sent.art;
      if (land > cap) { const k = cap / land; ['inf', 'tank', 'art'].forEach(t => sent[t] = Math.floor(sent[t] * k)); }
    }
    if (totalUnits(sent) <= 0) return { ok: false, msg: 'نیرویی برای ارسال نیست.' };
    if (friendly) {
      for (const t of TYPES) { src.units[t] -= sent[t]; dst.units[t] += sent[t]; }
      if (frac >= 0.5 && src.general && !dst.general) { dst.general = src.general; src.general = null; }
      src.acted = true; if (dst.owner === src.owner) dst.acted = true;
      WC.emit('move', { src, dst, sea, path, who });
      return { ok: true, kind: 'move' };
    }
    if (sent.inf + sent.tank < 1) return { ok: false, msg: 'برای حمله به پیاده‌نظام یا تانک نیاز است.' };
    const D = nat(dst.owner);
    let bombard = 0, sdef = 0, seaLost = false;
    if (sea) {
      bombard = shipAtk(src.ships) * navMul(A, true);
      sdef = shipDef(dst.ships) * 0.6;
      // رهگیری توسط ناوگان دشمن در مسیر
      const foes = G.fleets.filter(f => atWar(f.owner, src.owner) && warCount(f.ships) > 0 && path.some((c, i) => i % 2 === 0 && cellDist(c, fleetCell(f)) <= 3));
      if (foes.length) {
        const fp = foes.reduce((s, f) => s + shipAtk(f.ships), 0), ep = shipAtk(src.ships) * 0.5 + 1;
        if (rnd() < fp / (fp + ep) * 0.85) seaLost = true;
        if (seaLost) {
          const lost = Math.min(src.ships.trans, 1 + Math.floor(rnd() * 2)); src.ships.trans -= lost;
          for (const t of TYPES) { src.units[t] -= sent[t]; }
          src.acted = true; G.stats.lost += totalUnits(sent);
          log(`کاروان دریایی ${A.name} به مقصد ${dst.name} توسط ناوگان دشمن نابود شد.`, src.owner === G.player ? 'war' : '');
          WC.emit('convoy', { path, owner: src.owner, sunk: true });
          return { ok: true, kind: 'attack', captured: false, aL: totalUnits(sent), dL: 0, seaLost: true };
        }
      }
      WC.emit('convoy', { path, owner: src.owner });
    }
    const res = simulate(sent, dst.units, aMulOf(src, sea), dMulOf(dst), bombard, sdef);
    for (const t of TYPES) src.units[t] -= sent[t];
    const atkLoss = {}, defLoss = {}; let aL = 0, dL = 0;
    for (const t of TYPES) { atkLoss[t] = sent[t] - res.aEnd[t]; defLoss[t] = dst.units[t] - res.dEnd[t]; aL += atkLoss[t]; dL += defLoss[t]; }
    const captured = totalUnits(res.dEnd) === 0 && res.aEnd.inf + res.aEnd.tank > 0, oldOwner = dst.owner;
    src.acted = true; G.stats.battles++;
    const sGen = src.general, dGen = dst.general;
    if (captured) {
      dst.units = emptyU(); for (const t of ['inf', 'tank', 'art']) dst.units[t] = res.aEnd[t];
      src.units.air += res.aEnd.air;
      dst.ships = emptyS();
      Object.keys(dst.bld).forEach(k => { if (dst.bld[k] > (k === 'port' ? 1 : 0) && rnd() < 0.4) dst.bld[k]--; });
      setOwner(dst, src.owner); dst.occ = 0; dst.acted = true; dst.irr = 0; dst.general = null; dst.blockade = 0;
      if (frac >= 0.5 && sGen) { dst.general = sGen; src.general = null; }
      if (sGen) { sGen.xp++; if (sGen.xp >= 3 * sGen.skill && sGen.skill < 5) { sGen.skill++; sGen.xp = 0; if (src.owner === G.player || oldOwner === G.player) log(`${rankName(sGen)} ${sGen.name} به درجهٔ بالاتر ارتقا یافت.`, ''); } }
      if (dGen && rnd() < 0.5) log(`${dGen.name}، فرمانده ${D.name} در ${dst.name} کشته یا اسیر شد.`, '');
      if (G.player === src.owner) G.stats.captured++;
      if (dst.isCap && dst.c === oldOwner && ownedProvs(oldOwner).length) { const best = ownedProvs(oldOwner).slice().sort((a, b) => b.w - a.w)[0]; D.capital = best.id; log(`پایتخت ${D.name} به ${best.name} منتقل شد.`, ''); }
      if (ownedProvs(oldOwner).length === 0) eliminate(oldOwner, src.owner);
    } else {
      for (const t of TYPES) { src.units[t] += res.aEnd[t]; dst.units[t] = res.dEnd[t]; }
      if (dGen && dL > 0 && rnd() < 0.05) { dst.general = null; }
      if (sGen && aL > sent.inf * 0.6 && rnd() < 0.15) { src.general = null; log(`${rankName(sGen)} ${sGen.name} در نبرد ${dst.name} کشته شد.`, src.owner === G.player ? 'war' : ''); }
      if (dGen) { dGen.xp++; if (dGen.xp >= 3 * dGen.skill && dGen.skill < 5) { dGen.skill++; dGen.xp = 0; } }
    }
    const info = { src, dst, sea, captured, atkLoss, defLoss, aL, dL, attacker: src.owner, defender: oldOwner, who, path };
    WC.emit('attack', info);
    checkEnd();
    return { ok: true, kind: 'attack', captured, aL, dL };
  }

  function eliminate(id, by) {
    const n = nat(id); n.alive = false;
    Object.keys(G.rel).forEach(k => { const [a, b] = k.split('_').map(Number); if (a === id || b === id) G.rel[k].state = 'peace'; });
    G.offers = G.offers.filter(o => o.from !== id);
    G.fleets = G.fleets.filter(f => f.owner !== id); G.traders = G.traders.filter(t => t.owner !== id);
    log(`${n.name} سقوط کرد و به خاک ${nat(by).name} پیوست.`, 'big');
    WC.emit('fall', { id, by });
  }

  // ---------- ناوگان ----------
  function sendFleet(pid, frac, withTrans) {
    const p = prov(pid); if (!p.port || p.acted && false) return { ok: false, msg: 'این استان بندر ندارد.' };
    const ships = emptyS();
    ['boat', 'frig', 'dest'].forEach(t => { ships[t] = Math.floor(p.ships[t] * frac + 1e-9); if (frac >= 0.999) ships[t] = p.ships[t]; });
    if (withTrans) ships.trans = Math.floor(p.ships.trans * frac + 1e-9);
    if (shipCount(ships) <= 0) return { ok: false, msg: 'کشتی‌ای برای اعزام نیست.' };
    ST.forEach(t => p.ships[t] -= ships[t]);
    const f = { id: G.nextId++, owner: p.owner, ships, path: null, pi: 0, cell: p.port.cell.slice(), home: pid, dockTo: -1, anim: null };
    G.fleets.push(f); WC.emit('state');
    return { ok: true, fleet: f };
  }
  function fleetMove(fid, target) { // target: {cell} یا {prov}
    const f = G.fleets.find(x => x.id === fid); if (!f) return { ok: false, msg: '' };
    let cell = target.cell, dock = -1;
    if (target.prov != null) { const p = prov(target.prov); if (!p.port) return { ok: false, msg: 'این استان بندر ندارد.' }; cell = p.port.cell; if (p.owner === f.owner || allied(f.owner, p.owner)) dock = p.id; else if (!atWar(f.owner, p.owner)) return { ok: false, msg: 'ورود به بندر کشور بی‌طرف ممکن نیست.' }; }
    const SEA = WC.geo.SEA, from = fleetCell(f), to = SEA.isOcean(cell[0], cell[1]) ? cell : SEA.near(SEA.center(cell[0], cell[1])[0], SEA.center(cell[0], cell[1])[1], 4);
    if (!to) return { ok: false, msg: 'مقصد دریایی نیست.' };
    const path = SEA.path([((from[0] % SEA.gw) + SEA.gw) % SEA.gw, from[1]], [((to[0] % SEA.gw) + SEA.gw) % SEA.gw, to[1]]);
    if (!path) return { ok: false, msg: 'مسیر دریایی پیدا نشد.' };
    f.path = path; f.pi = 0; f.cell = from; f.dockTo = dock; f.target = target.prov != null ? target.prov : -1;
    WC.emit('state');
    return { ok: true, eta: Math.ceil(path.length / FLEET_SPEED) };
  }
  function dockFleet(f) {
    const p = prov(f.dockTo); if (!p || (p.owner !== f.owner && !allied(f.owner, p.owner))) { f.dockTo = -1; return false; }
    ST.forEach(t => p.ships[t] += f.ships[t]); G.fleets = G.fleets.filter(x => x !== f); return true;
  }
  function buildShip(pid, type, qty) {
    const p = prov(pid), n = nat(p.owner), s = SH[type];
    if (!p.port) return { ok: false, msg: 'این استان بندر ندارد.' };
    const room = shipCap(p) - p.srec; qty = Math.min(qty, room, Math.floor(n.money / s.cost));
    if (qty <= 0) return { ok: false, msg: room <= 0 ? 'ظرفیت بندر در این نوبت پر است.' : 'پول کافی نیست.' };
    n.money -= qty * s.cost; p.ships[type] += qty; p.srec += qty; WC.emit('recruit', { p, type, qty, ship: true });
    return { ok: true, qty };
  }
  function recruit(pid, type, qty) {
    const p = prov(pid), n = nat(p.owner), u = U[type];
    const room = prodCap(p) - p.rec; qty = Math.min(qty, room, Math.floor(n.money / u.cost));
    if (qty <= 0) return { ok: false, msg: room <= 0 ? 'ظرفیت تولید این استان در این نوبت پر است.' : 'پول کافی نیست.' };
    n.money -= qty * u.cost; p.units[type] += qty; p.rec += qty; ensureGeneral(p); WC.emit('recruit', { p, type, qty });
    return { ok: true, qty };
  }
  function build(pid, key) {
    const p = prov(pid), n = nat(p.owner), b = WC.BUILDINGS[key], lvl = p.bld[key];
    if (p.built) return { ok: false, msg: 'در هر نوبت فقط یک ساخت‌وساز در هر استان.' };
    if (lvl >= b.max) return { ok: false, msg: 'به حداکثر رسیده.' };
    if (key === 'port' && !p.port) return { ok: false, msg: 'این استان ساحلی نیست.' };
    const c = b.cost * (lvl + 1); if (n.money < c) return { ok: false, msg: 'پول کافی نیست.' };
    n.money -= c; p.bld[key]++; p.built = true; WC.emit('build', { p, key }); WC.emit('state');
    return { ok: true };
  }

  async function sailPhase() {
    const moving = [...G.fleets.filter(f => f.path && f.pi < f.path.length - 1), ...G.traders];
    if (!moving.length) return;
    G.fleets.concat(G.traders).forEach(o => { if (!o.path) return; const sp = o.ships ? FLEET_SPEED : TRADER_SPEED; o.anim = { from: o.pi, to: Math.min(o.path.length - 1, o.pi + sp) }; });
    G.sail = { t0: performance.now(), dur: 1500 };
    WC.emit('sail', G.sail);
    await sleep(1550);
    G.fleets.concat(G.traders).forEach(o => { if (o.anim) { o.pi = o.anim.to; o.anim = null; } });
    G.sail = null;
    // رسیدن
    G.fleets.slice().forEach(f => { if (f.path && f.pi >= f.path.length - 1) { f.cell = f.path[f.path.length - 1]; f.path = null; f.pi = 0; if (f.dockTo >= 0) dockFleet(f); } });
    G.traders.slice().forEach(t => {
      if (t.pi < t.path.length - 1) return;
      G.traders = G.traders.filter(x => x !== t);
      const to = prov(t.to), me = nat(t.owner); if (!me.alive) return;
      if (atWar(t.owner, to.owner) || !nat(to.owner).alive) return;
      me.tradeEarned += t.value; me.money += t.value;
      if (to.owner !== t.owner) { nat(to.owner).money += t.value * 0.5; nat(to.owner).tradeEarned += t.value * 0.5; }
    });
    navalPhase();
  }
  function navalPhase() {
    const SEA = WC.geo.SEA, pos = f => SEA.center(...fleetCell(f));
    // نبرد ناوگان‌ها
    for (let i = 0; i < G.fleets.length; i++) for (let j = i + 1; j < G.fleets.length; j++) {
      const a = G.fleets[i], b = G.fleets[j]; if (!a || !b || !atWar(a.owner, b.owner) || !warCount(a.ships) && !warCount(b.ships)) continue;
      if (cellDist(fleetCell(a), fleetCell(b)) > 2.6) continue;
      const A = nat(a.owner), B = nat(b.owner), r = navalSim(a.ships, b.ships, navMul(A, true), navMul(B, false)), r2 = navalSim(b.ships, a.ships, navMul(B, true), navMul(A, false));
      const na = {}, nb = {}; ST.forEach(t => { na[t] = Math.min(r.A[t], r2.D[t]); nb[t] = Math.min(r.D[t], r2.A[t]); });
      const lostA = shipCount(a.ships) - shipCount(na), lostB = shipCount(b.ships) - shipCount(nb);
      a.ships = na; b.ships = nb; G.stats.sunk += lostA + lostB;
      const p = pos(a); WC.emit('navalBattle', { x: p[0], y: p[1], a: a.owner, b: b.owner, lostA, lostB });
      log(`نبرد دریایی: ${A.name} ${WC.fa(lostA)} کشتی، ${B.name} ${WC.fa(lostB)} کشتی از دست داد.`, a.owner === G.player || b.owner === G.player ? 'war' : '');
    }
    G.fleets = G.fleets.filter(f => shipCount(f.ships) > 0);
    // محاصره و گلوله‌باران بنادر
    G.fleets.forEach(f => {
      if (!warCount(f.ships) || f.path) return;
      const fc = fleetCell(f);
      G.provinces.forEach(p => {
        if (!p.port || !atWar(f.owner, p.owner) || cellDist(fc, p.port.cell) > 2.4) return;
        const A = nat(f.owner), D = nat(p.owner);
        if (warCount(p.ships)) {
          const r = navalSim(f.ships, p.ships, navMul(A, true), navMul(D, false) * 1.1), r2 = navalSim(p.ships, f.ships, navMul(D, true), navMul(A, false));
          const nf = {}, np = {}; ST.forEach(t => { nf[t] = Math.min(r.A[t], r2.D[t]); np[t] = Math.min(r.D[t], r2.A[t]); });
          const lf = shipCount(f.ships) - shipCount(nf), lp = shipCount(p.ships) - shipCount(np); f.ships = nf; p.ships = np; G.stats.sunk += lf + lp;
          const q = pos(f); WC.emit('navalBattle', { x: q[0], y: q[1], a: f.owner, b: p.owner, lostA: lf, lostB: lp });
          log(`نبرد بندر ${p.name}: ${A.name} ${WC.fa(lf)} و ${D.name} ${WC.fa(lp)} کشتی از دست دادند.`, f.owner === G.player || p.owner === G.player ? 'war' : '');
        }
        if (shipCount(f.ships) > 0) {
          p.blockade = 2;
          const k = Math.min(0.25, shipAtk(f.ships) / (shipAtk(f.ships) + defL(p.units) * 0.8 + 1) * 0.25);
          let lost = 0; TYPES.forEach(t => { const d = Math.floor(p.units[t] * k); p.units[t] -= d; lost += d; });
          if (lost > 0) { const q = prov(p.id).port; WC.emit('bombard', { x: q.x, y: q.y }); log(`ناوگان ${A.name} ${p.name} را گلوله‌باران کرد (${WC.fa(lost)} نیرو نابود شد).`, p.owner === G.player ? 'war' : ''); }
        }
      });
    });
    G.fleets = G.fleets.filter(f => shipCount(f.ships) > 0);
    // شکار کشتی‌های تجاری
    G.traders.slice().forEach(t => {
      const tc = t.path[Math.min(t.path.length - 1, Math.round(t.pi))];
      const raider = G.fleets.find(f => warCount(f.ships) && atWar(f.owner, t.owner) && cellDist(tc, fleetCell(f)) <= 2.4);
      if (!raider) return;
      G.traders = G.traders.filter(x => x !== t); nat(raider.owner).money += Math.round(t.value * 0.5);
      const q = SEA.center(tc[0], tc[1]); WC.emit('bombard', { x: q[0], y: q[1] });
      log(`کشتی تجاری ${nat(t.owner).name} توسط ${nat(raider.owner).name} غرق شد.`, t.owner === G.player || raider.owner === G.player ? 'war' : '');
    });
  }
  function spawnTraders() {
    if (G.traders.length >= 44) return;
    const SEA = WC.geo.SEA;
    G.nations.forEach(n => {
      if (!n.alive || G.traders.length >= 44) return;
      const ports = ownedProvs(n.id).filter(p => p.port && p.blockade <= 0); if (!ports.length) return;
      if (rnd() > 0.5 * Math.min(1.6, Math.sqrt(ports.length))) return;
      const from = ports[Math.floor(rnd() * ports.length)];
      let best = null, bd = 0;
      for (let k = 0; k < 10; k++) {
        const q = G.provinces[Math.floor(rnd() * G.provinces.length)];
        if (!q.port || q.id === from.id || atWar(n.id, q.owner) || !nat(q.owner).alive) continue;
        const d = cellDist(from.port.cell, q.port.cell); if (d > 8 && d < 120 && d > bd * (0.6 + rnd() * 0.6)) { bd = d; best = q; }
      }
      if (!best) return;
      const key = from.port.cell.join(',') + '|' + best.port.cell.join(','); let path = G.pcache.get(key);
      if (path === undefined) { path = SEA.path(from.port.cell, best.port.cell); G.pcache.set(key, path); }
      if (!path || path.length < 4) return;
      G.traders.push({ id: G.nextId++, owner: n.id, from: from.id, to: best.id, path, pi: 0, value: Math.round(6 + 1.3 * (from.eco + best.eco) / 2 + from.bld.port * 2), anim: null });
    });
  }

  // ---------- دیپلماسی ----------
  function declareWar(a, b, silent) {
    if (a === b) return { ok: false, msg: '' };
    const r = rel(a, b);
    if (r.state === 'war') return { ok: false, msg: 'از پیش در جنگ هستید.' };
    if (r.state === 'ally') return { ok: false, msg: 'ابتدا باید اتحاد را لغو کنید.' };
    if (G.turn < r.truce) return { ok: false, msg: `آتش‌بس تا نوبت ${WC.fa(r.truce)} برقرار است.` };
    r.state = 'war'; r.since = G.turn;
    log(`${nat(a).name} به ${nat(b).name} اعلان جنگ کرد!`, 'war'); WC.emit('war', { a, b });
    G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a)));
    if (!silent) G.nations.forEach(c => {
      if (!c.alive || c.id === a || c.id === b || c.isPlayer) return;
      if (allied(c.id, b) && !allied(c.id, a) && !atWar(c.id, a) && rnd() < 0.5) declareWar(c.id, a, true);
      else if (allied(c.id, a) && !allied(c.id, b) && !atWar(c.id, b) && rnd() < 0.5) declareWar(c.id, b, true);
    });
    return { ok: true };
  }
  function makePeace(a, b) { const r = rel(a, b); if (r.state !== 'war') return; r.state = 'peace'; r.since = G.turn; r.truce = G.turn + 6; log(`${nat(a).name} و ${nat(b).name} آتش‌بس کردند.`, 'peace'); G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a))); WC.emit('peace', { a, b }); }
  function makeAlliance(a, b) { const r = rel(a, b); if (r.state === 'war') return; r.state = 'ally'; r.since = G.turn; log(`${nat(a).name} و ${nat(b).name} متحد شدند.`, 'peace'); G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a))); WC.emit('ally', { a, b }); }
  function breakAlliance(a, b) { const r = rel(a, b); if (r.state !== 'ally') return; r.state = 'peace'; r.since = G.turn; r.truce = G.turn + 3; log(`${nat(a).name} اتحاد با ${nat(b).name} را لغو کرد.`, ''); WC.emit('state'); }
  function opinion(a, b) {
    const lo = Math.min(a, b), hi = Math.max(a, b);
    let o = WC.hash(lo + '-' + hi + G.countries[lo].name) * 60 - 25;
    G.nations.forEach(m => { if (!m.alive || m.id === a || m.id === b) return; if (atWar(a, m.id) && atWar(b, m.id)) o += 25; if (atWar(a, m.id) && allied(b, m.id)) o -= 35; if (atWar(b, m.id) && allied(a, m.id)) o -= 35; });
    if (neighborNations(a).includes(b)) o -= 6;
    if (G.outrage > 0 && b === G.player) o -= 45;
    if (natPower(b) > natPower(a)) o += 6;
    o += (tt(nat(a)).dip || 0) + (tt(nat(b)).dip || 0);
    return o;
  }
  function propose(kind, aiId) {
    const me = G.player, ai = nat(aiId);
    if (kind === 'peace') {
      if (!atWar(me, aiId)) return { ok: false, msg: 'در جنگ نیستید.' };
      const dur = G.turn - rel(me, aiId).since, ratio = natPower(aiId) / Math.max(1, natPower(me)), p = ratio < 0.9 ? 0.9 : Math.min(0.85, 0.2 + dur * 0.1 + (tt(nat(me)).dip ? 0.1 : 0));
      if (rnd() < p) { makePeace(me, aiId); return { ok: true, msg: `${ai.name} آتش‌بس را پذیرفت.` }; }
      return { ok: false, msg: `${ai.name} هنوز آماده صلح نیست.` };
    }
    if (kind === 'ally') {
      if (rel(me, aiId).state !== 'peace') return { ok: false, msg: 'اکنون ممکن نیست.' };
      if (opinion(aiId, me) > 10) { makeAlliance(me, aiId); return { ok: true, msg: `${ai.name} با اتحاد موافقت کرد.` }; }
      return { ok: false, msg: `${ai.name} به اتحاد علاقه‌ای نشان نداد.` };
    }
    return { ok: false, msg: '' };
  }
  function answerOffer(idx, accept) { const o = G.offers[idx]; if (!o) return; G.offers.splice(idx, 1); if (accept) { if (o.type === 'peace') makePeace(o.from, G.player); else if (o.type === 'ally') makeAlliance(o.from, G.player); } WC.emit('state'); }

  // ---------- اقدامات بازیکن ----------
  function research(nid, branch) {
    const n = nat(nid);
    if (branch === 'nuke') { if (n.tech.nuke) return { ok: false, msg: 'پیش‌تر به دست آمده.' }; if (n.money < NUKE_TECH_COST) return { ok: false, msg: 'پول کافی نیست.' }; n.money -= NUKE_TECH_COST; n.tech.nuke = true; if (nid === G.player) log('برنامهٔ اتمی به نتیجه رسید.', 'big'); WC.emit('research', {}); return { ok: true }; }
    const lvl = n.tech[branch]; if (lvl >= TECH_MAX) return { ok: false, msg: 'به حداکثر رسیده.' };
    const c = techCost(n, lvl); if (n.money < c) return { ok: false, msg: 'پول کافی نیست.' };
    n.money -= c; n.tech[branch]++; WC.emit('research', {}); return { ok: true };
  }
  function setTax(v) { nat(G.player).tax = v; WC.emit('state'); }
  function nuke(targetId) {
    const me = nat(G.player), t = prov(targetId);
    if (!me.tech.nuke) return { ok: false, msg: 'فناوری اتمی ندارید.' };
    if (me.nukeCd > 0) return { ok: false, msg: `سلاح بعدی تا ${WC.fa(me.nukeCd)} نوبت دیگر آماده می‌شود.` };
    if (me.money < NUKE_COST) return { ok: false, msg: 'پول کافی نیست.' };
    if (!atWar(G.player, t.owner)) return { ok: false, msg: 'فقط به کشورهایی که با آن‌ها در جنگید.' };
    me.money -= NUKE_COST; me.nukeCd = 3;
    const before = totalUnits(t.units); TYPES.forEach(k => t.units[k] = Math.floor(t.units[k] * 0.2)); t.ships = emptyS(); t.irr = 4; G.outrage = 3; t.general = null;
    log(`حملهٔ اتمی به ${t.name}! ${WC.fa(before - totalUnits(t.units))} واحد نابود شد. جهان خشمگین است.`, 'war');
    WC.emit('nuke', { target: t }); return { ok: true };
  }

  // ---------- هوش مصنوعی ----------
  const shuffle = a => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  function aiTurn(n) {
    const diff = DIFF[G.diff], mine = ownedProvs(n.id);
    if (!mine.length) { n.alive = false; return []; }
    aiDiplomacy(n, diff); aiRecruit(n, mine); aiNavy(n, mine);
    const front = frontDist(n), plan = []; let seaOrders = 0;
    shuffle(mine.slice()).forEach(p => plan.push(() => { if (aiProvince(n, p, diff, front, seaOrders < 2)) { if (p._sea) { seaOrders++; p._sea = false; } } }));
    aiResearch(n);
    return plan;
  }
  function aiDiplomacy(n, diff) {
    wars(n.id).forEach(m => {
      const dur = G.turn - rel(n.id, m.id).since; if (dur < 4) return;
      const ratio = natPower(n.id) / Math.max(1, natPower(m.id));
      if (ratio < 0.6 || rnd() < 0.08) {
        if (m.isPlayer) { if (!G.offers.some(o => o.from === n.id && o.type === 'peace')) { G.offers.push({ from: n.id, to: m.id, type: 'peace', turn: G.turn }); WC.emit('offer', {}); } }
        else if (m.alive && natPower(m.id) / Math.max(1, natPower(n.id)) < 1.4 && rnd() < 0.5) makePeace(n.id, m.id);
      }
    });
    if (G.outrage > 0 && !n.isPlayer && !atWar(n.id, G.player) && !allied(n.id, G.player) && rnd() < 0.2) { const r = rel(n.id, G.player); if (G.turn >= r.truce && r.state === 'peace') declareWar(n.id, G.player); }
    const wc = wars(n.id).length; if (wc >= 2) return;
    const myP = natPower(n.id);
    if (rnd() < diff.aggr * (wc ? 0.5 : 1) * (0.6 + n.id % 3 * 0.25) * (1 + (tt(n).atk ? 0.4 : 0))) {
      let best = null, bs = 0;
      neighborNations(n.id).forEach(m => {
        if (!nat(m).alive || allied(n.id, m)) return; const r = rel(n.id, m); if (r.state !== 'peace' || G.turn < r.truce) return;
        let sc = myP / Math.max(1, natPower(m)); if (m === G.player) sc *= G.diff === 'easy' ? 0.7 : G.diff === 'hard' ? 1.3 : 1;
        if (sc > bs) { bs = sc; best = m; }
      });
      const need = G.diff === 'hard' ? 0.9 : G.diff === 'easy' ? 1.7 : 1.25;
      if (best !== null && bs >= need) declareWar(n.id, best);
    }
    if (rnd() < 0.025) {
      const c = neighborNations(n.id).filter(m => nat(m).alive && rel(n.id, m).state === 'peace');
      if (c.length) { const m = c[Math.floor(rnd() * c.length)]; if (opinion(n.id, m) > 14) { if (m === G.player) { if (!G.offers.some(o => o.from === n.id && o.type === 'ally')) { G.offers.push({ from: n.id, to: m, type: 'ally', turn: G.turn }); WC.emit('offer', {}); } } else makeAlliance(n.id, m); } }
    }
  }
  function aiRecruit(n, mine) {
    let budget = Math.max(0, n.money * 0.8 - 20);
    const frontP = mine.filter(p => p.neighbors.some(l => !l.sea && atWar(n.id, prov(l.to).owner)));
    const pool = frontP.length ? frontP.concat(mine.filter(() => rnd() < 0.2)) : mine;
    for (let i = 0; i < 70 && budget >= 10; i++) {
      const p = pool[Math.floor(rnd() * pool.length)]; if (p.rec >= prodCap(p)) continue;
      const r = rnd(); let t = r < 0.5 ? 'inf' : r < 0.74 ? 'tank' : r < 0.9 ? 'art' : 'air';
      if (U[t].cost > budget) t = 'inf'; if (U[t].cost > budget) break;
      p.units[t]++; p.rec++; n.money -= U[t].cost; budget -= U[t].cost; if (i % 9 === 0) ensureGeneral(p);
    }
  }
  function aiNavy(n, mine) {
    const ports = mine.filter(p => p.port), atw = wars(n.id).length > 0;
    if (!ports.length) return;
    // ساخت کشتی
    if (n.money > 150 && (atw || rnd() < 0.25)) {
      const p = ports[Math.floor(rnd() * ports.length)], r = rnd(), t = r < 0.3 ? 'boat' : r < 0.6 ? 'frig' : r < 0.78 ? 'dest' : 'trans';
      if (p.srec < shipCap(p) && n.money > SH[t].cost + 80) { p.ships[t]++; p.srec++; n.money -= SH[t].cost; }
    }
    // اعزام ناوگان به بنادر دشمن
    if (atw && rnd() < 0.5) {
      const p = ports.slice().sort((a, b) => shipPower(b.ships) - shipPower(a.ships))[0];
      if (p && warCount(p.ships) >= 3 && shipPower(p.ships) >= 8) {
        let best = null, bd = 1e9;
        G.provinces.forEach(q => { if (!q.port || !atWar(n.id, q.owner)) return; const d = cellDist(p.port.cell, q.port.cell); if (d < bd && d < 90) { bd = d; best = q; } });
        if (best) { const r = sendFleet(p.id, 0.7, false); if (r.ok) { const m = fleetMove(r.fleet.id, { prov: best.id }); if (!m.ok) { ST.forEach(t => p.ships[t] += r.fleet.ships[t]); G.fleets = G.fleets.filter(x => x !== r.fleet); } } }
      }
    }
    // بازگشت ناوگان بیکار
    G.fleets.filter(f => f.owner === n.id && !f.path).forEach(f => {
      const atEnemy = G.provinces.some(q => q.port && atWar(n.id, q.owner) && cellDist(fleetCell(f), q.port.cell) <= 2.4);
      if (atEnemy && shipPower(f.ships) > 2) return;
      const home = ports.slice().sort((a, b) => cellDist(a.port.cell, fleetCell(f)) - cellDist(b.port.cell, fleetCell(f)))[0];
      if (home) { const r = fleetMove(f.id, { prov: home.id }); if (!r.ok) dockFleet(Object.assign(f, { dockTo: home.id })); }
    });
  }
  function aiResearch(n) { if (n.money < 300) return; const br = ['atk', 'def', 'eco'].sort((a, b) => n.tech[a] - n.tech[b])[0]; if (n.tech[br] < TECH_MAX && n.money >= techCost(n, n.tech[br]) + 150) { n.money -= techCost(n, n.tech[br]); n.tech[br]++; } }
  function frontDist(n) {
    const dist = new Map(), q = [];
    ownedProvs(n.id).forEach(p => { if (p.neighbors.some(l => atWar(n.id, prov(l.to).owner))) { dist.set(p.id, 0); q.push(p.id); } });
    while (q.length) { const c = q.shift(), d = dist.get(c); prov(c).neighbors.forEach(l => { if (l.sea) return; const o = prov(l.to); if (o.owner !== n.id || dist.has(o.id)) return; dist.set(o.id, d + 1); q.push(o.id); }); }
    return dist;
  }
  function aiProvince(n, p, diff, front, allowSea) {
    if (p.acted || p.owner !== n.id) return false;
    if (unitPower(p.units) < 4) return false;
    let best = null, br = 0;
    for (const l of p.neighbors) {
      const q = prov(l.to); if (q.owner === n.id || !atWar(n.id, q.owner)) continue;
      if (l.sea && (!allowSea || p.ships.trans < 1)) continue;
      const aP = attL(p.units) * aMulOf(p, l.sea) + (l.sea ? shipAtk(p.ships) : 0), dP = defL(q.units) * dMulOf(q) + (l.sea ? shipDef(q.ships) * 0.6 : 0), ratio = aP / Math.max(1, dP) * (1 + q.eco * 0.03);
      if (ratio > br) { br = ratio; best = l; }
    }
    if (best && br >= diff.thr) {
      const exposed = p.neighbors.filter(l => !l.sea && atWar(n.id, prov(l.to).owner)).length > 1;
      const r = order(p.id, best.to, br > 2.2 ? 1 : exposed ? 0.6 : 0.8, 'ai'); if (best.sea) p._sea = true; return r.ok;
    }
    const d = front.get(p.id); if (d === undefined || d === 0) return false;
    for (const l of p.neighbors) { if (l.sea) continue; const o = prov(l.to); if (o.owner === n.id && front.get(o.id) === d - 1) { order(p.id, l.to, 0.9, 'ai'); return false; } }
    return false;
  }

  // ---------- نوبت ----------
  async function endTurn() {
    if (!G || G.busy || G.over) return;
    G.busy = true; WC.emit('busy', true);
    const list = shuffle(G.nations.filter(n => n.alive && !n.isPlayer)); let count = 0;
    for (const n of list) {
      if (!n.alive) continue;
      const plan = aiTurn(n);
      for (const step of plan) { const b = G.stats.battles; step(); if (G.stats.battles !== b) { count++; await sleep(count < 22 ? 60 : 6); } }
      if (G.over) break;
    }
    // ناوگان‌ها و تجارت
    ownedAll().forEach(p => { if (p.blockade > 0) p.blockade--; });
    await sailPhase();
    // اقتصاد
    G.turn++;
    G.nations.forEach(n => {
      if (!n.alive) return;
      const b = budget(n.id); n.budget = b; n.money += b.net; n.tradeEarned = 0;
      if (n.nukeCd > 0) n.nukeCd--;
      const target = 72 + (n.tax === 0 ? 12 : n.tax === 2 ? -18 : 0) - 4 * wars(n.id).length - (n.money < 0 ? 25 : 0);
      n.stab = clamp(n.stab + clamp(target - n.stab, -4, 4), 3, 100);
      if (n.money < 0) { ownedProvs(n.id).forEach(p => TYPES.forEach(t => { p.units[t] = Math.floor(p.units[t] * 0.96); })); n.money = Math.max(n.money, -500); if (n.isPlayer && G.turn % 2 === 0) log('خزانه منفی است! سربازان فرار می‌کنند.', 'war'); }
      if (rnd() < 0.012 && !n.isPlayer) leaderChange(n);
    });
    G.provinces.forEach(p => { p.acted = false; p.rec = 0; p.srec = 0; p.built = false; if (p.irr > 0) p.irr--; if (p.occ < 99) p.occ++; ensureGeneral(p); });
    if (G.outrage > 0) G.outrage--;
    G.offers = G.offers.filter(o => G.turn - o.turn < 3 && nat(o.from).alive);
    spawnTraders();
    G.busy = false; WC.emit('busy', false); WC.emit('turn', { turn: G.turn }); WC.emit('state'); checkEnd(); save();
  }
  const ownedAll = () => G.provinces;
  function leaderChange(n) {
    const keys = Object.keys(TR), old = n.leader.name;
    n.leader = { title: n.leader.title, name: WC.randName(n.culture, n.en + 'L' + G.turn + G.nextId++), trait: keys[Math.floor(rnd() * keys.length)], since: G.turn };
    log(`${n.leader.title} جدید ${n.name}: ${n.leader.name} (${TR[n.leader.trait].fa}) جانشین ${old} شد.`, '');
  }
  function checkEnd() {
    if (!G || G.over || G.player < 0) return;
    const mine = ownedProvs(G.player).length;
    if (mine === 0) { G.over = true; WC.emit('defeat'); return; }
    if (!G.won && mine / G.provinces.length >= 0.6) { G.won = true; WC.emit('victory'); }
  }

  // ---------- ذخیره ----------
  const sig = () => G.provinces.length + ':' + G.provinces.slice(0, 6).map(p => p.name).join('|');
  function save() {
    if (!G || G.player < 0) return;
    try {
      localStorage.setItem('wc_save_v2', JSON.stringify({
        v: 2, sig: sig(), turn: G.turn, player: G.player, diff: G.diff, log: G.log.slice(0, 60), rel: G.rel, offers: G.offers, outrage: G.outrage, won: G.won, stats: G.stats, nextId: G.nextId,
        provs: G.provinces.map(p => [p.owner, p.units, p.ships, p.bld, p.general, p.occ, p.irr, p.blockade]),
        nations: G.nations.map(n => [n.money, n.tech, n.alive ? 1 : 0, n.nukeCd, n.tax, n.stab, n.leader, n.capital]),
        fleets: G.fleets.map(f => ({ id: f.id, owner: f.owner, ships: f.ships, path: f.path, pi: f.pi, cell: f.cell, home: f.home, dockTo: f.dockTo })),
        traders: G.traders.map(t => ({ id: t.id, owner: t.owner, from: t.from, to: t.to, path: t.path, pi: t.pi, value: t.value }))
      }));
    } catch (e) {}
  }
  const hasSave = () => { try { return !!localStorage.getItem('wc_save_v2'); } catch (e) { return false; } };
  function load(countries, provs) {
    try {
      const d = JSON.parse(localStorage.getItem('wc_save_v2'));
      if (!d || d.sig !== provs.length + ':' + provs.slice(0, 6).map(p => p.name).join('|')) return false;
      WC.newGame(countries, provs, d.player, d.diff);
      G.turn = d.turn; G.log = d.log || []; G.rel = d.rel || {}; G.offers = d.offers || []; G.outrage = d.outrage || 0; G.won = !!d.won; G.stats = d.stats || G.stats; G.nextId = d.nextId || 1000;
      d.provs.forEach((a, i) => { const p = G.provinces[i]; p.owner = a[0]; p.units = a[1]; p.ships = a[2]; p.bld = a[3]; p.general = a[4]; p.occ = a[5]; p.irr = a[6]; p.blockade = a[7]; });
      d.nations.forEach((a, i) => { const n = G.nations[i]; n.money = a[0]; n.tech = a[1]; n.alive = !!a[2]; n.nukeCd = a[3]; n.tax = a[4]; n.stab = a[5]; n.leader = a[6]; n.capital = a[7]; });
      G.fleets = (d.fleets || []).map(f => Object.assign(f, { anim: null })); G.traders = (d.traders || []).map(t => Object.assign(t, { anim: null }));
      G._own = null; WC.emit('state'); return true;
    } catch (e) { console.error(e); return false; }
  }
  const clearSave = () => { try { localStorage.removeItem('wc_save_v2'); } catch (e) {} };

  WC.game = {
    DIFF, TECH_MAX, NUKE_COST, NUKE_TECH_COST, techCost, FLEET_SPEED,
    unitPower, totalUnits, shipPower, shipCount, warCount, nat, prov, rel, atWar, allied, ownedProvs, natPower, natIncome, budget, provYield, provIncome, prodCap, shipCap, wars, neighborNations, linkBetween, opinion,
    order, declareWar, makePeace, makeAlliance, breakAlliance, propose, answerOffer, recruit, buildShip, build, research, setTax, nuke, sendFleet, fleetMove, fleetCell, endTurn,
    save, load, hasSave, clearSave, log, checkEnd, rankName, ensureGeneral, occF, cellDist, shipAtk, defL, attL
  };
})(window.WC);
