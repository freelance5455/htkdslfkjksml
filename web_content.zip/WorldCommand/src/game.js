/* فرمان جهان — قوانین بازی، نبرد، دیپلماسی و هوش مصنوعی */
(function (WC) {
  const TYPES = WC.TYPES, U = WC.UNITS;
  let G = null;
  const L = {};
  WC.on = (e, f) => { (L[e] = L[e] || []).push(f); };
  WC.emit = (e, d) => { (L[e] || []).forEach(f => { try { f(d); } catch (err) { console.error(err); } }); };
  const rnd = Math.random;
  const rr = x => { const f = Math.floor(x); return f + (rnd() < x - f ? 1 : 0); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const emptyUnits = () => ({ inf: 0, tank: 0, art: 0, air: 0, nav: 0 });
  const DIFF = {
    easy:   { aggr: 0.03, income: 0.85, thr: 1.8, fort: 1.0, label: 'سرباز' },
    normal: { aggr: 0.06, income: 1.0,  thr: 1.35, fort: 1.0, label: 'سرهنگ' },
    hard:   { aggr: 0.10, income: 1.25, thr: 1.05, fort: 1.1, label: 'ژنرال' }
  };
  const TECH_MAX = 5, NUKE_TECH_COST = 800, NUKE_COST = 250;
  const techCost = lvl => 100 * (lvl + 1);

  function unitPower(u) { let s = 0; for (const t of TYPES) s += (u[t] || 0) * U[t].pw; return s; }
  function totalUnits(u) { let s = 0; for (const t of TYPES) s += (u[t] || 0); return s; }
  function relKey(a, b) { return a < b ? a + '_' + b : b + '_' + a; }

  function nationColor(i, isPlayer) {
    if (isPlayer) return { h: 44, s: 78, l: 54 };
    let h = (i * 137.508) % 360;
    if (h > 30 && h < 62) h += 42;
    const s = 46 + (i * 7) % 20, l = 40 + (i * 13) % 14;
    return { h, s, l };
  }
  function cssColor(c) {
    const f = (h, s, l, a) => a == null ? `hsl(${h.toFixed(0)},${s}%,${l}%)` : `hsla(${h.toFixed(0)},${s}%,${l}%,${a})`;
    return { fill: f(c.h, c.s, c.l), hi: f(c.h, Math.min(95, c.s + 6), Math.min(80, c.l + 14)), dk: f(c.h, c.s, Math.max(12, c.l - 20)), glow: f(c.h, c.s, Math.min(85, c.l + 25), 0.55), hex: f(c.h, c.s, c.l) };
  }

  function initStats(provs) {
    const sorted = provs.slice().sort((a, b) => b.area - a.area);
    const big = new Set(sorted.slice(0, 22).map(p => p.id));
    provs.forEach(p => {
      const st = WC.STATS[p.name];
      if (st) { p.mil = st[0]; p.econ = st[1]; }
      else {
        const h1 = WC.hash(p.name + 'm'), h2 = WC.hash(p.name + 'e');
        p.mil = 1 + Math.floor(h1 * 2.99) + (big.has(p.id) ? 1 : 0);
        p.econ = 1 + Math.floor(h2 * 2.99) + (big.has(p.id) ? 1 : 0);
      }
    });
  }

  function baseUnits(p) {
    const m = Math.pow(p.mil, 1.5), u = emptyUnits();
    u.inf = Math.round(2 * m) + 2;
    if (p.mil >= 3) u.tank = Math.round(0.35 * m);
    if (p.mil >= 2) u.art = Math.round(0.3 * m);
    if (p.mil >= 4) u.air = Math.round(0.25 * m);
    if (p.mil >= 3 && p.coastal && p.hasSea) u.nav = Math.max(1, Math.round(0.15 * m));
    return u;
  }

  WC.newGame = function (provs, playerId, diff) {
    initStats(provs);
    G = WC.G = {
      provinces: provs, nations: [], rel: {}, turn: 1, player: playerId, diff: DIFF[diff] ? diff : 'normal',
      log: [], offers: [], busy: false, won: false, over: false, outrage: 0, stats: { battles: 0, captured: 0, lost: 0 }
    };
    provs.forEach(p => {
      p.owner = p.id; p.units = baseUnits(p); p.acted = false; p.conquered = false; p.irr = 0; p.rec = 0;
    });
    provs.forEach(p => {
      const c = nationColor(p.id, p.id === playerId);
      G.nations.push({
        id: p.id, name: p.fa, en: p.name, color: c, css: cssColor(c), money: 50 + p.econ * 12,
        tech: { atk: 0, def: 0, eco: 0, nuke: false }, alive: true, isPlayer: p.id === playerId, nukeCd: 0, capital: p.id
      });
    });
    log(playerId >= 0 ? `فرماندهی ${G.nations[playerId].name} را بر عهده گرفتید. جهان در انتظار است.` : '');
    WC.emit('state');
    return G;
  };

  // ---------- ابزارها ----------
  const nat = id => G.nations[id];
  const prov = id => G.provinces[id];
  const rel = (a, b) => G.rel[relKey(a, b)] || (G.rel[relKey(a, b)] = { state: 'peace', since: 0, truce: 0 });
  const atWar = (a, b) => a !== b && rel(a, b).state === 'war';
  const allied = (a, b) => a !== b && rel(a, b).state === 'ally';
  const ownedProvs = id => G.provinces.filter(p => p.owner === id);
  const natPower = id => ownedProvs(id).reduce((s, p) => s + unitPower(p.units), 0);
  const provIncome = p => {
    const n = nat(p.owner);
    let v = (p.econ * 4 + 2) * (1 + 0.1 * n.tech.eco) * (p.conquered ? 0.8 : 1);
    if (p.irr > 0) v *= 0.4;
    if (!n.isPlayer) v *= DIFF[G.diff].income;
    return Math.round(v);
  };
  const natIncome = id => ownedProvs(id).reduce((s, p) => s + provIncome(p), 0);
  const prodCap = p => 6 + p.econ * 2;
  const wars = id => G.nations.filter(n => n.alive && atWar(id, n.id));

  function log(msg, kind) {
    if (!msg) return;
    G.log.unshift({ turn: G.turn, msg, kind: kind || '' });
    if (G.log.length > 250) G.log.length = 250;
    WC.emit('log', { msg, kind });
  }
  function neighborNations(id) {
    const s = new Set();
    ownedProvs(id).forEach(p => p.neighbors.forEach(l => { const o = prov(l.to).owner; if (o !== id) s.add(o); }));
    return [...s];
  }
  function linkBetween(a, b) { return prov(a).neighbors.find(l => l.to === b) || null; }

  // ---------- نبرد ----------
  function attPow(u, n, bonusNav) {
    let s = 0; for (const t of TYPES) { if (t === 'nav' && !bonusNav) continue; s += (u[t] || 0) * U[t].atk; }
    return s * (1 + 0.12 * n.tech.atk);
  }
  function defPow(u, n, fort) {
    let s = 0; for (const t of TYPES) s += (u[t] || 0) * U[t].def;
    return s * (1 + 0.12 * n.tech.def) * fort;
  }
  function fortOf(p) { const n = nat(p.owner); return 1.25 * (n.isPlayer ? 1 : DIFF[G.diff].fort); }

  function simulate(sent, defU, A, D, sea, srcNav, fort) {
    const a = Object.assign({}, sent), d = Object.assign({}, defU);
    const aT = Object.assign({}, a), dT = Object.assign({}, d);
    const bombard = sea ? srcNav : 0;
    for (let r = 0; r < 4; r++) {
      let aP = (attPow(a, A, false) + bombard * U.nav.atk * (1 + 0.12 * A.tech.atk)) * (sea ? 0.85 : 1) * (0.85 + rnd() * 0.3);
      let dP = defPow(d, D, fort) * (0.85 + rnd() * 0.3);
      if (aP <= 0.01 || dP <= 0.01) break;
      const fD = Math.min(1, 0.5 * aP / dP), fA = Math.min(1, 0.5 * dP / aP);
      for (const t of TYPES) { d[t] *= (1 - fD); a[t] *= (1 - fA); }
      if (totalUnits(d) < 0.6 || totalUnits(a) < 0.6) break;
    }
    const aEnd = {}, dEnd = {};
    for (const t of TYPES) { aEnd[t] = rr(a[t]); dEnd[t] = rr(d[t]); }
    return { aEnd, dEnd, aStart: aT, dStart: dT };
  }

  // انتقال/حمله از src به dst با کسر frac از نیروها
  function order(srcId, dstId, frac, who) {
    const src = prov(srcId), dst = prov(dstId);
    const link = linkBetween(srcId, dstId);
    if (!link) return { ok: false, msg: 'این دو استان به هم راه ندارند.' };
    if (src.acted) return { ok: false, msg: 'این استان در این نوبت فرمان داده است.' };
    const A = nat(src.owner);
    const friendly = dst.owner === src.owner || allied(src.owner, dst.owner);
    const sea = link.sea;
    if (!friendly && !atWar(src.owner, dst.owner)) return { ok: false, msg: 'با این کشور در جنگ نیستید.', needWar: dst.owner };
    const sent = emptyUnits();
    for (const t of TYPES) sent[t] = Math.floor(src.units[t] * frac + 1e-9);
    if (frac >= 0.999) for (const t of TYPES) sent[t] = src.units[t];
    if (!friendly) sent.nav = 0;
    const land = sent.inf + sent.tank + sent.art;
    if (sea) {
      if (src.units.nav < 1) return { ok: false, msg: 'برای عبور از دریا به ناوگان نیاز دارید.' };
      const cap = src.units.nav * 20;
      if (land > cap) {
        const k = cap / land; ['inf', 'tank', 'art'].forEach(t => sent[t] = Math.floor(sent[t] * k));
      }
    }
    if (totalUnits(sent) <= 0) return { ok: false, msg: 'نیرویی برای ارسال نیست.' };

    if (friendly) {
      for (const t of TYPES) { src.units[t] -= sent[t]; dst.units[t] += sent[t]; }
      src.acted = true; if (dst.owner === src.owner) dst.acted = true;
      WC.emit('move', { src, dst, sea, who });
      return { ok: true, kind: 'move' };
    }

    if (sent.inf + sent.tank < 1) return { ok: false, msg: 'برای حمله به پیاده‌نظام یا تانک نیاز است.' };
    const D = nat(dst.owner);
    const res = simulate(sent, dst.units, A, D, sea, src.units.nav, fortOf(dst));
    for (const t of TYPES) src.units[t] -= sent[t];
    const atkLoss = {}, defLoss = {}; let aL = 0, dL = 0;
    for (const t of TYPES) { atkLoss[t] = sent[t] - res.aEnd[t]; defLoss[t] = dst.units[t] - res.dEnd[t]; aL += atkLoss[t]; dL += defLoss[t]; }
    const defTotalEnd = totalUnits(res.dEnd), landLeft = res.aEnd.inf + res.aEnd.tank;
    const captured = defTotalEnd === 0 && landLeft > 0;
    const oldOwner = dst.owner;
    src.acted = true;
    G.stats.battles++;
    if (captured) {
      dst.units = emptyUnits();
      for (const t of ['inf', 'tank', 'art']) dst.units[t] = res.aEnd[t];
      src.units.air += res.aEnd.air;
      dst.owner = src.owner; dst.conquered = true; dst.acted = true; dst.irr = 0;
      if (who === 'player' || src.owner === G.player) G.stats.captured++;
      // اگر کشور مقابل حذف شد
      if (ownedProvs(oldOwner).length === 0) eliminate(oldOwner, src.owner);
    } else {
      for (const t of TYPES) { src.units[t] += res.aEnd[t]; dst.units[t] = res.dEnd[t]; }
    }
    if (dst.owner !== oldOwner) { /* مالکیت عوض شد */ }
    const info = { src, dst, sea, captured, atkLoss, defLoss, aL, dL, attacker: src.owner, defender: oldOwner, who };
    WC.emit('attack', info);
    checkEnd();
    return { ok: true, kind: 'attack', captured, aL, dL };
  }

  function eliminate(id, by) {
    const n = nat(id); n.alive = false;
    Object.keys(G.rel).forEach(k => { const [a, b] = k.split('_').map(Number); if (a === id || b === id) G.rel[k].state = 'peace'; });
    G.offers = G.offers.filter(o => o.from !== id);
    log(`${n.name} سقوط کرد و از نقشه حذف شد.`, 'big');
    WC.emit('fall', { id, by });
  }

  // ---------- دیپلماسی ----------
  function declareWar(a, b, silent) {
    if (a === b) return { ok: false, msg: '' };
    const r = rel(a, b);
    if (r.state === 'war') return { ok: false, msg: 'از پیش در جنگ هستید.' };
    if (r.state === 'ally') return { ok: false, msg: 'ابتدا باید اتحاد را لغو کنید.' };
    if (G.turn < r.truce) return { ok: false, msg: `آتش‌بس تا نوبت ${WC.fa(r.truce)} برقرار است.` };
    r.state = 'war'; r.since = G.turn;
    log(`${nat(a).name} به ${nat(b).name} اعلان جنگ کرد!`, 'war');
    WC.emit('war', { a, b });
    G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a)));
    // پیوستن متحدان
    if (!silent) G.nations.forEach(c => {
      if (!c.alive || c.id === a || c.id === b) return;
      if (c.isPlayer) return;
      if (allied(c.id, b) && !allied(c.id, a) && !atWar(c.id, a) && rnd() < 0.5) declareWar(c.id, a, true);
      else if (allied(c.id, a) && !allied(c.id, b) && !atWar(c.id, b) && rnd() < 0.5) declareWar(c.id, b, true);
    });
    return { ok: true };
  }
  function makePeace(a, b) {
    const r = rel(a, b); if (r.state !== 'war') return;
    r.state = 'peace'; r.since = G.turn; r.truce = G.turn + 6;
    log(`${nat(a).name} و ${nat(b).name} آتش‌بس کردند.`, 'peace');
    G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a)));
    WC.emit('peace', { a, b });
  }
  function makeAlliance(a, b) {
    const r = rel(a, b); if (r.state === 'war') return;
    r.state = 'ally'; r.since = G.turn;
    log(`${nat(a).name} و ${nat(b).name} متحد شدند.`, 'peace');
    G.offers = G.offers.filter(o => !((o.from === a && o.to === b) || (o.from === b && o.to === a)));
    WC.emit('ally', { a, b });
  }
  function breakAlliance(a, b) {
    const r = rel(a, b); if (r.state !== 'ally') return;
    r.state = 'peace'; r.since = G.turn; r.truce = G.turn + 3;
    log(`${nat(a).name} اتحاد با ${nat(b).name} را لغو کرد.`, '');
    WC.emit('state');
  }
  function opinion(a, b) {
    const lo = Math.min(a, b), hi = Math.max(a, b);
    let o = WC.hash(lo + '-' + hi + '-' + G.provinces[lo].name) * 60 - 25;
    G.nations.forEach(m => {
      if (!m.alive || m.id === a || m.id === b) return;
      if (atWar(a, m.id) && atWar(b, m.id)) o += 25;
      if (atWar(a, m.id) && allied(b, m.id)) o -= 35;
      if (atWar(b, m.id) && allied(a, m.id)) o -= 35;
    });
    if (neighborNations(a).includes(b)) o -= 6;
    if (G.outrage > 0 && b === G.player) o -= 45;
    if (natPower(b) > natPower(a)) o += 6;
    return o;
  }
  // پیشنهاد بازیکن
  function propose(kind, aiId) {
    const me = G.player, ai = nat(aiId);
    if (kind === 'peace') {
      if (!atWar(me, aiId)) return { ok: false, msg: 'در جنگ نیستید.' };
      const dur = G.turn - rel(me, aiId).since;
      const ratio = natPower(aiId) / Math.max(1, natPower(me));
      const p = ratio < 0.9 ? 0.9 : Math.min(0.85, 0.2 + dur * 0.1);
      if (rnd() < p) { makePeace(me, aiId); return { ok: true, msg: `${ai.name} آتش‌بس را پذیرفت.` }; }
      return { ok: false, msg: `${ai.name} هنوز آماده صلح نیست.` };
    }
    if (kind === 'ally') {
      if (rel(me, aiId).state !== 'peace') return { ok: false, msg: 'اکنون ممکن نیست.' };
      if (opinion(aiId, me) > 10) { makeAlliance(me, aiId); return { ok: true, msg: `${ai.name} با اتحاد موافقت کرد.` }; }
      return { ok: false, msg: `${ai.name} به اتحاد علاقه‌ای نشان نداد.` };
    }
    return { ok: false, msg: '' };
  }
  function answerOffer(idx, accept) {
    const o = G.offers[idx]; if (!o) return;
    G.offers.splice(idx, 1);
    if (!accept) { WC.emit('state'); return; }
    if (o.type === 'peace') makePeace(o.from, G.player);
    else if (o.type === 'ally') makeAlliance(o.from, G.player);
    WC.emit('state');
  }

  // ---------- اقدامات بازیکن ----------
  function recruit(pid, type, qty) {
    const p = prov(pid), n = nat(p.owner), u = U[type];
    if (!n.isPlayer) return { ok: false, msg: 'این استان مال شما نیست.' };
    if (type === 'nav' && !(p.coastal && p.hasSea)) return { ok: false, msg: 'ناوگان فقط در استان‌های ساحلی ساخته می‌شود.' };
    const room = prodCap(p) - p.rec;
    qty = Math.min(qty, room, Math.floor(n.money / u.cost));
    if (qty <= 0) return { ok: false, msg: room <= 0 ? 'ظرفیت تولید این استان در این نوبت پر است.' : 'پول کافی نیست.' };
    n.money -= qty * u.cost; p.units[type] += qty; p.rec += qty;
    WC.emit('recruit', { p, type, qty });
    return { ok: true, qty };
  }
  function research(nid, branch) {
    const n = nat(nid);
    if (branch === 'nuke') {
      if (n.tech.nuke) return { ok: false, msg: 'پیش‌تر به دست آمده.' };
      if (n.money < NUKE_TECH_COST) return { ok: false, msg: 'پول کافی نیست.' };
      n.money -= NUKE_TECH_COST; n.tech.nuke = true;
      if (nid === G.player) log('برنامهٔ اتمی به نتیجه رسید.', 'big');
      WC.emit('research', { nid, branch }); return { ok: true };
    }
    const lvl = n.tech[branch];
    if (lvl >= TECH_MAX) return { ok: false, msg: 'به حداکثر رسیده.' };
    const c = techCost(lvl);
    if (n.money < c) return { ok: false, msg: 'پول کافی نیست.' };
    n.money -= c; n.tech[branch]++;
    WC.emit('research', { nid, branch }); return { ok: true };
  }
  function nuke(targetId) {
    const me = nat(G.player), t = prov(targetId);
    if (!me.tech.nuke) return { ok: false, msg: 'فناوری اتمی ندارید.' };
    if (me.nukeCd > 0) return { ok: false, msg: `سلاح بعدی تا ${WC.fa(me.nukeCd)} نوبت دیگر آماده می‌شود.` };
    if (me.money < NUKE_COST) return { ok: false, msg: 'پول کافی نیست.' };
    if (!atWar(G.player, t.owner)) return { ok: false, msg: 'فقط به کشورهایی که با آن‌ها در جنگید.' };
    me.money -= NUKE_COST; me.nukeCd = 3;
    const before = totalUnits(t.units);
    TYPES.forEach(k => t.units[k] = Math.floor(t.units[k] * 0.2));
    t.irr = 4;
    G.outrage = 3;
    log(`حملهٔ اتمی به ${t.fa}! ${WC.fa(before - totalUnits(t.units))} واحد نابود شد. جهان خشمگین است.`, 'war');
    WC.emit('nuke', { target: t });
    return { ok: true };
  }

  // ---------- هوش مصنوعی ----------
  function aiTurn(n) {
    const diff = DIFF[G.diff];
    const mine = ownedProvs(n.id);
    if (!mine.length) { n.alive = false; return []; }
    aiDiplomacy(n, diff);
    aiRecruit(n, mine);
    const plan = [];
    const front = frontDist(n);
    shuffle(mine.slice()).forEach(p => plan.push(() => aiProvince(n, p, diff, front)));
    aiResearch(n);
    return plan;
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  function aiDiplomacy(n, diff) {
    // آتش‌بس
    wars(n.id).forEach(m => {
      const dur = G.turn - rel(n.id, m.id).since;
      if (dur < 4) return;
      const ratio = natPower(n.id) / Math.max(1, natPower(m.id));
      if (ratio < 0.6 || rnd() < 0.08) {
        if (m.isPlayer) { if (!G.offers.some(o => o.from === n.id && o.type === 'peace')) { G.offers.push({ from: n.id, to: m.id, type: 'peace', turn: G.turn }); WC.emit('offer', {}); } }
        else if (m.alive && natPower(m.id) / Math.max(1, natPower(n.id)) < 1.4 && rnd() < 0.5) makePeace(n.id, m.id);
      }
    });
    // خشم جهانی علیه حملهٔ اتمی
    if (G.outrage > 0 && !n.isPlayer && !atWar(n.id, G.player) && !allied(n.id, G.player) && rnd() < 0.2) {
      const r = rel(n.id, G.player); if (G.turn >= r.truce && r.state === 'peace') declareWar(n.id, G.player);
    }
    // اعلان جنگ
    const wcount = wars(n.id).length;
    if (wcount >= 2) return;
    const myP = natPower(n.id);
    if (rnd() < diff.aggr * (wcount ? 0.5 : 1) * (0.6 + n.id % 3 * 0.25)) {
      let best = null, bs = 0;
      neighborNations(n.id).forEach(m => {
        if (!nat(m).alive || allied(n.id, m)) return;
        const r = rel(n.id, m); if (r.state !== 'peace' || G.turn < r.truce) return;
        let sc = myP / Math.max(1, natPower(m));
        if (m === G.player) sc *= G.diff === 'easy' ? 0.7 : G.diff === 'hard' ? 1.3 : 1;
        if (sc > bs) { bs = sc; best = m; }
      });
      const need = G.diff === 'hard' ? 0.9 : G.diff === 'easy' ? 1.7 : 1.25;
      if (best !== null && bs >= need) declareWar(n.id, best);
    }
    // اتحاد
    if (rnd() < 0.025) {
      const cands = neighborNations(n.id).filter(m => nat(m).alive && rel(n.id, m).state === 'peace');
      if (cands.length) {
        const m = cands[Math.floor(rnd() * cands.length)];
        if (opinion(n.id, m) > 14) {
          if (m === G.player) { if (!G.offers.some(o => o.from === n.id && o.type === 'ally')) { G.offers.push({ from: n.id, to: m, type: 'ally', turn: G.turn }); WC.emit('offer', {}); } }
          else makeAlliance(n.id, m);
        }
      }
    }
  }

  function aiRecruit(n, mine) {
    let budget = n.money * 0.85;
    const frontP = mine.filter(p => p.neighbors.some(l => !l.sea && atWar(n.id, prov(l.to).owner)));
    const pool = frontP.length ? frontP.concat(mine.filter(p => rnd() < 0.2)) : mine;
    for (let i = 0; i < 80 && budget >= 10; i++) {
      const p = pool[Math.floor(rnd() * pool.length)];
      if (p.rec >= prodCap(p)) continue;
      let r = rnd(), t = r < 0.45 ? 'inf' : r < 0.68 ? 'tank' : r < 0.83 ? 'art' : r < 0.94 ? 'air' : 'nav';
      if (t === 'nav' && !(p.coastal && p.hasSea)) t = 'inf';
      if (U[t].cost > budget) t = 'inf';
      if (U[t].cost > budget) break;
      p.units[t]++; p.rec++; n.money -= U[t].cost; budget -= U[t].cost;
    }
  }
  function aiResearch(n) {
    if (n.money < 300) return;
    const br = ['atk', 'def', 'eco'].sort((a, b) => n.tech[a] - n.tech[b])[0];
    if (n.tech[br] < TECH_MAX && n.money >= techCost(n.tech[br]) + 150) { n.money -= techCost(n.tech[br]); n.tech[br]++; }
  }
  function frontDist(n) {
    const dist = new Map(); const q = [];
    ownedProvs(n.id).forEach(p => { if (p.neighbors.some(l => atWar(n.id, prov(l.to).owner))) { dist.set(p.id, 0); q.push(p.id); } });
    while (q.length) {
      const c = q.shift(), d = dist.get(c);
      prov(c).neighbors.forEach(l => { if (l.sea) return; const o = prov(l.to); if (o.owner !== n.id || dist.has(o.id)) return; dist.set(o.id, d + 1); q.push(o.id); });
    }
    return dist;
  }
  function aiProvince(n, p, diff, front) {
    if (p.acted || p.owner !== n.id) return;
    const force = unitPower(p.units);
    if (force < 4) return;
    let best = null, br = 0;
    for (const l of p.neighbors) {
      const q = prov(l.to);
      if (q.owner === n.id || !atWar(n.id, q.owner)) continue;
      if (l.sea && p.units.nav < 1) continue;
      const aP = attPow(p.units, n, l.sea) * (l.sea ? 0.85 : 1);
      const dP = defPow(q.units, nat(q.owner), fortOf(q));
      const ratio = aP / Math.max(1, dP) * (1 + q.econ * 0.03);
      if (ratio > br) { br = ratio; best = l; }
    }
    if (best && br >= diff.thr) {
      const exposed = p.neighbors.filter(l => !l.sea && atWar(n.id, prov(l.to).owner)).length > 1;
      const frac = br > 2.2 ? 1 : exposed ? 0.6 : 0.8;
      order(p.id, best.to, frac, 'ai');
      return;
    }
    // پشتیبانی: انتقال به خط مقدم
    const d = front.get(p.id);
    if (d === undefined) return;
    if (d === 0) return;
    let step = null;
    for (const l of p.neighbors) { if (l.sea) continue; const o = prov(l.to); if (o.owner === n.id && front.get(o.id) === d - 1) { step = l; break; } }
    if (step) order(p.id, step.to, 0.9, 'ai');
  }

  // ---------- نوبت ----------
  async function endTurn() {
    if (!G || G.busy || G.over) return;
    G.busy = true; WC.emit('busy', true);
    const order_ = shuffle(G.nations.filter(n => n.alive && !n.isPlayer));
    let count = 0;
    for (const n of order_) {
      if (!n.alive) continue;
      const plan = aiTurn(n);
      for (const step of plan) {
        const before = G.stats.battles;
        step();
        if (G.stats.battles !== before) { count++; await sleep(count < 25 ? 55 : 8); }
      }
      if (G.over) break;
    }
    // پایان دور: درآمد و بازنشانی
    G.turn++;
    G.nations.forEach(n => {
      if (!n.alive) return;
      n.money += natIncome(n.id);
      if (n.nukeCd > 0) n.nukeCd--;
    });
    G.provinces.forEach(p => { p.acted = false; p.rec = 0; if (p.irr > 0) p.irr--; });
    if (G.outrage > 0) G.outrage--;
    G.offers = G.offers.filter(o => G.turn - o.turn < 3 && nat(o.from).alive);
    G.busy = false;
    WC.emit('busy', false);
    WC.emit('turn', { turn: G.turn });
    WC.emit('state');
    checkEnd();
    save();
  }

  function checkEnd() {
    if (!G || G.over || G.player < 0) return;
    const mine = ownedProvs(G.player).length;
    if (mine === 0) { G.over = true; WC.emit('defeat'); return; }
    if (!G.won && mine / G.provinces.length >= 0.6) { G.won = true; WC.emit('victory'); }
  }

  // ---------- ذخیره ----------
  function sig() { return G.provinces.length + ':' + G.provinces.slice(0, 5).map(p => p.name).join('|'); }
  function save() {
    if (!G || G.player < 0) return;
    try {
      const data = {
        v: 1, sig: sig(), turn: G.turn, player: G.player, diff: G.diff, log: G.log.slice(0, 60), rel: G.rel, offers: G.offers, outrage: G.outrage, won: G.won, stats: G.stats,
        provs: G.provinces.map(p => [p.owner, p.units, p.conquered ? 1 : 0, p.irr]),
        nations: G.nations.map(n => [n.money, n.tech, n.alive ? 1 : 0, n.nukeCd])
      };
      localStorage.setItem('wc_save_v1', JSON.stringify(data));
    } catch (e) {}
  }
  function hasSave() { try { return !!localStorage.getItem('wc_save_v1'); } catch (e) { return false; } }
  function load(provs) {
    try {
      const d = JSON.parse(localStorage.getItem('wc_save_v1'));
      if (!d || d.sig !== provs.length + ':' + provs.slice(0, 5).map(p => p.name).join('|')) return false;
      WC.newGame(provs, d.player, d.diff);
      G.turn = d.turn; G.log = d.log || []; G.rel = d.rel || {}; G.offers = d.offers || []; G.outrage = d.outrage || 0; G.won = !!d.won; G.stats = d.stats || G.stats;
      d.provs.forEach((a, i) => { const p = G.provinces[i]; p.owner = a[0]; p.units = a[1]; p.conquered = !!a[2]; p.irr = a[3]; });
      d.nations.forEach((a, i) => { const n = G.nations[i]; n.money = a[0]; n.tech = a[1]; n.alive = !!a[2]; n.nukeCd = a[3]; });
      WC.emit('state');
      return true;
    } catch (e) { return false; }
  }
  function clearSave() { try { localStorage.removeItem('wc_save_v1'); } catch (e) {} }

  WC.game = {
    DIFF, TECH_MAX, NUKE_COST, NUKE_TECH_COST, techCost,
    unitPower, totalUnits, nat, prov, rel, atWar, allied, ownedProvs, natPower, natIncome, provIncome, prodCap, wars, neighborNations, linkBetween, opinion,
    order, declareWar, makePeace, makeAlliance, breakAlliance, propose, answerOffer, recruit, research, nuke, endTurn,
    save, load, hasSave, clearSave, log, checkEnd, attPow, defPow, fortOf
  };
})(window.WC);
