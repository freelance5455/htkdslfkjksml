/* فرمان جهان — داده‌های جهان: پایتخت‌ها، استان‌ها، حکومت‌ها، رهبران، منابع، کشتی‌ها */
(function (WC) {
  // پایتخت‌ها: نام|پایتخت|طول|عرض
  WC.CAP = {};
  `Afghanistan|کابل|69.2|34.5
Albania|تیرانا|19.8|41.3
Algeria|الجزیره|3.1|36.7
Angola|لوآندا|13.2|-8.8
Argentina|بوینوس‌آیرس|-58.4|-34.6
Armenia|ایروان|44.5|40.2
Australia|کانبرا|149.1|-35.3
Austria|وین|16.4|48.2
Azerbaijan|باکو|49.9|40.4
Bangladesh|داکا|90.4|23.8
Belarus|مینسک|27.6|53.9
Belgium|بروکسل|4.4|50.8
Benin|پورتونوو|2.6|6.5
Bhutan|تیمفو|89.6|27.5
Bolivia|لاپاز|-68.1|-16.5
Bosnia and Herz.|سارایوو|18.4|43.9
Botswana|گابورون|25.9|-24.7
Brazil|برازیلیا|-47.9|-15.8
Bulgaria|صوفیه|23.3|42.7
Burkina Faso|اوآگادوگو|-1.5|12.4
Cambodia|پنوم‌پن|104.9|11.6
Cameroon|یائونده|11.5|3.9
Canada|اتاوا|-75.7|45.4
Chad|انجامنا|15.0|12.1
Chile|سانتیاگو|-70.7|-33.4
China|پکن|116.4|39.9
Colombia|بوگوتا|-74.1|4.7
Costa Rica|سن‌خوزه|-84.1|9.9
Croatia|زاگرب|16.0|45.8
Cuba|هاوانا|-82.4|23.1
Cyprus|نیکوزیا|33.4|35.2
Czechia|پراگ|14.4|50.1
Dem. Rep. Congo|کینشاسا|15.3|-4.3
Denmark|کپنهاگ|12.6|55.7
Dominican Rep.|سانتو دومینگو|-69.9|18.5
Ecuador|کیتو|-78.5|-0.2
Egypt|قاهره|31.2|30.0
El Salvador|سن‌سالوادور|-89.2|13.7
Eritrea|اسمره|38.9|15.3
Estonia|تالین|24.7|59.4
Ethiopia|آدیس‌آبابا|38.7|9.0
Finland|هلسینکی|24.9|60.2
France|پاریس|2.3|48.9
Gabon|لیبرویل|9.5|0.4
Georgia|تفلیس|44.8|41.7
Germany|برلین|13.4|52.5
Ghana|آکرا|-0.2|5.6
Greece|آتن|23.7|38.0
Greenland|نوک|-51.7|64.2
Guatemala|گواتمالا|-90.5|14.6
Guinea|کوناکری|-13.7|9.5
Guyana|جورج‌تاون|-58.2|6.8
Haiti|پورتوپرنس|-72.3|18.5
Honduras|تگوسیگالپا|-87.2|14.1
Hungary|بوداپست|19.0|47.5
Iceland|ریکیاویک|-21.9|64.1
India|دهلی نو|77.2|28.6
Indonesia|جاکارتا|106.8|-6.2
Iran|تهران|51.4|35.7
Iraq|بغداد|44.4|33.3
Ireland|دوبلین|-6.3|53.3
Israel|اورشلیم|35.2|31.8
Italy|رم|12.5|41.9
Jamaica|کینگستون|-76.8|18.0
Japan|توکیو|139.7|35.7
Jordan|عمان|35.9|31.9
Kazakhstan|آستانه|71.4|51.2
Kenya|نایروبی|36.8|-1.3
Kuwait|کویت|47.9|29.4
Kyrgyzstan|بیشکک|74.6|42.9
Laos|وینتیان|102.6|18.0
Latvia|ریگا|24.1|56.9
Lebanon|بیروت|35.5|33.9
Liberia|مونروویا|-10.8|6.3
Libya|طرابلس|13.2|32.9
Lithuania|ویلنیوس|25.3|54.7
Madagascar|آنتاناناریوو|47.5|-18.9
Malawi|لیلانگوه|33.8|-14.0
Malaysia|کوالالامپور|101.7|3.1
Mali|باماکو|-8.0|12.6
Mauritania|نواکشوط|-15.98|18.1
Mexico|مکزیکوسیتی|-99.1|19.4
Moldova|کیشینیف|28.8|47.0
Mongolia|اولان‌باتور|106.9|47.9
Morocco|رباط|-6.8|34.0
Mozambique|ماپوتو|32.6|-25.9
Myanmar|نایپیداو|96.1|19.8
Namibia|ویندهوک|17.1|-22.6
Nepal|کاتماندو|85.3|27.7
Netherlands|آمستردام|4.9|52.4
New Zealand|ولینگتون|174.8|-41.3
Nicaragua|ماناگوا|-86.3|12.1
Niger|نیامی|2.1|13.5
Nigeria|ابوجا|7.5|9.1
North Korea|پیونگ‌یانگ|125.8|39.0
North Macedonia|اسکوپیه|21.4|42.0
Norway|اسلو|10.8|59.9
Oman|مسقط|58.4|23.6
Pakistan|اسلام‌آباد|73.1|33.7
Panama|پاناما|-79.5|9.0
Papua New Guinea|پورت‌مورسبی|147.2|-9.4
Paraguay|آسونسیون|-57.6|-25.3
Peru|لیما|-77.0|-12.0
Philippines|مانیل|121.0|14.6
Poland|ورشو|21.0|52.2
Portugal|لیسبون|-9.1|38.7
Qatar|دوحه|51.5|25.3
Romania|بخارست|26.1|44.4
Russia|مسکو|37.6|55.7
Rwanda|کیگالی|30.1|-1.9
Saudi Arabia|ریاض|46.7|24.7
Senegal|داکار|-17.4|14.7
Serbia|بلگراد|20.5|44.8
Sierra Leone|فریتاون|-13.2|8.5
Slovakia|براتیسلاوا|17.1|48.1
Slovenia|لیوبلیانا|14.5|46.1
Somalia|مقدیشو|45.3|2.0
South Africa|پرتوریا|28.2|-25.7
South Korea|سئول|127.0|37.6
S. Sudan|جوبا|31.6|4.9
Spain|مادرید|-3.7|40.4
Sri Lanka|کلمبو|79.9|6.9
Sudan|خارطوم|32.5|15.6
Sweden|استکهلم|18.1|59.3
Switzerland|برن|7.4|46.9
Syria|دمشق|36.3|33.5
Taiwan|تایپه|121.5|25.0
Tajikistan|دوشنبه|68.8|38.6
Tanzania|دودوما|35.7|-6.2
Thailand|بانکوک|100.5|13.8
Tunisia|تونس|10.2|36.8
Turkey|آنکارا|32.9|39.9
Turkmenistan|عشق‌آباد|58.4|37.9
Uganda|کامپالا|32.6|0.3
Ukraine|کی‌یف|30.5|50.4
United Arab Emirates|ابوظبی|54.4|24.5
United Kingdom|لندن|-0.1|51.5
United States of America|واشنگتن|-77.0|38.9
Uruguay|مونته‌ویدئو|-56.2|-34.9
Uzbekistan|تاشکند|69.2|41.3
Venezuela|کاراکاس|-66.9|10.5
Vietnam|هانوی|105.8|21.0
Yemen|صنعا|44.2|15.4
Zambia|لوساکا|28.3|-15.4
Zimbabwe|هراره|31.0|-17.8`.split('\n').forEach(l => { const a = l.split('|'); WC.CAP[a[0]] = { fa: a[1], lon: +a[2], lat: +a[3] }; });

  // استان‌های واقعی برای کشورهای بزرگ: [نام، طول، عرض] — نخستین مورد پایتخت است
  WC.REG = {
    "Iran": [["تهران",51.4,35.7],["خراسان",59.6,36.3],["اصفهان",51.7,32.6],["فارس",52.5,29.6],["خوزستان",48.7,31.3],["آذربایجان",46.3,38.1],["کرمان",57.1,30.3],["سیستان و بلوچستان",60.9,28.2],["مازندران و گیلان",52.5,36.6],["کردستان",47,35.3],["هرمزگان",56.3,27.2],["یزد",54.4,31.9]],
    "Russia": [["مسکو",37.6,55.7],["سن‌پترزبورگ",30.3,59.9],["قفقاز شمالی",44,43.5],["ولگا",48,53],["اورال",60.6,56.8],["سیبری غربی",75,62],["سیبری مرکزی",95,60],["یاکوتیا",125,63],["شرق دور",135,50],["چوکوتکا",170,66],["مورمانسک",40,66.5]],
    "United States of America": [["واشنگتن",-77,38.9],["نیویورک",-74,41.5],["کالیفرنیا",-120,37],["تگزاس",-99,31],["فلوریدا",-82,28],["شیکاگو",-88,41.8],["شمال‌غرب",-121,46.5],["کوهستان راکی",-109,41],["جنوب",-87,33],["آلاسکا",-150,64],["هاوایی",-157,20.5]],
    "China": [["پکن",116.4,39.9],["شانگهای",121.5,31.2],["گوانگژو",113.3,23.1],["چونگ‌کینگ",106.5,29.5],["شین‌جیانگ",87.6,43.8],["تبت",91,30],["مغولستان داخلی",111,41.5],["منچوری",126,45.8],["سیچوان",104,30.6],["هاینان و جنوب",110,19.5]],
    "India": [["دهلی",77.2,28.6],["بمبئی",72.8,19],["کلکته",88.4,22.6],["چنای",80.3,13],["حیدرآباد",78.5,17.4],["کشمیر",75,34],["راجستان",73.8,26.5],["آسام",92.9,26.2]],
    "Brazil": [["برازیلیا",-47.9,-15.8],["سائوپائولو",-46.6,-23.5],["ریودوژانیرو",-43.2,-22.9],["آمازون",-62,-4],["شمال‌شرق",-40,-8],["جنوب",-52,-29],["ماتوگروسو",-55,-13]],
    "Canada": [["اتاوا",-75.7,45.4],["کبک",-71,47],["انتاریو",-84,50],["بریتیش‌کلمبیا",-125,54],["آلبرتا",-114,53.5],["نوناووت",-90,66],["مانیتوبا",-100,53],["یوکان",-135,63]],
    "Australia": [["سیدنی",151,-33.9],["ملبورن",145,-37.8],["کوئینزلند",145,-22],["استرالیای غربی",121,-26],["استرالیای جنوبی",135,-30],["قلمرو شمالی",133,-19],["تاسمانی",147,-42]],
    "Germany": [["برلین",13.4,52.5],["باواریا",11.5,48.5],["رور",7.2,51.4],["هامبورگ",10,53.5]],
    "France": [["پاریس",2.3,48.9],["مارسی",5.4,43.3],["لیون",4.8,45.8],["بوردو",-0.6,44.8]],
    "United Kingdom": [["لندن",-0.1,51.5],["اسکاتلند",-4.3,56.8],["ولز",-3.6,52.3],["ایرلند شمالی",-6.5,54.6],["شمال انگلیس",-1.6,54]],
    "Turkey": [["آنکارا",32.9,39.9],["استانبول",29,41],["ازمیر",27.1,38.4],["آنتالیا",30.7,37],["شرق آناتولی",41,39]],
    "Saudi Arabia": [["ریاض",46.7,24.7],["حجاز",40,21.5],["منطقهٔ شرقی",49.6,26.4],["شمال",40,29],["جنوب",43,18]],
    "Egypt": [["قاهره",31.2,30],["اسکندریه",29.9,31.2],["صعید",32.6,25.7],["سینا",33.8,29.5]],
    "Japan": [["توکیو",139.7,35.7],["اوساکا",135.5,34.7],["هوکایدو",142.9,43.1],["کیوشو",130.7,32.5]],
    "Italy": [["رم",12.5,41.9],["میلان",9.2,45.5],["ناپل",14.3,40.9],["سیسیل",14,37.5],["ساردینیا",9,40]],
    "Spain": [["مادرید",-3.7,40.4],["کاتالونیا",2.2,41.4],["اندلس",-4.8,37.4],["گالیسیا",-8,42.8]],
    "Mexico": [["مکزیکوسیتی",-99.1,19.4],["شمال",-105,28],["یوکاتان",-89,20.5],["جنوب",-96,17]],
    "Indonesia": [["جاوه",110.4,-7.3],["سوماترا",101,-0.5],["کالیمانتان",114,0],["سولاوسی",121,-2],["پاپوآ",138,-4.5]],
    "Pakistan": [["اسلام‌آباد",73.1,33.7],["کراچی",67,25],["پنجاب",74,31],["بلوچستان",66,28.5],["خیبر",71.5,34.5]],
    "Ukraine": [["کی‌یف",30.5,50.4],["خارکف",36.2,50],["اودسا",30.7,46.5],["لویو",24,49.8]],
    "Poland": [["ورشو",21,52.2],["کراکوف",19.9,50],["گدانسک",18.6,54.4]],
    "Argentina": [["بوینوس‌آیرس",-58.4,-34.6],["پاتاگونیا",-69,-45],["شمال‌غرب",-65,-26],["کویو",-68,-33]],
    "South Africa": [["پرتوریا",28.2,-25.7],["کیپ‌تاون",20,-32],["دوربان",31,-29.5]],
    "Kazakhstan": [["آستانه",71.4,51.2],["آلماتی",76.9,43.2],["غرب",55,48]]
  };

  // حکومت‌ها
  WC.GOVS = {
    republic:  { fa: 'جمهوری ریاستی',   title: 'رئیس‌جمهور', mods: { inc: 0.03, trade: 0.06 } },
    parl:      { fa: 'جمهوری پارلمانی', title: 'نخست‌وزیر',  mods: { inc: 0.05, trade: 0.1 } },
    monarchy:  { fa: 'پادشاهی مشروطه',  title: 'پادشاه',     mods: { trade: 0.1, def: 0.03 } },
    absmon:    { fa: 'پادشاهی مطلقه',   title: 'پادشاه',     mods: { atk: 0.05, tax: 0.12, inc: -0.02 } },
    emirate:   { fa: 'امارت',           title: 'امیر',       mods: { tax: 0.1, def: 0.04 } },
    islamic:   { fa: 'جمهوری اسلامی',   title: 'رهبر',       mods: { def: 0.08, atk: 0.04 } },
    communist: { fa: 'حزب واحد',        title: 'دبیرکل',     mods: { recruit: 0.25, trade: -0.08 } },
    junta:     { fa: 'دولت نظامی',      title: 'رئیس شورای نظامی', mods: { atk: 0.1, inc: -0.08, recruit: 0.2 } }
  };
  const S = s => new Set(s.split('|'));
  const G_MON = S('United Kingdom|Spain|Netherlands|Belgium|Sweden|Norway|Denmark|Thailand|Cambodia|Malaysia|Morocco|Jordan|Lesotho|Bhutan|Japan');
  const G_ABS = S('Saudi Arabia|Oman|eSwatini|Brunei');
  const G_EMI = S('United Arab Emirates|Qatar|Kuwait|Bahrain|Afghanistan');
  const G_ISL = S('Iran|Pakistan|Mauritania');
  const G_COM = S('China|Vietnam|Laos|Cuba|North Korea');
  const G_JUN = S('Myanmar|Mali|Burkina Faso|Niger|Guinea|Sudan|Chad|Eritrea|Gabon');
  const G_PAR = S('Germany|Italy|India|Israel|Greece|Ireland|Poland|Czechia|Hungary|Canada|Australia|New Zealand|Bulgaria|Romania|Slovakia|Slovenia|Croatia|Serbia|Estonia|Latvia|Lithuania|Finland|Iraq|Lebanon|Bangladesh|Nepal|Ethiopia|Portugal|Austria|Switzerland|Albania|Armenia|Georgia|Kosovo|Iceland|Luxembourg|Montenegro|North Macedonia|Moldova');
  WC.govOf = n => G_MON.has(n) ? (n === 'Japan' ? 'monarchy' : 'monarchy') : G_ABS.has(n) ? 'absmon' : G_EMI.has(n) ? 'emirate' : G_ISL.has(n) ? 'islamic' : G_COM.has(n) ? 'communist' : G_JUN.has(n) ? 'junta' : G_PAR.has(n) ? 'parl' : 'republic';
  WC.leaderTitle = (gov, name) => name === 'Japan' ? 'امپراتور' : name === 'Iran' ? 'رهبر انقلاب' : name === 'Afghanistan' ? 'امیر' : WC.GOVS[gov].title;

  WC.TRAITS = {
    warlord:   { fa: 'جنگ‌طلب',  desc: '+۸٪ حمله', atk: 0.08 },
    economist: { fa: 'اقتصاددان', desc: '+۸٪ درآمد', inc: 0.08 },
    diplomat:  { fa: 'دیپلمات',  desc: 'اتحاد و آتش‌بس آسان‌تر', dip: 15 },
    fortifier: { fa: 'مدافع',    desc: '+۸٪ دفاع', def: 0.08 },
    reformer:  { fa: 'اصلاح‌گر', desc: '−۱۵٪ هزینهٔ پژوهش', res: 0.15 },
    tyrant:    { fa: 'مستبد',    desc: '+۲۰٪ سربازگیری، −۵٪ درآمد', recruit: 0.2, inc: -0.05 }
  };

  // نام‌های تصادفی (ساختگی) بر اساس فرهنگ
  const NM = {
    persian: [['علی','رضا','حسین','مهدی','کامران','بهرام','فرید','داریوش','سعید','نادر'], ['احمدی','کریمی','رضایی','حسینی','موسوی','نوری','صادقی','قاسمی','سلطانی','فرهادی']],
    arab:    [['محمد','خالد','عبدالله','یوسف','سلمان','فیصل','طارق','هشام','ناصر','کریم'], ['العلی','المنصور','الحسن','الفهد','السعید','الرشید','الحداد','النجار','الخطیب','القاسم']],
    turkic:  [['محمت','امره','اوزان','کنان','تیمور','بولات','نورسلطان','ایبک','آیدین','سردار'], ['یلدیز','آکتاش','قایا','دمیر','عثمانف','نظربایف','کریموف','آیدین','چلیک','ارسلان']],
    slavic:  [['ایوان','الکساندر','دیمیتری','سرگئی','ولادیمیر','پاول','نیکولای','یان','پتر','اندری'], ['پتروف','ایوانف','سوکولوف','کوالسکی','نوواک','کوزلوف','وولکوف','مارکوویچ','بوریسف','کراسنف']],
    western: [['جیمز','ویلیام','هنری','تامس','پیر','هانس','لوکا','اریک','اولاف','مارک'], ['اسمیت','براون','مولر','دوبوا','روسی','اندرسون','کلارک','هوفمان','لارسن','ریچاردز']],
    latin:   [['کارلوس','خوان','ماریو','دیگو','لوئیس','ریکاردو','فرناندو','آندرس','پدرو','میگل'], ['گونزالس','سیلوا','پرز','مارتینز','رودریگز','فرناندز','لوپز','سانچز','سانتوس','کاسترو']],
    chinese: [['وی','مینگ','جین','لی','هائو','چنگ','یونگ','شیائو','تائو','جون'], ['ژانگ','وانگ','لیو','چن','یانگ','ژائو','هوانگ','ژو','وو','سان']],
    japanese:[['هیروشی','کنجی','تاکشی','یوکیو','ساتوشی','آکیرا','کازوو','هیدکی','ریو','شینجی'], ['ساتو','سوزوکی','تاکاهاشی','تاناکا','ایتو','واتانابه','یاماموتو','ناکامورا','کوبایاشی','کاتو']],
    korean:  [['مین‌جون','جیهون','سونگ‌هو','هیونوو','دونگ‌هیون','سانگ‌چول','یونگ‌ایل','تائه‌یانگ','جونگ‌ایل','وون'], ['کیم','لی','پارک','چوی','جونگ','کانگ','چو','یون','جانگ','لیم']],
    indian:  [['راجش','آمیت','ویکرام','راهول','سانجی','ارجون','دیپاک','ماهش','آنیل','راوی'], ['شارما','کومار','پاتل','سینگ','گوپتا','ردی','ورما','ناییر','چوپرا','مهتا']],
    seasia:  [['سومارتو','آنوار','نگوین','سومچای','رامون','حسن','بونمی','خمر','ویچای','لی'], ['ویدودو','ابراهیم','تران','سریسای','سانتوس','رحمان','پانیا','چان','ساتین','ابدالله']],
    african: [['کوفی','امانوئل','جوزف','موسی','ایبراهیما','سیمون','تاندو','دانیل','سامسون','اوبا'], ['موتومبو','ندیایه','دیالو','اوکونکوو','موگابه','کیپروتیچ','آدبایو','سانکارا','تراوره','بانگورا']]
  };
  const CULT = {};
  [['persian','Iran|Tajikistan'],['turkic','Turkey|Azerbaijan|Uzbekistan|Kazakhstan|Turkmenistan|Kyrgyzstan'],['slavic','Russia|Ukraine|Belarus|Poland|Czechia|Slovakia|Serbia|Bulgaria|Croatia|Slovenia|Bosnia and Herz.|Montenegro|North Macedonia|Lithuania|Latvia|Estonia|Moldova|Romania|Hungary|Georgia|Armenia'],['chinese','China|Taiwan|Mongolia'],['japanese','Japan'],['korean','North Korea|South Korea'],['indian','India|Pakistan|Bangladesh|Nepal|Bhutan|Sri Lanka'],['seasia','Indonesia|Malaysia|Thailand|Vietnam|Laos|Cambodia|Myanmar|Philippines|Brunei|Timor-Leste|Papua New Guinea'],['latin','Mexico|Spain|Portugal|Italy|Cuba|Guatemala|Honduras|El Salvador|Nicaragua|Costa Rica|Panama|Colombia|Venezuela|Ecuador|Peru|Bolivia|Chile|Argentina|Uruguay|Paraguay|Brazil|Dominican Rep.|Haiti|Greece'],['western','United States of America|Canada|United Kingdom|France|Germany|Netherlands|Belgium|Switzerland|Austria|Ireland|Denmark|Norway|Sweden|Finland|Iceland|Australia|New Zealand|Luxembourg|Israel|Greenland']]
    .forEach(([c, l]) => l.split('|').forEach(n => CULT[n] = c));
  WC.cultureOf = (name, lon, lat) => CULT[name] || (lon > -20 && lon < 62 && lat > 12 && lat < 38 ? 'arab' : lat < 12 && lon > -20 && lon < 55 ? 'african' : lat < 0 && lon < 55 ? 'african' : 'african');
  WC.randName = (culture, seedStr) => {
    const pool = NM[culture] || NM.western, h = WC.hash(seedStr), h2 = WC.hash(seedStr + 'x');
    return pool[0][Math.floor(h * pool[0].length)] + ' ' + pool[1][Math.floor(h2 * pool[1].length)];
  };
  WC.RANKS = ['', 'سرهنگ', 'سرتیپ', 'سرلشکر', 'سپهبد', 'مارشال'];

  // منابع
  WC.OIL = S('Saudi Arabia|Iran|Iraq|Kuwait|United Arab Emirates|Qatar|Russia|Venezuela|Libya|Nigeria|Algeria|Norway|Kazakhstan|Angola|Oman|Azerbaijan|Mexico|Canada|United States of America|Brazil|Egypt|Turkmenistan|Yemen|Sudan|Colombia|Ecuador');
  WC.MINE = S('South Africa|Australia|Chile|Peru|Dem. Rep. Congo|Zambia|China|Mongolia|Indonesia|Guinea|Botswana|Namibia|Bolivia|Ghana|Papua New Guinea|Sweden|Finland|India|Canada|Russia|Brazil');
  WC.FARM = S('France|Ukraine|Argentina|Brazil|India|Thailand|Vietnam|Spain|Italy|Poland|Turkey|Egypt|Pakistan|New Zealand|Denmark|Netherlands|Kenya|Ethiopia|Uruguay|Paraguay');

  // کشتی‌ها
  WC.SHIPS = {
    boat:  { fa: 'قایق گشتی',     atk: 1.2, def: 0.9, cost: 14, pw: 1.2, size: 0.7 },
    frig:  { fa: 'ناوچه',         atk: 3.0, def: 2.4, cost: 38, pw: 3.0, size: 1.0 },
    dest:  { fa: 'ناو جنگی',      atk: 6.5, def: 5.0, cost: 90, pw: 6.5, size: 1.4 },
    trans: { fa: 'ناو ترابری',    atk: 0.0, def: 0.7, cost: 30, pw: 0.5, size: 1.1, cap: 25 }
  };
  WC.SHIP_TYPES = ['boat', 'frig', 'dest', 'trans'];
  WC.BUILDINGS = {
    factory:  { fa: 'کارخانه',  max: 3, cost: 120, desc: '+۳۰٪ تولید صنعتی هر سطح' },
    market:   { fa: 'بازار و بانک', max: 3, cost: 100, desc: '+۲۵٪ تجارت هر سطح' },
    port:     { fa: 'بندر',     max: 3, cost: 90,  desc: 'ظرفیت کشتی‌سازی و تجارت دریایی' },
    fort:     { fa: 'دژ و استحکامات', max: 3, cost: 80, desc: '+۱۰٪ دفاع هر سطح' },
    barracks: { fa: 'پادگان',   max: 2, cost: 90,  desc: '+۴ ظرفیت سربازگیری هر سطح' }
  };
})(window.WC);
