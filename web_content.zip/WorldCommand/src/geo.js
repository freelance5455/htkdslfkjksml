/* فرمان جهان — بارگذاری نقشهٔ جهان (TopoJSON/GeoJSON)، تصویرسازی، همسایگی */
(function (WC) {
  const W = 2000, K = W / (2 * Math.PI);
  // تصویر میلر: شکل آشنا و کمتر کج از مرکاتور
  function proj(lon, lat) {
    const phi = lat * Math.PI / 180;
    return [(lon + 180) / 360 * W, -1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * phi)) * K];
  }
  const BOUNDS = { x0: 0, x1: W, y0: proj(0, 83.5)[1], y1: proj(0, -56)[1] };

  const CDN = {
    low:  ['https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json', 'https://unpkg.com/world-atlas@2/countries-110m.json'],
    high: ['https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json',  'https://unpkg.com/world-atlas@2/countries-50m.json']
  };

  async function fetchJSON(url) {
    const r = await fetch(url, { cache: 'force-cache' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  async function loadWorld(quality, onMsg) {
    quality = quality === 'high' ? 'high' : 'low';
    const say = m => onMsg && onMsg(m);
    // ۱) فایل محلی (ساخته‌شده با tools/get-map)
    if (window.WORLD_TOPO && window.WORLD_TOPO[quality]) return toFeatures(window.WORLD_TOPO[quality]);
    if (window.WORLD_TOPO && window.WORLD_TOPO.any) return toFeatures(window.WORLD_TOPO.any);
    // ۲) فایل JSON کنار بازی (هنگام اجرا با سرور محلی)
    try { say('جست‌وجوی نقشهٔ محلی…'); return toFeatures(await fetchJSON('data/countries-' + (quality === 'high' ? '50m' : '110m') + '.json')); } catch (e) {}
    // ۳) کش مرورگر
    try { const c = localStorage.getItem('wc_map_' + quality); if (c) { say('بارگذاری از حافظهٔ مرورگر…'); return toFeatures(JSON.parse(c)); } } catch (e) {}
    // ۴) اینترنت
    for (const url of CDN[quality]) {
      try {
        say('دریافت نقشهٔ جهان…');
        const data = await fetchJSON(url);
        try { localStorage.setItem('wc_map_' + quality, JSON.stringify(data)); } catch (e) {}
        return toFeatures(data);
      } catch (e) { /* منبع بعدی */ }
    }
    throw new Error('map-unavailable');
  }

  function decodeTopo(topo) {
    const tr = topo.transform;
    const arcs = topo.arcs.map(a => {
      let x = 0, y = 0;
      return a.map(p => { x += p[0]; y += p[1]; return tr ? [x * tr.scale[0] + tr.translate[0], y * tr.scale[1] + tr.translate[1]] : [x, y]; });
    });
    const ring = list => {
      const pts = [];
      for (const i of list) {
        const a = i >= 0 ? arcs[i] : arcs[~i].slice().reverse();
        for (let k = pts.length ? 1 : 0; k < a.length; k++) pts.push(a[k]);
      }
      return pts;
    };
    const obj = topo.objects.countries || topo.objects[Object.keys(topo.objects)[0]];
    const geoms = obj.type === 'GeometryCollection' ? obj.geometries : [obj];
    return geoms.map(g => {
      let polys = [];
      if (g.type === 'Polygon') polys = [g.arcs.map(ring)];
      else if (g.type === 'MultiPolygon') polys = g.arcs.map(p => p.map(ring));
      return { name: (g.properties && g.properties.name) || String(g.id), id: g.id, polys };
    });
  }

  function toFeatures(data) {
    if (data.type === 'Topology') return decodeTopo(data);
    const feats = data.type === 'FeatureCollection' ? data.features : [data];
    return feats.map(f => {
      const g = f.geometry;
      const polys = g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
      return { name: (f.properties && (f.properties.name || f.properties.NAME)) || String(f.id), id: f.id, polys };
    });
  }


  const hitCtx = document.createElement('canvas').getContext('2d');
  const B = BOUNDS;
  const wrapDx = (a, b) => { let d = Math.abs(a - b); return d > W / 2 ? W - d : d; };

  function ringArea(r) { let a = 0; const n = r.length / 2; for (let i = 0, j = n - 1; i < n; j = i++) a += r[2*j] * r[2*i+1] - r[2*i] * r[2*j+1]; return Math.abs(a / 2); }
  function unwrap(ring) {
    const out = []; let off = 0, prev = null;
    for (const pt of ring) {
      let lon = pt[0] + off;
      if (prev !== null) { while (lon - prev > 180) { off -= 360; lon -= 360; } while (prev - lon > 180) { off += 360; lon += 360; } }
      out.push([lon, pt[1]]); prev = lon;
    }
    return out;
  }
  function pathOf(rings) { const p = new Path2D(); rings.forEach(r => { p.moveTo(r[0], r[1]); for (let i = 2; i < r.length; i += 2) p.lineTo(r[i], r[i+1]); p.closePath(); }); return p; }
  function shiftPoly(P, dx) {
    return { rings: P.rings.map(r => { const a = new Float64Array(r.length); for (let i = 0; i < r.length; i += 2) { a[i] = r[i] + dx; a[i+1] = r[i+1]; } return a; }), area: P.area, copy: true, bbox: { x0: P.bbox.x0 + dx, x1: P.bbox.x1 + dx, y0: P.bbox.y0, y1: P.bbox.y1 } };
  }

  function labelPoint(poly) {
    const outer = poly.rings[0], n = outer.length / 2;
    const stride = Math.max(1, Math.ceil(n / 400)), pts = [];
    for (let i = 0; i < n; i += stride) pts.push(outer[2*i], outer[2*i+1]);
    const path = pathOf(poly.rings), b = poly.bbox;
    let best = null, bd = -1;
    const search = (x0, y0, x1, y1, steps) => {
      for (let i = 0; i <= steps; i++) for (let j = 0; j <= steps; j++) {
        const x = x0 + (x1 - x0) * i / steps, y = y0 + (y1 - y0) * j / steps;
        if (!hitCtx.isPointInPath(path, x, y, 'evenodd')) continue;
        let md = 1e9;
        for (let k = 0; k < pts.length; k += 2) { const dx = pts[k] - x, dy = pts[k+1] - y; const d = dx*dx + dy*dy; if (d < md) md = d; }
        if (md > bd) { bd = md; best = [x, y]; }
      }
    };
    search(b.x0, b.y0, b.x1, b.y1, 18);
    if (best) { const sx = (b.x1 - b.x0) / 18, sy = (b.y1 - b.y0) / 18; search(best[0] - sx, best[1] - sy, best[0] + sx, best[1] + sy, 8); }
    return best || [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];
  }

  // ---------- کشورها ----------
  function buildCountries(features) {
    const list = [];
    for (const f of features) {
      if (WC.SKIP.has(f.name)) continue;
      let polys = [];
      for (const poly of f.polys) {
        const rings = [];
        for (const ring of poly) {
          if (ring.length < 4) continue;
          const u = unwrap(ring);
          if (Math.abs(u[u.length - 1][0] - u[0][0]) > 180) continue;
          const arr = new Float64Array(u.length * 2);
          for (let i = 0; i < u.length; i++) { const p = proj(u[i][0], u[i][1]); arr[2*i] = p[0]; arr[2*i+1] = p[1]; }
          rings.push(arr);
        }
        if (!rings.length) continue;
        let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; const o = rings[0];
        for (let i = 0; i < o.length; i += 2) { if (o[i] < x0) x0 = o[i]; if (o[i] > x1) x1 = o[i]; if (o[i+1] < y0) y0 = o[i+1]; if (o[i+1] > y1) y1 = o[i+1]; }
        let area = ringArea(o); for (let k = 1; k < rings.length; k++) area -= ringArea(rings[k]);
        const P = { rings, area, bbox: { x0, y0, x1, y1 }, copy: false };
        polys.push(P);
      }
      if (!polys.length) continue;
      polys.sort((a, b) => b.area - a.area);
      const extra = [];
      polys.forEach(P => { if (P.bbox.x1 > W + 1) extra.push(shiftPoly(P, -W)); if (P.bbox.x0 < -1) extra.push(shiftPoly(P, W)); });
      polys = polys.concat(extra);
      const path = new Path2D(); let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9, area = 0;
      for (const P of polys) {
        P.rings.forEach(r => { path.moveTo(r[0], r[1]); for (let i = 2; i < r.length; i += 2) path.lineTo(r[i], r[i+1]); path.closePath(); });
        bx0 = Math.min(bx0, P.bbox.x0); by0 = Math.min(by0, P.bbox.y0); bx1 = Math.max(bx1, P.bbox.x1); by1 = Math.max(by1, P.bbox.y1);
        if (!P.copy) area += P.area;
      }
      const lp = labelPoint(polys[0]);
      list.push({
        id: list.length, name: f.name, fa: WC.faName(f.name), polys, path, area, wrap: extra.length > 0,
        bbox: { x0: bx0, y0: by0, x1: bx1, y1: by1 }, lbbox: polys[0].bbox, anchor: { x: lp[0], y: lp[1] }, provs: []
      });
    }
    return list;
  }
  const inCountry = (c, x, y) => hitCtx.isPointInPath(c.path, x, y, 'evenodd');

  // ---------- شبکهٔ دریا و مسیریابی ----------
  const SEA = { cs: 5, gw: 0, gh: 0, y0: 0, ocean: null, ready: false };
  function buildSea(countries) {
    const cs = SEA.cs, SC = 4;
    SEA.y0 = B.y0 - 40; SEA.gw = Math.ceil(W / cs); SEA.gh = Math.ceil((B.y1 - B.y0 + 80) / cs);
    const cv = document.createElement('canvas'); cv.width = SEA.gw * SC; cv.height = SEA.gh * SC;
    const g = cv.getContext('2d', { willReadFrequently: true });
    g.scale(SC / cs, SC / cs); g.translate(0, -SEA.y0); g.fillStyle = '#000';
    countries.forEach(c => g.fill(c.path, 'evenodd'));
    const data = g.getImageData(0, 0, cv.width, cv.height).data, gw = SEA.gw, gh = SEA.gh;
    const sea = new Uint8Array(gw * gh);
    for (let cy = 0; cy < gh; cy++) for (let cx = 0; cx < gw; cx++) {
      let any = 0;
      for (let sy = 0; sy < SC && !any; sy++) for (let sx = 0; sx < SC; sx++) { if (data[(((cy * SC + sy) * cv.width) + cx * SC + sx) * 4 + 3] < 110) { any = 1; break; } }
      sea[cy * gw + cx] = any;
    }
    // بزرگ‌ترین مؤلفهٔ متصل (اقیانوس)
    const comp = new Int32Array(gw * gh), sizes = [0]; let nc = 0;
    for (let i = 0; i < gw * gh; i++) {
      if (!sea[i] || comp[i]) continue;
      nc++; let n = 0; const st = [i]; comp[i] = nc;
      while (st.length) {
        const c = st.pop(); n++; const cx = c % gw, cy = (c / gw) | 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue; const ny = cy + dy; if (ny < 0 || ny >= gh) continue;
          const nx = (cx + dx + gw) % gw, ni = ny * gw + nx;
          if (sea[ni] && !comp[ni]) { comp[ni] = nc; st.push(ni); }
        }
      }
      sizes[nc] = n;
    }
    let main = 1; for (let i = 1; i <= nc; i++) if (sizes[i] > sizes[main]) main = i;
    SEA.ocean = new Uint8Array(gw * gh);
    for (let i = 0; i < gw * gh; i++) SEA.ocean[i] = comp[i] === main ? 1 : 0;
    SEA.ready = true;
  }
  SEA.cellOf = (x, y) => { x = ((x % W) + W) % W; return [Math.floor(x / SEA.cs), Math.max(0, Math.min(SEA.gh - 1, Math.floor((y - SEA.y0) / SEA.cs)))]; };
  SEA.center = (cx, cy) => [((((cx + 0.5) * SEA.cs) % W) + W) % W, SEA.y0 + (cy + 0.5) * SEA.cs];
  SEA.isOcean = (cx, cy) => cy >= 0 && cy < SEA.gh && SEA.ocean[cy * SEA.gw + ((cx % SEA.gw) + SEA.gw) % SEA.gw] === 1;
  SEA.near = (x, y, r) => {
    const [c0, r0] = SEA.cellOf(x, y); let best = null, bd = 1e9;
    for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
      if (SEA.isOcean(c0 + dx, r0 + dy)) { const d = dx * dx + dy * dy; if (d < bd) { bd = d; best = [(c0 + dx + SEA.gw) % SEA.gw, r0 + dy]; } }
    }
    return best;
  };
  // A* روی شبکهٔ دریا (با چرخش افقی نقشه)
  SEA.path = (a, b) => {
    const gw = SEA.gw, gh = SEA.gh; if (!a || !b) return null;
    const key = (x, y) => y * gw + x, goal = key(b[0], b[1]);
    const h = (x, y) => { let dx = Math.abs(x - b[0]); dx = Math.min(dx, gw - dx); const dy = Math.abs(y - b[1]); return Math.max(dx, dy) + 0.41 * Math.min(dx, dy); };
    const open = [[h(a[0], a[1]), a[0], a[1]]], gs = new Map([[key(a[0], a[1]), 0]]), from = new Map(), closed = new Set();
    const push = n => { open.push(n); let i = open.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (open[p][0] <= open[i][0]) break; [open[p], open[i]] = [open[i], open[p]]; i = p; } };
    const pop = () => { const t = open[0], l = open.pop(); if (open.length) { open[0] = l; let i = 0; for (;;) { let m = i; const L = 2 * i + 1, R = L + 1; if (L < open.length && open[L][0] < open[m][0]) m = L; if (R < open.length && open[R][0] < open[m][0]) m = R; if (m === i) break; [open[m], open[i]] = [open[i], open[m]]; i = m; } } return t; };
    let guard = 0;
    while (open.length && guard++ < 120000) {
      const [, x, y] = pop(), k = key(x, y);
      if (closed.has(k)) continue; closed.add(k);
      if (k === goal) {
        const path = [[x, y]]; let c = k;
        while (from.has(c)) { c = from.get(c); path.push([c % gw, (c / gw) | 0]); }
        path.reverse();
        // پیوستگی افقی: مختصات ناپیوسته را باز کن
        const out = [path[0].slice()];
        for (let i = 1; i < path.length; i++) { let px = out[i - 1][0], nx = path[i][0]; while (nx - px > gw / 2) nx -= gw; while (px - nx > gw / 2) nx += gw; out.push([nx, path[i][1]]); }
        return out;
      }
      const g0 = gs.get(k);
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dy) continue; const ny = y + dy; if (ny < 0 || ny >= gh) continue;
        const nx = (x + dx + gw) % gw, nk = key(nx, ny);
        if (!SEA.ocean[nk] || closed.has(nk)) continue;
        const ng = g0 + (dx && dy ? 1.41 : 1);
        if (gs.has(nk) && gs.get(nk) <= ng) continue;
        gs.set(nk, ng); from.set(nk, k); push([ng + h(nx, ny), nx, ny]);
      }
    }
    return null;
  };

  // ---------- استان‌ها (تقسیم کشور با وورونوی) ----------
  function clipCell(rect, seeds, i) {
    let P = rect.map(p => p.slice()), lab = rect.map(() => -1);
    const s = seeds[i];
    for (let j = 0; j < seeds.length; j++) {
      if (j === i) continue;
      const o = seeds[j];
      for (const off of [0, -W, W]) {
        const ox = o.x + off, oy = o.y;
        const nx = ox - s.x, ny = oy - s.y, mx = (s.x + ox) / 2, my = (s.y + oy) / 2;
        if (Math.abs(off) && Math.hypot(nx, ny) > 900) continue;
        const f = p => (p[0] - mx) * nx + (p[1] - my) * ny; // ≤0: سمت s
        const out = [], ol = [], n = P.length;
        if (!n) break;
        for (let a = 0; a < n; a++) {
          const A = P[a], Bp = P[(a + 1) % n], fa = f(A), fb = f(Bp), ina = fa <= 0, inb = fb <= 0;
          if (ina) { out.push(A); ol.push(lab[a]); }
          if (ina !== inb) { const t = fa / (fa - fb); out.push([A[0] + (Bp[0] - A[0]) * t, A[1] + (Bp[1] - A[1]) * t]); ol.push(ina ? j : lab[a]); }
        }
        P = out; lab = ol;
      }
    }
    return { P, lab };
  }
  const DIRS = ['شرق', 'شمال‌شرقی', 'شمال', 'شمال‌غربی', 'غرب', 'جنوب‌غربی', 'جنوب', 'جنوب‌شرقی'];

  function subdivide(countries) {
    const provs = [];
    for (const c of countries) {
      const base = c.polys.filter(p => !p.copy), bb = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
      base.forEach(p => { bb.x0 = Math.min(bb.x0, p.bbox.x0); bb.x1 = Math.max(bb.x1, p.bbox.x1); bb.y0 = Math.min(bb.y0, p.bbox.y0); bb.y1 = Math.max(bb.y1, p.bbox.y1); });
      // نمونه‌برداری از درون کشور
      const pts = [], step = Math.max(1.2, Math.sqrt(c.area / 700));
      for (let x = bb.x0 + step / 2; x < bb.x1; x += step) for (let y = bb.y0 + step / 2; y < bb.y1; y += step) if (inCountry(c, x, y)) pts.push([x, y]);
      if (!pts.length) pts.push([c.anchor.x, c.anchor.y]);
      const reg = WC.REG[c.name], cap = WC.CAP[c.name];
      let k = reg ? reg.length : Math.max(1, Math.min(16, Math.round(Math.sqrt(c.area) / 16)));
      if (pts.length < k * 2) k = Math.max(1, Math.floor(pts.length / 2));
      const snap = (x, y) => { let b = pts[0], bd = 1e18; for (const p of pts) { const d = (p[0] - x) ** 2 + (p[1] - y) ** 2; if (d < bd) { bd = d; b = p; } } return { x: b[0], y: b[1] }; };
      let seeds = [], names = [], fixed = 0;
      if (reg) { reg.slice(0, k).forEach(r => { const q = proj(r[1], r[2]); seeds.push(inCountry(c, q[0], q[1]) ? { x: q[0], y: q[1] } : snap(q[0], q[1])); names.push(r[0]); }); fixed = seeds.length; }
      else {
        if (cap) { const q = proj(cap.lon, cap.lat); seeds.push(inCountry(c, q[0], q[1]) ? { x: q[0], y: q[1] } : snap(q[0], q[1])); fixed = 1; }
        else seeds.push(snap(c.anchor.x, c.anchor.y));
        names.push(null);
        // نقطه‌های دور از هم
        while (seeds.length < k) { let best = null, bd = -1; for (const p of pts) { let md = 1e18; for (const s of seeds) { const d = wrapDx(p[0], s.x) ** 2 + (p[1] - s.y) ** 2; if (d < md) md = d; } if (md > bd) { bd = md; best = p; } } seeds.push({ x: best[0], y: best[1] }); names.push(null); }
        for (let it = 0; it < 7 && k > 1; it++) {
          const sx = seeds.map(() => 0), sy = seeds.map(() => 0), cn = seeds.map(() => 0);
          for (const p of pts) { let bi = 0, bd = 1e18; seeds.forEach((s, i) => { const d = wrapDx(p[0], s.x) ** 2 + (p[1] - s.y) ** 2; if (d < bd) { bd = d; bi = i; } }); sx[bi] += p[0]; sy[bi] += p[1]; cn[bi]++; }
          for (let i = fixed; i < k; i++) if (cn[i]) seeds[i] = snap(sx[i] / cn[i], sy[i] / cn[i]);
        }
      }
      k = seeds.length;
      // سهم مساحت
      const cnt = seeds.map(() => 0);
      for (const p of pts) { let bi = 0, bd = 1e18; seeds.forEach((s, i) => { const d = wrapDx(p[0], s.x) ** 2 + (p[1] - s.y) ** 2; if (d < bd) { bd = d; bi = i; } }); cnt[bi]++; }
      // نام‌گذاری
      const cx = seeds.reduce((a, s) => a + s.x, 0) / k, cy = seeds.reduce((a, s) => a + s.y, 0) / k, used = {};
      for (let i = 0; i < k; i++) {
        if (names[i]) continue;
        if (i === 0) { names[i] = k === 1 ? c.fa : (cap ? cap.fa : 'مرکز ' + c.fa); continue; }
        const ang = Math.atan2(-(seeds[i].y - cy), seeds[i].x - cx), idx = ((Math.round(ang / (Math.PI / 4)) % 8) + 8) % 8;
        let nm = DIRS[idx] + ' ' + c.fa; used[nm] = (used[nm] || 0) + 1; if (used[nm] > 1) nm += ' ' + WC.fa(used[nm]); names[i] = nm;
      }
      // سلول‌های وورونوی
      const rect = [[bb.x0 - 12, bb.y0 - 12], [bb.x1 + 12, bb.y0 - 12], [bb.x1 + 12, bb.y1 + 12], [bb.x0 - 12, bb.y1 + 12]];
      c.seeds = seeds; c.provs = [];
      for (let i = 0; i < k; i++) {
        let cell = null, lab = [], P = [];
        if (k > 1) { const r = clipCell(rect, seeds, i); P = r.P; lab = r.lab; cell = new Path2D(); P.forEach((q, j) => j ? cell.lineTo(q[0], q[1]) : cell.moveTo(q[0], q[1])); cell.closePath(); }
        const id = provs.length;
        const pr = { id, c: c.id, ci: i, name: names[i], seed: seeds[i], anchor: seeds[i], cell, cellPts: P, cellLab: lab, share: cnt[i] / pts.length, port: null, coastal: false, neighbors: [], isCap: i === 0 };
        provs.push(pr); c.provs.push(id);
      }
    }
    return provs;
  }
  function seedOf(c, x, y) { let bi = 0, bd = 1e18; c.seeds.forEach((s, i) => { const d = wrapDx(x, s.x) ** 2 + (y - s.y) ** 2; if (d < bd) { bd = d; bi = i; } }); return bi; }

  function linkAll(countries, provs) {
    const link = new Map();
    const key = (a, b) => a < b ? a + '_' + b : b + '_' + a;
    const add = (a, b, sea) => { if (a === b) return; const k = key(a, b); const o = link.get(k); if (!o) link.set(k, { a: Math.min(a, b), b: Math.max(a, b), sea }); else if (!sea) o.sea = false; };
    // داخل کشور
    countries.forEach(c => {
      c.provs.forEach(pid => {
        const p = provs[pid], P = p.cellPts, n = P.length;
        const nb = new Map();
        for (let a = 0; a < n; a++) { const j = p.cellLab[a]; if (j < 0) continue; const A = P[a], Bq = P[(a + 1) % n]; const len = Math.hypot(A[0] - Bq[0], A[1] - Bq[1]); if (len > 0.5) nb.set(j, [(A[0] + Bq[0]) / 2, (A[1] + Bq[1]) / 2]); }
        nb.forEach((mid, j) => {
          const q = provs[c.provs[j]]; if (!q) return;
          const mx = ((mid[0] % W) + W) % W;
          if (inCountry(c, mx, mid[1])) add(p.id, q.id, false);
          else { const [cx, cy] = SEA.cellOf(mx, mid[1]); if (SEA.isOcean(cx, cy) || SEA.isOcean(cx + 1, cy) || SEA.isOcean(cx, cy + 1)) add(p.id, q.id, true); }
        });
      });
    });
    // مرز خشکی بین کشورها
    const seen = new Map(), cLinks = new Set();
    countries.forEach(c => c.polys.forEach(poly => poly.rings.forEach(r => {
      for (let k = 0; k < r.length; k += 2) {
        const kk = Math.round(r[k] * 50) + ',' + Math.round(r[k+1] * 50), o = seen.get(kk);
        if (o === undefined) seen.set(kk, c.id);
        else if (o !== c.id) { const oc = countries[o]; add(c.provs[seedOf(c, r[k], r[k+1])], oc.provs[seedOf(oc, r[k], r[k+1])], false); cLinks.add(key(c.id, o)); }
      }
    })));
    // دریا بین کشورها
    const pts = []; let total = 0;
    countries.forEach(c => c.polys.forEach(poly => { if (!poly.copy) total += poly.rings[0].length / 2; }));
    const stride = Math.max(1, Math.ceil(total / 9000));
    countries.forEach(c => c.polys.forEach(poly => { const r = poly.rings[0]; for (let k = 0; k < r.length; k += 2 * stride) pts.push([r[k], r[k+1], c.id]); }));
    const CELL = 50, TH = 30, grid = new Map();
    pts.forEach((p, idx) => { const k = Math.floor(p[0] / CELL) + ':' + Math.floor(p[1] / CELL); (grid.get(k) || grid.set(k, []).get(k)).push(idx); });
    const minD = new Map();
    pts.forEach(p => {
      const kx = Math.floor(p[0] / CELL), ky = Math.floor(p[1] / CELL);
      for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
        const cell = grid.get((kx + dx) + ':' + (ky + dy)); if (!cell) continue;
        for (const j of cell) { const q = pts[j]; if (q[2] === p[2]) continue; const d = Math.hypot(p[0] - q[0], p[1] - q[1]); if (d > TH) continue; const k = key(p[2], q[2]), cur = minD.get(k); if (!cur || d < cur.d) minD.set(k, { d, a: p, b: q }); }
      }
    });
    const per = countries.map(() => []);
    minD.forEach((v, k) => { if (cLinks.has(k)) return; per[v.a[2]].push(v); per[v.b[2]].push(v); });
    const keep = new Set();
    per.forEach(arr => { arr.sort((x, y) => x.d - y.d); arr.slice(0, 4).forEach(v => keep.add(v)); });
    keep.forEach(v => { const ca = countries[v.a[2]], cb = countries[v.b[2]]; add(ca.provs[seedOf(ca, v.a[0], v.a[1])], cb.provs[seedOf(cb, v.b[0], v.b[1])], true); });
    // اتصال اجزای جدا
    const n = provs.length, par = Array.from({ length: n }, (_, i) => i), find = x => par[x] === x ? x : (par[x] = find(par[x]));
    link.forEach(l => { par[find(l.a)] = find(l.b); });
    for (let g = 0; g < n; g++) {
      const cnt = new Map(); provs.forEach((_, i) => { const r = find(i); cnt.set(r, (cnt.get(r) || 0) + 1); });
      if (cnt.size <= 1) break;
      let main = null, mc = 0; cnt.forEach((v, r) => { if (v > mc) { mc = v; main = r; } });
      let done = false;
      for (const r of cnt.keys()) {
        if (r === main) continue; let best = null, bd = 1e18;
        provs.forEach((p, i) => { if (find(i) !== r) return; provs.forEach((q, j) => { if (find(j) === r) return; const d = wrapDx(p.seed.x, q.seed.x) ** 2 + (p.seed.y - q.seed.y) ** 2; if (d < bd) { bd = d; best = [i, j]; } }); });
        if (best) { add(best[0], best[1], true); par[find(best[0])] = find(best[1]); done = true; break; }
      }
      if (!done) break;
    }
    link.forEach(l => { provs[l.a].neighbors.push({ to: l.b, sea: l.sea }); provs[l.b].neighbors.push({ to: l.a, sea: l.sea }); });
  }

  function findPorts(countries, provs) {
    countries.forEach(c => {
      const best = c.provs.map(() => null);
      c.polys.forEach(poly => {
        if (poly.copy) return; const r = poly.rings[0], st = r.length > 4000 ? 2 : 1;
        for (let k = 0; k < r.length; k += 2 * st) {
          const x = r[k], y = r[k+1], i = seedOf(c, x, y), s = c.seeds[i], d = wrapDx(x, s.x) ** 2 + (y - s.y) ** 2;
          if (best[i] && d >= best[i].d) continue;
          const cell = SEA.near(x, y, 2); if (!cell) continue;
          best[i] = { d, x, y, cell };
        }
      });
      c.provs.forEach((pid, i) => { const b = best[i]; if (b) { provs[pid].port = { x: b.x, y: b.y, cell: b.cell }; provs[pid].coastal = true; } });
    });
  }

  function build(features) {
    const countries = buildCountries(features);
    buildSea(countries);
    const provs = subdivide(countries);
    findPorts(countries, provs);
    linkAll(countries, provs);
    // همسایگی کشورها
    countries.forEach(c => c.nb = new Set());
    provs.forEach(p => p.neighbors.forEach(l => { const a = p.c, b = provs[l.to].c; if (a !== b) { countries[a].nb.add(b); countries[b].nb.add(a); } }));
    return { countries, provs };
  }
  const provAt = (c, x, y) => c.provs[seedOf(c, x, y)];

  WC.geo = { W, K, BOUNDS, proj, loadWorld, build, toFeatures, SEA, wrapDx, inCountry, provAt, seedOf };
})(window.WC);
