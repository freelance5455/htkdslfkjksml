/* فرمان جهان — بارگذاری نقشهٔ جهان (TopoJSON/GeoJSON)، تصویرسازی، همسایگی */
(function (WC) {
  const W = 2000, K = W / (2 * Math.PI);
  // تصویر میلر: شکل آشنا و کمتر کج از مرکاتور
  function proj(lon, lat) {
    const phi = lat * Math.PI / 180;
    return [(lon + 180) / 360 * W, -1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * phi)) * K];
  }
  const BOUNDS = { x0: 0, x1: W, y0: proj(0, 83.5)[1], y1: proj(0, -56)[1] };

  const CDN = {
    low:  ['https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json', 'https://unpkg.com/world-atlas@2/countries-110m.json'],
    high: ['https://cdn.jsdelivr.net/npm/world-atlas@2/countries-50m.json',  'https://unpkg.com/world-atlas@2/countries-50m.json']
  };

  async function fetchJSON(url) {
    const r = await fetch(url, { cache: 'force-cache' });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  async function loadWorld(quality, onMsg) {
    quality = quality === 'high' ? 'high' : 'low';
    const say = m => onMsg && onMsg(m);
    // ۱) فایل محلی (ساخته‌شده با tools/get-map)
    if (window.WORLD_TOPO && window.WORLD_TOPO[quality]) return toFeatures(window.WORLD_TOPO[quality]);
    if (window.WORLD_TOPO && window.WORLD_TOPO.any) return toFeatures(window.WORLD_TOPO.any);
    // ۲) فایل JSON کنار بازی (هنگام اجرا با سرور محلی)
    try { say('جست‌وجوی نقشهٔ محلی…'); return toFeatures(await fetchJSON('data/countries-' + (quality === 'high' ? '50m' : '110m') + '.json')); } catch (e) {}
    // ۳) کش مرورگر
    try { const c = localStorage.getItem('wc_map_' + quality); if (c) { say('بارگذاری از حافظهٔ مرورگر…'); return toFeatures(JSON.parse(c)); } } catch (e) {}
    // ۴) اینترنت
    for (const url of CDN[quality]) {
      try {
        say('دریافت نقشهٔ جهان…');
        const data = await fetchJSON(url);
        try { localStorage.setItem('wc_map_' + quality, JSON.stringify(data)); } catch (e) {}
        return toFeatures(data);
      } catch (e) { /* منبع بعدی */ }
    }
    throw new Error('map-unavailable');
  }

  function decodeTopo(topo) {
    const tr = topo.transform;
    const arcs = topo.arcs.map(a => {
      let x = 0, y = 0;
      return a.map(p => { x += p[0]; y += p[1]; return tr ? [x * tr.scale[0] + tr.translate[0], y * tr.scale[1] + tr.translate[1]] : [x, y]; });
    });
    const ring = list => {
      const pts = [];
      for (const i of list) {
        const a = i >= 0 ? arcs[i] : arcs[~i].slice().reverse();
        for (let k = pts.length ? 1 : 0; k < a.length; k++) pts.push(a[k]);
      }
      return pts;
    };
    const obj = topo.objects.countries || topo.objects[Object.keys(topo.objects)[0]];
    const geoms = obj.type === 'GeometryCollection' ? obj.geometries : [obj];
    return geoms.map(g => {
      let polys = [];
      if (g.type === 'Polygon') polys = [g.arcs.map(ring)];
      else if (g.type === 'MultiPolygon') polys = g.arcs.map(p => p.map(ring));
      return { name: (g.properties && g.properties.name) || String(g.id), id: g.id, polys };
    });
  }

  function toFeatures(data) {
    if (data.type === 'Topology') return decodeTopo(data);
    const feats = data.type === 'FeatureCollection' ? data.features : [data];
    return feats.map(f => {
      const g = f.geometry;
      const polys = g.type === 'Polygon' ? [g.coordinates] : g.coordinates;
      return { name: (f.properties && (f.properties.name || f.properties.NAME)) || String(f.id), id: f.id, polys };
    });
  }

  const hitCtx = document.createElement('canvas').getContext('2d');

  function ringArea(r) { let a = 0; const n = r.length / 2; for (let i = 0, j = n - 1; i < n; j = i++) a += r[2*j] * r[2*i+1] - r[2*i] * r[2*j+1]; return Math.abs(a / 2); }

  function labelPoint(poly) {
    const outer = poly.rings[0], n = outer.length / 2;
    const stride = Math.max(1, Math.ceil(n / 400));
    const pts = [];
    for (let i = 0; i < n; i += stride) pts.push(outer[2*i], outer[2*i+1]);
    const path = new Path2D();
    poly.rings.forEach(r => { path.moveTo(r[0], r[1]); for (let i = 2; i < r.length; i += 2) path.lineTo(r[i], r[i+1]); path.closePath(); });
    const b = poly.bbox;
    let best = null, bd = -1;
    const search = (x0, y0, x1, y1, steps) => {
      for (let i = 0; i <= steps; i++) for (let j = 0; j <= steps; j++) {
        const x = x0 + (x1 - x0) * i / steps, y = y0 + (y1 - y0) * j / steps;
        if (!hitCtx.isPointInPath(path, x, y, 'evenodd')) continue;
        let md = 1e9;
        for (let k = 0; k < pts.length; k += 2) { const dx = pts[k] - x, dy = pts[k+1] - y; const d = dx*dx + dy*dy; if (d < md) md = d; }
        if (md > bd) { bd = md; best = [x, y]; }
      }
    };
    search(b.x0, b.y0, b.x1, b.y1, 18);
    if (best) { const sx = (b.x1 - b.x0) / 18, sy = (b.y1 - b.y0) / 18; search(best[0] - sx, best[1] - sy, best[0] + sx, best[1] + sy, 8); }
    if (!best) best = [(b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2];
    return best;
  }

  function buildProvinces(features) {
    const provs = [];
    for (const f of features) {
      if (WC.SKIP.has(f.name)) continue;
      const polys = [];
      for (const poly of f.polys) {
        const rings = [];
        for (const ring of poly) {
          if (ring.length < 3) continue;
          const arr = new Float64Array(ring.length * 2);
          for (let i = 0; i < ring.length; i++) { const p = proj(ring[i][0], ring[i][1]); arr[2*i] = p[0]; arr[2*i+1] = p[1]; }
          rings.push(arr);
        }
        if (!rings.length) continue;
        let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        const o = rings[0];
        for (let i = 0; i < o.length; i += 2) { if (o[i] < x0) x0 = o[i]; if (o[i] > x1) x1 = o[i]; if (o[i+1] < y0) y0 = o[i+1]; if (o[i+1] > y1) y1 = o[i+1]; }
        let area = ringArea(o); for (let k = 1; k < rings.length; k++) area -= ringArea(rings[k]);
        polys.push({ rings, area, bbox: { x0, y0, x1, y1 } });
      }
      if (!polys.length) continue;
      polys.sort((a, b) => b.area - a.area);
      const path = new Path2D();
      let bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9, area = 0;
      for (const p of polys) {
        for (const r of p.rings) { path.moveTo(r[0], r[1]); for (let i = 2; i < r.length; i += 2) path.lineTo(r[i], r[i+1]); path.closePath(); }
        bx0 = Math.min(bx0, p.bbox.x0); by0 = Math.min(by0, p.bbox.y0); bx1 = Math.max(bx1, p.bbox.x1); by1 = Math.max(by1, p.bbox.y1);
        area += p.area;
      }
      const lp = labelPoint(polys[0]);
      const id = provs.length;
      provs.push({
        id, name: f.name, fa: WC.faName(f.name), polys, path, area,
        bbox: { x0: bx0, y0: by0, x1: bx1, y1: by1 },
        lbbox: polys[0].bbox, anchor: { x: lp[0], y: lp[1] },
        neighbors: [], coastal: !WC.LANDLOCKED.has(f.name)
      });
    }
    computeLinks(provs);
    return provs;
  }

  function computeLinks(provs) {
    const n = provs.length;
    const link = new Map(); // "a_b" -> {a,b,sea}
    const key = (a, b) => a < b ? a + '_' + b : b + '_' + a;
    const add = (a, b, sea) => { const k = key(a, b); if (!link.has(k)) link.set(k, { a: Math.min(a, b), b: Math.max(a, b), sea }); };

    // خشکی: رأس‌های مشترک مرز
    const seen = new Map();
    provs.forEach((p, i) => p.polys.forEach(poly => poly.rings.forEach(r => {
      for (let k = 0; k < r.length; k += 2) {
        const kk = Math.round(r[k] * 50) + ',' + Math.round(r[k+1] * 50);
        const o = seen.get(kk);
        if (o === undefined) seen.set(kk, i);
        else if (o !== i) add(o, i, false);
      }
    })));

    // دریا: نزدیک‌ترین فاصله بین سواحل
    const pts = []; let total = 0;
    provs.forEach(p => p.polys.forEach(poly => poly.rings.forEach(r => total += r.length / 2)));
    const stride = Math.max(1, Math.ceil(total / 9000));
    provs.forEach((p, i) => p.polys.forEach(poly => { const r = poly.rings[0]; for (let k = 0; k < r.length; k += 2 * stride) pts.push([r[k], r[k+1], i]); }));
    const CELL = 50, TH = 30;
    const grid = new Map();
    pts.forEach((p, idx) => { const kx = Math.floor(p[0] / CELL), ky = Math.floor(p[1] / CELL); const k = kx + ':' + ky; (grid.get(k) || grid.set(k, []).get(k)).push(idx); });
    const minD = new Map();
    pts.forEach(p => {
      const kx = Math.floor(p[0] / CELL), ky = Math.floor(p[1] / CELL);
      for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
        const cell = grid.get((kx + dx) + ':' + (ky + dy)); if (!cell) continue;
        for (const j of cell) {
          const q = pts[j]; if (q[2] === p[2]) continue;
          const d = Math.hypot(p[0] - q[0], p[1] - q[1]); if (d > TH) continue;
          const k = key(p[2], q[2]); const cur = minD.get(k);
          if (cur === undefined || d < cur) minD.set(k, d);
        }
      }
    });
    // برای هر استان حداکثر ۴ مسیر دریایی نزدیک
    const perProv = Array.from({ length: n }, () => []);
    minD.forEach((d, k) => { if (link.has(k)) return; const [a, b] = k.split('_').map(Number); perProv[a].push([d, b]); perProv[b].push([d, a]); });
    const keep = new Set();
    perProv.forEach((arr, a) => { arr.sort((x, y) => x[0] - y[0]); arr.slice(0, 4).forEach(([d, b]) => keep.add(key(a, b))); });
    keep.forEach(k => { const [a, b] = k.split('_').map(Number); add(a, b, true); });

    // اتصال اجزای جدا (جزایر دور)
    const par = Array.from({ length: n }, (_, i) => i);
    const find = x => par[x] === x ? x : (par[x] = find(par[x]));
    link.forEach(l => { par[find(l.a)] = find(l.b); });
    for (let guard = 0; guard < n; guard++) {
      const roots = new Set(provs.map((_, i) => find(i)));
      if (roots.size <= 1) break;
      let main = null, mc = 0; const cnt = new Map();
      provs.forEach((_, i) => { const r = find(i); cnt.set(r, (cnt.get(r) || 0) + 1); });
      cnt.forEach((c, r) => { if (c > mc) { mc = c; main = r; } });
      let done = false;
      for (const r of roots) {
        if (r === main) continue;
        let best = null, bd = 1e9;
        provs.forEach((p, i) => { if (find(i) !== r) return; provs.forEach((q, j) => { if (find(j) === r) return; const d = Math.hypot(p.anchor.x - q.anchor.x, p.anchor.y - q.anchor.y); if (d < bd) { bd = d; best = [i, j]; } }); });
        if (best) { add(best[0], best[1], true); par[find(best[0])] = find(best[1]); done = true; break; }
      }
      if (!done) break;
    }

    link.forEach(l => {
      provs[l.a].neighbors.push({ to: l.b, sea: l.sea });
      provs[l.b].neighbors.push({ to: l.a, sea: l.sea });
    });
    provs.forEach(p => { if (p.neighbors.some(x => x.sea)) p.hasSea = true; });
  }

  WC.geo = { W, K, BOUNDS, proj, loadWorld, buildProvinces, toFeatures };
})(window.WC);
