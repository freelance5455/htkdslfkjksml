/* فرمان جهان — صدا و موسیقی با WebAudio (بدون فایل صوتی) */
(function (WC) {
  let ctx = null, master = null, musicBus = null, sfxOn = true, musicOn = true, timer = null, chordI = 0;
  try { const s = JSON.parse(localStorage.getItem('wc_audio') || '{}'); if (s.sfx === false) sfxOn = false; if (s.music === false) musicOn = false; } catch (e) {}

  function init() {
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.7; master.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = musicOn ? 0.5 : 0; musicBus.connect(master);
    if (musicOn) startMusic();
  }
  function tone(f, d, type, v, slide, delay) {
    if (!ctx || !sfxOn) return;
    const t = ctx.currentTime + (delay || 0);
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v || 0.15, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + d + 0.05);
  }
  let noiseBuf = null;
  function noise(d, f0, f1, v, delay) {
    if (!ctx || !sfxOn) return;
    if (!noiseBuf) { noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate); const a = noiseBuf.getChannelData(0); for (let i = 0; i < a.length; i++) a[i] = Math.random() * 2 - 1; }
    const t = ctx.currentTime + (delay || 0);
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const fl = ctx.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + d);
    const g = ctx.createGain(); g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(fl); fl.connect(g); g.connect(master); s.start(t, Math.random()); s.stop(t + d + 0.05);
  }
  const SFX = {
    click:   () => tone(520, 0.06, 'square', 0.05, 80),
    error:   () => { tone(180, 0.18, 'sawtooth', 0.08, -60); },
    recruit: () => { noise(0.08, 3000, 800, 0.18); tone(220, 0.1, 'square', 0.06, -80, 0.04); },
    move:    () => { noise(0.25, 900, 200, 0.14); },
    attack:  () => { noise(0.9, 2400, 70, 0.5); tone(90, 0.5, 'sine', 0.35, -60); noise(0.3, 4000, 500, 0.25, 0.25); },
    capture: () => { [392, 494, 587, 784].forEach((f, i) => tone(f, 0.35, 'triangle', 0.12, 0, i * 0.09)); },
    lose:    () => { [330, 262, 196].forEach((f, i) => tone(f, 0.5, 'sawtooth', 0.07, 0, i * 0.18)); },
    war:     () => { tone(110, 0.9, 'sawtooth', 0.12, -20); tone(165, 0.9, 'sawtooth', 0.08, -30); noise(0.5, 600, 100, 0.2); },
    peace:   () => { [523, 659, 784].forEach((f, i) => tone(f, 0.5, 'sine', 0.1, 0, i * 0.12)); },
    research:() => { [440, 660, 880].forEach((f, i) => tone(f, 0.18, 'square', 0.05, 0, i * 0.07)); },
    turn:    () => { tone(147, 0.7, 'sawtooth', 0.09, 0); tone(220, 0.7, 'sawtooth', 0.06, 0); },
    nuke:    () => { noise(3.2, 3000, 40, 0.9); tone(50, 2.5, 'sine', 0.6, -25); noise(2, 800, 40, 0.5, 0.6); },
    win:     () => { [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.5, 'triangle', 0.14, 0, i * 0.14)); }
  };
  function play(n) { try { if (SFX[n]) SFX[n](); } catch (e) {} }

  // موسیقی محیطی: آکوردهای آرام و درون‌مایهٔ نظامی
  const CHORDS = [[110, 165, 220, 262], [87.3, 131, 175, 220], [130.8, 196, 262, 330], [98, 147, 196, 247]];
  function pad() {
    if (!ctx || !musicOn) return;
    const ch = CHORDS[chordI++ % CHORDS.length], t = ctx.currentTime, d = 8;
    ch.forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain(), fl = ctx.createBiquadFilter();
      o.type = i === 0 ? 'sawtooth' : 'triangle'; o.frequency.value = f; o.detune.value = (Math.random() - 0.5) * 12;
      fl.type = 'lowpass'; fl.frequency.value = i === 0 ? 260 : 900;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(i === 0 ? 0.05 : 0.028, t + 2.5); g.gain.linearRampToValueAtTime(0.0001, t + d + 1);
      o.connect(fl); fl.connect(g); g.connect(musicBus); o.start(t); o.stop(t + d + 1.2);
    });
    // ضربهٔ آرام شبیه طبل دور
    [0, 2, 4, 6].forEach(k => { const tt = t + k; const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(70, tt); o.frequency.exponentialRampToValueAtTime(38, tt + 0.4); g.gain.setValueAtTime(0.05, tt); g.gain.exponentialRampToValueAtTime(0.0001, tt + 0.5); o.connect(g); g.connect(musicBus); o.start(tt); o.stop(tt + 0.6); });
  }
  function startMusic() { if (timer) return; pad(); timer = setInterval(pad, 8000); }
  function stopMusic() { clearInterval(timer); timer = null; }
  function persist() { try { localStorage.setItem('wc_audio', JSON.stringify({ sfx: sfxOn, music: musicOn })); } catch (e) {} }

  WC.audio = {
    init, play,
    get sfx() { return sfxOn; }, get music() { return musicOn; },
    setSfx(v) { sfxOn = v; persist(); },
    setMusic(v) { musicOn = v; persist(); if (!ctx) return; musicBus.gain.value = v ? 0.5 : 0; if (v) startMusic(); else stopMusic(); }
  };
})(window.WC);
