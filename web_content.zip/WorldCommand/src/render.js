/* فرمان جهان — رندر نقشه: اقیانوس، خشکی، مرزها، واحدها، جلوه‌ها */
(function (WC) {
  const R = WC.R = {};
  let canvas, ctx, dpr = 1, Wpx = 0, Hpx = 0;
  const cam = R.cam = { x: 1000, y: -120, z: 0.6 };
  let camAnim = null;
  let provs = [], land = null, order = [];
  R.targets = new Map(); R.selected = -1; R.hover = -1; R.linksFor = -1; R.onClick = null; R.onHover = null;
  const fx = { arrows: [], parts: [], rings: [], flash: 0, flashCol: '255,255,255', shake: 0, mush: [] };
  let noiseTile = null, waveTile = null, noisePat = null, wavePat = null;
  const B = WC.geo.BOUNDS;
  const TAU = Math.PI * 2;

  function makeNoise(size) {
    const c = document.createElement('canvas'); c.width = c.height = size;
    const g = c.getContext('2d'), img = g.createImageData(size, size), d = img.data;
    const octs = [[6, 0.5], [12, 0.27], [24, 0.15], [48, 0.08]];
    const grids = octs.map(([n]) => Array.from({ length: n * n }, Math.random));
    const sm = t => t * t * (3 - 2 * t);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      let v = 0;
      octs.forEach(([n, w], k) => {
        const fx_ = x / size * n, fy_ = y / size * n;
        const x0 = Math.floor(fx_), y0 = Math.floor(fy_), tx = sm(fx_ - x0), ty = sm(fy_ - y0);
        const g_ = grids[k], a = g_[(y0 % n) * n + (x0 % n)], b = g_[(y0 % n) * n + ((x0 + 1) % n)], c2 = g_[((y0 + 1) % n) * n + (x0 % n)], e = g_[((y0 + 1) % n) * n + ((x0 + 1) % n)];
        v += w * ((a * (1 - tx) + b * tx) * (1 - ty) + (c2 * (1 - tx) + e * tx) * ty);
      });
      const i = (y * size + x) * 4, val = Math.max(0, Math.min(255, Math.round(v * 255)));
      d[i] = d[i+1] = d[i+2] = val; d[i+3] = 255;
    }
    g.putImageData(img, 0, 0); return c;
  }
  function makeWaves(size) {
    const c = document.createElement('canvas'); c.width = c.height = size;
    const g = c.getContext('2d'), img = g.createImageData(size, size), d = img.data;
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      const u = x / size * TAU, v = y / size * TAU;
      const s = Math.sin(3 * u + 1.6 * Math.sin(2 * v) + Math.sin(v) * 0.8) * 0.5 + 0.5;
      const s2 = Math.sin(5 * v + 1.2 * Math.sin(3 * u)) * 0.5 + 0.5;
      const a = Math.pow(s, 14) * 70 + Math.pow(s2, 18) * 40;
      const i = (y * size + x) * 4; d[i] = 150; d[i+1] = 215; d[i+2] = 235; d[i+3] = Math.min(255, a);
    }
    g.putImageData(img, 0, 0); return c;
  }

  R.init = function (cv) {
    canvas = cv; ctx = cv.getContext('2d');
    noiseTile = makeNoise(256); waveTile = makeWaves(256);
    noisePat = ctx.createPattern(noiseTile, 'repeat'); wavePat = ctx.createPattern(waveTile, 'repeat');
    resize(); window.addEventListener('resize', resize);
    bindInput();
    requestAnimationFrame(frame);
  };
  R.setProvinces = function (p) {
    provs = p; land = new Path2D(); p.forEach(q => land.addPath(q.path));
    order = p.slice().sort((a, b) => a.area - b.area);
    R.fitWorld();
  };
  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    Wpx = window.innerWidth; Hpx = window.innerHeight;
    canvas.width = Wpx * dpr; canvas.height = Hpx * dpr; canvas.style.width = Wpx + 'px'; canvas.style.height = Hpx + 'px';
    clampCam();
  }
  const minZoom = () => Math.min(Wpx / (B.x1 - B.x0), Hpx / (B.y1 - B.y0)) * 1.0;
  R.fitWorld = function () { cam.z = minZoom() * 1.02; cam.x = (B.x0 + B.x1) / 2; cam.y = (B.y0 + B.y1) / 2 + 20; clampCam(); };
  function clampCam() {
    cam.z = Math.max(minZoom(), Math.min(16, cam.z));
    const hw = Wpx / (2 * cam.z), hh = Hpx / (2 * cam.z);
    const mx = 30, my = 40;
    if (hw * 2 >= (B.x1 - B.x0) + mx * 2) cam.x = (B.x0 + B.x1) / 2; else cam.x = Math.max(B.x0 - mx + hw, Math.min(B.x1 + mx - hw, cam.x));
    if (hh * 2 >= (B.y1 - B.y0) + my * 2) cam.y = (B.y0 + B.y1) / 2; else cam.y = Math.max(B.y0 - my + hh, Math.min(B.y1 + my - hh, cam.y));
  }
  const w2s = R.w2s = (x, y) => [(x - cam.x) * cam.z + Wpx / 2, (y - cam.y) * cam.z + Hpx / 2];
  const s2w = R.s2w = (sx, sy) => [(sx - Wpx / 2) / cam.z + cam.x, (sy - Hpx / 2) / cam.z + cam.y];

  R.flyTo = function (wx, wy, z, dur) {
    camAnim = { x0: cam.x, y0: cam.y, z0: cam.z, x1: wx, y1: wy, z1: z, t0: performance.now(), dur: dur || 900 };
  };
  R.focusProvince = function (p, zoomMul) {
    const b = p.lbbox, w = Math.max(20, b.x1 - b.x0), h = Math.max(14, b.y1 - b.y0);
    const z = Math.min(8, Math.min(Wpx * 0.45 / w, Hpx * 0.45 / h) * (zoomMul || 1));
    const zz = Math.max(minZoom() * 1.4, Math.min(z, minZoom() * 7));
    R.flyTo(p.anchor.x, p.anchor.y + (Wpx < 760 && WC.UI && WC.UI.mode === 'game' ? Hpx * 0.22 / zz : 0), zz, 1100);
  };

  // ---------- ورودی ----------
  const hitCtx = document.createElement('canvas').getContext('2d');
  R.hit = function (sx, sy) {
    const [x, y] = s2w(sx, sy);
    for (const p of order) {
      const b = p.bbox; if (x < b.x0 || x > b.x1 || y < b.y0 || y > b.y1) continue;
      if (hitCtx.isPointInPath(p.path, x, y, 'evenodd')) return p;
    }
    let best = null, bd = 16;
    for (const p of provs) { const [ax, ay] = w2s(p.anchor.x, p.anchor.y); const d = Math.hypot(ax - sx, ay - sy); if (d < bd) { bd = d; best = p; } }
    return best;
  };
  function bindInput() {
    const ptr = new Map(); let drag = null, pinch = null;
    canvas.addEventListener('pointerdown', e => {
      canvas.setPointerCapture(e.pointerId); ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
      camAnim = null;
      if (ptr.size === 1) drag = { x: e.clientX, y: e.clientY, cx: cam.x, cy: cam.y, moved: false };
      else if (ptr.size === 2) { const [a, b] = [...ptr.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), z: cam.z }; drag = null; }
    });
    canvas.addEventListener('pointermove', e => {
      if (ptr.has(e.pointerId)) ptr.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (pinch && ptr.size >= 2) {
        const [a, b] = [...ptr.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y);
        cam.z = pinch.z * d / pinch.d; clampCam(); return;
      }
      if (drag && ptr.size === 1) {
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 5) drag.moved = true;
        if (drag.moved) { cam.x = drag.cx - dx / cam.z; cam.y = drag.cy - dy / cam.z; clampCam(); }
      } else if (e.pointerType === 'mouse') {
        const p = R.hit(e.clientX, e.clientY); R.hover = p ? p.id : -1;
        if (R.onHover) R.onHover(p, e.clientX, e.clientY);
      }
    });
    const up = e => {
      const had = ptr.has(e.pointerId); ptr.delete(e.pointerId);
      if (ptr.size < 2) pinch = null;
      if (had && drag && !drag.moved && ptr.size === 0 && e.type === 'pointerup') { const p = R.hit(e.clientX, e.clientY); if (R.onClick) R.onClick(p, e); }
      if (ptr.size === 0) drag = null;
    };
    canvas.addEventListener('pointerup', up); canvas.addEventListener('pointercancel', up);
    canvas.addEventListener('pointerleave', () => { R.hover = -1; if (R.onHover) R.onHover(null); });
    canvas.addEventListener('wheel', e => {
      e.preventDefault(); camAnim = null;
      const [wx, wy] = s2w(e.clientX, e.clientY);
      cam.z *= Math.exp(-e.deltaY * 0.0015); cam.z = Math.max(minZoom(), Math.min(16, cam.z));
      cam.x = wx - (e.clientX - Wpx / 2) / cam.z; cam.y = wy - (e.clientY - Hpx / 2) / cam.z; clampCam();
    }, { passive: false });
    canvas.addEventListener('contextmenu', e => { e.preventDefault(); if (R.onClick) R.onClick(null, e); });
  }
  R.zoomBy = function (k) { cam.z *= k; clampCam(); };

  // ---------- جلوه‌ها ----------
  R.addArrow = function (a, b, color, kind, onArrive) {
    fx.arrows.push({ a, b, color, kind, t0: performance.now(), dur: kind === 'attack' ? 750 : 600, done: false, onArrive });
  };
  R.boom = function (wx, wy, big, color) {
    const now = performance.now();
    fx.rings.push({ wx, wy, t0: now, dur: 900, color: color || '255,190,90', max: big ? 70 : 42 });
    fx.rings.push({ wx, wy, t0: now + 90, dur: 700, color: '255,255,255', max: big ? 46 : 26 });
    const n = big ? 46 : 26;
    for (let i = 0; i < n; i++) {
      const a = Math.random() * TAU, s = (big ? 90 : 55) * (0.3 + Math.random());
      fx.parts.push({ wx, wy, ox: 0, oy: 0, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 18, t0: now, life: 500 + Math.random() * 800, size: 1.6 + Math.random() * (big ? 4 : 3), hot: Math.random() < 0.55, smoke: Math.random() < 0.35 });
    }
  };
  R.captureRipple = function (wx, wy, rgb) { fx.rings.push({ wx, wy, t0: performance.now(), dur: 1300, color: rgb || '255,255,255', max: 90, thick: 4 }); };
  R.nuke = function (wx, wy) {
    const now = performance.now();
    fx.flash = now + 1600; fx.shake = now + 1800;
    fx.mush.push({ wx, wy, t0: now, dur: 5000 });
    for (let k = 0; k < 4; k++) fx.rings.push({ wx, wy, t0: now + k * 220, dur: 1800, color: '255,220,160', max: 160 + k * 40, thick: 5 });
    for (let i = 0; i < 90; i++) { const a = Math.random() * TAU, s = 40 + Math.random() * 190; fx.parts.push({ wx, wy, ox: 0, oy: 0, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 40, t0: now, life: 900 + Math.random() * 1600, size: 2 + Math.random() * 5, hot: Math.random() < 0.6, smoke: Math.random() < 0.4 }); }
  };

  // ---------- رسم ----------
  function frame(now) {
    requestAnimationFrame(frame);
    if (!ctx || !provs.length) return;
    if (camAnim) {
      const t = Math.min(1, (now - camAnim.t0) / camAnim.dur), e = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      cam.x = camAnim.x0 + (camAnim.x1 - camAnim.x0) * e; cam.y = camAnim.y0 + (camAnim.y1 - camAnim.y0) * e;
      cam.z = Math.exp(Math.log(camAnim.z0) + (Math.log(camAnim.z1) - Math.log(camAnim.z0)) * e);
      clampCam(); if (t >= 1) camAnim = null;
    }
    
    draw(now);
  }

  function draw(now) {
    const G = WC.G, z = cam.z;
    let shx = 0, shy = 0;
    if (fx.shake > now) { const a = (fx.shake - now) / 1800 * 10; shx = (Math.random() - 0.5) * a; shy = (Math.random() - 0.5) * a; }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    // اقیانوس
    const og = ctx.createRadialGradient(Wpx / 2, Hpx / 2, Math.min(Wpx, Hpx) * 0.1, Wpx / 2, Hpx / 2, Math.max(Wpx, Hpx) * 0.75);
    og.addColorStop(0, '#1d5670'); og.addColorStop(0.55, '#123b50'); og.addColorStop(1, '#071a26');
    ctx.fillStyle = og; ctx.fillRect(0, 0, Wpx, Hpx);
    ctx.save();
    ctx.translate(shx, shy);
    // امواج
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.setTransform(dpr * 1.4, 0, 0, dpr * 1.4, (now * 0.012 - cam.x * z * 0.5) * dpr, (Math.sin(now / 5000) * 8 - cam.y * z * 0.5) * dpr);
    ctx.fillStyle = wavePat; ctx.fillRect(-2000, -2000, 8000, 8000);
    ctx.restore();

    // مختصات جهان
    ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * (Wpx / 2 - cam.x * z + shx), dpr * (Hpx / 2 - cam.y * z + shy));
    // شبکهٔ مختصات
    ctx.lineWidth = 0.7 / z; ctx.strokeStyle = 'rgba(160,215,235,0.07)';
    ctx.beginPath();
    for (let lon = -180; lon <= 180; lon += 20) { const x = (lon + 180) / 360 * WC.geo.W; ctx.moveTo(x, B.y0 - 40); ctx.lineTo(x, B.y1 + 40); }
    for (let lat = -50; lat <= 80; lat += 10) { const y = WC.geo.proj(0, lat)[1]; ctx.moveTo(B.x0, y); ctx.lineTo(B.x1, y); }
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,210,120,0.12)'; ctx.setLineDash([6 / z, 6 / z]); ctx.beginPath(); const ey = WC.geo.proj(0, 0)[1]; ctx.moveTo(B.x0, ey); ctx.lineTo(B.x1, ey); ctx.stroke(); ctx.setLineDash([]);

    // هالهٔ آب‌های کم‌عمق
    ctx.lineJoin = 'round';
    ctx.strokeStyle = 'rgba(110,210,225,0.10)'; ctx.lineWidth = 22 / z; ctx.stroke(land);
    ctx.strokeStyle = 'rgba(130,225,235,0.14)'; ctx.lineWidth = 11 / z; ctx.stroke(land);
    // سایهٔ خشکی
    ctx.save();
    ctx.shadowColor = 'rgba(0,10,20,0.65)'; ctx.shadowBlur = 26 * dpr; ctx.shadowOffsetY = 10 * dpr;
    ctx.fillStyle = '#0a1a22'; ctx.fill(land, 'evenodd');
    ctx.restore();

    // کشورها
    const nations = G ? G.nations : null;
    for (const p of provs) {
      const c = nations && nations[p.owner] ? nations[p.owner].css : { fill: '#556' };
      ctx.fillStyle = c.fill; ctx.fill(p.path, 'evenodd');
    }
    // بافت و نور
    ctx.save();
    ctx.clip(land, 'evenodd');
    ctx.globalCompositeOperation = 'overlay'; ctx.globalAlpha = 0.55;
    ctx.save(); ctx.scale(1.3, 1.3); ctx.fillStyle = noisePat; ctx.fillRect(B.x0 / 1.3 - 10, B.y0 / 1.3 - 10, 2100 / 1.3, 1100 / 1.3); ctx.restore();
    ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    const lg = ctx.createLinearGradient(B.x0, B.y0, B.x1, B.y1);
    lg.addColorStop(0, 'rgba(255,250,235,0.16)'); lg.addColorStop(0.5, 'rgba(0,0,0,0)'); lg.addColorStop(1, 'rgba(0,10,25,0.28)');
    ctx.fillStyle = lg; ctx.fillRect(B.x0 - 20, B.y0 - 40, 2060, 1100);
    ctx.restore();

    // مرزهای رنگی مالکیت + خط مرز تیره
    const bw = 1 / z;
    for (const p of provs) {
      const c = nations && nations[p.owner] ? nations[p.owner].css : null;
      if (c && p.owner !== p.id) { ctx.strokeStyle = c.hi; ctx.lineWidth = 2.4 * bw; ctx.globalAlpha = 0.55; ctx.stroke(p.path); ctx.globalAlpha = 1; }
    }
    ctx.strokeStyle = 'rgba(6,14,20,0.78)'; ctx.lineWidth = Math.max(0.5, 1.15) * bw;
    for (const p of provs) ctx.stroke(p.path);
    // خط ساحلی روشن
    ctx.strokeStyle = 'rgba(210,240,245,0.20)'; ctx.lineWidth = 0.9 * bw; ctx.stroke(land);

    // برجسته‌سازی‌ها
    const pulse = 0.55 + 0.45 * Math.sin(now / 260);
    if (R.hover >= 0 && provs[R.hover]) { ctx.fillStyle = 'rgba(255,255,255,0.14)'; ctx.fill(provs[R.hover].path, 'evenodd'); }
    R.targets.forEach((kind, id) => {
      const p = provs[id]; if (!p) return;
      const col = kind === 'attack' ? '236,84,60' : kind === 'war' ? '255,150,40' : kind === 'blocked' ? '150,150,150' : '70,200,170';
      ctx.fillStyle = `rgba(${col},${0.14 + 0.16 * pulse})`; ctx.fill(p.path, 'evenodd');
      ctx.strokeStyle = `rgba(${col},${0.7 + 0.3 * pulse})`; ctx.lineWidth = 2.6 * bw; ctx.stroke(p.path);
    });
    if (R.selected >= 0 && provs[R.selected]) {
      const p = provs[R.selected];
      ctx.save(); ctx.shadowColor = 'rgba(255,215,110,0.9)'; ctx.shadowBlur = 16 * dpr;
      ctx.strokeStyle = `rgba(255,222,130,${0.75 + 0.25 * pulse})`; ctx.lineWidth = 3.2 * bw; ctx.stroke(p.path); ctx.restore();
    }
    // مسیرهای دریایی
    if (R.linksFor >= 0 && provs[R.linksFor]) {
      const p = provs[R.linksFor];
      ctx.save(); ctx.setLineDash([7 * bw, 6 * bw]); ctx.lineDashOffset = -now / 60 * bw; ctx.strokeStyle = 'rgba(160,230,245,0.75)'; ctx.lineWidth = 1.8 * bw;
      p.neighbors.forEach(l => { if (!l.sea) return; const q = provs[l.to]; ctx.beginPath(); ctx.moveTo(p.anchor.x, p.anchor.y); const mx = (p.anchor.x + q.anchor.x) / 2, my = (p.anchor.y + q.anchor.y) / 2 - Math.hypot(p.anchor.x - q.anchor.x, p.anchor.y - q.anchor.y) * 0.12; ctx.quadraticCurveTo(mx, my, q.anchor.x, q.anchor.y); ctx.stroke(); });
      ctx.restore();
    }
    ctx.restore();

    // ---- فضای صفحه ----
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.save(); ctx.translate(shx, shy);
    if (G && G.nations) drawLabels(G, now);
    drawFx(now);
    ctx.restore();
    if (fx.flash > now) { const a = Math.min(1, (fx.flash - now) / 1600); ctx.fillStyle = `rgba(255,245,225,${a * 0.9})`; ctx.fillRect(0, 0, Wpx, Hpx); }
  }

  function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function tankIcon(x, y, s, col) {
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.fillStyle = col;
    ctx.beginPath(); ctx.moveTo(-6, 1); ctx.lineTo(6, 1); ctx.lineTo(5, 4); ctx.lineTo(-5, 4); ctx.closePath(); ctx.fill();
    ctx.fillRect(-3, -2, 6, 3); ctx.fillRect(1, -1.3, 7, 1.3);
    ctx.restore();
  }

  function drawLabels(G, now) {
    const me = G.player, z = cam.z;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    const showAll = z > 1.5;
    for (const p of provs) {
      const owner = G.nations[p.owner]; if (!owner || !owner.alive) continue;
      const [sx, sy] = w2s(p.anchor.x, p.anchor.y);
      if (sx < -80 || sx > Wpx + 80 || sy < -40 || sy > Hpx + 40) continue;
      const bw = (p.lbbox.x1 - p.lbbox.x0) * z, bh = (p.lbbox.y1 - p.lbbox.y0) * z;
      const isMine = p.owner === me, selected = p.id === R.selected || p.id === R.hover;
      const fs = Math.max(10, Math.min(17, Math.sqrt(bw * bh) / 7.5 + 7));
      const nameW = p.fa.length * fs * 0.52;
      const canName = (bw > nameW * 0.8 && bh > fs * 1.2) || selected || (showAll && bw > 22) || (isMine && bw > 14);
      if (!canName && bw < 15 && !selected) continue;
      if (canName) {
        ctx.font = `700 ${fs}px Vazirmatn, Tahoma, 'Segoe UI', sans-serif`;
        ctx.lineWidth = 3.4; ctx.strokeStyle = 'rgba(8,16,22,0.85)'; ctx.strokeText(p.fa, sx, sy - fs * 0.55);
        ctx.fillStyle = isMine ? '#ffe3a0' : '#f4f6f6'; ctx.fillText(p.fa, sx, sy - fs * 0.55);
      }
      if (bw > 20 || isMine || selected) {
        const pw = WC.game.unitPower(p.units);
        const txt = WC.compactFa(pw);
        ctx.font = `700 ${Math.max(10, Math.min(13, fs - 3))}px Vazirmatn, Tahoma, sans-serif`;
        const tw = ctx.measureText(txt).width, w = tw + 22, h = Math.max(15, Math.min(18, fs));
        const by = sy + (canName ? fs * 0.7 : 0);
        ctx.globalAlpha = isMine && p.acted ? 0.65 : 1;
        roundRect(sx - w / 2, by - h / 2, w, h, 4);
        ctx.fillStyle = 'rgba(8,16,22,0.82)'; ctx.fill();
        ctx.lineWidth = 1.4; ctx.strokeStyle = owner.css.hi; ctx.stroke();
        tankIcon(sx - w / 2 + 9, by, 0.62, owner.css.hi);
        ctx.fillStyle = '#fff'; ctx.fillText(txt, sx + 6, by + 0.5);
        if (isMine && !p.acted && G.player >= 0 && !G.busy && pw > 3) { ctx.fillStyle = `rgba(110,230,170,${0.6 + 0.4 * Math.sin(now / 300)})`; ctx.beginPath(); ctx.arc(sx + w / 2 - 1, by - h / 2 + 1, 2.6, 0, TAU); ctx.fill(); }
        if (p.irr > 0) { ctx.fillStyle = '#ffd24a'; ctx.fillText('☢', sx + w / 2 + 8, by); }
        ctx.globalAlpha = 1;
      }
    }
  }

  function bez(a, b, t) {
    const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2 - Math.hypot(a[0] - b[0], a[1] - b[1]) * 0.22;
    const u = 1 - t; return [u * u * a[0] + 2 * u * t * mx + t * t * b[0], u * u * a[1] + 2 * u * t * my + t * t * b[1]];
  }
  function drawFx(now) {
    // پیکان‌ها
    fx.arrows = fx.arrows.filter(a => now - a.t0 < a.dur + 500);
    for (const a of fx.arrows) {
      const p = Math.max(0, Math.min(1, (now - a.t0) / a.dur)), fade = now - a.t0 > a.dur ? 1 - (now - a.t0 - a.dur) / 500 : 1;
      const A = w2s(a.a[0], a.a[1]), Bp = w2s(a.b[0], a.b[1]);
      ctx.save(); ctx.globalAlpha = fade; ctx.lineCap = 'round';
      ctx.strokeStyle = a.color; ctx.lineWidth = a.kind === 'attack' ? 4 : 3; ctx.shadowColor = a.color; ctx.shadowBlur = 10; ctx.setLineDash([9, 6]); ctx.lineDashOffset = -now / 25;
      ctx.beginPath(); const N = 28; for (let i = 0; i <= N; i++) { const q = bez(A, Bp, p * i / N); i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); } ctx.stroke();
      ctx.setLineDash([]);
      const head = bez(A, Bp, p), prev = bez(A, Bp, Math.max(0, p - 0.04)), ang = Math.atan2(head[1] - prev[1], head[0] - prev[0]);
      ctx.fillStyle = a.color; ctx.translate(head[0], head[1]); ctx.rotate(ang);
      ctx.beginPath(); ctx.moveTo(9, 0); ctx.lineTo(-5, -6); ctx.lineTo(-2, 0); ctx.lineTo(-5, 6); ctx.closePath(); ctx.fill();
      ctx.restore();
      if (p >= 1 && !a.done) { a.done = true; if (a.onArrive) a.onArrive(); }
    }
    // حلقه‌ها
    fx.rings = fx.rings.filter(r => now - r.t0 < r.dur);
    for (const r of fx.rings) {
      const t = (now - r.t0) / r.dur; if (t < 0) continue;
      const [x, y] = w2s(r.wx, r.wy);
      ctx.beginPath(); ctx.arc(x, y, r.max * (1 - Math.pow(1 - t, 2.2)), 0, TAU);
      ctx.strokeStyle = `rgba(${r.color},${(1 - t) * 0.9})`; ctx.lineWidth = (r.thick || 3) * (1 - t) + 0.5; ctx.stroke();
      if (!r.thick) { const g = ctx.createRadialGradient(x, y, 0, x, y, r.max * 0.8 * (1 - (1 - t) * (1 - t))); g.addColorStop(0, `rgba(255,230,160,${(1 - t) * 0.55})`); g.addColorStop(1, 'rgba(255,120,40,0)'); ctx.fillStyle = g; ctx.globalCompositeOperation = 'lighter'; ctx.fillRect(x - r.max, y - r.max, r.max * 2, r.max * 2); ctx.globalCompositeOperation = 'source-over'; }
    }
    // ذرات
    fx.parts = fx.parts.filter(q => now - q.t0 < q.life);
    for (const q of fx.parts) {
      const t = Math.max(0, (now - q.t0) / q.life), s = Math.max(0, (now - q.t0) / 1000);
      const [x, y] = w2s(q.wx, q.wy);
      const px = x + q.vx * s * (1 - t * 0.5), py = y + q.vy * s + 30 * s * s * (q.smoke ? -1 : 1);
      ctx.globalAlpha = (1 - t) * 0.9;
      ctx.fillStyle = q.smoke ? 'rgba(60,60,64,0.8)' : q.hot ? 'rgba(255,170,60,1)' : 'rgba(255,240,200,1)';
      ctx.beginPath(); ctx.arc(px, py, q.size * (q.smoke ? 1 + t * 2 : 1 - t * 0.5), 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // قارچ اتمی
    fx.mush = fx.mush.filter(m => now - m.t0 < m.dur);
    for (const m of fx.mush) {
      const t = Math.max(0, (now - m.t0) / m.dur), [x, y] = w2s(m.wx, m.wy), h = 90 * Math.min(1, t * 2.2), a = Math.min(1, (1 - t) * 1.6);
      ctx.save(); ctx.globalAlpha = a;
      const g = ctx.createRadialGradient(x, y - h, 4, x, y - h, 46); g.addColorStop(0, 'rgba(255,240,190,1)'); g.addColorStop(0.5, 'rgba(255,140,50,0.9)'); g.addColorStop(1, 'rgba(90,40,30,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y - h, 46, 0, TAU); ctx.fill();
      ctx.fillStyle = 'rgba(190,100,50,0.8)'; ctx.fillRect(x - 6, y - h, 12, h);
      ctx.fillStyle = 'rgba(70,50,45,0.7)'; ctx.beginPath(); ctx.ellipse(x, y, 34 * Math.min(1, t * 3), 9, 0, 0, TAU); ctx.fill();
      ctx.restore();
    }
  }

  R.get = () => ({ cam, Wpx, Hpx });
})(window.WC);
