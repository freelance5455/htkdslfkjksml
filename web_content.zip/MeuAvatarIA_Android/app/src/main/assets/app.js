import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { VRMLoaderPlugin } from "@pixiv/three-vrm";
import * as webllm from "https://esm.run/@mlc-ai/web-llm";

const MODEL = "Llama-3.2-1B-Instruct-q4f16_1-MLC";
const VRM_URL = "avatar/model.vrm";

const input = document.getElementById("input");
const messages = document.getElementById("messages");
const send = document.getElementById("send");
const mic = document.getElementById("mic");
const status = document.getElementById("status");
const loading = document.getElementById("loading");
const stage = document.getElementById("avatarStage");

let engine = null;
let history = [];
let vrm = null;
let renderer = null;
let scene = null;
let camera = null;
let speaking = false;
let speakTimer = null;
let lastTime = performance.now();

function add(text, who) {
  const d = document.createElement("div");
  d.className = "msg " + who;
  d.textContent = text;
  messages.appendChild(d);
  messages.scrollTop = messages.scrollHeight;
}

function setExpression(name, value) {
  if (!vrm?.expressionManager) return;
  vrm.expressionManager.setValue(name, value);
}

function mood(m) {
  if (!vrm?.expressionManager) return;
  for (const n of ["happy", "angry", "sad", "surprised"]) setExpression(n, 0);
  if (m === "happy") setExpression("happy", 0.75);
  if (m === "surprised") setExpression("surprised", 0.7);
  if (m === "sad") setExpression("sad", 0.5);
}

function save() {
  localStorage.setItem("avatarIA_local_history", JSON.stringify(history.slice(-20)));
}

function loadHistory() {
  try { history = JSON.parse(localStorage.getItem("avatarIA_local_history") || "[]"); }
  catch { history = []; }
}

function startLipSync(text) {
  if (!vrm?.expressionManager) return;
  speaking = true;
  clearInterval(speakTimer);
  let i = 0;
  const vowels = ["aa", "ih", "ou", "oh", "aa", "ih"];
  speakTimer = setInterval(() => {
    if (!speaking) return;
    setExpression("aa", 0);
    setExpression("ih", 0);
    setExpression("oh", 0);
    setExpression("ou", 0);
    const char = (text?.replace(/\s/g, "").toLowerCase() || "")[i++ % Math.max(1, text.replace(/\s/g, "").length)];
    const vowel = char && "aeáàãâ".includes(char) ? "aa" : char && "eiéêí".includes(char) ? "ih" : char && "oóôõ".includes(char) ? "oh" : char && "uú".includes(char) ? "ou" : vowels[i % vowels.length];
    setExpression(vowel, 0.55 + Math.random() * 0.35);
  }, 90);
}

function stopLipSync() {
  speaking = false;
  clearInterval(speakTimer);
  for (const n of ["aa", "ih", "oh", "ou"]) setExpression(n, 0);
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "pt-BR";
  u.rate = 1;
  u.pitch = 1;
  u.onstart = () => { startLipSync(text); mood("happy"); };
  u.onend = () => { stopLipSync(); mood("happy"); };
  u.onerror = () => { stopLipSync(); };
  speechSynthesis.speak(u);
}

async function loadVRM() {
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x10131a);

  camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
  camera.position.set(0, 1.05, 2.35);

  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  stage.appendChild(renderer.domElement);

  const hemi = new THREE.HemisphereLight(0xffffff, 0x303744, 2.0);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xffffff, 2.4);
  key.position.set(1.5, 2.5, 3);
  scene.add(key);
  const fill = new THREE.DirectionalLight(0x88aaff, 0.8);
  fill.position.set(-2, 1, 1);
  scene.add(fill);

  const loader = new GLTFLoader();
  loader.register(parser => new VRMLoaderPlugin(parser));

  const gltf = await loader.loadAsync(VRM_URL);
  vrm = gltf.userData.vrm;
  if (!vrm) throw new Error("O arquivo VRM foi carregado, mas não foi reconhecido como VRM.");

  scene.add(vrm.scene);
  vrm.scene.rotation.y = Math.PI;
  vrm.scene.position.y = -0.78;

  if (vrm.lookAt) vrm.lookAt.target = camera;
  setExpression("neutral", 1);
  mood("happy");
  loading.remove();
  status.textContent = "🟢 Avatar VRM";
  resize();
  requestAnimationFrame(loop);
}

function resize() {
  if (!renderer || !camera) return;
  const w = stage.clientWidth || 320;
  const h = stage.clientHeight || 420;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}

function loop(now) {
  const delta = Math.min((now - lastTime) / 1000, 0.05);
  lastTime = now;
  if (vrm) vrm.update(delta);
  if (renderer && scene && camera) renderer.render(scene, camera);
  requestAnimationFrame(loop);
}

async function startAI() {
  if (!("gpu" in navigator)) {
    status.textContent = "⚠️ sem WebGPU";
    add("Seu navegador não oferece WebGPU. O avatar pode abrir normalmente, mas a IA local não poderá iniciar aqui.", "ai");
    send.disabled = true;
    return;
  }
  try {
    engine = await webllm.CreateMLCEngine(MODEL, {
      initProgressCallback: p => {
        const pct = p.progress ? Math.round(p.progress * 100) : 0;
        status.textContent = "🧠 " + pct + "%";
      }
    }, { context_window_size: 2048 });
    status.textContent = "🟢 IA + VRM";
    add("IA local pronta. Pode falar comigo. 🔥", "ai");
  } catch (e) {
    status.textContent = "⚠️ IA offline";
    add("O avatar abriu, mas a IA local não iniciou: " + e.message, "ai");
  }
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  if (!engine) {
    add("A IA ainda está carregando. Aguarde o download/preparo do modelo.", "ai");
    return;
  }
  add(text, "user");
  input.value = "";
  history.push({ role: "user", content: text });
  mood("surprised");
  try {
    const r = await engine.chat.completions.create({
      messages: [
        { role: "system", content: "Você é um avatar virtual brasileiro, amigável, natural e descontraído. Responda em português do Brasil. Seja conciso e converse como um amigo." },
        ...history.slice(-12)
      ],
      temperature: 0.8,
      max_tokens: 256
    });
    const answer = r.choices?.[0]?.message?.content || "Não consegui responder.";
    history.push({ role: "assistant", content: answer });
    save();
    add(answer, "ai");
    speak(answer);
  } catch (e) {
    add("Erro: " + e.message, "ai");
    mood("surprised");
  }
}

send.onclick = sendMessage;
input.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });
window.addEventListener("resize", resize);

mic.onclick = () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { add("Reconhecimento de voz não está disponível neste navegador.", "ai"); return; }
  const r = new SR();
  r.lang = "pt-BR";
  r.onstart = () => { status.textContent = "🎙️ ouvindo"; mood("surprised"); };
  r.onresult = e => { input.value = e.results[0][0].transcript; sendMessage(); };
  r.onerror = () => { status.textContent = vrm ? "🟢 Avatar VRM" : "⏳ iniciando..."; mood("happy"); };
  r.onend = () => { if (vrm) status.textContent = engine ? "🟢 IA + VRM" : "🟢 Avatar VRM"; };
  r.start();
};

loadHistory();
loadVRM().catch(e => {
  loading.textContent = "Não consegui carregar o model.vrm: " + e.message;
  status.textContent = "❌ VRM";
  add("Erro ao carregar o seu avatar: " + e.message, "ai");
});
startAI();
