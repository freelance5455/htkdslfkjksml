MEU AVATAR IA — PROJETO ANDROID PREPARADO

Este projeto transforma a versão web em um app Android via WebView.

INCLUÍDO:
- Seu model.vrm em app/src/main/assets/avatar/model.vrm
- Interface HTML/CSS/JS
- Three.js + three-vrm via CDN
- WebLLM via CDN
- TTS do aparelho/navegador
- suporte a microfone/permissão de áudio

COMO GERAR O APK:
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Vá em Build > Build APK(s).
4. O APK de debug ficará em app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE:
- O projeto precisa de internet na primeira sincronização para baixar o plugin Android Gradle.
- O app também usa recursos CDN e WebLLM, então a primeira execução precisa de internet.
- A IA local depende de WebGPU. A disponibilidade de WebGPU dentro do WebView varia conforme a versão do Android/System WebView. O avatar 3D pode abrir mesmo se a IA local não iniciar.
- O reconhecimento SpeechRecognition também depende do suporte do WebView/dispositivo.
