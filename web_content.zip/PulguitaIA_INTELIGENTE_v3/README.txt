Pulguita IA — Inteligente v3
Base profesional con interpretación local por intención.
Funciones: memoria, resúmenes extractivos, cálculos, porcentajes, hora/fecha, conversación básica,
consulta online prudente, voz TTS y reconocimiento de voz cuando la WebView lo soporte.
La aplicación NO inventa que hizo una búsqueda: si no encuentra una fuente suficiente, lo informa.
Nota: esta versión no incorpora un modelo generativo grande; el razonamiento local está implementado en JavaScript.
