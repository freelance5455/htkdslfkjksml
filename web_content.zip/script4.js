
/* PARTY/VENDOR SAVE RELIABILITY PATCH */
(function(){
  function byId(id){return document.getElementById(id);}
  function safeSave(){
    try{
      if(typeof window.save==='function') return window.save();
      localStorage.setItem('shaikhERP_v1',JSON.stringify(window.db||db));
      if(typeof window.renderAll==='function')window.renderAll();
      return true;
    }catch(e){alert('SAVE FAILED: '+(e.message||e)+' . PLEASE EXPORT BACKUP AND CHECK PHONE STORAGE.');return false;}
  }
  function refreshPartyControls(newId){
    const parties=(window.db||db).parties||[];
    const opt=(label,arr)=>'<option value="">'+label+'</option>'+arr.map(p=>'<option value="'+String(p.id).replace(/"/g,'&quot;')+'">'+String(p.name||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')+' ('+String(p.type||'Party')+')</option>').join('');
    ['bParty','qParty','kParty','payParty'].forEach(id=>{
      const el=byId(id);if(!el)return;const prev=(newId!==undefined&&['bParty','qParty'].includes(id))?String(newId):el.value;
      el.innerHTML=opt('SELECT PARTY',parties);if(prev)el.value=prev;
    });
    const vendor=byId('puParty');
    if(vendor){const prev=(newId!==undefined)?String(newId):vendor.value;vendor.innerHTML=opt('SELECT VENDOR',parties.filter(p=>p.type!=='Customer'));if(prev)vendor.value=prev;}
  }
  window.addParty=function(){
    const name=(byId('pName')?.value||'').trim();
    const type=byId('pType')?.value||'Customer';
    const mobile=(byId('pMobile')?.value||'').trim();
    const gst=(byId('pGst')?.value||'').trim().toUpperCase();
    const address=(byId('pAddress')?.value||'').trim();
    if(!name){alert('PLEASE ENTER PARTY / VENDOR NAME.');byId('pName')?.focus();return false;}
    const data=window.db||db;
    if(!Array.isArray(data.parties))data.parties=[];
    const duplicate=data.parties.find(p=>String(p.name||'').trim().toLowerCase()===name.toLowerCase() && String(p.mobile||'').replace(/\D/g,'')===mobile.replace(/\D/g,''));
    if(duplicate && !confirm('A PARTY WITH THIS NAME AND MOBILE ALREADY EXISTS. SAVE ANOTHER ENTRY?'))return false;
    const id=Date.now();
    data.parties.push({id,name,type,mobile,gst,address,companyId:data.activeCompanyId||'company-default',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
    if(!safeSave()){data.parties=data.parties.filter(p=>p.id!==id);return false;}
    refreshPartyControls(id);
    ['pName','pMobile','pGst','pAddress'].forEach(x=>{if(byId(x))byId(x).value='';});
    if(byId('pType'))byId('pType').value='Customer';
    if(byId('partyList'))byId('partyList').innerHTML=(data.parties||[]).slice().reverse().map(p=>'<div class="item"><b>'+String(p.name||'').replace(/</g,'&lt;')+'</b><div class="muted">'+String(p.type||'')+' • '+String(p.mobile||'')+' • '+String(p.gst||'NO GSTIN')+'</div><div>'+String(p.address||'').replace(/</g,'&lt;')+'</div></div>').join('');
    alert('PARTY SAVED SUCCESSFULLY.');
    return true;
  };
  window.refreshPartyControls=refreshPartyControls;
  /* Keep party/vendor selects synchronized after every screen render and company switch. */
  const priorRenderAll=window.renderAll;
  if(typeof priorRenderAll==='function'){window.renderAll=function(){const result=priorRenderAll.apply(this,arguments);try{refreshPartyControls();}catch(e){console.warn('Party dropdown refresh skipped',e);}return result;};}
  document.addEventListener('click',function(e){
    const btn=e.target.closest('button');if(!btn)return;
    const label=(btn.innerText||btn.textContent||'').trim().toLowerCase();
    if(label.includes('new party') && byId('parties')){
      e.preventDefault();e.stopPropagation();
      try{if(typeof window.go==='function')window.go('parties');else if(typeof window.show==='function')window.show('parties');}catch(err){byId('parties').classList.add('active');}
      setTimeout(()=>byId('pName')?.focus(),120);
    }
  },true);
  document.addEventListener('DOMContentLoaded',()=>{try{refreshPartyControls();}catch(e){}});
  try{refreshPartyControls();}catch(e){}
})();
