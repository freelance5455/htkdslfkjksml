// Скачивает шрифты (кириллица+латиница) в www/fonts и пишет www/css/fonts.css — для полностью офлайн-работы.
const fs = require('fs'), path = require('path'), https = require('https');
const fonts = [
  ['nunito', 'Nunito', [400, 600, 700, 800], 'normal'],
  ['cormorant-garamond', 'Cormorant Garamond', [500, 600, 700], 'normal'],
  ['cormorant-garamond', 'Cormorant Garamond', [500, 600], 'italic'],
  ['pixelify-sans', 'Pixelify Sans', [500, 600], 'normal']
];
const root = path.join(__dirname, '..', 'www'); fs.mkdirSync(path.join(root, 'fonts'), { recursive: true });
const get = (u, f) => new Promise((ok, no) => https.get(u, r => { if (r.statusCode !== 200) return no(new Error(r.statusCode + ' ' + u)); const w = fs.createWriteStream(f); r.pipe(w); w.on('finish', () => ok()); }).on('error', no));
(async () => {
  let css = '';
  for (const [id, fam, ws, st] of fonts) for (const w of ws) for (const sub of ['cyrillic', 'latin']) {
    const file = `${id}-${sub}-${w}-${st}.woff2`;
    try { await get(`https://cdn.jsdelivr.net/npm/@fontsource/${id}/files/${id}-${sub}-${w}-${st}.woff2`, path.join(root, 'fonts', file)); }
    catch (e) { console.log('пропуск', file, e.message); continue; }
    const rng = sub === 'cyrillic' ? 'U+0301,U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116' : 'U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD';
    css += `@font-face{font-family:'${fam}';font-style:${st};font-weight:${w};font-display:swap;src:url(../fonts/${file}) format('woff2');unicode-range:${rng}}\n`;
  }
  fs.writeFileSync(path.join(root, 'css', 'fonts.css'), css); console.log('Готово: шрифты сохранены, fonts.css обновлён.');
})();
