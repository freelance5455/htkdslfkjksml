const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
function create() {
  const win = new BrowserWindow({
    width: 1100, height: 800, minWidth: 380, minHeight: 560, backgroundColor: '#f4efe5',
    title: 'Карта Захвата', icon: path.join(__dirname, '../www/icons/icon-512.png'),
    webPreferences: { contextIsolation: true, sandbox: true }
  });
  Menu.setApplicationMenu(null);
  win.loadFile(path.join(__dirname, '../www/index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}
const lock = app.requestSingleInstanceLock();
if (!lock) app.quit(); else app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
