/* Карта Захвата — движок приложения. Без зависимостей, работает офлайн. */
(function () {
'use strict';
const T = window.THEMES, RAR = window.RARITY, SURR = window.SURROUND;
const CS = 16;                       // размер клетки в мировых единицах
const KEY = 'kz.v1', KEY_BAK = 'kz.v1.bak';
const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ───────── утилиты ───────── */
const $ = (s, r = document) => r.querySelector(s);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pick = (a, r = Math.random) => a[Math.floor(r() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pad2 = n => String(n).padStart(2, '0');
const dstr = d => d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate());
const todayStr = () => dstr(new Date());
const hex2rgb = h => { h = h.replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const mix = (a, b, t) => a.map((v, i) => v + (b[i] - v) * t);
const rgb = (c, a) => a == null ? `rgb(${c[0] | 0},${c[1] | 0},${c[2] | 0})` : `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${a})`;
const lum = c => (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255;
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function hash2(x, y, s) { let h = Math.imul(x * 374761393 + y * 668265263 + s * 1442695041 | 0, 1274126177); h ^= h >>> 13; h = Math.imul(h, 1274126177); return ((h ^ h >>> 16) >>> 0) / 4294967296; }
function vnoise(x, y, s) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
const N4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const N8 = N4.concat([[1, 1], [-1, 1], [1, -1], [-1, -1]]);

/* ───────── хранилище ───────── */
let S;
function load() {
  for (const k of [KEY, KEY_BAK]) {
    try { const raw = localStorage.getItem(k); if (raw) { const p = JSON.parse(raw); if (p && Array.isArray(p.maps)) { S = p; break; } } } catch (e) { }
  }
  if (!S) S = { v: 1, maps: [], active: null, ui: {} };
  S.ui = S.ui || {};
  if (S.ui.oneDay === undefined) S.ui.oneDay = true;
}
function save() {
  try {
    const prev = localStorage.getItem(KEY);
    if (prev) localStorage.setItem(KEY_BAK, prev);
    localStorage.setItem(KEY, JSON.stringify(S));
  } catch (e) { toast('Не удалось сохранить прогресс в браузере. Сделайте резервную копию в настройках.'); }
}
const active = () => S.maps.find(m => m.id === S.active) || null;

/* ───────── генерация карты (локально, без сети) ───────── */
function generate(N, themeId, seed) {
  const th = T[themeId], rnd = mulberry32(seed);
  const G = Math.ceil(Math.sqrt(N) * 2.1) + 10, W = G, H = G, M = 3;
  const ns = seed & 0xffff, fr = 0.2 + rnd() * 0.1;
  const land = new Uint8Array(W * H), cx = W >> 1, cy = H >> 1, maxR = G / 2 - M;
  const front = new Set();
  const addFront = (x, y) => { for (const [dx, dy] of N4) { const nx = x + dx, ny = y + dy; if (nx >= M && ny >= M && nx < W - M && ny < H - M && !land[ny * W + nx]) front.add(ny * W + nx); } };
  const place = (x, y) => { land[y * W + x] = 1; front.delete(y * W + x); addFront(x, y); };
  place(cx, cy); let cnt = 1;
  while (cnt < N && front.size) {
    const arr = [...front], ws = new Array(arr.length); let total = 0;
    for (let k = 0; k < arr.length; k++) {
      const i = arr[k], x = i % W, y = (i / W) | 0; let n = 0;
      for (const [dx, dy] of N4) n += land[(y + dy) * W + x + dx];
      const nz = vnoise(x * fr, y * fr, ns), d = Math.hypot(x - cx, y - cy) / maxR;
      const w = Math.pow(0.12 + nz, 1.7) * (0.35 + n * n * 0.9) * Math.max(0.04, 1 - d * d * 0.9);
      ws[k] = w; total += w;
    }
    let r = rnd() * total, k = 0; while (k < arr.length - 1 && (r -= ws[k]) > 0) k++;
    const i = arr[k]; place(i % W, (i / W) | 0); cnt++;
  }
  N = cnt;
  // внешний океан: заливка от границ
  const outer = new Uint8Array(W * H), q = [];
  for (let x = 0; x < W; x++) for (const y of [0, H - 1]) { const i = y * W + x; if (!land[i] && !outer[i]) { outer[i] = 1; q.push(i); } }
  for (let y = 0; y < H; y++) for (const x of [0, W - 1]) { const i = y * W + x; if (!land[i] && !outer[i]) { outer[i] = 1; q.push(i); } }
  while (q.length) {
    const i = q.pop(), x = i % W, y = (i / W) | 0;
    for (const [dx, dy] of N4) { const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const j = ny * W + nx; if (!land[j] && !outer[j]) { outer[j] = 1; q.push(j); } }
  }
  const types = new Uint8Array(W * H), landIdx = [];
  for (let i = 0; i < W * H; i++) {
    const x = i % W, y = (i / W) | 0;
    if (!land[i]) { types[i] = outer[i] ? 0 : 1; continue; }
    landIdx.push(i);
    let coast = false; for (const [dx, dy] of N4) if (!land[(y + dy) * W + x + dx]) coast = true;
    if (coast) { types[i] = 2; continue; }
    const n2 = vnoise(x * 0.17 + 40, y * 0.17 + 40, ns + 7);
    types[i] = n2 < 0.4 ? 3 : n2 < 0.66 ? 4 : 5;
  }
  const grid = Array.from(types, v => String.fromCharCode(48 + v)).join('');
  const shuffled = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const cheb = (a, b) => Math.max(Math.abs(a % W - b % W), Math.abs(((a / W) | 0) - ((b / W) | 0)));
  // рискованные клетки
  const risky = [], rc = N >= 12 ? Math.max(1, Math.round(N * 0.07)) : 0;
  for (const i of shuffled(landIdx)) { if (risky.length >= rc) break; if (risky.every(r => cheb(r, i) >= 2)) risky.push(i); }
  // места
  const want = {
    common: Math.max(2, Math.round(N * 0.05)),
    rare: N >= 20 ? Math.max(1, Math.round(N * 0.028)) : 0,
    epic: N >= 45 ? Math.max(1, Math.round(N * 0.011)) : 0,
    mythic: N >= 70 ? 1 + Math.floor(N / 450) : (N >= 35 && rnd() < 0.5 ? 1 : 0)
  };
  const used = new Set(risky), pois = [], names = shuffled(th.names); let ni = 0;
  for (const rar of ['mythic', 'epic', 'rare', 'common']) {
    const kinds = shuffled(th.pois.map((p, k) => [p, k]).filter(([p]) => p.r === rar).map(([, k]) => k));
    for (let c = 0; c < want[rar]; c++) {
      const k = kinds[c % kinds.length]; let spot = -1;
      for (const minD of [3, 2, 0]) {
        for (let t = 0; t < 60 && spot < 0; t++) {
          const i = landIdx[Math.floor(rnd() * landIdx.length)];
          if (used.has(i)) continue;
          if ((rar === 'mythic' || rar === 'epic') && types[i] === 2 && t < 40) continue;
          if (pois.every(p => cheb(p.i, i) >= minD)) spot = i;
        }
        if (spot >= 0) break;
      }
      if (spot < 0) continue;
      used.add(spot); pois.push({ i: spot, k, n: names[ni++ % names.length] });
    }
  }
  return { W, H, grid, risky, pois, size: N };
}

/* ───────── рантайм-данные карты ───────── */
function buildRT(m) {
  const th = T[m.theme], P = th.pal, W = m.W, H = m.H, n = W * H;
  const grid = new Uint8Array(n); for (let i = 0; i < n; i++) grid[i] = m.grid.charCodeAt(i) - 48;
  const dist = new Uint8Array(n).fill(255), q = [], landIdx = [];
  for (let i = 0; i < n; i++) if (grid[i] >= 2) { dist[i] = 0; q.push(i); landIdx.push(i); }
  for (let h = 0; h < q.length; h++) {
    const i = q[h], x = i % W, y = (i / W) | 0;
    if (dist[i] >= 12) continue;
    for (const [dx, dy] of N8) { const nx = x + dx, ny = y + dy; if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue; const j = ny * W + nx; if (dist[j] === 255) { dist[j] = dist[i] + 1; q.push(j); } }
  }
  const base = { 2: hex2rgb(P.shore), 3: hex2rgb(P.plain), 4: hex2rgb(P.alt), 5: hex2rgb(P.high) }, U = hex2rgb(P.unclaimed);
  const cA = new Array(n), cU = new Array(n), sd = m.seed & 1023;
  for (const i of landIdx) {
    const x = i % W, y = (i / W) | 0, j = (hash2(x, y, sd) - 0.5) * 0.14;
    const c = mix(base[grid[i]], j > 0 ? [255, 255, 255] : [0, 0, 0], Math.abs(j));
    cA[i] = rgb(c); cU[i] = rgb(mix(mix(c, U, 0.74), [0, 0, 0], 0.04));
  }
  const s1 = hex2rgb(P.sea1), s2 = hex2rgb(P.sea2), wc = [];
  for (let d = 0; d <= 9; d++) wc.push(rgb(mix(s1, s2, clamp((d - 1) / 7, 0, 1))));
  const rt = { m, th, P, W, H, grid, dist, landIdx, cA, cU, wc, edge: hex2rgb(P.edge), speck: hex2rgb(P.speck),
    claimed: new Set(m.log.map(l => l[0])), tried: new Set(m.tries || []), risky: new Set(m.risky),
    poi: new Map(m.pois.map(p => [p.i, p])), anims: [], parts: [], sel: -1, hover: -1, frontier: new Set(), free: true };
  refreshFrontier(rt);
  return rt;
}
function refreshFrontier(rt) {
  const f = new Set(), { W, grid } = rt;
  if (rt.claimed.size === 0) { rt.free = true; rt.landIdx.forEach(i => f.add(i)); }
  else {
    rt.free = false;
    for (const i of rt.claimed) { const x = i % W, y = (i / W) | 0; for (const [dx, dy] of N8) { const j = (y + dy) * W + x + dx; if (grid[j] >= 2 && !rt.claimed.has(j)) f.add(j); } }
  }
  rt.frontier = f;
}

/* ───────── спрайты (эмодзи → пиксель-арт) ───────── */
const spriteCache = new Map();
function sprite(e, px) {
  const key = e + '|' + px; let c = spriteCache.get(key); if (c) return c;
  c = document.createElement('canvas'); c.width = c.height = px;
  const g = c.getContext('2d');
  g.font = `${Math.round(px * 0.8)}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif`;
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(e, px / 2, px / 2 + px * 0.06);
  spriteCache.set(key, c); return c;
}

/* ───────── отрисовка карты ───────── */
function fitFor(rt, w, h) {
  let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
  for (const i of rt.landIdx) { const x = i % rt.W, y = (i / rt.W) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  const padc = 3.2, bw = (x1 - x0 + 1 + padc * 2) * CS, bh = (y1 - y0 + 1 + padc * 2) * CS;
  const s = Math.min(w / bw, h / bh), cx = (x0 + x1 + 1) / 2 * CS, cy = (y0 + y1 + 1) / 2 * CS;
  return { s, x: w / 2 - cx * s, y: h / 2 - cy * s };
}

function drawScene(ctx, rt, v, w, h, t, o) {
  o = o || {};
  const { P, W, H, grid, dist, th } = rt, cs = CS * v.s, kind = SURR[th.surround].speck;
  const live = !!o.live && !reduce, reveal = !!o.reveal, sdh = rt.m.seed & 1023;
  ctx.imageSmoothingEnabled = false; ctx.globalAlpha = 1;
  ctx.fillStyle = rt.wc[9]; ctx.fillRect(0, 0, w, h);
  const x0 = Math.max(0, Math.floor(-v.x / cs)), y0 = Math.max(0, Math.floor(-v.y / cs));
  const x1 = Math.min(W, Math.ceil((w - v.x) / cs)), y1 = Math.min(H, Math.ceil((h - v.y) / cs));
  const px = x => Math.round(v.x + x * cs), py = y => Math.round(v.y + y * cs);
  const sp = rt.speck;

  // вода / туман
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = y * W + x, g = grid[i]; if (g >= 2) continue;
    const X = px(x), Y = py(y), Wd = px(x + 1) - X, Hd = py(y + 1) - Y;
    ctx.fillStyle = g === 1 ? P.lake : rt.wc[Math.min(dist[i], 9)]; ctx.fillRect(X, Y, Wd, Hd);
    if (cs >= 5 && !o.noSpecks) {
      const hh = hash2(x, y, sdh);
      if (hh < 0.38) {
        const a = live ? 0.5 + 0.5 * Math.sin(t * 0.0016 + hh * 40) : 0.6;
        ctx.fillStyle = rgb(sp);
        const ox = Wd * (0.1 + (hh * 13 % 1) * 0.5), oy = Hd * (0.2 + (hh * 29 % 1) * 0.6);
        if (kind === 'wave') { ctx.globalAlpha = 0.12 + 0.38 * a; ctx.fillRect(X + ox, Y + oy, Math.max(2, Wd * 0.34), Math.max(1, Math.round(cs * 0.07))); }
        else if (kind === 'star') { ctx.globalAlpha = 0.15 + 0.8 * a * (hh * 2.6 % 1); const z = Math.max(1, Math.round(cs * (0.05 + (hh * 7 % 1) * 0.07))); ctx.fillRect(X + ox, Y + oy, z, z); }
        else { ctx.globalAlpha = 0.04 + 0.1 * a; const z = Math.round(cs * 0.42); ctx.fillRect(X + ox * 0.6, Y + oy * 0.4, z, Math.round(z * 0.55)); }
      }
    }
  }
  ctx.globalAlpha = 1;
  if (kind === 'cloud' && !o.thumb) {
    for (let k = 0; k < 6; k++) {
      const bx = (((t || 0) * 0.000012 * (1 + k * 0.2) + k * 0.37) % 1.3 - 0.15) * w, by = (0.12 + 0.76 * ((k * 0.618) % 1)) * h + Math.sin((t || 0) * 0.0003 + k) * 18;
      const rad = Math.max(w, h) * 0.3, gr = ctx.createRadialGradient(bx, by, 0, bx, by, rad);
      gr.addColorStop(0, rgb(sp, 0.17)); gr.addColorStop(1, rgb(sp, 0));
      ctx.fillStyle = gr; ctx.fillRect(bx - rad, by - rad, rad * 2, rad * 2);
    }
  }

  // суша
  const lw = Math.max(1, Math.round(cs * 0.09));
  for (let y = y0; y < y1; y++) for (let x = x0; x < x1; x++) {
    const i = y * W + x; if (grid[i] < 2) continue;
    const cl = reveal || rt.claimed.has(i);
    const X = px(x), Y = py(y), Wd = px(x + 1) - X, Hd = py(y + 1) - Y;
    ctx.fillStyle = cl ? rt.cA[i] : rt.cU[i]; ctx.fillRect(X, Y, Wd, Hd);
    if (cs >= 8) {
      const hh = hash2(x, y, 77);
      ctx.fillStyle = cl ? 'rgba(255,255,255,.17)' : 'rgba(255,255,255,.05)';
      ctx.fillRect(X + Wd * (0.12 + hh * 0.5), Y + Hd * (0.15 + (hh * 9 % 1) * 0.55), Math.max(1, Wd * 0.2), Math.max(1, Hd * 0.1));
      ctx.fillStyle = 'rgba(0,0,0,.09)';
      ctx.fillRect(X + Wd * (0.2 + (hh * 5 % 1) * 0.5), Y + Hd * (0.55 + (hh * 3 % 1) * 0.3), Math.max(1, Wd * 0.18), Math.max(1, Hd * 0.1));
    }
    if (cs >= 6) { ctx.fillStyle = cl ? 'rgba(0,0,0,.06)' : 'rgba(0,0,0,.13)'; ctx.fillRect(X + Wd - 1, Y, 1, Hd); ctx.fillRect(X, Y + Hd - 1, Wd, 1); }
    // береговая линия и граница владений
    const nb = [[i - 1, 0], [i + 1, 1], [i - W, 2], [i + W, 3]];
    for (const [j, s] of nb) {
      if (grid[j] < 2) { ctx.fillStyle = rgb(rt.edge, 0.7); }
      else if (cl && !reveal && !rt.claimed.has(j)) { ctx.fillStyle = 'rgba(255,255,255,.5)'; }
      else continue;
      if (s === 0) ctx.fillRect(X, Y, lw, Hd); else if (s === 1) ctx.fillRect(X + Wd - lw, Y, lw, Hd);
      else if (s === 2) ctx.fillRect(X, Y, Wd, lw); else ctx.fillRect(X, Y + Hd - lw, Wd, lw);
    }
    // мелкий декор
    if (cl && cs >= 10 && !(rt.poi.has(i) && !reveal)) {
      const h1 = hash2(x, y, 55);
      if (h1 < 0.3) {
        const e = th.decor[Math.floor(hash2(x, y, 56) * th.decor.length)], sz = Math.round(cs * 0.5);
        ctx.drawImage(sprite(e, 10), X + (hash2(x, y, 57) * 0.5) * Wd, Y + (hash2(x, y, 58) * 0.45) * Hd, sz, sz);
      }
    }
  }

  if (reveal || o.thumb) return;

  // места
  const pulse = live ? Math.sin(t * 0.004) : 0;
  for (const [i, p] of rt.poi) {
    const x = i % W, y = (i / W) | 0; if (x < x0 - 1 || x > x1 || y < y0 - 1 || y > y1) continue;
    const X = px(x), Y = py(y), cx = X + cs / 2, cy = Y + cs / 2, k = th.pois[p.k], R = RAR[k.r];
    if (rt.claimed.has(i)) {
      if (k.r !== 'common') { ctx.fillStyle = rgb(hex2rgb(R.color), 0.24 + (k.r === 'mythic' ? 0.14 * pulse : 0.05 * pulse)); ctx.beginPath(); ctx.arc(cx, cy, cs * (k.r === 'mythic' ? 0.62 : 0.52), 0, 7); ctx.fill(); }
      const sz = Math.round(cs * 0.86); ctx.drawImage(sprite(k.e, 14), Math.round(cx - sz / 2), Math.round(cy - sz / 2), sz, sz);
      if (k.r === 'mythic' && live && cs >= 12) { ctx.fillStyle = '#fff'; const a = (t * 0.002) % (Math.PI * 2); for (let s = 0; s < 3; s++) { const aa = a + s * 2.1; ctx.globalAlpha = 0.5 + 0.5 * Math.sin(t * 0.005 + s); ctx.fillRect(Math.round(cx + Math.cos(aa) * cs * 0.55), Math.round(cy + Math.sin(aa) * cs * 0.55), Math.max(1, cs * 0.07), Math.max(1, cs * 0.07)); } ctx.globalAlpha = 1; }
    } else if (cs >= 9) {
      ctx.fillStyle = 'rgba(255,255,255,.4)'; ctx.font = `600 ${Math.round(cs * 0.5)}px "Pixelify Sans",monospace`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('?', cx, cy + cs * 0.04);
    }
  }
  // рисковые клетки
  for (const i of rt.risky) {
    if (rt.claimed.has(i) && !rt.tried.has(i)) continue; if (rt.claimed.has(i)) continue;
    const x = i % W, y = (i / W) | 0; if (x < x0 - 1 || x > x1 || y < y0 - 1 || y > y1) continue;
    const cx = px(x) + cs / 2, cy = py(y) + cs / 2, r = cs * 0.3, tried = rt.tried.has(i);
    if (cs < 6) continue;
    if (live && !tried) { ctx.strokeStyle = `rgba(255,170,60,${0.25 + 0.25 * pulse})`; ctx.lineWidth = Math.max(1, cs * 0.06); ctx.strokeRect(px(x) + 1, py(y) + 1, cs - 2, cs - 2); }
    ctx.fillStyle = tried ? 'rgba(110,205,145,.96)' : 'rgba(255,165,55,.97)';
    ctx.beginPath(); ctx.moveTo(cx, cy - r); ctx.lineTo(cx + r * 1.08, cy + r * 0.82); ctx.lineTo(cx - r * 1.08, cy + r * 0.82); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#2a1800'; const u = Math.max(1, cs * 0.05);
    ctx.fillRect(cx - u, cy - r * 0.35, u * 2, r * 0.7); ctx.fillRect(cx - u, cy + r * 0.45, u * 2, u * 1.6);
  }
  // доступные клетки
  if (o.live && !rt.m.done) {
    const base = rt.free ? 0.06 : 0.12;
    for (const i of rt.frontier) {
      const x = i % W, y = (i / W) | 0; if (x < x0 || x >= x1 || y < y0 || y >= y1) continue;
      const a = base + (live ? (0.5 + 0.5 * Math.sin(t * 0.003 + (x + y) * 0.5)) * 0.14 : 0.08);
      ctx.fillStyle = `rgba(255,255,255,${a * 0.55})`; ctx.fillRect(px(x), py(y), cs, cs);
      ctx.strokeStyle = `rgba(255,255,255,${a * 2.2})`; ctx.lineWidth = Math.max(1, cs * 0.05); ctx.strokeRect(px(x) + 1, py(y) + 1, cs - 2, cs - 2);
    }
  }
  if (rt.hover >= 0 && rt.grid[rt.hover] >= 2 && !rt.claimed.has(rt.hover)) {
    const x = rt.hover % W, y = (rt.hover / W) | 0;
    ctx.strokeStyle = 'rgba(255,255,255,.95)'; ctx.lineWidth = Math.max(2, cs * 0.09); ctx.strokeRect(px(x) + 1, py(y) + 1, cs - 2, cs - 2);
  }
  if (rt.sel >= 0) {
    const x = rt.sel % W, y = (rt.sel / W) | 0;
    ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = Math.max(2, cs * 0.1); ctx.strokeRect(px(x) + 1, py(y) + 1, cs - 2, cs - 2);
  }
  // анимация захвата и частицы
  rt.anims = rt.anims.filter(a => (t - a.t0) < 1000);
  for (const a of rt.anims) {
    const p = (t - a.t0) / 1000, x = a.i % W, y = (a.i / W) | 0, cx = px(x) + cs / 2, cy = py(y) + cs / 2;
    ctx.fillStyle = `rgba(255,255,255,${0.55 * (1 - p)})`; ctx.fillRect(px(x), py(y), cs, cs);
    ctx.strokeStyle = `rgba(255,255,255,${0.9 * (1 - p)})`; ctx.lineWidth = Math.max(2, cs * 0.12 * (1 - p)); ctx.beginPath(); ctx.arc(cx, cy, cs * (0.4 + p * 1.8), 0, 7); ctx.stroke();
  }
  rt.parts = rt.parts.filter(q => q.life > 0);
  for (const q of rt.parts) {
    q.x += q.vx; q.y += q.vy; q.vy += 0.03; q.life -= 1;
    ctx.globalAlpha = clamp(q.life / 30, 0, 1); ctx.fillStyle = q.c;
    const z = Math.max(2, cs * 0.11); ctx.fillRect(Math.round(v.x + q.x * v.s), Math.round(v.y + q.y * v.s), z, z);
  }
  ctx.globalAlpha = 1;
}

/* ───────── основной холст ───────── */
const cv = $('#map'), ctx = cv.getContext('2d');
let rt = null, view = { s: 1, x: 0, y: 0 }, fitS = 1, cw = 0, ch = 0, dpr = 1;

function resize() {
  const r = cv.getBoundingClientRect(); if (!r.width) return;
  dpr = Math.min(window.devicePixelRatio || 1, 2.5); cw = r.width; ch = r.height;
  const W = Math.round(cw * dpr), H = Math.round(ch * dpr);
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; if (rt) refit(); }
}
function refit() { if (!rt) return; const f = fitFor(rt, cw, ch); view = { s: f.s, x: f.x, y: f.y }; fitS = f.s; }
function clampView() {
  if (!rt) return; const ws = rt.W * CS * view.s, hs = rt.H * CS * view.s;
  view.x = clamp(view.x, cw * 0.2 - ws, cw * 0.8); view.y = clamp(view.y, ch * 0.2 - hs, ch * 0.8);
}
function zoomAt(mx, my, f) {
  const ns = clamp(view.s * f, fitS * 0.55, Math.max(fitS * 2, 7.5)); f = ns / view.s;
  view.x = mx - (mx - view.x) * f; view.y = my - (my - view.y) * f; view.s = ns; clampView();
}
function focusCell(i, minCell) {
  if (!rt) return; const x = (i % rt.W + 0.5) * CS, y = ((i / rt.W | 0) + 0.5) * CS;
  view.s = Math.max(view.s, (minCell || 34) / CS); view.s = Math.min(view.s, 7.5);
  view.x = cw / 2 - x * view.s; view.y = ch / 2 - y * view.s; clampView();
}

/* ввод */
const ptrs = new Map(); let drag = null, pinch = null;
cv.addEventListener('pointerdown', e => {
  cv.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 1) drag = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y, moved: false };
  else if (ptrs.size === 2) { drag = null; const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 }; }
});
cv.addEventListener('pointermove', e => {
  const r = cv.getBoundingClientRect();
  if (!ptrs.has(e.pointerId)) { if (rt && e.pointerType === 'mouse') rt.hover = cellAt(e.clientX - r.left, e.clientY - r.top); return; }
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 2 && pinch) {
    const [a, b] = [...ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
    zoomAt(cx - r.left, cy - r.top, d / pinch.d); view.x += cx - pinch.cx; view.y += cy - pinch.cy; clampView(); pinch = { d, cx, cy };
  } else if (drag) {
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (!drag.moved && Math.hypot(dx, dy) > 7) { drag.moved = true; cv.classList.add('dragging'); }
    if (drag.moved) { view.x = drag.vx + dx; view.y = drag.vy + dy; clampView(); }
  }
});
const endPtr = e => {
  const r = cv.getBoundingClientRect();
  if (e.type === 'pointerup' && drag && !drag.moved && ptrs.size === 1) onTap(e.clientX - r.left, e.clientY - r.top);
  ptrs.delete(e.pointerId); drag = null; pinch = null; cv.classList.remove('dragging');
};
cv.addEventListener('pointerup', endPtr); cv.addEventListener('pointercancel', endPtr);
cv.addEventListener('pointerleave', e => { if (rt && e.pointerType === 'mouse') rt.hover = -1; });
cv.addEventListener('wheel', e => { e.preventDefault(); const r = cv.getBoundingClientRect(); zoomAt(e.clientX - r.left, e.clientY - r.top, Math.exp(-e.deltaY * 0.0016)); }, { passive: false });

function cellAt(sx, sy) {
  if (!rt) return -1; const cs = CS * view.s, gx = Math.floor((sx - view.x) / cs), gy = Math.floor((sy - view.y) / cs);
  if (gx < 0 || gy < 0 || gx >= rt.W || gy >= rt.H) return -1; return gy * rt.W + gx;
}

/* ───────── игровая логика ───────── */
const NO_MSGS = ['Ничего страшного. Отдых — тоже часть пути. Клетка никуда не денется.', 'Хорошо, что вы честны с собой. Вернитесь, когда день будет прожит.', 'Карта подождёт. Она терпеливая.', 'Не сегодня — значит, завтра. Всё по-доброму.'];

function onTap(sx, sy) {
  if (!rt) return; const i = cellAt(sx, sy); if (i < 0 || rt.grid[i] < 2) return;
  const m = rt.m;
  if (rt.claimed.has(i)) { const p = rt.poi.get(i); if (p) showPoi(p, false); else toast(pick(['Эта земля уже ваша.', 'Здесь вы уже побывали.', 'Тихо и спокойно — вы тут уже хозяин.'])); return; }
  if (m.done) { toast('Эта карта уже покорена целиком 🏆'); return; }
  if (rt.claimed.size > 0 && !rt.frontier.has(i)) { toast('Расширять владения можно только рядом с уже закрашенными клетками. Подсвеченные клетки — доступны.'); return; }
  if (S.ui.oneDay && m.lastDay === todayStr()) { toast('Сегодняшняя клетка уже занята ✨ Возвращайтесь завтра — карта вас дождётся.'); return; }
  askDone(i);
}

function askDone(i) {
  const th = rt.th, risky = rt.risky.has(i) && !rt.tried.has(i); rt.sel = i;
  const sh = sheet({ cls: 'small', x: false, onClose: () => { rt.sel = -1; },
    html: `<div class="confirm-ico">${risky ? th.riskIcon : '🗓️'}</div>
      ${risky ? `<div class="warn-tag">⚠ ${esc(th.riskName)} — удача может не улыбнуться</div>` : ''}
      <div class="confirm-q">Выполнили ли вы свои задания на сегодня?</div>
      <p class="sub">${risky ? 'Это рискованная клетка: с первого раза она покорится не наверняка.' : 'Закрасим клетку, если день прожит честно.'}</p>
      <div class="row center"><button class="btn ghost" data-a="no">Нет</button><button class="btn primary" data-a="yes">Да</button></div>` });
  sh.s.querySelector('[data-a=no]').onclick = () => { sh.close(); toast(pick(NO_MSGS)); };
  sh.s.querySelector('[data-a=yes]').onclick = () => { sh.close(); resolveClaim(i); };
}

let lastRisk = '';
function resolveClaim(i) {
  const m = rt.m, th = rt.th, today = todayStr();
  if (rt.risky.has(i) && !rt.tried.has(i)) {
    rt.tried.add(i); m.tries = (m.tries || []).concat(i); m.lastDay = today;
    if (Math.random() < 0.4) { claim(i, true); }
    else {
      let t; do { t = pick(th.risks); } while (t === lastRisk && th.risks.length > 1); lastRisk = t; save(); updateHUD();
      sheet({ cls: 'small', html: `<div class="confirm-ico">${th.riskIcon}</div><div class="confirm-q">Не в этот раз…</div>
        <p style="line-height:1.65;margin:8px 4px">${esc(t)}</p>
        <p class="sub" style="margin-top:12px">В следующий раз эта клетка покорится наверняка — шанс 100%.</p>
        <div class="row center"><button class="btn primary" data-close>Понятно</button></div>` });
    }
    return;
  }
  claim(i, false);
}

function claim(i, lucky) {
  const m = rt.m, th = rt.th, today = todayStr();
  m.log.push([i, today]); m.lastDay = today; rt.claimed.add(i); refreshFrontier(rt);
  const now = performance.now(); rt.anims.push({ i, t0: now });
  const wx = (i % rt.W + 0.5) * CS, wy = ((i / rt.W | 0) + 0.5) * CS, cols = [th.pal.shore, th.pal.plain, th.pal.high, '#ffffff', th.accent];
  if (!reduce) for (let k = 0; k < 26; k++) { const a = Math.random() * 6.283, s = 0.25 + Math.random() * 0.7; rt.parts.push({ x: wx, y: wy, vx: Math.cos(a) * s, vy: Math.sin(a) * s - 0.4, life: 40 + Math.random() * 30, c: pick(cols) }); }
  const p = rt.poi.get(i), done = rt.claimed.size >= m.size;
  if (done) m.done = Date.now();
  save(); updateHUD();
  toast(lucky ? 'Риск оправдался — клетка ваша! 🍀' : pick(['Клетка закрашена ✨', 'Ещё один шаг по карте 🌿', 'Территория расширена!', 'Красиво. Так держать 🌱']));
  if (p) setTimeout(() => showPoi(p, true, done ? () => setTimeout(() => showWin(), 300) : null), 850);
  else if (done) setTimeout(showWin, 1300);
}

/* ───────── HUD ───────── */
function streak(m) {
  const set = new Set(m.log.map(l => l[1])); const d = new Date(); d.setHours(12, 0, 0, 0);
  if (!set.has(dstr(d))) d.setDate(d.getDate() - 1);
  let n = 0; while (set.has(dstr(d))) { n++; d.setDate(d.getDate() - 1); } return n;
}
function applyAccent(th) {
  const root = document.documentElement; const c = th ? th.accent : (root.dataset.theme === 'dark' ? '#8fbba0' : '#7fa38b');
  root.style.setProperty('--accent', c); root.style.setProperty('--accent-ink', lum(hex2rgb(c)) > 0.66 ? '#1d1d1d' : '#ffffff');
}
let vTarget = 0, vShown = 0;
function updateHUD() {
  const m = active(), wel = $('#welcome');
  if (!m) { wel.hidden = false; $('#mapTitle').textContent = 'Карта Захвата'; $('#mapGoal').textContent = ''; $('#stats').innerHTML = ''; applyAccent(null); return; }
  wel.hidden = true; const th = T[m.theme], L = th.liquid, c = rt ? rt.claimed.size : m.log.length;
  $('#mapTitle').textContent = m.name; $('#mapGoal').textContent = '🎯 ' + m.goal; applyAccent(th);
  const p = c / m.size; vTarget = p;
  const pc = c >= m.size ? 100 : Math.floor(p * 100);
  $('#pct b').textContent = pc + '%'; $('#pct span').textContent = `${c} из ${m.size} клеток`;
  $('#capL').textContent = L.capL; $('#capR').textContent = L.capR;
  const st = streak(m), today = m.lastDay === todayStr();
  $('#stats').innerHTML = m.done ? `<span class="chip">🏆 <b>Карта покорена</b></span><span class="chip">🔥 серия: <b>${st}</b></span>` :
    `<span class="chip">${th.emoji} <b>${c}</b> / ${m.size}</span><span class="chip">🔥 серия: <b>${st}</b></span><span class="chip">${today ? '✅ сегодня занято' : '🌤️ сегодня свободно'}</span>`;
  const hint = $('#hint');
  if (c === 0) { hint.hidden = false; hint.textContent = 'Выберите любую клетку — с неё начнётся ваша история'; } else hint.hidden = true;
  const mt = document.querySelector('meta[name=theme-color]'); if (mt) mt.content = getComputedStyle(document.body).backgroundColor;
}

/* жидкий индикатор */
const vc = $('#liquid');
function rrect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
function drawVial(t) {
  const w = vc.clientWidth, h = vc.clientHeight; if (!w) return;
  const d = Math.min(window.devicePixelRatio || 1, 2);
  if (vc.width !== Math.round(w * d) || vc.height !== Math.round(h * d)) { vc.width = Math.round(w * d); vc.height = Math.round(h * d); }
  const g = vc.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0); g.clearRect(0, 0, w, h);
  const m = active(); if (!m) return; const L = T[m.theme].liquid;
  vShown += (vTarget - vShown) * 0.05; if (Math.abs(vTarget - vShown) < 0.0005) vShown = vTarget;
  const pad = 2, R = Math.min(L.r * h, h / 2 - 1);
  g.save(); rrect(g, pad, pad, w - pad * 2, h - pad * 2, R); g.clip();
  g.fillStyle = L.glass; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(0, 0, w, h);
  const fw = pad + (w - pad * 2) * vShown;
  if (vShown > 0.002) {
    const calm = vShown >= 0.999 ? 0.12 : 1, full = vShown >= 0.999;
    g.beginPath(); g.moveTo(0, 0);
    for (let y = 0; y <= h; y += 2) g.lineTo(full ? w + 2 : fw + (Math.sin(y * 0.19 + t * 0.0032) * L.amp + Math.sin(y * 0.07 - t * 0.0021) * L.amp * 0.5) * calm, y);
    g.lineTo(0, h); g.closePath();
    const lg = g.createLinearGradient(0, 0, Math.max(fw, 40), 0); lg.addColorStop(0, L.c2); lg.addColorStop(1, L.c1); g.fillStyle = lg; g.fill();
    g.fillStyle = 'rgba(255,255,255,.26)'; g.fillRect(0, h * 0.15, Math.max(0, fw - 4), h * 0.11);
    for (let k = 0; k < 9; k++) {
      const bx = pad + ((k * 0.137 + 0.08) % 1) * (fw - pad - 6), by = h - (((t || 0) * 0.00005 * (0.6 + (k % 3) * 0.3) + k * 0.19) % 1) * (h + 6) + 3;
      if (bx > fw - 6 && !full) continue;
      if (L.kind === 'spark') { g.fillStyle = L.bubble; g.globalAlpha = 0.4 + 0.6 * Math.abs(Math.sin((t || 0) * 0.004 + k)); const z = 1.5 + (k % 2); g.fillRect(bx, by, z, z); g.globalAlpha = 1; }
      else { g.strokeStyle = L.bubble; g.globalAlpha = 0.7; g.lineWidth = 1; g.beginPath(); g.arc(bx, by, 1.6 + (k % 3), 0, 7); g.stroke(); g.globalAlpha = 1; }
    }
  }
  if (L.ticks) { g.fillStyle = 'rgba(255,255,255,.4)'; for (let k = 1; k < L.ticks; k++) g.fillRect(pad + (w - pad * 2) * k / L.ticks, h - 8, 1.5, 6); }
  g.restore();
  rrect(g, pad, pad, w - pad * 2, h - pad * 2, R); g.lineWidth = 2.2; g.strokeStyle = L.border; g.stroke();
  g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(R * 0.8 + 4, pad + 4); g.lineTo(w * 0.45, pad + 4); g.stroke();
}
const tube = $('#tube'); let holdT = null;
tube.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') { clearTimeout(holdT); holdT = setTimeout(() => tube.classList.add('hold'), 160); } });
['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => tube.addEventListener(ev, e => { if (e.pointerType !== 'mouse') { clearTimeout(holdT); setTimeout(() => tube.classList.remove('hold'), 900); } }));
tube.addEventListener('click', () => { const m = active(); if (m && m.done) showWin(); });
tube.addEventListener('contextmenu', e => e.preventDefault());

/* ───────── главный цикл ───────── */
let last = 0;
function frame(t) {
  requestAnimationFrame(frame); if (document.hidden) return;
  if (t - last < (reduce ? 200 : 33)) return; last = t;
  resize();
  if (rt && cw) { ctx.setTransform(dpr, 0, 0, dpr, 0, 0); drawScene(ctx, rt, view, cw, ch, t, { live: true }); }
  else if (cw) { ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.fillStyle = '#0000'; ctx.clearRect(0, 0, cw, ch); }
  drawVial(t);
}

/* ───────── окна ───────── */
function sheet(o) {
  const ov = el('div', 'overlay' + (o.side ? ' side' : '')), s = el('div', 'sheet ' + (o.cls || ''), o.html || '');
  ov.appendChild(s); $('#layer').appendChild(ov); let closed = false;
  const close = () => { if (closed) return; closed = true; ov.classList.add('closing'); setTimeout(() => ov.remove(), 240); if (o.onClose) o.onClose(); };
  if (o.x !== false) { const x = el('button', 'x', '✕'); x.setAttribute('aria-label', 'Закрыть'); x.onclick = close; s.appendChild(x); }
  ov.addEventListener('pointerdown', e => { if (e.target === ov) close(); });
  s.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', close));
  ov._close = close; return { o: ov, s, close };
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') { const all = $('#layer').querySelectorAll('.overlay:not(.closing)'); const top = all[all.length - 1]; if (top && top._close) top._close(); } });

const toasts = el('div', 'toasts'); document.body.appendChild(toasts);
function toast(msg, ms = 4200) {
  const t = el('div', 'toast', esc(msg)); toasts.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 400); }, ms);
  while (toasts.children.length > 3) toasts.firstChild.remove();
}
const poiTitle = (k, p) => k.t.includes('«') ? `${k.t}, ${p.n}` : `${k.t} «${p.n}»`;
const poiLore = (k, p) => k.lore.split('{n}').join('«' + p.n + '»');
const fmtDate = (s, y) => { const [a, b, c] = s.split('-').map(Number); return new Date(a, b - 1, c).toLocaleDateString('ru-RU', y ? { day: 'numeric', month: 'long', year: 'numeric' } : { day: 'numeric', month: 'long' }); };

function showPoi(p, fresh, then) {
  const th = rt.th, k = th.pois[p.k], R = RAR[k.r];
  const sh = sheet({ cls: 'small', onClose: then, html: `<div class="poi-hero ${k.r}" style="--rc:${R.color}">
    ${fresh ? '<span class="new-badge">НОВОЕ МЕСТО ОТКРЫТО</span>' : ''}
    <div class="big">${k.e}</div><span class="rar">${R.name}</span>
    <h2>${esc(poiTitle(k, p))}</h2><p class="lore">${esc(poiLore(k, p))}</p></div>
    <div class="row center"><button class="btn primary" data-close>${fresh ? 'Продолжить путь' : 'Закрыть'}</button></div>` });
  if (fresh && k.r !== 'common') fireConfetti(th, k.r === 'mythic' ? 70 : 30, true);
  return sh;
}

function openCodex() {
  const m = active(); if (!m) return; const th = rt.th, order = ['mythic', 'epic', 'rare', 'common'];
  const dates = new Map(m.log.map(l => [l[0], l[1]]));
  const all = m.pois.map(p => ({ p, k: th.pois[p.k], got: rt.claimed.has(p.i) }));
  const cnt = r => all.filter(a => a.k.r === r), got = r => cnt(r).filter(a => a.got).length;
  let tab = 'all';
  const sh = sheet({ cls: 'wide', html: `<h2>Посещённые места</h2><p class="sub" id="cx-sub"></p><div class="tabs" id="cx-tabs"></div><div class="poi-list" id="cx-list"></div>` });
  const render = () => {
    $('#cx-sub', sh.s).textContent = `Открыто ${all.filter(a => a.got).length} из ${all.length}. Остальные ждут на карте — отмечены «?».`;
    $('#cx-tabs', sh.s).innerHTML = [['all', 'Все']].concat(order.map(r => [r, RAR[r].name])).map(([id, n]) => `<button data-t="${id}" class="${tab === id ? 'on' : ''}">${n}${id !== 'all' ? ` ${got(id)}/${cnt(id).length}` : ''}</button>`).join('');
    sh.s.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { tab = b.dataset.t; render(); });
    let list = all.filter(a => tab === 'all' || a.k.r === tab).sort((a, b) => (b.got - a.got) || (RAR[b.k.r].w - RAR[a.k.r].w));
    const box = $('#cx-list', sh.s); box.innerHTML = '';
    if (!list.length) { box.innerHTML = '<div class="empty">На этой карте таких мест нет.</div>'; return; }
    if (!all.some(a => a.got)) box.appendChild(el('div', 'empty', 'Пока ни одного места не найдено.<br>Закрашивайте клетки — карта будет раскрываться.'));
    for (const a of list) {
      const R = RAR[a.k.r], d = el('div', 'poi' + (a.got ? '' : ' lock')); d.style.setProperty('--rc', R.color);
      d.innerHTML = a.got ? `<div class="pe">${a.k.e}</div><div><span class="rar">${R.name}</span><b>${esc(poiTitle(a.k, a.p))}</b><p>${esc(poiLore(a.k, a.p))}</p><p style="font-size:.74rem;opacity:.8">Открыто ${fmtDate(dates.get(a.p.i))}</p></div>`
        : `<div class="pe">${a.k.e}</div><div><span class="rar">${R.name}</span><b>???</b><p>Место ещё не найдено — оно спрятано где-то на карте.</p></div>`;
      if (a.got) d.onclick = () => { sh.close(); focusCell(a.p.i, 40); setTimeout(() => showPoi(a.p, false), 350); };
      box.appendChild(d);
    }
  };
  render();
}

function openMaps() {
  const sh = sheet({ side: true, html: `<h2>Мои карты</h2><p class="sub">Переключайтесь между картами — у каждой своя цель.</p><div id="ml"></div><button class="btn primary" style="width:100%;margin-top:6px" id="mnew">＋ Новая карта</button>` });
  const list = $('#ml', sh.s);
  const dprr = Math.min(window.devicePixelRatio || 1, 2);
  for (const m of S.maps) {
    const th = T[m.theme], c = new Set(m.log.map(l => l[0])).size, pc = Math.round(c / m.size * 100);
    const d = el('div', 'mcard' + (m.id === S.active ? ' on' : ''));
    d.innerHTML = `<canvas></canvas><div class="mi"><b>${esc(m.name)}</b><small>${th.emoji} ${esc(th.name)} · ${c}/${m.size}${m.done ? ' · 🏆' : ''}</small><small>🎯 ${esc(m.goal)}</small><div class="mbar"><i style="width:${pc}%"></i></div></div><button class="mx" aria-label="Изменить">✎</button>`;
    const cvn = d.querySelector('canvas'), sz = Math.round(74 * dprr); cvn.width = cvn.height = sz;
    try { const r2 = buildRT(m), g = cvn.getContext('2d'); const f = fitFor(r2, sz, sz); drawScene(g, r2, f, sz, sz, 0, { thumb: true, noSpecks: true }); } catch (e) { }
    d.onclick = e => { if (e.target.closest('.mx')) return; setActive(m.id); sh.close(); };
    d.querySelector('.mx').onclick = () => { sh.close(); editMap(m); };
    list.appendChild(d);
  }
  $('#mnew', sh.s).onclick = () => { sh.close(); openWizard(); };
}

function editMap(m) {
  const sh = sheet({ cls: 'small', html: `<h2>Изменить карту</h2>
    <label class="f" style="text-align:left">Название</label><input type="text" id="en" maxlength="40" value="${esc(m.name)}">
    <label class="f" style="text-align:left">Цель</label><textarea id="eg" maxlength="140">${esc(m.goal)}</textarea>
    <div class="row" style="justify-content:space-between;margin-top:16px"><button class="btn danger" id="edel">Удалить</button><button class="btn primary" id="esave">Сохранить</button></div>` });
  $('#esave', sh.s).onclick = () => { m.name = $('#en', sh.s).value.trim() || m.name; m.goal = $('#eg', sh.s).value.trim() || m.goal; save(); updateHUD(); sh.close(); };
  $('#edel', sh.s).onclick = () => {
    sh.close();
    const c = sheet({ cls: 'small', html: `<div class="confirm-ico">🗑️</div><div class="confirm-q">Удалить «${esc(m.name)}»?</div><p class="sub">Весь прогресс этой карты исчезнет без возможности вернуть.</p><div class="row center"><button class="btn ghost" data-close>Оставить</button><button class="btn danger" id="yes">Удалить</button></div>` });
    $('#yes', c.s).onclick = () => { S.maps = S.maps.filter(x => x.id !== m.id); if (S.active === m.id) S.active = S.maps.length ? S.maps[0].id : null; save(); c.close(); setActive(S.active, true); };
  };
}

function setActive(id, noSave) {
  S.active = id; const m = active(); rt = m ? buildRT(m) : null;
  vShown = 0; resize(); refit(); updateHUD(); if (!noSave) save();
}

/* ───────── мастер создания ───────── */
function openWizard() {
  const first = !S.maps.length;
  const w = { step: 1, name: '', goal: '', size: 60, theme: 'darkfantasy', seed: (Math.random() * 1e9) | 0, gen: null };
  const sh = sheet({ cls: 'wide', html: '<div id="wz"></div>' }), root = $('#wz', sh.s);
  const keep = () => { const a = root.querySelector('#wn'), b = root.querySelector('#wg'); if (a) w.name = a.value; if (b) w.goal = b.value; };
  const steps = n => `<div class="steps">${[1, 2, 3].map(i => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</div>`;
  const render = () => {
    if (w.step === 1) {
      root.innerHTML = `${steps(1)}<h2>Новая карта</h2><p class="sub">Расскажите, куда вы идёте. Название и цель останутся с картой — а цель прозвучит в финальном поздравлении.</p>
      <label class="f">Название карты</label><input type="text" id="wn" maxlength="40" placeholder="Например: Чешский язык" value="${esc(w.name)}">
      <label class="f">Ваша цель<small>что будет, когда карта закончится</small></label><textarea id="wg" maxlength="140" placeholder="Например: свободно говорить на чешском на уровне B1">${esc(w.goal)}</textarea>
      <label class="f">Сколько клеток?<small>одна клетка = один день занятий</small></label>
      <div class="size-row"><input type="range" id="ws" min="10" max="500" value="${w.size}"><div class="size-num" id="wsn">${w.size}</div></div>
      <div class="chips" id="wc">${[14, 30, 60, 100, 180, 365].map(n => `<button data-n="${n}">${n}</button>`).join('')}</div>
      <div class="row end"><button class="btn primary" id="wnext">Дальше — выбрать мир</button></div>`;
      const rg = root.querySelector('#ws'), num = root.querySelector('#wsn');
      rg.oninput = () => { w.size = +rg.value; num.textContent = w.size; };
      root.querySelectorAll('#wc button').forEach(b => b.onclick = () => { w.size = +b.dataset.n; rg.value = w.size; num.textContent = w.size; });
      root.querySelector('#wnext').onclick = () => {
        keep(); if (!w.name.trim() || !w.goal.trim()) { toast('Добавьте название и цель — они понадобятся для финального поздравления.'); (w.name.trim() ? root.querySelector('#wg') : root.querySelector('#wn')).focus(); return; }
        w.step = 2; render();
      };
    } else if (w.step === 2) {
      root.innerHTML = `${steps(2)}<h2>Выберите мир</h2><p class="sub">От стиля зависят пейзаж, места, лор, рисковые события и цвет жидкой полоски прогресса.</p>
      <div class="themes">${Object.entries(T).map(([id, t]) => `<button class="tcard ${w.theme === id ? 'on' : ''}" data-t="${id}" style="--tc:${t.accent}"><span class="em">${t.emoji}</span><b>${esc(t.name)}</b><small>${esc(t.tag)}</small><span class="tag">${SURR[t.surround].label}</span><span class="dots">${['sea1', 'shore', 'plain', 'alt', 'high'].map(k => `<i style="background:${t.pal[k]}"></i>`).join('')}</span></button>`).join('')}</div>
      <div class="row end"><button class="btn ghost" id="wback">Назад</button><button class="btn primary" id="wnext">Показать карту</button></div>`;
      root.querySelectorAll('.tcard').forEach(b => b.onclick = () => { w.theme = b.dataset.t; w.gen = null; root.querySelectorAll('.tcard').forEach(x => x.classList.toggle('on', x === b)); });
      root.querySelector('#wback').onclick = () => { w.step = 1; render(); };
      root.querySelector('#wnext').onclick = () => { w.step = 3; render(); };
    } else {
      if (!w.gen) w.gen = generate(w.size, w.theme, w.seed);
      const th = T[w.theme], g = w.gen;
      const nr = g.pois.filter(p => th.pois[p.k].r !== 'common').length;
      root.innerHTML = `${steps(3)}<h2>${th.emoji} ${esc(w.name)}</h2><p class="sub">Вот ваш континент. Вокруг — ${SURR[th.surround].label.toLowerCase()}. Не нравится форма — бросьте кубик.</p>
      <div class="preview-wrap"><canvas id="wp"></canvas></div>
      <div class="sum"><span>${g.size} клеток · ${g.pois.length} мест (из них ${nr} редких и выше) · ${g.risky.length} рисковых</span><button class="btn" id="wdice">🎲 Другая карта</button></div>
      <div class="row end"><button class="btn ghost" id="wback">Назад</button><button class="btn primary" id="wgo">Начать путь</button></div>`;
      const c = root.querySelector('#wp'), side = Math.round(Math.min(560, root.clientWidth || 520) * Math.min(devicePixelRatio || 1, 2)); c.width = c.height = side;
      const tmp = { id: 'x', name: w.name, goal: w.goal, theme: w.theme, size: g.size, seed: w.seed, W: g.W, H: g.H, grid: g.grid, risky: g.risky, pois: g.pois, log: [], tries: [] };
      const prt = buildRT(tmp), pg = c.getContext('2d'); drawScene(pg, prt, fitFor(prt, side, side), side, side, 0, { reveal: true });
      root.querySelector('#wdice').onclick = () => { w.seed = (Math.random() * 1e9) | 0; w.gen = null; render(); };
      root.querySelector('#wback').onclick = () => { w.step = 2; render(); };
      root.querySelector('#wgo').onclick = () => {
        const m = { id: 'm' + Date.now().toString(36) + Math.floor(Math.random() * 1e4), name: w.name.trim(), goal: w.goal.trim(), theme: w.theme, size: g.size, seed: w.seed, W: g.W, H: g.H, grid: g.grid, risky: g.risky, pois: g.pois, log: [], tries: [], lastDay: null, created: Date.now(), done: null };
        S.maps.push(m); sh.close(); setActive(m.id); toast('Карта создана. Выберите первую клетку — любую 🌱');
      };
    }
  };
  render();
}

/* ───────── настройки ───────── */
let deferredInstall = null;
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferredInstall = e; });
function openSettings() {
  const th = S.ui.theme || document.documentElement.dataset.theme;
  const sh = sheet({ cls: 'wide', html: `<h2>Настройки</h2><p class="sub">Всё хранится только на этом устройстве.</p>
    <div class="setting"><div>Оформление</div><div class="seg" id="sg"><button data-v="auto">Авто</button><button data-v="light">Светлая</button><button data-v="dark">Тёмная</button></div></div>
    <div class="setting"><div>Одна клетка в день<small>Мягкое ограничение: захват — награда за честный день. Выключите, если хотите закрашивать без лимита.</small></div><div class="switch ${S.ui.oneDay ? 'on' : ''}" id="sw" role="switch"></div></div>
    <div class="setting"><div>Резервная копия<small>Сохраните файл с прогрессом — его можно загрузить на другом устройстве.</small></div><div class="row"><button class="btn" id="bex">Скачать</button><button class="btn" id="bim">Загрузить</button></div></div>
    <div class="setting" id="inst-row"><div>Установить приложение<small id="inst-hint">На телефоне: меню браузера → «Добавить на главный экран». На компьютере: значок установки в адресной строке.</small></div><button class="btn primary" id="binst">Установить</button></div>
    <div class="setting"><div>Сбросить всё<small>Удалит все карты на этом устройстве.</small></div><button class="btn danger" id="bres">Удалить данные</button></div>
    <input type="file" id="fimp" accept="application/json,.json" hidden>` });
  const seg = $('#sg', sh.s), mark = () => seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === (S.ui.theme || 'auto')));
  mark(); seg.querySelectorAll('button').forEach(b => b.onclick = () => { S.ui.theme = b.dataset.v === 'auto' ? null : b.dataset.v; applyTheme(); save(); mark(); });
  $('#sw', sh.s).onclick = e => { S.ui.oneDay = !S.ui.oneDay; e.currentTarget.classList.toggle('on', S.ui.oneDay); save(); };
  const bi = $('#binst', sh.s); if (!deferredInstall) bi.hidden = true; bi.onclick = async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; bi.hidden = true; };
  if (window.matchMedia('(display-mode: standalone)').matches || navigator.userAgent.includes('Electron')) $('#inst-row', sh.s).hidden = true;
  $('#bex', sh.s).onclick = () => {
    const blob = new Blob([JSON.stringify({ app: 'karta-zahvata', v: 1, data: S }, null, 1)], { type: 'application/json' }), a = el('a'); a.href = URL.createObjectURL(blob);
    a.download = 'karta-zahvata-' + todayStr() + '.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); toast('Копия сохранена 📦');
  };
  const fi = $('#fimp', sh.s); $('#bim', sh.s).onclick = () => fi.click();
  fi.onchange = async () => {
    try {
      const j = JSON.parse(await fi.files[0].text()), d = j.data || j; if (!d || !Array.isArray(d.maps)) throw 0;
      const c = sheet({ cls: 'small', html: `<div class="confirm-ico">📥</div><div class="confirm-q">Заменить текущие карты?</div><p class="sub">В файле карт: ${d.maps.length}. Текущие данные на этом устройстве будут заменены.</p><div class="row center"><button class="btn ghost" data-close>Отмена</button><button class="btn primary" id="yes">Заменить</button></div>` });
      $('#yes', c.s).onclick = () => { S = d; S.ui = S.ui || {}; if (S.ui.oneDay === undefined) S.ui.oneDay = true; save(); c.close(); sh.close(); applyTheme(); setActive(S.active || (S.maps[0] && S.maps[0].id) || null, true); toast('Данные загружены ✨'); };
    } catch (e) { toast('Не удалось прочитать файл — это точно копия из «Карты Захвата»?'); }
  };
  $('#bres', sh.s).onclick = () => {
    const c = sheet({ cls: 'small', html: `<div class="confirm-ico">⚠️</div><div class="confirm-q">Удалить все данные?</div><p class="sub">Все карты и прогресс будут удалены безвозвратно. Лучше сначала сделать резервную копию.</p><div class="row center"><button class="btn ghost" data-close>Отмена</button><button class="btn danger" id="yes">Удалить всё</button></div>` });
    $('#yes', c.s).onclick = () => { S.maps = []; S.active = null; save(); c.close(); sh.close(); setActive(null, true); };
  };
}
function openLegend() {
  sheet({ cls: 'small', html: `<h2>Обозначения</h2><div class="legend" style="margin-top:12px">
    <div><i style="background:rgba(255,255,255,.18);border:2px solid rgba(255,255,255,.7)"></i><span><b>Мерцающая рамка</b> — клетку можно закрасить сегодня (первая — любая, дальше — только рядом с закрашенными).</span></div>
    <div><i style="background:#ffa537;color:#2a1800">!</i><span><b>Оранжевый знак</b> — рискованная клетка. С первого раза захват удаётся в 40% случаев.</span></div>
    <div><i style="background:#6ecd91;color:#143">!</i><span><b>Зелёный знак</b> — второй шанс: теперь клетка покорится на 100%.</span></div>
    <div><i style="background:rgba(255,255,255,.12)">?</i><span><b>Знак вопроса</b> — под клеткой что-то спрятано: место, существо или тайна.</span></div>
    <div><i style="background:rgba(120,160,255,.2)">⌖</i><span>Колёсико / щипок — приближение. Тяните карту пальцем или мышью.</span></div>
    <div><i style="background:rgba(120,200,160,.2)">💧</i><span>Наведите курсор на жидкую полоску (или зажмите её на телефоне) — покажется процент.</span></div></div>
    <div class="row center"><button class="btn primary" data-close>Понятно</button></div>` });
}

/* ───────── победа и конфетти ───────── */
const cf = $('#confetti'), cfx = cf.getContext('2d'); let cfParts = [], cfRun = false;
function fireConfetti(th, n, burst) {
  if (reduce) n = Math.round(n / 3);
  cf.width = innerWidth; cf.height = innerHeight;
  const em = [th.emoji].concat(th.decor, th.pois.map(p => p.e)), cols = [th.accent, th.pal.shore, th.pal.plain, th.pal.high, '#fff', '#ffd36b'];
  for (let i = 0; i < n; i++) {
    const isE = Math.random() < 0.32;
    cfParts.push({ x: burst ? innerWidth / 2 : Math.random() * innerWidth, y: burst ? innerHeight * 0.45 : -20 - Math.random() * innerHeight * 0.5,
      vx: burst ? (Math.random() - 0.5) * 12 : (Math.random() - 0.5) * 2, vy: burst ? -Math.random() * 9 - 2 : 1.5 + Math.random() * 3,
      r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.3, s: 7 + Math.random() * 8, c: pick(cols), e: isE ? pick(em) : null, life: 260 + Math.random() * 120 });
  }
  if (!cfRun) { cfRun = true; requestAnimationFrame(cfLoop); }
}
function cfLoop() {
  cfx.clearRect(0, 0, cf.width, cf.height); cfParts = cfParts.filter(p => p.life > 0 && p.y < cf.height + 40);
  for (const p of cfParts) {
    p.x += p.vx; p.y += p.vy; p.vy += 0.05; p.vx *= 0.995; p.r += p.vr; p.life--;
    cfx.save(); cfx.translate(p.x, p.y); cfx.rotate(p.r); cfx.globalAlpha = clamp(p.life / 40, 0, 1);
    if (p.e) { cfx.font = Math.round(p.s * 2) + 'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif'; cfx.textAlign = 'center'; cfx.textBaseline = 'middle'; cfx.fillText(p.e, 0, 0); }
    else { cfx.fillStyle = p.c; cfx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); }
    cfx.restore();
  }
  if (cfParts.length) requestAnimationFrame(cfLoop); else { cfRun = false; cfx.clearRect(0, 0, cf.width, cf.height); }
}
function showWin() {
  const m = active(); if (!m) return; const th = T[m.theme], tpl = pick(window.GENERIC_WIN), goal = m.goal.replace(/[.!\s]+$/, '');
  const a = m.log.length ? fmtDate(m.log[0][1], true) : '', b = m.log.length ? fmtDate(m.log[m.log.length - 1][1], true) : '';
  const days = new Set(m.log.map(l => l[1])).size;
  const sh = sheet({ cls: 'small win-sheet', html: `<div class="trophy">${th.emoji === '🏴‍☠️' ? '🏆' : '🏆'}</div><h2>${esc(tpl.h)}</h2>
    <p>${esc(tpl.t.split('{goal}').join(goal))}</p><p style="font-family:var(--f-head);font-style:italic;font-size:1.25rem;color:var(--accent)">${esc(pick(th.win))}</p>
    <div class="meta">«${esc(m.name)}» · ${m.size} клеток · ${days} ${days % 10 === 1 && days % 100 !== 11 ? 'день' : (days % 10 >= 2 && days % 10 <= 4 && (days % 100 < 12 || days % 100 > 14)) ? 'дня' : 'дней'} занятий<br>${a} — ${b}</div>
    <div class="row center"><button class="btn" id="wnew">Новая карта</button><button class="btn primary" data-close>Спасибо ✨</button></div>` });
  $('#wnew', sh.s).onclick = () => { sh.close(); openWizard(); };
  fireConfetti(th, 160, true); setTimeout(() => fireConfetti(th, 120), 900); setTimeout(() => fireConfetti(th, 90), 2200);
}

/* ───────── тема приложения ───────── */
function applyTheme() {
  const dark = S.ui.theme ? S.ui.theme === 'dark' : (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'; applyAccent(active() ? T[active().theme] : null);
  setTimeout(() => { const mt = document.querySelector('meta[name=theme-color]'); if (mt) mt.content = getComputedStyle(document.body).backgroundColor; }, 60);
}

/* ───────── запуск ───────── */
function init() {
  load(); applyTheme();
  $('#btnMaps').onclick = openMaps; $('#btnCodex').onclick = () => active() ? openCodex() : toast('Сначала создайте карту');
  $('#btnMenu').onclick = openSettings; $('#btnLegend').onclick = openLegend; $('#btnWelcomeNew').onclick = openWizard;
  $('#btnFit').onclick = () => refit();
  $('#btnTheme').onclick = () => { const dark = document.documentElement.dataset.theme === 'dark'; S.ui.theme = dark ? 'light' : 'dark'; applyTheme(); save(); };
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (!S.ui.theme) applyTheme(); });
  new ResizeObserver(() => resize()).observe(cv);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); else updateHUD(); });
  window.addEventListener('pagehide', save);
  if (!S.maps.some(m => m.id === S.active)) S.active = S.maps.length ? S.maps[0].id : null;
  setActive(S.active, true);
  requestAnimationFrame(frame);
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist(); } catch (e) { }
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => { });
  window.__kz = { make(theme, size, name, goal) { const seed = (Math.random() * 1e9) | 0, g = generate(size, theme, seed); const m = { id: 'm' + Date.now().toString(36) + Math.floor(Math.random() * 1e4), name: name || 'Тест', goal: goal || 'пройти путь до конца', theme, size: g.size, seed, W: g.W, H: g.H, grid: g.grid, risky: g.risky, pois: g.pois, log: [], tries: [], lastDay: null, created: Date.now(), done: null }; S.maps.push(m); setActive(m.id); return m; },
    get S() { return S; }, get rt() { return rt; }, get view() { return view; }, claim: i => claim(i, false), openWizard, showWin, showPoi, cellAt, toast };
}
init();
})();
