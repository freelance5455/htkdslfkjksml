# Chattu Chat — Chrome Web App

Chattu Chat ek responsive web app hai. Chrome mein khulta hai aur Firebase configure karne ke baad ismein real account, friend code, real-time messages, online status aur photo sharing kaam karte hain.

## Important
ZIP mein app ka source code hai, lekin **aapke Firebase project ka config nahi hai**. Isliye pehli baar setup karna zaroori hai. Public hosted link tabhi milega jab aap ise Firebase Hosting ya kisi web host par deploy karenge. Yeh ZIP apne aap ek public website nahi banata.

## 1) Firebase project banayein
1. https://console.firebase.google.com/ kholein aur project create karein.
2. Project Overview → Add app → Web (`</>`) select karein.
3. Firebase SDK config copy karein.
4. `public/firebase-config.js` mein `PASTE_YOUR_API_KEY`, `YOUR_PROJECT_ID` wagairah ko apni actual values se replace karein. `databaseURL` Firebase Realtime Database page se copy karein; region ke hisaab se URL `https://PROJECT_ID-default-rtdb.firebaseio.com` ya doosra database URL ho sakta hai.

## 2) Firebase services enable karein
Firebase Console mein:
- **Authentication → Sign-in method → Email/Password → Enable**
- **Firestore Database → Create database**
- **Realtime Database → Create database**
- **Storage → Get started**

## 3) Rules lagayein
- Firestore → Rules: `firestore.rules` ka content paste karke Publish karein.
- Realtime Database → Rules: `database.rules.json` ka content paste karein.
- Storage → Rules: neeche diye gaye recommended rules paste karein.

### Storage rules (paste into Firebase Storage → Rules)
```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /chatPhotos/{chatId}/{fileName} {
      allow read: if request.auth != null;
      allow write: if request.auth != null
        && request.resource.size < 5 * 1024 * 1024
        && request.resource.contentType.matches('image/.*');
    }
  }
}
```

Note: Basic rules are a starter setup for testing. Production app ke liye stricter validation, abuse prevention, rate limits aur privacy/security review add karein. Current starter Firestore rules signed-in users ko user directory read karne dete hain taaki friend-code lookup kaam kare; isliye email jaise private profile fields ko production mein public user profile se alag rakhna behtar hai.

## 4) App ko Chrome mein test karein
### Sabse simple (local computer)
1. ZIP extract karein.
2. Computer par Node.js install ho to project folder ke andar terminal mein:
   ```bash
   npx serve public
   ```
3. Terminal mein jo local URL aaye, use Chrome mein kholein (aksar `http://localhost:3000`).

Firebase Auth mein local testing ke liye `localhost` authorized domain hona chahiye: Firebase Console → Authentication → Settings → Authorized domains.

### Public link banane ke liye (Firebase Hosting)
1. Node.js install karein.
2. Terminal mein project folder kholein aur:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init hosting
   ```
3. Public directory ke liye `public` select karein. Existing `index.html` overwrite na karein.
4. Single-page app rewrite ke sawal par `No` select kar sakte hain.
5. Phir:
   ```bash
   firebase deploy
   ```
6. Firebase aapko `https://YOUR_PROJECT_ID.web.app` jaisa live URL dega. Use Android Chrome mein bhi khol sakte hain.

## 5) Friend ke saath test
1. App ko do browser profiles/devices mein kholein.
2. Do alag email accounts se sign up karein.
3. Har account ka Friend Code copy karein.
4. Ek doosre ke code se add karein, phir message/photo bhej kar test karein.

## Features
- Email/password signup and login
- Unique friend code
- Friend add / reciprocal chat list
- Firestore real-time messages
- Realtime Database online status
- Photo upload (max 5 MB)
- Responsive layout for mobile and desktop

## Troubleshooting
- “Setup needed”: `public/firebase-config.js` abhi fill nahi hua.
- `permission-denied`: Firebase Rules publish hue hain ya nahi check karein.
- Auth error: Email/Password provider aur Authorized domains check karein.
- Photo upload failed: Storage enable karein aur Storage rules publish karein.
- Online status nahi aa raha: Realtime Database enable karein aur `databaseURL` sahi rakhein.
