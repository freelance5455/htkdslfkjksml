# JARVIS Android Starter (prototype)

यह एक शुरुआती Android Studio project है, production-ready पूरा AI assistant नहीं।

## इसमें क्या है
- Android WebView में HTML chat UI
- Android SpeechRecognizer से mic input
- Android TextToSpeech bridge
- कुछ known app package names खोलने का demo
- API key को ऐप में embed नहीं किया गया है

## Build करने के चरण
1. Android Studio install करें (आधिकारिक साइट से)।
2. ZIP extract करें।
3. Android Studio में `JarvisAndroidStarter` folder खोलें।
4. Gradle sync पूरा होने दें।
5. Galaxy A17 में Developer options और USB debugging चालू करें, फिर USB से जोड़ें; या Android Studio emulator इस्तेमाल करें।
6. Run दबाएँ। APK के लिए Build > Build APK(s) चुनें।
7. पहली बार microphone permission माँगे तो केवल तभी Allow करें जब आप voice feature इस्तेमाल करना चाहते हैं।

## अपना HTML जोड़ना
आपके पुराने HTML/CSS/JS को `app/src/main/assets/index.html` में रखें। लेकिन पुराने JavaScript में `speechSynthesis`/`SpeechRecognition` browser APIs इस्तेमाल होते हैं। Native bridge के लिए `AndroidJarvis.listen()` और `AndroidJarvis.speak(text)` को call करें या JavaScript fallback रखें।

## असली AI जोड़ना
- Backend (उदाहरण: Node.js server) बनाएँ और provider API key को server environment variable में रखें।
- ऐप/backend के बीच HTTPS endpoint बनाएँ, जैसे `POST /chat` जिसमें `{ "message": "...", "history": [...] }` जाए।
- ऐप में सीधे OpenAI/Gemini secret key न रखें। API key mobile/browser client में leak हो सकती है।
- Backend endpoint placeholder को लागू किए बिना यह starter AI answers generate नहीं करेगा।

## सीमाएँ
- “Hey Jarvis” always-on wake word इस starter में implement नहीं है।
- Android app launch demo है; package names फोन/region के अनुसार बदल सकते हैं।
- यह ऐप calls/SMS, flashlight, accessibility automation या settings बदलने की व्यापक अनुमति नहीं लेता।
- लगातार background microphone सुनने के लिए अलग foreground-service design, स्पष्ट user opt-in, notification, Android-version restrictions और battery testing चाहिए। सामान्य ऐप को हमेशा background से mic शुरू करने की अनुमति नहीं मिलती।
- API key, personal data, और permissions को production में सुरक्षित ढंग से संभालें।
