# Route Optimizer Android Project

यह ZIP एक **Android Studio project source** है, तैयार APK नहीं। इसमें आपकी HTML route-planner app को Android WebView के अंदर चलाने के लिए पैक किया गया है।

## शामिल सुविधाएँ
- आपकी मूल `route-planner.html` को `app/src/main/assets/index.html` के रूप में रखा गया है।
- Internet access, KML/KMZ file picker और location permission के लिए Android manifest/activity setup.
- HTML के मूल route-planning algorithm में जानबूझकर बदलाव नहीं किया गया।

## APK कैसे बनाएं
1. ZIP को extract करें।
2. Android Studio में `Route_Optimizer_Android_Project` folder खोलें।
3. Gradle sync पूरा होने दें।
4. **Build > Build APK(s)** चुनें।
5. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## जरूरी सीमाएँ
- इस ZIP में compiled `.apk` शामिल नहीं है। APK compile करने के लिए Android build environment (जैसे Android Studio/Gradle) चाहिए।
- Map tiles, OSRM routing और JavaScript libraries के लिए Internet जरूरी है।
- आपकी HTML में Google satellite tiles और public OSRM demo server इस्तेमाल होता है; उनकी उपलब्धता/usage limits अलग हो सकती हैं।
- Android WebView में local-file origin से GPS/geolocation का व्यवहार device/WebView के अनुसार बदल सकता है। यदि GPS अनुमति के बाद भी काम न करे, तो coordinates manually डालें।
