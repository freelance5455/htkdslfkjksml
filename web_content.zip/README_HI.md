# SafarSaathi — Android MVP Starter

SafarSaathi ek original Car + Bike ride-sharing app ka starter project hai. Is version mein **demo mode** chalta hai: sample rides search kar sakte hain, local session mein ride publish kar sakte hain aur demo booking bana sakte hain.

> **Zaroori:** Yeh abhi production-ready ride marketplace nahi hai. OTP, real accounts, online payments, GPS tracking, SOS, chat, push notifications aur admin actions abhi live integrations nahi hain. Demo data ko real verification na samjhein.

## Is MVP mein kya kaam karta hai?

- Home, Search, Publish, Trips aur Profile screens
- Car / Bike filter
- Route, date, seats aur fare fields
- Sample ride cards with trust indicators
- Demo booking ID creation (payment nahi hota)
- Ride publish local app session mein
- English / Hindi toggle (basic labels)
- Supabase starter client aur SQL schema
- Responsive static admin dashboard preview

## Requirements

- Node.js LTS
- Android phone par Expo Go, ya Android emulator
- Internet connection for installing packages
- Optional: free Supabase account

## 1. Project run karein

Terminal / command prompt mein project folder kholein:

```bash
npm install
npx expo start
```

Expo Go app mein QR code scan karein. Android emulator ke liye terminal mein `a` press kar sakte hain, agar Android Studio/emulator configured ho.

Agar Expo package compatibility ka issue aaye, installed Expo SDK ke compatible packages install karein:

```bash
npx expo install --fix
```

## 2. Admin dashboard preview

`admin/index.html` ko browser mein open karein. Yeh static demo preview hai, real database se connected nahi hai.

## 3. Supabase backend setup

1. https://supabase.com par free project banayein.
2. Project Settings → API se Project URL aur anon/public key copy karein.
3. `.env.example` ko `.env` naam se copy karein.
4. `.env` mein values daalein:

```bash
EXPO_PUBLIC_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

5. Supabase SQL Editor mein `supabase/schema.sql` ko review karke run karein.
6. App ko restart karein: `npx expo start -c`.

**Security:** `service_role` key kabhi mobile app mein na daalein. Public anon key ko bhi sirf proper RLS policies ke saath use karein. Is schema ko production se pehle security review ki zaroorat hai. Admin role ko client-side profile field se authorize na karein.

## 4. Android APK build

Development test ke liye pehle Expo Go use karein. Installable APK ke liye Expo Application Services (EAS) build workflow use kiya ja sakta hai; account/plan availability aur current build limits check karein.

Typical setup:

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

Agar EAS `preview` profile maange, project root mein `eas.json` banayein:

```json
{
  "build": {
    "preview": {
      "distribution": "internal",
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "app-bundle"
      }
    }
  }
}
```

Cloud build ki current free allowance/limits badal sakti hain. Build command ke output ko follow karein.

## 5. Real launch se pehle zaroori kaam

- Phone OTP provider and abuse/rate-limit protection
- Proper Supabase Auth sign-up/login and account deletion
- Server-side booking seat reservation to prevent double booking
- Payment gateway in test mode first; verified webhooks and refunds
- Map provider, location permission flows and real GPS testing
- Helmet, licence, RC and insurance verification process
- SOS flow with tested emergency contact/location sharing
- Chat moderation, block/report, notifications
- Admin dashboard connected to protected server-side API and audit log
- Legal, privacy, insurance and local transport-law review
- Unit/integration tests, monitoring, backups and incident handling

## Folder structure

```text
SafarSaathi_MVP/
├── App.tsx
├── app.json
├── package.json
├── tsconfig.json
├── .env.example
├── README_HI.md
├── src/
│   ├── data/demoRides.ts
│   └── lib/supabase.ts
├── supabase/schema.sql
└── admin/index.html
```

## Test checklist

1. Home screen par Car/Bike/Any select karein.
2. Search screen par Jaipur → Delhi search karein.
3. Kisi sample ride par View & book dabayein.
4. Confirm demo booking karein; Trips tab mein booking ID dikhni chahiye.
5. Publish tab par route aur fare fill karke ride publish karein.
6. Profile mein backend status dekhein.
7. Admin preview HTML browser mein open karein.

## Limitations

- Data abhi app memory mein hota hai; app restart hone par local changes reset ho sakte hain.
- Sample driver names, ratings aur verification labels illustrative demo data hain, real people/verification nahi.
- Real money, real bookings, identity documents, live GPS ya emergency response ke liye use na karein.
