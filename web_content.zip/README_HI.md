# Trading Plan Guard AI v1.5.3 — Paper Trading stage

## v1.5.3 change
- Fixed Paper Monitor initialization: its buttons now work independently of the separate Live API test button.
- Paper Monitor now writes status to its own status area, preventing Live API status from being overwritten.
- Added a busy guard to avoid overlapping LTP requests, safer invalid-state handling, and clearer JSON/API error messages.
- Retained opt-in 30-second visible-page checks; hidden pages are skipped.
- This is best-effort browser monitoring only, not background monitoring or a broker-side stop order.

## v1.5.2 retained
- Added opt-in 30-second repeated Paper SL/Target checks while the page is visible.
- Auto-check stops when the user presses stop; manual one-time SL/Target check remains available.

## Existing features
- Open paper trades can be checked against Groww LTP using the server-side read-only function.
- If LTP crosses the planned SL/Target, the app closes that trade in the local Paper Trading ledger and records the observed LTP as simulated exit.
- Each paper trade has CASH/FNO segment. For market monitoring, enter the exact Groww `exchange_symbols` value, e.g. `NSE_RELIANCE`.
- No live order create/modify/cancel endpoint is included or called.

## Deploy
1. Extract this ZIP. Deploy the files inside this folder (root `index.html`, `netlify.toml`, `netlify/functions/`).
2. Configure `GROWW_ACCESS_TOKEN` in Netlify Environment Variables. Never put it in HTML/ZIP/chat/public repository.
3. Redeploy and use Live API test.
4. Open the site and test paper mode with small simulated positions before relying on the monitor.

## Important limitations
- This is still Paper Trading + read-only market data. Live order placement is NOT implemented.
- The repeated check works only while the page is open and the browser permits timers/network requests. Phone lock, background suspension, network loss, stale prices, gaps and slippage can make the observed simulated exit differ from real fills.
- Browser localStorage is device-local and can be cleared/edited; it is not a tamper-proof risk engine.
- Real Auto Trading must use authenticated backend, persistent server-side limits, broker order status reconciliation, duplicate-order protection, kill switch, audit logs and strict per-order caps before any live orders are enabled.
- Real Groww API response and Android APK installation remain unverified until tested on the user's own Netlify/Groww setup.
