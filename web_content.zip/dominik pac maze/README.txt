DOMINIK PAC MAZE – prototípus

Indítás: nyisd meg az index.html fájlt egy modern böngészőben.
Irányítás: virtuális joystick, iránygombok, PC-n nyilak/WASD.
Funkciók: könnyű szellemek, 3 nehézségi szint/pálya, karakter-színek, helyi rekordmentés, kapcsolható hangok.

Google Play: ez a ZIP önmagában nem Android-alkalmazás és nem tölthető fel közvetlenül a Play Console-ba. Androidhoz csomagolás (pl. Android Studio/WebView vagy Unity), tesztelés, aláírt Android App Bundle (.aab), Play Console-fiók és a Google aktuális közzétételi követelményeinek teljesítése szükséges.
