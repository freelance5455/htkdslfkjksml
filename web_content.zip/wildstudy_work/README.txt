WildStudy website files

Upload the contents of this folder to a NEW Netlify site (do not overwrite NotesNest).
Open index.html to test locally. The notes page uses a broad portrait A4-ratio writing sheet and the side navigation now has white text on teal.

Note: this update fixes layout and tablet touch handling. It does not add independent multi-page note storage if that feature is not already present in the original app.
