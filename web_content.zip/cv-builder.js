import { createAHMADAiChat } from "./ai.js";

// عناصر صانع السيرة الذاتية
const cvFullName = document.getElementById("cvFullName");
const cvJobTitle = document.getElementById("cvJobTitle");
const cvEmail = document.getElementById("cvEmail");
const cvPhone = document.getElementById("cvPhone");
const cvLocation = document.getElementById("cvLocation");

const cvSummary = document.getElementById("cvSummary");
const cvEducation = document.getElementById("cvEducation");
const cvExperience = document.getElementById("cvExperience");
const cvSkills = document.getElementById("cvSkills");
const cvLanguages = document.getElementById("cvLanguages");

const cvTemplate = document.getElementById("cvTemplate");
const generateCVBtn = document.getElementById("generateCVBtn");
const cvBuilderStatus = document.getElementById("cvBuilderStatus");
const cvBuilderResult = document.getElementById("cvBuilderResult");
const cvBuilderOutput = document.getElementById("cvBuilderOutput");
const downloadCVBtn = document.getElementById("downloadCVBtn");
const editCVBtn = document.getElementById("editCVBtn");
const cvEditorBox = document.getElementById("cvEditorBox");
const cvEditorText = document.getElementById("cvEditorText");
const updateCVPreviewBtn = document.getElementById("updateCVPreviewBtn");
// عناصر سجل السير الذاتية
const cvHistorySection = document.getElementById("cvHistorySection");
const showCVHistoryBtn = document.getElementById("showCVHistoryBtn");
const cvHistoryList = document.getElementById("cvHistoryList");


// اتصال مستقل بالمساعد الذكي
const cvAI = createAHMADAiChat();

// تخزين آخر سيرة ذاتية تم إنشاؤها
let generatedCVText = "";
// معرّف السيرة المفتوحة حالياً
let currentCVId = null;
// نظام الحفظ التلقائي للسيرة الذاتية
const cvStorageKey = "ahmadAICVData";
// سجل جميع السير الذاتية
const cvHistoryKey = "ahmadAICVHistory";

let cvHistory = [];

try {
  cvHistory = JSON.parse(
    localStorage.getItem(cvHistoryKey) || "[]"
  );

  if (!Array.isArray(cvHistory)) {
    cvHistory = [];
  }
} catch (error) {
  cvHistory = [];
}
const cvFields = [
  cvFullName,
  cvJobTitle,
  cvEmail,
  cvPhone,
  cvLocation,
  cvSummary,
  cvEducation,
  cvExperience,
  cvSkills,
  cvLanguages,
  cvTemplate
];
// حفظ بيانات السيرة الذاتية
function saveCVData() {
  const data = {};

  cvFields.forEach(field => {
    data[field.id] = field.value;
  });

  data.generatedCVText = generatedCVText;

  localStorage.setItem(cvStorageKey, JSON.stringify(data));
}function saveCVToHistory() {
  const cvData = {};

  cvFields.forEach(field => {
    cvData[field.id] = field.value;
  });

  const cvRecord = {
    id: currentCVId || Date.now().toString(),
    name: cvFullName.value.trim(),
    job: cvJobTitle.value.trim(),
    date: new Date().toLocaleString("ar"),
    text: generatedCVText,
    fields: cvData
  };

  const existingIndex = cvHistory.findIndex(
    item => item.id === cvRecord.id
  );

  if (existingIndex !== -1) {
    cvHistory[existingIndex] = cvRecord;
  } else {
    cvHistory.unshift(cvRecord);
  }

  currentCVId = cvRecord.id;

  localStorage.setItem(
    cvHistoryKey,
    JSON.stringify(cvHistory)
  );
}
// عرض سجل السير الذاتية
function renderCVHistory(){
  cvHistoryList.innerHTML = "";

  if (cvHistory.length === 0) {
    cvHistoryList.textContent = "لا توجد سير ذاتية محفوظة حالياً.";
    return;
  }

  cvHistory.forEach(record => {
    const card = document.createElement("div");
    card.className = "cv-history-card";

    const name = document.createElement("h4");
    name.textContent = record.name || "بدون اسم";

    const job = document.createElement("p");
    job.textContent = record.job || "بدون مسمى وظيفي";

    const date = document.createElement("small");
    date.textContent = record.date || "";

    const openBtn = document.createElement("button");
openBtn.type = "button";
openBtn.textContent = "فتح وتعديل";
openBtn.dataset.action = "open";
openBtn.dataset.id = record.id;

const deleteBtn = document.createElement("button");
deleteBtn.type = "button";
deleteBtn.textContent = "حذف";
deleteBtn.dataset.action = "delete";
deleteBtn.dataset.id = record.id;

card.append(name, job, date, openBtn, deleteBtn);
    cvHistoryList.appendChild(card);
  });
} 
// عرض وإخفاء سجل السير الذاتية
showCVHistoryBtn?.addEventListener("click", () => {
  cvHistoryList.hidden = !cvHistoryList.hidden;

  if (!cvHistoryList.hidden) {
    renderCVHistory();
    showCVHistoryBtn.textContent = "إخفاء السجل";
  } else {
    showCVHistoryBtn.textContent = "عرض السير الذاتية المحفوظة";
  }
});

// فتح سيرة ذاتية محفوظة
cvHistoryList?.addEventListener("click", event => {
  const button = event.target.closest(
    'button[data-action="open"]'
  );

  if (!button) return;

  const record = cvHistory.find(
    item => item.id === button.dataset.id
  );

  if (!record) return;

  currentCVId = record.id;

  cvFields.forEach(field => {
    if (record.fields && record.fields[field.id] !== undefined) {
      field.value = record.fields[field.id];
    }
  });

  generatedCVText = record.text || "";

  renderCVPreview(generatedCVText);
  cvBuilderResult.hidden = false;
  cvEditorBox.hidden = true;

  saveCVData();

  cvBuilderStatus.textContent = "تم فتح السيرة الذاتية المحفوظة.";
  cvBuilderStatus.hidden = false;
});

// حذف سيرة ذاتية من السجل
cvHistoryList?.addEventListener("click", event => {
  const button = event.target.closest(
    'button[data-action="delete"]'
  );

  if (!button) return;

  const confirmed = confirm("هل تريد حذف هذه السيرة الذاتية نهائياً؟");

  if (!confirmed) return;

  cvHistory = cvHistory.filter(
    item => item.id !== button.dataset.id
  );

  localStorage.setItem(
    cvHistoryKey,
    JSON.stringify(cvHistory)
  );

  renderCVHistory();
});
// استعادة بيانات السيرة الذاتية
function loadCVData() {
  const saved = localStorage.getItem(cvStorageKey);

  if (!saved) return;

  try {
    const data = JSON.parse(saved);

    cvFields.forEach(field => {
      if (data[field.id] !== undefined) {
        field.value = data[field.id];
      }
    });

    generatedCVText = data.generatedCVText || "";

    if (generatedCVText.trim()) {
      renderCVPreview(generatedCVText);
      cvBuilderResult.hidden = false;
    }
  } catch (error) {
    console.error("CV Restore Error:", error);
  }
}

// الحفظ عند الكتابة أو تغيير القالب
cvFields.forEach(field => {
  field.addEventListener("input", saveCVData);
  field.addEventListener("change", saveCVData);
});

// استعادة البيانات عند فتح التطبيق
loadCVData();
function renderCVPreview(text) {
  const escapeHTML = value =>
    String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[char]);

  const sections = {
    "النبذة الشخصية": "summary",
    "الخبرات العملية": "experience",
    "التعليم والشهادات": "education",
    "المهارات": "skills",
    "اللغات": "languages"
  };

  const lines = text
    .replace(/\r/g, "")
    .split("\n")
    .map(line => line.trim())
    .filter(line => line && !/^---+$/.test(line));

  let name = cvFullName.value.trim();
  let job = cvJobTitle.value.trim();
  let contact = "";
  const data = {
    summary: [],
    experience: [],
    education: [],
    skills: [],
    languages: []
  };

  let currentSection = "";

  lines.forEach((line, index) => {
    const clean = line
      .replace(/^#{1,3}\s*/, "")
      .replace(/\*\*/g, "")
      .replace(/^[-*]\s*/, "")
      .trim();

    if (sections[clean]) {
      currentSection = sections[clean];
      return;
    }

    if (/^المسمى الوظيفي\s*[:：]/.test(clean)) {
      job = clean.replace(/^المسمى الوظيفي\s*[:：]\s*/, "");
      return;
    }

    if (
      /البريد الإلكتروني|الهاتف|الموقع/.test(clean) &&
      !currentSection
    ) {
      contact = clean;
      return;
    }

    if (!name && index === 0) {
      name = clean;
      return;
    }

    if (currentSection) {
      data[currentSection].push(clean);
    }
  });

  if (!contact) {
    contact = [
      cvLocation.value.trim(),
      cvPhone.value.trim(),
      cvEmail.value.trim()
    ].filter(Boolean).join(" | ");
  }

  const renderItems = items =>
    items.map(item =>
      `<p class="cv-layout-item">${escapeHTML(item)}</p>`
    ).join("");

  const renderSection = (title, key) => {
    if (!data[key].length) return "";

    return `
      <section class="cv-layout-section">
        <h3 class="cv-layout-section-title">${title}</h3>
        ${renderItems(data[key])}
      </section>
    `;
  };

  cvBuilderOutput.innerHTML = `
    <article class="cv-layout-page">

      <header class="cv-layout-header">
        <h1 class="cv-layout-name">${escapeHTML(name)}</h1>
        <p class="cv-layout-job">${escapeHTML(job)}</p>
        <p class="cv-layout-contact">${escapeHTML(contact)}</p>
      </header>

      <div class="cv-layout-columns">

        <aside class="cv-layout-sidebar">
          ${renderSection("المهارات", "skills")}
          ${renderSection("اللغات", "languages")}
        </aside>

        <main class="cv-layout-main">
          ${renderSection("النبذة الشخصية", "summary")}
          ${renderSection("الخبرات العملية", "experience")}
          ${renderSection("التعليم والشهادات", "education")}
        </main>

      </div>

      <footer class="cv-layout-footer">
        AHMAD AI · PROFESSIONAL CV
      </footer>

    </article>
  `;
}





// إنشاء السيرة الذاتية
generateCVBtn?.addEventListener("click", async () => {
  const fullName = cvFullName.value.trim();
  const jobTitle = cvJobTitle.value.trim();
  const email = cvEmail.value.trim();

  if (!fullName || !jobTitle || !email) {
    cvBuilderStatus.textContent =
      "يرجى إدخال الاسم والمسمى الوظيفي والبريد الإلكتروني.";
    cvBuilderStatus.hidden = false;
    return;
  }

  const templateNames = {
    modern: "عصري احترافي",
    classic: "كلاسيكي رسمي",
    minimal: "بسيط وأنيق",
    creative: "إبداعي مميز"
  };

  const prompt = `
أنت خبير محترف في كتابة السير الذاتية.

أنشئ سيرة ذاتية احترافية ومنظمة اعتماداً على المعلومات التالية فقط.
لا تخترع أي خبرات أو شهادات أو مهارات غير مذكورة.
إذا كانت المعلومات ناقصة، لا تضف معلومات من عندك.

الاسم: ${fullName}
المسمى الوظيفي: ${jobTitle}
البريد الإلكتروني: ${email}
الهاتف: ${cvPhone.value.trim()}
الموقع: ${cvLocation.value.trim()}

النبذة الشخصية:
${cvSummary.value.trim()}

التعليم والشهادات:
${cvEducation.value.trim()}

الخبرات العملية:
${cvExperience.value.trim()}

المهارات:
${cvSkills.value.trim()}

اللغات:
${cvLanguages.value.trim()}

القالب المطلوب: ${templateNames[cvTemplate.value] || "عصري احترافي"}

اكتب السيرة الذاتية بعناوين واضحة وترتيب احترافي.
اجعلها مناسبة للتقديم على الوظائف.
استخدم لغة عربية احترافية.
أعد النص النهائي فقط دون مقدمات أو تعليقات إضافية.
`;
currentCVId = null;
  generateCVBtn.disabled = true;
  generateCVBtn.textContent = "⏳ جارٍ إنشاء السيرة الذاتية...";

  cvBuilderStatus.hidden = false;
  cvBuilderStatus.textContent = "يتم الآن إعداد سيرتك الذاتية بالذكاء الاصطناعي.";

  cvBuilderResult.hidden = true;

  try {
    generatedCVText = await cvAI.send(prompt);

    if (!generatedCVText.trim()) {
      throw new Error("لم يتم إنشاء محتوى السيرة الذاتية.");
    }

    renderCVPreview(generatedCVText);
cvBuilderResult.hidden = false;
saveCVData();
saveCVToHistory();
    cvBuilderStatus.textContent =
      "تم إنشاء سيرتك الذاتية بنجاح. يمكنك مراجعتها الآن.";

  } catch (error) {
    console.error("CV Builder Error:", error);

    cvBuilderStatus.textContent =
      "تعذر إنشاء السيرة الذاتية. تحقق من الاتصال بالإنترنت وحاول مجدداً.";
  } finally {
    generateCVBtn.disabled = false;
    generateCVBtn.textContent =
      "✨ إنشاء السيرة الذاتية بالذكاء الاصطناعي";
  }
});




// تحميل السيرة الذاتية بصيغة PDF
downloadCVBtn?.addEventListener("click", () => {
  if (!generatedCVText.trim()) {
    cvBuilderStatus.textContent = "أنشئ السيرة الذاتية أولاً.";
    cvBuilderStatus.hidden = false;
    return;
  }

  window.print();
});

// فتح محرر السيرة الذاتية
editCVBtn?.addEventListener("click", () => {
  cvEditorText.value = generatedCVText;
  cvEditorBox.hidden = false;
  cvEditorText.focus();
});

// تحديث معاينة السيرة الذاتية بعد التعديل
updateCVPreviewBtn?.addEventListener("click", () => {
  const editedText = cvEditorText.value.trim();

  if (!editedText) {
    cvBuilderStatus.textContent = "اكتب محتوى السيرة الذاتية أولاً.";
    cvBuilderStatus.hidden = false;
    return;
  }

  generatedCVText = editedText;
  saveCVData();
  saveCVToHistory();
  renderCVPreview(generatedCVText);

  cvEditorBox.hidden = true;

  cvBuilderStatus.textContent = "تم تحديث السيرة الذاتية بنجاح.";
  cvBuilderStatus.hidden = false;
});