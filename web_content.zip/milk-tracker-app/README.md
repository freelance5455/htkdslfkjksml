# Milk Tracker App

Milk tracking app with a local web version and Android wrapper project.

## Features
- Local browser storage for month-wise milk records
- Daily status tracking with quantity controls
- Monthly total, extra paid, and amount due calculation
- JSON backup and restore for safer phone usage
- Mobile-friendly layout for browser and WebView use

## Web app usage
- Open `index.html`
- Data is saved in local storage on the same device/browser
- Use **Backup JSON** to download a backup file
- Use **Restore JSON** to load a previous backup file

## PWA install
- Serve this folder with any simple static server
- Open the app in Chrome on Android using `http://` or `https://` (not `file://`)
- Use the browser menu and choose **Install app** or **Add to Home screen**
- After install, it opens like a normal app
- Basic files are cached for offline use after first load

## Android APK packaging
This folder already contains an Android project in `app/`.

Recommended packaging approach:
- load the web app inside the Android app WebView
- keep local storage on the phone
- use JSON backup/restore for manual safety

## Build APK
- Open this folder in Android Studio
- Let Gradle sync
- Build debug APK or release APK from Android Studio

## Notes
- Local data can still be lost if app storage is cleared or the app is uninstalled
- Keep JSON backups for safety
- Service worker install requires serving the app from a local or hosted web server
