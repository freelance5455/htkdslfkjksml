const storageKey = 'milk-tracker-data-v1';
const defaultMilkRate = 50;

const monthPicker = document.getElementById('monthPicker');
const milkRateInput = document.getElementById('milkRate');
const extraPaidInput = document.getElementById('extraPaid');
const monthTitle = document.getElementById('monthTitle');
const calendarGrid = document.getElementById('calendarGrid');
const dayTemplate = document.getElementById('dayTemplate');
const takenDaysEl = document.getElementById('takenDays');
const missedDaysEl = document.getElementById('missedDays');
const notMarkedDaysEl = document.getElementById('notMarkedDays');
const monthlyTotalEl = document.getElementById('monthlyTotal');
const previousCreditEl = document.getElementById('previousCredit');
const finalAmountEl = document.getElementById('finalAmount');
const creditBreakdownEl = document.getElementById('creditBreakdown');
const extraInfoBtn = document.getElementById('extraInfoBtn');
const extraInfoPopup = document.getElementById('extraInfoPopup');
const paymentStatusEl = document.getElementById('paymentStatus');
const paidToggleBtn = document.getElementById('paidToggle');
const prevMonthBtn = document.getElementById('prevMonth');
const nextMonthBtn = document.getElementById('nextMonth');
const exportBackupBtn = document.getElementById('exportBackupBtn');
const importBackupBtn = document.getElementById('importBackupBtn');
const importBackupInput = document.getElementById('importBackupInput');
const backupStatusEl = document.getElementById('backupStatus');

const today = new Date();
let currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
let appState = loadState();

initialize();

function initialize() {
  monthPicker.value = formatMonthInput(currentMonth);
  ensureMonthState(getMonthKey(currentMonth));
  bindEvents();
  render();
}

function bindEvents() {
  monthPicker.addEventListener('change', () => {
    const [year, month] = monthPicker.value.split('-').map(Number);
    currentMonth = new Date(year, month - 1, 1);
    ensureMonthState(getMonthKey(currentMonth));
    render();
  });

  bindCommitInput(milkRateInput, (value) => {
    const monthState = getCurrentMonthState();
    monthState.rate = Number(value) || defaultMilkRate;
    saveState();
    updateSummary();
  });

  bindCommitInput(extraPaidInput, (value) => {
    const monthState = getCurrentMonthState();
    monthState.extraPaid = Number(value) || 0;
    saveState();
    updateSummary();
  });

  paidToggleBtn.addEventListener('click', () => {
    const monthState = getCurrentMonthState();
    monthState.paid = !monthState.paid;
    saveState();
    updatePaymentUI();
  });

  prevMonthBtn.addEventListener('click', () => changeMonth(-1));
  nextMonthBtn.addEventListener('click', () => changeMonth(1));

  exportBackupBtn.addEventListener('click', exportBackup);
  importBackupBtn.addEventListener('click', () => importBackupInput.click());
  importBackupInput.addEventListener('change', importBackup);

  extraInfoBtn.addEventListener('click', (event) => {
    event.stopPropagation();
    extraInfoPopup.hidden = !extraInfoPopup.hidden;
  });

  document.addEventListener('click', (event) => {
    if (!extraInfoPopup.hidden && !extraInfoPopup.contains(event.target) && event.target !== extraInfoBtn) {
      extraInfoPopup.hidden = true;
    }
  });
}

function bindCommitInput(input, onCommit) {
  const commit = () => onCommit(input.value);

  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      commit();
      input.blur();
    }
  });

  input.addEventListener('blur', commit);
}

function changeMonth(offset) {
  currentMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + offset, 1);
  monthPicker.value = formatMonthInput(currentMonth);
  ensureMonthState(getMonthKey(currentMonth));
  render();
}

function render() {
  const monthState = getCurrentMonthState();
  milkRateInput.value = monthState.rate || defaultMilkRate;
  extraPaidInput.value = monthState.extraPaid || '';
  monthTitle.textContent = currentMonth.toLocaleDateString('en-IN', {
    month: 'long',
    year: 'numeric'
  });
  renderCalendar();
  updateSummary();
  updatePaymentUI();
  extraInfoPopup.hidden = true;
}

function renderCalendar() {
  calendarGrid.innerHTML = '';

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i += 1) {
    const emptyCell = document.createElement('div');
    emptyCell.className = 'day-cell empty';
    calendarGrid.appendChild(emptyCell);
  }

  for (let day = 1; day <= daysInMonth; day += 1) {
    const dayCell = dayTemplate.content.firstElementChild.cloneNode(true);
    const dayNumber = dayCell.querySelector('.day-number');
    const dayStatus = dayCell.querySelector('.day-status');
    const quantityControls = dayCell.querySelector('.day-quantity-controls');
    const quantityLabel = dayCell.querySelector('.day-quantity');
    const minusBtn = dayCell.querySelector('.qty-minus');
    const plusBtn = dayCell.querySelector('.qty-plus');
    const tookBtn = dayCell.querySelector('.took-action');
    const missedBtn = dayCell.querySelector('.missed-action');
    const noneBtn = dayCell.querySelector('.none-action');
    const dayEntry = getDayEntry(day);
    const status = dayEntry.status;

    dayNumber.textContent = day;
    applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, status, dayEntry.quantity);

    tookBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      const currentEntry = getDayEntry(day);
      const nextQuantity = currentEntry.status === 'took' ? currentEntry.quantity : 0.5;
      setDayEntry(day, 'took', nextQuantity);
      saveState();
      const updatedEntry = getDayEntry(day);
      applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, updatedEntry.status, updatedEntry.quantity);
      updateSummary();
    });

    missedBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      setDayEntry(day, 'missed', 0);
      saveState();
      const updatedEntry = getDayEntry(day);
      applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, updatedEntry.status, updatedEntry.quantity);
      updateSummary();
    });

    noneBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      setDayEntry(day, 'none', 0);
      saveState();
      const updatedEntry = getDayEntry(day);
      applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, updatedEntry.status, updatedEntry.quantity);
      updateSummary();
    });

    minusBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      const currentEntry = getDayEntry(day);
      if (currentEntry.status !== 'took') {
        return;
      }

      const nextQuantity = Math.max(0.5, currentEntry.quantity - 0.5);
      setDayEntry(day, 'took', nextQuantity);
      saveState();
      applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, 'took', nextQuantity);
      updateSummary();
    });

    plusBtn.addEventListener('click', (event) => {
      event.stopPropagation();
      const currentEntry = getDayEntry(day);
      if (currentEntry.status !== 'took') {
        return;
      }

      const nextQuantity = currentEntry.quantity + 0.5;
      setDayEntry(day, 'took', nextQuantity);
      saveState();
      applyDayStatus(dayCell, dayStatus, quantityControls, quantityLabel, 'took', nextQuantity);
      updateSummary();
    });

    calendarGrid.appendChild(dayCell);
  }
}

function applyDayStatus(button, label, quantityControls, quantityLabel, status, quantity) {
  button.classList.remove('took', 'missed');

  if (status === 'took') {
    button.classList.add('took');
    label.textContent = 'Took';
    quantityControls.hidden = false;
    quantityLabel.textContent = formatQuantity(quantity);
  } else if (status === 'missed') {
    button.classList.add('missed');
    label.textContent = 'Missed';
    quantityControls.hidden = true;
  } else {
    label.textContent = 'Not marked';
    quantityControls.hidden = true;
  }
}

function updateSummary() {
  const monthState = getCurrentMonthState();
  const dayEntries = Object.values(monthState.days).map(normalizeDayEntry);
  const takenDays = dayEntries.filter((entry) => entry.status === 'took').length;
  const missedDays = dayEntries.filter((entry) => entry.status === 'missed').length;
  const totalQuantity = dayEntries
    .filter((entry) => entry.status === 'took')
    .reduce((sum, entry) => sum + entry.quantity, 0);
  const daysInMonth = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0).getDate();
  const notMarkedDays = Math.max(daysInMonth - takenDays - missedDays, 0);
  const total = totalQuantity * (Number(monthState.rate) || 0);
  const previousCredits = getPreviousCredits(currentMonth);
  const previousCarryForward = previousCredits.total;
  const amountPaid = Number(monthState.extraPaid) || 0;
  const finalAmount = Math.max(total - previousCarryForward - amountPaid, 0);

  takenDaysEl.textContent = takenDays;
  missedDaysEl.textContent = missedDays;
  notMarkedDaysEl.textContent = notMarkedDays;
  monthlyTotalEl.textContent = formatCurrency(total);
  previousCreditEl.textContent = formatCurrency(previousCarryForward);
  finalAmountEl.textContent = formatCurrency(finalAmount);
  extraInfoBtn.hidden = previousCarryForward <= 0 || previousCredits.items.length === 0;
  if (extraInfoBtn.hidden) {
    extraInfoPopup.hidden = true;
  }
  renderCreditBreakdown(previousCredits.items);
}

function updatePaymentUI() {
  const monthState = getCurrentMonthState();
  paymentStatusEl.textContent = monthState.paid ? 'Paid' : 'Unpaid';
  paidToggleBtn.textContent = monthState.paid ? 'Mark as Unpaid' : 'Mark as Paid';
  paidToggleBtn.classList.toggle('paid', monthState.paid);
  paidToggleBtn.classList.toggle('unpaid', !monthState.paid);
}

function getCurrentMonthState() {
  return appState.months[getMonthKey(currentMonth)];
}

function ensureMonthState(monthKey) {
  if (!appState.months[monthKey]) {
    appState.months[monthKey] = {
      rate: defaultMilkRate,
      extraPaid: 0,
      paid: false,
      days: {}
    };
    saveState();
    return;
  }

  if (!appState.months[monthKey].rate) {
    appState.months[monthKey].rate = defaultMilkRate;
    saveState();
  }
}

function getDayEntry(day) {
  return normalizeDayEntry(getCurrentMonthState().days[day]);
}

function setDayEntry(day, status, quantity) {
  if (status === 'none') {
    delete getCurrentMonthState().days[day];
    return;
  }

  getCurrentMonthState().days[day] = {
    status,
    quantity: status === 'took' ? Math.max(0.5, quantity || 0.5) : 0
  };
}

function normalizeDayEntry(entry) {
  if (typeof entry === 'string') {
    return {
      status: entry,
      quantity: entry === 'took' ? 0.5 : 0
    };
  }

  if (!entry || typeof entry !== 'object') {
    return { status: 'none', quantity: 0 };
  }

  return {
    status: entry.status || 'none',
    quantity: entry.status === 'took' ? Math.max(0.5, Number(entry.quantity) || 0.5) : 0
  };
}

function getPreviousMonthCarryForward(date) {
  return getPreviousCredits(date).total;
}

function getPreviousCredits(date) {
  const items = [];
  const currentKey = getMonthKey(date);
  const monthKeys = Object.keys(appState.months).sort();
  let runningCredit = 0;
  let activeCredits = [];

  for (const monthKey of monthKeys) {
    if (monthKey >= currentKey) {
      break;
    }

    const monthState = appState.months[monthKey];
    const totalQuantity = Object.values(monthState.days || {})
      .map(normalizeDayEntry)
      .filter((entry) => entry.status === 'took')
      .reduce((sum, entry) => sum + entry.quantity, 0);
    const total = totalQuantity * (Number(monthState.rate) || 0);
    const amountPaid = Number(monthState.extraPaid) || 0;
    let remainingDue = total;

    if (runningCredit > 0) {
      const usedFromPrevious = Math.min(runningCredit, remainingDue);
      remainingDue -= usedFromPrevious;
      runningCredit -= usedFromPrevious;

      if (runningCredit <= 0) {
        activeCredits = [];
      }
    }

    const usedFromCurrentPayment = Math.min(amountPaid, remainingDue);
    remainingDue -= usedFromCurrentPayment;
    const ownExtraPaid = Math.max(amountPaid - usedFromCurrentPayment, 0);

    if (ownExtraPaid > 0) {
      activeCredits.push({
        monthKey,
        credit: ownExtraPaid
      });
    }

    runningCredit += ownExtraPaid;

    items.length = 0;
    items.push(...activeCredits);
  }

  return { total: runningCredit, items };
}

function renderCreditBreakdown(items) {
  if (!items.length) {
    creditBreakdownEl.className = 'credit-breakdown empty-state';
    creditBreakdownEl.textContent = 'No previous extra paid available.';
    return;
  }

  creditBreakdownEl.className = 'credit-breakdown';
  creditBreakdownEl.innerHTML = items
    .map(({ monthKey, credit }) => {
      const [year, month] = monthKey.split('-').map(Number);
      const label = new Date(year, month - 1, 1).toLocaleDateString('en-IN', {
        month: 'short',
        year: '2-digit'
      }).replace(' ', '');

      return `<div class="credit-row"><span>${label}</span><strong>${formatCurrency(credit)}</strong></div>`;
    })
    .join('');
}

function getMonthKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

function formatMonthInput(date) {
  return getMonthKey(date);
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR'
  }).format(amount);
}

function formatQuantity(quantity) {
  return `${quantity}L`;
}

function exportBackup() {
  const backup = {
    exportedAt: new Date().toISOString(),
    version: 1,
    data: appState
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `milk-tracker-backup-${getMonthKey(new Date())}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  setBackupStatus('Backup downloaded successfully.');
}

function importBackup(event) {
  const [file] = event.target.files || [];
  if (!file) {
    return;
  }

  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      const nextState = parsed?.data || parsed;

      if (!nextState || typeof nextState !== 'object' || typeof nextState.months !== 'object') {
        throw new Error('Invalid backup file');
      }

      appState = {
        months: nextState.months || {}
      };
      ensureMonthState(getMonthKey(currentMonth));
      saveState();
      render();
      setBackupStatus(`Backup restored from ${file.name}.`);
    } catch {
      setBackupStatus('Could not restore backup. Please choose a valid JSON file.');
    } finally {
      importBackupInput.value = '';
    }
  };

  reader.readAsText(file);
}

function setBackupStatus(message) {
  backupStatusEl.textContent = message;
}

function loadState() {
  try {
    return JSON.parse(localStorage.getItem(storageKey)) || { months: {} };
  } catch {
    return { months: {} };
  }
}

function saveState() {
  localStorage.setItem(storageKey, JSON.stringify(appState));
}
