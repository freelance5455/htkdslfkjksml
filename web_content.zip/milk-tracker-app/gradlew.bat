@echo off
echo Gradle wrapper is not generated yet. Open this project in Android Studio and generate/sync the wrapper.
exit /b 1
