HUSSAIN SECRET CODE — Offline Web App
=====================================

Included:
- index.html: self-contained app, HTML/CSS/JavaScript, no external libraries or network requests.
- 12 selectable cyber themes.
- Automatic theme selection on launch (when reopened in a fresh app/browser session; browser lifecycle behavior can vary).
- Quick Code mode (randomized format, NOT secure encryption).
- AES-256-GCM encryption with fresh random salt and nonce each time.
- PBKDF2-SHA256 password derivation (250,000 iterations).
- Copy/share encrypted code and decrypt it on another copy of the app using the same password.
- Bangla and English text support.
- Local-only processing. No server or account.

IMPORTANT:
- This ZIP is a working offline web-app source package, NOT an APK.
- For best Web Crypto support, open it through an Android offline HTML viewer that supports Web Crypto, or serve it from localhost/HTTPS. Some file viewers disable crypto APIs.
- To decrypt, copy the entire HSC1.... string and enter the same password.
- Share the password separately using a trusted channel. Anyone with both code and password can decrypt the message.
- Quick Code is only obfuscation and is not secure; use AES-GCM password encryption for private messages.
- This has not been independently security-audited. Do not use it as the only protection for highly sensitive information.
- No internet connection is required by the app code once it is opened in a compatible environment.
