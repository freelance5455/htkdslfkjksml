# KnovelOfficial JEE Study Tracker

## Files
- `index.html` — app layout
- `styles.css` — responsive purple-blue glassmorphism styling
- `app.js` — offline storage, forms, calculations, charts, timer, backup/restore

## Run in Acode (Android)
1. Extract `Knovel_JEE_Study_Tracker.zip` into a folder on your phone.
2. Open Acode and open the extracted folder.
3. Open `index.html`.
4. Use Acode's Preview button (or its browser preview) to run the app.
5. If preview opens the raw file or storage doesn't persist, use Acode's local preview/server option if available and open the local page in your browser.
6. Add the page to your Home screen from the browser menu for app-like access.

## Important
- No external libraries, network calls, or paid APIs are required.
- Data is saved in this browser's `localStorage` on this device. Browser/site-data clearing can erase it.
- Use the top-right export icon or Settings → Import/backup to maintain a JSON backup.
- This is a local website, not a signed APK. It can be wrapped into an APK later if desired.

## How to use
1. Log study sessions with minutes, attempted questions and correct answers.
2. Add chapters and update status/confidence as your understanding improves.
3. Schedule revisions. Marking one reviewed creates the next review using 1/3/7/14/30-day spacing.
4. Track homework assignments and increment completed questions using +1 done.
5. Log each mock test with score/max marks, subject scores and the main lesson.
5. Check Overview for hours, question counts, streak, revision queue and charts.

The dashboard homework metric shows total question completion across your homework assignments.
