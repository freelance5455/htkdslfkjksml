DOMPETKU AI PRO — PROYEK ANDROID STUDIO

Isi ZIP ini adalah proyek sumber Android Studio, bukan file APK yang sudah dikompilasi.

CARA MEMBUAT APK:
1. Ekstrak ZIP.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder DompetKu_AI_Pro_AndroidStudio.
4. Tunggu Gradle Sync selesai. Jika diminta, izinkan Android Studio memasang Android SDK Platform 35 dan Build Tools.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya tersedia di app/build/outputs/apk/debug/app-debug.apk.
7. Salin APK ke HP penerima dan instal. Android mungkin meminta izin 'Instal aplikasi tidak dikenal'.

CATATAN:
- Aplikasi memuat HTML lokal dalam WebView dan menggunakan penyimpanan lokal browser.
- Scan keamanan dalam versi ini adalah simulasi informasi, bukan antivirus dan tidak memindai seluruh perangkat secara realtime.
- Jangan mengklaim perangkat bebas virus berdasarkan hasil scan ini.
- Copyright di footer: © 2026 DompetKu AI Pro.
