const letters = [
 {l:"آ",word:"آهو",image:"ahoo",audio:"alef",wordAudio:"ahoo"},
 {l:"ا",word:"انار",image:"anar",audio:"ale",wordAudio:"anar"},
 {l:"ب",word:"بابا",image:"baba",audio:"be",wordAudio:"baba"},
 {l:"پ",word:"پروانه",image:"parvane",audio:"pe",wordAudio:"parvane"},
 {l:"ت",word:"توپ",image:"toop",audio:"te",wordAudio:"toop"},
 {l:"ث",word:"ثریا",image:"soraya",audio:"se",wordAudio:"soraya"},
 {l:"ج",word:"جوجه",image:"jooje",audio:"jim",wordAudio:"jooje"},
 {l:"چ",word:"چتر",image:"chat",audio:"che",wordAudio:"chat"},
 {l:"ح",word:"حوض",image:"hoz",audio:"he",wordAudio:"hoz"},
 {l:"خ",word:"خرگوش",image:"khargoosh",audio:"khe",wordAudio:"khargoosh"},
 {l:"د",word:"درخت",image:"derakht",audio:"dal",wordAudio:"derakht"},
 {l:"ذ",word:"ذرت",image:"zorrat",audio:"zal",wordAudio:"zorrat"},
 {l:"ر",word:"رنگین‌کمان",image:"ranginkaman",audio:"re",wordAudio:"ranginkaman"},
 {l:"ز",word:"زرافه",image:"zarafe",audio:"ze",wordAudio:"zarafe"},
 {l:"ژ",word:"ژاکت",image:"zhaket",audio:"zhe",wordAudio:"zhaket"},
 {l:"س",word:"سیب",image:"sib",audio:"sin",wordAudio:"sib"},
 {l:"ش",word:"شیر",emoji:"🦁",audio:"shin",wordAudio:"shir"},
 {l:"ص",word:"صدف",emoji:"🐚",audio:"sad",wordAudio:"sadaf"},
 {l:"ض",word:"ضرب",emoji:"➗",audio:"zad",wordAudio:"zarb"},
 {l:"ط",word:"طوطی",emoji:"🦜",audio:"ta",wordAudio:"tooti"},
 {l:"ظ",word:"ظرف",emoji:"🍽️",audio:"za",wordAudio:"zarf"},
 {l:"ع",word:"عینک",emoji:"👓",audio:"eyn",wordAudio:"eyn ak"},
 {l:"غ",word:"غنچه",emoji:"🌷",audio:"gheyn",wordAudio:"ghonche"},
 {l:"ف",word:"فیل",emoji:"🐘",audio:"fe",wordAudio:"fil"},
 {l:"ق",word:"قلم",emoji:"✏️",audio:"qaf",wordAudio:"ghalam"},
 {l:"ک",word:"کتاب",emoji:"📚",audio:"kaf",wordAudio:"ketab"},
 {l:"گ",word:"گربه",emoji:"🐱",audio:"gaf",wordAudio:"gorbe"},
 {l:"ل",word:"لاله",emoji:"🌷",audio:"lam",wordAudio:"lale"},
 {l:"م",word:"ماهی",emoji:"🐠",audio:"mim",wordAudio:"mahi"},
 {l:"ن",word:"نان",emoji:"🍞",audio:"noon",wordAudio:"nan"},
 {l:"و",word:"ورزش",emoji:"🏃",audio:"vav",wordAudio:"varzesh"},
 {l:"ه",word:"هواپیما",emoji:"✈️",audio:"he2",wordAudio:"havapeyma"},
 {l:"ی",word:"یاس",emoji:"🌼",audio:"ye",wordAudio:"yas"}
];
const $=id=>document.getElementById(id);
let selectedIndex=0, stars=Number(localStorage.getItem("goldenAlphabetStars")||0), quizIndex=0, answered=false;
function toFa(n){return String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);}
$("starCount").textContent=toFa(stars);
function imageMarkup(item, id, cls){
 const el=$(id);
 if(item.image){el.src="images/"+item.image+".jpg";el.alt="تصویر "+item.word;el.classList.remove("emoji-fallback");}
 else {el.removeAttribute("src");el.alt=item.emoji||"🌟";el.classList.add("emoji-fallback");el.dataset.emoji=item.emoji||"🌟";}
}
function renderLetters(){
 $("letterGrid").innerHTML="";
 letters.forEach((item,index)=>{
  const btn=document.createElement("button");btn.className="letter-tile"+(index===selectedIndex?" selected":"");btn.textContent=item.l;
  btn.setAttribute("aria-label","حرف "+item.l);btn.addEventListener("click",()=>selectLetter(index));$("letterGrid").appendChild(btn);
 });
}
function selectLetter(index){
 selectedIndex=index;const item=letters[index];
 $("detailLetter").textContent=item.l;$("detailWord").textContent=item.l+" مثل "+item.word;
 $("detailHint").textContent="به تصویر نگاه کن، نام حرف و کلمه را با صدای بلند بگو.";
 imageMarkup(item,"detailImage");renderLetters();
}
function playAudio(filename){
 const audio=new Audio("audio/"+filename+".mp3");
 audio.onerror=()=>$("audioStatus").textContent="فایل audio/"+filename+".mp3 هنوز اضافه نشده است.";
 audio.oncanplaythrough=()=>$("audioStatus").textContent="در حال پخش صدا…";
 audio.play().catch(()=>$("audioStatus").textContent="فایل صوتی این مورد هنوز اضافه نشده است.");
}
$("playLetter").addEventListener("click",()=>playAudio(letters[selectedIndex].audio));
$("playWord").addEventListener("click",()=>playAudio(letters[selectedIndex].wordAudio));
document.querySelectorAll(".tab").forEach(tab=>tab.addEventListener("click",()=>{
 document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));tab.classList.add("active");
 $("learnPanel").classList.toggle("hidden",tab.dataset.tab!=="learn");$("quizPanel").classList.toggle("hidden",tab.dataset.tab!=="quiz");
 if(tab.dataset.tab==="quiz")startQuiz();
}));
function startQuiz(){
 quizIndex=Math.floor(Math.random()*letters.length);answered=false;const item=letters[quizIndex];
 $("quizWord").textContent=item.word;imageMarkup(item,"quizImage");$("quizFeedback").textContent="";$("quizFeedback").className="feedback";
 $("nextQuestion").classList.add("hidden");$("quizProgress").textContent="سؤال تازه";
 const choices=[item.l];while(choices.length<4){const c=letters[Math.floor(Math.random()*letters.length)].l;if(!choices.includes(c))choices.push(c);}
 choices.sort(()=>Math.random()-.5);$("quizOptions").innerHTML="";
 choices.forEach(letter=>{const btn=document.createElement("button");btn.className="quiz-option";btn.textContent=letter;btn.addEventListener("click",()=>checkAnswer(btn,letter,item.l));$("quizOptions").appendChild(btn);});
}
function checkAnswer(button,chosen,correct){
 if(answered)return;answered=true;
 document.querySelectorAll(".quiz-option").forEach(btn=>{btn.disabled=true;if(btn.textContent===correct)btn.classList.add("correct");});
 if(chosen===correct){$("quizFeedback").textContent="آفرین! جواب درست بود ⭐";$("quizFeedback").className="feedback good";stars++;localStorage.setItem("goldenAlphabetStars",stars);$("starCount").textContent=toFa(stars);}
 else{button.classList.add("wrong");$("quizFeedback").textContent="اشکالی نداره؛ جواب درست "+correct+" بود. دوباره تمرین می‌کنیم!";$("quizFeedback").className="feedback bad";}
 $("nextQuestion").classList.remove("hidden");
}
$("nextQuestion").addEventListener("click",startQuiz);
renderLetters();selectLetter(0);
