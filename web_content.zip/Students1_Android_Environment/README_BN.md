# Students 1 — Android Environment

এই প্রজেক্টে WebView shell, WhatsApp external-intent routing এবং Android native local reminder alarm যুক্ত করা হয়েছে। HTML app-এর বাকি business logic অপরিবর্তিত রাখা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
1. APKForge-এর প্রকাশিত documentation-এ custom Java/Kotlin bridge বা native AlarmManager integration-এর সেটিং/ইনজেকশন দেখানো নেই। তাই এই native notification ব্যবস্থা APKForge-এর সাধারণ HTML-to-APK build-এ নিজে থেকে সক্রিয় হবে না। এই প্রজেক্ট Android Studio/Gradle build-এর জন্য।
2. `app/build.gradle`-এর `applicationId`-এ বর্তমানে placeholder `com.tasnim.students1` আছে। ইনস্টল করা APK-এর **একই package name** না দিলে পুরোনো APK-এর উপর update হবে না এবং পুরোনো app data স্বয়ংক্রিয়ভাবে পাওয়া যাবে না।
3. `app/src/main/assets/index.html`-এ `Students_1_APK_Ready.html` কপি করে `index.html` নাম দিতে হবে।
4. একই signing keystore দিয়ে sign না করলে Android update install করতে দেবে না। পুরোনো keystore ছাড়া একই package-এ update সম্ভব নাও হতে পারে।
5. প্রথমবার Android 13+ এ notification permission চাইবে। Permission denied হলে OS notification দেখাবে না। Exact alarm permission না থাকলে Android-এর inexact idle alarm fallback ব্যবহার হবে; কিছু ফোনে সময় কয়েক মিনিট দেরি হতে পারে।

## Build
Android Studio-তে এই ফোল্ডার Open করে Gradle sync এবং Build APK করো। এই পরিবেশে Android SDK/Gradle build চালিয়ে APK runtime-test করা হয়নি।

## Included
- WebView JavaScript + DOM storage + file chooser
- WhatsApp `wa.me` / `api.whatsapp.com` Android app handoff
- Reminder JSON sync from existing `TasnimTuitionRemindersV1` localStorage key
- Android notification channel, scheduled alarms, reboot rescheduling
- Android 13+ POST_NOTIFICATIONS runtime permission request
