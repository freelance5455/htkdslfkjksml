Replace this placeholder with Students_1_APK_Ready.html renamed to index.html. Keep the filename index.html.
