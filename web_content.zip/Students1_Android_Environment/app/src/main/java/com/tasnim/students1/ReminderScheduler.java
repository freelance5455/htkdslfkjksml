package com.tasnim.students1;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

public final class ReminderScheduler {
    private static final String PREF="students1_native_reminders"; private ReminderScheduler(){}
    static void schedule(Context c,String id,String title,long at,String itemId) { if(at<=System.currentTimeMillis()) return;
        Intent i=new Intent(c,ReminderReceiver.class).setAction("com.tasnim.students1.REMINDER").putExtra("id",id).putExtra("title",title).putExtra("itemId",itemId);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(am!=null){ if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else am.set(AlarmManager.RTC_WAKEUP,at,pi); }
        SharedPreferences p=c.getSharedPreferences(PREF,0); try { JSONArray a=new JSONArray(p.getString("items","[]")); JSONArray n=new JSONArray(); boolean replaced=false; for(int x=0;x<a.length();x++){JSONObject old=a.getJSONObject(x);if(old.optString("id").equals(id)){replaced=true;continue;}n.put(old);} JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("at",at);o.put("itemId",itemId);n.put(o);p.edit().putString("items",n.toString()).apply(); }catch(Exception ignored){}
    }
    static void cancelMissing(Context c,Set<String> keep){ SharedPreferences p=c.getSharedPreferences(PREF,0); try{JSONArray a=new JSONArray(p.getString("items","[]"));JSONArray n=new JSONArray();for(int x=0;x<a.length();x++){JSONObject o=a.getJSONObject(x);String id=o.optString("id");if(keep.contains(id))n.put(o);else cancel(c,id);}p.edit().putString("items",n.toString()).apply();}catch(Exception ignored){} }
    static void cancel(Context c,String id){Intent i=new Intent(c,ReminderReceiver.class).setAction("com.tasnim.students1.REMINDER");PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);}
    static void restore(Context c){SharedPreferences p=c.getSharedPreferences(PREF,0);try{JSONArray a=new JSONArray(p.getString("items","[]"));for(int x=0;x<a.length();x++){JSONObject o=a.getJSONObject(x);schedule(c,o.optString("id"),o.optString("title","Reminder"),o.optLong("at"),o.optString("itemId",""));}}catch(Exception ignored){}}
}
