package com.tasnim.students1;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");String title=i.getStringExtra("title");if(title==null||title.isEmpty())title="Reminder";Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("reminder_id",id).putExtra("item_id",i.getStringExtra("itemId"));PendingIntent pi=PendingIntent.getActivity(c,id==null?1:id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"students1_reminders"):new Notification.Builder(c);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🔔 Tasnim Tuition").setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title+" — Reminder-এর সময় হয়েছে")).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id==null?1:id.hashCode(),b.build()); }
}
