package com.tasnim.students1;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 4101;
    private static final int NOTIFICATION_PERMISSION = 4102;
    private static final String CHANNEL_ID = "students1_reminders";

    @Override public void onCreate(Bundle state) { super.onCreate(state); createChannel(); requestNotificationPermission();
        web = new WebView(this); setContentView(web);
        WebSettings ws = web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        ws.setJavaScriptCanOpenWindowsAutomatically(false); ws.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) { return routeUrl(req.getUrl().toString()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return routeUrl(url); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null); fileCallback = cb;
                Intent i = params.createIntent(); try { startActivityForResult(i, FILE_CHOOSER); return true; }
                catch (ActivityNotFoundException e) { fileCallback = null; Toast.makeText(MainActivity.this, "ফাইল নির্বাচন করা যাচ্ছে না", Toast.LENGTH_SHORT).show(); return false; }
            }
            @Override public void onPermissionRequest(android.webkit.PermissionRequest request) {
                // WebView media permissions are granted only after Android runtime permission is available.
                if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { request.deny(); return; }
                request.grant(request.getResources());
            }
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    private boolean routeUrl(String url) {
        if (url == null) return false;
        Uri u = Uri.parse(url); String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase();
        if ("https".equals(scheme) && (host.equals("wa.me") || host.equals("api.whatsapp.com") || host.equals("www.whatsapp.com"))) { openExternal(url); return true; }
        if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme) || "tel".equals(scheme) || "whatsapp".equals(scheme)) {
            if (url.startsWith("file:///android_asset/")) return false; openExternal(url); return true;
        }
        return false;
    }
    private void openExternal(String url) { try { Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); startActivity(i); } catch (Exception e) { Toast.makeText(this, "এই লিংক খোলার অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show(); } }

    private void createChannel() { if (Build.VERSION.SDK_INT >= 26) { NotificationChannel c = new NotificationChannel(CHANNEL_ID, "Photo Note Reminders", NotificationManager.IMPORTANCE_HIGH); c.setDescription("Tasnim Tuition saved note reminders"); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c); } }
    private void requestNotificationPermission() { if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION); }

    public class AndroidBridge {
        @JavascriptInterface public void openExternal(String url) { runOnUiThread(() -> MainActivity.this.openExternal(url)); }
        @JavascriptInterface public void syncReminders(String json) {
            try { JSONArray arr = new JSONArray(json); java.util.HashSet<String> keep = new java.util.HashSet<>();
                for (int i=0;i<arr.length();i++) { JSONObject o=arr.getJSONObject(i); String id=o.optString("id"); if(id.isEmpty()) continue; keep.add(id); ReminderScheduler.schedule(MainActivity.this,id,o.optString("title","Reminder"),o.optLong("at",0),o.optString("itemId","")); }
                ReminderScheduler.cancelMissing(MainActivity.this, keep);
            } catch(Exception e) { android.util.Log.e("Students1", "Reminder sync failed", e); }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==FILE_CHOOSER && fileCallback!=null) { Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data); fileCallback.onReceiveValue(result); fileCallback=null; } }
    @Override public void onBackPressed() { if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if(web!=null) web.destroy(); super.onDestroy(); }
}
