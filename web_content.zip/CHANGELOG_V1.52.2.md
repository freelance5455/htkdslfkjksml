# v1.52.2 — Correção do encerramento Sub-20

- Corrigido o bloqueio em que a temporada Sub-20 já aparecia como processada, mas o jogador não conseguia abrir novamente a tela para escolher entre subir ao profissional ou continuar na base.
- A tela de fim de temporada pode ser reaberta sem duplicar o histórico, notícias ou registro de temporada.
- O avanço para a temporada seguinte continua sendo feito pelos botões de promoção ou permanência; não altera os resultados já registrados.
