# Trail Pocket — prototype Android / PWA

Cette archive contient un prototype fonctionnel de l'application Trail Pocket :
- calculateur de glucides et boisson avec marge configurable ;
- checklist de matériel enregistrée localement ;
- chronomètre ;
- calcul d'allure/vitesse ;
- estimation simplifiée du supplément lié au dénivelé.

## Important
Ce dossier **n'est pas un APK compilé**. L'environnement de création ne dispose pas de la chaîne Android nécessaire pour générer et signer un APK/AAB vérifiable. Le prototype peut être testé dans un navigateur moderne en ouvrant `index.html`.

## Installer comme application web (PWA)
Pour que l'installation PWA et le mode hors ligne fonctionnent correctement, héberger ces fichiers sur un site HTTPS, puis ouvrir le site dans Chrome sur Android et choisir « Installer l'application » ou « Ajouter à l'écran d'accueil ».

## Publier sur Google Play
Pour publier sur Google Play, il faut transformer ce prototype en application Android (par exemple avec Android Studio et une Trusted Web Activity / wrapper adapté), générer un **AAB signé**, tester l'application, remplir la fiche Play Store et respecter les exigences actuelles de Google Play. Un compte développeur Google Play est nécessaire et peut entraîner des frais. Les règles de test applicables aux nouveaux comptes doivent être vérifiées directement dans Play Console.

## Publicité et revenus
Aucun SDK publicitaire n'est intégré dans cette démo. Pour utiliser AdMob, créer l'application dans son compte AdMob, ajouter le SDK officiel à la version Android, déclarer les identifiants publicitaires et mettre en place le consentement RGPD applicable en France/EEE. Utiliser des annonces de test pendant le développement. Ne jamais cliquer sur ses propres annonces. Les revenus ne sont pas garantis et dépendent notamment du nombre d'utilisateurs et des impressions.

## À améliorer avant une vraie publication
- créer une icône d'application et des captures d'écran ;
- ajouter une politique de confidentialité hébergée publiquement ;
- tester l'accessibilité, les tailles d'écran et les cas limites ;
- vérifier les règles Play Store et les exigences de test du compte ;
- ne pas présenter les estimations de ravitaillement ou de temps comme des conseils médicaux ou des prédictions garanties.

## Fichiers
- `index.html` : interface et fonctionnalités ;
- `manifest.webmanifest` : métadonnées PWA ;
- `sw.js` : cache hors ligne simple.
