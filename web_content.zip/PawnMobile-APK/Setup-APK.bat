@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [1/4] npm install ...
call npm install || goto :err
if not exist android (
  echo [2/4] Adding Android project ...
  call npx cap add android || goto :err
)
echo [3/4] Camera permission ...
node scripts\patch-manifest.js || goto :err
echo [3b] App icon ...
node scripts\apply-icon.js || goto :err
echo [4/4] Copy web files ...
call npx cap sync android || goto :err
echo.
echo Done. Now run:  npx cap open android   (Android Studio) -> Build -> Build APK(s)
echo Or without Android Studio UI:  cd android ^&^& gradlew assembleDebug
echo APK: android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:err
echo FAILED - see message above.
pause
exit /b 1
