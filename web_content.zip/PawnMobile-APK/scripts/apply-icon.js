// Copies the shop logo icons into the generated Android project (launcher icon).
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const src = path.join(root, 'resources', 'icons');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
let n = 0;
for (const d of fs.readdirSync(src)) {
  const to = path.join(res, d);
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(path.join(src, d))) { fs.copyFileSync(path.join(src, d, f), path.join(to, f)); n++; }
}
// white background for the adaptive icon
const bgf = path.join(res, 'values', 'ic_launcher_background.xml');
fs.mkdirSync(path.dirname(bgf), { recursive: true });
fs.writeFileSync(bgf, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#FFFFFF</color>\n</resources>\n');
console.log('Icon applied (' + n + ' files)');

// App name shown under the icon
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const sf = path.join(res, 'values', 'strings.xml');
let sx = fs.readFileSync(sf, 'utf8');
sx = sx.replace(/(<string name="app_name">)[^<]*(<\/string>)/, '$1' + cfg.appName + '$2')
       .replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, '$1' + cfg.appName + '$2');
fs.writeFileSync(sf, sx);
console.log('App name: ' + cfg.appName);
