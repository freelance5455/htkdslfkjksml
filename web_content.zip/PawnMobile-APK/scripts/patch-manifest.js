// Adds CAMERA permission (needed for live QR scan) to the generated Android project.
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
let x = fs.readFileSync(f, 'utf8');
const add = [];
if (!x.includes('android.permission.CAMERA')) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!x.includes('android.hardware.camera"')) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (!x.includes('ACCESS_NETWORK_STATE')) add.push('    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />');
if (!x.includes('android.permission.INTERNET')) add.push('    <uses-permission android:name="android.permission.INTERNET" />');
if (add.length) {
  x = x.replace(/<\/manifest>\s*$/, add.join('\n') + '\n</manifest>\n');
  fs.writeFileSync(f, x);
}
console.log('Manifest OK (camera + internet permissions present)');
