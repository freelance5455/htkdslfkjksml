PAWN MOBILE — BUILD APK USING ONLY YOUR ANDROID PHONE

This package is prepared for cloud APK building with GitHub Actions.
You do NOT need Android Studio or a laptop for this method. You do need:
- Android phone + internet
- A GitHub account

STEPS
1. Extract this ZIP on your phone (Files app / ZArchiver).
2. In a browser, sign in to github.com and create a NEW repository.
3. Open the repository -> Add file -> Upload files.
4. Upload the CONTENTS of the PawnMobile-APK folder (not the outer folder).
   Make sure .github/workflows/build-apk.yml is included. If your file
   manager hides dot-folders, create .github/workflows on GitHub and add
   build-apk.yml using the exact workflow file from this package.
5. Commit the uploaded files.
6. Open the repository -> Actions -> "Build Pawn APK" -> Run workflow.
7. Wait until the workflow finishes with a green check.
8. Open that completed run, scroll to Artifacts, and download
   PawnMobile-debug-apk. Extract it; install app-debug.apk on your phone.
9. If Android asks, allow "Install unknown apps" for the browser/files app.

CONNECTION FIX
- The mobile app now keeps laptop API traffic on http://<laptop-ip>:5000.
- It no longer changes the address to https://<laptop-ip>:5443 just because the app WebView uses HTTPS.
- Use the exact laptop IP shown by Start-Pawn.bat; phone and laptop must be on the same Wi-Fi/hotspot.

IMPORTANT
- This creates a DEBUG APK for testing/installation, not a Play Store release.
- Keep the GitHub repository Private because your app source is uploaded there.
- Do not share your GitHub password or private tokens.
- No build method can promise zero errors; if Actions shows a red X, send
  the error log screenshot/text and I can help fix it.
- Camera permission is added by the included script. Allow camera permission
  when the app asks.
- The app's laptop live-QR feature requires the laptop/server and phone to
  be on the same Wi-Fi/hotspot, as described in the original README.
