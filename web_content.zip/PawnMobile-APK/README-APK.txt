PAWN MOBILE - APK build (Capacitor)

தேவை: Node.js 18+ (nodejs.org) மற்றும் Android Studio (SDK உடன்) - ஒருமுறை நிறுவவும்.

1. Setup-APK.bat-ஐ double-click செய்யவும் (இணையம் தேவை, ஒருமுறை).
2. Android Studio: npx cap open android  -> Build > Build APK(s)
   APK: android\app\build\outputs\apk\debug\app-debug.apk
3. APK-ஐ மொபைலில் install செய்து திறக்கவும். முதல் முறை "Camera allow" கேட்கும் -> Allow.

LIVE QR (APK-ல்):
  - header-ல் உள்ள லோகோவைத் தட்டினால் கேமரா திறக்கும்; லேப்டாப் QR-ஐக் காட்டினால் தானாக இணையும் (போட்டோ தேவையில்லை).
  - லேப்டாப்பும் மொபைலும் ஒரே Wi-Fi / hotspot. லேப்டாப்பில் Start-Pawn.bat ஓட வேண்டும்.
  - இந்த config-ல் androidScheme=http, cleartext=true உள்ளது (லேப்டாப் http://IP:5000-ஐ APK அழைக்க இது அவசியம்; மாற்ற வேண்டாம்).

www\index.html மாற்றினால்: npx cap sync android -> மீண்டும் Build APK.
(PawnShop\ui\mobile.html மாற்றினால் அதை www\index.html-ஆக copy செய்யவும்.)

வேறு APK tool (WebView / Cordova / online converter) பயன்படுத்தினால்:
  - AndroidManifest-ல் CAMERA + INTERNET permission சேர்க்கவும்.
  - WebView-ல் WebChromeClient.onPermissionRequest-ல் request.grant(request.getResources()) செய்து, runtime-ல் CAMERA அனுமதி கேட்கவும். இல்லையென்றால் live scan திறக்காது.
  - Page-ஐ https அல்லது http://localhost-ல் இருந்து ஏற்றவும் (file:// -ல் camera வராது).

APP ICON: கடை லோகோ (www\logo.png) தானாகவே app icon-ஆக அமையும் (Setup-APK.bat செய்யும்). மாற்ற: resources\icons\ உள்ள படங்களை மாற்றி Setup-APK.bat மீண்டும் இயக்கவும்.
