/* Орбита VPN: данные (страны, ошибки, тарифы, FAQ) */
(function (O) {
  'use strict';

  var U = O.util;
  var D = O.data = {};

  /* Точка, откуда считаются расстояния и пинг. */
  D.ORIGIN = { lat: 50.45, lon: 30.52 };

  /* Код | название ru | название en | широта | долгота | регион */
  var RAW = [
    'AF|Афганистан|Afghanistan|34.5|69.2|asia',
    'AL|Албания|Albania|41.3|19.8|europe',
    'DZ|Алжир|Algeria|36.7|3.1|africa',
    'AD|Андорра|Andorra|42.5|1.5|europe',
    'AO|Ангола|Angola|-8.8|13.2|africa',
    'AG|Антигуа и Барбуда|Antigua and Barbuda|17.1|-61.8|americas',
    'AR|Аргентина|Argentina|-34.6|-58.4|americas',
    'AM|Армения|Armenia|40.2|44.5|asia',
    'AU|Австралия|Australia|-35.3|149.1|oceania',
    'AT|Австрия|Austria|48.2|16.4|europe',
    'AZ|Азербайджан|Azerbaijan|40.4|49.9|asia',
    'BS|Багамы|Bahamas|25.0|-77.4|americas',
    'BH|Бахрейн|Bahrain|26.2|50.6|asia',
    'BD|Бангладеш|Bangladesh|23.8|90.4|asia',
    'BB|Барбадос|Barbados|13.1|-59.6|americas',
    'BY|Беларусь|Belarus|53.9|27.6|europe',
    'BE|Бельгия|Belgium|50.8|4.4|europe',
    'BZ|Белиз|Belize|17.3|-88.8|americas',
    'BJ|Бенин|Benin|6.5|2.6|africa',
    'BT|Бутан|Bhutan|27.5|89.6|asia',
    'BO|Боливия|Bolivia|-16.5|-68.1|americas',
    'BA|Босния и Герцеговина|Bosnia and Herzegovina|43.9|18.4|europe',
    'BW|Ботсвана|Botswana|-24.7|25.9|africa',
    'BR|Бразилия|Brazil|-15.8|-47.9|americas',
    'BN|Бруней|Brunei|4.9|114.9|asia',
    'BG|Болгария|Bulgaria|42.7|23.3|europe',
    'BF|Буркина-Фасо|Burkina Faso|12.4|-1.5|africa',
    'BI|Бурунди|Burundi|-3.4|29.4|africa',
    'CV|Кабо-Верде|Cabo Verde|14.9|-23.5|africa',
    'KH|Камбоджа|Cambodia|11.6|104.9|asia',
    'CM|Камерун|Cameroon|3.9|11.5|africa',
    'CA|Канада|Canada|45.4|-75.7|americas',
    'CF|ЦАР|Central African Republic|4.4|18.6|africa',
    'TD|Чад|Chad|12.1|15.0|africa',
    'CL|Чили|Chile|-33.4|-70.7|americas',
    'CN|Китай|China|39.9|116.4|asia',
    'CO|Колумбия|Colombia|4.7|-74.1|americas',
    'KM|Коморы|Comoros|-11.7|43.3|africa',
    'CG|Республика Конго|Republic of the Congo|-4.3|15.3|africa',
    'CD|ДР Конго|DR Congo|-4.4|15.4|africa',
    'CR|Коста-Рика|Costa Rica|9.9|-84.1|americas',
    'CI|Кот-д’Ивуар|Côte d’Ivoire|6.8|-5.3|africa',
    'HR|Хорватия|Croatia|45.8|16.0|europe',
    'CU|Куба|Cuba|23.1|-82.4|americas',
    'CY|Кипр|Cyprus|35.2|33.4|europe',
    'CZ|Чехия|Czechia|50.1|14.4|europe',
    'DK|Дания|Denmark|55.7|12.6|europe',
    'DJ|Джибути|Djibouti|11.6|43.1|africa',
    'DM|Доминика|Dominica|15.3|-61.4|americas',
    'DO|Доминиканская Республика|Dominican Republic|18.5|-69.9|americas',
    'EC|Эквадор|Ecuador|-0.2|-78.5|americas',
    'EG|Египет|Egypt|30.0|31.2|africa',
    'SV|Сальвадор|El Salvador|13.7|-89.2|americas',
    'GQ|Экваториальная Гвинея|Equatorial Guinea|3.8|8.8|africa',
    'ER|Эритрея|Eritrea|15.3|38.9|africa',
    'EE|Эстония|Estonia|59.4|24.7|europe',
    'SZ|Эсватини|Eswatini|-26.3|31.1|africa',
    'ET|Эфиопия|Ethiopia|9.0|38.7|africa',
    'FJ|Фиджи|Fiji|-18.1|178.4|oceania',
    'FI|Финляндия|Finland|60.2|24.9|europe',
    'FR|Франция|France|48.9|2.4|europe',
    'GA|Габон|Gabon|0.4|9.5|africa',
    'GM|Гамбия|Gambia|13.5|-16.6|africa',
    'GE|Грузия|Georgia|41.7|44.8|asia',
    'DE|Германия|Germany|52.5|13.4|europe',
    'GH|Гана|Ghana|5.6|-0.2|africa',
    'GR|Греция|Greece|38.0|23.7|europe',
    'GD|Гренада|Grenada|12.1|-61.7|americas',
    'GT|Гватемала|Guatemala|14.6|-90.5|americas',
    'GN|Гвинея|Guinea|9.6|-13.7|africa',
    'GW|Гвинея-Бисау|Guinea-Bissau|11.9|-15.6|africa',
    'GY|Гайана|Guyana|6.8|-58.2|americas',
    'HT|Гаити|Haiti|18.5|-72.3|americas',
    'HN|Гондурас|Honduras|14.1|-87.2|americas',
    'HU|Венгрия|Hungary|47.5|19.0|europe',
    'IS|Исландия|Iceland|64.1|-21.9|europe',
    'IN|Индия|India|28.6|77.2|asia',
    'ID|Индонезия|Indonesia|-6.2|106.8|asia',
    'IR|Иран|Iran|35.7|51.4|asia',
    'IQ|Ирак|Iraq|33.3|44.4|asia',
    'IE|Ирландия|Ireland|53.3|-6.3|europe',
    'IL|Израиль|Israel|31.8|35.2|asia',
    'IT|Италия|Italy|41.9|12.5|europe',
    'JM|Ямайка|Jamaica|18.0|-76.8|americas',
    'JP|Япония|Japan|35.7|139.7|asia',
    'JO|Иордания|Jordan|31.9|35.9|asia',
    'KZ|Казахстан|Kazakhstan|51.2|71.4|asia',
    'KE|Кения|Kenya|-1.3|36.8|africa',
    'KI|Кирибати|Kiribati|1.4|173.0|oceania',
    'KP|КНДР|North Korea|39.0|125.8|asia',
    'KR|Южная Корея|South Korea|37.6|127.0|asia',
    'KW|Кувейт|Kuwait|29.4|48.0|asia',
    'KG|Киргизия|Kyrgyzstan|42.9|74.6|asia',
    'LA|Лаос|Laos|18.0|102.6|asia',
    'LV|Латвия|Latvia|56.9|24.1|europe',
    'LB|Ливан|Lebanon|33.9|35.5|asia',
    'LS|Лесото|Lesotho|-29.3|27.5|africa',
    'LR|Либерия|Liberia|6.3|-10.8|africa',
    'LY|Ливия|Libya|32.9|13.2|africa',
    'LI|Лихтенштейн|Liechtenstein|47.1|9.5|europe',
    'LT|Литва|Lithuania|54.7|25.3|europe',
    'LU|Люксембург|Luxembourg|49.6|6.1|europe',
    'MG|Мадагаскар|Madagascar|-18.9|47.5|africa',
    'MW|Малави|Malawi|-14.0|33.8|africa',
    'MY|Малайзия|Malaysia|3.1|101.7|asia',
    'MV|Мальдивы|Maldives|4.2|73.5|asia',
    'ML|Мали|Mali|12.6|-8.0|africa',
    'MT|Мальта|Malta|35.9|14.5|europe',
    'MH|Маршалловы Острова|Marshall Islands|7.1|171.4|oceania',
    'MR|Мавритания|Mauritania|18.1|-16.0|africa',
    'MU|Маврикий|Mauritius|-20.2|57.5|africa',
    'MX|Мексика|Mexico|19.4|-99.1|americas',
    'FM|Микронезия|Micronesia|6.9|158.2|oceania',
    'MD|Молдова|Moldova|47.0|28.9|europe',
    'MC|Монако|Monaco|43.7|7.4|europe',
    'MN|Монголия|Mongolia|47.9|106.9|asia',
    'ME|Черногория|Montenegro|42.4|19.3|europe',
    'MA|Марокко|Morocco|34.0|-6.8|africa',
    'MZ|Мозамбик|Mozambique|-26.0|32.6|africa',
    'MM|Мьянма|Myanmar|19.8|96.2|asia',
    'NA|Намибия|Namibia|-22.6|17.1|africa',
    'NR|Науру|Nauru|-0.5|166.9|oceania',
    'NP|Непал|Nepal|27.7|85.3|asia',
    'NL|Нидерланды|Netherlands|52.4|4.9|europe',
    'NZ|Новая Зеландия|New Zealand|-41.3|174.8|oceania',
    'NI|Никарагуа|Nicaragua|12.1|-86.3|americas',
    'NE|Нигер|Niger|13.5|2.1|africa',
    'NG|Нигерия|Nigeria|9.1|7.4|africa',
    'MK|Северная Македония|North Macedonia|42.0|21.4|europe',
    'NO|Норвегия|Norway|59.9|10.8|europe',
    'OM|Оман|Oman|23.6|58.6|asia',
    'PK|Пакистан|Pakistan|33.7|73.0|asia',
    'PW|Палау|Palau|7.5|134.6|oceania',
    'PA|Панама|Panama|9.0|-79.5|americas',
    'PG|Папуа — Новая Гвинея|Papua New Guinea|-9.4|147.2|oceania',
    'PY|Парагвай|Paraguay|-25.3|-57.6|americas',
    'PE|Перу|Peru|-12.0|-77.0|americas',
    'PH|Филиппины|Philippines|14.6|121.0|asia',
    'PL|Польша|Poland|52.2|21.0|europe',
    'PT|Португалия|Portugal|38.7|-9.1|europe',
    'QA|Катар|Qatar|25.3|51.5|asia',
    'RO|Румыния|Romania|44.4|26.1|europe',
    'RU|Россия|Russia|55.8|37.6|europe',
    'RW|Руанда|Rwanda|-1.9|30.1|africa',
    'KN|Сент-Китс и Невис|Saint Kitts and Nevis|17.3|-62.7|americas',
    'LC|Сент-Люсия|Saint Lucia|14.0|-61.0|americas',
    'VC|Сент-Винсент и Гренадины|Saint Vincent and the Grenadines|13.2|-61.2|americas',
    'WS|Самоа|Samoa|-13.8|-171.8|oceania',
    'SM|Сан-Марино|San Marino|43.9|12.4|europe',
    'ST|Сан-Томе и Принсипи|São Tomé and Príncipe|0.3|6.7|africa',
    'SA|Саудовская Аравия|Saudi Arabia|24.7|46.7|asia',
    'SN|Сенегал|Senegal|14.7|-17.5|africa',
    'RS|Сербия|Serbia|44.8|20.5|europe',
    'SC|Сейшелы|Seychelles|-4.6|55.5|africa',
    'SL|Сьерра-Леоне|Sierra Leone|8.5|-13.2|africa',
    'SG|Сингапур|Singapore|1.4|103.8|asia',
    'SK|Словакия|Slovakia|48.1|17.1|europe',
    'SI|Словения|Slovenia|46.1|14.5|europe',
    'SB|Соломоновы Острова|Solomon Islands|-9.4|160.0|oceania',
    'SO|Сомали|Somalia|2.0|45.3|africa',
    'ZA|ЮАР|South Africa|-25.7|28.2|africa',
    'SS|Южный Судан|South Sudan|4.9|31.6|africa',
    'ES|Испания|Spain|40.4|-3.7|europe',
    'LK|Шри-Ланка|Sri Lanka|6.9|79.9|asia',
    'SD|Судан|Sudan|15.6|32.5|africa',
    'SR|Суринам|Suriname|5.9|-55.2|americas',
    'SE|Швеция|Sweden|59.3|18.1|europe',
    'CH|Швейцария|Switzerland|46.9|7.4|europe',
    'SY|Сирия|Syria|33.5|36.3|asia',
    'TJ|Таджикистан|Tajikistan|38.6|68.8|asia',
    'TZ|Танзания|Tanzania|-6.2|35.7|africa',
    'TH|Таиланд|Thailand|13.8|100.5|asia',
    'TL|Восточный Тимор|Timor-Leste|-8.6|125.6|asia',
    'TG|Того|Togo|6.1|1.2|africa',
    'TO|Тонга|Tonga|-21.1|-175.2|oceania',
    'TT|Тринидад и Тобаго|Trinidad and Tobago|10.7|-61.5|americas',
    'TN|Тунис|Tunisia|36.8|10.2|africa',
    'TR|Турция|Türkiye|39.9|32.9|asia',
    'TM|Туркменистан|Turkmenistan|37.9|58.4|asia',
    'TV|Тувалу|Tuvalu|-8.5|179.2|oceania',
    'UG|Уганда|Uganda|0.3|32.6|africa',
    'UA|Украина|Ukraine|50.5|30.5|europe',
    'AE|ОАЭ|United Arab Emirates|24.5|54.4|asia',
    'GB|Великобритания|United Kingdom|51.5|-0.1|europe',
    'US|США|United States|38.9|-77.0|americas',
    'UY|Уругвай|Uruguay|-34.9|-56.2|americas',
    'UZ|Узбекистан|Uzbekistan|41.3|69.3|asia',
    'VU|Вануату|Vanuatu|-17.7|168.3|oceania',
    'VE|Венесуэла|Venezuela|10.5|-66.9|americas',
    'VN|Вьетнам|Vietnam|21.0|105.8|asia',
    'YE|Йемен|Yemen|15.4|44.2|asia',
    'ZM|Замбия|Zambia|-15.4|28.3|africa',
    'ZW|Зимбабве|Zimbabwe|-17.8|31.1|africa',
    'VA|Ватикан|Vatican City|41.9|12.5|europe',
    'PS|Палестина|Palestine|31.9|35.2|asia'
  ];

  /* Страны с каналом 10 Гбит/с. */
  var PREMIUM = {
    US: 1, DE: 1, NL: 1, GB: 1, FR: 1, JP: 1, SG: 1, CA: 1, SE: 1, CH: 1, AU: 1,
    ES: 1, IT: 1, PL: 1, FI: 1, KR: 1, AE: 1, BR: 1, IN: 1, AT: 1, NO: 1, CZ: 1
  };

  D.regions = ['europe', 'asia', 'americas', 'africa', 'oceania'];

  D.countries = RAW.map(function (line) {
    var p = line.split('|');
    var c = {
      code: p[0], ru: p[1], en: p[2],
      lat: parseFloat(p[3]), lon: parseFloat(p[4]),
      region: p[5], premium: !!PREMIUM[p[0]]
    };
    c.km = U.haversine(D.ORIGIN.lat, D.ORIGIN.lon, c.lat, c.lon);
    c.seed = U.hash32(c.code);
    /* базовый пинг: оптоволокно ~ 1 мс на 100 км в одну сторону плюс маршрутизация */
    c.basePing = Math.round(7 + c.km / 62 + (c.seed % 13));
    c.baseLoad = 14 + (c.seed >>> 5) % 71;
    return c;
  });

  D.byCode = {};
  D.countries.forEach(function (c) { D.byCode[c.code] = c; });

  D.count = D.countries.length;

  /* Счётчик обновлений: каждый «тик» пинг и нагрузка слегка меняются. */
  D.tick = 0;
  D.bump = function () { D.tick++; };

  /** Текущие показатели сервера. */
  D.metrics = function (code) {
    var c = D.byCode[code];
    if (!c) return { ping: 0, load: 0, jitter: 0, speed: 0 };
    var h = U.hash32(code + ':' + D.tick);
    var ping = Math.max(5, c.basePing + (h % 9) - 4);
    var load = U.clamp(c.baseLoad + ((h >>> 7) % 11) - 5, 4, 98);
    return {
      ping: ping,
      load: load,
      jitter: 1 + (h >>> 11) % 6,
      speed: c.premium ? 10 : 1
    };
  };

  /** Уровень сигнала 1..4 по пингу. */
  D.signal = function (ping) {
    return ping < 40 ? 4 : ping < 90 ? 3 : ping < 160 ? 2 : 1;
  };

  /** Название страны на текущем языке. */
  D.name = function (code, lang) {
    var c = D.byCode[code];
    return c ? c[lang === 'en' ? 'en' : 'ru'] : code;
  };

  /** Поиск: по названию на обоих языках и по коду. */
  D.matches = function (c, query) {
    var q = query.trim().toLowerCase().replace(/ё/g, 'е');
    if (!q) return true;
    if (c.code.toLowerCase() === q) return true;
    return c.ru.toLowerCase().replace(/ё/g, 'е').indexOf(q) >= 0 || c.en.toLowerCase().indexOf(q) >= 0;
  };

  /** Лучшие по пингу. */
  D.fastest = function (n) {
    return D.countries.slice().sort(function (a, b) {
      return D.metrics(a.code).ping - D.metrics(b.code).ping;
    }).slice(0, n);
  };

  /* ------------------------------------------------------------------
   * Каталог ошибок
   * stage: на каком шаге подключения возникает
   * sev: critical | warning | info
   * ------------------------------------------------------------------ */
  D.errors = [
    {
      code: 'ERROR_SMG_01', sev: 'critical', stage: 'handshake', action: 'countries',
      title: { ru: 'VPN не подключён к серверу', en: 'VPN is not connected to a server' },
      what: {
        ru: 'Приложение не смогло договориться с выбранным сервером. Защищённый туннель не создан, весь трафик идёт напрямую, без шифрования.',
        en: 'The app could not negotiate with the selected server. No secure tunnel was created, so all traffic goes out directly and unencrypted.'
      },
      fix: {
        ru: [
          'Проверь интернет: открой любой сайт без VPN.',
          'Выбери другую страну в разделе «Страны».',
          'В настройках поставь транспорт TCP.',
          'Если ошибка повторяется, запусти диагностику.'
        ],
        en: [
          'Check your internet: open any website without VPN.',
          'Pick another country in the Countries tab.',
          'Set the transport to TCP in Settings.',
          'If the error keeps coming back, run diagnostics.'
        ]
      }
    },
    {
      code: 'ERROR_SMG_02', sev: 'warning', stage: 'handshake', action: 'countries',
      title: { ru: 'Сервер перегружен', en: 'Server is overloaded' },
      what: {
        ru: 'На сервере сейчас слишком много подключений, и он не принимает новые.',
        en: 'The server has too many active connections right now and is not accepting new ones.'
      },
      fix: {
        ru: ['Выбери страну с меньшей нагрузкой, она показана в списке.', 'Подожди пару минут и повтори.'],
        en: ['Pick a country with a lower load, it is shown in the list.', 'Wait a couple of minutes and try again.']
      }
    },
    {
      code: 'ERROR_SMG_03', sev: 'warning', stage: 'handshake', action: 'settings',
      title: { ru: 'Сервер не отвечает', en: 'Server is not responding' },
      what: {
        ru: 'Сервер не ответил за отведённое время. Так бывает, когда пакеты теряются по дороге.',
        en: 'The server did not reply in time. This happens when packets get lost on the way.'
      },
      fix: {
        ru: ['Смени транспорт на TCP в настройках.', 'Выбери страну поближе к тебе.'],
        en: ['Switch the transport to TCP in Settings.', 'Pick a country closer to you.']
      }
    },
    {
      code: 'ERROR_AUT_04', sev: 'warning', stage: 'lookup', action: 'sub',
      title: { ru: 'Сессия устарела', en: 'Session expired' },
      what: {
        ru: 'Данные входа больше не действуют, нужно войти заново.',
        en: 'Your sign-in data is no longer valid, you need to sign in again.'
      },
      fix: {
        ru: ['Перезапусти приложение.', 'Если не помогло, проверь статус подписки.'],
        en: ['Restart the app.', 'If that does not help, check your subscription status.']
      }
    },
    {
      code: 'ERROR_SUB_05', sev: 'info', stage: 'lookup', action: 'sub',
      title: { ru: 'Подписка не активна', en: 'Subscription is not active' },
      what: {
        ru: 'Срок подписки закончился или она ещё не оформлена.',
        en: 'Your subscription has expired or has not been purchased yet.'
      },
      fix: {
        ru: ['Открой раздел «Подписка» и выбери план.', 'Если уже платил, нажми «Восстановить покупку».'],
        en: ['Open the Subscription tab and choose a plan.', 'If you already paid, tap “Restore purchase”.']
      }
    },
    {
      code: 'ERROR_NET_06', sev: 'critical', stage: 'lookup', action: 'diag',
      title: { ru: 'Нет подключения к интернету', en: 'No internet connection' },
      what: {
        ru: 'Устройство не видит сеть, поэтому до сервера не добраться.',
        en: 'The device cannot see the network, so the server is unreachable.'
      },
      fix: {
        ru: ['Включи Wi-Fi или мобильные данные.', 'Отключи режим полёта.'],
        en: ['Turn on Wi-Fi or mobile data.', 'Turn off airplane mode.']
      }
    },
    {
      code: 'ERROR_DNS_07', sev: 'warning', stage: 'lookup', action: 'settings',
      title: { ru: 'DNS не отвечает', en: 'DNS is not responding' },
      what: {
        ru: 'Не удалось получить адрес сервера по его имени.',
        en: 'The server address could not be resolved from its name.'
      },
      fix: {
        ru: ['В настройках выбери другой DNS, например Cloudflare.', 'Смени сеть: Wi-Fi на мобильные данные или наоборот.'],
        en: ['Choose another DNS in Settings, for example Cloudflare.', 'Switch networks: Wi-Fi to mobile data or back.']
      }
    },
    {
      code: 'ERROR_TLS_08', sev: 'warning', stage: 'handshake', action: 'diag',
      title: { ru: 'Сбой защищённого рукопожатия', en: 'Secure handshake failed' },
      what: {
        ru: 'Приложение и сервер не договорились о шифровании. Чаще всего виновата неверная дата на устройстве.',
        en: 'The app and the server could not agree on encryption. The most common cause is a wrong date on the device.'
      },
      fix: {
        ru: ['Проверь дату и время на устройстве.', 'Включи автоматическую настройку времени.'],
        en: ['Check the date and time on your device.', 'Turn on automatic time setting.']
      }
    },
    {
      code: 'ERROR_PRT_09', sev: 'warning', stage: 'handshake', action: 'settings',
      title: { ru: 'Порт заблокирован сетью', en: 'Port blocked by the network' },
      what: {
        ru: 'Провайдер или точка Wi-Fi закрыли порт, через который работает VPN.',
        en: 'Your provider or Wi-Fi hotspot has closed the port the VPN uses.'
      },
      fix: {
        ru: ['Поставь транспорт TCP: он идёт через порт 443.', 'Подключись через другую сеть.'],
        en: ['Set the transport to TCP: it uses port 443.', 'Connect through another network.']
      }
    },
    {
      code: 'ERROR_CFG_10', sev: 'info', stage: 'encrypt', action: 'settings',
      title: { ru: 'Повреждена конфигурация', en: 'Configuration is corrupted' },
      what: {
        ru: 'Файл настроек подключения не читается.',
        en: 'The connection settings file cannot be read.'
      },
      fix: {
        ru: ['В настройках нажми «Сбросить настройки».', 'Если не помогло, переустанови приложение.'],
        en: ['Tap “Reset settings” in Settings.', 'If that does not help, reinstall the app.']
      }
    },
    {
      code: 'ERROR_GEO_11', sev: 'info', stage: 'lookup', action: 'countries',
      title: { ru: 'Страна временно недоступна', en: 'Country temporarily unavailable' },
      what: {
        ru: 'Серверы в выбранной стране сейчас на обслуживании.',
        en: 'Servers in the selected country are under maintenance.'
      },
      fix: {
        ru: ['Выбери другую страну из списка.', 'Загляни сюда позже.'],
        en: ['Choose another country from the list.', 'Check back later.']
      }
    }
  ];

  D.errorByCode = {};
  D.errors.forEach(function (e) { D.errorByCode[e.code] = e; });

  /* ------------------------------------------------------------------
   * Тарифы
   * ------------------------------------------------------------------ */
  D.plans = [
    { id: 'm1', months: 1, price: 4.99, badge: null },
    { id: 'm3', months: 3, price: 12.99, badge: 'popular' },
    { id: 'm12', months: 12, price: 29.99, badge: 'best' }
  ];

  /* Строки сравнения Free и Орбита+ (значения: true / false / строка по языку). */
  D.compare = [
    { key: 'countries', free: { ru: '3 страны', en: '3 countries' }, plus: { ru: 'Все страны', en: 'All countries' } },
    { key: 'speed', free: { ru: 'До 5 Мбит/с', en: 'Up to 5 Mbps' }, plus: { ru: 'Без ограничений', en: 'Unlimited' } },
    { key: 'devices', free: { ru: '1', en: '1' }, plus: { ru: '5', en: '5' } },
    { key: 'killswitch', free: false, plus: true },
    { key: 'split', free: false, plus: true },
    { key: 'premium', free: false, plus: true },
    { key: 'support', free: false, plus: true }
  ];

  D.faq = [
    {
      q: { ru: 'Почему я не могу подключиться?', en: 'Why can I not connect?' },
      a: {
        ru: 'В этой версии подключение к серверам не настроено, поэтому приложение показывает ERROR_SMG_01. Подробности ищи в разделе «Ошибки».',
        en: 'Server connections are not set up in this version, so the app shows ERROR_SMG_01. Details are in the Errors tab.'
      }
    },
    {
      q: { ru: 'Сколько устройств можно подключить?', en: 'How many devices can I connect?' },
      a: {
        ru: 'До пяти устройств одновременно на одной подписке.',
        en: 'Up to five devices at once on a single subscription.'
      }
    },
    {
      q: { ru: 'Можно ли отменить подписку?', en: 'Can I cancel my subscription?' },
      a: {
        ru: 'Да, в любой момент. Доступ сохранится до конца оплаченного периода.',
        en: 'Yes, at any time. Access stays active until the end of the paid period.'
      }
    },
    {
      q: { ru: 'Вы храните историю посещений?', en: 'Do you keep browsing logs?' },
      a: {
        ru: 'Нет. Приложение хранит только журнал ошибок на этом устройстве, и ты можешь очистить его в любой момент.',
        en: 'No. The app only keeps an error log on this device, and you can clear it at any time.'
      }
    }
  ];

  /* Приложения для раздельного туннелирования (названия общие, без брендов). */
  D.apps = [
    { id: 'browser', ru: 'Браузер', en: 'Browser', glyph: 'B' },
    { id: 'chat', ru: 'Мессенджер', en: 'Messenger', glyph: 'M' },
    { id: 'video', ru: 'Видео', en: 'Video', glyph: 'V' },
    { id: 'music', ru: 'Музыка', en: 'Music', glyph: 'S' },
    { id: 'bank', ru: 'Банк', en: 'Banking', glyph: '₴' },
    { id: 'games', ru: 'Игры', en: 'Games', glyph: 'G' },
    { id: 'mail', ru: 'Почта', en: 'Mail', glyph: '@' },
    { id: 'maps', ru: 'Карты', en: 'Maps', glyph: 'N' }
  ];

  /* DNS-провайдеры (названия публичных сервисов). */
  D.dns = [
    { id: 'auto', ru: 'Авто', en: 'Auto', addr: '—' },
    { id: 'cloudflare', ru: 'Cloudflare', en: 'Cloudflare', addr: '1.1.1.1' },
    { id: 'google', ru: 'Google', en: 'Google', addr: '8.8.8.8' },
    { id: 'quad9', ru: 'Quad9', en: 'Quad9', addr: '9.9.9.9' }
  ];

  /* Акценты интерфейса: цвета лежат в CSS, здесь только порядок и подписи. */
  D.accents = [
    { id: 'amber', ru: 'Янтарь', en: 'Amber' },
    { id: 'cyan', ru: 'Лёд', en: 'Ice' },
    { id: 'violet', ru: 'Ультрафиолет', en: 'Ultraviolet' },
    { id: 'lime', ru: 'Хлорофилл', en: 'Chlorophyll' },
    { id: 'rose', ru: 'Зарево', en: 'Glow' }
  ];

  D.APP_VERSION = '0.2.0';
  D.BUILD = '2610';
})(window.O = window.O || {});
