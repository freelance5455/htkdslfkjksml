/* Орбита VPN: боковое меню. Открывается кнопкой в шапке. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data;
  var Dr = O.drawer = {};
  var layer = null;
  var handle = null;
  var prevFocus = null;
  var releaseTrap = null;

  function t(k, p) { return O.t(k, p); }

  var ITEMS = [
    { id: 'home', icon: 'shield' },
    { id: 'countries', icon: 'globe' },
    { id: 'sub', icon: 'crown' },
    { id: 'errors', icon: 'alert' },
    { id: 'settings', icon: 'sliders' },
    { id: 'diag', icon: 'stethoscope' }
  ];

  function build() {
    var st = S.get();
    var cur = O.router.current();
    var n = st.errors.length;
    var items = ITEMS.map(function (it) {
      var label = it.id === 'diag' ? t('drawer.diag') : t('nav.' + it.id);
      var cnt = it.id === 'errors' && n ? '<em class="count">' + n + '</em>' : '';
      return '<button class="mi" type="button" data-go="' + it.id + '"' + (cur === it.id ? ' aria-current="page"' : '') + '>' +
        O.icon(it.icon) + '<span>' + label + '</span>' + cnt + '</button>';
    }).join('');

    return '<div class="drawer-head">' +
      '<div class="brand-lg"><svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="17" fill="none" stroke="var(--line)" stroke-width="2"/>' +
      '<circle cx="20" cy="20" r="9" fill="var(--surface-2)" stroke="var(--accent)" stroke-width="2"/><circle cx="20" cy="3" r="4" fill="var(--accent)"/></svg>' +
      '<div><b>' + t('app.name') + '</b><span>' + t('drawer.tag') + '</span></div></div>' +
      '<button class="icon-btn sm" type="button" data-close aria-label="' + t('common.close') + '">' + O.icon('close') + '</button></div>' +
      '<div class="drawer-card"><span class="dc-ic">' + O.icon('devices') + '</span>' +
      '<span class="dc-t"><b>' + (O.auth && O.auth.user() ? '@' + U.esc(O.auth.user().nick) : t('drawer.guest')) + '</b><span class="mono">' + U.esc(st.deviceId) + '</span></span>' +
      (O.auth && O.auth.isAdmin() ? '<span class="tag ok">ADMIN</span>' : (O.auth && O.auth.subInfo().active ? '<span class="tag ok">' + t('app.plus') + '</span>' : '<span class="tag danger">' + t('sub.none') + '</span>')) + '</div>' +
      '<nav class="drawer-nav" aria-label="' + t('drawer.nav') + '">' + items + '</nav>' +
      '<div class="drawer-quick">' +
      '<div class="dq"><span>' + t('settings.lang') + '</span><div class="seg" data-q="lang">' +
      '<button type="button" data-v="ru" aria-pressed="' + (st.lang === 'ru') + '">RU</button>' +
      '<button type="button" data-v="en" aria-pressed="' + (st.lang === 'en') + '">EN</button></div></div>' +
      '<div class="dq"><span>' + t('settings.theme') + '</span><div class="seg" data-q="theme">' +
      ['system', 'dark', 'light'].map(function (v) {
        return '<button type="button" data-v="' + v + '" aria-pressed="' + (st.theme === v) + '" aria-label="' + t('settings.theme.' + v) + '">' +
          O.icon(v === 'system' ? 'devices' : v === 'dark' ? 'moon' : 'sun') + '</button>';
      }).join('') + '</div></div></div>' +
      '<p class="drawer-foot mono">' + t('app.name') + ' ' + D.APP_VERSION + ' (' + D.BUILD + ')</p>';
  }

  function render() {
    if (layer) U.$('.drawer-body', layer).innerHTML = build();
  }

  Dr.open = function () {
    if (layer) return;
    prevFocus = document.activeElement;
    layer = document.createElement('div');
    layer.className = 'layer drawer-layer';
    layer.innerHTML =
      '<div class="scrim" data-close></div>' +
      '<aside class="drawer" role="dialog" aria-modal="true" aria-label="' + t('drawer.nav') + '" tabindex="-1"><div class="drawer-body"></div></aside>';
    U.$('#overlay').appendChild(layer);
    render();

    var panel = U.$('.drawer', layer);
    releaseTrap = U.trapFocus(panel);
    handle = { close: Dr.close };
    O.ui.pushLayer(handle);

    U.delegate(layer, 'click', '[data-close]', Dr.close);
    U.delegate(layer, 'click', '[data-go]', function (b) {
      var id = b.getAttribute('data-go');
      Dr.close();
      if (id === 'diag') setTimeout(function () { O.diag.open(); }, 260);
      else O.router.go(id);
    });
    U.delegate(layer, 'click', '[data-q] button', function (b) {
      var key = b.parentNode.getAttribute('data-q');
      var p = {}; p[key] = b.getAttribute('data-v');
      S.set(p);
      render();
    });

    requestAnimationFrame(function () {
      layer.classList.add('open');
      panel.focus({ preventScroll: true });
    });
  };

  Dr.close = function () {
    if (!layer) return;
    var l = layer;
    layer = null;
    if (releaseTrap) releaseTrap();
    O.ui.popLayer(handle);
    l.classList.remove('open');
    setTimeout(function () { if (l.parentNode) l.parentNode.removeChild(l); }, 280);
    if (prevFocus && prevFocus.focus) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* фокус потерян */ } }
  };
})(window.O = window.O || {});
