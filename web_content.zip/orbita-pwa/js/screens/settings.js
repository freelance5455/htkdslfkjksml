/* Орбита VPN: экран «Настройки». */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data;
  var Scr = O.screens = O.screens || {};
  var St = Scr.settings = {};
  var root = null;

  function t(k, p) { return O.t(k, p); }
  function lang() { return S.get().lang; }

  /* ------------------------------------------------------------------
   * Строители разметки
   * ------------------------------------------------------------------ */
  function sw(key, icon, titleKey, descKey) {
    return '<label class="srow" for="set-' + key + '"><span class="srow-ic">' + O.icon(icon) + '</span>' +
      '<span class="srow-t"><b>' + t(titleKey) + '</b><span>' + t(descKey) + '</span></span>' +
      '<span class="sw"><input type="checkbox" id="set-' + key + '" data-setting="' + key + '"><u></u></span></label>';
  }

  function seg(key, kind, icon, titleKey, descKey, options) {
    return '<div class="srow col"><div class="srow-line"><span class="srow-ic">' + O.icon(icon) + '</span>' +
      '<span class="srow-t"><b>' + t(titleKey) + '</b>' + (descKey ? '<span>' + t(descKey) + '</span>' : '') + '</span></div>' +
      '<div class="seg wide" role="group" aria-label="' + t(titleKey) + '" data-seg="' + key + '" data-kind="' + kind + '">' +
      options.map(function (o) {
        return '<button type="button" data-v="' + o.v + '" aria-pressed="false">' + o.label + '</button>';
      }).join('') + '</div></div>';
  }

  function link(action, icon, titleKey, valueId, danger) {
    return '<button class="srow link' + (danger ? ' danger-text' : '') + '" type="button" data-action="' + action + '">' +
      '<span class="srow-ic">' + O.icon(icon) + '</span><span class="srow-t"><b>' + t(titleKey) + '</b></span>' +
      (valueId ? '<span class="srow-v" id="' + valueId + '"></span>' : '') + O.icon('chev', 'chev') + '</button>';
  }

  function build() {
    var accents = D.accents.map(function (a) {
      return '<button class="swatch" type="button" role="radio" aria-checked="false" data-accent="' + a.id + '" aria-label="' + a[lang()] + '" title="' + a[lang()] + '"><i></i></button>';
    }).join('');

    return '<div class="settings">' +
      '<header class="scr-head"><div class="scr-titles"><h1 class="scr-title">' + t('settings.title') + '</h1><p class="scr-sub">' + t('settings.sub') + '</p></div></header>' +

      (O.auth ? O.auth.settingsHtml() : '') +

      '<section class="blk"><h2 class="grp">' + t('settings.connection') + '</h2><div class="group">' +
      sw('autoConnect', 'power', 'settings.auto', 'settings.autoD') +
      sw('killSwitch', 'shield', 'settings.kill', 'settings.killD') +
      sw('lanBypass', 'wifi', 'settings.lan', 'settings.lanD') +
      seg('protocol', 'setting', 'route', 'settings.proto', 'settings.protoD', [
        { v: 'auto', label: t('proto.auto') }, { v: 'udp', label: 'UDP' }, { v: 'tcp', label: 'TCP' }]) +
      link('pick-dns', 'server', 'settings.dns', 'v-dns') +
      sw('split', 'apps', 'settings.split', 'settings.splitD') +
      link('pick-apps', 'apps', 'settings.splitApps', 'v-apps') +
      '</div></section>' +

      '<section class="blk"><h2 class="grp">' + t('settings.look') + '</h2><div class="group">' +
      seg('lang', 'root', 'language', 'settings.lang', '', [{ v: 'ru', label: 'Русский' }, { v: 'en', label: 'English' }]) +
      seg('theme', 'root', 'moon', 'settings.theme', '', [
        { v: 'system', label: t('settings.theme.system') }, { v: 'dark', label: t('settings.theme.dark') }, { v: 'light', label: t('settings.theme.light') }]) +
      '<div class="srow col"><div class="srow-line"><span class="srow-ic">' + O.icon('spark') + '</span>' +
      '<span class="srow-t"><b>' + t('settings.accent') + '</b><span id="v-accent"></span></span></div>' +
      '<div class="swatches" role="radiogroup" aria-label="' + t('settings.accent') + '">' + accents + '</div></div>' +
      sw('showPing', 'activity', 'settings.showPing', 'settings.showPingD') +
      sw('reduceMotion', 'bolt', 'settings.motion', 'settings.motionD') +
      '</div></section>' +

      '<section class="blk"><h2 class="grp">' + t('settings.notify') + '</h2><div class="group">' +
      sw('notifyErrors', 'bell', 'settings.notifyErr', 'settings.notifyErrD') +
      sw('haptics', 'activity', 'settings.haptics', 'settings.hapticsD') +
      '</div></section>' +

      (O.pwa ? O.pwa.settingsHtml() : '') +

      '<section class="blk"><h2 class="grp">' + t('settings.data') + '</h2><div class="group">' +
      link('diag', 'stethoscope', 'settings.diag') +
      link('clear-log', 'trash', 'settings.clearLog', 'v-log') +
      link('reset', 'refresh', 'settings.reset', '', true) +
      '</div></section>' +

      '<section class="blk"><h2 class="grp">' + t('settings.about') + '</h2><div class="group about">' +
      '<div class="kv"><span>' + t('settings.version') + '</span><b class="mono">' + D.APP_VERSION + ' (' + D.BUILD + ')</b></div>' +
      '<div class="kv"><span>' + t('settings.device') + '</span><button class="copy-inline mono" type="button" data-action="copy-id" id="v-device"></button></div>' +
      '<div class="kv"><span>' + t('settings.servers') + '</span><b class="mono">' + D.count + '</b></div>' +
      '<p class="about-note">' + t('settings.demoNote') + '</p>' +
      '</div></section>' +
      '</div>';
  }

  /* ------------------------------------------------------------------
   * Синхронизация значений без пересборки разметки
   * ------------------------------------------------------------------ */
  function sync() {
    var st = S.get(), s = st.settings;
    U.$$('[data-setting]', root).forEach(function (inp) {
      inp.checked = !!s[inp.getAttribute('data-setting')];
    });
    U.$$('[data-seg]', root).forEach(function (g) {
      var key = g.getAttribute('data-seg');
      var val = g.getAttribute('data-kind') === 'setting' ? s[key] : st[key];
      U.$$('button', g).forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-v') === val ? 'true' : 'false'); });
    });
    U.$$('.swatch', root).forEach(function (b) {
      var on = b.getAttribute('data-accent') === st.accent;
      b.setAttribute('aria-checked', on ? 'true' : 'false');
    });
    var acc = D.accents.filter(function (a) { return a.id === st.accent; })[0];
    var va = U.$('#v-accent', root); if (va) va.textContent = acc ? acc[lang()] : '';
    var dns = D.dns.filter(function (d) { return d.id === s.dns; })[0];
    var vd = U.$('#v-dns', root); if (vd) vd.textContent = dns ? dns[lang()] + (dns.addr !== '—' ? ' · ' + dns.addr : '') : '';
    var count = Object.keys(s.splitApps).filter(function (k) { return s.splitApps[k]; }).length;
    var vp = U.$('#v-apps', root); if (vp) vp.textContent = count ? t('settings.appsN', { n: count }) : t('settings.appsNone');
    var vl = U.$('#v-log', root); if (vl) vl.textContent = String(st.errors.length);
    if (O.pwa) O.pwa.paint();
    var dv = U.$('#v-device', root); if (dv) dv.textContent = st.deviceId;
    var splitOn = !!s.split;
    var appsRow = U.$('[data-action="pick-apps"]', root);
    if (appsRow) appsRow.classList.toggle('dim', !splitOn);
  }

  /* ------------------------------------------------------------------
   * Шторки выбора
   * ------------------------------------------------------------------ */
  function pickDns() {
    var cur = S.get().settings.dns, L = lang();
    var h = O.ui.sheet({
      title: t('settings.dns'),
      html: '<div class="radio-list" role="radiogroup">' + D.dns.map(function (d) {
        return '<button class="radio-row" type="button" role="radio" aria-checked="' + (d.id === cur) + '" data-id="' + d.id + '">' +
          '<span class="radio-dot"></span><span class="radio-t"><b>' + d[L] + '</b><span class="mono">' + (d.addr === '—' ? t('settings.dnsAuto') : d.addr) + '</span></span></button>';
      }).join('') + '</div>'
    });
    U.delegate(h.body, 'click', '.radio-row', function (b) {
      S.setSetting('dns', b.getAttribute('data-id'));
      h.close();
    });
  }

  function pickApps() {
    var L = lang();
    var h = O.ui.sheet({
      title: t('settings.splitApps'),
      html: '<p class="sheet-lead">' + t('settings.splitLead') + '</p><div class="group flat" id="app-list">' +
        D.apps.map(function (a) {
          var on = !!S.get().settings.splitApps[a.id];
          return '<label class="srow" for="app-' + a.id + '"><span class="app-glyph">' + U.esc(a.glyph) + '</span>' +
            '<span class="srow-t"><b>' + a[L] + '</b></span>' +
            '<span class="sw"><input type="checkbox" id="app-' + a.id + '" data-app="' + a.id + '"' + (on ? ' checked' : '') + '><u></u></span></label>';
        }).join('') + '</div>' +
        '<button class="btn block" type="button" data-close>' + t('common.done') + '</button>'
    });
    h.body.addEventListener('change', function (e) {
      var id = e.target.getAttribute('data-app');
      if (!id) return;
      var map = Object.assign({}, S.get().settings.splitApps);
      map[id] = e.target.checked;
      S.setSetting('splitApps', map);
      if (e.target.checked && !S.get().settings.split) S.setSetting('split', true);
    });
  }

  var actions = {
    'pick-dns': pickDns,
    'pick-apps': pickApps,
    diag: function () { O.diag.open(); },
    'copy-id': function () { O.ui.copy(S.get().deviceId, 'toast.idCopied'); },
    'clear-log': function () {
      O.ui.confirm({ title: t('errors.clearTitle'), text: t('errors.clearText'), ok: t('errors.clearOk'), danger: true }).then(function (yes) {
        if (!yes) return;
        S.clearErrors();
        O.connect.reset();
        O.ui.toast(t('toast.logCleared'), 'ok');
      });
    },
    reset: function () {
      O.ui.confirm({ title: t('settings.resetTitle'), text: t('settings.resetText'), ok: t('settings.resetOk'), danger: true }).then(function (yes) {
        if (!yes) return;
        S.resetSettings();
        O.ui.toast(t('toast.resetDone'), 'ok');
      });
    }
  };

  St.mount = function (node) {
    root = node;
    root.innerHTML = build();

    root.addEventListener('change', function (e) {
      var key = e.target.getAttribute('data-setting');
      if (key) S.setSetting(key, e.target.checked);
    });
    U.delegate(root, 'click', '[data-seg] button', function (b) {
      var g = b.parentNode;
      var key = g.getAttribute('data-seg'), v = b.getAttribute('data-v');
      if (g.getAttribute('data-kind') === 'setting') S.setSetting(key, v);
      else { var p = {}; p[key] = v; S.set(p); }
    });
    U.delegate(root, 'click', '.swatch', function (b) { S.set({ accent: b.getAttribute('data-accent') }); });
    U.delegate(root, 'click', '[data-action]', function (b) {
      var fn = actions[b.getAttribute('data-action')];
      if (fn) fn(b);
    });

    sync();
    S.on(function () { sync(); });
  };

  St.refresh = function () {
    if (!root) return;
    root.innerHTML = build();
    sync();
  };
})(window.O = window.O || {});
