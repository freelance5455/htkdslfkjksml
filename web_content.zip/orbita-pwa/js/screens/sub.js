/* Орбита VPN: экран «Подписка».
 * Тарифы, сравнение с бесплатным режимом, устройства, промокод и вопросы. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data;
  var Scr = O.screens = O.screens || {};
  var Sb = Scr.sub = {};
  var root = null, el = {};
  var chosen = 'm12';

  function t(k, p) { return O.t(k, p); }
  function lang() { return S.get().lang; }
  function money(v) { return '$' + v.toFixed(2); }
  function planById(id) { return D.plans.filter(function (p) { return p.id === id; })[0]; }

  var ART =
    '<svg class="sub-art" viewBox="0 0 160 160" aria-hidden="true">' +
    '<circle class="a-ring r3" cx="80" cy="80" r="72"/>' +
    '<circle class="a-ring r2" cx="80" cy="80" r="52"/>' +
    '<circle class="a-ring r1" cx="80" cy="80" r="32"/>' +
    '<circle class="a-core" cx="80" cy="80" r="12"/>' +
    '<g class="a-orbit o1"><circle class="a-sat" cx="80" cy="8" r="5"/></g>' +
    '<g class="a-orbit o2"><circle class="a-sat cool" cx="80" cy="28" r="3.5"/></g>' +
    '<g class="a-orbit o3"><circle class="a-sat dim" cx="80" cy="48" r="2.6"/></g>' +
    '</svg>';

  function osLabel() { return t('os.' + U.deviceInfo().os); }

  function renderPlans() {
    var base = D.plans[0].price;
    el.plans.innerHTML = D.plans.map(function (p) {
      var per = p.price / p.months;
      var save = Math.round((1 - per / base) * 100);
      var sel = p.id === chosen;
      return '<button class="plan" type="button" role="radio" aria-checked="' + sel + '" data-action="plan" data-id="' + p.id + '">' +
        '<span class="plan-radio" aria-hidden="true"></span>' +
        '<span class="plan-main"><b class="plan-name">' + O.tn('sub.months', p.months) + '</b>' +
        '<span class="plan-per mono">' + t('sub.perMonth', { price: money(per) }) + '</span></span>' +
        '<span class="plan-side">' +
        (p.badge ? '<em class="plan-badge" data-kind="' + p.badge + '">' + t('sub.badge.' + p.badge) + '</em>' : '') +
        '<b class="plan-price mono">' + money(p.price) + '</b>' +
        (save > 0 ? '<span class="plan-save">−' + save + '%</span>' : '') +
        '</span></button>';
    }).join('');
    var p = planById(chosen);
    el.cta.textContent = t('sub.cta', { price: money(p.price) });
  }

  function cell(v) {
    if (v === true) return '<span class="yes">' + O.icon('check') + '<span class="sr">' + t('common.yes') + '</span></span>';
    if (v === false) return '<span class="no">' + O.icon('x') + '<span class="sr">' + t('common.no') + '</span></span>';
    return '<span class="val">' + U.esc(v[lang()]) + '</span>';
  }

  function renderCompare() {
    var rows = D.compare.map(function (r) {
      return '<tr><th scope="row">' + t('sub.cmp.' + r.key) + '</th><td>' + cell(r.free) + '</td><td class="plus">' + cell(r.plus) + '</td></tr>';
    }).join('');
    el.compare.innerHTML =
      '<table class="cmp"><thead><tr><th scope="col"><span class="sr">' + t('sub.cmp.feature') + '</span></th>' +
      '<th scope="col">' + t('sub.free') + '</th><th scope="col" class="plus">' + t('app.plus') + '</th></tr></thead><tbody>' + rows + '</tbody></table>';
  }

  function renderDevices() {
    var st = S.get();
    var slots = '';
    for (var i = 0; i < 4; i++) {
      slots += '<li class="dev empty"><span class="dev-ic">' + O.icon('plus') + '</span><span class="dev-text"><b>' + t('sub.devFree') + '</b></span></li>';
    }
    el.devices.innerHTML =
      '<li class="dev here"><span class="dev-ic">' + O.icon('devices') + '</span>' +
      '<span class="dev-text"><b>' + osLabel() + '</b><span class="mono">' + U.esc(st.deviceId) + '</span></span>' +
      '<em class="tag-here">' + t('sub.thisDevice') + '</em></li>' + slots;
    el.devCount.textContent = t('sub.devCount', { n: 1, max: 5 });
  }

  function renderFaq() {
    var L = lang();
    el.faq.innerHTML = D.faq.map(function (f) {
      return '<details class="faq"><summary><span>' + U.esc(f.q[L]) + '</span>' + O.icon('chevd', 'faq-chev') + '</summary><p>' + U.esc(f.a[L]) + '</p></details>';
    }).join('');
  }

  var TEMPLATE =
    '<div class="sub">' +
    '<section class="sub-hero">' + ART +
    '<div class="sub-hero-text"><span class="tag danger" data-i18n="sub.inactive"></span>' +
    '<h1 class="scr-title" data-i18n="app.plus"></h1><p data-i18n="sub.lead"></p></div></section>' +

    '<section class="blk"><h2 class="grp" data-i18n="sub.choose"></h2>' +
    '<div class="plans" id="s-plans" role="radiogroup" data-i18n-aria="sub.choose"></div>' +
    '<button class="btn block" id="s-cta" type="button" data-action="buy"></button>' +
    '<button class="btn ghost block" type="button" data-action="restore" data-i18n="sub.restore"></button></section>' +

    '<section class="blk"><h2 class="grp" data-i18n="sub.compare"></h2>' +
    '<div class="table-wrap" id="s-compare"></div></section>' +

    '<section class="blk"><div class="grp-row"><h2 class="grp" data-i18n="sub.devices"></h2><span class="muted mono" id="s-devcount"></span></div>' +
    '<ul class="devs" id="s-devs"></ul></section>' +

    '<section class="blk"><h2 class="grp" data-i18n="sub.promo"></h2>' +
    '<form class="promo" id="s-promo" novalidate>' +
    '<input id="s-code" class="field mono" type="text" autocomplete="off" autocapitalize="characters" spellcheck="false" data-i18n-ph="sub.promoPh" data-i18n-aria="sub.promo">' +
    '<button class="btn ghost" type="submit" data-i18n="sub.apply"></button></form>' +
    '<p class="form-msg" id="s-msg" role="status" aria-live="polite"></p></section>' +

    '<section class="blk"><h2 class="grp" data-i18n="sub.faq"></h2><div class="faqs" id="s-faq"></div></section>' +
    '</div>';

  function openPayment() {
    var p = planById(chosen);
    O.ui.sheet({
      title: t('sub.payTitle'),
      className: 'info-sheet',
      html:
        '<div class="info-ic warn">' + O.icon('card') + '</div>' +
        '<p class="info-text">' + t('sub.payText', { plan: O.tn('sub.months', p.months), price: money(p.price) }) + '</p>' +
        '<button class="btn block" type="button" data-close data-autofocus>' + t('common.ok') + '</button>'
    });
  }

  Sb.mount = function (node) {
    root = node;
    root.innerHTML = TEMPLATE;
    O.i18n.apply(root);
    el = {
      plans: U.$('#s-plans', root), cta: U.$('#s-cta', root), compare: U.$('#s-compare', root),
      devices: U.$('#s-devs', root), devCount: U.$('#s-devcount', root), faq: U.$('#s-faq', root),
      form: U.$('#s-promo', root), code: U.$('#s-code', root), msg: U.$('#s-msg', root)
    };
    renderPlans(); renderCompare(); renderDevices(); renderFaq();

    U.delegate(root, 'click', '[data-action]', function (b) {
      var a = b.getAttribute('data-action');
      if (a === 'plan') { chosen = b.getAttribute('data-id'); renderPlans(); }
      else if (a === 'buy') openPayment();
      else if (a === 'restore') O.ui.toast(t('sub.restoreNone'), 'info');
    });

    el.form.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = el.code.value.trim();
      el.msg.className = 'form-msg err';
      el.msg.textContent = v ? t('sub.promoBad') : t('sub.promoEmpty');
      el.code.classList.remove('shake');
      void el.code.offsetWidth;
      el.code.classList.add('shake');
      O.ui.haptic(30);
    });
  };

  Sb.refresh = function () {
    if (!root) return;
    O.i18n.apply(root);
    renderPlans(); renderCompare(); renderDevices(); renderFaq();
    if (el.msg.textContent) el.msg.textContent = '';
  };
})(window.O = window.O || {});
