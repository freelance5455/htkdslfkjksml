/* Орбита VPN: экран «Ошибки».
 * Последняя ошибка, журнал попыток и справочник кодов с советами. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data, C = O.connect;
  var Scr = O.screens = O.screens || {};
  var Er = Scr.errors = {};
  var root = null, el = {};
  var ui = { tab: 'log', q: '', open: '' };

  function t(k, p) { return O.t(k, p); }
  function lang() { return S.get().lang; }

  /** «5 мин назад», «только что». */
  function rel(ts) {
    var d = Math.max(0, Math.round((Date.now() - ts) / 1000));
    if (d < 10) return t('time.now');
    if (d < 60) return t('time.s', { n: d });
    if (d < 3600) return t('time.min', { n: Math.floor(d / 60) });
    if (d < 86400) return t('time.hour', { n: Math.floor(d / 3600) });
    return U.fmtDate(ts, lang());
  }

  /* ------------------------------------------------------------------
   * Текстовый отчёт: его можно отправить в поддержку
   * ------------------------------------------------------------------ */
  O.errorReport = function (extra) {
    var st = S.get(), L = lang();
    var c = D.byCode[st.country];
    var lines = [];
    lines.push('Orbita VPN ' + D.APP_VERSION + ' (' + D.BUILD + ')');
    lines.push('Device: ' + st.deviceId + ' / ' + U.deviceInfo().os);
    lines.push('Time: ' + new Date().toISOString());
    lines.push('Server: ' + c.code + ' ' + c.en + ', ' + D.metrics(c.code).ping + ' ms');
    lines.push('Transport: ' + st.settings.protocol + ', DNS: ' + st.settings.dns + ', kill switch: ' + (st.settings.killSwitch ? 'on' : 'off'));
    lines.push('Online: ' + (navigator.onLine ? 'yes' : 'no'));
    if (extra && extra.length) {
      lines.push('');
      lines.push('Checks:');
      extra.forEach(function (x) { lines.push('  [' + x.status.toUpperCase() + '] ' + x.name + (x.note ? ': ' + x.note : '')); });
    }
    lines.push('');
    lines.push('Last errors:');
    if (!st.errors.length) lines.push('  none');
    st.errors.slice(0, 5).forEach(function (e) {
      lines.push('  ' + new Date(e.ts).toISOString() + ' ' + e.code + ' step=' + e.step + ' server=' + e.country + ' transport=' + e.protocol + ' attempt=' + e.attempt);
    });
    return lines.join('\n');
  };

  /* ------------------------------------------------------------------
   * Шапка: последняя ошибка или «всё чисто»
   * ------------------------------------------------------------------ */
  function renderHero() {
    var st = S.get(), L = lang();
    var e = st.errors[0];
    if (!e) {
      el.hero.innerHTML =
        '<div class="err-hero ok"><span class="hero-ic">' + O.icon('shield') + '</span>' +
        '<div class="hero-text"><b>' + t('errors.noneTitle') + '</b><p>' + t('errors.noneText') + '</p></div></div>';
      return;
    }
    var def = D.errorByCode[e.code] || D.errors[0];
    var c = D.byCode[e.country];
    el.hero.innerHTML =
      '<div class="err-hero bad">' +
      '<div class="hero-top"><span class="hero-ic">' + O.icon('alert') + '</span>' +
      '<div class="hero-text"><span class="hero-code mono">' + def.code + '</span><b>' + U.esc(def.title[L]) + '</b></div></div>' +
      '<p class="hero-meta">' + O.ui.flag(e.country) + '<span>' + U.esc(c ? c[L] : e.country) + '</span><i></i><span>' +
      U.fmtClock(e.ts, L) + '</span><i></i><span>' + rel(e.ts) + '</span></p>' +
      '<div class="hero-actions">' +
      '<button class="btn sm" type="button" data-action="explain" data-code="' + def.code + '">' + t('errors.whatToDo') + '</button>' +
      '<button class="btn ghost sm" type="button" data-action="retry">' + t('home.retry') + '</button></div>' +
      '</div>';
  }

  /* ------------------------------------------------------------------
   * Журнал
   * ------------------------------------------------------------------ */
  function renderLog() {
    var st = S.get(), L = lang();
    if (!st.errors.length) {
      return '<div class="empty">' + O.icon('check', 'empty-ic') + '<b>' + t('errors.logEmptyTitle') + '</b><p>' + t('errors.logEmptyText') + '</p></div>';
    }
    var rows = st.errors.map(function (e) {
      var def = D.errorByCode[e.code] || D.errors[0];
      var c = D.byCode[e.country];
      return '<li class="log-row" data-sev="' + def.sev + '">' +
        '<div class="log-main"><span class="log-code mono">' + e.code + '</span>' +
        '<span class="log-title">' + U.esc(def.title[L]) + '</span>' +
        '<span class="log-meta">' + O.ui.flag(e.country) + '<span>' + U.esc(c ? c[L] : e.country) + '</span><i></i>' +
        '<span>' + t('step.' + e.step) + '</span><i></i><span>' + t('proto.' + e.protocol) + '</span></span></div>' +
        '<div class="log-side"><span class="log-time mono">' + U.fmtClock(e.ts, L) + '</span>' +
        '<span class="log-att">' + t('home.attempt', { n: e.attempt }) + '</span>' +
        '<button class="icon-btn xs" type="button" data-action="copy-row" data-id="' + e.id + '" aria-label="' + t('errors.copyRow') + '">' + O.icon('copy') + '</button></div>' +
        '</li>';
    }).join('');
    return '<ul class="log">' + rows + '</ul>' +
      '<button class="btn ghost block danger-text" type="button" data-action="clear-log">' + O.icon('trash') + '<span>' + t('errors.clear') + '</span></button>';
  }

  /* ------------------------------------------------------------------
   * Справочник
   * ------------------------------------------------------------------ */
  var ACTION_ICON = { countries: 'globe', settings: 'sliders', sub: 'card', diag: 'stethoscope' };

  function renderCatalog() {
    var L = lang();
    var q = ui.q.trim().toLowerCase();
    var list = D.errors.filter(function (e) {
      if (!q) return true;
      return e.code.toLowerCase().indexOf(q) >= 0 || e.title[L].toLowerCase().indexOf(q) >= 0 || e.what[L].toLowerCase().indexOf(q) >= 0;
    });
    var html = '<div class="search-wrap">' + O.icon('search', 'search-ic') +
      '<input id="e-q" class="search" type="search" autocomplete="off" spellcheck="false" value="' + U.esc(ui.q) + '" placeholder="' + t('errors.search') + '" aria-label="' + t('errors.search') + '"></div>';
    if (!list.length) {
      return html + '<div class="empty">' + O.icon('search', 'empty-ic') + '<b>' + t('errors.emptyTitle') + '</b><p>' + t('errors.emptyText') + '</p></div>';
    }
    html += '<div class="catalog">' + list.map(function (e) {
      var steps = e.fix[L].map(function (s) { return '<li>' + U.esc(s) + '</li>'; }).join('');
      return '<details class="err-item" data-code="' + e.code + '" data-sev="' + e.sev + '"' + (ui.open === e.code ? ' open' : '') + '>' +
        '<summary><span class="sev-bar"></span><span class="err-sum"><span class="err-code mono">' + e.code + '</span>' +
        '<span class="err-title">' + U.esc(e.title[L]) + '</span></span>' +
        '<span class="sev-badge">' + t('errors.sev.' + e.sev) + '</span>' + O.icon('chevd', 'faq-chev') + '</summary>' +
        '<div class="err-body"><h3>' + t('errors.what') + '</h3><p>' + U.esc(e.what[L]) + '</p>' +
        '<h3>' + t('errors.how') + '</h3><ol>' + steps + '</ol>' +
        '<div class="err-actions"><button class="btn sm" type="button" data-action="goto" data-to="' + e.action + '">' +
        O.icon(ACTION_ICON[e.action] || 'chev') + '<span>' + t('errors.act.' + e.action) + '</span></button>' +
        '<button class="btn ghost sm" type="button" data-action="copy-code" data-code="' + e.code + '">' + O.icon('copy') + '<span>' + t('errors.copyCode') + '</span></button></div>' +
        '</div></details>';
    }).join('') + '</div>';
    return html;
  }

  function renderPanel() {
    var keepQ = ui.tab === 'catalog' && document.activeElement && document.activeElement.id === 'e-q';
    el.panel.innerHTML = ui.tab === 'log' ? renderLog() : renderCatalog();
    if (ui.tab === 'catalog') {
      var inp = U.$('#e-q', el.panel);
      if (inp) {
        inp.addEventListener('input', U.debounce(function () {
          ui.q = inp.value;
          renderPanel();
          var again = U.$('#e-q', el.panel);
          if (again) { again.focus(); again.setSelectionRange(again.value.length, again.value.length); }
        }, 120));
        if (keepQ) inp.focus();
      }
    }
  }

  function renderTabs() {
    var n = S.get().errors.length;
    el.tabs.innerHTML =
      '<button type="button" role="tab" data-action="tab" data-tab="log" aria-selected="' + (ui.tab === 'log') + '">' +
      t('errors.tab.log') + (n ? '<em class="count">' + n + '</em>' : '') + '</button>' +
      '<button type="button" role="tab" data-action="tab" data-tab="catalog" aria-selected="' + (ui.tab === 'catalog') + '">' +
      t('errors.tab.catalog') + '</button>';
  }

  function renderAll() {
    var n = S.get().errors.length;
    el.sub.textContent = n ? O.tn('errors.count', n) : t('errors.subNone');
    renderHero();
    renderTabs();
    renderPanel();
  }

  /* ------------------------------------------------------------------ */

  function go(to) {
    if (to === 'diag') O.diag.open();
    else O.router.go(to);
  }

  var actions = {
    tab: function (b) { ui.tab = b.getAttribute('data-tab'); renderTabs(); renderPanel(); },
    explain: function (b) { Er.focusCode(b.getAttribute('data-code')); },
    retry: function () { O.router.go('home'); setTimeout(function () { O.connect.start(); }, 250); },
    goto: function (b) { go(b.getAttribute('data-to')); },
    'copy-code': function (b) { O.ui.copy(b.getAttribute('data-code'), 'toast.codeCopied'); },
    'copy-row': function (b) {
      var id = parseInt(b.getAttribute('data-id'), 10);
      var e = S.get().errors.filter(function (x) { return x.id === id; })[0];
      if (!e) return;
      O.ui.copy(e.code + ' · ' + new Date(e.ts).toISOString() + ' · ' + e.country + ' · ' + e.step + ' · ' + e.protocol);
    },
    'clear-log': function () {
      O.ui.confirm({ title: t('errors.clearTitle'), text: t('errors.clearText'), ok: t('errors.clearOk'), danger: true }).then(function (yes) {
        if (!yes) return;
        S.clearErrors();
        O.connect.reset();
        O.ui.toast(t('toast.logCleared'), 'ok');
      });
    },
    diag: function () { O.diag.open(); },
    report: function () { O.ui.copy(O.errorReport(), 'toast.reportCopied'); }
  };

  /** Открывает справочник на нужном коде. */
  Er.focusCode = function (code) {
    ui.tab = 'catalog';
    ui.q = '';
    ui.open = code;
    renderTabs();
    renderPanel();
    setTimeout(function () {
      var node = U.$('.err-item[data-code="' + code + '"]', el.panel);
      if (node && node.scrollIntoView) node.scrollIntoView({ block: 'center', behavior: O.store.reducedMotion() ? 'auto' : 'smooth' });
    }, 60);
  };

  Er.mount = function (node) {
    root = node;
    root.innerHTML =
      '<div class="errors">' +
      '<header class="scr-head"><div class="scr-titles"><h1 class="scr-title" data-i18n="errors.title"></h1><p class="scr-sub" id="e-sub"></p></div></header>' +
      '<div id="e-hero"></div>' +
      '<div class="pair">' +
      '<button class="btn" type="button" data-action="diag">' + O.icon('stethoscope') + '<span data-i18n="errors.diag"></span></button>' +
      '<button class="btn ghost" type="button" data-action="report">' + O.icon('copy') + '<span data-i18n="errors.report"></span></button></div>' +
      '<div class="tabs" id="e-tabs" role="tablist"></div>' +
      '<div id="e-panel"></div></div>';
    O.i18n.apply(root);
    el = { sub: U.$('#e-sub', root), hero: U.$('#e-hero', root), tabs: U.$('#e-tabs', root), panel: U.$('#e-panel', root) };
    renderAll();

    U.delegate(root, 'click', '[data-action]', function (b) {
      var fn = actions[b.getAttribute('data-action')];
      if (fn) fn(b);
    });
    S.on(function (ev) {
      if (ev.keys.indexOf('errors') >= 0 || ev.keys.indexOf('lang') >= 0) renderAll();
    });
  };

  Er.refresh = function () {
    if (!root) return;
    O.i18n.apply(root);
    renderAll();
  };

  Er.show = function (params) {
    if (params && params.code) Er.focusCode(params.code);
    else renderHero();
  };
})(window.O = window.O || {});
