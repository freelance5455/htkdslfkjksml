/* Орбита VPN: экран «Страны».
 * Поиск, фильтр по регионам и избранному, сортировка, обновление пинга. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data;
  var Scr = O.screens = O.screens || {};
  var Ct = Scr.countries = {};
  var root = null, el = {};
  var ui = { q: '', filter: 'all', sort: 'ping' };
  var timer = 0;

  function t(k, p) { return O.t(k, p); }
  function lang() { return S.get().lang; }

  var FILTERS = ['all', 'fav'].concat(D.regions);

  var TEMPLATE =
    '<div class="countries">' +
    '<header class="scr-head">' +
    '<div class="scr-titles"><h1 class="scr-title" data-i18n="countries.title"></h1><p class="scr-sub" id="c-sub"></p></div>' +
    '<button class="icon-btn" id="c-refresh" type="button" data-action="refresh" data-i18n-aria="countries.refresh">' + O.icon('refresh') + '</button>' +
    '</header>' +

    '<button class="auto-card" type="button" data-action="auto">' +
    '<span class="auto-ic">' + O.icon('bolt') + '</span>' +
    '<span class="auto-text"><b data-i18n="countries.autoTitle"></b><span data-i18n="countries.autoText"></span></span>' +
    O.icon('chev', 'chev') +
    '</button>' +

    '<div class="search-wrap">' + O.icon('search', 'search-ic') +
    '<input id="c-q" class="search" type="search" autocomplete="off" autocapitalize="off" spellcheck="false" data-i18n-ph="countries.search" data-i18n-aria="countries.search">' +
    '<button class="search-clear" id="c-clear" type="button" data-action="clear" hidden data-i18n-aria="countries.clear">' + O.icon('x') + '</button>' +
    '</div>' +

    '<div class="chips scroll-x" id="c-chips" role="group" data-i18n-aria="countries.filterAria"></div>' +

    '<div class="sort-row"><span class="sort-label" data-i18n="countries.sortBy"></span>' +
    '<div class="seg" id="c-sort" role="group" data-i18n-aria="countries.sortBy"></div></div>' +

    '<div id="c-list" class="c-list"></div>' +
    '</div>';

  /* ------------------------------------------------------------------ */

  function filtered() {
    var L = lang();
    var arr = D.countries.filter(function (c) {
      if (!D.matches(c, ui.q)) return false;
      if (ui.filter === 'all') return true;
      if (ui.filter === 'fav') return S.isFavorite(c.code);
      return c.region === ui.filter;
    });
    var m = {};
    arr.forEach(function (c) { m[c.code] = D.metrics(c.code); });
    arr.sort(function (a, b) {
      if (ui.sort === 'ping') return m[a.code].ping - m[b.code].ping;
      if (ui.sort === 'load') return m[a.code].load - m[b.code].load;
      return a[L].localeCompare(b[L], L);
    });
    return { list: arr, m: m };
  }

  function loadLevel(load) { return load < 50 ? 'low' : load < 80 ? 'mid' : 'high'; }

  function row(c, m) {
    var sel = c.code === S.get().country;
    var fav = S.isFavorite(c.code);
    var L = lang();
    return '<div class="c-row' + (sel ? ' sel' : '') + '" data-code="' + c.code + '">' +
      '<button class="c-main" type="button" data-action="pick" data-code="' + c.code + '" aria-pressed="' + sel + '">' +
      O.ui.flag(c.code, 'lg') +
      '<span class="c-text"><span class="c-name">' + U.esc(c[L]) + '</span>' +
      '<span class="c-sub">' + (c.premium ? '<em class="tag-prem">' + t('countries.premium') + '</em>' : '') +
      '<span>' + t('region.' + c.region) + '</span></span></span>' +
      '<span class="c-metrics">' +
      '<span class="c-ping mono" data-ping>' + m.ping + ' ' + t('unit.ms') + '</span>' +
      '<span data-sig>' + O.ui.signal(m.ping) + '</span>' +
      '<span class="c-load" data-loadwrap data-level="' + loadLevel(m.load) + '" title="' + t('home.load', { n: m.load }) + '"><i data-load style="width:' + m.load + '%"></i></span>' +
      '</span>' +
      '</button>' +
      '<button class="c-fav" type="button" data-action="fav" data-code="' + c.code + '" aria-pressed="' + fav + '" aria-label="' +
      t(fav ? 'countries.unfav' : 'countries.fav', { name: c[L] }) + '">' + O.icon(fav ? 'starfill' : 'star') + '</button>' +
      '</div>';
  }

  function emptyState() {
    if (ui.filter === 'fav' && !ui.q) {
      return '<div class="empty">' + O.icon('star', 'empty-ic') + '<b>' + t('countries.emptyFavTitle') + '</b><p>' + t('countries.emptyFavText') + '</p></div>';
    }
    return '<div class="empty">' + O.icon('search', 'empty-ic') + '<b>' + t('countries.emptyTitle') + '</b><p>' + t('countries.emptyText') + '</p></div>';
  }

  function renderList() {
    var r = filtered();
    var html = '';
    el.sub.textContent = O.tn('countries.count', r.list.length);

    if (!r.list.length) {
      el.list.innerHTML = emptyState();
      return;
    }

    if (ui.filter === 'all' && !ui.q) {
      var top = D.fastest(3);
      html += '<h2 class="grp">' + t('countries.recommended') + '</h2><div class="card-list">';
      top.forEach(function (c) { html += row(c, D.metrics(c.code)); });
      html += '</div><h2 class="grp">' + t('countries.all') + '</h2>';
    }

    if (ui.sort === 'name') {
      var letter = '', open = false;
      r.list.forEach(function (c) {
        var l = c[lang()].charAt(0).toUpperCase();
        if (l !== letter) {
          if (open) html += '</div>';
          letter = l;
          html += '<h3 class="letter">' + U.esc(l) + '</h3><div class="card-list">';
          open = true;
        }
        html += row(c, r.m[c.code]);
      });
      if (open) html += '</div>';
    } else {
      html += '<div class="card-list">';
      r.list.forEach(function (c) { html += row(c, r.m[c.code]); });
      html += '</div>';
    }
    el.list.innerHTML = html;
  }

  function renderChips() {
    el.chips.innerHTML = FILTERS.map(function (f) {
      var label = f === 'all' ? t('countries.f.all') : f === 'fav' ? t('countries.f.fav') : t('region.' + f);
      return '<button class="chip" type="button" data-action="filter" data-f="' + f + '" aria-pressed="' + (ui.filter === f) + '">' + label + '</button>';
    }).join('');
    var sorts = ['ping', 'name', 'load'];
    el.sort.innerHTML = sorts.map(function (s) {
      return '<button type="button" data-action="sort" data-s="' + s + '" aria-pressed="' + (ui.sort === s) + '">' + t('countries.s.' + s) + '</button>';
    }).join('');
  }

  /** Обновляет только цифры, не пересобирая список. */
  function updateMetrics() {
    U.$$('.c-row[data-code]', el.list).forEach(function (row) {
      var code = row.getAttribute('data-code');
      var m = D.metrics(code);
      var p = U.$('[data-ping]', row);
      if (p) p.textContent = m.ping + ' ' + t('unit.ms');
      var s = U.$('[data-sig]', row);
      if (s) s.innerHTML = O.ui.signal(m.ping);
      var lw = U.$('[data-loadwrap]', row);
      if (lw) lw.setAttribute('data-level', loadLevel(m.load));
      var li = U.$('[data-load]', row);
      if (li) li.style.width = m.load + '%';
    });
  }

  /* ------------------------------------------------------------------ */

  var actions = {
    pick: function (b) {
      var code = b.getAttribute('data-code');
      S.selectCountry(code);
      O.ui.toast(t('toast.picked', { name: D.name(code, lang()) }), 'ok');
      O.router.go('home');
    },
    fav: function (b) {
      var code = b.getAttribute('data-code');
      var added = S.toggleFavorite(code);
      O.ui.toast(t(added ? 'toast.favAdded' : 'toast.favRemoved', { name: D.name(code, lang()) }), 'info', 1800);
    },
    filter: function (b) { ui.filter = b.getAttribute('data-f'); renderChips(); renderList(); },
    sort: function (b) { ui.sort = b.getAttribute('data-s'); renderChips(); renderList(); },
    clear: function () {
      el.q.value = ''; ui.q = ''; el.clear.hidden = true; renderList(); el.q.focus();
    },
    auto: function () {
      var best = D.fastest(1)[0];
      S.selectCountry(best.code);
      O.ui.toast(t('toast.autoPicked', { name: best[lang()], ms: D.metrics(best.code).ping }), 'ok');
      O.router.go('home');
    },
    refresh: function () {
      el.refresh.classList.add('spin-once');
      setTimeout(function () { el.refresh.classList.remove('spin-once'); }, 700);
      D.bump();
      renderList();
      O.ui.toast(t('toast.pingUpdated'), 'info', 1600);
    }
  };

  Ct.mount = function (node) {
    root = node;
    root.innerHTML = TEMPLATE;
    O.i18n.apply(root);
    el = {
      sub: U.$('#c-sub', root), q: U.$('#c-q', root), clear: U.$('#c-clear', root),
      chips: U.$('#c-chips', root), sort: U.$('#c-sort', root), list: U.$('#c-list', root),
      refresh: U.$('#c-refresh', root)
    };
    renderChips();
    renderList();

    U.delegate(root, 'click', '[data-action]', function (b) {
      var fn = actions[b.getAttribute('data-action')];
      if (fn) fn(b);
    });
    el.q.addEventListener('input', U.debounce(function () {
      ui.q = el.q.value;
      el.clear.hidden = !el.q.value;
      renderList();
    }, 80));

    S.on(function (ev) {
      var k = ev.keys.join(',');
      if (/country|favorites|lang/.test(k)) {
        if (/lang/.test(k)) renderChips();
        renderList();
      }
    });
  };

  Ct.refresh = function () {
    if (!root) return;
    O.i18n.apply(root);
    renderChips();
    renderList();
  };

  Ct.show = function () {
    clearInterval(timer);
    timer = setInterval(function () { D.bump(); updateMetrics(); }, 6000);
  };

  Ct.hide = function () { clearInterval(timer); };
})(window.O = window.O || {});
