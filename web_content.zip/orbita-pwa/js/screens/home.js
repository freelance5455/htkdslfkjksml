/* Орбита VPN: главный экран.
 * Глобус, кнопка-орбита, шаги подключения, карточка сервера и показатели. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data, C = O.connect;
  var Scr = O.screens = O.screens || {};
  var H = Scr.home = {};
  var el = {};
  var lastCountry = '';
  var pingTimer = 0;
  var ringRaf = 0;
  var root = null;
  var tipCode = '';

  function t(k, p) { return O.t(k, p); }

  var TEMPLATE =
    '<div class="home">' +
    '<div class="home-top">' +
    '<div class="status-pill" id="h-pill" data-state="idle"><span class="status-dot"></span><span id="h-status"></span></div>' +
    '<div class="ip-chip"><span class="ip-label" data-i18n="home.ip"></span><span class="ip-val mono" id="h-ip"></span>' +
    '<span class="ip-open" id="h-ipstate"></span></div>' +
    '</div>' +

    '<div class="globe-card">' +
    '<div class="globe-stage">' +
    '<canvas id="h-globe" class="globe-canvas" role="img" data-i18n-aria="home.globeAria"></canvas>' +
    '<div class="globe-tip" id="h-tip" hidden role="dialog">' +
    '<div class="tip-head" id="h-tiphead"></div>' +
    '<div class="tip-meta mono" id="h-tipmeta"></div>' +
    '<button class="btn xs" type="button" data-action="tip-pick" data-i18n="home.tipPick"></button>' +
    '</div>' +
    '</div>' +
    '<div class="globe-foot">' +
    '<span class="lg lg-you"><i></i><span data-i18n="home.you"></span></span>' +
    '<span class="lg-route" id="h-route"></span>' +
    '</div>' +
    '</div>' +

    '<div class="orb-zone">' +
    '<button class="orb" id="h-orb" type="button" data-state="idle" data-action="orb">' +
    '<span class="orb-ripple r1"></span><span class="orb-ripple r2"></span>' +
    '<svg class="orb-svg" viewBox="0 0 220 220" aria-hidden="true">' +
    '<circle class="orb-track" cx="110" cy="110" r="100"/>' +
    '<circle class="orb-prog" id="h-prog" cx="110" cy="110" r="100" pathLength="100"/>' +
    '<g class="orb-sat s1"><circle cx="110" cy="8" r="4"/></g>' +
    '<g class="orb-sat s2"><circle cx="110" cy="24" r="2.6"/></g>' +
    '</svg>' +
    '<span class="orb-core"><span class="orb-icon" id="h-orbicon"></span></span>' +
    '</button>' +
    '<div class="orb-label" id="h-orblabel"></div>' +
    '<p class="orb-hint" id="h-hint"></p>' +
    '</div>' +

    '<ol class="steps" id="h-steps" hidden></ol>' +

    '<div class="alert-card" id="h-alert" role="alert" hidden>' +
    '<div class="alert-top">' +
    '<span class="alert-icon">' + O.icon('alert') + '</span>' +
    '<div class="alert-id"><div class="alert-code mono" id="h-acode"></div><div class="alert-title" id="h-atitle"></div></div>' +
    '<span class="attempt" id="h-attempt"></span>' +
    '</div>' +
    '<p class="alert-text" id="h-atext"></p>' +
    '<div class="alert-actions">' +
    '<button class="btn sm" type="button" data-action="retry" data-i18n="home.retry"></button>' +
    '<button class="btn ghost sm" type="button" data-action="other" data-i18n="home.other"></button>' +
    '<button class="btn ghost sm" type="button" data-action="about" data-i18n="home.about"></button>' +
    '</div>' +
    '</div>' +

    '<button class="server-card" type="button" data-action="servers">' +
    '<span id="h-sflag"></span>' +
    '<span class="srv-meta"><span class="srv-label" data-i18n="home.server"></span>' +
    '<span class="srv-name" id="h-sname"></span><span class="srv-sub" id="h-ssub"></span></span>' +
    '<span class="srv-side"><span id="h-ssig"></span><span class="srv-ping mono" id="h-sping"></span></span>' +
    O.icon('chev', 'chev') +
    '</button>' +

    '<div class="quick" id="h-quick" role="group" data-i18n-aria="home.quickAria"></div>' +

    '<div class="stats">' +
    '<div class="stat"><span class="stat-ic">' + O.icon('down') + '</span><b class="mono" id="h-down">0 B</b><span data-i18n="home.stat.down"></span></div>' +
    '<div class="stat"><span class="stat-ic">' + O.icon('up') + '</span><b class="mono" id="h-up">0 B</b><span data-i18n="home.stat.up"></span></div>' +
    '<div class="stat"><span class="stat-ic">' + O.icon('clock') + '</span><b class="mono" id="h-time">00:00:00</b><span data-i18n="home.stat.time"></span></div>' +
    '<div class="stat"><span class="stat-ic">' + O.icon('activity') + '</span><b class="mono" id="h-pingstat">—</b><span data-i18n="home.stat.ping"></span></div>' +
    '</div>' +

    '<div class="tiles">' +
    '<button class="tile" type="button" data-action="cycle-proto"><span class="tile-ic">' + O.icon('route') + '</span>' +
    '<span class="tile-l" data-i18n="home.tile.proto"></span><span class="tile-v" id="h-tproto"></span></button>' +
    '<button class="tile" type="button" data-action="cycle-dns"><span class="tile-ic">' + O.icon('server') + '</span>' +
    '<span class="tile-l" data-i18n="home.tile.dns"></span><span class="tile-v" id="h-tdns"></span></button>' +
    '<button class="tile" type="button" data-action="toggle-kill" id="h-tkill"><span class="tile-ic">' + O.icon('lock') + '</span>' +
    '<span class="tile-l" data-i18n="home.tile.kill"></span><span class="tile-v" id="h-tkillv"></span></button>' +
    '</div>' +
    '</div>';

  /* ------------------------------------------------------------------ */

  function fakeIp() {
    var n = 2 + (U.hash32(S.get().deviceId || 'x') % 250);
    return '198.51.100.' + n;
  }

  function country() { return D.byCode[S.get().country]; }
  function lang() { return S.get().lang; }

  function renderQuick() {
    var st = S.get(), seen = {}, list = [];
    st.favorites.concat(st.recents).forEach(function (code) {
      if (!seen[code] && D.byCode[code]) { seen[code] = 1; list.push(code); }
    });
    list = list.slice(0, 6);
    if (!list.length) { el.quick.innerHTML = ''; el.quick.hidden = true; return; }
    el.quick.hidden = false;
    el.quick.innerHTML = list.map(function (code) {
      var c = D.byCode[code];
      return '<button class="chip q" type="button" data-action="quick" data-code="' + code + '" aria-pressed="' + (code === st.country) + '">' +
        O.ui.flag(code) + '<span>' + U.esc(c[lang()]) + '</span></button>';
    }).join('');
  }

  function syncServer() {
    var st = S.get(), c = country(), m = D.metrics(c.code), L = lang();
    el.sflag.innerHTML = O.ui.flag(c.code, 'lg');
    el.sname.textContent = c[L];
    el.ssub.textContent = (c.premium ? t('home.premium') : t('home.standard')) + ' · ' + m.speed + ' ' + t('unit.gbps') + ' · ' + t('region.' + c.region);
    el.ssig.innerHTML = O.ui.signal(m.ping);
    el.sping.textContent = st.settings.showPing ? m.ping + ' ' + t('unit.ms') : '';
    el.sping.hidden = !st.settings.showPing;
    el.pingstat.textContent = m.ping + ' ' + t('unit.ms');
    el.route.textContent = t('home.route', { name: c[L], km: U.fmtNum(c.km) });
  }

  function syncTiles() {
    var s = S.get().settings;
    el.tproto.textContent = t('proto.' + s.protocol);
    var dns = D.dns.filter(function (d) { return d.id === s.dns; })[0];
    el.tdns.textContent = dns ? dns[lang()] : '—';
    el.tkillv.textContent = s.killSwitch ? t('common.on') : t('common.off');
    el.tkill.setAttribute('aria-pressed', s.killSwitch ? 'true' : 'false');
    el.tkill.dataset.on = s.killSwitch ? '1' : '0';
  }

  var ICON_FOR = { idle: 'power', connecting: 'close', failed: 'refresh' };

  function renderSteps() {
    var ss = C.stepStates();
    el.steps.innerHTML = C.STEPS.map(function (id, i) {
      var s = ss[i], mark = '', time = '';
      if (s === 'done') mark = O.icon('check');
      else if (s === 'fail') mark = O.icon('x');
      else if (s === 'active') mark = '<span class="spin"></span>';
      else mark = '<span class="dot"></span>';
      if ((s === 'done' || s === 'fail') && C.stepTime(i)) time = (C.stepTime(i) / 1000).toFixed(1) + ' ' + t('unit.s');
      else if (s === 'skipped') time = '—';
      return '<li class="step" data-state="' + s + '"><span class="step-mark">' + mark + '</span>' +
        '<span class="step-name">' + t('step.' + id) + '</span><span class="step-time mono">' + time + '</span></li>';
    }).join('');
  }

  function renderAlert() {
    var entry = C.lastError() || S.get().errors[0];
    var def = D.errorByCode[entry ? entry.code : 'ERROR_SMG_01'];
    var L = lang();
    el.acode.textContent = def.code;
    el.atitle.textContent = def.title[L];
    el.atext.textContent = def.what[L];
    el.attempt.textContent = t('home.attempt', { n: entry ? entry.attempt : 1 });
  }

  function syncConnect() {
    var cs = C.state(), c = country();
    el.pill.dataset.state = cs;
    el.status.textContent = t('status.' + cs);
    el.orb.dataset.state = cs;
    el.orb.setAttribute('aria-label', t('home.orb.' + cs));
    el.orbicon.innerHTML = O.icon(ICON_FOR[cs]);
    el.orblabel.textContent = t('home.orb.' + cs);
    el.hint.textContent = t('home.hint.' + cs, { name: c[lang()] });
    el.ipstate.textContent = t('home.ipOpen');
    el.steps.hidden = cs === 'idle';
    el.alert.hidden = cs !== 'failed';
    if (cs !== 'idle') renderSteps();
    if (cs === 'failed') renderAlert();
    if (cs === 'connecting') startRing(); else setRing();
  }

  function setRing() {
    var p = C.progress();
    el.prog.style.strokeDashoffset = String(100 - p * 100);
  }

  function startRing() {
    if (ringRaf) return;
    function tick() {
      setRing();
      if (C.state() === 'connecting') ringRaf = requestAnimationFrame(tick);
      else { ringRaf = 0; setRing(); }
    }
    ringRaf = requestAnimationFrame(tick);
  }

  function syncAll() {
    syncServer();
    syncTiles();
    renderQuick();
    var code = S.get().country;
    if (code !== lastCountry) {
      lastCountry = code;
      O.globe.setSelected(code);
    }
    syncConnect();
  }

  /* ------------------------------------------------------------------
   * Подсказка при касании страны на глобусе
   * ------------------------------------------------------------------ */
  function showTip(c, x, y) {
    if (!c) { el.tip.hidden = true; tipCode = ''; return; }
    tipCode = c.code;
    var m = D.metrics(c.code);
    el.tiphead.innerHTML = O.ui.flag(c.code) + '<b>' + U.esc(c[lang()]) + '</b>';
    el.tipmeta.textContent = m.ping + ' ' + t('unit.ms') + ' · ' + t('home.load', { n: m.load });
    el.tip.hidden = false;
    var stageW = el.stage.clientWidth;
    var w = el.tip.offsetWidth;
    var left = U.clamp(x - w / 2, 6, stageW - w - 6);
    var top = y - el.tip.offsetHeight - 14;
    if (top < 6) top = y + 16;
    el.tip.style.left = left + 'px';
    el.tip.style.top = top + 'px';
  }

  /* ------------------------------------------------------------------
   * Действия
   * ------------------------------------------------------------------ */
  var CYCLE_PROTO = ['auto', 'udp', 'tcp'];

  var actions = {
    orb: function () { C.start(); },
    retry: function () { C.start(); },
    other: function () { O.router.go('countries'); },
    about: function () { O.router.go('errors', { code: 'ERROR_SMG_01' }); },
    servers: function () { O.router.go('countries'); },
    quick: function (b) {
      var code = b.getAttribute('data-code');
      if (code === S.get().country) return;
      S.selectCountry(code);
    },
    'tip-pick': function () {
      if (tipCode) S.selectCountry(tipCode);
      showTip(null);
      O.ui.toast(t('toast.picked', { name: D.name(S.get().country, lang()) }), 'ok');
    },
    'cycle-proto': function () {
      var cur = S.get().settings.protocol;
      S.setSetting('protocol', CYCLE_PROTO[(CYCLE_PROTO.indexOf(cur) + 1) % CYCLE_PROTO.length]);
    },
    'cycle-dns': function () {
      var ids = D.dns.map(function (d) { return d.id; });
      var cur = S.get().settings.dns;
      S.setSetting('dns', ids[(ids.indexOf(cur) + 1) % ids.length]);
    },
    'toggle-kill': function () { S.setSetting('killSwitch', !S.get().settings.killSwitch); }
  };

  /* ------------------------------------------------------------------ */

  H.mount = function (node) {
    root = node;
    root.innerHTML = TEMPLATE;
    O.i18n.apply(root);
    function q(id) { return U.$('#' + id, root); }
    el = {
      pill: q('h-pill'), status: q('h-status'), ip: q('h-ip'), ipstate: q('h-ipstate'),
      canvas: q('h-globe'), stage: U.$('.globe-stage', root), tip: q('h-tip'), tiphead: q('h-tiphead'), tipmeta: q('h-tipmeta'),
      route: q('h-route'), orb: q('h-orb'), prog: q('h-prog'), orbicon: q('h-orbicon'), orblabel: q('h-orblabel'),
      hint: q('h-hint'), steps: q('h-steps'), alert: q('h-alert'), acode: q('h-acode'), atitle: q('h-atitle'),
      atext: q('h-atext'), attempt: q('h-attempt'), sflag: q('h-sflag'), sname: q('h-sname'), ssub: q('h-ssub'),
      ssig: q('h-ssig'), sping: q('h-sping'), quick: q('h-quick'), pingstat: q('h-pingstat'),
      tproto: q('h-tproto'), tdns: q('h-tdns'), tkill: q('h-tkill'), tkillv: q('h-tkillv')
    };
    el.ip.textContent = fakeIp();

    U.delegate(root, 'click', '[data-action]', function (b) {
      var fn = actions[b.getAttribute('data-action')];
      if (fn) fn(b);
    });

    O.globe.init(el.canvas, { onPick: showTip });
    lastCountry = '';
    syncAll();

    S.on(function (ev) {
      var k = ev.keys.join(',');
      if (/country|recents|favorites|settings|lang|errors/.test(k)) {
        if (ev.keys.indexOf('country') >= 0 && C.state() !== 'idle') C.reset();
        syncAll();
        O.globe.requestDraw();
      }
    });
    C.on(function (e) {
      if (e.type === 'state') syncConnect();
      if (e.type === 'step') renderSteps();
      O.globe.requestDraw();
    });
  };

  /** Перерисовать тексты после смены языка. */
  H.refresh = function () {
    if (!root) return;
    O.i18n.apply(root);
    syncAll();
  };

  H.show = function () {
    O.globe.setActive(true);
    O.globe.requestDraw();
    clearInterval(pingTimer);
    pingTimer = setInterval(function () {
      D.bump();
      syncServer();
    }, 4000);
  };

  H.hide = function () {
    O.globe.setActive(false);
    clearInterval(pingTimer);
    showTip(null);
  };
})(window.O = window.O || {});
