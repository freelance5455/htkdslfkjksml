/* Орбита VPN: состояние приложения с сохранением в localStorage */
(function (O) {
  'use strict';

  var U = O.util, D = O.data;
  var KEY = 'orbita.v2';

  var DEFAULT_SETTINGS = {
    autoConnect: false,
    killSwitch: true,
    lanBypass: true,
    protocol: 'auto',
    dns: 'auto',
    notifyErrors: true,
    haptics: true,
    reduceMotion: false,
    showPing: true,
    split: false,
    splitApps: {}
  };

  function defaults() {
    return {
      onboarded: false,
      lang: 'ru',
      theme: 'system',
      accent: 'amber',
      country: 'DE',
      favorites: ['DE', 'NL'],
      recents: [],
      settings: JSON.parse(JSON.stringify(DEFAULT_SETTINGS)),
      errors: [],
      attempts: 0,
      deviceId: null,
      errSeq: 0
    };
  }

  var state = defaults();
  var bus = U.emitter();

  function sanitize(s) {
    var d = defaults();
    var out = d;
    if (!s || typeof s !== 'object') return out;
    ['onboarded'].forEach(function (k) { if (typeof s[k] === 'boolean') out[k] = s[k]; });
    if (s.lang === 'ru' || s.lang === 'en') out.lang = s.lang;
    if (s.theme === 'system' || s.theme === 'dark' || s.theme === 'light') out.theme = s.theme;
    if (D.accents.some(function (a) { return a.id === s.accent; })) out.accent = s.accent;
    if (D.byCode[s.country]) out.country = s.country;
    if (Array.isArray(s.favorites)) out.favorites = s.favorites.filter(function (c) { return D.byCode[c]; }).slice(0, 40);
    if (Array.isArray(s.recents)) out.recents = s.recents.filter(function (c) { return D.byCode[c]; }).slice(0, 6);
    if (s.settings && typeof s.settings === 'object') {
      Object.keys(DEFAULT_SETTINGS).forEach(function (k) {
        if (typeof s.settings[k] === typeof DEFAULT_SETTINGS[k]) out.settings[k] = s.settings[k];
      });
    }
    if (Array.isArray(s.errors)) {
      out.errors = s.errors.filter(function (e) { return e && typeof e.code === 'string' && typeof e.ts === 'number'; }).slice(0, 50);
    }
    if (typeof s.attempts === 'number') out.attempts = Math.max(0, Math.floor(s.attempts));
    if (typeof s.errSeq === 'number') out.errSeq = s.errSeq;
    if (typeof s.deviceId === 'string') out.deviceId = s.deviceId;
    return out;
  }

  var saveTimer = 0;
  function persist() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(function () {
      U.storage.set(KEY, JSON.stringify(state));
    }, 120);
  }

  function emit(keys) {
    persist();
    bus.emit({ keys: keys || [], state: state });
  }

  var S = O.store = {};

  S.load = function () {
    var raw = U.storage.get(KEY);
    var parsed = null;
    if (raw) {
      try { parsed = JSON.parse(raw); } catch (e) { parsed = null; }
    }
    state = sanitize(parsed);
    if (!state.deviceId) {
      state.deviceId = U.randomId();
      persist();
    }
    return state;
  };

  S.get = function () { return state; };
  S.on = bus.on;

  /** Меняет верхнеуровневые поля. */
  S.set = function (patch) {
    var keys = Object.keys(patch);
    keys.forEach(function (k) { state[k] = patch[k]; });
    emit(keys);
  };

  S.setSetting = function (key, value) {
    state.settings[key] = value;
    emit(['settings', 'settings.' + key]);
  };

  S.toggleFavorite = function (code) {
    var i = state.favorites.indexOf(code);
    if (i >= 0) state.favorites.splice(i, 1);
    else state.favorites.unshift(code);
    emit(['favorites']);
    return i < 0;
  };

  S.isFavorite = function (code) { return state.favorites.indexOf(code) >= 0; };

  S.selectCountry = function (code) {
    if (!D.byCode[code]) return;
    state.country = code;
    var i = state.recents.indexOf(code);
    if (i >= 0) state.recents.splice(i, 1);
    state.recents.unshift(code);
    state.recents = state.recents.slice(0, 6);
    emit(['country', 'recents']);
  };

  S.addError = function (entry) {
    state.errSeq = (state.errSeq || 0) + 1;
    entry.id = state.errSeq;
    state.errors.unshift(entry);
    state.errors = state.errors.slice(0, 50);
    state.attempts += 1;
    emit(['errors', 'attempts']);
    return entry;
  };

  S.clearErrors = function () {
    state.errors = [];
    state.attempts = 0;
    emit(['errors', 'attempts']);
  };

  S.resetSettings = function () {
    state.settings = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
    emit(['settings']);
  };

  /** Эффективное значение: переключатель из настроек или системная настройка. */
  S.reducedMotion = function () {
    return state.settings.reduceMotion || U.reducedMotionOS();
  };
})(window.O = window.O || {});
