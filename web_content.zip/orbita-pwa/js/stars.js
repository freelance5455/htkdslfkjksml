/* Орбита VPN: звёздный фон страницы (canvas) */
(function (O) {
  'use strict';

  var S = O.stars = {};
  var cv, ctx, W = 0, H = 0, DPR = 1;
  var stars = [];
  var shooting = null;
  var nextShot = 0;
  var rgb = '238,233,255';
  var raf = 0, last = 0, running = false;
  var scrollY = 0;

  function rand(a, b) { return a + Math.random() * (b - a); }

  function build() {
    var n = Math.round(Math.min(170, Math.max(60, W * H / 7000)));
    stars = [];
    for (var i = 0; i < n; i++) {
      var depth = Math.random();
      stars.push({
        x: Math.random() * W,
        y: Math.random() * H,
        r: 0.4 + depth * 1.2,
        depth: depth,
        tw: rand(0.4, 1.6),
        ph: rand(0, 6.28)
      });
    }
  }

  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = window.innerWidth;
    H = window.innerHeight;
    cv.width = Math.round(W * DPR);
    cv.height = Math.round(H * DPR);
    cv.style.width = W + 'px';
    cv.style.height = H + 'px';
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    build();
    draw(0);
  }

  S.refreshColors = function () {
    var v = getComputedStyle(document.documentElement).getPropertyValue('--star-rgb').trim();
    if (v) rgb = v.replace(/\s/g, '');
    draw(last / 1000);
  };

  function draw(t) {
    ctx.clearRect(0, 0, W, H);
    var animated = !O.store.reducedMotion();
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var tw = animated ? 0.55 + 0.45 * Math.sin(t * s.tw + s.ph) : 0.8;
      var y = s.y - scrollY * (0.02 + s.depth * 0.06);
      y = ((y % H) + H) % H;
      ctx.fillStyle = 'rgba(' + rgb + ',' + (0.25 + 0.6 * s.depth * tw).toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(s.x, y, s.r, 0, 6.2832);
      ctx.fill();
    }
    if (shooting && animated) {
      var p = (t - shooting.t0) / shooting.dur;
      if (p >= 1) {
        shooting = null;
      } else {
        var x = shooting.x + shooting.dx * p, y2 = shooting.y + shooting.dy * p;
        var g = ctx.createLinearGradient(x, y2, x - shooting.dx * 0.12, y2 - shooting.dy * 0.12);
        g.addColorStop(0, 'rgba(' + rgb + ',' + (0.9 * (1 - p)).toFixed(3) + ')');
        g.addColorStop(1, 'rgba(' + rgb + ',0)');
        ctx.strokeStyle = g;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(x, y2);
        ctx.lineTo(x - shooting.dx * 0.12, y2 - shooting.dy * 0.12);
        ctx.stroke();
      }
    }
  }

  function frame(ts) {
    raf = 0;
    if (!running) return;
    var t = ts / 1000;
    last = ts;
    if (!shooting && t > nextShot && !O.store.reducedMotion()) {
      shooting = { t0: t, dur: rand(0.8, 1.3), x: rand(W * 0.1, W * 0.8), y: rand(0, H * 0.4), dx: rand(160, 260), dy: rand(70, 140) };
      nextShot = t + rand(9, 18);
    }
    draw(t);
    raf = requestAnimationFrame(frame);
  }

  S.start = function () {
    if (running) return;
    running = true;
    if (!O.store.reducedMotion()) raf = requestAnimationFrame(frame);
    else draw(0);
  };

  S.stop = function () {
    running = false;
    if (raf) cancelAnimationFrame(raf);
    raf = 0;
  };

  /** Включает или выключает анимацию после смены настройки. */
  S.syncMotion = function () {
    S.stop();
    S.start();
    draw(last / 1000);
  };

  S.init = function (canvas) {
    cv = canvas;
    ctx = cv.getContext('2d');
    nextShot = 4;
    resize();
    window.addEventListener('resize', O.util.debounce(resize, 150));
    window.addEventListener('scroll', function () {
      scrollY = window.pageYOffset || 0;
      if (!running || O.store.reducedMotion()) draw(last / 1000);
    }, { passive: true });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) S.stop(); else S.start();
    });
    S.refreshColors();
    S.start();
  };
})(window.O = window.O || {});
