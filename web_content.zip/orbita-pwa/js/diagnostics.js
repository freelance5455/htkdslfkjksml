/* Орбита VPN: диагностика подключения.
 * Проверки идут по очереди. Состояние сети настоящее (navigator.onLine),
 * остальное моделируется: серверы в этой версии не настроены. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data;
  var Dg = O.diag = {};
  var handle = null;
  var running = false;
  var token = 0;

  function t(k, p) { return O.t(k, p); }

  /* Каждая проверка возвращает {status, note, code?}. status: ok | warn | fail | skipped */
  var CHECKS = [
    {
      id: 'net',
      run: function () {
        return navigator.onLine
          ? { status: 'ok', note: t('diag.net.ok') }
          : { status: 'fail', note: t('diag.net.fail'), code: 'ERROR_NET_06' };
      }
    },
    {
      id: 'dns',
      run: function (ctx) {
        if (ctx.offline) return { status: 'skipped', note: t('diag.skipped') };
        var dns = D.dns.filter(function (d) { return d.id === S.get().settings.dns; })[0];
        return { status: 'ok', note: t('diag.dns.ok', { name: dns ? dns[S.get().lang] : '—' }) };
      }
    },
    {
      id: 'time',
      run: function () {
        var ok = Date.now() > Date.UTC(2025, 0, 1);
        return ok ? { status: 'ok', note: t('diag.time.ok') } : { status: 'fail', note: t('diag.time.fail'), code: 'ERROR_TLS_08' };
      }
    },
    {
      id: 'sub',
      run: function () { return { status: 'warn', note: t('diag.sub.warn'), code: 'ERROR_SUB_05' }; }
    },
    {
      id: 'port',
      run: function (ctx) {
        if (ctx.offline) return { status: 'skipped', note: t('diag.skipped') };
        var p = S.get().settings.protocol;
        return p === 'udp'
          ? { status: 'warn', note: t('diag.port.udp'), code: 'ERROR_PRT_09' }
          : { status: 'ok', note: t('diag.port.ok') };
      }
    },
    {
      id: 'server',
      run: function (ctx) {
        if (ctx.offline) return { status: 'skipped', note: t('diag.skipped') };
        var c = D.byCode[S.get().country];
        ctx.serverFailed = true;
        return { status: 'fail', note: t('diag.server.fail', { name: c[S.get().lang] }), code: 'ERROR_SMG_01' };
      }
    },
    {
      id: 'tls',
      run: function (ctx) {
        if (ctx.offline || ctx.serverFailed) return { status: 'skipped', note: t('diag.skipped') };
        return { status: 'ok', note: '' };
      }
    }
  ];

  var STATUS_ICON = { ok: 'check', warn: 'alert', fail: 'x', skipped: 'chev' };

  function rowHtml(c, res, state) {
    var name = t('diag.c.' + c.id);
    var mark, note = '';
    if (state === 'running') { mark = '<span class="spin"></span>'; note = t('diag.running'); }
    else if (state === 'pending') { mark = '<span class="dot"></span>'; }
    else { mark = O.icon(STATUS_ICON[res.status]); note = res.note; }
    return '<li class="dg-row" data-status="' + (res ? res.status : state) + '">' +
      '<span class="dg-mark">' + mark + '</span>' +
      '<span class="dg-text"><b>' + name + '</b><span>' + U.esc(note) + '</span></span>' +
      (res && res.code ? '<em class="dg-code mono">' + res.code + '</em>' : '') +
      '</li>';
  }

  function render(results, runningIdx, done) {
    var rows = CHECKS.map(function (c, i) {
      if (results[i]) return rowHtml(c, results[i], 'done');
      return rowHtml(c, null, i === runningIdx ? 'running' : 'pending');
    }).join('');

    var fails = results.filter(function (r) { return r && r.status === 'fail'; }).length;
    var warns = results.filter(function (r) { return r && r.status === 'warn'; }).length;
    var pct = Math.round(results.filter(Boolean).length / CHECKS.length * 100);

    var summary = '';
    if (done) {
      var main = results.filter(function (r) { return r.status === 'fail' && r.code; })
        .sort(function (a, b) { return a.code === 'ERROR_SMG_01' ? 1 : b.code === 'ERROR_SMG_01' ? -1 : 0; })[0];
      var def = main ? D.errorByCode[main.code] : null;
      var L = S.get().lang;
      summary =
        '<div class="dg-summary ' + (fails ? 'bad' : warns ? 'warn' : 'ok') + '">' +
        '<b>' + (fails ? O.tn('diag.problems', fails) : warns ? O.tn('diag.warnings', warns) : t('diag.allOk')) + '</b>' +
        (def ? '<p><span class="mono">' + def.code + '</span> ' + U.esc(def.title[L]) + '. ' + t('diag.cause') + '</p>' : '') +
        '</div>' +
        '<div class="dg-actions">' +
        '<button class="btn block" type="button" data-dg="copy">' + O.icon('copy') + '<span>' + t('errors.report') + '</span></button>' +
        '<div class="pair"><button class="btn ghost" type="button" data-dg="country">' + t('home.other') + '</button>' +
        '<button class="btn ghost" type="button" data-dg="again">' + O.icon('refresh') + '<span>' + t('diag.again') + '</span></button></div></div>';
    }

    return '<div class="dg">' +
      '<div class="dg-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '"><i style="width:' + pct + '%"></i></div>' +
      '<ul class="dg-list">' + rows + '</ul>' + summary + '</div>';
  }

  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function run() {
    if (running) return;
    running = true;
    var my = ++token;
    var results = [];
    var ctx = { offline: !navigator.onLine, serverFailed: false };
    handle.setBody(render(results, 0, false));

    var chain = Promise.resolve();
    CHECKS.forEach(function (c, i) {
      chain = chain.then(function () {
        if (my !== token || !handle) return null;
        handle.setBody(render(results, i, false));
        return wait(380 + Math.random() * 420).then(function () {
          if (my !== token || !handle) return;
          var r = c.run(ctx);
          r.name = t('diag.c.' + c.id);
          r.id = c.id;
          results.push(r);
          if (c.id === 'net' && r.status === 'fail') ctx.offline = true;
          handle.setBody(render(results, i + 1, i === CHECKS.length - 1));
        });
      });
    });
    chain.then(function () {
      running = false;
      if (my === token) Dg.last = results;
    });
  }

  Dg.last = null;

  Dg.open = function () {
    if (handle) return;
    handle = O.ui.sheet({
      title: t('diag.title'),
      className: 'diag-sheet',
      html: '',
      onClose: function () { handle = null; running = false; token++; }
    });
    U.delegate(handle.body, 'click', '[data-dg]', function (b) {
      var a = b.getAttribute('data-dg');
      if (a === 'copy') O.ui.copy(O.errorReport(Dg.last), 'toast.reportCopied');
      else if (a === 'country') { handle.close(); O.router.go('countries'); }
      else if (a === 'again') { running = false; run(); }
    });
    run();
  };
})(window.O = window.O || {});
