/* Орбита VPN: PWA. Регистрация SW, установка, обновление, офлайн-статус. */
(function (O) {
  'use strict';

  var P = O.pwa = {};
  var deferred = null, reg = null, swVersion = '';
  var standalone = false;
  try {
    standalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  } catch (e) { /* matchMedia недоступен */ }

  var ua = navigator.userAgent || '';
  var isIOS = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  var swOk = 'serviceWorker' in navigator && (location.protocol === 'https:' || /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname));
  var cached = false;

  function t(k, p) { return O.t(k, p); }
  function toast(k, kind) { if (O.ui && O.ui.toast) O.ui.toast(t(k), kind || 'ok'); }

  /* ---------- разметка раздела в настройках ---------- */
  function row(action, icon, tk, dk, id) {
    return '<button class="srow link" type="button" data-action="' + action + '" id="' + id + '">' +
      '<span class="srow-ic">' + O.icon(icon) + '</span><span class="srow-t"><b data-k="t"></b><span data-k="d"></span></span>' +
      O.icon('chev', 'chev') + '</button>';
  }

  P.settingsHtml = function () {
    return '<section class="blk" id="pwa-blk"><h2 class="grp">' + t('pwa.title') + '</h2><div class="group">' +
      row('pwa-install', 'down', '', '', 'pwa-install') +
      row('pwa-offline', 'shield', '', '', 'pwa-offline') +
      row('pwa-check', 'refresh', '', '', 'pwa-check') +
      '</div></section>';
  };

  function setRow(id, title, desc, disabled) {
    var el = document.getElementById(id); if (!el) return;
    el.querySelector('[data-k="t"]').textContent = title;
    el.querySelector('[data-k="d"]').textContent = desc;
    el.disabled = !!disabled;
    el.classList.toggle('dim', !!disabled);
  }

  P.paint = function () {
    if (!document.getElementById('pwa-blk')) return;
    var head = document.querySelector('#pwa-blk .grp'); if (head) head.textContent = t('pwa.title');
    if (standalone) setRow('pwa-install', t('pwa.installed'), t('pwa.installedD'), true);
    else if (deferred) setRow('pwa-install', t('pwa.install'), t('pwa.installD'), false);
    else if (isIOS) setRow('pwa-install', t('pwa.ios'), t('pwa.iosD'), false);
    else setRow('pwa-install', t('pwa.unavail'), t('pwa.unavailD'), true);
    setRow('pwa-offline', cached ? t('pwa.offline') : t('pwa.offlinePending'), t('pwa.offlineD'), true);
    setRow('pwa-check', t('pwa.check'), t('pwa.checkD', { v: swVersion || '—' }), !swOk);
  };

  /* ---------- действия ---------- */
  function iosSheet() {
    O.ui.sheet({
      title: t('pwa.iosTitle'),
      html: '<ol class="pwa-steps" style="display:grid;gap:12px;padding-left:20px;list-style:decimal"><li>' + t('pwa.iosS1') + '</li><li>' + t('pwa.iosS2') + '</li><li>' + t('pwa.iosS3') + '</li></ol>'
    });
  }

  function doInstall() {
    if (deferred) {
      var d = deferred; deferred = null;
      d.prompt();
      d.userChoice.then(function () { P.paint(); });
    } else if (isIOS) iosSheet();
  }

  function doCheck() {
    if (!reg) return;
    reg.update().then(function () {
      if (!reg.waiting && !reg.installing) toast('pwa.upToDate');
    }).catch(function () {});
  }

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest && ev.target.closest('[data-action^="pwa-"]'); if (!b) return;
    var a = b.getAttribute('data-action');
    if (a === 'pwa-install') doInstall();
    else if (a === 'pwa-check') doCheck();
  });

  /* ---------- события браузера ---------- */
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; P.paint(); });
  window.addEventListener('appinstalled', function () { deferred = null; standalone = true; toast('pwa.toast.installed'); P.paint(); });
  window.addEventListener('offline', function () { toast('pwa.toast.offline', 'warn'); });
  window.addEventListener('online', function () { toast('pwa.toast.online'); });

  /* ---------- service worker ---------- */
  function promptUpdate(worker) {
    if (!O.ui || !O.ui.toast) { worker.postMessage({ type: 'SKIP_WAITING' }); return; }
    O.ui.toast(t('pwa.toast.update'), 'ok', 12000);
    var box = document.getElementById('toasts');
    var last = box && box.lastElementChild;
    if (last) {
      last.style.cursor = 'pointer';
      last.addEventListener('click', function () { worker.postMessage({ type: 'SKIP_WAITING' }); });
    }
  }

  function register() {
    if (!swOk) return;
    var reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (reloading || !hadController) return;
      reloading = true; location.reload();
    });
    navigator.serviceWorker.addEventListener('message', function (e) {
      if (e.data && e.data.type === 'VERSION') { swVersion = e.data.version; P.paint(); }
    });
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.register('sw.js', { scope: './' }).then(function (r) {
      reg = r;
      if (r.waiting && hadController) promptUpdate(r.waiting);
      r.addEventListener('updatefound', function () {
        var w = r.installing; if (!w) return;
        w.addEventListener('statechange', function () {
          if (w.state === 'installed') {
            if (hadController) promptUpdate(w);
            else { cached = true; toast('pwa.toast.ready'); P.paint(); }
          }
        });
      });
      return navigator.serviceWorker.ready;
    }).then(function (r) {
      if (!r) return;
      cached = true;
      var w = r.active; if (w) w.postMessage({ type: 'GET_VERSION' });
      P.paint();
    }).catch(function () { P.paint(); });
  }

  P.info = function () { return { standalone: standalone, ios: isIOS, sw: swOk }; };

  if (document.readyState === 'complete') register();
  else window.addEventListener('load', register);
})(window.O = window.O || {});
