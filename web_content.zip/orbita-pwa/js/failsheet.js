/* Орбита VPN: шторка с ошибкой подключения.
 * Появляется после каждой неудачной попытки (если включены уведомления об ошибках). */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data, C = O.connect;
  var F = O.failSheet = {};
  var current = null;

  function t(k, p) { return O.t(k, p); }

  function html(entry) {
    var L = S.get().lang;
    var def = D.errorByCode[entry.code] || D.errors[0];
    var c = D.byCode[entry.country];
    var many = entry.attempt >= 3;
    return '<div class="fail">' +
      '<div class="fail-ic">' + O.icon('alert') + '</div>' +
      '<div class="fail-code mono">' + def.code + '</div>' +
      '<h2 class="fail-title">' + U.esc(def.title[L]) + '</h2>' +
      '<p class="fail-text">' + t('fail.text', { name: U.esc(c[L]) }) + '</p>' +
      '<div class="fail-meta">' +
      '<span class="chip static">' + t('home.attempt', { n: entry.attempt }) + '</span>' +
      '<span class="chip static">' + t('fail.step', { step: t('step.' + entry.step) }) + '</span>' +
      '<span class="chip static">' + t('fail.transport', { p: t('proto.' + entry.protocol) }) + '</span>' +
      '</div>' +
      '<ul class="fail-tips">' +
      '<li>' + O.icon('wifi') + '<span>' + t('fail.tip1') + '</span></li>' +
      '<li>' + O.icon('globe') + '<span>' + t('fail.tip2') + '</span></li>' +
      '<li>' + O.icon('route') + '<span>' + t('fail.tip3') + '</span></li>' +
      '</ul>' +
      (many ? '<div class="notice">' + O.icon('info') + '<span>' + t('fail.many') + '</span></div>' : '') +
      '<div class="fail-actions">' +
      '<button class="btn block" type="button" data-fa="retry" data-autofocus>' + O.icon('refresh') + '<span>' + t('home.retry') + '</span></button>' +
      '<div class="pair">' +
      '<button class="btn ghost" type="button" data-fa="other">' + t('home.other') + '</button>' +
      '<button class="btn ghost" type="button" data-fa="diag">' + t('fail.diag') + '</button></div>' +
      '<button class="link-btn" type="button" data-fa="about">' + t('home.about') + '</button>' +
      '</div></div>';
  }

  function open(entry) {
    if (current) { current.close(); current = null; }
    var h = O.ui.sheet({
      bare: true,
      className: 'fail-sheet',
      html: html(entry),
      onClose: function () { if (current === h) current = null; }
    });
    current = h;
    U.delegate(h.body, 'click', '[data-fa]', function (b) {
      var a = b.getAttribute('data-fa');
      h.close();
      if (a === 'retry') setTimeout(function () { C.start(); }, 300);
      else if (a === 'other') O.router.go('countries');
      else if (a === 'diag') setTimeout(function () { O.diag.open(); }, 280);
      else if (a === 'about') O.router.go('errors', { code: entry.code });
    });
  }

  F.init = function () {
    C.on(function (e) {
      if (e.type !== 'fail') return;
      O.ui.haptic([70, 50, 70]);
      if (S.get().settings.notifyErrors) open(e.entry);
      else O.ui.toast(e.entry.code, 'danger');
    });
  };
})(window.O = window.O || {});
