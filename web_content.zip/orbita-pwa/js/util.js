/* Орбита VPN: утилиты */
(function (O) {
  'use strict';

  var U = O.util = {};

  /* ---------- DOM ---------- */
  U.$ = function (sel, root) { return (root || document).querySelector(sel); };
  U.$$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  U.esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; });
  };

  /** Делегирование событий: on(root, 'click', '[data-action]', fn(el, ev)). */
  U.delegate = function (root, type, selector, fn) {
    root.addEventListener(type, function (ev) {
      var target = ev.target.closest ? ev.target.closest(selector) : null;
      if (target && root.contains(target)) fn(target, ev);
    });
  };

  U.debounce = function (fn, ms) {
    var id = 0;
    return function () {
      var args = arguments, self = this;
      clearTimeout(id);
      id = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  };

  /* ---------- числа ---------- */
  U.clamp = function (v, a, b) { return v < a ? a : v > b ? b : v; };
  U.lerp = function (a, b, k) { return a + (b - a) * k; };
  U.pad = function (n) { return n < 10 ? '0' + n : '' + n; };

  /** FNV-1a: стабильный хеш строки в 32-битное беззнаковое число. */
  U.hash32 = function (str) {
    var h = 0x811c9dc5;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193);
    }
    return h >>> 0;
  };

  /** Расстояние по большому кругу, км. */
  U.haversine = function (lat1, lon1, lat2, lon2) {
    var R = 6371, p = Math.PI / 180;
    var dLat = (lat2 - lat1) * p, dLon = (lon2 - lon1) * p;
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * p) * Math.cos(lat2 * p) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
  };

  /* ---------- форматирование ---------- */
  U.fmtDuration = function (sec) {
    sec = Math.max(0, Math.floor(sec));
    return U.pad(Math.floor(sec / 3600)) + ':' + U.pad(Math.floor(sec % 3600 / 60)) + ':' + U.pad(sec % 60);
  };

  U.fmtBytes = function (n) {
    if (!n) return '0 B';
    var u = ['B', 'KB', 'MB', 'GB'], i = Math.min(3, Math.floor(Math.log(n) / Math.log(1024)));
    return (n / Math.pow(1024, i)).toFixed(i ? 1 : 0) + ' ' + u[i];
  };

  U.fmtNum = function (n) {
    return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  };

  U.fmtClock = function (ts, lang) {
    try {
      return new Date(ts).toLocaleTimeString(lang === 'en' ? 'en-GB' : 'ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      var d = new Date(ts);
      return U.pad(d.getHours()) + ':' + U.pad(d.getMinutes()) + ':' + U.pad(d.getSeconds());
    }
  };

  U.fmtDate = function (ts, lang) {
    try {
      return new Date(ts).toLocaleDateString(lang === 'en' ? 'en-GB' : 'ru-RU', { day: 'numeric', month: 'short' });
    } catch (e) {
      var d = new Date(ts);
      return U.pad(d.getDate()) + '.' + U.pad(d.getMonth() + 1);
    }
  };

  /* ---------- хранилище ---------- */
  U.storage = {
    get: function (key) {
      try { return window.localStorage.getItem(key); } catch (e) { return null; }
    },
    set: function (key, value) {
      try { window.localStorage.setItem(key, value); return true; } catch (e) { return false; }
    },
    remove: function (key) {
      try { window.localStorage.removeItem(key); } catch (e) { /* хранилище недоступно */ }
    }
  };

  /* ---------- события ---------- */
  U.emitter = function () {
    var list = [];
    return {
      on: function (fn) {
        list.push(fn);
        return function () {
          var i = list.indexOf(fn);
          if (i >= 0) list.splice(i, 1);
        };
      },
      emit: function (payload) {
        list.slice().forEach(function (fn) {
          try { fn(payload); } catch (e) { if (window.console) console.error(e); }
        });
      }
    };
  };

  /* ---------- буфер обмена ---------- */
  U.copy = function (text) {
    function fallback() {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;pointer-events:none';
        document.body.appendChild(ta);
        ta.select();
        var ok = document.execCommand && document.execCommand('copy');
        document.body.removeChild(ta);
        return !!ok;
      } catch (e) { return false; }
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return fallback(); });
    }
    return Promise.resolve(fallback());
  };

  /* ---------- среда ---------- */
  U.reducedMotionOS = function () {
    try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
  };

  var flagOk = null;
  /** Проверяет, рисует ли система эмодзи-флаги (в Windows их нет). */
  U.flagEmojiSupported = function () {
    if (flagOk !== null) return flagOk;
    try {
      var c = document.createElement('canvas');
      c.width = 40; c.height = 24;
      var x = c.getContext('2d');
      x.textBaseline = 'top';
      x.font = '18px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
      x.fillText('🇺🇦', 2, 2);
      var d = x.getImageData(0, 0, 40, 24).data, colored = 0;
      for (var i = 0; i < d.length; i += 4) {
        if (d[i + 3] > 100 && (Math.abs(d[i] - d[i + 1]) > 24 || Math.abs(d[i + 1] - d[i + 2]) > 24)) colored++;
      }
      flagOk = colored > 12;
    } catch (e) { flagOk = true; }
    return flagOk;
  };

  U.flagEmoji = function (code) {
    return String.fromCodePoint(127397 + code.charCodeAt(0), 127397 + code.charCodeAt(1));
  };

  U.deviceInfo = function () {
    var ua = (navigator.userAgent || '').toLowerCase();
    var os = 'web';
    if (ua.indexOf('android') >= 0) os = 'android';
    else if (/iphone|ipad|ipod/.test(ua)) os = 'ios';
    else if (ua.indexOf('windows') >= 0) os = 'windows';
    else if (ua.indexOf('mac') >= 0) os = 'macos';
    else if (ua.indexOf('linux') >= 0) os = 'linux';
    return { os: os };
  };

  U.randomId = function () {
    var hex = '0123456789ABCDEF', s = 'ORB-';
    for (var i = 0; i < 4; i++) s += hex[Math.floor(Math.random() * 16)];
    s += '-';
    for (var j = 0; j < 2; j++) s += Math.floor(Math.random() * 10);
    return s;
  };

  /** Ловушка фокуса внутри контейнера. Возвращает функцию снятия. */
  U.trapFocus = function (root) {
    function handler(ev) {
      if (ev.key !== 'Tab') return;
      var f = U.$$('button:not([disabled]), [href], input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])', root)
        .filter(function (n) { return n.offsetParent !== null || n === document.activeElement; });
      if (!f.length) { ev.preventDefault(); return; }
      var first = f[0], last = f[f.length - 1];
      if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
      else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
    }
    root.addEventListener('keydown', handler);
    return function () { root.removeEventListener('keydown', handler); };
  };
})(window.O = window.O || {});
