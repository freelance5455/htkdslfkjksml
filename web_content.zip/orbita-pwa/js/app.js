/* Орбита VPN: запуск, роутер, оформление (тема, акцент, язык). */
(function (O) {
  'use strict';

  var U = O.util, S = O.store, D = O.data, C = O.connect;
  var Scr = O.screens;
  var R = O.router = {};

  var ORDER = ['home', 'countries', 'sub', 'errors', 'settings'];
  var TAB_ICON = { home: 'shield', countries: 'globe', sub: 'crown', errors: 'alert', settings: 'sliders' };
  var cur = '';
  var mounted = {};

  function t(k, p) { return O.t(k, p); }

  /* ------------------------------------------------------------------
   * Оформление
   * ------------------------------------------------------------------ */
  function applyAppearance() {
    var st = S.get(), rootEl = document.documentElement;
    if (st.theme === 'system') rootEl.removeAttribute('data-theme');
    else rootEl.setAttribute('data-theme', st.theme);
    rootEl.setAttribute('data-accent', st.accent);
    rootEl.setAttribute('lang', st.lang);
    rootEl.classList.toggle('reduce-motion', S.reducedMotion());
    /* Цвета canvas читаются из CSS, поэтому обновляем после применения атрибутов. */
    requestAnimationFrame(function () {
      O.globe.refreshColors();
      O.stars.refreshColors();
      O.globe.requestDraw();
    });
  }

  /* ------------------------------------------------------------------
   * Нижняя панель и шапка
   * ------------------------------------------------------------------ */
  function renderTabbar() {
    var n = S.get().errors.length;
    O.tabbar.innerHTML = ORDER.map(function (id) {
      var badge = id === 'errors' && n ? '<em class="badge" aria-hidden="true">' + (n > 9 ? '9+' : n) + '</em>' : '';
      return '<button class="tab" type="button" data-nav="' + id + '"' + (cur === id ? ' aria-current="page"' : '') + '>' +
        '<span class="tab-ic">' + O.icon(TAB_ICON[id]) + badge + '</span><span class="tab-l">' + t('nav.' + id) + '</span></button>';
    }).join('');
  }

  function renderTopbar() {
    var cs = C.state();
    O.tbPill.setAttribute('data-state', cs);
    O.tbPill.innerHTML = O.icon(cs === 'idle' ? 'shieldoff' : cs === 'connecting' ? 'activity' : 'alert') + '<span>' + t('status.short.' + cs) + '</span>';
    O.tbMenu.setAttribute('aria-label', t('app.menu'));
    var brand = U.$('#tb-brand');
    brand.setAttribute('aria-label', t('nav.home'));
  }

  /* ------------------------------------------------------------------
   * Роутер
   * ------------------------------------------------------------------ */
  R.current = function () { return cur; };

  R.go = function (name, params) {
    if (ORDER.indexOf(name) < 0) name = 'home';
    var changed = name !== cur;
    if (changed) {
      if (cur && Scr[cur] && Scr[cur].hide) Scr[cur].hide();
      U.$$('.screen').forEach(function (s) {
        var on = s.getAttribute('data-screen') === name;
        s.hidden = !on;
        s.classList.remove('enter');
        if (on) { void s.offsetWidth; s.classList.add('enter'); }
      });
      cur = name;
      document.body.setAttribute('data-screen', name);
      try {
        if (location.hash.replace('#', '') !== name) history.replaceState(null, '', '#' + name);
      } catch (e) { /* история недоступна */ }
      window.scrollTo(0, 0);
    }
    if (Scr[name] && Scr[name].show) Scr[name].show(params);
    renderTabbar();
    document.title = (name === 'home' ? t('app.name') : t('nav.' + name) + ' · ' + t('app.name'));
  };

  function mountAll() {
    ORDER.forEach(function (id) {
      var node = U.$('#screen-' + id);
      Scr[id].mount(node);
      mounted[id] = true;
    });
  }

  function refreshAll() {
    O.i18n.apply(document);
    ORDER.forEach(function (id) { if (Scr[id].refresh) Scr[id].refresh(); });
    renderTabbar();
    renderTopbar();
  }

  /* ------------------------------------------------------------------
   * Запуск
   * ------------------------------------------------------------------ */
  function init() {
    S.load();
    O.i18n.set(S.get().lang);

    O.tabbar = U.$('#tabbar');
    O.tbPill = U.$('#tb-pill');
    O.tbMenu = U.$('#tb-menu');

    applyAppearance();
    O.stars.init(U.$('#stars'));
    mountAll();
    O.failSheet.init();
    O.i18n.apply(document);
    renderTopbar();

    /* Навигация по data-nav и меню. */
    U.delegate(document, 'click', '[data-nav]', function (b) { R.go(b.getAttribute('data-nav')); });
    O.tbMenu.addEventListener('click', function () { O.drawer.open(); });
    O.tbPill.addEventListener('click', function () { R.go('home'); });

    var lastLang = S.get().lang, lastMotion = S.reducedMotion();
    S.on(function (ev) {
      var k = ev.keys.join(',');
      if (/theme|accent|lang|settings/.test(k)) applyAppearance();
      if (/lang/.test(k) && S.get().lang !== lastLang) {
        lastLang = S.get().lang;
        O.i18n.set(lastLang);
        refreshAll();
        document.title = (cur === 'home' ? t('app.name') : t('nav.' + cur) + ' · ' + t('app.name'));
      }
      if (/errors/.test(k)) renderTabbar();
      if (S.reducedMotion() !== lastMotion) {
        lastMotion = S.reducedMotion();
        O.stars.syncMotion();
        O.globe.requestDraw();
      }
    });
    C.on(function () { renderTopbar(); });

    /* Системная тема меняется на лету. */
    try {
      var mq = window.matchMedia('(prefers-color-scheme: light)');
      var onMq = function () { applyAppearance(); };
      if (mq.addEventListener) mq.addEventListener('change', onMq); else if (mq.addListener) mq.addListener(onMq);
    } catch (e) { /* matchMedia недоступен */ }

    window.addEventListener('scroll', function () {
      O.topbar.classList.toggle('scrolled', (window.pageYOffset || 0) > 6);
    }, { passive: true });

    window.addEventListener('hashchange', function () {
      var h = location.hash.replace('#', '');
      if (ORDER.indexOf(h) >= 0 && h !== cur) R.go(h);
    });

    var start = location.hash.replace('#', '');
    R.go(ORDER.indexOf(start) >= 0 ? start : 'home');

    function afterOnboarding() {
      if (S.get().settings.autoConnect) setTimeout(function () { if (C.state() === 'idle') C.start(); }, 1400);
    }
    if (!S.get().onboarded) O.onboarding.open(afterOnboarding);
    else afterOnboarding();
  }

  O.topbar = null;
  function boot() {
    O.topbar = U.$('#topbar');
    init();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window.O = window.O || {});
