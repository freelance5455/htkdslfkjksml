/* Орбита VPN: общие элементы интерфейса (тосты, шторки, подтверждения, флаги) */
(function (O) {
  'use strict';

  var U = O.util;
  var UI = O.ui = {};

  var stack = [];       // открытые слои: шторки и диалоги, верхний последний
  var toastBox = null;

  function lockScroll() {
    document.documentElement.classList.toggle('is-locked', stack.length > 0);
  }

  function esc(s) { return U.esc(s); }

  /* ------------------------------------------------------------------
   * Мелкие помощники для разметки
   * ------------------------------------------------------------------ */

  /** Флаг страны: эмодзи, а если система их не рисует, плашка с кодом. */
  UI.flag = function (code, cls) {
    var c = cls ? ' ' + cls : '';
    if (U.flagEmojiSupported()) {
      return '<span class="flag' + c + '" aria-hidden="true">' + U.flagEmoji(code) + '</span>';
    }
    return '<span class="flag flag-code' + c + '" aria-hidden="true">' + esc(code) + '</span>';
  };

  /** Четыре столбика сигнала по пингу. */
  UI.signal = function (ping) {
    var lvl = O.data.signal(ping);
    return '<span class="sig" data-level="' + lvl + '" aria-hidden="true"><i></i><i></i><i></i><i></i></span>';
  };

  UI.haptic = function (pattern) {
    try {
      if (O.store.get().settings.haptics && navigator.vibrate) navigator.vibrate(pattern);
    } catch (e) { /* вибрация недоступна */ }
  };

  /** Копирует текст и показывает тост с результатом. */
  UI.copy = function (text, okKey) {
    return U.copy(text).then(function (ok) {
      UI.toast(O.t(ok ? (okKey || 'toast.copied') : 'toast.copyFail'), ok ? 'ok' : 'warn');
      return ok;
    });
  };

  /* ------------------------------------------------------------------
   * Тосты
   * ------------------------------------------------------------------ */
  UI.toast = function (msg, kind, ms) {
    if (!toastBox) toastBox = U.$('#toasts');
    if (!toastBox) return;
    var el = document.createElement('div');
    el.className = 'toast';
    el.setAttribute('data-kind', kind || 'info');
    el.textContent = msg;
    toastBox.appendChild(el);
    while (toastBox.children.length > 3) toastBox.removeChild(toastBox.firstChild);
    requestAnimationFrame(function () { el.classList.add('in'); });
    setTimeout(function () {
      el.classList.remove('in');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 260);
    }, ms || 2600);
  };

  /* ------------------------------------------------------------------
   * Шторка снизу
   * opts: title, html, className, bare, onClose(), onMount(handle)
   * ------------------------------------------------------------------ */
  UI.sheet = function (opts) {
    var root = U.$('#overlay');
    var prevFocus = document.activeElement;
    var layer = document.createElement('div');
    layer.className = 'layer sheet-layer';
    var head = opts.bare ? '' :
      '<header class="sheet-head"><h2 class="sheet-title">' + esc(opts.title || '') + '</h2>' +
      '<button class="icon-btn sm" type="button" data-close aria-label="' + esc(O.t('common.close')) + '">' + O.icon('close') + '</button></header>';
    layer.innerHTML =
      '<div class="scrim" data-close></div>' +
      '<section class="sheet ' + (opts.className || '') + '" role="dialog" aria-modal="true" aria-label="' + esc(opts.title || O.t('app.name')) + '" tabindex="-1">' +
      '<div class="sheet-grab" aria-hidden="true"><i></i></div>' + head +
      '<div class="sheet-body">' + (opts.html || '') + '</div></section>';
    root.appendChild(layer);

    var panel = U.$('.sheet', layer);
    var body = U.$('.sheet-body', layer);
    var releaseTrap = U.trapFocus(panel);
    var closed = false;

    var handle = {
      el: panel,
      body: body,
      setBody: function (html) { body.innerHTML = html; },
      close: function () {
        if (closed) return;
        closed = true;
        releaseTrap();
        var i = stack.indexOf(handle);
        if (i >= 0) stack.splice(i, 1);
        lockScroll();
        layer.classList.remove('open');
        setTimeout(function () { if (layer.parentNode) layer.parentNode.removeChild(layer); }, 260);
        if (prevFocus && prevFocus.focus) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* фокус потерян */ } }
        if (opts.onClose) opts.onClose();
      }
    };

    U.delegate(layer, 'click', '[data-close]', function () { handle.close(); });

    /* Перетаскивание за ручку закрывает шторку. */
    var grab = U.$('.sheet-grab', layer);
    var drag = null;
    grab.addEventListener('pointerdown', function (e) {
      drag = { y: e.clientY, d: 0 };
      try { grab.setPointerCapture(e.pointerId); } catch (err) { /* нет захвата */ }
      panel.style.transition = 'none';
    });
    grab.addEventListener('pointermove', function (e) {
      if (!drag) return;
      drag.d = Math.max(0, e.clientY - drag.y);
      panel.style.transform = 'translateY(' + drag.d + 'px)';
    });
    function endDrag() {
      if (!drag) return;
      var d = drag.d;
      drag = null;
      panel.style.transition = '';
      panel.style.transform = '';
      if (d > 90) handle.close();
    }
    grab.addEventListener('pointerup', endDrag);
    grab.addEventListener('pointercancel', endDrag);

    stack.push(handle);
    lockScroll();
    requestAnimationFrame(function () {
      layer.classList.add('open');
      var f = U.$('[data-autofocus]', panel);
      (f || panel).focus({ preventScroll: true });
    });
    if (opts.onMount) opts.onMount(handle);
    return handle;
  };

  /* ------------------------------------------------------------------
   * Диалог подтверждения. Возвращает Promise<boolean>.
   * o: title, text, ok, cancel, danger
   * ------------------------------------------------------------------ */
  UI.confirm = function (o) {
    return new Promise(function (resolve) {
      var root = U.$('#overlay');
      var prevFocus = document.activeElement;
      var layer = document.createElement('div');
      layer.className = 'layer modal-layer';
      layer.innerHTML =
        '<div class="scrim" data-no></div>' +
        '<section class="modal" role="alertdialog" aria-modal="true" aria-label="' + esc(o.title) + '" tabindex="-1">' +
        '<h2 class="modal-title">' + esc(o.title) + '</h2>' +
        (o.text ? '<p class="modal-text">' + esc(o.text) + '</p>' : '') +
        '<div class="modal-actions">' +
        '<button class="btn ghost" type="button" data-no>' + esc(o.cancel || O.t('common.cancel')) + '</button>' +
        '<button class="btn ' + (o.danger ? 'danger' : '') + '" type="button" data-yes data-autofocus>' + esc(o.ok || O.t('common.ok')) + '</button>' +
        '</div></section>';
      root.appendChild(layer);
      var panel = U.$('.modal', layer);
      var releaseTrap = U.trapFocus(panel);
      var done = false;

      var handle = {
        close: function () { finish(false); }
      };
      function finish(v) {
        if (done) return;
        done = true;
        releaseTrap();
        var i = stack.indexOf(handle);
        if (i >= 0) stack.splice(i, 1);
        lockScroll();
        layer.classList.remove('open');
        setTimeout(function () { if (layer.parentNode) layer.parentNode.removeChild(layer); }, 220);
        if (prevFocus && prevFocus.focus) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* фокус потерян */ } }
        resolve(v);
      }
      U.delegate(layer, 'click', '[data-yes]', function () { finish(true); });
      U.delegate(layer, 'click', '[data-no]', function () { finish(false); });
      stack.push(handle);
      lockScroll();
      requestAnimationFrame(function () {
        layer.classList.add('open');
        U.$('[data-autofocus]', panel).focus({ preventScroll: true });
      });
    });
  };

  /** Закрывает верхний слой. Возвращает true, если что-то закрыл. */
  UI.closeTop = function () {
    var top = stack[stack.length - 1];
    if (!top) return false;
    top.close();
    return true;
  };

  UI.closeAll = function () {
    while (stack.length) stack[stack.length - 1].close();
  };

  UI.hasLayer = function () { return stack.length > 0; };

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && UI.closeTop()) e.preventDefault();
  });

  /* Регистрация слоёв из других модулей (боковое меню). */
  UI.pushLayer = function (handle) {
    stack.push(handle);
    lockScroll();
  };
  UI.popLayer = function (handle) {
    var i = stack.indexOf(handle);
    if (i >= 0) stack.splice(i, 1);
    lockScroll();
  };
})(window.O = window.O || {});
