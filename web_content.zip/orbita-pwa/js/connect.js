/* Орбита VPN: логика подключения.
 * Подключение всегда заканчивается ошибкой ERROR_SMG_01 на шаге «рукопожатие»,
 * потому что серверы в этой версии не настроены. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store;
  var C = O.connect = {};
  var bus = U.emitter();

  var STEPS = ['lookup', 'handshake', 'encrypt', 'tunnel'];
  var FAIL_INDEX = 1;        // рукопожатие
  var FAIL_PROGRESS = 0.6;   // доля пути, на которой обрывается линия на глобусе

  var state = 'idle';        // idle | connecting | failed
  var stepIdx = -1;
  var t0 = 0, t1 = 0;
  var d0 = 0, d1 = 0;
  var stepMs = [];
  var timers = [];
  var lastEntry = null;

  C.STEPS = STEPS;
  C.on = bus.on;
  C.state = function () { return state; };
  C.lastError = function () { return lastEntry; };
  C.stepIndex = function () { return stepIdx; };

  function clearTimers() {
    timers.forEach(clearTimeout);
    timers = [];
  }

  function emit(type, extra) {
    var e = extra || {};
    e.type = type;
    e.state = state;
    bus.emit(e);
  }

  /** Состояние каждого шага: pending | active | done | fail | skipped. */
  C.stepStates = function () {
    return STEPS.map(function (_, i) {
      if (state === 'idle') return 'pending';
      if (state === 'failed') {
        if (i < FAIL_INDEX) return 'done';
        if (i === FAIL_INDEX) return 'fail';
        return 'skipped';
      }
      if (i < stepIdx) return 'done';
      if (i === stepIdx) return 'active';
      return 'pending';
    });
  };

  /** Сколько миллисекунд занял шаг (для подписи). */
  C.stepTime = function (i) { return stepMs[i] || 0; };

  /** Прогресс от 0 до 1 для кольца и линии на глобусе. */
  C.progress = function () {
    if (state === 'idle') return 0;
    if (state === 'failed') return FAIL_PROGRESS;
    var now = performance.now();
    if (stepIdx === 0) return 0.3 * U.clamp((now - t0) / d0, 0, 1);
    return 0.3 + 0.3 * U.clamp((now - t1) / d1, 0, 1);
  };

  C.failProgress = FAIL_PROGRESS;

  C.start = function () {
    if (state === 'connecting') { C.cancel(); return; }
    clearTimers();
    var st = S.get();
    S.selectCountry(st.country);
    state = 'connecting';
    stepIdx = 0;
    stepMs = [];
    d0 = 650 + Math.random() * 450;
    d1 = 1200 + Math.random() * 900;
    t0 = performance.now();
    emit('state');
    emit('step', { index: 0 });

    timers.push(setTimeout(function () {
      stepMs[0] = Math.round(d0);
      stepIdx = 1;
      t1 = performance.now();
      emit('step', { index: 1 });
    }, d0));

    timers.push(setTimeout(fail, d0 + d1));
  };

  function fail() {
    clearTimers();
    stepMs[1] = Math.round(d1);
    state = 'failed';
    stepIdx = FAIL_INDEX;
    var st = S.get();
    var entry = S.addError({
      code: 'ERROR_SMG_01',
      ts: Date.now(),
      country: st.country,
      step: STEPS[FAIL_INDEX],
      protocol: st.settings.protocol,
      attempt: st.attempts + 1
    });
    lastEntry = entry;
    emit('state');
    emit('fail', { entry: entry });
  }

  C.cancel = function () {
    if (state !== 'connecting') return;
    clearTimers();
    state = 'idle';
    stepIdx = -1;
    emit('state');
    emit('cancel');
  };

  /** Возвращает в исходное состояние (например, после смены страны). */
  C.reset = function () {
    if (state === 'idle') return;
    clearTimers();
    state = 'idle';
    stepIdx = -1;
    emit('state');
  };
})(window.O = window.O || {});
