/* Орбита VPN: аккаунты, вход, регистрация, подписка и админ-панель.
 * ВАЖНО: это демо без сервера. Всё хранится в localStorage этого браузера. */
(function (O) {
  'use strict';

  var U = O.util;
  var A = O.auth = {};
  var UKEY = 'orbita.users.v1', SKEY = 'orbita.session.v1';
  var ADMIN_NICK = 'adminorbitaVPN';
  var ADMIN_SALT = '6f7262697461a1c93e5b07d2';
  var ADMIN_HASH = '918c2e63de663ec7d249c78170206da2ecb3266c47db43597c8137860cac7306';
  var ROUNDS = 20000;

  function t(k, p) { return O.t(k, p); }

  /* ---------- SHA-256 (чистый JS, работает и без HTTPS) ---------- */
  var K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  var W = new Array(64);
  function sha256(msg) {
    var H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    var n = msg.length, padLen = ((n + 9 + 63) >> 6) << 6, buf = new Uint8Array(padLen);
    buf.set(msg); buf[n] = 0x80;
    var bits = n * 8, dv = new DataView(buf.buffer);
    dv.setUint32(padLen - 8, Math.floor(bits / 4294967296)); dv.setUint32(padLen - 4, bits >>> 0);
    for (var o = 0; o < padLen; o += 64) {
      var i;
      for (i = 0; i < 16; i++) W[i] = dv.getUint32(o + i * 4);
      for (i = 16; i < 64; i++) {
        var a15 = W[i - 15], a2 = W[i - 2];
        var s0 = ((a15 >>> 7) | (a15 << 25)) ^ ((a15 >>> 18) | (a15 << 14)) ^ (a15 >>> 3);
        var s1 = ((a2 >>> 17) | (a2 << 15)) ^ ((a2 >>> 19) | (a2 << 13)) ^ (a2 >>> 10);
        W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (i = 0; i < 64; i++) {
        var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + K[i] + W[i]) | 0;
        var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        var mj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + mj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = new Uint8Array(32), ov = new DataView(out.buffer);
    for (var j = 0; j < 8; j++) ov.setUint32(j * 4, H[j]);
    return out;
  }
  function hexToBytes(hx) { var o = new Uint8Array(hx.length / 2); for (var i = 0; i < o.length; i++) o[i] = parseInt(hx.substr(i * 2, 2), 16); return o; }
  function bytesToHex(b) { var s = ''; for (var i = 0; i < b.length; i++) s += (b[i] < 16 ? '0' : '') + b[i].toString(16); return s; }
  function cat() { var n = 0, i; for (i = 0; i < arguments.length; i++) n += arguments[i].length; var o = new Uint8Array(n), p = 0; for (i = 0; i < arguments.length; i++) { o.set(arguments[i], p); p += arguments[i].length; } return o; }
  function utf8(s) { return new TextEncoder().encode(s); }
  function hashPw(pw, saltHex) {
    var sb = hexToBytes(saltHex), pb = utf8(pw), x = sha256(cat(sb, pb));
    for (var i = 0; i < ROUNDS; i++) x = sha256(cat(x, sb, pb));
    return bytesToHex(x);
  }
  function newSalt() { var a = new Uint8Array(12); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.floor(Math.random() * 256); }); return bytesToHex(a); }
  A._hash = hashPw;

  /* ---------- хранилище ---------- */
  function loadUsers() {
    var raw = U.storage.get(UKEY), d = null;
    try { d = raw ? JSON.parse(raw) : null; } catch (e) { d = null; }
    if (!d || typeof d !== 'object' || !d.users) d = { users: {} };
    var k = ADMIN_NICK.toLowerCase();
    if (!d.users[k]) d.users[k] = { nick: ADMIN_NICK, created: Date.now(), sub: { plan: 'forever', until: null, by: 'system', ts: Date.now() } };
    d.users[k].nick = ADMIN_NICK;
    return d;
  }
  var db = null;
  function users() { if (!db) db = loadUsers(); return db.users; }
  function saveUsers() { U.storage.set(UKEY, JSON.stringify(db)); }
  function cleanNick(s) { return String(s || '').trim().replace(/^@+/, ''); }
  function keyOf(s) { return cleanNick(s).toLowerCase(); }

  /* ---------- сессия ---------- */
  A.user = function () {
    var raw = U.storage.get(SKEY), s = null;
    try { s = raw ? JSON.parse(raw) : null; } catch (e) { s = null; }
    if (!s || !s.nick) return null;
    return users()[keyOf(s.nick)] || null;
  };
  A.isAdmin = function () { var u = A.user(); return !!u && keyOf(u.nick) === ADMIN_NICK.toLowerCase(); };
  function setSession(u) { U.storage.set(SKEY, JSON.stringify({ nick: u.nick, ts: Date.now() })); }

  /* ---------- подписка ---------- */
  A.subInfo = function (u) {
    u = u || A.user();
    var s = u && u.sub;
    if (!s) return { active: false };
    if (s.until && s.until < Date.now()) return { active: false, expired: true };
    return { active: true, plan: s.plan, until: s.until || null };
  };
  A.grant = function (nick, plan, viaKey) {
    var u = users()[keyOf(nick)]; if (!u) return false;
    var until = null;
    if (plan !== 'forever') { var d = new Date(); d.setMonth(d.getMonth() + Number(plan)); until = d.getTime(); }
    u.sub = { plan: plan === 'forever' ? 'forever' : 'm' + plan, until: until, by: viaKey ? 'key' : ((A.user() || {}).nick || ''), ts: Date.now() };
    saveUsers(); return true;
  };
  A.revoke = function (nick) {
    var u = users()[keyOf(nick)]; if (!u) return false;
    u.sub = null; saveUsers(); return true;
  };

  /* ---------- вход / регистрация ---------- */
  var fails = 0, lockUntil = 0;
  function validNick(n) { return /^[A-Za-z0-9_]{3,20}$/.test(n); }

  A.register = function (nick, pw, pw2) {
    nick = cleanNick(nick);
    if (!validNick(nick)) return { err: 'auth.err.nick' };
    if (keyOf(nick) === ADMIN_NICK.toLowerCase() || users()[keyOf(nick)]) return { err: 'auth.err.taken' };
    if (pw.length < 6) return { err: 'auth.err.short' };
    if (pw !== pw2) return { err: 'auth.err.match' };
    var salt = newSalt();
    var u = users()[keyOf(nick)] = { nick: nick, salt: salt, hash: hashPw(pw, salt), created: Date.now(), sub: null };
    saveUsers(); setSession(u);
    return { ok: true };
  };

  A.login = function (nick, pw) {
    if (Date.now() < lockUntil) return { err: 'auth.err.locked', n: Math.ceil((lockUntil - Date.now()) / 1000) };
    nick = cleanNick(nick);
    var u = users()[keyOf(nick)], ok = false;
    if (u) {
      var isAdm = keyOf(nick) === ADMIN_NICK.toLowerCase();
      ok = hashPw(pw, isAdm ? ADMIN_SALT : u.salt || '00') === (isAdm ? ADMIN_HASH : u.hash);
    }
    if (!ok) {
      fails++;
      if (fails >= 5) { fails = 0; lockUntil = Date.now() + 30000; }
      return { err: 'auth.err.bad' };
    }
    fails = 0; setSession(u);
    return { ok: true };
  };

  A.logout = function () {
    try { localStorage.removeItem(SKEY); } catch (e) { /* хранилище недоступно */ }
    if (O.connect) O.connect.reset();
    if (O.ui && O.ui.closeAll) O.ui.closeAll();
    A.gate(function () { O.router.go('home'); refreshViews(); });
  };

  A._save = function () { saveUsers(); };
  A.refreshViews = function () { refreshViews(); };

  function refreshViews() {
    ['settings', 'sub'].forEach(function (id) { var s = O.screens[id]; if (s && s.refresh) s.refresh(); });
  }

  /* ---------- экран входа ---------- */
  var gateLayer = null;
  A.gate = function (done) {
    if (A.user()) { done(); return; }
    if (gateLayer) return;
    var mode = 'login';
    var layer = gateLayer = document.createElement('div');
    layer.className = 'layer onb-layer auth-layer';
    layer.setAttribute('role', 'dialog'); layer.setAttribute('aria-modal', 'true'); layer.setAttribute('aria-label', t('app.name'));
    layer.tabIndex = -1;
    U.$('#overlay').appendChild(layer);
    var release = U.trapFocus(layer);

    function render(keepNick) {
      var reg = mode === 'register';
      layer.innerHTML =
        '<form class="auth" novalidate autocomplete="on">' +
        '<div class="auth-logo"><svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="17" fill="none" stroke="var(--line)" stroke-width="2"/><circle cx="20" cy="20" r="9" fill="var(--surface-2)" stroke="var(--accent)" stroke-width="2"/><circle cx="20" cy="3" r="4" fill="var(--accent)"/></svg>' +
        '<b>' + t('app.name') + '</b></div>' +
        '<h1 class="auth-title">' + t(reg ? 'auth.regTitle' : 'auth.loginTitle') + '</h1>' +
        '<p class="auth-sub">' + t(reg ? 'auth.regSub' : 'auth.loginSub') + '</p>' +
        '<div class="seg wide" role="tablist">' +
        '<button type="button" role="tab" data-mode="login" aria-pressed="' + !reg + '">' + t('auth.tabLogin') + '</button>' +
        '<button type="button" role="tab" data-mode="register" aria-pressed="' + reg + '">' + t('auth.tabReg') + '</button></div>' +
        '<label class="auth-f"><span>' + t('auth.nick') + '</span><input class="field" id="au-nick" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="@nickname" value="' + U.esc(keepNick || '') + '"></label>' +
        '<label class="auth-f"><span>' + t('auth.pass') + '</span><input class="field" id="au-pass" type="password" autocomplete="' + (reg ? 'new-password' : 'current-password') + '" placeholder="••••••"></label>' +
        (reg ? '<label class="auth-f"><span>' + t('auth.pass2') + '</span><input class="field" id="au-pass2" type="password" autocomplete="new-password" placeholder="••••••"></label>' : '') +
        '<label class="auth-show"><input type="checkbox" id="au-show"> ' + t('auth.show') + '</label>' +
        '<p class="form-msg" id="au-msg" role="alert"></p>' +
        '<button class="btn block" type="submit" data-autofocus>' + t(reg ? 'auth.doReg' : 'auth.doLogin') + '</button>' +
        '<p class="auth-note">' + t('auth.note') + '</p></form>';
      var f = U.$(keepNick ? '#au-pass' : '#au-nick', layer); if (f) f.focus({ preventScroll: true });
    }

    function finish() {
      release();
      gateLayer = null;
      layer.classList.remove('open');
      setTimeout(function () { if (layer.parentNode) layer.parentNode.removeChild(layer); }, 320);
      refreshViews();
      done();
    }

    layer.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-mode]');
      if (b && b.getAttribute('data-mode') !== mode) { mode = b.getAttribute('data-mode'); render(U.$('#au-nick', layer).value); }
    });
    layer.addEventListener('change', function (e) {
      if (e.target.id !== 'au-show') return;
      ['au-pass', 'au-pass2'].forEach(function (id) { var el = U.$('#' + id, layer); if (el) el.type = e.target.checked ? 'text' : 'password'; });
    });
    layer.addEventListener('submit', function (e) {
      e.preventDefault();
      var nick = U.$('#au-nick', layer).value, pw = U.$('#au-pass', layer).value;
      var r = mode === 'register' ? A.register(nick, pw, (U.$('#au-pass2', layer) || {}).value || '') : A.login(nick, pw);
      var msg = U.$('#au-msg', layer);
      if (r.err) {
        msg.className = 'form-msg err'; msg.textContent = t(r.err, { n: r.n });
        var fld = U.$('#au-pass', layer); fld.classList.remove('shake'); void fld.offsetWidth; fld.classList.add('shake');
        if (O.ui.haptic) O.ui.haptic(30);
        return;
      }
      finish();
    });

    render();
    requestAnimationFrame(function () { layer.classList.add('open'); });
  };

  /* ---------- разметка в настройках ---------- */
  function fmtDate(ts) { return new Date(ts).toLocaleDateString(O.store.get().lang === 'ru' ? 'ru-RU' : 'en-GB'); }
  function subText(u) {
    var s = A.subInfo(u);
    if (!s.active) return t(s.expired ? 'admin.expired' : 'admin.noSub');
    return s.until ? t('admin.until', { d: fmtDate(s.until) }) : t('admin.forever');
  }
  A.subText = subText;

  A.settingsHtml = function () {
    var u = A.user(); if (!u) return '';
    var adm = A.isAdmin();
    var html = '<section class="blk"><h2 class="grp">' + t('auth.account') + '</h2><div class="group">' +
      '<div class="kv"><span>' + t('auth.nick') + '</span><b class="mono">@' + U.esc(u.nick) + '</b></div>' +
      '<div class="kv"><span>' + t('auth.role') + '</span><b>' + t(adm ? 'auth.roleAdmin' : 'auth.roleUser') + '</b></div>' +
      '<div class="kv"><span>' + t('admin.sub') + '</span><b>' + subText(u) + '</b></div>' +
      '<button class="srow link danger-text" type="button" data-action="auth-logout"><span class="srow-ic">' + O.icon('power') + '</span>' +
      '<span class="srow-t"><b>' + t('auth.logout') + '</b></span>' + O.icon('chev', 'chev') + '</button></div></section>';
    if (!adm) return html;
    var list = Object.keys(users()).map(function (k) { return users()[k]; })
      .sort(function (a, b) { return a.created - b.created; })
      .map(function (x) {
        var on = A.subInfo(x).active;
        return '<div class="adm-user"><div class="adm-who"><b class="mono">@' + U.esc(x.nick) + '</b>' +
          '<span class="' + (on ? 'ok' : '') + '">' + subText(x) + '</span></div>' +
          '<div class="adm-btns"><button class="btn xs" type="button" data-action="auth-grant" data-nick="' + U.esc(x.nick) + '">' + t('admin.grant') + '</button>' +
          '<button class="btn xs ghost" type="button" data-action="auth-revoke" data-nick="' + U.esc(x.nick) + '"' + (on ? '' : ' disabled') + '>' + t('admin.revoke') + '</button></div></div>';
      }).join('');
    return html + '<section class="blk"><div class="grp-row"><h2 class="grp">' + t('admin.title') + '</h2><span class="tag ok">ADMIN</span></div>' +
      '<div class="group adm">' + list + '</div><p class="adm-note">' + t('admin.note') + '</p></section>' + keysHtml();
  };

  function planLabel(p) { return t(p === 'forever' ? 'admin.pForever' : 'admin.p' + p); }
  function keysHtml() {
    var codes = O.keys ? O.keys.codes() : [];
    var rows = codes.map(function (c) {
      return '<div class="adm-user"><div class="adm-who"><b class="mono">' + U.esc(c.code) + '</b><span class="' + (c.usedBy ? '' : 'ok') + '">' +
        planLabel(c.plan) + ' · ' + (c.usedBy ? t('admin.keyUsed', { nick: '@' + U.esc(c.usedBy) }) : t('admin.keyFree')) + '</span></div>' +
        '<div class="adm-btns"><button class="btn xs" type="button" data-action="auth-copykey" data-code="' + c.code + '">' + t('admin.keyCopy') + '</button>' +
        '<button class="btn xs ghost" type="button" data-action="auth-delkey" data-code="' + c.code + '">' + t('admin.keyDel') + '</button></div></div>';
    }).join('') || '<div class="adm-user"><span class="muted">' + t('admin.keysEmpty') + '</span></div>';
    return '<section class="blk"><h2 class="grp">' + t('admin.keysTitle') + '</h2><div class="group adm">' + rows + '</div>' +
      '<button class="btn block" type="button" data-action="auth-genkey">' + t('admin.keyNew') + '</button>' +
      '<p class="adm-note">' + t('admin.keysNote') + '</p></section>';
  }

  function genSheet() {
    var opts = [['1', 'admin.p1'], ['3', 'admin.p3'], ['12', 'admin.p12'], ['forever', 'admin.pForever']];
    var h = O.ui.sheet({
      title: t('admin.keyNew'),
      html: '<div class="radio-list">' + opts.map(function (o) {
        return '<button class="radio-row" type="button" data-plan="' + o[0] + '"><span class="radio-dot"></span><span class="radio-t"><b>' + t(o[1]) + '</b></span></button>';
      }).join('') + '</div>'
    });
    U.delegate(h.body, 'click', '[data-plan]', function (b) {
      var code = O.keys.generate(b.getAttribute('data-plan'));
      h.close(); O.ui.copy(code, 'admin.keyCopied'); refreshViews();
    });
  }

  /* ---------- действия админа ---------- */
  function grantSheet(nick) {
    var opts = [['1', 'admin.p1'], ['3', 'admin.p3'], ['12', 'admin.p12'], ['forever', 'admin.pForever']];
    var h = O.ui.sheet({
      title: t('admin.grantTo', { nick: '@' + nick }),
      html: '<div class="radio-list">' + opts.map(function (o) {
        return '<button class="radio-row" type="button" data-plan="' + o[0] + '"><span class="radio-dot"></span><span class="radio-t"><b>' + t(o[1]) + '</b></span></button>';
      }).join('') + '</div>'
    });
    U.delegate(h.body, 'click', '[data-plan]', function (b) {
      A.grant(nick, b.getAttribute('data-plan'));
      h.close(); O.ui.toast(t('admin.granted', { nick: '@' + nick }), 'ok'); refreshViews();
    });
  }

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest && ev.target.closest('[data-action^="auth-"]'); if (!b || b.disabled) return;
    var a = b.getAttribute('data-action'), nick = b.getAttribute('data-nick');
    if (a === 'auth-logout') {
      O.ui.confirm({ title: t('auth.logoutTitle'), text: t('auth.logoutText'), ok: t('auth.logout'), danger: true }).then(function (y) { if (y) A.logout(); });
    } else if (a === 'auth-genkey' && A.isAdmin()) { genSheet();
    } else if (a === 'auth-copykey' && A.isAdmin()) { O.ui.copy(b.getAttribute('data-code'), 'admin.keyCopied');
    } else if (a === 'auth-delkey' && A.isAdmin()) { O.keys.deleteCode(b.getAttribute('data-code')); refreshViews();
    } else if ((a === 'auth-grant' || a === 'auth-revoke') && A.isAdmin()) {
      if (a === 'auth-grant') grantSheet(nick);
      else O.ui.confirm({ title: t('admin.revokeTitle', { nick: '@' + nick }), text: t('admin.revokeText'), ok: t('admin.revoke'), danger: true }).then(function (y) {
        if (y) { A.revoke(nick); O.ui.toast(t('admin.revoked', { nick: '@' + nick }), 'ok'); refreshViews(); }
      });
    }
  });
})(window.O = window.O || {});
