/* Орбита VPN: ключи доступа.
 * Понимает ссылки и ключи в формате Happ / v2ray-клиентов (vless, vmess, trojan, ss, hysteria2, tuic),
 * ссылки-подписки (https://...) и ссылки happ://add/... .
 * Также: ключи активации ORB-XXXX-XXXX-XXXX, которые выдаёт админ. */
(function (O) {
  'use strict';

  var U = O.util;
  var Kx = O.keys = {};
  var CKEY = 'orbita.keys.v1';
  var MAX_KEYS = 20;
  var ORB_RE = /^ORB-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/i;
  var PROTOS = { vless: 1, vmess: 1, trojan: 1, ss: 1, hysteria2: 1, hy2: 1, tuic: 1, wireguard: 1 };

  function b64(s) {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '');
    while (s.length % 4) s += '=';
    var bin = atob(s), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  }
  function dec(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
  function id() { return U.randomId().toLowerCase(); }

  /* Разбирает одну строку. Возвращает {ok, key} или {err}. */
  function parseOne(line) {
    line = line.trim();
    if (!line) return null;
    if (ORB_RE.test(line)) return { ok: true, key: { kind: 'activation', code: line.toUpperCase() } };

    var m = /^([a-z0-9+.-]+):\/\/(.*)$/i.exec(line);
    if (!m) return { err: 'keys.err.bad' };
    var scheme = m[1].toLowerCase(), rest = m[2];

    if (scheme === 'happ') {
      if (/^crypt/i.test(rest)) return { err: 'keys.err.crypt' };
      var inner = /^add\/(.+)$/i.exec(rest);
      return inner ? parseOne(dec(inner[1])) : { err: 'keys.err.bad' };
    }

    if (scheme === 'http' || scheme === 'https') {
      var u;
      try { u = new URL(line); } catch (e) { return { err: 'keys.err.bad' }; }
      if (!u.hostname || u.hostname.indexOf('.') < 0) return { err: 'keys.err.bad' };
      return { ok: true, key: { kind: 'sub', proto: 'sub', name: dec(u.hash.replace(/^#/, '')) || u.hostname, host: u.hostname, port: Number(u.port) || (scheme === 'https' ? 443 : 80), raw: line } };
    }

    if (!PROTOS[scheme]) return { err: 'keys.err.unknown' };
    var name = '', host = '', port = 0;
    var hashAt = rest.indexOf('#');
    if (hashAt >= 0) { name = dec(rest.slice(hashAt + 1)); rest = rest.slice(0, hashAt); }
    try {
      if (scheme === 'vmess') {
        var j = JSON.parse(b64(rest));
        host = String(j.add || ''); port = Number(j.port) || 0; name = name || String(j.ps || '');
      } else if (scheme === 'ss' && rest.indexOf('@') < 0) {
        var d = b64(rest.split('?')[0]), at = d.lastIndexOf('@');
        var hp = d.slice(at + 1), c = hp.lastIndexOf(':');
        host = hp.slice(0, c); port = Number(hp.slice(c + 1)) || 0;
      } else {
        var u2 = new URL(scheme + '://' + rest);
        host = u2.hostname.replace(/^\[|\]$/g, ''); port = Number(u2.port) || 0;
      }
    } catch (e) { return { err: 'keys.err.bad' }; }
    if (!host) return { err: 'keys.err.bad' };
    return { ok: true, key: { kind: 'server', proto: scheme === 'hy2' ? 'hysteria2' : scheme, name: name || host, host: host, port: port, raw: line } };
  }

  Kx.parse = function (text) {
    var lines = String(text || '').split(/[\r\n\s]+/).filter(Boolean);
    if (!lines.length) return { err: 'keys.err.empty' };
    var keys = [], err = null;
    lines.forEach(function (l) {
      var r = parseOne(l);
      if (!r) return;
      if (r.ok) keys.push(r.key); else err = err || r.err;
    });
    if (!keys.length) return { err: err || 'keys.err.bad' };
    return { keys: keys };
  };

  /* ---------- реестр ключей активации (общий для браузера) ---------- */
  function loadCodes() {
    var raw = U.storage.get(CKEY), d = null;
    try { d = raw ? JSON.parse(raw) : null; } catch (e) { d = null; }
    return d && d.codes ? d : { codes: {} };
  }
  function saveCodes(d) { U.storage.set(CKEY, JSON.stringify(d)); }

  Kx.generate = function (plan) {
    var A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', a = new Uint8Array(12), s = '';
    (window.crypto && crypto.getRandomValues) ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.floor(Math.random() * 256); });
    for (var i = 0; i < 12; i++) { s += A[a[i] % A.length]; if (i % 4 === 3 && i < 11) s += '-'; }
    var code = 'ORB-' + s, d = loadCodes();
    d.codes[code] = { plan: plan, created: Date.now(), by: (O.auth.user() || {}).nick || '', usedBy: null };
    saveCodes(d);
    return code;
  };
  Kx.codes = function () {
    var d = loadCodes();
    return Object.keys(d.codes).map(function (c) { var x = d.codes[c]; x.code = c; return x; })
      .sort(function (a, b) { return b.created - a.created; });
  };
  Kx.deleteCode = function (code) { var d = loadCodes(); delete d.codes[code]; saveCodes(d); };

  /* ---------- ключи пользователя ---------- */
  Kx.mine = function () { var u = O.auth.user(); return (u && u.keys) || []; };

  /* Ключ, который можно передать в Happ: сначала подписка, потом одиночный сервер. */
  Kx.primary = function () {
    var l = Kx.mine();
    return l.filter(function (k) { return k.kind === 'sub'; })[0] || l.filter(function (k) { return k.kind === 'server'; })[0] || null;
  };
  Kx.happLink = function (k) { return 'happ://add/' + k.raw; };

  Kx.remove = function (kid) {
    var u = O.auth.user(); if (!u || !u.keys) return;
    u.keys = u.keys.filter(function (k) { return k.id !== kid; });
    O.auth._save(); O.auth.refreshViews();
  };

  /* Главная точка входа: вставили текст в поле. */
  Kx.submit = function (text) {
    var u = O.auth.user();
    if (!u) return { err: 'keys.err.bad' };
    var p = Kx.parse(text);
    if (p.err) return p;
    var added = 0, activated = 0, dup = 0, err = null, lastPlan = null;
    u.keys = u.keys || [];
    p.keys.forEach(function (k) {
      if (k.kind === 'activation') {
        var d = loadCodes(), rec = d.codes[k.code];
        if (!rec) { err = err || 'keys.err.noCode'; return; }
        if (rec.usedBy) { err = err || 'keys.err.used'; return; }
        rec.usedBy = u.nick; rec.usedAt = Date.now(); saveCodes(d);
        O.auth.grant(u.nick, rec.plan, true);
        activated++; lastPlan = rec.plan;
        return;
      }
      if (u.keys.some(function (x) { return x.raw === k.raw; })) { dup++; return; }
      if (u.keys.length >= MAX_KEYS) { err = err || 'keys.err.limit'; return; }
      k.id = id(); k.added = Date.now();
      u.keys.unshift(k); added++;
    });
    if (added) O.auth._save();
    if (!added && !activated) return { err: err || (dup ? 'keys.err.dup' : 'keys.err.bad') };
    O.auth.refreshViews();
    return { ok: true, added: added, activated: activated, first: p.keys[0] };
  };
})(window.O = window.O || {});
