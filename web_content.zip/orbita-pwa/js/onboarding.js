/* Орбита VPN: первый запуск. Три коротких экрана. */
(function (O) {
  'use strict';

  var U = O.util, S = O.store;
  var Ob = O.onboarding = {};

  function t(k, p) { return O.t(k, p); }

  function art(i) {
    if (i === 0) {
      var dots = '', lines = '';
      var pts = [];
      for (var k = 0; k < 26; k++) {
        var a = (k / 26) * 6.2832 * 2.3 + 0.4;
        var r = 18 + (k * 53 % 62);
        pts.push([100 + Math.cos(a) * r, 100 + Math.sin(a) * r * 0.92]);
      }
      pts.forEach(function (p, idx) {
        dots += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="' + (idx % 5 === 0 ? 3 : 1.8) + '" class="' + (idx % 5 === 0 ? 'hl' : '') + '"/>';
        if (idx % 3 === 0 && pts[idx + 2]) lines += '<line x1="' + p[0].toFixed(1) + '" y1="' + p[1].toFixed(1) + '" x2="' + pts[idx + 2][0].toFixed(1) + '" y2="' + pts[idx + 2][1].toFixed(1) + '"/>';
      });
      return '<svg class="ob-art a0" viewBox="0 0 200 200" aria-hidden="true"><circle class="ring" cx="100" cy="100" r="92"/><g class="ln">' + lines + '</g><g class="dt">' + dots + '</g></svg>';
    }
    if (i === 1) {
      return '<svg class="ob-art a1" viewBox="0 0 200 200" aria-hidden="true">' +
        '<circle class="ring" cx="100" cy="100" r="88"/><circle class="ring dash" cx="100" cy="100" r="68"/>' +
        '<circle class="core" cx="100" cy="100" r="46"/>' +
        '<path class="pw" d="M100 80v22M85.5 88.5a22 22 0 1 0 29 0"/>' +
        '<g class="sat s1"><circle cx="100" cy="12" r="6"/></g><g class="sat s2"><circle cx="100" cy="32" r="3.5"/></g></svg>';
    }
    return '<svg class="ob-art a2" viewBox="0 0 200 200" aria-hidden="true">' +
      '<rect class="card" x="22" y="52" width="156" height="96" rx="18"/>' +
      '<circle class="bang" cx="52" cy="84" r="14"/><path class="bx" d="M52 77v8M52 90.5h.01"/>' +
      '<text class="code" x="76" y="88" font-size="11">ERROR_SMG_01</text>' +
      '<rect class="ph" x="38" y="112" width="124" height="7" rx="3.5"/><rect class="ph" x="38" y="126" width="84" height="7" rx="3.5"/></svg>';
  }

  Ob.open = function (onDone) {
    var i = 0, N = 3;
    var layer = document.createElement('div');
    layer.className = 'layer onb-layer';
    layer.setAttribute('role', 'dialog');
    layer.setAttribute('aria-modal', 'true');
    layer.setAttribute('aria-label', t('app.name'));
    layer.tabIndex = -1;
    U.$('#overlay').appendChild(layer);
    var releaseTrap = U.trapFocus(layer);
    var handle = { close: finish };
    var finished = false;

    function render() {
      layer.innerHTML =
        '<div class="onb">' +
        '<button class="link-btn skip" type="button" data-ob="skip"' + (i === N - 1 ? ' hidden' : '') + '>' + t('onb.skip') + '</button>' +
        '<div class="onb-stage" key="' + i + '">' + art(i) + '</div>' +
        '<div class="onb-copy"><h1>' + t('onb.t' + i) + '</h1><p>' + t('onb.d' + i) + '</p></div>' +
        '<div class="onb-foot"><div class="dots" aria-hidden="true">' +
        [0, 1, 2].map(function (k) { return '<i' + (k === i ? ' class="on"' : '') + '></i>'; }).join('') + '</div>' +
        '<button class="btn block" type="button" data-ob="next" data-autofocus>' + t(i === N - 1 ? 'onb.start' : 'onb.next') + '</button></div>' +
        '</div>';
      var f = U.$('[data-autofocus]', layer);
      if (f) f.focus({ preventScroll: true });
    }

    function finish() {
      if (finished) return;
      finished = true;
      releaseTrap();
      O.ui.popLayer(handle);
      S.set({ onboarded: true });
      layer.classList.remove('open');
      setTimeout(function () { if (layer.parentNode) layer.parentNode.removeChild(layer); }, 320);
      if (onDone) onDone();
    }

    U.delegate(layer, 'click', '[data-ob]', function (b) {
      var a = b.getAttribute('data-ob');
      if (a === 'skip') finish();
      else if (i < N - 1) { i++; render(); }
      else finish();
    });

    O.ui.pushLayer(handle);
    render();
    requestAnimationFrame(function () { layer.classList.add('open'); });
  };
})(window.O = window.O || {});
