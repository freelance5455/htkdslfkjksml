/* Орбита VPN: глобус из звёзд-стран (canvas, ортографическая проекция).
 * Каждая страна это точка на сфере. Между тобой и выбранным сервером идёт дуга. */
(function (O) {
  'use strict';

  var U = O.util, D = O.data;
  var G = O.globe = {};

  var cv, ctx, ro;
  var W = 0, H = 0, R = 0, RR = 0, CX = 0, CY = 0, DPR = 1;
  var zoom = 1, zoomT = 1;
  var base = { lon: 0.5, lat: 0.6 };      // куда смотрит камера, радианы
  var target = { lon: 0.5, lat: 0.6 };
  var off = { lon: 0, lat: 0 };           // смещение от перетаскивания
  var drag = null;
  var lastTouch = -10;
  var now = 0, lastTs = 0, raf = 0;
  var active = true, dirty = true, inited = false;
  var colors = null;
  var sel = null;
  var arc = [];
  var texture = [];
  var grat = [];
  var hits = [];
  var onPick = null;
  var userVec = null;

  var cL = 1, sL = 0, cP = 1, sP = 0;
  var P = { x: 0, y: 0, z: 0, vis: false };

  var RAD = Math.PI / 180;

  function toVec(lat, lon) {
    var la = lat * RAD, lo = lon * RAD;
    return [Math.cos(la) * Math.sin(lo), Math.sin(la), Math.cos(la) * Math.cos(lo)];
  }

  function norm(v) {
    var l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1;
    return [v[0] / l, v[1] / l, v[2] / l];
  }

  function hexRgb(hex) {
    var h = String(hex).replace('#', '').trim();
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    return [parseInt(h.slice(0, 2), 16) || 0, parseInt(h.slice(2, 4), 16) || 0, parseInt(h.slice(4, 6), 16) || 0];
  }

  function rgba(c, a) {
    return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')';
  }

  G.refreshColors = function () {
    var cs = getComputedStyle(document.documentElement);
    function g(n) { return hexRgb(cs.getPropertyValue(n)); }
    colors = {
      fg: g('--fg'), accent: g('--accent'), cool: g('--cool'), danger: g('--danger'),
      line: g('--line'), s2: g('--surface-2'), s1: g('--surface'), bg: g('--bg'), warn: g('--warn')
    };
    dirty = true;
  };

  /* ------------------------------------------------------------------
   * Подготовка геометрии
   * ------------------------------------------------------------------ */
  function prepare() {
    D.countries.forEach(function (c) { c._v = toVec(c.lat, c.lon); });
    userVec = toVec(D.ORIGIN.lat, D.ORIGIN.lon);

    /* Меридианы и параллели. */
    var lo, la, i, line;
    for (lo = -180; lo < 180; lo += 30) {
      line = [];
      for (i = 0; i <= 36; i++) line.push(toVec(-90 + i * 5, lo));
      grat.push({ pts: line, major: lo === 0 });
    }
    for (la = -60; la <= 60; la += 30) {
      line = [];
      for (i = 0; i <= 72; i++) line.push(toVec(la, -180 + i * 5));
      grat.push({ pts: line, major: la === 0 });
    }

    /* Точки фоновой текстуры: спираль Фибоначчи. */
    var n = 420, golden = Math.PI * (3 - Math.sqrt(5));
    for (i = 0; i < n; i++) {
      var y = 1 - (i / (n - 1)) * 2;
      var r = Math.sqrt(1 - y * y), th = golden * i;
      texture.push([Math.cos(th) * r, y, Math.sin(th) * r]);
    }
  }

  /* ------------------------------------------------------------------
   * Камера
   * ------------------------------------------------------------------ */
  function prep() {
    var lon = base.lon + off.lon, lat = U.clamp(base.lat + off.lat, -1.25, 1.25);
    cL = Math.cos(lon); sL = Math.sin(lon);
    cP = Math.cos(lat); sP = Math.sin(lat);
    RR = R * zoom;
  }

  function proj(v, r, out) {
    var x1 = v[0] * cL - v[2] * sL;
    var z1 = v[0] * sL + v[2] * cL;
    var y2 = v[1] * cP - z1 * sP;
    var z2 = v[1] * sP + z1 * cP;
    out.x = CX + x1 * RR * r;
    out.y = CY - y2 * RR * r;
    out.z = z2 * r;
    out.vis = z2 > 0 || (x1 * x1 + y2 * y2) * r * r > 1;
    return out;
  }

  function wrapAngle(a) {
    while (a > Math.PI) a -= 2 * Math.PI;
    while (a < -Math.PI) a += 2 * Math.PI;
    return a;
  }

  /* Дуга от точки пользователя до выбранной страны. */
  function buildArc() {
    arc = [];
    if (!sel) return;
    var a = userVec, b = sel._v;
    var dot = U.clamp(a[0] * b[0] + a[1] * b[1] + a[2] * b[2], -1, 1);
    var w = Math.acos(dot);
    zoomT = 1 + 0.9 * U.clamp(1 - w / 1.0, 0, 1);
    var N = 64;
    for (var i = 0; i <= N; i++) {
      var t = i / N, k1, k2;
      if (w < 1e-3) { k1 = 1 - t; k2 = t; }
      else { k1 = Math.sin((1 - t) * w) / Math.sin(w); k2 = Math.sin(t * w) / Math.sin(w); }
      var v = norm([a[0] * k1 + b[0] * k2, a[1] * k1 + b[1] * k2, a[2] * k1 + b[2] * k2]);
      var lift = Math.min(0.3, 0.05 + 0.11 * w) * Math.sin(Math.PI * t);
      arc.push({ v: v, r: 1 + lift });
    }
    /* Камера смотрит на середину дуги. */
    var mid = [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
    var len = Math.sqrt(mid[0] * mid[0] + mid[1] * mid[1] + mid[2] * mid[2]);
    var m = len < 0.05 ? b : norm(mid);
    target.lon = Math.atan2(m[0], m[2]);
    target.lat = U.clamp(Math.asin(U.clamp(m[1], -1, 1)), -1.1, 1.1);
    dirty = true;
  }

  /* ------------------------------------------------------------------
   * Отрисовка
   * ------------------------------------------------------------------ */
  function strokePoly(pts, r) {
    ctx.beginPath();
    var pen = false;
    for (var i = 0; i < pts.length; i++) {
      proj(pts[i], r, P);
      if (P.z > 0) {
        if (pen) ctx.lineTo(P.x, P.y); else ctx.moveTo(P.x, P.y);
        pen = true;
      } else { pen = false; }
    }
    ctx.stroke();
  }

  function label(text, x, y, color, align) {
    ctx.font = '600 11px "JetBrains Mono", ui-monospace, Menlo, monospace';
    var w = ctx.measureText(text).width + 14;
    var h = 20;
    var lx = align === 'left' ? x - w : x;
    lx = U.clamp(lx, 4, W - w - 4);
    var ly = U.clamp(y - h / 2, 4, H - h - 4);
    ctx.fillStyle = rgba(colors.bg, 0.78);
    ctx.beginPath();
    var r = 10;
    ctx.moveTo(lx + r, ly);
    ctx.arcTo(lx + w, ly, lx + w, ly + h, r);
    ctx.arcTo(lx + w, ly + h, lx, ly + h, r);
    ctx.arcTo(lx, ly + h, lx, ly, r);
    ctx.arcTo(lx, ly, lx + w, ly, r);
    ctx.fill();
    ctx.strokeStyle = rgba(color, 0.55);
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = rgba(color, 1);
    ctx.textBaseline = 'middle';
    ctx.fillText(text, lx + 7, ly + h / 2 + 0.5);
  }

  function draw() {
    if (!colors || !W) return;
    prep();
    var reduced = O.store.reducedMotion();
    var cstate = O.connect ? O.connect.state() : 'idle';
    var prog = O.connect ? O.connect.progress() : 0;
    ctx.clearRect(0, 0, W, H);

    /* Атмосфера. */
    var atm = ctx.createRadialGradient(CX, CY, RR * 0.92, CX, CY, RR * 1.3);
    atm.addColorStop(0, rgba(colors.accent, 0.2));
    atm.addColorStop(1, rgba(colors.accent, 0));
    ctx.fillStyle = atm;
    ctx.beginPath();
    ctx.arc(CX, CY, RR * 1.3, 0, 6.2832);
    ctx.fill();

    /* Шар. */
    var sph = ctx.createRadialGradient(CX - RR * 0.32, CY - RR * 0.38, RR * 0.1, CX, CY, RR * 1.08);
    sph.addColorStop(0, rgba(colors.s2, 1));
    sph.addColorStop(0.7, rgba(colors.s1, 1));
    sph.addColorStop(1, rgba(colors.bg, 1));
    ctx.fillStyle = sph;
    ctx.beginPath();
    ctx.arc(CX, CY, RR, 0, 6.2832);
    ctx.fill();

    /* Сетка. */
    ctx.lineWidth = 1;
    for (var gi = 0; gi < grat.length; gi++) {
      ctx.strokeStyle = rgba(colors.line, grat[gi].major ? 0.85 : 0.5);
      strokePoly(grat[gi].pts, 1);
    }

    /* Текстура: мелкая россыпь. */
    var i, c;
    for (i = 0; i < texture.length; i++) {
      proj(texture[i], 1, P);
      if (P.z <= 0.05) continue;
      ctx.fillStyle = rgba(colors.fg, 0.07 + 0.1 * P.z);
      ctx.fillRect(P.x - 0.5, P.y - 0.5, 1, 1);
    }

    /* Страны. */
    hits = [];
    var favs = O.store.get().favorites;
    for (i = 0; i < D.countries.length; i++) {
      c = D.countries[i];
      proj(c._v, 1, P);
      if (P.z <= 0.04) continue;
      var isFav = favs.indexOf(c.code) >= 0;
      var col = isFav ? colors.warn : c.premium ? colors.cool : colors.fg;
      var rad = (c.premium || isFav ? 2.1 : 1.6) * (0.6 + 0.4 * P.z);
      ctx.fillStyle = rgba(col, 0.28 + 0.72 * P.z);
      ctx.beginPath();
      ctx.arc(P.x, P.y, rad, 0, 6.2832);
      ctx.fill();
      hits.push({ c: c, x: P.x, y: P.y });
    }

    /* Дуга маршрута. */
    if (arc.length) drawArc(cstate, prog, reduced);

    /* Точка пользователя. */
    proj(userVec, 1, P);
    var uvis = P.z > 0;
    var ux = P.x, uy = P.y;
    if (uvis) {
      ctx.fillStyle = rgba(colors.cool, 0.25);
      ctx.beginPath(); ctx.arc(ux, uy, 8, 0, 6.2832); ctx.fill();
      ctx.fillStyle = rgba(colors.cool, 1);
      ctx.beginPath(); ctx.arc(ux, uy, 3.4, 0, 6.2832); ctx.fill();
    }

    /* Выбранная страна. */
    if (sel) {
      proj(sel._v, 1, P);
      if (P.z > 0) {
        var ringCol = cstate === 'failed' ? colors.danger : colors.accent;
        var pulse = reduced ? 0.4 : (now % 1.8) / 1.8;
        ctx.strokeStyle = rgba(ringCol, 0.7 * (1 - pulse));
        ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.arc(P.x, P.y, 5 + pulse * 15, 0, 6.2832); ctx.stroke();
        ctx.fillStyle = rgba(ringCol, 0.28);
        ctx.beginPath(); ctx.arc(P.x, P.y, 9, 0, 6.2832); ctx.fill();
        ctx.fillStyle = rgba(ringCol, 1);
        ctx.beginPath(); ctx.arc(P.x, P.y, 4.2, 0, 6.2832); ctx.fill();
        var nm = O.i18n.lang() === 'en' ? sel.en : sel.ru;
        label(nm, P.x + 12, P.y, ringCol, P.x > W * 0.62 ? 'left' : 'right');
        if (P.x > W * 0.62) { /* подпись слева, чтобы не уходить за край */ }
      }
    }
    if (uvis) {
      label(O.t('globe.you'), ux + (ux > W * 0.62 ? -12 : 12), uy + 18, colors.cool, ux > W * 0.62 ? 'left' : 'right');
    }

    /* Кромка шара. */
    ctx.strokeStyle = rgba(colors.accent, 0.35);
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(CX, CY, RR, 0, 6.2832);
    ctx.stroke();
  }

  function drawArc(cstate, prog, reduced) {
    var N = arc.length - 1;
    var col = cstate === 'failed' ? colors.danger : colors.accent;
    var upto = cstate === 'idle' ? 0 : Math.floor(prog * N);
    var i, p0 = null;

    /* Весь путь: пунктир. */
    ctx.setLineDash([3, 6]);
    ctx.lineWidth = 1.4;
    ctx.strokeStyle = rgba(col, cstate === 'idle' ? 0.55 : 0.3);
    ctx.beginPath();
    var pen = false;
    for (i = 0; i <= N; i++) {
      proj(arc[i].v, arc[i].r, P);
      if (P.vis) { if (pen) ctx.lineTo(P.x, P.y); else ctx.moveTo(P.x, P.y); pen = true; } else pen = false;
    }
    ctx.stroke();
    ctx.setLineDash([]);

    if (upto > 0) {
      /* Пройденная часть: сплошная. */
      ctx.lineWidth = 2.2;
      ctx.strokeStyle = rgba(col, 0.95);
      ctx.shadowColor = rgba(col, 0.8);
      ctx.shadowBlur = reduced ? 0 : 8;
      ctx.beginPath();
      pen = false;
      for (i = 0; i <= upto; i++) {
        proj(arc[i].v, arc[i].r, P);
        if (P.vis) { if (pen) ctx.lineTo(P.x, P.y); else ctx.moveTo(P.x, P.y); pen = true; } else pen = false;
      }
      ctx.stroke();
      ctx.shadowBlur = 0;
      proj(arc[upto].v, arc[upto].r, P);
      p0 = { x: P.x, y: P.y, vis: P.vis };
    }

    if (p0 && p0.vis) {
      if (cstate === 'connecting') {
        ctx.fillStyle = rgba(colors.fg, 1);
        ctx.beginPath(); ctx.arc(p0.x, p0.y, 3.2, 0, 6.2832); ctx.fill();
        ctx.fillStyle = rgba(col, 0.35);
        ctx.beginPath(); ctx.arc(p0.x, p0.y, 8, 0, 6.2832); ctx.fill();
      } else if (cstate === 'failed') {
        /* Крестик в месте обрыва. */
        ctx.strokeStyle = rgba(colors.danger, 1);
        ctx.lineWidth = 2.4;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(p0.x - 5, p0.y - 5); ctx.lineTo(p0.x + 5, p0.y + 5);
        ctx.moveTo(p0.x + 5, p0.y - 5); ctx.lineTo(p0.x - 5, p0.y + 5);
        ctx.stroke();
        ctx.lineCap = 'butt';
      }
    }
  }

  /* ------------------------------------------------------------------
   * Цикл
   * ------------------------------------------------------------------ */
  function update(dt) {
    var moving = false;
    var k = 1 - Math.exp(-dt * 3.4);
    var dLon = wrapAngle(target.lon - base.lon);
    var dLat = target.lat - base.lat;
    if (Math.abs(dLon) > 0.0004 || Math.abs(dLat) > 0.0004) {
      base.lon += dLon * k;
      base.lat += dLat * k;
      moving = true;
    }
    if (Math.abs(zoomT - zoom) > 0.002) { zoom += (zoomT - zoom) * k; moving = true; }
    if (!drag && now - lastTouch > 2.4 && (Math.abs(off.lon) > 0.001 || Math.abs(off.lat) > 0.001)) {
      var d = 1 - Math.min(1, dt * 1.1);
      off.lon *= d; off.lat *= d;
      moving = true;
    }
    return moving || !!drag;
  }

  function frame(ts) {
    raf = 0;
    if (!active) return;
    var dt = Math.min(0.06, lastTs ? (ts - lastTs) / 1000 : 0.016);
    lastTs = ts;
    now = ts / 1000;
    var moving = update(dt);
    var cstate = O.connect ? O.connect.state() : 'idle';
    var animate = !O.store.reducedMotion() || cstate === 'connecting';
    if (animate || moving || dirty) {
      draw();
      dirty = false;
    }
    raf = requestAnimationFrame(frame);
  }

  function schedule() {
    if (!raf && active && inited) { lastTs = 0; raf = requestAnimationFrame(frame); }
  }

  /* ------------------------------------------------------------------
   * Размер и события
   * ------------------------------------------------------------------ */
  function resize() {
    var rect = cv.getBoundingClientRect();
    if (!rect.width) return;
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = rect.width; H = rect.height;
    cv.width = Math.round(W * DPR);
    cv.height = Math.round(H * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    CX = W / 2; CY = H / 2;
    R = Math.min(W / 2, H / 2) * 0.84;
    dirty = true;
  }

  function localPoint(e) {
    var r = cv.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  function pick(pt) {
    var best = null, bd = 22 * 22;
    for (var i = 0; i < hits.length; i++) {
      var dx = hits[i].x - pt.x, dy = hits[i].y - pt.y, d = dx * dx + dy * dy;
      if (d < bd) { bd = d; best = hits[i]; }
    }
    return best;
  }

  function bind() {
    cv.addEventListener('pointerdown', function (e) {
      drag = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, moved: false };
      try { cv.setPointerCapture(e.pointerId); } catch (err) { /* нет захвата */ }
    });
    cv.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) > 5) drag.moved = true;
      if (drag.moved) {
        off.lon -= dx / RR;
        off.lat = U.clamp(off.lat + dy / RR, -1, 1);
        lastTouch = now;
        dirty = true;
        if (onPick) onPick(null);
      }
      drag.x = e.clientX; drag.y = e.clientY;
    });
    cv.addEventListener('pointerup', function (e) {
      if (!drag) return;
      var wasTap = !drag.moved;
      drag = null;
      lastTouch = now;
      if (wasTap && onPick) {
        var pt = localPoint(e);
        var h = pick(pt);
        onPick(h ? h.c : null, h ? h.x : 0, h ? h.y : 0);
      }
    });
    cv.addEventListener('pointercancel', function () { drag = null; });

    if (window.ResizeObserver) {
      ro = new ResizeObserver(function () { resize(); });
      ro.observe(cv);
    } else {
      window.addEventListener('resize', resize);
    }
  }

  /* ------------------------------------------------------------------
   * Публичный интерфейс
   * ------------------------------------------------------------------ */
  G.init = function (canvas, handlers) {
    cv = canvas;
    ctx = cv.getContext('2d');
    onPick = handlers && handlers.onPick;
    prepare();
    G.refreshColors();
    bind();
    resize();
    inited = true;
    schedule();
  };

  G.setSelected = function (code) {
    sel = D.byCode[code] || null;
    buildArc();
    if (onPick) onPick(null);
    schedule();
  };

  G.setActive = function (v) {
    active = !!v;
    if (active) { dirty = true; schedule(); }
    else if (raf) { cancelAnimationFrame(raf); raf = 0; }
  };

  G.requestDraw = function () { dirty = true; schedule(); };

  /** Расстояние до выбранного сервера, км. */
  G.distance = function () { return sel ? Math.round(sel.km) : 0; };
})(window.O = window.O || {});
