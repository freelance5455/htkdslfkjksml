/* Орбита VPN: service worker. Офлайн-кэш оболочки + рантайм-кэш шрифтов. */
const VERSION = 'orbita-2610-1';
const SHELL = VERSION + '-shell';
const RUNTIME = VERSION + '-rt';

const FILES = [
  './', 'index.html', 'manifest.webmanifest',
  'css/tokens.css', 'css/base.css', 'css/components.css', 'css/home.css', 'css/screens.css', 'css/overlays.css',
  'js/icons.js', 'js/util.js', 'js/data.js', 'js/store.js', 'js/i18n.js', 'js/ui.js', 'js/stars.js', 'js/globe.js',
  'js/connect.js', 'js/screens/home.js', 'js/screens/countries.js', 'js/screens/sub.js', 'js/screens/errors.js',
  'js/screens/settings.js', 'js/failsheet.js', 'js/diagnostics.js', 'js/drawer.js', 'js/onboarding.js', 'js/pwa.js', 'js/app.js',
  'icons/icon.svg', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/maskable-192.png', 'icons/maskable-512.png',
  'icons/apple-touch-icon.png', 'icons/favicon-32.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(FILES.map((f) => new Request(f, { cache: 'reload' })))));
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keep = [SHELL, RUNTIME];
    for (const k of await caches.keys()) if (!keep.includes(k)) await caches.delete(k);
    if (self.registration.navigationPreload) { try { await self.registration.navigationPreload.disable(); } catch (_) {} }
    await self.clients.claim();
  })());
});

self.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.type === 'SKIP_WAITING') self.skipWaiting();
  if (d.type === 'GET_VERSION' && e.source) e.source.postMessage({ type: 'VERSION', version: VERSION });
});

const FONT_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com'];

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Шрифты Google: stale-while-revalidate.
  if (FONT_HOSTS.includes(url.hostname)) {
    e.respondWith((async () => {
      const cache = await caches.open(RUNTIME);
      const hit = await cache.match(req);
      const net = fetch(req).then((r) => { if (r && (r.ok || r.type === 'opaque')) cache.put(req, r.clone()); return r; }).catch(() => null);
      return hit || (await net) || Response.error();
    })());
    return;
  }

  if (url.origin !== self.location.origin) return;

  // Навигация: оболочка из кэша, обновление в фоне.
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      const cache = await caches.open(SHELL);
      const cached = await cache.match('index.html');
      const net = fetch(req).then((r) => { if (r.ok) cache.put('index.html', r.clone()); return r; }).catch(() => null);
      return cached || (await net) || new Response('Offline', { status: 503 });
    })());
    return;
  }

  // Остальное своё: сначала кэш, потом сеть с докладыванием в кэш.
  e.respondWith((async () => {
    const hit = await caches.match(req, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const r = await fetch(req);
      if (r.ok) (await caches.open(RUNTIME)).put(req, r.clone());
      return r;
    } catch (_) {
      return new Response('', { status: 504 });
    }
  })());
});
