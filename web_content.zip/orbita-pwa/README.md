# Орбита VPN: PWA

Установка и офлайн работают только по HTTPS (или на localhost). Открывать index.html двойным кликом нельзя: service worker не запустится.

## Проверить у себя
    python3 -m http.server 8080
    # открыть http://localhost:8080

## Выложить (бесплатно, HTTPS из коробки)
- Netlify: drag-and-drop папки на app.netlify.com/drop
- Cloudflare Pages / Vercel / GitHub Pages: залить папку как статический сайт, сборка не нужна

## Установка
- Android/Chrome, desktop Chrome/Edge: кнопка «Установить на экран» в Настройках → Приложение
- iPhone/iPad: Safari → Поделиться → «На экран Домой»

## Обновление
Поменяй `VERSION` в sw.js (например orbita-2610-2) и перезалей. У пользователей появится тост «Доступна новая версия».

## Иконки
`python3 tools/make_icons.py` (нужен Pillow) перерисует PNG в icons/.

Шрифты (Google Fonts) кэшируются при первом онлайн-запуске; до этого офлайн работает на системных шрифтах.
