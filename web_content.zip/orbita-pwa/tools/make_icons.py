#!/usr/bin/env python3
"""Рисует иконки Орбиты. Запуск: python3 tools/make_icons.py (нужен Pillow)."""
import math, os, random
from PIL import Image, ImageDraw, ImageFilter

OUT = os.path.join(os.path.dirname(__file__), '..', 'icons')
SS = 4  # суперсэмплинг для гладких линий

BG_IN, BG_OUT = (30, 26, 80), (10, 8, 32)
RING = (74, 67, 160)
CORE = (30, 26, 75)
AMBER = (255, 179, 64)
COOL = (111, 214, 255)


def artwork(size, scale=1.0, bg='full', radius_frac=0.22):
    """bg: 'full' заливка во весь квадрат, 'round' скруглённый квадрат на прозрачном фоне."""
    S = size * SS
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))

    # фон: радиальный градиент
    grad = Image.new('RGBA', (S, S))
    gp = grad.load()
    cx, cy = S * 0.5, S * 0.42
    maxd = S * 0.75
    for y in range(S):
        for x in range(S):
            d = min(1.0, math.hypot(x - cx, y - cy) / maxd)
            gp[x, y] = tuple(int(BG_IN[i] + (BG_OUT[i] - BG_IN[i]) * d) for i in range(3)) + (255,)
    if bg == 'round':
        mask = Image.new('L', (S, S), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * radius_frac), fill=255)
        img.paste(grad, (0, 0), mask)
    else:
        img.paste(grad, (0, 0))

    d = ImageDraw.Draw(img)

    # звёзды
    rnd = random.Random(7)
    for _ in range(26):
        x, y = rnd.uniform(0.06, 0.94) * S, rnd.uniform(0.06, 0.94) * S
        if math.hypot(x - S / 2, y - S / 2) < S * 0.30 * scale + S * 0.05:
            continue
        r = rnd.choice((1.2, 1.6, 2.2)) * SS * size / 256
        a = rnd.randint(90, 200)
        d.ellipse((x - r, y - r, x + r, y + r), fill=(238, 233, 255, a))

    c = S / 2
    R = S * 0.355 * scale

    # внешнее кольцо
    w = max(2, int(S * 0.022 * scale))
    d.ellipse((c - R, c - R, c + R, c + R), outline=RING + (255,), width=w)
    # пунктирное внутреннее кольцо
    R2 = R * 0.72
    n = 36
    for i in range(n):
        a0 = i * 360 / n
        d.arc((c - R2, c - R2, c + R2, c + R2), a0, a0 + 360 / n * 0.35, fill=RING + (200,), width=max(2, int(w * 0.6)))

    # свечение ядра
    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    rc = R * 0.46
    gd.ellipse((c - rc * 1.5, c - rc * 1.5, c + rc * 1.5, c + rc * 1.5), fill=AMBER + (120,))
    glow = glow.filter(ImageFilter.GaussianBlur(S * 0.03 * scale))
    img = Image.alpha_composite(img, glow)
    d = ImageDraw.Draw(img)

    # ядро
    d.ellipse((c - rc, c - rc, c + rc, c + rc), fill=CORE + (255,), outline=AMBER + (255,), width=max(3, int(S * 0.03 * scale)))

    # спутники
    for ang, rr, col in ((-52, 0.058, AMBER), (128, 0.036, COOL)):
        x = c + R * math.cos(math.radians(ang))
        y = c + R * math.sin(math.radians(ang))
        r = S * rr * scale
        halo = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        ImageDraw.Draw(halo).ellipse((x - r * 2, y - r * 2, x + r * 2, y + r * 2), fill=col + (110,))
        halo = halo.filter(ImageFilter.GaussianBlur(r * 0.8))
        img = Image.alpha_composite(img, halo)
        d = ImageDraw.Draw(img)
        d.ellipse((x - r, y - r, x + r, y + r), fill=col + (255,))

    return img.resize((size, size), Image.LANCZOS)


def save(img, name):
    path = os.path.join(OUT, name)
    img.save(path, optimize=True)
    print('wrote', name, img.size)


os.makedirs(OUT, exist_ok=True)
save(artwork(192, 1.0, 'round'), 'icon-192.png')
save(artwork(512, 1.0, 'round'), 'icon-512.png')
# maskable: безопасная зона 80%, поэтому рисунок меньше, фон на весь квадрат
save(artwork(512, 0.66, 'full'), 'maskable-512.png')
save(artwork(192, 0.66, 'full'), 'maskable-192.png')
# iOS сам скругляет и не любит прозрачность
save(artwork(180, 0.82, 'full').convert('RGB'), 'apple-touch-icon.png')
save(artwork(32, 1.0, 'round'), 'favicon-32.png')
