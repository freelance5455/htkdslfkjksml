const fs = require('fs');
let code = fs.readFileSync('src/App.tsx', 'utf8');

const targetImport = `import { OwnerUpdateView } from './components/OwnerUpdateView';`;
const replaceImport = `import React, { lazy, Suspense } from 'react';\nconst OwnerUpdateView = lazy(() => import('./components/OwnerUpdateView').then(m => ({ default: m.OwnerUpdateView })));`;

if (code.includes(targetImport)) {
  code = code.replace(targetImport, replaceImport);
}

const targetRender = `{currentTab === 'owner' && isOwnerSession && <OwnerUpdateView />}`;
const replaceRender = `{currentTab === 'owner' && isOwnerSession && (
          <Suspense fallback={<div className="p-10 text-amber-500 font-bold text-center">Authenticating Owner Vault...</div>}>
            <OwnerUpdateView />
          </Suspense>
        )}`;

if (code.includes(targetRender)) {
  code = code.replace(targetRender, replaceRender);
}

// Remove duplicated import React if it exists
if (code.includes(`import React, { useState`)) {
  code = code.replace(`import React, { lazy, Suspense } from 'react';\n`, '');
  code = code.replace(`import React, { useState`, `import React, { useState, lazy, Suspense`);
}

fs.writeFileSync('src/App.tsx', code);
console.log("App patched");
