# AuraFocus – Web App (PWA)

Beautiful Pomodoro focus timer + ambient sounds + streaks + stats.

## Features
- 25 / 5 / 15 min timer modes
- Animated progress ring
- Ambient sounds (Rain, Forest, Café + 4 premium)
- Daily focus minutes, streak & total sessions
- Premium unlock (demo mode – instant unlock)
- Fully offline-capable Progressive Web App
- Installable on Android / iOS home screen

## How to Test the Web App Right Now

### Option A – Local file
1. Open the folder `AuraFocus`
2. Double-click `index.html` (or open it in Chrome/Edge)

### Option B – Better (recommended)
Serve it with any simple server so PWA features work:

```bash
# From inside the AuraFocus folder
python3 -m http.server 8080
```

Then open: http://localhost:8080

On your phone: open the same URL (use your computer’s IP if on same Wi-Fi).

### Install as App on Android
1. Open the site in Chrome
2. Tap the 3-dot menu → “Add to Home screen” or “Install app”
3. It will appear like a native app (fullscreen, no browser bar)

---

## How to Convert This Web App into a Real Android APK

There are 3 excellent modern ways. Ranked by recommendation:

### Method 1: Capacitor (Best & Most Powerful) ★ Recommended

Capacitor turns your web app into a real native Android (and iOS) project while keeping full access to native APIs (AdMob, In-App Purchases, notifications, etc.).

#### Steps:

1. **Install Node.js** (if you don’t have it)  
   https://nodejs.org

2. **Create a new Capacitor project and copy your files**

```bash
npm create @capacitor/app@latest
# Choose name: AuraFocus, package: com.yourname.aurafocus

cd aurafocus          # or whatever folder was created
```

3. **Replace the web assets**
- Delete everything inside the `www` or `dist` folder
- Copy all files from this AuraFocus folder into `www/` (or the webDir)

4. **Install Android platform**

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap add android
npx cap sync
```

5. **Open in Android Studio**

```bash
npx cap open android
```

6. **Build APK**
- In Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s)
- The debug APK will be in `android/app/build/outputs/apk/debug/`

7. **Add real monetization later**
- AdMob: install `@capacitor-community/admob`
- In-App Purchase: `@capgo/capacitor-purchases` or official Google Play Billing

### Method 2: PWABuilder + Bubblewrap (Trusted Web Activity)

Very easy, produces a lightweight APK that wraps your hosted PWA.

1. Go to https://www.pwabuilder.com
2. Enter the URL where your AuraFocus is hosted
3. Click “Package for stores” → Android
4. Download the project and follow the short instructions (uses Bubblewrap)
5. You get a signed APK ready for testing / Play Store

### Method 3: Apache Cordova (Older but still works)

```bash
npm install -g cordova
cordova create AuraFocusApp com.yourname.aurafocus AuraFocus
cd AuraFocusApp
# Replace www/ contents with this project’s files
cordova platform add android
cordova build android
```

APK will be in `platforms/android/app/build/outputs/apk/`

---

## Revenue Setup (After you have the APK)

1. **AdMob** – Create account → App → Ad units (Banner + Interstitial + Rewarded)
2. **Play Console** – Create app → set up In-App Product “premium_unlock”
3. Connect them via Capacitor plugins

---

## Next Steps I can help you with

Just tell me:
- “Add AdMob placeholders to the web version”
- “Make the timer durations customizable”
- “Add a simple weekly chart”
- “Generate the Capacitor project structure for me”
- “Help me with Play Store listing text”

Enjoy focusing with AuraFocus!  
Built with ❤️ by Grok
