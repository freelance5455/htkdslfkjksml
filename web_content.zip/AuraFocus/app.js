// ======================
// AuraFocus - Core Logic
// ======================

const MODES = {
  focus: { minutes: 25, label: "Focus Time", color: "#7c6aff" },
  short: { minutes: 5,  label: "Short Break", color: "#ff9f43" },
  long:  { minutes: 15, label: "Long Break", color: "#00d4aa" }
};

const SOUNDS = [
  { id: "none",     name: "None",     icon: "🔇", premium: false },
  { id: "rain",     name: "Rain",     icon: "🌧️", premium: false },
  { id: "forest",   name: "Forest",   icon: "🌲", premium: false },
  { id: "cafe",     name: "Café",     icon: "☕", premium: false },
  { id: "waves",    name: "Waves",    icon: "🌊", premium: true  },
  { id: "fire",     name: "Fireplace",icon: "🔥", premium: true  },
  { id: "wind",     name: "Wind",     icon: "💨", premium: true  },
  { id: "night",    name: "Night",    icon: "🌙", premium: true  }
];

// State
let state = {
  mode: "focus",
  remaining: 25 * 60,
  total: 25 * 60,
  isRunning: false,
  interval: null,
  currentSound: "none",
  isPremium: false,
  stats: {
    todayFocusMinutes: 0,
    streak: 0,
    totalSessions: 0,
    lastDate: null
  }
};

// DOM
const timeDisplay = document.getElementById("timeDisplay");
const sessionLabel = document.getElementById("sessionLabel");
const startPauseBtn = document.getElementById("startPauseBtn");
const startPauseIcon = document.getElementById("startPauseIcon");
const resetBtn = document.getElementById("resetBtn");
const skipBtn = document.getElementById("skipBtn");
const progressCircle = document.querySelector(".progress-ring-circle");
const soundGrid = document.getElementById("soundGrid");
const volumeSlider = document.getElementById("volumeSlider");
const premiumBtn = document.getElementById("premiumBtn");
const premiumModal = document.getElementById("premiumModal");
const closePremium = document.getElementById("closePremium");
const buyPremiumBtn = document.getElementById("buyPremiumBtn");
const toast = document.getElementById("toast");

const CIRCUMFERENCE = 2 * Math.PI * 90; // r=90

// ---------- Persistence ----------
function loadState() {
  try {
    const saved = localStorage.getItem("aurafocus");
    if (saved) {
      const data = JSON.parse(saved);
      state.isPremium = data.isPremium || false;
      state.stats = data.stats || state.stats;
      state.currentSound = data.currentSound || "none";
      checkStreak();
    }
  } catch (e) {}
  updatePremiumUI();
  updateStatsUI();
}

function saveState() {
  localStorage.setItem("aurafocus", JSON.stringify({
    isPremium: state.isPremium,
    stats: state.stats,
    currentSound: state.currentSound
  }));
}

function checkStreak() {
  const today = new Date().toDateString();
  if (state.stats.lastDate === today) return;

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (state.stats.lastDate === yesterday.toDateString()) {
    // streak continues (will increment on session complete)
  } else if (state.stats.lastDate !== today) {
    state.stats.streak = 0;
  }
}

// ---------- Timer ----------
function setMode(mode) {
  if (state.isRunning) stopTimer();
  state.mode = mode;
  state.total = MODES[mode].minutes * 60;
  state.remaining = state.total;
  updateDisplay();
  updateProgress();
  document.body.classList.toggle("break", mode !== "focus");
  document.body.classList.remove("running");

  document.querySelectorAll(".mode-tab").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.mode === mode);
  });
}

function updateDisplay() {
  const m = Math.floor(state.remaining / 60);
  const s = state.remaining % 60;
  timeDisplay.textContent = `${m.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`;
  sessionLabel.textContent = state.isRunning ? MODES[state.mode].label : "Ready to focus";
}

function updateProgress() {
  const progress = state.remaining / state.total;
  const offset = CIRCUMFERENCE * (1 - progress);
  progressCircle.style.strokeDasharray = CIRCUMFERENCE;
  progressCircle.style.strokeDashoffset = offset;
}

function startTimer() {
  if (state.remaining <= 0) return;
  state.isRunning = true;
  document.body.classList.add("running");
  startPauseIcon.textContent = "⏸";
  sessionLabel.textContent = MODES[state.mode].label;

  state.interval = setInterval(() => {
    state.remaining--;
    updateDisplay();
    updateProgress();

    if (state.remaining <= 0) {
      completeSession();
    }
  }, 1000);
}

function stopTimer() {
  state.isRunning = false;
  clearInterval(state.interval);
  document.body.classList.remove("running");
  startPauseIcon.textContent = "▶";
  sessionLabel.textContent = "Paused";
}

function toggleTimer() {
  if (state.isRunning) stopTimer();
  else startTimer();
}

function resetTimer() {
  stopTimer();
  state.remaining = state.total;
  updateDisplay();
  updateProgress();
  sessionLabel.textContent = "Ready to focus";
}

function skipTimer() {
  if (state.isRunning) stopTimer();
  // Move to next logical mode
  if (state.mode === "focus") {
    // After focus → short break (or long every 4 sessions - simplified)
    setMode("short");
  } else {
    setMode("focus");
  }
}

function completeSession() {
  stopTimer();
  playCompletionSound();

  if (state.mode === "focus") {
    state.stats.todayFocusMinutes += MODES.focus.minutes;
    state.stats.totalSessions += 1;

    const today = new Date().toDateString();
    if (state.stats.lastDate !== today) {
      state.stats.streak += 1;
      state.stats.lastDate = today;
    }
    saveState();
    updateStatsUI();
    showToast(`Focus complete! +${MODES.focus.minutes} min 🎉`);
  } else {
    showToast("Break finished. Back to focus!");
  }

  // Auto switch
  if (state.mode === "focus") setMode("short");
  else setMode("focus");
}

// ---------- Sounds (Web Audio simple generators for zero external files) ----------
let audioCtx = null;
let currentOsc = null;
let currentGain = null;
let noiseNode = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === "suspended") audioCtx.resume();
}

function stopSound() {
  if (currentOsc) {
    try { currentOsc.stop(); } catch(e){}
    currentOsc = null;
  }
  if (noiseNode) {
    try { noiseNode.stop(); } catch(e){}
    noiseNode = null;
  }
  if (currentGain) {
    currentGain.disconnect();
    currentGain = null;
  }
}

function playSound(id) {
  stopSound();
  if (id === "none") return;

  initAudio();
  const vol = parseFloat(volumeSlider.value);

  currentGain = audioCtx.createGain();
  currentGain.gain.value = vol * 0.3;
  currentGain.connect(audioCtx.destination);

  if (id === "rain" || id === "waves" || id === "wind" || id === "fire") {
    // White / pink-ish noise
    const bufferSize = 2 * audioCtx.sampleRate;
    const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    noiseNode = audioCtx.createBufferSource();
    noiseNode.buffer = buffer;
    noiseNode.loop = true;

    // Simple filter to color the noise
    const filter = audioCtx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = id === "rain" ? 800 : id === "waves" ? 400 : id === "fire" ? 600 : 1200;

    noiseNode.connect(filter);
    filter.connect(currentGain);
    noiseNode.start();
  } else if (id === "forest" || id === "cafe" || id === "night") {
    // Soft drone + occasional tones
    currentOsc = audioCtx.createOscillator();
    currentOsc.type = "sine";
    currentOsc.frequency.value = id === "forest" ? 110 : id === "cafe" ? 220 : 80;
    currentOsc.connect(currentGain);
    currentOsc.start();
  }
}

function playCompletionSound() {
  initAudio();
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  osc.frequency.value = 880;
  gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.8);
  osc.start();
  osc.stop(audioCtx.currentTime + 0.8);
}

// ---------- UI Builders ----------
function buildSoundGrid() {
  soundGrid.innerHTML = "";
  SOUNDS.forEach(s => {
    const btn = document.createElement("button");
    btn.className = "sound-btn";
    if (s.id === state.currentSound) btn.classList.add("active");
    if (s.premium && !state.isPremium) btn.classList.add("locked");

    btn.innerHTML = `<span class="icon">${s.icon}</span><span>${s.name}</span>`;
    btn.onclick = () => {
      if (s.premium && !state.isPremium) {
        openPremium();
        return;
      }
      state.currentSound = s.id;
      document.querySelectorAll(".sound-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      playSound(s.id);
      saveState();
    };
    soundGrid.appendChild(btn);
  });
}

function updateStatsUI() {
  document.getElementById("todayFocus").textContent = state.stats.todayFocusMinutes;
  document.getElementById("streak").textContent = state.stats.streak;
  document.getElementById("totalSessions").textContent = state.stats.totalSessions;
}

function updatePremiumUI() {
  if (state.isPremium) {
    premiumBtn.textContent = "✦ Premium";
    premiumBtn.classList.add("unlocked");
    buyPremiumBtn.textContent = "Already Unlocked ✓";
    buyPremiumBtn.disabled = true;
  }
  buildSoundGrid();
}

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2800);
}

function openPremium() {
  premiumModal.classList.remove("hidden");
}

function closePremiumModal() {
  premiumModal.classList.add("hidden");
}

// ---------- Events ----------
document.querySelectorAll(".mode-tab").forEach(tab => {
  tab.addEventListener("click", () => setMode(tab.dataset.mode));
});

startPauseBtn.addEventListener("click", toggleTimer);
resetBtn.addEventListener("click", resetTimer);
skipBtn.addEventListener("click", skipTimer);

volumeSlider.addEventListener("input", () => {
  if (currentGain) currentGain.gain.value = parseFloat(volumeSlider.value) * 0.3;
});

premiumBtn.addEventListener("click", openPremium);
closePremium.addEventListener("click", closePremiumModal);
premiumModal.addEventListener("click", (e) => {
  if (e.target === premiumModal) closePremiumModal();
});

buyPremiumBtn.addEventListener("click", () => {
  // Demo: unlock instantly (in real app → real payment)
  state.isPremium = true;
  saveState();
  updatePremiumUI();
  closePremiumModal();
  showToast("Welcome to Premium! ✨ All sounds unlocked");
});

// Prevent sleep while running (best effort)
let wakeLock = null;
async function requestWakeLock() {
  try {
    if ("wakeLock" in navigator && state.isRunning) {
      wakeLock = await navigator.wakeLock.request("screen");
    }
  } catch (e) {}
}

// Init
loadState();
setMode("focus");
buildSoundGrid();
updateProgress();

// Service Worker for PWA
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}
