import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let cachedBundleHtml: string | null = null;

function encodeImagesToDataUriMap(): Record<string, string> {
  const imagesDir = path.resolve(__dirname, 'src/assets/images');
  const map: Record<string, string> = {};
  if (!fs.existsSync(imagesDir)) return map;

  for (const file of fs.readdirSync(imagesDir)) {
    if (file.endsWith('.jpg') || file.endsWith('.jpeg') || file.endsWith('.png')) {
      const fullPath = path.join(imagesDir, file);
      const ext = file.endsWith('.png') ? 'image/png' : 'image/jpeg';
      const b64 = fs.readFileSync(fullPath).toString('base64');
      map[`/src/assets/images/${file}`] = `data:${ext};base64,${b64}`;
    }
  }
  return map;
}

export async function generateStandaloneHtml(serverOrigin: string): Promise<string> {
  const distDir = path.resolve(__dirname, 'dist');
  const distIndex = path.join(distDir, 'index.html');

  // Ensure a fresh production dist build exists
  if (!fs.existsSync(distIndex) || !cachedBundleHtml) {
    const { build } = await import('vite');
    await build({
      root: __dirname,
      logLevel: 'silent',
    });
  }

  let html = fs.readFileSync(distIndex, 'utf-8');
  const imageMap = encodeImagesToDataUriMap();

  // Inline stylesheet links
  html = html.replace(
    /<link\s+rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g,
    (_match, href: string) => {
      const relPath = href.replace(/^\//, '');
      const cssFile = path.join(distDir, relPath);
      if (fs.existsSync(cssFile)) {
        const cssContent = fs.readFileSync(cssFile, 'utf-8');
        return `<style>${cssContent}</style>`;
      }
      return '';
    }
  );

  // Inline module script and embed image assets as base64 data URIs
  html = html.replace(
    /<script\s+type="module"[^>]*src="([^"]+)"[^>]*><\/script>/g,
    (_match, src: string) => {
      const relPath = src.replace(/^\//, '');
      const jsFile = path.join(distDir, relPath);
      if (!fs.existsSync(jsFile)) return '';

      let jsContent = fs.readFileSync(jsFile, 'utf-8');
      for (const [assetUrl, dataUri] of Object.entries(imageMap)) {
        jsContent = jsContent.split(assetUrl).join(dataUri);
      }
      // Escape </script> inside bundled strings
      jsContent = jsContent.replace(/<\/script>/gi, '<\\/script>');

      const bootstrap = `<script>window.__ARI_UNO_STANDALONE__=true;window.__ARI_UNO_SERVER_URL__=${JSON.stringify(
        serverOrigin
      )};</script>`;
      return `${bootstrap}<script type="module">${jsContent}</script>`;
    }
  );

  cachedBundleHtml = html;
  return html;
}
