# Keshri Nandan Manufacturing ERP — Source Code

## What is included
- React + TypeScript + Vite frontend
- Offline-first service worker and installable web-app manifest
- Local device storage using `localStorage`
- Manufacturing modules: product master, material master, sales, purchases, production, BOM, material issue, expenses, journal/accounts, cash book, attendance, employee payment and assets
- Four-decimal numeric entry/display (example: `1.6447`)
- Add, edit, delete, search, Excel import/export and JSON backup/restore

## Requirements
- Node.js 18+ (Node 20 LTS recommended)
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Build for deployment
```bash
npm run build
npm run preview
```
The production build is generated in `dist/`.

## Offline operation
The service worker caches the application shell and runtime assets after the first successful online visit. Open the app once while online, then revisit it while offline. Browser storage belongs to that device/browser profile; use **Backup JSON** regularly and store the backup somewhere safe. Clearing browser data can erase local records.

## Decimal precision
Numeric fields use `step="any"` and JavaScript number storage. Display formatting uses `maximumFractionDigits: 4`, so values such as `1.6447` are retained and shown without rounding to two decimal places.

## Workbook compatibility
Excel import attempts to match workbook sheet names to the module names. Export creates one sheet per ERP module. Review imported values and sheet mappings before using the data for accounting or statutory reporting.

## Project layout
- `src/App.tsx` — ERP modules, local persistence, CRUD, stock summaries, import/export
- `src/style.css` — responsive interface
- `src/main.tsx` — React entry point
- `public/sw.js` — offline cache
- `public/manifest.json` — installable app metadata
- `vite.config.ts`, `tsconfig.json`, `package.json` — build configuration
