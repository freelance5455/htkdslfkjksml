#!/usr/bin/env python3
"""Code-drawn AeroPulse share cards. Gen APIs were out of credits."""

from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

OUT = Path("/workspace/.grok")
FONTS = OUT / "fonts"

BG = (7, 8, 12, 255)
FG = (238, 241, 246, 255)
STEEL = (139, 147, 167, 255)
LIFT = (46, 229, 157, 255)
CRASH = (255, 59, 59, 255)
PLANE = (255, 45, 45, 255)
PLANE_DARK = (200, 30, 30, 255)
PLANE_LIGHT = (255, 217, 217, 255)
NOSE = (255, 245, 245, 255)


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(path), size)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def exp_path(
    n: int, x0: float, y0: float, x1: float, y1: float, k: float = 2.6
) -> list[tuple[float, float]]:
    pts: list[tuple[float, float]] = []
    den = math.exp(k) - 1
    for i in range(n):
        t = i / (n - 1)
        x = lerp(x0, x1, t)
        climb = (math.exp(k * t) - 1) / den
        y = lerp(y0, y1, climb)
        pts.append((x, y))
    return pts


def tangent(pts: list[tuple[float, float]], i: int) -> float:
    a = pts[max(0, i - 3)]
    b = pts[min(len(pts) - 1, i)]
    return math.atan2(b[1] - a[1], b[0] - a[0])


def new_canvas(w: int, h: int) -> Image.Image:
    return Image.new("RGBA", (w, h), BG)


def add_vignette(im: Image.Image, strength: float = 0.62) -> None:
    w, h = im.size
    # White disc, invert after blur → dark edges.
    hole = Image.new("L", (w, h), 0)
    ImageDraw.Draw(hole).ellipse(
        (-int(w * 0.08), -int(h * 0.12), int(w * 1.08), int(h * 1.12)),
        fill=255,
    )
    hole = hole.filter(ImageFilter.GaussianBlur(max(24, min(w, h) // 6)))
    alpha = hole.point(lambda p: int((255 - p) * strength))
    vg = Image.new("RGBA", (w, h), (0, 0, 0, 255))
    vg.putalpha(alpha)
    im.alpha_composite(vg)


def add_stars(im: Image.Image, n: int, seed: int, scale: float = 1.0) -> None:
    rng = random.Random(seed)
    d = ImageDraw.Draw(im)
    w, h = im.size
    for _ in range(n):
        x = rng.random() * w
        y = rng.random() * h
        r = (rng.random() * 1.4 + 0.4) * scale
        a = int(40 + rng.random() * 120)
        d.ellipse((x - r, y - r, x + r, y + r), fill=(238, 241, 246, a))


def add_grid(im: Image.Image, origin: tuple[float, float], plot_w: float, plot_h: float) -> None:
    d = ImageDraw.Draw(im)
    ox, oy = origin
    w, _h = im.size
    for i in range(5):
        y = oy - (i / 4) * plot_h
        d.line((ox, y, w - 24, y), fill=(238, 241, 246, 16), width=1)
    for i in range(7):
        x = ox + (i / 6) * plot_w
        d.line((x, 20, x, oy), fill=(238, 241, 246, 14), width=1)
    d.line((ox, 20, ox, oy), fill=(238, 241, 246, 40), width=2)
    d.line((ox, oy, w - 24, oy), fill=(238, 241, 246, 40), width=2)


def glow_polyline(
    im: Image.Image,
    pts: list[tuple[float, float]],
    color: tuple[int, int, int],
    width: int,
    blur: float,
    glow_alpha: int = 170,
) -> None:
    size = im.size
    glow = Image.new("RGBA", size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    ip = [(round(x), round(y)) for x, y in pts]
    gd.line(ip, fill=(*color[:3], glow_alpha), width=width + int(blur * 2.2), joint="curve")
    glow = glow.filter(ImageFilter.GaussianBlur(blur))
    im.alpha_composite(glow)
    sharp = Image.new("RGBA", size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(sharp)
    sd.line(ip, fill=(*color[:3], 255), width=width, joint="curve")
    im.alpha_composite(sharp)


def fill_under(
    im: Image.Image,
    pts: list[tuple[float, float]],
    origin_y: float,
    top_rgba: tuple[int, int, int, int],
    bot_rgba: tuple[int, int, int, int],
) -> None:
    w, h = im.size
    y0 = min(p[1] for p in pts)
    span = max(1.0, origin_y - y0)
    col_img = Image.new("RGBA", (1, h))
    col_img.putdata(
        [
            tuple(int(lerp(top_rgba[i], bot_rgba[i], max(0.0, min(1.0, (y - y0) / span)))) for i in range(4))
            for y in range(h)
        ]
    )
    grad = col_img.resize((w, h), Image.Resampling.BILINEAR)
    mask = Image.new("L", (w, h), 0)
    poly = [(round(x), round(y)) for x, y in pts]
    poly += [(poly[-1][0], round(origin_y)), (poly[0][0], round(origin_y))]
    ImageDraw.Draw(mask).polygon(poly, fill=255)
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    layer.paste(grad, mask=mask)
    im.alpha_composite(layer)


def draw_plane(im: Image.Image, x: float, y: float, angle: float, scale: float) -> None:
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    ca, sa = math.cos(angle), math.sin(angle)

    def xf(px: float, py: float) -> tuple[float, float]:
        return (x + (px * ca - py * sa) * scale, y + (px * sa + py * ca) * scale)

    body = [xf(18, 0), xf(8, -4.2), xf(-14, -4), xf(-18, -9), xf(-20, -4), xf(-16, 0),
            xf(-20, 4), xf(-18, 8), xf(-14, 3), xf(8, 3.6)]
    # glow
    glow = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow).polygon(body, fill=CRASH[:3] + (140,))
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(6 * scale / 3)))
    d.polygon(body, fill=PLANE)
    d.polygon([xf(-2, 0), xf(-8, 9), xf(2, 1)], fill=PLANE_DARK)
    # canopy
    cx, cy = xf(6, -0.5)
    rx, ry = 3.2 * scale, 1.5 * scale
    d.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=PLANE_LIGHT)
    d.polygon([xf(18, 0), xf(12, -2), xf(12, 2)], fill=NOSE)
    im.alpha_composite(layer)


def tracked_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    xy: tuple[float, float],
    font_: ImageFont.FreeTypeFont,
    fill,
    tracking: float,
    anchor: str = "lt",
) -> tuple[float, float]:
    widths = [font_.getlength(ch) for ch in text]
    total = sum(widths) + tracking * max(0, len(text) - 1)
    x, y = xy
    if "m" in anchor:
        x -= total / 2
    elif "r" in anchor:
        x -= total
    if anchor[0] == "m":
        ascent, descent = font_.getmetrics()
        y -= (ascent - descent) / 2
    for ch, w in zip(text, widths):
        draw.text((x, y), ch, font=font_, fill=fill)
        x += w + tracking
    return total, font_.getmetrics()[0]


def text_halo(im: Image.Image, render_fn, blur: float = 6) -> None:
    halo = Image.new("RGBA", im.size, (0, 0, 0, 0))
    hd = ImageDraw.Draw(halo)
    render_fn(hd, (0, 0, 0, 220))
    im.alpha_composite(halo.filter(ImageFilter.GaussianBlur(blur)))
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    render_fn(ImageDraw.Draw(layer), FG)
    im.alpha_composite(layer)


def pulse_ticks(im: Image.Image, pts: list[tuple[float, float]], every: int, scale: float) -> None:
    d = ImageDraw.Draw(im)
    for i in range(every, len(pts) - 4, every):
        x, y = pts[i]
        ang = tangent(pts, i) + math.pi / 2
        r = 5 * scale
        x2, y2 = x + math.cos(ang) * r, y + math.sin(ang) * r
        d.line((x, y, x2, y2), fill=LIFT[:3] + (180,), width=max(2, int(2 * scale)))


def render_og(path: Path) -> None:
    scale = 2
    w, h = 1200 * scale, 630 * scale
    im = new_canvas(w, h)
    # ambient glows
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((w * 0.55, -h * 0.15, w * 1.15, h * 0.7), fill=CRASH[:3] + (50,))
    gd.ellipse((-w * 0.1, h * 0.35, w * 0.55, h * 1.15), fill=LIFT[:3] + (28,))
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(90)))
    add_stars(im, 90, seed=11, scale=scale)

    origin = (72 * scale, h - 56 * scale)
    plot_w, plot_h = w - origin[0] - 40 * scale, h - 90 * scale
    add_grid(im, origin, plot_w, plot_h)

    pts = exp_path(
        280,
        origin[0],
        origin[1],
        w - 90 * scale,
        92 * scale,
        k=2.55,
    )
    fill_under(im, pts, origin[1], CRASH[:3] + (110,), CRASH[:3] + (8,))
    glow_polyline(im, pts, CRASH, width=7 * scale, blur=10 * scale, glow_alpha=160)
    pulse_ticks(im, pts, every=22, scale=scale)
    # green pulse ribbon under the red stroke, faint
    glow_polyline(im, pts[::], LIFT, width=2 * scale, blur=4 * scale, glow_alpha=70)

    pi = int(len(pts) * 0.92)
    ang = tangent(pts, pi)
    draw_plane(im, pts[pi][0], pts[pi][1], ang, scale=3.4 * scale / 2)

    add_vignette(im, 0.58)

    display = font(FONTS / "rajdhani-700.ttf", 152 * scale)
    tag_f = font(FONTS / "ibm-plex-mono-500.ttf", 20 * scale)

    cx = w / 2
    # Final-pixel lockup (middle half of 630 is 158–472): AERO 236, PULSE 372, tag 458
    title_y1 = 236 * scale
    title_y2 = 372 * scale
    tag_y = 458 * scale

    def titles(draw: ImageDraw.ImageDraw, fill) -> None:
        tracked_text(draw, "AERO", (cx, title_y1), display, fill, tracking=14 * scale, anchor="mm")
        tracked_text(draw, "PULSE", (cx, title_y2), display, fill, tracking=14 * scale, anchor="mm")

    text_halo(im, titles, blur=10)

    tag_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    td = ImageDraw.Draw(tag_layer)
    tracked_text(
        td,
        "CASH BEFORE THE CRASH",
        (cx, tag_y),
        tag_f,
        STEEL,
        tracking=6 * scale,
        anchor="mm",
    )
    im.alpha_composite(tag_layer)

    # live pip
    d = ImageDraw.Draw(im)
    d.ellipse((w - 54 * scale, 36 * scale, w - 38 * scale, 52 * scale), fill=LIFT)

    out = im.resize((1200, 630), Image.Resampling.LANCZOS).convert("RGB")
    out.save(path, "PNG")


def render_banner(path: Path) -> None:
    scale = 2
    w, h = 1200 * scale, 264 * scale
    im = new_canvas(w, h)
    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((w * 0.62, -h * 0.4, w * 1.2, h * 1.2), fill=CRASH[:3] + (55,))
    gd.ellipse((-w * 0.05, h * 0.15, w * 0.4, h * 1.3), fill=LIFT[:3] + (26,))
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(70)))
    add_stars(im, 50, seed=23, scale=scale)

    origin = (40 * scale, h - 28 * scale)
    pts = exp_path(
        220,
        w * 0.54,
        origin[1] - 6 * scale,
        w - 64 * scale,
        34 * scale,
        k=2.15,
    )
    fill_under(im, pts, origin[1] + 4 * scale, CRASH[:3] + (100,), CRASH[:3] + (6,))
    glow_polyline(im, pts, CRASH, width=6 * scale, blur=8 * scale, glow_alpha=150)
    pulse_ticks(im, pts, every=18, scale=scale)
    pi = int(len(pts) * 0.9)
    draw_plane(im, pts[pi][0], pts[pi][1], tangent(pts, pi), scale=2.3 * scale / 2)

    add_vignette(im, 0.5)

    display = font(FONTS / "rajdhani-700.ttf", 72 * scale)
    tag_f = font(FONTS / "ibm-plex-mono-500.ttf", 14 * scale)

    def titles(draw: ImageDraw.ImageDraw, fill) -> None:
        tracked_text(
            draw,
            "AeroPulse",
            (48 * scale, 32 * scale),
            display,
            fill,
            tracking=2 * scale,
            anchor="lt",
        )

    text_halo(im, titles, blur=6)

    tag_layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    td = ImageDraw.Draw(tag_layer)
    tracked_text(
        td,
        "CASH BEFORE THE CRASH",
        (48 * scale, 112 * scale),
        tag_f,
        STEEL,
        tracking=4 * scale,
        anchor="lt",
    )
    im.alpha_composite(tag_layer)

    out = im.resize((1200, 264), Image.Resampling.LANCZOS).convert("RGB")
    out.save(path, "PNG")


if __name__ == "__main__":
    og = OUT / "og-raw.png"
    banner = OUT / "x-banner-raw.png"
    render_og(og)
    render_banner(banner)
    print("wrote", og, banner)
