#!/usr/bin/env python3
"""Original Sky Chirp share card + X banner. Vector-style Pillow art (no gen)."""
from PIL import Image, ImageDraw, ImageFilter, ImageFont

FONT = "/workspace/.grok/fonts/LilitaOne-Regular.ttf"
CREAM = (255, 247, 236, 255)
APRICOT = (239, 106, 69, 255)
APRICOT_DEEP = (196, 72, 42, 255)
MANGO = (240, 180, 41, 255)
MANGO_DEEP = (196, 132, 24, 255)
JADE = (28, 124, 100, 255)
JADE_DEEP = (16, 78, 64, 255)
JADE_LIFT = (46, 158, 126, 255)
INK = (27, 36, 48, 255)
PINK = (240, 138, 160, 255)
PINK_DEEP = (214, 96, 128, 255)
SKY_TOP = (255, 196, 122, 255)
SKY_MID = (255, 236, 206, 255)
SKY_LOW = (255, 168, 112, 255)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))


def gradient(size, stops):
    w, h = size
    im = Image.new("RGBA", size)
    d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / max(1, h - 1)
        for i in range(len(stops) - 1):
            t0, c0 = stops[i]
            t1, c1 = stops[i + 1]
            if t0 <= t <= t1:
                u = 0 if t1 == t0 else (t - t0) / (t1 - t0)
                d.line([(0, y), (w, y)], fill=lerp(c0, c1, u))
                break
    return im


def font(px):
    return ImageFont.truetype(FONT, px)


def ink_box(fnt, text):
    b = fnt.getbbox(text)
    return b


def draw_sky(size):
    im = gradient(
        size,
        [
            (0.0, (255, 176, 102, 255)),
            (0.28, SKY_TOP),
            (0.52, SKY_MID),
            (0.78, (255, 206, 150, 255)),
            (1.0, SKY_LOW),
        ],
    )
    return im


def add_sun(im, cx, cy, r):
    glow = Image.new("RGBA", im.size, (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    for i in range(10, 0, -1):
        rr = int(r * (1.0 + i * 0.16))
        alpha = 18 + (10 - i) * 6
        g.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=(255, 214, 120, alpha))
    glow = glow.filter(ImageFilter.GaussianBlur(18))
    im.alpha_composite(glow)
    d = ImageDraw.Draw(im)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 208, 86, 255))
    d.ellipse(
        [cx - int(r * 0.72), cy - int(r * 0.78), cx + int(r * 0.15), cy + int(r * 0.1)],
        fill=(255, 236, 170, 255),
    )


def add_clouds(im, specs):
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for cx, cy, scale, alpha in specs:
        puffs = [
            (-40, 6, 46, 28),
            (0, 0, 58, 34),
            (42, 8, 40, 24),
            (16, -16, 34, 22),
        ]
        for dx, dy, rx, ry in puffs:
            d.ellipse(
                [
                    cx + (dx - rx) * scale,
                    cy + (dy - ry) * scale,
                    cx + (dx + rx) * scale,
                    cy + (dy + ry) * scale,
                ],
                fill=(255, 247, 236, alpha),
            )
    im.alpha_composite(layer)


def gate(im, post, beam, side):
    """Jade post + mango lintel. side is 'left' or 'right'."""
    d = ImageDraw.Draw(im)
    px0, py0, px1, py1 = post
    # soft shadow behind the post
    shadow = Image.new("RGBA", im.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle([px0 + 10, py0 + 16, px1 + 16, py1], radius=18, fill=(27, 36, 48, 70))
    shadow = shadow.filter(ImageFilter.GaussianBlur(10))
    im.alpha_composite(shadow)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle(post, radius=16, fill=JADE)
    # block courses
    block_h = 26
    y = py0 + 18
    row = 0
    while y < py1 - 8:
        inset = 10
        x = px0 + inset + (12 if row % 2 else 0)
        while x < px1 - inset - 16:
            d.rounded_rectangle(
                [x, y, min(x + 28, px1 - inset), y + block_h - 6],
                radius=3,
                fill=JADE_LIFT if (row + x // 30) % 3 == 0 else JADE_DEEP,
            )
            x += 36
        y += block_h
        row += 1
    # inner reveal (thickness toward the opening)
    if side == "left":
        d.rectangle([px1 - 22, py0 + 8, px1, py1], fill=JADE_DEEP)
        d.rectangle([px0, py0 + 8, px0 + 10, py1], fill=JADE_LIFT)
    else:
        d.rectangle([px0, py0 + 8, px0 + 22, py1], fill=JADE_DEEP)
        d.rectangle([px1 - 10, py0 + 8, px1, py1], fill=JADE_LIFT)
    # mango lintel
    bx0, by0, bx1, by1 = beam
    d.rounded_rectangle([bx0, by0 + 8, bx1, by1], radius=10, fill=APRICOT_DEEP)
    d.rounded_rectangle([bx0, by0, bx1, by1 - 10], radius=10, fill=MANGO)
    d.rounded_rectangle(
        [bx0 + 8, by0 + 6, bx1 - 8, by0 + 16],
        radius=5,
        fill=(255, 220, 130, 255),
    )
    # diamond emblem on the post
    mx = (px0 + px1) / 2
    my = py0 + (py1 - py0) * 0.42
    s = min(22, (px1 - px0) * 0.18)
    d.polygon(
        [(mx, my - s), (mx + s, my), (mx, my + s), (mx - s, my)],
        fill=MANGO,
    )
    d.polygon(
        [(mx, my - s * 0.45), (mx + s * 0.45, my), (mx, my + s * 0.45), (mx - s * 0.45, my)],
        fill=CREAM,
    )


def draw_bird(im, cx, cy, s, flip=False):
    """Round apricot songbird. flip mirrors so the beak points left."""
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))

    def X(x):
        return cx - (x - cx) if flip else x

    def poly(pts, fill):
        ImageDraw.Draw(layer).polygon([(X(x), y) for x, y in pts], fill=fill)

    def ell(box, fill):
        x0, y0, x1, y1 = box
        ImageDraw.Draw(layer).ellipse([X(x1), y0, X(x0), y1] if flip else box, fill=fill)

    # shadow
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).ellipse(
        [cx - 78 * s, cy + 72 * s, cx + 96 * s, cy + 108 * s],
        fill=(27, 36, 48, 80),
    )
    im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(max(2, int(10 * s)))))

    # tail
    poly(
        [
            (cx - 40 * s, cy + 6 * s),
            (cx - 120 * s, cy - 28 * s),
            (cx - 108 * s, cy + 8 * s),
            (cx - 126 * s, cy + 26 * s),
            (cx - 96 * s, cy + 24 * s),
            (cx - 112 * s, cy + 52 * s),
            (cx - 48 * s, cy + 36 * s),
        ],
        APRICOT_DEEP,
    )
    # rear wing
    poly(
        [
            (cx - 8 * s, cy + 4 * s),
            (cx - 78 * s, cy + 46 * s),
            (cx - 20 * s, cy + 36 * s),
            (cx + 10 * s, cy + 28 * s),
        ],
        (176, 64, 40, 255),
    )
    # body
    ell([cx - 78 * s, cy - 74 * s, cx + 82 * s, cy + 86 * s], APRICOT)
    # belly
    ell([cx - 46 * s, cy - 8 * s, cx + 52 * s, cy + 70 * s], CREAM)
    # raised wing
    poly(
        [
            (cx - 6 * s, cy - 6 * s),
            (cx + 18 * s, cy - 78 * s),
            (cx + 62 * s, cy - 96 * s),
            (cx + 78 * s, cy - 58 * s),
            (cx + 36 * s, cy - 18 * s),
        ],
        APRICOT_DEEP,
    )
    poly(
        [
            (cx + 10 * s, cy - 16 * s),
            (cx + 8 * s, cy - 62 * s),
            (cx + 36 * s, cy - 70 * s),
            (cx + 30 * s, cy - 22 * s),
        ],
        (255, 154, 112, 255),
    )
    # crest
    poly(
        [(cx - 6 * s, cy - 62 * s), (cx + 14 * s, cy - 58 * s), (cx + 2 * s, cy - 118 * s)],
        PINK,
    )
    poly(
        [(cx - 28 * s, cy - 48 * s), (cx - 4 * s, cy - 58 * s), (cx - 16 * s, cy - 100 * s)],
        PINK_DEEP,
    )
    poly(
        [(cx + 16 * s, cy - 52 * s), (cx + 36 * s, cy - 40 * s), (cx + 30 * s, cy - 96 * s)],
        (255, 176, 190, 255),
    )
    # beak
    poly(
        [(cx + 62 * s, cy - 6 * s), (cx + 124 * s, cy + 10 * s), (cx + 60 * s, cy + 26 * s)],
        MANGO,
    )
    poly(
        [(cx + 64 * s, cy + 8 * s), (cx + 112 * s, cy + 12 * s), (cx + 62 * s, cy + 24 * s)],
        MANGO_DEEP,
    )
    # cheek
    ell([cx + 18 * s, cy + 8 * s, cx + 48 * s, cy + 28 * s], (240, 138, 160, 150))
    # eye
    ell([cx + 30 * s, cy - 32 * s, cx + 62 * s, cy + 2 * s], CREAM)
    ell([cx + 40 * s, cy - 22 * s, cx + 56 * s, cy - 4 * s], INK)
    ell([cx + 44 * s, cy - 18 * s, cx + 49 * s, cy - 12 * s], CREAM)
    im.alpha_composite(layer)


def lockup(im, cx, top, big, small, align="center", max_right=None, with_tag=True):
    """Draw SKY / CHIRP and an optional tagline. Returns glyph bboxes."""
    f_big = font(big)
    f_sm = font(small)
    lines = [("SKY", f_big), ("CHIRP", f_big)]
    if with_tag:
        lines.append(("Soar the sunrise", f_sm))
    gap = max(-2, int(big * -0.04))
    tag_gap = max(8, int(big * 0.06))
    measured = []
    for text, fnt in lines:
        measured.append((text, fnt, ink_box(fnt, text)))
    widths = [b[2] - b[0] for _, _, b in measured]
    heights = [b[3] - b[1] for _, _, b in measured]
    y = top
    boxes = []
    d = ImageDraw.Draw(im)
    for i, ((text, fnt, b), w, h) in enumerate(zip(measured, widths, heights)):
        x = (cx - w / 2 - b[0]) if align == "center" else (cx - b[0])
        stroke = max(5, int(big * 0.07)) if i < 2 else max(2, int(small * 0.14))
        d.text(
            (x + 4, y - b[1] + 5),
            text,
            font=fnt,
            fill=INK,
            stroke_width=stroke + 3,
            stroke_fill=INK,
        )
        rim = APRICOT if i < 2 else JADE_DEEP
        d.text(
            (x, y - b[1]),
            text,
            font=fnt,
            fill=CREAM,
            stroke_width=stroke,
            stroke_fill=rim,
        )
        pad = stroke + 3
        boxes.append((x + b[0] - pad, y - pad, x + b[2] + pad, y + h + pad))
        step = tag_gap if (with_tag and i == 1) else gap
        y += h + step
    if max_right is not None:
        for box in boxes:
            if box[2] > max_right:
                raise SystemExit(f"lockup overflows safe right edge {max_right}: {box}")
    return boxes


def ridges(im, baseline):
    w, h = im.size
    d = ImageDraw.Draw(im)
    d.polygon(
        [
            (0, h),
            (0, baseline + 30),
            (90, baseline - 10),
            (180, baseline + 36),
            (300, baseline),
            (430, baseline + 44),
            (560, baseline + 8),
            (700, baseline + 40),
            (860, baseline - 6),
            (1000, baseline + 34),
            (1120, baseline + 4),
            (w, baseline + 28),
            (w, h),
        ],
        fill=(20, 52, 48, 255),
    )
    d.polygon(
        [
            (0, h),
            (0, baseline + 70),
            (140, baseline + 40),
            (280, baseline + 78),
            (460, baseline + 48),
            (640, baseline + 82),
            (820, baseline + 46),
            (1000, baseline + 76),
            (w, baseline + 52),
            (w, h),
        ],
        fill=INK,
    )


def card():
    w, h = 1200, 630
    im = draw_sky((w, h))
    add_clouds(
        im,
        [
            (220, 96, 0.95, 200),
            (1000, 120, 0.8, 185),
            (800, 64, 0.48, 155),
            (390, 52, 0.4, 145),
        ],
    )
    gate(im, post=(48, 150, 176, 630), beam=(28, 118, 250, 182), side="left")
    gate(im, post=(1024, 150, 1152, 630), beam=(950, 118, 1172, 182), side="right")
    big, small = 188, 38
    scratch = Image.new("RGBA", (w, h))
    probe = lockup(scratch, 600, 0, big, small, align="center")
    block_top = min(b[1] for b in probe)
    block_bot = max(b[3] for b in probe)
    block_h = block_bot - block_top
    # Bias the lockup slightly below center so the mascot has a band of sky.
    top = (h - block_h) / 2 - block_top + 36
    title_y0 = top + block_top
    # Bird perches in the opening above the wordmark, clear of the glyphs.
    bird_s = 0.7
    bird_bottom = title_y0 - 8
    bird_cy = bird_bottom - 86 * bird_s
    add_sun(im, 600, bird_cy - 6, 100)
    draw_bird(im, 600, bird_cy, bird_s, flip=False)
    ridges(im, max(548, int(top + block_h + 8)))
    boxes = lockup(im, 600, top, big, small, align="center")
    widest = max(b[2] - b[0] for b in boxes)
    print(
        f"card title width {widest:.0f}px ({widest / w:.0%} of frame), "
        f"title_y0 {title_y0:.0f}, bird_cy {bird_cy:.0f}"
    )
    for b in boxes:
        if b[0] < 40 or b[1] < 24 or b[2] > w - 40 or b[3] > h - 28:
            raise SystemExit(f"title too close to edge: {b}")
    return im, boxes


def banner():
    w, h = 1200, 264
    im = draw_sky((w, h))
    add_sun(im, 690, 70, 64)
    add_clouds(
        im,
        [
            (470, 42, 0.55, 200),
            (260, 64, 0.36, 160),
            (1040, 36, 0.62, 180),
        ],
    )
    gate(im, post=(1010, 28, 1148, 264), beam=(930, 8, 1184, 54), side="right")
    draw_bird(im, 790, 132, 0.7, flip=False)
    ridges(im, 220)
    # Whole lockup in the left half and the top 80%. Block sits above the midline.
    boxes = lockup(
        im, 64, 16, big=74, small=22, align="left", max_right=560, with_tag=True
    )
    for b in boxes:
        if b[2] > 600 or b[3] > 200 or b[0] < 12 or b[1] < 6:
            raise SystemExit(f"banner lockup outside safe zone: {b}")
    return im, boxes


def main():
    og, og_boxes = card()
    bn, bn_boxes = banner()
    og.convert("RGB").save("/workspace/.grok/og-raw.png", "PNG")
    bn.convert("RGB").save("/workspace/.grok/x-banner-raw.png", "PNG")
    print("og", og.size, "boxes", [(round(a), round(b), round(c), round(d)) for a, b, c, d in og_boxes])
    print("banner", bn.size, "boxes", [(round(a), round(b), round(c), round(d)) for a, b, c, d in bn_boxes])


if __name__ == "__main__":
    main()
