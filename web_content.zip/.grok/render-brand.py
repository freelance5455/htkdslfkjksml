#!/usr/bin/env python3
"""Instrument-plate share cards for Orrery. Exact type, palette-locked."""

import math
import random
from PIL import Image, ImageDraw, ImageFilter, ImageFont

CHARTER = "/usr/share/fonts/X11/Type1/c0648bt_.pfb"
SANS = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"

INK = (10, 10, 11)          # #0a0a0b
PAPER = (244, 244, 245)     # #f4f4f5
STEEL = (158, 176, 196)     # #9eb0c4
SAGE = (109, 143, 134)      # #6d8f86
WARM = (246, 241, 230)      # warm-white star, not gold


def font(size):
    return ImageFont.truetype(CHARTER, size)


def advance(text, face, tracking):
    if not text:
        return 0
    return sum(face.getlength(ch) for ch in text) + tracking * (len(text) - 1)


def draw_tracked(draw, text, x, y, face, fill, tracking, align="left"):
    width = advance(text, face, tracking)
    if align == "center":
        x -= width / 2
    elif align == "right":
        x -= width
    cursor = x
    for i, ch in enumerate(text):
        draw.text((cursor, y), ch, font=face, fill=fill)
        cursor += face.getlength(ch)
        if i < len(text) - 1:
            cursor += tracking
    return x, x + width


def ellipse_point(cx, cy, rx, ry, rot_deg, t_deg):
    t = math.radians(t_deg)
    a = math.radians(rot_deg)
    x = rx * math.cos(t)
    y = ry * math.sin(t)
    return (
        cx + x * math.cos(a) - y * math.sin(a),
        cy + x * math.sin(a) + y * math.cos(a),
    )


def paint_planet(base, cx, cy, radius, rgb):
    """Matte sphere. Light from the upper left, no specular neon."""
    r = int(math.ceil(radius))
    pad = 3
    size = r * 2 + pad * 2
    yy, xx = __import__("numpy").mgrid[0:size, 0:size]
    px = xx - (r + pad) + 0.5
    py = yy - (r + pad) + 0.5
    dist = __import__("numpy").sqrt(px * px + py * py)
    mask = dist <= radius
    # limb darkening + offset illumination
    lx, ly = -0.42 * radius, -0.48 * radius
    ld = __import__("numpy").sqrt((px - lx) ** 2 + (py - ly) ** 2)
    light = __import__("numpy").clip(1.0 - ld / (radius * 2.15), 0, 1)
    limb = __import__("numpy").clip(dist / radius, 0, 1)
    shade = 0.42 + 0.58 * light
    shade = shade * (1.0 - 0.38 * limb ** 1.6)
    rgb_a = __import__("numpy").array(rgb, dtype="float32")
    dark = rgb_a * 0.28 + __import__("numpy").array(INK, dtype="float32") * 0.72
    lit = rgb_a * 0.78 + __import__("numpy").array(PAPER, dtype="float32") * 0.22
    col = dark + (lit - dark) * shade[..., None]
    col = __import__("numpy").clip(col, 0, 255).astype("uint8")
    patch = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    pix = patch.load()
    alpha = __import__("numpy").clip((radius - dist) * 2.2, 0, 1)
    for y in range(size):
        for x in range(size):
            if mask[y, x]:
                a = int(alpha[y, x] * 255)
                if a:
                    c = col[y, x]
                    pix[x, y] = (int(c[0]), int(c[1]), int(c[2]), a)
    base.alpha_composite(patch, (int(round(cx)) - r - pad, int(round(cy)) - r - pad))


def stroke_ellipse(layer, cx, cy, rx, ry, rot, color, width):
    tmp_w = int(rx * 2 + width * 4 + 8)
    tmp_h = int(ry * 2 + width * 4 + 8)
    tmp = Image.new("RGBA", (tmp_w, tmp_h), (0, 0, 0, 0))
    d = ImageDraw.Draw(tmp)
    m = width * 2 + 2
    d.ellipse([m, m, tmp_w - m - 1, tmp_h - m - 1], outline=color, width=width)
    rot_img = tmp.rotate(rot, resample=Image.BICUBIC, expand=True)
    layer.alpha_composite(
        rot_img,
        (int(round(cx - rot_img.width / 2)), int(round(cy - rot_img.height / 2))),
    )


def punch_capsule(layer, box, radius, blur):
    """Fade orbit strokes out of the inscription well."""
    import numpy as np

    mask = Image.new("L", layer.size, 255)
    md = ImageDraw.Draw(mask)
    md.rounded_rectangle(box, radius=radius, fill=0)
    mask = mask.filter(ImageFilter.GaussianBlur(blur))
    aa = np.array(layer.getchannel("A"), dtype=np.uint16)
    mm = np.array(mask, dtype=np.uint16)
    layer.putalpha(Image.fromarray(((aa * mm) // 255).astype(np.uint8), "L"))


def starfield(rng, w, h, n, avoid, scale=1):
    stars = []
    guard = 0
    while len(stars) < n and guard < n * 40:
        guard += 1
        x = rng.uniform(24 * scale, w - 24 * scale)
        y = rng.uniform(24 * scale, h - 24 * scale)
        if any(ax0 <= x <= ax1 and ay0 <= y <= ay1 for ax0, ay0, ax1, ay1 in avoid):
            continue
        roll = rng.random()
        if roll > 0.94:
            rad = rng.uniform(2.2, 3.1) * scale
            col = WARM
            alpha = rng.randint(210, 245)
        elif roll > 0.78:
            rad = rng.uniform(1.3, 1.9) * scale
            col = PAPER
            alpha = rng.randint(170, 230)
        else:
            rad = rng.uniform(0.6, 1.15) * scale
            col = PAPER if rng.random() > 0.25 else WARM
            alpha = rng.randint(90, 180)
        stars.append((x, y, rad, col, alpha))
    return stars


def draw_stars(base, stars):
    glow = Image.new("RGBA", base.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    sharp = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(sharp)
    for x, y, rad, col, alpha in stars:
        if rad >= 1.6:
            gd.ellipse([x - rad * 2.4, y - rad * 2.4, x + rad * 2.4, y + rad * 2.4], fill=col + (int(alpha * 0.35),))
        sd.ellipse([x - rad, y - rad, x + rad, y + rad], fill=col + (alpha,))
    glow = glow.filter(ImageFilter.GaussianBlur(1.6))
    base.alpha_composite(glow)
    base.alpha_composite(sharp)


def vignette(im, cool=0.07):
    import numpy as np
    arr = np.array(im).astype(np.float32)
    h, w = arr.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w]
    nx = (xx - w / 2) / (w / 2)
    ny = (yy - h / 2) / (h / 2)
    d = np.sqrt(nx * nx * 0.72 + ny * ny)
    # slight cool lift at center, falloff to black at corners
    lift = np.clip(1 - d, 0, 1) ** 1.7 * cool
    fall = np.clip((d - 0.55) / 0.7, 0, 1) ** 1.4
    arr[..., 0] = arr[..., 0] * (1 - fall) + STEEL[0] * lift
    arr[..., 1] = arr[..., 1] * (1 - fall) + STEEL[1] * lift
    arr[..., 2] = arr[..., 2] * (1 - fall) + STEEL[2] * lift
    arr = np.clip(arr, 0, 255)
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def background(w, h):
    im = Image.new("RGBA", (w, h), INK + (255,))
    return vignette(im)


def render_og(scale=2):
    W, H = 1200 * scale, 630 * scale
    im = background(W, H)
    cx, cy = 600 * scale, 316 * scale

    # Fit "ORRERY" to ~58% of the frame.
    target = 0.58 * W
    size = 80 * scale
    face = font(size)
    tracking = int(0.085 * size)
    for _ in range(24):
        width = advance("ORRERY", face, tracking)
        if abs(width - target) < 8 * scale:
            break
        size = max(40, int(size * (target / max(width, 1)) ** 0.85))
        face = font(size)
        tracking = int(round(0.085 * size))
    title_w = advance("ORRERY", face, tracking)
    ascent, descent = face.getmetrics()
    tag_size = max(12 * scale, int(size * 0.155))
    tag_face = font(tag_size)
    tag_track = int(round(tag_size * 0.34))
    tag_w = advance("AN ORBITAL SANDBOX", tag_face, tag_track)
    # Keep the tagline from outgrowing the title.
    while tag_w > title_w * 1.02 and tag_track > 1:
        tag_track -= 1
        tag_w = advance("AN ORBITAL SANDBOX", tag_face, tag_track)
    tag_ascent, tag_descent = tag_face.getmetrics()
    gap1 = int(22 * scale)
    rule_gap = int(16 * scale)
    block_h = ascent + descent + gap1 + rule_gap + tag_ascent + tag_descent
    top = int(cy - block_h / 2)
    title_y = top
    rule_y = title_y + ascent + descent + gap1 // 2
    tag_y = title_y + ascent + descent + gap1 + rule_gap - tag_ascent + ascent // 8

    # Inscription well — orbits fade here, planets stay outside.
    pad_x, pad_y = int(54 * scale), int(36 * scale)
    well = [
        int(cx - title_w / 2 - pad_x),
        title_y - pad_y,
        int(cx + title_w / 2 + pad_x),
        tag_y + tag_ascent + tag_descent + pad_y,
    ]

    orbits = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    steel_hi = STEEL + (168,)
    steel_mid = STEEL + (120,)
    sage_line = SAGE + (140,)
    stroke_ellipse(orbits, cx, cy, 470 * scale, 236 * scale, -7, steel_hi, max(2, int(1.6 * scale)))
    stroke_ellipse(orbits, cx, cy, 360 * scale, 168 * scale, 16, steel_mid, max(2, int(1.35 * scale)))
    stroke_ellipse(orbits, cx, cy, 548 * scale, 196 * scale, -18, sage_line, max(2, int(1.25 * scale)))
    punch_capsule(orbits, well, radius=int(28 * scale), blur=int(10 * scale))
    im.alpha_composite(orbits)

    rng = random.Random(11)
    stars = starfield(rng, W, H, 78, avoid=[tuple(well)], scale=scale)
    draw_stars(im, stars)

    bodies = [
        # t, which ellipse (rx, ry, rot), radius, color
        (198, 470, 236, -7, 52, SAGE),
        (332, 470, 236, -7, 34, STEEL),
        (28, 360, 168, 16, 16, WARM),
    ]
    placed = []
    for t, rx, ry, rot, rad, col in bodies:
        x, y = ellipse_point(cx, cy, rx * scale, ry * scale, rot, t)
        placed.append((x, y, rad * scale, col))
        paint_planet(im, x, y, rad * scale, col)
    # A small attendant beside the sage body, still clear of the well.
    sx, sy, _, _ = placed[0]
    paint_planet(im, sx + 78 * scale, sy - 36 * scale, 7.5 * scale, PAPER)

    # Type last, so nothing crosses a glyph.
    plate = ImageDraw.Draw(im)
    draw_tracked(plate, "ORRERY", cx, title_y, face, PAPER + (255,), tracking, align="center")
    rule_w = int(64 * scale)
    plate.line(
        [(cx - rule_w / 2, rule_y), (cx + rule_w / 2, rule_y)],
        fill=STEEL + (200,),
        width=max(1, scale),
    )
    draw_tracked(
        plate, "AN ORBITAL SANDBOX", cx, tag_y, tag_face, STEEL + (255,), tag_track, align="center"
    )

    meta = {
        "title_box": (
            (cx - title_w / 2) / scale,
            title_y / scale,
            (cx + title_w / 2) / scale,
            (title_y + ascent + descent) / scale,
        ),
        "tag_box": (
            (cx - tag_w / 2) / scale,
            tag_y / scale,
            (cx + tag_w / 2) / scale,
            (tag_y + tag_ascent + tag_descent) / scale,
        ),
        "planets": [(x / scale, y / scale, r / scale) for x, y, r, _ in placed],
        "title_frac": title_w / W,
    }
    out = im.resize((1200, 630), Image.Resampling.LANCZOS)
    return out, meta


def render_banner(scale=2):
    W, H = 1200 * scale, 264 * scale
    im = background(W, H)
    # Instrument lives on the right; inscription stays in the left safe zone.
    ocx, ocy = 860 * scale, 122 * scale

    size = 70 * scale
    face = font(size)
    tracking = int(round(size * 0.06))
    title_w = advance("ORRERY", face, tracking)
    # Must finish before the midpoint, with air.
    while title_w > 430 * scale and size > 20 * scale:
        size -= 2 * scale
        face = font(size)
        tracking = int(round(size * 0.06))
        title_w = advance("ORRERY", face, tracking)
    ascent, descent = face.getmetrics()
    tag_size = max(11 * scale, int(size * 0.22))
    tag_face = font(tag_size)
    # Spread the tagline to roughly the title width, but never past x=560.
    left = 68 * scale
    max_right = 540 * scale
    tag_track = 2 * scale
    tag_w = advance("AN ORBITAL SANDBOX", tag_face, tag_track)
    while tag_w < min(title_w * 0.98, max_right - left - 8 * scale) and tag_track < 20 * scale:
        tag_track += 1
        tag_w = advance("AN ORBITAL SANDBOX", tag_face, tag_track)
    while left + tag_w > max_right and tag_track > 0:
        tag_track -= 1
        tag_w = advance("AN ORBITAL SANDBOX", tag_face, tag_track)
    tag_ascent, tag_descent = tag_face.getmetrics()

    title_y = 40 * scale
    rule_y = title_y + ascent + descent + int(8 * scale)
    tag_y = rule_y + int(12 * scale)
    # If the lockup slips toward the midline, pull it up.
    block_bottom = tag_y + tag_ascent + tag_descent
    block_mid = (title_y + block_bottom) / 2
    if block_mid > 120 * scale:
        shift = block_mid - 108 * scale
        title_y -= shift
        rule_y -= shift
        tag_y -= shift
        block_bottom -= shift

    orbits = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    stroke_ellipse(orbits, ocx, ocy, 300 * scale, 78 * scale, -6, STEEL + (170,), max(2, int(1.5 * scale)))
    stroke_ellipse(orbits, ocx, ocy, 200 * scale, 48 * scale, 12, SAGE + (150,), max(2, int(1.3 * scale)))
    # A longer arc that may enter the lower scenery strip; type stays clear.
    stroke_ellipse(orbits, ocx + 20 * scale, ocy + 8 * scale, 420 * scale, 96 * scale, 3, STEEL + (90,), max(2, int(1.2 * scale)))
    # Keep strokes out of the left inscription.
    well = [int(36 * scale), int(title_y - 18 * scale), int(max(left + title_w, left + tag_w) + 36 * scale), int(block_bottom + 16 * scale)]
    punch_capsule(orbits, well, radius=int(18 * scale), blur=int(8 * scale))
    im.alpha_composite(orbits)

    rng = random.Random(29)
    stars = starfield(
        rng,
        W,
        H,
        54,
        avoid=[
            tuple(well),
            # Keep the inscription column quiet, including beneath the lockup.
            (int(48 * scale), int(block_bottom), int(max_right), H - 1),
        ],
        scale=scale,
    )
    draw_stars(im, stars)

    bodies = [
        (236, 300, 78, -6, 32, SAGE),
        (42, 300, 78, -6, 15, STEEL),
        (120, 200, 48, 12, 8, WARM),
    ]
    placed = []
    for t, rx, ry, rot, rad, col in bodies:
        x, y = ellipse_point(ocx, ocy, rx * scale, ry * scale, rot, t)
        placed.append((x / scale, y / scale, rad))
        paint_planet(im, x, y, rad * scale, col)

    plate = ImageDraw.Draw(im)
    t_left, t_right = draw_tracked(plate, "ORRERY", left, title_y, face, PAPER + (255,), tracking, align="left")
    rule_w = int(148 * scale)
    plate.line([(left, rule_y), (left + rule_w, rule_y)], fill=STEEL + (210,), width=max(1, scale))
    g_left, g_right = draw_tracked(
        plate, "AN ORBITAL SANDBOX", left, tag_y, tag_face, STEEL + (255,), tag_track, align="left"
    )

    meta = {
        "title_box": (t_left / scale, title_y / scale, t_right / scale, (title_y + ascent + descent) / scale),
        "tag_box": (g_left / scale, tag_y / scale, g_right / scale, (tag_y + tag_ascent + tag_descent) / scale),
        "planets": placed,
        "rule": (left / scale, rule_y / scale, (left + rule_w) / scale, rule_y / scale),
    }
    out = im.resize((1200, 264), Image.Resampling.LANCZOS)
    return out, meta


def main():
    og, og_meta = render_og()
    banner, ban_meta = render_banner()
    og.save("/workspace/.grok/card-raw.png", "PNG")
    banner.save("/workspace/.grok/banner-raw.png", "PNG")
    print("OG", og.size, og_meta)
    print("BANNER", banner.size, ban_meta)


if __name__ == "__main__":
    main()
