import { chromium } from "playwright";
import { readFileSync, writeFileSync } from "node:fs";

const svgs = {
  m: readFileSync("/workspace/.grok/favicon-m.svg", "utf8"),
  nested: readFileSync("/workspace/.grok/favicon-nested.svg", "utf8"),
};

const browser = await chromium.launch({ args: ["--disable-web-security"] });

async function raster(svg, size, outPath, { round = true } = {}) {
  const markup = round
    ? svg
    : svg.replace(/rx="8"/, 'rx="0"');
  const page = await browser.newPage({
    viewport: { width: size, height: size },
    deviceScaleFactor: 1,
  });
  await page.setContent(
    `<!doctype html><html><head><style>
      html,body{margin:0;padding:0;width:${size}px;height:${size}px;background:#0c0c0b;}
      svg{display:block;width:${size}px;height:${size}px;}
    </style></head><body>${markup}</body></html>`,
    { waitUntil: "load" },
  );
  await page.screenshot({ path: outPath, type: "png", omitBackground: false });
  await page.close();
}

await raster(svgs.m, 16, "/workspace/.grok/favicon-m-16.png");
await raster(svgs.m, 32, "/workspace/.grok/favicon-m-32.png");
await raster(svgs.nested, 16, "/workspace/.grok/favicon-nested-16.png");
await raster(svgs.nested, 32, "/workspace/.grok/favicon-nested-32.png");
await raster(svgs.m, 192, "/workspace/.grok/icon-m-192.png", { round: false });
await raster(svgs.nested, 192, "/workspace/.grok/icon-nested-192.png", { round: false });

await browser.close();
console.log("rasterized");
