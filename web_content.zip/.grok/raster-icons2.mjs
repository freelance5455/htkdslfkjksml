import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const svgs = {
  stroke: readFileSync("/workspace/.grok/favicon-stroke-m.svg", "utf8"),
  bold: readFileSync("/workspace/.grok/favicon-bold-m.svg", "utf8"),
};

const browser = await chromium.launch();
async function raster(svg, size, outPath) {
  const page = await browser.newPage({
    viewport: { width: size, height: size },
    deviceScaleFactor: 1,
  });
  await page.setContent(
    `<!doctype html><html><head><style>
      html,body{margin:0;padding:0;width:${size}px;height:${size}px;background:#0c0c0b;}
      svg{display:block;width:${size}px;height:${size}px;}
    </style></head><body>${svg}</body></html>`,
    { waitUntil: "load" },
  );
  await page.screenshot({ path: outPath, type: "png" });
  await page.close();
}
for (const [k, svg] of Object.entries(svgs)) {
  await raster(svg, 16, `/workspace/.grok/favicon-${k}-16.png`);
  await raster(svg, 32, `/workspace/.grok/favicon-${k}-32.png`);
  await raster(svg, 192, `/workspace/.grok/icon-${k}-192.png`);
}
await browser.close();
console.log("ok");
