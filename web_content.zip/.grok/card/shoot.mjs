import { chromium } from "playwright-core";

const executablePath =
  "/opt/pw-browsers/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell";

const browser = await chromium.launch({ executablePath, headless: true });

const card = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 2,
});
await card.goto("file:///workspace/.grok/card/card.html", { waitUntil: "load" });
await card.evaluate(async () => { await document.fonts.ready; });
await card.screenshot({
  path: "/workspace/.grok/card/card.png",
  clip: { x: 0, y: 0, width: 1200, height: 630 },
});

const icons = await browser.newPage({
  viewport: { width: 420, height: 220 },
  deviceScaleFactor: 2,
});
await icons.goto("file:///workspace/.grok/card/icons.html", { waitUntil: "load" });
await icons.screenshot({ path: "/workspace/.grok/card/icons.png" });

await browser.close();
console.log("shot");
