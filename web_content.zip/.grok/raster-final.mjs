import { chromium } from "playwright";
import { readFileSync } from "node:fs";

const svg = readFileSync("/workspace/.grok/favicon.svg.tmp", "utf8");
const browser = await chromium.launch();

async function raster(size, outPath) {
  const page = await browser.newPage({
    viewport: { width: size, height: size },
    deviceScaleFactor: 1,
  });
  await page.setContent(
    `<!doctype html><html><head><style>
      html,body{margin:0;padding:0;background:#0c0c0b;width:${size}px;height:${size}px;}
      svg{display:block;width:${size}px;height:${size}px;}
    </style></head><body>${svg}</body></html>`,
    { waitUntil: "load" },
  );
  await page.screenshot({ path: outPath, type: "png" });
  await page.close();
}

await raster(16, "/workspace/.grok/favicon-16-qc.png");
await raster(32, "/workspace/.grok/favicon-32-qc.png");
await raster(192, "/workspace/.grok/icon-192.png.tmp");
await raster(512, "/workspace/.grok/icon-512.png.tmp");
await browser.close();
console.log("final rasters done");
