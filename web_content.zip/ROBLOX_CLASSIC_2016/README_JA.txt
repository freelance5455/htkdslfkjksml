ROBLOX CLASSIC 2016 - Android Studio project

これは2016年頃のゲームサイトをイメージした非公式の画面デモです。
本物のRobloxへのログイン、Robux、ゲーム接続機能はありません。

APKを作るには:
1. ZIPを展開する
2. Android Studioでこのフォルダを開く
3. Gradle同期が終わるまで待つ
4. Build > Build Bundle(s) / APK(s) > Build APK(s)
5. app/build/outputs/apk/debug/app-debug.apk が生成されます

必要環境: Android Studio と Android SDK。初回ビルド時はGradleプラグイン等の取得にネット接続が必要です。
