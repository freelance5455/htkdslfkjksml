RAJA INTERNATIONAL TRAVEL KPK — MULTI AGENCY POS (PHASE 1)

HOW TO OPEN
1. Extract this ZIP file on your Windows computer.
2. Open index.html in Chrome or Edge.
3. On Android, extract the ZIP and open index.html in a browser (availability depends on your file manager/browser).

NEW FEATURE: EDIT TICKET
1. Open Ticket Ledger.
2. Find the ticket and press Edit ✏️.
3. Ticket details will appear in the New Ticket form.
4. Correct the information and press Update Ticket.
5. The same ticket record is updated; it is not added as a duplicate.

FEATURES
- Unlimited separate agency ledgers
- Separate tickets, sales, outstanding and profit per agency
- Separate cash book and opening cash balance per agency
- Ticket search, edit and delete
- CSV export and JSON backup/restore

IMPORTANT LIMITATIONS
This is an offline browser prototype. Data is saved in the browser on the current device. Firebase cloud sync, Android/Windows shared data, native app packaging, and PDF/WhatsApp multi-ticket sharing are not connected in this version. Export regular backups and do not use this prototype as the only record of business accounts.
