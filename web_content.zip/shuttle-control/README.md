# Shuttle Control v3.1.0 — Shuttle Car fleet, PLC monitoring architecture & diagnostics

Scope: Shuttle Car automation only (monitoring, batteries, faults, maintenance, diagnostics, multi-manufacturer).
Not an ERP / warehouse / accounting system.

## Requirements
Node.js >= 22.13 (uses built-in `node:sqlite`). **No npm packages are needed** — there is nothing to install.

## Run
```
npm start                      # http://127.0.0.1:8080
ADMIN_PASSWORD='...' npm start # optional: set the first super-admin password
```
On first run a `super_admin` user `admin` is created. If `ADMIN_PASSWORD` is not set, a random password is printed **once** in the console.
Env: `PORT`, `HOST` (default 127.0.0.1), `DB_PATH` (default `data/shuttle.db`), `SIMULATION=0` to disable the simulator ticker.

## Test
`npm test` (Node built-in test runner; 19 backend tests: auth, RBAC, validation, simulation labeling, diagnostics, audit, backup+restore, battery cycles, work orders, reports).

## Layout
- `server/` backend (db + migrations, REST API, auth/RBAC/audit, diagnostics engine, simulator, protocol adapter registry)
- `public/` frontend (vanilla JS, no build step; Arabic RTL + English; dark/light; responsive)
- `test/` automated tests · `docs/` API, integration, limitations · `legacy/` the original v2.1.0 build, untouched
- `tools/visual-check.py` optional Playwright layout check · `CHANGELOG.md` · `VERSION`, `package.json`

## Data labels
Every shuttle carries `data_source`: `REAL` / `SIMULATION` / `OFFLINE` (+ UI badge). Simulated rows are created only by the simulator and are always `SIMULATION`. Nothing is `REAL` until a commissioned adapter writes it.

## Roles
super_admin > admin > technician > operator > viewer (see docs/API.md for per-endpoint minimum role). Passwords: scrypt. Sessions: random bearer tokens (stored hashed, 8 h). Login throttling: 5 failures -> 60 s lock. Every sensitive action is written to the audit log.

## Backup / restore / recovery
- Stop the server, copy `data/shuttle.db` (+ `-wal`/`-shm` if present) to a safe place. Restore = stop server, put the file back, start.
- `GET /api/backup` (super_admin) exports all operational tables as JSON (password hashes excluded). `POST /api/restore` (super_admin) restores that JSON atomically (validated, integrity-checked, rolled back on any error; users and the audit log are never overwritten).
- Lost super-admin password: stop the server, delete the `admin` row's lock by creating a new DB, or restore a backup (no password-reset CLI yet).

## Deployment
Run behind an HTTPS reverse proxy (nginx/Caddy) and keep `HOST=127.0.0.1`; run under systemd/PM2 with `DB_PATH` on persistent storage. Do not expose plain HTTP on a network. The APK wrapper should point to the HTTPS URL of this server.

See `docs/LIMITATIONS.md` before relying on this in production.
