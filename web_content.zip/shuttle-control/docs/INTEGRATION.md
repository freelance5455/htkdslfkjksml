# Manufacturer / PLC integration (to be completed at commissioning)
Nothing in this release communicates with real hardware. `server/protocols.js` lists adapters (Modbus TCP, OPC UA, Ethernet TCP/IP, MQTT, REST, BLE, vendor-specific); each throws "not commissioned".
To integrate a manufacturer:
1. Obtain the official communication documentation and register/tag map for the exact model (Cassioli, Craftsman, ACME ...). Names/protocols stored for them here are `unverified`.
2. Add the manufacturer via `POST /api/manufacturers` with `protocol` and `register_map` (as documented — never guessed).
3. Implement the adapter read loop (READ-ONLY) writing to `readings` with `source='REAL'` and updating `vehicles.last_seen`/`data_source='REAL'`.
4. Test against the real PLC or a vendor simulator. Do not send control commands; never bypass E-Stop/interlocks.
5. Background alarms/push (Firebase FCM) need a deployed backend + gateway + service account; not included.
