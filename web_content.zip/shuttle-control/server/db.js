import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const MIGRATIONS = [`
CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
CREATE TABLE sessions(token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), exp INTEGER NOT NULL);
CREATE TABLE manufacturers(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, country TEXT, protocol TEXT NOT NULL DEFAULT 'unverified', register_map TEXT NOT NULL DEFAULT '{}', docs TEXT NOT NULL DEFAULT '');
CREATE TABLE vehicles(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, manufacturer_id INTEGER REFERENCES manufacturers(id), model TEXT, status TEXT NOT NULL DEFAULT 'offline', hours REAL NOT NULL DEFAULT 0, data_source TEXT NOT NULL DEFAULT 'OFFLINE', last_seen TEXT, created_at TEXT NOT NULL);
CREATE TABLE batteries(id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, charge INTEGER NOT NULL DEFAULT 0, state TEXT NOT NULL DEFAULT 'idle', vehicle_id INTEGER REFERENCES vehicles(id), health INTEGER, cycles INTEGER NOT NULL DEFAULT 0);
CREATE TABLE battery_history(id INTEGER PRIMARY KEY, battery_id INTEGER NOT NULL, vehicle_id INTEGER, event TEXT NOT NULL, actor TEXT, ts TEXT NOT NULL);
CREATE TABLE faults(id INTEGER PRIMARY KEY, vehicle_id INTEGER NOT NULL REFERENCES vehicles(id), type TEXT NOT NULL, severity TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', assignee TEXT, resolution TEXT, reported_by TEXT, created_at TEXT NOT NULL, closed_at TEXT, downtime_min INTEGER);
CREATE TABLE maintenance(id INTEGER PRIMARY KEY, vehicle_id INTEGER NOT NULL REFERENCES vehicles(id), kind TEXT NOT NULL, due TEXT NOT NULL, done_at TEXT, technician TEXT, notes TEXT);
CREATE TABLE readings(id INTEGER PRIMARY KEY, vehicle_id INTEGER NOT NULL, signal TEXT NOT NULL, kind TEXT NOT NULL, value REAL, source TEXT NOT NULL, ts TEXT NOT NULL);
CREATE INDEX idx_readings ON readings(vehicle_id, signal, id);
CREATE TABLE audit(id INTEGER PRIMARY KEY, actor TEXT, action TEXT NOT NULL, detail TEXT, ts TEXT NOT NULL);
`, `
CREATE TABLE battery_cycles(id INTEGER PRIMARY KEY, battery_id INTEGER NOT NULL REFERENCES batteries(id), vehicle_id INTEGER REFERENCES vehicles(id), kind TEXT NOT NULL, start_pct INTEGER NOT NULL, end_pct INTEGER NOT NULL, started_at TEXT NOT NULL, ended_at TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'MANUAL', actor TEXT);
CREATE TABLE work_orders(id INTEGER PRIMARY KEY, vehicle_id INTEGER NOT NULL REFERENCES vehicles(id), fault_id INTEGER REFERENCES faults(id), title TEXT NOT NULL, fault_type TEXT, priority TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', technician TEXT, parts TEXT NOT NULL DEFAULT '[]', actions TEXT, downtime_min INTEGER, repair_min INTEGER, created_by TEXT, created_at TEXT NOT NULL, started_at TEXT, completed_at TEXT);
`];

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA foreign_keys=ON;');
  if (file !== ':memory:') db.exec('PRAGMA journal_mode=WAL;');
  db.exec('CREATE TABLE IF NOT EXISTS schema_version(v INTEGER)');
  let v = db.prepare('SELECT MAX(v) AS v FROM schema_version').get().v ?? 0;
  for (; v < MIGRATIONS.length; v++) {
    db.exec(MIGRATIONS[v]);
    db.prepare('INSERT INTO schema_version(v) VALUES(?)').run(v + 1);
  }
  return db;
}
