# Optional visual check (needs python3 + playwright + chromium). Start the server on port 8098 with ADMIN_PASSWORD=VisualTest12345 on an empty DB first.
import json, urllib.request
from playwright.sync_api import sync_playwright
B='http://127.0.0.1:8098'
def api(p,body=None,tok=None):
    r=urllib.request.Request(B+'/api'+p,data=json.dumps(body).encode() if body is not None else None,headers={'Content-Type':'application/json',**({'Authorization':'Bearer '+tok} if tok else {})})
    return json.load(urllib.request.urlopen(r))
tok=api('/login',{'username':'admin','password':'VisualTest12345'})['token']
api('/simulation/seed',{},tok)
v=api('/vehicles',None,tok)[0]['id']
for i in range(3): api('/faults',{'vehicle_id':v,'type':'sensor','severity':'high','description':'حساس معطل / sensor stuck '+'x'*60},tok)
api('/work-orders',{'vehicle_id':v,'title':'استبدال حساس طويل جدا '+'y'*80,'priority':'high','technician':'tech'},tok)
tabs=['dashboard','fleet','batteries','faults','maint','orders','reports','diag','plc','mfr','users','audit']
issues=[]
with sync_playwright() as p:
    br=p.chromium.launch()
    for name,vp in [('mobile',(390,844)),('tablet',(820,1180))]:
        for lang in ['ar','en']:
            for theme in ['dark','light']:
                ctx=br.new_context(viewport={'width':vp[0],'height':vp[1]})
                pg=ctx.new_page(); errs=[]
                pg.on('pageerror',lambda e:errs.append(str(e))); pg.on('console',lambda m: errs.append(m.text) if m.type=='error' else None)
                pg.goto(B); pg.evaluate(f"localStorage.setItem('lang','{lang}');localStorage.setItem('theme','{theme}')"); pg.reload()
                pg.fill('input[name=username]','admin'); pg.fill('input[name=password]','VisualTest12345'); pg.click('button:has-text("%s")'%('دخول' if lang=='ar' else 'Sign in'))
                pg.wait_for_selector('nav')
                for i,tb in enumerate(tabs):
                    pg.locator('nav button').nth(i).click(); pg.wait_for_timeout(250)
                    m=pg.evaluate("({sw:document.documentElement.scrollWidth,iw:innerWidth,dir:document.dir,th:document.documentElement.dataset.theme})")
                    if m['sw']>m['iw']+1: issues.append((name,lang,theme,tb,'overflow',m))
                    if m['dir']!=('rtl' if lang=='ar' else 'ltr') or m['th']!=theme: issues.append((name,lang,theme,tb,'dir/theme',m))
                    if (name,lang,theme,tb)==('mobile','ar','dark','dashboard') or (name,lang,theme,tb)==('tablet','en','light','reports'): pg.screenshot(path=f'/tmp/shots/{name}-{lang}-{theme}-{tb}.png',full_page=True)
                if errs: issues.append((name,lang,theme,'console',errs[:3]))
                ctx.close()
    br.close()
print(len(issues)); [print(i) for i in issues[:15]]
