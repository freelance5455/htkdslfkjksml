import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.js';

process.env.ADMIN_PASSWORD = 'TestPass12345';
let base, server, tok, tech, vid, bid, vid2;
const call = async (p, o = {}, t = tok) => {
  const r = await fetch(base + p, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: 'Bearer ' + t } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  const txt = await r.text(); let j = {}; try { j = JSON.parse(txt); } catch { j = { raw: txt }; }
  return { s: r.status, j, h: r.headers };
};
const login = async (u, p) => (await call('/api/login', { method: 'POST', body: { username: u, password: p } }, null)).j.token;

test.before(async () => {
  server = createApp({ dbPath: ':memory:', simulation: false });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
  tok = await login('admin', 'TestPass12345');
  await call('/api/users', { method: 'POST', body: { username: 'tech1', password: 'LongPassword123', role: 'technician' } });
  tech = await login('tech1', 'LongPassword123');
  vid = (await call('/api/vehicles', { method: 'POST', body: { code: 'SH-10' } })).j.id;
  vid2 = (await call('/api/vehicles', { method: 'POST', body: { code: 'SH-11' } })).j.id;
  bid = (await call('/api/batteries', { method: 'POST', body: { code: 'B-10', charge: 10 } })).j.id;
});
test.after(() => { server.closeAllConnections(); server.close(); });

test('battery cycles: record, validate, analytics never invent health', async () => {
  const ok = await call(`/api/batteries/${bid}/cycles`, { method: 'POST', body: { kind: 'charge', start_pct: 10, end_pct: 90, started_at: '2026-11-01T08:00:00Z', ended_at: '2026-11-01T10:00:00Z' } }, tech);
  assert.equal(ok.s, 200); assert.equal(ok.j.source, 'MANUAL');
  assert.equal((await call(`/api/batteries/${bid}/cycles`, { method: 'POST', body: { kind: 'charge', start_pct: 90, end_pct: 10 } }, tech)).s, 400);
  assert.equal((await call(`/api/batteries/${bid}/cycles`, { method: 'POST', body: { kind: 'discharge', start_pct: 10, end_pct: 50 } }, tech)).s, 400);
  assert.equal((await call(`/api/batteries/${bid}/cycles`, { method: 'POST', body: { kind: 'charge', start_pct: 1, end_pct: 2, started_at: '2026-11-02T10:00:00Z', ended_at: '2026-11-02T09:00:00Z' } }, tech)).s, 400);
  const a = (await call('/api/batteries/analytics')).j.batteries.find((b) => b.code === 'B-10');
  assert.equal(a.recorded_charge_sessions, 1); assert.equal(a.avg_charge_delta_pct, 80); assert.equal(a.avg_charge_minutes, 120);
  assert.ok(!('health' in a) && !('soh' in a));
  assert.equal((await call('/api/batteries/' + bid + '/cycles', {}, tech)).j.length, 1);
});
test('battery swap between shuttles keeps usage history for both batteries', async () => {
  const b2 = (await call('/api/batteries', { method: 'POST', body: { code: 'B-11', charge: 50 } })).j.id;
  await call('/api/batteries/' + bid, { method: 'PATCH', body: { vehicle_id: vid } }, tech);
  await call('/api/batteries/' + b2, { method: 'PATCH', body: { vehicle_id: vid } }, tech);
  const h1 = (await call(`/api/batteries/${bid}/history`)).j.map((x) => x.event);
  assert.deepEqual(h1, ['removed', 'installed']);
  await call('/api/batteries/' + bid, { method: 'PATCH', body: { vehicle_id: vid2 } }, tech);
  assert.equal((await call('/api/vehicles')).j.find((v) => v.code === 'SH-11').battery_code, 'B-10');
});
test('work orders: lifecycle, parts, validation, auto-close linked fault', async () => {
  const f = (await call('/api/faults', { method: 'POST', body: { vehicle_id: vid, type: 'sensor', severity: 'high', description: 'sensor stuck' } })).j;
  assert.equal((await call('/api/work-orders', { method: 'POST', body: { vehicle_id: vid2, fault_id: f.id, title: 't', priority: 'low' } }, tech)).s, 400, 'fault of another shuttle');
  const w = (await call('/api/work-orders', { method: 'POST', body: { vehicle_id: vid, fault_id: f.id, title: '=HYPERLINK("x")', fault_type: 'sensor', priority: 'high', technician: 'tech1' } }, tech)).j;
  assert.equal(w.status, 'open');
  assert.equal((await call('/api/work-orders', { method: 'POST', body: { vehicle_id: vid, title: 't', priority: 'urgent' } }, tech)).s, 400);
  const p = (await call('/api/work-orders/' + w.id, { method: 'PATCH', body: { status: 'in_progress', parts: [{ name: 'Sensor', ref: 'S-1', qty: 1 }] } }, tech)).j;
  assert.ok(p.started_at && p.parts[0].qty === 1);
  assert.equal((await call('/api/work-orders/' + w.id, { method: 'PATCH', body: { parts: [{ name: 'x', qty: 0 }] } }, tech)).s, 400);
  assert.equal((await call('/api/work-orders/' + w.id, { method: 'PATCH', body: { status: 'completed' } }, tech)).s, 400, 'needs actions/times');
  const d = (await call('/api/work-orders/' + w.id, { method: 'PATCH', body: { status: 'completed', actions: 'replaced sensor, tested', repair_min: 45, downtime_min: 90 } }, tech)).j;
  assert.equal(d.status, 'completed');
  const fault = (await call('/api/faults')).j.find((x) => x.id === f.id);
  assert.equal(fault.status, 'closed'); assert.equal(fault.downtime_min, 90);
  assert.equal((await call('/api/work-orders/' + w.id, { method: 'PATCH', body: { status: 'open' } }, tech)).s, 409, 'final');
});
test('reports: summary, repeated faults, technicians; CSV escapes formulas; admin only', async () => {
  for (let i = 0; i < 3; i++) await call('/api/faults', { method: 'POST', body: { vehicle_id: vid2, type: 'cable', severity: 'low', description: 'd' } });
  assert.equal((await call('/api/reports/summary', {}, tech)).s, 403);
  const r = (await call('/api/reports/summary')).j;
  assert.ok(r.repeated_faults.some((x) => x.vehicle === 'SH-11' && x.type === 'cable' && x.n === 3));
  assert.equal(r.technicians.find((x) => x.technician === 'tech1').avg_repair_min, 45);
  assert.equal(r.downtime_total_min, 90);
  const c = await call('/api/reports/work-orders.csv');
  assert.match(c.h.get('content-type'), /text\/csv/);
  assert.ok(c.j.raw.includes("'=HYPERLINK"), 'formula injection neutralised');
});
test('backup -> change -> restore returns exact data; audit kept; bad restore rolls back', async () => {
  const snap = async () => { const b = (await call('/api/backup')).j; const { audit, ...rest } = b.tables; return JSON.stringify(rest); };
  const backup = (await call('/api/backup')).j; const before = await snap();
  assert.ok(JSON.stringify(backup).includes('work_orders') && !JSON.stringify(backup).includes('pass_hash'));
  await call('/api/vehicles', { method: 'POST', body: { code: 'TMP-1' } });
  assert.notEqual(await snap(), before);
  assert.equal((await call('/api/restore', { method: 'POST', body: backup }, tech)).s, 403);
  assert.equal((await call('/api/restore', { method: 'POST', body: backup })).s, 200);
  assert.equal(await snap(), before);
  assert.ok((await call('/api/audit')).j.some((a) => a.action === 'restore'));
  const bad = structuredClone(backup); bad.tables.faults.push({ id: 9999, vehicle_id: 424242, type: 'x', severity: 'low', description: 'd', status: 'open', created_at: 't' });
  assert.equal((await call('/api/restore', { method: 'POST', body: bad })).s, 400);
  assert.equal(await snap(), before, 'rollback preserved data');
  const evil = structuredClone(backup); evil.tables.vehicles[0]['x); DROP TABLE users;--'] = 1;
  assert.equal((await call('/api/restore', { method: 'POST', body: evil })).s, 400);
  assert.equal((await call('/api/restore', { method: 'POST', body: { tables: {} } })).s, 400);
  assert.equal((await call('/api/users')).s, 200);
});
