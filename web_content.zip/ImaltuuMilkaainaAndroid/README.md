# IMALTUU MILKAA’INA — Android Project

**Qopheessaa:** Mubarak Aliyyii  
**Gulaalaa:** Falmataa Aliyyii

Project kun kitaaba `IMALTUU MILKAA’INA` HTML keessaa gara Android WebView appitti geeddara.

## APK ijaaruuf

Android Studio keessatti folder kana bani. Sana booda:

1. Gradle sync godhi.
2. `app` configuration filadhu.
3. **Build > Build APK(s)** filadhu.
4. APK debug argamu: `app/build/outputs/apk/debug/app-debug.apk`

## Odeeffannoo
- Application ID: `com.mubarak.imaltuumilkaaina`
- Version: `1.0`
- Min SDK: 23
- Target SDK: 35
- Internet permission hin barbaadu; kitaabni asset keessaa offline hojjetaa.
