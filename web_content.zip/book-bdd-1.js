/* JOSTECH — MANUEL 07 : BASES DE DONNÉES NIVEAU 1 */
registerLessonDetail(7, 1, "bdd-1-1-1", {
  title: "Leçon 1 : Modélisation Relationnelle, Cardinalités et Normalisation",
  duration: "40 min (Manuel complet)",
  objectives: [
    "Comprendre pourquoi un SGBDR (MySQL, PostgreSQL) remplace avantageusement de simples tableurs Excel.",
    "Modéliser Entités, Associations et Cardinalités (1:N et N:M avec table de jonction).",
    "Appliquer les 3 premières Formes Normales (1FN, 2FN, 3FN) et maîtriser PK / FK."
  ],
  prerequisites: ["Notions de fichiers et logique."],
  sections: [
    {
      type: "definition",
      term: "SGBDR, Clé Primaire (PK) et Clé Étrangère (FK)",
      text: "Un Système de Gestion de Base de Données Relationnelle (SGBDR) organise les données en tables (lignes = enregistrements, colonnes = attributs) reliées mathématiquement pour éliminer les doublons et empêcher les incohérences.\n• Clé Primaire (PK) : colonne unique et jamais nulle identifiant une ligne (ex: id_etudiant).\n• Clé Étrangère (FK) : colonne dans une table B qui référence la PK d'une table A pour garantir l'intégrité référentielle (impossible d'enregistrer une note pour un étudiant qui n'existe pas !)."
    },
    {
      type: "theory",
      title: "1. Gérer les relations 1:N et N:M (Many-to-Many)",
      text: "Lorsqu'on modélise (méthode Merise / Entité-Association) :\n• Relation 1 à Plusieurs (1:N) : 1 étudiant possède plusieurs notes, mais 1 note appartient à 1 seul étudiant → on place la clé étrangère id_etudiant du côté « Plusieurs » (dans la table Notes).\n• Relation Plusieurs à Plusieurs (N:M) : 1 étudiant suit plusieurs cours ET 1 cours est suivi par plusieurs étudiants → on doit obligatoirement créer une 3e table intermédiaire appelée « Table de jonction » (ex: Inscriptions(id_etudiant, id_cours, date_inscription))."
    },
    {
      type: "table",
      title: "2. Les trois Formes Normales essentielles (Codd)",
      headers: ["Forme Normale", "Règle d'or à respecter"],
      rows: [
        ["1FN (Atomicité)", "1 seule valeur par case (pas de liste 'Python, C, Java' dans une seule cellule !)."],
        ["2FN", "En 1FN + chaque colonne dépend de TOUTE la clé primaire (pas d'une partie)."],
        ["3FN", "En 2FN + aucune dépendance transitive (une colonne ne dépend pas d'une autre non-clé)."]
      ]
    },
    {
      type: "warning",
      title: "Piège classique de modélisation",
      text: "Ne stockez jamais l'âge calculable ni l'adresse d'une faculté recopiée 10 000 fois dans chaque ligne d'étudiant : stockez la date de naissance et créez une table Facultes séparée liée par id_faculte. Sinon, modifier le nom de la faculté obligerait à corriger 10 000 lignes avec risque d'erreurs !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Modéliser une bibliothèque JOSTECH",
      question: "Un Emprunteur peut emprunter plusieurs Livres au fil du temps, et un même Livre (titre) peut être emprunté par différents Emprunteurs successivement. Quelle est la cardinalité (1:N ou N:M) et comment traduire cela en tables ?",
      solution: "C'est une relation N:M (Plusieurs-à-Plusieurs). On crée 3 tables :\n1) Emprunteurs (id_emp PK, nom)\n2) Livres (id_livre PK, titre)\n3) Emprunts (id_emprunt PK, id_emp FK, id_livre FK, date_emprunt)."
    },
    {
      title: "Exercice 2 — Corriger une violation de 1FN",
      question: "La table Cours(id, titre, tags) contient une ligne : (1, 'Python', 'algo, boucle, poO'). Pourquoi viole-t-elle la 1re Forme Normale ?",
      solution: "Parce que la colonne tags contient plusieurs valeurs séparées par des virgules dans une seule cellule (non atomique). Il faut créer une table Tags et une table de liaison Cours_Tags."
    }
  ],
  summary: "La modélisation relationnelle (Merise, PK/FK, tables de jonction N:M et normalisation 1FN-3FN) garantit des bases de données propres, sans redondance et faciles à faire évoluer.",
  references: ["Codd, E. F. (1970) — A Relational Model of Data for Large Shared Data Banks.", "Date, C. J. — An Introduction to Database Systems."]
});