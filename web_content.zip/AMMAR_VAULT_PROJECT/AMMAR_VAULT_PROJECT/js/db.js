/* AMMAR VAULT - طبقة البيانات: كل سجل يُشفَّر قبل الحفظ. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const uid = () => Date.now().toString(36) + V.Crypto.b64(V.Crypto.rnd(6)).replace(/[^a-z0-9]/gi, '');
  function DB(store, auth) {
    // أي عملية أثناء القفل (مثلاً مهمة خلفية انتهت بعد القفل التلقائي) تُرفض برسالة واضحة بدل خطأ تشفير
    const guard = () => { if (!auth.key) throw Object.assign(new Error('الخزنة مقفلة'), { arabic: 'الخزنة مقفلة', locked: true }); return auth.key; }; // يُرجع المفتاح مرة واحدة كي لا يتغيّر أثناء العملية
    const k = (t, id) => `rec:${t}:${id}`;
    return {
      async put(table, obj) {
        const key = guard();
        const rec = { ...obj, id: obj.id || uid(), updatedAt: Date.now() };
        if (!rec.createdAt) rec.createdAt = rec.updatedAt;
        await store.set(k(table, rec.id), await V.Crypto.encrypt(key, rec));
        return rec;
      },
      async get(table, id) { const key = guard(); const s = await store.get(k(table, id)); return s ? V.Crypto.decrypt(key, s) : null; },
      async all(table) { const key = guard(); const ks = await store.keys(`rec:${table}:`);
        return Promise.all(ks.map(async (x) => V.Crypto.decrypt(key, await store.get(x)))); },
      async count(table) { return (await store.keys(`rec:${table}:`)).length; },
      async remove(table, id) { await store.del(k(table, id)); },
      // مرفقات (صور/PDF/أي ملف): تُشفَّر كاملة قبل الحفظ
      async putBlob({ name, type, bytes }) {
        const key = guard();
        const id = uid();
        await store.set('blob:' + id, await V.Crypto.encrypt(key, { name, type, data: V.Crypto.b64(bytes) }));
        return id;
      },
      async getBlob(id) { const key = guard(); const s = await store.get('blob:' + id); if (!s) return null;
        const o = await V.Crypto.decrypt(key, s); return { name: o.name, type: o.type, bytes: V.Crypto.unb64(o.data) }; },
      async removeBlob(id) { await store.del('blob:' + id); },
    };
  }
  V.DB = DB;
})();
