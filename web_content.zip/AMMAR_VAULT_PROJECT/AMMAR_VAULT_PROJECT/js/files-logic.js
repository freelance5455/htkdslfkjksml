/* AMMAR VAULT - منطق الملفات والصور (بدون واجهة، قابل للاختبار). */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const MAX_BYTES = 50 * 1024 * 1024;
  const lc = (s) => String(s || '').toLowerCase();
  const byName = (a, b) => a.name.localeCompare(b.name, 'ar');
  const childFolders = (folders, id) => folders.filter((f) => (f.parentId || null) === (id || null)).sort(byName);
  function breadcrumbs(folders, id) { const out = []; let c = id; while (c) { const f = folders.find((x) => x.id === c); if (!f) break; out.unshift({ id: f.id, name: f.name }); c = f.parentId || null; } return out; }
  const path = (folders, id) => breadcrumbs(folders, id).map((b) => b.name).join(' / ');
  function validateName(name, siblings) {
    const n = String(name || '').trim();
    if (!n) return 'الاسم مطلوب';
    if (/[\/\\]/.test(n)) return 'الاسم لا يجوز أن يحتوي / أو \\';
    if (siblings.some((s) => lc(s).trim() === lc(n))) return 'يوجد عنصر بنفس الاسم في هذا المكان';
    return null;
  }
  function uniqueName(name, existing) {
    const set = new Set(existing.map(lc)); if (!set.has(lc(name))) return name;
    const dot = name.lastIndexOf('.'), base = dot > 0 ? name.slice(0, dot) : name, ext = dot > 0 ? name.slice(dot) : '';
    for (let i = 2; ; i++) { const c = `${base} (${i})${ext}`; if (!set.has(lc(c))) return c; }
  }
  const folderEmpty = (folders, files, id) => !folders.some((f) => f.parentId === id) && !files.some((f) => f.folderId === id);
  const searchFiles = (files, q) => { q = lc(q).trim(); return files.filter((f) => !q || lc(f.name + ' ' + (f.description || '')).includes(q)).sort(byName); };
  function kindOf(type, name) {
    const n = lc(name);
    if (lc(type).startsWith('image/')) return 'image';
    if (type === 'application/pdf' || n.endsWith('.pdf')) return 'pdf';
    if (type === 'text/plain' || n.endsWith('.txt')) return 'text';
    return 'other';
  }
  const fmtSize = (b) => b < 1024 ? b + ' ب' : b < 1048576 ? (b / 1024).toFixed(1) + ' ك.ب' : (b / 1048576).toFixed(1) + ' م.ب';
  const PHOTO_CATS = ['عائلة', 'سفر', 'عمل', 'دراسة', 'وثائق', 'أخرى'];
  function searchPhotos(photos, albums, q, albumId) {
    q = lc(q).trim(); const an = (id) => (albums.find((a) => a.id === id) || {}).name || '';
    return photos.filter((p) => (!albumId || (albumId === 'none' ? !p.albumId : p.albumId === albumId)) &&
      (!q || lc([p.name, p.description, p.category, an(p.albumId)].join(' ')).includes(q))).sort((a, b) => b.createdAt - a.createdAt);
  }
  V.FilesLogic = { MAX_BYTES, childFolders, breadcrumbs, path, validateName, uniqueName, folderEmpty, searchFiles, kindOf, fmtSize, PHOTO_CATS, searchPhotos };
})();
