/* AMMAR VAULT - واجهة البحث الشامل (المرحلة 8) في الصفحة الرئيسية + فهرسة نص PDF محلياً. */
(function () {
  const V = window.Vault, S = V.SearchLogic, FL = V.FilesLogic;
  const WHERE = { docs: 'الوثائق', pass: 'كلمات المرور', debts: 'دفتر الديون', files: 'الملفات', photos: 'الصور', plan: 'جدولي', kb: 'مكتبتي المعرفية', links: 'الروابط' };
  let indexing = false;
  async function indexPdfs(db, onStatus) {
    if (indexing) return; indexing = true;
    try {
      const [docs, files, idx] = await Promise.all([db.all('documents'), db.all('files'), db.all('pdf_index')]);
      const pdfs = [...docs.flatMap((d) => (d.pdfs || []).map((p) => ({ blobId: p.id, name: p.name, section: 'docs', srcId: d.id }))),
        ...files.filter((f) => FL.kindOf(f.type, f.name) === 'pdf').map((f) => ({ blobId: f.blobId, name: f.name, section: 'files', srcId: f.id }))];
      const valid = new Set(pdfs.map((p) => p.blobId)); const have = new Set(idx.map((i) => i.id));
      for (const i of idx) if (!valid.has(i.id)) await db.remove('pdf_index', i.id);
      const todo = pdfs.filter((p) => !have.has(p.blobId)); let done = 0, fail = idx.filter((i) => valid.has(i.id) && !i.ok).length;
      for (const p of todo) {
        onStatus(`جاري فهرسة ملفات PDF… (${done + 1}/${todo.length})`);
        const b = await db.getBlob(p.blobId); const r = b ? await V.PdfText.extract(b.bytes) : { ok: false, text: '' };
        await db.put('pdf_index', { id: p.blobId, ...p, text: r.text || '', ok: r.ok }); done++; if (!r.ok) fail++;
      }
      onStatus(todo.length || fail ? `فُهرس نص ${pdfs.length - fail} من ${pdfs.length} ملف PDF.${fail ? ` تعذّر استخراج نص ${fail} (ممسوح ضوئياً يحتاج OCR، وهو غير مفعّل).` : ''}` : '');
      return todo.length > 0;
    } catch (e) { onStatus('تعذّرت فهرسة PDF: ' + e.message); } finally { indexing = false; }
  }
  async function buildCorpus(db) {
    const data = {}; for (const s of S.SOURCES) data[s.table] = await db.all(s.table);
    return S.buildEntries(data, await db.all('pdf_index'));
  }
  V.Search = { mount(el, { db, esc, nav }) {
    el.innerHTML = `<div class="gsearch"><input id="gq" type="text" placeholder="ابحث في كل الخزنة: وثائق، ملفات، ملخصات، PDF…" aria-label="بحث شامل"><p class="note" id="gst"></p><div class="rows" id="gr"></div></div>`;
    const inp = el.querySelector('#gq'), box = el.querySelector('#gr'), st = el.querySelector('#gst'); let corpus = null, t;
    const ensure = async () => corpus || (corpus = await buildCorpus(db));
    const run = async () => {
      const q = inp.value; if (!q.trim()) { box.innerHTML = ''; return; }
      const res = S.search(await ensure(), q, 40);
      box.innerHTML = res.length ? res.map((r, i) => `<button class="item" data-i="${i}"><b>${esc(r.entry.title)}</b><span>${esc(r.entry.type)} · ${esc(WHERE[r.entry.section] || '')}${r.entry.where ? ' · ' + esc(r.entry.where) : ''}</span><span class="snip" style="grid-column:1/3">${esc(r.snippet)}</span></button>`).join('') : '<p class="note">لا نتائج مطابقة.</p>';
      box.querySelectorAll('.item').forEach((b) => b.onclick = () => nav(res[b.dataset.i].entry.section, res[b.dataset.i].entry.id));
    };
    inp.oninput = () => { clearTimeout(t); t = setTimeout(run, 200); };
    inp.onfocus = () => ensure();
    indexPdfs(db, (m) => { if (st.isConnected) st.textContent = m; }).then((changed) => { if (changed) corpus = null; });
  } };
})();
