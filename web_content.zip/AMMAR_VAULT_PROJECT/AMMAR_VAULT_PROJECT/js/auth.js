/* AMMAR VAULT - كلمة المرور الرئيسية والقفل. المفتاح لا يُحفظ إلا في الذاكرة أثناء الفتح. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const C = () => V.Crypto;
  const META = 'meta:auth';
  const MIN_LEN = 8;
  function Auth(store) {
    let dek = null, verifiedAt = 0;
    const err = (m) => Object.assign(new Error(m), { arabic: m });
    const pack = async (pw) => {
      const salt = C().rnd(16), kek = await C().deriveKEK(pw, salt, C().ITER);
      return { v: 1, iter: C().ITER, salt: C().b64(salt), wrapped: await C().wrapDEK(dek, kek), check: await C().encrypt(dek, { ok: 1 }) };
    };
    return {
      get key() { return dek; },
      get unlocked() { return !!dek; },
      async isSetup() { return !!(await store.get(META)); },
      async setup(pw) {
        if (await this.isSetup()) throw err('تم إعداد الخزنة مسبقاً');
        if (!pw || pw.length < MIN_LEN) throw err('كلمة المرور يجب ألا تقل عن 8 أحرف');
        dek = await C().newDEK();
        await store.set(META, await pack(pw));
      },
      async unlock(pw) {
        const m = await store.get(META);
        if (!m) throw err('الخزنة غير معدّة');
        try { dek = await C().unwrapDEK(m.wrapped, await C().deriveKEK(pw, C().unb64(m.salt), m.iter)); }
        catch (e) { dek = null; throw err('كلمة المرور غير صحيحة'); }
        if (!m.check) { try { await store.set(META, { ...m, check: await C().encrypt(dek, { ok: 1 }) }); } catch (e) {} } // ترقية الخزائن القديمة
      },
      // فتح بمفتاح البيانات (للبصمة فقط): يُتحقق من صلاحيته بقيمة check
      async unlockWithKey(raw) {
        const m = await store.get(META); if (!m) throw err('الخزنة غير معدّة');
        if (!m.check) throw err('افتح الخزنة بكلمة المرور مرة واحدة أولاً');
        const k = await C().importDEK(raw);
        try { await C().decrypt(k, m.check); } catch (e) { throw err('مفتاح البصمة لم يعد صالحاً لهذه الخزنة'); }
        dek = k;
      },
      exportKey() { if (!dek) throw err('الخزنة مقفلة'); return C().exportDEK(dek); },
      lock() { dek = null; verifiedAt = 0; },
      // إعادة تحقق من كلمة المرور (لحماية الأقسام الحساسة) دون تغيير حالة الفتح
      async verify(pw) {
        const m = await store.get(META);
        try { await C().unwrapDEK(m.wrapped, await C().deriveKEK(pw, C().unb64(m.salt), m.iter)); }
        catch (e) { throw err('كلمة المرور غير صحيحة'); }
        verifiedAt = Date.now();
      },
      recentlyVerified(ms) { return !!dek && verifiedAt > 0 && Date.now() - verifiedAt < ms; },
      async changePassword(oldPw, newPw) {
        if (!newPw || newPw.length < MIN_LEN) throw err('كلمة المرور الجديدة يجب ألا تقل عن 8 أحرف');
        await this.unlock(oldPw);
        await store.set(META, await pack(newPw));
      },
    };
  }
  V.Auth = Auth;
})();
