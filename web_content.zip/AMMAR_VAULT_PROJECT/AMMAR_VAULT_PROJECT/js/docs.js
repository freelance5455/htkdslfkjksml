/* AMMAR VAULT - واجهة قسم الوثائق (المرحلة 4). */
(function () {
  const V = window.Vault, L = V.DocsLogic;
  V.Sections = V.Sections || {};
  const readBytes = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(new Uint8Array(r.result)); r.onerror = rej; r.readAsArrayBuffer(f); });

  V.Sections.docs = async function (m, { db, esc }) {
    let q = '', type = '';
    const list = async () => {
      const all = (await db.all('documents')).sort((a, b) => (L.status(a).days ?? 1e9) - (L.status(b).days ?? 1e9));
      const rows = all.filter((d) => (!type || d.type === type) &&
        (!q || [d.title, d.number, d.issuer, d.notes, d.type].join(' ').toLowerCase().includes(q.toLowerCase())));
      m.querySelector('#rows').innerHTML = rows.length ? rows.map((d) => { const s = L.status(d);
        return `<button class="item st-${s.state}" data-id="${d.id}"><b>${esc(d.title)}</b><span>${esc(d.type || '')}${d.number ? ' · ' + esc(d.number) : ''}</span><em>${L.label(s)}</em></button>`; }).join('')
        : `<p class="note">${all.length ? 'لا نتائج مطابقة.' : 'لا توجد وثائق بعد. اضغط «إضافة وثيقة» لتبدأ.'}</p>`;
      m.querySelectorAll('.item').forEach((b) => b.onclick = () => form(b.dataset.id));
    };
    const shell = () => {
      m.innerHTML = `<h2>الوثائق</h2><div class="row"><button class="btn ghost" id="add">إضافة وثيقة</button>
        <input id="q" type="text" placeholder="بحث في الوثائق" style="max-width:220px">
        <select id="t"><option value="">كل الأنواع</option>${L.TYPES.map((t) => `<option>${t}</option>`).join('')}</select></div><div id="rows" class="rows"></div>`;
      m.querySelector('#add').onclick = () => form();
      m.querySelector('#q').oninput = (e) => { q = e.target.value; list(); };
      m.querySelector('#t').onchange = (e) => { type = e.target.value; list(); };
      list();
    };
    async function form(id) {
      const d = id ? await db.get('documents', id) : { images: [], pdfs: [], alertDays: 30, type: L.TYPES[0] };
      let seq = 0; let images = [...d.images], pdfs = [...d.pdfs]; const removed = [];
      const newFiles = [];
      m.innerHTML = `<h2>${id ? 'تعديل وثيقة' : 'وثيقة جديدة'}</h2><form class="panel wide" id="f" autocomplete="off">
        <label>اسم الوثيقة</label><input name="title" type="text" value="${esc(d.title || '')}" required>
        <label>النوع</label><select name="type">${L.TYPES.map((t) => `<option ${t === d.type ? 'selected' : ''}>${t}</option>`).join('')}</select>
        <label>رقم الوثيقة</label><input name="number" type="text" value="${esc(d.number || '')}">
        <label>جهة الإصدار</label><input name="issuer" type="text" value="${esc(d.issuer || '')}">
        <label>تاريخ الإصدار</label><input name="issueDate" type="date" value="${d.issueDate || ''}">
        <label>تاريخ الانتهاء</label><input name="expiryDate" type="date" value="${d.expiryDate || ''}">
        <label>التنبيه قبل الانتهاء بـ (أيام)</label><input name="alertDays" type="text" inputmode="numeric" value="${d.alertDays ?? 30}">
        <label>ملاحظات</label><textarea name="notes" rows="3">${esc(d.notes || '')}</textarea>
        <label>صور الوثيقة (يمكن أكثر من صورة)</label><input id="im" type="file" accept="image/*" multiple>
        <div class="thumbs" id="ith"></div>
        <label>ملفات PDF</label><input id="pf" type="file" accept="application/pdf" multiple><div id="pth"></div>
        <p class="err" id="e" role="alert"></p>
        <div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button>
        ${id ? '<button type="button" class="btn ghost danger" id="dl">حذف</button>' : ''}</div></form>`;
      const f = m.querySelector('#f'), e = m.querySelector('#e');
      const paint = async () => {
        const my = ++seq; const ith = m.querySelector('#ith'), fi = document.createDocumentFragment();
        for (const bid of images) { const b = await db.getBlob(bid); if (!b) continue;
          const w = document.createElement('div'); w.className = 'th';
          const img = new Image(); img.alt = b.name; img.src = URL.createObjectURL(new Blob([b.bytes], { type: b.type }));
          img.onclick = () => (V.Native.isNative() ? V.UI.openBytes(b.name, b.type, b.bytes) : window.open(img.src));
          const x = document.createElement('button'); x.type = 'button'; x.textContent = '×'; x.setAttribute('aria-label', 'إزالة الصورة');
          x.onclick = () => { images = images.filter((i) => i !== bid); removed.push(bid); paint(); };
          w.append(img, x); fi.append(w); }
        const pth = m.querySelector('#pth'), fp = document.createDocumentFragment();
        for (const p of pdfs) { const r = document.createElement('div'); r.className = 'row';
          const a = document.createElement('button'); a.type = 'button'; a.className = 'btn ghost'; a.textContent = p.name;
          a.onclick = async () => { const b = await db.getBlob(p.id); V.UI.openBytes(p.name, 'application/pdf', b.bytes); };
          const x = document.createElement('button'); x.type = 'button'; x.className = 'btn ghost'; x.textContent = 'إزالة';
          x.onclick = () => { pdfs = pdfs.filter((i) => i.id !== p.id); removed.push(p.id); paint(); };
          r.append(a, x); fp.append(r); }
        if (my !== seq) return; // استدعاء أحدث بدأ أثناء الانتظار: لا نكتب نتيجة قديمة
        ith.replaceChildren(fi); pth.replaceChildren(fp);
      };
      paint();
      const add = (inp, kind) => inp.onchange = async () => {
        for (const file of inp.files) { const bytes = await readBytes(file);
          const bid = await db.putBlob({ name: file.name, type: file.type, bytes }); newFiles.push(bid);
          kind === 'img' ? images.push(bid) : pdfs.push({ id: bid, name: file.name }); }
        inp.value = ''; paint(); };
      add(m.querySelector('#im'), 'img'); add(m.querySelector('#pf'), 'pdf');
      const cleanupNew = () => Promise.all(newFiles.filter((b) => ![...images, ...pdfs.map((p) => p.id)].includes(b)).map((b) => db.removeBlob(b)));
      m.querySelector('#cn').onclick = async () => { await Promise.all(newFiles.map((b) => db.removeBlob(b))); shell(); };
      f.onsubmit = async (ev) => {
        ev.preventDefault();
        const o = { ...d, title: f.title.value.trim(), type: f.type.value, number: f.number.value.trim(), issuer: f.issuer.value.trim(),
          issueDate: f.issueDate.value, expiryDate: f.expiryDate.value, alertDays: f.alertDays.value.trim() === '' ? 30 : +f.alertDays.value,
          notes: f.notes.value, images, pdfs };
        const bad = L.validate({ ...o, alertDays: f.alertDays.value }); if (bad) { e.textContent = bad; return; }
        await db.put('documents', o);
        await Promise.all(removed.filter((b) => !newFiles.includes(b) || true).map((b) => db.removeBlob(b)));
        await cleanupNew(); shell();
      };
      const dl = m.querySelector('#dl');
      if (dl) dl.onclick = async () => {
        if (!confirm('حذف هذه الوثيقة وكل مرفقاتها نهائياً؟')) return;
        await Promise.all([...d.images, ...d.pdfs.map((p) => p.id)].map((b) => db.removeBlob(b)));
        await db.remove('documents', id); shell();
      };
    }
    const pid = V.takePending('docs'); pid ? form(pid) : shell();
  };
})();
