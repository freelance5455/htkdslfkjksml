/* AMMAR VAULT - واجهة النسخ الاحتياطي والاستعادة (المرحلة 12) + قسم الإحصائيات (المرحلة 11). النسخ يدوي فقط عند الضغط على الزر. */
(function () {
  const V = window.Vault, B = V.Backup, UI = V.UI, FL = V.FilesLogic;
  V.Sections = V.Sections || {};
  const snapStore = () => V.Storage.auto('ammar_vault_snapshot');
  const LBL = { documents: 'وثائق', accounts: 'حسابات', debt_people: 'أشخاص (ديون)', debt_tx: 'عمليات ديون', files: 'ملفات', folders: 'مجلدات', photos: 'صور', albums: 'ألبومات', tasks: 'مهام', notes: 'ملخصات', links: 'روابط', _blobs: 'مرفقات وصور وملفات' };
  const counts = (c, esc) => '<ul style="margin:.4rem 0;padding-inline-start:1.2rem">' + Object.entries(c || {}).map(([k, n]) => `<li>${esc(LBL[k] || k)}: ${n}</li>`).join('') + '</ul>';
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const setPref = (k, v) => { try { localStorage.setItem('av_' + k, v); } catch (e) {} };
  const getPref = (k) => { try { return localStorage.getItem('av_' + k); } catch (e) { return null; } };

  // حفظ الملف: منتقي الملفات (إن وُجد) ثم إعادة قراءة الملف المحفوظ؛ وإلا تنزيل عادي.
  // اختيار مجلد Android/USB عبر Storage Access Framework يتطلب إضافة أصلية (المرحلة 13) ولم يُنفَّذ بعد.
  async function save(name, bytes) {
    if (V.Native.isNative() && V.Native.plugin('AmmarFile')) {
      try { const r = await V.Native.saveDocument(name, bytes); return { method: 'saf', name: r.name, nativeHash: r.sha256 }; }
      catch (e) { if (e.code === 'CANCELLED' || /CANCELLED/.test(e.message || '')) return { method: 'cancelled' }; throw e; }
    }
    if (window.showSaveFilePicker) {
      try {
        const h = await window.showSaveFilePicker({ suggestedName: name, types: [{ description: 'نسخة AMMAR VAULT', accept: { 'application/octet-stream': ['.avbak'] } }] });
        const w = await h.createWritable(); await w.write(bytes); await w.close();
        return { method: 'picker', name: h.name, readBack: new Uint8Array(await (await h.getFile()).arrayBuffer()) };
      } catch (e) { if (e.name === 'AbortError') return { method: 'cancelled' }; }
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([bytes], { type: 'application/octet-stream' })); a.download = name; document.body.append(a); a.click(); a.remove();
    return { method: 'download', name };
  }
  V.FileSaver = { save };

  function backupFlow({ store, auth, onDone }) {
    const d = UI.dialog('حفظ نسخة احتياطية', '<p>سيُنشأ ملف واحد مضغوط ومشفّر يحوي كل بياناتك ومرفقاتك. أدخل كلمة المرور الرئيسية للمتابعة، ثم اختر مكان الحفظ.</p><input name="pw" type="password" required autofocus><p class="note" id="pg"></p>', { ok: 'إنشاء النسخة', onOk: async (f) => {
      const pw = f.pw.value, pg = d.body.querySelector('#pg'), prog = (s, i, n) => { pg.textContent = n ? `${s} (${i}/${n})` : s; };
      await auth.verify(pw);
      const { bytes, manifest } = await B.create(store, pw, prog);
      const v = await B.verify(bytes, pw, store, prog); if (!v.ok) throw new Error('فشل التحقق من سلامة النسخة: ' + v.problems[0]);
      prog('اختيار مكان الحفظ…'); const r = await V.FileSaver.save(B.fileName(), bytes);
      if (r.method === 'cancelled') throw new Error('أُلغي الحفظ ولم يُحفظ أي ملف.');
      let verified = 'تم التحقق من سلامة النسخة قبل الحفظ (فك تشفير كل السجلات بنجاح).';
      if (r.nativeHash) { if ((await V.Crypto.sha256(bytes)) !== r.nativeHash) throw new Error('الملف المحفوظ لا يطابق النسخة. أعد المحاولة.'); verified += ' وأُعيدت قراءة الملف المحفوظ من التخزين والتأكد من مطابقته.'; }
      if (r.readBack) { if ((await V.Crypto.sha256(r.readBack)) !== (await V.Crypto.sha256(bytes))) throw new Error('الملف المحفوظ لا يطابق النسخة. أعد المحاولة.'); verified += ' وتمت إعادة قراءة الملف المحفوظ والتأكد من مطابقته.'; }
      setPref('lastBackup', new Date().toISOString());
      const where = r.method === 'saf' ? 'في المجلد الذي اخترتَه عبر مستعرض ملفات Android' : r.method === 'picker' ? 'في المكان الذي اخترتَه' : 'أُرسل إلى تنزيلات جهازك (تحقّق من ظهوره في مجلد التنزيلات)';
      UI.dialog('تم إنشاء النسخة', `<p><b dir="ltr">${esc(r.name)}</b></p><p>الحجم: ${FL.fmtSize(bytes.length)} · السجلات: ${manifest.records}</p>${counts(manifest.counts, esc)}<p>المكان: ${where}.</p><p class="note">${verified} احتفظ بالملف في مكان آخر غير الهاتف (فلاش أو حاسوب) واحفظ كلمة المرور الرئيسية.</p>`);
      if (onDone) onDone();
    } });
  }

  function restoreFlow({ store, afterRestore }) {
    let parsed = null;
    const d = UI.dialog('استعادة نسخة احتياطية', '<p>اختر ملف النسخة (.avbak) وأدخل كلمة المرور الرئيسية وقت إنشائها. يعمل دون إنترنت وعلى أي جهاز.</p><input id="rf" type="file" required><label>كلمة المرور</label><input name="pw" type="password" required><p class="note" id="pg"></p><div id="rp"></div>', { ok: 'فحص النسخة', onOk: async (f) => {
      if (parsed) return false;
      const file = d.body.querySelector('#rf').files[0]; if (!file) throw new Error('اختر ملف النسخة أولاً');
      const pg = d.body.querySelector('#pg'), err = d.form.querySelector('.err'); pg.textContent = 'جاري فحص الملف والتحقق من سلامته…';
      parsed = await B.open(await UI.readBytes(file), f.pw.value); pg.textContent = '';
      const had = (await store.get('meta:auth')) != null, m = parsed.manifest;
      d.body.querySelector('#rp').innerHTML = `<div class="panel" style="max-width:none"><b>النسخة سليمة</b><p class="note">أُنشئت: ${esc(new Date(m.createdAt).toLocaleString('ar'))} · السجلات: ${m.records}</p>${counts(m.counts, esc)}
        ${had ? '<p style="color:var(--danger)">ستُستبدل بياناتك الحالية بمحتوى النسخة. تُحفظ لقطة من بياناتك الحالية تتيح لك التراجع لاحقاً.</p><label style="display:flex;gap:8px;align-items:center;color:var(--text)"><input type="checkbox" id="ck"> أفهم أن بياناتي الحالية ستُستبدل</label>' : ''}
        <button type="button" class="btn" id="go">استعادة الآن</button></div>`;
      d.form.querySelector('.btn:not(.ghost):not(#go)').style.display = 'none';
      d.body.querySelector('#go').onclick = async (ev) => {
        if (had && !d.body.querySelector('#ck').checked) { err.textContent = 'أكّد أنك تفهم أن بياناتك الحالية ستُستبدل.'; return; }
        ev.target.disabled = true; err.textContent = '';
        try { const r = await B.restore(store, parsed, snapStore(), (s, i, n) => { pg.textContent = `${s} (${i}/${n})`; }); d.close();
          UI.dialog('تمت الاستعادة', `<p>استُعيدت ${r.records} عنصراً بنجاح.</p>${counts(r.counts, esc)}<p class="note">سجّل الدخول الآن بكلمة المرور الرئيسية الخاصة بهذه النسخة.${r.hadData ? ' يمكنك التراجع من قسم «النسخ الاحتياطي».' : ''}</p>`);
          afterRestore(); } catch (e) { err.textContent = e.arabic || e.message; ev.target.disabled = false; }
      };
      return false;
    } });
  }
  V.BackupUI = { backupFlow, restoreFlow };

  V.Sections.backup = async function (m, { esc, auth, store }) {
    const has = await B.hasSnapshot(snapStore()), last = getPref('lastBackup');
    m.innerHTML = `<h2>النسخ الاحتياطي والاستعادة</h2><div class="panel wide"><p>النسخ يدوي فقط؛ لا تُنشأ نسخ تلقائية.</p>
      <p class="note">آخر نسخة من هذا الجهاز: ${last ? esc(new Date(last).toLocaleString('ar')) : 'لا توجد'}</p>
      <div class="row"><button class="btn" id="bk" style="width:auto">حفظ نسخة احتياطية</button><button class="btn ghost" id="rt">استعادة نسخة احتياطية</button></div>
      ${has ? '<div class="row"><button class="btn ghost danger" id="undo">التراجع عن آخر استعادة</button><button class="btn ghost" id="dsn">حذف اللقطة</button></div>' : ''}
      <p class="note">الملف مشفّر بكلمة المرور الرئيسية، ويُستعاد على أي هاتف بها وحدها. إن نسيتها فلا يمكن فتح النسخة.</p></div>`;
    m.querySelector('#bk').onclick = () => backupFlow({ store, auth, onDone: () => V.Sections.backup(m, { esc, auth, store }) });
    m.querySelector('#rt').onclick = () => restoreFlow({ store, afterRestore: V.relock });
    const u = m.querySelector('#undo'); if (u) u.onclick = async () => { if (!confirm('سيُستبدل ما في الخزنة الآن بلقطة بياناتك قبل آخر استعادة. متابعة؟')) return; await B.undo(store, snapStore()); V.relock(); };
    const ds = m.querySelector('#dsn'); if (ds) ds.onclick = async () => { if (confirm('حذف اللقطة نهائياً؟ لن يمكن التراجع عن آخر استعادة.')) { await snapStore().clear(); V.Sections.backup(m, { esc, auth, store }); } };
  };

  V.Sections.stats = async function (m, { db, esc }) {
    const d = {}; for (const n of ['documents', 'accounts', 'photos', 'files', 'notes', 'links', 'debt_people', 'debt_tx', 'tasks']) d[n] = await db.all(n);
    const s = V.StatsLogic.compute(d, Date.now()), Dl = V.DebtsLogic, P = V.PlanLogic, c = (v, l) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`;
    m.innerHTML = `<h2>الإحصائيات</h2><h3>المحتوى</h3><div class="grid">${c(s.documents, 'وثائق')}${c(s.accounts, 'حسابات محفوظة')}${c(s.photos, 'صور')}${c(s.files, 'ملفات')}${c(s.notes, 'ملخصات')}${c(s.links, 'روابط')}${c(FL.fmtSize(s.mediaBytes), 'حجم الملفات والصور')}</div>
      <h3>الديون</h3><div class="grid">${c(Dl.fmt(s.debts.outstanding), 'إجمالي الديون المستحقة')}${c(Dl.fmt(s.debts.paid), 'إجمالي المسدد')}${c(s.debts.debtors, 'عدد المدينين')}</div>
      <h3>المهام</h3><div class="grid">${c(s.tasks.completed, 'مهام مكتملة')}${c(s.tasks.remaining, 'مهام متبقية (حتى 7 أيام)')}${c(s.tasks.overdue, 'مهام متأخرة')}</div>
      <h3>المواعيد القادمة (7 أيام)</h3><div class="rows">${s.upcoming.length ? s.upcoming.map((o) => `<div class="item"><b>${esc(o.task.title)}</b><span>${P.DAY_NAMES[P.parseD(o.date).getDay()]} ${o.date} ${o.task.startTime || ''}</span></div>`).join('') : '<p class="note">لا مواعيد قادمة.</p>'}</div>
      <h3>وثائق اقترب انتهاؤها أو انتهت</h3><div class="rows">${s.docAlerts.length ? s.docAlerts.map((x) => `<div class="item st-${x.st.state}"><b>${esc(x.doc.title)}</b><span>${V.DocsLogic.label(x.st)}</span></div>`).join('') : '<p class="note">لا تنبيهات.</p>'}</div>`;
  };
})();
