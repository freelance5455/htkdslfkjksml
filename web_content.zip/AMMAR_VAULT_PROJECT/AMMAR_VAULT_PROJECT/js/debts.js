/* AMMAR VAULT - واجهة دفتر الديون (المرحلة 6). الأشخاص في debt_people والعمليات في debt_tx. لا تُحذف عملية منفردة حفاظاً على السجل. */
(function () {
  const V = window.Vault, L = V.DebtsLogic;
  V.Sections = V.Sections || {};
  const today = () => { const d = new Date(), z = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`; };
  const readBytes = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(new Uint8Array(r.result)); r.onerror = rej; r.readAsArrayBuffer(f); });

  V.Sections.debts = async function (m, { db, esc }) {
    let q = '';
    const load = async () => { const [people, txs] = await Promise.all([db.all('debt_people'), db.all('debt_tx')]); return { people, txs }; };
    const mine = (txs, id) => txs.filter((t) => t.personId === id);

    async function home() {
      const { people, txs } = await load(); const T = L.totals(people, txs);
      m.innerHTML = `<h2>دفتر الديون</h2><div class="grid">
        <div class="stat"><b>${L.fmt(T.outstanding)}</b><span>إجمالي الديون المستحقة</span></div>
        <div class="stat"><b>${L.fmt(T.paid)}</b><span>إجمالي المسدد</span></div>
        <div class="stat"><b>${T.debtors}</b><span>عدد المدينين</span></div>
        <div class="stat"><b>${T.settled}</b><span>حسابات مسددة</span></div>
        <div class="stat"><b>${T.open}</b><span>حسابات متبقية</span></div></div>
        <div class="row"><button class="btn ghost" id="add">إضافة شخص</button><input id="q" type="text" placeholder="بحث بالاسم أو الهاتف" style="max-width:230px" value="${esc(q)}"></div><div class="rows" id="rows"></div>`;
      m.querySelector('#add').onclick = () => personForm();
      m.querySelector('#q').oninput = (e) => { q = e.target.value; paint(people, txs); };
      paint(people, txs);
    }
    function paint(people, txs) {
      const k = q.trim().toLowerCase();
      const rows = people.filter((p) => !k || (p.name + ' ' + (p.phone || '')).toLowerCase().includes(k)).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
      m.querySelector('#rows').innerHTML = rows.length ? rows.map((p) => { const s = L.summarize(mine(txs, p.id));
        const tail = s.status === 'settled' ? `<em>مسدد بالكامل</em><span class="okmsg">${L.SETTLED_MSG}</span>` : s.status === 'empty' ? '<em>لا ديون مسجلة</em>' : `<em>${L.fmt(s.remaining)}</em>`;
        return `<button class="item st-${s.status === 'open' ? 'soon' : 'valid'}" data-id="${p.id}"><b>${esc(p.name)}</b><span>${esc(p.phone || '')}</span>${tail}</button>`; }).join('')
        : `<p class="note">${people.length ? 'لا نتائج مطابقة.' : 'الدفتر فارغ. اضغط «إضافة شخص» لتبدأ.'}</p>`;
      m.querySelectorAll('.item').forEach((b) => b.onclick = () => detail(b.dataset.id));
    }

    function personForm(id) {
      return (async () => {
        const p = id ? await db.get('debt_people', id) : {};
        m.innerHTML = `<h2>${id ? 'تعديل بيانات الشخص' : 'شخص جديد'}</h2><form class="panel wide" id="f" autocomplete="off">
          <label>الاسم</label><input name="name" type="text" value="${esc(p.name || '')}" required>
          <label>رقم الهاتف</label><input name="phone" type="text" dir="ltr" inputmode="tel" value="${esc(p.phone || '')}">
          <label>ملاحظات</label><textarea name="notes" rows="3">${esc(p.notes || '')}</textarea><p class="err" id="e" role="alert"></p>
          <div class="row"><button class="btn" style="width:auto">${id ? 'حفظ' : 'التالي: تسجيل الدين'}</button><button type="button" class="btn ghost" id="cn">رجوع</button></div></form>`;
        m.querySelector('#cn').onclick = () => (id ? detail(id) : home());
        m.querySelector('#f').onsubmit = async (ev) => { ev.preventDefault(); const f = ev.target;
          if (!f.name.value.trim()) { m.querySelector('#e').textContent = 'الاسم مطلوب'; return; }
          const saved = await db.put('debt_people', { ...p, name: f.name.value.trim(), phone: f.phone.value.trim(), notes: f.notes.value });
          id ? detail(saved.id) : txForm(saved.id, 'debt'); };
      })();
    }

    async function txForm(personId, kind) {
      const { txs } = await load(); const person = await db.get('debt_people', personId);
      const rem = L.summarize(mine(txs, personId)).remaining; const added = [];
      m.innerHTML = `<h2>${kind === 'debt' ? 'تسجيل دين' : 'تسجيل سداد'} — ${esc(person.name)}</h2><form class="panel wide" id="f" autocomplete="off">
        ${kind === 'payment' ? `<p>المتبقي حالياً: <b>${L.fmt(rem)}</b> <button type="button" class="btn ghost" id="full" style="padding:.2rem .7rem">سداد كامل</button></p>` : ''}
        <label>المبلغ</label><input name="amount" type="text" inputmode="decimal" dir="ltr" required>
        <label>التاريخ</label><input name="date" type="date" value="${today()}" required>
        <label>${kind === 'debt' ? 'سبب الدين' : 'ملاحظة'}</label><input name="reason" type="text">
        <label>صور أو إيصالات</label><input id="rc" type="file" accept="image/*" multiple><div class="thumbs" id="th"></div><p class="err" id="e" role="alert"></p>
        <div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button></div></form>`;
      const f = m.querySelector('#f'); const full = m.querySelector('#full'); if (full) full.onclick = () => f.amount.value = rem / 100;
      m.querySelector('#rc').onchange = async (e) => { for (const file of e.target.files) { const id = await db.putBlob({ name: file.name, type: file.type, bytes: await readBytes(file) }); added.push(id); }
        e.target.value = ''; m.querySelector('#th').textContent = `${added.length} إيصال مرفق`; };
      m.querySelector('#cn').onclick = async () => { await Promise.all(added.map((b) => db.removeBlob(b))); detail(personId); };
      f.onsubmit = async (ev) => { ev.preventDefault();
        const amount = parseFloat(f.amount.value.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(',', '.'));
        const tx = { personId, kind, amount, date: f.date.value, reason: f.reason.value.trim(), receipts: added };
        const bad = L.validateTx(tx, rem); if (bad) { m.querySelector('#e').textContent = bad; return; }
        await db.put('debt_tx', tx); detail(personId); };
    }

    async function detail(id) {
      const { txs } = await load(); const p = await db.get('debt_people', id), my = mine(txs, id), s = L.summarize(my);
      m.innerHTML = `<h2>${esc(p.name)}</h2><p class="note" dir="auto">${esc(p.phone || '')} ${p.notes ? '· ' + esc(p.notes) : ''}</p>
        ${s.status === 'settled' ? `<div class="panel wide okbox">${L.SETTLED_MSG}</div>` : ''}
        <div class="grid"><div class="stat"><b>${L.fmt(s.original)}</b><span>المبلغ الأصلي</span></div><div class="stat"><b>${L.fmt(s.paid)}</b><span>المسدد</span></div><div class="stat"><b>${L.fmt(Math.max(s.remaining, 0))}</b><span>المتبقي</span></div></div>
        <div class="row"><button class="btn ghost" id="d">إضافة دين</button>${s.status === 'open' ? '<button class="btn ghost" id="p">تسجيل سداد</button>' : ''}<button class="btn ghost" id="e">تعديل البيانات</button><button class="btn ghost" id="b">رجوع</button><button class="btn ghost danger" id="x">حذف الشخص وسجله</button></div>
        <h3>سجل العمليات</h3><div class="rows" id="h">${s.status === 'empty' && !my.length ? '<p class="note">لا عمليات بعد.</p>' : ''}</div>`;
      m.querySelector('#d').onclick = () => txForm(id, 'debt'); const pb = m.querySelector('#p'); if (pb) pb.onclick = () => txForm(id, 'payment');
      m.querySelector('#e').onclick = () => personForm(id); m.querySelector('#b').onclick = home;
      m.querySelector('#x').onclick = async () => { if (!confirm(`حذف «${p.name}» وكل سجل ديونه وسداداته وإيصالاته نهائياً؟`)) return;
        for (const t of my) { await Promise.all((t.receipts || []).map((b) => db.removeBlob(b))); await db.remove('debt_tx', t.id); }
        await db.remove('debt_people', id); home(); };
      const h = m.querySelector('#h');
      for (const t of L.history(my)) { const row = document.createElement('div'); row.className = 'item';
        row.innerHTML = `<b>${t.kind === 'debt' ? 'دين' : 'سداد'}: ${L.fmt(L.cents(t.amount))}</b><span>${esc(t.date)}${t.reason ? ' · ' + esc(t.reason) : ''}</span>`;
        for (const bid of t.receipts || []) { const b = await db.getBlob(bid); if (!b) continue; const a = document.createElement('button'); a.className = 'btn ghost'; a.textContent = 'إيصال'; a.style.cssText = 'grid-column:1/3;width:auto;padding:.2rem .7rem';
          a.onclick = () => V.UI.openBytes(b.name || 'receipt', b.type, b.bytes); row.append(a); }
        h.append(row); }
    }
    const pid = V.takePending('debts'); pid ? detail(pid) : home();
  };
})();
