/* AMMAR VAULT - إبطاء المحاولات الخاطئة لكلمة المرور (على مستوى التطبيق). لا يمنع هجوماً يملك ملفات الجهاز؛ حماية ذلك هي قوة كلمة المرور وPBKDF2. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const SCHEDULE = [0, 0, 0, 0, 30, 60, 120, 300, 900]; // ثوانٍ بعد المحاولة الخاطئة رقم 1..9، ثم ساعة
  const delayFor = (n) => (n <= 0 ? 0 : n <= SCHEDULE.length ? SCHEDULE[n - 1] : 3600);
  const lsStore = () => ({ get: () => { try { return JSON.parse(localStorage.getItem('av_att') || 'null'); } catch (e) { return null; } },
    set: (v) => { try { localStorage.setItem('av_att', JSON.stringify(v)); } catch (e) {} } });
  function create(storage, now) {
    const st = storage || lsStore(), clock = now || Date.now;
    const read = () => st.get() || { n: 0, until: 0 };
    return {
      status() { const s = read(), left = Math.ceil((s.until - clock()) / 1000); return { locked: left > 0, seconds: Math.max(left, 0), failures: s.n }; },
      fail() { const s = read(); s.n += 1; s.until = clock() + delayFor(s.n) * 1000; st.set(s); },
      ok() { st.set({ n: 0, until: 0 }); },
    };
  }
  V.Attempts = Object.assign(create(), { create, delayFor });
})();
