/* AMMAR VAULT - واجهة مدير كلمات المرور (المرحلة 5). القسم محمي بإعادة إدخال كلمة المرور الرئيسية. */
(function () {
  const V = window.Vault, L = V.PassLogic, GRACE = 2 * 60000;
  V.Sections = V.Sections || {};
  let clipTimer = null;
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); }
    catch (e) { const t = document.createElement('textarea'); t.value = text; document.body.append(t); t.select(); document.execCommand('copy'); t.remove(); }
    clearTimeout(clipTimer); clipTimer = setTimeout(() => navigator.clipboard && navigator.clipboard.writeText('').catch(() => {}), 30000);
  }
  V.Sections.pass = async function (m, { db, esc, auth }) {
    if (!auth.recentlyVerified(GRACE)) {
      m.innerHTML = `<h2>كلمات المرور</h2><form class="panel" id="v" autocomplete="off"><p>هذا القسم محمي. أدخل كلمة المرور الرئيسية للمتابعة.</p>
        <input id="pw" type="password" required autofocus><button class="btn">تحقق</button><p class="err" id="e" role="alert"></p></form>`;
      m.querySelector('#v').onsubmit = async (ev) => { ev.preventDefault();
        try { await auth.verify(m.querySelector('#pw').value); V.Sections.pass(m, { db, esc, auth }); }
        catch (x) { m.querySelector('#e').textContent = x.arabic || 'تعذّر التحقق'; } };
      return;
    }
    let q = '', cat = ''; const shown = new Set();
    const list = async () => {
      const rows = L.search(await db.all('accounts'), q, cat);
      const box = m.querySelector('#rows');
      box.innerHTML = rows.length ? rows.map((a) => `<div class="item acc" data-id="${a.id}"><b>${esc(a.site)}</b>
        <span>${esc(a.username || a.email || '')}${a.category ? ' · ' + esc(a.category) : ''}</span>
        <code dir="ltr">${shown.has(a.id) ? esc(a.password) : '••••••••'}</code>
        <div class="row"><button class="btn ghost" data-a="show">${shown.has(a.id) ? 'إخفاء' : 'إظهار'}</button><button class="btn ghost" data-a="copy">نسخ</button><button class="btn ghost" data-a="edit">تعديل</button>${a.url ? '<button class="btn ghost" data-a="open">فتح الرابط</button>' : ''}</div></div>`).join('')
        : '<p class="note">لا توجد حسابات مطابقة. اضغط «إضافة حساب».</p>';
      box.querySelectorAll('.acc').forEach((el) => {
        const a = rows.find((r) => r.id === el.dataset.id);
        el.querySelectorAll('button').forEach((b) => b.onclick = async () => {
          const act = b.dataset.a;
          if (act === 'show') { shown.has(a.id) ? shown.delete(a.id) : shown.add(a.id); list(); }
          else if (act === 'copy') { await copy(a.password); b.textContent = 'تم النسخ'; setTimeout(() => b.textContent = 'نسخ', 1500); }
          else if (act === 'edit') form(a.id);
          else if (act === 'open') window.open(/^https?:\/\//i.test(a.url) ? a.url : 'https://' + a.url, '_blank', 'noopener');
        });
      });
    };
    const shell = () => {
      m.innerHTML = `<h2>كلمات المرور</h2><div class="row"><button class="btn ghost" id="add">إضافة حساب</button>
        <input id="q" type="text" placeholder="بحث بالتطبيق أو المستخدم" style="max-width:230px">
        <select id="c"><option value="">كل التصنيفات</option>${L.CATS.map((c) => `<option>${c}</option>`).join('')}</select>
        <button class="btn ghost" id="lk">قفل الخزنة</button></div><div class="rows" id="rows"></div>
        <p class="note">يُمسح ما نسخته من الحافظة بعد 30 ثانية. يُطلب التحقق مجدداً بعد دقيقتين من آخر تحقق.</p>`;
      m.querySelector('#add').onclick = () => form();
      m.querySelector('#q').oninput = (e) => { q = e.target.value; list(); };
      m.querySelector('#c').onchange = (e) => { cat = e.target.value; list(); };
      m.querySelector('#lk').onclick = () => { auth.lock(); location.reload(); };
      list();
    };
    async function form(id) {
      const a = id ? await db.get('accounts', id) : { category: L.CATS[0] };
      m.innerHTML = `<h2>${id ? 'تعديل حساب' : 'حساب جديد'}</h2><form class="panel wide" id="f" autocomplete="off">
        <label>اسم التطبيق أو الموقع</label><input name="site" type="text" value="${esc(a.site || '')}" required>
        <label>اسم المستخدم</label><input name="username" type="text" dir="ltr" value="${esc(a.username || '')}">
        <label>البريد الإلكتروني</label><input name="email" type="text" dir="ltr" value="${esc(a.email || '')}">
        <label>كلمة المرور</label><div class="row"><input name="password" id="pw" type="password" dir="ltr" value="${esc(a.password || '')}" style="flex:1">
        <button type="button" class="btn ghost" id="sh">إظهار</button></div>
        <label>رابط تسجيل الدخول</label><input name="url" type="text" dir="ltr" value="${esc(a.url || '')}">
        <label>التصنيف</label><select name="category">${L.CATS.map((c) => `<option ${c === a.category ? 'selected' : ''}>${c}</option>`).join('')}</select>
        <label>ملاحظات</label><textarea name="notes" rows="3">${esc(a.notes || '')}</textarea>
        <p class="err" id="e" role="alert"></p>
        <div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button>${id ? '<button type="button" class="btn ghost danger" id="dl">حذف</button>' : ''}</div></form>`;
      const f = m.querySelector('#f');
      m.querySelector('#sh').onclick = (e) => { const p = m.querySelector('#pw'); p.type = p.type === 'password' ? 'text' : 'password'; e.target.textContent = p.type === 'password' ? 'إظهار' : 'إخفاء'; };
      m.querySelector('#cn').onclick = shell;
      f.onsubmit = async (ev) => { ev.preventDefault();
        const o = { ...a }; ['site', 'username', 'email', 'password', 'url', 'category', 'notes'].forEach((k) => o[k] = f[k].value);
        o.site = o.site.trim(); const bad = L.validate(o); if (bad) { m.querySelector('#e').textContent = bad; return; }
        await db.put('accounts', o); shell(); };
      const dl = m.querySelector('#dl');
      if (dl) dl.onclick = async () => { if (confirm(`حذف حساب «${a.site}» نهائياً؟`)) { await db.remove('accounts', id); shell(); } };
    }
    const pid = V.takePending('pass'); pid ? form(pid) : shell();
  };
})();
