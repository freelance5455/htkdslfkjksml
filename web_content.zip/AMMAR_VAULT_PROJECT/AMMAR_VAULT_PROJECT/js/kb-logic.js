/* AMMAR VAULT - منطق مكتبة الملخصات والروابط. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const CATS = ['البرمجة', 'المحاسبة', 'قواعد البيانات', 'تطوير الويب', 'اللغة الإنجليزية', 'مواد الجامعة', 'معلومات عامة', 'شروحات تقنية'];
  const LINK_CATS = ['دراسة', 'برمجة', 'مراجع', 'أدوات', 'عمل', 'أخرى'];
  function normalizeUrl(u) {
    u = String(u || '').trim(); if (!u || /\s/.test(u)) return null;
    if (/^[a-z][a-z0-9+.-]*:/i.test(u) && !/^https?:\/\//i.test(u)) return null; // يمنع javascript: و data: وغيرها
    try { const x = new URL(/^https?:\/\//i.test(u) ? u : 'https://' + u); return /\./.test(x.hostname) || x.hostname === 'localhost' ? x.href : null; } catch (e) { return null; }
  }
  const parseKeywords = (s) => [...new Set(String(s || '').split(/[,،\n]/).map((x) => x.trim()).filter(Boolean))];
  function parseLinks(text) {
    const urls = [], bad = [];
    for (const l of String(text || '').split('\n').map((x) => x.trim()).filter(Boolean)) { const u = normalizeUrl(l); u ? urls.push(u) : bad.push(l); }
    return { urls, bad };
  }
  const validateNote = (n) => !n.title || !n.title.trim() ? 'عنوان الملخص مطلوب' : !n.content || !n.content.trim() ? 'محتوى الملخص مطلوب' : null;
  const validateLink = (l) => !l.name || !l.name.trim() ? 'اسم الموقع مطلوب' : !normalizeUrl(l.url) ? 'الرابط غير صالح (يُقبل http/https فقط)' : null;
  function filterNotes(notes, q, cat) {
    const tk = V.SearchLogic.tokens(q);
    return notes.filter((n) => (!cat || n.category === cat) && (() => { const h = V.SearchLogic.norm([n.title, n.lessonName, n.category, n.content, (n.keywords || []).join(' '), n.notes].join(' ')).n; return tk.every((t) => h.includes(t)); })())
      .sort((a, b) => (b.addedAt || '').localeCompare(a.addedAt || ''));
  }
  const filterLinks = (links, q, cat) => { const tk = V.SearchLogic.tokens(q);
    return links.filter((l) => (!cat || l.category === cat) && (() => { const h = V.SearchLogic.norm([l.name, l.url, l.description, l.notes, l.category].join(' ')).n; return tk.every((t) => h.includes(t)); })())
      .sort((a, b) => a.name.localeCompare(b.name, 'ar')); };
  V.KbLogic = { CATS, LINK_CATS, normalizeUrl, parseKeywords, parseLinks, validateNote, validateLink, filterNotes, filterLinks };
})();
