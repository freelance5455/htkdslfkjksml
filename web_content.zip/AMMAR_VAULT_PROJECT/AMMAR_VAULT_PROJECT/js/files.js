/* AMMAR VAULT - مدير الملفات (المرحلة 7): مجلدات، رفع، إعادة تسمية، نقل، وصف، معاينة، مشاركة، حذف بعد تأكيد، بحث. */
(function () {
  const V = window.Vault, L = V.FilesLogic, UI = V.UI;
  V.Sections = V.Sections || {};
  V.Sections.files = async function (m, { db, esc }) {
    let cur = null, q = '';
    const load = async () => { const [folders, files] = await Promise.all([db.all('folders'), db.all('files')]); return { folders, files }; };
    async function paint(msg) {
      const { folders, files } = await load();
      const crumbs = L.breadcrumbs(folders, cur);
      const subs = q ? [] : L.childFolders(folders, cur);
      const fl = q ? L.searchFiles(files, q) : L.searchFiles(files.filter((f) => (f.folderId || null) === cur), '');
      m.innerHTML = `<h2>الملفات</h2><div class="row"><button class="btn ghost" id="nf">مجلد جديد</button><label class="btn ghost" style="margin:0;cursor:pointer;color:var(--text)">رفع ملفات<input id="up" type="file" multiple hidden></label>
        <input id="q" type="text" placeholder="بحث في الملفات" style="max-width:220px" value="${esc(q)}"></div>
        <p class="note"><button class="link" data-go="">الرئيسي</button>${crumbs.map((c) => ` / <button class="link" data-go="${c.id}">${esc(c.name)}</button>`).join('')}</p>
        <p class="err" role="alert">${msg ? esc(msg) : ''}</p><div class="rows" id="rows">
        ${subs.map((f) => `<div class="item"><b>📁 ${esc(f.name)}</b><span></span><div class="row" style="grid-column:1/3"><button class="btn ghost sm" data-a="open" data-id="${f.id}">فتح</button><button class="btn ghost sm" data-a="renf" data-id="${f.id}">إعادة تسمية</button><button class="btn ghost sm danger" data-a="delf" data-id="${f.id}">حذف</button></div></div>`).join('')}
        ${fl.map((f) => `<div class="item"><b dir="auto">${esc(f.name)}</b><span>${L.fmtSize(f.size)}${f.description ? ' · ' + esc(f.description) : ''}${q ? ' · ' + esc(L.path(folders, f.folderId) || 'الرئيسي') : ''}</span>
          <div class="row" style="grid-column:1/3"><button class="btn ghost sm" data-a="prev" data-id="${f.id}">معاينة</button><button class="btn ghost sm" data-a="share" data-id="${f.id}">مشاركة</button><button class="btn ghost sm" data-a="ren" data-id="${f.id}">إعادة تسمية</button><button class="btn ghost sm" data-a="mv" data-id="${f.id}">نقل</button><button class="btn ghost sm" data-a="desc" data-id="${f.id}">وصف</button><button class="btn ghost sm danger" data-a="del" data-id="${f.id}">حذف</button></div></div>`).join('')}
        ${!subs.length && !fl.length ? `<p class="note">${q ? 'لا نتائج.' : 'هذا المجلد فارغ.'}</p>` : ''}</div>`;
      m.querySelectorAll('[data-go]').forEach((b) => b.onclick = () => { cur = b.dataset.go || null; q = ''; paint(); });
      m.querySelector('#q').oninput = (e) => { q = e.target.value; clearTimeout(paint.t); paint.t = setTimeout(async () => { await paint(); const i = m.querySelector('#q'); i.focus(); i.setSelectionRange(q.length, q.length); }, 250); };
      m.querySelector('#nf').onclick = () => UI.dialog('مجلد جديد', '<input name="n" type="text" required autofocus>', { ok: 'إنشاء', onOk: async (f) => {
        const bad = L.validateName(f.n.value, L.childFolders(folders, cur).map((x) => x.name)); if (bad) throw new Error(bad);
        await db.put('folders', { name: f.n.value.trim(), parentId: cur }); paint(); } });
      m.querySelector('#up').onchange = async (e) => {
        const errs = []; let names = files.filter((x) => (x.folderId || null) === cur).map((x) => x.name);
        for (const file of e.target.files) {
          if (file.size > L.MAX_BYTES) { errs.push(`«${file.name}» أكبر من ${L.fmtSize(L.MAX_BYTES)}`); continue; }
          const name = L.uniqueName(file.name, names); names.push(name);
          const blobId = await db.putBlob({ name, type: file.type, bytes: await UI.readBytes(file) });
          await db.put('files', { name, folderId: cur, blobId, type: file.type, size: file.size, description: '' });
        }
        paint(errs.join('، ')); };
      m.querySelector('#rows').onclick = (ev) => { const b = ev.target.closest('button[data-a]'); if (b) act(b.dataset.a, b.dataset.id, { folders, files }); };
    }
    async function act(a, id, { folders, files }) {
      const f = files.find((x) => x.id === id), fo = folders.find((x) => x.id === id);
      if (a === 'open') { cur = id; return paint(); }
      if (a === 'renf') return UI.dialog('إعادة تسمية المجلد', `<input name="n" type="text" value="${esc(fo.name)}" required>`, { onOk: async (d) => {
        const bad = L.validateName(d.n.value, L.childFolders(folders, fo.parentId || null).filter((x) => x.id !== id).map((x) => x.name)); if (bad) throw new Error(bad);
        await db.put('folders', { ...fo, name: d.n.value.trim() }); paint(); } });
      if (a === 'delf') { if (!L.folderEmpty(folders, files, id)) return paint('لا يمكن حذف مجلد غير فارغ. انقل ملفاته أو احذفها أولاً.');
        if (confirm(`حذف المجلد «${fo.name}»؟`)) { await db.remove('folders', id); paint(); } return; }
      if (a === 'del') { if (confirm(`حذف الملف «${f.name}» نهائياً؟`)) { await db.removeBlob(f.blobId); await db.remove('files', id); paint(); } return; }
      if (a === 'ren') return UI.dialog('إعادة تسمية الملف', `<input name="n" type="text" value="${esc(f.name)}" required>`, { onOk: async (d) => {
        const bad = L.validateName(d.n.value, files.filter((x) => (x.folderId || null) === (f.folderId || null) && x.id !== id).map((x) => x.name)); if (bad) throw new Error(bad);
        await db.put('files', { ...f, name: d.n.value.trim() }); paint(); } });
      if (a === 'desc') return UI.dialog('وصف الملف', `<textarea name="d" rows="3">${esc(f.description || '')}</textarea>`, { onOk: async (d) => { await db.put('files', { ...f, description: d.d.value }); paint(); } });
      if (a === 'mv') { const opts = [{ id: '', p: 'الرئيسي' }, ...folders.map((x) => ({ id: x.id, p: L.path(folders, x.id) }))];
        return UI.dialog('نقل الملف إلى', `<select name="t">${opts.map((o) => `<option value="${o.id}" ${o.id === (f.folderId || '') ? 'selected' : ''}>${esc(o.p)}</option>`).join('')}</select>`, { ok: 'نقل', onOk: async (d) => {
          const to = d.t.value || null; if (to === (f.folderId || null)) return;
          const bad = L.validateName(f.name, files.filter((x) => (x.folderId || null) === to).map((x) => x.name)); if (bad) throw new Error('يوجد ملف بنفس الاسم في الوجهة');
          await db.put('files', { ...f, folderId: to }); paint(); } }); }
      const blob = await db.getBlob(f.blobId); if (!blob) return paint('تعذّر قراءة الملف.');
      if (a === 'share') { const r = await UI.shareOrDownload(f.name, f.type, blob.bytes); return paint(r === 'downloaded' ? 'تم تنزيل الملف على الجهاز.' : ''); }
      if (a === 'prev') { const k = L.kindOf(f.type, f.name), url = URL.createObjectURL(new Blob([blob.bytes], { type: f.type }));
        if (k === 'pdf') return UI.openBytes(f.name, f.type, blob.bytes);
        const body = k === 'image' ? `<img src="${url}" alt="" style="max-width:100%">` : k === 'text' ? `<pre style="white-space:pre-wrap;max-height:60vh;overflow:auto" dir="auto"></pre>` : '<p>لا تتوفر معاينة لهذا النوع (Word/Excel/مضغوط…). استخدم «مشاركة» لفتحه في تطبيق مناسب.</p>';
        const d = UI.dialog(f.name, body); if (k === 'text') d.body.querySelector('pre').textContent = new TextDecoder().decode(blob.bytes); }
    }
    const pid = V.takePending('files'); if (pid) { const f = await db.get('files', pid); if (f) { cur = f.folderId || null; q = f.name; } }
    paint();
  };
})();
