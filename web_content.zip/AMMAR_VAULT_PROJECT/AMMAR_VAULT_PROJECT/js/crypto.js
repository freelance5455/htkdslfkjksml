/* AMMAR VAULT - طبقة التشفير: PBKDF2 + AES-256-GCM. مفتاح البيانات (DEK) عشوائي ومغلَّف بمفتاح مشتق من كلمة المرور. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const c = root.crypto && root.crypto.subtle ? root.crypto : require('crypto').webcrypto;
  const enc = new TextEncoder(), dec = new TextDecoder();
  const ITER = 310000;
  const b64 = (u) => { u = new Uint8Array(u); let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (x) => x.charCodeAt(0));
  const rnd = (n) => c.getRandomValues(new Uint8Array(n));

  async function deriveKEK(pw, salt, iter) {
    const m = await c.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveKey']);
    return c.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, m,
      { name: 'AES-GCM', length: 256 }, false, ['wrapKey', 'unwrapKey']);
  }
  const newDEK = () => c.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
  async function wrapDEK(dek, kek) {
    const iv = rnd(12);
    const w = await c.subtle.wrapKey('raw', dek, kek, { name: 'AES-GCM', iv });
    return b64(iv) + '.' + b64(w);
  }
  function unwrapDEK(str, kek) {
    const [iv, w] = str.split('.');
    return c.subtle.unwrapKey('raw', unb64(w), kek, { name: 'AES-GCM', iv: unb64(iv) },
      { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
  }
  async function encrypt(key, obj) {
    const iv = rnd(12);
    const ct = await c.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj)));
    return b64(iv) + '.' + b64(ct);
  }
  async function decrypt(key, str) {
    const [iv, ct] = str.split('.');
    const pt = await c.subtle.decrypt({ name: 'AES-GCM', iv: unb64(iv) }, key, unb64(ct));
    return JSON.parse(dec.decode(pt));
  }
  async function deriveAES(pw, salt, iter) {
    const m = await c.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveKey']);
    return c.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, m, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  const encBytes = async (key, bytes, iv, aad) => new Uint8Array(await c.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad }, key, bytes));
  const decBytes = async (key, bytes, iv, aad) => new Uint8Array(await c.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: aad }, key, bytes));
  const sha256 = async (bytes) => b64(await c.subtle.digest('SHA-256', bytes));
  const importDEK = (raw) => c.subtle.importKey('raw', raw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']);
  const exportDEK = async (k) => new Uint8Array(await c.subtle.exportKey('raw', k));
  V.Crypto = { importDEK, exportDEK, deriveAES, encBytes, decBytes, sha256, ITER, b64, unb64, rnd, deriveKEK, newDEK, wrapDEK, unwrapDEK, encrypt, decrypt };
})();
