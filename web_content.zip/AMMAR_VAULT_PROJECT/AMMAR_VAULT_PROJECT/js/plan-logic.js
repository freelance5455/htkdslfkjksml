/* AMMAR VAULT - منطق الجدول الزمني: التكرار، الإنجاز لكل تاريخ، المتأخرات، خطة الإشعارات، شبكة الشهر (الأسبوع يبدأ السبت). */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const pad = (n) => String(n).padStart(2, '0');
  const fmtD = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const parseD = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const addDays = (s, n) => { const d = parseD(s); d.setDate(d.getDate() + n); return fmtD(d); };
  const dow = (s) => parseD(s).getDay();
  const today = (now) => fmtD(new Date(now || Date.now()));
  const atMs = (ds, time) => { const [h, mi] = (time || '00:00').split(':').map(Number); const d = parseD(ds); d.setHours(h, mi, 0, 0); return d.getTime(); };
  const rec = (t) => t.repeat === 'daily' || t.repeat === 'weekly';
  function occursOn(t, ds) {
    if (!t.date || ds < t.date) return false;
    if (rec(t)) { if (t.repeatUntil && ds > t.repeatUntil) return false; return t.repeat === 'daily' || dow(ds) === dow(t.date); }
    return ds === t.date;
  }
  const isDone = (t, ds) => (rec(t) ? (t.doneDates || []).includes(ds) : !!t.done);
  const endOf = (t) => t.endTime || t.startTime || '23:59';
  const mk = (t, ds) => ({ task: t, date: ds, start: atMs(ds, t.startTime), end: atMs(ds, endOf(t)), done: isDone(t, ds) });
  function occurrences(tasks, from, to) {
    const out = []; for (let d = from; d <= to; d = addDays(d, 1)) for (const t of tasks) if (occursOn(t, d)) out.push(mk(t, d));
    return out.sort((a, b) => a.start - b.start);
  }
  function overdue(tasks, now) {
    const td = today(now), out = [];
    for (const t of tasks) {
      const days = rec(t) ? Array.from({ length: 15 }, (_, i) => addDays(td, -i)) : [t.date];
      for (const d of days) if (d && d <= td && occursOn(t, d)) { const o = mk(t, d); if (!o.done && o.end < now) out.push(o); }
    }
    return out.sort((a, b) => a.start - b.start);
  }
  function notifPlan(tasks, now, horizon, limit) {
    const td = today(now), out = [];
    for (const o of occurrences(tasks, td, addDays(td, horizon || 30))) {
      const t = o.task; if (o.done || t.alertMin == null || t.alertMin === '') continue;
      const at = atMs(o.date, t.startTime || '09:00') - Number(t.alertMin) * 60000;
      if (at > now) out.push({ key: `${t.id}|${o.date}`, at, title: t.title, body: t.startTime ? `الساعة ${t.startTime}` : 'مهمة اليوم' });
    }
    return out.sort((a, b) => a.at - b.at).slice(0, limit || 60);
  }
  function toggleDone(t, ds) {
    if (!rec(t)) return { ...t, done: !t.done };
    const s = new Set(t.doneDates || []); s.has(ds) ? s.delete(ds) : s.add(ds); return { ...t, doneDates: [...s] };
  }
  function validate(t) {
    if (!t.title || !t.title.trim()) return 'عنوان المهمة مطلوب';
    if (!t.date) return 'تاريخ المهمة مطلوب';
    const tm = /^([01]\d|2[0-3]):[0-5]\d$/;
    if (t.startTime && !tm.test(t.startTime)) return 'وقت البداية غير صحيح'; if (t.endTime && !tm.test(t.endTime)) return 'وقت النهاية غير صحيح';
    if (t.endTime && !t.startTime) return 'حدّد وقت البداية أولاً';
    if (t.startTime && t.endTime && t.endTime <= t.startTime) return 'وقت النهاية يجب أن يكون بعد البداية';
    if (t.repeatUntil && t.repeatUntil < t.date) return 'تاريخ نهاية التكرار قبل تاريخ المهمة';
    if (t.alertMin != null && t.alertMin !== '' && !(Number(t.alertMin) >= 0)) return 'مدة التنبيه غير صحيحة';
    return null;
  }
  const weekStart = (ds) => addDays(ds, -((dow(ds) + 1) % 7));
  function monthGrid(y, m0) {
    const first = fmtD(new Date(y, m0, 1)), last = fmtD(new Date(y, m0 + 1, 0)), weeks = []; let s = weekStart(first);
    while (s <= last) { weeks.push(Array.from({ length: 7 }, (_, i) => addDays(s, i))); s = addDays(s, 7); }
    return weeks;
  }
  const DAY_NAMES = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const MONTH_NAMES = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  V.PlanLogic = { fmtD, parseD, addDays, dow, today, occursOn, isDone, occurrences, overdue, notifPlan, toggleDone, validate, weekStart, monthGrid, DAY_NAMES, MONTH_NAMES };
})();
