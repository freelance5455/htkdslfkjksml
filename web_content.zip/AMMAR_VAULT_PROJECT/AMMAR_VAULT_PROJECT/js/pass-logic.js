/* AMMAR VAULT - منطق مدير كلمات المرور (قابل للاختبار). */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const CATS = ['تواصل اجتماعي', 'بريد إلكتروني', 'بنوك ومحافظ', 'عمل', 'دراسة', 'ألعاب وترفيه', 'أخرى'];
  const norm = (s) => String(s || '').toLowerCase();
  // البحث باسم التطبيق/الموقع أو اسم المستخدم أو البريد (لا يبحث في كلمة المرور إطلاقاً)
  function search(list, q, cat) {
    q = norm(q).trim();
    return list.filter((a) => (!cat || a.category === cat) &&
      (!q || [a.site, a.username, a.email].some((x) => norm(x).includes(q))))
      .sort((a, b) => norm(a.site).localeCompare(norm(b.site), 'ar'));
  }
  function validate(a) {
    if (!a.site || !a.site.trim()) return 'اسم التطبيق أو الموقع مطلوب';
    if (!a.password) return 'كلمة المرور مطلوبة';
    if (a.email && !/^\S+@\S+\.\S+$/.test(a.email.trim())) return 'صيغة البريد الإلكتروني غير صحيحة';
    return null;
  }
  V.PassLogic = { CATS, search, validate };
})();
