/* AMMAR VAULT - منطق الإحصائيات (المرحلة 11): كل رقم محسوب من البيانات الفعلية. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  function compute(d, now) {
    now = now || Date.now(); const P = V.PlanLogic, D = V.DocsLogic, Dl = V.DebtsLogic, g = (k) => d[k] || [];
    const T = Dl.totals(g('debt_people'), g('debt_tx')), tasks = g('tasks'), td = P.today(now), end = P.addDays(td, 7);
    const rec = (t) => t.repeat === 'daily' || t.repeat === 'weekly';
    const upcoming = P.occurrences(tasks, td, end).filter((o) => !o.done && o.end >= now);
    const completed = tasks.reduce((s, t) => s + (rec(t) ? (t.doneDates || []).length : t.done ? 1 : 0), 0);
    const remaining = tasks.filter((t) => !rec(t) && !t.done).length + upcoming.filter((o) => rec(o.task)).length;
    const docAlerts = D.alerts(g('documents'), now);
    return { documents: g('documents').length, accounts: g('accounts').length, photos: g('photos').length, files: g('files').length, notes: g('notes').length, links: g('links').length,
      mediaBytes: [...g('files'), ...g('photos')].reduce((s, x) => s + (x.size || 0), 0),
      debts: { outstanding: T.outstanding, paid: T.paid, debtors: T.debtors, settled: T.settled, open: T.open },
      tasks: { completed, remaining, overdue: P.overdue(tasks, now).length }, upcoming: upcoming.slice(0, 6), docAlerts };
  }
  V.StatsLogic = { compute };
})();
