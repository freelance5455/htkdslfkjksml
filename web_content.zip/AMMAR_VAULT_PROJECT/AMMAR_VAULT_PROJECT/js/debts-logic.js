/* AMMAR VAULT - منطق دفتر الديون. الحساب بالفلس/السنت (أعداد صحيحة) لتفادي أخطاء الكسور. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const cents = (x) => Math.round(Number(x) * 100);
  const fmt = (c) => (c / 100).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  // person: سجل الشخص، txs: عمليات هذا الشخص فقط {kind:'debt'|'payment', amount, date}
  function summarize(txs) {
    let o = 0, p = 0;
    for (const t of txs) (t.kind === 'debt' ? (o += cents(t.amount)) : (p += cents(t.amount)));
    const r = o - p;
    return { original: o, paid: p, remaining: r, status: o === 0 ? 'empty' : r <= 0 ? 'settled' : 'open' };
  }
  function totals(people, allTxs) {
    const t = { outstanding: 0, paid: 0, debtors: 0, settled: 0, open: 0 };
    for (const pr of people) {
      const s = summarize(allTxs.filter((x) => x.personId === pr.id));
      t.paid += s.paid;
      if (s.status === 'open') { t.outstanding += s.remaining; t.debtors++; t.open++; }
      else if (s.status === 'settled') t.settled++;
    }
    return t;
  }
  function validateTx(tx, remainingCents) {
    const a = cents(tx.amount);
    if (!(a > 0)) return 'المبلغ يجب أن يكون أكبر من صفر';
    if (!tx.date) return 'التاريخ مطلوب';
    if (tx.kind === 'payment' && a > remainingCents) return `مبلغ السداد (${fmt(a)}) أكبر من المتبقي (${fmt(Math.max(remainingCents, 0))})`;
    return null;
  }
  const SETTLED_MSG = 'ليس لديك أي دين مستحق على هذا الشخص، الحساب مسدد بالكامل.';
  const history = (txs) => [...txs].sort((a, b) => (b.date + b.createdAt).toString().localeCompare((a.date + a.createdAt).toString()));
  V.DebtsLogic = { cents, fmt, summarize, totals, validateTx, SETTLED_MSG, history };
})();
