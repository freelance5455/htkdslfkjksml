/* AMMAR VAULT - منطق البحث الشامل: توحيد النص العربي، مصادر البحث، الترتيب، المقتطفات. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const DIAC = /[\u064B-\u065F\u0670\u0640]/;
  const MAP = { 'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ة': 'ه' };
  // توحيد (الهمزات، الياء، التاء المربوطة، التشكيل، الأرقام الهندية، حالة الأحرف) مع خريطة لمواضع النص الأصلي
  function norm(s) {
    s = String(s == null ? '' : s); let n = ''; const map = [];
    for (let i = 0; i < s.length; i++) {
      let c = s[i]; if (DIAC.test(c)) continue; c = MAP[c] || c;
      const k = c.charCodeAt(0);
      if (k >= 0x660 && k <= 0x669) c = String(k - 0x660); else if (k >= 0x6f0 && k <= 0x6f9) c = String(k - 0x6f0);
      else { const l = c.toLowerCase(); if (l.length === 1) c = l; }
      n += c; map.push(i);
    }
    return { n, map };
  }
  const tokens = (q) => norm(q).n.split(/\s+/).filter(Boolean);
  const j = (...a) => a.flat().filter((x) => x != null).join(' ');
  // مصادر البحث. لا تُفهرس كلمات المرور إطلاقاً.
  const SOURCES = [
    { table: 'documents', type: 'وثيقة', section: 'docs', title: (r) => r.title, text: (r) => j(r.type, r.number, r.issuer, r.notes) },
    { table: 'accounts', type: 'حساب', section: 'pass', title: (r) => r.site, text: (r) => j(r.username, r.email, r.category, r.notes) },
    { table: 'debt_people', type: 'شخص (ديون)', section: 'debts', title: (r) => r.name, text: (r) => j(r.phone, r.notes) },
    { table: 'files', type: 'ملف', section: 'files', title: (r) => r.name, text: (r) => j(r.description) },
    { table: 'photos', type: 'صورة', section: 'photos', title: (r) => r.name, text: (r) => j(r.description, r.category) },
    { table: 'tasks', type: 'مهمة', section: 'plan', title: (r) => r.title, text: (r) => j(r.description, r.notes) },
    { table: 'notes', type: 'ملخص', section: 'kb', title: (r) => r.title, text: (r) => j(r.category, r.lessonName, r.content, (r.keywords || []).join(' '), (r.links || []).join(' '), r.notes) },
    { table: 'links', type: 'رابط', section: 'links', title: (r) => r.name, text: (r) => j(r.url, r.category, r.description, r.notes) },
  ];
  const entry = (type, section, id, title, text, where) => ({ type, section, id, title: title || '', text: text || '', where: where || '', nt: norm(title), nx: norm(text) });
  function buildEntries(data, pdfIndex) {
    const out = [];
    for (const s of SOURCES) for (const r of data[s.table] || []) out.push(entry(s.type, s.section, r.id, s.title(r), s.text(r)));
    for (const p of pdfIndex || []) if (p.text) out.push(entry('محتوى PDF', p.section, p.srcId, p.name, p.text, 'داخل ملف PDF'));
    return out;
  }
  function search(entries, q, limit) {
    const tk = tokens(q); if (!tk.length) return [];
    const res = [];
    for (const e of entries) {
      const hay = e.nt.n + ' ' + e.nx.n; if (!tk.every((t) => hay.includes(t))) continue;
      let score = tk.reduce((s, t) => s + (e.nt.n.includes(t) ? 10 : 0) + (e.nx.n.includes(t) ? 1 : 0), 0);
      if (e.nt.n === tk.join(' ')) score += 5;
      let snippet = '';
      const k = e.nx.n.indexOf(tk.find((t) => e.nx.n.includes(t)) || '\u0000');
      if (k >= 0) { const o = e.nx.map[k]; const a = Math.max(0, o - 40); snippet = (a > 0 ? '…' : '') + e.text.slice(a, o + 70).replace(/\s+/g, ' ') + '…'; }
      res.push({ entry: e, score, snippet });
    }
    return res.sort((a, b) => b.score - a.score || a.entry.title.localeCompare(b.entry.title, 'ar')).slice(0, limit || 50);
  }
  V.SearchLogic = { norm, tokens, SOURCES, buildEntries, search };
})();
