/* AMMAR VAULT - جدولي (المرحلة 9): يومي/أسبوعي/شهري، تكرار، أولوية، إنجاز، متأخرات، إشعارات. */
(function () {
  const V = window.Vault, P = V.PlanLogic;
  V.Sections = V.Sections || {};
  const PRI = { high: 'عالية', med: 'متوسطة', low: 'منخفضة' };
  const ALERTS = [['', 'بدون تنبيه'], ['0', 'عند الموعد'], ['5', 'قبل 5 دقائق'], ['15', 'قبل 15 دقيقة'], ['30', 'قبل 30 دقيقة'], ['60', 'قبل ساعة'], ['1440', 'قبل يوم']];
  const label = (ds) => { const d = P.parseD(ds); return `${P.DAY_NAMES[d.getDay()]} ${d.getDate()} ${P.MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`; };
  V.Sections.plan = async function (m, { db, esc }) {
    let view = 'day', date = P.today();
    const sync = async () => V.Notify.sync(await db.all('tasks'));
    const hm = (t) => (t.startTime ? t.startTime + (t.endTime ? '–' + t.endTime : '') : 'طوال اليوم');
    const rowH = (o) => `<div class="item pri-${o.task.priority || 'med'} ${o.done ? 'done' : ''}"><label style="margin:0;grid-column:1/3;color:inherit"><input type="checkbox" data-t="${o.task.id}" data-d="${o.date}" ${o.done ? 'checked' : ''}> <b>${esc(o.task.title)}</b></label>
      <span>${hm(o.task)} · ${PRI[o.task.priority || 'med']}${o.task.repeat && o.task.repeat !== 'none' ? ' · متكررة' : ''}</span><button class="btn ghost sm" data-e="${o.task.id}">تعديل</button></div>`;
    async function paint() {
      const tasks = await db.all('tasks'), od = P.overdue(tasks, Date.now());
      const nav = view === 'month' ? (() => { const d = P.parseD(date); return `${P.MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`; })() : view === 'week' ? `أسبوع ${label(P.weekStart(date))}` : label(date);
      let body = '';
      if (view === 'day') { const os = P.occurrences(tasks, date, date); body = os.length ? os.map(rowH).join('') : '<p class="note">لا مهام في هذا اليوم.</p>'; }
      else if (view === 'week') { const ws = P.weekStart(date); body = Array.from({ length: 7 }, (_, i) => P.addDays(ws, i)).map((d) => { const os = P.occurrences(tasks, d, d);
        return `<h3 style="font-size:1rem">${label(d)}${d === P.today() ? ' (اليوم)' : ''}</h3>${os.length ? os.map(rowH).join('') : '<p class="note" style="margin:0">—</p>'}`; }).join(''); }
      else { const d = P.parseD(date), g = P.monthGrid(d.getFullYear(), d.getMonth());
        body = `<div class="cal">${[6, 0, 1, 2, 3, 4, 5].map((i) => `<div class="calh">${P.DAY_NAMES[i]}</div>`).join('')}${g.flat().map((ds) => { const n = P.occurrences(tasks, ds, ds).length, inM = P.parseD(ds).getMonth() === d.getMonth();
          return `<button class="cd ${inM ? '' : 'off'} ${ds === P.today() ? 'today' : ''}" data-day="${ds}">${P.parseD(ds).getDate()}${n ? `<i>${n}</i>` : ''}</button>`; }).join('')}</div>`; }
      m.innerHTML = `<h2>جدولي</h2><div class="row"><button class="btn ghost" id="nt">مهمة جديدة</button>
        ${['day:يومي', 'week:أسبوعي', 'month:شهري'].map((x) => { const [k, l] = x.split(':'); return `<button class="btn ghost ${view === k ? 'on' : ''}" data-v="${k}">${l}</button>`; }).join('')}</div>
        <div class="row"><button class="btn ghost sm" id="pv">‹ السابق</button><b>${nav}</b><button class="btn ghost sm" id="nx">التالي ›</button><button class="btn ghost sm" id="td">اليوم</button></div>
        ${od.length ? `<div class="panel wide"><b style="color:var(--danger)">متأخرة (${od.length})</b>${od.map((o) => `<div class="row" style="margin:.3rem 0"><span style="flex:1">${esc(o.task.title)} — ${label(o.date)} ${hm(o.task)}</span><button class="btn ghost sm" data-t="${o.task.id}" data-d="${o.date}" data-done="1">تم</button><button class="btn ghost sm" data-e="${o.task.id}">تعديل</button></div>`).join('')}</div>` : ''}
        <div class="rows" style="max-width:640px">${body}</div>
        <p class="note">${V.Notify.isNative() ? 'الإشعارات المحلية مفعّلة (تعمل والتطبيق مغلق).' : 'في المتصفح تصل الإشعارات أثناء فتح الصفحة فقط؛ الإشعارات والتطبيق مغلق تعمل في نسخة Android.'} <button class="link" id="pm">تفعيل الإشعارات</button></p>`;
      m.querySelector('#nt').onclick = () => form(); m.querySelector('#pm').onclick = async () => { const ok = await V.Notify.requestPermission(); await sync(); alert(ok ? 'تم تفعيل الإشعارات.' : 'لم يُمنح إذن الإشعارات.'); };
      m.querySelectorAll('[data-v]').forEach((b) => b.onclick = () => { view = b.dataset.v; paint(); });
      const step = (s) => { date = view === 'month' ? (() => { const d = P.parseD(date); d.setMonth(d.getMonth() + s, 1); return P.fmtD(d); })() : P.addDays(date, s * (view === 'week' ? 7 : 1)); paint(); };
      m.querySelector('#pv').onclick = () => step(-1); m.querySelector('#nx').onclick = () => step(1); m.querySelector('#td').onclick = () => { date = P.today(); paint(); };
      m.querySelectorAll('[data-day]').forEach((b) => b.onclick = () => { date = b.dataset.day; view = 'day'; paint(); });
      m.querySelectorAll('[data-e]').forEach((b) => b.onclick = () => form(b.dataset.e));
      m.querySelectorAll('input[data-t],button[data-done]').forEach((el) => el.onclick = async (ev) => { const t = await db.get('tasks', el.dataset.t); if (!t) return;
        const wasDone = P.isDone(t, el.dataset.d); if (el.tagName === 'BUTTON' && wasDone) return;
        await db.put('tasks', P.toggleDone(t, el.dataset.d)); await sync(); paint(); });
    }
    async function form(id) {
      const t = id ? await db.get('tasks', id) : { date, priority: 'med', repeat: 'none', alertMin: '15' };
      m.innerHTML = `<h2>${id ? 'تعديل مهمة' : 'مهمة جديدة'}</h2><form class="panel wide" id="f" autocomplete="off">
        <label>العنوان</label><input name="title" type="text" value="${esc(t.title || '')}" required>
        <label>التاريخ</label><input name="date" type="date" value="${t.date || ''}" required>
        <div class="row"><div style="flex:1"><label>وقت البداية</label><input name="startTime" type="time" value="${t.startTime || ''}"></div><div style="flex:1"><label>وقت النهاية</label><input name="endTime" type="time" value="${t.endTime || ''}"></div></div>
        <label>التكرار</label><select name="repeat"><option value="none">لا يتكرر</option><option value="daily" ${t.repeat === 'daily' ? 'selected' : ''}>يومياً</option><option value="weekly" ${t.repeat === 'weekly' ? 'selected' : ''}>أسبوعياً (نفس اليوم)</option></select>
        <label>ينتهي التكرار في (اختياري)</label><input name="repeatUntil" type="date" value="${t.repeatUntil || ''}">
        <label>الأولوية</label><select name="priority">${Object.entries(PRI).map(([k, v]) => `<option value="${k}" ${t.priority === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
        <label>التنبيه</label><select name="alertMin">${ALERTS.map(([k, v]) => `<option value="${k}" ${String(t.alertMin ?? '') === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
        <label>الوصف</label><textarea name="description" rows="2">${esc(t.description || '')}</textarea><label>ملاحظات</label><textarea name="notes" rows="2">${esc(t.notes || '')}</textarea>
        <p class="err" id="e" role="alert"></p><div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button>${id ? '<button type="button" class="btn ghost danger" id="dl">حذف</button>' : ''}</div></form>`;
      const f = m.querySelector('#f'); m.querySelector('#cn').onclick = paint;
      f.onsubmit = async (ev) => { ev.preventDefault(); const o = { ...t };
        ['title', 'date', 'startTime', 'endTime', 'repeat', 'repeatUntil', 'priority', 'description', 'notes'].forEach((k) => o[k] = f[k].value); o.title = o.title.trim(); o.alertMin = f.alertMin.value === '' ? null : Number(f.alertMin.value);
        const bad = P.validate(o); if (bad) { m.querySelector('#e').textContent = bad; return; }
        if (o.date) { date = o.date; } await db.put('tasks', o); await sync(); paint(); };
      const dl = m.querySelector('#dl'); if (dl) dl.onclick = async () => { if (confirm(`حذف المهمة «${t.title}»؟`)) { await db.remove('tasks', id); await sync(); paint(); } };
    }
    const pid = V.takePending('plan'); pid ? form(pid) : paint();
  };
})();
