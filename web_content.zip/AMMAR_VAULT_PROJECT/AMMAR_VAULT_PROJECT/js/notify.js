/* AMMAR VAULT - الإشعارات المحلية. على Android (Capacitor) تُجدوَل أصلياً وتعمل والتطبيق مغلق؛ في المتصفح تعمل أثناء فتح التطبيق فقط. */
(function () {
  const V = window.Vault; let timers = [];
  const native = () => V.Native && V.Native.plugin('LocalNotifications');
  const hash = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h) % 2147483647 || 1; };
  function toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; document.body.append(d); setTimeout(() => d.remove(), 8000); }
  function fire(x) { if (window.Notification && Notification.permission === 'granted') new Notification(x.title, { body: x.body }); else toast(`${x.title} — ${x.body}`); }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }
  async function sync(tasks) {
    const plan = V.PlanLogic.notifPlan(tasks, Date.now(), 30, 60), N = native();
    if (N) { try { const p = await N.getPending(); if (p.notifications && p.notifications.length) await N.cancel({ notifications: p.notifications });
      if (plan.length) await N.schedule({ notifications: plan.map((x) => ({ id: hash(x.key), title: x.title, body: x.body, schedule: { at: new Date(x.at), allowWhileIdle: true } })) });
      return { mode: 'native', count: plan.length }; } catch (e) { return { mode: 'native', error: String(e) }; } }
    clearTimers(); const lim = Date.now() + 24 * 3600e3;
    plan.filter((x) => x.at < lim).forEach((x) => timers.push(setTimeout(() => fire(x), x.at - Date.now())));
    return { mode: 'browser', count: timers.length };
  }
  async function requestPermission() { const N = native(); if (N) return (await N.requestPermissions()).display === 'granted'; return window.Notification ? (await Notification.requestPermission()) === 'granted' : false; }
  V.Notify = { sync, clearTimers, requestPermission, isNative: () => !!native() };
})();
