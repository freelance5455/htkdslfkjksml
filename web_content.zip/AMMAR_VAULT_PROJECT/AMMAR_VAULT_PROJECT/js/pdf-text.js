/* AMMAR VAULT - استخراج نص PDF محلياً (مستخرِج مبسّط بلا مكتبات): يدعم PDF النصي البسيط (Flate + سلاسل نصية).
   لا يدعم: PDF الممسوح ضوئياً (يحتاج OCR)، ولا الخطوط ذات الترميز الخاص (شائعة في PDF العربي من Word).
   الواجهة extract(bytes) => {text, ok, reason} قابلة للاستبدال بـ pdf.js عند دمج المكتبات المحلية (م13). */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const BASE = typeof document !== 'undefined' && document.currentScript ? new URL('../lib/pdfjs/', document.currentScript.src).href : null;
  let pdfjsP = null;
  const loadPdfJs = () => pdfjsP || (pdfjsP = BASE ? import(BASE + 'pdf.min.js').then((m) => { m.GlobalWorkerOptions.workerSrc = BASE + 'pdf.worker.min.js'; return m; }) : Promise.reject(new Error('no pdfjs')));
  // الاستخراج الرئيسي عبر pdf.js المحلي (lib/pdfjs): يدعم الخطوط المضمّنة ومعظم PDF العربي النصي
  async function extractWith(pdfjs, bytes) {
    const task = pdfjs.getDocument({ data: new Uint8Array(bytes), useSystemFonts: false, isEvalSupported: false, disableFontFace: true, verbosity: 0 }); const doc = await task.promise;
    const out = []; const n = Math.min(doc.numPages, 300);
    for (let i = 1; i <= n; i++) { const tc = await (await doc.getPage(i)).getTextContent(); out.push(tc.items.map((x) => x.str).join(' ')); }
    try { await task.destroy(); } catch (e) {} return out.join('\n').replace(/[ \t]+/g, ' ').trim();
  }
  const latin = (u) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return s; };
  async function inflate(bytes) {
    const ds = new DecompressionStream('deflate'), w = ds.writable.getWriter(); w.write(bytes).catch(() => {}); w.close().catch(() => {});
    return new Uint8Array(await new Response(ds.readable).arrayBuffer());
  }
  const unesc = (s) => s.replace(/\\([nrtbf()\\]|[0-7]{1,3}|\r?\n)/g, (_, c) => ({ n: '\n', r: '\r', t: '\t', b: '', f: '', '(': '(', ')': ')', '\\': '\\' }[c] ?? (/^[0-7]/.test(c) ? String.fromCharCode(parseInt(c, 8)) : '')));
  function textFromContent(c) {
    const out = []; const bt = /BT([\s\S]*?)ET/g; let m;
    while ((m = bt.exec(c))) {
      const re = /\(((?:\\[\s\S]|[^\\()])*)\)|(T\*|Td|TD|')/g; let r, line = '';
      while ((r = re.exec(m[1]))) line += r[1] !== undefined ? unesc(r[1]) : ' ';
      out.push(line.trim());
    }
    return out.filter(Boolean).join('\n');
  }
  async function extract(bytes, pdfjsModule) {
    try { const t = await extractWith(pdfjsModule || (await loadPdfJs()), bytes); if (t.replace(/\s/g, '').length >= 10) return { text: t, ok: true, engine: 'pdfjs' }; } catch (e) { /* ننتقل للمستخرج المبسّط */ }
    return extractSimple(bytes);
  }
  async function extractSimple(bytes) {
    try {
      const s = latin(bytes); const parts = []; let i = 0;
      while ((i = s.indexOf('stream', i)) !== -1) {
        if (s.slice(i - 3, i) === 'end') { i += 6; continue; }
        const head = s.slice(Math.max(0, i - 400), i); let st = i + 6; if (s[st] === '\r') st++; if (s[st] === '\n') st++;
        const en = s.indexOf('endstream', st); if (en === -1) break;
        const raw = bytes.subarray(st, en); i = en + 9;
        if (/\/Subtype\s*\/Image/.test(head)) continue;
        let data = null;
        if (/\/FlateDecode/.test(head)) { for (const cut of [0, 1, 2]) { try { data = await inflate(raw.subarray(0, raw.length - cut)); break; } catch (e) { data = null; } } }
        else data = /\/Filter/.test(head) ? null : raw;
        if (!data) continue; const c = latin(data); if (c.includes('BT')) { const t = textFromContent(c); if (t) parts.push(t); }
      }
      const text = parts.join('\n').trim();
      const good = (text.match(/[A-Za-z0-9\u0600-\u06FF]/g) || []).length;
      if (text.length < 10) return { text: '', ok: false, reason: 'لا نص قابل للاستخراج (غالباً ممسوح ضوئياً ويحتاج OCR)' };
      if (good / text.length < 0.6) return { text: '', ok: false, reason: 'ترميز خطوط غير مدعوم في المستخرج المبسّط' };
      return { text, ok: true };
    } catch (e) { return { text: '', ok: false, reason: 'تعذّر قراءة الملف' }; }
  }
  V.PdfText = { extract, extractSimple, extractWith };
})();
