/* AMMAR VAULT - أدوات واجهة مشتركة: نافذة حوار، قراءة ملف، تنزيل/مشاركة. */
(function () {
  const V = window.Vault;
  function dialog(title, bodyHtml, opts) {
    opts = opts || {};
    const o = document.createElement('div'); o.className = 'modal';
    o.innerHTML = `<form class="mbox" role="dialog" aria-modal="true"><h3 style="margin-top:0"></h3><div class="mbody">${bodyHtml}</div><p class="err" role="alert"></p>
      <div class="row">${opts.onOk ? `<button class="btn" style="width:auto">${opts.ok || 'حفظ'}</button>` : ''}<button type="button" class="btn ghost" data-x>إغلاق</button></div></form>`;
    o.querySelector('h3').textContent = title; document.body.append(o);
    const f = o.querySelector('form'), e = o.querySelector('.err'), close = () => o.remove();
    o.querySelector('[data-x]').onclick = close; o.onclick = (ev) => { if (ev.target === o) close(); };
    f.onsubmit = async (ev) => { ev.preventDefault(); try { if ((await opts.onOk(f)) !== false) close(); } catch (x) { e.textContent = x.message || String(x); } };
    return { form: f, body: o.querySelector('.mbody'), close };
  }
  const readBytes = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(new Uint8Array(r.result)); r.onerror = rej; r.readAsArrayBuffer(f); });
  async function shareOrDownload(name, type, bytes) {
    if (V.Native && V.Native.isNative() && V.Native.plugin('AmmarFile')) { const r = await openBytes(name, type, bytes); return r === 'cancelled' ? 'cancelled' : 'downloaded'; }
    const file = new File([bytes], name, { type: type || 'application/octet-stream' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], title: name }); return 'shared'; } catch (e) { if (e.name === 'AbortError') return 'cancelled'; } }
    const a = document.createElement('a'); a.href = URL.createObjectURL(file); a.download = name; document.body.append(a); a.click(); a.remove(); return 'downloaded';
  }
  // فتح بايتات: في المتصفح نافذة جديدة؛ على Android (WebView لا يفتح blob خارجياً) تُحفظ نسخة عبر مستعرض الملفات
  const native = () => V.Native && V.Native.isNative() && V.Native.plugin('AmmarFile');
  async function openBytes(name, type, bytes) {
    if (native()) { try { await V.Native.saveDocument(name, bytes); return 'saved'; } catch (e) { if (e.code === 'CANCELLED' || /CANCELLED/.test(e.message || '')) return 'cancelled'; throw e; } }
    window.open(URL.createObjectURL(new Blob([bytes], { type: type || 'application/octet-stream' }))); return 'opened';
  }
  V.UI = { dialog, readBytes, shareOrDownload, openBytes };
})();
