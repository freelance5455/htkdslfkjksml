/* AMMAR VAULT - معرض الصور (المرحلة 7): الأصل يُحفظ بلا ضغط، مع مصغّرة منفصلة للعرض السريع. */
(function () {
  const V = window.Vault, L = V.FilesLogic, UI = V.UI;
  V.Sections = V.Sections || {};
  async function makeThumb(file) {
    try {
      const url = URL.createObjectURL(file), img = new Image(); img.src = url; await img.decode();
      const k = 240 / Math.max(img.width, img.height, 240), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      const b = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.7)); return b ? new Uint8Array(await b.arrayBuffer()) : null;
    } catch (e) { return null; }
  }
  V.Sections.photos = async function (m, { db, esc }) {
    let q = '', album = '', urls = [];
    async function paint(msg) {
      urls.forEach(URL.revokeObjectURL); urls = [];
      const [photos, albums] = await Promise.all([db.all('photos'), db.all('albums')]);
      const rows = L.searchPhotos(photos, albums, q, album);
      m.innerHTML = `<h2>الصور</h2><div class="row"><label class="btn ghost" style="margin:0;cursor:pointer;color:var(--text)">إضافة صور<input id="up" type="file" accept="image/*" multiple hidden></label><button class="btn ghost" id="na">ألبوم جديد</button>
        <input id="q" type="text" placeholder="بحث بالاسم أو الوصف أو التصنيف" style="max-width:240px" value="${esc(q)}">
        <select id="al"><option value="">كل الصور</option><option value="none" ${album === 'none' ? 'selected' : ''}>بدون ألبوم</option>${albums.map((a) => `<option value="${a.id}" ${album === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select></div>
        <p class="err" role="alert">${msg ? esc(msg) : ''}</p><div class="gallery" id="g">${rows.length ? '' : `<p class="note">${photos.length ? 'لا نتائج.' : 'لا توجد صور بعد.'}</p>`}</div>`;
      const g = m.querySelector('#g');
      for (const p of rows) { const b = document.createElement('button'); b.className = 'ph'; b.setAttribute('aria-label', p.name);
        const blob = await db.getBlob(p.thumbId || p.blobId); if (blob) { const img = new Image(); const u = URL.createObjectURL(new Blob([blob.bytes], { type: p.thumbId ? 'image/jpeg' : p.type })); urls.push(u); img.src = u; img.alt = p.name; b.append(img); }
        b.onclick = () => view(p, albums); g.append(b); }
      m.querySelector('#q').oninput = (e) => { q = e.target.value; clearTimeout(paint.t); paint.t = setTimeout(async () => { await paint(); const i = m.querySelector('#q'); i.focus(); i.setSelectionRange(q.length, q.length); }, 250); };
      m.querySelector('#al').onchange = (e) => { album = e.target.value; paint(); };
      m.querySelector('#na').onclick = () => UI.dialog('ألبوم جديد', '<input name="n" type="text" required autofocus>', { ok: 'إنشاء', onOk: async (f) => {
        const bad = L.validateName(f.n.value, albums.map((a) => a.name)); if (bad) throw new Error(bad); await db.put('albums', { name: f.n.value.trim() }); paint(); } });
      m.querySelector('#up').onchange = async (e) => { const errs = [];
        for (const file of e.target.files) { if (file.size > L.MAX_BYTES) { errs.push(`«${file.name}» كبيرة جداً`); continue; }
          const blobId = await db.putBlob({ name: file.name, type: file.type, bytes: await UI.readBytes(file) });
          const t = await makeThumb(file), thumbId = t ? await db.putBlob({ name: 'thumb', type: 'image/jpeg', bytes: t }) : null;
          await db.put('photos', { name: file.name.replace(/\.[^.]+$/, ''), description: '', category: '', albumId: album && album !== 'none' ? album : null, blobId, thumbId, type: file.type, size: file.size }); }
        paint(errs.join('، ')); };
    }
    async function view(p, albums) {
      const blob = await db.getBlob(p.blobId); const u = blob ? URL.createObjectURL(new Blob([blob.bytes], { type: p.type })) : '';
      const d = UI.dialog(p.name, `<img src="${u}" alt="${esc(p.name)}" style="max-width:100%;max-height:55vh;display:block;margin:auto"><p class="note">${esc(p.description || '')} ${p.category ? '· ' + esc(p.category) : ''}</p>
        <div class="row"><button type="button" class="btn ghost sm" id="ed">تعديل المعلومات</button><button type="button" class="btn ghost sm" id="full">الحجم الكامل</button><button type="button" class="btn ghost sm" id="sh">مشاركة</button><button type="button" class="btn ghost sm danger" id="dl">حذف</button></div>`);
      d.body.querySelector('#full').onclick = () => (V.Native.isNative() ? UI.openBytes(p.name, p.type, blob.bytes) : window.open(u));
      d.body.querySelector('#sh').onclick = () => UI.shareOrDownload(p.name + '.' + (p.type.split('/')[1] || 'jpg'), p.type, blob.bytes);
      d.body.querySelector('#dl').onclick = async () => { if (!confirm(`حذف الصورة «${p.name}» نهائياً؟`)) return; await db.removeBlob(p.blobId); if (p.thumbId) await db.removeBlob(p.thumbId); await db.remove('photos', p.id); d.close(); paint(); };
      d.body.querySelector('#ed').onclick = () => { d.close(); UI.dialog('معلومات الصورة', `<label>الاسم</label><input name="n" type="text" value="${esc(p.name)}" required><label>الوصف</label><textarea name="d" rows="2">${esc(p.description || '')}</textarea>
        <label>التصنيف</label><select name="c"><option value=""></option>${L.PHOTO_CATS.map((c) => `<option ${c === p.category ? 'selected' : ''}>${c}</option>`).join('')}</select>
        <label>الألبوم</label><select name="a"><option value="">بدون</option>${albums.map((a) => `<option value="${a.id}" ${a.id === p.albumId ? 'selected' : ''}>${esc(a.name)}</option>`).join('')}</select>`, { onOk: async (f) => {
        if (!f.n.value.trim()) throw new Error('الاسم مطلوب'); await db.put('photos', { ...p, name: f.n.value.trim(), description: f.d.value, category: f.c.value, albumId: f.a.value || null }); paint(); } }); };
    }
    const pid = V.takePending('photos'); await paint(); if (pid) { const p = await db.get('photos', pid); if (p) view(p, await db.all('albums')); }
  };
})();
