/* AMMAR VAULT - محوّلات التخزين (get/set/del/keys/clear). المتصفح: IndexedDB (اتصال واحد مخزَّن). الاختبارات: ذاكرة.
   عند إضافة SQLite (المرحلة 13) يُكتب محوّل جديد بنفس الواجهة دون تغيير باقي الكود. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  function memory() {
    const m = new Map();
    return { async get(k) { return m.has(k) ? m.get(k) : null; }, async set(k, v) { m.set(k, v); }, async del(k) { m.delete(k); },
      async keys(p) { return [...m.keys()].filter((k) => k.startsWith(p)); }, async clear() { m.clear(); } };
  }
  function indexedDBAdapter(name) {
    let dbp = null;
    const open = () => dbp || (dbp = new Promise((res, rej) => {
      const r = indexedDB.open(name || 'ammar_vault', 1);
      r.onupgradeneeded = () => r.result.createObjectStore('kv');
      r.onsuccess = () => res(r.result); r.onerror = () => { dbp = null; rej(r.error); };
    }));
    const run = async (mode, fn) => { const db = await open();
      return new Promise((res, rej) => { const t = db.transaction('kv', mode); const out = fn(t.objectStore('kv'));
        t.oncomplete = () => res(out && out.result); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error); }); };
    return {
      get: async (k) => (await run('readonly', (s) => s.get(k))) ?? null,
      set: (k, v) => run('readwrite', (s) => s.put(v, k)),
      del: (k) => run('readwrite', (s) => s.delete(k)),
      keys: async (p) => (await run('readonly', (s) => s.getAllKeys())).filter((k) => k.startsWith(p)),
      clear: () => run('readwrite', (s) => s.clear()),
    };
  }
  // محوّل SQLite عبر إضافة @capacitor-community/sqlite (Android). القيم مشفّرة أصلاً بمفتاح البيانات.
  // الواجهة المستخدمة: createConnection/open/execute/run/query. (لم يُجرَّب على جهاز: انظر docs/BUILD_APK.md)
  function sqliteAdapter(plugin, database) {
    let ready = null;
    const init = () => ready || (ready = (async () => {
      try { await plugin.createConnection({ database, version: 1, encrypted: false, mode: 'no-encryption', readonly: false }); } catch (e) { /* قد يكون الاتصال موجوداً */ }
      await plugin.open({ database });
      await plugin.execute({ database, statements: 'CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY NOT NULL, v TEXT NOT NULL);' });
    })());
    const run = async (statement, values) => { await init(); return plugin.run({ database, statement, values, transaction: false }); };
    const query = async (statement, values) => { await init(); const r = await plugin.query({ database, statement, values }); return (r.values || []).filter((x) => x && 'k' in x || x && 'v' in x); };
    return {
      async get(k) { const r = await query('SELECT v FROM kv WHERE k = ?', [k]); return r.length ? JSON.parse(r[0].v) : null; }, // القيم تُخزَّن JSON (نصوص أو كائنات مثل meta:auth)
      async set(k, v) { await run('INSERT OR REPLACE INTO kv (k, v) VALUES (?, ?)', [k, JSON.stringify(v)]); },
      async del(k) { await run('DELETE FROM kv WHERE k = ?', [k]); },
      async keys(p) { return (await query('SELECT k FROM kv WHERE substr(k, 1, ?) = ?', [p.length, p])).map((x) => x.k); },
      async clear() { await run('DELETE FROM kv', []); },
    };
  }
  V.Storage = { memory, indexedDB: indexedDBAdapter, sqlite: sqliteAdapter };
})();
