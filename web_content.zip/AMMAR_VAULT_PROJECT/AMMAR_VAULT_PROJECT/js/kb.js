/* AMMAR VAULT - مكتبتي المعرفية (ملخصات) + الروابط المهمة (المرحلة 10). */
(function () {
  const V = window.Vault, K = V.KbLogic, UI = V.UI;
  V.Sections = V.Sections || {};
  const today = () => V.PlanLogic.today();
  const openUrl = (u) => { const n = K.normalizeUrl(u); if (n) window.open(n, '_blank', 'noopener'); };
  async function copy(t) { try { await navigator.clipboard.writeText(t); } catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.append(a); a.select(); document.execCommand('copy'); a.remove(); } }

  V.Sections.kb = async function (m, { db, esc }) {
    let q = '', cat = '';
    async function list() {
      const rows = K.filterNotes(await db.all('notes'), q, cat);
      m.querySelector('#rows').innerHTML = rows.length ? rows.map((n) => `<button class="item" data-id="${n.id}"><b>${esc(n.title)}</b><span>${esc(n.category || '')}${n.lessonName ? ' · ' + esc(n.lessonName) : ''}</span><em>${esc(n.addedAt || '')}</em></button>`).join('') : '<p class="note">لا ملخصات مطابقة. اضغط «ملخص جديد» وألصق ملخصك.</p>';
      m.querySelectorAll('.item').forEach((b) => b.onclick = () => view(b.dataset.id));
    }
    function shell() {
      m.innerHTML = `<h2>مكتبتي المعرفية</h2><div class="row"><button class="btn ghost" id="add">ملخص جديد</button><input id="q" type="text" placeholder="بحث داخل الملخصات" style="max-width:230px" value="${esc(q)}">
        <select id="c"><option value="">كل التصنيفات</option>${K.CATS.map((c) => `<option ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select></div><div class="rows" id="rows"></div>`;
      m.querySelector('#add').onclick = () => form(); m.querySelector('#q').oninput = (e) => { q = e.target.value; list(); }; m.querySelector('#c').onchange = (e) => { cat = e.target.value; list(); }; list();
    }
    async function view(id) {
      const n = await db.get('notes', id);
      m.innerHTML = `<h2>${esc(n.title)}</h2><p class="note">${esc(n.category || '')}${n.lessonName ? ' · ' + esc(n.lessonName) : ''} · ${esc(n.addedAt || '')}</p>
        <div class="panel wide" style="max-width:720px"><div class="mdtxt" dir="auto">${esc(n.content)}</div></div>
        ${(n.keywords || []).length ? `<div class="chips">${n.keywords.map((k) => `<span>${esc(k)}</span>`).join('')}</div>` : ''}
        <div id="ex"></div>${n.notes ? `<p class="note">ملاحظات: ${esc(n.notes)}</p>` : ''}
        <div class="row"><button class="btn ghost" id="ed">تعديل</button><button class="btn ghost" id="bk">رجوع</button><button class="btn ghost danger" id="dl">حذف</button></div>`;
      const ex = m.querySelector('#ex');
      (n.links || []).forEach((u) => { const r = document.createElement('div'); r.className = 'row'; r.innerHTML = `<code dir="ltr" style="flex:1;overflow:hidden;text-overflow:ellipsis">${esc(u)}</code><button class="btn ghost sm">فتح</button>`; r.querySelector('button').onclick = () => openUrl(u); ex.append(r); });
      (n.files || []).forEach((f) => { const b = document.createElement('button'); b.className = 'btn ghost sm'; b.textContent = 'مرفق: ' + f.name; b.style.margin = '2px';
        b.onclick = async () => { const x = await db.getBlob(f.id); if (x) UI.openBytes(f.name, x.type, x.bytes); }; ex.append(b); });
      m.querySelector('#bk').onclick = shell; m.querySelector('#ed').onclick = () => form(id);
      m.querySelector('#dl').onclick = async () => { if (!confirm(`حذف الملخص «${n.title}» ومرفقاته نهائياً؟`)) return; await Promise.all((n.files || []).map((f) => db.removeBlob(f.id))); await db.remove('notes', id); shell(); };
    }
    async function form(id) {
      const n = id ? await db.get('notes', id) : { category: K.CATS[0], addedAt: today(), files: [] }; let files = [...(n.files || [])]; const added = [], removed = [];
      m.innerHTML = `<h2>${id ? 'تعديل ملخص' : 'ملخص جديد'}</h2><form class="panel wide" style="max-width:720px" id="f" autocomplete="off">
        <label>عنوان الملخص</label><input name="title" type="text" value="${esc(n.title || '')}" required>
        <label>المادة / التصنيف</label><select name="category">${K.CATS.map((c) => `<option ${c === n.category ? 'selected' : ''}>${c}</option>`).join('')}</select>
        <label>اسم الدرس</label><input name="lessonName" type="text" value="${esc(n.lessonName || '')}">
        <label>تاريخ الإضافة</label><input name="addedAt" type="date" value="${n.addedAt || today()}">
        <div class="row" style="justify-content:space-between"><label style="margin:0">محتوى الملخص</label><button type="button" class="btn ghost sm" id="ps">لصق من الحافظة</button></div>
        <textarea name="content" rows="10" dir="auto">${esc(n.content || '')}</textarea>
        <label>كلمات مفتاحية (افصل بفاصلة)</label><input name="keywords" type="text" value="${esc((n.keywords || []).join('، '))}">
        <label>روابط مهمة (رابط في كل سطر)</label><textarea name="links" rows="2" dir="ltr">${esc((n.links || []).join('\n'))}</textarea>
        <label>ملفات مرفقة</label><input id="at" type="file" multiple><div id="fl"></div>
        <label>ملاحظات</label><textarea name="notes" rows="2">${esc(n.notes || '')}</textarea><p class="err" id="e" role="alert"></p>
        <div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button></div></form>`;
      const f = m.querySelector('#f'), paintF = () => { const el = m.querySelector('#fl'); el.innerHTML = '';
        files.forEach((x) => { const r = document.createElement('div'); r.className = 'row'; r.innerHTML = `<span style="flex:1">${esc(x.name)}</span><button type="button" class="btn ghost sm">إزالة</button>`; r.querySelector('button').onclick = () => { files = files.filter((y) => y.id !== x.id); removed.push(x.id); paintF(); }; el.append(r); }); };
      paintF();
      m.querySelector('#ps').onclick = async () => { try { f.content.value = (f.content.value ? f.content.value + '\n' : '') + await navigator.clipboard.readText(); } catch (e) { m.querySelector('#e').textContent = 'تعذّر قراءة الحافظة، الصق يدوياً داخل الحقل.'; } };
      m.querySelector('#at').onchange = async (e) => { for (const file of e.target.files) { if (file.size > V.FilesLogic.MAX_BYTES) { m.querySelector('#e').textContent = `«${file.name}» كبير جداً`; continue; }
        const bid = await db.putBlob({ name: file.name, type: file.type, bytes: await UI.readBytes(file) }); added.push(bid); files.push({ id: bid, name: file.name, type: file.type }); } e.target.value = ''; paintF(); };
      m.querySelector('#cn').onclick = async () => { await Promise.all(added.map((b) => db.removeBlob(b))); id ? view(id) : shell(); };
      f.onsubmit = async (ev) => { ev.preventDefault(); const pl = K.parseLinks(f.links.value);
        const o = { ...n, title: f.title.value.trim(), category: f.category.value, lessonName: f.lessonName.value.trim(), addedAt: f.addedAt.value, content: f.content.value, keywords: K.parseKeywords(f.keywords.value), links: pl.urls, notes: f.notes.value, files };
        const bad = K.validateNote(o) || (pl.bad.length ? `رابط غير صالح: ${pl.bad[0]}` : null); if (bad) { m.querySelector('#e').textContent = bad; return; }
        const saved = await db.put('notes', o); await Promise.all(removed.filter((b) => !added.includes(b)).map((b) => db.removeBlob(b)));
        await Promise.all(added.filter((b) => !files.some((x) => x.id === b)).map((b) => db.removeBlob(b))); view(saved.id); };
    }
    const pid = V.takePending('kb'); pid ? view(pid) : shell();
  };

  V.Sections.links = async function (m, { db, esc }) {
    let q = '', cat = '';
    async function list() {
      const rows = K.filterLinks(await db.all('links'), q, cat);
      const box = m.querySelector('#rows');
      box.innerHTML = rows.length ? rows.map((l) => `<div class="item" data-id="${l.id}"><b>${esc(l.name)}</b><span>${esc(l.category || '')}${l.description ? ' · ' + esc(l.description) : ''}</span><code dir="ltr" style="grid-column:1/3;overflow:hidden;text-overflow:ellipsis">${esc(l.url)}</code>
        <div class="row" style="grid-column:1/3"><button class="btn ghost sm" data-a="open">فتح</button><button class="btn ghost sm" data-a="copy">نسخ</button><button class="btn ghost sm" data-a="edit">تعديل</button></div></div>`).join('') : '<p class="note">لا روابط مطابقة. اضغط «رابط جديد».</p>';
      box.querySelectorAll('.item').forEach((el) => { const l = rows.find((r) => r.id === el.dataset.id);
        el.querySelectorAll('button').forEach((b) => b.onclick = async () => { const a = b.dataset.a; if (a === 'open') openUrl(l.url); else if (a === 'copy') { await copy(l.url); b.textContent = 'تم النسخ'; setTimeout(() => b.textContent = 'نسخ', 1500); } else form(l.id); }); });
    }
    function shell() {
      m.innerHTML = `<h2>الروابط المهمة</h2><div class="row"><button class="btn ghost" id="add">رابط جديد</button><input id="q" type="text" placeholder="بحث في الروابط" style="max-width:220px" value="${esc(q)}">
        <select id="c"><option value="">كل التصنيفات</option>${K.LINK_CATS.map((c) => `<option ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select></div><div class="rows" id="rows"></div>`;
      m.querySelector('#add').onclick = () => form(); m.querySelector('#q').oninput = (e) => { q = e.target.value; list(); }; m.querySelector('#c').onchange = (e) => { cat = e.target.value; list(); }; list();
    }
    async function form(id) {
      const l = id ? await db.get('links', id) : { category: K.LINK_CATS[0] };
      m.innerHTML = `<h2>${id ? 'تعديل رابط' : 'رابط جديد'}</h2><form class="panel wide" id="f" autocomplete="off"><label>اسم الموقع</label><input name="name" type="text" value="${esc(l.name || '')}" required>
        <label>الرابط</label><input name="url" type="text" dir="ltr" value="${esc(l.url || '')}" required><label>التصنيف</label><select name="category">${K.LINK_CATS.map((c) => `<option ${c === l.category ? 'selected' : ''}>${c}</option>`).join('')}</select>
        <label>الوصف</label><input name="description" type="text" value="${esc(l.description || '')}"><label>ملاحظات</label><textarea name="notes" rows="2">${esc(l.notes || '')}</textarea><p class="err" id="e" role="alert"></p>
        <div class="row"><button class="btn" style="width:auto">حفظ</button><button type="button" class="btn ghost" id="cn">رجوع</button>${id ? '<button type="button" class="btn ghost danger" id="dl">حذف</button>' : ''}</div></form>`;
      const f = m.querySelector('#f'); m.querySelector('#cn').onclick = shell;
      f.onsubmit = async (ev) => { ev.preventDefault(); const o = { ...l, name: f.name.value.trim(), url: f.url.value.trim(), category: f.category.value, description: f.description.value.trim(), notes: f.notes.value };
        const bad = K.validateLink(o); if (bad) { m.querySelector('#e').textContent = bad; return; } o.url = K.normalizeUrl(o.url); await db.put('links', o); shell(); };
      const dl = m.querySelector('#dl'); if (dl) dl.onclick = async () => { if (confirm(`حذف الرابط «${l.name}»؟`)) { await db.remove('links', id); shell(); } };
    }
    const pid = V.takePending('links'); pid ? form(pid) : shell();
  };
})();
