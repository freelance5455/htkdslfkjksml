/* AMMAR VAULT - منطق الوثائق (بدون واجهة، قابل للاختبار): حالة الصلاحية والتنبيهات. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const DAY = 86400000;
  const TYPES = ['جواز سفر', 'بطاقة شخصية', 'رخصة قيادة', 'شهادة', 'بطاقة وظيفية', 'عقد', 'وثيقة رسمية', 'أخرى'];
  const parse = (s) => (s ? new Date(s + 'T00:00:00').getTime() : NaN);
  const startOfDay = (d) => { const x = new Date(d); x.setHours(0, 0, 0, 0); return x.getTime(); };
  function status(doc, now) {
    const exp = parse(doc.expiryDate);
    if (isNaN(exp)) return { state: 'none', days: null };
    const days = Math.round((exp - startOfDay(now || Date.now())) / DAY);
    const alertDays = Number.isFinite(+doc.alertDays) ? +doc.alertDays : 30;
    if (days < 0) return { state: 'expired', days };
    return { state: days <= alertDays ? 'soon' : 'valid', days };
  }
  const label = (s) => s.state === 'none' ? 'بدون تاريخ انتهاء' : s.state === 'expired' ? `منتهية منذ ${-s.days} يوم`
    : s.days === 0 ? 'تنتهي اليوم' : s.state === 'soon' ? `تنتهي خلال ${s.days} يوم` : `سارية (${s.days} يوم)`;
  const alerts = (docs, now) => docs.map((d) => ({ doc: d, st: status(d, now) }))
    .filter((x) => x.st.state === 'expired' || x.st.state === 'soon').sort((a, b) => a.st.days - b.st.days);
  function validate(d) {
    if (!d.title || !d.title.trim()) return 'اسم الوثيقة مطلوب';
    const i = parse(d.issueDate), e = parse(d.expiryDate);
    if (!isNaN(i) && !isNaN(e) && e < i) return 'تاريخ الانتهاء قبل تاريخ الإصدار';
    if (d.alertDays !== '' && d.alertDays != null && !(+d.alertDays >= 0)) return 'مدة التنبيه يجب أن تكون رقماً';
    return null;
  }
  V.DocsLogic = { TYPES, status, label, alerts, validate };
})();
