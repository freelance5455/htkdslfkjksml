/* AMMAR VAULT - النسخ الاحتياطي والاستعادة (المرحلة 12) — منطق بلا واجهة.
   صيغة الملف (.avbak): AMVAULT1 | salt(16) | iter(4) | iv(12) | AES-256-GCM( ZIP{manifest,meta,index,d/n} )
   مفتاح الغلاف يُشتق من كلمة المرور الرئيسية فقط، والسجلات بداخله مشفّرة أصلاً بمفتاح البيانات المغلَّف بنفس الكلمة.
   لذلك تُستعاد النسخة على أي هاتف بكلمة المرور وحدها، دون أي مفتاح مرتبط بالجهاز القديم. */
(function () {
  const root = typeof window !== 'undefined' ? window : globalThis;
  const V = (root.Vault = root.Vault || {});
  const C = () => V.Crypto, Z = () => (typeof JSZip !== 'undefined' ? JSZip : require('../lib/jszip/jszip.min.js'));
  const MAGIC = new TextEncoder().encode('AMVAULT1');
  const EXCLUDE = ['rec:pdf_index:']; // فهرس مشتق يُعاد بناؤه تلقائياً بعد الاستعادة
  const err = (m) => Object.assign(new Error(m), { arabic: m });
  const included = (k) => !EXCLUDE.some((p) => k.startsWith(p));
  const tableOf = (k) => (k.startsWith('blob:') ? '_blobs' : k.split(':')[1]);
  const KEY_RE = /^(rec:[a-z_]+:[^:]+|blob:[^:]+)$/;

  async function create(store, password, onProgress) {
    const meta = await store.get('meta:auth'); if (!meta) throw err('لا توجد خزنة لعمل نسخة منها');
    const keys = (await store.keys('')).filter((k) => included(k) && k !== 'meta:auth').sort();
    const zip = new (Z())(), idx = [], counts = {}; let chars = 0;
    for (const k of keys) { const v = await store.get(k); if (v == null) continue; zip.file('d/' + idx.length, v); idx.push(k); chars += v.length;
      const t = tableOf(k); counts[t] = (counts[t] || 0) + 1; if (onProgress && idx.length % 25 === 0) onProgress('قراءة البيانات', idx.length, keys.length); }
    const manifest = { format: 1, app: 'AMMAR VAULT', createdAt: new Date().toISOString(), records: idx.length, counts, payloadChars: chars };
    zip.file('manifest.json', JSON.stringify(manifest)); zip.file('meta.json', JSON.stringify(meta)); zip.file('index.json', JSON.stringify(idx));
    if (onProgress) onProgress('الضغط والتشفير', 0, 0);
    const zbytes = await zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    const salt = C().rnd(16), iv = C().rnd(12), head = new Uint8Array(28); head.set(MAGIC, 0); head.set(salt, 8); new DataView(head.buffer).setUint32(24, C().ITER);
    const ct = await C().encBytes(await C().deriveAES(password, salt, C().ITER), zbytes, iv, head);
    const out = new Uint8Array(40 + ct.length); out.set(head, 0); out.set(iv, 28); out.set(ct, 40);
    return { bytes: out, manifest };
  }

  async function open(bytes, password) {
    bytes = new Uint8Array(bytes);
    if (bytes.length < 60 || !MAGIC.every((b, i) => bytes[i] === b)) throw err('هذا ليس ملف نسخة احتياطية من AMMAR VAULT');
    const head = bytes.slice(0, 28), iv = bytes.slice(28, 40), ct = bytes.subarray(40);
    const iter = new DataView(head.buffer).getUint32(24); if (iter < 100000 || iter > 5000000) throw err('ملف النسخة تالف');
    let zbytes; try { zbytes = await C().decBytes(await C().deriveAES(password, head.slice(8, 24), iter), ct, iv, head); } catch (e) { throw err('كلمة المرور غير صحيحة أو ملف النسخة تالف'); }
    let zip; try { zip = await Z().loadAsync(zbytes); } catch (e) { throw err('ملف النسخة تالف'); }
    const rd = async (n) => { const f = zip.file(n); if (!f) throw err('ملف النسخة غير مكتمل'); return f.async('string'); };
    let manifest, meta, idx; try { manifest = JSON.parse(await rd('manifest.json')); meta = JSON.parse(await rd('meta.json')); idx = JSON.parse(await rd('index.json')); } catch (e) { throw err(e.arabic || 'ملف النسخة تالف'); }
    if (manifest.format !== 1) throw err('إصدار النسخة غير مدعوم'); if (!Array.isArray(idx) || idx.length !== manifest.records) throw err('ملف النسخة غير مكتمل');
    if (!idx.every((k) => typeof k === 'string' && KEY_RE.test(k))) throw err('ملف النسخة يحتوي مفاتيح غير صالحة');
    let dek; try { dek = await C().unwrapDEK(meta.wrapped, await C().deriveKEK(password, C().unb64(meta.salt), meta.iter)); } catch (e) { throw err('النسخة سليمة لكنها لا تُفتح بكلمة المرور هذه'); }
    return { manifest, meta, idx, dek, read: (i) => rd('d/' + i) };
  }

  // تحقق عميق: كل سجل في النسخة يُفك تشفيره فعلاً، وعدد/أسماء السجلات تطابق المصدر
  async function verify(bytes, password, store, onProgress) {
    const p = await open(bytes, password), problems = [];
    if (store) { const live = (await store.keys('')).filter((k) => included(k) && k !== 'meta:auth').sort(); const mine = [...p.idx].sort();
      if (live.length !== mine.length || live.some((k, i) => k !== mine[i])) problems.push('محتوى النسخة لا يطابق البيانات الحالية'); }
    for (let i = 0; i < p.idx.length; i++) { try { await C().decrypt(p.dek, await p.read(i)); } catch (e) { problems.push('سجل تالف: ' + p.idx[i]); }
      if (onProgress && i % 25 === 0) onProgress('التحقق من السلامة', i, p.idx.length); }
    return { ok: problems.length === 0, problems, manifest: p.manifest };
  }

  async function rollback(store, snap) {
    for (const k of await store.keys('')) await store.del(k);
    for (const k of await snap.keys('')) if (k !== '__snapshot_at') await store.set(k, await snap.get(k));
  }
  // استعادة آمنة: لقطة للبيانات الحالية أولاً ثم الاستبدال، مع تراجع تلقائي عند أي فشل
  async function restore(store, parsed, snap, onProgress) {
    const old = await store.keys(''), hadData = old.length > 0;
    if (hadData) { await snap.clear(); for (const k of old) await snap.set(k, await store.get(k)); await snap.set('__snapshot_at', new Date().toISOString()); }
    try {
      for (const k of old) await store.del(k);
      await store.set('meta:auth', parsed.meta);
      for (let i = 0; i < parsed.idx.length; i++) { await store.set(parsed.idx[i], await parsed.read(i)); if (onProgress && i % 25 === 0) onProgress('استعادة البيانات', i, parsed.idx.length); }
      const now = (await store.keys('')).filter(included);
      if (now.length !== parsed.idx.length + 1) throw err('عدد السجلات بعد الاستعادة لا يطابق النسخة');
    } catch (e) {
      if (hadData) await rollback(store, snap); else for (const k of await store.keys('')) await store.del(k);
      throw err('فشلت الاستعادة' + (hadData ? ' وأُعيدت بياناتك السابقة' : '') + ': ' + (e.arabic || e.message));
    }
    return { ...parsed.manifest, hadData };
  }
  const hasSnapshot = async (snap) => !!(await snap.get('__snapshot_at'));
  async function undo(store, snap) { if (!(await hasSnapshot(snap))) throw err('لا توجد لقطة للتراجع عنها'); await rollback(store, snap); await snap.clear(); }
  const fileName = (d) => { d = d || new Date(); const z = (n) => String(n).padStart(2, '0'); return `AMMAR_VAULT_${d.getFullYear()}${z(d.getMonth() + 1)}${z(d.getDate())}_${z(d.getHours())}${z(d.getMinutes())}.avbak`; };
  V.Backup = { create, open, verify, restore, undo, hasSnapshot, fileName, EXCLUDE };
})();
