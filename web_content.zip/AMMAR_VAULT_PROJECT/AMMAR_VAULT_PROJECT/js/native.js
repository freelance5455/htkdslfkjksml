/* AMMAR VAULT - جسر Android (Capacitor). خارج Android كل شيء هنا يتعطّل بأمان ويعمل التطبيق في المتصفح.
   الإضافات الأصلية: CapacitorSQLite (تخزين) · LocalNotifications · AmmarSecure (بصمة + Android Keystore) · AmmarFile (حفظ عبر Storage Access Framework).
   غير مجرَّب على جهاز: راجع docs/BUILD_APK.md. */
(function () {
  const V = window.Vault, cap = () => window.Capacitor, cache = {};
  const isNative = () => !!(cap() && cap().isNativePlatform && cap().isNativePlatform());
  const plugin = (n) => (isNative() && cap().registerPlugin ? cache[n] || (cache[n] = cap().registerPlugin(n)) : null);
  const secure = {
    available: async () => { const p = plugin('AmmarSecure'); return p ? p.isAvailable() : { available: false }; },
    enable: (raw) => plugin('AmmarSecure').enable({ secret: V.Crypto.b64(raw) }),
    unlock: async () => V.Crypto.unb64((await plugin('AmmarSecure').unlock()).secret),
    disable: () => plugin('AmmarSecure').disable(),
  };
  // حفظ ملف عبر مستعرض ملفات Android الرسمي (يسمح بذاكرة الهاتف أو فلاش USB)، مع بصمة SHA-256 لإعادة قراءة الملف المحفوظ
  async function saveDocument(name, bytes, onProgress) {
    const p = plugin('AmmarFile'), r0 = await p.begin({ name, mime: 'application/octet-stream' }), CH = 512 * 1024;
    try { for (let i = 0; i < bytes.length; i += CH) { await p.write({ chunk: V.Crypto.b64(bytes.subarray(i, i + CH)) }); if (onProgress) onProgress(Math.min(i + CH, bytes.length), bytes.length); }
      const f = await p.finish(); return { name: r0.name || name, size: f.size, sha256: f.sha256 }; }
    catch (e) { try { await p.abort(); } catch (x) {} throw e; }
  }
  V.Storage.auto = (name) => (isNative() ? V.Storage.sqlite(plugin('CapacitorSQLite'), name) : V.Storage.indexedDB(name));
  if (isNative()) V.FilesLogic.MAX_BYTES = Math.min(V.FilesLogic.MAX_BYTES, 20 * 1024 * 1024); // حد أصغر عبر جسر Capacitor حتى يُختبر على جهاز
  V.Native = { isNative, plugin, secure, saveDocument };
})();
