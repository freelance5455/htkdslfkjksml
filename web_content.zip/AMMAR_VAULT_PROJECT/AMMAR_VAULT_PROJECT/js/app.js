/* AMMAR VAULT - الواجهة (المراحل 1-3): إعداد كلمة المرور، القفل، لوحة رئيسية بأعداد حقيقية، الإعدادات. */
(function () {
  const V = window.Vault;
  const store = V.Storage.auto('ammar_vault');
  const auth = V.Auth(store);
  const db = V.DB(store, auth);
  const $app = document.getElementById('app');
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pref = (k, d) => { try { return localStorage.getItem('av_' + k) ?? d; } catch (e) { return d; } };
  const setPref = (k, v) => { try { localStorage.setItem('av_' + k, v); } catch (e) {} };
  const applyTheme = () => document.documentElement.dataset.theme = pref('theme', 'dark');
  applyTheme();
  const bioOn = () => V.Native.isNative() && pref('bio', '0') === '1';

  const SECTIONS = [
    { id: 'home', name: 'الرئيسية', phase: 0 }, { id: 'docs', name: 'الوثائق', phase: 0, table: 'documents', label: 'وثيقة' },
    { id: 'pass', name: 'كلمات المرور', phase: 0, table: 'accounts', label: 'حساب' },
    { id: 'debts', name: 'الديون', phase: 0, table: 'debt_people', label: 'شخص في دفتر الديون' },
    { id: 'files', name: 'الملفات', phase: 0, table: 'files', label: 'ملف' },
    { id: 'photos', name: 'الصور', phase: 0, table: 'photos', label: 'صورة' },
    { id: 'plan', name: 'جدولي', phase: 0, table: 'tasks', label: 'مهمة' },
    { id: 'kb', name: 'مكتبتي', phase: 0, table: 'notes', label: 'ملخص' },
    { id: 'links', name: 'الروابط', phase: 0, table: 'links', label: 'رابط' },
    { id: 'stats', name: 'الإحصائيات', phase: 0 }, { id: 'backup', name: 'النسخ الاحتياطي', phase: 0 },
    { id: 'settings', name: 'الإعدادات', phase: 0 },
  ];
  let current = 'home', timer = null;
  window.addEventListener('unhandledrejection', (e) => { if (e.reason && e.reason.locked) e.preventDefault(); }); // مهام خلفية انتهت بعد القفل
  V.pending = null;
  V.takePending = (sec) => { if (V.pending && V.pending.section === sec) { const id = V.pending.id; V.pending = null; return id; } return null; };
  V.nav = (sec, id) => { V.pending = { section: sec, id }; current = sec; render(); };

  function resetTimer() {
    clearTimeout(timer);
    const min = +pref('autolock', 5);
    if (min > 0 && auth.unlocked) timer = setTimeout(lockNow, min * 60000);
  }
  V.relock = () => lockNow();
  ['click', 'keydown', 'touchstart'].forEach((e) => document.addEventListener(e, resetTimer, { passive: true }));
  document.addEventListener('visibilitychange', () => { if (document.hidden && pref('lockhide', '1') === '1' && auth.unlocked) lockNow(); });
  function lockNow() { auth.lock(); V.Notify.clearTimers(); clearTimeout(timer); start(); }

  function gate(setup) {
    $app.innerHTML = `<div class="center"><form class="card" id="f" autocomplete="off">
      <h1 class="brand">AMMAR VAULT</h1><p class="sub">${setup ? 'أنشئ كلمة المرور الرئيسية لخزنتك' : 'أدخل كلمة المرور الرئيسية'}</p>
      <label for="p1">كلمة المرور</label><input id="p1" type="password" required autofocus>
      ${setup ? '<label for="p2">تأكيد كلمة المرور</label><input id="p2" type="password" required><p class="note">8 أحرف على الأقل. لا توجد طريقة لاستعادتها إن نسيتَها، فاحفظها جيداً.</p>' : ''}
      <button class="btn">${setup ? 'إنشاء الخزنة' : 'فتح الخزنة'}</button>${!setup && bioOn() ? '<button type="button" class="btn ghost" id="bio" style="width:100%;margin-top:.6rem">فتح بالبصمة</button>' : ''}<p class="err" id="e" role="alert"></p><p style="margin:.4rem 0 0"><button type="button" class="link" id="rs">استعادة من نسخة احتياطية</button></p></form></div>`;
    const f = document.getElementById('f'), e = document.getElementById('e');
    f.querySelector('#rs').onclick = () => V.BackupUI.restoreFlow({ store, afterRestore: () => lockNow() });
    const bio = f.querySelector('#bio');
    if (bio) { bio.onclick = async () => { e.textContent = '';
        try { await auth.unlockWithKey(await V.Native.secure.unlock()); current = 'home'; resetTimer(); render(); }
        catch (x) { const m = (x.code || '') + ' ' + (x.message || '');
          if (/CANCEL|USER_CANCEL/i.test(m)) return;
          if (/INVALIDATED/i.test(m) || x.arabic) { setPref('bio', '0'); try { await V.Native.secure.disable(); } catch (_) {} e.textContent = 'تغيّرت بصمات الجهاز أو المفتاح. استخدم كلمة المرور ثم فعّل البصمة من الإعدادات.'; }
          else e.textContent = 'تعذّر التحقق بالبصمة. استخدم كلمة المرور.'; } };
      setTimeout(() => bio.click(), 300); }
    f.onsubmit = async (ev) => {
      ev.preventDefault(); e.textContent = '';
      const p1 = f.p1.value; if (!setup) { const st = V.Attempts.status(); if (st.locked) { e.textContent = `محاولات خاطئة كثيرة. انتظر ${st.seconds} ثانية ثم أعد المحاولة.`; return; } } f.querySelector('.btn').disabled = true;
      try {
        if (setup) { if (p1 !== f.p2.value) throw { arabic: 'كلمتا المرور غير متطابقتين' }; await auth.setup(p1); }
        else { try { await auth.unlock(p1); V.Attempts.ok(); } catch (x) { V.Attempts.fail(); const st = V.Attempts.status(); if (st.locked) x.arabic = `${x.arabic} — انتظر ${st.seconds} ثانية قبل المحاولة التالية`; throw x; } }
        current = 'home'; resetTimer(); render();
      } catch (x) { e.textContent = x.arabic || 'تعذّر الفتح'; f.querySelector('.btn').disabled = false; }
    };
  }

  async function render() {
    if (!auth.unlocked) return;
    const nav = SECTIONS.map((s) => `<button class="nav" data-id="${s.id}" ${s.id === current ? 'aria-current="page"' : ''} ${s.phase ? 'disabled' : ''}>
      <span>${s.name}</span>${s.phase ? `<small>م${s.phase}</small>` : ''}</button>`).join('');
    $app.innerHTML = `<div class="shell"><nav class="side"><h1 class="brand">AMMAR VAULT</h1>${nav}</nav><main id="m"></main></div>`;
    $app.querySelectorAll('.nav:not([disabled])').forEach((b) => b.onclick = () => { current = b.dataset.id; render(); });
    const m = document.getElementById('m');
    if (current === 'home') {
      const stats = await Promise.all(SECTIONS.filter((s) => s.table).map(async (s) => `<div class="stat"><b>${await db.count(s.table)}</b><span>${s.label}</span></div>`));
      const al = V.DocsLogic.alerts(await db.all('documents'));
      const alHtml = al.length ? `<div class="panel wide"><b>تنبيهات الوثائق</b>${al.map((x) => `<p class="st-${x.st.state}" style="margin:.4rem 0">${esc(x.doc.title)} — ${V.DocsLogic.label(x.st)}</p>`).join('')}</div>` : '';
      m.innerHTML = `<h2>الرئيسية</h2><div id="gs"></div>${alHtml}<div class="grid">${stats.join('')}</div>
        <p class="note">الأقسام المعطّلة في القائمة ستُفعَّل في مراحلها (الرقم بجانب كل قسم). الأرقام أعلاه حقيقية وتبدأ من صفر.</p>`;
      V.Search.mount(m.querySelector('#gs'), { db, esc, nav: V.nav }); V.Notify.sync(await db.all('tasks'));
    } else if (V.Sections && V.Sections[current]) await V.Sections[current](m, { db, esc, auth, store });
    else settings(m);
  }

  function settings(m) {
    m.innerHTML = `<h2>الإعدادات</h2>
      <div class="panel"><div class="row"><button class="btn ghost" id="th">تبديل الوضع (داكن / فاتح)</button><button class="btn ghost" id="lk">قفل الآن</button></div>
        <label for="al">القفل التلقائي بعد (دقائق، 0 = معطّل)</label><input id="al" type="text" inputmode="numeric" value="${esc(pref('autolock', 5))}">
        <div class="row"><input type="checkbox" id="lh" ${pref('lockhide', '1') === '1' ? 'checked' : ''}><label for="lh" style="margin:0">القفل عند مغادرة التطبيق</label></div></div>
      <form class="panel" id="cp" autocomplete="off"><b>تغيير كلمة المرور الرئيسية</b>
        <label for="o">الحالية</label><input id="o" type="password" required>
        <label for="n">الجديدة</label><input id="n" type="password" required>
        <button class="btn">تغيير</button><p class="err" id="ce" role="alert"></p><p class="ok" id="cs"></p></form>${V.Native.isNative() ? '<div class="panel"><b>بصمة الإصبع</b><p class="note" id="bs"></p><div class="row"><button class="btn ghost" id="be">تفعيل</button><button class="btn ghost" id="bd">إيقاف</button></div></div>' : ''}`;
    if (V.Native.isNative()) {
      const st = m.querySelector('#bs');
      const refresh = async () => { const a = await V.Native.secure.available().catch(() => ({ available: false })); st.textContent = !a.available ? 'بصمة الإصبع غير متاحة (أضف بصمة من إعدادات النظام).' : bioOn() ? 'مفعّلة.' : 'غير مفعّلة.'; }; refresh();
      m.querySelector('#be').onclick = () => V.UI.dialog('تفعيل البصمة', '<p>أدخل كلمة المرور الرئيسية للتأكيد. تبقى كلمة المرور مطلوبة للاستعادة وعند تغيير بصمات الجهاز.</p><input name="pw" type="password" required autofocus>', { ok: 'تفعيل', onOk: async (f) => { await auth.verify(f.pw.value); await V.Native.secure.enable(await auth.exportKey()); setPref('bio', '1'); refresh(); } });
      m.querySelector('#bd').onclick = async () => { try { await V.Native.secure.disable(); } catch (e) {} setPref('bio', '0'); refresh(); };
    }
    m.querySelector('#th').onclick = () => { setPref('theme', pref('theme', 'dark') === 'dark' ? 'light' : 'dark'); applyTheme(); };
    m.querySelector('#lk').onclick = lockNow;
    m.querySelector('#al').onchange = (e) => { const v = Math.max(0, parseInt(e.target.value, 10) || 0); setPref('autolock', v); e.target.value = v; resetTimer(); };
    m.querySelector('#lh').onchange = (e) => setPref('lockhide', e.target.checked ? '1' : '0');
    m.querySelector('#cp').onsubmit = async (ev) => {
      ev.preventDefault(); const f = ev.target; f.ce.textContent = f.cs.textContent = '';
      try { await auth.changePassword(f.o.value, f.n.value); f.reset(); f.cs.textContent = 'تم تغيير كلمة المرور. بياناتك كما هي.'; }
      catch (x) { f.ce.textContent = x.arabic || 'تعذّر التغيير'; }
    };
  }

  async function start() {
    if (!window.crypto || !crypto.subtle) { $app.innerHTML = '<div class="center"><p class="card">هذا المتصفح لا يدعم التشفير. شغّل المشروع عبر localhost أو داخل التطبيق.</p></div>'; return; }
    gate(!(await auth.isSetup()));
  }
  start();
})();
