package com.ammar.vault;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;

/**
 * حفظ ملف عبر مستعرض ملفات Android الرسمي (Storage Access Framework، ACTION_CREATE_DOCUMENT):
 * يختار المستخدم المجلد (ذاكرة الهاتف أو فلاش USB) واسم الملف. تُكتب البيانات على دفعات،
 * وعند الانتهاء يُعاد قراءة الملف المحفوظ ويُرجَع SHA-256 له للمطابقة. غير مجرَّب على جهاز.
 */
@CapacitorPlugin(name = "AmmarFile")
public class AmmarFilePlugin extends Plugin {
  private OutputStream out;
  private Uri uri;

  private void closeQuietly() {
    try { if (out != null) out.close(); } catch (Exception ignored) {}
    out = null;
  }

  @PluginMethod
  public void begin(PluginCall call) {
    closeQuietly();
    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType(call.getString("mime", "application/octet-stream"));
    i.putExtra(Intent.EXTRA_TITLE, call.getString("name", "backup.avbak"));
    startActivityForResult(call, i, "onPicked");
  }

  @ActivityCallback
  private void onPicked(PluginCall call, ActivityResult result) {
    if (call == null) return;
    if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
      call.reject("CANCELLED", "CANCELLED");
      return;
    }
    try {
      uri = result.getData().getData();
      out = getContext().getContentResolver().openOutputStream(uri, "wt");
      JSObject o = new JSObject();
      String name = null;
      try (Cursor c = getContext().getContentResolver().query(uri, null, null, null, null)) {
        if (c != null && c.moveToFirst()) name = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME));
      } catch (Exception ignored) {}
      o.put("name", name);
      call.resolve(o);
    } catch (Exception e) { call.reject("OPEN_FAILED: " + e.getMessage()); }
  }

  @PluginMethod
  public void write(PluginCall call) {
    try {
      out.write(Base64.decode(call.getString("chunk"), Base64.NO_WRAP));
      call.resolve();
    } catch (Exception e) { call.reject("WRITE_FAILED: " + e.getMessage()); }
  }

  @PluginMethod
  public void finish(PluginCall call) {
    try {
      out.flush();
      out.close();
      out = null;
      MessageDigest md = MessageDigest.getInstance("SHA-256");
      long size = 0;
      try (InputStream in = getContext().getContentResolver().openInputStream(uri)) {
        byte[] buf = new byte[65536];
        int n;
        while ((n = in.read(buf)) > 0) { md.update(buf, 0, n); size += n; }
      }
      JSObject o = new JSObject();
      o.put("size", size);
      o.put("sha256", Base64.encodeToString(md.digest(), Base64.NO_WRAP));
      call.resolve(o);
    } catch (Exception e) { call.reject("FINISH_FAILED: " + e.getMessage()); }
  }

  @PluginMethod
  public void abort(PluginCall call) {
    closeQuietly();
    try { if (uri != null) DocumentsContract.deleteDocument(getContext().getContentResolver(), uri); } catch (Exception ignored) {}
    uri = null;
    call.resolve();
  }
}
