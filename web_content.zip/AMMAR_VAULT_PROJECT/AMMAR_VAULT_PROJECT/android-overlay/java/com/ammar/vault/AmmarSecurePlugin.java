package com.ammar.vault;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * بصمة الإصبع + Android Keystore. غير مجرَّب على جهاز.
 * يحفظ نسخة من مفتاح بيانات الخزنة مشفّرة بمفتاح داخل Keystore لا يُستخدم إلا بعد بصمة (لكل عملية).
 * يُبطَل المفتاح تلقائياً عند إضافة بصمة جديدة للجهاز. لا يُستخدم للاستعادة على هاتف آخر (تلك بكلمة المرور فقط).
 */
@CapacitorPlugin(name = "AmmarSecure")
public class AmmarSecurePlugin extends Plugin {
  private static final String KEYSTORE = "AndroidKeyStore";
  private static final String ALIAS = "ammar_vault_bio_key_v1";
  private static final String PREFS = "ammar_secure";
  private static final int AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG;

  private SharedPreferences prefs() {
    return getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
  }

  private void clear() throws Exception {
    KeyStore ks = KeyStore.getInstance(KEYSTORE);
    ks.load(null);
    if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS);
    prefs().edit().clear().apply();
  }

  private SecretKey key() throws Exception {
    KeyStore ks = KeyStore.getInstance(KEYSTORE);
    ks.load(null);
    return (SecretKey) ks.getKey(ALIAS, null);
  }

  private void createKey() throws Exception {
    KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
    KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
      .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
      .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
      .setKeySize(256)
      .setUserAuthenticationRequired(true)
      .setInvalidatedByBiometricEnrollment(true);
    if (Build.VERSION.SDK_INT >= 30) b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
    kg.init(b.build());
    kg.generateKey();
  }

  private void prompt(String title, Cipher cipher, BiometricPrompt.AuthenticationCallback cb) {
    getActivity().runOnUiThread(() -> {
      BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setSubtitle("AMMAR VAULT")
        .setNegativeButtonText("استخدم كلمة المرور")
        .setAllowedAuthenticators(AUTH)
        .build();
      new BiometricPrompt((FragmentActivity) getActivity(), ContextCompat.getMainExecutor(getContext()), cb)
        .authenticate(info, new BiometricPrompt.CryptoObject(cipher));
    });
  }

  private static String code(int err) {
    return (err == BiometricPrompt.ERROR_USER_CANCELED || err == BiometricPrompt.ERROR_NEGATIVE_BUTTON || err == BiometricPrompt.ERROR_CANCELED) ? "CANCELLED" : "AUTH_ERROR";
  }

  @PluginMethod
  public void isAvailable(PluginCall call) {
    JSObject o = new JSObject();
    o.put("available", BiometricManager.from(getContext()).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS);
    o.put("enrolled", prefs().contains("ct"));
    call.resolve(o);
  }

  @PluginMethod
  public void enable(PluginCall call) {
    final String secret = call.getString("secret");
    if (secret == null) { call.reject("secret required"); return; }
    try {
      clear();
      createKey();
      Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
      c.init(Cipher.ENCRYPT_MODE, key());
      prompt("تفعيل البصمة", c, new BiometricPrompt.AuthenticationCallback() {
        @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult r) {
          try {
            Cipher ci = r.getCryptoObject().getCipher();
            byte[] ct = ci.doFinal(Base64.decode(secret, Base64.NO_WRAP));
            prefs().edit().putString("ct", Base64.encodeToString(ct, Base64.NO_WRAP)).putString("iv", Base64.encodeToString(ci.getIV(), Base64.NO_WRAP)).apply();
            call.resolve();
          } catch (Exception e) { call.reject("ENCRYPT_FAILED: " + e.getMessage()); }
        }
        @Override public void onAuthenticationError(int errorCode, @NonNull CharSequence msg) {
          try { clear(); } catch (Exception ignored) {}
          call.reject(String.valueOf(msg), code(errorCode));
        }
      });
    } catch (Exception e) { call.reject("ENABLE_FAILED: " + e.getMessage()); }
  }

  @PluginMethod
  public void unlock(PluginCall call) {
    String ct = prefs().getString("ct", null), iv = prefs().getString("iv", null);
    if (ct == null || iv == null) { call.reject("NOT_ENABLED", "NOT_ENABLED"); return; }
    try {
      Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
      c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
      prompt("فتح الخزنة", c, new BiometricPrompt.AuthenticationCallback() {
        @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult r) {
          try {
            byte[] pt = r.getCryptoObject().getCipher().doFinal(Base64.decode(ct, Base64.NO_WRAP));
            JSObject o = new JSObject();
            o.put("secret", Base64.encodeToString(pt, Base64.NO_WRAP));
            call.resolve(o);
          } catch (Exception e) { call.reject("DECRYPT_FAILED: " + e.getMessage()); }
        }
        @Override public void onAuthenticationError(int errorCode, @NonNull CharSequence msg) {
          call.reject(String.valueOf(msg), code(errorCode));
        }
      });
    } catch (KeyPermanentlyInvalidatedException e) {
      try { clear(); } catch (Exception ignored) {}
      call.reject("INVALIDATED", "INVALIDATED");
    } catch (Exception e) { call.reject("UNLOCK_FAILED: " + e.getMessage()); }
  }

  @PluginMethod
  public void disable(PluginCall call) {
    try { clear(); call.resolve(); } catch (Exception e) { call.reject("DISABLE_FAILED: " + e.getMessage()); }
  }
}
