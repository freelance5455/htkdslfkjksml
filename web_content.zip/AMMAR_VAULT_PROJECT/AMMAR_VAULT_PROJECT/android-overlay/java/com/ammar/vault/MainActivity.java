package com.ammar.vault;

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(AmmarSecurePlugin.class);
    registerPlugin(AmmarFilePlugin.class);
    super.onCreate(savedInstanceState);
    // يمنع لقطات الشاشة ويخفي محتوى التطبيق في قائمة التطبيقات الأخيرة. احذف السطر التالي إن أردت السماح بلقطات الشاشة.
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
  }
}
