-- AMMAR VAULT: مخطط SQLite (يُنشأ تلقائياً في js/storage.js عند أول تشغيل على Android).
-- كل القيم مشفّرة أصلاً (AES-256-GCM) قبل الوصول إلى هذه الطبقة؛ العمود v يحوي JSON لنص مشفّر أو لكائن meta:auth.
-- مفاتيح k:  meta:auth | rec:<table>:<id> | blob:<id>
CREATE TABLE IF NOT EXISTS kv (
  k TEXT PRIMARY KEY NOT NULL,
  v TEXT NOT NULL
);
-- الجداول المنطقية (داخل المفتاح): documents, accounts, debt_people, debt_tx, folders, files, photos, albums, tasks, notes, links, pdf_index
