#!/usr/bin/env node
/* ينسخ ملفات التطبيق فقط (index.html, css, js, lib) إلى مجلد www الذي يقرأه Capacitor. الاستخدام: node scripts/build-www.js [المجلد الجذر] [المخرج] */
const fs = require('fs'), path = require('path');
const root = path.resolve(process.argv[2] || path.join(__dirname, '..')), out = path.resolve(process.argv[3] || path.join(root, 'www'));
fs.rmSync(out, { recursive: true, force: true }); fs.mkdirSync(out, { recursive: true });
let n = 0;
for (const item of ['index.html', 'css', 'js', 'lib']) { const src = path.join(root, item); if (!fs.existsSync(src)) { console.error('مفقود: ' + item); process.exit(1); } fs.cpSync(src, path.join(out, item), { recursive: true }); }
const html = fs.readFileSync(path.join(out, 'index.html'), 'utf8'); const missing = [...html.matchAll(/(?:src|href)="((?:js|css|lib)\/[^"]+)"/g)].map((m) => m[1]).filter((f) => !fs.existsSync(path.join(out, f)));
if (missing.length) { console.error('ملفات مذكورة في index.html وغير موجودة: ' + missing.join(', ')); process.exit(1); }
(function count(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) e.isDirectory() ? count(path.join(d, e.name)) : n++; })(out);
console.log(`تم: ${n} ملفاً في ${out}`);
