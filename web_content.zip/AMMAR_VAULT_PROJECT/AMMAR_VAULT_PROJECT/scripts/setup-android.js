#!/usr/bin/env node
/* يجهّز مشروع Android (بعد npm install و npx cap add android): ينسخ إضافات Java ويضبط الأذونات وAndroidManifest وbuild.gradle. آمن للتكرار.
   الاستخدام: node scripts/setup-android.js [المجلد الجذر] */
const fs = require('fs'), path = require('path'), cp = require('child_process');
const root = path.resolve(process.argv[2] || path.join(__dirname, '..')), cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
const android = path.join(root, 'android'); const log = []; const warn = [];
if (!fs.existsSync(android)) { console.log('لا يوجد مجلد android؛ تشغيل: npx cap add android'); const r = cp.spawnSync('npx', ['cap', 'add', 'android'], { cwd: root, stdio: 'inherit', shell: process.platform === 'win32' }); if (r.status !== 0) { console.error('فشل npx cap add android (تأكد من npm install والاتصال بالإنترنت لمرة واحدة).'); process.exit(1); } }
// 1) إضافات Java
const pkgDir = path.join(android, 'app/src/main/java', ...cfg.appId.split('.')); fs.mkdirSync(pkgDir, { recursive: true });
for (const f of ['MainActivity.java', 'AmmarSecurePlugin.java', 'AmmarFilePlugin.java']) {
  const src = fs.readFileSync(path.join(root, 'android-overlay/java/com/ammar/vault', f), 'utf8').replace(/^package com\.ammar\.vault;/m, `package ${cfg.appId};`);
  fs.writeFileSync(path.join(pkgDir, f), src); log.push('نُسخ ' + f);
}
// 2) AndroidManifest
const mf = path.join(android, 'app/src/main/AndroidManifest.xml'); let m = fs.readFileSync(mf, 'utf8');
for (const perm of ['USE_BIOMETRIC', 'POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED']) {
  if (!m.includes(`android.permission.${perm}"`)) { if (!m.includes('</manifest>')) { warn.push('لم أجد </manifest>'); break; } m = m.replace('</manifest>', `    <uses-permission android:name="android.permission.${perm}" />\n</manifest>`); log.push('أُضيف إذن ' + perm); }
}
if (/android:allowBackup="true"/.test(m)) { m = m.replace('android:allowBackup="true"', 'android:allowBackup="false"'); log.push('allowBackup=false (لا نسخ سحابي من أندرويد)'); } else if (!/android:allowBackup="false"/.test(m)) warn.push('تحقق يدوياً من android:allowBackup="false" في AndroidManifest.xml');
fs.writeFileSync(mf, m);
// 3) build.gradle: androidx.biometric
const gf = path.join(android, 'app/build.gradle'); let g = fs.readFileSync(gf, 'utf8');
if (!g.includes('androidx.biometric:biometric')) { if (/dependencies\s*\{/.test(g)) { g = g.replace(/dependencies\s*\{/, (x) => `${x}\n    implementation 'androidx.biometric:biometric:1.1.0'`); log.push('أُضيفت مكتبة androidx.biometric'); } else warn.push('لم أجد dependencies في app/build.gradle؛ أضف implementation \'androidx.biometric:biometric:1.1.0\' يدوياً'); }
fs.writeFileSync(gf, g);
console.log(log.join('\n') || 'لا تغييرات (مُجهَّز مسبقاً)'); if (warn.length) console.warn('\nتنبيهات:\n- ' + warn.join('\n- '));
