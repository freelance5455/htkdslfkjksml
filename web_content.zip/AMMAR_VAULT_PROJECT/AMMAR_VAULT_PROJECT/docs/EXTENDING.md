# تعديل المشروع وإضافة أقسام جديدة

## البنية
- `js/crypto.js` التشفير · `js/storage.js` محوّلات التخزين · `js/auth.js` كلمة المرور · `js/db.js` السجلات المشفّرة.
- كل قسم = ملف منطق `xxx-logic.js` (بلا DOM، قابل للاختبار) + ملف واجهة `xxx.js` يسجّل `Vault.Sections.<id>`.
- `js/app.js` القائمة (`SECTIONS`) والقفل والصفحة الرئيسية. `js/backup.js` النسخ الاحتياطي (منطق) و`js/backup-ui.js` (واجهة + الإحصائيات).

## إضافة قسم جديد (مثال: «المشاريع»)
1. **المنطق**: `js/projects-logic.js` يصدّر `Vault.ProjectsLogic = { validate, search, ... }` ثم اختبره في `tests/run.js`.
2. **الواجهة**: `js/projects.js`:
       Vault.Sections.projects = async function (m, { db, esc, auth, store }) {
         const all = await db.all('projects');         // الجدول يُنشأ تلقائياً عند أول db.put('projects', {...})
         m.innerHTML = '<h2>المشاريع</h2>…';
       };
   استعمل `db.put/get/all/remove/count` فتُشفَّر السجلات وتدخل النسخ الاحتياطي تلقائياً. المرفقات: `db.putBlob/getBlob/removeBlob`.
   اسم الجدول: حروف إنجليزية صغيرة و`_` فقط (شرط في تحقق الاستعادة).
3. **القائمة**: أضف إلى `SECTIONS` في `js/app.js`: `{ id: 'projects', name: 'المشاريع', phase: 0, table: 'projects', label: 'مشروع' }` (وجود `table` يضيف عدّاداً للصفحة الرئيسية).
4. **index.html**: أضف وسمَي `<script>` للملفين قبل `js/app.js`.
5. **البحث الشامل**: أضف عنصراً إلى `SOURCES` في `js/search-logic.js`: `{ table:'projects', type:'مشروع', section:'projects', title:r=>r.name, text:r=>[r.notes].join(' ') }`. لا تُضف أبداً حقول كلمات المرور.
6. **فتح النتيجة مباشرة**: في آخر قسمك: `const pid = Vault.takePending('projects'); pid ? openForm(pid) : list();`
7. **الإحصائيات**: أضف العدّاد في `js/stats-logic.js` و`js/backup-ui.js` (قسم stats).
8. **الاختبار**: أضف اختبارات المنطق إلى `tests/run.js`، ثم `node tests/run.js` و`node tests/e2e.js`.

## قواعد يجب احترامها
- لا تخزّن شيئاً حساساً خارج `db.put` (لا localStorage) إلا الإعدادات غير الحساسة.
- كل نص يُدرج في HTML يمر عبر `esc()`.
- لتغيير التخزين اكتب محوّلاً بواجهة `get/set/del/keys(prefix)/clear` في `js/storage.js`.
- عند تغيير شكل السجلات القديمة اكتب ترحيلاً داخل القسم؛ النسخ الاحتياطية القديمة تحمل الشكل القديم.
