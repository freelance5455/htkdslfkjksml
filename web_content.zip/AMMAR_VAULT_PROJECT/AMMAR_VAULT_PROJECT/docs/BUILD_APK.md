# تحويل AMMAR VAULT إلى تطبيق Android (APK)

> **تنبيه صريح:** كل ما يخص Android في هذا المشروع (إضافات Java، SQLite الأصلي، البصمة، Keystore، الإشعارات، الحفظ عبر مستعرض الملفات) **كُتب دون إمكانية بنائه أو تشغيله على جهاز** في بيئة التطوير. منطق JavaScript اختُبر (بما فيه محوّل SQLite على SQLite حقيقي عبر مُحاكٍ لواجهة الإضافة)، أما ملفات Java فلم تُصرَّف حتى. توقّع إصلاح أخطاء صغيرة عند أول بناء، واتبع قائمة الفحص أدناه.

## المتطلبات (على حاسوبك، تحتاج إنترنت مرة واحدة)
Node.js 18+ · JDK 17 · Android Studio (مع Android SDK) · هاتف Android بنظام 8+ (يُفضَّل 11+) مع بصمة مسجّلة.

## الخطوات
    cd AMMAR_VAULT_PROJECT
    npm install --save @capacitor/core @capacitor/android @capacitor/local-notifications @capacitor-community/sqlite
    npm install --save-dev @capacitor/cli
    node scripts/build-www.js          # ينسخ التطبيق إلى www/
    node scripts/setup-android.js      # يشغّل cap add android إن لزم، ثم ينسخ إضافات Java ويضبط الأذونات وbuild.gradle
    npx cap sync android               # يجلب الإضافات الأصلية ويحدّث www
    npx cap open android               # يفتح Android Studio

في Android Studio: **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)** ثم الملف في
`android/app/build/outputs/apk/debug/app-debug.apk`. أو من الطرفية: `cd android && ./gradlew assembleDebug`.
للتوزيع: **Build ▸ Generate Signed Bundle / APK** وأنشئ مفتاح توقيع واحفظه وكلمته في مكان آمن (بدونه لا يمكنك تحديث التطبيق).
بعد أي تعديل على ملفات الويب: `npm run android:sync`.

## ما يفعله سكربت الإعداد
- ينسخ `MainActivity` و`AmmarSecurePlugin` (بصمة + Keystore) و`AmmarFilePlugin` (حفظ عبر مستعرض الملفات) إلى حزمة التطبيق.
- يضيف أذونات: USE_BIOMETRIC، POST_NOTIFICATIONS، SCHEDULE_EXACT_ALARM، RECEIVE_BOOT_COMPLETED.
- يضبط `android:allowBackup="false"` حتى لا يُرسل أندرويد بيانات التطبيق إلى نسخ سحابي.
- يضيف `androidx.biometric:biometric:1.1.0`.
- `MainActivity` يفعّل `FLAG_SECURE` (يمنع لقطات الشاشة ويحجب التطبيق في قائمة التطبيقات الأخيرة). احذف سطره إن لم تُرده.

## كيف يعمل (للمراجعة)
| الجانب | الحل |
|---|---|
| التخزين | `js/storage.js`: محوّل `sqlite` يستعمل `CapacitorSQLite` (جدول `kv(k,v)`، القيم JSON). القيم مشفّرة أصلاً بمفتاح البيانات، فلا حاجة لـSQLCipher. |
| البصمة | `AmmarSecurePlugin`: مفتاح AES-256-GCM في Android Keystore يتطلب بصمة لكل استعمال ويُبطَل عند إضافة بصمة جديدة، يحمي نسخة من مفتاح البيانات. كلمة المرور تبقى مطلوبة للاستعادة. |
| الإشعارات | `js/notify.js` يجدول حتى 60 إشعاراً (30 يوماً) عبر `LocalNotifications` مع `allowWhileIdle`، ويُعاد الجدولة كلما فُتح التطبيق أو عُدّلت مهمة. |
| حفظ النسخة | `AmmarFilePlugin` يفتح `ACTION_CREATE_DOCUMENT` (مستعرض الملفات الرسمي، يشمل فلاش USB)، يكتب على دفعات 512KB، ثم يعيد قراءة الملف ويرجع SHA-256 للمطابقة. |
| الاستعادة | حقل اختيار الملف يفتح مستعرض النظام تلقائياً؛ يعمل من أي مسار. |
| إبطاء المحاولات | `js/attempts.js`: بعد 4 محاولات خاطئة تأخير 30ث ثم 60ث…ساعة. |

## قائمة فحص على الجهاز (لم تُنفَّذ — افحصها بنفسك)
1. التثبيت والتشغيل، إنشاء الخزنة، إغلاق التطبيق تماماً ثم الفتح: البيانات باقية (SQLite).
2. إضافة وثيقة بصورة وملف PDF وإعادة فتح التطبيق: تظهر وتُعرض.
3. الإعدادات ▸ تفعيل البصمة ▸ قفل ▸ فتح بالبصمة. ثم أضف بصمة جديدة في إعدادات النظام: يجب أن يرفض ويطلب كلمة المرور.
4. مهمة بتنبيه بعد دقيقتين وأغلق التطبيق: يصل الإشعار. على Android 12+ فعّل «المنبهات والتذكيرات» للتطبيق، وعلى 13+ اسمح بالإشعارات. بعض الشركات (Xiaomi، Huawei، Samsung) تقتل التطبيقات في الخلفية: استثنِ التطبيق من توفير البطارية.
5. النسخ الاحتياطي ▸ حفظ ▸ اختر مجلداً على الهاتف، ثم كرّر على فلاش USB (OTG). تأكد من ظهور الملف وحجمه.
6. على هاتف آخر (أو بعد حذف التطبيق): أنشئ خزنة جديدة ◂ «استعادة من نسخة احتياطية» ◂ اختر الملف وكلمة المرور.
7. ملف كبير (10–20MB) ثم نسخة احتياطية: راقب الذاكرة. الحد الأقصى للملف الواحد على Android 20MB حتى تُختبر الحدود (يُعدَّل في `js/native.js`).
8. تحقق أن البحث داخل PDF يعمل (pdf.js يحتاج WebView حديثاً؛ حدّث Android System WebView).

## إن فشل شيء
- خطأ تصريف Java: أرسل نص الخطأ؛ الملفات في `android-overlay/` ويعاد نسخها بتشغيل `node scripts/setup-android.js`.
- «plugin not implemented» لـ `CapacitorSQLite`/`AmmarSecure`/`AmmarFile`: تأكد من `npx cap sync android` ومن تسجيل الإضافتين في `MainActivity`.
- أسماء دوال إضافة SQLite (`createConnection/open/execute/run/query`) كُتبت من التوثيق ولم تُجرَّب؛ عدّلها في `js/storage.js` (دالة `sqliteAdapter`) إن اختلفت في الإصدار المثبّت.
