/* يولّد ملفات اختبار مؤقتة (صور PNG، نص، ملف ثنائي 8MB) في مجلد مؤقت. */
const zlib = require('zlib'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const crc = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) { c ^= b[i]; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1; } return (c ^ 0xffffffff) >>> 0; };
const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
const png = (w, h, rgb) => { const raw = Buffer.alloc((w * 3 + 1) * h); for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) raw.set(rgb, y * (w * 3 + 1) + 1 + x * 3);
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2; return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]); };
module.exports = (dir) => { fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'red.png'), png(300, 200, [200, 30, 30])); fs.writeFileSync(path.join(dir, 'blue.png'), png(120, 120, [30, 60, 200]));
  fs.writeFileSync(path.join(dir, 'note.txt'), 'ملاحظة اختبار: Hello secret-needle-42'); fs.writeFileSync(path.join(dir, 'big.bin'), crypto.randomBytes(8 * 1024 * 1024)); return dir; };
if (require.main === module) console.log(module.exports(process.argv[2] || path.join(require('os').tmpdir(), 'avvault-fixtures')));
