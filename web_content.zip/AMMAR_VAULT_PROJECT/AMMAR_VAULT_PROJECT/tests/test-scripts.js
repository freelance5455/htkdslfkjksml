/* يختبر سكربتات البناء على مشروع Android وهمي (دون Android SDK): النسخ، الترقيع، وعدم التكرار. */
const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process'), assert = require('assert');
const proj = path.join(__dirname, '..'), tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'avt-'));
for (const f of ['scripts', 'android-overlay', 'capacitor.config.json']) fs.cpSync(path.join(proj, f), path.join(tmp, f), { recursive: true });
fs.mkdirSync(path.join(tmp, 'android/app/src/main'), { recursive: true });
fs.writeFileSync(path.join(tmp, 'android/app/src/main/AndroidManifest.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n    <application android:allowBackup="true" android:label="x">\n    </application>\n    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>\n');
fs.writeFileSync(path.join(tmp, 'android/app/build.gradle'), "apply plugin: 'com.android.application'\nandroid { namespace 'com.ammar.vault' }\ndependencies {\n    implementation fileTree(dir: 'libs', include: ['*.jar'])\n}\n");
const run = () => cp.execFileSync('node', [path.join(tmp, 'scripts/setup-android.js'), tmp], { encoding: 'utf8' });
const out1 = run(); const mf = () => fs.readFileSync(path.join(tmp, 'android/app/src/main/AndroidManifest.xml'), 'utf8'), gr = () => fs.readFileSync(path.join(tmp, 'android/app/build.gradle'), 'utf8');
for (const p of ['USE_BIOMETRIC', 'POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED']) assert.strictEqual(mf().split(`android.permission.${p}"`).length - 1, 1, p);
assert(mf().includes('allowBackup="false"') && !mf().includes('allowBackup="true"')); assert(gr().includes("androidx.biometric:biometric:1.1.0")); assert(out1.includes('MainActivity'));
const j = path.join(tmp, 'android/app/src/main/java/com/ammar/vault'); for (const f of ['MainActivity', 'AmmarSecurePlugin', 'AmmarFilePlugin']) assert(fs.readFileSync(path.join(j, f + '.java'), 'utf8').startsWith('package com.ammar.vault;'));
const m1 = mf(), g1 = gr(); run(); assert.strictEqual(mf(), m1); assert.strictEqual(gr(), g1); console.log('✔ setup-android: ينسخ الإضافات ويضيف الأذونات ومكتبة البصمة ويعطّل allowBackup، وتكراره لا يغيّر شيئاً');
const www = path.join(tmp, 'www'); const o = cp.execFileSync('node', [path.join(proj, 'scripts/build-www.js'), proj, www], { encoding: 'utf8' });
for (const f of ['index.html', 'js/app.js', 'css/style.css', 'lib/pdfjs/pdf.min.js', 'lib/pdfjs/pdf.worker.min.js', 'lib/jszip/jszip.min.js']) assert(fs.existsSync(path.join(www, f)), f);
assert(!fs.existsSync(path.join(www, 'tests')) && !fs.existsSync(path.join(www, 'android-overlay'))); console.log('✔ build-www: ' + o.trim());
fs.rmSync(tmp, { recursive: true, force: true });
// ---- يعمل دون إنترنت: لا طلبات شبكة ولا موارد خارجية في كود التطبيق ----
(function () {
  const fs = require('fs'), path = require('path'), root = path.join(__dirname, '..'); const bad = [];
  const files = fs.readdirSync(path.join(root, 'js')).map((f) => 'js/' + f).concat(['index.html', 'css/style.css']);
  for (const f of files) { const s = fs.readFileSync(path.join(root, f), 'utf8');
    if (/\bfetch\s*\(|XMLHttpRequest|WebSocket\s*\(|navigator\.sendBeacon|importScripts\(\s*['"]https?:/.test(s)) bad.push(f + ': طلب شبكة');
    if (/(?:src|href)\s*=\s*["']https?:\/\//.test(s) || /url\(\s*['"]?https?:/.test(s) || /@import\s+url\(\s*['"]?https?:/.test(s)) bad.push(f + ': مورد خارجي'); }
  assert.deepStrictEqual(bad, []); console.log('✔ دون إنترنت: لا fetch ولا XHR ولا موارد خارجية في ' + files.length + ' ملفاً');
})();
