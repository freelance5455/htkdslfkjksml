const assert = require('assert');
require('../js/crypto.js'); require('../js/storage.js'); require('../js/auth.js'); require('../js/db.js');
const V = globalThis.Vault;
let n = 0; const ok = (name) => console.log('✔', ++n, name);
(async () => {
  const store = V.Storage.memory(), auth = V.Auth(store), db = V.DB(store, auth);
  assert.strictEqual(await auth.isSetup(), false); ok('الخزنة جديدة');
  await assert.rejects(auth.setup('123'), /8 أحرف/); ok('رفض كلمة مرور قصيرة');
  await auth.setup('كلمة-سر-قوية-1'); assert(auth.unlocked); ok('إعداد الخزنة');
  const rec = await db.put('accounts', { site: 'example', password: 'SECRET-XYZ' });
  assert.strictEqual((await db.get('accounts', rec.id)).password, 'SECRET-XYZ'); ok('حفظ وقراءة سجل');
  const raw = await store.get(`rec:accounts:${rec.id}`);
  assert(!raw.includes('SECRET-XYZ') && !raw.includes('example')); ok('السجل مشفّر في التخزين');
  auth.lock(); assert(!auth.unlocked); ok('القفل');
  await assert.rejects(auth.unlock('خطأ-خطأ-خطأ'), /غير صحيحة/); assert(!auth.unlocked); ok('رفض كلمة مرور خاطئة');
  await auth.unlock('كلمة-سر-قوية-1'); assert.strictEqual(await db.count('accounts'), 1); ok('فتح بكلمة صحيحة');
  await auth.changePassword('كلمة-سر-قوية-1', 'جديدة-جديدة-2'); auth.lock();
  await assert.rejects(auth.unlock('كلمة-سر-قوية-1')); ok('القديمة لا تعمل بعد التغيير');
  await auth.unlock('جديدة-جديدة-2');
  assert.strictEqual((await db.all('accounts'))[0].password, 'SECRET-XYZ'); ok('البيانات سليمة بعد تغيير كلمة المرور');
  const s2 = V.Storage.memory(); for (const x of await store.keys('')) await s2.set(x, await store.get(x));
  const a2 = V.Auth(s2); await a2.unlock('جديدة-جديدة-2'); ok('الاستعادة بكلمة المرور فقط على مخزن جديد');
  await db.remove('accounts', rec.id); assert.strictEqual(await db.count('accounts'), 0); ok('حذف سجل');
  console.log('\nكل الاختبارات نجحت:', n);
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });
// ---- المرحلة 4: منطق الوثائق والمرفقات ----
require('../js/docs-logic.js');
(async () => {
  const L = globalThis.Vault.DocsLogic, assert = require('assert');
  const now = new Date('2026-11-20T10:00:00').getTime();
  assert.strictEqual(L.status({ expiryDate: '2026-11-19' }, now).state, 'expired');
  assert.strictEqual(L.status({ expiryDate: '2026-11-20' }, now).days, 0);
  assert.strictEqual(L.status({ expiryDate: '2026-12-10', alertDays: 30 }, now).state, 'soon');
  assert.strictEqual(L.status({ expiryDate: '2026-12-10', alertDays: 10 }, now).state, 'valid');
  assert.strictEqual(L.status({}, now).state, 'none');
  console.log('✔ حالات الصلاحية');
  assert.strictEqual(L.alerts([{ title: 'a', expiryDate: '2027-12-01' }, { title: 'b', expiryDate: '2026-11-25' }, { title: 'c', expiryDate: '2026-10-01' }], now).map((x) => x.doc.title).join(), 'c,b');
  console.log('✔ التنبيهات مرتبة (المنتهية ثم الأقرب)');
  assert(L.validate({ title: '' })); assert(L.validate({ title: 'x', issueDate: '2026-05-01', expiryDate: '2026-01-01' })); assert.strictEqual(L.validate({ title: 'x' }), null);
  console.log('✔ التحقق من المدخلات');
  const V = globalThis.Vault, s = V.Storage.memory(), a = V.Auth(s), db = V.DB(s, a); await a.setup('كلمة-سر-قوية-1');
  const bytes = new Uint8Array(300000).map((_, i) => i % 251);
  const id = await db.putBlob({ name: 'جواز.pdf', type: 'application/pdf', bytes });
  const back = await db.getBlob(id); assert.deepStrictEqual(Buffer.from(back.bytes), Buffer.from(bytes)); assert.strictEqual(back.name, 'جواز.pdf');
  assert(!(await s.get('blob:' + id)).includes('جواز')); console.log('✔ مرفق 300KB: مشفّر ويُستعاد بايتاً ببايت');
  await db.removeBlob(id); assert.strictEqual(await db.getBlob(id), null); console.log('✔ حذف المرفق');
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });
// ---- المرحلة 5: مدير كلمات المرور ----
require('../js/pass-logic.js');
(async () => {
  const V = globalThis.Vault, L = V.PassLogic, assert = require('assert');
  const list = [{ site: 'Gmail', username: 'ammar', email: 'a@x.com', password: 'PW-SECRET', category: 'بريد إلكتروني' },
    { site: 'فيسبوك', username: 'am123', password: 'zzz', category: 'تواصل اجتماعي' }];
  assert.strictEqual(L.search(list, 'gma').length, 1); assert.strictEqual(L.search(list, 'am123')[0].site, 'فيسبوك');
  assert.strictEqual(L.search(list, 'a@x').length, 1); assert.strictEqual(L.search(list, 'PW-SECRET').length, 0);
  assert.strictEqual(L.search(list, '', 'بريد إلكتروني').length, 1); assert.strictEqual(L.search(list, '').length, 2);
  console.log('✔ بحث الحسابات (التطبيق/المستخدم/البريد/التصنيف) ولا يبحث في كلمة المرور');
  assert(L.validate({ site: '', password: 'x' })); assert(L.validate({ site: 'a', password: '' })); assert(L.validate({ site: 'a', password: 'x', email: 'bad' }));
  assert.strictEqual(L.validate({ site: 'a', password: 'x', email: 'a@b.co' }), null); console.log('✔ التحقق من مدخلات الحساب');
  const s = V.Storage.memory(), a = V.Auth(s), db = V.DB(s, a); await a.setup('كلمة-سر-قوية-1');
  assert(!a.recentlyVerified(1000)); await assert.rejects(a.verify('خطأ-خطأ-خطأ'), /غير صحيحة/); assert(!a.recentlyVerified(1000));
  await a.verify('كلمة-سر-قوية-1'); assert(a.recentlyVerified(1000)); assert(a.unlocked); console.log('✔ إعادة التحقق تعمل وترفض الخاطئة');
  a.lock(); await a.unlock('كلمة-سر-قوية-1'); assert(!a.recentlyVerified(1000)); console.log('✔ القفل يُلغي التحقق السابق');
  const r = await db.put('accounts', list[0]); const raw = await s.get(`rec:accounts:${r.id}`);
  assert(!raw.includes('PW-SECRET') && !raw.includes('Gmail')); console.log('✔ كلمة المرور المحفوظة غير مقروءة في التخزين');
  await db.put('accounts', { ...r, password: 'NEW' }); assert.strictEqual((await db.get('accounts', r.id)).password, 'NEW'); assert.strictEqual(await db.count('accounts'), 1);
  await db.remove('accounts', r.id); assert.strictEqual(await db.count('accounts'), 0); console.log('✔ تعديل ثم حذف');
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });
// ---- المرحلة 6: دفتر الديون ----
require('../js/debts-logic.js');
(async () => {
  const V = globalThis.Vault, L = V.DebtsLogic, assert = require('assert');
  const tx = (personId, kind, amount, date) => ({ personId, kind, amount, date, createdAt: 1 });
  let s = L.summarize([tx('a', 'debt', 0.1, '2026-01-01'), tx('a', 'debt', 0.2, '2026-01-02')]); assert.strictEqual(s.original, 30);
  console.log('✔ دقة الكسور (0.1+0.2=0.30)');
  s = L.summarize([tx('a', 'debt', 1000, '2026-01-01'), tx('a', 'payment', 400, '2026-02-01')]);
  assert.deepStrictEqual([s.original, s.paid, s.remaining, s.status], [100000, 40000, 60000, 'open']); console.log('✔ سداد جزئي: الأصلي/المسدد/المتبقي');
  s = L.summarize([tx('a', 'debt', 1000, 'x'), tx('a', 'payment', 400, 'x'), tx('a', 'payment', 600, 'x')]); assert.strictEqual(s.status, 'settled'); assert.strictEqual(s.remaining, 0);
  console.log('✔ السداد الكامل ⇒ الحالة «مسدد» والرصيد صفر'); assert.strictEqual(L.summarize([]).status, 'empty');
  assert(L.validateTx(tx('a', 'payment', 700, '2026-01-01'), 60000).includes('أكبر من المتبقي')); assert(L.validateTx(tx('a', 'debt', 0, '2026-01-01'), 0)); assert(L.validateTx(tx('a', 'debt', 5, ''), 0));
  assert.strictEqual(L.validateTx(tx('a', 'payment', 600, '2026-01-01'), 60000), null); assert.strictEqual(L.validateTx(tx('a', 'debt', 5, '2026-01-01'), 0), null);
  console.log('✔ رفض سداد يزيد عن المتبقي، ومبلغ صفر، وتاريخ ناقص');
  const people = [{ id: 'a' }, { id: 'b' }, { id: 'c' }];
  const all = [tx('a', 'debt', 1000, 'x'), tx('a', 'payment', 400, 'x'), tx('b', 'debt', 200, 'x'), tx('b', 'payment', 200, 'x'), tx('c', 'debt', 50, 'x')];
  const T = L.totals(people, all); assert.deepStrictEqual(T, { outstanding: 65000, paid: 60000, debtors: 2, settled: 1, open: 2 }); console.log('✔ إحصائيات الدفتر (المستحق/المسدد/المدينون/المسددة/المتبقية)');
  const h = L.history([tx('a', 'debt', 1, '2026-01-01'), tx('a', 'payment', 1, '2026-03-01')]); assert.strictEqual(h[0].kind, 'payment'); console.log('✔ السجل مرتب من الأحدث');
  const st = V.Storage.memory(), a = V.Auth(st), db = V.DB(st, a); await a.setup('كلمة-سر-قوية-1');
  const p = await db.put('debt_people', { name: 'خالد', phone: '777' }); const d = await db.put('debt_tx', tx(p.id, 'debt', 500, '2026-01-01'));
  assert(!(await st.get(`rec:debt_tx:${d.id}`)).includes('500')); assert(!(await st.get(`rec:debt_people:${p.id}`)).includes('خالد')); console.log('✔ الأسماء والمبالغ مشفّرة في التخزين');
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });
// ---- المرحلة 7: الملفات والصور ----
require('../js/files-logic.js');
(async () => {
  const V = globalThis.Vault, L = V.FilesLogic, assert = require('assert');
  const fo = [{ id: 'a', name: 'جامعة', parentId: null }, { id: 'b', name: 'سنة أولى', parentId: 'a' }, { id: 'c', name: 'شخصي', parentId: null }];
  assert.strictEqual(L.path(fo, 'b'), 'جامعة / سنة أولى'); assert.strictEqual(L.childFolders(fo, null).length, 2); assert.strictEqual(L.breadcrumbs(fo, null).length, 0);
  console.log('✔ المجلدات: المسار والأبناء');
  assert(L.validateName('', [])); assert(L.validateName('a/b', [])); assert(L.validateName('Report', ['report'])); assert.strictEqual(L.validateName('جديد', ['قديم']), null);
  assert.strictEqual(L.uniqueName('a.pdf', ['a.pdf', 'a (2).pdf']), 'a (3).pdf'); assert.strictEqual(L.uniqueName('x', []), 'x'); console.log('✔ أسماء الملفات: التحقق وعدم التكرار');
  const files = [{ id: 'f1', name: 'عقد.pdf', description: 'عقد الإيجار', folderId: 'c' }];
  assert(!L.folderEmpty(fo, files, 'c')); assert(!L.folderEmpty(fo, files, 'a')); assert(L.folderEmpty(fo, files, 'b')); console.log('✔ لا يُحذف مجلد غير فارغ');
  assert.strictEqual(L.searchFiles(files, 'إيجار').length, 1); assert.strictEqual(L.searchFiles(files, 'xyz').length, 0); console.log('✔ البحث في اسم الملف ووصفه');
  assert.deepStrictEqual(['a.PDF', 'x.txt', 'y.docx'].map((n, i) => L.kindOf(i === 1 ? 'text/plain' : '', n)), ['pdf', 'text', 'other']); assert.strictEqual(L.kindOf('image/png', 'p'), 'image'); console.log('✔ تحديد نوع المعاينة');
  const albums = [{ id: 'al', name: 'رحلة عدن' }], ph = [{ id: '1', name: 'شاطئ', albumId: 'al', category: 'سفر', description: '', createdAt: 2 }, { id: '2', name: 'بطاقة', albumId: null, category: 'وثائق', description: 'أمامية', createdAt: 1 }];
  assert.strictEqual(L.searchPhotos(ph, albums, 'عدن', '').length, 1); assert.strictEqual(L.searchPhotos(ph, albums, '', 'none')[0].id, '2'); assert.strictEqual(L.searchPhotos(ph, albums, 'أمامية', '')[0].id, '2'); console.log('✔ بحث الصور (اسم/وصف/تصنيف/ألبوم) وتصفية الألبوم');
  const s = V.Storage.memory(), a = V.Auth(s), db = V.DB(s, a); await a.setup('كلمة-سر-قوية-1');
  const big = new Uint8Array(5 * 1024 * 1024).map((_, i) => (i * 7) % 256); const id = await db.putBlob({ name: 'k.zip', type: 'application/zip', bytes: big });
  assert.deepStrictEqual(Buffer.from((await db.getBlob(id)).bytes), Buffer.from(big)); console.log('✔ ملف 5MB: تشفير واستعادة مطابقة بايتاً ببايت');
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });
// ---- المراحل 8-10: البحث، الجدول، المكتبة ----
require('../js/search-logic.js'); require('../js/pdf-text.js'); require('../js/plan-logic.js'); require('../js/kb-logic.js');
(async () => {
  const V = globalThis.Vault, S = V.SearchLogic, assert = require('assert'), zlib = require('zlib');
  // 8: البحث الشامل
  assert.strictEqual(S.norm('أَحْمَد إبراهيم ١٢٣').n, 'احمد ابراهيم 123'); assert.strictEqual(S.norm('مدرسة').n, 'مدرسه'); console.log('✔ توحيد النص العربي (همزات/تشكيل/تاء مربوطة/أرقام)');
  const data = { documents: [{ id: 'd1', title: 'بطاقة شخصية', type: 'بطاقة شخصية', notes: '' }, { id: 'd2', title: 'بطاقة العمل', type: 'بطاقة وظيفية' }, { id: 'd3', title: 'شهادة بكالوريوس', type: 'شهادة' }],
    accounts: [{ id: 'a1', site: 'Gmail', username: 'ammar', password: 'TOPSECRET' }], notes: [{ id: 'n1', title: 'ملخص SQL', content: 'عبارة JOIN تربط الجداول ببعضها وهذا شرح مطوّل للدرس', keywords: ['قواعد'] }], tasks: [{ id: 't1', title: 'مذاكرة البرمجة' }] };
  const idx = [{ section: 'files', srcId: 'f9', name: 'عقد.pdf', text: 'Contract between parties effective January' }];
  const E = S.buildEntries(data, idx);
  assert.deepStrictEqual(S.search(E, 'بطاقه').map((r) => r.entry.id).sort(), ['d1', 'd2']); assert.strictEqual(S.search(E, 'شهاده')[0].entry.id, 'd3'); console.log('✔ «بطاقة» تُظهر كل البطاقات و«شهادة» كل الشهادات');
  const r = S.search(E, 'join الجداول'); assert.strictEqual(r[0].entry.id, 'n1'); assert(r[0].snippet.includes('JOIN')); console.log('✔ البحث داخل محتوى الملخص مع مقتطف');
  const p = S.search(E, 'effective january'); assert.strictEqual(p[0].entry.type, 'محتوى PDF'); assert.strictEqual(p[0].entry.section, 'files'); console.log('✔ البحث داخل نص PDF المفهرس');
  assert.strictEqual(S.search(E, 'TOPSECRET').length, 0); console.log('✔ كلمات المرور لا تُفهرس ولا تظهر في البحث');
  // مستخرج PDF
  const content = 'BT /F1 12 Tf 72 700 Td (Invoice number 4471 for AMMAR) Tj T* (Total \\(USD\\) 250) Tj ET';
  const pdf = Buffer.concat([Buffer.from('%PDF-1.4\n1 0 obj\n<< /Filter /FlateDecode /Length 99 >>\nstream\n', 'latin1'), zlib.deflateSync(Buffer.from(content, 'latin1')), Buffer.from('\nendstream\nendobj\n%%EOF', 'latin1')]);
  const ex = await V.PdfText.extractSimple(new Uint8Array(pdf)); assert(ex.ok && ex.text.includes('Invoice number 4471') && ex.text.includes('Total (USD) 250')); console.log('✔ استخراج نص PDF بسيط (Flate)');
  const bad = await V.PdfText.extractSimple(new Uint8Array(Buffer.from('%PDF-1.4 no text here'))); assert(!bad.ok && bad.reason); console.log('✔ PDF بلا نص ⇒ يُعلَن عدم الدعم بدل نتائج مضلّلة');
  // 9: الجدول
  const P = V.PlanLogic, sat = '2026-11-21'; // سبت
  assert.strictEqual(P.dow(sat), 6); assert.strictEqual(P.weekStart('2026-11-20'), '2026-11-14'); assert.strictEqual(P.weekStart(sat), sat); console.log('✔ الأسبوع يبدأ السبت');
  const weekly = { id: 'w', title: 'مذاكرة البرمجة', date: sat, startTime: '14:00', endTime: '16:00', repeat: 'weekly', alertMin: 30 };
  assert(P.occursOn(weekly, '2026-11-28')); assert(!P.occursOn(weekly, '2026-11-22')); assert(!P.occursOn(weekly, '2026-11-14')); assert(!P.occursOn({ ...weekly, repeatUntil: '2026-11-25' }, '2026-11-28')); console.log('✔ التكرار الأسبوعي والحد الأقصى للتكرار');
  assert.strictEqual(P.occurrences([{ id: 'd', title: 'x', date: '2026-11-20', repeat: 'daily' }], '2026-11-20', '2026-11-26').length, 7); console.log('✔ التكرار اليومي');
  const t2 = P.toggleDone(weekly, '2026-11-21'); assert(P.isDone(t2, '2026-11-21') && !P.isDone(t2, '2026-11-28')); assert(!P.isDone(P.toggleDone(t2, '2026-11-21'), '2026-11-21')); console.log('✔ إنجاز كل تكرار على حدة');
  const now = new Date('2026-11-20T10:00:00').getTime();
  const ov = P.overdue([{ id: 'o1', title: 'قديمة', date: '2026-11-18', startTime: '09:00', endTime: '10:00' }, { id: 'o2', title: 'منجزة', date: '2026-11-18', done: true }, { id: 'o3', title: 'اليوم لاحقاً', date: '2026-11-20', startTime: '18:00' }, { id: 'o4', title: 'مستقبلية', date: '2026-11-25' }], now);
  assert.deepStrictEqual(ov.map((o) => o.task.id), ['o1']); console.log('✔ المهام المتأخرة (غير المنجزة التي انتهى وقتها فقط)');
  const plan = P.notifPlan([weekly, { id: 'n', title: 'بدون تنبيه', date: sat, startTime: '10:00' }], now, 30, 60);
  assert.strictEqual(plan[0].at, new Date('2026-11-21T13:30:00').getTime()); assert(plan.every((x) => x.title === 'مذاكرة البرمجة')); assert.strictEqual(plan.length, 5); console.log('✔ خطة الإشعارات: قبل الموعد بـ30 دقيقة، ولا إشعار لمهمة بلا تنبيه');
  assert(P.validate({ title: '', date: sat })); assert(P.validate({ title: 'a', date: sat, startTime: '10:00', endTime: '09:00' })); assert(P.validate({ title: 'a', date: sat, endTime: '09:00' })); assert.strictEqual(P.validate({ title: 'a', date: sat, startTime: '09:00', endTime: '10:00' }), null); console.log('✔ التحقق من المهام');
  const g = P.monthGrid(2026, 10); assert(g.every((w) => w.length === 7) && g[0][0] <= '2026-11-01' && g.at(-1).includes('2026-11-30')); assert.strictEqual(P.dow(g[0][0]), 6); console.log('✔ شبكة الشهر');
  // 10: المكتبة والروابط
  const K = V.KbLogic;
  assert.strictEqual(K.normalizeUrl('example.com/a'), 'https://example.com/a'); assert.strictEqual(K.normalizeUrl('javascript:alert(1)'), null); assert.strictEqual(K.normalizeUrl('data:text/html,x'), null); assert.strictEqual(K.normalizeUrl('ftp://a.com'), null); assert.strictEqual(K.normalizeUrl('not a url'), null); console.log('✔ الروابط: تُقبل http/https فقط (يُحظر javascript: وdata:)');
  assert.deepStrictEqual(K.parseKeywords('sql، join, SQL\n join ,'), ['sql', 'join', 'SQL']); const pl = K.parseLinks('w3schools.com\nbad link\nhttps://x.org'); assert.strictEqual(pl.urls.length, 2); assert.strictEqual(pl.bad.length, 1); console.log('✔ الكلمات المفتاحية والروابط داخل الملخص');
  const notes = [{ title: 'JOIN', category: 'قواعد البيانات', content: 'ربط الجداول', keywords: ['sql'], addedAt: '2026-11-01' }, { title: 'محاسبة', category: 'المحاسبة', content: 'قيد مزدوج', addedAt: '2026-11-05' }];
  assert.strictEqual(K.filterNotes(notes, 'الجداول', '').length, 1); assert.strictEqual(K.filterNotes(notes, '', 'المحاسبة').length, 1); assert.strictEqual(K.filterNotes(notes, 'sql', '')[0].title, 'JOIN'); assert.strictEqual(K.filterNotes(notes, '', '')[0].title, 'محاسبة'); console.log('✔ البحث والتصفية داخل الملخصات');
  assert(K.validateNote({ title: 'a', content: '' })); assert(K.validateLink({ name: 'a', url: 'javascript:1' })); assert.strictEqual(K.validateLink({ name: 'a', url: 'a.com' }), null); console.log('✔ التحقق من الملخص والرابط');
})().catch((e) => { console.error('✘ فشل', e); process.exit(1); });

// pdf.js المحلي (نفس الملفات في lib/pdfjs) على PDF حقيقي
(async () => {
  const assert = require('assert'); const { PDFDocument, StandardFonts } = require('/opt/npm-tools/node_modules/pdf-lib');
  const d = await PDFDocument.create(); const pg = d.addPage(); pg.drawText('Annual report 2026 - AMMAR VAULT demo file', { x: 40, y: 700, font: await d.embedFont(StandardFonts.Helvetica), size: 14 });
  const bytes = await d.save(); const pdfjs = await import('/opt/npm-tools/node_modules/pdfjs-dist/legacy/build/pdf.mjs');
  const r = await globalThis.Vault.PdfText.extract(bytes, pdfjs); assert(r.ok && r.engine === 'pdfjs' && r.text.includes('Annual report 2026')); console.log('✔ استخراج نص PDF حقيقي عبر pdf.js');
})().catch((e) => { console.error('✘ فشل pdfjs', e.message); process.exit(1); });
// ---- المرحلة 11: الإحصائيات ----
require('../js/docs-logic.js'); require('../js/debts-logic.js'); require('../js/stats-logic.js');
(async () => {
  const V = globalThis.Vault, assert = require('assert'), now = new Date('2026-11-20T10:00:00').getTime();
  const d = { documents: [{ title: 'a', expiryDate: '2026-12-01', alertDays: 30 }, { title: 'b', expiryDate: '2030-01-01' }, { title: 'c', expiryDate: '2026-01-01' }], accounts: [{}, {}], photos: [{ size: 1000 }], files: [{ size: 500 }], notes: [{}], links: [{}, {}, {}],
    debt_people: [{ id: 'p1' }, { id: 'p2' }], debt_tx: [{ personId: 'p1', kind: 'debt', amount: 100, date: 'x' }, { personId: 'p1', kind: 'payment', amount: 40, date: 'x' }, { personId: 'p2', kind: 'debt', amount: 5, date: 'x' }, { personId: 'p2', kind: 'payment', amount: 5, date: 'x' }],
    tasks: [{ id: 't1', title: 'منجزة', date: '2026-11-19', done: true }, { id: 't2', title: 'متأخرة', date: '2026-11-18', startTime: '09:00' }, { id: 't3', title: 'قادمة', date: '2026-11-21', startTime: '10:00' },
      { id: 't4', title: 'يومية', date: '2026-11-15', repeat: 'daily', startTime: '23:00', doneDates: ['2026-11-15', '2026-11-16'] }] };
  const s = V.StatsLogic.compute(d, now);
  assert.deepStrictEqual([s.documents, s.accounts, s.photos, s.files, s.notes, s.links, s.mediaBytes], [3, 2, 1, 1, 1, 3, 1500]);
  assert.deepStrictEqual(s.debts, { outstanding: 6000, paid: 4500, debtors: 1, settled: 1, open: 1 });
  assert.strictEqual(s.tasks.completed, 3); assert.strictEqual(s.tasks.overdue >= 1, true); assert.strictEqual(s.docAlerts.length, 2);
  assert(s.upcoming.some((o) => o.task.id === 't3')); assert(!s.upcoming.some((o) => o.task.id === 't2'));
  assert.strictEqual(s.tasks.remaining, 2 /* t2 وt3 غير منجزتين */ + 8 /* اليومية من اليوم حتى +7 أيام */);
  console.log('✔ الإحصائيات (الأعداد، الديون، المهام المكتملة/المتبقية/المتأخرة، المواعيد، تنبيهات الوثائق)');
})().catch((e) => { console.error('✘ فشل stats', e.message); process.exit(1); });
// ---- المرحلة 12: النسخ الاحتياطي والاستعادة ----
require('../js/backup.js');
(async () => {
  const V = globalThis.Vault, B = V.Backup, assert = require('assert'), PW = 'كلمة-سر-قوية-1', zlib = require('zlib');
  const mk = async () => { const st = V.Storage.memory(), a = V.Auth(st), db = V.DB(st, a); await a.setup(PW); return { st, a, db }; };
  const { st, a, db } = await mk();
  const acc = await db.put('accounts', { site: 'Gmail', password: 'PW-SECRET' }); await db.put('documents', { title: 'جواز' });
  const big = new Uint8Array(3 * 1024 * 1024).map((_, i) => (i * 13) % 256); const bid = await db.putBlob({ name: 'k.bin', type: 'application/octet-stream', bytes: big });
  await st.set('rec:pdf_index:zz', await V.Crypto.encrypt(a.key, { text: 'x' }));
  const { bytes, manifest } = await B.create(st, PW);
  assert.strictEqual(manifest.records, 3); assert.strictEqual(manifest.counts.accounts, 1); assert.strictEqual(manifest.counts._blobs, 1); assert(!manifest.counts.pdf_index); console.log('✔ إنشاء نسخة: العدّادات صحيحة ويُستثنى فهرس PDF المشتق');
  const asText = Buffer.from(bytes).toString('latin1'); assert(!asText.includes('Gmail') && !asText.includes('PW-SECRET') && !asText.includes('accounts') && !asText.includes('manifest')); console.log('✔ الملف لا يكشف أي نص ولا أسماء جداول');
  const v = await B.verify(bytes, PW, st); assert(v.ok, v.problems.join()); console.log('✔ التحقق العميق من السلامة (كل السجلات تُفك)');
  await assert.rejects(B.open(bytes, 'خطأ-خطأ-خطأ'), /غير صحيحة/); console.log('✔ كلمة مرور خاطئة مرفوضة');
  const c1 = Uint8Array.from(bytes); c1[c1.length - 5] ^= 1; await assert.rejects(B.open(c1, PW), /تالف/);
  const c2 = Uint8Array.from(bytes); c2[10] ^= 1; await assert.rejects(B.open(c2, PW), /تالف|غير صحيحة/); await assert.rejects(B.open(bytes.slice(0, bytes.length - 100), PW), /تالف|غير صحيحة/);
  await assert.rejects(B.open(new Uint8Array(200), PW), /ليس ملف نسخة/); console.log('✔ ملف معطوب/مبتور/معدَّل الترويسة/ليس نسخة ⇒ يُرفض');
  // هاتف جديد: مخزن فارغ + كلمة المرور فقط
  const st2 = V.Storage.memory(), snap2 = V.Storage.memory(); const rep = await B.restore(st2, await B.open(bytes, PW), snap2);
  assert.strictEqual(rep.records, 3); assert(!rep.hadData); const a2 = V.Auth(st2), db2 = V.DB(st2, a2); await a2.unlock(PW);
  assert.strictEqual((await db2.get('accounts', acc.id)).password, 'PW-SECRET'); assert.deepStrictEqual(Buffer.from((await db2.getBlob(bid)).bytes), Buffer.from(big)); console.log('✔ الاستعادة على هاتف جديد بكلمة المرور فقط (سجلات + مرفق 3MB مطابق)');
  // الاستعادة فوق بيانات موجودة + لقطة + تراجع
  const o = await mk(); const extra = await o.db.put('accounts', { site: 'OLD', password: 'old' }); const snap = V.Storage.memory();
  await B.restore(o.st, await B.open(bytes, PW), snap); assert(await B.hasSnapshot(snap)); const a3 = V.Auth(o.st), db3 = V.DB(o.st, a3); await a3.unlock(PW);
  assert.strictEqual(await db3.get('accounts', extra.id), null); assert((await db3.get('accounts', acc.id)).site === 'Gmail'); console.log('✔ الاستعادة فوق بيانات موجودة تستبدلها');
  await B.undo(o.st, snap); await o.a.unlock(PW); assert.strictEqual((await V.DB(o.st, o.a).get('accounts', extra.id)).site, 'OLD'); assert(!(await B.hasSnapshot(snap))); console.log('✔ التراجع عن الاستعادة يعيد البيانات السابقة');
  // فشل أثناء الكتابة ⇒ تراجع تلقائي
  const o2 = await mk(); const keep = await o2.db.put('accounts', { site: 'KEEP', password: 'k' }); const p = await B.open(bytes, PW); let n = 0; const real = o2.st.set.bind(o2.st);
  o2.st.set = async (k, vv) => { if (++n === 3) throw new Error('disk full'); return real(k, vv); }; const snap3 = V.Storage.memory();
  await assert.rejects(B.restore(o2.st, p, snap3), /أُعيدت بياناتك السابقة/); o2.st.set = real; await o2.a.unlock(PW); assert.strictEqual((await V.DB(o2.st, o2.a).get('accounts', keep.id)).site, 'KEEP'); console.log('✔ فشل منتصف الاستعادة ⇒ تراجع تلقائي وبياناتك سليمة');
  // تغيير كلمة المرور بعد النسخة: النسخة القديمة تُفتح بكلمتها القديمة فقط
  await a.changePassword(PW, 'جديدة-جديدة-2'); await B.open(bytes, PW); await assert.rejects(B.open(bytes, 'جديدة-جديدة-2'), /غير صحيحة/); const nb = await B.create(st, 'جديدة-جديدة-2'); assert((await B.verify(nb.bytes, 'جديدة-جديدة-2', st)).ok); console.log('✔ النسخة تُفتح بكلمة المرور وقت إنشائها');
  assert(/^AMMAR_VAULT_\d{8}_\d{4}\.avbak$/.test(B.fileName(new Date(2026, 10, 21, 9, 5)))); console.log('✔ اسم الملف');
})().catch((e) => { console.error('✘ فشل backup', e); process.exit(1); });
// ---- المرحلة 13: SQLite (عبر SQLite حقيقي في Node)، البصمة (منطق المفتاح)، إبطاء المحاولات ----
require('../js/attempts.js');
(async () => {
  const V = globalThis.Vault, assert = require('assert'), PW = 'كلمة-سر-قوية-1';
  // إبطاء المحاولات
  let t = 1000000; const mem = { v: null }, A = V.Attempts.create({ get: () => mem.v, set: (x) => (mem.v = x) }, () => t);
  for (let i = 0; i < 4; i++) A.fail(); assert(!A.status().locked); A.fail(); assert(A.status().locked && A.status().seconds === 30);
  t += 31000; assert(!A.status().locked); A.fail(); assert.strictEqual(A.status().seconds, 60); A.ok(); assert(!A.status().locked && A.status().failures === 0);
  assert.strictEqual(V.Attempts.delayFor(12), 3600); console.log('✔ إبطاء المحاولات: 4 مجاناً ثم 30ث/60ث/… وإعادة الضبط عند النجاح');
  // مفتاح البصمة: تصدير/استيراد DEK + التحقق + ترقية الخزائن القديمة
  const st = V.Storage.memory(), a = V.Auth(st); await a.setup(PW); const raw = await a.exportKey(); assert.strictEqual(raw.length, 32);
  const a2 = V.Auth(st); await a2.unlockWithKey(raw); assert(a2.unlocked); const db = V.DB(st, a2); assert((await db.put('links', { name: 'x' })).id);
  await assert.rejects(V.Auth(st).unlockWithKey(new Uint8Array(32)), /لم يعد صالحاً/); console.log('✔ فتح بمفتاح البصمة: مفتاح صحيح يفتح، ومفتاح خاطئ يُرفض');
  await a.changePassword(PW, 'جديدة-جديدة-2'); await V.Auth(st).unlockWithKey(raw); console.log('✔ تغيير كلمة المرور لا يُبطل مفتاح البصمة');
  const old = await st.get('meta:auth'); delete old.check; await st.set('meta:auth', old); await assert.rejects(V.Auth(st).unlockWithKey(raw), /مرة واحدة/);
  await V.Auth(st).unlock('جديدة-جديدة-2'); assert((await st.get('meta:auth')).check); await V.Auth(st).unlockWithKey(raw); console.log('✔ خزنة قديمة بلا check: تُرقّى عند أول فتح بكلمة المرور');
  // SQLite حقيقي عبر مُحاكي واجهة الإضافة
  const { DatabaseSync } = require('node:sqlite'); const dbs = {};
  const plugin = { async createConnection({ database }) { dbs[database] = dbs[database] || new DatabaseSync(':memory:'); }, async open() {}, async execute({ database, statements }) { dbs[database].exec(statements); return {}; },
    async run({ database, statement, values }) { dbs[database].prepare(statement).run(...(values || [])); return {}; }, async query({ database, statement, values }) { return { values: dbs[database].prepare(statement).all(...(values || [])) }; } };
  const S = V.Storage.sqlite(plugin, 'main'); await S.set('rec:debt_people:a1', 'v1'); await S.set('rec:debt_people:a2', 'v2'); await S.set('rec:debtXpeople:z', 'bad'); await S.set('blob:b1', 'v3'); await S.set("rec:q'uote:1", "it's");
  assert.strictEqual(await S.get('blob:b1'), 'v3'); assert.strictEqual(await S.get('nope'), null); await S.set('blob:b1', 'v4'); assert.strictEqual(await S.get('blob:b1'), 'v4');
  assert.deepStrictEqual((await S.keys('rec:debt_people:')).sort(), ['rec:debt_people:a1', 'rec:debt_people:a2']); assert.strictEqual((await S.keys('')).length, 5); assert.strictEqual(await S.get("rec:q'uote:1"), "it's");
  await S.del('blob:b1'); assert.strictEqual(await S.get('blob:b1'), null); await S.clear(); assert.strictEqual((await S.keys('')).length, 0); console.log('✔ محوّل SQLite: get/set/del/keys/clear (بادئة تحتوي _ لا تُعامل كرمز بحث) على SQLite حقيقي');
  // التطبيق كاملاً فوق SQLite: خزنة + سجلات + مرفق + نسخة احتياطية + استعادة على قاعدة أخرى
  const s1 = V.Storage.sqlite(plugin, 'vault1'), s2 = V.Storage.sqlite(plugin, 'vault2'), sn = V.Storage.sqlite(plugin, 'snap'); const au = V.Auth(s1), d1 = V.DB(s1, au); await au.setup(PW);
  const acc = await d1.put('accounts', { site: 'Gmail', password: 'PW-SECRET' }); const bid = await d1.putBlob({ name: 'f.bin', type: 'application/octet-stream', bytes: new Uint8Array(200000).map((_, i) => i % 255) });
  const bk = await V.Backup.create(s1, PW); assert((await V.Backup.verify(bk.bytes, PW, s1)).ok); await V.Backup.restore(s2, await V.Backup.open(bk.bytes, PW), sn);
  const au2 = V.Auth(s2); await au2.unlock(PW); assert.strictEqual((await V.DB(s2, au2).get('accounts', acc.id)).password, 'PW-SECRET'); assert.strictEqual((await V.DB(s2, au2).getBlob(bid)).bytes.length, 200000);
  const raw1 = JSON.stringify([...dbs.vault1.prepare('SELECT v FROM kv').all()]); assert(!raw1.includes('Gmail') && !raw1.includes('PW-SECRET')); console.log('✔ الخزنة والنسخ الاحتياطي والاستعادة فوق SQLite، والقاعدة لا تحوي نصاً مقروءاً');
})().catch((e) => { console.error('✘ فشل المرحلة 13', e); process.exit(1); });
// ---- الحماية أثناء القفل ----
(async () => {
  const V = globalThis.Vault, assert = require('assert'), st = V.Storage.memory(), a = V.Auth(st), db = V.DB(st, a); await a.setup('كلمة-سر-قوية-1'); const r = await db.put('links', { name: 'x' }); a.lock();
  for (const f of [() => db.put('links', {}), () => db.get('links', r.id), () => db.all('links'), () => db.putBlob({ name: 'a', type: 't', bytes: new Uint8Array(1) }), () => db.getBlob('x')]) await assert.rejects(f(), (e) => e.locked === true && /مقفلة/.test(e.arabic));
  assert.strictEqual(await db.count('links'), 1); console.log('✔ كل عمليات البيانات أثناء القفل تُرفض بخطأ «الخزنة مقفلة» (بلا تسريب ولا خطأ تشفير)');
})().catch((e) => { console.error('✘ فشل قفل', e); process.exit(1); });
