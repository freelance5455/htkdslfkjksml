const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer'); const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const PW = 'كلمة-سر-قوية-1'; let bad = 0;
const check = (n, c) => { if (!c) bad++; console.log(c ? '✔' : '✘ FAIL', n); };
(async () => {
  const b = await puppeteer.launch({ headless: 'new', executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] }); const p = await b.newPage(); p.on('dialog', (d) => d.accept());
  await p.goto('http://localhost:8099/index.html'); await p.waitForSelector('#f'); await p.type('#p1', PW); await p.type('#p2', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 });
  await p.click('.nav[data-id=settings]'); await sleep(400); await p.click('#lk'); await p.waitForSelector('#p1');
  const msg = () => p.$eval('#e', (e) => e.textContent); const wrong = async () => { await p.$eval('#p1', (e) => e.value = ''); await p.type('#p1', 'خطأ-خطأ-خطأ'); await p.click('#f .btn'); await sleep(1800); };
  for (let i = 0; i < 4; i++) await wrong(); check('4 محاولات خاطئة: رسالة «غير صحيحة» دون انتظار', (await msg()).includes('غير صحيحة') && !(await msg()).includes('انتظر'));
  await wrong(); check('المحاولة الخامسة الخاطئة: يُطلب الانتظار', (await msg()).includes('انتظر'));
  await p.$eval('#p1', (e) => e.value = ''); await p.type('#p1', PW); await p.click('#f .btn'); await sleep(800); check('أثناء الانتظار: حتى كلمة المرور الصحيحة لا تُقبل', !(await p.$('.shell')) && (await msg()).includes('انتظر'));
  await p.evaluate(() => localStorage.setItem('av_att', JSON.stringify({ n: 5, until: Date.now() - 1000 }))); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 }); check('بعد انتهاء الانتظار: تُقبل الصحيحة وتُصفَّر العدّادات', JSON.parse(await p.evaluate(() => localStorage.getItem('av_att'))).n === 0);
  await b.close(); process.exit(bad ? 1 : 0);
})().catch((e) => { console.log('FATAL', e.message); process.exit(1); });
