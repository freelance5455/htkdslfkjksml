const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer'); const fs = require('fs');
const FX = process.env.FIXTURES || 'tests/fixtures';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const PW = 'كلمة-سر-قوية-1'; let ok = 0, bad = 0;
const check = (n, c, extra) => { c ? ok++ : bad++; console.log(c ? '✔' : '✘ FAIL', n, extra || ''); };
const X = '<img src=x onerror="window.__xss=1">';
(async () => {
  const b = await puppeteer.launch({ headless: 'new', executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] }); const p = await b.newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept());
  const set = (sel, v) => p.$eval(sel, (e, v) => { e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }, v);
  const go = async (id) => { await p.click(`.nav[data-id="${id}"]`); await sleep(500); };
  const submit = async () => { await p.click('main form .btn:not(.ghost)'); await sleep(700); }; const msubmit = async () => { await p.click('.modal form .btn:not(.ghost)'); await sleep(800); };
  const text = () => p.$eval('main', (e) => e.innerText); const blobs = () => p.evaluate(() => new Promise((res) => { const r = indexedDB.open('ammar_vault'); r.onsuccess = () => { const q = r.result.transaction('kv').objectStore('kv').getAllKeys(); q.onsuccess = () => res(q.result.filter((k) => k.startsWith('blob:')).length); }; }));
  await p.goto('http://localhost:8099/index.html'); await p.waitForSelector('#f'); await p.type('#p1', PW); await p.type('#p2', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 });
  // ===== الوثائق: مرفقات + تنظيف المرفقات اليتيمة
  await go('docs'); await p.click('#add'); await set('[name=title]', 'رخصة قيادة'); await (await p.$('#im')).uploadFile(FX + '/red.png', FX + '/blue.png'); await (await p.$('#pf')).uploadFile('tests/sample.pdf'); await sleep(1500);
  check('وثيقة: صورتان وPDF تظهر قبل الحفظ', (await p.$$('.th img')).length === 2 && (await text()).includes('sample.pdf')); await submit();
  check('وثيقة: 3 مرفقات مشفّرة محفوظة', (await blobs()) === 3, 'blobs=' + (await blobs()));
  await p.click('.item'); await sleep(600); check('وثيقة: المرفقات تُعرض عند إعادة الفتح', (await p.$$('.th img')).length === 2);
  await p.click('.th button'); await sleep(300); await submit(); check('وثيقة: إزالة صورة تحذف مرفقها (لا يتامى)', (await blobs()) === 2, 'blobs=' + (await blobs()));
  await p.click('.item'); await sleep(500); await p.click('#dl'); await sleep(800); check('وثيقة: حذفها يحذف كل المرفقات', (await blobs()) === 0, 'blobs=' + (await blobs()));
  // ===== معرض الصور
  await go('photos'); await p.click('#na'); await set('.modal [name=n]', 'رحلة'); await msubmit();
  await (await p.$('#up')).uploadFile(FX + '/red.png', FX + '/blue.png'); await sleep(2500);
  check('صور: صورتان بمصغّرات', (await p.$$('.ph img')).length === 2); check('صور: أصل + مصغّرة لكل صورة (4 مرفقات)', (await blobs()) === 4, 'blobs=' + (await blobs()));
  await p.click('.ph'); await sleep(800); check('صور: العرض بالحجم الكامل', (await p.$eval('.modal img', (i) => i.naturalWidth)) >= 120);
  await p.click('.modal #ed'); await sleep(400); await set('.modal [name=n]', 'غروب'); await set('.modal [name=c]', 'سفر'); await p.$eval('.modal [name=a]', (e) => { e.selectedIndex = 1; }); await msubmit();
  await set('#q', 'سفر'); await sleep(700); check('صور: البحث بالتصنيف', (await p.$$('.ph')).length === 1);
  await set('#q', ''); await sleep(600); await p.$eval('#al', (e) => { e.selectedIndex = 2; e.dispatchEvent(new Event('change')); }); await sleep(700); check('صور: تصفية الألبوم', (await p.$$('.ph')).length === 1);
  await p.$eval('#al', (e) => { e.value = ''; e.dispatchEvent(new Event('change')); }); await sleep(600); await p.click('.ph'); await sleep(600); await p.click('.modal #dl'); await sleep(900);
  check('صور: الحذف يزيل الأصل والمصغّرة', (await p.$$('.ph')).length === 1 && (await blobs()) === 2, 'blobs=' + (await blobs()));
  // ===== الملفات
  await go('files'); await p.click('#nf'); await set('.modal [name=n]', 'أوراق'); await msubmit(); await p.click('[data-a=open]'); await sleep(500);
  await (await p.$('#up')).uploadFile(FX + '/note.txt'); await sleep(1200); check('ملفات: الرفع داخل مجلد', (await text()).includes('note.txt'));
  await p.click('[data-a=prev]'); await sleep(700); check('ملفات: معاينة TXT بمحتواه', (await p.$eval('.modal pre', (e) => e.textContent)).includes('secret-needle-42')); await p.click('.modal [data-x]');
  await p.click('[data-a=desc]'); await set('.modal [name=d]', 'محضر اجتماع الأسبوع'); await msubmit(); await p.click('[data-a=ren]'); await set('.modal [name=n]', 'محضر.txt'); await msubmit(); check('ملفات: إعادة تسمية + وصف', (await text()).includes('محضر.txt') && (await text()).includes('محضر اجتماع'));
  await p.click('[data-a=mv]'); await p.$eval('.modal [name=t]', (e) => { e.value = ''; }); await msubmit(); check('ملفات: النقل إلى الرئيسي', (await text()).includes('هذا المجلد فارغ'));
  await p.click('[data-go=""]'); await sleep(500); check('ملفات: الملف في الرئيسي بعد النقل', (await text()).includes('محضر.txt')); await set('#q', 'اجتماع'); await sleep(900); check('ملفات: البحث في الوصف', (await text()).includes('محضر.txt'));
  await set('#q', ''); await sleep(700); await p.click('[data-a=del]'); await sleep(800); check('ملفات: حذف الملف بعد تأكيد', !(await text()).includes('محضر.txt'));
  await p.click('[data-a=delf]'); await sleep(600); check('ملفات: حذف مجلد فارغ', !(await text()).includes('📁 أوراق'));
  // ===== حماية XSS في كل الأقسام
  await go('docs'); await p.click('#add'); await set('[name=title]', X); await set('[name=notes]', X); await submit();
  await go('links'); await p.click('#add'); await set('[name=name]', X); await set('[name=url]', 'a.com'); await submit();
  await go('kb'); await p.click('#add'); await set('[name=title]', X); await set('[name=content]', X); await set('[name=keywords]', X); await submit();
  await go('plan'); await p.click('#nt'); await set('[name=title]', X); await submit();
  await go('debts'); await p.click('#add'); await set('[name=name]', X); await submit(); await set('[name=amount]', '5'); await set('[name=reason]', X); await submit();
  await go('photos'); await p.click('#na'); await set('.modal [name=n]', X); await msubmit(); await go('files'); await p.click('#nf'); await set('.modal [name=n]', X); await msubmit();
  await go('pass'); await p.type('#pw', PW); await p.click('#v .btn'); await sleep(2500); await p.click('#add'); await set('[name=site]', X); await set('[name=password]', 'x'); await set('[name=notes]', X); await submit();
  await go('home'); await sleep(500); await p.type('#gq', 'img'); await sleep(1200); const found = await p.$$eval('#gr .item', (x) => x.length);
  for (const id of ['docs', 'links', 'kb', 'plan', 'debts', 'photos', 'files', 'stats']) await go(id);
  check('XSS: لا تنفيذ لأي حمولة في 8 أقسام + البحث', (await p.evaluate(() => window.__xss)) === undefined && found >= 5, 'results=' + found);
  await go('docs'); check('XSS: الحمولة تظهر نصاً حرفياً', (await text()).includes('<img src=x'));
  // ===== المظهر والقفل
  await go('settings'); const t0 = await p.evaluate(() => document.documentElement.dataset.theme); await p.click('#th'); const t1 = await p.evaluate(() => document.documentElement.dataset.theme); check('مظهر: التبديل داكن/فاتح', t0 !== t1 && ['dark', 'light'].includes(t1));
  await p.evaluate(() => { localStorage.setItem('av_autolock', '0.05'); }); await p.click('main'); await sleep(4500); check('قفل تلقائي بعد عدم الاستخدام', !!(await p.$('#f #p1')));
  await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 }); check('مظهر: يبقى بعد القفل', (await p.evaluate(() => document.documentElement.dataset.theme)) === t1);
  await p.evaluate(() => { localStorage.setItem('av_autolock', '5'); Object.defineProperty(document, 'hidden', { get: () => true, configurable: true }); document.dispatchEvent(new Event('visibilitychange')); }); await sleep(800); check('قفل عند مغادرة التطبيق', !!(await p.$('#f #p1')));
  await p.evaluate(() => { Object.defineProperty(document, 'hidden', { get: () => false, configurable: true }); }); await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 });
  // ===== هاتف: عرض 390px
  const relogin = async () => { await p.waitForSelector('#p1', { timeout: 15000 }); await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 }); };
  await p.setViewport({ width: 390, height: 800, isMobile: true, hasTouch: true }); await relogin(); let over = [], bottom = true;
  for (const id of ['home', 'docs', 'debts', 'files', 'photos', 'plan', 'kb', 'links', 'stats', 'backup', 'settings']) { await go(id); const w = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]); if (w[0] > w[1] + 1) over.push(id + ':' + w[0]); }
  bottom = (await p.$eval('.side', (e) => e.getBoundingClientRect().top)) > 400; check('هاتف: لا تمرير أفقي في 11 قسماً', over.length === 0, over.join()); check('هاتف: القائمة في الأسفل', bottom);
  await p.setViewport({ width: 1280, height: 800 }); await relogin();
  // ===== ملف كبير + نسخة احتياطية: أداء
  await go('files'); await (await p.$('#up')).uploadFile(FX + '/big.bin'); await sleep(4000); check('ملف 8MB: رُفع وظهر', (await text()).includes('big.bin'));
  await go('backup'); await p.evaluate(() => { Vault.FileSaver.save = async (n, bytes) => { window.__bk = { n, b64: Vault.Crypto.b64(bytes), len: bytes.length }; return { method: 'download', name: n }; }; });
  const t = Date.now(); await p.click('#bk'); await p.type('.modal [name=pw]', PW); await p.click('.modal form .btn:not(.ghost)'); await p.waitForFunction(() => document.body.innerText.includes('تم إنشاء النسخة'), { timeout: 120000 }); const secs = ((Date.now() - t) / 1000).toFixed(1);
  const info = await p.evaluate(() => ({ len: window.__bk.len })); check('نسخة بحجم ~' + (info.len / 1048576).toFixed(1) + 'MB تُنشأ وتُتحقق', info.len > 8e6, 'الوقت ' + secs + 'ث'); fs.writeFileSync(require('os').tmpdir() + '/bk_big.avbak', Buffer.from(await p.evaluate(() => window.__bk.b64), 'base64'));
  console.log(`\nنجح ${ok}، فشل ${bad}`); console.log('أخطاء الصفحة:', JSON.stringify(errs)); await b.close(); process.exit(bad ? 1 : 0);
})().catch((e) => { console.log('FATAL', e.message); process.exit(1); });
