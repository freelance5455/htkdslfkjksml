const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const PW = 'كلمة-سر-قوية-1'; let ok = 0, bad = 0;
const check = (name, cond) => { cond ? ok++ : bad++; console.log(cond ? '✔' : '✘ FAIL', name); };
(async () => {
  const b = await puppeteer.launch({ headless: 'new', executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] }); const p = await b.newPage();
  const errs = []; p.on('pageerror', (e) => errs.push(e.message)); p.on('response', (r) => { if (r.status() >= 400) errs.push(r.status() + ' ' + r.url()); }); p.on('dialog', (d) => d.accept());
  const go = async (id) => { await p.click(`.nav[data-id="${id}"]`); await sleep(500); };
  const set = async (sel, v) => { await p.$eval(sel, (e, v) => { e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }, v); };
  const submit = async () => { await p.click('form .btn:not(.ghost)'); await sleep(700); };
  const text = () => p.$eval('main', (e) => e.innerText);
  await p.goto('http://localhost:8099/index.html'); await p.waitForSelector('#f');
  await p.type('#p1', PW); await p.type('#p2', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 20000 });
  // الوثائق
  await go('docs'); await p.click('#add'); await set('[name=title]', 'بطاقة شخصية'); const soon = new Date(Date.now() + 10 * 864e5).toISOString().slice(0, 10); await set('[name=expiryDate]', soon);
  await p.$eval('[name=type]', (e) => e.value = 'بطاقة شخصية'); await submit(); check('وثيقة: تظهر في القائمة مع حالة الانتهاء', (await text()).includes('بطاقة شخصية') && (await text()).includes('تنتهي خلال'));
  // كلمات المرور
  await go('pass'); await p.type('#pw', PW); await p.click('#v .btn'); await sleep(2500); await p.click('#add'); await set('[name=site]', 'Gmail'); await set('[name=username]', 'ammar'); await set('[name=password]', 'TOP-SECRET-77'); await submit();
  let t = await text(); check('حساب: يظهر مقنَّعاً', t.includes('Gmail') && !t.includes('TOP-SECRET-77') && t.includes('••••'));
  await p.click('[data-a=show]'); await sleep(300); check('حساب: إظهار كلمة المرور', (await text()).includes('TOP-SECRET-77'));
  // الديون
  await go('debts'); await p.click('#add'); await set('[name=name]', 'خالد'); await submit(); await set('[name=amount]', '1000'); await set('[name=reason]', 'سلفة'); await submit();
  check('ديون: المتبقي 1,000', (await text()).includes('1,000'));
  await p.click('#p'); await sleep(500); await p.click('#full'); await submit(); t = await text(); check('ديون: رسالة السداد الكامل', t.includes('ليس لديك أي دين مستحق على هذا الشخص، الحساب مسدد بالكامل.'));
  // الروابط
  await go('links'); await p.click('#add'); await set('[name=name]', 'W3Schools'); await set('[name=url]', 'w3schools.com'); await submit(); check('رابط: حُفظ ويُطبَّع', (await text()).includes('https://www.w3schools.com') || (await text()).includes('https://w3schools.com'));
  await p.click('#add'); await set('[name=name]', 'خبيث'); await set('[name=url]', 'javascript:alert(1)'); await p.click('form .btn:not(.ghost)'); await sleep(300); check('رابط: رفض javascript:', (await p.$eval('#e', (e) => e.textContent)).includes('غير صالح')); await p.click('#cn');
  // الملخصات
  await go('kb'); await p.click('#add'); await set('[name=title]', 'شرح JOIN'); await set('[name=content]', 'عبارة ربط الجداول ببعضها في قواعد البيانات'); await set('[name=keywords]', 'sql، join'); await submit(); check('ملخص: يُعرض المحتوى والكلمات المفتاحية', (await text()).includes('ربط الجداول') && (await text()).includes('sql'));
  // الجدول
  await go('plan'); await p.click('#nt'); await set('[name=title]', 'مذاكرة البرمجة'); await set('[name=startTime]', '23:00'); await set('[name=endTime]', '23:30'); await submit(); check('جدول: مهمة اليوم تظهر', (await text()).includes('مذاكرة البرمجة'));
  await p.click('input[type=checkbox]'); await sleep(600); check('جدول: إنجاز المهمة', await p.$eval('input[type=checkbox]', (e) => e.checked));
  await p.click('[data-v=month]'); await sleep(400); check('جدول: العرض الشهري', (await p.$$('.cd')).length >= 28); await p.click('[data-v=week]'); await sleep(400); check('جدول: العرض الأسبوعي', (await text()).includes('مذاكرة البرمجة'));
  // الملفات (PDF)
  await go('files'); const up = await p.$('#up'); await up.uploadFile(process.env.TEST_PDF || 'tests/sample.pdf'); await sleep(1500); check('ملفات: رُفع الملف', (await text()).includes('sample.pdf'));
  // البحث الشامل
  await go('home'); await sleep(6000); const st = await p.$eval('#gst', (e) => e.textContent); console.log('حالة الفهرسة:', st);
  const q = async (w) => { await p.$eval('#gq', (e) => { e.value = ''; }); await p.type('#gq', w); await sleep(900); return p.$$eval('#gr .item', (x) => x.map((e) => e.innerText.replace(/\s+/g, ' '))); };
  let r = await q('بطاقه'); check('بحث: «بطاقة» ← الوثيقة', r.some((x) => x.includes('بطاقة شخصية')));
  r = await q('الجداول'); check('بحث: داخل محتوى الملخص', r.some((x) => x.includes('شرح JOIN')));
  r = await q('zebra-9921'); check('بحث: داخل نص PDF', r.some((x) => x.includes('sample.pdf') && x.includes('PDF')));
  r = await q('TOP-SECRET'); check('بحث: كلمة المرور لا تظهر', r.length === 0);
  r = await q('خالد'); check('بحث: شخص في دفتر الديون', r.some((x) => x.includes('خالد')));
  await q('شرح'); await p.click('#gr .item'); await sleep(900); check('فتح النتيجة مباشرة (الملخص)', (await p.$eval('main h2', (e) => e.textContent)).includes('شرح JOIN'));
  // القفل وإعادة الفتح
  await go('settings'); await p.click('#lk'); await p.waitForSelector('#f'); await p.type('#p1', 'خطأ-خطأ-خطأ'); await p.click('#f .btn'); await sleep(2500); check('قفل: كلمة خاطئة مرفوضة', (await p.$eval('#e', (e) => e.textContent)).includes('غير صحيحة'));
  await p.$eval('#p1', (e) => e.value = ''); await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 20000 }); check('قفل: الفتح بكلمة صحيحة', true);
  console.log(`\nنجح ${ok}، فشل ${bad}`); console.log('أخطاء الصفحة/الشبكة:', JSON.stringify(errs)); await b.close(); process.exit(bad ? 1 : 0);
})().catch((e) => { console.log('FATAL', e.message); process.exit(1); });
