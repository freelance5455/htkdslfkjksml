const puppeteer = require(process.env.PUPPETEER_PATH || 'puppeteer'); const fs = require('fs');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms)); const PW = 'كلمة-سر-قوية-1'; let ok = 0, bad = 0;
const check = (n, c) => { c ? ok++ : bad++; console.log(c ? '✔' : '✘ FAIL', n); };
const U = 'http://localhost:8099/index.html';
(async () => {
  const b = await puppeteer.launch({ headless: 'new', executablePath: process.env.CHROME_PATH || undefined, args: ['--no-sandbox'] });
  const errs = []; const newPage = async (ctx) => { const p = await (ctx || b).newPage(); p.on('pageerror', (e) => errs.push(e.message)); p.on('dialog', (d) => d.accept()); return p; };
  const set = (p, sel, v) => p.$eval(sel, (e, v) => { e.value = v; e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); }, v);
  const go = async (p, id) => { await p.click(`.nav[data-id="${id}"]`); await sleep(500); };
  const text = (p) => p.$eval('main', (e) => e.innerText); const modal = (p) => p.$eval('.modal', (e) => e.innerText).catch(() => '');
  const submit = async (p) => { await p.click('main form .btn:not(.ghost)'); await sleep(700); };
  const login = async (p, pw) => { await p.waitForSelector('#p1'); await p.type('#p1', pw); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 }); };
  const addLink = async (p, name, url) => { await go(p, 'links'); await p.click('#add'); await set(p, '[name=name]', name); await set(p, '[name=url]', url); await submit(p); };
  const p = await newPage(); await p.goto(U); await p.waitForSelector('#f'); await p.type('#p1', PW); await p.type('#p2', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 });
  await addLink(p, 'W3Schools', 'w3schools.com');
  await go(p, 'docs'); await p.click('#add'); await set(p, '[name=title]', 'جواز السفر'); await set(p, '[name=expiryDate]', new Date(Date.now() + 5 * 864e5).toISOString().slice(0, 10)); await submit(p);
  await go(p, 'files'); await (await p.$('#up')).uploadFile('tests/sample.pdf'); await sleep(1500);
  await go(p, 'plan'); await p.click('#nt'); await set(p, '[name=title]', 'موعد مهم'); await set(p, '[name=startTime]', '23:30'); await submit(p);
  // الإحصائيات
  await go(p, 'stats'); let t = await text(p);
  check('إحصائيات: وثيقة وملف ورابط ومهمة ومنبّه الانتهاء', /1\s*\n?\s*وثائق/.test(t) && t.includes('جواز السفر') && t.includes('موعد مهم') && /تنتهي خلال/.test(t) && /1\s*\n?\s*روابط/.test(t) && /1\s*\n?\s*ملفات/.test(t));
  // النسخ الاحتياطي (نلتقط البايتات بدل نافذة اختيار الملف)
  await go(p, 'backup'); await p.evaluate(() => { Vault.FileSaver.save = async (n, b) => { window.__bk = { n, b: Array.from(b) }; return { method: 'download', name: n }; }; });
  await p.click('#bk'); await p.type('.modal [name=pw]', 'خطأ-خطأ-خطأ'); await p.click('.modal form .btn:not(.ghost)'); await sleep(2500);
  check('نسخة: كلمة مرور خاطئة تُرفض ولا تُنشأ نسخة', (await modal(p)).includes('غير صحيحة') && !(await p.evaluate(() => window.__bk)));
  await p.$eval('.modal [name=pw]', (e) => e.value = ''); await p.type('.modal [name=pw]', PW); await p.click('.modal form .btn:not(.ghost)');
  await p.waitForFunction(() => document.body.innerText.includes('تم إنشاء النسخة'), { timeout: 40000 }); const sm = await p.$$eval('.modal', (x) => x.map((e) => e.innerText).join('\n'));
  check('نسخة: رسالة نجاح بالاسم والحجم والعدّادات والتحقق', /AMMAR_VAULT_\d{8}_\d{4}\.avbak/.test(sm) && sm.includes('الحجم') && sm.includes('وثائق: 1') && sm.includes('روابط: 1') && sm.includes('التحقق من سلامة'));
  const bk = await p.evaluate(() => window.__bk); fs.writeFileSync(require('os').tmpdir() + '/bk.avbak', Buffer.from(bk.b)); const bad1 = Buffer.from(bk.b); bad1[bad1.length - 9] ^= 1; fs.writeFileSync(require('os').tmpdir() + '/bk_bad.avbak', bad1);
  check('نسخة: الملف لا يحوي نصاً مقروءاً', !Buffer.from(bk.b).toString('latin1').includes('W3Schools'));
  await p.click('.modal [data-x]'); await addLink(p, 'EXTRA-AFTER', 'example.org');
  // هاتف جديد: سياق متصفح جديد تماماً (تخزين فارغ)
  const ctx = await (b.createBrowserContext ? b.createBrowserContext() : b.createIncognitoBrowserContext());
  const q = await newPage(ctx); await q.goto(U); await q.waitForSelector('#f');
  const restore = async (page, file, pw) => { await page.click('#rs, #rt'); await page.waitForSelector('.modal'); await (await page.$('.modal #rf')).uploadFile(file); await page.type('.modal [name=pw]', pw); await page.click('.modal form .btn:not(.ghost)'); await sleep(3500); };
  await restore(q, require('os').tmpdir() + '/bk.avbak', 'خطأ-خطأ-خطأ'); check('استعادة: كلمة مرور خاطئة', (await modal(q)).includes('غير صحيحة')); await q.click('.modal [data-x]');
  await restore(q, require('os').tmpdir() + '/bk_bad.avbak', PW); check('استعادة: ملف معطوب يُرفض', (await modal(q)).includes('تالف')); await q.click('.modal [data-x]');
  await restore(q, require('os').tmpdir() + '/bk.avbak', PW); check('استعادة: تقرير الفحص قبل التنفيذ', (await modal(q)).includes('النسخة سليمة') && (await modal(q)).includes('وثائق: 1'));
  await q.click('#go'); await q.waitForFunction(() => document.body.innerText.includes('تمت الاستعادة'), { timeout: 30000 }); check('استعادة على هاتف جديد: تقرير النتيجة', (await modal(q)).includes('استُعيدت'));
  await q.click('.modal [data-x]'); await login(q, 'كلمة-خاطئة-1').catch(() => {}); 
  await q.waitForSelector('#e'); await q.$eval('#p1', (e) => e.value = ''); await q.type('#p1', PW); await q.click('#f .btn'); await q.waitForSelector('.shell', { timeout: 25000 });
  await go(q, 'links'); t = await text(q); check('هاتف جديد: الرابط موجود والرابط الذي أُضيف بعد النسخة غير موجود', t.includes('W3Schools') && !t.includes('EXTRA-AFTER'));
  await go(q, 'docs'); check('هاتف جديد: الوثيقة موجودة', (await text(q)).includes('جواز السفر')); await go(q, 'files'); check('هاتف جديد: الملف موجود', (await text(q)).includes('sample.pdf'));
  await go(q, 'home'); await sleep(7000); await q.type('#gq', 'zebra-9921'); await sleep(1000); check('هاتف جديد: فهرس PDF أُعيد بناؤه والبحث يعمل', (await q.$$eval('#gr .item', (x) => x.length)) >= 1);
  // استعادة فوق بيانات موجودة ثم التراجع (على الصفحة الأولى)
  await go(p, 'backup'); await p.click('#rt'); await p.waitForSelector('.modal'); await (await p.$('.modal #rf')).uploadFile(require('os').tmpdir() + '/bk.avbak'); await p.type('.modal [name=pw]', PW); await p.click('.modal form .btn:not(.ghost)'); await sleep(3500);
  await p.click('#go'); await sleep(500); check('فوق بيانات: يُطلب تأكيد صريح', (await modal(p)).includes('أفهم'));
  await p.click('#ck'); await p.click('#go'); await p.waitForFunction(() => document.body.innerText.includes('تمت الاستعادة'), { timeout: 30000 }); await p.click('.modal [data-x]');
  await p.waitForSelector('#p1'); await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 });
  await go(p, 'links'); t = await text(p); check('فوق بيانات: استُبدلت بمحتوى النسخة', t.includes('W3Schools') && !t.includes('EXTRA-AFTER'));
  await go(p, 'backup'); check('فوق بيانات: زر التراجع ظاهر', !!(await p.$('#undo'))); await p.click('#undo'); await sleep(1500);
  await p.waitForSelector('#p1'); await p.type('#p1', PW); await p.click('#f .btn'); await p.waitForSelector('.shell', { timeout: 25000 }); await go(p, 'links'); check('التراجع: عاد الرابط الذي أُضيف بعد النسخة', (await text(p)).includes('EXTRA-AFTER'));
  console.log(`\nنجح ${ok}، فشل ${bad}`); console.log('أخطاء الصفحة:', JSON.stringify(errs)); await b.close(); process.exit(bad ? 1 : 0);
})().catch((e) => { console.log('FATAL', e.message); process.exit(1); });
