#!/usr/bin/env node
/* يشغّل اختبارات المتصفح الحقيقي كلها بأمر واحد: خادم ثابت على 8099 + ملفات اختبار مؤقتة.
   المتطلبات: puppeteer (npm i puppeteer) أو PUPPETEER_PATH، وإن لزم CHROME_PATH لمتصفح Chromium. */
const http = require('http'), fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
const root = path.join(__dirname, '..'), PORT = 8099, MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => { const f = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/^\/+$/, '/index.html'));
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res); });
server.on('error', (e) => { if (e.code !== 'EADDRINUSE') throw e; console.log('المنفذ 8099 مشغول: سأفترض أن خادماً للمشروع يعمل عليه.'); run(); });
server.listen(PORT, run);
let started = false;
async function run() {
  if (started) return; started = true; const fx = require('./make-fixtures.js')(path.join(os.tmpdir(), 'avvault-fixtures-' + process.pid)); const results = [];
  for (const t of ['e2e.js', 'e2e-backup.js', 'e2e-security.js', 'e2e-extra.js']) { console.log('\n=== ' + t);
    // spawn غير متزامن (spawnSync يجمّد الخادم الموجود في نفس العملية)
    const { code, out } = await new Promise((resolve) => { let out = ''; const c = cp.spawn('node', [path.join(__dirname, t)], { cwd: root, env: { ...process.env, FIXTURES: fx } });
      const kill = setTimeout(() => c.kill(), 400000); c.stdout.on('data', (d) => (out += d)); c.stderr.on('data', (d) => (out += d)); c.on('close', (code) => { clearTimeout(kill); resolve({ code, out }); }); });
    console.log(out.split('\n').filter((l) => /✘|FATAL|نجح|أخطاء/.test(l)).join('\n') || out.slice(-400)); results.push([t, code === 0]); }
  fs.rmSync(fx, { recursive: true, force: true }); console.log('\n' + results.map(([t, ok]) => (ok ? '✔ ' : '✘ ') + t).join('\n')); server.close(); process.exit(results.every((x) => x[1]) ? 0 : 1);
}
