GAMER TURBO ANDROID — 2.3.2 (NATIVE BRIDGE CHECK)

Este é um projeto Android nativo com interface HTML/CSS/JavaScript carregada em uma WebView local.
Não é um arquivo HTML isolado: MainActivity cria a WebView, registra GamerTurboBridge via
addJavascriptInterface e carrega app/src/main/assets/index.html.

MUDANÇAS 2.3.2
- GamerTurboBridge agora é public final, com métodos públicos anotados com @JavascriptInterface.
- Contrato de ponte identificado por getBridgeVersion() = 2.3.2.
- A interface não exige igualdade literal de versão; valida a presença da ponte e confere cada recurso individualmente.
- Indicador do topo abre diagnóstico da ponte, Android, permissões e Shizuku.
- Indicador visível mostra “ANDROID NATIVO CONECTADO” no APK compatível ou “PRÉVIA HTML” no navegador/empacotador sem ponte.
- Activity e Manifest mantêm a orientação landscape; aceleração de hardware está ligada.
- versionCode 11 / versionName 2.3.2.

PONTES NATIVAS IMPLEMENTADAS NO CÓDIGO
- Descoberta e abertura de aplicativos instalados (PackageManager).
- Leitura de bateria, temperatura da bateria, RAM e estado térmico.
- Brilho global (Settings.System; requer autorização do usuário).
- Não Perturbe (NotificationManager; requer acesso de política de notificações).
- HUD flutuante (GameOverlayService; requer “Mostrar sobre outros apps”).
- Tela imersiva e vibração.
- Gravação de tela (MediaProjection + serviço foreground; requer consentimento do usuário).
- Shizuku UserService/AIDL para comandos de shell autorizados.
- GameOptimizer tenta Game Mode, taxa de atualização e governor somente quando o Android/kernel permite,
  registra os valores originais e tenta restaurá-los ao retornar do jogo.

LIMITES DECLARADOS
- ANALISAR RAM faz leitura/diagnóstico; não mata processos nem promete liberar RAM.
- Não há overclock, aumento de tensão ou desbloqueio de limites térmicos.
- CPU/GPU só podem ter governor alterado se houver nó sysfs gravável e governor “performance” disponível.
- Nem todo jogo/ROM implementa Game Mode; cada ajuste precisa ser confirmado pelo comando de sistema.
- Recursos de sistema exigem permissões específicas e, para comandos privilegiados, Shizuku ativo e autorizado.

COMPILAÇÃO
- Projeto fonte, não APK pronto.
- Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, compileSdk 35 e minSdk 23.
- Abra a pasta GamerTurbo-Android em Android Studio/AndroidIDE com SDK 35 instalado e permita sincronizar
  as dependências Maven. Gere o APK debug para primeiro teste.
- O script gradlew deste pacote baixa a distribuição oficial Gradle 8.9; requer rede, curl/wget e unzip.

VALIDAÇÃO DESTE PACOTE
- HTML/JavaScript conferido sintaticamente com Node.js.
- AndroidManifest.xml validado como XML.
- Chamadas do HTML comparadas com métodos nativos @JavascriptInterface.
- Não foi possível compilar/testar em aparelho nesta sessão: não havia Android SDK/Gradle instalado nem
  acesso de rede ao repositório de dependências. Portanto, este ZIP é uma revisão auditada do código-fonte,
  não uma garantia de build ou de comportamento em todo aparelho.
