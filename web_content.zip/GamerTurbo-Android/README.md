# GAMER TURBO ANDROID — 2.3.7

Aplicativo Android nativo (Java) com a interface em HTML/CSS/JS dentro de uma WebView local.
O visual e as funções são os mesmos da 2.3.6; esta versão corrige a **ponte Java ↔ interface** e a
**lista de apps**. Este ZIP é código-fonte: é preciso gerar o APK (instruções abaixo).

## Como gerar o APK

Requisitos: Android Studio ou AndroidIDE, JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3 e SDK 35
(se o seu AndroidIDE só tiver o SDK 34, instale o `android-35` no gerenciador de SDK).

- **Debug:** `./gradlew assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
- **Release:** `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`
  (assinado com a chave debug, então instala direto; minificação desligada de propósito).

Instale por cima da versão anterior. Se o Android disser "App não instalado", a assinatura é
diferente da versão antiga: desinstale a antiga primeiro e instale de novo.

## O que foi corrigido na 2.3.7

1. **"Exige APK Android" dentro do APK / nenhuma função funciona.**
   - O release agora sai **sem R8/minificação**. O R8 pode remover as anotações `@JavascriptInterface`,
     e aí a ponte existe mas fica sem nenhum método. A interface tratava isso como "sem APK".
   - A interface aceita a ponte mesmo se o WebView reportar os métodos como `object` em vez de `function`,
     tenta de novo por ~12 s se a ponte demorar a aparecer e o Java confere a ponte depois que a página carrega.
   - Se ainda falhar, o indicador do topo e o diagnóstico dizem a causa exata (ponte ausente × ponte sem métodos).
2. **Lista de jogos vazia no Redmi/Xiaomi (MIUI/HyperOS).** A permissão `GET_INSTALLED_APPS` voltou a ser
   pedida na primeira abertura (só em ROMs que a definem). Sem ela a Xiaomi devolve uma lista vazia.
3. **Remover jogo da biblioteca não fazia nada.** O WebView ignorava o `confirm()`; agora o app mostra a janela.
4. **Interface travando ao abrir.** Os ícones dos apps eram recriados a cada leitura; agora ficam em cache e a
   biblioteca é pré-carregada em segundo plano.
5. **"Aplicativo não encontrado" ao abrir um jogo.** Se a ROM esconder o app do `getLaunchIntentForPackage`,
   há uma segunda tentativa por `queryIntentActivities` e `LauncherApps`.
6. Release não é mais barrado por erros de lint.

## Permissões

- **RAM, bateria, temperatura:** APIs públicas, sem permissão.
- **Lista de apps:** `QUERY_ALL_PACKAGES` (declarada) + `GET_INSTALLED_APPS` (Xiaomi, pedida na abertura).
- **Notificações (Android 13+):** pedida na abertura.
- **Painel flutuante / brilho / Não Perturbe:** telas especiais de Ajustes, abertas ao ativar cada recurso.
- **CPU/GPU e comandos de sistema:** dependem do Shizuku autorizado e do que o kernel deixa gravar.
  Não há overclock nem promessa de FPS.

## Se ainda aparecer "SEM PONTE"

Toque no indicador verde/amarelo do topo: o diagnóstico informa a causa. Para ver detalhes, filtre o
Logcat pela tag `GamerTurbo` (a linha "Verificação da ponte no WebView" mostra o que o WebView recebeu).

## Limitações

- Não foi possível compilar nem rodar em aparelho nesta sessão (sem Android SDK). Veja `AUDITORIA-2.3.7.txt`
  para o que foi e o que não foi validado. Os relatórios das versões anteriores estão em `docs/historico/`.
- A leitura de RAM é do sistema todo, não de um jogo. "Analisar RAM" não promete liberar memória.
