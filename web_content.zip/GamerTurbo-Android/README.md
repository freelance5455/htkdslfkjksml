# Gamer Turbo — projeto Android nativo

Versão retrabalhada com visual de central de jogos, biblioteca em grade com ícones reais dos apps, HUD flutuante nativo e ferramentas específicas do perfil Performance.

## O que mudou nesta versão

- Tela horizontal refeita: grade de jogos, ícones obtidos do Android, painel de status, seleção de perfil e atalhos compactos.
- Alça flutuante nativa: arrastável sobre outros aplicativos. Ao tocar, abre HUD com bateria, RAM livre, temperatura da bateria e tempo da sessão.
- Perfil Performance: libera no HUD o botão de otimização de processos em cache. O comando usa `am kill-all` pela integração Shizuku, com autorização explícita do usuário.
- Captura de tela salva em `Pictures/GamerTurbo`; gravação de tela salva em `Movies/GamerTurbo` (até 3 minutos, sem áudio), ambas pelo shell Shizuku.
- Foco/Não Perturbe, brilho do sistema com autorização WRITE_SETTINGS, painel de conectividade Wi-Fi e seleção dos modos no painel flutuante.
- O HUD também exibe estado térmico do Android, além da temperatura do sensor da bateria.
- A biblioteca importa jogos reconhecidos pelo Android e permite selecionar apps manualmente.

## Importante sobre a otimização de RAM

Android 14 ou superior impede que um app comum encerre processos de outros aplicativos usando `ActivityManager.killBackgroundProcesses()`. Para oferecer uma ação equivalente ao botão Optimize de alguns Game Space, este projeto usa Shizuku com privilégio de shell, após instalação, inicialização e autorização do usuário. O comando `am kill-all` solicita ao Android encerrar processos em cache; o sistema decide o que é seguro. Isso não garante aumento de FPS e processos podem ser iniciados novamente. Não encerra o jogo ativo quando o sistema o mantém em primeiro plano.

Shizuku exige configuração pelo próprio usuário. Em Android 11 ou superior é possível iniciá-lo por depuração sem fio, sem computador, mas é necessário repetir a inicialização após reiniciar o aparelho. Leia o manual oficial: https://shizuku.rikka.app/guide/setup/

## Como compilar o APK

1. Extraia o ZIP.
2. Abra `GamerTurbo-Android` no Android Studio.
3. Instale Android SDK Platform 35 e Java 17 quando solicitado.
4. Sincronize Gradle e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Projeto: Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, compileSdk 35 e minSdk 23 (Android 6.0+). Não usa GitHub para compilar.

## Permissões

O Android solicita permissão de sobreposição, acesso Não Perturbe e notificação do serviço. Shizuku solicita autorização própria para executar captura, gravação e otimização avançada. A primeira captura/gravação também precisa do acesso Shizuku ativo.

## Limites técnicos

Os perfis são de experiência e liberam ou ocultam ferramentas no Gamer Turbo; não fazem overclock, não alteram frequência da CPU/GPU, nem mudam a sensibilidade física do touch. A leitura de temperatura é a do sensor de bateria e a RAM é a memória global do sistema, não memória exclusiva do jogo.


## Biblioteca automática (v1.2.0)

- Consulta aplicativos com atividade de inicialização (`MAIN` + `LAUNCHER`) e atividades `MAIN` + `GAME`, respeitando a visibilidade de pacotes do Android 11+.
- Tenta reconhecer jogos pela categoria `ApplicationInfo.CATEGORY_GAME`, pela categoria de atividade e por uma lista auxiliar de nomes/pacotes conhecidos. Como nem todo desenvolvedor classifica o app como jogo, a tela “Escolher instalado” permite adicionar manualmente qualquer app iniciável.
- Lê o ícone real instalado pelo `PackageManager`, reduz para WebP de 88 px e usa esse ícone na grade. O Android não oferece uma capa promocional universal instalada em todos os jogos; capas editoriais exigiriam catálogo remoto próprio.
- O botão de play em cada cartão da tela inicial e da biblioteca inicia o pacote por `getLaunchIntentForPackage`. A lista é atualizada na abertura e quando o usuário retorna ao app.
- Os cartões têm animação de entrada e rotação 3D curta ao selecionar, respeitando `prefers-reduced-motion`.

## Compatibilidade e limites

- `minSdk 23`: Android 6.0 ou superior, com recursos ativados conforme as APIs e permissões disponíveis no aparelho.
- Detecção automática só vê aplicativos que o Android torna visíveis pelas consultas declaradas. Não usa `QUERY_ALL_PACKAGES`; aplicativos sem atividade iniciável não aparecem.
- O ícone real do app é automático; imagem de capa/arte de loja não é garantida pelo sistema.
- Painel flutuante depende de autorização “Mostrar sobre outros apps”. Gravação depende do consentimento do MediaProjection. Não Perturbe e brilho têm permissões próprias.
- Perfis do Gamer Turbo organizam ferramentas e aparência; não prometem overclock, aumento de FPS, desbloqueio de taxa de atualização ou controle de clocks de CPU/GPU.
- A opção “Otimizar RAM” usa Shizuku/ADB quando autorizado para pedir ao ActivityManager que encerre processos em cache; o Android continua decidindo o que encerra e isso não garante FPS melhor.
