# Gamer Turbo Android 2.2.0

Projeto Android nativo com interface de jogo em modo paisagem e ponte JavaScript para recursos do sistema.

## Perfis

- **Básico (azul):** otimização leve, mantendo o gerenciamento automático do Android e priorizando estabilidade e consumo equilibrado.
- **Gamer (amarelo):** solicita o Game Mode de desempenho por pacote e a maior taxa de atualização suportada.
- **Extremo (vermelho):** tenta o modo personalizado oficial do Game Mode com downscale 0,90 e alvo de FPS compatível quando a ROM oferece suporte e não há intervenção preexistente a preservar; solicita a taxa de atualização máxima, desativa temporariamente a economia de bateria e tenta governor `performance` apenas em nós CPU/GPU graváveis e com temperatura segura.

## Shizuku

A comunicação foi migrada para `UserService` com AIDL. Não usa mais reflexão sobre `Shizuku.newProcess`, método marcado como deprecated no Shizuku API. O serviço é iniciado com o backend autorizado pelo usuário e fica sob a identidade fornecida pelo Shizuku (normalmente UID 2000/shell ao iniciar por ADB sem root).

## Segurança e compatibilidade

- Pacotes são validados antes de entrar em comandos shell.
- Configurações de taxa de atualização e economia de bateria são lidas e gravadas de forma persistente antes da alteração; a restauração confere os valores e mantém o snapshot salvo se algo não puder ser restaurado.
- O modo Game Mode atual é consultado antes da alteração. Intervenções preexistentes são preservadas; quando um modo personalizado novo é criado, ele é removido ao final e o modo anterior é reativado.
- No modo Extremo, solicita o governor `performance` somente em nós de CPU e GPU comprovadamente graváveis, se a lista de governors oferecer essa opção e se a temperatura estiver em nível seguro; outros domínios devfreq não são alterados. O valor anterior é restaurado ao encerrar. Não altera clocks máximos nem tensão.
- CPU/GPU sysfs é inspecionado antes de qualquer tentativa de escrita.
- Não desativa proteção térmica nem altera tensão.
- O botão de RAM apenas mede uso de memória; não mata todos os processos em cache.

O suporte real varia conforme Android/MIUI/HyperOS, firmware, kernel e jogo. A aceitação de um comando não garante ganho de FPS. O código desta versão ainda precisa ser compilado e validado no aparelho físico.

## Compilar

Abra a pasta `GamerTurbo-Android` em um ambiente Android Gradle compatível (AGP 8.7.3, Gradle 8.9, JDK 17), sincronize e gere APK debug/release. Shizuku API 13.1.5 é obtida pelo Maven Central.
