package com.gamerturbo.mobile;

import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Small, user-authorized shell bridge. Commands are fixed by this app, never supplied by WebView. */
public final class ShizukuShell {
    private ShizukuShell() { }

    public static boolean isRunning() {
        try { return Shizuku.pingBinder(); }
        catch (Throwable ignored) { return false; }
    }

    public static boolean isAuthorized() {
        try { return isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable ignored) { return false; }
    }

    public static String state() {
        if (!isRunning()) return "OFF";
        return isAuthorized() ? "READY" : "NEED_PERMISSION";
    }

    public static Result execute(String command) {
        Process process = null;
        try {
            // Shizuku 13.x exposes the shell process bridge; reflection keeps this helper compatible
            // with the Java artifact while avoiding use of hidden Android APIs.
            Method method = Shizuku.class.getDeclaredMethod(
                    "newProcess", String[].class, String[].class, String.class);
            method.setAccessible(true);
            process = (Process) method.invoke(null,
                    new String[]{"sh", "-c", "exec 2>&1; " + command}, null, null);
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (output.length() < 5000) output.append(line).append('\n');
                }
            }
            int code = process.waitFor();
            return new Result(code == 0, output.toString().trim(), code);
        } catch (Throwable error) {
            return new Result(false, error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage(), -1);
        } finally {
            if (process != null) try { process.destroy(); } catch (Throwable ignored) { }
        }
    }

    public static final class Result {
        public final boolean success;
        public final String output;
        public final int exitCode;
        Result(boolean success, String output, int exitCode) {
            this.success = success; this.output = output; this.exitCode = exitCode;
        }
    }
}
