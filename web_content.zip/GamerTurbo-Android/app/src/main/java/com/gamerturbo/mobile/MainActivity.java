package com.gamerturbo.mobile;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import rikka.shizuku.Shizuku;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQUEST_SCREEN_CAPTURE = 7401;
    private static final int REQUEST_SHIZUKU = 7410;
    private static final String PREFS = "gamer_turbo_native";
    private static final String KEY_PENDING_OVERLAY = "pending_overlay_permission";
    private WebView webView;
    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_SHIZUKU) runOnUiThread(() -> {
            Toast.makeText(this, grantResult == PackageManager.PERMISSION_GRANTED ? "Shizuku autorizado para o Gamer Turbo." : "Permissão Shizuku negada.", Toast.LENGTH_LONG).show();
            if (webView != null) webView.postDelayed(() -> webView.evaluateJavascript("if(window.refreshNativeState){window.refreshNativeState();}", null), 250);
        });
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        try { Shizuku.addRequestPermissionResultListener(shizukuPermissionListener); } catch (Throwable ignored) { }

        Window window = getWindow();
        window.setStatusBarColor(0xFF090A0E);
        window.setNavigationBarColor(0xFF090A0E);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF090A0E);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setBlockNetworkLoads(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // The WebView is intentionally restricted to local app assets.
                return true;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new GamerTurboBridge(), "GamerTurboAndroid");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean(KEY_PENDING_OVERLAY, false)) {
            if (Settings.canDrawOverlays(this)) {
                prefs.edit().putBoolean(KEY_PENDING_OVERLAY, false).putBoolean("overlay_enabled", true).apply();
                startOverlayService();
            } else {
                prefs.edit().putBoolean(KEY_PENDING_OVERLAY, false).apply();
            }
        }
        if (getIntent() != null && getIntent().getBooleanExtra("request_shizuku", false)) {
            getIntent().removeExtra("request_shizuku");
            requestShizukuPermissionInternal();
        }
        if (webView != null) {
            webView.postDelayed(() -> webView.evaluateJavascript(
                    "if(window.refreshNativeState){window.refreshNativeState();}if(window.refreshInstalledGames){window.refreshInstalledGames();}", null), 250);
        }
    }

    private void startOverlayService() {
        Intent service = new Intent(this, GameOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
        else startService(service);
    }

    private void requestOverlayPermissionInternal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_PENDING_OVERLAY, true).apply();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("request_shizuku", false)) {
            intent.removeExtra("request_shizuku");
            requestShizukuPermissionInternal();
        }
    }

    private void requestShizukuPermissionInternal() {
        try {
            if (!ShizukuShell.isRunning()) {
                Intent manager = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (manager != null) startActivity(manager);
                else Toast.makeText(this, "Instale e inicie o Shizuku primeiro. Abra a opção de depuração sem fio no próprio Shizuku.", Toast.LENGTH_LONG).show();
                return;
            }
            if (ShizukuShell.isAuthorized()) {
                Toast.makeText(this, "Shizuku já está autorizado.", Toast.LENGTH_SHORT).show();
                return;
            }
            Shizuku.requestPermission(REQUEST_SHIZUKU);
        } catch (Throwable e) {
            Toast.makeText(this, "Não foi possível solicitar acesso ao Shizuku: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent service = new Intent(this, ScreenRecordService.class);
                service.putExtra(ScreenRecordService.EXTRA_RESULT_CODE, resultCode);
                service.putExtra(ScreenRecordService.EXTRA_RESULT_DATA, data);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service);
                else startService(service);
                Toast.makeText(this, "Preparando gravação da tela...", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Gravação cancelada.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private class GamerTurboBridge {
        @JavascriptInterface
        public String getInstalledApps() {
            try {
                PackageManager pm = getPackageManager();
                Intent launcher = new Intent(Intent.ACTION_MAIN);
                launcher.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> resolved = pm.queryIntentActivities(launcher, 0);
                // Alguns jogos declaram CATEGORY_GAME, outros apenas CATEGORY_LAUNCHER.
                // Consultamos as duas categorias para não depender só do nome do app.
                Intent gameQuery = new Intent(Intent.ACTION_MAIN);
                gameQuery.addCategory("android.intent.category.GAME");
                List<ResolveInfo> gameActivities = pm.queryIntentActivities(gameQuery, 0);
                Set<String> gamePackages = new HashSet<>();
                for (ResolveInfo item : gameActivities) {
                    if (item.activityInfo != null && item.activityInfo.applicationInfo != null) {
                        gamePackages.add(item.activityInfo.packageName);
                    }
                }
                Map<String, JSONObject> unique = new HashMap<>();

                for (ResolveInfo item : resolved) {
                    if (item.activityInfo == null || item.activityInfo.applicationInfo == null) continue;
                    ApplicationInfo app = item.activityInfo.applicationInfo;
                    String packageName = app.packageName;
                    if (packageName == null || packageName.equals(getPackageName())) continue;

                    CharSequence labelValue = item.loadLabel(pm);
                    String label = labelValue == null ? packageName : labelValue.toString().trim();
                    boolean game = isGameApplication(app, label, packageName, gamePackages.contains(packageName));
                    if (unique.containsKey(packageName)) continue;

                    JSONObject row = new JSONObject();
                    row.put("label", label);
                    row.put("packageName", packageName);
                    row.put("isGame", game);
                    row.put("category", app.category);
                    row.put("iconData", loadIconData(pm, app));
                    unique.put(packageName, row);
                }

                List<JSONObject> rows = new ArrayList<>(unique.values());
                Collections.sort(rows, (a, b) -> {
                    boolean gameA = a.optBoolean("isGame");
                    boolean gameB = b.optBoolean("isGame");
                    if (gameA != gameB) return gameA ? -1 : 1;
                    return a.optString("label").compareToIgnoreCase(b.optString("label"));
                });
                JSONArray result = new JSONArray();
                for (JSONObject row : rows) result.put(row);
                return result.toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public boolean launchGame(String packageName) {
            if (packageName == null || !packageName.matches("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) {
                showMessage("Identificador do aplicativo inválido.");
                return false;
            }
            PackageManager pm = getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            if (launchIntent == null) {
                showMessage("Aplicativo não encontrado. Atualize a biblioteca.");
                return false;
            }
            android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            prefs.edit().putString("active_game_package", packageName)
                    .putLong("game_session_started", System.currentTimeMillis()).apply();
            if (prefs.getBoolean("overlay_enabled", false) && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(MainActivity.this))) {
                runOnUiThread(MainActivity.this::startOverlayService);
            }
            runOnUiThread(() -> {
                try {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launchIntent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir esse aplicativo.", Toast.LENGTH_LONG).show();
                }
            });
            return true;
        }

        @JavascriptInterface
        public String getShizukuState() { return ShizukuShell.state(); }

        @JavascriptInterface
        public void requestShizukuPermission() {
            runOnUiThread(MainActivity.this::requestShizukuPermissionInternal);
        }

        @JavascriptInterface
        public boolean cleanRam() {
            if (!ShizukuShell.isAuthorized()) return false;
            new Thread(() -> {
                ShizukuShell.Result result = ShizukuShell.execute("am kill-all");
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        result.success ? "O Android recebeu o pedido para encerrar processos em cache. Isso não garante aumento de FPS." : "Falha na otimização: " + result.output,
                        Toast.LENGTH_LONG).show());
            }, "GamerTurbo-RamOptimize").start();
            return true;
        }

        @JavascriptInterface
        public String getDeviceStats() {
            try {
                JSONObject result = new JSONObject();
                Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (battery != null) {
                    int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                    int tempTenths = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
                    int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                    int percentage = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
                    boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                            || status == BatteryManager.BATTERY_STATUS_FULL;
                    result.put("batteryLevel", percentage);
                    result.put("charging", charging);
                    result.put("batteryTempC", tempTenths >= 0 ? tempTenths / 10.0 : -1);
                }

                ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                if (activityManager != null) {
                    ActivityManager.MemoryInfo memory = new ActivityManager.MemoryInfo();
                    activityManager.getMemoryInfo(memory);
                    long total = memory.totalMem;
                    long available = memory.availMem;
                    long used = Math.max(0, total - available);
                    int percent = total > 0 ? Math.round(used * 100f / total) : -1;
                    result.put("ramUsedMB", Math.round(used / (1024f * 1024f)));
                    result.put("ramTotalMB", Math.round(total / (1024f * 1024f)));
                    result.put("ramPercent", percent);
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
                    if (power != null) result.put("thermalStatus", thermalLabel(power.getCurrentThermalStatus()));
                } else {
                    result.put("thermalStatus", "indisponível");
                }
                return result.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean hasNotificationPolicyAccess() {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            return manager != null && manager.isNotificationPolicyAccessGranted();
        }

        @JavascriptInterface
        public void requestNotificationPolicyAccess() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Ajuste Não Perturbe não disponível.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public boolean isGameDndEnabled() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("game_dnd_active", false);
        }

        @JavascriptInterface
        public boolean setGameDnd(boolean enabled) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager == null || !manager.isNotificationPolicyAccessGranted()) return false;
            android.content.SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            try {
                if (enabled) {
                    if (!prefs.getBoolean("game_dnd_active", false)) {
                        prefs.edit().putInt("previous_dnd_filter", manager.getCurrentInterruptionFilter()).apply();
                    }
                    manager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
                    prefs.edit().putBoolean("game_dnd_active", true).apply();
                } else {
                    int previous = prefs.getInt("previous_dnd_filter", NotificationManager.INTERRUPTION_FILTER_ALL);
                    manager.setInterruptionFilter(previous);
                    prefs.edit().putBoolean("game_dnd_active", false).remove("previous_dnd_filter").apply();
                }
                return true;
            } catch (SecurityException e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean canWriteSettings() {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.System.canWrite(MainActivity.this);
        }

        @JavascriptInterface
        public void requestWriteSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Permissão de brilho não disponível.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public int getSystemBrightness() {
            try {
                return Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 166);
            } catch (Exception e) {
                return 166;
            }
        }

        @JavascriptInterface
        public boolean setSystemBrightness(int value) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(MainActivity.this)) return false;
            int brightness = Math.max(5, Math.min(255, value));
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                return Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, brightness);
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void openWifiSettings() {
            runOnUiThread(() -> {
                try {
                    Intent intent;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        intent = new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY);
                    } else {
                        intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    }
                    startActivity(intent);
                } catch (Exception e) {
                    try { startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)); }
                    catch (Exception ignored) { showMessage("Configurações de Wi-Fi indisponíveis."); }
                }
            });
        }

        @JavascriptInterface
        public void vibrate() {
            try {
                Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (vibrator != null && vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(14, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vibrator.vibrate(14);
                    }
                }
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public boolean canDrawOverlays() {
            return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(MainActivity.this);
        }

        @JavascriptInterface
        public void requestOverlayPermission() {
            runOnUiThread(MainActivity.this::requestOverlayPermissionInternal);
        }

        @JavascriptInterface
        public boolean isOverlayEnabled() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("overlay_enabled", false)
                    && (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(MainActivity.this));
        }

        @JavascriptInterface
        public boolean setOverlayEnabled(boolean enabled) {
            if (!enabled) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                        .putBoolean("overlay_enabled", false).putBoolean(KEY_PENDING_OVERLAY, false).apply();
                runOnUiThread(() -> stopService(new Intent(MainActivity.this, GameOverlayService.class)));
                return true;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                requestOverlayPermission();
                return false;
            }
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("overlay_enabled", true).apply();
            runOnUiThread(MainActivity.this::startOverlayService);
            return true;
        }

        @JavascriptInterface
        public String getMode() {
            String mode = getSharedPreferences(PREFS, MODE_PRIVATE).getString("game_mode", "performance");
            if (!"normal".equals(mode) && !"balanced".equals(mode) && !"performance".equals(mode)) return "performance";
            return mode;
        }

        @JavascriptInterface
        public void setMode(String mode) {
            if ("normal".equals(mode) || "balanced".equals(mode) || "performance".equals(mode)) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("game_mode", mode).apply();
            }
        }

        @JavascriptInterface
        public boolean isScreenRecording() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("screen_recording", false);
        }

        @JavascriptInterface
        public void requestScreenRecording() {
            runOnUiThread(() -> {
                if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("screen_recording", false)) return;
                try {
                    MediaProjectionManager manager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if (manager == null) {
                        Toast.makeText(MainActivity.this, "Gravação de tela indisponível neste aparelho.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não foi possível solicitar a captura de tela.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void stopScreenRecording() {
            runOnUiThread(() -> {
                Intent stop = new Intent(MainActivity.this, ScreenRecordService.class);
                stop.setAction(ScreenRecordService.ACTION_STOP);
                startService(stop);
            });
        }
    }

    private String loadIconData(PackageManager pm, ApplicationInfo app) {
        Bitmap bitmap = null;
        try {
            Drawable drawable = pm.getApplicationIcon(app);
            int size = 88;
            bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, size, size);
            drawable.draw(canvas);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            // WebP reduz bastante o tamanho total da resposta da biblioteca sem perder o ícone.
            boolean encoded = bitmap.compress(Bitmap.CompressFormat.WEBP, 82, out);
            if (!encoded) {
                out.reset();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, out);
                return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            }
            return "data:image/webp;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception ignored) {
            return "";
        } finally {
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private boolean isGameApplication(ApplicationInfo app, String label, String packageName, boolean gameCategoryMatch) {
        if (gameCategoryMatch) return true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.category == ApplicationInfo.CATEGORY_GAME) return true;
        String value = (label + " " + packageName).toLowerCase(Locale.ROOT).replace("_", " ").replace("-", " ");
        String[] terms = {
                "free fire", "freefire", "garena", "pubg", "call of duty", "callofduty", "cod mobile", "codm",
                "roblox", "minecraft", "genshin", "honkai", "mobile legends", "mobilelegends", "clash of clans",
                "clash royale", "brawl stars", "asphalt", "stumble guys", "fortnite", "wild rift", "pokemon unite",
                "efootball", "fc mobile", "fifa mobile", "subway surfers", "among us", "terraria", "shadow fight",
                "standoff", "arena breakout", "league of legends", "racing", "game launcher", "gamehub"
        };
        for (String term : terms) if (value.contains(term)) return true;
        return false;
    }

    private String thermalLabel(int status) {
        switch (status) {
            case PowerManager.THERMAL_STATUS_LIGHT: return "leve";
            case PowerManager.THERMAL_STATUS_MODERATE: return "moderado";
            case PowerManager.THERMAL_STATUS_SEVERE: return "alto";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "crítico";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "emergência";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "desligamento";
            default: return "normal";
        }
    }

    private void showMessage(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){return window.handleAndroidBack?window.handleAndroidBack():false})()", value -> {
                if ("false".equals(value) || value == null) MainActivity.super.onBackPressed();
            });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener); } catch (Throwable ignored) { }
        if (webView != null) {
            webView.removeJavascriptInterface("GamerTurboAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
