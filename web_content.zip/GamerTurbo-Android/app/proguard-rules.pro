# Mantido por segurança caso a minificação seja religada no futuro.
# Sem estes atributos o R8 remove @JavascriptInterface e a ponte Java fica vazia.
-keepattributes *Annotation*,InnerClasses,EnclosingMethod,Signature,RuntimeVisibleAnnotations

# O JavaScript bridge é chamado pelo WebView por meio das anotações @JavascriptInterface.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.gamerturbo.mobile.MainActivity$GamerTurboBridge { *; }

# Preserva os serviços Android declarados no Manifest.
-keep class com.gamerturbo.mobile.MainActivity { *; }
-keep class com.gamerturbo.mobile.GameOverlayService { *; }
-keep class com.gamerturbo.mobile.ScreenRecordService { *; }

# O Shizuku UserService é carregado pelo nome da classe em outro processo.
-keep class com.gamerturbo.mobile.GamerTurboUserService { *; }
-keep interface com.gamerturbo.mobile.IGamerTurboUserService { *; }
-keep class com.gamerturbo.mobile.IGamerTurboUserService$Stub { *; }
-keep class rikka.shizuku.** { *; }
