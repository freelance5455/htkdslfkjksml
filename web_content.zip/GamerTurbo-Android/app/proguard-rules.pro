# O JavaScript bridge é chamado pelo WebView por meio das anotações @JavascriptInterface.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Preserva os serviços Android declarados no Manifest.
-keep class com.gamerturbo.mobile.MainActivity { *; }
-keep class com.gamerturbo.mobile.GameOverlayService { *; }
-keep class com.gamerturbo.mobile.ScreenRecordService { *; }

# A integração Shizuku procura o método de criação de processo por reflexão.
-keep class rikka.shizuku.** { *; }
