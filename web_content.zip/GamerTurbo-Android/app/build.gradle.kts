plugins {
    id("com.android.application")
}

android {
    buildFeatures {
        aidl = true
    }

    namespace = "com.gamerturbo.mobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.gamerturbo.mobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 15
        versionName = "2.3.7"
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Um erro de lint nunca deve impedir a geração do APK.
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    buildTypes {
        debug {
            versionNameSuffix = "-debug"
        }
        release {
            // R8/ProGuard DESLIGADO de propósito: ele pode remover as anotações @JavascriptInterface
            // e deixar a ponte Java vazia. Foi a causa mais provável de "exige APK Android" dentro do APK.
            // O app é pequeno, então minificar não traz ganho relevante.
            isMinifyEnabled = false
            isShrinkResources = false
            // Assina com a chave debug para o APK release ser instalável direto (uso pessoal).
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.5")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
