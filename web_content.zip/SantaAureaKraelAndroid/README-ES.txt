SANTA AUREA · KRAEL — PROYECTO ANDROID ACTUALIZADO

Incluye el juego más reciente dentro de una app Android WebView y un icono de launcher inspirado en Krael.

IMPORTANTE: esto es el proyecto fuente de Android Studio, NO un APK instalable. En este entorno no hay Android SDK ni Gradle instalados para compilar y firmar el APK.

Para generar el APK:
1. Descomprime el proyecto en un computador con Android Studio.
2. Abre la carpeta del proyecto en Android Studio y espera a que Gradle termine la sincronización.
3. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
4. En la notificación de finalización, pulsa Locate para encontrar el APK.
5. Pasa ese APK al teléfono Android e instálalo.

Configuración: orientación horizontal, JavaScript habilitado, juego embebido en app/src/main/assets/game/index.html.
El icono está en app/src/main/res/mipmap-*/ic_launcher.png y representa a Krael.


ORIENTACION HORIZONTAL FORZADA
La Activity principal tiene android:screenOrientation="landscape" en AndroidManifest.xml. Android abrirá la aplicación en horizontal aunque la rotación automática del teléfono esté desactivada. Este archivo es un proyecto fuente, no un APK ya compilado.
