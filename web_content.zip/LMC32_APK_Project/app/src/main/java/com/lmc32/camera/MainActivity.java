package com.lmc32.camera;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.content.Intent;

public class MainActivity extends Activity {
    WebView web; ValueCallback<android.net.Uri[]> fileCallback;
    static final int PICK_FILE=1001;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        web=new WebView(this); setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.getSettings().setSupportZoom(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
          @Override public void onPermissionRequest(PermissionRequest r){ runOnUiThread(()->r.grant(r.getResources())); }
          @Override public boolean onShowFileChooser(WebView v, ValueCallback<android.net.Uri[]> cb, FileChooserParams p){
            if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
            Intent i=p.createIntent(); try{startActivityForResult(i,PICK_FILE);}catch(Exception e){fileCallback=null;return false;} return true;
          }
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FILE && fileCallback!=null){android.net.Uri[] r= (resultCode==RESULT_OK && data!=null && data.getData()!=null)?new android.net.Uri[]{data.getData()}:null; fileCallback.onReceiveValue(r);fileCallback=null;}
    }
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
