LMC32 Camera Android wrapper project (32-bit ARM target-ready)

This is Android Studio source, not a prebuilt APK. The included HTML is loaded offline from app assets.

Build:
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build APK(s).

For phone-only building, AndroidIDE or another Gradle Android IDE may work, depending on the device/version.

Note: WebView camera access depends on the device WebView and HTML camera implementation. This wrapper does not reproduce LMC/GCam proprietary image processing. For armeabi-v7a (32-bit) APK output, configure ABI filters in app/build.gradle if needed; this project is intended as a lightweight WebView wrapper and currently does not include native camera engine code.
