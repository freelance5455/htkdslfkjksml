// ===== pdf-viewer.js — Visualizador/Download genérico de PDFs da Biblioteca =====
// Sistema reutilizável: qualquer documento PDF (base64) pode ser registado aqui
// e ganha automaticamente um botão "Visualizar PDF" (leitura dentro da app,
// com navegação pelas páginas através do leitor nativo do navegador) e um
// botão "Baixar PDF" (download do ficheiro original).
// Não substitui nem remove o visualizador já existente do Manual de Gastrite
// (data-gastrite-pdf.js) — apenas acrescenta o mesmo comportamento para
// qualquer outro documento futuro da Biblioteca.

window.PDF_LIBRARY = window.PDF_LIBRARY || {};

function registerLibraryPdf(id, base64Data, filename){
  window.PDF_LIBRARY[id] = { data: base64Data, filename: filename };
}

function _pdfB64toBlob(b64Data, contentType){
  const sliceSize = 512;
  const byteCharacters = atob(b64Data);
  const byteArrays = [];
  for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    const slice = byteCharacters.slice(offset, offset + sliceSize);
    const byteNumbers = new Array(slice.length);
    for (let i = 0; i < slice.length; i++) byteNumbers[i] = slice.charCodeAt(i);
    byteArrays.push(new Uint8Array(byteNumbers));
  }
  return new Blob(byteArrays, { type: contentType || 'application/pdf' });
}

// Abre/fecha (toggle) o leitor de PDF embutido para o documento "id".
// Requer que exista no HTML um <div id="pdf-area-ID"> com um
// <iframe id="pdf-iframe-ID"> lá dentro — ver libraryPdfViewerBlock() abaixo.
function openLibraryPdf(id){
  const entry = window.PDF_LIBRARY[id];
  const area = document.getElementById('pdf-area-' + id);
  if (!entry || !area) return;
  if (area.style.display === 'block') {
    area.style.display = 'none';
    return;
  }
  const iframe = document.getElementById('pdf-iframe-' + id);
  if (iframe && (!iframe.src || iframe.src === 'about:blank')) {
    const blob = _pdfB64toBlob(entry.data, 'application/pdf');
    iframe.src = URL.createObjectURL(blob);
  }
  area.style.display = 'block';
  area.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Abre o leitor já posicionado numa página específica do PDF (navegação
// directa a partir de um índice/categoria). Funciona no leitor nativo de
// PDF do navegador (Chrome, Edge, Firefox), que respeita o fragmento #page=.
function openLibraryPdfAtPage(id, page){
  const entry = window.PDF_LIBRARY[id];
  const area = document.getElementById('pdf-area-' + id);
  const iframe = document.getElementById('pdf-iframe-' + id);
  if (!entry || !area || !iframe) return;
  if (!entry._blobUrl) {
    const blob = _pdfB64toBlob(entry.data, 'application/pdf');
    entry._blobUrl = URL.createObjectURL(blob);
  }
  iframe.src = entry._blobUrl + '#page=' + page;
  area.style.display = 'block';
  area.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function downloadLibraryPdf(id){
  const entry = window.PDF_LIBRARY[id];
  if (!entry) return;
  const blob = _pdfB64toBlob(entry.data, 'application/pdf');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = entry.filename || (id + '.pdf');
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// Gera o par de botões "Visualizar PDF" / "Baixar PDF" para usar dentro do
// corpo de um item da Biblioteca (buildAccordionView).
function libraryPdfButtons(id){
  return '<div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;">' +
    '<button onclick="openLibraryPdf(\'' + id + '\')" style="background:linear-gradient(135deg,#00205B,#0A4DA8);color:#fff;border:none;border-radius:10px;padding:10px 18px;font-size:13px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:7px;">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="16" height="16"><path d="M14 3v4a1 1 0 001 1h4"/><path d="M17 21H7a2 2 0 01-2-2V5a2 2 0 012-2h7l5 5v11a2 2 0 01-2 2z"/></svg>' +
      'Visualizar PDF' +
    '</button>' +
    '<button onclick="downloadLibraryPdf(\'' + id + '\')" style="background:#faf3df;color:#9c7d20;border:1px solid #9c7d20;border-radius:10px;padding:10px 18px;font-size:13px;font-weight:700;cursor:pointer;display:flex;align-items:center;gap:7px;">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" width="16" height="16"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>' +
      'Baixar PDF' +
    '</button>' +
  '</div>';
}

// Gera a área do leitor embutido (iframe oculto até ser aberto) para o
// documento "id" — deve ser inserida no corpo do item, junto dos botões.
function libraryPdfViewerBlock(id, title){
  return '<div id="pdf-area-' + id + '" style="display:none;margin-top:14px;border-radius:12px;overflow:hidden;border:1px solid var(--borda);">' +
    '<iframe id="pdf-iframe-' + id + '" style="width:100%;height:520px;border:none;" title="' + (title || 'Documento PDF') + '"></iframe>' +
  '</div>';
}

// Regista automaticamente o Manual de Gastrite Ulcerativa neste sistema
// genérico (sem alterar o visualizador antigo, que continua a funcionar).
(function registerExistingGastrite(){
  if (typeof window.GASTRITE_PDF_B64 !== 'undefined') {
    registerLibraryPdf('gastrite', window.GASTRITE_PDF_B64, 'Manual_Gastrite_Ulcerativa_Karlyon_2026.pdf');
  } else {
    // data-gastrite-pdf.js pode ainda não ter corrido; tenta novamente após carregamento.
    window.addEventListener('load', function(){
      if (typeof window.GASTRITE_PDF_B64 !== 'undefined') {
        registerLibraryPdf('gastrite', window.GASTRITE_PDF_B64, 'Manual_Gastrite_Ulcerativa_Karlyon_2026.pdf');
      }
    });
  }
})();
