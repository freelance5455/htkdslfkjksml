# Eldoria v1.8 - Modo online cooperativo

## Ativar no Firebase (projeto eldoria-6720d) - uma vez só
1. **Build > Realtime Database > Criar banco de dados** (modo bloqueado). Copie o endereço que aparece no topo
   (ex.: `https://eldoria-6720d-default-rtdb.firebaseio.com`). Se for diferente do que está no `index.html`
   (constante `RT`), troque lá.
2. Aba **Regras** do Realtime Database: cole `database.rules.json` e **Publicar**.
3. **Firestore > Regras**: cole `firestore.rules` e **Publicar** (é o ranking global, já existente).
4. Publique de novo a pasta (Netlify) ou gere o APK. Todos os jogadores precisam da **mesma versão (1.8)**.

## Como jogar junto
- Entrou na conta > **Modo online** > um jogador toca **Criar sala** e passa o código de 5 letras;
  os outros digitam o código em **Entrar na sala**. O anfitrião precisa estar dentro do jogo para os outros entrarem.
- Até 4 jogadores. Cada um mantém o próprio personagem, ouro e itens (salvos no próprio aparelho).
- Monstros são controlados pelo aparelho do anfitrião e atacam o jogador mais próximo.
- XP, moedas, drops e missões de um monstro vão para quem estiver a até ~8 tiles dele quando morre.

## Limites desta primeira versão
- Se o anfitrião fechar o app, os outros voltam ao modo solo após ~12 s. Se ele abrir menus, os monstros pausam para todos.
- Arena e criaturas invocadas por chefes são locais (não sincronizadas).
- Sem login anônimo/validação no servidor: quem souber o código entra e pode trapacear. Compartilhe só com amigos.
- Novo mundo: guarda 1 backup do progresso anterior (Novo mundo > Restaurar meu backup).
