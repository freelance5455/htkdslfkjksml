# NEXORA Beta — proyecto Android de prueba

Este proyecto envuelve el prototipo web de NEXORA dentro de una app Android mediante WebView. Habilita JavaScript y DOM Storage para que el almacenamiento local pueda funcionar mejor que al abrir el HTML como archivo suelto en algunos navegadores.

## Crear un APK de prueba

1. Instala Android Studio en una computadora.
2. Abre esta carpeta como proyecto existente.
3. Acepta la sincronización de Gradle y permite que Android Studio descargue los componentes requeridos.
4. En el menú **Build**, selecciona **Build APK(s)** (o **Build > Build Bundle(s) / APK(s) > Build APK(s)**, según la versión).
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.
6. Copia el APK al teléfono Android, ábrelo y permite instalar aplicaciones desde esa fuente si Android lo solicita.

También hay un flujo de GitHub Actions en `.github/workflows/build-apk.yml` para compilar el APK en GitHub después de subir el proyecto a un repositorio propio. El APK generado aparece como artefacto descargable de la ejecución del flujo.

## Alcance de esta beta

- La interfaz y funciones son las del prototipo web inicial.
- Los datos son locales al dispositivo; todavía no hay cuentas reales ni publicaciones sincronizadas entre usuarios.
- Denunciar/bloquear son demostraciones locales, no moderación de servidor.
- El generador de sensibilidad usa reglas sencillas, no una IA entrenada.
- Esta versión es para pruebas, no está lista para publicar en Google Play.
