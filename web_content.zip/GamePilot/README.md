# GamePilot — MVP Android

Aplicativo Android nativo em Kotlin + Jetpack Compose, com identidade GamePilot (toxzinfps), launcher de apps, diagnóstico do aparelho e fluxo de autorização Shizuku.

## O que já está no projeto
- Painel com SoC reportado pelo Android, núcleos, RAM, bateria/temperatura, rede e taxa de atualização.
- Informação de capacidade OpenGL ES e identificação explícita quando o Android não expõe o modelo de GPU.
- Lista de aplicativos iniciáveis para abrir jogos rapidamente.
- Integração de API Shizuku: detecção do serviço, solicitação de permissão e estado autorizado.
- Interface escura tecnológica adaptável.

## Limites importantes
Este MVP não altera clock/voltagem de CPU ou GPU, não atualiza firmware e não promete reduzir ping. O Shizuku concede identidade ADB/shell (ou root via Sui), não remove as políticas do fabricante; a disponibilidade de comandos depende da versão do Android e do aparelho. Os valores de rede são estimativas reportadas pelo Android, não um teste de velocidade.

## Abrir e compilar
1. Abra a pasta `GamePilot` no Android Studio recente.
2. Aguarde a sincronização do Gradle e compile para um aparelho Android 8.0+.
3. Instale e inicie Shizuku no telefone; no Android 11+, use Depuração sem fio para iniciar sem PC.
4. No GamePilot, toque em **Ativar / autorizar Shizuku** e aceite a solicitação no Shizuku.

A autorização é solicitada pelo próprio app e pode ser revogada a qualquer momento nas configurações do Shizuku.

## Próximos módulos possíveis
HUD flutuante com consentimento de sobreposição, painel de ping/estabilidade (sem alegar aceleração), perfis seguros de sessão e integração com o modo de jogo oficial quando o fabricante disponibilizar API. Ações privilegiadas devem ser implementadas por UserService Shizuku e validadas por modelo de aparelho; não executar comandos de overclock ou desativação de proteção térmica.
