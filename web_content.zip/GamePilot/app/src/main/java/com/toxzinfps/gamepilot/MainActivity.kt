package com.toxzinfps.gamepilot

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.Locale

private val Ink = Color(0xFF080B13)
private val Panel = Color(0xFF121827)
private val Accent = Color(0xFF66F2C2)
private val Secondary = Color(0xFF8AA2FF)

class MainActivity : ComponentActivity() {
    private var shizukuRevision by mutableIntStateOf(0)
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ -> shizukuRevision++ }
    private val binderReceived = Shizuku.OnBinderReceivedListener { shizukuRevision++ }
    private val binderDead = Shizuku.OnBinderDeadListener { shizukuRevision++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListener(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { GamePilotApp(this, shizukuRevision) }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        super.onDestroy()
    }

    fun connectShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                startActivity(Intent("moe.shizuku.manager.intent.action.REQUEST_PERMISSION"))
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                shizukuRevision++
            } else {
                Shizuku.requestPermission(42)
            }
        } catch (_: Exception) {
            try { startActivity(Intent("moe.shizuku.manager.intent.action.REQUEST_PERMISSION")) } catch (_: Exception) { }
        }
    }
}

private data class GameItem(val name: String, val packageName: String)

@Composable
private fun GamePilotApp(activity: MainActivity, revision: Int) {
    var page by remember { mutableStateOf("Início") }
    var games by remember { mutableStateOf(loadLaunchableApps(activity)) }
    var refresh by remember { mutableIntStateOf(0) }
    val shizukuOnline = remember(revision) { runCatching { Shizuku.pingBinder() }.getOrDefault(false) }
    val shizukuAllowed = remember(revision, shizukuOnline) {
        shizukuOnline && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Accent, secondary = Secondary,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Início", "Jogos", "Celular", "HTML").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item },
                        icon = { Text(when (item) { "Início" -> "⌂"; "Jogos" -> "▶"; "Celular" -> "▦"; else -> "</>" }, fontSize = 20.sp) },
                        label = { Text(item) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, indicatorColor = Color(0xFF23372F), selectedTextColor = Accent, unselectedTextColor = Color.LightGray))
                }
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("GAMEPILOT", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Desempenho sem mito.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("●", color = if (shizukuAllowed) Accent else Color.Gray, fontSize = 20.sp)
                }
                when (page) {
                    "Início" -> HomePage(activity, shizukuOnline, shizukuAllowed, refresh) { activity.connectShizuku() }
                    "Jogos" -> GamesPage(games, onRefresh = { games = loadLaunchableApps(activity) }, onLaunch = { launchGame(activity, it) })
                    "Celular" -> DevicePage(activity, refresh)
                    else -> HtmlPage()
                }
            }
        }
    }
}

@Composable
private fun HomePage(activity: MainActivity, shizukuOnline: Boolean, shizukuAllowed: Boolean, refresh: Int, onConnect: () -> Unit) {
    val stats = remember(refresh) { readDeviceStats(activity) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("SESSÃO DE JOGO", color = Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(stats.soc, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${stats.cores} núcleos · ${stats.ramLivre} RAM livre · ${stats.temp}°C bateria", color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        StatChip("REDE", stats.rede)
                        StatChip("TELA", stats.refreshRate)
                    }
                }
            }
        }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("CONTROLE SHIZUKU", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(when { shizukuAllowed -> "Conectado e autorizado"; shizukuOnline -> "Shizuku ativo — falta autorizar"; else -> "Shizuku não está ativo" }, color = if (shizukuAllowed) Accent else Color.LightGray, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onConnect, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink)) {
                        Text(if (shizukuAllowed) "Shizuku autorizado" else "Ativar / autorizar Shizuku", fontWeight = FontWeight.Bold)
                    }
                    Text("Abra o Shizuku e inicie o serviço antes de autorizar. No Android 11+, dá para iniciar pela depuração sem fio.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
        item {
            Surface(color = Color(0xFF192538), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(17.dp)) {
                    Text("Otimização segura", color = Secondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Acompanhe temperatura, memória, rede e tela; abra seus jogos pelo launcher. O app não força clock nem desativa proteções térmicas.", color = Color.White, fontSize = 13.sp)
                }
            }
        }
        item { Text("Leitura do aparelho", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item { InfoCard("CPU / SoC", "${stats.soc}\n${stats.cores} núcleos · ${stats.abi}") }
        item { InfoCard("GPU / gráficos", "${stats.gpuHint}\nOpenGL ES ${stats.glEs}") }
        item { InfoCard("Wi‑Fi / rede", stats.rede + "\n" + stats.redeDetail) }
        item { Text("Os dados de GPU, clocks e recursos variam por fabricante; esta versão mostra apenas informações fornecidas pelo Android.", color = Color.Gray, fontSize = 11.sp) }
    }
}

@Composable
private fun GamesPage(games: List<GameItem>, onRefresh: () -> Unit, onLaunch: (GameItem) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Seus aplicativos", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onRefresh) { Text("Atualizar", color = Accent) }
        }
        Text("Toque para abrir. Escolha seus jogos favoritos para iniciar sessões rapidamente.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(games, key = { it.packageName }) { game ->
                Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { onLaunch(game) }) {
                    Row(Modifier.padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(game.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(game.packageName, color = Color.Gray, fontSize = 11.sp)
                        }
                        Text("ABRIR  ›", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (games.isEmpty()) item { Text("Nenhum app com ícone de inicialização encontrado.", color = Color.LightGray) }
        }
    }
}

@Composable
private fun DevicePage(context: Context, refresh: Int) {
    val s = remember(refresh) { readDeviceStats(context) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Text("Diagnóstico do celular", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("Processador", "${s.soc}\n${s.cores} núcleos · ABI ${s.abi}") }
        item { InfoCard("Gráficos", "${s.gpuHint}\nOpenGL ES ${s.glEs}") }
        item { InfoCard("Memória", "${s.ramLivre} livres de ${s.ramTotal}") }
        item { InfoCard("Bateria e temperatura", "${s.bateria}% · ${s.temp}°C") }
        item { InfoCard("Conexão", "${s.rede}\n${s.redeDetail}") }
        item { InfoCard("Tela", s.refreshRate) }
        item { Text("Este painel identifica o hardware reportado pelo sistema; não instala atualizações de CPU/GPU nem altera o firmware do Wi‑Fi.", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun StatChip(label: String, value: String) {
    Surface(color = Color(0xFF202B3D), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoCard(title: String, value: String) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title.uppercase(Locale.getDefault()), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontSize = 14.sp)
        }
    }
}

private data class DeviceStats(
    val soc: String, val cores: Int, val abi: String, val gpuHint: String, val glEs: String,
    val ramLivre: String, val ramTotal: String, val bateria: Int, val temp: String,
    val rede: String, val redeDetail: String, val refreshRate: String
)

@Suppress("DEPRECATION")
private fun readDeviceStats(context: Context): DeviceStats {
    val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotBlank()) Build.SOC_MODEL else Build.HARDWARE
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memory = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memory)
    val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val battery = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val tempRaw = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
    val temp = if (tempRaw > 0) String.format(Locale.US, "%.1f", tempRaw / 10f) else "—"
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val network = cm.activeNetwork
    val caps = network?.let { cm.getNetworkCapabilities(it) }
    val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    val isCell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
    val netName = when { isWifi -> "Wi‑Fi"; isCell -> "Dados móveis"; caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"; else -> "Sem conexão" }
    val down = caps?.linkDownstreamBandwidthKbps ?: 0
    val up = caps?.linkUpstreamBandwidthKbps ?: 0
    val netDetail = if (down > 0) "Estimativa do Android: ↓ ${down} kb/s · ↑ ${up} kb/s" else "Velocidade/latência real dependem do roteador e da internet"
    val refreshRate = runCatching { String.format(Locale.US, "%.0f Hz", (context as? ComponentActivity)?.windowManager?.defaultDisplay?.refreshRate ?: 0f) }.getOrDefault("Não informado")
    val glEs = runCatching { activityManager.deviceConfigurationInfo.glEsVersion ?: "não informado" }.getOrDefault("não informado")
    return DeviceStats(
        soc = soc.ifBlank { "Não informado pelo fabricante" }, cores = Runtime.getRuntime().availableProcessors(),
        abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "não informado", gpuHint = "Modelo exato não exposto em API pública universal",
        glEs = glEs, ramLivre = formatBytes(memory.availMem), ramTotal = formatBytes(memory.totalMem), bateria = battery,
        temp = temp, rede = netName, redeDetail = netDetail, refreshRate = refreshRate
    )
}

private fun formatBytes(bytes: Long): String {
    val gb = bytes / (1024.0 * 1024.0 * 1024.0)
    return if (gb >= 1.0) String.format(Locale.getDefault(), "%.1f GB", gb) else "${bytes / (1024 * 1024)} MB"
}

@Suppress("DEPRECATION")
private fun loadLaunchableApps(context: Context): List<GameItem> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, 0)
        .mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            GameItem(info.loadLabel(context.packageManager)?.toString() ?: pkg, pkg)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.name.lowercase(Locale.getDefault()) }
}

private fun launchGame(context: Context, game: GameItem) {
    val intent = context.packageManager.getLaunchIntentForPackage(game.packageName) ?: return
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

@Composable
private fun HtmlPage() {
    AndroidView(
        modifier = Modifier.fillMaxSize().padding(bottom = 8.dp),
        factory = { context ->
            WebView(context).apply {
                settings.javaScriptEnabled = false
                settings.domStorageEnabled = false
                webViewClient = WebViewClient()
                loadUrl("file:///android_asset/index.html")
            }
        }
    )
}
