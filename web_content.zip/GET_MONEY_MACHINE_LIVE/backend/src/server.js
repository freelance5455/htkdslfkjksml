import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import Stripe from 'stripe';
import crypto from 'node:crypto';

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 4242);
const key = process.env.STRIPE_SECRET_KEY;
if (!key) console.warn('STRIPE_SECRET_KEY is not configured. The server will start, but Stripe calls will fail.');
const stripe = key ? new Stripe(key) : null;
const origin = process.env.CORS_ORIGIN || '*';
app.use(cors({ origin }));
app.use(express.json({ limit: '1mb' }));

const payments = new Map();
const sources = Array.from({length:15}, (_,i)=>({scanner_id:`SC-${String(i+1).padStart(2,'0')}`,url:'https://www.google.com/'}));

function requireStripe(res){
  if(!stripe){ res.status(503).json({error:'Stripe LIVE backend is not configured.'}); return false; }
  return true;
}
function normalizeAmount(v){
  const n=Number(v);
  if(!Number.isFinite(n) || n<=0 || n>99999999) return null;
  return Math.round(n*100);
}

app.get('/health', async (_req,res)=>{
  if(!stripe) return res.status(503).json({ok:false,mode:'live',stripe_configured:false});
  try { await stripe.balance.retrieve(); res.json({ok:true,mode:'live',stripe_configured:true}); }
  catch(e){ res.status(503).json({ok:false,mode:'live',stripe_configured:true,error:'Stripe authentication/connection failed'}); }
});

app.get('/payments/status', (_req,res)=>res.json({count:payments.size,payments:[...payments.values()].map(({checkout_url,...p})=>p)}));

app.post('/payments/create', async (req,res)=>{
  if(!requireStripe(res)) return;
  const cents=normalizeAmount(req.body?.amount);
  if(cents===null) return res.status(400).json({error:'Invalid amount'});
  const currency=String(req.body?.currency||'usd').toLowerCase();
  const description=String(req.body?.description||'GET MONEY MACHINE payment').slice(0,500);
  const id=crypto.randomUUID();
  try{
    const session=await stripe.checkout.sessions.create({
      mode:'payment',
      line_items:[{price_data:{currency,product_data:{name:description},unit_amount:cents},quantity:1}],
      success_url:`${process.env.PUBLIC_BASE_URL || 'http://localhost:'+port}/payment-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:`${process.env.PUBLIC_BASE_URL || 'http://localhost:'+port}/payment-cancelled`,
      metadata:{gmm_transaction_id:id}
    });
    const row={transaction_id:id,stripe_session_id:session.id,status:'PENDING',amount:cents/100,currency,description,created_at:new Date().toISOString()};
    payments.set(id,{...row,checkout_url:session.url});
    res.json(row);
  }catch(e){res.status(502).json({error:'Stripe payment creation failed'});}
});

app.get('/payments/:id/status', async (req,res)=>{
  if(!requireStripe(res)) return;
  const row=payments.get(req.params.id);
  if(!row) return res.status(404).json({error:'Transaction not found'});
  try{
    const s=await stripe.checkout.sessions.retrieve(row.stripe_session_id);
    let status='PENDING';
    if(s.payment_status==='paid') status='SETTLED';
    else if(s.status==='expired') status='CANCELLED';
    row.status=status; row.payment_status=s.payment_status; payments.set(row.transaction_id,row);
    res.json({transaction_id:row.transaction_id,status,payment_status:s.payment_status});
  }catch(e){res.status(502).json({error:'Stripe status lookup failed'});}
});

app.get('/opportunities/sources', (_req,res)=>res.json({sources}));
app.get('/payment-success', (_req,res)=>res.send('<h1>Payment received</h1><p>You can return to GET MONEY MACHINE.</p>'));
app.get('/payment-cancelled', (_req,res)=>res.send('<h1>Payment cancelled</h1><p>No payment was completed.</p>'));

app.listen(port,()=>console.log(`GET MONEY MACHINE Stripe LIVE backend listening on ${port}`));
