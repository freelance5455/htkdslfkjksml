GET MONEY MACHINE — LIVE STRIPE BUILD

The Android/web app is in web/index.html.
The secure Stripe backend is in backend/.

IMPORTANT: the Stripe LIVE secret key is intentionally NOT embedded in the HTML or APK. It must be supplied to the backend as STRIPE_SECRET_KEY. The app never receives the secret key.

Backend endpoints expected by the app:
GET  /health
GET  /payments/status
POST /payments/create
GET  /payments/:id/status
GET  /opportunities/sources

This build creates Stripe Checkout payment sessions. It does not claim that a payment automatically becomes a debit-card payout. Debit-card payouts require the appropriate Stripe Connect/recipient setup and eligibility.
