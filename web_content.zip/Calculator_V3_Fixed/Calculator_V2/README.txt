Calculator V3 - File picker fix

Use index.html in a modern mobile browser (Chrome) to test.
Vault import controls:
- Photos / Videos: opens media picker (accepts images and videos)
- Documents / Files: opens general file picker

Note: Browser prototype only. Not encrypted. If wrapped in an Android WebView APK,
file selection may still require native WebView file chooser support in the builder.
