# AMAZON GAZA — Full Stack حقيقي

هذه النسخة ليست HTML فقط.

## ما الذي أصبح حقيقيًا؟
- Express API + PostgreSQL
- حسابات مستخدمين وبائعين
- JWT authentication
- منتجات وقاعدة مخزون حقيقية
- سلة محفوظة في PostgreSQL
- إنشاء طلبات ومعاملة ذرية للمخزون
- عمولات البائعين ومحافظهم
- عناوين التوصيل
- لوحة المؤسس عبر API حقيقي
- سجل تدقيق
- AI عبر Gemini من الخادم فقط عند وضع مفتاحه
- الواجهة نفسها تُخدم من نفس الخادم
- لا يوجد وضع Offline

## كلمة مرور المؤسس
لا توجد كلمة مرور المؤسس داخل HTML أو JavaScript.
استخدم:
`node apps/api/scripts/make-founder-hash.mjs`
ثم ضع القيمتين الناتجتين في متغيري:
`FOUNDER_PASSWORD_SALT`
`FOUNDER_PASSWORD_HASH`

## قاعدة البيانات
شغّل `database/schema.sql` ثم `database/seed.sql` على PostgreSQL.

## تشغيل
`npm install --prefix apps/api`
`DATABASE_URL=... JWT_SECRET=... FOUNDER_PASSWORD_SALT=... FOUNDER_PASSWORD_HASH=... npm --prefix apps/api start`

ثم افتح عنوان الخادم.

## AI
ضع `GEMINI_API_KEY` في بيئة الخادم فقط. لا تضعه في الواجهة.

## الدفع
Jawwal Pay وPaltel Pay في هذه النسخة معرفان كطرق دفع، لكن لا يوجد ادعاء بوجود تحويل مالي حقيقي قبل تزويد المنصة ببيانات API الرسمية للتاجر والـwebhooks.
