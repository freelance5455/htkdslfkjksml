(() => {
'use strict';
const $ = (id) => document.getElementById(id);
const canvas = $('canvas'), ctx = canvas.getContext('2d', { alpha: false });
const workspace = $('workspace');
const DB_NAME = 'InfiniteCanvasNotebookDB', DB_VERSION = 2;
const PREF_KEY = 'infinite-canvas-v2-settings';
const readPrefs = () => { try { return {...{startPage:'lobby',zoomLimit:100,imageQuality:70,imageLayout:'vertical',performanceMode:'balanced',fps:12,lastBoardId:null},...JSON.parse(localStorage.getItem(PREF_KEY)||'{}')}; } catch { return {startPage:'lobby',zoomLimit:100,imageQuality:70,imageLayout:'vertical',performanceMode:'balanced',fps:12,lastBoardId:null}; } };
let appPrefs = readPrefs(), stickerItems = [], pendingImageFiles = [];
const maxZoom = () => Math.max(100, Number(appPrefs.zoomLimit)||100);
const clampZoom = n => clamp(n, 1/maxZoom(), maxZoom());
const savePrefs = () => { try { localStorage.setItem(PREF_KEY, JSON.stringify(appPrefs)); } catch { showToast('ذخیره تنظیمات انجام نشد؛ حافظه دستگاه کافی نیست.'); } };
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const uid = () => 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9);
const clone = (v) => JSON.parse(JSON.stringify(v));
const defaults = () => ({
  folders: [{id:'folder-general', name:'عمومی'}],
  boards: [{id:'board-welcome', title:'دفترچه من', folderId:'folder-general', items:[], updatedAt:Date.now()}]
});
let db = null, dbReady = false, memory = defaults();
let folders = [], boards = [], currentBoard = null, activeFolder = 'all';
let tool = 'select', ink = '#26384c', inkWidth = 4, fontSize = 24;
let camera = {x:0,y:0,scale:1}, dpr = 1, dirty = false, saveTimer = 0, toastTimer = 0;
let selection = [], active = null, pointers = new Map(), gesture = null, spaceDown = false;
let undoStack = [], redoStack = [], imageCache = new Map(), flashId = null, flashTimer = 0;
let editingId = null, pendingNewText = null, renderQueued = false, animationFrameQueued=false;

function showToast(message) {
  const t = $('toast'); t.textContent = message; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}
function status(message, good=true) {
  $('saveStatus').textContent = message;
  $('saveStatus').previousElementSibling.style.background = good ? '#6ebd91' : '#e4b96b';
}
function requestRender() { if (!renderQueued) { renderQueued = true; requestAnimationFrame(() => { renderQueued = false; render(); }); } }
function worldAt(sx, sy) { const r=canvas.getBoundingClientRect(); return {x:(sx-r.width/2)/camera.scale+camera.x, y:(sy-r.height/2)/camera.scale+camera.y}; }
function screenAt(x,y) { const r=canvas.getBoundingClientRect(); return {x:(x-camera.x)*camera.scale+r.width/2,y:(y-camera.y)*camera.scale+r.height/2}; }
function resizeCanvas() {
  const r=workspace.getBoundingClientRect(); const cap=appPrefs.performanceMode==='saving'?1:(appPrefs.performanceMode==='quality'?3:1.7);dpr=Math.max(1,Math.min(cap,window.devicePixelRatio||1));
  canvas.width=Math.max(1,Math.round(r.width*dpr)); canvas.height=Math.max(1,Math.round(r.height*dpr));
  requestRender();
}
function wrapLines(text, maxWidth, c) {
  const out=[];
  String(text||'').split('\n').forEach(paragraph=>{
    if (!paragraph) { out.push(''); return; }
    const words=paragraph.split(/\s+/); let line='';
    for (const word of words) {
      const test=line ? line+' '+word : word;
      if (line && c.measureText(test).width>maxWidth) { out.push(line); line=word; }
      else line=test;
    }
    out.push(line);
  });
  return out.length ? out : [''];
}
function textMetrics(item, c=ctx) {
  c.save(); c.font=`${item.bold?'700':'400'} ${item.fontSize||24}px Tahoma, Arial, sans-serif`;
  const pad=item.padding??(item.background?14:2), maxW=item.width||430;
  const lines=wrapLines(item.text||'',maxW-pad*2,c);
  const lineHeight=(item.fontSize||24)*1.48;
  let w=0; lines.forEach(l=>w=Math.max(w,c.measureText(l).width));
  const bounds={x:item.x,y:item.y,width:Math.max(w+pad*2,90),height:lines.length*lineHeight+pad*2};
  c.restore(); return {lines,lineHeight,pad,bounds};
}
function itemBounds(item) {
  if (item.type==='text') return textMetrics(item).bounds;
  if (['image','gif','sequence','sticker'].includes(item.type)) return {x:item.x,y:item.y,width:item.width||240,height:item.height||180};
  if (item.type==='shape') {
    const x=Math.min(item.x,item.x2), y=Math.min(item.y,item.y2);
    return {x,y,width:Math.abs(item.x2-item.x),height:Math.abs(item.y2-item.y)};
  }
  if (item.type==='stroke') {
    const pts=item.points||[];if(!pts.length)return {x:0,y:0,width:0,height:0};
    let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(const p of pts){if(p.x<minX)minX=p.x;if(p.x>maxX)maxX=p.x;if(p.y<minY)minY=p.y;if(p.y>maxY)maxY=p.y;}
    const pad=(item.width||4)/2+5;return {x:minX-pad,y:minY-pad,width:maxX-minX+pad*2,height:maxY-minY+pad*2};
  }
  return {x:item.x,y:item.y,width:0,height:0};
}
function overlaps(a,b) { return a.x<=b.x+b.width && a.x+a.width>=b.x && a.y<=b.y+b.height && a.y+a.height>=b.y; }
function itemHit(item,p) {
  const b=itemBounds(item);
  if (item.type==='stroke') {
    const rad=Math.max(9/camera.scale,(item.width||4)*1.7);
    for(let i=0;i<item.points.length;i++) if(Math.hypot(item.points[i].x-p.x,item.points[i].y-p.y)<rad) return true;
    for(let i=1;i<item.points.length;i++) if(pointSegmentDistance(p,item.points[i-1],item.points[i])<rad) return true;
    return false;
  }
  const pad=8/camera.scale;
  return p.x>=b.x-pad && p.x<=b.x+b.width+pad && p.y>=b.y-pad && p.y<=b.y+b.height+pad;
}
function pointSegmentDistance(p,a,b) {
  const dx=b.x-a.x,dy=b.y-a.y,den=dx*dx+dy*dy;
  if(!den) return Math.hypot(p.x-a.x,p.y-a.y);
  const t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/den,0,1);
  return Math.hypot(p.x-(a.x+t*dx),p.y-(a.y+t*dy));
}
function drawGrid(c,w,h) {
  const s=camera.scale, base=40;
  c.fillStyle='#f7f8fa';c.fillRect(0,0,w,h);
  if(s<.08)return;
  const step=s<.32?base*4:s<.65?base*2:base;
  const left=camera.x-w/(2*s), top=camera.y-h/(2*s);
  const right=camera.x+w/(2*s), bottom=camera.y+h/(2*s);
  const startX=Math.floor(left/step)*step, startY=Math.floor(top/step)*step;
  c.fillStyle='#dfe5eb';
  const dot=Math.max(0.65,Math.min(1.25,s*.95));
  for(let x=startX;x<=right+step;x+=step) for(let y=startY;y<=bottom+step;y+=step){
    const sx=(x-camera.x)*s+w/2, sy=(y-camera.y)*s+h/2;
    c.beginPath();c.arc(sx,sy,dot,0,Math.PI*2);c.fill();
  }
  // Slightly stronger five-cell anchors make orientation easier without imposing a page boundary.
  c.strokeStyle='#e9edf1'; c.lineWidth=1;
  const major=step*5, mx=Math.floor(left/major)*major, my=Math.floor(top/major)*major;
  for(let x=mx;x<=right+major;x+=major){const sx=(x-camera.x)*s+w/2;c.beginPath();c.moveTo(sx,0);c.lineTo(sx,h);c.stroke();}
  for(let y=my;y<=bottom+major;y+=major){const sy=(y-camera.y)*s+h/2;c.beginPath();c.moveTo(0,sy);c.lineTo(w,sy);c.stroke();}
}
function drawStroke(c,item) {
  const pts=item.points||[]; if(!pts.length)return;
  c.save();c.strokeStyle=item.color||ink;c.lineCap='round';c.lineJoin='round';
  if(pts.length===1){c.fillStyle=item.color||ink;c.beginPath();c.arc(pts[0].x,pts[0].y,Math.max(.6,(item.width||4)*(pts[0].p||.5)),0,Math.PI*2);c.fill();}
  else {
    c.beginPath();c.moveTo(pts[0].x,pts[0].y);
    for(let i=1;i<pts.length-1;i++){const midX=(pts[i].x+pts[i+1].x)/2,midY=(pts[i].y+pts[i+1].y)/2;c.quadraticCurveTo(pts[i].x,pts[i].y,midX,midY);}
    const last=pts[pts.length-1];c.lineTo(last.x,last.y);c.lineWidth=item.width||4;c.stroke();
  } c.restore();
}
function drawItem(c,item) {
  if(item.hidden) return;
  c.save(); c.translate(item.x||0,item.y||0);
  if(item.type==='stroke') { c.restore(); drawStroke(c,item); return; }
  if(item.type==='text') {
    const m=textMetrics(item,c), b=m.bounds;
    if(item.background){c.fillStyle=item.background;c.strokeStyle='rgba(30,50,70,.10)';c.lineWidth=1;c.beginPath();c.roundRect(0,0,b.width,b.height,8);c.fill();c.stroke();}
    c.font=`${item.bold?'700':'400'} ${item.fontSize||24}px Tahoma, Arial, sans-serif`;
    c.textBaseline='top';c.fillStyle=item.color||ink;
    m.lines.forEach((line,i)=>c.fillText(line,m.pad,m.pad+i*m.lineHeight));
  } else if(['image','gif','sequence','sticker'].includes(item.type)) {
    let src=item.src;
    if(item.type==='sequence' && item.frames?.length){const fps=Math.max(1,Math.min(30,item.fps||appPrefs.fps||12));src=item.frames[Math.floor((Date.now()-(item.startedAt||0))/(1000/fps))%item.frames.length];}
    let img=imageCache.get(src);
    if(!img){img=new Image();imageCache.set(src,img);img.onload=requestRender;img.src=src;}
    if(img.complete&&img.naturalWidth){c.drawImage(img,0,0,item.width||240,item.height||180);} else {c.fillStyle='#e8edf2';c.fillRect(0,0,item.width||240,item.height||180);c.fillStyle='#72869a';c.font='14px Tahoma';c.fillText('در حال بارگذاری تصویر…',12,22);}
  } else if(item.type==='shape') {
    c.strokeStyle=item.color||ink;c.lineWidth=item.width||3;c.lineCap='round';c.lineJoin='round';
    const dx=item.x2-item.x,dy=item.y2-item.y;
    if(item.shape==='arrow'){
      const angle=Math.atan2(dy,dx), head=14;
      c.beginPath();c.moveTo(0,0);c.lineTo(dx,dy);c.moveTo(dx-head*Math.cos(angle-.48),dy-head*Math.sin(angle-.48));c.lineTo(dx,dy);c.lineTo(dx-head*Math.cos(angle+.48),dy-head*Math.sin(angle+.48));c.stroke();
    } else {c.strokeRect(0,0,dx,dy);}
  }
  c.restore();
}
function render() {
  const r=canvas.getBoundingClientRect(),w=r.width,h=r.height;
  ctx.setTransform(dpr,0,0,dpr,0,0);drawGrid(ctx,w,h);
  const items=(currentBoard?.items||[]).filter(it=>!it.hidden);
  const visibleWorld={x:camera.x-w/(2*camera.scale),y:camera.y-h/(2*camera.scale),width:w/camera.scale,height:h/camera.scale};
  ctx.save();ctx.translate(w/2-camera.x*camera.scale,h/2-camera.y*camera.scale);ctx.scale(camera.scale,camera.scale);
  for(const item of items) { if(overlaps(itemBounds(item),visibleWorld)) drawItem(ctx,item); }
  ctx.restore();
  // Selection bounds are drawn in screen space for stable handles.
  selection.forEach(id=>{
    const item=items.find(v=>v.id===id);if(!item)return;const b=itemBounds(item),a=screenAt(b.x,b.y),z=screenAt(b.x+b.width,b.y+b.height);
    ctx.save();ctx.strokeStyle=flashId===id?'#d18b37':'#2877b8';ctx.lineWidth=flashId===id?2.4:1.4;ctx.setLineDash([5,4]);ctx.strokeRect(a.x-5,a.y-5,z.x-a.x+10,z.y-a.y+10);ctx.setLineDash([]);ctx.restore();
  });
  if(active?.kind==='marquee') {const a=screenAt(active.start.x,active.start.y),b=screenAt(active.current.x,active.current.y);const x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);const el=$('marquee');el.hidden=false;el.style.left=x+'px';el.style.top=y+'px';el.style.width=Math.abs(a.x-b.x)+'px';el.style.height=Math.abs(a.y-b.y)+'px';} else $('marquee').hidden=true;
  $('zoomLabel').textContent=(camera.scale>=10?(camera.scale*100).toFixed(0):camera.scale<0.1?(camera.scale*100).toFixed(4):Math.round(camera.scale*100))+'%';
  $('canvasHint').classList.toggle('hidden',!!items.length);
  if(items.some(it=>it.type==='sequence'||it.type==='gif') && !animationFrameQueued){animationFrameQueued=true;setTimeout(()=>{animationFrameQueued=false;requestRender();},Math.max(16,1000/Math.max(1,Number(appPrefs.fps)||12)));}
}
function currentSnapshot() { return (currentBoard?.items||[]).map(item=>{const copy={...item};if(item.points)copy.points=item.points.map(p=>({...p}));if(item.frames)copy.frames=[...item.frames];return copy;}); }
function pushUndo() {
  if(!currentBoard)return;undoStack.push(currentSnapshot());if(undoStack.length>70)undoStack.shift();redoStack=[];updateUndoUI();
}
function updateUndoUI(){ $('undoBtn').disabled=!undoStack.length;$('redoBtn').disabled=!redoStack.length; }
function undo(){if(!undoStack.length||!currentBoard)return;redoStack.push(currentSnapshot());currentBoard.items=undoStack.pop();selection=[];markDirty();updateUndoUI();requestRender();}
function redo(){if(!redoStack.length||!currentBoard)return;undoStack.push(currentSnapshot());currentBoard.items=redoStack.pop();selection=[];markDirty();updateUndoUI();requestRender();}
function markDirty(){dirty=true;$('dirtyMark').classList.add('on');status('ذخیره‌نشده',false);clearTimeout(saveTimer);saveTimer=setTimeout(saveCurrent,750);}
function openDatabase(){return new Promise((resolve,reject)=>{if(!('indexedDB'in window)){reject(new Error('IndexedDB unavailable'));return;}const req=indexedDB.open(DB_NAME,DB_VERSION);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains('boards'))d.createObjectStore('boards',{keyPath:'id'});if(!d.objectStoreNames.contains('folders'))d.createObjectStore('folders',{keyPath:'id'});if(!d.objectStoreNames.contains('stickers'))d.createObjectStore('stickers',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
function txRequest(store,mode,fn){return new Promise((resolve,reject)=>{try{const tx=db.transaction(store,mode),s=tx.objectStore(store),req=fn(s);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);tx.onabort=()=>reject(tx.error||new Error('Transaction aborted'));}catch(e){reject(e);}});}
async function loadData(){
  try{db=await openDatabase();dbReady=true;const [b,f,st]=await Promise.all([txRequest('boards','readonly',s=>s.getAll()),txRequest('folders','readonly',s=>s.getAll()),txRequest('stickers','readonly',s=>s.getAll())]);
    if(b.length){boards=b;folders=f.length?f:defaults().folders;stickerItems=st||[];}else{const d=defaults();boards=d.boards;folders=d.folders;await persistAll();}
  }catch(e){dbReady=false;try{const raw=localStorage.getItem('infinite-canvas-fallback');memory=raw?JSON.parse(raw):defaults();}catch{memory=defaults();}boards=memory.boards;folders=memory.folders;}
  if(!folders.length)folders=defaults().folders;if(!boards.length)boards=defaults().boards;
  currentBoard=boards.find(b=>b.id===appPrefs.lastBoardId)||boards[0];activeFolder='all';renderNavigation();loadBoardView();
  if(appPrefs.startPage==='last'){showLobby(false);}else{showLobby(true);if(appPrefs.startPage==='folders'&&folders.length)activeFolder=folders[0].id;renderLobby();}
}
async function persistAll(){
  if(dbReady&&db){await Promise.all(boards.map(b=>txRequest('boards','readwrite',s=>s.put(b))));await Promise.all(folders.map(f=>txRequest('folders','readwrite',s=>s.put(f))));}
  else{memory={boards,folders};localStorage.setItem('infinite-canvas-fallback',JSON.stringify(memory));}
}
async function saveCurrent(){
  if(!currentBoard)return;
  try{currentBoard.updatedAt=Date.now();if(dbReady&&db)await txRequest('boards','readwrite',s=>s.put(currentBoard));else{memory={boards,folders};localStorage.setItem('infinite-canvas-fallback',JSON.stringify(memory));}
    dirty=false;$('dirtyMark').classList.remove('on');status('همه تغییرات ذخیره شد',true);
  }catch(e){status('خطا در ذخیره‌سازی',false);showToast('ذخیره‌سازی انجام نشد؛ فضای دستگاه را بررسی کن.');}
}
function loadBoardView(){
  if(!currentBoard)return;appPrefs.lastBoardId=currentBoard.id;savePrefs();$('boardTitle').value=currentBoard.title||'بدون نام';camera={x:0,y:0,scale:1};selection=[];undoStack=[];redoStack=[];updateUndoUI();$('searchPanel').hidden=true;$('searchInput').value='';
  dirty=false;$('dirtyMark').classList.remove('on');status('آماده',true);renderNavigation();requestRender();
}
function renderNavigation(){
  const fl=$('folderList');fl.innerHTML='';
  const all=document.createElement('button');all.className='folder-row'+(activeFolder==='all'?' active':'');all.innerHTML='<span>▦</span><span>همه دفترچه‌ها</span><span class="folder-count">'+boards.length+'</span>';all.onclick=()=>{activeFolder='all';renderNavigation();};fl.append(all);
  folders.forEach(folder=>{const count=boards.filter(b=>b.folderId===folder.id).length;const btn=document.createElement('button');btn.className='folder-row'+(activeFolder===folder.id?' active':'');btn.innerHTML='<span>📁</span><span></span><span class="folder-count">'+count+'</span>';btn.children[1].textContent=folder.name;btn.onclick=()=>{activeFolder=folder.id;renderNavigation();};fl.append(btn);});
  const list=$('boardList');list.innerHTML='';const visible=boards.filter(b=>activeFolder==='all'||b.folderId===activeFolder);$('boardCount').textContent=visible.length;
  visible.forEach(board=>{const btn=document.createElement('button');btn.className='board-row'+(currentBoard?.id===board.id?' active':'');btn.innerHTML='<span class="board-icon">▤</span><span class="board-name"></span>';btn.children[1].textContent=board.title||'بدون نام';btn.onclick=()=>switchBoard(board.id);list.append(btn);});
}
function formatBytes(n){if(n<1024)return n+' B';if(n<1024*1024)return (n/1024).toFixed(1)+' KB';return (n/1024/1024).toFixed(2)+' MB';}
function boardBytes(board){const items=board?.items||[];let n=(board?.title||'').length*2+256;for(const it of items){n+=160+(it.text?new Blob([it.text]).size:0)+(it.src?.length||0)+(it.frames?.reduce((a,x)=>a+x.length,0)||0)+(it.points?.length||0)*36;}return n;}
function estimateLoad(bytes){if(bytes<5*1024*1024)return 'معمولاً سریع؛ اما به دستگاه وابسته است.';if(bytes<25*1024*1024)return 'ممکن است چند ثانیه طول بکشد؛ حدود ۲ تا ۵ ثانیه روی دستگاه‌های متوسط.';return 'یادداشت سنگین است؛ ممکن است بیش از ۵ ثانیه طول بکشد یا در گوشی‌های کم‌حافظه با کمبود RAM روبه‌رو شود.';}
function showLobby(show=true){$('lobby').hidden=!show;if(show){renderLobby();$('sidebar').classList.remove('open');}}
function renderLobby(){if(!$('lobbyBoardList'))return;const query=($('globalSearch')?.value||'').trim().toLocaleLowerCase();const fl=$('lobbyFolderList');fl.innerHTML='';const all=document.createElement('button');all.textContent='▦ همه پوشه‌ها';all.className=activeFolder==='all'?'active':'';all.onclick=()=>{activeFolder='all';renderLobby();};fl.append(all);folders.forEach(f=>{const b=document.createElement('button');b.textContent='📁 '+f.name;b.className=activeFolder===f.id?'active':'';b.onclick=()=>{activeFolder=f.id;renderLobby();};fl.append(b);});const list=$('lobbyBoardList');list.innerHTML='';let hits=[];boards.forEach(board=>{if(activeFolder!=='all'&&board.folderId!==activeFolder)return;const text=board.items.filter(it=>it.type==='text').map(it=>it.text||'').join(' ');if(query&&!(board.title||'').toLocaleLowerCase().includes(query)&&!text.toLocaleLowerCase().includes(query))return;hits.push({board,text});});$('lobbySectionTitle').textContent=query?'نتایج جست‌وجوی سراسری':(activeFolder==='all'?'همه یادداشت‌ها':(folders.find(f=>f.id===activeFolder)?.name||'پوشه'));$('lobbyCount').textContent=hits.length+' یادداشت';if(!hits.length){list.innerHTML='<div class="lobby-empty">یادداشتی با این عبارت پیدا نشد.</div>';return;}hits.forEach(({board,text})=>{const b=document.createElement('button');b.className='lobby-board-card';const size=boardBytes(board);const snippet=query?text.toLocaleLowerCase().includes(query)?text.slice(Math.max(0,text.toLocaleLowerCase().indexOf(query)-30),text.toLocaleLowerCase().indexOf(query)+90):'':(board.items.length+' آیتم');const strong=document.createElement('strong');strong.textContent='▤ '+(board.title||'بدون نام');const small=document.createElement('small');small.textContent=formatBytes(size)+' · '+board.items.length+' آیتم'+(snippet?' · '+snippet.replace(/\s+/g,' ').slice(0,80):'');b.append(strong,small);b.onclick=async()=>{const id=board.id;await switchBoard(id);showLobby(false);if(query){const q=query;const item=currentBoard.items.find(it=>it.type==='text'&&(it.text||'').toLocaleLowerCase().includes(q));if(item)navigateTo(item);}};list.append(b);});}
async function switchBoard(id){if(currentBoard?.id===id){showLobby(false);return;}await saveCurrent();currentBoard=boards.find(b=>b.id===id);loadBoardView();showLobby(false);if(window.innerWidth<=650)$('sidebar').classList.remove('open');}
function createBoard(){const title=prompt('نام دفترچه جدید:', 'دفترچه جدید');if(title===null)return;const b={id:uid(),title:title.trim()||'دفترچه جدید',folderId:activeFolder==='all'?folders[0]?.id:activeFolder,items:[],updatedAt:Date.now()};boards.unshift(b);currentBoard=b;persistAll().then(()=>{loadBoardView();showLobby(false);renderLobby();showToast('دفترچه ساخته شد');});}
function createFolder(){const name=prompt('نام پوشه:','پوشه جدید');if(name===null)return;const folder={id:uid(),name:name.trim()||'پوشه جدید'};folders.push(folder);activeFolder=folder.id;persistAll().then(()=>{renderNavigation();renderLobby();showToast('پوشه ساخته شد');});}
function updateToolUI(){document.querySelectorAll('.tool').forEach(b=>b.classList.toggle('active',b.dataset.tool===tool));workspace.dataset.tool=tool;}
function setTool(t){tool=t;updateToolUI();if(t==='text')showToast('روی نقطه‌ای از بوم بزن تا متن بسازی.');}
function pointerPos(e){const r=canvas.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
function zoomAt(sx,sy,newScale){newScale=clampZoom(newScale);const r=canvas.getBoundingClientRect(),wx=(sx-r.width/2)/camera.scale+camera.x,wy=(sy-r.height/2)/camera.scale+camera.y;camera.scale=newScale;camera.x=wx-(sx-r.width/2)/newScale;camera.y=wy-(sy-r.height/2)/newScale;requestRender();}
function setScaleAtCenter(n){const r=canvas.getBoundingClientRect();zoomAt(r.width/2,r.height/2,n);}
function cancelActiveForGesture(){
  if(!active)return;
  if(active.kind==='draw'||active.kind==='shapePreview'){currentBoard.items=currentBoard.items.filter(it=>it.id!==active.item.id);undoStack.pop();updateUndoUI();}
  else if(active.kind==='move'){active.starts.forEach(st=>{const it=currentBoard.items.find(q=>q.id===st.id);if(!it)return;if(it.type==='shape'){it.x=st.x;it.y=st.y;it.x2=st.x2;it.y2=st.y2;}else if(it.type==='stroke'){it.points=st.points;}else{it.x=st.x;it.y=st.y;}});undoStack.pop();updateUndoUI();}
  else if(active.kind==='erase'&&active.changed)markDirty();
  active=null;requestRender();
}
function pinchStart(){const pts=[...pointers.values()];if(pts.length<2)return;const a=pts[0],b=pts[1],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};const d=Math.hypot(a.x-b.x,a.y-b.y);const r=canvas.getBoundingClientRect();gesture={distance:d,scale:camera.scale,mid,world:{x:(mid.x-r.width/2)/camera.scale+camera.x,y:(mid.y-r.height/2)/camera.scale+camera.y},cam:{x:camera.x,y:camera.y}};active=null;$('marquee').hidden=true;}
function pinchMove(){if(!gesture||pointers.size<2)return;const pts=[...pointers.values()],a=pts[0],b=pts[1],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};const d=Math.hypot(a.x-b.x,a.y-b.y),s=clampZoom(gesture.scale*(d/Math.max(1,gesture.distance))),r=canvas.getBoundingClientRect();camera.scale=s;camera.x=gesture.world.x-(mid.x-r.width/2)/s;camera.y=gesture.world.y-(mid.y-r.height/2)/s;requestRender();}
function startPointer(e){
  if(e.button===2)return;
  e.preventDefault();const p=pointerPos(e);pointers.set(e.pointerId,p);try{canvas.setPointerCapture(e.pointerId);}catch{}
  if(pointers.size>=2){if(!gesture){cancelActiveForGesture();pinchStart();}return;}
  const w=worldAt(p.x,p.y),isPan=tool==='hand'||spaceDown||e.button===1;
  if(isPan){active={kind:'pan',pointerId:e.pointerId,last:p};return;}
  if(tool==='pen') {pushUndo();const point={x:w.x,y:w.y,p:clamp(e.pressure||.5,.1,1)};const item={id:uid(),type:'stroke',color:ink,width:inkWidth,points:[point]};currentBoard.items.push(item);active={kind:'draw',pointerId:e.pointerId,item};requestRender();return;}
  if(tool==='eraser'){pushUndo();active={kind:'erase',pointerId:e.pointerId,changed:false};eraseAt(w);return;}
  if(tool==='text'||tool==='sticky'){pushUndo();const item={id:uid(),type:'text',x:w.x,y:w.y,text:'',fontSize, color:ink,bold:false,width:380,background:tool==='sticky'?'#fff2c9':null,padding:tool==='sticky'?16:3};currentBoard.items.push(item);editingId=item.id;pendingNewText=item.id;active=null;openTextModal(item);setTool('select');return;}
  if(tool==='rect'||tool==='arrow'){pushUndo();const item={id:uid(),type:'shape',shape:tool==='arrow'?'arrow':'rect',x:w.x,y:w.y,x2:w.x,y2:w.y,color:ink,width:inkWidth};currentBoard.items.push(item);active={kind:'shapePreview',pointerId:e.pointerId,item};requestRender();return;}
  if(tool==='select'){
    const hit=[...(currentBoard.items||[])].reverse().find(it=>!it.hidden&&itemHit(it,w));
    if(hit){const groupIds=hit.groupId?currentBoard.items.filter(it=>it.groupId===hit.groupId).map(it=>it.id):[hit.id];if(e.shiftKey){const removing=selection.includes(hit.id);selection=removing?selection.filter(id=>!groupIds.includes(id)):[...new Set([...selection,...groupIds])];}else if(!selection.includes(hit.id))selection=groupIds;
      const movable=selection.map(id=>currentBoard.items.find(q=>q.id===id)).filter(it=>it&&!it.locked&&!it.groupLocked&&!it.hidden);if(movable.length){pushUndo();const starts=movable.map(it=>({id:it.id,x:it.x,y:it.y,x2:it.x2,y2:it.y2,points:it.type==='stroke'?clone(it.points):null}));active={kind:'move',pointerId:e.pointerId,start:w,last:w,starts};}else active=null;requestRender();
    }else{if(!e.shiftKey)selection=[];active={kind:'marquee',pointerId:e.pointerId,start:w,current:w};requestRender();}
  }
}
function movePointer(e){if(!pointers.has(e.pointerId))return;const p=pointerPos(e);pointers.set(e.pointerId,p);if(pointers.size>=2){if(!gesture)pinchStart();pinchMove();return;}if(!active||active.pointerId!==e.pointerId)return;const w=worldAt(p.x,p.y);
  if(active.kind==='pan'){const dx=p.x-active.last.x,dy=p.y-active.last.y;camera.x-=dx/camera.scale;camera.y-=dy/camera.scale;active.last=p;requestRender();}
  else if(active.kind==='draw'){const coalesced=e.getCoalescedEvents?e.getCoalescedEvents():[e];for(const ev of coalesced){const q=worldAt(ev.clientX-canvas.getBoundingClientRect().left,ev.clientY-canvas.getBoundingClientRect().top);active.item.points.push({x:q.x,y:q.y,p:clamp(ev.pressure||.5,.1,1)});}requestRender();}
  else if(active.kind==='erase'){eraseAt(w);}
  else if(active.kind==='move'){const dx=w.x-active.start.x,dy=w.y-active.start.y;active.starts.forEach(s=>{const it=currentBoard.items.find(q=>q.id===s.id);if(it){if(it.type==='shape'){it.x=s.x+dx;it.y=s.y+dy;it.x2=s.x2+dx;it.y2=s.y2+dy;}else if(it.type==='stroke'){it.points=s.points.map(p=>({...p,x:p.x+dx,y:p.y+dy}));}else{it.x=s.x+dx;it.y=s.y+dy;}}});requestRender();}
  else if(active.kind==='marquee'){active.current=w;requestRender();}
  else if(active.kind==='shapePreview'){active.item.x2=w.x;active.item.y2=w.y;requestRender();}
}
function endPointer(e){
  if(pointers.has(e.pointerId))pointers.delete(e.pointerId);
  if(gesture){if(pointers.size<2)gesture=null;active=null;return;}
  if(active&&active.pointerId===e.pointerId){
    if(active.kind==='marquee'){const a={x:Math.min(active.start.x,active.current.x),y:Math.min(active.start.y,active.current.y),width:Math.abs(active.current.x-active.start.x),height:Math.abs(active.current.y-active.start.y)};if(a.width>3||a.height>3)selection=(currentBoard.items||[]).filter(it=>overlaps(itemBounds(it),a)).map(it=>it.id);}
    if(active.kind==='shapePreview'){const it=active.item;if(Math.hypot(it.x2-it.x,it.y2-it.y)<5/camera.scale){it.x2=it.x+80;it.y2=it.y+50;}}
    if(['draw','erase','move','shapePreview'].includes(active.kind))markDirty();
    active=null;requestRender();
  }
}
function eraseAt(p){const items=currentBoard.items;let found=-1;for(let i=items.length-1;i>=0;i--)if(!items[i].hidden&&!items[i].locked&&!items[i].groupLocked&&itemHit(items[i],p)){found=i;break;}if(found>=0){items.splice(found,1);selection=selection.filter(id=>items.some(it=>it.id===id));active.changed=true;requestRender();}}
function openTextModal(item){
  $('textModal').hidden=false;$('textModalTitle').textContent=item.background?'یادداشت رنگی':'ویرایش متن';$('textContent').value=item.text||'';$('fontSizePicker').value=item.fontSize||fontSize;$('fontSizeValue').textContent=$('fontSizePicker').value;$('textColorPicker').value=item.color||ink;$('boldPicker').checked=!!item.bold;setTimeout(()=>$('textContent').focus(),40);
}
function closeTextModal(){ if(pendingNewText){const id=pendingNewText;const it=currentBoard?.items.find(x=>x.id===id);if(it&&!it.text.trim()){currentBoard.items=currentBoard.items.filter(x=>x.id!==id);undoStack.pop();updateUndoUI();requestRender();}} $('textModal').hidden=true;editingId=null;pendingNewText=null; }
function saveTextModal(){
  const value=$('textContent').value.trimEnd();if(!editingId){closeTextModal();return;}
  const item=currentBoard.items.find(it=>it.id===editingId);
  if(item){item.text=value;item.fontSize=Number($('fontSizePicker').value);item.color=$('textColorPicker').value;item.bold=$('boldPicker').checked;if(!value.trim())currentBoard.items=currentBoard.items.filter(it=>it.id!==editingId);else selection=[editingId];pendingNewText=null;markDirty();requestRender();}
  closeTextModal();
}
function fitContent(){const items=(currentBoard?.items||[]).filter(it=>!it.hidden);if(!items.length){camera={x:0,y:0,scale:1};requestRender();return;}let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;items.forEach(it=>{const b=itemBounds(it);minX=Math.min(minX,b.x);minY=Math.min(minY,b.y);maxX=Math.max(maxX,b.x+b.width);maxY=Math.max(maxY,b.y+b.height);});const r=canvas.getBoundingClientRect(),w=Math.max(1,maxX-minX),h=Math.max(1,maxY-minY);camera.scale=clampZoom(Math.min((r.width-120)/w,(r.height-120)/h));camera.x=(minX+maxX)/2;camera.y=(minY+maxY)/2;requestRender();}
function navigateTo(item){const b=itemBounds(item);camera.x=b.x+b.width/2;camera.y=b.y+b.height/2;camera.scale=Math.max(camera.scale,.75);selection=[item.id];flashId=item.id;clearTimeout(flashTimer);flashTimer=setTimeout(()=>{flashId=null;requestRender();},2200);requestRender();}
function search(){const q=$('searchInput').value.trim().toLocaleLowerCase();const out=$('searchResults');out.innerHTML='';if(!q){out.innerHTML='<small>عبارت جست‌وجو را وارد کن.</small>';return;}const hits=(currentBoard?.items||[]).filter(it=>it.type==='text'&&(it.text||'').toLocaleLowerCase().includes(q));if(!hits.length){out.innerHTML='<small>متنی با این عبارت در این دفترچه پیدا نشد.</small>';return;}hits.forEach((it,i)=>{const b=itemBounds(it),btn=document.createElement('button');btn.className='search-result';const excerpt=(it.text||'').replace(/\s+/g,' ').slice(0,110);const page=document.createElement('span');page.className='result-page';page.textContent=`نتیجه ${i+1}`;const sn=document.createElement('span');sn.className='result-snippet';sn.textContent=excerpt;btn.append(page,sn);btn.onclick=()=>navigateTo(it);out.append(btn);});}

function openDetails(){if(!currentBoard)return;const bytes=boardBytes(currentBoard),imgs=currentBoard.items.filter(it=>['image','gif','sequence'].includes(it.type));$('detailsContent').innerHTML='';const rows=[['حجم تقریبی یادداشت',formatBytes(bytes)],['تعداد عناصر',String(currentBoard.items.length)],['تصاویر و توالی‌ها',String(imgs.length)],['زمان بارگذاری تخمینی',estimateLoad(bytes)]];rows.forEach(([k,v])=>{const d=document.createElement('p');d.className='muted-note';const b=document.createElement('b');b.textContent=k+' : ';d.append(b,document.createTextNode(v));$('detailsContent').append(d);});const help=document.createElement('p');help.className='module-info';help.textContent='راهنما: اندازه فایل به‌تنهایی زمان بازشدن را تعیین نمی‌کند؛ تعداد تصاویر، ابعاد پیکسلی، فرمت فشرده‌سازی، حافظه آزاد و سرعت پردازنده نیز مؤثرند. عدد بالا تخمین تقریبی است، نه تضمین.';$('detailsContent').append(help);$('detailsModal').hidden=false;}
function editSelectedText(){const it=currentBoard?.items.find(x=>selection.includes(x.id)&&x.type==='text');if(!it){showToast('ابتدا یک متن را انتخاب کن.');return;}pushUndo();editingId=it.id;pendingNewText=null;openTextModal(it);}
function groupSelected(){if(selection.length<2){showToast('برای گروه‌بندی حداقل دو عنصر را انتخاب کن.');return;}pushUndo();const id=uid();currentBoard.items.filter(it=>selection.includes(it.id)).forEach(it=>it.groupId=id);markDirty();showToast('عناصر انتخاب‌شده در یک گروه قرار گرفتند.');}
function toggleSelectedLock(){const arr=currentBoard?.items.filter(it=>selection.includes(it.id))||[];if(!arr.length){showToast('ابتدا عناصر موردنظر را انتخاب کن.');return;}const next=!arr.every(it=>it.locked||it.groupLocked);pushUndo();arr.forEach(it=>{it.locked=next;});markDirty();requestRender();showToast(next?'گروه قفل شد.':'قفل گروه برداشته شد.');}
function toggleSelectedVisibility(){const arr=currentBoard?.items.filter(it=>selection.includes(it.id))||[];if(!arr.length){showToast('ابتدا عناصر موردنظر را انتخاب کن.');return;}const next=!arr.every(it=>it.hidden);pushUndo();arr.forEach(it=>{it.hidden=next;});if(next)selection=[];imageCache.clear();markDirty();requestRender();showToast(next?'این گروه از رندر بوم خارج شد.':'گروه دوباره بارگذاری می‌شود.');}
function showAllHidden(){if(!currentBoard)return;let n=0;if(currentBoard.items.some(it=>it.hidden))pushUndo();currentBoard.items.forEach(it=>{if(it.hidden){it.hidden=false;n++;}});imageCache.clear();markDirty();requestRender();showToast(n?`${n} عنصر دوباره بارگذاری شد.`:'عنصر مخفی وجود ندارد.');}
function backupAll(){saveCurrent().then(()=>{const data={format:'infinite-canvas-full-backup',version:2,createdAt:new Date().toISOString(),boards,folders,stickers:stickerItems,settings:appPrefs};downloadBlob(new Blob([JSON.stringify(data)],{type:'application/json'}),'infinite-canvas-backup.json');showToast('پشتیبان کامل آماده شد.');});}
function restoreAll(file){const r=new FileReader();r.onload=async()=>{try{const d=JSON.parse(r.result);if(d.format!=='infinite-canvas-full-backup'||!Array.isArray(d.boards)||!d.boards.length||!Array.isArray(d.folders))throw Error('invalid');if(!confirm('بازیابی، دفترچه‌ها و پوشه‌های فعلی را با اطلاعات پشتیبان جایگزین می‌کند. ادامه می‌دهی؟'))return;boards=d.boards;folders=d.folders;stickerItems=Array.isArray(d.stickers)?d.stickers:stickerItems;appPrefs={...appPrefs,...(d.settings||{})};savePrefs();if(dbReady&&db){await Promise.all(['boards','folders','stickers'].map(name=>new Promise((res,rej)=>{const tx=db.transaction(name,'readwrite');tx.objectStore(name).clear();tx.oncomplete=res;tx.onerror=()=>rej(tx.error);})));await persistAll();for(const st of stickerItems)await txRequest('stickers','readwrite',s=>s.put(st));}else await persistAll();currentBoard=boards.find(b=>b.id===appPrefs.lastBoardId)||boards[0];renderNavigation();loadBoardView();showLobby(appPrefs.startPage!=='last');if(appPrefs.startPage==='folders'&&folders.length){activeFolder=folders[0].id;renderLobby();}showToast('بازیابی اطلاعات کامل شد.');}catch(e){showToast('فایل پشتیبان معتبر نیست یا قابل بازیابی نیست.');}};r.readAsText(file);}
function updateSettingsUI(){ $('startPage').value=appPrefs.startPage;$('zoomLimit').value=String(appPrefs.zoomLimit);$('defaultQuality').value=appPrefs.imageQuality;$('qualityValue').textContent=appPrefs.imageQuality+'٪';$('imageLayout').value=appPrefs.imageLayout;$('performanceMode').value=appPrefs.performanceMode;$('defaultFps').value=appPrefs.fps;$('fpsValue').textContent=appPrefs.fps+' FPS';}
function openSettings(){$('settingsModal').hidden=false;updateSettingsUI();}
function saveSettingsFromUI(){appPrefs.startPage=$('startPage').value;appPrefs.zoomLimit=Number($('zoomLimit').value);appPrefs.imageQuality=Number($('defaultQuality').value);appPrefs.imageLayout=$('imageLayout').value;appPrefs.performanceMode=$('performanceMode').value;appPrefs.fps=Number($('defaultFps').value);savePrefs();resizeCanvas();$('settingsModal').hidden=true;requestRender();showToast('تنظیمات ذخیره شد.');}
function imageToDataUrl(file,quality,maxEdge=1800){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(reader.error);reader.onload=()=>{const img=new Image();img.onerror=()=>reject(new Error('تصویر خوانده نشد'));img.onload=()=>{const scale=Math.min(1,maxEdge/Math.max(img.naturalWidth,img.naturalHeight));const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').drawImage(img,0,0,w,h);let data=c.toDataURL('image/webp',quality);if(!data.startsWith('data:image/webp'))data=c.toDataURL('image/jpeg',quality);resolve({src:data,width:w,height:h});};img.src=reader.result;};reader.readAsDataURL(file);});}
async function normalizeSequenceFrames(arr,quality){const maxW=Math.min(900,Math.max(...arr.map(a=>a.width))),maxH=Math.min(900,Math.max(...arr.map(a=>a.height)));const w=Math.max(1,maxW),h=Math.max(1,maxH),frames=[];for(let i=0;i<arr.length;i++){const im=await new Promise((res,rej)=>{const x=new Image();x.onload=()=>res(x);x.onerror=rej;x.src=arr[i].src;});const c=document.createElement('canvas');c.width=w;c.height=h;const ctx2=c.getContext('2d');const k=Math.min(w/im.naturalWidth,h/im.naturalHeight);const dw=im.naturalWidth*k,dh=im.naturalHeight*k;ctx2.drawImage(im,(w-dw)/2,(h-dh)/2,dw,dh);let out=c.toDataURL('image/webp',quality);if(!out.startsWith('data:image/webp'))out=c.toDataURL('image/jpeg',quality);frames.push(out);if(i%3===0)await new Promise(r=>setTimeout(r,0));}return {frames,width:w,height:h};}
function setSelectedFps(){const item=currentBoard?.items.find(it=>selection.includes(it.id)&&it.type==='sequence');if(!item){showToast('ابتدا یک توالی انیمیشنی را انتخاب کن.');return;}const n=Number(prompt('نرخ فریم بین ۱ تا ۳۰ FPS:',String(item.fps||appPrefs.fps)));if(!Number.isFinite(n))return;pushUndo();item.fps=clamp(Math.round(n),1,30);item.startedAt=Date.now();markDirty();requestRender();showToast(`سرعت توالی روی ${item.fps} FPS تنظیم شد.`);}
async function importImages(files,layout,quality){
  const list=[...files].filter(f=>f.type.startsWith('image/'));if(!list.length)return;
  const sequence=layout==='sequence',arr=[];
  pushUndo();
  showToast('ورود تصاویر آغاز شد؛ برنامه را نبند.');
  let cursorX=camera.x,cursorY=camera.y,added=0;selection=[];
  try{
    for(let i=0;i<list.length;i++){
      const f=list[i];let z;
      if(f.type==='image/gif'&&!sequence){
        const data=await new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(r.error);r.readAsDataURL(f);});
        const im=await new Promise((res,rej)=>{const x=new Image();x.onload=()=>res(x);x.onerror=rej;x.src=data;});
        z={src:data,width:im.naturalWidth,height:im.naturalHeight,gif:true,name:f.name};
      }else{
        const cap=appPrefs.performanceMode==='saving'?700:1600;
        const data=await imageToDataUrl(f,quality,cap);z={...data,name:f.name,gif:false};
      }
      if(sequence){arr.push(z);}
      else{
        let w=z.width,h=z.height;const cap=appPrefs.performanceMode==='saving'?600:850;const scale=Math.min(1,cap/Math.max(w,h));w*=scale;h*=scale;
        let x,y;if(layout==='horizontal'){x=cursorX;y=camera.y-h/2;cursorX+=w;}else{x=camera.x-w/2;y=cursorY;cursorY+=h;}
        const item={id:uid(),type:z.gif?'gif':'image',x,y,width:w,height:h,src:z.src,name:z.name,compressedQuality:z.gif?null:Math.round(quality*100)};
        currentBoard.items.push(item);selection.push(item.id);added++;
      }
      if(i%3===0){showToast(`در حال آماده‌سازی ${i+1} از ${list.length} تصویر…`);if(!sequence){markDirty();requestRender();}await new Promise(r=>setTimeout(r,0));}
    }
    if(sequence){
      const normalized=await normalizeSequenceFrames(arr,quality);
      const item={id:uid(),type:'sequence',x:camera.x-normalized.width/2,y:camera.y-normalized.height/2,width:normalized.width,height:normalized.height,frames:normalized.frames,fps:appPrefs.fps,startedAt:Date.now(),name:'توالی '+arr.length+' فریم'};
      currentBoard.items.push(item);selection=[item.id];added=1;
    }
    markDirty();requestRender();$('imageOptionsModal').hidden=true;
    showToast(`${list.length} فایل پردازش شد؛ ${added} عنصر روی بوم قرار گرفت.`);
  }catch(e){console.error(e);if(added){markDirty();requestRender();}showToast(`ورود پس از ${added} عنصر متوقف شد؛ فضای ذخیره یا حافظه دستگاه کافی نبود.`);}
}
async function compressExistingImages(quality,onlySelected=false){const target=(currentBoard?.items||[]).filter(it=>(!onlySelected||selection.includes(it.id))&&!it.locked&&!it.groupLocked&&['image','sticker'].includes(it.type));if(!target.length){showToast('تصویر قابل فشرده‌سازی پیدا نشد. GIF و توالی انیمیشن دست‌نخورده می‌مانند.');return;}const storedChars=(currentBoard?.items||[]).reduce((n,it)=>n+(it.src?.length||0)+(it.frames?.reduce((a,x)=>a+x.length,0)||0),0);const large=target.length>20||storedChars>16*1024*1024;if(!large)pushUndo();let changed=0;try{for(let i=0;i<target.length;i++){const it=target[i];const blob=await fetch(it.src).then(r=>r.blob());const file=new File([blob],it.name||'image.png',{type:blob.type||'image/png'});const nextQ=Math.min(Number(quality)||50,Number(it.compressedQuality)||100);const z=await imageToDataUrl(file,nextQ/100,1800);if(z.src.length<it.src.length){it.src=z.src;it.compressedQuality=nextQ;changed++;}if(i%3===0)await new Promise(r=>setTimeout(r,0));}}catch(e){console.error(e);if(changed){markDirty();imageCache.clear();requestRender();}showToast('فشرده‌سازی زودتر متوقف شد؛ بخشی از تصاویر ممکن است تغییر کرده باشند.');return;}imageCache.clear();if(changed){markDirty();requestRender();}showToast(`${changed} تصویر از ${target.length} تصویر واقعاً کم‌حجم‌تر شد.`+(large?' برای جلوگیری از مصرف شدید حافظه، عملیات در تاریخچه واگرد ثبت نشد.':''));}
function openImageOptions(files){pendingImageFiles=[...files];$('imageSelectionCount').textContent=`${pendingImageFiles.length} فایل تصویری انتخاب شده است.`;$('importLayout').value=appPrefs.imageLayout;$('importQuality').value=appPrefs.imageQuality;$('importQualityValue').textContent=appPrefs.imageQuality+'٪';$('imageOptionsModal').hidden=false;}
function renderStickers(){const grid=$('stickerGrid');grid.innerHTML='';stickerItems.forEach(st=>{const b=document.createElement('button');b.className='sticker-tile';const im=document.createElement('img');im.src=st.src;im.alt=st.name||'استیکر';b.append(im);b.title=st.name||'استیکر';b.onclick=()=>{pushUndo();const item={id:uid(),type:'sticker',x:camera.x-100,y:camera.y-100,width:200,height:200,src:st.src,name:st.name};currentBoard.items.push(item);selection=[item.id];markDirty();requestRender();$('stickerModal').hidden=true;};grid.append(b);});if(!stickerItems.length)grid.innerHTML='<p class="muted-note">هنوز استیکری وارد نشده است.</p>';}
async function addStickers(files){for(const f of files){try{const z=await imageToDataUrl(f,.8,900);const st={id:uid(),name:f.name,src:z.src};stickerItems.push(st);if(dbReady)await txRequest('stickers','readwrite',s=>s.put(st));}catch{}}renderStickers();showToast('استیکرها به مخزن اضافه شدند.');}

function boardExport(){const data={format:'infinite-canvas-notebook',version:1,exportedAt:new Date().toISOString(),board:currentBoard};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});downloadBlob(blob,(currentBoard.title||'notebook').replace(/[\\/:*?"<>|]/g,'_')+'.json');}
function downloadBlob(blob,name){const a=document.createElement('a');const url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1200);}
function importBoard(file){const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(reader.result);if(data.format==='infinite-canvas-full-backup'){restoreAll(new Blob([reader.result],{type:'application/json'}));return;}const b=data.board||data;if(!b||!Array.isArray(b.items))throw new Error('invalid');pushUndo();currentBoard.items=clone(b.items);markDirty();requestRender();showToast('محتوای دفترچه وارد شد');}catch{showToast('فایل انتخاب‌شده فرمت معتبر دفترچه نیست.');}};reader.readAsText(file);}
function addImage(file){if(!file||!file.type.startsWith('image/')){showToast('فقط فایل تصویری پشتیبانی می‌شود.');return;}const reader=new FileReader();reader.onload=()=>{const img=new Image();img.onload=()=>{pushUndo();const max=850,scale=Math.min(1,max/Math.max(img.width,img.height));const w=img.width*scale,h=img.height*scale;const src=reader.result;currentBoard.items.push({id:uid(),type:'image',x:camera.x-w/2,y:camera.y-h/2,width:w,height:h,src,name:file.name});selection=[currentBoard.items[currentBoard.items.length-1].id];markDirty();requestRender();showToast('تصویر به بوم اضافه شد');};img.src=reader.result;};reader.readAsDataURL(file);}
function exportPNG(){
  const items=currentBoard?.items||[];if(!items.length){showToast('بوم خالی است.');return;}let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;items.forEach(it=>{const b=itemBounds(it);minX=Math.min(minX,b.x);minY=Math.min(minY,b.y);maxX=Math.max(maxX,b.x+b.width);maxY=Math.max(maxY,b.y+b.height);});
  const pad=50,w=Math.ceil(maxX-minX+pad*2),h=Math.ceil(maxY-minY+pad*2);if(w*h>40000000){showToast('محتوا بیش از حد بزرگ است؛ ابتدا زوم/محدوده را کوچک کن.');return;}const out=document.createElement('canvas');out.width=Math.max(1,w);out.height=Math.max(1,h);const c=out.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,w,h);c.save();c.translate(pad-minX,pad-minY);items.forEach(it=>drawItem(c,it));c.restore();out.toBlob(async blob=>{if(!blob){showToast('ساخت تصویر ناموفق بود.');return;}const name=(currentBoard.title||'notebook')+'.png';try{if(navigator.share&&navigator.canShare){const f=new File([blob],name,{type:'image/png'});if(navigator.canShare({files:[f]})){await navigator.share({files:[f],title:currentBoard.title||'دفترچه'});return;}}}catch(e){if(e.name==='AbortError')return;}downloadBlob(blob,name);showToast('تصویر آماده شد');},'image/png');
}
function renameBoard(){const name=prompt('نام جدید دفترچه:',currentBoard.title||'');if(name===null)return;currentBoard.title=name.trim()||'بدون نام';$('boardTitle').value=currentBoard.title;markDirty();persistAll();renderNavigation();$('boardMenu').hidden=true;}
function duplicateBoard(){const b=clone(currentBoard);b.id=uid();b.title=(b.title||'دفترچه')+' - کپی';b.updatedAt=Date.now();boards.unshift(b);currentBoard=b;persistAll().then(loadBoardView);$('boardMenu').hidden=true;showToast('یک کپی ساخته شد');}
function deleteBoard(){if(boards.length<2){showToast('حداقل یک دفترچه باید باقی بماند.');return;}if(!confirm(`دفترچه «${currentBoard.title}» حذف شود؟ این کار قابل بازگشت نیست.`))return;const id=currentBoard.id;boards=boards.filter(b=>b.id!==id);currentBoard=boards[0];if(dbReady&&db)txRequest('boards','readwrite',s=>s.delete(id)).then(()=>persistAll());else persistAll();loadBoardView();$('boardMenu').hidden=true;showToast('دفترچه حذف شد');}

// Pointer events separate drawing from gestures: stylus/mouse writes; two touch points pan+zoom.
canvas.addEventListener('dblclick',e=>{const p=pointerPos(e),w=worldAt(p.x,p.y),hit=[...(currentBoard?.items||[])].reverse().find(it=>it.type==='text'&&itemHit(it,w));if(hit){pushUndo();editingId=hit.id;pendingNewText=null;openTextModal(hit);}});
canvas.addEventListener('pointerdown',startPointer);canvas.addEventListener('pointermove',movePointer);canvas.addEventListener('pointerup',endPointer);canvas.addEventListener('pointercancel',endPointer);canvas.addEventListener('lostpointercapture',endPointer);
canvas.addEventListener('wheel',e=>{e.preventDefault();if(e.ctrlKey||e.metaKey){const factor=Math.exp(-e.deltaY*.002);zoomAt(e.offsetX,e.offsetY,camera.scale*factor);}else{camera.x+=e.deltaX/camera.scale;camera.y+=e.deltaY/camera.scale;requestRender();}},{passive:false});
window.addEventListener('resize',resizeCanvas);
document.querySelectorAll('.tool').forEach(b=>b.addEventListener('click',()=>setTool(b.dataset.tool)));
$('colorPicker').addEventListener('input',e=>{ink=e.target.value;});$('widthPicker').addEventListener('input',e=>{inkWidth=Number(e.target.value);$('widthValue').textContent=inkWidth;});
$('fontSizePicker').addEventListener('input',e=>$('fontSizeValue').textContent=e.target.value);
$('newBoardBtn').onclick=createBoard;$('newFolderBtn').onclick=createFolder;$('allBoardsBtn').onclick=()=>{activeFolder='all';renderNavigation();};$('sidebarToggle').onclick=()=>$('sidebar').classList.toggle('open');
$('saveBtn').onclick=saveCurrent;$('exportBtn').onclick=boardExport;$('importBtn').onclick=()=>$('importInput').click();$('importInput').onchange=e=>{if(e.target.files[0])importBoard(e.target.files[0]);e.target.value='';};
$('pngBtn').onclick=exportPNG;$('imageBtn').onclick=()=>$('imageInput').click();$('imageInput').onchange=e=>{if(e.target.files.length)openImageOptions(e.target.files);e.target.value='';};
$('searchBtn').onclick=()=>{$('searchPanel').hidden=!$('searchPanel').hidden;if(!$('searchPanel').hidden)$('searchInput').focus();};$('searchInput').addEventListener('input',search);$('searchClear').onclick=()=>{$('searchInput').value='';$('searchResults').innerHTML='<small>جست‌وجو در متن یادداشت‌ها و نوشته‌ها</small>';};
$('undoBtn').onclick=undo;$('redoBtn').onclick=redo;$('zoomIn').onclick=()=>setScaleAtCenter(camera.scale*1.2);$('zoomOut').onclick=()=>setScaleAtCenter(camera.scale/1.2);$('zoomLabel').onclick=()=>{camera.scale=1;requestRender();};$('fitBtn').onclick=fitContent;
$('boardMenuBtn').onclick=()=>{$('boardMenu').hidden=!$('boardMenu').hidden;};$('renameBoardBtn').onclick=renameBoard;$('duplicateBoardBtn').onclick=duplicateBoard;$('deleteBoardBtn').onclick=deleteBoard;
$('lobbyBtn').onclick=()=>showLobby(true);$('settingsBtn').onclick=openSettings;$('lobbySettings').onclick=openSettings;$('lobbyNewBoard').onclick=createBoard;$('globalSearch').addEventListener('input',renderLobby);$('detailsBtn').onclick=openDetails;$('editTextBtn').onclick=editSelectedText;$('groupBtn').onclick=groupSelected;$('lockBtn').onclick=toggleSelectedLock;$('hideGroupBtn').onclick=toggleSelectedVisibility;$('showHiddenBtn').onclick=showAllHidden;$('compressSelectedBtn').onclick=()=>{const q=Number(prompt('کیفیت هدف برای تصاویر انتخاب‌شده (۱۰ تا ۹۰٪):','40')||40);compressExistingImages(clamp(q,10,90),true);};$('sequenceFpsBtn').onclick=setSelectedFps;$('stickerBtn').onclick=()=>{$('stickerModal').hidden=false;renderStickers();};$('addStickerBtn').onclick=()=>$('stickerInput').click();$('stickerInput').onchange=e=>{if(e.target.files.length)addStickers(e.target.files);e.target.value='';};$('compressNoteBtn').onclick=()=>{const q=Number(prompt('کیفیت جدید از ۱۰ تا ۹۰ درصد:',String(Math.min(70,appPrefs.imageQuality-10)))||50);compressExistingImages(clamp(q,10,90),false);};$('confirmImageImport').onclick=()=>importImages(pendingImageFiles,$('importLayout').value,Number($('importQuality').value)/100);$('importQuality').oninput=e=>$('importQualityValue').textContent=e.target.value+'٪';$('defaultQuality').oninput=e=>$('qualityValue').textContent=e.target.value+'٪';$('defaultFps').oninput=e=>$('fpsValue').textContent=e.target.value+' FPS';$('saveSettingsBtn').onclick=saveSettingsFromUI;$('backupAllBtn').onclick=backupAll;$('restoreAllBtn').onclick=()=>$('backupInput').click();$('backupInput').onchange=e=>{if(e.target.files[0])restoreAll(e.target.files[0]);e.target.value='';};document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).hidden=true));$('settingsModal').addEventListener('click',e=>{if(e.target===$('settingsModal'))$('settingsModal').hidden=true;});$('imageOptionsModal').addEventListener('click',e=>{if(e.target===$('imageOptionsModal'))$('imageOptionsModal').hidden=true;});$('detailsModal').addEventListener('click',e=>{if(e.target===$('detailsModal'))$('detailsModal').hidden=true;});$('stickerModal').addEventListener('click',e=>{if(e.target===$('stickerModal'))$('stickerModal').hidden=true;});
 document.addEventListener('click',e=>{const menu=$('boardMenu');if(!menu.hidden&&!menu.contains(e.target)&&e.target!==$('boardMenuBtn'))menu.hidden=true;const sp=$('searchPanel');if(!sp.hidden&&!sp.contains(e.target)&&e.target!==$('searchBtn'))sp.hidden=true;const side=$('sidebar');if(side.classList.contains('open')&&!side.contains(e.target)&&e.target!==$('sidebarToggle'))side.classList.remove('open');});
$('boardTitle').addEventListener('change',()=>{currentBoard.title=$('boardTitle').value.trim()||'بدون نام';markDirty();renderNavigation();});
$('textSave').onclick=saveTextModal;$('textCancel').onclick=closeTextModal;$('textCancelTop').onclick=closeTextModal;$('textModal').addEventListener('click',e=>{if(e.target===$('textModal'))closeTextModal();});
window.addEventListener('keydown',e=>{
  if(e.key==='Escape'){if(!$('textModal').hidden)closeTextModal();$('boardMenu').hidden=true;$('searchPanel').hidden=true;document.querySelectorAll('.modal-backdrop').forEach(m=>m.hidden=true);showLobby(false);return;}
  if(e.target.matches('input,textarea,select'))return;
  if(e.code==='Space'){spaceDown=true;workspace.style.cursor='grab';e.preventDefault();}
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();saveCurrent();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo();}
  else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo();}
  else if(e.key==='Delete'||e.key==='Backspace'){if(selection.length){const deletable=currentBoard.items.filter(it=>selection.includes(it.id)&&!it.locked&&!it.groupLocked);if(deletable.length){pushUndo();const ids=new Set(deletable.map(it=>it.id));currentBoard.items=currentBoard.items.filter(it=>!ids.has(it.id));selection=[];markDirty();requestRender();}else showToast('عناصر انتخاب‌شده قفل هستند.');}}
  else if(e.key.toLowerCase()==='v')setTool('select');else if(e.key.toLowerCase()==='p')setTool('pen');else if(e.key.toLowerCase()==='e')setTool('eraser');else if(e.key.toLowerCase()==='t')setTool('text');else if(e.key.toLowerCase()==='h')setTool('hand');
});
window.addEventListener('keyup',e=>{if(e.code==='Space'){spaceDown=false;workspace.style.cursor='';}});
window.addEventListener('beforeunload',()=>{if(dirty){try{localStorage.setItem('infinite-canvas-emergency',JSON.stringify({boards,folders}));}catch{}}});

resizeCanvas();updateToolUI();loadData().then(()=>{let emergency=null;try{emergency=localStorage.getItem('infinite-canvas-emergency');}catch{}if(emergency){try{const x=JSON.parse(emergency);if(x.boards?.some(b=>b.id===currentBoard.id)){boards=x.boards;folders=x.folders||folders;currentBoard=boards.find(b=>b.id===currentBoard.id)||boards[0];loadBoardView();localStorage.removeItem('infinite-canvas-emergency');}}catch{}}});
if('serviceWorker'in navigator && /^https?:$/.test(location.protocol)){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
})();
