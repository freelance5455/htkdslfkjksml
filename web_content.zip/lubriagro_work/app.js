let equipamentos = [];
let manutencoes = [];
let lubrificacoes = [];

const CHAVES = {
    equipamentos: "lubriagro_equipamentos",
    manutencoes: "lubriagro_manutencoes",
    lubrificacoes: "lubriagro_lubrificacoes",
    login: "lubriagro_login"
};

document.addEventListener("DOMContentLoaded", () => {
    carregarDados();
    configurarFormularios();
    verificarLogin();
    atualizarTudo();
    colocarDataAtual();
});

function carregarDados() {
    equipamentos = JSON.parse(localStorage.getItem(CHAVES.equipamentos) || "[]");
    manutencoes = JSON.parse(localStorage.getItem(CHAVES.manutencoes) || "[]");
    lubrificacoes = JSON.parse(localStorage.getItem(CHAVES.lubrificacoes) || "[]");
}

function salvarDados() {
    localStorage.setItem(CHAVES.equipamentos, JSON.stringify(equipamentos));
    localStorage.setItem(CHAVES.manutencoes, JSON.stringify(manutencoes));
    localStorage.setItem(CHAVES.lubrificacoes, JSON.stringify(lubrificacoes));
}

function verificarLogin() {
    const logado = localStorage.getItem(CHAVES.login) === "sim";
    document.getElementById("telaLogin").style.display = logado ? "none" : "flex";
    document.getElementById("app").classList.toggle("app-escondido", !logado);
}

document.getElementById("formLogin").addEventListener("submit", function(e) {
    e.preventDefault();
    const email = document.getElementById("loginEmail").value.trim();
    const senha = document.getElementById("loginSenha").value.trim();
    if (!email || senha.length < 3) {
        mostrarMensagem("Atenção", "Informe um e-mail e uma senha válida.");
        return;
    }
    localStorage.setItem(CHAVES.login, "sim");
    verificarLogin();
});

function entrarDemo() {
    localStorage.setItem(CHAVES.login, "sim");
    verificarLogin();
}

function sair() {
    localStorage.removeItem(CHAVES.login);
    document.getElementById("app").classList.add("app-escondido");
    document.getElementById("telaLogin").style.display = "flex";
}

function abrirTela(nome) {
    document.querySelectorAll(".tela").forEach(t => t.classList.remove("ativa"));
    const mapa = {
        inicio: "telaInicio",
        equipamentos: "telaEquipamentos",
        manutencoes: "telaManutencoes",
        lubrificacao: "telaLubrificacao",
        historico: "telaHistorico",
        alertas: "telaAlertas",
        relatorios: "telaRelatorios"
    };
    const tela = document.getElementById(mapa[nome] || "telaInicio");
    tela.classList.add("ativa");
    atualizarTudo();
    window.scrollTo({top: 0, behavior: "smooth"});
}

function configurarFormularios() {
    document.getElementById("formEquipamento").addEventListener("submit", salvarEquipamento);
    document.getElementById("formManutencao").addEventListener("submit", salvarManutencao);
    document.getElementById("formLubrificacao").addEventListener("submit", salvarLubrificacao);
}

function abrirFormularioEquipamento() {
    document.getElementById("formEquipamento").classList.remove("escondido");
    document.getElementById("formEquipamento").scrollIntoView({behavior:"smooth"});
}

function abrirFormularioManutencao() {
    atualizarSelects();
    document.getElementById("formManutencao").classList.remove("escondido");
    document.getElementById("dataManutencao").value = hoje();
    document.getElementById("formManutencao").scrollIntoView({behavior:"smooth"});
}

function abrirFormularioLubrificacao() {
    atualizarSelects();
    document.getElementById("formLubrificacao").classList.remove("escondido");
    document.getElementById("dataLubrificacao").value = hoje();
    document.getElementById("formLubrificacao").scrollIntoView({behavior:"smooth"});
}

function fecharForm(id) {
    document.getElementById(id).classList.add("escondido");
    document.getElementById(id).reset();
}

function salvarEquipamento(e) {
    e.preventDefault();
    const id = document.getElementById("equipamentoId").value;
    const dados = {
        id: id || Date.now().toString(),
        nome: valor("nomeEquipamento"),
        tipo: valor("tipoEquipamento"),
        marca: valor("marcaEquipamento"),
        modelo: valor("modeloEquipamento"),
        ano: valor("anoEquipamento"),
        identificacao: valor("identificacaoEquipamento"),
        horimetro: numero("horimetroEquipamento"),
        criadoEm: new Date().toISOString()
    };
    if (id) {
        const i = equipamentos.findIndex(x => x.id === id);
        if (i >= 0) equipamentos[i] = {...equipamentos[i], ...dados};
    } else {
        equipamentos.push(dados);
    }
    salvarDados();
    fecharForm("formEquipamento");
    atualizarTudo();
    mostrarMensagem("Equipamento salvo", "O equipamento foi cadastrado com sucesso.");
}

function editarEquipamento(id) {
    const e = equipamentos.find(x => x.id === id);
    if (!e) return;
    document.getElementById("equipamentoId").value = e.id;
    document.getElementById("nomeEquipamento").value = e.nome;
    document.getElementById("tipoEquipamento").value = e.tipo;
    document.getElementById("marcaEquipamento").value = e.marca;
    document.getElementById("modeloEquipamento").value = e.modelo;
    document.getElementById("anoEquipamento").value = e.ano;
    document.getElementById("identificacaoEquipamento").value = e.identificacao;
    document.getElementById("horimetroEquipamento").value = e.horimetro;
    document.getElementById("formEquipamento").classList.remove("escondido");
    window.scrollTo({top: 0, behavior:"smooth"});
}

function excluirEquipamento(id) {
    if (!confirm("Excluir este equipamento? O histórico dele também será removido.")) return;
    equipamentos = equipamentos.filter(x => x.id !== id);
    manutencoes = manutencoes.filter(x => x.equipamentoId !== id);
    lubrificacoes = lubrificacoes.filter(x => x.equipamentoId !== id);
    salvarDados();
    atualizarTudo();
}

function salvarManutencao(e) {
    e.preventDefault();
    const registro = {
        id: Date.now().toString(),
        equipamentoId: valor("manutencaoEquipamento"),
        tipo: valor("tipoManutencao"),
        data: valor("dataManutencao"),
        horimetro: numero("horimetroManutencao"),
        produto: valor("produtoManutencao"),
        quantidade: numero("quantidadeManutencao"),
        valor: numero("valorManutencao"),
        observacao: valor("observacaoManutencao")
    };
    manutencoes.push(registro);
    atualizarHorimetro(registro.equipamentoId, registro.horimetro);
    salvarDados();
    fecharForm("formManutencao");
    atualizarTudo();
    mostrarMensagem("Manutenção registrada", "O serviço foi adicionado ao histórico do equipamento.");
}

function salvarLubrificacao(e) {
    e.preventDefault();
    lubrificacoes.push({
        id: Date.now().toString(),
        equipamentoId: valor("lubrificacaoEquipamento"),
        ponto: valor("pontoLubrificacao"),
        produto: valor("produtoLubrificacao"),
        horimetro: numero("horimetroLubrificacao"),
        data: valor("dataLubrificacao"),
        observacao: valor("observacaoLubrificacao")
    });
    salvarDados();
    fecharForm("formLubrificacao");
    atualizarTudo();
    mostrarMensagem("Lubrificação registrada", "O registro foi adicionado ao histórico.");
}

function atualizarHorimetro(id, h) {
    const e = equipamentos.find(x => x.id === id);
    if (e && h > Number(e.horimetro || 0)) e.horimetro = h;
}

function atualizarSelects() {
    const selects = ["manutencaoEquipamento", "lubrificacaoEquipamento"];
    selects.forEach(id => {
        const s = document.getElementById(id);
        const atual = s.value;
        s.innerHTML = '<option value="">Selecione o equipamento</option>' +
            equipamentos.map(e => `<option value="${e.id}">${esc(e.nome)}${e.identificacao ? " — " + esc(e.identificacao) : ""}</option>`).join("");
        s.value = atual;
    });
}

function renderEquipamentos() {
    const box = document.getElementById("listaEquipamentos");
    if (!equipamentos.length) {
        box.innerHTML = vazio("🚜", "Nenhum equipamento cadastrado", "Cadastre a primeira máquina para começar.");
        return;
    }
    box.innerHTML = equipamentos.map(e => {
        const total = manutencoes.filter(m => m.equipamentoId === e.id).length;
        return `<article class="item-card">
            <div class="item-topo"><div class="item-icone">🚜</div><div class="item-info">
                <h3>${esc(e.nome)}</h3>
                <p>${esc(e.tipo)} ${e.marca ? "• " + esc(e.marca) : ""} ${e.modelo ? "• " + esc(e.modelo) : ""}</p>
                <p>⏱️ Horímetro: <strong>${fmtNum(e.horimetro)} h</strong></p>
                <p>📋 ${total} registro(s) de manutenção</p>
            </div></div>
            <div class="item-acoes">
                <button class="botao-pequeno botao-editar" onclick="verHistoricoEquipamento('${e.id}')">📋 Histórico</button>
                <button class="botao-pequeno botao-editar" onclick="editarEquipamento('${e.id}')">✏️ Editar</button>
                <button class="botao-pequeno botao-excluir" onclick="excluirEquipamento('${e.id}')">Excluir</button>
            </div>
        </article>`;
    }).join("");
}

function renderManutencoes() {
    const box = document.getElementById("listaManutencoes");
    const lista = [...manutencoes].sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    if (!lista.length) {
        box.innerHTML = vazio("🔧", "Nenhuma manutenção registrada", "Os serviços aparecerão aqui.");
        return;
    }
    box.innerHTML = lista.map(m => {
        const e = equipamento(m.equipamentoId);
        return `<article class="item-card">
            <div class="item-topo"><div class="item-icone">🔧</div><div class="item-info">
                <h3>${esc(e?.nome || "Equipamento removido")}</h3>
                <p><strong>${esc(m.tipo)}</strong></p>
                <p>📅 ${dataBR(m.data)} • ⏱️ ${fmtNum(m.horimetro)} h</p>
                ${m.produto ? `<p>🧰 ${esc(m.produto)} ${m.quantidade ? "• " + fmtNum(m.quantidade) : ""}</p>` : ""}
                <p class="valor">💰 ${moeda(m.valor)}</p>
                ${m.observacao ? `<p>${esc(m.observacao)}</p>` : ""}
            </div></div>
        </article>`;
    }).join("");
}

function renderLubrificacoes() {
    const box = document.getElementById("listaLubrificacoes");
    const lista = [...lubrificacoes].sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    if (!lista.length) {
        box.innerHTML = vazio("🧴", "Nenhuma lubrificação registrada", "Registre os pontos lubrificados.");
        return;
    }
    box.innerHTML = lista.map(l => {
        const e = equipamento(l.equipamentoId);
        return `<article class="item-card"><div class="item-topo"><div class="item-icone">🧴</div><div class="item-info">
            <h3>${esc(e?.nome || "Equipamento removido")}</h3>
            <p>📍 ${esc(l.ponto)}</p><p>🧴 ${esc(l.produto || "Produto não informado")}</p>
            <p>📅 ${dataBR(l.data)} ${l.horimetro ? "• ⏱️ " + fmtNum(l.horimetro) + " h" : ""}</p>
            ${l.observacao ? `<p>${esc(l.observacao)}</p>` : ""}
        </div></div></article>`;
    }).join("");
}

function renderHistorico() {
    const filtro = document.getElementById("filtroHistorico");
    filtro.innerHTML = `<select onchange="renderHistorico()" id="historicoEquipamento"><option value="">Todos os equipamentos</option>${equipamentos.map(e => `<option value="${e.id}">${esc(e.nome)}</option>`).join("")}</select>`;
    const id = document.getElementById("historicoEquipamento").value;
    const eventos = [];
    manutencoes.forEach(m => { if (!id || m.equipamentoId === id) eventos.push({...m, categoria:"Manutenção"}); });
    lubrificacoes.forEach(l => { if (!id || l.equipamentoId === id) eventos.push({...l, categoria:"Lubrificação"}); });
    eventos.sort((a,b) => (b.data || "").localeCompare(a.data || ""));
    const box = document.getElementById("listaHistorico");
    if (!eventos.length) {
        box.innerHTML = vazio("📋", "Histórico vazio", "Selecione um equipamento ou registre um serviço.");
        return;
    }
    box.innerHTML = eventos.map(x => {
        const e = equipamento(x.equipamentoId);
        const titulo = x.categoria === "Manutenção" ? x.tipo : "Lubrificação — " + x.ponto;
        return `<article class="historico-item"><div class="linha-icone">${x.categoria === "Manutenção" ? "🔧" : "🧴"}</div><div><strong>${esc(titulo)}</strong><p>${esc(e?.nome || "Equipamento removido")}</p><small>📅 ${dataBR(x.data)} ${x.horimetro ? "• ⏱️ " + fmtNum(x.horimetro) + " h" : ""}</small>${x.valor ? `<small>💰 ${moeda(x.valor)}</small>` : ""}</div></article>`;
    }).join("");
}

function verHistoricoEquipamento(id) {
    abrirTela("historico");
    setTimeout(() => {
        const select = document.getElementById("historicoEquipamento");
        if (select) { select.value = id; renderHistorico(); }
    }, 50);
}

function renderAlertas() {
    const box = document.getElementById("listaAlertas");
    const alertas = [];
    equipamentos.forEach(e => {
        const trocas = manutencoes.filter(m => m.equipamentoId === e.id && m.tipo === "Troca de óleo").sort((a,b) => b.horimetro - a.horimetro);
        const ultima = trocas[0];
        const base = ultima ? Number(ultima.horimetro) : 0;
        const atual = Number(e.horimetro || 0);
        const restante = 250 - (atual - base);
        if (!ultima) alertas.push({e, texto:"Ainda não há troca de óleo registrada.", classe:"atrasado"});
        else if (restante <= 0) alertas.push({e, texto:`Troca de óleo atrasada em ${Math.abs(restante).toFixed(0)} h.`, classe:"atrasado"});
        else if (restante <= 50) alertas.push({e, texto:`Troca de óleo próxima: faltam ${restante.toFixed(0)} h.`, classe:""});
    });
    if (!alertas.length) {
        box.innerHTML = vazio("✅", "Tudo em dia", "Nenhum alerta de troca de óleo no momento.");
        return;
    }
    box.innerHTML = alertas.map(a => `<article class="alerta-card ${a.classe}"><div class="item-icone">⚠️</div><h3>${esc(a.e.nome)}</h3><p>${esc(a.texto)}</p><small>Horímetro atual: ${fmtNum(a.e.horimetro)} h</small></article>`).join("");
}

function renderRelatorios() {
    const tipos = {};
    manutencoes.forEach(m => tipos[m.tipo] = (tipos[m.tipo] || 0) + 1);
    const custos = {};
    manutencoes.forEach(m => {
        const e = equipamento(m.equipamentoId);
        const nome = e?.nome || "Outros";
        custos[nome] = (custos[nome] || 0) + Number(m.valor || 0);
    });
    renderGrafico("graficoTipos", tipos, "registros", false);
    renderGrafico("graficoCustos", custos, "R$", true);

    const total = manutencoes.reduce((s,m)=>s+Number(m.valor||0),0);
    const qtd = manutencoes.length;
    document.getElementById("resumoFinanceiro").innerHTML = `<div><span>Total gasto</span><strong>${moeda(total)}</strong></div><div><span>Manutenções</span><strong>${qtd}</strong></div><div><span>Custo médio</span><strong>${moeda(qtd ? total/qtd : 0)}</strong></div>`;
    renderTabelaRelatorioEquipamentos();
}

function dadosRelatorioEquipamentos() {
    return equipamentos.map(e => {
        const regsLub = lubrificacoes.filter(l => l.equipamentoId === e.id).sort((a,b) => (b.data || "").localeCompare(a.data || ""));
        const regsMan = manutencoes.filter(m => m.equipamentoId === e.id).sort((a,b) => (b.data || "").localeCompare(a.data || ""));
        const ultimaLub = regsLub[0];
        const ultimaMan = regsMan[0];
        const pendencias = [];
        if (!ultimaLub) pendencias.push("Lubrificação em falta");
        if (!ultimaMan) pendencias.push("Manutenção em falta");
        return {
            equipamento: e,
            ultimaLub,
            ultimaMan,
            statusLub: ultimaLub ? "Realizada" : "Em falta",
            statusMan: ultimaMan ? "Realizada" : "Em falta",
            pendencias: pendencias.length ? pendencias.join("; ") : "Sem falta de registro"
        };
    });
}

function renderTabelaRelatorioEquipamentos() {
    const tbody = document.getElementById("corpoRelatorioEquipamentos");
    const resumo = document.getElementById("resumoStatusEquipamentos");
    if (!tbody || !resumo) return;
    const linhas = dadosRelatorioEquipamentos();
    const faltaLub = linhas.filter(x => !x.ultimaLub).length;
    const faltaMan = linhas.filter(x => !x.ultimaMan).length;
    const completos = linhas.filter(x => x.ultimaLub && x.ultimaMan).length;
    resumo.innerHTML = `<div><strong>${linhas.length}</strong><span>Equipamentos</span></div><div class="status-ok"><strong>${completos}</strong><span>Com os dois registros</span></div><div class="status-falta"><strong>${faltaLub}</strong><span>Sem lubrificação registrada</span></div><div class="status-falta"><strong>${faltaMan}</strong><span>Sem manutenção registrada</span></div>`;
    if (!linhas.length) {
        tbody.innerHTML = `<tr><td colspan="7" class="tabela-vazia">Nenhum equipamento cadastrado. Cadastre equipamentos para montar o relatório.</td></tr>`;
        return;
    }
    tbody.innerHTML = linhas.map(x => {
        const e = x.equipamento;
        const nome = esc(e.nome || "Sem nome");
        const ident = esc(e.identificacao || "—");
        const dataLub = x.ultimaLub ? dataBR(x.ultimaLub.data) : "—";
        const dataMan = x.ultimaMan ? dataBR(x.ultimaMan.data) : "—";
        const lubClass = x.ultimaLub ? "status-celula ok" : "status-celula falta";
        const manClass = x.ultimaMan ? "status-celula ok" : "status-celula falta";
        return `<tr><td><strong>${nome}</strong><small>${esc([e.marca,e.modelo].filter(Boolean).join(" ") || e.tipo || "")}</small></td><td>${ident}</td><td>${dataLub}</td><td><span class="${lubClass}">${x.statusLub}</span></td><td>${dataMan}</td><td><span class="${manClass}">${x.statusMan}</span></td><td>${esc(x.pendencias)}</td></tr>`;
    }).join("");
}

function exportarRelatorioCSV() {
    const linhas = dadosRelatorioEquipamentos();
    if (!linhas.length) {
        mostrarMensagem("Relatório vazio", "Cadastre pelo menos um equipamento antes de exportar.");
        return;
    }
    const cabecalho = ["Equipamento", "Tipo", "Marca", "Modelo", "Identificacao", "Horimetro", "Ultima lubrificacao", "Status lubrificacao", "Ultima manutencao", "Status manutencao", "Pendencias"];
    const csvEsc = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const registros = linhas.map(x => [x.equipamento.nome, x.equipamento.tipo, x.equipamento.marca, x.equipamento.modelo, x.equipamento.identificacao, x.equipamento.horimetro, x.ultimaLub ? dataBR(x.ultimaLub.data) : "Sem registro", x.statusLub, x.ultimaMan ? dataBR(x.ultimaMan.data) : "Sem registro", x.statusMan, x.pendencias]);
    const conteudo = "\uFEFF" + [cabecalho, ...registros].map(row => row.map(csvEsc).join(";")).join("\r\n");
    const blob = new Blob([conteudo], {type: "text/csv;charset=utf-8;"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "relatorio_equipamentos_lubriagro.csv";
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

function imprimirRelatorio() {
    abrirTela("relatorios");
    setTimeout(() => window.print(), 150);
}

function renderGrafico(id, dados, unidade, dinheiro) {
    const box = document.getElementById(id);
    const entries = Object.entries(dados).sort((a,b)=>b[1]-a[1]);
    if (!entries.length) { box.innerHTML = `<div class="sem-grafico">Sem dados suficientes para gerar o gráfico.</div>`; return; }
    const max = Math.max(...entries.map(x=>x[1]), 1);
    box.innerHTML = entries.map(([nome,val]) => `<div class="barra-linha"><div class="barra-label"><span>${esc(nome)}</span><strong>${dinheiro ? moeda(val) : val + " " + unidade}</strong></div><div class="barra-fundo"><div class="barra" style="width:${Math.max(4,(val/max)*100)}%"></div></div></div>`).join("");
}

function atualizarTudo() {
    document.getElementById("totalEquipamentos").textContent = equipamentos.length;
    document.getElementById("totalManutencoes").textContent = manutencoes.length;
    document.getElementById("totalAlertas").textContent = contarAlertas();
    renderEquipamentos();
    renderManutencoes();
    renderLubrificacoes();
    renderHistorico();
    renderAlertas();
    renderRelatorios();
    atualizarSelects();
}

function contarAlertas() {
    let n = 0;
    equipamentos.forEach(e => {
        const trocas = manutencoes.filter(m => m.equipamentoId === e.id && m.tipo === "Troca de óleo").sort((a,b)=>b.horimetro-a.horimetro);
        const base = trocas[0] ? Number(trocas[0].horimetro) : 0;
        const restante = 250 - (Number(e.horimetro||0)-base);
        if (!trocas[0] || restante <= 50) n++;
    });
    return n;
}

function equipamento(id) { return equipamentos.find(e => e.id === id); }
function valor(id) { return document.getElementById(id).value.trim(); }
function numero(id) { return Number(document.getElementById(id).value || 0); }
function hoje() { return new Date().toISOString().slice(0,10); }
function colocarDataAtual() {
    ["dataManutencao","dataLubrificacao"].forEach(id => { const el=document.getElementById(id); if(el) el.value=hoje(); });
}
function dataBR(s) { if(!s) return "Data não informada"; const p=s.split("-"); return p.length===3 ? `${p[2]}/${p[1]}/${p[0]}` : s; }
function moeda(v) { return Number(v||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"}); }
function fmtNum(v) { return Number(v||0).toLocaleString("pt-BR",{maximumFractionDigits:1}); }
function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c])); }
function vazio(icone,titulo,texto) { return `<div class="lista-vazia"><div class="vazio-icone">${icone}</div><strong>${titulo}</strong><p>${texto}</p></div>`; }
function mostrarMensagem(titulo,texto) {
    document.getElementById("mensagemTitulo").textContent = titulo;
    document.getElementById("mensagemTexto").textContent = texto;
    document.getElementById("mensagem").classList.add("visivel");
}
function fecharMensagem() { document.getElementById("mensagem").classList.remove("visivel"); }
