const $=s=>document.querySelector(s),LS='habits.v1',DN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const o=(x,y,r)=>`M${x-r} ${y}a${r} ${r} 0 1 0 ${2*r} 0a${r} ${r} 0 1 0 ${-2*r} 0`;
const IC={today:'M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9',habits:o(12,9,6)+'M8.5 14.5L7 22l5-3 5 3-1.5-7.5',tasks:'M4 6l1.5 1.5L8 5M4 13l1.5 1.5L8 12M11 6h9M11 13h9M4 20h.01M11 20h9',cats:'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',set:'M4 7h9M17 7h3M4 17h3M11 17h9'+o(15,7,2)+o(9,17,2),
plus:'M12 5v14M5 12h14',check:'M5 12l5 5 9-10',x:'M6 6l12 12M18 6L6 18',lock:'M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3',chev:'M15 5l-7 7 7 7',trash:'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',cal:'M4 6h16v14H4zM8 3v4M16 3v4M4 11h16',
run:o(14,4,2)+'M8 21l3-6-2-3 3-3 3 3h3M8 12l-3 1M12 15l3 2 1 4',dumb:'M6 8v8M3 10v4M18 8v8M21 10v4M6 12h12',cap:'M2 9l10-5 10 5-10 5zM6 11v5c0 1.5 3 3 6 3s6-1.5 6-3v-5',book:'M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11',
drop:'M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z',med:o(12,5,2)+'M12 8v5M8 11h8M5 19c2-5 4-6 7-6s5 1 7 6',apple:'M12 7c-2-2-6-1-6 4 0 5 3 9 6 9s6-4 6-9c0-5-4-6-6-4zM12 7c0-2 1-3 3-4',moon:'M20 14A8 8 0 1 1 10 4a6 6 0 0 0 10 10z',laptop:'M5 6h14v9H5zM3 19h18',
music:'M9 18V6l10-2v12'+o(6,18,3)+o(16,16,3),block:o(12,12,9)+'M5.6 5.6l12.8 12.8',coin:'M12 4v16M16 8c-1-1.5-2.5-2-4-2-2 0-3.5 1-3.5 2.5S10 11 12 11.5s3.5 1 3.5 2.5S14 18 12 18c-1.5 0-3-.5-4-2',home:'M4 11l8-7 8 7M6 10v10h12V10',
heart:'M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.5A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z',pen:'M4 20l4-1L19 8l-3-3L5 16zM14 7l3 3',bike:o(6,16,3.5)+o(18,16,3.5)+'M6 16l4-8h5l3 8M10 8L9 5H7',star:'M12 3l2.8 5.8 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.7l6.2-.9z',
chat:'M4 5h16v11H9l-5 4z',brief:'M4 8h16v11H4zM9 8V5h6v3M4 13h16',mtn:'M3 19l6-11 4 7 3-4 5 8z',fork:'M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 3c-2 2-3 5-3 8h3v10',dna:'M7 3c0 6 10 6 10 12s-10 6-10 6M17 3c0 6-10 6-10 12M8 7h8M8 17h8',
sun:o(12,12,4)+'M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2',bolt:'M13 2L4 14h7l-1 8 9-12h-7z',flag:'M5 21V4M5 4h11l-2 4 2 4H5',flame:'M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 2 1.5 2C10 8 11 5 12 3z',
target:o(12,12,9)+o(12,12,5)+o(12,12,1),trophy:'M8 4h8v5a4 4 0 0 1-8 0zM8 6H4v1a3 3 0 0 0 4 3M16 6h4v1a3 3 0 0 1-4 3M12 13v4M8 21h8M10 17h4',award:o(12,9,6)+'M8.5 14.5L7 22l5-3 5 3-1.5-7.5',crown:'M3 8l4 4 5-7 5 7 4-4-2 11H5z'};
const ico=(k,z=22)=>`<svg class=i viewBox="0 0 24 24" width=${z} height=${z} fill=none stroke=currentColor stroke-width=2 stroke-linecap=round stroke-linejoin=round><path d="${IC[k]||IC.star}"/></svg>`;
const DC=[['Quit a bad habit','block','#e0364a'],['Art','pen','#e0546a'],['Meditation','med','#d63fb4'],['Exercise','run','#8a6be0'],['Study','cap','#8a5be0'],['Neuro Plasticity','dna','#8a6be0'],['Sports','bike','#5b7be0'],['Mind','heart','#5b8be0'],['Entertainment','star','#2a9db0'],['Social','chat','#2fb58a'],['Finance','coin','#34b35a'],['Health','plus','#8bc34a'],['Work','brief','#a5c034'],['Muscles','dumb','#a5c034'],['Nutrition','fork','#f0a020'],['Home','home','#f08a20'],['Outdoor','mtn','#e0703a'],['Other','cats','#e0603a']];
let mem=null,warned=0;
const ld=()=>{try{return localStorage.getItem(LS)}catch(e){return mem}};
const sv=x=>{mem=x;try{localStorage.setItem(LS,x)}catch(e){if(!warned){warned=1;toast('Storage is blocked here, so data is lost on close. Open index.html in Chrome to keep it.')}}};
let tcnt=0;function toast(m){tcnt++;document.querySelectorAll('.toast').forEach(x=>x.remove());const e=document.createElement('div');e.className='toast';e.textContent=m;document.body.appendChild(e);setTimeout(()=>e.remove(),3500)}
let S;try{S=JSON.parse(ld()||'null')}catch(e){}S=S||{h:[],t:[],c:[]};S.th=S.th||'ocean';S.md=S.md||'auto';if(!S.cats)S.cats=DC.map(x=>x.slice()).concat((S.c||[]).map(x=>[x[0],'star',x[2]||'#14a0bf']));S.h.forEach(h=>{if(h.ic&&!IC[h.ic])delete h.ic;h.e=h.e||'';if(h.ty!='y'){h.mx=h.mx||(h.ty=='t'?1440:Math.max(10,h.g*10));h.lim=h.lim||'min';h.u=h.u||''}});
let view='today',sel=new Date(),cur=null,tab='cal',mon=new Date(),wiz=null,ec=null,anc=new Date();
const K=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const D=k=>new Date(k+'T00:00'),save=()=>{SC={};sv(JSON.stringify(S))},saveD=(()=>{let t;return()=>{clearTimeout(t);t=setTimeout(save,300)}})();let SC={};
const esc=s=>String(s).replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';');
const cats=()=>S.cats,ct=n=>S.cats.find(c=>c[0]==n)||S.cats[S.cats.length-1]||['Other','cats','#e0603a'];
const fm=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
const fd=f=>f.t=='d'?'Every day':f.t=='w'?f.v.map(i=>DN[i]).join(', '):f.t=='m'?'Days '+f.v.join(', ')+' of the month':'Every '+f.n+' days';
const due=(h,d)=>{const f=h.f;d=new Date(d.getFullYear(),d.getMonth(),d.getDate());return d>=D(h.cr)&&(!h.e||K(d)<=h.e)&&(f.t=='d'||(f.t=='w'&&f.v.includes(d.getDay()))||(f.t=='m'&&f.v.includes(d.getDate()))||(f.t=='r'&&Math.round((d-D(h.cr))/864e5)%f.n==0))};
const st=(h,k)=>{const v=h.l[k];if(v==null)return null;if(h.ty=='y')return v;const ok=h.lim=='max'?v<=h.g:v>=h.g;return ok?1:(h.lim!='max'&&k==K(new Date())?null:0)};
function setLog(h,k,v){if(v==null)delete h.l[k];else h.l[k]=v;save()}
function stats(h){const now=new Date(),tk=K(now),ky=h.id+'@'+tk;if(SC[ky])return SC[ky];const end=h.e&&h.e<tk?h.e:tk,c30=new Date(now);c30.setDate(now.getDate()-29);const k30=K(c30);
 let s=null,c=0,b=0,n=0,w=0,m=0,y=0,dn=0,sum=0,cnt=0,mxv=0,hist=[],wd=Array.from({length:7},()=>[0,0]),r30=[0,0];
 const mo=new Date(now);mo.setDate(now.getDate()-((now.getDay()+6)%7));const wk=K(mo);
 for(const k in h.l){if(st(h,k)===1){n++;if(k>=wk&&k<=tk)w++;if(k.slice(0,7)==tk.slice(0,7))m++;if(k.slice(0,4)==tk.slice(0,4))y++}
  if(h.ty!='y'){const v=h.l[k];sum+=v;cnt++;mxv=Math.max(mxv,v)}}
 for(let d=D(h.cr);K(d)<=end;d.setDate(d.getDate()+1)){if(!due(h,d))continue;const k=K(d),x=st(h,k);if(x==null&&k==tk)continue;
  const v=x===1?1:0;s=s==null?v:s*.93+v*.07;hist.push(Math.round(s*100));wd[d.getDay()][1]++;wd[d.getDay()][0]+=v;dn++;
  if(k>=k30){r30[1]++;r30[0]+=v}if(v){c++;b=Math.max(b,c)}else c=0}
 const r1=x=>Math.round(x*10)/10;
 return SC[ky]={s:Math.round((s||0)*100),c,b,n,w,m,y,hist,wd,due:dn,rate:dn?Math.min(100,Math.round(n/dn*100)):0,r30:r30[1]?Math.round(r30[0]/r30[1]*100):0,avg:cnt?r1(sum/cnt):0,sum:r1(sum),mxv}}
function ask(t,v,cb,ni,cls){const d=$('#dlg');d.innerHTML=`<form method=dialog><h3>${t}</h3>${ni?'':`<input class="in ${cls||''}" type=${cls=='date'?'date':'text'} inputmode=${cls=='num'?'decimal':'text'} autocomplete=off id=inp value="${esc(v==null?'':v)}">`}<menu><button value=o>OK</button><button value=c>Cancel</button></menu></form>`;
 d.returnValue='';d.onclose=()=>{d.onclose=null;if(d.returnValue=='o')cb(ni?'':$('#inp').value)};d.showModal()}
const conf=(t,cb)=>ask(t,'',cb,1);
function tap(h,k){
 if(k>K(new Date()))return toast("Future days can't be edited yet");
 if(k<h.cr)return toast('This day is before the start date');
 if(!due(h,D(k)))return toast('Rest day: this habit is not scheduled');
 if(h.ty=='y'){const v=h.l[k];setLog(h,k,v==null?1:v===1?0:null);render();pop(h,k)}
 else ask(`${esc(h.name)}<br><small class=mu2>${h.lim=='max'?'Limit':'Goal'}: ${h.g} ${esc(h.u||(h.ty=='t'?'min':''))} · allowed 0 to ${h.mx}</small>`,h.l[k],x=>{x=x.trim();
  if(x==='')setLog(h,k,null);else{const n=+x;if(!isFinite(n)||n<0||n>h.mx){toast(`Enter a number from 0 to ${h.mx}`);return tap(h,k)}setLog(h,k,Math.round(n*100)/100)}render();pop(h,k)},0,'num')}
const ci=h=>{const c=ct(h.cat);return[c[0],h.ic||c[1],h.col||c[2]]};
const pop=(h,k)=>setTimeout(()=>{const e=document.querySelector(`.ck[data-v="${h.id}"],.cell[data-v="${k}"]`);e&&e.classList.add('pop')},0);
const TH=[['ocean','Ocean','#14a0bf'],['amoled','Amoled','#00e5a0'],['forest','Forest','#4caf50'],['sunset','Sunset','#ff7043'],['rose','Rose','#ec407a'],['violet','Violet','#9575ff'],['light','Paper','#0a84ff'],['glass','Liquid Glass','linear-gradient(135deg,#8b5cf6,#22d3ee,#ff5fa2)'],['ios','iOS','#007aff'],['oneui','One UI','#3e91ff'],['oxygen','OxygenOS','#eb0028'],['origin','OriginOS','#4166ff'],['hyper','HyperOS','#3482ff']],OS=['ios','oneui','oxygen','origin','hyper'];
const IK=['run','dumb','book','drop','med','apple','moon','laptop','music','block','coin','home','heart','pen','bike','sun','bolt','flag','fork','mtn','cap','dna','chat','star'],COL=['#14a0bf','#4caf50','#ff7043','#ec407a','#9575ff','#f0a020','#5b7be0','#e0364a'];
const spark=a=>a.length<2?'<p class=mu>Not enough data yet</p>':`<svg viewBox="0 0 300 80" class=sp><polyline pathLength=1000 fill=none stroke="var(--ac)" stroke-width=3 stroke-linejoin=round stroke-linecap=round points="${a.map((v,i)=>(i/(a.length-1)*300).toFixed(1)+','+(76-v*.72).toFixed(1)).join(' ')}"/></svg>`;
const tagHtml=(c,t)=>`<span class=tg style="color:${c[2]};background:${c[2]}22">${t}</span>`;
const icHtml=c=>`<i class=ic style="background:${c[2]}22;color:${c[2]}">${ico(c[1],24)}</i>`;
const MED=(ok,ic,t,d)=>`<div class="bd ${ok?'on':''}"><i>${ico(ok?ic:'lock',22)}</i><b>${t}</b><small>${d}</small></div>`;
const BG=(a,t)=>{const u=a.filter(x=>x[0]).length;return `<div class=card><small>${t} · ${u}/${a.length}</small><div class=bg>${a.map(x=>MED(...x)).join('')}</div></div>`};
const BGH=(h,s)=>BG([...[[3,'flame'],[7,'flame'],[14,'bolt'],[21,'bolt'],[30,'award'],[60,'award'],[100,'trophy'],[200,'crown'],[365,'crown']].map(([n,i])=>[s.b>=n,i,n+'-day streak','Best '+Math.min(s.b,n)+'/'+n]),
 ...[[10,'check'],[25,'check'],[50,'target'],[100,'target'],[250,'trophy'],[500,'crown']].map(([n,i])=>[s.n>=n,i,n+' done','Total '+Math.min(s.n,n)+'/'+n]),
 [s.due>=30&&s.r30==100,'star','Perfect month','100% for 30 days'],[s.due>=14&&s.s>=90,'heart','Score 90+','Keep score above 90'],[s.due>=1&&s.rate>=80,'target','Consistent','80%+ overall']],'Achievements');
function gs(){const t=K(new Date());let mn=t,pf=0,run=0,br=0,tot=0;S.h.forEach(h=>{if(h.cr<mn)mn=h.cr});
 for(let d=D(mn);K(d)<=t;d.setDate(d.getDate()+1)){const k=K(d),L=S.h.filter(h=>!h.arch&&k>=h.cr&&due(h,d));if(!L.length)continue;const ok=L.filter(h=>st(h,k)===1).length;tot+=ok;if(ok==L.length){pf++;run++;br=Math.max(br,run)}else if(k!=t)run=0}
 return{pf,br,tot}}
function BGG(){if(!S.h.length)return '';const g=gs(),n=S.h.length,sk=Math.max(...S.h.map(h=>stats(h).b));
 return BG([[n>=1,'flag','First habit','Add a habit'],[n>=5,'cats','Collector','Track 5 habits'],[n>=10,'cats','Habit master','Track 10 habits'],...[[100,'check'],[500,'target'],[1000,'crown']].map(([c,i])=>[g.tot>=c,i,c+' check-ins','Total '+Math.min(g.tot,c)+'/'+c]),
 ...[[1,'sun','Perfect day'],[7,'sun','7 perfect days'],[30,'trophy','30 perfect days']].map(([c,i,t])=>[g.pf>=c,i,t,'Finished '+Math.min(g.pf,c)+'/'+c]),[g.br>=7,'flame','Perfect week','7 perfect days in a row'],[sk>=30,'award','30-day streak','Any habit'],[sk>=100,'crown','100-day streak','Any habit']],'Achievements')}
const TD=()=>{const k=K(sel),fut=k>K(new Date()),days=[];for(let i=-10;i<=14;i++){const d=new Date(anc);d.setDate(d.getDate()+i);days.push(d)}
 const L=S.h.filter(h=>!h.arch&&due(h,sel));
 return `<div class=top><h1 data-a=tday>${sel.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</h1><span data-a=now>${ico('cal',24)}</span></div>
 <div class=strip>${days.map(d=>`<div class="dy ${K(d)==k?'sel':''}" data-a=day data-v=${K(d)}><small>${DN[d.getDay()]}</small><b>${d.getDate()}</b></div>`).join('')}</div>
 ${L.map(h=>{const c=ci(h),x=st(h,k),v=h.l[k];return `<div class=it data-a=open data-v=${h.id}>${icHtml(c)}<div><b>${esc(h.name)}</b><br>${tagHtml(c,'Habit')}${h.ty!='y'?` <small class=mu2>${h.lim=='max'?'≤ ':''}${v==null?0:v}/${h.g} ${esc(h.u||(h.ty=='t'?'min':''))}</small>`:''}</div><button class="ck ${x===1?'ok':x===0?'no':''} ${fut?'lk':''}" data-a=tog data-v=${h.id}>${fut?ico('lock',20):x===1?ico('check',22):x===0?ico('x',20):''}</button></div>`}).join('')||'<p class=mu>No habits due this day. Tap + to add one.</p>'}
 <button class=fab data-a=add>+</button>`};
const OV=()=>{const t=new Date(),bars=[];for(let i=6;i>=0;i--){const d=new Date(t);d.setDate(t.getDate()-i);const L=S.h.filter(h=>!h.arch&&K(d)>=h.cr&&due(h,d));const ok=L.filter(h=>st(h,K(d))===1).length;bars.push([L.length?Math.round(ok/L.length*100):0,DN[d.getDay()][0]])}
 const all=S.h.filter(h=>!h.arch).map(h=>[h,stats(h)]);if(!all.length)return '';const top=all.slice().sort((a,b)=>b[1].s-a[1].s)[0][0];
 return `<div class=card><small>Last 7 days completion</small><div class=bars>${bars.map(b=>`<div>${b[0]}%<i style="height:${b[0]*.9}px"></i>${b[1]}</div>`).join('')}</div><div class=row2><div>Avg score<b>${Math.round(all.reduce((a,x)=>a+x[1].s,0)/all.length)}</b></div><div>Best streak<b>${Math.max(...all.map(x=>x[1].b))}</b></div><div>Top habit<b style="font-size:15px">${esc(top.name)}</b></div></div></div>`};
const HB=()=>`<div class=top><h1>Habits</h1></div>${OV()}${BGG()}${S.h.map(h=>{const c=ci(h);return `<div class=it style="${h.arch?'opacity:.5':''}" data-a=open data-v=${h.id}>${icHtml(c)}<div><b>${esc(h.name)}</b><br>${tagHtml(c,esc(h.arch?'Paused':h.e&&h.e<K(new Date())?'Ended':c[0]))}</div><b class=sc>${stats(h).s}</b></div>`}).join('')||'<p class=mu>No habits yet. Tap + to add one.</p>'}<button class=fab data-a=add>+</button>`;
const CG=()=>`<div class=top><h1>Categories</h1></div><div class=grid>${cats().map((c,i)=>`<div class=it data-a=ce data-v=${i}>${icHtml(c)}<div><b>${esc(c[0])}</b><br><small class=mu2>${S.h.filter(h=>h.cat==c[0]).length} habits</small></div><span class=mu2>${ico('pen',16)}</span></div>`).join('')}<div class=it data-a=nc><b>＋ New category</b></div></div>`;
const CE=()=>{const c=S.cats[ec];return `<div class=top><h1><span data-a=back>${ico('chev',24)}</span>Edit category</h1></div><div class=card><small>Name</small><input class=in data-w=cn maxlength=24 value="${esc(c[0])}"><small>Icon</small><div class=row>${IK.map(k=>`<span class="chip ${c[1]==k?'on':''}" data-a=cic data-v=${k}>${ico(k,20)}</span>`).join('')}</div><small>Color</small><div class=row>${COL.map(x=>`<i class="dot ${c[2]==x?'on':''}" style="background:${x}" data-a=ccl data-v=${x}></i>`).join('')}</div><p class=ins>${S.h.filter(h=>h.cat==c[0]).length} habits use this category</p></div><button class="btn red" data-a=cdel>Delete category</button>`};
const TK=()=>`<div class=top><h1>Tasks</h1></div>${S.t.map((t,i)=>`<div class=it><button class="ck ${t.d?'ok':''}" data-a=tt data-v=${i}>${t.d?ico('check',22):''}</button><div style="${t.d?'text-decoration:line-through;opacity:.5':''}"><b>${esc(t.n)}</b></div><span data-a=td data-v=${i}>${ico('trash',20)}</span></div>`).join('')||'<p class=mu>No tasks yet.</p>'}<button class=fab data-a=nt>+</button>`;

const CAL=(h,s)=>{const y=mon.getFullYear(),m=mon.getMonth(),n=new Date(y,m+1,0).getDate(),o=(new Date(y,m,1).getDay()+6)%7;let g='';
 for(let i=0;i<o;i++)g+='<i></i>';
 for(let d=1;d<=n;d++){const k=K(new Date(y,m,d)),x=st(h,k);g+=`<div class="cell ${k==K(new Date())?'td':''} ${k>K(new Date())?'fut':k<h.cr||!due(h,D(k))?'off':''} ${x===1?'ok':x===0?'no':''}" data-a=cell data-v=${k}>${d}</div>`}
 return `<div class="top mid"><span data-a=mm data-v=-1>‹</span><b>${mon.toLocaleDateString('en-US',{month:'long',year:'numeric'})}</b><span data-a=mm data-v=1>›</span></div>
 <div class=cg>${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(x=>`<small>${x}</small>`).join('')}${g}</div><div class=card><small>Streak</small><h2>${s.c} DAYS</h2></div>`};
const SET=()=>`<div class=top><h1>Settings</h1></div><div class=card><small>Theme</small><div class=th>${TH.map(t=>`<div class="sw ${S.th==t[0]?'on':''}" data-a=th data-v=${t[0]}><i style="background:${t[2]}"></i>${t[1]}</div>`).join('')}</div><small>Appearance for iOS, One UI, OxygenOS, OriginOS and HyperOS</small><div class=seg>${['auto','dark','light'].map(m=>`<span class="${S.md==m?'on':''}" data-a=md data-v=${m}>${m[0].toUpperCase()+m.slice(1)}</span>`).join('')}</div></div><button class="btn red" data-a=rst>Reset all data</button>`;
const ST=(h,s)=>{const y=mon.getFullYear(),cnt=Array(12).fill(0),T0=K(new Date());let ok=0,bad=0;
 for(const k in h.l){const x=st(h,k);if(x===1){ok++;if(+k.slice(0,4)==y)cnt[+k.slice(5,7)-1]++}else if(x===0)bad++}
 const mx=Math.max(1,...cnt),p=ok+bad?Math.round(ok/(ok+bad)*100):0,H=s.hist,tr=H.length>1?H[H.length-1]-H[Math.max(0,H.length-15)]:0;
 const wd=[1,2,3,4,5,6,0].map(i=>({i,r:s.wd[i][1]?Math.round(s.wd[i][0]/s.wd[i][1]*100):null})),hs=wd.filter(x=>x.r!=null);
 const bst=hs.length&&hs.reduce((a,b)=>b.r>a.r?b:a),wk=hs.length&&hs.reduce((a,b)=>b.r<a.r?b:a);
 const h0=new Date();h0.setDate(h0.getDate()-((h0.getDay()+6)%7)-77);let hm='';
 for(let i=0;i<84;i++){const d=new Date(h0);d.setDate(h0.getDate()+i);const k=K(d),x=st(h,k);hm+=`<i class="${k>T0?'z':x===1?'ok':x===0?'no':due(h,d)&&k>=h.cr?'':'off'}"></i>`}
 return `<div class=card><small>Habit score</small><div class=ring style="--p:${s.s}"><b>${s.s}</b></div><p class=ins>${tr>0?'▲ Up':tr<0?'▼ Down':'● Steady'} ${Math.abs(tr)} pts over the last 2 weeks</p></div>
 <div class=card><small>Consistency</small><div class=row2><div>Overall<b>${s.rate}%</b></div><div>Last 30 days<b>${s.r30}%</b></div><div>Scheduled<b>${s.due}</b></div></div></div>
 <div class=card><small>Streak</small><div class=row2><div>Current<b>${s.c} DAYS</b></div><div>Best<b>${s.b} DAYS</b></div></div></div>
 ${h.ty!='y'?`<div class=card><small>Values</small><div class=row2><div>Average<b>${s.avg}</b></div><div>Total<b>${s.sum}</b></div><div>Best day<b>${s.mxv}</b></div></div></div>`:''}
 <div class=card><small>Times completed</small>${[['This week',s.w],['This month',s.m],['This year',s.y],['All',s.n]].map(r=>`<div class=tl><span>${r[0]}</span><b>${r[1]}</b></div>`).join('')}</div>
 ${BGH(h,s)}
 <div class=card><small>Score trend</small>${spark(H.slice(-60))}</div>
 <div class=card><small>By weekday</small><div class=bars>${wd.map(x=>`<div>${x.r==null?'':x.r+'%'}<i style="height:${x.r||0}px"></i>${DN[x.i][0]}</div>`).join('')}</div>${bst?`<p class=ins>Strongest: ${DN[bst.i]} (${bst.r}%) · Weakest: ${DN[wk.i]} (${wk.r}%)</p>`:''}</div>
 <div class=card><small>Last 12 weeks</small><div class=hm>${hm}</div></div>
 <div class=card><div class="top mid"><span data-a=mm data-v=-12>‹</span><b>${y}</b><span data-a=mm data-v=12>›</span></div>Times completed per month<div class=bars>${cnt.map((v,i)=>`<div>${v||''}<i style="height:${v/mx*100}px"></i>${'JFMAMJJASOND'[i]}</div>`).join('')}</div></div>
 <div class=card><small>Success / Fail</small><div class=donut style="--p:${p}"><b>${ok}</b></div><span style="color:var(--ok)">● Done ${ok}</span> &nbsp; <span style="color:var(--no)">● Fail ${bad}</span></div>`};
const FQ=o=>{const f=o.f;return [['d','Every day'],['w','Specific days of the week'],['m','Specific days of the month'],['r','Repeat every N days']].map(([t,n])=>`<label class=rd><input type=radio name=f ${f.t==t?'checked':''} data-a=wf data-v=${t}>${n}</label>`).join('')
 +(f.t=='w'?`<div class=row>${[1,2,3,4,5,6,0].map(i=>`<span class="chip ${f.v.includes(i)?'on':''}" data-a=wd data-v=${i}>${DN[i]}</span>`).join('')}</div>`:f.t=='m'?`<input class="in lst" data-w=mv placeholder="Days, e.g. 1,15,28" value="${f.v.join(',')}">`:f.t=='r'?`<input class="in num" inputmode=numeric data-w=n value="${f.n||2}">`:'')};
const ED=h=>{const c=ci(h),nu=h.ty!='y',t0=K(new Date());
 return `<div class=card><small>Name</small><input class=in data-w=nm maxlength=40 value="${esc(h.name)}"><small>Category</small><select class=in data-w=cat>${cats().map(x=>`<option ${x[0]==h.cat?'selected':''}>${esc(x[0])}</option>`).join('')}</select></div>
 <div class=card><small>Icon</small><div class=row>${IK.map(k=>`<span class="chip ${c[1]==k?'on':''}" data-a=eic data-v=${k}>${ico(k,20)}</span>`).join('')}</div><small>Color</small><div class=row>${COL.map(x=>`<i class="dot ${c[2]==x?'on':''}" style="background:${x}" data-a=ecl data-v=${x}></i>`).join('')}</div></div>
 <div class=card><small>Start date</small><input class=in type=date data-w=cr max="${t0}" value="${h.cr}"><small>End date (optional)</small><input class=in type=date data-w=e min="${h.cr}" value="${h.e||''}">${h.e?'<span class=chip data-a=eclr>Remove end date</span>':''}<small>Repeats</small><div style="text-align:left">${FQ(h)}</div></div>
 ${nu?`<div class=card><small>${h.ty=='t'?'Minutes per day':'Daily value'}</small><select class=in data-w=lim><option value=min ${h.lim!='max'?'selected':''}>At least (daily goal)</option><option value=max ${h.lim=='max'?'selected':''}>At most (daily limit)</option></select><input class="in num" inputmode=decimal data-w=g value="${h.g}" placeholder="Goal"><input class=in data-w=u maxlength=12 value="${esc(h.u||'')}" placeholder="Unit (e.g. glasses)"><input class="in num" inputmode=decimal data-w=mx value="${h.mx}" placeholder="Maximum allowed per day"></div>`:''}
 <div class=card><small>Notes</small><textarea class=in data-w=note rows=3 placeholder="Why this habit matters">${esc(h.note||'')}</textarea></div>
 <button class=btn style="width:100%;margin-top:8px" data-a=arch>${h.arch?'Resume habit':'Pause habit'}</button><button class="btn red" data-a=clr>Clear history</button><button class="btn red" data-a=del>Delete habit</button>`};
const DT=()=>{const h=cur,c=ci(h),s=stats(h);
 return `<div class="top"><h1><span data-a=back>${ico('chev',24)}</span>${esc(h.name)}</h1><span style="color:${c[2]}">${ico(c[1],26)}</span></div><div class=tabs>${[['cal','Calendar'],['stats','Statistics'],['edit','Edit']].map(([k,n])=>`<a class="${tab==k?'on':''}" data-a=tab data-v=${k}>${n}</a>`).join('')}</div>${tab=='cal'?CAL(h,s):tab=='stats'?ST(h,s):ED(h)}`};
const WZ=()=>{const s=wiz.s;let b='';
 if(s==1)b=[['y','With a yes or no','Record whether you succeed with the activity or not'],['n','With a numeric value','Set a count as a daily goal or limit'],['t','With a timer','Set minutes as a daily goal or limit']].map(o=>`<button class=big data-a=wt data-v=${o[0]}>${o[1]}</button><p>${o[2]}</p>`).join('');
 if(s==2)b=`<div class=grid>${cats().map(c=>`<div class=it data-a=wc data-v="${esc(c[0])}"><div><b>${esc(c[0])}</b></div>${icHtml(c)}</div>`).join('')}</div>`;
 if(s==3)b=FQ(wiz);
 if(s==4){const nu=wiz.ty!='y';b=`<input class=in data-w=name maxlength=40 placeholder="Habit name" value="${esc(wiz.name||'')}"><label class=fl>Start date<input class=in type=date data-w=cr max="${K(new Date())}" value="${wiz.cr||K(new Date())}"></label><label class=fl>End date (optional)<input class=in type=date data-w=e min="${wiz.cr||K(new Date())}" value="${wiz.e||''}"></label>${nu?`<select class=in data-w=lim><option value=min ${wiz.lim!='max'?'selected':''}>At least (daily goal)</option><option value=max ${wiz.lim=='max'?'selected':''}>At most (daily limit)</option></select><input class="in num" inputmode=decimal data-w=g placeholder="${wiz.ty=='t'?'Goal in minutes':'Goal or limit value'}" value="${esc(wiz.g||'')}"><input class=in data-w=u maxlength=12 placeholder="Unit (e.g. glasses)" value="${esc(wiz.u||'')}"><input class="in num" inputmode=decimal data-w=mx placeholder="Max allowed per day (optional)" value="${esc(wiz.mx||'')}">`:''}`}
 return `<div class=wz><h2>${['How do you want to evaluate your progress?','Select a category for your habit','How often do you want to do it?','Name your habit'][s-1]}</h2>${b}</div>
 <div class=bar><a data-a=wb>${s==1?'CANCEL':'BACK'}</a><span>${[1,2,3,4].map(i=>i<=s?'●':'○').join('')}</span><a data-a=wn>${s>=3?(s==4?'SAVE':'NEXT'):''}</a></div>`};
const ph=()=>{try{history.pushState({},'')}catch(e){}};
const A={nav:v=>{view=v},day:v=>{sel=D(v)},now:()=>ask('Jump to date',K(sel),v=>{if(v){sel=D(v);anc=D(v);render()}},0,'date'),tday:()=>{sel=new Date();anc=new Date()},
 tog:v=>tap(S.h.find(h=>h.id==v),K(sel)),open:v=>{cur=S.h.find(h=>h.id==v);tab='cal';mon=new Date();ph()},
 back:()=>{cur=null;ec=null},tab:v=>{tab=v},cell:v=>tap(cur,v),mm:v=>{mon=new Date(mon.getFullYear(),mon.getMonth()+ +v,1)},
 del:()=>conf('Delete this habit and its history?',()=>{S.h=S.h.filter(h=>h!==cur);cur=null;save();render()}),
 clr:()=>conf('Clear all logged history for this habit?',()=>{cur.l={};save();render()}),
 arch:()=>{cur.arch=!cur.arch;save()},eic:v=>{cur.ic=v;save()},ecl:v=>{cur.col=v;save()},eclr:()=>{cur.e='';save()},
 add:()=>{wiz={s:1,f:{t:'d',v:[],n:2}};ph()},wt:v=>{wiz.ty=v;wiz.s=2},wc:v=>{wiz.cat=v;wiz.s=3},
 wf:v=>{const o=wiz||cur;o.f={t:v,v:v=='w'?[1,2,3,4,5]:v=='m'?[1]:[],n:2};if(cur)save()},
 wd:v=>{const o=wiz||cur,a=o.f.v;v=+v;if(a.includes(v)){if(a.length<2)return toast('Pick at least one day');a.splice(a.indexOf(v),1)}else a.push(v);if(cur)save()},
 wb:()=>{wiz.s==1?wiz=null:wiz.s--},
 wn:()=>{const f=wiz.f;
  if(wiz.s==3){if((f.t=='w'||f.t=='m')&&!f.v.length)return toast(f.t=='w'?'Pick at least one day':'Enter days like 1,15,28');f.n=Math.max(1,f.n||2);wiz.s=4}
  else if(wiz.s==4){const nm=(wiz.name||'').trim();if(!nm)return toast('Enter a name');const nu=wiz.ty!='y',t=wiz.ty=='t',T0=K(new Date()),cr=wiz.cr||T0;let g=1,mx=1;const u=t?'min':(wiz.u||'').trim();
   if(cr>T0)return toast('Start date cannot be in the future');if(wiz.e&&wiz.e<cr)return toast('End date must be on or after the start date');
   if(nu){g=+wiz.g;if(!(g>0))return toast('Enter a goal above 0');mx=wiz.mx?+wiz.mx:(t?1440:Math.max(10,g*10));if(t&&(g>1440||mx>1440))return toast('Minutes cannot exceed 1440 per day');if(!(mx>=g))return toast('Max allowed must be at least the goal')}
   S.h.push({id:Date.now(),name:nm,ty:wiz.ty,cat:wiz.cat,g,mx,u,lim:wiz.lim||'min',f,cr,e:wiz.e||'',l:{}});save();wiz=null;view='today';sel=new Date()}},
 ce:v=>{ec=+v;ph()},cic:v=>{S.cats[ec][1]=v;save()},ccl:v=>{S.cats[ec][2]=v;save()},
 cdel:()=>{const c=S.cats[ec],n=S.h.filter(h=>h.cat==c[0]).length;if(S.cats.length<2)return toast('Keep at least one category');const t=S.cats.find((x,i)=>i!=ec)[0];
  conf(`Delete "${esc(c[0])}"?${n?` Its ${n} habit${n>1?'s':''} will move to ${esc(t)}.`:''}`,()=>{S.h.forEach(h=>{if(h.cat==c[0])h.cat=t});S.cats.splice(ec,1);ec=null;save();render()})},
 nc:()=>ask('Category name','',n=>{n=n.trim();if(!n)return;if(S.cats.some(c=>c[0].toLowerCase()==n.toLowerCase()))return toast('That category already exists');S.cats.push([n,'star','#14a0bf']);save();ec=S.cats.length-1;ph();render()}),
 nt:()=>ask('New task','',n=>{if(n.trim()){S.t.push({n:n.trim(),d:0});save();render()}}),
 tt:v=>{S.t[v].d=!S.t[v].d;save()},td:v=>{S.t.splice(v,1);save()},th:v=>{S.th=v;save()},md:v=>{S.md=v;save()},
 rst:()=>conf('Erase all habits, tasks and categories?',()=>{S={h:[],t:[],c:[],cats:DC.map(x=>x.slice()),th:S.th,md:S.md};save();render()})};
document.onclick=e=>{const t=e.target.closest('[data-a]');if(t){A[t.dataset.a](t.dataset.v,t);render()}};
document.oninput=e=>{const t=e.target,w=t.dataset.w,l=t.classList;
 if(l.contains('num'))t.value=t.value.replace(/[^0-9.]/g,'').replace(/(\..*)\./g,'$1');
 if(l.contains('lst'))t.value=t.value.replace(/[^0-9,]/g,'');
 if(!w)return;const v=t.value;
 if(cur){if(w=='nm'&&v.trim()){cur.name=v.trim();saveD()}else if(w=='u'||w=='note'){cur[w]=v;saveD()}}
 else if(wiz){if(w=='mv')wiz.f.v=v.split(',').map(Number).filter(x=>x>=1&&x<=31);else if(w=='n')wiz.f.n=Math.max(1,parseInt(v)||2);else wiz[w]=v}};
document.onchange=e=>{const t=e.target,w=t.dataset.w;if(!w)return;const v=t.value.trim(),n=+v;
 if(w=='cn'&&ec!=null){const c=S.cats[ec];if(!v||S.cats.some((x,i)=>i!=ec&&x[0].toLowerCase()==v.toLowerCase())){toast(v?'That category already exists':'Name cannot be empty');render();return}
  S.h.forEach(h=>{if(h.cat==c[0])h.cat=v});c[0]=v;save();return}
 if(!cur)return;const c0=tcnt;if(w=='nm'&&!v)toast('Name cannot be empty');
 if(w=='cat')cur.cat=v;else if(w=='lim')cur.lim=v;
 else if(w=='cr'){if(!v||v>K(new Date()))toast('Start date cannot be in the future');else if(cur.e&&v>cur.e)toast('Start date must be before the end date');else cur.cr=v}
 else if(w=='e'){if(!v)cur.e='';else if(v<cur.cr)toast('End date must be on or after the start date');else cur.e=v}
 else if(w=='g'){if(n>0&&n<=cur.mx)cur.g=n;else toast(`Goal must be above 0 and at most ${cur.mx}`)}
 else if(w=='mx'){if(n>=cur.g&&(cur.ty!='t'||n<=1440))cur.mx=n;else toast(`Max must be at least ${cur.g}`+(cur.ty=='t'?' and at most 1440':''))}
 else if(w=='mv'){const a=v.split(',').map(Number).filter(x=>x>=1&&x<=31);if(a.length)cur.f.v=a;else toast('Enter days like 1,15,28')}
 else if(w=='n'){if(n>=1)cur.f.n=Math.floor(n);else toast('Enter 1 or more')}
 save();if(tcnt>c0||w=='cat'||w=='lim'||w=='e')render()};
function applyTheme(){const th=S.th||'ocean',b=document.body,os=OS.includes(th);let m=th=='light'?'light':'dark';if(os)m=S.md=='auto'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):S.md;b.dataset.theme=th;b.dataset.mode=m;b.toggleAttribute('data-os',os)}
function goBack(){const d=$('#dlg');if(d.open){d.close();return 1}
 if(wiz){A.wb();if(wiz)ph()}else if(cur||ec!=null){cur=null;ec=null}else if(view!='today')view='today';else return 0;render();return 1}
window.onBack=goBack;addEventListener('popstate',goBack);addEventListener('pagehide',()=>save());
try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(S.md=='auto')render()})}catch(e){}
let lk='';
function render(){applyTheme();const off=cur||wiz||ec!=null;$('#nav').style.display=off?'none':'flex';
 document.querySelectorAll('#nav a').forEach(a=>a.classList.toggle('on',a.dataset.v==view));
 const a=$('#app'),key=[view,cur&&cur.id,tab,wiz&&wiz.s,ec].join();
 a.innerHTML=wiz?WZ():ec!=null?CE():cur?DT():({today:TD,habits:HB,tasks:TK,cats:CG,set:SET})[view]();
 if(key!=lk){lk=key;a.classList.remove('enter');void a.offsetWidth;a.classList.add('enter')}
 if(view=='today'&&!off){const e=$('.sel');e&&e.scrollIntoView({inline:'center',block:'nearest'})}}
document.querySelectorAll('#nav a').forEach(a=>a.insertAdjacentHTML('afterbegin',ico(a.dataset.i,24)));
render();
