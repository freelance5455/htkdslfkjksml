# V63 Excel in-app picker fix

Version 2.29 / versionCode 33.

The Excel `<input type=file>` callback no longer launches DocumentsUI, ACTION_OPEN_DOCUMENT, ACTION_GET_CONTENT, or ACTION_PICK. It opens an app-owned `ImportPickerActivity`, which lists `.xlsx`, `.csv`, and `.txt` files from Downloads through MediaStore and returns the selected content URI to WebView. This is intended to avoid vendor Android 14 picker failures.
