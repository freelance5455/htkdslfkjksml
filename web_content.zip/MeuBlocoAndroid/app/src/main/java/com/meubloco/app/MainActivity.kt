package com.meubloco.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val dataFile: File by lazy {
        File(File(filesDir, "MeuBloco"), "anotacoes.json")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataFile.parentFile?.mkdirs()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(StorageBridge(), "AndroidStorage")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class StorageBridge {
        @JavascriptInterface
        fun loadNotes(): String {
            return try {
                if (dataFile.exists()) dataFile.readText(Charsets.UTF_8) else "[]"
            } catch (_: Exception) {
                "[]"
            }
        }

        @JavascriptInterface
        fun saveNotes(json: String): Boolean {
            return try {
                dataFile.parentFile?.mkdirs()
                val temp = File(dataFile.parentFile, "anotacoes.tmp")
                temp.writeText(json, Charsets.UTF_8)
                if (dataFile.exists()) dataFile.delete()
                temp.renameTo(dataFile)
            } catch (_: Exception) {
                false
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
