MEU BLOCO - PROJETO ANDROID

Este é um projeto-fonte Android Studio, não um APK já compilado.

COMO GERAR O APK:
1. Instale o Android Studio em um computador.
2. Extraia a pasta MeuBlocoAndroid.
3. No Android Studio, escolha Open e selecione essa pasta.
4. Aguarde a sincronização do Gradle.
5. Acesse Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Quando terminar, use o link "locate" para encontrar o APK.

ARMAZENAMENTO:
As anotações são gravadas em:
filesDir/MeuBloco/anotacoes.json
Essa pasta fica na área privada do aplicativo Android. Não exige permissão de arquivos.

IDENTIFICADOR:
com.meubloco.app
