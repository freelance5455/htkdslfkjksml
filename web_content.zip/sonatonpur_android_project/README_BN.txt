Sonatonpur Senior or Jonior Club — Android wrapper project

এই ZIP-এ আপনার HTML ক্লাব অ্যাপটি Android WebView অ্যাপ হিসেবে প্যাক করা আছে।
এটি APK ফাইল নয়; APK তৈরি করতে Android build environment লাগবে।

APK তৈরি করার উপায়:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP extract করুন।
3. Android Studio > Open থেকে SonatonpurClub ফোল্ডারটি খুলুন।
4. Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk ফাইলে তৈরি হবে।

গুরুত্বপূর্ণ:
- HTML অ্যাপের ডেটা ডিভাইসের WebView/local storage-এ থাকবে।
- একাধিক ফোনে স্বয়ংক্রিয় sync নেই; এর জন্য Firebase/backend যোগ করতে হবে।
- অ্যাপের পাসওয়ার্ডটি HTML-এর client-side login, তাই এটি শক্তিশালী সার্ভার-ভিত্তিক নিরাপত্তা নয়।
- Play Store-এ প্রকাশের আগে target SDK, signing, privacy policy ও পরীক্ষা প্রয়োজন।
