# Socle 3.8 — Impact réel du staff sur les performances

## Objectif
Relier les compétences du personnel et les délégations aux effets sportifs concrets, sans remplacer le moteur de dames ni modifier les formats des compétitions.

## Fonctionnalités ajoutées
- **Entraîneur :** progression fractionnaire quotidienne des deux damistes du club dirigé. Le niveau n'augmente que lorsque le cumul atteint un point complet et reste plafonné à 100.
- **Installations :** le niveau du centre d'entraînement module progressivement la vitesse de développement.
- **Responsable des jeunes :** la délégation « Conseils aux jeunes » ajoute un effet de développement limité.
- **Kiné :** amélioration quotidienne graduelle de la forme, plafonnée à 100.
- **Adjoint :** lorsque la préparation des matchs lui est déléguée, son niveau produit un bonus de préparation plafonné à +/- 2,5 points de force pour les simulations automatiques du club dirigé.
- **Anti-double traitement :** une journée ne peut être traitée qu'une fois (`lastStaffDevelopmentDay`). Une journée annulée par un événement officiel bloqué ne déclenche pas les gains de développement.
- **Interface :** le bureau du club affiche les modificateurs sportifs et la progression fractionnaire des deux damistes.

## Limites explicites
- Le bonus de préparation est appliqué aux rencontres automatiques simulées. Une rencontre jouée manuellement reste déterminée par les coups réellement joués, les règles et les horloges ; aucun résultat manuel n'est artificiellement modifié.
- Les compétences sont des valeurs de simulation internes ; elles ne constituent pas des données sportives historiques.
- La progression quotidienne est graduelle et bornée. Elle ne crée aucun damiste supplémentaire et ne modifie pas la règle de deux damistes par club.
- Les effets de recrutement/scouting sur la génération de rapports et les effets tactiques directs dans le match manuel restent à développer.

## Préservation
Aucun moteur de compétition, calendrier, qualification, classement, règle de déplacement/prise/promotion, horloge, transfert ou identité visuelle n'a été modifié dans cette étape. Le moteur commun de dames demeure la source des coups légaux.
