import { ArrowUp, Bot, Check, ChevronDown, CircleHelp, Clock3, Code2, Cpu, FileBox, FolderKanban, Gamepad2, Gauge, Layers3, LogOut, Menu, MessageSquare, MoreHorizontal, PanelLeftClose, Plus, Radio, RefreshCw, Send, Settings2, ShieldCheck, Sparkles, X, Zap } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useClerk, useUser } from '@clerk/react';
import { getGetGamaOverviewQueryKey, getHealthCheckQueryKey, type GamaChatMessage, type GamaMode, GamaMode as GamaModeValues, useCreateGamaBuild, useGetGamaOverview, useHealthCheck, useSendGamaMessage } from '@workspace/api-client-react';
import { GamaMark } from '@/components/gama/brand';

const modeMeta: Record<GamaMode, { label: string; icon: typeof Code2; color: string }> = {
  build: { label: 'Build', icon: Code2, color: '#2D7C7E' },
  media: { label: 'Media', icon: Radio, color: '#B64D37' },
  hardware: { label: 'Hardware', icon: Cpu, color: '#6F5B95' },
  games: { label: 'Games', icon: Gamepad2, color: '#D68E22' },
  strategy: { label: 'Strategy', icon: Gauge, color: '#2D7C7E' },
};

const starterPrompts = [
  'Turn this rough idea into a build plan',
  'Pressure-test the riskiest assumption',
  'Find the smallest version worth shipping',
];

const metricCards = [
  { key: 'projects', label: 'projects in orbit', icon: Layers3, color: '#2D7C7E' },
  { key: 'activeRuns', label: 'active runs', icon: Zap, color: '#B64D37' },
  { key: 'assets', label: 'assets indexed', icon: FileBox, color: '#6F5B95' },
  { key: 'credits', label: 'credits remaining', icon: Sparkles, color: '#D68E22' },
] as const;

function WorkspaceSkeleton() {
  return <div className="animate-pulse space-y-8" data-testid="workspace-loading"><div className="h-8 w-64 rounded bg-[#17243A]/10" /><div className="grid gap-4 sm:grid-cols-4"><div className="h-28 rounded-2xl bg-[#17243A]/10" /><div className="h-28 rounded-2xl bg-[#17243A]/10" /><div className="h-28 rounded-2xl bg-[#17243A]/10" /><div className="h-28 rounded-2xl bg-[#17243A]/10" /></div><div className="h-[420px] rounded-2xl bg-[#17243A]/10" /></div>;
}

function StatusPill({ status }: { status: string }) {
  const statusLabel = status === 'complete' ? 'Complete' : status === 'running' ? 'Running' : 'Queued';
  return <span className={`inline-flex items-center gap-2 rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.1em] ${status === 'complete' ? 'bg-[#2D7C7E]/10 text-[#2D7C7E]' : status === 'running' ? 'bg-[#F4B844]/25 text-[#95691A]' : 'bg-[#17243A]/8 text-[#17243A]/55'}`} data-testid={`status-activity-${status}`}><span className={`h-1.5 w-1.5 rounded-full ${status === 'complete' ? 'bg-[#2D7C7E]' : status === 'running' ? 'bg-[#F4B844] gama-pulse' : 'bg-[#17243A]/35'}`} />{statusLabel}</span>;
}

export function Workspace() {
  const [, setLocation] = useLocation();
  const { signOut } = useClerk();
  const { user } = useUser();
  const [railOpen, setRailOpen] = useState(false);
  const [mode, setMode] = useState<GamaMode>('build');
  const [message, setMessage] = useState('');
  const [conversation, setConversation] = useState<GamaChatMessage[]>([]);
  const [lastResponse, setLastResponse] = useState<{ message: string; nextSteps: string[] } | null>(null);
  const [buildArtifact, setBuildArtifact] = useState<{ title: string; filename: string } | null>(null);
  const [chatError, setChatError] = useState<string | null>(null);
  const { data: overview, isLoading, isError, refetch } = useGetGamaOverview({ query: { queryKey: getGetGamaOverviewQueryKey() } });
  const { data: health } = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000 } });
  const sendMessage = useSendGamaMessage();
  const createBuild = useCreateGamaBuild();
  const currentMode = modeMeta[mode];
  const CurrentModeIcon = currentMode.icon;
  const initials = useMemo(() => (user?.firstName?.[0] ?? user?.emailAddresses?.[0]?.emailAddress?.[0] ?? 'G').toUpperCase(), [user]);
  const activity = overview?.recentActivity ?? [];

  const submitMessage = (value = message) => {
    const trimmed = value.trim();
    if (!trimmed || sendMessage.isPending) return;
    const nextMessage: GamaChatMessage = { role: 'user', content: trimmed };
    const nextHistory = [...conversation, nextMessage].slice(-24);
    setConversation(nextHistory);
    setMessage('');
    setLastResponse(null);
    setChatError(null);
    sendMessage.mutate({ data: { message: trimmed, mode, history: nextHistory } }, {
      onSuccess: (response) => {
        setConversation((current) => [...current, { role: 'assistant' as const, content: response.message }].slice(-24));
        setLastResponse({ message: response.message, nextSteps: response.nextSteps });
      },
      onError: (error) => {
        setConversation((current) => current.filter((item, index) => !(index === current.length - 1 && item.role === 'user' && item.content === trimmed)));
        setMessage(trimmed);
        setChatError(error instanceof Error ? error.message : 'GAMA could not send that message. Try again.');
      },
    });
  };

  const createBuildFromConversation = () => {
    if (conversation.length === 0 || createBuild.isPending) return;
    createBuild.mutate({ data: { mode, history: conversation.slice(-24) } }, {
      onSuccess: (artifact) => {
        const blob = new Blob([artifact.content], { type: artifact.contentType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = artifact.filename;
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
        setBuildArtifact({ title: artifact.title, filename: artifact.filename });
      },
    });
  };

  return <div className="gama-noise flex min-h-[100dvh] bg-[#F6F2E9] text-[#17243A]">
    <aside className={`fixed inset-y-0 left-0 z-30 flex w-[268px] flex-col bg-[#17243A] px-5 py-6 text-[#F3F0E8] transition-transform duration-300 lg:relative lg:translate-x-0 ${railOpen ? 'translate-x-0' : '-translate-x-full'}`} data-testid="workspace-sidebar">
      <div className="flex items-center justify-between"><Link href="/" className="inline-flex" data-testid="link-workspace-brand"><span className="[&_span]:text-[#F3F0E8]"><GamaMark /></span></Link><button className="grid h-8 w-8 place-items-center rounded-full text-[#F3F0E8]/50 hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8] lg:hidden" onClick={() => setRailOpen(false)} aria-label="Close sidebar" data-testid="button-close-sidebar"><X className="h-4 w-4" /></button></div>
      <div className="mt-12"><p className="gama-mono px-3 text-[10px] uppercase tracking-[0.16em] text-[#F4B844]/70">Command center</p><nav className="mt-4 grid gap-1" aria-label="Workspace navigation">
        <button className="flex items-center gap-3 rounded-xl bg-[#F4B844] px-3 py-3 text-left text-sm font-semibold text-[#17243A]" data-testid="button-nav-overview"><Gauge className="h-4 w-4" /> Overview <span className="ml-auto text-[10px] uppercase opacity-50">now</span></button>
        <button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-[#F3F0E8]/60 transition-colors hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8]" onClick={() => setMessage('Show me all active runs and what they need next.')} data-testid="button-nav-runs"><Zap className="h-4 w-4" /> Active runs <span className="ml-auto rounded-full bg-[#F3F0E8]/10 px-2 py-0.5 text-[10px]">{overview?.activeRuns ?? '—'}</span></button>
        <button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-[#F3F0E8]/60 transition-colors hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8]" onClick={() => setMessage('Help me organize my latest assets.')} data-testid="button-nav-assets"><FileBox className="h-4 w-4" /> Assets <span className="ml-auto rounded-full bg-[#F3F0E8]/10 px-2 py-0.5 text-[10px]">{overview?.assets ?? '—'}</span></button>
        <button className="flex items-center gap-3 rounded-xl px-3 py-3 text-left text-sm text-[#F3F0E8]/60 transition-colors hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8]" onClick={() => setMessage('Give me a snapshot of my projects.')} data-testid="button-nav-projects"><FolderKanban className="h-4 w-4" /> Projects <span className="ml-auto rounded-full bg-[#F3F0E8]/10 px-2 py-0.5 text-[10px]">{overview?.projects ?? '—'}</span></button>
      </nav></div>
      <div className="mt-auto">
        <div className="rounded-2xl border border-[#F3F0E8]/12 bg-[#F3F0E8]/5 p-4"><div className="flex items-center gap-2 text-xs font-semibold"><ShieldCheck className="h-4 w-4 text-[#F4B844]" /> Private workspace</div><p className="mt-2 text-xs leading-relaxed text-[#F3F0E8]/45">Your ideas stay in your room. GAMA only moves when you ask it to.</p></div>
        <div className="mt-5 grid gap-1"><button className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs text-[#F3F0E8]/55 hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8]" onClick={() => setMessage('Help')} data-testid="button-help"><CircleHelp className="h-4 w-4" /> Help & guidance</button><button className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-left text-xs text-[#F3F0E8]/55 hover:bg-[#F3F0E8]/10 hover:text-[#F3F0E8]" onClick={() => setMessage('Open workspace settings.')} data-testid="button-settings"><Settings2 className="h-4 w-4" /> Workspace settings</button></div>
      </div>
    </aside>
    {railOpen && <button className="fixed inset-0 z-20 bg-[#17243A]/35 lg:hidden" onClick={() => setRailOpen(false)} aria-label="Close navigation overlay" data-testid="button-navigation-overlay" />}
    <section className="min-w-0 flex-1">
      <header className="flex h-[76px] items-center justify-between border-b border-[#17243A]/10 px-5 sm:px-8">
        <div className="flex items-center gap-3"><button className="grid h-9 w-9 place-items-center rounded-lg border border-[#17243A]/12 lg:hidden" onClick={() => setRailOpen(true)} aria-label="Open sidebar" data-testid="button-open-sidebar"><Menu className="h-4 w-4" /></button><span className="gama-mono text-[11px] uppercase tracking-[0.15em] text-[#17243A]/45">Workspace / overview</span></div>
        <div className="flex items-center gap-4"><div className="hidden items-center gap-2 text-[10px] uppercase tracking-[0.12em] text-[#17243A]/45 sm:flex" data-testid="status-system-health"><span className={`h-1.5 w-1.5 rounded-full ${health?.status === 'ok' ? 'bg-[#2D7C7E]' : 'bg-[#F4B844]'}`} /> system {health?.status === 'ok' ? 'nominal' : 'checking'}</div><button className="grid h-9 w-9 place-items-center rounded-full bg-[#2D7C7E] text-xs font-semibold text-[#F3F0E8]" onClick={() => signOut({ redirectUrl: import.meta.env.BASE_URL || '/' })} aria-label="Sign out" data-testid="button-sign-out">{initials}</button></div>
      </header>
      <main className="mx-auto max-w-[1280px] px-5 py-8 sm:px-8 sm:py-10">
        {isLoading ? <WorkspaceSkeleton /> : isError ? <div className="grid min-h-[60vh] place-items-center" data-testid="workspace-error"><div className="max-w-sm text-center"><div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-[#B64D37]/10 text-[#B64D37]"><RefreshCw className="h-5 w-5" /></div><h1 className="mt-5 text-xl font-semibold">The room is quiet.</h1><p className="mt-2 text-sm text-[#17243A]/55">We couldn't load your workspace signal. Try the connection again.</p><button className="mt-6 inline-flex items-center gap-2 rounded-full bg-[#17243A] px-5 py-3 text-sm font-semibold text-[#F3F0E8]" onClick={() => refetch()} data-testid="button-retry-overview"><RefreshCw className="h-4 w-4" /> Retry connection</button></div></div> : <div className="space-y-9">
          <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="gama-mono text-[10px] uppercase tracking-[0.16em] text-[#B64D37]">Signal online / {new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</p><h1 className="mt-3 text-3xl font-semibold tracking-[-0.05em] sm:text-4xl">Good to see you{user?.firstName ? `, ${user.firstName}` : ''}.</h1><p className="mt-2 text-sm text-[#17243A]/55">What are we making clearer today?</p></div><div className="flex items-center gap-2 text-xs text-[#17243A]/45"><span className="h-2 w-2 rounded-full bg-[#2D7C7E]" /> Foundry ready</div></div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {metricCards.map((metric) => { const Icon = metric.icon; const value = overview?.[metric.key] ?? 0; return <div key={metric.key} className="rounded-2xl border border-[#17243A]/10 bg-[#FBF8F1] p-5 transition-transform hover:-translate-y-1" data-testid={`card-metric-${metric.key}`}><div className="flex items-start justify-between"><span className="gama-mono text-2xl font-medium tracking-[-0.06em]">{value}</span><Icon className="h-4 w-4" style={{ color: metric.color }} /></div><p className="mt-6 text-xs text-[#17243A]/50">{metric.label}</p></div>; })}
          </div>
          <div className="grid gap-6 xl:grid-cols-[1.35fr_.65fr]">
            <section className="overflow-hidden rounded-2xl border border-[#17243A]/10 bg-[#17243A] text-[#F3F0E8]" data-testid="card-gama-chat">
              <div className="gama-grid-dark border-b border-[#F3F0E8]/10 px-5 py-5 sm:px-7"><div className="flex items-start justify-between"><div><div className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#F4B844] gama-pulse" /><p className="gama-mono text-[10px] uppercase tracking-[0.15em] text-[#F4B844]">GAMA / thinking room</p></div><h2 className="mt-3 text-xl font-medium tracking-[-0.03em]">Put the rough version here.</h2></div><Bot className="h-5 w-5 text-[#F4B844]" /></div><div className="mt-6 flex flex-wrap gap-2">{(Object.keys(modeMeta) as GamaMode[]).map((key) => { const meta = modeMeta[key]; const Icon = meta.icon; return <button key={key} onClick={() => setMode(key)} className={`inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs transition-colors ${mode === key ? 'border-[#F4B844] bg-[#F4B844] font-semibold text-[#17243A]' : 'border-[#F3F0E8]/15 text-[#F3F0E8]/55 hover:border-[#F3F0E8]/45 hover:text-[#F3F0E8]'}`} data-testid={`button-chat-mode-${key}`}><Icon className="h-3.5 w-3.5" />{meta.label}</button>; })}</div></div>
              <div className="min-h-[238px] space-y-4 p-5 sm:p-7" data-testid="chat-message-list">{conversation.length === 0 && !lastResponse ? <div className="flex min-h-[180px] flex-col items-center justify-center text-center"><MessageSquare className="h-5 w-5 text-[#F4B844]" /><p className="mt-4 max-w-sm text-sm leading-relaxed text-[#F3F0E8]/55">Ask for a plan, a sharper question, or a second brain. GAMA will keep the thread moving.</p></div> : conversation.map((item, index) => <div key={`${item.role}-${index}`} className={`flex gap-3 ${item.role === 'user' ? 'justify-end' : ''}`} data-testid={`chat-message-${item.role}-${index}`}><div className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${item.role === 'user' ? 'bg-[#F4B844] text-[#17243A]' : 'bg-[#F3F0E8]/8 text-[#F3F0E8]/80'}`}>{item.content}</div></div>)}</div>
              {chatError && <div className="mx-5 mb-4 flex items-start gap-2 rounded-xl border border-[#F4B844]/35 bg-[#B64D37]/20 px-4 py-3 text-xs leading-relaxed text-[#F3F0E8]/85 sm:mx-7" role="alert" data-testid="text-chat-error"><CircleHelp className="mt-0.5 h-4 w-4 shrink-0 text-[#F4B844]" /><span>{chatError}</span></div>}
              {lastResponse && <div className="border-t border-[#F3F0E8]/10 px-5 py-4 sm:px-7"><div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between"><div><p className="gama-mono text-[10px] uppercase text-[#F4B844]">Turn direction into a build</p><p className="mt-2 max-w-md text-xs leading-relaxed text-[#F3F0E8]/55">GAMA will create a real downloadable artifact from this conversation.</p>{buildArtifact && <p className="mt-2 flex items-center gap-2 text-xs text-[#F4B844]" data-testid="text-build-created"><Check className="h-3.5 w-3.5" /> {buildArtifact.title} · {buildArtifact.filename}</p>}{createBuild.isError && <p className="mt-2 text-xs text-[#F4B844]" data-testid="text-build-error">The build could not be created. Try again.</p>}</div><button onClick={createBuildFromConversation} disabled={createBuild.isPending || conversation.length === 0} className="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-[#F4B844] px-4 py-2.5 text-xs font-semibold text-[#17243A] transition-opacity disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-create-gama-build"><Zap className="h-3.5 w-3.5" /> {createBuild.isPending ? 'Creating build...' : 'Create build'}</button></div>{lastResponse.nextSteps.length > 0 && <div className="mt-4 flex flex-wrap gap-2">{lastResponse.nextSteps.map((step, index) => <button key={step} onClick={() => submitMessage(step)} className="rounded-full border border-[#F3F0E8]/15 px-3 py-2 text-left text-xs text-[#F3F0E8]/65 transition-colors hover:border-[#F4B844] hover:text-[#F4B844]" data-testid={`button-next-step-${index}`}>{step}</button>)}</div>}</div>}
              <div className="border-t border-[#F3F0E8]/10 p-4 sm:p-5"><div className="rounded-xl border border-[#F3F0E8]/15 bg-[#F3F0E8]/5 p-2 focus-within:border-[#F4B844]/70"><textarea value={message} onChange={(event) => setMessage(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); submitMessage(); } }} placeholder={`Ask GAMA in ${currentMode.label.toLowerCase()} mode...`} className="min-h-[76px] w-full resize-none bg-transparent px-2 py-1 text-sm text-[#F3F0E8] outline-none placeholder:text-[#F3F0E8]/30" maxLength={12000} data-testid="input-gama-message" /><div className="flex items-center justify-between gap-3 px-2 pt-2"><span className="text-[10px] text-[#F3F0E8]/30">Shift + Enter for a new line</span><button onClick={() => submitMessage()} disabled={!message.trim() || sendMessage.isPending} className="inline-flex items-center gap-2 rounded-lg bg-[#F4B844] px-4 py-2.5 text-xs font-semibold text-[#17243A] transition-opacity disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-send-gama">{sendMessage.isPending ? 'Thinking...' : 'Send'} <Send className="h-3.5 w-3.5" /></button></div></div></div>
            </section>
            <aside className="rounded-2xl border border-[#17243A]/10 bg-[#E8E2D5] p-5 sm:p-6" data-testid="card-starter-prompts"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Sparkles className="h-4 w-4 text-[#B64D37]" /><h2 className="text-sm font-semibold">Start somewhere</h2></div><span className="gama-mono text-[10px] text-[#17243A]/40">prompts</span></div><p className="mt-3 text-xs leading-relaxed text-[#17243A]/55">The best conversations start a little unfinished.</p><div className="mt-7 grid gap-2">{starterPrompts.map((prompt, index) => <button key={prompt} onClick={() => { setMessage(prompt); }} className="group flex items-center justify-between gap-3 rounded-xl border border-[#17243A]/10 bg-[#F6F2E9] p-3 text-left text-xs text-[#17243A]/70 transition-all hover:-translate-y-0.5 hover:border-[#B64D37]/40 hover:text-[#17243A]" data-testid={`button-starter-prompt-${index}`}><span>{prompt}</span><ArrowUp className="h-3.5 w-3.5 rotate-45 text-[#B64D37] transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" /></button>)}</div><div className="mt-8 border-t border-[#17243A]/10 pt-5"><p className="gama-mono text-[10px] uppercase text-[#17243A]/40">Mode selected</p><div className="mt-3 flex items-center gap-3"><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#17243A] text-[#F4B844]"><CurrentModeIcon className="h-4 w-4" /></span><div><p className="text-sm font-semibold">{currentMode.label}</p><p className="text-xs text-[#17243A]/50">Context tuned for your ask</p></div></div></div></aside>
          </div>
          <section className="rounded-2xl border border-[#17243A]/10 bg-[#FBF8F1] p-5 sm:p-7" data-testid="card-recent-activity"><div className="flex items-center justify-between"><div><p className="gama-mono text-[10px] uppercase tracking-[0.15em] text-[#2D7C7E]">The trail</p><h2 className="mt-2 text-xl font-semibold tracking-[-0.03em]">Recent activity</h2></div><button className="grid h-8 w-8 place-items-center rounded-full border border-[#17243A]/12 text-[#17243A]/45 hover:bg-[#E8E2D5] hover:text-[#17243A]" onClick={() => refetch()} aria-label="Refresh recent activity" data-testid="button-refresh-activity"><RefreshCw className="h-3.5 w-3.5" /></button></div>{activity.length === 0 ? <div className="grid min-h-[150px] place-items-center text-center"><Clock3 className="h-5 w-5 text-[#17243A]/30" /><p className="mt-3 text-sm text-[#17243A]/50">Your first move will show up here.</p></div> : <div className="mt-6 divide-y divide-[#17243A]/8">{activity.map((item, index) => <div key={`${item.title}-${index}`} className="grid gap-3 py-4 first:pt-0 sm:grid-cols-[1fr_auto_auto] sm:items-center" data-testid={`row-recent-activity-${index}`}><div className="flex items-start gap-3"><span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-[#E8E2D5] text-[#2D7C7E]"><Radio className="h-3.5 w-3.5" /></span><div><p className="text-sm font-semibold">{item.title}</p><p className="mt-1 text-xs text-[#17243A]/50">{item.detail}</p></div></div><span className="text-xs text-[#17243A]/40">{item.time}</span><StatusPill status={item.status} /></div>)}</div>}</section>
        </div>}
      </main>
    </section>
  </div>;
}