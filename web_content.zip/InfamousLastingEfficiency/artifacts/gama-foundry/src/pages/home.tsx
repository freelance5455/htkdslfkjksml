import { ArrowDown, ArrowRight, Check, ChevronRight, Command, Cpu, Crosshair, Gamepad2, Layers3, LockKeyhole, Menu, Play, Radio, ScanLine, Sparkles, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'wouter';
import { BrandLink, GamaMark } from '@/components/gama/brand';

const modes = [
  { key: 'build', label: 'Build', desc: 'Ship software that holds up.', icon: Command, color: '#2D7C7E' },
  { key: 'media', label: 'Media', desc: 'Direct the signal.', icon: Radio, color: '#B64D37' },
  { key: 'hardware', label: 'Hardware', desc: 'Make the physical real.', icon: Cpu, color: '#6F5B95' },
  { key: 'games', label: 'Games', desc: 'Design worlds with gravity.', icon: Gamepad2, color: '#D68E22' },
  { key: 'strategy', label: 'Strategy', desc: 'Find the move beneath the noise.', icon: Crosshair, color: '#2D7C7E' },
];

export function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeMode, setActiveMode] = useState('build');

  return (
    <main className="gama-noise overflow-hidden bg-[#F6F2E9] text-[#17243A]">
      <header className="relative z-20 mx-auto flex w-full max-w-[1240px] items-center justify-between px-6 py-6 lg:px-10">
        <BrandLink />
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
          <a href="#operating-system" className="text-sm text-[#17243A]/65 transition-colors hover:text-[#17243A]" data-testid="link-operating-system">Operating system</a>
          <a href="#modes" className="text-sm text-[#17243A]/65 transition-colors hover:text-[#17243A]" data-testid="link-modes">Modes</a>
          <a href="#manifesto" className="text-sm text-[#17243A]/65 transition-colors hover:text-[#17243A]" data-testid="link-manifesto">Manifesto</a>
        </nav>
        <div className="hidden items-center gap-5 md:flex">
          <Link href="/sign-in" className="text-sm font-semibold text-[#17243A]/70 transition-colors hover:text-[#17243A]" data-testid="link-sign-in">Sign in</Link>
          <Link href="/sign-up" className="inline-flex items-center gap-2 rounded-full bg-[#17243A] px-5 py-3 text-sm font-semibold text-[#F6F2E9] shadow-[4px_4px_0_#F4B844] transition-all hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[2px_2px_0_#F4B844]" data-testid="link-create-account">Create account <ArrowRight className="h-4 w-4" /></Link>
        </div>
        <button className="grid h-10 w-10 place-items-center rounded-full border border-[#17243A]/15 md:hidden" onClick={() => setMenuOpen((current) => !current)} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} data-testid="button-mobile-menu">
          {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </header>

      {menuOpen && (
        <div className="relative z-20 mx-6 mb-4 rounded-2xl border border-[#17243A]/12 bg-[#F3EDE0] p-5 md:hidden" data-testid="mobile-navigation">
          <div className="grid gap-4 text-sm">
            <a href="#operating-system" onClick={() => setMenuOpen(false)} data-testid="link-mobile-operating-system">Operating system</a>
            <a href="#modes" onClick={() => setMenuOpen(false)} data-testid="link-mobile-modes">Modes</a>
            <a href="#manifesto" onClick={() => setMenuOpen(false)} data-testid="link-mobile-manifesto">Manifesto</a>
            <div className="mt-2 flex gap-4 border-t border-[#17243A]/10 pt-4">
              <Link href="/sign-in" className="font-semibold" data-testid="link-mobile-sign-in">Sign in</Link>
              <Link href="/sign-up" className="font-semibold text-[#B64D37]" data-testid="link-mobile-sign-up">Create account</Link>
            </div>
          </div>
        </div>
      )}

      <section className="gama-grid relative mx-4 overflow-hidden rounded-[28px] border border-[#17243A]/10 bg-[#EAE5D8] sm:mx-6 lg:mx-10">
        <div className="absolute -right-20 top-8 h-64 w-64 rounded-full bg-[#F4B844]/25 blur-3xl" />
        <div className="absolute bottom-[-100px] left-[42%] h-72 w-72 rounded-full bg-[#2D7C7E]/15 blur-3xl" />
        <div className="relative mx-auto grid max-w-[1240px] gap-14 px-6 pb-20 pt-16 sm:pt-24 lg:grid-cols-[1.05fr_.95fr] lg:gap-8 lg:px-10 lg:pb-28 lg:pt-28">
          <div className="max-w-[720px]">
            <div className="gama-reveal mb-8 flex items-center gap-3 text-xs font-medium uppercase tracking-[0.18em] text-[#2D7C7E]"><span className="h-2 w-2 rounded-full bg-[#2D7C7E] gama-pulse" /> The personal command center for ambitious builders</div>
            <h1 className="gama-reveal gama-reveal-delay-1 max-w-[700px] text-[clamp(3.5rem,8vw,7.7rem)] font-semibold leading-[0.89] tracking-[-0.075em] text-[#17243A]">Make the idea<br /><span className="text-[#B64D37]">production.</span></h1>
            <p className="gama-reveal gama-reveal-delay-2 mt-8 max-w-[530px] text-lg leading-relaxed text-[#17243A]/65 sm:text-xl">GAMA turns plain-language intent into working software, media, games, and hardware plans — with the rigor to take them all the way.</p>
            <div className="gama-reveal gama-reveal-delay-3 mt-10 flex flex-col items-start gap-4 sm:flex-row sm:items-center">
              <Link href="/sign-up" className="inline-flex items-center gap-3 rounded-full bg-[#17243A] px-6 py-4 text-sm font-semibold text-[#F6F2E9] shadow-[5px_5px_0_#F4B844] transition-all hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[3px_3px_0_#F4B844]" data-testid="link-hero-start-building">Start building <ArrowRight className="h-4 w-4" /></Link>
              <a href="#operating-system" className="inline-flex items-center gap-2 px-2 py-3 text-sm font-semibold text-[#17243A]/65 hover:text-[#17243A]" data-testid="link-hero-see-how">See how it works <ArrowDown className="h-4 w-4" /></a>
            </div>
          </div>
          <div className="relative flex min-h-[360px] items-center justify-center lg:min-h-[480px]">
            <div className="absolute right-[12%] top-[4%] h-20 w-20 rounded-full border border-[#B64D37]/30" />
            <div className="absolute bottom-[8%] left-[5%] h-12 w-12 rounded-full border border-[#2D7C7E]/40" />
            <div className="relative aspect-square w-[min(82vw,420px)] rounded-[34%] border border-[#17243A]/20 bg-[#17243A] p-5 shadow-[15px_15px_0_rgba(23,36,58,.12)] rotate-[4deg] transition-transform duration-700 hover:rotate-0">
              <div className="gama-grid-dark flex h-full flex-col justify-between rounded-[28%] border border-[#F4B844]/25 p-6 text-[#F6F2E9] sm:p-8">
                <div className="flex items-start justify-between">
                  <div><p className="gama-mono text-[10px] uppercase text-[#F4B844]">GAMA / core</p><p className="mt-2 text-lg font-medium">Intent → outcome</p></div>
                  <ScanLine className="h-6 w-6 text-[#F4B844]" />
                </div>
                <div className="relative mx-auto w-full max-w-[260px]">
                  <div className="absolute left-1/2 top-1/2 h-36 w-36 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#F4B844]/20" />
                  <div className="absolute left-1/2 top-1/2 h-24 w-24 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#2D7C7E]/40" />
                  <div className="relative mx-auto grid h-28 w-28 place-items-center rounded-full border-2 border-[#F4B844] bg-[#17243A] shadow-[0_0_0_10px_rgba(244,184,68,.08)]"><GamaMark compact /></div>
                </div>
                <div className="flex items-end justify-between border-t border-[#F3F0E8]/15 pt-4">
                  <div><p className="gama-mono text-[10px] uppercase text-[#F3F0E8]/45">current signal</p><p className="mt-1 text-sm">A sharp idea, in motion.</p></div>
                  <div className="h-2 w-2 rounded-full bg-[#F4B844] gama-pulse" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-4 right-7 hidden items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-[#17243A]/40 lg:flex"><span>01</span><span className="h-px w-12 bg-[#17243A]/25" /><span>signal detected</span></div>
      </section>

      <section id="operating-system" className="mx-auto max-w-[1240px] px-6 py-24 lg:px-10 lg:py-36">
        <div className="grid gap-14 lg:grid-cols-[.7fr_1.3fr]">
          <div><p className="gama-mono text-xs uppercase text-[#B64D37]">01 / Operating system</p><h2 className="mt-5 max-w-[380px] text-4xl font-semibold leading-tight tracking-[-0.05em] sm:text-5xl">The distance between a thought and a shipped thing.</h2></div>
          <div className="grid gap-10 sm:grid-cols-3">
            {[
              ['01', 'State the intent', 'Start with the thing you can explain, not the tool you think you need.', Command],
              ['02', 'Choose your mode', 'GAMA shifts its lens — product, story, system, strategy — without losing context.', Layers3],
              ['03', 'Keep the thread', 'Your plans, runs, assets, and decisions stay in one private, searchable memory.', LockKeyhole],
            ].map(([number, title, detail, Icon]) => (
              <div key={number as string} className="border-t border-[#17243A]/20 pt-5" data-testid={`card-operating-step-${number}`}>
                <div className="flex items-center justify-between"><span className="gama-mono text-xs text-[#17243A]/45">{number as string}</span><Icon className="h-5 w-5 text-[#2D7C7E]" /></div>
                <h3 className="mt-10 text-xl font-semibold">{title as string}</h3><p className="mt-3 text-sm leading-relaxed text-[#17243A]/60">{detail as string}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="modes" className="bg-[#17243A] px-6 py-24 text-[#F3F0E8] lg:px-10 lg:py-32">
        <div className="mx-auto max-w-[1240px]">
          <div className="flex flex-col justify-between gap-8 border-b border-[#F3F0E8]/15 pb-10 md:flex-row md:items-end">
            <div><p className="gama-mono text-xs uppercase text-[#F4B844]">02 / Five ways in</p><h2 className="mt-5 max-w-[600px] text-4xl font-semibold leading-[.95] tracking-[-0.06em] sm:text-6xl">Bring your whole<br /><span className="text-[#F4B844]">range.</span></h2></div>
            <p className="max-w-[300px] text-sm leading-relaxed text-[#F3F0E8]/55">One mind. Five lenses. No context switching tax.</p>
          </div>
          <div className="grid gap-3 pt-10 md:grid-cols-5">
            {modes.map((mode) => {
              const Icon = mode.icon;
              const isActive = activeMode === mode.key;
              return <button key={mode.key} onClick={() => setActiveMode(mode.key)} className={`group min-h-[190px] border p-5 text-left transition-all ${isActive ? 'border-[#F4B844] bg-[#F4B844] text-[#17243A] -translate-y-1' : 'border-[#F3F0E8]/15 bg-transparent text-[#F3F0E8] hover:-translate-y-1 hover:border-[#F3F0E8]/50'}`} data-testid={`button-mode-${mode.key}`}>
                <div className="flex items-start justify-between"><span className="gama-mono text-[10px] uppercase opacity-55">0{modes.indexOf(mode) + 1}</span><Icon className="h-5 w-5" style={{ color: isActive ? '#17243A' : mode.color }} /></div>
                <div className="mt-16"><p className="text-lg font-semibold">{mode.label}</p><p className={`mt-2 text-xs leading-relaxed ${isActive ? 'text-[#17243A]/70' : 'text-[#F3F0E8]/50'}`}>{mode.desc}</p></div>
              </button>;
            })}
          </div>
          <div className="mt-10 flex flex-col items-start justify-between gap-6 border border-[#F3F0E8]/15 p-6 sm:flex-row sm:items-center">
            <div className="flex items-center gap-3"><span className="h-2 w-2 rounded-full bg-[#F4B844]" /><p className="text-sm">GAMA is ready for <span className="font-semibold text-[#F4B844]">{activeMode}</span> work.</p></div>
            <Link href="/sign-up" className="inline-flex items-center gap-2 text-sm font-semibold hover:text-[#F4B844]" data-testid="link-mode-continue">Continue with this mode <ChevronRight className="h-4 w-4" /></Link>
          </div>
        </div>
      </section>

      <section id="manifesto" className="mx-auto max-w-[1240px] px-6 py-24 lg:px-10 lg:py-36">
        <div className="grid items-start gap-12 lg:grid-cols-[1.2fr_.8fr]">
          <div><p className="gama-mono text-xs uppercase text-[#2D7C7E]">03 / A different kind of tool</p><p className="mt-8 max-w-[780px] text-4xl font-medium leading-[1.04] tracking-[-0.055em] sm:text-6xl">Not another chatbot in a browser tab. <span className="text-[#B64D37]">A foundry for the work that matters.</span></p></div>
          <div className="border-l border-[#17243A]/15 pl-6 lg:mt-16"><Sparkles className="h-5 w-5 text-[#F4B844]" /><p className="mt-5 text-sm leading-relaxed text-[#17243A]/65">GAMA is designed for the messy middle: the part where a sketch becomes a system, a hunch becomes a brief, and a late-night question becomes a real artifact.</p><div className="mt-8 flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.14em] text-[#17243A]/45"><span className="h-px w-10 bg-[#B64D37]" /> Built for range</div></div>
        </div>
        <div className="mt-24 grid overflow-hidden rounded-[24px] bg-[#E6DFD0] sm:grid-cols-2">
          <div className="gama-grid-dark min-h-[300px] bg-[#2D7C7E] p-8 text-[#F3F0E8] sm:min-h-[380px]"><div className="flex h-full flex-col justify-between"><div className="flex justify-between"><span className="gama-mono text-xs uppercase text-[#F4B844]">private by design</span><LockKeyhole className="h-5 w-5 text-[#F4B844]" /></div><p className="max-w-[340px] text-3xl font-medium leading-tight tracking-[-0.04em]">Your unfinished thinking deserves a secure room to get sharper.</p></div></div>
          <div className="flex min-h-[300px] flex-col justify-between p-8 sm:min-h-[380px]"><div className="flex justify-between"><span className="gama-mono text-xs uppercase text-[#B64D37]">always in context</span><Play className="h-5 w-5 text-[#B64D37]" /></div><p className="max-w-[340px] text-3xl font-medium leading-tight tracking-[-0.04em]">Every run leaves a trail you can pick up tomorrow.</p></div>
        </div>
      </section>

      <section className="mx-4 mb-4 overflow-hidden rounded-[28px] bg-[#F4B844] px-6 py-20 sm:mx-6 lg:mx-10 lg:px-10 lg:py-28">
        <div className="mx-auto flex max-w-[1240px] flex-col justify-between gap-12 md:flex-row md:items-end">
          <div><p className="gama-mono text-xs uppercase text-[#17243A]/55">04 / Your next move</p><h2 className="mt-6 max-w-[680px] text-5xl font-semibold leading-[.92] tracking-[-0.07em] sm:text-7xl">Bring the idea<br />you keep circling.</h2></div>
          <Link href="/sign-up" className="inline-flex w-fit items-center gap-3 rounded-full bg-[#17243A] px-6 py-4 text-sm font-semibold text-[#F3F0E8] transition-transform hover:translate-x-1" data-testid="link-final-create-account">Open your foundry <ArrowRight className="h-4 w-4" /></Link>
        </div>
      </section>

      <footer className="mx-auto flex max-w-[1240px] flex-col justify-between gap-5 px-6 py-10 text-xs text-[#17243A]/50 sm:flex-row sm:items-center lg:px-10">
        <BrandLink />
        <div className="flex items-center gap-5"><span>GAMA / 2025</span><span className="h-1 w-1 rounded-full bg-[#B64D37]" /><span>Private creative infrastructure</span></div>
      </footer>
    </main>
  );
}