import { ArrowUpRight } from 'lucide-react';
import { Link } from 'wouter';

export function GamaMark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3" data-testid="brand-gama">
      <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-[11px] bg-[#17243A] shadow-[3px_3px_0_#F4B844]">
        <span className="absolute left-[9px] top-[9px] h-[18px] w-[18px] border-[2px] border-[#F4B844]" />
        <span className="absolute right-[7px] top-[7px] h-[8px] w-[8px] border-b-[2px] border-l-[2px] border-[#F4B844]" />
        <span className="absolute bottom-[7px] right-[7px] h-[7px] w-[7px] rounded-full bg-[#2D7C7E] ring-[2px] ring-[#17243A]" />
      </span>
      {!compact && (
        <span className="gama-wordmark text-[15px] text-[#17243A]">GAMA <span className="font-normal tracking-[0.02em] text-[#2D7C7E]">FOUNDRY</span></span>
      )}
    </span>
  );
}

export function BrandLink({ dark = false }: { dark?: boolean }) {
  return (
    <Link href="/" className="inline-flex items-center" data-testid="link-brand-home">
      <span className={dark ? '[&_span]:text-[#F3F0E8]' : ''}>
        <GamaMark />
      </span>
    </Link>
  );
}

export function ArrowLink({ href, children, dark = false }: { href: string; children: string; dark?: boolean }) {
  return (
    <Link
      href={href}
      className={`group inline-flex items-center gap-2 text-sm font-semibold transition-colors ${dark ? 'text-[#F3F0E8] hover:text-[#F4B844]' : 'text-[#17243A] hover:text-[#B64D37]'}`}
      data-testid={`link-${children.toLowerCase().replaceAll(' ', '-')}`}
    >
      {children}
      <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
    </Link>
  );
}