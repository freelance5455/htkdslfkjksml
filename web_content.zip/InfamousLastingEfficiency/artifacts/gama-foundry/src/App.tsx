import { type ReactNode, useEffect, useRef } from 'react';
import { ClerkProvider, Show, SignIn, SignUp, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Home } from '@/pages/home';
import NotFound from '@/pages/not-found';
import { Workspace } from '@/pages/workspace';
import {
  Redirect,
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

if (!clerkPubKey) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in .env file');
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: 'bottom' as const,
    socialButtonsVariant: 'blockButton' as const,
  },
  variables: {
    colorPrimary: '#2D7C7E',
    colorForeground: '#17243A',
    colorMutedForeground: '#687183',
    colorDanger: '#B64D37',
    colorBackground: '#FBF8F1',
    colorInput: '#F3EDE0',
    colorInputForeground: '#17243A',
    colorNeutral: '#CBD0D0',
    fontFamily: 'Space Grotesk, sans-serif',
    borderRadius: '0.8rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#FBF8F1] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#17243A]/10 shadow-[8px_8px_0_#F4B844]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#17243A] font-semibold',
    headerSubtitle: 'text-[#687183]',
    socialButtonsBlockButtonText: 'text-[#17243A] font-medium',
    formFieldLabel: 'text-[#17243A] font-medium',
    footerActionLink: 'text-[#2D7C7E] font-semibold',
    footerActionText: 'text-[#687183]',
    dividerText: 'text-[#687183]',
    identityPreviewEditButton: 'text-[#2D7C7E]',
    formFieldSuccessText: 'text-[#2D7C7E]',
    alertText: 'text-[#B64D37]',
    logoBox: 'h-12',
    logoImage: 'h-10 w-10',
    socialButtonsBlockButton: 'border-[#17243A]/15 bg-[#F3EDE0] hover:bg-[#E8E2D5]',
    formButtonPrimary: 'bg-[#17243A] text-[#F3F0E8] hover:bg-[#2D7C7E]',
    formFieldInput: 'border-[#17243A]/15 bg-[#F3EDE0] text-[#17243A]',
    footerAction: 'border-t border-[#17243A]/10',
    dividerLine: 'bg-[#17243A]/12',
    alert: 'border-[#B64D37]/25 bg-[#B64D37]/8',
    otpCodeFieldInput: 'border-[#17243A]/15 bg-[#F3EDE0] text-[#17243A]',
    formFieldRow: 'gap-2',
    main: 'bg-transparent',
  },
};

function stripBase(path: string) {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/workspace" />
      </Show>
      <Show when="signed-out">
        <Home />
      </Show>
    </>
  );
}

function WorkspaceGate() {
  return (
    <>
      <Show when="signed-in">
        <Workspace />
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

function SignInPage() {
  return (
    <div className="gama-noise flex min-h-[100dvh] items-center justify-center bg-[#17243A] px-4 py-10">
      <div className="absolute left-0 top-0 hidden h-full w-1/2 gama-grid-dark opacity-60 lg:block" />
      <div className="relative z-10 w-full max-w-[440px]">
        <div className="mb-8 flex items-center justify-center">
          <a href={basePath || '/'} className="[&_span]:text-[#F3F0E8]" data-testid="link-sign-in-logo"><span><span className="flex items-center gap-3"><img src={`${basePath}/logo.svg`} alt="GAMA" className="h-10 w-10" /><span className="gama-wordmark text-[15px] text-[#F3F0E8]">GAMA <span className="font-normal text-[#F4B844]">FOUNDRY</span></span></span></span></a>
        </div>
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
        <p className="mt-8 text-center gama-mono text-[10px] uppercase tracking-[0.15em] text-[#F3F0E8]/35">A private room for unfinished thinking</p>
      </div>
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="gama-noise flex min-h-[100dvh] items-center justify-center bg-[#17243A] px-4 py-10">
      <div className="absolute right-0 top-0 hidden h-full w-1/2 gama-grid-dark opacity-60 lg:block" />
      <div className="relative z-10 w-full max-w-[440px]">
        <div className="mb-8 flex items-center justify-center">
          <a href={basePath || '/'} className="[&_span]:text-[#F3F0E8]" data-testid="link-sign-up-logo"><span><span className="flex items-center gap-3"><img src={`${basePath}/logo.svg`} alt="GAMA" className="h-10 w-10" /><span className="gama-wordmark text-[15px] text-[#F3F0E8]">GAMA <span className="font-normal text-[#F4B844]">FOUNDRY</span></span></span></span></a>
        </div>
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
        <p className="mt-8 text-center gama-mono text-[10px] uppercase tracking-[0.15em] text-[#F3F0E8]/35">Your next move starts here</p>
      </div>
    </div>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const currentQueryClient = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) {
        currentQueryClient.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, currentQueryClient]);

  return null;
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={HomeRedirect} />
        <Route path="/sign-in/*?" component={SignInPage} />
        <Route path="/sign-up/*?" component={SignUpPage} />
        <Route path="/workspace" component={WorkspaceGate} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: { start: { title: 'Welcome back, builder', subtitle: 'Your room is waiting.' } },
        signUp: { start: { title: 'Open your foundry', subtitle: 'Make the idea production.' } },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <ClerkQueryClientCacheInvalidator />
          <Router />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <WouterRouter base={basePath}>
      <ClerkProviderWithRoutes />
    </WouterRouter>
  );
}

export default App;
