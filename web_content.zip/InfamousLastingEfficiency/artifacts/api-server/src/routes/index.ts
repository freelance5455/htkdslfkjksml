import { Router, type IRouter } from "express";
import healthRouter from "./health";
import gamaRouter from "./gama";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gamaRouter);

export default router;
