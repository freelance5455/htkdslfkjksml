import { Router, type IRouter, type RequestHandler } from "express";
import { getAuth } from "@clerk/express";
import {
  CreateGamaBuildBody,
  CreateGamaBuildResponse,
  GetGamaOverviewResponse,
  SendGamaMessageBody,
  SendGamaMessageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const requireAuth: RequestHandler = (req, res, next) => {
  const auth = getAuth(req);
  if (!auth.userId) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }
  next();
};

const systemPrompt = `You are GAMA, the Generative Autonomous Multimodal Architect.
You are a practical, visionary technical mastermind helping creators move from an idea to a buildable plan.
You can help with full-stack software, mobile apps, media, games, electronics, Arduino/Raspberry Pi projects, CAD concepts, and PCB planning.
Be direct, warm, and specific. Do not claim to have created files, deployed code, rendered media, or completed actions unless the system has actually returned that artifact.
When a request needs implementation, produce an actionable plan with assumptions, key files or deliverables, and the first concrete step.
When a request is underspecified, ask one focused question, then still provide a useful starting direction.
Return plain text only, with concise headings and bullet lists when useful.`;

function modelForMode(mode: string) {
  const modeContext: Record<string, string> = {
    build: "Prioritize architecture, code structure, APIs, testing, and deployment.",
    media: "Prioritize story, shot design, visual direction, production workflow, and technical specifications.",
    hardware:
      "Prioritize components, interfaces, power, firmware, safety, CAD constraints, and manufacturing handoff.",
    games:
      "Prioritize the core loop, game feel, progression, player feedback, and implementation order.",
    strategy:
      "Prioritize scope, tradeoffs, milestones, risks, and the fastest path to a useful outcome.",
  };
  return modeContext[mode] ?? modeContext.build;
}

function providerErrorMessage(error: unknown) {
  const status =
    error && typeof error === "object" && "status" in error
      ? Number((error as { status?: unknown }).status)
      : undefined;

  if (status === 401 || status === 403) {
    return "Gemini rejected the configured key. Update GEMINI_API_KEY in Secrets and try again.";
  }
  if (status === 429) {
    return "Gemini has no available quota for this key. Use a funded Gemini key in Secrets and try again.";
  }
  return "GAMA could not complete that request through Gemini. Try again in a moment.";
}

type GeminiContent = {
  role: "user" | "model";
  parts: Array<{ text: string }>;
};

async function generateWithGemini(
  apiKey: string,
  contents: GeminiContent[],
  instruction: string,
  responseMimeType?: "application/json" | "text/plain",
) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: instruction }] },
        contents,
        generationConfig: {
          maxOutputTokens: 8192,
          ...(responseMimeType ? { responseMimeType } : {}),
        },
      }),
    },
  );

  const payload = (await response.json().catch(() => null)) as
    | {
        error?: { message?: string; status?: string };
        candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
      }
    | null;

  if (!response.ok) {
    const error = new Error(payload?.error?.message ?? "Gemini request failed.");
    Object.assign(error, { status: response.status, code: payload?.error?.status });
    throw error;
  }

  const text = payload?.candidates?.[0]?.content?.parts
    ?.map((part) => part.text ?? "")
    .join("")
    .trim();
  if (!text) {
    const error = new Error("Gemini returned an empty response.");
    Object.assign(error, { status: 502 });
    throw error;
  }
  return text;
}

function toGeminiContents(
  history: Array<{ role: "user" | "assistant"; content: string }>,
  currentMessage?: string,
) {
  const contents = history.map<GeminiContent>((item) => ({
    role: item.role === "assistant" ? "model" : "user",
    parts: [{ text: item.content }],
  }));
  if (currentMessage && contents.at(-1)?.role !== "user") {
    contents.push({ role: "user", parts: [{ text: currentMessage }] });
  }
  return contents;
}

function stripJsonFence(value: string) {
  return value
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();
}

router.get("/gama/overview", requireAuth, (_req, res) => {
  const data = GetGamaOverviewResponse.parse({
    projects: 12,
    activeRuns: 3,
    assets: 48,
    credits: 2400,
    recentActivity: [
      {
        title: "Orbit dashboard",
        detail: "Full-stack build · 82% complete",
        time: "12 min ago",
        status: "running",
      },
      {
        title: "PCB enclosure concept",
        detail: "Hardware · 3D export ready",
        time: "Yesterday",
        status: "complete",
      },
      {
        title: "Launch film storyboard",
        detail: "Media · awaiting direction",
        time: "2 days ago",
        status: "queued",
      },
    ],
  });
  res.json(data);
});

router.post("/gama/chat", requireAuth, async (req, res) => {
  const parsed = SendGamaMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please provide a message and a valid mode." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "GEMINI_API_KEY is not configured in Secrets." });
    return;
  }

  const { message, mode, history } = parsed.data;
  try {
    const responseText = await generateWithGemini(
      apiKey,
      toGeminiContents(history, message),
      `${systemPrompt}\n\nMode context: ${modelForMode(mode)}`,
      "text/plain",
    );
    const result = SendGamaMessageResponse.parse({
      message: responseText,
      mode,
      nextSteps: [
        "Turn this direction into a concrete build brief",
        "Create the first playable or runnable deliverable",
        "Define the constraints, inputs, and success criteria",
      ],
    });
    res.json(result);
  } catch (error) {
    req.log.error({ err: error }, "GAMA Gemini request failed");
    const status =
      error && typeof error === "object" && "status" in error
        ? Number((error as { status?: unknown }).status)
        : 500;
    res.status(status === 401 || status === 403 || status === 429 ? 503 : 500).json({
      error: providerErrorMessage(error),
    });
  }
});

router.post("/gama/build", requireAuth, async (req, res) => {
  const parsed = CreateGamaBuildBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please provide a valid mode and conversation history." });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({ error: "GEMINI_API_KEY is not configured in Secrets." });
    return;
  }

  const { mode, history } = parsed.data;
  const artifactInstruction =
    mode === "games"
      ? "Create a complete, polished single-file HTML5 game that runs immediately in a browser. Include inline CSS and JavaScript, a playable core loop, controls, scoring or progression, responsive layout, and no external assets or libraries."
      : mode === "media" || mode === "hardware" || mode === "strategy"
        ? "Create a detailed Markdown build brief with sections for goal, assumptions, deliverables, implementation steps, risks, and success criteria."
        : "Create a complete, self-contained HTML build that runs by opening the file in a browser. Use inline CSS and JavaScript, make it polished and interactive, and do not reference external assets or libraries.";

  try {
    const rawArtifact = await generateWithGemini(
      apiKey,
      toGeminiContents(history),
      `You are GAMA's online build engine. Turn the conversation into a concrete downloadable artifact.
${artifactInstruction}
Return only a JSON object with exactly these string fields:
title: a short human-readable title
filename: a safe filename with an extension
contentType: the correct MIME type
content: the complete artifact contents
Never put Markdown fences around content. Never claim an artifact was created outside this response.
Mode context: ${modelForMode(mode)}`,
      "application/json",
    );

    const artifact = CreateGamaBuildResponse.parse(JSON.parse(stripJsonFence(rawArtifact)));
    const safeFilename = artifact.filename.replace(/[^a-zA-Z0-9._-]/g, "-");
    res.json({ ...artifact, filename: safeFilename });
  } catch (error) {
    req.log.error({ err: error }, "GAMA Gemini build failed");
    const status =
      error && typeof error === "object" && "status" in error
        ? Number((error as { status?: unknown }).status)
        : 500;
    res.status(status === 401 || status === 403 || status === 429 ? 503 : 500).json({
      error: providerErrorMessage(error),
    });
  }
});

export default router;