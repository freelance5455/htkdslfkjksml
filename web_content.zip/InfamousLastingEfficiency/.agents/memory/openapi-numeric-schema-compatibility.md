---
name: OpenAPI numeric schema compatibility
description: A code-generation compatibility note for numeric OpenAPI fields in this workspace.
---

When adding numeric counters to OpenAPI responses, verify the generated Zod output against the workspace's installed Zod version. Integer schemas may generate helpers that are unavailable in the current Zod package, so prefer the compatible numeric representation when the API does not require integer-only validation.

**Why:** The first codegen pass generated `z.int()` for integer response fields while the workspace's Zod runtime only exposed the compatible numeric helper, causing the library typecheck to fail.

**How to apply:** After any OpenAPI schema change involving `integer`, run the API codegen command and the library typecheck before wiring the generated client into an app.