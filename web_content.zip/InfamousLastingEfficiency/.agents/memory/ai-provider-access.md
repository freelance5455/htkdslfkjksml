---
name: GAMA AI provider access
description: How this project should handle AI provider access when managed Replit AI setup is unavailable.
---

Use the workspace-managed provider secret for GAMA's server-side AI client when a managed Replit AI integration cannot be provisioned. Never put provider keys in frontend code or chat messages, and surface provider billing/auth failures as actionable API errors instead of silently substituting fake assistant responses.

**Why:** Managed AI setup can be blocked by account-plan requirements, while the project can still operate with a user-provided provider key stored through the secure Secrets flow. Provider model availability can also differ for new accounts; live provider errors are the source of truth over stale model lists.

**How to apply:** Keep AI calls server-side, restart the API workflow after secret changes, use a currently accepted model, and distinguish provider authentication/quota/model failures from generic application errors.