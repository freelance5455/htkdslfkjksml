# Cambios en android/app/src/main/AndroidManifest.xml

Dentro de la etiqueta `<activity ...>` de MainActivity añade/ajusta:

```xml
android:screenOrientation="sensorLandscape"
android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation"
android:exported="true"
```

Esto fuerza el modo horizontal (los dos sentidos) y evita que la app se reinicie al girar.
No hace falta pedir permisos: el juego no usa internet, cámara ni micrófono.
Vibración opcional (si quieres que vibre al disparar): `<uses-permission android:name="android.permission.VIBRATE" />`
