# Textos para la ficha de Google Play

## Nombre (máx. 30 caracteres)
Bear Arena 4v4

## Descripción breve (máx. 80 caracteres)
Shooter de osos 4 vs 4: modos, mapas, trajes y armas evolutivas. ¡Sin internet!

## Descripción completa
¡Entra a la arena y lidera a tu equipo de osos en combates 4 contra 4!

**12 osos únicos**, cada uno con su arma, estilo de caminar, de disparar y su personalidad.
**12 mapas con estrategia**: contenedores, piscina, aldea, planta industrial, pantano, nieve, lava y más. Usa los pads de salto y las escaleras para llegar a las azoteas.
**7 modos de juego**: Duelo por equipos, Contrarreloj, Rey de la colina, Todos contra todos, Capturar la bandera, Dominio y Un solo golpe.
**Armas con carácter**: francotirador con mira, ballesta, armas láser y eléctricas, lanzagranadas con trayectoria visible y granadas con onda expansiva.
**Armas evolutivas** que suben de nivel con tus eliminaciones y cambian de aspecto y de efectos.
**Tienda con más de 90 objetos**: trajes, alas, capas, auras, estelas y pelajes con movimiento y luces.
Rachas de eliminaciones, headshots, combos, power-ups y una pantalla final donde el ganador baila.
Controles táctiles personalizables. Sin conexión a internet.

## Categoría sugerida
Juegos > Acción

## Etiquetas sugeridas
shooter, acción, multijugador local con bots, osos, 3D
