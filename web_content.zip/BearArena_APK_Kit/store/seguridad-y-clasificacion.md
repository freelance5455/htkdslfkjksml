# Respuestas orientativas para la consola de Google Play
(Revisa cada pregunta con calma: tú eres responsable de que sean correctas.)

## Seguridad de los datos
- ¿La app recopila o comparte datos de usuario requeridos? **No**
- Todo se guarda en el dispositivo (ajustes, monedas, objetos).
- Sin anuncios, sin análisis, sin cuentas, sin servidor.

## Anuncios
- ¿Contiene anuncios? **No**

## Clasificación de contenido (cuestionario IARC)
- Violencia: combates de fantasía entre personajes de dibujos animados (osos) con armas, sangre estilizada y efectos de explosiones. Responde con honestidad que hay violencia de fantasía.
- Sin lenguaje soez, sin contenido sexual, sin apuestas reales, sin compras con dinero real.
- Interacción entre usuarios: **No** (es offline).
- Probable resultado: PEGI 12 / Teen. Confirma con el cuestionario.

## Público objetivo
- Elige 13+ (evita seleccionar edades infantiles, que activan requisitos extra de la política Familias).

## Compras dentro de la app
- El juego usa solo monedas ganadas jugando. Si más adelante vendes monedas con dinero real, tendrás que
  configurar Google Play Billing y actualizar esta información.
