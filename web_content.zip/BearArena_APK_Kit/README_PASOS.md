# Bear Arena 4v4: guía para generar el APK / AAB

## 0. Qué necesitas instalar (una sola vez)
- Node.js (versión LTS): https://nodejs.org
- Android Studio (incluye el SDK de Android): https://developer.android.com/studio

## 1. Prepara la carpeta
1. Descarga three.js r128 y guárdalo como `www/three.min.js`
   (enlace en `www/LEEME_three.txt`). Así el juego abre sin internet.
2. Abre una terminal dentro de esta carpeta (`BearArena_APK_Kit`).

## 2. Crea el proyecto Android
```bash
npm install @capacitor/core @capacitor/android @capacitor/app
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
npx capacitor-assets generate --android     # crea iconos y pantalla de inicio desde la carpeta assets/
npx cap sync android
```
Cambia el `appId` de `capacitor.config.json` por el tuyo (por ejemplo `com.tunombre.beararena`)
ANTES de ejecutar `npx cap add android`. Una vez publicada, el appId ya no se puede cambiar.

## 3. Ajustes de Android
- Copia `android-extra/MainActivity.java` sobre el MainActivity del proyecto
  (`android/app/src/main/java/.../MainActivity.java`) y deja la primera línea (`package ...`) con tu appId.
- Aplica lo que dice `android-extra/AndroidManifest-cambios.md` (modo horizontal).
- En `android/variables.gradle` pon `targetSdkVersion = 36` (Google Play exige actualmente Android 16 / API 36
  para apps nuevas; comprueba el requisito vigente en
  https://developer.android.com/google/play/requirements/target-sdk).
- Sube `versionCode` (entero) y `versionName` en `android/app/build.gradle` en cada actualización.

## 4. Probar en tu móvil
```bash
npx cap open android
```
En Android Studio conecta el móvil (depuración USB activada) y pulsa **Run**.
Comprueba: abre sin internet, horizontal, botón atrás pausa el juego, se guarda la tienda y las monedas.

## 5. Generar el archivo para Google Play
Android Studio > **Build > Generate Signed Bundle / APK > Android App Bundle (.aab)**.
Crea tu llave (keystore) y GUÁRDALA en un lugar seguro con su contraseña: sin ella no podrás actualizar la app.
Para probar en tu móvil sin la tienda también puedes generar un **APK**.

## 6. Publicar en Google Play
1. Crea la cuenta de desarrollador (pago único): https://play.google.com/console
2. Crea la app y rellena la ficha con los textos de la carpeta `store/`:
   - `descripcion.md` (textos), `icon-512.png`, `feature-graphic-1024x500.png`
   - Capturas de pantalla (mínimo 2) hechas desde tu móvil jugando.
3. Política de privacidad: sube `store/politica-privacidad.html` a una página web pública (por ejemplo GitHub Pages)
   y pega el enlace en la consola.
4. Seguridad de los datos y clasificación por edades: usa `store/seguridad-y-clasificacion.md`.
5. Sube el `.aab` en una prueba cerrada o interna primero. Las cuentas personales nuevas pueden tener
   requisitos de prueba con testers antes de producción; compruébalo en la consola.
6. Envía a revisión.

## Notas
- El juego es 100% offline: no recoge datos ni usa servidor. Todo se guarda en el dispositivo.
- Para actualizar: cambia `www/index.html`, sube `versionCode`, `npx cap sync android` y genera un nuevo .aab.
