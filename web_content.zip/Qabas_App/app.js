(() => {
  'use strict';

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const STORE = 'iqtibasi_state_v4';
  const tips = [
    ['لا تحتاج كل لحظة إلى قرار.', 'أحيانًا يكفي أن تتوقف قليلًا، تقرأ، ثم تكمل يومك بهدوء.'],
    ['اجعل يومك أخف.', 'اترك ما لا تستطيع تغييره، وركّز على الخطوة التي تستطيع فعلها الآن.'],
    ['الكلمة الطيبة أثر.', 'قد تنسى تفاصيل كثيرة، لكنك قد تتذكر كلمة طيبة قيلت لك في الوقت المناسب.'],
    ['ابدأ من مكانك.', 'لا تنتظر الظروف المثالية؛ ابدأ بما لديك وطوّر الطريق أثناء السير.'],
    ['الهدوء ليس فراغًا.', 'في بعض الأيام، يكون الهدوء هو المساحة التي تحتاجها لتسمع نفسك بوضوح.']
  ];

  let state = loadState();
  let randomQuote = null;
  let image = null;
  let frame = 'none';

  function loadState() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE) || '{}');
      return {
        favorites: Array.isArray(raw.favorites) ? raw.favorites : [],
        theme: raw.theme === 'light' || raw.theme === 'dark' ? raw.theme : null,
        tip: Number.isInteger(raw.tip) ? raw.tip : 0,
        avatar: typeof raw.avatar === 'string' ? raw.avatar : ''
      };
    } catch (_) {
      return {favorites: [], theme: null, tip: 0, avatar: ''};
    }
  }

  function saveState() {
    try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (_) {}
  }

  function icon(id) {
    return `<svg aria-hidden="true"><use href="#${id}"></use></svg>`;
  }

  function toast(message) {
    const t = $('#toast');
    t.textContent = message;
    t.classList.add('show');
    clearTimeout(window.__iqToast);
    window.__iqToast = setTimeout(() => t.classList.remove('show'), 1800);
  }

  async function copyText(text) {
    if (!text) return false;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.focus();
        area.select();
        document.execCommand('copy');
        area.remove();
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  function escapeHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function applyTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    document.body.classList.toggle('light-mode', next === 'light');
    state.theme = next;
    saveState();
    const btn = $('#theme');
    if (btn) {
      btn.setAttribute('aria-label', next === 'light' ? 'تفعيل الوضع الليلي' : 'تفعيل الوضع النهاري');
      btn.title = next === 'light' ? 'الوضع الليلي' : 'الوضع النهاري';
      const use = btn.querySelector('use');
      if (use) use.setAttribute('href', next === 'light' ? '#i-moon' : '#i-sun');
    }
    const meta = $('#themeColor');
    if (meta) meta.setAttribute('content', next === 'dark' ? '#0a0b10' : '#f3f5fa');
  }

  function toggleTheme() {
    state.theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    saveState();
    applyTheme(state.theme || 'dark');
    toast(state.theme === 'light' ? 'تم تفعيل الوضع النهاري ✓' : 'تم تفعيل الوضع الليلي ✓');
  }

  function closeMenu() { document.body.classList.remove('menuOpen'); }

  function nav(page) {
    $$('.page').forEach(p => p.classList.toggle('active', p.id === page));
    $$('.nav').forEach(n => n.classList.toggle('active', n.dataset.page === page));
    closeMenu();
    window.scrollTo({top: 0, behavior: 'smooth'});
    if (page === 'library') renderLibrary();
    if (page === 'favorites') renderFavorites();
    if (page === 'random') renderRandom();
    if (page === 'designer') setTimeout(draw, 0);
  }

  $$('.nav').forEach(btn => btn.addEventListener('click', () => nav(btn.dataset.page)));
  $('#menu').addEventListener('click', () => document.body.classList.toggle('menuOpen'));
  $('#closeMenu').addEventListener('click', closeMenu);
  $('#overlay').addEventListener('click', closeMenu);
  $('#theme').addEventListener('click', toggleTheme);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });

  function isFavorite(q) { return state.favorites.includes(q.id); }

  function toggleFavorite(q) {
    if (isFavorite(q)) {
      state.favorites = state.favorites.filter(id => id !== q.id);
      toast('أزيلت من المفضلة');
    } else {
      state.favorites = [...state.favorites, q.id];
      toast('أضيفت إلى المفضلة ✓');
    }
    saveState();
    updateCounts();
    renderFavorites();
    renderLibrary();
    if (randomQuote) renderRandom();
  }

  function shareQuote(q) {
    if (!q) return;
    if (navigator.share) {
      navigator.share({title: 'اقتباسي', text: q.text}).catch(() => {});
    } else {
      copyText(q.text).then(ok => toast(ok ? 'تم نسخ العبارة ✓' : 'تعذر النسخ'));
    }
  }

  function makeCard(q) {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div class="meta"><span class="category">${escapeHTML(q.category)}</span></div>
      <div class="qtext">${escapeHTML(q.text)}</div>
      <div class="card-actions">
        <button class="copy" aria-label="نسخ">${icon('i-copy')}</button>
        <button class="fav ${isFavorite(q) ? 'saved' : ''}" aria-label="${isFavorite(q) ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}">${icon('i-heart')}</button>
        <button class="share" aria-label="مشاركة">${icon('i-share')}</button>
      </div>`;
    $('.copy', card).addEventListener('click', () => copyText(q.text).then(ok => toast(ok ? 'تم النسخ ✓' : 'تعذر النسخ')));
    $('.fav', card).addEventListener('click', () => toggleFavorite(q));
    $('.share', card).addEventListener('click', () => shareQuote(q));
    return card;
  }

  function renderInto(selector, list) {
    const grid = $(selector);
    grid.innerHTML = '';
    if (!list.length) {
      grid.innerHTML = `<div class="empty">لا توجد عبارات هنا بعد.<br><small>ابدأ بحفظ العبارات التي تعجبك من المكتبة.</small></div>`;
      return;
    }
    const fragment = document.createDocumentFragment();
    list.slice(0, 120).forEach(q => fragment.appendChild(makeCard(q)));
    grid.appendChild(fragment);
  }

  function updateCounts() {
    $('#favCount').textContent = state.favorites.length;
    $('#homeFavCount').textContent = state.favorites.length;
  }

  const categories = [...new Set(QUOTES.map(q => q.category))];
  categories.forEach(category => {
    const option = document.createElement('option');
    option.value = category;
    option.textContent = category;
    $('#filter').appendChild(option);
  });

  function renderCategoryChips() {
    const wrap = $('#libraryCategories');
    const selected = $('#filter').value;
    wrap.innerHTML = '';
    const all = ['all', ...categories];
    all.forEach(category => {
      const b = document.createElement('button');
      b.className = `category-chip ${selected === category ? 'active' : ''}`;
      b.textContent = category === 'all' ? 'الكل' : category;
      b.addEventListener('click', () => {
        $('#filter').value = category;
        renderLibrary();
      });
      wrap.appendChild(b);
    });
  }

  function renderLibrary() {
    const term = $('#search').value.trim().toLowerCase();
    const category = $('#filter').value;
    const result = QUOTES.filter(q => {
      const matchCategory = category === 'all' || q.category === category;
      const matchText = !term || q.text.toLowerCase().includes(term) || q.category.toLowerCase().includes(term);
      return matchCategory && matchText;
    });
    $('#resultCount').textContent = `${result.length.toLocaleString('ar-EG')} نتيجة`;
    renderCategoryChips();
    renderInto('#libraryGrid', result);
  }

  function renderFavorites() {
    const result = QUOTES.filter(q => isFavorite(q));
    renderInto('#favGrid', result);
  }

  $('#search').addEventListener('input', renderLibrary);
  $('#filter').addEventListener('change', renderLibrary);

  function chooseDaily() {
    const dayIndex = Math.floor(new Date().setHours(0,0,0,0) / 86400000);
    return QUOTES[((dayIndex % QUOTES.length) + QUOTES.length) % QUOTES.length];
  }

  const dailyQuote = chooseDaily();
  $('#daily').textContent = dailyQuote.text;
  $('#dailyCategory').textContent = dailyQuote.category;
  $('#copyDaily').addEventListener('click', () => copyText(dailyQuote.text).then(ok => toast(ok ? 'تم نسخ اقتباس اليوم ✓' : 'تعذر النسخ')));
  $('#homeRandom').addEventListener('click', () => nav('random'));
  $('#homeDaily').addEventListener('click', () => {
    copyText(dailyQuote.text).then(ok => toast(ok ? 'اقتـباس اليوم جاهز للنسخ ✓' : 'هذا اقتباس اليوم'));
  });

  function showTip() {
    const item = tips[state.tip % tips.length];
    $('#tipTitle').textContent = item[0];
    $('#tipText').textContent = item[1];
  }
  $('#nextTip').addEventListener('click', () => { state.tip = (state.tip + 1) % tips.length; saveState(); showTip(); });

  function pickRandom() {
    if (QUOTES.length < 2) return QUOTES[0];
    let q;
    do { q = QUOTES[Math.floor(Math.random() * QUOTES.length)]; } while (randomQuote && q.id === randomQuote.id);
    return q;
  }

  function renderRandom() {
    randomQuote = randomQuote || pickRandom();
    $('#randomCard').innerHTML = `
      <div class="meta"><span class="category">${escapeHTML(randomQuote.category)}</span></div>
      <div class="qtext">${escapeHTML(randomQuote.text)}</div>`;
    $('#favRandom').innerHTML = `${icon('i-heart')}${isFavorite(randomQuote) ? 'محفوظة' : 'حفظ'}`;
    $('#favRandom').classList.toggle('saved', isFavorite(randomQuote));
  }

  $('#newRandom').addEventListener('click', () => { randomQuote = pickRandom(); renderRandom(); });
  $('#copyRandom').addEventListener('click', () => copyText(randomQuote.text).then(ok => toast(ok ? 'تم النسخ ✓' : 'تعذر النسخ')));
  $('#shareRandom').addEventListener('click', () => shareQuote(randomQuote));
  $('#favRandom').addEventListener('click', () => toggleFavorite(randomQuote));


  // Developer avatar can be replaced locally and remains on this device.
  const avatar = $('#developerAvatar');
  if (state.avatar) avatar.src = state.avatar;
  $('#changeAvatar').addEventListener('click', () => $('#avatarInput').click());
  $('#avatarInput').addEventListener('change', e => {
    const file=e.target.files?.[0]; if(!file) return;
    const reader=new FileReader();reader.onload=()=>{state.avatar=reader.result;avatar.src=state.avatar;saveState();toast('تم تحديث صورة المطور ✓')};reader.readAsDataURL(file);
  });

  $$('.contacts button').forEach(btn => btn.addEventListener('click', async () => {
    const ok=await copyText(btn.dataset.copy);toast(ok ? 'تم نسخ بيانات التواصل ✓' : 'تعذر النسخ');
  }));

  // Initialize.
  applyTheme(state.theme || 'dark');
  showTip();
  updateCounts();
  renderLibrary();
  renderFavorites();
  renderRandom();
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
})();
