GERADOR DE SENSI - PROJETO ANDROID

1. Abra esta pasta no Android Studio.
2. Espere o Gradle terminar a sincronização.
3. Vá em Build > Generate App Bundles or APKs > Generate APKs.
4. O Android Studio criará o APK em:
   app/build/outputs/apk/debug/app-debug.apk

O app usa o HTML local dentro de assets.
A DPI informada pelo usuário participa do cálculo da sensibilidade.
O app não altera a DPI do aparelho e não automatiza o Free Fire.
