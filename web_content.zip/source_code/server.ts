import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

const PUBLIC_DIR = path.resolve(__dirname, 'public');

// Service Worker route with standard Service-Worker-Allowed header
app.get('/sw.js', (_req: Request, res: Response) => {
  const swPath = path.resolve(PUBLIC_DIR, 'sw.js');
  if (fs.existsSync(swPath)) {
    res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
    res.setHeader('Service-Worker-Allowed', '/');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    return res.sendFile(swPath);
  }
  return res.status(404).send('Service worker not found');
});

// Web App Manifests routes with application/manifest+json MIME type
app.get(['/manifest.json', '/manifest.webmanifest'], (_req: Request, res: Response) => {
  const manifestPath = path.resolve(PUBLIC_DIR, 'manifest.webmanifest');
  if (fs.existsSync(manifestPath)) {
    res.setHeader('Content-Type', 'application/manifest+json; charset=utf-8');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    return res.sendFile(manifestPath);
  }
  return res.status(404).send('Manifest not found');
});

app.use(express.static(PUBLIC_DIR));

// Direct download endpoint for the complete Android APK / PWA bundle
app.get(['/download/app', '/download/apk-bundle', '/download/zip'], (_req: Request, res: Response) => {
  const zipPath = path.resolve(PUBLIC_DIR, 'nexa-android-apk-bundle.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Disposition', 'attachment; filename="nexa-android-apk-bundle.zip"');
    res.setHeader('Content-Type', 'application/zip');
    return res.sendFile(zipPath);
  }
  const fallbackZip = path.resolve(PUBLIC_DIR, 'nexa-student-safety-network.zip');
  if (fs.existsSync(fallbackZip)) {
    res.setHeader('Content-Disposition', 'attachment; filename="nexa-student-safety-network.zip"');
    res.setHeader('Content-Type', 'application/zip');
    return res.sendFile(fallbackZip);
  }
  return res.status(404).send('Paquete de la aplicación en preparación');
});

// Ensure data directory exists for server-side persistence across devices
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.resolve(DATA_DIR, 'nexa_db.json');

if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.warn('Could not create data directory:', err);
  }
}

interface StoredMessage {
  id: string;
  senderPhone: string;
  senderName: string;
  receiverPhone: string;
  content: string;
  timestamp: string;
  isSosAlert: boolean;
  sosDetails?: any;
  read: boolean;
}

interface StoredUserAccount {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  password?: string;
  isStudent?: boolean;
  roleCategory?: string;
  institution: string;
  gradeOrRole: string;
  isMinor?: boolean;
  guardianName?: string;
  guardianPhone?: string;
  guardianConsentAccepted?: boolean;
  privacyPolicyAccepted?: boolean;
  createdAt: string;
  contacts?: any[];
  customRoutes?: any[];
  sosConfig?: any;
  settings?: any;
}

export interface StoredCall {
  id: string;
  callerPhone: string;
  callerName: string;
  recipientPhone: string;
  recipientName: string;
  status: 'calling' | 'ringing' | 'connected' | 'ended' | 'rejected';
  isSosEmergency?: boolean;
  startedAt: string;
  connectedAt?: string;
  endedAt?: string;
  signals?: Array<{ from: string; data: any; timestamp: string }>;
}

interface DatabaseSchema {
  accounts: Record<string, StoredUserAccount>; // keyed by normalized phone or email
  messages: StoredMessage[];
}

function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      return {
        accounts: parsed.accounts || {},
        messages: parsed.messages || [],
      };
    }
  } catch (err) {
    console.error('Error loading DB file, fallback to defaults:', err);
  }
  return {
    accounts: {},
    messages: [
      {
        id: 'msg_welcome_1',
        senderPhone: '0987654322',
        senderName: 'Alex (Amigo NEXA)',
        receiverPhone: '0991234567',
        content:
          '¡Hola! Ya tengo instalada la app NEXA en mi teléfono. Si me agregas con mi número en tus contactos, cuando actives una alerta SOS recibiré tu ubicación aquí en tiempo real.',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        isSosAlert: false,
        read: true,
      },
    ],
  };
}

let db: DatabaseSchema = loadDatabase();

// In-memory call management store
const activeCalls: Map<string, StoredCall> = new Map();

function saveDatabase(): void {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving DB file:', err);
  }
}

const normalize = (phone?: string) => (phone || '').replace(/\D/g, '');

const isSamePhone = (p1?: string, p2?: string): boolean => {
  const n1 = normalize(p1);
  const n2 = normalize(p2);
  if (!n1 || !n2) return false;
  if (n1 === n2) return true;
  const s1 = n1.replace(/^593/, '').replace(/^0+/, '');
  const s2 = n2.replace(/^593/, '').replace(/^0+/, '');
  if (s1 && s2 && s1 === s2) return true;
  if (s1.length >= 6 && s2.length >= 6 && (s1.endsWith(s2) || s2.endsWith(s1))) return true;
  return false;
};

// ================= AUTH & USER MULTI-DEVICE PERSISTENCE =================

// Register / Create Account
app.post('/api/auth/register', (req: Request, res: Response) => {
  const { user, password, contacts, customRoutes, sosConfig, settings } = req.body;

  if (!user || (!user.phone && !user.email)) {
    return res.status(400).json({ error: 'Se requiere teléfono o correo para registrar la cuenta' });
  }

  const normPhone = normalize(user.phone);
  const normEmail = (user.email || '').trim().toLowerCase();
  const primaryKey = normPhone || normEmail;

  const newAccount: StoredUserAccount = {
    id: user.id || `usr_${Date.now()}`,
    fullName: user.fullName || 'Usuario NEXA',
    email: normEmail,
    phone: user.phone || '',
    password: password || '',
    isStudent: user.isStudent !== false,
    roleCategory: user.roleCategory || (user.isStudent !== false ? 'estudiante' : 'familiar'),
    institution: user.institution || 'Colegio / Universidad',
    gradeOrRole: user.gradeOrRole || 'Estudiante',
    isMinor: Boolean(user.isMinor),
    guardianName: user.guardianName || '',
    guardianPhone: user.guardianPhone || '',
    guardianConsentAccepted: Boolean(user.guardianConsentAccepted),
    privacyPolicyAccepted: true,
    createdAt: user.createdAt || new Date().toISOString(),
    contacts: contacts || [],
    customRoutes: customRoutes || [],
    sosConfig: sosConfig || null,
    settings: settings || null,
  };

  db.accounts[primaryKey] = newAccount;
  if (normEmail && normEmail !== primaryKey) {
    db.accounts[normEmail] = newAccount;
  }
  saveDatabase();

  return res.json({
    success: true,
    message: 'Cuenta guardada en la nube NEXA con éxito.',
    user: newAccount,
  });
});

// Login from any device (phone or email + password)
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { identifier, password } = req.body;

  if (!identifier) {
    return res.status(400).json({ error: 'Ingresa tu número de teléfono o correo electrónico registrado' });
  }

  const cleanIdent = identifier.trim().toLowerCase();
  const normPhone = normalize(cleanIdent);

  // Search by phone, email, or partial match
  let account: StoredUserAccount | undefined =
    db.accounts[normPhone] ||
    db.accounts[cleanIdent] ||
    Object.values(db.accounts).find((acc) => {
      const aPhone = normalize(acc.phone);
      const aEmail = (acc.email || '').toLowerCase();
      return (
        (normPhone.length > 5 && (aPhone.endsWith(normPhone) || normPhone.endsWith(aPhone))) ||
        (cleanIdent.includes('@') && aEmail === cleanIdent)
      );
    });

  if (!account) {
    // If user is logging in with a new number or demo, create a ready account so they are never blocked
    const newId = `usr_${Date.now()}`;
    account = {
      id: newId,
      fullName: cleanIdent.includes('@') ? cleanIdent.split('@')[0] : 'Estudiante NEXA',
      email: cleanIdent.includes('@') ? cleanIdent : `${normPhone || 'usuario'}@nexa.edu.ec`,
      phone: normPhone || identifier,
      password: password || '',
      institution: 'Institución Educativa',
      gradeOrRole: 'Estudiante',
      isMinor: false,
      guardianConsentAccepted: true,
      privacyPolicyAccepted: true,
      createdAt: new Date().toISOString(),
      contacts: [],
      customRoutes: [],
    };
    db.accounts[normPhone || cleanIdent] = account;
    saveDatabase();
  }

  // Password check: if account has a password, verify it
  if (account.password && password && account.password !== password) {
    return res.status(401).json({ error: 'Contraseña incorrecta para esta cuenta.' });
  }

  return res.json({
    success: true,
    message: 'Sesión iniciada correctamente. Datos de la cuenta sincronizados.',
    user: account,
    contacts: account.contacts || [],
    customRoutes: account.customRoutes || [],
    sosConfig: account.sosConfig || null,
    settings: account.settings || null,
  });
});

// Sync data (contacts, routes, settings) to cloud account
app.post('/api/auth/sync', (req: Request, res: Response) => {
  const { phone, email, user, contacts, customRoutes, sosConfig, settings } = req.body;
  const key = normalize(phone) || (email || '').trim().toLowerCase();

  if (!key) {
    return res.status(400).json({ error: 'Falta identificador de cuenta' });
  }

  let acc = db.accounts[key];
  if (!acc && user) {
    acc = { ...user };
  }

  if (acc) {
    if (user) Object.assign(acc, user);
    if (contacts) acc.contacts = contacts;
    if (customRoutes) acc.customRoutes = customRoutes;
    if (sosConfig) acc.sosConfig = sosConfig;
    if (settings) acc.settings = settings;

    db.accounts[key] = acc;
    saveDatabase();
  }

  return res.json({ success: true, timestamp: new Date().toISOString() });
});

// ================= REAL-TIME CHAT & SOS ALERTS =================

// API: Get messages for a phone number
app.get('/api/chat/messages', (req: Request, res: Response) => {
  const phone = req.query.phone as string;
  if (!phone) {
    return res.json({ success: true, messages: db.messages });
  }

  const norm = normalize(phone);
  const relevant = db.messages.filter((m) => {
    const s = normalize(m.senderPhone);
    const r = normalize(m.receiverPhone);
    return (
      s === norm ||
      r === norm ||
      (norm.length > 5 && (s.endsWith(norm) || norm.endsWith(s) || r.endsWith(norm) || norm.endsWith(r)))
    );
  });

  return res.json({ success: true, messages: relevant });
});

// API: Send a new message or SOS alert (PRESERVES CLIENT ID TO PREVENT DUPLICATES)
app.post('/api/chat/send', (req: Request, res: Response) => {
  const { id, senderPhone, senderName, receiverPhone, content, isSosAlert, sosDetails } = req.body;

  if (!content || !receiverPhone) {
    return res.status(400).json({ error: 'Faltan parámetros requeridos' });
  }

  const msgId = id || `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  // Deduplicate: check if message with this id or exact content/timestamp already exists
  const existingIdx = db.messages.findIndex((m) => m.id === msgId);
  if (existingIdx !== -1) {
    return res.json({ success: true, message: db.messages[existingIdx] });
  }

  const newMsg: StoredMessage = {
    id: msgId,
    senderPhone: senderPhone || '0991234567',
    senderName: senderName || 'Usuario',
    receiverPhone: receiverPhone,
    content: String(content),
    timestamp: req.body.timestamp || new Date().toISOString(),
    isSosAlert: Boolean(isSosAlert),
    sosDetails: sosDetails || null,
    read: false,
  };

  db.messages.push(newMsg);

  // Keep store bounded
  if (db.messages.length > 600) {
    db.messages.splice(0, db.messages.length - 600);
  }

  saveDatabase();

  return res.json({ success: true, message: newMsg });
});

// API: Broadcast SOS to multiple friends at once
app.post('/api/alerts/broadcast', (req: Request, res: Response) => {
  const { senderPhone, senderName, recipientPhones, message, location, battery, alertId } = req.body;

  if (!Array.isArray(recipientPhones) || recipientPhones.length === 0) {
    return res.status(400).json({ error: 'Se requiere lista de teléfonos destinatarios' });
  }

  const createdMessages: StoredMessage[] = [];
  const mapsUrl = location ? `https://maps.google.com/?q=${location.lat},${location.lng}` : undefined;

  for (const phone of recipientPhones) {
    const msgId = alertId
      ? `sos_${alertId}_${normalize(phone)}`
      : `sos_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    // Check if duplicate
    if (db.messages.some((m) => m.id === msgId)) continue;

    const newMsg: StoredMessage = {
      id: msgId,
      senderPhone: senderPhone || '0991234567',
      senderName: senderName || 'Usuario',
      receiverPhone: phone,
      content:
        message ||
        `🚨 ¡ALERTA SOS ACTIVADA! Necesito ayuda urgente en mi ubicación: ${mapsUrl || 'Sin GPS'}`,
      timestamp: new Date().toISOString(),
      isSosAlert: true,
      sosDetails: {
        location: location || null,
        battery: battery || 85,
        mapsUrl,
        activationSource: 'sos_broadcast',
      },
      read: false,
    };

    db.messages.push(newMsg);
    createdMessages.push(newMsg);
  }

  saveDatabase();

  return res.json({ success: true, count: createdMessages.length, messages: createdMessages });
});

// API: Mark messages as read
app.post('/api/chat/mark-read', (req: Request, res: Response) => {
  const { userPhone, contactPhone } = req.body;
  const uNorm = normalize(userPhone);
  const cNorm = normalize(contactPhone);

  db.messages.forEach((m) => {
    const sNorm = normalize(m.senderPhone);
    const rNorm = normalize(m.receiverPhone);
    if (sNorm === cNorm && (rNorm === uNorm || rNorm.endsWith(uNorm) || uNorm.endsWith(rNorm))) {
      m.read = true;
    }
  });

  saveDatabase();

  return res.json({ success: true });
});

// API: Delete individual message (Instagram style unsend)
app.delete('/api/chat/message/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const initialLen = db.messages.length;
  db.messages = db.messages.filter((m) => m.id !== id);
  if (db.messages.length !== initialLen) {
    saveDatabase();
    return res.json({ success: true, messageId: id });
  }
  return res.json({ success: false, error: 'Mensaje no encontrado' });
});

// API: Clear entire conversation between two contacts (Instagram style delete chat)
app.post('/api/chat/clear-conversation', (req: Request, res: Response) => {
  const { userPhone, contactPhone } = req.body;
  const uNorm = normalize(userPhone);
  const cNorm = normalize(contactPhone);

  const initialLen = db.messages.length;
  db.messages = db.messages.filter((m) => {
    const sNorm = normalize(m.senderPhone);
    const rNorm = normalize(m.receiverPhone);
    const isConv =
      (sNorm === uNorm && rNorm === cNorm) ||
      (sNorm === cNorm && rNorm === uNorm) ||
      (sNorm.endsWith(cNorm) && rNorm.endsWith(uNorm)) ||
      (sNorm.endsWith(uNorm) && rNorm.endsWith(cNorm));
    return !isConv;
  });

  saveDatabase();

  return res.json({ success: true, countDeleted: initialLen - db.messages.length });
});

// ================= REAL-TIME IN-APP CALLS (PHONE <-> LAPTOP / MULTI-DEVICE) =================

// API: Initiate outgoing in-app call
app.post('/api/calls/initiate', (req: Request, res: Response) => {
  const { id, callerPhone, callerName, recipientPhone, recipientName, isSosEmergency } = req.body;

  if (!callerPhone || !recipientPhone) {
    return res.status(400).json({ error: 'Faltan números de origen y destino de la llamada' });
  }

  // End any previous ringing calls involving these phones
  for (const [cId, existingCall] of activeCalls.entries()) {
    if (
      (isSamePhone(existingCall.callerPhone, callerPhone) ||
        isSamePhone(existingCall.recipientPhone, recipientPhone) ||
        isSamePhone(existingCall.recipientPhone, callerPhone)) &&
      (existingCall.status === 'ringing' || existingCall.status === 'calling')
    ) {
      existingCall.status = 'ended';
      existingCall.endedAt = new Date().toISOString();
    }
  }

  const callId = id || `call_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  const callRecord: StoredCall = {
    id: callId,
    callerPhone,
    callerName: callerName || 'Usuario NEXA',
    recipientPhone,
    recipientName: recipientName || 'Contacto',
    status: 'ringing',
    isSosEmergency: Boolean(isSosEmergency),
    startedAt: new Date().toISOString(),
    signals: [],
  };

  activeCalls.set(callId, callRecord);

  return res.json({ success: true, call: callRecord });
});

// API: Check active call status for a phone (caller or recipient polling)
app.get('/api/calls/status', (req: Request, res: Response) => {
  const phone = req.query.phone as string;
  const callId = req.query.callId as string;

  const now = Date.now();

  // Housekeeping: expire calls ringing > 45 seconds without answer
  for (const [cId, c] of activeCalls.entries()) {
    const age = now - new Date(c.startedAt).getTime();
    if (c.status === 'ringing' && age > 45000) {
      c.status = 'ended';
      c.endedAt = new Date().toISOString();
    }
    // Clean up ended calls older than 5 minutes
    if ((c.status === 'ended' || c.status === 'rejected') && age > 300000) {
      activeCalls.delete(cId);
    }
  }

  if (callId) {
    const call = activeCalls.get(callId);
    return res.json({ success: true, call: call || null });
  }

  if (phone) {
    // Find active ringing or connected call for this phone
    for (const c of activeCalls.values()) {
      if (
        (isSamePhone(c.recipientPhone, phone) || isSamePhone(c.callerPhone, phone)) &&
        (c.status === 'ringing' || c.status === 'connected')
      ) {
        return res.json({ success: true, call: c });
      }
    }
  }

  return res.json({ success: true, call: null });
});

// API: Answer incoming call
app.post('/api/calls/answer', (req: Request, res: Response) => {
  const { callId } = req.body;
  if (!callId) return res.status(400).json({ error: 'Falta callId' });

  const call = activeCalls.get(callId);
  if (!call) return res.status(404).json({ error: 'Llamada no encontrada o expirada' });

  call.status = 'connected';
  call.connectedAt = new Date().toISOString();

  return res.json({ success: true, call });
});

// API: End call
app.post('/api/calls/end', (req: Request, res: Response) => {
  const { callId, reason } = req.body;
  if (!callId) return res.status(400).json({ error: 'Falta callId' });

  const call = activeCalls.get(callId);
  if (call) {
    call.status = 'ended';
    call.endedAt = new Date().toISOString();
  }

  return res.json({ success: true, message: 'Llamada finalizada' });
});

// API: Reject incoming call
app.post('/api/calls/reject', (req: Request, res: Response) => {
  const { callId } = req.body;
  if (!callId) return res.status(400).json({ error: 'Falta callId' });

  const call = activeCalls.get(callId);
  if (call) {
    call.status = 'rejected';
    call.endedAt = new Date().toISOString();
  }

  return res.json({ success: true, message: 'Llamada rechazada' });
});

// API: WebRTC signal relay (offer, answer, ice candidates)
app.post('/api/calls/signal', (req: Request, res: Response) => {
  const { callId, fromPhone, data } = req.body;
  if (!callId || !data) return res.status(400).json({ error: 'Faltan parámetros' });

  const call = activeCalls.get(callId);
  if (!call) return res.status(404).json({ error: 'Llamada no encontrada' });

  if (!call.signals) call.signals = [];
  call.signals.push({
    from: fromPhone || '',
    data,
    timestamp: new Date().toISOString(),
  });

  // Keep signals bounded
  if (call.signals.length > 50) call.signals.splice(0, call.signals.length - 50);

  return res.json({ success: true });
});

// API: Get pending signals
app.get('/api/calls/signals', (req: Request, res: Response) => {
  const callId = req.query.callId as string;
  const fromOtherThan = req.query.myPhone as string;
  const since = req.query.since as string;

  if (!callId) return res.status(400).json({ error: 'Falta callId' });

  const call = activeCalls.get(callId);
  if (!call || !call.signals) return res.json({ success: true, signals: [] });

  let signals = call.signals;
  if (fromOtherThan) {
    signals = signals.filter((s) => !isSamePhone(s.from, fromOtherThan));
  }
  if (since) {
    const sinceTime = new Date(since).getTime();
    signals = signals.filter((s) => new Date(s.timestamp).getTime() > sinceTime);
  }

  return res.json({ success: true, signals });
});

async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    // Mount Vite dev middlewares
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve production build
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`NEXA server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
