export type SafetyState = 'SAFE' | 'ROUTE' | 'CHECK' | 'ALERT' | 'EMERGENCY';

export type ContactRelationship = 'familiar' | 'tutor' | 'amigo' | 'otro';

export type NotificationChannel = 'sms' | 'email' | 'push' | 'call' | 'share_link';

export type DeliveryStatus = 'pendiente' | 'enviado' | 'entregado' | 'requiere_accion' | 'fallido';

export interface EmergencyContact {
  id: string;
  firstName: string;
  lastName: string;
  countryCode: string;
  phone: string;
  email?: string;
  relationship: ContactRelationship;
  priority: number;
  channels: NotificationChannel[];
  authorized: boolean;
  receiveSos: boolean;
  locationConsent: boolean;
  updatedAt: string;
}

export interface SosMessageConfig {
  template: string;
  includeUserName: boolean;
  includeLocationLink: boolean;
  includeCoordinates: boolean;
  includeTimestamp: boolean;
  includeActivationType: boolean;
  includeBatteryLevel: boolean;
  includeConnectionStatus: boolean;
  holdDurationMs: number;
}

export interface GeoLocationData {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: string;
  permissionStatus: 'granted' | 'prompt' | 'denied' | 'unsupported';
  isLive: boolean;
  errorMessage?: string;
}

export interface ContactDeliveryAttempt {
  id: string;
  contactId: string;
  contactName: string;
  phone: string;
  email?: string;
  priority: number;
  channel: NotificationChannel;
  status: DeliveryStatus;
  timestamp: string;
  detail: string;
}

export type ActivationSource =
  | 'app_manual'
  | 'nexa_core_ble_long'
  | 'nexa_core_ble_short'
  | 'saferoute_escalation'
  | 'test_simulation';

export interface ActiveEmergencySession {
  id: string;
  startedAt: string;
  updatedAt: string;
  resolvedAt?: string;
  source: ActivationSource;
  isTest: boolean;
  status: 'active' | 'cancelled' | 'resolved';
  cancelReason?: string;
  messageSent: string;
  locationSnapshot: GeoLocationData | null;
  deviceBattery: number | null;
  isOnline: boolean;
  attempts: ContactDeliveryAttempt[];
}

export interface SafeRoutePreset {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  estimatedMinutes: number;
}

export interface SafeRouteSession {
  id: string;
  mode: 'saferoute' | 'accompany';
  destinationName: string;
  destinationAddress: string;
  destinationLat: number;
  destinationLng: number;
  originLat: number;
  originLng: number;
  startedAt: string;
  estimatedArrivalAt: string;
  sharedContactIds: string[];
  escalationLevel: 0 | 1 | 2 | 3;
  lastCheckAt: string;
  nextCheckCountdownSec: number;
  deviationMeters: number;
  toleranceMeters: number;
  checkIntervalMinutes: number;
  status: 'active' | 'arrived' | 'cancelled' | 'escalated';
}

export type WearableFormat = 'clip' | 'loop' | 'pin' | 'nova';

export interface PendingBleEvent {
  id: string;
  type: 'short_press' | 'long_press_sos' | 'battery_low' | 'imu_motion' | 'sync_heartbeat';
  timestamp: string;
  battery: number;
  synced: boolean;
  isSimulated: boolean;
}

export interface NexaDeviceState {
  connectionStatus: 'disconnected' | 'scanning' | 'connected_real_ble' | 'connected_demo';
  isDemoMode: boolean;
  deviceId: string | null;
  deviceName: string;
  selectedFormat: WearableFormat;
  batteryLevel: number | null;
  isCharging: boolean;
  lastSyncAt: string | null;
  firmwareVersion: string;
  rssi: number | null;
  connectionError: string | null;
  pendingEvents: PendingBleEvent[];
  lastButtonEvent: {
    type: 'short' | 'long';
    timestamp: string;
    isDemo: boolean;
  } | null;
}

export type ActivityEventType =
  | 'sos_activated'
  | 'sos_cancelled'
  | 'sos_resolved'
  | 'route_started'
  | 'route_arrived'
  | 'route_deviation_l1'
  | 'route_deviation_l2'
  | 'route_deviation_l3'
  | 'ble_connected'
  | 'ble_disconnected'
  | 'ble_short_press'
  | 'ble_long_press'
  | 'ble_sync_completed'
  | 'connection_error'
  | 'location_shared'
  | 'call_completed';

export interface ActivityLogItem {
  id: string;
  type: ActivityEventType;
  title: string;
  description: string;
  timestamp: string;
  severity: 'info' | 'safe' | 'warning' | 'orange' | 'critical';
  isSimulated?: boolean;
  location?: { lat: number; lng: number; accuracy?: number } | null;
  contactsNotified?: { name: string; channel: string; status: DeliveryStatus }[];
  activationSource?: string;
}

export interface UserAccount {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  password?: string;
  isStudent?: boolean;
  roleCategory?: 'estudiante' | 'familiar' | 'tutor' | 'amigo' | 'contacto_apoyo';
  institution: string;
  gradeOrRole: string;
  isMinor: boolean;
  guardianName?: string;
  guardianPhone?: string;
  guardianConsentAccepted: boolean;
  privacyPolicyAccepted: boolean;
  createdAt: string;
}

export interface ActiveCallSession {
  callId: string;
  callerPhone: string;
  callerName: string;
  recipientPhone: string;
  recipientName: string;
  status: 'calling' | 'ringing' | 'connected' | 'ended' | 'rejected';
  startedAt: string;
  connectedAt?: string;
  endedAt?: string;
  isSosEmergency?: boolean;
}

export interface AppSettings {
  darkMode: boolean;
  silentMode: boolean;
  safeRouteToleranceMeters: number;
  safeRouteLevel1WaitSec: number;
  safeRouteLevel2WaitSec: number;
  autoShareLocationOnSos: boolean;
  offlineQueueEnabled: boolean;
  dataRetentionDays: number;
  preferredChannels: NotificationChannel[];
}

export interface ChatMessage {
  id: string;
  senderPhone: string;
  senderName: string;
  receiverPhone: string;
  content: string;
  timestamp: string;
  isSosAlert: boolean;
  sosDetails?: {
    location?: { lat: number; lng: number; accuracy?: number };
    battery?: number;
    mapsUrl?: string;
    activationSource?: string;
  };
  read: boolean;
}

export interface UserCustomRoute {
  id: string;
  name: string;
  originName: string;
  originLat?: number;
  originLng?: number;
  destinationName: string;
  destinationAddress: string;
  destinationLat: number;
  destinationLng: number;
  estimatedMinutes: number;
  toleranceMeters: number;
  sharedContactIds: string[];
  notes?: string;
  isFavorite?: boolean;
}

export type NavigationTab =
  | 'inicio'
  | 'rutas'
  | 'ubicacion'
  | 'mensajes'
  | 'contactos'
  | 'alerta_config'
  | 'dispositivo'
  | 'actividad'
  | 'ajustes'
  | 'privacidad';
