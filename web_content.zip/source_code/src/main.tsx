import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Google Maps Platform Quota Defense — Mandatory handler for demo key limits
(window as any).gm_authFailure = () => {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
};
const origError = console.error;
console.error = (...args: unknown[]) => {
  origError.apply(console, args);
  const msg = args.map((a) => String(a)).join(' ');
  if (msg.includes('OverQuotaMapError') || msg.includes('QuotaExceededError')) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
};

// Register PWA service worker for instant installation, offline readiness, and automatic updates
if ('serviceWorker' in navigator) {
  try {
    const updateSW = registerSW({
      immediate: true,
      onNeedRefresh() {
        console.log('[NEXA PWA] Nueva versión disponible. Actualizando en segundo plano...');
        updateSW(true);
      },
      onOfflineReady() {
        console.log('[NEXA PWA] Aplicación lista para funcionar sin conexión.');
      },
    });
  } catch (err) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch((swErr) => {
        console.warn('[NEXA SW] Fallback registration note:', swErr);
      });
    });
  }
}

createRoot(document.getElementById('root')!).render(<App />);
