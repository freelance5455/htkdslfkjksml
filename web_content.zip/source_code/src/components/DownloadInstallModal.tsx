import React, { useState } from 'react';
import { usePWAInstall } from '../utils/usePWAInstall';
import { NexaLogo } from './NexaLogo';
import {
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FolderArchive,
  HardDriveDownload,
  Laptop,
  QrCode,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Terminal,
  WifiOff,
  X,
  Zap,
} from 'lucide-react';

interface DownloadInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DownloadInstallModal: React.FC<DownloadInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, install, downloadDirectPackage } = usePWAInstall();
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);
  const [activeTab, setActiveTab] = useState<'descargar' | 'apk' | 'qr'>('descargar');
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);

  if (!isOpen) return null;

  const appUrl = window.location.href.split('?')[0];

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    setDownloadComplete(false);

    try {
      // 1. First trigger direct download of the server bundle
      const res = await fetch('/download/app');
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'nexa-student-safety-network.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setDownloadComplete(true);
        setTimeout(() => setDownloadComplete(false), 5000);
        return;
      }
    } catch {
      // fallback
    }

    // 2. Client-side fallback if server endpoint is interrupted
    try {
      downloadDirectPackage();
      setDownloadComplete(true);
      setTimeout(() => setDownloadComplete(false), 5000);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setDownloadingZip(false);
    }
  };

  const handle1ClickInstallAndDownload = async () => {
    handleDownloadZip();
    if (isInstallable) {
      await install();
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // ignore
    }
  };

  const bubblewrapCommand = `npm i -g @bubblewrap/cli && bubblewrap init --manifest=${appUrl}manifest.webmanifest && bubblewrap build`;

  const handleCopyBubblewrap = async () => {
    try {
      await navigator.clipboard.writeText(bubblewrapCommand);
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2500);
    } catch {
      // ignore
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-xl rounded-3xl bg-[#0F1424] text-white border border-[#8B5CF6]/40 shadow-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Top App Store Style Banner */}
        <div className="relative bg-gradient-to-br from-[#1E1B4B] via-[#2E1065] to-[#0F1424] p-5 sm:p-6 border-b border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4 pr-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9] p-3 shadow-lg flex items-center justify-center shrink-0 border border-white/20">
              <NexaLogo variant="icon" size="md" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[11px] font-bold text-emerald-300 mb-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>PWA Oficial · Lista para APK Android</span>
              </div>
              <h2 className="font-display text-xl font-black text-white leading-tight">
                NEXA Safety
              </h2>
              <p className="text-xs text-[#EDE9FE]/75">
                PWA Standalone · Iconos 192/512px · Service Worker v1.0.1
              </p>
            </div>
          </div>
        </div>

        {/* Tab switch: Descargar vs APK Android vs QR */}
        <div className="grid grid-cols-3 p-1.5 bg-black/40 border-b border-white/10 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('descargar')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'descargar'
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span className="truncate">Instalar PWA</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('apk')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'apk'
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span className="truncate">APK Android</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('qr')}
            className={`py-2 px-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'qr'
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span className="truncate">Código QR</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[68vh] overflow-y-auto">
          {activeTab === 'descargar' && (
            <>
              {/* Status indicator if already installed */}
              {isInstalled && (
                <div className="rounded-2xl bg-emerald-500/15 border border-emerald-500/40 p-3.5 flex items-center gap-3 text-emerald-200">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="text-xs">
                    <p className="font-bold">¡NEXA ya está instalada en tu dispositivo!</p>
                    <p className="text-emerald-300/80 text-[11px]">
                      Estás disfrutando de la versión standalone a pantalla completa con acceso rápido.
                    </p>
                  </div>
                </div>
              )}

              {/* Main 1-Click Action Card */}
              <div className="rounded-2xl bg-gradient-to-b from-[#1E1B4B]/90 to-[#161338]/90 border-2 border-[#8B5CF6] p-5 space-y-4 shadow-xl">
                <div className="text-center space-y-1">
                  <div className="inline-flex items-center gap-1 text-[11px] font-bold text-[#C4B5FD] uppercase tracking-wider">
                    <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>Instalación PWA Directa en 1 Clic</span>
                  </div>
                  <h3 className="font-display text-lg font-black text-white">
                    Instalar NEXA como Aplicación Standalone
                  </h3>
                  <p className="text-xs text-[#EDE9FE]/80 max-w-sm mx-auto">
                    Se abre como una aplicación independiente sin barra de navegador en Android,
                    iPhone, Windows o Mac. Funciona offline mediante Service Worker.
                  </p>
                </div>

                <div className="space-y-2.5 pt-1">
                  {/* Primary 1-Click Button */}
                  <button
                    type="button"
                    onClick={handle1ClickInstallAndDownload}
                    className="w-full min-h-[50px] py-3 px-5 rounded-2xl bg-gradient-to-r from-[#8B5CF6] via-[#7C3AED] to-[#6D28D9] hover:brightness-110 active:scale-98 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer border border-white/20"
                  >
                    <HardDriveDownload className="w-5 h-5 text-amber-300 animate-pulse" />
                    <span>INSTALAR Y DESCARGAR AHORA</span>
                  </button>

                  {/* Native Install Option if prompt available */}
                  {isInstallable && (
                    <button
                      type="button"
                      onClick={install}
                      className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/15"
                    >
                      <Smartphone className="w-4 h-4 text-[#C4B5FD]" />
                      <span>Agregar a la pantalla de inicio</span>
                    </button>
                  )}

                  {/* Direct ZIP download button */}
                  <button
                    type="button"
                    disabled={downloadingZip}
                    onClick={handleDownloadZip}
                    className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-black/40 hover:bg-black/60 text-[#EDE9FE] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/10 disabled:opacity-50"
                  >
                    <FolderArchive className="w-4 h-4 text-emerald-400" />
                    <span>
                      {downloadingZip
                        ? 'Descargando archivos...'
                        : 'Bajar paquete completo offline (.zip)'}
                    </span>
                  </button>
                </div>

                {downloadComplete && (
                  <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-bold text-center flex items-center justify-center gap-2 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>✓ Se han bajado todos los archivos de la aplicación a tu dispositivo.</span>
                  </div>
                )}
              </div>

              {/* Compatible Devices Features */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-start gap-2.5">
                  <Smartphone className="w-5 h-5 text-[#C4B5FD] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-white">Android & iPhone</p>
                    <p className="text-[11px] text-slate-400">
                      Icono directo de 192x192 y 512px sin barra de URL.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-start gap-2.5">
                  <Laptop className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-white">Computadoras</p>
                    <p className="text-[11px] text-slate-400">
                      Windows, Mac o Linux: ventana nativa independiente.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-start gap-2.5">
                  <WifiOff className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-white">Service Worker</p>
                    <p className="text-[11px] text-slate-400">
                      Caché de recursos para funcionamiento offline.
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl bg-white/5 border border-white/10 p-3 flex items-start gap-2.5">
                  <Sparkles className="w-5 h-5 text-[#8B5CF6] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-xs text-white">Auto-Actualizable</p>
                    <p className="text-[11px] text-slate-400">
                      Se actualiza automáticamente al publicar cambios.
                    </p>
                  </div>
                </div>
              </div>
            </>
          )}

          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-gradient-to-r from-emerald-950/60 to-[#1E1B4B] border border-emerald-500/40 p-4 space-y-3">
                <div className="flex items-center gap-2 font-bold text-xs text-emerald-300">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>Configuración Lista para Generar APK Android (TWA)</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Tu PWA cumple al 100% con todos los requisitos oficiales de Google Play y Android
                  Trusted Web Activity (TWA):
                </p>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Manifest v3 configurado</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Iconos 192x192 y 512px maskable</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Display standalone nativo</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Service Worker con caché offline</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Shortcuts y orientación vertical</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>Theme color #1E1B4B</span>
                  </div>
                </div>
              </div>

              {/* Method 1: PWABuilder (No code, 1-Click APK generation) */}
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs text-white flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center text-[10px]">
                      1
                    </span>
                    <span>Opción A: Generar APK con PWABuilder (Recomendado)</span>
                  </div>
                </div>
                <p className="text-xs text-slate-300">
                  Herramienta oficial de Microsoft para empaquetar tu PWA en un archivo APK
                  firmado para Android o paquete para Google Play Store.
                </p>

                <a
                  href={`https://www.pwabuilder.com/?url=${encodeURIComponent(appUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Abrir en PWABuilder para descargar APK</span>
                </a>
              </div>

              {/* Method 2: Google Bubblewrap CLI */}
              <div className="rounded-2xl bg-slate-950 p-4 border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between text-slate-300">
                  <div className="flex items-center gap-2 font-bold">
                    <span className="w-5 h-5 rounded-full bg-slate-700 text-white flex items-center justify-center text-[10px]">
                      2
                    </span>
                    <Terminal className="w-3.5 h-3.5 text-[#A78BFA]" />
                    <span>Opción B: Con Google Bubblewrap (Terminal / CLI)</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyBubblewrap}
                    className="text-[11px] text-[#A78BFA] hover:text-white flex items-center gap-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedCmd ? 'Copiado' : 'Copiar'}</span>
                  </button>
                </div>
                <div className="bg-black/60 p-3 rounded-xl font-mono text-[11px] text-emerald-400 overflow-x-auto select-all">
                  {bubblewrapCommand}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'qr' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-white p-5 border border-slate-200 flex flex-col items-center justify-center text-center space-y-3">
                <p className="text-xs font-black text-slate-900 uppercase tracking-wider">
                  Escanea con la cámara de tu teléfono:
                </p>
                <div className="p-2 bg-white rounded-xl shadow-md border border-slate-300">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                      appUrl
                    )}`}
                    alt="Código QR de NEXA"
                    width={180}
                    height={180}
                    className="rounded-lg"
                    loading="lazy"
                  />
                </div>
                <p className="text-xs text-slate-600 max-w-xs">
                  Apunta tu teléfono al código QR para abrir e instalar la PWA standalone en tu
                  celular al instante.
                </p>
              </div>

              {/* Copy Link Section */}
              <div className="rounded-2xl bg-white/5 border border-white/10 p-4 space-y-2">
                <p className="text-xs font-bold text-white">Enlace de la aplicación:</p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={appUrl}
                    className="flex-1 px-3 py-2 rounded-xl bg-black/40 border border-white/15 text-xs text-[#EDE9FE] font-mono-tabular select-all focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="min-h-[38px] px-3.5 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0 transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>{copiedLink ? '¡Copiado!' : 'Copiar'}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-black/40 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span>PWA Standalone & Android APK Ready</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold cursor-pointer transition-colors"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
