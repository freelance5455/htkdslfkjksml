import React, { useState } from 'react';
import { usePWAInstall } from '../utils/usePWAInstall';
import { NexaLogo } from './NexaLogo';
import {
  AlertTriangle,
  Apple,
  CheckCircle2,
  Compass,
  Copy,
  Download,
  ExternalLink,
  FolderArchive,
  HardDriveDownload,
  Laptop,
  Monitor,
  QrCode,
  Share2,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Terminal,
  WifiOff,
  X,
  Zap,
} from 'lucide-react';

interface DownloadInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Visual Apple Safari Share Icon (Square box with upward arrow)
const AppleShareIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7" />
    <line x1="12" y1="2" x2="12" y2="15" />
    <polyline points="7 7 12 2 17 7" />
  </svg>
);

// Visual Apple Add to Home Screen Icon (Square box with plus sign)
const AppleAddHomeIcon = ({ className = 'w-5 h-5' }: { className?: string }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    aria-hidden="true"
  >
    <rect x="3" y="3" width="18" height="18" rx="4" />
    <line x1="12" y1="8" x2="12" y2="16" />
    <line x1="8" y1="12" x2="16" y2="12" />
  </svg>
);

export const DownloadInstallModal: React.FC<DownloadInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, isInAppBrowser, install, downloadDirectPackage } =
    usePWAInstall();

  // Detect platform automatically
  const isMobile =
    typeof navigator !== 'undefined' &&
    (/android|iphone|ipad|ipod|mobile|blackberry|iemobile|opera mini/i.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));

  // The 2 PRIMARY OPTIONS requested: 'moviles' vs 'computadoras'
  const [primaryOption, setPrimaryOption] = useState<'moviles' | 'computadoras'>(() => {
    return isMobile ? 'moviles' : 'computadoras';
  });

  // Mobile sub-mode if user wants to switch between detected OS and another
  const [forcedMobileOs, setForcedMobileOs] = useState<'auto' | 'android' | 'ios'>('auto');

  const [downloadingZip, setDownloadingZip] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showQrCode, setShowQrCode] = useState(false);

  if (!isOpen) return null;

  const appUrl = window.location.href.split('?')[0];

  // Determine active mobile mode
  const effectiveIsIos = forcedMobileOs === 'ios' ? true : forcedMobileOs === 'android' ? false : isIOS;

  // Detect desktop OS
  const userAgent = typeof navigator !== 'undefined' ? navigator.userAgent.toLowerCase() : '';
  const isWindows = /windows|win32/i.test(userAgent);
  const isMac = /macintosh|mac os x/i.test(userAgent) && !isIOS;
  const isLinux = /linux/i.test(userAgent) && !isAndroid;

  const desktopOsName = isWindows
    ? 'Windows 10 / 11'
    : isMac
    ? 'macOS (Apple)'
    : isLinux
    ? 'Linux'
    : 'Computadora (Escritorio)';

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    setDownloadComplete(false);

    try {
      const res = await fetch('/download/app');
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'nexa-student-safety-network.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setDownloadComplete(true);
        setTimeout(() => setDownloadComplete(false), 5000);
        return;
      }
    } catch {
      // fallback
    }

    try {
      downloadDirectPackage();
      setDownloadComplete(true);
      setTimeout(() => setDownloadComplete(false), 5000);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setDownloadingZip(false);
    }
  };

  const handle1ClickInstall = async () => {
    if (isInstallable) {
      await install();
    } else {
      // If prompt isn't directly dispatchable, download package
      handleDownloadZip();
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(appUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-xl rounded-3xl bg-[#0F1424] text-white border border-[#8B5CF6]/50 shadow-2xl overflow-hidden my-auto">
        {/* Top Header */}
        <div className="relative bg-gradient-to-br from-[#1E1B4B] via-[#2E1065] to-[#0F1424] p-5 sm:p-6 border-b border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4 pr-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9] p-3 shadow-lg flex items-center justify-center shrink-0 border border-white/20">
              <NexaLogo variant="icon" size="md" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[11px] font-bold text-emerald-300 mb-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Aplicación Multiplataforma Oficial</span>
              </div>
              <h2 className="font-display text-xl font-black text-white leading-tight">
                Instalar y Descargar NEXA
              </h2>
              <p className="text-xs text-[#EDE9FE]/75">
                Ventana independiente · Sin barras de navegador · Modo Offline
              </p>
            </div>
          </div>
        </div>

        {/* 2 MAIN PRIMARY OPTIONS AS REQUESTED BY USER */}
        <div className="grid grid-cols-2 p-2 bg-black/50 border-b border-white/10 gap-2">
          {/* OPTION 1: APLICACIÓN PARA MÓVILES */}
          <button
            type="button"
            onClick={() => setPrimaryOption('moviles')}
            className={`py-3 px-3 rounded-2xl font-black text-xs sm:text-sm flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              primaryOption === 'moviles'
                ? 'bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] text-white shadow-lg border-white/20 scale-[1.01]'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border-transparent'
            }`}
          >
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Para Móviles</span>
            </div>
            <span className="text-[10px] font-normal opacity-85">
              Android, Samsung, Xiaomi, iPhone
            </span>
          </button>

          {/* OPTION 2: APLICACIÓN PARA COMPUTADORAS */}
          <button
            type="button"
            onClick={() => setPrimaryOption('computadoras')}
            className={`py-3 px-3 rounded-2xl font-black text-xs sm:text-sm flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer border ${
              primaryOption === 'computadoras'
                ? 'bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] text-white shadow-lg border-white/20 scale-[1.01]'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 border-transparent'
            }`}
          >
            <div className="flex items-center gap-2">
              <Monitor className="w-4 h-4 text-blue-400" />
              <span>Para Computadoras</span>
            </div>
            <span className="text-[10px] font-normal opacity-85">
              Windows, macOS, Linux
            </span>
          </button>
        </div>

        {/* MODAL BODY */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[66vh] overflow-y-auto">
          {/* OPTION 1: UNIFIED MOBILE DOWNLOAD */}
          {primaryOption === 'moviles' && (
            <div className="space-y-4">
              {/* Device Auto-Detection Badge */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-[#8B5CF6]/30 text-[#C4B5FD] flex items-center justify-center">
                    {effectiveIsIos ? <Apple className="w-4 h-4" /> : <Smartphone className="w-4 h-4" />}
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      Dispositivo detectado:
                    </span>
                    <p className="font-bold text-white text-xs">
                      {effectiveIsIos
                        ? 'Apple iPhone / iPad (iOS)'
                        : 'Teléfono Android (Samsung, Xiaomi, Motorola, Huawei)'}
                    </p>
                  </div>
                </div>

                {/* Optional switch to test or share with other phones */}
                <div className="flex items-center gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setForcedMobileOs('android')}
                    className={`px-2 py-1 rounded-lg font-bold cursor-pointer transition-colors ${
                      !effectiveIsIos ? 'bg-[#8B5CF6] text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Android
                  </button>
                  <button
                    type="button"
                    onClick={() => setForcedMobileOs('ios')}
                    className={`px-2 py-1 rounded-lg font-bold cursor-pointer transition-colors ${
                      effectiveIsIos ? 'bg-[#8B5CF6] text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    iPhone
                  </button>
                </div>
              </div>

              {/* Status if already running as installed standalone app */}
              {isInstalled && (
                <div className="rounded-2xl bg-emerald-500/15 border border-emerald-500/40 p-3.5 flex items-center gap-3 text-emerald-200">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="text-xs">
                    <p className="font-bold">¡NEXA ya está instalada en este teléfono!</p>
                    <p className="text-emerald-300/80 text-[11px] mt-0.5">
                      Estás usando la aplicación a pantalla completa, sin barras de navegador y con alertas prioritarias.
                    </p>
                  </div>
                </div>
              )}

              {/* In-app browser warning for mobile users */}
              {isInAppBrowser && (
                <div className="rounded-2xl bg-amber-500/20 border-2 border-amber-500/60 p-4 space-y-2 text-amber-200">
                  <div className="flex items-center gap-2 font-bold text-xs text-amber-300">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Estás dentro del navegador de WhatsApp, Instagram o Facebook</span>
                  </div>
                  <p className="text-xs text-amber-100/90 leading-relaxed">
                    Las redes sociales bloquean la instalación directa en el teléfono. Toca los tres puntos (•••) o el icono de brújula y pulsa <strong>"Abrir en el navegador"</strong> (Chrome o Safari).
                  </p>
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedLink ? '¡Enlace copiado!' : 'Copiar enlace directo'}</span>
                  </button>
                </div>
              )}

              {/* CASE A: ANDROID (Samsung, Xiaomi, Motorola, Huawei, etc.) */}
              {!effectiveIsIos ? (
                <div className="rounded-2xl bg-gradient-to-b from-[#1E1B4B]/95 to-[#161338]/95 border-2 border-[#8B5CF6] p-5 space-y-4 shadow-xl">
                  <div className="text-center space-y-1">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[11px] font-bold">
                      <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span>Instalación Automática para Android</span>
                    </div>
                    <h3 className="font-display text-lg font-black text-white">
                      Instalar en Teléfono Android
                    </h3>
                    <p className="text-xs text-[#EDE9FE]/80 max-w-sm mx-auto">
                      Compatible con Samsung, Xiaomi, Motorola, Huawei y cualquier dispositivo Android.
                      Se abre como app nativa independiente con icono propio.
                    </p>
                  </div>

                  <div className="space-y-2.5 pt-1">
                    {/* Primary Button */}
                    <button
                      type="button"
                      onClick={handle1ClickInstall}
                      className="w-full min-h-[50px] py-3 px-5 rounded-2xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-[#8B5CF6] hover:brightness-110 active:scale-98 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer border border-white/20"
                    >
                      <HardDriveDownload className="w-5 h-5 text-amber-300 animate-pulse" />
                      <span>{isInstallable ? 'INSTALAR EN ANDROID EN 1 CLIC' : 'DESCARGAR APLICACIÓN MÓVIL'}</span>
                    </button>

                    {/* Direct APK Link with PWABuilder */}
                    <a
                      href={`https://www.pwabuilder.com/?url=${encodeURIComponent(appUrl)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/15"
                    >
                      <ExternalLink className="w-4 h-4 text-emerald-400" />
                      <span>Generar archivo APK para Android (PWABuilder Oficial)</span>
                    </a>

                    {/* Download Full Offline Bundle */}
                    <button
                      type="button"
                      disabled={downloadingZip}
                      onClick={handleDownloadZip}
                      className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-black/40 hover:bg-black/60 text-[#EDE9FE] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/10 disabled:opacity-50"
                    >
                      <FolderArchive className="w-4 h-4 text-purple-300" />
                      <span>
                        {downloadingZip ? 'Descargando paquete...' : 'Bajar paquete para convertidores APK (.zip)'}
                      </span>
                    </button>
                  </div>

                  {downloadComplete && (
                    <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-bold text-center flex items-center justify-center gap-2 animate-in fade-in">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>✓ Paquete móvil descargado exitosamente.</span>
                    </div>
                  )}
                </div>
              ) : (
                /* CASE B: IPHONE (iOS Safari) */
                <div className="rounded-2xl bg-gradient-to-b from-[#1E1B4B]/95 to-[#161338]/95 border-2 border-[#8B5CF6] p-5 space-y-4 shadow-xl">
                  <div className="text-center space-y-1">
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 text-[11px] font-bold text-[#C4B5FD]">
                      <Apple className="w-3.5 h-3.5 text-white" />
                      <span>Instalación Oficial en iPhone (iOS)</span>
                    </div>
                    <h3 className="font-display text-lg font-black text-white">
                      Cómo instalar NEXA en tu iPhone
                    </h3>
                    <p className="text-xs text-[#EDE9FE]/80 max-w-sm mx-auto">
                      En iOS Safari se instala en 3 pasos rápidos sin necesidad de App Store:
                    </p>
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="rounded-2xl bg-white/5 border border-white/15 p-3 flex items-start gap-3">
                      <div className="w-7 h-7 rounded-xl bg-[#8B5CF6] text-white font-black text-xs flex items-center justify-center shrink-0">
                        1
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-xs text-white">Toca Compartir en Safari</p>
                          <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center justify-center">
                            <AppleShareIcon className="w-3.5 h-3.5" />
                          </div>
                        </div>
                        <p className="text-[11px] text-slate-300 mt-0.5">
                          Icono de cuadro con flecha hacia arriba en la barra inferior de Safari.
                        </p>
                      </div>
                    </div>

                    <div className="rounded-2xl bg-white/5 border border-white/15 p-3 flex items-start gap-3">
                      <div className="w-7 h-7 rounded-xl bg-[#8B5CF6] text-white font-black text-xs flex items-center justify-center shrink-0">
                        2
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-xs text-white">Selecciona "Agregar al inicio"</p>
                          <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center">
                            <AppleAddHomeIcon className="w-3.5 h-3.5" />
                          </div>
                        </div>
                        <p className="text-[11px] text-slate-300 mt-0.5">
                          Desplaza hacia abajo en las opciones hasta encontrar "Agregar al inicio" (➕).
                        </p>
                      </div>
                    </div>

                    <div className="rounded-2xl bg-white/5 border border-white/15 p-3 flex items-start gap-3">
                      <div className="w-7 h-7 rounded-xl bg-[#8B5CF6] text-white font-black text-xs flex items-center justify-center shrink-0">
                        3
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-xs text-white">Presiona "Agregar" (Add)</p>
                        <p className="text-[11px] text-slate-300 mt-0.5">
                          En la esquina superior derecha. ¡Listo! NEXA se abrirá como app nativa con su icono oficial.
                        </p>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={downloadingZip}
                    onClick={handleDownloadZip}
                    className="w-full min-h-[42px] py-2 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-[#EDE9FE] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/15"
                  >
                    <FolderArchive className="w-4 h-4 text-emerald-400" />
                    <span>
                      {downloadingZip ? 'Descargando paquete...' : 'Bajar archivos completos de la aplicación (.zip)'}
                    </span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* OPTION 2: DESKTOP COMPUTER DOWNLOAD */}
          {primaryOption === 'computadoras' && (
            <div className="space-y-4">
              {/* Standalone Desktop Explanation */}
              <div className="rounded-2xl bg-gradient-to-r from-blue-950/60 via-[#1E1B4B] to-[#0F1424] border border-blue-500/40 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-300">
                  <Laptop className="w-4 h-4 text-blue-400" />
                  <span>Aplicación Independiente para {desktopOsName}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  La versión para computadoras mantiene exactamente el mismo diseño, estética y funciones de tu aplicación,
                  pero <strong>se abre en su propia ventana independiente</strong>, con su propio icono en la barra de tareas o Dock,
                  sin depender de tener Google Chrome abierto y sin barras de navegación web.
                </p>

                <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                  <div className="flex items-center gap-1.5 text-blue-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Ventana sin barras de URL</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-blue-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Icono en barra de tareas / Dock</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-blue-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Acceso directo de inicio</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-blue-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>Alertas sonoras y visuales</span>
                  </div>
                </div>
              </div>

              {/* 1-Click Desktop Installation Card */}
              <div className="rounded-2xl bg-gradient-to-b from-[#1E1B4B] to-[#161338] border-2 border-blue-500/50 p-5 space-y-4 shadow-xl">
                <div className="text-center space-y-1">
                  <h3 className="font-display text-lg font-black text-white">
                    Instalar en esta Computadora
                  </h3>
                  <p className="text-xs text-[#EDE9FE]/80 max-w-sm mx-auto">
                    Presiona el botón para agregar NEXA como programa de escritorio en Windows, macOS o Linux:
                  </p>
                </div>

                <div className="space-y-2.5">
                  <button
                    type="button"
                    onClick={handle1ClickInstall}
                    className="w-full min-h-[50px] py-3 px-5 rounded-2xl bg-gradient-to-r from-blue-600 via-indigo-600 to-[#8B5CF6] hover:brightness-110 active:scale-98 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2.5 transition-all cursor-pointer border border-white/20"
                  >
                    <Monitor className="w-5 h-5 text-amber-300" />
                    <span>{isInstallable ? 'INSTALAR COMO PROGRAMA DE ESCRITORIO' : 'INSTALAR APLICACIÓN STANDALONE'}</span>
                  </button>

                  {/* Fallback instruction for browser menu installation */}
                  <div className="rounded-xl bg-black/40 border border-white/10 p-3 text-[11px] text-slate-300 space-y-1">
                    <div className="font-bold text-white flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span>Instalación manual desde el navegador:</span>
                    </div>
                    <p className="leading-relaxed">
                      En Google Chrome, Edge o Brave, haz clic en el icono de instalación (🖥️) en la barra de direcciones o en <strong>Menú (⋮) &gt; "Instalar NEXA Safety"</strong>.
                    </p>
                  </div>

                  {/* Direct Desktop ZIP Package */}
                  <button
                    type="button"
                    disabled={downloadingZip}
                    onClick={handleDownloadZip}
                    className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-[#EDE9FE] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/15"
                  >
                    <FolderArchive className="w-4 h-4 text-emerald-400" />
                    <span>
                      {downloadingZip ? 'Descargando paquete...' : 'Descargar paquete completo offline para PC (.zip)'}
                    </span>
                  </button>
                </div>

                {downloadComplete && (
                  <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-xs font-bold text-center flex items-center justify-center gap-2 animate-in fade-in">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>✓ Paquete de computadora descargado exitosamente.</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Collapsible QR Code for transferring to other devices */}
          <div className="pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={() => setShowQrCode(!showQrCode)}
              className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-slate-300 hover:text-white flex items-center justify-between transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-[#8B5CF6]" />
                <span>¿Deseas abrir o instalar en otro teléfono o computadora?</span>
              </div>
              <span className="text-[#A78BFA] text-[11px]">
                {showQrCode ? 'Ocultar QR ▲' : 'Ver Código QR ▼'}
              </span>
            </button>

            {showQrCode && (
              <div className="mt-3 p-4 rounded-2xl bg-white text-slate-900 border border-slate-200 flex flex-col items-center justify-center text-center space-y-2.5 animate-in fade-in">
                <p className="text-xs font-black uppercase tracking-wider">
                  Escanea con la cámara de cualquier teléfono:
                </p>
                <div className="p-2 bg-white rounded-xl shadow-md border border-slate-300">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(
                      appUrl
                    )}`}
                    alt="Código QR de NEXA"
                    width={160}
                    height={160}
                    className="rounded-lg"
                    loading="lazy"
                  />
                </div>
                <div className="flex items-center gap-2 w-full max-w-sm pt-1">
                  <input
                    type="text"
                    readOnly
                    value={appUrl}
                    className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-100 border border-slate-300 text-xs font-mono select-all text-slate-800"
                  />
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-lg bg-[#8B5CF6] text-white text-xs font-bold cursor-pointer hover:bg-[#7C3AED]"
                  >
                    {copiedLink ? '¡Copiado!' : 'Copiar'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-black/50 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2 text-[11px]">
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Móviles (Android / iOS)</span>
            <span>·</span>
            <Monitor className="w-3.5 h-3.5 text-blue-400" />
            <span>Computadoras (Win/Mac/Linux)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold cursor-pointer transition-colors"
          >
            Listo
          </button>
        </div>
      </div>
    </div>
  );
};
