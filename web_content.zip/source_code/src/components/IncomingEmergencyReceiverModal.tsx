import React, { useEffect, useState } from 'react';
import {
  AlertOctagon,
  ExternalLink,
  MapPin,
  MessageCircle,
  Phone,
  PhoneCall,
  ShieldAlert,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { stopEmergencySiren } from '../utils/emergencySiren';
import { releaseScreenWakeLock } from '../utils/emergencyAlertService';

export interface IncomingEmergencyData {
  id: string;
  senderName: string;
  senderPhone: string;
  senderRole?: string;
  institution?: string;
  content: string;
  mapsUrl?: string;
  location?: {
    lat: number;
    lng: number;
    accuracy?: number;
  };
  timestamp: string;
  receivedAt?: string;
}

interface IncomingEmergencyReceiverModalProps {
  alert: IncomingEmergencyData | null;
  onAcknowledge: () => void;
  onOpenChat: () => void;
  onStartInAppCall?: (contact: { name: string; phone: string }) => void;
}

export const IncomingEmergencyReceiverModal: React.FC<IncomingEmergencyReceiverModalProps> = ({
  alert,
  onAcknowledge,
  onOpenChat,
  onStartInAppCall,
}) => {
  const [secondsElapsed, setSecondsElapsed] = useState(0);

  useEffect(() => {
    if (!alert) {
      setSecondsElapsed(0);
      return;
    }

    const timer = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [alert]);

  if (!alert) return null;

  const handleStopAndAcknowledge = () => {
    stopEmergencySiren();
    releaseScreenWakeLock();
    onAcknowledge();
  };

  const handleOpenChat = () => {
    stopEmergencySiren();
    releaseScreenWakeLock();
    onOpenChat();
  };

  const handleInAppCall = () => {
    stopEmergencySiren();
    releaseScreenWakeLock();
    if (onStartInAppCall) {
      onStartInAppCall({
        name: alert.senderName,
        phone: alert.senderPhone,
      });
    }
  };

  const cleanPhone = alert.senderPhone.replace(/\s+/g, '');
  const destinationMapUrl =
    alert.mapsUrl ||
    (alert.location
      ? `https://www.google.com/maps/dir/?api=1&destination=${alert.location.lat},${alert.location.lng}`
      : undefined);

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-150">
      <div className="w-full max-w-lg rounded-3xl bg-[#0F1424] text-white border-2 border-red-500 shadow-[0_0_50px_rgba(239,68,68,0.4)] overflow-hidden my-auto">
        {/* Pulsing Emergency Header */}
        <div className="relative bg-gradient-to-r from-red-700 via-rose-600 to-red-700 p-5 sm:p-6 text-white text-center border-b-2 border-red-400">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-black/30 border border-white/20 text-xs font-black tracking-wider uppercase mb-2 animate-bounce">
            <AlertOctagon className="w-4 h-4 text-amber-300 fill-amber-300" />
            <span>Alerta SOS Recibida en Vivo</span>
          </div>

          <h2 className="font-display text-2xl sm:text-3xl font-black leading-tight drop-shadow-md">
            ¡EMERGENCIA DE {alert.senderName.toUpperCase()}!
          </h2>

          <div className="flex items-center justify-center gap-3 mt-3 text-xs">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-400 text-amber-950 font-black shadow-sm">
              <Volume2 className="w-3.5 h-3.5 animate-pulse" />
              <span>Sirena Activa · Pantalla Encendida</span>
            </span>
            <span className="px-2.5 py-1 rounded-xl bg-white/20 text-white font-mono font-bold">
              Hace {secondsElapsed}s
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {/* Sender details card */}
          <div className="rounded-2xl bg-white/5 border border-white/10 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                Persona en peligro
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-[11px] font-bold">
                Prioridad Crítica
              </span>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-600 to-rose-700 flex items-center justify-center text-white font-black text-xl shadow-lg shrink-0">
                {alert.senderName.charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0">
                <h3 className="font-display text-lg font-black text-white truncate">
                  {alert.senderName}
                </h3>
                <p className="text-xs text-[#EDE9FE]/80">
                  {alert.institution?.trim()
                    ? `${alert.institution} · ${alert.senderRole || 'Estudiante'}`
                    : 'Contacto registrado en tu red de seguridad'}
                </p>
                <p className="text-xs font-mono text-[#C4B5FD] mt-0.5 font-bold">
                  {alert.senderPhone}
                </p>
              </div>
            </div>
          </div>

          {/* Emergency Message Box */}
          <div className="rounded-2xl bg-red-950/40 border border-red-500/40 p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-red-300">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>Mensaje de auxilio recibido:</span>
            </div>
            <p className="text-xs text-white leading-relaxed font-mono-tabular bg-black/40 p-3 rounded-xl border border-white/10 whitespace-pre-wrap">
              {alert.content || '¡Necesito ayuda urgente! Estoy en peligro. Por favor comunícate conmigo.'}
            </p>
          </div>

          {/* GPS Location & Navigation Link */}
          {destinationMapUrl && (
            <div className="rounded-2xl bg-gradient-to-r from-blue-950/40 to-indigo-950/40 border border-blue-500/40 p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-300">
                  <MapPin className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>Ubicación Satelital en Tiempo Real</span>
                </div>
                {alert.location?.accuracy && (
                  <span className="text-[10px] text-slate-400 font-mono">
                    Precisión ±{Math.round(alert.location.accuracy)}m
                  </span>
                )}
              </div>

              {alert.location && (
                <p className="text-[11px] font-mono text-slate-300">
                  Lat: {alert.location.lat.toFixed(6)}, Lng: {alert.location.lng.toFixed(6)}
                </p>
              )}

              <a
                href={destinationMapUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  stopEmergencySiren();
                  releaseScreenWakeLock();
                }}
                className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Abrir Ruta Satelital en Google Maps</span>
              </a>
            </div>
          )}

          {/* Emergency Response Actions */}
          <div className="space-y-2.5 pt-1">
            <div className="grid grid-cols-2 gap-2.5">
              {/* Native GSM Phone Call */}
              <a
                href={`tel:${cleanPhone}`}
                onClick={() => {
                  stopEmergencySiren();
                  releaseScreenWakeLock();
                }}
                className="min-h-[48px] py-2.5 px-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
              >
                <Phone className="w-4 h-4" />
                <span>Llamar por Celular</span>
              </a>

              {/* In-App Audio Call */}
              {onStartInAppCall ? (
                <button
                  type="button"
                  onClick={handleInAppCall}
                  className="min-h-[48px] py-2.5 px-3 rounded-2xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Llamada por App</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleOpenChat}
                  className="min-h-[48px] py-2.5 px-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Abrir Chat</span>
                </button>
              )}
            </div>

            {/* Direct Chat Button */}
            {onStartInAppCall && (
              <button
                type="button"
                onClick={handleOpenChat}
                className="w-full min-h-[42px] py-2 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-[#EDE9FE] font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/10"
              >
                <MessageCircle className="w-4 h-4 text-[#C4B5FD]" />
                <span>Abrir Chat de Auxilio con {alert.senderName}</span>
              </button>
            )}

            {/* Primary Dismiss / Stop Siren Button */}
            <button
              type="button"
              onClick={handleStopAndAcknowledge}
              className="w-full min-h-[48px] py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer border border-slate-700 shadow-md"
            >
              <VolumeX className="w-4 h-4 text-amber-400" />
              <span>Confirmar Recepción y Detener Sirena</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
