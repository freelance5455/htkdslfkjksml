import React, { useState, useEffect, useRef } from 'react';
import {
  ChatMessage,
  EmergencyContact,
  GeoLocationData,
  UserAccount,
} from '../types';
import { buildGoogleMapsLink } from '../utils/sosFormatter';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCheck,
  ChevronRight,
  ExternalLink,
  Heart,
  Image as ImageIcon,
  Info,
  MapPin,
  MessageCircle,
  Mic,
  MoreVertical,
  Navigation,
  Phone,
  PhoneCall,
  Plus,
  Search,
  Send,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Smile,
  Trash2,
  UserPlus,
} from 'lucide-react';

interface NexaChatViewProps {
  currentUser: UserAccount;
  contacts: EmergencyContact[];
  messages: ChatMessage[];
  currentLocation: GeoLocationData | null;
  onSendMessage: (receiverPhone: string, content: string, isSos?: boolean, sosDetails?: any) => void;
  onMarkMessagesAsRead: (contactPhone: string) => void;
  onDeleteMessage?: (messageId: string) => void;
  onClearConversation?: (contactPhone: string) => void;
  onStartInAppCall?: (contact: EmergencyContact) => void;
  onOpenAddContactModal: () => void;
  onNavigateToLocation?: () => void;
}

export const NexaChatView: React.FC<NexaChatViewProps> = ({
  currentUser,
  contacts,
  messages,
  currentLocation,
  onSendMessage,
  onMarkMessagesAsRead,
  onDeleteMessage,
  onClearConversation,
  onStartInAppCall,
  onOpenAddContactModal,
  onNavigateToLocation,
}) => {
  const chatContacts = contacts.filter((c) => c.phone && c.phone.trim().length > 0);

  const [activeContactId, setActiveContactId] = useState<string>(
    chatContacts[0]?.id || ''
  );
  const [inputText, setInputText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileConversationOpen, setIsMobileConversationOpen] = useState(false);
  const [showChatMenu, setShowChatMenu] = useState(false);
  const [hoveredMsgId, setHoveredMsgId] = useState<string | null>(null);
  const [likedMessageIds, setLikedMessageIds] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeContact = chatContacts.find((c) => c.id === activeContactId) || chatContacts[0];

  const normalizePhone = (num?: string) => (num || '').replace(/\D/g, '');
  const userNormPhone = normalizePhone(currentUser.phone);
  const contactNormPhone = activeContact ? normalizePhone(activeContact.phone) : '';

  // Deduplicate and filter messages for current active conversation
  const rawConversationMessages = messages.filter((msg) => {
    const sNorm = normalizePhone(msg.senderPhone);
    const rNorm = normalizePhone(msg.receiverPhone);
    return (
      (sNorm === userNormPhone && rNorm === contactNormPhone) ||
      (sNorm === contactNormPhone && rNorm === userNormPhone) ||
      (contactNormPhone.length > 5 && (rNorm.endsWith(contactNormPhone) || contactNormPhone.endsWith(rNorm)))
    );
  });

  // Strict deduplication by ID or exact content within 2 seconds
  const seenIds = new Set<string>();
  const conversationMessages: ChatMessage[] = [];
  for (const msg of rawConversationMessages) {
    if (!seenIds.has(msg.id)) {
      seenIds.add(msg.id);
      conversationMessages.push(msg);
    }
  }

  const getUnreadCount = (cPhone: string) => {
    const cNorm = normalizePhone(cPhone);
    return messages.filter(
      (m) =>
        !m.read &&
        (normalizePhone(m.senderPhone) === cNorm || (cNorm.length > 5 && normalizePhone(m.senderPhone).endsWith(cNorm)))
    ).length;
  };

  const getLastMessage = (cPhone: string) => {
    const cNorm = normalizePhone(cPhone);
    const msgs = messages.filter((m) => {
      const s = normalizePhone(m.senderPhone);
      const r = normalizePhone(m.receiverPhone);
      return s === cNorm || r === cNorm || (cNorm.length > 5 && (s.endsWith(cNorm) || r.endsWith(cNorm)));
    });
    return msgs[msgs.length - 1];
  };

  useEffect(() => {
    if (activeContact?.phone) {
      onMarkMessagesAsRead(activeContact.phone);
    }
  }, [activeContactId, messages.length]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversationMessages.length]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeContact) return;

    onSendMessage(activeContact.phone, inputText.trim(), false);
    setInputText('');
  };

  const handleSendQuickSos = () => {
    if (!activeContact) return;
    const lat = currentLocation?.lat ?? -2.1894;
    const lng = currentLocation?.lng ?? -79.8891;
    const mapsLink = buildGoogleMapsLink(lat, lng);

    const sosDetails = {
      location: { lat, lng, accuracy: currentLocation?.accuracy ?? 12 },
      battery: 88,
      mapsUrl: mapsLink,
      activationSource: 'chat_direct_alert',
    };

    onSendMessage(
      activeContact.phone,
      `🚨 ¡ALERTA DE EMERGENCIA SOS! Necesito ayuda urgente en mi ubicación: ${mapsLink}`,
      true,
      sosDetails
    );
  };

  const handleQuickReply = (text: string) => {
    if (!activeContact) return;
    onSendMessage(activeContact.phone, text, false);
  };

  const toggleLikeMessage = (id: string) => {
    setLikedMessageIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleClearChat = () => {
    if (!activeContact) return;
    if (window.confirm(`¿Estás seguro de que deseas vaciar todos los mensajes del chat con ${activeContact.firstName}?`)) {
      if (onClearConversation) {
        onClearConversation(activeContact.phone);
      }
      setShowChatMenu(false);
    }
  };

  const filteredContacts = chatContacts.filter(
    (c) =>
      `${c.firstName} ${c.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm)
  );

  return (
    <div className="rounded-3xl bg-[#0F172A] border border-slate-800 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[620px] max-h-[750px]">
      {/* LEFT: Instagram Direct Sidebar */}
      <div
        className={`md:col-span-5 lg:col-span-4 border-r border-slate-800/80 flex flex-col bg-[#0B0F19] ${
          isMobileConversationOpen ? 'hidden md:flex' : 'flex'
        }`}
      >
        {/* Instagram Direct Header */}
        <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="font-display text-base font-bold text-white tracking-tight">
              {currentUser.fullName || 'usuario'}
            </h2>
            <span className="w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20" />
          </div>

          <button
            type="button"
            onClick={onOpenAddContactModal}
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-[#8B5CF6]/20 text-[#C4B5FD] flex items-center justify-center cursor-pointer transition-colors"
            title="Añadir nuevo contacto"
          >
            <UserPlus className="w-4 h-4" />
          </button>
        </div>

        {/* Search bar */}
        <div className="p-3 border-b border-slate-800/60">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar amigos o chats..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>
        </div>

        {/* Chats list */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40">
          {filteredContacts.length === 0 ? (
            <div className="p-8 text-center space-y-3">
              <MessageCircle className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-xs text-slate-400">No tienes contactos agregados con número móvil.</p>
              <button
                type="button"
                onClick={onOpenAddContactModal}
                className="px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold cursor-pointer shadow-md"
              >
                + Añadir amigo a contactos
              </button>
            </div>
          ) : (
            filteredContacts.map((contact) => {
              const isActive = activeContact?.id === contact.id;
              const unread = getUnreadCount(contact.phone);
              const lastMsg = getLastMessage(contact.phone);

              return (
                <button
                  key={contact.id}
                  type="button"
                  onClick={() => {
                    setActiveContactId(contact.id);
                    setIsMobileConversationOpen(true);
                  }}
                  className={`w-full p-3.5 text-left flex items-center gap-3 transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-slate-800/80 border-l-4 border-[#8B5CF6]'
                      : 'hover:bg-slate-900/60'
                  }`}
                >
                  {/* Story-ring style Instagram avatar */}
                  <div className="relative shrink-0">
                    <div className="w-11 h-11 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 via-rose-500 to-[#8B5CF6]">
                      <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center font-display font-bold text-xs text-white uppercase">
                        {contact.firstName.charAt(0)}
                        {contact.lastName.charAt(0)}
                      </div>
                    </div>
                    {contact.authorized && (
                      <span
                        className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-[#0B0F19] absolute bottom-0 right-0"
                        title="Contacto de auxilio activo"
                      />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-display text-xs font-bold text-white truncate">
                        {contact.firstName} {contact.lastName}
                      </p>
                      {lastMsg && (
                        <span className="text-[10px] text-slate-500">
                          {new Date(lastMsg.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between mt-0.5">
                      <p className="text-[11px] text-slate-400 truncate">
                        {lastMsg ? (
                          lastMsg.isSosAlert ? (
                            <span className="text-rose-400 font-semibold">🚨 Alerta SOS</span>
                          ) : (
                            lastMsg.content
                          )
                        ) : (
                          `@${contact.firstName.toLowerCase()}_nexa`
                        )}
                      </p>

                      {unread > 0 && (
                        <span className="ml-2 px-1.5 py-0.5 rounded-full bg-[#8B5CF6] text-white text-[10px] font-bold shrink-0">
                          {unread}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* RIGHT: Active Chat Room (Instagram Direct Style) */}
      <div
        className={`md:col-span-7 lg:col-span-8 flex flex-col bg-[#0F172A] ${
          isMobileConversationOpen ? 'flex' : 'hidden md:flex'
        }`}
      >
        {activeContact ? (
          <>
            {/* Direct Header Bar */}
            <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-[#0F172A]/90 backdrop-blur-md relative">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsMobileConversationOpen(false)}
                  className="md:hidden p-1.5 rounded-lg text-slate-400 hover:text-white"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>

                <div className="relative">
                  <div className="w-10 h-10 rounded-full p-0.5 bg-gradient-to-tr from-amber-500 to-[#8B5CF6]">
                    <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center font-display font-bold text-xs text-white">
                      {activeContact.firstName.charAt(0)}
                    </div>
                  </div>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#0F172A] absolute bottom-0 right-0" />
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-display text-sm font-bold text-white">
                      {activeContact.firstName} {activeContact.lastName}
                    </h3>
                    <span title="Contacto de Confianza">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    {activeContact.phone}
                  </p>
                </div>
              </div>

              {/* Action Buttons: SOS, In-App Call, Direct Phone, Menu */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handleSendQuickSos}
                  className="px-2.5 py-1.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition-all active:scale-95 cursor-pointer"
                  title="Enviar alerta SOS inmediata con coordenadas"
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Alerta SOS</span>
                </button>

                {/* IN-APP VOICE CALL */}
                {onStartInAppCall && (
                  <button
                    type="button"
                    onClick={() => onStartInAppCall(activeContact)}
                    className="w-9 h-9 rounded-full bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/35 text-[#C4B5FD] flex items-center justify-center cursor-pointer transition-colors"
                    title="Llamada de voz NEXA por la app"
                  >
                    <PhoneCall className="w-4 h-4 text-emerald-400" />
                  </button>
                )}

                {/* Cellular Call */}
                <a
                  href={`tel:${activeContact.phone}`}
                  className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer transition-colors"
                  title="Llamar por red celular"
                >
                  <Phone className="w-4 h-4" />
                </a>

                {/* Instagram 3-Dots Menu */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowChatMenu(!showChatMenu)}
                    className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer transition-colors"
                    title="Opciones de chat"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>

                  {showChatMenu && (
                    <div className="absolute right-0 top-11 z-20 w-48 rounded-2xl bg-[#1E1B4B] border border-slate-700 shadow-xl py-1 text-xs text-slate-200">
                      <button
                        type="button"
                        onClick={handleClearChat}
                        className="w-full px-4 py-2.5 text-left hover:bg-rose-950/40 text-rose-300 flex items-center gap-2 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Vaciar conversación</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setShowChatMenu(false);
                          if (onStartInAppCall) onStartInAppCall(activeContact);
                        }}
                        className="w-full px-4 py-2.5 text-left hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                      >
                        <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Iniciar llamada NEXA</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Messages Feed */}
            <div className="flex-1 p-4 overflow-y-auto space-y-2.5 min-h-[360px] max-h-[480px]">
              {conversationMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-3">
                  <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-[#C4B5FD]">
                    <MessageCircle className="w-8 h-8" />
                  </div>
                  <h4 className="font-display text-sm font-bold text-white">
                    Conversación con {activeContact.firstName}
                  </h4>
                  <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                    Escribe un mensaje, inicia una llamada por la misma app o presiona el botón SOS
                    para enviar tu ubicación en tiempo real.
                  </p>
                </div>
              ) : (
                conversationMessages.map((msg) => {
                  const isFromMe =
                    normalizePhone(msg.senderPhone) === userNormPhone ||
                    msg.senderName === currentUser.fullName;
                  const isLiked = likedMessageIds.has(msg.id);

                  // EMERGENCY SOS ALERT CARD
                  if (msg.isSosAlert) {
                    return (
                      <div
                        key={msg.id}
                        className={`my-3 p-4 rounded-3xl border-2 shadow-2xl transition-all ${
                          isFromMe
                            ? 'bg-rose-950/60 border-rose-500 text-white ml-auto max-w-sm'
                            : 'bg-rose-900/80 border-rose-400 text-white mr-auto max-w-sm ring-4 ring-rose-500/25'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 font-display text-xs font-black uppercase tracking-wider text-rose-300 mb-2">
                          <div className="flex items-center gap-1.5">
                            <ShieldAlert className="w-4 h-4 animate-bounce text-rose-400" />
                            <span>
                              {isFromMe ? 'Alerta SOS Enviada' : `🚨 ¡ALERTA SOS DE ${msg.senderName.toUpperCase()}!`}
                            </span>
                          </div>

                          {onDeleteMessage && (
                            <button
                              type="button"
                              onClick={() => onDeleteMessage(msg.id)}
                              className="text-rose-300/60 hover:text-rose-100 p-1"
                              title="Eliminar este mensaje"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>

                        <p className="text-xs font-medium leading-relaxed mb-3 text-rose-100">
                          {msg.content}
                        </p>

                        {msg.sosDetails?.location && (
                          <div className="bg-black/40 p-2.5 rounded-2xl text-[11px] font-mono-tabular space-y-1 mb-3 border border-rose-500/30">
                            <p className="text-slate-300">
                              📍 Lat: {msg.sosDetails.location.lat.toFixed(5)}, Lng:{' '}
                              {msg.sosDetails.location.lng.toFixed(5)}
                            </p>
                            {msg.sosDetails.battery && (
                              <p className="text-slate-300">
                                🔋 Batería: {msg.sosDetails.battery}%
                              </p>
                            )}
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2 pt-1">
                          {(msg.sosDetails?.mapsUrl || msg.sosDetails?.location) && (
                            <a
                              href={
                                msg.sosDetails?.mapsUrl ||
                                (msg.sosDetails?.location
                                  ? buildGoogleMapsLink(msg.sosDetails.location.lat, msg.sosDetails.location.lng)
                                  : '#')
                              }
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-3 py-1.5 rounded-xl bg-white text-rose-900 text-[11px] font-bold flex items-center gap-1 shadow-sm hover:bg-rose-100"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>Ver en Google Maps</span>
                            </a>
                          )}

                          {!isFromMe && (
                            <button
                              type="button"
                              onClick={() => handleQuickReply('¡Tranquilo! Recibí tu alerta SOS, voy en camino.')}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <Navigation className="w-3 h-3" />
                              <span>Responder: &ldquo;Voy en camino&rdquo;</span>
                            </button>
                          )}
                        </div>

                        <div className="text-[10px] text-rose-300/80 mt-2.5 pt-2 border-t border-rose-500/20 flex justify-between">
                          <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          <span>{isFromMe ? 'Enviado una vez' : 'Recibido en NEXA'}</span>
                        </div>
                      </div>
                    );
                  }

                  // INSTAGRAM DIRECT TEXT BUBBLE
                  return (
                    <div
                      key={msg.id}
                      onMouseEnter={() => setHoveredMsgId(msg.id)}
                      onMouseLeave={() => setHoveredMsgId(null)}
                      className={`group relative flex flex-col ${isFromMe ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center gap-1.5 max-w-[85%]">
                        {/* Action buttons (Instagram style: heart & delete) on hover */}
                        {isFromMe && (hoveredMsgId === msg.id || isLiked) && (
                          <div className="flex items-center gap-1 opacity-90 transition-opacity">
                            {onDeleteMessage && (
                              <button
                                type="button"
                                onClick={() => onDeleteMessage(msg.id)}
                                className="p-1 rounded-full text-slate-500 hover:text-rose-400 hover:bg-slate-800 cursor-pointer"
                                title="Eliminar mensaje (Instagram unsend)"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => toggleLikeMessage(msg.id)}
                              className={`p-1 rounded-full hover:bg-slate-800 cursor-pointer ${
                                isLiked ? 'text-rose-500' : 'text-slate-500 hover:text-rose-400'
                              }`}
                              title="Reaccionar con corazón"
                            >
                              <Heart className="w-3.5 h-3.5 fill-current" />
                            </button>
                          </div>
                        )}

                        <div
                          onDoubleClick={() => toggleLikeMessage(msg.id)}
                          className={`relative px-4 py-2.5 rounded-3xl text-xs leading-relaxed transition-all ${
                            isFromMe
                              ? 'bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] text-white rounded-br-xs shadow-md'
                              : 'bg-slate-800 text-slate-100 rounded-bl-xs'
                          }`}
                        >
                          <p>{msg.content}</p>
                          <div
                            className={`flex items-center justify-end gap-1 text-[9px] mt-1 ${
                              isFromMe ? 'text-purple-200' : 'text-slate-400'
                            }`}
                          >
                            <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            {isFromMe && <CheckCheck className="w-3 h-3" />}
                          </div>

                          {/* Instagram Heart Reaction badge */}
                          {isLiked && (
                            <span className="absolute -bottom-2 -right-1 bg-[#1E1B4B] border border-rose-500/40 rounded-full p-0.5 text-rose-500 shadow-sm animate-bounce">
                              <Heart className="w-3 h-3 fill-rose-500" />
                            </span>
                          )}
                        </div>

                        {/* For messages received from friend */}
                        {!isFromMe && (hoveredMsgId === msg.id || isLiked) && (
                          <div className="flex items-center gap-1 opacity-90 transition-opacity">
                            <button
                              type="button"
                              onClick={() => toggleLikeMessage(msg.id)}
                              className={`p-1 rounded-full hover:bg-slate-800 cursor-pointer ${
                                isLiked ? 'text-rose-500' : 'text-slate-500 hover:text-rose-400'
                              }`}
                              title="Reaccionar con corazón"
                            >
                              <Heart className="w-3.5 h-3.5 fill-current" />
                            </button>
                            {onDeleteMessage && (
                              <button
                                type="button"
                                onClick={() => onDeleteMessage(msg.id)}
                                className="p-1 rounded-full text-slate-500 hover:text-rose-400 hover:bg-slate-800 cursor-pointer"
                                title="Eliminar para mí"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Instagram Suggestion Chips */}
            <div className="px-4 py-2 bg-[#0B0F19] border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto">
              <button
                type="button"
                onClick={() => handleQuickReply('¿Estás bien?')}
                className="px-3 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] whitespace-nowrap cursor-pointer transition-colors"
              >
                ¿Estás bien?
              </button>
              <button
                type="button"
                onClick={() => handleQuickReply('Voy en camino a buscarte.')}
                className="px-3 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] whitespace-nowrap cursor-pointer transition-colors"
              >
                Voy en camino
              </button>
              <button
                type="button"
                onClick={() => handleQuickReply('Ya llegué bien a mi destino.')}
                className="px-3 py-1 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-[11px] whitespace-nowrap cursor-pointer transition-colors"
              >
                Llegué bien
              </button>
            </div>

            {/* Instagram Direct Input Bar */}
            <form
              onSubmit={handleSendText}
              className="p-3 border-t border-slate-800 bg-[#0F172A] flex items-center gap-2"
            >
              <button
                type="button"
                onClick={handleSendQuickSos}
                title="Mandar Alerta SOS con mi ubicación"
                className="w-10 h-10 rounded-full bg-rose-600/20 text-rose-500 hover:bg-rose-600 hover:text-white flex items-center justify-center shrink-0 cursor-pointer transition-colors"
              >
                <AlertTriangle className="w-5 h-5" />
              </button>

              <div className="flex-1 flex items-center bg-slate-900 border border-slate-800 rounded-full px-4 py-2 text-xs focus-within:border-[#8B5CF6]">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Mensaje a ${activeContact.firstName}...`}
                  className="flex-1 bg-transparent text-white placeholder-slate-500 focus:outline-none text-xs"
                />
              </div>

              <button
                type="submit"
                disabled={!inputText.trim()}
                className="w-10 h-10 rounded-full bg-[#8B5CF6] hover:bg-[#7C3AED] disabled:opacity-40 text-white flex items-center justify-center shrink-0 cursor-pointer shadow-md transition-all active:scale-95"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-3">
            <MessageCircle className="w-12 h-12 text-slate-600" />
            <h3 className="font-display text-sm font-bold text-white">
              Tus Mensajes y Alertas
            </h3>
            <p className="text-xs text-slate-400 max-w-sm">
              Envía mensajes directos a tus amigos o activa la alerta SOS para que reciban tu
              ubicación de inmediato.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
