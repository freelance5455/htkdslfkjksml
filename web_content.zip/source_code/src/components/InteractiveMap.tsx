// Source: Google Maps Platform Code Assist
import React, { useEffect, useRef, useState } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin, useMap } from '@vis.gl/react-google-maps';
import { GeoLocationData, SafeRouteSession } from '../types';
import { Compass, Crosshair, MapPin, Navigation, ShieldAlert, Sparkles } from 'lucide-react';

interface InteractiveMapProps {
  location: GeoLocationData | null;
  activeRoute: SafeRouteSession | null;
  onRequestLocation: () => void;
  isLocating: boolean;
  onSelectCustomDestination?: (lat: number, lng: number) => void;
  heightClass?: string;
  theme?: 'dark' | 'light';
}

const GOOGLE_MAPS_API_KEY =
  import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'AIzaSyDop5yAZtZSfPit_hpsIfhtnK8c6lbj88I';

// Custom dark purple map styling to match NEXA branding
const DARK_PURPLE_MAP_STYLE: google.maps.MapTypeStyle[] = [
  { elementType: 'geometry', stylers: [{ color: '#171435' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#120f2c' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#a5b4fc' }] },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#c4b5fd' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#818cf8' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#1d1945' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#2b2463' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1e1a42' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#6366f1' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#252055' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#0c0a1f' }],
  },
];

// Inner controller to pan/fit bounds and render polyline & radius
function MapViewController({
  location,
  activeRoute,
  onSelectCustomDestination,
}: {
  location: GeoLocationData | null;
  activeRoute: SafeRouteSession | null;
  onSelectCustomDestination?: (lat: number, lng: number) => void;
}) {
  const map = useMap();
  const polylineRef = useRef<google.maps.Polyline | null>(null);
  const userCircleRef = useRef<google.maps.Circle | null>(null);
  const destCircleRef = useRef<google.maps.Circle | null>(null);

  // Handle map click for custom destination
  useEffect(() => {
    if (!map || !onSelectCustomDestination) return;
    const listener = map.addListener('click', (e: google.maps.MapMouseEvent) => {
      if (e.latLng) {
        onSelectCustomDestination(
          Number(e.latLng.lat().toFixed(6)),
          Number(e.latLng.lng().toFixed(6))
        );
      }
    });
    return () => {
      google.maps.event.removeListener(listener);
    };
  }, [map, onSelectCustomDestination]);

  // Handle camera position & geometric layers
  useEffect(() => {
    if (!map) return;

    // Clean previous vectors
    if (polylineRef.current) polylineRef.current.setMap(null);
    if (userCircleRef.current) userCircleRef.current.setMap(null);
    if (destCircleRef.current) destCircleRef.current.setMap(null);

    // Accuracy circle for user
    if (location && location.isLive) {
      userCircleRef.current = new google.maps.Circle({
        strokeColor: '#8B5CF6',
        strokeOpacity: 0.8,
        strokeWeight: 1.5,
        fillColor: '#8B5CF6',
        fillOpacity: 0.15,
        map,
        center: { lat: location.lat, lng: location.lng },
        radius: Math.max(location.accuracy || 20, 15),
      });
    }

    // Active Route: Destination radius + Polyline connecting route
    if (activeRoute && activeRoute.status === 'active') {
      destCircleRef.current = new google.maps.Circle({
        strokeColor: '#38BDF8',
        strokeOpacity: 0.9,
        strokeWeight: 2,
        fillColor: '#38BDF8',
        fillOpacity: 0.12,
        map,
        center: { lat: activeRoute.destinationLat, lng: activeRoute.destinationLng },
        radius: activeRoute.toleranceMeters,
      });

      if (location && location.isLive) {
        const path = [
          { lat: location.lat, lng: location.lng },
          { lat: activeRoute.destinationLat, lng: activeRoute.destinationLng },
        ];

        polylineRef.current = new google.maps.Polyline({
          path,
          geodesic: true,
          strokeColor: '#A78BFA',
          strokeOpacity: 0.9,
          strokeWeight: 4,
          map,
        });

        const bounds = new google.maps.LatLngBounds();
        bounds.extend({ lat: location.lat, lng: location.lng });
        bounds.extend({ lat: activeRoute.destinationLat, lng: activeRoute.destinationLng });
        map.fitBounds(bounds, { top: 40, right: 40, bottom: 40, left: 40 });
      } else {
        map.panTo({ lat: activeRoute.destinationLat, lng: activeRoute.destinationLng });
        map.setZoom(15);
      }
    } else if (location && location.isLive) {
      map.panTo({ lat: location.lat, lng: location.lng });
      map.setZoom(16);
    }
  }, [map, location?.lat, location?.lng, activeRoute?.id, activeRoute?.status]);

  return null;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  location,
  activeRoute,
  onRequestLocation,
  isLocating,
  onSelectCustomDestination,
  heightClass = 'h-72 sm:h-80',
  theme = 'dark',
}) => {
  // Default fallback center: Ecuador standard coordinates or live user coordinates
  const defaultCenter = location && location.isLive
    ? { lat: location.lat, lng: location.lng }
    : activeRoute
    ? { lat: activeRoute.destinationLat, lng: activeRoute.destinationLng }
    : { lat: -2.1894, lng: -79.8891 };

  return (
    <div className={`relative w-full ${heightClass} rounded-2xl overflow-hidden border border-[#8B5CF6]/30 shadow-lg bg-[#0F0C20]`}>
      <APIProvider apiKey={GOOGLE_MAPS_API_KEY}>
        <Map
          mapId="DEMO_MAP_ID"
          defaultCenter={defaultCenter}
          defaultZoom={location && location.isLive ? 16 : 14}
          styles={theme === 'dark' ? DARK_PURPLE_MAP_STYLE : undefined}
          gestureHandling="greedy"
          disableDefaultUI={false}
          zoomControl={true}
          mapTypeControl={false}
          streetViewControl={false}
          fullscreenControl={false}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          className="w-full h-full min-h-full"
        >
          <MapViewController
            location={location}
            activeRoute={activeRoute}
            onSelectCustomDestination={onSelectCustomDestination}
          />

          {/* User Live Marker */}
          {location && location.isLive && (
            <AdvancedMarker position={{ lat: location.lat, lng: location.lng }} title="Tu ubicación real GPS">
              <div className="relative flex items-center justify-center">
                <span className="absolute w-8 h-8 rounded-full bg-violet-500/40 animate-ping" />
                <div className="w-5 h-5 rounded-full bg-violet-600 border-2 border-white shadow-md flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-white" />
                </div>
              </div>
            </AdvancedMarker>
          )}

          {/* SafeRoute Destination Marker */}
          {activeRoute && activeRoute.status === 'active' && (
            <AdvancedMarker
              position={{ lat: activeRoute.destinationLat, lng: activeRoute.destinationLng }}
              title={`Destino: ${activeRoute.destinationName}`}
            >
              <Pin background="#4F46E5" glyphColor="#FFFFFF" borderColor="#C4B5FD" scale={1.15} />
            </AdvancedMarker>
          )}
        </Map>
      </APIProvider>

      {/* Floating Controls Overlay */}
      <div className="absolute top-3 right-3 z-10 flex flex-col gap-2">
        <button
          type="button"
          onClick={onRequestLocation}
          disabled={isLocating}
          title="Centrar en mi ubicación GPS en tiempo real"
          className="p-2.5 rounded-xl bg-[#1E1B4B]/90 hover:bg-[#2E296B] backdrop-blur-md border border-[#8B5CF6]/40 text-white shadow-md cursor-pointer transition-all flex items-center justify-center active:scale-95"
        >
          <Crosshair className={`w-4 h-4 text-[#C4B5FD] ${isLocating ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Bottom status badge */}
      <div className="absolute bottom-3 left-3 right-3 sm:right-auto z-10 pointer-events-none">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#0F0C20]/85 backdrop-blur-md border border-[#8B5CF6]/30 text-white text-[11px] font-medium shadow-md">
          {location && location.isLive ? (
            <>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>GPS en vivo · Precisión ±{Math.round(location.accuracy)} m</span>
            </>
          ) : (
            <>
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>Ubicación estimada · Pulsa el icono para GPS exacto</span>
            </>
          )}
          {activeRoute && (
            <span className="text-[#C4B5FD] border-l border-white/20 pl-2">
              Ruta: {activeRoute.destinationName}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
