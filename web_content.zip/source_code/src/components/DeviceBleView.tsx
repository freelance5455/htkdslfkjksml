import React, { useState } from 'react';
import { NexaDeviceState, WearableFormat } from '../types';
import { PROVISIONAL_BLE_SPEC, WEARABLE_FORMATS } from '../constants';
import { WearableIllustration } from './NexaLogo';
import { testSirenBriefly } from '../utils/emergencySiren';
import {
  AlertCircle,
  AlertOctagon,
  BatteryCharging,
  Bluetooth,
  BluetoothConnected,
  BluetoothOff,
  Cpu,
  FlaskConical,
  Lightbulb,
  MapPin,
  Radio,
  RefreshCw,
  ShieldCheck,
  Volume2,
  VolumeX,
  Waves,
} from 'lucide-react';

interface DeviceBleViewProps {
  device: NexaDeviceState;
  onScanRealBle: () => void;
  onToggleDemoConnection: () => void;
  onDisconnect: () => void;
  onSelectFormat: (format: WearableFormat) => void;
  onSimulateButtonPress: (pressType: 'short' | 'long') => void;
  onQueueOfflineDemoEvent: () => void;
  onSyncPendingEvents: () => void;
  onHardwareTest: (component: 'vibrator' | 'led' | 'buzzer') => void;
}

export const DeviceBleView: React.FC<DeviceBleViewProps> = ({
  device,
  onScanRealBle,
  onToggleDemoConnection,
  onDisconnect,
  onSelectFormat,
  onSimulateButtonPress,
  onQueueOfflineDemoEvent,
  onSyncPendingEvents,
  onHardwareTest,
}) => {
  const [activeLedColor, setActiveLedColor] = useState('#8B5CF6');
  const [testFeedback, setTestFeedback] = useState<string | null>(null);

  const isConnected =
    device.connectionStatus === 'connected_real_ble' ||
    device.connectionStatus === 'connected_demo';

  const triggerTest = (component: 'vibrator' | 'led' | 'buzzer') => {
    onHardwareTest(component);
    if (component === 'led') {
      setActiveLedColor('#10B981');
      setTestFeedback('Comando 0x12 enviado: Destello de verificación en LED RGB del módulo.');
      setTimeout(() => setActiveLedColor('#8B5CF6'), 2200);
    } else if (component === 'vibrator') {
      if ('vibrate' in navigator) {
        navigator.vibrate([180, 80, 180]);
      }
      setTestFeedback('Comando 0x11 enviado: Pulso háptico de 250ms en motor vibrador.');
    } else if (component === 'buzzer') {
      // No emitir sonido en los altavoces del navegador del usuario. El comando se envía directamente al hardware ESP32.
      setTestFeedback('Comando GATT 0x13 transmitido: El buzzer físico del módulo ESP32 emite su tono sin alterar el altavoz de tu teléfono.');
    }
    setTimeout(() => setTestFeedback(null), 4000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#1E1B4B] dark:text-white">
            Mi dispositivo · NEXA Core (ESP32 BLE)
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
            Módulo electrónico universal con microcontrolador ESP32, botón físico de dos niveles,
            motor vibrador, LED, buzzer, unidad inercial (IMU) y batería LiPo protegida.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {device.connectionStatus === 'connected_real_ble' && (
            <span className="px-3.5 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 text-emerald-800 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
              <BluetoothConnected className="w-4 h-4" />
              Hardware ESP32 Conectado (BLE Real)
            </span>
          )}
          {device.connectionStatus === 'connected_demo' && (
            <span className="px-3.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 text-amber-900 dark:text-amber-300 text-xs font-semibold flex items-center gap-2">
              <FlaskConical className="w-4 h-4" />
              MODO DEMOSTRACIÓN ACTIVO (Sin hardware físico)
            </span>
          )}
          {device.connectionStatus === 'disconnected' && (
            <span className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold flex items-center gap-2">
              <BluetoothOff className="w-4 h-4" />
              Sin dispositivo vinculado
            </span>
          )}
        </div>
      </div>

      {device.connectionError && (
        <div className="rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-800 p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs text-amber-900 dark:text-amber-200 space-y-1">
            <p className="font-bold">Estado del escaneo Bluetooth Low Energy (BLE):</p>
            <p>{device.connectionError}</p>
            <p className="text-[11px] opacity-85">
              Nota: NEXA nunca simula que existe un ESP32 físico conectado si no hay hardware real.
              Si aún no dispones de la placa física, puedes activar el{' '}
              <strong>Modo de Demostración</strong> claramente identificado.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-5">
          <div className="rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-5 sm:p-6 space-y-5 shadow-md">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="w-36 h-36 rounded-3xl bg-[#1E1B4B] border border-[#8B5CF6]/40 flex items-center justify-center shrink-0 shadow-inner">
                <WearableIllustration
                  format={device.selectedFormat}
                  isActive={isConnected}
                  ledColor={activeLedColor}
                  className="w-28 h-28"
                />
              </div>

              <div className="flex-1 space-y-3 text-center sm:text-left">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C4B5FD]">
                    Un núcleo · Cuatro formatos impresos en 3D
                  </span>
                  <h2 className="font-display text-xl font-bold text-white mt-0.5">
                    {device.deviceName}
                  </h2>
                  <p className="text-xs text-[#EDE9FE]/80">
                    {device.connectionStatus === 'connected_real_ble'
                      ? `Conectado vía Web Bluetooth · Firmware ${device.firmwareVersion}`
                      : device.connectionStatus === 'connected_demo'
                      ? 'Simulador interactivo de protocolo ESP32 BLE (Sin contactar automáticamente a terceros)'
                      : 'Listo para buscar dispositivos cercanos vía Bluetooth Low Energy'}
                  </p>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-1">
                  <div className="rounded-xl bg-[#1E1B4B] p-2.5 border border-[#8B5CF6]/30">
                    <p className="text-[10px] text-[#C4B5FD]">Batería LiPo</p>
                    <p className="font-mono-tabular text-xs font-bold text-white mt-0.5 flex items-center justify-center sm:justify-start gap-1">
                      <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                      {isConnected && device.batteryLevel !== null
                        ? `${device.batteryLevel}%`
                        : '—'}
                    </p>
                  </div>

                  <div className="rounded-xl bg-[#1E1B4B] p-2.5 border border-[#8B5CF6]/30">
                    <p className="text-[10px] text-[#C4B5FD]">Última sincr.</p>
                    <p className="font-mono-tabular text-xs font-bold text-white mt-0.5">
                      {device.lastSyncAt
                        ? new Date(device.lastSyncAt).toLocaleTimeString('es-EC', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'Sin sincr.'}
                    </p>
                  </div>

                  <div className="rounded-xl bg-[#1E1B4B] p-2.5 border border-[#8B5CF6]/30">
                    <p className="text-[10px] text-[#C4B5FD]">Cola offline</p>
                    <p className="font-mono-tabular text-xs font-bold text-white mt-0.5">
                      {device.pendingEvents.filter((e) => !e.synced).length} pendientes
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5 pt-1">
                  <button
                    type="button"
                    onClick={onScanRealBle}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-md"
                  >
                    <Bluetooth className="w-4 h-4 text-white" />
                    <span>Buscar ESP32 cercano (BLE Real)</span>
                  </button>

                  {!isConnected ? (
                    <button
                      type="button"
                      onClick={onToggleDemoConnection}
                      className="min-h-[42px] px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer border border-white/10"
                    >
                      <FlaskConical className="w-4 h-4 text-[#C4B5FD]" />
                      <span>Iniciar Modo Demostración</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={onDisconnect}
                      className="min-h-[42px] px-4 py-2 rounded-xl bg-red-950/60 hover:bg-red-900/70 border border-red-500/40 text-red-200 text-xs font-semibold cursor-pointer"
                    >
                      Desvincular ({device.isDemoMode ? 'Demo' : 'BLE'})
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-[#8B5CF6]/20 space-y-2.5">
              <p className="text-xs font-semibold text-[#EDE9FE]">
                Selecciona el formato de carcasa impresa en 3D donde está alojado tu NEXA Core:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {WEARABLE_FORMATS.map((fmt) => {
                  const selected = device.selectedFormat === fmt.id;
                  return (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => onSelectFormat(fmt.id)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                        selected
                          ? 'bg-[#8B5CF6]/25 border-[#8B5CF6] shadow-md ring-1 ring-[#8B5CF6]'
                          : 'bg-[#1E1B4B] border-[#8B5CF6]/30 hover:border-[#8B5CF6]'
                      }`}
                    >
                      <p className="font-display text-xs font-bold text-white">
                        {fmt.name}
                      </p>
                      <p className="text-[11px] text-[#C4B5FD] font-medium">{fmt.concept}</p>
                      <p className="text-[10px] text-[#EDE9FE]/70 mt-1 line-clamp-2">
                        {fmt.formatLabel}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-5 sm:p-6 space-y-4 shadow-md">
            <div className="flex items-center justify-between border-b border-[#8B5CF6]/20 pb-3">
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Pruebas de actuadores y botón físico de dos niveles
                </h3>
                <p className="text-xs text-[#C4B5FD]">
                  {device.isDemoMode
                    ? 'Eventos simulados en Modo Demostración (sin contactar a personas reales).'
                    : 'Envía tramas de prueba GATT al dispositivo conectado.'}
                </p>
              </div>
            </div>

            {/* Explicación destacada sobre el botón físico del dispositivo */}
            <div className="rounded-2xl bg-indigo-950/70 border border-[#8B5CF6]/50 p-4 space-y-2.5">
              <div className="flex items-center gap-2 text-white font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Funcionamiento del Botón Físico Wearable (ESP32 · Modo Silencioso)</span>
              </div>
              <p className="text-xs text-[#EDE9FE]/90 leading-relaxed">
                Cuando presiones el <strong>botón físico</strong> en tu dispositivo ESP32 (clip, anillo, colgante o pulsera), la alerta de emergencia se enviará instantáneamente a todos tus contactos registrados junto con tu <strong>ubicación GPS en tiempo real</strong>.
              </p>
              <div className="rounded-xl bg-emerald-950/60 border border-emerald-500/40 p-2.5 flex items-start gap-2 text-[11px] text-emerald-200">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  <strong>A tu teléfono NO le sonará la alarma:</strong> Tu celular se mantendrá en absoluto silencio y sin delatarte ante un agresor. La alarma acústica potente y moderna sonará en los teléfonos de tus <strong>contactos autorizados</strong> para avisarles de inmediato.
                </span>
              </div>
            </div>

            {testFeedback && (
              <div className="rounded-xl bg-[#1E1B4B] border border-[#8B5CF6] p-3 text-xs font-medium text-[#EDE9FE]">
                {testFeedback}
              </div>
            )}

            <div className="flex flex-wrap items-center gap-2.5">
              {/* Botón para probar el nuevo sonido moderno de alerta */}
              <button
                type="button"
                onClick={() => testSirenBriefly(2.5)}
                className="px-3.5 py-2 rounded-xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/30 border border-[#8B5CF6]/40 text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm transition-colors"
                title="Escuchar una muestra del nuevo sonido de alerta fuerte y moderno que sonará en el teléfono de tus contactos"
              >
                <Volume2 className="w-4 h-4 text-amber-400" />
                <span>Probar Sonido de Alerta de Destinatario (Nuevo Tono Moderno)</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                disabled={!isConnected}
                onClick={() => triggerTest('vibrator')}
                className="min-h-[44px] px-3 py-2.5 rounded-xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/30 border border-[#8B5CF6]/30 text-white text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer transition-colors"
              >
                <Waves className="w-4 h-4 text-[#C4B5FD]" />
                <span>Probar Vibración Háptica</span>
              </button>

              <button
                type="button"
                disabled={!isConnected}
                onClick={() => triggerTest('led')}
                className="min-h-[44px] px-3 py-2.5 rounded-xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/30 border border-[#8B5CF6]/30 text-white text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer transition-colors"
              >
                <Lightbulb className="w-4 h-4 text-[#C4B5FD]" />
                <span>Probar LED de Estado</span>
              </button>

              <button
                type="button"
                disabled={!isConnected}
                onClick={() => triggerTest('buzzer')}
                className="min-h-[44px] px-3 py-2.5 rounded-xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/30 border border-[#8B5CF6]/30 text-white text-xs font-semibold flex items-center justify-center gap-2 disabled:opacity-40 cursor-pointer transition-colors"
              >
                <Volume2 className="w-4 h-4 text-[#C4B5FD]" />
                <span>Probar Buzzer Interno</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-[#8B5CF6]/20">
              <button
                type="button"
                disabled={!isConnected}
                onClick={() => onSimulateButtonPress('short')}
                className="p-3.5 rounded-2xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/25 border border-[#8B5CF6]/30 text-left space-y-1 disabled:opacity-40 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-xs font-bold text-white">
                    Nivel 1: Pulsación Corta (0x01)
                  </span>
                  <Radio className="w-4 h-4 text-[#8B5CF6]" />
                </div>
                <p className="text-[11px] text-[#EDE9FE]/80">
                  Vibración de confirmación silenciosa y aviso preventivo o check-in de Ruta Segura.
                </p>
              </button>

              <button
                type="button"
                disabled={!isConnected}
                onClick={() => onSimulateButtonPress('long')}
                className="p-3.5 rounded-2xl bg-red-950/50 hover:bg-red-900/60 border-2 border-red-500/60 text-left space-y-1 disabled:opacity-40 cursor-pointer transition-colors shadow-lg active:scale-95"
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-xs font-bold text-red-200 flex items-center gap-1.5">
                    <AlertOctagon className="w-4 h-4 text-red-400" />
                    Simular Pulsación de Botón Físico (ESP32)
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                    Silencioso
                  </span>
                </div>
                <p className="text-[11px] text-red-200/90 leading-relaxed">
                  Activa exactamente el mismo evento que presionar el botón físico en el ESP32: envía la alerta SOS silenciosamente con tu GPS a tus contactos y hace sonar su alarma.
                </p>
              </button>
            </div>

            <div className="pt-2 border-t border-[#8B5CF6]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs">
                <p className="font-semibold text-white">
                  Memoria temporal de eventos desconectados (NVS Ring Buffer)
                </p>
                <p className="text-[11px] text-[#C4B5FD]">
                  Guarda pulsaciones cuando el teléfono no está cerca y las sincroniza al
                  reconectar.
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={onQueueOfflineDemoEvent}
                  className="px-3.5 py-2 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/30 hover:border-[#8B5CF6] text-white text-xs font-medium cursor-pointer transition-colors"
                >
                  + Encolar evento local
                </button>
                <button
                  type="button"
                  onClick={onSyncPendingEvents}
                  disabled={device.pendingEvents.filter((e) => !e.synced).length === 0}
                  className="px-3.5 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-md transition-transform active:scale-95"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Sincronizar ahora</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-3xl bg-[#0F172A] text-[#F8FAFC] p-5 sm:p-6 space-y-4 border border-slate-800">
          <div className="flex items-center gap-2.5 border-b border-white/10 pb-3">
            <Cpu className="w-5 h-5 text-[#C4B5FD] shrink-0" />
            <div>
              <h3 className="font-display text-sm font-bold text-white">
                Especificación Técnica BLE (ESP32 Firmware)
              </h3>
              <p className="text-[11px] text-[#C4B5FD]">
                Documentación de UUIDs provisionales y protocolo de paquetes
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-amber-500/10 border border-amber-400/30 p-3 text-[11px] text-amber-200 leading-relaxed">
            {PROVISIONAL_BLE_SPEC.statusNote}
          </div>

          <div className="space-y-2 text-xs">
            <div className="rounded-xl bg-white/5 p-3 border border-white/10">
              <p className="text-[10px] text-slate-400 uppercase">Prefijo de anuncio BLE</p>
              <p className="font-mono-tabular text-xs text-[#C4B5FD] mt-0.5">
                {PROVISIONAL_BLE_SPEC.deviceNamePrefix}XXXX
              </p>
            </div>

            <div className="rounded-xl bg-white/5 p-3 border border-white/10">
              <p className="text-[10px] text-slate-400 uppercase">
                Primary Service UUID (Provisional)
              </p>
              <p className="font-mono-tabular text-[11px] text-white mt-0.5 break-all">
                {PROVISIONAL_BLE_SPEC.primaryServiceUuid}
              </p>
            </div>

            <div className="rounded-xl bg-white/5 p-3 border border-white/10">
              <p className="text-[10px] text-slate-400 uppercase">
                Battery Service UUID (Estándar SIG 0x180F)
              </p>
              <p className="font-mono-tabular text-[11px] text-white mt-0.5 break-all">
                {PROVISIONAL_BLE_SPEC.batteryServiceUuid}
              </p>
            </div>
          </div>

          <div className="space-y-2.5">
            <p className="text-xs font-semibold text-[#C4B5FD]">
              Características GATT y Comandos de Confirmación:
            </p>
            {PROVISIONAL_BLE_SPEC.characteristics.map((char) => (
              <div
                key={char.uuid}
                className="rounded-xl bg-white/5 p-3 border border-white/10 space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono-tabular text-[11px] font-bold text-white">
                    {char.name}
                  </span>
                  <span className="text-[10px] text-[#C4B5FD] font-mono-tabular">
                    {char.properties}
                  </span>
                </div>
                <p className="font-mono-tabular text-[10px] text-slate-400 break-all">
                  UUID: {char.uuid}
                </p>
                <p className="text-[11px] text-slate-300 leading-relaxed pt-0.5">
                  {char.payloadSpec}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
