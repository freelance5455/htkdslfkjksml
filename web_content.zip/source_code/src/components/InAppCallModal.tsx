import React, { useState, useEffect, useRef } from 'react';
import { playCallEndedTone } from '../utils/phoneRingtone';
import {
  Mic,
  MicOff,
  Phone,
  PhoneCall,
  PhoneOff,
  Radio,
  Shield,
  ShieldAlert,
  Smartphone,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface InAppCallModalProps {
  contact: {
    name: string;
    phone: string;
    relationship?: string;
  };
  currentUser: {
    fullName: string;
    phone: string;
  };
  isSosEmergency?: boolean;
  initialCallId?: string;
  isIncomingAnswer?: boolean;
  onClose: () => void;
  onCallFinished?: (durationSeconds: number) => void;
}

export const InAppCallModal: React.FC<InAppCallModalProps> = ({
  contact,
  currentUser,
  isSosEmergency = false,
  initialCallId,
  isIncomingAnswer = false,
  onClose,
  onCallFinished,
}) => {
  const [callId, setCallId] = useState<string>(
    initialCallId || `call_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`
  );
  const [callState, setCallState] = useState<'calling' | 'connected' | 'ended'>(
    isIncomingAnswer ? 'connected' : 'calling'
  );
  const [callSeconds, setCallSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);
  const [micVolumeLevel, setMicVolumeLevel] = useState<number>(0);
  const [peerConnected, setPeerConnected] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>(
    isIncomingAnswer ? 'Conectando audio cifrado...' : 'Llamando... Esperando respuesta'
  );

  const localStreamRef = useRef<MediaStream | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const ringbackIntervalRef = useRef<any>(null);
  const pollIntervalRef = useRef<any>(null);
  const hasEndedRef = useRef<boolean>(false);

  // 1. Play realistic outgoing ringback tone ("tuuuut... tuuuut...") for caller
  useEffect(() => {
    if (isIncomingAnswer || callState !== 'calling') return;

    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const playRingback = () => {
        if (!audioContextRef.current || callState !== 'calling' || hasEndedRef.current) return;
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(425, now);

        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(0.08, now + 0.05);
        gain.gain.setValueAtTime(0.08, now + 1.2);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.3);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 1.35);
      };

      playRingback();
      ringbackIntervalRef.current = setInterval(playRingback, 4000);
    } catch {}

    return () => {
      if (ringbackIntervalRef.current) clearInterval(ringbackIntervalRef.current);
    };
  }, [isIncomingAnswer, callState]);

  // 2. Server signaling: Register call and poll status
  useEffect(() => {
    hasEndedRef.current = false;

    // Caller initiates call on server
    if (!isIncomingAnswer) {
      fetch('/api/calls/initiate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: callId,
          callerPhone: currentUser.phone,
          callerName: currentUser.fullName,
          recipientPhone: contact.phone,
          recipientName: contact.name,
          isSosEmergency,
        }),
      }).catch(() => {});
    }

    // Polling loop to check if answered, rejected, or ended
    pollIntervalRef.current = setInterval(async () => {
      if (hasEndedRef.current) return;

      try {
        const res = await fetch(`/api/calls/status?callId=${encodeURIComponent(callId)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.call) {
            if (data.call.status === 'connected' && callState === 'calling') {
              if (ringbackIntervalRef.current) clearInterval(ringbackIntervalRef.current);
              setCallState('connected');
              setStatusMessage('Llamada conectada en tiempo real');
            } else if (data.call.status === 'ended' || data.call.status === 'rejected') {
              handleTerminateCall(false);
            }
          }
        }
      } catch {}
    }, 1200);

    return () => {
      if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    };
  }, [callId, currentUser.phone, currentUser.fullName, contact.phone, contact.name, isIncomingAnswer, callState]);

  // 3. Audio & WebRTC setup when connected
  useEffect(() => {
    if (callState !== 'connected') return;

    let isMounted = true;

    // Setup local microphone
    const startAudio = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
          video: false,
        });

        if (!isMounted) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        localStreamRef.current = stream;

        // Setup Web Audio Analyser for realistic VU meter
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            const source = ctx.createMediaStreamSource(stream);
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 64;
            source.connect(analyser);
            analyserRef.current = analyser;

            const bufferLength = analyser.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);

            const updateMeter = () => {
              if (!analyserRef.current || hasEndedRef.current) return;
              analyserRef.current.getByteFrequencyData(dataArray);
              let sum = 0;
              for (let i = 0; i < bufferLength; i++) {
                sum += dataArray[i];
              }
              const avg = sum / bufferLength;
              setMicVolumeLevel(Math.min(100, Math.round((avg / 128) * 100)));
              animationFrameRef.current = requestAnimationFrame(updateMeter);
            };

            updateMeter();
          }
        } catch {}

        // Setup WebRTC PeerConnection
        const pc = new RTCPeerConnection({
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
          ],
        });
        peerConnectionRef.current = pc;

        // Add local mic track to WebRTC
        stream.getTracks().forEach((track) => pc.addTrack(track, stream));

        // When remote audio stream arrives
        pc.ontrack = (event) => {
          if (remoteAudioRef.current && event.streams[0]) {
            remoteAudioRef.current.srcObject = event.streams[0];
            remoteAudioRef.current.play().catch(() => {});
            setPeerConnected(true);
            setStatusMessage('Audio bidireccional activo');
          }
        };

        // ICE candidate exchange via server
        pc.onicecandidate = (event) => {
          if (event.candidate) {
            fetch('/api/calls/signal', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                callId,
                fromPhone: currentUser.phone,
                data: { type: 'candidate', candidate: event.candidate },
              }),
            }).catch(() => {});
          }
        };

        // If caller: create offer; if recipient: listen for offer
        if (!isIncomingAnswer) {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await fetch('/api/calls/signal', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              callId,
              fromPhone: currentUser.phone,
              data: { type: 'offer', sdp: offer.sdp },
            }),
          });
        }

        // Signal polling loop for remote SDP & ICE
        const signalInterval = setInterval(async () => {
          if (!peerConnectionRef.current || hasEndedRef.current) return;
          try {
            const res = await fetch(
              `/api/calls/signals?callId=${encodeURIComponent(callId)}&myPhone=${encodeURIComponent(
                currentUser.phone
              )}`
            );
            if (res.ok) {
              const data = await res.json();
              if (data.signals && Array.isArray(data.signals)) {
                for (const sig of data.signals) {
                  if (sig.data.type === 'offer' && isIncomingAnswer && !pc.currentRemoteDescription) {
                    await pc.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: sig.data.sdp }));
                    const answer = await pc.createAnswer();
                    await pc.setLocalDescription(answer);
                    await fetch('/api/calls/signal', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        callId,
                        fromPhone: currentUser.phone,
                        data: { type: 'answer', sdp: answer.sdp },
                      }),
                    });
                  } else if (sig.data.type === 'answer' && !isIncomingAnswer && !pc.currentRemoteDescription) {
                    await pc.setRemoteDescription(new RTCSessionDescription({ type: 'answer', sdp: sig.data.sdp }));
                  } else if (sig.data.type === 'candidate') {
                    try {
                      await pc.addIceCandidate(new RTCIceCandidate(sig.data.candidate));
                    } catch {}
                  }
                }
              }
            }
          } catch {}
        }, 1000);

        return () => {
          clearInterval(signalInterval);
        };
      } catch (err) {
        console.warn('Microphone access denied or audio unavailable:', err);
        setStatusMessage('Llamada conectada en modo seguro');
      }
    };

    startAudio();

    return () => {
      isMounted = false;
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((t) => t.stop());
        localStreamRef.current = null;
      }
      if (peerConnectionRef.current) {
        peerConnectionRef.current.close();
        peerConnectionRef.current = null;
      }
    };
  }, [callState, callId, currentUser.phone, isIncomingAnswer]);

  // 4. Timer for connected call
  useEffect(() => {
    let timer: any = null;
    if (callState === 'connected') {
      timer = setInterval(() => {
        setCallSeconds((s) => s + 1);
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [callState]);

  // Terminate call handler
  const handleTerminateCall = (notifyServer: boolean = true) => {
    if (hasEndedRef.current) return;
    hasEndedRef.current = true;

    setCallState('ended');
    playCallEndedTone();

    if (ringbackIntervalRef.current) clearInterval(ringbackIntervalRef.current);
    if (pollIntervalRef.current) clearInterval(pollIntervalRef.current);
    if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);

    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => t.stop());
      localStreamRef.current = null;
    }

    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }

    if (notifyServer) {
      fetch('/api/calls/end', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callId, reason: 'user_ended' }),
      }).catch(() => {});
    }

    if (onCallFinished) {
      onCallFinished(callSeconds);
    }

    setTimeout(() => {
      onClose();
    }, 700);
  };

  const handleToggleMute = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    } else {
      setIsMuted(!isMuted);
    }
  };

  const handleToggleSpeaker = () => {
    setIsSpeaker(!isSpeaker);
    if (remoteAudioRef.current) {
      remoteAudioRef.current.muted = isSpeaker; // toggle
    }
  };

  const handleCellularFallback = () => {
    handleTerminateCall(true);
    const cleanPhone = contact.phone.replace(/\D/g, '');
    window.location.href = `tel:${cleanPhone}`;
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      {/* Hidden HTML audio element for remote stream output */}
      <audio ref={remoteAudioRef} autoPlay playsInline />

      <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#1E1B4B] via-[#161338] to-[#0A0818] border-2 border-[#8B5CF6]/50 text-white shadow-2xl p-6 sm:p-7 flex flex-col items-center text-center space-y-5 relative overflow-hidden">
        
        {/* Header Security Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/15 text-[11px] font-medium text-[#C4B5FD]">
          <Shield className="w-3.5 h-3.5 text-emerald-400" />
          <span>Llamada de Voz Directa NEXA</span>
        </div>

        {/* Contact Avatar & Name */}
        <div className="space-y-3">
          <div className="relative mx-auto w-24 h-24 rounded-full bg-gradient-to-tr from-[#312E81] to-[#6366F1] border-4 border-[#8B5CF6]/60 flex items-center justify-center shadow-lg">
            {callState === 'calling' && (
              <span className="absolute inset-0 rounded-full border-2 border-[#8B5CF6] animate-ping opacity-60" />
            )}
            {callState === 'connected' && (
              <span
                className="absolute inset-0 rounded-full border-2 border-emerald-400/50 transition-transform duration-100"
                style={{ transform: `scale(${1 + micVolumeLevel / 180})` }}
              />
            )}
            <span className="text-3xl font-extrabold text-white">
              {contact.name.charAt(0).toUpperCase()}
            </span>
          </div>

          <div>
            <h3 className="font-display text-xl font-bold">{contact.name}</h3>
            <p className="font-mono-tabular text-xs text-[#C4B5FD] mt-0.5">{contact.phone}</p>
            {contact.relationship && (
              <span className="text-[10px] uppercase tracking-wider font-semibold text-[#A78BFA] bg-white/5 px-2 py-0.5 rounded-md mt-1 inline-block">
                {contact.relationship}
              </span>
            )}
          </div>
        </div>

        {/* Call State / Duration / Audio visualizer */}
        <div className="space-y-2 w-full">
          {callState === 'calling' && (
            <div className="space-y-2">
              <p className="text-xs font-semibold text-amber-300 animate-pulse flex items-center justify-center gap-1.5">
                <PhoneCall className="w-4 h-4 animate-bounce" />
                <span>{statusMessage}</span>
              </p>
              <p className="text-[11px] text-[#EDE9FE]/60">
                El teléfono o laptop de tu contacto está timbrando ahora...
              </p>
            </div>
          )}

          {callState === 'connected' && (
            <div className="space-y-3">
              <span className="text-2xl font-mono tabular-nums font-bold text-emerald-400">
                {formatTimer(callSeconds)}
              </span>

              {/* Live interactive audio spectrum bars reacting to voice */}
              <div className="flex items-center justify-center gap-1.5 h-8">
                {[14, 24, 18, 30, 22, 16, 26, 20].map((baseH, idx) => {
                  const dynamicH = Math.max(6, Math.min(32, baseH * (1 + micVolumeLevel / 50)));
                  return (
                    <span
                      key={idx}
                      className="w-1.5 bg-gradient-to-t from-[#8B5CF6] to-emerald-400 rounded-full transition-all duration-75"
                      style={{ height: `${dynamicH}px` }}
                    />
                  );
                })}
              </div>

              <p className="text-[11px] text-emerald-300/90 font-medium flex items-center justify-center gap-1">
                <Radio className="w-3 h-3 animate-pulse" />
                <span>Audio activo en ambos dispositivos</span>
              </p>
            </div>
          )}

          {callState === 'ended' && (
            <p className="text-xs font-medium text-slate-400">Llamada finalizada</p>
          )}
        </div>

        {/* Controls row */}
        <div className="flex items-center justify-center gap-4 w-full pt-1">
          {/* Mute */}
          <button
            type="button"
            onClick={handleToggleMute}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              isMuted
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-white/10 border-white/15 text-white hover:bg-white/20'
            }`}
            title={isMuted ? 'Activar micrófono' : 'Silenciar mi micrófono'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* End Call Button */}
          <button
            type="button"
            onClick={() => handleTerminateCall(true)}
            className="p-4 rounded-2xl bg-red-600 hover:bg-red-700 text-white shadow-lg active:scale-95 transition-all cursor-pointer shadow-red-900/50"
            title="Finalizar llamada"
          >
            <PhoneOff className="w-6 h-6" />
          </button>

          {/* Speaker */}
          <button
            type="button"
            onClick={handleToggleSpeaker}
            className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
              isSpeaker
                ? 'bg-[#8B5CF6]/30 border-[#8B5CF6] text-white'
                : 'bg-white/10 border-white/15 text-white/70 hover:bg-white/20'
            }`}
            title="Altavoz"
          >
            {isSpeaker ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>

        {/* Fallback to GSM carrier phone call */}
        <div className="w-full pt-2 border-t border-white/10">
          <button
            type="button"
            onClick={handleCellularFallback}
            className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs text-[#EDE9FE]/80 hover:text-white flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Smartphone className="w-3.5 h-3.5 text-[#C4B5FD]" />
            <span>Pasar a llamada telefónica celular estándar</span>
          </button>
        </div>

      </div>
    </div>
  );
};
