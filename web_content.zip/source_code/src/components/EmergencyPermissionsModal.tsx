import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  ExternalLink,
  MapPin,
  Play,
  RotateCcw,
  ShieldAlert,
  Smartphone,
  Sparkles,
  Sun,
  Volume2,
  VolumeX,
  Vibrate,
  X,
  Zap,
} from 'lucide-react';
import {
  getEmergencyPermissionsStatus,
  requestNotificationPermission,
} from '../utils/emergencyAlertService';
import { startEmergencySiren, stopEmergencySiren, testSirenBriefly } from '../utils/emergencySiren';

interface EmergencyPermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSimulateIncomingSos: () => void;
}

export const EmergencyPermissionsModal: React.FC<EmergencyPermissionsModalProps> = ({
  isOpen,
  onClose,
  onSimulateIncomingSos,
}) => {
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission | 'unsupported'>('default');
  const [wakeLockSupported, setWakeLockSupported] = useState(true);
  const [vibrationSupported, setVibrationSupported] = useState(true);
  const [audioSupported, setAudioSupported] = useState(true);
  const [geolocationStatus, setGeolocationStatus] = useState<string>('prompt');
  const [isPlayingTestSound, setIsPlayingTestSound] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    getEmergencyPermissionsStatus().then((status) => {
      setNotificationStatus(status.notifications);
      setWakeLockSupported(status.wakeLockSupported);
      setVibrationSupported(status.vibrationSupported);
      setAudioSupported(status.audioSupported);
    });

    if (typeof navigator !== 'undefined' && 'permissions' in navigator) {
      (navigator as any).permissions
        ?.query({ name: 'geolocation' })
        ?.then((res: any) => {
          setGeolocationStatus(res.state);
        })
        ?.catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRequestNotifications = async () => {
    const result = await requestNotificationPermission();
    setNotificationStatus(result);
  };

  const handleTestSound = () => {
    if (isPlayingTestSound) {
      stopEmergencySiren();
      setIsPlayingTestSound(false);
    } else {
      setIsPlayingTestSound(true);
      testSirenBriefly(3.5);
      setTimeout(() => {
        setIsPlayingTestSound(false);
      }, 3500);
    }
  };

  const handleTestVibration = () => {
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([400, 150, 400, 150, 600]);
      } catch {}
    }
  };

  const handleSimulateAlert = () => {
    onClose();
    onSimulateIncomingSos();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-[#0F1424] text-white border border-[#8B5CF6]/40 shadow-2xl overflow-hidden my-auto">
        {/* Header */}
        <div className="relative bg-gradient-to-br from-[#1E1B4B] via-[#2E1065] to-[#0F1424] p-5 sm:p-6 border-b border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-display text-lg sm:text-xl font-black text-white">
                Permisos y Alertas de Emergencia
              </h2>
              <p className="text-xs text-[#EDE9FE]/75">
                Configuración para recibir alertas audibles, activar pantalla y avisos en segundo plano
              </p>
            </div>
          </div>
        </div>

        {/* Permissions List */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[66vh] overflow-y-auto">
          {/* Permission 1: Notifications */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-bold text-xs text-white">
                <Bell className="w-4 h-4 text-[#8B5CF6]" />
                <span>Notificaciones en Pantalla Bloqueada</span>
              </div>
              {notificationStatus === 'granted' ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Concedido</span>
                </span>
              ) : (
                <span className="text-[11px] font-bold text-amber-400 bg-amber-500/15 px-2 py-0.5 rounded-full border border-amber-500/30">
                  {notificationStatus === 'denied' ? 'Bloqueado' : 'Pendiente'}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Permite despachar notificaciones de alta prioridad inmediatamente cuando alguien envíe una alerta SOS, incluso con la pantalla apagada.
            </p>
            {notificationStatus !== 'granted' && (
              <button
                type="button"
                onClick={handleRequestNotifications}
                className="w-full mt-1 py-2 px-3 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Activar Permiso de Notificaciones
              </button>
            )}
          </div>

          {/* Permission 2: Emergency Sound */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-bold text-xs text-white">
                <Volume2 className="w-4 h-4 text-rose-400" />
                <span>Sonido de Emergencia (Alta Penetración)</span>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" />
                <span>Listo</span>
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Sirena de doble frecuencia (880 Hz / 1250 Hz) a volumen máximo para captar tu atención en caso de peligro real.
            </p>
            <button
              type="button"
              onClick={handleTestSound}
              className={`w-full mt-1 py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                isPlayingTestSound
                  ? 'bg-red-600 hover:bg-red-700 text-white animate-pulse'
                  : 'bg-white/10 hover:bg-white/20 text-[#EDE9FE]'
              }`}
            >
              {isPlayingTestSound ? (
                <>
                  <VolumeX className="w-4 h-4" />
                  <span>Detener Prueba de Sonido</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-emerald-400" />
                  <span>Probar Sonido de Alarma Ahora</span>
                </>
              )}
            </button>
          </div>

          {/* Permission 3: Screen Wake Lock */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-bold text-xs text-white">
                <Sun className="w-4 h-4 text-amber-400" />
                <span>Activación de Pantalla (Screen Wake Lock)</span>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" />
                <span>{wakeLockSupported ? 'Soportado' : 'Estándar'}</span>
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Mantiene la pantalla del teléfono encendida e iluminada al recibir una emergencia, evitando que se apague o bloquee mientras atiendes el llamado.
            </p>
          </div>

          {/* Permission 4: Haptic Vibration */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-bold text-xs text-white">
                <Smartphone className="w-4 h-4 text-purple-400" />
                <span>Vibración Háptica Continua</span>
              </div>
              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" />
                <span>{vibrationSupported ? 'Activo' : 'Opcional'}</span>
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Patrón rítmico de vibración simultánea con el sonido para sentir la alerta aun si el teléfono está en el bolsillo o bolso.
            </p>
            <button
              type="button"
              onClick={handleTestVibration}
              className="w-full mt-1 py-1.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-[#EDE9FE] font-bold text-xs transition-colors cursor-pointer"
            >
              Probar Vibración
            </button>
          </div>

          {/* Permission 5: GPS Location */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 font-bold text-xs text-white">
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>Ubicación Satelital GPS</span>
              </div>
              <span className="text-[11px] font-bold text-emerald-300 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                {geolocationStatus === 'granted' ? 'Habilitado' : 'Al activar SOS'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Permite calcular tus coordenadas satelitales en vivo para enviárselas a tus contactos autorizados junto con el enlace a Google Maps.
            </p>
          </div>

          {/* LIVE SIMULATOR FOR USER VERIFICATION */}
          <div className="rounded-2xl bg-gradient-to-r from-red-950/60 to-[#1E1B4B] border-2 border-red-500/50 p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-red-300">
              <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>Prueba Completa de Alerta de Emergencia</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Simula cómo sonará, vibrará y se desplegará la pantalla de auxilio cuando un contacto de tu red te envíe un SOS real.
            </p>
            <button
              type="button"
              onClick={handleSimulateAlert}
              className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 cursor-pointer"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Simular Llegada de Alerta SOS en Vivo</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-black/50 border-t border-white/10 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-xs cursor-pointer transition-colors"
          >
            Entendido / Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};
