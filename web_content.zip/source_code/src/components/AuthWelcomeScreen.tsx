import React, { useState } from 'react';
import { NexaLogo, WearableIllustration } from './NexaLogo';
import { AppSettings, EmergencyContact, SosMessageConfig, UserAccount, UserCustomRoute } from '../types';
import { DEFAULT_USER_ACCOUNT, WEARABLE_FORMATS } from '../constants';
import {
  AlertOctagon,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Cloud,
  Download,
  Eye,
  EyeOff,
  GraduationCap,
  KeyRound,
  Lock,
  Mail,
  Phone,
  Shield,
  ShieldCheck,
  Smartphone,
  Sparkles,
  UserCheck,
  Users,
} from 'lucide-react';

interface AuthWelcomeScreenProps {
  onAuthenticated: (
    user: UserAccount,
    cloudData?: {
      contacts?: EmergencyContact[];
      customRoutes?: UserCustomRoute[];
      sosConfig?: SosMessageConfig;
      settings?: AppSettings;
    }
  ) => void;
  onOpenDownloadModal?: () => void;
}

export const AuthWelcomeScreen: React.FC<AuthWelcomeScreenProps> = ({
  onAuthenticated,
  onOpenDownloadModal,
}) => {
  // Directly start in 'register' mode as requested ("como cuando vas a entrar a Instagram, te sale registrarte...")
  const [activeTab, setActiveTab] = useState<'register' | 'login'>('register');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessNotice, setAuthSuccessNotice] = useState<string | null>(null);

  // Registration form inputs
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Student selection: "decir si eres estudiante o no"
  const [isStudent, setIsStudent] = useState<boolean>(true);
  const [institution, setInstitution] = useState('');
  const [gradeOrRole, setGradeOrRole] = useState('');
  const [supportRole, setSupportRole] = useState<'familiar' | 'tutor' | 'amigo' | 'contacto_apoyo'>('familiar');

  // Login inputs
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // 1. Handle Registration Submission
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessNotice(null);

    if (fullName.trim().length < 3) {
      setAuthError('Por favor ingresa tus nombres y apellidos completos.');
      return;
    }

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 8) {
      setAuthError('Ingresa un número de celular válido (ej. 0991234567) para recibir y enviar alertas.');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setAuthError('Ingresa un correo electrónico válido.');
      return;
    }

    if (password.length < 5) {
      setAuthError('La contraseña debe tener al menos 5 caracteres.');
      return;
    }

    const roleDescription = isStudent
      ? (gradeOrRole.trim() || 'Estudiante')
      : supportRole === 'familiar'
      ? 'Familiar (Mamá / Papá)'
      : supportRole === 'tutor'
      ? 'Tutor Legal'
      : 'Contacto de Apoyo';

    const newUser: UserAccount = {
      id: `usr_${Date.now()}`,
      fullName: fullName.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      password,
      isStudent,
      roleCategory: isStudent ? 'estudiante' : supportRole,
      institution: isStudent ? (institution.trim() || 'Institución Educativa') : 'Red de Apoyo Familiar',
      gradeOrRole: roleDescription,
      isMinor: false,
      guardianConsentAccepted: true,
      privacyPolicyAccepted: true,
      createdAt: new Date().toISOString(),
    };

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: newUser,
          password,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setAuthSuccessNotice('¡Cuenta creada con éxito! Entrando a tu panel principal...');
        setTimeout(() => {
          onAuthenticated(data.user || newUser);
        }, 400);
      } else {
        setAuthError(data.error || 'No se pudo registrar la cuenta. Inténtalo nuevamente.');
      }
    } catch {
      // Local fallback
      setAuthSuccessNotice('¡Registro completado! Accediendo...');
      setTimeout(() => {
        onAuthenticated(newUser);
      }, 400);
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Handle Login Submission
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessNotice(null);

    if (!loginIdentifier.trim()) {
      setAuthError('Ingresa tu número de celular o correo registrado.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: loginIdentifier.trim(),
          password: loginPassword,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success && data.user) {
        setAuthSuccessNotice('¡Bienvenido de vuelta! Cargando tus contactos y rutas...');
        setTimeout(() => {
          onAuthenticated(data.user, {
            contacts: data.contacts,
            customRoutes: data.customRoutes,
            sosConfig: data.sosConfig,
            settings: data.settings,
          });
        }, 400);
      } else {
        setAuthError(data.error || 'Datos incorrectos. Verifica tu celular/correo.');
      }
    } catch {
      // Offline fallback
      onAuthenticated({
        ...DEFAULT_USER_ACCOUNT,
        phone: loginIdentifier.replace(/\D/g, '') || DEFAULT_USER_ACCOUNT.phone,
        email: loginIdentifier.includes('@') ? loginIdentifier.trim() : DEFAULT_USER_ACCOUNT.email,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Quick demo login to test multi-device
  const handleQuickLoginAs = (role: 'estudiante' | 'mama' | 'alex') => {
    if (role === 'estudiante') {
      onAuthenticated({
        id: 'usr_student_demo',
        fullName: 'Estudiante NEXA',
        email: 'estudiante@nexa.edu.ec',
        phone: '0991234567',
        isStudent: true,
        institution: 'Colegio Nacional',
        gradeOrRole: '3er Bachillerato',
        isMinor: false,
        guardianConsentAccepted: true,
        privacyPolicyAccepted: true,
        createdAt: new Date().toISOString(),
      });
    } else if (role === 'mama') {
      onAuthenticated({
        id: 'usr_mama_demo',
        fullName: 'Mamá (Contacto Tutor)',
        email: 'mama@familia.ec',
        phone: '0991248830',
        isStudent: false,
        roleCategory: 'familiar',
        institution: 'Familia',
        gradeOrRole: 'Madre / Contacto de Emergencia',
        isMinor: false,
        guardianConsentAccepted: true,
        privacyPolicyAccepted: true,
        createdAt: new Date().toISOString(),
      });
    } else {
      onAuthenticated({
        id: 'usr_alex_demo',
        fullName: 'Alex (Amigo NEXA)',
        email: 'alex@amigo.ec',
        phone: '0987654322',
        isStudent: true,
        institution: 'Colegio Nacional',
        gradeOrRole: 'Amigo / Red de Apoyo',
        isMinor: false,
        guardianConsentAccepted: true,
        privacyPolicyAccepted: true,
        createdAt: new Date().toISOString(),
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#0C0A1A] text-white flex flex-col justify-between relative overflow-hidden selection:bg-[#8B5CF6] selection:text-white">
      {/* Background radial gradients */}
      <div
        className="pointer-events-none absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full opacity-20 blur-3xl"
        style={{ background: 'radial-gradient(circle, #8B5CF6 0%, transparent 70%)' }}
      />
      <div
        className="pointer-events-none absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full opacity-15 blur-3xl"
        style={{ background: 'radial-gradient(circle, #38BDF8 0%, transparent 70%)' }}
      />

      {/* Header */}
      <header className="w-full max-w-6xl mx-auto flex items-center justify-between gap-4 px-6 py-4 border-b border-white/10 z-10">
        <NexaLogo variant="horizontal" theme="dark" size="sm" showTagline={false} />
        
        <div className="flex items-center gap-2 sm:gap-3">
          {onOpenDownloadModal && (
            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="px-3 sm:px-4 py-1.5 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:brightness-110 border border-white/20 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
            >
              <Download className="w-3.5 h-3.5 text-amber-300" />
              <span>Descargar App</span>
            </button>
          )}

          <div className="flex items-center bg-black/40 border border-white/10 rounded-xl p-1 text-xs">
            <button
              type="button"
              onClick={() => setActiveTab('register')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-[#8B5CF6] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Registrarse
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('login')}
              className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                activeTab === 'login'
                  ? 'bg-[#8B5CF6] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Iniciar sesión
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <main className="w-full max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center flex-1 z-10">
        
        {/* Left Column: Visual branding and description */}
        <div className="lg:col-span-6 space-y-5 text-center lg:text-left">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-xs font-bold text-[#C4B5FD]">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Red de Seguridad y Alerta Inmediata</span>
          </div>

          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
            Regístrate en NEXA. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#C4B5FD] via-[#A78BFA] to-white">
              Seguridad rápida e instantánea.
            </span>
          </h1>

          <p className="text-sm text-[#EDE9FE]/80 max-w-lg mx-auto lg:mx-0 leading-relaxed">
            Ingresa tus datos y especifica si eres <strong>estudiante</strong> o <strong>familiar/contacto de apoyo</strong>. Al registrarte tendrás acceso inmediato a tu botón de emergencia SOS, rutas seguras, llamadas directas y red de contactos.
          </p>

          <div className="hidden sm:grid grid-cols-2 gap-3 pt-2 max-w-md mx-auto lg:mx-0">
            <div className="rounded-2xl bg-white/5 border border-white/10 p-3.5 space-y-1">
              <div className="flex items-center gap-2 text-white font-bold text-xs">
                <AlertOctagon className="w-4 h-4 text-red-400" />
                <span>Botón SOS 1-Toque</span>
              </div>
              <p className="text-[11px] text-[#EDE9FE]/70">
                Alerta inmediata y silenciosa en tu celular, potente en el de tus contactos.
              </p>
            </div>

            <div className="rounded-2xl bg-white/5 border border-white/10 p-3.5 space-y-1">
              <div className="flex items-center gap-2 text-white font-bold text-xs">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Llamadas Directas</span>
              </div>
              <p className="text-[11px] text-[#EDE9FE]/70">
                Llama desde tu celular a la laptop o entre dispositivos con timbrado real.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Registration Card (Instagram style with custom NEXA fields) */}
        <div className="lg:col-span-6 max-w-md w-full mx-auto">
          <div className="rounded-3xl bg-[#161338]/90 backdrop-blur-xl border border-[#8B5CF6]/40 p-6 sm:p-7 shadow-2xl relative">
            
            {/* Header of Form */}
            <div className="text-center space-y-1.5 pb-3 border-b border-white/10">
              <h2 className="font-display text-xl font-black text-white">
                {activeTab === 'register' ? 'Crear Cuenta en NEXA' : 'Iniciar Sesión'}
              </h2>
              <p className="text-xs text-[#EDE9FE]/75">
                {activeTab === 'register'
                  ? 'Completa tus datos para ingresar al botón de emergencia y contactos'
                  : 'Ingresa con tu número de celular o correo electrónico'}
              </p>
            </div>

            {/* Error or Success notification */}
            {authError && (
              <div className="mt-4 rounded-xl bg-red-950/70 border border-red-500/60 p-3 text-xs text-red-200">
                {authError}
              </div>
            )}

            {authSuccessNotice && (
              <div className="mt-4 rounded-xl bg-emerald-950/70 border border-emerald-500/60 p-3 text-xs text-emerald-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{authSuccessNotice}</span>
              </div>
            )}

            {/* FORM: REGISTRO (Initial screen as requested by user) */}
            {activeTab === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="mt-4 space-y-3.5">
                
                {/* 1. Nombres y Apellidos */}
                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Nombres y Apellidos *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ej. Carlos Andrade"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6]"
                  />
                </div>

                {/* 2. Número de Celular */}
                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Número de Celular *
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0991234567 o +593..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6]"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Necesario para enviar/recibir alertas SOS y llamadas entre dispositivos.
                  </span>
                </div>

                {/* 3. Correo Electrónico */}
                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Correo Electrónico *
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="tunombre@correo.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6]"
                    />
                  </div>
                </div>

                {/* 4. Contraseña */}
                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Contraseña *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Crea una contraseña segura"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6] focus:ring-1 focus:ring-[#8B5CF6]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-white cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* 5. ¿ERES ESTUDIANTE O NO? (Selección obligatoria requerida por el usuario) */}
                <div className="pt-1 space-y-2">
                  <label className="block text-xs font-black text-[#C4B5FD] uppercase tracking-wider">
                    ¿Eres estudiante o no? *
                  </label>

                  <div className="grid grid-cols-2 gap-2.5">
                    {/* Opción A: Sí, soy estudiante */}
                    <button
                      type="button"
                      onClick={() => setIsStudent(true)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isStudent
                          ? 'bg-[#8B5CF6]/30 border-[#8B5CF6] ring-2 ring-[#8B5CF6]'
                          : 'bg-black/30 border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <GraduationCap className={`w-5 h-5 ${isStudent ? 'text-[#C4B5FD]' : 'text-slate-400'}`} />
                        <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${isStudent ? 'border-[#8B5CF6] bg-[#8B5CF6]' : 'border-slate-500'}`}>
                          {isStudent && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </span>
                      </div>
                      <div>
                        <p className="font-bold text-xs text-white">Sí, soy estudiante</p>
                        <p className="text-[10px] text-[#EDE9FE]/70 mt-0.5">Colegio o Universidad</p>
                      </div>
                    </button>

                    {/* Opción B: No, soy familiar / tutor / apoyo */}
                    <button
                      type="button"
                      onClick={() => setIsStudent(false)}
                      className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        !isStudent
                          ? 'bg-[#8B5CF6]/30 border-[#8B5CF6] ring-2 ring-[#8B5CF6]'
                          : 'bg-black/30 border-white/10 hover:border-white/25'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Users className={`w-5 h-5 ${!isStudent ? 'text-[#C4B5FD]' : 'text-slate-400'}`} />
                        <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${!isStudent ? 'border-[#8B5CF6] bg-[#8B5CF6]' : 'border-slate-500'}`}>
                          {!isStudent && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                        </span>
                      </div>
                      <div>
                        <p className="font-bold text-xs text-white">No, soy familiar / apoyo</p>
                        <p className="text-[10px] text-[#EDE9FE]/70 mt-0.5">Mamá, Papá, Tutor o Amigo</p>
                      </div>
                    </button>
                  </div>

                  {/* Campos dinámicos según selección */}
                  {isStudent ? (
                    <div className="grid grid-cols-2 gap-2 pt-1 animate-in fade-in duration-150">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Colegio / Universidad
                        </label>
                        <input
                          type="text"
                          value={institution}
                          onChange={(e) => setInstitution(e.target.value)}
                          placeholder="Ej. Colegio Nacional"
                          className="w-full px-3 py-2 rounded-xl bg-black/40 border border-[#8B5CF6]/30 text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                          Año / Curso
                        </label>
                        <input
                          type="text"
                          value={gradeOrRole}
                          onChange={(e) => setGradeOrRole(e.target.value)}
                          placeholder="Ej. 3er Bachillerato"
                          className="w-full px-3 py-2 rounded-xl bg-black/40 border border-[#8B5CF6]/30 text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="pt-1 animate-in fade-in duration-150">
                      <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                        ¿Cuál es tu rol o relación con el estudiante?
                      </label>
                      <select
                        value={supportRole}
                        onChange={(e) => setSupportRole(e.target.value as any)}
                        className="w-full px-3 py-2 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/40 text-white text-xs focus:outline-none focus:border-[#8B5CF6]"
                      >
                        <option value="familiar">Madre o Padre de familia</option>
                        <option value="tutor">Tutor / Representante Legal</option>
                        <option value="amigo">Amigo / Compañero de confianza</option>
                        <option value="contacto_apoyo">Contacto de Seguridad / Familiar</option>
                      </select>
                    </div>
                  )}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full min-h-[46px] mt-2 py-3 px-4 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] text-white font-bold text-sm shadow-xl shadow-[#8B5CF6]/30 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>{isLoading ? 'Registrando...' : 'Registrarme y Entrar a NEXA'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <p className="text-center text-xs text-slate-400 pt-1">
                  ¿Ya tienes cuenta?{' '}
                  <button
                    type="button"
                    onClick={() => setActiveTab('login')}
                    className="text-[#C4B5FD] font-bold hover:underline cursor-pointer"
                  >
                    Inicia sesión aquí
                  </button>
                </p>
              </form>
            )}

            {/* FORM: INICIAR SESIÓN */}
            {activeTab === 'login' && (
              <form onSubmit={handleLoginSubmit} className="mt-4 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Número de Celular o Correo *
                  </label>
                  <div className="relative">
                    <Smartphone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="0991234567 o correo@ejemplo.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#EDE9FE] mb-1">
                    Contraseña *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="Tu contraseña secreta"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-black/40 border border-[#8B5CF6]/40 text-white text-xs sm:text-sm placeholder:text-slate-500 focus:outline-none focus:border-[#8B5CF6]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-white cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full min-h-[46px] py-3 px-4 rounded-2xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-sm shadow-xl active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Cloud className="w-4 h-4" />
                  <span>{isLoading ? 'Verificando...' : 'Iniciar Sesión'}</span>
                </button>

                {/* Quick Shortcuts to test calling between devices (Phone <-> Laptop) */}
                <div className="pt-2 border-t border-white/10 space-y-2">
                  <p className="text-[11px] font-bold text-[#C4B5FD] text-center">
                    Atajos para probar llamadas entre Laptop y Celular:
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => handleQuickLoginAs('estudiante')}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left cursor-pointer transition-colors"
                    >
                      <p className="text-[11px] font-bold text-white">🎓 Estudiante</p>
                      <p className="text-[10px] text-slate-400">Tel: 0991234567</p>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleQuickLoginAs('mama')}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left cursor-pointer transition-colors"
                    >
                      <p className="text-[11px] font-bold text-white">🛡️ Mamá (Tutor)</p>
                      <p className="text-[10px] text-slate-400">Tel: 0991248830</p>
                    </button>
                  </div>
                </div>

                <p className="text-center text-xs text-slate-400 pt-1">
                  ¿No tienes cuenta?{' '}
                  <button
                    type="button"
                    onClick={() => setActiveTab('register')}
                    className="text-[#C4B5FD] font-bold hover:underline cursor-pointer"
                  >
                    Regístrate aquí
                  </button>
                </p>
              </form>
            )}

          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="w-full max-w-6xl mx-auto px-6 py-4 border-t border-white/10 text-center text-xs text-[#EDE9FE]/60 z-10 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p>© 2026 NEXA Student Safety Network · Todos los derechos reservados.</p>
        <p className="text-[11px]">Diseñado para protección discreta e intuitiva de estudiantes.</p>
      </footer>
    </div>
  );
};
