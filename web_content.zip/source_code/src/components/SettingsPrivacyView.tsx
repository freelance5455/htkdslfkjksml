import React, { useState } from 'react';
import {
  AppSettings,
  GeoLocationData,
  NavigationTab,
  UserAccount,
} from '../types';
import { testSirenBriefly } from '../utils/emergencySiren';
import {
  Bluetooth,
  CheckCircle2,
  Cloud,
  Download,
  Eye,
  EyeOff,
  FolderArchive,
  KeyRound,
  Lock,
  LogOut,
  Mail,
  MapPin,
  Moon,
  Save,
  ShieldCheck,
  Smartphone,
  Sun,
  Trash2,
  User,
  UserCheck,
  Volume2,
} from 'lucide-react';

interface SettingsPrivacyViewProps {
  user: UserAccount;
  settings: AppSettings;
  location: GeoLocationData | null;
  onUpdateUser: (updated: UserAccount) => void;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onNavigate: (tab: NavigationTab) => void;
  onClearHistory: () => void;
  onLogout: () => void;
  onDeleteAccountAndData: () => void;
  onOpenDownloadModal?: () => void;
}

export const SettingsPrivacyView: React.FC<SettingsPrivacyViewProps> = ({
  user,
  settings,
  location,
  onUpdateUser,
  onUpdateSettings,
  onNavigate,
  onClearHistory,
  onLogout,
  onDeleteAccountAndData,
  onOpenDownloadModal,
}) => {
  const [fullName, setFullName] = useState(user.fullName);
  const [email, setEmail] = useState(user.email || '');
  const [password, setPassword] = useState(user.password || 'NexaSegura2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [phone, setPhone] = useState(user.phone);
  const [institution, setInstitution] = useState(user.institution);
  const [gradeOrRole, setGradeOrRole] = useState(user.gradeOrRole);
  const [guardianName, setGuardianName] = useState(user.guardianName || '');
  const [guardianPhone, setGuardianPhone] = useState(user.guardianPhone || '');
  const [savedBanner, setSavedBanner] = useState(false);
  const [confirmDeleteAccount, setConfirmDeleteAccount] = useState(false);
  const [isSavingServer, setIsSavingServer] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingServer(true);

    const updatedUser: UserAccount = {
      ...user,
      fullName: fullName.trim() || 'Usuario',
      email: email.trim() || user.email,
      phone: phone.trim() || user.phone,
      password: password.trim() || undefined,
      institution: institution.trim(),
      gradeOrRole: gradeOrRole.trim(),
      guardianName: guardianName.trim() || undefined,
      guardianPhone: guardianPhone.trim() || undefined,
    };

    onUpdateUser(updatedUser);

    // Save directly to server database for cross-device access
    try {
      await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user: updatedUser,
          password: password.trim(),
          settings,
        }),
      });
    } catch {
      // offline fallback
    } finally {
      setIsSavingServer(false);
      setSavedBanner(true);
      setTimeout(() => setSavedBanner(false), 4500);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#1E1B4B] dark:text-white">
            Ajustes, Permisos y Privacidad
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
            Gestiona tu perfil estudiantil, apariencia de la marca, parámetros de SafeRoute y tus
            derechos bajo la Ley Orgánica de Protección de Datos Personales (Ecuador).
          </p>
        </div>

        <div className="flex items-center gap-2">
          {onOpenDownloadModal && (
            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>Descargar / Instalar App</span>
            </button>
          )}

        </div>
      </div>

      {/* Download and Installation Banner */}
      {onOpenDownloadModal && (
        <div className="rounded-3xl bg-gradient-to-r from-[#1E1B4B] to-[#2E296B] text-white p-5 sm:p-6 border border-[#8B5CF6]/40 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C4B5FD]">
              Acceso Móvil y Código
            </span>
            <h2 className="font-display text-base sm:text-lg font-bold">
              ¿Quieres descargar o instalar NEXA en tu teléfono?
            </h2>
            <p className="text-xs text-[#EDE9FE]/80 max-w-xl">
              Instala la aplicación en tu celular Android o iPhone (PWA a pantalla completa sin
              navegador) o descarga el código fuente completo en formato .zip.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="px-4 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer shadow-md whitespace-nowrap"
            >
              <Smartphone className="w-4 h-4" />
              <span>Instalar en Teléfono</span>
            </button>
            <button
              type="button"
              onClick={onOpenDownloadModal}
              className="px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-[#EDE9FE] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            >
              <FolderArchive className="w-4 h-4" />
              <span>Descargar .zip</span>
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-5">
          <form
            onSubmit={handleSaveProfile}
            className="rounded-3xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <User className="w-5 h-5 text-[#8B5CF6]" />
                <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
                  Perfil Personal del Estudiante
                </h2>
              </div>
              <span className="text-xs text-slate-500">{user.email}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Nombre completo
                </label>
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Teléfono del estudiante
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Institución educativa
                </label>
                <input
                  type="text"
                  value={institution}
                  onChange={(e) => setInstitution(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Curso / Grado
                </label>
                <input
                  type="text"
                  value={gradeOrRole}
                  onChange={(e) => setGradeOrRole(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-[#8B5CF6]" />
                  <span>Correo electrónico de la cuenta</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="estudiante@nexa.edu.ec"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    <span>Contraseña (Acceso multi-celular)</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-[#8B5CF6] hover:underline cursor-pointer flex items-center gap-1"
                  >
                    {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    <span>{showPassword ? 'Ocultar' : 'Ver'}</span>
                  </button>
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Tu clave para entrar desde otro celular"
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Representante / Tutor autorizado
                </label>
                <input
                  type="text"
                  value={guardianName}
                  onChange={(e) => setGuardianName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Teléfono del representante
                </label>
                <input
                  type="tel"
                  value={guardianPhone}
                  onChange={(e) => setGuardianPhone(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 text-[11px] text-indigo-900 dark:text-[#C4B5FD] flex items-start gap-2">
              <Cloud className="w-4 h-4 text-[#8B5CF6] shrink-0 mt-0.5" />
              <p>
                <strong>Guardado en el servidor para cualquier celular:</strong> Tu correo (
                <strong>{email || user.email}</strong>), tu teléfono (<strong>{phone || user.phone}</strong>)
                y tu contraseña quedan guardados en la nube NEXA. Si abres esta app en otro teléfono, solo
                ingresas tus datos para ver tus contactos y rutas.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
              {savedBanner ? (
                <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>¡Datos guardados y sincronizados en la nube NEXA con éxito!</span>
                </span>
              ) : (
                <span className="text-[11px] text-slate-500">
                  Consentimiento LOPDP y sincronización en servidor activa
                </span>
              )}

              <button
                type="submit"
                disabled={isSavingServer}
                className="min-h-[42px] px-5 py-2.5 rounded-xl bg-[#1E1B4B] dark:bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95 disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSavingServer ? 'Guardando en la nube...' : 'Guardar y sincronizar'}</span>
              </button>
            </div>
          </form>

          {/* DAY / NIGHT THEME SELECTOR CARD */}
          <div className="rounded-3xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {settings.darkMode !== false ? (
                  <Moon className="w-5 h-5 text-[#8B5CF6]" />
                ) : (
                  <Sun className="w-5 h-5 text-amber-500" />
                )}
                <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
                  Apariencia y Modo de Pantalla
                </h2>
              </div>
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-[#8B5CF6]/20 text-[#8B5CF6] font-semibold">
                {settings.darkMode !== false ? 'Noche (Morado Oscuro)' : 'Modo Día'}
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              Por defecto NEXA utiliza el modo noche morado oscuro para máxima discreción visual y protección en la noche. Puedes alternar a modo día en cualquier instante.
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={() => onUpdateSettings({ darkMode: true })}
                className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 text-center transition-all cursor-pointer ${
                  settings.darkMode !== false
                    ? 'bg-[#171435] border-[#8B5CF6] ring-2 ring-[#8B5CF6] text-white shadow-md'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Moon className="w-6 h-6 text-[#C4B5FD]" />
                <div>
                  <p className="font-display text-xs font-bold">Modo Noche (Predeterminado)</p>
                  <p className="text-[10px] opacity-75">Morado oscuro NEXA</p>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onUpdateSettings({ darkMode: false })}
                className={`p-3.5 rounded-2xl border flex flex-col items-center gap-2 text-center transition-all cursor-pointer ${
                  settings.darkMode === false
                    ? 'bg-amber-50 border-amber-500 ring-2 ring-amber-500 text-slate-900 shadow-md'
                    : 'bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Sun className="w-6 h-6 text-amber-500" />
                <div>
                  <p className="font-display text-xs font-bold">Modo Día</p>
                  <p className="text-[10px] opacity-75">Claridad y contraste</p>
                </div>
              </button>
            </div>
          </div>

          <div className="rounded-3xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
            <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
              Parámetros de SafeRoute y Discreción
            </h2>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 cursor-pointer">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-white">
                    Modo Silencio (Discreción prioritaria)
                  </p>
                  <p className="text-[11px] text-slate-500">
                    Prioriza confirmación por vibración táctil sin emitir sonidos que llamen la
                    atención.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.silentMode}
                  onChange={(e) => onUpdateSettings({ silentMode: e.target.checked })}
                  className="rounded text-[#8B5CF6] w-4 h-4"
                />
              </label>

              {/* Tono acústico para contactos */}
              <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <p className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Volume2 className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Tono Acústico de Emergencia (Contactos)</span>
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Nuevo tono armónico moderno, potente y no estridente que sonará en el celular de tus contactos registrados al recibir tu alerta SOS.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => testSirenBriefly(2.4)}
                  className="px-3.5 py-2 rounded-xl bg-[#1E1B4B] dark:bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold cursor-pointer shrink-0 transition-transform active:scale-95 shadow-sm"
                >
                  Probar sonido
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Margen desviación GPS (m)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={500}
                    step={25}
                    value={settings.safeRouteToleranceMeters}
                    onChange={(e) =>
                      onUpdateSettings({
                        safeRouteToleranceMeters: Number(e.target.value) || 150,
                      })
                    }
                    className="w-full font-mono-tabular font-bold text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Espera Nivel 1 → 2 (seg)
                  </label>
                  <input
                    type="number"
                    min={15}
                    max={180}
                    value={settings.safeRouteLevel1WaitSec}
                    onChange={(e) =>
                      onUpdateSettings({
                        safeRouteLevel1WaitSec: Number(e.target.value) || 45,
                      })
                    }
                    className="w-full font-mono-tabular font-bold text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Conservación historial (días)
                  </label>
                  <input
                    type="number"
                    min={7}
                    max={90}
                    value={settings.dataRetentionDays}
                    onChange={(e) =>
                      onUpdateSettings({
                        dataRetentionDays: Number(e.target.value) || 30,
                      })
                    }
                    className="w-full font-mono-tabular font-bold text-sm bg-transparent text-slate-900 dark:text-white focus:outline-none"
                  />
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => onNavigate('contactos')}
                className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                Administrar contactos SOS
              </button>
              <button
                type="button"
                onClick={() => onNavigate('alerta_config')}
                className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                Personalizar mensaje SOS
              </button>
              <button
                type="button"
                onClick={() => onNavigate('dispositivo')}
                className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                Configurar NEXA Core BLE
              </button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-5">
          <div className="rounded-3xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#8B5CF6]" />
              <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
                ¿Qué permisos usa NEXA y por qué?
              </h2>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-[#8B5CF6]" />
                    Ubicación GPS precisa
                  </span>
                  <span className="text-[11px] text-[#8B5CF6]">
                    {location?.isLive ? 'Autorizado' : 'Bajo demanda'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  Se utiliza exclusivamente para adjuntar tus coordenadas en una alerta SOS o
                  verificar tu recorrido durante una Ruta Segura activa. Nunca rastrea en segundo
                  plano cuando no tienes una ruta o alerta activa.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                  <span className="flex items-center gap-1.5">
                    <Bluetooth className="w-4 h-4 text-[#8B5CF6]" />
                    Bluetooth Low Energy (BLE)
                  </span>
                  <span className="text-[11px] text-[#8B5CF6]">Opcional</span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                  Permite recibir la señal del botón físico de tu accesorio NEXA Core (ESP32), leer
                  el nivel de batería y enviar confirmaciones por vibración.
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/70 space-y-1">
                <p className="font-semibold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-emerald-600" />
                  Garantía de Cero Vigilancia Acústica
                </p>
                <p className="text-[11px] text-emerald-800 dark:text-emerald-300 leading-relaxed">
                  Ni la aplicación NEXA ni el hardware NEXA Core solicitan permiso de micrófono ni
                  graban conversaciones. Cumplimos con la Ley Orgánica de Protección de Datos
                  Personales (LOPDP del Ecuador).
                </p>
              </div>
            </div>

            <div className="rounded-2xl bg-slate-50 dark:bg-slate-900 p-3.5 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300 space-y-1 leading-relaxed">
              <p className="font-semibold text-slate-900 dark:text-white">
                Alcance de la plataforma y limitaciones operativas:
              </p>
              <p>
                • En versión web/PWA, el envío mediante servidor NEXA se procesa automáticamente si
                hay conexión a internet, mientras que el envío por SMS nativo o llamada telefónica
                abre la aplicación del teléfono para confirmación del usuario.
              </p>
              <p>
                • Para despertar la aplicación en segundo plano mediante BLE con la pantalla
                bloqueada en iOS/Android se requiere compilar el cliente nativo (React Native /
                Flutter) con permisos de <em>Background BLE Central</em>.
              </p>
              <p>
                • NEXA es una herramienta de apoyo estudiantil y no sustituye al servicio integrado
                de seguridad <strong>ECU 911</strong>.
              </p>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={onClearHistory}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium cursor-pointer"
                >
                  Limpiar historial de eventos
                </button>

                <button
                  type="button"
                  onClick={onLogout}
                  className="px-3.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Cerrar sesión</span>
                </button>

                <button
                  type="button"
                  onClick={onLogout}
                  className="px-3.5 py-2 rounded-xl bg-[#8B5CF6]/15 hover:bg-[#8B5CF6]/25 text-[#8B5CF6] dark:text-[#C4B5FD] text-xs font-semibold flex items-center gap-1.5 cursor-pointer border border-[#8B5CF6]/30"
                  title="Ingresa con otra cuenta o crea una nueva cuenta desde cero"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Cambiar / Crear otra cuenta</span>
                </button>
              </div>

              {!confirmDeleteAccount ? (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteAccount(true)}
                  className="w-full py-2.5 rounded-xl bg-red-50 dark:bg-red-950/40 hover:bg-red-100 text-red-700 dark:text-red-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Eliminar mi cuenta y todos mis datos personales</span>
                </button>
              ) : (
                <div className="p-3 rounded-2xl bg-red-50 dark:bg-red-950/60 border border-red-300 space-y-2">
                  <p className="text-xs font-bold text-red-800 dark:text-red-200">
                    ¿Confirmas la eliminación definitiva de tu cuenta, contactos e historial?
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={onDeleteAccountAndData}
                      className="px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-semibold cursor-pointer"
                    >
                      Sí, borrar todos mis datos
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteAccount(false)}
                      className="px-3 py-1.5 rounded-lg bg-white text-slate-700 text-xs font-medium cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
