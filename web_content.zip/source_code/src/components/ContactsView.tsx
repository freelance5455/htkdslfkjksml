import React, { useState } from 'react';
import {
  ContactRelationship,
  EmergencyContact,
  NotificationChannel,
} from '../types';
import { validatePhoneWithCountry } from '../utils/sosFormatter';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  Edit3,
  Mail,
  MessageCircle,
  Phone,
  Plus,
  ShieldCheck,
  Trash2,
  UserPlus,
  Users,
} from 'lucide-react';

interface ContactsViewProps {
  contacts: EmergencyContact[];
  onSaveContacts: (updated: EmergencyContact[]) => void;
  onOpenChatWithContact?: (contact: EmergencyContact) => void;
  onStartInAppCall?: (contact: EmergencyContact) => void;
}

const CHANNEL_LABELS: { id: NotificationChannel; label: string }[] = [
  { id: 'push', label: 'Notificación NEXA' },
  { id: 'sms', label: 'SMS' },
  { id: 'email', label: 'Correo' },
  { id: 'call', label: 'Marcador telefónico' },
];

const RELATIONSHIP_LABELS: { id: ContactRelationship; label: string }[] = [
  { id: 'tutor', label: 'Madre / Padre / Tutor' },
  { id: 'familiar', label: 'Familiar' },
  { id: 'amigo', label: 'Amigo / Compañero' },
  { id: 'otro', label: 'Coordinación / Otro' },
];

export const ContactsView: React.FC<ContactsViewProps> = ({
  contacts,
  onSaveContacts,
  onOpenChatWithContact,
  onStartInAppCall,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [countryCode, setCountryCode] = useState('+593');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [relationship, setRelationship] = useState<ContactRelationship>('familiar');
  const [channels, setChannels] = useState<NotificationChannel[]>(['sms', 'push']);
  const [authorized, setAuthorized] = useState(true);
  const [receiveSos, setReceiveSos] = useState(true);
  const [locationConsent, setLocationConsent] = useState(true);
  const [formError, setFormError] = useState<string | null>(null);

  const sortedContacts = [...contacts].sort((a, b) => a.priority - b.priority);
  const activeSosRecipients = sortedContacts.filter((c) => c.authorized && c.receiveSos);

  const resetForm = () => {
    setEditingId(null);
    setFirstName('');
    setLastName('');
    setCountryCode('+593');
    setPhone('');
    setEmail('');
    setRelationship('familiar');
    setChannels(['sms', 'push']);
    setAuthorized(true);
    setReceiveSos(true);
    setLocationConsent(true);
    setFormError(null);
    setShowForm(false);
  };

  const handleStartEdit = (contact: EmergencyContact) => {
    setEditingId(contact.id);
    setFirstName(contact.firstName);
    setLastName(contact.lastName);
    setCountryCode(contact.countryCode);
    setPhone(contact.phone);
    setEmail(contact.email || '');
    setRelationship(contact.relationship);
    setChannels(contact.channels);
    setAuthorized(contact.authorized);
    setReceiveSos(contact.receiveSos);
    setLocationConsent(contact.locationConsent);
    setFormError(null);
    setShowForm(true);
  };

  const toggleChannel = (ch: NotificationChannel) => {
    setChannels((prev) =>
      prev.includes(ch) ? prev.filter((item) => item !== ch) : [...prev, ch]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (firstName.trim().length < 2 || lastName.trim().length < 2) {
      setFormError('Ingresa el nombre y el apellido del contacto.');
      return;
    }

    const phoneValidation = validatePhoneWithCountry(countryCode, phone);
    if (!phoneValidation.valid) {
      setFormError(phoneValidation.error || 'Número telefónico inválido.');
      return;
    }

    if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setFormError('El correo electrónico ingresado no tiene un formato válido.');
      return;
    }

    if (channels.length === 0) {
      setFormError('Selecciona al menos un canal de notificación para este contacto.');
      return;
    }

    if (!locationConsent) {
      setFormError(
        'Debes confirmar el consentimiento para compartir tu ubicación temporal con este contacto durante una emergencia o ruta.'
      );
      return;
    }

    if (editingId) {
      const updated = sortedContacts.map((c) =>
        c.id === editingId
          ? {
              ...c,
              firstName: firstName.trim(),
              lastName: lastName.trim(),
              countryCode: countryCode.trim().startsWith('+')
                ? countryCode.trim()
                : `+${countryCode.trim()}`,
              phone: phoneValidation.cleanedPhone,
              email: email.trim() || undefined,
              relationship,
              channels,
              authorized,
              receiveSos,
              locationConsent,
              updatedAt: new Date().toISOString(),
            }
          : c
      );
      onSaveContacts(updated);
    } else {
      const newContact: EmergencyContact = {
        id: `cnt_${Date.now()}`,
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        countryCode: countryCode.trim().startsWith('+')
          ? countryCode.trim()
          : `+${countryCode.trim()}`,
        phone: phoneValidation.cleanedPhone,
        email: email.trim() || undefined,
        relationship,
        priority: sortedContacts.length + 1,
        channels,
        authorized,
        receiveSos,
        locationConsent,
        updatedAt: new Date().toISOString(),
      };
      onSaveContacts([...sortedContacts, newContact]);
    }

    resetForm();
  };

  const handleDelete = (id: string) => {
    const filtered = sortedContacts
      .filter((c) => c.id !== id)
      .map((c, idx) => ({ ...c, priority: idx + 1 }));
    onSaveContacts(filtered);
  };

  const handleMovePriority = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= sortedContacts.length) return;
    const copy = [...sortedContacts];
    const temp = copy[index];
    copy[index] = copy[targetIdx];
    copy[targetIdx] = temp;
    const reindexed = copy.map((c, idx) => ({ ...c, priority: idx + 1 }));
    onSaveContacts(reindexed);
  };

  const handleToggleReceiveSos = (id: string) => {
    const updated = sortedContacts.map((c) =>
      c.id === id ? { ...c, receiveSos: !c.receiveSos } : c
    );
    onSaveContacts(updated);
  };

  const handleToggleAuthorized = (id: string) => {
    const updated = sortedContacts.map((c) =>
      c.id === id ? { ...c, authorized: !c.authorized } : c
    );
    onSaveContacts(updated);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-[#1E1B4B] dark:text-white">
            Mis contactos de emergencia
          </h1>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
            Administra tu red de apoyo autorizada. Al activar el SOS, NEXA notificará a todos los
            contactos activos respetando su orden de prioridad.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            resetForm();
            setShowForm(true);
          }}
          className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer shrink-0 shadow-sm"
        >
          <UserPlus className="w-4 h-4" />
          <span>Añadir contacto</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-2xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Contactos registrados</p>
          <p className="font-display text-2xl font-bold text-[#1E1B4B] dark:text-white tabular-nums mt-0.5">
            {sortedContacts.length}{' '}
            <span className="text-xs font-normal text-slate-500">/ mín. 5 recomendados</span>
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">Destinatarios SOS activos</p>
          <p className="font-display text-2xl font-bold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
            {activeSosRecipients.length}{' '}
            <span className="text-xs font-normal text-slate-500">autorizados</span>
          </p>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-4 flex items-center gap-3">
          {sortedContacts.length >= 5 && activeSosRecipients.length > 0 ? (
            <>
              <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />
              <div className="text-xs">
                <p className="font-semibold text-slate-900 dark:text-white">Red de apoyo completa</p>
                <p className="text-slate-500 dark:text-slate-400">
                  Tus 5+ contactos están validados y listos.
                </p>
              </div>
            </>
          ) : (
            <>
              <AlertTriangle className="w-6 h-6 text-amber-500 shrink-0" />
              <div className="text-xs">
                <p className="font-semibold text-amber-800 dark:text-amber-300">
                  {activeSosRecipients.length === 0
                    ? 'Sin destinatarios SOS activos'
                    : `Faltan ${Math.max(0, 5 - sortedContacts.length)} contactos para la red de 5`}
                </p>
                <p className="text-slate-500 dark:text-slate-400">
                  Registra al menos 5 contactos de confianza.
                </p>
              </div>
            </>
          )}
        </div>
      </div>

      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="rounded-3xl bg-white dark:bg-[#1E1B4B]/80 border-2 border-[#8B5CF6]/40 p-5 sm:p-6 space-y-4 shadow-lg"
        >
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
              {editingId ? 'Editar contacto de emergencia' : 'Nuevo contacto de emergencia'}
            </h2>
            <button
              type="button"
              onClick={resetForm}
              className="text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer"
            >
              Cancelar
            </button>
          </div>

          {formError && (
            <div className="rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-200 dark:border-red-800 p-3 text-xs text-red-700 dark:text-red-300">
              {formError}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Nombre *
              </label>
              <input
                type="text"
                required
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                placeholder="Ej. Elena"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Apellido y parentesco *
              </label>
              <input
                type="text"
                required
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                placeholder="Ej. Chacha (Mamá)"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Código de país *
              </label>
              <input
                type="text"
                required
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                placeholder="+593"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Número de teléfono *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="991248830"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs font-mono-tabular text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Relación con el estudiante
              </label>
              <select
                value={relationship}
                onChange={(e) => setRelationship(e.target.value as ContactRelationship)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              >
                {RELATIONSHIP_LABELS.map((rel) => (
                  <option key={rel.id} value={rel.id}>
                    {rel.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
              Correo electrónico (opcional para respaldo de alertas)
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="contacto@familia.ec"
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-2">
              Canales de notificación habilitados
            </label>
            <div className="flex flex-wrap gap-2">
              {CHANNEL_LABELS.map((ch) => {
                const active = channels.includes(ch.id);
                return (
                  <button
                    key={ch.id}
                    type="button"
                    onClick={() => toggleChannel(ch.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-colors cursor-pointer border ${
                      active
                        ? 'bg-[#8B5CF6] text-white border-[#8B5CF6]'
                        : 'bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {ch.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-2 rounded-2xl bg-slate-50 dark:bg-slate-900/90 p-3.5 border border-slate-200 dark:border-slate-800">
            <label className="flex items-center gap-2 text-xs text-slate-800 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={authorized}
                onChange={(e) => setAuthorized(e.target.checked)}
                className="rounded text-[#8B5CF6]"
              />
              <span>Contacto verificado y autorizado en mi red de seguridad</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-800 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={receiveSos}
                onChange={(e) => setReceiveSos(e.target.checked)}
                className="rounded text-[#8B5CF6]"
              />
              <span>Incluir en el envío automático de alertas de emergencia SOS</span>
            </label>

            <label className="flex items-start gap-2 text-xs text-slate-800 dark:text-slate-200 cursor-pointer">
              <input
                type="checkbox"
                checked={locationConsent}
                onChange={(e) => setLocationConsent(e.target.checked)}
                className="mt-0.5 rounded text-[#8B5CF6]"
              />
              <span>
                Otorgo mi consentimiento informado para compartir mi ubicación GPS temporal con este
                contacto únicamente cuando se active una emergencia SOS o un recorrido SafeRoute.
              </span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-1">
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#1E1B4B] dark:bg-[#8B5CF6] text-white text-xs font-semibold cursor-pointer"
            >
              {editingId ? 'Guardar cambios' : 'Registrar contacto'}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {sortedContacts.length === 0 ? (
          <div className="rounded-3xl bg-white dark:bg-[#1E1B4B]/40 border border-slate-200 dark:border-slate-800 p-8 text-center space-y-3">
            <Users className="w-10 h-10 text-[#8B5CF6] mx-auto" />
            <h3 className="font-display text-base font-bold text-slate-900 dark:text-white">
              Aún no tienes contactos registrados
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Añade al menos un tutor o familiar autorizado para poder enviar alertas SOS y
              compartir tu Ruta Segura.
            </p>
            <button
              type="button"
              onClick={() => setShowForm(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Añadir primer contacto</span>
            </button>
          </div>
        ) : (
          sortedContacts.map((contact, idx) => (
            <div
              key={contact.id}
              className="rounded-2xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-colors"
            >
              <div className="flex items-start gap-3.5">
                <div className="flex flex-col items-center justify-center bg-[#EDE9FE] dark:bg-[#1E1B4B] text-[#1E1B4B] dark:text-[#C4B5FD] rounded-xl px-2.5 py-1.5 shrink-0">
                  <span className="text-[10px] font-semibold uppercase">Prioridad</span>
                  <span className="font-display text-base font-extrabold tabular-nums">
                    #{contact.priority}
                  </span>
                </div>

                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                      {contact.firstName} {contact.lastName}
                    </h3>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-[#8B5CF6] font-medium capitalize">
                      {contact.relationship}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 dark:text-slate-300">
                    <span className="inline-flex items-center gap-1 font-mono-tabular">
                      <Phone className="w-3.5 h-3.5 text-slate-400" />
                      {contact.countryCode} {contact.phone}
                    </span>
                    {contact.email && (
                      <span className="inline-flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        {contact.email}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 pt-0.5">
                    <span>Canales: {contact.channels.map((c) => c.toUpperCase()).join(' / ')}</span>
                    <span>·</span>
                    <span
                      className={
                        contact.authorized && contact.receiveSos
                          ? 'text-emerald-600 dark:text-emerald-400 font-medium'
                          : 'text-amber-600 dark:text-amber-400 font-medium'
                      }
                    >
                      {contact.authorized && contact.receiveSos
                        ? 'Recibe alertas SOS y ubicación'
                        : 'Pausado para alertas SOS'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800 shrink-0">
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleMovePriority(idx, 'up')}
                    disabled={idx === 0}
                    title="Subir prioridad"
                    className="min-h-[38px] min-w-[38px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#EDE9FE] text-slate-700 dark:text-slate-200 flex items-center justify-center disabled:opacity-35 cursor-pointer"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleMovePriority(idx, 'down')}
                    disabled={idx === sortedContacts.length - 1}
                    title="Bajar prioridad"
                    className="min-h-[38px] min-w-[38px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#EDE9FE] text-slate-700 dark:text-slate-200 flex items-center justify-center disabled:opacity-35 cursor-pointer"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                </div>

                {onOpenChatWithContact && contact.phone && (
                  <button
                    type="button"
                    onClick={() => onOpenChatWithContact(contact)}
                    title="Abrir chat seguro con este contacto"
                    className="min-h-[38px] px-3 py-2 rounded-xl bg-[#8B5CF6]/15 hover:bg-[#8B5CF6]/25 text-[#8B5CF6] dark:text-[#C4B5FD] text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Chat</span>
                  </button>
                )}

                {onStartInAppCall && contact.phone && (
                  <button
                    type="button"
                    onClick={() => onStartInAppCall(contact)}
                    title="Iniciar llamada de voz por la app NEXA"
                    className="min-h-[38px] px-3 py-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Llamar</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => handleToggleReceiveSos(contact.id)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    contact.receiveSos
                      ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {contact.receiveSos ? 'SOS Activo' : 'SOS Pausado'}
                </button>

                <button
                  type="button"
                  onClick={() => handleToggleAuthorized(contact.id)}
                  title="Cambiar estado de autorización"
                  className={`min-h-[38px] min-w-[38px] rounded-xl flex items-center justify-center cursor-pointer ${
                    contact.authorized
                      ? 'bg-[#EDE9FE] dark:bg-[#1E1B4B] text-[#8B5CF6]'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => handleStartEdit(contact)}
                  title="Editar contacto"
                  className="min-h-[38px] min-w-[38px] rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-[#EDE9FE] text-slate-700 dark:text-slate-200 flex items-center justify-center cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => handleDelete(contact.id)}
                  title="Eliminar contacto"
                  className="min-h-[38px] min-w-[38px] rounded-xl bg-red-50 dark:bg-red-950/40 hover:bg-red-100 text-red-600 dark:text-red-400 flex items-center justify-center cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
