import React, { useState, useEffect } from 'react';
import {
  ActiveEmergencySession,
  ContactDeliveryAttempt,
  NotificationChannel,
} from '../types';
import { buildGoogleMapsLink, getActivationSourceLabel } from '../utils/sosFormatter';
import { stopEmergencySiren } from '../utils/emergencySiren';
import {
  AlertOctagon,
  CheckCircle2,
  Clock,
  Copy,
  ExternalLink,
  MapPin,
  MessageSquare,
  Phone,
  PhoneCall,
  RefreshCw,
  Send,
  ShieldAlert,
  ShieldCheck,
  VolumeX,
  WifiOff,
  XCircle,
} from 'lucide-react';

interface EmergencyOverlayModalProps {
  session: ActiveEmergencySession;
  onRefreshLocation: () => void;
  onRetryAttempt: (attemptId: string, fallbackChannel?: NotificationChannel) => void;
  onResendAll: () => void;
  onCancelAccidental: (reason: string) => void;
  onResolveEmergency: () => void;
  onStartInAppCall?: (contact: { name: string; phone: string }) => void;
  isLocating: boolean;
}

export const EmergencyOverlayModal: React.FC<EmergencyOverlayModalProps> = ({
  session,
  onRefreshLocation,
  onRetryAttempt,
  onResendAll,
  onCancelAccidental,
  onResolveEmergency,
  onStartInAppCall,
  isLocating,
}) => {
  const [showCancelPrompt, setShowCancelPrompt] = useState(false);
  const [cancelReason, setCancelReason] = useState('Activación accidental del botón');
  const [copiedMessage, setCopiedMessage] = useState(false);

  // MODO SILENCIOSO ESTRICTO DE SEGURIDAD PARA EL REMITENTE:
  // El teléfono del estudiante NUNCA debe emitir sonido al activarse el SOS para protegerlo de un agresor.
  // Solo se realiza una confirmación háptica discreta por vibración.
  useEffect(() => {
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([160, 70, 160]);
      } catch {}
    }
    // Asegurar que la sirena no suene bajo ninguna circunstancia en el dispositivo del remitente
    stopEmergencySiren();

    return () => {
      stopEmergencySiren();
    };
  }, []);

  const handleResolve = () => {
    stopEmergencySiren();
    onResolveEmergency();
  };

  const handleCancel = (reason: string) => {
    stopEmergencySiren();
    onCancelAccidental(reason);
  };

  const mapsUrl =
    session.locationSnapshot && session.locationSnapshot.isLive
      ? buildGoogleMapsLink(session.locationSnapshot.lat, session.locationSnapshot.lng)
      : null;

  const handleCopyAlertText = async () => {
    try {
      await navigator.clipboard.writeText(session.messageSent);
      setCopiedMessage(true);
      setTimeout(() => setCopiedMessage(false), 2500);
    } catch {
      // ignore
    }
  };

  const handleNativeAction = (attempt: ContactDeliveryAttempt) => {
    const cleanPhone = attempt.phone.replace(/\s+/g, '');
    const encodedBody = encodeURIComponent(session.messageSent);
    if (attempt.channel === 'sms') {
      window.location.href = `sms:${cleanPhone}?body=${encodedBody}`;
      onRetryAttempt(attempt.id, 'sms');
    } else if (attempt.channel === 'call') {
      window.location.href = `tel:${cleanPhone}`;
      onRetryAttempt(attempt.id, 'call');
    } else if (attempt.channel === 'email' && attempt.email) {
      const subject = encodeURIComponent(
        session.isTest ? '[PRUEBA] Alerta NEXA' : '¡EMERGENCIA NEXA! Necesito ayuda'
      );
      window.location.href = `mailto:${attempt.email}?subject=${subject}&body=${encodedBody}`;
      onRetryAttempt(attempt.id, 'email');
    } else {
      onRetryAttempt(attempt.id);
    }
  };

  const statusMeta = (status: ContactDeliveryAttempt['status']) => {
    switch (status) {
      case 'entregado':
        return {
          label: 'Entregado (Confirmado)',
          color: 'text-emerald-700 dark:text-emerald-300',
          Icon: CheckCircle2,
        };
      case 'enviado':
        return {
          label: 'Enviado al proveedor',
          color: 'text-blue-700 dark:text-blue-300',
          Icon: Send,
        };
      case 'requiere_accion':
        return {
          label: 'Requiere confirmar en teléfono',
          color: 'text-amber-700 dark:text-amber-300',
          Icon: ExternalLink,
        };
      case 'pendiente':
        return {
          label: 'Pendiente en cola',
          color: 'text-slate-600 dark:text-slate-300',
          Icon: Clock,
        };
      case 'fallido':
        return {
          label: 'Fallido — Intentar otro canal',
          color: 'text-red-700 dark:text-red-300',
          Icon: XCircle,
        };
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div
        className={`w-full max-w-2xl rounded-3xl shadow-2xl border-2 overflow-hidden my-auto ${
          session.isTest
            ? 'bg-white dark:bg-[#0F172A] border-[#8B5CF6]'
            : 'bg-white dark:bg-[#0F172A] border-red-600 ring-4 ring-red-600/30'
        }`}
      >
        <div
          className={`px-6 py-4 text-white flex flex-wrap items-center justify-between gap-3 ${
            session.isTest ? 'bg-[#1E1B4B]' : 'bg-red-600'
          }`}
        >
          <div className="flex items-center gap-3">
            <AlertOctagon className="w-8 h-8 shrink-0 animate-pulse" />
            <div>
              <h2 className="font-display text-lg sm:text-xl font-extrabold tracking-tight">
                {session.isTest
                  ? 'SIMULACIÓN DE ALERTA SOS (MODO PRUEBA)'
                  : '🚨 ¡EMERGENCIA SOS ACTIVA!'}
              </h2>
              <p className="text-xs text-white/90">
                {getActivationSourceLabel(session.source)} ·{' '}
                {new Date(session.startedAt).toLocaleTimeString('es-EC')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Indicador garantizado de MODO SILENCIOSO en el dispositivo del remitente */}
            <div
              className="px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md bg-emerald-950/80 border border-emerald-400/50 text-emerald-200"
              title="Tu dispositivo no emite sonido. La alerta sonora sonará en el celular de tus contactos registrados."
            >
              <VolumeX className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Silencioso (0 dB)</span>
            </div>

            <button
              type="button"
              onClick={() => setShowCancelPrompt(true)}
              className="px-3 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Fue un error / Cancelar
            </button>
          </div>
        </div>

        {/* Banner de protección silenciosa para el estudiante */}
        <div className="bg-emerald-50 dark:bg-emerald-950/70 border-b border-emerald-200 dark:border-emerald-800/80 px-6 py-2.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-xs text-emerald-900 dark:text-emerald-200">
            <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <div>
              <p className="font-bold">
                Modo Silencioso de Seguridad Activo — Tu teléfono NO emite sonido
              </p>
              <p className="text-[11px] text-emerald-800 dark:text-emerald-300">
                Tu teléfono permanece en completo silencio para no delatarte ante ningún agresor. La alarma acústica sonora y tus coordenadas GPS en vivo se despacharon a tus contactos registrados.
              </p>
            </div>
          </div>
        </div>

        {!session.isOnline && (
          <div className="bg-amber-50 dark:bg-amber-950/60 border-b border-amber-200 dark:border-amber-800 px-6 py-3 flex items-start gap-3">
            <WifiOff className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900 dark:text-amber-200 leading-relaxed">
              <strong>Sin conexión a internet:</strong> El evento se ha guardado en la cola segura
              local y se sincronizará automáticamente al recuperar red. Si tienes señal celular GSM,
              usa los botones de <strong>Abrir SMS</strong> o <strong>Llamar al 911 / Contacto</strong>.
            </div>
          </div>
        )}

        <div className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {showCancelPrompt && (
            <div className="rounded-2xl bg-amber-50 dark:bg-slate-800/90 border border-amber-300 dark:border-amber-700 p-4 space-y-3">
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                ¿Deseas cancelar esta activación por error?
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-300">
                Se registrará la cancelación en tu historial de actividad y se detendrá la sirena.
              </p>
              <input
                type="text"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Motivo de cancelación (ej. Pulsación accidental)"
                className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white"
              />
              <div className="flex gap-2 justify-end">
                <button
                  type="button"
                  onClick={() => setShowCancelPrompt(false)}
                  className="px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium cursor-pointer"
                >
                  Volver a la alerta
                </button>
                <button
                  type="button"
                  onClick={() => handleCancel(cancelReason)}
                  className="px-3 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-700 cursor-pointer"
                >
                  Confirmar cancelación
                </button>
              </div>
            </div>
          )}

          {/* Location snapshot banner */}
          <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Coordenadas GPS de la alerta
                </h3>
              </div>
              <button
                type="button"
                onClick={onRefreshLocation}
                disabled={isLocating}
                className="text-xs font-semibold text-[#8B5CF6] hover:underline flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
                <span>Actualizar GPS</span>
              </button>
            </div>

            {session.locationSnapshot && session.locationSnapshot.isLive ? (
              <div className="text-xs space-y-1 font-mono-tabular">
                <p className="text-slate-700 dark:text-slate-300">
                  Latitud: {session.locationSnapshot.lat.toFixed(6)} · Longitud:{' '}
                  {session.locationSnapshot.lng.toFixed(6)} (Precisión: ±
                  {Math.round(session.locationSnapshot.accuracy)} m)
                </p>
                {mapsUrl && (
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#8B5CF6] hover:underline font-sans text-xs font-semibold pt-1"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Abrir en Google Maps satelital</span>
                  </a>
                )}
              </div>
            ) : (
              <p className="text-xs text-amber-700 dark:text-amber-400">
                Ubicación GPS no disponible en el instante de activación. Pulsa &quot;Actualizar GPS&quot;
                para reintentar.
              </p>
            )}
          </div>

          {/* Message Sent preview */}
          <div className="rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Texto del mensaje despachado
              </span>
              <button
                type="button"
                onClick={handleCopyAlertText}
                className="text-xs text-[#8B5CF6] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedMessage ? 'Copiado' : 'Copiar texto'}</span>
              </button>
            </div>
            <p className="text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap leading-relaxed font-mono-tabular bg-white dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
              {session.messageSent}
            </p>
          </div>

          {/* Contact delivery attempts table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-display text-sm font-bold text-slate-900 dark:text-white">
                  Estado real de envío a contactos autorizados
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Notificando en orden de prioridad a tu red de apoyo estudiantil.
                </p>
              </div>
              <button
                type="button"
                onClick={onResendAll}
                className="px-3 py-1.5 rounded-xl bg-[#EDE9FE] dark:bg-[#1E1B4B] text-[#1E1B4B] dark:text-[#C4B5FD] text-xs font-semibold hover:opacity-90 transition-opacity cursor-pointer whitespace-nowrap shrink-0"
              >
                Reenviar alerta
              </button>
            </div>

            <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              {session.attempts.map((att) => {
                const meta = statusMeta(att.status);
                const StatusIcon = meta.Icon;
                return (
                  <div
                    key={att.id}
                    className="p-3.5 bg-white dark:bg-slate-900/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-900 dark:text-white">
                        <span className="font-mono-tabular text-[#8B5CF6]">#{att.priority}</span>
                        <span>{att.contactName}</span>
                        <span className="text-slate-400">·</span>
                        <span className="font-mono-tabular text-slate-600 dark:text-slate-400 font-normal">
                          {att.phone}
                        </span>
                      </div>
                      <div className={`flex items-center gap-1.5 text-xs font-medium ${meta.color}`}>
                        <StatusIcon className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          Canal {att.channel.toUpperCase()}: {meta.label}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">{att.detail}</p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* IN-APP VOICE CALL OPTION */}
                      {onStartInAppCall && (
                        <button
                          type="button"
                          onClick={() => onStartInAppCall({ name: att.contactName, phone: att.phone })}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-600 dark:text-emerald-400 text-[11px] font-bold flex items-center gap-1 cursor-pointer"
                          title="Llamar por la app NEXA"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>Llamar por App</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleNativeAction({ ...att, channel: 'sms' })}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-[#EDE9FE] dark:hover:bg-[#1E1B4B] text-slate-800 dark:text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                        title="Abrir app de mensajes SMS con el texto prellenado"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-[#8B5CF6]" />
                        <span>Abrir SMS</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleNativeAction({ ...att, channel: 'call' })}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-slate-800 dark:text-slate-200 text-[11px] font-medium flex items-center gap-1 cursor-pointer"
                        title="Abrir marcador telefónico"
                      >
                        <Phone className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Marcador</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <a
              href="tel:911"
              className="min-h-[44px] px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold text-xs flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
            >
              <PhoneCall className="w-4 h-4 text-red-500" />
              <span>Abrir marcador ECU 911 (Servicios de Emergencia)</span>
            </a>

            <button
              type="button"
              onClick={handleResolve}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg active:scale-95"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Estoy a salvo · Finalizar emergencia</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
