import React, { useState } from 'react';
import {
  AppSettings,
  EmergencyContact,
  GeoLocationData,
  SafeRouteSession,
  UserCustomRoute,
} from '../types';
import { SAFEROUTE_PRESETS } from '../constants';
import { InteractiveMap } from './InteractiveMap';
import { calculateDistanceMeters } from '../utils/sosFormatter';
import {
  AlertTriangle,
  BellRing,
  CheckCircle2,
  Clock,
  Compass,
  MapPin,
  Navigation,
  Plus,
  Route,
  ShieldCheck,
  StopCircle,
  Trash2,
  Users,
  X,
} from 'lucide-react';

interface SafeRouteManagerViewProps {
  location: GeoLocationData | null;
  isLocating: boolean;
  onRequestLocation: () => void;
  activeRoute: SafeRouteSession | null;
  contacts: EmergencyContact[];
  settings: AppSettings;
  customRoutes: UserCustomRoute[];
  onSaveCustomRoutes: (routes: UserCustomRoute[]) => void;
  onStartRoute: (params: {
    mode: 'saferoute' | 'accompany';
    destinationName: string;
    destinationAddress: string;
    destinationLat: number;
    destinationLng: number;
    estimatedMinutes: number;
    sharedContactIds: string[];
  }) => void;
  onConfirmSafeInRoute: () => void;
  onSimulateDeviationStep: () => void;
  onMarkArrived: () => void;
  onStopRoute: () => void;
  onNavigateToChat?: () => void;
}

export const SafeRouteManagerView: React.FC<SafeRouteManagerViewProps> = ({
  location,
  isLocating,
  onRequestLocation,
  activeRoute,
  contacts,
  settings,
  customRoutes,
  onSaveCustomRoutes,
  onStartRoute,
  onConfirmSafeInRoute,
  onSimulateDeviationStep,
  onMarkArrived,
  onStopRoute,
  onNavigateToChat,
}) => {
  const authorizedContacts = contacts.filter((c) => c.authorized);

  // Modal for creating custom route
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newRouteName, setNewRouteName] = useState('');
  const [newOriginName, setNewOriginName] = useState('Ubicación actual');
  const [newDestName, setNewDestName] = useState('');
  const [newDestAddress, setNewDestAddress] = useState('');
  const [newDestLat, setNewDestLat] = useState<number>(-2.1894);
  const [newDestLng, setNewDestLng] = useState<number>(-79.8891);
  const [newEstMinutes, setNewEstMinutes] = useState<number>(20);
  const [newToleranceMeters, setNewToleranceMeters] = useState<number>(150);
  const [newSelectedContacts, setNewSelectedContacts] = useState<string[]>(
    authorizedContacts.slice(0, 2).map((c) => c.id)
  );
  const [newNotes, setNewNotes] = useState('');

  // Selected route to start
  const [selectedRouteId, setSelectedRouteId] = useState<string>(
    customRoutes[0]?.id || SAFEROUTE_PRESETS[0].id
  );
  const [startMode, setStartMode] = useState<'saferoute' | 'accompany'>('saferoute');

  const handleCreateRouteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRouteName.trim() || !newDestName.trim()) return;

    const newRoute: UserCustomRoute = {
      id: `route_${Date.now()}`,
      name: newRouteName.trim(),
      originName: newOriginName.trim() || 'Ubicación actual',
      destinationName: newDestName.trim(),
      destinationAddress: newDestAddress.trim() || newDestName.trim(),
      destinationLat: newDestLat,
      destinationLng: newDestLng,
      estimatedMinutes: Number(newEstMinutes) || 20,
      toleranceMeters: Number(newToleranceMeters) || 150,
      sharedContactIds: newSelectedContacts,
      notes: newNotes.trim() || undefined,
    };

    const updated = [newRoute, ...customRoutes];
    onSaveCustomRoutes(updated);
    setSelectedRouteId(newRoute.id);
    setShowCreateModal(false);

    // Reset form
    setNewRouteName('');
    setNewDestName('');
    setNewDestAddress('');
    setNewNotes('');
  };

  const handleDeleteRoute = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customRoutes.filter((r) => r.id !== id);
    onSaveCustomRoutes(updated);
    if (selectedRouteId === id && updated.length > 0) {
      setSelectedRouteId(updated[0].id);
    }
  };

  // Determine target for starting a route
  const currentSelectedRoute = customRoutes.find((r) => r.id === selectedRouteId);
  const currentPreset = SAFEROUTE_PRESETS.find((p) => p.id === selectedRouteId);

  const targetName = currentSelectedRoute?.destinationName || currentPreset?.name || 'Destino';
  const targetAddress =
    currentSelectedRoute?.destinationAddress || currentPreset?.address || 'Guayaquil, Ecuador';
  const targetLat = currentSelectedRoute?.destinationLat ?? currentPreset?.lat ?? -2.1894;
  const targetLng = currentSelectedRoute?.destinationLng ?? currentPreset?.lng ?? -79.8891;
  const targetEstMinutes = currentSelectedRoute?.estimatedMinutes ?? currentPreset?.estimatedMinutes ?? 20;

  const handleLaunchSelectedRoute = () => {
    onStartRoute({
      mode: startMode,
      destinationName: targetName,
      destinationAddress: targetAddress,
      destinationLat: targetLat,
      destinationLng: targetLng,
      estimatedMinutes: targetEstMinutes,
      sharedContactIds: currentSelectedRoute?.sharedContactIds || authorizedContacts.slice(0, 2).map((c) => c.id),
    });
  };

  const distanceToDestMeters =
    location && location.isLive && activeRoute
      ? calculateDistanceMeters(
          location.lat,
          location.lng,
          activeRoute.destinationLat,
          activeRoute.destinationLng
        )
      : null;

  return (
    <div className="space-y-6">
      {/* Header and Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-[#8B5CF6]/15 text-[#8B5CF6] dark:text-[#C4B5FD]">
              <Route className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold text-[#1E1B4B] dark:text-white">
                Ruta Segura y Acompáñame
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Planifica tus trayectos escolares habituales, detecta desvíos y notifica a tus contactos
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowCreateModal(true)}
          className="min-h-[42px] px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-all cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Crear Nueva Ruta</span>
        </button>
      </div>

      {/* ACTIVE ROUTE BANNER (If session is running) */}
      {activeRoute && activeRoute.status === 'active' && (
        <div className="rounded-3xl bg-gradient-to-r from-[#1E1B4B] via-[#2E296B] to-[#1E1B4B] text-white p-5 sm:p-6 shadow-xl border border-[#8B5CF6]/50 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Navigation className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">
                  {activeRoute.mode === 'accompany' ? 'Modo Acompáñame Activo' : 'Ruta Segura en Progreso'}
                </span>
                <h2 className="font-display text-lg font-bold">{activeRoute.destinationName}</h2>
                <p className="text-xs text-[#EDE9FE]/80">{activeRoute.destinationAddress}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onConfirmSafeInRoute}
                className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirmar que estoy a salvo</span>
              </button>

              <button
                type="button"
                onClick={onMarkArrived}
                className="px-3.5 py-2 rounded-xl bg-white text-[#1E1B4B] hover:bg-[#EDE9FE] font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <span>¡He llegado!</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-black/30 p-3 rounded-2xl">
              <p className="text-slate-400 text-[10px]">Distancia estimada:</p>
              <p className="font-bold text-sm text-white">
                {distanceToDestMeters !== null
                  ? distanceToDestMeters > 1000
                    ? `${(distanceToDestMeters / 1000).toFixed(1)} km`
                    : `${distanceToDestMeters} m`
                  : 'Calculando...'}
              </p>
            </div>

            <div className="bg-black/30 p-3 rounded-2xl">
              <p className="text-slate-400 text-[10px]">Próximo check-in en:</p>
              <p className="font-bold text-sm text-white">{activeRoute.nextCheckCountdownSec} seg</p>
            </div>

            <div className="bg-black/30 p-3 rounded-2xl">
              <p className="text-slate-400 text-[10px]">Desvío detectado:</p>
              <p
                className={`font-bold text-sm ${
                  activeRoute.deviationMeters > activeRoute.toleranceMeters
                    ? 'text-rose-400'
                    : 'text-emerald-400'
                }`}
              >
                {activeRoute.deviationMeters} m (Límite: {activeRoute.toleranceMeters} m)
              </p>
            </div>

            <div className="bg-black/30 p-3 rounded-2xl flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-[10px]">Contactos avisados:</p>
                <p className="font-bold text-sm text-white">{activeRoute.sharedContactIds.length}</p>
              </div>
              <button
                type="button"
                onClick={onSimulateDeviationStep}
                title="Simular desvío para probar escalamiento"
                className="p-1.5 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-[10px] font-semibold cursor-pointer"
              >
                Simular desvío
              </button>
            </div>
          </div>

          <div className="flex justify-between items-center pt-1 text-xs">
            <span className="text-slate-300 text-[11px]">
              Tus contactos autorizados pueden ver tu avance en el Chat y recibirán alerta si te desvías.
            </span>
            <button
              type="button"
              onClick={onStopRoute}
              className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
            >
              <StopCircle className="w-3.5 h-3.5" />
              <span>Detener trayecto</span>
            </button>
          </div>
        </div>
      )}

      {/* CATALOG OF USER'S SAVED ROUTES */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
            Mis Rutas Habituales
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            {customRoutes.length} ruta(s) configurada(s)
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {customRoutes.map((route) => {
            const isSelected = selectedRouteId === route.id;
            return (
              <div
                key={route.id}
                onClick={() => setSelectedRouteId(route.id)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer relative ${
                  isSelected
                    ? 'bg-[#EDE9FE]/40 dark:bg-[#1E1B4B]/80 border-[#8B5CF6] shadow-md ring-2 ring-[#8B5CF6]/30'
                    : 'bg-white dark:bg-[#1E1B4B]/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 rounded-lg bg-[#8B5CF6]/15 text-[#8B5CF6] dark:text-[#C4B5FD]">
                        <Compass className="w-4 h-4" />
                      </span>
                      <h3 className="font-display text-sm font-bold text-[#1E1B4B] dark:text-white">
                        {route.name}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 pl-8">
                      <strong>Destino:</strong> {route.destinationName}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 pl-8">
                      {route.destinationAddress}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => handleDeleteRoute(route.id, e)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Eliminar esta ruta"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    <span>~{route.estimatedMinutes} min</span>
                  </span>
                  <span>Tolerancia: ±{route.toleranceMeters}m</span>
                  <span className="flex items-center gap-1 font-semibold text-[#8B5CF6] dark:text-[#C4B5FD]">
                    <Users className="w-3.5 h-3.5" />
                    <span>{route.sharedContactIds.length} contacto(s)</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* START ROUTE CONTROLLER */}
      <div className="rounded-3xl bg-white dark:bg-[#1E1B4B]/50 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
              Iniciar Trayecto Seleccionado: {targetName}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {targetAddress} · Tiempo estimado: {targetEstMinutes} minutos
            </p>
          </div>

          {/* Mode Selector */}
          <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setStartMode('saferoute')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                startMode === 'saferoute'
                  ? 'bg-white dark:bg-[#1E1B4B] text-[#1E1B4B] dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              SafeRoute
            </button>
            <button
              type="button"
              onClick={() => setStartMode('accompany')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                startMode === 'accompany'
                  ? 'bg-white dark:bg-[#1E1B4B] text-[#1E1B4B] dark:text-white shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Acompáñame
            </button>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 text-xs space-y-2 border border-slate-200 dark:border-slate-800">
          <p className="text-slate-700 dark:text-slate-300">
            {startMode === 'saferoute' ? (
              <span>
                <strong>Modo SafeRoute:</strong> Monitorea tu trayecto de forma silenciosa. Si detecta
                una parada prolongada o te desvías más de la tolerancia configurada, te solicitará
                confirmar mediante vibración háptica o escalonará la alerta a tus contactos si no respondes.
              </span>
            ) : (
              <span>
                <strong>Modo Acompáñame:</strong> Comparte tu enlace y progreso de ubicación en vivo
                con tus contactos de confianza en tiempo real por el Chat de NEXA hasta que confirmes
                tu llegada segura.
              </span>
            )}
          </p>
        </div>

        <button
          type="button"
          onClick={handleLaunchSelectedRoute}
          className="w-full min-h-[46px] py-3 px-5 rounded-2xl bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] text-white font-semibold text-sm flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all active:scale-95"
        >
          <Navigation className="w-4 h-4" />
          <span>Iniciar {startMode === 'accompany' ? 'Acompáñame' : 'SafeRoute'} hacia {targetName}</span>
        </button>
      </div>

      {/* MODAL: CREATE CUSTOM ROUTE */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl bg-white dark:bg-[#1E1B4B] text-slate-900 dark:text-[#F8FAFC] p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 my-auto">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Route className="w-5 h-5 text-[#8B5CF6]" />
                <h3 className="font-display text-base font-bold text-[#1E1B4B] dark:text-white">
                  Crear Nueva Ruta de Seguridad
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateRouteSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Nombre descriptivo de la ruta *
                </label>
                <input
                  type="text"
                  required
                  value={newRouteName}
                  onChange={(e) => setNewRouteName(e.target.value)}
                  placeholder="Ej. Casa al Colegio, Colegio al Entrenamiento, etc."
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Punto de partida (Origen)
                  </label>
                  <input
                    type="text"
                    value={newOriginName}
                    onChange={(e) => setNewOriginName(e.target.value)}
                    placeholder="Ej. Casa, Ubicación actual"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Nombre del Destino *
                  </label>
                  <input
                    type="text"
                    required
                    value={newDestName}
                    onChange={(e) => setNewDestName(e.target.value)}
                    placeholder="Ej. Colegio, Biblioteca, Gimnasio"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Dirección o referencia del destino
                </label>
                <input
                  type="text"
                  value={newDestAddress}
                  onChange={(e) => setNewDestAddress(e.target.value)}
                  placeholder="Ej. Av. de las Américas y Callejón 3"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Tiempo estimado (minutos)
                  </label>
                  <input
                    type="number"
                    min="5"
                    max="180"
                    value={newEstMinutes}
                    onChange={(e) => setNewEstMinutes(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                    Tolerancia de desvío (metros)
                  </label>
                  <select
                    value={newToleranceMeters}
                    onChange={(e) => setNewToleranceMeters(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value={100}>100 m (Estricto)</option>
                    <option value={150}>150 m (Recomendado peatonal)</option>
                    <option value={300}>300 m (Transporte urbano / bus)</option>
                    <option value={500}>500 m (Rutas interparroquiales)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1 text-slate-700 dark:text-slate-300">
                  Contactos a notificar en Chat de NEXA
                </label>
                <div className="space-y-1.5 max-h-32 overflow-y-auto p-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  {authorizedContacts.map((c) => {
                    const isChecked = newSelectedContacts.includes(c.id);
                    return (
                      <label
                        key={c.id}
                        className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-200/50 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() =>
                            setNewSelectedContacts((prev) =>
                              prev.includes(c.id)
                                ? prev.filter((id) => id !== c.id)
                                : [...prev, c.id]
                            )
                          }
                          className="rounded text-[#8B5CF6]"
                        />
                        <span>
                          {c.firstName} {c.lastName} ({c.phone})
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-semibold cursor-pointer shadow-sm"
                >
                  Guardar Ruta
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
