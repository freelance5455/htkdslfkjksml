import React, { useState } from 'react';
import {
  AppSettings,
  EmergencyContact,
  GeoLocationData,
  SafeRouteSession,
} from '../types';
import { SAFEROUTE_PRESETS } from '../constants';
import { InteractiveMap } from './InteractiveMap';
import { buildGoogleMapsLink, calculateDistanceMeters } from '../utils/sosFormatter';
import {
  AlertTriangle,
  BellRing,
  CheckCircle2,
  Clock,
  Copy,
  MapPin,
  Navigation,
  Route,
  Share2,
  ShieldCheck,
  StopCircle,
  Users,
} from 'lucide-react';

interface SafeRouteViewProps {
  modeView: 'ubicacion' | 'rutas';
  location: GeoLocationData | null;
  isLocating: boolean;
  onRequestLocation: () => void;
  activeRoute: SafeRouteSession | null;
  contacts: EmergencyContact[];
  settings: AppSettings;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onStartRoute: (params: {
    mode: 'saferoute' | 'accompany';
    destinationName: string;
    destinationAddress: string;
    destinationLat: number;
    destinationLng: number;
    estimatedMinutes: number;
    sharedContactIds: string[];
  }) => void;
  onConfirmSafeInRoute: () => void;
  onSimulateDeviationStep: () => void;
  onMarkArrived: () => void;
  onStopRoute: () => void;
  onLogLocationShared: (recipientCount: number) => void;
}

export const SafeRouteView: React.FC<SafeRouteViewProps> = ({
  modeView,
  location,
  isLocating,
  onRequestLocation,
  activeRoute,
  contacts,
  settings,
  onUpdateSettings,
  onStartRoute,
  onConfirmSafeInRoute,
  onSimulateDeviationStep,
  onMarkArrived,
  onStopRoute,
  onLogLocationShared,
}) => {
  const authorizedContacts = contacts.filter((c) => c.authorized);
  const [selectedPresetId, setSelectedPresetId] = useState(SAFEROUTE_PRESETS[0].id);
  const [routeMode, setRouteMode] = useState<'saferoute' | 'accompany'>('saferoute');
  const [customDestName, setCustomDestName] = useState('');
  const [customLat, setCustomLat] = useState<number | null>(null);
  const [customLng, setCustomLng] = useState<number | null>(null);
  const [estimatedMinutes, setEstimatedMinutes] = useState(20);
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>(
    authorizedContacts.slice(0, 2).map((c) => c.id)
  );
  const [shareCopied, setShareCopied] = useState(false);

  const selectedPreset =
    SAFEROUTE_PRESETS.find((p) => p.id === selectedPresetId) || SAFEROUTE_PRESETS[0];

  const targetLat = customLat !== null ? customLat : selectedPreset.lat;
  const targetLng = customLng !== null ? customLng : selectedPreset.lng;
  const targetName =
    customLat !== null ? customDestName.trim() || 'Destino seleccionado en mapa' : selectedPreset.name;

  const distanceToDestMeters =
    location && location.isLive && activeRoute
      ? calculateDistanceMeters(
          location.lat,
          location.lng,
          activeRoute.destinationLat,
          activeRoute.destinationLng
        )
      : null;

  const toggleContactSelection = (id: string) => {
    setSelectedContactIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleCopyLocationLink = async () => {
    if (!location || !location.isLive) {
      onRequestLocation();
      return;
    }
    const url = buildGoogleMapsLink(location.lat, location.lng);
    try {
      await navigator.clipboard.writeText(
        `Ubicación temporal NEXA (${new Date(location.timestamp).toLocaleTimeString('es-EC')}): ${url}`
      );
      setShareCopied(true);
      onLogLocationShared(selectedContactIds.length || 1);
      setTimeout(() => setShareCopied(false), 3000);
    } catch {
      // ignore
    }
  };

  const handleStartSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStartRoute({
      mode: routeMode,
      destinationName: targetName,
      destinationAddress:
        customLat !== null
          ? `Coordenadas ${targetLat.toFixed(5)}, ${targetLng.toFixed(5)}`
          : selectedPreset.address,
      destinationLat: targetLat,
      destinationLng: targetLng,
      estimatedMinutes,
      sharedContactIds: selectedContactIds,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            {modeView === 'ubicacion'
              ? 'Mi ubicación GPS en tiempo real'
              : 'Ruta Segura (SafeRoute) y Modo Acompáñame'}
          </h1>
          <p className="text-xs text-[#EDE9FE]/80 mt-1">
            {modeView === 'ubicacion'
              ? 'Consulta tus coordenadas reales, precisión del sensor y comparte un enlace temporal solo cuando lo necesites.'
              : 'Seguimiento temporal con confirmación escalonada en 3 niveles para evitar falsas alarmas por simples cambios de calle.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onRequestLocation}
            disabled={isLocating}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#161338] border border-[#8B5CF6]/40 hover:border-[#8B5CF6] text-white text-xs font-semibold flex items-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <Navigation className="w-4 h-4 text-[#C4B5FD]" />
            <span>{isLocating ? 'Actualizando GPS...' : 'Actualizar GPS'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopyLocationLink}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md transition-all active:scale-95"
          >
            {shareCopied ? <Copy className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
            <span>{shareCopied ? '¡Enlace copiado!' : 'Compartir enlace GPS'}</span>
          </button>
        </div>
      </div>

      {activeRoute && activeRoute.status === 'active' && activeRoute.escalationLevel > 0 && (
        <div
          className={`rounded-3xl p-5 border-2 shadow-lg space-y-3 ${
            activeRoute.escalationLevel === 1
              ? 'bg-amber-950/70 border-amber-400 text-amber-100'
              : activeRoute.escalationLevel === 2
              ? 'bg-orange-950/80 border-orange-500 text-orange-100'
              : 'bg-red-950/80 border-red-600 text-red-100'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <BellRing className="w-6 h-6 shrink-0 mt-0.5 text-amber-300" />
              <div>
                <h2 className="font-display text-base font-extrabold text-white">
                  {activeRoute.escalationLevel === 1 &&
                    'Nivel 1 — Confirmación discreta: ¿Sigues bien en tu ruta?'}
                  {activeRoute.escalationLevel === 2 &&
                    'Nivel 2 — Segunda confirmación requerida antes de avisar a tus contactos'}
                  {activeRoute.escalationLevel === 3 &&
                    'Nivel 3 — Alerta enviada a tus contactos autorizados por falta de confirmación'}
                </h2>
                <p className="text-xs mt-1 leading-relaxed text-[#EDE9FE]/90">
                  {activeRoute.escalationLevel === 1 &&
                    `Se detectó una desviación superior al margen configurado (±${activeRoute.toleranceMeters} m) o tiempo de control cumplido. Se activó vibración discreta.`}
                  {activeRoute.escalationLevel === 2 &&
                    'No recibimos respuesta al primer aviso. Confirma ahora que estás bien para cancelar el aviso a tus contactos.'}
                  {activeRoute.escalationLevel === 3 &&
                    'Se ha notificado preventivamente a los contactos compartidos de tu Ruta Segura.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={onConfirmSafeInRoute}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Estoy bien · Seguir en ruta</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7 space-y-4">
          <InteractiveMap
            location={location}
            activeRoute={activeRoute}
            onRequestLocation={onRequestLocation}
            isLocating={isLocating}
            heightClass="h-80 sm:h-96"
            onSelectCustomDestination={(lat, lng) => {
              setCustomLat(lat);
              setCustomLng(lng);
              if (!customDestName) {
                setCustomDestName('Punto seleccionado en el mapa');
              }
            }}
          />

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-2xl bg-[#161338] border border-[#8B5CF6]/30 p-3.5 shadow-md">
              <p className="text-[11px] text-[#C4B5FD]">Estado del GPS</p>
              <p className="font-display text-xs font-bold text-white mt-1">
                {location?.isLive
                  ? 'Señal Real Activa'
                  : location?.permissionStatus === 'denied'
                  ? 'Permiso Denegado'
                  : 'Esperando Permiso'}
              </p>
            </div>

            <div className="rounded-2xl bg-[#161338] border border-[#8B5CF6]/30 p-3.5 shadow-md">
              <p className="text-[11px] text-[#C4B5FD]">Coordenadas</p>
              <p className="font-mono-tabular text-xs font-semibold text-white mt-1 truncate">
                {location?.isLive
                  ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
                  : 'No disponible'}
              </p>
            </div>

            <div className="rounded-2xl bg-[#161338] border border-[#8B5CF6]/30 p-3.5 shadow-md">
              <p className="text-[11px] text-[#C4B5FD]">Precisión GPS</p>
              <p className="font-mono-tabular text-xs font-semibold text-white mt-1">
                {location?.isLive ? `±${Math.round(location.accuracy)} metros` : '—'}
              </p>
            </div>

            <div className="rounded-2xl bg-[#161338] border border-[#8B5CF6]/30 p-3.5 shadow-md">
              <p className="text-[11px] text-[#C4B5FD]">Última lectura</p>
              <p className="font-mono-tabular text-xs font-semibold text-white mt-1">
                {location?.isLive
                  ? new Date(location.timestamp).toLocaleTimeString('es-EC')
                  : 'Sin lectura'}
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-4">
          {activeRoute && activeRoute.status === 'active' ? (
            <div className="rounded-3xl bg-[#161338] border-2 border-[#8B5CF6] p-5 sm:p-6 space-y-5 shadow-xl">
              <div className="flex items-center justify-between border-b border-[#8B5CF6]/30 pb-3">
                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C4B5FD]">
                    {activeRoute.mode === 'accompany'
                      ? 'Modo Acompáñame Activo'
                      : 'Ruta Segura (SafeRoute) Activa'}
                  </span>
                  <h2 className="font-display text-lg font-bold text-white mt-0.5">
                    {activeRoute.destinationName}
                  </h2>
                </div>
                <Route className="w-6 h-6 text-[#8B5CF6]" />
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between text-[#EDE9FE]/90">
                  <span>Inicio del recorrido:</span>
                  <span className="font-mono-tabular font-semibold text-white">
                    {new Date(activeRoute.startedAt).toLocaleTimeString('es-EC', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[#EDE9FE]/90">
                  <span>Llegada estimada:</span>
                  <span className="font-mono-tabular font-semibold text-white">
                    {new Date(activeRoute.estimatedArrivalAt).toLocaleTimeString('es-EC', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[#EDE9FE]/90">
                  <span>Margen de tolerancia GPS:</span>
                  <span className="font-mono-tabular font-semibold text-white">
                    ±{activeRoute.toleranceMeters} m
                  </span>
                </div>

                {distanceToDestMeters !== null && (
                  <div className="flex items-center justify-between text-[#EDE9FE]/90">
                    <span>Distancia actual al destino:</span>
                    <span className="font-mono-tabular font-semibold text-[#C4B5FD]">
                      {distanceToDestMeters > 1000
                        ? `${(distanceToDestMeters / 1000).toFixed(2)} km`
                        : `${distanceToDestMeters} m`}
                    </span>
                  </div>
                )}

                <div className="flex items-center justify-between text-[#EDE9FE]/90">
                  <span>Nivel de escalamiento actual:</span>
                  <span className="font-semibold text-white">
                    Nivel {activeRoute.escalationLevel} de 3
                  </span>
                </div>
              </div>

              <div className="rounded-2xl bg-[#1E1B4B] border border-[#8B5CF6]/30 p-3.5 space-y-2">
                <p className="text-xs font-semibold text-[#C4B5FD] flex items-center gap-1.5">
                  <Users className="w-4 h-4" />
                  <span>Compartiendo recorrido temporalmente con:</span>
                </p>
                <div className="flex flex-wrap gap-2 text-xs text-[#EDE9FE]">
                  {contacts
                    .filter((c) => activeRoute.sharedContactIds.includes(c.id))
                    .map((c) => (
                      <span key={c.id} className="font-semibold bg-[#161338] px-2.5 py-1 rounded-lg border border-[#8B5CF6]/30">
                        {c.firstName} {c.lastName}
                      </span>
                    ))}
                </div>
              </div>

              <div className="space-y-2.5 pt-2">
                <button
                  type="button"
                  onClick={onMarkArrived}
                  className="w-full min-h-[48px] py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-lg"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Modo &ldquo;Llegué&rdquo; · Confirmar llegada y finalizar seguimiento</span>
                </button>

                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={onConfirmSafeInRoute}
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer border border-white/10 transition-colors"
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>Confirmar &ldquo;Sigo bien&rdquo;</span>
                  </button>

                  <button
                    type="button"
                    onClick={onSimulateDeviationStep}
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-amber-950/70 border border-amber-500/50 text-amber-200 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer hover:bg-amber-900/80 transition-colors"
                    title="Avanza del Nivel 0 -> Nivel 1 -> Nivel 2 -> Nivel 3 para demostrar el escalamiento SafeRoute"
                  >
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>
                      Probar Nivel {Math.min(3, activeRoute.escalationLevel + 1)} SafeRoute
                    </span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={onStopRoute}
                  className="w-full min-h-[42px] py-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 border border-red-500/30 text-red-200 text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                >
                  <StopCircle className="w-4 h-4 text-red-400" />
                  <span>Cancelar recorrido y dejar de compartir ubicación</span>
                </button>
              </div>
            </div>
          ) : (
            <form
              onSubmit={handleStartSubmit}
              className="rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-5 sm:p-6 space-y-4 shadow-md"
            >
              <div className="flex items-center justify-between border-b border-[#8B5CF6]/20 pb-3">
                <h2 className="font-display text-base font-bold text-white">
                  Configurar nuevo recorrido
                </h2>
                <span className="text-[11px] text-[#C4B5FD]">Seguimiento con consentimiento</span>
              </div>

              <div className="grid grid-cols-2 gap-1.5 p-1 bg-[#100D2B] rounded-xl border border-[#8B5CF6]/20">
                <button
                  type="button"
                  onClick={() => setRouteMode('saferoute')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    routeMode === 'saferoute'
                      ? 'bg-[#8B5CF6] text-white shadow-md'
                      : 'text-[#EDE9FE]/70 hover:text-white'
                  }`}
                >
                  Ruta Segura (SafeRoute)
                </button>
                <button
                  type="button"
                  onClick={() => setRouteMode('accompany')}
                  className={`py-2 px-3 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    routeMode === 'accompany'
                      ? 'bg-[#8B5CF6] text-white shadow-md'
                      : 'text-[#EDE9FE]/70 hover:text-white'
                  }`}
                >
                  Modo Acompáñame
                </button>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-[#EDE9FE]">
                  Destino frecuente (o toca el mapa para elegir otro punto)
                </label>
                <select
                  value={selectedPresetId}
                  onChange={(e) => {
                    setSelectedPresetId(e.target.value);
                    setCustomLat(null);
                    setCustomLng(null);
                    const found = SAFEROUTE_PRESETS.find((p) => p.id === e.target.value);
                    if (found) setEstimatedMinutes(found.estimatedMinutes);
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/40 text-xs text-white focus:outline-none focus:border-[#8B5CF6]"
                >
                  {SAFEROUTE_PRESETS.map((preset) => (
                    <option key={preset.id} value={preset.id} className="bg-[#1E1B4B] text-white">
                      {preset.name} ({preset.estimatedMinutes} min aprox.)
                    </option>
                  ))}
                </select>
              </div>

              {customLat !== null && customLng !== null && (
                <div className="rounded-xl bg-[#1E1B4B] p-3 border border-[#8B5CF6]/40 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-[#C4B5FD] flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
                      Destino personalizado ({customLat.toFixed(4)}, {customLng.toFixed(4)})
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setCustomLat(null);
                        setCustomLng(null);
                      }}
                      className="text-[11px] text-[#C4B5FD] hover:underline cursor-pointer"
                    >
                      Usar lista
                    </button>
                  </div>
                  <input
                    type="text"
                    value={customDestName}
                    onChange={(e) => setCustomDestName(e.target.value)}
                    placeholder="Nombre del destino"
                    className="w-full px-3 py-1.5 rounded-lg bg-[#161338] border border-[#8B5CF6]/30 text-xs text-white placeholder-[#EDE9FE]/40"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#EDE9FE] mb-1">
                    Tiempo estimado (min)
                  </label>
                  <div className="relative">
                    <Clock className="w-3.5 h-3.5 text-[#C4B5FD] absolute left-3 top-3" />
                    <input
                      type="number"
                      min={5}
                      max={180}
                      value={estimatedMinutes}
                      onChange={(e) => setEstimatedMinutes(Number(e.target.value) || 20)}
                      className="w-full pl-8 pr-3 py-2 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/40 text-xs font-mono-tabular text-white focus:outline-none focus:border-[#8B5CF6]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#EDE9FE] mb-1">
                    Margen de desviación (m)
                  </label>
                  <input
                    type="number"
                    min={50}
                    max={500}
                    step={25}
                    value={settings.safeRouteToleranceMeters}
                    onChange={(e) =>
                      onUpdateSettings({
                        safeRouteToleranceMeters: Math.max(50, Number(e.target.value) || 150),
                      })
                    }
                    className="w-full px-3 py-2 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/40 text-xs font-mono-tabular text-white focus:outline-none focus:border-[#8B5CF6]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-[#EDE9FE]">
                  Contactos autorizados que acompañarán tu recorrido:
                </label>
                <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                  {authorizedContacts.map((c) => (
                    <label
                      key={c.id}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-[#1E1B4B] border border-[#8B5CF6]/30 text-xs cursor-pointer hover:border-[#8B5CF6]"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedContactIds.includes(c.id)}
                          onChange={() => toggleContactSelection(c.id)}
                          className="rounded text-[#8B5CF6]"
                        />
                        <span className="font-semibold text-white">
                          {c.firstName} {c.lastName}
                        </span>
                      </div>
                      <span className="text-[11px] text-[#C4B5FD]">Prioridad #{c.priority}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl bg-[#1E1B4B] p-3 text-[11px] text-[#EDE9FE]/85 space-y-1 leading-relaxed border border-[#8B5CF6]/20">
                <p className="font-bold text-white">
                  Confirmación escalonada (Cero falsas alarmas):
                </p>
                <p>
                  <strong>Nivel 1:</strong> Aviso discreto y vibración táctil si hay desviación ±
                  {settings.safeRouteToleranceMeters}m. <strong>Nivel 2:</strong> Segunda confirmación ({settings.safeRouteLevel1WaitSec}s). <strong>Nivel 3:</strong>{' '}
                  Alerta automática a los contactos seleccionados.
                </p>
              </div>

              <button
                type="submit"
                className="w-full min-h-[48px] py-3 rounded-2xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white font-bold text-sm flex items-center justify-center gap-2 transition-transform active:scale-95 cursor-pointer shadow-lg"
              >
                <Route className="w-4 h-4" />
                <span>
                  {routeMode === 'accompany'
                    ? 'Iniciar Modo Acompáñame ahora'
                    : 'Iniciar Ruta Segura (SafeRoute)'}
                </span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
