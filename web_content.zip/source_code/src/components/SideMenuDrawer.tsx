import React from 'react';
import { NavigationTab, UserAccount } from '../types';
import { NexaLogo } from './NexaLogo';
import {
  AlertOctagon,
  ArrowRight,
  Bell,
  Bluetooth,
  CheckCircle2,
  ChevronRight,
  Download,
  GraduationCap,
  History,
  Home,
  LogOut,
  MapPin,
  MessageCircle,
  Moon,
  Route,
  Settings,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sun,
  Users,
  X,
  Zap,
} from 'lucide-react';

interface SideMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  user: UserAccount;
  unreadMessageCount?: number;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onOpenDownloadModal: () => void;
  onOpenPermissionsModal?: () => void;
  onLogout: () => void;
  onTriggerSos: () => void;
}

export const SideMenuDrawer: React.FC<SideMenuDrawerProps> = ({
  isOpen,
  onClose,
  activeTab,
  onNavigate,
  user,
  unreadMessageCount = 0,
  darkMode,
  onToggleDarkMode,
  onOpenDownloadModal,
  onOpenPermissionsModal,
  onLogout,
  onTriggerSos,
}) => {
  if (!isOpen) return null;

  const handleItemClick = (tab: NavigationTab) => {
    onNavigate(tab);
    onClose();
  };

  const userInitial = user.fullName ? user.fullName.trim().charAt(0).toUpperCase() : 'U';

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop overlay */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 animate-in fade-in"
        aria-hidden="true"
      />

      {/* Slide-over Drawer (Left Side, Facebook style) */}
      <div className="fixed inset-y-0 left-0 max-w-full flex">
        <aside
          role="dialog"
          aria-label="Menú principal de opciones"
          className="w-80 sm:w-96 max-w-[88vw] bg-[#0F1424] text-white shadow-2xl border-r border-white/10 flex flex-col justify-between overflow-y-auto animate-in slide-in-from-left duration-300"
        >
          {/* Header & User Profile section */}
          <div className="p-5 border-b border-white/10 bg-gradient-to-b from-[#1E1B4B] to-[#0F1424]">
            <div className="flex items-center justify-between mb-4">
              <NexaLogo variant="horizontal" theme="dark" size="sm" showTagline={false} />
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
                aria-label="Cerrar menú"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Card (Facebook style) */}
            <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-white/5 border border-white/10">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9] text-white flex items-center justify-center font-display font-black text-lg shadow-md shrink-0 border border-white/20">
                {userInitial}
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-display text-sm font-bold text-white truncate">
                  {user.fullName || 'Usuario NEXA'}
                </p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="text-[11px] font-semibold text-[#C4B5FD] flex items-center gap-1">
                    {user.isStudent !== false ? (
                      <>
                        <GraduationCap className="w-3 h-3 text-[#A78BFA]" />
                        <span>Estudiante</span>
                      </>
                    ) : (
                      <>
                        <Shield className="w-3 h-3 text-emerald-400" />
                        <span>Contacto Apoyo</span>
                      </>
                    )}
                  </span>
                  <span className="text-[10px] text-slate-400 truncate">
                    · {user.phone || '0991234567'}
                  </span>
                </div>
                {user.institution && (
                  <p className="text-[10px] text-slate-400 truncate mt-0.5">
                    {user.institution}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Navigation Links and Sections */}
          <div className="p-4 space-y-6 flex-1">
            {/* 1. SECCIÓN PRINCIPAL */}
            <div className="space-y-1">
              <p className="px-3 text-[10px] font-black uppercase tracking-wider text-[#A78BFA]">
                Menú Principal
              </p>

              <button
                type="button"
                onClick={() => handleItemClick('inicio')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'inicio'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'inicio' ? 'bg-white/20' : 'bg-white/5 text-[#A78BFA]'}`}>
                    <Home className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Inicio</p>
                    <p className="text-[11px] opacity-75">Botón SOS y estado de seguridad</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('rutas')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'rutas'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'rutas' ? 'bg-white/20' : 'bg-white/5 text-[#A78BFA]'}`}>
                    <Route className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Rutas Seguras</p>
                    <p className="text-[11px] opacity-75">SafeRoute y monitoreo en trayecto</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('ubicacion')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'ubicacion'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'ubicacion' ? 'bg-white/20' : 'bg-white/5 text-emerald-400]'}`}>
                    <MapPin className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Mi Ubicación</p>
                    <p className="text-[11px] opacity-75">GPS en vivo y zonas seguras</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('mensajes')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'mensajes'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center relative ${activeTab === 'mensajes' ? 'bg-white/20' : 'bg-white/5 text-sky-400'}`}>
                    <MessageCircle className="w-4 h-4" />
                    {unreadMessageCount > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                        {unreadMessageCount}
                      </span>
                    )}
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Mensajes & Chat</p>
                    <p className="text-[11px] opacity-75">Alertas y llamadas de voz</p>
                  </div>
                </div>
                {unreadMessageCount > 0 ? (
                  <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white font-bold text-[10px]">
                    {unreadMessageCount} nuevo{unreadMessageCount > 1 ? 's' : ''}
                  </span>
                ) : (
                  <ChevronRight className="w-4 h-4 opacity-50" />
                )}
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('contactos')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'contactos'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'contactos' ? 'bg-white/20' : 'bg-white/5 text-amber-400'}`}>
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Contactos de Confianza</p>
                    <p className="text-[11px] opacity-75">Tutores y red de auxilio</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>
            </div>

            {/* 2. HERRAMIENTAS Y CONFIGURACIÓN */}
            <div className="space-y-1">
              <p className="px-3 text-[10px] font-black uppercase tracking-wider text-[#A78BFA]">
                Herramientas y Wearables
              </p>

              <button
                type="button"
                onClick={() => handleItemClick('dispositivo')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'dispositivo'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'dispositivo' ? 'bg-white/20' : 'bg-white/5 text-blue-400'}`}>
                    <Bluetooth className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">NEXA Core (BLE)</p>
                    <p className="text-[11px] opacity-75">Conectar botón físico wearable</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('alerta_config')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'alerta_config'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'alerta_config' ? 'bg-white/20' : 'bg-white/5 text-rose-400'}`}>
                    <Settings className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Configuración de Alerta</p>
                    <p className="text-[11px] opacity-75">Mensaje SOS, tono y 0dB silencioso</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              <button
                type="button"
                onClick={() => handleItemClick('actividad')}
                className={`w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs transition-all cursor-pointer ${
                  activeTab === 'actividad'
                    ? 'bg-[#8B5CF6] text-white shadow-md'
                    : 'text-slate-200 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${activeTab === 'actividad' ? 'bg-white/20' : 'bg-white/5 text-slate-300'}`}>
                    <History className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm">Historial de Actividad</p>
                    <p className="text-[11px] opacity-75">Registro de eventos y alertas</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>

              {/* Botón Permisos y Alertas */}
              {onOpenPermissionsModal && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenPermissionsModal();
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs text-slate-200 hover:bg-white/5 hover:text-white transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
                      <ShieldAlert className="w-4 h-4" />
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-sm">Permisos de Emergencia</p>
                      <p className="text-[11px] opacity-75">Notificaciones, sirena y pantalla</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </button>
              )}

              {/* Botón Descargar App */}
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenDownloadModal();
                }}
                className="w-full flex items-center justify-between p-3 rounded-2xl font-semibold text-xs bg-gradient-to-r from-emerald-500/20 to-[#8B5CF6]/20 border border-emerald-500/30 text-emerald-200 hover:brightness-110 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/30 text-emerald-300 flex items-center justify-center">
                    <Download className="w-4 h-4" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm text-white">Instalar Aplicación</p>
                    <p className="text-[11px] text-emerald-300/80">iPhone (iOS), Android o PC</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-emerald-400" />
              </button>
            </div>
          </div>

          {/* Footer Controls: Theme Toggle & Logout */}
          <div className="p-4 border-t border-white/10 bg-black/40 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={onToggleDarkMode}
                className="flex-1 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-[#EDE9FE] flex items-center justify-center gap-2 transition-colors cursor-pointer border border-white/10"
              >
                {darkMode ? (
                  <>
                    <Sun className="w-4 h-4 text-amber-400" />
                    <span>Modo Día</span>
                  </>
                ) : (
                  <>
                    <Moon className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Modo Noche</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onLogout();
                }}
                className="py-2 px-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Cerrar sesión"
              >
                <LogOut className="w-4 h-4" />
                <span>Salir</span>
              </button>
            </div>

            <p className="text-[10px] text-center text-slate-500 pt-1">
              NEXA Student Safety Network · 2026
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
};
