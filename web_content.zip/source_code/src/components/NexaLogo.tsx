import React from 'react';
import { WearableFormat } from '../types';

interface NexaLogoProps {
  variant?: 'horizontal' | 'icon' | 'vertical';
  theme?: 'light' | 'dark' | 'auto';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showTagline?: boolean;
  className?: string;
}

export const NexaSymbol: React.FC<{ className?: string; size?: number }> = ({
  className = '',
  size = 36,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 64 64"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-label="Símbolo NEXA"
  >
    <circle cx="32" cy="11.5" r="5.5" fill="#8B5CF6" />
    <path
      d="M13 18.5L26.5 34C28.8 36.6 28.8 40.4 26.5 43L13 58.5"
      stroke="#8B5CF6"
      strokeWidth="7.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      d="M51 18.5L37.5 34C35.2 36.6 35.2 40.4 37.5 43L51 58.5"
      stroke="#C4B5FD"
      strokeWidth="7.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const NexaLogo: React.FC<NexaLogoProps> = ({
  variant = 'horizontal',
  theme = 'auto',
  size = 'md',
  showTagline = true,
  className = '',
}) => {
  const sizeMap = {
    sm: { text: 'text-xl', sub: 'text-[7px] tracking-[0.26em]', icon: 24, box: 'w-8 h-8 rounded-xl' },
    md: { text: 'text-2xl', sub: 'text-[8px] tracking-[0.28em]', icon: 30, box: 'w-10 h-10 rounded-xl' },
    lg: { text: 'text-4xl', sub: 'text-[10px] tracking-[0.32em]', icon: 42, box: 'w-14 h-14 rounded-2xl' },
    xl: { text: 'text-5xl', sub: 'text-[11px] tracking-[0.34em]', icon: 54, box: 'w-16 h-16 rounded-2xl' },
  }[size];

  const textColor =
    theme === 'dark'
      ? 'text-[#F8FAFC]'
      : theme === 'light'
      ? 'text-[#1E1B4B]'
      : 'text-[#1E1B4B] dark:text-[#F8FAFC]';

  const subColor =
    theme === 'dark'
      ? 'text-[#C4B5FD]'
      : theme === 'light'
      ? 'text-[#1E1B4B]/80'
      : 'text-[#1E1B4B]/80 dark:text-[#C4B5FD]';

  if (variant === 'icon') {
    return (
      <div
        className={`inline-flex items-center justify-center bg-[#1E1B4B] shadow-md shadow-[#1E1B4B]/20 shrink-0 ${sizeMap.box} ${className}`}
      >
        <NexaSymbol size={sizeMap.icon * 0.78} />
      </div>
    );
  }

  return (
    <div
      className={`inline-flex flex-col ${
        variant === 'vertical' ? 'items-start' : 'items-center'
      } select-none ${className}`}
    >
      <div className="inline-flex items-center font-display font-extrabold tracking-tight leading-none">
        <span className={`${sizeMap.text} ${textColor}`}>NE</span>
        <NexaSymbol size={sizeMap.icon} className="-mx-0.5 -mt-1" />
        <span className={`${sizeMap.text} ${textColor}`}>A</span>
      </div>
      {showTagline && (
        <span
          className={`font-display font-semibold uppercase mt-1 whitespace-nowrap ${sizeMap.sub} ${subColor}`}
        >
          STUDENT SAFETY NETWORK
        </span>
      )}
    </div>
  );
};

export const WearableIllustration: React.FC<{
  format: WearableFormat;
  isActive?: boolean;
  ledColor?: string;
  className?: string;
}> = ({ format, isActive = false, ledColor = '#8B5CF6', className = 'w-28 h-28' }) => {
  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <radialGradient id={`ledGlow-${format}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor={ledColor} stopOpacity="1" />
          <stop offset="100%" stopColor={ledColor} stopOpacity="0" />
        </radialGradient>
        <linearGradient id="coreBodyDark" x1="25" y1="20" x2="95" y2="100" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#2E2A5A" />
          <stop offset="50%" stopColor="#1B1938" />
          <stop offset="100%" stopColor="#0F172A" />
        </linearGradient>
        <linearGradient id="lavenderBody" x1="25" y1="25" x2="95" y2="95" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#EDE9FE" />
          <stop offset="60%" stopColor="#C4B5FD" />
          <stop offset="100%" stopColor="#A78BFA" />
        </linearGradient>
      </defs>

      {format === 'loop' && (
        <>
          <path
            d="M42 8H78L82 32H38L42 8Z"
            fill="#1E1B4B"
            stroke="#4C1D95"
            strokeWidth="1.5"
          />
          <path
            d="M38 88H82L78 112H42L38 88Z"
            fill="#1E1B4B"
            stroke="#4C1D95"
            strokeWidth="1.5"
          />
          <rect
            x="28"
            y="24"
            width="64"
            height="72"
            rx="32"
            fill="url(#coreBodyDark)"
            stroke="#8B5CF6"
            strokeWidth="2"
          />
          <rect x="92" y="50" width="4" height="18" rx="2" fill="#8B5CF6" />
          <ellipse cx="60" cy="60" rx="23" ry="27" stroke="#475569" strokeWidth="1.2" />
          <text
            x="60"
            y="58"
            textAnchor="middle"
            fill="#C4B5FD"
            fontSize="9"
            fontFamily="Montserrat, sans-serif"
            fontWeight="700"
            letterSpacing="1.5"
          >
            NEXA
          </text>
          <circle cx="60" cy="78" r="7" fill={`url(#ledGlow-${format})`} />
          <circle cx="60" cy="78" r="2.8" fill={isActive ? '#F8FAFC' : ledColor} />
        </>
      )}

      {format === 'pin' && (
        <>
          <circle cx="60" cy="20" r="5" stroke="#94A3B8" strokeWidth="2.5" />
          <circle
            cx="60"
            cy="63"
            r="38"
            fill="url(#lavenderBody)"
            stroke="#8B5CF6"
            strokeWidth="2"
          />
          <circle cx="60" cy="63" r="31" stroke="#F8FAFC" strokeOpacity="0.6" strokeWidth="1.2" />
          <circle cx="60" cy="44" r="5.5" fill="#6D28D9" />
          <text
            x="60"
            y="67"
            textAnchor="middle"
            fill="#1E1B4B"
            fontSize="10"
            fontFamily="Montserrat, sans-serif"
            fontWeight="800"
            letterSpacing="1.5"
          >
            NEXA
          </text>
          <circle cx="60" cy="84" r="6" fill={`url(#ledGlow-${format})`} />
          <circle cx="60" cy="84" r="2.5" fill={ledColor} />
        </>
      )}

      {format === 'nova' && (
        <>
          <path d="M40 6L56 26M80 6L64 26" stroke="#334155" strokeWidth="3" strokeLinecap="round" />
          <rect x="54" y="21" width="12" height="10" rx="4" fill="#1E293B" stroke="#64748B" strokeWidth="1.5" />
          <ellipse
            cx="60"
            cy="67"
            rx="30"
            ry="39"
            fill="url(#coreBodyDark)"
            stroke="#8B5CF6"
            strokeWidth="2"
          />
          <ellipse cx="60" cy="67" rx="23" ry="31" stroke="#334155" strokeWidth="1.2" />
          <text
            x="60"
            y="66"
            textAnchor="middle"
            fill="#C4B5FD"
            fontSize="9.5"
            fontFamily="Montserrat, sans-serif"
            fontWeight="700"
            letterSpacing="1.5"
          >
            NEXA
          </text>
          <circle cx="60" cy="87" r="7" fill={`url(#ledGlow-${format})`} />
          <circle cx="60" cy="87" r="2.8" fill={isActive ? '#F8FAFC' : ledColor} />
        </>
      )}

      {format === 'clip' && (
        <>
          <path
            d="M48 32V16C48 10.5 52.5 6 58 6H64C69.5 6 74 10.5 74 16V28"
            stroke="#334155"
            strokeWidth="4.5"
            strokeLinecap="round"
          />
          <path d="M72 44L88 52V98L72 92" fill="#475569" opacity="0.65" />
          <rect
            x="28"
            y="29"
            width="56"
            height="74"
            rx="24"
            fill="url(#coreBodyDark)"
            stroke="#8B5CF6"
            strokeWidth="2"
          />
          <rect x="35" y="37" width="42" height="58" rx="18" stroke="#334155" strokeWidth="1.2" />
          <text
            x="56"
            y="66"
            textAnchor="middle"
            fill="#C4B5FD"
            fontSize="9"
            fontFamily="Montserrat, sans-serif"
            fontWeight="700"
            letterSpacing="1.5"
          >
            NEXA
          </text>
          <circle cx="56" cy="84" r="7" fill={`url(#ledGlow-${format})`} />
          <circle cx="56" cy="84" r="2.8" fill={isActive ? '#F8FAFC' : ledColor} />
        </>
      )}
    </svg>
  );
};
