import React from 'react';
import {
  EmergencyContact,
  GeoLocationData,
  NavigationTab,
  NexaDeviceState,
  SafeRouteSession,
  SafetyState,
  UserAccount,
} from '../types';
import { SAFETY_STATE_META, WEARABLE_FORMATS } from '../constants';
import { NexaLogo, WearableIllustration } from './NexaLogo';
import {
  AlertOctagon,
  BatteryCharging,
  Bluetooth,
  CheckCircle2,
  Clock,
  Download,
  MapPin,
  MessageCircle,
  Phone,
  Route,
  Shield,
  ShieldCheck,
  Smartphone,
  Users,
  Zap,
} from 'lucide-react';

interface HomeDashboardViewProps {
  user: UserAccount;
  safetyState: SafetyState;
  location: GeoLocationData | null;
  isLocating: boolean;
  isOnline: boolean;
  device: NexaDeviceState;
  contacts: EmergencyContact[];
  activeRoute: SafeRouteSession | null;
  holdDurationMs: number;
  onTriggerSos: (isTest?: boolean) => void;
  onRequestLocation: () => void;
  onNavigate: (tab: NavigationTab) => void;
  onConfirmSafeInRoute: () => void;
  onMarkArrived: () => void;
  onOpenDownloadModal?: () => void;
}

export const HomeDashboardView: React.FC<HomeDashboardViewProps> = ({
  user,
  safetyState,
  location,
  isLocating,
  isOnline,
  device,
  contacts,
  activeRoute,
  onTriggerSos,
  onRequestLocation,
  onNavigate,
  onConfirmSafeInRoute,
  onMarkArrived,
  onOpenDownloadModal,
}) => {
  const stateMeta = SAFETY_STATE_META[safetyState];
  const authorizedSosCount = contacts.filter((c) => c.authorized && c.receiveSos).length;
  const isDeviceConnected =
    device.connectionStatus === 'connected_real_ble' ||
    device.connectionStatus === 'connected_demo';

  const currentFormatInfo =
    WEARABLE_FORMATS.find((f) => f.id === device.selectedFormat) || WEARABLE_FORMATS[0];

  const handleInstantSosClick = () => {
    if ('vibrate' in navigator) {
      try {
        navigator.vibrate([180, 80, 180]);
      } catch {}
    }
    onTriggerSos(false);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Clean Greeting Header (No clutter) */}
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#A78BFA] mb-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Protección estudiantil activa</span>
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-black text-white">
            Hola, {user.fullName && !user.fullName.toLowerCase().includes('damaris') ? user.fullName.trim() : 'Usuario'}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            {user.institution?.trim()
              ? `${user.institution.trim()} · ${user.gradeOrRole || 'Estudiante'}`
              : 'Red de Seguridad Personal · Alerta Discreta 0dB'}
          </p>
        </div>

        {/* State Badge */}
        <div className={`px-3 py-1.5 rounded-2xl border text-xs font-bold flex items-center gap-2 ${stateMeta.surfaceClass}`}>
          <div className={`w-2.5 h-2.5 rounded-full ${stateMeta.bgClass} animate-pulse`} />
          <span className={stateMeta.textClass}>{stateMeta.label}</span>
        </div>
      </div>

      {/* Active Route Notification (if ongoing) */}
      {activeRoute && (
        <div className="rounded-2xl bg-gradient-to-r from-[#8B5CF6]/20 to-emerald-500/20 border border-emerald-500/40 p-4 flex items-center justify-between gap-3 shadow-md animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0">
              <Route className="w-5 h-5" />
            </div>
            <div>
              <p className="font-display text-xs font-bold text-white">
                Ruta Segura Activa: {activeRoute.destinationName}
              </p>
              <p className="text-[11px] text-slate-300">
                Llegada estimada:{' '}
                {new Date(activeRoute.estimatedArrivalAt).toLocaleTimeString('es-EC', {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onConfirmSafeInRoute}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold cursor-pointer"
            >
              Sigo bien
            </button>
            <button
              type="button"
              onClick={onMarkArrived}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer shadow-sm"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Llegué</span>
            </button>
          </div>
        </div>
      )}

      {/* Main SOS Emergency Center (Clean, spacious, tactile) */}
      <div className="rounded-3xl bg-gradient-to-b from-[#1E1B4B] via-[#161338] to-[#0F1424] text-white p-6 sm:p-10 flex flex-col items-center justify-center text-center shadow-2xl border border-[#8B5CF6]/40 relative overflow-hidden">
        {/* Soft background ambient glow */}
        <div
          className="pointer-events-none absolute inset-0 opacity-20"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, rgba(139, 92, 246, 0.6) 0%, transparent 65%)',
          }}
        />

        <div className="z-10 space-y-1 mb-6">
          <h2 className="font-display text-lg sm:text-xl font-black text-white">
            Botón de Emergencia Inmediato
          </h2>
          <p className="text-xs text-[#EDE9FE]/80 max-w-md mx-auto">
            1 Solo Toque · Silencioso para ti (0dB), alerta fuerte e inmediata para tus{' '}
            <strong className="text-white">{authorizedSosCount} contactos</strong> con tu ubicación GPS en vivo.
          </p>
        </div>

        {/* Tactical 1-Touch Button */}
        <div className="z-10 relative flex items-center justify-center my-2">
          {/* Pulsing radar rings */}
          <div className="absolute w-60 h-60 rounded-full border border-[#8B5CF6]/20 animate-ping opacity-40 pointer-events-none" />
          <div className="absolute w-52 h-52 rounded-full border border-[#8B5CF6]/30 animate-pulse pointer-events-none" />

          <button
            type="button"
            onClick={handleInstantSosClick}
            aria-label="Activar alerta de emergencia SOS de un solo toque"
            className={`relative z-20 w-44 h-44 sm:w-48 sm:h-48 rounded-full flex flex-col items-center justify-center select-none cursor-pointer transition-all active:scale-90 hover:scale-105 shadow-2xl ${
              safetyState === 'EMERGENCY'
                ? 'bg-gradient-to-b from-red-500 via-red-600 to-red-700 text-white shadow-red-600/60 ring-8 ring-red-500/30 animate-pulse'
                : 'bg-gradient-to-b from-[#EDE9FE] via-[#C4B5FD] to-[#8B5CF6] text-[#1E1B4B] shadow-[#8B5CF6]/50 ring-8 ring-[#8B5CF6]/30'
            }`}
          >
            <AlertOctagon
              className={`w-12 h-12 mb-1.5 ${
                safetyState === 'EMERGENCY' ? 'text-white animate-bounce' : 'text-[#1E1B4B]'
              }`}
            />
            <span className="font-display text-lg sm:text-xl font-black tracking-tight leading-none uppercase">
              {safetyState === 'EMERGENCY' ? 'SOS ACTIVO' : 'SOS AUXILIO'}
            </span>
            <span
              className={`text-[10px] font-extrabold mt-1 uppercase tracking-wider ${
                safetyState === 'EMERGENCY' ? 'text-white/90' : 'text-[#1E1B4B]'
              }`}
            >
              {safetyState === 'EMERGENCY' ? 'Alerta En curso' : '1 Toque Rápido'}
            </span>
          </button>
        </div>

        {/* Secondary Clean Actions Under SOS */}
        <div className="z-10 mt-6 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={() => onTriggerSos(true)}
            className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-[#EDE9FE] text-xs font-semibold transition-colors cursor-pointer border border-white/10"
          >
            🧪 Probar alerta de prueba (simulación)
          </button>

          <button
            type="button"
            onClick={() => onNavigate('contactos')}
            className="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-emerald-500/30"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Llamar a contacto de apoyo</span>
          </button>
        </div>

        {/* Discreet reminder */}
        <div className="z-10 mt-4 text-[11px] text-emerald-300/90 font-medium">
          🔒 Recuerda: A ti no te sonará ninguna sirena para proteger tu discreción. La alarma suena del lado de tu contacto.
        </div>
      </div>

      {/* 4 Clean Quick-Action Cards (Clean, organized, responsive) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: SafeRoute */}
        <div
          onClick={() => onNavigate('rutas')}
          className="rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-[#8B5CF6]/60 p-4 transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/20 text-[#C4B5FD] flex items-center justify-center group-hover:scale-105 transition-transform">
              <Route className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              SafeRoute
            </span>
          </div>
          <div>
            <p className="font-display text-sm font-bold text-white">Ruta Segura</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Monitoreo de desvíos y alertas automáticas en tu camino.
            </p>
          </div>
          <span className="text-[11px] font-semibold text-[#A78BFA] flex items-center gap-1">
            Abrir rutas →
          </span>
        </div>

        {/* Card 2: Ubicación GPS */}
        <div
          onClick={() => onNavigate('ubicacion')}
          className="rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-emerald-500/60 p-4 transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center group-hover:scale-105 transition-transform">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
              {location?.isLive ? 'GPS Activo' : 'Ubicación'}
            </span>
          </div>
          <div>
            <p className="font-display text-sm font-bold text-white">Mi Ubicación</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {location?.isLive
                ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
                : 'Toca para ver en mapa'}
            </p>
          </div>
          <span className="text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
            Ver mapa en vivo →
          </span>
        </div>

        {/* Card 3: Contactos de Confianza */}
        <div
          onClick={() => onNavigate('contactos')}
          className="rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-amber-500/60 p-4 transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
              {contacts.length} Contactos
            </span>
          </div>
          <div>
            <p className="font-display text-sm font-bold text-white">Red de Auxilio</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Familiares, tutores y amigos que recibirán tu alerta.
            </p>
          </div>
          <span className="text-[11px] font-semibold text-amber-400 flex items-center gap-1">
            Gestionar contactos →
          </span>
        </div>

        {/* Card 4: Dispositivo Wearable BLE */}
        <div
          onClick={() => onNavigate('dispositivo')}
          className="rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-blue-500/60 p-4 transition-all cursor-pointer flex flex-col justify-between space-y-3 group"
        >
          <div className="flex items-center justify-between">
            <div className="w-9 h-9 rounded-xl bg-blue-500/20 text-blue-300 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Bluetooth className="w-5 h-5" />
            </div>
            <span className={`text-[10px] font-bold uppercase tracking-wider ${isDeviceConnected ? 'text-emerald-400' : 'text-slate-400'}`}>
              {isDeviceConnected ? 'Conectado' : 'Bluetooth'}
            </span>
          </div>
          <div>
            <p className="font-display text-sm font-bold text-white">Botón NEXA Core</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {isDeviceConnected
                ? `Batería: ${device.batteryLevel ?? 100}% · Listo`
                : 'Vincular dispositivo físico'}
            </p>
          </div>
          <span className="text-[11px] font-semibold text-blue-400 flex items-center gap-1">
            Configurar BLE →
          </span>
        </div>
      </div>
    </div>
  );
};
