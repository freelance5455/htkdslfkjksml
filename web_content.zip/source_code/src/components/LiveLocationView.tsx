import React, { useState, useEffect } from 'react';
import { GeoLocationData } from '../types';
import { InteractiveMap } from './InteractiveMap';
import { buildGoogleMapsLink } from '../utils/sosFormatter';
import {
  Compass,
  Copy,
  ExternalLink,
  Locate,
  LocateFixed,
  MapPin,
  Navigation,
  Power,
  RefreshCw,
  Share2,
  ShieldAlert,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface LiveLocationViewProps {
  location: GeoLocationData | null;
  isLocating: boolean;
  onRequestLocation: () => void;
  onLogLocationShared?: (count: number) => void;
}

interface SafeZonePoint {
  id: string;
  name: string;
  type: 'police' | 'hospital' | 'community' | 'transport';
  address: string;
  lat: number;
  lng: number;
  phone: string;
}

const NEARBY_SAFE_ZONES: SafeZonePoint[] = [
  {
    id: 'sz_upc_1',
    name: 'Unidad de Policía Comunitaria (UPC Norte)',
    type: 'police',
    address: 'Av. Principal y Calle 4 · Cuadrante de Vigilancia 12',
    lat: -2.185,
    lng: -79.892,
    phone: '102',
  },
  {
    id: 'sz_upc_2',
    name: 'UPC Central Estudiantil',
    type: 'police',
    address: 'Sector Académico · Vigilancia Policial Continua',
    lat: -2.1915,
    lng: -79.885,
    phone: '911',
  },
  {
    id: 'sz_hosp_1',
    name: 'Centro de Salud / Primeros Auxilios',
    type: 'hospital',
    address: 'Área Médica Comunitaria · Atención de Urgencias',
    lat: -2.179,
    lng: -79.898,
    phone: '171',
  },
  {
    id: 'sz_trans_1',
    name: 'Parada Segura / Terminal de Transporte Vigilada',
    type: 'transport',
    address: 'Estación de Conexión de Transporte con Cámaras',
    lat: -2.188,
    lng: -79.895,
    phone: '911',
  },
];

export const LiveLocationView: React.FC<LiveLocationViewProps> = ({
  location,
  isLocating,
  onRequestLocation,
  onLogLocationShared,
}) => {
  const [gpsEnabled, setGpsEnabled] = useState(true);
  const [highAccuracyMode, setHighAccuracyMode] = useState(true);
  const [copiedCoords, setCopiedCoords] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (gpsEnabled && (!location || !location.isLive)) {
      onRequestLocation();
    }
  }, [gpsEnabled]);

  const handleToggleGps = () => {
    if (!gpsEnabled) {
      setGpsEnabled(true);
      onRequestLocation();
    } else {
      setGpsEnabled(false);
    }
  };

  const isLiveGps = Boolean(location && location.isLive && location.lat !== 0 && location.lng !== 0);
  const currentLat = isLiveGps ? (location?.lat as number) : -2.1894;
  const currentLng = isLiveGps ? (location?.lng as number) : -79.8891;
  const mapsUrl = buildGoogleMapsLink(currentLat, currentLng);

  const handleCopyCoords = async () => {
    const text = `${currentLat.toFixed(6)}, ${currentLng.toFixed(6)}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCoords(true);
      setTimeout(() => setCopiedCoords(false), 2500);
    } catch {}
  };

  const handleCopyShareLink = async () => {
    try {
      await navigator.clipboard.writeText(mapsUrl);
      setCopiedLink(true);
      if (onLogLocationShared) onLogLocationShared(1);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {}
  };

  const calculateDist = (lat: number, lng: number): number => {
    const rad = (x: number) => (x * Math.PI) / 180;
    const R = 6378137;
    const dLat = rad(lat - currentLat);
    const dLong = rad(lng - currentLng);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(rad(currentLat)) * Math.cos(rad(lat)) * Math.sin(dLong / 2) * Math.sin(dLong / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  };

  return (
    <div className="space-y-5">
      {/* Top Header & GPS Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-[#8B5CF6]/20 text-[#C4B5FD]">
            <MapPin className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-display text-2xl font-bold text-white tracking-tight">
              Mapa GPS y Localización en Vivo
            </h1>
            <p className="text-xs text-slate-400">
              Ubicación satelital en tiempo real con visor cartográfico y cuadrante de seguridad
            </p>
          </div>
        </div>

        {/* GPS Master Switch */}
        <div className="flex items-center gap-3 bg-[#0F172A] p-2 sm:p-2.5 rounded-2xl border border-slate-800 shadow-sm">
          <div className="text-right">
            <p className="text-xs font-bold text-white">
              {gpsEnabled ? 'GPS Activo' : 'GPS Desactivado'}
            </p>
            <p className="text-[10px] text-slate-400">
              {gpsEnabled ? 'Rastreo satelital en vivo' : 'Modo privado / pausa'}
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleGps}
            aria-pressed={gpsEnabled}
            className={`min-h-[42px] px-4 py-2 rounded-xl font-semibold text-xs flex items-center gap-2 transition-all cursor-pointer ${
              gpsEnabled
                ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg'
                : 'bg-slate-800 text-slate-300'
            }`}
          >
            <Power className="w-4 h-4" />
            <span>{gpsEnabled ? 'Encendido' : 'Encender'}</span>
          </button>
        </div>
      </div>

      {/* PROMINENT INTERACTIVE MAP & HUD (Primary Feature) */}
      <div className="rounded-3xl bg-[#0F172A] border border-slate-800 p-4 sm:p-5 shadow-2xl space-y-3">
        <div className="flex items-center justify-between pb-1">
          <div className="flex items-center gap-2">
            <LocateFixed className="w-5 h-5 text-[#8B5CF6]" />
            <h2 className="font-display text-base font-bold text-white">
              Mapa Satelital de Posición Actual
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={!gpsEnabled || isLocating}
              onClick={onRequestLocation}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer disabled:opacity-40 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
              <span>{isLocating ? 'Actualizando GPS...' : 'Actualizar'}</span>
            </button>
          </div>
        </div>

        {/* Map Container */}
        <div className="relative rounded-2xl overflow-hidden border border-slate-800 h-[400px] sm:h-[460px]">
          <InteractiveMap
            location={gpsEnabled ? location : null}
            activeRoute={null}
            onRequestLocation={onRequestLocation}
            isLocating={isLocating}
            heightClass="h-full"
          />

          {/* Floating GPS Coordinates HUD on Top-Left */}
          {gpsEnabled && (
            <div className="absolute top-3 left-3 z-[1000] bg-[#0F172A]/90 backdrop-blur-md border border-[#8B5CF6]/40 p-3 rounded-2xl shadow-xl font-mono-tabular text-xs space-y-1 text-slate-200">
              <div className="flex items-center gap-2 text-[10px] font-bold pb-1 border-b border-slate-800">
                <span
                  className={`w-2 h-2 rounded-full ${
                    isLiveGps ? 'bg-emerald-400 animate-pulse' : 'bg-[#8B5CF6]'
                  }`}
                />
                <span className={isLiveGps ? 'text-emerald-400' : 'text-[#C4B5FD]'}>
                  {isLiveGps ? 'SEÑAL GPS EN TIEMPO REAL' : 'VISOR CARTOGRÁFICO NEXA'}
                </span>
              </div>
              <p>Lat: <strong className="text-white">{currentLat.toFixed(6)}</strong></p>
              <p>Lng: <strong className="text-white">{currentLng.toFixed(6)}</strong></p>
              <p className="text-[11px] text-slate-400">
                {isLiveGps ? (
                  <>
                    Precisión:{' '}
                    <strong className="text-purple-300">
                      ±{Math.round(location?.accuracy ?? 12)} m
                    </strong>
                  </>
                ) : (
                  <span className="text-[#C4B5FD]/80">Modo mapa · Pulsa Actualizar para fijar GPS</span>
                )}
              </p>
            </div>
          )}

          {!gpsEnabled && (
            <div className="absolute inset-0 bg-[#0B0F19]/80 backdrop-blur-xs flex items-center justify-center p-6 text-center z-20">
              <div className="bg-[#0F172A] p-6 rounded-3xl shadow-2xl max-w-sm space-y-3 border border-slate-800">
                <Power className="w-10 h-10 text-amber-500 mx-auto" />
                <h3 className="font-bold text-sm text-white">El GPS está en pausa</h3>
                <p className="text-xs text-slate-400">
                  Activa el interruptor superior para habilitar el seguimiento de tu posición en vivo en el mapa.
                </p>
                <button
                  type="button"
                  onClick={handleToggleGps}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-semibold cursor-pointer shadow-md"
                >
                  Encender GPS
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Control Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: GPS Signal Status */}
        <div className="rounded-2xl bg-[#0F172A] border border-slate-800 p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Estado de la Señal</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                gpsEnabled && location?.isLive
                  ? 'bg-emerald-900/60 text-emerald-300'
                  : 'bg-amber-900/60 text-amber-300'
              }`}
            >
              {gpsEnabled && location?.isLive ? 'EN VIVO' : 'PAUSADO'}
            </span>
          </div>

          <p className="font-display text-xl font-bold text-white">
            {location?.isLive ? `±${Math.round(location.accuracy)} metros` : 'Sin señal activa'}
          </p>

          <p className="text-[11px] text-slate-400">
            {location?.isLive
              ? `Actualizado: ${new Date(location.timestamp).toLocaleTimeString()}`
              : 'Presiona "Actualizar" para forzar la lectura del sensor GPS'}
          </p>
        </div>

        {/* Card 2: Coordinates and Quick Maps */}
        <div className="rounded-2xl bg-[#0F172A] border border-slate-800 p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Coordenadas Exactas</span>
            <Compass className="w-4 h-4 text-[#8B5CF6]" />
          </div>

          <div className="font-mono-tabular text-xs space-y-1 bg-slate-900 p-2.5 rounded-xl border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">Latitud:</span>
              <span className="font-bold text-white">{currentLat.toFixed(6)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Longitud:</span>
              <span className="font-bold text-white">{currentLng.toFixed(6)}</span>
            </div>
          </div>

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={handleCopyCoords}
              className="flex-1 py-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedCoords ? '¡Copiado!' : 'Copiar'}</span>
            </button>
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-[#8B5CF6]/20 hover:bg-[#8B5CF6]/30 text-[#C4B5FD] text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Abrir Maps</span>
            </a>
          </div>
        </div>

        {/* Card 3: Share Live Link */}
        <div className="rounded-2xl bg-[#0F172A] border border-slate-800 p-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Compartir en Vivo</span>
            <Share2 className="w-4 h-4 text-[#8B5CF6]" />
          </div>

          <p className="text-xs text-slate-300">
            Envía tu enlace satelital directo a tus contactos de auxilio o por mensaje.
          </p>

          <button
            type="button"
            onClick={handleCopyShareLink}
            className="w-full min-h-[42px] px-4 py-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#7C3AED] hover:to-[#6D28D9] text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-md transition-all active:scale-95"
          >
            <Share2 className="w-4 h-4" />
            <span>{copiedLink ? '✓ Enlace Copiado' : 'Copiar Enlace de Ubicación'}</span>
          </button>
        </div>
      </div>

      {/* Safe Zones and Emergency Facilities */}
      <div className="rounded-3xl bg-[#0F172A] border border-slate-800 p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="font-display text-base font-bold text-white">
                Puntos de Auxilio y Zonas Seguras Cercanas
              </h2>
              <p className="text-xs text-slate-400">
                Estaciones de policía, centros médicos y paradas vigiladas
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {NEARBY_SAFE_ZONES.map((zone) => {
            const dist = calculateDist(zone.lat, zone.lng);
            return (
              <div
                key={zone.id}
                className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-start justify-between gap-3 hover:border-[#8B5CF6]/50 transition-colors"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${
                        zone.type === 'police'
                          ? 'bg-blue-500'
                          : zone.type === 'hospital'
                          ? 'bg-rose-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                    <h3 className="font-display text-xs font-bold text-white">
                      {zone.name}
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-400">{zone.address}</p>
                  <p className="text-[11px] font-semibold text-[#C4B5FD]">
                    Aprox. {dist > 1000 ? `${(dist / 1000).toFixed(1)} km` : `${dist} metros`}
                  </p>
                </div>

                <div className="flex flex-col gap-1.5 shrink-0">
                  <a
                    href={`https://maps.google.com/?daddr=${zone.lat},${zone.lng}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="min-h-[32px] px-3 py-1.5 rounded-xl bg-slate-800 text-white border border-slate-700 text-[11px] font-semibold flex items-center justify-center gap-1 hover:border-[#8B5CF6]"
                  >
                    <Navigation className="w-3 h-3 text-[#8B5CF6]" />
                    <span>Ruta</span>
                  </a>
                  <a
                    href={`tel:${zone.phone}`}
                    className="min-h-[32px] px-3 py-1.5 rounded-xl bg-emerald-600 text-white text-[11px] font-semibold flex items-center justify-center gap-1 hover:bg-emerald-700"
                  >
                    <span>Llamar {zone.phone}</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
