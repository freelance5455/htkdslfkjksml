import React, { useEffect } from 'react';
import { ActiveCallSession } from '../types';
import { startIncomingRingtone, stopIncomingRingtone } from '../utils/phoneRingtone';
import {
  Phone,
  PhoneCall,
  PhoneOff,
  Shield,
  ShieldAlert,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface IncomingCallModalProps {
  call: ActiveCallSession;
  onAnswer: (call: ActiveCallSession) => void;
  onReject: (call: ActiveCallSession) => void;
}

export const IncomingCallModal: React.FC<IncomingCallModalProps> = ({
  call,
  onAnswer,
  onReject,
}) => {
  // Start authentic phone ringtone when modal mounts
  useEffect(() => {
    startIncomingRingtone(0.9);

    return () => {
      stopIncomingRingtone();
    };
  }, []);

  const handleAnswerClick = () => {
    stopIncomingRingtone();
    onAnswer(call);
  };

  const handleRejectClick = () => {
    stopIncomingRingtone();
    onReject(call);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-gradient-to-b from-[#1E1B4B] via-[#161338] to-[#0A0818] border-2 border-[#8B5CF6]/50 text-white shadow-2xl p-6 sm:p-7 flex flex-col items-center text-center space-y-6 relative overflow-hidden">
        {/* Ambient pulse background glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-[#8B5CF6]/30 rounded-full blur-3xl pointer-events-none" />

        {/* Incoming call badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold uppercase tracking-wider animate-pulse">
          <PhoneCall className="w-4 h-4 animate-bounce" />
          <span>Llamada Entrante</span>
        </div>

        {/* Avatar with multiple pulsing ring waves */}
        <div className="relative my-2">
          <div className="absolute -inset-4 rounded-full border-2 border-emerald-400/30 animate-ping" />
          <div className="absolute -inset-8 rounded-full border border-emerald-400/20 animate-pulse" />
          
          <div className="relative w-28 h-28 rounded-full bg-gradient-to-tr from-[#312E81] to-[#6366F1] border-4 border-emerald-400 flex items-center justify-center shadow-xl">
            <span className="font-display text-4xl font-black text-white">
              {(call.callerName || 'C').charAt(0).toUpperCase()}
            </span>
          </div>
        </div>

        {/* Caller Info */}
        <div className="space-y-1 z-10">
          <h3 className="font-display text-2xl font-black tracking-tight text-white">
            {call.callerName || 'Contacto NEXA'}
          </h3>
          <p className="font-mono-tabular text-sm text-[#C4B5FD] font-semibold">
            {call.callerPhone}
          </p>
          <p className="text-xs text-emerald-300 font-medium flex items-center justify-center gap-1.5 pt-1">
            <Volume2 className="w-3.5 h-3.5 animate-pulse" />
            <span>Timbrando en este dispositivo...</span>
          </p>
        </div>

        {call.isSosEmergency && (
          <div className="w-full rounded-2xl bg-red-950/70 border border-red-500/60 p-2.5 text-xs text-red-200 flex items-center justify-center gap-2 z-10">
            <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 animate-bounce" />
            <span className="font-bold">¡Esta llamada proviene de una alerta SOS!</span>
          </div>
        )}

        {/* Action Buttons: Contestar / Rechazar */}
        <div className="flex items-center justify-around w-full pt-3 z-10">
          {/* Decline Button (Red) */}
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={handleRejectClick}
              className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 active:scale-95 text-white flex items-center justify-center shadow-xl shadow-red-900/50 transition-transform cursor-pointer"
              title="Rechazar llamada"
            >
              <PhoneOff className="w-7 h-7" />
            </button>
            <span className="text-xs font-bold text-red-300">Rechazar</span>
          </div>

          {/* Answer Button (Green) */}
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={handleAnswerClick}
              className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-white flex items-center justify-center shadow-xl shadow-emerald-900/50 transition-transform cursor-pointer animate-bounce"
              title="Contestar llamada"
            >
              <Phone className="w-7 h-7" />
            </button>
            <span className="text-xs font-bold text-emerald-300">Contestar</span>
          </div>
        </div>

        {/* Privacy notice */}
        <p className="text-[11px] text-[#EDE9FE]/50 z-10">
          Llamada de voz cifrada mediante la red de apoyo escolar NEXA.
        </p>
      </div>
    </div>
  );
};
