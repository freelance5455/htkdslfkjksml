import React, { useState } from 'react';
import { GeoLocationData, SosMessageConfig, UserAccount } from '../types';
import { DEFAULT_SOS_MESSAGE, EXAMPLE_DETAILED_SOS_MESSAGE } from '../constants';
import { formatSosMessage } from '../utils/sosFormatter';
import {
  CheckCircle2,
  Eye,
  FileText,
  RotateCcw,
  Save,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';

interface SosConfigViewProps {
  config: SosMessageConfig;
  user: UserAccount;
  location: GeoLocationData | null;
  batteryLevel: number | null;
  isOnline: boolean;
  onSaveConfig: (newConfig: SosMessageConfig) => void;
  onTriggerTestAlert: () => void;
}

const AVAILABLE_VARIABLES = [
  { token: '[NOMBRE]', label: 'Nombre del estudiante' },
  { token: '[ENLACE DE UBICACIÓN]', label: 'Enlace Google Maps' },
  { token: '[UBICACIÓN]', label: 'Coordenadas + Mapa' },
  { token: '[FECHA]', label: 'Fecha actual' },
  { token: '[HORA]', label: 'Hora exacta' },
  { token: '[BATERÍA]', label: 'Batería NEXA Core' },
];

export const SosConfigView: React.FC<SosConfigViewProps> = ({
  config,
  user,
  location,
  batteryLevel,
  isOnline,
  onSaveConfig,
  onTriggerTestAlert,
}) => {
  const [draft, setDraft] = useState<SosMessageConfig>(config);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleInsertVariable = (token: string) => {
    setDraft((prev) => ({
      ...prev,
      template: `${prev.template.trim()} ${token}`,
    }));
  };

  const handleRestoreDefault = () => {
    setDraft((prev) => ({
      ...prev,
      template: DEFAULT_SOS_MESSAGE,
      includeLocationLink: true,
    }));
  };

  const handleUseDetailedExample = () => {
    setDraft((prev) => ({
      ...prev,
      template: EXAMPLE_DETAILED_SOS_MESSAGE,
      includeLocationLink: true,
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const safeDraft: SosMessageConfig = {
      ...draft,
      includeLocationLink: true,
    };
    onSaveConfig(safeDraft);
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  const previewText = formatSosMessage({
    config: draft,
    user,
    location,
    batteryLevel,
    isOnline,
    source: 'app_manual',
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Mi alerta SOS
          </h1>
          <p className="text-xs text-[#EDE9FE]/85 mt-1">
            Personaliza el mensaje y los metadatos que recibirán tus contactos autorizados cuando
            actives una emergencia desde la aplicación o desde tu dispositivo NEXA Core.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              import('../utils/emergencySiren').then((m) => m.testSirenBriefly(3.5));
            }}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500/20 border border-amber-500/50 hover:bg-amber-500/30 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md active:scale-95"
            title="Escuchar volumen de sirena continua"
          >
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Probar Sonido de Sirena Fuerte (3s)</span>
          </button>

          <button
            type="button"
            onClick={onTriggerTestAlert}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-[#161338] border border-[#8B5CF6]/50 hover:border-[#8B5CF6] text-white text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md active:scale-95"
          >
            <ShieldAlert className="w-4 h-4 text-[#C4B5FD]" />
            <span>Probar alerta completa</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-5 sm:p-6 space-y-5 shadow-md"
        >
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#8B5CF6]/20 pb-3">
            <label className="font-display text-sm font-bold text-white flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#8B5CF6]" />
              <span>Plantilla del mensaje de emergencia</span>
            </label>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleUseDetailedExample}
                className="px-2.5 py-1.5 rounded-lg bg-[#1E1B4B] border border-[#8B5CF6]/40 text-[#C4B5FD] text-[11px] font-semibold hover:text-white cursor-pointer flex items-center gap-1 transition-colors"
              >
                <Sparkles className="w-3 h-3 text-[#8B5CF6]" />
                <span>Usar plantilla detallada</span>
              </button>
              <button
                type="button"
                onClick={handleRestoreDefault}
                className="px-2.5 py-1.5 rounded-lg bg-[#1E1B4B] border border-[#8B5CF6]/40 text-[#EDE9FE]/80 text-[11px] font-medium hover:text-white cursor-pointer flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Restaurar original</span>
              </button>
            </div>
          </div>

          <textarea
            rows={4}
            required
            value={draft.template}
            onChange={(e) => setDraft({ ...draft, template: e.target.value })}
            className="w-full p-3.5 rounded-2xl bg-[#1E1B4B] border border-[#8B5CF6]/40 text-xs sm:text-sm text-white leading-relaxed focus:outline-none focus:border-[#8B5CF6]"
          />

          <div className="space-y-2">
            <p className="text-xs font-semibold text-[#EDE9FE]">
              Insertar variables automáticas (clic para añadir):
            </p>
            <div className="flex flex-wrap gap-2">
              {AVAILABLE_VARIABLES.map((v) => (
                <button
                  key={v.token}
                  type="button"
                  onClick={() => handleInsertVariable(v.token)}
                  className="px-2.5 py-1.5 rounded-xl bg-[#1E1B4B] hover:bg-[#8B5CF6]/30 text-[#C4B5FD] text-xs font-mono-tabular transition-colors cursor-pointer border border-[#8B5CF6]/30"
                >
                  + {v.token}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2.5 pt-2 border-t border-[#8B5CF6]/20">
            <p className="text-xs font-semibold text-[#EDE9FE]">
              Datos adjuntos en el bloque técnico de la alerta:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <label className="flex items-center gap-2 text-[#EDE9FE]/90 opacity-90">
                <input
                  type="checkbox"
                  checked={true}
                  disabled
                  className="rounded text-[#8B5CF6]"
                />
                <span>Ubicación y enlace al mapa (Requisito mínimo)</span>
              </label>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.includeUserName}
                  onChange={(e) => setDraft({ ...draft, includeUserName: e.target.checked })}
                  className="rounded text-[#8B5CF6]"
                />
                <span>Nombre completo del estudiante</span>
              </label>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.includeCoordinates}
                  onChange={(e) => setDraft({ ...draft, includeCoordinates: e.target.checked })}
                  className="rounded text-[#8B5CF6]"
                />
                <span>Coordenadas GPS exactas y precisión (±m)</span>
              </label>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.includeTimestamp}
                  onChange={(e) => setDraft({ ...draft, includeTimestamp: e.target.checked })}
                  className="rounded text-[#8B5CF6]"
                />
                <span>Fecha y hora exacta de activación</span>
              </label>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.includeActivationType}
                  onChange={(e) => setDraft({ ...draft, includeActivationType: e.target.checked })}
                  className="rounded text-[#8B5CF6]"
                />
                <span>Tipo de activación (App vs. NEXA Core BLE)</span>
              </label>

              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.includeBatteryLevel}
                  onChange={(e) => setDraft({ ...draft, includeBatteryLevel: e.target.checked })}
                  className="rounded text-[#8B5CF6]"
                />
                <span>Nivel de batería del dispositivo NEXA Core</span>
              </label>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            {savedNotice ? (
              <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                Configuración guardada para alertas futuras
              </span>
            ) : (
              <span className="text-[11px] text-[#C4B5FD]">
                Tiempo de pulsación antierrores: {(draft.holdDurationMs / 1000).toFixed(1)} segundos
              </span>
            )}

            <button
              type="submit"
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7C3AED] text-white text-xs font-bold flex items-center gap-2 cursor-pointer shadow-md transition-transform active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Guardar mi alerta SOS</span>
            </button>
          </div>
        </form>

        <div className="lg:col-span-5 rounded-3xl bg-[#1E1B4B] text-white p-5 sm:p-6 space-y-4 shadow-xl">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-[#C4B5FD]" />
              <h2 className="font-display text-sm font-bold">Vista previa en vivo de la alerta</h2>
            </div>
            <span className="text-[11px] text-[#C4B5FD]">Así la recibirán tus contactos</span>
          </div>

          <div className="rounded-2xl bg-[#0F172A] border border-white/10 p-4 space-y-2.5">
            <div className="flex items-center justify-between text-[11px] text-[#C4B5FD]">
              <span>NEXA Student Safety Network</span>
              <span className="font-mono-tabular">Ahora</span>
            </div>
            <p className="text-xs text-[#F8FAFC] whitespace-pre-line leading-relaxed font-normal">
              {previewText}
            </p>
          </div>

          <div className="text-[11px] text-[#EDE9FE]/75 space-y-1 leading-relaxed">
            <p>
              • Si el GPS está autorizado, el enlace abre directamente la posición en Google Maps.
            </p>
            <p>
              • Si realizas una prueba, NEXA añade automáticamente la etiqueta{' '}
              <strong className="text-white">[MODO PRUEBA]</strong> para evitar alarmar
              innecesariamente a tu familia.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
