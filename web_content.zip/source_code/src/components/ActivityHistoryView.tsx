import React, { useState } from 'react';
import { ActivityLogItem } from '../types';
import { buildGoogleMapsLink } from '../utils/sosFormatter';
import {
  Activity,
  AlertOctagon,
  Bluetooth,
  CheckCircle2,
  ExternalLink,
  MapPin,
  Route,
  ShieldCheck,
  Trash2,
} from 'lucide-react';

interface ActivityHistoryViewProps {
  logs: ActivityLogItem[];
  onDeleteLog: (id: string) => void;
  onClearAllLogs: () => void;
}

export const ActivityHistoryView: React.FC<ActivityHistoryViewProps> = ({
  logs,
  onDeleteLog,
  onClearAllLogs,
}) => {
  const [filter, setFilter] = useState<'todos' | 'sos' | 'rutas' | 'dispositivo'>('todos');
  const [selectedId, setSelectedId] = useState<string | null>(logs[0]?.id || null);

  const filteredLogs = logs.filter((item) => {
    if (filter === 'todos') return true;
    if (filter === 'sos') return item.type.startsWith('sos_');
    if (filter === 'rutas') return item.type.startsWith('route_') || item.type === 'location_shared';
    if (filter === 'dispositivo')
      return item.type.startsWith('ble_') || item.type === 'connection_error';
    return true;
  });

  const selectedLog = logs.find((l) => l.id === selectedId) || filteredLogs[0] || null;

  const getEventIcon = (type: ActivityLogItem['type']) => {
    if (type.startsWith('sos_')) return AlertOctagon;
    if (type.startsWith('route_')) return Route;
    if (type.startsWith('ble_')) return Bluetooth;
    return Activity;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">
            Actividad e historial de eventos
          </h1>
          <p className="text-xs text-[#EDE9FE]/80 mt-1">
            Registro auditado de alertas SOS, Rutas Seguras, confirmaciones de llegada y eventos del
            dispositivo NEXA Core. Protegido bajo principios de minimización de datos (sin audio ni
            vigilancia).
          </p>
        </div>

        {logs.length > 0 && (
          <button
            type="button"
            onClick={onClearAllLogs}
            className="min-h-[42px] px-4 py-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 border border-red-500/30 text-red-200 text-xs font-semibold flex items-center gap-2 cursor-pointer shrink-0 transition-colors"
          >
            <Trash2 className="w-4 h-4 text-red-400" />
            <span>Borrar todo mi historial</span>
          </button>
        )}
      </div>

      <div className="flex items-center gap-1.5 p-1 bg-[#100D2B] rounded-xl border border-[#8B5CF6]/20 w-fit overflow-x-auto max-w-full">
        {(
          [
            { id: 'todos', label: 'Todos los eventos' },
            { id: 'sos', label: 'Alertas SOS' },
            { id: 'rutas', label: 'Rutas y Ubicación' },
            { id: 'dispositivo', label: 'Dispositivo BLE' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer whitespace-nowrap ${
              filter === tab.id
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'text-[#EDE9FE]/70 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filteredLogs.length === 0 ? (
        <div className="rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-10 text-center space-y-2 shadow-md">
          <ShieldCheck className="w-10 h-10 text-[#8B5CF6] mx-auto" />
          <h3 className="font-display text-base font-bold text-white">
            No hay registros en esta categoría
          </h3>
          <p className="text-xs text-[#C4B5FD] max-w-md mx-auto">
            Aquí aparecerán las alertas SOS, recorridos SafeRoute y eventos de conexión de tu
            dispositivo NEXA Core.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7 space-y-2.5">
            {filteredLogs.map((item) => {
              const Icon = getEventIcon(item.type);
              const isSelected = selectedLog?.id === item.id;
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedId(item.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-3 ${
                    isSelected
                      ? 'bg-[#1E1B4B] border-[#8B5CF6] shadow-md ring-1 ring-[#8B5CF6]'
                      : 'bg-[#161338] border-[#8B5CF6]/30 hover:border-[#8B5CF6]'
                  }`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        item.severity === 'critical'
                          ? 'bg-red-950/60 text-red-400 border border-red-500/30'
                          : item.severity === 'warning' || item.severity === 'orange'
                          ? 'bg-amber-950/60 text-amber-400 border border-amber-500/30'
                          : item.severity === 'safe'
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/30'
                          : 'bg-[#8B5CF6]/20 text-[#C4B5FD] border border-[#8B5CF6]/30'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>

                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-display text-xs sm:text-sm font-bold text-white">
                          {item.title}
                        </h3>
                        {item.isSimulated && (
                          <span className="text-[11px] font-semibold text-amber-400">
                            · Evento de Prueba/Demo
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#EDE9FE]/85 line-clamp-2">
                        {item.description}
                      </p>
                      <div className="flex items-center gap-2 text-[11px] text-[#C4B5FD] font-mono-tabular">
                        <span>{new Date(item.timestamp).toLocaleDateString('es-EC')}</span>
                        <span>·</span>
                        <span>{new Date(item.timestamp).toLocaleTimeString('es-EC')}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteLog(item.id);
                    }}
                    title="Eliminar este registro"
                    className="min-h-[36px] min-w-[36px] rounded-xl text-[#EDE9FE]/50 hover:text-red-400 hover:bg-red-950/40 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>

          {selectedLog && (
            <div className="lg:col-span-5 rounded-3xl bg-[#161338] border border-[#8B5CF6]/30 p-5 sm:p-6 space-y-4 sticky top-20 shadow-md">
              <div className="border-b border-[#8B5CF6]/20 pb-3">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C4B5FD]">
                  Detalle del registro seleccionado
                </span>
                <h2 className="font-display text-base font-bold text-white mt-0.5">
                  {selectedLog.title}
                </h2>
                <p className="font-mono-tabular text-xs text-[#C4B5FD] mt-0.5">
                  {new Date(selectedLog.timestamp).toLocaleString('es-EC')}
                </p>
              </div>

              <p className="text-xs text-[#EDE9FE] leading-relaxed">
                {selectedLog.description}
              </p>

              {selectedLog.activationSource && (
                <div className="rounded-xl bg-[#1E1B4B] p-3 border border-[#8B5CF6]/30 text-xs">
                  <span className="text-[#C4B5FD] block text-[11px]">Origen de activación:</span>
                  <span className="font-semibold text-white">
                    {selectedLog.activationSource}
                  </span>
                </div>
              )}

              {selectedLog.location && (
                <div className="rounded-xl bg-[#1E1B4B] p-3 border border-[#8B5CF6]/30 space-y-1 text-xs">
                  <span className="text-[#C4B5FD] flex items-center gap-1 text-[11px]">
                    <MapPin className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    Ubicación registrada en el evento:
                  </span>
                  <p className="font-mono-tabular font-semibold text-white">
                    {selectedLog.location.lat.toFixed(5)}, {selectedLog.location.lng.toFixed(5)}
                  </p>
                  <a
                    href={buildGoogleMapsLink(selectedLog.location.lat, selectedLog.location.lng)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#C4B5FD] font-semibold hover:text-white hover:underline pt-0.5"
                  >
                    <span>Abrir ubicación en Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              {selectedLog.contactsNotified && selectedLog.contactsNotified.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-[#EDE9FE]">
                    Intentos de notificación a contactos:
                  </p>
                  <div className="divide-y divide-[#8B5CF6]/20 rounded-xl border border-[#8B5CF6]/30 overflow-hidden">
                    {selectedLog.contactsNotified.map((cn, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 bg-[#1E1B4B] flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-semibold text-white">
                            {cn.name}
                          </span>
                          <span className="text-[#C4B5FD]"> · {cn.channel.toUpperCase()}</span>
                        </div>
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-400 capitalize">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          {cn.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
