import {
  AppSettings,
  EmergencyContact,
  SafeRoutePreset,
  SosMessageConfig,
  UserAccount,
  WearableFormat,
} from './types';

export const DEFAULT_SOS_MESSAGE =
  '¡EMERGENCIA NEXA! Necesito ayuda. Esta es mi ubicación actual: [ENLACE DE UBICACIÓN]. Por favor, comunícate conmigo o busca ayuda si no respondo.';

export const EXAMPLE_DETAILED_SOS_MESSAGE =
  'Hola, soy [NOMBRE]. He activado una alerta de emergencia mediante NEXA. Mi ubicación actual es [UBICACIÓN]. La alerta se generó el [FECHA] a las [HORA]. Necesito que intentes comunicarte conmigo y me ayudes.';

export const DEFAULT_SOS_CONFIG: SosMessageConfig = {
  template: DEFAULT_SOS_MESSAGE,
  includeUserName: true,
  includeLocationLink: true,
  includeCoordinates: true,
  includeTimestamp: true,
  includeActivationType: true,
  includeBatteryLevel: true,
  includeConnectionStatus: true,
  holdDurationMs: 2000,
};

export const DEFAULT_USER_ACCOUNT: UserAccount = {
  id: 'usr_default_01',
  fullName: 'Usuario',
  email: '',
  phone: '0991234567',
  institution: '',
  gradeOrRole: '',
  isMinor: false,
  guardianName: '',
  guardianPhone: '',
  guardianConsentAccepted: true,
  privacyPolicyAccepted: true,
  createdAt: '2026-10-15T00:00:00.000Z',
};

export const DEFAULT_EMERGENCY_CONTACTS: EmergencyContact[] = [
  {
    id: 'cnt_1',
    firstName: 'Mamá',
    lastName: '(Tutor)',
    countryCode: '+593',
    phone: '0991248830',
    email: '',
    relationship: 'tutor',
    priority: 1,
    channels: ['sms', 'push', 'call'],
    authorized: true,
    receiveSos: true,
    locationConsent: true,
    updatedAt: '2026-10-15T08:00:00.000Z',
  },
  {
    id: 'cnt_2',
    firstName: 'Carlos',
    lastName: '(Papá)',
    countryCode: '+593',
    phone: '0984512093',
    email: '',
    relationship: 'familiar',
    priority: 2,
    channels: ['sms', 'push', 'call'],
    authorized: true,
    receiveSos: true,
    locationConsent: true,
    updatedAt: '2026-10-15T08:00:00.000Z',
  },
  {
    id: 'cnt_3',
    firstName: 'Alex',
    lastName: '(Amigo NEXA)',
    countryCode: '+593',
    phone: '0987654322',
    email: '',
    relationship: 'amigo',
    priority: 3,
    channels: ['push', 'sms'],
    authorized: true,
    receiveSos: true,
    locationConsent: true,
    updatedAt: '2026-10-15T08:00:00.000Z',
  },
  {
    id: 'cnt_4',
    firstName: 'Sofía',
    lastName: '(Compañera de ruta)',
    countryCode: '+593',
    phone: '0998877665',
    email: '',
    relationship: 'amigo',
    priority: 4,
    channels: ['push', 'sms'],
    authorized: true,
    receiveSos: true,
    locationConsent: true,
    updatedAt: '2026-10-15T08:00:00.000Z',
  },
];

export const DEFAULT_APP_SETTINGS: AppSettings = {
  darkMode: false,
  silentMode: true,
  safeRouteToleranceMeters: 150,
  safeRouteLevel1WaitSec: 45,
  safeRouteLevel2WaitSec: 60,
  autoShareLocationOnSos: true,
  offlineQueueEnabled: true,
  dataRetentionDays: 30,
  preferredChannels: ['push', 'sms', 'email'],
};

export const SAFEROUTE_PRESETS: SafeRoutePreset[] = [
  {
    id: 'dest_colegio',
    name: 'Colegio / Instituto Educativo',
    address: 'Zona escolar principal',
    lat: -2.1894,
    lng: -79.8891,
    estimatedMinutes: 20,
  },
  {
    id: 'dest_casa',
    name: 'Residencia Familiar',
    address: 'Retorno seguro a casa',
    lat: -2.1709,
    lng: -79.9012,
    estimatedMinutes: 25,
  },
  {
    id: 'dest_biblioteca',
    name: 'Biblioteca y Centro de Estudios',
    address: 'Zona académica habitual',
    lat: -2.1932,
    lng: -79.8835,
    estimatedMinutes: 15,
  },
  {
    id: 'dest_deportivo',
    name: 'Actividades Extracurriculares',
    address: 'Complejo deportivo o academia',
    lat: -2.1815,
    lng: -79.8964,
    estimatedMinutes: 18,
  },
];

export const WEARABLE_FORMATS: {
  id: WearableFormat;
  name: string;
  concept: string;
  formatLabel: string;
  typicalUse: string;
  badge: string;
}[] = [
  {
    id: 'clip',
    name: 'NEXA Clip',
    concept: 'BackpackTag / SafeTag',
    formatLabel: 'Accesorio de mochila',
    typicalUse: 'Producto de entrada (MVP) con mosquetón reforzado para mochila escolar.',
    badge: 'MVP Oficial',
  },
  {
    id: 'loop',
    name: 'NEXA Loop',
    concept: 'EmergencyBand',
    formatLabel: 'Pulsera ergonómica',
    typicalUse: 'Acceso táctil inmediato desde la muñeca durante traslados.',
    badge: 'Acceso Rápido',
  },
  {
    id: 'pin',
    name: 'NEXA Pin',
    concept: 'SafeButton',
    formatLabel: 'Broche de uniforme o ropa',
    typicalUse: 'Se integra en el uniforme o chaqueta con máxima discreción.',
    badge: 'Máxima Discreción',
  },
  {
    id: 'nova',
    name: 'NEXA Nova',
    concept: 'SafeNecklace / SafePendant',
    formatLabel: 'Collar / Dije',
    typicalUse: 'Uso diario con apariencia de accesorio minimalista.',
    badge: 'Uso Diario',
  },
];

export const PROVISIONAL_BLE_SPEC = {
  statusNote:
    'IDENTIFICADORES PROVISIONALES DE DESARROLLO (ESP32 NEXA Core v1.0-proto) — Sujetos a homologación en Mes 4',
  deviceNamePrefix: 'NEXA-Core-',
  primaryServiceUuid: '6e400001-b5a3-f393-e0a9-e50e24dcca9e',
  batteryServiceUuid: '0000180f-0000-1000-8000-00805f9b34fb',
  characteristics: [
    {
      name: 'BUTTON_EVENT_CHAR (TX Notify)',
      uuid: '6e400002-b5a3-f393-e0a9-e50e24dcca9e',
      properties: 'NOTIFY, READ',
      payloadSpec:
        'Byte[0]: Tipo (0x01 = Pulsación corta / Check-in, 0x02 = Pulsación prolongada >=2s / SOS Emergencia, 0x03 = Cancelación local). Byte[1]: Nivel de batería (%). Byte[2..5]: Timestamp relativo (uint32).',
    },
    {
      name: 'ACTUATOR_CMD_CHAR (RX Write/Ack)',
      uuid: '6e400003-b5a3-f393-e0a9-e50e24dcca9e',
      properties: 'WRITE, WRITE_WITHOUT_RESPONSE',
      payloadSpec:
        'Byte[0]: Comando (0x10 = Ack Vibración silenciosa, 0x11 = Test Motor Vibrador 250ms, 0x12 = Test LED Morado #8B5CF6, 0x13 = Test Buzzer Acústico, 0x1F = Confirmación de Alerta Recibida por App).',
    },
    {
      name: 'OFFLINE_BUFFER_SYNC_CHAR',
      uuid: '6e400004-b5a3-f393-e0a9-e50e24dcca9e',
      properties: 'NOTIFY, WRITE',
      payloadSpec:
        'Sincroniza registros guardados en memoria flash NVS del ESP32 cuando el dispositivo estuvo fuera de alcance Bluetooth.',
    },
    {
      name: 'IMU_MOTION_STATE_CHAR',
      uuid: '6e400005-b5a3-f393-e0a9-e50e24dcca9e',
      properties: 'NOTIFY, READ',
      payloadSpec:
        'Estado de unidad de medición inercial (MPU6050/BMI160): reposo, marcha normal o impacto brusco.',
    },
  ],
};

export const SAFETY_STATE_META = {
  SAFE: {
    code: 'SAFE',
    label: 'Estado Seguro',
    shortDesc: 'Todo bien · Sin alertas activas',
    bgClass: 'bg-emerald-500',
    textClass: 'text-emerald-700 dark:text-emerald-300',
    surfaceClass: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800/60',
    ringColor: '#10B981',
  },
  ROUTE: {
    code: 'ROUTE',
    label: 'Recorrido Activo',
    shortDesc: 'Ruta Segura o Acompáñame en curso',
    bgClass: 'bg-blue-500',
    textClass: 'text-blue-700 dark:text-blue-300',
    surfaceClass: 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800/60',
    ringColor: '#3B82F6',
  },
  CHECK: {
    code: 'CHECK',
    label: 'Confirmación Pendiente',
    shortDesc: 'Nivel 1/2: Confirma que sigues bien en tu ruta',
    bgClass: 'bg-amber-500',
    textClass: 'text-amber-800 dark:text-amber-300',
    surfaceClass: 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800/60',
    ringColor: '#F59E0B',
  },
  ALERT: {
    code: 'ALERT',
    label: 'Alerta Preventiva',
    shortDesc: 'Aviso enviado a contactos · Seguimiento prioritario',
    bgClass: 'bg-orange-500',
    textClass: 'text-orange-800 dark:text-orange-300',
    surfaceClass: 'bg-orange-50 dark:bg-orange-950/40 border-orange-300 dark:border-orange-800/60',
    ringColor: '#F97316',
  },
  EMERGENCY: {
    code: 'EMERGENCY',
    label: 'Emergencia SOS Activa',
    shortDesc: 'Prioridad máxima · Notificando a red de apoyo',
    bgClass: 'bg-red-600',
    textClass: 'text-red-700 dark:text-red-300',
    surfaceClass: 'bg-red-50 dark:bg-red-950/50 border-red-300 dark:border-red-800/70',
    ringColor: '#DC2626',
  },
} as const;
