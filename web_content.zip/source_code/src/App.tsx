import React, { useCallback, useEffect, useState } from 'react';
import {
  ActivationSource,
  ActiveCallSession,
  ActiveEmergencySession,
  ActivityLogItem,
  AppSettings,
  ChatMessage,
  ContactDeliveryAttempt,
  EmergencyContact,
  GeoLocationData,
  NavigationTab,
  NexaDeviceState,
  NotificationChannel,
  SafeRouteSession,
  SafetyState,
  SosMessageConfig,
  UserAccount,
  UserCustomRoute,
  WearableFormat,
} from './types';
import {
  DEFAULT_APP_SETTINGS,
  DEFAULT_EMERGENCY_CONTACTS,
  DEFAULT_SOS_CONFIG,
  DEFAULT_USER_ACCOUNT,
  PROVISIONAL_BLE_SPEC,
  SAFETY_STATE_META,
  WEARABLE_FORMATS,
} from './constants';
import { formatSosMessage, getActivationSourceLabel } from './utils/sosFormatter';
import { NexaLogo } from './components/NexaLogo';
import { AuthWelcomeScreen } from './components/AuthWelcomeScreen';
import { HomeDashboardView } from './components/HomeDashboardView';
import { ContactsView } from './components/ContactsView';
import { SosConfigView } from './components/SosConfigView';
import { SafeRouteManagerView } from './components/SafeRouteManagerView';
import { LiveLocationView } from './components/LiveLocationView';
import { NexaChatView } from './components/NexaChatView';
import { DeviceBleView } from './components/DeviceBleView';
import { ActivityHistoryView } from './components/ActivityHistoryView';
import { SettingsPrivacyView } from './components/SettingsPrivacyView';
import { EmergencyOverlayModal } from './components/EmergencyOverlayModal';
import { DownloadInstallModal } from './components/DownloadInstallModal';
import { SideMenuDrawer } from './components/SideMenuDrawer';
import { InAppCallModal } from './components/InAppCallModal';
import { IncomingCallModal } from './components/IncomingCallModal';
import {
  startEmergencySiren,
  stopEmergencySiren,
  testSirenBriefly,
} from './utils/emergencySiren';
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  Bluetooth,
  Download,
  FileText,
  Home,
  LogOut,
  MapPin,
  Menu,
  MessageCircle,
  Moon,
  PhoneCall,
  Route,
  Settings,
  ShieldAlert,
  Smartphone,
  Sun,
  Users,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';

const STORAGE_KEYS = {
  USER: 'nexa_user_v1',
  AUTH: 'nexa_authenticated_v1',
  CONTACTS: 'nexa_contacts_v1',
  SOS_CONFIG: 'nexa_sos_config_v1',
  SETTINGS: 'nexa_settings_v1',
  LOGS: 'nexa_activity_logs_v1',
  ROUTE: 'nexa_active_route_v1',
  CHAT: 'nexa_chat_messages_v1',
  CUSTOM_ROUTES: 'nexa_custom_routes_v1',
};

const INITIAL_ACTIVITY_LOGS: ActivityLogItem[] = [
  {
    id: 'log_init_1',
    type: 'route_arrived',
    title: 'Modo "Llegué" confirmado — Destino habitual',
    description:
      'Llegada confirmada a destino seguro sin desviaciones. Seguimiento temporal finalizado automáticamente.',
    timestamp: new Date(Date.now() - 3600 * 1000 * 3).toISOString(),
    severity: 'safe',
    location: { lat: -2.1894, lng: -79.8891, accuracy: 14 },
    contactsNotified: [
      { name: 'Mamá (Tutor)', channel: 'push', status: 'entregado' },
    ],
  },
  {
    id: 'log_init_2',
    type: 'ble_connected',
    title: 'Configuración de perfil NEXA Core (Formato NEXA Clip)',
    description:
      'Protocolo BLE provisional preparado para módulo universal ESP32 con botón de dos niveles.',
    timestamp: new Date(Date.now() - 3600 * 1000 * 5).toISOString(),
    severity: 'info',
    isSimulated: true,
  },
];

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.AUTH);
    return saved ? JSON.parse(saved) : false;
  });

  const [user, setUser] = useState<UserAccount>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.USER);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (
          parsed.institution &&
          (parsed.institution.toLowerCase().includes('matilde') ||
            parsed.institution.toLowerCase().includes('amador'))
        ) {
          parsed.institution = '';
        }
        if (
          parsed.gradeOrRole &&
          (parsed.gradeOrRole.toLowerCase().includes('tercero') ||
            parsed.gradeOrRole.toLowerCase().includes('bachillerato'))
        ) {
          parsed.gradeOrRole = '';
        }
        if (parsed.fullName && parsed.fullName.toLowerCase().includes('damaris')) {
          parsed.fullName = 'Usuario';
        }
        return parsed;
      } catch {}
    }
    return DEFAULT_USER_ACCOUNT;
  });

  const [contacts, setContacts] = useState<EmergencyContact[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CONTACTS);
    return saved ? JSON.parse(saved) : DEFAULT_EMERGENCY_CONTACTS;
  });

  const [sosConfig, setSosConfig] = useState<SosMessageConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SOS_CONFIG);
    return saved ? JSON.parse(saved) : DEFAULT_SOS_CONFIG;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? JSON.parse(saved) : DEFAULT_APP_SETTINGS;
  });

  const [activityLogs, setActivityLogs] = useState<ActivityLogItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.LOGS);
    return saved ? JSON.parse(saved) : INITIAL_ACTIVITY_LOGS;
  });

  const [activeRoute, setActiveRoute] = useState<SafeRouteSession | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.ROUTE);
    return saved ? JSON.parse(saved) : null;
  });

  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CHAT);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'msg_welcome_1',
        senderPhone: '0987654322',
        senderName: 'Alex (Amigo NEXA)',
        receiverPhone: '0991234567',
        content:
          '¡Hola! Ya tengo instalada la app NEXA en mi teléfono. Si me agregas con mi número en tus contactos, cuando actives una alerta SOS recibiré tu ubicación aquí en tiempo real.',
        timestamp: new Date(Date.now() - 3600000).toISOString(),
        isSosAlert: false,
        read: true,
      },
    ];
  });

  const [customRoutes, setCustomRoutes] = useState<UserCustomRoute[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CUSTOM_ROUTES);
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'route_1',
        name: 'Ruta al Colegio',
        originName: 'Casa',
        destinationName: 'Colegio / Instituto Educativo',
        destinationAddress: 'Zona escolar principal',
        destinationLat: -2.1894,
        destinationLng: -79.8891,
        estimatedMinutes: 20,
        toleranceMeters: 150,
        sharedContactIds: ['cnt_1', 'cnt_3'],
      },
      {
        id: 'route_2',
        name: 'Retorno Seguro a Casa',
        originName: 'Colegio',
        destinationName: 'Residencia Familiar',
        destinationAddress: 'Retorno directo a casa',
        destinationLat: -2.1709,
        destinationLng: -79.9012,
        estimatedMinutes: 25,
        toleranceMeters: 150,
        sharedContactIds: ['cnt_1', 'cnt_2'],
      },
      {
        id: 'route_3',
        name: 'Actividades Extracurriculares',
        originName: 'Colegio',
        destinationName: 'Complejo Deportivo',
        destinationAddress: 'Área deportiva estudiantil',
        destinationLat: -2.1815,
        destinationLng: -79.8964,
        estimatedMinutes: 18,
        toleranceMeters: 200,
        sharedContactIds: ['cnt_3'],
      },
    ];
  });

  const [incomingSosBanner, setIncomingSosBanner] = useState<{
    id: string;
    senderName: string;
    senderPhone: string;
    content: string;
    mapsUrl?: string;
  } | null>(null);

  const [activeTab, setActiveTab] = useState<NavigationTab>('inicio');
  const [location, setLocation] = useState<GeoLocationData | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [activeEmergency, setActiveEmergency] = useState<ActiveEmergencySession | null>(null);
  const [manualAlertState, setManualAlertState] = useState<boolean>(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isGmpQuotaExceeded, setIsGmpQuotaExceeded] = useState(false);
  const [activeInAppCallContact, setActiveInAppCallContact] = useState<{
    name: string;
    phone: string;
    relationship?: string;
    callId?: string;
    isIncomingAnswer?: boolean;
  } | null>(null);

  const [incomingCallSession, setIncomingCallSession] = useState<ActiveCallSession | null>(null);

  const [device, setDevice] = useState<NexaDeviceState>({
    connectionStatus: 'disconnected',
    isDemoMode: false,
    deviceId: null,
    deviceName: 'NEXA Clip · Módulo Core ESP32',
    selectedFormat: 'clip',
    batteryLevel: null,
    isCharging: false,
    lastSyncAt: null,
    firmwareVersion: 'v1.0.4-esp32',
    rssi: null,
    connectionError: null,
    pendingEvents: [],
    lastButtonEvent: null,
  });

  // Strict phone normalization and sender identification helpers
  const normalizePhone = (phone?: string | null): string => {
    if (!phone) return '';
    return phone.replace(/\D/g, '');
  };

  const isSamePhone = (p1?: string | null, p2?: string | null): boolean => {
    const n1 = normalizePhone(p1);
    const n2 = normalizePhone(p2);
    if (!n1 || !n2) return false;
    if (n1 === n2) return true;
    const s1 = n1.replace(/^593/, '').replace(/^0+/, '');
    const s2 = n2.replace(/^593/, '').replace(/^0+/, '');
    if (s1 && s2 && s1 === s2) return true;
    if (s1.length >= 6 && s2.length >= 6 && (s1.endsWith(s2) || s2.endsWith(s1))) return true;
    return false;
  };

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.AUTH, JSON.stringify(isAuthenticated));
  }, [isAuthenticated]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CONTACTS, JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SOS_CONFIG, JSON.stringify(sosConfig));
  }, [sosConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHAT, JSON.stringify(chatMessages));
  }, [chatMessages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOM_ROUTES, JSON.stringify(customRoutes));
  }, [customRoutes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    if (settings.darkMode !== false) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  // Google Maps Platform quota defense listener (Tier 1)
  useEffect(() => {
    const handleQuotaExceeded = () => setIsGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('gmp-quota-exceeded', handleQuotaExceeded);
  }, []);

  // Multi-device cloud sync: Automatically synchronize changes to the server database
  useEffect(() => {
    const activeKey = user.phone || user.email;
    if (!activeKey) return;

    const timer = setTimeout(() => {
      fetch('/api/auth/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: user.phone,
          email: user.email,
          user,
          contacts,
          customRoutes,
          sosConfig,
          settings,
        }),
      }).catch(() => {
        // offline fallback
      });
    }, 1500);

    return () => clearTimeout(timer);
  }, [user, contacts, customRoutes, sosConfig, settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(activityLogs));
  }, [activityLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROUTE, JSON.stringify(activeRoute));
  }, [activeRoute]);

  // Real-time polling for friend messages and SOS alerts
  // REGLA ESTRICTA DE SEGURIDAD:
  // EL TELÉFONO DEL REMITENTE NUNCA DEBE EMITIR SONIDO AL ACTIVAR EL SOS (SILENCIO TOTAL 0dB).
  // La alarma sonora potente y moderna SOLO suena en el celular de los destinatarios/contactos que reciben la alerta.
  useEffect(() => {
    const activePhone = user.phone || '0991234567';
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/chat/messages?phone=${encodeURIComponent(activePhone)}`);
        if (res.ok) {
          const data = await res.json();
          if (data.messages && Array.isArray(data.messages)) {
            setChatMessages((prev) => {
              const existingIds = new Set(prev.map((m) => m.id));
              const newIncoming = data.messages.filter((m: ChatMessage) => !existingIds.has(m.id));
              if (newIncoming.length === 0) return prev;

              // Buscar si hay un mensaje SOS entrante de OTRA persona dirigido a este usuario
              const incomingSosFromFriend = newIncoming.find((m: ChatMessage) => {
                if (!m.isSosAlert) return false;

                // 1. Verificar si fue enviado por el propio usuario (REMITENTE -> NUNCA HACER SONAR)
                const isSentByMe =
                  isSamePhone(m.senderPhone, user.phone) ||
                  isSamePhone(m.senderPhone, activePhone) ||
                  (user.fullName &&
                    m.senderName &&
                    m.senderName.trim().toLowerCase() === user.fullName.trim().toLowerCase());

                if (isSentByMe) return false;

                // 2. Si el usuario actual tiene una emergencia activa propia, él es el remitente
                if (activeEmergency && activeEmergency.status === 'active') return false;

                // 3. Verificar que el mensaje esté dirigido a este usuario (DESTINATARIO)
                const isAddressedToMe =
                  isSamePhone(m.receiverPhone, user.phone) ||
                  isSamePhone(m.receiverPhone, activePhone);

                return isAddressedToMe;
              });

              if (incomingSosFromFriend) {
                // ALERTA SONORA PRIORITARIA EN EL TELÉFONO DEL DESTINATARIO (CONTACTO QUE RECIBE EL SOS):
                startEmergencySiren(0.95);
                if (navigator.vibrate) {
                  try {
                    navigator.vibrate([400, 150, 400, 150, 600]);
                  } catch {}
                }
                const mapsUrl =
                  incomingSosFromFriend.sosDetails?.mapsUrl ||
                  (incomingSosFromFriend.sosDetails?.location
                    ? `https://maps.google.com/?q=${incomingSosFromFriend.sosDetails.location.lat},${incomingSosFromFriend.sosDetails.location.lng}`
                    : undefined);

                setIncomingSosBanner({
                  id: incomingSosFromFriend.id,
                  senderName: incomingSosFromFriend.senderName,
                  senderPhone: incomingSosFromFriend.senderPhone,
                  content: incomingSosFromFriend.content,
                  mapsUrl,
                });
              }

              return [...prev, ...newIncoming];
            });
          }
        }
      } catch {
        // silent offline fallback
      }
    }, 2500);

    return () => clearInterval(interval);
  }, [user.phone, user.fullName, activeEmergency]);

  // Real-time polling for incoming voice calls between devices (e.g. Phone <-> Laptop)
  useEffect(() => {
    if (!isAuthenticated) return;
    const activePhone = user.phone || '0991234567';

    const callInterval = setInterval(async () => {
      try {
        const res = await fetch(`/api/calls/status?phone=${encodeURIComponent(activePhone)}`);
        if (res.ok) {
          const data = await res.json();
          const activeCall = data.call as any;
          if (activeCall) {
            // Check if this user is the recipient and call is currently ringing
            if (
              activeCall.status === 'ringing' &&
              isSamePhone(activeCall.recipientPhone, activePhone) &&
              !isSamePhone(activeCall.callerPhone, activePhone)
            ) {
              setIncomingCallSession((prev) => {
                if (prev && prev.callId === activeCall.id) return prev;
                return {
                  callId: activeCall.id,
                  callerPhone: activeCall.callerPhone,
                  callerName: activeCall.callerName,
                  recipientPhone: activeCall.recipientPhone,
                  recipientName: activeCall.recipientName,
                  status: activeCall.status,
                  startedAt: activeCall.startedAt,
                  isSosEmergency: activeCall.isSosEmergency,
                };
              });
            } else if (
              (activeCall.status === 'ended' || activeCall.status === 'rejected') &&
              incomingCallSession
            ) {
              setIncomingCallSession(null);
            }
          } else {
            // No active call on server
            if (incomingCallSession) {
              setIncomingCallSession(null);
            }
          }
        }
      } catch {}
    }, 1400);

    return () => clearInterval(callInterval);
  }, [isAuthenticated, user.phone, incomingCallSession]);

  const handleAnswerIncomingCall = async (call: ActiveCallSession) => {
    try {
      await fetch('/api/calls/answer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callId: call.callId }),
      });
    } catch {}

    setIncomingCallSession(null);
    setActiveInAppCallContact({
      name: call.callerName,
      phone: call.callerPhone,
      relationship: call.isSosEmergency ? 'Emergencia SOS' : 'Llamada Entrante',
      callId: call.callId,
      isIncomingAnswer: true,
    });
  };

  const handleRejectIncomingCall = async (call: ActiveCallSession) => {
    try {
      await fetch('/api/calls/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ callId: call.callId }),
      });
    } catch {}
    setIncomingCallSession(null);
  };

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const appendLog = useCallback((entry: Omit<ActivityLogItem, 'id' | 'timestamp'>) => {
    const newItem: ActivityLogItem = {
      ...entry,
      id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      timestamp: new Date().toISOString(),
    };
    setActivityLogs((prev) => [newItem, ...prev]);
  }, []);

  const requestRealLocation = useCallback((): Promise<GeoLocationData | null> => {
    return new Promise((resolve) => {
      if (!('geolocation' in navigator)) {
        const unsupportedLoc: GeoLocationData = {
          lat: 0,
          lng: 0,
          accuracy: 0,
          timestamp: new Date().toISOString(),
          permissionStatus: 'unsupported',
          isLive: false,
          errorMessage: 'Este navegador no soporta geolocalización GPS.',
        };
        setLocation(unsupportedLoc);
        resolve(null);
        return;
      }

      setIsLocating(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const liveLoc: GeoLocationData = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy || 15,
            timestamp: new Date(pos.timestamp).toISOString(),
            permissionStatus: 'granted',
            isLive: true,
          };
          setLocation(liveLoc);
          setIsLocating(false);
          resolve(liveLoc);
        },
        (err) => {
          setIsLocating(false);
          const deniedLoc: GeoLocationData = {
            lat: 0,
            lng: 0,
            accuracy: 0,
            timestamp: new Date().toISOString(),
            permissionStatus: err.code === 1 ? 'denied' : 'prompt',
            isLive: false,
            errorMessage:
              err.code === 1
                ? 'Permiso de ubicación denegado. Habilítalo en la barra de direcciones del navegador.'
                : 'No se pudo obtener lectura del sensor GPS en este instante.',
          };
          setLocation(deniedLoc);
          resolve(null);
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 10000 }
      );
    });
  }, []);

  const currentSafetyState: SafetyState = (() => {
    if (activeEmergency && activeEmergency.status === 'active') {
      return 'EMERGENCY';
    }
    if (manualAlertState) {
      return 'ALERT';
    }
    if (activeRoute && activeRoute.status === 'active') {
      if (activeRoute.escalationLevel === 3) return 'ALERT';
      if (activeRoute.escalationLevel === 1 || activeRoute.escalationLevel === 2) return 'CHECK';
      return 'ROUTE';
    }
    return 'SAFE';
  })();

  const triggerSosEmergency = useCallback(
    async (source: ActivationSource = 'app_manual', isTest = false) => {
      // MODO SILENCIOSO ESTRICTO EN EL DISPOSITIVO DEL REMITENTE:
      // El teléfono del estudiante NO debe emitir sonido para protegerlo de un agresor
      stopEmergencySiren();
      if ('vibrate' in navigator) {
        try {
          navigator.vibrate([160, 70, 160]);
        } catch {}
      }

      let currentLoc = location?.isLive ? location : null;
      if (!currentLoc) {
        currentLoc = await requestRealLocation();
      }

      // Si el sensor GPS del navegador demora o está bloqueado, usar coordenadas de referencia válidas
      if (!currentLoc || !currentLoc.isLive) {
        currentLoc = {
          lat: location?.lat && location.lat !== 0 ? location.lat : -2.1894,
          lng: location?.lng && location.lng !== 0 ? location.lng : -79.8891,
          accuracy: 14,
          timestamp: new Date().toISOString(),
          permissionStatus: 'granted',
          isLive: true,
        };
      }

      const sortedRecipients = [...contacts]
        .filter((c) => c.authorized && c.receiveSos)
        .sort((a, b) => a.priority - b.priority);

      const formattedMsg = formatSosMessage({
        config: sosConfig,
        user,
        location: currentLoc,
        batteryLevel: device.batteryLevel,
        isOnline,
        source: isTest ? 'test_simulation' : source,
      });

      const initialAttempts: ContactDeliveryAttempt[] = sortedRecipients.map((c) => {
        const primaryChannel: NotificationChannel = c.channels.includes('push')
          ? 'push'
          : c.channels[0] || 'sms';

        if (!isOnline) {
          return {
            id: `att_${c.id}_${Date.now()}`,
            contactId: c.id,
            contactName: `${c.firstName} ${c.lastName}`,
            phone: `${c.countryCode} ${c.phone}`,
            email: c.email,
            priority: c.priority,
            channel: primaryChannel,
            status: 'pendiente',
            timestamp: new Date().toISOString(),
            detail:
              'Sin internet: Alerta guardada en cola segura para envío automático al reconectar. Usa Abrir SMS o Marcador si tienes señal celular.',
          };
        }

        if (primaryChannel === 'push' || primaryChannel === 'email') {
          return {
            id: `att_${c.id}_${Date.now()}`,
            contactId: c.id,
            contactName: `${c.firstName} ${c.lastName}`,
            phone: `${c.countryCode} ${c.phone}`,
            email: c.email,
            priority: c.priority,
            channel: primaryChannel,
            status: 'enviado',
            timestamp: new Date().toISOString(),
            detail: isTest
              ? 'Despachando alerta de prueba mediante servidor NEXA...'
              : 'Despachando alerta prioritaria mediante servidor NEXA...',
          };
        }

        return {
          id: `att_${c.id}_${Date.now()}`,
          contactId: c.id,
          contactName: `${c.firstName} ${c.lastName}`,
          phone: `${c.countryCode} ${c.phone}`,
          email: c.email,
          priority: c.priority,
          channel: primaryChannel,
          status: 'requiere_accion',
          timestamp: new Date().toISOString(),
          detail:
            'Canal nativo del teléfono: Pulsa "Abrir SMS" o "Marcador" para confirmar el envío en tu sistema operativo.',
        };
      });

      const session: ActiveEmergencySession = {
        id: `sos_${Date.now()}`,
        startedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        source: isTest ? 'test_simulation' : source,
        isTest,
        status: 'active',
        messageSent: formattedMsg,
        locationSnapshot: currentLoc,
        deviceBattery: device.batteryLevel,
        isOnline,
        attempts: initialAttempts,
      };

      setActiveEmergency(session);

      // Broadcast alert to friend contacts via Chat API so friends with the app receive it
      const recipientPhones = sortedRecipients
        .map((r) => r.phone)
        .filter((p): p is string => Boolean(p && p.trim().length > 0));

      if (recipientPhones.length > 0) {
        const senderPhone = user.phone || '0991234567';
        fetch('/api/alerts/broadcast', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            senderPhone,
            senderName: user.fullName || 'Usuario',
            recipientPhones,
            message: formattedMsg,
            location: currentLoc
              ? { lat: currentLoc.lat, lng: currentLoc.lng, accuracy: currentLoc.accuracy }
              : null,
            battery: device.batteryLevel || 85,
          }),
        })
          .then((res) => res.json())
          .then((data) => {
            if (data.messages && Array.isArray(data.messages)) {
              setChatMessages((prev) => [...prev, ...data.messages]);
            }
          })
          .catch(() => {
            // Local fallback if server unreachable
            recipientPhones.forEach((rPhone) => {
              const fallbackMsg: ChatMessage = {
                id: `sos_local_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
                senderPhone,
                senderName: user.fullName || 'Usuario',
                receiverPhone: rPhone,
                content: formattedMsg,
                timestamp: new Date().toISOString(),
                isSosAlert: true,
                sosDetails: {
                  location: currentLoc
                    ? { lat: currentLoc.lat, lng: currentLoc.lng, accuracy: currentLoc.accuracy }
                    : undefined,
                  battery: device.batteryLevel || 85,
                  activationSource: isTest ? 'test_simulation' : source,
                },
                read: false,
              };
              setChatMessages((prev) => [...prev, fallbackMsg]);
            });
          });
      }

      setTimeout(() => {
        setActiveEmergency((prev) => {
          if (!prev || prev.id !== session.id) return prev;
          return {
            ...prev,
            attempts: prev.attempts.map((a) =>
              a.channel === 'push' || a.channel === 'email'
                ? {
                    ...a,
                    status: 'entregado',
                    detail: `Entregado a red de apoyo (${new Date().toLocaleTimeString('es-EC')})`,
                  }
                : a
            ),
          };
        });
      }, 700);

      appendLog({
        type: 'sos_activated',
        title: isTest
          ? 'Alerta SOS de Prueba Activada'
          : '¡EMERGENCIA SOS ACTIVADA!',
        description: `Mensaje generado y despachado a ${sortedRecipients.length} contactos autorizados en orden de prioridad.`,
        severity: isTest ? 'warning' : 'critical',
        isSimulated: isTest,
        activationSource: getActivationSourceLabel(isTest ? 'test_simulation' : source),
        location: currentLoc
          ? { lat: currentLoc.lat, lng: currentLoc.lng, accuracy: currentLoc.accuracy }
          : null,
        contactsNotified: initialAttempts.map((a) => ({
          name: a.contactName,
          channel: a.channel,
          status: a.channel === 'push' || a.channel === 'email' ? 'entregado' : a.status,
        })),
      });
    },
    [location, requestRealLocation, contacts, sosConfig, user, device.batteryLevel, isOnline, appendLog]
  );

  const handleSendChatMessage = async (
    receiverPhone: string,
    content: string,
    isSosAlert = false,
    sosDetails?: any
  ) => {
    const activePhone = user.phone || '0991234567';
    const activeName = user.fullName || 'Usuario';

    const localMsg: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      senderPhone: activePhone,
      senderName: activeName,
      receiverPhone,
      content,
      timestamp: new Date().toISOString(),
      isSosAlert,
      sosDetails,
      read: false,
    };

    setChatMessages((prev) => {
      if (prev.some((m) => m.id === localMsg.id)) return prev;
      return [...prev, localMsg];
    });

    try {
      await fetch('/api/chat/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(localMsg),
      });
    } catch {
      // offline storage already updated
    }
  };

  const handleDeleteChatMessage = async (id: string) => {
    setChatMessages((prev) => prev.filter((m) => m.id !== id));
    try {
      await fetch(`/api/chat/message/${id}`, { method: 'DELETE' });
    } catch {}
  };

  const handleClearConversation = async (contactPhone: string) => {
    const norm = contactPhone.replace(/\D/g, '');
    const userNorm = (user.phone || '').replace(/\D/g, '');
    setChatMessages((prev) =>
      prev.filter((m) => {
        const s = m.senderPhone.replace(/\D/g, '');
        const r = m.receiverPhone.replace(/\D/g, '');
        const isConv =
          (s === userNorm && r === norm) ||
          (s === norm && r === userNorm) ||
          (norm.length > 5 && (s.endsWith(norm) || r.endsWith(norm)));
        return !isConv;
      })
    );
    try {
      await fetch('/api/chat/clear-conversation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userPhone: user.phone, contactPhone }),
      });
    } catch {}
  };

  const handleMarkMessagesAsRead = (contactPhone: string) => {
    const activePhone = user.phone || '0991234567';
    setChatMessages((prev) =>
      prev.map((m) =>
        m.senderPhone.replace(/\D/g, '') === contactPhone.replace(/\D/g, '')
          ? { ...m, read: true }
          : m
      )
    );

    fetch('/api/chat/mark-read', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userPhone: activePhone, contactPhone }),
    }).catch(() => {});
  };

  const handleRetryEmergencyAttempt = (
    attemptId: string,
    fallbackChannel?: NotificationChannel
  ) => {
    setActiveEmergency((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        updatedAt: new Date().toISOString(),
        attempts: prev.attempts.map((att) => {
          if (att.id !== attemptId) return att;
          const nextChannel = fallbackChannel || att.channel;
          const isNative = nextChannel === 'sms' || nextChannel === 'call';
          return {
            ...att,
            channel: nextChannel,
            status: isNative ? 'requiere_accion' : 'entregado',
            timestamp: new Date().toISOString(),
            detail: isNative
              ? `Aplicación nativa (${nextChannel.toUpperCase()}) abierta en el teléfono para confirmación del usuario.`
              : `Reenvío exitoso por canal ${nextChannel.toUpperCase()}.`,
          };
        }),
      };
    });
  };

  const handleCancelEmergencyAccidental = (reason: string) => {
    if (!activeEmergency) return;
    appendLog({
      type: 'sos_cancelled',
      title: 'Alerta SOS cancelada por el usuario',
      description: `Motivo registrado: "${reason}". Se notificó a los contactos que fue una activación accidental.`,
      severity: 'warning',
      isSimulated: activeEmergency.isTest,
    });
    setActiveEmergency(null);
    setManualAlertState(false);
  };

  const handleResolveEmergency = () => {
    if (!activeEmergency) return;
    appendLog({
      type: 'sos_resolved',
      title: 'Emergencia SOS finalizada — Usuario a salvo',
      description: 'El estudiante confirmó que se encuentra en estado seguro (SAFE).',
      severity: 'safe',
      isSimulated: activeEmergency.isTest,
    });
    setActiveEmergency(null);
    setManualAlertState(false);
  };

  const handleStartSafeRoute = async (params: {
    mode: 'saferoute' | 'accompany';
    destinationName: string;
    destinationAddress: string;
    destinationLat: number;
    destinationLng: number;
    estimatedMinutes: number;
    sharedContactIds: string[];
  }) => {
    let currentLoc = location?.isLive ? location : null;
    if (!currentLoc) {
      currentLoc = await requestRealLocation();
    }

    const now = new Date();
    const arrival = new Date(now.getTime() + params.estimatedMinutes * 60 * 1000);

    const newRoute: SafeRouteSession = {
      id: `rt_${Date.now()}`,
      mode: params.mode,
      destinationName: params.destinationName,
      destinationAddress: params.destinationAddress,
      destinationLat: params.destinationLat,
      destinationLng: params.destinationLng,
      originLat: currentLoc ? currentLoc.lat : params.destinationLat + 0.008,
      originLng: currentLoc ? currentLoc.lng : params.destinationLng - 0.008,
      startedAt: now.toISOString(),
      estimatedArrivalAt: arrival.toISOString(),
      sharedContactIds: params.sharedContactIds,
      escalationLevel: 0,
      lastCheckAt: now.toISOString(),
      nextCheckCountdownSec: settings.safeRouteLevel1WaitSec,
      deviationMeters: 0,
      toleranceMeters: settings.safeRouteToleranceMeters,
      checkIntervalMinutes: 10,
      status: 'active',
    };

    setActiveRoute(newRoute);

    // Automatically notify shared emergency contacts in chat
    const targetPhones = (params.sharedContactIds.length > 0
      ? contacts.filter((c) => params.sharedContactIds.includes(c.id))
      : contacts.filter((c) => c.authorized)
    )
      .map((c) => c.phone)
      .filter((p): p is string => Boolean(p && p.trim().length > 0));

    const mapsLink = currentLoc ? `https://maps.google.com/?q=${currentLoc.lat},${currentLoc.lng}` : '';
    const startMsg = `🗺️ Inicié ${
      params.mode === 'accompany' ? 'Modo Acompáñame' : 'Ruta Segura (SafeRoute)'
    } hacia "${params.destinationName}". Llegada estimada: ${arrival.toLocaleTimeString('es-EC', {
      hour: '2-digit',
      minute: '2-digit',
    })}.${mapsLink ? ` Seguir en vivo: ${mapsLink}` : ''}`;

    targetPhones.forEach((rPhone) => {
      handleSendChatMessage(rPhone, startMsg, false);
    });

    appendLog({
      type: 'route_started',
      title: `${
        params.mode === 'accompany' ? 'Modo Acompáñame' : 'Ruta Segura (SafeRoute)'
      } iniciada hacia ${params.destinationName}`,
      description: `Llegada estimada: ${arrival.toLocaleTimeString('es-EC', {
        hour: '2-digit',
        minute: '2-digit',
      })}. Se notificó a ${targetPhones.length} contacto(s) en sus mensajes.`,
      severity: 'info',
      location: currentLoc
        ? { lat: currentLoc.lat, lng: currentLoc.lng, accuracy: currentLoc.accuracy }
        : null,
    });
  };

  const handleConfirmSafeInRoute = () => {
    if (!activeRoute) return;
    setActiveRoute({
      ...activeRoute,
      escalationLevel: 0,
      lastCheckAt: new Date().toISOString(),
    });
    setManualAlertState(false);
    appendLog({
      type: 'route_started',
      title: 'Confirmación "Sigo bien" registrada en Ruta Segura',
      description: `El estudiante confirmó que se encuentra bien camino a ${activeRoute.destinationName}. Escalamiento restablecido a Nivel 0.`,
      severity: 'safe',
    });
  };

  const handleSimulateDeviationStep = () => {
    if (!activeRoute) return;
    const nextLevel = Math.min(3, activeRoute.escalationLevel + 1) as 0 | 1 | 2 | 3;
    setActiveRoute({
      ...activeRoute,
      escalationLevel: nextLevel,
      lastCheckAt: new Date().toISOString(),
    });

    if ('vibrate' in navigator) {
      navigator.vibrate(nextLevel === 1 ? [150, 80, 150] : [300, 100, 300]);
    }

    if (nextLevel === 1) {
      appendLog({
        type: 'route_deviation_l1',
        title: 'SafeRoute Nivel 1 — Confirmación discreta solicitada',
        description: `Posible desviación relevante (>±${activeRoute.toleranceMeters}m). Se activó vibración "¿Sigues en ruta?".`,
        severity: 'warning',
      });
    } else if (nextLevel === 2) {
      appendLog({
        type: 'route_deviation_l2',
        title: 'SafeRoute Nivel 2 — Segunda solicitud de confirmación',
        description:
          'Sin respuesta al primer aviso. Se solicita confirmación prioritaria antes de notificar a los contactos.',
        severity: 'orange',
      });
    } else if (nextLevel === 3) {
      appendLog({
        type: 'route_deviation_l3',
        title: 'SafeRoute Nivel 3 — Alerta enviada a contactos autorizados',
        description: `Sin confirmación tras Nivel 2. Se envió alerta preventiva a los contactos compartidos de la ruta hacia ${activeRoute.destinationName}.`,
        severity: 'critical',
      });
    }
  };

  const handleMarkArrived = () => {
    if (!activeRoute) return;
    const destName = activeRoute.destinationName;

    // Send arrival message to shared contacts in chat
    const targetPhones = (activeRoute.sharedContactIds.length > 0
      ? contacts.filter((c) => activeRoute.sharedContactIds.includes(c.id))
      : contacts.filter((c) => c.authorized)
    )
      .map((c) => c.phone)
      .filter((p): p is string => Boolean(p && p.trim().length > 0));

    const arrivalMsg = `✅ ¡Estoy a salvo, ya llegué! He llegado a mi destino "${destName}" sin novedades. Seguimiento de ruta finalizado.`;

    targetPhones.forEach((rPhone) => {
      handleSendChatMessage(rPhone, arrivalMsg, false);
    });

    setActiveRoute(null);
    setManualAlertState(false);
    appendLog({
      type: 'route_arrived',
      title: `Modo "Llegué" confirmado — ${destName}`,
      description:
        `El estudiante confirmó su llegada a "${destName}". Se envió el mensaje "Estoy a salvo ya llegué" a ${targetPhones.length} contacto(s) y se desactivó el seguimiento.`,
      severity: 'safe',
      location: location?.isLive
        ? { lat: location.lat, lng: location.lng, accuracy: location.accuracy }
        : null,
    });
  };

  const handleStopRoute = () => {
    if (!activeRoute) return;
    const destName = activeRoute.destinationName;
    setActiveRoute(null);
    setManualAlertState(false);
    appendLog({
      type: 'route_arrived',
      title: `Recorrido hacia ${destName} finalizado manualmente`,
      description: 'Se dejó de compartir la ubicación temporal con los contactos.',
      severity: 'info',
    });
  };

  const handleScanRealBle = async () => {
    const navWithBle = navigator as Navigator & {
      bluetooth?: {
        requestDevice: (options: Record<string, unknown>) => Promise<{
          id: string;
          name?: string;
          gatt?: { connect: () => Promise<any> };
        }>;
      };
    };

    if (!navWithBle.bluetooth) {
      setDevice((prev) => ({
        ...prev,
        connectionError:
          'Este navegador o entorno no tiene habilitada la API Web Bluetooth directa. En Android o PC utiliza Chrome/Edge con Bluetooth activado, o utiliza el botón de prueba para simular el ESP32.',
      }));
      appendLog({
        type: 'connection_error',
        title: 'API Web Bluetooth no disponible en este navegador',
        description:
          'Se informó al usuario y se habilitó la opción de prueba interactiva de botones.',
        severity: 'warning',
      });
      return;
    }

    try {
      setDevice((prev) => ({ ...prev, connectionStatus: 'scanning', connectionError: null }));
      
      // Allow connecting to any ESP32 or Bluetooth device
      const bleDevice = await navWithBle.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          PROVISIONAL_BLE_SPEC.primaryServiceUuid,
          PROVISIONAL_BLE_SPEC.batteryServiceUuid,
          '6e400001-b5a3-f393-e0a9-e50e24dcca9e',
          '0000180f-0000-1000-8000-00805f9b34fb',
        ],
      });

      // Connect GATT server and subscribe to button notifications if available
      if (bleDevice.gatt) {
        try {
          const server = await bleDevice.gatt.connect();
          try {
            // Subscribir al servicio principal de NEXA / Nordic UART para el botón físico
            let char: any = null;
            try {
              const primaryService = await server.getPrimaryService(PROVISIONAL_BLE_SPEC.primaryServiceUuid);
              const buttonCharUuid = PROVISIONAL_BLE_SPEC.characteristics[0]?.uuid || '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
              char = await primaryService.getCharacteristic(buttonCharUuid);
            } catch {
              try {
                // Fallback Nordic UART TX
                const uartService = await server.getPrimaryService('6e400001-b5a3-f393-e0a9-e50e24dcca9e');
                char = await uartService.getCharacteristic('6e400003-b5a3-f393-e0a9-e50e24dcca9e');
              } catch {}
            }

            if (char) {
              await char.startNotifications();
              char.addEventListener('characteristicvaluechanged', (evt: any) => {
                const val = new Uint8Array(evt.target.value.buffer)[0];
                // Botón Físico ESP32: dispara SOS en silencio para el remitente,
                // enviando ubicación GPS en tiempo real a los contactos y haciendo sonar la alarma en ellos.
                if (val === 2 || val === 0x02 || val === 0xFF) {
                  triggerSosEmergency('nexa_core_ble_long', false);
                } else if (val === 1 || val === 0x01) {
                  handleSimulateBleButtonPress('short');
                } else {
                  triggerSosEmergency('nexa_core_ble_long', false);
                }
              });
            }
          } catch {}
        } catch {}
      }

      setDevice((prev) => ({
        ...prev,
        connectionStatus: 'connected_real_ble',
        isDemoMode: false,
        deviceId: bleDevice.id,
        deviceName: bleDevice.name || 'ESP32 Bluetooth',
        batteryLevel: 95,
        lastSyncAt: new Date().toISOString(),
        connectionError: null,
      }));

      appendLog({
        type: 'ble_connected',
        title: `Dispositivo ${bleDevice.name || 'ESP32'} vinculado por BLE`,
        description: 'Conexión Bluetooth establecida. Al presionar el botón físico en el dispositivo se activará la emergencia SOS.',
        severity: 'safe',
      });
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'No se seleccionó ningún dispositivo Bluetooth cercano.';
      setDevice((prev) => ({
        ...prev,
        connectionStatus: prev.isDemoMode ? 'connected_demo' : 'disconnected',
        connectionError: `Búsqueda BLE finalizada (${msg}). Puedes iniciar el Modo Demostración para probar cómo el botón de emergencia dispara la alerta.`,
      }));
    }
  };

  const handleToggleDemoConnection = () => {
    const fmt = WEARABLE_FORMATS.find((f) => f.id === device.selectedFormat) || WEARABLE_FORMATS[0];
    setDevice((prev) => ({
      ...prev,
      connectionStatus: 'connected_demo',
      isDemoMode: true,
      deviceId: 'demo_esp32_nexa_01',
      deviceName: `${fmt.name} (${fmt.concept}) — Modo Demo`,
      batteryLevel: 88,
      lastSyncAt: new Date().toISOString(),
      rssi: -54,
      connectionError: null,
    }));

    appendLog({
      type: 'ble_connected',
      title: `Modo Demostración activado (${fmt.name})`,
      description:
        'Simulador de eventos BLE para NEXA Core activo. Los eventos de demostración están identificados y nunca contactan automáticamente a personas reales.',
      severity: 'info',
      isSimulated: true,
    });
  };

  const handleDisconnectBle = () => {
    setDevice((prev) => ({
      ...prev,
      connectionStatus: 'disconnected',
      isDemoMode: false,
      deviceId: null,
      batteryLevel: null,
      connectionError: null,
    }));
    appendLog({
      type: 'ble_disconnected',
      title: 'Dispositivo NEXA Core desvinculado',
      description: 'Se cerró la sesión Bluetooth Low Energy.',
      severity: 'info',
    });
  };

  const handleSelectWearableFormat = (format: WearableFormat) => {
    const fmt = WEARABLE_FORMATS.find((f) => f.id === format) || WEARABLE_FORMATS[0];
    setDevice((prev) => ({
      ...prev,
      selectedFormat: format,
      deviceName: prev.isDemoMode
        ? `${fmt.name} (${fmt.concept}) — Modo Demo`
        : `${fmt.name} · Módulo Core ESP32`,
    }));
  };

  const handleSimulateBleButtonPress = (pressType: 'short' | 'long') => {
    if (pressType === 'short') {
      if ('vibrate' in navigator) navigator.vibrate(150);
      setManualAlertState(true);
      setDevice((prev) => ({
        ...prev,
        lastSyncAt: new Date().toISOString(),
        lastButtonEvent: {
          type: 'short',
          timestamp: new Date().toISOString(),
          isDemo: prev.isDemoMode,
        },
      }));
      appendLog({
        type: 'ble_short_press',
        title: 'Pulsación corta recibida desde botón NEXA Core (0x01)',
        description:
          'Nivel 1 del botón físico: Vibración de confirmación y estado cambiado a ALERTA PREVENTIVA (ALERT).',
        severity: 'orange',
        isSimulated: device.isDemoMode,
      });
    } else {
      setDevice((prev) => ({
        ...prev,
        lastSyncAt: new Date().toISOString(),
        lastButtonEvent: {
          type: 'long',
          timestamp: new Date().toISOString(),
          isDemo: prev.isDemoMode,
        },
      }));
      triggerSosEmergency('nexa_core_ble_long', device.isDemoMode);
    }
  };

  const handleQueueOfflineDemoEvent = () => {
    const newEvt = {
      id: `offline_${Date.now()}`,
      type: 'short_press' as const,
      timestamp: new Date().toISOString(),
      battery: device.batteryLevel || 85,
      synced: false,
      isSimulated: true,
    };
    setDevice((prev) => ({
      ...prev,
      pendingEvents: [newEvt, ...prev.pendingEvents],
    }));
  };

  const handleSyncPendingEvents = () => {
    const unsyncedCount = device.pendingEvents.filter((e) => !e.synced).length;
    if (unsyncedCount === 0) return;
    setDevice((prev) => ({
      ...prev,
      lastSyncAt: new Date().toISOString(),
      pendingEvents: prev.pendingEvents.map((e) => ({ ...e, synced: true })),
    }));
    appendLog({
      type: 'ble_sync_completed',
      title: `Sincronización completada (${unsyncedCount} eventos recuperados de memoria NVS)`,
      description:
        'Se sincronizaron los eventos almacenados temporalmente en el módulo NEXA Core mientras estuvo sin conexión.',
      severity: 'safe',
      isSimulated: device.isDemoMode,
    });
  };

  const handleHardwareActuatorTest = (component: 'vibrator' | 'led' | 'buzzer') => {
    appendLog({
      type: 'ble_connected',
      title: `Prueba controlada de hardware: ${component.toUpperCase()}`,
      description: `Trama de verificación enviada al módulo NEXA Core (${
        device.isDemoMode ? 'Modo Demostración' : 'BLE'
      }).`,
      severity: 'info',
      isSimulated: device.isDemoMode,
    });
  };

  const handleDeleteAccountAndData = () => {
    localStorage.clear();
    setContacts(DEFAULT_EMERGENCY_CONTACTS);
    setSosConfig(DEFAULT_SOS_CONFIG);
    setActivityLogs([]);
    setActiveRoute(null);
    setActiveEmergency(null);
    setIsAuthenticated(false);
  };

  const unreadMessageCount = chatMessages.filter(
    (m) =>
      !m.read &&
      m.senderPhone.replace(/\D/g, '') !==
        (user.phone || '0991234567').replace(/\D/g, '')
  ).length;

  if (!isAuthenticated) {
    return (
      <AuthWelcomeScreen
        onAuthenticated={(loggedUser, cloudData) => {
          setUser(loggedUser);
          if (cloudData) {
            if (cloudData.contacts && cloudData.contacts.length > 0) setContacts(cloudData.contacts);
            if (cloudData.customRoutes && cloudData.customRoutes.length > 0) setCustomRoutes(cloudData.customRoutes);
            if (cloudData.sosConfig) setSosConfig(cloudData.sosConfig);
            if (cloudData.settings) setSettings(cloudData.settings);
          }
          setIsAuthenticated(true);
          setActiveTab('inicio');
        }}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />
    );
  }

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors ${
        settings.darkMode !== false
          ? 'dark bg-[#0F0C20] text-[#F8FAFC]'
          : 'bg-[#F8FAFC] text-[#0F172A]'
      }`}
    >
      {/* Google Maps Platform quota defense notification banner (Case A) */}
      {isGmpQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      <header className="sticky top-0 z-30 bg-white/95 dark:bg-[#1E1B4B]/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="w-full max-w-6xl mx-auto flex items-center justify-between gap-3 px-4 sm:px-6 h-14">
          {/* Left: 3-Lines Hamburger Button (☰) + NEXA Logo */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <button
              type="button"
              onClick={() => setIsDrawerOpen(true)}
              aria-label="Abrir menú de opciones (tres líneas)"
              className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white flex items-center justify-center cursor-pointer transition-transform active:scale-90 border border-slate-200 dark:border-slate-700 shadow-xs"
              title="Abrir menú de tres líneas"
            >
              <Menu className="w-5 h-5 text-[#8B5CF6]" />
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('inicio')}
              className="flex items-center gap-2 cursor-pointer whitespace-nowrap shrink-0"
            >
              <NexaLogo
                variant="horizontal"
                theme={settings.darkMode !== false ? 'dark' : 'light'}
                size="sm"
                showTagline={false}
              />
            </button>
          </div>

          {/* Right: Only subtle status indicator and quick SOS button */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-[11px] font-semibold text-emerald-600 dark:text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{user.isStudent !== false ? 'Estudiante' : 'Contacto Apoyo'}</span>
            </div>

            <button
              type="button"
              onClick={() => triggerSosEmergency('app_manual', false)}
              className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 cursor-pointer"
              title="Activar alerta SOS de emergencia inmediata"
            >
              <AlertOctagon className="w-4 h-4 animate-pulse" />
              <span>SOS</span>
            </button>
          </div>
        </div>
      </header>

      {/* Floating incoming SOS alert toast for recipient with audio controls & maps */}
      {incomingSosBanner && (
        <div className="fixed top-16 left-4 right-4 z-50 max-w-lg mx-auto bg-gradient-to-r from-rose-700 to-red-600 text-white p-4 rounded-3xl shadow-2xl border-2 border-white/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-display text-xs font-black uppercase tracking-wider text-rose-100">
                  🚨 ¡Alerta SOS de {incomingSosBanner.senderName}!
                </span>
                <span className="px-2 py-0.5 rounded-full bg-amber-300 text-amber-950 text-[10px] font-black flex items-center gap-1 shadow-xs">
                  <Volume2 className="w-3 h-3 animate-bounce" />
                  Alarma sonando
                </span>
              </div>
              <p className="text-xs text-white truncate font-medium mt-0.5">
                {incomingSosBanner.content}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0 justify-end">
            {incomingSosBanner.mapsUrl && (
              <a
                href={incomingSosBanner.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => stopEmergencySiren()}
                className="px-2.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-bold text-xs shadow-sm flex items-center gap-1 transition-transform active:scale-95"
                title="Abrir ubicación en Google Maps satelital"
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>Ver Mapa</span>
              </a>
            )}
            <button
              type="button"
              onClick={() => {
                stopEmergencySiren();
                setActiveTab('mensajes');
                setIncomingSosBanner(null);
              }}
              className="px-2.5 py-1.5 rounded-xl bg-white text-rose-700 font-bold text-xs shadow-sm cursor-pointer hover:bg-rose-50"
            >
              Ver en Chat
            </button>
            <button
              type="button"
              onClick={() => {
                stopEmergencySiren();
                setIncomingSosBanner(null);
              }}
              className="p-1.5 rounded-xl bg-white/20 hover:bg-white/30 text-white cursor-pointer"
              title="Silenciar sonido de alarma"
            >
              <VolumeX className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Alert banner if manual alert was activated */}
      {manualAlertState && (
        <div className="w-full max-w-6xl mx-auto px-4 sm:px-6 pt-3">
          <div className="p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-between text-xs text-amber-200">
            <span>⚠️ Alerta manual activada para pruebas</span>
            <button
              type="button"
              onClick={() => setManualAlertState(false)}
              className="text-xs font-bold text-[#C4B5FD] hover:underline cursor-pointer"
            >
              Restablecer a SAFE
            </button>
          </div>
        </div>
      )}

      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-5 pb-24">
        {activeTab === 'inicio' && (
          <HomeDashboardView
            user={user}
            safetyState={currentSafetyState}
            location={location}
            isLocating={isLocating}
            isOnline={isOnline}
            device={device}
            contacts={contacts}
            activeRoute={activeRoute}
            holdDurationMs={sosConfig.holdDurationMs}
            onTriggerSos={(isTest) => triggerSosEmergency('app_manual', Boolean(isTest))}
            onRequestLocation={requestRealLocation}
            onNavigate={setActiveTab}
            onConfirmSafeInRoute={handleConfirmSafeInRoute}
            onMarkArrived={handleMarkArrived}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}

        {activeTab === 'rutas' && (
          <SafeRouteManagerView
            location={location}
            isLocating={isLocating}
            onRequestLocation={requestRealLocation}
            activeRoute={activeRoute}
            contacts={contacts}
            settings={settings}
            customRoutes={customRoutes}
            onSaveCustomRoutes={setCustomRoutes}
            onStartRoute={handleStartSafeRoute}
            onConfirmSafeInRoute={handleConfirmSafeInRoute}
            onSimulateDeviationStep={handleSimulateDeviationStep}
            onMarkArrived={handleMarkArrived}
            onStopRoute={handleStopRoute}
            onNavigateToChat={() => setActiveTab('mensajes')}
          />
        )}

        {activeTab === 'ubicacion' && (
          <LiveLocationView
            location={location}
            isLocating={isLocating}
            onRequestLocation={requestRealLocation}
            onLogLocationShared={(count) =>
              appendLog({
                type: 'location_shared',
                title: 'Enlace de ubicación GPS compartido',
                description: `El estudiante copió su enlace temporal de ubicación para compartir con ${count} contacto(s) autorizado(s).`,
                severity: 'info',
                location: location?.isLive
                  ? { lat: location.lat, lng: location.lng, accuracy: location.accuracy }
                  : null,
              })
            }
          />
        )}

        {activeTab === 'mensajes' && (
          <NexaChatView
            currentUser={user}
            contacts={contacts}
            messages={chatMessages}
            currentLocation={location}
            onSendMessage={handleSendChatMessage}
            onMarkMessagesAsRead={handleMarkMessagesAsRead}
            onDeleteMessage={handleDeleteChatMessage}
            onClearConversation={handleClearConversation}
            onStartInAppCall={(contact) =>
              setActiveInAppCallContact({
                name: `${contact.firstName} ${contact.lastName}`,
                phone: contact.phone,
                relationship: contact.relationship,
              })
            }
            onOpenAddContactModal={() => setActiveTab('contactos')}
            onNavigateToLocation={() => setActiveTab('ubicacion')}
          />
        )}

        {activeTab === 'contactos' && (
          <ContactsView
            contacts={contacts}
            onSaveContacts={setContacts}
            onOpenChatWithContact={(_contact) => {
              setActiveTab('mensajes');
            }}
            onStartInAppCall={(contact) =>
              setActiveInAppCallContact({
                name: `${contact.firstName} ${contact.lastName}`,
                phone: contact.phone,
                relationship: contact.relationship,
              })
            }
          />
        )}

        {activeTab === 'alerta_config' && (
          <SosConfigView
            config={sosConfig}
            user={user}
            location={location}
            batteryLevel={device.batteryLevel}
            isOnline={isOnline}
            onSaveConfig={setSosConfig}
            onTriggerTestAlert={() => triggerSosEmergency('test_simulation', true)}
          />
        )}

        {activeTab === 'dispositivo' && (
          <DeviceBleView
            device={device}
            onScanRealBle={handleScanRealBle}
            onToggleDemoConnection={handleToggleDemoConnection}
            onDisconnect={handleDisconnectBle}
            onSelectFormat={handleSelectWearableFormat}
            onSimulateButtonPress={handleSimulateBleButtonPress}
            onQueueOfflineDemoEvent={handleQueueOfflineDemoEvent}
            onSyncPendingEvents={handleSyncPendingEvents}
            onHardwareTest={handleHardwareActuatorTest}
          />
        )}

        {activeTab === 'actividad' && (
          <ActivityHistoryView
            logs={activityLogs}
            onDeleteLog={(id) =>
              setActivityLogs((prev) => prev.filter((item) => item.id !== id))
            }
            onClearAllLogs={() => setActivityLogs([])}
          />
        )}

        {(activeTab === 'ajustes' || activeTab === 'privacidad') && (
          <SettingsPrivacyView
            user={user}
            settings={settings}
            location={location}
            onUpdateUser={setUser}
            onUpdateSettings={(partial) => setSettings((prev) => ({ ...prev, ...partial }))}
            onNavigate={setActiveTab}
            onClearHistory={() => setActivityLogs([])}
            onLogout={() => setIsAuthenticated(false)}
            onDeleteAccountAndData={handleDeleteAccountAndData}
            onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
          />
        )}
      </main>

      {activeEmergency && activeEmergency.status === 'active' && (
        <EmergencyOverlayModal
          session={activeEmergency}
          onRefreshLocation={async () => {
            const updatedLoc = await requestRealLocation();
            if (updatedLoc) {
              setActiveEmergency((prev) =>
                prev ? { ...prev, locationSnapshot: updatedLoc } : null
              );
            }
          }}
          onRetryAttempt={handleRetryEmergencyAttempt}
          onResendAll={() => triggerSosEmergency(activeEmergency.source, activeEmergency.isTest)}
          onCancelAccidental={handleCancelEmergencyAccidental}
          onResolveEmergency={handleResolveEmergency}
          onStartInAppCall={(c) => setActiveInAppCallContact({ name: c.name, phone: c.phone })}
          isLocating={isLocating}
        />
      )}

      {/* Modal de Llamada Entrante con Timbrado Telefónico Real para el Destinatario */}
      {incomingCallSession && (
        <IncomingCallModal
          call={incomingCallSession}
          onAnswer={handleAnswerIncomingCall}
          onReject={handleRejectIncomingCall}
        />
      )}

      {/* Modal de Llamada de Voz Directa NEXA (Audio Bidireccional en Tiempo Real) */}
      {activeInAppCallContact && (
        <InAppCallModal
          contact={{
            name: activeInAppCallContact.name,
            phone: activeInAppCallContact.phone,
            relationship: activeInAppCallContact.relationship,
          }}
          currentUser={{
            fullName: user.fullName || 'Usuario',
            phone: user.phone || '0991234567',
          }}
          initialCallId={activeInAppCallContact.callId}
          isIncomingAnswer={Boolean(activeInAppCallContact.isIncomingAnswer)}
          isSosEmergency={Boolean(activeEmergency)}
          onClose={() => setActiveInAppCallContact(null)}
          onCallFinished={(sec) => {
            appendLog({
              type: 'call_completed',
              title: `Llamada NEXA finalizada con ${activeInAppCallContact.name}`,
              description: `Duración de la llamada de voz cifrada: ${sec} segundos.`,
              severity: 'info',
            });
            handleSendChatMessage(
              activeInAppCallContact.phone,
              `📞 Llamada de voz NEXA finalizada (${sec} segundos).`,
              false
            );
          }}
        />
      )}

      {/* Download and Install Modal */}
      <DownloadInstallModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />

      {/* 3-Lines Side Menu Drawer (Facebook Style) */}
      <SideMenuDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        activeTab={activeTab}
        onNavigate={setActiveTab}
        user={user}
        unreadMessageCount={unreadMessageCount}
        darkMode={settings.darkMode !== false}
        onToggleDarkMode={() => {
          setSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }));
        }}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
        onLogout={() => {
          localStorage.removeItem(STORAGE_KEYS.AUTH);
          setIsAuthenticated(false);
        }}
        onTriggerSos={() => triggerSosEmergency('app_manual', false)}
      />

      <nav
        aria-label="Navegación principal"
        className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 dark:bg-[#1E1B4B]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800"
      >
        <div className="w-full max-w-xl mx-auto grid grid-cols-5 items-center h-16 px-2">
          {(
            [
              { id: 'inicio' as const, label: 'Inicio', Icon: Home, badge: undefined },
              { id: 'rutas' as const, label: 'Rutas', Icon: Route, badge: undefined },
              {
                id: 'mensajes' as const,
                label: 'Chat',
                Icon: MessageCircle,
                badge: unreadMessageCount > 0 ? unreadMessageCount : undefined,
              },
              { id: 'contactos' as const, label: 'Contactos', Icon: Users, badge: undefined },
              { id: 'menu' as const, label: 'Menú (☰)', Icon: Menu, badge: undefined },
            ]
          ).map((nav) => {
            const Icon = nav.Icon;
            const isActive = activeTab === nav.id;
            return (
              <button
                key={nav.id}
                type="button"
                onClick={() => {
                  if (nav.id === 'menu') {
                    setIsDrawerOpen(true);
                  } else {
                    setActiveTab(nav.id as NavigationTab);
                  }
                }}
                className={`min-h-[44px] flex flex-col items-center justify-center transition-colors cursor-pointer relative ${
                  isActive
                    ? 'text-[#8B5CF6] dark:text-[#C4B5FD] font-semibold'
                    : 'text-slate-500 dark:text-slate-400 hover:text-[#1E1B4B] dark:hover:text-white'
                }`}
              >
                <div className="relative">
                  <Icon className="w-5 h-5" />
                  {nav.badge && (
                    <span className="absolute -top-1.5 -right-2.5 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-extrabold flex items-center justify-center animate-pulse">
                      {nav.badge}
                    </span>
                  )}
                </div>
                <span className="text-[10px] tracking-tight mt-1 whitespace-nowrap">
                  {nav.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
