/**
 * NEXA Realistic Telephone Ringtone Engine (Web Audio API)
 * Plays an authentic telephone ringing cadence for incoming in-app voice calls:
 * "se tiene que escuchar, ósea como una llamada normal"
 */

let ringAudioCtx: AudioContext | null = null;
let ringInterval: any = null;
let vibrateInterval: any = null;
let isRingingActive = false;

export function isIncomingRingtonePlaying(): boolean {
  return isRingingActive;
}

/**
 * Plays a single telephone ring pulse (dual-frequency 440Hz + 480Hz)
 * with authentic analog telephone modulation and envelope.
 */
function playPhoneRingBurst(ctx: AudioContext, masterGain: GainNode, volume: number): void {
  const now = ctx.currentTime;
  const duration = 1.7; // 1.7 seconds burst of ringing

  // Dual telephone frequencies
  const osc1 = ctx.createOscillator();
  const osc2 = ctx.createOscillator();

  osc1.type = 'sine';
  osc1.frequency.setValueAtTime(440, now);

  osc2.type = 'sine';
  osc2.frequency.setValueAtTime(480, now);

  // Tremolo effect (20Hz cadence modulation, like a real phone bell hammer)
  const tremoloOsc = ctx.createOscillator();
  const tremoloGain = ctx.createGain();
  tremoloOsc.frequency.setValueAtTime(20, now);
  tremoloGain.gain.setValueAtTime(0.35, now);
  tremoloOsc.connect(tremoloGain.gain);

  // Amplitude envelope
  const burstGain = ctx.createGain();
  burstGain.gain.setValueAtTime(0.001, now);
  // Quick ramp up
  burstGain.gain.linearRampToValueAtTime(volume * 0.9, now + 0.08);
  // Sustain
  burstGain.gain.setValueAtTime(volume * 0.9, now + duration - 0.08);
  // Quick ramp down
  burstGain.gain.linearRampToValueAtTime(0.001, now + duration);

  osc1.connect(burstGain);
  osc2.connect(burstGain);
  burstGain.connect(masterGain);

  osc1.start(now);
  osc2.start(now);
  tremoloOsc.start(now);

  osc1.stop(now + duration + 0.05);
  osc2.stop(now + duration + 0.05);
  tremoloOsc.stop(now + duration + 0.05);
}

/**
 * Starts continuous incoming call telephone ringing.
 * Standard cadence: 1.7s Ring -> 2.3s Pause -> Repeat.
 */
export function startIncomingRingtone(volume: number = 0.85): void {
  if (isRingingActive) return;

  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    ringAudioCtx = new AudioContextClass();
    if (ringAudioCtx.state === 'suspended') {
      ringAudioCtx.resume();
    }

    const masterGain = ringAudioCtx.createGain();
    masterGain.gain.setValueAtTime(Math.min(1.0, Math.max(0.1, volume)), ringAudioCtx.currentTime);
    masterGain.connect(ringAudioCtx.destination);

    // Immediate first ring
    playPhoneRingBurst(ringAudioCtx, masterGain, volume);
    isRingingActive = true;

    // Repeat every 4 seconds (1.7s ring + 2.3s pause)
    ringInterval = setInterval(() => {
      if (!ringAudioCtx || ringAudioCtx.state === 'closed') return;
      playPhoneRingBurst(ringAudioCtx, masterGain, volume);
    }, 4000);

    // Telephone vibration pattern on smartphones
    if ('vibrate' in navigator) {
      navigator.vibrate([1500, 1000, 1500, 1000]);
      vibrateInterval = setInterval(() => {
        if ('vibrate' in navigator) {
          navigator.vibrate([1500, 1000, 1500, 1000]);
        }
      }, 4000);
    }
  } catch (err) {
    console.warn('AudioContext ringtone could not start without user interaction:', err);
  }
}

/**
 * Stops incoming call telephone ringing immediately.
 */
export function stopIncomingRingtone(): void {
  if (ringInterval) {
    clearInterval(ringInterval);
    ringInterval = null;
  }
  if (vibrateInterval) {
    clearInterval(vibrateInterval);
    vibrateInterval = null;
  }
  if ('vibrate' in navigator) {
    navigator.vibrate(0);
  }

  try {
    if (ringAudioCtx) {
      ringAudioCtx.close();
      ringAudioCtx = null;
    }
  } catch {}

  isRingingActive = false;
}

/**
 * Plays short call-end / busy tone (beeps 3 times when disconnected).
 */
export function playCallEndedTone(): void {
  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(425, now);

    // Beep 1
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.setValueAtTime(0.001, now + 0.2);
    // Beep 2
    gain.gain.setValueAtTime(0.2, now + 0.35);
    gain.gain.setValueAtTime(0.001, now + 0.55);
    // Beep 3
    gain.gain.setValueAtTime(0.2, now + 0.7);
    gain.gain.setValueAtTime(0.001, now + 0.9);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 1.0);
  } catch {}
}
