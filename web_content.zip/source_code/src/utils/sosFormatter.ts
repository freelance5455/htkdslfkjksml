import {
  ActivationSource,
  GeoLocationData,
  SosMessageConfig,
  UserAccount,
} from '../types';

export function buildGoogleMapsLink(lat: number, lng: number): string {
  return `https://www.google.com/maps?q=${lat.toFixed(6)},${lng.toFixed(6)}`;
}

export function getActivationSourceLabel(source: ActivationSource): string {
  switch (source) {
    case 'app_manual':
      return 'SOS manual desde aplicación NEXA (pulsación 2s)';
    case 'nexa_core_ble_long':
      return 'Botón físico NEXA Core BLE (pulsación prolongada)';
    case 'nexa_core_ble_short':
      return 'Botón físico NEXA Core BLE (pulsación corta / aviso)';
    case 'saferoute_escalation':
      return 'Escalamiento automático Nivel 3 de Ruta Segura (SafeRoute)';
    case 'test_simulation':
      return 'SIMULACIÓN / PRUEBA CONTROLADA (No es una emergencia real)';
  }
}

export function formatSosMessage(params: {
  config: SosMessageConfig;
  user: UserAccount;
  location: GeoLocationData | null;
  batteryLevel: number | null;
  isOnline: boolean;
  source: ActivationSource;
  now?: Date;
}): string {
  const { config, user, location, batteryLevel, isOnline, source, now = new Date() } = params;

  const dateStr = now.toLocaleDateString('es-EC', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
  const timeStr = now.toLocaleTimeString('es-EC', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const hasValidGps = Boolean(location && location.isLive);
  const mapsUrl = hasValidGps && location
    ? buildGoogleMapsLink(location.lat, location.lng)
    : 'Sin señal GPS autorizada en este momento';

  const coordsText = hasValidGps && location
    ? `${location.lat.toFixed(5)}, ${location.lng.toFixed(5)} (±${Math.round(location.accuracy)}m) - ${mapsUrl}`
    : 'Ubicación GPS no disponible (permiso pendiente o sin cobertura)';

  let msg = config.template || '';

  msg = msg
    .replace(/\[NOMBRE\]/gi, user.fullName)
    .replace(/\[ENLACE DE UBICACIÓN\]/gi, mapsUrl)
    .replace(/\[UBICACIÓN\]/gi, coordsText)
    .replace(/\[FECHA\]/gi, dateStr)
    .replace(/\[HORA\]/gi, timeStr)
    .replace(
      /\[BATERÍA\]/gi,
      batteryLevel !== null ? `${batteryLevel}%` : 'No reportada'
    );

  const extraLines: string[] = [];

  if (source === 'test_simulation') {
    extraLines.unshift('[MODO PRUEBA NEXA — ESTE MENSAJE ES UNA DEMOSTRACIÓN]');
  }

  if (config.includeUserName && !config.template.toUpperCase().includes('[NOMBRE]')) {
    extraLines.push(`Estudiante: ${user.fullName}`);
  }

  if (
    config.includeLocationLink &&
    !config.template.toUpperCase().includes('[ENLACE DE UBICACIÓN]') &&
    !config.template.toUpperCase().includes('[UBICACIÓN]')
  ) {
    extraLines.push(`Ubicación: ${coordsText}`);
  } else if (config.includeCoordinates && hasValidGps && location) {
    if (!msg.includes(location.lat.toFixed(5))) {
      extraLines.push(
        `Coordenadas GPS: ${location.lat.toFixed(5)}, ${location.lng.toFixed(5)} (±${Math.round(
          location.accuracy
        )}m)`
      );
    }
  }

  if (
    config.includeTimestamp &&
    !config.template.toUpperCase().includes('[FECHA]') &&
    !config.template.toUpperCase().includes('[HORA]')
  ) {
    extraLines.push(`Fecha y hora: ${dateStr} ${timeStr}`);
  }

  if (config.includeActivationType) {
    extraLines.push(`Activación: ${getActivationSourceLabel(source)}`);
  }

  if (config.includeBatteryLevel) {
    extraLines.push(
      `Batería NEXA Core: ${batteryLevel !== null ? `${batteryLevel}%` : 'Sin dispositivo BLE conectado'}`
    );
  }

  if (config.includeConnectionStatus) {
    extraLines.push(`Red móvil/Internet: ${isOnline ? 'En línea' : 'Sin conexión (evento en cola local)'}`);
  }

  return extraLines.length > 0 ? `${msg}\n\n${extraLines.join(' · ')}` : msg;
}

export function validatePhoneWithCountry(countryCode: string, phone: string): {
  valid: boolean;
  cleanedPhone: string;
  error?: string;
} {
  const cleanedCode = countryCode.trim().startsWith('+')
    ? countryCode.trim()
    : `+${countryCode.trim()}`;
  const digitsOnly = phone.replace(/[\s\-()]/g, '');

  if (!/^\+\d{1,4}$/.test(cleanedCode)) {
    return { valid: false, cleanedPhone: digitsOnly, error: 'Código de país inválido (ej. +593).' };
  }
  if (!/^\d{7,12}$/.test(digitsOnly)) {
    return {
      valid: false,
      cleanedPhone: digitsOnly,
      error: 'Ingresa un número válido de 7 a 12 dígitos sin espacios ni letras.',
    };
  }
  return { valid: true, cleanedPhone: digitsOnly };
}

export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3;
  const p1 = (lat1 * Math.PI) / 180;
  const p2 = (lat2 * Math.PI) / 180;
  const dp = ((lat2 - lat1) * Math.PI) / 180;
  const dl = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(dp / 2) * Math.sin(dp / 2) +
    Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) * Math.sin(dl / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}
