/**
 * NEXA Student Safety Network — Emergency Alert & Notification Service
 * Handles:
 * 1. Screen Wake Lock API (keeps recipient screen awake and lit up during emergency)
 * 2. High-Priority Notifications (Service Worker & Web Notification API with requireInteraction)
 * 3. Cross-Tab / Cross-Window Emergency Synchronization (BroadcastChannel)
 * 4. Permissions Auditing (Notification, Audio, Vibration, Wake Lock, Geolocation)
 */

let wakeLockSentinel: any = null;

export interface EmergencyAlertPayload {
  id: string;
  senderName: string;
  senderPhone: string;
  senderRole?: string;
  institution?: string;
  content: string;
  timestamp: string;
  location?: {
    lat: number;
    lng: number;
    accuracy?: number;
  };
  mapsUrl?: string;
}

// Cross-tab broadcast channel for instant multi-window wake up
let emergencyChannel: BroadcastChannel | null = null;
try {
  if (typeof BroadcastChannel !== 'undefined') {
    emergencyChannel = new BroadcastChannel('nexa_emergency_alert_bus');
  }
} catch {
  emergencyChannel = null;
}

/**
 * Requests Screen Wake Lock to keep the screen active and prevent dimming/sleeping.
 */
export async function requestScreenWakeLock(): Promise<boolean> {
  if (typeof navigator === 'undefined' || !('wakeLock' in navigator)) {
    return false;
  }
  try {
    if (wakeLockSentinel && !wakeLockSentinel.released) {
      return true;
    }
    wakeLockSentinel = await (navigator as any).wakeLock.request('screen');
    wakeLockSentinel.addEventListener('release', () => {
      wakeLockSentinel = null;
    });
    return true;
  } catch (err) {
    console.warn('[NEXA Alert] Screen Wake Lock not granted or unavailable:', err);
    return false;
  }
}

/**
 * Releases active Screen Wake Lock when emergency is acknowledged.
 */
export async function releaseScreenWakeLock(): Promise<void> {
  try {
    if (wakeLockSentinel && !wakeLockSentinel.released) {
      await wakeLockSentinel.release();
    }
  } catch {}
  wakeLockSentinel = null;
}

/**
 * Dispatches a high-priority system notification to wake the user's attention.
 */
export async function dispatchSystemEmergencyNotification(
  payload: EmergencyAlertPayload
): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  // Ensure permission
  if (Notification.permission !== 'granted') {
    return false;
  }

  const title = `🚨 ¡EMERGENCIA SOS: ${payload.senderName.toUpperCase()}!`;
  const body = `${payload.content || 'Requiere asistencia urgente inmediata.'} Coordenadas GPS y llamada disponibles.`;

  // 1. Prefer Service Worker registration showNotification (works better in background / lock screen)
  try {
    if ('serviceWorker' in navigator) {
      const reg = await navigator.serviceWorker.ready;
      if (reg && reg.showNotification) {
        await reg.showNotification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/icon.svg',
          tag: 'nexa-emergency-' + payload.id,
          renotify: true,
          requireInteraction: true,
          data: {
            url: '/?action=emergency_alert&alertId=' + payload.id,
            ...payload,
          },
          actions: [
            { action: 'open_sos', title: '🚨 VER ALERTA Y UBICACIÓN' },
            { action: 'call', title: '📞 LLAMAR AHORA' },
          ],
        } as any);
        return true;
      }
    }
  } catch (err) {
    console.warn('[NEXA Alert] SW notification failed, trying native window Notification:', err);
  }

  // 2. Fallback to standard window Notification
  try {
    const notif = new Notification(title, {
      body,
      icon: '/pwa-192x192.png',
      tag: 'nexa-emergency-' + payload.id,
      requireInteraction: true,
    });
    notif.onclick = () => {
      window.focus();
      notif.close();
    };
    return true;
  } catch (err) {
    console.warn('[NEXA Alert] Window notification error:', err);
    return false;
  }
}

/**
 * Broadcasts an incoming emergency alert to all open tabs / windows on this device.
 */
export function broadcastEmergencyAlert(payload: EmergencyAlertPayload): void {
  try {
    if (emergencyChannel) {
      emergencyChannel.postMessage({ type: 'SOS_EMERGENCY_RECEIVED', payload });
    }
    // Also use localStorage storage event as fallback cross-tab trigger
    localStorage.setItem(
      'nexa_incoming_sos_sync',
      JSON.stringify({ ...payload, _syncedAt: Date.now() })
    );
  } catch {}
}

/**
 * Subscribes a listener to receive cross-tab emergency events.
 */
export function subscribeToEmergencyBroadcasts(
  callback: (payload: EmergencyAlertPayload) => void
): () => void {
  const channelHandler = (event: MessageEvent) => {
    if (event.data && event.data.type === 'SOS_EMERGENCY_RECEIVED') {
      callback(event.data.payload);
    }
  };

  const storageHandler = (e: StorageEvent) => {
    if (e.key === 'nexa_incoming_sos_sync' && e.newValue) {
      try {
        const parsed = JSON.parse(e.newValue);
        callback(parsed);
      } catch {}
    }
  };

  if (emergencyChannel) {
    emergencyChannel.addEventListener('message', channelHandler);
  }
  window.addEventListener('storage', storageHandler);

  return () => {
    if (emergencyChannel) {
      emergencyChannel.removeEventListener('message', channelHandler);
    }
    window.removeEventListener('storage', storageHandler);
  };
}

/**
 * Requests Notification permission with user-friendly handling.
 */
export async function requestNotificationPermission(): Promise<NotificationPermission> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'denied';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch {
    return Notification.permission;
  }
}

/**
 * Returns complete permissions audit for emergency alerting.
 */
export async function getEmergencyPermissionsStatus(): Promise<{
  notifications: NotificationPermission | 'unsupported';
  wakeLockSupported: boolean;
  vibrationSupported: boolean;
  audioSupported: boolean;
  geolocationSupported: boolean;
}> {
  return {
    notifications:
      typeof window !== 'undefined' && 'Notification' in window
        ? Notification.permission
        : 'unsupported',
    wakeLockSupported: typeof navigator !== 'undefined' && 'wakeLock' in navigator,
    vibrationSupported: typeof navigator !== 'undefined' && 'vibrate' in navigator,
    audioSupported:
      typeof window !== 'undefined' &&
      !!(window.AudioContext || (window as any).webkitAudioContext),
    geolocationSupported: typeof navigator !== 'undefined' && 'geolocation' in navigator,
  };
}
