/**
 * NEXA Student Safety Network — Modern High-Priority Emergency Alert Sound Engine
 * Clean, piercing, high-penetration harmonic alert pulse (Web Audio API)
 * Designed for recipients to hear instantly without harsh/grating sawtooth distortion.
 */

let audioCtx: AudioContext | null = null;
let alertInterval: any = null;
let vibrationInterval: any = null;
let isPlaying = false;

export function isEmergencySirenPlaying(): boolean {
  return isPlaying;
}

/**
 * Plays a modern, crisp multi-tone high-priority emergency chime burst.
 * Uses pure sine and soft triangle harmonics (960Hz fundamental + 1440Hz fifth + 1920Hz harmonic)
 * with sharp attack and punchy envelope for immediate ear capture.
 */
function playEmergencyBurst(ctx: AudioContext, masterGain: GainNode, volume: number): void {
  const now = ctx.currentTime;

  // Staggered dual/triple high-urgency chime burst: Beep - Beep - High Chime
  const pulses = [
    { start: 0.0, duration: 0.11, freq1: 960, freq2: 1440, amp: 1.0 },
    { start: 0.16, duration: 0.11, freq1: 960, freq2: 1440, amp: 1.0 },
    { start: 0.32, duration: 0.22, freq1: 1280, freq2: 1920, amp: 1.1 },
  ];

  pulses.forEach((p) => {
    const pStart = now + p.start;
    const pEnd = pStart + p.duration;

    // Fundamental oscillator (pure sine)
    const oscA = ctx.createOscillator();
    oscA.type = 'sine';
    oscA.frequency.setValueAtTime(p.freq1, pStart);

    // Harmonic overtone oscillator (triangle for acoustic clarity and punch)
    const oscB = ctx.createOscillator();
    oscB.type = 'triangle';
    oscB.frequency.setValueAtTime(p.freq2, pStart);

    // Amplitude envelope for this burst
    const burstGain = ctx.createGain();
    burstGain.gain.setValueAtTime(0.001, pStart);
    // Instant attack (punch)
    burstGain.gain.linearRampToValueAtTime(volume * p.amp, pStart + 0.015);
    // Crisp exponential decay
    burstGain.gain.exponentialRampToValueAtTime(0.001, pEnd);

    oscA.connect(burstGain);
    oscB.connect(burstGain);
    burstGain.connect(masterGain);

    oscA.start(pStart);
    oscB.start(pStart);
    oscA.stop(pEnd + 0.02);
    oscB.stop(pEnd + 0.02);
  });
}

/**
 * Starts continuous modern emergency alert sound on recipient's device.
 */
export function startEmergencySiren(volume: number = 0.95): void {
  if (isPlaying) return;

  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    audioCtx = new AudioContextClass();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const masterGain = audioCtx.createGain();
    masterGain.gain.setValueAtTime(Math.min(1.0, Math.max(0.1, volume)), audioCtx.currentTime);
    masterGain.connect(audioCtx.destination);

    // Play immediate first burst
    playEmergencyBurst(audioCtx, masterGain, volume);
    isPlaying = true;

    // Repeat repeating pattern every 750ms for maximum urgency
    alertInterval = setInterval(() => {
      if (!audioCtx || audioCtx.state === 'closed') return;
      playEmergencyBurst(audioCtx, masterGain, volume);
    }, 750);

    // Tactile haptic emergency pattern for mobile devices
    if ('vibrate' in navigator) {
      navigator.vibrate([350, 100, 350, 100, 500]);
      vibrationInterval = setInterval(() => {
        if ('vibrate' in navigator) {
          navigator.vibrate([350, 100, 350, 100, 500]);
        }
      }, 1600);
    }
  } catch (err) {
    console.warn('AudioContext not allowed without user interaction or unsupported:', err);
  }
}

/**
 * Stops any playing emergency alert sound and tactile vibration.
 */
export function stopEmergencySiren(): void {
  if (alertInterval) {
    clearInterval(alertInterval);
    alertInterval = null;
  }
  if (vibrationInterval) {
    clearInterval(vibrationInterval);
    vibrationInterval = null;
  }
  if ('vibrate' in navigator) {
    navigator.vibrate(0);
  }

  try {
    if (audioCtx) {
      audioCtx.close();
      audioCtx = null;
    }
  } catch {}

  isPlaying = false;
}

/**
 * Test the modern alert sound briefly (duration in seconds)
 */
export function testSirenBriefly(durationSec: number = 2.4): void {
  stopEmergencySiren();
  startEmergencySiren(0.85);
  setTimeout(() => {
    stopEmergencySiren();
  }, durationSec * 1000);
}

// Aliases for modern naming
export const startModernAlertSound = startEmergencySiren;
export const stopModernAlertSound = stopEmergencySiren;
export const isModernAlertSoundPlaying = isEmergencySirenPlaying;
