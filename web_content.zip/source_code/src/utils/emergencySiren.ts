/**
 * NEXA Student Safety Network — High-Penetration Emergency Alert Sound Engine
 * Specially engineered for maximum audibility and attention capture on recipient devices:
 * - Dual alternating frequency siren (880 Hz / 1250 Hz) with overtone harmonics
 * - Piercing attack envelope designed to be heard even when phone is in bag or pocket
 * - Seamless integration with Screen Wake Lock API (keeps screen illuminated)
 * - Rhythmic continuous tactile vibration pattern
 */

import { releaseScreenWakeLock, requestScreenWakeLock } from './emergencyAlertService';

let audioCtx: AudioContext | null = null;
let alertInterval: any = null;
let vibrationInterval: any = null;
let isPlaying = false;

export function isEmergencySirenPlaying(): boolean {
  return isPlaying;
}

/**
 * Plays a high-impact, piercing dual-tone emergency burst:
 * Tone 1: 880 Hz (A5 - High Urgency) + 1760 Hz harmonic
 * Tone 2: 1250 Hz (High Alarm) + 2500 Hz overtone
 * Fast alternating sequence designed to cut through ambient noise.
 */
function playEmergencyBurst(ctx: AudioContext, masterGain: GainNode, volume: number): void {
  const now = ctx.currentTime;

  const pulses = [
    { start: 0.0, duration: 0.14, freq1: 880, freq2: 1760, type: 'triangle' as OscillatorType },
    { start: 0.17, duration: 0.14, freq1: 1250, freq2: 2500, type: 'sawtooth' as OscillatorType },
    { start: 0.34, duration: 0.14, freq1: 880, freq2: 1760, type: 'triangle' as OscillatorType },
    { start: 0.51, duration: 0.22, freq1: 1320, freq2: 2640, type: 'sawtooth' as OscillatorType },
  ];

  pulses.forEach((p) => {
    const pStart = now + p.start;
    const pEnd = pStart + p.duration;

    // Primary oscillator
    const oscA = ctx.createOscillator();
    oscA.type = p.type;
    oscA.frequency.setValueAtTime(p.freq1, pStart);

    // Harmonic overtone for penetration
    const oscB = ctx.createOscillator();
    oscB.type = 'sine';
    oscB.frequency.setValueAtTime(p.freq2, pStart);

    // Envelope
    const burstGain = ctx.createGain();
    burstGain.gain.setValueAtTime(0.001, pStart);
    burstGain.gain.linearRampToValueAtTime(volume, pStart + 0.015);
    burstGain.gain.exponentialRampToValueAtTime(0.001, pEnd);

    oscA.connect(burstGain);
    oscB.connect(burstGain);
    burstGain.connect(masterGain);

    oscA.start(pStart);
    oscB.start(pStart);
    oscA.stop(pEnd + 0.02);
    oscB.stop(pEnd + 0.02);
  });
}

/**
 * Starts continuous emergency alarm sound and screen illumination on recipient's device.
 */
export function startEmergencySiren(volume: number = 1.0): void {
  if (isPlaying) return;

  // Request screen wake lock so the screen does not turn off
  requestScreenWakeLock().catch(() => {});

  try {
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    audioCtx = new AudioContextClass();
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    // Dynamic compressor to prevent distortion while keeping maximum sound pressure level (SPL)
    const compressor = audioCtx.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-12, audioCtx.currentTime);
    compressor.knee.setValueAtTime(8, audioCtx.currentTime);
    compressor.ratio.setValueAtTime(4, audioCtx.currentTime);
    compressor.attack.setValueAtTime(0.003, audioCtx.currentTime);
    compressor.release.setValueAtTime(0.25, audioCtx.currentTime);

    const masterGain = audioCtx.createGain();
    masterGain.gain.setValueAtTime(Math.min(1.0, Math.max(0.1, volume)), audioCtx.currentTime);

    masterGain.connect(compressor);
    compressor.connect(audioCtx.destination);

    // Immediate playback
    playEmergencyBurst(audioCtx, masterGain, volume);
    isPlaying = true;

    // Repeat repeating pattern every 850ms continuously until acknowledged
    alertInterval = setInterval(() => {
      if (!audioCtx || audioCtx.state === 'closed') return;
      playEmergencyBurst(audioCtx, masterGain, volume);
    }, 850);

    // Tactile haptic emergency pattern (pulsing vibration)
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      navigator.vibrate([600, 150, 600, 150, 800]);
      vibrationInterval = setInterval(() => {
        if ('vibrate' in navigator) {
          navigator.vibrate([600, 150, 600, 150, 800]);
        }
      }, 1800);
    }
  } catch (err) {
    console.warn('[NEXA Siren] AudioContext blocked or not allowed:', err);
  }
}

/**
 * Stops emergency siren, releases screen wake lock, and clears vibration.
 */
export function stopEmergencySiren(): void {
  if (alertInterval) {
    clearInterval(alertInterval);
    alertInterval = null;
  }
  if (vibrationInterval) {
    clearInterval(vibrationInterval);
    vibrationInterval = null;
  }
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    navigator.vibrate(0);
  }

  // Release screen wake lock
  releaseScreenWakeLock().catch(() => {});

  try {
    if (audioCtx) {
      audioCtx.close();
      audioCtx = null;
    }
  } catch {}

  isPlaying = false;
}

/**
 * Test the alert sound briefly (duration in seconds)
 */
export function testSirenBriefly(durationSec: number = 2.5): void {
  stopEmergencySiren();
  startEmergencySiren(0.9);
  setTimeout(() => {
    stopEmergencySiren();
  }, durationSec * 1000);
}

// Aliases
export const startModernAlertSound = startEmergencySiren;
export const stopModernAlertSound = stopEmergencySiren;
export const isModernAlertSoundPlaying = isEmergencySirenPlaying;
