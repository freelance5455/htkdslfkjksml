import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const publicDir = path.join(rootDir, 'public');
const outputFile = path.join(publicDir, 'nexa-student-safety-network.zip');

const zip = new JSZip();

const excludePrefixes = [
  'node_modules',
  '.git',
  'dist',
  '.cache',
  'data',
  '.aistudio',
  'public/nexa-student-safety-network.zip',
];

function addFilesRecursively(currentPath, zipFolder) {
  const entries = fs.readdirSync(currentPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentPath, entry.name);
    const relPath = path.relative(rootDir, fullPath);

    if (excludePrefixes.some((p) => relPath === p || relPath.startsWith(p + '/'))) {
      continue;
    }

    if (entry.isDirectory()) {
      const subFolder = zipFolder.folder(entry.name);
      if (subFolder) addFilesRecursively(fullPath, subFolder);
    } else if (entry.isFile()) {
      const fileData = fs.readFileSync(fullPath);
      zipFolder.file(entry.name, fileData);
    }
  }
}

async function run() {
  console.log('Empaquetando aplicación NEXA...');
  addFilesRecursively(rootDir, zip);

  const content = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  fs.writeFileSync(outputFile, content);
  console.log(`Zip generado exitosamente (${(content.length / 1024).toFixed(1)} KB) en: ${outputFile}`);
}

run().catch((err) => {
  console.error('Error al empaquetar:', err);
  process.exit(1);
});
