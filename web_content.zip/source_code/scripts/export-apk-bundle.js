import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { execSync } from 'child_process';

const rootDir = process.cwd();
const distDir = path.join(rootDir, 'dist');
const publicDir = path.join(rootDir, 'public');

console.log('1. Compilando aplicación de producción con rutas relativas para Android WebView...');
execSync('npx vite build --base=./', { stdio: 'inherit', cwd: rootDir });

console.log('2. Verificando archivos compilados en dist/...');
if (!fs.existsSync(distDir) || !fs.existsSync(path.join(distDir, 'index.html'))) {
  throw new Error('Error: dist/index.html no fue generado durante la compilación.');
}

const zip = new JSZip();

// 1. Agregar todos los archivos de producción en la RAÍZ del ZIP (para que el convertidor encuentre index.html directamente)
console.log('3. Agregando archivos compilados (index.html, assets, sw.js, manifest) en la raíz del ZIP...');

function addDirectoryToZip(dirPath, zipFolder, baseDir) {
  const items = fs.readdirSync(dirPath, { withFileTypes: true });
  for (const item of items) {
    const fullPath = path.join(dirPath, item.name);
    if (item.isDirectory()) {
      const nextFolder = zipFolder.folder(item.name);
      addDirectoryToZip(fullPath, nextFolder, baseDir);
    } else if (item.isFile()) {
      // Ignorar archivos zip dentro de dist
      if (item.name.endsWith('.zip')) continue;
      const fileData = fs.readFileSync(fullPath);
      zipFolder.file(item.name, fileData);
    }
  }
}

addDirectoryToZip(distDir, zip, distDir);

// 2. Agregar config.xml para convertidores Cordova/PhoneGap/Monaca/Capacitor
const configXmlContent = `<?xml version='1.0' encoding='utf-8'?>
<widget id="com.nexa.studentsafety" version="1.0.0" xmlns="http://www.w3.org/ns/widgets" xmlns:cdv="http://cordova.apache.org/ns/1.0">
    <name>NEXA Safety</name>
    <description>NEXA Student Safety Network - Red de seguridad estudiantil con alertas SOS discretas, SafeRoute y llamadas directas.</description>
    <author email="alexcamilomunoz@gmail.com">NEXA Safety Team</author>
    <content src="index.html" />
    <access origin="*" />
    <allow-intent href="http://*/*" />
    <allow-intent href="https://*/*" />
    <allow-intent href="tel:*" />
    <allow-intent href="sms:*" />
    <allow-intent href="mailto:*" />
    <allow-intent href="geo:*" />
    <preference name="Orientation" value="portrait" />
    <preference name="StatusBarBackgroundColor" value="#1E1B4B" />
    <preference name="StatusBarStyle" value="lightcontent" />
    <preference name="BackgroundColor" value="#0B0F19" />
    <preference name="Fullscreen" value="false" />
    <preference name="DisallowOverscroll" value="true" />
    <icon src="pwa-512x512.png" />
    <platform name="android">
        <allow-intent href="market:*" />
        <icon density="mdpi" src="pwa-192x192.png" />
        <icon density="hdpi" src="pwa-192x192.png" />
        <icon density="xhdpi" src="pwa-192x192.png" />
        <icon density="xxhdpi" src="pwa-512x512.png" />
        <icon density="xxxhdpi" src="pwa-512x512.png" />
    </platform>
</widget>
`;
zip.file('config.xml', configXmlContent);

// 3. Guía clara de instrucciones en texto plano
const instructionsContent = `========================================================================
NEXA Student Safety Network — Paquete Completo para Conversión a APK
========================================================================

Este archivo ZIP contiene la aplicación NEXA completamente compilada,
optimizada y lista con su "index.html" en la raíz para ser convertida a APK.

ESTRUCTURA DEL ARCHIVO ZIP:
- index.html              -> Archivo principal compilado con rutas relativas
- assets/                 -> Códigos JavaScript y estilos CSS compilados
- manifest.json           -> Configuración de la aplicación móvil PWA
- manifest.webmanifest    -> Manifiesto web estándar
- sw.js                   -> Service Worker para funcionamiento Offline
- pwa-192x192.png         -> Icono de la aplicación en alta resolución
- pwa-512x512.png         -> Icono para la pantalla de inicio y splash screen
- pwa-maskable-512x512.png-> Icono adaptable para Android (círculo/cuadrado)
- apple-touch-icon.png    -> Icono para dispositivos iOS
- icon.svg                -> Icono vectorial oficial
- config.xml              -> Archivo de configuración para empaquetadores Android
- source_code/            -> Copia completa del código fuente original TypeScript/React

------------------------------------------------------------------------
CÓMO CONVERTIR ESTE ZIP EN UN ARCHIVO APK PARA ANDROID:
------------------------------------------------------------------------

MÉTODO 1: Convertidores Web / ZIP a APK (El más rápido sin programar)
1. Ingresa a una plataforma externa de conversión como:
   - Website 2 APK Builder (https://websitetoapk.com)
   - AppsGeyser (https://appsgeyser.com)
   - WebviewGold / GoNative
2. Selecciona la opción "Local HTML / ZIP Website".
3. Sube este archivo ZIP tal como está. El convertidor detectará automáticamente el archivo "index.html" en la raíz.
4. Asigna el nombre: "NEXA Safety" y selecciona el icono "pwa-512x512.png".
5. Haz clic en "Build APK" / "Generar APK". ¡Listo!

MÉTODO 2: PWABuilder (Herramienta oficial de Microsoft)
1. Ingresa a https://www.pwabuilder.com
2. Introduce la URL de tu aplicación en línea.
3. PWABuilder validará automáticamente el manifest.json y sw.js incluidos.
4. Presiona "Package for Android" para descargar tu APK firmado.

MÉTODO 3: Con Capacitor / Android Studio (Nativo)
1. Descomprime la carpeta "source_code/".
2. Ejecuta:
   npm install
   npm run build
   npx cap init "NEXA Safety" com.nexa.studentsafety --web-dir dist
   npx cap add android
   npx cap open android
3. En Android Studio presiona: Build > Build APK.

========================================================================
NEXA Student Safety Network · 2026
========================================================================
`;
zip.file('INSTRUCCIONES_APK.txt', instructionsContent);
zip.file('README.md', instructionsContent);

// 4. Agregar carpeta "source_code" con todo el código fuente original (TypeScript, React, server, configs)
console.log('4. Agregando código fuente original en la subcarpeta source_code/...');
const sourceFolder = zip.folder('source_code');

const sourceExclude = [
  'node_modules',
  '.git',
  'dist',
  '.cache',
  'data',
  '.aistudio',
  'public/nexa-student-safety-network.zip',
  'public/nexa-android-apk-bundle.zip',
];

function addSourceRecursively(currentPath, zipFolder) {
  const entries = fs.readdirSync(currentPath, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(currentPath, entry.name);
    const relPath = path.relative(rootDir, fullPath);

    if (sourceExclude.some((p) => relPath === p || relPath.startsWith(p + '/'))) {
      continue;
    }

    if (entry.isDirectory()) {
      const sub = zipFolder.folder(entry.name);
      if (sub) addSourceRecursively(fullPath, sub);
    } else if (entry.isFile()) {
      const fileData = fs.readFileSync(fullPath);
      zipFolder.file(entry.name, fileData);
    }
  }
}

if (sourceFolder) {
  addSourceRecursively(rootDir, sourceFolder);
}

// 5. Generar archivo ZIP en public/
console.log('5. Generando paquete ZIP comprimido...');
const outputApkBundle = path.join(publicDir, 'nexa-android-apk-bundle.zip');
const outputStandardZip = path.join(publicDir, 'nexa-student-safety-network.zip');

const content = await zip.generateAsync({
  type: 'nodebuffer',
  compression: 'DEFLATE',
  compressionOptions: { level: 6 },
});

fs.writeFileSync(outputApkBundle, content);
fs.writeFileSync(outputStandardZip, content);

console.log(`✓ Archivo ZIP generado exitosamente:`);
console.log(`  - ${outputApkBundle} (${(content.length / 1024).toFixed(1)} KB)`);
console.log(`  - ${outputStandardZip} (${(content.length / 1024).toFixed(1)} KB)`);
