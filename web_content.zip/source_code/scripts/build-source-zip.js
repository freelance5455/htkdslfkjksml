import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';

const rootDir = process.cwd();
const publicDir = path.join(rootDir, 'public');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

const zip = new JSZip();

const includePaths = [
  'index.html',
  'package.json',
  'tsconfig.json',
  'vite.config.ts',
  'metadata.json',
  '.env.example',
  'src',
  'public',
];

function addFileToZip(relativePath) {
  const fullPath = path.join(rootDir, relativePath);
  if (!fs.existsSync(fullPath)) return;

  const stat = fs.statSync(fullPath);
  if (stat.isDirectory()) {
    const entries = fs.readdirSync(fullPath);
    for (const entry of entries) {
      if (entry === 'node_modules' || entry === '.git' || entry === 'dist') continue;
      // skip the target zip itself if inside public
      if (entry === 'nexa-student-safety-network.zip') continue;
      addFileToZip(path.join(relativePath, entry));
    }
  } else {
    // Avoid binary artifacts or large caches
    if (relativePath.endsWith('.zip')) return;
    const content = fs.readFileSync(fullPath);
    zip.file(relativePath, content);
  }
}

for (const p of includePaths) {
  addFileToZip(p);
}

// Add informative README.md
const readme = `# NEXA Student Safety Network
> "Tu seguridad, sin llamar la atención."

Sistema integral y discreto de seguridad personal para estudiantes:
- **Botón SOS Inteligente:** Con cuenta regresiva de 2 segundos, vibración háptica, prevención de toques accidentales y cancelación por PIN / clave.
- **Ruta Segura (SafeRoute) y Acompáñame:** Monitoreo activo de trayectos, detección de desvíos, cálculo de llegada y notificación automática a contactos autorizados.
- **Dispositivo Físico Wearable NEXA Core (ESP32 BLE):** Integración con Web Bluetooth API real y modo simulación para 4 formatos de carcasas impresas en 3D (NEXA Clip, NEXA Loop, NEXA Pin, NEXA Nova).
- **Contactos Autorizados y Plantillas SOS:** Configuración con variables dinámicas de GPS, batería y enlace a Google Maps / OpenStreetMap.
- **Privacidad y LOPDP:** Cumplimiento con la Ley Orgánica de Protección de Datos Personales del Ecuador y consentimiento de tutores para menores de edad.

## 🚀 Requisitos e Instalación Local

1. Requiere **Node.js 18+** o superior.
2. Descomprime este archivo en tu equipo.
3. Abre una terminal en la carpeta extraída.
4. Instala las dependencias:
   \`\`\`bash
   npm install
   \`\`\`
5. Inicia el servidor de desarrollo:
   \`\`\`bash
   npm run dev
   \`\`\`
6. Abre tu navegador en:
   \`http://localhost:3000\`

---
Desarrollado para: Damaris Chacha y Alex Muñoz · Unidad Educativa Matilde Amador Santistevan (Guayaquil, Ecuador).
`;

zip.file('README.md', readme);

zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }).then((buffer) => {
  const outPath = path.join(publicDir, 'nexa-student-safety-network.zip');
  fs.writeFileSync(outPath, buffer);
  console.log(`Successfully generated ${outPath} (${buffer.length} bytes)`);
});
