/* ============================================================
 * FEATURE:        Notification List (Premium Redesign)
 * FEATURE NUMBER: 101
 * FILE:           js/notifications/101-notif-list.js
 * ACTION:         REPLACE (v2 — premium UI, all functionality preserved)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * 1. INJECT PREMIUM CSS
   * ============================================================ */
  (function injectNotifCSS() {
    if (document.getElementById('__saiko_notif_css_v2')) return;
    var s = document.createElement('style');
    s.id = '__saiko_notif_css_v2';
    s.textContent =
      '#page-notifications{padding:.7rem .8rem 6rem;}' +

      /* ---- Header ---- */
      '.nt-header{display:flex;align-items:center;gap:.75rem;margin:.2rem 0 1rem;}' +
      '.nt-header-icon{' +
        'width:2.8rem;height:2.8rem;border-radius:.9rem;flex:0 0 auto;' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'display:flex;align-items:center;justify-content:center;color:#fff;' +
        'box-shadow:0 8px 22px rgba(124,92,255,.4);' +
      '}' +
      '.nt-header-icon svg{width:1.5rem;height:1.5rem;}' +
      '.nt-header-titles{flex:1;min-width:0;}' +
      '.nt-header-title{font-size:1.5rem;font-weight:800;letter-spacing:-.02em;line-height:1.1;color:#fff;}' +
      '.nt-header-sub{font-size:.74rem;color:#8b93a7;margin-top:.15rem;}' +
      '.nt-mark-all{' +
        'display:inline-flex;align-items:center;gap:.35rem;' +
        'padding:.5rem .8rem;border-radius:1rem;' +
        'background:linear-gradient(135deg,rgba(124,92,255,.22),rgba(58,160,255,.15));' +
        'border:1px solid rgba(124,92,255,.4);' +
        'color:#c4b5ff;font-size:.72rem;font-weight:700;' +
        'white-space:nowrap;cursor:pointer;' +
        '-webkit-tap-highlight-color:transparent;' +
        'transition:transform .14s ease,background .2s;' +
      '}' +
      '.nt-mark-all:active{transform:scale(.94);}' +
      '.nt-mark-all svg{width:.85rem;height:.85rem;}' +
      '.nt-mark-all:disabled{opacity:.45;pointer-events:none;}' +

      /* ---- Filter pills ---- */
      '.nt-filters{' +
        'display:flex;gap:.45rem;overflow-x:auto;padding-bottom:.6rem;margin-bottom:.9rem;' +
        'scrollbar-width:none;-webkit-overflow-scrolling:touch;' +
      '}' +
      '.nt-filters::-webkit-scrollbar{display:none;}' +
      '.nt-filter{' +
        'display:inline-flex;align-items:center;gap:.35rem;' +
        'padding:.5rem .9rem;border-radius:1.2rem;' +
        'background:rgba(22,34,54,.6);' +
        'border:1px solid rgba(124,92,255,.18);' +
        'color:#8b93a7;font-size:.78rem;font-weight:600;' +
        'white-space:nowrap;flex:0 0 auto;cursor:pointer;' +
        'transition:all .18s ease;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
      '}' +
      '.nt-filter svg{width:.9rem;height:.9rem;}' +
      '.nt-filter:active{transform:scale(.94);}' +
      '.nt-filter.sel{' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'color:#fff;border-color:transparent;' +
        'box-shadow:0 6px 18px rgba(124,92,255,.5);' +
      '}' +

      /* ---- Notification card ---- */
      '.nt-list{display:flex;flex-direction:column;gap:.55rem;}' +

      '.nt-card{' +
        'position:relative;display:flex;align-items:center;gap:.65rem;' +
        'padding:.7rem .75rem;border-radius:1rem;' +
        'background:linear-gradient(180deg,#0f1a2e 0%,#0c1526 100%);' +
        'border:1px solid rgba(124,92,255,.12);' +
        'cursor:pointer;' +
        'transition:transform .14s ease,border-color .2s,box-shadow .2s;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
      '}' +
      '.nt-card:active{transform:scale(.985);}' +
      '.nt-card.unread{' +
        'border-color:rgba(58,160,255,.55);' +
        'box-shadow:0 0 0 1px rgba(58,160,255,.25),0 6px 22px rgba(58,160,255,.14);' +
        'background:linear-gradient(180deg,#122040 0%,#0d1830 100%);' +
      '}' +

      /* Icon badge (colored gradient circle) */
      '.nt-icon{' +
        'width:2.4rem;height:2.4rem;border-radius:50%;flex:0 0 auto;' +
        'display:flex;align-items:center;justify-content:center;' +
        'color:#fff;box-shadow:0 4px 14px rgba(0,0,0,.35);' +
      '}' +
      '.nt-icon svg{width:1.15rem;height:1.15rem;}' +
      '.nt-icon-like{background:linear-gradient(135deg,#ff5c8a,#e63946);}' +
      '.nt-icon-comment{background:linear-gradient(135deg,#3aa0ff,#2563eb);}' +
      '.nt-icon-follow{background:linear-gradient(135deg,#7c5cff,#5b3df0);}' +
      '.nt-icon-share{background:linear-gradient(135deg,#2ecc8f,#10b981);}' +
      '.nt-icon-call{background:linear-gradient(135deg,#ff9f43,#ff7a1a);}' +
      '.nt-icon-reward{background:linear-gradient(135deg,#a55eea,#7c5cff);}' +
      '.nt-icon-story{background:linear-gradient(135deg,#ff5c8a,#a55eea);}' +
      '.nt-icon-system{background:linear-gradient(135deg,#7c5cff,#3aa0ff);}' +
      '.nt-icon-default{background:linear-gradient(135deg,#5b6b8f,#3d4b6b);}' +

      /* Avatar (user photo) */
      '.nt-avatar{' +
        'width:2.4rem;height:2.4rem;border-radius:50%;flex:0 0 auto;' +
        'overflow:hidden;background:#1c2030;' +
        'border:2px solid rgba(124,92,255,.25);' +
        'display:flex;align-items:center;justify-content:center;' +
      '}' +
      '.nt-avatar img{width:100%;height:100%;object-fit:cover;display:block;}' +
      '.nt-avatar .nt-av-initial{' +
        'font-size:.95rem;font-weight:800;color:#8b93a7;' +
      '}' +

      /* Body */
      '.nt-body{flex:1;min-width:0;display:flex;flex-direction:column;gap:.15rem;}' +
      '.nt-name{' +
        'font-size:.85rem;font-weight:700;color:#eef1f8;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.2;' +
      '}' +
      '.nt-msg{' +
        'font-size:.78rem;color:#a5b0c5;line-height:1.35;' +
        'display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;' +
        'overflow:hidden;word-break:break-word;' +
      '}' +
      '.nt-time{' +
        'font-size:.68rem;color:#6b7285;margin-top:.15rem;' +
      '}' +

      /* Right column */
      '.nt-right{' +
        'display:flex;flex-direction:column;align-items:center;gap:.35rem;' +
        'flex:0 0 auto;min-width:1.5rem;' +
      '}' +
      '.nt-dot{' +
        'width:.55rem;height:.55rem;border-radius:50%;' +
        'background:#3aa0ff;' +
        'box-shadow:0 0 8px rgba(58,160,255,.9);' +
      '}' +
      '.nt-dot.placeholder{background:transparent;box-shadow:none;}' +
      '.nt-arrow{' +
        'color:#6b7285;display:flex;align-items:center;justify-content:center;' +
      '}' +
      '.nt-arrow svg{width:1rem;height:1rem;}' +
      '.nt-del{' +
        'width:1.3rem;height:1.3rem;border-radius:50%;' +
        'background:rgba(255,255,255,.05);' +
        'border:1px solid rgba(255,255,255,.1);' +
        'color:#6b7285;font-size:.75rem;line-height:1;' +
        'display:flex;align-items:center;justify-content:center;' +
        'cursor:pointer;padding:0;' +
        '-webkit-tap-highlight-color:transparent;' +
        'transition:background .18s,color .18s;' +
      '}' +
      '.nt-del:active{background:rgba(255,92,108,.22);color:#ff5c6c;}' +

      /* Empty state */
      '.nt-empty{' +
        'display:flex;flex-direction:column;align-items:center;gap:.6rem;' +
        'padding:3rem 1rem;color:#8b93a7;text-align:center;' +
      '}' +
      '.nt-empty svg{width:2.8rem;height:2.8rem;opacity:.5;}' +
      '.nt-empty p{margin:0;font-size:.85rem;}' +

      /* Narrow screens */
      '@media (max-width:360px){' +
        '.nt-card{padding:.6rem .65rem;gap:.55rem;}' +
        '.nt-icon{width:2.1rem;height:2.1rem;}' +
        '.nt-icon svg{width:1rem;height:1rem;}' +
        '.nt-avatar{width:2.1rem;height:2.1rem;}' +
        '.nt-name{font-size:.82rem;}' +
        '.nt-msg{font-size:.74rem;}' +
        '.nt-header-title{font-size:1.35rem;}' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  })();

  /* ============================================================
   * 2. CONSTANTS + STATE
   * ============================================================ */
  var FETCH_LIMIT = 120;
  var UNREAD_CAP  = 99;

  var notifRef = null;
  var notifCb  = null;
  window.notifCache = window.notifCache || [];

  /* Filter state — 'all' | 'likes' | 'comments' | 'follows' | 'others' */
  if (typeof window.notifFilter !== 'string') window.notifFilter = 'all';

  /* ============================================================
   * 3. HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[notif-list] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * 4. INLINE SVG ICONS
   * ============================================================ */
  function svgBell() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/>' +
      '<path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>';
  }
  function svgCheck() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" ' +
      'stroke-linecap="round" stroke-linejoin="round"><path d="m20 6-11 11-5-5"/></svg>';
  }
  function svgHeart(filled) {
    return '<svg viewBox="0 0 24 24" fill="' + (filled ? 'currentColor' : 'none') + '" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M20.8 5.6a5 5 0 0 0-7.1 0L12 7.3l-1.7-1.7a5 5 0 1 0-7.1 7.1l8.8 8.8 8.8-8.8a5 5 0 0 0 0-7.1z"/></svg>';
  }
  function svgComment() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/></svg>';
  }
  function svgUserAdd() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 21a6.5 6.5 0 0 1 13 0"/>' +
      '<path d="M19 8v6M16 11h6"/></svg>';
  }
  function svgShare() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="18" cy="5" r="2.6"/><circle cx="6" cy="12" r="2.6"/>' +
      '<circle cx="18" cy="19" r="2.6"/><path d="m8.4 13.5 7.2 4M15.6 6.5l-7.2 4"/></svg>';
  }
  function svgPhone() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>';
  }
  function svgReward() {
    return '<svg viewBox="0 0 24 24" fill="currentColor">' +
      '<path d="M3 18h18l-1-9-5 4-3-6-3 6-5-4z"/></svg>';
  }
  function svgArrow() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>';
  }
  function svgClock() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  }

  /* ============================================================
   * 5. TYPE → icon + class mapping
   * ============================================================ */
  function getIconForType(type) {
    switch (type) {
      case 'like':
      case 'reaction':
        return { svg: svgHeart(true), cls: 'nt-icon-like' };
      case 'comment':
      case 'reply':
      case 'mention':
        return { svg: svgComment(), cls: 'nt-icon-comment' };
      case 'follow':
      case 'friend':
        return { svg: svgUserAdd(), cls: 'nt-icon-follow' };
      case 'share':
      case 'reel':
      case 'reel-share':
        return { svg: svgShare(), cls: 'nt-icon-share' };
      case 'call':
      case 'missed_call':
        return { svg: svgPhone(), cls: 'nt-icon-call' };
      case 'achievement':
      case 'mission':
      case 'xp':
        return { svg: svgReward(), cls: 'nt-icon-reward' };
      case 'story':
      case 'story_reply':
        return { svg: svgComment(), cls: 'nt-icon-story' };
      case 'admin':
      case 'broadcast':
      case 'system':
        return { svg: svgBell(), cls: 'nt-icon-system' };
      default:
        return { svg: svgBell(), cls: 'nt-icon-default' };
    }
  }

  /* ============================================================
   * 6. TYPE → filter bucket
   * ============================================================ */
  function getBucket(type) {
    if (!type) return 'others';
    if (type === 'like' || type === 'reaction') return 'likes';
    if (type === 'comment' || type === 'reply' || type === 'mention') return 'comments';
    if (type === 'follow' || type === 'friend') return 'follows';
    return 'others';
  }

  /* ============================================================
   * 7. BADGE UPDATE (preserved)
   * ============================================================ */
  function updateBadge(unread) {
    if (typeof unread !== 'number' || unread < 0) unread = 0;

    var nb = window.SaikoNavBadges;
    if (nb && typeof nb.setNotifBadge === 'function') {
      try { nb.setNotifBadge(unread); return; } catch (e) {}
    }

    var badge = qs('#navBadge');
    if (!badge) return;
    badge.textContent = unread
      ? (unread > UNREAD_CAP ? UNREAD_CAP + '+' : String(unread))
      : '';
  }

  /* ============================================================
   * 8. LISTENER LIFECYCLE (preserved)
   * ============================================================ */
  function start() {
    if (notifRef && notifCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    notifRef = fbDb.ref('notifications/' + uid)
      .orderByChild('createdAt')
      .limitToLast(FETCH_LIMIT);

    notifCb = notifRef.on('value', function (snap) {
      var v = snap.val() || {};
      var list = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      }).sort(function (a, b) {
        return (b.createdAt || 0) - (a.createdAt || 0);
      });

      window.notifCache = list;

      var unread = 0;
      for (var i = 0; i < list.length; i++) {
        if (!list[i].read) unread++;
      }
      updateBadge(unread);

      if (typeof window.currentNav === 'string' &&
          window.currentNav === 'notifications') {
        render();
      }
    });

    return true;
  }

  function detach() {
    if (notifRef && notifCb) {
      try { notifRef.off('value', notifCb); } catch (e) {}
    }
    notifRef = null;
    notifCb  = null;
    window.notifCache = [];
    return true;
  }

  /* ============================================================
   * 9. RENDER — premium notification page
   * ============================================================ */
  function render() {
    var page = qs('#page-notifications');
    if (!page) return;

    var all = window.notifCache || [];

    /* ---- Header ---- */
    var unreadCount = 0;
    for (var u = 0; u < all.length; u++) {
      if (!all[u].read) unreadCount++;
    }

    var header =
      '<div class="nt-header">' +
        '<div class="nt-header-icon">' + svgBell() + '</div>' +
        '<div class="nt-header-titles">' +
          '<div class="nt-header-title">' + esc(T('notifications')) + '</div>' +
          '<div class="nt-header-sub">Stay updated with your activity</div>' +
        '</div>' +
        '<button class="nt-mark-all" id="ntMarkAll"' +
          (unreadCount === 0 ? ' disabled' : '') + '>' +
          svgCheck() + ' <span>Mark all read</span>' +
        '</button>' +
      '</div>';

    /* ---- Filter pills ---- */
    var currentFilter = window.notifFilter || 'all';
    var filters = [
      { k: 'all',      label: 'All',      ic: svgBell() },
      { k: 'likes',    label: 'Likes',    ic: svgHeart(false) },
      { k: 'comments', label: 'Comments', ic: svgComment() },
      { k: 'follows',  label: 'Follows',  ic: svgUserAdd() },
      { k: 'others',   label: 'Others',   ic: svgShare() }
    ];

    var filtersHTML = '<div class="nt-filters" id="ntFilters">' +
      filters.map(function (f) {
        return '<div class="nt-filter' + (currentFilter === f.k ? ' sel' : '') + '" ' +
               'data-ntf="' + f.k + '">' +
               f.ic + ' <span>' + esc(f.label) + '</span>' +
               '</div>';
      }).join('') +
    '</div>';

    /* ---- Filter list ---- */
    var list = all.filter(function (n) {
      if (currentFilter === 'all') return true;
      return getBucket(n.type) === currentFilter;
    });

    /* ---- Empty state ---- */
    if (!list.length) {
      page.innerHTML = header + filtersHTML +
        '<div class="nt-empty">' +
          svgBell() +
          '<p>' + esc(T('no_notifications')) + '</p>' +
        '</div>';
      wireHeader(page);
      return;
    }

    /* ---- Cards ---- */
    var cards = list.map(function (n) {
      var iconInfo = getIconForType(n.type);
      var name = n.fromName || n.title || T('admin');
      var msg = n.text || n.message || '';

      /* Avatar — real photo if available, else initial fallback */
      var avHTML;
      if (n.fromUid && n.fromPhoto) {
        avHTML = '<div class="nt-avatar">' + avatarHTML(n.fromPhoto, name, 'av-40', n.fromUid) + '</div>';
      } else if (n.fromUid) {
        var initial = String(name || '?').trim().charAt(0).toUpperCase() || '?';
        avHTML = '<div class="nt-avatar"><span class="nt-av-initial">' + esc(initial) + '</span></div>';
      } else {
        /* No sender user — show generic icon-only avatar */
        var init2 = String(name || '?').trim().charAt(0).toUpperCase() || '?';
        avHTML = '<div class="nt-avatar"><span class="nt-av-initial">' + esc(init2) + '</span></div>';
      }

      var dotHTML = n.read
        ? '<span class="nt-dot placeholder"></span>'
        : '<span class="nt-dot"></span>';

      return '<div class="nt-card' + (n.read ? '' : ' unread') + '" data-nid="' + esc(n.id) + '">' +
        '<div class="nt-icon ' + iconInfo.cls + '">' + iconInfo.svg + '</div>' +
        avHTML +
        '<div class="nt-body">' +
          '<div class="nt-name">' + esc(name) + '</div>' +
          '<div class="nt-msg">' + esc(msg) + '</div>' +
          '<div class="nt-time">' + esc(timeAgo(n.createdAt)) + '</div>' +
        '</div>' +
        '<div class="nt-right">' +
          dotHTML +
          '<span class="nt-arrow">' + svgArrow() + '</span>' +
          '<button class="nt-del" data-ndel="' + esc(n.id) + '" aria-label="Delete">×</button>' +
        '</div>' +
      '</div>';
    }).join('');

    page.innerHTML =
      header +
      filtersHTML +
      '<div class="nt-list">' + cards + '</div>';

    wireHeader(page);
    wireList(page);
  }

  /* ============================================================
   * 10. WIRING — header / filters
   * ============================================================ */
  function wireHeader(page) {
    /* Mark all read button */
    var markBtn = qs('#ntMarkAll', page);
    if (markBtn) {
      markBtn.addEventListener('click', function () {
        markAllRead().then(function (ok) {
          if (ok) safeToast(T('saved') || 'All marked read', 'ok');
        });
      });
    }

    /* Filter pills */
    qsa('[data-ntf]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        var k = n.getAttribute('data-ntf');
        if (!k || k === window.notifFilter) return;
        window.notifFilter = k;
        render();
      });
    });
  }

  /* ============================================================
   * 11. WIRING — list cards
   * ============================================================ */
  function wireList(page) {
    qsa('[data-nid]', page).forEach(function (card) {
      card.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('[data-ndel]')) return;
        openNotification(card.getAttribute('data-nid'));
      });
    });

    qsa('[data-ndel]', page).forEach(function (b) {
      b.addEventListener('click', async function (e) {
        e.stopPropagation();
        var nid = b.getAttribute('data-ndel');
        await removeNotification(nid);
      });
    });
  }

  /* ============================================================
   * 12. MARK ALL READ (preserved)
   * ============================================================ */
  async function markAllRead() {
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    var updates = {};
    (window.notifCache || []).forEach(function (n) {
      if (!n.read) updates['notifications/' + uid + '/' + n.id + '/read'] = true;
    });
    if (!Object.keys(updates).length) return false;

    try {
      await fbDb.ref().update(updates);
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * 13. REMOVE ONE (preserved)
   * ============================================================ */
  async function removeNotification(nid) {
    if (!nid) return false;
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;
    try {
      await fbDb.ref('notifications/' + uid + '/' + nid).remove();
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * 14. OPEN NOTIFICATION (routing preserved 1:1)
   * ============================================================ */
  async function openNotification(nid) {
    if (!nid) return;

    var n = null;
    var list = window.notifCache || [];
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === nid) { n = list[i]; break; }
    }
    if (!n) return;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (fbDb && uid) {
      try { await fbDb.ref('notifications/' + uid + '/' + nid + '/read').set(true); }
      catch (e) {}
    }

    if (n.type === 'admin' || n.type === 'broadcast') {
      safeToast(
        (n.title ? (n.title + ': ') : '') +
        (n.message || n.text || ''),
        'ok'
      );
      return;
    }
    if (n.type === 'missed_call' || n.type === 'call') {
      safeCall('openCallHistory');
      return;
    }
    if (n.type === 'achievement' || n.type === 'mission' || n.type === 'xp') {
      safeCall('openMissions');
      return;
    }
    if (n.postId &&
        (n.type === 'like' ||
         n.type === 'comment' ||
         n.type === 'reply' ||
         n.type === 'reaction')) {
      safeCall('navigate', ['home']);
      setTimeout(function () {
        safeCall('openPostSplit', [n.postId]);
      }, 250);
      return;
    }
    if (n.chatId) {
      safeCall('openChatById', [n.chatId]);
      return;
    }
    if (n.reelId) {
      safeCall('openReels', [n.reelId]);
      return;
    }
    if (n.storyUid) {
      safeCall('openStoriesForUser', [n.storyUid]);
      return;
    }
    if (n.fromUid) {
      safeCall('openUserProfile', [n.fromUid]);
      return;
    }
    safeToast(n.text || T('admin'));
  }

  /* ============================================================
   * 15. PUBLIC API (preserved)
   * ============================================================ */
  window.startNotifs          = start;
  window.detachNotifs         = detach;
  window.renderNotifications  = render;
  window.markAllRead          = markAllRead;
  window.openNotification     = openNotification;
  window.removeNotification   = removeNotification;

  window.SaikoNotifList = {
    start: start,
    detach: detach,
    render: render,
    markAllRead: markAllRead,
    open: openNotification,
    remove: removeNotification,
    setFilter: function (k) { window.notifFilter = k || 'all'; if (typeof window.currentNav === 'string' && window.currentNav === 'notifications') render(); },
    getFilter: function () { return window.notifFilter; },
    FETCH_LIMIT: FETCH_LIMIT,
    getCache: function () { return (window.notifCache || []).slice(); }
  };

  try {
    console.debug('[boot] feature 101 — notif-list ready (v2 — premium UI)');
  } catch (e) {}

})();