/* ============================================================
 * FEATURE:        Push Notification (Write Path)
 * FEATURE NUMBER: 106
 * FILE:           js/notifications/106-push-notif.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Centralised writer that every feature uses to deliver an
 *   in-app notification to another user. Owns:
 *
 *     1. SELF / EMPTY GUARD
 *          Never writes a notification to the current user or
 *          to an empty uid. Prevents self-notifications and
 *          accidental null-target writes.
 *
 *     2. DEDUPLICATION
 *          A short-lived key in `lastNotifKeys` prevents the
 *          same logical event (same type + fromUid + postId +
 *          chatId + reelId + 8-second time bucket) from
 *          producing duplicate notification rows when a UI
 *          action fires twice in quick succession.
 *
 *          Key is deleted after 12 s.
 *
 *     3. WRITE
 *          db.ref('notifications/{toUid}').push() then
 *          .set({ id, read: false, ...data })
 *
 *   Public function:
 *     window.pushNotification(toUid, data) → Promise<void>
 *
 *   Behaviour preserved 1:1 from the original §19 block:
 *
 *     async function pushNotification(toUid, data){
 *       try{
 *         if(!toUid || toUid === myUid) return;
 *         const key = [data.type, data.fromUid, data.postId||'',
 *                      data.chatId||'', data.reelId||'',
 *                      Math.floor(now()/8000)].join('_');
 *         if(lastNotifKeys[key]) return;
 *         lastNotifKeys[key] = true;
 *         setTimeout(()=>{ delete lastNotifKeys[key]; }, 12000);
 *         const ref = db.ref('notifications/' + toUid).push();
 *         await ref.set(Object.assign({id: ref.key, read:false}, data));
 *       }catch(e){}
 *     }
 *
 *   Notes on the semantics preserved:
 *     • The 8000 ms time bucket means two identical events
 *       within the same 8-second window collapse into one.
 *     • The 12000 ms key TTL is intentionally longer than the
 *       bucket so a late arrival cannot slip through.
 *     • All errors are silently swallowed. Callers never need
 *       to guard against notification failures.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §19 NOTIFICATIONS → pushNotification()
 *   (Used from §10 AUTH, §15 FEED, §17 POST SPLIT, §22 CHAT,
 *    §23 CALLS, §24 GAMES, §28 STORIES, §29 REELS, §30
 *    SETTINGS — every feature that produces activity.)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db          js/core/firebase-init.js
 *   - myUid       js/auth/004-auth-state.js
 *   - now()       js/core/utils.js (falls back to Date.now())
 *
 * DOM ELEMENTS USED:
 *   none — pure Firebase write.
 *
 * FIREBASE PATHS:
 *   notifications/{toUid}         (write)
 *   notifications/{toUid}/{id}    (write — the pushed child)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.pushNotification          (original name preserved)
 *   window.lastNotifKeys             (live dedupe map)
 *   window.SaikoPushNotification = {
 *     push, buildKey, shouldSend,
 *     TIME_BUCKET_MS, DEDUPE_TTL_MS,
 *     getDedupeCount, clearDedupe
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var TIME_BUCKET_MS = 8000;     /* bucket every 8 s           */
  var DEDUPE_TTL_MS  = 12000;    /* keep key alive for 12 s    */

  /* ============================================================
   * STATE
   * ============================================================
   * Live dedupe map exposed on window for debugging and
   * introspection — same global name the original used.
   * ============================================================ */
  window.lastNotifKeys = window.lastNotifKeys || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * BUILD KEY — pure
   * ============================================================
   * Preserved 1:1 from the original dedupe-key expression:
   *
   *   [data.type, data.fromUid,
   *    data.postId||'', data.chatId||'', data.reelId||'',
   *    Math.floor(now()/8000)].join('_')
   *
   * Exposed so callers can pre-check before doing expensive
   * work (though pushNotification itself performs the check).
   * ============================================================ */
  function buildKey(data) {
    if (!data) return '';
    var bucket = Math.floor(timeNow() / TIME_BUCKET_MS);
    return [
      data.type    || '',
      data.fromUid || '',
      data.postId  || '',
      data.chatId  || '',
      data.reelId  || '',
      bucket
    ].join('_');
  }

  /* ============================================================
   * SHOULD SEND — pure predicate for the dedupe guard
   * ============================================================
   * Returns true when:
   *   • toUid is present and not the current user
   *   • the dedupe key is not already in the map
   * ============================================================ */
  function shouldSend(toUid, data) {
    if (!toUid) return false;
    if (toUid === getMyUid()) return false;
    if (!data) return false;
    var key = buildKey(data);
    if (!key) return false;
    return !window.lastNotifKeys[key];
  }

  /* ============================================================
   * PUSH — main entry
   * ============================================================
   * Preserved 1:1 from the original pushNotification().
   * Silently swallows every error — callers can fire-and-forget.
   * ============================================================ */
  async function push(toUid, data) {
    try {
      /* 1) Self / empty guard ------------------------------- */
      if (!toUid) return;
      if (toUid === getMyUid()) return;
      if (!data) return;

      /* 2) Dedupe ------------------------------------------- */
      var key = buildKey(data);
      if (!key) return;
      if (window.lastNotifKeys[key]) return;

      window.lastNotifKeys[key] = true;
      setTimeout(function () {
        try { delete window.lastNotifKeys[key]; } catch (e) {}
      }, DEDUPE_TTL_MS);

      /* 3) Write -------------------------------------------- */
      var fbDb = getDB();
      if (!fbDb) return;

      var ref = fbDb.ref('notifications/' + toUid).push();
      await ref.set(Object.assign({ id: ref.key, read: false }, data));
    } catch (e) {
      /* Silent — matches original. */
    }
  }

  /* ============================================================
   * INTROSPECTION HELPERS (additive)
   * ============================================================ */
  function getDedupeCount() {
    return Object.keys(window.lastNotifKeys || {}).length;
  }

  function clearDedupe() {
    window.lastNotifKeys = {};
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — preserved so every feature that already
   * calls window.pushNotification(toUid, data) keeps working
   * unchanged. */
  window.pushNotification = push;

  window.SaikoPushNotification = {
    push: push,
    buildKey: buildKey,
    shouldSend: shouldSend,
    getDedupeCount: getDedupeCount,
    clearDedupe: clearDedupe,
    TIME_BUCKET_MS: TIME_BUCKET_MS,
    DEDUPE_TTL_MS: DEDUPE_TTL_MS
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 106 — push-notification ready');
  } catch (e) {}

})();