/* ============================================================
 * MISSING FILE 4/8 — BLOCK + REPORT SYSTEM
 * FILE:   js/feed/091-block-report.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * Provides:
 *   • window.iBlocked(uid)   — is uid blocked by me?
 *   • window.blockUser(uid, fromProfile) — toggle block
 *   • window.REPORT_REASONS  — reason list
 *   • window.reportTarget    — active report
 *   • window.openReport(type, targetId, parentId)
 *   • #btnSendReport click handler
 * ============================================================ */

(function () {
  'use strict';

  /* ============ HELPERS ============ */
  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() { try { return window.now(); } catch (e) { return Date.now(); } }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try { if (typeof window.confirmDialog === 'function') return window.confirmDialog(title, text); } catch (e) {}
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (window.db) return window.db; } catch (e) {}
    return null;
  }
  function getUid() { return window.myUid || null; }

  /* ============ STATE ============ */
  window.blockedUsers = window.blockedUsers || {};
  window.reportTarget = null;

  var REPORT_REASONS = [
    'reason_spam',
    'reason_abuse',
    'reason_inappropriate',
    'reason_fake',
    'reason_hate',
    'reason_other'
  ];

  /* ============ PREDICATE ============ */
  function iBlocked(uid) {
    if (!uid) return false;
    return !!window.blockedUsers[uid];
  }

  /* ============ BLOCK / UNBLOCK ============ */
  async function blockUser(uid, fromProfile) {
    if (!uid || uid === getUid()) return;
    var fbDb = getDB();
    if (!fbDb) return;

    var already = iBlocked(uid);

    if (already) {
      /* === Unblock ==================================== */
      try {
        await fbDb.ref('blockedUsers/' + getUid() + '/' + uid).remove();
        if (window.blockedUsers) delete window.blockedUsers[uid];
        safeToast(T('unblocked'), 'ok');
      } catch (e) {
        safeToast(e.message || T('error'), 'err');
      }
    } else {
      /* === Block ====================================== */
      var ok = await askConfirm(T('block'), T('are_you_sure'));
      if (!ok) return;
      try {
        await fbDb.ref('blockedUsers/' + getUid() + '/' + uid).set(true);
        window.blockedUsers = window.blockedUsers || {};
        window.blockedUsers[uid] = true;
        safeToast(T('user_blocked'), 'ok');
      } catch (e) {
        safeToast(e.message || T('error'), 'err');
      }
    }

    /* Refresh views ------------------------------------ */
    try {
      if (typeof window.currentNav === 'string') {
        if (window.currentNav === 'inbox') safeCall('renderInbox');
        if (window.currentNav === 'home') safeCall('renderFeed', [true]);
        if (window.currentNav === 'profile') safeCall('renderProfilePage');
      }
    } catch (e) {}

    if (fromProfile && qs('#ovProfile') && qs('#ovProfile').classList.contains('open')) {
      safeCall('openUserProfile', [uid]);
    }
  }

  /* ============ OPEN REPORT ============ */
  function openReport(type, targetId, parentId) {
    window.reportTarget = { type: type, targetId: targetId, parentId: parentId };

    var descEl = qs('#reportDesc');
    if (descEl) descEl.value = '';

    var box = qs('#reportReasons');
    if (!box) return;

    box.innerHTML = REPORT_REASONS.map(function (r, i) {
      var sel = (i === 0) ? ' sel' : '';
      return '<div class="report-reason' + sel + '" data-rr="' + r + '">' + esc(T(r)) + '</div>';
    }).join('');

    /* Wire reason selection --------------------------- */
    qsa('[data-rr]', box).forEach(function (n) {
      n.addEventListener('click', function () {
        qsa('.report-reason', box).forEach(function (x) { x.classList.remove('sel'); });
        n.classList.add('sel');
      });
    });

    safeCall('openOverlay', ['ovReport']);
  }

  /* ============ SEND REPORT ============ */
  async function sendReport() {
    if (!window.reportTarget) return;
    var fbDb = getDB();
    if (!fbDb) return;

    var sel = qs('#reportReasons .report-reason.sel');
    var reason = sel ? sel.getAttribute('data-rr') : 'reason_other';
    var desc = qs('#reportDesc') ? qs('#reportDesc').value.trim() : '';

    var btn = qs('#btnSendReport');
    if (btn) btn.disabled = true;

    try {
      var ref = fbDb.ref('reports').push();
      var payload = {
        id: ref.key,
        type: window.reportTarget.type,
        targetId: window.reportTarget.targetId,
        parentId: window.reportTarget.parentId || null,
        reporterUid: getUid(),
        reporterName: (window.myProfile && window.myProfile.name) || '',
        reason: reason,
        reasonText: T(reason),
        description: desc,
        status: 'pending',
        createdAt: timeNow()
      };

      /* Try to resolve target's owner uid -------------- */
      try {
        if (window.reportTarget.type === 'user') {
          payload.targetUid = window.reportTarget.targetId;
        } else if (window.reportTarget.type === 'post') {
          var pc = window.postsCache || [];
          var post = pc.find(function (p) { return p.id === window.reportTarget.targetId; });
          if (post && post.uid) payload.targetUid = post.uid;
        } else if (window.reportTarget.type === 'comment' && window.reportTarget.parentId) {
          var snap = await fbDb.ref('comments/' + window.reportTarget.parentId + '/' + window.reportTarget.targetId).get();
          var c = snap.val();
          if (c && c.uid) payload.targetUid = c.uid;
        } else if (window.reportTarget.type === 'message' && window.reportTarget.parentId) {
          var snap2 = await fbDb.ref('messages/' + window.reportTarget.parentId + '/' + window.reportTarget.targetId).get();
          var m = snap2.val();
          if (m && m.from) payload.targetUid = m.from;
        } else if (window.reportTarget.type === 'reel') {
          var rc = window.reelsCache || [];
          var r = rc.find(function (x) { return x.id === window.reportTarget.targetId; });
          if (r && r.uid) payload.targetUid = r.uid;
        }
      } catch (e) {}

      await ref.set(payload);

      safeCall('closeOverlay', ['ovReport']);
      safeToast(T('report_sent'), 'ok');
    } catch (e) {
      safeToast(e.message || T('error'), 'err');
    } finally {
      if (btn) btn.disabled = false;
      window.reportTarget = null;
    }
  }

  /* ============ BIND SEND BUTTON ============ */
  var _bound = false;
  function bindSend() {
    if (_bound) return;
    var btn = qs('#btnSendReport');
    if (!btn) return;
    _bound = true;
    btn.addEventListener('click', sendReport);
  }

  /* ============ EXPORTS ============ */
  window.iBlocked            = iBlocked;
  window.blockUser           = blockUser;
  window.REPORT_REASONS      = REPORT_REASONS;
  window.openReport          = openReport;
  window.sendReport          = sendReport;

  window.SaikoBlockReport = {
    iBlocked: iBlocked,
    blockUser: blockUser,
    openReport: openReport,
    sendReport: sendReport,
    REPORT_REASONS: REPORT_REASONS
  };

  /* Auto-bind send button at DOM ready ------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindSend, { once: true });
  } else {
    bindSend();
  }

  try { console.debug('[boot] block-report ready'); } catch (e) {}
})();