/* ============================================================
 * FEATURE:        Comment Count
 * FEATURE NUMBER: 066
 * FILE:           js/feed/066-comment-count.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper that answers "how many comments does this
 *   post have?" — with suspension filtering applied.
 *
 *   In the original single-file build this logic lived inline
 *   inside feature 051's countComments():
 *
 *     function countComments(pid){
 *       const o = commentsMap[pid];
 *       if(!o) return 0;
 *       let n = 0;
 *       Object.keys(o).forEach(k => {
 *         const c = o[k];
 *         if(!isSuspended(c)) n++;
 *       });
 *       return n;
 *     }
 *
 *   The modular build keeps feature 051's countComments() as
 *   the feed-render entry point, but this file is the
 *   canonical owner of the algorithm so:
 *
 *     • Feature 051 (feed render), 067 (post split),
 *       068 (comments list), 073 (report), 088 (post menu),
 *       and profile views all call the same implementation.
 *     • The suspension predicate (isSuspended) is applied in
 *       exactly one place.
 *     • Future optimisations (e.g. caching counts per render
 *       cycle) can be added here without touching callers.
 *
 *   Public function:
 *     window.countComments(postId)   → number
 *
 *   Behaviour preserved 1:1 from the original source:
 *     • Missing commentsMap entry → 0
 *     • Suspended comment (per isSuspended) → not counted
 *     • Live comment → counted
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → countComments(pid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - isSuspended    js/feed/051-feed-render.js
 *                    (reads window.isSuspended)
 *   - window.postsCache / SaikoFeedRender.getCommentsMap()
 *                    js/feed/051-feed-render.js (live map)
 *
 * DOM ELEMENTS USED:
 *   none — pure data.
 *
 * FIREBASE PATHS:
 *   none directly. The comments map is maintained by feature
 *   051's live listener on `comments`.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.countComments          (original name preserved)
 *   window.SaikoCommentCount = {
 *     count,
 *     countAll,     // ignores suspension
 *     suspendedCount,
 *     hasComments
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */

  /* Return the shared comments map. Prefers feature 051's
   * public getter; falls back to an internal read of
   * SaikoFeedRender's state — and finally to an empty object
   * so this module never crashes on cold boot. */
  function getCommentsMap() {
    try {
      if (window.SaikoFeedRender &&
          typeof window.SaikoFeedRender.getCommentsMap === 'function') {
        return window.SaikoFeedRender.getCommentsMap() || {};
      }
    } catch (e) {}
    return {};
  }

  /* Resolve the suspension predicate. Prefers feature 051's
   * global isSuspended(). If it is not yet loaded, falls back
   * to a local copy of the same logic (identical to the
   * original source's inline implementation). */
  function isSuspended(obj) {
    if (!obj) return false;

    /* Preferred path: shared predicate */
    try {
      if (typeof window.isSuspended === 'function') {
        return !!window.isSuspended(obj);
      }
    } catch (e) {}

    /* Fallback — byte-for-byte copy of the original logic */
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > Date.now()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > Date.now();
  }

  /* ----------------------------------------------------------
   * count(postId)
   * Preserved 1:1 from the original source.
   * Returns the number of visible (non-suspended) comments.
   * ---------------------------------------------------------- */
  function count(pid) {
    if (!pid) return 0;
    var map = getCommentsMap();
    var bucket = map[pid];
    if (!bucket) return 0;

    var n = 0;
    var keys = Object.keys(bucket);
    for (var i = 0; i < keys.length; i++) {
      var c = bucket[keys[i]];
      if (!isSuspended(c)) n++;
    }
    return n;
  }

  /* ----------------------------------------------------------
   * countAll(postId)
   * Additive — counts every comment regardless of suspension.
   * Useful for admin views and moderation screens.
   * ---------------------------------------------------------- */
  function countAll(pid) {
    if (!pid) return 0;
    var map = getCommentsMap();
    var bucket = map[pid];
    if (!bucket) return 0;
    return Object.keys(bucket).length;
  }

  /* ----------------------------------------------------------
   * suspendedCount(postId)
   * Additive — number of hidden/suspended comments only.
   * ---------------------------------------------------------- */
  function suspendedCount(pid) {
    return Math.max(0, countAll(pid) - count(pid));
  }

  /* ----------------------------------------------------------
   * hasComments(postId)
   * Additive — true when at least one visible comment exists.
   * ---------------------------------------------------------- */
  function hasComments(pid) {
    return count(pid) > 0;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so feature 051's feed render
   * (and any other caller) continues to work unchanged. */
  window.countComments = count;

  window.SaikoCommentCount = {
    count: count,
    countAll: countAll,
    suspendedCount: suspendedCount,
    hasComments: hasComments
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 066 — comment-count ready');
  } catch (e) {}

})();