/* ============================================================
 * FEATURE:        Like Post Toggle
 * FEATURE NUMBER: 064
 * FILE:           js/feed/064-like-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused entry point for the classic "heart" like on a post.
 *   This is DIFFERENT from feature 065 (post reactions) which
 *   handles the emoji-reaction picker — a like always uses the
 *   heart and is the default action of the [data-like] button.
 *
 *   Public function:
 *     window.toggleLike(postId)   → Promise<boolean>
 *
 *   Behaviour preserved 1:1 from the original source's
 *   toggleLike(pid):
 *
 *     • ref = postLikes/{pid}/{myUid}
 *     • If the entry exists:
 *         - remove it
 *       Else (fresh like):
 *         - set the entry to { at: now() }
 *         - remove any existing postReactions/{pid}/{myUid}
 *           entry (a "like" is the zero-th reaction state)
 *         - if the post's author is not me, push a 'like'
 *           notification to them with text
 *           t('liked_your_post')
 *         - awardXp('like_given', 1)
 *         - bumpDaily('like', 1)
 *     • Always repaint post counts (paintPostCounts).
 *     • On error, toast err.message || t('error') as 'err'.
 *
 *   Feature 051 (feed render) wires [data-like] clicks to
 *   window.toggleLike(pid) inside wirePostInteractions.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → toggleLike(pid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid / myProfile        js/auth/004-auth-state.js
 *   - window.postsCache        js/feed/051-feed-render.js
 *   - paintPostCounts          js/feed/051-feed-render.js
 *   - pushNotification         js/notifications/106-push-notif.js
 *   - awardXp / bumpDaily      features 025-area / daily stats
 *   - toast                    js/nav/042-toast.js
 *   - t(key) / now()           js/nav/046-i18n.js / core/utils
 *
 * DOM ELEMENTS USED:
 *   none — purely Firebase + repaint hook. The DOM update
 *   happens inside feature 051's paintPostCounts().
 *
 * FIREBASE PATHS:
 *   postLikes/{pid}/{myUid}         (read + write / remove)
 *   postReactions/{pid}/{myUid}     (remove on like — the
 *                                    like "replaces" any emoji)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.toggleLike          (original name preserved)
 *   window.SaikoLikePost = {
 *     toggle, like, unlike,
 *     isLiked, getCount
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[like-post] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findPost(postId) {
    if (!postId) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === postId) return p;
        }
      }
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * isLiked(postId)
   * Reads the live postLikes map that feature 051 maintains.
   * ---------------------------------------------------------- */
  function isLiked(postId) {
    if (!postId) return false;
    try {
      if (window.SaikoFeedRender &&
          typeof window.SaikoFeedRender.getLikesMap === 'function') {
        var m = window.SaikoFeedRender.getLikesMap() || {};
        var uid = getMyUid();
        return !!(uid && m[postId] && m[postId][uid]);
      }
    } catch (e) {}
    return false;
  }

  /* ----------------------------------------------------------
   * getCount(postId)
   * Additive helper — total likes on a post (distinct users
   * across postLikes + postReactions). Delegates to feature
   * 051's countLikes() so the number matches what the feed
   * paints.
   * ---------------------------------------------------------- */
  function getCount(postId) {
    try {
      if (typeof window.countLikes === 'function') return window.countLikes(postId);
    } catch (e) {}
    return 0;
  }

  /* ----------------------------------------------------------
   * like(postId) — force-like path.
   * (Additive helper; original only exposed the toggle.)
   * ---------------------------------------------------------- */
  async function like(postId) {
    if (!postId) return false;
    if (isLiked(postId)) return false;
    return toggle(postId);
  }

  /* ----------------------------------------------------------
   * unlike(postId) — force-unlike path.
   * (Additive helper.)
   * ---------------------------------------------------------- */
  async function unlike(postId) {
    if (!postId) return false;
    if (!isLiked(postId)) return false;
    return toggle(postId);
  }

  /* ----------------------------------------------------------
   * toggle(postId)
   * Preserved 1:1 from the original toggleLike(pid).
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function toggle(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    var ref = fbDb.ref('postLikes/' + postId + '/' + uid);

    try {
      var snap = await ref.get();

      if (snap.exists()) {
        /* === UNLIKE ===================================== */
        await ref.remove();
      } else {
        /* === LIKE ======================================= */
        await ref.set({ at: timeNow() });

        /* A like supersedes any emoji reaction on the same
         * post by the same user — the original removed the
         * postReactions entry in the same write batch. */
        try {
          await fbDb.ref('postReactions/' + postId + '/' + uid).remove();
        } catch (e) {}

        /* Notify the author (skip if I'm liking my own post) */
        var post = findPost(postId);
        if (post && post.uid && post.uid !== uid) {
          var me = getMyProfile();
          safeCall('pushNotification', [post.uid, {
            type: 'like',
            fromUid: uid,
            fromName: (me && me.name) || 'User',
            fromPhoto: (me && me.photo) || '',
            text: T('liked_your_post'),
            postId: postId,
            createdAt: timeNow()
          }]);
        }

        /* XP + daily stat for missions ------------------- */
        safeCall('awardXp', ['like_given', 1]);
        safeCall('bumpDaily', ['like', 1]);
      }

      /* Refresh every rendered card's like state + count --- */
      safeCall('paintPostCounts');

      /* Notify subscribers -------------------------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:like-changed', {
          detail: { postId: postId, liked: !snap.exists() }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so feature 051's
   * wirePostInteractions and any other caller keeps working
   * unchanged. */
  window.toggleLike = toggle;

  window.SaikoLikePost = {
    toggle: toggle,
    like: like,
    unlike: unlike,
    isLiked: isLiked,
    getCount: getCount
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 064 — like-post ready');
  } catch (e) {}

})();