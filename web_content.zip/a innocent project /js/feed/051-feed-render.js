/* ============================================================
 * FEATURE:        Feed Render (Premium Home UI)
 * FEATURE NUMBER: 051
 * FILE:           js/feed/051-feed-render.js
 * ACTION:         REPLACE (v4 — premium home redesign)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * 1. INJECT PREMIUM HOME CSS
   * ============================================================ */
  (function injectHomeCSS() {
    if (document.getElementById('__saiko_home_css_v4')) return;
    var s = document.createElement('style');
    s.id = '__saiko_home_css_v4';
    s.textContent =
      /* ---- Home wrapper ---- */
      '#page-home{padding:.7rem .8rem 6rem;}' +

      /* ---- Page title ---- */
      '#page-home > .page-title{' +
        'font-size:1.6rem;font-weight:800;letter-spacing:-.02em;' +
        'color:#fff;margin:.2rem 0 .9rem;padding:0 .15rem;' +
      '}' +

      /* ---- Feed tabs (filter chips) ---- */
      '.feed-tabs{' +
        'display:flex;gap:.45rem;overflow-x:auto;padding:.1rem 0 .6rem;' +
        'margin-bottom:.55rem;scrollbar-width:none;-webkit-overflow-scrolling:touch;' +
      '}' +
      '.feed-tabs::-webkit-scrollbar{display:none;}' +
      '.feed-tabs .chip{' +
        'display:inline-flex;align-items:center;gap:.35rem;' +
        'padding:.5rem .95rem;border-radius:1.3rem;' +
        'background:rgba(22,34,54,.55);' +
        'border:1px solid rgba(58,160,255,.18);' +
        'color:#8b93a7;font-size:.76rem;font-weight:600;' +
        'white-space:nowrap;flex:0 0 auto;cursor:pointer;' +
        'transition:all .18s ease;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
      '}' +
      '.feed-tabs .chip:active{transform:scale(.94);}' +
      '.feed-tabs .chip.sel{' +
        'background:linear-gradient(135deg,#2ecc8f,#00b85f);' +
        'color:#062014;border-color:transparent;font-weight:700;' +
        'box-shadow:0 6px 18px rgba(46,204,143,.4);' +
      '}' +

      /* ---- Action row (quick actions) ---- */
      '#page-home > .row{' +
        'display:flex;gap:.5rem;margin-bottom:.75rem;' +
        'flex-wrap:nowrap;overflow-x:auto;padding-bottom:.15rem;' +
        'scrollbar-width:none;' +
      '}' +
      '#page-home > .row::-webkit-scrollbar{display:none;}' +
      '#page-home > .row > .btn{' +
        'flex:0 0 auto;border-radius:1rem;' +
      '}' +

      /* ---- Composer quick-box (new) ---- */
      '.hm-composer{' +
        'display:flex;align-items:center;gap:.6rem;' +
        'padding:.6rem .7rem;border-radius:1.15rem;' +
        'background:linear-gradient(180deg,#0f1a2e 0%,#0c1526 100%);' +
        'border:1px solid rgba(58,160,255,.15);' +
        'margin-bottom:.75rem;cursor:pointer;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
        'transition:border-color .2s ease;' +
      '}' +
      '.hm-composer:active{border-color:rgba(58,160,255,.35);}' +
      '.hm-composer-av{' +
        'width:2.3rem;height:2.3rem;border-radius:50%;flex:0 0 auto;' +
        'overflow:hidden;background:#1c2030;' +
        'border:1.5px solid rgba(124,92,255,.35);' +
        'display:flex;align-items:center;justify-content:center;' +
      '}' +
      '.hm-composer-av img{width:100%;height:100%;object-fit:cover;display:block;}' +
      '.hm-composer-av .hm-av-init{' +
        'font-size:.9rem;font-weight:800;color:#8b93a7;' +
      '}' +
      '.hm-composer-placeholder{' +
        'flex:1;min-width:0;font-size:.82rem;color:#6b7285;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;' +
      '}' +
      '.hm-composer-icons{' +
        'display:flex;gap:.35rem;align-items:center;flex:0 0 auto;color:#7c5cff;opacity:.85;' +
      '}' +
      '.hm-composer-icons .ic{width:1.15rem;height:1.15rem;}' +
      '.hm-composer-post{' +
        'padding:.5rem 1rem;border-radius:.85rem;' +
        'background:linear-gradient(135deg,#2ecc8f,#00b85f);' +
        'color:#062014;font-size:.78rem;font-weight:800;' +
        'border:none;flex:0 0 auto;cursor:pointer;' +
        'box-shadow:0 4px 14px rgba(46,204,143,.4);' +
        '-webkit-tap-highlight-color:transparent;' +
      '}' +
      '.hm-composer-post:active{transform:scale(.95);}' +

      /* ---- Sticky page-title shadow when scrolling ---- */
      '#page-home .page-title + #storiesBarWrap{margin-top:-.2rem;}' +

      /* ---- Narrow screens ---- */
      '@media (max-width:360px){' +
        '#page-home{padding:.6rem .65rem 5.5rem;}' +
        '#page-home > .page-title{font-size:1.4rem;margin-bottom:.7rem;}' +
        '.feed-tabs .chip{padding:.45rem .75rem;font-size:.72rem;}' +
        '.hm-composer{padding:.5rem .6rem;gap:.5rem;}' +
        '.hm-composer-av{width:2rem;height:2rem;}' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  })();

  var FEED_BATCH = 10;
  var FEED_FETCH_LIMIT = 300;
  var INFINITE_SCROLL_PX = 600;
  var INFINITE_SCROLL_MS = 400;
  var FEED_SIG_SAFETY_MS = 200;

  var feedRef = null, feedCb = null;
  var likesRef = null, likesCb = null;
  var commentsRef = null, commentsCb = null;
  var hiddenPostsRef = null, hiddenPostsCb = null;

  var likesMap = {};
  var commentsMap = {};
  var hiddenPosts = {};

  window.postsCache = window.postsCache || [];

  var feedVisibleCount = FEED_BATCH;
  var feedLoadingMore = false;
  var feedListenerActive = false;
  var feedShellSig = '';
  var lastFeedRenderHash = '';
  var feedRotationSeed = 0;

  var _feedShuffleSeed = -1;
  var _feedShuffleIds = null;

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { if (typeof window.svgIcon === 'function') return window.svgIcon(name, fill); } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[feed] safeCall:', name, e); }
    return undefined;
  }
  function throttle(fn, ms) {
    var last = 0, tm = null;
    return function () {
      var a = arguments, c = this, now = Date.now();
      if (now - last >= ms) { last = now; fn.apply(c, a); }
      else {
        clearTimeout(tm);
        tm = setTimeout(function () {
          last = Date.now();
          fn.apply(c, a);
        }, ms - (now - last));
      }
    };
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function getFeedMode() {
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.getMode === 'function') {
        return window.SaikoFeedMode.getMode();
      }
    } catch (e) {}
    return 'latest';
  }
  function setFeedMode(mode) {
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.setMode === 'function') {
        return window.SaikoFeedMode.setMode(mode, { persist: false });
      }
    } catch (e) {}
    return false;
  }

  function applyFeedShuffle(arr) {
    if (!arr || !arr.length) return arr || [];
    if (feedRotationSeed <= 0) return arr;

    if (feedRotationSeed === _feedShuffleSeed && _feedShuffleIds) {
      var byId = {};
      for (var k = 0; k < arr.length; k++) byId[arr[k].id] = arr[k];

      var ordered = [];
      var idLen = _feedShuffleIds.length;
      for (var i = 0; i < idLen; i++) {
        var id = _feedShuffleIds[i];
        if (byId[id]) {
          ordered.push(byId[id]);
          delete byId[id];
        }
      }
      for (var j = 0; j < arr.length; j++) {
        var p = arr[j];
        if (byId[p.id]) {
          ordered.unshift(p);
          delete byId[p.id];
        }
      }
      return ordered;
    }

    var shuffled = arr.slice();
    for (var m = shuffled.length - 1; m > 0; m--) {
      var n = Math.floor(Math.random() * (m + 1));
      var t = shuffled[m];
      shuffled[m] = shuffled[n];
      shuffled[n] = t;
    }
    _feedShuffleSeed = feedRotationSeed;
    _feedShuffleIds = new Array(shuffled.length);
    for (var q = 0; q < shuffled.length; q++) {
      _feedShuffleIds[q] = shuffled[q].id;
    }
    return shuffled;
  }

  function countLikes(pid) {
    var liked = likesMap[pid] || {};
    var reacted = (window.postReactionsMap && window.postReactionsMap[pid]) || {};
    var set = {};
    Object.keys(liked).forEach(function (u) { set[u] = true; });
    Object.keys(reacted).forEach(function (u) { set[u] = true; });
    return Object.keys(set).length;
  }
  function countComments(pid) {
    var o = commentsMap[pid];
    if (!o) return 0;
    var n = 0;
    Object.keys(o).forEach(function (k) {
      var c = o[k];
      if (!isSuspended(c)) n++;
    });
    return n;
  }
  function iLiked(pid) {
    var uid = getMyUid();
    if (!uid) return false;
    return !!(likesMap[pid] && likesMap[pid][uid]);
  }
  function isSuspended(obj) {
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > timeNow()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > timeNow();
  }
  function isVisiblePost(p) {
    if (!p) return false;
    if (isSuspended(p)) return false;
    if (hiddenPosts[p.id]) return false;
    if (p.hidden === true) return false;
    try {
      if (typeof window.iMutedAuthor === 'function' && window.iMutedAuthor(p.uid)) return false;
    } catch (e) {}
    return true;
  }

  function sortedFeed() {
    var mode = getFeedMode();
    var vis = window.postsCache.filter(isVisiblePost);

    if (mode === 'trending') {
      vis = vis.slice().sort(function (a, b) {
        return (countLikes(b.id) + countComments(b.id) * 2) -
               (countLikes(a.id) + countComments(a.id) * 2);
      });
    } else if (mode === 'foryou') {
      vis = vis.slice().sort(function (a, b) {
        var sa = (countLikes(a.id) * 2 + countComments(a.id) * 3) /
                 Math.max(1, (timeNow() - (a.createdAt || 0)) / 3600000);
        var sb = (countLikes(b.id) * 2 + countComments(b.id) * 3) /
                 Math.max(1, (timeNow() - (b.createdAt || 0)) / 3600000);
        return sb - sa;
      });
    } else if (mode === 'popular') {
      vis = vis.slice().sort(function (a, b) {
        return countLikes(b.id) - countLikes(a.id);
      });
    } else if (mode === 'interests') {
      var tags = {};
      var recentPlayed = (window.recentPlayed || []);
      var reelsCache = (window.reelsCache || []);
      vis.forEach(function (p) {
        if (p.uid === getMyUid()) {
          var tk = (window.extractTags ? window.extractTags(p.text) : {}) || {};
          Object.keys(tk).forEach(function (k) { tags[k] = (tags[k] || 0) + 3; });
        }
      });
      recentPlayed.forEach(function (id) {
        var r = reelsCache.find(function (x) { return x.id === id; });
        if (r) {
          var tk = (window.extractTags ? window.extractTags(r.text) : {}) || {};
          Object.keys(tk).forEach(function (k) { tags[k] = (tags[k] || 0) + 2; });
        }
      });
      vis = vis.slice().sort(function (a, b) {
        var ea = (window.extractTags ? window.extractTags(a.text) : {}) || {};
        var eb = (window.extractTags ? window.extractTags(b.text) : {}) || {};
        var sa = Object.keys(ea).reduce(function (s, k) { return s + (tags[k] || 0); }, 0);
        var sb = Object.keys(eb).reduce(function (s, k) { return s + (tags[k] || 0); }, 0);
        return sb - sa;
      });
    }

    vis = applyFeedShuffle(vis);
    return vis;
  }

  function paintPostCounts() {
    qsa('[data-like]').forEach(function (btn) {
      var pid = btn.getAttribute('data-like');
      var myRx = null;
      try { if (typeof window.myReactionOn === 'function') myRx = window.myReactionOn(pid); } catch (e) {}
      var liked = myRx || iLiked(pid);
      btn.classList.toggle('liked', !!liked);
      var cnt = btn.querySelector('[data-likecount]');
      if (cnt) cnt.textContent = countLikes(pid);
      var icon = btn.querySelector('.like-icon');
      if (icon) icon.innerHTML = myRx ? esc(myRx) : svgIcon('heart', true);
    });
    qsa('[data-commentcount]').forEach(function (n) {
      n.textContent = countComments(n.getAttribute('data-commentcount'));
    });
    qsa('[data-save]').forEach(function (b) {
      var saved = false;
      try { if (typeof window.iSaved === 'function') saved = window.iSaved(b.getAttribute('data-save')); } catch (e) {}
      b.classList.toggle('saved', saved);
    });
  }

  /* ============================================================
   * COMPOSER QUICK-BOX (new — opens existing composer)
   * ============================================================ */
  function buildComposerBox() {
    var mp = getMyProfile();
    var name = (mp && mp.name) || 'You';
    var initial = String(name).charAt(0).toUpperCase() || 'U';
    var photo = (mp && mp.photo) || '';

    var avHTML = photo
      ? '<div class="hm-composer-av"><img src="' + esc(photo) + '" alt="" ' +
        'onerror="this.parentNode.innerHTML=\'<span class=&quot;hm-av-init&quot;>' + esc(initial) + '</span>\'"></div>'
      : '<div class="hm-composer-av"><span class="hm-av-init">' + esc(initial) + '</span></div>';

    return '<div class="hm-composer" id="hmComposer">' +
      avHTML +
      '<div class="hm-composer-placeholder">What\'s on your mind?</div>' +
      '<div class="hm-composer-icons">' +
        '<span class="ic">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
          'stroke-linecap="round" stroke-linejoin="round">' +
          '<rect x="3" y="3" width="18" height="18" rx="3"/>' +
          '<circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>' +
        '</span>' +
        '<span class="ic">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
          'stroke-linecap="round" stroke-linejoin="round">' +
          '<rect x="2" y="3" width="20" height="14" rx="2"/>' +
          '<path d="M8 21h8M12 17v4"/></svg>' +
        '</span>' +
      '</div>' +
      '<button class="hm-composer-post" id="hmPostBtn">Post</button>' +
    '</div>';
  }

  /* ============================================================
   * INLINE TAB WIRING
   * ============================================================ */
  function wireFeedTabs(page) {
    if (!page) return;
    var chips = page.querySelectorAll('[data-feedtab]');
    if (!chips.length) return;

    for (var i = 0; i < chips.length; i++) {
      (function (chip) {
        if (chip.dataset.feedInlineBound === '1') return;
        chip.dataset.feedInlineBound = '1';

        chip.addEventListener('click', function (e) {
          if (e && typeof e.stopPropagation === 'function') e.stopPropagation();

          var mode = chip.getAttribute('data-feedtab');
          if (!mode) return;

          var previous = getFeedMode();
          if (mode === previous) {
            for (var j = 0; j < chips.length; j++) {
              chips[j].classList.toggle('sel', chips[j].getAttribute('data-feedtab') === mode);
            }
            return;
          }

          setFeedMode(mode);
          feedVisibleCount = FEED_BATCH;
          feedShellSig = '';
          renderFeed(false);
        });
      })(chips[i]);
    }
  }

  function renderFeed(preserveScroll) {
    var page = qs('#page-home');
    if (!page) return;

    var mode = getFeedMode();
    var allVisible = sortedFeed();
    var visible = allVisible.slice(0, feedVisibleCount);
    var sig = 'm' + mode + '|v' + visible.length + '|t' + allVisible.length +
              '|p' + visible.map(function (p) { return p.id; }).join(',');
    var existed = feedShellSig === sig && qs('#feedList');

    if (existed && preserveScroll) {
      paintPostCounts();
      safeCall('observePostVideos', [page]);
      return;
    }
    if (existed && !preserveScroll) return;
    feedShellSig = sig;

    if (!allVisible.length) {
      page.innerHTML =
        '<div class="page-title">' + esc(T('home')) + '</div>' +
        '<div id="storiesBarWrap"></div>' +
        buildComposerBox() +
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('image') + '</span>' +
          '<p>' + esc(T('feed_empty')) + '</p>' +
        '</div>' +
        '<div style="display:flex;justify-content:center">' +
          '<button class="btn solid" id="emptyCreate">' + esc(T('create_post')) + '</button>' +
        '</div>';
      var b = qs('#emptyCreate');
      if (b) b.addEventListener('click', function () { safeCall('openComposer'); });
      wireComposerBox(page);
      safeCall('renderStoriesBar');
      return;
    }

    var hasMore = visible.length < allVisible.length;
    var sc = window.scrollY;

    var tabsHTML = '';
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.renderTabs === 'function') {
        tabsHTML = window.SaikoFeedMode.renderTabs();
      }
    } catch (e) {}
    if (!tabsHTML) {
      tabsHTML = '<div class="feed-tabs">' +
        ['foryou', 'latest', 'popular', 'trending', 'interests'].map(function (k) {
          return '<span class="chip ' + (mode === k ? 'sel' : '') + '" data-feedtab="' + k + '">' +
                 esc(T(k)) +
                 '</span>';
        }).join('') +
      '</div>';
    }

    var cardsHTML = visible.map(function (p) {
      try {
        if (typeof window.postHTML === 'function') return window.postHTML(p);
      } catch (e) {}
      return '';
    }).join('');

    page.innerHTML =
      '<div class="page-title">' + esc(T('home')) + '</div>' +
      '<div id="storiesBarWrap"></div>' +
      buildComposerBox() +
      tabsHTML +
      '<div class="row" style="margin-bottom:.7rem;flex-wrap:wrap">' +
        '<button class="btn sm solid" id="feedCreate">+ ' + esc(T('create_post')) + '</button>' +
        '<button class="btn sm ghost" id="feedReels">🎬 ' + esc(T('reels')) + '</button>' +
        '<button class="btn sm ghost" id="feedTrend">🔥 ' + esc(T('trending')) + '</button>' +
        '<button class="btn sm ghost" id="feedSaved">' + esc(T('saved_posts')) + '</button>' +
      '</div>' +
      '<div id="feedList">' + cardsHTML + '</div>' +
      (hasMore
        ? '<div class="load-more"><button class="btn ghost sm" id="loadMore">' + esc(T('load_more')) + '</button></div>'
        : '<div class="load-more"><span class="mini">' + esc(T('no_more_posts')) + '</span></div>');

    safeCall('renderStoriesBar');
    wireComposerBox(page);

    var fc = qs('#feedCreate'); if (fc) fc.addEventListener('click', function () { safeCall('openComposer'); });
    var fr = qs('#feedReels');  if (fr) fr.addEventListener('click', function () { safeCall('openReels'); });
    var ft = qs('#feedTrend');  if (ft) ft.addEventListener('click', function () { safeCall('openTrending'); });
    var fs = qs('#feedSaved');  if (fs) fs.addEventListener('click', function () { safeCall('openSaved'); });
    var lm = qs('#loadMore');   if (lm) lm.addEventListener('click', function () { loadMoreFeed(); });

    wireFeedTabs(page);

    safeCall('wirePostInteractions', [page]);
    paintPostCounts();
    safeCall('observePostVideos', [page]);

    if (preserveScroll) {
      requestAnimationFrame(function () {
        try { window.scrollTo(0, sc); } catch (e) {}
      });
    }
  }

  function wireComposerBox(page) {
    var box = qs('#hmComposer', page);
    if (box && box.dataset.hmBound !== '1') {
      box.dataset.hmBound = '1';
      box.addEventListener('click', function (e) {
        if (e.target && e.target.closest && e.target.closest('#hmPostBtn')) return;
        safeCall('openComposer');
      });
    }
    var pb = qs('#hmPostBtn', page);
    if (pb && pb.dataset.hmBound !== '1') {
      pb.dataset.hmBound = '1';
      pb.addEventListener('click', function (e) {
        e.stopPropagation();
        safeCall('openComposer');
      });
    }
  }

  function loadMoreFeed() {
    if (feedLoadingMore) return;
    var allVisible = sortedFeed();
    if (feedVisibleCount >= allVisible.length) {
      var lm = qs('#loadMore');
      if (lm) lm.outerHTML = '<div class="load-more"><span class="mini">' + esc(T('no_more_posts')) + '</span></div>';
      return;
    }
    feedLoadingMore = true;

    var lmBtn = qs('#loadMore');
    if (lmBtn) { lmBtn.disabled = true; lmBtn.textContent = T('loading_more'); }

    feedVisibleCount += FEED_BATCH;
    var sc = window.scrollY;
    var all = sortedFeed().slice(0, feedVisibleCount);
    var list = qs('#feedList');

    if (list) {
      list.innerHTML = all.map(function (p) {
        try {
          if (typeof window.postHTML === 'function') return window.postHTML(p);
        } catch (e) {}
        return '';
      }).join('');
      safeCall('wirePostInteractions', [list]);
      paintPostCounts();
      safeCall('observePostVideos', [list]);

      var hasMore = feedVisibleCount < allVisible.length;
      var lm2 = qs('#loadMore');
      if (lm2) {
        if (hasMore) { lm2.disabled = false; lm2.textContent = T('load_more'); }
        else lm2.outerHTML = '<div class="load-more"><span class="mini">' + esc(T('no_more_posts')) + '</span></div>';
      }
      requestAnimationFrame(function () {
        try { window.scrollTo(0, sc); } catch (e) {}
      });
    } else {
      renderFeed(true);
    }

    setTimeout(function () { feedLoadingMore = false; }, FEED_SIG_SAFETY_MS);
  }

  function startFeed() {
    if (feedListenerActive) return;
    var fbDb = getDB();
    if (!fbDb) return;
    feedListenerActive = true;

    var page = qs('#page-home');
    if (page && !window.postsCache.length) {
      page.innerHTML = '<div class="skeleton" style="height:9rem;margin-bottom:.75rem"></div>'.repeat(3);
    }

    likesRef = fbDb.ref('postLikes');
    likesCb = likesRef.on('value', function (s) {
      likesMap = s.val() || {};
      paintPostCounts();
    });

    commentsRef = fbDb.ref('comments');
    commentsCb = commentsRef.on('value', function (s) {
      commentsMap = s.val() || {};
      paintPostCounts();
    });

    var me = getMyUid();
    if (me) {
      hiddenPostsRef = fbDb.ref('hiddenPosts/' + me);
      hiddenPostsCb = hiddenPostsRef.on('value', function (s) {
        hiddenPosts = s.val() || {};
        if (typeof window.currentNav === 'string' && window.currentNav === 'home') {
          renderFeed(true);
        }
      });
    }

    feedRef = fbDb.ref('posts').orderByChild('createdAt').limitToLast(FEED_FETCH_LIMIT);
    feedCb = feedRef.on('value', function (snap) {
      var v = snap.val() || {};
      var newCache = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      }).sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });

      var newHash = newCache.map(function (p) {
        return p.id + ':' + (p.updatedAt || 0) + ':' + (p.suspended ? 1 : 0);
      }).join('|');

      if (newHash === lastFeedRenderHash) return;
      lastFeedRenderHash = newHash;
      window.postsCache = newCache;

      if (typeof window.currentNav === 'string' && window.currentNav === 'home') {
        renderFeed(true);
      }
    }, function (err) {
      if (!page) return;
      page.innerHTML =
        '<div class="banner">' + esc(err.message) + ' ' +
        '<button class="btn sm ghost" id="feedRetry">' + esc(T('retry')) + '</button></div>';
      var rb = qs('#feedRetry');
      if (rb) rb.addEventListener('click', function () {
        feedListenerActive = false;
        startFeed();
      });
    });
  }

  function detachFeed() {
    try { if (feedRef && feedCb) feedRef.off('value', feedCb); } catch (e) {}
    try { if (likesRef && likesCb) likesRef.off('value', likesCb); } catch (e) {}
    try { if (commentsRef && commentsCb) commentsRef.off('value', commentsCb); } catch (e) {}
    try { if (hiddenPostsRef && hiddenPostsCb) hiddenPostsRef.off('value', hiddenPostsCb); } catch (e) {}
    feedRef = feedCb = likesRef = likesCb = commentsRef = commentsCb = null;
    hiddenPostsRef = hiddenPostsCb = null;
    feedListenerActive = false;
  }

  var onScroll = throttle(function () {
    if (typeof window.currentNav === 'string' && window.currentNav !== 'home') return;
    if (feedLoadingMore) return;
    var scrolled = window.scrollY + window.innerHeight;
    if (scrolled > document.body.scrollHeight - INFINITE_SCROLL_PX) {
      var allVisible = sortedFeed();
      if (feedVisibleCount < allVisible.length) loadMoreFeed();
    }
  }, INFINITE_SCROLL_MS);

  window.addEventListener('scroll', onScroll, { passive: true });

  window.startFeed       = startFeed;
  window.detachFeed      = detachFeed;
  window.renderFeed      = renderFeed;
  window.sortedFeed      = sortedFeed;
  window.loadMoreFeed    = loadMoreFeed;
  window.paintPostCounts = paintPostCounts;
  window.countLikes      = countLikes;
  window.countComments   = countComments;
  window.iLiked          = iLiked;
  window.isSuspended     = isSuspended;
  window.isVisiblePost   = isVisiblePost;

  window.SaikoFeedRender = {
    FEED_BATCH: FEED_BATCH,
    start: startFeed,
    detach: detachFeed,
    render: renderFeed,
    sorted: sortedFeed,
    loadMore: loadMoreFeed,
    paintCounts: paintPostCounts,
    countLikes: countLikes,
    countComments: countComments,
    iLiked: iLiked,
    isSuspended: isSuspended,
    isVisiblePost: isVisiblePost,
    getVisibleCount: function () { return feedVisibleCount; },
    setVisibleCount: function (n) { feedVisibleCount = Math.max(FEED_BATCH, Number(n) || FEED_BATCH); },
    bumpRotationSeed: function () { feedRotationSeed++; },
    getLikesMap: function () { return likesMap; },
    getCommentsMap: function () { return commentsMap; },
    getHiddenPosts: function () { return hiddenPosts; }
  };

  try {
    console.debug('[boot] feature 051 — feed-render ready (v4 — premium home)');
  } catch (e) {}

})();