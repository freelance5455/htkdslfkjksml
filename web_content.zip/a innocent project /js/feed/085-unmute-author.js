/* ============================================================
 * FEATURE:        Unmute Author
 * FEATURE NUMBER: 085
 * FILE:           js/feed/085-unmute-author.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for UNMUTING an author. The original source
 *   handled unmute as the else-branch of the toggle inside two
 *   places:
 *
 *     1. §15 openPostMenu() → case 'muteauthor'
 *          if (iMutedAuthor(post.uid)) {
 *            mutedAuthors/{myUid}/{uid}.remove().catch(()=>{})
 *            toast(t('unmute_author'), 'ok')
 *          }
 *
 *     2. §30 mutedHTML() + wireMuted() (settings page)
 *          [data-unmute] click → remove + toast + re-render list
 *
 *   Feature 084 already exposes the toggle (which contains the
 *   unmute branch). This file extracts the unmute-only path as
 *   a first-class helper so callers can:
 *
 *     • Programmatically unmute without checking current state
 *     • Batch-unmute multiple uids
 *     • Trigger the settings-page unmute flow ([data-unmute]
 *       buttons) without depending on the settings-page code
 *
 *   Public functions:
 *     window.unmuteAuthor(uid)          → Promise<boolean>
 *     window.SaikoUnmuteAuthor = {
 *       unmute,          // single
 *       unmuteMany,      // batch — Promise<number>
 *       wireSettingsList,// binds [data-unmute] inside a root
 *       unbindSettingsList,
 *       isMuted,         // passthrough
 *       listMuted        // snapshot
 *     }
 *
 *   Behaviour preserved 1:1 from the original:
 *
 *     • removed node: mutedAuthors/{myUid}/{uid}
 *     • write is `.catch(() => {})` best-effort
 *     • toast is t('unmute_author') with kind 'ok'
 *     • settings-page flow additionally re-renders the list
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED     → openPostMenu() → case 'muteauthor'
 *                          (unmute branch)
 *   Section §30 SETTINGS → mutedHTML() + wireMuted()
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *   - SaikoMuteAuthor (084)  js/feed/084-mute-author.js
 *                            (optional — used for isMuted/map)
 *
 * DOM ELEMENTS USED:
 *   Any [data-unmute] elements in the muted-users settings list
 *   (feature 040 renders them; this feature wires the click
 *   behaviour and can also be used to wire a re-rendered list).
 *
 * FIREBASE PATHS:
 *   mutedAuthors/{uid}                   (read + listen via 084)
 *   mutedAuthors/{uid}/{authorUid}       (remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.unmuteAuthor
 *   window.SaikoUnmuteAuthor = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[unmute-author] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMap() {
    try { return window.mutedAuthors || {}; } catch (e) { return {}; }
  }

  /* ----------------------------------------------------------
   * Predicate passthrough — prefers feature 084's implementation
   * when available so the source of truth stays single.
   * ---------------------------------------------------------- */
  function isMuted(uid) {
    if (!uid) return false;
    try {
      if (typeof window.iMutedAuthor === 'function') {
        return !!window.iMutedAuthor(uid);
      }
    } catch (e) {}
    return !!getMap()[uid];
  }

  /* ----------------------------------------------------------
   * listMuted — snapshot of currently-muted uids.
   * ---------------------------------------------------------- */
  function listMuted() {
    return Object.keys(getMap());
  }

  /* ============================================================
   * UNMUTE — main entry
   * ============================================================
   * Preserved 1:1 from the original unmute branch:
   *   await db.ref('mutedAuthors/' + myUid + '/' + uid).remove()
   *           .catch(() => {});
   *   toast(t('unmute_author'), 'ok');
   *
   * The write is silent-fail (never surfaces an error toast).
   * The toast fires on every call, matching the original —
   * even if the user was not muted (edge case, harmless).
   * ============================================================ */
  async function unmute(uid) {
    if (!uid) return false;

    var fbDb = getDB();
    var myUid = getMyUid();
    if (!fbDb || !myUid) return false;

    try {
      await fbDb.ref('mutedAuthors/' + myUid + '/' + uid).remove();
    } catch (e) {
      /* Original swallowed the error silently. Preserved. */
      return false;
    }

    safeToast(T('unmute_author'), 'ok');

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:mute-changed', {
        detail: { authorUid: uid, muted: false }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * UNMUTE MANY — batch
   * ============================================================
   * Sequential best-effort removal. Returns the number of
   * uids that were successfully unmuted. Emits a single
   * summary toast at the end (kind 'ok') when at least one
   * succeeded. Silent when none succeed.
   * ============================================================ */
  async function unmuteMany(uids) {
    if (!Array.isArray(uids) || !uids.length) return 0;

    var fbDb = getDB();
    var myUid = getMyUid();
    if (!fbDb || !myUid) return 0;

    var done = 0;
    for (var i = 0; i < uids.length; i++) {
      var uid = uids[i];
      if (!uid) continue;
      try {
        await fbDb.ref('mutedAuthors/' + myUid + '/' + uid).remove();
        done++;
      } catch (e) {
        /* Best-effort — keep going. */
      }
    }

    if (done > 0) {
      safeToast(T('unmute_author'), 'ok');
      try {
        window.dispatchEvent(new CustomEvent('saiko:mute-changed', {
          detail: { authorUid: null, muted: false, batch: done }
        }));
      } catch (e) {}
    }

    return done;
  }

  /* ============================================================
   * SETTINGS PAGE WIRING
   * ============================================================
   * Preserved 1:1 from the original wireMuted() block:
   *
   *   $('[data-unmute]').forEach(b => {
   *     b.addEventListener('click', async e => {
   *       e.stopPropagation();
   *       const uid = b.getAttribute('data-unmute');
   *       await db.ref('mutedAuthors/' + myUid + '/' + uid).remove();
   *       delete mutedAuthors[uid];
   *       toast(t('unmute_author'), 'ok');
   *       // re-render the muted-users page
   *       settingPageBody.innerHTML = mutedHTML();
   *       wireMuted();
   *     });
   *   });
   *
   * Two callbacks drive the re-render so this feature stays
   * decoupled from the settings page implementation:
   *
   *   opts.renderList    — fn() → HTML string for the list
   *   opts.mountRoot     — element where the re-rendered HTML
   *                        should be written
   *   opts.afterRender   — fn(root) called after the new HTML
   *                        is written (typically re-binds the
   *                        list, including calling
   *                        wireSettingsList again)
   *
   * Idempotent per node via dataset.unmuteBound.
   * ============================================================ */
  function wireSettingsList(root, opts) {
    var scope = root || document;
    opts = opts || {};
    var bound = 0;

    qsa('[data-unmute]', scope).forEach(function (b) {
      if (b.dataset.unmuteBound === '1') return;
      b.dataset.unmuteBound = '1';

      b.addEventListener('click', async function (e) {
        if (e && typeof e.stopPropagation === 'function') e.stopPropagation();

        var uid = b.getAttribute('data-unmute');
        if (!uid) return;

        /* 1) Perform the unmute --------------------------- */
        var ok = await unmute(uid);
        if (!ok) return;

        /* 2) Local map cleanup (mirrors original
         *    `delete mutedAuthors[uid]`) so the re-render
         *    does not show the removed row even before the
         *    Firebase listener updates the map. ------------ */
        try {
          if (window.mutedAuthors && window.mutedAuthors[uid]) {
            delete window.mutedAuthors[uid];
          }
        } catch (err) {}

        /* 3) Re-render the settings list ------------------ */
        if (typeof opts.renderList === 'function' &&
            opts.mountRoot) {
          try {
            var html = opts.renderList();
            if (typeof html === 'string') {
              opts.mountRoot.innerHTML = html;
              if (typeof opts.afterRender === 'function') {
                opts.afterRender(opts.mountRoot);
              }
            }
          } catch (err2) {
            console.warn('[unmute-author] re-render failed', err2);
          }
        }
      });
      bound++;
    });

    return bound;
  }

  function unbindSettingsList(root) {
    var scope = root || document;
    qsa('[data-unmute]', scope).forEach(function (b) {
      if (b.dataset.unmuteBound !== '1') return;
      var clone = b.cloneNode(true);
      clone.removeAttribute('data-unmute-bound');
      b.parentNode && b.parentNode.replaceChild(clone, b);
    });
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original entry point — used by feature 088's post menu and
   * by anything else that wants the unmute-only path. */
  window.unmuteAuthor = unmute;

  window.SaikoUnmuteAuthor = {
    unmute: unmute,
    unmuteMany: unmuteMany,
    wireSettingsList: wireSettingsList,
    unbindSettingsList: unbindSettingsList,
    isMuted: isMuted,
    listMuted: listMuted
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 085 — unmute-author ready');
  } catch (e) {}

})();