/* ============================================================
 * FEATURE:        Bookmark / Save Post
 * FEATURE NUMBER: 063
 * FILE:           js/feed/063-bookmark-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "Save" (bookmark) system for posts:
 *
 *     • toggleSave(pid)         toggle the bookmark
 *     • iSaved(pid)             check the bookmark state
 *     • startSavedPosts()       attach the live listener
 *     • detachSavedPosts()      detach the live listener
 *     • openSaved()             open the Saved-Posts overlay
 *
 *   Behaviour preserved 1:1 from the original §26 block.
 *
 *   ORIGINAL STATE SHAPE:
 *     savedPosts = { [postId]: timestampNumber }
 *     — truthy keys mark saved posts; the value is the save
 *       time (originally set via `now()`).
 *
 *   The saved feed is rendered using the SAME post-card
 *   renderer as the main feed (feature 055: post-card.js),
 *   wired with the same click handlers, and re-painted with
 *   the same count refresher (feature 051).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §26 SAVED / HASHTAGS / … → savedPosts, savedRef,
 *   savedCb, detachSavedPosts(), startSavedPosts(),
 *   toggleSave(), openSaved(), iSaved().
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - window.postsCache      js/feed/051-feed-render.js
 *   - paintPostCounts        js/feed/051-feed-render.js
 *   - postHTML               js/feed/post-card.js
 *   - wirePostInteractions   js/feed/post-card.js
 *   - observePostVideos      js/feed/082-video-observer.js (optional)
 *   - openOverlay            js/nav/038-overlay-system.js
 *   - toast                  js/nav/042-toast.js
 *   - t / now                helpers
 *
 * DOM ELEMENTS USED:
 *   #ovSaved        (overlay container)
 *   #savedBody      (list container inside it)
 *
 * FIREBASE PATHS:
 *   savedPosts/{uid}          (read + listen)
 *   savedPosts/{uid}/{pid}    (write / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.toggleSave          (original name preserved)
 *   window.iSaved              (original name preserved)
 *   window.startSavedPosts     (original name preserved)
 *   window.detachSavedPosts    (original name preserved)
 *   window.openSaved           (original name preserved)
 *   window.savedPosts          (live map — shared)
 *   window.SaikoBookmark = {
 *     toggle, isSaved, start, detach, open,
 *     getMap, getCount, clear
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * STATE
   * ---------------------------------------------------------- */
  var savedRef = null;
  var savedCb  = null;

  /* Live map — exposed on window so 051 / 088 / 070 can read
   * it without going through a getter. */
  window.savedPosts = window.savedPosts || {};

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[bookmark] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * IS SAVED
   * Reads the live map. Safe even before the listener has
   * populated it (returns false).
   * ---------------------------------------------------------- */
  function isSaved(pid) {
    if (!pid) return false;
    return !!window.savedPosts[pid];
  }

  /* ----------------------------------------------------------
   * GET MAP / COUNT (additive helpers)
   * ---------------------------------------------------------- */
  function getMap() { return window.savedPosts; }
  function getCount() {
    return Object.keys(window.savedPosts || {}).length;
  }

  /* ----------------------------------------------------------
   * TOGGLE SAVE
   * Preserved 1:1 from original toggleSave(pid):
   *   • ref = savedPosts/{uid}/{pid}
   *   • if snap exists → remove + toast t('unbookmark')
   *   • else            → set(now()) + toast t('bookmark')
   *                       + bumpDaily('save', 1)
   *   • always → paintPostCounts()
   *   • errors → toast err.message || t('error')
   * ---------------------------------------------------------- */
  async function toggle(pid) {
    if (!pid) return false;
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    var ref = fbDb.ref('savedPosts/' + uid + '/' + pid);
    try {
      var snap = await ref.get();
      if (snap.exists()) {
        await ref.remove();
        safeToast(T('unbookmark'), 'ok');
      } else {
        await ref.set(timeNow());
        safeToast(T('bookmark'), 'ok');
        /* Daily stat for missions */
        safeCall('bumpDaily', ['save', 1]);
      }
      /* Refresh every rendered card's bookmark state */
      safeCall('paintPostCounts');
      /* Notify subscribers */
      try {
        window.dispatchEvent(new CustomEvent('saiko:save-changed', {
          detail: { postId: pid, saved: !snap.exists() }
        }));
      } catch (e) {}
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * START — attach the live listener.
   * Preserved 1:1 from original startSavedPosts().
   * ---------------------------------------------------------- */
  function start() {
    if (savedRef && savedCb) return true;
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    savedRef = fbDb.ref('savedPosts/' + uid);
    savedCb = savedRef.on('value', function (s) {
      window.savedPosts = s.val() || {};
      safeCall('paintPostCounts');
    });
    return true;
  }

  /* ----------------------------------------------------------
   * DETACH — detach the live listener + reset local map.
   * Preserved 1:1 from original detachSavedPosts().
   * ---------------------------------------------------------- */
  function detach() {
    if (savedRef && savedCb) {
      try { savedRef.off('value', savedCb); } catch (e) {}
    }
    savedRef = null;
    savedCb = null;
    window.savedPosts = {};
    return true;
  }

  /* ----------------------------------------------------------
   * OPEN SAVED OVERLAY
   * Preserved 1:1 from original openSaved().
   * ---------------------------------------------------------- */
  function open() {
    safeCall('openOverlay', ['ovSaved']);

    var body = qs('#savedBody');
    if (!body) return false;

    var ids = Object.keys(window.savedPosts || {});
    var cache = Array.isArray(window.postsCache) ? window.postsCache : [];
    var list = ids
      .map(function (id) {
        for (var i = 0; i < cache.length; i++) {
          if (cache[i] && cache[i].id === id) return cache[i];
        }
        return null;
      })
      .filter(Boolean);

    if (!list.length) {
      body.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' +
            (typeof svgIcon === 'function' ? svgIcon('bookmark') : '') +
          '</span>' +
          '<p>' + esc(T('no_posts')) + '</p>' +
        '</div>';
      return true;
    }

    /* Render each saved post using the shared card renderer,
     * then wire its interactions and repaint counts. */
    body.innerHTML = list.map(function (p) {
      try {
        if (typeof window.postHTML === 'function') return window.postHTML(p);
      } catch (e) {}
      return '';
    }).join('');

    safeCall('wirePostInteractions', [body]);
    safeCall('paintPostCounts');
    safeCall('observePostVideos', [body]);

    return true;
  }

  /* ----------------------------------------------------------
   * CLEAR — additive helper for tests / logout teardown.
   * Removes the entire savedPosts/{uid} node.
   * ---------------------------------------------------------- */
  async function clear() {
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;
    try {
      await fbDb.ref('savedPosts/' + uid).remove();
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original globals — preserved so feature 051, feature 088
   * (openPostMenu), feature 070 (profile "Saved" tab), and any
   * other caller keeps working unchanged. */
  window.toggleSave       = toggle;
  window.iSaved           = isSaved;
  window.startSavedPosts  = start;
  window.detachSavedPosts = detach;
  window.openSaved        = open;

  window.SaikoBookmark = {
    toggle: toggle,
    isSaved: isSaved,
    start: start,
    detach: detach,
    open: open,
    getMap: getMap,
    getCount: getCount,
    clear: clear
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 063 — bookmark-post ready');
  } catch (e) {}

})();