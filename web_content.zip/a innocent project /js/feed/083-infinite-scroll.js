/* ============================================================
 * FEATURE:        Infinite Scroll
 * FEATURE NUMBER: 083
 * FILE:           js/feed/083-infinite-scroll.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused, reusable infinite-scroll driver for the home
 *   feed. Extracts the throttled window scroll listener that
 *   lived inline at the bottom of feature 051's feed-render
 *   block so:
 *
 *     • The listener is owned by its own module (single
 *       attach/detach lifecycle).
 *     • Any future surface (e.g. profile grid, hashtag feed,
 *       saved-posts list) can reuse the same driver by
 *       supplying its own callbacks.
 *     • Feature 051 stays focused on rendering.
 *
 *   Preserved 1:1 from the original source:
 *
 *     window.addEventListener('scroll', throttle(() => {
 *       if (typeof currentNav === 'string' && currentNav !== 'home') return;
 *       if (feedLoadingMore) return;
 *       const scrolled = window.scrollY + window.innerHeight;
 *       if (scrolled > document.body.scrollHeight - 600) {
 *         const allVisible = sortedFeed();
 *         if (feedVisibleCount < allVisible.length) loadMoreFeed();
 *       }
 *     }, 400), { passive: true });
 *
 *   Constants preserved:
 *     • INFINITE_SCROLL_PX = 600   (bottom offset)
 *     • INFINITE_SCROLL_MS = 400   (throttle window)
 *
 *   All state reads and the load-more call delegate to the
 *   public API of feature 051 (SaikoFeedRender). The driver
 *   itself keeps no state, so it is trivially testable.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → the trailing throttled scroll listener
 *
 * DEPENDENCIES (loaded earlier):
 *   - SaikoFeedRender       js/feed/051-feed-render.js
 *                             .getVisibleCount
 *                             .sorted
 *                             .loadMore
 *   - window.currentNav     js/nav/036-bottom-nav.js
 *
 * DOM ELEMENTS USED:
 *   document (window scroll)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoInfiniteScroll = {
 *     start, stop,
 *     isRunning,
 *     tick,               // one manual pass — useful for tests
 *     CONFIG
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * Preserved byte-for-byte from the original.
   * ============================================================ */
  var INFINITE_SCROLL_PX = 600;
  var INFINITE_SCROLL_MS = 400;

  /* ============================================================
   * STATE
   * ============================================================ */
  var scrollHandler = null;
  var running = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function isHomeActive() {
    try {
      return (typeof window.currentNav === 'string')
        ? window.currentNav === 'home'
        : false;
    } catch (e) {
      return false;
    }
  }

  /* Throttle — preserved from the original helper used in 051. */
  function throttle(fn, ms) {
    var last = 0, tm = null;
    return function () {
      var a = arguments, c = this, now = Date.now();
      if (now - last >= ms) {
        last = now;
        fn.apply(c, a);
      } else {
        clearTimeout(tm);
        tm = setTimeout(function () {
          last = Date.now();
          fn.apply(c, a);
        }, ms - (now - last));
      }
    };
  }

  /* ============================================================
   * MANUAL TICK — one evaluation pass, no throttling
   * ============================================================
   * Returns true when a load-more was triggered, false
   * otherwise. Exposed so tests and programmatic callers can
   * drive a single pass without attaching the scroll listener.
   * ============================================================ */
  function tick() {
    /* 1) Home only --------------------------------------- */
    if (!isHomeActive()) return false;

    /* 2) Feature 051 must be available ------------------- */
    var feed = null;
    try { feed = window.SaikoFeedRender; } catch (e) {}
    if (!feed || typeof feed.loadMore !== 'function') return false;

    /* 3) Bottom-proximity check -------------------------- */
    var scrolled;
    var docHeight;
    try {
      scrolled  = window.scrollY + window.innerHeight;
      docHeight = document.body ? document.body.scrollHeight : 0;
    } catch (e) {
      return false;
    }
    if (scrolled <= docHeight - INFINITE_SCROLL_PX) return false;

    /* 4) Is there anything more to load? ----------------- */
    var allVisible = [];
    try {
      if (typeof feed.sorted === 'function') {
        allVisible = feed.sorted() || [];
      }
    } catch (e) {
      allVisible = [];
    }

    var visibleCount = 0;
    try {
      if (typeof feed.getVisibleCount === 'function') {
        visibleCount = Number(feed.getVisibleCount()) || 0;
      }
    } catch (e) {}

    if (visibleCount >= allVisible.length) return false;

    /* 5) Trigger load-more ------------------------------- */
    try {
      feed.loadMore();
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * START / STOP
   * ============================================================ */
  function start() {
    if (running) return true;

    /* Throttled wrapper — the original used exactly this
     * combination (throttle at INFINITE_SCROLL_MS on top of a
     * passive scroll listener). */
    var throttled = throttle(tick, INFINITE_SCROLL_MS);

    scrollHandler = function () { throttled(); };

    try {
      window.addEventListener('scroll', scrollHandler, { passive: true });
      running = true;
      return true;
    } catch (e) {
      scrollHandler = null;
      running = false;
      return false;
    }
  }

  function stop() {
    if (!running || !scrollHandler) return false;
    try {
      window.removeEventListener('scroll', scrollHandler);
    } catch (e) {}
    scrollHandler = null;
    running = false;
    return true;
  }

  function isRunning() { return running; }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoInfiniteScroll = {
    start: start,
    stop: stop,
    isRunning: isRunning,
    tick: tick,
    CONFIG: {
      INFINITE_SCROLL_PX: INFINITE_SCROLL_PX,
      INFINITE_SCROLL_MS: INFINITE_SCROLL_MS
    }
  };

  /* ============================================================
   * AUTO-START
   * The original attached the scroll listener at module load.
   * Feature 051 does not need to be loaded yet — the listener
   * gracefully no-ops until the feed API is available.
   *
   * If a caller wants to disable the listener (e.g. embedding
   * in a host shell that scrolls a custom container instead of
   * the window), call SaikoInfiniteScroll.stop() at any time.
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 083 — infinite-scroll ready');
  } catch (e) {}

})();