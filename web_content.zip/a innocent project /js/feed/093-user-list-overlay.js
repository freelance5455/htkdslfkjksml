/* ============================================================
 * FEATURE:        User List Overlay
 * FEATURE NUMBER: 093 (feed folder)
 * FILE:           js/feed/093-user-list-overlay.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Central helper for "tap a count → see the users" flows.
 *
 *   Provides:
 *     • showUsersOverlay(title, uids)            — generic
 *     • showCommentReactionUsers(pid, cid, emoji, isReel)
 *     • showPostLikers(pid)                      — likes + reactions
 *     • showReelLikers(rid)                      — likes + reactions
 *
 *   Uses the existing #ovUserList / #userListBody (already in
 *   index.html). Clicking a row closes the list and opens the
 *   user's profile.
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[user-list] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * RENDER USER LIST INTO #ovUserList
   * ============================================================ */
  function renderUsersOverlay(title, uids) {
    var body = qs('#userListBody');
    var titleEl = qs('#userListTitle');
    if (!body) { safeToast('User list not found', 'err'); return false; }

    if (titleEl) titleEl.textContent = title || 'Users';

    if (!uids || !uids.length) {
      body.innerHTML = '<div class="empty"><p>' + esc(T('no_results') || 'No users') + '</p></div>';
      safeCall('openOverlay', ['ovUserList']);
      return true;
    }

    var me = getMyUid();

    body.innerHTML = uids.map(function (uid) {
      var u = findUser(uid) || { name: 'User', photo: '' };
      var isMe = (uid === me);
      var displayName = (u.name || 'User') + (isMe ? ' (' + T('you') + ')' : '');
      return '<div class="user-card" data-uluid="' + esc(uid) + '">' +
        avatarHTML(u.photo, u.name, 'av-40', uid) +
        '<div class="grow">' +
          '<div class="name">' + esc(displayName) + '</div>' +
          (u.bio ? '<div class="muted ellipsis">' + esc(String(u.bio).slice(0, 60)) + '</div>' : '') +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
      '</div>';
    }).join('');

    qsa('[data-uluid]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var uid = n.getAttribute('data-uluid');
        if (!uid) return;
        safeCall('closeOverlay', ['ovUserList']);
        setTimeout(function () {
          safeCall('openUserProfile', [uid]);
        }, 100);
      });
    });

    safeCall('openOverlay', ['ovUserList']);
    return true;
  }

  /* ============================================================
   * SHOW COMMENT REACTION USERS
   * pid     — post id (or reel id when isReel is true)
   * cid     — comment id
   * emoji   — the emoji to filter by
   * isReel  — false → commentReactions/{pid}/{cid}
   *           true  → reelCommentReactions/{rid}/{cid}
   * ============================================================ */
  async function showCommentReactionUsers(pid, cid, emoji, isReel) {
    if (!pid || !cid || !emoji) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    var path = isReel
      ? ('reelCommentReactions/' + pid + '/' + cid)
      : ('commentReactions/' + pid + '/' + cid);

    try {
      var snap = await fbDb.ref(path).get();
      var v = snap.val() || {};
      var uids = [];
      Object.keys(v).forEach(function (u) {
        var rv = v[u];
        var rt = (typeof rv === 'string') ? rv : (rv && rv.type);
        if (rt === emoji) uids.push(u);
      });
      if (!uids.length) {
        safeToast('No ' + emoji + ' reactions yet');
        return false;
      }
      return renderUsersOverlay(emoji + ' Reactions', uids);
    } catch (err) {
      console.error('[user-list] showCommentReactionUsers error', err);
      return false;
    }
  }

  /* ============================================================
   * SHOW POST LIKERS (postLikes + postReactions combined)
   * ============================================================ */
  async function showPostLikers(pid) {
    if (!pid) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      var results = await Promise.all([
        fbDb.ref('postLikes/' + pid).get(),
        fbDb.ref('postReactions/' + pid).get()
      ]);
      var likesMap = results[0].val() || {};
      var reactMap = results[1].val() || {};
      var seen = {};
      var uids = [];
      Object.keys(likesMap).forEach(function (u) {
        if (!seen[u]) { seen[u] = 1; uids.push(u); }
      });
      Object.keys(reactMap).forEach(function (u) {
        if (!seen[u]) { seen[u] = 1; uids.push(u); }
      });
      if (!uids.length) {
        safeToast('No likes yet');
        return false;
      }
      return renderUsersOverlay('Liked by', uids);
    } catch (err) {
      console.error('[user-list] showPostLikers error', err);
      return false;
    }
  }

  /* ============================================================
   * SHOW REEL LIKERS (reelLikes + reelReactions combined)
   * ============================================================ */
  async function showReelLikers(rid) {
    if (!rid) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      var results = await Promise.all([
        fbDb.ref('reelLikes/' + rid).get(),
        fbDb.ref('reelReactions/' + rid).get()
      ]);
      var likesMap = results[0].val() || {};
      var reactMap = results[1].val() || {};
      var seen = {};
      var uids = [];
      Object.keys(likesMap).forEach(function (u) {
        if (!seen[u]) { seen[u] = 1; uids.push(u); }
      });
      Object.keys(reactMap).forEach(function (u) {
        if (!seen[u]) { seen[u] = 1; uids.push(u); }
      });
      if (!uids.length) {
        safeToast('No likes yet');
        return false;
      }
      return renderUsersOverlay('Liked by', uids);
    } catch (err) {
      console.error('[user-list] showReelLikers error', err);
      return false;
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.showUsersOverlay         = renderUsersOverlay;
  window.showCommentReactionUsers = showCommentReactionUsers;
  window.showPostLikers           = showPostLikers;
  window.showReelLikers           = showReelLikers;

  window.SaikoUserListOverlay = {
    render: renderUsersOverlay,
    showCommentReactionUsers: showCommentReactionUsers,
    showPostLikers: showPostLikers,
    showReelLikers: showReelLikers
  };

  try { console.debug('[boot] feature 093 (feed) — user-list-overlay ready'); } catch (e) {}
})();