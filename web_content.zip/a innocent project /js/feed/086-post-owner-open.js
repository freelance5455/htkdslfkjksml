/* ============================================================
 * FEATURE:        Post Owner Profile Open
 * FEATURE NUMBER: 086
 * FILE:           js/feed/086-post-owner-open.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper that owns the "click on a post author →
 *   open their profile (or, when it's the current user, switch
 *   to the profile tab)" flow.
 *
 *   The original single-file build had this logic inline twice:
 *
 *     §15 FEED (wirePostInteractions):
 *       [data-postowner] click →
 *         if (uid !== myUid) openUserProfile(uid);
 *         else                navigate('profile');
 *
 *     §17 POST SPLIT (openPostSplit + comment rendering):
 *       the post head avatar click → same rule for the author,
 *       plus a variant for comment authors ([data-suser]) that
 *       closes the split view first.
 *
 *   This module extracts those rules into:
 *
 *     • openAuthor(uid, opts)
 *         → Promise<boolean>
 *         → self / other dispatch with optional overlay close
 *
 *     • wireOwnerElements(root, opts)
 *         → binds every [data-postowner] inside root
 *
 *     • wireCommentAuthorElements(root, opts)
 *         → binds every [data-suser] inside root and closes
 *           #ovSplitComments before navigating
 *
 *   All navigation routes through the app's public API:
 *     window.openUserProfile (feature 070 area)
 *     window.navigate        (feature 036)
 *     window.closePostSplit  (feature 067, optional)
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → wirePostInteractions() → [data-postowner]
 *   Section §17 POST SPLIT → [data-suser] handling in
 *                            wireSplitComments()
 *
 * DEPENDENCIES (loaded earlier):
 *   - myUid               js/auth/004-auth-state.js
 *   - openUserProfile     profile module (safely-called)
 *   - navigate            js/nav/036-bottom-nav.js
 *   - closePostSplit      js/feed/067-post-split.js (optional)
 *
 * DOM ELEMENTS USED:
 *   [data-postowner]    (post head avatar + name row)
 *   [data-suser]        (comment author avatar + name)
 *
 * FIREBASE PATHS:
 *   none directly — profile module owns the data reads.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openPostOwner            (new global, additive)
 *   window.SaikoPostOwnerOpen = {
 *     open,                 // single uid
 *     wireOwnerElements,    // [data-postowner] inside root
 *     wireCommentAuthorElements, // [data-suser] inside root
 *     unbindOwnerElements,
 *     unbindCommentAuthorElements,
 *     DATA_ATTRS            // { owner: 'data-postowner', comment: 'data-suser' }
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var DATA_ATTRS = {
    owner:   'data-postowner',
    comment: 'data-suser'
  };

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-owner-open] safeCall:', name, e); }
    return undefined;
  }

  function getMyUid() {
    try {
      return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null;
    } catch (e) { return null; }
  }

  /* ============================================================
   * OPEN — the dispatch rule
   * ============================================================
   * Preserved 1:1 from the original inline behaviour:
   *
   *   • uid === myUid → navigate('profile')
   *   • uid !== myUid → openUserProfile(uid)
   *   • uid missing   → no-op
   *
   * opts.closeSplit
   *   When true and #ovSplitComments is open, closePostSplit()
   *   is called first. Used by the [data-suser] wiring.
   *
   * opts.beforeNavigate
   *   Optional hook — fires after closeSplit (if any) but
   *   before the actual navigation. Useful for adding analytics
   *   without touching the routing logic.
   *
   * Returns Promise<boolean> — true when a navigation was
   * attempted, false on empty uid.
   * ============================================================ */
  async function open(uid, opts) {
    if (!uid) return false;
    opts = opts || {};

    /* 1) Optional overlay close --------------------------- */
    if (opts.closeSplit) {
      safeCall('closePostSplit');
    }

    /* 2) Optional pre-navigation hook --------------------- */
    if (typeof opts.beforeNavigate === 'function') {
      try { opts.beforeNavigate(uid); } catch (e) {}
    }

    /* 3) Self / other dispatch ---------------------------- */
    var me = getMyUid();

    if (me && uid === me) {
      safeCall('navigate', ['profile']);
      return true;
    }

    var opened = safeCall('openUserProfile', [uid]);
    /* openUserProfile returns undefined in the original; treat
     * any non-throwing call as success. */
    return opened !== false;
  }

  /* ============================================================
   * WIRE OWNER ELEMENTS — [data-postowner]
   * ============================================================
   * Preserved 1:1 from feature 055's wirePostInteractions():
   *
   *   root.querySelectorAll('[data-postowner]').forEach(n => {
   *     if (n.dataset.wired) return; n.dataset.wired = '1';
   *     n.addEventListener('click', () => {
   *       const uid = n.getAttribute('data-postowner');
   *       if (uid !== myUid) openUserProfile(uid);
   *       else                navigate('profile');
   *     });
   *   });
   *
   * Idempotent via dataset.ownerOpenBound.
   * ============================================================ */
  function wireOwnerElements(root, opts) {
    var scope = root || document;
    var bound = 0;

    qsa('[' + DATA_ATTRS.owner + ']', scope).forEach(function (n) {
      if (n.dataset.ownerOpenBound === '1') return;
      n.dataset.ownerOpenBound = '1';

      n.addEventListener('click', function (e) {
        /* Click on the options (⋯) button or a hashtag inside
         * the head text should not trigger profile open. The
         * original relied on those handlers calling
         * stopPropagation; we add a light guard for safety. */
        var t = e && e.target;
        if (t && t.closest &&
            (t.closest('[data-postmenu]') ||
             t.closest('.hashtag') ||
             t.closest('.mention'))) {
          return;
        }

        var uid = n.getAttribute(DATA_ATTRS.owner);
        open(uid, opts);
      });

      bound++;
    });

    return bound;
  }

  /* ============================================================
   * WIRE COMMENT AUTHOR ELEMENTS — [data-suser]
   * ============================================================
   * Preserved 1:1 from feature 067's wireSplitComments():
   *
   *   [data-suser] click → closePostSplit() then openUserProfile(uid)
   *   (self → skip in the split context — the original only
   *    navigated for OTHER uids inside comments)
   *
   * IMPORTANT DIFFERENCE FROM OWNER:
   *   For comment authors the original did NOT navigate to the
   *   profile tab when uid === myUid — it simply did nothing.
   *   We preserve that rule here by passing a variant that
   *   skips self.
   *
   * Idempotent via dataset.commentAuthorBound.
   * ============================================================ */
  function wireCommentAuthorElements(root, opts) {
    var scope = root || document;
    var bound = 0;

    qsa('[' + DATA_ATTRS.comment + ']', scope).forEach(function (n) {
      if (n.dataset.commentAuthorBound === '1') return;
      n.dataset.commentAuthorBound = '1';

      n.addEventListener('click', function (e) {
        /* Same guard — reply/react chips inside the comment
         * head must not trigger profile open. */
        var t = e && e.target;
        if (t && t.closest &&
            (t.closest('.reply-btn') ||
             t.closest('.cmt-react') ||
             t.closest('.cmt-rx') ||
             t.closest('.hashtag') ||
             t.closest('.mention'))) {
          return;
        }

        var uid = n.getAttribute(DATA_ATTRS.comment);
        if (!uid) return;

        var me = getMyUid();

        /* Preserved original rule: skip self in comment context. */
        if (me && uid === me) return;

        /* Close the split overlay first, then navigate. */
        safeCall('closePostSplit');
        safeCall('openUserProfile', [uid]);
      });

      bound++;
    });

    return bound;
  }

  /* ============================================================
   * UNBIND — clone-and-swap detach
   * ============================================================ */
  function unbindOwnerElements(root) {
    qsa('[' + DATA_ATTRS.owner + ']', root || document).forEach(function (n) {
      if (n.dataset.ownerOpenBound !== '1') return;
      var clone = n.cloneNode(true);
      clone.removeAttribute('data-owner-open-bound');
      n.parentNode && n.parentNode.replaceChild(clone, n);
    });
  }

  function unbindCommentAuthorElements(root) {
    qsa('[' + DATA_ATTRS.comment + ']', root || document).forEach(function (n) {
      if (n.dataset.commentAuthorBound !== '1') return;
      var clone = n.cloneNode(true);
      clone.removeAttribute('data-comment-author-bound');
      n.parentNode && n.parentNode.replaceChild(clone, n);
    });
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openPostOwner = open;

  window.SaikoPostOwnerOpen = {
    open: open,
    wireOwnerElements: wireOwnerElements,
    wireCommentAuthorElements: wireCommentAuthorElements,
    unbindOwnerElements: unbindOwnerElements,
    unbindCommentAuthorElements: unbindCommentAuthorElements,
    DATA_ATTRS: DATA_ATTRS
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 086 — post-owner-open ready');
  } catch (e) {}

})();