/* ============================================================
 * FEATURE:        Video Observer
 * FEATURE NUMBER: 082
 * FILE:           js/feed/082-video-observer.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Centralised autoplay/pause controller for inline post
 *   videos (the ones rendered by the post-card as
 *   `.post-video video`) plus a global "tab hidden" cleanup
 *   that also reaches into reels, split-view media, and any
 *   other <video> in the app.
 *
 *   Responsibilities preserved 1:1 from the original §15 FEED
 *   block plus the §5 UTILITIES media helpers it depends on:
 *
 *     1. play/pause primitives
 *          safePlay(video)      — best-effort play with
 *                                 AbortError / NotAllowedError
 *                                 handling and a pending-guard
 *          safePause(video)     — pause if playing
 *          hardStopVideo(v)     — pause + mute (used by teardown)
 *          hardStopAll(selector)— hardStop every match
 *
 *     2. IntersectionObserver
 *          setupPostVideoObserver()  — create the observer
 *          observePostVideos(root)   — attach every
 *                                      `.post-video video`
 *          detachPostVideoObserver() — additive teardown hook
 *
 *        Threshold 0.4 — a video starts playing when 40% of it
 *        is visible AND the user is on the home feed AND the
 *        browser tab is not hidden. It pauses the moment it
 *        falls below that threshold.
 *
 *     3. Visibility handling
 *          document 'visibilitychange' → pause every playing
 *          video in the app (feed posts, reels, reel-split,
 *          split-view) when the tab goes hidden. When the tab
 *          comes back AND the user is on the home feed, resume
 *          every video that is currently on-screen.
 *
 *   All play/pause calls go through the safe primitives so a
 *   browser autoplay rejection (very common on iOS Safari) or
 *   a mid-flight `AbortError` can never crash the app.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §5 UTILITIES → safePlay, safePause,
 *                          hardStopVideo, hardStopAll
 *   Section §15 FEED     → postVideoObserver,
 *                          setupPostVideoObserver,
 *                          observePostVideos,
 *                          visibilitychange listener
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure DOM + IntersectionObserver API
 *
 * DOM ELEMENTS USED:
 *   .post-video video            (feed post videos)
 *   #feedList .post-video video  (feed scope for resume)
 *   .reel video                  (reels feed)
 *   #ovReelSplit video           (reel split view)
 *   .rs-video                    (reel split video)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.safePlay
 *   window.safePause
 *   window.hardStopVideo
 *   window.hardStopAll
 *   window.setupPostVideoObserver
 *   window.observePostVideos
 *   window.detachPostVideoObserver   (additive)
 *   window.SaikoVideoObserver = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var THRESHOLD = 0.4;
  var OBS_DATASET = 'obs';               /* v.dataset.obs guard */

  /* ============================================================
   * STATE
   * ============================================================ */
  var postVideoObserver = null;
  var visibilityHandler = null;

  /* ============================================================
   * LOCAL HELPERS
   * ============================================================ */
  function isHomeActive() {
    try {
      return (typeof window.currentNav === 'string')
        ? window.currentNav === 'home'
        : false;
    } catch (e) { return false; }
  }

  /* ============================================================
   * SAFE MEDIA PRIMITIVES
   * Preserved 1:1 from the original §5 UTILITIES block.
   * ============================================================ */

  /* safePlay(video) → Promise<void>
   * Best-effort play with:
   *   • isConnected guard        — skip detached nodes
   *   • already-playing guard
   *   • playPending dataset flag — prevents double-play
   *                                races
   *   • AbortError              — silent (rapid play/pause
   *                                toggle; not a failure)
   *   • NotAllowedError         — retry muted once (the
   *                                standard autoplay workaround)
   */
  function safePlay(video) {
    if (!video || !video.isConnected) return Promise.resolve();
    if (!video.paused) return Promise.resolve();
    if (video.dataset.playPending === '1') return Promise.resolve();

    video.dataset.playPending = '1';

    var p;
    try {
      p = video.play();
    } catch (e) {
      video.dataset.playPending = '';
      return Promise.resolve();
    }

    if (p && p.then) {
      return p.then(function () {
        video.dataset.playPending = '';
      }).catch(function (err) {
        video.dataset.playPending = '';

        if (err && err.name === 'AbortError') return;

        if (err && err.name === 'NotAllowedError') {
          /* Retry muted — matches the standard workaround and
           * the original source. */
          try {
            video.muted = true;
            var p2 = video.play();
            if (p2 && p2.catch) p2.catch(function () {});
          } catch (e2) {}
          return;
        }
      });
    }

    video.dataset.playPending = '';
    return Promise.resolve();
  }

  /* safePause(video) — pause if playing, swallow errors. */
  function safePause(video) {
    if (!video) return;
    try { if (!video.paused) video.pause(); }
    catch (e) {}
  }

  /* hardStopVideo(v) — pause + mute, used by teardown. */
  function hardStopVideo(v) {
    if (!v) return;
    try { v.pause(); } catch (e) {}
    try { v.muted = true; } catch (e) {}
  }

  /* hardStopAll(selector) — hardStop every match. */
  function hardStopAll(selector) {
    try {
      document.querySelectorAll(selector).forEach(hardStopVideo);
    } catch (e) {}
  }

  /* ============================================================
   * INTERSECTION OBSERVER
   * ============================================================ */

  /* setupPostVideoObserver()
   * Preserved 1:1 from the original:
   *   • idempotent (returns if already created)
   *   • threshold 0.4
   *   • on intersect   → if on home and tab visible, mute+play
   *   • on unobserve   → safePause
   */
  function setupPostVideoObserver() {
    if (postVideoObserver) return postVideoObserver;

    try {
      postVideoObserver = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
          var en = entries[i];
          var v = en.target;
          if (!v || !v.isConnected) continue;

          if (en.isIntersecting) {
            if (isHomeActive() && !document.hidden) {
              v.muted = true;
              safePlay(v);
            }
          } else {
            safePause(v);
          }
        }
      }, { threshold: THRESHOLD });
    } catch (e) {
      /* Very old browsers without IntersectionObserver — leave
       * observer null. observePostVideos() will be a no-op and
       * the feed simply has no autoplay. */
      postVideoObserver = null;
    }

    return postVideoObserver;
  }

  /* observePostVideos(root)
   * Preserved 1:1 from the original:
   *   • ensure the observer exists
   *   • walk every `.post-video video` inside `root`
   *   • skip ones already observed (via dataset.obs)
   *   • default to muted
   *   • observe
   */
  function observePostVideos(root) {
    if (!postVideoObserver) setupPostVideoObserver();
    if (!postVideoObserver) return 0;

    var scope = root || document;
    var nodes = scope.querySelectorAll('.post-video video');
    var count = 0;

    for (var i = 0; i < nodes.length; i++) {
      var v = nodes[i];
      if (v.dataset[OBS_DATASET] === '1') continue;
      v.dataset[OBS_DATASET] = '1';
      v.muted = true;
      try {
        postVideoObserver.observe(v);
        count++;
      } catch (e) {}
    }
    return count;
  }

  /* detachPostVideoObserver() — additive
   * Fully tears down the observer and un-marks every observed
   * video so a later re-attach will re-observe them.
   */
  function detachPostVideoObserver() {
    if (postVideoObserver) {
      try { postVideoObserver.disconnect(); } catch (e) {}
      postVideoObserver = null;
    }
    try {
      document.querySelectorAll('.post-video video').forEach(function (v) {
        try { delete v.dataset[OBS_DATASET]; } catch (e) {}
      });
    } catch (e) {}
    return true;
  }

  /* ============================================================
   * VISIBILITY HANDLING
   * Preserved 1:1 from the original document 'visibilitychange'
   * listener:
   *   • hidden          → pause every playing video across
   *                       feed / reels / split-view
   *   • back & on home  → resume every #feedList video whose
   *                       bounding rect intersects the viewport
   * ============================================================ */
  function handleVisibilityChange() {
    /* --- Tab hidden → stop all playback ------------------- */
    if (document.hidden) {
      try {
        document.querySelectorAll(
          '.post-video video, .reel video, #ovReelSplit video, .rs-video'
        ).forEach(function (v) {
          if (!v.paused) safePause(v);
        });
      } catch (e) {}
      return;
    }

    /* --- Tab visible & on home → resume on-screen videos -- */
    if (!isHomeActive()) return;

    try {
      document.querySelectorAll('#feedList .post-video video').forEach(function (v) {
        var r = v.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) {
          v.muted = true;
          safePlay(v);
        }
      });
    } catch (e) {}
  }

  /* ============================================================
   * AUTO-ATTACH — visibility listener
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      visibilityHandler = handleVisibilityChange;
      document.addEventListener('visibilitychange', visibilityHandler);
    }, { once: true });
  } else {
    visibilityHandler = handleVisibilityChange;
    document.addEventListener('visibilitychange', visibilityHandler);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original globals — preserved so feature 051 (feed render),
   * feature 063 (bookmark overlay), feature 067 (post-split),
   * feature 080 (hashtag overlay), and feature 038's teardown
   * (via detachAll's hardStopAll calls) all keep working. */
  window.safePlay                 = safePlay;
  window.safePause                = safePause;
  window.hardStopVideo            = hardStopVideo;
  window.hardStopAll              = hardStopAll;
  window.setupPostVideoObserver   = setupPostVideoObserver;
  window.observePostVideos        = observePostVideos;
  window.detachPostVideoObserver  = detachPostVideoObserver;

  window.SaikoVideoObserver = {
    /* primitives */
    safePlay: safePlay,
    safePause: safePause,
    hardStopVideo: hardStopVideo,
    hardStopAll: hardStopAll,

    /* observer lifecycle */
    setup: setupPostVideoObserver,
    observe: observePostVideos,
    detach: detachPostVideoObserver,

    /* exposed for tests / introspection */
    getObserver: function () { return postVideoObserver; },
    THRESHOLD: THRESHOLD
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 082 — video-observer ready');
  } catch (e) {}

})();