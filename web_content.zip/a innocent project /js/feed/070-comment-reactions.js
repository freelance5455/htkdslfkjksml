/* ============================================================
 * FEATURE:        Comment Reactions (Helpers)
 * FEATURE NUMBER: 070
 * FILE:           js/feed/070-comment-reactions.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Extracts the six-emoji comment-reaction logic that lives
 *   inline inside feature 067 (post-split) into a set of
 *   reusable, guarded helpers so the same flow can be shared
 *   with any future comment surface (post-split, legacy
 *   overlay, reel comments, story replies, chat replies).
 *
 *   In the original single-file build, the flow was:
 *     • a live listener on commentReactions/{pid}
 *     • openCommentReactionPicker(pid, cid)
 *       → renders the six emoji buttons into #rxPicker
 *     • toggleCommentReaction(pid, cid, emoji)
 *       → toggles the reaction, notifies the comment author,
 *         updates local state, repaints the affected row
 *     • a "counts" helper that folds the raw map into
 *       { emoji: count } and identifies the current user's
 *       emoji so the chip can be highlighted.
 *
 *   This module provides:
 *
 *     • buildCounts(map)             — { emoji: count }
 *     • myEmojiFromMap(map)          — the current user's emoji
 *     • countChipHTML(cid, emoji, n, isMine)
 *     • buildPickerHTML(map)         — the picker grid markup
 *     • buildReactionRowHTML(cid, map)
 *     • attachReactionsListener(pid) — live listener on
 *                                      commentReactions/{pid}
 *     • detachReactionsListener()
 *     • getMap()                     — live local map
 *     • toggle(pid, cid, emoji, opts) — write path (set /
 *                                       remove + notify)
 *
 *   Feature 067 continues to own its own inline version for
 *   its specific DOM surface (so we do not touch shipped code).
 *   This module is purely additive and can be adopted later by
 *   refactoring 067 to call SaikoCommentReactions helpers.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     • splitCommentReactions (module-scoped)
 *     • the commentReactions/{pid} listener in loadSplitComments
 *     • openCommentReactionPicker()
 *     • toggleCommentReaction()
 *     • the inline "counts" reducer used by commentHTML2 +
 *       paintCmtRxRow
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - pushNotification       js/notifications/106-push-notif.js
 *                            (safely-called)
 *   - openOverlay / closeOverlay
 *                            js/nav/038-overlay-system.js
 *                            (safely-called)
 *   - toast                  js/nav/042-toast.js (safely-called)
 *   - t / now                helpers
 *
 * DOM ELEMENTS USED:
 *   #rxPicker, #ovReactions  (shared with features 065 / 067)
 *
 * FIREBASE PATHS:
 *   commentReactions/{pid}                 (read + listen)
 *   commentReactions/{pid}/{cid}/{uid}     (set / remove)
 *   comments/{pid}/{cid}                   (read for
 *                                            notification)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoCommentReactions = {
 *     RX,
 *     buildCounts, myEmojiFromMap,
 *     countChipHTML, buildPickerHTML, buildReactionRowHTML,
 *     attachListener, detachListener, getMap,
 *     openPicker, toggle, remove,
 *     isMine, getMyEmoji
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS — same six emojis, same order, everywhere.
   * ============================================================ */
  var RX = ['❤️', '😂', '😮', '😢', '😡', '👍'];
  var PICKER_Z = '130';

  /* ============================================================
   * STATE — per-post reaction map, exposed on window so feature
   * 067 (and others) can read it without going through a getter
   * when they prefer.
   * ============================================================ */
  var listenerRef = null;
  var listenerCb  = null;

  /* Currently watched post id — kept so attach/detach can be
   * called repeatedly without leaking listeners. */
  var watchedPid = null;

  /* Live map: { cid: { uid: {type, at} | '<emoji>' } } */
  window.commentReactionsMap = window.commentReactionsMap || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[comment-reactions] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * NORMALISATION
   * ============================================================
   * Older builds stored a bare string ('❤️'); newer builds
   * store { type, at }. Both shapes are accepted everywhere.
   * ---------------------------------------------------------- */
  function typeOf(v) {
    if (v == null) return null;
    if (typeof v === 'string') return v;
    return v.type || null;
  }

  /* ============================================================
   * PURE REDUCERS
   * ============================================================ */

  /* buildCounts(map) → { emoji: count }
   * map is the per-comment portion of the reaction map:
   *   { uidA: '❤️', uidB: {type:'😂', at:…} }
   * ---------------------------------------------------------- */
  function buildCounts(map) {
    var counts = {};
    if (!map || typeof map !== 'object') return counts;
    var uids = Object.keys(map);
    for (var i = 0; i < uids.length; i++) {
      var t = typeOf(map[uids[i]]);
      if (t) counts[t] = (counts[t] || 0) + 1;
    }
    return counts;
  }

  /* myEmojiFromMap(map) → the current user's emoji, or null */
  function myEmojiFromMap(map) {
    var uid = getMyUid();
    if (!uid || !map) return null;
    return typeOf(map[uid]);
  }

  /* ============================================================
   * MARKUP BUILDERS
   * ============================================================ */

  /* countChipHTML(cid, emoji, n, isMine) */
  function countChipHTML(cid, emoji, n, isMine) {
    return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" ' +
             'data-crx="' + esc(emoji) + '" data-cid="' + esc(cid) + '">' +
             esc(emoji) + ' ' + Number(n || 0) +
           '</span>';
  }

  /* buildReactionRowHTML(cid, map) → the full chip row or '' */
  function buildReactionRowHTML(cid, map) {
    var counts = buildCounts(map);
    var keys = Object.keys(counts);
    if (!keys.length) return '';

    var mineType = myEmojiFromMap(map);
    return '<div class="cmt-rx-row" data-cid="' + esc(cid) + '">' +
      keys.map(function (rx) {
        return countChipHTML(cid, rx, counts[rx], mineType === rx);
      }).join('') +
    '</div>';
  }

  /* buildPickerHTML(map) → the six-button grid, current emoji
   * highlighted with the accent-soft background. */
  function buildPickerHTML(map) {
    var mineType = myEmojiFromMap(map);
    return RX.map(function (r) {
      var isCur = (mineType === r);
      return '<button data-crx-pick="' + r + '" style="' +
               (isCur ? 'background:var(--accent-soft);border-radius:.7rem' : '') +
             '">' + r + '</button>';
    }).join('');
  }

  /* ============================================================
   * LIVE LISTENER
   * ============================================================ */
  function attachListener(pid, onUpdate) {
    if (!pid) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    /* Detach any previous listener so we do not leak */
    detachListener();

    watchedPid = pid;
    listenerRef = fbDb.ref('commentReactions/' + pid);
    listenerCb = listenerRef.on('value', function (s) {
      window.commentReactionsMap = s.val() || {};
      if (typeof onUpdate === 'function') {
        try { onUpdate(window.commentReactionsMap); } catch (e) {}
      }
    });
    return true;
  }

  function detachListener() {
    if (listenerRef && listenerCb) {
      try { listenerRef.off('value', listenerCb); } catch (e) {}
    }
    listenerRef = null;
    listenerCb = null;
    watchedPid = null;
  }

  function getMap() { return window.commentReactionsMap; }

  /* ============================================================
   * PICKER
   * ============================================================
   * Preserved 1:1 from the original openCommentReactionPicker():
   *   • renders buttons into #rxPicker
   *   • opens #ovReactions with inline z-index bump
   *   • each button click → closeOverlay + toggle
   * ---------------------------------------------------------- */
  function openPicker(pid, cid) {
    if (!pid || !cid) return false;

    var picker = document.getElementById('rxPicker');
    if (!picker) return false;

    var map = (window.commentReactionsMap[cid]) || {};
    picker.innerHTML = buildPickerHTML(map);

    var ov = document.getElementById('ovReactions');
    if (ov) {
      ov.style.zIndex = PICKER_Z;
      ov.classList.add('open');
    }
    safeCall('pushOverlayState');

    var btns = picker.querySelectorAll('[data-crx-pick]');
    for (var i = 0; i < btns.length; i++) {
      (function (b) {
        b.addEventListener('click', async function () {
          safeCall('closeOverlay', ['ovReactions']);
          await toggle(pid, cid, b.getAttribute('data-crx-pick'));
        });
      })(btns[i]);
    }
    return true;
  }

  /* ============================================================
   * TOGGLE
   * ============================================================
   * Preserved 1:1 from the original toggleCommentReaction():
   *   • ref = commentReactions/{pid}/{cid}/{myUid}
   *   • curType === emoji → remove
   *   • else              → set({type, at})
   *                          + notify the comment author
   *                            (skip if self)
   *   • always update local map optimistically
   *   • call onUpdate so the caller can repaint
   *
   * opts.onUpdate(map) — optional per-call repaint callback
   * ---------------------------------------------------------- */
  async function toggle(pid, cid, emoji, opts) {
    if (!pid || !cid || !emoji) return false;
    var uid = getMyUid();
    if (!uid) return false;

    var fbDb = getDB();
    if (!fbDb) return false;

    opts = opts || {};

    try {
      var ref = fbDb.ref('commentReactions/' + pid + '/' + cid + '/' + uid);
      var snap = await ref.get();
      var curT = typeOf(snap.val());

      if (curT === emoji) {
        /* === Toggle off =============================== */
        await ref.remove();
      } else {
        /* === Set / replace =========================== */
        await ref.set({ type: emoji, at: timeNow() });

        /* Notify comment author (skip if self) ------- */
        try {
          var cs = await fbDb.ref('comments/' + pid + '/' + cid).get();
          var c = cs.val();
          if (c && c.uid && c.uid !== uid) {
            var me = getMyProfile();
            safeCall('pushNotification', [c.uid, {
              type: 'reaction',
              fromUid: uid,
              fromName: (me && me.name) || 'User',
              fromPhoto: (me && me.photo) || '',
              text: emoji + ' ' + T('reacted_to'),
              postId: pid,
              commentId: cid,
              createdAt: timeNow()
            }]);
          }
        } catch (e) {}
      }

      /* Optimistic local update ---------------------- */
      if (!window.commentReactionsMap[cid]) window.commentReactionsMap[cid] = {};
      if (curT === emoji) {
        delete window.commentReactionsMap[cid][uid];
      } else {
        window.commentReactionsMap[cid][uid] = { type: emoji, at: timeNow() };
      }

      /* Caller-controlled repaint -------------------- */
      if (typeof opts.onUpdate === 'function') {
        try { opts.onUpdate(window.commentReactionsMap); } catch (e) {}
      }

      return true;
    } catch (err) {
      safeCall('toast', [(err && err.message) ? err.message : T('error'), 'err']);
      return false;
    }
  }

  /* Convenience — clear the current user's reaction on a
   * comment if any. */
  async function remove(pid, cid, opts) {
    var map = window.commentReactionsMap[cid] || {};
    var mine = myEmojiFromMap(map);
    if (!mine) return false;
    return toggle(pid, cid, mine, opts);
  }

  /* ============================================================
   * CONVENIENCE PREDICATES
   * ============================================================ */
  function isMine(cid, emoji) {
    var map = window.commentReactionsMap[cid] || {};
    return myEmojiFromMap(map) === emoji;
  }
  function getMyEmoji(cid) {
    var map = window.commentReactionsMap[cid] || {};
    return myEmojiFromMap(map);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoCommentReactions = {
    RX: RX.slice(),

    /* reducers / markup */
    buildCounts: buildCounts,
    myEmojiFromMap: myEmojiFromMap,
    countChipHTML: countChipHTML,
    buildReactionRowHTML: buildReactionRowHTML,
    buildPickerHTML: buildPickerHTML,

    /* listener */
    attachListener: attachListener,
    detachListener: detachListener,
    getMap: getMap,

    /* actions */
    openPicker: openPicker,
    toggle: toggle,
    remove: remove,

    /* predicates */
    isMine: isMine,
    getMyEmoji: getMyEmoji
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 070 — comment-reactions helpers ready');
  } catch (e) {}

})();