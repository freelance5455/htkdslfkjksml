/* ============================================================
 * FEATURE:        Hashtag Extraction
 * FEATURE NUMBER: 079
 * FILE:           js/feed/079-hashtag-extract.js
 * ACTION:         REPLACE (Batch 9 — clean rewrite)
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * CONSTANTS
   * ---------------------------------------------------------- */
  var TAG_CHAR_CLASS =
    'A-Za-z0-9_' +
    '\\u00C0-\\u024F' +
    '\\u0900-\\u097F' +
    '\\u0600-\\u06FF' +
    '\\u4E00-\\u9FFF';

  var REGEX = new RegExp('#(' + TAG_CHAR_CLASS + ')+', 'g');

  /* ----------------------------------------------------------
   * EXTRACT — frequency map of hashtags
   * ---------------------------------------------------------- */
  function extract(text) {
    var out = {};
    if (!text) return out;

    var str = String(text);
    var m = str.match(REGEX) || [];

    for (var i = 0; i < m.length; i++) {
      var x = m[i];
      var k = x.slice(1).toLowerCase();
      if (k) out[k] = (out[k] || 0) + 1;
    }
    return out;
  }

  function extractList(text) {
    var map = extract(text);
    return Object.keys(map);
  }

  function extractUnique(text) {
    var seen = {};
    var order = [];
    if (!text) return order;

    var str = String(text);
    var m = str.match(REGEX) || [];

    for (var i = 0; i < m.length; i++) {
      var original = m[i].slice(1);
      var key = original.toLowerCase();
      if (!key || seen[key]) continue;
      seen[key] = true;
      order.push(original);
    }
    return order;
  }

  function hasHashtag(text) {
    if (!text) return false;
    try {
      return /#([A-Za-z0-9_\u00C0-\u024F\u0900-\u097F\u0600-\u06FF\u4E00-\u9FFF]+)/.test(String(text));
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.extractTags = extract;

  window.SaikoHashtagExtract = {
    extract: extract,
    extractList: extractList,
    extractUnique: extractUnique,
    hasHashtag: hasHashtag,
    REGEX: REGEX,
    TAG_CHAR_CLASS: TAG_CHAR_CLASS
  };

  try {
    console.debug('[boot] feature 079 — hashtag-extract ready');
  } catch (e) {}

})();