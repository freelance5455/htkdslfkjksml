/* ============================================================
 * FEATURE:        Post Reactions (6-emoji Picker)
 * FEATURE NUMBER: 065
 * FILE:           js/feed/065-post-reactions.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the six-emoji reaction system for posts:
 *
 *     ❤️  😂  😮  😢  😡  👍
 *
 *   Responsibilities:
 *     1. Live listener on `postReactions` (whole tree) →
 *        window.postReactionsMap
 *     2. Helpers
 *          myReactionOn(pid)   → the current user's emoji on pid
 *          countReactions(pid) → total distinct reactors on pid
 *     3. Picker
 *          openPostReactionPicker(pid)
 *            → renders the six buttons into #rxPicker and
 *              opens the #ovReactions overlay
 *     4. Write path
 *          setPostReaction(pid, emoji)
 *            → toggles the reaction, removes any plain "like"
 *              on the same post (a reaction supersedes a like),
 *              notifies the author, awards XP + daily stat
 *
 *   Feature 064 (like) is the sibling of this module: a "like"
 *   removes any reaction on the same post, and a "reaction"
 *   removes any like — the two are mutually exclusive per
 *   user per post.
 *
 *   ORIGINAL STATE SHAPE:
 *     postReactions/{pid}/{uid} = { type: '<emoji>', at: now() }
 *   Older builds stored a bare string. `myReactionOn` and the
 *   picker's selected-state check accept both shapes.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §13 ADMIN → startPostReactionsListener(),
 *                       postReactionsRef/Cb, postReactionsMap
 *   Section §13 ADMIN → openPostReactionPicker(pid),
 *                       myReactionOn(pid), countReactions(pid),
 *                       setPostReaction(pid, emoji)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                    js/core/firebase-init.js
 *   - myUid / myProfile     js/auth/004-auth-state.js
 *   - window.postsCache     js/feed/051-feed-render.js
 *   - paintPostCounts       js/feed/051-feed-render.js
 *   - openOverlay / closeOverlay / pushOverlayState
 *                              js/nav/038-overlay-system.js
 *   - pushNotification      js/notifications/106-push-notif.js
 *   - awardXp / bumpDaily   features 025-area / daily stats
 *   - toast                 js/nav/042-toast.js
 *   - t / now               helpers
 *
 * DOM ELEMENTS USED:
 *   #ovReactions  (overlay container)
 *   #rxPicker     (button grid inside it)
 *
 * FIREBASE PATHS:
 *   postReactions/{pid}              (read + listen)
 *   postReactions/{pid}/{uid}        (set / remove)
 *   postLikes/{pid}/{uid}            (remove — reaction
 *                                     supersedes like)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.postReactionsMap                (live map)
 *   window.startPostReactionsListener      (original name)
 *   window.detachPostReactions             (additive)
 *   window.myReactionOn                    (original name)
 *   window.countReactions                  (original name)
 *   window.openPostReactionPicker          (original name)
 *   window.setPostReaction                 (original name)
 *   window.SaikoPostReactions = {
 *     RX, start, detach, open, set, remove,
 *     myReactionOn, countReactions, getMap,
 *     isMyReaction
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * CONSTANTS
   * ---------------------------------------------------------- */
  var RX = ['❤️', '😂', '😮', '😢', '😡', '👍'];
  var PICKER_Z = '130';

  /* ----------------------------------------------------------
   * STATE
   * ---------------------------------------------------------- */
  var postReactionsRef = null;
  var postReactionsCb  = null;
  var postReactionPid  = null;   /* last-opened picker target */

  /* Live map — exposed on window (feature 051 reads it in
   * countLikes via window.postReactionsMap). */
  window.postReactionsMap = window.postReactionsMap || {};

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-reactions] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findPost(postId) {
    if (!postId) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === postId) return p;
        }
      }
    } catch (e) {}
    return null;
  }

  /* Normalise a stored reaction value (string OR {type}) */
  function reactionTypeOf(v) {
    if (v == null) return null;
    if (typeof v === 'string') return v;
    return v.type || null;
  }

  /* ----------------------------------------------------------
   * MY REACTION
   * Preserved 1:1 from original myReactionOn(pid).
   * ---------------------------------------------------------- */
  function myReactionOn(pid) {
    var uid = getMyUid();
    if (!pid || !uid) return null;
    var o = window.postReactionsMap[pid];
    if (!o || !o[uid]) return null;
    return reactionTypeOf(o[uid]);
  }

  /* ----------------------------------------------------------
   * COUNT
   * Preserved 1:1 from original countReactions(pid).
   * ---------------------------------------------------------- */
  function countReactions(pid) {
    var o = window.postReactionsMap[pid];
    return o ? Object.keys(o).length : 0;
  }

  /* ----------------------------------------------------------
   * isMyReaction(pid, emoji)
   * Convenience — true when the current user's reaction on pid
   * is exactly this emoji.
   * ---------------------------------------------------------- */
  function isMyReaction(pid, emoji) {
    return myReactionOn(pid) === emoji;
  }

  /* ----------------------------------------------------------
   * START — attach the live listener on the whole
   * postReactions tree, matching the original source.
   * ---------------------------------------------------------- */
  function start() {
    if (postReactionsRef && postReactionsCb) return true;
    var fbDb = getDB();
    if (!fbDb) return false;

    postReactionsRef = fbDb.ref('postReactions');
    postReactionsCb = postReactionsRef.on('value', function (s) {
      window.postReactionsMap = s.val() || {};
      safeCall('paintPostCounts');
    });
    return true;
  }

  /* ----------------------------------------------------------
   * DETACH — detach the listener + reset local map.
   * (In the original source this was folded into
   *  detachAdminSync; we expose it as its own function so the
   *  boot teardown can call it cleanly.)
   * ---------------------------------------------------------- */
  function detach() {
    if (postReactionsRef && postReactionsCb) {
      try { postReactionsRef.off('value', postReactionsCb); } catch (e) {}
    }
    postReactionsRef = null;
    postReactionsCb = null;
    window.postReactionsMap = {};
    return true;
  }

  /* ----------------------------------------------------------
   * OPEN PICKER
   * Preserved 1:1 from original openPostReactionPicker(pid):
   *   • renders the six emoji buttons into #rxPicker
   *   • highlights the current user's existing reaction
   *   • opens #ovReactions with an inline z-index bump
   *   • pushes an overlay history state (feature 038)
   *   • each button click → closeOverlay + setPostReaction
   * ---------------------------------------------------------- */
  function open(pid) {
    if (!pid) return false;
    postReactionPid = pid;

    var picker = document.getElementById('rxPicker');
    if (!picker) return false;

    var cur = myReactionOn(pid);

    picker.innerHTML = RX.map(function (r) {
      var isCur = (cur === r);
      return '<button data-prx="' + r + '" style="' +
               (isCur ? 'background:var(--accent-soft);border-radius:.7rem' : '') +
             '">' + r + '</button>';
    }).join('');

    var ov = document.getElementById('ovReactions');
    if (ov) {
      ov.classList.add('open');
      ov.style.zIndex = PICKER_Z;
    }
    safeCall('pushOverlayState');

    picker.querySelectorAll('[data-prx]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var r = b.getAttribute('data-prx');
        safeCall('closeOverlay', ['ovReactions']);
        await set(pid, r);
      });
    });

    return true;
  }

  /* ----------------------------------------------------------
   * SET REACTION
   * Preserved 1:1 from original setPostReaction(pid, emoji):
   *
   *   curType === emoji → remove reaction + remove any like
   *   else              → set { type, at } + remove any like
   *                       + notify author (if not me)
   *                       + awardXp('like_given', 1)
   *                       + bumpDaily('like', 1)
   *   Always → paintPostCounts()
   *   Error  → toast err.message || t('error')
   * ---------------------------------------------------------- */
  async function set(pid, emoji) {
    if (!pid || !emoji) return false;
    var uid = getMyUid();
    if (!uid) return false;

    var fbDb = getDB();
    if (!fbDb) return false;

    var ref = fbDb.ref('postReactions/' + pid + '/' + uid);

    try {
      var snap = await ref.get();
      var curType = reactionTypeOf(snap.val());

      if (curType === emoji) {
        /* === TOGGLE OFF ================================== */
        await ref.remove();
        try {
          await fbDb.ref('postLikes/' + pid + '/' + uid).remove();
        } catch (e) {}
      } else {
        /* === SET / REPLACE ============================== */
        await ref.set({ type: emoji, at: timeNow() });

        /* A reaction supersedes any plain like on the same
         * post by the same user. */
        try {
          await fbDb.ref('postLikes/' + pid + '/' + uid).remove();
        } catch (e) {}

        /* Notify the author (skip on self) --------------- */
        var post = findPost(pid);
        if (post && post.uid && post.uid !== uid) {
          var me = getMyProfile();
          safeCall('pushNotification', [post.uid, {
            type: 'reaction',
            fromUid: uid,
            fromName: (me && me.name) || 'User',
            fromPhoto: (me && me.photo) || '',
            text: emoji + ' ' + T('reacted_to'),
            postId: pid,
            createdAt: timeNow()
          }]);
        }

        /* XP + daily stat -------------------------------- */
        safeCall('awardXp', ['like_given', 1]);
        safeCall('bumpDaily', ['like', 1]);
      }

      /* Refresh every rendered card's like/reaction state -- */
      safeCall('paintPostCounts');

      /* Notify subscribers -------------------------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:reaction-changed', {
          detail: { postId: pid, emoji: emoji, active: curType !== emoji }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * REMOVE REACTION (additive helper)
   * Clears the current user's reaction on pid if any.
   * ---------------------------------------------------------- */
  async function remove(pid) {
    if (!pid) return false;
    var uid = getMyUid();
    if (!uid) return false;
    var cur = myReactionOn(pid);
    if (!cur) return false;
    return set(pid, cur);
  }

  /* ----------------------------------------------------------
   * GET MAP (additive)
   * ---------------------------------------------------------- */
  function getMap() { return window.postReactionsMap; }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original globals — preserved so feature 051 (feed render),
   * feature 055 (post-card), feature 067 (refreshSplitPost),
   * feature 088 (openPostMenu), and any other caller keep
   * working unchanged. */
  window.startPostReactionsListener = start;
  window.detachPostReactions        = detach;
  window.myReactionOn               = myReactionOn;
  window.countReactions             = countReactions;
  window.openPostReactionPicker     = open;
  window.setPostReaction            = set;

  window.SaikoPostReactions = {
    RX: RX.slice(),
    start: start,
    detach: detach,
    open: open,
    set: set,
    remove: remove,
    myReactionOn: myReactionOn,
    countReactions: countReactions,
    isMyReaction: isMyReaction,
    getMap: getMap
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 065 — post-reactions ready');
  } catch (e) {}

})();