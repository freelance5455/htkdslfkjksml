/* ============================================================
 * MISSING FILE 6/8 — TRENDING PAGE
 * FILE:   js/feed/034-trending.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * Provides openTrending() — the feed "🔥 Trending" button opens
 * #ovTrending with:
 *   • Trending hashtags (top 20)
 *   • Trending posts (top 5 by like+comment)
 *   • Top users (top 5 by XP)
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(n, f) { try { return window.svgIcon(n, f) || ''; } catch (e) { return ''; } }
  function avatarHTML(url, name, cls, uid) {
    try { return window.avatarHTML(url, name, cls, uid); } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function getCache(name) {
    try { return Array.isArray(window[name]) ? window[name] : []; }
    catch (e) { return []; }
  }
  function countLikes(pid) {
    try { return window.countLikes ? window.countLikes(pid) : 0; }
    catch (e) { return 0; }
  }
  function countComments(pid) {
    try { return window.countComments ? window.countComments(pid) : 0; }
    catch (e) { return 0; }
  }
  function isVisiblePost(p) {
    try { return window.isVisiblePost ? window.isVisiblePost(p) : !!p; }
    catch (e) { return !!p; }
  }
  function extractTags(text) {
    try { return window.extractTags ? window.extractTags(text) : {}; }
    catch (e) { return {}; }
  }

  /* ============ TRENDING TAGS ============ */
  function computeTrendingTags(limit) {
    var posts = getCache('postsCache');
    var counts = {};
    posts.forEach(function (p) {
      if (!p || p.suspended) return;
      var tags = extractTags(p.text);
      Object.keys(tags).forEach(function (k) {
        counts[k] = (counts[k] || 0) + tags[k];
      });
    });
    var list = Object.keys(counts).map(function (k) {
      return { tag: k, count: counts[k] };
    }).sort(function (a, b) { return b.count - a.count; });
    return list.slice(0, limit || 20);
  }

  /* ============ TRENDING POSTS ============ */
  function computeTrendingPosts(limit) {
    var posts = getCache('postsCache').filter(isVisiblePost);
    var ranked = posts.map(function (p) {
      return {
        p: p,
        score: countLikes(p.id) * 2 + countComments(p.id) * 3
      };
    }).sort(function (a, b) { return b.score - a.score; });
    return ranked.slice(0, limit || 5).map(function (x) { return x.p; });
  }

  /* ============ TOP USERS ============ */
  function computeTopUsers(limit) {
    var users = getCache('allUsersCache').slice();
    users.sort(function (a, b) { return (b.xp || 0) - (a.xp || 0); });
    return users.slice(0, limit || 5);
  }

  /* ============ LEVEL HELPER ============ */
  function levelFromXp(xp) {
    try { return window.levelFromXp ? window.levelFromXp(xp) : 1; }
    catch (e) { return 1; }
  }

  /* ============ OPEN TRENDING ============ */
  function openTrending() {
    safeCall('openOverlay', ['ovTrending']);

    var body = qs('#trendingBody');
    if (!body) return;

    var tags = computeTrendingTags(20);
    var topPosts = computeTrendingPosts(5);
    var topUsers = computeTopUsers(5);

    body.innerHTML =
      '<div class="sec-title">🔥 Trending Hashtags</div>' +
      (tags.length
        ? tags.map(function (x) {
            return '<div class="trend-item" data-tagopen="' + esc(x.tag) + '">' +
              '<span class="ic" style="color:var(--accent)">' + svgIcon('fire') + '</span>' +
              '<div class="grow">' +
                '<div class="name">#' + esc(x.tag) + '</div>' +
                '<div class="mini">' + x.count + ' posts</div>' +
              '</div>' +
              '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
            '</div>';
          }).join('')
        : '<div class="mini" style="padding:.4rem .2rem">No trending hashtags yet</div>') +

      '<div class="sec-title">📈 Trending Posts</div>' +
      (topPosts.length
        ? topPosts.map(function (p) {
            try { if (typeof window.postHTML === 'function') return window.postHTML(p); }
            catch (e) {}
            return '';
          }).join('')
        : '<div class="mini" style="padding:.4rem .2rem">No posts yet</div>') +

      '<div class="sec-title">⭐ Top Users</div>' +
      (topUsers.length
        ? topUsers.map(function (u) {
            return '<div class="user-card" data-tuid="' + esc(u.uid) + '">' +
              avatarHTML(u.photo, u.name, 'av-40', u.uid) +
              '<div class="grow">' +
                '<div class="name">' + esc(u.name || 'User') + '</div>' +
                '<div class="mini">Lv ' + levelFromXp(u.xp) + ' · ' + esc(String(u.xp || 0)) + ' XP</div>' +
              '</div>' +
            '</div>';
          }).join('')
        : '<div class="mini" style="padding:.4rem .2rem">No users yet</div>');

    /* Wire hashtags ------------------------------------ */
    qsa('[data-tagopen]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovTrending']);
        safeCall('openHashtag', [n.getAttribute('data-tagopen')]);
      });
    });

    /* Wire user cards ---------------------------------- */
    qsa('[data-tuid]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovTrending']);
        safeCall('openUserProfile', [n.getAttribute('data-tuid')]);
      });
    });

    /* Wire post cards ---------------------------------- */
    safeCall('wirePostInteractions', [body]);
    safeCall('paintPostCounts');
    safeCall('observePostVideos', [body]);
  }

  /* ============ EXPORTS ============ */
  window.openTrending         = openTrending;
  window.computeTrendingTags  = computeTrendingTags;
  window.computeTrendingPosts = computeTrendingPosts;
  window.computeTopUsers      = computeTopUsers;

  window.SaikoTrending = {
    open: openTrending,
    tags: computeTrendingTags,
    posts: computeTrendingPosts,
    users: computeTopUsers
  };

  try { console.debug('[boot] trending ready'); } catch (e) {}
})();