/* ============================================================
 * FEATURE:        Pull-to-Refresh
 * FEATURE NUMBER: 083b
 * FILE:           js/feed/083b-pull-to-refresh.js
 * ACTION:         REPLACE (v2 — shuffle posts + stories on refresh)
 * ============================================================ */

(function () {
  'use strict';

  var THRESHOLD     = 80;
  var IND_TOP_MAX   = 60;
  var SCROLL_TOP    = 2;
  var NEAR_BOTTOM   = 40;
  var FEED_BATCH    = 10;

  var indEl      = null;
  var startY     = 0;
  var pulling    = false;
  var pullActive = false;
  var bound      = false;

  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[pull-to-refresh] safeCall:', name, e); }
    return undefined;
  }

  function ensureIndicator() {
    if (indEl && indEl.parentNode) return indEl;

    indEl = qs('.pull-ind');
    if (!indEl) {
      indEl = document.createElement('div');
      indEl.className = 'pull-ind';
      indEl.textContent = T('pull_refresh');
      document.body.appendChild(indEl);
    }
    return indEl;
  }

  function anyOverlayOpen() {
    if (qs('.overlay.open')) return true;

    var extraIds = ['ovReels', 'ovReelSplit', 'ovSplitComments', 'ovStoryViewer'];
    for (var i = 0; i < extraIds.length; i++) {
      var el = document.getElementById(extraIds[i]);
      if (el && el.classList.contains('open')) return true;
    }
    return false;
  }

  function onTouchStart(e) {
    if (!e.touches || !e.touches.length) return;

    var atTop      = window.scrollY <= SCROLL_TOP;
    var nearBottom = (window.scrollY + window.innerHeight) >= (document.body.scrollHeight - NEAR_BOTTOM);

    if (atTop && !nearBottom && !pulling && !anyOverlayOpen()) {
      startY = e.touches[0].clientY;
      pullActive = true;
    } else {
      pullActive = false;
    }
  }

  function onTouchMove(e) {
    if (!pullActive) return;

    if (window.scrollY > SCROLL_TOP) {
      pullActive = false;
      var ind = ensureIndicator();
      ind.classList.remove('show');
      return;
    }

    var dy = e.touches[0].clientY - startY;
    if (dy > THRESHOLD) {
      pulling = true;
      var ind2 = ensureIndicator();
      ind2.classList.add('show');
      ind2.style.top = Math.min(dy / 3, IND_TOP_MAX) + 'px';
    }
  }

  function onTouchEnd() {
    if (pulling) {
      pulling = false;
      var ind = ensureIndicator();
      ind.classList.remove('show');
      ind.style.top = '.2rem';
      trigger();
    }
    startY = 0;
    pullActive = false;
  }

  function trigger() {
    var nav = (typeof window.currentNav === 'string') ? window.currentNav : 'home';

    if (nav === 'home') {
      /* 1) Bump feed shuffle seed → full random shuffle */
      try {
        if (window.SaikoFeedRender &&
            typeof window.SaikoFeedRender.bumpRotationSeed === 'function') {
          window.SaikoFeedRender.bumpRotationSeed();
        }
        if (window.SaikoFeedRender &&
            typeof window.SaikoFeedRender.setVisibleCount === 'function') {
          window.SaikoFeedRender.setVisibleCount(FEED_BATCH);
        }
      } catch (e) {}

      /* 2) Bump story shuffle seed → random story order */
      safeCall('bumpStoryShuffle');

      /* 3) Re-render both */
      safeCall('renderFeed', [false]);
      safeCall('renderStoriesBar');

    } else if (nav === 'notifications') {
      safeCall('renderNotifications');

    } else if (nav === 'inbox') {
      safeCall('renderInbox');
    }

    try {
      window.dispatchEvent(new CustomEvent('saiko:pull-to-refresh', {
        detail: { nav: nav }
      }));
    } catch (e) {}
  }

  function bind() {
    if (bound) return true;
    ensureIndicator();

    document.addEventListener('touchstart',  onTouchStart, { passive: true });
    document.addEventListener('touchmove',   onTouchMove,  { passive: true });
    document.addEventListener('touchend',    onTouchEnd,   { passive: true });
    document.addEventListener('touchcancel', onTouchEnd,   { passive: true });

    bound = true;
    return true;
  }

  function unbind() {
    if (!bound) return false;

    document.removeEventListener('touchstart',  onTouchStart);
    document.removeEventListener('touchmove',   onTouchMove);
    document.removeEventListener('touchend',    onTouchEnd);
    document.removeEventListener('touchcancel', onTouchEnd);

    pulling = false;
    pullActive = false;
    startY = 0;

    if (indEl) indEl.classList.remove('show');

    bound = false;
    return true;
  }

  function isBound() { return bound; }

  window.SaikoPullToRefresh = {
    bind: bind,
    unbind: unbind,
    trigger: trigger,
    isBound: isBound,
    THRESHOLD: THRESHOLD
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  try {
    console.debug('[boot] feature 083b — pull-to-refresh ready (v2 — full shuffle)');
  } catch (e) {}

})();