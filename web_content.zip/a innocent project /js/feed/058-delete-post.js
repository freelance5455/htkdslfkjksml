/* ============================================================
 * FEATURE:        Delete Post
 * FEATURE NUMBER: 058
 * FILE:           js/feed/058-delete-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused entry point for deleting a post the current user
 *   authored. Performs the exact cascade the original
 *   inlined into openPostMenu()'s "delete" case:
 *
 *     posts/{pid}                remove
 *     postLikes/{pid}            remove
 *     postReactions/{pid}        remove
 *     comments/{pid}             remove
 *     commentReactions/{pid}     remove
 *
 *   Each remove is best-effort — a failure on one node does
 *   NOT abort the rest of the cascade. The one exception is
 *   the primary `posts/{pid}` remove, whose failure surfaces
 *   as a toast so the user knows the delete did not stick.
 *
 *   Public function:
 *     window.deletePost(postId)  → Promise<boolean>
 *
 *   Behaviour preserved 1:1 from the original source:
 *     • showConfirm(t('delete_post'), t('are_you_sure'))
 *     • abort silently if the user cancels
 *     • remove the five Firebase nodes in the same order
 *     • toast the error if `posts/{pid}` removal fails
 *
 *   The post options menu (feature 088) will call
 *   window.deletePost(pid) instead of inlining this logic.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu() → case 'delete'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - t(key)                 js/nav/046-i18n.js
 *   - confirmDialog          js/nav/043-confirm-dialog.js
 *   - toast                  js/nav/042-toast.js
 *
 * DOM ELEMENTS USED:
 *   none — pure Firebase cascade.
 *
 * FIREBASE PATHS (all removals):
 *   posts/{pid}                (primary)
 *   postLikes/{pid}
 *   postReactions/{pid}
 *   comments/{pid}
 *   commentReactions/{pid}
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.deletePost
 *   window.SaikoDeletePost = {
 *     deletePost,
 *     cascadeRemove,
 *     isOwner
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') return window.confirmDialog(title, text);
    } catch (e) {}
    /* Fallback — never block the flow if confirmDialog is
     * missing during early boot. */
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function findPost(postId) {
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === postId) return p;
        }
      }
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * isOwner(postId)
   * Convenience guard. Returns true only when the post exists
   * in the cache AND the current user authored it.
   * ---------------------------------------------------------- */
  function isOwner(postId) {
    var post = findPost(postId);
    var uid = getMyUid();
    return !!(post && uid && post.uid === uid);
  }

  /* ----------------------------------------------------------
   * cascadeRemove(pid)
   * The five best-effort removes, in the exact order of the
   * original source. Each call is independently `.catch()`ed
   * so a failure on any secondary node does not stop the rest.
   *
   * If the PRIMARY `posts/{pid}` remove fails, the error is
   * re-thrown after the cascade completes, so the caller can
   * surface a toast without losing the secondary cleanups.
   * ---------------------------------------------------------- */
  async function cascadeRemove(pid) {
    var fbDb = getDB();
    if (!fbDb || !pid) return;

    var primaryError = null;

    /* 1) Primary: posts/{pid} ----------------------------- */
    try {
      await fbDb.ref('posts/' + pid).remove();
    } catch (err) {
      primaryError = err;
    }

    /* 2) postLikes/{pid} ---------------------------------- */
    try { await fbDb.ref('postLikes/' + pid).remove(); } catch (e) {}

    /* 3) postReactions/{pid} ------------------------------ */
    try { await fbDb.ref('postReactions/' + pid).remove(); } catch (e) {}

    /* 4) comments/{pid} ----------------------------------- */
    try { await fbDb.ref('comments/' + pid).remove(); } catch (e) {}

    /* 5) commentReactions/{pid} --------------------------- */
    try { await fbDb.ref('commentReactions/' + pid).remove(); } catch (e) {}

    if (primaryError) throw primaryError;
  }

  /* ----------------------------------------------------------
   * deletePost(postId)
   * Preserved 1:1 from the original `case 'delete'` handler.
   *
   * Returns Promise<boolean>:
   *   true  — the cascade completed (user confirmed)
   *   false — the user cancelled, or the primary remove failed
   * ---------------------------------------------------------- */
  async function deletePost(postId) {
    if (!postId) return false;

    /* 1) Confirm ----------------------------------------- */
    var ok = await askConfirm(T('delete_post'), T('are_you_sure'));
    if (!ok) return false;

    /* 2) Cascade remove ---------------------------------- */
    try {
      await cascadeRemove(postId);
    } catch (err) {
      /* Original surfaced the error via a toast but did not
       * abort the (already-completed) secondary removes. */
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }

    /* 3) Notify subscribers ------------------------------ */
    try {
      window.dispatchEvent(new CustomEvent('saiko:post-deleted', {
        detail: { postId: postId }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.deletePost = deletePost;

  window.SaikoDeletePost = {
    deletePost: deletePost,
    cascadeRemove: cascadeRemove,
    isOwner: isOwner
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 058 — delete-post ready');
  } catch (e) {}

})();