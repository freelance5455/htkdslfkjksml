/* ============================================================
 * FEATURE:        Post Menu (Options Sheet)
 * FEATURE NUMBER: 088
 * FILE:           js/feed/088-post-menu.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The bottom-sheet action menu that appears when the user
 *   taps the "⋯" button on any post card (#msgMenuSheet, the
 *   same sheet used by chat message menus and the group member
 *   menu). Dynamically builds a list of actions based on
 *   whether the current user authored the post.
 *
 *   Action list (preserved 1:1 from the original):
 *
 *     OWNER:
 *       edit     → t('edit_post')
 *       pin      → t('pin_post')    | t('unpin_post')
 *       feature  → t('feature_post')| t('unfeature_post')
 *       delete   → t('delete_post')            (danger)
 *
 *     NON-OWNER:
 *       hide       → t('hide_post')
 *       muteauthor → t('mute_author') | t('unmute_author')
 *       report     → t('report')                (danger)
 *       block      → t('block')                 (danger)
 *
 *     ALWAYS:
 *       share            → t('share')
 *       save / unsave    → t('bookmark')  | t('unbookmark')
 *
 *   Every action is delegated to its own feature module via
 *   window.* globals, so this file stays a thin orchestrator:
 *
 *     edit        → SaikoEditPost.edit(pid)
 *     pin         → SaikoPinPost.toggle(pid)
 *     feature     → SaikoFeaturePost.toggle(pid)
 *     delete      → SaikoDeletePost.deletePost(pid)
 *     hide        → SaikoHidePost.hide(pid)
 *     muteauthor  → SaikoMuteAuthor.toggle(authorUid)
 *     report      → window.openReport('post', pid, null)
 *     block       → window.blockUser(authorUid)
 *     share       → SaikoSharePost.share(pid)
 *     save        → SaikoBookmark.toggle(pid)
 *
 *   The sheet closes (closeOverlay('ovMsgMenu')) before the
 *   chosen action runs — exactly as the original did.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu(pid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache       js/feed/051-feed-render.js
 *   - myUid / myProfile       js/auth/004-auth-state.js
 *   - t(key) / esc(str)       helpers
 *   - svgIcon(name)           js/nav/045-icon-system.js
 *   - openOverlay / closeOverlay
 *                             js/nav/038-overlay-system.js
 *   - feature modules 057–063, 084, and the block/report +
 *     profile modules — all safely-called
 *
 * DOM ELEMENTS USED:
 *   #ovMsgMenu      (overlay container)
 *   #msgMenuSheet   (sheet inside it — shared with other menus)
 *
 * FIREBASE PATHS:
 *   none directly — every write is delegated to its feature.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openPostMenu          (original name preserved)
 *   window.SaikoPostMenu = {
 *     open, close,
 *     buildItems,      // pure — items array for a post
 *     bind,
 *     ACTION_KEYS,
 *     ACTION_ICONS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var ACTION_ICONS = {
    edit:       'edit',
    pin:        'pin',
    unpin:      'unpin',
    feature:    'star',
    unfeature:  'star',
    delete:     'trash',
    hide:       'eyeOff',
    muteauthor: 'micOff',
    unmuteauthor: 'micOff',
    report:     'flag',
    block:      'block',
    share:      'share',
    save:       'bookmark',
    unsave:     'bookmark'
  };

  var ACTION_KEYS = Object.keys(ACTION_ICONS);

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { if (typeof window.svgIcon === 'function') return window.svgIcon(name, fill); } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-menu] safeCall:', name, e); }
    return undefined;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findPost(pid) {
    if (!pid) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === pid) return p;
        }
      }
    } catch (e) {}
    return null;
  }
  function isPinned(pid) {
    var me = getMyProfile();
    return !!(me && me.pinnedPosts && me.pinnedPosts[pid]);
  }
  function isFeatured(pid) {
    var me = getMyProfile();
    return !!(me && me.featuredPosts && me.featuredPosts[pid]);
  }
  function isSaved(pid) {
    try {
      if (typeof window.iSaved === 'function') return !!window.iSaved(pid);
    } catch (e) {}
    return !!(window.savedPosts && window.savedPosts[pid]);
  }
  function isMutedAuthor(uid) {
    try {
      if (typeof window.iMutedAuthor === 'function') return !!window.iMutedAuthor(uid);
    } catch (e) {}
    return !!(window.mutedAuthors && window.mutedAuthors[uid]);
  }

  /* ============================================================
   * BUILD ITEMS — pure
   * ============================================================
   * Preserved 1:1 from the original item-array construction:
   *   • Owner branch first, then non-owner branch
   *   • Shared items (share, save/unsave) appended last
   * Each item: { k, i, label, danger? }
   * ============================================================ */
  function buildItems(pid) {
    var post = findPost(pid);
    if (!post) return [];

    var me = getMyUid();
    var mine = (post.uid && me && post.uid === me);
    var items = [];

    if (mine) {
      items.push({ k: 'edit',    i: 'edit',  label: T('edit_post') });
      items.push({
        k: 'pin',
        i: 'pin',
        label: isPinned(pid) ? T('unpin_post') : T('pin_post')
      });
      items.push({
        k: 'feature',
        i: 'star',
        label: isFeatured(pid) ? T('unfeature_post') : T('feature_post')
      });
      items.push({ k: 'delete',  i: 'trash', label: T('delete_post'), danger: true });
    } else {
      items.push({ k: 'hide',        i: 'eyeOff', label: T('hide_post') });
      items.push({
        k: 'muteauthor',
        i: 'micOff',
        label: isMutedAuthor(post.uid) ? T('unmute_author') : T('mute_author')
      });
      items.push({ k: 'report',      i: 'flag',   label: T('report'), danger: true });
      items.push({ k: 'block',       i: 'block',  label: T('block'),  danger: true });
    }

    items.push({ k: 'share', i: 'share', label: T('share') });
    items.push({
      k: isSaved(pid) ? 'unsave' : 'save',
      i: 'bookmark',
      label: isSaved(pid) ? T('unbookmark') : T('bookmark')
    });

    return items;
  }

  /* ============================================================
   * RENDER SHEET
   * ============================================================ */
  function renderSheet(items) {
    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;
    sheet.innerHTML =
      '<div class="sheet-handle"></div>' +
      items.map(function (it) {
        return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" ' +
                    'data-pm="' + esc(it.k) + '">' +
                 svgIcon(it.i) +
                 '<span>' + esc(it.label) + '</span>' +
               '</div>';
      }).join('');
    return true;
  }

  /* ============================================================
   * ACTION DISPATCH
   * ============================================================
   * Every branch closes the sheet first (closeOverlay was
   * called at the top of the click handler in the original),
   * then delegates to its feature module.
   * ============================================================ */
  async function dispatchAction(k, post) {
    if (!k || !post) return false;

    var pid = post.id;
    var authorUid = post.uid;

    /* --- Owner actions ---------------------------------- */
    if (k === 'edit') {
      safeCall('editPost', [pid]);
      return true;
    }
    if (k === 'delete') {
      safeCall('deletePost', [pid]);
      return true;
    }
    if (k === 'pin') {
      safeCall('pinPost', [pid]);
      return true;
    }
    if (k === 'feature') {
      safeCall('featurePost', [pid]);
      return true;
    }

    /* --- Non-owner actions ------------------------------ */
    if (k === 'hide') {
      safeCall('hidePost', [pid]);
      return true;
    }
    if (k === 'muteauthor') {
      safeCall('muteAuthor', [authorUid]);
      return true;
    }
    if (k === 'report') {
      safeCall('openReport', ['post', pid, null]);
      return true;
    }
    if (k === 'block') {
      safeCall('blockUser', [authorUid]);
      return true;
    }

    /* --- Shared actions --------------------------------- */
    if (k === 'share') {
      safeCall('sharePost', [pid]);
      return true;
    }
    if (k === 'save' || k === 'unsave') {
      safeCall('toggleSave', [pid]);
      return true;
    }

    return false;
  }

  /* ============================================================
   * BIND ITEM CLICKS
   * ============================================================ */
  function bindItems(post) {
    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;

    var nodes = sheet.querySelectorAll('[data-pm]');
    for (var i = 0; i < nodes.length; i++) {
      (function (n) {
        n.addEventListener('click', function () {
          var k = n.getAttribute('data-pm');
          /* Close the sheet FIRST — matches the original. */
          safeCall('closeOverlay', ['ovMsgMenu']);
          dispatchAction(k, post);
        });
      })(nodes[i]);
    }
    return true;
  }

  /* ============================================================
   * OPEN — main entry
   * ============================================================
   * Preserved 1:1 from the original openPostMenu(pid):
   *   1. findPost(pid); bail if missing
   *   2. build the items array based on ownership
   *   3. render into #msgMenuSheet
   *   4. openOverlay('ovMsgMenu')
   *   5. wire item clicks
   * ============================================================ */
  function open(pid) {
    if (!pid) return false;

    var post = findPost(pid);
    if (!post) return false;

    var items = buildItems(pid);
    if (!items.length) return false;

    if (!renderSheet(items)) return false;

    safeCall('openOverlay', ['ovMsgMenu']);
    bindItems(post);

    return true;
  }

  /* ============================================================
   * CLOSE — convenience, additive
   * ============================================================ */
  function close() {
    safeCall('closeOverlay', ['ovMsgMenu']);
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — preserved so feature 055's
   * wirePostInteractions (via safeCall('openPostMenu', [pid]))
   * and any other caller keeps working unchanged. */
  window.openPostMenu = open;

  window.SaikoPostMenu = {
    open: open,
    close: close,
    buildItems: buildItems,
    bind: bindItems,
    ACTION_KEYS: ACTION_KEYS.slice(),
    ACTION_ICONS: Object.assign({}, ACTION_ICONS)
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 088 — post-menu ready');
  } catch (e) {}

})();