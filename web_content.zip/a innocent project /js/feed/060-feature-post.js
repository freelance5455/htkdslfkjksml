/* ============================================================
 * FEATURE:        Feature Post
 * FEATURE NUMBER: 060
 * FILE:           js/feed/060-feature-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused toggle for marking a post as "featured" on the
 *   current user's profile. Featured posts are shown above the
 *   regular post grid in the profile view.
 *
 *   Public functions:
 *     window.featurePost(postId)         → Promise<boolean>
 *     window.toggleFeaturePost(postId)   → Promise<boolean> (alias)
 *
 *   Behaviour preserved 1:1 from the original source's
 *   openPostMenu() "feature" branch:
 *
 *     • If the post is already featured → remove the flag.
 *     • Otherwise → set the flag.
 *     • Both writes are best-effort — a network hiccup never
 *       bubbles up as an exception.
 *     • On success, toast t('saved') (original did NOT use
 *       distinct "featured" / "unfeatured" strings — it
 *       reused the generic "saved" message).
 *
 *   Unlike feature 059 (pin), there is no numeric limit on
 *   featured posts — the original source allowed any number.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu() → case 'feature'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none — pure state + Firebase.
 *
 * FIREBASE PATHS (read + write):
 *   users/{uid}/featuredPosts/{pid}   (set true / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.featurePost
 *   window.toggleFeaturePost
 *   window.SaikoFeaturePost = {
 *     toggle, feature, unfeature,
 *     isFeatured, getCount
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * isFeatured(postId)
   * Reads from the live myProfile.featuredPosts map. Returns
   * false when either the map or the entry is missing.
   * ---------------------------------------------------------- */
  function isFeatured(postId) {
    if (!postId) return false;
    var me = getMyProfile();
    if (!me || !me.featuredPosts) return false;
    return !!me.featuredPosts[postId];
  }

  /* ----------------------------------------------------------
   * getCount()
   * How many posts the current user currently has featured.
   * ---------------------------------------------------------- */
  function getCount() {
    var me = getMyProfile();
    if (!me || !me.featuredPosts) return 0;
    return Object.keys(me.featuredPosts).length;
  }

  /* ----------------------------------------------------------
   * feature(postId)
   * Write path for adding the featured flag. No numeric limit.
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function feature(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    /* Already featured → nothing to do */
    if (isFeatured(postId)) return false;

    try {
      await fbDb.ref('users/' + uid + '/featuredPosts/' + postId).set(true);
    } catch (e) {
      /* Original swallowed the error silently. Preserved. */
      return false;
    }

    safeToast(T('saved'), 'ok');
    emit('featured', postId);
    return true;
  }

  /* ----------------------------------------------------------
   * unfeature(postId)
   * Write path for removing the featured flag.
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function unfeature(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    if (!isFeatured(postId)) return false;

    try {
      await fbDb.ref('users/' + uid + '/featuredPosts/' + postId).remove();
    } catch (e) {
      return false;
    }

    safeToast(T('saved'), 'ok');
    emit('unfeatured', postId);
    return true;
  }

  /* ----------------------------------------------------------
   * toggle(postId)
   * Main entry point. Mirrors the original branch exactly:
   *   if (isFeatured) → unfeature
   *   else            → feature
   * Both paths toast the same t('saved') message.
   * ---------------------------------------------------------- */
  async function toggle(postId) {
    if (!postId) return false;
    return isFeatured(postId) ? unfeature(postId) : feature(postId);
  }

  /* ----------------------------------------------------------
   * Event emitter — additive. Fires on window so any module
   * that wants to observe feature-flag changes can subscribe
   * without polling myProfile.
   * ---------------------------------------------------------- */
  function emit(kind, postId) {
    try {
      window.dispatchEvent(new CustomEvent('saiko:feature-changed', {
        detail: { postId: postId, kind: kind }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.featurePost       = toggle;
  window.toggleFeaturePost = toggle;

  window.SaikoFeaturePost = {
    toggle: toggle,
    feature: feature,
    unfeature: unfeature,
    isFeatured: isFeatured,
    getCount: getCount
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 060 — feature-post ready');
  } catch (e) {}

})();