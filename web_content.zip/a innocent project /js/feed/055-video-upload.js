/* ============================================================
 * FEATURE:        Post Video Upload
 * FEATURE NUMBER: 055
 * FILE:           js/feed/055-video-upload.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused, reusable video-upload pipeline. Mirrors feature
 *   054's image flow but for video files — used by every part
 *   of the app that needs to take a video File and end up
 *   with a hosted HTTPS URL on Cloudinary:
 *
 *     • Post composer         (feature 053)
 *     • Story video           (feature 187)
 *     • Reel upload           (feature 229)
 *     • Chat video send       (feature 142 area)
 *
 *   The pipeline is:
 *
 *     File
 *       → validateVideo()       (type + size)
 *       → probeVideo()          (duration metadata)
 *       → duration guard
 *       → cloudinaryUpload()    (XHR w/ progress)
 *       → hosted URL (secure_url)
 *
 *   Both validateVideo and probeVideo are exposed as global
 *   functions so every existing call site keeps working with
 *   no changes:
 *
 *     window.validateVideo(file, maxBytes, maxSeconds)  → string|null
 *     window.probeVideo(file)                           → Promise<number>
 *     window.uploadPostVideo(file, opts, onProgress)    → Promise<url>
 *
 *   NOTE: This module owns the ORCHESTRATION + validation
 *   rules. It does NOT own the raw XHR uploader (that is
 *   core/cloudinary) nor the media metadata probing
 *   (probeVideo is defined here because it is a pure helper
 *   with no other home in the modular tree).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §5 UTILITIES  → probeVideo(file)
 *   Section §8 CLOUDINARY → validateVideo(file, maxBytes, maxSec)
 *   Section §16 COMPOSER  → inline video upload flow
 *   Section §28 STORIES   → inline video upload flow
 *   Section §29 REELS     → inline video upload flow
 *
 * DEPENDENCIES (loaded earlier):
 *   - MEDIA_CONFIG               (core/config, or fallback here)
 *   - cloudinaryUpload(blob, …)  (core/cloudinary)
 *   - t(key)                     (046 i18n)
 *
 * DOM ELEMENTS USED:
 *   none — pure data pipeline (uses an off-screen <video>)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.validateVideo
 *   window.probeVideo
 *   window.uploadPostVideo
 *   window.SaikoVideoUpload = {
 *     validate, probe, upload,
 *     MAX_BYTES, MAX_SECONDS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — fall back to the exact values from the
   * original §1 CONFIG if MEDIA_CONFIG is not yet on window.
   * ---------------------------------------------------------- */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_POST_VIDEO_SECONDS: 5 * 60,
    MAX_POST_VIDEO_BYTES: 100 * 1024 * 1024,
    MAX_UPLOAD_BYTES: 100 * 1024 * 1024
  };

  var DEFAULT_MAX_BYTES   = MEDIA_CONFIG.MAX_POST_VIDEO_BYTES || (100 * 1024 * 1024);
  var DEFAULT_MAX_SECONDS = MEDIA_CONFIG.MAX_POST_VIDEO_SECONDS || (5 * 60);

  var PROBE_TIMEOUT_MS = 8000;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  /* ----------------------------------------------------------
   * VALIDATE
   * Preserved 1:1 from original validateVideo(file, maxBytes, maxSec):
   *   - must exist
   *   - must be a video/* MIME
   *   - must be ≤ maxBytes
   * (Duration check is done separately by probeVideo + caller
   *  because we need to actually read the file's metadata.)
   *
   * Returns null on success, or an i18n-ready error string.
   * ---------------------------------------------------------- */
  function validate(file, maxBytes, maxSeconds) {
    maxBytes   = maxBytes   || DEFAULT_MAX_BYTES;
    maxSeconds = maxSeconds || DEFAULT_MAX_SECONDS;

    if (!file) return T('invalid_file');
    if (!file.type || file.type.indexOf('video/') !== 0) return T('invalid_file');
    if (file.size > maxBytes) {
      return T('video_too_big') + ' (' + (maxBytes / (1024 * 1024)).toFixed(1) + ' MB)';
    }
    return null;
  }

  /* ----------------------------------------------------------
   * PROBE
   * Preserved 1:1 from original probeVideo(file):
   *   - reads the file's duration by mounting an off-screen
   *     <video preload="metadata" muted>
   *   - revokes the object URL regardless of outcome
   *   - has an 8-second safety timeout
   * ---------------------------------------------------------- */
  function probe(file) {
    return new Promise(function (resolve, reject) {
      if (!file) return reject(new Error('No file'));

      var url = URL.createObjectURL(file);
      var v = document.createElement('video');
      v.preload = 'metadata';
      v.muted = true;
      v.src = url;

      var done = false;
      v.onloadedmetadata = function () {
        if (done) return;
        done = true;
        var d = v.duration;
        try { URL.revokeObjectURL(url); } catch (e) {}
        resolve(d);
      };
      v.onerror = function () {
        if (done) return;
        done = true;
        try { URL.revokeObjectURL(url); } catch (e) {}
        reject(new Error('Cannot read video metadata'));
      };

      setTimeout(function () {
        if (done) return;
        done = true;
        try { URL.revokeObjectURL(url); } catch (e) {}
        reject(new Error('Video metadata timeout'));
      }, PROBE_TIMEOUT_MS);
    });
  }

  /* ----------------------------------------------------------
   * UPLOAD (single)
   *   upload(file, opts, onProgress) → Promise<url>
   *
   *   opts.maxBytes     — size ceiling (default 100 MB)
   *   opts.maxSeconds   — duration ceiling (default 300 s)
   *   opts.filename     — Cloudinary filename (default 'video.mp4')
   *   opts.skipProbe    — when true, skips the duration probe
   *                       (used when the caller has already
   *                        probed the file, e.g. re-upload)
   *
   * Throws on validation failure, on duration overflow, or
   * on uploader failure.
   * ---------------------------------------------------------- */
  async function upload(file, opts, onProgress) {
    opts = opts || {};
    var maxBytes   = opts.maxBytes   || DEFAULT_MAX_BYTES;
    var maxSeconds = opts.maxSeconds || DEFAULT_MAX_SECONDS;

    /* 1) Validate type + size ------------------------------ */
    var err = validate(file, maxBytes, maxSeconds);
    if (err) throw new Error(err);

    /* 2) Probe duration (optional) ------------------------- */
    if (!opts.skipProbe) {
      var dur = 0;
      try {
        dur = await probe(file);
      } catch (e) {
        /* Some browsers occasionally fail to read metadata for
         * perfectly valid files. Preserve the original
         * behaviour: continue without a duration guard when
         * the probe itself fails. */
        dur = 0;
      }
      if (dur && dur > maxSeconds) {
        throw new Error(T('video_too_long') + ' (' + maxSeconds + 's)');
      }
    }

    /* 3) Upload ------------------------------------------- */
    var uploader = null;
    try {
      if (typeof window.cloudinaryUpload === 'function') uploader = window.cloudinaryUpload;
    } catch (e) {}
    if (!uploader) throw new Error(T('upload_failed'));

    var url = await uploader(file, opts.filename || 'video.mp4', onProgress);
    if (!url) throw new Error(T('upload_failed'));
    return url;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original globals — preserved so feature 053 (composer),
   * 187 (story), 229 (reel), and feature 040 all keep working
   * unchanged. */
  window.validateVideo = validate;
  window.probeVideo    = probe;

  /* Convenience global for direct-URL callers */
  window.uploadPostVideo = function (file, opts, onProgress) {
    return upload(file, opts, onProgress);
  };

  window.SaikoVideoUpload = {
    validate: validate,
    probe: probe,
    upload: upload,
    MAX_BYTES: DEFAULT_MAX_BYTES,
    MAX_SECONDS: DEFAULT_MAX_SECONDS
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 055 — video-upload ready');
  } catch (e) {}

})();