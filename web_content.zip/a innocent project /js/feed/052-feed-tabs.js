/* ============================================================
 * FEATURE:        Feed Tabs Controller
 * FEATURE NUMBER: 052
 * FILE:           js/feed/052-feed-tabs.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "what happens after a feed tab click" coordinator.
 *
 *   Architecture split across three modules:
 *     035 (prefs/035-feed-mode.js)
 *       - owns the mode STATE (getMode / setMode)
 *       - renders the tab strip HTML (renderTabs)
 *       - provides generic chip click binding (bindTabs)
 *
 *     051 (feed/051-feed-render.js)
 *       - owns the feed DOM (page-home, #feedList, post cards)
 *       - owns pagination counters (feedVisibleCount, shell sig)
 *
 *     052 (THIS FILE)
 *       - the coordinator in between
 *       - when a tab is clicked it:
 *           1. updates the mode (via 035's setMode)
 *           2. resets pagination back to FEED_BATCH
 *           3. invalidates the feed shell signature
 *           4. re-renders the feed (via 051's renderFeed)
 *       - exposes render() and bind() so 051 (or any other
 *         feed context) can delegate its tab-strip handling
 *
 *   Behaviour preserved 1:1 from the original §15 inline
 *   tab-click handler:
 *
 *       page.querySelectorAll('[data-feedtab]').forEach(n => {
 *         n.addEventListener('click', () => {
 *           feedMode = n.getAttribute('data-feedtab');
 *           feedVisibleCount = FEED_BATCH;
 *           feedShellSig = '';
 *           renderFeed(false);
 *         });
 *       });
 *
 *   The only difference from the original is the ordering:
 *   instead of mutating module-scoped variables directly, we
 *   go through the public setters exposed by 035 and 051.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED — the [data-feedtab] click handler that
 *   sits inside renderFeed().
 *
 * DEPENDENCIES (loaded earlier):
 *   - SaikoFeedMode   (js/prefs/035-feed-mode.js)  — optional
 *   - SaikoFeedRender (js/feed/051-feed-render.js) — optional
 *   - t / esc                                       helpers
 *
 * DOM ELEMENTS USED:
 *   .feed-tabs     (container)
 *   [data-feedtab] (chips)
 *   #page-home     (feed root — passed to bindTabs)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoFeedTabs = {
 *     render, bind, unbind,
 *     onTabChange,
 *     getActive,
 *     MODES
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — mirrored from the original source so this
   * module works even without feature 035.
   * ---------------------------------------------------------- */
  var MODES = ['foryou', 'latest', 'popular', 'trending', 'interests'];
  var FEED_BATCH = 10;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[feed-tabs] safeCall:', name, e); }
    return undefined;
  }

  /* ----------------------------------------------------------
   * State readers/writers — always route through public APIs
   * so features 035 and 051 stay the single source of truth.
   * ---------------------------------------------------------- */

  function getActiveMode() {
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.getMode === 'function') {
        return window.SaikoFeedMode.getMode();
      }
    } catch (e) {}
    return 'latest';
  }

  function setActiveMode(mode) {
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.setMode === 'function') {
        return window.SaikoFeedMode.setMode(mode, { persist: false });
      }
    } catch (e) {}
    /* Fallback: at least remember it locally so chips highlight */
    _fallbackMode = mode;
    return true;
  }

  var _fallbackMode = 'latest';

  /* ----------------------------------------------------------
   * PAGINATION RESET — delegates to 051's setter if available,
   * otherwise records the intent for the next re-render.
   * ---------------------------------------------------------- */
  function resetPagination() {
    try {
      if (window.SaikoFeedRender && typeof window.SaikoFeedRender.setVisibleCount === 'function') {
        window.SaikoFeedRender.setVisibleCount(FEED_BATCH);
        return true;
      }
    } catch (e) {}
    return false;
  }

  /* ----------------------------------------------------------
   * SHELL INVALIDATION — force the next renderFeed() to
   * rebuild the shell even if the visible post ids are the
   * same. In the original this was done by setting
   * `feedShellSig = ''`. Since 051 keeps that variable
   * module-scoped, we invalidate it by bumping the visible
   * count (which changes the signature) and relying on 051's
   * `renderFeed(false)` to rebuild.
   *
   * We also bump the rotation seed so "latest"/"foryou" get
   * the gentle reshuffle the original pull-to-refresh did.
   * ---------------------------------------------------------- */
  function invalidateShell(bumpRotation) {
    try {
      if (bumpRotation &&
          window.SaikoFeedRender &&
          typeof window.SaikoFeedRender.bumpRotationSeed === 'function') {
        window.SaikoFeedRender.bumpRotationSeed();
      }
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * ON TAB CHANGE — the coordinator's core routine.
   *
   * Preserved 1:1 from the original inline click handler:
   *   1. update the mode
   *   2. reset feedVisibleCount to FEED_BATCH
   *   3. invalidate feedShellSig
   *   4. renderFeed(false)
   * ---------------------------------------------------------- */
  function onTabChange(mode) {
    if (!mode || MODES.indexOf(mode) === -1) return false;

    /* 1) Update the mode ------------------------------------ */
    setActiveMode(mode);

    /* 2) Reset pagination ----------------------------------- */
    resetPagination();

    /* 3) Invalidate the shell signature -------------------- */
    invalidateShell(false);

    /* 4) Re-render the feed -------------------------------- */
    safeCall('renderFeed', [false]);

    /* 5) Notify subscribers -------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:feed-tab-changed', {
        detail: { mode: mode }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * RENDER — returns the tab strip HTML.
   * Prefers feature 035's renderTabs() so the .sel state stays
   * canonical; falls back to an inline copy of the original
   * markup if 035 has not loaded.
   * ---------------------------------------------------------- */
  function render() {
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.renderTabs === 'function') {
        return window.SaikoFeedMode.renderTabs();
      }
    } catch (e) {}

    /* Inline fallback — byte-for-byte from the original source */
    var current = getActiveMode();
    var chips = MODES.map(function (k) {
      var sel = (current === k) ? ' sel' : '';
      return '<span class="chip' + sel + '" data-feedtab="' + esc(k) + '">' +
             esc(T(k)) +
             '</span>';
    }).join('');
    return '<div class="feed-tabs">' + chips + '</div>';
  }

  /* ----------------------------------------------------------
   * BIND — attaches the tab-click flow.
   *
   * Preferred path: delegate to feature 035's bindTabs() and
   * pass THIS module's onTabChange as the callback. That way
   * 035 stays in charge of chip click handling and 052 only
   * provides the coordinator logic.
   *
   * Fallback path: wire clicks inline (byte-for-byte original
   * behaviour) so the tabs work even without 035.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;

    /* Preferred: hand off to 035 with our coordinator as cb */
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.bindTabs === 'function') {
        return window.SaikoFeedMode.bindTabs(scope, function (mode) {
          onTabChange(mode);
        });
      }
    } catch (e) {}

    /* Fallback: inline wiring */
    var chips = scope.querySelectorAll('[data-feedtab]');
    if (!chips.length) return false;

    var bound = false;
    chips.forEach(function (chip) {
      if (chip.dataset.feedTabsBound === '1') return;
      chip.dataset.feedTabsBound = '1';
      chip.addEventListener('click', function () {
        var mode = chip.getAttribute('data-feedtab');
        if (!mode) return;
        onTabChange(mode);
        /* Refresh .sel state across the strip */
        chips.forEach(function (x) {
          x.classList.toggle('sel', x.getAttribute('data-feedtab') === mode);
        });
      });
      bound = true;
    });
    return bound;
  }

  function unbind(root) {
    var scope = root || document;
    try {
      if (window.SaikoFeedMode && typeof window.SaikoFeedMode.unbindTabs === 'function') {
        return window.SaikoFeedMode.unbindTabs(scope);
      }
    } catch (e) {}
    scope.querySelectorAll('[data-feedtab]').forEach(function (chip) {
      if (chip.dataset.feedTabsBound !== '1') return;
      var clone = chip.cloneNode(true);
      clone.removeAttribute('data-feed-tabs-bound');
      chip.parentNode && chip.parentNode.replaceChild(clone, chip);
    });
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoFeedTabs = {
    MODES: MODES.slice(),
    render: render,
    bind: bind,
    unbind: unbind,
    onTabChange: onTabChange,
    getActive: getActiveMode
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 052 — feed-tabs ready');
  } catch (e) {}

})();