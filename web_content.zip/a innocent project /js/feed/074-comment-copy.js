/* ============================================================
 * FEATURE:        Comment Copy
 * FEATURE NUMBER: 074
 * FILE:           js/feed/074-comment-copy.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for copying a comment's text to the
 *   clipboard. Extracts the "copy" branch that lives inline
 *   inside feature 067's openSplitCommentMenu() so any future
 *   comment surface (post-split, legacy overlay, reel
 *   comments, story replies) can reuse the same flow.
 *
 *   Behaviour preserved 1:1 from the original §17 POST SPLIT
 *   copy branch:
 *
 *     try {
 *       await navigator.clipboard.writeText(c.text || '');
 *       toast(t('copied'), 'ok');
 *     } catch (e) {
 *       toast(c.text || '');
 *     }
 *
 *   Public functions:
 *     window.copyComment(postId, commentId)      → Promise<boolean>
 *     window.copyCommentText(text)               → Promise<boolean>
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     openSplitCommentMenu() → case 'copy'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *                            (only when copyComment needs to
 *                             fetch the text by id)
 *   - toast                  js/nav/042-toast.js
 *                            (safely-called)
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none
 *
 * FIREBASE PATHS:
 *   comments/{pid}/{cid}     (read — to fetch the text)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.copyComment
 *   window.copyCommentText
 *   window.SaikoCommentCopy = {
 *     copy, copyText,
 *     canUseClipboard,
 *     getCommentText
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * canUseClipboard
   * Preserved 1:1 from the original guard.
   * ---------------------------------------------------------- */
  function canUseClipboard() {
    try {
      return !!(navigator && navigator.clipboard &&
                typeof navigator.clipboard.writeText === 'function');
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * getCommentText(postId, commentId) → Promise<string>
   * Reads the comment's current text from Firebase. Resolves
   * with '' when the comment is missing or the DB is
   * unavailable. Exposed for callers that want to preview the
   * text before invoking copy.
   * ---------------------------------------------------------- */
  async function getCommentText(postId, commentId) {
    if (!postId || !commentId) return '';
    var fbDb = getDB();
    if (!fbDb) return '';
    try {
      var snap = await fbDb.ref('comments/' + postId + '/' + commentId).get();
      var c = snap.val();
      return c ? (c.text || '') : '';
    } catch (e) {
      return '';
    }
  }

  /* ----------------------------------------------------------
   * copyText(text) → Promise<boolean>
   * The raw clipboard helper. Preserves the exact original
   * fallback behaviour:
   *   • clipboard available → writeText + toast(t('copied'),'ok')
   *   • clipboard throws    → toast(text)
   *   • clipboard missing   → toast(text)
   *
   * Empty or missing text is short-circuited to a plain
   * toast(text) — matching the "c.text || ''" default in the
   * original.
   * ---------------------------------------------------------- */
  async function copyText(text) {
    var body = (text == null) ? '' : String(text);

    /* 1) Preferred path — Web Clipboard API ---------------- */
    if (canUseClipboard()) {
      try {
        await navigator.clipboard.writeText(body);
        safeToast(T('copied'), 'ok');
        return true;
      } catch (e) {
        /* Fall through to the toast-echo fallback so the user
         * at least sees the text (matches original). */
        safeToast(body);
        return false;
      }
    }

    /* 2) Fallback — show the text in a toast -------------- */
    safeToast(body);
    return false;
  }

  /* ----------------------------------------------------------
   * copy(postId, commentId) → Promise<boolean>
   * Main entry point — resolves the text from Firebase and
   * delegates to copyText().
   * ---------------------------------------------------------- */
  async function copy(postId, commentId) {
    if (!postId || !commentId) return false;

    var text = await getCommentText(postId, commentId);

    /* Even when the comment is missing, the original would
     * have called toast(c.text || '') → toast(''). We keep
     * that behaviour so the flow is identical. */
    return copyText(text);
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.copyComment     = copy;
  window.copyCommentText = copyText;

  window.SaikoCommentCopy = {
    copy: copy,
    copyText: copyText,
    canUseClipboard: canUseClipboard,
    getCommentText: getCommentText
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 074 — comment-copy ready');
  } catch (e) {}

})();