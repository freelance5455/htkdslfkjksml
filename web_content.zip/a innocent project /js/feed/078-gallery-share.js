/* ============================================================
 * FEATURE:        Gallery Share (URL Share Helper)
 * FEATURE NUMBER: 078
 * FILE:           js/feed/078-gallery-share.js
 * ACTION:         REPLACE (Batch 9 — clean rewrite)
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * CONSTANTS
   * ---------------------------------------------------------- */
  var TRACK = {
    SHARE_API: 'share-api',
    CLIPBOARD: 'clipboard',
    NONE:      'none'
  };

  /* ----------------------------------------------------------
   * HELPERS
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  function canUseShareApi() {
    try { return !!(navigator && typeof navigator.share === 'function'); }
    catch (e) { return false; }
  }
  function canUseClipboard() {
    try {
      return !!(navigator && navigator.clipboard &&
                typeof navigator.clipboard.writeText === 'function');
    } catch (e) { return false; }
  }

  function buildSharePayload(url, opts) {
    if (!url) return null;
    opts = opts || {};
    var payload = { url: url };
    if (opts.title) payload.title = String(opts.title);
    if (opts.text)  payload.text  = String(opts.text);
    return payload;
  }

  function emitSuccess(url, transport, opts) {
    if (opts && typeof opts.onShareSuccess === 'function') {
      try { opts.onShareSuccess(url, transport); } catch (e) {}
    }
    try {
      window.dispatchEvent(new CustomEvent('saiko:url-shared', {
        detail: { url: url, transport: transport }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * SHARE — main entry
   * ---------------------------------------------------------- */
  async function share(url, opts) {
    if (!url) return { ok: false, transport: TRACK.NONE };

    opts = opts || {};
    var payload = buildSharePayload(url, opts);

    /* Transport 1: Web Share API ----------------------- */
    if (canUseShareApi()) {
      try {
        await navigator.share(payload);
        emitSuccess(url, TRACK.SHARE_API, opts);
        return { ok: true, transport: TRACK.SHARE_API };
      } catch (err) {
        return { ok: false, transport: TRACK.SHARE_API };
      }
    }

    /* Transport 2: Clipboard --------------------------- */
    if (canUseClipboard()) {
      try {
        await navigator.clipboard.writeText(url);
        safeToast(T('copied'), 'ok');
        emitSuccess(url, TRACK.CLIPBOARD, opts);
        return { ok: true, transport: TRACK.CLIPBOARD };
      } catch (err) {
        return { ok: false, transport: TRACK.CLIPBOARD };
      }
    }

    /* Transport 3: none available ---------------------- */
    return { ok: false, transport: TRACK.NONE };
  }

  function shareImage(url, opts) {
    return share(url, opts);
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.shareUrl = share;

  window.SaikoGalleryShare = {
    share: share,
    shareImage: shareImage,
    canUseShareApi: canUseShareApi,
    canUseClipboard: canUseClipboard,
    buildSharePayload: buildSharePayload,
    TRACK: TRACK
  };

  try {
    console.debug('[boot] feature 078 — gallery-share ready');
  } catch (e) {}

})();