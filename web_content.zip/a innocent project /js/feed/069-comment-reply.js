/* ============================================================
 * FEATURE:        Comment Replies (Reply Helpers)
 * FEATURE NUMBER: 069
 * FILE:           js/feed/069-comment-reply.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Extracts the reply-target logic that lives inline inside
 *   feature 067 (post-split) into a set of reusable, guarded
 *   helpers so the same flow can be shared with any future
 *   comment surface (post-split, legacy overlay, story replies,
 *   reel comments, chat replies).
 *
 *   In the original single-file build, the reply logic was a
 *   mixture of:
 *     • a module-scoped `splitReplyTarget` variable
 *     • a [data-sreply] click handler that set the target and
 *       prefixed the input with `@name `
 *     • a send-time block that read the target and produced
 *       `{ parent, parentUid, parentName }` fields
 *     • a notification block that pushed two distinct
 *       notifications (post owner + parent author)
 *
 *   This module provides:
 *
 *     • setTarget(target) / getTarget() / clearTarget()
 *     • applyMentionPrefix(inputEl, name)
 *     • stripMentionPrefix(text)
 *     • buildCommentPayload({ text, target, uid, name, photo })
 *     • buildNotifications({ post, target, uid, name, photo })
 *     • wireReplyButton(node) — the reusable [data-sreply]
 *       click handler
 *
 *   The reply target is exposed on `window.splitReplyTarget`
 *   so feature 067 (and any sibling) can migrate from its own
 *   internal variable to this canonical one with no source
 *   edits beyond removing the local declaration.
 *
 *   All helpers are pure/stateless except for the single target
 *   slot, so calling code can pick and choose what it needs.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     • splitReplyTarget (module-scoped)
 *     • [data-sreply] click handler
 *     • #splitSendComment handler (read parent / parentUid /
 *       parentName, push two notifications)
 *
 * DEPENDENCIES (loaded earlier):
 *   - t(key)                 js/nav/046-i18n.js
 *   - now()                  js/core/utils.js
 *   - pushNotification       js/notifications/106-push-notif.js
 *                            (only when the caller chooses to
 *                             dispatch via SaikoCommentReply)
 *
 * DOM ELEMENTS USED:
 *   Any input element passed to applyMentionPrefix() — e.g.
 *   #splitCommentInput, #rsCommentInput, #commentInput.
 *
 * FIREBASE PATHS:
 *   none — the payload builder is a pure formatter. The caller
 *   writes to comments/{pid} and dispatches notifications.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.splitReplyTarget       (live target object)
 *   window.SaikoCommentReply = {
 *     setTarget, getTarget, clearTarget,
 *     applyMentionPrefix, stripMentionPrefix,
 *     getMentionPrefix,
 *     buildCommentPayload,
 *     buildNotifications,
 *     dispatchNotifications,
 *     wireReplyButton
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE — single slot for the current reply target.
   * ============================================================
   * Shape:
   *   {
   *     commentId: string,   // id of the comment being replied to
   *     name:      string,   // display name of the commenter
   *     uid:       string    // uid of the commenter
   *   }
   *
   * Exposed on window so feature 067 can adopt it without
   * keeping its own duplicate. Until then, 067's own variable
   * remains authoritative for its flow — 069 is purely
   * additive and does not interfere.
   * ---------------------------------------------------------- */
  window.splitReplyTarget = window.splitReplyTarget || null;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[comment-reply] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * TARGET MANAGEMENT
   * ============================================================ */

  function setTarget(target) {
    if (!target || !target.commentId) {
      window.splitReplyTarget = null;
      return false;
    }
    window.splitReplyTarget = {
      commentId: String(target.commentId),
      name: target.name != null ? String(target.name) : '',
      uid: target.uid != null ? String(target.uid) : ''
    };
    return true;
  }

  function getTarget() {
    return window.splitReplyTarget || null;
  }

  function clearTarget() {
    var had = !!window.splitReplyTarget;
    window.splitReplyTarget = null;
    return had;
  }

  /* ============================================================
   * MENTION PREFIX HELPERS
   * ============================================================ */

  /* Build the mention string used at the start of the input. */
  function getMentionPrefix(name) {
    if (!name) return '';
    return '@' + name + ' ';
  }

  /* Preserved from original inline logic:
   *   if (!input.value.startsWith(mention)) {
   *     input.value = mention + input.value.replace(/^@\S+\s+/, '');
   *   }
   * The `^@\S+\s+` strip removes any PREVIOUS mention so the
   * user does not end up with `@A @B …` when switching replies
   * quickly. */
  function applyMentionPrefix(inputEl, name) {
    if (!inputEl) return false;
    var mention = getMentionPrefix(name);
    if (!mention) return false;

    var current = inputEl.value || '';
    if (current.indexOf(mention) === 0) {
      /* Already prefixed with the exact mention — no-op. */
    } else {
      inputEl.value = mention + current.replace(/^@\S+\s+/, '');
    }

    /* Preserve the original focus + caret-to-end behaviour. */
    try {
      if (typeof inputEl.focus === 'function') inputEl.focus();
      setTimeout(function () {
        try {
          inputEl.selectionStart = inputEl.selectionEnd = inputEl.value.length;
        } catch (e) {}
      }, 10);
    } catch (e) {}

    return true;
  }

  /* Strip a leading @mention from a message body. Useful for
   * storage, or for building a cleaner preview. */
  function stripMentionPrefix(text) {
    if (!text) return '';
    return String(text).replace(/^@\S+\s+/, '');
  }

  /* ============================================================
   * PAYLOAD BUILDER
   * ============================================================
   * Produces the exact object shape that feature 067 writes to
   * comments/{pid}/{cid}. Caller then:
   *    const ref = fbDb.ref('comments/'+pid).push();
   *    await ref.set(buildCommentPayload({...}));
   * --------------------------------------------------------- */
  function buildCommentPayload(opts) {
    opts = opts || {};
    var target = opts.target || getTarget();
    var id = opts.id != null ? opts.id : null;

    return {
      id: id,
      uid: opts.uid || null,
      authorName: opts.name || '',
      authorPhoto: opts.photo || '',
      text: opts.text || '',
      parent: (target && target.commentId) || null,
      parentUid: (target && target.uid) || null,
      createdAt: opts.createdAt != null ? opts.createdAt : timeNow()
    };
  }

  /* ============================================================
   * NOTIFICATION BUILDER
   * ============================================================
   * Returns an array of { toUid, payload } objects. The caller
   * may either:
   *   • loop and call window.pushNotification(toUid, payload)
   *   • or call SaikoCommentReply.dispatchNotifications(list)
   *
   * Preserved from original §17 #splitSendComment handler:
   *   • Always notify the post owner (if not me)
   *   • Always notify the parent author (if not me AND not the
   *     post owner) — avoids duplicate notifications when the
   *     parent author happens to be the post owner
   *   • Type is 'reply' when there is a target, 'comment'
   *     otherwise
   * --------------------------------------------------------- */
  function buildNotifications(opts) {
    opts = opts || {};
    var post = opts.post || null;
    var target = opts.target || getTarget();
    var uid = opts.uid || null;
    var name = opts.name || '';
    var photo = opts.photo || '';
    var pid = opts.postId || (post && post.id) || null;
    var commentId = opts.commentId || null;
    var parentName = (target && target.name) || '';
    var parentUid = (target && target.uid) || null;

    var out = [];

    /* 1) Post owner --------------------------------------- */
    if (post && post.uid && post.uid !== uid) {
      out.push({
        toUid: post.uid,
        payload: {
          type: target ? 'reply' : 'comment',
          fromUid: uid,
          fromName: name || 'User',
          fromPhoto: photo,
          text: target ? T('replied_to') : T('commented_on'),
          postId: pid,
          commentId: commentId,
          parentName: parentName,
          createdAt: timeNow()
        }
      });
    }

    /* 2) Parent author — only if distinct from post owner */
    if (parentUid && parentUid !== uid && parentUid !== (post && post.uid)) {
      out.push({
        toUid: parentUid,
        payload: {
          type: 'reply',
          fromUid: uid,
          fromName: name || 'User',
          fromPhoto: photo,
          text: T('replied_to'),
          postId: pid,
          commentId: commentId,
          parentName: parentName,
          createdAt: timeNow()
        }
      });
    }

    return out;
  }

  /* Convenience dispatcher — safely calls pushNotification for
   * each entry. Failures are swallowed per the original. */
  function dispatchNotifications(list) {
    if (!Array.isArray(list)) return 0;
    var sent = 0;
    for (var i = 0; i < list.length; i++) {
      var entry = list[i];
      if (!entry || !entry.toUid || !entry.payload) continue;
      safeCall('pushNotification', [entry.toUid, entry.payload]);
      sent++;
    }
    return sent;
  }

  /* ============================================================
   * WIRE REPLY BUTTON
   * ============================================================
   * Attaches the [data-sreply] click handler to a single node
   * (or to every [data-sreply] inside a root, when a root is
   * passed).
   *
   * The handler:
   *   1. Reads data-sreply / data-sreplyto / data-suid
   *   2. Sets the reply target
   *   3. Applies the @mention prefix to the given input
   *   4. Updates the input placeholder
   *
   * Idempotent per node via dataset.replyBound.
   * --------------------------------------------------------- */
  function wireOneReplyButton(node, inputEl) {
    if (!node) return false;
    if (node.dataset.replyBound === '1') return true;
    node.dataset.replyBound = '1';

    node.addEventListener('click', function () {
      var cid  = node.getAttribute('data-sreply');
      var to   = node.getAttribute('data-sreplyto');
      var uid  = node.getAttribute('data-suid');

      setTarget({ commentId: cid, name: to, uid: uid });

      if (inputEl) {
        applyMentionPrefix(inputEl, to);
        try {
          inputEl.placeholder = T('reply_hint') + ' ' + to + '...';
        } catch (e) {}
      }
    });
    return true;
  }

  function wireReplyButton(arg1, arg2) {
    /* Case A: (node, inputEl) — wire one specific node */
    if (arg1 && arg1.nodeType === 1) {
      return wireOneReplyButton(arg1, arg2);
    }
    /* Case B: (root, inputEl) — wire every [data-sreply] in root */
    var root = arg1 || document;
    var inputEl = arg2 || null;
    var nodes = root.querySelectorAll ? root.querySelectorAll('[data-sreply]') : [];
    var bound = false;
    for (var i = 0; i < nodes.length; i++) {
      if (wireOneReplyButton(nodes[i], inputEl)) bound = true;
    }
    return bound;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoCommentReply = {
    /* state */
    setTarget: setTarget,
    getTarget: getTarget,
    clearTarget: clearTarget,

    /* mention prefix */
    getMentionPrefix: getMentionPrefix,
    applyMentionPrefix: applyMentionPrefix,
    stripMentionPrefix: stripMentionPrefix,

    /* payload + notifications */
    buildCommentPayload: buildCommentPayload,
    buildNotifications: buildNotifications,
    dispatchNotifications: dispatchNotifications,

    /* UI wiring */
    wireReplyButton: wireReplyButton
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 069 — comment-reply helpers ready');
  } catch (e) {}

})();