/* ============================================================
 * FEATURE:        Comment Edit
 * FEATURE NUMBER: 071
 * FILE:           js/feed/071-comment-edit.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for editing an existing comment. Extracts
 *   the "edit" branch that lives inline inside feature 067's
 *   openSplitCommentMenu() so any future comment surface
 *   (post-split, legacy overlay, reel comments, story replies)
 *   can reuse the same flow.
 *
 *   Behaviour preserved 1:1 from the original §17 POST SPLIT
 *   edit branch:
 *
 *     1. promptDialog(t('edit_comment'), currentText)
 *     2. abort silently when the user cancels (null)
 *     3. trim the input; abort silently when it becomes empty
 *     4. comments/{pid}/{cid}.update({ text, updatedAt: now() })
 *     5. on error, toast the error message
 *
 *   Public function:
 *     window.editComment(postId, commentId) → Promise<boolean>
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     openSplitCommentMenu() → case 'edit'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - promptDialog           js/nav/044-prompt-dialog.js
 *                            (safely-called)
 *   - toast                  js/nav/042-toast.js
 *                            (safely-called)
 *   - t(key) / now()         helpers
 *
 * DOM ELEMENTS USED:
 *   none directly — promptDialog builds its own overlay.
 *
 * FIREBASE PATHS:
 *   comments/{pid}/{cid}          (read for the current text,
 *                                  write for the update)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.editComment
 *   window.SaikoCommentEdit = {
 *     edit, getCurrentText, buildUpdatePayload
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') {
        return window.promptDialog(title, defValue, placeholder);
      }
    } catch (e) {}
    /* If promptDialog is missing, resolve with null so the
     * caller treats it as a cancel rather than hanging. */
    return Promise.resolve(null);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * getCurrentText(postId, commentId) → Promise<string>
   * Reads the comment's current text from Firebase. Resolves
   * with an empty string when the comment is missing or the
   * DB is unavailable. Useful for callers that want to preview
   * the edit without re-reading.
   * ---------------------------------------------------------- */
  async function getCurrentText(postId, commentId) {
    if (!postId || !commentId) return '';
    var fbDb = getDB();
    if (!fbDb) return '';
    try {
      var snap = await fbDb.ref('comments/' + postId + '/' + commentId).get();
      var c = snap.val();
      return c ? (c.text || '') : '';
    } catch (e) {
      return '';
    }
  }

  /* ----------------------------------------------------------
   * buildUpdatePayload(text) → { text, updatedAt }
   * Pure — exposed so callers can reuse the exact payload
   * shape that the original wrote.
   * ---------------------------------------------------------- */
  function buildUpdatePayload(text) {
    return {
      text: (text == null) ? '' : String(text),
      updatedAt: timeNow()
    };
  }

  /* ----------------------------------------------------------
   * edit(postId, commentId) → Promise<boolean>
   * Preserved 1:1 from the original edit branch.
   * ---------------------------------------------------------- */
  async function edit(postId, commentId) {
    if (!postId || !commentId) return false;

    var fbDb = getDB();
    if (!fbDb) return false;

    /* 1) Fetch the current text --------------------------- */
    var currentText = '';
    try {
      var snap = await fbDb.ref('comments/' + postId + '/' + commentId).get();
      var c = snap.val();
      if (!c) return false;                     /* comment gone */
      currentText = c.text || '';
    } catch (e) {
      /* Best-effort read — fall through with empty default
       * so the user can still type a replacement. */
      currentText = '';
    }

    /* 2) Prompt for the new text ------------------------- */
    var nt = await askPrompt(T('edit_comment'), currentText);
    if (nt == null) return false;               /* cancelled */

    /* 3) Trim + reject empty ----------------------------- */
    var txt = String(nt).trim();
    if (!txt) return false;

    /* 4) Update Firebase -------------------------------- */
    try {
      await fbDb.ref('comments/' + postId + '/' + commentId)
        .update(buildUpdatePayload(txt));
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }

    /* 5) Notify subscribers (additive) ------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:comment-edited', {
        detail: { postId: postId, commentId: commentId, text: txt }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.editComment = edit;

  window.SaikoCommentEdit = {
    edit: edit,
    getCurrentText: getCurrentText,
    buildUpdatePayload: buildUpdatePayload
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 071 — comment-edit ready');
  } catch (e) {}

})();