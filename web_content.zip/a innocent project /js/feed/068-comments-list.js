/* ============================================================
 * FEATURE:        Comments List (Legacy Comments Overlay)
 * FEATURE NUMBER: 068
 * FILE:           js/feed/068-comments-list.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The legacy standalone comments overlay (#ovComments). In
 *   the original single-file build this overlay still existed
 *   in the DOM but its main entry point was redirected to the
 *   newer post-split view (feature 067). What remained was:
 *
 *     • A live-listener lifecycle (commentsListener /
 *       replyTarget) that the newer flow no longer populated,
 *       but whose cleanup hooks were still invoked by the
 *       overlay system.
 *     • A [data-close="ovComments"] delegation that calls
 *       detachCommentsListener() before the overlay closes.
 *     • openComments(pid) → openPostSplit(pid)
 *     • A no-op sendComment() and its #btnSendComment /
 *       #commentInput listeners (kept for backwards compat so
 *       the old markup does not throw if someone still opens
 *       it).
 *
 *   This module preserves that behaviour byte-for-byte. Its
 *   primary job is to keep the FUNCTION NAMES that other
 *   modules already reference:
 *
 *     window.detachCommentsListener     (feature 038 popstate)
 *     window.detachCommentReactions     (feature 038 teardown)
 *     window.openComments               (feature 051 / 088)
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §18 COMMENTS legacy
 *     let currentPostId, commentsListener, replyTarget
 *     detachCommentsListener()
 *     detachCommentReactions()
 *     openComments(pid) → openPostSplit(pid)
 *     #ovComments click → detachCommentsListener()
 *     sendComment() (no-op)
 *     #btnSendComment click → sendComment
 *     #commentInput Enter  → sendComment
 *
 * DEPENDENCIES (loaded earlier):
 *   - openPostSplit     js/feed/067-post-split.js (safely-called)
 *   - openOverlay/closeOverlay
 *                       js/nav/038-overlay-system.js (optional)
 *
 * DOM ELEMENTS USED:
 *   #ovComments      (overlay container)
 *   #btnSendComment  (send button — no-op)
 *   #commentInput    (comment input — no-op)
 *
 * FIREBASE PATHS:
 *   none directly — the newer post-split view (067) owns the
 *   live listener on comments/{pid}. This module only holds the
 *   LEGACY cleanup hooks that used to detach the same listener.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openComments                 (original name)
 *   window.detachCommentsListener       (original name)
 *   window.detachCommentReactions       (original name)
 *   window.sendComment                  (original name)
 *   window.SaikoCommentsList = {
 *     open, detachListener, detachReactions,
 *     send, bind, unbind,
 *     getCurrentPostId, setCurrentPostId
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * STATE
   * ----------------------------------------------------------
   * Preserved from the original §18 block. In the newer
   * architecture these are effectively dormant (the split view
   * in feature 067 owns its own listener), but they are kept
   * for API compatibility so callers can still inspect /
   * mutate them.
   * ---------------------------------------------------------- */
  var currentPostId = null;
  var commentsListener = null;   /* { ref, cb } or null */
  var replyTarget = null;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[comments-list] safeCall:', name, e); }
    return undefined;
  }

  /* ----------------------------------------------------------
   * DETACH COMMENTS LISTENER
   * Preserved 1:1 from original detachCommentsListener().
   * Called by:
   *   • feature 038 popstate (Back closes overlay)
   *   • feature 038 [data-close="ovComments"] delegation
   * ---------------------------------------------------------- */
  function detachListener() {
    if (commentsListener) {
      try { commentsListener.ref.off('value', commentsListener.cb); } catch (e) {}
      commentsListener = null;
    }
  }

  /* ----------------------------------------------------------
   * DETACH COMMENT REACTIONS
   * Preserved 1:1 from original detachCommentReactions()
   * (empty stub in the source — kept for API parity).
   * ---------------------------------------------------------- */
  function detachReactions() {
    /* Intentionally empty — matches the original source.
     * The live reaction listener lives on feature 067's
     * split view, which owns its own detach lifecycle. */
  }

  /* ----------------------------------------------------------
   * OPEN COMMENTS
   * Preserved 1:1 from original openComments(pid):
   *   → delegates to openPostSplit(pid)
   * ---------------------------------------------------------- */
  function open(pid) {
    if (!pid) return false;
    currentPostId = pid;
    return safeCall('openPostSplit', [pid]) === true;
  }

  /* ----------------------------------------------------------
   * SEND COMMENT
   * Preserved 1:1 from original sendComment() — intentionally
   * a NO-OP. All real comment sending happens through
   * feature 067's #splitSendComment handler.
   * ---------------------------------------------------------- */
  async function send() {
    return false;
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Wires the legacy overlay hooks:
   *   • #ovComments click → [data-close="ovComments"] →
   *     detachCommentsListener()
   *   • #btnSendComment click → sendComment
   *   • #commentInput Enter   → sendComment
   * ---------------------------------------------------------- */
  function onOverlayClick(e) {
    var c = e.target && e.target.closest ? e.target.closest('[data-close="ovComments"]') : null;
    if (!c) return;
    detachListener();
    /* Note: we do NOT call closeOverlay here. Feature 038's
     * own [data-close] delegation owns the actual close
     * (because it too calls detachCommentsListener via its
     * own teardown chain, and double-close would be redundant). */
  }

  function onSendClick(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    send();
  }

  function onInputKeydown(e) {
    if (e && e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* 1) #ovComments — [data-close] delegation ------------- */
    var ov = qs('#ovComments');
    if (ov && ov.dataset.commentsListBound !== '1') {
      ov.dataset.commentsListBound = '1';
      ov.addEventListener('click', onOverlayClick);
      bound = true;
    }

    /* 2) #btnSendComment ----------------------------------- */
    var btn = qs('#btnSendComment');
    if (btn && btn.dataset.commentsListBound !== '1') {
      btn.dataset.commentsListBound = '1';
      btn.addEventListener('click', onSendClick);
      bound = true;
    }

    /* 3) #commentInput ------------------------------------- */
    var input = qs('#commentInput');
    if (input && input.dataset.commentsListBound !== '1') {
      input.dataset.commentsListBound = '1';
      input.addEventListener('keydown', onInputKeydown);
      bound = true;
    }

    return bound;
  }

  function unbind(root) {
    var scope = root || document;

    var ov = qs('#ovComments');
    if (ov) {
      ov.removeEventListener('click', onOverlayClick);
      delete ov.dataset.commentsListBound;
    }

    var btn = qs('#btnSendComment');
    if (btn) {
      btn.removeEventListener('click', onSendClick);
      delete btn.dataset.commentsListBound;
    }

    var input = qs('#commentInput');
    if (input) {
      input.removeEventListener('keydown', onInputKeydown);
      delete input.dataset.commentsListBound;
    }
  }

  /* ----------------------------------------------------------
   * STATE INTROSPECTION (additive)
   * ---------------------------------------------------------- */
  function getCurrentPostId() { return currentPostId; }
  function setCurrentPostId(pid) { currentPostId = pid; }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original globals — preserved so feature 038 (popstate +
   * [data-close]), feature 051, and any caller that still
   * references the legacy names keeps working unchanged. */
  window.openComments            = open;
  window.detachCommentsListener  = detachListener;
  window.detachCommentReactions  = detachReactions;
  window.sendComment             = send;

  window.SaikoCommentsList = {
    open: open,
    detachListener: detachListener,
    detachReactions: detachReactions,
    send: send,
    bind: bind,
    unbind: unbind,
    getCurrentPostId: getCurrentPostId,
    setCurrentPostId: setCurrentPostId
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * The overlay and its controls are static in index.html, so
   * binding at DOM ready is safe.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 068 — comments-list (legacy) ready');
  } catch (e) {}

})();