/* ============================================================
 * FEATURE:        Restricted Posts + Review Requests
 * FEATURE NUMBER: 092
 * FILE:           js/feed/092-restricted-requests.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "restricted posts" subsystem:
 *
 *     1. LIVE LISTENER on `posts` filtered to:
 *          p.uid === myUid && isSuspended(p)
 *        → window.restrictedPosts
 *
 *     2. LIVE LISTENER on `restrictionRequests`
 *        → window.restrictionRequests
 *
 *     3. renderRestrictedPosts() — renders the restricted list
 *        into #restrictedBody showing:
 *          • the suspension reason + date
 *          • the current review status when a request exists
 *            ("Review: pending · <admin reply>")
 *          • a "Request review" button when no active request
 *            exists (or the last one was rejected)
 *
 *   Exposed globally so:
 *     • boot.js's startGlobalListeners can call startRestrictedPosts()
 *     • page-renderers.js openRestrictedPosts() delegates to
 *       renderRestrictedPosts() when available
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §26 SAVED / HASHTAGS / TRENDING — startRestrictedPosts,
 *   restrictedPostsRef/Cb, restrictionRequestsRef/Cb,
 *   restrictedPosts map, restrictionRequests map,
 *   renderRestrictedPosts().
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var postsRef = null, postsCb = null;
  var reqsRef  = null, reqsCb  = null;

  window.restrictedPosts     = window.restrictedPosts     || {};
  window.restrictionRequests = window.restrictionRequests || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) { return ''; }
  }
  function fmtDate(ts) {
    try { if (typeof window.fmtDate === 'function') return window.fmtDate(ts); }
    catch (e) { return ''; }
  }
  function fmtTime(ts) {
    try { if (typeof window.fmtTime === 'function') return window.fmtTime(ts); }
    catch (e) { return ''; }
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[restricted-requests] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function isSuspended(obj) {
    try {
      if (typeof window.isSuspended === 'function') return !!window.isSuspended(obj);
    } catch (e) {}
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > timeNow()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > timeNow();
  }
  function isOverlayOpen() {
    var ov = qs('#ovRestricted');
    return !!(ov && ov.classList.contains('open'));
  }

  /* ============================================================
   * START LISTENERS
   * ============================================================ */
  function startRestrictedPosts() {
    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    /* ---- 1) posts/{all} filtered to my suspended --------- */
    if (!(postsRef && postsCb)) {
      postsRef = fbDb.ref('posts');
      postsCb = postsRef.on('value', function (s) {
        var v = s.val() || {};
        var out = {};
        Object.keys(v).forEach(function (k) {
          var p = Object.assign({ id: k }, v[k]);
          if (p.uid === uid && isSuspended(p)) out[k] = p;
        });
        window.restrictedPosts = out;

        if (isOverlayOpen()) renderRestrictedPosts();
      });
    }

    /* ---- 2) restrictionRequests (whole tree, filtered by uid at render) */
    if (!(reqsRef && reqsCb)) {
      reqsRef = fbDb.ref('restrictionRequests');
      reqsCb = reqsRef.on('value', function (s) {
        window.restrictionRequests = s.val() || {};
        if (isOverlayOpen()) renderRestrictedPosts();
      });
    }

    return true;
  }

  function detachRestrictedPosts() {
    if (postsRef && postsCb) { try { postsRef.off('value', postsCb); } catch (e) {} }
    if (reqsRef  && reqsCb)  { try { reqsRef.off('value',  reqsCb);  } catch (e) {} }
    postsRef = postsCb = reqsRef = reqsCb = null;
    window.restrictedPosts     = {};
    window.restrictionRequests = {};
    return true;
  }

  /* ============================================================
   * RENDER
   * ============================================================
   * Preserved 1:1 from the original renderRestrictedPosts().
   * Reads window.restrictedPosts + window.restrictionRequests,
   * shows review status per post, and only offers the
   * "Request review" button when no active request exists
   * (or the last request was rejected).
   * ============================================================ */
  function renderRestrictedPosts() {
    var body = qs('#restrictedBody');
    if (!body) return false;

    var uid = getMyUid();
    var list = Object.keys(window.restrictedPosts || {}).map(function (k) {
      return window.restrictedPosts[k];
    }).sort(function (a, b) {
      return (b.suspendedAt || b.createdAt || 0) - (a.suspendedAt || a.createdAt || 0);
    });

    if (!list.length) {
      body.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('shield') + '</span>' +
          '<p>No restricted posts</p>' +
        '</div>';
      return true;
    }

    /* Build a lookup of my active request per postId --------- */
    var requestsById = {};
    try {
      var reqsAll = window.restrictionRequests || {};
      Object.keys(reqsAll).forEach(function (rid) {
        var r = reqsAll[rid];
        if (!r || r.uid !== uid || !r.postId) return;
        var cur = requestsById[r.postId];
        if (!cur || (r.createdAt || 0) > (cur.createdAt || 0)) {
          requestsById[r.postId] = r;
        }
      });
    } catch (e) {}

    body.innerHTML = list.map(function (p) {
      var reason = p.suspendReason || 'Violated community guidelines';
      var since  = p.suspendedAt || p.createdAt;
      var reqFor = requestsById[p.id] || null;

      var reqStatusLabel = reqFor
        ? ('Review: ' + (reqFor.status || 'pending') +
           (reqFor.adminReply ? ' · ' + reqFor.adminReply : ''))
        : '';

      var currentStatus = reqFor ? T('pending_review') : T('restricted');
      var canRequest = !reqFor || reqFor.status === 'rejected';

      var img = p.image || (Array.isArray(p.images) && p.images.length ? p.images[0] : '');

      return '<div class="card">' +
        '<div class="row" style="justify-content:space-between;align-items:flex-start">' +
          '<span class="restricted-badge">' + svgIcon('alert') + ' ' + esc(T('restricted')) + '</span>' +
          '<span class="mini">' + esc(timeAgo(since)) + '</span>' +
        '</div>' +
        (p.text ? '<div class="post-text" style="margin-top:.5rem">' + esc(String(p.text).slice(0, 220)) + '</div>' : '') +
        (img ? '<div style="margin:.4rem 0"><img src="' + esc(img) + '" style="max-height:10rem;border-radius:.7rem" /></div>' : '') +
        '<div class="mini" style="margin-top:.4rem"><b>' + esc(T('restriction_reason')) + ':</b> ' + esc(reason) + '</div>' +
        '<div class="mini"><b>' + esc(T('suspended_on')) + ':</b> ' + esc(fmtDate(since)) + ' ' + esc(fmtTime(since)) + '</div>' +
        '<div class="mini"><b>' + esc(T('current_status')) + ':</b> ' + esc(currentStatus) + '</div>' +
        (reqFor ? '<div class="mini" style="color:var(--accent)">' + esc(reqStatusLabel) + '</div>' : '') +
        (canRequest
          ? '<button class="btn sm solid" data-rr-open="' + esc(p.id) + '" style="margin-top:.6rem">' + esc(T('request_review')) + '</button>'
          : '') +
      '</div>';
    }).join('');

    /* Wire each "Request review" button ---------------------- */
    var nodes = body.querySelectorAll('[data-rr-open]');
    for (var i = 0; i < nodes.length; i++) {
      (function (n) {
        n.addEventListener('click', function () {
          safeCall('openRestrictionRequest', [n.getAttribute('data-rr-open')]);
        });
      })(nodes[i]);
    }

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startRestrictedPosts   = startRestrictedPosts;
  window.detachRestrictedPosts  = detachRestrictedPosts;
  window.renderRestrictedPosts  = renderRestrictedPosts;

  window.SaikoRestrictedRequests = {
    start: startRestrictedPosts,
    detach: detachRestrictedPosts,
    render: renderRestrictedPosts,
    getPosts: function () { return window.restrictedPosts; },
    getRequests: function () { return window.restrictionRequests; }
  };

  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 092 — restricted-requests ready');
  } catch (e) {}

})();