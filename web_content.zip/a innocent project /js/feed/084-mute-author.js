/* ============================================================
 * FEATURE:        Mute Author
 * FEATURE NUMBER: 084
 * FILE:           js/feed/084-mute-author.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused toggle for muting an author's posts out of the
 *   current user's feed. Muted authors are filtered out by
 *   feature 051's isVisiblePost() predicate (via
 *   window.iMutedAuthor) and by the muted-users settings page
 *   (feature 040).
 *
 *   Public functions:
 *     window.iMutedAuthor(uid)             → boolean
 *     window.muteAuthor(uid)               → Promise<boolean>
 *     window.toggleMuteAuthor(uid)         → Promise<boolean>
 *                                              (same as above)
 *     window.startMutedAuthorsListener()   → boolean
 *     window.detachMutedAuthorsListener()  → boolean
 *
 *   Behaviour preserved 1:1 from the original source:
 *
 *     • Live listener on mutedAuthors/{myUid} writes into
 *       window.mutedAuthors and re-renders the home feed when
 *       active.
 *     • Toggle:
 *         if muted  → remove + toast(t('unmute_author'), 'ok')
 *         else      → set true + toast(t('mute_author'), 'ok')
 *       Both writes are `.catch(() => {})` best-effort.
 *
 *   The ORIGINAL §13 startAdminSync() setup listener for
 *   mutedAuthors also triggered a re-render of the feed if the
 *   user was on the home tab. That behaviour is preserved here
 *   via the feed-render public API.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10  AUTH side → let mutedAuthors = {},
 *                            mutedRef, mutedCb (created inside
 *                            listenBlocked)
 *   Section §13  ADMIN     → iMutedAuthor(uid)
 *   Section §15  FEED      → openPostMenu() → case 'muteauthor'
 *   Section §30  SETTINGS  → mutedHTML() + wireMuted()
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - renderFeed             js/feed/051-feed-render.js
 *                            (safely-called)
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none directly — mute changes propagate via the feed
 *   re-render triggered from the live listener.
 *
 * FIREBASE PATHS:
 *   mutedAuthors/{uid}                   (read + listen)
 *   mutedAuthors/{uid}/{authorUid}       (set true / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.mutedAuthors                  (live map)
 *   window.iMutedAuthor
 *   window.muteAuthor
 *   window.toggleMuteAuthor
 *   window.startMutedAuthorsListener
 *   window.detachMutedAuthorsListener
 *   window.SaikoMuteAuthor = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var mutedRef = null;
  var mutedCb  = null;

  /* Live map — exposed on window so feature 051's
   * isVisiblePost() predicate can read it without going
   * through a getter. Same global shape as the original
   * single-file build. */
  window.mutedAuthors = window.mutedAuthors || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[mute-author] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * PREDICATE
   * Preserved 1:1 from original iMutedAuthor(uid).
   * ============================================================ */
  function isMuted(uid) {
    if (!uid) return false;
    return !!window.mutedAuthors[uid];
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================
   * Attach a live listener on mutedAuthors/{uid}. Whenever the
   * map changes we re-render the feed (only if the user is on
   * the home tab) so newly-muted or newly-unmuted posts appear
   * / disappear immediately.
   *
   * The original wired this inside listenBlocked() alongside
   * other per-user listeners; here it is a self-contained
   * start/detach pair for clean teardown on logout.
   * ============================================================ */
  function startListener() {
    if (mutedRef && mutedCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    mutedRef = fbDb.ref('mutedAuthors/' + uid);
    mutedCb  = mutedRef.on('value', function (s) {
      window.mutedAuthors = s.val() || {};
      if (typeof window.currentNav === 'string' && window.currentNav === 'home') {
        safeCall('renderFeed', [true]);
      }
    });
    return true;
  }

  function detachListener() {
    if (mutedRef && mutedCb) {
      try { mutedRef.off('value', mutedCb); } catch (e) {}
    }
    mutedRef = null;
    mutedCb  = null;
    window.mutedAuthors = {};
    return true;
  }

  /* ============================================================
   * TOGGLE
   * Preserved 1:1 from the original `case 'muteauthor'` branch.
   * ============================================================ */
  async function toggle(uid) {
    if (!uid) return false;

    var fbDb = getDB();
    var myUid = getMyUid();
    if (!fbDb || !myUid) return false;

    try {
      if (isMuted(uid)) {
        /* --- UNMUTE ------------------------------------- */
        await fbDb.ref('mutedAuthors/' + myUid + '/' + uid).remove();
        safeToast(T('unmute_author'), 'ok');
      } else {
        /* --- MUTE -------------------------------------- */
        await fbDb.ref('mutedAuthors/' + myUid + '/' + uid).set(true);
        safeToast(T('mute_author'), 'ok');
      }

      /* Notify subscribers (additive) -------------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:mute-changed', {
          detail: { authorUid: uid, muted: !isMuted(uid) }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      /* Original swallowed write errors silently. */
      return false;
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global predicate — preserved so feature 051's
   * isVisiblePost() keeps working unchanged. */
  window.iMutedAuthor = isMuted;

  /* Toggle — used by feature 088 (openPostMenu) and the
   * muted-users settings page (feature 040). */
  window.muteAuthor       = toggle;
  window.toggleMuteAuthor = toggle;

  /* Listener lifecycle — used by boot.js and logout teardown. */
  window.startMutedAuthorsListener  = startListener;
  window.detachMutedAuthorsListener = detachListener;

  window.SaikoMuteAuthor = {
    isMuted: isMuted,
    toggle: toggle,
    startListener: startListener,
    detachListener: detachListener,
    getMap: function () { return window.mutedAuthors; },
    getCount: function () { return Object.keys(window.mutedAuthors || {}).length; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 084 — mute-author ready');
  } catch (e) {}

})();