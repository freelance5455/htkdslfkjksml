/* ============================================================
 * FEATURE:        Gallery Viewer
 * FEATURE NUMBER: 075
 * FILE:           js/feed/075-gallery-viewer.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The fullscreen image viewer (#ovViewer). Shows one image
 *   at a time from a list, with:
 *     • Left / right tap zones for prev / next
 *     • Horizontal swipe gestures (touch)
 *     • Counter "N / M"
 *     • Share button  — Web Share API / clipboard fallback
 *     • Download button — Cloudinary fetch → file save
 *     • Single-image mode via openViewer(url)
 *
 *   Behaviour preserved 1:1 from the original §16 GALLERY
 *   VIEWER block.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §16 COMPOSER / GALLERY VIEWER
 *     let galleryImgs = [], galleryIdx = 0, galleryPid = null
 *     openGallery(imgs, idx, pid)
 *     showGalleryIdx()
 *     openViewer(url)
 *     #viewerPrev click
 *     #viewerNext click
 *     #viewerWrap touch start/end
 *     #viewerShare click
 *     #viewerDownload click
 *
 * DEPENDENCIES (loaded earlier):
 *   - downloadMedia          js/core/media-download.js
 *                            (feature 024-area utility)
 *   - openOverlay / closeOverlay
 *                            js/nav/038-overlay-system.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   #ovViewer, #viewerImg, #viewerCounter, #viewerWrap,
 *   #viewerPrev, #viewerNext, #viewerShare, #viewerDownload
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openGallery
 *   window.openViewer
 *   window.showGalleryIdx
 *   window.SaikoGalleryViewer = {
 *     open, openSingle, showIndex,
 *     next, prev, share, download,
 *     bind, unbind,
 *     getState
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var galleryImgs = [];
  var galleryIdx  = 0;
  var galleryPid  = null;

  /* Swipe tracking */
  var swipeStartX = 0;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[gallery-viewer] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * SHOW CURRENT INDEX
   * Preserved 1:1 from original showGalleryIdx():
   *   • set #viewerImg.src to current image
   *   • set #viewerCounter text to "N / M"
   * ============================================================ */
  function showIndex() {
    var img = qs('#viewerImg');
    if (img) img.src = galleryImgs[galleryIdx] || '';

    var counter = qs('#viewerCounter');
    if (counter) {
      counter.textContent = (galleryIdx + 1) + ' / ' + galleryImgs.length;
    }
  }

  /* ============================================================
   * OPEN GALLERY — main entry
   * Preserved 1:1 from original openGallery(imgs, idx, pid).
   * ============================================================ */
  function openGallery(imgs, idx, pid) {
    if (!imgs || !imgs.length) return false;

    /* Normalise copies so caller's array is not mutated */
    galleryImgs = imgs.slice();
    galleryIdx  = Number(idx) || 0;
    if (galleryIdx < 0) galleryIdx = 0;
    if (galleryIdx >= galleryImgs.length) galleryIdx = galleryImgs.length - 1;
    galleryPid  = pid || null;

    safeCall('openOverlay', ['ovViewer']);
    showIndex();

    /* Wire the share / download buttons for this session.
     * (We re-bind per open — the original source did the same
     * via inline `onclick` assignments.) */
    var shareBtn = qs('#viewerShare');
    if (shareBtn) {
      shareBtn.onclick = function () { share(); };
    }
    var dlBtn = qs('#viewerDownload');
    if (dlBtn) {
      dlBtn.onclick = function () { download(); };
    }

    return true;
  }

  /* ============================================================
   * OPEN SINGLE VIEWER
   * Preserved 1:1 from original openViewer(url):
   *   → openGallery([url], 0, null)
   * ============================================================ */
  function openViewer(url) {
    if (!url) return false;
    return openGallery([url], 0, null);
  }

  /* ============================================================
   * NAVIGATION
   * ============================================================ */
  function next() {
    if (galleryIdx < galleryImgs.length - 1) {
      galleryIdx++;
      showIndex();
    }
  }

  function prev() {
    if (galleryIdx > 0) {
      galleryIdx--;
      showIndex();
    }
  }

  /* ============================================================
   * SHARE
   * Preserved 1:1 from original #viewerShare click handler.
   *   • try navigator.share({ url })
   *   • else if clipboard → copy url + toast(t('copied'), 'ok')
   *   • errors silently swallowed
   * ============================================================ */
  async function share() {
    var url = galleryImgs[galleryIdx];
    if (!url) return false;

    try {
      if (navigator && typeof navigator.share === 'function') {
        await navigator.share({ url: url });
        return true;
      } else if (navigator && navigator.clipboard &&
                 typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(url);
        safeToast(T('copied'), 'ok');
        return true;
      }
    } catch (e) {}
    return false;
  }

  /* ============================================================
   * DOWNLOAD
   * Preserved 1:1 from original #viewerDownload click handler:
   *   • read current URL
   *   • pick a file extension from the URL
   *   • delegate to downloadMedia(url, filename)
   * ============================================================ */
  function download() {
    var url = galleryImgs[galleryIdx];
    if (!url) return false;

    /* Extension heuristic from the original:
     *   (url.split('.').pop() || 'jpg').split('?')[0].slice(0,4) */
    var ext = (url.split('.').pop() || 'jpg').split('?')[0].slice(0, 4);
    var filename = 'innocentsaiko-image-' + Date.now() + '.' + ext;

    safeCall('downloadMedia', [url, filename]);
    return true;
  }

  /* ============================================================
   * SWIPE HANDLERS
   * Preserved 1:1 from the original anonymous IIFE:
   *   touchstart → record x
   *   touchend   → compare, > 50px delta triggers prev/next
   * ============================================================ */
  function onTouchStart(e) {
    if (!e.touches || !e.touches.length) return;
    swipeStartX = e.touches[0].clientX;
  }

  function onTouchEnd(e) {
    if (!e.changedTouches || !e.changedTouches.length) return;
    var dx = e.changedTouches[0].clientX - swipeStartX;
    if (Math.abs(dx) > 50) {
      if (dx < 0 && galleryIdx < galleryImgs.length - 1) {
        galleryIdx++;
        showIndex();
      } else if (dx > 0 && galleryIdx > 0) {
        galleryIdx--;
        showIndex();
      }
    }
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* Prev tap zone ---------------------------------------- */
    var pv = qs('#viewerPrev');
    if (pv && pv.dataset.galleryBound !== '1') {
      pv.dataset.galleryBound = '1';
      pv.addEventListener('click', prev);
      bound = true;
    }

    /* Next tap zone --------------------------------------- */
    var nx = qs('#viewerNext');
    if (nx && nx.dataset.galleryBound !== '1') {
      nx.dataset.galleryBound = '1';
      nx.addEventListener('click', next);
      bound = true;
    }

    /* Wrap swipe gestures -------------------------------- */
    var wrap = qs('#viewerWrap');
    if (wrap && wrap.dataset.galleryBound !== '1') {
      wrap.dataset.galleryBound = '1';
      wrap.addEventListener('touchstart', onTouchStart, { passive: true });
      wrap.addEventListener('touchend',   onTouchEnd,   { passive: true });
      bound = true;
    }

    /* Share & download are re-bound per open via onclick.
     * No dataset guard needed there — assignment is
     * idempotent by design. */

    return bound;
  }

  function unbind(root) {
    var scope = root || document;

    var pv = qs('#viewerPrev');
    if (pv) {
      pv.removeEventListener('click', prev);
      delete pv.dataset.galleryBound;
    }

    var nx = qs('#viewerNext');
    if (nx) {
      nx.removeEventListener('click', next);
      delete nx.dataset.galleryBound;
    }

    var wrap = qs('#viewerWrap');
    if (wrap) {
      wrap.removeEventListener('touchstart', onTouchStart);
      wrap.removeEventListener('touchend',   onTouchEnd);
      delete wrap.dataset.galleryBound;
    }

    var shareBtn = qs('#viewerShare');
    if (shareBtn) shareBtn.onclick = null;

    var dlBtn = qs('#viewerDownload');
    if (dlBtn) dlBtn.onclick = null;
  }

  /* ============================================================
   * STATE INTROSPECTION (additive)
   * ============================================================ */
  function getState() {
    return {
      images: galleryImgs.slice(),
      index: galleryIdx,
      postId: galleryPid
    };
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openGallery     = openGallery;
  window.openViewer      = openViewer;
  window.showGalleryIdx  = showIndex;

  window.SaikoGalleryViewer = {
    open: openGallery,
    openSingle: openViewer,
    showIndex: showIndex,
    next: next,
    prev: prev,
    share: share,
    download: download,
    bind: bind,
    unbind: unbind,
    getState: getState
  };

  /* ============================================================
   * AUTO-BIND
   * The viewer overlay is static in index.html, so binding at
   * DOM ready is safe.
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 075 — gallery-viewer ready');
  } catch (e) {}

})();