/* ============================================================
 * FEATURE:        Share Post
 * FEATURE NUMBER: 062
 * FILE:           js/feed/062-share-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused entry point for sharing a post. Uses the best
 *   available mechanism in the current browser, in this order:
 *
 *     1. Web Share API          (navigator.share)
 *        → native share sheet on mobile
 *     2. Clipboard              (navigator.clipboard.writeText)
 *        → copies "<text>\n<url>" and toasts t('link_copied')
 *     3. Fallback               (toast(url))
 *        → just shows the URL in a toast
 *
 *   Public function:
 *     window.sharePost(postId)   → Promise<boolean>
 *
 *   Behaviour preserved 1:1 from the original source's
 *   sharePost(pid):
 *
 *     • Look up the post in window.postsCache
 *     • Bail silently if the post is missing
 *     • Build text = post.text.slice(0, 160) || t('app_name')
 *     • Build url  = origin + pathname + '#post-' + pid
 *       (matches feature 047 deep-link format)
 *     • Try navigator.share → { title: t('app_name'), text, url }
 *     • If Share API is unavailable, try clipboard with
 *       text + '\n' + url, then toast t('link_copied')
 *     • Final fallback → toast(url)
 *     • Any error during the share sheet (e.g. user cancels)
 *       is silently swallowed
 *
 *   Feature 051 (feed render, wirePostInteractions) and
 *   feature 088 (openPostMenu, "share" case) both call
 *   window.sharePost(pid) — this file supplies that global.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → sharePost(pid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache      (feature 051)
 *   - toast                  (feature 042)
 *   - t(key)                 (046 i18n)
 *
 * DOM ELEMENTS USED:
 *   none — pure navigator + toast.
 *
 * FIREBASE PATHS:
 *   none.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.sharePost
 *   window.SaikoSharePost = {
 *     share, buildUrl, buildText,
 *     canUseShareApi, canUseClipboard
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — match the original 160-char trim.
   * ---------------------------------------------------------- */
  var TEXT_LIMIT = 160;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function findPost(postId) {
    if (!postId) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === postId) return p;
        }
      }
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * Capability detection — wrapped so we never throw on old
   * browsers that lack navigator.share / navigator.clipboard.
   * ---------------------------------------------------------- */
  function canUseShareApi() {
    try { return !!(navigator && typeof navigator.share === 'function'); }
    catch (e) { return false; }
  }

  function canUseClipboard() {
    try { return !!(navigator && navigator.clipboard && typeof navigator.clipboard.writeText === 'function'); }
    catch (e) { return false; }
  }

  /* ----------------------------------------------------------
   * buildText(post)
   * Preserved from the original: first 160 chars of text, or
   * the app name when the post has no caption.
   * ---------------------------------------------------------- */
  function buildText(post) {
    if (!post) return T('app_name');
    var raw = (post.text || '');
    var trimmed = raw.slice(0, TEXT_LIMIT);
    return trimmed || T('app_name');
  }

  /* ----------------------------------------------------------
   * buildUrl(postId)
   * Preserved from the original:
   *   location.origin + location.pathname + '#post-' + pid
   * Matches the deep-link format consumed by feature 047.
   * ---------------------------------------------------------- */
  function buildUrl(postId) {
    try {
      return location.origin + location.pathname + '#post-' + postId;
    } catch (e) {
      return '#post-' + postId;
    }
  }

  /* ----------------------------------------------------------
   * share(postId)
   * Preserved 1:1 from the original sharePost().
   *
   * Returns Promise<boolean>:
   *   true  — a share / copy / fallback path was executed
   *   false — the post could not be resolved
   * ---------------------------------------------------------- */
  async function share(postId) {
    if (!postId) return false;

    /* 1) Resolve the post --------------------------------- */
    var post = findPost(postId);
    if (!post) return false;

    /* 2) Build the payload -------------------------------- */
    var text = buildText(post);
    var url  = buildUrl(postId);

    /* 3) Try each transport in order ---------------------- */
    try {
      /* 3a) Native share sheet --------------------------- */
      if (canUseShareApi()) {
        await navigator.share({
          title: T('app_name'),
          text: text,
          url: url
        });
        emit('shared', postId, 'share-api');
        return true;
      }

      /* 3b) Clipboard ------------------------------------ */
      if (canUseClipboard()) {
        await navigator.clipboard.writeText(text + '\n' + url);
        safeToast(T('link_copied'), 'ok');
        emit('shared', postId, 'clipboard');
        return true;
      }

      /* 3c) Fallback — show the URL in a toast ----------- */
      safeToast(url);
      emit('shared', postId, 'fallback');
      return true;

    } catch (e) {
      /* Silently swallow — matches the original source.
       * Typical trigger: user dismisses the native share
       * sheet (AbortError). No toast, no rethrow. */
      return false;
    }
  }

  /* ----------------------------------------------------------
   * Event emitter — additive. Fires on window so analytics
   * or preview modules can observe shares without polling.
   * ---------------------------------------------------------- */
  function emit(kind, postId, transport) {
    try {
      window.dispatchEvent(new CustomEvent('saiko:post-shared', {
        detail: { postId: postId, transport: transport }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.sharePost = share;

  window.SaikoSharePost = {
    share: share,
    buildUrl: buildUrl,
    buildText: buildText,
    canUseShareApi: canUseShareApi,
    canUseClipboard: canUseClipboard
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 062 — share-post ready');
  } catch (e) {}

})();