/* ============================================================
 * FEATURE:        Gallery Download (Media Download Helper)
 * FEATURE NUMBER: 077
 * FILE:           js/feed/077-gallery-download.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused, reusable download helper for any media URL:
 *   gallery images, chat images, story images, avatar / cover
 *   photos, or any HTTPS asset the app displays.
 *
 *   Behaviour preserved 1:1 from the original source's
 *   downloadMedia(url, filename) helper (§5 UTILITIES):
 *
 *     1. `fetch(url, { mode:'cors' })`
 *     2. If the response is not ok → fall through to the
 *        window.open fallback.
 *     3. Blob → ObjectURL → anchor.download → click → remove
 *     4. ObjectURL revoked after 5 s.
 *     5. On success → toast t('saved_to_device') as 'ok'.
 *     6. Any fetch/CORS error → try window.open(url, '_blank')
 *        and toast t('opening_image').
 *     7. Final fallback (both paths fail) → toast t('error')
 *        as 'err'.
 *
 *   Public function:
 *     window.downloadMedia(url, filename)  → Promise<boolean>
 *
 *   Also exposed:
 *     window.SaikoGalleryDownload = {
 *       download,
 *       buildFilename,        // pure ext/prefix helper
 *       guessExtension,       // pure url → ext
 *       isDataUrl,            // quick guard
 *     }
 *
 *   NOTE: The viewer's #viewerDownload button in feature 075
 *   uses SaikoGalleryViewer.download() which itself delegates
 *   to window.downloadMedia(). This module supplies that
 *   global. Any other caller that wants the same behaviour
 *   (chat image, story, avatar, cover) can call
 *   SaikoGalleryDownload.download(url, filename) directly.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §5 UTILITIES → async function downloadMedia(
 *       url, filename) { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   - toast                  js/nav/042-toast.js
 *                            (safely-called)
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none  (creates a temporary <a> that is removed immediately)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.downloadMedia
 *   window.SaikoGalleryDownload = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ----------------------------------------------------------
   * guessExtension(url)
   * Preserved 1:1 from the original inline expression:
   *   (url.split('.').pop() || 'jpg').split('?')[0].slice(0,4)
   *
   * Returns a 1–4 character lowercase-safe extension, default
   * 'jpg' when the URL has no discernible one.
   * ---------------------------------------------------------- */
  function guessExtension(url) {
    if (!url) return 'jpg';
    try {
      var parts = String(url).split('.');
      var last = parts.length > 1 ? parts[parts.length - 1] : '';
      if (!last) return 'jpg';
      var noQuery = last.split('?')[0];
      if (!noQuery) return 'jpg';
      return noQuery.slice(0, 4);
    } catch (e) {
      return 'jpg';
    }
  }

  /* ----------------------------------------------------------
   * buildFilename(prefix, url)
   * Convenience — produces "prefix-<timestamp>.<ext>".
   * Default prefix is 'innocentsaiko-image' (matches the
   * gallery viewer's default in feature 075).
   * ---------------------------------------------------------- */
  function buildFilename(prefix, url) {
    var p = prefix || 'innocentsaiko-image';
    var ext = guessExtension(url);
    return p + '-' + timeNow() + '.' + ext;
  }

  /* ----------------------------------------------------------
   * isDataUrl(url)
   * Quick guard — data: URLs are skipped from the fetch()
   * path (they are already local, and some browsers reject
   * CORS-mode fetches on them).
   * ---------------------------------------------------------- */
  function isDataUrl(url) {
    return typeof url === 'string' && url.indexOf('data:') === 0;
  }

  /* ----------------------------------------------------------
   * isSameOrigin(url)
   * Quick guard used by the fetch path — if we're already on
   * the same origin, CORS mode is harmless but unnecessary.
   * Kept simple so it never throws on weird inputs.
   * ---------------------------------------------------------- */
  function isSameOrigin(url) {
    try {
      var a = document.createElement('a');
      a.href = url;
      return a.origin === location.origin;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * triggerAnchorDownload(objectUrl, filename)
   * The final step of the fetch path — creates an off-DOM
   * anchor with the download attribute, clicks it, removes it.
   * ---------------------------------------------------------- */
  function triggerAnchorDownload(objectUrl, filename) {
    var a = document.createElement('a');
    a.href = objectUrl;
    a.download = filename;
    /* Ensure the anchor is in the DOM for older browsers to
     * actually respect .click() (Safari < 15 quirk). */
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  /* ----------------------------------------------------------
   * openInNewTab(url)
   * Fallback path when fetch fails (CORS, 4xx, network).
   * ---------------------------------------------------------- */
  function openInNewTab(url) {
    try {
      var w = window.open(url, '_blank');
      /* Some ad-blockers / pop-up blockers return null. */
      return !!w || true; /* Preserve original behaviour — the
                             original always showed the toast
                             regardless of popup success. */
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * download(url, filename) → Promise<boolean>
   * Preserved 1:1 from the original downloadMedia(url, filename):
   *   • fetch in CORS mode
   *   • blob → object URL → anchor click
   *   • revoke object URL after 5 s
   *   • toast saved_to_device on success
   *   • on fetch error → window.open + toast opening_image
   *   • on final failure → toast error
   * ---------------------------------------------------------- */
  async function download(url, filename) {
    if (!url) return false;

    var fname = filename || buildFilename(null, url);
    var objUrl = null;

    /* --- FAST PATH: data: URLs ---------------------------- *
     * Data URLs cannot be fetched in cors mode safely on
     * every browser; the anchor.download path works directly.
     * ------------------------------------------------------ */
    if (isDataUrl(url)) {
      try {
        triggerAnchorDownload(url, fname);
        safeToast(T('saved_to_device'), 'ok');
        return true;
      } catch (e) {
        safeToast(T('error'), 'err');
        return false;
      }
    }

    /* --- PRIMARY PATH: fetch → blob → anchor -------------- */
    try {
      var res = await fetch(url, { mode: 'cors' });
      if (!res.ok) {
        throw new Error('HTTP ' + res.status);
      }
      var blob = await res.blob();

      objUrl = URL.createObjectURL(blob);
      triggerAnchorDownload(objUrl, fname);

      /* Revoke after a short delay so the download can start
       * even on slower devices. Matches the original 5 s. */
      setTimeout(function () {
        try { URL.revokeObjectURL(objUrl); } catch (e) {}
      }, 5000);

      safeToast(T('saved_to_device'), 'ok');
      return true;
    } catch (fetchErr) {
      /* --- FALLBACK PATH: open in new tab ---------------- */
      try {
        openInNewTab(url);
        safeToast(T('opening_image'));
        return true;
      } catch (e2) {
        safeToast(T('error'), 'err');
        return false;
      }
    } finally {
      /* Safety net — if we reached here through a non-fatal
       * path and objUrl was created but we somehow skipped the
       * scheduled revoke, this prevents a leak. */
      if (objUrl) {
        setTimeout(function () {
          try { URL.revokeObjectURL(objUrl); } catch (e) {}
        }, 6000);
      }
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so feature 075, feature 142
   * (chat image), feature 187 (story), feature 040 (avatar
   * viewer), and any other caller keeps working unchanged. */
  window.downloadMedia = download;

  window.SaikoGalleryDownload = {
    download: download,
    buildFilename: buildFilename,
    guessExtension: guessExtension,
    isDataUrl: isDataUrl,
    isSameOrigin: isSameOrigin
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 077 — gallery-download ready');
  } catch (e) {}

})();