/* ============================================================
 * FEATURE:        Pin Post (max 3)
 * FEATURE NUMBER: 059
 * FILE:           js/feed/059-pin-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused toggle for pinning a post to the current user's
 *   profile. A user may pin at most MAX_PINS (3) posts at a
 *   time; the guard is enforced before any write.
 *
 *   Public functions:
 *     window.pinPost(postId)           → Promise<boolean>
 *     window.togglePinPost(postId)     → Promise<boolean> (alias)
 *
 *   Behaviour preserved 1:1 from the original source's
 *   openPostMenu() "pin" branch:
 *
 *     • If the post is already pinned → remove it, toast
 *       t('unpin_post').
 *     • Otherwise → count existing pins; if >= 3, toast
 *       t('max_pins') and abort. Otherwise set the pin and
 *       toast t('pinned').
 *     • Every write is `.catch(()=>{})` best-effort — a
 *       network hiccup never bubbles up as an exception.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu() → case 'pin'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none — pure state + Firebase.
 *
 * FIREBASE PATHS (read + write):
 *   users/{uid}/pinnedPosts/{pid}   (set true / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.pinPost
 *   window.togglePinPost
 *   window.SaikoPinPost = {
 *     toggle, pin, unpin,
 *     isPinned, getCount, MAX_PINS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  var MAX_PINS = 3;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * isPinned(postId)
   * Reads from the live myProfile.pinnedPosts map. Returns
   * false when either the map or the entry is missing.
   * ---------------------------------------------------------- */
  function isPinned(postId) {
    if (!postId) return false;
    var me = getMyProfile();
    if (!me || !me.pinnedPosts) return false;
    return !!me.pinnedPosts[postId];
  }

  /* ----------------------------------------------------------
   * getCount()
   * How many posts the current user currently has pinned.
   * ---------------------------------------------------------- */
  function getCount() {
    var me = getMyProfile();
    if (!me || !me.pinnedPosts) return 0;
    return Object.keys(me.pinnedPosts).length;
  }

  /* ----------------------------------------------------------
   * pin(postId)
   * Write path for adding a pin. Enforces the MAX_PINS guard.
   * Returns Promise<boolean>:
   *   true  — write attempted
   *   false — refused (already pinned, or limit reached, or
   *           no user / no db)
   * ---------------------------------------------------------- */
  async function pin(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    /* 1) Already pinned? — nothing to do ------------------ */
    if (isPinned(postId)) return false;

    /* 2) Enforce the 3-pin limit -------------------------- */
    if (getCount() >= MAX_PINS) {
      safeToast(T('max_pins'), 'err');
      return false;
    }

    /* 3) Write the pin ------------------------------------ */
    try {
      await fbDb.ref('users/' + uid + '/pinnedPosts/' + postId).set(true);
    } catch (e) {
      /* Original swallowed the error silently. Preserved. */
      return false;
    }

    safeToast(T('pinned'), 'ok');
    emit('pinned', postId);
    return true;
  }

  /* ----------------------------------------------------------
   * unpin(postId)
   * Write path for removing a pin. No limit check needed.
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function unpin(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    if (!isPinned(postId)) return false;

    try {
      await fbDb.ref('users/' + uid + '/pinnedPosts/' + postId).remove();
    } catch (e) {
      return false;
    }

    safeToast(T('unpin_post'), 'ok');
    emit('unpinned', postId);
    return true;
  }

  /* ----------------------------------------------------------
   * toggle(postId)
   * Main entry point. Mirrors the original branch exactly:
   *   if (isPinned) → unpin
   *   else          → pin (with max-3 guard)
   * ---------------------------------------------------------- */
  async function toggle(postId) {
    if (!postId) return false;
    return isPinned(postId) ? unpin(postId) : pin(postId);
  }

  /* ----------------------------------------------------------
   * Event emitter — additive. Fires on window so any module
   * that wants to observe pin changes can subscribe without
   * polling myProfile.
   * ---------------------------------------------------------- */
  function emit(kind, postId) {
    try {
      window.dispatchEvent(new CustomEvent('saiko:pin-changed', {
        detail: { postId: postId, kind: kind }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.pinPost       = toggle;
  window.togglePinPost = toggle;

  window.SaikoPinPost = {
    toggle: toggle,
    pin: pin,
    unpin: unpin,
    isPinned: isPinned,
    getCount: getCount,
    MAX_PINS: MAX_PINS
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 059 — pin-post ready');
  } catch (e) {}

})();