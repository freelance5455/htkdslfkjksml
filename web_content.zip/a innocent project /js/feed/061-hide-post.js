/* ============================================================
 * FEATURE:        Hide Post
 * FEATURE NUMBER: 061
 * FILE:           js/feed/061-hide-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused entry point for hiding a post from the current
 *   user's own feed. The post itself is NOT deleted — only a
 *   per-user marker is written so that the feed renderer
 *   (feature 051) filters it out.
 *
 *   Public function:
 *     window.hidePost(postId)   → Promise<boolean>
 *
 *   Behaviour preserved 1:1 from the original source's
 *   openPostMenu() "hide" branch:
 *
 *     • Write hiddenPosts/{myUid}/{pid} = true
 *     • `.catch(()=>{})` — best-effort, a network hiccup is
 *       silently swallowed
 *     • On success, toast t('hidden')
 *
 *   The original code did NOT expose an "unhide" UI in the
 *   post options menu — once a post was hidden the only way to
 *   see it again was via the profile-owner's own view or by
 *   clearing the hiddenPosts node (e.g. clear-cache tool).
 *   We preserve that one-way UX here, but also expose a
 *   programmatic `unhide` for symmetry and for future tooling.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu() → case 'hide'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none — pure state + Firebase.
 *
 * FIREBASE PATHS (read + write):
 *   hiddenPosts/{uid}/{pid}   (set true / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.hidePost
 *   window.unhidePost
 *   window.SaikoHidePost = {
 *     hide, unhide,
 *     isHidden, getHiddenMap
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * isHidden(postId)
   * Reads the shared hidden map that feature 051 maintains
   * from the hiddenPosts/{uid} listener. Falls back to false
   * if the map is not yet populated.
   * ---------------------------------------------------------- */
  function isHidden(postId) {
    if (!postId) return false;
    try {
      if (window.SaikoFeedRender &&
          typeof window.SaikoFeedRender.getHiddenPosts === 'function') {
        var m = window.SaikoFeedRender.getHiddenPosts() || {};
        return !!m[postId];
      }
    } catch (e) {}
    return false;
  }

  /* ----------------------------------------------------------
   * getHiddenMap()
   * Returns the live hidden map (or an empty object).
   * ---------------------------------------------------------- */
  function getHiddenMap() {
    try {
      if (window.SaikoFeedRender &&
          typeof window.SaikoFeedRender.getHiddenPosts === 'function') {
        return window.SaikoFeedRender.getHiddenPosts() || {};
      }
    } catch (e) {}
    return {};
  }

  /* ----------------------------------------------------------
   * hide(postId)
   * Preserved 1:1 from the original `case 'hide'` branch.
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function hide(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    /* 1) Write the hidden marker ------------------------- */
    try {
      await fbDb.ref('hiddenPosts/' + uid + '/' + postId).set(true);
    } catch (e) {
      /* Original swallowed the error silently. Preserved. */
      return false;
    }

    /* 2) Toast ------------------------------------------ */
    safeToast(T('hidden'), 'ok');

    /* 3) Notify subscribers ----------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:post-hidden', {
        detail: { postId: postId }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * unhide(postId)
   * Symmetric counterpart, provided for future tooling
   * (profile "hidden posts" manager, clear-cache flows).
   * Not part of the original post-options menu.
   * Returns Promise<boolean>.
   * ---------------------------------------------------------- */
  async function unhide(postId) {
    if (!postId) return false;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    try {
      await fbDb.ref('hiddenPosts/' + uid + '/' + postId).remove();
    } catch (e) {
      return false;
    }

    try {
      window.dispatchEvent(new CustomEvent('saiko:post-unhidden', {
        detail: { postId: postId }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.hidePost   = hide;
  window.unhidePost = unhide;

  window.SaikoHidePost = {
    hide: hide,
    unhide: unhide,
    isHidden: isHidden,
    getHiddenMap: getHiddenMap
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 061 — hide-post ready');
  } catch (e) {}

})();