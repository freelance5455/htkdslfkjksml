/* ============================================================
 * FEATURE:        Comment Delete
 * FEATURE NUMBER: 072
 * FILE:           js/feed/072-comment-delete.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for deleting an existing comment. Extracts
 *   the "delete" branch that lives inline inside feature 067's
 *   openSplitCommentMenu() so any future comment surface
 *   (post-split, legacy overlay, reel comments, story replies)
 *   can reuse the same flow.
 *
 *   Behaviour preserved 1:1 from the original §17 POST SPLIT
 *   delete branch:
 *
 *     1. confirmDialog(t('delete_comment'), t('are_you_sure'))
 *     2. abort silently when the user cancels
 *     3. remove comments/{pid}/{cid}
 *     4. remove commentReactions/{pid}/{cid}
 *     5. on error, toast the error message
 *
 *   Public function:
 *     window.deleteComment(postId, commentId) → Promise<boolean>
 *
 *   NOTE: Replies to a deleted comment are NOT cascaded by the
 *   original source. If a parent comment is removed, its child
 *   replies still exist under comments/{pid} but become
 *   orphaned (parent points to a missing node). The original
 *   source did not clean them up and this module preserves that
 *   behaviour — see SaikoCommentDelete.cascadeRemoveReplies()
 *   for an opt-in helper if a caller ever needs the full
 *   cascade.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     openSplitCommentMenu() → case 'delete'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - confirmDialog          js/nav/043-confirm-dialog.js
 *                            (safely-called)
 *   - toast                  js/nav/042-toast.js
 *                            (safely-called)
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none directly — confirmDialog builds its own overlay.
 *
 * FIREBASE PATHS:
 *   comments/{pid}/{cid}                 (remove)
 *   commentReactions/{pid}/{cid}         (remove)
 *   comments/{pid}                       (read — optional,
 *                                          for the reply count
 *                                          shown in the confirm
 *                                          dialog if enabled)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.deleteComment
 *   window.SaikoCommentDelete = {
 *     delete: deleteComment,
 *     confirmAndDelete,
 *     cascadeRemoveReplies,
 *     buildRemovePaths,
 *     countReplies
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    /* If confirmDialog is missing, treat as "yes" so the flow
     * is never blocked. Matches the semantics of every other
     * feature file that wraps confirmDialog. */
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * buildRemovePaths(postId, commentId)
   * Pure — returns the exact ordered list of Firebase paths
   * that the delete flow removes. Exposed so callers can
   * preview, log, or batch these removals.
   * ---------------------------------------------------------- */
  function buildRemovePaths(postId, commentId) {
    if (!postId || !commentId) return [];
    return [
      'comments/' + postId + '/' + commentId,
      'commentReactions/' + postId + '/' + commentId
    ];
  }

  /* ----------------------------------------------------------
   * countReplies(postId, commentId) → Promise<number>
   * Optional helper — counts how many live comments are
   * direct replies to commentId. Useful when a caller wants to
   * warn the user ("This comment has 3 replies") before
   * deleting.
   * ---------------------------------------------------------- */
  async function countReplies(postId, commentId) {
    if (!postId || !commentId) return 0;
    var fbDb = getDB();
    if (!fbDb) return 0;
    try {
      var snap = await fbDb.ref('comments/' + postId).get();
      var v = snap.val() || {};
      var n = 0;
      var keys = Object.keys(v);
      for (var i = 0; i < keys.length; i++) {
        var c = v[keys[i]];
        if (c && c.parent === commentId) n++;
      }
      return n;
    } catch (e) {
      return 0;
    }
  }

  /* ----------------------------------------------------------
   * performRemove(postId, commentId)
   * The five-line core of the flow, with best-effort error
   * handling per call. The primary remove (comments/…) is the
   * one whose failure surfaces as a toast; the secondary
   * (commentReactions/…) is best-effort like the original.
   *
   * Returns Promise<{ ok, primaryError }>.
   * ---------------------------------------------------------- */
  async function performRemove(postId, commentId) {
    var fbDb = getDB();
    if (!fbDb) return { ok: false, primaryError: new Error(T('error')) };

    var primaryError = null;

    /* 1) Primary: comments/{pid}/{cid} -------------------- */
    try {
      await fbDb.ref('comments/' + postId + '/' + commentId).remove();
    } catch (err) {
      primaryError = err;
    }

    /* 2) Secondary: commentReactions/{pid}/{cid} ---------- *
     *    Best-effort — never surfaces as a user-facing error,
     *    matching the original .catch(() => {}). */
    try {
      await fbDb.ref('commentReactions/' + postId + '/' + commentId).remove();
    } catch (e) {}

    return { ok: !primaryError, primaryError: primaryError };
  }

  /* ----------------------------------------------------------
   * deleteComment(postId, commentId) → Promise<boolean>
   * Preserved 1:1 from the original delete branch.
   * ---------------------------------------------------------- */
  async function deleteComment(postId, commentId) {
    if (!postId || !commentId) return false;

    /* 1) Confirm ----------------------------------------- */
    var ok = await askConfirm(T('delete_comment'), T('are_you_sure'));
    if (!ok) return false;

    /* 2) Perform the removes ----------------------------- */
    var res = await performRemove(postId, commentId);

    /* 3) Surface the primary error if any ---------------- */
    if (!res.ok) {
      var msg = (res.primaryError && res.primaryError.message)
        ? res.primaryError.message
        : T('error');
      safeToast(msg, 'err');
      return false;
    }

    /* 4) Notify subscribers (additive) ------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:comment-deleted', {
        detail: { postId: postId, commentId: commentId }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * cascadeRemoveReplies(postId, commentId, opts)
   * OPT-IN helper — NOT part of the original source.
   *
   * Walks comments/{pid}, finds every comment whose parent is
   * commentId (recursively), and removes them + their
   * commentReactions nodes. Callers must explicitly invoke
   * this; deleteComment() does NOT call it, matching the
   * original behaviour where replies were left orphaned.
   *
   * Returns Promise<number> — the count of replies removed.
   * ---------------------------------------------------------- */
  async function cascadeRemoveReplies(postId, commentId, opts) {
    if (!postId || !commentId) return 0;
    var fbDb = getDB();
    if (!fbDb) return 0;

    opts = opts || {};
    var maxDepth = (typeof opts.maxDepth === 'number' && opts.maxDepth > 0)
      ? opts.maxDepth
      : 10;

    /* Build the full tree of descendants once. ------------ */
    var snap;
    try {
      snap = await fbDb.ref('comments/' + postId).get();
    } catch (e) {
      return 0;
    }
    var all = snap.val() || {};

    var toRemove = [];
    var frontier = [commentId];
    var depth = 0;

    while (frontier.length && depth < maxDepth) {
      var next = [];
      for (var i = 0; i < frontier.length; i++) {
        var parentId = frontier[i];
        var keys = Object.keys(all);
        for (var j = 0; j < keys.length; j++) {
          var cid = keys[j];
          var c = all[cid];
          if (c && c.parent === parentId) {
            toRemove.push(cid);
            next.push(cid);
          }
        }
      }
      frontier = next;
      depth++;
    }

    /* Remove each descendant + its reaction bucket --------- */
    for (var k = 0; k < toRemove.length; k++) {
      var id = toRemove[k];
      try { await fbDb.ref('comments/' + postId + '/' + id).remove(); }
      catch (e) {}
      try { await fbDb.ref('commentReactions/' + postId + '/' + id).remove(); }
      catch (e) {}
    }

    if (toRemove.length) {
      try {
        window.dispatchEvent(new CustomEvent('saiko:comment-replies-cascaded', {
          detail: { postId: postId, commentId: commentId, removed: toRemove.length }
        }));
      } catch (e) {}
    }

    return toRemove.length;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.deleteComment = deleteComment;

  window.SaikoCommentDelete = {
    delete: deleteComment,
    confirmAndDelete: deleteComment,     /* alias — same flow */
    cascadeRemoveReplies: cascadeRemoveReplies,
    buildRemovePaths: buildRemovePaths,
    countReplies: countReplies
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 072 — comment-delete ready');
  } catch (e) {}

})();