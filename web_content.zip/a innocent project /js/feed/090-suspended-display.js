/* ============================================================
 * FEATURE:        Suspended / Restricted Display
 * FEATURE NUMBER: 090
 * FILE:           js/feed/090-suspended-display.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical owner of the "is this post/comment suspended?"
 *   predicate used across the feed, comments, hashtag, and
 *   split-view surfaces. Every renderer that filters out
 *   suspended content reads through this function so the rule
 *   lives in exactly one place.
 *
 *   Public function:
 *     window.isSuspended(obj) → boolean
 *
 *   Behaviour preserved 1:1 from the original §15 FEED block
 *   (isSuspended), which itself was reused by:
 *     • §15 feed renderer      (filter suspended posts)
 *     • §17 post-split         (comment filter)
 *     • §19 notifications      (skip suspended comments in count)
 *     • §26 hashtag / trending (filter)
 *     • §30 settings           (restricted posts list)
 *
 *   Shape of a suspended item (from the original source):
 *
 *     suspended: true
 *       When true, the item is suspended. The `suspendedUntil`
 *       field decides for how long:
 *         -1 → permanent
 *         null / 0 / undefined → permanent (treat as no expiry)
 *         > now() → still suspended
 *         <= now() → expired, NOT suspended
 *
 *     suspendedUntil only (suspended flag absent)
 *       -1 → permanent
 *       > now() → still suspended
 *       <= now() → NOT suspended
 *
 *   Everything falls through to `false` when neither field is
 *   present — a normal, non-suspended object.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → isSuspended(obj)
 *
 * DEPENDENCIES (loaded earlier):
 *   - now()      js/core/utils.js  (falls back to Date.now())
 *
 * DOM ELEMENTS USED:
 *   none — pure predicate
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.isSuspended
 *   window.SaikoSuspended = {
 *     check:        isSuspended,   // main predicate (same fn)
 *     isPermanent,                 // pure — permanent suspension?
 *     isExpired,                   // pure — expired suspension?
 *     remainingMs,                 // pure — time left, 0 when not
 *     reason,                      // pure — read reason string
 *     PERMANENT
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var PERMANENT = -1;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * CHECK — the main predicate
   * ============================================================
   * Preserved 1:1 from the original source.
   *
   * The original had two branches:
   *   A) `suspended === true` (the flag) with `suspendedUntil`
   *      deciding duration.
   *   B) `suspendedUntil` present without the flag (legacy
   *      data written by older builds).
   *
   * Both are honoured, in that order.
   * ============================================================ */
  function check(obj) {
    if (!obj) return false;

    /* Branch A — explicit `suspended: true` flag ---------- */
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);

      /* Permanent (no expiry or explicit -1). */
      if (u === PERMANENT) return true;
      if (!u) return true;             /* 0 / NaN / undefined */

      /* Time-based — suspended only until `u` passes. */
      if (u > timeNow()) return true;
      return false;                    /* expired */
    }

    /* Branch B — `suspendedUntil` set without the flag ---- */
    var until = Number(obj.suspendedUntil || 0);
    if (until === PERMANENT) return true;
    return until > timeNow();
  }

  /* ============================================================
   * DERIVED PREDICATES (additive)
   * ============================================================ */

  /* isPermanent(obj) → true when the suspension never expires.
   * Returns false for any non-suspended object. */
  function isPermanent(obj) {
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === PERMANENT) return true;
      if (!u) return true;
    }
    var until = Number(obj.suspendedUntil || 0);
    return until === PERMANENT;
  }

  /* isExpired(obj) → true when a suspension existed but has
   * already passed. Returns false for non-suspended objects. */
  function isExpired(obj) {
    if (!obj) return false;
    var u = Number(obj.suspendedUntil);
    if (obj.suspended === true) {
      if (u === PERMANENT || !u) return false;
      return u <= timeNow();
    }
    if (u === PERMANENT) return false;
    if (!u) return false;
    return u <= timeNow();
  }

  /* remainingMs(obj) → milliseconds left in the suspension.
   *   • 0 when not suspended
   *   • Infinity when permanent
   *   • positive ms when time-based
   */
  function remainingMs(obj) {
    if (!check(obj)) return 0;
    if (isPermanent(obj)) return Infinity;
    var u = Number(obj.suspendedUntil);
    if (!isFinite(u)) return Infinity;
    var left = u - timeNow();
    return left > 0 ? left : 0;
  }

  /* reason(obj) → the stored suspension reason string, or ''
   * when none. Mirrors the field names used across the app:
   *   suspendReason (preferred)
   *   reason        (fallback) */
  function reason(obj) {
    if (!obj) return '';
    return String(obj.suspendReason || obj.reason || '');
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — preserved so feature 051 (feed filter),
   * feature 066 (comment count), feature 067 (post-split),
   * feature 080 (hashtag open), and any other caller keeps
   * working unchanged. */
  window.isSuspended = check;

  window.SaikoSuspended = {
    check: check,
    isPermanent: isPermanent,
    isExpired: isExpired,
    remainingMs: remainingMs,
    reason: reason,
    PERMANENT: PERMANENT
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 090 — suspended-display ready');
  } catch (e) {}

})();