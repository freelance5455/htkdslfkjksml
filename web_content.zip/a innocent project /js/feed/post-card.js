/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED)
 * FILE:   js/feed/post-card.js
 * ACTION: REPLACE (v2 — premium post card UI)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * 1. INJECT PREMIUM POST CARD CSS
   * ============================================================ */
  (function injectPostCardCSS() {
    if (document.getElementById('__saiko_postcard_css_v2')) return;
    var s = document.createElement('style');
    s.id = '__saiko_postcard_css_v2';
    s.textContent =
      /* Card wrapper */
      '.card[data-post]{' +
        'padding:0 !important;overflow:hidden;border-radius:1.15rem;' +
        'background:linear-gradient(180deg,#0f1a2e 0%,#0c1526 100%);' +
        'border:1px solid rgba(58,160,255,.12);' +
        'margin-bottom:.9rem;' +
        'box-shadow:0 6px 22px rgba(0,0,0,.25);' +
      '}' +

      /* Post head */
      '.card[data-post] .post-head{' +
        'display:flex;align-items:center;gap:.65rem;' +
        'padding:.7rem .8rem .55rem;margin:0;' +
      '}' +
      '.card[data-post] .post-head .name{' +
        'display:flex;align-items:center;gap:.35rem;' +
        'font-size:.88rem;font-weight:700;color:#fff;line-height:1.15;' +
      '}' +
      '.card[data-post] .post-head .muted{' +
        'font-size:.7rem;color:#7c8699;margin-top:.12rem;' +
        'display:flex;align-items:center;gap:.25rem;' +
      '}' +
      '.card[data-post] .post-head .muted .ic{' +
        'width:.75rem;height:.75rem;display:inline-flex;vertical-align:middle;' +
        'opacity:.7;' +
      '}' +
      '.card[data-post] .post-head .icon-btn{' +
        'width:1.9rem;height:1.9rem;border-color:transparent;' +
        'color:#8b93a7;font-size:1.1rem;letter-spacing:.1em;' +
      '}' +
      '.card[data-post] .post-head .icon-btn:active{' +
        'background:rgba(124,92,255,.15);color:#7c5cff;' +
      '}' +

      /* Verified badge */
      '.card[data-post] .pc-verified{' +
        'width:.85rem;height:.85rem;border-radius:50%;' +
        'background:linear-gradient(135deg,#2ecc8f,#00b85f);' +
        'display:inline-flex;align-items:center;justify-content:center;' +
        'color:#fff;flex:0 0 auto;' +
      '}' +
      '.card[data-post] .pc-verified svg{' +
        'width:.55rem;height:.55rem;' +
      '}' +

      /* Text caption */
      '.card[data-post] .post-text{' +
        'padding:0 .8rem .55rem;' +
        'font-size:.88rem;line-height:1.45;color:#eef1f8;' +
        'white-space:pre-wrap;word-break:break-word;margin:0;' +
      '}' +

      /* Media wrappers */
      '.card[data-post] .post-gallery{' +
        'position:relative;border-radius:0;border:none;border-top:1px solid rgba(255,255,255,.04);' +
        'border-bottom:1px solid rgba(255,255,255,.04);' +
        'margin:0 0 .1rem;overflow:hidden;background:#000;' +
      '}' +
      '.card[data-post] .post-video{' +
        'border-radius:0;border:none;border-top:1px solid rgba(255,255,255,.04);' +
        'border-bottom:1px solid rgba(255,255,255,.04);' +
        'margin:0 0 .1rem;background:#000;position:relative;' +
      '}' +
      '.card[data-post] .post-video video{' +
        'width:100%;max-height:32rem;display:block;background:#000;' +
      '}' +
      '.card[data-post] .post-gallery .gitem img{' +
        'width:100%;height:100%;object-fit:cover;display:block;' +
      '}' +
      '.card[data-post] .post-gallery.g1 .gitem{' +
        'aspect-ratio:auto;' +
      '}' +
      '.card[data-post] .post-gallery.g1 .gitem img{' +
        'max-height:32rem;object-fit:contain;background:#000;' +
      '}' +

      /* Media page counter */
      '.pc-media-count{' +
        'position:absolute;top:.55rem;right:.55rem;z-index:3;' +
        'background:rgba(0,0,0,.65);color:#fff;' +
        'font-size:.68rem;font-weight:800;' +
        'padding:.2rem .55rem;border-radius:.65rem;' +
        'backdrop-filter:blur(4px);' +
        'letter-spacing:.02em;' +
      '}' +

      /* Action bar */
      '.card[data-post] .post-actions{' +
        'display:flex;align-items:center;justify-content:space-between;' +
        'gap:.15rem;padding:.55rem .55rem .6rem;' +
        'border-top:none;margin:0;' +
      '}' +
      '.card[data-post] .act{' +
        'display:inline-flex;align-items:center;gap:.4rem;' +
        'padding:.5rem .65rem;border-radius:.75rem;' +
        'font-size:.78rem;font-weight:700;color:#8b93a7;' +
        'background:none;border:none;cursor:pointer;' +
        'transition:color .18s,background .18s,transform .14s;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;flex:1;' +
        'justify-content:center;' +
      '}' +
      '.card[data-post] .act:active{transform:scale(.94);}' +
      '.card[data-post] .act:hover{background:rgba(255,255,255,.03);}' +
      '.card[data-post] .act .ic{width:1.15rem;height:1.15rem;}' +
      '.card[data-post] .act .like-icon{' +
        'font-size:1.1rem;line-height:1;display:inline-flex;align-items:center;' +
      '}' +
      '.card[data-post] .act.liked{color:#ff5c8a;}' +
      '.card[data-post] .act.liked .ic svg{fill:currentColor;stroke:currentColor;}' +
      '.card[data-post] .act.saved{color:#7c5cff;}' +
      '.card[data-post] .act.saved .ic svg{fill:currentColor;stroke:currentColor;}' +

      /* Small screens */
      '@media (max-width:360px){' +
        '.card[data-post] .act{padding:.45rem .4rem;font-size:.72rem;gap:.3rem;}' +
        '.card[data-post] .act .ic{width:1.05rem;height:1.05rem;}' +
        '.card[data-post] .post-head{padding:.6rem .7rem .5rem;}' +
        '.card[data-post] .post-text{padding:0 .7rem .5rem;font-size:.85rem;}' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  })();

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-card] safeCall:', name, e); }
    return undefined;
  }

  function callIf(fn, args, fallback) {
    try { if (typeof fn === 'function') return fn.apply(null, args || []); } catch (e) {}
    return fallback;
  }

  function countLikes(pid)   { return callIf(window.countLikes,   [pid], 0); }
  function countComments(pid){ return callIf(window.countComments,[pid], 0); }
  function iLiked(pid)       { return callIf(window.iLiked,       [pid], false); }
  function iSaved(pid)       { return callIf(window.iSaved,       [pid], false); }
  function myReactionOn(pid) { return callIf(window.myReactionOn, [pid], null); }

  function linkifyTags(s) {
    return callIf(window.linkifyTags, [s], s);
  }
  function avatarHTML(url, name, cls, uid) {
    return callIf(window.avatarHTML, [url, name, cls, uid], '');
  }
  function timeAgo(ts) {
    return callIf(window.timeAgo, [ts], '');
  }
  function fmtTime(ts) {
    return callIf(window.fmtTime, [ts], '');
  }
  function svgIcon(name, fill) {
    return callIf(window.svgIcon, [name, fill], '');
  }
  function findUser(uid) {
    return callIf(window.findUser, [uid], null);
  }

  /* Inline icons */
  function svgGlobe() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/></svg>';
  }
  function svgVerified() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="m5 12 5 5L20 7"/></svg>';
  }

  /* ============================================================
   * postHTML — premium markup, same data attributes preserved
   * ============================================================ */
  function postHTML(p) {
    if (!p) return '';
    var u = findUser(p.uid) || { name: p.authorName || 'User', photo: p.authorPhoto || '' };
    var edited = (p.updatedAt && p.updatedAt > (p.createdAt || 0) + 1500) ? (' · ' + T('edited')) : '';
    var myRx = myReactionOn(p.id);
    var likeIconHTML = myRx ? esc(myRx) : svgIcon('heart', true);
    var likedCls = (myRx || iLiked(p.id)) ? 'liked' : '';
    var pinned = (window.myProfile && window.myProfile.pinnedPosts && window.myProfile.pinnedPosts[p.id]);

    /* Verified badge — only if data supports */
    var verifiedHTML = (u.verified === true || u.isVerified === true)
      ? '<span class="pc-verified">' + svgVerified() + '</span>'
      : '';

    /* Media */
    var mediaHtml = '';
    var images = Array.isArray(p.images) ? p.images.filter(Boolean) : (p.image ? [p.image] : []);
    var video = p.video || null;

    if (video) {
      mediaHtml =
        '<div class="post-video">' +
          '<video controls playsinline preload="metadata" src="' + esc(video) + '" muted></video>' +
        '</div>';
    } else if (images.length) {
      var n = Math.min(images.length, 10);
      var gcls = 'post-gallery g' + n;
      var items = images.slice(0, n).map(function (src, i) {
        var more = (i === n - 1 && images.length > n)
          ? ('<div class="more">+' + (images.length - n) + '</div>')
          : '';
        return '<div class="gitem" data-gopen="' + esc(p.id) + '" data-gidx="' + i + '">' +
                 '<img loading="lazy" src="' + esc(src) + '" alt="">' + more +
               '</div>';
      }).join('');
      var counter = images.length > 1
        ? ('<div class="pc-media-count">1/' + images.length + '</div>')
        : '';
      mediaHtml = '<div class="' + gcls + '" style="position:relative">' + counter + items + '</div>';
    }

    /* Pinned chip */
    var pinnedChip = pinned
      ? ' <span class="chip" style="font-size:.55rem;padding:.1rem .35rem;background:var(--accent-soft);color:var(--accent);">📌</span>'
      : '';

    return (
      '<div class="card" data-post="' + esc(p.id) + '">' +
        '<div class="post-head">' +
          '<div data-postowner="' + esc(p.uid) + '" style="cursor:pointer">' +
            avatarHTML(u.photo, u.name, 'av-40', p.uid) +
          '</div>' +
          '<div class="grow" data-postowner="' + esc(p.uid) + '" style="cursor:pointer;min-width:0">' +
            '<div class="name">' + esc(u.name) + verifiedHTML + pinnedChip + '</div>' +
            '<div class="muted">' +
              esc(timeAgo(p.createdAt)) + ' · ' + esc(fmtTime(p.createdAt)) + esc(edited) +
              ' <span class="ic">' + svgGlobe() + '</span>' +
            '</div>' +
          '</div>' +
          '<button class="icon-btn" data-postmenu="' + esc(p.id) + '" ' +
                  'aria-label="Options">⋯</button>' +
        '</div>' +
        (p.text ? ('<div class="post-text">' + linkifyTags(esc(p.text)) + '</div>') : '') +
        mediaHtml +
        '<div class="post-actions">' +
          '<button class="act ' + likedCls + '" data-like="' + esc(p.id) + '">' +
            '<span class="like-icon">' + likeIconHTML + '</span>' +
            '<span data-likecount="' + esc(p.id) + '">' + countLikes(p.id) + '</span>' +
          '</button>' +
          '<button class="act" data-opencomments="' + esc(p.id) + '">' +
            svgIcon('comment', true) +
            '<span data-commentcount="' + esc(p.id) + '">' + countComments(p.id) + '</span>' +
          '</button>' +
          '<button class="act ' + (iSaved(p.id) ? 'saved' : '') + '" data-save="' + esc(p.id) + '">' +
            svgIcon('bookmark', true) +
            '<span>' + esc(T('bookmark') || 'Save') + '</span>' +
          '</button>' +
          '<button class="act" data-share="' + esc(p.id) + '">' +
            svgIcon('share', true) +
            '<span>' + esc(T('share') || 'Share') + '</span>' +
          '</button>' +
        '</div>' +
      '</div>'
    );
  }

  /* ============================================================
   * wirePostInteractions — preserved (all handlers + guards)
   * ============================================================ */
  function wirePostInteractions(root) {
    if (!root) return;

    root.querySelectorAll('[data-postowner]').forEach(function (n) {
      if (n.dataset.wired) return; n.dataset.wired = '1';
      n.addEventListener('click', function () {
        var uid = n.getAttribute('data-postowner');
        if (!uid) return;
        if (uid !== window.myUid) safeCall('openUserProfile', [uid]);
        else safeCall('navigate', ['profile']);
      });
    });

    root.querySelectorAll('[data-like]').forEach(function (b) {
      if (b.dataset.wired) return; b.dataset.wired = '1';
      var pid = b.getAttribute('data-like');
      var longPressed = false, pressTimer = null;

      function start() {
        longPressed = false;
        pressTimer = setTimeout(function () {
          longPressed = true;
          safeCall('openPostReactionPicker', [pid]);
          if (navigator.vibrate) try { navigator.vibrate(15); } catch (e) {}
        }, 550);
      }
      function cancel() { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } }

      b.addEventListener('pointerdown', start);
      b.addEventListener('pointerup', cancel);
      b.addEventListener('pointerleave', cancel);
      b.addEventListener('pointercancel', cancel);
      b.addEventListener('contextmenu', function (e) {
        e.preventDefault(); safeCall('openPostReactionPicker', [pid]); longPressed = true;
      });
      b.addEventListener('click', function () {
        if (longPressed) { longPressed = false; return; }
        safeCall('toggleLike', [pid]);
      });
    });

    root.querySelectorAll('[data-opencomments]').forEach(function (b) {
      if (b.dataset.wired) return; b.dataset.wired = '1';
      b.addEventListener('click', function () {
        safeCall('openPostSplit', [b.getAttribute('data-opencomments')]);
      });
    });

    root.querySelectorAll('[data-save]').forEach(function (b) {
      if (b.dataset.wired) return; b.dataset.wired = '1';
      b.addEventListener('click', function () {
        safeCall('toggleSave', [b.getAttribute('data-save')]);
      });
    });

    root.querySelectorAll('[data-share]').forEach(function (b) {
      if (b.dataset.wired) return; b.dataset.wired = '1';
      b.addEventListener('click', function () {
        safeCall('sharePost', [b.getAttribute('data-share')]);
      });
    });

    root.querySelectorAll('[data-postmenu]').forEach(function (b) {
      if (b.dataset.wired) return; b.dataset.wired = '1';
      b.addEventListener('click', function () {
        safeCall('openPostMenu', [b.getAttribute('data-postmenu')]);
      });
    });

    root.querySelectorAll('[data-gopen]').forEach(function (n) {
      if (n.dataset.wired) return; n.dataset.wired = '1';
      n.addEventListener('click', function () {
        var pid = n.getAttribute('data-gopen');
        var idx = Number(n.getAttribute('data-gidx')) || 0;
        var post = null;
        try {
          if (Array.isArray(window.postsCache)) {
            post = window.postsCache.find(function (p) { return p.id === pid; });
          }
        } catch (e) {}
        if (!post) return;
        var imgs = Array.isArray(post.images) ? post.images : (post.image ? [post.image] : []);
        safeCall('openGallery', [imgs, idx, pid]);
      });
    });

    root.querySelectorAll('.hashtag').forEach(function (n) {
      if (n.dataset.wired) return; n.dataset.wired = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        safeCall('openHashtag', [n.getAttribute('data-tag')]);
      });
    });
  }

  window.postHTML = postHTML;
  window.wirePostInteractions = wirePostInteractions;

  window.SaikoPostCard = {
    postHTML: postHTML,
    wirePostInteractions: wirePostInteractions
  };

  try {
    console.debug('[boot] post-card ready (v2 — premium)');
  } catch (e) {}

})();