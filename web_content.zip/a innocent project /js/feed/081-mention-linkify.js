/* ============================================================
 * FEATURE:        @Mention Linkify
 * FEATURE NUMBER: 081
 * FILE:           js/feed/081-mention-linkify.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical text formatter that converts @mentions and
 *   #hashtags inside an ALREADY-ESCAPED string into clickable
 *   <span> markup:
 *
 *     @username  →  <span class="mention">@username</span>
 *     #hashtag   →  <span class="hashtag" data-tag="...">#hashtag</span>
 *
 *   Public function:
 *     window.linkifyTags(escapedText) → string
 *
 *   CRITICAL CONTRACT — the input must already be HTML-escaped
 *   by the caller. The original call sites always passed
 *   `esc(post.text)` and not the raw text:
 *
 *     '<div class="post-text">' + linkifyTags(esc(p.text)) + '</div>'
 *
 *   We preserve that contract exactly. linkifyTags() does NOT
 *   escape on its own; feeding it raw user text could leak
 *   HTML into the page.
 *
 *   Regexes preserved 1:1 from the original:
 *
 *     MENTION: /@([A-Za-z0-9_]+)/g
 *       — ASCII only, matching the original source.
 *
 *     HASHTAG: /#([A-Za-z0-9_\u00C0-\u024F\u0900-\u097F\u0600-\u06FF\u4E00-\u9FFF]+)/g
 *       — the exact same multi-script character class as
 *         feature 079 (extractTags).
 *
 *   Why hashtags get a data-tag attribute:
 *     The click handler in feature 055 (post-card) and feature
 *     067 (post-split) reads `getAttribute('data-tag')` and
 *     calls `openHashtag(tag)`. Mentions deliberately do NOT
 *     get a data attribute — the original had no click handler
 *     for them, and we preserve that (no mention click → no
 *     user profile jump).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §5 UTILITIES → linkifyTags(escapedText)
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure string processing
 *
 * DOM ELEMENTS USED:
 *   none
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.linkifyTags
 *   window.SaikoMentionLinkify = {
 *     linkify,
 *     hasMention,
 *     hasHashtag,
 *     MENTION_REGEX,
 *     HASHTAG_REGEX,
 *     HASHTAG_CHAR_CLASS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * REGEX CONSTANTS
   * Preserved byte-for-byte from the original §5 block.
   * ============================================================ */

  /* Mention: ASCII-only username characters. */
  var MENTION_REGEX = /@([A-Za-z0-9_]+)/g;

  /* Hashtag: multi-script (Devanagari / Arabic / CJK / Latin
   * Extended). Same character class as feature 079's extract
   * regex, so what one recognises the other also recognises. */
  var HASHTAG_CHAR_CLASS =
    'A-Za-z0-9_' +
    '\\u00C0-\\u024F' +
    '\\u0900-\\u097F' +
    '\\u0600-\\u06FF' +
    '\\u4E00-\\u9FFF';

  var HASHTAG_REGEX = new RegExp(
    '#(' + HASHTAG_CHAR_CLASS + ')+',
    'g'
  );

  /* ============================================================
   * LINKIFY
   * Preserved 1:1 from original linkifyTags(escapedText).
   *
   *   if (!escapedText) return '';
   *   return String(escapedText)
   *     .replace(MENTION_REGEX, '<span class="mention">@$1</span>')
   *     .replace(HASHTAG_REGEX, '<span class="hashtag" data-tag="$1">#$1</span>');
   *
   * Order matters: mentions first, then hashtags. Swapping
   * would not change the output for the current regexes (they
   * do not overlap), but the ordering is preserved exactly so
   * future tweaks to either regex keep the same semantics.
   * ============================================================ */
  function linkify(escapedText) {
    if (!escapedText) return '';
    return String(escapedText)
      .replace(MENTION_REGEX, function (_full, username) {
        return '<span class="mention">@' + username + '</span>';
      })
      .replace(HASHTAG_REGEX, function (_full, tag) {
        return '<span class="hashtag" data-tag="' + tag + '">#' + tag + '</span>';
      });
  }

  /* ============================================================
   * PREDICATES (additive)
   * ============================================================
   * Both use non-global fresh regexes so calling them does not
   * interfere with the global MENTION_REGEX / HASHTAG_REGEX
   * .lastIndex state.
   * ============================================================ */
  function hasMention(text) {
    if (!text) return false;
    try { return /@([A-Za-z0-9_]+)/.test(String(text)); }
    catch (e) { return false; }
  }

  function hasHashtag(text) {
    if (!text) return false;
    try {
      return new RegExp('#(' + HASHTAG_CHAR_CLASS + ')+').test(String(text));
    } catch (e) { return false; }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — preserved so every call site keeps
   * working unchanged:
   *   • feature 055 (post-card)
   *   • feature 067 (post-split comment rendering)
   *   • feature 068 (legacy overlay)
   *   • feature 128 (chat message rendering)
   *   • any future text surface
   */
  window.linkifyTags = linkify;

  window.SaikoMentionLinkify = {
    linkify: linkify,
    hasMention: hasMention,
    hasHashtag: hasHashtag,
    MENTION_REGEX: MENTION_REGEX,
    HASHTAG_REGEX: HASHTAG_REGEX,
    HASHTAG_CHAR_CLASS: HASHTAG_CHAR_CLASS
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 081 — mention-linkify ready');
  } catch (e) {}

})();