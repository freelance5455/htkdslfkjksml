/* ============================================================
 * FEATURE:        Post + Comments Split View
 * FEATURE NUMBER: 067
 * FILE:           js/feed/067-post-split.js
 * ACTION:         REPLACE (window.splitPostId expose + reaction UI fix)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var splitPostId = null;
  var splitCommentListener = null;
  var splitReplyTarget = null;
  var splitDividerDrag = null;
  var splitCommentReactions = {};
  var splitReactionsRef = null;
  var splitReactionsCb = null;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-split] safeCall:', name, e); }
    return undefined;
  }
  function safeGet(name, args, fallback) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {}
    return fallback;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findPost(pid) {
    if (!pid) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === pid) return p;
        }
      }
    } catch (e) {}
    return null;
  }
  function findUser(uid) {
    return safeGet('findUser', [uid], null);
  }
  function avatarHTML(url, name, cls, uid) {
    return safeGet('avatarHTML', [url, name, cls, uid], '');
  }
  function svgIcon(name, fill) {
    return safeGet('svgIcon', [name, fill], '');
  }
  function linkifyTags(s) {
    return safeGet('linkifyTags', [s], s);
  }
  function timeAgo(ts) { return safeGet('timeAgo', [ts], ''); }

  function countLikes(pid)    { return safeGet('countLikes', [pid], 0); }
  function countComments(pid) { return safeGet('countComments', [pid], 0); }
  function iLiked(pid)        { return safeGet('iLiked', [pid], false); }
  function iSaved(pid)        { return safeGet('iSaved', [pid], false); }
  function myReactionOn(pid)  { return safeGet('myReactionOn', [pid], null); }

  function isSuspended(obj) {
    try { if (typeof window.isSuspended === 'function') return !!window.isSuspended(obj); }
    catch (e) {}
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > timeNow()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > timeNow();
  }

  /* ============================================================
   * OPEN / CLOSE
   * ============================================================ */
  function openSplitOverlay() {
    var ov = qs('#ovSplitComments');
    if (!ov) return false;
    ov.classList.add('open');
    ov.classList.remove('video-fs');
    ov.classList.remove('comments-fs');
    var top = qs('#splitTop');
    if (top) top.style.flex = '';
    return true;
  }

  function closePostSplit() {
    var mediaBox = qs('#splitMedia');
    if (mediaBox) {
      qsa('video', mediaBox).forEach(function (v) {
        try { v.pause(); } catch (e) {}
      });
      mediaBox.innerHTML = '';
    }

    var ov = qs('#ovSplitComments');
    if (ov) ov.classList.remove('open');

    if (splitCommentListener) {
      try { splitCommentListener.ref.off('value', splitCommentListener.cb); }
      catch (e) {}
      splitCommentListener = null;
    }

    if (splitReactionsRef && splitReactionsCb) {
      try { splitReactionsRef.off('value', splitReactionsCb); }
      catch (e) {}
    }
    splitReactionsRef = null;
    splitReactionsCb = null;

    splitPostId = null;
    window.splitPostId = null;
    splitReplyTarget = null;
    splitCommentReactions = {};
    window.splitCommentReactions = {};
  }

  function openPostSplit(pid) {
    var post = findPost(pid);
    if (!post) return false;
    splitPostId = pid;
    window.splitPostId = pid;

    openSplitOverlay();

    var mediaBox = qs('#splitMedia');
    if (!mediaBox) return false;

    var u = findUser(post.uid) || { name: post.authorName || 'User', photo: post.authorPhoto || '' };
    var images = Array.isArray(post.images) ? post.images.filter(Boolean) : (post.image ? [post.image] : []);

    var mediaHtml = '<div class="card">';
    mediaHtml +=
      '<div class="post-head">' +
        '<div>' + avatarHTML(u.photo, u.name, 'av-40') + '</div>' +
        '<div class="grow">' +
          '<div class="name">' + esc(u.name) + '</div>' +
          '<div class="muted">' + esc(timeAgo(post.createdAt)) + '</div>' +
        '</div>' +
      '</div>';

    if (post.text) {
      mediaHtml += '<div class="post-text">' + linkifyTags(esc(post.text)) + '</div>';
    }

    if (post.video) {
      mediaHtml +=
        '<div class="post-video">' +
          '<video controls playsinline preload="metadata" src="' + esc(post.video) + '" muted></video>' +
        '</div>';
    } else if (images.length) {
      var n = Math.min(images.length, 4);
      mediaHtml +=
        '<div class="post-gallery g' + n + '">' +
          images.slice(0, 4).map(function (src, i) {
            var more = (i === 3 && images.length > 4)
              ? ('<div class="more">+' + (images.length - 4) + '</div>')
              : '';
            return '<div class="gitem" data-sgidx="' + i + '">' +
                     '<img src="' + esc(src) + '" alt="">' + more +
                   '</div>';
          }).join('') +
        '</div>';
    }

    var myRx = myReactionOn(pid);
    var liked = !!(myRx || iLiked(pid));
    mediaHtml +=
      '<div class="post-actions">' +
        '<button class="act ' + (liked ? 'liked' : '') + '" data-split-like="' + esc(pid) + '">' +
          '<span class="like-icon">' + (myRx ? esc(myRx) : '') + '</span>' +
          svgIcon('heart', true) +
          '<span data-split-likecount="' + esc(pid) + '">' + countLikes(pid) + '</span>' +
        '</button>' +
        '<button class="act ' + (iSaved(pid) ? 'saved' : '') + '" data-split-save="' + esc(pid) + '">' +
          svgIcon('bookmark', true) +
          '<span>' + esc(T('bookmark')) + '</span>' +
        '</button>' +
      '</div>';

    mediaHtml += '</div>';
    mediaBox.innerHTML = mediaHtml;

    qsa('[data-split-like]', mediaBox).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('toggleLike', [pid]);
        refreshSplitPost(pid);
      });
    });
    qsa('[data-split-save]', mediaBox).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('toggleSave', [pid]);
        refreshSplitPost(pid);
      });
    });
    qsa('.gitem', mediaBox).forEach(function (n) {
      n.addEventListener('click', function () {
        var idx = Number(n.getAttribute('data-sgidx')) || 0;
        safeCall('openGallery', [images, idx, pid]);
      });
    });
    qsa('.hashtag', mediaBox).forEach(function (n) {
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        closePostSplit();
        safeCall('openHashtag', [n.getAttribute('data-tag')]);
      });
    });

    loadSplitComments(pid);
    return true;
  }

  function refreshSplitPost(pid) {
    var likeBtn = qs('#splitMedia [data-split-like]');
    if (!likeBtn) return;
    var myRx = myReactionOn(pid);
    likeBtn.classList.toggle('liked', !!(myRx || iLiked(pid)));
    var cnt = likeBtn.querySelector('[data-split-likecount]');
    if (cnt) cnt.textContent = countLikes(pid);

    var saveBtn = qs('#splitMedia [data-split-save]');
    if (saveBtn) saveBtn.classList.toggle('saved', iSaved(pid));
  }

  /* ============================================================
   * LOAD COMMENTS
   * ============================================================ */
  function loadSplitComments(pid) {
    if (splitCommentListener) {
      try { splitCommentListener.ref.off('value', splitCommentListener.cb); }
      catch (e) {}
      splitCommentListener = null;
    }

    var box = qs('#splitComments');
    if (box) {
      box.innerHTML =
        '<div class="skeleton" style="height:3rem;margin-bottom:.5rem"></div>' +
        '<div class="skeleton" style="height:3rem;margin-bottom:.5rem"></div>';
    }

    var fbDb = getDB();
    if (!fbDb) return;

    var ref = fbDb.ref('comments/' + pid);
    var cb = ref.on('value', function (s) {
      var v = s.val() || {};
      var arr = Object.keys(v)
        .map(function (k) { return Object.assign({ id: k }, v[k]); })
        .filter(function (c) { return !isSuspended(c); });

      var tops = arr.filter(function (c) { return !c.parent; })
                    .sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      var byParent = {};
      arr.filter(function (c) { return c.parent; })
         .forEach(function (c) {
           (byParent[c.parent] = byParent[c.parent] || []).push(c);
         });
      Object.keys(byParent).forEach(function (k) {
        byParent[k].sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      });

      var boxNow = qs('#splitComments');
      if (!boxNow) return;

      if (!tops.length) {
        boxNow.innerHTML =
          '<div class="empty">' +
            '<span class="ic">' + svgIcon('comment') + '</span>' +
            '<p>' + esc(T('no_posts')) + '</p>' +
          '</div>';
        return;
      }

      boxNow.innerHTML = tops.map(function (c) {
        return commentHTML2(c, byParent[c.id] || []);
      }).join('');
      wireSplitComments(boxNow);
      repaintAllSplitReactions();
    });
    splitCommentListener = { ref: ref, cb: cb };

    if (splitReactionsRef && splitReactionsCb) {
      try { splitReactionsRef.off('value', splitReactionsCb); } catch (e) {}
    }
    splitReactionsRef = fbDb.ref('commentReactions/' + pid);
    splitReactionsCb = splitReactionsRef.on('value', function (s) {
      splitCommentReactions = s.val() || {};
      window.splitCommentReactions = splitCommentReactions;
      repaintAllSplitReactions();
    });
  }

  /* ============================================================
   * REPAINT ONE ROW (kept for backwards compat)
   * ============================================================ */
  function paintCmtRxRow(row, cid) {
    var map = splitCommentReactions[cid] || {};
    var counts = {};
    Object.keys(map).forEach(function (uid) {
      var v = map[uid];
      var type = (typeof v === 'string') ? v : (v && v.type);
      if (type) counts[type] = (counts[type] || 0) + 1;
    });
    var uid = getMyUid();
    var mine = map[uid];
    var mineType = (typeof mine === 'string') ? mine : (mine && mine.type);

    row.innerHTML = Object.keys(counts).map(function (rx) {
      var isMine = mineType === rx;
      return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" data-crx="' + esc(rx) + '" data-cid="' + esc(cid) + '">' +
             esc(rx) + ' ' + counts[rx] +
             '</span>';
    }).join('');
    wireCmtRx();
  }

  /* ============================================================
   * REPAINT ALL REACTIONS — creates rows on first reaction,
   * updates counts on change, removes empty rows.
   * ============================================================ */
  function repaintAllSplitReactions() {
    var box = qs('#splitComments');
    if (!box) return;

    qsa('.comment[data-scid]', box).forEach(function (node) {
      var cid = node.getAttribute('data-scid');
      if (!cid) return;

      var body = node.querySelector('.body');
      if (!body) return;

      var map = splitCommentReactions[cid] || {};
      var counts = {};
      Object.keys(map).forEach(function (uid) {
        var v = map[uid];
        var type = (typeof v === 'string') ? v : (v && v.type);
        if (type) counts[type] = (counts[type] || 0) + 1;
      });

      var existing = body.querySelector('.cmt-rx-row');
      var keys = Object.keys(counts);

      if (!keys.length) {
        if (existing) existing.remove();
        return;
      }

      var uid = getMyUid();
      var mine = map[uid];
      var mineType = (typeof mine === 'string') ? mine : (mine && mine.type);

      var html = '<div class="cmt-rx-row" data-cid="' + esc(cid) + '">' +
        keys.map(function (rx) {
          var isMine = (mineType === rx);
          return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" ' +
                      'data-crx="' + esc(rx) + '" data-cid="' + esc(cid) + '">' +
                   esc(rx) + ' ' + counts[rx] +
                 '</span>';
        }).join('') + '</div>';

      if (existing) {
        existing.outerHTML = html;
      } else {
        var actions = body.querySelector('.cmt-actions');
        if (actions) {
          actions.insertAdjacentHTML('afterend', html);
        } else {
          body.insertAdjacentHTML('beforeend', html);
        }
      }
    });

    wireCmtRx();
  }

  /* ============================================================
   * COMMENT HTML
   * ============================================================ */
  function commentHTML2(c, reps) {
    var u = findUser(c.uid) || { name: c.authorName || 'User', photo: c.authorPhoto || '' };
    var rxMap = splitCommentReactions[c.id] || {};
    var counts = {};
    Object.keys(rxMap).forEach(function (uid) {
      var v = rxMap[uid];
      var type = (typeof v === 'string') ? v : (v && v.type);
      if (type) counts[type] = (counts[type] || 0) + 1;
    });
    var uid = getMyUid();
    var mine = rxMap[uid];
    var mineType = (typeof mine === 'string') ? mine : (mine && mine.type);

    var rxRow = Object.keys(counts).length
      ? ('<div class="cmt-rx-row" data-cid="' + esc(c.id) + '">' +
           Object.keys(counts).map(function (rx) {
             var isMine = mineType === rx;
             return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" ' +
                    'data-crx="' + esc(rx) + '" data-cid="' + esc(c.id) + '">' +
                    esc(rx) + ' ' + counts[rx] +
                    '</span>';
           }).join('') +
         '</div>')
      : '';

    return (
      '<div class="comment" data-scid="' + esc(c.id) + '">' +
        '<div data-suser="' + esc(c.uid) + '" style="cursor:pointer">' +
          avatarHTML(u.photo, u.name, 'av-32') +
        '</div>' +
        '<div class="grow">' +
          '<div class="body">' +
            '<div class="name" style="font-size:.79rem" data-suser="' + esc(c.uid) + '">' + esc(u.name) + '</div>' +
            '<div class="tx">' + linkifyTags(esc(c.text)) + '</div>' +
            '<div class="mini" style="margin-top:.2rem">' + esc(timeAgo(c.createdAt)) + '</div>' +
            '<div class="cmt-actions">' +
              '<span class="reply-btn" data-sreply="' + esc(c.id) + '" ' +
                    'data-sreplyto="' + esc(u.name) + '" data-suid="' + esc(c.uid) + '">' +
                esc(T('reply')) +
              '</span>' +
              '<span class="reply-btn" data-scmenu="' + esc(c.id) + '">' + esc(T('more')) + '</span>' +
              '<span class="cmt-react" data-creact="' + esc(c.id) + '">😊 React</span>' +
            '</div>' +
            rxRow +
          '</div>' +
          (reps.length
            ? ('<div class="replies">' +
                reps.map(function (r) {
                  var ru = findUser(r.uid) || { name: r.authorName || 'User', photo: r.authorPhoto || '' };
                  var rMap = splitCommentReactions[r.id] || {};
                  var rCounts = {};
                  Object.keys(rMap).forEach(function (u2) {
                    var v = rMap[u2];
                    var type = (typeof v === 'string') ? v : (v && v.type);
                    if (type) rCounts[type] = (rCounts[type] || 0) + 1;
                  });
                  var rMine = rMap[uid];
                  var rMineType = (typeof rMine === 'string') ? rMine : (rMine && rMine.type);
                  var rRxRow = Object.keys(rCounts).length
                    ? ('<div class="cmt-rx-row" data-cid="' + esc(r.id) + '">' +
                         Object.keys(rCounts).map(function (rx) {
                           var isMine = rMineType === rx;
                           return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" ' +
                                  'data-crx="' + esc(rx) + '" data-cid="' + esc(r.id) + '">' +
                                  esc(rx) + ' ' + rCounts[rx] +
                                  '</span>';
                         }).join('') +
                       '</div>')
                    : '';

                  return '<div class="comment" style="margin-bottom:.5rem" data-scid="' + esc(r.id) + '">' +
                    '<div data-suser="' + esc(r.uid) + '" style="cursor:pointer">' +
                      avatarHTML(ru.photo, ru.name, 'av-32') +
                    '</div>' +
                    '<div class="grow">' +
                      '<div class="body">' +
                        '<div class="name" style="font-size:.76rem" data-suser="' + esc(r.uid) + '">' + esc(ru.name) + '</div>' +
                        '<div class="tx">' + linkifyTags(esc(r.text)) + '</div>' +
                        '<div class="mini" style="margin-top:.2rem">' + esc(timeAgo(r.createdAt)) + '</div>' +
                        '<div class="cmt-actions">' +
                          '<span class="reply-btn" data-sreply="' + esc(r.id) + '" ' +
                                'data-sreplyto="' + esc(ru.name) + '" data-suid="' + esc(r.uid) + '">' +
                            esc(T('reply')) +
                          '</span>' +
                          '<span class="cmt-react" data-creact="' + esc(r.id) + '">😊 React</span>' +
                        '</div>' +
                        rRxRow +
                      '</div>' +
                    '</div>' +
                  '</div>';
                }).join('') +
              '</div>')
            : '') +
        '</div>' +
      '</div>'
    );
  }

  /* ============================================================
   * WIRE COMMENT REACTION CHIPS — click → user list
   * ============================================================ */
  function wireCmtRx() {
    qsa('#splitComments [data-crx]').forEach(function (n) {
      if (n.dataset.wired === '1') return;
      n.dataset.wired = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        var cid = n.getAttribute('data-cid');
        var rx  = n.getAttribute('data-crx');
        if (typeof window.showCommentReactionUsers === 'function') {
          window.showCommentReactionUsers(window.splitPostId, cid, rx, false);
        }
      });
    });
  }

  /* ============================================================
   * WIRE COMMENT INTERACTIONS
   * ============================================================ */
  function wireSplitComments(body) {
    if (!body) return;

    qsa('[data-sreply]', body).forEach(function (b) {
      if (b.dataset.wired === '1') return;
      b.dataset.wired = '1';
      b.addEventListener('click', function () {
        var cid = b.getAttribute('data-sreply');
        var to  = b.getAttribute('data-sreplyto');
        var uid = b.getAttribute('data-suid');
        splitReplyTarget = { commentId: cid, name: to, uid: uid };

        var input = qs('#splitCommentInput');
        if (!input) return;
        var mention = '@' + to + ' ';
        if (input.value.indexOf(mention) !== 0) {
          input.value = mention + input.value.replace(/^@\S+\s+/, '');
        }
        input.placeholder = T('reply_hint') + ' ' + to + '...';
        input.focus();
        setTimeout(function () {
          try {
            input.selectionStart = input.selectionEnd = input.value.length;
          } catch (e) {}
        }, 10);
      });
    });

    qsa('[data-creact]', body).forEach(function (b) {
      if (b.dataset.wired === '1') return;
      b.dataset.wired = '1';
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        openCommentReactionPicker(splitPostId, b.getAttribute('data-creact'));
      });
    });

    qsa('[data-scmenu]', body).forEach(function (b) {
      if (b.dataset.wired === '1') return;
      b.dataset.wired = '1';
      b.addEventListener('click', function () {
        openSplitCommentMenu(b.getAttribute('data-scmenu'));
      });
    });

           qsa('[data-suser]', body).forEach(function (n) {
         if (n.dataset.wired === '1') return;
         n.dataset.wired = '1';
         n.addEventListener('click', function () {
           var u = n.getAttribute('data-suser');
           var me = getMyUid();
           if (u && u !== me) {
             /* Do NOT closePostSplit — stack profile on top */
             safeCall('openUserProfile', [u]);
           }
         });
       });

    qsa('.hashtag', body).forEach(function (n) {
      if (n.dataset.wired === '1') return;
      n.dataset.wired = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        closePostSplit();
        safeCall('openHashtag', [n.getAttribute('data-tag')]);
      });
    });

    wireCmtRx();
  }

  /* ============================================================
   * COMMENT REACTION PICKER
   * ============================================================ */
  function openCommentReactionPicker(pid, cid) {
    var RX = ['❤️', '😂', '😮', '😢', '😡', '👍'];
    var map = splitCommentReactions[cid] || {};
    var uid = getMyUid();
    var mine = map[uid];
    var mineType = (typeof mine === 'string') ? mine : (mine && mine.type);

    var picker = qs('#rxPicker');
    if (!picker) return false;

    picker.innerHTML = RX.map(function (r) {
      var isCur = (mineType === r);
      return '<button data-crx-pick="' + r + '" style="' +
               (isCur ? 'background:var(--accent-soft);border-radius:.7rem' : '') +
             '">' + r + '</button>';
    }).join('');

    var ov = qs('#ovReactions');
    if (ov) {
      ov.style.zIndex = '130';
      ov.classList.add('open');
    }

    qsa('[data-crx-pick]', picker).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovReactions']);
        await toggleCommentReaction(pid, cid, b.getAttribute('data-crx-pick'));
      });
    });
    return true;
  }

  /* ============================================================
   * TOGGLE COMMENT REACTION
   * ============================================================ */
  async function toggleCommentReaction(pid, cid, emoji) {
    var uid = getMyUid();
    if (!pid || !cid || !uid) return false;

    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      var ref = fbDb.ref('commentReactions/' + pid + '/' + cid + '/' + uid);
      var snap = await ref.get();
      var curV = snap.val();
      var curT = (typeof curV === 'string') ? curV : (curV && curV.type);

      if (curT === emoji) {
        await ref.remove();
      } else {
        await ref.set({ type: emoji, at: timeNow() });

        try {
          var cs = await fbDb.ref('comments/' + pid + '/' + cid).get();
          var c = cs.val();
          if (c && c.uid && c.uid !== uid) {
            var me = getMyProfile();
            safeCall('pushNotification', [c.uid, {
              type: 'reaction',
              fromUid: uid,
              fromName: (me && me.name) || 'User',
              fromPhoto: (me && me.photo) || '',
              text: emoji + ' ' + T('reacted_to'),
              postId: pid,
              commentId: cid,
              createdAt: timeNow()
            }]);
          }
        } catch (e) {}
      }

      if (!splitCommentReactions[cid]) splitCommentReactions[cid] = {};
      if (curT === emoji) delete splitCommentReactions[cid][uid];
      else splitCommentReactions[cid][uid] = emoji;
      window.splitCommentReactions = splitCommentReactions;

      repaintAllSplitReactions();
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * COMMENT MENU
   * ============================================================ */
  async function openSplitCommentMenu(cid) {
    if (!splitPostId) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    var snap = await fbDb.ref('comments/' + splitPostId + '/' + cid).get();
    var c = snap.val();
    if (!c) return false;

    var uid = getMyUid();
    var mine = c.uid === uid;
    var items = [];

    if (mine) {
      items.push({ k: 'edit',   i: 'edit',  label: T('edit_comment') });
      items.push({ k: 'delete', i: 'trash', label: T('delete_comment'), danger: true });
    } else {
      items.push({ k: 'report', i: 'flag',  label: T('report'), danger: true });
      items.push({ k: 'block',  i: 'block', label: T('block'),  danger: true });
    }
    items.push({ k: 'copy', i: 'copy', label: T('copy_text') });

    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;

    sheet.innerHTML = '<div class="sheet-handle"></div>' + items.map(function (it) {
      return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" data-scm="' + it.k + '">' +
               svgIcon(it.i) +
               '<span>' + esc(it.label) + '</span>' +
             '</div>';
    }).join('');

    safeCall('openOverlay', ['ovMsgMenu']);

    qsa('[data-scm]', sheet).forEach(function (n) {
      n.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var k = n.getAttribute('data-scm');

        if (k === 'edit') {
          var nt = await safeCall('promptDialog', [T('edit_comment'), c.text || '']);
          if (nt == null) return;
          var txt = String(nt).trim();
          if (!txt) return;
          try {
            await fbDb.ref('comments/' + splitPostId + '/' + cid).update({
              text: txt,
              updatedAt: timeNow()
            });
          } catch (e) { safeToast(e.message || T('error'), 'err'); }
        }
        else if (k === 'delete') {
          var ok = await safeCall('confirmDialog', [T('delete_comment'), T('are_you_sure')]);
          if (!ok) return;
          try {
            await fbDb.ref('comments/' + splitPostId + '/' + cid).remove();
            await fbDb.ref('commentReactions/' + splitPostId + '/' + cid).remove();
          } catch (e) { safeToast(e.message || T('error'), 'err'); }
        }
        else if (k === 'report') {
          safeCall('openReport', ['comment', cid, splitPostId]);
        }
        else if (k === 'block') {
          safeCall('blockUser', [c.uid]);
        }
        else if (k === 'copy') {
          try {
            await navigator.clipboard.writeText(c.text || '');
            safeToast(T('copied'), 'ok');
          } catch (e) {
            safeToast(c.text || '');
          }
        }
      });
    });
    return true;
  }

  /* ============================================================
   * SEND COMMENT
   * ============================================================ */
  async function sendSplitComment() {
    if (!splitPostId) return false;
    var input = qs('#splitCommentInput');
    if (!input) return false;

    var text = input.value.trim();
    if (!text) return false;

    input.value = '';

    var pid = splitPostId;
    var parent = splitReplyTarget ? splitReplyTarget.commentId : null;
    var parentName = splitReplyTarget ? splitReplyTarget.name : '';
    var parentUid = splitReplyTarget ? splitReplyTarget.uid : null;
    splitReplyTarget = null;
    input.placeholder = T('write_comment');

    var fbDb = getDB();
    var uid = getMyUid();
    if (!fbDb || !uid) return false;

    try {
      var ref = fbDb.ref('comments/' + pid).push();
      var me = getMyProfile();

      await ref.set({
        id: ref.key,
        uid: uid,
        authorName: (me && me.name) || '',
        authorPhoto: (me && me.photo) || '',
        text: text,
        parent: parent || null,
        parentUid: parentUid || null,
        createdAt: timeNow()
      });

      var post = findPost(pid);
      if (post && post.uid && post.uid !== uid) {
        safeCall('pushNotification', [post.uid, {
          type: parent ? 'reply' : 'comment',
          fromUid: uid,
          fromName: (me && me.name) || 'User',
          fromPhoto: (me && me.photo) || '',
          text: parent ? T('replied_to') : T('commented_on'),
          postId: pid,
          commentId: ref.key,
          parentName: parentName,
          createdAt: timeNow()
        }]);
      }

      if (parentUid && parentUid !== uid && parentUid !== (post && post.uid)) {
        safeCall('pushNotification', [parentUid, {
          type: 'reply',
          fromUid: uid,
          fromName: (me && me.name) || 'User',
          fromPhoto: (me && me.photo) || '',
          text: T('replied_to'),
          postId: pid,
          commentId: ref.key,
          parentName: parentName,
          createdAt: timeNow()
        }]);
      }

      safeCall('awardXp', ['comment_made', 2]);
      safeCall('bumpDaily', ['comment', 1]);

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    var closeBtn = qs('#splitClose', scope);
    if (closeBtn && closeBtn.dataset.splitBound !== '1') {
      closeBtn.dataset.splitBound = '1';
      closeBtn.addEventListener('click', closePostSplit);
      bound = true;
    }

    var mfs = qs('#splitMediaFs', scope);
    if (mfs && mfs.dataset.splitBound !== '1') {
      mfs.dataset.splitBound = '1';
      mfs.addEventListener('click', function () {
        var el = qs('#ovSplitComments');
        if (!el) return;
        if (el.classList.contains('video-fs')) el.classList.remove('video-fs');
        else { el.classList.add('video-fs'); el.classList.remove('comments-fs'); }
      });
      bound = true;
    }

    var cfs = qs('#splitCommentsFs', scope);
    if (cfs && cfs.dataset.splitBound !== '1') {
      cfs.dataset.splitBound = '1';
      cfs.addEventListener('click', function () {
        var el = qs('#ovSplitComments');
        if (!el) return;
        if (el.classList.contains('comments-fs')) el.classList.remove('comments-fs');
        else { el.classList.add('comments-fs'); el.classList.remove('video-fs'); }
      });
      bound = true;
    }

    var send = qs('#splitSendComment', scope);
    if (send && send.dataset.splitBound !== '1') {
      send.dataset.splitBound = '1';
      send.addEventListener('click', sendSplitComment);
      bound = true;
    }

    var inp = qs('#splitCommentInput', scope);
    if (inp && inp.dataset.splitBound !== '1') {
      inp.dataset.splitBound = '1';
      inp.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendSplitComment();
        }
      });
      bound = true;
    }

    var div = qs('#splitDivider', scope);
    if (div && div.dataset.splitBound !== '1') {
      div.dataset.splitBound = '1';
      div.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        var top = qs('#splitTop');
        if (!top) return;
        splitDividerDrag = {
          y: e.clientY,
          topH: top.getBoundingClientRect().height
        };
        document.body.style.userSelect = 'none';
      });
      bound = true;
    }

    return bound;
  }

  function unbind(root) {
    var scope = root || document;
    ['#splitClose', '#splitMediaFs', '#splitCommentsFs',
     '#splitSendComment', '#splitCommentInput', '#splitDivider']
      .forEach(function (sel) {
        var n = qs(sel, scope);
        if (!n) return;
        var clone = n.cloneNode(true);
        clone.removeAttribute('data-split-bound');
        n.parentNode && n.parentNode.replaceChild(clone, n);
      });
  }

  /* ============================================================
   * DIVIDER DRAG — document-level
   * ============================================================ */
  document.addEventListener('pointermove', function (e) {
    if (!splitDividerDrag) return;
    var ov = qs('#ovSplitComments');
    var top = qs('#splitTop');
    if (!ov || !top) return;

    var total = ov.getBoundingClientRect().height;
    var delta = e.clientY - splitDividerDrag.y;
    var newTop = splitDividerDrag.topH + delta;
    newTop = Math.max(total * 0.25, Math.min(total * 0.85, newTop));
    top.style.flex = '0 0 ' + ((newTop / total) * 100) + '%';
  });

  document.addEventListener('pointerup', function () {
    if (!splitDividerDrag) return;
    splitDividerDrag = null;
    document.body.style.userSelect = '';
  });

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openPostSplit              = openPostSplit;
  window.closePostSplit             = closePostSplit;
  window.refreshSplitPost           = refreshSplitPost;
  window.loadSplitComments          = loadSplitComments;
  window.commentHTML2               = commentHTML2;
  window.wireSplitComments          = wireSplitComments;
  window.openCommentReactionPicker  = openCommentReactionPicker;
  window.toggleCommentReaction      = toggleCommentReaction;
  window.openSplitCommentMenu       = openSplitCommentMenu;
  window.repaintAllSplitReactions   = repaintAllSplitReactions;

  window.SaikoPostSplit = {
    open: openPostSplit,
    close: closePostSplit,
    refresh: refreshSplitPost,
    loadComments: loadSplitComments,
    sendComment: sendSplitComment,
    bind: bind,
    unbind: unbind,
    getCurrentId: function () { return splitPostId; }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  try {
    console.debug('[boot] feature 067 — post-split ready (window.splitPostId + reaction UI fix)');
  } catch (e) {}

})();