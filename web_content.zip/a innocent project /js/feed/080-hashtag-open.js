/* ============================================================
 * FEATURE:        Hashtag Open
 * FEATURE NUMBER: 080
 * FILE:           js/feed/080-hashtag-open.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Opens the hashtag feed overlay (#ovHashtag) and renders
 *   every post in the local cache whose text contains the
 *   requested #tag.
 *
 *   Public function:
 *     window.openHashtag(tag) → boolean
 *
 *   Behaviour preserved 1:1 from the original §26 block:
 *
 *     1. Normalise the tag → String(tag||'').toLowerCase()
 *     2. openOverlay('ovHashtag')
 *     3. #hashtagTitle.textContent = '#' + tag
 *     4. Filter postsCache for posts where !isSuspended(post)
 *        AND post.text.toLowerCase().indexOf('#' + tag) !== -1
 *     5. Empty → show "no posts" empty state
 *     6. Otherwise → render each via the shared post-card
 *        renderer (window.postHTML), then:
 *          • wirePostInteractions(root)
 *          • paintPostCounts()
 *          • observePostVideos(root)
 *
 *   IMPORTANT — substring semantics preserved:
 *     The filter uses `indexOf('#' + tag)` — that is a plain
 *     SUBSTRING check, not a hashtag-boundary check. So
 *     opening "#cat" will also match "#category" if that
 *     substring appears anywhere in the post text. This is
 *     exactly how the original behaved; we do NOT tighten it.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §26 SAVED / HASHTAGS / TRENDING →
 *     openHashtag(tag)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache            js/feed/051-feed-render.js
 *   - isSuspended                  js/feed/051-feed-render.js
 *   - window.postHTML              js/feed/post-card.js
 *   - window.wirePostInteractions  js/feed/post-card.js
 *   - paintPostCounts              js/feed/051-feed-render.js
 *   - observePostVideos            js/feed/082-video-observer.js
 *   - openOverlay                  js/nav/038-overlay-system.js
 *   - t(key) / esc(str)            helpers
 *
 * DOM ELEMENTS USED:
 *   #ovHashtag       (overlay container)
 *   #hashtagTitle    (overlay title)
 *   #hashtagBody     (list container)
 *
 * FIREBASE PATHS:
 *   none directly — this feature reads from the local
 *   postsCache that feature 051 maintains via its live
 *   listener on `posts`.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openHashtag          (original name preserved)
 *   window.SaikoHashtagOpen = {
 *     open,
 *     filterPosts,     // pure — returns the matching list
 *     buildTitle,      // pure — returns '#<tag>'
 *     renderEmpty,     // helper — writes the empty state
 *     renderList       // helper — writes the list and wires it
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { if (typeof window.svgIcon === 'function') return window.svgIcon(name, fill); } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[hashtag-open] safeCall:', name, e); }
    return undefined;
  }
  function getPostsCache() {
    try {
      if (Array.isArray(window.postsCache)) return window.postsCache;
    } catch (e) {}
    return [];
  }
  function isSuspended(obj) {
    try {
      if (typeof window.isSuspended === 'function') return !!window.isSuspended(obj);
    } catch (e) {}
    /* Fallback — same predicate used in feature 051. */
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > Date.now()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > Date.now();
  }

  /* ----------------------------------------------------------
   * buildTitle(tag)
   * Pure — mirrors the original '#<lowercased-tag>' string.
   * ---------------------------------------------------------- */
  function buildTitle(tag) {
    return '#' + String(tag || '').toLowerCase();
  }

  /* ----------------------------------------------------------
   * filterPosts(tag)
   * Pure — returns the ordered list of posts matching the tag.
   *
   * Preserved 1:1 from the original inline filter:
   *   (postsCache||[])
   *     .filter(p => !isSuspended(p)
   *               && (p.text||'').toLowerCase().indexOf('#'+tag) !== -1)
   * ---------------------------------------------------------- */
  function filterPosts(tag) {
    var needle = '#' + String(tag || '').toLowerCase();
    var cache = getPostsCache();
    return cache.filter(function (p) {
      if (!p) return false;
      if (isSuspended(p)) return false;
      var text = (p.text || '').toLowerCase();
      return text.indexOf(needle) !== -1;
    });
  }

  /* ----------------------------------------------------------
   * renderEmpty(body)
   * Writes the exact empty-state markup the original used.
   * ---------------------------------------------------------- */
  function renderEmpty(body) {
    if (!body) return;
    body.innerHTML =
      '<div class="empty">' +
        '<p>' + esc(T('no_posts')) + '</p>' +
      '</div>';
  }

  /* ----------------------------------------------------------
   * renderList(body, posts)
   * Writes the post cards and wires interactions. Preserved
   * 1:1 from the original tail of openHashtag():
   *   body.innerHTML = list.map(postHTML).join('');
   *   wirePostInteractions(body);
   *   paintPostCounts();
   *   observePostVideos(body);
   * ---------------------------------------------------------- */
  function renderList(body, posts) {
    if (!body) return;
    var html = (posts || []).map(function (p) {
      try {
        if (typeof window.postHTML === 'function') return window.postHTML(p);
      } catch (e) {}
      return '';
    }).join('');
    body.innerHTML = html;
    safeCall('wirePostInteractions', [body]);
    safeCall('paintPostCounts');
    safeCall('observePostVideos', [body]);
  }

  /* ----------------------------------------------------------
   * open(tag)
   * Preserved 1:1 from original openHashtag(tag).
   * Returns true when the overlay was opened (even if empty),
   * false when tag was missing.
   * ---------------------------------------------------------- */
  function open(tag) {
    var normalised = String(tag || '').toLowerCase();

    /* 1) Open the overlay --------------------------------- */
    safeCall('openOverlay', ['ovHashtag']);

    /* 2) Set the title ------------------------------------ */
    var titleEl = qs('#hashtagTitle');
    if (titleEl) titleEl.textContent = buildTitle(normalised);

    /* 3) Filter the cache --------------------------------- */
    var list = filterPosts(normalised);

    /* 4) Render ------------------------------------------- */
    var body = qs('#hashtagBody');
    if (!body) return true;   /* overlay still opened */

    if (!list.length) {
      renderEmpty(body);
      return true;
    }
    renderList(body, list);
    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so feature 051 (feed tabs),
   * feature 055 (post-card), feature 067 (post-split), and
   * feature 047 (deep-link #tag-) keep working unchanged. */
  window.openHashtag = open;

  window.SaikoHashtagOpen = {
    open: open,
    filterPosts: filterPosts,
    buildTitle: buildTitle,
    renderEmpty: renderEmpty,
    renderList: renderList
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 080 — hashtag-open ready');
  } catch (e) {}

})();