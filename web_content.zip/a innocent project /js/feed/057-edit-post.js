/* ============================================================
 * FEATURE:        Edit Post
 * FEATURE NUMBER: 057
 * FILE:           js/feed/057-edit-post.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused entry point for editing an existing post.
 *
 *   In the original single-file build, the "Edit post" action
 *   was inlined inside the post-options bottom sheet (see
 *   feature 088 openPostMenu) as:
 *
 *       if (k === 'edit') openComposer(post);
 *
 *   The composer itself (feature 053) then handled the rest —
 *   populating the text, media, and switching publish() into
 *   "update" mode based on editingPostId.
 *
 *   This module extracts that single responsibility into a
 *   named, guarded entry point so:
 *
 *     • Any module can programmatically trigger an edit
 *       without knowing about the composer.
 *     • Ownership/permission checks live in ONE place
 *       (only the author can edit their post).
 *     • The composer remains unchanged.
 *
 *   Public function:
 *     window.editPost(postId)  → Promise<boolean>
 *     window.openEditPost(postId) → Promise<boolean> (alias)
 *
 *   Behaviour preserved 1:1 from the original:
 *     • Looks up the post in window.postsCache
 *     • Refuses if the post is missing
 *     • Refuses if the current user is not the author
 *     • Delegates to window.openComposer(post) with the full
 *       post object (the same object the original inline
 *       handler passed).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu() → case 'edit'
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache      (feature 051)
 *   - window.myUid           (feature 004)
 *   - window.openComposer    (feature 053)
 *   - window.toast           (feature 042)  — for error msgs
 *   - t(key)                 (046 i18n)
 *
 * DOM ELEMENTS USED:
 *   none directly — the composer (053) owns the overlay.
 *
 * FIREBASE PATHS:
 *   none — writes happen later inside composer.publish()
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.editPost
 *   window.openEditPost
 *   window.SaikoEditPost = {
 *     edit, canEdit, findPost, isAuthor
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getPostsCache() {
    try {
      if (Array.isArray(window.postsCache)) return window.postsCache;
    } catch (e) {}
    return [];
  }

  /* ----------------------------------------------------------
   * findPost(postId)
   * Looks the post up in the shared cache. Returns the full
   * post object or null.
   * ---------------------------------------------------------- */
  function findPost(postId) {
    if (!postId) return null;
    var cache = getPostsCache();
    for (var i = 0; i < cache.length; i++) {
      if (cache[i] && cache[i].id === postId) return cache[i];
    }
    return null;
  }

  /* ----------------------------------------------------------
   * isAuthor(post)
   * Pure check — is the current user the author of `post`?
   * ---------------------------------------------------------- */
  function isAuthor(post) {
    if (!post) return false;
    var uid = getMyUid();
    if (!uid) return false;
    return post.uid === uid;
  }

  /* ----------------------------------------------------------
   * canEdit(postId)
   * Convenience — resolves the post and returns a boolean.
   * ---------------------------------------------------------- */
  function canEdit(postId) {
    var post = findPost(postId);
    return !!post && isAuthor(post);
  }

  /* ----------------------------------------------------------
   * edit(postId)
   * Preserved 1:1 from the original `case 'edit'` behaviour:
   *   - resolve the post
   *   - bail with an error toast if missing
   *   - bail silently if the current user is not the author
   *     (the original menu never showed the edit option to
   *      non-authors, so this is a defensive guard)
   *   - delegate to window.openComposer(post) with the full
   *     post object
   *
   * Returns Promise<boolean> for caller convenience.
   * ---------------------------------------------------------- */
  async function edit(postId) {
    if (!postId) return false;

    /* 1) Resolve the post -------------------------------- */
    var post = findPost(postId);
    if (!post) {
      safeToast(T('error'), 'err');
      return false;
    }

    /* 2) Author guard ------------------------------------ */
    if (!isAuthor(post)) return false;

    /* 3) Delegate to the composer ------------------------ */
    try {
      if (typeof window.openComposer === 'function') {
        window.openComposer(post);
        return true;
      }
    } catch (e) {
      console.warn('[edit-post] openComposer failed', e);
    }

    safeToast(T('error'), 'err');
    return false;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  window.editPost     = edit;
  window.openEditPost = edit;

  window.SaikoEditPost = {
    edit: edit,
    canEdit: canEdit,
    findPost: findPost,
    isAuthor: isAuthor
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 057 — edit-post ready');
  } catch (e) {}

})();