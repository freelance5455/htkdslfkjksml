/* ============================================================
 * FEATURE:        Gallery Swipe (Enhanced Gestures)
 * FEATURE NUMBER: 076
 * FILE:           js/feed/076-gallery-swipe.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Enhanced input gestures for the fullscreen image viewer
 *   (#ovViewer). The original single-file build had a single
 *   touch-swipe handler inline in the gallery block — that
 *   basic swipe lives in feature 075
 *   (js/feed/075-gallery-viewer.js) and is preserved there
 *   byte-for-byte.
 *
 *   This module adds OPT-IN gestures that the original did not
 *   have. Nothing here runs automatically — a caller must
 *   explicitly invoke one of the attach functions so the
 *   original swipe behaviour is never double-bound or
 *   overridden by default:
 *
 *     • Keyboard navigation — ← / → keys, Esc to close.
 *       Auto-enabled when the viewer overlay is open (via
 *       document-level keydown delegation).
 *
 *     • Mouse drag on desktop — click-and-drag horizontally
 *       across the image to trigger prev / next.
 *       Attach explicitly: SaikoGallerySwipe.attachMouseDrag(el)
 *
 *     • Velocity-based touch swipe — an alternative to 075's
 *       distance-only rule. Fast small flicks trigger the same
 *       navigation as a slow long swipe.
 *       Attach explicitly: SaikoGallerySwipe.attachTouchSwipe(el)
 *       (typically the caller will NOT attach both 075 and 076
 *        swipe handlers to the same element).
 *
 *   All gestures route through feature 075's public API —
 *   window.SaikoGalleryViewer.next() / .prev() / .showIndex() —
 *   so state stays canonical and the counter/img src update
 *   exactly as the original.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §16 GALLERY VIEWER → the touch start/end IIFE
 *     (that basic handler is already extracted into 075).
 *   This module is entirely additive.
 *
 * DEPENDENCIES (loaded earlier):
 *   - SaikoGalleryViewer       js/feed/075-gallery-viewer.js
 *                              (window.SaikoGalleryViewer)
 *   - closeOverlay             js/nav/038-overlay-system.js
 *                              (safely-called)
 *   - getViewerState           SaikoGalleryViewer.getState
 *                              (safely-called)
 *
 * DOM ELEMENTS USED:
 *   #ovViewer        (open-state check)
 *   #viewerWrap      (default attach target for mouse drag)
 *   The element the caller passes to attachMouseDrag /
 *   attachTouchSwipe.
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoGallerySwipe = {
 *     // opt-in enhancers
 *     attachMouseDrag, detachMouseDrag,
 *     attachTouchSwipe, detachTouchSwipe,
 *
 *     // keyboard
 *     enableKeyboard, disableKeyboard,
 *     isKeyboardEnabled,
 *
 *     // direct programmatic nav (thin wrappers)
 *     next, prev,
 *
 *     // config
 *     CONFIG
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONFIG
   * ============================================================ */
  var CONFIG = {
    /* distance threshold (matches 075's rule for consistency) */
    DIST_THRESHOLD: 50,

    /* velocity threshold — px/ms. Above this, a small flick
     * still counts as a swipe. Chosen so a ~150 ms flick of
     * 30 px triggers nav, but a slow 40 px drag does not. */
    VELOCITY_THRESHOLD: 0.35,

    /* max ms between touch start and end for velocity check */
    FLICK_TIME_MS: 260,

    /* ignore tiny vertical movement — only horizontal counts */
    MAX_VERTICAL_DRIFT: 80
  };

  /* ============================================================
   * INTERNAL STATE
   * ============================================================ */
  var mouseDrag = {
    el: null,
    onDown: null,
    onMove: null,
    onUp: null,
    onCancel: null,
    active: false,
    startX: 0,
    startY: 0,
    dragging: false
  };

  var touchSwipe = {
    el: null,
    onStart: null,
    onMove: null,
    onEnd: null,
    onCancel: null,
    active: false,
    startX: 0,
    startY: 0,
    startT: 0,
    lastX: 0,
    lastT: 0,
    verticalDrift: 0
  };

  var keyboardEnabled = false;
  var keyboardHandler = null;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function isViewerOpen() {
    var ov = document.getElementById('ovViewer');
    return !!(ov && ov.classList.contains('open'));
  }

  function getViewer() {
    try {
      if (window.SaikoGalleryViewer &&
          typeof window.SaikoGalleryViewer === 'object') {
        return window.SaikoGalleryViewer;
      }
    } catch (e) {}
    return null;
  }

  function viewerState() {
    var v = getViewer();
    if (v && typeof v.getState === 'function') {
      try { return v.getState(); } catch (e) {}
    }
    return { images: [], index: 0, postId: null };
  }

  function viewerNext() {
    var v = getViewer();
    if (v && typeof v.next === 'function') { try { return v.next(); } catch (e) {} }
  }

  function viewerPrev() {
    var v = getViewer();
    if (v && typeof v.prev === 'function') { try { return v.prev(); } catch (e) {} }
  }

  function closeViewer() {
    try {
      if (typeof window.closeOverlay === 'function') {
        window.closeOverlay('ovViewer');
      } else {
        var ov = document.getElementById('ovViewer');
        if (ov) ov.classList.remove('open');
      }
    } catch (e) {}
  }

  /* ============================================================
   * KEYBOARD NAVIGATION
   * ============================================================
   * Active only while #ovViewer is open. Bind once via
   * document-level keydown so the caller does not have to
   * coordinate with overlay open/close.
   * ============================================================ */
  function enableKeyboard() {
    if (keyboardEnabled) return true;

    keyboardHandler = function (e) {
      if (!isViewerOpen()) return;
      if (!e) return;
      var key = e.key;

      /* Ignore keys while the user is typing into an input
       * (safety — the viewer has no inputs, but a stray
       * focus should never hijack text). */
      var t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' ||
                (t.isContentEditable === true))) {
        return;
      }

      if (key === 'ArrowRight') {
        e.preventDefault();
        viewerNext();
      } else if (key === 'ArrowLeft') {
        e.preventDefault();
        viewerPrev();
      } else if (key === 'Escape') {
        e.preventDefault();
        closeViewer();
      }
    };

    try {
      document.addEventListener('keydown', keyboardHandler);
      keyboardEnabled = true;
      return true;
    } catch (e) {
      keyboardHandler = null;
      keyboardEnabled = false;
      return false;
    }
  }

  function disableKeyboard() {
    if (!keyboardEnabled || !keyboardHandler) return false;
    try { document.removeEventListener('keydown', keyboardHandler); }
    catch (e) {}
    keyboardHandler = null;
    keyboardEnabled = false;
    return true;
  }

  function isKeyboardEnabled() { return keyboardEnabled; }

  /* ============================================================
   * MOUSE DRAG (desktop)
   * ============================================================
   * Horizontal click-and-drag across the element triggers
   * prev / next. Uses pointer events so it also works on
   * hybrid touch devices without double-firing.
   *
   * Attach explicitly; default target in callers is
   * #viewerWrap.
   * ============================================================ */
  function attachMouseDrag(el) {
    var target = el || document.getElementById('viewerWrap');
    if (!target) return false;

    /* Already attached to this same element? */
    if (mouseDrag.active && mouseDrag.el === target) return true;
    if (mouseDrag.active) detachMouseDrag();

    var onDown = function (e) {
      /* Left button only */
      if (e.button != null && e.button !== 0) return;
      /* Do not start a drag on buttons or links */
      var t = e.target;
      if (t && t.closest && (t.closest('button') || t.closest('a'))) return;

      mouseDrag.active    = true;
      mouseDrag.dragging  = true;
      mouseDrag.startX    = e.clientX;
      mouseDrag.startY    = e.clientY;

      try { target.style.cursor = 'grabbing'; } catch (err) {}
    };

    var onMove = function (e) {
      if (!mouseDrag.dragging) return;
      /* Prevent text selection / image ghost drag */
      if (e.preventDefault) e.preventDefault();
    };

    var onUp = function (e) {
      if (!mouseDrag.dragging) return;
      mouseDrag.dragging = false;
      try { target.style.cursor = ''; } catch (err) {}

      var dx = (e.clientX != null ? e.clientX : 0) - mouseDrag.startX;
      var dy = (e.clientY != null ? e.clientY : 0) - mouseDrag.startY;
      if (Math.abs(dy) > CONFIG.MAX_VERTICAL_DRIFT) return;
      if (Math.abs(dx) < CONFIG.DIST_THRESHOLD) return;

      if (dx < 0) viewerNext();
      else        viewerPrev();
    };

    var onCancel = function () {
      mouseDrag.dragging = false;
      try { target.style.cursor = ''; } catch (err) {}
    };

    target.addEventListener('mousedown',  onDown);
    target.addEventListener('mousemove',  onMove);
    target.addEventListener('mouseup',    onUp);
    target.addEventListener('mouseleave', onCancel);

    mouseDrag.el     = target;
    mouseDrag.onDown = onDown;
    mouseDrag.onMove = onMove;
    mouseDrag.onUp   = onUp;
    mouseDrag.onCancel = onCancel;

    return true;
  }

  function detachMouseDrag() {
    if (!mouseDrag.el) return false;
    var el = mouseDrag.el;
    try {
      el.removeEventListener('mousedown',  mouseDrag.onDown);
      el.removeEventListener('mousemove',  mouseDrag.onMove);
      el.removeEventListener('mouseup',    mouseDrag.onUp);
      el.removeEventListener('mouseleave', mouseDrag.onCancel);
      el.style.cursor = '';
    } catch (e) {}
    mouseDrag.el = null;
    mouseDrag.onDown = mouseDrag.onMove = mouseDrag.onUp = mouseDrag.onCancel = null;
    mouseDrag.active = false;
    mouseDrag.dragging = false;
    return true;
  }

  /* ============================================================
   * VELOCITY-BASED TOUCH SWIPE (opt-in)
   * ============================================================
   * Alternative to 075's distance-only rule. Adds:
   *   • velocity detection (fast small flicks work)
   *   • vertical-drift guard (prevents accidental trigger
   *     during page scroll gestures)
   *
   * Do NOT attach this to the same element that already has
   * 075's basic touch swipe — pick one. Callers that want
   * velocity should detach 075's handler first (or attach
   * this to a different layer).
   * ============================================================ */
  function attachTouchSwipe(el) {
    var target = el || document.getElementById('viewerWrap');
    if (!target) return false;

    if (touchSwipe.active && touchSwipe.el === target) return true;
    if (touchSwipe.active) detachTouchSwipe();

    var onStart = function (e) {
      if (!e.touches || !e.touches.length) return;
      touchSwipe.active        = true;
      touchSwipe.startX        = e.touches[0].clientX;
      touchSwipe.startY        = e.touches[0].clientY;
      touchSwipe.lastX         = touchSwipe.startX;
      touchSwipe.startT        = Date.now();
      touchSwipe.lastT         = touchSwipe.startT;
      touchSwipe.verticalDrift = 0;
    };

    var onMove = function (e) {
      if (!touchSwipe.active || !e.touches || !e.touches.length) return;
      var cx = e.touches[0].clientX;
      var cy = e.touches[0].clientY;
      touchSwipe.verticalDrift = Math.max(
        touchSwipe.verticalDrift,
        Math.abs(cy - touchSwipe.startY)
      );
      touchSwipe.lastX = cx;
      touchSwipe.lastT = Date.now();
    };

    var onEnd = function (e) {
      if (!touchSwipe.active) return;
      touchSwipe.active = false;

      var endX = (e.changedTouches && e.changedTouches[0])
        ? e.changedTouches[0].clientX
        : touchSwipe.lastX;
      var dx = endX - touchSwipe.startX;
      var dt = Math.max(1, Date.now() - touchSwipe.startT);

      /* Ignore mostly-vertical gestures (page scroll). */
      if (touchSwipe.verticalDrift > CONFIG.MAX_VERTICAL_DRIFT) return;

      /* Distance OR velocity — either one triggers. */
      var distOK     = Math.abs(dx) >= CONFIG.DIST_THRESHOLD;
      var velocity   = Math.abs(dx) / dt;
      var velOK      = (velocity >= CONFIG.VELOCITY_THRESHOLD) &&
                       (dt <= CONFIG.FLICK_TIME_MS);

      if (!distOK && !velOK) return;

      if (dx < 0) viewerNext();
      else        viewerPrev();
    };

    var onCancel = function () { touchSwipe.active = false; };

    target.addEventListener('touchstart',  onStart,  { passive: true });
    target.addEventListener('touchmove',   onMove,   { passive: true });
    target.addEventListener('touchend',    onEnd,    { passive: true });
    target.addEventListener('touchcancel', onCancel, { passive: true });

    touchSwipe.el      = target;
    touchSwipe.onStart = onStart;
    touchSwipe.onMove  = onMove;
    touchSwipe.onEnd   = onEnd;
    touchSwipe.onCancel = onCancel;

    return true;
  }

  function detachTouchSwipe() {
    if (!touchSwipe.el) return false;
    var el = touchSwipe.el;
    try {
      el.removeEventListener('touchstart',  touchSwipe.onStart);
      el.removeEventListener('touchmove',   touchSwipe.onMove);
      el.removeEventListener('touchend',    touchSwipe.onEnd);
      el.removeEventListener('touchcancel', touchSwipe.onCancel);
    } catch (e) {}
    touchSwipe.el = null;
    touchSwipe.onStart = touchSwipe.onMove = touchSwipe.onEnd = touchSwipe.onCancel = null;
    touchSwipe.active = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoGallerySwipe = {
    /* opt-in enhancers */
    attachMouseDrag: attachMouseDrag,
    detachMouseDrag: detachMouseDrag,
    attachTouchSwipe: attachTouchSwipe,
    detachTouchSwipe: detachTouchSwipe,

    /* keyboard */
    enableKeyboard: enableKeyboard,
    disableKeyboard: disableKeyboard,
    isKeyboardEnabled: isKeyboardEnabled,

    /* direct programmatic nav (thin wrappers so callers do not
     * have to reach into SaikoGalleryViewer themselves) */
    next: viewerNext,
    prev: viewerPrev,

    /* config (read-only exposure) */
    CONFIG: CONFIG
  };

  /* ============================================================
   * AUTO-ENABLE KEYBOARD
   * The original did not have keyboard nav, but it is a
   * harmless, additive enhancement that only fires while the
   * viewer overlay is open. Enable it at DOM ready so users
   * get arrow-key navigation for free.
   *
   * If a caller wants to disable it (e.g. embedding), they can
   * call SaikoGallerySwipe.disableKeyboard() at any time.
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      enableKeyboard();
    }, { once: true });
  } else {
    enableKeyboard();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 076 — gallery-swipe (enhanced) ready');
  } catch (e) {}

})();