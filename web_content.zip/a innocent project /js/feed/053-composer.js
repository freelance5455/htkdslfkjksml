/* ============================================================
 * FEATURE:        Post Composer
 * FEATURE NUMBER: 053
 * FILE:           js/feed/053-composer.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "Create Post" / "Edit Post" overlay
 *   (#ovComposer). Handles:
 *
 *     • Opening fresh or in edit mode
 *     • Text input (#composerText)
 *     • Up to 10 images per post (#composerFiles)
 *     • One video up to 5 min / 100 MB (#composerVideoFile)
 *     • Live preview grid with remove + move buttons
 *       (#composerPreview)
 *     • Upload progress bar (#composerBar)
 *     • Publish button (#btnPublish) — creates a new post or
 *       updates an existing one
 *
 *   Behaviour preserved 1:1 from the original §16 COMPOSER
 *   block.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §16 COMPOSER — composerImages / composerVideo /
 *   editingPostId / publishing state, openComposer(),
 *   renderComposerPreview(), the file-input change handlers,
 *   and the #btnPublish click handler.
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                    js/core/firebase-init.js
 *   - myUid / myProfile     js/auth/004-auth-state.js
 *   - t / esc / now         helpers
 *   - MEDIA_CONFIG          (defined in the original §1 CONFIG,
 *                            falls back to defaults below)
 *   - validateImage / validateVideo / compressImage /
 *     cloudinaryUpload / probeVideo
 *   - openOverlay / closeOverlay (038)
 *   - navigate (036)
 *   - toast (042)
 *   - awardXp / bumpDaily (features 025 area / daily stats)
 *
 * DOM ELEMENTS USED (all static in index.html):
 *   #ovComposer, #composerTitle, #btnPublish,
 *   #composerText, #composerPreview,
 *   #btnComposerImages, #btnComposerVideo,
 *   #composerFiles, #composerVideoFile, #btnComposerClear,
 *   #composerStatus, #composerBar
 *
 * FIREBASE PATHS:
 *   posts               (write — new post)
 *   posts/{id}          (update — edited post)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openComposer          (original name preserved)
 *   window.renderComposerPreview (original name preserved)
 *   window.SaikoComposer = {
 *     open, renderPreview,
 *     bind, unbind,
 *     publish,
 *     reset,
 *     getState
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * MEDIA_CONFIG — use the global if present, otherwise fall
   * back to the exact defaults from the original §1 CONFIG.
   * ---------------------------------------------------------- */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_POST_IMAGES: 10,
    MAX_POST_IMAGE_BYTES: 25 * 1024 * 1024,
    MAX_POST_VIDEO_SECONDS: 5 * 60,
    MAX_POST_VIDEO_BYTES: 100 * 1024 * 1024,
    MAX_UPLOAD_BYTES: 100 * 1024 * 1024
  };

  /* ----------------------------------------------------------
   * Module state — preserved from the original source.
   * ---------------------------------------------------------- */
  var composerImages = [];
  var composerVideo = '';
  var editingPostId = null;
  var publishing = false;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[composer] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * RESET — clear all media + text + editing state.
   * ---------------------------------------------------------- */
  function reset() {
    composerImages = [];
    composerVideo = '';
    editingPostId = null;
    publishing = false;

    var textEl = qs('#composerText');
    if (textEl) textEl.value = '';

    var prev = qs('#composerPreview');
    if (prev) prev.innerHTML = '';

    var status = qs('#composerStatus');
    if (status) status.textContent = '';

    var bar = qs('#composerBar');
    if (bar) {
      bar.classList.add('hidden');
      var i = bar.querySelector('i');
      if (i) i.style.width = '0';
    }

    var clearBtn = qs('#btnComposerClear');
    if (clearBtn) clearBtn.classList.add('hidden');

    var title = qs('#composerTitle');
    if (title) title.textContent = T('create_post');
  }

  /* ----------------------------------------------------------
   * OPEN — fresh or in edit mode.
   * Preserved 1:1 from original openComposer(post).
   * ---------------------------------------------------------- */
  function open(post) {
    editingPostId = post ? post.id : null;

    var title = qs('#composerTitle');
    if (title) title.textContent = post ? T('edit_post') : T('create_post');

    var textEl = qs('#composerText');
    if (textEl) textEl.value = post ? (post.text || '') : '';

    var prev = qs('#composerPreview');
    if (prev) prev.innerHTML = '';

    var status = qs('#composerStatus');
    if (status) status.textContent = '';

    var bar = qs('#composerBar');
    if (bar) bar.classList.add('hidden');

    /* Media state ----------------------------------------- */
    if (post) {
      composerImages = Array.isArray(post.images)
        ? post.images.slice()
        : (post.image ? [post.image] : []);
      composerVideo = post.video || '';
    } else {
      composerImages = [];
      composerVideo = '';
    }

    publishing = false;
    var pub = qs('#btnPublish');
    if (pub) pub.disabled = false;

    renderPreview();
    safeCall('openOverlay', ['ovComposer']);
  }

  /* ----------------------------------------------------------
   * RENDER PREVIEW
   * Preserved 1:1 from original renderComposerPreview().
   * ---------------------------------------------------------- */
  function renderPreview() {
    var box = qs('#composerPreview');
    if (!box) return;

    var html = '';

    if (composerVideo) {
      html += '<div class="post-video">' +
        '<video controls playsinline preload="metadata" src="' + esc(composerVideo) + '"></video>' +
      '</div>';
    } else if (composerImages.length) {
      html += '<div class="mi-preview">' +
        composerImages.map(function (url, i) {
          return '<div class="mi-item" data-mi="' + i + '">' +
            '<img src="' + esc(url) + '" alt="">' +
            '<span class="rm" data-rmi="' + i + '">✕</span>' +
            '<span class="move">' +
              (i > 0 ? '<button data-mvl="' + i + '">◀</button>' : '') +
              (i < composerImages.length - 1 ? '<button data-mvr="' + i + '">▶</button>' : '') +
            '</span>' +
          '</div>';
        }).join('') +
      '</div>';
      html += '<div class="mini" style="margin-top:.4rem">' +
        composerImages.length + ' / ' + MEDIA_CONFIG.MAX_POST_IMAGES + ' · ' + esc(T('composer_hint')) +
      '</div>';
    }

    box.innerHTML = html;

    /* Remove button --------------------------------------- */
    box.querySelectorAll('[data-rmi]').forEach(function (n) {
      n.addEventListener('click', function () {
        var i = Number(n.getAttribute('data-rmi'));
        composerImages.splice(i, 1);
        renderPreview();
      });
    });

    /* Move left ------------------------------------------- */
    box.querySelectorAll('[data-mvl]').forEach(function (n) {
      n.addEventListener('click', function () {
        var i = Number(n.getAttribute('data-mvl'));
        if (i > 0) {
          var a = composerImages[i - 1];
          composerImages[i - 1] = composerImages[i];
          composerImages[i] = a;
          renderPreview();
        }
      });
    });

    /* Move right ------------------------------------------ */
    box.querySelectorAll('[data-mvr]').forEach(function (n) {
      n.addEventListener('click', function () {
        var i = Number(n.getAttribute('data-mvr'));
        if (i < composerImages.length - 1) {
          var a = composerImages[i + 1];
          composerImages[i + 1] = composerImages[i];
          composerImages[i] = a;
          renderPreview();
        }
      });
    });

    /* Clear-all button visibility ------------------------- */
    var clearBtn = qs('#btnComposerClear');
    if (clearBtn) clearBtn.classList.toggle('hidden', !(composerImages.length || composerVideo));
  }

  /* ----------------------------------------------------------
   * IMAGE UPLOAD HANDLER
   * Preserved 1:1 from original #composerFiles change handler.
   * ---------------------------------------------------------- */
  async function onImagesPicked(e) {
    var files = Array.prototype.slice.call((e.target && e.target.files) || []);
    if (e.target) e.target.value = '';
    if (!files.length) return;

    var room = MEDIA_CONFIG.MAX_POST_IMAGES - composerImages.length;
    if (files.length > room) {
      safeToast(T('too_many_images').replace('{n}', MEDIA_CONFIG.MAX_POST_IMAGES), 'err');
    }
    var toUpload = files.slice(0, room);

    var bar = qs('#composerBar');
    var st  = qs('#composerStatus');
    if (bar) bar.classList.remove('hidden');
    if (st) st.textContent = T('uploading');

    try {
      for (var i = 0; i < toUpload.length; i++) {
        var f = toUpload[i];

        /* 1) Validate ------------------------------------- */
        var err = null;
        try {
          if (typeof window.validateImage === 'function') err = window.validateImage(f);
        } catch (e2) {}
        if (err) { safeToast(err, 'err'); continue; }

        /* 2) Compress ------------------------------------- */
        var comp = f;
        try {
          if (typeof window.compressImage === 'function') {
            comp = await window.compressImage(f, 1400, 0.82);
          }
        } catch (e3) {}

        /* 3) Upload to Cloudinary ------------------------- */
        var url = null;
        if (typeof window.cloudinaryUpload === 'function') {
          url = await window.cloudinaryUpload(comp, 'post_' + i + '.jpg', function (pct) {
            var total = toUpload.length;
            if (bar) {
              var barInner = bar.querySelector('i');
              if (barInner) {
                barInner.style.width = Math.round(((i + pct / 100) / total) * 100) + '%';
              }
            }
          });
        }
        if (!url) throw new Error(T('upload_failed'));

        composerImages.push(url);
        renderPreview();
      }

      if (bar) {
        var inner = bar.querySelector('i');
        if (inner) inner.style.width = '100%';
      }
      if (st) st.textContent = '';
      setTimeout(function () { if (bar) bar.classList.add('hidden'); }, 400);
    } catch (err2) {
      if (bar) bar.classList.add('hidden');
      if (st) st.textContent = '';
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
    }
  }

  /* ----------------------------------------------------------
   * VIDEO UPLOAD HANDLER
   * Preserved 1:1 from original #composerVideoFile handler.
   * ---------------------------------------------------------- */
  async function onVideoPicked(e) {
    var f = e.target && e.target.files ? e.target.files[0] : null;
    if (e.target) e.target.value = '';
    if (!f) return;

    /* 1) Validate ----------------------------------------- */
    var err = null;
    try {
      if (typeof window.validateVideo === 'function') {
        err = window.validateVideo(f, MEDIA_CONFIG.MAX_POST_VIDEO_BYTES, MEDIA_CONFIG.MAX_POST_VIDEO_SECONDS);
      }
    } catch (e2) {}
    if (err) { safeToast(err, 'err'); return; }

    try {
      /* 2) Probe duration -------------------------------- */
      var dur = 0;
      try {
        if (typeof window.probeVideo === 'function') dur = await window.probeVideo(f);
      } catch (e3) {}
      if (dur && dur > MEDIA_CONFIG.MAX_POST_VIDEO_SECONDS) {
        safeToast(T('video_too_long') + ' (' + MEDIA_CONFIG.MAX_POST_VIDEO_SECONDS + 's)', 'err');
        return;
      }

      /* 3) Upload ---------------------------------------- */
      var bar = qs('#composerBar');
      var st  = qs('#composerStatus');
      if (bar) {
        bar.classList.remove('hidden');
        var inner = bar.querySelector('i');
        if (inner) inner.style.width = '10%';
      }
      if (st) st.textContent = T('uploading');

      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(f, 'post_video.mp4', function (pct) {
          if (bar) {
            var bi = bar.querySelector('i');
            if (bi) bi.style.width = pct + '%';
          }
        });
      }
      if (!url) throw new Error(T('upload_failed'));

      composerVideo = url;
      composerImages = [];
      renderPreview();

      if (bar) {
        var inner2 = bar.querySelector('i');
        if (inner2) inner2.style.width = '100%';
      }
      if (st) st.textContent = '';
      setTimeout(function () { if (bar) bar.classList.add('hidden'); }, 400);
    } catch (err4) {
      safeToast((err4 && err4.message) ? err4.message : T('upload_failed'), 'err');
      var st2 = qs('#composerStatus'); if (st2) st2.textContent = '';
      var bar2 = qs('#composerBar'); if (bar2) bar2.classList.add('hidden');
    }
  }

  /* ----------------------------------------------------------
   * CLEAR MEDIA
   * Preserved 1:1 from original #btnComposerClear handler.
   * ---------------------------------------------------------- */
  function clearMedia() {
    composerImages = [];
    composerVideo = '';
    renderPreview();
  }

  /* ----------------------------------------------------------
   * PUBLISH
   * Preserved 1:1 from original #btnPublish click handler.
   * ---------------------------------------------------------- */
  async function publish() {
    if (publishing) return;

    var textEl = qs('#composerText');
    var text = textEl ? textEl.value.trim() : '';

    if (!text && !composerImages.length && !composerVideo) {
      safeToast(T('fill_all'), 'err');
      return;
    }

    var btn = qs('#btnPublish');
    publishing = true;
    if (btn) btn.disabled = true;

    var fbDb = getDB();
    var uid = getMyUid();
    var me = getMyProfile();

    if (!fbDb || !uid) {
      safeToast(T('error'), 'err');
      publishing = false;
      if (btn) btn.disabled = false;
      return;
    }

    try {
      if (editingPostId) {
        /* EDIT -------------------------------------------- */
        await fbDb.ref('posts/' + editingPostId).update({
          text: text,
          image: composerImages[0] || '',
          images: composerImages,
          video: composerVideo || '',
          updatedAt: timeNow()
        });
      } else {
        /* CREATE ------------------------------------------ */
        var ref = fbDb.ref('posts').push();
        await ref.set({
          id: ref.key,
          uid: uid,
          authorName: (me && me.name) || '',
          authorPhoto: (me && me.photo) || '',
          text: text,
          image: composerImages[0] || '',
          images: composerImages,
          video: composerVideo || '',
          createdAt: timeNow()
        });
        /* XP + daily stat --------------------------------- */
        safeCall('awardXp', ['post_created', 5]);
        safeCall('bumpDaily', ['post', 1]);
      }

      /* Close + notify ---------------------------------- */
      safeCall('closeOverlay', ['ovComposer']);
      safeToast(T('saved'), 'ok');
      safeCall('navigate', ['home']);
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
    } finally {
      publishing = false;
      if (btn) btn.disabled = false;
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Wires every composer control. Idempotent via dataset guards.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* Open-images button ----------------------------------- */
    var bi = qs('#btnComposerImages', scope);
    if (bi && bi.dataset.composerBound !== '1') {
      bi.dataset.composerBound = '1';
      bi.addEventListener('click', function () {
        var fi = qs('#composerFiles');
        if (fi) fi.click();
      });
      bound = true;
    }

    /* Open-video button ------------------------------------ */
    var bv = qs('#btnComposerVideo', scope);
    if (bv && bv.dataset.composerBound !== '1') {
      bv.dataset.composerBound = '1';
      bv.addEventListener('click', function () {
        var fi = qs('#composerVideoFile');
        if (fi) fi.click();
      });
      bound = true;
    }

    /* Clear media button ----------------------------------- */
    var bc = qs('#btnComposerClear', scope);
    if (bc && bc.dataset.composerBound !== '1') {
      bc.dataset.composerBound = '1';
      bc.addEventListener('click', clearMedia);
      bound = true;
    }

    /* Files input (images) --------------------------------- */
    var cf = qs('#composerFiles', scope);
    if (cf && cf.dataset.composerBound !== '1') {
      cf.dataset.composerBound = '1';
      cf.addEventListener('change', onImagesPicked);
      bound = true;
    }

    /* Video input ----------------------------------------- */
    var vf = qs('#composerVideoFile', scope);
    if (vf && vf.dataset.composerBound !== '1') {
      vf.dataset.composerBound = '1';
      vf.addEventListener('change', onVideoPicked);
      bound = true;
    }

    /* Publish button -------------------------------------- */
    var pb = qs('#btnPublish', scope);
    if (pb && pb.dataset.composerBound !== '1') {
      pb.dataset.composerBound = '1';
      pb.addEventListener('click', publish);
      bound = true;
    }

    return bound;
  }

  function unbind(root) {
    var scope = root || document;
    /* Since all handlers are named, we can detach them cleanly */
    var bi = qs('#btnComposerImages', scope);
    if (bi) {
      bi.removeEventListener('click', function () { var fi = qs('#composerFiles'); if (fi) fi.click(); });
      delete bi.dataset.composerBound;
    }
    /* Simpler: clone-and-swap every control to strip handlers */
    ['#btnComposerImages', '#btnComposerVideo', '#btnComposerClear',
     '#composerFiles', '#composerVideoFile', '#btnPublish'].forEach(function (sel) {
      var n = qs(sel, scope);
      if (!n) return;
      var clone = n.cloneNode(true);
      clone.removeAttribute('data-composer-bound');
      n.parentNode && n.parentNode.replaceChild(clone, n);
    });
  }

  /* ----------------------------------------------------------
   * STATE INTROSPECTION (additive)
   * ---------------------------------------------------------- */
  function getState() {
    return {
      editingPostId: editingPostId,
      images: composerImages.slice(),
      video: composerVideo,
      publishing: publishing
    };
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original globals — preserved so feature 051, feature 040,
   * profile page, deep links, etc. keep working unchanged. */
  window.openComposer = open;
  window.renderComposerPreview = renderPreview;

  window.SaikoComposer = {
    open: open,
    renderPreview: renderPreview,
    bind: bind,
    unbind: unbind,
    publish: publish,
    reset: reset,
    clearMedia: clearMedia,
    getState: getState
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * The composer overlay is static in index.html, so we can
   * bind at DOM ready without waiting for open().
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 053 — composer ready');
  } catch (e) {}

})();