/* ============================================================
 * FEATURE:        Comment Report
 * FEATURE NUMBER: 073
 * FILE:           js/feed/073-comment-report.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for reporting a comment. Extracts the
 *   "report" branch that lives inline inside feature 067's
 *   openSplitCommentMenu() so any future comment surface
 *   (post-split, legacy overlay, reel comments, story replies)
 *   can reuse the same flow.
 *
 *   The generic report pipeline (openReport + #ovReport overlay
 *   + REPORT_REASONS + #btnSendReport) is owned by its own
 *   feature file (the block/report module). This module is the
 *   COMMENT-SPECIFIC entry point that:
 *
 *     1. Validates the post/comment ids
 *     2. (Optionally) resolves the comment author so the report
 *        carries targetUid
 *     3. Delegates to window.openReport('comment', cid, pid)
 *        — the same call the original made from openSplitCommentMenu
 *
 *   In the original single-file build the call was one line:
 *
 *       if (k === 'report') openReport('comment', cid, splitPostId);
 *
 *   Feature 073 exposes that line as a reusable, guarded
 *   function so future callers do not have to duplicate the
 *   argument order or resolve the author themselves.
 *
 *   Public function:
 *     window.reportComment(postId, commentId) → Promise<boolean>
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §17 POST SPLIT
 *     openSplitCommentMenu() → case 'report'
 *   Section §31 BLOCK / REPORT
 *     openReport(type, targetId, parentId) — the delegate
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - openReport             report module (feature 090 area)
 *                            (safely-called)
 *   - toast                  js/nav/042-toast.js
 *                            (safely-called)
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none directly — the report overlay is built by openReport.
 *
 * FIREBASE PATHS:
 *   comments/{pid}/{cid}     (read — to resolve targetUid)
 *   reports                  (write — happens inside the
 *                             report module after the user
 *                             picks a reason and submits)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.reportComment
 *   window.SaikoCommentReport = {
 *     report,
 *     openReportOverlay,
 *     resolveAuthor,
 *     buildTarget,
 *     REPORT_TARGET_TYPE
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * CONSTANT
   * ---------------------------------------------------------- */
  var REPORT_TARGET_TYPE = 'comment';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[comment-report] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * resolveAuthor(postId, commentId) → Promise<string|null>
   * Reads the comment node and returns the author's uid, or
   * null when the comment is missing / unreadable. Exposed so
   * callers can pre-check ownership (e.g. "you cannot report
   * your own comment") before opening the report overlay.
   * ---------------------------------------------------------- */
  async function resolveAuthor(postId, commentId) {
    if (!postId || !commentId) return null;
    var fbDb = getDB();
    if (!fbDb) return null;
    try {
      var snap = await fbDb.ref('comments/' + postId + '/' + commentId).get();
      var c = snap.val();
      return c ? (c.uid || null) : null;
    } catch (e) {
      return null;
    }
  }

  /* ----------------------------------------------------------
   * buildTarget(postId, commentId, authorUid)
   * Pure — the shape the report pipeline expects. Mirrors the
   * { type, targetId, parentId } tuple that openReport takes,
   * plus the resolved author for downstream analytics.
   * ---------------------------------------------------------- */
  function buildTarget(postId, commentId, authorUid) {
    return {
      type: REPORT_TARGET_TYPE,
      targetId: commentId,
      parentId: postId || null,
      targetUid: authorUid || null
    };
  }

  /* ----------------------------------------------------------
   * openReportOverlay(postId, commentId)
   * Delegates to window.openReport('comment', cid, pid) — the
   * exact call the original source made from
   * openSplitCommentMenu's `case 'report'`.
   *
   * Safe when the report module is not yet loaded: returns
   * false and shows a generic error toast.
   * ---------------------------------------------------------- */
  function openReportOverlay(postId, commentId) {
    if (!postId || !commentId) return false;

    var fn = null;
    try { fn = window.openReport; } catch (e) {}
    if (typeof fn !== 'function') {
      safeToast(T('error'), 'err');
      return false;
    }

    try {
      fn(REPORT_TARGET_TYPE, commentId, postId);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * report(postId, commentId, opts) → Promise<boolean>
   * Main entry point.
   *
   * opts.skipAuthorCheck (default false)
   *   When false (default), the author is resolved and the
   *   self-report guard is applied: if the current user is the
   *   comment's author, the report is refused with an error
   *   toast (the original UI never showed the report option
   *   on the user's own comments, so this is a defensive guard).
   *
   *   When true, the resolution is skipped — useful for admin
   *   tooling that wants to report without a self-check.
   * ---------------------------------------------------------- */
  async function report(postId, commentId, opts) {
    if (!postId || !commentId) return false;

    opts = opts || {};
    var skipAuthorCheck = !!opts.skipAuthorCheck;

    /* 1) Optional author resolution + self-report guard --- */
    if (!skipAuthorCheck) {
      var authorUid = await resolveAuthor(postId, commentId);

      /* Comment missing? Nothing to report. */
      if (!authorUid) {
        safeToast(T('error'), 'err');
        return false;
      }

      var me = getMyUid();
      if (me && authorUid === me) {
        /* Silent refusal on self-report (original UI simply
         * did not offer the option). We do not toast here so
         * programmatic callers can skip quietly. */
        return false;
      }
    }

    /* 2) Delegate to the report pipeline ------------------ */
    var ok = openReportOverlay(postId, commentId);

    /* 3) Notify subscribers (additive) -------------------- */
    if (ok) {
      try {
        window.dispatchEvent(new CustomEvent('saiko:comment-report-opened', {
          detail: { postId: postId, commentId: commentId }
        }));
      } catch (e) {}
    }

    return ok;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.reportComment = report;

  window.SaikoCommentReport = {
    report: report,
    openReportOverlay: openReportOverlay,
    resolveAuthor: resolveAuthor,
    buildTarget: buildTarget,
    REPORT_TARGET_TYPE: REPORT_TARGET_TYPE
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 073 — comment-report ready');
  } catch (e) {}

})();