/* ============================================================
 * FEATURE:        Self Nav Guard
 * FEATURE NUMBER: 087
 * FILE:           js/feed/087-self-nav-guard.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Reusable guard that encodes the "if the target uid is the
 *   current user, switch to the profile tab instead of opening
 *   the profile overlay" rule that appeared in every profile-
 *   opening entry point in the original source.
 *
 *   Original occurrences of the rule (all preserved as
 *   behaviour, now delegating here or duplicated identically):
 *
 *     §14 USER CACHE / SEARCH → search result click
 *       openUserProfile(uid)  → inside:
 *         if(uid === myUid){ navigate('profile'); return; }
 *
 *     §15 FEED → wirePostInteractions → [data-postowner] click
 *       uid !== myUid ? openUserProfile(uid) : navigate('profile')
 *
 *     §22 CHAT / comment author clicks → similar self-guard
 *
 *     §26 TRENDING topUsers click → openUserProfile(uid)
 *
 *     §30 SETTINGS account → same rule when opening own profile
 *
 *   This module provides:
 *
 *     window.isSelfUid(uid)                 → boolean
 *     window.openProfileSmart(uid, opts)    → Promise<boolean>
 *     window.SaikoSelfNavGuard = {
 *       isSelf, shouldOpenOverlay,
 *       openSmart,
 *       wrap,           // wraps an existing openUserProfile
 *       DATA_ATTRS
 *     }
 *
 *   `openSmart(uid)` is the canonical helper:
 *     • uid missing          → returns false
 *     • uid === myUid        → navigate('profile') + true
 *     • otherwise            → openUserProfile(uid) + true
 *
 *   It never throws, and never double-navigates. All side
 *   effects route through the app's public navigation API.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH  → openUserProfile()
 *   Section §15 FEED                 → wirePostInteractions()
 *   Section §22 CHAT                 → various click handlers
 *   Section §26 TRENDING             → topUsers click
 *
 * DEPENDENCIES (loaded earlier):
 *   - myUid               js/auth/004-auth-state.js
 *   - navigate            js/nav/036-bottom-nav.js
 *   - openUserProfile     profile module (safely-called)
 *
 * DOM ELEMENTS USED:
 *   none — pure logic helper
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.isSelfUid
 *   window.openProfileSmart
 *   window.SaikoSelfNavGuard = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[self-nav-guard] safeCall:', name, e); }
    return undefined;
  }

  function getMyUid() {
    try {
      return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null;
    } catch (e) { return null; }
  }

  /* ============================================================
   * PREDICATES
   * ============================================================ */

  /* isSelf(uid) → true when uid matches the current user.
   * Returns false when either side is missing, so callers can
   * safely rely on it as a guard. */
  function isSelf(uid) {
    if (!uid) return false;
    var me = getMyUid();
    return !!(me && uid === me);
  }

  /* shouldOpenOverlay(uid) → true when the overlay path is the
   * correct destination (i.e. NOT self, and uid is present). */
  function shouldOpenOverlay(uid) {
    if (!uid) return false;
    return !isSelf(uid);
  }

  /* ============================================================
   * OPEN SMART — the canonical dispatch helper
   * ============================================================
   * Preserved 1:1 from the original rule:
   *
   *     if(uid === myUid){ navigate('profile'); return; }
   *     openUserProfile(uid);
   *
   * Returns Promise<boolean>:
   *   • false — uid missing
   *   • true  — a navigation was attempted (either the profile
   *              tab or the user overlay)
   *
   * opts:
   *   closeSplit (boolean)      — call closePostSplit() before
   *                                routing (comment-author flow)
   *   onBefore (fn(uid))        — fires after closeSplit, before
   *                                the actual route dispatch
   *   onSelf (fn())             — fires when the self branch is
   *                                taken
   *   onOther (fn(uid))         — fires when the overlay branch
   *                                is taken
   * ============================================================ */
  async function openSmart(uid, opts) {
    if (!uid) return false;
    opts = opts || {};

    /* 1) Optional overlay close --------------------------- */
    if (opts.closeSplit) {
      safeCall('closePostSplit');
    }

    /* 2) Pre-route hook ----------------------------------- */
    if (typeof opts.onBefore === 'function') {
      try { opts.onBefore(uid); } catch (e) {}
    }

    /* 3) Self → profile tab ------------------------------- */
    if (isSelf(uid)) {
      if (typeof opts.onSelf === 'function') {
        try { opts.onSelf(); } catch (e) {}
      }
      safeCall('navigate', ['profile']);
      return true;
    }

    /* 4) Other → profile overlay -------------------------- */
    if (typeof opts.onOther === 'function') {
      try { opts.onOther(uid); } catch (e) {}
    }
    var opened = safeCall('openUserProfile', [uid]);
    return opened !== false;
  }

  /* ============================================================
   * WRAP — decorate an existing openUserProfile
   * ============================================================
   * Replaces window.openUserProfile with a self-guarded version
   * so every call site automatically obeys the rule without
   * needing to be updated.
   *
   * This is opt-in. Feature 086 and any other consumer can
   * continue to route through openSmart() directly without
   * invoking wrap().
   *
   * Returns true when the wrapper was installed. Idempotent.
   * ============================================================ */
  var wrapped = false;
  var originalFn = null;

  function wrap() {
    if (wrapped) return true;

    var current = window.openUserProfile;
    if (typeof current !== 'function') return false;

    originalFn = current;

    var guarded = function (uid, opts) {
      if (!uid) return;
      if (isSelf(uid)) {
        safeCall('navigate', ['profile']);
        return;
      }
      return originalFn.call(window, uid, opts);
    };

    /* Copy through convenience properties that might be
     * attached to the original function. */
    try {
      Object.keys(current).forEach(function (k) {
        guarded[k] = current[k];
      });
    } catch (e) {}

    window.openUserProfile = guarded;
    wrapped = true;
    return true;
  }

  function unwrap() {
    if (!wrapped || typeof originalFn !== 'function') return false;
    window.openUserProfile = originalFn;
    wrapped = false;
    originalFn = null;
    return true;
  }

  function isWrapped() { return wrapped; }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.isSelfUid = isSelf;
  window.openProfileSmart = openSmart;

  window.SaikoSelfNavGuard = {
    isSelf: isSelf,
    shouldOpenOverlay: shouldOpenOverlay,
    openSmart: openSmart,
    wrap: wrap,
    unwrap: unwrap,
    isWrapped: isWrapped
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 087 — self-nav-guard ready');
  } catch (e) {}

})();