/* ============================================================
 * FEATURE:        Image Compression
 * FEATURE NUMBER: 056
 * FILE:           js/feed/056-image-compress.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical canvas-based image compressor. Takes an image
 *   File/Blob and returns a resized + re-encoded JPEG File that
 *   is typically 60–90% smaller than the original, before the
 *   file is handed to Cloudinary for upload.
 *
 *   Public function (used by ~15 sibling modules):
 *     window.compressImage(file, maxSide, quality)
 *       → Promise<File>
 *
 *     maxSide  — longest edge in pixels (default 1280)
 *     quality  — JPEG quality 0..1 (default 0.82)
 *
 *   Behaviour preserved 1:1 from original §8 CLOUDINARY
 *   compressImage():
 *
 *     1. If the file is not an image, or is a GIF (already
 *        compressed / animated), return the file unchanged.
 *     2. Load the file into an off-screen Image via
 *        URL.createObjectURL.
 *     3. If either edge exceeds maxSide, scale proportionally
 *        so the longest edge is exactly maxSide.
 *     4. Draw onto an off-screen canvas, encode to JPEG with
 *        the requested quality via canvas.toBlob.
 *     5. Wrap the resulting Blob in a new File so downstream
 *        code keeps seeing a File instance.
 *     6. Object URL is always revoked.
 *     7. Any failure (image load error, canvas OOM, toBlob
 *        returning null) resolves with the ORIGINAL file — the
 *        caller is never rejected by compression; only the
 *        actual uploader can fail the pipeline.
 *
 *   This "never reject" contract is what lets feature 054
 *   (uploadPostImage), feature 142 (chat image), feature 187
 *   (story image), feature 040 (profile photo), etc. treat
 *   compression as best-effort and still succeed with a
 *   slightly larger upload if compression hiccups.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §8 CLOUDINARY → function compressImage() { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure DOM (Image + Canvas + toBlob)
 *
 * DOM ELEMENTS USED:
 *   none — creates an off-screen <img> and <canvas>
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.compressImage                 (original name preserved)
 *   window.SaikoImageCompress = {
 *     compress,
 *     DEFAULT_MAX_SIDE,
 *     DEFAULT_QUALITY,
 *     isCompressible
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Defaults — match the original source exactly.
   * ---------------------------------------------------------- */
  var DEFAULT_MAX_SIDE = 1280;
  var DEFAULT_QUALITY  = 0.82;

  /* ----------------------------------------------------------
   * isCompressible(file)
   *   Returns true when the file is an image whose format we
   *   can usefully re-encode. GIFs are skipped because they
   *   may be animated and re-encoding would destroy frames.
   * ---------------------------------------------------------- */
  function isCompressible(file) {
    if (!file) return false;
    if (!file.type) return false;
    if (file.type.indexOf('image/') !== 0) return false;
    if (file.type === 'image/gif') return false;
    return true;
  }

  /* ----------------------------------------------------------
   * COMPRESS — main entry point.
   * Preserved 1:1 from original compressImage().
   * ---------------------------------------------------------- */
  function compress(file, maxSide, quality) {
    maxSide = maxSide || DEFAULT_MAX_SIDE;
    quality = quality || DEFAULT_QUALITY;

    return new Promise(function (resolve) {
      /* 1) Skip non-images and GIFs — return the file as-is. */
      if (!isCompressible(file)) return resolve(file);

      var img = new Image();
      var objUrl = null;
      try {
        objUrl = URL.createObjectURL(file);
      } catch (e) {
        /* URL.createObjectURL failed (quota / unsupported) —
         * skip compression gracefully. */
        return resolve(file);
      }

      /* 2) Load image --------------------------------------- */
      img.onload = function () {
        try {
          /* 2a) Compute target dimensions ----------------- */
          var w = img.naturalWidth || img.width;
          var h = img.naturalHeight || img.height;

          if (w > maxSide || h > maxSide) {
            var r = Math.min(maxSide / w, maxSide / h);
            w = Math.round(w * r);
            h = Math.round(h * r);
          }

          /* 2b) Draw onto canvas --------------------------- */
          var canvas = document.createElement('canvas');
          canvas.width = w;
          canvas.height = h;
          var ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, w, h);

          /* 2c) Encode to JPEG ---------------------------- */
          canvas.toBlob(function (blob) {
            try { URL.revokeObjectURL(objUrl); } catch (e) {}
            if (!blob) return resolve(file);

            /* 2d) Wrap in a File for downstream code ------ */
            try {
              resolve(new File([blob], 'image.jpg', { type: 'image/jpeg' }));
            } catch (e) {
              /* File constructor unsupported (very old
               * browsers) — fall back to the raw Blob. */
              resolve(blob);
            }
          }, 'image/jpeg', quality);

        } catch (e) {
          /* Any canvas / draw / encode error → original file */
          try { URL.revokeObjectURL(objUrl); } catch (e2) {}
          resolve(file);
        }
      };

      /* 3) Load failure → original file -------------------- */
      img.onerror = function () {
        try { URL.revokeObjectURL(objUrl); } catch (e) {}
        resolve(file);
      };

      img.src = objUrl;
    });
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so every caller (feature 053
   * composer, 040 settings, 142 chat image, 187 story image,
   * 054 uploadPostImage, 229 reel, …) continues to work with
   * no changes. */
  window.compressImage = compress;

  window.SaikoImageCompress = {
    compress: compress,
    DEFAULT_MAX_SIDE: DEFAULT_MAX_SIDE,
    DEFAULT_QUALITY: DEFAULT_QUALITY,
    isCompressible: isCompressible
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 056 — image-compress ready');
  } catch (e) {}

})();