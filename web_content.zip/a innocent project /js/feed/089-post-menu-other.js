/* ============================================================
 * FEATURE:        Post Menu (Non-Owner Items)
 * FEATURE NUMBER: 089
 * FILE:           js/feed/089-post-menu-other.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper that owns the NON-OWNER branch of the post
 *   options menu. Extracts the four non-owner action items
 *   from feature 088's inline logic so they can be:
 *
 *     • Consumed as a pure items array (buildItems)
 *     • Dispatched programmatically (hide/mute/report/block)
 *     • Wired to any future menu surface without duplicating
 *       the state-dependent labels
 *
 *   Non-owner items (preserved 1:1 from the original):
 *
 *     hide          → t('hide_post')
 *     muteauthor    → t('mute_author')   | t('unmute_author')
 *     report        → t('report')        (danger)
 *     block         → t('block')         (danger)
 *
 *   The label for muteauthor is state-dependent — it reads
 *   from the live muted-authors map (feature 084) so the same
 *   action toggles the correct message.
 *
 *   Feature 088 continues to inline the same non-owner branch
 *   for its specific DOM surface; this module is purely
 *   additive and can be adopted later by refactoring 088 to
 *   call SaikoPostMenuOther.buildItems().
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §15 FEED → openPostMenu(pid) — the `else` branch
 *     (non-owner items)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache      js/feed/051-feed-render.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none — pure items/dispatch helper
 *
 * FIREBASE PATHS:
 *   none directly — every action delegates to its own feature.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoPostMenuOther = {
 *     buildItems,          // pure items array for a non-owner
 *     dispatch,            // run one action by key
 *     isOwner,             // predicate
 *     isMutedAuthor,       // state reader
 *     ACTION_KEYS,
 *     ACTION_ICONS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var ACTION_ICONS = {
    hide:       'eyeOff',
    muteauthor: 'micOff',
    report:     'flag',
    block:      'block'
  };

  var ACTION_KEYS = Object.keys(ACTION_ICONS);

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[post-menu-other] safeCall:', name, e); }
    return undefined;
  }
  function getMyUid() {
    try {
      return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null;
    } catch (e) { return null; }
  }
  function findPost(pid) {
    if (!pid) return null;
    try {
      if (Array.isArray(window.postsCache)) {
        for (var i = 0; i < window.postsCache.length; i++) {
          var p = window.postsCache[i];
          if (p && p.id === pid) return p;
        }
      }
    } catch (e) {}
    return null;
  }

  /* ============================================================
   * PREDICATES
   * ============================================================ */

  /* isOwner(post) → boolean. Pure — takes the post object. */
  function isOwner(post) {
    if (!post || !post.uid) return false;
    var me = getMyUid();
    return !!(me && post.uid === me);
  }

  /* isMutedAuthor(uid) → boolean.
   * Prefers feature 084's predicate; falls back to the live
   * map so this module works standalone. */
  function isMutedAuthor(uid) {
    if (!uid) return false;
    try {
      if (typeof window.iMutedAuthor === 'function') {
        return !!window.iMutedAuthor(uid);
      }
    } catch (e) {}
    return !!(window.mutedAuthors && window.mutedAuthors[uid]);
  }

  /* ============================================================
   * BUILD ITEMS — pure
   * ============================================================
   * Preserved 1:1 from the original non-owner branch:
   *
   *   items.push({ k:'hide',        i:'eyeOff', label:t('hide_post') });
   *   items.push({ k:'muteauthor',  i:'micOff',
   *                label: iMutedAuthor(post.uid)
   *                       ? t('unmute_author') : t('mute_author') });
   *   items.push({ k:'report',      i:'flag',   label:t('report'), danger:true });
   *   items.push({ k:'block',       i:'block',  label:t('block'),  danger:true });
   *
   * Accepts either a post object or a postId string for
   * convenience.
   * ============================================================ */
  function buildItems(postOrId) {
    var post = (typeof postOrId === 'string')
      ? findPost(postOrId)
      : postOrId;
    if (!post) return [];

    var items = [];

    items.push({
      k: 'hide',
      i: ACTION_ICONS.hide,
      label: T('hide_post')
    });

    items.push({
      k: 'muteauthor',
      i: ACTION_ICONS.muteauthor,
      label: isMutedAuthor(post.uid)
        ? T('unmute_author')
        : T('mute_author')
    });

    items.push({
      k: 'report',
      i: ACTION_ICONS.report,
      label: T('report'),
      danger: true
    });

    items.push({
      k: 'block',
      i: ACTION_ICONS.block,
      label: T('block'),
      danger: true
    });

    return items;
  }

  /* ============================================================
   * DISPATCH — run one action by key
   * ============================================================
   * Preserved 1:1 from feature 088's non-owner branches:
   *
   *   if(k === 'hide')        hidePost(pid)
   *   if(k === 'muteauthor')  muteAuthor(authorUid)
   *   if(k === 'report')      openReport('post', pid, null)
   *   if(k === 'block')       blockUser(authorUid)
   *
   * All handlers are safely-called so a missing module never
   * crashes the menu.
   *
   * Returns Promise<boolean> — true when the key matched.
   * ============================================================ */
  async function dispatch(k, postOrId) {
    if (!k) return false;

    var post = (typeof postOrId === 'string')
      ? findPost(postOrId)
      : postOrId;
    if (!post) return false;

    var pid = post.id;
    var authorUid = post.uid;

    switch (k) {
      case 'hide':
        safeCall('hidePost', [pid]);
        return true;

      case 'muteauthor':
        safeCall('muteAuthor', [authorUid]);
        return true;

      case 'report':
        /* Original call shape: openReport('post', pid, null).
         * The third arg is the parent comment id (not used for
         * post reports) — passed as null exactly as in 088. */
        safeCall('openReport', ['post', pid, null]);
        return true;

      case 'block':
        safeCall('blockUser', [authorUid]);
        return true;

      default:
        return false;
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoPostMenuOther = {
    buildItems: buildItems,
    dispatch: dispatch,
    isOwner: isOwner,
    isMutedAuthor: isMutedAuthor,
    ACTION_KEYS: ACTION_KEYS.slice(),
    ACTION_ICONS: Object.assign({}, ACTION_ICONS)
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 089 — post-menu-other ready');
  } catch (e) {}

})();