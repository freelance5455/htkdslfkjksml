/* ============================================================
 * FEATURE:        Post Image Upload
 * FEATURE NUMBER: 054
 * FILE:           js/feed/054-image-upload.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused, reusable image-upload pipeline used by every part
 *   of the app that needs to take a File and end up with a
 *   hosted HTTPS URL on Cloudinary:
 *
 *     • Post composer        (feature 053)
 *     • Chat image send      (feature 142)
 *     • Story image          (feature 187)
 *     • Group avatar         (feature 116)
 *     • Profile photo        (feature 040 settings)
 *     • Cover photo          (feature 070 area)
 *     • Story reply thumb    (feature 195 area)
 *
 *   The pipeline is:
 *
 *     File
 *       → validateImage()       (type + size)
 *       → compressImage()       (canvas, quality 0.82, max side 1400)
 *       → cloudinaryUpload()    (XHR w/ progress)
 *       → hosted URL (secure_url)
 *
 *   Both validateImage and the orchestrated upload are exposed
 *   as global functions so every existing call site keeps
 *   working with no changes:
 *
 *     window.validateImage(file)                 → string | null
 *     window.uploadPostImage(file, onProgress)   → Promise<url>
 *     window.uploadPostImages(files, onProgress) → Promise<url[]>
 *
 *   NOTE: This module does NOT own the low-level canvas
 *   compression (feature 056 does) or the raw XHR uploader
 *   (core/cloudinary). It only owns the ORCHESTRATION and the
 *   validation rules — matching the original source layout
 *   where validateImage lived in §8 CLOUDINARY and the
 *   composer-owned pipeline inlined the rest.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §8 CLOUDINARY → validateImage(file)
 *   Section §16 COMPOSER  → inline image upload loop
 *
 * DEPENDENCIES (loaded earlier):
 *   - MEDIA_CONFIG               (core/config, or fallback here)
 *   - compressImage(file, …)     (feature 056, or global)
 *   - cloudinaryUpload(blob, …)  (core/cloudinary)
 *   - t(key)                     (046 i18n)
 *
 * DOM ELEMENTS USED:
 *   none — pure data pipeline
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.validateImage
 *   window.uploadPostImage
 *   window.uploadPostImages
 *   window.SaikoImageUpload = {
 *     validate, upload, uploadMany,
 *     MAX_BYTES, DEFAULT_MAX_SIDE, DEFAULT_QUALITY
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — fall back to the exact values from the
   * original §1 CONFIG if MEDIA_CONFIG is not yet on window.
   * ---------------------------------------------------------- */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_POST_IMAGE_BYTES: 25 * 1024 * 1024,
    MAX_UPLOAD_BYTES: 100 * 1024 * 1024
  };

  var MAX_BYTES       = MEDIA_CONFIG.MAX_POST_IMAGE_BYTES || (25 * 1024 * 1024);
  var DEFAULT_MAX_SIDE = 1400;
  var DEFAULT_QUALITY  = 0.82;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  /* ----------------------------------------------------------
   * VALIDATE
   * Preserved 1:1 from original validateImage(file):
   *   - must exist
   *   - must be an image/* MIME
   *   - must be ≤ MAX_POST_IMAGE_BYTES
   * Returns null on success, or an i18n-ready error string on
   * failure.
   * ---------------------------------------------------------- */
  function validate(file) {
    if (!file) return T('invalid_file');
    if (!file.type || file.type.indexOf('image/') !== 0) return T('invalid_file');
    if (file.size > MAX_BYTES) return T('file_too_large');
    return null;
  }

  /* ----------------------------------------------------------
   * COMPRESS — resolve the compressor from feature 056 or a
   * local fallback. The local fallback is a minimal canvas
   * resizer identical to the original source's compressImage.
   * ---------------------------------------------------------- */
  function compressor() {
    try {
      if (typeof window.compressImage === 'function') return window.compressImage;
    } catch (e) {}
    return fallbackCompressImage;
  }

  function fallbackCompressImage(file, maxSide, quality) {
    maxSide = maxSide || DEFAULT_MAX_SIDE;
    quality = quality || DEFAULT_QUALITY;
    return new Promise(function (resolve) {
      if (!file || !file.type || file.type.indexOf('image/') !== 0 || file.type === 'image/gif') {
        return resolve(file);
      }
      var img = new Image();
      var objUrl = URL.createObjectURL(file);
      img.onload = function () {
        var w = img.naturalWidth;
        var h = img.naturalHeight;
        if (w > maxSide || h > maxSide) {
          var r = Math.min(maxSide / w, maxSide / h);
          w = Math.round(w * r);
          h = Math.round(h * r);
        }
        var c = document.createElement('canvas');
        c.width = w;
        c.height = h;
        c.getContext('2d').drawImage(img, 0, 0, w, h);
        c.toBlob(function (b) {
          try { URL.revokeObjectURL(objUrl); } catch (e) {}
          if (!b) return resolve(file);
          resolve(new File([b], 'image.jpg', { type: 'image/jpeg' }));
        }, 'image/jpeg', quality);
      };
      img.onerror = function () {
        try { URL.revokeObjectURL(objUrl); } catch (e) {}
        resolve(file);
      };
      img.src = objUrl;
    });
  }

  /* ----------------------------------------------------------
   * UPLOAD (single)
   *   upload(file, opts, onProgress) → Promise<url>
   *
   *   opts.maxSide   — compression max side (default 1400)
   *   opts.quality   — jpeg quality (default 0.82)
   *   opts.filename  — Cloudinary filename (default 'post.jpg')
   *
   * Throws on validation failure OR on uploader failure.
   * ---------------------------------------------------------- */
  async function upload(file, opts, onProgress) {
    opts = opts || {};

    /* 1) Validate ----------------------------------------- */
    var err = validate(file);
    if (err) throw new Error(err);

    /* 2) Compress ----------------------------------------- */
    var comp = file;
    try {
      var compFn = compressor();
      comp = await compFn(file, opts.maxSide || DEFAULT_MAX_SIDE, opts.quality || DEFAULT_QUALITY);
    } catch (e) {
      /* Compression is best-effort — fall back to raw file. */
      comp = file;
    }

    /* 3) Upload ------------------------------------------ */
    var uploader = null;
    try {
      if (typeof window.cloudinaryUpload === 'function') uploader = window.cloudinaryUpload;
    } catch (e) {}
    if (!uploader) throw new Error(T('upload_failed'));

    var url = await uploader(comp, opts.filename || 'post.jpg', onProgress);
    if (!url) throw new Error(T('upload_failed'));
    return url;
  }

  /* ----------------------------------------------------------
   * UPLOAD MANY (batch)
   *   uploadMany(files, opts, onProgress) → Promise<url[]>
   *
   *   onProgress(completedCount, totalCount, itemPercent, index)
   *
   *   Preserves the original composer's progress semantics:
   *   the caller's bar goes from 0 → 100 across the batch, and
   *   within each item's upload it slides proportionally.
   * ---------------------------------------------------------- */
  async function uploadMany(files, opts, onProgress) {
    var list = Array.prototype.slice.call(files || []);
    var total = list.length;
    var out = [];
    if (!total) return out;

    for (var i = 0; i < total; i++) {
      var f = list[i];
      var url = await upload(f, opts, function (pct) {
        if (typeof onProgress === 'function') {
          try { onProgress(i, total, pct, i); } catch (e) {}
        }
      });
      out.push(url);
    }
    return out;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so existing call sites in
   * feature 053, 142, 187, etc. continue to work unchanged. */
  window.validateImage = validate;

  /* New convenient globals for direct-URL callers */
  window.uploadPostImage  = function (file, onProgress) {
    return upload(file, null, onProgress);
  };
  window.uploadPostImages = function (files, onProgress) {
    return uploadMany(files, null, onProgress);
  };

  window.SaikoImageUpload = {
    validate: validate,
    upload: upload,
    uploadMany: uploadMany,
    MAX_BYTES: MAX_BYTES,
    DEFAULT_MAX_SIDE: DEFAULT_MAX_SIDE,
    DEFAULT_QUALITY: DEFAULT_QUALITY
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 054 — image-upload ready');
  } catch (e) {}

})();