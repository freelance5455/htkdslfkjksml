/* ============================================================
 * FEATURE:        Video Call (1:1)
 * FEATURE NUMBER: 162
 * FILE:           js/calls/162-video-call.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Thin feature entry that wires the video-call button
 *   (#btnVideoCall) inside the chat header to the shared
 *   startCall(peerUid, 'video', peerName, peerPhoto) helper
 *   that lives in calls-core.
 *
 *   Responsibilities:
 *
 *     1. Resolve the current chat's peer (direct) or dispatch
 *        to the group-call entry (feature 163) when the active
 *        chat is a group.
 *     2. Guard against admin-support chats (E2E-only — video
 *        calling an admin-support chat is not supported).
 *     3. Call startCall(peerUid, 'video', name, photo).
 *
 *   Behaviour preserved 1:1 from the original §23 CALLS block's
 *   #btnVideoCall click handler:
 *
 *     $('#btnVideoCall').addEventListener('click', ()=>{
 *       const c = chatMeta[currentChatId]; if(!c) return;
 *       if(c.type === 'group'){ startGroupCall(currentChatId,'video'); return; }
 *       if(chatIsAdminSupport){ toast(t('not_supported'),'err'); return; }
 *       if(!chatPeerUid){ toast(t('error'),'err'); return; }
 *       const u = findUser(chatPeerUid) || {name:'User', photo:''};
 *       startCall(chatPeerUid, 'video', u.name, u.photo);
 *     });
 *
 *   This file does NOT touch the WebRTC layer — that is all in
 *   calls-core. The video-mode behaviour (camera on/off toggle,
 *   front/back switch, video transceiver) is handled by
 *   calls-core's newPC() / buildCallControls(type) / switchCamera()
 *   which read the call.type from the shared window.call object.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §23 CALLS → #btnVideoCall click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - db / myUid / chatMeta    features 001 / 111
 *   - findUser                 js/search/091-search-users.js
 *   - startCall                js/calls/calls-core.js
 *   - startGroupCall           js/calls/163-group-call.js (opt)
 *   - toast / t                helpers
 *
 * DOM ELEMENTS USED:
 *   #btnVideoCall  (the button inside the chat header)
 *
 * FIREBASE PATHS:
 *   none directly — the signalling lives in calls-core.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoVideoCall = { start, bind, unbind }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[video-call] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * START — the video call flow
   * ============================================================
   * Preserved 1:1 from the original #btnVideoCall handler.
   *
   * Notice the only difference from feature 161 is the second
   * argument to startCall — 'video' instead of 'audio'.
   * ============================================================ */
  function start() {
    var chatId = window.currentChatId;
    if (!chatId) return false;

    var c = (window.chatMeta && window.chatMeta[chatId]) || null;
    if (!c) return false;

    /* Group chat → delegate to feature 163 ----------------- */
    if (c.type === 'group') {
      safeCall('startGroupCall', [chatId, 'video']);
      return true;
    }

    /* Admin-support chats do not support video calls ------ */
    if (window.chatIsAdminSupport) {
      safeToast(T('not_supported'), 'err');
      return false;
    }

    var peerUid = window.chatPeerUid;
    if (!peerUid) {
      safeToast(T('error'), 'err');
      return false;
    }

    /* Resolve display info --------------------------------- */
    var u = null;
    try {
      if (typeof window.findUser === 'function') u = window.findUser(peerUid);
    } catch (e) {}
    if (!u) u = { name: 'User', photo: '' };

    /* Delegate to calls-core ------------------------------- */
    safeCall('startCall', [peerUid, 'video', u.name, u.photo]);
    return true;
  }

  /* ============================================================
   * BIND — wire #btnVideoCall
   * ============================================================ */
  function bind() {
    if (bound) return true;
    var btn = qs('#btnVideoCall');
    if (!btn) return false;
    if (btn.dataset.videoCallBound === '1') { bound = true; return true; }
    btn.dataset.videoCallBound = '1';
    btn.addEventListener('click', function (e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      start();
    });
    bound = true;
    return true;
  }

  function unbind() {
    var btn = qs('#btnVideoCall');
    if (btn) {
      var clone = btn.cloneNode(true);
      clone.removeAttribute('data-video-call-bound');
      btn.parentNode && btn.parentNode.replaceChild(clone, btn);
    }
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoVideoCall = {
    start: start,
    bind: bind,
    unbind: unbind
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 162 — video-call ready');
  } catch (e) {}

})();