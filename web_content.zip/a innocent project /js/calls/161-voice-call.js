/* ============================================================
 * FEATURE:        Voice Call (1:1 + group delegate)
 * FEATURE NUMBER: 161
 * FILE:           js/calls/161-voice-call.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Thin feature entry that wires the voice-call button
 *   (#btnVoiceCall) inside the chat header to the shared
 *   startCall(peerUid, 'audio', peerName, peerPhoto) helper
 *   that lives in calls-core.
 *
 *   Responsibilities:
 *
 *     1. Resolve the current chat's peer (direct) or dispatch
 *        to the group-call entry (feature 163) when the active
 *        chat is a group.
 *     2. Guard against admin-support chats (E2E-only — voice
 *        calling an admin-support chat is not supported).
 *     3. Call startCall(peerUid, 'audio', name, photo).
 *
 *   Behaviour preserved 1:1 from the original §23 CALLS block's
 *   #btnVoiceCall click handler:
 *
 *     $('#btnVoiceCall').addEventListener('click', ()=>{
 *       const c = chatMeta[currentChatId]; if(!c) return;
 *       if(c.type === 'group'){ startGroupCall(currentChatId,'audio'); return; }
 *       if(chatIsAdminSupport){ toast(t('not_supported'),'err'); return; }
 *       if(!chatPeerUid){ toast(t('error'),'err'); return; }
 *       const u = findUser(chatPeerUid) || {name:'User', photo:''};
 *       startCall(chatPeerUid, 'audio', u.name, u.photo);
 *     });
 *
 *   This file does NOT touch the WebRTC layer — that is all in
 *   calls-core. The audio-mode behaviour (mute toggle, speaker
 *   sink, ring timeout) is handled by calls-core's newPC() /
 *   buildCallControls(type) which read the call.type from the
 *   shared window.call object.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §23 CALLS → #btnVoiceCall click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - db / myUid / chatMeta    features 001 / 111
 *   - findUser                 js/search/091-search-users.js
 *   - startCall                js/calls/calls-core.js
 *   - startGroupCall           js/calls/163-group-call.js (opt)
 *   - toast / t                helpers
 *
 * DOM ELEMENTS USED:
 *   #btnVoiceCall  (the button inside the chat header)
 *
 * FIREBASE PATHS:
 *   none directly — the signalling lives in calls-core.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoVoiceCall = { start, bind, unbind }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[voice-call] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * START — the voice call flow
   * ============================================================
   * Preserved 1:1 from the original #btnVoiceCall handler.
   *
   * Notice the only difference from feature 162 is the second
   * argument to startCall — 'audio' instead of 'video'.
   * ============================================================ */
  function start() {
    var chatId = window.currentChatId;
    if (!chatId) return false;

    var c = (window.chatMeta && window.chatMeta[chatId]) || null;
    if (!c) return false;

    /* Group chat → delegate to feature 163 ----------------- */
    if (c.type === 'group') {
      safeCall('startGroupCall', [chatId, 'audio']);
      return true;
    }

    /* Admin-support chats do not support voice calls -------- */
    if (window.chatIsAdminSupport) {
      safeToast(T('not_supported'), 'err');
      return false;
    }

    var peerUid = window.chatPeerUid;
    if (!peerUid) {
      safeToast(T('error'), 'err');
      return false;
    }

    /* Resolve display info --------------------------------- */
    var u = null;
    try {
      if (typeof window.findUser === 'function') u = window.findUser(peerUid);
    } catch (e) {}
    if (!u) u = { name: 'User', photo: '' };

    /* Delegate to calls-core ------------------------------- */
    safeCall('startCall', [peerUid, 'audio', u.name, u.photo]);
    return true;
  }

  /* ============================================================
   * BIND — wire #btnVoiceCall
   * ============================================================ */
  function bind() {
    if (bound) return true;
    var btn = qs('#btnVoiceCall');
    if (!btn) return false;
    if (btn.dataset.voiceCallBound === '1') { bound = true; return true; }
    btn.dataset.voiceCallBound = '1';
    btn.addEventListener('click', function (e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      start();
    });
    bound = true;
    return true;
  }

  function unbind() {
    var btn = qs('#btnVoiceCall');
    if (btn) {
      var clone = btn.cloneNode(true);
      clone.removeAttribute('data-voice-call-bound');
      btn.parentNode && btn.parentNode.replaceChild(clone, btn);
    }
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoVoiceCall = {
    start: start,
    bind: bind,
    unbind: unbind
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 161 — voice-call ready');
  } catch (e) {}

})();