/* ============================================================
 * FEATURE:        Group Call
 * FEATURE NUMBER: 163
 * FILE:           js/calls/163-group-call.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the group-call room lifecycle. Reuses the shared
 *   call UI + WebRTC primitives from calls-core and layers the
 *   multi-participant coordination on top:
 *
 *     1. ROOM CREATION
 *          startGroupCall(chatId, type) — pushes a new node
 *          into `groupCallRooms` with host + metadata, publishes
 *          a `groupCall/{roomId}` flag into the chat, and fans
 *          out notifications to every member.
 *
 *     2. UI + LOCAL MEDIA
 *          Reuses showActiveCall + buildCallControls from
 *          calls-core (mute / speaker / end), then sets the
 *          local video preview (video mode) or keeps the
 *          avatar (audio mode).
 *
 *     3. PARTICIPANT LISTENER
 *          A live listener on `groupCallRooms/{roomId}/participants`
 *          updates #callStatus with the current headcount.
 *
 *     4. END
 *          endGroupCall() — removes me from the participant
 *          list, closes every peer connection in
 *          `groupCallPCs`, tears down the room if I was the
 *          last one, stops my local tracks, hides the UI, and
 *          toasts t('call_ended').
 *
 *   Behaviour preserved 1:1 from the original §23 CALLS block's
 *   startGroupCall() and endGroupCall() functions.
 *
 *   NOTE ON SCOPE — PRESERVED FROM SOURCE:
 *     The original source scaffolded the room + UI + participant
 *     tracking but did NOT wire per-peer RTCPeerConnection offers
 *     between participants. `groupCallPCs` was declared and
 *     cleaned up on end, but never populated during the room's
 *     lifetime — i.e. the audio/video mesh for group calls was
 *     left as a placeholder. Feature 163 preserves that
 *     behaviour exactly: it opens the room, shows the UI, tracks
 *     participants, and cleans up on end, but does not establish
 *     a WebRTC mesh. Any future mesh extension can be layered
 *     onto `groupCallPCs` without changing this feature's shape.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §23 CALLS → startGroupCall(chatId, type) and
 *                        endGroupCall()
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid / myProfile        js/auth/004-auth-state.js
 *   - chatMeta                 js/inbox/111-inbox-list.js
 *   - findUser                 js/search/091-search-users.js
 *   - isRecipientOnline        js/calls/calls-core.js
 *   - showActiveCall           js/calls/calls-core.js
 *   - buildCallControls        js/calls/calls-core.js
 *   - pushNotification         js/notifications/106-push-notif.js
 *   - svgIcon                  js/nav/045-icon-system.js
 *   - toast / t                helpers
 *
 * DOM ELEMENTS USED:
 *   #ovCall, #callName, #callStatus, #callTimer, #callControls,
 *   #localVideo, #remoteVideo
 *
 * FIREBASE PATHS:
 *   groupCallRooms/{roomId}                    (create / update)
 *   groupCallRooms/{roomId}/participants/{uid} (add / remove)
 *   groupCallRooms/{roomId}/status             ('active' | 'ended')
 *   chats/{chatId}/groupCall/{roomId}          (flag)
 *   notifications/{uid}                        (via 106)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.groupCallRoom        (live state or null)
 *   window.groupCallPCs         (live map of peer connections)
 *   window.startGroupCall       (original name preserved)
 *   window.endGroupCall         (original name preserved)
 *   window.detachGroupCall      (additive teardown)
 *   window.SaikoGroupCall = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE — kept on window for cross-module reads
   * ============================================================ */
  window.groupCallRoom  = null;
  window.groupCallPCs   = window.groupCallPCs || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[group-call] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function getChatMeta(chatId) {
    try { return (window.chatMeta && window.chatMeta[chatId]) || null; }
    catch (e) { return null; }
  }
  function isOnline(uid) {
    try {
      if (typeof window.isRecipientOnline === 'function') {
        return !!window.isRecipientOnline(uid);
      }
    } catch (e) {}
    return !!(window.onlineUsers && window.onlineUsers[uid]);
  }

  /* ============================================================
   * START GROUP CALL
   * ============================================================
   * Preserved 1:1 from the original startGroupCall(chatId, type).
   * ============================================================ */
  async function startGroupCall(chatId, type) {
    if (window.groupCallRoom) {
      safeToast(T('user_busy'), 'err');
      return false;
    }

    var me = getMyProfile();
    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var c = getChatMeta(chatId);
    if (!c || c.type !== 'group') {
      safeToast(T('error'), 'err');
      return false;
    }

    var members = Object.keys(c.members || {}).filter(function (u) { return u !== uid; });
    if (!members.length) {
      safeToast(T('no_results'), 'err');
      return false;
    }

    /* ---- Create the room -------------------------------- */
    var roomRef = fbDb.ref('groupCallRooms').push();
    var roomId = roomRef.key;

    try {
      await roomRef.set({
        id: roomId,
        chatId: chatId,
        hostUid: uid,
        hostName: (me && me.name) || '',
        hostPhoto: (me && me.photo) || '',
        type: type || 'audio',
        status: 'active',
        participants: (function () {
          var p = {};
          p[uid] = {
            at: timeNow(),
            name: (me && me.name) || '',
            photo: (me && me.photo) || '',
            online: true
          };
          return p;
        })(),
        createdAt: timeNow()
      });

      /* ---- Notify every member ------------------------- */
      var updates = {};
      for (var i = 0; i < members.length; i++) {
        var u = members[i];
        var isOn = isOnline(u);
        updates['chats/' + chatId + '/groupCall/' + roomId] = true;

        safeCall('pushNotification', [u, {
          type: isOn ? 'call' : 'missed_call',
          fromUid: uid,
          fromName: (me && me.name) || '',
          fromPhoto: (me && me.photo) || '',
          text: (isOn ? T('incoming_call') : T('missed_call')) + ' · ' +
                (type === 'video' ? T('video_call') : T('group_call')),
          chatId: chatId,
          groupCallId: roomId,
          createdAt: timeNow()
        }]);
      }
      if (Object.keys(updates).length) {
        try { await fbDb.ref().update(updates); } catch (e) {}
      }
    } catch (e) {
      safeToast((e && e.message) ? e.message : T('error'), 'err');
      return false;
    }

    /* ---- Publish the live room object ------------------- */
    window.groupCallRoom = {
      id: roomId,
      chatId: chatId,
      type: type,
      refs: []
    };

    /* ---- Show UI via calls-core ------------------------- */
    var anyOnline = members.some(isOnline);

    safeCall('showActiveCall', [c.name || 'Group Call', c.image || '', type]);

    /* Override status + controls the way the original did: */
    var nEl = qs('#callName');
    if (nEl) nEl.textContent = c.name || 'Group Call';

    var sEl = qs('#callStatus');
    if (sEl) sEl.textContent = anyOnline ? T('ringing') : T('group_call_waiting');

    var tEl = qs('#callTimer');
    if (tEl) tEl.textContent = '';

    /* Group-call controls differ from 1:1 — no camera toggle,
     * no switch, no minimize in the source. Preserve exactly. */
    var ctrl = qs('#callControls');
    if (ctrl) {
      ctrl.innerHTML =
        '<button class="call-btn" id="btnMute">' + svgIcon('mic') + '</button>' +
        '<button class="call-btn" id="btnSpeaker">' + svgIcon('speaker') + '</button>' +
        '<button class="call-btn end" id="btnEnd">' + svgIcon('phoneOff') + '</button>';
    }

    var btnEnd = qs('#btnEnd');
    if (btnEnd) btnEnd.onclick = function () { endGroupCall(); };

    var btnMute = qs('#btnMute');
    if (btnMute) {
      btnMute.onclick = function () {
        if (!window.localStreamRef) return;
        var tracks = window.localStreamRef.getAudioTracks();
        if (!tracks.length) return;
        var cur = tracks[0];
        cur.enabled = !cur.enabled;
        btnMute.classList.toggle('on', !cur.enabled);
        btnMute.innerHTML = svgIcon(cur.enabled ? 'mic' : 'micOff');
      };
    }

    var btnSpk = qs('#btnSpeaker');
    if (btnSpk) {
      btnSpk.onclick = function () {
        window.speakerOn = !window.speakerOn;
        btnSpk.classList.toggle('on', window.speakerOn);
        btnSpk.innerHTML = svgIcon(window.speakerOn ? 'speaker' : 'speakerOff');
        /* Reuse the shared sink-id logic. */
        safeCall('applySpeaker');
      };
    }

    /* ---- Participant listener --------------------------- */
    var partRef = fbDb.ref('groupCallRooms/' + roomId + '/participants');
    var partCb = partRef.on('value', function (snap) {
      var v = snap.val() || {};
      var count = Object.keys(v).length;
      var statusEl = qs('#callStatus');
      if (statusEl) {
        statusEl.textContent = count > 1
          ? (count + ' ' + T('participants'))
          : T('group_call_waiting');
      }
    });
    window.groupCallRoom.refs.push({ ref: partRef, event: 'value', cb: partCb });

    /* ---- Local media ------------------------------------ */
    try {
      if (!window.localStreamRef) {
        window.localStreamRef = await navigator.mediaDevices.getUserMedia(
          type === 'video'
            ? { audio: true, video: { facingMode: 'user' } }
            : { audio: true }
        );
      }
      var lv = qs('#localVideo');
      if (lv) lv.srcObject = window.localStreamRef;
      if (type === 'video' && lv) lv.style.display = 'block';
    } catch (e) {
      safeToast(T('mic_permission'), 'err');
    }

    return true;
  }

  /* ============================================================
   * END GROUP CALL
   * ============================================================
   * Preserved 1:1 from the original endGroupCall().
   * ============================================================ */
  async function endGroupCall() {
    if (!window.groupCallRoom) return false;

    var roomId = window.groupCallRoom.id;
    var uid = getMyUid();
    var fbDb = getDB();

    /* 1) Remove me from participants ---------------------- */
    try {
      if (fbDb && uid) {
        await fbDb.ref('groupCallRooms/' + roomId + '/participants/' + uid).remove();
      }
    } catch (e) {}

    /* 2) Close every PC (declared but unused in source —
     *    preserved as an empty teardown loop) -------------- */
    Object.keys(window.groupCallPCs || {}).forEach(function (k) {
      try { window.groupCallPCs[k].close(); } catch (e) {}
    });
    window.groupCallPCs = {};

    /* 3) If no participants remain, mark room ended ------ */
    try {
      if (fbDb) {
        var snap = await fbDb.ref('groupCallRooms/' + roomId + '/participants').get();
        var v = snap.val() || {};
        if (!Object.keys(v).length) {
          await fbDb.ref('groupCallRooms/' + roomId + '/status').set('ended')
            .catch(function () {});
        }
      }
    } catch (e) {}

    /* 4) Detach refs -------------------------------------- */
    (window.groupCallRoom.refs || []).forEach(function (r) {
      try { r.ref.off(r.event, r.cb); } catch (e) {}
    });

    /* 5) Stop local media --------------------------------- */
    if (window.localStreamRef) {
      try {
        window.localStreamRef.getTracks().forEach(function (tr) {
          try { tr.stop(); } catch (e) {}
        });
      } catch (e) {}
      window.localStreamRef = null;
    }

    /* 6) Clear UI bindings --------------------------------- */
    var rv = qs('#remoteVideo');
    var lv = qs('#localVideo');
    if (rv) rv.srcObject = null;
    if (lv) lv.srcObject = null;

    var ov = qs('#ovCall');
    if (ov) ov.classList.remove('open');

    window.groupCallRoom = null;
    safeToast(T('call_ended'));

    /* Notify subscribers (additive) ----------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:group-call-ended', {
        detail: { roomId: roomId }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * DETACH — additive hard teardown for logout
   * ============================================================
   * Unlike endGroupCall() this does NOT touch Firebase — it is
   * meant to be called when the session is being torn down and
   * we may not have network access anymore.
   * ============================================================ */
  function detachGroupCall() {
    if (window.groupCallRoom && window.groupCallRoom.refs) {
      window.groupCallRoom.refs.forEach(function (r) {
        try { r.ref.off(r.event, r.cb); } catch (e) {}
      });
    }
    Object.keys(window.groupCallPCs || {}).forEach(function (k) {
      try { window.groupCallPCs[k].close(); } catch (e) {}
    });
    window.groupCallPCs = {};
    if (window.localStreamRef) {
      try {
        window.localStreamRef.getTracks().forEach(function (tr) {
          try { tr.stop(); } catch (e) {}
        });
      } catch (e) {}
      window.localStreamRef = null;
    }
    window.groupCallRoom = null;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startGroupCall  = startGroupCall;
  window.endGroupCall    = endGroupCall;
  window.detachGroupCall = detachGroupCall;

  window.SaikoGroupCall = {
    start: startGroupCall,
    end: endGroupCall,
    detach: detachGroupCall,
    isActive: function () { return !!window.groupCallRoom; },
    getRoom: function () { return window.groupCallRoom; },
    getPCs: function () { return window.groupCallPCs; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 163 — group-call ready');
  } catch (e) {}

})();