/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED)
 * FILE:   js/calls/calls-core.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Shared WebRTC + signaling + call UI + call history layer.
 *   Provides everything that features 161 (voice call), 162
 *   (video call), and 163 (group call) depend on so those
 *   features can be thin entry points.
 *
 *   Responsibilities:
 *
 *     1. ICE + peer connection
 *          ICE_SERVERS, newPC(), ensureVideoTransceiver()
 *
 *     2. Signaling
 *          startCall(peerUid, type, name, photo)
 *          answerCall(callId, data)
 *          endCall(remote)
 *          savePendingCall(peerUid, type)
 *
 *     3. Incoming call handling
 *          startIncomingCalls()
 *          detachIncomingCalls()
 *          showIncomingCall(callId, data)
 *
 *     4. Call UI
 *          showActiveCall(name, photo, type)
 *          buildCallControls(type)
 *          minimizeCall(), expandCall()
 *          applySpeaker(), switchCamera()
 *          startCallTimer()
 *
 *     5. Capability helpers
 *          isBrowserCallSupported(type)
 *          isRecipientOnline(uid)
 *
 *     6. Call history
 *          writeCallHistory(peerUid, peerName, peerPhoto,
 *                           type, direction, status, duration)
 *          startCallHistory()  /  detachCallHistory()
 *          openCallHistory()   /  renderCallHistory()
 *          #btnClearHistory handler
 *
 *   Behaviour preserved 1:1 from the original §23 CALLS block.
 *
 *   The MINI-CALL and CALL OVERLAY wire the shared #ovCall and
 *   #miniCall DOM. Feature 161 (voice) and 162 (video) do not
 *   touch this DOM directly — they call into this module.
 *
 *   Group calls (feature 163) have their own logic and use
 *   their own `groupCallRooms` tree; they reuse showActiveCall
 *   and the call controls builder from this module but
 *   override the end path.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §23 CALLS — everything from `const ICE_SERVERS`
 *     through the call-history UI wiring.
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - t / esc / fmtDur / now / timeAgo helpers
 *   - svgIcon / avatarHTML   helpers
 *   - toast                  js/nav/042-toast.js
 *   - findUser / userName    js/search/091-search-users.js
 *   - pushNotification       js/notifications/106-push-notif.js
 *   - isCallBlocked (155)    js/chat/155-call-block.js
 *   - isSmsBlocked (154)     js/chat/154-sms-block.js (skip for
 *                              call — informational only)
 *
 * DOM ELEMENTS USED:
 *   #ovCall, #remoteVideo, #localVideo, #callInfo,
 *   #callAvatar, #callName, #callStatus, #callTimer,
 *   #callControls, #miniCall, #miniRemote, #miniAvatar,
 *   #miniTimer, #miniMute, #miniExpand, #miniEnd,
 *   #ovHistory, #historyBody, #btnClearHistory
 *
 * FIREBASE PATHS:
 *   calls/{callId}                          (create / update)
 *   calls/{callId}/offer, /answer           (SDP)
 *   calls/{callId}/callerCandidates         (ICE)
 *   calls/{callId}/calleeCandidates         (ICE)
 *   calls/{callId}/status                   (ringing / accepted /
 *                                            rejected / ended)
 *   userCalls/{uid}/{callId}                (incoming-call index)
 *   pendingCalls/{id}                       (offline queue)
 *   callHistory/{uid}/{id}                  (log rows)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.ICE_SERVERS
 *   window.isBrowserCallSupported
 *   window.isRecipientOnline
 *   window.savePendingCall
 *   window.startIncomingCalls
 *   window.detachIncomingCalls
 *   window.showIncomingCall
 *   window.answerCall
 *   window.startCall
 *   window.newPC
 *   window.ensureVideoTransceiver
 *   window.showActiveCall
 *   window.buildCallControls
 *   window.minimizeCall
 *   window.expandCall
 *   window.applySpeaker
 *   window.switchCamera
 *   window.startCallTimer
 *   window.endCall
 *   window.writeCallHistory
 *   window.startCallHistory
 *   window.detachCallHistory
 *   window.openCallHistory
 *   window.renderCallHistory
 *   window.call                     (live state or null)
 *   window.miniCallActive           (live bool)
 *   window.SaikoCalls = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var ICE_SERVERS = {
    iceServers: [
      { urls: [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
        'stun:stun2.l.google.com:19302'
      ]}
    ]
  };

  var CALL_TIMEOUT_MS = 45000;   /* ringing timeout */

  /* ============================================================
   * SHARED STATE — kept on window for cross-module reads
   * ============================================================ */
  window.call            = null;      /* active call session */
  window.miniCallActive  = false;
  window.speakerOn       = false;

  var incomingRef = null;
  var incomingCb  = null;

  var callDurationTimer = null;
  var callStartedAt     = 0;
  var localStreamRef    = null;
  var callTimeoutHandle = null;

  var callHistoryRef   = null;
  var callHistoryCb    = null;
  var callHistoryCache = [];

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel)  { return document.querySelector(sel); }
  function qsa(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function fmtDur(sec) {
    try { if (typeof window.fmtDur === 'function') return window.fmtDur(sec); }
    catch (e) {}
    var s = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(s / 60);
    var r = s % 60;
    if (m >= 60) {
      var h = Math.floor(m / 60);
      return h + ':' + String(m % 60).padStart(2, '0') + ':' + String(r).padStart(2, '0');
    }
    return m + ':' + String(r).padStart(2, '0');
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[calls-core] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }

  /* ============================================================
   * CAPABILITY HELPERS
   * ============================================================ */
  function isBrowserCallSupported() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return false;
    if (!window.RTCPeerConnection) return false;
    return true;
  }

  function isRecipientOnline(uid) {
    try { return !!(window.onlineUsers && window.onlineUsers[uid]); }
    catch (e) { return false; }
  }

  function ensureVideoTransceiver(pc) {
    try {
      var has = pc.getTransceivers && pc.getTransceivers().some(function (tr) {
        return tr.receiver && tr.receiver.track && tr.receiver.track.kind === 'video';
      });
      if (!has && pc.addTransceiver) pc.addTransceiver('video', { direction: 'sendrecv' });
    } catch (e) {}
  }

  /* ============================================================
   * PENDING CALL (offline recipient queue)
   * ============================================================ */
  async function savePendingCall(peerUid, type) {
    var uid = getMyUid();
    var fbDb = getDB();
    var me = getMyProfile();
    if (!uid || !fbDb || !peerUid) return;

    try {
      var ref = fbDb.ref('pendingCalls').push();
      await ref.set({
        id: ref.key,
        from: uid,
        fromName: (me && me.name) || '',
        fromPhoto: (me && me.photo) || '',
        to: peerUid,
        type: type || 'audio',
        status: 'pending',
        createdAt: timeNow()
      });
      try {
        await fbDb.ref('userCalls/' + peerUid + '/' + ref.key).set({
          at: timeNow(), from: uid, type: type, status: 'pending'
        });
      } catch (e) {}

      safeCall('pushNotification', [peerUid, {
        type: 'missed_call',
        fromUid: uid,
        fromName: (me && me.name) || '',
        fromPhoto: (me && me.photo) || '',
        text: T('missed_call') + ' (' +
              (type === 'video' ? T('video_call') : T('call')) + ')',
        createdAt: timeNow()
      }]);
    } catch (e) {}
  }

  /* ============================================================
   * INCOMING CALL
   * ============================================================ */
  function detachIncomingCalls() {
    if (incomingRef && incomingCb) {
      try { incomingRef.off('child_added', incomingCb); } catch (e) {}
    }
    incomingRef = null;
    incomingCb  = null;
  }

  function startIncomingCalls() {
    if (incomingRef && incomingCb) return true;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    incomingRef = fbDb.ref('userCalls/' + uid);
    incomingCb = incomingRef.on('child_added', async function (snap) {
      var callId = snap.key;
      if (window.call && window.call.id === callId) return;

      try {
        var s = await fbDb.ref('calls/' + callId).get();
        var data = s.val();
        if (!data || data.status !== 'ringing' || data.from === uid) return;

                     /* Call block check (feature 155) ---------------- */
              if (typeof window.isCallBlocked === 'function' && window.isCallBlocked(data.from)) {
                fbDb.ref('calls/' + callId + '/status').set('blocked').catch(function () {});
                fbDb.ref('userCalls/' + uid + '/' + callId).remove().catch(function () {});
                return;
              }

        /* Privacy prefs ---------------------------------- */
        var cp = null;
        try { cp = window.myProfile && window.myProfile.privacy && window.myProfile.privacy.callPerm; }
        catch (e) {}
                      if (cp === 'nobody') {
                fbDb.ref('calls/' + callId + '/status').set('blocked').catch(function () {});
                fbDb.ref('userCalls/' + uid + '/' + callId).remove().catch(function () {});
                return;
              }

        showIncomingCall(callId, data);
      } catch (e) {}
    });

    return true;
  }

  function showIncomingCall(callId, data) {
    if (window.call) return;

    var ov = qs('#ovCall');
    if (!ov) return;
    ov.classList.add('open');

    /* Toggle visual mode -------------------------------- */
    var rv = qs('#remoteVideo');
    var lv = qs('#localVideo');
    var ci = qs('#callInfo');
    if (rv) rv.style.display = 'none';
    if (lv) lv.style.display = 'none';
    if (ci) ci.style.display = 'flex';

    var av = qs('#callAvatar');
    if (av) {
      var html = avatarHTML(data.fromPhoto, data.fromName, 'av-88');
      av.outerHTML = html.replace('class="avatar', 'id="callAvatar" class="avatar');
    }

    var nEl = qs('#callName');
    if (nEl) nEl.textContent = data.fromName || 'User';

    var sEl = qs('#callStatus');
    if (sEl) {
      sEl.textContent = T('incoming_call') + ' · ' +
        (data.type === 'video' ? T('video_call') : T('call'));
    }

    var tEl = qs('#callTimer');
    if (tEl) tEl.textContent = '';

    var ctrl = qs('#callControls');
    if (ctrl) {
      ctrl.innerHTML =
        '<button class="call-btn end" id="btnReject">' + svgIcon('phoneOff') + '</button>' +
        '<button class="call-btn acc" id="btnAccept">' +
          svgIcon(data.type === 'video' ? 'video' : 'phone') +
        '</button>';
    }

    var uid = getMyUid();
    var fbDb = getDB();

    var reject = qs('#btnReject');
    if (reject) {
      reject.onclick = async function () {
        try {
          if (fbDb) {
            await fbDb.ref('calls/' + callId + '/status').set('rejected');
            await fbDb.ref('userCalls/' + uid + '/' + callId).remove();
          }
        } catch (e) {}
        ov.classList.remove('open');
        writeCallHistory(data.from, data.fromName, data.fromPhoto, data.type,
                         'incoming', 'missed', 0);
      };
    }

    var accept = qs('#btnAccept');
    if (accept) {
      accept.onclick = function () {
        ov.classList.remove('open');
        answerCall(callId, data);
      };
    }

    try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch (e) {}
  }

  async function answerCall(callId, data) {
    if (window.call) return;

    window.call = {
      id: callId,
      peer: data.from,
      type: data.type,
      role: 'callee',
      pc: null,
      refs: [],
      muted: false,
      camOff: false
    };

    /* Local media ------------------------------------------ */
    try {
      window.call.localStream = await navigator.mediaDevices.getUserMedia(
        data.type === 'video'
          ? { audio: true, video: { facingMode: 'user' } }
          : { audio: true }
      );
    } catch (e) {
      safeToast(T('permission_denied'), 'err');
      try { getDB().ref('calls/' + callId + '/status').set('ended'); } catch (e2) {}
      window.call = null;
      return;
    }
    localStreamRef = window.call.localStream;

    showActiveCall(data.fromName || 'User', data.fromPhoto || '', data.type);
    var lv = qs('#localVideo');
    if (lv) lv.srcObject = window.call.localStream;

    var pc = newPC();
    window.call.pc = pc;
    window.call.localStream.getTracks().forEach(function (tr) {
      pc.addTrack(tr, window.call.localStream);
    });
    ensureVideoTransceiver(pc);

    var fbDb = getDB();
    try { await fbDb.ref('calls/' + callId + '/status').set('accepted'); } catch (e) {}

    /* Offer ------------------------------------------------ */
    try {
      var offerSnap = await fbDb.ref('calls/' + callId + '/offer').get();
      var offer = offerSnap.val();
      if (!offer) { safeToast(T('call_failed'), 'err'); endCall(); return; }

      await pc.setRemoteDescription(new RTCSessionDescription(offer));
      var answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await fbDb.ref('calls/' + callId + '/answer').set({
        type: answer.type, sdp: answer.sdp
      });
    } catch (e) {
      safeToast(T('call_failed'), 'err');
      endCall();
      return;
    }

    /* Caller ICE ------------------------------------------- */
    var cRef = fbDb.ref('calls/' + callId + '/callerCandidates');
    var cCb = cRef.on('child_added', function (s) {
      try { pc.addIceCandidate(new RTCIceCandidate(s.val())); } catch (e) {}
    });
    window.call.refs.push({ ref: cRef, event: 'child_added', cb: cCb });

             /* Status ---------------------------------------------- */
          var stRef = fbDb.ref('calls/' + callId + '/status');
          var stCb = stRef.on('value', function (s) {
            var v = s.val();
            if (v === 'ended' || v === 'rejected') {
              endCall(true);
            } else if (v === 'blocked') {
              safeToast('This person blocked your call', 'err');
              endCall(true);
            }
          });
          window.call.refs.push({ ref: stRef, event: 'value', cb: stCb });

    var sEl = qs('#callStatus');
    if (sEl) sEl.textContent = T('connected');
    startCallTimer();
  }

  /* ============================================================
   * START CALL — the caller side
   * ============================================================
   * Preserved 1:1 from the original startCall(peerUid, type,
   * peerName, peerPhoto):
   *   • reject if a call is already active
   *   • reject if I blocked the peer
   *   • if the peer is offline → queue a pending call and
   *     return (no browser-unsupported toast in that case)
   *   • otherwise: request local media, open the call overlay,
   *     create the PC, push the offer, wire all listeners
   * ============================================================ */
  async function startCall(peerUid, type, peerName, peerPhoto) {
    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb || !peerUid) return false;

    if (window.call) {
      safeToast(T('user_busy'), 'err');
      return false;
    }

    /* Blocked peer ----------------------------------------- */
    if (typeof window.iBlocked === 'function' && window.iBlocked(peerUid)) {
      safeToast(T('user_blocked'), 'err');
      return false;
    }

    /* Peer offline → queue and return ---------------------- */
    if (!isRecipientOnline(peerUid)) {
      await savePendingCall(peerUid, type);
      safeToast(T('offline_call_saved'), 'ok');
      writeCallHistory(peerUid, peerName, peerPhoto, type, 'outgoing', 'missed', 0);
      return false;
    }

    /* Browser support -------------------------------------- */
    if (!isBrowserCallSupported()) {
      safeToast(T('not_supported'), 'err');
      return false;
    }

    var callId = fbDb.ref('calls').push().key;
    window.call = {
      id: callId,
      peer: peerUid,
      type: type,
      role: 'caller',
      pc: null,
      refs: [],
      muted: false,
      camOff: false,
      peerWasOnline: true
    };

    /* Local media ------------------------------------------ */
    try {
      window.call.localStream = await navigator.mediaDevices.getUserMedia(
        type === 'video'
          ? { audio: true, video: { facingMode: 'user' } }
          : { audio: true }
      );
    } catch (e) {
      safeToast(type === 'video' ? T('camera_permission') : T('mic_permission'), 'err');
      window.call = null;
      return false;
    }
    localStreamRef = window.call.localStream;

    showActiveCall(peerName || 'User', peerPhoto || '', type);
    var lv = qs('#localVideo');
    if (lv) lv.srcObject = window.call.localStream;

    var sEl = qs('#callStatus');
    if (sEl) sEl.textContent = T('calling');

    var pc = newPC();
    window.call.pc = pc;
    window.call.localStream.getTracks().forEach(function (tr) {
      pc.addTrack(tr, window.call.localStream);
    });
    ensureVideoTransceiver(pc);

    /* Publish the call ------------------------------------ */
    var me = getMyProfile() || {};
    try {
      await fbDb.ref('calls/' + callId).set({
        id: callId,
        from: uid,
        to: peerUid,
        type: type,
        status: 'ringing',
        fromName: me.name || '',
        fromPhoto: me.photo || '',
        createdAt: timeNow(),
        recipientWasOnline: true
      });

      try {
        await fbDb.ref('userCalls/' + peerUid + '/' + callId).set({
          at: timeNow(), from: uid, type: type, status: 'ringing'
        });
      } catch (e) {}

      var offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await fbDb.ref('calls/' + callId + '/offer').set({
        type: offer.type, sdp: offer.sdp
      });
    } catch (e) {
      safeToast(T('call_failed'), 'err');
      endCall();
      return false;
    }

    /* Answer listener ------------------------------------- */
    var aRef = fbDb.ref('calls/' + callId + '/answer');
    var aCb = aRef.on('value', async function (s) {
      var a = s.val();
      if (a && pc.signalingState !== 'stable') {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(a));
          var sEl2 = qs('#callStatus');
          if (sEl2) sEl2.textContent = T('connected');
          startCallTimer();
        } catch (e) {}
      }
    });
    window.call.refs.push({ ref: aRef, event: 'value', cb: aCb });

    /* Callee ICE ------------------------------------------- */
    var ccRef = fbDb.ref('calls/' + callId + '/calleeCandidates');
    var ccCb = ccRef.on('child_added', function (s) {
      try { pc.addIceCandidate(new RTCIceCandidate(s.val())); } catch (e) {}
    });
    window.call.refs.push({ ref: ccRef, event: 'child_added', cb: ccCb });

    /* Status ---------------------------------------------- */
    var stRef = fbDb.ref('calls/' + callId + '/status');
    var stCb = stRef.on('value', function (s) {
      var v = s.val();
      if (v === 'ended' || v === 'rejected') endCall(true);
    });
    window.call.refs.push({ ref: stRef, event: 'value', cb: stCb });

    /* Ring timeout ---------------------------------------- */
    callTimeoutHandle = setTimeout(function () {
      if (window.call && window.call.id === callId &&
          pc.connectionState !== 'connected') {
        safeToast(T('no_answer'));
        endCall();
      }
    }, CALL_TIMEOUT_MS);

    return true;
  }

  /* ============================================================
   * PEER CONNECTION
   * ============================================================ */
  function newPC() {
    var pc = new RTCPeerConnection(ICE_SERVERS);

    pc.onicecandidate = function (e) {
      if (!e.candidate || !window.call) return;
      var bucket = window.call.role === 'caller'
        ? 'callerCandidates'
        : 'calleeCandidates';
      var fbDb = getDB();
      if (!fbDb) return;
      fbDb.ref('calls/' + window.call.id + '/' + bucket)
        .push(e.candidate.toJSON()).catch(function () {});
    };

    pc.ontrack = function (e) {
      var rv = qs('#remoteVideo');
      var mr = qs('#miniRemote');
      if (e.streams && e.streams[0]) {
        if (rv) rv.srcObject = e.streams[0];
        if (mr) mr.srcObject = e.streams[0];
      }
      if (e.track && e.track.kind === 'video' && window.call &&
          window.call.type !== 'video') {
        if (rv) rv.style.display = 'block';
        var info = qs('#callInfo');
        if (info) info.style.display = 'none';
      }
    };

    pc.onconnectionstatechange = function () {
      if (!window.call) return;
      var st = pc.connectionState;
      var sEl = qs('#callStatus');

      if (st === 'connected') {
        if (sEl) sEl.textContent = T('connected');
        startCallTimer();
        if (callTimeoutHandle) {
          clearTimeout(callTimeoutHandle);
          callTimeoutHandle = null;
        }
      } else if (st === 'failed') {
        safeToast(T('connection_failed'), 'err');
        endCall();
      } else if (st === 'disconnected') {
        if (sEl) sEl.textContent = T('reconnecting');
      }
    };

    return pc;
  }

  /* ============================================================
   * ACTIVE CALL UI
   * ============================================================ */
  function showActiveCall(name, photo, type) {
    var ov = qs('#ovCall');
    if (!ov) return;
    ov.classList.add('open');

    var rv = qs('#remoteVideo');
    var lv = qs('#localVideo');
    var ci = qs('#callInfo');

    if (type === 'video') {
      if (rv) rv.style.display = 'block';
      if (lv) lv.style.display = 'block';
      if (ci) ci.style.display = 'none';
    } else {
      if (rv) rv.style.display = 'none';
      if (lv) lv.style.display = 'none';
      if (ci) ci.style.display = 'flex';
    }

    var av = qs('#callAvatar');
    if (av) {
      var html = avatarHTML(photo, name, 'av-88');
      av.outerHTML = html.replace('class="avatar', 'id="callAvatar" class="avatar');
    }

    var nEl = qs('#callName');
    if (nEl) nEl.textContent = name;

    var sEl = qs('#callStatus');
    if (sEl) sEl.textContent = T('ringing');

    var tEl = qs('#callTimer');
    if (tEl) tEl.textContent = '';

    buildCallControls(type);
    window.miniCallActive = false;
    var mini = qs('#miniCall');
    if (mini) mini.classList.remove('show');
  }

  function buildCallControls(type) {
    var ctrl = qs('#callControls');
    if (!ctrl) return;

    var isVideo = (type === 'video');
    ctrl.innerHTML =
      '<button class="call-btn" id="btnMute" title="' + esc(T('mute')) + '">' +
        svgIcon('mic') +
      '</button>' +
      '<button class="call-btn" id="btnSpeaker" title="' + esc(T('speaker')) + '">' +
        svgIcon('speaker') +
      '</button>' +
      (isVideo
        ? '<button class="call-btn" id="btnCam" title="' + esc(T('camera')) + '">' + svgIcon('video') + '</button>'
        : '') +
      (isVideo
        ? '<button class="call-btn" id="btnSwitch" title="' + esc(T('switch_camera')) + '">' + svgIcon('switchCam') + '</button>'
        : '') +
      '<button class="call-btn" id="btnMini" title="' + esc(T('minimize')) + '">' +
        svgIcon('minimize') +
      '</button>' +
      '<button class="call-btn end" id="btnEnd" title="' + esc(T('end_call')) + '">' +
        svgIcon('phoneOff') +
      '</button>';

    var btnEnd = qs('#btnEnd');
    if (btnEnd) btnEnd.onclick = function () { endCall(); };

    var btnMini = qs('#btnMini');
    if (btnMini) btnMini.onclick = function () { minimizeCall(); };

    var btnMute = qs('#btnMute');
    if (btnMute) {
      btnMute.onclick = function () {
        if (!window.call || !window.call.localStream) return;
        window.call.muted = !window.call.muted;
        window.call.localStream.getAudioTracks().forEach(function (tr) {
          tr.enabled = !window.call.muted;
        });
        btnMute.classList.toggle('on', window.call.muted);
        btnMute.innerHTML = svgIcon(window.call.muted ? 'micOff' : 'mic');
        var mm = qs('#miniMute');
        if (mm) {
          mm.innerHTML = svgIcon(window.call.muted ? 'micOff' : 'mic');
          mm.classList.toggle('on', window.call.muted);
        }
      };
    }

    var btnSpk = qs('#btnSpeaker');
    if (btnSpk) {
      btnSpk.onclick = async function () {
        window.speakerOn = !window.speakerOn;
        btnSpk.classList.toggle('on', window.speakerOn);
        btnSpk.innerHTML = svgIcon(window.speakerOn ? 'speaker' : 'speakerOff');
        await applySpeaker();
      };
    }

    var btnCam = qs('#btnCam');
    if (btnCam) {
      btnCam.onclick = function () {
        if (!window.call || !window.call.localStream) return;
        window.call.camOff = !window.call.camOff;
        window.call.localStream.getVideoTracks().forEach(function (tr) {
          tr.enabled = !window.call.camOff;
        });
        btnCam.classList.toggle('on', window.call.camOff);
        btnCam.innerHTML = svgIcon(window.call.camOff ? 'videoOff' : 'video');
      };
    }

    var btnSw = qs('#btnSwitch');
    if (btnSw) btnSw.onclick = function () { switchCamera(); };

    var mm = qs('#miniMute');
    if (mm) {
      mm.innerHTML = svgIcon('mic');
      mm.classList.remove('on');
    }
    var me = qs('#miniExpand');
    if (me) me.onclick = function () { expandCall(); };
    var mnd = qs('#miniEnd');
    if (mnd) mnd.onclick = function () { endCall(); };
  }

  async function applySpeaker() {
    try {
      var rv = qs('#remoteVideo');
      var mr = qs('#miniRemote');
      if (!rv || !rv.setSinkId) throw new Error('unsupported');

      var deviceId = '';
      if (window.speakerOn) {
        var devs = await navigator.mediaDevices.enumerateDevices();
        var outs = devs.filter(function (d) { return d.kind === 'audiooutput'; });
        if (outs.length > 1) {
          var spk = outs.find(function (d) { return /speaker/i.test(d.label); }) ||
                    outs[outs.length - 1];
          deviceId = spk.deviceId;
        }
      }
      await rv.setSinkId(deviceId);
      if (mr && mr.setSinkId) {
        try { await mr.setSinkId(deviceId); } catch (e) {}
      }
    } catch (e) {
      safeToast(T('not_supported'), 'err');
      window.speakerOn = false;
      var sb = qs('#btnSpeaker');
      if (sb) { sb.classList.remove('on'); sb.innerHTML = svgIcon('speakerOff'); }
    }
  }

  async function switchCamera() {
    if (!window.call || !window.call.localStream) return;
    try {
      var tracks = window.call.localStream.getVideoTracks();
      if (!tracks.length) { safeToast(T('camera_on')); return; }
      var cur = tracks[0].getSettings().facingMode || 'user';
      var next = cur === 'user' ? 'environment' : 'user';

      var ns = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: next }, audio: false
      });
      var nt = ns.getVideoTracks()[0];

      var sender = window.call.pc.getSenders().find(function (s) {
        return s.track && s.track.kind === 'video';
      });
      if (sender) await sender.replaceTrack(nt);

      tracks.forEach(function (tr) {
        tr.stop();
        window.call.localStream.removeTrack(tr);
      });
      window.call.localStream.addTrack(nt);

      var lv = qs('#localVideo');
      if (lv) lv.srcObject = window.call.localStream;
    } catch (e) {
      safeToast(T('not_supported'), 'err');
    }
  }

  function minimizeCall() {
    if (!window.call) return;
    window.miniCallActive = true;
    var ov = qs('#ovCall');
    if (ov) ov.classList.remove('open');
    var mini = qs('#miniCall');
    if (mini) mini.classList.add('show');

    var mr = qs('#miniRemote');
    var rv = qs('#remoteVideo');

    /* Show peer avatar if no video is available --------- */
    var ma = qs('#miniAvatar');
    if (rv && rv.srcObject && mr) {
      mr.srcObject = rv.srcObject;
      mr.style.display = 'block';
      if (ma) ma.style.display = 'none';
    } else if (mr) {
      mr.style.display = 'none';
      var peer = findUser(window.call.peer) || { name: '', photo: '' };
      if (ma) {
        ma.style.display = 'flex';
        var html = avatarHTML(peer.photo, peer.name, 'av-56');
        ma.outerHTML = html.replace('class="avatar', 'id="miniAvatar" class="avatar');
      }
    }

    var mt = qs('#miniTimer');
    if (mt) mt.textContent = fmtDur(Math.floor((timeNow() - callStartedAt) / 1000));

    var mm = qs('#miniMute');
    if (mm) {
      mm.innerHTML = svgIcon(window.call.muted ? 'micOff' : 'mic');
      mm.classList.toggle('on', !!window.call.muted);
    }
  }

  function expandCall() {
    if (!window.call) return;
    window.miniCallActive = false;
    var mini = qs('#miniCall');
    if (mini) mini.classList.remove('show');
    var ov = qs('#ovCall');
    if (ov) ov.classList.add('open');

    var rv = qs('#remoteVideo');
    var lv = qs('#localVideo');
    var ci = qs('#callInfo');

    if (window.call.type === 'video' || (rv && rv.srcObject)) {
      if (rv) rv.style.display = 'block';
      if (window.call.type === 'video' && lv) lv.style.display = 'block';
      if (ci) ci.style.display = 'none';
    } else {
      if (ci) ci.style.display = 'flex';
    }
    if (window.call.localStream && lv) lv.srcObject = window.call.localStream;
  }

  function startCallTimer() {
    if (callDurationTimer) clearInterval(callDurationTimer);
    callStartedAt = callStartedAt || timeNow();
    callDurationTimer = setInterval(function () {
      var s = Math.floor((timeNow() - callStartedAt) / 1000);
      var el = qs('#callTimer');
      if (el) el.textContent = fmtDur(s);
      var mt = qs('#miniTimer');
      if (mt) mt.textContent = fmtDur(s);
    }, 1000);
  }

  /* ============================================================
   * END CALL
   * ============================================================
   * Preserved 1:1 from the original endCall(remote):
   *   • clear timers
   *   • write status='ended' when we are the one hanging up
   *   • remove the incoming-call index entries
   *   • detach all listeners
   *   • close the PC + stop tracks
   *   • reset UI
   *   • log into call history (only when !remote)
   * ============================================================ */
  async function endCall(remote) {
    if (!window.call) return;
    var c = window.call;
    window.call = null;

    if (callTimeoutHandle) { clearTimeout(callTimeoutHandle); callTimeoutHandle = null; }
    if (callDurationTimer) { clearInterval(callDurationTimer); callDurationTimer = null; }

    var dur = callStartedAt ? Math.floor((timeNow() - callStartedAt) / 1000) : 0;
    callStartedAt = 0;

    var fbDb = getDB();

    try {
      if (!remote && c.id && fbDb) {
        await fbDb.ref('calls/' + c.id + '/status').set('ended');
      }
    } catch (e) {}

    try { if (c.peer && fbDb) await fbDb.ref('userCalls/' + c.peer + '/' + c.id).remove(); }
    catch (e) {}
    var myUid = getMyUid();
    try { if (myUid && fbDb) await fbDb.ref('userCalls/' + myUid + '/' + c.id).remove(); }
    catch (e) {}

    c.refs.forEach(function (r) {
      try { r.ref.off(r.event, r.cb); } catch (e) {}
    });

    if (c.pc) {
      try {
        c.pc.getSenders().forEach(function (s) {
          try { s.track && s.track.stop && s.track.stop(); } catch (e) {}
        });
        c.pc.ontrack = null;
        c.pc.onicecandidate = null;
        c.pc.onconnectionstatechange = null;
        c.pc.close();
      } catch (e) {}
    }

    if (c.localStream) {
      c.localStream.getTracks().forEach(function (tr) {
        try { tr.stop(); } catch (e) {}
      });
    }
    localStreamRef = null;

    var rv = qs('#remoteVideo');
    var lv = qs('#localVideo');
    var mr = qs('#miniRemote');
    if (rv) rv.srcObject = null;
    if (lv) lv.srcObject = null;
    if (mr) mr.srcObject = null;

    var ov = qs('#ovCall');
    if (ov) ov.classList.remove('open');
    var mini = qs('#miniCall');
    if (mini) mini.classList.remove('show');
    window.miniCallActive = false;

    if (!remote) {
      var peer = findUser(c.peer) || { name: '', photo: '' };
      writeCallHistory(
        c.peer, peer.name, peer.photo, c.type,
        c.role === 'caller' ? 'outgoing' : 'incoming',
        'ended', dur
      );
    }

    if (dur > 0) safeCall('bumpDaily', ['call', 1]);
    safeToast(T('call_ended'));
  }

  /* ============================================================
   * CALL HISTORY
   * ============================================================ */
  async function writeCallHistory(peerUid, peerName, peerPhoto, type, direction, status, duration) {
    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb || !peerUid) return;

    try {
      var ref = fbDb.ref('callHistory/' + uid).push();
      await ref.set({
        id: ref.key,
        peerUid: peerUid,
        peerName: peerName || '',
        peerPhoto: peerPhoto || '',
        type: type || 'audio',
        direction: direction,
        status: status,
        duration: duration || 0,
        createdAt: timeNow()
      });

      if (status === 'missed') {
        safeCall('pushNotification', [uid, {
          type: 'missed_call',
          fromUid: peerUid,
          fromName: peerName,
          fromPhoto: peerPhoto,
          text: T('missed_call'),
          createdAt: timeNow()
        }]);
      }
    } catch (e) {}
  }

  function startCallHistory() {
    if (callHistoryRef && callHistoryCb) return true;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    callHistoryRef = fbDb.ref('callHistory/' + uid)
      .orderByChild('createdAt')
      .limitToLast(100);

    callHistoryCb = callHistoryRef.on('value', function (s) {
      var v = s.val() || {};
      callHistoryCache = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      }).sort(function (a, b) {
        return (b.createdAt || 0) - (a.createdAt || 0);
      });
      if (qs('#ovHistory') && qs('#ovHistory').classList.contains('open')) {
        renderCallHistory();
      }
    });
    return true;
  }

  function detachCallHistory() {
    if (callHistoryRef && callHistoryCb) {
      try { callHistoryRef.off('value', callHistoryCb); } catch (e) {}
    }
    callHistoryRef = null;
    callHistoryCb  = null;
    callHistoryCache = [];
    return true;
  }

  function openCallHistory() {
    safeCall('openOverlay', ['ovHistory']);
    renderCallHistory();
  }

  function renderCallHistory() {
    var body = qs('#historyBody');
    if (!body) return;

    if (!callHistoryCache.length) {
      body.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('phone') + '</span>' +
          '<p>' + esc(T('no_notifications')) + '</p>' +
        '</div>';
      return;
    }

    body.innerHTML = callHistoryCache.map(function (h) {
      var durTxt = h.duration ? ' · ' + esc(fmtDur(h.duration)) : '';
      var pillCls = h.status === 'missed' ? 'missed' : 'ok';
      var pillTxt = h.status === 'missed' ? T('missed_call') : T('call_ended');
      return '<div class="hist-item" data-hist="' + esc(h.id) + '">' +
        avatarHTML(h.peerPhoto, h.peerName, 'av-40') +
        '<div class="grow">' +
          '<div class="name">' + esc(h.peerName || 'User') + '</div>' +
          '<div class="mini">' +
            esc(T(h.direction)) + ' · ' + esc(timeAgo(h.createdAt)) + durTxt +
          '</div>' +
        '</div>' +
        '<span class="call-pill ' + pillCls + '">' + esc(pillTxt) + '</span>' +
      '</div>';
    }).join('');

    qsa('[data-hist]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var h = callHistoryCache.find(function (x) {
          return x.id === n.getAttribute('data-hist');
        });
        if (!h) return;
        safeCall('closeOverlay', ['ovHistory']);
        startCall(h.peerUid, h.type === 'video' ? 'video' : 'audio',
                  h.peerName, h.peerPhoto);
      });
    });
  }

  /* ============================================================
   * BIND — #btnClearHistory
   * ============================================================ */
  var boundClear = false;
  function bind() {
    if (boundClear) return true;
    var btn = qs('#btnClearHistory');
    if (btn && btn.dataset.callsCoreBound !== '1') {
      btn.dataset.callsCoreBound = '1';
      btn.addEventListener('click', async function () {
        var ok = await safeCall('confirmDialog', [T('clear'), T('are_you_sure')]);
        if (!ok) return;
        var uid = getMyUid();
        var fbDb = getDB();
        if (!uid || !fbDb) return;
        try { await fbDb.ref('callHistory/' + uid).remove(); } catch (e) {}
        callHistoryCache = [];
        renderCallHistory();
      });
    }
    boundClear = true;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.ICE_SERVERS              = ICE_SERVERS;
  window.isBrowserCallSupported   = isBrowserCallSupported;
  window.isRecipientOnline        = isRecipientOnline;
  window.savePendingCall          = savePendingCall;
  window.startIncomingCalls       = startIncomingCalls;
  window.detachIncomingCalls      = detachIncomingCalls;
  window.showIncomingCall         = showIncomingCall;
  window.answerCall               = answerCall;
  window.startCall                = startCall;
  window.newPC                    = newPC;
  window.ensureVideoTransceiver   = ensureVideoTransceiver;
  window.showActiveCall           = showActiveCall;
  window.buildCallControls        = buildCallControls;
  window.minimizeCall             = minimizeCall;
  window.expandCall               = expandCall;
  window.applySpeaker             = applySpeaker;
  window.switchCamera             = switchCamera;
  window.startCallTimer           = startCallTimer;
  window.endCall                  = endCall;
  window.writeCallHistory         = writeCallHistory;
  window.startCallHistory         = startCallHistory;
  window.detachCallHistory        = detachCallHistory;
  window.openCallHistory          = openCallHistory;
  window.renderCallHistory        = renderCallHistory;

  window.SaikoCalls = {
    ICE_SERVERS: ICE_SERVERS,
    isSupported: isBrowserCallSupported,
    isOnline: isRecipientOnline,
    start: startCall,
    answer: answerCall,
    end: endCall,
    incoming: startIncomingCalls,
    detachIncoming: detachIncomingCalls,
    historyStart: startCallHistory,
    historyDetach: detachCallHistory,
    historyOpen: openCallHistory,
    historyRender: renderCallHistory,
    writeHistory: writeCallHistory,
    bind: bind
  };

  /* Auto-bind clear-history button -------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] calls-core ready (supported=' + isBrowserCallSupported() + ')');
  } catch (e) {}

})();