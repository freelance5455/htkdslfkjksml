/* ============================================================
 * SAIKO FIX — Live Profile Stats v3 (Direct DOM + Visible Errors)
 * FILE: js/_fix-stats-live.js
 * ============================================================ */
(function () {
  'use strict';

  console.log('[stats-live] BOOTED v3');

  function getDB() { try { return window.db || null; } catch (e) { return null; } }
  function getUid() { try { return window.myUid || null; } catch (e) { return null; } }
  function toast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }

  var lastFetchAt = 0;
  var lastCount = -1;
  var fetchInFlight = false;

  /* ---------- Direct DOM update ---------- */
  function updateVisitorsCountUI(count) {
    var el = document.querySelector('#openVisitors b');
    if (el) {
      el.textContent = String(count);
      console.log('[stats-live] ✓ UI updated to', count);
    } else {
      console.log('[stats-live] ✗ #openVisitors b not found in DOM');
    }
  }

  /* ---------- Fetch visitors from Firebase ---------- */
  function fetchVisitors() {
    if (fetchInFlight) return;

    var uid = getUid();
    var fbDb = getDB();
    if (!uid || !fbDb) {
      console.log('[stats-live] skip — uid:', uid, 'db:', !!fbDb);
      return;
    }

    var now = Date.now();
    if (now - lastFetchAt < 1000) return;
    lastFetchAt = now;
    fetchInFlight = true;

    console.log('[stats-live] → fetching profileVisits/' + uid);

    fbDb.ref('profileVisits/' + uid).get().then(function (s) {
      fetchInFlight = false;
      var v = s.val() || {};
      window.visitorsCache = v;
      var count = Object.keys(v).length;
      console.log('[stats-live] ✓ got', count, 'visitors:', v);

      lastCount = count;
      updateVisitorsCountUI(count);

      if (count > 0) {
        toast('Visitors: ' + count, 'ok');
      }
    }).catch(function (e) {
      fetchInFlight = false;
      var msg = (e && e.message) ? e.message : 'unknown';
      console.error('[stats-live] ✗ fetch ERROR:', e);
      /* Visible error */
      toast('Visitors load failed: ' + msg, 'err');
    });
  }

  /* ---------- Watch #page-profile for re-render ---------- */
  function watchProfilePage() {
    var page = document.getElementById('page-profile');
    if (!page) { setTimeout(watchProfilePage, 500); return; }
    if (page.dataset.slWatch === '1') return;
    page.dataset.slWatch = '1';

    try {
      var obs = new MutationObserver(function () {
        if (window.currentNav !== 'profile') return;
        var el = document.querySelector('#openVisitors');
        if (el) setTimeout(fetchVisitors, 20);
      });
      obs.observe(page, { childList: true, subtree: false });
      console.log('[stats-live] ✓ watching #page-profile');
    } catch (e) {
      console.warn('[stats-live] MutationObserver failed', e);
    }
  }

  /* ---------- Event hooks ---------- */
  window.addEventListener('saiko:navigate', function (e) {
    if (e && e.detail && e.detail.nav === 'profile') {
      setTimeout(fetchVisitors, 150);
      setTimeout(fetchVisitors, 600);
      setTimeout(fetchVisitors, 1500);
    }
  });

  window.addEventListener('saiko:login', function () {
    lastCount = -1;
    lastFetchAt = 0;
    setTimeout(fetchVisitors, 600);
  });

  /* ---------- Interval fallback ---------- */
  setInterval(function () {
    if (window.currentNav === 'profile') {
      var el = document.querySelector('#openVisitors');
      if (el) fetchVisitors();
    }
  }, 3000);

  /* ---------- Boot ---------- */
  setTimeout(fetchVisitors, 400);
  setTimeout(fetchVisitors, 1200);
  setTimeout(fetchVisitors, 2500);
  watchProfilePage();

  /* ---------- Debug API ---------- */
  window.SaikoStatsDebug = {
    VERSION: 'v3',
    status: function () {
      return {
        myUid: getUid(),
        currentNav: window.currentNav,
        visitorsCacheSize: Object.keys(window.visitorsCache || {}).length,
        visitorsCache: window.visitorsCache,
        lastCount: lastCount,
        domText: (document.querySelector('#openVisitors b') || {}).textContent
      };
    },
    fetchNow: fetchVisitors,
    reset: function () { lastFetchAt = 0; lastCount = -1; fetchInFlight = false; fetchVisitors(); }
  };

  console.log('[stats-live] v3 ready — SaikoStatsDebug.status() available');
})();