/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED) — BOOT ORCHESTRATOR
 * FILE:   js/boot.js
 * ACTION: REPLACE (v2 — removed duplicate #offlineGameBtn wiring)
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel) { return document.querySelector(sel); }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[boot] safeCall:', name, e); }
    return undefined;
  }

  var _listenersAttached = false;

  /* ============================================================
   * GLOBAL LISTENERS
   * ============================================================ */
  function startGlobalListeners() {
    if (_listenersAttached) return true;
    _listenersAttached = true;

    safeCall('attachSearchListener');
    safeCall('startFeed');
    safeCall('startInbox');
    safeCall('startNotifs');
    safeCall('startGames');
    safeCall('startIncomingCalls');
    safeCall('startCallHistory');
    safeCall('startStories');
    safeCall('startReels');
    safeCall('startReelLikes');
    safeCall('startSavedPosts');
    safeCall('startVisitors');
    safeCall('startAdminSync');
    safeCall('startRestrictedPosts');

    /* Optional modules */
    safeCall('startStarredMsgsListener');
    safeCall('startSmsBlockedListener');
    safeCall('startCallBlockedListener');
    safeCall('startMutedAuthorsListener');
    safeCall('startHighlightsListener');
    safeCall('startReelHistory');

    return true;
  }

  /* ============================================================
   * BUTTON FALLBACK WIRING
   * ============================================================
   * NOTE: #offlineGameBtn is NOT wired here anymore. It is wired
   * exclusively by js/games/025-offline-games.js (which waits for
   * the cache to finish before opening the overlay). Wiring it
   * here too caused a race condition where the overlay opened
   * before the cache was ready.
   * ============================================================ */
  function wireFallbackButtons() {
    var mr = qs('#maintRetry');
    if (mr && mr.dataset.bootWired !== '1') {
      mr.dataset.bootWired = '1';
      mr.addEventListener('click', function () { location.reload(); });
    }

    var br = qs('#blkRetry');
    if (br && br.dataset.bootWired !== '1') {
      br.dataset.bootWired = '1';
      br.addEventListener('click', function () { location.reload(); });
    }
  }

  /* ============================================================
   * CONFIG-MISSING FALLBACK
   * ============================================================ */
  function handleConfigMissing() {
    var m = qs('#authMsg');
    if (m) {
      m.className = 'auth-msg err';
      m.textContent = 'Firebase config missing. Check console.';
    }
    var lb = qs('#loginBtn');
    if (lb) lb.disabled = true;
    var sb = qs('#signupBtn');
    if (sb) sb.disabled = true;
  }

  /* ============================================================
   * AUTH FAILSAFE — 3 s
   * ============================================================ */
  function armAuthFailsafe() {
    setTimeout(function () {
      var resolved = false;
      try { resolved = !!window.authResolved; } catch (e) {}
      if (resolved) return;

      try { window.authResolved = true; } catch (e) {}
      safeCall('hideSplash');

      var u = null;
      try { u = window.myUid || null; } catch (e) {}
      if (!u) {
        var a = qs('#authScreen');
        if (a) a.classList.remove('hidden');
      }
    }, 3000);
  }

  /* ============================================================
   * CLEANUP
   * ============================================================ */
  function onPageHide() {
    try { if (typeof window.hardStopReelsPlayback === 'function') window.hardStopReelsPlayback(); }
    catch (e) {}
  }

  /* ============================================================
   * BOOT
   * ============================================================ */
  function boot() {
    safeCall('mountIcons', [document]);
    safeCall('applyI18n');
    safeCall('buildNavIcons');

    wireFallbackButtons();

    var ok = true;
    try { ok = !!window.configOK; } catch (e) { ok = false; }
    if (!ok) handleConfigMissing();

    armAuthFailsafe();

    setTimeout(function () { safeCall('handleHash'); }, 800);

    window.addEventListener('pagehide', onPageHide);
    window.addEventListener('beforeunload', onPageHide);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startGlobalListeners = startGlobalListeners;

  window.SaikoBoot = {
    startGlobalListeners: startGlobalListeners,
    isBooted: function () { return _listenersAttached; },
    boot: boot
  };

  /* ============================================================
   * AUTO-RUN
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    console.debug('[boot] boot.js ready');
  } catch (e) {}
})();