/* ============================================================
 * FEATURE:        Reel Collection
 * FEATURE NUMBER: 227
 * FILE:           js/reels/227-reel-collection.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "save this reel into a collection" flow plus the
 *   collection browser overlay:
 *
 *     1. ADD TO COLLECTION
 *          addReelToCollection(rid)
 *            — reads the user's collections from
 *              collections/{uid}
 *            — if none exist, prompts for a name and creates
 *              the first collection with the reel inside it
 *            — otherwise, opens a bottom sheet listing every
 *              collection + a "New collection" button
 *            — clicking a collection writes
 *                collections/{uid}/{cid}/items/{rid} = true
 *              and toasts t('saved_to_collection')
 *
 *     2. OPEN COLLECTIONS
 *          openCollections()
 *            — reads collections/{uid}
 *            — renders one row per collection with its item
 *              count
 *            — clicking a row opens a sub-overlay listing the
 *              items (reels from window.reelsCache, or posts
 *              from window.postsCache — a collection can hold
 *              either)
 *
 *   Behaviour preserved 1:1 from the original §29 REELS block:
 *
 *     async function addReelToCollection(rid){
 *       const snap = await db.ref('collections/'+myUid).get();
 *       const cols = snap.val() || {};
 *       const names = Object.keys(cols);
 *       if(!names.length){
 *         const name = await promptDialog(t('new_collection'), '',
 *                                         t('collection_name'));
 *         if(name == null || !name.trim()) return;
 *         const ref = db.ref('collections/'+myUid).push();
 *         await ref.set({ id: ref.key, name: name.trim(),
 *                         items: { [rid]: true }, type:'reels',
 *                         createdAt: now() });
 *         toast(t('saved_to_collection'), 'ok');
 *         return;
 *       }
 *       // ... render the picker sheet ...
 *     }
 *
 *     function openCollections(){
 *       openOverlay('ovCollection');
 *       ... render ...
 *     }
 *
 *   Data shape:
 *     collections/{uid}/{cid} = {
 *       id, name,
 *       items: { [itemId]: true },
 *       type: 'reels' | 'posts',
 *       createdAt
 *     }
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §29 REELS
 *       addReelToCollection(rid)
 *       openCollections()
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid / myProfile        js/auth/004-auth-state.js
 *   - t / esc / now / timeAgo  helpers
 *   - openOverlay / closeOverlay (038)
 *   - toast                    js/nav/042-toast.js
 *   - promptDialog             js/nav/044-prompt-dialog.js
 *   - svgIcon                  js/nav/045-icon-system.js
 *   - findUser                 js/search/091-search-users.js
 *   - postHTML / wirePostInteractions  js/feed/post-card.js
 *   - openReels                js/reels/211-reels-feed.js
 *
 * DOM ELEMENTS USED:
 *   #msgMenuSheet      (shared bottom sheet, used for the picker)
 *   #ovMsgMenu         (shared overlay for that sheet)
 *   #ovCollection      (the collections browser overlay)
 *   #collectionTitle   (title of the browser)
 *   #collectionBody    (content of the browser)
 *   #collectionAdd     (the "+" button in the browser header)
 *   #ovUserList        (reused as the "collection contents" overlay)
 *   #userListTitle     (its title)
 *   #userListBody      (its content)
 *
 * FIREBASE PATHS:
 *   collections/{uid}                          (read + listen)
 *   collections/{uid}/{cid}                    (create / remove)
 *   collections/{uid}/{cid}/items/{itemId}     (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.addReelToCollection     (original name preserved)
 *   window.openCollections         (original name preserved)
 *   window.SaikoReelCollection = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var collectionsRef = null;
  var collectionsCb  = null;
  var collectionsCache = {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) { return ''; }
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') {
        return window.promptDialog(title, defValue, placeholder);
      }
    } catch (e) {}
    return Promise.resolve(null);
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reel-collection] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * LISTENER — collections/{uid}
   * ============================================================ */
  function startListener() {
    if (collectionsRef && collectionsCb) return true;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    collectionsRef = fbDb.ref('collections/' + uid);
    collectionsCb = collectionsRef.on('value', function (s) {
      collectionsCache = s.val() || {};
      if (qs('#ovCollection') && qs('#ovCollection').classList.contains('open')) {
        renderCollections();
      }
    });
    return true;
  }

  function detachListener() {
    if (collectionsRef && collectionsCb) {
      try { collectionsRef.off('value', collectionsCb); } catch (e) {}
    }
    collectionsRef = null;
    collectionsCb = null;
    collectionsCache = {};
    return true;
  }

  /* ============================================================
   * ADD REEL TO COLLECTION
   * ============================================================
   * Preserved 1:1 from the original addReelToCollection(rid).
   * ============================================================ */
  async function addReelToCollection(rid) {
    if (!rid) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var snap;
    try {
      snap = await fbDb.ref('collections/' + uid).get();
    } catch (e) {
      safeToast(T('error'), 'err');
      return false;
    }

    var cols = snap.val() || {};
    var names = Object.keys(cols);

    /* ---- No collections yet → create the first one ------ */
    if (!names.length) {
      var name = await askPrompt(
        T('new_collection'), '',
        T('collection_name')
      );
      if (name == null) return false;
      var trimmed = String(name).trim();
      if (!trimmed) return false;

      try {
        var ref = fbDb.ref('collections/' + uid).push();
        await ref.set({
          id: ref.key,
          name: trimmed,
          items: (function () { var o = {}; o[rid] = true; return o; })(),
          type: 'reels',
          createdAt: timeNow()
        });
        safeToast(T('saved_to_collection'), 'ok');
        return true;
      } catch (err) {
        safeToast((err && err.message) ? err.message : T('error'), 'err');
        return false;
      }
    }

    /* ---- Collections exist → show the picker sheet ------ */
    var html = names.map(function (n) {
      var c = cols[n] || {};
      return '<div class="col-item" data-col="' + esc(n) + '">' +
        '<span class="ic">' + svgIcon('folder') + '</span>' +
        '<div class="grow">' + esc(c.name || 'Collection') + '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
      '</div>';
    }).join('');

    html += '<button class="btn ghost block" id="newColBtn" style="margin-top:.6rem">+ ' +
            esc(T('new_collection')) + '</button>';

    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;

    sheet.innerHTML = '<div class="sheet-handle"></div>' +
                      '<div style="padding:.4rem">' + html + '</div>';

    safeCall('openOverlay', ['ovMsgMenu']);

    /* ---- Collection click ------------------------------- */
    qsa('[data-col]', sheet).forEach(function (n) {
      n.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var cid = n.getAttribute('data-col');
        try {
          await fbDb.ref('collections/' + uid + '/' + cid + '/items/' + rid).set(true);
          safeToast(T('saved_to_collection'), 'ok');
        } catch (err) {
          safeToast((err && err.message) ? err.message : T('error'), 'err');
        }
      });
    });

    /* ---- New collection button -------------------------- */
    var nb = qs('#newColBtn', sheet);
    if (nb) {
      nb.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var name2 = await askPrompt(
          T('new_collection'), '',
          T('collection_name')
        );
        if (name2 == null) return;
        var trimmed2 = String(name2).trim();
        if (!trimmed2) return;
        try {
          var ref2 = fbDb.ref('collections/' + uid).push();
          await ref2.set({
            id: ref2.key,
            name: trimmed2,
            items: (function () { var o = {}; o[rid] = true; return o; })(),
            type: 'reels',
            createdAt: timeNow()
          });
          safeToast(T('saved_to_collection'), 'ok');
        } catch (err) {
          safeToast((err && err.message) ? err.message : T('error'), 'err');
        }
      });
    }

    return true;
  }

  /* ============================================================
   * OPEN COLLECTIONS
   * ============================================================
   * Preserved 1:1 from the original openCollections():
   *   • open #ovCollection
   *   • read collections/{uid}
   *   • render .col-item rows
   *   • wire each row → openCollectionContents(cid, name)
   * ============================================================ */
  function openCollections() {
    safeCall('openOverlay', ['ovCollection']);

    /* Kick off the live listener (idempotent) ------------ */
    startListener();

    /* If the listener has not fired yet, do a one-shot read */
    if (!Object.keys(collectionsCache).length) {
      var uid  = getMyUid();
      var fbDb = getDB();
      if (uid && fbDb) {
        fbDb.ref('collections/' + uid).get().then(function (s) {
          collectionsCache = s.val() || {};
          renderCollections();
        }).catch(function () { renderCollections(); });
      } else {
        renderCollections();
      }
    } else {
      renderCollections();
    }
    return true;
  }

  /* ============================================================
   * RENDER COLLECTIONS LIST
   * ============================================================ */
  function renderCollections() {
    var body = qs('#collectionBody');
    if (!body) return false;

    var keys = Object.keys(collectionsCache);
    if (!keys.length) {
      body.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('folder') + '</span>' +
          '<p>' + esc(T('no_data')) + '</p>' +
        '</div>';
      return true;
    }

    var list = keys.map(function (k) {
      return Object.assign({ id: k }, collectionsCache[k]);
    }).sort(function (a, b) {
      return (b.createdAt || 0) - (a.createdAt || 0);
    });

    body.innerHTML = list.map(function (c) {
      var count = Object.keys(c.items || {}).length;
      return '<div class="col-item" data-colopen="' + esc(c.id) + '">' +
        '<span class="ic">' + svgIcon('folder') + '</span>' +
        '<div class="grow">' +
          '<div class="name">' + esc(c.name || 'Collection') + '</div>' +
          '<div class="mini">' + count + ' items</div>' +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
      '</div>';
    }).join('');

    body.innerHTML = list.map(function (c) {
      var count = Object.keys(c.items || {}).length;
      return '<div class="col-item" data-colopen="' + esc(c.id) + '">' +
        '<span class="ic">' + svgIcon('folder') + '</span>' +
        '<div class="grow">' +
          '<div class="name">' + esc(c.name || 'Collection') + '</div>' +
          '<div class="mini">' + count + ' items</div>' +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
      '</div>';
    }).join('');

    qsa('[data-colopen]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var cid = n.getAttribute('data-colopen');
        var col = list.find(function (x) { return x.id === cid; });
        if (!col) return;
        openCollectionContents(col);
      });
    });

    return true;
  }

  /* ============================================================
   * OPEN COLLECTION CONTENTS
   * ============================================================
   * Reuses the #ovUserList overlay (the same one used by reels
   * history). Renders each item as either a reel preview (when
   * it can be found in reelsCache) or a post card (via the
   * shared post-card renderer).
   * ============================================================ */
  function openCollectionContents(col) {
    if (!col) return false;

    safeCall('closeOverlay', ['ovCollection']);
    safeCall('openOverlay', ['ovUserList']);

    var titleEl = qs('#userListTitle');
    if (titleEl) titleEl.textContent = col.name || T('collections');

    var body = qs('#userListBody');
    if (!body) return false;

    var ids = Object.keys(col.items || {});
    if (!ids.length) {
      body.innerHTML =
        '<div class="empty"><p>' + esc(T('no_data')) + '</p></div>';
      return true;
    }

    var reelsCache = Array.isArray(window.reelsCache) ? window.reelsCache : [];
    var postsCache = Array.isArray(window.postsCache) ? window.postsCache : [];

    var rows = ids.map(function (id) {
      /* Reel? ------------------------------------------- */
      var r = null;
      for (var i = 0; i < reelsCache.length; i++) {
        if (reelsCache[i].id === id) { r = reelsCache[i]; break; }
      }
      if (r) {
        var u = findUser(r.uid) || { name: r.authorName || 'User', photo: r.authorPhoto || '' };
        return '<div class="user-card" data-ropen="' + esc(r.id) + '" style="padding:.5rem">' +
          '<video src="' + esc(r.url) + '" muted playsinline preload="metadata" ' +
                 'style="width:3.5rem;height:4.5rem;object-fit:cover;border-radius:.5rem"></video>' +
          '<div class="grow">' +
            '<div class="name">' + esc(u.name) + '</div>' +
            '<div class="muted ellipsis">' + esc(r.text || '') + '</div>' +
          '</div>' +
        '</div>';
      }

      /* Post? ------------------------------------------- */
      var p = null;
      for (var j = 0; j < postsCache.length; j++) {
        if (postsCache[j].id === id) { p = postsCache[j]; break; }
      }
      if (p) {
        try {
          if (typeof window.postHTML === 'function') return window.postHTML(p);
        } catch (e) {}
        return '';
      }
      return '';
    }).join('');

    body.innerHTML = rows || ('<div class="empty"><p>' + esc(T('no_data')) + '</p></div>');

    /* Wire reel rows ------------------------------------ */
    qsa('[data-ropen]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovUserList']);
        safeCall('openReels', [n.getAttribute('data-ropen')]);
      });
    });

    /* Wire post cards ----------------------------------- */
    safeCall('wirePostInteractions', [body]);
    safeCall('paintPostCounts');

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.addReelToCollection = addReelToCollection;
  window.openCollections     = openCollections;

  window.SaikoReelCollection = {
    add: addReelToCollection,
    open: openCollections,
    renderCollections: renderCollections,
    openContents: openCollectionContents,
    startListener: startListener,
    detachListener: detachListener,
    getCache: function () { return collectionsCache; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 227 — reel-collection ready');
  } catch (e) {}

})();