/* ============================================================
 * FEATURE:        Reels Upload
 * FEATURE NUMBER: 229
 * FILE:           js/reels/229-reels-upload.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "New Reel" composer (#ovReelUpload). Handles:
 *
 *     1. OPEN
 *          openReelUpload() — reset state (video, caption,
 *          progress bar, status line), open the overlay, and
 *          raise the overlay's z-index to sit above the reels
 *          feed (matches the original inline style).
 *
 *     2. VIDEO PICK
 *          #reelPick → hidden #reelFile
 *          #reelFile change →
 *            • validateVideo(file, 100 MB, 3 min)
 *            • probeVideo(file) duration guard
 *            • cloudinaryUpload(file, 'reel.mp4', onProgress)
 *            • preview <video controls>
 *
 *     3. PUBLISH
 *          #reelPublish → push into reels/{rid} with:
 *              { id, uid, url, text,
 *                authorName, authorPhoto,
 *                createdAt, views: 0, likes: 0 }
 *          then close + open the reels feed at the new reel.
 *
 *   Behaviour preserved 1:1 from the original §29 REELS block:
 *
 *     reelMedia (state)       — { type:null, url:'' }
 *     MAX_REEL_SECONDS = 3*60 (from MEDIA_CONFIG)
 *     MAX_REEL_BYTES   = 100 MB (from MEDIA_CONFIG)
 *     awardXp('post_created', 5)
 *     bumpDaily('reel_create', 1)
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §29 REELS
 *       openReelUpload() / #reelsUpload click handler
 *       #reelPick click handler
 *       #reelFile change handler
 *       #reelPublish click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid / myProfile        js/auth/004-auth-state.js
 *   - t / esc / now            helpers
 *   - openOverlay / closeOverlay (038)
 *   - toast                    js/nav/042-toast.js
 *   - validateVideo / probeVideo / cloudinaryUpload
 *   - openReels                js/reels/211-reels-feed.js
 *
 * DOM ELEMENTS USED:
 *   #ovReelUpload, #reelPick, #reelFile, #reelText,
 *   #reelPreview, #reelBar, #reelStatus, #reelPublish
 *
 * FIREBASE PATHS:
 *   reels/{rid}                (write)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openReelUpload          (original name preserved)
 *   window.SaikoReelUpload = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_REEL_SECONDS: 3 * 60,
    MAX_REEL_BYTES: 100 * 1024 * 1024
  };
  var MAX_REEL_SECONDS = MEDIA_CONFIG.MAX_REEL_SECONDS || (3 * 60);
  var MAX_REEL_BYTES   = MEDIA_CONFIG.MAX_REEL_BYTES   || (100 * 1024 * 1024);

  /* ============================================================
   * STATE
   * ============================================================ */
  var reelMedia = { type: null, url: '' };
  var publishing = false;
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reel-upload] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }

  /* Bar helpers ------------------------------------------- */
  function showBar() {
    var bar = qs('#reelBar');
    if (bar) bar.classList.remove('hidden');
  }
  function setBarWidth(pct) {
    var bar = qs('#reelBar');
    if (!bar) return;
    var i = bar.querySelector('i');
    if (i) i.style.width = Math.max(0, Math.min(100, pct)) + '%';
  }
  function hideBarLater() {
    var bar = qs('#reelBar');
    if (!bar) return;
    setTimeout(function () {
      bar.classList.add('hidden');
      setBarWidth(0);
    }, 400);
  }
  function setStatus(text) {
    var el = qs('#reelStatus');
    if (el) el.textContent = text || '';
  }

  /* ============================================================
   * RESET
   * ============================================================ */
  function reset() {
    reelMedia = { type: null, url: '' };

    var text = qs('#reelText');
    if (text) text.value = '';

    var prev = qs('#reelPreview');
    if (prev) prev.innerHTML = '';

    setStatus('');
    var bar = qs('#reelBar');
    if (bar) bar.classList.add('hidden');
    setBarWidth(0);

    publishing = false;
    var pub = qs('#reelPublish');
    if (pub) pub.disabled = false;
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openReelUpload() {
    reset();

    var ov = qs('#ovReelUpload');
    if (ov) {
      /* Original raised the overlay's z-index inline so it
       * renders above the reels feed. */
      ov.style.zIndex = '97';
      ov.classList.add('open');
    } else {
      safeCall('openOverlay', ['ovReelUpload']);
    }
    return true;
  }

  /* ============================================================
   * VIDEO PICK — pipeline
   * ============================================================ */
  async function handleVideoPicked(file) {
    if (!file) return false;

    /* 1) Validate type + size ----------------------------- */
    var err = null;
    try {
      if (typeof window.validateVideo === 'function') {
        err = window.validateVideo(file, MAX_REEL_BYTES, MAX_REEL_SECONDS);
      }
    } catch (e) {}
    if (err) { safeToast(err, 'err'); return false; }

    try {
      /* 2) Duration guard ------------------------------- */
      var dur = 0;
      try {
        if (typeof window.probeVideo === 'function') dur = await window.probeVideo(file);
      } catch (e) { dur = 0; }
      if (dur && dur > MAX_REEL_SECONDS) {
        safeToast(T('video_too_long') + ' (' + MAX_REEL_SECONDS + 's)', 'err');
        return false;
      }

      /* 3) Progress + status ---------------------------- */
      showBar();
      setBarWidth(40);
      setStatus(T('uploading'));

      /* 4) Upload --------------------------------------- */
      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(file, 'reel.mp4', function (pct) {
          setBarWidth(pct);
        });
      }
      if (!url) throw new Error(T('upload_failed'));

      /* 5) Store + preview ------------------------------ */
      reelMedia = { type: 'video', url: url };

      var prev = qs('#reelPreview');
      if (prev) {
        prev.innerHTML =
          '<video controls style="width:100%;max-height:16rem;border-radius:.7rem" ' +
                 'src="' + esc(url) + '"></video>';
      }

      setBarWidth(100);
      setStatus('');
      hideBarLater();
      return true;
    } catch (err2) {
      setStatus('');
      var bar2 = qs('#reelBar');
      if (bar2) bar2.classList.add('hidden');
      setBarWidth(0);
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
      return false;
    }
  }

  /* ============================================================
   * PUBLISH
   * ============================================================ */
  async function publish() {
    if (publishing) return false;

    if (!reelMedia.url) {
      safeToast(T('fill_all'), 'err');
      return false;
    }

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) { safeToast(T('error'), 'err'); return false; }

    var textEl = qs('#reelText');
    var text = textEl ? textEl.value.trim() : '';

    publishing = true;
    var btn = qs('#reelPublish');
    if (btn) btn.disabled = true;

    try {
      var me = getMyProfile() || {};

      /* Push the reel node ----------------------------- */
      var ref = fbDb.ref('reels').push();
      await ref.set({
        id: ref.key,
        uid: uid,
        url: reelMedia.url,
        text: text,
        authorName: me.name || '',
        authorPhoto: me.photo || '',
        createdAt: timeNow(),
        views: 0,
        likes: 0
      });

      /* XP + daily stat -------------------------------- */
      safeCall('awardXp', ['post_created', 5]);
      safeCall('bumpDaily', ['reel_create', 1]);

      /* Close + open the feed at the new reel --------- */
      safeCall('closeOverlay', ['ovReelUpload']);

      /* Notify subscribers (additive) ----------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:reel-created', {
          detail: { reelId: ref.key }
        }));
      } catch (e) {}

      safeCall('openReels', [ref.key]);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    } finally {
      publishing = false;
      if (btn) btn.disabled = false;
    }
  }

  /* ============================================================
   * BIND
   * ============================================================ */
  function bind() {
    if (bound) return true;

    /* #reelPick → trigger #reelFile ---------------------- */
    var pick = qs('#reelPick');
    if (pick && pick.dataset.ruBound !== '1') {
      pick.dataset.ruBound = '1';
      pick.addEventListener('click', function () {
        var fi = qs('#reelFile');
        if (fi) fi.click();
      });
    }

    /* #reelFile change ----------------------------------- */
    var file = qs('#reelFile');
    if (file && file.dataset.ruBound !== '1') {
      file.dataset.ruBound = '1';
      file.addEventListener('change', function (e) {
        var f = e.target && e.target.files ? e.target.files[0] : null;
        if (e.target) e.target.value = '';
        if (f) handleVideoPicked(f);
      });
    }

    /* #reelPublish --------------------------------------- */
    var pub = qs('#reelPublish');
    if (pub && pub.dataset.ruBound !== '1') {
      pub.dataset.ruBound = '1';
      pub.addEventListener('click', function () { publish(); });
    }

    bound = true;
    return true;
  }

  function unbind() {
    ['#reelPick', '#reelFile', '#reelPublish'].forEach(function (sel) {
      var n = qs(sel);
      if (!n) return;
      var clone = n.cloneNode(true);
      clone.removeAttribute('data-ru-bound');
      n.parentNode && n.parentNode.replaceChild(clone, n);
    });
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openReelUpload = openReelUpload;

  window.SaikoReelUpload = {
    open: openReelUpload,
    reset: reset,
    bind: bind,
    unbind: unbind,
    handleFile: handleVideoPicked,
    publish: publish,
    getState: function () {
      return {
        media: { type: reelMedia.type, url: reelMedia.url },
        publishing: publishing
      };
    },
    MAX_REEL_SECONDS: MAX_REEL_SECONDS,
    MAX_REEL_BYTES: MAX_REEL_BYTES
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 229 — reel-upload ready');
  } catch (e) {}

})();