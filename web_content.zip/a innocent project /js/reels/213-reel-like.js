/* ============================================================
 * FEATURE:        Reel Like
 * FEATURE NUMBER: 213
 * FILE:           js/reels/213-reel-like.js
 * ACTION:         REPLACE (UI fix for new markup)
 * ============================================================ */

(function () {
  'use strict';

  var likesRef     = null;
  var likesCb      = null;
  var reactionsRef = null;
  var reactionsCb  = null;

  window.reelLikes        = window.reelLikes        || {};
  window.reelReactionsMap = window.reelReactionsMap || {};

  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reel-like] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  function isReelLiked(rid) {
    if (!rid) return false;
    var uid = getMyUid();
    if (!uid) return false;
    var bucket = window.reelLikes[rid];
    return !!(bucket && bucket[uid]);
  }

  function getReelLikeCount(rid) {
    if (!rid) return 0;
    var bucket = window.reelLikes[rid];
    return bucket ? Object.keys(bucket).length : 0;
  }

  function myReaction(rid) {
    if (!rid) return null;
    var uid = getMyUid();
    if (!uid) return null;
    var map = window.reelReactionsMap[rid];
    if (!map || !map[uid]) return null;
    var v = map[uid];
    return (typeof v === 'string') ? v : (v && v.type) || null;
  }

  /* ============================================================
   * REPAINT BUTTONS — new markup aware
   * ============================================================ */
  function updateReelLikeButtons() {
    qsa('#reelsList [data-rellike]').forEach(function (btn) {
      var rid = btn.getAttribute('data-rellike');
      if (!rid) return;

      var liked = isReelLiked(rid);
      btn.classList.toggle('liked', liked);

      /* Icon fill toggle */
      var ic = btn.querySelector('.ic');
      if (ic) ic.classList.toggle('fill', liked);
      var svg = btn.querySelector('svg');
      if (svg) svg.setAttribute('fill', liked ? 'currentColor' : 'none');

      /* Count — target the .cnt span specifically, NOT first span */
      var cnt = btn.querySelector('[data-rellike-count]') || btn.querySelector('.cnt');
      if (cnt) cnt.textContent = String(getReelLikeCount(rid));
    });
  }

  function updateReelReactionBadges() {
    qsa('#reelsList .reel').forEach(function (node) {
      var rid = node.getAttribute('data-reel');
      var likeBtn = node.querySelector('[data-rellike]');
      if (!likeBtn) return;

      var rxType = myReaction(rid);
      var existing = likeBtn.querySelector('.rx-on');

      if (rxType) {
        if (existing) {
          existing.textContent = rxType;
        } else {
          var b = document.createElement('span');
          b.className = 'rx-on';
          b.textContent = rxType;
          likeBtn.appendChild(b);
        }
      } else if (existing) {
        existing.remove();
      }
    });
  }

  /* ============================================================
   * LISTENERS
   * ============================================================ */
  function startReelLikes() {
    var fbDb = getDB();
    if (!fbDb) return false;

    if (!(likesRef && likesCb)) {
      likesRef = fbDb.ref('reelLikes');
      likesCb = likesRef.on('value', function (s) {
        window.reelLikes = s.val() || {};
        if (qs('#ovReels') && qs('#ovReels').classList.contains('open')) {
          updateReelLikeButtons();
        }
      });
    }

    if (!(reactionsRef && reactionsCb)) {
      reactionsRef = fbDb.ref('reelReactions');
      reactionsCb = reactionsRef.on('value', function (s) {
        window.reelReactionsMap = s.val() || {};
        if (qs('#ovReels') && qs('#ovReels').classList.contains('open')) {
          updateReelReactionBadges();
          updateReelLikeButtons();
        }
      });
    }

    return true;
  }

  function detachReelLikes() {
    if (likesRef && likesCb) {
      try { likesRef.off('value', likesCb); } catch (e) {}
    }
    if (reactionsRef && reactionsCb) {
      try { reactionsRef.off('value', reactionsCb); } catch (e) {}
    }
    likesRef = null; likesCb = null;
    reactionsRef = null; reactionsCb = null;
    window.reelLikes = {};
    window.reelReactionsMap = {};
    return true;
  }

  /* ============================================================
   * TOGGLE
   * ============================================================ */
  async function toggleReelLike(rid, forceLike) {
    if (!rid) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var ref = fbDb.ref('reelLikes/' + rid + '/' + uid);

    try {
      var snap = await ref.get();

      if (snap.exists() && !forceLike) {
        await ref.remove();
        fbDb.ref('reels/' + rid + '/likes')
          .transaction(function (c) {
            return Math.max(0, (Number(c) || 0) - 1);
          })
          .catch(function () {});
      } else if (!snap.exists()) {
        await ref.set(true);
        fbDb.ref('reels/' + rid + '/likes')
          .transaction(function (c) {
            return (Number(c) || 0) + 1;
          })
          .catch(function () {});

        safeCall('awardXp', ['like_given', 1]);
        safeCall('bumpDaily', ['reel_like', 1]);
      }

      /* Immediate local repaint (does not wait for listener) */
      updateReelLikeButtons();
      updateReelReactionBadges();

      try {
        window.dispatchEvent(new CustomEvent('saiko:reel-like-changed', {
          detail: { reelId: rid, liked: isReelLiked(rid) }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      return false;
    }
  }

  window.toggleReelLike            = toggleReelLike;
  window.startReelLikes            = startReelLikes;
  window.detachReelLikes           = detachReelLikes;
  window.updateReelLikeButtons     = updateReelLikeButtons;
  window.updateReelReactionBadges  = updateReelReactionBadges;

  window.SaikoReelLike = {
    toggle: toggleReelLike,
    isLiked: isReelLiked,
    getCount: getReelLikeCount,
    myReaction: myReaction,
    startListener: startReelLikes,
    detachListener: detachReelLikes,
    updateButtons: updateReelLikeButtons,
    updateBadges: updateReelReactionBadges
  };

  try { console.debug('[boot] feature 213 — reel-like ready (UI fix)'); } catch (e) {}
})();