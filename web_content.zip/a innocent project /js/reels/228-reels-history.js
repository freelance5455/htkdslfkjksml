/* ============================================================
 * FEATURE:        Reels History
 * FEATURE NUMBER: 228
 * FILE:           js/reels/228-reels-history.js
 * ACTION:         REPLACE (v4 debug)
 * ============================================================ */

(function () {
  'use strict';

  var HISTORY_KEY = 'saiko_reels_history';
  var HISTORY_MAX = 50;
  var _loading = false;

  function log() {
    try {
      var a = ['[history]'].concat(Array.prototype.slice.call(arguments));
      console.log.apply(console, a);
    } catch (e) {}
  }
  function warn() {
    try {
      var a = ['[history]'].concat(Array.prototype.slice.call(arguments));
      console.warn.apply(console, a);
    } catch (e) {}
  }

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(n, f) { try { return window.svgIcon(n, f) || ''; } catch (e) { return ''; } }
  function findUser(uid) {
    try { return window.findUser ? window.findUser(uid) : null; } catch (e) { return null; }
  }
  function timeAgo(ts) { try { return window.timeAgo(ts); } catch (e) { return ''; } }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try { if (typeof window.confirmDialog === 'function') return window.confirmDialog(title, text); } catch (e) {}
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ============================================================
   * STORAGE
   * ============================================================ */
  function readHistory() {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function writeHistory(arr) {
    try { localStorage.setItem(HISTORY_KEY, JSON.stringify((arr || []).slice(0, HISTORY_MAX))); } catch (e) {}
  }
  function getIds() {
    var fromMem = Array.isArray(window.reelsHistory) ? window.reelsHistory : [];
    var fromStorage = readHistory();
    log('getIds — mem:', fromMem.length, 'storage:', fromStorage.length);
    if (fromMem.length) return fromMem.slice();
    return fromStorage;
  }
  function clearReelsHistory() {
    try { localStorage.removeItem(HISTORY_KEY); } catch (e) {}
    window.reelsHistory = [];
    safeToast(T('saved') || 'Cleared', 'ok');
  }
  function removeFromReelsHistory(id) {
    if (!id) return;
    var arr = getIds().filter(function (x) { return x !== id; });
    writeHistory(arr);
    window.reelsHistory = arr;
  }

  /* ============================================================
   * RESOLVE
   * ============================================================ */
  async function resolveReels(ids) {
    var cache = Array.isArray(window.reelsCache) ? window.reelsCache : [];
    log('resolveReels — cache size:', cache.length);

    var byId = {};
    cache.forEach(function (r) { if (r && r.id) byId[r.id] = r; });

    var missing = ids.filter(function (id) { return !byId[id]; });
    log('resolveReels — missing:', missing.length, missing.slice(0, 5));

    var fbDb = getDB();
    log('resolveReels — fbDb:', !!fbDb);

    if (missing.length && fbDb) {
      try {
        var results = await Promise.all(missing.map(function (id) {
          return fbDb.ref('reels/' + id).get()
            .then(function (s) {
              var r = s.val();
              if (r) { r.id = id; return r; }
              return null;
            })
            .catch(function (e) {
              warn('fetch error for', id, e && e.message);
              return null;
            });
        }));
        results.forEach(function (r) {
          if (r) byId[r.id] = r;
        });
      } catch (e) {
        warn('Promise.all failed', e);
      }
    }

    var resolved = [];
    var missingIds = [];
    ids.forEach(function (id) {
      if (byId[id]) resolved.push(byId[id]);
      else missingIds.push(id);
    });

    log('resolveReels — resolved:', resolved.length, 'still missing:', missingIds.length);
    return { list: resolved, missing: missingIds };
  }

  /* ============================================================
   * EMPTY STATE
   * ============================================================ */
  function showEmpty(body, text, hasUnavailable) {
    body.innerHTML =
      '<div class="empty" style="padding:2rem 1rem;text-align:center">' +
        '<span class="ic">' + svgIcon('film') + '</span>' +
        '<p>' + esc(text) + '</p>' +
        (hasUnavailable
          ? '<button class="btn sm ghost" id="cleanReelsHist" style="margin-top:.6rem">Clean unavailable</button>'
          : '') +
      '</div>';

    var cleanBtn = qs('#cleanReelsHist', body);
    if (cleanBtn) cleanBtn.addEventListener('click', function () {
      window.reelsHistory = [];
      writeHistory([]);
      safeToast(T('saved') || 'Cleared', 'ok');
      openReelsHistory();
    });
  }

  /* ============================================================
   * RENDER LIST
   * ============================================================ */
  function renderList(body, list, missingCount) {
    var html =
      '<div class="row" style="justify-content:space-between;padding:0 .2rem .6rem">' +
        '<div class="mini">' + list.length + ' items' +
          (missingCount ? ' · ' + missingCount + ' unavailable' : '') +
        '</div>' +
        '<button class="btn sm ghost" id="clearReelsHistBtn">' + esc(T('clear_all') || 'Clear all') + '</button>' +
      '</div>';

    html += list.map(function (r) {
      var u = findUser(r.uid) || { name: r.authorName || 'User', photo: r.authorPhoto || '' };
      var likes = (window.reelLikes && window.reelLikes[r.id]) ? Object.keys(window.reelLikes[r.id]).length : 0;
      return '<div class="user-card" data-ropen="' + esc(r.id) + '" style="padding:.5rem;display:flex;align-items:center;gap:.6rem">' +
                '<video src="' + esc(r.url) + '" muted playsinline preload="metadata" ' +
               'data-reel-thumb="1" ' +
               'style="width:3.5rem;height:4.5rem;object-fit:cover;border-radius:.5rem;background:#000;flex:0 0 auto;pointer-events:none"></video>' +
        '<div class="grow" style="min-width:0">' +
          '<div class="name">' + esc(u.name) + '</div>' +
          '<div class="muted ellipsis">' + esc(r.text || '') + '</div>' +
          '<div class="mini" style="margin-top:.15rem">❤️ ' + likes + ' · ▶ ' + (r.views || 0) + ' · ' + esc(timeAgo(r.createdAt)) + '</div>' +
        '</div>' +
        '<button class="icon-btn" data-rremove="' + esc(r.id) + '" style="width:1.9rem;height:1.9rem;border-color:transparent;flex:0 0 auto">✕</button>' +
      '</div>';
    }).join('');

    body.innerHTML = html;

    qsa('[data-ropen]', body).forEach(function (n) {
      n.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('[data-rremove]')) return;
        safeCall('closeOverlay', ['ovUserList']);
        safeCall('openReels', [n.getAttribute('data-ropen')]);
      });
    });

    qsa('[data-rremove]', body).forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = b.getAttribute('data-rremove');
        removeFromReelsHistory(id);
        var card = b.closest('.user-card');
        if (card) card.remove();
      });
    });

        var clr = qs('#clearReelsHistBtn', body);
    if (clr) clr.addEventListener('click', async function () {
      var ok = await askConfirm(T('clear_all') || 'Clear all', T('are_you_sure') || 'Are you sure?');
      if (!ok) return;
      clearReelsHistory();
      openReelsHistory();
    });

    /* Thumbnail: seek each video to 0.1s so browser decodes first frame */
    qsa('[data-reel-thumb]', body).forEach(function (v) {
      if (v.dataset.thumbReady === '1') return;
      v.dataset.thumbReady = '1';

      var setFrame = function () {
        try {
          if (v.duration && v.currentTime < 0.05) {
            v.currentTime = 0.1;
          }
        } catch (e) {}
        try { v.pause(); } catch (e) {}
      };

      if (v.readyState >= 1) {
        setFrame();
      } else {
        v.addEventListener('loadedmetadata', setFrame, { once: true });
      }
    });
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  async function openReelsHistory() {
    log('=====================================');
    log('openReelsHistory called');

    var ov = document.getElementById('ovUserList');
    log('ovUserList exists:', !!ov);

    if (!ov) {
      safeToast('History overlay missing', 'err');
      return;
    }

    try {
      if (typeof window.openOverlay === 'function') {
        window.openOverlay('ovUserList');
      } else {
        ov.classList.add('open');
      }
    } catch (e) { warn('openOverlay failed', e); }

    var body = document.getElementById('userListBody');
    var titleEl = document.getElementById('userListTitle');
    log('userListBody exists:', !!body);
    log('userListTitle exists:', !!titleEl);

    if (titleEl) titleEl.textContent = T('reels_history') || 'Reels History';

    if (!body) {
      safeToast('History body missing', 'err');
      return;
    }

    var ids = getIds();
    log('ids count:', ids.length);

    if (!ids.length) {
      showEmpty(body, 'No history yet — watch some reels', false);
      return;
    }

    if (_loading) {
      warn('already loading — abort');
      return;
    }

    _loading = true;
    body.innerHTML =
      '<div style="padding:1.5rem;text-align:center;color:var(--muted)">' +
        'Loading ' + ids.length + ' items...' +
      '</div>';

    try {
      var result = await resolveReels(ids);
      _loading = false;

      /* Cleanup: remove unavailable ids automatically */
      if (result.missing.length) {
        var newIds = ids.filter(function (id) {
          for (var i = 0; i < result.list.length; i++) {
            if (result.list[i].id === id) return true;
          }
          return false;
        });
        window.reelsHistory = newIds;
        writeHistory(newIds);
        log('cleaned up', result.missing.length, 'unavailable items');
      }

      if (!result.list.length) {
        showEmpty(body, 'Reels no longer available', false);
        return;
      }

      renderList(body, result.list, 0);
      log('✓ rendered', result.list.length, 'reels');
    } catch (e) {
      _loading = false;
      warn('open error', e);
      body.innerHTML =
        '<div class="empty" style="padding:2rem;text-align:center">' +
          '<p>Error: ' + esc(e && e.message || 'unknown') + '</p>' +
        '</div>';
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openReelsHistory        = openReelsHistory;
  window.clearReelsHistory       = clearReelsHistory;
  window.removeFromReelsHistory  = removeFromReelsHistory;

  window.SaikoReelsHistory = {
    open: openReelsHistory,
    clear: clearReelsHistory,
    remove: removeFromReelsHistory,
    getIds: getIds,
    debugStatus: function () {
      return {
        memHistory: Array.isArray(window.reelsHistory) ? window.reelsHistory.length : 0,
        storageHistory: readHistory().length,
        cacheSize: Array.isArray(window.reelsCache) ? window.reelsCache.length : 0,
        loading: _loading,
        ovUserListExists: !!document.getElementById('ovUserList'),
        userListBodyExists: !!document.getElementById('userListBody')
      };
    }
  };

  log('✓ feature 228 v4 loaded');
})();