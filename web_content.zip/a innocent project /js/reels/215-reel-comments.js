/* ============================================================
 * FEATURE:        Reel Comments (Split View)
 * FEATURE NUMBER: 215
 * FILE:           js/reels/215-reel-comments.js
 * ACTION:         REPLACE (v3 — syntax fix + pause-only profile-open)
 * ============================================================ */

(function () {
  'use strict';

  var RX = ['❤️', '😂', '😮', '😢', '😡', '👍'];
  var PICKER_Z = '130';
  var MIN_TOP_PCT = 0.25;
  var MAX_TOP_PCT = 0.85;

  window.rsReelId          = null;
  window.rsCommentReactions = window.rsCommentReactions || {};
  window.rsReplyTarget     = null;
  window.reelCommentCounts = window.reelCommentCounts || {};

  var rsCommentListener     = null;
  var rsCommentReactionsRef = null;
  var rsDividerDrag         = null;
  var rsCountsRef           = null;
  var rsCountsCb            = null;

  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function linkifyTags(s) {
    try { if (typeof window.linkifyTags === 'function') return window.linkifyTags(s); }
    catch (e) {}
    return s;
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reel-comments] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function typeOf(v) {
    if (v == null) return null;
    if (typeof v === 'string') return v;
    return v.type || null;
  }
  function isSuspended(obj) {
    try { if (typeof window.isSuspended === 'function') return !!window.isSuspended(obj); }
    catch (e) {}
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > timeNow()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > timeNow();
  }

  /* ============================================================
   * COUNTS LISTENER
   * ============================================================ */
  function startCountsListener() {
    if (rsCountsRef && rsCountsCb) return true;
    var fbDb = getDB();
    if (!fbDb) return false;

    rsCountsRef = fbDb.ref('reelComments');
    rsCountsCb = rsCountsRef.on('value', function (s) {
      var v = s.val() || {};
      var map = {};
      Object.keys(v).forEach(function (rid) {
        var bucket = v[rid] || {};
        map[rid] = Object.keys(bucket).length;
      });
      window.reelCommentCounts = map;

      qsa('[data-relcomment-count]').forEach(function (el) {
        var rid = el.getAttribute('data-relcomment-count');
        el.textContent = String(map[rid] || 0);
      });
    });
    return true;
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openReelSplit(rid) {
    if (!rid) return false;

    var r = null;
    var cache = Array.isArray(window.reelsCache) ? window.reelsCache : [];
    for (var i = 0; i < cache.length; i++) {
      if (cache[i].id === rid) { r = cache[i]; break; }
    }
    if (!r) return false;

    window.rsReelId = rid;
    window.__reelSplitOpen = true;

    safeCall('hardStopReelsPlayback');

    var ov = qs('#ovReelSplit');
    if (ov) {
      ov.classList.add('open');
      ov.classList.remove('video-fs');
      ov.classList.remove('comments-fs');
    }

    var rv = qs('#rsVideo');
    if (rv) {
      if (rv.getAttribute('src') !== r.url) rv.src = r.url;
      rv.muted = false;
      rv.playsInline = true;
    }

    safeCall('stopAllReelsExcept', [rv]);
    safeCall('safePlay', [rv]);

    startCountsListener();
    loadComments(rid);
    attachReactionsListener(rid);

    return true;
  }

  /* ============================================================
   * CLOSE
   * ============================================================ */
  function closeReelSplit() {
    var rv = qs('#rsVideo');
    if (rv) {
      try { rv.pause(); } catch (e) {}
    }

    var ov = qs('#ovReelSplit');
    if (ov) ov.classList.remove('open');

    window.rsReelId = null;
    window.rsCommentReactions = {};
    window.__reelSplitOpen = false;
    window.__reelSplitBackgroundPaused = false;

    if (rsCommentListener) {
      try { rsCommentListener.ref.off('value', rsCommentListener.cb); } catch (e) {}
      rsCommentListener = null;
    }
    if (rsCommentReactionsRef) {
      try { rsCommentReactionsRef.off(); } catch (e) {}
      rsCommentReactionsRef = null;
    }

    if (qs('#ovReels') && qs('#ovReels').classList.contains('open')) {
      setTimeout(function () {
        if (typeof window.tickVisibleReel === 'function') window.tickVisibleReel();
      }, 200);
    }
  }

  /* ============================================================
   * REACTIONS LISTENER
   * ============================================================ */
  function attachReactionsListener(rid) {
    if (rsCommentReactionsRef) {
      try { rsCommentReactionsRef.off(); } catch (e) {}
      rsCommentReactionsRef = null;
    }
    var fbDb = getDB();
    if (!fbDb) return;
    rsCommentReactionsRef = fbDb.ref('reelCommentReactions/' + rid);
    rsCommentReactionsRef.on('value', function (s) {
      window.rsCommentReactions = s.val() || {};
      if (qs('#ovReelSplit') && qs('#ovReelSplit').classList.contains('open')) {
        loadComments(rid);
      }
    });
  }

  /* ============================================================
   * LOAD COMMENTS
   * ============================================================ */
  function loadComments(rid) {
    if (rsCommentListener) {
      try { rsCommentListener.ref.off('value', rsCommentListener.cb); } catch (e) {}
      rsCommentListener = null;
    }

    var box = qs('#rsComments');
    if (box) {
      box.innerHTML =
        '<div class="skeleton" style="height:3rem;margin-bottom:.5rem"></div>' +
        '<div class="skeleton" style="height:3rem;margin-bottom:.5rem"></div>';
    }

    var fbDb = getDB();
    if (!fbDb) return;

    var ref = fbDb.ref('reelComments/' + rid);
    var cb = ref.on('value', function (s) {
      var v = s.val() || {};
      var arr = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      }).filter(function (c) { return !isSuspended(c); });

      var tops = arr.filter(function (c) { return !c.parent; })
                    .sort(function (a, b) {
                      return (b.createdAt || 0) - (a.createdAt || 0);
                    });

      var byP = {};
      arr.filter(function (c) { return c.parent; })
         .forEach(function (c) {
           (byP[c.parent] = byP[c.parent] || []).push(c);
         });

      var boxNow = qs('#rsComments');
      if (!boxNow) return;

      if (!tops.length) {
        boxNow.innerHTML =
          '<div class="empty">' +
            '<span class="ic">' + svgIcon('comment') + '</span>' +
            '<p>' + esc(T('no_posts')) + '</p>' +
          '</div>';
        return;
      }

      boxNow.innerHTML = tops.map(function (c) {
        return commentBlockHTML(rid, c, byP[c.id] || []);
      }).join('');

      qsa('[data-rcreply]', boxNow).forEach(function (n) {
        n.addEventListener('click', function () {
          var cid  = n.getAttribute('data-rcreply');
          var name = n.getAttribute('data-rcname');
          var uid  = n.getAttribute('data-rcuid');
          window.rsReplyTarget = { cid: cid, name: name, uid: uid };
          var inp = qs('#rsCommentInput');
          if (!inp) return;
          var mention = '@' + name + ' ';
          if (inp.value.indexOf(mention) !== 0) {
            inp.value = mention + inp.value.replace(/^@\S+\s+/, '');
          }
          try { inp.focus(); } catch (e) {}
        });
      });

      qsa('[data-rcrx]', boxNow).forEach(function (n) {
        if (n.dataset.rcrxWired === '1') return;
        n.dataset.rcrxWired = '1';
        n.addEventListener('click', function () {
          openCommentReactionPicker(rid, n.getAttribute('data-rcrx'));
        });
      });

      qsa('.cmt-rx[data-crx]', boxNow).forEach(function (n) {
        if (n.dataset.cmtRxWired === '1') return;
        n.dataset.cmtRxWired = '1';
        n.addEventListener('click', async function (e) {
          e.stopPropagation();
          var cid = n.getAttribute('data-cid');
          var rx  = n.getAttribute('data-crx');
          if (!cid) {
            var wrap = n.closest('.comment');
            if (wrap) cid = wrap.getAttribute('data-rcid');
          }
          if (!cid) return;
          await toggleCommentReaction(rid, cid, rx);
        });
      });

      qsa('[data-rcmenu]', boxNow).forEach(function (n) {
        if (n.dataset.rcmenuWired === '1') return;
        n.dataset.rcmenuWired = '1';
        n.addEventListener('click', function (e) {
          e.stopPropagation();
          openCommentMenu(rid, n.getAttribute('data-rcmenu'));
        });
      });

      qsa('[data-rcuid]', boxNow).forEach(function (n) {
        if (n.dataset.rcUserWired === '1') return;
        n.dataset.rcUserWired = '1';
        n.addEventListener('click', function () {
          var uid = n.getAttribute('data-rcuid');
          if (uid && uid !== getMyUid()) {
            var rv = document.getElementById('rsVideo');
            if (rv && !rv.paused) {
              try { rv.pause(); } catch (err) {}
            }
            safeCall('openUserProfile', [uid]);
          }
        });
      });

      qsa('.hashtag', boxNow).forEach(function (n) {
        if (n.dataset.rcHashWired === '1') return;
        n.dataset.rcHashWired = '1';
        n.addEventListener('click', function (e) {
          e.stopPropagation();
          closeReelSplit();
          safeCall('openHashtag', [n.getAttribute('data-tag')]);
        });
      });
    });
    rsCommentListener = { ref: ref, cb: cb };
  }

  /* ============================================================
   * COMMENT BLOCK HTML
   * ============================================================ */
  function commentBlockHTML(rid, c, reps) {
    var u = findUser(c.uid) || { name: c.authorName || 'User', photo: c.authorPhoto || '' };
    var me = getMyUid();
    var mine = (c.uid === me);

    var actions =
      '<div class="cmt-actions">' +
        '<span class="reply-btn" data-rcreply="' + esc(c.id) + '" ' +
              'data-rcname="' + esc(u.name) + '" ' +
              'data-rcuid="' + esc(c.uid) + '">' + esc(T('reply')) + '</span>' +
        '<span class="cmt-react" data-rcrx="' + esc(c.id) + '">😊 React</span>' +
        '<span class="reply-btn" data-rcmenu="' + esc(c.id) + '" ' +
              'style="font-weight:800;letter-spacing:.05em">···</span>' +
      '</div>';

    return '<div class="comment" data-rcid="' + esc(c.id) + '">' +
      '<div data-rcuid="' + esc(c.uid) + '" style="cursor:pointer">' +
        avatarHTML(u.photo, u.name, 'av-32', c.uid) +
      '</div>' +
      '<div class="grow">' +
        '<div class="body">' +
          '<div class="name" style="font-size:.76rem" data-rcuid="' + esc(c.uid) + '">' +
            esc(u.name) + (mine ? ' <span class="mini">(you)</span>' : '') +
          '</div>' +
          '<div class="tx">' + linkifyTags(esc(c.text || '')) + '</div>' +
          '<div class="mini">' + esc(timeAgo(c.createdAt)) + '</div>' +
          actions +
          renderCommentReactions(rid, c.id) +
        '</div>' +
        (reps.length
          ? ('<div class="replies">' + reps.map(function (r) {
              return replyBlockHTML(rid, r);
            }).join('') + '</div>')
          : '') +
      '</div>' +
    '</div>';
  }

  function replyBlockHTML(rid, r) {
    var ru = findUser(r.uid) || { name: r.authorName || 'User', photo: r.authorPhoto || '' };
    var me = getMyUid();
    var mine = (r.uid === me);

    return '<div class="comment" data-rcid="' + esc(r.id) + '">' +
      '<div data-rcuid="' + esc(r.uid) + '" style="cursor:pointer">' +
        avatarHTML(ru.photo, ru.name, 'av-32', r.uid) +
      '</div>' +
      '<div class="grow">' +
        '<div class="body">' +
          '<div class="name" style="font-size:.74rem" data-rcuid="' + esc(r.uid) + '">' +
            esc(ru.name) + (mine ? ' <span class="mini">(you)</span>' : '') +
          '</div>' +
          '<div class="tx">' + linkifyTags(esc(r.text || '')) + '</div>' +
          '<div class="mini">' + esc(timeAgo(r.createdAt)) + '</div>' +
          '<div class="cmt-actions">' +
            '<span class="reply-btn" data-rcreply="' + esc(r.id) + '" ' +
                  'data-rcname="' + esc(ru.name) + '" ' +
                  'data-rcuid="' + esc(r.uid) + '">' + esc(T('reply')) + '</span>' +
            '<span class="cmt-react" data-rcrx="' + esc(r.id) + '">😊 React</span>' +
            '<span class="reply-btn" data-rcmenu="' + esc(r.id) + '" ' +
                  'style="font-weight:800;letter-spacing:.05em">···</span>' +
          '</div>' +
          renderCommentReactions(rid, r.id) +
        '</div>' +
      '</div>' +
    '</div>';
  }

  /* ============================================================
   * RENDER REACTIONS
   * ============================================================ */
  function renderCommentReactions(rid, cid) {
    if (!cid) return '';
    var map = (window.rsCommentReactions && window.rsCommentReactions[cid]) || {};
    var counts = {};
    var keys = Object.keys(map);
    for (var i = 0; i < keys.length; i++) {
      var t = typeOf(map[keys[i]]);
      if (t) counts[t] = (counts[t] || 0) + 1;
    }
    if (!Object.keys(counts).length) return '';

    var uid = getMyUid();
    var mineType = typeOf(map[uid]);

    return '<div class="cmt-rx-row">' + Object.keys(counts).map(function (rx) {
      var isMine = (mineType === rx);
      return '<span class="cmt-rx' + (isMine ? ' mine' : '') + '" ' +
                  'data-crx="' + esc(rx) + '" ' +
                  'data-cid="' + esc(cid) + '">' +
               esc(rx) + ' ' + counts[rx] +
             '</span>';
    }).join('') + '</div>';
  }

  /* ============================================================
   * COMMENT REACTION PICKER
   * ============================================================ */
  function openCommentReactionPicker(rid, cid) {
    if (!rid || !cid) return false;

    var picker = qs('#rxPicker');
    if (!picker) return false;

    var map = (window.rsCommentReactions && window.rsCommentReactions[cid]) || {};
    var uid = getMyUid();
    var mineType = typeOf(map[uid]);

    picker.innerHTML = RX.map(function (r) {
      var isCur = (mineType === r);
      return '<button data-rcrx-pick="' + r + '" style="' +
               (isCur ? 'background:var(--accent-soft);border-radius:.7rem' : '') +
             '">' + r + '</button>';
    }).join('');

    safeCall('openOverlay', ['ovReactions']);
    var ov = qs('#ovReactions');
    if (ov) ov.style.zIndex = PICKER_Z;

    qsa('[data-rcrx-pick]', picker).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovReactions']);
        await toggleCommentReaction(rid, cid, b.getAttribute('data-rcrx-pick'));
      });
    });
    return true;
  }

  /* ============================================================
   * TOGGLE COMMENT REACTION
   * ============================================================ */
  async function toggleCommentReaction(rid, cid, emoji) {
    if (!rid || !cid || !emoji) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    try {
      var ref = fbDb.ref('reelCommentReactions/' + rid + '/' + cid + '/' + uid);
      var snap = await ref.get();
      var curT = typeOf(snap.val());

      if (curT === emoji) {
        await ref.remove();
      } else {
        await ref.set({ type: emoji, at: timeNow() });

        try {
          var cs = await fbDb.ref('reelComments/' + rid + '/' + cid).get();
          var c = cs.val();
          if (c && c.uid && c.uid !== uid) {
            var mp = getMyProfile() || {};
            safeCall('pushNotification', [c.uid, {
              type: 'reaction',
              fromUid: uid,
              fromName: mp.name || '',
              fromPhoto: mp.photo || '',
              text: emoji + ' ' + T('reacted_to'),
              reelId: rid,
              commentId: cid,
              createdAt: timeNow()
            }]);
          }
        } catch (e) {}
      }

      if (!window.rsCommentReactions[cid]) window.rsCommentReactions[cid] = {};
      if (curT === emoji) delete window.rsCommentReactions[cid][uid];
      else window.rsCommentReactions[cid][uid] = emoji;

      loadComments(rid);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * COMMENT MENU
   * ============================================================ */
  async function openCommentMenu(rid, cid) {
    if (!rid || !cid) return false;
    var fbDb = getDB();
    if (!fbDb) return false;

    var snap = await fbDb.ref('reelComments/' + rid + '/' + cid).get();
    var c = snap.val();
    if (!c) { safeToast('Comment not found', 'err'); return false; }

    var uid = getMyUid();
    var mine = (c.uid === uid);
    var items = [];

    if (mine) {
      items.push({ k: 'edit',   i: 'edit',  label: T('edit_comment') || 'Edit comment' });
      items.push({ k: 'delete', i: 'trash', label: T('delete_comment') || 'Delete comment', danger: true });
    } else {
      items.push({ k: 'report', i: 'flag',  label: T('report') || 'Report', danger: true });
      items.push({ k: 'block',  i: 'block', label: T('block') || 'Block user', danger: true });
    }
    items.push({ k: 'copy', i: 'copy', label: T('copy_text') || 'Copy text' });

    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;

    sheet.innerHTML = '<div class="sheet-handle"></div>' + items.map(function (it) {
      return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" data-cm="' + it.k + '">' +
        svgIcon(it.i) + '<span>' + esc(it.label) + '</span>' +
      '</div>';
    }).join('');

    safeCall('openOverlay', ['ovMsgMenu']);

    qsa('[data-cm]', sheet).forEach(function (n) {
      n.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var k = n.getAttribute('data-cm');

        if (k === 'edit') {
          var nt = await safeCall('promptDialog', [T('edit_comment') || 'Edit', c.text || '']);
          if (nt == null) return;
          var txt = String(nt).trim();
          if (!txt) return;
          try {
            await fbDb.ref('reelComments/' + rid + '/' + cid).update({
              text: txt,
              updatedAt: timeNow()
            });
            safeToast(T('saved') || 'Saved', 'ok');
          } catch (e) { safeToast(e.message || T('error'), 'err'); }
        }
        else if (k === 'delete') {
          var ok = await safeCall('confirmDialog', [T('delete_comment') || 'Delete', T('are_you_sure')]);
          if (!ok) return;
          try {
            await fbDb.ref('reelComments/' + rid + '/' + cid).remove();
            await fbDb.ref('reelCommentReactions/' + rid + '/' + cid).remove();
            safeToast(T('saved') || 'Deleted', 'ok');
          } catch (e) { safeToast(e.message || T('error'), 'err'); }
        }
        else if (k === 'report') {
          safeCall('openReport', ['comment', cid, rid]);
        }
        else if (k === 'block') {
          safeCall('blockUser', [c.uid]);
        }
        else if (k === 'copy') {
          try {
            await navigator.clipboard.writeText(c.text || '');
            safeToast(T('copied') || 'Copied', 'ok');
          } catch (e) {
            safeToast(c.text || '');
          }
        }
      });
    });
    return true;
  }

  /* ============================================================
   * SEND COMMENT
   * ============================================================ */
  async function sendComment() {
    var rid = window.rsReelId;
    if (!rid) return false;

    var inp = qs('#rsCommentInput');
    if (!inp) return false;
    var text = (inp.value || '').trim();
    if (!text) return false;
    inp.value = '';

    var parent = window.rsReplyTarget ? window.rsReplyTarget.cid : null;
    var parentUid = window.rsReplyTarget ? window.rsReplyTarget.uid : null;
    var parentName = window.rsReplyTarget ? window.rsReplyTarget.name : '';
    window.rsReplyTarget = null;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    try {
      var ref = fbDb.ref('reelComments/' + rid).push();
      var mp = getMyProfile() || {};

      await ref.set({
        id: ref.key,
        uid: uid,
        authorName: mp.name || '',
        authorPhoto: mp.photo || '',
        text: text,
        parent: parent || null,
        parentUid: parentUid || null,
        createdAt: timeNow()
      });

      var reel = null;
      try {
        var cache = Array.isArray(window.reelsCache) ? window.reelsCache : [];
        for (var i = 0; i < cache.length; i++) {
          if (cache[i].id === rid) { reel = cache[i]; break; }
        }
      } catch (e) {}

      if (reel && reel.uid && reel.uid !== uid) {
        safeCall('pushNotification', [reel.uid, {
          type: parent ? 'reply' : 'comment',
          fromUid: uid,
          fromName: mp.name || '',
          fromPhoto: mp.photo || '',
          text: parent ? T('replied_to') : T('commented_on'),
          reelId: rid,
          parentName: parentName,
          createdAt: timeNow()
        }]);
      }

      if (parentUid && parentUid !== uid && parentUid !== (reel && reel.uid)) {
        safeCall('pushNotification', [parentUid, {
          type: 'reply',
          fromUid: uid,
          fromName: mp.name || '',
          fromPhoto: mp.photo || '',
          text: T('replied_to'),
          reelId: rid,
          parentName: parentName,
          createdAt: timeNow()
        }]);
      }

      safeCall('awardXp', ['comment_made', 2]);
      safeCall('bumpDaily', ['comment', 1]);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * DIVIDER DRAG
   * ============================================================ */
  function onDividerDown(e) {
    if (e && typeof e.preventDefault === 'function') e.preventDefault();
    var top = qs('#rsTop');
    if (!top) return;
    rsDividerDrag = { y: e.clientY, topH: top.getBoundingClientRect().height };
    document.body.style.userSelect = 'none';
  }
  function onDocMove(e) {
    if (!rsDividerDrag) return;
    var ov = qs('#ovReelSplit');
    var top = qs('#rsTop');
    if (!ov || !top) return;
    var total = ov.getBoundingClientRect().height;
    var delta = e.clientY - rsDividerDrag.y;
    var newTop = rsDividerDrag.topH + delta;
    newTop = Math.max(total * MIN_TOP_PCT, Math.min(total * MAX_TOP_PCT, newTop));
    top.style.flex = '0 0 ' + ((newTop / total) * 100) + '%';
  }
  function onDocUp() {
    if (!rsDividerDrag) return;
    rsDividerDrag = null;
    document.body.style.userSelect = '';
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  var bound = false;
  function bind() {
    if (bound) return true;

    var closeBtn = qs('#rsClose');
    if (closeBtn && closeBtn.dataset.rcBound !== '1') {
      closeBtn.dataset.rcBound = '1';
      closeBtn.addEventListener('click', closeReelSplit);
    }

    var vFs = qs('#rsVideoFs');
    if (vFs && vFs.dataset.rcBound !== '1') {
      vFs.dataset.rcBound = '1';
      vFs.addEventListener('click', function () {
        var el = qs('#ovReelSplit');
        if (!el) return;
        if (el.classList.contains('video-fs')) el.classList.remove('video-fs');
        else { el.classList.add('video-fs'); el.classList.remove('comments-fs'); }
      });
    }

    var cFs = qs('#rsCommentsFs');
    if (cFs && cFs.dataset.rcBound !== '1') {
      cFs.dataset.rcBound = '1';
      cFs.addEventListener('click', function () {
        var el = qs('#ovReelSplit');
        if (!el) return;
        if (el.classList.contains('comments-fs')) el.classList.remove('comments-fs');
        else { el.classList.add('comments-fs'); el.classList.remove('video-fs'); }
      });
    }

    var send = qs('#rsSendComment');
    if (send && send.dataset.rcBound !== '1') {
      send.dataset.rcBound = '1';
      send.addEventListener('click', function () { sendComment(); });
    }

    var input = qs('#rsCommentInput');
    if (input && input.dataset.rcBound !== '1') {
      input.dataset.rcBound = '1';
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendComment();
        }
      });
    }

    var divider = qs('#rsDivider');
    if (divider && divider.dataset.rcBound !== '1') {
      divider.dataset.rcBound = '1';
      divider.addEventListener('pointerdown', onDividerDown);
    }

    document.addEventListener('pointermove', onDocMove);
    document.addEventListener('pointerup', onDocUp);

    startCountsListener();

    bound = true;
    return true;
  }

  function unbind() {
    ['#rsClose', '#rsVideoFs', '#rsCommentsFs',
     '#rsSendComment', '#rsCommentInput', '#rsDivider']
      .forEach(function (sel) {
        var n = qs(sel);
        if (!n) return;
        var clone = n.cloneNode(true);
        clone.removeAttribute('data-rc-bound');
        n.parentNode && n.parentNode.replaceChild(clone, n);
      });
    document.removeEventListener('pointermove', onDocMove);
    document.removeEventListener('pointerup', onDocUp);
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openReelSplit                 = openReelSplit;
  window.closeReelSplit                = closeReelSplit;
  window.loadReelSplitComments         = loadComments;
  window.renderReelCommentReactions    = renderCommentReactions;
  window.openReelCommentReactionPicker = openCommentReactionPicker;
  window.toggleReelCommentReaction     = toggleCommentReaction;
  window.openReelCommentMenu           = openCommentMenu;

  window.SaikoReelComments = {
    open: openReelSplit,
    close: closeReelSplit,
    loadComments: loadComments,
    sendComment: sendComment,
    renderReactions: renderCommentReactions,
    openPicker: openCommentReactionPicker,
    toggleReaction: toggleCommentReaction,
    openMenu: openCommentMenu,
    bind: bind,
    unbind: unbind,
    getCurrentId: function () { return window.rsReelId; }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  try {
    console.debug('[boot] feature 215 — reel-comments ready (v3 — no-mute, syntax clean)');
  } catch (e) {}

})();