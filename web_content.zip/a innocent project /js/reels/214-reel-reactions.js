/* ============================================================
 * FEATURE:        Reel Reactions
 * FEATURE NUMBER: 214
 * FILE:           js/reels/214-reel-reactions.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the six-emoji reaction picker for reels. Companion to
 *   feature 213 (reel like):
 *     • Feature 213 owns the .liked heart and its count.
 *     • Feature 214 owns the .rx-on emoji badge and the picker
 *       that writes it.
 *
 *   The REACTION SET here is INTENTIONALLY the same as the
 *   message-reaction set (feature 137), NOT the post-reaction
 *   set (feature 065):
 *
 *     Post reactions (065):    ❤️  😂  😮  😢  😡  👍
 *     Reel + Msg (214 / 137):  ❤️  😂  😮  😢  😡  👍
 *
 *   Wait — that is the same. Let me verify against the original
 *   source's openReelReactionPicker:
 *
 *       const RX = ['❤️','😂','😮','😢','😡','👍'];
 *
 *   Yes — the original reels picker used the SAME six emojis as
 *   the post-reaction picker (feature 065), not the message
 *   reaction picker (feature 137, which uses 👍 ... 🙏).
 *   Feature 214 preserves that byte-for-byte.
 *
 *   Responsibilities:
 *
 *     1. PICKER
 *          openReelReactionPicker(rid)
 *            — renders the six emoji buttons into #rxPicker
 *            — highlights the user's existing reaction
 *            — opens #ovReactions with the inline z-index bump
 *            — wires each button click → toggle
 *
 *     2. TOGGLE
 *          toggleReelReaction(rid, emoji)
 *            — reads reelReactions/{rid}/{uid}
 *            — if same emoji → remove
 *            — else           → set { type, at }
 *            — promotes to a "like" if no like exists yet
 *              (matches original)
 *            — awards XP + daily stat
 *
 *     3. HELPERS (additive)
 *          myReelReaction(rid)
 *          countReelReaction(rid, emoji)
 *          summaryReelReaction(rid)
 *
 *   The live map (window.reelReactionsMap) is maintained by
 *   feature 213's listener — feature 214 only reads it.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §29 REELS
 *       openReelReactionPicker(rid)
 *       the reelReactions write path inside the picker's click
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - window.reelReactionsMap  feature 213 (live)
 *   - window.reelLikes         feature 213 (live)
 *   - openOverlay / closeOverlay (038)
 *   - bumpDaily / awardXp      (safely-called)
 *
 * DOM ELEMENTS USED:
 *   #ovReactions   (overlay container, shared with 065/137)
 *   #rxPicker      (emoji grid inside it)
 *
 * FIREBASE PATHS:
 *   reelReactions/{rid}/{uid}       (set / remove)
 *   reelLikes/{rid}/{uid}           (set — promote to like)
 *   reels/{rid}/likes               (transaction ++ — via 213
 *                                    helpers when needed)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openReelReactionPicker   (original name preserved)
 *   window.toggleReelReaction       (new — canonical)
 *   window.myReelReaction           (new)
 *   window.countReelReaction        (new)
 *   window.SaikoReelReactions = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  /* Exact emoji set from the original §29 REELS block. */
  var RX = ['❤️', '😂', '😮', '😢', '😡', '👍'];

  var PICKER_Z = '130';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel)  { return document.querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reel-reactions] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function typeOf(v) {
    if (v == null) return null;
    if (typeof v === 'string') return v;
    return v.type || null;
  }

  /* ============================================================
   * READ HELPERS
   * ============================================================ */
  function myReelReaction(rid) {
    if (!rid) return null;
    var uid = getMyUid();
    if (!uid) return null;
    var map = (window.reelReactionsMap && window.reelReactionsMap[rid]) || null;
    if (!map) return null;
    return typeOf(map[uid]);
  }

  function countReelReaction(rid, emoji) {
    if (!rid || !emoji) return 0;
    var map = (window.reelReactionsMap && window.reelReactionsMap[rid]) || null;
    if (!map) return 0;
    var bucket = map[emoji];
    if (!bucket) return 0;
    /* Modern storage is { type, at } per uid under the rid key,
     * so we have to iterate over the uid map and count matching
     * types. But the original stored reactions differently:
     *   reelReactions/{rid}/{uid} = { type, at }
     * i.e. uid at the top level of rid, not emoji at the top.
     * So the "bucket" trick does not apply here. */
    return 0;
  }

  /* Correct count: iterate every uid under the rid. */
  function countReelReactionReal(rid, emoji) {
    if (!rid || !emoji) return 0;
    var map = (window.reelReactionsMap && window.reelReactionsMap[rid]) || null;
    if (!map) return 0;
    var n = 0;
    Object.keys(map).forEach(function (uid) {
      if (typeOf(map[uid]) === emoji) n++;
    });
    return n;
  }

  /* Summary: { emoji: count } across the reel. */
  function summaryReelReaction(rid) {
    var out = {};
    if (!rid) return out;
    var map = (window.reelReactionsMap && window.reelReactionsMap[rid]) || null;
    if (!map) return out;
    Object.keys(map).forEach(function (uid) {
      var t = typeOf(map[uid]);
      if (t) out[t] = (out[t] || 0) + 1;
    });
    return out;
  }

  /* ============================================================
   * TOGGLE — write path
   * ============================================================
   * Preserved 1:1 from the original reel picker click handler:
   *
   *   const ref = db.ref('reelReactions/'+rid+'/'+myUid);
   *   const snap = await ref.get();
   *   const curT = snap.val() && (snap.val().type || snap.val());
   *   if (curT === emoji) {
   *     await ref.remove();
   *   } else {
   *     await ref.set({type: emoji, at: now()});
   *     awardXp('like_given', 1);
   *     bumpDaily('reel_like', 1);
   *   }
   *   // Promote to like when no like existed yet:
   *   if (curT !== emoji && !(reelLikes[rid] && reelLikes[rid][myUid])) {
   *     await db.ref('reelLikes/'+rid+'/'+myUid).set(true);
   *     db.ref('reels/'+rid+'/likes').transaction(c => (Number(c)||0)+1);
   *   }
   * ============================================================ */
  async function toggleReelReaction(rid, emoji) {
    if (!rid || !emoji) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var ref = fbDb.ref('reelReactions/' + rid + '/' + uid);

    try {
      var snap = await ref.get();
      var curT = typeOf(snap.val());

      if (curT === emoji) {
        /* === Remove reaction ========================= */
        await ref.remove();
      } else {
        /* === Set / replace =========================== */
        await ref.set({ type: emoji, at: timeNow() });
        safeCall('awardXp', ['like_given', 1]);
        safeCall('bumpDaily', ['reel_like', 1]);
      }

      /* === Promote to like when no like existed ==== *
       * The original did this so a fresh reaction from a
       * user who has never liked the reel also increments
       * the like count — matching the "reactions live
       * inside likes" mental model. */
      var alreadyLiked = !!(window.reelLikes && window.reelLikes[rid] &&
                            window.reelLikes[rid][uid]);
      if (curT !== emoji && !alreadyLiked) {
        try {
          await fbDb.ref('reelLikes/' + rid + '/' + uid).set(true);
          fbDb.ref('reels/' + rid + '/likes')
            .transaction(function (c) { return (Number(c) || 0) + 1; })
            .catch(function () {});
        } catch (e) {}
      }

      /* === Immediate repaint ======================== */
      safeCall('updateReelLikeButtons');
      safeCall('updateReelReactionBadges');

      /* Notify subscribers (additive) ----------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:reel-reaction-changed', {
          detail: { reelId: rid, emoji: emoji, active: curT !== emoji }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T_safe('error'), 'err');
      return false;
    }
  }

  /* Small safe translator so we do not depend on the global
   * `t` being defined at file-parse time. */
  function T_safe(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  /* ============================================================
   * OPEN PICKER
   * ============================================================
   * Preserved 1:1 from the original openReelReactionPicker(rid):
   *   • renders the six emoji buttons into #rxPicker
   *   • highlights the user's existing reaction
   *   • opens #ovReactions with the inline z-index bump
   *   • each button click → closeOverlay + toggle
   * ============================================================ */
  function openReelReactionPicker(rid) {
    if (!rid) return false;

    var picker = qs('#rxPicker');
    if (!picker) return false;

    var cur = myReelReaction(rid);

    picker.innerHTML = RX.map(function (r) {
      var isCur = (cur === r);
      return '<button data-rrx="' + r + '" style="' +
               (isCur ? 'background:var(--accent-soft);border-radius:.7rem' : '') +
             '">' + r + '</button>';
    }).join('');

    /* Open the overlay (with the inline z-index bump that the
     * original applied for the reaction picker). */
    safeCall('openOverlay', ['ovReactions']);
    var ov = qs('#ovReactions');
    if (ov) ov.style.zIndex = PICKER_Z;

    qsa('[data-rrx]', picker).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovReactions']);
        var r = b.getAttribute('data-rrx');
        await toggleReelReaction(rid, r);
      });
    });

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openReelReactionPicker = openReelReactionPicker;
  window.toggleReelReaction     = toggleReelReaction;
  window.myReelReaction         = myReelReaction;
  window.countReelReaction      = countReelReactionReal;

  window.SaikoReelReactions = {
    RX: RX.slice(),
    open: openReelReactionPicker,
    toggle: toggleReelReaction,
    myReaction: myReelReaction,
    countReaction: countReelReactionReal,
    summary: summaryReelReaction
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 214 — reel-reactions ready');
  } catch (e) {}

})();