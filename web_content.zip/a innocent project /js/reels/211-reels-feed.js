/* ============================================================
 * FEATURE:        Reels Feed
 * FEATURE NUMBER: 211
 * FILE:           js/reels/211-reels-feed.js
 * ACTION:         REPLACE (v11 — no-mute fix + pause-respect)
 * ============================================================ */

(function () {
  'use strict';

  var FETCH_LIMIT     = 60;
  var HISTORY_MAX     = 50;
  var DOUBLE_TAP_MS   = 280;
  var LONG_PRESS_MS   = 550;
  var TAP_MOVE_TOL    = 10;
  var HISTORY_KEY     = 'saiko_reels_history';
  var VIEWED_PREFIX   = 'saiko_reel_viewed_';
  var SOUND_KEY       = 'saiko_reels_sound_on';
  var WATCHDOG_MS     = 300;
  var STALL_MS        = 1800;
  var STALL_RECOVER_MS = 250;
  var HYDRATE_RANGE   = 1;

  var reelsRef = null;
  var reelsCb  = null;
  var watchdogTimer = null;

  window.reelsCache        = window.reelsCache || [];
  window.reelsSoundOn      = (function () {
    try { return localStorage.getItem(SOUND_KEY) === '1'; }
    catch (e) { return false; }
  })();
  window.__reelsUserInteracted = false;
  window.reelsActiveVideo  = null;
  window.reelsActiveId     = null;
  window.reelsActiveIndex  = -1;
  window.__userPausedReels = false;
  window.__reelsLastScrollAt = 0;
  window.__reelReportedThisSession = window.__reelReportedThisSession || {};

  window.reelsHistory = window.reelsHistory || (function () {
    try { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]'); }
    catch (e) { return []; }
  })();

  (function trackUserGesture() {
    function mark() { window.__reelsUserInteracted = true; }
    try {
      document.addEventListener('pointerdown', mark, { capture: true, passive: true });
      document.addEventListener('touchstart', mark, { capture: true, passive: true });
      document.addEventListener('keydown', mark, { capture: true, passive: true });
    } catch (e) {}
  })();

  /* ============================================================
   * CSS
   * ============================================================ */
  (function injectReelsCSS() {
    if (document.getElementById('__saiko_reels_v11')) return;
    var s = document.createElement('style');
    s.id = '__saiko_reels_v11';
    s.textContent =
      '.reel-topbar{position:fixed !important;top:0;left:0;right:0;}' +
      '.reel-topbar .sound-toggle{margin-left:auto;}' +
      '.reel-topbar .reels-refresh-btn{' +
        'width:2.4rem;height:2.4rem;border-radius:50%;' +
        'display:flex;align-items:center;justify-content:center;' +
        'border:1.4px solid rgba(255,255,255,.28);color:#fff;' +
        'background:rgba(0,0,0,.28);backdrop-filter:blur(6px);' +
        'font-size:1rem;line-height:1;}' +
      '.reel-topbar .reels-refresh-btn:active{transform:scale(.9);}' +
      '.reel-topbar .reels-refresh-btn.spin .ic{animation:reelSpin .6s linear infinite;}' +
      '.reels-refresh-toast{' +
        'position:fixed;left:50%;top:12%;transform:translateX(-50%);' +
        'background:rgba(0,0,0,.75);color:#fff;padding:.45rem .9rem;' +
        'border-radius:1rem;font-size:.76rem;font-weight:700;z-index:120;' +
        'opacity:0;pointer-events:none;transition:opacity .25s;}' +
      '.reels-refresh-toast.show{opacity:1;}' +
      '.reel-progress{' +
        'height:22px !important;background:transparent !important;' +
        'pointer-events:auto !important;cursor:pointer;' +
        'padding-bottom:6px;display:flex;align-items:flex-end;}' +
      '.reel-progress::before{' +
        'content:"";position:absolute;left:0;right:0;bottom:4px;' +
        'height:3px;background:rgba(255,255,255,.22);border-radius:2px;}' +
      '.reel-progress i{' +
        'position:relative;display:block;height:3px !important;' +
        'background:rgba(255,255,255,.95) !important;width:0;' +
        'border-radius:2px;transition:width .08s linear;margin-bottom:4px;}' +
      '.reel-progress .reel-time{' +
        'position:absolute;right:.7rem;bottom:calc(100% + .1rem);' +
        'font-size:.68rem;font-weight:700;color:#fff;' +
        'background:rgba(0,0,0,.5);padding:.12rem .4rem;' +
        'border-radius:.4rem;font-variant-numeric:tabular-nums;' +
        'pointer-events:none;white-space:nowrap;}' +
      '.reel-progress.dragging i{transition:none !important;}' +
      '.reel-loading{' +
        'position:absolute;inset:0;display:flex;' +
        'align-items:center;justify-content:center;' +
        'background:transparent;z-index:2;pointer-events:none;}' +
      '.reel-loading::after{' +
        'content:"";width:2.4rem;height:2.4rem;border-radius:50%;' +
        'border:2.5px solid rgba(255,255,255,.25);border-top-color:#fff;' +
        'animation:reelSpin .75s linear infinite;}' +
      '.reel-loading.hide{display:none !important;}' +
      '@keyframes reelSpin{to{transform:rotate(360deg);}}' +
      '.reel-side .cnt{font-size:.7rem;font-weight:700;color:#fff;' +
        'text-shadow:0 1px 4px rgba(0,0,0,.75);line-height:1;}' +
      '.reel-side button.saved .cnt{color:#ffd60a;}' +
      '#ovReelShare,#ovReelPicker{background:rgba(0,0,0,.55);}' +
      '.reel-share-selbar{display:flex;gap:.35rem;flex-wrap:wrap;' +
        'padding:.4rem .6rem;border-bottom:1px solid var(--line);' +
        'min-height:2.4rem;align-items:center;}' +
      '.reel-share-userlist{flex:1;overflow-y:auto;padding:.5rem .6rem;}' +
      '.reel-share-item{display:flex;align-items:center;gap:.6rem;' +
        'padding:.55rem .6rem;border-radius:.85rem;border:1px solid var(--line);' +
        'background:var(--card);margin-bottom:.4rem;cursor:pointer;' +
        'user-select:none;transition:border-color .15s,background .15s;}' +
      '.reel-share-item.sel{border-color:var(--accent);' +
        'background:color-mix(in srgb,var(--accent) 10%,var(--card));}' +
      '.reel-share-item .check{width:1.5rem;height:1.5rem;border-radius:50%;' +
        'border:2px solid var(--line);display:flex;align-items:center;' +
        'justify-content:center;flex:0 0 auto;}' +
      '.reel-share-item.sel .check{background:var(--accent);border-color:var(--accent);color:#fff;}' +
      '.reel-share-footer{padding:.5rem .6rem calc(.6rem + env(safe-area-inset-bottom));' +
        'border-top:1px solid var(--line);background:var(--surface);}' +
      '.reel-share-chip{display:inline-flex;align-items:center;gap:.3rem;' +
        'padding:.25rem .55rem;border-radius:1rem;background:var(--accent-soft);' +
        'color:var(--accent);border:1px solid var(--accent-line);' +
        'font-size:.72rem;font-weight:700;}' +
      '.reel-share-chip button{color:inherit;font-size:.9rem;padding:0 .1rem;}';
    (document.head || document.documentElement).appendChild(s);
  })();

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function linkifyTags(s) {
    try { if (typeof window.linkifyTags === 'function') return window.linkifyTags(s); }
    catch (e) {}
    return s;
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function iSaved(rid) {
    try { if (typeof window.iSaved === 'function') return !!window.iSaved(rid); }
    catch (e) {}
    return false;
  }
  function myReactionOn(rid) {
    try {
      if (typeof window.myReactionOn === 'function') return window.myReactionOn(rid);
    } catch (e) {}
    var map = (window.reelReactionsMap && window.reelReactionsMap[rid]) || null;
    if (!map) return null;
    var uid = getMyUid();
    if (!uid || !map[uid]) return null;
    var v = map[uid];
    return (typeof v === 'string') ? v : (v && v.type) || null;
  }
  function reelLikesCount(rid) {
    var map = (window.reelLikes && window.reelLikes[rid]) || null;
    return map ? Object.keys(map).length : 0;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[reels-feed] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function persistHistory() {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(window.reelsHistory.slice(0, HISTORY_MAX)));
    } catch (e) {}
  }
  function wasViewed(rid) {
    try { return !!localStorage.getItem(VIEWED_PREFIX + rid); } catch (e) { return false; }
  }
  function markViewed(rid) {
    try { localStorage.setItem(VIEWED_PREFIX + rid, '1'); } catch (e) {}
  }
  function fmtViews(n) {
    n = Number(n) || 0;
    if (n < 1000) return String(n);
    if (n < 1000000) return (n / 1000).toFixed(n < 10000 ? 1 : 0).replace(/\.0$/, '') + 'K';
    return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }
  function fmtTime(sec) {
    if (!isFinite(sec) || sec < 0) sec = 0;
    sec = Math.floor(sec);
    var m = Math.floor(sec / 60);
    var s = sec % 60;
    return m + ':' + (s < 10 ? '0' : '') + s;
  }
  function persistSound() {
    try { localStorage.setItem(SOUND_KEY, window.reelsSoundOn ? '1' : '0'); } catch (e) {}
  }
  function shuffleArray(arr) {
    var a = (arr || []).slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function getReelById(rid) {
    var cache = window.reelsCache || [];
    for (var i = 0; i < cache.length; i++) {
      if (cache[i].id === rid) return cache[i];
    }
    return null;
  }
  function getReelCount(rid, field) {
    var r = getReelById(rid);
    if (!r) return 0;
    var n = Number(r[field]);
    return isFinite(n) && n > 0 ? Math.floor(n) : 0;
  }
  function bumpReelCounter(rid, field, delta) {
    if (!rid || !field) return;
    var fbDb = getDB();
    if (!fbDb) return;
    var d = Number(delta) || 0;
    if (!d) return;
    fbDb.ref('reels/' + rid + '/' + field)
      .transaction(function (c) {
        var n = (Number(c) || 0) + d;
        return n < 0 ? 0 : n;
      })
      .catch(function () {});
  }

  function recordReelView(rid) {
    if (!rid) return;
    if (!Array.isArray(window.reelsHistory)) window.reelsHistory = [];
    if (!wasViewed(rid)) {
      markViewed(rid);
      var fbDb = getDB();
      if (fbDb) {
        fbDb.ref('reels/' + rid + '/views')
          .transaction(function (c) { return (Number(c) || 0) + 1; })
          .catch(function () {});
      }
      safeCall('bumpDaily', ['reel_watch', 1]);
    }
    if (window.reelsHistory.indexOf(rid) === -1) {
      window.reelsHistory.unshift(rid);
      window.reelsHistory = window.reelsHistory.slice(0, HISTORY_MAX);
      persistHistory();
    } else {
      var idx = window.reelsHistory.indexOf(rid);
      if (idx > 0) {
        window.reelsHistory.splice(idx, 1);
        window.reelsHistory.unshift(rid);
        persistHistory();
      }
    }
  }

  /* ============================================================
   * HYDRATION
   * ============================================================ */
  function hydrateVideo(vid, url) {
    if (!vid || !url) return false;
    if (vid.dataset.hydrated === '1') return false;
    try {
      vid.src = url;
      vid.dataset.hydrated = '1';
      try { vid.load(); } catch (e) {}
      return true;
    } catch (e) {
      return false;
    }
  }

  function dehydrateVideo(vid) {
    if (!vid) return false;
    if (vid.dataset.hydrated !== '1') return false;
    try {
      try { vid.pause(); } catch (e) {}
      vid.removeAttribute('src');
      delete vid.dataset.hydrated;
      try { vid.load(); } catch (e) {}
      return true;
    } catch (e) {
      return false;
    }
  }

  function hydrateNeighbors(activeIdx) {
    var reels = qsa('#reelsList .reel');
    for (var i = 0; i < reels.length; i++) {
      var vid = reels[i].querySelector('video');
      if (!vid) continue;
      var url = vid.getAttribute('data-src');
      var near = Math.abs(i - activeIdx) <= HYDRATE_RANGE;
      if (near) hydrateVideo(vid, url);
      else dehydrateVideo(vid);
    }
  }

  /* ============================================================
   * SOUND
   * ============================================================ */
  function updateSoundIcons() {
    var on = !!window.reelsSoundOn;
    var topBtn = qs('#reelSoundToggle');
    if (topBtn) {
      topBtn.classList.toggle('on', on);
      topBtn.innerHTML = on
        ? '<span class="ic" style="width:1.2rem;height:1.2rem;display:block">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M11 5 6 9H2v6h4l5 4z"/>' +
              '<path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>' +
            '</svg>' +
          '</span>'
        : '<span class="ic" style="width:1.2rem;height:1.2rem;display:block">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M11 5 6 9H2v6h4l5 4z"/>' +
              '<path d="m22 9-6 6M16 9l6 6"/>' +
            '</svg>' +
          '</span>';
    }
    qsa('.reel-sound-hint').forEach(function (h) {
      var v = window.reelsActiveVideo;
      var isPlaying = v && !v.paused && v.readyState >= 3;
      var shouldShow = on && v && v.muted && isPlaying;
      h.classList.toggle('show', shouldShow);
    });
  }

  function setSoundOn(on) {
    window.reelsSoundOn = !!on;
    persistSound();
    var v = window.reelsActiveVideo;
    if (v && v.isConnected) {
      try { v.muted = !on; } catch (e) {}
      if (on && v.paused && !window.__userPausedReels) {
        try {
          var p = v.play();
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
      }
    }
    updateSoundIcons();
  }

  /* ============================================================
   * PLAYBACK
   * ============================================================ */
  function hideLoading(reel) {
    if (!reel) return;
    var l = reel.querySelector('.reel-loading');
    if (l) l.classList.add('hide');
  }
  function showLoading(reel) {
    if (!reel) return;
    var l = reel.querySelector('.reel-loading');
    if (l) l.classList.remove('hide');
  }
  function hidePlayIcon(reel) {
    if (!reel) return;
    var pp = reel.querySelector('.reel-play');
    if (pp) pp.classList.remove('show');
  }

  function tryAutoplay(vid, reel) {
    if (!vid || !vid.isConnected) return;
    if (vid.dataset.hydrated !== '1') return;

    var wantSound = !!window.reelsSoundOn;
    var canUnmute = wantSound && window.__reelsUserInteracted;

    if (!vid.paused && vid.readyState >= 2) {
      try { vid.muted = !canUnmute; } catch (e) {}
      hideLoading(reel);
      hidePlayIcon(reel);
      updateSoundIcons();
      return;
    }

    try { vid.muted = true; } catch (e) {}

    var p = null;
    try { p = vid.play(); } catch (e) { p = null; }

    if (p && p.then) {
      p.then(function () {
        if (window.reelsActiveVideo !== vid) return;
        if (canUnmute) {
          try { vid.muted = false; } catch (e) {}
        }
        hideLoading(reel);
        hidePlayIcon(reel);
        updateSoundIcons();
      }).catch(function (err) {
        if (err && err.name === 'AbortError') return;
        if (window.reelsActiveVideo !== vid) return;
        try { vid.muted = true; } catch (e) {}
        var p2 = null;
        try { p2 = vid.play(); } catch (e) { p2 = null; }
        if (p2 && p2.catch) p2.catch(function () {});
      });
    } else {
      hideLoading(reel);
      hidePlayIcon(reel);
      if (canUnmute) {
        setTimeout(function () {
          if (window.reelsActiveVideo !== vid) return;
          try { vid.muted = false; } catch (e) {}
          updateSoundIcons();
        }, 120);
      }
    }
  }

  function recoverStalledVideo(vid, reel) {
    if (!vid || !vid.isConnected) return;
    if (window.reelsActiveVideo !== vid) return;
    if (vid.dataset.hydrated !== '1') return;

    var now = Date.now();
    if (vid.__lastRecoverAt && now - vid.__lastRecoverAt < 1200) return;
    vid.__lastRecoverAt = now;

    var resumeTime = vid.currentTime;
    try { vid.pause(); } catch (e) {}

    setTimeout(function () {
      if (window.reelsActiveVideo !== vid) return;
      if (!vid.isConnected) return;

      try {
        vid.removeAttribute('src');
        delete vid.dataset.hydrated;
        vid.load();
      } catch (e) {}

      var url = vid.getAttribute('data-src');
      if (url) {
        try {
          vid.src = url;
          vid.dataset.hydrated = '1';
          vid.load();
        } catch (e) {}
      }

      setTimeout(function () {
        if (window.reelsActiveVideo !== vid) return;
        try {
          if (isFinite(resumeTime) && resumeTime > 0.1 && Math.abs(vid.currentTime - resumeTime) > 0.5) {
            vid.currentTime = resumeTime;
          }
        } catch (e) {}
        try {
          var p = vid.play();
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
        vid.__stallSince = null;
        vid.__lastCT = null;
      }, 120);
    }, STALL_RECOVER_MS);
  }

  function startWatchdog() {
    if (watchdogTimer) return;
    watchdogTimer = setInterval(function () {
      if (window.__reelSplitOpen) return;
      if (window.__reelsBackgroundPaused) return;
      var feed = qs('#ovReels');
      if (!feed || !feed.classList.contains('open')) return;

      tickVisibleReel();

      var vid = window.reelsActiveVideo;
      if (vid && vid.isConnected && !window.__userPausedReels) {
        if (vid.dataset.hydrated !== '1') {
          var url = vid.getAttribute('data-src');
          if (url) {
            hydrateVideo(vid, url);
            tryAutoplay(vid, vid.closest('.reel'));
          }
          return;
        }

        if (vid.paused && vid.readyState >= 2) {
          tryAutoplay(vid, vid.closest('.reel'));
        }
        if (!vid.paused) {
          var now = Date.now();
          var ct = vid.currentTime;
          if (vid.__lastCT === ct) {
            if (!vid.__stallSince) vid.__stallSince = now;
            if (now - vid.__stallSince > STALL_MS) {
              recoverStalledVideo(vid, vid.closest('.reel'));
            }
          } else {
            vid.__lastCT = ct;
            vid.__stallSince = null;
          }
        } else {
          vid.__stallSince = null;
          vid.__lastCT = null;
        }
      }
    }, WATCHDOG_MS);
  }

  function stopWatchdog() {
    if (watchdogTimer) {
      clearInterval(watchdogTimer);
      watchdogTimer = null;
    }
  }

  function stopAllReelsExcept(activeVideo) {
    qsa('#reelsList video').forEach(function (v) {
      if (v === activeVideo) return;
      try { v.pause(); } catch (e) {}
    });
  }

  function hardStopReelsPlayback() {
    qsa('#reelsList video').forEach(function (v) {
      try { v.pause(); } catch (e) {}
    });
    window.reelsActiveVideo = null;
    window.reelsActiveId    = null;
    window.reelsActiveIndex = -1;
    window.__userPausedReels = false;
  }

  function tickVisibleReel() {
    if (window.__reelSplitOpen) return;
    var feed = qs('#ovReels');
    if (!feed || !feed.classList.contains('open')) return;

    var reels = qsa('#reelsList .reel');
    if (!reels.length) return;

    var vh = window.innerHeight || 0;
    var best = null;
    var bestIdx = -1;
    var bestRatio = 0;

    for (var i = 0; i < reels.length; i++) {
      var rect = reels[i].getBoundingClientRect();
      var visH = Math.min(rect.bottom, vh) - Math.max(rect.top, 0);
      var ratio = visH / Math.max(1, rect.height);
      if (ratio > bestRatio) { bestRatio = ratio; best = reels[i]; bestIdx = i; }
    }

    if (!best || bestRatio < 0.4) return;

    var vid = best.querySelector('video');
    if (!vid) return;
    var rid = best.getAttribute('data-reel');

    if (window.reelsActiveVideo === vid) {
      hydrateNeighbors(bestIdx);
      if (window.__reelsBackgroundPaused) {
        if (!vid.paused) {
          try { vid.pause(); } catch (e) {}
        }
        return;
      }
      if (!vid.paused && vid.readyState >= 3) {
        hideLoading(best);
        hidePlayIcon(best);
      } else if (!window.__userPausedReels) {
        showLoading(best);
        if (vid.dataset.hydrated !== '1') {
          var u = vid.getAttribute('data-src');
          if (u) hydrateVideo(vid, u);
        }
        tryAutoplay(vid, best);
      }
      return;
    }

    window.__userPausedReels = false;
    stopAllReelsExcept(vid);
    window.reelsActiveVideo = vid;
    window.reelsActiveId    = rid;
    window.reelsActiveIndex = bestIdx;

    vid.__stallSince = null;
    vid.__lastCT = null;
    vid.__lastRecoverAt = 0;

    hydrateNeighbors(bestIdx);

    showLoading(best);
    hidePlayIcon(best);
    tryAutoplay(vid, best);
    recordReelView(rid);
  }

  var scrollTickTimer = null;
  function onReelsScroll() {
    window.__reelsLastScrollAt = Date.now();
    if (scrollTickTimer) return;
    scrollTickTimer = setTimeout(function () {
      scrollTickTimer = null;
      tickVisibleReel();
    }, 60);
  }

  /* ============================================================
   * FIREBASE LISTENER
   * ============================================================ */
  function startReels() {
    if (reelsRef && reelsCb) return true;
    var fbDb = getDB();
    if (!fbDb) return false;

    reelsRef = fbDb.ref('reels').orderByChild('createdAt').limitToLast(FETCH_LIMIT);

    reelsCb = reelsRef.on('value', function (s) {
      var v = s.val() || {};
      var fetched = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      }).sort(function (a, b) {
        return (b.createdAt || 0) - (a.createdAt || 0);
      });

      if (window.reelsCache && window.reelsCache.length === fetched.length) {
        var existingIds = window.reelsCache.map(function (r) { return r.id; });
        var newIds = fetched.map(function (r) { return r.id; });
        var sameSet = existingIds.every(function (id) { return newIds.indexOf(id) !== -1; });
        if (sameSet) {
          var byId = {};
          fetched.forEach(function (r) { byId[r.id] = r; });
          window.reelsCache = existingIds.map(function (id) { return byId[id]; });
          return;
        }
      }

      window.reelsCache = fetched;

      if (qs('#ovReels') && qs('#ovReels').classList.contains('open')) {
        renderReelsIncremental();
      }
    });
    return true;
  }

  function detachReels() {
    if (reelsRef && reelsCb) {
      try { reelsRef.off('value', reelsCb); } catch (e) {}
    }
    hardStopReelsPlayback();
    stopWatchdog();
    reelsRef = null;
    reelsCb  = null;
    return true;
  }

  /* ============================================================
   * OPEN / CLOSE
   * ============================================================ */
  function openReels(highlightId) {
    safeCall('openOverlay', ['ovReels']);
    window.__reelSplitOpen = false;
    window.__userPausedReels = false;

    if (window.reelsCache.length > 1 && !highlightId) {
      window.reelsCache = shuffleArray(window.reelsCache);
    }

    var list = qs('#reelsList');
    if (list && !list.querySelector('.reel')) {
      list.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#fff;padding:2rem">' +
          '<div class="spinner" style="border-color:rgba(255,255,255,.2);border-top-color:#fff"></div>' +
        '</div>';
    }

    startReels();

    var feed = qs('#ovReels');
    if (feed && feed.dataset.tickBound !== '1') {
      feed.dataset.tickBound = '1';
      feed.addEventListener('scroll', onReelsScroll, { passive: true });
    }

    ensureRefreshButton();
    updateSoundIcons();
    startWatchdog();

    if (highlightId && !getReelById(highlightId)) {
      var fbDb = getDB();
      if (fbDb) {
        fbDb.ref('reels/' + highlightId).get().then(function (s) {
          var r = s.val();
          if (r) {
            r.id = highlightId;
            window.reelsCache = [r].concat(window.reelsCache);
          }
          doRender(highlightId);
        }).catch(function () { doRender(highlightId); });
      } else {
        doRender(highlightId);
      }
    } else {
      doRender(highlightId);
    }

    function doRender(hid) {
      setTimeout(function () { renderReelsIncremental(hid); }, 40);
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        if (window.reelsCache.length) {
          renderReelsIncremental(hid);
          clearInterval(iv);
        } else if (tries > 20) {
          clearInterval(iv);
        }
      }, 150);
    }
  }

  function closeReels() {
    hardStopReelsPlayback();
    stopWatchdog();
    var ov = qs('#ovReels');
    if (ov) ov.classList.remove('open');
  }

  function refreshReels(showFeedback) {
    if (!window.reelsCache || window.reelsCache.length < 2) return false;
    hardStopReelsPlayback();
    window.reelsCache = shuffleArray(window.reelsCache);
    var list = qs('#reelsList');
    if (list) list.innerHTML = '';
    renderReelsIncremental();
    var feed = qs('#ovReels');
    if (feed) { try { feed.scrollTop = 0; } catch (e) {} }
    if (showFeedback !== false) showRefreshToast('Reels refreshed');
    return true;
  }

  function showRefreshToast(msg) {
    var el = qs('#__reelsRefreshToast');
    if (!el) {
      el = document.createElement('div');
      el.id = '__reelsRefreshToast';
      el.className = 'reels-refresh-toast';
      document.body.appendChild(el);
    }
    el.textContent = msg || 'Refreshed';
    el.classList.add('show');
    clearTimeout(showRefreshToast._t);
    showRefreshToast._t = setTimeout(function () { el.classList.remove('show'); }, 1200);
  }

  function ensureRefreshButton() {
    var topbar = qs('#ovReels .reel-topbar');
    if (!topbar) return;

    if (!qs('#reelSoundToggle')) {
      var sBtn = document.createElement('button');
      sBtn.className = 'icon-btn sound-toggle';
      sBtn.id = 'reelSoundToggle';
      sBtn.setAttribute('aria-label', 'Sound');
      topbar.appendChild(sBtn);
      sBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        setSoundOn(!window.reelsSoundOn);
      });
    }

    if (!qs('#reelsRefresh')) {
      var rBtn = document.createElement('button');
      rBtn.className = 'icon-btn reels-refresh-btn';
      rBtn.id = 'reelsRefresh';
      rBtn.setAttribute('aria-label', 'Refresh');
      rBtn.innerHTML =
        '<span class="ic" style="width:1.1rem;height:1.1rem;display:block">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
            '<path d="M21 12a9 9 0 1 1-2.6-6.4M21 3v6h-6"/>' +
          '</svg>' +
        '</span>';
      var soundBtn = qs('#reelSoundToggle');
      if (soundBtn) topbar.insertBefore(rBtn, soundBtn);
      else topbar.appendChild(rBtn);
      rBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        rBtn.classList.add('spin');
        refreshReels(true);
        setTimeout(function () { rBtn.classList.remove('spin'); }, 700);
      });
    }
  }

  /* ============================================================
   * RENDER
   * ============================================================ */
  function renderReelsIncremental(highlightId) {
    var list = qs('#reelsList');
    if (!list) return;

    if (!window.reelsCache.length) {
      list.innerHTML =
        '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#fff;padding:2rem;text-align:center">' +
          '<div><div style="font-size:2.5rem;margin-bottom:.6rem">🎬</div>' +
            '<div style="font-weight:700">' + esc(T('no_reels') || 'No reels yet') + '</div></div>' +
        '</div>';
      return;
    }

    var existingIds = qsa('.reel', list).map(function (n) { return n.getAttribute('data-reel'); });
    var same = existingIds.length === window.reelsCache.length &&
      existingIds.every(function (id, i) { return id === window.reelsCache[i].id; });

    if (same) {
      updateReelButtonsInPlace();
      setTimeout(tickVisibleReel, 30);
      return;
    }

    hardStopReelsPlayback();
    var me = getMyUid();

    list.innerHTML = window.reelsCache.map(function (r) {
      var u = findUser(r.uid) || {
        name: r.authorName || 'User',
        photo: r.authorPhoto || ''
      };
      var liked = !!(window.reelLikes && window.reelLikes[r.id] && window.reelLikes[r.id][me]);
      var rx = myReactionOn(r.id);
      var rxBadge = rx ? '<span class="rx-on">' + esc(rx) + '</span>' : '';
      var likesCount = reelLikesCount(r.id);
      var commentCount = (window.reelCommentCounts && window.reelCommentCounts[r.id]) || 0;
      var shareCount   = getReelCount(r.id, 'shares');
      var saveCount    = getReelCount(r.id, 'saves');
      var collectCount = getReelCount(r.id, 'collects');
      var reportCount  = getReelCount(r.id, 'reports');
      var savedCls = iSaved(r.id) ? ' saved' : '';
      var views = Number(r.views) || 0;
      var isMine = (r.uid === me);
      var caption = r.text || '';

      return '<div class="reel" data-reel="' + esc(r.id) + '">' +
        '<video data-src="' + esc(r.url) + '" playsinline loop preload="none" muted></video>' +
        '<div class="reel-progress" data-rseek="' + esc(r.id) + '">' +
          '<i></i>' +
          '<span class="reel-time">' +
            '<span class="reel-time-cur">0:00</span> / <span class="reel-time-total">0:00</span>' +
          '</span>' +
        '</div>' +
        '<div class="reel-loading"></div>' +
        '<div class="reel-play">' + svgIcon('play') + '</div>' +
        '<div class="reel-heart">❤️</div>' +
        '<div class="reel-sound-hint">🔊 Tap for sound</div>' +

        '<div class="reel-side">' +
          '<button data-rellike="' + esc(r.id) + '" class="' + (liked ? 'liked' : '') + '">' +
            '<span class="ic' + (liked ? ' fill' : '') + '">' +
              '<svg viewBox="0 0 24 24" fill="' + (liked ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M20.8 5.6a5 5 0 0 0-7.1 0L12 7.3l-1.7-1.7a5 5 0 1 0-7.1 7.1l8.8 8.8 8.8-8.8a5 5 0 0 0 0-7.1z"/>' +
              '</svg>' +
            '</span>' +
            '<span class="cnt" data-rellike-count="' + esc(r.id) + '">' + likesCount + '</span>' +
            rxBadge +
          '</button>' +

          '<button data-relcomments="' + esc(r.id) + '">' +
            '<span class="ic">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/>' +
              '</svg>' +
            '</span>' +
            '<span class="cnt" data-relcomment-count="' + esc(r.id) + '">' + commentCount + '</span>' +
          '</button>' +

          '<button data-relshare="' + esc(r.id) + '">' +
            '<span class="ic">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>' +
              '</svg>' +
            '</span>' +
            '<span class="cnt" data-relshare-count="' + esc(r.id) + '">' + shareCount + '</span>' +
          '</button>' +

          '<button data-relsave="' + esc(r.id) + '" class="' + savedCls.trim() + '">' +
            '<span class="ic' + (savedCls ? ' fill' : '') + '">' +
              '<svg viewBox="0 0 24 24" fill="' + (savedCls ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"/>' +
              '</svg>' +
            '</span>' +
            '<span class="cnt" data-relsave-count="' + esc(r.id) + '">' + saveCount + '</span>' +
          '</button>' +

          '<button data-relcollection="' + esc(r.id) + '">' +
            '<span class="ic">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>' +
              '</svg>' +
            '</span>' +
            '<span class="cnt" data-relcollect-count="' + esc(r.id) + '">' + collectCount + '</span>' +
          '</button>' +

          (isMine
            ? '<button data-relmenu="' + esc(r.id) + '">' +
                '<span class="ic">' +
                  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                    '<circle cx="12" cy="5" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="12" cy="19" r="1.2"/>' +
                  '</svg>' +
                '</span></button>'
            : '<button data-relreport="' + esc(r.id) + '">' +
                '<span class="ic">' +
                  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
                    '<path d="M4 15V3h13l-2 5 2 5H4zM4 21v-6"/>' +
                  '</svg>' +
                '</span>' +
                '<span class="cnt" data-relreport-count="' + esc(r.id) + '">' + reportCount + '</span>' +
              '</button>'
          ) +
        '</div>' +

        '<div class="reel-bottom">' +
          '<div class="who" data-relowner="' + esc(r.uid) + '">' +
            avatarHTML(u.photo, u.name, 'av-32', r.uid) +
            '<span>' + esc(u.name) + '</span>' +
            (isMine ? '' : '<span class="reel-follow-chip" data-ropen-profile="' + esc(r.uid) + '">Open</span>') +
          '</div>' +
          (caption ? '<div class="desc" data-reldesc>' + linkifyTags(esc(caption)) + '</div>' : '') +
          '<div class="reel-meta-row">' +
            '<span class="reel-views">' +
              '<span class="ic" style="width:.85rem;height:.85rem;display:inline-flex;vertical-align:middle">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
                  '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>' +
                '</svg>' +
              '</span>' +
              ' ' + fmtViews(views) + ' views' +
            '</span>' +
          '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    qsa('.reel', list).forEach(wireReelGestures);

    setTimeout(tickVisibleReel, 30);
    setTimeout(tickVisibleReel, 200);
    setTimeout(tickVisibleReel, 600);

    if (highlightId) {
      var node = list.querySelector('.reel[data-reel="' + highlightId + '"]');
      if (node) {
        setTimeout(function () {
          try { node.scrollIntoView({ behavior: 'auto', block: 'start' }); }
          catch (e) {}
          setTimeout(tickVisibleReel, 80);
        }, 60);
      }
    }
  }

  function updateReelButtonsInPlace() {
    var me = getMyUid();
    qsa('#reelsList .reel').forEach(function (node) {
      var rid = node.getAttribute('data-reel');
      if (!rid) return;

      var likeBtn = node.querySelector('[data-rellike]');
      if (likeBtn) {
        var liked = !!(window.reelLikes && window.reelLikes[rid] && window.reelLikes[rid][me]);
        likeBtn.classList.toggle('liked', liked);
        var ic = likeBtn.querySelector('.ic');
        if (ic) ic.classList.toggle('fill', liked);
        var svg = likeBtn.querySelector('svg');
        if (svg) svg.setAttribute('fill', liked ? 'currentColor' : 'none');
        var cnt = likeBtn.querySelector('[data-rellike-count]');
        if (cnt) cnt.textContent = reelLikesCount(rid);
        var rxType = myReactionOn(rid);
        var rxEl = likeBtn.querySelector('.rx-on');
        if (rxType) {
          if (!rxEl) {
            rxEl = document.createElement('span');
            rxEl.className = 'rx-on';
            likeBtn.appendChild(rxEl);
          }
          rxEl.textContent = rxType;
        } else if (rxEl) { rxEl.remove(); }
      }

      var cmtCnt = node.querySelector('[data-relcomment-count]');
      if (cmtCnt) cmtCnt.textContent = String((window.reelCommentCounts && window.reelCommentCounts[rid]) || 0);

      var shrCnt = node.querySelector('[data-relshare-count]');
      if (shrCnt) shrCnt.textContent = String(getReelCount(rid, 'shares'));

      var saveBtn = node.querySelector('[data-relsave]');
      if (saveBtn) {
        var saved = iSaved(rid);
        saveBtn.classList.toggle('saved', saved);
        var sic = saveBtn.querySelector('.ic');
        if (sic) sic.classList.toggle('fill', saved);
        var ssvg = saveBtn.querySelector('svg');
        if (ssvg) ssvg.setAttribute('fill', saved ? 'currentColor' : 'none');
      }
      var svCnt = node.querySelector('[data-relsave-count]');
      if (svCnt) svCnt.textContent = String(getReelCount(rid, 'saves'));

      var clCnt = node.querySelector('[data-relcollect-count]');
      if (clCnt) clCnt.textContent = String(getReelCount(rid, 'collects'));

      var rpCnt = node.querySelector('[data-relreport-count]');
      if (rpCnt) rpCnt.textContent = String(getReelCount(rid, 'reports'));
    });
  }

  /* ============================================================
   * ACTION HANDLERS
   * ============================================================ */
  function handleShare(rid) {
    if (typeof window.openReelShareDialog === 'function') {
      window.openReelShareDialog(rid);
      return;
    }
  }

  function handleSaveToggle(rid) {
    var wasSaved = iSaved(rid);
    safeCall('toggleSave', [rid]);
    bumpReelCounter(rid, 'saves', wasSaved ? -1 : 1);
    setTimeout(updateReelButtonsInPlace, 250);
  }
  function handleCollect(rid) {
    safeCall('addReelToCollection', [rid]);
    bumpReelCounter(rid, 'collects', 1);
  }
  function handleReport(rid) {
    var flag = window.__reelReportedThisSession || (window.__reelReportedThisSession = {});
    if (!flag[rid]) {
      flag[rid] = true;
      bumpReelCounter(rid, 'reports', 1);
    }
    safeCall('openReport', ['reel', rid, null]);
  }

  /* ============================================================
   * GESTURES
   * ============================================================ */
  function wireReelGestures(el) {
    var rid = el.getAttribute('data-reel');
    var vid = el.querySelector('video');
    var pp = el.querySelector('.reel-play');
    var heartEl = el.querySelector('.reel-heart');
    var progBar = el.querySelector('.reel-progress i');
    var progWrap = el.querySelector('.reel-progress');
    var timeCur = el.querySelector('.reel-time-cur');
    var timeTot = el.querySelector('.reel-time-total');

    var tapTimer = null;
    var lastTap = 0;
    var longPressTimer = null;
    var suppressTap = false;
    var tapStartX = 0;
    var tapStartY = 0;

    var doSingle = function () {
      if (!vid) return;
      stopAllReelsExcept(vid);
      window.reelsActiveVideo = vid;
      window.reelsActiveId = rid;

      if (vid.paused) {
        window.__userPausedReels = false;
        if (vid.dataset.hydrated !== '1') {
          var u = vid.getAttribute('data-src');
          if (u) hydrateVideo(vid, u);
        }
        tryAutoplay(vid, el);
        if (pp) pp.classList.remove('show');
      } else {
        window.__userPausedReels = true;
        try { vid.pause(); } catch (e) {}
        if (pp) pp.classList.add('show');
      }
    };

    var doDouble = function () {
      if (heartEl) {
        heartEl.classList.remove('burst');
        void heartEl.offsetWidth;
        heartEl.classList.add('burst');
      }
      safeCall('toggleReelLike', [rid, true]);
      setTimeout(updateReelButtonsInPlace, 250);
    };

    var doLongPress = function () {
      try { if (navigator.vibrate) navigator.vibrate(15); } catch (e) {}
      safeCall('openReelReactionPicker', [rid]);
    };

    var onPointerDown = function (e) {
      if (e.target.closest('.reel-side') ||
          e.target.closest('.reel-bottom') ||
          e.target.closest('.reel-topbar') ||
          e.target.closest('.reel-progress')) {
        suppressTap = true;
        if (longPressTimer) clearTimeout(longPressTimer);
        longPressTimer = null;
        return;
      }
      suppressTap = false;
      tapStartX = e.clientX || 0;
      tapStartY = e.clientY || 0;

      longPressTimer = setTimeout(function () {
        suppressTap = true;
        doLongPress();
      }, LONG_PRESS_MS);
    };

    var onPointerMove = function (e) {
      var dx = Math.abs((e.clientX || 0) - tapStartX);
      var dy = Math.abs((e.clientY || 0) - tapStartY);
      if (dx > TAP_MOVE_TOL || dy > TAP_MOVE_TOL) {
        suppressTap = true;
        if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
      }
    };

    var onPointerUp = function () {
      if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
      if (Date.now() - (window.__reelsLastScrollAt || 0) < 300) {
        suppressTap = false;
        return;
      }
      if (suppressTap) { suppressTap = false; return; }

      var t2 = Date.now();
      if (t2 - lastTap < DOUBLE_TAP_MS) {
        if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; }
        lastTap = 0;
        doDouble();
      } else {
        lastTap = t2;
        if (tapTimer) clearTimeout(tapTimer);
        tapTimer = setTimeout(function () {
          doSingle();
          tapTimer = null;
        }, DOUBLE_TAP_MS);
      }
    };

    el.addEventListener('pointerdown', onPointerDown);
    el.addEventListener('pointermove', onPointerMove);
    el.addEventListener('pointerup', onPointerUp);
    el.addEventListener('pointercancel', function () {
      if (longPressTimer) clearTimeout(longPressTimer);
      if (tapTimer) clearTimeout(tapTimer);
      suppressTap = false;
    });

    if (vid && progBar) {
      vid.addEventListener('loadedmetadata', function () {
        if (timeTot) timeTot.textContent = fmtTime(vid.duration);
      });
      vid.addEventListener('timeupdate', function () {
        if (!vid.duration) return;
        progBar.style.width = Math.min(100, (vid.currentTime / vid.duration) * 100) + '%';
        if (timeCur) timeCur.textContent = fmtTime(vid.currentTime);
      });
      vid.addEventListener('ended', function () {
        progBar.style.width = '0%';
        if (timeCur) timeCur.textContent = '0:00';
      });
      vid.addEventListener('waiting', function () {
        if (window.reelsActiveVideo === vid) showLoading(el);
      });
      vid.addEventListener('playing', function () {
        hideLoading(el);
        hidePlayIcon(el);
        if (window.reelsActiveVideo === vid) recordReelView(rid);
      });
      vid.addEventListener('canplay', function () {
        if (timeTot && vid.duration) timeTot.textContent = fmtTime(vid.duration);
      });
      vid.addEventListener('pause', function () {
        if (window.__userPausedReels && window.reelsActiveVideo === vid) {
          if (pp) pp.classList.add('show');
        }
      });
    }

    if (progWrap && vid) {
      var isDragging = false;
      var seekTo = function (clientX) {
        var rect = progWrap.getBoundingClientRect();
        var x = clientX - rect.left;
        var pct = Math.max(0, Math.min(1, x / Math.max(1, rect.width)));
        if (vid.duration && isFinite(vid.duration)) {
          try { vid.currentTime = pct * vid.duration; } catch (e) {}
          progBar.style.width = (pct * 100) + '%';
          if (timeCur) timeCur.textContent = fmtTime(pct * vid.duration);
        }
      };

      progWrap.addEventListener('pointerdown', function (e) {
        e.stopPropagation(); e.preventDefault();
        isDragging = true;
        progWrap.classList.add('dragging');
        seekTo(e.clientX || (e.touches && e.touches[0].clientX) || 0);
      });
      progWrap.addEventListener('pointermove', function (e) {
        if (!isDragging) return;
        seekTo(e.clientX || (e.touches && e.touches[0].clientX) || 0);
      });
      var endDrag = function () {
        if (!isDragging) return;
        isDragging = false;
        progWrap.classList.remove('dragging');
        if (vid.paused && !window.__userPausedReels) tryAutoplay(vid, el);
      };
      progWrap.addEventListener('pointerup', endDrag);
      progWrap.addEventListener('pointercancel', endDrag);
      progWrap.addEventListener('pointerleave', endDrag);
      progWrap.addEventListener('click', function (e) { e.stopPropagation(); });
    }

    var likeBtn = el.querySelector('[data-rellike]');
    if (likeBtn) {
      var lpTimer = null, lpFired = false;
      likeBtn.addEventListener('pointerdown', function (e) {
        e.stopPropagation();
        lpFired = false;
        lpTimer = setTimeout(function () {
          lpFired = true;
          safeCall('openReelReactionPicker', [rid]);
          try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}
        }, 500);
      });
      likeBtn.addEventListener('pointerup', function (e) {
        e.stopPropagation();
        if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; }
        if (lpFired) return;
        safeCall('toggleReelLike', [rid]);
        setTimeout(updateReelButtonsInPlace, 250);
      });
      likeBtn.addEventListener('pointerleave', function () {
        if (lpTimer) { clearTimeout(lpTimer); lpTimer = null; }
      });
      likeBtn.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        safeCall('openReelReactionPicker', [rid]);
      });
    }

    var cmt = el.querySelector('[data-relcomments]');
    if (cmt) cmt.addEventListener('click', function (e) {
      e.stopPropagation();
      safeCall('openReelSplit', [rid]);
    });
    var saveBtn = el.querySelector('[data-relsave]');
    if (saveBtn) saveBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      handleSaveToggle(rid);
    });
    var colBtn = el.querySelector('[data-relcollection]');
    if (colBtn) colBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      handleCollect(rid);
    });
    var shrBtn = el.querySelector('[data-relshare]');
    if (shrBtn) shrBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      handleShare(rid);
    });
    var repBtn = el.querySelector('[data-relreport]');
    if (repBtn) repBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      handleReport(rid);
    });
    var menuBtn = el.querySelector('[data-relmenu]');
    if (menuBtn) menuBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      openReelOwnerMenu(rid);
    });

    var ownerEl = el.querySelector('[data-relowner]');
    if (ownerEl) ownerEl.addEventListener('click', function (e) {
      e.stopPropagation();
      var uid = ownerEl.getAttribute('data-relowner');
      if (uid && uid !== getMyUid()) {
        var rv = window.reelsActiveVideo;
        if (rv && !rv.paused) {
          try { rv.pause(); } catch (err) {}
          window.__reelsBackgroundPaused = true;
        }
        safeCall('openUserProfile', [uid]);
      }
    });

    var openChip = el.querySelector('[data-ropen-profile]');
    if (openChip) openChip.addEventListener('click', function (e) {
      e.stopPropagation();
      var uid = openChip.getAttribute('data-ropen-profile');
      if (uid && uid !== getMyUid()) {
        var rv2 = window.reelsActiveVideo;
        if (rv2 && !rv2.paused) {
          try { rv2.pause(); } catch (err) {}
          window.__reelsBackgroundPaused = true;
        }
        safeCall('openUserProfile', [uid]);
      }
    });

    var hint = el.querySelector('.reel-sound-hint');
    if (hint) {
      hint.style.pointerEvents = 'auto';
      hint.addEventListener('click', function (e) {
        e.stopPropagation();
        setSoundOn(true);
      });
    }

    var descEl = el.querySelector('.desc');
    if (descEl) qsa('.hashtag', descEl).forEach(function (n) {
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        closeReels();
        safeCall('openHashtag', [n.getAttribute('data-tag')]);
      });
    });
  }

  /* ============================================================
   * OWNER MENU
   * ============================================================ */
  async function openReelOwnerMenu(rid) {
    var r = getReelById(rid);
    if (!r) return;

    var items = [
      { k: 'edit',   i: 'edit',  label: T('edit_reel') || 'Edit reel' },
      { k: 'copy',   i: 'copy',  label: T('copy_caption') || 'Copy caption' },
      { k: 'delete', i: 'trash', label: T('delete_reel') || 'Delete reel', danger: true }
    ];

    var sheet = qs('#msgMenuSheet');
    if (!sheet) return;

    sheet.innerHTML = '<div class="sheet-handle"></div>' + items.map(function (it) {
      return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" data-rm="' + it.k + '">' +
        svgIcon(it.i) + '<span>' + esc(it.label) + '</span>' +
      '</div>';
    }).join('');

    safeCall('openOverlay', ['ovMsgMenu']);

    qsa('[data-rm]', sheet).forEach(function (n) {
      n.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var k = n.getAttribute('data-rm');
        var fbDb = getDB();
        if (!fbDb) return;

        if (k === 'edit') {
          var nt = await safeCall('promptDialog', [T('reel_caption') || 'Caption', r.text || '']);
          if (nt == null) return;
          try { await fbDb.ref('reels/' + rid + '/text').set(String(nt).trim()); } catch (e) {}
        } else if (k === 'copy') {
          try { await navigator.clipboard.writeText(r.text || ''); safeToast(T('copied') || 'Copied', 'ok'); } catch (e) {}
        } else if (k === 'delete') {
          var ok = await safeCall('confirmDialog', [T('delete_reel') || 'Delete reel', T('are_you_sure')]);
          if (!ok) return;
          try { await fbDb.ref('reels/' + rid).remove(); } catch (e) {}
        }
      });
    });
  }

  /* ============================================================
   * SHARE DIALOG
   * ============================================================ */
  function openReelShareDialog(rid) {
    var r = getReelById(rid);
    if (!r) return false;

    var old = qs('#ovReelShare');
    if (old) old.remove();

    var ov = document.createElement('div');
    ov.className = 'overlay open';
    ov.id = 'ovReelShare';
    ov.style.zIndex = '200';
    ov.innerHTML =
      '<div class="sheet">' +
        '<div class="sheet-handle"></div>' +
        '<div style="padding:.4rem .6rem .7rem;font-weight:800;font-size:.95rem">Share Reel</div>' +
        '<div class="sheet-item" data-reelshr="story">' +
          '<span class="ic" style="color:var(--accent)">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>' +
            '</svg>' +
          '</span>' +
          '<span>Add to My Story</span>' +
        '</div>' +
        '<div class="sheet-item" data-reelshr="send">' +
          '<span class="ic" style="color:var(--accent)">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>' +
            '</svg>' +
          '</span>' +
          '<span>Send to Users</span>' +
        '</div>' +
      '</div>';

    document.body.appendChild(ov);

    ov.addEventListener('click', function (e) {
      if (e.target === ov) ov.remove();
    });

    qsa('[data-reelshr]', ov).forEach(function (n) {
      n.addEventListener('click', async function () {
        var k = n.getAttribute('data-reelshr');
        ov.remove();
        if (k === 'story') {
          await publishReelAsStory(rid);
        } else if (k === 'send') {
          openReelRecipientPicker(rid);
        }
      });
    });

    return true;
  }

  /* ============================================================
   * ADD TO MY STORY
   * ============================================================ */
  async function publishReelAsStory(rid) {
    var r = getReelById(rid);
    if (!r) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) { safeToast('Login required', 'err'); return false; }

    var privacy = 'public';
    try { if (window.prefs && window.prefs.storyPrivacy) privacy = window.prefs.storyPrivacy; } catch (e) {}

    try {
      var ref = fbDb.ref('stories/' + uid).push();
      await ref.set({
        id: ref.key,
        uid: uid,
        kind: 'normal',
        text: r.text || '',
        type: 'video',
        url: r.url || '',
        privacy: privacy,
        createdAt: timeNow(),
        views: {}
      });
      safeToast('Added to your story', 'ok');
      try {
        window.dispatchEvent(new CustomEvent('saiko:story-created', {
          detail: { storyId: ref.key, source: 'reel-share' }
        }));
      } catch (e) {}
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : 'Failed to add story', 'err');
      return false;
    }
  }

  /* ============================================================
   * SEND TO USERS
   * ============================================================ */
  function openReelRecipientPicker(rid) {
    var r = getReelById(rid);
    if (!r) return false;

    var old = qs('#ovReelPicker');
    if (old) old.remove();

    var selected = {};
    var me = getMyUid();

    var ov = document.createElement('div');
    ov.className = 'overlay open';
    ov.id = 'ovReelPicker';
    ov.style.zIndex = '200';
    ov.style.display = 'flex';
    ov.style.flexDirection = 'column';
    ov.innerHTML =
      '<div class="ov-head" style="flex:0 0 auto">' +
        '<button class="icon-btn" id="rpsClose">←</button>' +
        '<div class="ov-title">Send Reel</div>' +
      '</div>' +
      '<div style="flex:0 0 auto;padding:.5rem .6rem .3rem">' +
        '<div class="searchbar" style="margin-bottom:.4rem">' +
          '<span class="ic">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
              '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>' +
            '</svg>' +
          '</span>' +
          '<input type="search" id="rpsSearch" placeholder="Search users...">' +
        '</div>' +
      '</div>' +
      '<div class="reel-share-selbar" id="rpsSelBar" style="flex:0 0 auto"></div>' +
      '<div class="reel-share-userlist" id="rpsList" style="flex:1 1 auto"></div>' +
      '<div class="reel-share-footer" style="flex:0 0 auto">' +
        '<button class="btn solid block" id="rpsSend" disabled>Send</button>' +
      '</div>';

    document.body.appendChild(ov);

    var selBar = qs('#rpsSelBar', ov);
    var listEl = qs('#rpsList', ov);
    var searchEl = qs('#rpsSearch', ov);
    var sendBtn = qs('#rpsSend', ov);

    function close() { try { ov.remove(); } catch (e) {} }
    qs('#rpsClose', ov).addEventListener('click', close);

    function userRow(u) {
      var isSel = !!selected[u.uid];
      return '<div class="reel-share-item' + (isSel ? ' sel' : '') + '" data-uid="' + esc(u.uid) + '">' +
        avatarHTML(u.photo, u.name, 'av-40', u.uid) +
        '<div class="grow" style="min-width:0">' +
          '<div style="font-weight:700;font-size:.88rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' +
            esc(u.name || 'User') +
          '</div>' +
        '</div>' +
        '<div class="check">' + (isSel
          ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m20 6-11 11-5-5"/></svg>'
          : '') + '</div>' +
      '</div>';
    }

    function renderList(q) {
      var users = Array.isArray(window.allUsersCache) ? window.allUsersCache : [];
      var ql = (q || '').trim().toLowerCase();
      var filtered = users.filter(function (u) {
        if (!u || !u.uid || u.uid === me) return false;
        if (!ql) return true;
        return ((u.name || '') + ' ' + (u.searchName || '') + ' ' + (u.username || ''))
          .toLowerCase().indexOf(ql) !== -1;
      }).slice(0, 100);

      if (!filtered.length) {
        listEl.innerHTML =
          '<div class="empty" style="padding:2rem 1rem;text-align:center;color:var(--muted)">' +
            '<p>' + esc(ql ? 'No users found' : 'Type to search users') + '</p>' +
          '</div>';
        return;
      }

      listEl.innerHTML = filtered.map(userRow).join('');
      qsa('[data-uid]', listEl).forEach(function (n) {
        n.addEventListener('click', function () {
          var uid = n.getAttribute('data-uid');
          if (!uid) return;
          if (selected[uid]) delete selected[uid];
          else selected[uid] = true;
          renderSelBar();
          renderList(searchEl.value);
          updateSendBtn();
        });
      });
    }

    function renderSelBar() {
      var uids = Object.keys(selected);
      if (!uids.length) {
        selBar.innerHTML = '<div class="mini" style="color:var(--muted);font-size:.75rem">No recipients selected</div>';
        return;
      }
      selBar.innerHTML = uids.map(function (uid) {
        var u = findUser(uid) || { name: 'User' };
        return '<span class="reel-share-chip">' +
          esc(u.name || 'User') +
          '<button type="button" data-rpsrm="' + esc(uid) + '">×</button>' +
        '</span>';
      }).join('');
      qsa('[data-rpsrm]', selBar).forEach(function (b) {
        b.addEventListener('click', function () {
          var uid = b.getAttribute('data-rpsrm');
          if (selected[uid]) {
            delete selected[uid];
            renderSelBar();
            renderList(searchEl.value);
            updateSendBtn();
          }
        });
      });
    }

    function updateSendBtn() {
      var n = Object.keys(selected).length;
      if (n > 0) {
        sendBtn.disabled = false;
        sendBtn.textContent = 'Send (' + n + ')';
      } else {
        sendBtn.disabled = true;
        sendBtn.textContent = 'Send';
      }
    }

    var searchTimer = null;
    searchEl.addEventListener('input', function () {
      if (searchTimer) clearTimeout(searchTimer);
      searchTimer = setTimeout(function () {
        searchTimer = null;
        renderList(searchEl.value);
      }, 140);
    });

    var sending = false;
    sendBtn.addEventListener('click', async function () {
      if (sending) return;
      var uids = Object.keys(selected);
      if (!uids.length) return;
      sending = true;
      sendBtn.disabled = true;
      sendBtn.textContent = 'Sending...';

      var okCount = 0;
      for (var i = 0; i < uids.length; i++) {
        var toUid = uids[i];
        var ok = await sendReelToUser(rid, toUid);
        if (ok) okCount++;
      }

      sending = false;
      if (okCount > 0) {
        safeToast('Sent to ' + okCount + ' user' + (okCount === 1 ? '' : 's'), 'ok');
        close();
      } else {
        safeToast('Failed to send', 'err');
        sendBtn.disabled = false;
        sendBtn.textContent = 'Send (' + uids.length + ')';
      }
    });

    renderSelBar();
    updateSendBtn();

    if (!Array.isArray(window.allUsersCache) || !window.allUsersCache.length) {
      listEl.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--muted)">Loading users...</div>';
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        if (Array.isArray(window.allUsersCache) && window.allUsersCache.length) {
          clearInterval(iv);
          renderList(searchEl.value);
        } else if (tries > 30) {
          clearInterval(iv);
          listEl.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--muted)">No users available</div>';
        }
      }, 200);
    } else {
      renderList('');
    }

    return true;
  }

  async function sendReelToUser(rid, toUid) {
    if (!rid || !toUid) return false;
    var r = getReelById(rid);
    if (!r) return false;
    var uid = getMyUid();
    var fbDb = getDB();
    var me = getMyProfile() || {};
    if (!uid || !fbDb) return false;

    try {
      var chatId = await safeCall('ensureDirectChat', [toUid]);
      if (!chatId) return false;

      var ref = fbDb.ref('messages/' + chatId).push();
      var readBy = {}; readBy[uid] = true;
      await ref.set({
        id: ref.key,
        from: uid,
        fromName: me.name || '',
        fromPhoto: me.photo || '',
        type: 'reel',
        reelId: rid,
        url: r.url || '',
        text: (r.text || '').slice(0, 120),
        createdAt: timeNow(),
        readBy: readBy
      });

      safeCall('updateChatMeta', [chatId, '🎬 Reel']);
      safeCall('pushNotification', [toUid, {
        type: 'message',
        fromUid: uid,
        fromName: me.name || '',
        fromPhoto: me.photo || '',
        text: 'Shared a reel',
        chatId: chatId,
        createdAt: timeNow()
      }]);
      bumpReelCounter(rid, 'shares', 1);
      return true;
    } catch (e) {
      console.warn('[reel-share] send failed', e);
      return false;
    }
  }

  /* ============================================================
   * BIND
   * ============================================================ */
  var bound = false;
  function bind() {
    if (bound) return true;

    var closeBtn = qs('#reelsClose');
    if (closeBtn && closeBtn.dataset.reelsFeedBound !== '1') {
      closeBtn.dataset.reelsFeedBound = '1';
      closeBtn.addEventListener('click', closeReels);
    }

    var histBtn = qs('#reelsHistory');
    if (histBtn && histBtn.dataset.reelsFeedBound !== '1') {
      histBtn.dataset.reelsFeedBound = '1';
      histBtn.addEventListener('click', function () {
        safeCall('openReelsHistory');
      });
    }

    var upBtn = qs('#reelsUpload');
    if (upBtn && upBtn.dataset.reelsFeedBound !== '1') {
      upBtn.dataset.reelsFeedBound = '1';
      upBtn.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation();
        hardStopReelsPlayback();
        safeCall('openReelUpload');
      });
    }

    if (document.body && document.body.dataset.reelsVisBound !== '1') {
      document.body.dataset.reelsVisBound = '1';
      document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
          if (window.reelsActiveVideo && !window.reelsActiveVideo.paused) {
            try { window.reelsActiveVideo.pause(); } catch (e) {}
          }
          return;
        }
        var feed = qs('#ovReels');
        if (!feed || !feed.classList.contains('open')) return;
        if (window.__userPausedReels) return;
        if (window.__reelsBackgroundPaused) return;
        if (window.reelsActiveVideo && window.reelsActiveVideo.paused) {
          tryAutoplay(window.reelsActiveVideo, window.reelsActiveVideo.closest('.reel'));
        } else {
          tickVisibleReel();
        }
      });
    }

    ensureRefreshButton();
    updateSoundIcons();

    bound = true;
    return true;
  }

  function unbind() {
    ['#reelsClose', '#reelsHistory', '#reelsUpload'].forEach(function (sel) {
      var n = qs(sel);
      if (!n) return;
      var clone = n.cloneNode(true);
      clone.removeAttribute('data-reels-feed-bound');
      n.parentNode && n.parentNode.replaceChild(clone, n);
    });
    var feed = qs('#ovReels');
    if (feed) {
      feed.removeEventListener('scroll', onReelsScroll);
      delete feed.dataset.tickBound;
    }
    stopWatchdog();
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startReels              = startReels;
  window.detachReels             = detachReels;
  window.openReels               = openReels;
  window.closeReels              = closeReels;
  window.refreshReels            = refreshReels;
  window.renderReelsIncremental  = renderReelsIncremental;
  window.stopAllReelsExcept      = stopAllReelsExcept;
  window.hardStopReelsPlayback   = hardStopReelsPlayback;
  window.tickVisibleReel         = tickVisibleReel;
  window.setReelsSound           = setSoundOn;
  window.updateReelButtonsInPlace = updateReelButtonsInPlace;
  window.openReelShareDialog     = openReelShareDialog;
  window.publishReelAsStory      = publishReelAsStory;
  window.openReelRecipientPicker = openReelRecipientPicker;
  window.sendReelToUser          = sendReelToUser;

  window.SaikoReelsFeed = {
    start: startReels,
    detach: detachReels,
    open: openReels,
    close: closeReels,
    refresh: refreshReels,
    render: renderReelsIncremental,
    stopAllExcept: stopAllReelsExcept,
    hardStop: hardStopReelsPlayback,
    tick: tickVisibleReel,
    setSound: setSoundOn,
    refreshButtons: updateReelButtonsInPlace,
    shuffle: refreshReels,
    bind: bind,
    unbind: unbind,
    openShareDialog: openReelShareDialog,
    addToStory: publishReelAsStory,
    openRecipientPicker: openReelRecipientPicker,
    sendToUser: sendReelToUser,
    hydrateNeighbors: hydrateNeighbors,
    getCache: function () { return window.reelsCache; },
    getActiveId: function () { return window.reelsActiveId; },
    isSoundOn: function () { return !!window.reelsSoundOn; },
    isUserPaused: function () { return !!window.__userPausedReels; },
    FETCH_LIMIT: FETCH_LIMIT,
    HISTORY_MAX: HISTORY_MAX
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }
  setTimeout(bind, 800);

  try {
    console.debug('[boot] feature 211 — reels-feed ready (v11 — no-mute, pause-respect)');
  } catch (e) {}

})();