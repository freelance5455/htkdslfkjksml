/* ============================================================
 * FEATURE:        Story Viewer
 * FEATURE NUMBER: 189
 * FILE:           js/stories/189-story-viewer.js
 * ACTION:         REPLACE (v2 — sound persist + swipe + heart long-press + viewer reactions)
 * ============================================================ */

(function () {
  'use strict';

  var PROGRESS_DEFAULT_MS = 5000;
  var SOUND_KEY = 'saiko_story_sound_on';

  window.storyQueue          = window.storyQueue || [];
  window.storyUserQueue      = window.storyUserQueue || [];
  window.storyUserIdx        = window.storyUserIdx || 0;
  window.storyIndex          = window.storyIndex || 0;
  window.currentStoryKey     = window.currentStoryKey || null;
  window.storyProgressPaused = false;
  window.storyPausedElapsed  = 0;
  window.storyPausedStart    = 0;
  window.storyMedia          = window.storyMedia || { type: null, url: '' };

  /* v2 — persist sound preference */
  window.storySoundOn = (function () {
    try { return localStorage.getItem(SOUND_KEY) === '1'; }
    catch (e) { return false; }
  })();

  var storyTimer = null;
  var gestureBound = false;

  function qs(sel)  { return document.querySelector(sel); }
  function qsa(sel) { return Array.prototype.slice.call(document.querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-viewer] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function getCache() {
    try { return window.storiesCache || {}; } catch (e) { return {}; }
  }

  function persistSound() {
    try { localStorage.setItem(SOUND_KEY, window.storySoundOn ? '1' : '0'); }
    catch (e) {}
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openStoriesForUser(uid) {
    if (!uid) return false;

    /* v2 — disable legacy swipe handler to avoid conflicts */
    try {
      if (window.SaikoStorySwipe && typeof window.SaikoStorySwipe.unbind === 'function') {
        window.SaikoStorySwipe.unbind();
      }
    } catch (e) {}

    var list = getCache()[uid];
    if (!list || !list.length) {
      safeToast(T('no_stories'));
      return false;
    }

    var order = [uid];
    Object.keys(getCache()).forEach(function (u) {
      if (u === uid) return;
      var items = getCache()[u];
      if (items && items.length) order.push(u);
    });

    window.storyUserQueue = order;
    window.storyUserIdx   = 0;
    window.storyQueue     = list.slice();
    window.storyIndex     = 0;
    window.currentStoryKey     = null;
    window.storyProgressPaused = false;
    window.storyPausedElapsed  = 0;
    window.storyPausedStart    = 0;

        if (typeof window.openOverlay === 'function') {
      window.openOverlay('ovStoryViewer');
    } else {
      var ov = qs('#ovStoryViewer');
      if (ov) ov.classList.add('open');
    }

    var sheet = qs('#storyViewersSheet');
    if (sheet) sheet.classList.remove('open');

    buildStoryProgress();
    showStoryAt(0);
    bindAllGestures();
    return true;
  }

    /* Open a specific user's story and jump to a specific story id */
  function openStoryAt(uid, storyId) {
    if (!uid || !storyId) return false;

    var list = getCache()[uid] || [];
    var idx = -1;
    for (var i = 0; i < list.length; i++) {
      if (list[i].id === storyId) { idx = i; break; }
    }

    if (idx === -1) {
      /* Story expired or not loaded — fall back to first available story */
      if (list.length) {
        openStoriesForUser(uid);
        return true;
      }
      safeToast(T('no_stories') || 'Story unavailable');
      return false;
    }

    openStoriesForUser(uid);
    if (idx > 0) {
      setTimeout(function () {
        if (window.currentStoryKey && window.currentStoryKey.indexOf(uid + '/') === 0) {
          showStoryAt(idx);
        }
      }, 40);
    }
    return true;
  }

  /* ============================================================
   * PROGRESS BARS
   * ============================================================ */
  function buildStoryProgress() {
    var p = qs('#storyProgress');
    if (!p) return false;
    p.innerHTML = window.storyQueue.map(function (_, i) {
      var style = (i === 0) ? ' style="width:0"' : '';
      return '<i><b' + style + '></b></i>';
    }).join('');
    return true;
  }

  /* ============================================================
   * PREV STORY (for tap / swipe)
   * ============================================================ */
  function prevStory() {
    if (window.storyIndex > 0) {
      showStoryAt(window.storyIndex - 1);
      return;
    }
    /* Previous user */
    var prevIdx = window.storyUserIdx - 1;
    var cache = getCache();
    if (prevIdx >= 0 && cache[window.storyUserQueue[prevIdx]] && cache[window.storyUserQueue[prevIdx]].length) {
      window.storyUserIdx = prevIdx;
      window.storyQueue = cache[window.storyUserQueue[prevIdx]].slice();
      window.storyIndex = window.storyQueue.length - 1;
      buildStoryProgress();
      showStoryAt(window.storyIndex);
    }
    /* Else: no previous, do nothing */
  }

  /* ============================================================
   * SEND STORY REACTION
   * ============================================================ */
  async function sendStoryReaction(sUid, sId, emoji) {
    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;
    if (!sUid || !sId || !emoji) return false;
    if (sUid === me) return false;

    try {
      await fbDb.ref('storyReactions/' + sUid + '/' + sId + '/' + me)
        .set({ type: emoji, at: timeNow() });

      var storyObj = (getCache()[sUid] || []).find(function (x) { return x.id === sId; });
      var thumb = (storyObj && storyObj.type === 'image') ? storyObj.url : '';
      var mp = getMyProfile() || {};

      safeCall('pushNotification', [sUid, {
        type: 'reaction',
        fromUid: me,
        fromName: mp.name || '',
        fromPhoto: mp.photo || '',
        text: emoji + ' · ' + (T('story_reacted') || 'reacted to your story'),
        storyUid: sUid,
        storyId: sId,
        storyThumb: thumb,
        createdAt: timeNow()
      }]);

      safeCall('bumpDaily', ['story_react', 1]);
      safeToast(T('story_reacted') || 'Reaction sent', 'ok');
      return true;
    } catch (e) {
      safeToast((e && e.message) ? e.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * SHOW STORY AT INDEX
   * ============================================================ */
  function showStoryAt(i) {
    if (i < 0 || i >= window.storyQueue.length) {
      var nextIdx = window.storyUserIdx + 1;
      var cache = getCache();
      if (nextIdx < window.storyUserQueue.length &&
          cache[window.storyUserQueue[nextIdx]] &&
          cache[window.storyUserQueue[nextIdx]].length) {
        window.storyUserIdx = nextIdx;
        window.storyQueue   = cache[window.storyUserQueue[nextIdx]].slice();
        window.storyIndex   = 0;
        buildStoryProgress();
        setTimeout(function () { showStoryAt(0); }, 60);
        return;
      }
      closeStoryViewer();
      return;
    }

    window.storyIndex = i;
    window.storyProgressPaused = false;
    window.storyPausedElapsed  = 0;
    window.storyPausedStart    = 0;

    var s = window.storyQueue[i];
    var sUid = s.uid;
    window.currentStoryKey = sUid + '/' + s.id;

    var me = getMyUid();
    var viewer = findUser(sUid) || { name: 'User', photo: '' };

        var avEl = qs('#storyTopAvatar');
    if (avEl) {
      var avHtml = avatarHTML(viewer.photo, viewer.name, 'av-32');
      /* avatarHTML uses inline styles (no class="avatar").
       * Build the new node in a temp wrapper, force the id/class on it,
       * then swap it in — guarantees #storyTopAvatar exists next time. */
      var tmp = document.createElement('div');
      tmp.innerHTML = avHtml;
      var newAv = tmp.firstElementChild;
      if (newAv) {
        newAv.id = 'storyTopAvatar';
        newAv.classList.add('avatar', 'av-32');
        avEl.parentNode.replaceChild(newAv, avEl);
      }
    }
    var nmEl = qs('#storyTopName');
    if (nmEl) nmEl.textContent = viewer.name || 'User';

    var tmEl = qs('#storyTopTime');
    if (tmEl) tmEl.textContent = timeAgo(s.createdAt);

    var stage = qs('#storyStage');
    var hint = qs('#storySoundHint');
    if (hint) hint.classList.remove('show');

    if (storyTimer) {
      clearInterval(storyTimer);
      storyTimer = null;
    }

    if (!stage) return;

    if (s.kind === 'poll' && s.poll) {
      stage.innerHTML =
        '<div class="textstory" style="background:linear-gradient(135deg,var(--accent),#ff5c6c);flex-direction:column;gap:1rem">' +
          '<div style="font-size:1.2rem">' + esc(s.poll.q) + '</div>' +
          '<div style="display:flex;flex-direction:column;gap:.5rem;width:100%;max-width:16rem">' +
            '<button class="btn solid" data-sp="A">' + esc(s.poll.a) + '</button>' +
            '<button class="btn solid" data-sp="B">' + esc(s.poll.b) + '</button>' +
          '</div>' +
        '</div>';

      qsa('[data-sp]', stage).forEach(function (b) {
        b.addEventListener('click', async function (e) {
          e.stopPropagation();
          safeCall('voteStoryPoll', [sUid, s.id, b.getAttribute('data-sp')]);
        });
      });

      startProgress(PROGRESS_DEFAULT_MS, null);

    } else if (s.type === 'image') {
      stage.innerHTML =
        '<img src="' + esc(s.url) + '" alt="">' +
        (s.text ? '<div class="textoverlay">' + esc(s.text) + '</div>' : '');
      startProgress(PROGRESS_DEFAULT_MS, null);

    } else if (s.type === 'video') {
      stage.innerHTML = '';
      var v = document.createElement('video');
      v.src = s.url;
      v.setAttribute('playsinline', '');
      v.setAttribute('webkit-playsinline', '');
      v.preload = 'auto';
      v.muted = !window.storySoundOn;
      stage.appendChild(v);

      if (s.text) {
        var overlay = document.createElement('div');
        overlay.className = 'textoverlay';
        overlay.textContent = s.text;
        stage.appendChild(overlay);
      }

      var started = false;
      var startFromVideo = function () {
        if (started) return;
        started = true;
        var dur = (isFinite(v.duration) && v.duration > 0)
          ? v.duration * 1000
          : PROGRESS_DEFAULT_MS;
        startProgress(dur, v);
      };

      v.addEventListener('loadedmetadata', startFromVideo);
      v.addEventListener('timeupdate', function () {
        if (window.storyProgressPaused || !v.duration) return;
        var bars = qsa('#storyProgress i b');
        var cur = bars[window.storyIndex];
        if (cur) {
          cur.style.width = Math.min(100, (v.currentTime / v.duration) * 100) + '%';
        }
      });
      v.addEventListener('ended', function () {
        showStoryAt(window.storyIndex + 1);
      });

      var pr = v.play();
      if (pr && pr.catch) {
        pr.catch(function (err) {
          if (err && err.name === 'NotAllowedError') {
            v.muted = true;
            var p2 = v.play();
            if (p2 && p2.catch) p2.catch(function () {});
            if (hint) hint.classList.add('show');
          }
        });
      } else if (v.muted && hint) {
        hint.classList.add('show');
      }

      setTimeout(startFromVideo, 1200);

    } else {
      stage.innerHTML =
        '<div class="textstory" style="background:linear-gradient(135deg,var(--accent),#ff5c6c)">' +
          esc(s.text || '') +
        '</div>';
      startProgress(PROGRESS_DEFAULT_MS, null);
    }

    /* Mine-only buttons */
    var del = qs('#storyDelete');
    if (del) {
      if (sUid === me) {
        del.style.display = '';
        del.onclick = async function () {
          var ok = await safeCall('confirmDialog', [T('delete'), T('are_you_sure')]);
          if (!ok) return;
          var fbDb = getDB();
          if (fbDb) {
            try { await fbDb.ref('stories/' + sUid + '/' + s.id).remove(); } catch (e) {}
          }
          closeStoryViewer();
        };
      } else {
        del.style.display = 'none';
      }
    }

    var vbtn = qs('#storyViewersBtn');
    if (vbtn) {
      if (sUid === me) {
        vbtn.style.display = '';
        vbtn.onclick = function () { openStoryViewers(); };
      } else {
        vbtn.style.display = 'none';
      }
    }

    var hbtn = qs('#storyHighlightBtn');
    if (hbtn) {
      if (sUid === me) {
        hbtn.style.display = '';
        hbtn.onclick = function () {
          safeCall('addStoryToHighlight', [s]);
        };
      } else {
        hbtn.style.display = 'none';
      }
    }

    var viewsEl = qs('#storyViews');
    if (viewsEl) {
      if (sUid === me) {
        var views = s.views ? Object.keys(s.views).length : 0;
        viewsEl.textContent = views + ' ' + T('viewers');
      } else {
        viewsEl.textContent = '';
      }
    }

    if (sUid !== me) {
      var fbDb = getDB();
      if (fbDb) {
        fbDb.ref('stories/' + sUid + '/' + s.id + '/views/' + me)
          .set({ at: timeNow() }).catch(function () {});
      }
      safeCall('markSeen', [sUid, s.id]);
      safeCall('bumpDaily', ['story_watch', 1]);
    }

    /* ============================================================
     * REACTIONS — v2: single heart, long press expands
     * ============================================================ */
    var rxBox = qs('#storyReactions');
    var replyBar = qs('#storyReplyBar');

    if (sUid !== me) {
      if (rxBox) {
        rxBox.style.display = 'flex';
        rxBox.innerHTML = buildHeartOnlyReactions();
        wireHeartReactions(rxBox, sUid, s.id);
      }
      if (replyBar) replyBar.style.display = 'flex';
    } else {
      if (rxBox) rxBox.style.display = 'none';
      if (replyBar) replyBar.style.display = 'none';
    }
  }

  /* ============================================================
   * HEART-ONLY REACTION UI
   * ============================================================ */
  function buildHeartOnlyReactions() {
    return (
      '<button data-srx-main style="font-size:2rem;padding:.2rem .4rem;background:none;border:none;color:inherit;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:manipulation;">❤️</button>' +
      '<span class="rx-more-wrap" style="display:none;gap:.25rem;align-items:center;">' +
        ['😂','😮','😢','😡','👍'].map(function (r) {
          return '<button data-srx="' + r + '" style="font-size:1.5rem;padding:.15rem .25rem;background:none;border:none;color:inherit;cursor:pointer;user-select:none;-webkit-user-select:none;touch-action:manipulation;">' + r + '</button>';
        }).join('') +
      '</span>'
    );
  }

  function wireHeartReactions(rxBox, sUid, sId) {
    var mainBtn = rxBox.querySelector('[data-srx-main]');
    var moreWrap = rxBox.querySelector('.rx-more-wrap');
    if (!mainBtn || !moreWrap) return;

    var longPressT = null;
    var longFired = false;

    var cancelLong = function () {
      if (longPressT) { clearTimeout(longPressT); longPressT = null; }
    };

    mainBtn.addEventListener('pointerdown', function (e) {
      e.stopPropagation();
      longFired = false;
      longPressT = setTimeout(function () {
        longFired = true;
        moreWrap.style.display = 'flex';
        mainBtn.style.display = 'none';
        try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}
      }, 400);
    });

    mainBtn.addEventListener('pointerup', function (e) {
      e.stopPropagation();
      cancelLong();
      if (longFired) return;
      /* Single tap → immediate heart reaction */
      sendStoryReaction(sUid, sId, '❤️');
    });

    mainBtn.addEventListener('pointerleave', cancelLong);
    mainBtn.addEventListener('pointercancel', cancelLong);

    /* Other emojis */
    qsa('[data-srx]', moreWrap).forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var emoji = b.getAttribute('data-srx');
        sendStoryReaction(sUid, sId, emoji);
        moreWrap.style.display = 'none';
        mainBtn.style.display = '';
      });
    });

    /* Dismiss more panel on outside click (one-shot on document) */
    setTimeout(function () {
      function dismiss(e) {
        if (!moreWrap || moreWrap.style.display !== 'flex') return;
        if (e.target && e.target.closest && e.target.closest('.rx-more-wrap')) return;
        if (e.target && e.target.closest && e.target.closest('[data-srx-main]')) return;
        moreWrap.style.display = 'none';
        mainBtn.style.display = '';
        document.removeEventListener('pointerdown', dismiss, true);
      }
      document.addEventListener('pointerdown', dismiss, true);
    }, 100);
  }

  /* ============================================================
   * START PROGRESS
   * ============================================================ */
  function startProgress(dur, videoEl) {
    if (storyTimer) {
      clearInterval(storyTimer);
      storyTimer = null;
    }

    var bars = qsa('#storyProgress i b');
    for (var i = 0; i < bars.length; i++) {
      if (i < window.storyIndex) bars[i].style.width = '100%';
      else if (i > window.storyIndex) bars[i].style.width = '0';
    }

    var cur = bars[window.storyIndex];
    if (!cur) return;

    if (videoEl) return;

    cur.style.width = '0';
    var t0 = timeNow();
    window.storyPausedStart = t0;

    storyTimer = setInterval(function () {
      if (window.storyProgressPaused) return;
      var elapsed = timeNow() - t0 - window.storyPausedElapsed;
      cur.style.width = Math.min(100, (elapsed / dur) * 100) + '%';
      if (elapsed >= dur) {
        clearInterval(storyTimer);
        storyTimer = null;
        showStoryAt(window.storyIndex + 1);
      }
    }, 50);
  }

  /* ============================================================
   * CLOSE
   * ============================================================ */
  function closeStoryViewer() {
    if (storyTimer) {
      clearInterval(storyTimer);
      storyTimer = null;
    }

    var stage = qs('#storyStage');
    if (stage) {
      var v = stage.querySelector('video');
      if (v) {
        try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) {}
      }
    }

    var ov = qs('#ovStoryViewer');
    if (ov) ov.classList.remove('open');

    var sheet = qs('#storyViewersSheet');
    if (sheet) sheet.classList.remove('open');

    if (stage) stage.innerHTML = '';

    window.currentStoryKey     = null;
    window.storyProgressPaused = false;
    return true;
  }

  /* ============================================================
   * VIEWERS SHEET — v2: shows reactions too
   * ============================================================ */
  async function openStoryViewers() {
    var s = window.storyQueue[window.storyIndex];
    if (!s) return false;
    var me = getMyUid();
    if (s.uid !== me) return false;

    var sheet = qs('#storyViewersSheet');
    var body  = qs('#storyViewersBody');
    if (!sheet || !body) return false;

    sheet.classList.add('open');
    body.innerHTML = '<div class="loading-row"><span class="spinner"></span>' +
                     esc(T('loading')) + '</div>';

    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      var results = await Promise.all([
        fbDb.ref('stories/' + s.uid + '/' + s.id + '/views').get(),
        fbDb.ref('storyReactions/' + s.uid + '/' + s.id).get()
      ]);

      var views     = results[0].val() || {};
      var reactions = results[1].val() || {};

      /* Merge uids from both maps */
      var uidsSet = {};
      Object.keys(views).forEach(function (u) { uidsSet[u] = true; });
      Object.keys(reactions).forEach(function (u) { uidsSet[u] = true; });

      var list = Object.keys(uidsSet).map(function (u) {
        var viewRaw = views[u];
        var viewAt = (viewRaw && typeof viewRaw === 'object' && viewRaw.at)
          ? viewRaw.at
          : (typeof viewRaw === 'number' ? viewRaw : 0);

        var reactRaw = reactions[u];
        var reactType = reactRaw
          ? (typeof reactRaw === 'string' ? reactRaw : (reactRaw && reactRaw.type) || null)
          : null;
        var reactAt = (reactRaw && typeof reactRaw === 'object' && reactRaw.at) ? reactRaw.at : 0;

        return {
          uid: u,
          at: Math.max(viewAt || 0, reactAt || 0),
          react: reactType
        };
      }).sort(function (a, b) { return (b.at || 0) - (a.at || 0); });

      if (!list.length) {
        body.innerHTML =
          '<div class="empty">' +
            '<span class="ic">' + (window.svgIcon ? window.svgIcon('eye') : '') + '</span>' +
            '<p>' + esc(T('no_viewers')) + '</p>' +
          '</div>';
        return true;
      }

      body.innerHTML = list.map(function (x) {
        var u = findUser(x.uid) || { name: 'User', photo: '' };
        var reactBadge = x.react
          ? '<span class="story-viewer-rx" style="display:inline-flex;align-items:center;' +
            'justify-content:center;min-width:1.5rem;height:1.5rem;' +
            'padding:0 .35rem;border-radius:.75rem;background:rgba(124,92,255,.15);' +
            'border:1px solid rgba(124,92,255,.35);font-size:.9rem;margin-left:.4rem;">' +
            esc(x.react) + '</span>'
          : '';

        return '<div class="user-card" data-svuid="' + esc(x.uid) + '">' +
          avatarHTML(u.photo, u.name, 'av-40', x.uid) +
          '<div class="grow">' +
            '<div class="name" style="display:flex;align-items:center;">' +
              esc(u.name) + reactBadge +
            '</div>' +
            '<div class="mini">' + (x.at ? esc(timeAgo(x.at)) : '—') + '</div>' +
          '</div>' +
        '</div>';
      }).join('');

            qsa('[data-svuid]', body).forEach(function (n) {
        n.addEventListener('click', function () {
          var uid = n.getAttribute('data-svuid');
          /* Do NOT closeStoryViewer — stack profile on top */
          safeCall('openUserProfile', [uid]);
        });
      });

      return true;
    } catch (e) {
      body.innerHTML = '<div class="banner">' + esc((e && e.message) || T('error')) + '</div>';
      return false;
    }
  }

  /* ============================================================
   * STORY REPLY
   * ============================================================ */
  async function sendStoryReply() {
    if (!window.currentStoryKey) return false;
    var parts = window.currentStoryKey.split('/');
    var sUid = parts[0];
    var sId  = parts[1];
    if (!sUid || sUid === getMyUid()) return false;

    var inp = qs('#storyReplyInput');
    if (!inp) return false;
    var text = (inp.value || '').trim();
    if (!text) return false;
    inp.value = '';

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    try {
      var chatId = await safeCall('ensureDirectChat', [sUid]);
      if (!chatId) throw new Error(T('error'));

            var storyObj = (getCache()[sUid] || []).find(function (x) { return x.id === sId; });
      var thumb = (storyObj && storyObj.type === 'image') ? storyObj.url : '';
      var storyText = (storyObj && storyObj.text) || '';
      var storyType = storyObj ? (storyObj.type || '') : '';
      var storyUrl  = storyObj ? (storyObj.url  || '') : '';

      var ref = fbDb.ref('messages/' + chatId).push();
      var mp = getMyProfile() || {};

      await ref.set({
        id: ref.key,
        from: me,
        fromName: mp.name || '',
        fromPhoto: mp.photo || '',
        type: 'text',
        text: text,
        storyReply: {
          storyUid: sUid,
          storyId: sId,
          thumb: thumb || '',
          storyText: storyText.slice(0, 120),
          storyType: storyType,
          storyUrl: storyUrl,
          sentAt: timeNow()
        },
        createdAt: timeNow(),
        readBy: (function () { var r = {}; r[me] = true; return r; })()
      });

      safeCall('updateChatMeta', [chatId, ('📖 ' + text).slice(0, 80)]);

      safeCall('pushNotification', [sUid, {
        type: 'message',
        fromUid: me,
        fromName: mp.name || '',
        fromPhoto: mp.photo || '',
        text: T('reply_to_story'),
        chatId: chatId,
        storyUid: sUid,
        storyId: sId,
        storyThumb: thumb,
        createdAt: timeNow()
      }]);

      safeCall('bumpDaily', ['story_reply', 1]);
      safeToast(T('story_reply_sent'), 'ok');
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * SOUND UNMUTE HANDLER
   * ============================================================ */
  function onStoryPointerDown(e) {
    var t = e.target;
    if (t && t.closest && (
        t.closest('.story-reply-bar') ||
        t.closest('.story-reactions') ||
        t.closest('.story-top') ||
        t.closest('.story-foot') ||
        t.closest('.story-viewers-sheet'))) {
      return;
    }

    if (window.storySoundOn) return;
    window.storySoundOn = true;
    persistSound();

    var v = qs('#storyStage video');
    if (v) {
      try { v.muted = false; } catch (err) {}
      try {
        var p = v.play();
        if (p && p.catch) p.catch(function () {});
      } catch (err) {}
    }

    var h = qs('#storySoundHint');
    if (h) h.classList.remove('show');
  }

  /* ============================================================
   * GESTURES — tap + swipe in one place
   * ============================================================ */
  function bindAllGestures() {
    if (gestureBound) return;
    var ov = qs('#ovStoryViewer');
    if (!ov) return;
    gestureBound = true;

    var startX = 0, startY = 0, startT = 0;
    var active = false;
    var moved  = false;

    ov.addEventListener('pointerdown', function (e) {
      var t = e.target;
      if (t && t.closest && (
          t.closest('.story-reply-bar') ||
          t.closest('.story-reactions') ||
          t.closest('.story-top') ||
          t.closest('.story-foot') ||
          t.closest('.story-viewers-sheet'))) {
        return;
      }
      active = true;
      moved = false;
      startX = e.clientX || 0;
      startY = e.clientY || 0;
      startT = Date.now();
    }, { capture: true, passive: true });

    ov.addEventListener('pointermove', function (e) {
      if (!active) return;
      var dx = Math.abs((e.clientX || 0) - startX);
      var dy = Math.abs((e.clientY || 0) - startY);
      if (dx > 12 || dy > 12) moved = true;
    }, { capture: true, passive: true });

    ov.addEventListener('pointerup', function (e) {
      if (!active) return;
      active = false;

      var dx = (e.clientX || 0) - startX;
      var dy = (e.clientY || 0) - startY;
      var dt = Date.now() - startT;

      /* Horizontal swipe */
      if (moved && Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) && dt < 900) {
        if (dx < 0) showStoryAt(window.storyIndex + 1);
        else prevStory();
        return;
      }

      /* Swipe down → close */
      if (moved && dy > 90 && Math.abs(dy) > Math.abs(dx)) {
        closeStoryViewer();
        return;
      }

      /* Tap */
      if (!moved && dt < 400) {
        var rect = ov.getBoundingClientRect();
        var x = (e.clientX || 0) - rect.left;
        if (x < rect.width * 0.35) prevStory();
        else showStoryAt(window.storyIndex + 1);
      }
    }, { capture: true, passive: true });

    ov.addEventListener('pointercancel', function () {
      active = false;
      moved = false;
    }, { capture: true, passive: true });
  }

  /* ============================================================
   * BIND STATIC CONTROLS
   * ============================================================ */
  var bound = false;
  function bind() {
    if (bound) return true;

    var send = qs('#storyReplySend');
    if (send && send.dataset.svBound !== '1') {
      send.dataset.svBound = '1';
      send.addEventListener('click', function () { sendStoryReply(); });
    }

    var input = qs('#storyReplyInput');
    if (input && input.dataset.svBound !== '1') {
      input.dataset.svBound = '1';
      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          sendStoryReply();
        }
      });
    }

    var closeBtn = qs('#storyClose');
    if (closeBtn && closeBtn.dataset.svBound !== '1') {
      closeBtn.dataset.svBound = '1';
      closeBtn.addEventListener('click', closeStoryViewer);
    }

    var vClose = qs('#storyViewersClose');
    if (vClose && vClose.dataset.svBound !== '1') {
      vClose.dataset.svBound = '1';
      vClose.addEventListener('click', function () {
        var sheet = qs('#storyViewersSheet');
        if (sheet) sheet.classList.remove('open');
      });
    }

    var ov = qs('#ovStoryViewer');
    if (ov && ov.dataset.soundBound !== '1') {
      ov.dataset.soundBound = '1';
      ov.addEventListener('pointerdown', onStoryPointerDown, { capture: true, passive: true });
    }

    bound = true;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
    window.openStoriesForUser = openStoriesForUser;
  window.openStoryAt        = openStoryAt;
  window.buildStoryProgress = buildStoryProgress;
  window.showStoryAt        = showStoryAt;
  window.closeStoryViewer   = closeStoryViewer;
  window.openStoryViewers   = openStoryViewers;
  window.prevStory          = prevStory;
  window.sendStoryReaction  = sendStoryReaction;

  window.SaikoStoryViewer = {
    open: openStoriesForUser,
    buildProgress: buildStoryProgress,
    showAt: showStoryAt,
    prev: prevStory,
    close: closeStoryViewer,
    openViewers: openStoryViewers,
    sendReply: sendStoryReply,
    sendReaction: sendStoryReaction,
    startProgress: startProgress,
    bind: bind,
    getState: function () {
      return {
        userQueue: window.storyUserQueue.slice(),
        userIdx: window.storyUserIdx,
        queue: window.storyQueue.slice(),
        index: window.storyIndex,
        currentStoryKey: window.currentStoryKey,
        soundOn: !!window.storySoundOn
      };
    },
    PROGRESS_DEFAULT_MS: PROGRESS_DEFAULT_MS
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  try {
    console.debug('[boot] feature 189 — story-viewer ready (v2)');
  } catch (e) {}

})();