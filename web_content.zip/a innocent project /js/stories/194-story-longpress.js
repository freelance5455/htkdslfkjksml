/* ============================================================
 * FEATURE:        Story Long-Press Pause
 * FEATURE NUMBER: 194
 * FILE:           js/stories/194-story-longpress.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the pause / resume state machine that feature 193
 *   (story-swipe) triggers when the user long-presses the
 *   story viewer. Provides the two global entry points that
 *   193 calls:
 *
 *       pauseStory()   — enter the paused state
 *       resumeStory()  — leave the paused state
 *
 *   What "paused" means:
 *
 *     • window.storyProgressPaused = true
 *         Feature 189's progress timer reads this and freezes
 *         the bar in place (it early-returns from the interval
 *         tick while paused).
 *
 *     • window.storyPausedStart = now()
 *         Timestamp of when the pause began — used on resume
 *         to compute the frozen duration.
 *
 *     • If the current story is a video, its playback is
 *         paused via safePause(). Feature 189 already
 *         early-returns from the video's own progress writes
 *         while paused, so the video visually freezes too.
 *
 *   What "resume" means:
 *
 *     • window.storyPausedElapsed += (now() - storyPausedStart)
 *         The cumulative paused time is added to the offset
 *         feature 189 subtracts from its running elapsed
 *         calculation:
 *             elapsed = now() - t0 - storyPausedElapsed
 *         so the bar picks up exactly where it left off.
 *
 *     • window.storyProgressPaused = false
 *
 *     • If a video exists, playback is resumed via safePlay().
 *
 *   Behaviour preserved 1:1 from the original §28 STORIES
 *   block's pauseStory() / resumeStory() functions.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §28 STORIES
 *       function pauseStory() { … }
 *       function resumeStory() { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   - safePlay / safePause  js/feed/082-video-observer.js
 *                           (safely-called — falls back to
 *                            direct .play()/.pause() when 082
 *                            is not loaded)
 *
 * DOM ELEMENTS USED:
 *   #storyStage > video    (the video element when the current
 *                           story is a video type)
 *
 * FIREBASE PATHS:
 *   none — purely client-side state.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.pauseStory         (original name preserved)
 *   window.resumeStory        (original name preserved)
 *   window.SaikoStoryLongpress = {
 *     pause, resume,
 *     isPaused, toggle,
 *     getPausedMs, reset
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-longpress] safeCall:', name, e); }
    return undefined;
  }

  /* Locate the currently-rendered story video (if any).
   * Feature 189 appends it inside #storyStage. */
  function currentVideo() {
    var stage = qs('#storyStage');
    if (!stage) return null;
    return stage.querySelector('video');
  }

  /* ============================================================
   * PAUSE
   * ============================================================
   * Preserved 1:1 from the original pauseStory():
   *   • no-op when already paused (idempotent)
   *   • set storyProgressPaused = true
   *   • record storyPausedStart = now()
   *   • safePause the story video if one is playing
   * ============================================================ */
  function pauseStory() {
    if (window.storyProgressPaused) return false;

    window.storyProgressPaused = true;
    window.storyPausedStart    = timeNow();

    var v = currentVideo();
    if (v && !v.paused) {
      /* Prefer the shared safePause (feature 082). Fall back
       * to a direct .pause() so this module works standalone. */
      var paused = safeCall('safePause', [v]);
      if (paused === undefined) {
        try { v.pause(); } catch (e) {}
      }
    }

    /* Notify subscribers (additive) ----------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:story-paused'));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * RESUME
   * ============================================================
   * Preserved 1:1 from the original resumeStory():
   *   • no-op when not paused (idempotent)
   *   • accumulate storyPausedElapsed += now() - storyPausedStart
   *   • clear the paused flag
   *   • safePlay the story video if one exists
   * ============================================================ */
  function resumeStory() {
    if (!window.storyProgressPaused) return false;

    var pausedAt = window.storyPausedStart || timeNow();
    window.storyPausedElapsed =
      (window.storyPausedElapsed || 0) + (timeNow() - pausedAt);

    window.storyProgressPaused = false;

    var v = currentVideo();
    if (v && v.paused) {
      var played = safeCall('safePlay', [v]);
      if (played === undefined) {
        try {
          var p = v.play();
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
      }
    }

    /* Notify subscribers (additive) ----------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:story-resumed'));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * TOGGLE — additive convenience
   * ============================================================
   * Flips the paused state. Useful for a "tap-to-pause" gesture
   * or a keyboard shortcut binding.
   * ============================================================ */
  function toggle() {
    if (window.storyProgressPaused) return resumeStory();
    return pauseStory();
  }

  /* ============================================================
   * STATE READERS
   * ============================================================ */
  function isPaused() {
    return !!window.storyProgressPaused;
  }

  /* getPausedMs() — total time frozen during the current story.
   * While paused, includes the current in-flight pause segment. */
  function getPausedMs() {
    var base = window.storyPausedElapsed || 0;
    if (!window.storyProgressPaused) return base;
    return base + (timeNow() - (window.storyPausedStart || timeNow()));
  }

  /* ============================================================
   * RESET — additive helper
   * ============================================================
   * Clears the paused flags. Feature 189's showStoryAt() already
   * resets these at each story advance, but a manual reset is
   * useful for programmatic switches and testing.
   * ============================================================ */
  function reset() {
    window.storyProgressPaused = false;
    window.storyPausedElapsed  = 0;
    window.storyPausedStart    = 0;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.pauseStory  = pauseStory;
  window.resumeStory = resumeStory;

  window.SaikoStoryLongpress = {
    pause: pauseStory,
    resume: resumeStory,
    toggle: toggle,
    isPaused: isPaused,
    getPausedMs: getPausedMs,
    reset: reset
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 194 — story-longpress ready');
  } catch (e) {}

})();