/* ============================================================
 * FEATURE:        Story Create
 * FEATURE NUMBER: 187
 * FILE:           js/stories/187-story-create.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "New Story" composer (#ovStoryCreate). Handles:
 *
 *     1. OPEN
 *          openStoryCreate() — reset the composer state (text,
 *          media, kind, poll fields, progress bar, status line)
 *          and open the overlay.
 *
 *     2. KIND SWITCH
 *          #storyKind change → show / hide the poll-details
 *          panel (#storyPollWrap) when "poll" is selected.
 *
 *     3. MEDIA PICK
 *          • #storyPickImage → hidden #storyImgFile
 *          • #storyPickVideo → hidden #storyVidFile
 *          • #storyImgFile change → validate → compress (1400,
 *            0.82) → upload → storyMedia = {type:'image', url}
 *          • #storyVidFile change → validate (50 MB / 60 s) →
 *            probeVideo duration → upload → storyMedia =
 *            {type:'video', url}
 *          Both paths update #storyPreview with a thumbnail and
 *          drive the progress bar (#storyBar) + status line
 *          (#storyStatus).
 *
 *     4. PUBLISH
 *          #storyPublish click → validate (text or media;
 *          poll fields when kind='poll') → push into
 *          stories/{myUid} with the exact payload shape from
 *          the original → close + toast.
 *
 *   Behaviour preserved 1:1 from the original §28 STORIES
 *   block:
 *
 *     Story payload:
 *       { id: ref.key, uid: myUid, kind, text,
 *         type: 'image' | 'video' | 'text',
 *         url: <uploaded URL or ''>,
 *         privacy: 'public' | 'close',
 *         createdAt: now(),
 *         views: {} }
 *       When kind === 'poll':
 *         poll: { q, a, b }
 *
 *     Limits (from MEDIA_CONFIG):
 *       MAX_STORY_BYTES     50 MB
 *       MAX_STORY_SECONDS   60 s
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §28 STORIES
 *       openStoryCreate()
 *       #storyKind change
 *       #storyPickImage / #storyPickVideo click
 *       #storyImgFile / #storyVidFile change
 *       #storyPublish click
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - t / esc / now            helpers
 *   - openOverlay / closeOverlay (038)
 *   - toast                    js/nav/042-toast.js
 *   - validateImage / compressImage / cloudinaryUpload
 *   - validateVideo / probeVideo / cloudinaryUpload
 *
 * DOM ELEMENTS USED:
 *   #ovStoryCreate, #storyText, #storyKind, #storyPollWrap,
 *   #storyPollQ, #storyPollA, #storyPollB, #storyPrivacy,
 *   #storyPickImage, #storyPickVideo, #storyImgFile,
 *   #storyVidFile, #storyPreview, #storyBar, #storyStatus,
 *   #storyPublish
 *
 * FIREBASE PATHS:
 *   stories/{uid}                     (write on publish)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openStoryCreate         (original name preserved)
 *   window.SaikoStoryCreate = {
 *     open, bind, unbind,
 *     pickImage, pickVideo,
 *     publish,
 *     getState, reset
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_STORY_SECONDS: 60,
    MAX_STORY_BYTES: 50 * 1024 * 1024
  };
  var MAX_STORY_SECONDS = MEDIA_CONFIG.MAX_STORY_SECONDS || 60;
  var MAX_STORY_BYTES   = MEDIA_CONFIG.MAX_STORY_BYTES   || (50 * 1024 * 1024);
  var IMAGE_MAX_SIDE    = 1400;
  var IMAGE_QUALITY     = 0.82;

  /* ============================================================
   * STATE
   * ============================================================ */
  var storyMedia = { type: null, url: '' };
  var publishing = false;
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-create] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* Bar helpers ------------------------------------------------ */
  function showBar() {
    var bar = qs('#storyBar');
    if (bar) bar.classList.remove('hidden');
  }
  function setBarWidth(pct) {
    var bar = qs('#storyBar');
    if (!bar) return;
    var i = bar.querySelector('i');
    if (i) i.style.width = Math.max(0, Math.min(100, pct)) + '%';
  }
  function hideBarLater() {
    var bar = qs('#storyBar');
    if (!bar) return;
    setTimeout(function () {
      bar.classList.add('hidden');
      setBarWidth(0);
    }, 400);
  }
  function setStatus(text) {
    var el = qs('#storyStatus');
    if (el) el.textContent = text || '';
  }

  /* ============================================================
   * RESET
   * ============================================================ */
  function reset() {
    storyMedia = { type: null, url: '' };

    var txt = qs('#storyText');
    if (txt) txt.value = '';

    var prev = qs('#storyPreview');
    if (prev) prev.innerHTML = '';

    setStatus('');
    var bar = qs('#storyBar');
    if (bar) bar.classList.add('hidden');
    setBarWidth(0);

    var kind = qs('#storyKind');
    if (kind) kind.value = 'normal';

    var wrap = qs('#storyPollWrap');
    if (wrap) wrap.classList.add('hidden');

    var q = qs('#storyPollQ'); if (q) q.value = '';
    var a = qs('#storyPollA'); if (a) a.value = '';
    var b = qs('#storyPollB'); if (b) b.value = '';

    publishing = false;
    var pub = qs('#storyPublish');
    if (pub) pub.disabled = false;
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openStoryCreate() {
    reset();
    safeCall('openOverlay', ['ovStoryCreate']);
    return true;
  }

  /* ============================================================
   * IMAGE PICK
   * ============================================================ */
  async function handleImagePicked(file) {
    if (!file) return false;

    /* 1) Validate ----------------------------------------- */
    var err = null;
    try {
      if (typeof window.validateImage === 'function') {
        err = window.validateImage(file);
      }
    } catch (e) {}
    if (err) { safeToast(err, 'err'); return false; }

    try {
      /* 2) Progress + status ---------------------------- */
      showBar();
      setBarWidth(50);
      setStatus(T('uploading'));

      /* 3) Compress (best effort) ----------------------- */
      var comp = file;
      try {
        if (typeof window.compressImage === 'function') {
          comp = await window.compressImage(file, IMAGE_MAX_SIDE, IMAGE_QUALITY);
        }
      } catch (e) { comp = file; }

      /* 4) Upload to Cloudinary ------------------------- */
      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(comp, 'story.jpg');
      }
      if (!url) throw new Error(T('upload_failed'));

      /* 5) Store + preview ------------------------------ */
      storyMedia = { type: 'image', url: url };

      var prev = qs('#storyPreview');
      if (prev) {
        prev.innerHTML =
          '<div class="post-img"><img src="' + esc(url) + '" alt=""></div>';
      }

      setBarWidth(100);
      setStatus('');
      hideBarLater();
      return true;
    } catch (err2) {
      setStatus('');
      var bar2 = qs('#storyBar');
      if (bar2) bar2.classList.add('hidden');
      setBarWidth(0);
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
      return false;
    }
  }

  /* ============================================================
   * VIDEO PICK
   * ============================================================ */
  async function handleVideoPicked(file) {
    if (!file) return false;

    /* 1) Validate type + size ----------------------------- */
    var err = null;
    try {
      if (typeof window.validateVideo === 'function') {
        err = window.validateVideo(file, MAX_STORY_BYTES, MAX_STORY_SECONDS);
      }
    } catch (e) {}
    if (err) { safeToast(err, 'err'); return false; }

    try {
      /* 2) Duration guard ------------------------------- */
      var dur = 0;
      try {
        if (typeof window.probeVideo === 'function') dur = await window.probeVideo(file);
      } catch (e) { dur = 0; }
      if (dur && dur > MAX_STORY_SECONDS) {
        safeToast(T('video_too_long') + ' (' + MAX_STORY_SECONDS + 's)', 'err');
        return false;
      }

      /* 3) Progress + status ---------------------------- */
      showBar();
      setBarWidth(5);
      setStatus(T('uploading'));

      /* 4) Upload --------------------------------------- */
      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(file, 'story.mp4', function (pct) {
          setBarWidth(pct);
        });
      }
      if (!url) throw new Error(T('upload_failed'));

      /* 5) Store + preview ------------------------------ */
      storyMedia = { type: 'video', url: url };

      var prev = qs('#storyPreview');
      if (prev) {
        prev.innerHTML =
          '<video controls style="width:100%;border-radius:.7rem" src="' +
          esc(url) + '"></video>';
      }

      setBarWidth(100);
      setStatus('');
      hideBarLater();
      return true;
    } catch (err2) {
      setStatus('');
      var bar2 = qs('#storyBar');
      if (bar2) bar2.classList.add('hidden');
      setBarWidth(0);
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
      return false;
    }
  }

  /* ============================================================
   * PUBLISH
   * ============================================================ */
  async function publish() {
    if (publishing) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) { safeToast(T('error'), 'err'); return false; }

    /* 1) Read the composer fields ------------------------- */
    var textEl = qs('#storyText');
    var text = textEl ? textEl.value.trim() : '';

    var kindEl = qs('#storyKind');
    var kind = kindEl ? kindEl.value : 'normal';

    var privacyEl = qs('#storyPrivacy');
    var privacy = privacyEl ? privacyEl.value : 'public';

    /* 2) Validate ---------------------------------------- */
    if (!text && !storyMedia.url) {
      safeToast(T('fill_all'), 'err');
      return false;
    }

    var pollData = null;
    if (kind === 'poll') {
      var q = (qs('#storyPollQ') || {}).value || '';
      var a = (qs('#storyPollA') || {}).value || '';
      var b = (qs('#storyPollB') || {}).value || '';
      q = q.trim(); a = a.trim(); b = b.trim();
      if (!q || !a || !b) {
        safeToast(T('fill_all'), 'err');
        return false;
      }
      pollData = { q: q, a: a, b: b };
    }

    /* 3) Disable button ---------------------------------- */
    publishing = true;
    var btn = qs('#storyPublish');
    if (btn) btn.disabled = true;

    try {
      /* 4) Build the story node ------------------------- */
      var ref = fbDb.ref('stories/' + uid).push();

      var payload = {
        id: ref.key,
        uid: uid,
        kind: kind,
        text: text,
        type: storyMedia.url ? storyMedia.type : 'text',
        url: storyMedia.url || '',
        privacy: privacy,
        createdAt: timeNow(),
        views: {}
      };
      if (pollData) payload.poll = pollData;

      /* 5) Write ---------------------------------------- */
      await ref.set(payload);

      /* 6) Close + toast -------------------------------- */
      safeCall('closeOverlay', ['ovStoryCreate']);
      safeToast(T('saved'), 'ok');

      /* Notify subscribers (additive) ------------------ */
      try {
        window.dispatchEvent(new CustomEvent('saiko:story-created', {
          detail: { storyId: ref.key }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    } finally {
      publishing = false;
      if (btn) btn.disabled = false;
    }
  }

  /* ============================================================
   * BIND — wire every static control inside the overlay
   * ============================================================ */
  function bind() {
    if (bound) return true;

    /* #storyKind ----------------------------------------- */
    var kind = qs('#storyKind');
    if (kind && kind.dataset.scBound !== '1') {
      kind.dataset.scBound = '1';
      kind.addEventListener('change', function (e) {
        var wrap = qs('#storyPollWrap');
        if (!wrap) return;
        if (e.target.value === 'poll') wrap.classList.remove('hidden');
        else wrap.classList.add('hidden');
      });
    }

    /* #storyPickImage ------------------------------------ */
    var pi = qs('#storyPickImage');
    if (pi && pi.dataset.scBound !== '1') {
      pi.dataset.scBound = '1';
      pi.addEventListener('click', function () {
        var fi = qs('#storyImgFile');
        if (fi) fi.click();
      });
    }

    /* #storyPickVideo ------------------------------------ */
    var pv = qs('#storyPickVideo');
    if (pv && pv.dataset.scBound !== '1') {
      pv.dataset.scBound = '1';
      pv.addEventListener('click', function () {
        var fi = qs('#storyVidFile');
        if (fi) fi.click();
      });
    }

    /* #storyImgFile -------------------------------------- */
    var imgFile = qs('#storyImgFile');
    if (imgFile && imgFile.dataset.scBound !== '1') {
      imgFile.dataset.scBound = '1';
      imgFile.addEventListener('change', function (e) {
        var f = e.target && e.target.files ? e.target.files[0] : null;
        if (e.target) e.target.value = '';
        if (f) handleImagePicked(f);
      });
    }

    /* #storyVidFile -------------------------------------- */
    var vidFile = qs('#storyVidFile');
    if (vidFile && vidFile.dataset.scBound !== '1') {
      vidFile.dataset.scBound = '1';
      vidFile.addEventListener('change', function (e) {
        var f = e.target && e.target.files ? e.target.files[0] : null;
        if (e.target) e.target.value = '';
        if (f) handleVideoPicked(f);
      });
    }

    /* #storyPublish -------------------------------------- */
    var pub = qs('#storyPublish');
    if (pub && pub.dataset.scBound !== '1') {
      pub.dataset.scBound = '1';
      pub.addEventListener('click', function () { publish(); });
    }

    bound = true;
    return true;
  }

  function unbind() {
    ['#storyKind', '#storyPickImage', '#storyPickVideo',
     '#storyImgFile', '#storyVidFile', '#storyPublish']
      .forEach(function (sel) {
        var n = qs(sel);
        if (!n) return;
        var clone = n.cloneNode(true);
        clone.removeAttribute('data-sc-bound');
        n.parentNode && n.parentNode.replaceChild(clone, n);
      });
    bound = false;
    return true;
  }

  /* ============================================================
   * GETTERS
   * ============================================================ */
  function getState() {
    return {
      media: { type: storyMedia.type, url: storyMedia.url },
      publishing: publishing
    };
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openStoryCreate = openStoryCreate;

  window.SaikoStoryCreate = {
    open: openStoryCreate,
    reset: reset,
    bind: bind,
    unbind: unbind,
    pickImage: handleImagePicked,
    pickVideo: handleVideoPicked,
    publish: publish,
    getState: getState,
    MAX_STORY_SECONDS: MAX_STORY_SECONDS,
    MAX_STORY_BYTES: MAX_STORY_BYTES
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 187 — story-create ready');
  } catch (e) {}

})();