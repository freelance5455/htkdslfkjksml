/* ============================================================
 * FEATURE:        Story Highlight
 * FEATURE NUMBER: 201
 * FILE:           js/stories/201-story-highlight.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "Add to Highlight" flow that lets a user pin a
 *   story into a named collection shown on their profile.
 *
 *   Responsibilities:
 *
 *     1. ADD STORY
 *          addStoryToHighlight(story, opts)
 *            — prompt for a highlight name (with an "e.g. Travel"
 *              placeholder matching the original)
 *            — create the highlights/{uid} entry with the story
 *              id included in `storyIds` and a cover if the story
 *              is an image
 *            — toast t('saved') on success
 *
 *     2. LIVE MAP
 *          window.myHighlights — { [highlightId]: { id, name,
 *              storyIds: [sid, ...], cover, createdAt } }
 *          A live listener on highlights/{myUid} keeps it fresh.
 *
 *     3. ADD TO EXISTING
 *          addStoryToExistingHighlight(highlightId, story)
 *            — appends the sid to the highlight's storyIds array
 *              without prompting (used when the user picks a
 *              highlight from a picker).
 *
 *     4. REMOVE STORY
 *          removeStoryFromHighlight(highlightId, sid)
 *            — removes one sid from the highlight's storyIds.
 *              If the list becomes empty the highlight itself is
 *              not deleted (matches the original behaviour —
 *              empty highlights remain until explicitly deleted).
 *
 *     5. DELETE HIGHLIGHT
 *          deleteHighlight(highlightId) — confirm + remove.
 *
 *     6. RENAME
 *          renameHighlight(highlightId) — prompt + update name.
 *
 *     7. OPEN
 *          openHighlight(highlightId) — additive helper that
 *            loads the highlight's stories into a viewer queue
 *            and calls openStoriesForUser-like flow.
 *
 *   Behaviour preserved 1:1 from the original §28 STORIES block:
 *
 *     $('#storyHighlightBtn').onclick = async () => {
 *       const name = await promptDialog(t('highlight_name'), '',
 *                                        'e.g. Travel');
 *       if (name == null || !name.trim()) return;
 *       const ref = db.ref('highlights/'+myUid).push();
 *       await ref.set({
 *         id: ref.key,
 *         name: name.trim(),
 *         storyIds: [s.id],
 *         cover: s.type === 'image' ? s.url : '',
 *         createdAt: now()
 *       });
 *       toast(t('saved'), 'ok');
 *     };
 *
 *   Notes on the semantics preserved:
 *     • The highlight is a per-user collection. Only the owner
 *       can add to or modify it.
 *     • `cover` is empty for video / text / poll stories — the
 *       UI falls back to a gradient tile in that case.
 *     • The prompt accepts null (cancel) and empty-after-trim
 *       as silent no-ops.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §28 STORIES
 *       #storyHighlightBtn click handler (inside showStoryAt)
 *       let myHighlights = {}
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - t / now                  helpers
 *   - promptDialog             js/nav/044-prompt-dialog.js
 *   - confirmDialog            js/nav/043-confirm-dialog.js
 *   - toast                    js/nav/042-toast.js
 *   - openOverlay / closeOverlay (038)
 *   - storiesCache             js/stories/186-story-bar.js
 *   - openStoriesForUser       js/stories/189-story-viewer.js
 *
 * DOM ELEMENTS USED:
 *   none — pure state + overlays. Consumers (profile page,
 *   story viewer) call into this module's helpers.
 *
 * FIREBASE PATHS:
 *   highlights/{uid}                           (read + listen)
 *   highlights/{uid}/{highlightId}             (create / update
 *                                                / remove)
 *   highlights/{uid}/{highlightId}/storyIds    (array)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.myHighlights               (live map)
 *   window.addStoryToHighlight        (original name preserved)
 *   window.startHighlightsListener    (additive)
 *   window.detachHighlightsListener   (additive)
 *   window.SaikoStoryHighlight = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var highlightsRef = null;
  var highlightsCb  = null;

  window.myHighlights = window.myHighlights || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') {
        return window.promptDialog(title, defValue, placeholder);
      }
    } catch (e) {}
    return Promise.resolve(null);
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    return Promise.resolve(true);
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-highlight] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * LIVE MAP — highlights/{uid}
   * ============================================================ */
  function startListener() {
    if (highlightsRef && highlightsCb) return true;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    highlightsRef = fbDb.ref('highlights/' + uid);
    highlightsCb  = highlightsRef.on('value', function (s) {
      window.myHighlights = s.val() || {};

      /* Nudge open UI (profile page, highlight picker) ---- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:highlights-changed', {
          detail: { map: window.myHighlights }
        }));
      } catch (e) {}
    });
    return true;
  }

  function detachListener() {
    if (highlightsRef && highlightsCb) {
      try { highlightsRef.off('value', highlightsCb); } catch (e) {}
    }
    highlightsRef = null;
    highlightsCb  = null;
    window.myHighlights = {};
    return true;
  }

  /* ============================================================
   * CREATE — prompt for a name and create the highlight
   * ============================================================
   * Preserved 1:1 from the original #storyHighlightBtn handler.
   * ============================================================ */
  async function addStoryToHighlight(story, opts) {
    if (!story || !story.id) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    opts = opts || {};

    /* 1) Prompt for a name -------------------------------- */
    var name = await askPrompt(T('highlight_name'), '', 'e.g. Travel');
    if (name == null) return false;              /* cancelled */
    var trimmed = String(name).trim();
    if (!trimmed) return false;                  /* empty */

    /* 2) Build the payload -------------------------------- */
    var payload = {
      id: null, /* filled after push */
      name: trimmed,
      storyIds: [story.id],
      cover: (story.type === 'image') ? (story.url || '') : '',
      createdAt: timeNow()
    };

    try {
      var ref = fbDb.ref('highlights/' + uid).push();
      payload.id = ref.key;
      await ref.set(payload);

      safeToast(T('saved'), 'ok');

      try {
        window.dispatchEvent(new CustomEvent('saiko:highlight-created', {
          detail: { highlightId: ref.key, storyId: story.id }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * ADD TO EXISTING — append sid to a highlight's storyIds
   * ============================================================ */
  async function addStoryToExistingHighlight(highlightId, story) {
    if (!highlightId || !story || !story.id) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var h = (window.myHighlights && window.myHighlights[highlightId]) || null;
    if (!h) return false;

    /* Skip if already present ---------------------------- */
    var ids = Array.isArray(h.storyIds) ? h.storyIds.slice() : [];
    if (ids.indexOf(story.id) !== -1) {
      safeToast(T('saved'), 'ok');
      return true;
    }

    ids.push(story.id);

    /* Update cover if the highlight had none and this story
     * carries an image ------------------------------------- */
    var updates = { storyIds: ids };
    if (!h.cover && story.type === 'image' && story.url) {
      updates.cover = story.url;
    }

    try {
      await fbDb.ref('highlights/' + uid + '/' + highlightId).update(updates);
      safeToast(T('saved'), 'ok');
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * REMOVE STORY FROM HIGHLIGHT
   * ============================================================ */
  async function removeStoryFromHighlight(highlightId, sid) {
    if (!highlightId || !sid) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var h = (window.myHighlights && window.myHighlights[highlightId]) || null;
    if (!h) return false;

    var ids = Array.isArray(h.storyIds) ? h.storyIds.filter(function (x) {
      return x !== sid;
    }) : [];

    try {
      await fbDb.ref('highlights/' + uid + '/' + highlightId)
        .update({ storyIds: ids });
      return true;
    } catch (err) {
      return false;
    }
  }

  /* ============================================================
   * RENAME HIGHLIGHT
   * ============================================================ */
  async function renameHighlight(highlightId) {
    if (!highlightId) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var h = (window.myHighlights && window.myHighlights[highlightId]) || null;
    if (!h) return false;

    var name = await askPrompt(T('highlight_name'), h.name || '', 'e.g. Travel');
    if (name == null) return false;
    var trimmed = String(name).trim();
    if (!trimmed) return false;

    try {
      await fbDb.ref('highlights/' + uid + '/' + highlightId)
        .update({ name: trimmed });
      safeToast(T('saved'), 'ok');
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * DELETE HIGHLIGHT
   * ============================================================ */
  async function deleteHighlight(highlightId) {
    if (!highlightId) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var ok = await askConfirm(T('delete'), T('are_you_sure'));
    if (!ok) return false;

    try {
      await fbDb.ref('highlights/' + uid + '/' + highlightId).remove();
      safeToast(T('saved'), 'ok');
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * OPEN HIGHLIGHT — additive viewer entry
   * ============================================================
   * Loads the highlight's stories from the local storiesCache
   * (feature 186), swaps them into window.storyQueue, and hands
   * control to feature 189's showStoryAt(0) so the user can
   * play them like a normal story.
   *
   * Note: highlight stories may be older than 24h and therefore
   * no longer present in storiesCache. Missing ids are silently
   * skipped; if none resolve, we toast t('no_stories').
   * ============================================================ */
  function openHighlight(highlightId) {
    if (!highlightId) return false;

    var h = (window.myHighlights && window.myHighlights[highlightId]) || null;
    if (!h || !Array.isArray(h.storyIds) || !h.storyIds.length) {
      safeToast(T('no_stories'));
      return false;
    }

    var uid   = getMyUid();
    var cache = (window.storiesCache && window.storiesCache[uid]) || [];

    var resolved = [];
    for (var i = 0; i < h.storyIds.length; i++) {
      var sid = h.storyIds[i];
      for (var j = 0; j < cache.length; j++) {
        if (cache[j].id === sid) { resolved.push(cache[j]); break; }
      }
    }

    if (!resolved.length) {
      safeToast(T('no_stories'));
      return false;
    }

    /* Swap the viewer queue + open ---------------------- */
    window.storyUserQueue = [uid];
    window.storyUserIdx   = 0;
    window.storyQueue     = resolved.slice();
    window.storyIndex     = 0;

    safeCall('openOverlay', ['ovStoryViewer']);
    safeCall('buildStoryProgress');
    safeCall('showStoryAt', [0]);
    return true;
  }

  /* ============================================================
   * SNAPSHOT HELPERS
   * ============================================================ */
  function getMap() { return window.myHighlights; }
  function getCount() { return Object.keys(window.myHighlights || {}).length; }

  function listHighlights() {
    var map = window.myHighlights || {};
    var keys = Object.keys(map);
    return keys.map(function (k) { return map[k]; }).sort(function (a, b) {
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.addStoryToHighlight      = addStoryToHighlight;
  window.startHighlightsListener  = startListener;
  window.detachHighlightsListener = detachListener;

  window.SaikoStoryHighlight = {
    /* creation */
    addStory: addStoryToHighlight,
    addToExisting: addStoryToExistingHighlight,

    /* mutation */
    removeStory: removeStoryFromHighlight,
    rename: renameHighlight,
    delete: deleteHighlight,

    /* reading */
    open: openHighlight,
    getMap: getMap,
    getCount: getCount,
    list: listHighlights,

    /* lifecycle */
    startListener: startListener,
    detachListener: detachListener
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 201 — story-highlight ready');
  } catch (e) {}

})();