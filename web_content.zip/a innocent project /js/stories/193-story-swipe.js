/* ============================================================
 * FEATURE:        Story Swipe Gestures
 * FEATURE NUMBER: 193
 * FILE:           js/stories/193-story-swipe.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the touch + mouse gesture layer on the story viewer
 *   (#ovStoryViewer). Detects three separate gesture types
 *   and routes each to the correct handler:
 *
 *     1. TAP
 *          Delegated to the existing .story-tapzone children
 *          (left = prev, right = next). We do NOT wire taps
 *          here — the viewer DOM already contains those zones
 *          and the tap handlers are attached elsewhere
 *          (feature 192).
 *
 *     2. SWIPE (horizontal)
 *          |dx| > 40 AND |dx| > |dy| → showStoryAt(next | prev)
 *
 *     3. LONG-PRESS
 *          400 ms hold without movement → pause. Release or
 *          movement cancels/resumes.
 *          pauseStory / resumeStory are delegated to feature
 *          194 via safeCall so that this file works standalone
 *          (long-press becomes a silent no-op) until 194 is
 *          loaded.
 *
 *   Behaviour preserved 1:1 from the original §28 STORIES
 *   setupStoryGestures() IIFE.
 *
 *   Auto-attach: the IIFE runs at module load and attaches
 *   listeners to #ovStoryViewer if it exists in the DOM (it
 *   does, in index.html).
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §28 STORIES → (function setupStoryGestures(){ … })()
 *
 * DEPENDENCIES (loaded earlier):
 *   - showStoryAt           js/stories/189-story-viewer.js
 *   - pauseStory / resumeStory
 *                           js/stories/194-story-longpress.js
 *                           (safely-called — long-press is a
 *                            silent no-op when 194 is absent)
 *
 * DOM ELEMENTS USED:
 *   #ovStoryViewer     (gesture surface)
 *   .story-reply-bar   (excluded)
 *   .story-reactions   (excluded)
 *   .story-top         (excluded)
 *   .story-foot        (excluded)
 *   .story-viewers-sheet (excluded)
 *
 * FIREBASE PATHS:
 *   none — purely DOM.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoStorySwipe = {
 *     bind, unbind,
 *     isBound,
 *     LONGPRESS_MS, SWIPE_MIN_PX
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var LONGPRESS_MS  = 400;
  var SWIPE_MIN_PX  = 40;

  /* ============================================================
   * STATE
   * ============================================================ */
  var bound = false;
  var startX = 0, startY = 0;
  var touchActive = false;
  var longPressTimer = null;
  var isLongPress = false;
  var moved = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function getOverlay() {
    return document.getElementById('ovStoryViewer');
  }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-swipe] safeCall:', name, e); }
    return undefined;
  }

  function getIndex() {
    return typeof window.storyIndex === 'number' ? window.storyIndex : 0;
  }

  /* ============================================================
   * TARGET GUARD
   * ============================================================
   * Preserved from the original onDown guard:
   *   Ignore gestures that start inside any interactive chrome
   *   element so taps land where the user expects them.
   * ============================================================ */
  function isExcludedTarget(el) {
    if (!el || !el.closest) return false;
    if (el.closest('.story-reply-bar'))        return true;
    if (el.closest('.story-reactions'))        return true;
    if (el.closest('.story-top'))              return true;
    if (el.closest('.story-foot'))             return true;
    if (el.closest('.story-viewers-sheet'))    return true;
    return false;
  }

  /* ============================================================
   * DOWN
   * ============================================================ */
  function onDown(e) {
    var target = e.target;
    if (isExcludedTarget(target)) return;

    var t0 = e.touches ? e.touches[0] : e;
    if (!t0) return;

    startX = t0.clientX;
    startY = t0.clientY;

    touchActive = true;
    moved = false;
    isLongPress = false;

    if (longPressTimer) clearTimeout(longPressTimer);
    longPressTimer = setTimeout(function () {
      longPressTimer = null;
      isLongPress = true;
      safeCall('pauseStory');
      try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}
    }, LONGPRESS_MS);
  }

  /* ============================================================
   * MOVE
   * ============================================================ */
  function onMove(e) {
    if (!touchActive) return;

    var t0 = e.touches ? e.touches[0] : e;
    if (!t0) return;

    var dx = Math.abs(t0.clientX - startX);
    var dy = Math.abs(t0.clientY - startY);

    if (dx > 12 || dy > 12) {
      moved = true;
      if (longPressTimer) {
        clearTimeout(longPressTimer);
        longPressTimer = null;
      }
    }
  }

  /* ============================================================
   * UP — swipe dispatch or long-press release
   * ============================================================ */
  function onUp(e) {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
    if (!touchActive) return;

    var t0 = e.changedTouches ? e.changedTouches[0] : e;
    if (!t0) { touchActive = false; return; }

    var dx = t0.clientX - startX;
    var dy = t0.clientY - startY;
    touchActive = false;

    /* --- Long-press release → resume ------------------ */
    if (isLongPress) {
      safeCall('resumeStory');
      isLongPress = false;
      return;
    }

    /* --- Horizontal swipe → next / prev ---------------- */
    if (moved &&
        Math.abs(dx) > SWIPE_MIN_PX &&
        Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) {
        /* Swipe left → next */
        safeCall('showStoryAt', [getIndex() + 1]);
      } else {
        /* Swipe right → prev */
        var prev = getIndex() - 1;
        if (prev < 0) prev = 0;
        safeCall('showStoryAt', [prev]);
      }
      moved = false;
      return;
    }

    /* Anything else → reset and let tap zones handle it. */
    moved = false;
  }

  /* ============================================================
   * CANCEL
   * ============================================================ */
  function onCancel() {
    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
    if (isLongPress) {
      safeCall('resumeStory');
      isLongPress = false;
    }
    touchActive = false;
    moved = false;
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  function bind() {
    if (bound) return true;
    var ov = getOverlay();
    if (!ov) return false;

    /* Touch ---------------------------------------------- */
    ov.addEventListener('touchstart',  onDown,   { passive: true });
    ov.addEventListener('touchmove',   onMove,   { passive: true });
    ov.addEventListener('touchend',    onUp,     { passive: true });
    ov.addEventListener('touchcancel', onCancel, { passive: true });

    /* Mouse (desktop fallback) --------------------------- */
    ov.addEventListener('mousedown',  onDown);
    ov.addEventListener('mousemove',  onMove);
    ov.addEventListener('mouseup',    onUp);
    ov.addEventListener('mouseleave', onCancel);

    bound = true;
    return true;
  }

  function unbind() {
    var ov = getOverlay();
    if (!ov) return false;

    ov.removeEventListener('touchstart',  onDown);
    ov.removeEventListener('touchmove',   onMove);
    ov.removeEventListener('touchend',    onUp);
    ov.removeEventListener('touchcancel', onCancel);

    ov.removeEventListener('mousedown',  onDown);
    ov.removeEventListener('mousemove',  onMove);
    ov.removeEventListener('mouseup',    onUp);
    ov.removeEventListener('mouseleave', onCancel);

    if (longPressTimer) {
      clearTimeout(longPressTimer);
      longPressTimer = null;
    }
    touchActive = false;
    isLongPress = false;
    moved = false;
    bound = false;
    return true;
  }

  function isBound() { return bound; }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoStorySwipe = {
    bind: bind,
    unbind: unbind,
    isBound: isBound,
    LONGPRESS_MS: LONGPRESS_MS,
    SWIPE_MIN_PX: SWIPE_MIN_PX
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 193 — story-swipe ready');
  } catch (e) {}

})();