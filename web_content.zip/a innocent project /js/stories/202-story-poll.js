/* ============================================================
 * FEATURE:        Story Poll Vote
 * FEATURE NUMBER: 202
 * FILE:           js/stories/202-story-poll.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Provides window.voteStoryPoll(uid, sid, opt) — the write
 *   path that the story viewer (feature 189) invokes when the
 *   user taps an "A" or "B" option on a poll-type story.
 *
 *   Behavior preserved 1:1 from the original §28 STORIES block:
 *
 *     stage.querySelectorAll('[data-sp]').forEach(b =>
 *       b.addEventListener('click', async e => {
 *         e.stopPropagation();
 *         await db.ref('stories/'+s.uid+'/'+s.id+'/votes/'+myUid)
 *                 .set(b.getAttribute('data-sp')).catch(()=>{});
 *         toast('✓', 'ok');
 *       }));
 *
 *   Notes on the semantics preserved:
 *     • The vote key is the raw option id — 'A' or 'B'.
 *     • A repeat click on the SAME option simply overwrites the
 *       same value (idempotent). Clicking the OTHER option
 *       switches the vote. This matches the reference.
 *     • Errors are silently swallowed (matches `.catch(()=>{})`).
 *     • A short '✓' toast is shown on success.
 *
 * FIREBASE PATHS:
 *   stories/{storyUid}/{storyId}/votes/{myUid}   (set)
 *
 * DOM ELEMENTS USED:
 *   none — the viewer passes the option value.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.voteStoryPoll
 *   window.SaikoStoryPoll = { vote, getMyVote, countVotes }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function isValidOption(opt) {
    return opt === 'A' || opt === 'B';
  }

  /* ============================================================
   * VOTE — main entry point
   * ============================================================
   * uid — story owner's uid
   * sid — story id
   * opt — 'A' or 'B'
   * ============================================================ */
  async function vote(uid, sid, opt) {
    if (!uid || !sid || !opt) return false;
    if (!isValidOption(opt)) return false;

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    try {
      await fbDb.ref('stories/' + uid + '/' + sid + '/votes/' + me).set(opt);
      safeToast('✓', 'ok');

      /* Notify subscribers so any listener (e.g. a poll-count UI)
       * can refresh. Additive; does not change original behavior. */
      try {
        window.dispatchEvent(new CustomEvent('saiko:story-poll-voted', {
          detail: { storyUid: uid, storyId: sid, option: opt }
        }));
      } catch (e) {}

      return true;
    } catch (e) {
      /* Original swallowed write errors silently. Preserved. */
      return false;
    }
  }

  /* ============================================================
   * READ HELPERS (additive — do not touch original flow)
   * ============================================================ */
  async function getMyVote(uid, sid) {
    if (!uid || !sid) return null;
    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return null;
    try {
      var snap = await fbDb.ref('stories/' + uid + '/' + sid + '/votes/' + me).get();
      var v = snap.val();
      return isValidOption(v) ? v : null;
    } catch (e) {
      return null;
    }
  }

  async function countVotes(uid, sid) {
    if (!uid || !sid) return { A: 0, B: 0, total: 0 };
    var fbDb = getDB();
    if (!fbDb) return { A: 0, B: 0, total: 0 };
    try {
      var snap = await fbDb.ref('stories/' + uid + '/' + sid + '/votes').get();
      var v = snap.val() || {};
      var a = 0, b = 0;
      Object.keys(v).forEach(function (k) {
        if (v[k] === 'A') a++;
        else if (v[k] === 'B') b++;
      });
      return { A: a, B: b, total: a + b };
    } catch (e) {
      return { A: 0, B: 0, total: 0 };
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.voteStoryPoll = vote;

  window.SaikoStoryPoll = {
    vote: vote,
    getMyVote: getMyVote,
    countVotes: countVotes
  };

  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 202 — story-poll ready');
  } catch (e) {}

})();