/* ============================================================
 * FEATURE:        Story Bar (Premium Design)
 * FEATURE NUMBER: 186
 * FILE:           js/stories/186-story-bar.js
 * ACTION:         REPLACE (v3 — premium story row)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * 1. INJECT PREMIUM STORY CSS
   * ============================================================ */
  (function injectStoryCSS() {
    if (document.getElementById('__saiko_story_css_v3')) return;
    var s = document.createElement('style');
    s.id = '__saiko_story_css_v3';
    s.textContent =
      '#storiesBarWrap{margin-bottom:.9rem;}' +

      '.stories-head{' +
        'display:flex;align-items:center;justify-content:space-between;' +
        'padding:0 .15rem;margin-bottom:.55rem;' +
      '}' +
      '.stories-head-left{' +
        'display:inline-flex;align-items:center;gap:.45rem;' +
        'font-size:1.02rem;font-weight:800;color:#fff;letter-spacing:-.01em;' +
      '}' +
      '.stories-head-left svg{width:1.1rem;height:1.1rem;color:#7c5cff;}' +
      '.stories-head-action{' +
        'display:inline-flex;align-items:center;gap:.3rem;' +
        'font-size:.72rem;font-weight:700;color:#2ecc8f;' +
        'background:none;border:none;padding:.3rem .45rem;' +
        'border-radius:.55rem;cursor:pointer;' +
        '-webkit-tap-highlight-color:transparent;' +
      '}' +
      '.stories-head-action:active{background:rgba(46,204,143,.12);}' +
      '.stories-head-action svg{width:.85rem;height:.85rem;}' +

      '.stories-row{' +
        'display:flex;gap:.7rem;overflow-x:auto;padding:.15rem 0 .5rem;' +
        'scrollbar-width:none;-webkit-overflow-scrolling:touch;' +
      '}' +
      '.stories-row::-webkit-scrollbar{display:none;}' +

      '.story-item{' +
        'display:flex;flex-direction:column;align-items:center;gap:.35rem;' +
        'flex:0 0 auto;width:4.4rem;user-select:none;cursor:pointer;' +
        '-webkit-tap-highlight-color:transparent;' +
      '}' +
      '.story-ring{' +
        'position:relative;width:3.8rem;height:3.8rem;border-radius:50%;' +
        'padding:2.5px;display:flex;align-items:center;justify-content:center;' +
        'background:linear-gradient(140deg,#7c5cff,#3aa0ff,#2ecc8f);' +
        'transition:transform .14s ease;' +
      '}' +
      '.story-ring:active{transform:scale(.93);}' +
      '.story-ring.seen{background:rgba(255,255,255,.12);}' +
      '.story-ring.mine{background:linear-gradient(140deg,#7c5cff,#2ecc8f);}' +
      '.story-ring.mine .addmark{' +
        'position:absolute;right:-.15rem;bottom:-.15rem;' +
        'width:1.25rem;height:1.25rem;border-radius:50%;' +
        'background:#2ecc8f;color:#062014;' +
        'font-size:.9rem;font-weight:800;' +
        'display:flex;align-items:center;justify-content:center;' +
        'border:2px solid #0a0b10;' +
        'box-shadow:0 4px 12px rgba(46,204,143,.5);' +
      '}' +
      '.story-ring .avatar,' +
      '.story-ring > div{' +
        'width:100% !important;height:100% !important;' +
        'border-radius:50% !important;overflow:hidden !important;' +
      '}' +
      '.story-ring img{' +
        'width:100% !important;height:100% !important;object-fit:cover !important;' +
        'border-radius:50% !important;' +
      '}' +
      '.story-name{' +
        'font-size:.66rem;color:#c0c7d4;font-weight:600;' +
        'max-width:4.4rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;' +
        'text-align:center;' +
      '}' +

      /* Add-story tile */
      '.story-item.add-tile .story-ring{' +
        'background:rgba(22,34,54,.6);' +
        'border:1.5px dashed rgba(124,92,255,.5);' +
        'padding:0;' +
      '}' +
      '.story-item.add-tile .story-ring .plus-ic{' +
        'color:#7c5cff;width:1.6rem;height:1.6rem;' +
        'display:flex;align-items:center;justify-content:center;' +
      '}' +

      /* Narrow */
      '@media (max-width:360px){' +
        '.story-item{width:4rem;}' +
        '.story-ring{width:3.4rem;height:3.4rem;}' +
        '.story-name{font-size:.62rem;max-width:4rem;}' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  })();

  var FETCH_LIMIT   = 200;
  var TTL_MS        = 24 * 3600 * 1000;
  var SEEN_PREFIX   = 'saiko_story_seen_';

  var storiesRef = null;
  var storiesCb  = null;

  window.storiesCache = window.storiesCache || {};

  var _storyShuffleSeed = 0;
  var _storyShuffleOrder = null;
  var _lastAppliedStorySeed = -1;

  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[story-bar] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* Inline icons */
  function svgStoriesIcon() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round">' +
      '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4" fill="currentColor" ' +
      'stroke="none" opacity=".9"/></svg>';
  }
  function svgArrowRight() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" ' +
      'stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>';
  }
  function svgPlus() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" ' +
      'stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>';
  }

  function shuffleArray(arr) {
    var a = (arr || []).slice();
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i];
      a[i] = a[j];
      a[j] = t;
    }
    return a;
  }

  function bumpStoryShuffle() {
    _storyShuffleSeed++;
    _storyShuffleOrder = null;
    _lastAppliedStorySeed = -1;
    return _storyShuffleSeed;
  }

  function applyStoryShuffle(uids) {
    if (!uids || !uids.length) return uids || [];
    if (_storyShuffleSeed <= 0) return uids;

    if (_storyShuffleSeed === _lastAppliedStorySeed && _storyShuffleOrder) {
      var currentSet = {};
      for (var i = 0; i < uids.length; i++) currentSet[uids[i]] = true;

      var ordered = [];
      for (var j = 0; j < _storyShuffleOrder.length; j++) {
        var u = _storyShuffleOrder[j];
        if (currentSet[u]) {
          ordered.push(u);
          delete currentSet[u];
        }
      }
      for (var k = 0; k < uids.length; k++) {
        var u2 = uids[k];
        if (currentSet[u2]) {
          ordered.unshift(u2);
          delete currentSet[u2];
        }
      }
      return ordered;
    }

    var shuffled = shuffleArray(uids);
    _storyShuffleOrder = shuffled.slice();
    _lastAppliedStorySeed = _storyShuffleSeed;
    return shuffled;
  }

  function viewedKey(uid, sid) {
    if (!uid || !sid) return false;
    try {
      var raw = localStorage.getItem(SEEN_PREFIX + uid) || '{}';
      var obj = JSON.parse(raw);
      return !!obj[sid];
    } catch (e) {
      return false;
    }
  }

  function markSeen(uid, sid) {
    if (!uid || !sid) return false;
    try {
      var raw = localStorage.getItem(SEEN_PREFIX + uid) || '{}';
      var obj = JSON.parse(raw);
      obj[sid] = 1;
      localStorage.setItem(SEEN_PREFIX + uid, JSON.stringify(obj));
      return true;
    } catch (e) {
      return false;
    }
  }

  function clearSeenForUser(uid) {
    if (!uid) return false;
    try {
      localStorage.removeItem(SEEN_PREFIX + uid);
      return true;
    } catch (e) {
      return false;
    }
  }

  function myStories() {
    var me = getMyUid();
    if (!me) return [];
    return window.storiesCache[me] || [];
  }

  function startStories() {
    if (storiesRef && storiesCb) return true;

    var fbDb = getDB();
    if (!fbDb) return false;

    storiesRef = fbDb.ref('stories')
      .orderByChild('createdAt')
      .limitToLast(FETCH_LIMIT);

    storiesCb = storiesRef.on('value', function (snap) {
      var v = snap.val() || {};
      var out = {};
      var cutoff = timeNow() - TTL_MS;

      Object.keys(v).forEach(function (uid) {
        var items = v[uid] || {};
        var arr = Object.keys(items).map(function (k) {
          return Object.assign({ id: k, uid: uid }, items[k]);
        }).filter(function (x) {
          return (x.createdAt || 0) > cutoff;
        }).sort(function (a, b) {
          return (a.createdAt || 0) - (b.createdAt || 0);
        });
        if (arr.length) out[uid] = arr;
      });

      window.storiesCache = out;

      if (typeof window.currentNav === 'string' &&
          window.currentNav === 'home') {
        renderStoriesBar();
      }
    });

    return true;
  }

  function detachStories() {
    if (storiesRef && storiesCb) {
      try { storiesRef.off('value', storiesCb); } catch (e) {}
    }
    storiesRef = null;
    storiesCb  = null;
    window.storiesCache = {};
    return true;
  }

  /* ============================================================
   * RENDER — Premium story row
   * ============================================================ */
  function renderStoriesBar() {
    var wrap = qs('#storiesBarWrap');
    if (!wrap) return false;

    var me = getMyUid();
    var mp = getMyProfile();
    var mine = myStories();
    var hasMine = mine.length > 0;

    var others = Object.keys(window.storiesCache).filter(function (u) {
      return u !== me;
    });

    others = applyStoryShuffle(others);

    /* Add Story tile — dashed ring with plus */
    var addCell =
      '<div class="story-item add-tile" id="storyAdd">' +
        '<div class="story-ring">' +
          '<span class="plus-ic">' + svgPlus() + '</span>' +
        '</div>' +
        '<div class="story-name">' + esc(T('add_story')) + '</div>' +
      '</div>';

    /* My Story tile — gradient ring */
    var mineCell = hasMine
      ? ('<div class="story-item" data-story-open="' + esc(me) + '">' +
           '<div class="story-ring mine">' +
             avatarHTML(mp && mp.photo, mp && mp.name, 'av-40', me) +
             '<span class="addmark" style="display:none;"></span>' +
           '</div>' +
           '<div class="story-name">' + esc(T('my_story')) + '</div>' +
         '</div>')
      : '';

    /* Others — colored ring based on seen state */
    var othersCells = others.map(function (u) {
      var uinfo = findUser(u) || { name: 'User', photo: '' };
      var items = window.storiesCache[u];
      var last = items[items.length - 1];
      var seen = viewedKey(u, last.id);
      var ringClass = seen ? 'story-ring seen' : 'story-ring';

      return '<div class="story-item" data-story-open="' + esc(u) + '">' +
        '<div class="' + ringClass + '">' +
          avatarHTML(uinfo.photo, uinfo.name, 'av-40', u) +
        '</div>' +
        '<div class="story-name">' + esc(uinfo.name) + '</div>' +
      '</div>';
    }).join('');

    /* Header with "Stories" title + View All action */
    var header =
      '<div class="stories-head">' +
        '<div class="stories-head-left">' + svgStoriesIcon() + ' <span>Stories</span></div>' +
        (others.length
          ? '<button class="stories-head-action" id="storiesViewAll">View all ' + svgArrowRight() + '</button>'
          : '') +
      '</div>';

    wrap.innerHTML =
      header +
      '<div class="stories-row">' +
        addCell + mineCell + othersCells +
      '</div>';

    /* --- Wire Add Story --- */
    var add = qs('#storyAdd', wrap);
    if (add) {
      add.addEventListener('click', function () {
        safeCall('openStoryCreate');
      });
    }

    /* --- Wire each user tile --- */
    qsa('[data-story-open]', wrap).forEach(function (n) {
      n.addEventListener('click', function () {
        safeCall('openStoriesForUser', [n.getAttribute('data-story-open')]);
      });
    });

    /* --- Wire "View all" → open the first other user's stories --- */
    var va = qs('#storiesViewAll', wrap);
    if (va) {
      va.addEventListener('click', function () {
        if (!others.length) return;
        var first = others[0];
        safeCall('openStoriesForUser', [first]);
      });
    }

    return true;
  }

  window.startStories     = startStories;
  window.detachStories    = detachStories;
  window.renderStoriesBar = renderStoriesBar;
  window.myStories        = myStories;
  window.viewedKey        = viewedKey;
  window.markSeen         = markSeen;
  window.bumpStoryShuffle = bumpStoryShuffle;

  window.SaikoStoryBar = {
    start: startStories,
    detach: detachStories,
    render: renderStoriesBar,
    myStories: myStories,
    viewedKey: viewedKey,
    markSeen: markSeen,
    clearSeenForUser: clearSeenForUser,
    bumpShuffle: bumpStoryShuffle,
    getCache: function () { return window.storiesCache; },
    FETCH_LIMIT: FETCH_LIMIT,
    TTL_MS: TTL_MS,
    SEEN_PREFIX: SEEN_PREFIX
  };

  try {
    console.debug('[boot] feature 186 — story-bar ready (v3 — premium)');
  } catch (e) {}

})();