/* ============================================================
 * FEATURE:        Recent Searches
 * FEATURE NUMBER: 096
 * FILE:           js/search/096-recent-searches.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "recent searches" state that the search overlay
 *   shows when the input is empty (the "idle" state):
 *
 *     1. PERSISTENCE
 *          recentSearches array persisted to localStorage under
 *          the key 'saiko_recent_search'.
 *          Max 20 entries, deduped by (q + type), newest first.
 *
 *     2. IDLE RENDER
 *          showSearchIdle() — renders the recent list + a
 *          "Clear all" button into #searchResults.
 *          Each row has:
 *            • a clock icon
 *            • the query text (ellipsis)
 *            • a small ✕ to remove just that entry
 *          Empty → "type to search" hint.
 *
 *     3. CLEAR
 *          #clearRecent button → wipe storage + re-render idle.
 *          [data-rdel=i] → remove a single entry + re-render.
 *
 *     4. ROW CLICK
 *          Populate #globalSearchInput with the entry's q,
 *          restore the type-specific chip as .sel, and call
 *          window.runSearch(q) to run the actual search.
 *
 *   Public functions:
 *     window.saveRecentSearch(q, type)  → void
 *     window.showSearchIdle()           → void
 *     window.clearRecentSearches()      → void (additive)
 *
 *   Behaviour preserved 1:1 from the original §14 block.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH
 *     let recentSearches = [];
 *     try{ … localStorage.getItem('saiko_recent_search') … }
 *     saveRecentSearch(q, type)
 *     showSearchIdle()
 *
 *   Section §11 NAV / §37 topbar
 *     #btnSearch click → showSearchIdle() + attachSearchListener()
 *
 *   Section §14 SEARCH TABS
 *     $('#searchTabs') click → change tab → runSearch(q)
 *     (feature 097 wires the tabs themselves; 096 supplies
 *      the idle and recent-search behaviour they depend on.)
 *
 * DEPENDENCIES (loaded earlier):
 *   - t / esc                     helpers
 *   - svgIcon                     js/nav/045-icon-system.js
 *   - runSearch (097)             js/search/097-search-tabs.js
 *                                 (safely-called)
 *
 * DOM ELEMENTS USED:
 *   #searchResults    (container)
 *   #globalSearchInput (input — set value on row click)
 *   #searchTabs       (chips — restore .sel on row click)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : 'saiko_recent_search'   (read + write)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.recentSearches       (live array — read-only view)
 *   window.saveRecentSearch     (original name preserved)
 *   window.showSearchIdle       (original name preserved)
 *   window.clearRecentSearches  (additive)
 *   window.SaikoRecentSearches = {
 *     get, save, clear, remove,
 *     showIdle, MAX, STORAGE_KEY
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var STORAGE_KEY = 'saiko_recent_search';
  var MAX_ENTRIES = 20;
  var DEFAULT_TYPE = 'users';

  /* ============================================================
   * STATE
   * ============================================================
   * Kept on window as `recentSearches` (the same global name
   * the original used) so any module can read it, but the
   * canonical writers are the helpers below.
   * ============================================================ */
  try {
    var raw = localStorage.getItem(STORAGE_KEY);
    window.recentSearches = raw ? (JSON.parse(raw) || []) : [];
  } catch (e) {
    window.recentSearches = [];
  }

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[recent-searches] safeCall:', name, e); }
    return undefined;
  }
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(window.recentSearches || []));
    } catch (e) {}
  }

  /* ============================================================
   * SAVE — push / promote an entry
   * ============================================================
   * Preserved 1:1 from the original saveRecentSearch(q, type):
   *   • no-op on empty q
   *   • remove existing entry with the SAME q AND type
   *     (so re-searching promotes it to the top rather than
   *      duplicating)
   *   • unshift the new { q, type, at: now() }
   *   • slice(0, 20)
   *   • persist
   * ============================================================ */
  function save(q, type) {
    if (!q) return;
    var t = type || DEFAULT_TYPE;

    var list = (window.recentSearches || []).filter(function (x) {
      return !(x && x.q === q && x.type === t);
    });
    list.unshift({ q: q, type: t, at: timeNow() });
    list = list.slice(0, MAX_ENTRIES);

    window.recentSearches = list;
    persist();
  }

  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * REMOVE / CLEAR
   * ============================================================ */
  function remove(index) {
    var idx = Number(index);
    if (!isFinite(idx) || idx < 0) return false;
    var list = (window.recentSearches || []).slice();
    if (idx >= list.length) return false;
    list.splice(idx, 1);
    window.recentSearches = list;
    persist();
    return true;
  }

  function clear() {
    window.recentSearches = [];
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
  }

  /* ============================================================
   * IDLE RENDER
   * ============================================================
   * Preserved 1:1 from the original showSearchIdle():
   *
   *   if recentSearches.length:
   *     <row with heading "Recent Searches" + "Clear all" btn>
   *     <N rows: [clock icon] q [✕ delete]>
   *   else:
   *     <empty state with search icon + "Type a name to search">
   *
   * Wires:
   *   #clearRecent        → clear() + re-render
   *   [data-rdel=i]       → remove(i) + re-render
   *   [data-ridx=i]       → populate input, restore chip .sel,
   *                          runSearch(q)
   * ============================================================ */
  function showIdle() {
    var box = qs('#searchResults');
    if (!box) return;

    var list = window.recentSearches || [];

    /* ---- No recent searches → hint ---------------------- */
    if (!list.length) {
      box.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('search') + '</span>' +
          '<p>' + esc(T('type_to_search')) + '</p>' +
        '</div>';
      return;
    }

    /* ---- Heading row ------------------------------------ */
    var heading =
      '<div class="row" style="justify-content:space-between;align-items:center;padding:0 .2rem">' +
        '<div class="sec-title" style="margin:0">' + esc(T('recent_searches')) + '</div>' +
        '<button class="btn sm ghost" id="clearRecent">' + esc(T('clear_all')) + '</button>' +
      '</div>';

    /* ---- Rows ------------------------------------------- */
    var rows = list.map(function (r, i) {
      return '<div class="recent-row" data-ridx="' + i + '">' +
        '<span class="ic">' + svgIcon('clock') + '</span>' +
        '<span class="grow ellipsis">' + esc(r.q) + '</span>' +
        '<button data-rdel="' + i + '">✕</button>' +
      '</div>';
    }).join('');

    box.innerHTML = heading + rows;

    /* ---- Clear all -------------------------------------- */
    var clearBtn = qs('#clearRecent', box);
    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        clear();
        showIdle();
      });
    }

    /* ---- Per-row delete --------------------------------- */
    var delNodes = box.querySelectorAll('[data-rdel]');
    for (var d = 0; d < delNodes.length; d++) {
      (function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          var idx = Number(btn.getAttribute('data-rdel'));
          remove(idx);
          showIdle();
        });
      })(delNodes[d]);
    }

    /* ---- Per-row click → re-run search ------------------ */
    var rowNodes = box.querySelectorAll('[data-ridx]');
    for (var k = 0; k < rowNodes.length; k++) {
      (function (row) {
        row.addEventListener('click', function () {
          var idx = Number(row.getAttribute('data-ridx'));
          var r = (window.recentSearches || [])[idx];
          if (!r) return;

          /* 1) Populate the input ------------------------- */
          var input = qs('#globalSearchInput');
          if (input) input.value = r.q;

          /* 2) Restore the tab chip state ----------------- */
          var tab = r.type || DEFAULT_TYPE;
          var chips = document.querySelectorAll('#searchTabs .chip');
          for (var c = 0; c < chips.length; c++) {
            chips[c].classList.toggle(
              'sel',
              chips[c].getAttribute('data-stab') === tab
            );
          }

          /* 3) Run the search ----------------------------- */
          safeCall('runSearch', [r.q]);
        });
      })(rowNodes[k]);
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original globals — preserved so feature 037 (topbar),
   * features 091–095 (search tabs), and any other caller keeps
   * working unchanged. */
  window.saveRecentSearch = save;
  window.showSearchIdle   = showIdle;

  /* Additive convenience */
  window.clearRecentSearches = clear;

  window.SaikoRecentSearches = {
    get: function () { return (window.recentSearches || []).slice(); },
    save: save,
    clear: clear,
    remove: remove,
    showIdle: showIdle,
    MAX: MAX_ENTRIES,
    STORAGE_KEY: STORAGE_KEY
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 096 — recent-searches ready');
  } catch (e) {}

})();