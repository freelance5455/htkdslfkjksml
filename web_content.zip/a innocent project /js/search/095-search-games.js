/* ============================================================
 * FEATURE:        Search Games
 * FEATURE NUMBER: 095
 * FILE:           js/search/095-search-games.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the GAMES tab of the search overlay. Filters the
 *   in-memory gamesCache by a substring match across each
 *   game's title AND description (case-insensitive) and
 *   renders the matches as full game cards (thumbnail + title
 *   + description).
 *
 *   Public function:
 *     window.runGameSearch(box, q) → void
 *
 *   Behaviour preserved 1:1 from the original §14 block:
 *
 *     const list = (gamesCache||[]).filter(g =>
 *       !q || ((g.title||'') + ' ' + (g.description||''))
 *                .toLowerCase().indexOf(q) !== -1
 *     );
 *
 *     if (!list.length) {
 *       box.innerHTML = '<div class="empty">'
 *                     + '<span class="ic">'+svgIcon('game')+'</span>'
 *                     + '<p>'+esc(t('no_games'))+'</p>'
 *                     + '</div>';
 *       return;
 *     }
 *
 *     box.innerHTML = list.map(g => {
 *       const thumb = g.thumbnail
 *         ? '<img class="thumb" src="'+esc(g.thumbnail)+'">'
 *         : '<div class="thumb" style="display:flex;align-items:center;justify-content:center">'
 *           + svgIcon('game') + '</div>';
 *       return '<div class="game-card" data-game="'+esc(g.id)+'">'
 *         + thumb
 *         + '<div class="body">'
 *           + '<h4>'+esc(g.title||'Game')+'</h4>'
 *           + '<div class="muted ellipsis">'+esc(g.description||'')+'</div>'
 *         + '</div>'
 *         + '</div>';
 *     }).join('');
 *
 *     box.querySelectorAll('[data-game]').forEach(n =>
 *       n.addEventListener('click', () => {
 *         saveRecentSearch(q, 'games');
 *         closeOverlay('ovSearch');
 *         openGame(n.getAttribute('data-game'));
 *       }));
 *
 *   Notes on the semantics preserved:
 *     • The original does NOT cap the game-search result set
 *       (games are relatively few compared to posts / reels),
 *       unlike features 092 and 093 which slice(0, 50). We
 *       preserve that — no slice.
 *     • An empty query matches every game — the original's
 *       `!q ||` guard.
 *     • `openGame(id)` is owned by the games feature module
 *       (§24 GAMES); we delegate safely.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH → runGameSearch(box, q)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.gamesCache             js/games/24-games.js
 *                                   (or the games module)
 *   - saveRecentSearch (096)        js/search/096-recent-searches.js
 *   - openOverlay / closeOverlay    js/nav/038-overlay-system.js
 *   - openGame                      the games module
 *   - svgIcon                       js/nav/045-icon-system.js
 *   - t / esc                       helpers
 *
 * DOM ELEMENTS USED:
 *   None owned directly. The caller passes the results
 *   container (typically #searchResults) into runGameSearch.
 *
 * FIREBASE PATHS:
 *   none directly — reads from the shared gamesCache that the
 *   games module maintains via its live listener on `games`.
 *
 * localStorage  : none owned here
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.runGameSearch          (original name preserved)
 *   window.SaikoSearchGames = {
 *     runSearch, filterGames, renderRow
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[search-games] safeCall:', name, e); }
    return undefined;
  }

  function getGamesCache() {
    try {
      if (Array.isArray(window.gamesCache)) return window.gamesCache;
    } catch (e) {}
    return [];
  }

  /* ============================================================
   * FILTER — pure
   * ============================================================
   * Preserved 1:1 from the original filter chain.
   *
   * The match haystack is the concatenation
   *   `(title||'') + ' ' + (description||'')`
   * — so a search for "puzzle" matches both games whose title
   * contains "puzzle" and games whose description mentions
   * "puzzle".
   *
   * An empty query matches every game — the original's
   * `!q ||` guard.
   *
   * NOTE: Unlike features 092 / 093, this filter has NO slice
   * cap — the original did not cap the games result set.
   * ============================================================ */
  function filterGames(q) {
    var needle = String(q || '').toLowerCase();
    var cache = getGamesCache();
    var matchAll = (needle === '');

    return cache.filter(function (g) {
      if (!g) return false;
      if (matchAll) return true;
      var haystack = String(g.title || '') + ' ' + String(g.description || '');
      return haystack.toLowerCase().indexOf(needle) !== -1;
    });
  }

  /* ============================================================
   * RENDER ONE ROW
   * ============================================================
   * Extracted so the exact markup shape is testable and the
   * main renderer stays readable. Preserves:
   *   • .game-card wrapper with data-game
   *   • thumb: <img class="thumb"> when a thumbnail exists,
   *     otherwise a .thumb div with the centred game icon
   *   • .body: <h4> title + .muted.ellipsis description
   * ============================================================ */
  function renderRow(g) {
    var thumb = g.thumbnail
      ? '<img class="thumb" src="' + esc(g.thumbnail) + '" alt="">'
      : '<div class="thumb" style="display:flex;align-items:center;justify-content:center">' +
          svgIcon('game') +
        '</div>';

    return (
      '<div class="game-card" data-game="' + esc(g.id) + '">' +
        thumb +
        '<div class="body">' +
          '<h4>' + esc(g.title || 'Game') + '</h4>' +
          '<div class="muted ellipsis">' + esc(g.description || '') + '</div>' +
        '</div>' +
      '</div>'
    );
  }

  /* ============================================================
   * RUN — main entry
   * ============================================================
   * Preserved 1:1 from the original runGameSearch(box, q).
   * ============================================================ */
  function run(box, qRaw) {
    if (!box) return;

    var q = String(qRaw || '').trim().toLowerCase();

    /* 1) Build the list ----------------------------------- */
    var list = filterGames(q);

    /* 2) Empty state -------------------------------------- */
    if (!list.length) {
      box.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('game') + '</span>' +
          '<p>' + esc(T('no_games')) + '</p>' +
        '</div>';
      return;
    }

    /* 3) Render ------------------------------------------- */
    box.innerHTML = list.map(renderRow).join('');

    /* 4) Wire clicks -------------------------------------- */
    var nodes = box.querySelectorAll('[data-game]');
    for (var i = 0; i < nodes.length; i++) {
      (function (n) {
        n.addEventListener('click', function () {
          var gid = n.getAttribute('data-game');
          safeCall('saveRecentSearch', [q, 'games']);
          safeCall('closeOverlay', ['ovSearch']);
          safeCall('openGame', [gid]);
        });
      })(nodes[i]);
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — used by feature 097's runSearch
   * dispatcher (`searchTab === 'games'`) and by any other
   * caller that wants the exact game-search behaviour. */
  window.runGameSearch = run;

  window.SaikoSearchGames = {
    runSearch: run,
    filterGames: filterGames,
    renderRow: renderRow
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 095 — search-games ready');
  } catch (e) {}

})();