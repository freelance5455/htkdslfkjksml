/* ============================================================
 * FEATURE:        Search Hashtags
 * FEATURE NUMBER: 094
 * FILE:           js/search/094-search-hashtags.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the HASHTAGS tab of the search overlay. Computes the
 *   top trending hashtags from the in-memory postsCache (via
 *   feature 079's extractTags), optionally filters them by a
 *   substring match on the tag itself, and renders a compact
 *   "trend row" per hashtag: 🔥 fire icon, `#tag`, post count,
 *   arrow. Clicking a row opens the hashtag feed overlay.
 *
 *   Public function:
 *     window.runHashtagSearch(box, q) → void
 *
 *   Behaviour preserved 1:1 from the original §14 block:
 *
 *     const tags = trendingTags(30).filter(x =>
 *       !q || x.tag.indexOf(q) !== -1
 *     );
 *
 *     if (!tags.length) {
 *       box.innerHTML = '<div class="empty"><p>'
 *                     + esc(t('no_results'))
 *                     + '</p></div>';
 *       return;
 *     }
 *
 *     box.innerHTML = tags.map(x =>
 *       '<div class="trend-item" data-tagopen="'+esc(x.tag)+'">'
 *         + '<span class="ic" style="color:var(--accent)">'+svgIcon('fire')+'</span>'
 *         + '<div class="grow">'
 *           + '<div class="name">#'+esc(x.tag)+'</div>'
 *           + '<div class="mini">'+x.count+' posts</div>'
 *         + '</div>'
 *         + '<span class="ic" style="color:var(--muted)">'+svgIcon('arrow')+'</span>'
 *         + '</div>'
 *     ).join('');
 *
 *     box.querySelectorAll('[data-tagopen]').forEach(n =>
 *       n.addEventListener('click', () => {
 *         saveRecentSearch(q, 'hashtags');
 *         closeOverlay('ovSearch');
 *         openHashtag(n.getAttribute('data-tagopen'));
 *       }));
 *
 *   Notes on the semantics preserved:
 *     • The candidate set is the top 30 tags by post count,
 *       computed fresh on every call via trendingTags(30).
 *     • The query filter is a substring match on the tag
 *       (no leading '#') — case-sensitive in the original
 *       because trendingTags already lowercases its keys and
 *       the caller lowercases the query, so this is effectively
 *       case-insensitive.
 *     • Empty query returns the full top 30 — the original's
 *       `!q ||` guard.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH → runHashtagSearch(box, q)
 *   Section §26 SAVED / HASHTAGS / TRENDING →
 *     trendingTags(limit) — the trending tag computer
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache             js/feed/051-feed-render.js
 *   - extractTags                   js/feed/079-hashtag-extract.js
 *   - isSuspended                   js/feed/090-suspended-display.js
 *   - trendingTags                  js/feed/074-trending-tags.js
 *                                    (or computed inline here)
 *   - saveRecentSearch (096)        js/search/096-recent-searches.js
 *   - openOverlay / closeOverlay    js/nav/038-overlay-system.js
 *   - openHashtag (080)             js/feed/080-hashtag-open.js
 *   - svgIcon                       js/nav/045-icon-system.js
 *   - t / esc                       helpers
 *
 * DOM ELEMENTS USED:
 *   None owned directly. The caller passes the results
 *   container (typically #searchResults) into runHashtagSearch.
 *
 * FIREBASE PATHS:
 *   none directly — reads from the shared postsCache that
 *   feature 051 maintains via its live listener on `posts`.
 *
 * localStorage  : none owned here
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.runHashtagSearch          (original name preserved)
 *   window.trendingTags              (original name preserved)
 *   window.SaikoSearchHashtags = {
 *     runSearch, filterTags,
 *     trendingTags,
 *     TOP_LIMIT
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var TOP_LIMIT = 30;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[search-hashtags] safeCall:', name, e); }
    return undefined;
  }

  function getPostsCache() {
    try {
      if (Array.isArray(window.postsCache)) return window.postsCache;
    } catch (e) {}
    return [];
  }

  function extractTags(text) {
    try {
      if (typeof window.extractTags === 'function') return window.extractTags(text) || {};
    } catch (e) {}
    return {};
  }

  function isSuspended(obj) {
    try {
      if (typeof window.isSuspended === 'function') return !!window.isSuspended(obj);
    } catch (e) {}
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > Date.now()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > Date.now();
  }

  /* ============================================================
   * TRENDING TAGS — preserved 1:1
   * ============================================================
   * Aggregates hashtag counts across postsCache (skipping
   * suspended posts), returns a descending-by-count array of
   * { tag, count } objects, capped at `limit`.
   *
   * Original source:
   *   const counts = {};
   *   (postsCache||[]).forEach(p => {
   *     if (isSuspended(p)) return;
   *     const tags = extractTags(p.text);
   *     Object.keys(tags).forEach(k => {
   *       counts[k] = (counts[k]||0) + tags[k];
   *     });
   *   });
   *   return Object.keys(counts)
   *     .map(k => ({ tag:k, count:counts[k] }))
   *     .sort((a,b) => b.count - a.count)
   *     .slice(0, limit || 15);
   * ============================================================ */
  function computeTrendingTags(limit) {
    var counts = {};
    var cache = getPostsCache();

    for (var i = 0; i < cache.length; i++) {
      var p = cache[i];
      if (!p) continue;
      if (isSuspended(p)) continue;
      var tags = extractTags(p.text);
      var keys = Object.keys(tags);
      for (var j = 0; j < keys.length; j++) {
        var k = keys[j];
        counts[k] = (counts[k] || 0) + tags[k];
      }
    }

    var out = Object.keys(counts).map(function (k) {
      return { tag: k, count: counts[k] };
    });
    out.sort(function (a, b) { return b.count - a.count; });
    return out.slice(0, limit || 15);
  }

  /* Prefer a globally-provided trendingTags() if one exists
   * (e.g. from feature 034 trending / feature 051), so the
   * source of truth stays single. Fall back to our local
   * implementation otherwise. */
  function trendingTags(limit) {
    try {
      if (typeof window.trendingTags === 'function' &&
          window.trendingTags !== trendingTags) {
        return window.trendingTags(limit);
      }
    } catch (e) {}
    return computeTrendingTags(limit);
  }

  /* ============================================================
   * FILTER — pure
   * ============================================================
   * Preserved 1:1 from the original filter chain.
   *
   * `q` is expected to be lowercased + trimmed by the caller
   * (feature 091's runSearch does this). An empty query
   * matches every tag — the original's `!q ||` guard.
   * ============================================================ */
  function filterTags(q) {
    var needle = String(q || '').toLowerCase();
    var tags = trendingTags(TOP_LIMIT);
    if (!needle) return tags;
    return tags.filter(function (x) {
      return x && x.tag && x.tag.indexOf(needle) !== -1;
    });
  }

  /* ============================================================
   * RENDER ONE ROW
   * ============================================================
   * Extracted so the exact markup shape is testable and the
   * main renderer stays readable. Preserves:
   *   • .trend-item wrapper with data-tagopen
   *   • fire icon in accent colour at start
   *   • grow column: "#tag" name + "<N> posts" mini
   *   • arrow icon at end
   * ============================================================ */
  function renderRow(x) {
    return (
      '<div class="trend-item" data-tagopen="' + esc(x.tag) + '">' +
        '<span class="ic" style="color:var(--accent)">' + svgIcon('fire') + '</span>' +
        '<div class="grow">' +
          '<div class="name">#' + esc(x.tag) + '</div>' +
          '<div class="mini">' + x.count + ' posts</div>' +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('arrow') + '</span>' +
      '</div>'
    );
  }

  /* ============================================================
   * RUN — main entry
   * ============================================================
   * Preserved 1:1 from the original runHashtagSearch(box, q).
   * ============================================================ */
  function run(box, qRaw) {
    if (!box) return;

    var q = String(qRaw || '').trim().toLowerCase();

    /* 1) Build the list ----------------------------------- */
    var list = filterTags(q);

    /* 2) Empty state -------------------------------------- */
    if (!list.length) {
      box.innerHTML =
        '<div class="empty">' +
          '<p>' + esc(T('no_results')) + '</p>' +
        '</div>';
      return;
    }

    /* 3) Render ------------------------------------------- */
    box.innerHTML = list.map(renderRow).join('');

    /* 4) Wire clicks -------------------------------------- */
    var nodes = box.querySelectorAll('[data-tagopen]');
    for (var i = 0; i < nodes.length; i++) {
      (function (n) {
        n.addEventListener('click', function () {
          var tag = n.getAttribute('data-tagopen');
          safeCall('saveRecentSearch', [q, 'hashtags']);
          safeCall('closeOverlay', ['ovSearch']);
          safeCall('openHashtag', [tag]);
        });
      })(nodes[i]);
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original globals — preserved so feature 097's runSearch
   * dispatcher, feature 034 (trending), and any other caller
   * keeps working unchanged. */
  window.runHashtagSearch = run;
  window.trendingTags     = trendingTags;

  window.SaikoSearchHashtags = {
    runSearch: run,
    filterTags: filterTags,
    trendingTags: trendingTags,
    computeTrendingTags: computeTrendingTags,
    renderRow: renderRow,
    TOP_LIMIT: TOP_LIMIT
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 094 — search-hashtags ready');
  } catch (e) {}

})();