/* ============================================================
 * FEATURE:        Search Reels
 * FEATURE NUMBER: 093
 * FILE:           js/search/093-search-reels.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the REELS tab of the search overlay. Filters the
 *   in-memory reelsCache by a substring match across each
 *   reel's text AND author name (case-insensitive) and renders
 *   the matches as compact preview rows: video thumbnail on
 *   the left, author + caption on the right, play icon at the
 *   end.
 *
 *   Public function:
 *     window.runReelsSearch(box, q) → void
 *
 *   Behaviour preserved 1:1 from the original §14 block:
 *
 *     const list = (reelsCache||[])
 *       .filter(r =>
 *         !q ||
 *         ((r.text||'') + ' ' + (r.authorName||''))
 *           .toLowerCase().indexOf(q) !== -1
 *       )
 *       .slice(0, 50);
 *
 *     if (!list.length) {
 *       box.innerHTML = '<div class="empty">'
 *                     + '<span class="ic">'+svgIcon('film')+'</span>'
 *                     + '<p>'+esc(t('no_reels'))+'</p>'
 *                     + '</div>';
 *       return;
 *     }
 *
 *     box.innerHTML = list.map(r => {
 *       const u = findUser(r.uid) || { name: r.authorName||'User',
 *                                      photo: r.authorPhoto||'' };
 *       return '<div class="user-card" data-ropen="'+esc(r.id)+'" style="padding:.5rem">'
 *         + '<video src="'+esc(r.url)+'" muted playsinline preload="metadata" '
 *         + 'style="width:3.5rem;height:4.5rem;object-fit:cover;border-radius:.5rem"></video>'
 *         + '<div class="grow">'
 *           + '<div class="name">'+esc(u.name)+'</div>'
 *           + '<div class="muted ellipsis">'+esc(r.text||'')+'</div>'
 *         + '</div>'
 *         + '<span class="ic" style="color:var(--muted)">'+svgIcon('play')+'</span>'
 *         + '</div>';
 *     }).join('');
 *
 *     box.querySelectorAll('[data-ropen]').forEach(n =>
 *       n.addEventListener('click', () => {
 *         saveRecentSearch(q, 'reels');
 *         closeOverlay('ovSearch');
 *         openReels(n.getAttribute('data-ropen'));
 *       }));
 *
 *   Notes on the semantics preserved:
 *     • An empty query is accepted — the original did NOT
 *       short-circuit empty q; instead it treated it as "match
 *       all" (via the `!q ||` guard). Callers that wish to
 *       avoid that should not invoke this with an empty q.
 *     • The match is on the concatenation
 *         `text + ' ' + authorName`
 *       — so a search for "ali" matches both captions that
 *       contain "ali" and reels authored by someone named
 *       "Ali".
 *     • Result set is capped at 50.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH → runReelsSearch(box, q)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.reelsCache              js/reels/211-reels-feed.js
 *   - findUser                       js/search/091-search-users.js
 *   - saveRecentSearch (096)         js/search/096-recent-searches.js
 *                                    (safely-called)
 *   - openOverlay / closeOverlay     js/nav/038-overlay-system.js
 *   - openReels                      js/reels/211-reels-feed.js
 *                                    (safely-called)
 *   - svgIcon                        js/nav/045-icon-system.js
 *   - t / esc                        helpers
 *
 * DOM ELEMENTS USED:
 *   None owned directly. The caller passes the results
 *   container (typically #searchResults) into runReelsSearch.
 *
 * FIREBASE PATHS:
 *   none directly — reads from the shared reelsCache that the
 *   reels feed maintains via its live listener on `reels`.
 *
 * localStorage  : none owned here
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.runReelsSearch          (original name preserved)
 *   window.SaikoSearchReels = {
 *     runSearch, filterReels, buildList, RESULT_LIMIT
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var RESULT_LIMIT = 50;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[search-reels] safeCall:', name, e); }
    return undefined;
  }
  function findUser(uid) {
    try {
      if (typeof window.findUser === 'function') return window.findUser(uid);
    } catch (e) {}
    return null;
  }

  function getReelsCache() {
    try {
      if (Array.isArray(window.reelsCache)) return window.reelsCache;
    } catch (e) {}
    return [];
  }

  /* ============================================================
   * FILTER — pure
   * ============================================================
   * Preserved 1:1 from the original filter chain.
   *
   * The needle is the raw query as passed by the caller
   * (feature 091's runSearch already lowercases + trims).
   * An empty needle matches every reel — the original's
   * `!q ||` guard.
   * ============================================================ */
  function filterReels(q) {
    var needle = String(q || '').toLowerCase();
    var cache = getReelsCache();
    var matchAll = (needle === '');

    return cache.filter(function (r) {
      if (!r) return false;
      if (matchAll) return true;
      var haystack = String(r.text || '') + ' ' + String(r.authorName || '');
      return haystack.toLowerCase().indexOf(needle) !== -1;
    });
  }

  /* buildList(q) — the exact list the original rendered
   * (filter + slice(0, 50)). */
  function buildList(q) {
    return filterReels(q).slice(0, RESULT_LIMIT);
  }

  /* ============================================================
   * RENDER ONE ROW
   * ============================================================
   * Extracted so the exact markup shape is testable and the
   * main renderer stays readable. Preserves:
   *   • .user-card wrapper with data-ropen
   *   • 3.5rem × 4.5rem video thumb, muted, playsinline,
   *     preload=metadata
   *   • grow column: author name + ellipsis caption
   *   • muted play icon at the end
   * ============================================================ */
  function renderRow(r) {
    var u = findUser(r.uid) || {
      name: r.authorName || 'User',
      photo: r.authorPhoto || ''
    };
    return (
      '<div class="user-card" data-ropen="' + esc(r.id) + '" style="padding:.5rem">' +
        '<video src="' + esc(r.url) + '" muted playsinline preload="metadata" ' +
              'style="width:3.5rem;height:4.5rem;object-fit:cover;border-radius:.5rem"></video>' +
        '<div class="grow">' +
          '<div class="name">' + esc(u.name) + '</div>' +
          '<div class="muted ellipsis">' + esc(r.text || '') + '</div>' +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + svgIcon('play') + '</span>' +
      '</div>'
    );
  }

  /* ============================================================
   * RUN — main entry
   * ============================================================
   * Preserved 1:1 from the original runReelsSearch(box, q).
   * ============================================================ */
  function run(box, qRaw) {
    if (!box) return;

    var q = String(qRaw || '').trim().toLowerCase();

    /* 1) Build the list ----------------------------------- */
    var list = buildList(q);

    /* 2) Empty state -------------------------------------- */
    if (!list.length) {
      box.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('film') + '</span>' +
          '<p>' + esc(T('no_reels')) + '</p>' +
        '</div>';
      return;
    }

    /* 3) Render ------------------------------------------- */
    box.innerHTML = list.map(renderRow).join('');

    /* 4) Wire clicks -------------------------------------- */
    var nodes = box.querySelectorAll('[data-ropen]');
    for (var i = 0; i < nodes.length; i++) {
      (function (n) {
        n.addEventListener('click', function () {
          var rid = n.getAttribute('data-ropen');
          safeCall('saveRecentSearch', [q, 'reels']);
          safeCall('closeOverlay', ['ovSearch']);
          safeCall('openReels', [rid]);
        });
      })(nodes[i]);
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — used by feature 097's runSearch
   * dispatcher (`searchTab === 'reels'`) and by any other
   * caller that wants the exact reels-search behaviour. */
  window.runReelsSearch = run;

  window.SaikoSearchReels = {
    runSearch: run,
    filterReels: filterReels,
    buildList: buildList,
    renderRow: renderRow,
    RESULT_LIMIT: RESULT_LIMIT
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 093 — search-reels ready');
  } catch (e) {}

})();