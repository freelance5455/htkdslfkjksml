/* ============================================================
 * FEATURE:        Search Tabs (Search Dispatcher)
 * FEATURE NUMBER: 097
 * FILE:           js/search/097-search-tabs.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the search-group orchestrator:
 *
 *     1. TAB STATE
 *          window.searchTab — the currently active tab key
 *          ('users' | 'posts' | 'reels' | 'hashtags' | 'games').
 *          Initialised by feature 037 (topbar) and mutated here
 *          when a chip is clicked.
 *
 *     2. TAB CHIP WIRING
 *          #searchTabs click → set searchTab + refresh .sel
 *          + re-run the current query.
 *
 *     3. INPUT DEBOUNCE
 *          #globalSearchInput 'input' → debounced runSearch
 *          (140 ms — the exact original delay).
 *
 *     4. DISPATCH
 *          runSearch(q) → route to the tab-specific searcher:
 *              users    → runUserSearch     (091)
 *              posts    → runPostSearch     (092)
 *              reels    → runReelsSearch    (093)
 *              hashtags → runHashtagSearch  (094)
 *              games    → runGameSearch     (095)
 *          Empty query → showSearchIdle() (096).
 *
 *     5. CLOSE HOOK
 *          document-level delegation for [data-close="ovSearch"]
 *          → detachSearchListener() (the original wired this in
 *          the §14 block).
 *
 *   Behaviour preserved 1:1 from the original §14 dispatcher +
 *   §11 nav wiring.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH
 *     $('#searchTabs') click
 *     $('#globalSearchInput') input (debounced)
 *     runSearch(q) dispatcher
 *     document click → [data-close="ovSearch"] → detachSearchListener
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.searchTab (or default 'users')
 *   - t                                 js/nav/046-i18n.js
 *   - showSearchIdle                    js/search/096-recent-searches.js
 *   - runUserSearch                     js/search/091-search-users.js
 *   - runPostSearch                     js/search/092-search-posts.js
 *   - runReelsSearch                    js/search/093-search-reels.js
 *   - runHashtagSearch                  js/search/094-search-hashtags.js
 *   - runGameSearch                     js/search/095-search-games.js
 *   - detachSearchListener              091
 *
 * DOM ELEMENTS USED:
 *   #searchTabs              (chip container)
 *   [data-stab]              (chips — attribute = tab key)
 *   #globalSearchInput       (input — reads value)
 *   #searchResults           (results container — passed to
 *                             the tab searchers)
 *
 * FIREBASE PATHS:
 *   none — tab dispatch is purely UI, the actual queries
 *   delegate to the tab searchers.
 *
 * localStorage  : none owned here (recent searches are 096)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.searchTab             (kept in sync — 037 owns the
 *                                 initial write, 097 owns the
 *                                 updates from chip clicks)
 *   window.runSearch             (original name preserved)
 *   window.SaikoSearchTabs = {
 *     runSearch, setTab, getTab,
 *     VALID_TABS, DEBOUNCE_MS,
 *     bind, unbind
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var VALID_TABS = ['users', 'posts', 'reels', 'hashtags', 'games'];
  var DEFAULT_TAB = 'users';
  var DEBOUNCE_MS = 140;

  /* ============================================================
   * STATE
   * ============================================================
   * The global `window.searchTab` is initialised by feature 037
   * (topbar) when the search overlay opens. We defend here so
   * the dispatcher works standalone if 037 has not run yet.
   * ============================================================ */
  if (typeof window.searchTab !== 'string' || VALID_TABS.indexOf(window.searchTab) === -1) {
    window.searchTab = DEFAULT_TAB;
  }

  var debounceTimer = null;
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[search-tabs] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * TAB STATE
   * ============================================================ */
  function getTab() {
    return (typeof window.searchTab === 'string') ? window.searchTab : DEFAULT_TAB;
  }

  /* setTab(tab, opts) — updates the active tab and refreshes
   * the .sel classes on the chips.
   *
   * opts.silent → when true, does NOT re-run the query.
   *               Used by feature 096 when restoring a recent
   *               entry (the caller drives the search itself).
   */
  function setTab(tab, opts) {
    if (!tab || VALID_TABS.indexOf(tab) === -1) return false;
    window.searchTab = tab;

    /* Refresh chip highlight ------------------------------ */
    var chips = qsa('#searchTabs .chip');
    for (var i = 0; i < chips.length; i++) {
      chips[i].classList.toggle(
        'sel',
        chips[i].getAttribute('data-stab') === tab
      );
    }

    if (opts && opts.silent) return true;

    /* Re-run the current query under the new tab ---------- */
    var input = qs('#globalSearchInput');
    runSearch(input ? input.value : '');
    return true;
  }

  /* ============================================================
   * DEBOUNCE — same algorithm as feature 051's throttle helper
   * but tuned for the input event (trailing edge).
   * ============================================================ */
  function debounce(fn, ms) {
    return function () {
      var a = arguments, c = this;
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () {
        debounceTimer = null;
        fn.apply(c, a);
      }, ms);
    };
  }

  /* ============================================================
   * RUN SEARCH — dispatcher
   * ============================================================
   * Preserved 1:1 from the original runSearch(qRaw):
   *   • normalise q
   *   • empty → showSearchIdle()
   *   • dispatch by searchTab
   * ============================================================ */
  function runSearch(qRaw) {
    var box = qs('#searchResults');
    if (!box) return;

    var q = String(qRaw || '').trim().toLowerCase();

    /* Empty query → idle state ---------------------------- */
    if (!q) {
      safeCall('showSearchIdle');
      return;
    }

    /* Dispatch by active tab ------------------------------ */
    var tab = getTab();
    switch (tab) {
      case 'users':    safeCall('runUserSearch',    [box, q]); return;
      case 'posts':    safeCall('runPostSearch',    [box, q]); return;
      case 'reels':    safeCall('runReelsSearch',   [box, q]); return;
      case 'hashtags': safeCall('runHashtagSearch', [box, q]); return;
      case 'games':    safeCall('runGameSearch',    [box, q]); return;
      default:
        /* Unknown tab → fall back to the default so the user
         * does not see a blank results pane. */
        window.searchTab = DEFAULT_TAB;
        safeCall('runUserSearch', [box, q]);
        return;
    }
  }

  /* ============================================================
   * CHIP CLICK HANDLER
   * ============================================================ */
  function onTabsClick(e) {
    var c = e.target && e.target.closest ? e.target.closest('[data-stab]') : null;
    if (!c) return;
    var tab = c.getAttribute('data-stab');
    if (!tab || VALID_TABS.indexOf(tab) === -1) return;
    setTab(tab);
  }

  /* ============================================================
   * INPUT HANDLER (debounced)
   * ============================================================ */
  function onInput(e) {
    var v = e && e.target ? e.target.value : '';
    runSearch(v);
  }

  var debouncedInput = debounce(onInput, DEBOUNCE_MS);

  /* ============================================================
   * CLOSE HOOK — [data-close="ovSearch"]
   * ============================================================ */
  function onDocumentClick(e) {
    var c = e.target && e.target.closest ? e.target.closest('[data-close="ovSearch"]') : null;
    if (!c) return;
    safeCall('detachSearchListener');
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  function bind(root) {
    var scope = root || document;
    if (bound) return true;

    var tabs = qs('#searchTabs', scope);
    if (tabs) tabs.addEventListener('click', onTabsClick);

    var input = qs('#globalSearchInput', scope);
    if (input) input.addEventListener('input', debouncedInput);

    /* Document-level close delegation -------------------- */
    document.addEventListener('click', onDocumentClick);

    bound = true;
    return true;
  }

  function unbind(root) {
    if (!bound) return false;

    var tabs = qs('#searchTabs', root || document);
    if (tabs) tabs.removeEventListener('click', onTabsClick);

    var input = qs('#globalSearchInput', root || document);
    if (input) input.removeEventListener('input', debouncedInput);

    document.removeEventListener('click', onDocumentClick);

    if (debounceTimer) {
      clearTimeout(debounceTimer);
      debounceTimer = null;
    }

    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — used by feature 037 (topbar focus flow),
   * feature 096 (recent-search row click), and any other
   * caller that wants the tab-aware dispatch. */
  window.runSearch = runSearch;

  window.SaikoSearchTabs = {
    runSearch: runSearch,
    setTab: setTab,
    getTab: getTab,
    VALID_TABS: VALID_TABS.slice(),
    DEBOUNCE_MS: DEBOUNCE_MS,
    bind: bind,
    unbind: unbind
  };

  /* ============================================================
   * AUTO-BIND
   * Search overlay markup is static in index.html, so binding
   * at DOM ready is safe.
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 097 — search-tabs ready');
  } catch (e) {}

})();