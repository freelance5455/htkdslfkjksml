/* ============================================================
 * FEATURE:        Search Users (Avatar + Sort Fixed)
 * FEATURE NUMBER: 091
 * FILE:           js/search/091-search-users.js
 * ============================================================ */
(function () {
  'use strict';

  /* ============================================================
   * AVATAR HTML — INLINE STYLES (CSS-independent)
   * ============================================================ */
  function makeAvatar(url, name, size) {
    size = size || 40;
    var px = size + 'px';
    var fontSize = Math.round(size * 0.38) + 'px';
    var nm = String(name || 'User').trim();
    var init = (nm.charAt(0) || '?').toUpperCase();
    var hasUrl = url && String(url).trim().length > 0;

    var boxStyle =
      'width:' + px + ';height:' + px + ';' +
      'min-width:' + px + ';min-height:' + px + ';' +
      'border-radius:50%;overflow:hidden;position:relative;' +
      'display:inline-flex;align-items:center;justify-content:center;' +
      'background:#1c2030;color:#8b93a7;' +
      'font-weight:800;font-size:' + fontSize + ';' +
      'border:1.5px solid rgba(255,255,255,.12);flex:0 0 auto;';

    var initSpan =
      '<span style="position:absolute;inset:0;display:flex;' +
      'align-items:center;justify-content:center;' +
      'color:#8b93a7;font-weight:800;font-size:' + fontSize + ';">' +
      esc(init) + '</span>';

    if (hasUrl) {
      return '<div style="' + boxStyle + '">' + initSpan +
        '<img src="' + esc(String(url).trim()) + '" alt="" ' +
        'style="position:absolute;inset:0;width:100%;height:100%;' +
        'object-fit:cover;display:block;" ' +
        'onerror="this.style.display=\'none\';" ' +
        'onload="this.style.display=\'block\';">' +
      '</div>';
    }
    return '<div style="' + boxStyle + '">' + initSpan + '</div>';
  }

  function avatarHTML(url, name, cls, uid) {
    var sizeMap = { 'av-32': 32, 'av-40': 40, 'av-56': 56, 'av-88': 88 };
    var size = sizeMap[cls] || 40;
    var base = makeAvatar(url, name, size);

    if (uid && window.onlineUsers && window.onlineUsers[uid]) {
      return '<span style="position:relative;display:inline-flex;flex:0 0 auto;">' +
        base +
        '<span style="position:absolute;right:-1px;bottom:-1px;width:12px;height:12px;' +
        'border-radius:50%;background:#2ecc8f;' +
        'border:2px solid #101219;display:block;"></span>' +
      '</span>';
    }
    return base;
  }

  /* Global install — this fixes EVERY avatar in the app */
  window.avatarHTML = avatarHTML;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
    });
  }
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function fmtDate(ts) {
    if (!ts) return '—';
    try {
      return new Date(ts).toLocaleDateString(undefined,
        { year:'numeric', month:'short', day:'numeric' });
    } catch (e) { return '—'; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {}
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * STATE
   * ============================================================ */
  var SIMILARITY_THRESHOLD = 62;
  var LENGTH_CUTOFF = 3;
  var RESULT_LIMIT = 80;

  window.allUsersCache = window.allUsersCache || [];
  window.onlineUsers = window.onlineUsers || {};

  var searchListener = null;
  var presenceRefs = {};
  var presenceCbs = {};

  /* ============================================================
   * SIMILARITY
   * ============================================================ */
  function similarity(a, b) {
    if (!a || !b) return 0;
    if (a === b) return 100;
    if (a.indexOf(b) !== -1 || b.indexOf(a) !== -1) return 80;
    var m = a.length, n = b.length;
    if (Math.abs(m - n) > LENGTH_CUTOFF) return 0;
    var dp = new Array(n + 1);
    for (var j = 0; j <= n; j++) dp[j] = j;
    for (var i = 1; i <= m; i++) {
      var prev = dp[0]; dp[0] = i;
      for (var k = 1; k <= n; k++) {
        var tmp = dp[k];
        dp[k] = Math.min(dp[k]+1, dp[k-1]+1, prev + (a.charAt(i-1) === b.charAt(k-1) ? 0 : 1));
        prev = tmp;
      }
    }
    return Math.max(0, 100 - Math.round((dp[n] / Math.max(m, n)) * 100));
  }

  /* ============================================================
   * PRESENCE
   * ============================================================ */
  function watchPresence(uids) {
    var want = {};
    (uids || []).forEach(function (u) {
      if (u && u !== getMyUid()) want[u] = true;
    });
    Object.keys(presenceRefs).forEach(function (k) {
      if (!want[k]) {
        try { presenceRefs[k].off('value', presenceCbs[k]); } catch (e) {}
        delete presenceRefs[k];
        delete presenceCbs[k];
      }
    });
    var fbDb = getDB();
    if (!fbDb) return;
    Object.keys(want).forEach(function (u) {
      if (presenceRefs[u]) return;
      var ref = fbDb.ref('users/' + u + '/online');
      var cb = ref.on('value', function (s) { window.onlineUsers[u] = !!s.val(); });
      presenceRefs[u] = ref;
      presenceCbs[u] = cb;
    });
  }

  function detachUserPresence() {
    Object.keys(presenceRefs).forEach(function (k) {
      try { presenceRefs[k].off('value', presenceCbs[k]); } catch (e) {}
    });
    presenceRefs = {};
    presenceCbs = {};
  }

  /* ============================================================
   * LOOKUP HELPERS
   * ============================================================ */
  function findUser(uid) {
    if (!uid) return null;
    var arr = window.allUsersCache || [];
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] && arr[i].uid === uid) return arr[i];
    }
    return null;
  }
  function userName(uid) { var u = findUser(uid); return (u && u.name) || 'User'; }
  function userPhoto(uid) { var u = findUser(uid); return (u && u.photo) || ''; }
  function getAllUsers() { return (window.allUsersCache || []).slice(); }

  /* ============================================================
   * LISTENER
   * ============================================================ */
  function attachSearchListener() {
    detachSearchListener();
    var fbDb = getDB();
    if (!fbDb) return false;

    var ref = fbDb.ref('users');
    var cb = ref.on('value', function (snap) {
      var val = snap.val() || {};
      var arr = Object.keys(val).map(function (k) {
        return Object.assign({ uid: k }, val[k]);
      });
      arr.sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      window.allUsersCache = arr;
      watchPresence(Object.keys(val));
      try {
        window.dispatchEvent(new CustomEvent('saiko:users-cache-updated', {
          detail: { count: arr.length }
        }));
      } catch (e) {}
    }, function (err) {
      var box = document.querySelector('#searchResults');
      if (box) box.innerHTML = '<div class="banner">' + esc(err && err.message || '') + '</div>';
    });

    searchListener = { ref: ref, cb: cb };
    return true;
  }

  function detachSearchListener() {
    if (searchListener) {
      try { searchListener.ref.off('value', searchListener.cb); } catch (e) {}
      searchListener = null;
    }
  }

  /* ============================================================
   * USER SEARCH — sort state
   * ============================================================ */
  var sortOrder = 'newest';

  function renderUserSearch(box, qRaw) {
    if (!box) return;
    var q = String(qRaw || '').trim().toLowerCase();
    if (!q) return;

    if (!window.allUsersCache || !window.allUsersCache.length) {
      box.innerHTML = '<div style="height:3.4rem;margin-bottom:.5rem;' +
        'background:linear-gradient(90deg,#161923 25%,#1c2030 50%,#161923 75%);' +
        'background-size:200% 100%;border-radius:.7rem;animation:sk 1.3s infinite;"></div>'
        .repeat(3);
      return;
    }

    var me = getMyUid();
    var nowTs = timeNow();
    var exact = [], partial = [];

    window.allUsersCache.forEach(function (u) {
      if (!u) return;
      if (u.uid === me) return;
      if (u.blockedUntil && Number(u.blockedUntil) > nowTs) return;
      var n = (u.searchName || (u.name || '').toLowerCase());
      if (!n) return;
      if (n === q) exact.push(u);
      else if (n.indexOf(q) !== -1) partial.push(u);
      else {
        var sim = similarity(n, q);
        if (sim >= SIMILARITY_THRESHOLD) {
          partial.push(Object.assign({}, u, { __sim: sim }));
        }
      }
    });

    function byDate(a, b) {
      var aT = a.createdAt || 0, bT = b.createdAt || 0;
      return sortOrder === 'newest' ? bT - aT : aT - bT;
    }

    exact.sort(byDate);
    partial.sort(function (a, b) {
      var an = a.searchName || '', bn = b.searchName || '';
      var ap = an.indexOf(q), bp = bn.indexOf(q);
      var aH = ap !== -1, bH = bp !== -1;
      if (aH !== bH) return aH ? -1 : 1;
      if (aH && bH) {
        if (ap !== bp) return ap - bp;
        if (an.length !== bn.length) return an.length - bn.length;
      } else {
        var as = a.__sim || 0, bs = b.__sim || 0;
        if (as !== bs) return bs - as;
      }
      return byDate(a, b);
    });

    var list = exact.concat(partial).slice(0, RESULT_LIMIT);

    /* ---- Header with sort filter ------------------------------ */
    var header =
      '<div style="display:flex;justify-content:space-between;align-items:center;' +
      'margin-bottom:.6rem;padding:0 .2rem;">' +
        '<div style="font-size:.72rem;color:#8b93a7;">' +
          list.length + ' user' + (list.length === 1 ? '' : 's') +
        '</div>' +
        '<select id="userSortFilter" style="width:auto;' +
          'padding:.35rem .55rem;font-size:.72rem;border-radius:.6rem;' +
          'background:#1c2030;color:#eef1f8;' +
          'border:1px solid rgba(255,255,255,.12);outline:none;">' +
          '<option value="newest"' + (sortOrder === 'newest' ? ' selected' : '') + '>Sort: Newest</option>' +
          '<option value="oldest"' + (sortOrder === 'oldest' ? ' selected' : '') + '>Sort: Oldest</option>' +
        '</select>' +
      '</div>';

    if (!list.length) {
      box.innerHTML = header +
        '<div style="text-align:center;padding:2.4rem 1rem;color:#8b93a7;">' +
          '<p>' + esc(T('no_results') || 'No users found') + '</p>' +
        '</div>';
      wireSort(box, q);
      return;
    }

    /* ---- Cards with INLINE avatar + info ---------------------- */
    var cards = list.map(function (u) {
      var online = window.onlineUsers && window.onlineUsers[u.uid];
      var statusColor = online ? '#2ecc8f' : '#8b93a7';
      var statusText = online ? (T('online') || 'Online') : (T('offline') || 'Offline');
      var avatarEl = makeAvatar(u.photo || '', u.name || 'User', 40);

      return '<div class="user-card" data-uid="' + esc(u.uid) + '" ' +
        'style="display:flex;align-items:center;gap:.7rem;padding:.65rem;' +
        'border-radius:.9rem;border:1px solid rgba(255,255,255,.08);' +
        'background:#161923;margin-bottom:.5rem;cursor:pointer;">' +
        avatarEl +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-weight:700;font-size:.9rem;color:#eef1f8;' +
            'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' +
            esc(u.name || 'User') +
          '</div>' +
          '<div style="font-size:.76rem;color:#8b93a7;' +
            'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' +
            esc((u.bio || '').slice(0, 80) || '—') +
          '</div>' +
          '<div style="font-size:.7rem;color:#8b93a7;margin-top:.15rem;">' +
            esc(T('joining') || 'Joined') + ': ' + esc(fmtDate(u.createdAt)) +
            ' · <span style="color:' + statusColor + ';font-weight:700;">● ' +
            esc(statusText) + '</span>' +
          '</div>' +
        '</div>' +
        '<span style="color:#8b93a7;font-size:1.2rem;">›</span>' +
      '</div>';
    }).join('');

    box.innerHTML = header + cards;
    wireSort(box, q);

    /* ---- Wire click → profile --------------------------------- */
    var nodes = box.querySelectorAll('.user-card');
    for (var i = 0; i < nodes.length; i++) {
      (function (card) {
        card.addEventListener('click', function () {
          var uid = card.getAttribute('data-uid');
          safeCall('saveRecentSearch', [q, 'users']);
          safeCall('closeOverlay', ['ovSearch']);
          detachSearchListener();
          setTimeout(function () { safeCall('openUserProfile', [uid]); }, 100);
        });
      })(nodes[i]);
    }
  }

  function wireSort(box, q) {
    var sel = box.querySelector('#userSortFilter');
    if (!sel) return;
    sel.addEventListener('change', function () {
      sortOrder = sel.value;
      renderUserSearch(box, q);
    });
  }

  /* ============================================================
   * EXPORT
   * ============================================================ */
  window.similarity           = similarity;
  window.findUser             = findUser;
  window.userName             = userName;
  window.userPhoto            = userPhoto;
  window.watchPresence        = watchPresence;
  window.detachUserPresence   = detachUserPresence;
  window.attachSearchListener = attachSearchListener;
  window.detachSearchListener = detachSearchListener;
  window.runUserSearch        = renderUserSearch;

  window.SaikoSearchUsers = {
    similarity: similarity,
    findUser: findUser,
    userName: userName,
    userPhoto: userPhoto,
    getAllUsers: getAllUsers,
    watchPresence: watchPresence,
    detachUserPresence: detachUserPresence,
    attachListener: attachSearchListener,
    detachListener: detachSearchListener,
    runSearch: renderUserSearch,
    SIMILARITY_THRESHOLD: SIMILARITY_THRESHOLD,
    RESULT_LIMIT: RESULT_LIMIT
  };

  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 091 — search-users ready (avatar+sort fix)');
  } catch (e) {}

})();