/* ============================================================
 * FEATURE:        Search Posts
 * FEATURE NUMBER: 092
 * FILE:           js/search/092-search-posts.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the POSTS tab of the search overlay. Filters the
 *   in-memory postsCache by a substring match on each post's
 *   text (case-insensitive) and renders the matches as full
 *   feed-style post cards.
 *
 *   Public function:
 *     window.runPostSearch(box, q) → void
 *
 *   Behaviour preserved 1:1 from the original §14 block:
 *
 *     const list = (postsCache||[])
 *       .filter(p =>
 *         !isSuspended(p) &&
 *         !p.hidden &&
 *         (p.text||'').toLowerCase().indexOf(q) !== -1
 *       )
 *       .slice(0, 50);
 *
 *     if (!list.length) {
 *       box.innerHTML = '<div class="empty"><p>'
 *                     + esc(t('no_posts'))
 *                     + '</p></div>';
 *       return;
 *     }
 *
 *     box.innerHTML = list.map(postHTML).join('');
 *     wirePostInteractions(box);
 *     paintPostCounts();
 *
 *   Notes on the semantics preserved:
 *     • `q` is expected to already be lowercased + trimmed by
 *       the caller (feature 091's runSearch does this).
 *     • Suspended posts (`isSuspended`) are hidden.
 *     • Posts explicitly marked `hidden: true` are hidden.
 *       (User-specific hiddenPosts filtering is a feed-render
 *       concern, not a search concern — the original does not
 *       apply it here.)
 *     • Result set is capped at 50.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §14 USER CACHE / SEARCH → runPostSearch(box, q)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.postsCache              js/feed/051-feed-render.js
 *   - isSuspended                    js/feed/090-suspended-display.js
 *                                     (or 051 fallback)
 *   - window.postHTML                js/feed/post-card.js
 *   - window.wirePostInteractions    js/feed/post-card.js
 *   - paintPostCounts                js/feed/051-feed-render.js
 *   - t / esc                        helpers
 *
 * DOM ELEMENTS USED:
 *   None owned directly. The caller passes the results
 *   container (typically #searchResults) into runPostSearch.
 *
 * FIREBASE PATHS:
 *   none directly — reads from the shared postsCache that
 *   feature 051 maintains via its live listener on `posts`.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.runPostSearch          (original name preserved)
 *   window.SaikoSearchPosts = {
 *     runSearch, filterPosts, buildList, RESULT_LIMIT
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var RESULT_LIMIT = 50;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[search-posts] safeCall:', name, e); }
    return undefined;
  }

  function getPostsCache() {
    try {
      if (Array.isArray(window.postsCache)) return window.postsCache;
    } catch (e) {}
    return [];
  }

  /* Resolve the suspension predicate — prefers feature 090's
   * global, falls back to a local copy so the module works
   * before 051 / 090 have loaded. */
  function isSuspended(obj) {
    try {
      if (typeof window.isSuspended === 'function') {
        return !!window.isSuspended(obj);
      }
    } catch (e) {}

    /* Fallback — byte-for-byte from the original §15 FEED. */
    if (!obj) return false;
    if (obj.suspended === true) {
      var u = Number(obj.suspendedUntil);
      if (u === -1) return true;
      if (!u) return true;
      if (u > Date.now()) return true;
      return false;
    }
    var until = Number(obj.suspendedUntil || 0);
    if (until === -1) return true;
    return until > Date.now();
  }

  /* ============================================================
   * FILTER — pure
   * ============================================================
   * Preserved 1:1 from the original filter chain.
   * The caller is expected to have already lowercased + trimmed
   * the query (feature 091's runSearch does exactly this).
   * ============================================================ */
  function filterPosts(q) {
    var needle = String(q || '').toLowerCase();
    var cache = getPostsCache();

    return cache.filter(function (p) {
      if (!p) return false;
      if (isSuspended(p)) return false;
      if (p.hidden) return false;
      var text = (p.text || '').toLowerCase();
      return text.indexOf(needle) !== -1;
    });
  }

  /* buildList(q) — the exact list the original rendered
   * (filter + slice(0, 50)). */
  function buildList(q) {
    return filterPosts(q).slice(0, RESULT_LIMIT);
  }

  /* ============================================================
   * RUN — main entry
   * ============================================================
   * Preserved 1:1 from the original runPostSearch(box, q).
   * ============================================================ */
  function run(box, qRaw) {
    if (!box) return;

    var q = String(qRaw || '').trim().toLowerCase();

    /* 1) Build the list ----------------------------------- */
    var list = q ? buildList(q) : [];

    /* 2) Empty state -------------------------------------- */
    if (!list.length) {
      box.innerHTML =
        '<div class="empty">' +
          '<p>' + esc(T('no_posts')) + '</p>' +
        '</div>';
      return;
    }

    /* 3) Render ------------------------------------------- */
    var html = list.map(function (p) {
      try {
        if (typeof window.postHTML === 'function') return window.postHTML(p);
      } catch (e) {}
      return '';
    }).join('');
    box.innerHTML = html;

    /* 4) Wire interactions + counts ----------------------- */
    safeCall('wirePostInteractions', [box]);
    safeCall('paintPostCounts');
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original global — used by feature 097's runSearch
   * dispatcher (`searchTab === 'posts'`) and by any other
   * caller that wants the exact post-search behaviour. */
  window.runPostSearch = run;

  window.SaikoSearchPosts = {
    runSearch: run,
    filterPosts: filterPosts,
    buildList: buildList,
    RESULT_LIMIT: RESULT_LIMIT
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 092 — search-posts ready');
  } catch (e) {}

})();