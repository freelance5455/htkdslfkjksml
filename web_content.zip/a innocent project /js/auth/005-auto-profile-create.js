/* ============================================================
 * FEATURE:        Auto Profile Creation
 * FEATURE NUMBER: 005
 * FILE:           js/auth/005-auto-profile-create.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   When a Firebase Auth user exists but has no matching
 *   profile node under `users/{uid}` in Realtime Database,
 *   this module creates a default profile document so the
 *   rest of the app can boot cleanly.
 *
 *   Exposes:
 *     window.createAutoProfile(user)
 *         -> called by auth-state (feature 004) whenever the
 *            profile listener finds no data.
 *         -> also callable by any sibling module.
 *
 *     window.SaikoAutoProfile.ensure(uid, userInfo?)
 *         -> programmatic ensure-by-uid (used by admin tools,
 *            signup recovery, etc.)
 *
 *   Default field set is preserved EXACTLY as in the original
 *   index.html §10 profileCb fallback branch:
 *     uid, name, searchName, email, photo, cover, bio, dob,
 *     relationship, online, lastSeen, createdAt, updatedAt,
 *     xp, level
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10 AUTH → profileCb →  if (!v) { db.ref(
 *       'users/' + myUid).set({ ...defaults }); return; }
 *
 * DEPENDENCIES (loaded earlier):
 *   - db          Firebase Realtime Database instance
 *   - now()       Timestamp helper (falls back to Date.now)
 *   - myProfile   global (updated elsewhere; not required)
 *
 * DOM ELEMENTS USED:
 *   none  (pure data-layer module)
 *
 * FIREBASE PATHS:
 *   RTDB : users/{uid}            (write defaults if missing)
 *          users/{uid}/online     (write true)
 *          users/{uid}/lastSeen   (write now)
 *          users/{uid}/createdAt  (write now)
 *          users/{uid}/updatedAt  (write now)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.createAutoProfile(user)
 *   window.SaikoAutoProfile = {
 *     ensure,
 *     ensureOnce,
 *     exists,
 *     buildDefaults
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) {}
    return Date.now();
  }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * In-flight dedupe — prevents duplicate writes when the
   * profile listener fires multiple times quickly on boot.
   * key = uid, value = Promise
   * ---------------------------------------------------------- */
  const inflight = new Map();

  /* ----------------------------------------------------------
   * BUILD DEFAULT PROFILE
   * Returns the exact field set used in the original source.
   * ---------------------------------------------------------- */
  function buildDefaults(uid, userInfo) {
    userInfo = userInfo || {};
    const email = userInfo.email || '';
    const rawName = (userInfo.name && String(userInfo.name).trim())
      || (email ? email.split('@')[0] : '')
      || 'User';
    const name = rawName;
    const created = timeNow();

    return {
      uid: uid,
      name: name,
      searchName: name.toLowerCase(),
      email: email,
      photo: '',
      cover: '',
      bio: '',
      dob: '',
      relationship: '',
      online: true,
      lastSeen: created,
      createdAt: created,
      updatedAt: created,
      xp: 0,
      level: 1
    };
  }

  /* ----------------------------------------------------------
   * EXISTS
   * Returns true if users/{uid} already has data.
   * ---------------------------------------------------------- */
  async function exists(uid) {
    if (!uid) return false;
    const fbDb = getDB();
    if (!fbDb) return false;
    try {
      const snap = await fbDb.ref('users/' + uid).get();
      return snap.exists();
    } catch (e) {
      console.warn('[auto-profile] exists check failed', e);
      return false;
    }
  }

  /* ----------------------------------------------------------
   * ENSURE
   * Create the profile node ONLY if it does not already exist.
   * Returns the created (or existing) profile object.
   * Deduped by uid.
   * ---------------------------------------------------------- */
  function ensure(uid, userInfo) {
    if (!uid) return Promise.resolve(null);

    if (inflight.has(uid)) return inflight.get(uid);

    const p = (async function () {
      const fbDb = getDB();
      if (!fbDb) return null;

      try {
        /* 1) Already present? → read and return ------------ */
        const snap = await fbDb.ref('users/' + uid).get();
        if (snap.exists()) {
          return snap.val();
        }

        /* 2) Build defaults + write atomically -------------- */
        const defaults = buildDefaults(uid, userInfo);

        // Use update() with root-relative paths so we can also
        // touch sibling indexing nodes in a future iteration
        // without adding another network round-trip.
        // For now it maps 1:1 to writing users/{uid}.
        await fbDb.ref('users/' + uid).set(defaults);

        /* 3) Emit an event so interested modules can react --- */
        try {
          window.dispatchEvent(new CustomEvent('saiko:profile-created', {
            detail: { uid: uid, profile: defaults }
          }));
        } catch (e) {}

        return defaults;
      } catch (err) {
        console.warn('[auto-profile] ensure failed', err);
        return null;
      } finally {
        inflight.delete(uid);
      }
    })();

    inflight.set(uid, p);
    return p;
  }

  /* ----------------------------------------------------------
   * ENSURE ONCE
   * Synchronous guard wrapper — fires ensure() and forgets.
   * Useful for fire-and-forget call sites.
   * ---------------------------------------------------------- */
  function ensureOnce(uid, userInfo) {
    // Fire and forget — errors are logged inside ensure()
    ensure(uid, userInfo).catch(function () {});
  }

  /* ----------------------------------------------------------
   * PRIMARY ENTRY — called by auth-state (feature 004)
   *
   * `user` is a Firebase Auth User object. We extract only
   * the fields we care about so this function is robust even
   * if it's called with a plain object (e.g. from admin tools
   * or tests).
   * ---------------------------------------------------------- */
  function createAutoProfile(user) {
    if (!user) return Promise.resolve(null);

    const uid = user.uid || user.userId;
    if (!uid) return Promise.resolve(null);

    const info = {
      email: user.email || '',
      name:  user.displayName || ''
    };

    return ensure(uid, info);
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.createAutoProfile = createAutoProfile;

  window.SaikoAutoProfile = {
    ensure: ensure,
    ensureOnce: ensureOnce,
    exists: exists,
    buildDefaults: buildDefaults
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * (Single console line so we can verify load order during
   *  the migration without touching app behavior.)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 005 — auto-profile-create ready');
  } catch (e) {}

})();