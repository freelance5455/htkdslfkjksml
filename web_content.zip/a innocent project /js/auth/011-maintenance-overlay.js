/* ============================================================
 * FEATURE:        Maintenance Mode Overlay
 * FEATURE NUMBER: 011
 * FILE:           js/auth/011-maintenance-overlay.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Admin-controlled global maintenance screen.
 *
 *   - Subscribes to Firebase RTDB path appConfig/webApp
 *     (shape: { enabled: boolean, message?: string }).
 *   - When enabled === false → shows #maintenanceOverlay for
 *     every user EXCEPT admins (isAdmin bypass).
 *   - When enabled !== false → hides the overlay.
 *   - Writes the admin-supplied message into #maintMsg
 *     (falling back to the original default copy).
 *   - Wires the #maintRetry button → location.reload().
 *
 *   The overlay HTML (#maintenanceOverlay) itself lives in
 *   index.html and is untouched; this module only toggles its
 *   display and text.
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §13 ADMIN → applyWebAppState()
 *   - Section §13 ADMIN → startWebAppConfigListener()
 *   - Section §35 BOOT  → #maintRetry click → location.reload()
 *   - Globals: webAppEnabled, webAppMessage
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - db             Firebase Realtime Database (firebase-init)
 *   - myProfile      global current-user profile (has isAdmin
 *                    or admin === true for admins)
 *   - (optional)     SaikoAuthState for reactive re-eval
 *
 * DOM ELEMENTS USED:
 *   #maintenanceOverlay       (show/hide)
 *   #maintMsg                 (message text)
 *   #maintRetry               (reload button)
 *
 * FIREBASE PATHS:
 *   RTDB : appConfig/webApp           (read + listen)
 *          appConfig/webApp/enabled   (boolean)
 *          appConfig/webApp/message   (string)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.applyWebAppState
 *   window.startWebAppConfigListener
 *   window.SaikoMaintenanceOverlay = {
 *     start, stop,
 *     applyState,
 *     isEnabled,
 *     getMessage,
 *     isAdmin,
 *     bind
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  const DEFAULT_MESSAGE =
    'WebApp is currently under maintenance. Please come back later.';

  const PATH_ROOT    = 'appConfig/webApp';
  const PATH_ENABLED = PATH_ROOT + '/enabled';
  const PATH_MESSAGE = PATH_ROOT + '/message';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * Admin detection — mirrors the original one-liner check:
   *   const isAdmin = myProfile && (myProfile.isAdmin === true
   *                    || myProfile.admin === true);
   * ---------------------------------------------------------- */
  function isAdmin() {
    try {
      const p = (typeof myProfile !== 'undefined') ? myProfile : null;
      return !!(p && (p.isAdmin === true || p.admin === true));
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * Local state (module-scoped; the original kept these as
   * globals webAppEnabled / webAppMessage. We expose getters
   * rather than leaking globals.)
   * ---------------------------------------------------------- */
  let _enabled = true;   // default: web app is enabled
  let _message = '';

  function isEnabled() { return !!_enabled; }
  function getMessage() { return _message || ''; }

  /* ----------------------------------------------------------
   * applyWebAppState
   * Behaviour preserved 1:1 from the original applyWebAppState().
   *   - overlay is hidden when enabled OR the current user is
   *     an admin
   *   - overlay is shown otherwise
   *   - message element gets the admin message (or default)
   * ---------------------------------------------------------- */
  function applyWebAppState() {
    const o = document.getElementById('maintenanceOverlay');
    if (!o) return;

    /* 1) Message text -------------------------------------- */
    const msgEl = o.querySelector('#maintMsg');
    if (msgEl) {
      msgEl.textContent = _message || DEFAULT_MESSAGE;
    }

    /* 2) Visibility decision ------------------------------- */
    const show = (!_enabled && !isAdmin());
    o.style.display = show ? 'flex' : 'none';
  }

  /* ----------------------------------------------------------
   * Update internal state from a Firebase snapshot object.
   * Kept separate so both the listener and the initial .get()
   * use identical parsing.
   * ---------------------------------------------------------- */
  function applySnapshot(v) {
    const val = v || {};
    _enabled = (val.enabled !== false);          // default true
    _message = (typeof val.message === 'string') ? val.message : '';
    applyWebAppState();
  }

  /* ----------------------------------------------------------
   * START — attach the live listener + do one initial read
   * Behaviour preserved 1:1 from startWebAppConfigListener().
   * ---------------------------------------------------------- */
  let ref = null;
  let cb = null;
  let started = false;

  function start() {
    if (started) return true;
    const fbDb = getDB();
    if (!fbDb) return false;
    started = true;

    try {
      /* 1) Live listener ---------------------------------- */
      ref = fbDb.ref(PATH_ROOT);
      cb = ref.on('value', function (snap) {
        applySnapshot(snap.val());
      }, function (err) {
        // Non-fatal — keep the overlay hidden on read errors.
        // Matches the original behavior where a read error
        // does not force the maintenance screen.
        console.warn('[maintenance] listener error', err);
      });

      /* 2) One-shot initial read (guarantees correct state
       *    even if the live event is delayed) -------------- */
      fbDb.ref(PATH_ROOT).get().then(function (snap) {
        applySnapshot(snap.val());
      }).catch(function () {});

      return true;
    } catch (e) {
      console.warn('[maintenance] start failed', e);
      started = false;
      return false;
    }
  }

  /* ----------------------------------------------------------
   * STOP — detach the listener (used on logout / teardown)
   * ---------------------------------------------------------- */
  function stop() {
    if (ref && cb) {
      try { ref.off('value', cb); } catch (e) {}
    }
    ref = null;
    cb = null;
    started = false;
  }

  /* ----------------------------------------------------------
   * BIND — wire #maintRetry → location.reload()
   * Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind() {
    const btn = qs('#maintRetry');
    if (!btn) return false;
    if (btn.dataset.maintRetryBound === '1') return true;
    btn.dataset.maintRetryBound = '1';
    btn.addEventListener('click', function () {
      try { location.reload(); } catch (e) {}
    });
    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.applyWebAppState = applyWebAppState;
  window.startWebAppConfigListener = start;

  window.SaikoMaintenanceOverlay = {
    start: start,
    stop: stop,
    applyState: applyWebAppState,
    isEnabled: isEnabled,
    getMessage: getMessage,
    isAdmin: isAdmin,
    bind: bind
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Wires the reload button as soon as the DOM is ready.
   * Does NOT start the listener — that is the boot module's
   * job (startGlobalListeners) so we preserve original order.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * React to login/logout so admin bypass updates reactively.
   * Auth-state module dispatches 'saiko:login' / 'saiko:logout'
   * CustomEvents; we re-evaluate the overlay on those.
   * ---------------------------------------------------------- */
  try {
    window.addEventListener('saiko:login',  applyWebAppState);
    window.addEventListener('saiko:logout', applyWebAppState);
  } catch (e) {}

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 011 — maintenance-overlay ready');
  } catch (e) {}

})();