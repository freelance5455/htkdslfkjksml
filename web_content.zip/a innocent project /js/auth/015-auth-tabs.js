/* ============================================================
 * FEATURE:        Login / Signup Tab Switch
 * FEATURE NUMBER: 015
 * FILE:           js/auth/015-auth-tabs.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the two tabs at the top of the auth screen
 *   (#tabLogin, #tabSignup) that toggle between:
 *
 *     • Login form  (#loginForm)
 *     • Signup form (#signupForm)
 *
 *   Behaviour for each tab click:
 *
 *     Login tab:
 *       1. #tabLogin  → add    .active
 *       2. #tabSignup → remove .active
 *       3. #loginForm  → remove .hidden   (show)
 *       4. #signupForm → add    .hidden   (hide)
 *       5. authMsg('')  — clear any error/success banner
 *
 *     Signup tab:
 *       1. #tabSignup → add    .active
 *       2. #tabLogin  → remove .active
 *       3. #signupForm → remove .hidden   (show)
 *       4. #loginForm  → add    .hidden   (hide)
 *       5. authMsg('')  — clear any error/success banner
 *
 *   The active tab is also exposed as a small state reader
 *   (SaikoAuthTabs.getActive()) for downstream modules that
 *   may want to know which form is currently visible (e.g.
 *   auto-focus logic, telemetry).
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §10 AUTH
 *       $('#tabLogin').addEventListener('click', ...)
 *       $('#tabSignup').addEventListener('click', ...)
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - authMsg(text, kind)     optional auth-banner helper
 *                             (falls back to inline fallback)
 *
 * DOM ELEMENTS USED:
 *   #tabLogin, #tabSignup     (buttons)
 *   #loginForm, #signupForm   (forms)
 *   #authMsg                  (message banner)
 *
 * FIREBASE PATHS:
 *   none  (pure UI toggle)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoAuthTabs = {
 *     bind, unbind,
 *     showLogin, showSignup,
 *     getActive,
 *     isBound
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  /* ----------------------------------------------------------
   * authMsg helper fallback (matches the pattern used by
   * features 001/002/003 so this file works even when the
   * shared helper has not yet loaded).
   *
   * The fallback only installs itself if the global is missing
   * — it never overwrites an existing implementation.
   * ---------------------------------------------------------- */
  function ensureAuthMsgHelper() {
    try {
      if (typeof authMsg === 'function') return;
    } catch (e) { /* not defined */ }

    window.authMsg = function (text, kind) {
      const m = document.querySelector('#authMsg');
      if (!m) return;
      m.textContent = text || '';
      m.className = 'auth-msg' + (text ? ' ' + (kind || 'err') : '');
    };
  }

  /* ----------------------------------------------------------
   * Safe caller for the shared authMsg helper
   * ---------------------------------------------------------- */
  function clearAuthMsg() {
    try {
      if (typeof authMsg === 'function') {
        authMsg('');
        return;
      }
    } catch (e) {}
    const m = document.querySelector('#authMsg');
    if (m) {
      m.textContent = '';
      m.className = 'auth-msg';
    }
  }

  /* ----------------------------------------------------------
   * Module state
   * ---------------------------------------------------------- */
  let _active = 'login';  // 'login' | 'signup'

  /* ----------------------------------------------------------
   * SHOW LOGIN
   * Behaviour preserved 1:1 from the original #tabLogin
   * click handler.
   * ---------------------------------------------------------- */
  function showLogin() {
    /* 1) Tab styling --------------------------------------- */
    const tabLogin  = qs('#tabLogin');
    const tabSignup = qs('#tabSignup');
    if (tabLogin)  tabLogin.classList.add('active');
    if (tabSignup) tabSignup.classList.remove('active');

    /* 2) Form visibility ----------------------------------- */
    const loginForm  = qs('#loginForm');
    const signupForm = qs('#signupForm');
    if (loginForm)  loginForm.classList.remove('hidden');
    if (signupForm) signupForm.classList.add('hidden');

    /* 3) Clear auth banner --------------------------------- */
    clearAuthMsg();

    /* 4) Remember state ------------------------------------ */
    _active = 'login';

    /* 5) Notify subscribers -------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:auth-tab-changed', {
        detail: { active: 'login' }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * SHOW SIGNUP
   * Behaviour preserved 1:1 from the original #tabSignup
   * click handler.
   * ---------------------------------------------------------- */
  function showSignup() {
    /* 1) Tab styling --------------------------------------- */
    const tabSignup = qs('#tabSignup');
    const tabLogin  = qs('#tabLogin');
    if (tabSignup) tabSignup.classList.add('active');
    if (tabLogin)  tabLogin.classList.remove('active');

    /* 2) Form visibility ----------------------------------- */
    const signupForm = qs('#signupForm');
    const loginForm  = qs('#loginForm');
    if (signupForm) signupForm.classList.remove('hidden');
    if (loginForm)  loginForm.classList.add('hidden');

    /* 3) Clear auth banner --------------------------------- */
    clearAuthMsg();

    /* 4) Remember state ------------------------------------ */
    _active = 'signup';

    /* 5) Notify subscribers -------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:auth-tab-changed', {
        detail: { active: 'signup' }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * GET ACTIVE
   * Returns 'login' | 'signup'. Starts as 'login' because
   * index.html renders #tabLogin with .active by default.
   * ---------------------------------------------------------- */
  function getActive() { return _active; }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Idempotent via dataset guards so the module can safely
   * re-run bind() after a re-render without stacking handlers.
   * ---------------------------------------------------------- */
  function bind(root) {
    const scope = root || document;

    const tabLogin  = qs('#tabLogin', scope);
    const tabSignup = qs('#tabSignup', scope);

    let bound = false;

    if (tabLogin && tabLogin.dataset.authTabBound !== '1') {
      tabLogin.dataset.authTabBound = '1';
      tabLogin.addEventListener('click', showLogin);
      bound = true;
    }

    if (tabSignup && tabSignup.dataset.authTabBound !== '1') {
      tabSignup.dataset.authTabBound = '1';
      tabSignup.addEventListener('click', showSignup);
      bound = true;
    }

    return bound;
  }

  function unbind(root) {
    const scope = root || document;

    const tabLogin  = qs('#tabLogin', scope);
    const tabSignup = qs('#tabSignup', scope);

    if (tabLogin) {
      tabLogin.removeEventListener('click', showLogin);
      delete tabLogin.dataset.authTabBound;
    }

    if (tabSignup) {
      tabSignup.removeEventListener('click', showSignup);
      delete tabSignup.dataset.authTabBound;
    }
  }

  function isBound() {
    const tabLogin  = qs('#tabLogin');
    const tabSignup = qs('#tabSignup');
    return !!(tabLogin && tabLogin.dataset.authTabBound === '1'
           && tabSignup && tabSignup.dataset.authTabBound === '1');
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoAuthTabs = {
    bind: bind,
    unbind: unbind,
    showLogin: showLogin,
    showSignup: showSignup,
    getActive: getActive,
    isBound: isBound
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * The tabs live in index.html so they exist at parse time.
   * Auto-bind for consistency with the other feature modules.
   * ---------------------------------------------------------- */
  ensureAuthMsgHelper();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 015 — auth-tabs ready');
  } catch (e) {}

})();