/* ============================================================
 * FEATURE:        Email / Password Sign Up
 * FEATURE NUMBER: 002
 * FILE:           js/auth/002-signup.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Handle new-user registration via Firebase Authentication
 *   (#signupForm submit). Validates name/email/password,
 *   creates the Firebase Auth user, then writes the initial
 *   profile node under users/{uid} in Realtime Database with
 *   all default fields (photo, cover, bio, dob, relationship,
 *   online, lastSeen, createdAt, updatedAt, xp, level).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10 AUTH  →  $("#signupForm").addEventListener(
 *       "submit", ...)
 *
 * DEPENDENCIES (must be loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - db             Firebase Realtime Database instance
 *   - configOK       Boolean flag from firebase-init
 *   - t(key)         i18n translator
 *   - authMsg()      Shared auth-message helper
 *   - now()          Timestamp helper (falls back to Date.now)
 *
 * DOM ELEMENTS USED:
 *   #signupForm, #signupName, #signupEmail,
 *   #signupPassword, #signupBtn, #authMsg
 *
 * FIREBASE PATHS:
 *   Auth : createUserWithEmailAndPassword(email, password)
 *   RTDB : users/{uid}   (write initial profile)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoSignup.bind()      → attach submit listener
 *   window.SaikoSignup.unbind()    → detach submit listener
 *   window.SaikoSignup.submit(e)   → programmatic submit
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function $(sel) {
    return document.querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver — falls back to key if t() is not ready
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) { /* t() not defined yet */ }
    return key;
  }

  /* ----------------------------------------------------------
   * Timestamp helper — uses global now() if present
   * ---------------------------------------------------------- */
  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) { /* now() not defined */ }
    return Date.now();
  }

  /* ----------------------------------------------------------
   * Auth-message helper fallback (installed once)
   * ---------------------------------------------------------- */
  function ensureAuthMsgHelper() {
    try {
      if (typeof authMsg === 'function') return;
    } catch (e) { /* not defined */ }

    window.authMsg = function (text, kind) {
      const m = document.querySelector('#authMsg');
      if (!m) return;
      m.textContent = text || '';
      m.className = 'auth-msg' + (text ? ' ' + (kind || 'err') : '');
    };
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Auth instance
   * ---------------------------------------------------------- */
  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) { /* auth not defined */ }
    return null;
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Realtime Database instance
   * ---------------------------------------------------------- */
  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) { /* db not defined */ }
    return null;
  }

  /* ----------------------------------------------------------
   * Config guard
   * ---------------------------------------------------------- */
  function isConfigOK() {
    try {
      return typeof configOK !== 'undefined' && !!configOK;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * SUBMIT HANDLER
   * Behaviour preserved 1:1 from original index.html §10
   * ---------------------------------------------------------- */
  async function handleSignupSubmit(event) {
    if (event && typeof event.preventDefault === 'function') {
      event.preventDefault();
    }

    /* 1) Config guard ---------------------------------------- */
    if (!isConfigOK()) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 2) Read DOM inputs ------------------------------------- */
    const nameEl  = $('#signupName');
    const emailEl = $('#signupEmail');
    const passEl  = $('#signupPassword');
    if (!nameEl || !emailEl || !passEl) return;

    const name  = (nameEl.value || '').trim();
    const email = (emailEl.value || '').trim();
    const pass  = passEl.value || '';

    /* 3) Client-side validation ------------------------------ */
    if (!name || !email || !pass) {
      window.authMsg(T('fill_all'));
      return;
    }

    /* 4) Firebase instance guards ---------------------------- */
    const fbAuth = getAuth();
    const fbDb   = getDB();
    if (!fbAuth || !fbDb) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 5) Button busy state ----------------------------------- */
    const btn = $('#signupBtn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = T('please_wait');
    }

    /* 6) Attempt sign-up + write initial profile node ------- */
    try {
      const cred = await fbAuth.createUserWithEmailAndPassword(email, pass);
      const u = cred && cred.user;
      if (!u) throw new Error(T('signup_failed'));

      const created = timeNow();

      // Write the initial profile document. Field set preserved
      // exactly as in the original source.
      await fbDb.ref('users/' + u.uid).set({
        uid: u.uid,
        name: name,
        searchName: name.toLowerCase(),
        email: email,
        photo: '',
        cover: '',
        bio: '',
        dob: '',
        relationship: '',
        online: true,
        lastSeen: created,
        createdAt: created,
        updatedAt: created,
        xp: 0,
        level: 1
      });

      // Clear any previous error
      window.authMsg('');
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('signup_failed');
      window.authMsg(msg);
    } finally {
      /* 7) Restore button state ------------------------------ */
      if (btn) {
        btn.disabled = false;
        btn.textContent = T('signup_btn');
      }
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * ---------------------------------------------------------- */
  function bind() {
    const form = document.querySelector('#signupForm');
    if (!form) return false;
    if (form.dataset.signupBound === '1') return true;
    form.dataset.signupBound = '1';
    form.addEventListener('submit', handleSignupSubmit);
    return true;
  }

  function unbind() {
    const form = document.querySelector('#signupForm');
    if (!form) return;
    form.removeEventListener('submit', handleSignupSubmit);
    delete form.dataset.signupBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoSignup = {
    bind: bind,
    unbind: unbind,
    submit: handleSignupSubmit
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Handles both "DOM already parsed" and "still loading".
   * ---------------------------------------------------------- */
  ensureAuthMsgHelper();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

})();