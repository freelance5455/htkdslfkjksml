/* ============================================================
 * FEATURE:        Account Blocked Overlay
 * FEATURE NUMBER: 012
 * FILE:           js/auth/012-blocked-overlay.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Displays the full-screen "Account Restricted" overlay
 *   (#blockedOverlay) whenever the current user has been
 *   restricted by an administrator.
 *
 *   Two independent Firebase signals feed this overlay:
 *
 *   A) accountStatus/{uid}
 *      shape: { status: 'active' | 'blocked' | 'temp_blocked',
 *               reason?: string,
 *               blockedUntil?: number }
 *
 *      - 'active' or missing → clear block state
 *      - 'blocked'           → permanent ban
 *      - 'temp_blocked'      → temporary ban if blockedUntil > now
 *
 *   B) users/{uid}/blocked  (legacy/boolean path)
 *      combined with users/{uid}/blockedUntil:
 *        - blockedUntil > now  → temporary ban
 *        - blockedUntil == -1 or null → permanent ban
 *
 *   Only ONE block state can be active at a time; whichever
 *   signal arrives latest wins (matches original, which only
 *   overwrote `accountBlockedInfo` when it was previously null
 *   in the users/{uid}/blocked branch).
 *
 *   Temporary bans auto-expire: a setTimeout clears the state
 *   at blockedUntil + 1500 ms (small grace, matches original).
 *
 *   The overlay HTML (#blockedOverlay) itself lives in
 *   index.html and is untouched; this module only toggles its
 *   display and text.
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §13 ADMIN → applyBlockState()
 *   - Section §13 ADMIN → scheduleBlockExpiryCheck()
 *   - Section §13 ADMIN → startAccountStatusListener()
 *   - Section §13 ADMIN → startAdminSync() second half
 *     (db.ref('users/' + myUid + '/blocked').on(...))
 *   - Section §35 BOOT  → #blkRetry click → location.reload()
 *   - Globals: accountStatusRef, accountStatusCb,
 *              accountBlockedInfo, blockExpiryTimer
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - db             Firebase Realtime Database (firebase-init)
 *   - myUid          global current-uid
 *   - myProfile      global current-user profile
 *   - now()          Timestamp helper
 *
 * DOM ELEMENTS USED:
 *   #blockedOverlay       (show/hide)
 *   #blkMsg               (reason text)
 *   #blkUntil             (expiry / permanent notice)
 *   #blkRetry             (reload button)
 *
 * NOTE: #blkLogout is intentionally NOT wired here.
 *       That button belongs to Feature 013
 *       (js/auth/013-blocked-logout.js).
 *
 * FIREBASE PATHS:
 *   RTDB : accountStatus/{uid}                    (read + listen)
 *          accountStatus/{uid}/status             (string)
 *          accountStatus/{uid}/reason             (string)
 *          accountStatus/{uid}/blockedUntil       (number)
 *          users/{uid}/blocked                    (read + listen)
 *          users/{uid}/blockedUntil               (read)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.applyBlockState
 *   window.startAccountStatusListener
 *   window.SaikoBlockedOverlay = {
 *     start, stop,
 *     applyState, scheduleExpiry,
 *     setInfo, clearInfo, getInfo,
 *     bind
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  const DEFAULT_REASON =
    'Your account has been restricted by an administrator.';

  const PERMANENT_TEXT = 'This restriction is permanent.';

  const EXPIRY_GRACE_MS = 1500;  // matches original setTimeout ms + 1500

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) {}
    return Date.now();
  }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  function getUid() {
    try {
      return (typeof myUid !== 'undefined' && myUid) ? myUid : null;
    } catch (e) {}
    return null;
  }

  function getProfile() {
    try {
      return (typeof myProfile !== 'undefined') ? myProfile : null;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * Module-scoped state (original used globals:
   *   accountBlockedInfo, blockExpiryTimer)
   *
   * _info shape (when blocked):
   *   {
   *     permanent: boolean,
   *     until:     number,   // ms epoch, or -1 for permanent
   *     reason:    string
   *   }
   *
   * _info === null → no restriction active
   * ---------------------------------------------------------- */
  let _info = null;
  let _timer = null;
  let _statusRef = null;
  let _statusCb = null;
  let _blockedRef = null;
  let _blockedCb = null;
  let _started = false;

  /* ----------------------------------------------------------
   * STATE HELPERS
   * ---------------------------------------------------------- */
  function setInfo(info) {
    _info = info || null;
    applyState();
    scheduleExpiry();
  }

  function clearInfo() {
    _info = null;
    applyState();
    scheduleExpiry();
  }

  function getInfo() { return _info; }

  /* ----------------------------------------------------------
   * applyBlockState
   * Behaviour preserved 1:1 from the original applyBlockState().
   * ---------------------------------------------------------- */
  function applyState() {
    const o = document.getElementById('blockedOverlay');
    if (!o) return;

    /* 1) No restriction → hide overlay --------------------- */
    if (!_info) {
      o.style.display = 'none';
      return;
    }

    /* 2) Reason text --------------------------------------- */
    const msgEl = o.querySelector('#blkMsg');
    if (msgEl) {
      msgEl.textContent = _info.reason || DEFAULT_REASON;
    }

    /* 3) Expiry / permanent text --------------------------- */
    const untilEl = o.querySelector('#blkUntil');
    if (untilEl) {
      untilEl.textContent = _info.permanent
        ? PERMANENT_TEXT
        : ('Restriction ends ' + new Date(_info.until).toLocaleString());
    }

    /* 4) Reveal -------------------------------------------- */
    o.style.display = 'flex';
  }

  /* ----------------------------------------------------------
   * scheduleBlockExpiryCheck
   * Behaviour preserved 1:1 from the original
   * scheduleBlockExpiryCheck().
   * ---------------------------------------------------------- */
  function scheduleExpiry() {
    /* 1) Always clear previous timer ----------------------- */
    if (_timer) {
      clearTimeout(_timer);
      _timer = null;
    }

    /* 2) Nothing to schedule for permanent / empty --------- */
    if (!_info || _info.permanent) return;

    /* 3) If already expired → clear immediately ------------ */
    const ms = _info.until - timeNow();
    if (ms <= 0) {
      _info = null;
      applyState();
      return;
    }

    /* 4) Schedule auto-clear ------------------------------- */
    _timer = setTimeout(function () {
      _info = null;
      _timer = null;
      applyState();
    }, ms + EXPIRY_GRACE_MS);
  }

  /* ----------------------------------------------------------
   * Parse a snapshot of accountStatus/{uid}
   * Returns an info object, or null when not restricted.
   * ---------------------------------------------------------- */
  function parseAccountStatus(v) {
    if (!v || !v.status || v.status === 'active') return null;

    if (v.status === 'blocked') {
      return {
        permanent: true,
        reason: v.reason || '',
        until: -1
      };
    }

    if (v.status === 'temp_blocked') {
      if (v.blockedUntil && v.blockedUntil > timeNow()) {
        return {
          permanent: false,
          until: v.blockedUntil,
          reason: v.reason || ''
        };
      }
      return null; // expired temp ban
    }

    return null;
  }

  /* ----------------------------------------------------------
   * Parse the legacy users/{uid}/blocked flag + blockedUntil
   * Returns an info object, or null when not restricted.
   *
   * Matches the original startAdminSync() branch exactly:
   *   if (blk) {
   *     if (until > now)      → temp ban
   *     else if (until === -1 || until == null) → permanent
   *   }
   * ---------------------------------------------------------- */
  function parseLegacyBlockedFlag(isBlocked) {
    if (!isBlocked) return null;

    const p = getProfile();
    const until = p ? p.blockedUntil : null;

    if (until && Number(until) > timeNow()) {
      return {
        permanent: false,
        until: Number(until),
        reason: 'Account restricted.'
      };
    }

    if (until === -1 || until == null) {
      return {
        permanent: true,
        reason: 'Account restricted.'
      };
    }

    // until is a past timestamp → treat as expired
    return null;
  }

  /* ----------------------------------------------------------
   * START — attach both Firebase listeners
   *
   * Listener 1: accountStatus/{uid}
   * Listener 2: users/{uid}/blocked
   *
   * Both are wired to the same internal setInfo/clearInfo so
   * whichever arrives latest wins. Preserves the original
   * semantics where the legacy path only overwrote state when
   * no restriction was already active.
   * ---------------------------------------------------------- */
  function start() {
    if (_started) return true;
    const fbDb = getDB();
    const uid = getUid();
    if (!fbDb || !uid) return false;
    _started = true;

    /* -------- Listener 1: accountStatus/{uid} ---------- */
    try {
      _statusRef = fbDb.ref('accountStatus/' + uid);
      _statusCb = _statusRef.on('value', function (snap) {
        const parsed = parseAccountStatus(snap.val());
        setInfo(parsed);
      }, function (err) {
        console.warn('[blocked-overlay] accountStatus error', err);
      });
    } catch (e) {
      console.warn('[blocked-overlay] accountStatus attach failed', e);
    }

    /* -------- Listener 2: users/{uid}/blocked ---------- */
    try {
      _blockedRef = fbDb.ref('users/' + uid + '/blocked');
      _blockedCb = _blockedRef.on('value', function (snap) {
        const isBlocked = !!snap.val();

        /* Original only set state when no info was active
         * (see startAdminSync): if a restriction was already
         * present, the legacy flag did not overwrite it. We
         * preserve that exact behaviour.
         */
        if (isBlocked && !_info) {
          const parsed = parseLegacyBlockedFlag(true);
          if (parsed) setInfo(parsed);
        }
        // Note: when isBlocked is false we deliberately do NOT
        // clear existing state — the accountStatus listener is
        // the authoritative source for unblock. This matches
        // the original code path.
      }, function (err) {
        console.warn('[blocked-overlay] users/blocked error', err);
      });
    } catch (e) {
      console.warn('[blocked-overlay] users/blocked attach failed', e);
    }

    return true;
  }

  /* ----------------------------------------------------------
   * STOP — detach both listeners + clear timer
   * ---------------------------------------------------------- */
  function stop() {
    if (_statusRef && _statusCb) {
      try { _statusRef.off('value', _statusCb); } catch (e) {}
    }
    if (_blockedRef && _blockedCb) {
      try { _blockedRef.off('value', _blockedCb); } catch (e) {}
    }
    _statusRef = null;
    _statusCb = null;
    _blockedRef = null;
    _blockedCb = null;

    if (_timer) {
      clearTimeout(_timer);
      _timer = null;
    }

    _info = null;
    _started = false;
    applyState();
  }

  /* ----------------------------------------------------------
   * BIND — wire #blkRetry → location.reload()
   * (#blkLogout is Feature 013's responsibility.)
   * ---------------------------------------------------------- */
  function bind() {
    const btn = qs('#blkRetry');
    if (!btn) return false;
    if (btn.dataset.blkRetryBound === '1') return true;
    btn.dataset.blkRetryBound = '1';
    btn.addEventListener('click', function () {
      try { location.reload(); } catch (e) {}
    });
    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.applyBlockState = applyState;
  window.startAccountStatusListener = start;

  window.SaikoBlockedOverlay = {
    start: start,
    stop: stop,
    applyState: applyState,
    scheduleExpiry: scheduleExpiry,
    setInfo: setInfo,
    clearInfo: clearInfo,
    getInfo: getInfo,
    bind: bind
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Wires the reload button as soon as the DOM is ready.
   * Does NOT start the listeners — that is boot.js's job
   * (startGlobalListeners) so original load order is preserved.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * Re-evaluate overlay when the authenticated user changes
   * (login) — the auth-state module dispatches a CustomEvent.
   * On logout the boot teardown path calls stop().
   * ---------------------------------------------------------- */
  try {
    window.addEventListener('saiko:login', function () {
      // If listeners were already attached for a previous uid,
      // detach and re-attach for the new one.
      if (_started) stop();
      start();
    });
  } catch (e) {}

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 012 — blocked-overlay ready');
  } catch (e) {}

})();