/* ============================================================
 * FEATURE:        Change Password
 * FEATURE NUMBER: 007
 * FILE:           js/auth/007-change-password.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Provides the "Account → Password" subsection of the Account
 *   settings page. Renders:
 *     - <input id="accPass" type="password">
 *     - <button id="accPassBtn"> change-password trigger
 *   and wires the click handler that calls
 *   auth.currentUser.updatePassword(newPassword).
 *
 *   In the original single-file build, this HTML lived inside
 *   the larger `accountHTML()` string and the click handler
 *   lived inside `wireAccount()`. Feature 007 owns ONLY the
 *   password subsection so that email (006) and logout (008)
 *   can live in their own files. A higher-level settings page
 *   coordinator (js/settings/account.js) will stitch the three
 *   fragments together.
 *
 * ORIGINAL LOCATION (index.html):
 *   - accountHTML()      → the <input id="accPass"> and
 *                          <button id="accPassBtn"> block
 *   - wireAccount()      → $('#accPassBtn').addEventListener
 *                          ('click', async () => { … })
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - t(key)         i18n translator
 *   - esc(str)       HTML-escape helper (falls back to local)
 *   - toast(msg,k)   Optional toast notifier
 *
 * DOM ELEMENTS USED:
 *   #accPass, #accPassBtn
 *
 * FIREBASE PATHS:
 *   Auth : auth.currentUser.updatePassword(newPassword)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoChangePassword = {
 *     renderFragment,     → returns HTML string for the section
 *     bind,               → attach click handler inside a root
 *     unbind,             → detach click handler
 *     trigger,            → programmatic change-password
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper — prefers global esc() if present,
   * otherwise uses a minimal built-in implementation that
   * matches the global one's output for &, <, >, ", '.
   * ---------------------------------------------------------- */
  function esc(str) {
    try {
      if (typeof window.esc === 'function') return window.esc(str);
    } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast notifier — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Auth instance
   * ---------------------------------------------------------- */
  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Returns the HTML for the password subsection of the Account
   * settings page. Structure is preserved 1:1 from the original
   * accountHTML() — same IDs, same classes, same order.
   * ---------------------------------------------------------- */
  function renderFragment() {
    return (
      '<div class="field">' +
        '<label>' + esc(T('password')) + '</label>' +
        '<input class="input" id="accPass" type="password" ' +
          'placeholder="••••••••">' +
      '</div>' +
      '<button class="btn ghost block" id="accPassBtn">' +
        esc(T('change_password')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * TRIGGER — performs the change-password operation.
   * Behaviour preserved 1:1 from the original wireAccount()
   * click handler:
   *   1. read #accPass value
   *   2. if empty OR length < 6 → toast(fill_all, err); return
   *   3. auth.currentUser.updatePassword(v)
   *   4. success → clear input, toast(password_changed, ok)
   *   5. error   → toast(err.message || error, err)
   * ---------------------------------------------------------- */
  async function trigger() {
    const input = qs('#accPass');
    const v = input ? String(input.value || '') : '';

    /* 1) Presence + minimum-length check ------------------- */
    if (!v || v.length < 6) {
      safeToast(T('fill_all'), 'err');
      return false;
    }

    /* 2) Auth + user guard ---------------------------------- */
    const fbAuth = getAuth();
    if (!fbAuth || !fbAuth.currentUser) {
      safeToast(T('error'), 'err');
      return false;
    }

    /* 3) Attempt change ------------------------------------- */
    try {
      await fbAuth.currentUser.updatePassword(v);

      /* Clear the input field (original behaviour) --------- */
      if (input) input.value = '';

      safeToast(T('password_changed'), 'ok');

      /* Fire an event so sibling modules can react --------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:password-changed'));
      } catch (e) {}

      return true;
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('error');
      safeToast(msg, 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Binds the click handler on #accPassBtn inside `root`
   * (defaults to document). Uses a data-attribute guard so
   * re-binding is safe across re-renders.
   * ---------------------------------------------------------- */
  function bind(root) {
    const scope = root || document;
    const btn = qs('#accPassBtn', scope);
    if (!btn) return false;
    if (btn.dataset.changePassBound === '1') return true;
    btn.dataset.changePassBound = '1';
    btn.addEventListener('click', trigger);
    return true;
  }

  function unbind(root) {
    const scope = root || document;
    const btn = qs('#accPassBtn', scope);
    if (!btn) return;
    btn.removeEventListener('click', trigger);
    delete btn.dataset.changePassBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoChangePassword = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    trigger: trigger
  };

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 007 — change-password ready');
  } catch (e) {}

})();