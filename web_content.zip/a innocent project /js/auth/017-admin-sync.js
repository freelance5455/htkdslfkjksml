/* ============================================================
 * MISSING FILE 8/8 — ADMIN SYNC + LOG ACTIVITY
 * FILE:   js/auth/017-admin-sync.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * Provides:
 *   • startAdminSync()      — attach 3 live listeners
 *   • detachAdminSync()     — cleanup on logout
 *   • logActivity()         — push to adminActivity/{push}
 *   • applyWebAppState()    — show/hide maintenance overlay
 *   • applyBlockState()     — show/hide blocked overlay
 *
 * Listens to:
 *   • appConfig/webApp      → maintenance mode (admin bypass)
 *   • accountStatus/{uid}   → block / temp-block / active
 *   • postReactions         → real-time post reactions map
 *   • users/{uid}/blocked   → legacy block flag
 * ============================================================ */

(function () {
  'use strict';

  /* ============ HELPERS ============ */
  function qs(sel) { return document.querySelector(sel); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() { try { return window.now(); } catch (e) { return Date.now(); } }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function getDB() { try { return window.db || null; } catch (e) { return null; } }
  function getUid() { return window.myUid || null; }
  function isAdmin() {
    try {
      var p = window.myProfile;
      return !!(p && (p.isAdmin === true || p.admin === true));
    } catch (e) { return false; }
  }

  /* ============ STATE ============ */
  var webAppConfigRef = null, webAppConfigCb = null;
  var accountStatusRef = null, accountStatusCb = null;
  var postReactionsRef = null, postReactionsCb = null;
  var legacyBlockRef = null, legacyBlockCb = null;

  var webAppEnabled = true;
  var webAppMessage = '';
  var accountBlockedInfo = null;
  var blockExpiryTimer = null;

  /* ============ MAINTENANCE OVERLAY ============ */
  function applyWebAppState() {
    var o = qs('#maintenanceOverlay');
    if (!o) return;

    var msgEl = o.querySelector('#maintMsg');
    if (msgEl) {
      msgEl.textContent = webAppMessage || 'WebApp is currently under maintenance. Please come back later.';
    }

    /* Admin bypass ------------------------------------- */
    o.style.display = (webAppEnabled || isAdmin()) ? 'none' : 'flex';
  }

  /* ============ BLOCKED OVERLAY ============ */
  function applyBlockState() {
    var o = qs('#blockedOverlay');
    if (!o) return;

    if (!accountBlockedInfo) {
      o.style.display = 'none';
      return;
    }

    var msgEl = o.querySelector('#blkMsg');
    if (msgEl) {
      msgEl.textContent = accountBlockedInfo.reason || 'Your account has been restricted by an administrator.';
    }

    var untilEl = o.querySelector('#blkUntil');
    if (untilEl) {
      if (accountBlockedInfo.permanent) {
        untilEl.textContent = 'This restriction is permanent.';
      } else {
        untilEl.textContent = 'Restriction ends ' + new Date(accountBlockedInfo.until).toLocaleString();
      }
    }

    o.style.display = 'flex';
  }

  function scheduleBlockExpiryCheck() {
    if (blockExpiryTimer) {
      clearTimeout(blockExpiryTimer);
      blockExpiryTimer = null;
    }
    if (!accountBlockedInfo || accountBlockedInfo.permanent) return;

    var ms = accountBlockedInfo.until - timeNow();
    if (ms <= 0) {
      accountBlockedInfo = null;
      applyBlockState();
      return;
    }
    blockExpiryTimer = setTimeout(function () {
      accountBlockedInfo = null;
      applyBlockState();
    }, ms + 1500);
  }

  /* ============ START ADMIN SYNC ============ */
  function startAdminSync() {
    var fbDb = getDB();
    if (!fbDb) return false;

    /* ---- 1) appConfig/webApp listener --------------- */
    if (!webAppConfigRef) {
      webAppConfigRef = fbDb.ref('appConfig/webApp');
      webAppConfigCb = webAppConfigRef.on('value', function (s) {
        var v = s.val() || {};
        webAppEnabled = v.enabled !== false;
        webAppMessage = v.message || '';
        applyWebAppState();
      });

      /* One-shot fallback ----------------------------- */
      webAppConfigRef.get().then(function (s) {
        var v = s.val() || {};
        webAppEnabled = v.enabled !== false;
        webAppMessage = v.message || '';
        applyWebAppState();
      }).catch(function () {});
    }

    /* ---- 2) accountStatus/{uid} listener ----------- */
    var uid = getUid();
    if (uid && !accountStatusRef) {
      accountStatusRef = fbDb.ref('accountStatus/' + uid);
      accountStatusCb = accountStatusRef.on('value', function (s) {
        var v = s.val();
        if (!v || !v.status || v.status === 'active') {
          accountBlockedInfo = null;
        } else if (v.status === 'blocked') {
          accountBlockedInfo = {
            permanent: true,
            reason: v.reason || '',
            until: -1
          };
        } else if (v.status === 'temp_blocked') {
          if (v.blockedUntil && v.blockedUntil > timeNow()) {
            accountBlockedInfo = {
              permanent: false,
              until: v.blockedUntil,
              reason: v.reason || ''
            };
          } else {
            accountBlockedInfo = null;
          }
        } else {
          accountBlockedInfo = null;
        }
        applyBlockState();
        scheduleBlockExpiryCheck();
      });
    }

    /* ---- 3) postReactions listener ----------------- */
    if (!postReactionsRef) {
      postReactionsRef = fbDb.ref('postReactions');
      postReactionsCb = postReactionsRef.on('value', function (s) {
        window.postReactionsMap = s.val() || {};
        /* Repaint every visible post card's like count -- */
        safeCall('paintPostCounts');
      });
    }

    /* ---- 4) Legacy users/{uid}/blocked flag -------- */
    if (uid && !legacyBlockRef) {
      legacyBlockRef = fbDb.ref('users/' + uid + '/blocked');
      legacyBlockCb = legacyBlockRef.on('value', function (s) {
        var blk = !!s.val();
        var p = window.myProfile || {};
        var until = Number(p.blockedUntil || 0);

        if (blk && !accountBlockedInfo) {
          if (until && until > timeNow()) {
            accountBlockedInfo = {
              permanent: false,
              until: until,
              reason: 'Account restricted.'
            };
          } else if (until === -1 || until === 0) {
            accountBlockedInfo = {
              permanent: true,
              reason: 'Account restricted.'
            };
          }
          applyBlockState();
          scheduleBlockExpiryCheck();
        }
      });
    }

    return true;
  }

  /* ============ DETACH ============ */
  function detachAdminSync() {
    if (webAppConfigRef && webAppConfigCb) {
      try { webAppConfigRef.off('value', webAppConfigCb); } catch (e) {}
    }
    webAppConfigRef = webAppConfigCb = null;

    if (accountStatusRef && accountStatusCb) {
      try { accountStatusRef.off('value', accountStatusCb); } catch (e) {}
    }
    accountStatusRef = accountStatusCb = null;

    if (postReactionsRef && postReactionsCb) {
      try { postReactionsRef.off('value', postReactionsCb); } catch (e) {}
    }
    postReactionsRef = postReactionsCb = null;

    if (legacyBlockRef && legacyBlockCb) {
      try { legacyBlockRef.off('value', legacyBlockCb); } catch (e) {}
    }
    legacyBlockRef = legacyBlockCb = null;

    window.postReactionsMap = {};
    accountBlockedInfo = null;
    if (blockExpiryTimer) {
      clearTimeout(blockExpiryTimer);
      blockExpiryTimer = null;
    }
  }

  /* ============ LOG ACTIVITY ============ */
  function logActivity(action, extra) {
    var uid = getUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return;
    try {
      var ref = fbDb.ref('adminActivity').push();
      ref.set({
        id: ref.key,
        uid: uid,
        name: (window.myProfile && window.myProfile.name) || '',
        action: action,
        extra: extra || null,
        createdAt: timeNow()
      }).catch(function () {});
    } catch (e) {}
  }

  /* ============ EXPORTS ============ */
  window.startAdminSync   = startAdminSync;
  window.detachAdminSync  = detachAdminSync;
  window.logActivity      = logActivity;
  window.applyWebAppState = applyWebAppState;
  window.applyBlockState  = applyBlockState;

  window.SaikoAdminSync = {
    start: startAdminSync,
    detach: detachAdminSync,
    log: logActivity,
    applyWebApp: applyWebAppState,
    applyBlock: applyBlockState
  };

  /* ============ AUTO-RUN ============ */
  /* If we are already authenticated by the time this file loads,
   * kick the listeners right away. Otherwise, attach on the
   * next auth change. */
  if (window.auth && typeof window.auth.onAuthStateChanged === 'function') {
    window.auth.onAuthStateChanged(function (u) {
      if (u) { try { startAdminSync(); } catch (e) {} }
      else { try { detachAdminSync(); } catch (e) {} }
    });
  } else if (getUid()) {
    startAdminSync();
  }

  try { console.debug('[boot] admin-sync ready'); } catch (e) {}
})();