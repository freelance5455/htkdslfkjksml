/* ============================================================
 * SUPPORTING FILE — ENTER APP + PRESENCE + BLOCKED + SESSIONS
 * FILE:   js/auth/016-enter-app.js
 * ACTION: REPLACE (Batch 4 — adds grantLoginXpOnce + cacheOfflineGames)
 * ------------------------------------------------------------
 * PURPOSE:
 *   Provides the 4 functions that the auth-state module
 *   (feature 004) calls after a successful login but that
 *   do not live in any other feature file:
 *
 *     enterApp()        — switch UI from auth screen → main app
 *                         + apply prefs/i18n + start listeners
 *                         + daily-login XP + offline-games warm-up
 *                         + fire initial renders
 *     setupPresence()   — Firebase Realtime presence (online /
 *                         offline / lastSeen) with onDisconnect
 *     listenBlocked()   — attach the four per-user block maps
 *                         (blockedUsers / mutedAuthors /
 *                          callBlocks / smsBlocks)
 *     registerSession() — write a userSessions/{uid}/{sid} row
 *                         and heartbeat it every 60 s
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel) { return document.querySelector(sel); }

  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[enter-app] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * ENTER APP — the missing orchestrator
   * ============================================================ */
  function enterApp() {
    /* 1) Switch UI ---------------------------------------- */
    var authEl = qs('#authScreen');
    var appEl  = qs('#app');
    if (authEl) authEl.classList.add('hidden');
    if (appEl)  appEl.classList.remove('hidden');

    /* 2) Re-apply prefs + i18n + icons -------------------- */
    if (typeof window.applyPrefs === 'function') {
      try { window.applyPrefs(); } catch (e) {}
    }
    if (typeof window.applyI18n === 'function') {
      try { window.applyI18n(); } catch (e) {}
    }
    if (typeof window.buildNavIcons === 'function') {
      try { window.buildNavIcons(); } catch (e) {}
    }

    /* 3) App lock (feature 009) --------------------------- */
    try {
      if (window.prefs && window.prefs.appLock && window.prefs.appLockPin) {
        if (!sessionStorage.getItem('saiko_unlocked')) {
          if (typeof window.showLockScreen === 'function') {
            window.showLockScreen();
          }
        }
      }
    } catch (e) {}

    /* 4) First-time global listeners ---------------------- */
    if (!window.__appEntered) {
      window.__appEntered = true;

      if (typeof window.startGlobalListeners === 'function') {
        window.startGlobalListeners();
      }

      /* ============================================================
       * === CHANGE (Batch 4) ===
       * Daily login XP / streak + offline games warm-up.
       * Both are safe-calls — no-op if their providers are missing.
       * ============================================================ */
      safeCall('grantLoginXpOnce');
      safeCall('cacheOfflineGames');
      /* ============================================================ */

      try { console.debug('[enter-app] first-run warm-up: grantLoginXpOnce + cacheOfflineGames'); } catch (e) {}
    }

    /* 5) Initial page render ------------------------------ */
    try {
      if (typeof window.renderProfilePage === 'function') window.renderProfilePage();
    } catch (e) {}
    try {
      if (typeof window.renderFeed === 'function' &&
          typeof window.currentNav === 'string' &&
          window.currentNav === 'home') {
        window.renderFeed(false);
      }
    } catch (e) {}

    /* 6) Hide splash -------------------------------------- */
    if (typeof window.hideSplash === 'function') {
      setTimeout(function () { window.hideSplash(); }, 120);
    }

    /* 7) Mark auth-resolved so the failsafe does not fire  */
    try { window.authResolved = true; } catch (e) {}
  }

  /* ============================================================
   * PRESENCE — online / offline / lastSeen
   * ============================================================ */
  function setupPresence() {
    if (!window.db || !window.myUid) return;

    var userRef = window.db.ref('users/' + window.myUid);
    var connRef = window.db.ref('.info/connected');

    connRef.on('value', function (snap) {
      if (snap.val() === true) {
        /* Register the disconnect hook, then mark online -- */
        userRef.onDisconnect().update({
          online: false,
          lastSeen: Date.now()
        }).then(function () {
          userRef.update({ online: true, lastSeen: Date.now() });
        }).catch(function () {});
      } else {
        userRef.update({ online: false, lastSeen: Date.now() }).catch(function () {});
      }
    });
  }

  /* ============================================================
   * BLOCKED / MUTED / CALL-BLOCK / SMS-BLOCK listeners
   * ============================================================
   * These four maps power the per-user privacy flags used by
   * feed filtering (feature 051 isVisiblePost), messaging
   * (feature 154), and call signalling (feature 155).
   * ============================================================ */
  function listenBlocked() {
    if (!window.db || !window.myUid) return;

    window.blockedUsers     = window.blockedUsers     || {};
    window.mutedAuthors     = window.mutedAuthors     || {};
    window.callBlockedUsers = window.callBlockedUsers || {};
    window.smsBlockedUsers  = window.smsBlockedUsers  || {};

    window.db.ref('blockedUsers/' + window.myUid).on('value', function (s) {
      window.blockedUsers = s.val() || {};
    });
    window.db.ref('mutedAuthors/' + window.myUid).on('value', function (s) {
      window.mutedAuthors = s.val() || {};
      if (typeof window.currentNav === 'string' &&
          window.currentNav === 'home' &&
          typeof window.renderFeed === 'function') {
        window.renderFeed(true);
      }
    });
    window.db.ref('callBlocks/' + window.myUid).on('value', function (s) {
      window.callBlockedUsers = s.val() || {};
    });
    window.db.ref('smsBlocks/' + window.myUid).on('value', function (s) {
      window.smsBlockedUsers = s.val() || {};
    });
  }

  /* ============================================================
   * SESSION — one row + 60 s heartbeat
   * ============================================================ */
  function registerSession() {
    if (!window.db || !window.myUid) return;
    try {
      var sid = sessionStorage.getItem('saiko_session_id');
      if (!sid) {
        sid = 's_' + Math.random().toString(36).slice(2, 10) + '_' + Date.now();
        sessionStorage.setItem('saiko_session_id', sid);
      }

      window.db.ref('userSessions/' + window.myUid + '/' + sid).set({
        id: sid,
        ua: navigator.userAgent,
        platform: navigator.platform || '',
        last: Date.now(),
        createdAt: Date.now()
      }).catch(function () {});

      setInterval(function () {
        if (!window.myUid || !window.db) return;
        window.db.ref('userSessions/' + window.myUid + '/' + sid + '/last')
          .set(Date.now()).catch(function () {});
      }, 60000);

      window.addEventListener('beforeunload', function () {
        if (!window.myUid || !window.db) return;
        window.db.ref('userSessions/' + window.myUid + '/' + sid + '/last')
          .set(Date.now()).catch(function () {});
      });
    } catch (e) {}
  }

  /* ============================================================
   * EXPORTS
   * ============================================================ */
  window.enterApp        = enterApp;
  window.setupPresence   = setupPresence;
  window.listenBlocked   = listenBlocked;
  window.registerSession = registerSession;

  window.SaikoEnterApp = {
    enterApp: enterApp,
    setupPresence: setupPresence,
    listenBlocked: listenBlocked,
    registerSession: registerSession
  };

  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 016 — enter-app + presence + sessions ready');
  } catch (e) {}

})();