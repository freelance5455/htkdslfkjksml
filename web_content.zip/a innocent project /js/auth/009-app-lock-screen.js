/* ============================================================
 * FEATURE:        App Lock Screen (4-digit PIN entry overlay)
 * FEATURE NUMBER: 009
 * FILE:           js/auth/009-app-lock-screen.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Renders the full-screen PIN entry overlay (#lockScreen)
 *   shown on cold start / resume when App Lock is enabled and
 *   the current browser session has not yet been unlocked.
 *
 *   On correct 4-digit PIN:
 *     • sessionStorage['saiko_unlocked'] = '1'
 *     • hide the lock overlay
 *   On wrong PIN:
 *     • toast(t('wrong_pin'), 'err')
 *     • reset the entry counter, re-render the dots
 *
 *   The keyboard layout is fixed: 1..9, empty-spacer, 0, ⌫.
 *   Backspace removes the last digit. Digits are capped at 4.
 *
 *   NOTE: This file is ONLY the runtime entry overlay.
 *   Setting / removing the PIN itself lives in Feature 010
 *   (js/auth/010-app-lock-pin.js).
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §10d  →  function showLockScreen() { … }
 *   - enterApp()    →  if(prefs.appLock && prefs.appLockPin
 *                        && !sessionStorage.getItem(
 *                           'saiko_unlocked')) showLockScreen()
 *
 * DEPENDENCIES (loaded earlier):
 *   - prefs                   global preference object
 *   - t(key)                  i18n translator
 *   - toast(msg, kind)        Optional toast notifier
 *
 * DOM ELEMENTS USED:
 *   #lockScreen, #pinPad, #pinDots
 *
 * FIREBASE PATHS:
 *   none  (local-only feature)
 *
 * localStorage  : (read indirectly via prefs — 'saiko_prefs_v7')
 * sessionStorage: 'saiko_unlocked'       (read + write)
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.showLockScreen
 *   window.SaikoAppLockScreen = {
 *     show, hide, isUnlocked, shouldShow,
 *     setUnlocked, clearUnlocked, isEnabled
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  const UNLOCKED_KEY = 'saiko_unlocked';
  const PIN_LENGTH   = 4;
  const KEYPAD       = ['1','2','3','4','5','6','7','8','9','','0','⌫'];

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prefs access (defensive — prefs may be undefined during
   * very early boot in some load orders)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof prefs !== 'undefined' && prefs) return prefs;
    } catch (e) {}
    return null;
  }

  function isEnabled() {
    const p = getPrefs();
    return !!(p && p.appLock && p.appLockPin);
  }

  function getConfiguredPin() {
    const p = getPrefs();
    return (p && p.appLockPin) ? String(p.appLockPin) : '';
  }

  /* ----------------------------------------------------------
   * Session state
   * ---------------------------------------------------------- */
  function isUnlocked() {
    try {
      return sessionStorage.getItem(UNLOCKED_KEY) === '1';
    } catch (e) {
      return false;
    }
  }

  function setUnlocked() {
    try { sessionStorage.setItem(UNLOCKED_KEY, '1'); } catch (e) {}
  }

  function clearUnlocked() {
    try { sessionStorage.removeItem(UNLOCKED_KEY); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Should the overlay be shown right now?
   * Mirrors the original enterApp() guard exactly.
   * ---------------------------------------------------------- */
  function shouldShow() {
    return isEnabled() && !isUnlocked();
  }

  /* ----------------------------------------------------------
   * SHOW — render the overlay + wire the keypad
   * Behaviour preserved 1:1 from original showLockScreen().
   * ---------------------------------------------------------- */
  function show() {
    const ls = qs('#lockScreen');
    if (!ls) return false;

    ls.classList.remove('hidden');

    /* Local entry buffer ----------------------------------- */
    let entered = '';

    const pad  = qs('#pinPad');
    const dots = qs('#pinDots');
    if (!pad || !dots) return false;

    /* Initial dots — 4 empty pin-dots --------------------- */
    dots.innerHTML = '';
    for (let i = 0; i < PIN_LENGTH; i++) {
      const d = document.createElement('div');
      d.className = 'pin-dot';
      dots.appendChild(d);
    }

    /* Fresh keypad --------------------------------------- */
    pad.innerHTML = '';

    KEYPAD.forEach(function (k) {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = k;

      if (k === '') {
        b.style.visibility = 'hidden';
      }
      if (k === '0') {
        b.classList.add('zero');
      }

      b.addEventListener('click', function () {
        /* Backspace -------------------------------------- */
        if (k === '⌫') {
          entered = entered.slice(0, -1);
          updateDots();
          return;
        }

        /* Digit input (capped at PIN_LENGTH) ------------ */
        if (k && entered.length < PIN_LENGTH) {
          entered += k;
        }
        updateDots();

        /* Full-length → validate after a tiny delay so the
         * last dot visibly fills first. Preserves the
         * original 120 ms hold. -------------------------- */
        if (entered.length === PIN_LENGTH) {
          setTimeout(function () {
            if (entered === getConfiguredPin()) {
              setUnlocked();
              ls.classList.add('hidden');
            } else {
              safeToast(T('wrong_pin'), 'err');
              entered = '';
              updateDots();
            }
          }, 120);
        }
      });

      pad.appendChild(b);
    });

    /* Dot renderer --------------------------------------- */
    function updateDots() {
      dots.innerHTML = '';
      for (let i = 0; i < PIN_LENGTH; i++) {
        const d = document.createElement('div');
        d.className = 'pin-dot' + (i < entered.length ? ' on' : '');
        dots.appendChild(d);
      }
    }

    return true;
  }

  /* ----------------------------------------------------------
   * HIDE — dismiss overlay without unlocking.
   * Useful for programmatic transitions (e.g. logout,
   * admin-driven lock removal while overlay is open).
   * ---------------------------------------------------------- */
  function hide() {
    const ls = qs('#lockScreen');
    if (ls) ls.classList.add('hidden');
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.showLockScreen = show;

  window.SaikoAppLockScreen = {
    show: show,
    hide: hide,
    isUnlocked: isUnlocked,
    shouldShow: shouldShow,
    setUnlocked: setUnlocked,
    clearUnlocked: clearUnlocked,
    isEnabled: isEnabled
  };

  /* ----------------------------------------------------------
   * OPTIONAL: auto-lock on tab visibility return
   * Not enabled by default — preserved as a no-op so we do
   * not introduce new behavior beyond the original source.
   * ---------------------------------------------------------- */
  // (intentionally empty)

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 009 — app-lock-screen ready');
  } catch (e) {}

})();