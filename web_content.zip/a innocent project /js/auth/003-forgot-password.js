/* ============================================================
 * FEATURE:        Forgot Password (Send Reset Email)
 * FEATURE NUMBER: 003
 * FILE:           js/auth/003-forgot-password.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Wire up the "#btnForgot" link on the login screen.
 *   Reads the email field (#loginEmail), validates presence,
 *   then calls Firebase Auth sendPasswordResetEmail(email).
 *   Displays success or failure via the shared auth-msg
 *   helper (#authMsg).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10 AUTH  →  $("#btnForgot").addEventListener(
 *       "click", ...)
 *
 * DEPENDENCIES (must be loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - configOK       Boolean flag from firebase-init
 *   - t(key)         i18n translator
 *   - authMsg()      Shared auth-message helper
 *   - toast(msg)     Optional toast (used as fallback notice)
 *
 * DOM ELEMENTS USED:
 *   #btnForgot, #loginEmail, #authMsg
 *
 * FIREBASE PATHS:
 *   Auth : sendPasswordResetEmail(email)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoForgotPassword.bind()    → attach click listener
 *   window.SaikoForgotPassword.unbind()  → detach click listener
 *   window.SaikoForgotPassword.trigger() → programmatic send
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function $(sel) {
    return document.querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver — falls back to key if t() is not ready
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) { /* t() not defined yet */ }
    return key;
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallow if not available
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) { /* toast not defined — ignore */ }
  }

  /* ----------------------------------------------------------
   * Auth-message helper fallback (installed once)
   * ---------------------------------------------------------- */
  function ensureAuthMsgHelper() {
    try {
      if (typeof authMsg === 'function') return;
    } catch (e) { /* not defined */ }

    window.authMsg = function (text, kind) {
      const m = document.querySelector('#authMsg');
      if (!m) return;
      m.textContent = text || '';
      m.className = 'auth-msg' + (text ? ' ' + (kind || 'err') : '');
    };
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Auth instance
   * ---------------------------------------------------------- */
  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) { /* auth not defined */ }
    return null;
  }

  /* ----------------------------------------------------------
   * Config guard
   * ---------------------------------------------------------- */
  function isConfigOK() {
    try {
      return typeof configOK !== 'undefined' && !!configOK;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * TRIGGER HANDLER
   * Behaviour preserved 1:1 from original index.html §10
   * ---------------------------------------------------------- */
  async function triggerForgotPassword() {
    /* 1) Read email ----------------------------------------- */
    const emailEl = $('#loginEmail');
    const email = emailEl ? (emailEl.value || '').trim() : '';

    /* 2) Presence check ------------------------------------- */
    if (!email) {
      safeToast(T('fill_all'), 'err');
      return;
    }

    /* 3) Config guard --------------------------------------- */
    if (!isConfigOK()) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 4) Firebase guard ------------------------------------- */
    const fbAuth = getAuth();
    if (!fbAuth) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 5) Send reset email ----------------------------------- */
    try {
      await fbAuth.sendPasswordResetEmail(email);
      window.authMsg(T('reset_sent'), 'ok');
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('reset_failed');
      window.authMsg(msg);
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * ---------------------------------------------------------- */
  function bind() {
    const btn = document.querySelector('#btnForgot');
    if (!btn) return false;
    if (btn.dataset.forgotBound === '1') return true;
    btn.dataset.forgotBound = '1';
    btn.addEventListener('click', triggerForgotPassword);
    return true;
  }

  function unbind() {
    const btn = document.querySelector('#btnForgot');
    if (!btn) return;
    btn.removeEventListener('click', triggerForgotPassword);
    delete btn.dataset.forgotBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoForgotPassword = {
    bind: bind,
    unbind: unbind,
    trigger: triggerForgotPassword
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Handles both "DOM already parsed" and "still loading".
   * ---------------------------------------------------------- */
  ensureAuthMsgHelper();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

})();