/* ============================================================
 * FEATURE:        Splash Screen
 * FEATURE NUMBER: 014
 * FILE:           js/auth/014-splash-screen.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the full-screen boot splash (#splash).
 *
 *   The splash is rendered statically in index.html and stays
 *   visible until the app is ready. This module handles:
 *
 *     • hideSplash()  — fade out then physically remove the
 *                       splash element (400 ms delay matching
 *                       the original .hide CSS transition).
 *     • showSplash()  — convenience to re-show (used by any
 *                       future re-boot / re-auth flow).
 *     • armFailsafe(ms) — schedules a one-shot auto-hide so
 *                       the splash never gets stuck forever
 *                       if auth/config listeners fail to fire.
 *                       Original used 3000 ms in the boot IIFE.
 *
 *   hideSplash() is idempotent — calling it twice is safe, the
 *   second call is a no-op once #splash has been removed.
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §7 FIREBASE  → function hideSplash() { … }
 *   - Section §10 AUTH     → hideSplash() called from
 *                             enterApp() (via setTimeout 120ms),
 *                             logout branch, and config-missing
 *                             branch
 *   - Section §35 BOOT     → setTimeout(() => {
 *                               if (!authResolved) {
 *                                 authResolved = true;
 *                                 hideSplash();
 *                                 if (!myUid) $('#authScreen')
 *                                     .classList.remove('hidden');
 *                               }
 *                             }, 3000)
 *
 *   The authScreen reveal step of that IIFE is NOT the
 *   splash's concern — the boot orchestrator (js/boot.js)
 *   will own it. This module only owns the splash hide.
 *
 * DEPENDENCIES (loaded earlier):
 *   none  (pure DOM — no Firebase, no prefs)
 *
 * DOM ELEMENTS USED:
 *   #splash        (show/hide/remove)
 *   .brand-logo    (child — visual only)
 *   .spinner       (child — visual only)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.hideSplash          (original name preserved)
 *   window.SaikoSplash = {
 *     hide, show, isVisible,
 *     armFailsafe, cancelFailsafe,
 *     getFailsafeMs
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  const SPLASH_ID       = 'splash';
  const HIDE_MS         = 400;    // matches original remove() delay
  const DEFAULT_FAILSAFE_MS = 3000; // matches original boot IIFE

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function getSplashEl() {
    return document.getElementById(SPLASH_ID);
  }

  /* ----------------------------------------------------------
   * Module state
   * ---------------------------------------------------------- */
  let _failsafeTimer = null;
  let _failsafeMs = DEFAULT_FAILSAFE_MS;

  /* ----------------------------------------------------------
   * HIDE
   * Behaviour preserved 1:1 from original hideSplash():
   *   1. Find #splash; if absent → no-op (already hidden).
   *   2. Add .hide class (triggers CSS opacity fade).
   *   3. After 400 ms, physically remove the element.
   *
   * Idempotent: safe to call multiple times.
   * ---------------------------------------------------------- */
  function hide() {
    const s = getSplashEl();
    if (!s) return false;

    /* 1) Apply fade-out class ------------------------------ */
    s.classList.add('hide');

    /* 2) Remove after the CSS transition completes --------- */
    setTimeout(function () {
      try {
        if (s.parentNode) s.parentNode.removeChild(s);
        else s.remove();
      } catch (e) {}
    }, HIDE_MS);

    return true;
  }

  /* ----------------------------------------------------------
   * SHOW
   * Convenience re-show. Not used by the original source, but
   * exposed so future re-boot / re-auth flows can re-display
   * the splash without re-loading the page.
   *
   * Since index.html already contains #splash at load time,
   * show() only matters after a previous hide() removed the
   * element. In that case we rebuild a minimal splash node
   * from the same structure the original used.
   * ---------------------------------------------------------- */
  function show() {
    /* Already in DOM? Just remove .hide ------------------- */
    let s = getSplashEl();
    if (s) {
      s.classList.remove('hide');
      return true;
    }

    /* Rebuild from scratch --------------------------------- */
    try {
      s = document.createElement('div');
      s.className = 'splash';
      s.id = SPLASH_ID;

      /* Inner structure preserved from original HTML:
       *   <div class="brand-logo">
       *     <img ... class="logo-img">
       *   </div>
       *   <div class="spinner"></div>
       * --------------------------------------------------- */
      const logoWrap = document.createElement('div');
      logoWrap.className = 'brand-logo';

      const img = document.createElement('img');
      img.alt = 'InnocentSaiko';
      img.className = 'logo-img';
      // Prefer the live URL from the current <head> icon or
      // any existing splash logo to avoid hardcoding.
      img.src = pickLogoUrl();

      logoWrap.appendChild(img);

      const spinner = document.createElement('div');
      spinner.className = 'spinner';

      s.appendChild(logoWrap);
      s.appendChild(spinner);

      document.body.appendChild(s);
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * pickLogoUrl
   * Returns a logo URL without hardcoding:
   *   1. If the app exposes a global LOGO_URL, use it.
   *   2. Otherwise, use the <link rel="icon"> href.
   *   3. Fall back to the original hosted URL.
   * ---------------------------------------------------------- */
  function pickLogoUrl() {
    try {
      if (typeof LOGO_URL === 'string' && LOGO_URL) return LOGO_URL;
    } catch (e) {}

    try {
      const link = document.querySelector('link[rel="icon"]');
      if (link && link.href) return link.href;
    } catch (e) {}

    return 'https://i.ibb.co/mFYtJvRL/file-0000000024f48211b152c5f12db975f9.png';
  }

  /* ----------------------------------------------------------
   * IS VISIBLE
   * True when #splash is currently in the DOM.
   * ---------------------------------------------------------- */
  function isVisible() {
    return !!getSplashEl();
  }

  /* ----------------------------------------------------------
   * ARM FAILSAFE
   * Schedules a one-shot timer that will call hide() if the
   * splash is still present. Cancels any prior schedule.
   *
   * Original used 3000 ms in the boot IIFE. Default matches.
   * ---------------------------------------------------------- */
  function armFailsafe(ms) {
    cancelFailsafe();
    _failsafeMs = (typeof ms === 'number' && ms > 0) ? ms : DEFAULT_FAILSAFE_MS;
    _failsafeTimer = setTimeout(function () {
      _failsafeTimer = null;
      if (isVisible()) hide();
    }, _failsafeMs);
    return _failsafeMs;
  }

  /* ----------------------------------------------------------
   * CANCEL FAILSAFE
   * ---------------------------------------------------------- */
  function cancelFailsafe() {
    if (_failsafeTimer) {
      clearTimeout(_failsafeTimer);
      _failsafeTimer = null;
      return true;
    }
    return false;
  }

  function getFailsafeMs() { return _failsafeMs; }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.hideSplash = hide;

  window.SaikoSplash = {
    hide: hide,
    show: show,
    isVisible: isVisible,
    armFailsafe: armFailsafe,
    cancelFailsafe: cancelFailsafe,
    getFailsafeMs: getFailsafeMs
  };

  /* ----------------------------------------------------------
   * AUTO-ARM FAILSAFE
   * The original boot IIFE scheduled this at document load.
   * We arm it here so the splash is guaranteed to disappear
   * even if every downstream module fails.
   *
   * The authScreen-reveal half of that original IIFE is NOT
   * handled here — it belongs to js/boot.js. This module only
   * guarantees the splash hides.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      armFailsafe(DEFAULT_FAILSAFE_MS);
    }, { once: true });
  } else {
    armFailsafe(DEFAULT_FAILSAFE_MS);
  }

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 014 — splash-screen ready');
  } catch (e) {}

})();