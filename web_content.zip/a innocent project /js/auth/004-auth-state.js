/* ============================================================
 * FEATURE:        Auth State Persistence
 * FEATURE NUMBER: 004
 * FILE:           js/auth/004-auth-state.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Central orchestrator for the authenticated session.
 *   - Attaches firebase.auth().onAuthStateChanged(...)
 *   - On LOGIN : sets global myUid, subscribes to the user's
 *                profile node (users/{uid}), triggers
 *                enterApp() when the profile is ready.
 *   - On LOGOUT: tears down profile/presence listeners,
 *                clears globals, hides #app, shows
 *                #authScreen, closes all overlays.
 *
 *   Additional subsystems (auto-profile-create, presence,
 *   blocked-users, nicknames, sessions) are invoked through
 *   optional global functions so each one can live in its own
 *   feature file. If a subsystem is not yet loaded, the
 *   call is safely skipped (no crash).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10 AUTH  →  auth.onAuthStateChanged(user => …)
 *   (also references setupPresence, listenBlocked,
 *    listenNicknames, registerSession, detachAll, enterApp,
 *    closeAllOverlays)
 *
 * DEPENDENCIES (loaded earlier):
 *   - firebase auth & db instances (core/firebase-init)
 *   - configOK flag (core/firebase-init)
 *   - now() timestamp helper (core/utils)
 *   - hideSplash() (auth/014-splash-screen)
 *   - enterApp()  (boot orchestrator)
 *   - Optional (may be absent → safe-skipped):
 *       setupPresence, listenBlocked, listenNicknames,
 *       registerSession, detachAll, closeAllOverlays
 *
 * DOM ELEMENTS USED:
 *   #app, #authScreen
 *
 * FIREBASE PATHS:
 *   Auth : onAuthStateChanged
 *   RTDB : users/{uid}                (read, listen, write default)
 *
 * GLOBAL EXPORTS:
 *   window.myUid
 *   window.myProfile
 *   window.authResolved
 *   window.appEntered
 *   window.SaikoAuthState = {
 *     init, isLoggedIn, getUid, getProfile,
 *     onLogin, offLogin, onLogout, offLogout
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function $(sel) { return document.querySelector(sel); }

  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) {}
    return Date.now();
  }

  function isConfigOK() {
    try {
      return typeof configOK !== 'undefined' && !!configOK;
    } catch (e) { return false; }
  }

  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) {}
    return null;
  }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * Safe optional-global invoker
   * Calls fnName(...args) if defined, otherwise no-op.
   * ---------------------------------------------------------- */
  function safeCall(fnName, args) {
    try {
      const fn = window[fnName];
      if (typeof fn === 'function') {
        return fn.apply(window, args || []);
      }
    } catch (e) {
      // Swallow — auth flow must not break because a sibling
      // module failed to load or threw.
      console.warn('[auth-state] safeCall failed for', fnName, e);
    }
    return undefined;
  }

  /* ----------------------------------------------------------
   * Listener registries — external modules can subscribe to
   * login/logout events without touching internals.
   * ---------------------------------------------------------- */
  const loginHandlers = new Set();
  const logoutHandlers = new Set();

  function emitLogin(user, profile) {
    loginHandlers.forEach(function (fn) {
      try { fn(user, profile); } catch (e) { console.warn(e); }
    });
    // Also dispatch a CustomEvent on window for non-module code
    try {
      window.dispatchEvent(new CustomEvent('saiko:login', {
        detail: { user: user, profile: profile }
      }));
    } catch (e) {}
  }

  function emitLogout() {
    logoutHandlers.forEach(function (fn) {
      try { fn(); } catch (e) { console.warn(e); }
    });
    try {
      window.dispatchEvent(new CustomEvent('saiko:logout'));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Internal state
   * ---------------------------------------------------------- */
  let profileRef = null;
  let profileCb  = null;
  let attached   = false;
  let firstFire  = true;   // first onAuthStateChanged fire (boot)

  /* ----------------------------------------------------------
   * Default profile node written when a user exists in Auth
   * but has no RTDB profile yet. This mirrors the original
   * fallback branch inside profileCb (auto-create).
   *
   * NOTE: the dedicated auto-profile-create module (005)
   * owns richer default writes. This inline fallback only
   * runs if 005 is not yet loaded, guaranteeing the app
   * still boots.
   * ---------------------------------------------------------- */
  async function createDefaultProfile(fbDb, user) {
    const created = timeNow();
    const fallbackName = (user.email || 'User').split('@')[0];
    const payload = {
      uid: user.uid,
      name: fallbackName,
      searchName: fallbackName.toLowerCase(),
      email: user.email || '',
      photo: '',
      cover: '',
      bio: '',
      dob: '',
      relationship: '',
      online: true,
      lastSeen: created,
      createdAt: created,
      updatedAt: created,
      xp: 0,
      level: 1
    };
    await fbDb.ref('users/' + user.uid).set(payload);
    return payload;
  }

  /* ----------------------------------------------------------
   * ON LOGIN
   * ---------------------------------------------------------- */
  function handleLogin(user) {
    const fbDb = getDB();
    if (!fbDb) return;

    /* 1) Publish global uid -------------------------------- */
    window.myUid = user.uid;

    /* 2) Detach any previous profile listener -------------- */
    if (profileRef && profileCb) {
      try { profileRef.off('value', profileCb); } catch (e) {}
    }

    /* 3) Attach profile listener --------------------------- */
    profileRef = fbDb.ref('users/' + user.uid);
    profileCb = profileRef.on('value', function (snap) {
      const v = snap.val();

      /* 3a) No profile yet → create default and wait ------- */
      if (!v) {
        // Try the dedicated feature-005 module first
        if (typeof window.createAutoProfile === 'function') {
          try { window.createAutoProfile(user); return; } catch (e) {}
        }
        // Fallback: create the minimal node inline
        createDefaultProfile(fbDb, user).catch(function (e) {
          console.warn('[auth-state] default profile create failed', e);
        });
        return;
      }

      /* 3b) Publish profile globally ----------------------- */
      window.myProfile = v;
      if (!window.myProfile.searchName) {
        window.myProfile.searchName = (window.myProfile.name || '').toLowerCase();
      }

      /* 3c) Enter app -------------------------------------- */
      safeCall('enterApp');

      /* 3d) Fire subscriber callbacks ---------------------- */
      emitLogin(user, window.myProfile);
    }, function (err) {
      console.warn('[auth-state] profile listener error', err);
    });

    /* 4) Optional auth-side subsystems --------------------- */
    safeCall('setupPresence');
    safeCall('listenBlocked');
    safeCall('listenNicknames');
    safeCall('registerSession');
  }

  /* ----------------------------------------------------------
   * ON LOGOUT
   * ---------------------------------------------------------- */
  function handleLogout() {
    /* 1) Clear globals ------------------------------------- */
    window.myUid = null;
    window.myProfile = null;

    /* 2) Detach profile listener --------------------------- */
    if (profileRef && profileCb) {
      try { profileRef.off('value', profileCb); } catch (e) {}
    }
    profileRef = null;
    profileCb  = null;

    /* 3) Optional teardown hooks --------------------------- */
    // Presence disconnect cleanup is owned by the presence
    // module; it observes myUid === null and cleans up itself.
    safeCall('detachPresence');   // optional
    safeCall('detachAll');        // detach all live listeners

    /* 4) UI: hide app, show auth --------------------------- */
    const appEl  = $('#app');
    const authEl = $('#authScreen');
    if (appEl)  appEl.classList.add('hidden');
    if (authEl) authEl.classList.remove('hidden');

    /* 5) Close any overlay that might be open -------------- */
    safeCall('closeAllOverlays');

    /* 6) Mark auth resolved & hide splash ------------------ */
    window.authResolved = true;
    safeCall('hideSplash');

    /* 7) Reset app-entered flag ---------------------------- */
    window.appEntered = false;

    /* 8) Fire subscriber callbacks ------------------------- */
    emitLogout();
  }

  /* ----------------------------------------------------------
   * BOOTSTRAP: attach onAuthStateChanged
   * ---------------------------------------------------------- */
  function init() {
    if (attached) return;
    attached = true;

    const fbAuth = getAuth();

    /* Config-missing path — mirrors original behavior -------- */
    if (!isConfigOK() || !fbAuth) {
      safeCall('hideSplash');
      const authEl = $('#authScreen');
      if (authEl) authEl.classList.remove('hidden');

      const m = document.querySelector('#authMsg');
      if (m) {
        m.className = 'auth-msg err';
        m.textContent = 'Firebase config missing. Check console.';
      }
      const lb = document.querySelector('#loginBtn');
      const sb = document.querySelector('#signupBtn');
      if (lb) lb.disabled = true;
      if (sb) sb.disabled = true;

      window.authResolved = true;
      return;
    }

    /* Attach the listener ------------------------------------ */
    fbAuth.onAuthStateChanged(function (user) {
      if (user) {
        handleLogin(user);
      } else {
        handleLogout();
      }
      firstFire = false;
    });
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  function onLogin(fn)  { if (typeof fn === 'function') loginHandlers.add(fn); }
  function offLogin(fn) { loginHandlers.delete(fn); }
  function onLogout(fn) { if (typeof fn === 'function') logoutHandlers.add(fn); }
  function offLogout(fn){ logoutHandlers.delete(fn); }

  function isLoggedIn() { return !!window.myUid; }
  function getUid()      { return window.myUid; }
  function getProfile()  { return window.myProfile; }

  window.SaikoAuthState = {
    init: init,
    isLoggedIn: isLoggedIn,
    getUid: getUid,
    getProfile: getProfile,
    onLogin: onLogin,
    offLogin: offLogin,
    onLogout: onLogout,
    offLogout: offLogout
  };

  /* ----------------------------------------------------------
   * AUTO-INIT
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }

})();