/* ============================================================
 * FEATURE:        Email / Password Login
 * FEATURE NUMBER: 001
 * FILE:           js/auth/001-login.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Handle email/password sign-in via Firebase Authentication.
 *   Wires up the #loginForm submit handler, validates inputs,
 *   toggles the busy state on #loginBtn, and displays any
 *   error/success message via the shared auth-msg helper
 *   (#authMsg element).
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §10 AUTH  →  $("#loginForm").addEventListener(
 *       "submit", ...)
 *
 * DEPENDENCIES (must be loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - configOK       Boolean flag from firebase-init
 *   - t(key)         i18n translator
 *   - authMsg()      Shared auth-message helper
 *   - logActivity()  Optional admin activity logger
 *
 * DOM ELEMENTS USED:
 *   #loginForm, #loginEmail, #loginPassword,
 *   #loginBtn, #authMsg
 *
 * FIREBASE PATHS:
 *   Auth   : signInWithEmailAndPassword(email, password)
 *   RTDB   : (none directly — the auth-state listener in the
 *            auth-state module creates users/{uid} if missing)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoLogin.bind()      → attach submit listener
 *   window.SaikoLogin.unbind()    → detach submit listener
 *   window.SaikoLogin.submit(e)   → programmatic submit
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper (kept local so we do not depend on the
   * global $ being defined at the moment this file executes)
   * ---------------------------------------------------------- */
  function $(sel) {
    return document.querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver — falls back to key if t() is not ready
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) { /* t() not defined yet */ }
    return key;
  }

  /* ----------------------------------------------------------
   * Auth-message helper.
   * If authMsg() is not already defined globally, install a
   * minimal fallback so this module works standalone.
   * ---------------------------------------------------------- */
  function ensureAuthMsgHelper() {
    try {
      if (typeof authMsg === 'function') return;
    } catch (e) { /* not defined */ }

    window.authMsg = function (text, kind) {
      const m = document.querySelector('#authMsg');
      if (!m) return;
      m.textContent = text || '';
      m.className = 'auth-msg' + (text ? ' ' + (kind || 'err') : '');
    };
  }

  /* ----------------------------------------------------------
   * Safe wrapper around optional logActivity global
   * ---------------------------------------------------------- */
  function safeLogActivity(action) {
    try {
      if (typeof logActivity === 'function') {
        logActivity(action);
      }
    } catch (e) { /* swallow — logging must never break login */ }
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Auth instance.
   * Uses the global `auth` created by the firebase-init module.
   * ---------------------------------------------------------- */
  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) { /* auth not defined */ }
    return null;
  }

  /* ----------------------------------------------------------
   * Config guard — mirrors the original `if (!configOK)`
   * Semantics: undefined configOK is treated as NOT OK.
   * ---------------------------------------------------------- */
  function isConfigOK() {
    try {
      return typeof configOK !== 'undefined' && !!configOK;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * SUBMIT HANDLER
   * Behaviour preserved 1:1 from the original index.html
   * ---------------------------------------------------------- */
  async function handleLoginSubmit(event) {
    if (event && typeof event.preventDefault === 'function') {
      event.preventDefault();
    }

    /* 1) Config guard ---------------------------------------- */
    if (!isConfigOK()) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 2) Read DOM inputs ------------------------------------- */
    const emailEl = $('#loginEmail');
    const passEl  = $('#loginPassword');
    if (!emailEl || !passEl) return;

    const email = (emailEl.value || '').trim();
    const pass  = passEl.value || '';

    /* 3) Client-side validation ------------------------------ */
    if (!email || !pass) {
      window.authMsg(T('fill_all'));
      return;
    }

    /* 4) Auth instance guard --------------------------------- */
    const fbAuth = getAuth();
    if (!fbAuth) {
      window.authMsg(T('config_missing'));
      return;
    }

    /* 5) Button busy state ----------------------------------- */
    const btn = $('#loginBtn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = T('please_wait');
    }

    /* 6) Attempt sign-in ------------------------------------- */
    try {
      await fbAuth.signInWithEmailAndPassword(email, pass);

      // Clear any previous error
      window.authMsg('');

      // Optional admin activity log
      safeLogActivity('login');

      // Note: onAuthStateChanged (handled in the auth-state
      // module) will hide #authScreen and reveal #app.
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('login_failed');
      window.authMsg(msg);
    } finally {
      /* 7) Restore button state ------------------------------ */
      if (btn) {
        btn.disabled = false;
        btn.textContent = T('login_btn');
      }
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * ---------------------------------------------------------- */
  function bind() {
    const form = document.querySelector('#loginForm');
    if (!form) return false;
    if (form.dataset.loginBound === '1') return true;
    form.dataset.loginBound = '1';
    form.addEventListener('submit', handleLoginSubmit);
    return true;
  }

  function unbind() {
    const form = document.querySelector('#loginForm');
    if (!form) return;
    form.removeEventListener('submit', handleLoginSubmit);
    delete form.dataset.loginBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoLogin = {
    bind: bind,
    unbind: unbind,
    submit: handleLoginSubmit
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Original code attached the listener immediately because
   * the script tag sits at the end of <body>. To be safe
   * when this module is loaded elsewhere, we also handle the
   * DOMContentLoaded case.
   * ---------------------------------------------------------- */
  ensureAuthMsgHelper();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

})();