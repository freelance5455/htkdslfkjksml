/* ============================================================
 * FEATURE:        Blocked Logout
 * FEATURE NUMBER: 013
 * FILE:           js/auth/013-blocked-logout.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Wires the "#blkLogout" button on the Account-Restricted
 *   overlay (#blockedOverlay) so a restricted user can still
 *   sign out of the device.
 *
 *   Flow (behaviour preserved 1:1 from the original inline
 *   handler in index.html §35 BOOT):
 *
 *     Step 1 — best-effort cleanup while still authenticated:
 *              • userCalls/{myUid}.remove()
 *              • users/{myUid}.update({ online:false,
 *                                       lastSeen: now() })
 *              • userSessions/{myUid}/{sid}.remove()
 *              Each call is individually guarded with
 *              .catch(() => {}) so a single failure never
 *              blocks signOut.
 *
 *     Step 2 — auth.signOut()
 *
 *     Step 3 — manual UI teardown:
 *              • #blockedOverlay.style.display = 'none'
 *              • #authScreen.classList.remove('hidden')
 *              • #app.classList.add('hidden')
 *
 *              The manual teardown is deliberately NOT
 *              delegated to the auth-state listener, because
 *              the restricted-overlay is shown *before*
 *              onAuthStateChanged fires back. Preserving the
 *              original order prevents a visual flash where
 *              the overlay stays on-screen over the login form.
 *
 *     Errors → toast(err.message || t('error'), 'err')
 *
 *   NOTE: This is a DIFFERENT flow from Feature 008
 *   (js/auth/008-logout.js). Feature 008 uses a confirmation
 *   dialog and relies on the auth-state listener for UI
 *   teardown. This file (013) skips the dialog and performs
 *   the teardown inline — matching the original code exactly.
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §35 BOOT
 *       $('#blkLogout').addEventListener('click', async () => {
 *         …cleanup…
 *         await auth.signOut();
 *         $('#blockedOverlay').style.display = 'none';
 *         $('#authScreen').classList.remove('hidden');
 *         $('#app').classList.add('hidden');
 *       });
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - db             Firebase Realtime Database (firebase-init)
 *   - myUid          global current-uid
 *   - now()          Timestamp helper
 *   - t(key)         i18n translator
 *   - toast(msg,k)   Optional toast notifier
 *
 * DOM ELEMENTS USED:
 *   #blkLogout, #blockedOverlay, #authScreen, #app
 *
 * FIREBASE PATHS (all best-effort, all cleanup):
 *   RTDB : userCalls/{myUid}                 (remove)
 *          users/{myUid}/online              (write false)
 *          users/{myUid}/lastSeen            (write now)
 *          userSessions/{myUid}/{sid}        (remove)
 *   Auth : auth.signOut()
 *
 * localStorage  : none
 * sessionStorage: 'saiko_session_id'   (read)
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoBlockedLogout = {
 *     bind, unbind,
 *     trigger,
 *     cleanupOnly
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * Optional globals — safely resolved
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) {}
    return Date.now();
  }

  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) {}
    return null;
  }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  function getUid() {
    try {
      return (typeof myUid !== 'undefined' && myUid) ? myUid : null;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * CLEANUP — best-effort removal of session-scoped data.
   * Runs while the user is still authenticated so that
   * Firebase security rules allow the writes/removes.
   *
   * Preserved EXACTLY from the original inline handler:
   *   - userCalls/{myUid}.remove()
   *   - users/{myUid}.update({ online:false, lastSeen: now })
   *   - userSessions/{myUid}/{sid}.remove()
   * Every call is individually guarded with .catch(() => {}).
   * ---------------------------------------------------------- */
  async function cleanupOnly() {
    const fbDb = getDB();
    const uid = getUid();
    if (!fbDb || !uid) return;

    /* 1) Incoming-call queue ------------------------------- */
    try {
      await fbDb.ref('userCalls/' + uid).remove().catch(function () {});
    } catch (e) {}

    /* 2) Presence — offline + lastSeen --------------------- */
    try {
      await fbDb.ref('users/' + uid)
        .update({ online: false, lastSeen: timeNow() })
        .catch(function () {});
    } catch (e) {}

    /* 3) Current session entry ----------------------------- */
    try {
      const sid = sessionStorage.getItem('saiko_session_id');
      if (sid) {
        await fbDb.ref('userSessions/' + uid + '/' + sid)
          .remove()
          .catch(function () {});
      }
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * TRIGGER — main handler for #blkLogout
   * Behaviour preserved 1:1 from the original inline handler.
   * ---------------------------------------------------------- */
  async function trigger() {
    try {
      /* 1) Cleanup (best-effort) -------------------------- */
      await cleanupOnly();

      /* 2) Sign out --------------------------------------- */
      const fbAuth = getAuth();
      if (fbAuth) {
        await fbAuth.signOut();
      }

      /* 3) Manual UI teardown ----------------------------- *
       *  Original order preserved:
       *    - hide the blocked overlay
       *    - reveal the login screen
       *    - hide the main app shell
       *  This is intentionally NOT delegated to the auth
       *  listener so the restricted-overlay disappears
       *  immediately (no flash of overlay over the login
       *  screen while onAuthStateChanged settles).
       * ---------------------------------------------------- */
      const ov = document.getElementById('blockedOverlay');
      if (ov) ov.style.display = 'none';

      const authEl = document.getElementById('authScreen');
      if (authEl) authEl.classList.remove('hidden');

      const appEl = document.getElementById('app');
      if (appEl) appEl.classList.add('hidden');

    } catch (err) {
      const msg = (err && err.message) ? err.message : T('error');
      safeToast(msg, 'err');
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Idempotent via dataset guard so re-renders do not stack
   * multiple listeners on the same button.
   * ---------------------------------------------------------- */
  function bind(root) {
    const scope = root || document;
    const btn = qs('#blkLogout', scope);
    if (!btn) return false;
    if (btn.dataset.blkLogoutBound === '1') return true;
    btn.dataset.blkLogoutBound = '1';
    btn.addEventListener('click', trigger);
    return true;
  }

  function unbind(root) {
    const scope = root || document;
    const btn = qs('#blkLogout', scope);
    if (!btn) return;
    btn.removeEventListener('click', trigger);
    delete btn.dataset.blkLogoutBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoBlockedLogout = {
    bind: bind,
    unbind: unbind,
    trigger: trigger,
    cleanupOnly: cleanupOnly
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * The button lives in index.html so it exists on first
   * paint; auto-bind anyway to stay consistent with the
   * other feature modules.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 013 — blocked-logout ready');
  } catch (e) {}

})();