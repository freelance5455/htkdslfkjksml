/* ============================================================
 * FEATURE:        Logout
 * FEATURE NUMBER: 008
 * FILE:           js/auth/008-logout.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Central logout flow for the authenticated session.
 *
 *   Step 1 — Confirm dialog (title: t('logout'),
 *            body: t('confirm_logout')). Abort if cancelled.
 *
 *   Step 2 — Best-effort cleanup while still authenticated:
 *            • Remove the incoming-call queue node
 *              (userCalls/{myUid}) so this device stops
 *              receiving ring events.
 *            • Mark the profile offline
 *              (users/{myUid}/online = false,
 *               users/{myUid}/lastSeen = now()).
 *            • Remove the current session entry
 *              (userSessions/{myUid}/{sid}) using the
 *              sessionStorage key 'saiko_session_id'.
 *            Each cleanup call is individually guarded with
 *            .catch(() => {}) so a single failure never
 *            prevents signOut.
 *
 *   Step 3 — auth.signOut(). This triggers the auth-state
 *            listener (feature 004), which performs the UI
 *            teardown (hide #app, show #authScreen, close
 *            overlays, detach listeners).
 *
 *   Renders the "#accLogout" danger button that lives inside
 *   the Account settings page (fragment only). Sibling
 *   features 006 & 007 render their own fragments; the
 *   account-page coordinator stitches all three together.
 *
 * ORIGINAL LOCATION (index.html):
 *   - doLogout()         → the main logout routine
 *   - accountHTML()      → <button id="accLogout"> fragment
 *   - wireAccount()      → $('#accLogout').addEventListener(
 *                            'click', doLogout)
 *   - openSettingsSidebar() → the "logout" sidebar item calls
 *                            doLogout()
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - db             Firebase Realtime Database (firebase-init)
 *   - myUid          global current-uid
 *   - now()          Timestamp helper
 *   - t(key)         i18n translator
 *   - esc(str)       HTML-escape helper (local fallback OK)
 *   - toast(msg,k)   Optional toast
 *   - confirmDialog  Confirm modal helper
 *
 * DOM ELEMENTS USED:
 *   #accLogout                (account page)
 *   [data-set="logout"]       (settings sidebar item)
 *
 * FIREBASE PATHS (all best-effort, all cleanup):
 *   RTDB : userCalls/{myUid}                 (remove)
 *          users/{myUid}/online              (write false)
 *          users/{myUid}/lastSeen            (write now)
 *          userSessions/{myUid}/{sid}        (remove)
 *   Auth : auth.signOut()
 *
 * localStorage  : none
 * sessionStorage: 'saiko_session_id'   (read)
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.doLogout               (preserves original name)
 *   window.SaikoLogout = {
 *     doLogout,
 *     renderFragment,
 *     bindAccountBtn,
 *     bindSidebarItem,
 *     cleanupOnly
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try {
      if (typeof window.esc === 'function') return window.esc(str);
    } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional globals — safely resolved
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  function timeNow() {
    try {
      if (typeof now === 'function') return now();
    } catch (e) {}
    return Date.now();
  }

  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) {}
    return null;
  }

  function getDB() {
    try {
      if (typeof db !== 'undefined' && db) return db;
    } catch (e) {}
    return null;
  }

  function getUid() {
    try {
      return (typeof myUid !== 'undefined' && myUid) ? myUid : null;
    } catch (e) {}
    return null;
  }

  function askConfirm(title, text) {
    try {
      if (typeof confirmDialog === 'function') return confirmDialog(title, text);
    } catch (e) {}
    // Fallback — never blocks signOut if confirmDialog is missing.
    return Promise.resolve(true);
  }

  /* ----------------------------------------------------------
   * CLEANUP — best-effort removal of session-scoped data.
   * Runs while the user is still authenticated so that
   * Firebase security rules allow the writes/removes.
   *
   * Preserved EXACTLY from the original doLogout() body:
   *   - userCalls/{myUid}.remove()
   *   - users/{myUid}.update({ online:false, lastSeen: now })
   *   - userSessions/{myUid}/{sid}.remove()
   * Every call is individually guarded with .catch(() => {}).
   * ---------------------------------------------------------- */
  async function cleanupOnly() {
    const fbDb = getDB();
    const uid = getUid();
    if (!fbDb || !uid) return;

    /* 1) Incoming-call queue ------------------------------- */
    try {
      await fbDb.ref('userCalls/' + uid).remove().catch(function () {});
    } catch (e) {}

    /* 2) Presence — offline + lastSeen --------------------- */
    try {
      await fbDb.ref('users/' + uid)
        .update({ online: false, lastSeen: timeNow() })
        .catch(function () {});
    } catch (e) {}

    /* 3) Current session entry ----------------------------- */
    try {
      const sid = sessionStorage.getItem('saiko_session_id');
      if (sid) {
        await fbDb.ref('userSessions/' + uid + '/' + sid)
          .remove()
          .catch(function () {});
      }
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * MAIN LOGOUT
   * Public — exposed as window.doLogout for backward compat
   * with the original single-file build.
   * ---------------------------------------------------------- */
  async function doLogout() {
    /* 1) Confirm ------------------------------------------- */
    const ok = await askConfirm(T('logout'), T('confirm_logout'));
    if (!ok) return false;

    /* 2) Cleanup + signOut --------------------------------- */
    try {
      await cleanupOnly();

      const fbAuth = getAuth();
      if (fbAuth) {
        await fbAuth.signOut();
      }

      /* UI teardown is handled by the auth-state listener
       * (feature 004). We do NOT duplicate it here. */

      return true;
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('error');
      safeToast(msg, 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * The "#accLogout" danger button that belongs to the
   * Account settings page. Same ID, same classes, same
   * spacing as the original accountHTML() output.
   * ---------------------------------------------------------- */
  function renderFragment() {
    return (
      '<button class="btn danger block" id="accLogout" ' +
        'style="margin-top:1.2rem">' +
        esc(T('logout')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * BIND — Account page button
   * Wires #accLogout → doLogout(). Re-bind-safe via dataset.
   * ---------------------------------------------------------- */
  function bindAccountBtn(root) {
    const scope = root || document;
    const btn = qs('#accLogout', scope);
    if (!btn) return false;
    if (btn.dataset.logoutBound === '1') return true;
    btn.dataset.logoutBound = '1';
    btn.addEventListener('click', doLogout);
    return true;
  }

  /* ----------------------------------------------------------
   * BIND — Settings sidebar item
   * The sidebar module (feature 039) renders items with
   * [data-set="<key>"]. This binds ONLY the "logout" key so
   * that no other sidebar key is affected.
   * ---------------------------------------------------------- */
  function bindSidebarItem(root) {
    const scope = root || document;
    const items = qsa('[data-set="logout"]', scope);
    if (!items.length) return false;

    let boundCount = 0;
    items.forEach(function (n) {
      if (n.dataset.logoutBound === '1') return;
      n.dataset.logoutBound = '1';
      n.addEventListener('click', function (e) {
        // Mirror the original click flow: close the sidebar
        // is the sidebar module's concern; here we just trigger
        // the logout dialog.
        if (e && typeof e.preventDefault === 'function') e.preventDefault();
        doLogout();
      });
      boundCount++;
    });
    return boundCount > 0;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.doLogout = doLogout;

  window.SaikoLogout = {
    doLogout: doLogout,
    renderFragment: renderFragment,
    bindAccountBtn: bindAccountBtn,
    bindSidebarItem: bindSidebarItem,
    cleanupOnly: cleanupOnly
  };

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 008 — logout ready');
  } catch (e) {}

})();