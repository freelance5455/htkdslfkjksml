/* ============================================================
 * FEATURE:        Change Email
 * FEATURE NUMBER: 006
 * FILE:           js/auth/006-change-email.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Provides the "Account → Email" subsection of the Account
 *   settings page. Renders:
 *     - <input id="accEmail">   (pre-filled with current email)
 *     - <button id="accEmailBtn"> change-email trigger
 *   and wires the click handler that calls
 *   auth.currentUser.updateEmail(newEmail).
 *
 *   In the original single-file build, this HTML lived inside
 *   the larger `accountHTML()` string and the click handler
 *   lived inside `wireAccount()`. Feature 006 owns ONLY the
 *   email subsection so that password (007) and logout (008)
 *   can live in their own files. A higher-level settings page
 *   coordinator (js/settings/account.js) will stitch the three
 *   fragments together.
 *
 * ORIGINAL LOCATION (index.html):
 *   - accountHTML()      → the <input id="accEmail"> and
 *                          <button id="accEmailBtn"> block
 *   - wireAccount()      → $('#accEmailBtn').addEventListener
 *                          ('click', async () => { … })
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - auth           Firebase Auth instance (firebase-init)
 *   - t(key)         i18n translator
 *   - esc(str)       HTML-escape helper (falls back to local)
 *   - toast(msg,k)   Optional toast notifier
 *
 * DOM ELEMENTS USED:
 *   #accEmail, #accEmailBtn
 *
 * FIREBASE PATHS:
 *   Auth : auth.currentUser.updateEmail(newEmail)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoChangeEmail = {
 *     renderFragment,     → returns HTML string for the section
 *     bind,               → attach click handler inside a root
 *     unbind,             → detach click handler
 *     trigger,            → programmatic change-email
 *     getCurrentEmail     → read current Firebase Auth email
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper — prefers global esc() if present,
   * otherwise uses a minimal built-in implementation that
   * matches the global one's output for &, <, >, ", '.
   * ---------------------------------------------------------- */
  function esc(str) {
    try {
      if (typeof window.esc === 'function') return window.esc(str);
    } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast notifier — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Resolve Firebase Auth instance
   * ---------------------------------------------------------- */
  function getAuth() {
    try {
      if (typeof auth !== 'undefined' && auth) return auth;
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * Read current email from Firebase Auth
   * (Guarded: returns '' when auth/user missing.)
   * ---------------------------------------------------------- */
  function getCurrentEmail() {
    const fbAuth = getAuth();
    if (!fbAuth || !fbAuth.currentUser) return '';
    return fbAuth.currentUser.email || '';
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Returns the HTML for the email subsection of the Account
   * settings page. Structure is preserved 1:1 from the original
   * accountHTML() — same IDs, same classes, same order.
   * ---------------------------------------------------------- */
  function renderFragment() {
    const currentEmail = getCurrentEmail();

    return (
      '<div class="field">' +
        '<label>' + esc(T('email')) + '</label>' +
        '<input class="input" id="accEmail" type="email" value="' +
          esc(currentEmail) +
        '">' +
      '</div>' +
      '<button class="btn ghost block" id="accEmailBtn" ' +
        'style="margin-bottom:.8rem">' +
        esc(T('change_email')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * TRIGGER — performs the change-email operation.
   * Behaviour preserved 1:1 from the original wireAccount()
   * click handler:
   *   1. read #accEmail value, trim
   *   2. if empty → toast(fill_all, err); return
   *   3. auth.currentUser.updateEmail(v)
   *   4. success → toast(email_changed, ok)
   *   5. error   → toast(err.message || error, err)
   * ---------------------------------------------------------- */
  async function trigger() {
    const input = qs('#accEmail');
    const v = input ? String(input.value || '').trim() : '';

    /* 1) Presence check ------------------------------------- */
    if (!v) {
      safeToast(T('fill_all'), 'err');
      return false;
    }

    /* 2) Auth + user guard ---------------------------------- */
    const fbAuth = getAuth();
    if (!fbAuth || !fbAuth.currentUser) {
      safeToast(T('error'), 'err');
      return false;
    }

    /* 3) Attempt change ------------------------------------- */
    try {
      await fbAuth.currentUser.updateEmail(v);
      safeToast(T('email_changed'), 'ok');

      /* Fire an event so sibling modules (e.g. profile header)
       * can react without polling. */
      try {
        window.dispatchEvent(new CustomEvent('saiko:email-changed', {
          detail: { email: v }
        }));
      } catch (e) {}

      return true;
    } catch (err) {
      const msg = (err && err.message) ? err.message : T('error');
      safeToast(msg, 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Binds the click handler on #accEmailBtn inside `root`
   * (defaults to document). Uses a data-attribute guard so
   * re-binding is safe across re-renders.
   * ---------------------------------------------------------- */
  function bind(root) {
    const scope = root || document;
    const btn = qs('#accEmailBtn', scope);
    if (!btn) return false;
    if (btn.dataset.changeEmailBound === '1') return true;
    btn.dataset.changeEmailBound = '1';
    btn.addEventListener('click', trigger);
    return true;
  }

  function unbind(root) {
    const scope = root || document;
    const btn = qs('#accEmailBtn', scope);
    if (!btn) return;
    btn.removeEventListener('click', trigger);
    delete btn.dataset.changeEmailBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoChangeEmail = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    trigger: trigger,
    getCurrentEmail: getCurrentEmail
  };

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 006 — change-email ready');
  } catch (e) {}

})();