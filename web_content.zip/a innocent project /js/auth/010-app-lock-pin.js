/* ============================================================
 * FEATURE:        Set / Remove App Lock PIN
 * FEATURE NUMBER: 010
 * FILE:           js/auth/010-app-lock-pin.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The Settings → App Lock page fragment.
 *
 *   Renders:
 *     • #alToggle button whose label and style reflect the
 *       current state of prefs.appLock:
 *         OFF → "Set PIN"      (btn solid)
 *         ON  → "Remove PIN"   (btn danger)
 *     • A helper card with the t('app_lock_hint') copy.
 *
 *   On click:
 *     IF app lock is currently ON:
 *       1. prefs.appLock    = false
 *       2. prefs.appLockPin = ''
 *       3. savePrefs()
 *       4. toast(t('pin_removed'), 'ok')
 *       5. re-render settings page (safe-call openSettingPage)
 *
 *     ELSE (setting a new PIN):
 *       1. promptDialog(t('set_pin'),        '', '4 digits')
 *       2. validate /^\d{4}$/  — else toast wrong_pin and abort
 *       3. promptDialog(t('confirm_pin'),    '', '4 digits')
 *       4. if the two entries differ → toast wrong_pin and abort
 *       5. prefs.appLock    = true
 *       6. prefs.appLockPin = p1
 *       7. savePrefs()
 *       8. toast(t('pin_set'), 'ok')
 *       9. re-render settings page
 *
 *   This module ONLY manages the PIN lifecycle. The runtime
 *   overlay that actually locks the UI lives in Feature 009
 *   (js/auth/009-app-lock-screen.js) and is triggered by the
 *   boot orchestrator via SaikoAppLockScreen.shouldShow().
 *
 * ORIGINAL LOCATION (index.html):
 *   - appLockHTML()   → the fragment string
 *   - wireAppLock()   → $('#alToggle').addEventListener(
 *                          'click', async () => { … })
 *
 * DEPENDENCIES (loaded earlier in global lexical scope):
 *   - prefs                global preference object
 *   - savePrefs()          preference persistence
 *   - promptDialog()       text-input modal helper
 *   - toast(msg, kind)     optional toast notifier
 *   - t(key)               i18n translator
 *   - esc(str)             HTML-escape helper (local fallback)
 *   - openSettingPage()    optional settings-page coordinator
 *
 * DOM ELEMENTS USED:
 *   #alToggle
 *
 * FIREBASE PATHS:
 *   none  (app lock is device-local only)
 *
 * localStorage  : 'saiko_prefs_v7'   (read + write via prefs)
 * sessionStorage: (untouched here — that is Feature 009's job)
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoAppLockPin = {
 *     renderFragment,
 *     bind, unbind,
 *     trigger,
 *     setPin, removePin,
 *     isEnabled,
 *     getConfiguredPin
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) {
    return (root || document).querySelector(sel);
  }

  function T(key) {
    try {
      if (typeof t === 'function') return t(key);
    } catch (e) {}
    return key;
  }

  function esc(str) {
    try {
      if (typeof window.esc === 'function') return window.esc(str);
    } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      })[c];
    });
  }

  function safeToast(msg, kind) {
    try {
      if (typeof toast === 'function') toast(msg, kind);
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prefs access — defensive read
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof prefs !== 'undefined' && prefs) return prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try {
      if (typeof savePrefs === 'function') savePrefs();
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prompt dialog — safe wrapper.
   * Falls back to a promise that resolves to null (i.e. the
   * user "cancelled") so we never hang if the helper is
   * missing during early boot.
   * ---------------------------------------------------------- */
  function askPrompt(title, defaultValue, placeholder) {
    try {
      if (typeof promptDialog === 'function') {
        return promptDialog(title, defaultValue, placeholder);
      }
    } catch (e) {}
    return Promise.resolve(null);
  }

  /* ----------------------------------------------------------
   * Settings-page re-render — safe call.
   * The original wireAppLock() called openSettingPage('app_lock')
   * after a state change to refresh the fragment. In the
   * modular build, the settings coordinator owns that function;
   * we call it only if present, and always dispatch an event
   * so any interested listener can refresh the page.
   * ---------------------------------------------------------- */
  function refreshSettingsPage() {
    try {
      if (typeof window.openSettingPage === 'function') {
        window.openSettingPage('app_lock');
      }
    } catch (e) {}

    try {
      window.dispatchEvent(new CustomEvent('saiko:applock-changed'));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State readers
   * ---------------------------------------------------------- */
  function isEnabled() {
    const p = getPrefs();
    return !!(p && p.appLock);
  }

  function getConfiguredPin() {
    const p = getPrefs();
    return (p && p.appLockPin) ? String(p.appLockPin) : '';
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Preserves the exact structure, IDs, classes, and button
   * label/style toggling from the original appLockHTML().
   * ---------------------------------------------------------- */
  function renderFragment() {
    const on = isEnabled();

    /* Helper card ----------------------------------------- */
    const helperCard =
      '<div class="card">' +
        '<div class="mini">' + esc(T('app_lock_hint')) + '</div>' +
      '</div>';

    /* Toggle button --------------------------------------- */
    /* OFF → "Set PIN"   (btn solid)
     * ON  → "Remove PIN" (btn danger)
     * The label intentionally matches the original:
     *   on  → t('pin_removed') + ' — ' + t('remove')
     *   off → t('set_pin')
     * --------------------------------------------------- */
    const label = on
      ? (T('pin_removed') + ' — ' + T('remove'))
      : T('set_pin');

    const btnClass = 'btn ' + (on ? 'danger' : 'solid') + ' block';

    const toggleBtn =
      '<button class="' + btnClass + '" id="alToggle" ' +
        'style="margin-top:.6rem">' +
        esc(label) +
      '</button>';

    return (
      '<div class="sec-title">' + esc(T('app_lock')) + '</div>' +
      helperCard +
      toggleBtn
    );
  }

  /* ----------------------------------------------------------
   * REMOVE PIN
   * Used by both trigger() and programmatic callers.
   * ---------------------------------------------------------- */
  function removePin() {
    const p = getPrefs();
    if (!p) return false;

    p.appLock = false;
    p.appLockPin = '';
    callSavePrefs();

    /* Also clear the current session unlock flag so the next
     * cold start correctly re-prompts (only relevant if the
     * PIN was set then removed within the same session).
     * This mirrors the intent of the original code, which
     * also clears appLockPin entirely. */
    try {
      if (window.SaikoAppLockScreen &&
          typeof window.SaikoAppLockScreen.clearUnlocked === 'function') {
        window.SaikoAppLockScreen.clearUnlocked();
      }
    } catch (e) {}

    safeToast(T('pin_removed'), 'ok');
    refreshSettingsPage();
    return true;
  }

  /* ----------------------------------------------------------
   * SET PIN
   * Programmatic variant: pass an already-validated 4-digit
   * string. Used internally by trigger() and externally by
   * tests / migration utilities.
   * ---------------------------------------------------------- */
  function setPin(pin) {
    if (!pin || !/^\d{4}$/.test(String(pin))) {
      safeToast(T('wrong_pin'), 'err');
      return false;
    }
    const p = getPrefs();
    if (!p) return false;

    p.appLock = true;
    p.appLockPin = String(pin);
    callSavePrefs();

    /* Mark the current session as unlocked so the user is not
     * immediately locked out of the running app. */
    try {
      if (window.SaikoAppLockScreen &&
          typeof window.SaikoAppLockScreen.setUnlocked === 'function') {
        window.SaikoAppLockScreen.setUnlocked();
      }
    } catch (e) {}

    safeToast(T('pin_set'), 'ok');
    refreshSettingsPage();
    return true;
  }

  /* ----------------------------------------------------------
   * TRIGGER — the #alToggle click handler.
   * Behaviour preserved 1:1 from the original wireAppLock().
   * ---------------------------------------------------------- */
  async function trigger() {
    /* CASE 1 — currently ON → remove PIN ------------------ */
    if (isEnabled()) {
      removePin();
      return;
    }

    /* CASE 2 — currently OFF → set a new PIN -------------- */
    const p1 = await askPrompt(T('set_pin'), '', '4 digits');
    if (!p1 || !/^\d{4}$/.test(String(p1))) {
      safeToast(T('wrong_pin'), 'err');
      return;
    }

    const p2 = await askPrompt(T('confirm_pin'), '', '4 digits');
    if (String(p1) !== String(p2)) {
      safeToast(T('wrong_pin'), 'err');
      return;
    }

    setPin(p1);
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Wires the click handler on #alToggle inside `root`
   * (defaults to document). Re-bind-safe via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    const scope = root || document;
    const btn = qs('#alToggle', scope);
    if (!btn) return false;
    if (btn.dataset.appLockPinBound === '1') return true;
    btn.dataset.appLockPinBound = '1';
    btn.addEventListener('click', trigger);
    return true;
  }

  function unbind(root) {
    const scope = root || document;
    const btn = qs('#alToggle', scope);
    if (!btn) return;
    btn.removeEventListener('click', trigger);
    delete btn.dataset.appLockPinBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoAppLockPin = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    trigger: trigger,
    setPin: setPin,
    removePin: removePin,
    isEnabled: isEnabled,
    getConfiguredPin: getConfiguredPin
  };

  /* ----------------------------------------------------------
   * BOOT LOG (single line — migration visibility only)
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 010 — app-lock-pin ready');
  } catch (e) {}

})();