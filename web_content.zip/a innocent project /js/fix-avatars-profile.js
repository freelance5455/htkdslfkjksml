/* ============================================================
 * SAIKO FIX — Avatar + User Search (INLINE STYLES v4)
 * FILE: js/_fix-avatars-profile.js
 * ============================================================ */
(function () {
  'use strict';

  var VERSION = 'v4-inline';

  /* ---------- LOAD BANNER ---------- */
  setTimeout(function () {
    try {
      if (!document.body) return;
      var b = document.createElement('div');
      b.id = '__afix_banner';
      b.style.cssText =
        'position:fixed;top:.3rem;left:.3rem;right:.3rem;' +
        'padding:.6rem .75rem;border-radius:.7rem;' +
        'font-size:.78rem;font-weight:800;z-index:2147483647;' +
        'text-align:center;font-family:monospace;' +
        'background:#2ecc8f;color:#062014;' +
        'box-shadow:0 6px 22px rgba(0,0,0,.5);';
      b.textContent = '✓ Avatar Fix ' + VERSION + ' LOADED';
      document.body.appendChild(b);
      setTimeout(function () { try { b.remove(); } catch (e) {} }, 6000);
    } catch (e) {}
  }, 100);

  console.log('[avatar-fix] BOOTED ' + VERSION);

  /* ---------- HELPERS ---------- */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
    });
  }
  function fmtDate(ts) {
    if (!ts) return '—';
    try {
      return new Date(ts).toLocaleDateString(undefined,
        { year:'numeric', month:'short', day:'numeric' });
    } catch (e) { return '—'; }
  }
  function T(k) {
    try { if (typeof window.t === 'function') return window.t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      if (typeof window[name] === 'function') return window[name].apply(window, args || []);
    } catch (e) {}
    return undefined;
  }

  /* ============================================================
   * INLINE-STYLED AVATAR — NO CSS CLASS DEPENDENCY
   * ============================================================ */
  function makeAvatarHTML(url, name, size) {
    size = size || 40;
    var px = size + 'px';
    var fontSize = Math.round(size * 0.38) + 'px';
    var nm = String(name || 'User').trim();
    var init = (nm.charAt(0) || '?').toUpperCase();

    var boxStyle =
      'width:' + px + ';height:' + px + ';' +
      'min-width:' + px + ';min-height:' + px + ';' +
      'border-radius:50%;overflow:hidden;' +
      'display:flex;align-items:center;justify-content:center;' +
      'background:#1c2030;color:#8b93a7;' +
      'font-weight:800;font-size:' + fontSize + ';' +
      'border:1.5px solid rgba(255,255,255,.12);' +
      'flex:0 0 auto;position:relative;';

    var hasUrl = url && String(url).trim().length > 0;

    /* If image: render initials BEHIND + img absolutely ON TOP */
    if (hasUrl) {
      return (
        '<div style="' + boxStyle + '">' +
          '<span style="position:absolute;inset:0;' +
            'display:flex;align-items:center;justify-content:center;' +
            'color:#8b93a7;font-weight:800;font-size:' + fontSize + ';">' +
            esc(init) +
          '</span>' +
          '<img src="' + esc(String(url).trim()) + '" alt="" ' +
            'style="position:absolute;inset:0;width:100%;height:100%;' +
            'object-fit:cover;display:block;" ' +
            'onerror="this.style.display=\'none\';" ' +
            'onload="this.style.display=\'block\';">' +
        '</div>'
      );
    }

    /* No image: just initials */
    return (
      '<div style="' + boxStyle + '">' +
        '<span style="position:absolute;inset:0;' +
          'display:flex;align-items:center;justify-content:center;' +
          'color:#8b93a7;font-weight:800;font-size:' + fontSize + ';">' +
          esc(init) +
        '</span>' +
      '</div>'
    );
  }

  /* ---------- INSTALL GLOBAL avatarHTML ---------- */
  function avatarHTML(url, name, cls, uid) {
    var sizeMap = { 'av-32': 32, 'av-40': 40, 'av-56': 56, 'av-88': 88 };
    var size = sizeMap[cls] || 40;
    var base = makeAvatarHTML(url, name, size);

    if (uid) {
      var online = window.onlineUsers && window.onlineUsers[uid];
      if (online) {
        return '<div style="position:relative;display:inline-flex;flex:0 0 auto;">' +
          base +
          '<span style="position:absolute;right:0;bottom:0;width:12px;height:12px;' +
          'border-radius:50%;background:#2ecc8f;' +
          'border:2px solid #101219;display:block;"></span>' +
        '</div>';
      }
    }
    return base;
  }
  window.avatarHTML = avatarHTML;
  console.log('[avatar-fix] avatarHTML installed (inline styles)');

  /* ---------- SIMILARITY ---------- */
  function similarity(a, b) {
    if (!a || !b) return 0;
    if (a === b) return 100;
    if (a.indexOf(b) !== -1 || b.indexOf(a) !== -1) return 80;
    var m = a.length, n = b.length;
    if (Math.abs(m - n) > 3) return 0;
    var dp = new Array(n + 1);
    for (var j = 0; j <= n; j++) dp[j] = j;
    for (var i = 1; i <= m; i++) {
      var prev = dp[0]; dp[0] = i;
      for (var k = 1; k <= n; k++) {
        var tmp = dp[k];
        dp[k] = Math.min(dp[k]+1, dp[k-1]+1, prev + (a[i-1] === b[k-1] ? 0 : 1));
        prev = tmp;
      }
    }
    return Math.max(0, 100 - Math.round((dp[n] / Math.max(m, n)) * 100));
  }

  var sortOrder = 'newest';

  /* ---------- USER SEARCH RENDER ---------- */
  function renderUserSearch(box, q) {
    if (!box) return;
    var users = window.allUsersCache || [];

    if (!users.length) {
      box.innerHTML = '<div style="height:3.4rem;margin-bottom:.5rem;' +
        'background:linear-gradient(90deg,#161923 25%,#1c2030 50%,#161923 75%);' +
        'background-size:200% 100%;border-radius:.7rem;animation:sk 1.3s infinite;"></div>'.repeat(3);
      return;
    }

    var me = window.myUid;
    var nowTs = Date.now();
    var exact = [], partial = [];

    users.forEach(function (u) {
      if (!u || u.uid === me) return;
      if (u.blockedUntil && Number(u.blockedUntil) > nowTs) return;
      var n = (u.searchName || (u.name || '').toLowerCase());
      if (!n) return;
      if (n === q) exact.push(u);
      else if (n.indexOf(q) !== -1) partial.push(u);
      else {
        var sim = similarity(n, q);
        if (sim >= 62) partial.push(Object.assign({}, u, { __sim: sim }));
      }
    });

    function byDate(a, b) {
      var aT = a.createdAt || 0, bT = b.createdAt || 0;
      return sortOrder === 'newest' ? bT - aT : aT - bT;
    }

    exact.sort(byDate);
    partial.sort(function (a, b) {
      var an = a.searchName || '', bn = b.searchName || '';
      var ap = an.indexOf(q), bp = bn.indexOf(q);
      var aH = ap !== -1, bH = bp !== -1;
      if (aH !== bH) return aH ? -1 : 1;
      if (aH && bH) {
        if (ap !== bp) return ap - bp;
        if (an.length !== bn.length) return an.length - bn.length;
      } else {
        var as = a.__sim || 0, bs = b.__sim || 0;
        if (as !== bs) return bs - as;
      }
      return byDate(a, b);
    });

    var list = exact.concat(partial).slice(0, 80);

    /* Header with sort filter */
    var header =
      '<div style="display:flex;justify-content:space-between;align-items:center;' +
      'margin-bottom:.6rem;padding:0 .2rem;">' +
        '<div style="font-size:.7rem;color:#8b93a7;">' +
          list.length + ' user' + (list.length === 1 ? '' : 's') +
        '</div>' +
        '<select id="userSortFilter" style="width:auto;padding:.35rem .55rem;' +
          'font-size:.72rem;border-radius:.6rem;' +
          'background:#1c2030;color:#eef1f8;' +
          'border:1px solid rgba(255,255,255,.12);outline:none;">' +
          '<option value="newest"' + (sortOrder === 'newest' ? ' selected' : '') +
            '>Sort: Newest</option>' +
          '<option value="oldest"' + (sortOrder === 'oldest' ? ' selected' : '') +
            '>Sort: Oldest</option>' +
        '</select>' +
      '</div>';

    if (!list.length) {
      box.innerHTML = header +
        '<div style="text-align:center;padding:2rem 1rem;color:#8b93a7;">' +
          '<p>' + esc(T('no_results') || 'No users found') + '</p>' +
        '</div>';
      wireSort(box, q);
      return;
    }

    /* Cards with INLINE-styled avatar */
    var cards = list.map(function (u) {
      var online = window.onlineUsers && window.onlineUsers[u.uid];
      var statusColor = online ? '#2ecc8f' : '#8b93a7';
      var statusText = online ? (T('online') || 'Online') : (T('offline') || 'Offline');
      var avatarEl = makeAvatarHTML(u.photo || '', u.name || 'User', 40);

      return '<div class="user-card" data-uid="' + esc(u.uid) + '" ' +
        'style="display:flex;align-items:center;gap:.7rem;padding:.65rem;' +
        'border-radius:.9rem;border:1px solid rgba(255,255,255,.08);' +
        'background:#161923;margin-bottom:.5rem;cursor:pointer;">' +
        avatarEl +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-weight:700;font-size:.9rem;color:#eef1f8;' +
            'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' +
            esc(u.name || 'User') +
          '</div>' +
          '<div style="font-size:.76rem;color:#8b93a7;overflow:hidden;' +
            'text-overflow:ellipsis;white-space:nowrap;">' +
            esc((u.bio || '').slice(0, 80) || '—') +
          '</div>' +
          '<div style="font-size:.7rem;color:#8b93a7;margin-top:.15rem;">' +
            esc(T('joining') || 'Joined') + ': ' + esc(fmtDate(u.createdAt)) +
            ' · <span style="color:' + statusColor + ';font-weight:700;">● ' +
            esc(statusText) + '</span>' +
          '</div>' +
        '</div>' +
        '<span style="color:#8b93a7;font-size:1.1rem;">›</span>' +
      '</div>';
    }).join('');

    box.innerHTML = header + cards;
    wireSort(box, q);

    box.querySelectorAll('.user-card').forEach(function (c) {
      c.addEventListener('click', function () {
        var uid = c.getAttribute('data-uid');
        if (!uid) return;
        safeCall('saveRecentSearch', [q, 'users']);
        safeCall('closeOverlay', ['ovSearch']);
        safeCall('detachSearchListener');
        setTimeout(function () { safeCall('openUserProfile', [uid]); }, 100);
      });
    });
  }

  function wireSort(box, q) {
    var sel = box.querySelector('#userSortFilter');
    if (!sel) return;
    sel.addEventListener('change', function () {
      sortOrder = sel.value;
      renderUserSearch(box, q);
    });
  }

  window.runUserSearch = renderUserSearch;
  console.log('[avatar-fix] runUserSearch installed');

  /* ---------- MUTATION OBSERVER ---------- */
  function attachObserver() {
    var box = document.getElementById('searchResults');
    if (!box) { setTimeout(attachObserver, 500); return; }
    if (box.dataset.afixObs === '1') return;
    box.dataset.afixObs = '1';

    try {
      var obs = new MutationObserver(function () {
        if (window.searchTab !== 'users') return;
        if (box.querySelector('#userSortFilter')) return;
        var cards = box.querySelectorAll('.user-card[data-uid]');
        if (!cards.length) return;
        var input = document.getElementById('globalSearchInput');
        var q = input ? (input.value || '').trim().toLowerCase() : '';
        if (!q) return;
        setTimeout(function () {
          if (box.querySelector('#userSortFilter')) return;
          renderUserSearch(box, q);
        }, 30);
      });
      obs.observe(box, { childList: true, subtree: false });
      console.log('[avatar-fix] observer attached');
    } catch (e) {}
  }

  attachObserver();
  setTimeout(attachObserver, 800);
  setTimeout(attachObserver, 2500);

  /* ---------- EXPOSE ---------- */
  window.SaikoAvatarFix = {
    VERSION: VERSION,
    avatarHTML: avatarHTML,
    runUserSearch: renderUserSearch,
    makeAvatarHTML: makeAvatarHTML,
    forceRefresh: function () {
      var box = document.getElementById('searchResults');
      var input = document.getElementById('globalSearchInput');
      if (box && input) renderUserSearch(box, (input.value || '').trim().toLowerCase());
    }
  };

  console.log('[avatar-fix] ready ' + VERSION);

})();