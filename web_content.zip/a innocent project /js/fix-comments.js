/* ============================================================
 * SAIKO FIX — Comments + Reactions + Mentions + User Lists
 * FILE: js/_fix-comments.js
 * ============================================================ */
(function () {
  'use strict';

  var VERSION = 'v1-comments';
  console.log('[comments-fix] BOOTED ' + VERSION);

  /* ---------- LOAD BANNER ---------- */
  setTimeout(function () {
    try {
      if (!document.body) return;
      var b = document.createElement('div');
      b.id = '__cfix_banner';
      b.style.cssText = 'position:fixed;top:.3rem;left:.3rem;right:.3rem;' +
        'padding:.5rem .7rem;border-radius:.7rem;' +
        'font-size:.72rem;font-weight:800;z-index:2147483647;' +
        'text-align:center;font-family:monospace;' +
        'background:#2ecc8f;color:#062014;' +
        'box-shadow:0 6px 22px rgba(0,0,0,.5);';
      b.textContent = '✓ Comments Fix ' + VERSION + ' LOADED';
      document.body.appendChild(b);
      setTimeout(function () { try { b.remove(); } catch (e) {} }, 4000);
    } catch (e) {}
  }, 100);

  /* ---------- HELPERS ---------- */
  function qs(s, r) { return (r || document).querySelector(s); }
  function qsa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[c];
    });
  }
  function getDB() { try { return window.db || null; } catch (e) { return null; } }
  function getUid() { try { return window.myUid || null; } catch (e) { return null; } }
  function getMe() { try { return window.myProfile || {}; } catch (e) { return {}; } }
  function safeCall(n, a) {
    try { var f = window[n]; if (typeof f === 'function') return f.apply(window, a || []); } catch (e) {}
    return undefined;
  }
  function safeToast(m, k) {
    try { if (typeof window.toast === 'function') window.toast(m, k); } catch (e) {}
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') return window.avatarHTML(url, name, cls, uid);
    } catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { return window.findUser ? window.findUser(uid) : null; } catch (e) { return null; }
  }

  /* ============================================================
   * 1. MENTION CLICK → OPEN USER PROFILE
   * ============================================================ */
  document.addEventListener('click', function (e) {
    var mention = e.target && e.target.closest && e.target.closest('.mention');
    if (!mention) return;

    var text = (mention.textContent || '').replace(/^@/, '').trim();
    if (!text) return;

    var users = window.allUsersCache || [];
    var lower = text.toLowerCase();
    var found = null;

    for (var i = 0; i < users.length; i++) {
      var u = users[i];
      if (!u) continue;
      if (u.name && u.name.toLowerCase() === lower) { found = u; break; }
      if (u.searchName && u.searchName === lower) { found = u; break; }
      if (u.username && u.username.toLowerCase() === lower) { found = u; break; }
    }

    if (found && found.uid) {
      e.preventDefault();
      e.stopPropagation();
      console.log('[comments-fix] mention → profile', found.uid);
      safeCall('openUserProfile', [found.uid]);
    } else {
      safeToast('User not found: ' + text);
    }
  }, true);

  /* ============================================================
   * 2. REACT BUTTON → OPEN PICKER
   * ============================================================ */
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.closest) return;
    var btn = e.target.closest('[data-creact]') || e.target.closest('[data-rcrx]');
    if (!btn) return;
    if (btn.closest('#rxPicker')) return;

    var cid = btn.getAttribute('data-creact') || btn.getAttribute('data-rcrx');
    if (!cid) return;

    var pid = null;
    var isReel = false;
    if (btn.closest('#ovReelSplit')) {
      pid = window.rsReelId;
      isReel = true;
    } else if (btn.closest('#ovSplitComments')) {
      pid = window.splitPostId;
      isReel = false;
    } else {
      return;
    }

    if (!pid) return;

    e.preventDefault();
    e.stopPropagation();

    console.log('[comments-fix] react →', cid, 'pid:', pid, 'isReel:', isReel);
    openPicker(pid, cid, isReel);
  }, true);

  /* ============================================================
   * 3. REACTION CHIP CLICK → SHOW USERS
   * ============================================================ */
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.closest) return;
    var chip = e.target.closest('.cmt-rx[data-crx]');
    if (!chip) return;
    if (chip.closest('#rxPicker')) return;

    var cid = chip.getAttribute('data-cid');
    var emoji = chip.getAttribute('data-crx');
    if (!cid || !emoji) return;

    var pid = null;
    var isReel = false;
    if (chip.closest('#ovReelSplit')) {
      pid = window.rsReelId;
      isReel = true;
    } else if (chip.closest('#ovSplitComments')) {
      pid = window.splitPostId;
      isReel = false;
    } else {
      return;
    }

    if (!pid) return;

    e.preventDefault();
    e.stopPropagation();

    console.log('[comments-fix] chip →', emoji, 'cid:', cid);
    showReactionUsers(pid, cid, emoji, isReel);
  }, true);

  /* ============================================================
   * 4. LIKE COUNT CLICK → SHOW USERS
   * ============================================================ */
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.closest) return;
    var cnt = e.target.closest('[data-likecount]');
    if (!cnt) return;

    var pid = cnt.getAttribute('data-likecount');
    if (!pid) return;

    e.preventDefault();
    e.stopPropagation();

    console.log('[comments-fix] like count →', pid);
    showPostLikers(pid);
  }, true);

  /* ============================================================
   * 5. MORE BUTTON → OWN IMPLEMENTATION
   * ============================================================ */
  document.addEventListener('click', function (e) {
    if (!e.target || !e.target.closest) return;
    var moreBtn = e.target.closest('[data-scmenu]');
    if (!moreBtn) return;

    var cid = moreBtn.getAttribute('data-scmenu');
    var pid = window.splitPostId;
    if (!cid || !pid) return;

    e.preventDefault();
    e.stopImmediatePropagation();
    e.stopPropagation();

    console.log('[comments-fix] more → cid:', cid, 'pid:', pid);
    showCommentMenu(pid, cid);
  }, true);

  /* ============================================================
   * 6. PICKER
   * ============================================================ */
  function openPicker(pid, cid, isReel) {
    var RX = ['❤️','😂','😮','😢','😡','👍'];
    var picker = qs('#rxPicker');
    if (!picker) { safeToast('Picker not found', 'err'); return; }

    var map = {};
    if (isReel) {
      map = (window.rsCommentReactions && window.rsCommentReactions[cid]) || {};
    } else {
      map = (window.splitCommentReactions && window.splitCommentReactions[cid]) || {};
    }

    var uid = getUid();
    var mine = map[uid];
    var mineType = (typeof mine === 'string') ? mine : (mine && mine.type);

    picker.innerHTML = RX.map(function (r) {
      var isCur = mineType === r;
      return '<button type="button" data-crx-pick="' + r + '" style="' +
        (isCur ? 'background:var(--accent-soft);border-radius:.7rem;' : '') +
        'font-size:1.6rem;padding:.3rem .4rem;cursor:pointer;border:none;background:transparent;color:inherit;">' +
        r + '</button>';
    }).join('');

    var ov = qs('#ovReactions');
    if (ov) {
      ov.style.zIndex = '9999';
      ov.classList.add('open');
    }

    qsa('[data-crx-pick]', picker).forEach(function (b) {
      b.addEventListener('click', async function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        var emoji = b.getAttribute('data-crx-pick');
        if (ov) ov.classList.remove('open');
        await applyReaction(pid, cid, emoji, isReel);
      });
    });
  }

  /* ============================================================
   * 7. APPLY REACTION
   * ============================================================ */
  async function applyReaction(pid, cid, emoji, isReel) {
    var uid = getUid();
    var fbDb = getDB();
    if (!uid || !fbDb || !pid || !cid || !emoji) return;

    var path = isReel
      ? ('reelCommentReactions/' + pid + '/' + cid + '/' + uid)
      : ('commentReactions/' + pid + '/' + cid + '/' + uid);

    try {
      var ref = fbDb.ref(path);
      var snap = await ref.get();
      var curV = snap.val();
      var curT = (typeof curV === 'string') ? curV : (curV && curV.type);

      if (curT === emoji) {
        await ref.remove();
      } else {
        await ref.set({ type: emoji, at: Date.now() });
        try {
          var cPath = isReel
            ? ('reelComments/' + pid + '/' + cid)
            : ('comments/' + pid + '/' + cid);
          var cs = await fbDb.ref(cPath).get();
          var c = cs.val();
          if (c && c.uid && c.uid !== uid) {
            var me = getMe();
            safeCall('pushNotification', [c.uid, {
              type: 'reaction',
              fromUid: uid,
              fromName: me.name || '',
              fromPhoto: me.photo || '',
              text: emoji + ' ' + (T('reacted_to') || 'reacted'),
              postId: isReel ? null : pid,
              reelId: isReel ? pid : null,
              commentId: cid,
              createdAt: Date.now()
            }]);
          }
        } catch (e) {}
      }

      /* Reload comments */
      if (isReel) {
        if (typeof window.loadReelSplitComments === 'function') window.loadReelSplitComments(pid);
      } else {
        if (typeof window.loadSplitComments === 'function') window.loadSplitComments(pid);
      }

      safeToast(curT === emoji ? 'Reaction removed' : 'Reaction added', 'ok');
    } catch (err) {
      console.error('[comments-fix] reaction error', err);
      safeToast((err && err.message) || 'Reaction failed', 'err');
    }
  }

  /* ============================================================
   * 8. SHOW REACTION USERS
   * ============================================================ */
  async function showReactionUsers(pid, cid, emoji, isReel) {
    var fbDb = getDB();
    if (!fbDb) return;

    var path = isReel
      ? ('reelCommentReactions/' + pid + '/' + cid)
      : ('commentReactions/' + pid + '/' + cid);

    try {
      var snap = await fbDb.ref(path).get();
      var v = snap.val() || {};
      var uids = [];
      Object.keys(v).forEach(function (u) {
        var rv = v[u];
        var rt = (typeof rv === 'string') ? rv : (rv && rv.type);
        if (rt === emoji) uids.push(u);
      });

      if (!uids.length) { safeToast('No ' + emoji + ' reactions yet'); return; }
      renderUsersOverlay(emoji + ' Reactions', uids);
    } catch (err) {
      console.error('[comments-fix] showReactionUsers error', err);
    }
  }

  /* ============================================================
   * 9. SHOW POST LIKERS
   * ============================================================ */
  async function showPostLikers(pid) {
    var fbDb = getDB();
    if (!fbDb) return;

    try {
      var snap = await fbDb.ref('postLikes/' + pid).get();
      var v = snap.val() || {};
      var uids = Object.keys(v);
      if (!uids.length) { safeToast('No likes yet'); return; }
      renderUsersOverlay('Liked by', uids);
    } catch (err) {
      console.error('[comments-fix] showPostLikers error', err);
    }
  }

  /* ============================================================
   * 10. GENERIC USERS OVERLAY
   * ============================================================ */
  function renderUsersOverlay(title, uids) {
    var body = qs('#userListBody');
    var titleEl = qs('#userListTitle');
    if (!body) { safeToast('User list not found', 'err'); return; }

    if (titleEl) titleEl.textContent = title;

    body.innerHTML = uids.map(function (uid) {
      var u = findUser(uid) || { name: 'User', photo: '' };
      return '<div class="user-card" data-cfuid="' + esc(uid) + '" ' +
        'style="display:flex;align-items:center;gap:.7rem;padding:.65rem;' +
        'border-radius:.9rem;border:1px solid rgba(255,255,255,.08);' +
        'background:#161923;margin-bottom:.5rem;cursor:pointer;">' +
        avatarHTML(u.photo, u.name, 'av-40', uid) +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-weight:700;font-size:.9rem;color:#eef1f8;">' +
            esc(u.name) +
          '</div>' +
        '</div>' +
        '<span style="color:#8b93a7;">›</span>' +
      '</div>';
    }).join('');

    qsa('[data-cfuid]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var uid = n.getAttribute('data-cfuid');
        safeCall('closeOverlay', ['ovUserList']);
        safeCall('openUserProfile', [uid]);
      });
    });

    safeCall('openOverlay', ['ovUserList']);
  }

  /* ============================================================
   * 11. COMMENT MENU (More button)
   * ============================================================ */
  async function showCommentMenu(pid, cid) {
    var fbDb = getDB();
    if (!fbDb) return;

    var snap = await fbDb.ref('comments/' + pid + '/' + cid).get();
    var c = snap.val();
    if (!c) { safeToast('Comment not found'); return; }

    var uid = getUid();
    var mine = c.uid === uid;
    var items = [];

    if (mine) {
      items.push({ k: 'edit',   i: '✏️', label: 'Edit Comment' });
      items.push({ k: 'delete', i: '🗑', label: 'Delete Comment', danger: true });
    } else {
      items.push({ k: 'report', i: '🚩', label: 'Report', danger: true });
      items.push({ k: 'block',  i: '🚫', label: 'Block',  danger: true });
    }
    items.push({ k: 'copy', i: '📋', label: 'Copy Text' });

    var sheet = qs('#msgMenuSheet');
    var menu  = qs('#ovMsgMenu');
    if (!sheet || !menu) return;

    sheet.innerHTML = '<div class="sheet-handle"></div>' + items.map(function (it) {
      return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" data-cfm="' + it.k + '">' +
        '<span style="margin-right:.5rem;">' + it.i + '</span>' +
        '<span>' + esc(it.label) + '</span>' +
      '</div>';
    }).join('');

    menu.style.zIndex = '9999';
    menu.classList.add('open');

    qsa('[data-cfm]', sheet).forEach(function (n) {
      n.addEventListener('click', async function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        var k = n.getAttribute('data-cfm');
        menu.classList.remove('open');

        if (k === 'edit') {
          var nt = await safeCall('promptDialog', ['Edit Comment', c.text || '']);
          if (nt == null) return;
          var txt = String(nt).trim();
          if (!txt) return;
          try { await fbDb.ref('comments/' + pid + '/' + cid).update({ text: txt, updatedAt: Date.now() }); }
          catch (e) { safeToast(e.message || 'Failed', 'err'); }
        } else if (k === 'delete') {
          var ok = await safeCall('confirmDialog', ['Delete Comment', 'Are you sure?']);
          if (!ok) return;
          try {
            await fbDb.ref('comments/' + pid + '/' + cid).remove();
            await fbDb.ref('commentReactions/' + pid + '/' + cid).remove();
            safeToast('Deleted', 'ok');
          } catch (e) { safeToast(e.message || 'Failed', 'err'); }
        } else if (k === 'report') {
          safeCall('openReport', ['comment', cid, pid]);
        } else if (k === 'block') {
          safeCall('blockUser', [c.uid]);
        } else if (k === 'copy') {
          try {
            await navigator.clipboard.writeText(c.text || '');
            safeToast('Copied', 'ok');
          } catch (e) { safeToast(c.text || ''); }
        }
      });
    });
  }

  /* ============================================================
   * EXPOSE
   * ============================================================ */
  window.SaikoCommentsFix = {
    VERSION: VERSION,
    openPicker: openPicker,
    applyReaction: applyReaction,
    showReactionUsers: showReactionUsers,
    showPostLikers: showPostLikers,
    showCommentMenu: showCommentMenu
  };

  console.log('[comments-fix] ready ' + VERSION);

})();