/* ============================================================
 * SAIKO FIX — Navigation State (Stuck Overlay Re-Open)
 * FILE: js/_fix-navigation.js
 *
 * BUG:
 *   window.profileTab gets stuck at 'missions' / 'leaderboard'
 *   / 'collections' / 'restricted'. Every re-render of profile
 *   page then re-opens those overlays again.
 *
 * FIX:
 *   1. Before every renderProfilePage(), reset stuck profileTab.
 *   2. Intercept action-chip clicks — open overlay directly,
 *      do NOT touch window.profileTab.
 *   3. When action overlays close, reset profileTab too.
 * ============================================================ */
(function () {
  'use strict';

  var ACTION_TABS = ['collections', 'restricted', 'missions', 'leaderboard'];
  var log = function () {
    try {
      console.debug.apply(console,
        ['[fix-navigation]'].concat(Array.prototype.slice.call(arguments)));
    } catch (e) {}
  };

  log('loading v1-stuck-tab');

  /* ---------- 1. Reset stuck profileTab ---------- */
  function resetStuckProfileTab() {
    if (window.profileTab && ACTION_TABS.indexOf(window.profileTab) !== -1) {
      log('resetting stuck profileTab →', window.profileTab);
      window.profileTab = 'posts';
      return true;
    }
    return false;
  }

  /* ---------- 2. Wrap renderProfilePage ---------- */
  function installWrapper() {
    if (window.__NAV_FIX_WRAPPER) return true;
    var orig = window.renderProfilePage;
    if (typeof orig !== 'function') return false;

    window.renderProfilePage = function () {
      resetStuckProfileTab();
      return orig.apply(this, arguments);
    };
    window.__NAV_FIX_WRAPPER = true;
    log('✓ wrapper installed on renderProfilePage');
    return true;
  }

  /* ---------- 3. Intercept action chip clicks ---------- */
  function installChipInterceptor() {
    if (window.__NAV_FIX_CHIP) return true;
    document.addEventListener('click', function (e) {
      var chip = e.target && e.target.closest ? e.target.closest('[data-ptab]') : null;
      if (!chip) return;
      var tab = chip.getAttribute('data-ptab');
      if (!tab || ACTION_TABS.indexOf(tab) === -1) return;

      /* Stop original profile-page chip handler */
      try { e.stopImmediatePropagation(); } catch (err) {}
      try { e.stopPropagation(); } catch (err) {}
      try { e.preventDefault(); } catch (err) {}

      log('action chip →', tab);

      /* Open overlay directly WITHOUT changing window.profileTab */
      if (tab === 'missions' && typeof window.openMissions === 'function') {
        window.openMissions();
      } else if (tab === 'leaderboard' && typeof window.openLeaderboard === 'function') {
        window.openLeaderboard();
      } else if (tab === 'collections' && typeof window.openCollections === 'function') {
        window.openCollections();
      } else if (tab === 'restricted' && typeof window.openRestrictedPosts === 'function') {
        window.openRestrictedPosts();
      }
    }, true); /* capture phase — runs before target listeners */

    window.__NAV_FIX_CHIP = true;
    log('✓ chip interceptor installed');
    return true;
  }

  /* ---------- 4. Reset on action overlay close ---------- */
  function installCloseHook() {
    if (window.__NAV_FIX_CLOSE) return true;
    var origClose = window.closeOverlay;
    if (typeof origClose !== 'function') return false;

    var ACTION_OVERLAYS = [
      'ovMissions', 'ovLeaderboard', 'ovCollection',
      'ovRestricted', 'ovUserList', 'ovPinBoard'
    ];

    window.closeOverlay = function (id) {
      var result = origClose.apply(this, arguments);
      if (ACTION_OVERLAYS.indexOf(id) !== -1) {
        resetStuckProfileTab();
      }
      return result;
    };
    window.__NAV_FIX_CLOSE = true;
    log('✓ closeOverlay hook installed');
    return true;
  }

  /* ---------- Boot with retries ---------- */
  function boot() {
    var tries = 0;
    function attempt() {
      tries++;
      var w = installWrapper();
      installChipInterceptor();
      installCloseHook();
      if (!w && tries < 25) setTimeout(attempt, 300);
    }
    attempt();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      setTimeout(boot, 150);
    }, { once: true });
  } else {
    setTimeout(boot, 150);
  }

  /* Extra retry — in case page-renderers.js loads very late */
  setTimeout(installWrapper, 1200);
  setTimeout(installWrapper, 2500);

  /* ---------- Expose ---------- */
  window.SaikoNavFix = {
    VERSION: 'v1-stuck-tab',
    resetStuckProfileTab: resetStuckProfileTab,
    ACTION_TABS: ACTION_TABS.slice()
  };

  log('✓ ready');
})();