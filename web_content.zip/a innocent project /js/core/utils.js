/* ============================================================
   SAIKO UTILS - Global Helper Functions
   ============================================================ */

const $  = (s, r) => (r||document).querySelector(s);
const $$ = (s, r) => Array.from((r||document).querySelectorAll(s));
const esc = s => String(s==null?'':s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const now = () => Date.now();

// Time formatting (2m, 3h, etc.)
function timeAgo(ts){
  if(!ts) return '';
  const s = (Date.now()-ts)/1000;
  if(s < 60) return 'now';
  if(s < 3600) return Math.floor(s/60)+'m';
  if(s < 86400) return Math.floor(s/3600)+'h';
  if(s < 604800) return Math.floor(s/86400)+'d';
  return new Date(ts).toLocaleDateString();
}

function fmtDate(ts){ if(!ts) return '—'; return new Date(ts).toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'}); }
function fmtTime(ts){ if(!ts) return ''; return new Date(ts).toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'}); }

function fmtDur(sec){
  sec = Math.max(0, Math.floor(sec||0));
  const m = Math.floor(sec/60), s = sec%60;
  if(m >= 60){ const h = Math.floor(m/60); return h+':'+String(m%60).padStart(2,'0')+String(s).padStart(2,'0'); }
  return m+':'+String(s).padStart(2,'0');
}

// Name initials for avatar
function initials(name){ return (name||'?').trim().charAt(0).toUpperCase() || '?'; }

// Utility to Revoke object URLs to save memory
function cleanupMediaUrl(url){ if(url && url.startsWith('blob:')) URL.revokeObjectURL(url); }

// Basic Debounce for search
function debounce(fn, ms){
  let tm = null;
  return function(){ const a = arguments, c = this; clearTimeout(tm); tm = setTimeout(()=> fn.apply(c,a), ms||250); };
}

// Basic Throttle for scrolling
function throttle(fn, ms){
  let last = 0, tm = null;
  return function(){ const a = arguments, c = this, t = Date.now();
    if(t - last >= ms){ last = t; fn.apply(c,a); }
    else{ clearTimeout(tm); tm = setTimeout(()=>{ last = Date.now(); fn.apply(c,a); }, ms - (t-last)); }
  };
}

// Cloudinary image/video validation helper
function fileSizeMB(bytes){ return (bytes / (1024*1024)).toFixed(1)+' MB'; }

// Global constants for media limits
const MEDIA_CONFIG = {
  MAX_POST_IMAGES: 10,
  MAX_POST_IMAGE_BYTES: 25 * 1024 * 1024,
  MAX_POST_VIDEO_SECONDS: 5 * 60,
  MAX_POST_VIDEO_BYTES: 100 * 1024 * 1024,
  MAX_REEL_SECONDS: 3 * 60,
  MAX_REEL_BYTES: 100 * 1024 * 1024,
  MAX_STORY_SECONDS: 60,
  MAX_STORY_BYTES: 50 * 1024 * 1024,
  MAX_UPLOAD_BYTES: 100 * 1024 * 1024,
  MAX_VOICE_SECONDS: 180
};