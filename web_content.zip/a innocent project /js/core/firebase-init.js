/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED) — FIREBASE BOOT
 * FILE:   js/core/firebase-init.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Boots the Firebase SDK once and exposes three globals that
 *   every feature module depends on:
 *
 *     window.app       — firebase.app() instance
 *     window.auth      — firebase.auth() instance
 *     window.db        — firebase.database() instance
 *     window.configOK  — true when boot succeeded
 *
 *   Preserved 1:1 from the original §7 FIREBASE block.
 *
 *   If the config block is missing (empty apiKey / placeholder),
 *   configOK is set to false and the app gracefully degrades:
 *   the auth-state listener (feature 004) disables the login /
 *   signup buttons and shows a config-missing message.
 *
 * DEPENDENCIES:
 *   - FIREBASE_CONFIG (js/core/firebase-config.js)
 *   - Firebase compat SDK (three <script> tags in index.html)
 *
 * DOM ELEMENTS USED:
 *   none directly
 *
 * FIREBASE PATHS:
 *   none — this file only creates the SDK instances
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.app
 *   window.auth
 *   window.db
 *   window.configOK
 *   window.SaikoFirebase = { app, auth, db, configOK, isReady }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * GLOBAL STATE — set once, read by every module
   * ============================================================ */
  window.app      = null;
  window.auth     = null;
  window.db       = null;
  window.configOK = true;

  /* ============================================================
   * BOOT
   * ============================================================
   * Preserved 1:1 from the original initFirebase() IIFE:
   *   • Verify the config has been populated.
   *   • firebase.initializeApp(config)
   *   • Capture auth + database instances.
   *   • On any error → configOK = false.
   * ============================================================ */
  (function initFirebase() {
    try {
      /* Config presence check ------------------------------ */
      var cfg = window.FIREBASE_CONFIG || null;
      if (!cfg || !cfg.apiKey || cfg.apiKey.indexOf('YOUR_') === 0) {
        throw new Error('Firebase config missing');
      }

      /* Firebase SDK presence check ------------------------ */
      if (typeof firebase === 'undefined' ||
          typeof firebase.initializeApp !== 'function') {
        throw new Error('Firebase SDK not loaded');
      }

      /* Boot ------------------------------------------------ */
      window.app  = firebase.initializeApp(cfg);
      window.auth = firebase.auth();
      window.db   = firebase.database();
      window.configOK = true;
    } catch (e) {
      console.error('Firebase init error:', e);
      window.configOK = false;
    }
  })();

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoFirebase = {
    get app()      { return window.app; },
    get auth()     { return window.auth; },
    get db()       { return window.db; },
    get configOK() { return window.configOK; },
    isReady: function () {
      return !!(window.configOK && window.auth && window.db);
    }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] firebase-init ready (configOK=' + window.configOK + ')');
  } catch (e) {}

})();