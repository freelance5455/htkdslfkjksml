/* ============================================================
 * MISSING FILE 1/8 — XP / MISSIONS / STREAK SYSTEM
 * FILE:   js/core/xp-system.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * This file provides every XP-related function that other
 * modules call via safeCall (and currently silent-fail):
 *
 *   • XP_LIMITS      — daily rate-limit table
 *   • xpLocal        — in-memory rate-limit tracker
 *   • canXp()        — check rate limit
 *   • dayKey()       — YYYY-MM-DD helper
 *   • bumpDaily()    — write to dailyStats/{uid}/{date}
 *   • awardXp()      — write to users/{uid}/xp + xpLog
 *   • grantLoginXpOnce()
 *   • levelFromXp() / xpForLevel()
 *   • weeklyStats write
 *   • BADGES
 *   • startDailyListener — optional
 * ============================================================ */

(function () {
  'use strict';

  /* ============ CONSTANTS ============ */
  var XP_LIMITS = {
    post_created: { max: 20, win: 86400000 },
    comment_made: { max: 40, win: 86400000 },
    like_given:   { max: 50, win: 86400000 },
    game_played:  { max: 20, win: 86400000 },
    daily_login:  { max: 1,  win: 86400000 }
  };

  var xpLocal = {};

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof window.now === 'function') return window.now(); }
    catch (e) {}
    return Date.now();
  }
  function getDB() {
    try { if (typeof window.db !== 'undefined' && window.db) return window.db; }
    catch (e) {}
    return null;
  }
  function getUid() {
    try { return window.myUid || null; } catch (e) { return null; }
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }

  /* ============ LEVEL MATH ============ */
  function levelFromXp(xp) {
    xp = Number(xp) || 0;
    return Math.max(1, Math.floor(Math.sqrt(xp / 50)) + 1);
  }
  function xpForLevel(lv) {
    return Math.pow(lv - 1, 2) * 50;
  }

  /* ============ DAY KEY ============ */
  function dayKey(ts) {
    var d = new Date(ts || timeNow());
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, '0');
    var dd = String(d.getDate()).padStart(2, '0');
    return y + '-' + m + '-' + dd;
  }

  /* ============ RATE LIMIT ============ */
  function canXp(action, amount) {
    var lim = XP_LIMITS[action];
    if (!lim) return true;                /* unlimited */
    var nowTs = timeNow();
    var rec = xpLocal[action] || { t: 0, c: 0 };
    if (nowTs - rec.t > lim.win) {
      rec.t = nowTs;
      rec.c = 0;
    }
    if (rec.c + amount > lim.max) return false;
    rec.c += amount;
    xpLocal[action] = rec;
    return true;
  }

  /* ============ DAILY STATS ============ */
  function bumpDaily(action, n) {
    var uid = getUid();
    var fbDb = getDB();
    if (!uid || !fbDb || !action) return;

    var k = dayKey();
    fbDb.ref('dailyStats/' + uid + '/' + k + '/' + action)
      .transaction(function (v) { return (Number(v) || 0) + (n || 1); })
      .catch(function () {});

    /* Also write weekly stats for weekly missions --------- */
    var wk = 'w_' + Math.floor(timeNow() / (7 * 86400000));
    fbDb.ref('weeklyStats/' + uid + '/' + wk + '/' + action)
      .transaction(function (v) { return (Number(v) || 0) + (n || 1); })
      .catch(function () {});
  }

  /* ============ AWARD XP ============ */
  async function awardXp(action, amount) {
    try {
      var uid = getUid();
      var fbDb = getDB();
      if (!uid || !fbDb) return;
      if (!canXp(action, amount)) return;

      await fbDb.ref('users/' + uid + '/xp')
        .transaction(function (cur) { return (Number(cur) || 0) + amount; })
        .catch(function () {});

      /* Level recompute ---------------------------------- */
      var xpNow = (Number(window.myProfile && window.myProfile.xp) || 0) + amount;
      var lv = levelFromXp(xpNow);
      if (!window.myProfile || window.myProfile.level !== lv) {
        fbDb.ref('users/' + uid + '/level').set(lv).catch(function () {});
      }

      /* XP log ------------------------------------------- */
      fbDb.ref('xpLog/' + uid + '/' + dayKey())
        .transaction(function (v) { return (Number(v) || 0) + amount; })
        .catch(function () {});

      /* Also bump daily for compatibility with missions - */
      bumpDaily(action, 1);
    } catch (e) {}
  }

  /* ============ LOGIN XP ONCE PER DAY ============ */
  function grantLoginXpOnce() {
    try {
      var k = 'saiko_login_xp_' + dayKey();
      if (localStorage.getItem(k)) return;
      localStorage.setItem(k, '1');

      setTimeout(function () {
        awardXp('daily_login', 10);
        bumpDaily('login', 1);

        /* Streak update ----------------------------------- */
        var uid = getUid();
        var fbDb = getDB();
        if (!uid || !fbDb) return;

        var today = dayKey();
        var last = window.myProfile && window.myProfile.lastStreakDay;
        if (last === today) return;

        var yesterday = dayKey(timeNow() - 86400000);
        var streak = (last === yesterday)
          ? ((window.myProfile.streak || 0) + 1)
          : 1;

        fbDb.ref('users/' + uid + '/streak').set(streak).catch(function () {});
        fbDb.ref('users/' + uid + '/lastStreakDay').set(today).catch(function () {});
      }, 1500);
    } catch (e) {}
  }

  /* ============ BADGES ============ */
  var BADGES = [
    { id: 'first_post',  ic: '📝', name: 'First Post',        test: function (p) { return (p.posts || 0) >= 1; } },
    { id: 'social',      ic: '💬', name: 'Conversationalist', test: function (p) { return (p.comments || 0) >= 10; } },
    { id: 'liked',       ic: '❤️', name: 'Popular',            test: function (p) { return (p.likes || 0) >= 25; } },
    { id: 'gamer',       ic: '🎮', name: 'Gamer',              test: function (p) { return (p.games || 0) >= 5; } },
    { id: 'veteran',     ic: '🏅', name: 'Veteran',            test: function (p) { return (p.level || 1) >= 5; } },
    { id: 'storyteller', ic: '📸', name: 'Storyteller',        test: function (p) { return (p.stories || 0) >= 3; } },
    { id: 'creator',     ic: '🎬', name: 'Creator',            test: function (p) { return (p.reels || 0) >= 2; } }
  ];

  /* ============ EXPORTS ============ */
  window.XP_LIMITS           = XP_LIMITS;
  window.xpLocal             = xpLocal;
  window.canXp               = canXp;
  window.dayKey              = dayKey;
  window.bumpDaily           = bumpDaily;
  window.awardXp             = awardXp;
  window.grantLoginXpOnce    = grantLoginXpOnce;
  window.levelFromXp         = levelFromXp;
  window.xpForLevel          = xpForLevel;
  window.BADGES              = BADGES;

  window.SaikoXp = {
    XP_LIMITS: XP_LIMITS,
    canXp: canXp,
    dayKey: dayKey,
    bumpDaily: bumpDaily,
    awardXp: awardXp,
    grantLoginXpOnce: grantLoginXpOnce,
    levelFromXp: levelFromXp,
    xpForLevel: xpForLevel,
    BADGES: BADGES
  };

  try { console.debug('[boot] xp-system ready'); } catch (e) {}
})();