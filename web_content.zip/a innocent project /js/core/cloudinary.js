/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED) — CLOUDINARY UPLOADER
 * FILE:   js/core/cloudinary.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Single XHR-based uploader used by every media feature in
 *   the app:
 *     • post images   (feature 054)
 *     • post video    (feature 055)
 *     • chat image    (feature 142)
 *     • voice message (feature 139)
 *     • group avatar  (feature 115)
 *     • story image   (feature 187)
 *     • story video   (feature 187)
 *     • reel video    (feature 229)
 *
 *   The uploader:
 *     • POSTs the file to
 *         https://api.cloudinary.com/v1_1/<cloud>/auto/upload
 *     • Appends the configured upload_preset (and folder if set)
 *     • Reports progress 0–99 via an onProgress callback, then
 *       calls onProgress(100) once the response is parsed.
 *     • Returns the secure HTTPS URL (falls back to `url`).
 *
 *   Preserved 1:1 from the original §8 CLOUDINARY block's
 *   cloudinaryUpload() helper.
 *
 * DEPENDENCIES:
 *   - CLOUDINARY_CONFIG  (js/core/firebase-config.js)
 *   - MEDIA_CONFIG       (js/core/firebase-config.js) — for the
 *                        MAX_UPLOAD_BYTES guard
 *   - t()                (js/nav/046-i18n.js) — for error
 *                        strings
 *
 * DOM ELEMENTS USED:
 *   none — creates the XHR internally
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.cloudinaryUpload
 *   window.SaikoCloudinary = { upload, isConfigured }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }

  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * CONFIG HELPERS
   * ============================================================ */
  function getConfig() {
    try {
      if (typeof window.CLOUDINARY_CONFIG !== 'undefined' && window.CLOUDINARY_CONFIG) {
        return window.CLOUDINARY_CONFIG;
      }
    } catch (e) {}
    return null;
  }

  function isConfigured() {
    var c = getConfig();
    return !!(c && c.cloudName && c.cloudName.indexOf('YOUR_') !== 0 &&
              c.uploadPreset && c.uploadPreset.indexOf('YOUR_') !== 0);
  }

  /* ============================================================
   * UPLOAD
   * ============================================================
   * Preserved 1:1 from the original cloudinaryUpload():
   *
   *   async function cloudinaryUpload(fileOrBlob, filename,
   *                                   onProgress){
   *     if (!CLOUDINARY_CONFIG.cloudName || …) throw …
   *     if (size > MAX_UPLOAD_BYTES) throw …
   *     const url = 'https://api.cloudinary.com/v1_1/<cloud>/auto/upload';
   *     return new Promise((resolve, reject) => {
   *       const fd = new FormData();
   *       fd.append('file', fileOrBlob, filename || 'file_<ts>');
   *       fd.append('upload_preset', CLOUDINARY_CONFIG.uploadPreset);
   *       if (folder) fd.append('folder', folder);
   *       const xhr = new XMLHttpRequest();
   *       xhr.open('POST', url, true);
   *       xhr.upload.onprogress = e => onProgress?.(
   *         Math.min(99, Math.round((e.loaded/e.total)*100)));
   *       xhr.onload = () => { … resolve(secure_url || url) … };
   *       xhr.onerror = () => reject(new Error('Network error…'));
   *       xhr.ontimeout = () => reject(new Error('Upload timed out'));
   *       xhr.timeout = 120000;
   *       xhr.send(fd);
   *     });
   *   }
   * ============================================================ */
  function upload(fileOrBlob, filename, onProgress) {
    return new Promise(function (resolve, reject) {
      /* ---- Config guard --------------------------------- */
      var cfg = getConfig();
      if (!isConfigured()) {
        reject(new Error(T('config_missing')));
        return;
      }

      /* ---- Size guard ----------------------------------- */
      var maxBytes = 100 * 1024 * 1024;
      try {
        if (window.MEDIA_CONFIG && window.MEDIA_CONFIG.MAX_UPLOAD_BYTES) {
          maxBytes = window.MEDIA_CONFIG.MAX_UPLOAD_BYTES;
        }
      } catch (e) {}

      if (fileOrBlob && fileOrBlob.size && fileOrBlob.size > maxBytes) {
        reject(new Error(T('file_too_large')));
        return;
      }

      /* ---- Build the request ---------------------------- */
      var url = 'https://api.cloudinary.com/v1_1/' + cfg.cloudName + '/auto/upload';

      var fd = new FormData();
      var name = filename || ('file_' + timeNow());
      try {
        fd.append('file', fileOrBlob, name);
      } catch (e) {
        reject(new Error('Cannot append file'));
        return;
      }
      fd.append('upload_preset', cfg.uploadPreset);
      if (cfg.folder) fd.append('folder', cfg.folder);

      var xhr = new XMLHttpRequest();
      xhr.open('POST', url, true);

      /* ---- Progress ------------------------------------- */
      xhr.upload.onprogress = function (e) {
        if (typeof onProgress !== 'function') return;
        if (!e || !e.lengthComputable) return;
        var pct = Math.min(99, Math.round((e.loaded / e.total) * 100));
        try { onProgress(pct); } catch (err) {}
      };

      /* ---- Success -------------------------------------- */
      xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            var data = JSON.parse(xhr.responseText);
            if (typeof onProgress === 'function') {
              try { onProgress(100); } catch (e) {}
            }
            resolve(data.secure_url || data.url);
          } catch (e) {
            reject(new Error('Invalid upload response'));
          }
        } else {
          var msg = 'Upload failed (' + xhr.status + ')';
          try {
            var j = JSON.parse(xhr.responseText);
            if (j && j.error && j.error.message) msg = j.error.message;
          } catch (e) {}
          reject(new Error(msg));
        }
      };

      /* ---- Failure -------------------------------------- */
      xhr.onerror = function () {
        reject(new Error('Network error during upload'));
      };
      xhr.ontimeout = function () {
        reject(new Error('Upload timed out'));
      };

      xhr.timeout = 120000;

      try {
        xhr.send(fd);
      } catch (e) {
        reject(e);
      }
    });
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.cloudinaryUpload = upload;

  window.SaikoCloudinary = {
    upload: upload,
    isConfigured: isConfigured
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] cloudinary ready (configured=' + isConfigured() + ')');
  } catch (e) {}

})();