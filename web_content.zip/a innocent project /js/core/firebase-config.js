/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED) — CONFIG CONSTANTS
 * FILE:   js/core/firebase-config.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the CONFIG block that all other core files and every
 *   feature module depend on:
 *
 *     • FIREBASE_CONFIG    — Firebase project credentials
 *     • CLOUDINARY_CONFIG  — Cloudinary cloud name + preset
 *     • LOGO_URL           — application brand image
 *     • MEDIA_CONFIG       — media size / duration limits
 *
 *   Preserved 1:1 from the original §1 CONFIG block of the
 *   single-file source.
 *
 *   NOTE: These are API keys that ship to the browser anyway —
 *   the original source hard-codes them in the HTML. Keep them
 *   here for compatibility. If you ever rotate them, update
 *   this file only.
 *
 * DEPENDENCIES:
 *   none
 *
 * DOM ELEMENTS USED:
 *   none
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.FIREBASE_CONFIG
 *   window.CLOUDINARY_CONFIG
 *   window.LOGO_URL
 *   window.MEDIA_CONFIG
 *   window.SaikoConfig = { FIREBASE_CONFIG, CLOUDINARY_CONFIG,
 *                          LOGO_URL, MEDIA_CONFIG }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * FIREBASE — project credentials
   * ============================================================
   * Preserved byte-for-byte from the original §1 CONFIG.
   * ============================================================ */
  var FIREBASE_CONFIG = {
    apiKey: "AIzaSyCDDlrNg9ZkLDfJFyrA5NRJB9my5OBhzjA",
    authDomain: "saikochat-ed420.firebaseapp.com",
    databaseURL: "https://saikochat-ed420-default-rtdb.firebaseio.com",
    projectId: "saikochat-ed420",
    storageBucket: "saikochat-ed420.firebasestorage.app",
    messagingSenderId: "638200083059",
    appId: "1:638200083059:web:655553b778ef2a54bc7006"
  };

  /* ============================================================
   * CLOUDINARY — upload credentials
   * ============================================================ */
  var CLOUDINARY_CONFIG = {
    cloudName: "j307sqdf",
    uploadPreset: "oh19mxgy",
    folder: ""
  };

  /* ============================================================
   * BRAND — logo URL
   * ============================================================ */
  var LOGO_URL = "https://i.ibb.co/mFYtJvRL/file-0000000024f48211b152c5f12db975f9.png";

  /* ============================================================
   * MEDIA LIMITS
   * ============================================================
   * Preserved byte-for-byte from the original §1 CONFIG.
   * ============================================================ */
  var MEDIA_CONFIG = {
    MAX_POST_IMAGES: 10,
    MAX_POST_IMAGE_BYTES: 25 * 1024 * 1024,
    MAX_POST_VIDEO_SECONDS: 5 * 60,
    MAX_POST_VIDEO_BYTES: 100 * 1024 * 1024,
    MAX_REEL_SECONDS: 3 * 60,
    MAX_REEL_BYTES: 100 * 1024 * 1024,
    MAX_STORY_SECONDS: 60,
    MAX_STORY_BYTES: 50 * 1024 * 1024,
    MAX_UPLOAD_BYTES: 100 * 1024 * 1024,
    MAX_VOICE_SECONDS: 180
  };

  /* ============================================================
   * GLOBAL EXPORTS
   * ============================================================ */
  window.FIREBASE_CONFIG   = FIREBASE_CONFIG;
  window.CLOUDINARY_CONFIG = CLOUDINARY_CONFIG;
  window.LOGO_URL          = LOGO_URL;
  window.MEDIA_CONFIG      = MEDIA_CONFIG;

  window.SaikoConfig = {
    FIREBASE_CONFIG: FIREBASE_CONFIG,
    CLOUDINARY_CONFIG: CLOUDINARY_CONFIG,
    LOGO_URL: LOGO_URL,
    MEDIA_CONFIG: MEDIA_CONFIG
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] core config ready');
  } catch (e) {}

})();