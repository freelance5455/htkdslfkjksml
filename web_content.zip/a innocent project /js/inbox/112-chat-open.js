/* ============================================================
 * FEATURE:        Chat Meta (Chat Open / Close + Header +
 *                 Message Listener + Send)
 * FEATURE NUMBER: 112
 * FILE:           js/inbox/112-chat-open.js
 * ACTION:         REPLACE (v2 — Restore Chat support)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var MSG_FETCH_LIMIT = 200;
  var TYPING_TTL_MS   = 5000;
  var TYPING_DEBOUNCE = 3500;
  var BOTTOM_EPSILON  = 80;

  /* ============================================================
   * STATE — shared as globals
   * ============================================================ */
  window.currentChatId      = null;
  window.chatMessages       = window.chatMessages || {};
  window.chatPeerUid        = null;
  window.chatIsAdminSupport = false;
  window.chatAtBottom       = true;
  window.chatE2EKey         = null;
  window.replyMsg           = null;
  window.pinnedMsgId        = null;
  window.failedMessages     = window.failedMessages || {};
  window.__msgHides         = window.__msgHides || {};

  var chatMsgRefs = [];
  var chatMetaRef = null;
  var chatMetaCb  = null;
  var typingRef   = null;
  var typingCb    = null;
  var typingTimer = null;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[chat-open] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function userName(uid) {
    var u = findUser(uid);
    return (u && u.name) || 'User';
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }

  /* ============================================================
   * DETACH
   * ============================================================ */
  function detachChat() {
    for (var i = 0; i < chatMsgRefs.length; i++) {
      try { chatMsgRefs[i].ref.off(chatMsgRefs[i].event, chatMsgRefs[i].cb); }
      catch (e) {}
    }
    chatMsgRefs = [];

    if (chatMetaRef && chatMetaCb) {
      try { chatMetaRef.off('value', chatMetaCb); } catch (e) {}
    }
    if (typingRef && typingCb) {
      try { typingRef.off('value', typingCb); } catch (e) {}
    }
    if (typingTimer) {
      clearTimeout(typingTimer);
      typingTimer = null;
    }

    chatMetaRef = null; chatMetaCb = null;
    typingRef   = null; typingCb   = null;

    window.currentChatId      = null;
    window.chatPeerUid        = null;
    window.chatMessages       = {};
    window.replyMsg           = null;
    window.pinnedMsgId        = null;
    window.chatE2EKey         = null;
    window.chatIsAdminSupport = false;
    window.chatAtBottom       = true;
    window.__msgHides         = {};

    hideReplyBar();
    var pinBar = qs('#pinBar');
    if (pinBar) pinBar.classList.add('hidden');

    var root = document.documentElement;
    if (root) {
      root.style.removeProperty('--bubble-me');
      root.style.removeProperty('--bubble-you');
      root.style.removeProperty('--bubble-me-text');
      root.style.removeProperty('--bubble-you-text');
      root.style.removeProperty('--chat-bg');
      root.style.removeProperty('--chat-input-bg');
    }
  }

  /* ============================================================
   * E2E — admin support shared key derivation
   * ============================================================ */
  async function setupE2EForAdminChat(chatId) {
    try {
      var uid = getMyUid();
      if (!uid) return;

      var E2E = window.SaikoE2E || window.E2E;
      if (!E2E || typeof E2E.getOrCreateMyKeyPair !== 'function') return;

      var fbDb = getDB();
      if (!fbDb) return;

      var myKp = await E2E.getOrCreateMyKeyPair(uid);
      var adminSnap = await fbDb.ref('e2eKeys/admin').get();
      var adminKey = adminSnap.val();

      if (!adminKey) {
        if (window.crypto && window.crypto.subtle) {
          var seed = new TextEncoder().encode('saiko-admin-' + chatId);
          var hash = await window.crypto.subtle.digest('SHA-256', seed);
          window.chatE2EKey = await window.crypto.subtle.importKey(
            'raw', hash, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt']
          );
        }
        return;
      }

      var adminJwk = adminKey.jwk || adminKey;
      var adminPub = await E2E.importPeerKey(adminJwk);
      window.chatE2EKey = await E2E.deriveAesKey(myKp.priv, adminPub);

      await fbDb.ref('e2eKeys/' + uid).set({ jwk: myKp.pubJwk, v: 1 });
    } catch (e) {
      window.chatE2EKey = null;
    }
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openChatById(chatId) {
    if (!chatId) return false;

    detachChat();

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    window.currentChatId = chatId;
    window.chatMessages  = {};
    window.chatIsAdminSupport = (
      chatId.indexOf('admin_') === 0 ||
      chatId.indexOf('adminSupport_') === 0
    );
    window.__msgHides = {};

    var body = qs('#chatBody');
    if (body) {
      body.innerHTML =
        '<div class="skeleton" style="height:2.6rem;width:60%;margin-bottom:.5rem"></div>'.repeat(3);
    }
    safeCall('openOverlay', ['ovChat']);

    var searchWrap = qs('#chatSearchWrap');
    if (searchWrap) searchWrap.classList.add('hidden');
    var searchInp = qs('#chatSearchInput');
    if (searchInp) searchInp.value = '';

    safeCall('applyChatTheme', [chatId]);

    /* ---- Meta listener ---- */
    chatMetaRef = fbDb.ref('chats/' + chatId);
    chatMetaCb = chatMetaRef.on('value', function (snap) {
      var c = snap.val();
      if (!c) {
        safeCall('closeOverlay', ['ovChat']);
        return;
      }
      if (window.chatMeta) window.chatMeta[chatId] = Object.assign({ id: chatId }, c);

      var info = safeCall('chatDisplay', [chatId, c]) || { name: 'Chat', photo: '', uid: null };

      var nameEl = qs('#chatHeadName');
      if (nameEl) nameEl.textContent = info.name;

      var avEl = qs('#chatHeadAvatar');
      if (avEl) {
        var avUid = (c.type === 'direct' && !c.adminSupport) ? info.uid : null;
        var html = avatarHTML(info.photo, info.name, 'av-32', avUid);
        avEl.outerHTML = html.replace('class="avatar', 'id="chatHeadAvatar" class="avatar');
      }

      var subEl = qs('#chatHeadSub');
      if (subEl) {
        if (c.type === 'group') {
          var count = Object.keys(c.members || {}).length;
          subEl.textContent = count + ' ' + T('members_count');
          window.chatPeerUid = null;
        } else if (c.adminSupport) {
          subEl.textContent = '🛡 ' + T('e2e_secure_chat');
          window.chatPeerUid = null;
        } else {
          var peer = null;
          var mKeys = Object.keys(c.members || {});
          for (var k = 0; k < mKeys.length; k++) {
            if (mKeys[k] !== uid && mKeys[k] !== 'admin') { peer = mKeys[k]; break; }
          }
          window.chatPeerUid = peer;

          var pu = peer ? findUser(peer) : null;
          var isOn = peer && window.onlineUsers && window.onlineUsers[peer];
          var sub = '';
          if (isOn) sub = T('online');
          else if (pu && pu.lastSeen) sub = T('offline') + ' · ' + (
            typeof window.timeAgo === 'function' ? window.timeAgo(pu.lastSeen) : ''
          );
          else sub = T('offline');
          subEl.textContent = sub;
        }
      }

      if (c.pinned) {
        window.pinnedMsgId = c.pinned;
        safeCall('loadPinned');
      } else {
        window.pinnedMsgId = null;
        var pb = qs('#pinBar');
        if (pb) pb.classList.add('hidden');
      }
    });

    fbDb.ref('chats/' + chatId + '/unread/' + uid).set(0).catch(function () {});
    fbDb.ref('chats/' + chatId + '/reads/' + uid).set(timeNow()).catch(function () {});

    if (window.chatIsAdminSupport) {
      setupE2EForAdminChat(chatId);
    }

    var body2 = qs('#chatBody');
    if (body2) body2.innerHTML = '';

    var msgPath = window.chatIsAdminSupport
      ? ('adminChats/' + chatId + '/messages')
      : ('messages/' + chatId);

    var mref = fbDb.ref(msgPath)
      .orderByChild('createdAt')
      .limitToLast(MSG_FETCH_LIMIT);

    var cAdd = mref.on('child_added', function (snap) {
      var m = snap.val();
      if (!m) return;
      window.chatMessages[snap.key] = m;
      if (window.__msgHides && window.__msgHides[snap.key]) return;
      safeCall('decryptAndRenderMessage', [snap.key, m, true]);
    });
    var cChg = mref.on('child_changed', function (snap) {
      var m = snap.val();
      if (!m) return;
      window.chatMessages[snap.key] = m;
      if (window.__msgHides && window.__msgHides[snap.key]) return;
      safeCall('decryptAndRenderMessage', [snap.key, m, false]);
    });
    var cRem = mref.on('child_removed', function (snap) {
      var node = qs('[data-mid="' + snap.key + '"]');
      if (node) node.remove();
      delete window.chatMessages[snap.key];
    });

    chatMsgRefs.push({ ref: mref, event: 'child_added',   cb: cAdd });
    chatMsgRefs.push({ ref: mref, event: 'child_changed', cb: cChg });
    chatMsgRefs.push({ ref: mref, event: 'child_removed', cb: cRem });

    /* ---------- Message-hides live listener (Clear / Restore) ---------- */
    var hRef = fbDb.ref('messageHides/' + uid + '/' + chatId);
    var hCb = hRef.on('value', function (s) {
      window.__msgHides = s.val() || {};
      var bb = qs('#chatBody');
      if (!bb) return;
      Object.keys(window.__msgHides).forEach(function (mid) {
        var n = bb.querySelector('[data-mid="' + mid + '"]');
        if (n) n.remove();
      });
    });
    chatMsgRefs.push({ ref: hRef, event: 'value', cb: hCb });

    /* ---- Typing listener ---- */
    typingRef = fbDb.ref('chats/' + chatId + '/typing');
    typingCb = typingRef.on('value', function (s) {
      var v = s.val() || {};
      var nowTs = timeNow();
      var others = [];
      var keys = Object.keys(v);
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (k === uid) continue;
        if (nowTs - (v[k] || 0) < TYPING_TTL_MS) others.push(k);
      }
      var subEl = qs('#chatHeadSub');
      if (subEl && others.length &&
          window.chatMeta && window.chatMeta[chatId] &&
          window.chatMeta[chatId].type !== 'group') {
        var names = others.map(userName).slice(0, 2).join(', ');
        subEl.textContent = names + ' ' + T('typing');
      }
    });
    chatMsgRefs.push({ ref: typingRef, event: 'value', cb: typingCb });

    setTimeout(function () {
      var b = qs('#chatBody');
      if (b) b.scrollTop = b.scrollHeight;
      window.chatAtBottom = true;
    }, 200);

    return true;
  }

  /* ============================================================
   * SCROLL WATCHER
   * ============================================================ */
  (function initChatScrollWatcher() {
    var b = document.getElementById('chatBody');
    if (!b) {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
          var b2 = document.getElementById('chatBody');
          if (!b2) return;
          b2.addEventListener('scroll', function () {
            window.chatAtBottom =
              (b2.scrollHeight - b2.scrollTop - b2.clientHeight) < BOTTOM_EPSILON;
          }, { passive: true });
        }, { once: true });
      }
      return;
    }
    b.addEventListener('scroll', function () {
      window.chatAtBottom =
        (b.scrollHeight - b.scrollTop - b.clientHeight) < BOTTOM_EPSILON;
    }, { passive: true });
  })();

  /* ============================================================
   * UPDATE CHAT META
   * ============================================================ */
  function updateChatMeta(chatId, text) {
    var fbDb = getDB();
    if (!fbDb || !chatId) return Promise.resolve();

    var c = (window.chatMeta && window.chatMeta[chatId]) || null;
    var updates = {};
    updates['chats/' + chatId + '/lastMessage'] = text;
    updates['chats/' + chatId + '/lastAt']      = timeNow();

    if (c && c.members) {
      var uids = Object.keys(c.members);
      for (var i = 0; i < uids.length; i++) {
        updates['userChats/' + uids[i] + '/' + chatId] = true;
      }
    }
    return fbDb.ref().update(updates).catch(function () {});
  }

  /* ============================================================
   * SEND
   * ============================================================ */
  var lastSentKey = '';
  var lastSentAt  = 0;

  async function sendMessage(payload) {
    var chatId = window.currentChatId;
    if (!chatId || !payload) return false;

    var uid = getMyUid();
    var me  = getMyProfile() || {};

    var sig = (payload.type || 'text') + '|' + (payload.text || payload.url || '');
    var nowTs = timeNow();
    if (sig === lastSentKey && (nowTs - lastSentAt) < 1200) return false;
    lastSentKey = sig;
    lastSentAt  = nowTs;

    var fbDb = getDB();
    if (!fbDb) throw new Error(T('error'));
      /* ============================================================
       * SMS BLOCK CHECK (feature 154 enforcement)
       * Agar peer ne mujhe SMS-block kiya hai → message bhejne se rok do.
       * Note: admin-support chats exempt hai (E2E).
       * ============================================================ */
      if (!window.chatIsAdminSupport && window.chatPeerUid && typeof window.isSmsBlockedByPeer === 'function') {
        try {
          var blockedByPeer = await window.isSmsBlockedByPeer(window.chatPeerUid);
          if (blockedByPeer) {
            safeCall('toast', ['You are blocked by this user', 'err']);
            return false;
          }
        } catch (e) {}
      }

    var isAdminSupport = window.chatIsAdminSupport;
    var msgPath = isAdminSupport
      ? ('adminChats/' + chatId + '/messages')
      : ('messages/' + chatId);

    var ref = fbDb.ref(msgPath).push();
    var msg = Object.assign({
      id: ref.key,
      from: uid,
      fromName: me.name || '',
      fromPhoto: me.photo || '',
      createdAt: nowTs,
      readBy: Object.assign({}, { [uid]: true })
    }, payload);

    if (window.replyMsg) {
      msg.replyTo = window.replyMsg.id;
      msg.replyName = window.replyMsg.name;
    }
    hideReplyBar();

    if (isAdminSupport && msg.type === 'text' && msg.text && window.chatE2EKey) {
      try {
        var E2E = window.SaikoE2E || window.E2E;
        if (E2E && typeof E2E.encrypt === 'function') {
          var enc = await E2E.encrypt(window.chatE2EKey, msg.text);
          msg.e2e = enc;
          msg.text = '';
        }
      } catch (e) {}
    }

    try {
      await ref.set(msg);

      var preview = (payload.type === 'image')
        ? '📷 ' + T('image')
        : (payload.type === 'voice')
          ? '🎤 ' + T('voice_message')
          : (payload.text || '');

      if (isAdminSupport) {
        var unreadAdmin = 0;
        try {
          var s = await fbDb.ref('adminChats/' + chatId + '/unreadAdmin').get();
          unreadAdmin = s.val() || 0;
        } catch (e) {}
        var adUpd = {};
        adUpd['adminChats/' + chatId + '/lastMessage'] = String(preview).slice(0, 80);
        adUpd['adminChats/' + chatId + '/lastAt']      = timeNow();
        adUpd['adminChats/' + chatId + '/unreadAdmin'] = unreadAdmin + 1;
        await fbDb.ref().update(adUpd).catch(function () {});
        await updateChatMeta(chatId, String(preview).slice(0, 80));
      } else {
        await updateChatMeta(chatId, String(preview).slice(0, 80));

        var c = (window.chatMeta && window.chatMeta[chatId]) || null;
        if (c && c.members) {
          var uids = Object.keys(c.members);
          var updates = {};
          for (var i = 0; i < uids.length; i++) {
            var r = uids[i];
            if (r === uid || r === 'admin') continue;
            var cur = (c.unread && c.unread[r]) || 0;
            updates['chats/' + chatId + '/unread/' + r] = cur + 1;
            if (!(c.muted && c.muted[r])) {
              safeCall('pushNotification', [r, {
                type: 'message',
                fromUid: uid,
                fromName: me.name || '',
                fromPhoto: me.photo || '',
                text: T('new_message'),
                chatId: chatId,
                createdAt: nowTs
              }]);
            }
          }
          if (Object.keys(updates).length) {
            await fbDb.ref().update(updates).catch(function () {});
          }
        }
      }

      fbDb.ref('chats/' + chatId + '/typing/' + uid).remove().catch(function () {});
      safeCall('bumpDaily', ['message', 1]);

      return true;
    } catch (err) {
      window.failedMessages[ref.key] = msg;
      safeCall('toast', [(err && err.message) ? err.message : T('error'), 'err']);
      throw err;
    }
  }

  /* ============================================================
   * RETRY
   * ============================================================ */
  async function retryMessage(mid) {
    var m = window.failedMessages[mid];
    if (!m) return false;
    delete window.failedMessages[mid];
    var node = qs('[data-mid="' + mid + '"]');
    if (node) node.remove();
    try {
      await sendMessage({ type: m.type, text: m.text || '', url: m.url || '' });
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * REPLY BAR
   * ============================================================ */
  function showReplyBar() {
    if (!window.replyMsg) return;
    var bar = qs('#replyBar');
    if (!bar) return;

    bar.classList.remove('hidden');
    bar.innerHTML =
      '<div class="rb-body">' +
        '<div class="mini" style="font-weight:800;color:var(--accent)">' +
          esc(T('reply_hint')) + ' ' + esc(window.replyMsg.name) +
        '</div>' +
        '<div class="mini ellipsis">' + esc(window.replyMsg.text) + '</div>' +
      '</div>' +
      '<button class="icon-btn" id="cancelReply" style="width:1.9rem;height:1.9rem">✕</button>';

    var cancel = qs('#cancelReply', bar);
    if (cancel) cancel.addEventListener('click', hideReplyBar);
  }

  function hideReplyBar() {
    window.replyMsg = null;
    var bar = qs('#replyBar');
    if (!bar) return;
    bar.classList.add('hidden');
    bar.innerHTML = '';
  }

  /* ============================================================
   * PINNED MESSAGE
   * ============================================================ */
  async function loadPinned() {
    var mid = window.pinnedMsgId;
    var chatId = window.currentChatId;
    if (!mid || !chatId) return;

    var fbDb = getDB();
    if (!fbDb) return;

    try {
      var s = await fbDb.ref('messages/' + chatId + '/' + mid).get();
      var m = s.val();
      var bar = qs('#pinBar');
      if (!bar) return;

      if (!m) {
        bar.classList.add('hidden');
        return;
      }
      bar.classList.remove('hidden');

      var label = m.deleted
        ? T('message_deleted')
        : (m.text ||
           (m.type === 'image' ? '📷' :
             (m.type === 'voice' ? '🎤' : '')));
      label = String(label).slice(0, 90);

      bar.innerHTML =
        '<span class="ic">' + (window.svgIcon ? window.svgIcon('pin') : '') + '</span>' +
        '<span class="grow ellipsis">' + esc(label) + '</span>' +
        '<button class="icon-btn" id="unpinBtn" style="width:1.7rem;height:1.7rem">✕</button>';

      var unpin = qs('#unpinBtn', bar);
      if (unpin) {
        unpin.addEventListener('click', function () {
          fbDb.ref('chats/' + chatId + '/pinned').remove().catch(function () {});
          window.pinnedMsgId = null;
          bar.classList.add('hidden');
        });
      }
    } catch (e) {}
  }

  /* ============================================================
   * INPUT WIRING
   * ============================================================ */
  function wireInput() {
    var input = qs('#chatInput');
    var send  = qs('#btnSend');
    if (send && send.dataset.chatOpenBound !== '1') {
      send.dataset.chatOpenBound = '1';
      send.addEventListener('click', async function () {
        var text = input ? input.value.trim() : '';
        if (!text) return;
        if (input) { input.value = ''; input.style.height = 'auto'; }
        try { await sendMessage({ type: 'text', text: text }); } catch (e) {}
      });
    }

    if (input && input.dataset.chatOpenBound !== '1') {
      input.dataset.chatOpenBound = '1';

      input.addEventListener('keydown', function (e) {
        var enterToSend = true;
        try {
          if (window.prefs && typeof window.prefs.enterToSend === 'boolean') {
            enterToSend = window.prefs.enterToSend;
          }
        } catch (err) {}
        if (e.key === 'Enter' && !e.shiftKey && enterToSend) {
          e.preventDefault();
          if (send) send.click();
        }
      });

      input.addEventListener('input', function (e) {
        var t = e.target;
        t.style.height = 'auto';
        t.style.height = Math.min(t.scrollHeight, 96) + 'px';

        var chatId = window.currentChatId;
        if (!chatId) return;
        var typingEnabled = true;
        try {
          if (window.prefs && typeof window.prefs.typingIndicator === 'boolean') {
            typingEnabled = window.prefs.typingIndicator;
          }
        } catch (err) {}
        if (!typingEnabled) return;

        var fbDb = getDB();
        var uid  = getMyUid();
        if (!fbDb || !uid) return;

        fbDb.ref('chats/' + chatId + '/typing/' + uid).set(timeNow()).catch(function () {});
        if (typingTimer) clearTimeout(typingTimer);
        typingTimer = setTimeout(function () {
          if (window.currentChatId === chatId) {
            fbDb.ref('chats/' + chatId + '/typing/' + uid).remove().catch(function () {});
          }
        }, TYPING_DEBOUNCE);
      });
    }
  }

  /* ============================================================
   * OVERLAY CLOSE HOOK
   * ============================================================ */
  function onDocumentClick(e) {
    var c = e.target && e.target.closest ? e.target.closest('[data-close="ovChat"]') : null;
    if (!c) return;
    detachChat();
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.detachChat            = detachChat;
  window.openChatById          = openChatById;
  window.sendMessage           = sendMessage;
  window.retryMessage          = retryMessage;
  window.updateChatMeta        = updateChatMeta;
  window.showReplyBar          = showReplyBar;
  window.hideReplyBar          = hideReplyBar;
  window.loadPinned            = loadPinned;
  window.setupE2EForAdminChat  = setupE2EForAdminChat;

  window.SaikoChatOpen = {
    open: openChatById,
    detach: detachChat,
    send: sendMessage,
    retry: retryMessage,
    updateMeta: updateChatMeta,
    showReplyBar: showReplyBar,
    hideReplyBar: hideReplyBar,
    loadPinned: loadPinned,
    setupE2E: setupE2EForAdminChat
  };

  /* ============================================================
   * BOOT
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      wireInput();
      document.addEventListener('click', onDocumentClick);
    }, { once: true });
  } else {
    wireInput();
    document.addEventListener('click', onDocumentClick);
  }

  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 112 — chat-open ready (v2-restore)');
  } catch (e) {}

})();