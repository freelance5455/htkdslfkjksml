/* ============================================================
 * FEATURE:        Group Info
 * FEATURE NUMBER: 119
 * FILE:           js/inbox/119-group-info.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the full-screen group info screen (#ovProfile overlay
 *   reused as a full-page container). Handles:
 *
 *     1. HEADER
 *          • Group image (admin-only "Change image" button)
 *          • Group name (admin-only "Rename group" button)
 *          • Member count
 *          • Action buttons: Mute/Unmute, Chat Theme, Leave
 *
 *     2. MEMBER LIST
 *          • Avatar + display name (nickname-aware) + admin
 *            badge
 *          • "@" set-nickname button per member (except self)
 *          • "⋯" options menu per member (admin-only):
 *              make admin / remove admin
 *              remove member (danger)
 *
 *     3. ADD MEMBERS (admin-only)
 *          Replaces the body with a picker of candidates
 *          (users not already in the group). Clicking one adds
 *          them + mirrors into their userChats.
 *
 *     4. START CHAT
 *          Closes the info overlay + opens the actual chat.
 *
 *   Behaviour preserved 1:1 from the original §22 block.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openGroupInfo(chatId)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - t / esc / now          helpers
 *   - svgIcon                js/nav/045-icon-system.js
 *   - avatarHTML             js/core/utils.js
 *   - openOverlay / closeOverlay (038)
 *   - promptDialog           js/nav/044-prompt-dialog.js
 *   - confirmDialog          js/nav/043-confirm-dialog.js
 *   - toast                  js/nav/042-toast.js
 *   - openChatById           js/inbox/112-chat-open.js
 *   - detachChat             js/inbox/112-chat-open.js
 *   - chatMeta               js/inbox/111-inbox-list.js
 *   - getNickname / setNickname  js/chat/152-chat-nickname.js
 *   - openChatThemePicker    js/prefs/021-chat-themes.js
 *   - validateImage / compressImage / cloudinaryUpload
 *   - openUserProfile        profile module
 *
 * DOM ELEMENTS USED:
 *   #ovProfile        (overlay container — reused)
 *   #profileViewBody  (content container — reused)
 *   #msgMenuSheet     (shared bottom sheet)
 *
 * FIREBASE PATHS:
 *   chats/{chatId}/image              (write — change image)
 *   chats/{chatId}/name               (write — rename)
 *   chats/{chatId}/muted/{uid}        (set / remove)
 *   chats/{chatId}/admins/{uid}       (set / null)
 *   chats/{chatId}/members/{uid}      (write / null)
 *   userChats/{uid}/{chatId}          (write / null)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openGroupInfo          (original name preserved)
 *   window.SaikoGroupInfo = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[group-info] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') return window.confirmDialog(title, text);
    } catch (e) {}
    return Promise.resolve(true);
  }
  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') return window.promptDialog(title, defValue, placeholder);
    } catch (e) {}
    return Promise.resolve(null);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function userName(uid) {
    var u = findUser(uid);
    return (u && u.name) || 'User';
  }
  function getNickname(chatId, targetUid) {
    try {
      if (typeof window.getNickname === 'function') {
        return window.getNickname(chatId, targetUid);
      }
    } catch (e) {}
    return null;
  }

  /* ============================================================
   * OPEN — main entry point
   * ============================================================
   * Preserved 1:1 from the original openGroupInfo(chatId).
   * ============================================================ */
  function openGroupInfo(chatId) {
    if (!chatId) return false;

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    var c = (window.chatMeta && window.chatMeta[chatId]) || null;
    if (!c) return false;

    var members = Object.keys(c.members || {});
    var admins  = c.admins || {};
    var isAdmin = !!admins[me] || c.createdBy === me;

    var body = qs('#profileViewBody');
    if (!body) return false;

    /* ---- Render header + member list -------------------- */
    body.innerHTML =
      '<div class="prof-head">' +
        '<div id="grpImgWrap">' + avatarHTML(c.image, c.name, 'av-88') + '</div>' +
        (isAdmin
          ? '<button class="btn sm ghost" id="grpChangeImg">' + esc(T('change_image')) + '</button>'
          : '') +
        '<div class="nm" id="grpName">' + esc(c.name || 'Group') + '</div>' +
        '<div class="muted">' + members.length + ' ' + esc(T('members_count')) + '</div>' +
        (isAdmin
          ? '<button class="btn sm ghost" id="grpRename">' + esc(T('rename_group')) + '</button>'
          : '') +
        '<div class="row" style="gap:.5rem;margin-top:.5rem;flex-wrap:wrap;justify-content:center">' +
          '<button class="btn sm ' + (c.muted && c.muted[me] ? 'solid' : 'ghost') + '" id="grpMute">' +
            esc(c.muted && c.muted[me] ? T('unmute') : T('mute')) +
          '</button>' +
          '<button class="btn sm ghost" id="grpTheme">' + esc(T('chat_theme')) + '</button>' +
          '<button class="btn sm danger" id="grpLeave">' + esc(T('leave_group')) + '</button>' +
        '</div>' +
      '</div>' +
      '<div style="padding:0 .8rem 1.5rem">' +
        '<div class="sec-title">' + esc(T('members')) + '</div>' +
        members.map(function (u) {
          var usr = findUser(u) || { name: 'User', photo: '' };
          var isAd = !!admins[u] || c.createdBy === u;
          var nick = (u !== me) ? getNickname(chatId, u) : null;
          var display = nick || usr.name;

          return '<div class="user-card" data-gm="' + esc(u) + '">' +
            avatarHTML(usr.photo, usr.name, 'av-40', u) +
            '<div class="grow">' +
              '<div class="name">' + esc(display) +
                (u === me ? ' (' + esc(T('you')) + ')' : '') +
              '</div>' +
              '<div class="muted">' +
                (isAd ? esc(T('admin')) : '') +
                (nick ? ' · ' + esc(usr.name) : '') +
              '</div>' +
            '</div>' +
            (u !== me
              ? '<button class="icon-btn" data-gnick="' + esc(u) + '" ' +
                       'style="width:2rem;height:2rem" ' +
                       'title="' + esc(T('set_nickname')) + '">@</button>'
              : '') +
            (isAdmin && u !== me
              ? '<button class="icon-btn" data-gmenu="' + esc(u) + '" ' +
                       'style="width:2rem;height:2rem">⋯</button>'
              : '') +
          '</div>';
        }).join('') +
        '<div class="row" style="gap:.6rem;margin-top:.8rem;flex-wrap:wrap">' +
          (isAdmin
            ? '<button class="btn sm solid" id="grpAdd">+ ' + esc(T('add_members')) + '</button>'
            : '') +
          '<button class="btn sm ghost" id="grpStartChat">' + esc(T('start_chat')) + '</button>' +
        '</div>' +
      '</div>';

    safeCall('openOverlay', ['ovProfile']);

    /* ---- Nickname button wiring ------------------------- */
    qsa('[data-gnick]', body).forEach(function (n) {
      n.addEventListener('click', async function (e) {
        e.stopPropagation();
        var targetUid = n.getAttribute('data-gnick');
        var current = getNickname(chatId, targetUid) || '';
        var inp = await askPrompt(
          T('set_nickname') + ' — ' + userName(targetUid),
          current,
          T('nickname_hint')
        );
        if (inp === null) return;
        safeCall('setNickname', [chatId, targetUid, inp]);
        openGroupInfo(chatId);
      });
    });

    /* ---- Member row click → open profile ---------------- */
    qsa('[data-gm]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var u = n.getAttribute('data-gm');
        if (u !== me) safeCall('openUserProfile', [u]);
      });
    });

    /* ---- Member options (⋯) menu ------------------------ */
    qsa('[data-gmenu]', body).forEach(function (n) {
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        var targetUid = n.getAttribute('data-gmenu');
        var isAd = !!admins[targetUid];

        var items = [
          { k: 'adm', i: 'shield', label: isAd ? T('remove_admin') : T('make_admin') },
          { k: 'rm',  i: 'trash',  label: T('remove_member'), danger: true }
        ];

        var sheet = qs('#msgMenuSheet');
        if (!sheet) return;
        sheet.innerHTML =
          '<div class="sheet-handle"></div>' +
          items.map(function (it) {
            return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" ' +
                        'data-gmm="' + it.k + '">' +
                     svgIcon(it.i) +
                     '<span>' + esc(it.label) + '</span>' +
                   '</div>';
          }).join('');

        safeCall('openOverlay', ['ovMsgMenu']);

        qsa('[data-gmm]', sheet).forEach(function (x) {
          x.addEventListener('click', async function () {
            safeCall('closeOverlay', ['ovMsgMenu']);
            var k = x.getAttribute('data-gmm');

            if (k === 'adm') {
              try {
                await fbDb.ref('chats/' + chatId + '/admins/' + targetUid)
                  .set(isAd ? null : true);
              } catch (e) {}
            } else if (k === 'rm') {
              var ok = await askConfirm(T('remove_member'), T('are_you_sure'));
              if (!ok) return;
              var updates = {};
              updates['chats/' + chatId + '/members/' + targetUid] = null;
              updates['chats/' + chatId + '/admins/' + targetUid]  = null;
              updates['userChats/' + targetUid + '/' + chatId]     = null;
              try { await fbDb.ref().update(updates); } catch (e) {}
            }
            openGroupInfo(chatId);
          });
        });
      });
    });

    /* ---- Change image (admin) --------------------------- */
    var ci = qs('#grpChangeImg', body);
    if (ci) {
      ci.addEventListener('click', function () {
        var inp = document.createElement('input');
        inp.type = 'file';
        inp.accept = 'image/*';
        inp.addEventListener('change', async function () {
          var f = inp.files && inp.files[0];
          if (!f) return;

          /* Validate ----------------------------------- */
          var err = null;
          try {
            if (typeof window.validateImage === 'function') err = window.validateImage(f);
          } catch (e) {}
          if (err) { safeToast(err, 'err'); return; }

          try {
            safeToast(T('uploading'));

            /* Compress ------------------------------- */
            var comp = f;
            try {
              if (typeof window.compressImage === 'function') {
                comp = await window.compressImage(f, 700, 0.82);
              }
            } catch (e) {}

            /* Upload -------------------------------- */
            var url = null;
            if (typeof window.cloudinaryUpload === 'function') {
              url = await window.cloudinaryUpload(comp, 'group.jpg');
            }
            if (!url) throw new Error(T('upload_failed'));

            /* Persist ------------------------------- */
            await fbDb.ref('chats/' + chatId + '/image').set(url);

            /* Update preview ------------------------ */
            var w = qs('#grpImgWrap');
            if (w) w.innerHTML = avatarHTML(url, c.name, 'av-88');

            safeToast(T('saved'), 'ok');
          } catch (e2) {
            safeToast((e2 && e2.message) ? e2.message : T('upload_failed'), 'err');
          }
        });
        inp.click();
      });
    }

    /* ---- Rename (admin) --------------------------------- */
    var rn = qs('#grpRename', body);
    if (rn) {
      rn.addEventListener('click', async function () {
        var nn = await askPrompt(T('rename_group'), c.name || '');
        if (nn == null) return;
        var v = String(nn).trim();
        if (!v) return;
        try { await fbDb.ref('chats/' + chatId + '/name').set(v); } catch (e) {}
        var n2 = qs('#grpName');
        if (n2) n2.textContent = v;
        safeToast(T('saved'), 'ok');
      });
    }

    /* ---- Mute toggle ------------------------------------ */
    var mu = qs('#grpMute', body);
    if (mu) {
      mu.addEventListener('click', async function () {
        var cur = !!(c.muted && c.muted[me]);
        try {
          await fbDb.ref('chats/' + chatId + '/muted/' + me).set(cur ? null : true);
        } catch (e) {}
        safeToast(cur ? T('chat_unmuted') : T('chat_muted'), 'ok');
        openGroupInfo(chatId);
      });
    }

    /* ---- Chat theme ------------------------------------- */
    var th = qs('#grpTheme', body);
    if (th) {
      th.addEventListener('click', function () {
        safeCall('openChatThemePicker', [chatId]);
      });
    }

    /* ---- Leave group ------------------------------------ */
    var lv = qs('#grpLeave', body);
    if (lv) {
      lv.addEventListener('click', async function () {
        var ok = await askConfirm(T('leave_group'), T('are_you_sure'));
        if (!ok) return;

        var updates = {};
        updates['chats/' + chatId + '/members/' + me] = null;
        updates['chats/' + chatId + '/admins/' + me]  = null;
        updates['userChats/' + me + '/' + chatId]     = null;

        try { await fbDb.ref().update(updates); } catch (e) {}

        safeCall('closeOverlay', ['ovProfile']);
        safeCall('closeOverlay', ['ovChat']);
        safeCall('detachChat');
      });
    }

    /* ---- Add members (admin) ---------------------------- */
    var ab = qs('#grpAdd', body);
    if (ab) {
      ab.addEventListener('click', function () {
        var all = Array.isArray(window.allUsersCache) ? window.allUsersCache : [];
        var candidates = all.filter(function (u) {
          return u && u.uid && u.uid !== me && !c.members[u.uid];
        });

        if (!candidates.length) {
          safeToast(T('no_results'));
          return;
        }

        body.innerHTML =
          '<div style="padding:.8rem">' +
            '<div class="sec-title">' + esc(T('add_members')) + '</div>' +
            candidates.map(function (u) {
              return '<div class="picker-item" data-add="' + esc(u.uid) + '">' +
                avatarHTML(u.photo, u.name, 'av-40') +
                '<div class="grow"><div class="name">' + esc(u.name) + '</div></div>' +
                '<span class="ic">' + svgIcon('plus') + '</span>' +
              '</div>';
            }).join('') +
          '</div>';

        qsa('[data-add]', body).forEach(function (n) {
          n.addEventListener('click', async function () {
            var targetUid = n.getAttribute('data-add');
            if (!targetUid) return;

            var updates = {};
            updates['chats/' + chatId + '/members/' + targetUid] = true;
            updates['userChats/' + targetUid + '/' + chatId]     = true;

            try { await fbDb.ref().update(updates); } catch (e) {}

            safeToast(T('saved'), 'ok');
            openGroupInfo(chatId);
          });
        });
      });
    }

    /* ---- Start chat ------------------------------------- */
    var sc = qs('#grpStartChat', body);
    if (sc) {
      sc.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovProfile']);
        safeCall('openChatById', [chatId]);
      });
    }

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openGroupInfo = openGroupInfo;

  window.SaikoGroupInfo = {
    open: openGroupInfo
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 119 — group-info ready');
  } catch (e) {}

})();