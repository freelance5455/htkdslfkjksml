/* ============================================================
 * FEATURE:        New Direct Chat (Picker + Ensure Chat)
 * FEATURE NUMBER: 114
 * FILE:           js/inbox/114-new-direct-chat.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "New Chat" flow for starting a direct (1:1) chat
 *   with another user. Handles three concerns:
 *
 *     1. PICKER OVERLAY
 *          openNewChatPicker() — resets picker state, sets the
 *          title, opens #ovPicker.
 *          renderPickerList() — builds the search bar + user
 *          list into #pickerBody, wires row click to
 *          startDirectChat() when the picker is in
 *          'newchat' mode, and wires the search input for
 *          client-side filtering.
 *
 *     2. CHAT GUARANTEE
 *          ensureDirectChat(otherUid) — deterministic chat id
 *          `[a,b].sort().join('_')`, create the chats/{id}
 *          node if missing, mirror into userChats/{uid}/{id}
 *          for both members.
 *
 *     3. OPEN
 *          startDirectChat(otherUid) — block check + ensure +
 *          openChatById(chatId).
 *
 *   Behaviour preserved 1:1 from the original §21 block.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §21 PICKERS / GROUP → openNewChatPicker(),
 *     renderPickerList(), startDirectChat(uid),
 *     ensureDirectChat(otherUid).
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid / myProfile      js/auth/004-auth-state.js
 *   - t / esc                helpers
 *   - svgIcon                js/nav/045-icon-system.js
 *   - avatarHTML / findUser  helpers / feature 091
 *   - openOverlay / closeOverlay (038)
 *   - openChatById (112)     js/inbox/112-chat-open.js
 *   - iBlocked               feature 011 / 012
 *   - openForwardPicker      feature 131 (sets pickerMode='forward')
 *
 * DOM ELEMENTS USED:
 *   #ovPicker, #pickerTitle, #pickerDone, #pickerBody
 *
 * FIREBASE PATHS:
 *   chats/{chatId}                  (read + write)
 *   userChats/{uid}/{chatId}        (write)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.pickerMode
 *   window.pickerSelected
 *   window.openNewChatPicker         (original name preserved)
 *   window.renderPickerList          (original name preserved)
 *   window.startDirectChat           (original name preserved)
 *   window.ensureDirectChat          (original name preserved)
 *   window.SaikoNewDirectChat = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================
   * `pickerMode` and `pickerSelected` are shared with the
   * forward-picker (feature 131) and any future picker variant
   * — the original kept them module-scoped and mutated them
   * from multiple sites, so we expose them on window.
   * ============================================================ */
  window.pickerMode     = window.pickerMode || 'newchat';
  window.pickerSelected = window.pickerSelected || [];

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[new-direct-chat] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function isBlocked(uid) {
    try {
      if (typeof window.iBlocked === 'function') return !!window.iBlocked(uid);
    } catch (e) {}
    return !!(window.blockedUsers && window.blockedUsers[uid]);
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * OPEN PICKER — entry point
   * ============================================================ */
  function openNewChatPicker() {
    window.pickerMode = 'newchat';
    window.pickerSelected = [];

    var title = qs('#pickerTitle');
    if (title) title.textContent = T('new_chat');

    var done = qs('#pickerDone');
    if (done) done.classList.add('hidden');

    renderPickerList();
    safeCall('openOverlay', ['ovPicker']);
    return true;
  }

  /* ============================================================
   * RENDER LIST
   * ============================================================
   * Preserved 1:1 from the original renderPickerList():
   *   • search bar + user list into #pickerBody
   *   • filter out self + blocked users
   *   • list row click → startDirectChat when mode = newchat
   *   • search input → client-side name filter
   * ============================================================ */
  function renderPickerList() {
    var body = qs('#pickerBody');
    if (!body) return;

    var uid = getMyUid();

    /* ---- Skeleton --------------------------------------- */
    body.innerHTML =
      '<div class="searchbar">' +
        '<span class="ic">' + svgIcon('search') + '</span>' +
        '<input type="search" id="pickerSearch" placeholder="' +
          esc(T('search_users_ph')) + '">' +
      '</div>' +
      '<div id="pickerList"></div>';

    var list = qs('#pickerList', body);
    if (!list) return;

    /* ---- Filter users ----------------------------------- */
    var all = Array.isArray(window.allUsersCache) ? window.allUsersCache : [];
    var users = all.filter(function (u) {
      if (!u || !u.uid) return false;
      if (u.uid === uid) return false;
      if (isBlocked(u.uid)) return false;
      return true;
    });

    /* ---- Empty state ------------------------------------ */
    if (!users.length) {
      list.innerHTML =
        '<div class="empty"><p>' + esc(T('no_results')) + '</p></div>';
      return;
    }

    /* ---- Render rows ------------------------------------ */
    list.innerHTML = users.map(function (u) {
      return '<div class="picker-item" data-pick="' + esc(u.uid) + '">' +
        avatarHTML(u.photo, u.name, 'av-40', u.uid) +
        '<div class="grow">' +
          '<div class="name">' + esc(u.name || 'User') + '</div>' +
          '<div class="muted ellipsis">' + esc((u.bio || '').slice(0, 60) || '—') + '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    /* ---- Wire row clicks -------------------------------- */
    var rows = list.querySelectorAll('[data-pick]');
    for (var i = 0; i < rows.length; i++) {
      (function (row) {
        row.addEventListener('click', function () {
          var target = row.getAttribute('data-pick');
          if (!target) return;
          if (window.pickerMode === 'newchat') {
            safeCall('closeOverlay', ['ovPicker']);
            startDirectChat(target);
          }
          /* Forward-picker (mode === 'forward') is handled
           * by feature 131's own delegated handler — we do
           * not interfere. */
        });
      })(rows[i]);
    }

    /* ---- Search input ----------------------------------- */
    var s = qs('#pickerSearch', body);
    if (s) {
      s.addEventListener('input', function () {
        var q = (s.value || '').trim().toLowerCase();
        var rowNodes = list.querySelectorAll('[data-pick]');
        for (var j = 0; j < rowNodes.length; j++) {
          var rn = rowNodes[j];
          var uu = findUser(rn.getAttribute('data-pick'));
          if (!uu) continue;
          var nm = (uu.name || '').toLowerCase();
          rn.style.display = (!q || nm.indexOf(q) !== -1) ? '' : 'none';
        }
      });
    }
  }

  /* ============================================================
   * ENSURE DIRECT CHAT
   * ============================================================
   * Preserved 1:1 from the original ensureDirectChat():
   *   • deterministic chat id — [a,b].sort().join('_')
   *   • create the chats/{id} node when missing
   *   • mirror into userChats/{uid}/{id} for BOTH members
   *   • return the id
   * ============================================================ */
  async function ensureDirectChat(otherUid) {
    var uid = getMyUid();
    var fbDb = getDB();
    if (!fbDb || !uid || !otherUid) return null;

    var id = [uid, otherUid].sort().join('_');
    var snap = await fbDb.ref('chats/' + id).get();

    if (!snap.exists()) {
      var other = findUser(otherUid);
      await fbDb.ref('chats/' + id).set({
        type: 'direct',
        members: { [uid]: true, [otherUid]: true },
        otherName: (other && other.name) || '',
        createdAt: timeNow(),
        lastAt: timeNow(),
        lastMessage: ''
      });

      var updates = {};
      updates['userChats/' + uid + '/' + id] = true;
      updates['userChats/' + otherUid + '/' + id] = true;
      await fbDb.ref().update(updates);
    }

    return id;
  }

  /* ============================================================
   * START DIRECT CHAT
   * ============================================================
   * Preserved 1:1 from the original startDirectChat(otherUid):
   *   • block guard with toast
   *   • ensure the chat node exists
   *   • openChatById
   * ============================================================ */
  async function startDirectChat(otherUid) {
    if (!otherUid) return false;

    if (isBlocked(otherUid)) {
      safeToast(T('user_blocked'), 'err');
      return false;
    }

    try {
      var id = await ensureDirectChat(otherUid);
      if (!id) return false;
      safeCall('openChatById', [id]);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openNewChatPicker = openNewChatPicker;
  window.renderPickerList  = renderPickerList;
  window.startDirectChat   = startDirectChat;
  window.ensureDirectChat  = ensureDirectChat;

  window.SaikoNewDirectChat = {
    openPicker: openNewChatPicker,
    renderPickerList: renderPickerList,
    startDirectChat: startDirectChat,
    ensureDirectChat: ensureDirectChat,
    getMode: function () { return window.pickerMode; },
    setMode: function (m) { window.pickerMode = m; return true; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 114 — new-direct-chat ready');
  } catch (e) {}

})();