/* ============================================================
 * FEATURE:        Inbox List (Image-2 redesign)
 * FEATURE NUMBER: 111
 * FILE:           js/inbox/111-inbox-list.js
 * ACTION:         REPLACE
 * ============================================================ */

(function () {
  'use strict';

  var userChatsRef = null;
  var userChatsCb  = null;
  var chatMetaRefs = {};

  var pinnedRef = null;
  var pinnedCb  = null;
  var pinnedChats = {};   /* { [chatId]: true } */

  var currentFilter = 'all'; /* all | direct | group | calls */

  window.chatMeta  = window.chatMeta  || {};
  window.unreadMap = window.unreadMap || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[inbox-list] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function getNickname(chatId, targetUid) {
    try {
      if (typeof window.getNickname === 'function') {
        return window.getNickname(chatId, targetUid);
      }
    } catch (e) {}
    return null;
  }
  function iBlocked(uid) {
    try {
      if (typeof window.iBlocked === 'function') return !!window.iBlocked(uid);
    } catch (e) {}
    return !!(window.blockedUsers && window.blockedUsers[uid]);
  }

  /* ============================================================
   * BADGE
   * ============================================================ */
  function updateInboxBadge() {
    var total = 0;
    var map = window.unreadMap || {};
    var keys = Object.keys(map);
    for (var i = 0; i < keys.length; i++) total += (map[keys[i]] || 0);

    var nb = window.SaikoNavBadges;
    if (nb && typeof nb.setInboxBadge === 'function') {
      try { nb.setInboxBadge(total); return; } catch (e) {}
    }
    var badge = qs('#navInboxBadge');
    if (!badge) return;
    badge.textContent = total ? (total > 99 ? '99+' : String(total)) : '';
  }

  /* ============================================================
   * CHAT DISPLAY
   * ============================================================ */
  function chatDisplay(chatId, c) {
    if (!c) return { name: 'Chat', photo: '', uid: null };

    if (c.adminSupport) {
      return { name: T('admin_support'), photo: '', uid: null };
    }

    if (c.type === 'group') {
      return { name: c.name || 'Group', photo: c.image || '', uid: null };
    }

    var me = getMyUid();
    var members = c.members || {};
    var other = null;
    var keys = Object.keys(members);
    for (var i = 0; i < keys.length; i++) {
      if (keys[i] !== me) { other = keys[i]; break; }
    }
    if (!other) other = me;

    var u = findUser(other);
    var nick = getNickname(chatId, other);
    return {
      name: nick || (u && u.name) || c.otherName || 'User',
      photo: (u && u.photo) || '',
      uid: other
    };
  }

  /* ============================================================
   * START LISTENERS
   * ============================================================ */
  function startInbox() {
    if (userChatsRef && userChatsCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    /* ---- userChats ---- */
    userChatsRef = fbDb.ref('userChats/' + uid);
    userChatsCb  = userChatsRef.on('value', function (snap) {
      var v = snap.val() || {};
      var ids = Object.keys(v);

      Object.keys(chatMetaRefs).forEach(function (id) {
        if (ids.indexOf(id) === -1) {
          try { chatMetaRefs[id].ref.off('value', chatMetaRefs[id].cb); } catch (e) {}
          delete chatMetaRefs[id];
          delete window.chatMeta[id];
          delete window.unreadMap[id];
        }
      });

      ids.forEach(function (id) {
        if (chatMetaRefs[id]) return;
        var ref = fbDb.ref('chats/' + id);
        var cb  = ref.on('value', function (s) {
          var d = s.val();
          if (!d) {
            delete window.chatMeta[id];
            delete window.unreadMap[id];
          } else {
            window.chatMeta[id] = Object.assign({ id: id }, d);
            window.unreadMap[id] = (d.unread && d.unread[uid]) || 0;
          }
          updateInboxBadge();
          if (typeof window.currentNav === 'string' && window.currentNav === 'inbox') {
            renderInbox();
          }
        });
        chatMetaRefs[id] = { ref: ref, cb: cb };
      });

      updateInboxBadge();
      if (typeof window.currentNav === 'string' && window.currentNav === 'inbox') {
        renderInbox();
      }
    });

    /* ---- pinned chats ---- */
    pinnedRef = fbDb.ref('pinnedChats/' + uid);
    pinnedCb = pinnedRef.on('value', function (s) {
      pinnedChats = s.val() || {};
      if (typeof window.currentNav === 'string' && window.currentNav === 'inbox') {
        renderInbox();
      }
    });

    return true;
  }

  function detachInbox() {
    if (userChatsRef && userChatsCb) {
      try { userChatsRef.off('value', userChatsCb); } catch (e) {}
    }
    userChatsRef = null; userChatsCb = null;

    if (pinnedRef && pinnedCb) {
      try { pinnedRef.off('value', pinnedCb); } catch (e) {}
    }
    pinnedRef = null; pinnedCb = null;
    pinnedChats = {};

    Object.keys(chatMetaRefs).forEach(function (id) {
      try { chatMetaRefs[id].ref.off('value', chatMetaRefs[id].cb); } catch (e) {}
    });
    chatMetaRefs = {};
    window.chatMeta  = {};
    window.unreadMap = {};
    return true;
  }

  /* ============================================================
   * RENDER — IMAGE 2 LAYOUT
   * ============================================================ */
  function renderInbox() {
    var page = qs('#page-inbox');
    if (!page) return;

    var me = getMyUid();
    var all = Object.keys(window.chatMeta || {});

    /* ---- Compute counts for chips ---- */
    var countDirect = 0, countGroup = 0, countAll = 0;
    all.forEach(function (id) {
      var c = window.chatMeta[id];
      if (!c) return;
      if (c.type === 'direct' || c.adminSupport) countDirect++;
      else if (c.type === 'group') countGroup++;
      countAll++;
    });
    var callHistoryCount = 0;
    try {
      if (Array.isArray(window.callHistoryCache)) callHistoryCount = window.callHistoryCache.length;
    } catch (e) {}

    /* ---- Filter rows ---- */
    var ids = all.filter(function (id) {
      var c = window.chatMeta[id];
      if (!c) return false;

      /* Block peer in direct chats */
      if (c.type === 'direct' && !c.adminSupport) {
        var members = c.members || {};
        var other = null;
        var mKeys = Object.keys(members);
        for (var i = 0; i < mKeys.length; i++) {
          var k = mKeys[i];
          if (k !== me && k !== 'admin') { other = k; break; }
        }
        if (other && iBlocked(other)) return false;
      }

      if (currentFilter === 'direct') return (c.type === 'direct' || c.adminSupport);
      if (currentFilter === 'group')  return (c.type === 'group');
      if (currentFilter === 'calls')  return false; /* calls view opens history */
      return true; /* all */
    });

    /* Sort: pinned first, then by lastAt desc */
    ids.sort(function (a, b) {
      var aP = !!pinnedChats[a];
      var bP = !!pinnedChats[b];
      if (aP !== bP) return aP ? -1 : 1;
      var A = window.chatMeta[a] || {};
      var B = window.chatMeta[b] || {};
      var at = A.lastAt || A.createdAt || 0;
      var bt = B.lastAt || B.createdAt || 0;
      return bt - at;
    });

    /* ---- Compose HTML ---- */
    var header =
      '<div class="ix-header">' +
        '<div class="ix-head-left">' +
          '<div class="ix-head-icon">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
              '<path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/>' +
              '<path d="M8 11h.01M12 11h.01M16 11h.01"/>' +
            '</svg>' +
          '</div>' +
          '<div class="grow">' +
            '<div class="ix-title">' + esc(T('inbox') || 'Inbox') + '</div>' +
            '<div class="ix-subtitle">Your chats, groups and more...</div>' +
          '</div>' +
        '</div>' +
        '<div class="ix-online-pill">' +
          '<span class="ix-online-dot"></span>' +
          '<span>Online</span>' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:.75rem;height:.75rem">' +
            '<path d="m6 9 6 6 6-6"/>' +
          '</svg>' +
        '</div>' +
      '</div>';

    var chips =
      '<div class="ix-chips" id="ixChips">' +
        '<div class="ix-chip ' + (currentFilter === 'all' ? 'sel' : '') + '" data-ifilter="all">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/></svg>' +
          '<span>All Chats</span><span class="cnt">' + countAll + '</span>' +
        '</div>' +
        '<div class="ix-chip ' + (currentFilter === 'direct' ? 'sel' : '') + '" data-ifilter="direct">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>' +
          '<span>Direct</span><span class="cnt">' + countDirect + '</span>' +
        '</div>' +
        '<div class="ix-chip ' + (currentFilter === 'group' ? 'sel' : '') + '" data-ifilter="group">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M17 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-4-6.3"/></svg>' +
          '<span>Groups</span><span class="cnt">' + countGroup + '</span>' +
        '</div>' +
        '<div class="ix-chip ' + (currentFilter === 'calls' ? 'sel' : '') + '" data-ifilter="calls">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>' +
          '<span>Calls</span><span class="cnt">' + callHistoryCount + '</span>' +
        '</div>' +
      '</div>';

    var actions =
      '<div class="ix-actions">' +
        '<div class="ix-action" data-iact="newchat">' +
          '<div class="ix-action-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/><path d="M12 8v6M9 11h6"/></svg></div>' +
          '<div class="ix-action-label">New Chat</div>' +
        '</div>' +
        '<div class="ix-action" data-iact="newgroup">' +
          '<div class="ix-action-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M17 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-4-6.3"/><path d="M18 10v4M16 12h4"/></svg></div>' +
          '<div class="ix-action-label">New Group</div>' +
        '</div>' +
        '<div class="ix-action" data-iact="newcall">' +
          '<div class="ix-action-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></div>' +
          '<div class="ix-action-label">New Call</div>' +
        '</div>' +
        '<div class="ix-action" data-iact="contacts">' +
          '<div class="ix-action-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></div>' +
          '<div class="ix-action-label">Contacts</div>' +
        '</div>' +
      '</div>';

    /* ---- Chat rows ---- */
    var listHTML = '';
    if (currentFilter === 'calls') {
      listHTML = '';
    } else if (!ids.length) {
      listHTML = '<div class="empty">' +
        '<span class="ic">' + svgIcon('chat') + '</span>' +
        '<p>' + esc(T('no_chats') || 'No chats yet') + '</p>' +
      '</div>';
    } else {
      listHTML = ids.map(function (id) {
        var c = window.chatMeta[id];
        var info = chatDisplay(id, c);
        var unread = window.unreadMap[id] || 0;
        var muted = !!(c && c.muted && c.muted[me]);
        var isPinned = !!pinnedChats[id];
        var avUid = (c && c.type === 'direct' && !c.adminSupport) ? info.uid : null;
        var online = !!(avUid && window.onlineUsers && window.onlineUsers[avUid]);

        var lastMsg = String(c.lastMessage || '').slice(0, 80);

        /* Prefix "You:" for messages sent by me — check via lastFrom if available */
        var isMine = false;
        try { isMine = (c.lastFrom === me); } catch (e) {}
        var msgHTML = isMine
          ? ('<span class="you">You:</span>' + esc(lastMsg))
          : esc(lastMsg);

        var badgeHTML = '';
        if (muted) badgeHTML = ' <span class="ci-badge">🔇</span>';
        if (c.adminSupport) badgeHTML = ' <span class="ci-badge">🛡</span>';

        var unreadHTML = unread
          ? ('<span class="ci-unread">' + (unread > 99 ? '99+' : unread) + '</span>')
          : '';

        var pinHTML = isPinned
          ? ('<span class="ci-pin-chip">📌 Pinned</span>')
          : '';

        var tickHTML = isMine && !unread
          ? ('<span class="ci-read-tick">✓✓</span>')
          : '';

        var onlineDot = online
          ? ('<span class="ci-online"></span>')
          : '';

        return '<div class="chat-item' + (isPinned ? ' pinned' : '') + '" data-chat="' + esc(id) + '">' +
          '<div class="ci-avatar">' +
            avatarHTML(info.photo, info.name, 'av-40', avUid) +
            onlineDot +
          '</div>' +
          '<div class="ci-body">' +
            '<div class="ci-toprow">' +
              '<span class="ci-name">' + esc(info.name) + badgeHTML + '</span>' +
            '</div>' +
            '<div class="ci-msg">' + msgHTML + '</div>' +
          '</div>' +
          '<div class="ci-side">' +
            '<span class="ci-time">' + esc(timeAgo(c.lastAt || c.createdAt)) + '</span>' +
            pinHTML +
            (unreadHTML || tickHTML) +
          '</div>' +
          '<button class="ci-menu" data-cmenu="' + esc(id) + '" aria-label="Chat menu">⋮</button>' +
        '</div>';
      }).join('');
    }

    /* ---- Compose page ---- */
    page.innerHTML = header + chips + actions + '<div id="inboxList">' + listHTML + '</div>';

    /* ---- Wire chips ---- */
    qsa('[data-ifilter]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        var f = n.getAttribute('data-ifilter');
        if (f === 'calls') {
          /* Calls chip → open call history directly */
          safeCall('openCallHistory');
          return;
        }
        currentFilter = f;
        renderInbox();
      });
    });

    /* ---- Wire action cards ---- */
    qsa('[data-iact]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        var act = n.getAttribute('data-iact');
        if (act === 'newchat')  safeCall('openNewChatPicker');
        else if (act === 'newgroup') safeCall('openGroupScreen');
        else if (act === 'newcall')  openCallPicker();
        else if (act === 'contacts') openContactsPicker();
      });
    });

    /* ---- Wire chat rows ---- */
    qsa('[data-chat]', page).forEach(function (n) {
      n.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('[data-cmenu]')) return;
        safeCall('openChatById', [n.getAttribute('data-chat')]);
      });
    });

    /* ---- Wire 3-dot menu ---- */
    qsa('[data-cmenu]', page).forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        openChatMenu(b.getAttribute('data-cmenu'));
      });
    });
  }

  /* ============================================================
   * CHAT MENU (3 dots)
   * ============================================================ */
  async function openChatMenu(chatId) {
    if (!chatId) return;
    var fbDb = getDB();
    var uid = getMyUid();
    if (!fbDb || !uid) return;

    var isPinned = !!pinnedChats[chatId];
    var items = [
      { k: 'pin',   i: 'pin',  label: isPinned ? 'Unpin chat' : 'Pin chat' },
      { k: 'read',  i: 'check', label: 'Mark as read' },
      { k: 'clear', i: 'trash', label: 'Clear chat', danger: true },
      { k: 'del',   i: 'trash', label: 'Delete chat', danger: true }
    ];

    var sheet = qs('#msgMenuSheet');
    if (!sheet) return;

    sheet.innerHTML = '<div class="sheet-handle"></div>' + items.map(function (it) {
      return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" data-cm="' + it.k + '">' +
        svgIcon(it.i) + '<span>' + esc(it.label) + '</span>' +
      '</div>';
    }).join('');

    safeCall('openOverlay', ['ovMsgMenu']);

    qsa('[data-cm]', sheet).forEach(function (n) {
      n.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovMsgMenu']);
        var k = n.getAttribute('data-cm');

        if (k === 'pin') {
          try {
            if (isPinned) {
              await fbDb.ref('pinnedChats/' + uid + '/' + chatId).remove();
            } else {
              await fbDb.ref('pinnedChats/' + uid + '/' + chatId).set(true);
            }
          } catch (e) {}
        }
        else if (k === 'read') {
          try { await fbDb.ref('chats/' + chatId + '/unread/' + uid).set(0); } catch (e) {}
        }
        else if (k === 'clear') {
          var ok1 = await safeCall('confirmDialog', ['Clear chat', T('are_you_sure')]);
          if (!ok1) return;
          try {
            var snap = await fbDb.ref('messages/' + chatId).get();
            var v = snap.val() || {};
            var updates = {};
            Object.keys(v).forEach(function (mid) {
              updates['messageHides/' + uid + '/' + chatId + '/' + mid] = true;
            });
            if (Object.keys(updates).length) await fbDb.ref().update(updates);
          } catch (e) {}
        }
        else if (k === 'del') {
          var ok2 = await safeCall('confirmDialog', ['Delete chat', T('are_you_sure')]);
          if (!ok2) return;
          try {
            await fbDb.ref('userChats/' + uid + '/' + chatId).remove();
          } catch (e) {}
        }
      });
    });
  }

  /* ============================================================
   * NEW CALL PICKER
   * ============================================================ */
  function openCallPicker() {
    var body = qs('#pickerBody');
    var title = qs('#pickerTitle');
    if (!body) { safeCall('openNewChatPicker'); return; }

    if (title) title.textContent = 'New Call';

    var me = getMyUid();
    var users = (Array.isArray(window.allUsersCache) ? window.allUsersCache : [])
      .filter(function (u) { return u && u.uid && u.uid !== me; });

    body.innerHTML =
      '<div class="searchbar">' +
        '<span class="ic">' + svgIcon('search') + '</span>' +
        '<input type="search" id="callPickSearch" placeholder="Search users...">' +
      '</div>' +
      '<div id="callPickList">' +
        (users.length ? users.map(function (u) {
          return '<div class="picker-item" data-callpick="' + esc(u.uid) + '">' +
            avatarHTML(u.photo, u.name, 'av-40', u.uid) +
            '<div class="grow"><div class="name">' + esc(u.name || 'User') + '</div></div>' +
            '<span class="ic" style="color:#00e676">' + svgIcon('phone') + '</span>' +
          '</div>';
        }).join('') : '<div class="empty"><p>No users</p></div>') +
      '</div>';

    safeCall('openOverlay', ['ovPicker']);

    qsa('[data-callpick]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var uid = n.getAttribute('data-callpick');
        if (!uid) return;
        safeCall('closeOverlay', ['ovPicker']);
        var u = findUser(uid) || { name: 'User', photo: '' };
        safeCall('startCall', [uid, 'audio', u.name, u.photo]);
      });
    });

    var s = qs('#callPickSearch', body);
    if (s) {
      s.addEventListener('input', function () {
        var q = (s.value || '').toLowerCase();
        qsa('[data-callpick]', body).forEach(function (n) {
          var u = findUser(n.getAttribute('data-callpick'));
          if (!u) return;
          n.style.display = (!q || (u.name || '').toLowerCase().indexOf(q) !== -1) ? '' : 'none';
        });
      });
    }
  }

  /* ============================================================
   * CONTACTS PICKER
   * ============================================================ */
  function openContactsPicker() {
    var body = qs('#pickerBody');
    var title = qs('#pickerTitle');
    if (!body) { safeCall('openNewChatPicker'); return; }

    if (title) title.textContent = 'Contacts';

    var me = getMyUid();
    var users = (Array.isArray(window.allUsersCache) ? window.allUsersCache : [])
      .filter(function (u) { return u && u.uid && u.uid !== me; });

    body.innerHTML =
      '<div class="searchbar">' +
        '<span class="ic">' + svgIcon('search') + '</span>' +
        '<input type="search" id="contactsSearch" placeholder="Search contacts...">' +
      '</div>' +
      '<div id="contactsList">' +
        (users.length ? users.map(function (u) {
          return '<div class="picker-item" data-contact="' + esc(u.uid) + '">' +
            avatarHTML(u.photo, u.name, 'av-40', u.uid) +
            '<div class="grow">' +
              '<div class="name">' + esc(u.name || 'User') + '</div>' +
              (u.bio ? '<div class="muted ellipsis">' + esc(String(u.bio).slice(0, 50)) + '</div>' : '') +
            '</div>' +
          '</div>';
        }).join('') : '<div class="empty"><p>No contacts</p></div>') +
      '</div>';

    safeCall('openOverlay', ['ovPicker']);

    qsa('[data-contact]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var uid = n.getAttribute('data-contact');
        if (!uid) return;
        safeCall('closeOverlay', ['ovPicker']);
        safeCall('startDirectChat', [uid]);
      });
    });

    var s = qs('#contactsSearch', body);
    if (s) {
      s.addEventListener('input', function () {
        var q = (s.value || '').toLowerCase();
        qsa('[data-contact]', body).forEach(function (n) {
          var u = findUser(n.getAttribute('data-contact'));
          if (!u) return;
          n.style.display = (!q || (u.name || '').toLowerCase().indexOf(q) !== -1) ? '' : 'none';
        });
      });
    }
  }

  /* ============================================================
   * ADMIN SUPPORT (unchanged core flow)
   * ============================================================ */
  async function openAdminSupport() {
    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    var chatId = 'admin_' + uid;
    var me = getMyProfile() || {};

    try {
      var snap = await fbDb.ref('adminChats/' + chatId).get();

      if (!snap.exists()) {
        await fbDb.ref('adminChats/' + chatId).set({
          type: 'adminSupport',
          userId: uid,
          userName: me.name || '',
          userPhoto: me.photo || '',
          createdAt: timeNow(),
          lastAt: timeNow(),
          lastMessage: '',
          unreadAdmin: 0,
          unreadUser: 0
        });
        await fbDb.ref('userChats/' + uid + '/' + chatId).set(true);
        await fbDb.ref('chats/' + chatId).set({
          type: 'direct',
          adminSupport: true,
          members: Object.assign({}, { [uid]: true }, { admin: true }),
          otherName: T('admin_support'),
          createdAt: timeNow(),
          lastAt: timeNow(),
          lastMessage: ''
        });
      } else {
        await fbDb.ref('userChats/' + uid + '/' + chatId).set(true);
        var ex = await fbDb.ref('chats/' + chatId).get();
        if (!ex.exists()) {
          await fbDb.ref('chats/' + chatId).set({
            type: 'direct',
            adminSupport: true,
            members: Object.assign({}, { [uid]: true }, { admin: true }),
            otherName: T('admin_support'),
            createdAt: timeNow(),
            lastAt: timeNow(),
            lastMessage: ''
          });
        }
      }

      try {
        if (window.E2E && typeof window.E2E.getOrCreateMyKeyPair === 'function') {
          var kp = await window.E2E.getOrCreateMyKeyPair(uid);
          await fbDb.ref('e2eKeys/' + uid).set({ jwk: kp.pubJwk, v: 1 });
        } else if (window.SaikoE2E && typeof window.SaikoE2E.getOrCreateMyKeyPair === 'function') {
          var kp2 = await window.SaikoE2E.getOrCreateMyKeyPair(uid);
          await fbDb.ref('e2eKeys/' + uid).set({ jwk: kp2.pubJwk, v: 1 });
        }
      } catch (e) {}

      safeCall('openChatById', [chatId]);
      return true;
    } catch (err) {
      safeCall('toast', [(err && err.message) ? err.message : T('error'), 'err']);
      return false;
    }
  }

  /* ============================================================
   * TOPBAR SETTINGS BUTTON
   * ============================================================ */
  function bindTopSettings() {
    var sBtn = qs('#btnSettingsTop');
    if (!sBtn || sBtn.dataset.bound === '1') return;
    sBtn.dataset.bound = '1';
    sBtn.addEventListener('click', function () {
      safeCall('openSettingsSidebar');
    });
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startInbox        = startInbox;
  window.detachInbox       = detachInbox;
  window.updateInboxBadge  = updateInboxBadge;
  window.renderInbox       = renderInbox;
  window.chatDisplay       = chatDisplay;
  window.openAdminSupport  = openAdminSupport;
  window.openCallPicker    = openCallPicker;
  window.openContactsPicker = openContactsPicker;

  window.SaikoInboxList = {
    start: startInbox,
    detach: detachInbox,
    render: renderInbox,
    updateBadge: updateInboxBadge,
    chatDisplay: chatDisplay,
    openAdminSupport: openAdminSupport,
    openCallPicker: openCallPicker,
    openContactsPicker: openContactsPicker,
    getChatMeta: function () { return window.chatMeta; },
    getUnreadMap: function () { return window.unreadMap; },
    getPinnedChats: function () { return pinnedChats; },
    setFilter: function (f) { currentFilter = f; renderInbox(); },
    getFilter: function () { return currentFilter; }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindTopSettings, { once: true });
  } else {
    bindTopSettings();
  }
  setTimeout(bindTopSettings, 800);
  setTimeout(bindTopSettings, 2000);

  try { console.debug('[boot] feature 111 — inbox-list (image-2 redesign) ready'); } catch (e) {}
})();