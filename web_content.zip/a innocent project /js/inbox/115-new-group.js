/* ============================================================
 * FEATURE:        New Group Chat
 * FEATURE NUMBER: 115
 * FILE:           js/inbox/115-new-group.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "New Group" creation flow. Handles:
 *
 *     1. PICKER OVERLAY
 *          openGroupScreen() — resets the group state, sets the
 *          initial preview, opens #ovGroup, and renders the
 *          user-picker list.
 *
 *     2. USER LIST + SEARCH
 *          Renders one row per user (excluding self) with a
 *          checkbox-style checkmark. Clicking a row toggles
 *          selection. A search input filters rows by name.
 *
 *     3. GROUP IMAGE
 *          #btnGroupImage → file input → compressImage →
 *          cloudinaryUpload → updates groupImageUrl and the
 *          #groupImagePreview.
 *
 *     4. CREATE
 *          #btnCreateGroup → validates name + members,
 *          writes chats/{id}, mirrors into userChats/{uid}/{id}
 *          for every member.
 *
 *   Behaviour preserved 1:1 from the original §21 block.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §21 PICKERS / GROUP → openGroupScreen(),
 *     the group-user-picker render, the #groupImageFile
 *     upload flow, and the #btnCreateGroup click handler.
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - t / esc / now            helpers
 *   - svgIcon                  js/nav/045-icon-system.js
 *   - avatarHTML / findUser    helpers / feature 091
 *   - openOverlay / closeOverlay (038)
 *   - validateImage / compressImage / cloudinaryUpload
 *   - openChatById (112)       js/inbox/112-chat-open.js
 *   - toast                    js/nav/042-toast.js
 *
 * DOM ELEMENTS USED:
 *   #ovGroup, #groupName, #groupImagePreview,
 *   #btnGroupImage, #groupImageFile, #groupUserSearch,
 *   #groupUserList, #btnCreateGroup
 *
 * FIREBASE PATHS:
 *   chats/{chatId}                   (write)
 *   userChats/{uid}/{chatId}         (write)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.groupSelected       (live array)
 *   window.groupImageUrl       (live string)
 *   window.openGroupScreen     (original name preserved)
 *   window.SaikoNewGroup = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE — shared on window (matches original)
   * ============================================================ */
  window.groupSelected = window.groupSelected || [];
  window.groupImageUrl = window.groupImageUrl || '';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[new-group] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * OPEN — entry point
   * ============================================================
   * Preserved 1:1 from the original #btnNewGroup click flow:
   *   • reset selected + name + image + search input
   *   • reset the preview to the placeholder avatar
   *   • render the picker list
   *   • open the overlay
   * ============================================================ */
  function openGroupScreen() {
    var uid = getMyUid();
    if (!uid) return false;

    window.groupSelected = [];
    window.groupImageUrl = '';

    var nameEl = qs('#groupName');
    if (nameEl) nameEl.value = '';

    var searchEl = qs('#groupUserSearch');
    if (searchEl) searchEl.value = '';

    /* Replace the preview node so any previous <img> is gone */
    var preview = qs('#groupImagePreview');
    if (preview) {
      var wrapper = document.createElement('div');
      wrapper.className = 'avatar av-56';
      wrapper.id = 'groupImagePreview';
      preview.parentNode && preview.parentNode.replaceChild(wrapper, preview);
    }

    renderUserList();
    safeCall('openOverlay', ['ovGroup']);
    return true;
  }

  /* ============================================================
   * RENDER USER LIST
   * ============================================================
   * Preserved 1:1 from the original block:
   *   • one .picker-item per user (excluding self)
   *   • .on class when selected
   *   • [data-check] span shows the check svg when selected
   *   • click toggles selection + refreshes the checkmark
   *   • search input filters rows by lowercase name match
   * ============================================================ */
  function renderUserList() {
    var list = qs('#groupUserList');
    if (!list) return;

    var uid = getMyUid();
    var all = Array.isArray(window.allUsersCache) ? window.allUsersCache : [];
    var users = all.filter(function (u) {
      return u && u.uid && u.uid !== uid;
    });

    if (!users.length) {
      list.innerHTML = '<div class="empty"><p>' + esc(T('no_results')) + '</p></div>';
      return;
    }

    list.innerHTML = users.map(function (u) {
      var isSel = window.groupSelected.indexOf(u.uid) !== -1;
      return '<div class="picker-item' + (isSel ? ' on' : '') + '" data-gpick="' + esc(u.uid) + '">' +
        avatarHTML(u.photo, u.name, 'av-40') +
        '<div class="grow">' +
          '<div class="name">' + esc(u.name || 'User') + '</div>' +
        '</div>' +
        '<span class="ic" data-check="' + esc(u.uid) + '">' +
          (isSel ? svgIcon('check') : '') +
        '</span>' +
      '</div>';
    }).join('');

    /* ---- Row click toggles selection ------------------- */
    var rows = list.querySelectorAll('[data-gpick]');
    for (var i = 0; i < rows.length; i++) {
      (function (row) {
        row.addEventListener('click', function () {
          var target = row.getAttribute('data-gpick');
          if (!target) return;
          var idx = window.groupSelected.indexOf(target);
          if (idx === -1) window.groupSelected.push(target);
          else            window.groupSelected.splice(idx, 1);

          var on = window.groupSelected.indexOf(target) !== -1;
          row.classList.toggle('on', on);
          var check = row.querySelector('[data-check]');
          if (check) check.innerHTML = on ? svgIcon('check') : '';
        });
      })(rows[i]);
    }

    /* ---- Search filter --------------------------------- *
     * Wire idempotently: replace the input via clone so a
     * fresh listener is attached every render.
     * ---------------------------------------------------- */
    var s = qs('#groupUserSearch');
    if (s) {
      var clone = s.cloneNode(true);
      clone.removeAttribute('data-group-search-bound');
      s.parentNode && s.parentNode.replaceChild(clone, s);

      clone.addEventListener('input', function () {
        var q = (clone.value || '').trim().toLowerCase();
        var rowNodes = list.querySelectorAll('[data-gpick]');
        for (var j = 0; j < rowNodes.length; j++) {
          var rn = rowNodes[j];
          var uu = findUser(rn.getAttribute('data-gpick'));
          if (!uu) continue;
          var nm = (uu.name || '').toLowerCase();
          rn.style.display = (!q || nm.indexOf(q) !== -1) ? '' : 'none';
        }
      });
    }
  }

  /* ============================================================
   * IMAGE UPLOAD
   * ============================================================
   * Preserved 1:1 from the original #groupImageFile change:
   *   • validate → compress (600px, q=0.82) → upload
   *   • update groupImageUrl + replace the preview node with
   *     an <img class="avatar av-56" id="groupImagePreview">
   * ============================================================ */
  async function handleGroupImagePicked(file) {
    if (!file) return false;

    /* Validate -------------------------------------------- */
    var err = null;
    try {
      if (typeof window.validateImage === 'function') {
        err = window.validateImage(file);
      }
    } catch (e) {}
    if (err) { safeToast(err, 'err'); return false; }

    try {
      safeToast(T('uploading'));

      /* Compress --------------------------------------- */
      var comp = file;
      try {
        if (typeof window.compressImage === 'function') {
          comp = await window.compressImage(file, 600, 0.82);
        }
      } catch (e) {}

      /* Upload ----------------------------------------- */
      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(comp, 'group.jpg');
      }
      if (!url) throw new Error(T('upload_failed'));

      window.groupImageUrl = url;

      /* Replace preview node --------------------------- */
      var preview = qs('#groupImagePreview');
      if (preview) {
        var img = document.createElement('img');
        img.className = 'avatar av-56';
        img.id = 'groupImagePreview';
        img.src = url;
        preview.parentNode && preview.parentNode.replaceChild(img, preview);
      }

      return true;
    } catch (err2) {
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
      return false;
    }
  }

  /* ============================================================
   * CREATE — the #btnCreateGroup click handler
   * ============================================================
   * Preserved 1:1 from the original:
   *   • require name + at least one selected member
   *   • members = { [me]: true, ...selected }
   *   • admins  = { [me]: true }
   *   • push into chats/ with type='group'
   *   • mirror into userChats/{each}/{id}
   *   • closeOverlay('ovGroup')
   *   • openChatById(id)
   * ============================================================ */
  async function createGroup() {
    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    var nameEl = qs('#groupName');
    var name = nameEl ? nameEl.value.trim() : '';

    if (!name) { safeToast(T('fill_all'), 'err'); return false; }
    if (!window.groupSelected.length) { safeToast(T('select_users'), 'err'); return false; }

    var btn = qs('#btnCreateGroup');
    if (btn) btn.disabled = true;

    try {
      /* Build member map ------------------------------- */
      var members = {};
      members[uid] = true;
      for (var i = 0; i < window.groupSelected.length; i++) {
        members[window.groupSelected[i]] = true;
      }
      var admins = {};
      admins[uid] = true;

      /* Create chat ------------------------------------ */
      var ref = fbDb.ref('chats').push();
      await ref.set({
        type: 'group',
        name: name,
        image: window.groupImageUrl || '',
        members: members,
        admins: admins,
        createdBy: uid,
        createdAt: timeNow(),
        lastAt: timeNow(),
        lastMessage: ''
      });

      /* Mirror into userChats for every member --------- */
      var updates = {};
      var memberIds = Object.keys(members);
      for (var j = 0; j < memberIds.length; j++) {
        updates['userChats/' + memberIds[j] + '/' + ref.key] = true;
      }
      await fbDb.ref().update(updates);

      /* Close + open ----------------------------------- */
      safeCall('closeOverlay', ['ovGroup']);
      safeCall('openChatById', [ref.key]);
      return true;
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  /* ============================================================
   * BIND — wire the group overlay's static controls once
   * ============================================================ */
  function bind() {
    var imgBtn = qs('#btnGroupImage');
    if (imgBtn && imgBtn.dataset.newGroupBound !== '1') {
      imgBtn.dataset.newGroupBound = '1';
      imgBtn.addEventListener('click', function () {
        var fi = qs('#groupImageFile');
        if (fi) fi.click();
      });
    }

    var imgFile = qs('#groupImageFile');
    if (imgFile && imgFile.dataset.newGroupBound !== '1') {
      imgFile.dataset.newGroupBound = '1';
      imgFile.addEventListener('change', function (e) {
        var f = e.target && e.target.files ? e.target.files[0] : null;
        if (e.target) e.target.value = '';
        if (f) handleGroupImagePicked(f);
      });
    }

    var createBtn = qs('#btnCreateGroup');
    if (createBtn && createBtn.dataset.newGroupBound !== '1') {
      createBtn.dataset.newGroupBound = '1';
      createBtn.addEventListener('click', createGroup);
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openGroupScreen = openGroupScreen;

  window.SaikoNewGroup = {
    open: openGroupScreen,
    renderUserList: renderUserList,
    create: createGroup,
    handleImagePicked: handleGroupImagePicked,
    bind: bind,
    getSelected: function () { return (window.groupSelected || []).slice(); },
    getImageUrl: function () { return window.groupImageUrl || ''; }
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 115 — new-group ready');
  } catch (e) {}

})();