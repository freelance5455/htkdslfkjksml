/* ============================================================
 * FEATURE:        Enter to Send Toggle
 * FEATURE NUMBER: 030
 * FILE:           js/prefs/030-enter-to-send.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Enter to send" toggle of the Chat settings page.
 *   Renders a single toggle button (#csEnter) that switches
 *   prefs.enterToSend on/off.
 *
 *   Behaviour (preserved 1:1 from original wireChatSettings):
 *
 *     #csEnter click:
 *       1. prefs.enterToSend = !prefs.enterToSend
 *       2. #csEnter.classList.toggle('active', prefs.enterToSend)
 *       3. #csEnter.textContent = t('enter_to_send')
 *                                + ': ' + t(enterToSend ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: Like feature 029, this label prefix uses t()
 *   — matching the original source (unlike feature 028 which
 *   used a hard-coded literal).
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original chatSettingsHTML() rendered THREE toggles:
 *       • #csRead   → read receipts   (feature 029)
 *       • #csEnter  → enter to send   (THIS feature, 030)
 *       • #csE2E    → E2E encryption  (feature 033)
 *     Plus one <select>:
 *       • #csAutoDel → auto-delete    (feature 032)
 *     This file owns ONLY the #csEnter toggle.
 *
 *   NOTE: Original did NOT call applyPrefs() here —
 *   enterToSend is a runtime flag read on-demand by the
 *   chat-input keydown handler (feature 147 area) to decide
 *   whether pressing Enter sends the message or inserts a
 *   newline:
 *     chatInput keydown:
 *       if (e.key === 'Enter' && !e.shiftKey && prefs.enterToSend)
 *         → preventDefault + btnSend.click()
 *   Not a CSS variable. Preserved exactly. An additive
 *   CustomEvent ('saiko:enter-to-send-changed') is emitted
 *   for any subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - chatSettingsHTML()  → the #csEnter element
 *   - wireChatSettings()  → #csEnter click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #csEnter
 *
 * FIREBASE PATHS:
 *   none directly — the keydown read happens in the chat-input
 *   module (part of feature 147 area / chat send flow).
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoEnterToSend = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (enterToSend: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.enterToSend : true;
  }

  /* ----------------------------------------------------------
   * Label builder — uses t('enter_to_send') as prefix,
   * matching the original source.
   * ---------------------------------------------------------- */
  function buildLabel(on) {
    return T('enter_to_send') + ': ' + T(on ? 'on' : 'off');
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #csEnter element inside
   * original chatSettingsHTML():
   *   - .toggle-row with a single #csEnter button whose class
   *     is .active when prefs.enterToSend is true, and whose
   *     label reads:
   *       "<Enter to send>: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or sibling controls. The settings coordinator
   *   renders the sec-title "Chat" once and stitches all
   *   chat-settings fragments together.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="csEnter">' +
          esc(buildLabel(on)) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.enterToSend = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * enterToSend is read on-demand by the chat-input keydown
     * handler. Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#csEnter');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = buildLabel(on);
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:enter-to-send-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #csEnter click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#csEnter', scope);
    if (!btn) return false;
    if (btn.dataset.enterToSendBound === '1') return true;
    btn.dataset.enterToSendBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.enterToSend = !prefs.enterToSend
       *   btn.classList.toggle('active', prefs.enterToSend)
       *   btn.textContent = t('enter_to_send') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#csEnter', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-enter-to-send-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoEnterToSend = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 030 — enter-to-send ready');
  } catch (e) {}

})();