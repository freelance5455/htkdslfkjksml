/* ============================================================
 * FEATURE:        Call Permission (Who can call me)
 * FEATURE NUMBER: 027
 * FILE:           js/prefs/027-call-permission.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Who can call me" <select> of the Privacy settings
 *   page. Renders a dropdown (#pvCallPerm) with two options:
 *
 *       • everyone  (default)
 *       • nobody
 *
 *   Behaviour — PRESERVED EXACTLY FROM ORIGINAL:
 *
 *     Unlike features 025 (online status) and 026 (last-seen),
 *     this control has NO dedicated change listener in the
 *     original source. It is a pure <select> whose value is
 *     only read when the privacy page's Save button (#pvSave)
 *     is clicked. At that time:
 *         prefs.callPerm = #pvCallPerm.value
 *         savePrefs()
 *         db.ref('users/' + myUid + '/privacy').set({ … })
 *
 *     The #pvSave button and the Firebase write are owned by
 *     the privacy-page coordinator (not this feature). This
 *     module only:
 *         1. renders the dropdown
 *         2. exposes getValue() / setValue() / readPref() so
 *            the coordinator can commit the value on Save
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original privacyHTML() rendered SIX elements:
 *       • #pvOnline        → feature 025
 *       • #pvLastSeen      → feature 026
 *       • #pvTyping        → feature 028
 *       • #pvCallPerm      → THIS feature (027)
 *       • #pvStoryPrivacy  → covered by feature 034
 *       • #pvSave          → coordinator-owned
 *
 *   NOTE: Original did NOT call applyPrefs() here — callPerm
 *   is a runtime flag read on-demand when an incoming call is
 *   received (see the call-signaling module: privacy check
 *   `if (cp === 'nobody') reject`). Not a CSS variable.
 *
 * ORIGINAL LOCATION (index.html):
 *   - privacyHTML()  → the <div class="field"> … <select
 *                       id="pvCallPerm">…</div> block
 *   - wirePrivacy()  → the #pvSave click handler reads
 *                       $('#pvCallPerm').value
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)  [only used by setValue]
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #pvCallPerm  (a <select class="input">)
 *
 * FIREBASE PATHS:
 *   none directly — the privacy coordinator writes
 *   users/{uid}/privacy on Save.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoCallPermission = {
 *     renderFragment,
 *     bind, unbind,
 *     getValue,        → reads current select value from DOM
 *     setValue,        → programmatic set (DOM + prefs + save)
 *     readPref,        → reads prefs.callPerm
 *     isValid          → validates 'everyone' | 'nobody'
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Allowed values — matches the two <option>s in the
   * original fragment.
   * ---------------------------------------------------------- */
  var ALLOWED = ['everyone', 'nobody'];
  var DEFAULT_VALUE = 'everyone';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Value validation
   * ---------------------------------------------------------- */
  function isValid(v) {
    return ALLOWED.indexOf(v) !== -1;
  }

  /* ----------------------------------------------------------
   * readPref — read the persisted value from prefs
   * Defaults to 'everyone' when prefs missing.
   * ---------------------------------------------------------- */
  function readPref() {
    var p = getPrefs();
    var v = p ? p.callPerm : null;
    return isValid(v) ? v : DEFAULT_VALUE;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #pvCallPerm block inside
   * original privacyHTML():
   *
   *   <div class="field">
   *     <label>Who can call me</label>
   *     <select class="input" id="pvCallPerm">
   *       <option value="everyone" selected>Everyone</option>
   *       <option value="nobody">Nobody</option>
   *     </select>
   *   </div>
   *
   *   NOTE: The sec-title "Privacy" is NOT included here — the
   *   privacy coordinator renders it once, and stitches all
   *   toggle fragments (025, 026, 027, 028) + Save button
   *   underneath.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var current = readPref();

    function optionHTML(value, labelKey) {
      var sel = (current === value) ? ' selected' : '';
      return '<option value="' + esc(value) + '"' + sel + '>' +
             esc(T(labelKey)) +
             '</option>';
    }

    return (
      '<div class="field">' +
        '<label>' + esc(T('call_permission')) + '</label>' +
        '<select class="input" id="pvCallPerm">' +
          optionHTML('everyone', 'everyone') +
          optionHTML('nobody',   'nobody') +
        '</select>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   *
   *   NO CHANGE LISTENER IS ADDED — matching the original
   *   source exactly. The privacy coordinator reads
   *   #pvCallPerm.value at #pvSave time.
   *
   *   bind() is a lightweight marker so the settings framework
   *   can track which fragment is currently wired. It returns
   *   true when the element exists and no exception was thrown.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var sel = qs('#pvCallPerm', scope);
    if (!sel) return false;
    if (sel.dataset.callPermBound === '1') return true;
    sel.dataset.callPermBound = '1';
    /* No listener — by design (see header comment). */
    return true;
  }

  function unbind(root) {
    var scope = root || document;
    var sel = qs('#pvCallPerm', scope);
    if (!sel) return;
    /* There is no listener to remove, but we clear the marker
     * so a subsequent bind() is a no-op cleanly. */
    delete sel.dataset.callPermBound;
  }

  /* ----------------------------------------------------------
   * getValue — read the currently-selected value from the DOM.
   * Falls back to the persisted pref, then to the default.
   * ---------------------------------------------------------- */
  function getValue() {
    var sel = qs('#pvCallPerm');
    if (!sel) return readPref();
    var v = sel.value;
    return isValid(v) ? v : readPref();
  }

  /* ----------------------------------------------------------
   * setValue — programmatic setter.
   *   • writes the value into prefs.callPerm
   *   • persists via savePrefs()
   *   • reflects the value in the DOM if the fragment is open
   *
   *   This is intended for programmatic callers (migration
   *   tools, admin flows, reset-to-default). It is NOT wired
   *   to any DOM event so the original click/save semantics
   *   remain unchanged.
   * ---------------------------------------------------------- */
  function setValue(v) {
    if (!isValid(v)) return false;

    /* 1) Update prefs + persist --------------------------- */
    var p = getPrefs();
    if (p) p.callPerm = v;
    callSavePrefs();

    /* 2) Reflect in the DOM if mounted -------------------- */
    var sel = qs('#pvCallPerm');
    if (sel) sel.value = v;

    /* 3) Notify subscribers ------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:call-permission-changed', {
        detail: { value: v }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoCallPermission = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getValue: getValue,
    setValue: setValue,
    readPref: readPref,
    isValid: isValid
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 027 — call-permission ready');
  } catch (e) {}

})();