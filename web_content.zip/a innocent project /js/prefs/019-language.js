/* ============================================================
 * FEATURE:        Language Selection (22 languages)
 * FEATURE NUMBER: 019
 * FILE:           js/prefs/019-language.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Language" settings page. Renders:
 *
 *     • A search bar (#langSearch) for filtering by name /
 *       native name.
 *     • A scrollable list (#langList) of every entry in
 *       SaikoI18n.LANGUAGES (22 rows). Each row shows the
 *       native name + (English name in muted text) and a
 *       check icon when it matches prefs.lang.
 *
 *   Behaviour (preserved 1:1 from original wireLanguage()):
 *
 *     Row click:
 *       1. prefs.lang = <code>            (via SaikoI18n.setLang)
 *       2. savePrefs()
 *       3. applyPrefs()                   (updates <html lang>)
 *       4. applyI18n()                    (re-translates DOM)
 *       5. Re-render #settingPageBody     (updates .sel state)
 *       6. buildNavIcons()                (rebuild dynamic labels)
 *       7. Re-render every page that shows translated text:
 *            renderProfilePage, renderNotifications,
 *            renderInbox, renderGames, renderFeed
 *       8. toast(t('saved'), 'ok')
 *
 *     Search input:
 *       Filters visible rows by matching the query against
 *       both the English name and native name
 *       (case-insensitive). Empty query restores all rows.
 *
 * ORIGINAL LOCATION (index.html):
 *   - languageHTML()  → the search + list fragment string
 *   - wireLanguage()  → search input + row click handlers
 *
 * DEPENDENCIES (loaded earlier):
 *   - SaikoI18n / I18N / LANGUAGES / t / applyI18n
 *                                       (js/nav/046-i18n.js)
 *   - window.prefs / savePrefs / applyPrefs
 *                                       (js/prefs/prefs-core.js)
 *   - esc(str)                          HTML-escape helper
 *   - toast(msg, kind)                  optional toast
 *   - buildNavIcons()                   optional nav refresher
 *   - renderProfilePage, renderNotifications, renderInbox,
 *     renderGames, renderFeed           optional page refresh
 *   - openSettingPage()                 optional settings router
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #langSearch, #langList, [data-lang]
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoLanguage = {
 *     renderFragment,
 *     bind, unbind,
 *     getCurrent,
 *     getLanguages,
 *     setLanguage
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ----------------------------------------------------------
   * i18n resolver — prefers window.t, falls back to key
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof window.t === 'function') return window.t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * i18n core accessors (defensive)
   * ---------------------------------------------------------- */
  function getLanguages() {
    try {
      if (typeof window.LANGUAGES !== 'undefined' && Array.isArray(window.LANGUAGES)) {
        return window.LANGUAGES.slice();
      }
    } catch (e) {}
    return [];
  }

  function getPrefsLang() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs && window.prefs.lang) {
        return window.prefs.lang;
      }
    } catch (e) {}
    return 'en';
  }

  function getCurrent() { return getPrefsLang(); }

  /* ----------------------------------------------------------
   * setLanguage — programmatic apply + persist + refresh
   * Used internally by row click and exposed for tests.
   * ---------------------------------------------------------- */
  function setLanguage(code) {
    if (!code) return false;

    /* 1) Update prefs ------------------------------------- */
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) {
        window.prefs.lang = code;
      }
    } catch (e) {}

    /* 2) Persist + apply ---------------------------------- */
    try { if (typeof window.savePrefs  === 'function') window.savePrefs();  } catch (e) {}
    try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {}

    /* 3) Re-translate static DOM -------------------------- */
    try { if (typeof window.applyI18n === 'function') window.applyI18n(); } catch (e) {}

    /* 4) Rebuild dynamic nav labels ----------------------- */
    try { if (typeof window.buildNavIcons === 'function') window.buildNavIcons(); } catch (e) {}

    /* 5) Refresh visible pages that show translated text -- */
    try { if (typeof window.renderProfilePage   === 'function') window.renderProfilePage();   } catch (e) {}
    try { if (typeof window.renderNotifications === 'function') window.renderNotifications(); } catch (e) {}
    try { if (typeof window.renderInbox         === 'function') window.renderInbox();         } catch (e) {}
    try { if (typeof window.renderGames         === 'function') window.renderGames();         } catch (e) {}
    try { if (typeof window.renderFeed          === 'function') window.renderFeed(false);     } catch (e) {}

    /* 6) Toast -------------------------------------------- */
    safeToast(T('saved'), 'ok');

    /* 7) Notify subscribers ------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:language-changed', {
        detail: { lang: code }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Preserves the exact structure of the original
   * languageHTML() output:
   *   - search bar (#langSearch)
   *   - list container (#langList)
   *   - rows with class lang-item (+ sel) and data-lang="code"
   * ---------------------------------------------------------- */
  function renderFragment() {
    var langs = getLanguages();
    var current = getCurrent();

    var rows = langs.map(function (l) {
      var isSel = (current === l.code);
      var selCls = isSel ? ' sel' : '';
      var iconHTML = isSel ? '<span class="ic">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="m20 6-11 11-5-5"/></svg></span>' : '';

      return '<div class="lang-item' + selCls + '" data-lang="' + esc(l.code) + '">' +
               '<span>' + esc(l.native) +
                 ' <span class="muted" style="font-size:.75rem">(' + esc(l.name) + ')</span>' +
               '</span>' +
               iconHTML +
             '</div>';
    }).join('');

    return (
      '<div class="searchbar">' +
        '<span class="ic">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
          'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
          '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>' +
        '</span>' +
        '<input type="search" id="langSearch" placeholder="' +
          esc(T('search_lang_ph')) +
        '">' +
      '</div>' +
      '<div id="langList">' + rows + '</div>'
    );
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires search filter + row clicks. Idempotent via dataset
   * guards so the settings coordinator can safely re-render.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* 1) Search input ------------------------------------- */
    var search = qs('#langSearch', scope);
    if (search && search.dataset.langSearchBound !== '1') {
      search.dataset.langSearchBound = '1';
      search.addEventListener('input', function () {
        var q = (search.value || '').trim().toLowerCase();
        qsa('#langList [data-lang]', scope).forEach(function (row) {
          var code = row.getAttribute('data-lang');
          var meta = getLanguages().filter(function (x) { return x.code === code; })[0];
          if (!meta) { row.style.display = 'none'; return; }
          var hay = (meta.name + ' ' + meta.native).toLowerCase();
          row.style.display = (!q || hay.indexOf(q) !== -1) ? '' : 'none';
        });
      });
      bound = true;
    }

    /* 2) Row clicks --------------------------------------- */
    qsa('#langList [data-lang]', scope).forEach(function (row) {
      if (row.dataset.langBound === '1') return;
      row.dataset.langBound = '1';

      row.addEventListener('click', function () {
        var code = row.getAttribute('data-lang');
        if (!code) return;

        /* Delegate to the shared setter so all side-effects
         * happen in one place. */
        setLanguage(code);

        /* Re-render this fragment so the .sel + checkmark
         * reflect the new selection, mirroring the original
         * wireLanguage() behavior of refreshing #settingPageBody. */
        var body = qs('#settingPageBody');
        if (body) {
          body.innerHTML = renderFragment();
          bind(body);
        }
      });

      bound = true;
    });

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip handlers
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;

    var search = qs('#langSearch', scope);
    if (search) {
      var cSearch = search.cloneNode(true);
      cSearch.removeAttribute('data-lang-search-bound');
      search.parentNode && search.parentNode.replaceChild(cSearch, search);
    }

    qsa('#langList [data-lang]', scope).forEach(function (row) {
      if (row.dataset.langBound !== '1') return;
      var clone = row.cloneNode(true);
      clone.removeAttribute('data-lang-bound');
      row.parentNode && row.parentNode.replaceChild(clone, row);
    });
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoLanguage = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getCurrent: getCurrent,
    getLanguages: getLanguages,
    setLanguage: setLanguage
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 019 — language ready');
  } catch (e) {}

})();