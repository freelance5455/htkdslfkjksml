/* ============================================================
 * PREFS CORE — Definitive Bulletproof v3
 * FILE:   js/prefs/prefs-core.js
 * CACHE-BUSTER: prefs-core-v3-2025
 * ============================================================ */

(function () {
  'use strict';

  /* ---------- VERSION MARKER (console me dikhna chahiye) ---------- */
  window.__SAIKO_PREFS_VERSION = 'v3-bulletproof';
  console.log('[prefs-core] loading', window.__SAIKO_PREFS_VERSION);

  var PREF_KEY = 'saiko_prefs_v7';

  var DEFAULT_PREFS = {
    accent: '#7c5cff',
    scale: 50,
    dark: true,
    lang: 'en',
    showOnline: true,
    showLastSeen: true,
    callPerm: 'everyone',
    showReadReceipts: true,
    enterToSend: true,
    autoDownload: true,
    notifSound: false,
    reducedMotion: false,
    dataSaver: false,
    performanceMode: false,
    e2eEnabled: true,
    typingIndicator: true,
    appLock: false,
    appLockPin: '',
    feedMode: 'latest',
    storyPrivacy: 'public',
    autoDeleteMsgs: 'off',
    profileTheme: 'default'
  };

  /* ---------- Load from localStorage ---------- */
  var stored = {};
  try {
    var raw = localStorage.getItem(PREF_KEY);
    if (raw) stored = JSON.parse(raw) || {};
  } catch (e) { stored = {}; }

  /* ---------- GUARANTEE window.prefs exists as a STABLE object ---------- */
  if (typeof window.prefs !== 'object' || window.prefs === null) {
    window.prefs = {};
  }
  Object.keys(DEFAULT_PREFS).forEach(function (k) {
    if (typeof window.prefs[k] === 'undefined') window.prefs[k] = DEFAULT_PREFS[k];
  });
  Object.keys(stored).forEach(function (k) {
    window.prefs[k] = stored[k];
  });
  window.PREF_KEY = PREF_KEY;
  window.SAIKO_DEFAULT_PREFS = DEFAULT_PREFS;

  /* ---------- hexA ---------- */
  function hexA(hex, a) {
    var h = String(hex || '#7c5cff').replace('#', '');
    var f = h.length === 3 ? h.split('').map(function (c) { return c + c; }).join('') : h;
    var n = parseInt(f, 16) || 0;
    var r = (n >> 16) & 255;
    var g = (n >> 8) & 255;
    var b = n & 255;
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }

  /* ---------- applyPrefs ---------- */
  function applyPrefs() {
    try {
      var root = document.documentElement;
      if (!root) return;
      var p = window.prefs || DEFAULT_PREFS;

      root.style.setProperty('--accent', p.accent || DEFAULT_PREFS.accent);
      root.style.setProperty('--accent-soft', hexA(p.accent || DEFAULT_PREFS.accent, 0.16));
      root.style.setProperty('--accent-line', hexA(p.accent || DEFAULT_PREFS.accent, 0.45));

      var rawScale = Number(p.scale);
      if (!isFinite(rawScale) || rawScale < 1) rawScale = 50;
      if (rawScale > 100) rawScale = 100;
      var scale = 0.55 + (rawScale / 100) * 0.9;
      root.style.setProperty('--scale', scale.toFixed(3));

      if (document.body) {
        document.body.classList.toggle('light', !p.dark);
        document.body.classList.toggle('reduced-motion', !!p.reducedMotion);
      }
      root.lang = p.lang || 'en';
    } catch (e) { console.warn('[prefs-core] applyPrefs error:', e); }
  }

  /* ---------- savePrefs ---------- */
  function savePrefs() {
    try { localStorage.setItem(PREF_KEY, JSON.stringify(window.prefs || {})); }
    catch (e) { console.warn('[prefs-core] savePrefs error:', e); }
  }

  /* ---------- loadPrefs ---------- */
  function loadPrefs() {
    try {
      var r = localStorage.getItem(PREF_KEY);
      if (r) {
        var j = JSON.parse(r) || {};
        Object.keys(j).forEach(function (k) { window.prefs[k] = j[k]; });
      }
    } catch (e) {}
    applyPrefs();
  }

  /* ---------- reset ---------- */
  function reset() {
    Object.keys(DEFAULT_PREFS).forEach(function (k) {
      window.prefs[k] = DEFAULT_PREFS[k];
    });
    savePrefs();
    applyPrefs();
  }

  /* ---------- set helper (used by addEventListener watchers) ---------- */
  function set(key, value) {
    if (!key) return false;
    window.prefs[key] = value;
    savePrefs();
    applyPrefs();
    try {
      window.dispatchEvent(new CustomEvent('saiko:prefs-changed', {
        detail: { key: key, value: value }
      }));
    } catch (e) {}
    return true;
  }

  /* ---------- Expose ---------- */
  window.hexA = hexA;
  window.applyPrefs = applyPrefs;
  window.savePrefs = savePrefs;
  window.loadPrefs = loadPrefs;

  window.SaikoPrefs = {
    VERSION: 'v3-bulletproof',
    PREF_KEY: PREF_KEY,
    defaults: DEFAULT_PREFS,
    load: loadPrefs,
    save: savePrefs,
    apply: applyPrefs,
    set: set,
    hexA: hexA,
    reset: reset,
    getAll: function () { return Object.assign({}, window.prefs); }
  };

  /* ---------- Initial apply ---------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      applyPrefs();
      console.log('[prefs-core] ✅ ready (DOMContentLoaded) —',
                  Object.keys(window.prefs).length, 'keys');
    }, { once: true });
  } else {
    applyPrefs();
    console.log('[prefs-core] ✅ ready (immediate) —',
                Object.keys(window.prefs).length, 'keys');
  }

})();