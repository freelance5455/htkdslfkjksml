/* ============================================================
 * FEATURE:        Feed Mode Tabs
 * FEATURE NUMBER: 035
 * FILE:           js/prefs/035-feed-mode.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Feed Mode" preference + tab-strip. This is the
 *   LAST prefs feature (016–035 group closes with this file).
 *
 *   Manages five feed-ordering modes:
 *       • foryou     — interest-weighted ranking
 *       • latest     — newest first (default)
 *       • popular    — most-liked first
 *       • trending   — likes + comments*2 score
 *       • interests  — tag-affinity ranking
 *
 *   Provides three responsibilities:
 *
 *     1. STATE
 *        Owns the current feed mode as a module-scoped value,
 *        initialised from prefs.feedMode (default 'latest').
 *        Exposes getMode() / setMode(mode) / readPref().
 *
 *     2. RENDER
 *        renderTabs() returns the exact tab-strip HTML that
 *        originally lived inside renderFeed() in the single-
 *        file build:
 *
 *          <div class="feed-tabs">
 *            <span class="chip [sel]" data-feedtab="foryou">…</span>
 *            <span class="chip [sel]" data-feedtab="latest">…</span>
 *            … five chips …
 *          </div>
 *
 *     3. BIND
 *        bindTabs(root, onChange) wires each .chip click to
 *        update the mode, refresh .sel state, and invoke the
 *        caller's onChange callback so the feed renderer can
 *        reset its own pagination and re-render.
 *
 *   ORIGINAL BEHAVIOR PRESERVED 1:1:
 *
 *     In the original single-file build, the feed module kept
 *     its own module-scoped `let feedMode = 'latest'` and the
 *     tab click handler did:
 *         feedMode = chip.dataset.feedtab;
 *         feedVisibleCount = FEED_BATCH;
 *         feedShellSig = '';
 *         renderFeed(false);
 *
 *     It did NOT persist the mode to prefs.feedMode — that
 *     prefs field existed in the defaults but was essentially
 *     dormant. To remain byte-for-byte behavior-compatible we
 *     DO NOT auto-persist on tab click. Persistence is
 *     available via setMode(mode, { persist: true }) for any
 *     caller that explicitly wants it (e.g. a future "remember
 *     my feed tab" preference).
 *
 *   The feed renderer module (feature 051) will use this file
 *   like so:
 *       container.innerHTML =
 *           SaikoFeedMode.renderTabs() + '…rest of feed html…';
 *       SaikoFeedMode.bindTabs(container, function () {
 *           // reset pagination, re-render feed
 *       });
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §15 FEED
 *       let feedMode = 'latest';
 *       ['foryou','latest','popular','trending','interests']
 *         .map(k => `<span class="chip …" data-feedtab="${k}">…`)
 *       page.querySelectorAll('[data-feedtab]').forEach(…
 *         feedMode = chip.dataset.feedtab; …)
 *   - Section §6 PREFS
 *       feedMode: 'latest'   (in the defaults object)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   .feed-tabs  (container)
 *   .chip[data-feedtab]
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoFeedMode = {
 *     MODES,
 *     getMode, setMode,
 *     readPref, isValid,
 *     renderTabs, bindTabs, unbindTabs
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  var MODES = ['foryou', 'latest', 'popular', 'trending', 'interests'];
  var DEFAULT_MODE = 'latest';

  /* ----------------------------------------------------------
   * Module-scoped current mode.
   * Initialised from prefs.feedMode when valid; otherwise the
   * original hard-coded default 'latest'.
   * ---------------------------------------------------------- */
  var _mode = null;

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Validation
   * ---------------------------------------------------------- */
  function isValid(mode) {
    return MODES.indexOf(mode) !== -1;
  }

  /* ----------------------------------------------------------
   * readPref — read the persisted value from prefs.
   * Defaults to 'latest' when prefs missing or invalid.
   * ---------------------------------------------------------- */
  function readPref() {
    var p = getPrefs();
    var v = p ? p.feedMode : null;
    return isValid(v) ? v : DEFAULT_MODE;
  }

  /* ----------------------------------------------------------
   * getMode — current in-memory mode.
   * Lazily initialised from prefs on first call.
   * ---------------------------------------------------------- */
  function getMode() {
    if (_mode == null) _mode = readPref();
    return _mode;
  }

  /* ----------------------------------------------------------
   * setMode — update the current mode.
   *
   *   opts.persist  (default false)
   *     When true, also writes the value into prefs.feedMode
   *     and calls savePrefs(). Default is false to match the
   *     original single-file behavior, which did not persist
   *     on tab click.
   *
   *   opts.silent   (default false)
   *     When true, skips the 'saiko:feed-mode-changed' event.
   *
   * Returns true on success, false on invalid mode.
   * ---------------------------------------------------------- */
  function setMode(mode, opts) {
    if (!isValid(mode)) return false;
    opts = opts || {};

    var prev = getMode();
    _mode = mode;

    if (opts.persist) {
      var p = getPrefs();
      if (p) p.feedMode = mode;
      callSavePrefs();
    }

    if (!opts.silent) {
      try {
        window.dispatchEvent(new CustomEvent('saiko:feed-mode-changed', {
          detail: { mode: mode, previous: prev }
        }));
      } catch (e) {}
    }

    return true;
  }

  /* ----------------------------------------------------------
   * RENDER TABS
   * Preserves 1:1 the tab-strip HTML that used to live inside
   * renderFeed() in the original single-file build:
   *
   *   <div class="feed-tabs">
   *     <span class="chip ${feedMode===k?'sel':''}"
   *           data-feedtab="${k}">${t(k)}</span>
   *     … one per MODES entry …
   *   </div>
   *
   * Note the mode-key is used directly as an i18n key (t('foryou'),
   * t('latest'), t('popular'), t('trending'), t('interests')) —
   * exactly as the original did.
   * ---------------------------------------------------------- */
  function renderTabs() {
    var current = getMode();

    var chips = MODES.map(function (k) {
      var sel = (current === k) ? ' sel' : '';
      return '<span class="chip' + sel + '" data-feedtab="' + esc(k) + '">' +
             esc(T(k)) +
             '</span>';
    }).join('');

    return '<div class="feed-tabs">' + chips + '</div>';
  }

  /* ----------------------------------------------------------
   * BIND TABS
   * Wires each [data-feedtab] chip inside `root`.
   *
   *   onChange — optional callback(mode, previous) invoked
   *              AFTER the mode state is updated and the
   *              .sel class has been refreshed. The feed
   *              module uses this to reset its pagination
   *              (feedVisibleCount = FEED_BATCH), invalidate
   *              its shell signature (feedShellSig = '') and
   *              call renderFeed(false).
   *
   * Idempotent per-chip via dataset guard.
   * ---------------------------------------------------------- */
  function bindTabs(root, onChange) {
    var scope = root || document;
    var chips = qsa('[data-feedtab]', scope);
    if (!chips.length) return false;

    var bound = false;

    chips.forEach(function (chip) {
      if (chip.dataset.feedModeBound === '1') return;
      chip.dataset.feedModeBound = '1';

      chip.addEventListener('click', function () {
        var mode = chip.getAttribute('data-feedtab');
        if (!isValid(mode)) return;

        var previous = getMode();
        if (mode === previous) {
          /* Still refresh .sel in case something drifted. */
          chips.forEach(function (x) {
            x.classList.toggle('sel', x.getAttribute('data-feedtab') === mode);
          });
          return;
        }

        /* 1) Update module state (no persist — matches original) */
        setMode(mode, { persist: false });

        /* 2) Refresh .sel visual state --------------------- */
        chips.forEach(function (x) {
          x.classList.toggle('sel', x.getAttribute('data-feedtab') === mode);
        });

        /* 3) Notify caller --------------------------------- */
        if (typeof onChange === 'function') {
          try { onChange(mode, previous); } catch (e) {}
        }
      });

      bound = true;
    });

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND TABS — clone-and-swap to strip handlers
   * ---------------------------------------------------------- */
  function unbindTabs(root) {
    var scope = root || document;
    qsa('[data-feedtab]', scope).forEach(function (chip) {
      if (chip.dataset.feedModeBound !== '1') return;
      var clone = chip.cloneNode(true);
      clone.removeAttribute('data-feed-mode-bound');
      chip.parentNode && chip.parentNode.replaceChild(clone, chip);
    });
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoFeedMode = {
    MODES: MODES.slice(),
    getMode: getMode,
    setMode: setMode,
    readPref: readPref,
    isValid: isValid,
    renderTabs: renderTabs,
    bindTabs: bindTabs,
    unbindTabs: unbindTabs
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 035 — feed-mode ready');
  } catch (e) {}

})();