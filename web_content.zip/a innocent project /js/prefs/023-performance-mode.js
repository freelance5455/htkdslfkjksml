/* ============================================================
 * FEATURE:        Performance Mode
 * FEATURE NUMBER: 023
 * FILE:           js/prefs/023-performance-mode.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Performance Mode" settings page. Renders a single
 *   toggle button (#pfTog) that switches prefs.performanceMode
 *   on/off.
 *
 *   Behaviour (preserved 1:1 from original wirePerf):
 *
 *     #pfTog click:
 *       1. prefs.performanceMode = !prefs.performanceMode
 *       2. #pfTog.classList.toggle('active', prefs.performanceMode)
 *       3. #pfTog.textContent = t('performance_mode') + ': ' +
 *                               t(prefs.performanceMode ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: Original did NOT call applyPrefs() here — same reason
 *   as feature 022 (data saver): performanceMode is a runtime
 *   hint read on-demand by the feed/reel renderers, not a CSS
 *   variable. Preserved exactly. An additive CustomEvent
 *   ('saiko:performance-mode-changed') is emitted for any
 *   subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - perfHTML()  → the fragment string
 *   - wirePerf()  → #pfTog click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #pfTog
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoPerformanceMode = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to false if prefs missing,
   * matching the original default.
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.performanceMode : false;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original perfHTML():
   *   - sec-title "Performance Mode"
   *   - .toggle-row with a single #pfTog button whose class
   *     is .active when prefs.performanceMode is true, and
   *     whose label reads "Performance Mode: ON|OFF".
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="sec-title">' + esc(T('performance_mode')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="pfTog">' +
          esc(T('performance_mode')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.performanceMode = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * performanceMode is read on-demand by the renderers.
     * Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#pfTog');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('performance_mode') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:performance-mode-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #pfTog click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#pfTog', scope);
    if (!btn) return false;
    if (btn.dataset.perfModeBound === '1') return true;
    btn.dataset.perfModeBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.performanceMode = !prefs.performanceMode
       *   btn.classList.toggle('active', prefs.performanceMode)
       *   btn.textContent = t('performance_mode') + ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#pfTog', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-perf-mode-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoPerformanceMode = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 023 — performance-mode ready');
  } catch (e) {}

})();