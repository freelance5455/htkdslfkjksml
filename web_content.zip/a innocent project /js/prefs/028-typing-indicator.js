/* ============================================================
 * FEATURE:        Typing Indicator
 * FEATURE NUMBER: 028
 * FILE:           js/prefs/028-typing-indicator.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Typing indicator" toggle of the Privacy settings
 *   page. Renders a single toggle button (#pvTyping) that
 *   switches prefs.typingIndicator on/off.
 *
 *   Behaviour (preserved 1:1 from original wirePrivacy):
 *
 *     #pvTyping click:
 *       1. prefs.typingIndicator = !prefs.typingIndicator
 *       2. #pvTyping.classList.toggle('active', prefs.typingIndicator)
 *       3. #pvTyping.textContent =
 *            'Typing indicator: ' + t(typingIndicator ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: The original label was HARD-CODED as the literal
 *   English string 'Typing indicator' — it was NOT passed
 *   through t(). To preserve byte-for-byte behaviour we do
 *   the same: literal 'Typing indicator: ' + t('on'/'off').
 *   (In contrast, features 025/026 used t() for the whole
 *   label prefix.)
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original privacyHTML() rendered SIX elements.
 *     This feature owns ONLY the #pvTyping toggle. Sibling
 *     toggles (#pvOnline, #pvLastSeen, #pvCallPerm) and the
 *     #pvSave button are owned by other feature files and
 *     the settings coordinator respectively.
 *
 *   NOTE: Original did NOT call applyPrefs() here —
 *   typingIndicator is a runtime flag read on-demand by the
 *   chat-input handler in feature 143 (`js/chat/143-typing-indicator.js`)
 *   before broadcasting the `chats/{id}/typing/{uid}` write.
 *   Not a CSS variable. Preserved exactly. An additive
 *   CustomEvent ('saiko:typing-indicator-changed') is emitted
 *   for any subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - privacyHTML()  → the #pvTyping element
 *   - wirePrivacy()  → #pvTyping click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #pvTyping
 *
 * FIREBASE PATHS:
 *   none directly — the privacy coordinator writes
 *   users/{uid}/privacy when the Save button is pressed.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoTypingIndicator = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (typingIndicator: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.typingIndicator : true;
  }

  /* ----------------------------------------------------------
   * Label builder — mirrors the original's hard-coded prefix
   * 'Typing indicator' (NOT passed through t()), plus the
   * translated on/off suffix.
   * ---------------------------------------------------------- */
  function buildLabel(on) {
    return 'Typing indicator: ' + T(on ? 'on' : 'off');
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #pvTyping element inside
   * original privacyHTML():
   *   - .toggle-row with a single #pvTyping button whose class
   *     is .active when prefs.typingIndicator is true, and
   *     whose label reads:
   *       "Typing indicator: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or sibling controls. The privacy coordinator
   *   renders the sec-title "Privacy" once and stitches all
   *   toggle fragments (025, 026, 027, 028) plus the save
   *   button underneath it.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="pvTyping">' +
          esc(buildLabel(on)) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.typingIndicator = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * typingIndicator is read on-demand by the chat-input
     * handler before broadcasting the typing write.
     * Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#pvTyping');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = buildLabel(on);
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:typing-indicator-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #pvTyping click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#pvTyping', scope);
    if (!btn) return false;
    if (btn.dataset.typingIndicatorBound === '1') return true;
    btn.dataset.typingIndicatorBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.typingIndicator = !prefs.typingIndicator
       *   btn.classList.toggle('active', prefs.typingIndicator)
       *   btn.textContent = 'Typing indicator: ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#pvTyping', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-typing-indicator-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoTypingIndicator = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 028 — typing-indicator ready');
  } catch (e) {}

})();