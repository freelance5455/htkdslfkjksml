/* ============================================================
 * FEATURE:        Notification Sound
 * FEATURE NUMBER: 024
 * FILE:           js/prefs/024-notif-sound.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Notification Sound" toggle of the Notification
 *   settings page. Renders a single toggle button (#nsSound)
 *   that switches prefs.notifSound on/off.
 *
 *   Behaviour (preserved 1:1 from original wireNotifSettings):
 *
 *     #nsSound click:
 *       1. prefs.notifSound = !prefs.notifSound
 *       2. #nsSound.classList.toggle('active', prefs.notifSound)
 *       3. #nsSound.textContent = t('notification_settings') +
 *                                 ': ' + t(prefs.notifSound ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original notifSettingsHTML() rendered TWO elements:
 *       • #nsSound   → the sound toggle     (this feature, 024)
 *       • #nsMarkAll → the mark-all-read    (feature 103)
 *     Per the modular rules ("unnecessarily merge mat karo"),
 *     this feature owns ONLY the sound toggle. Feature 103
 *     renders its own mark-all-read fragment. The settings
 *     coordinator stitches both fragments into the final
 *     notification_settings page.
 *
 *   NOTE: Original did NOT call applyPrefs() here — same
 *   reason as features 022 and 023: notifSound is a runtime
 *   hint read on-demand when a push notification arrives, not
 *   a CSS variable. Preserved exactly. An additive CustomEvent
 *   ('saiko:notif-sound-changed') is emitted for any subscriber
 *   that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - notifSettingsHTML()  → the #nsSound element
 *   - wireNotifSettings()  → #nsSound click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #nsSound
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoNotifSound = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to false if prefs missing,
   * matching the original default.
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.notifSound : false;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #nsSound element inside
   * original notifSettingsHTML():
   *   - sec-title "Notifications"
   *   - .toggle-row with a single #nsSound button whose class
   *     is .active when prefs.notifSound is true, and whose
   *     label reads:
   *       "<notification_settings>: <ON|OFF>"
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="sec-title">' + esc(T('notification_settings')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="nsSound">' +
          esc(T('notification_settings')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.notifSound = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * notifSound is read on-demand when a notification arrives.
     * Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#nsSound');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('notification_settings') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:notif-sound-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #nsSound click. Idempotent via dataset guard.
   * NOTE: The original wireNotifSettings() also wired the
   * #nsMarkAll button — that button now belongs to feature
   * 103 and is wired by its own module.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#nsSound', scope);
    if (!btn) return false;
    if (btn.dataset.notifSoundBound === '1') return true;
    btn.dataset.notifSoundBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.notifSound = !prefs.notifSound
       *   btn.classList.toggle('active', prefs.notifSound)
       *   btn.textContent = t('notification_settings') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#nsSound', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-notif-sound-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoNotifSound = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 024 — notif-sound ready');
  } catch (e) {}

})();