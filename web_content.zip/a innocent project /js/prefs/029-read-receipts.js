/* ============================================================
 * FEATURE:        Show Read Receipts Toggle
 * FEATURE NUMBER: 029
 * FILE:           js/prefs/029-read-receipts.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Show read receipts" toggle of the Chat settings page.
 *   Renders a single toggle button (#csRead) that switches
 *   prefs.showReadReceipts on/off.
 *
 *   Behaviour (preserved 1:1 from original wireChatSettings):
 *
 *     #csRead click:
 *       1. prefs.showReadReceipts = !prefs.showReadReceipts
 *       2. #csRead.classList.toggle('active', prefs.showReadReceipts)
 *       3. #csRead.textContent = t('show_read_receipts')
 *                                + ': ' + t(showReadReceipts ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: Unlike feature 028 (typing indicator), this label
 *   prefix DOES go through t() — matching the original source.
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original chatSettingsHTML() rendered THREE toggles:
 *       • #csRead   → read receipts   (THIS feature, 029)
 *       • #csEnter  → enter to send   (feature 030)
 *       • #csE2E    → E2E encryption  (feature 033)
 *     Plus one <select>:
 *       • #csAutoDel → auto-delete    (feature 032)
 *     Per modular rules, this file owns ONLY the #csRead
 *     toggle. Sibling controls are owned by their own feature
 *     files and stitched together by the settings coordinator.
 *
 *   NOTE: Original did NOT call applyPrefs() here —
 *   showReadReceipts is a runtime flag read on-demand by the
 *   message-render code (feature 128) before writing the
 *   `messages/{chatId}/{mid}/readBy/{uid}` node. Not a CSS
 *   variable. Preserved exactly. An additive CustomEvent
 *   ('saiko:read-receipts-changed') is emitted for any
 *   subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - chatSettingsHTML()  → the #csRead element
 *   - wireChatSettings()  → #csRead click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #csRead
 *
 * FIREBASE PATHS:
 *   none directly — the readBy write happens in feature 128
 *   (message-render) when a new message arrives and
 *   prefs.showReadReceipts is true.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoReadReceipts = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (showReadReceipts: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.showReadReceipts : true;
  }

  /* ----------------------------------------------------------
   * Label builder — uses t('show_read_receipts') as prefix,
   * matching the original source (unlike feature 028 which
   * used a hard-coded literal).
   * ---------------------------------------------------------- */
  function buildLabel(on) {
    return T('show_read_receipts') + ': ' + T(on ? 'on' : 'off');
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #csRead element inside
   * original chatSettingsHTML():
   *   - .toggle-row with a single #csRead button whose class
   *     is .active when prefs.showReadReceipts is true, and
   *     whose label reads:
   *       "<Show read receipts>: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or sibling controls (#csEnter, #csE2E,
   *   #csAutoDel). The settings coordinator renders the
   *   sec-title "Chat" once and stitches all chat-settings
   *   fragments together.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="csRead">' +
          esc(buildLabel(on)) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.showReadReceipts = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * showReadReceipts is read on-demand by the message-render
     * code before writing readBy. Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#csRead');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = buildLabel(on);
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:read-receipts-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #csRead click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#csRead', scope);
    if (!btn) return false;
    if (btn.dataset.readReceiptsBound === '1') return true;
    btn.dataset.readReceiptsBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.showReadReceipts = !prefs.showReadReceipts
       *   btn.classList.toggle('active', prefs.showReadReceipts)
       *   btn.textContent = t('show_read_receipts') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#csRead', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-read-receipts-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoReadReceipts = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 029 — read-receipts ready');
  } catch (e) {}

})();