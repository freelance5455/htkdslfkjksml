/* ============================================================
 * FEATURE:        Auto-Delete Messages Select
 * FEATURE NUMBER: 032
 * FILE:           js/prefs/032-auto-delete-messages.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Auto-delete messages" <select> of the Chat settings
 *   page. Renders a dropdown (#csAutoDel) with FOUR options:
 *
 *       • off          (default)
 *       • 86400000     (24 hours)
 *       • 604800000    (7 days)
 *       • 7776000000   (90 days)
 *
 *   Behaviour (preserved 1:1 from original wireChatSettings):
 *
 *     #csAutoDel 'change' event:
 *       1. prefs.autoDeleteMsgs = e.target.value
 *       2. savePrefs()
 *       3. toast(t('saved'), 'ok')
 *
 *   NOTE: Unlike feature 027 (call permission — no listener,
 *   read only on Save), this control DOES have a 'change'
 *   listener in the original source and persists IMMEDIATELY
 *   when the dropdown value changes. That behaviour is
 *   preserved byte-for-byte.
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original chatSettingsHTML() rendered THREE toggles
 *     and one <select>:
 *       • #csRead      → read receipts   (feature 029)
 *       • #csEnter     → enter to send   (feature 030)
 *       • #csE2E       → E2E encryption  (feature 033)
 *       • #csAutoDel   → THIS feature (032)
 *     This file owns ONLY the #csAutoDel <select>.
 *
 *   NOTE: Original did NOT call applyPrefs() here —
 *   autoDeleteMsgs is a runtime flag read on-demand by the
 *   send-message pipeline before scheduling a message expiry
 *   (feature 128 area). Not a CSS variable. Preserved exactly.
 *   An additive CustomEvent ('saiko:auto-delete-changed') is
 *   emitted for any subscriber that wants to react in real
 *   time (e.g. to display a warning banner in the chat).
 *
 * ORIGINAL LOCATION (index.html):
 *   - chatSettingsHTML()  → the #csAutoDel <select> block
 *   - wireChatSettings()  → #csAutoDel 'change' listener
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *   - toast(msg, kind)  optional toast notifier
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #csAutoDel  (a <select class="input">)
 *
 * FIREBASE PATHS:
 *   none directly — auto-delete is enforced at message-send
 *   time by the chat pipeline (feature 128 area).
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoAutoDeleteMessages = {
 *     renderFragment,
 *     bind, unbind,
 *     getValue,        → reads current select value from DOM
 *     setValue,        → programmatic set (DOM + prefs + save)
 *     readPref,        → reads prefs.autoDeleteMsgs
 *     isValid,         → validates against ALLOWED values
 *     getMilliseconds, → converts current value to ms (0 = off)
 *     getOptions       → returns array of { value, labelKey }
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Allowed values — matches the four <option>s in the
   * original fragment. Order preserved.
   * ---------------------------------------------------------- */
  var OPTIONS = [
    { value: 'off',        labelKey: 'auto_delete_off' },
    { value: '86400000',   labelKey: 'auto_delete_24h' },
    { value: '604800000',  labelKey: 'auto_delete_7d'  },
    { value: '7776000000', labelKey: 'auto_delete_90d' }
  ];

  var ALLOWED_VALUES = OPTIONS.map(function (o) { return o.value; });
  var DEFAULT_VALUE = 'off';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Value validation
   * ---------------------------------------------------------- */
  function isValid(v) {
    return ALLOWED_VALUES.indexOf(v) !== -1;
  }

  /* ----------------------------------------------------------
   * readPref — read the persisted value from prefs.
   * Defaults to 'off' when prefs missing or invalid.
   * ---------------------------------------------------------- */
  function readPref() {
    var p = getPrefs();
    var v = p ? p.autoDeleteMsgs : null;
    return isValid(v) ? v : DEFAULT_VALUE;
  }

  /* ----------------------------------------------------------
   * getMilliseconds — convert current value to a number.
   * 'off' → 0, otherwise the value itself (already ms).
   * Useful for the chat pipeline deciding whether to schedule
   * an expiry timestamp.
   * ---------------------------------------------------------- */
  function getMilliseconds(v) {
    var val = v != null ? v : getValue();
    if (!isValid(val) || val === 'off') return 0;
    var n = Number(val);
    return isFinite(n) ? n : 0;
  }

  /* ----------------------------------------------------------
   * getOptions — expose the option list
   * ---------------------------------------------------------- */
  function getOptions() {
    return OPTIONS.map(function (o) {
      return { value: o.value, labelKey: o.labelKey };
    });
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #csAutoDel block inside
   * original chatSettingsHTML():
   *
   *   <div class="field">
   *     <label>Auto-delete messages</label>
   *     <select class="input" id="csAutoDel">
   *       <option value="off">Off</option>
   *       <option value="86400000">24 hours</option>
   *       <option value="604800000">7 days</option>
   *       <option value="7776000000">90 days</option>
   *     </select>
   *   </div>
   *
   *   NOTE: The sec-title "Chat" is NOT included here — the
   *   settings coordinator renders it once and stitches all
   *   chat-settings fragments (029, 030, 032, 033) under it.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var current = readPref();

    var optionsHTML = OPTIONS.map(function (o) {
      var sel = (current === o.value) ? ' selected' : '';
      return '<option value="' + esc(o.value) + '"' + sel + '>' +
             esc(T(o.labelKey)) +
             '</option>';
    }).join('');

    return (
      '<div class="field">' +
        '<label>' + esc(T('auto_delete')) + '</label>' +
        '<select class="input" id="csAutoDel">' +
          optionsHTML +
        '</select>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * BIND — wires the 'change' listener.
   *
   * Behaviour preserved 1:1 from the original:
   *   on change:
   *     prefs.autoDeleteMsgs = e.target.value
   *     savePrefs()
   *     toast(t('saved'), 'ok')
   *
   * Note: this is a LIVE write — the value is persisted the
   * moment the user picks a different option, no explicit
   * Save button needed. This differs from feature 027
   * (call permission) which is only read at Save time.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var sel = qs('#csAutoDel', scope);
    if (!sel) return false;
    if (sel.dataset.autoDeleteBound === '1') return true;
    sel.dataset.autoDeleteBound = '1';

    sel.addEventListener('change', function (e) {
      var v = e && e.target ? e.target.value : sel.value;
      if (!isValid(v)) v = DEFAULT_VALUE;

      /* 1) Persist ---------------------------------------- */
      var p = getPrefs();
      if (p) p.autoDeleteMsgs = v;
      callSavePrefs();

      /* 2) Toast ------------------------------------------ */
      safeToast(T('saved'), 'ok');

      /* 3) Notify subscribers ----------------------------- */
      try {
        window.dispatchEvent(new CustomEvent('saiko:auto-delete-changed', {
          detail: { value: v, milliseconds: getMilliseconds(v) }
        }));
      } catch (e2) {}
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the listener
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var sel = qs('#csAutoDel', scope);
    if (!sel) return;
    var clone = sel.cloneNode(true);
    clone.removeAttribute('data-auto-delete-bound');
    sel.parentNode && sel.parentNode.replaceChild(clone, sel);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* getValue — read the current select value from the DOM.
   * Falls back to persisted pref, then to the default. */
  function getValue() {
    var sel = qs('#csAutoDel');
    if (!sel) return readPref();
    var v = sel.value;
    return isValid(v) ? v : readPref();
  }

  /* setValue — programmatic setter.
   *   • writes the value into prefs.autoDeleteMsgs
   *   • persists via savePrefs()
   *   • reflects the value in the DOM if the fragment is open
   *   • emits the same CustomEvent as a user-driven change
   * NOT wired to any DOM event so the original user-driven
   * semantics remain unchanged. */
  function setValue(v) {
    if (!isValid(v)) return false;

    /* 1) Update prefs + persist --------------------------- */
    var p = getPrefs();
    if (p) p.autoDeleteMsgs = v;
    callSavePrefs();

    /* 2) Reflect in the DOM if mounted -------------------- */
    var sel = qs('#csAutoDel');
    if (sel) sel.value = v;

    /* 3) Notify subscribers ------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:auto-delete-changed', {
        detail: { value: v, milliseconds: getMilliseconds(v) }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoAutoDeleteMessages = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getValue: getValue,
    setValue: setValue,
    readPref: readPref,
    isValid: isValid,
    getMilliseconds: getMilliseconds,
    getOptions: getOptions
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 032 — auto-delete-messages ready');
  } catch (e) {}

})();