/* ============================================================
 * FEATURE:        Data Saver Mode
 * FEATURE NUMBER: 022
 * FILE:           js/prefs/022-data-saver.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Data Saver" settings page. Renders a single toggle
 *   button (#dsTog) that switches prefs.dataSaver on/off.
 *
 *   Behaviour (preserved 1:1 from original wireDataSaver):
 *
 *     #dsTog click:
 *       1. prefs.dataSaver = !prefs.dataSaver
 *       2. #dsTog.classList.toggle('active', prefs.dataSaver)
 *       3. #dsTog.textContent = t('data_saver') + ': ' +
 *                               t(prefs.dataSaver ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: The original code did NOT call applyPrefs() here
 *   because dataSaver is a runtime hint rather than a CSS
 *   variable — it is read on-demand by media-handling code
 *   (e.g. auto-download, image compression level). We
 *   preserve that exact behaviour. Subscribers can listen
 *   for the 'saiko:data-saver-changed' event that we emit
 *   (additive, does not change behaviour).
 *
 * ORIGINAL LOCATION (index.html):
 *   - dataSaverHTML()  → the fragment string
 *   - wireDataSaver()  → #dsTog click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #dsTog
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoDataSaver = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to false if prefs missing,
   * matching the original default.
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.dataSaver : false;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original dataSaverHTML():
   *   - sec-title "Data Saver"
   *   - .toggle-row with a single #dsTog button whose class
   *     is .active when prefs.dataSaver is true, and whose
   *     label reads "Data Saver: ON|OFF".
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="sec-title">' + esc(T('data_saver')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="dsTog">' +
          esc(T('data_saver')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.dataSaver = !!on;

    /* Original DID NOT call applyPrefs() for this toggle —
     * dataSaver is read on-demand by media handlers, not
     * by CSS variables. Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#dsTog');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('data_saver') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:data-saver-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #dsTog click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#dsTog', scope);
    if (!btn) return false;
    if (btn.dataset.dataSaverBound === '1') return true;
    btn.dataset.dataSaverBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.dataSaver = !prefs.dataSaver
       *   btn.classList.toggle('active', prefs.dataSaver)
       *   btn.textContent = t('data_saver') + ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#dsTog', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-data-saver-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoDataSaver = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 022 — data-saver ready');
  } catch (e) {}

})();