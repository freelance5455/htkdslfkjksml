/* ============================================================
 * FEATURE:        Presence Privacy (Online Status Visibility)
 * FEATURE NUMBER: 025
 * FILE:           js/prefs/025-presence-privacy.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Online status visibility" toggle of the Privacy
 *   settings page. Renders a single toggle button (#pvOnline)
 *   that switches prefs.showOnline on/off.
 *
 *   Behaviour (preserved 1:1 from original wirePrivacy):
 *
 *     #pvOnline click:
 *       1. prefs.showOnline = !prefs.showOnline
 *       2. #pvOnline.classList.toggle('active', prefs.showOnline)
 *       3. #pvOnline.textContent = t('online_status_visibility')
 *                                  + ': ' + t(showOnline ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original privacyHTML() rendered SIX elements:
 *       • #pvOnline        → online status   (this feature, 025)
 *       • #pvLastSeen      → last seen       (feature 026)
 *       • #pvTyping        → typing          (feature 028)
 *       • #pvCallPerm      → call perm       (feature 027)
 *       • #pvStoryPrivacy  → story privacy   (feature 034 overlap)
 *       • #pvSave          → save to FB      (coordinator-owned)
 *
 *     Per modular rules ("unnecessarily merge mat karo"), this
 *     feature owns ONLY the #pvOnline toggle. The settings
 *     coordinator for the privacy page will stitch all sibling
 *     fragments together and provide the #pvSave button that
 *     pushes the callPerm + storyPrivacy values to Firebase.
 *
 *   NOTE: Original did NOT call applyPrefs() here — showOnline
 *   is a runtime flag read on-demand by presence code (see
 *   js/core/presence.js) and chat-header renderer, not a CSS
 *   variable. Preserved exactly. An additive CustomEvent
 *   ('saiko:presence-privacy-changed') is emitted for any
 *   subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - privacyHTML()  → the #pvOnline element
 *   - wirePrivacy()  → #pvOnline click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #pvOnline
 *
 * FIREBASE PATHS:
 *   none directly — the privacy coordinator (settings page)
 *   writes users/{uid}/privacy when the Save button is pressed.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoPresencePrivacy = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (showOnline: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.showOnline : true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #pvOnline element inside
   * original privacyHTML():
   *   - .toggle-row with a single #pvOnline button whose class
   *     is .active when prefs.showOnline is true, and whose
   *     label reads:
   *       "<online_status_visibility>: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or the sibling controls. The privacy
   *   coordinator renders the sec-title "Privacy" once and
   *   stitches all four toggle fragments (025, 026, 027, 028)
   *   plus the save button underneath it.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="pvOnline">' +
          esc(T('online_status_visibility')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.showOnline = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * showOnline is read on-demand by presence + chat-header.
     * Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#pvOnline');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('online_status_visibility') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:presence-privacy-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #pvOnline click. Idempotent via dataset guard.
   * NOTE: The original wirePrivacy() also wired #pvLastSeen,
   * #pvTyping, #pvSave — those belong to sibling feature files
   * (026, 028) and the coordinator respectively.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#pvOnline', scope);
    if (!btn) return false;
    if (btn.dataset.presencePrivacyBound === '1') return true;
    btn.dataset.presencePrivacyBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.showOnline = !prefs.showOnline
       *   btn.classList.toggle('active', prefs.showOnline)
       *   btn.textContent = t('online_status_visibility') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#pvOnline', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-presence-privacy-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoPresencePrivacy = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 025 — presence-privacy ready');
  } catch (e) {}

})();