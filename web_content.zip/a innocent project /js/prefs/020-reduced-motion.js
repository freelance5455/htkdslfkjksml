/* ============================================================
 * FEATURE:        Reduced Motion (Accessibility)
 * FEATURE NUMBER: 020
 * FILE:           js/prefs/020-reduced-motion.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Accessibility → Reduce motion" settings page.
 *   Renders a single toggle button (#acMotion) that switches
 *   prefs.reducedMotion on/off.
 *
 *   Behaviour (preserved 1:1 from original wireAccessibility):
 *
 *     #acMotion click:
 *       1. prefs.reducedMotion = !prefs.reducedMotion
 *       2. #acMotion.classList.toggle('active', prefs.reducedMotion)
 *       3. #acMotion.textContent = t('reduced_motion') + ': ' +
 *                                  t(prefs.reducedMotion ? 'on' : 'off')
 *       4. applyPrefs()   → toggles body.reduced-motion class
 *       5. savePrefs()
 *
 *   The visual effect: `applyPrefs()` (in prefs-core) toggles
 *   `body.reduced-motion`, whose CSS rule (see base.css) collapses
 *   all animation-duration and transition-duration to 0.01 ms.
 *
 * ORIGINAL LOCATION (index.html):
 *   - accessibilityHTML()  → the fragment string
 *   - wireAccessibility()  → #acMotion click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - applyPrefs()      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #acMotion
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoReducedMotion = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callApplyPrefs() {
    try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {}
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to false (motion enabled) if
   * prefs missing, matching the original default.
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.reducedMotion : false;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original accessibilityHTML():
   *   - sec-title "Accessibility"
   *   - .toggle-row with a single #acMotion button whose
   *     class is .active when prefs.reducedMotion is true,
   *     and whose label reads:
   *       "<Reduce motion>: <ON|OFF>"
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="sec-title">' + esc(T('accessibility')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="acMotion">' +
          esc(T('reduced_motion')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, and update the
   * on-page button label/class if mounted.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.reducedMotion = !!on;

    callApplyPrefs();
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#acMotion');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('reduced_motion') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:reduced-motion-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #acMotion click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#acMotion', scope);
    if (!btn) return false;
    if (btn.dataset.reducedMotionBound === '1') return true;
    btn.dataset.reducedMotionBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.reducedMotion = !prefs.reducedMotion
       *   btn.classList.toggle('active', prefs.reducedMotion)
       *   btn.textContent = t('reduced_motion') + ': ' + t(on/off)
       *   applyPrefs()
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#acMotion', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-reduced-motion-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoReducedMotion = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 020 — reduced-motion ready');
  } catch (e) {}

})();