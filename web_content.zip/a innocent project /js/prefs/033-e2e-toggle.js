/* ============================================================
 * FEATURE:        E2E Encryption Toggle
 * FEATURE NUMBER: 033
 * FILE:           js/prefs/033-e2e-toggle.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "End-to-end encrypted" toggle of the Chat settings
 *   page. Renders a single toggle button (#csE2E) that
 *   switches prefs.e2eEnabled on/off.
 *
 *   Behaviour (preserved 1:1 from original wireChatSettings):
 *
 *     #csE2E click:
 *       1. prefs.e2eEnabled = !prefs.e2eEnabled
 *       2. #csE2E.classList.toggle('active', prefs.e2eEnabled)
 *       3. #csE2E.textContent = t('e2e_encrypted')
 *                              + ': ' + t(e2eEnabled ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE: Label prefix goes through t() — same as features
 *   029 and 030. Matches the original source exactly.
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original chatSettingsHTML() rendered THREE toggles
 *     and one <select>. This file owns ONLY the #csE2E
 *     toggle. This is the LAST fragment of the Chat settings
 *     page — features 029, 030, 032 and this one (033) fully
 *     cover the original chatSettingsHTML() + wireChatSettings().
 *
 *   NOTE: Original did NOT call applyPrefs() here —
 *   e2eEnabled is a runtime flag read on-demand by the
 *   admin-support chat setup (setupE2EForAdminChat) and by
 *   the message-send pipeline before deciding whether to
 *   encrypt the payload (feature 128/129 area). Not a CSS
 *   variable. Preserved exactly. An additive CustomEvent
 *   ('saiko:e2e-changed') is emitted for any subscriber that
 *   wants to react in real time (e.g. to display the lock
 *   icon in the chat header).
 *
 * ORIGINAL LOCATION (index.html):
 *   - chatSettingsHTML()  → the #csE2E element
 *   - wireChatSettings()  → #csE2E click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #csE2E
 *
 * FIREBASE PATHS:
 *   none directly — e2eEnabled is read by the admin-support
 *   chat setup and the send-message pipeline.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoE2EToggle = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (e2eEnabled: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.e2eEnabled : true;
  }

  /* ----------------------------------------------------------
   * Label builder — uses t('e2e_encrypted') as prefix,
   * matching the original source.
   * ---------------------------------------------------------- */
  function buildLabel(on) {
    return T('e2e_encrypted') + ': ' + T(on ? 'on' : 'off');
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #csE2E element inside
   * original chatSettingsHTML():
   *   - .toggle-row with a single #csE2E button whose class
   *     is .active when prefs.e2eEnabled is true, and whose
   *     label reads:
   *       "<End-to-end encrypted>: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or sibling controls (#csRead, #csEnter,
   *   #csAutoDel). The settings coordinator renders the
   *   sec-title "Chat" once and stitches all chat-settings
   *   fragments together.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="csE2E">' +
          esc(buildLabel(on)) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.e2eEnabled = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * e2eEnabled is read on-demand by the admin-support chat
     * setup and the message-send pipeline. Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#csE2E');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = buildLabel(on);
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:e2e-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #csE2E click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#csE2E', scope);
    if (!btn) return false;
    if (btn.dataset.e2eBound === '1') return true;
    btn.dataset.e2eBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.e2eEnabled = !prefs.e2eEnabled
       *   btn.classList.toggle('active', prefs.e2eEnabled)
       *   btn.textContent = t('e2e_encrypted') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#csE2E', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-e2e-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoE2EToggle = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 033 — e2e-toggle ready');
  } catch (e) {}

})();