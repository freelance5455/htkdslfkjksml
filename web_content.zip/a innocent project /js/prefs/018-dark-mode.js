/* ============================================================
 * FEATURE:        Dark / Light Mode Toggle (standalone page)
 * FEATURE NUMBER: 018
 * FILE:           js/prefs/018-dark-mode.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The standalone "Dark Mode" settings page (reachable from
 *   the Settings sidebar → "dark_mode"). Renders:
 *
 *     • Section title  <div class="sec-title">Dark Mode</div>
 *     • Two toggle buttons in a .toggle-row:
 *         #darkOn   → ON   (active when prefs.dark === true)
 *         #darkOff  → OFF  (active when prefs.dark === false)
 *
 *   Behaviour (preserved 1:1 from original wireDark()):
 *
 *     #darkOn click:
 *       1. prefs.dark = true
 *       2. applyPrefs()   → toggles body.light class
 *       3. savePrefs()
 *       4. #darkOn.classList.add('active')
 *       5. #darkOff.classList.remove('active')
 *
 *     #darkOff click:
 *       1. prefs.dark = false
 *       2. applyPrefs()
 *       3. savePrefs()
 *       4. #darkOff.classList.add('active')
 *       5. #darkOn.classList.remove('active')
 *
 *   IMPORTANT — SAME IDS AS FEATURE 016:
 *     The Appearance page (feature 016) also embeds an inline
 *     Dark Mode toggle using the same `#darkOn` / `#darkOff`
 *     IDs. That is safe because only one settings page is
 *     mounted at a time (the settings coordinator swaps
 *     #settingPageBody.innerHTML entirely). The bind/unbind
 *     guards (dataset.darkModeBound) keep handlers from
 *     stacking across re-renders.
 *
 * ORIGINAL LOCATION (index.html):
 *   - darkHTML()  → the fragment string
 *   - wireDark()  → #darkOn / #darkOff click handlers
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - applyPrefs()      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #darkOn, #darkOff
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoDarkMode = {
 *     renderFragment,
 *     bind, unbind,
 *     isDark, setDark, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callApplyPrefs() {
    try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {}
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true (dark) if prefs missing
   * ---------------------------------------------------------- */
  function isDark() {
    var p = getPrefs();
    return p ? !!p.dark : true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original darkHTML():
   *   - sec-title
   *   - .toggle-row containing #darkOn (active if dark) and
   *     #darkOff (active if not dark)
   * ---------------------------------------------------------- */
  function renderFragment() {
    var dark = isDark();

    return (
      '<div class="sec-title">' + esc(T('dark_mode')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (dark ? 'active' : '') + '" id="darkOn">' +
          esc(T('on')) +
        '</button>' +
        '<button class="btn ' + (!dark ? 'active' : '') + '" id="darkOff">' +
          esc(T('off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new dark value, persist, and update the
   * on-page button states if the fragment is mounted.
   * ---------------------------------------------------------- */
  function applyDarkState(dark) {
    var p = getPrefs();
    if (p) p.dark = !!dark;

    callApplyPrefs();
    callSavePrefs();

    /* Update button classes if mounted in the DOM ------------- */
    var onBtn  = qs('#darkOn');
    var offBtn = qs('#darkOff');
    if (onBtn)  onBtn.classList.toggle('active', !!dark);
    if (offBtn) offBtn.classList.toggle('active', !dark);
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the ON / OFF buttons. Idempotent via dataset guards.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;

    var onBtn  = qs('#darkOn',  scope);
    var offBtn = qs('#darkOff', scope);
    var bound  = false;

    /* 1) ON button ---------------------------------------- */
    if (onBtn && onBtn.dataset.darkModeBound !== '1') {
      onBtn.dataset.darkModeBound = '1';
      onBtn.addEventListener('click', function () {
        /* Original order preserved exactly:
         *   prefs.dark = true
         *   applyPrefs()
         *   savePrefs()
         *   #darkOn.classList.add('active')
         *   #darkOff.classList.remove('active')
         * ----------------------------------------------- */
        applyDarkState(true);
      });
      bound = true;
    }

    /* 2) OFF button --------------------------------------- */
    if (offBtn && offBtn.dataset.darkModeBound !== '1') {
      offBtn.dataset.darkModeBound = '1';
      offBtn.addEventListener('click', function () {
        applyDarkState(false);
      });
      bound = true;
    }

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — detach handlers via clone-and-swap
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;

    var onBtn  = qs('#darkOn',  scope);
    var offBtn = qs('#darkOff', scope);

    if (onBtn) {
      var cloneOn = onBtn.cloneNode(true);
      cloneOn.removeAttribute('data-dark-mode-bound');
      onBtn.parentNode && onBtn.parentNode.replaceChild(cloneOn, onBtn);
    }

    if (offBtn) {
      var cloneOff = offBtn.cloneNode(true);
      cloneOff.removeAttribute('data-dark-mode-bound');
      offBtn.parentNode && offBtn.parentNode.replaceChild(cloneOff, offBtn);
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setDark — programmatic apply + persist (used by future
   * "reset to default" or quick-theme toggles). */
  function setDark(dark) {
    applyDarkState(!!dark);
    return true;
  }

  /* toggle — flip whatever is currently active */
  function toggle() {
    return setDark(!isDark());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoDarkMode = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isDark: isDark,
    setDark: setDark,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 018 — dark-mode ready');
  } catch (e) {}

})();