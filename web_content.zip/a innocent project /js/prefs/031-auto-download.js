/* ============================================================
 * FEATURE:        Auto-Download Media + Clear Cache
 * FEATURE NUMBER: 031
 * FILE:           js/prefs/031-auto-download.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The complete "Media" settings page. Renders TWO elements:
 *
 *     1. #mdAuto    → "Auto-download media" toggle button
 *     2. #mdClear   → "Clear cache" danger-ghost button
 *
 *   These two controls live together in the original
 *   mediaHTML() fragment and are wired by the same
 *   wireMedia() function, so they belong to one feature file.
 *
 *   Behaviour (preserved 1:1 from original wireMedia):
 *
 *     #mdAuto click:
 *       1. prefs.autoDownload = !prefs.autoDownload
 *       2. #mdAuto.classList.toggle('active', prefs.autoDownload)
 *       3. #mdAuto.textContent = t('auto_download_media') +
 *                                ': ' + t(autoDownload ? 'on' : 'off')
 *       4. savePrefs()
 *
 *     #mdClear click:
 *       1. Show confirmDialog(t('clear_cache'), t('are_you_sure'))
 *       2. Abort if cancelled
 *       3. recentPlayed = [];   localStorage.removeItem('saiko_recent_games')
 *       4. reelsHistory = [];   localStorage.removeItem('saiko_reels_history')
 *       5. If 'caches' in window:
 *            keys = await caches.keys()
 *            Promise.all(keys.map(k => caches.delete(k)))
 *       6. toast(t('saved'), 'ok')
 *       7. On error → toast(t('error'), 'err')
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     mediaHTML() renders the sec-title "Media" + the toggle +
 *     the clear button in one shot. Unlike the privacy/chat
 *     settings pages which had multiple sibling toggles split
 *     across features, this page has exactly two controls and
 *     both are wired by wireMedia(). Per modular rules
 *     ("unnecessarily merge mat karo" but also "don't split
 *     artificially"), these stay together in feature 031.
 *
 *   NOTE: Original did NOT call applyPrefs() for the toggle —
 *   autoDownload is a runtime flag read on-demand by media
 *   upload/download code. Preserved exactly. An additive
 *   CustomEvent ('saiko:auto-download-changed') is emitted
 *   for any subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - mediaHTML()  → the whole Media page fragment
 *   - wireMedia()  → #mdAuto click + #mdClear click
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *   - confirmDialog     confirm modal helper (optional)
 *   - toast(msg, kind)  optional toast notifier
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #mdAuto, #mdClear
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : 'saiko_prefs_v7'          (via prefs-core)
 *                 'saiko_recent_games'      (remove on clear)
 *                 'saiko_reels_history'     (remove on clear)
 * sessionStorage: none
 * IndexedDB     : none  (but Cache Storage API is used)
 *
 * EXPORTS (global):
 *   window.SaikoAutoDownload = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle,
 *     clearCache
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional helpers — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  function askConfirm(title, text) {
    try {
      if (typeof confirmDialog === 'function') return confirmDialog(title, text);
    } catch (e) {}
    /* Fallback — never blocks clearing if confirmDialog is
     * missing during early boot. */
    return Promise.resolve(true);
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (autoDownload: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.autoDownload : true;
  }

  /* ----------------------------------------------------------
   * Label builder
   * ---------------------------------------------------------- */
  function buildLabel(on) {
    return T('auto_download_media') + ': ' + T(on ? 'on' : 'off');
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original mediaHTML():
   *   - sec-title "Media"
   *   - .toggle-row with a single #mdAuto button
   *   - <button class="btn ghost block" id="mdClear"
   *             style="margin-top:.8rem">
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="sec-title">' + esc(T('media')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="mdAuto">' +
          esc(buildLabel(on)) +
        '</button>' +
      '</div>' +
      '<button class="btn ghost block" id="mdClear" ' +
        'style="margin-top:.8rem">' +
        esc(T('clear_cache')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new autoDownload value, persist, update
   * on-page button label/class, notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.autoDownload = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * autoDownload is read on-demand by media code. */
    callSavePrefs();

    var btn = qs('#mdAuto');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = buildLabel(on);
    }

    try {
      window.dispatchEvent(new CustomEvent('saiko:auto-download-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * CLEAR CACHE — the #mdClear flow.
   * Preserved 1:1 from the original wireMedia() #mdClear
   * click handler.
   *
   * The original referenced globals `recentPlayed` and
   * `reelsHistory` (owned by the games and reels modules).
   * In the modular build we:
   *   • clear the localStorage keys unconditionally
   *   • reset the module-scoped arrays via their public APIs
   *     if the modules are loaded (SaikoReelsHistory etc.)
   *   • fall back to direct window.xxx = [] assignment for
   *     backward compatibility while we are mid-migration
   * ---------------------------------------------------------- */
  async function clearCache() {
    const ok = await askConfirm(T('clear_cache'), T('are_you_sure'));
    if (!ok) return false;

    try {
      /* 1) Games "recent played" list -------------------- */
      try {
        if (window.SaikoRecentGames &&
            typeof window.SaikoRecentGames.clear === 'function') {
          window.SaikoRecentGames.clear();
        } else {
          if (typeof window.recentPlayed !== 'undefined') {
            window.recentPlayed = [];
          }
          localStorage.removeItem('saiko_recent_games');
        }
      } catch (e) {
        try { localStorage.removeItem('saiko_recent_games'); } catch (e2) {}
      }

      /* 2) Reels history ---------------------------------- */
      try {
        if (window.SaikoReelsHistory &&
            typeof window.SaikoReelsHistory.clear === 'function') {
          window.SaikoReelsHistory.clear();
        } else {
          if (typeof window.reelsHistory !== 'undefined') {
            window.reelsHistory = [];
          }
          localStorage.removeItem('saiko_reels_history');
        }
      } catch (e) {
        try { localStorage.removeItem('saiko_reels_history'); } catch (e2) {}
      }

      /* 3) Cache Storage API ------------------------------ *
       * Only runs if the browser supports it; silently
       * skipped otherwise. Matches the original guard.
       * --------------------------------------------------- */
      if ('caches' in window) {
        try {
          const keys = await caches.keys();
          await Promise.all(keys.map(function (k) {
            return caches.delete(k);
          }));
        } catch (e) { /* swallow */ }
      }

      /* 4) Success toast ---------------------------------- */
      safeToast(T('saved'), 'ok');
      return true;
    } catch (e) {
      safeToast(T('error'), 'err');
      return false;
    }
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires #mdAuto + #mdClear. Idempotent via dataset guards.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* 1) #mdAuto toggle ----------------------------------- */
    var auto = qs('#mdAuto', scope);
    if (auto && auto.dataset.autoDownloadBound !== '1') {
      auto.dataset.autoDownloadBound = '1';
      auto.addEventListener('click', function () {
        /* Original order preserved:
         *   prefs.autoDownload = !prefs.autoDownload
         *   btn.classList.toggle('active', prefs.autoDownload)
         *   btn.textContent = t('auto_download_media') +
         *                     ': ' + t(on/off)
         *   savePrefs()
         * ------------------------------------------- */
        applyState(!isEnabled());
      });
      bound = true;
    }

    /* 2) #mdClear button ---------------------------------- */
    var clr = qs('#mdClear', scope);
    if (clr && clr.dataset.autoDownloadBound !== '1') {
      clr.dataset.autoDownloadBound = '1';
      clr.addEventListener('click', function () {
        clearCache();
      });
      bound = true;
    }

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip handlers
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;

    var auto = qs('#mdAuto', scope);
    if (auto) {
      var cloneA = auto.cloneNode(true);
      cloneA.removeAttribute('data-auto-download-bound');
      auto.parentNode && auto.parentNode.replaceChild(cloneA, auto);
    }

    var clr = qs('#mdClear', scope);
    if (clr) {
      var cloneC = clr.cloneNode(true);
      cloneC.removeAttribute('data-auto-download-bound');
      clr.parentNode && clr.parentNode.replaceChild(cloneC, clr);
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoAutoDownload = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle,
    clearCache: clearCache
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 031 — auto-download ready');
  } catch (e) {}

})();