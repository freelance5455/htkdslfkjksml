/* ============================================================
 * FEATURE:        Chat Themes (15 themes)
 * FEATURE NUMBER: 021
 * FILE:           js/prefs/021-chat-themes.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Chat Theme" picker page. Renders a 3-column grid of
 *   the 15 available themes (from SaikoChatThemesCore) into
 *   the #profileViewBody container of the existing #ovProfile
 *   overlay, so it can be launched from:
 *     • Chat info menu → "Chat Theme" (feature 151/153 path)
 *     • Group info menu → "Chat Theme" (feature 119 path)
 *
 *   Behaviour (preserved 1:1 from original
 *   openChatThemePicker(chatId)):
 *
 *     openChatThemePicker(chatId):
 *       1. current = localStorage[CHAT_THEME_KEY + chatId]
 *          (falls back to 'default')
 *       2. body = #profileViewBody
 *       3. body.innerHTML = back button + grid of theme cards
 *       4. openOverlay('ovProfile')
 *       5. Bind back button → closeOverlay('ovProfile') and,
 *          if the chat was a group, re-open group info.
 *       6. Bind each theme card click:
 *            a. localStorage[CHAT_THEME_KEY + chatId] = id
 *            b. toast(t('saved'), 'ok')
 *            c. applyChatTheme(chatId)  (writes CSS vars)
 *            d. update .sel on the picked card only
 *
 * ORIGINAL LOCATION (index.html):
 *   - Section §22 CHAT → openChatThemePicker(chatId)
 *
 * DEPENDENCIES (loaded earlier):
 *   - SaikoChatThemesCore / CHAT_THEMES / CHAT_THEME_KEY /
 *     applyChatTheme                      (js/chat/chat-themes-core.js)
 *   - t(key)                              i18n translator
 *   - esc(str)                            HTML-escape helper
 *   - toast(msg, kind)                    optional toast
 *   - openOverlay / closeOverlay          nav helpers
 *   - chatMeta, chatMeta[chatId].type     optional group-type check
 *   - openGroupInfo(chatId)               optional back-nav target
 *
 * DOM ELEMENTS USED:
 *   #profileViewBody   (rendered into)
 *   #ovProfile         (opened overlay)
 *   #themeBack         (back button, created by this fragment)
 *   [data-thid]        (theme cards, created by this fragment)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : 'saiko_chat_theme_<chatId>'  (read + write)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openChatThemePicker
 *   window.SaikoChatThemePicker = {
 *     open, renderFragment, bind, unbind,
 *     getCurrent, setTheme
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Chat-themes-core accessors (defensive)
   * ---------------------------------------------------------- */
  function getThemes() {
    try {
      if (typeof window.CHAT_THEMES !== 'undefined' && Array.isArray(window.CHAT_THEMES)) {
        return window.CHAT_THEMES;
      }
    } catch (e) {}
    return [];
  }

  function getThemeKeyPrefix() {
    try {
      if (typeof window.CHAT_THEME_KEY === 'string') return window.CHAT_THEME_KEY;
    } catch (e) {}
    return 'saiko_chat_theme_';
  }

  function callApplyChatTheme(chatId) {
    try {
      if (typeof window.applyChatTheme === 'function') {
        window.applyChatTheme(chatId);
      }
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Overlay helpers (defensive — both may not exist yet)
   * ---------------------------------------------------------- */
  function safeOpenOverlay(id) {
    try {
      if (typeof window.openOverlay === 'function') window.openOverlay(id);
      else {
        var el = document.getElementById(id);
        if (el) el.classList.add('open');
      }
    } catch (e) {}
  }

  function safeCloseOverlay(id) {
    try {
      if (typeof window.closeOverlay === 'function') window.closeOverlay(id);
      else {
        var el = document.getElementById(id);
        if (el) el.classList.remove('open');
      }
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * chatMeta accessor (defensive — chat module owns this)
   * ---------------------------------------------------------- */
  function getChatMeta(chatId) {
    try {
      if (typeof window.chatMeta !== 'undefined' && window.chatMeta) {
        return window.chatMeta[chatId] || null;
      }
    } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * getCurrent — read the currently selected theme id for a
   * chat (delegates to chat-themes-core if available).
   * ---------------------------------------------------------- */
  function getCurrent(chatId) {
    try {
      if (window.SaikoChatThemesCore &&
          typeof window.SaikoChatThemesCore.getThemeId === 'function') {
        return window.SaikoChatThemesCore.getThemeId(chatId);
      }
    } catch (e) {}
    if (!chatId) return 'default';
    try {
      return localStorage.getItem(getThemeKeyPrefix() + chatId) || 'default';
    } catch (e) {
      return 'default';
    }
  }

  /* ----------------------------------------------------------
   * setTheme — persist + apply + notify.
   * Extracted so both the card click handler and programmatic
   * callers can share the exact same behaviour.
   * ---------------------------------------------------------- */
  function setTheme(chatId, themeId) {
    if (!chatId || !themeId) return false;

    /* 1) Persist ------------------------------------------ */
    try {
      if (window.SaikoChatThemesCore &&
          typeof window.SaikoChatThemesCore.setThemeId === 'function') {
        window.SaikoChatThemesCore.setThemeId(chatId, themeId);
      } else {
        localStorage.setItem(getThemeKeyPrefix() + chatId, themeId);
      }
    } catch (e) {}

    /* 2) Toast -------------------------------------------- */
    safeToast(T('saved'), 'ok');

    /* 3) Apply -------------------------------------------- */
    callApplyChatTheme(chatId);

    /* 4) Notify subscribers ------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:chat-theme-changed', {
        detail: { chatId: chatId, themeId: themeId }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Returns the HTML for the theme picker page. Structure
   * preserved 1:1 from original openChatThemePicker():
   *
   *   <div class="ov-head" style="position:sticky;top:0">
   *     <button class="icon-btn" id="themeBack">←</button>
   *     <div class="ov-title">…</div>
   *   </div>
   *   <div style="padding:1rem">
   *     <div class="theme-grid">
   *       …15 theme cards…
   *     </div>
   *   </div>
   * ---------------------------------------------------------- */
  function renderFragment(chatId) {
    var themes = getThemes();
    var current = getCurrent(chatId);

    var cards = themes.map(function (th) {
      var isSel = (current === th.id);
      return (
        '<div class="theme-card' + (isSel ? ' sel' : '') + '" ' +
             'data-thid="' + esc(th.id) + '">' +
          '<div class="swatchrow">' +
            '<i style="background:' + th.me  + '"></i>' +
            '<i style="background:' + th.you + '"></i>' +
            '<i style="background:' + th.bg  + '"></i>' +
          '</div>' +
          '<div class="nm">' + esc(th.name) + '</div>' +
        '</div>'
      );
    }).join('');

    return (
      '<div class="ov-head" style="position:sticky;top:0">' +
        '<button class="icon-btn" id="themeBack">←</button>' +
        '<div class="ov-title">' + esc(T('chat_theme')) + '</div>' +
      '</div>' +
      '<div style="padding:1rem">' +
        '<div class="theme-grid">' + cards + '</div>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the back button and every theme card inside
   * `#profileViewBody`. Idempotent via dataset guards.
   * ---------------------------------------------------------- */
  function bind(chatId, root) {
    var scope = root || document;
    var bound = false;

    /* 1) Back button -------------------------------------- */
    var back = qs('#themeBack', scope);
    if (back && back.dataset.chatThemeBound !== '1') {
      back.dataset.chatThemeBound = '1';
      back.addEventListener('click', function () {
        /* Original behaviour: close the overlay, then if the
         * chat is a group, return to group info. */
        safeCloseOverlay('ovProfile');

        var c = getChatMeta(chatId);
        if (c && c.type === 'group') {
          try {
            if (typeof window.openGroupInfo === 'function') {
              window.openGroupInfo(chatId);
            }
          } catch (e) {}
        }
      });
      bound = true;
    }

    /* 2) Theme cards -------------------------------------- */
    qsa('#profileViewBody [data-thid]', scope).forEach(function (card) {
      if (card.dataset.chatThemeBound === '1') return;
      card.dataset.chatThemeBound = '1';

      card.addEventListener('click', function () {
        var id = card.getAttribute('data-thid');
        if (!id) return;

        /* Persist + toast + apply (matches original order) */
        setTheme(chatId, id);

        /* Update .sel so only the clicked card is highlighted.
         * Original used a querySelectorAll + class toggle on
         * every card, comparing with the clicked one. */
        qsa('#profileViewBody .theme-card', scope).forEach(function (x) {
          x.classList.toggle('sel', x === card);
        });
      });

      bound = true;
    });

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip handlers
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;

    var back = qs('#themeBack', scope);
    if (back) {
      var cBack = back.cloneNode(true);
      cBack.removeAttribute('data-chat-theme-bound');
      back.parentNode && back.parentNode.replaceChild(cBack, back);
    }

    qsa('#profileViewBody [data-thid]', scope).forEach(function (card) {
      if (card.dataset.chatThemeBound !== '1') return;
      var clone = card.cloneNode(true);
      clone.removeAttribute('data-chat-theme-bound');
      card.parentNode && card.parentNode.replaceChild(clone, card);
    });
  }

  /* ----------------------------------------------------------
   * OPEN — main entry point.
   * Renders the picker into #profileViewBody, opens the
   * #ovProfile overlay, and wires interactions.
   *
   * Preserved 1:1 from original openChatThemePicker(chatId).
   * ---------------------------------------------------------- */
  function open(chatId) {
    var body = qs('#profileViewBody');
    if (!body) return false;

    /* 1) Render fragment ---------------------------------- */
    body.innerHTML = renderFragment(chatId);

    /* 2) Open overlay ------------------------------------- */
    safeOpenOverlay('ovProfile');

    /* 3) Bind interactions -------------------------------- */
    bind(chatId, body);

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.openChatThemePicker = open;

  window.SaikoChatThemePicker = {
    open: open,
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getCurrent: getCurrent,
    setTheme: setTheme
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 021 — chat-themes ready');
  } catch (e) {}

})();