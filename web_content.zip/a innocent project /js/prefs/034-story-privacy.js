/* ============================================================
 * FEATURE:        Default Story Privacy
 * FEATURE NUMBER: 034
 * FILE:           js/prefs/034-story-privacy.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The complete "Stories" settings page. Renders THREE
 *   elements that all belong to the same original fragment
 *   (storiesSettingsHTML) and are wired by the same original
 *   function (wireStoriesSettings):
 *
 *     1. sec-title  "Stories"
 *     2. #stPriv    → <select class="input"> with two options:
 *                       • public        (default)
 *                       • close         (Close Friends)
 *     3. #stSave    → solid block save button
 *
 *   Behaviour (preserved 1:1 from original wireStoriesSettings):
 *
 *     On render:
 *       #stPriv.value = prefs.storyPrivacy || 'public'
 *
 *     #stSave click:
 *       1. prefs.storyPrivacy = #stPriv.value
 *       2. savePrefs()
 *       3. toast(t('saved'), 'ok')
 *
 *   NOTE: The original had NO 'change' listener on #stPriv.
 *   It was a save-button-driven control (like feature 027
 *   call permission), NOT a live-write control (like feature
 *   032 auto-delete). This distinction is preserved byte-for-
 *   byte — the value is only committed when the user taps
 *   Save.
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     storiesSettingsHTML() rendered exactly these three
 *     elements and wireStoriesSettings() wired only #stSave.
 *     Per modular rules ("unnecessarily merge mat karo"),
 *     this whole page is small enough that its three elements
 *     belong together — they represent one settings page with
 *     no sibling controls in other feature files.
 *
 *   NOTE: Original did NOT call applyPrefs() — storyPrivacy
 *   is a runtime flag read on-demand by the story-creation
 *   composer (feature 187/188) to pre-select the privacy
 *   dropdown for a new story. Not a CSS variable. An additive
 *   CustomEvent ('saiko:story-privacy-changed') is emitted
 *   for any subscriber that wants to react in real time.
 *
 *   NOTE: This feature is DISTINCT from #pvStoryPrivacy
 *   which appeared inside the Privacy page (privacyHTML).
 *   That control (owned by the privacy coordinator) reads
 *   and writes the SAME prefs.storyPrivacy value. This
 *   feature (034) is the Stories-page variant of the same
 *   preference; both write to prefs.storyPrivacy. The two
 *   screens are never mounted simultaneously, so there is no
 *   conflict.
 *
 * ORIGINAL LOCATION (index.html):
 *   - storiesSettingsHTML()  → the fragment string
 *   - wireStoriesSettings()  → #stSave click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *   - toast(msg, kind)  optional toast notifier
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #stPriv, #stSave
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoStoryPrivacy = {
 *     renderFragment,
 *     bind, unbind,
 *     getValue,        → reads current select value from DOM
 *     setValue,        → programmatic set (DOM + prefs + save)
 *     readPref,        → reads prefs.storyPrivacy
 *     isValid          → validates 'public' | 'close'
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Allowed values — matches the two <option>s in the
   * original fragment.
   * ---------------------------------------------------------- */
  var ALLOWED = ['public', 'close'];
  var DEFAULT_VALUE = 'public';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Value validation
   * ---------------------------------------------------------- */
  function isValid(v) {
    return ALLOWED.indexOf(v) !== -1;
  }

  /* ----------------------------------------------------------
   * readPref — read the persisted value from prefs.
   * Defaults to 'public' when prefs missing or invalid.
   * ---------------------------------------------------------- */
  function readPref() {
    var p = getPrefs();
    var v = p ? p.storyPrivacy : null;
    return isValid(v) ? v : DEFAULT_VALUE;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original storiesSettingsHTML():
   *   <div class="sec-title">Stories</div>
   *   <div class="field">
   *     <label>Default privacy</label>
   *     <select class="input" id="stPriv">
   *       <option value="public">Public</option>
   *       <option value="close">Close Friends</option>
   *     </select>
   *   </div>
   *   <button class="btn solid block" id="stSave">Save</button>
   * ---------------------------------------------------------- */
  function renderFragment() {
    var current = readPref();

    function optionHTML(value, labelKey) {
      var sel = (current === value) ? ' selected' : '';
      return '<option value="' + esc(value) + '"' + sel + '>' +
             esc(T(labelKey)) +
             '</option>';
    }

    return (
      '<div class="sec-title">' + esc(T('stories')) + '</div>' +
      '<div class="field">' +
        '<label>Default privacy</label>' +
        '<select class="input" id="stPriv">' +
          optionHTML('public', 'public') +
          optionHTML('close',  'close_friends') +
        '</select>' +
      '</div>' +
      '<button class="btn solid block" id="stSave">' +
        esc(T('save')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires only #stSave — matching the original exactly.
   *
   *   The original wireStoriesSettings() explicitly set
   *   sel.value from prefs at bind-time (in case the fragment
   *   was rendered before the pref was loaded), then wired
   *   only the Save button. We preserve both steps.
   *
   *   Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* 1) Sync select value from prefs (matches original) --- */
    var sel = qs('#stPriv', scope);
    if (sel) {
      var pref = readPref();
      if (sel.value !== pref) sel.value = pref;
    }

    /* 2) Wire #stSave ------------------------------------- */
    var save = qs('#stSave', scope);
    if (save && save.dataset.storyPrivBound !== '1') {
      save.dataset.storyPrivBound = '1';
      save.addEventListener('click', function () {
        /* Original order preserved exactly:
         *   prefs.storyPrivacy = sel.value
         *   savePrefs()
         *   toast(t('saved'), 'ok')
         * ------------------------------------------- */
        var s = qs('#stPriv', scope);
        var v = s ? s.value : readPref();
        if (!isValid(v)) v = DEFAULT_VALUE;

        var p = getPrefs();
        if (p) p.storyPrivacy = v;
        callSavePrefs();

        safeToast(T('saved'), 'ok');

        try {
          window.dispatchEvent(new CustomEvent('saiko:story-privacy-changed', {
            detail: { value: v }
          }));
        } catch (e) {}
      });
      bound = true;
    }

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var save = qs('#stSave', scope);
    if (!save) return;
    var clone = save.cloneNode(true);
    clone.removeAttribute('data-story-priv-bound');
    save.parentNode && save.parentNode.replaceChild(clone, save);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* getValue — read the current select value from the DOM.
   * Falls back to persisted pref, then to the default. */
  function getValue() {
    var sel = qs('#stPriv');
    if (!sel) return readPref();
    var v = sel.value;
    return isValid(v) ? v : readPref();
  }

  /* setValue — programmatic setter.
   *   • writes the value into prefs.storyPrivacy
   *   • persists via savePrefs()
   *   • reflects the value in the DOM if the fragment is open
   *   • emits the same CustomEvent as a user-driven Save
   * NOT wired to any DOM event so the original click-driven
   * semantics remain unchanged. */
  function setValue(v) {
    if (!isValid(v)) return false;

    /* 1) Update prefs + persist --------------------------- */
    var p = getPrefs();
    if (p) p.storyPrivacy = v;
    callSavePrefs();

    /* 2) Reflect in the DOM if mounted -------------------- */
    var sel = qs('#stPriv');
    if (sel) sel.value = v;

    /* 3) Notify subscribers ------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:story-privacy-changed', {
        detail: { value: v }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoStoryPrivacy = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getValue: getValue,
    setValue: setValue,
    readPref: readPref,
    isValid: isValid
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 034 — story-privacy ready');
  } catch (e) {}

})();