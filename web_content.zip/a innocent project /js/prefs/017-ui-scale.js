/* ============================================================
 * FEATURE:        UI Scale Slider (standalone page)
 * FEATURE NUMBER: 017
 * FILE:           js/prefs/017-ui-scale.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The standalone "UI Size" settings page (reachable from the
 *   Settings sidebar → "ui_size"). Renders:
 *
 *     • Section title          <div class="sec-title">UI Size</div>
 *     • Live percentage card   #sizeVal      (big centred number)
 *     • Range slider           #sizeRange    (min 1, max 100)
 *     • Min/Max legend row     "1%" … "100%"
 *     • Save button            #sizeSave
 *
 *   Behaviour (preserved 1:1 from original wireUiSize()):
 *
 *     #sizeRange input:
 *       1. prefs.scale = Number(r.value)
 *       2. #sizeVal.textContent = prefs.scale + '%'
 *       3. applyPrefs()   → live CSS var update
 *       NOTE: does NOT persist on input — this differs from
 *       the mini slider embedded inside the Appearance page
 *       (which is owned by feature 016 and DOES save on input).
 *       Save here is explicit, button-driven.
 *
 *     #sizeSave click:
 *       1. savePrefs()
 *       2. toast(t('saved'), 'ok')
 *
 *   IMPORTANT — SAME IDS AS FEATURE 016:
 *     Both this page and the mini slider inside the Appearance
 *     page use `#sizeVal` and `#sizeRange`. That is safe because
 *     only one settings page is rendered at a time (the settings
 *     coordinator swaps #settingPageBody.innerHTML entirely).
 *     The bind/unbind guards (dataset.sizeScaleBound) keep
 *     handlers from stacking across re-renders.
 *
 * ORIGINAL LOCATION (index.html):
 *   - uiSizeHTML()  → the fragment string
 *   - wireUiSize()  → #sizeRange input + #sizeSave click
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - applyPrefs()      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *   - toast(msg,kind)   optional toast notifier
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #sizeVal, #sizeRange, #sizeSave
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoUiSize = {
 *     renderFragment,
 *     bind, unbind,
 *     getCurrent,
 *     setScale
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Optional toast — safely swallowed if absent
   * ---------------------------------------------------------- */
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callApplyPrefs() {
    try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {}
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Current scale — clamped to [1, 100], integer.
   * ---------------------------------------------------------- */
  function getCurrent() {
    var p = getPrefs();
    var v = p && p.scale != null ? Number(p.scale) : 50;
    if (!isFinite(v)) v = 50;
    if (v < 1) v = 1;
    if (v > 100) v = 100;
    return Math.round(v);
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from original uiSizeHTML():
   *   - sec-title
   *   - centred big value card (id="sizeVal")
   *   - range input (id="sizeRange", min=1, max=100)
   *   - 1% / 100% legend row
   *   - save button (id="sizeSave", with margin-top:1rem)
   * ---------------------------------------------------------- */
  function renderFragment() {
    var current = getCurrent();
    var currentStr = String(current);

    return (
      '<div class="sec-title">' + esc(T('ui_size')) + '</div>' +

      '<div class="card" style="text-align:center">' +
        '<div style="font-size:1.6rem;font-weight:800" id="sizeVal">' +
          esc(currentStr) + '%' +
        '</div>' +
      '</div>' +

      '<input type="range" min="1" max="100" value="' + esc(currentStr) + '" id="sizeRange">' +

      '<div class="row" style="justify-content:space-between;font-size:.72rem;color:var(--muted)">' +
        '<span>1%</span><span>100%</span>' +
      '</div>' +

      '<button class="btn solid block" id="sizeSave" style="margin-top:1rem">' +
        esc(T('save')) +
      '</button>'
    );
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the slider input and the save button. Idempotent
   * via dataset.sizeScaleBound guards.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;

    var range = qs('#sizeRange', scope);
    var save  = qs('#sizeSave',  scope);
    var bound = false;

    /* 1) Slider — live preview (no save) ------------------ */
    if (range && range.dataset.sizeScaleBound !== '1') {
      range.dataset.sizeScaleBound = '1';
      range.addEventListener('input', function () {
        var v = Number(range.value);
        if (!isFinite(v)) v = 50;
        if (v < 1) v = 1;
        if (v > 100) v = 100;
        v = Math.round(v);

        var p = getPrefs();
        if (p) p.scale = v;

        var valEl = qs('#sizeVal', scope);
        if (valEl) valEl.textContent = v + '%';

        callApplyPrefs();
      });
      bound = true;
    }

    /* 2) Save button — persist + toast -------------------- */
    if (save && save.dataset.sizeScaleBound !== '1') {
      save.dataset.sizeScaleBound = '1';
      save.addEventListener('click', function () {
        /* Slider already updated prefs.scale during input,
         * so we only need to persist whatever is current. */
        callSavePrefs();
        safeToast(T('saved'), 'ok');
      });
      bound = true;
    }

    return bound;
  }

  /* ----------------------------------------------------------
   * UNBIND — detach handlers by cloning (removes listeners)
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;

    var range = qs('#sizeRange', scope);
    var save  = qs('#sizeSave',  scope);

    if (range) {
      var cloneR = range.cloneNode(true);
      cloneR.removeAttribute('data-size-scale-bound');
      range.parentNode && range.parentNode.replaceChild(cloneR, range);
    }

    if (save) {
      var cloneS = save.cloneNode(true);
      cloneS.removeAttribute('data-size-scale-bound');
      save.parentNode && save.parentNode.replaceChild(cloneS, save);
    }
  }

  /* ----------------------------------------------------------
   * setScale — programmatic apply + persist
   * Used by future tools (reset-to-default, UI-scale presets,
   * accessibility quick-controls, etc).
   * ---------------------------------------------------------- */
  function setScale(v) {
    var n = Number(v);
    if (!isFinite(n)) return false;
    if (n < 1) n = 1;
    if (n > 100) n = 100;
    n = Math.round(n);

    var p = getPrefs();
    if (p) p.scale = n;
    callApplyPrefs();
    callSavePrefs();

    /* Update the on-page value if the fragment is mounted */
    var valEl = qs('#sizeVal');
    if (valEl) valEl.textContent = n + '%';

    var rangeEl = qs('#sizeRange');
    if (rangeEl) rangeEl.value = String(n);

    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoUiSize = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    getCurrent: getCurrent,
    setScale: setScale
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 017 — ui-scale ready');
  } catch (e) {}

})();