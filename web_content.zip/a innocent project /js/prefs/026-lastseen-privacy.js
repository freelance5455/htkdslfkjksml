/* ============================================================
 * FEATURE:        Last Seen Privacy
 * FEATURE NUMBER: 026
 * FILE:           js/prefs/026-lastseen-privacy.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The "Last seen visibility" toggle of the Privacy settings
 *   page. Renders a single toggle button (#pvLastSeen) that
 *   switches prefs.showLastSeen on/off.
 *
 *   Behaviour (preserved 1:1 from original wirePrivacy):
 *
 *     #pvLastSeen click:
 *       1. prefs.showLastSeen = !prefs.showLastSeen
 *       2. #pvLastSeen.classList.toggle('active', prefs.showLastSeen)
 *       3. #pvLastSeen.textContent = t('last_seen_visibility')
 *                                    + ': ' + t(showLastSeen ? 'on' : 'off')
 *       4. savePrefs()
 *
 *   NOTE ON THE ORIGINAL FRAGMENT:
 *     The original privacyHTML() rendered SIX elements.
 *     This feature owns ONLY the #pvLastSeen toggle. Sibling
 *     toggles (#pvOnline, #pvTyping, #pvCallPerm, #pvStoryPrivacy)
 *     and the #pvSave button are owned by other feature files
 *     and the settings coordinator respectively.
 *
 *   NOTE: Original did NOT call applyPrefs() here — showLastSeen
 *   is a runtime flag read on-demand by chat-header rendering
 *   (see renderMessage / chatDisplay) and by user-profile
 *   rendering (openUserProfile → "Offline · 5m ago" line).
 *   Not a CSS variable. Preserved exactly. An additive
 *   CustomEvent ('saiko:lastseen-privacy-changed') is emitted
 *   for any subscriber that wants to react in real time.
 *
 * ORIGINAL LOCATION (index.html):
 *   - privacyHTML()  → the #pvLastSeen element
 *   - wirePrivacy()  → #pvLastSeen click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs      (prefs-core.js)
 *   - savePrefs()       (prefs-core.js)
 *   - t(key)            i18n translator
 *   - esc(str)          HTML-escape helper (local fallback)
 *
 * DOM ELEMENTS USED (rendered by this fragment):
 *   #pvLastSeen
 *
 * FIREBASE PATHS:
 *   none directly — the privacy coordinator writes
 *   users/{uid}/privacy when the Save button is pressed.
 *
 * localStorage  : via prefs-core ('saiko_prefs_v7')
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoLastSeenPrivacy = {
 *     renderFragment,
 *     bind, unbind,
 *     isEnabled,
 *     setEnabled, toggle
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local DOM helper
   * ---------------------------------------------------------- */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Prefs accessors (defensive)
   * ---------------------------------------------------------- */
  function getPrefs() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) return window.prefs;
    } catch (e) {}
    return null;
  }

  function callSavePrefs() {
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
  }

  /* ----------------------------------------------------------
   * State reader — defaults to true if prefs missing,
   * matching the original default (showLastSeen: true).
   * ---------------------------------------------------------- */
  function isEnabled() {
    var p = getPrefs();
    return p ? !!p.showLastSeen : true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Structure preserved 1:1 from the #pvLastSeen element
   * inside original privacyHTML():
   *   - .toggle-row with a single #pvLastSeen button whose
   *     class is .active when prefs.showLastSeen is true,
   *     and whose label reads:
   *       "<last_seen_visibility>: <ON|OFF>"
   *
   *   NOTE: This fragment intentionally does NOT include the
   *   sec-title or sibling controls. The privacy coordinator
   *   renders the sec-title "Privacy" once and stitches all
   *   toggle fragments (025, 026, 027, 028) plus the save
   *   button underneath it.
   * ---------------------------------------------------------- */
  function renderFragment() {
    var on = isEnabled();

    return (
      '<div class="toggle-row">' +
        '<button class="btn ' + (on ? 'active' : '') + '" id="pvLastSeen">' +
          esc(T('last_seen_visibility')) + ': ' + esc(T(on ? 'on' : 'off')) +
        '</button>' +
      '</div>'
    );
  }

  /* ----------------------------------------------------------
   * Internal: apply a new value, persist, update the on-page
   * button label/class if mounted, then notify subscribers.
   * ---------------------------------------------------------- */
  function applyState(on) {
    var p = getPrefs();
    if (p) p.showLastSeen = !!on;

    /* Original did NOT call applyPrefs() for this toggle —
     * showLastSeen is read on-demand by chat-header and
     * user-profile renderers. Preserved exactly. */
    callSavePrefs();

    /* Update the button in-place (idempotent if not mounted) */
    var btn = qs('#pvLastSeen');
    if (btn) {
      btn.classList.toggle('active', !!on);
      btn.textContent = T('last_seen_visibility') + ': ' + T(on ? 'on' : 'off');
    }

    /* Notify subscribers --------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:lastseen-privacy-changed', {
        detail: { enabled: !!on }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * BIND
   * Wires the #pvLastSeen click. Idempotent via dataset guard.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#pvLastSeen', scope);
    if (!btn) return false;
    if (btn.dataset.lastSeenPrivacyBound === '1') return true;
    btn.dataset.lastSeenPrivacyBound = '1';

    btn.addEventListener('click', function () {
      /* Original order preserved exactly:
       *   prefs.showLastSeen = !prefs.showLastSeen
       *   btn.classList.toggle('active', prefs.showLastSeen)
       *   btn.textContent = t('last_seen_visibility') +
       *                     ': ' + t(on/off)
       *   savePrefs()
       * ----------------------------------------------- */
      applyState(!isEnabled());
    });

    return true;
  }

  /* ----------------------------------------------------------
   * UNBIND — clone-and-swap to strip the handler
   * ---------------------------------------------------------- */
  function unbind(root) {
    var scope = root || document;
    var btn = qs('#pvLastSeen', scope);
    if (!btn) return;
    var clone = btn.cloneNode(true);
    clone.removeAttribute('data-last-seen-privacy-bound');
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
  }

  /* ----------------------------------------------------------
   * PUBLIC HELPERS
   * ---------------------------------------------------------- */

  /* setEnabled — programmatic apply + persist. */
  function setEnabled(on) {
    applyState(!!on);
    return true;
  }

  /* toggle — flip whatever is currently active. */
  function toggle() {
    return setEnabled(!isEnabled());
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoLastSeenPrivacy = {
    renderFragment: renderFragment,
    bind: bind,
    unbind: unbind,
    isEnabled: isEnabled,
    setEnabled: setEnabled,
    toggle: toggle
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 026 — lastseen-privacy ready');
  } catch (e) {}

})();