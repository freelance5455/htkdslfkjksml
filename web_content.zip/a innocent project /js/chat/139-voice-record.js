/* ============================================================
 * FEATURE:        Voice Recording
 * FEATURE NUMBER: 139
 * FILE:           js/chat/139-voice-record.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the voice-message recorder attached to #btnMic. The
 *   recorder:
 *
 *     1. Requests microphone permission via getUserMedia.
 *     2. Starts a MediaRecorder with the best supported Opus
 *        codec (falls back to browser default).
 *     3. Shows an in-chat recording pill with a live timer
 *        and a Cancel button.
 *     4. Auto-stops when the duration exceeds MAX_VOICE_SECONDS
 *        (from MEDIA_CONFIG, default 180 s).
 *     5. On stop:
 *          • stops the mic tracks
 *          • discards the recording when cancelled
 *          • discards sub-800-byte clips (too short to matter)
 *          • uploads the blob to Cloudinary
 *          • sends it as a voice message via feature 112's
 *            sendMessage({ type:'voice', url, dur })
 *          • bumps the daily 'voice' stat
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block
 *   (the #btnMic click handler).
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → #btnMic click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - sendMessage              js/inbox/112-chat-open.js
 *   - cloudinaryUpload         js/core/cloudinary.js
 *   - toast                    js/nav/042-toast.js
 *   - t(key) / fmtDur()        helpers
 *   - MEDIA_CONFIG             core/config
 *   - bumpDaily                stats helper
 *
 * DOM ELEMENTS USED:
 *   #btnMic      — play/stop toggle button
 *   #chatBody    — the recording pill is appended here
 *
 * FIREBASE PATHS:
 *   none directly — the write happens inside sendMessage().
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoVoiceRecorder = {
 *     start, stop, cancel,
 *     isRecording, getDuration,
 *     bind, unbind
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS — fall back to the exact values from the original
   * §1 CONFIG when MEDIA_CONFIG is not yet on window.
   * ============================================================ */
  var MEDIA_CONFIG = (typeof window.MEDIA_CONFIG !== 'undefined' && window.MEDIA_CONFIG) || {
    MAX_VOICE_SECONDS: 180
  };
  var MAX_VOICE_SECONDS = MEDIA_CONFIG.MAX_VOICE_SECONDS || 180;
  var MIN_BLOB_BYTES    = 800;

  /* ============================================================
   * STATE
   * ============================================================ */
  var mediaRecorder = null;
  var recChunks     = [];
  var recStream     = null;
  var recTimer      = null;
  var recSeconds    = 0;
  var recordingCancelled = false;
  var bound         = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function fmtDur(sec) {
    try { if (typeof window.fmtDur === 'function') return window.fmtDur(sec); }
    catch (e) {}
    var s = Math.max(0, Math.floor(sec || 0));
    var m = Math.floor(s / 60);
    var r = s % 60;
    return m + ':' + (r < 10 ? '0' + r : r);
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[voice-record] safeCall:', name, e); }
    return undefined;
  }

  function isRecording() {
    return !!(mediaRecorder && mediaRecorder.state === 'recording');
  }

  function getDuration() { return recSeconds; }

  /* ============================================================
   * PICK MIME
   * ============================================================
   * Prefer Opus in WebM (best compatibility with Cloudinary's
   * audio/video pipeline and the widest browser support). If
   * the browser does not advertise that exact MIME, fall back
   * to the MediaRecorder default by returning an empty string.
   * ============================================================ */
  function pickMime() {
    try {
      if (typeof MediaRecorder === 'undefined') return '';
      if (typeof MediaRecorder.isTypeSupported !== 'function') return '';
      if (MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) {
        return 'audio/webm;codecs=opus';
      }
    } catch (e) {}
    return '';
  }

  /* ============================================================
   * RECORDING PILL — the visible in-chat indicator
   * ============================================================ */
  function showPill() {
    var body = qs('#chatBody');
    if (!body) return null;

    /* Remove any previous pill ------------------------- */
    var existing = qs('#recordingBar');
    if (existing) existing.remove();

    var bar = document.createElement('div');
    bar.id = 'recordingBar';
    bar.className = 'recording-pill';
    bar.innerHTML =
      '<span class="rec-dot"></span>' +
      '<span id="recTime">' + fmtDur(0) + '</span>' +
      '<button class="btn sm danger" id="recCancel">' +
        T('cancel') +
      '</button>';

    body.appendChild(bar);
    body.scrollTop = body.scrollHeight;

    /* Cancel button ------------------------------------ */
    var cancelBtn = qs('#recCancel', bar);
    if (cancelBtn) {
      cancelBtn.addEventListener('click', function () {
        recordingCancelled = true;
        if (mediaRecorder && mediaRecorder.state === 'recording') {
          try { mediaRecorder.stop(); } catch (e) {}
        }
      });
    }

    return bar;
  }

  function updatePillTimer() {
    var t = qs('#recTime');
    if (t) t.textContent = fmtDur(recSeconds);
  }

  function removePill() {
    var bar = qs('#recordingBar');
    if (bar) bar.remove();
  }

  /* ============================================================
   * STOP
   * ============================================================
   * Called from #btnMic click (while recording) or from the
   * Cancel button. The actual onstop callback (set up in
   * start()) handles the cleanup and the upload.
   * ============================================================ */
  function stop() {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      try { mediaRecorder.stop(); } catch (e) {}
    }
  }

  function cancel() {
    recordingCancelled = true;
    stop();
  }

  /* ============================================================
   * START
   * ============================================================
   * Preserved 1:1 from the original #btnMic handler:
   *   • mediaRecorder + mediaDevices guard
   *   • mic permission request
   *   • mime pick
   *   • ondataavailable → recChunks
   *   • onstop → cleanup + upload + send voice message
   *   • start + timer + pill
   * ============================================================ */
  async function start() {
    /* Already recording → stop ----------------------------- */
    if (isRecording()) {
      stop();
      return;
    }

    /* Feature detection ---------------------------------- */
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      safeToast(T('not_supported'), 'err');
      return;
    }

    /* Request mic ---------------------------------------- */
    try {
      recStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (e) {
      safeToast(T('mic_permission'), 'err');
      return;
    }

    recChunks = [];
    recordingCancelled = false;

    /* Choose codec --------------------------------------- */
    var mime = pickMime();

    try {
      mediaRecorder = mime
        ? new MediaRecorder(recStream, { mimeType: mime })
        : new MediaRecorder(recStream);
    } catch (e) {
      /* Fallback to default constructor ----------------- */
      try {
        mediaRecorder = new MediaRecorder(recStream);
      } catch (e2) {
        safeToast(T('not_supported'), 'err');
        try { recStream.getTracks().forEach(function (tr) { tr.stop(); }); } catch (e3) {}
        recStream = null;
        mediaRecorder = null;
        return;
      }
    }

    /* Data chunk handler --------------------------------- */
    mediaRecorder.ondataavailable = function (e) {
      if (e.data && e.data.size) recChunks.push(e.data);
    };

    /* Stop handler — cleanup + upload + send ------------- */
    mediaRecorder.onstop = async function () {
      if (recTimer) { clearInterval(recTimer); recTimer = null; }

      /* Restore mic button ------------------------------ */
      var btn = qs('#btnMic');
      if (btn) btn.innerHTML = svgIconSafe('mic');

      removePill();

      /* Build blob -------------------------------------- */
      var blobType = (mediaRecorder && mediaRecorder.mimeType) || 'audio/webm';
      var blob = new Blob(recChunks, { type: blobType });
      var dur  = recSeconds;

      /* Stop mic tracks --------------------------------- */
      try { recStream.getTracks().forEach(function (tr) { tr.stop(); }); } catch (e) {}
      recStream = null;
      mediaRecorder = null;
      recSeconds = 0;

      /* Discard cancelled recordings -------------------- */
      if (recordingCancelled) {
        recordingCancelled = false;
        return;
      }

      /* Discard blobs that are too small --------------- */
      if (!blob.size || blob.size < MIN_BLOB_BYTES) return;

      /* Upload + send ----------------------------------- */
      try {
        safeToast(T('uploading'));

        var url = null;
        if (typeof window.cloudinaryUpload === 'function') {
          url = await window.cloudinaryUpload(blob, 'voice.webm');
        }
        if (!url) throw new Error(T('upload_failed'));

        await safeCall('sendMessage', [{
          type: 'voice',
          url: url,
          dur: dur
        }]);

        safeCall('bumpDaily', ['voice', 1]);
      } catch (err) {
        safeToast((err && err.message) ? err.message : T('upload_failed'), 'err');
      }
    };

    /* Start recording ------------------------------------ */
    try {
      mediaRecorder.start();
    } catch (e) {
      safeToast(T('not_supported'), 'err');
      try { recStream.getTracks().forEach(function (tr) { tr.stop(); }); } catch (e2) {}
      recStream = null;
      mediaRecorder = null;
      return;
    }

    recSeconds = 0;

    /* Update button icon to "stop" ----------------------- */
    var micBtn = qs('#btnMic');
    if (micBtn) micBtn.innerHTML = svgIconSafe('stop');

    /* Show pill + start timer ---------------------------- */
    showPill();
    recTimer = setInterval(function () {
      recSeconds++;
      updatePillTimer();

      /* Auto-stop at max duration ---------------------- */
      if (recSeconds > MAX_VOICE_SECONDS && isRecording()) {
        try { mediaRecorder.stop(); } catch (e) {}
      }
    }, 1000);
  }

  /* ============================================================
   * SVG HELPER — prefer the shared icon module
   * ============================================================ */
  function svgIconSafe(name) {
    try {
      if (typeof window.svgIcon === 'function') return window.svgIcon(name);
    } catch (e) {}
    return '';
  }

  /* ============================================================
   * BIND — attach the #btnMic click handler
   * ============================================================ */
  function bind() {
    var btn = qs('#btnMic');
    if (!btn || bound) return bound;
    bound = true;

    btn.addEventListener('click', function (e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      /* Dispatch based on current recorder state. */
      if (isRecording()) stop();
      else start();
    });
    return true;
  }

  function unbind() {
    var btn = qs('#btnMic');
    if (!btn) return false;
    /* Clone-and-swap detaches the anonymous listener. */
    var clone = btn.cloneNode(true);
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoVoiceRecorder = {
    start: start,
    stop: stop,
    cancel: cancel,
    isRecording: isRecording,
    getDuration: getDuration,
    bind: bind,
    unbind: unbind,
    MAX_SECONDS: MAX_VOICE_SECONDS
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 139 — voice-record ready');
  } catch (e) {}

})();