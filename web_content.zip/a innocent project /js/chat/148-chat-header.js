/* ============================================================
 * FEATURE:        Chat Header
 * FEATURE NUMBER: 148
 * FILE:           js/chat/148-chat-header.js
 * ACTION:         REPLACE (Batch 9 — fixed nickname propagation)
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper that owns everything about the chat header:
 *   the avatar (#chatHeadAvatar), the display name
 *   (#chatHeadName), and the sub-line (#chatHeadSub).
 *
 *   Batch 9 fix: refreshHeaderNames() now ALWAYS updates the
 *   header name (for direct AND group chats). Previously it
 *   early-returned for non-group chats, which broke nickname
 *   propagation — a nickname set in Chat Info was never
 *   reflected in the header of a direct chat.
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[chat-header] safeCall:', name, e); }
    return undefined;
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function userName(uid) {
    try { if (typeof window.userName === 'function') return window.userName(uid); }
    catch (e) {}
    var u = findUser(uid);
    return (u && u.name) || 'User';
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function chatDisplay(chatId, c) {
    try {
      if (typeof window.chatDisplay === 'function') {
        return window.chatDisplay(chatId, c);
      }
    } catch (e) {}
    return { name: 'Chat', photo: '', uid: null };
  }
  function getNickname(chatId, uid) {
    try {
      if (typeof window.getNickname === 'function') {
        return window.getNickname(chatId, uid);
      }
    } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * RESOLVE — pure header-info computation
   * ============================================================ */
  function resolveHeader(chatId, c) {
    if (!chatId || !c) {
      return { name: 'Chat', photo: '', peerUid: null, kind: 'direct', memberCount: 0, subText: '' };
    }

    var me = getMyUid();

    /* --- admin support ---------------------------------- */
    if (c.adminSupport) {
      return {
        name: T('admin_support'),
        photo: '',
        peerUid: null,
        kind: 'adminSupport',
        memberCount: 0,
        subText: '🛡 ' + T('e2e_secure_chat')
      };
    }

    /* --- group ------------------------------------------ */
    if (c.type === 'group') {
      var count = Object.keys(c.members || {}).length;
      return {
        name: c.name || 'Group',
        photo: c.image || '',
        peerUid: null,
        kind: 'group',
        memberCount: count,
        subText: count + ' ' + T('members_count')
      };
    }

    /* --- direct ----------------------------------------- */
    var info = chatDisplay(chatId, c);
    var peerUid = info.uid || null;

    if (!peerUid) {
      var keys = Object.keys(c.members || {});
      for (var i = 0; i < keys.length; i++) {
        if (keys[i] !== me && keys[i] !== 'admin') { peerUid = keys[i]; break; }
      }
    }

    var isOnline = !!(peerUid && window.onlineUsers && window.onlineUsers[peerUid]);
    var pu = peerUid ? findUser(peerUid) : null;
    var sub = '';
    if (isOnline) sub = T('online');
    else if (pu && pu.lastSeen) sub = T('offline') + ' · ' + timeAgo(pu.lastSeen);
    else sub = T('offline');

    return {
      name: info.name || 'User',
      photo: info.photo || '',
      peerUid: peerUid,
      kind: 'direct',
      memberCount: 0,
      subText: sub
    };
  }

  /* ============================================================
   * RENDER — write the resolved info into the DOM
   * ============================================================ */
  function renderHeader(chatId, c) {
    if (!chatId) return false;
    if (!c) c = (window.chatMeta && window.chatMeta[chatId]) || null;
    if (!c) return false;

    var info = resolveHeader(chatId, c);

    var nameEl = qs('#chatHeadName');
    if (nameEl) nameEl.textContent = info.name;

    var avEl = qs('#chatHeadAvatar');
    if (avEl) {
      var avUid = (info.kind === 'direct') ? info.peerUid : null;
      var html = avatarHTML(info.photo, info.name, 'av-32', avUid);
      avEl.outerHTML = html.replace(
        'class="avatar',
        'id="chatHeadAvatar" class="avatar'
      );
    }

    var subEl = qs('#chatHeadSub');
    if (subEl) subEl.textContent = info.subText;

    if (info.kind === 'direct') {
      window.chatPeerUid = info.peerUid;
    } else {
      window.chatPeerUid = null;
    }

    return true;
  }

  /* ============================================================
   * SUB-LINE HELPERS
   * ============================================================ */
  function setSub(text) {
    var sub = qs('#chatHeadSub');
    if (!sub) return false;
    sub.textContent = String(text || '');
    return true;
  }

  function restoreHeaderSub(chatId) {
    var cid = chatId || window.currentChatId;
    if (!cid) return false;

    var c = (window.chatMeta && window.chatMeta[cid]) || null;
    if (!c) return false;

    var info = resolveHeader(cid, c);
    return setSub(info.subText);
  }

  function showTypingSub(uids) {
    if (!uids || !uids.length) return false;

    var text;
    try {
      if (window.SaikoTypingIndicator &&
          typeof window.SaikoTypingIndicator.formatTypingText === 'function') {
        text = window.SaikoTypingIndicator.formatTypingText(uids);
      }
    } catch (e) {}
    if (!text) {
      var names = uids.map(userName).slice(0, 2).join(', ');
      text = names + ' ' + T('typing');
    }
    return setSub(text);
  }

  /* ============================================================
   * REFRESH HEADER NAMES — BATCH 9 FIX
   * ============================================================
   * Preserved from the reference single-file build:
   *   1. ALWAYS update the header name (direct + group + admin).
   *   2. ONLY for group chats, also re-label every "who" line in
   *      existing bubbles so a member rename appears there too.
   * ============================================================ */
  function refreshHeaderNames(chatId) {
    var cid = chatId || window.currentChatId;
    if (!cid) return false;

    var c = (window.chatMeta && window.chatMeta[cid]) || null;
    if (!c) return false;

    /* 1) Always refresh the header NAME -------------------- */
    var info = resolveHeader(cid, c);
    var nameEl = qs('#chatHeadName');
    if (nameEl) nameEl.textContent = info.name;

    /* Also refresh the peer uid for listeners ------------- */
    if (info.kind === 'direct') {
      window.chatPeerUid = info.peerUid;
    }

    /* 2) Group-only: re-label every bubble's sender -------- */
    if (c.type !== 'group') return true;

    var nodes = qsa('#chatBody .bubble.you .who');
    for (var i = 0; i < nodes.length; i++) {
      var who = nodes[i];
      var bubble = who.closest ? who.closest('.bubble') : null;
      if (!bubble) continue;
      var uid = bubble.getAttribute('data-from');
      if (!uid) continue;

      var nick = getNickname(cid, uid);
      var u = findUser(uid);
      who.textContent = nick || (u && u.name) || 'User';
    }
    return true;
  }

  function getCurrent() {
    var cid = window.currentChatId;
    if (!cid) return null;
    var c = (window.chatMeta && window.chatMeta[cid]) || null;
    if (!c) return null;
    return resolveHeader(cid, c);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.refreshChatHeaderNames = refreshHeaderNames;

  window.SaikoChatHeader = {
    resolve: resolveHeader,
    render: renderHeader,
    refreshNames: refreshHeaderNames,
    setSub: setSub,
    restoreSub: restoreHeaderSub,
    showTypingSub: showTypingSub,
    getCurrent: getCurrent
  };

  try {
    console.debug('[boot] feature 148 — chat-header ready (batch 9 fix)');
  } catch (e) {}

})();