/* ============================================================
 * FEATURE:        Message Render
 * FEATURE NUMBER: 128
 * FILE:           js/chat/128-message-render.js
 * ACTION:         REPLACE (v2 — reel-share support added)
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function linkifyTags(s) {
    try { if (typeof window.linkifyTags === 'function') return window.linkifyTags(s); }
    catch (e) {}
    return s;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function fmtTime(ts) {
    try { if (typeof window.fmtTime === 'function') return window.fmtTime(ts); }
    catch (e) {}
    return '';
  }
  function fmtDur(sec) {
    try { if (typeof window.fmtDur === 'function') return window.fmtDur(sec); }
    catch (e) {}
    return '';
  }
  function fmtDayLabel(ts) {
    try { if (typeof window.fmtDayLabel === 'function') return window.fmtDayLabel(ts); }
    catch (e) {}
    return '';
  }
  function dateKey(ts) {
    try { if (typeof window.dateKey === 'function') return window.dateKey(ts); }
    catch (e) {}
    return '';
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[message-render] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function getNickname(chatId, targetUid) {
    try {
      if (typeof window.getNickname === 'function') return window.getNickname(chatId, targetUid);
    } catch (e) {}
    return null;
  }
  function isMsgStarred(mid) {
    try {
      if (typeof window.isMsgStarred === 'function') return !!window.isMsgStarred(mid);
    } catch (e) {}
    return false;
  }

  /* ============================================================
   * DECRYPT + RENDER
   * ============================================================ */
  async function decryptAndRenderMessage(mid, m, isNew) {
    if (!m) return;

    var isAdminSupport = !!window.chatIsAdminSupport;

    if (!isAdminSupport || !m.e2e) {
      renderMessage(mid, m, isNew);
      return;
    }

    if (!window.chatE2EKey) {
      renderMessage(mid, Object.assign({}, m, {
        text: '[encrypted — key unavailable]',
        encrypted: true,
        type: 'text'
      }), isNew);
      return;
    }

    try {
      var E2E = window.SaikoE2E || window.E2E;
      if (!E2E || typeof E2E.decrypt !== 'function') throw new Error('E2E missing');
      var plain = await E2E.decrypt(window.chatE2EKey, m.e2e);
      renderMessage(mid, Object.assign({}, m, { text: plain, decrypted: true }), isNew);
    } catch (e) {
      renderMessage(mid, Object.assign({}, m, {
        text: '[encrypted — unable to decrypt]',
        decryptFailed: true,
        type: 'text'
      }), isNew);
    }
  }

  /* ============================================================
   * RENDER MESSAGE
   * ============================================================ */
  function renderMessage(mid, m, isNew) {
    var chatId = window.currentChatId;
    if (!chatId) return;

    var body = qs('#chatBody');
    if (!body) return;

    var existing = body.querySelector('[data-mid="' + mid + '"]');
    var me = getMyUid();
    var mine = (m.from === me);
    var c = (window.chatMeta && window.chatMeta[chatId]) || {};
    var groupChat = (c.type === 'group');
    var chatIsAdminSupport = !!window.chatIsAdminSupport;

    /* ---- Display name ---- */
    var displayName;
    if (mine) {
      var mp = getMyProfile();
      displayName = (mp && mp.name) || '';
    } else {
      var nick = getNickname(chatId, m.from);
      displayName = nick ||
                    m.fromName ||
                    (findUser(m.from) || {}).name ||
                    'User';
    }

    /* ---- Date separator ---- */
    var dayKey = dateKey(m.createdAt);
    if (isNew && !existing && dayKey !== window.__lastRenderedMsgDay) {
      var sep = document.createElement('div');
      sep.className = 'date-sep';
      sep.innerHTML = '<span>' + esc(fmtDayLabel(m.createdAt)) + '</span>';
      body.appendChild(sep);
      window.__lastRenderedMsgDay = dayKey;
    }

    /* ---- Inner HTML ---- */
    var inner = '';

    if (groupChat && !mine) {
      inner += '<div class="who">' + esc(displayName) + '</div>';
    }

    if (isMsgStarred(mid)) {
      inner += '<span class="star-badge" title="Starred">⭐ </span>';
    }

    if (m.deleted) {
      inner += '<i>' + esc(T('message_deleted')) + '</i>';
    } else {
      /* Story reply quote */
            if (m.storyReply) {
        var sr = m.storyReply;
        var owner = (sr.storyUid === me)
          ? T('your_story')
          : (((findUser(sr.storyUid) || {}).name) || 'Story');

        var thumbHTML = '';
        if (sr.storyType === 'video' && sr.storyUrl) {
          thumbHTML =
            '<video src="' + esc(sr.storyUrl) + '" muted playsinline preload="metadata" ' +
              'data-reel-thumb="1" ' +
              'style="width:2.6rem;height:2.6rem;border-radius:.4rem;object-fit:cover;' +
              'margin:0;flex:0 0 auto;background:#000;pointer-events:none"></video>';
        } else if (sr.thumb) {
          thumbHTML =
            '<img src="' + esc(sr.thumb) + '" alt="" ' +
              'style="width:2.6rem;height:2.6rem;border-radius:.4rem;object-fit:cover;' +
              'margin:0;flex:0 0 auto">';
        }

        inner += '<div class="storyquote" ' +
          'data-story-open-uid="' + esc(sr.storyUid || '') + '" ' +
          'data-story-open-id="' + esc(sr.storyId || '') + '" ' +
          'style="cursor:pointer">' + thumbHTML +
          '<div class="sq-txt">' +
            '<span class="sq-tag">📖 ' + esc(T('reply_to_story')) + '</span>' +
            esc(owner) +
          '</div>' +
        '</div>';
      }

      /* Reply quote */
      if (m.replyTo) {
        var rm = (window.chatMessages || {})[m.replyTo];
        var preview = rm
          ? ((rm.text || '').slice(0, 90) || '📷')
          : '…';
        inner += '<div class="quote">' +
          '<b>' + esc(m.replyName || '') + '</b>' +
          esc(preview) +
        '</div>';
      }

      /* Body by type */
      if (m.type === 'image') {
        inner += '<img src="' + esc(m.url) + '" loading="lazy" alt="" ' +
                 'data-view="' + esc(m.url) + '">';
        if (m.text) inner += '<div>' + esc(m.text) + '</div>';
      } else if (m.type === 'voice') {
        inner += renderVoiceMessage(mid, m);
      } else if (m.type === 'poll') {
        inner += renderPollMessage(mid, m);
      } else if (m.type === 'reel') {
        inner += renderReelShareMessage(mid, m);
      } else {
        inner += linkifyTags(esc(m.text || ''));
        if (chatIsAdminSupport) {
          inner += ' <span style="font-size:.6rem;opacity:.7">🔒</span>';
        }
      }
    }

    /* Time + edited + read receipt */
    var meta = '<div class="t"><span>' + esc(fmtTime(m.createdAt)) + '</span>';
    if (m.edited) {
      meta += '<span>· ' + esc(T('edited')) + '</span>';
    }
    if (mine && !m.deleted) {
      var readBy = m.readBy || {};
      var others = Object.keys(readBy).filter(function (x) { return x !== me; });
      meta += '<span>' + (others.length ? '✓✓' : '✓') + '</span>';
    }
    meta += '</div>';
    inner += meta;

    /* Reactions row */
    if (m.reactions && Object.keys(m.reactions).length) {
      inner += '<div class="rxrow">' +
        Object.keys(m.reactions).map(function (r) {
          var bucket = m.reactions[r] || {};
          var count = Object.keys(bucket).length;
          if (!count) return '';
          return '<span class="rx">' + esc(r) + ' ' + count + '</span>';
        }).join('') +
      '</div>';
    }

    /* Apply bubble */
    var div = existing || document.createElement('div');
    div.className = 'bubble ' + (mine ? 'me' : 'you') +
                    (m.deleted ? ' deleted' : '') +
                    (window.failedMessages && window.failedMessages[mid] ? ' failed' : '');
    div.setAttribute('data-mid', mid);
    div.setAttribute('data-from', m.from || '');
    div.innerHTML = inner;

    if (!existing) body.appendChild(div);

    /* Retry chip */
    if (window.failedMessages && window.failedMessages[mid] &&
        !div.querySelector('.retry')) {
      var retryEl = document.createElement('span');
      retryEl.className = 'retry';
      retryEl.textContent = T('tap_retry');
      retryEl.addEventListener('click', function () {
        safeCall('retryMessage', [mid]);
      });
      div.appendChild(retryEl);
    }

    /* Wire inline interactions */
        bindInlineImage(div);
    bindVoiceControls(div);
    bindPollOptions(div, mid);
    bindReelShare(div);
    bindStoryReply(div);

    /* Scroll on new appends */
    if (isNew && window.chatAtBottom) {
      body.scrollTop = body.scrollHeight;
    }

    /* Read receipt */
    if (!mine && m.from && !chatIsAdminSupport) {
      var allow = true;
      try {
        if (window.prefs && typeof window.prefs.showReadReceipts === 'boolean') {
          allow = window.prefs.showReadReceipts;
        }
      } catch (e) {}
      if (allow) {
        var fbDb = getDB();
        if (fbDb) {
          fbDb.ref('messages/' + chatId + '/' + mid + '/readBy/' + me)
            .set(true).catch(function () {});
        }
      }
    }
  }

  /* ============================================================
   * REEL SHARE MESSAGE
   * ============================================================ */
  function renderReelShareMessage(mid, m) {
    var rid = m.reelId || '';
    var url = m.url || '';
    if (!rid) {
      return '<div style="font-size:.82rem;opacity:.85">Shared reel (unavailable)</div>';
    }
    return '<div class="reel-share-bubble" data-openreel="' + esc(rid) + '" ' +
      'style="cursor:pointer;max-width:15rem;border-radius:.7rem;overflow:hidden;' +
      'border:1px solid rgba(255,255,255,.15);background:#000">' +
            (url
        ? '<video src="' + esc(url) + '" muted playsinline preload="metadata" ' +
          'data-reel-thumb="1" ' +
          'style="width:100%;max-height:16rem;object-fit:cover;background:#000;display:block;pointer-events:none"></video>'
        : '<div style="padding:2rem 1rem;text-align:center;color:#fff;font-size:.8rem">Reel</div>') +
    '</div>';
  }

  function bindStoryReply(div) {
    qsa('[data-story-open-uid]', div).forEach(function (n) {
      if (n.dataset.storyBound === '1') return;
      n.dataset.storyBound = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        var uid = n.getAttribute('data-story-open-uid');
        var sid = n.getAttribute('data-story-open-id');
        if (!uid || !sid) return;
        try {
          if (typeof window.closeOverlay === 'function') window.closeOverlay('ovChat');
        } catch (err) {}
        setTimeout(function () {
          if (typeof window.openStoryAt === 'function') {
            window.openStoryAt(uid, sid);
          } else if (typeof window.openStoriesForUser === 'function') {
            window.openStoriesForUser(uid);
          }
        }, 250);
      });
    });

    /* Video thumb scrub — decode first frame */
    qsa('[data-reel-thumb]', div).forEach(function (v) {
      if (v.dataset.thumbReady === '1') return;
      v.dataset.thumbReady = '1';
      var setFrame = function () {
        try {
          if (v.duration && v.currentTime < 0.05) v.currentTime = 0.1;
        } catch (err) {}
        try { v.pause(); } catch (err) {}
      };
      if (v.readyState >= 1) setFrame();
      else v.addEventListener('loadedmetadata', setFrame, { once: true });
    });
  }

    function bindStoryReply(div) {
    qsa('[data-story-open-uid]', div).forEach(function (n) {
      if (n.dataset.storyBound === '1') return;
      n.dataset.storyBound = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        var uid = n.getAttribute('data-story-open-uid');
        var sid = n.getAttribute('data-story-open-id');
        if (!uid || !sid) return;
        try {
          if (typeof window.closeOverlay === 'function') window.closeOverlay('ovChat');
        } catch (err) {}
        setTimeout(function () {
          if (typeof window.openStoryAt === 'function') {
            window.openStoryAt(uid, sid);
          } else if (typeof window.openStoriesForUser === 'function') {
            window.openStoriesForUser(uid);
          }
        }, 250);
      });
    });

    /* Video thumb scrub — decode first frame */
    qsa('[data-reel-thumb]', div).forEach(function (v) {
      if (v.dataset.thumbReady === '1') return;
      v.dataset.thumbReady = '1';
      var setFrame = function () {
        try {
          if (v.duration && v.currentTime < 0.05) v.currentTime = 0.1;
        } catch (err) {}
        try { v.pause(); } catch (err) {}
      };
      if (v.readyState >= 1) setFrame();
      else v.addEventListener('loadedmetadata', setFrame, { once: true });
    });
  }

  function bindReelShare(div) {

    qsa('[data-openreel]', div).forEach(function (n) {
      if (n.dataset.rendered === '1') return;
      n.dataset.rendered = '1';
      n.addEventListener('click', function (e) {
        e.stopPropagation();
        var rid = n.getAttribute('data-openreel');
        if (!rid) return;
        try {
          if (typeof window.closeOverlay === 'function') window.closeOverlay('ovChat');
        } catch (err) {}
        setTimeout(function () {
          if (typeof window.openReels === 'function') window.openReels(rid);
        }, 250);
      });
    });

    /* Thumbnail: seek to 0.1s so browser decodes first frame */
    qsa('[data-reel-thumb]', div).forEach(function (v) {
      if (v.dataset.thumbReady === '1') return;
      v.dataset.thumbReady = '1';

      var setFrame = function () {
        try {
          if (v.duration && v.currentTime < 0.05) {
            v.currentTime = 0.1;
          }
        } catch (e) {}
        try { v.pause(); } catch (e) {}
      };

      if (v.readyState >= 1) {
        setFrame();
      } else {
        v.addEventListener('loadedmetadata', setFrame, { once: true });
      }
    });
  }

  /* ============================================================
   * INLINE BINDERS
   * ============================================================ */
  function bindInlineImage(div) {
    qsa('[data-view]', div).forEach(function (img) {
      if (img.dataset.rendered === '1') return;
      img.dataset.rendered = '1';
      img.addEventListener('click', function (e) {
        e.stopPropagation();
        var url = img.getAttribute('data-view');
        safeCall('openViewer', [url]);
      });
    });
  }

  function bindVoiceControls(div) {
    qsa('.voice-btn', div).forEach(function (b) {
      if (b.dataset.rendered === '1') return;
      b.dataset.rendered = '1';
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var audio = div.querySelector('audio');
        if (!audio) return;
        if (audio.paused) {
          var p = audio.play();
          if (p && p.catch) p.catch(function () {});
        } else {
          audio.pause();
        }
        b.innerHTML = audio.paused ? svgIcon('play', true) : svgIcon('stop', true);
      });
    });

    qsa('.voice-speed', div).forEach(function (sp) {
      if (sp.dataset.rendered === '1') return;
      sp.dataset.rendered = '1';
      sp.addEventListener('click', function (e) {
        e.stopPropagation();
        var audio = div.querySelector('audio');
        if (!audio) return;
        var speeds = [0.5, 1, 1.5, 2];
        var idx = speeds.indexOf(audio.playbackRate);
        var next = speeds[(idx + 1) % speeds.length];
        audio.playbackRate = next;
        sp.textContent = next + 'x';
      });
    });
  }

  function bindPollOptions(div, mid) {
    qsa('[data-pollopt]', div).forEach(function (b) {
      if (b.dataset.rendered === '1') return;
      b.dataset.rendered = '1';
      b.addEventListener('click', async function (e) {
        e.stopPropagation();

        var chatId = window.currentChatId;
        var me = getMyUid();
        if (!chatId || !me) return;

        var opt = b.getAttribute('data-pollopt');
        if (!opt) return;

        var fbDb = getDB();
        if (!fbDb) return;

        var base = window.chatIsAdminSupport
          ? ('adminChats/' + chatId + '/messages')
          : ('messages/' + chatId);

        var ref = fbDb.ref(base + '/' + mid + '/votes/' + me);
        try {
          var snap = await ref.get();
          if (snap.val() === opt) {
            await ref.remove();
          } else {
            await ref.set(opt);
          }
        } catch (err) {}
      });
    });
  }

  /* ============================================================
   * VOICE MESSAGE
   * ============================================================ */
  function renderVoiceMessage(mid, m) {
    var dur = Number(m.dur) || 0;

    var bars = [];
    for (var i = 0; i < 26; i++) {
      var h = 20 + Math.round(Math.abs(Math.sin(i * 1.7 + (mid || '').length)) * 80);
      bars.push('<i style="height:' + h + '%"></i>');
    }

    return '<div class="voice-wrap">' +
      '<button class="voice-btn">' + svgIcon('play', true) + '</button>' +
      '<div class="voice-wave">' + bars.join('') + '</div>' +
      '<div class="voice-time">' + esc(fmtDur(dur)) + '</div>' +
      '<button class="voice-speed">1x</button>' +
      '<audio preload="metadata" src="' + esc(m.url) + '" style="display:none"></audio>' +
    '</div>';
  }

  /* ============================================================
   * POLL MESSAGE
   * ============================================================ */
  function renderPollMessage(mid, m) {
    var votes = m.votes || {};
    var counts = { A: 0, B: 0 };
    var keys = Object.keys(votes);
    for (var i = 0; i < keys.length; i++) {
      var v = votes[keys[i]];
      if (v) counts[v] = (counts[v] || 0) + 1;
    }
    var total = keys.length || 1;
    var me = getMyUid();
    var mine = votes[me];
    var pA = Math.round((counts.A / total) * 100);
    var pB = Math.round((counts.B / total) * 100);

    var poll = m.poll || {};

    return '<div class="poll-wrap">' +
      '<div style="font-weight:800;margin-bottom:.35rem">' + esc(poll.q || '') + '</div>' +
      '<div class="poll-opt" data-pollopt="A">' +
        '<div class="bar" style="width:' + pA + '%"></div>' +
        '<span><b>' + esc(poll.a || 'A') + '</b>' +
        '<span>' + pA + '% (' + counts.A + ')</span></span>' +
      '</div>' +
      '<div class="poll-opt" data-pollopt="B">' +
        '<div class="bar" style="width:' + pB + '%"></div>' +
        '<span><b>' + esc(poll.b || 'B') + '</b>' +
        '<span>' + pB + '% (' + counts.B + ')</span></span>' +
      '</div>' +
      '<div class="poll-meta">' +
        '<span>' + (total - 1) + ' votes</span>' +
        '<span>' + (mine ? 'Your vote: ' + esc(mine) : 'Tap to vote') + '</span>' +
      '</div>' +
    '</div>';
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.decryptAndRenderMessage = decryptAndRenderMessage;
  window.renderMessage           = renderMessage;
  window.renderVoiceMessage      = renderVoiceMessage;
  window.renderPollMessage       = renderPollMessage;
  window.renderReelShareMessage  = renderReelShareMessage;

  window.SaikoMessageRender = {
    decryptAndRender: decryptAndRenderMessage,
    render: renderMessage,
    renderVoice: renderVoiceMessage,
    renderPoll: renderPollMessage,
    renderReelShare: renderReelShareMessage
  };

  try {
    console.debug('[boot] feature 128 — message-render ready (v2)');
  } catch (e) {}

})();