/* ============================================================
 * FEATURE:        Call Block
 * FEATURE NUMBER: 155
 * FILE:           js/chat/155-call-block.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for the "block this user from calling me"
 *   action. Extracts the "call" branch that lives inline
 *   inside feature 119's openChatInfoMenu() so any future
 *   surface (user profile, long-press sheet, settings page,
 *   incoming-call ring screen) can trigger the same flow.
 *
 *   IMPORTANT — SEMANTIC DISTINCTION:
 *     There are THREE independent block concepts in the app:
 *       • blockedUsers/{uid}/{target}  (feature 085 group)
 *         — full block: profile + feed + messaging
 *       • smsBlocks/{uid}/{target}     (feature 154)
 *         — block only direct messages from {target}
 *       • callBlocks/{uid}/{target}    (THIS feature)
 *         — block only incoming calls from {target}
 *
 *     A user can be call-blocked but still able to message you,
 *     or message-blocked but still able to call you. The three
 *     trees are independent. Call blocks are enforced by
 *     feature 161+ (call signalling) when an incoming call
 *     arrives — this module only owns the STATE and the UI
 *     toggle.
 *
 *   Responsibilities:
 *
 *     1. LIVE MAP
 *          window.callBlockedUsers — { [targetUid]: true }
 *          A live listener keeps it fresh so the call-signalling
 *          feature (161+) and the chat-info menu both read the
 *          current state instantly.
 *
 *     2. PREDICATE
 *          isCallBlocked(uid) — true when I have call-blocked
 *                              the given user.
 *
 *     3. TOGGLE
 *          toggleCallBlock(uid)
 *            — if blocked: remove + toast t('unblocked')
 *            — otherwise:  confirmDialog + set + toast
 *                          t('calls_blocked')
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'call') {
 *       const cur = isCallBlocked(peerUid);
 *       if (cur) {
 *         await db.ref('callBlocks/'+myUid+'/'+peerUid)
 *                 .remove().catch(()=>{});
 *         toast(t('unblocked'), 'ok');
 *       } else {
 *         const ok = await confirmDialog(t('call_block'),
 *                                        t('block_call_confirm'));
 *         if (!ok) return;
 *         await db.ref('callBlocks/'+myUid+'/'+peerUid)
 *                 .set(true).catch(()=>{});
 *         toast(t('calls_blocked'), 'ok');
 *       }
 *     }
 *
 *   Notes on the semantics preserved:
 *     • The unblock path has NO confirmation dialog (asymmetry
 *       from the block path — preserved from the original).
 *     • Both writes are best-effort (`.catch(() => {})`).
 *     • The map is kept fresh by an auth-side listener in the
 *       original; we keep it here as an explicit start/detach
 *       pair so the boot orchestrator can call it cleanly.
 *     • Feature 161 (call signalling) reads isCallBlocked()
 *       before showing an incoming-call ring screen for a peer
 *       that the user has blocked.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §10 AUTH side → callBlockedUsers map + listener
 *     Section §22 CHAT      → openChatInfoMenu() → case 'call'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - confirmDialog          js/nav/043-confirm-dialog.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none — pure state + Firebase.
 *
 * FIREBASE PATHS:
 *   callBlocks/{uid}                 (read + listen)
 *   callBlocks/{uid}/{targetUid}     (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.callBlockedUsers           (live map)
 *   window.isCallBlocked              (original name preserved)
 *   window.toggleCallBlock            (new — canonical)
 *   window.startCallBlockedListener   (additive)
 *   window.detachCallBlockedListener  (additive)
 *   window.SaikoCallBlock = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var callBlockRef = null;
  var callBlockCb  = null;

  window.callBlockedUsers = window.callBlockedUsers || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    /* Missing confirmDialog → treat as "yes" so the flow is
     * never blocked (mirrors every other feature file). */
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * PREDICATE — isCallBlocked(uid)
   * ============================================================ */
  function isCallBlocked(uid) {
    if (!uid) return false;
    return !!window.callBlockedUsers[uid];
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================
   * Attach a live listener on callBlocks/{myUid} so the local
   * map reflects the current block list at all times.
   * ============================================================ */
  function startListener() {
    if (callBlockRef && callBlockCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    callBlockRef = fbDb.ref('callBlocks/' + uid);
    callBlockCb  = callBlockRef.on('value', function (s) {
      window.callBlockedUsers = s.val() || {};

      /* Emit an event so any listener can react (e.g. call
       * history re-render). */
      try {
        window.dispatchEvent(new CustomEvent('saiko:call-block-changed', {
          detail: { map: window.callBlockedUsers }
        }));
      } catch (e) {}
    });
    return true;
  }

  function detachListener() {
    if (callBlockRef && callBlockCb) {
      try { callBlockRef.off('value', callBlockCb); } catch (e) {}
    }
    callBlockRef = null;
    callBlockCb  = null;
    window.callBlockedUsers = {};
    return true;
  }

  /* ============================================================
   * TOGGLE — the write path
   * ============================================================
   * Preserved 1:1 from the original `case 'call'` branch:
   *   • currently blocked → remove + toast t('unblocked')
   *   • otherwise         → confirm → set + toast t('calls_blocked')
   * Both writes are silent on error.
   * ============================================================ */
  async function toggleCallBlock(uid) {
    if (!uid) return false;

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    var ref = fbDb.ref('callBlocks/' + me + '/' + uid);

    try {
      if (isCallBlocked(uid)) {
        /* === Unblock ===================================== *
         *  No confirm dialog — matches the original's
         *  asymmetric behaviour. */
        await ref.remove();
        safeToast(T('unblocked'), 'ok');
      } else {
        /* === Block ======================================= *
         *  Confirm dialog is required on the block path. */
        var ok = await askConfirm(T('call_block'), T('block_call_confirm'));
        if (!ok) return false;

        await ref.set(true);
        safeToast(T('calls_blocked'), 'ok');
      }
    } catch (err) {
      /* Original swallowed write errors silently. Preserved. */
      return false;
    }

    /* Notify subscribers (additive) ------------------------ */
    try {
      window.dispatchEvent(new CustomEvent('saiko:call-block-changed', {
        detail: { targetUid: uid, blocked: isCallBlocked(uid) }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * ADDITIVE HELPERS
   * ============================================================ */
  function getMap() { return window.callBlockedUsers; }
  function getCount() { return Object.keys(window.callBlockedUsers || {}).length; }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.isCallBlocked              = isCallBlocked;
  window.toggleCallBlock            = toggleCallBlock;
  window.startCallBlockedListener   = startListener;
  window.detachCallBlockedListener  = detachListener;

  window.SaikoCallBlock = {
    isBlocked: isCallBlocked,
    toggle: toggleCallBlock,
    startListener: startListener,
    detachListener: detachListener,
    getMap: getMap,
    getCount: getCount
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 155 — call-block ready');
  } catch (e) {}

})();