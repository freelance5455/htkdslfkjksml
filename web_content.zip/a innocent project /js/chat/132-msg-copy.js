/* ============================================================
 * FEATURE:        Message Copy
 * FEATURE NUMBER: 132
 * FILE:           js/chat/132-msg-copy.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for copying a chat message's text to the
 *   clipboard. Extracts the "copy" branch that lives inline
 *   inside feature 145's openMessageMenu() so any future
 *   surface (message list, long-press sheet, forwarded
 *   messages, pinned preview) can trigger the same flow.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'copy') {
 *       try {
 *         await navigator.clipboard.writeText(m.text || '');
 *         toast(t('copied'), 'ok');
 *       } catch (e) {
 *         toast(m.text || '');
 *       }
 *     }
 *
 *   Public functions:
 *     window.copyMessage(mid)         → Promise<boolean>
 *     window.copyMessageText(text)    → Promise<boolean>
 *
 *   Notes on the semantics preserved:
 *     • Only the raw text is copied. Voice / image / poll
 *       messages have no useful text (empty string), so the
 *       clipboard is set to '' — same as original.
 *     • On any clipboard failure (permission denied, HTTPS
 *       required), the fallback path shows the text in a
 *       toast so the user can still select-and-copy manually.
 *     • The original did NOT read the message fresh from
 *       Firebase; it read it from the live in-memory map
 *       (window.chatMessages). We preserve that.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu() → case 'copy'
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.chatMessages    feature 112 (live map)
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.copyMessage          (new — canonical)
 *   window.copyMessageText      (new — canonical)
 *   window.SaikoMsgCopy = {
 *     copy, copyText,
 *     canUseClipboard,
 *     getMessageText
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }

  /* ============================================================
   * CAPABILITY CHECK — preserved from the original guard
   * ============================================================ */
  function canUseClipboard() {
    try {
      return !!(navigator && navigator.clipboard &&
                typeof navigator.clipboard.writeText === 'function');
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * GET MESSAGE TEXT
   * ============================================================
   * Pure — reads the live window.chatMessages entry and
   * returns its text (or ''). Mirrors the original:
   *   (m.text || '')
   * ============================================================ */
  function getMessageText(mid) {
    if (!mid) return '';
    var m = (window.chatMessages && window.chatMessages[mid]) || null;
    return m ? (m.text || '') : '';
  }

  /* ============================================================
   * COPY TEXT
   * ============================================================
   * The raw clipboard helper. Preserves the exact original
   * fallback behaviour:
   *   • clipboard available → writeText + toast(t('copied'),'ok')
   *   • clipboard throws    → toast(text)
   *   • clipboard missing   → toast(text)
   * ============================================================ */
  async function copyText(text) {
    var body = (text == null) ? '' : String(text);

    /* 1) Preferred — Web Clipboard API -------------------- */
    if (canUseClipboard()) {
      try {
        await navigator.clipboard.writeText(body);
        safeToast(T('copied'), 'ok');
        return true;
      } catch (e) {
        /* Fall through to toast fallback — matches original. */
        safeToast(body);
        return false;
      }
    }

    /* 2) Fallback — show the text so the user can copy ----- */
    safeToast(body);
    return false;
  }

  /* ============================================================
   * COPY — main entry
   * ============================================================
   * Preserved 1:1 from the original `case 'copy'` branch.
   * ============================================================ */
  async function copy(mid) {
    if (!mid) return false;
    var text = getMessageText(mid);
    return copyText(text);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.copyMessage     = copy;
  window.copyMessageText = copyText;

  window.SaikoMsgCopy = {
    copy: copy,
    copyText: copyText,
    canUseClipboard: canUseClipboard,
    getMessageText: getMessageText
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 132 — msg-copy ready');
  } catch (e) {}

})();