/* ============================================================
 * FEATURE:        Message Long-Press Menu (Message Options Sheet)
 * FEATURE NUMBER: 145
 * FILE:           js/chat/145-msg-longpress.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the bottom-sheet action menu that appears when the user
 *   long-presses a chat bubble. Orchestrates every message-
 *   level action and delegates each to its dedicated feature.
 *
 *   Responsibilities:
 *
 *     1. LONG-PRESS DETECTION
 *          • touchstart → 480 ms hold timer
 *          • touchmove / touchend → cancel on movement
 *          • contextmenu (desktop right-click) → open immediately
 *          Wired on #chatBody, delegated to .bubble nodes.
 *
 *     2. SHEET CONSTRUCTION
 *          openMessageMenu(mid)
 *            — resolves the message from window.chatMessages
 *            — builds the item list based on:
 *                mine        → edit / star / pin / delme / delall
 *                not mine    → reply / copy / forward / star /
 *                              pin / saveimg / report / block /
 *                              delme
 *                always      → react / reply / copy / forward /
 *                              star / pin
 *            — writes the sheet HTML into #msgMenuSheet
 *            — opens #ovMsgMenu
 *            — wires each row's click
 *
 *     3. DISPATCH
 *          Each row's key is routed to the corresponding
 *          helper. All routing uses safeCall so a missing
 *          feature module never crashes the menu.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     async function openMessageMenu(mid){
 *       const m = chatMessages[mid]; if(!m || !currentChatId) return;
 *       const mine = m.from === myUid;
 *       const items = [];
 *       items.push({k:'react', i:'emoji', label:t('react')});
 *       if(!m.deleted){
 *         items.push({k:'reply', i:'reply', label:t('reply')});
 *         if(m.type === 'text' && !m.e2e)
 *           items.push({k:'copy', i:'copy', label:t('copy')});
 *         items.push({k:'forward', i:'forward', label:t('forward')});
 *         items.push({k:'star', i:'star',
 *                     label: isMsgStarred(mid) ? t('unstar_message')
 *                                              : t('star_message')});
 *         if(mine && m.type === 'text' && !chatIsAdminSupport)
 *           items.push({k:'edit', i:'edit', label:t('edit')});
 *         items.push({k:'pin', i:'pin',
 *                     label: pinnedMsgId === mid ? t('unpin') : t('pin')});
 *       }
 *       if(m.type === 'image')
 *         items.push({k:'saveimg', i:'download', label:t('download')});
 *       if(mine){
 *         items.push({k:'delme', i:'trash',
 *                     label:t('delete_for_me'), danger:true});
 *         if(!m.deleted && !chatIsAdminSupport)
 *           items.push({k:'delall', i:'trash',
 *                       label:t('delete_for_everyone'), danger:true});
 *       } else {
 *         items.push({k:'report', i:'flag',
 *                     label:t('report'), danger:true});
 *         items.push({k:'block', i:'block',
 *                     label:t('block'), danger:true});
 *         items.push({k:'delme', i:'trash',
 *                     label:t('delete_for_me'), danger:true});
 *       }
 *       $('#msgMenuSheet').innerHTML = '<div class="sheet-handle"></div>'
 *         + items.map(...).join('');
 *       openOverlay('ovMsgMenu');
 *       ... wire clicks ...
 *     }
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu(mid) + the setupMessageLongPress IIFE
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.chatMessages / window.currentChatId /
 *     window.chatIsAdminSupport / window.pinnedMsgId
 *                              js/inbox/112-chat-open.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - t / esc / svgIcon        helpers
 *   - openOverlay / closeOverlay  js/nav/038-overlay-system.js
 *   - isMsgStarred             js/chat/135-msg-star.js
 *   - startReply               js/chat/130-msg-reply.js
 *   - openForwardPicker        js/chat/131-msg-forward.js
 *   - copyMessage              js/chat/132-msg-copy.js
 *   - editMessage              js/chat/133-msg-edit.js
 *   - deleteMessageForMe /
 *     deleteMessageForEveryone js/chat/134-msg-delete.js
 *   - togglePinMessage         js/chat/136-msg-pin.js
 *   - openReactions            js/chat/137-msg-reactions.js
 *   - openViewer               js/feed/075-gallery-viewer.js
 *   - openReport               report module (safely-called)
 *   - blockUser                block module (safely-called)
 *
 * DOM ELEMENTS USED:
 *   #chatBody       — long-press target container
 *   .bubble[data-mid] — the pressable element
 *   #ovMsgMenu      — the overlay
 *   #msgMenuSheet   — the sheet inside it
 *
 * FIREBASE PATHS:
 *   none directly — every action delegates to its feature.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openMessageMenu          (original name preserved)
 *   window.SaikoMsgLongpress = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var LONG_PRESS_MS   = 480;
  var MOVE_TOLERANCE  = 12;   /* px */

  /* ============================================================
   * STATE
   * ============================================================ */
  var pressTimer  = null;
  var pressTarget = null;
  var startX = 0, startY = 0;
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-longpress] safeCall:', name, e); }
    return undefined;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMessage(mid) {
    if (!mid) return null;
    return (window.chatMessages && window.chatMessages[mid]) || null;
  }
  function isMsgStarred(mid) {
    try { if (typeof window.isMsgStarred === 'function') return !!window.isMsgStarred(mid); }
    catch (e) {}
    return false;
  }

  /* ============================================================
   * BUILD ITEMS — the exact list from the original source
   * ============================================================
   * Returns an array of { k, i, label, danger? }.
   * Order matters — preserved byte-for-byte.
   * ============================================================ */
  function buildItems(mid) {
    var m = getMessage(mid);
    if (!m) return [];

    var me = getMyUid();
    var mine = (m.from === me);
    var chatIsAdminSupport = !!window.chatIsAdminSupport;
    var pinnedMsgId = window.pinnedMsgId;

    var items = [];

    /* 1) React — always present, at the very top ---------- */
    items.push({ k: 'react', i: 'emoji', label: T('react') });

    /* 2) Non-deleted message actions ---------------------- */
    if (!m.deleted) {
      items.push({ k: 'reply',   i: 'reply',   label: T('reply') });

      /* Copy is only offered on plaintext text messages -- */
      if (m.type === 'text' && !m.e2e) {
        items.push({ k: 'copy', i: 'copy', label: T('copy') });
      }

      items.push({ k: 'forward', i: 'forward', label: T('forward') });

      items.push({
        k: 'star',
        i: 'star',
        label: isMsgStarred(mid) ? T('unstar_message') : T('star_message')
      });

      /* Edit is only for my plaintext messages ----------- */
      if (mine && m.type === 'text' && !chatIsAdminSupport) {
        items.push({ k: 'edit', i: 'edit', label: T('edit') });
      }

      items.push({
        k: 'pin',
        i: 'pin',
        label: (pinnedMsgId === mid) ? T('unpin') : T('pin')
      });
    }

    /* 3) Image-specific: download ------------------------- */
    if (m.type === 'image') {
      items.push({ k: 'saveimg', i: 'download', label: T('download') });
    }

    /* 4) Owner vs other ----------------------------------- */
    if (mine) {
      items.push({
        k: 'delme',
        i: 'trash',
        label: T('delete_for_me'),
        danger: true
      });
      /* Delete for everyone is hidden for already-deleted
       * messages and for admin-support chats. */
      if (!m.deleted && !chatIsAdminSupport) {
        items.push({
          k: 'delall',
          i: 'trash',
          label: T('delete_for_everyone'),
          danger: true
        });
      }
    } else {
      items.push({ k: 'report', i: 'flag',  label: T('report'), danger: true });
      items.push({ k: 'block',  i: 'block', label: T('block'),  danger: true });
      items.push({ k: 'delme',  i: 'trash', label: T('delete_for_me'), danger: true });
    }

    return items;
  }

  /* ============================================================
   * RENDER SHEET
   * ============================================================ */
  function renderSheet(items) {
    var sheet = qs('#msgMenuSheet');
    if (!sheet) return false;
    sheet.innerHTML =
      '<div class="sheet-handle"></div>' +
      items.map(function (it) {
        return '<div class="sheet-item' + (it.danger ? ' danger' : '') + '" ' +
                    'data-mm="' + esc(it.k) + '">' +
                 svgIcon(it.i) +
                 '<span>' + esc(it.label) + '</span>' +
               '</div>';
      }).join('');
    return true;
  }

  /* ============================================================
   * DISPATCH — route one key to its helper
   * ============================================================ */
  async function dispatch(k, mid) {
    if (!k || !mid) return false;

    var m = getMessage(mid);
    if (!m) return false;

    var chatId = window.currentChatId;

    switch (k) {
      case 'react':
        safeCall('openReactions', [mid]);
        return true;

      case 'reply':
        safeCall('startReply', [mid]);
        return true;

      case 'copy':
        safeCall('copyMessage', [mid]);
        return true;

      case 'forward':
        safeCall('openForwardPicker', [mid]);
        return true;

      case 'star':
        safeCall('toggleMsgStar', [mid]);
        return true;

      case 'edit':
        safeCall('editMessage', [mid]);
        return true;

      case 'pin':
        safeCall('togglePinMessage', [mid]);
        return true;

      case 'saveimg':
        /* The original just reused the same download logic
         * exposed by feature 077's downloadMedia helper. */
        if (m.url) {
          var ext = (String(m.url).split('.').pop() || 'jpg')
            .split('?')[0].slice(0, 4);
          var fname = 'innocentsaiko-image-' + Date.now() + '.' + ext;
          safeCall('downloadMedia', [m.url, fname]);
        }
        return true;

      case 'delme':
        safeCall('deleteMessageForMe', [mid]);
        return true;

      case 'delall':
        safeCall('deleteMessageForEveryone', [mid]);
        return true;

      case 'report':
        safeCall('openReport', ['message', mid, chatId]);
        return true;

      case 'block':
        safeCall('blockUser', [m.from]);
        return true;

      default:
        return false;
    }
  }

  /* ============================================================
   * OPEN — main entry
   * ============================================================ */
  function openMessageMenu(mid) {
    if (!mid) return false;
    if (!window.currentChatId) return false;

    var m = getMessage(mid);
    if (!m) return false;

    var items = buildItems(mid);
    if (!items.length) return false;

    if (!renderSheet(items)) return false;

    safeCall('openOverlay', ['ovMsgMenu']);

    /* Wire row clicks ------------------------------------ */
    var sheet = qs('#msgMenuSheet');
    if (sheet) {
      qsa('[data-mm]', sheet).forEach(function (n) {
        n.addEventListener('click', function () {
          safeCall('closeOverlay', ['ovMsgMenu']);
          var k = n.getAttribute('data-mm');
          dispatch(k, mid);
        });
      });
    }

    return true;
  }

  /* ============================================================
   * LONG-PRESS DETECTION
   * ============================================================
   * Preserved from the original setupMessageLongPress() IIFE:
   *   • 480 ms hold → open the menu
   *   • 12 px movement → cancel
   *   • contextmenu on a bubble → open immediately (desktop)
   * ============================================================ */
  function onTouchStart(e) {
    var bubble = e.target && e.target.closest ? e.target.closest('.bubble') : null;
    if (!bubble) return;

    /* Skip if the touch is on an interactive child that owns
     * its own tap behaviour. */
    if (e.target.closest('.voice-btn') ||
        e.target.closest('.voice-speed') ||
        e.target.closest('[data-pollopt]')) {
      return;
    }

    pressTarget = bubble.getAttribute('data-mid');
    if (!pressTarget) return;

    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;

    if (pressTimer) clearTimeout(pressTimer);
    pressTimer = setTimeout(function () {
      pressTimer = null;
      var t = pressTarget;
      pressTarget = null;
      if (t) {
        openMessageMenu(t);
        try { if (navigator.vibrate) navigator.vibrate(15); } catch (err) {}
      }
    }, LONG_PRESS_MS);
  }

  function onTouchMove(e) {
    if (!pressTimer) return;
    var dx = Math.abs(e.touches[0].clientX - startX);
    var dy = Math.abs(e.touches[0].clientY - startY);
    if (dx > MOVE_TOLERANCE || dy > MOVE_TOLERANCE) {
      clearTimeout(pressTimer);
      pressTimer = null;
      pressTarget = null;
    }
  }

  function onTouchEnd() {
    if (pressTimer) {
      clearTimeout(pressTimer);
      pressTimer = null;
    }
    pressTarget = null;
  }

  function onContextMenu(e) {
    var bubble = e.target && e.target.closest ? e.target.closest('.bubble') : null;
    if (!bubble) return;
    e.preventDefault();
    var mid = bubble.getAttribute('data-mid');
    if (mid) openMessageMenu(mid);
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  function bind() {
    var body = qs('#chatBody');
    if (!body || bound) return bound;
    bound = true;

    body.addEventListener('touchstart',  onTouchStart,  { passive: true });
    body.addEventListener('touchmove',   onTouchMove,   { passive: true });
    body.addEventListener('touchend',    onTouchEnd,    { passive: true });
    body.addEventListener('touchcancel', onTouchEnd,    { passive: true });
    body.addEventListener('contextmenu', onContextMenu);

    return true;
  }

  function unbind() {
    var body = qs('#chatBody');
    if (!body) return false;

    body.removeEventListener('touchstart',  onTouchStart);
    body.removeEventListener('touchmove',   onTouchMove);
    body.removeEventListener('touchend',    onTouchEnd);
    body.removeEventListener('touchcancel', onTouchEnd);
    body.removeEventListener('contextmenu', onContextMenu);

    if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; }
    pressTarget = null;
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openMessageMenu = openMessageMenu;

  window.SaikoMsgLongpress = {
    open: openMessageMenu,
    buildItems: buildItems,
    dispatch: dispatch,
    bind: bind,
    unbind: unbind,
    LONG_PRESS_MS: LONG_PRESS_MS,
    MOVE_TOLERANCE: MOVE_TOLERANCE
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 145 — msg-longpress ready');
  } catch (e) {}

})();