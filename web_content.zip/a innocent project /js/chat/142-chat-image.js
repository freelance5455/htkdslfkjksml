/* ============================================================
 * FEATURE:        Chat Image Upload
 * FEATURE NUMBER: 142
 * FILE:           js/chat/142-chat-image.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the image-upload flow attached to #btnAttach. The
 *   flow:
 *
 *     1. #btnAttach click → open a hidden file input accepting
 *        image/*.
 *     2. On file pick:
 *          • validateImage (type + size)
 *          • compressImage (1400 px, q=0.82)
 *          • cloudinaryUpload → hosted URL
 *          • sendMessage({ type:'image', url, text:'' })
 *          • bumpDaily('chat_image', 1)
 *        Failures abort with a toast; no partial writes.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block
 *   (the #btnAttach click handler).
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → #btnAttach click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - sendMessage              js/inbox/112-chat-open.js
 *   - validateImage            js/feed/054-image-upload.js
 *   - compressImage            js/feed/056-image-compress.js
 *   - cloudinaryUpload         js/core/cloudinary.js
 *   - toast                    js/nav/042-toast.js
 *   - t(key)                   js/nav/046-i18n.js
 *   - bumpDaily                stats helper
 *
 * DOM ELEMENTS USED:
 *   #btnAttach      (the visible trigger)
 *   A transient <input type="file"> created per invocation.
 *
 * FIREBASE PATHS:
 *   none directly — the write happens inside sendMessage().
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoChatImage = {
 *     pick, handleFile, bind, unbind,
 *     MAX_SIDE, QUALITY
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var MAX_SIDE = 1400;
  var QUALITY  = 0.82;
  var UPLOAD_FILENAME = 'chat.jpg';

  /* ============================================================
   * STATE
   * ============================================================ */
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[chat-image] safeCall:', name, e); }
    return undefined;
  }

  /* ============================================================
   * HANDLE FILE — the post-pick pipeline
   * ============================================================
   * Preserved 1:1 from the original handler:
   *   • validateImage(file)              → abort with toast
   *   • toast(t('uploading'))
   *   • compressImage(file, 1400, 0.82)  → best effort
   *   • cloudinaryUpload(comp, 'chat.jpg')
   *   • sendMessage({ type:'image', url, text:'' })
   *   • bumpDaily('chat_image', 1)
   * Any thrown error is toasted; nothing else is written.
   * ============================================================ */
  async function handleFile(file) {
    if (!file) return false;

    /* 1) Validate ----------------------------------------- */
    var err = null;
    try {
      if (typeof window.validateImage === 'function') {
        err = window.validateImage(file);
      }
    } catch (e) {}
    if (err) {
      safeToast(err, 'err');
      return false;
    }

    try {
      /* 2) Uploading indicator -------------------------- */
      safeToast(T('uploading'));

      /* 3) Compress (best effort) ----------------------- */
      var comp = file;
      try {
        if (typeof window.compressImage === 'function') {
          comp = await window.compressImage(file, MAX_SIDE, QUALITY);
        }
      } catch (e) {
        /* Compression failure is non-fatal — send the raw
         * file rather than aborting the upload. */
        comp = file;
      }

      /* 4) Cloudinary upload ---------------------------- */
      var url = null;
      if (typeof window.cloudinaryUpload === 'function') {
        url = await window.cloudinaryUpload(comp, UPLOAD_FILENAME);
      }
      if (!url) throw new Error(T('upload_failed'));

      /* 5) Send the message ----------------------------- */
      await safeCall('sendMessage', [{
        type: 'image',
        url: url,
        text: ''
      }]);

      /* 6) Daily stat ----------------------------------- */
      safeCall('bumpDaily', ['chat_image', 1]);

      return true;
    } catch (err2) {
      safeToast((err2 && err2.message) ? err2.message : T('upload_failed'), 'err');
      return false;
    }
  }

  /* ============================================================
   * PICK — open the hidden file input
   * ============================================================
   * Preserved 1:1 from the original #btnAttach click handler:
   *   • create a fresh <input type="file" accept="image/*">
   *   • wire change → handleFile
   *   • click it
   * ============================================================ */
  function pick() {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    /* Do not let the browser keep focus on a detached node. */
    input.style.display = 'none';

    input.addEventListener('change', function () {
      var f = input.files && input.files[0];
      /* Clear the value so re-picking the same file works. */
      input.value = '';
      if (f) handleFile(f);
      /* Clean up the transient node. */
      setTimeout(function () {
        if (input.parentNode) input.parentNode.removeChild(input);
      }, 0);
    });

    /* Attach to the DOM for browsers that require it for the
     * programmatic .click() to work (older Safari). */
    document.body.appendChild(input);
    input.click();
    return true;
  }

  /* ============================================================
   * BIND — attach the #btnAttach click handler
   * ============================================================ */
  function bind() {
    var btn = qs('#btnAttach');
    if (!btn || bound) return bound;
    bound = true;

    btn.addEventListener('click', function (e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      pick();
    });
    return true;
  }

  function unbind() {
    var btn = qs('#btnAttach');
    if (!btn) return false;
    var clone = btn.cloneNode(true);
    btn.parentNode && btn.parentNode.replaceChild(clone, btn);
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoChatImage = {
    pick: pick,
    handleFile: handleFile,
    bind: bind,
    unbind: unbind,
    MAX_SIDE: MAX_SIDE,
    QUALITY: QUALITY
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 142 — chat-image ready');
  } catch (e) {}

})();