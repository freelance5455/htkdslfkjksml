/* ============================================================
 * FEATURE:        E2E Key Pair Setup
 * FEATURE NUMBER: 159
 * FILE:           js/chat/159-e2e-keys.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical owner of the end-to-end encryption subsystem.
 *   Extracts the E2E core that lived inline in §9 E2E of the
 *   original source and exposes it as a namespace
 *   (`window.SaikoE2E`) that feature 112 (chat open) and any
 *   future caller can use.
 *
 *   The E2E scheme:
 *
 *     1. Each user has a persistent ECDH P-256 key pair stored
 *        in localStorage under saiko_e2e_keys_{uid}. The
 *        private key is exported as a JWK — the pair is
 *        device-local only and is regenerated on a new device.
 *
 *     2. The public key (JWK) is published to
 *        e2eKeys/{uid} = { jwk, v:1 } in Firebase so peers
 *        can fetch it.
 *
 *     3. To encrypt a payload for a peer, derive a shared AES-
 *        GCM-256 key from (myPriv, peerPub) and use it to
 *        encrypt the plaintext with a fresh random 12-byte IV.
 *
 *     4. To decrypt an incoming payload, derive the same
 *        shared key from (myPriv, peerPub) — since the
 *        derivation is symmetric, the same AES key encrypts
 *        and decrypts.
 *
 *     5. Payload envelope:
 *          { v: 1, iv: <base64>, ct: <base64> }
 *        `v` allows future scheme migrations without breaking
 *        old messages.
 *
 *   The admin-support chat (§22) uses a deterministic fallback
 *   when the admin has not yet published a public key: a
 *   SHA-256 hash of 'saiko-admin-' + chatId is imported as an
 *   AES-GCM key directly. Both sides compute the same key.
 *
 *   Public API (window.SaikoE2E):
 *     getOrCreateMyKeyPair(uid)  → { priv, pub, pubJwk }
 *     importPeerKey(jwk)         → CryptoKey (public)
 *     deriveAesKey(priv, pub)    → CryptoKey (AES-GCM 256)
 *     encrypt(aesKey, text)      → Promise<{v,iv,ct}>
 *     decrypt(aesKey, payload)   → Promise<string>
 *     b64(buf) / unb64(str)      → base64 helpers
 *     setupChatKey(chatId, opts) → CryptoKey | null
 *     isSupported()              → boolean
 *
 *   Behaviour preserved 1:1 from the original §9 E2E block.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §9 E2E → the whole E2E IIFE
 *     Section §22 CHAT → setupE2EForAdminChat(chatId)
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.crypto.subtle       (WebCrypto API)
 *   - db                         js/core/firebase-init.js
 *   - myUid                      js/auth/004-auth-state.js
 *
 * DOM ELEMENTS USED:
 *   none — pure cryptography + Firebase reads/writes.
 *
 * FIREBASE PATHS:
 *   e2eKeys/{uid}       (write on key creation)
 *   e2eKeys/admin       (read for admin public key)
 *
 * localStorage  : 'saiko_e2e_keys_{uid}'   (read + write)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoE2E = { … }
 *   window.E2E      = window.SaikoE2E   (compat alias)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var KEY_DB_KEY = 'saiko_e2e_keys';
  var CURVE      = 'P-256';
  var IV_BYTES   = 12;
  var ENVELOPE_V = 1;

  /* ============================================================
   * STATE
   * ============================================================ */
  var _keyCache = {};   /* { [uid]: { priv, pub, pubJwk } } */

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* WebCrypto availability check. Requires a secure context
   * (HTTPS or localhost). */
  function isSupported() {
    try {
      return !!(window.isSecureContext && window.crypto && window.crypto.subtle);
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * BASE64 HELPERS
   * ============================================================
   * Preserved 1:1 from the original E2E block:
   *   b64(buf)   → base64 string
   *   unb64(str) → Uint8Array
   * ============================================================ */
  function b64(buf) {
    var bytes = new Uint8Array(buf);
    var bin = '';
    for (var i = 0; i < bytes.length; i++) {
      bin += String.fromCharCode(bytes[i]);
    }
    return btoa(bin);
  }

  function unb64(str) {
    var bin = atob(str);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  /* ============================================================
   * GET OR CREATE MY KEY PAIR
   * ============================================================
   * Preserved 1:1 from the original getOrCreateMyKeyPair(uid):
   *   • try to load the JWK pair from localStorage
   *   • if present → import into CryptoKey objects
   *   • if absent  → generate a fresh ECDH P-256 pair, export
   *                  as JWK, persist to localStorage, and
   *                  return the CryptoKey objects
   *
   * Throws when WebCrypto is unavailable so the caller can
   * gracefully degrade.
   * ============================================================ */
  async function getOrCreateMyKeyPair(uid) {
    if (!uid) throw new Error('uid required');

    /* Cached CryptoKey objects in memory ------------------- */
    if (_keyCache[uid]) return _keyCache[uid];

    /* Try localStorage ------------------------------------- */
    try {
      var raw = localStorage.getItem(KEY_DB_KEY + '_' + uid);
      if (raw) {
        var j = JSON.parse(raw);
        var priv = await crypto.subtle.importKey(
          'jwk', j.priv,
          { name: 'ECDH', namedCurve: CURVE },
          true,
          ['deriveKey', 'deriveBits']
        );
        var pub = await crypto.subtle.importKey(
          'jwk', j.pub,
          { name: 'ECDH', namedCurve: CURVE },
          true,
          []
        );
        var out = { priv: priv, pub: pub, pubJwk: j.pub };
        _keyCache[uid] = out;
        return out;
      }
    } catch (e) {
      /* Corrupt or incompatible — fall through and regenerate. */
    }

    /* WebCrypto guard -------------------------------------- */
    if (!isSupported()) throw new Error('WebCrypto unavailable');

    /* Generate fresh ---------------------------------------- */
    var kp = await crypto.subtle.generateKey(
      { name: 'ECDH', namedCurve: CURVE },
      true,
      ['deriveKey', 'deriveBits']
    );
    var privJwk = await crypto.subtle.exportKey('jwk', kp.privateKey);
    var pubJwk  = await crypto.subtle.exportKey('jwk', kp.publicKey);

    try {
      localStorage.setItem(
        KEY_DB_KEY + '_' + uid,
        JSON.stringify({ priv: privJwk, pub: pubJwk })
      );
    } catch (e) {
      /* LocalStorage full or disabled — still return the
       * in-memory pair so the current session works. */
    }

    var result = { priv: kp.privateKey, pub: kp.publicKey, pubJwk: pubJwk };
    _keyCache[uid] = result;
    return result;
  }

  /* ============================================================
   * IMPORT PEER PUBLIC KEY
   * ============================================================
   * Preserved 1:1 from the original importPeerKey(jwk).
   * ============================================================ */
  async function importPeerKey(jwk) {
    return crypto.subtle.importKey(
      'jwk', jwk,
      { name: 'ECDH', namedCurve: CURVE },
      true,
      []
    );
  }

  /* ============================================================
   * DERIVE SHARED AES KEY
   * ============================================================
   * Preserved 1:1 from the original deriveAesKey(priv, pub):
   *   AES-GCM-256 derived from an ECDH exchange.
   * ============================================================ */
  async function deriveAesKey(priv, pub) {
    return crypto.subtle.deriveKey(
      { name: 'ECDH', public: pub },
      priv,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  /* ============================================================
   * ENCRYPT
   * ============================================================
   * Preserved 1:1 from the original encrypt(aesKey, plaintext):
   *   • fresh random 12-byte IV
   *   • UTF-8 encode the plaintext
   *   • AES-GCM encrypt
   *   • return { v:1, iv: b64, ct: b64 }
   * ============================================================ */
  async function encrypt(aesKey, plaintext) {
    var iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
    var enc = new TextEncoder().encode(plaintext == null ? '' : String(plaintext));
    var ct = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv: iv },
      aesKey,
      enc
    );
    return { v: ENVELOPE_V, iv: b64(iv), ct: b64(ct) };
  }

  /* ============================================================
   * DECRYPT
   * ============================================================
   * Preserved 1:1 from the original decrypt(aesKey, payload):
   *   • validate envelope version
   *   • AES-GCM decrypt
   *   • UTF-8 decode
   * ============================================================ */
  async function decrypt(aesKey, payload) {
    if (!payload || payload.v !== ENVELOPE_V) {
      throw new Error('Unsupported payload');
    }
    var iv = unb64(payload.iv);
    var ct = unb64(payload.ct);
    var pt = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: iv },
      aesKey,
      ct
    );
    return new TextDecoder().decode(pt);
  }

  /* ============================================================
   * SETUP CHAT KEY — admin support
   * ============================================================
   * Preserved 1:1 from the original setupE2EForAdminChat()
   * logic, generalized as an explicit helper.
   *
   *   1. Ensure my key pair + publish my public JWK.
   *   2. Try to read e2eKeys/admin.
   *      a. Present → import + derive AES key.
   *      b. Absent  → deterministic fallback: SHA-256 of
   *                   'saiko-admin-' + chatId, imported as AES.
   *
   * Returns the CryptoKey (or null on failure). The caller
   * stores it on window.chatE2EKey for the message renderer.
   * ============================================================ */
  async function setupChatKey(chatId, opts) {
    opts = opts || {};
    var peerPath = opts.peerKeyPath || 'e2eKeys/admin';
    var fallbackSeed = opts.fallbackSeed || ('saiko-admin-' + (chatId || ''));

    var uid = getMyUid();
    if (!uid) return null;
    if (!isSupported()) return null;

    try {
      /* 1) My key pair ------------------------------------- */
      var myKp = await getOrCreateMyKeyPair(uid);

      /* 2) Publish my public key --------------------------- */
      var fbDb = getDB();
      if (fbDb) {
        try {
          await fbDb.ref('e2eKeys/' + uid).set({ jwk: myKp.pubJwk, v: 1 });
        } catch (e) {
          /* Non-fatal — the peer may already have a cached
           * copy of our key. */
        }
      }

      /* 3) Fetch peer key ---------------------------------- */
      var peerJwk = null;
      if (fbDb) {
        try {
          var snap = await fbDb.ref(peerPath).get();
          var val = snap.val();
          if (val) peerJwk = val.jwk || val;
        } catch (e) {}
      }

      /* 4a) Deterministic fallback ------------------------- */
      if (!peerJwk) {
        var seed = new TextEncoder().encode(fallbackSeed);
        var hash = await crypto.subtle.digest('SHA-256', seed);
        return crypto.subtle.importKey(
          'raw', hash,
          { name: 'AES-GCM' },
          false,
          ['encrypt', 'decrypt']
        );
      }

      /* 4b) ECDH derivation -------------------------------- */
      var peerPub = await importPeerKey(peerJwk);
      return deriveAesKey(myKp.priv, peerPub);
    } catch (e) {
      return null;
    }
  }

  /* ============================================================
   * CLEAR CACHE — additive helper
   * ============================================================
   * Drops the in-memory cache so the next getOrCreateMyKeyPair
   * re-reads from localStorage. Useful on logout or after the
   * user manually resets their keys.
   * ============================================================ */
  function clearCache() {
    _keyCache = {};
    return true;
  }

  /* ============================================================
   * RESET MY KEYS — additive helper
   * ============================================================
   * Deletes the local key pair and clears the cache. The next
   * getOrCreateMyKeyPair() call regenerates a fresh pair.
   * DOES NOT delete the published Firebase public key — call
   * resetMyKeys(true) to also remove that.
   * ============================================================ */
  async function resetMyKeys(removePublished) {
    var uid = getMyUid();
    if (!uid) return false;

    try {
      localStorage.removeItem(KEY_DB_KEY + '_' + uid);
    } catch (e) {}
    clearCache();

    if (removePublished) {
      var fbDb = getDB();
      if (fbDb) {
        try { await fbDb.ref('e2eKeys/' + uid).remove(); } catch (e) {}
      }
    }
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  var api = {
    /* core crypto */
    getOrCreateMyKeyPair: getOrCreateMyKeyPair,
    importPeerKey: importPeerKey,
    deriveAesKey: deriveAesKey,
    encrypt: encrypt,
    decrypt: decrypt,
    b64: b64,
    unb64: unb64,

    /* orchestration */
    setupChatKey: setupChatKey,

    /* utility */
    isSupported: isSupported,
    clearCache: clearCache,
    resetMyKeys: resetMyKeys,

    /* constants */
    CURVE: CURVE,
    IV_BYTES: IV_BYTES,
    ENVELOPE_V: ENVELOPE_V
  };

  /* Two global names — the original source used `E2E`, later
   * modules were told to look for `SaikoE2E`. Expose both so
   * every call site (feature 112, 128, 129) works whichever
   * name it prefers. */
  window.SaikoE2E = api;
  window.E2E      = api;

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 159 — e2e-keys ready (supported=' + isSupported() + ')');
  } catch (e) {}

})();