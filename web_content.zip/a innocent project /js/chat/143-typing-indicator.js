/* ============================================================
 * FEATURE:        Typing Indicator
 * FEATURE NUMBER: 143
 * FILE:           js/chat/143-typing-indicator.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical owner of the typing-indicator subsystem. The
 *   inline implementation in the original source was spread
 *   across three places:
 *
 *     • #chatInput 'input' handler → writes
 *         chats/{chatId}/typing/{uid} = now()
 *       debounced by 3500 ms
 *
 *     • openChatById() → attaches a listener on
 *         chats/{chatId}/typing
 *       and updates #chatHeadSub with "<name> typing..."
 *       when the timestamp is fresh (< 5000 ms old)
 *
 *     • detachChat() → clears the module-scoped typingTimer
 *
 *   Feature 143 extracts that logic into one helper so any
 *   surface — send message, voice record start, image upload,
 *   future edit — can call sendTypingBeacon() without
 *   duplicating the debounce or the write path.
 *
 *   Public functions:
 *     sendTypingBeacon(chatId)     → fires the write + debounce
 *     clearTypingBeacon(chatId)    → remove the write now
 *     getTypingUsers(chatId)       → array of uids currently
 *                                    typing (fresh within TTL)
 *     isAnyoneTyping(chatId)       → boolean
 *     formatTypingText(uids)       → "Alice typing..." etc.
 *     startTypingListener(chatId)  → attach live listener
 *     detachTypingListener()       → detach
 *
 *   Behaviour preserved 1:1 from the original:
 *
 *     TYPING_TTL_MS      = 5000   (others' beacon is fresh if
 *                                  < 5000 ms old)
 *     TYPING_DEBOUNCE_MS = 3500   (our beacon is cleared 3.5 s
 *                                  after the last keystroke)
 *     Header text format = "<name> typing..." (single user) or
 *                          "<name1>, <name2> typing..." (2)
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT
 *       #chatInput 'input' handler → typing write
 *       openChatById()             → typing listener
 *       detachChat()               → typingTimer cleanup
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - window.prefs             js/prefs/prefs-core.js
 *   - findUser                 js/search/091-search-users.js
 *   - t(key) / now()           helpers
 *
 * DOM ELEMENTS USED:
 *   #chatHeadSub  — header sub-line updated when others type
 *
 * FIREBASE PATHS:
 *   chats/{chatId}/typing/{uid}     (write / remove / listen)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoTypingIndicator = {
 *     beacon, clearBeacon,
 *     getTypingUsers, isAnyoneTyping,
 *     formatTypingText,
 *     startListener, detachListener,
 *     TYPING_TTL_MS, TYPING_DEBOUNCE_MS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var TYPING_TTL_MS      = 5000;   /* freshness window for others */
  var TYPING_DEBOUNCE_MS = 3500;   /* our own beacon clears after */
  var HEADER_MAX_NAMES   = 2;      /* show at most 2 names in header */

  /* ============================================================
   * STATE
   * ============================================================ */
  var typingRef = null;
  var typingCb  = null;
  var typingTimer = null;          /* our own debounce timer     */
  var watchedChatId = null;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function userName(uid) {
    var u = findUser(uid);
    return (u && u.name) || 'User';
  }

  /* User's typing-indicator preference (features 028 / 025) */
  function isTypingIndicatorEnabled() {
    try {
      if (window.prefs && typeof window.prefs.typingIndicator === 'boolean') {
        return window.prefs.typingIndicator;
      }
    } catch (e) {}
    return true;
  }

  /* ============================================================
   * SEND — beacon write with debounce
   * ============================================================
   * Preserved from the original #chatInput 'input' handler:
   *
   *   fb.ref('chats/'+chatId+'/typing/'+uid).set(now());
   *   clearTimeout(typingTimer);
   *   typingTimer = setTimeout(() => {
   *     if(currentChatId === chatId)
   *       fb.ref('chats/'+chatId+'/typing/'+uid).remove();
   *   }, 3500);
   *
   * Silent on errors — a failed beacon never surfaces.
   * ============================================================ */
  function sendTypingBeacon(chatId) {
    if (!chatId) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    /* Respect the user's preference -------------------- */
    if (!isTypingIndicatorEnabled()) return false;

    /* Initial write ------------------------------------ */
    try {
      fbDb.ref('chats/' + chatId + '/typing/' + uid)
        .set(timeNow()).catch(function () {});
    } catch (e) {
      return false;
    }

    /* Debounced removal -------------------------------- */
    if (typingTimer) clearTimeout(typingTimer);
    typingTimer = setTimeout(function () {
      typingTimer = null;
      /* Only clear if the user is still in the same chat */
      if (window.currentChatId === chatId) {
        try {
          fbDb.ref('chats/' + chatId + '/typing/' + uid)
            .remove().catch(function () {});
        } catch (e) {}
      }
    }, TYPING_DEBOUNCE_MS);

    return true;
  }

  /* ============================================================
   * CLEAR — force-remove the beacon immediately
   * ============================================================
   * Called on send (feature 112 already does this), on chat
   * close, and by any caller that wants to cancel the beacon.
   * ============================================================ */
  function clearTypingBeacon(chatId) {
    var cid = chatId || window.currentChatId;
    if (!cid) return false;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    /* Cancel any pending debounce ---------------------- */
    if (typingTimer) {
      clearTimeout(typingTimer);
      typingTimer = null;
    }

    try {
      fbDb.ref('chats/' + cid + '/typing/' + uid)
        .remove().catch(function () {});
    } catch (e) {
      return false;
    }
    return true;
  }

  /* ============================================================
   * READ — pull the live typing map and filter by freshness
   * ============================================================
   * Preserved from the original listener filter:
   *   Object.keys(v).filter(u => u !== myUid &&
   *     (now() - (v[u]||0) < 5000))
   * ============================================================ */
  function getTypingUsers(chatId) {
    var cid = chatId || window.currentChatId;
    if (!cid) return [];

    var fbDb = getDB();
    if (!fbDb) return [];

    /* The listener keeps the map cached in a module-scoped
     * object; getTypingUsers reads from that cache. */
    var v = _typingMap || {};
    var uid = getMyUid();
    var nowTs = timeNow();
    var out = [];
    var keys = Object.keys(v);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (k === uid) continue;
      if (nowTs - (v[k] || 0) < TYPING_TTL_MS) out.push(k);
    }
    return out;
  }

  function isAnyoneTyping(chatId) {
    return getTypingUsers(chatId).length > 0;
  }

  /* ============================================================
   * FORMAT — "<name> typing..." style header text
   * ============================================================
   * Preserved from the original:
   *   const nm = others.map(u => userName(u)).slice(0,2).join(', ');
   *   sub.textContent = nm + ' ' + t('typing');
   *
   * Returns '' when nobody is typing.
   * ============================================================ */
  function formatTypingText(uids) {
    if (!uids || !uids.length) return '';
    var names = uids.map(userName).slice(0, HEADER_MAX_NAMES).join(', ');
    return names + ' ' + T('typing');
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================ */
  var _typingMap = {};

  function startListener(chatId) {
    if (!chatId) return false;

    /* Detach any previous listener ---------------------- */
    detachListener();

    var fbDb = getDB();
    if (!fbDb) return false;

    watchedChatId = chatId;
    typingRef = fbDb.ref('chats/' + chatId + '/typing');
    typingCb  = typingRef.on('value', function (s) {
      _typingMap = s.val() || {};

      /* Update the header sub-line --------------------- */
      var others = getTypingUsers(chatId);
      var sub = qs('#chatHeadSub');
      if (!sub) return;

      /* Only show typing status in direct chats -------- */
      var c = (window.chatMeta && window.chatMeta[chatId]) || null;
      if (!c || c.type === 'group') return;

      if (others.length) {
        sub.textContent = formatTypingText(others);
      } else {
        /* Restore the normal header sub-line. Feature 112
         * set it when the chat opened; if the chat meta
         * listener is still alive it will re-set it on the
         * next meta tick. We only nudge it back to the
         * friend's last-seen style if we still have peer
         * info handy. */
        var peerUid = window.chatPeerUid;
        if (peerUid) {
          var pu = findUser(peerUid);
          var isOn = peerUid && window.onlineUsers && window.onlineUsers[peerUid];
          var sub2 = '';
          if (isOn) sub2 = T('online');
          else if (pu && pu.lastSeen) {
            sub2 = T('offline') + ' · ' +
              (typeof window.timeAgo === 'function' ? window.timeAgo(pu.lastSeen) : '');
          } else sub2 = T('offline');
          sub.textContent = sub2;
        }
      }
    });

    return true;
  }

  function detachListener() {
    if (typingRef && typingCb) {
      try { typingRef.off('value', typingCb); } catch (e) {}
    }
    typingRef = null;
    typingCb  = null;
    watchedChatId = null;
    _typingMap = {};

    /* Cancel our own outbound debounce too -------------- */
    if (typingTimer) {
      clearTimeout(typingTimer);
      typingTimer = null;
    }
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoTypingIndicator = {
    /* outbound */
    beacon: sendTypingBeacon,
    clearBeacon: clearTypingBeacon,

    /* inbound */
    getTypingUsers: getTypingUsers,
    isAnyoneTyping: isAnyoneTyping,
    formatTypingText: formatTypingText,
    startListener: startListener,
    detachListener: detachListener,

    /* introspection */
    getWatchedChatId: function () { return watchedChatId; },
    getMap: function () { return _typingMap; },

    /* constants */
    TYPING_TTL_MS: TYPING_TTL_MS,
    TYPING_DEBOUNCE_MS: TYPING_DEBOUNCE_MS
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 143 — typing-indicator ready');
  } catch (e) {}

})();