/* ============================================================
 * FEATURE:        Message Delete (for Me / for Everyone)
 * FEATURE NUMBER: 134
 * FILE:           js/chat/134-msg-delete.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper that owns both delete paths for a chat
 *   message:
 *
 *     1. DELETE FOR ME
 *          deleteForMe(mid)
 *            — write messageHides/{myUid}/{chatId}/{mid} = true
 *            — remove the bubble from the DOM immediately
 *            — no confirm dialog (matches original)
 *            — no Firebase message deletion (other members
 *              still see the message)
 *
 *     2. DELETE FOR EVERYONE
 *          deleteForEveryone(mid)
 *            — confirm dialog
 *            — update messages/{chatId}/{mid} with
 *              { deleted:true, text:'', url:'', updatedAt: now() }
 *            — the bubble stays, but renders as the italic
 *              "message_deleted" placeholder via feature 128
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'delme') {
 *       await db.ref('messageHides/'+myUid+'/'+cid+'/'+mid)
 *               .set(true).catch(()=>{});
 *       const node = $('[data-mid="'+mid+'"]');
 *       if (node) node.remove();
 *     }
 *     else if (k === 'delall') {
 *       const ok = await confirmDialog(t('delete_for_everyone'),
 *                                       t('are_you_sure'));
 *       if (!ok) return;
 *       await db.ref('messages/'+cid+'/'+mid).update({
 *         deleted: true, text: '', url: '', updatedAt: now()
 *       }).catch(e => toast(e.message, 'err'));
 *     }
 *
 *   Notes on the semantics preserved:
 *     • deleteForMe is silent (no confirm, no toast) — the
 *       bubble disappearing is the feedback.
 *     • deleteForEveryone requires a confirm dialog and, on
 *       write failure, toasts the error.
 *     • Admin-support chats use their own message path
 *       (adminChats/{chatId}/messages). The original delete
 *       flow did not special-case it for delme (the hide map
 *       lives under messageHides/{uid}/{cid}/{mid}) but did
 *       for delall (updating the message row). This helper
 *       preserves both: delme writes messageHides; delall
 *       skips when the chat is admin support (E2E encrypted
 *       rows cannot be redacted this way).
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu() → case 'delme' /
 *                        case 'delall'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - window.currentChatId   feature 112 (live)
 *   - window.chatIsAdminSupport  feature 112 (live)
 *   - confirmDialog          js/nav/043-confirm-dialog.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key) / now()         helpers
 *
 * DOM ELEMENTS USED:
 *   [data-mid="<mid>"]       (bubble node removed on delme)
 *
 * FIREBASE PATHS:
 *   messageHides/{uid}/{chatId}/{mid}    (set true — delme)
 *   messages/{chatId}/{mid}              (update — delall)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.deleteMessageForMe         (new — canonical)
 *   window.deleteMessageForEveryone   (new — canonical)
 *   window.SaikoMsgDelete = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    /* Missing confirmDialog → treat as confirm so the flow is
     * never blocked (mirrors every other feature file). */
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * DELETE FOR ME — silent hide
   * ============================================================
   * Preserved 1:1 from the original `case 'delme'` branch:
   *   • write messageHides/{uid}/{chatId}/{mid} = true
   *   • remove the bubble from the DOM
   *   • no confirm, no toast
   * ============================================================ */
  async function deleteForMe(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    var uid    = getMyUid();
    var fbDb   = getDB();
    if (!chatId || !uid || !fbDb) return false;

    /* 1) Persist the hide marker ------------------------- */
    try {
      await fbDb.ref('messageHides/' + uid + '/' + chatId + '/' + mid).set(true);
    } catch (e) {
      /* Original swallowed errors silently. Preserved. */
      return false;
    }

    /* 2) Remove the bubble from the DOM ------------------ */
    var node = qs('[data-mid="' + mid + '"]');
    if (node && node.parentNode) {
      try { node.parentNode.removeChild(node); } catch (e) {}
    }

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-deleted-for-me', {
        detail: { messageId: mid, chatId: chatId }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * DELETE FOR EVERYONE — redact the message row
   * ============================================================
   * Preserved 1:1 from the original `case 'delall'` branch:
   *   • confirm dialog
   *   • update messages/{chatId}/{mid} with
   *         { deleted:true, text:'', url:'', updatedAt: now() }
   *   • on write failure, toast the error
   *
   * Admin-support chats are skipped — those rows live under
   * adminChats/{chatId}/messages and are E2E encrypted; a
   * plaintext redaction would desync the ciphertext contract.
   * The original menu already hid the "delete for everyone"
   * option on admin-support chats, so this skip is defensive.
   * ============================================================ */
  async function deleteForEveryone(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    var fbDb   = getDB();
    if (!chatId || !fbDb) return false;

    /* Skip admin-support chats (E2E) --------------------- */
    if (window.chatIsAdminSupport) return false;

    /* 1) Confirm ----------------------------------------- */
    var ok = await askConfirm(T('delete_for_everyone'), T('are_you_sure'));
    if (!ok) return false;

    /* 2) Redact the message row -------------------------- */
    try {
      await fbDb.ref('messages/' + chatId + '/' + mid).update({
        deleted: true,
        text: '',
        url: '',
        updatedAt: timeNow()
      });
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-deleted-for-everyone', {
        detail: { messageId: mid, chatId: chatId }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.deleteMessageForMe       = deleteForMe;
  window.deleteMessageForEveryone = deleteForEveryone;

  window.SaikoMsgDelete = {
    forMe: deleteForMe,
    forEveryone: deleteForEveryone
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 134 — msg-delete ready');
  } catch (e) {}

})();