/* ============================================================
 * FEATURE:        Message Reply
 * FEATURE NUMBER: 130
 * FILE:           js/chat/130-msg-reply.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for starting, previewing, and cancelling a
 *   reply to a specific chat message. Extracts the reply
 *   branch that lives inline inside feature 112's message
 *   menu (openMessageMenu's `case 'reply'`) so any future
 *   surface (message list, long-press sheet, forwarded
 *   messages, story replies) can trigger the same flow.
 *
 *   Responsibilities:
 *
 *     1. START
 *          startReply(mid) — reads the message from the live
 *          window.chatMessages map, builds a preview string,
 *          stores it on window.replyMsg, calls
 *          showReplyBar() (feature 112) and focuses the input.
 *
 *     2. PREVIEW BUILDING
 *          buildPreview(m) — collapses a message into a short
 *          single-line preview:
 *              text   → first 90 chars
 *              image  → "📷"
 *              voice  → "🎤"
 *              poll   → poll question (first 90 chars)
 *              deleted → t('message_deleted')
 *          Falls back to '' when nothing useful can be shown.
 *
 *     3. CANCEL
 *          cancelReply() — clears window.replyMsg and hides
 *          the reply bar (delegates to feature 112's
 *          hideReplyBar).
 *
 *     4. RE-OPEN
 *          getReply() / hasReply() — state readers for other
 *          modules that need to inspect the current reply
 *          target without touching the DOM.
 *
 *   Behaviour preserved 1:1 from the original reply branch:
 *
 *     replyMsg = {
 *       id:   mid,
 *       name: userName(m.from),
 *       text: (m.text||'').slice(0,90) ||
 *             (m.type==='image' ? '📷' :
 *              (m.type==='voice' ? '🎤' : ''))
 *     };
 *     showReplyBar();
 *     $('#chatInput').focus();
 *
 *   Send-time context (msg.replyTo / msg.replyName) is handled
 *   inside feature 112's sendMessage(); this module only owns
 *   the pre-send side.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu() → case 'reply'
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.chatMessages        feature 112 (live map)
 *   - window.replyMsg            feature 112 (shared state)
 *   - showReplyBar / hideReplyBar  feature 112
 *   - userName(uid)              feature 091 (safely-called)
 *
 * DOM ELEMENTS USED:
 *   #chatInput — focused after startReply
 *   #replyBar  — rendered by feature 112's showReplyBar
 *
 * FIREBASE PATHS:
 *   none — the write happens in feature 112's sendMessage()
 *   when window.replyMsg is populated.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.startReply          (new — canonical)
 *   window.cancelReply         (new — canonical)
 *   window.SaikoMsgReply = {
 *     start, cancel, buildPreview,
 *     getReply, hasReply,
 *     MAX_PREVIEW
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var MAX_PREVIEW = 90;   /* matches original .slice(0, 90) */

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-reply] safeCall:', name, e); }
    return undefined;
  }
  function userName(uid) {
    try {
      if (typeof window.userName === 'function') return window.userName(uid);
    } catch (e) {}
    try {
      if (typeof window.findUser === 'function') {
        var u = window.findUser(uid);
        if (u && u.name) return u.name;
      }
    } catch (e2) {}
    return 'User';
  }

  /* ============================================================
   * BUILD PREVIEW
   * ============================================================
   * Pure — collapses a message object into a short single-line
   * preview for the reply bar.
   *
   * Preserved 1:1 from the original expression:
   *   (m.text||'').slice(0,90) ||
   *     (m.type==='image' ? '📷' :
   *      (m.type==='voice' ? '🎤' : ''))
   *
   * Extended (additive, does not change the original output
   * for text/image/voice messages) to also handle:
   *   • deleted → t('message_deleted')
   *   • poll    → poll question (first 90 chars)
   * ============================================================ */
  function buildPreview(m) {
    if (!m) return '';

    /* Deleted messages have no text to preview. */
    if (m.deleted) return T('message_deleted');

    /* Prefer the text field if present. */
    var text = (m.text || '').slice(0, MAX_PREVIEW);
    if (text) return text;

    /* Fallback by type. */
    if (m.type === 'image') return '📷';
    if (m.type === 'voice') return '🎤';
    if (m.type === 'poll' && m.poll && m.poll.q) {
      return String(m.poll.q).slice(0, MAX_PREVIEW);
    }
    return '';
  }

  /* ============================================================
   * START — the canonical reply trigger
   * ============================================================
   * Preserved 1:1 from the original `case 'reply'` branch:
   *   replyMsg = {
   *     id:   mid,
   *     name: userName(m.from),
   *     text: buildPreview(m)
   *   };
   *   showReplyBar();
   *   $('#chatInput').focus();
   * ============================================================ */
  function start(mid) {
    if (!mid) return false;

    var m = (window.chatMessages && window.chatMessages[mid]) || null;
    if (!m) return false;

    window.replyMsg = {
      id: mid,
      name: userName(m.from),
      text: buildPreview(m)
    };

    /* Delegate the reply-bar render to feature 112 ---------- */
    safeCall('showReplyBar');

    /* Focus the input so the user can start typing --------- */
    var input = qs('#chatInput');
    if (input && typeof input.focus === 'function') {
      try { input.focus(); } catch (e) {}
    }

    /* Notify subscribers (additive) ------------------------ */
    try {
      window.dispatchEvent(new CustomEvent('saiko:chat-reply-started', {
        detail: { messageId: mid }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * CANCEL — clear the reply target
   * ============================================================
   * Preserved 1:1 from the original cancelReply click inside
   * feature 112's showReplyBar() (which called hideReplyBar()).
   * ============================================================ */
  function cancel() {
    var had = !!window.replyMsg;
    window.replyMsg = null;

    safeCall('hideReplyBar');

    if (had) {
      try {
        window.dispatchEvent(new CustomEvent('saiko:chat-reply-cancelled'));
      } catch (e) {}
    }
    return true;
  }

  /* ============================================================
   * STATE READERS (additive)
   * ============================================================ */
  function getReply() {
    return window.replyMsg || null;
  }

  function hasReply() {
    return !!window.replyMsg;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.startReply  = start;
  window.cancelReply = cancel;

  window.SaikoMsgReply = {
    start: start,
    cancel: cancel,
    buildPreview: buildPreview,
    getReply: getReply,
    hasReply: hasReply,
    MAX_PREVIEW: MAX_PREVIEW
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 130 — msg-reply ready');
  } catch (e) {}

})();