/* ============================================================
 * FEATURE:        Chat Info Menu (⋯ button)
 * FEATURE NUMBER: 149
 * FILE:           js/chat/149-chat-info-menu.js
 * ACTION:         REPLACE (v3 — z-index fix)
 * ============================================================ */

(function () {
  'use strict';

  function qs(s, r) { return (r || document).querySelector(s); }
  function qsa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c];
    });
  }
  function getDB() { try { if (typeof db !== 'undefined' && db) return db; } catch (e) {} return null; }
  function getUid() { try { return window.myUid || null; } catch (e) { return null; } }
  function safeCall(n, a) {
    try {
      var f = window[n];
      if (typeof f === 'function') return f.apply(window, a || []);
    } catch (e) { console.warn('[chat-info] safeCall', n, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); }
    catch (e) {}
  }
  function userPhoto(uid) { try { return window.userPhoto ? window.userPhoto(uid) : ''; } catch (e) { return ''; } }
  function userName(uid) { try { return window.userName ? window.userName(uid) : 'User'; } catch (e) { return 'User'; } }
  function getNickname(chatId, uid) { try { return window.getNickname ? window.getNickname(chatId, uid) : null; } catch (e) { return null; } }
  function setNickname(chatId, uid, nick) { try { return window.setNickname ? window.setNickname(chatId, uid, nick) : Promise.resolve(); } catch (e) { return Promise.resolve(); } }
  function isSmsBlocked(uid) { try { return window.isSmsBlocked ? window.isSmsBlocked(uid) : false; } catch (e) { return false; } }
  function isCallBlocked(uid) { try { return window.isCallBlocked ? window.isCallBlocked(uid) : false; } catch (e) { return false; } }

  /* ---------- Inline avatar ---------- */
  function makeAvatar(url, name, size) {
    size = size || 88;
    var px = size + 'px';
    var fontSize = Math.round(size * 0.38) + 'px';
    var init = (String(name || 'User').trim().charAt(0) || '?').toUpperCase();
    var hasUrl = url && String(url).trim().length > 0;
    var box = 'width:' + px + ';height:' + px + ';min-width:' + px + ';min-height:' + px +
      ';border-radius:50%;overflow:hidden;position:relative;display:inline-flex;' +
      'align-items:center;justify-content:center;background:#1c2030;color:#8b93a7;' +
      'font-weight:800;font-size:' + fontSize + ';border:1.5px solid rgba(255,255,255,.12);';
    var inner = '<span style="position:absolute;inset:0;display:flex;align-items:center;' +
      'justify-content:center;color:#8b93a7;font-weight:800;font-size:' + fontSize + ';">' +
      esc(init) + '</span>';
    if (hasUrl) {
      inner += '<img src="' + esc(String(url).trim()) + '" alt="" ' +
        'style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;" ' +
        'onerror="this.style.display=\'none\';" onload="this.style.display=\'block\';">';
    }
    return '<div style="' + box + '">' + inner + '</div>';
  }

  /* ============================================================
   * Self-contained confirm dialog
   * FIX: use openOverlay/closeOverlay so z-index auto-boosts
   * above the currently open Chat Info overlay.
   * ============================================================ */
  function askConfirm(title, text) {
    return new Promise(function (resolve) {
      var ov = qs('#ovConfirm');
      var titleEl = qs('#confirmTitle');
      var textEl = qs('#confirmText');
      var yes = qs('#confirmYes');
      var no = qs('#confirmNo');

      if (!ov || !titleEl || !textEl || !yes || !no) {
        try { resolve(window.confirm(String(title || '') + '\n' + String(text || ''))); }
        catch (e) { resolve(true); }
        return;
      }

      titleEl.textContent = title || '';
      textEl.textContent = text || '';

      /* KEY FIX — go through openOverlay so the shared z-index
       * auto-boost applies and the dialog sits ABOVE Chat Info. */
      if (typeof window.openOverlay === 'function') {
        window.openOverlay('ovConfirm');
      } else {
        ov.classList.add('open');
      }

      var done = false;
      function finish(v) {
        if (done) return;
        done = true;
        if (typeof window.closeOverlay === 'function') {
          window.closeOverlay('ovConfirm');
        } else {
          ov.classList.remove('open');
        }
        yes.removeEventListener('click', onYes);
        no.removeEventListener('click', onNo);
        resolve(v);
      }
      function onYes() { finish(true); }
      function onNo() { finish(false); }
      yes.addEventListener('click', onYes);
      no.addEventListener('click', onNo);
    });
  }

  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') {
        return window.promptDialog(title, defValue, placeholder);
      }
    } catch (e) {}
    var v = window.prompt(String(title || ''), String(defValue || ''));
    return Promise.resolve(v);
  }

  function row(key, icon, label, mark) {
    return '<div class="side-item" data-ci="' + key + '">' +
      '<span class="ic" style="font-size:1.1rem;width:1.4rem;text-align:center;">' + icon + '</span>' +
      '<div class="grow">' + esc(label) + (mark ? ' <span style="color:var(--accent);font-weight:700">' + mark + '</span>' : '') + '</div>' +
      '<span class="ic" style="color:var(--muted)">›</span>' +
    '</div>';
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function openChatInfoMenu() {
    var chatId = window.currentChatId;
    if (!chatId) { safeToast('No chat open', 'err'); return; }

    var c = (window.chatMeta && window.chatMeta[chatId]) || null;
    if (!c) { safeToast('Chat info missing', 'err'); return; }

    if (c.type === 'group') { safeCall('openGroupInfo', [chatId]); return; }

    var peerUid = window.chatPeerUid;
    if (!peerUid) { safeToast('Peer missing', 'err'); return; }

    var smsBlk = isSmsBlocked(peerUid);
    var callBlk = isCallBlocked(peerUid);
    var nick = getNickname(chatId, peerUid);
    var muted = c.muted && c.muted[getUid()];

    var body = qs('#chatInfoBody');
    if (!body) { safeToast('#chatInfoBody missing', 'err'); return; }

    body.innerHTML =
      '<div class="prof-head" style="display:flex;flex-direction:column;align-items:center;gap:.5rem;padding:1rem">' +
        makeAvatar(userPhoto(peerUid), userName(peerUid), 88) +
        '<div style="font-size:1.15rem;font-weight:800;margin-top:.4rem">' +
          esc(nick || userName(peerUid)) +
        '</div>' +
        (nick ? '<div style="font-size:.76rem;color:#8b93a7">' + esc(userName(peerUid)) + '</div>' : '') +
      '</div>' +

      row('nickname', '@',   T('set_nickname'), nick ? '✓' : '') +
      row('profile',  '👤', T('profile'), '') +
      row('theme',    '🎨', T('theme'), '') +
      row('mute',     '🔔', muted ? T('unmute') : T('mute'), '') +
      row('sms',      '💬', T('sms_block'),  smsBlk ? '✓ Blocked' : '') +
      row('call',     '📵', T('call_block'), callBlk ? '✓ Blocked' : '') +
      row('clear',    '🗑',  T('clear_chat'), '') +
      row('restore',  '♻️', 'Restore Chat', '');

    safeCall('openOverlay', ['ovChatInfo']);

    qsa('[data-ci]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var k = n.getAttribute('data-ci');
        handleAction(k, chatId, peerUid, c, nick);
      });
    });
  }

  /* ============================================================
   * ACTIONS
   * ============================================================ */
  async function handleAction(k, chatId, peerUid, c, currentNick) {
    var fbDb = getDB();
    var uid = getUid();
    if (!fbDb || !uid) { safeToast('Not signed in', 'err'); return; }

    try {
      if (k === 'nickname') {
        var inp = await askPrompt(T('set_nickname') + ' — ' + userName(peerUid), currentNick || '', T('nickname_hint'));
        if (inp === null) return;
        await setNickname(chatId, peerUid, inp);
        safeCall('closeOverlay', ['ovChatInfo']);
        setTimeout(openChatInfoMenu, 200);
        return;
      }

      if (k === 'profile') {
        safeCall('closeOverlay', ['ovChatInfo']);
        safeCall('openUserProfile', [peerUid]);
        return;
      }

      if (k === 'theme') {
        safeCall('closeOverlay', ['ovChatInfo']);
        safeCall('openChatThemePicker', [chatId]);
        return;
      }

      if (k === 'mute') {
        var cur = !!(c.muted && c.muted[uid]);
        if (cur) {
          await fbDb.ref('chats/' + chatId + '/muted/' + uid).remove();
          safeToast(T('chat_unmuted'), 'ok');
        } else {
          await fbDb.ref('chats/' + chatId + '/muted/' + uid).set(true);
          safeToast(T('chat_muted'), 'ok');
        }
        safeCall('closeOverlay', ['ovChatInfo']);
        setTimeout(openChatInfoMenu, 200);
        return;
      }

      if (k === 'sms') {
        var smsCur = isSmsBlocked(peerUid);
        if (smsCur) {
          await fbDb.ref('smsBlocks/' + uid + '/' + peerUid).remove();
          safeToast(T('unblocked'), 'ok');
        } else {
          var ok1 = await askConfirm(T('sms_block'), T('block_sms_confirm'));
          if (!ok1) return;
          await fbDb.ref('smsBlocks/' + uid + '/' + peerUid).set(true);
          safeToast(T('sms_blocked'), 'ok');
        }
        safeCall('closeOverlay', ['ovChatInfo']);
        setTimeout(openChatInfoMenu, 300);
        return;
      }

      if (k === 'call') {
        var callCur = isCallBlocked(peerUid);
        if (callCur) {
          await fbDb.ref('callBlocks/' + uid + '/' + peerUid).remove();
          safeToast(T('unblocked'), 'ok');
        } else {
          var ok2 = await askConfirm(T('call_block'), T('block_call_confirm'));
          if (!ok2) return;
          await fbDb.ref('callBlocks/' + uid + '/' + peerUid).set(true);
          safeToast(T('calls_blocked'), 'ok');
        }
        safeCall('closeOverlay', ['ovChatInfo']);
        setTimeout(openChatInfoMenu, 300);
        return;
      }

      if (k === 'clear') {
        var ok3 = await askConfirm(T('clear_chat'), T('are_you_sure'));
        if (!ok3) return;
        var snap = await fbDb.ref('messages/' + chatId).get();
        var v = snap.val() || {};
        var updates = {};
        Object.keys(v).forEach(function (mid) {
          updates['messageHides/' + uid + '/' + chatId + '/' + mid] = true;
        });
        if (Object.keys(updates).length) await fbDb.ref().update(updates);

        var chatBody = qs('#chatBody');
        if (chatBody) chatBody.innerHTML = '';

        safeCall('closeOverlay', ['ovChatInfo']);
        safeToast(T('saved'), 'ok');
        return;
      }

      if (k === 'restore') {
        var ok4 = await askConfirm('Restore Chat', 'Bring back all cleared messages in this chat?');
        if (!ok4) return;

        await fbDb.ref('messageHides/' + uid + '/' + chatId).remove();

        safeCall('closeOverlay', ['ovChatInfo']);
        safeToast('Chat restored', 'ok');

        setTimeout(function () {
          if (typeof window.openChatById === 'function') {
            window.openChatById(chatId);
          }
        }, 400);
        return;
      }
    } catch (err) {
      console.error('[chat-info] action error:', err);
      safeToast((err && err.message) ? err.message : 'Action failed', 'err');
    }
  }

  /* ============================================================
   * BIND
   * ============================================================ */
  var _bound = false;
  function bind() {
    if (_bound) return;
    var btn = qs('#btnChatInfo');
    if (!btn) return;
    _bound = true;
    btn.addEventListener('click', function (e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      openChatInfoMenu();
    });
  }

  window.openChatInfoMenu = openChatInfoMenu;
  window.SaikoChatInfo = {
    open: openChatInfoMenu,
    bind: bind
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  try { console.debug('[boot] feature 149 — chat-info-menu ready (v3 z-index fix)'); } catch (e) {}
})();