/* ============================================================
 * FEATURE:        Message Star / Unstar
 * FEATURE NUMBER: 135
 * FILE:           js/chat/135-msg-star.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for the ⭐ star / unstar toggle on a chat
 *   message. Extracts the "star" branch that lives inline
 *   inside feature 145's openMessageMenu() so any future
 *   surface (message list, long-press sheet, search results,
 *   pinned preview) can trigger the same flow.
 *
 *   Responsibilities:
 *
 *     1. LIVE MAP
 *          window.starredMsgs — { [mid]: { chatId, at } }
 *          A live listener on starredMessages/{myUid} keeps the
 *          map fresh so every bubble can render the star badge
 *          (feature 128 reads via isMsgStarred).
 *
 *     2. PREDICATE
 *          isMsgStarred(mid) — true when the message is
 *                              currently starred.
 *
 *     3. TOGGLE
 *          toggleStar(mid)
 *            — if starred: remove the entry
 *                          + toast t('message_unstarred')
 *            — otherwise : set  { chatId, at: now() }
 *                          + toast t('message_starred')
 *            — re-render the affected bubble in place so the
 *              ⭐ badge appears / disappears immediately.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'star') {
 *       const ref = db.ref('starredMessages/'+myUid+'/'+mid);
 *       const snap = await ref.get();
 *       if (snap.exists()) {
 *         await ref.remove();
 *         toast(t('message_unstarred'), 'ok');
 *       } else {
 *         await ref.set({ chatId: cid, at: now() });
 *         toast(t('message_starred'), 'ok');
 *       }
 *       const node = $('[data-mid="'+mid+'"]');
 *       if (node) renderMessage(mid, chatMessages[mid], false);
 *     }
 *
 *   Notes on the semantics preserved:
 *     • The live listener that populates `window.starredMsgs`
 *       originally lived in the auth-side `listenBlocked()`
 *       block (db.ref('starredMessages/'+myUid).on('value',...)).
 *       We keep it here as an explicit start/detach pair so the
 *       boot orchestrator can call it cleanly.
 *     • The bubble re-render uses feature 128's renderMessage
 *       with isNew=false so no date separator is inserted and
 *       no scroll jump occurs.
 *     • Admin-support chats are NOT special-cased — the star
 *       map is a per-user flag and works identically.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §10 AUTH side    → starredMsgs map + listener
 *     Section §22 CHAT         → openMessageMenu() → case 'star'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - myUid                  js/auth/004-auth-state.js
 *   - window.currentChatId   feature 112 (live)
 *   - window.chatMessages    feature 112 (live map)
 *   - renderMessage          js/chat/128-message-render.js
 *   - toast                  js/nav/042-toast.js
 *   - t(key) / now()         helpers
 *
 * DOM ELEMENTS USED:
 *   [data-mid="<mid>"]       (bubble node re-rendered in place)
 *
 * FIREBASE PATHS:
 *   starredMessages/{uid}                 (read + listen)
 *   starredMessages/{uid}/{mid}           (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.starredMsgs              (live map)
 *   window.isMsgStarred             (original name preserved)
 *   window.startStarredMsgsListener (additive)
 *   window.detachStarredMsgsListener(additive)
 *   window.toggleMsgStar            (new — canonical)
 *   window.SaikoMsgStar = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE — live map exposed on window
   * ============================================================ */
  var starredRef = null;
  var starredCb  = null;

  window.starredMsgs = window.starredMsgs || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-star] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * PREDICATE — isMsgStarred(mid)
   * ============================================================ */
  function isMsgStarred(mid) {
    if (!mid) return false;
    return !!window.starredMsgs[mid];
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================
   * Attaches a live listener on starredMessages/{myUid}. Every
   * change refreshes window.starredMsgs so any bubble already
   * in the DOM can render its ⭐ badge on the next paint.
   * ============================================================ */
  function startListener() {
    if (starredRef && starredCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    starredRef = fbDb.ref('starredMessages/' + uid);
    starredCb = starredRef.on('value', function (s) {
      window.starredMsgs = s.val() || {};
      /* Repaint every visible bubble's star badge ---------- */
      var nodes = document.querySelectorAll('[data-mid]');
      for (var i = 0; i < nodes.length; i++) {
        var mid = nodes[i].getAttribute('data-mid');
        if (!mid) continue;
        var m = (window.chatMessages && window.chatMessages[mid]) || null;
        if (m) safeCall('renderMessage', [mid, m, false]);
      }
    });
    return true;
  }

  function detachListener() {
    if (starredRef && starredCb) {
      try { starredRef.off('value', starredCb); } catch (e) {}
    }
    starredRef = null;
    starredCb  = null;
    window.starredMsgs = {};
    return true;
  }

  /* ============================================================
   * TOGGLE — main entry
   * ============================================================
   * Preserved 1:1 from the original `case 'star'` branch:
   *   • read the current node
   *   • if starred  → remove  + toast t('message_unstarred')
   *   • otherwise   → set { chatId, at: now() }
   *                   + toast t('message_starred')
   *   • re-render the bubble in place with isNew=false
   * ============================================================ */
  async function toggleStar(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    var uid    = getMyUid();
    var fbDb   = getDB();
    if (!uid || !fbDb) return false;

    var ref = fbDb.ref('starredMessages/' + uid + '/' + mid);

    try {
      var snap = await ref.get();

      if (snap.exists()) {
        /* === Unstar ====================================== */
        await ref.remove();
        safeToast(T('message_unstarred'), 'ok');
      } else {
        /* === Star ======================================== */
        await ref.set({ chatId: chatId || '', at: timeNow() });
        safeToast(T('message_starred'), 'ok');
      }
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }

    /* Re-render the bubble in place so the ⭐ badge updates
     * immediately, without waiting for the listener tick. */
    var node = qs('[data-mid="' + mid + '"]');
    if (node) {
      var m = (window.chatMessages && window.chatMessages[mid]) || null;
      if (m) safeCall('renderMessage', [mid, m, false]);
    }

    /* Notify subscribers (additive) ------------------------ */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-star-changed', {
        detail: { messageId: mid, starred: !snap || !snap.exists() }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.isMsgStarred              = isMsgStarred;
  window.toggleMsgStar             = toggleStar;
  window.startStarredMsgsListener  = startListener;
  window.detachStarredMsgsListener = detachListener;

  window.SaikoMsgStar = {
    isStarred: isMsgStarred,
    toggle: toggleStar,
    startListener: startListener,
    detachListener: detachListener,
    getMap: function () { return window.starredMsgs; },
    getCount: function () { return Object.keys(window.starredMsgs || {}).length; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 135 — msg-star ready');
  } catch (e) {}

})();