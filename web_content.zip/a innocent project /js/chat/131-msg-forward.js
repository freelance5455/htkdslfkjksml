/* ============================================================
 * FEATURE:        Message Forward
 * FEATURE NUMBER: 131
 * FILE:           js/chat/131-msg-forward.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "Forward" flow for a chat message. Handles:
 *
 *     1. OPEN
 *          openForwardPicker(mid) — renders a user-picker
 *          into #pickerBody with #data-fwd rows, wires each row
 *          to clone the source message into a new direct chat
 *          with the tapped user, and opens #ovPicker.
 *
 *     2. ROW CLICK
 *          • resolve source message from window.chatMessages
 *          • ensureDirectChat(targetUid) → chatId
 *          • push a NEW message into messages/{chatId}
 *            carrying the source message's type / text / url /
 *            dur (fresh id, fresh createdAt, fresh readBy)
 *          • updateChatMeta on the new chat with a preview
 *          • toast t('message_forwarded') on success
 *          • toast the error on failure
 *
 *   Behaviour preserved 1:1 from the original §22 block.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openForwardPicker(mid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid / myProfile        js/auth/004-auth-state.js
 *   - t / esc / now            helpers
 *   - svgIcon                  js/nav/045-icon-system.js
 *   - avatarHTML               js/core/utils.js
 *   - openOverlay / closeOverlay (038)
 *   - toast                    js/nav/042-toast.js
 *   - ensureDirectChat (114)   js/inbox/114-new-direct-chat.js
 *   - updateChatMeta (112)     js/inbox/112-chat-open.js
 *
 * DOM ELEMENTS USED:
 *   #ovPicker, #pickerTitle, #pickerDone, #pickerBody
 *
 * FIREBASE PATHS:
 *   messages/{chatId}                (write — the forwarded copy)
 *   chats/{chatId}                   (via ensureDirectChat +
 *                                     via updateChatMeta)
 *   userChats/{uid}/{chatId}         (via ensureDirectChat)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openForwardPicker      (original name preserved)
 *   window.SaikoMsgForward = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-forward] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMyProfile() {
    try { return (typeof window.myProfile !== 'undefined') ? window.myProfile : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }

  /* ============================================================
   * OPEN — main entry
   * ============================================================
   * Preserved 1:1 from the original openForwardPicker(mid):
   *   • set picker title to t('forward')
   *   • hide #pickerDone (single-select, immediate action)
   *   • render search bar + user list into #pickerBody
   *   • wire each [data-fwd] row to clone the source message
   *     into a new direct chat with the tapped user
   *   • open the overlay
   * ============================================================ */
  function open(mid) {
    if (!mid) return false;

    var body = qs('#pickerBody');
    if (!body) return false;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return false;

    /* ---- Title + done button ---------------------------- */
    var titleEl = qs('#pickerTitle');
    if (titleEl) titleEl.textContent = T('forward');

    var doneEl = qs('#pickerDone');
    if (doneEl) doneEl.classList.add('hidden');

    /* ---- Render skeleton -------------------------------- */
    body.innerHTML =
      '<div class="searchbar">' +
        '<span class="ic">' + svgIcon('search') + '</span>' +
        '<input type="search" id="pickerSearch" ' +
               'placeholder="' + esc(T('search_users_ph')) + '">' +
      '</div>' +
      '<div id="pickerList"></div>';

    var list = qs('#pickerList', body);
    if (!list) return false;

    /* ---- Filter + render user rows ---------------------- */
    var all = Array.isArray(window.allUsersCache) ? window.allUsersCache : [];
    var users = all.filter(function (u) {
      return u && u.uid && u.uid !== uid;
    });

    if (!users.length) {
      list.innerHTML =
        '<div class="empty"><p>' + esc(T('no_results')) + '</p></div>';
    } else {
      list.innerHTML = users.map(function (u) {
        return '<div class="picker-item" data-fwd="' + esc(u.uid) + '">' +
          avatarHTML(u.photo, u.name, 'av-40') +
          '<div class="grow">' +
            '<div class="name">' + esc(u.name || 'User') + '</div>' +
          '</div>' +
          '<span class="ic">' + svgIcon('forward') + '</span>' +
        '</div>';
      }).join('');
    }

    /* ---- Wire row clicks -------------------------------- */
    var rows = list.querySelectorAll('[data-fwd]');
    for (var i = 0; i < rows.length; i++) {
      (function (row) {
        row.addEventListener('click', async function () {
          var targetUid = row.getAttribute('data-fwd');
          if (!targetUid) return;

          /* Resolve the source message from the live map.
           * If it disappeared while the picker was open (e.g.
           * deleted), silently abort. */
          var m = (window.chatMessages && window.chatMessages[mid]) || null;
          if (!m) return;

          safeCall('closeOverlay', ['ovPicker']);

          try {
            /* Ensure the direct chat exists ----------------- */
            var chatId = await safeCall('ensureDirectChat', [targetUid]);
            if (!chatId) throw new Error(T('error'));

            /* Clone the message into the new chat ---------- */
            var me = getMyProfile() || {};
            var ref = fbDb.ref('messages/' + chatId).push();
            var readBy = {};
            readBy[uid] = true;

            await ref.set({
              id: ref.key,
              from: uid,
              fromName: me.name || '',
              fromPhoto: me.photo || '',
              type: m.type,
              text: m.text || '',
              url:  m.url  || '',
              dur:  m.dur  || 0,
              createdAt: timeNow(),
              readBy: readBy
            });

            /* Update chat meta with a short preview -------- *
             *  Preserved exactly: (m.text || '📷').slice(0,80)
             *  — the original used a plain '📷' fallback
             *    regardless of the actual message type.    */
            var preview = String(m.text || '📷').slice(0, 80);
            safeCall('updateChatMeta', [chatId, preview]);

            /* Feedback ------------------------------------- */
            safeToast(T('message_forwarded'), 'ok');
          } catch (err) {
            safeToast((err && err.message) ? err.message : T('error'), 'err');
          }
        });
      })(rows[i]);
    }

    /* ---- Open overlay ----------------------------------- */
    safeCall('openOverlay', ['ovPicker']);
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openForwardPicker = open;

  window.SaikoMsgForward = {
    open: open
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 131 — msg-forward ready');
  } catch (e) {}

})();