/* ============================================================
 * FEATURE:        Message Edit
 * FEATURE NUMBER: 133
 * FILE:           js/chat/133-msg-edit.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for editing a chat message's text. Extracts
 *   the "edit" branch that lives inline inside feature 145's
 *   openMessageMenu() so any future surface (message list,
 *   long-press sheet, pinned preview) can trigger the same
 *   flow.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     if (k === 'edit') {
 *       const nt = await promptDialog(t('edit'), m.text || '');
 *       if (nt == null) return;
 *       const txt = nt.trim();
 *       if (!txt) return;
 *       await db.ref('messages/' + cid + '/' + mid)
 *               .update({ text: txt, edited: true, updatedAt: now() })
 *               .catch(e => toast(e.message, 'err'));
 *     }
 *
 *   Public functions:
 *     window.editMessage(mid)         → Promise<boolean>
 *     window.canEditMessage(m)        → boolean
 *     window.buildEditPayload(text)   → { text, edited, updatedAt }
 *
 *   Notes on the semantics preserved:
 *     • The original offered the edit action only when:
 *         - the message is mine, AND
 *         - its type is 'text', AND
 *         - the chat is NOT an admin-support chat.
 *       canEditMessage() reproduces that gate so callers can
 *       pre-check whether to include the option in a menu.
 *     • The prompt dialog is called with the message's current
 *       text as the default value so the user can amend it.
 *     • Cancelling the prompt (null) or submitting empty text
 *       (after trim) is a silent no-op.
 *     • On a Firebase write failure, the error is toasted with
 *       kind 'err'. On success, no toast (the bubble re-render
 *       from the live listener is the feedback).
 *     • Admin-support chats are excluded because those messages
 *       are E2E-encrypted and rewriting the ciphertext is not
 *       supported by this helper.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu() → case 'edit'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - window.chatMessages      feature 112 (live map)
 *   - window.currentChatId     feature 112 (live)
 *   - window.chatIsAdminSupport  feature 112 (live)
 *   - promptDialog             js/nav/044-prompt-dialog.js
 *   - toast                    js/nav/042-toast.js
 *   - t(key) / now()           helpers
 *
 * DOM ELEMENTS USED:
 *   none directly — promptDialog builds its own overlay.
 *
 * FIREBASE PATHS:
 *   messages/{chatId}/{mid}      (update)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.editMessage          (new — canonical)
 *   window.canEditMessage       (new — canonical)
 *   window.buildEditPayload     (new — canonical)
 *   window.SaikoMsgEdit = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askPrompt(title, defValue, placeholder) {
    try {
      if (typeof window.promptDialog === 'function') {
        return window.promptDialog(title, defValue, placeholder);
      }
    } catch (e) {}
    /* If promptDialog is missing, resolve null so the caller
     * treats the operation as cancelled rather than hanging. */
    return Promise.resolve(null);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * CAN EDIT — pure predicate
   * ============================================================
   * Preserved from the original menu-gate logic in feature 145:
   *   mine && m.type === 'text' && !chatIsAdminSupport
   *
   * Accepts either a message object or a message id.
   * ============================================================ */
  function canEditMessage(mOrMid) {
    var m = mOrMid;
    if (typeof mOrMid === 'string') {
      m = (window.chatMessages && window.chatMessages[mOrMid]) || null;
    }
    if (!m) return false;

    var me = getMyUid();
    if (!me) return false;
    if (m.from !== me) return false;
    if (m.type !== 'text') return false;
    if (window.chatIsAdminSupport) return false;

    return true;
  }

  /* ============================================================
   * BUILD PAYLOAD — pure
   * ============================================================
   * The exact object shape the original wrote:
   *   { text: <trimmed>, edited: true, updatedAt: now() }
   * ============================================================ */
  function buildEditPayload(text) {
    return {
      text: (text == null) ? '' : String(text),
      edited: true,
      updatedAt: timeNow()
    };
  }

  /* ============================================================
   * EDIT — main entry
   * ============================================================
   * Preserved 1:1 from the original `case 'edit'` branch.
   * Returns Promise<boolean>:
   *   true  — write attempted and succeeded
   *   false — cancelled, empty, guard failed, or write error
   * ============================================================ */
  async function edit(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    if (!chatId) return false;

    var m = (window.chatMessages && window.chatMessages[mid]) || null;
    if (!m) return false;

    /* Guard — mirrors the menu gate ----------------------- */
    if (!canEditMessage(m)) return false;

    /* Prompt for the new text ----------------------------- */
    var nt = await askPrompt(T('edit'), m.text || '');
    if (nt == null) return false;                     /* cancelled */

    var txt = String(nt).trim();
    if (!txt) return false;                           /* empty */

    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      await fbDb.ref('messages/' + chatId + '/' + mid)
        .update(buildEditPayload(txt));
    } catch (err) {
      safeToast((err && err.message) ? err.message : T('error'), 'err');
      return false;
    }

    /* Notify subscribers (additive) ----------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-edited', {
        detail: { messageId: mid, chatId: chatId, text: txt }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.editMessage       = edit;
  window.canEditMessage    = canEditMessage;
  window.buildEditPayload  = buildEditPayload;

  window.SaikoMsgEdit = {
    edit: edit,
    canEdit: canEditMessage,
    buildPayload: buildEditPayload
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 133 — msg-edit ready');
  } catch (e) {}

})();