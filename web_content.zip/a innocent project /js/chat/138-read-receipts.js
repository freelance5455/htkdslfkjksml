/* ============================================================
 * FEATURE:        Read Receipts
 * FEATURE NUMBER: 138
 * FILE:           js/chat/138-read-receipts.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Canonical owner of the read-receipt subsystem for chat
 *   messages. Extracts the readBy writes and reads that were
 *   spread across feature 112 (chat open) and feature 128
 *   (message render) into one helper so any surface can:
 *
 *     • Explicitly mark a single message as read
 *     • Batch-mark every unread message in the active chat
 *     • Read how many distinct users have read a message
 *     • Read who read a message
 *     • Check whether the current user has enabled read
 *       receipts
 *
 *   Public functions:
 *     markMessageRead(mid)          → Promise<boolean>
 *     markChatRead(chatId)          → Promise<number>
 *     countReaders(mid)             → number
 *     getReaders(mid)               → string[]
 *     hasReader(mid, uid)           → boolean
 *     isReadReceiptsEnabled()       → boolean
 *
 *   Behaviour preserved 1:1 from the original source:
 *
 *     Feature 128 wrote:
 *       db.ref('messages/'+chatId+'/'+mid+'/readBy/'+myUid)
 *         .set(true).catch(()=>{});
 *       — only for incoming messages, only when
 *         prefs.showReadReceipts !== false, and never on
 *         admin-support chats.
 *
 *     Feature 112 wrote on chat open:
 *       db.ref('chats/'+chatId+'/reads/'+myUid).set(now())
 *
 *   Feature 138 does NOT replace either call site — it exposes
 *   the same operations as standalone helpers so future callers
 *   (search-in-chat, pinned-preview, read-receipts settings
 *   page) can trigger them without duplicating the path logic.
 *
 *   IMPORTANT — READ RECEIPT SEMANTICS PRESERVED:
 *     • A readBy write is only meaningful for INCOMING
 *       messages. Writing your own message's readBy is a no-op
 *       (matches the original guard `!mine`).
 *     • Admin-support chats are skipped entirely — those
 *       messages are E2E encrypted and the readBy field is not
 *       used by the UI.
 *     • The user's `prefs.showReadReceipts` toggle gates the
 *       write. When false, no readBy is written at all. Note:
 *       the original only gated the WRITE side. Reading back
 *       is always allowed (you can still see others' read
 *       status of your messages even when you've turned your
 *       own receipts off).
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT
 *       Feature-112 open:   chats/{chatId}/reads/{uid} = now()
 *       Feature-128 render: messages/{chatId}/{mid}/readBy/{uid} = true
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - window.chatMessages      feature 112 (live map)
 *   - window.currentChatId     feature 112 (live)
 *   - window.chatIsAdminSupport  feature 112 (live)
 *   - window.prefs             js/prefs/prefs-core.js
 *   - now()                    js/core/utils.js
 *
 * DOM ELEMENTS USED:
 *   none — pure data helpers.
 *
 * FIREBASE PATHS:
 *   messages/{chatId}/{mid}/readBy/{uid}    (write / read)
 *   chats/{chatId}/reads/{uid}              (write)
 *
 * localStorage  : none owned here (prefs read via prefs-core)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.markMessageRead          (new — canonical)
 *   window.markChatRead             (new — canonical)
 *   window.countReaders             (new)
 *   window.getReaders               (new)
 *   window.hasReader                (new)
 *   window.isReadReceiptsEnabled    (new)
 *   window.SaikoReadReceipts = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function getMessage(mid) {
    if (!mid) return null;
    return (window.chatMessages && window.chatMessages[mid]) || null;
  }

  /* ============================================================
   * PREFERENCE
   * ============================================================
   * Reads prefs.showReadReceipts. Defaults to true so the
   * helper works even before prefs-core has loaded.
   * ============================================================ */
  function isReadReceiptsEnabled() {
    try {
      if (window.prefs && typeof window.prefs.showReadReceipts === 'boolean') {
        return window.prefs.showReadReceipts;
      }
    } catch (e) {}
    return true;
  }

  /* ============================================================
   * MARK MESSAGE READ
   * ============================================================
   * Writes messages/{chatId}/{mid}/readBy/{myUid} = true when:
   *   • mid is present
   *   • a chat is active
   *   • the chat is not admin support
   *   • the user has read receipts enabled
   *   • the message is NOT authored by me
   *
   * Silent on error — matches the original `.catch(()=>{})`.
   * ============================================================ */
  async function markMessageRead(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    var uid    = getMyUid();
    var fbDb   = getDB();
    if (!chatId || !uid || !fbDb) return false;

    /* Admin-support chats do not use readBy ------------- */
    if (window.chatIsAdminSupport) return false;

    /* Respect the user's preference --------------------- */
    if (!isReadReceiptsEnabled()) return false;

    /* Only incoming messages are worth marking ---------- */
    var m = getMessage(mid);
    if (!m || m.from === uid) return false;

    try {
      await fbDb.ref('messages/' + chatId + '/' + mid + '/readBy/' + uid)
        .set(true);
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * MARK CHAT READ
   * ============================================================
   * Writes chats/{chatId}/reads/{myUid} = now() (the chat-level
   * read timestamp used by feature 112 on open).
   *
   * Optionally also walks the live window.chatMessages map and
   * calls markMessageRead() for every incoming message that does
   * not already carry my uid in its readBy. Returns the count
   * of messages that had a fresh readBy written.
   * ============================================================ */
  async function markChatRead(chatId) {
    if (!chatId) return 0;

    var uid  = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return 0;

    /* 1) Chat-level read timestamp ----------------------- */
    try {
      await fbDb.ref('chats/' + chatId + '/reads/' + uid).set(timeNow());
    } catch (e) {
      /* Silent — best-effort. */
    }

    /* 2) Per-message readBy (only for the active chat) --- */
    if (chatId !== window.currentChatId) return 0;
    if (window.chatIsAdminSupport) return 0;
    if (!isReadReceiptsEnabled()) return 0;

    var written = 0;
    var cache = window.chatMessages || {};
    var keys = Object.keys(cache);
    for (var i = 0; i < keys.length; i++) {
      var mid = keys[i];
      var m = cache[mid];
      if (!m || m.from === uid) continue;
      if (m.readBy && m.readBy[uid]) continue;   /* already */
      var ok = await markMessageRead(mid);
      if (ok) written++;
    }
    return written;
  }

  /* ============================================================
   * READ HELPERS — pure
   * ============================================================ */

  /* countReaders(mid) — number of distinct users in readBy,
   * excluding the sender themselves (the original bubble render
   * in feature 128 filters myUid out when deciding ✓ vs ✓✓). */
  function countReaders(mid) {
    var m = getMessage(mid);
    if (!m || !m.readBy) return 0;
    var keys = Object.keys(m.readBy);
    var sender = m.from;
    var count = 0;
    for (var i = 0; i < keys.length; i++) {
      if (keys[i] !== sender) count++;
    }
    return count;
  }

  /* getReaders(mid) — the uids that have read the message,
   * excluding the sender. */
  function getReaders(mid) {
    var m = getMessage(mid);
    if (!m || !m.readBy) return [];
    var keys = Object.keys(m.readBy);
    var sender = m.from;
    var out = [];
    for (var i = 0; i < keys.length; i++) {
      if (keys[i] !== sender) out.push(keys[i]);
    }
    return out;
  }

  /* hasReader(mid, uid) — did the specified uid read the
   * message? */
  function hasReader(mid, uid) {
    if (!mid || !uid) return false;
    var m = getMessage(mid);
    if (!m || !m.readBy) return false;
    return !!m.readBy[uid];
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.markMessageRead         = markMessageRead;
  window.markChatRead            = markChatRead;
  window.countReaders            = countReaders;
  window.getReaders              = getReaders;
  window.hasReader               = hasReader;
  window.isReadReceiptsEnabled   = isReadReceiptsEnabled;

  window.SaikoReadReceipts = {
    markMessageRead: markMessageRead,
    markChatRead: markChatRead,
    countReaders: countReaders,
    getReaders: getReaders,
    hasReader: hasReader,
    isEnabled: isReadReceiptsEnabled
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 138 — read-receipts ready');
  } catch (e) {}

})();