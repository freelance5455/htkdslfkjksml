/* ============================================================
 * FEATURE:        Message Reactions (6-emoji Picker)
 * FEATURE NUMBER: 137
 * FILE:           js/chat/137-msg-reactions.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the six-emoji reaction picker for CHAT messages.
 *
 *   Note on the emoji set — this is INTENTIONALLY different
 *   from post reactions (feature 065):
 *
 *     Post reactions (065):   ❤️ 😂 😮 😢 😡 👍
 *     Message reactions (137): 👍 ❤️ 😂 😮 😢 🙏
 *
 *   The message set starts with 👍 and ends with 🙏 instead of
 *   😡. The original source hard-coded this second list inside
 *   openReactions(); we preserve it byte-for-byte.
 *
 *   Responsibilities:
 *
 *     1. PICKER
 *          openReactions(mid) — renders the six emoji buttons
 *          into #rxPicker, opens #ovReactions, wires each
 *          button's click to the toggle flow below.
 *
 *     2. TOGGLE
 *          toggleReaction(mid, emoji) — reads
 *          messages/{chatId}/{mid}/reactions/{emoji}/{myUid};
 *          if it exists, remove it; otherwise set it to true.
 *          Silent on errors (matches original).
 *
 *     3. HELPERS
 *          myReaction(mid) — returns the current user's emoji
 *                            on the message, or null.
 *          countReaction(mid, emoji) — number of distinct
 *                            users who chose that emoji.
 *          summary(mid) — { emoji: count } map, useful for
 *                            rendering.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     function openReactions(mid){
 *       const RX = ['👍','❤️','😂','😮','😢','🙏'];
 *       $('#rxPicker').innerHTML = RX.map(r =>
 *         '<button data-rx="'+r+'">'+r+'</button>').join('');
 *       openOverlay('ovReactions');
 *       $('#rxPicker').querySelectorAll('[data-rx]').forEach(b => {
 *         b.addEventListener('click', async () => {
 *           closeOverlay('ovReactions');
 *           if (!currentChatId) return;
 *           const r = b.getAttribute('data-rx');
 *           const ref = db.ref('messages/'+currentChatId+'/'+mid+
 *                             '/reactions/'+r+'/'+myUid);
 *           const s = await ref.get();
 *           if (s.exists()) await ref.remove();
 *           else await ref.set(true);
 *         });
 *       });
 *     }
 *
 *   Notes on the semantics preserved:
 *     • The reaction is stored as a boolean `true` under the
 *       emoji path — NOT as a string or object. Feature 128's
 *       renderer counts keys to derive the number next to
 *       each emoji.
 *     • Multiple emojis per user are allowed by the storage
 *       schema (one row per emoji), but the UI only displays
 *       one; the original did not enforce exclusivity on the
 *       message path either. This module preserves that.
 *     • Admin-support chats use their own message path
 *       (adminChats/{chatId}/messages). The original did not
 *       branch here — reactions on admin chats would write
 *       into the wrong tree. We add a guard: skip the picker
 *       on admin-support chats so the message tree stays
 *       clean.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openReactions(mid)
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - window.currentChatId     feature 112 (live)
 *   - window.chatIsAdminSupport  feature 112 (live)
 *   - window.chatMessages      feature 112 (live map)
 *   - openOverlay / closeOverlay (038)
 *   - renderMessage            feature 128 (re-render after toggle)
 *   - t(key)                   js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   #ovReactions, #rxPicker
 *
 * FIREBASE PATHS:
 *   messages/{chatId}/{mid}/reactions/{emoji}/{uid}   (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openReactions             (original name preserved)
 *   window.toggleMessageReaction     (new — canonical)
 *   window.myMessageReaction         (new)
 *   window.countMessageReaction      (new)
 *   window.SaikoMsgReactions = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var RX = ['👍', '❤️', '😂', '😮', '😢', '🙏'];
  var PICKER_Z = '130';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-reactions] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }
  function getMessage(mid) {
    if (!mid) return null;
    return (window.chatMessages && window.chatMessages[mid]) || null;
  }

  /* ============================================================
   * READ HELPERS
   * ============================================================ */

  /* myReaction(mid) — the current user's emoji on the message,
   * or null when they have not reacted (or the message lacks
   * a reactions map). */
  function myReaction(mid) {
    var m = getMessage(mid);
    if (!m || !m.reactions) return null;
    var uid = getMyUid();
    if (!uid) return null;

    var keys = Object.keys(m.reactions);
    for (var i = 0; i < keys.length; i++) {
      var bucket = m.reactions[keys[i]] || {};
      if (bucket[uid]) return keys[i];
    }
    return null;
  }

  /* countReaction(mid, emoji) — number of distinct users who
   * chose that emoji. */
  function countReaction(mid, emoji) {
    var m = getMessage(mid);
    if (!m || !m.reactions || !emoji) return 0;
    var bucket = m.reactions[emoji] || {};
    return Object.keys(bucket).length;
  }

  /* summary(mid) — { emoji: count } map. Useful for rendering
   * or sorting. */
  function summary(mid) {
    var out = {};
    var m = getMessage(mid);
    if (!m || !m.reactions) return out;
    var keys = Object.keys(m.reactions);
    for (var i = 0; i < keys.length; i++) {
      var emoji = keys[i];
      var bucket = m.reactions[emoji] || {};
      var count = Object.keys(bucket).length;
      if (count) out[emoji] = count;
    }
    return out;
  }

  /* ============================================================
   * TOGGLE — the write path
   * ============================================================
   * Preserved 1:1 from the original click handler:
   *   ref = messages/{chatId}/{mid}/reactions/{emoji}/{myUid}
   *   if exists → remove
   *   else      → set(true)
   * Silent on errors.
   * ============================================================ */
  async function toggleReaction(mid, emoji) {
    if (!mid || !emoji) return false;

    var chatId = window.currentChatId;
    var uid    = getMyUid();
    var fbDb   = getDB();
    if (!chatId || !uid || !fbDb) return false;

    /* Skip admin-support chats — the reaction tree does not
     * exist for those messages. */
    if (window.chatIsAdminSupport) return false;

    var ref = fbDb.ref('messages/' + chatId + '/' + mid +
                       '/reactions/' + emoji + '/' + uid);

    try {
      var snap = await ref.get();
      if (snap.exists()) {
        await ref.remove();
      } else {
        await ref.set(true);
      }
    } catch (err) {
      /* Silent — matches original. */
      return false;
    }

    /* Nudge the bubble re-render so the reactions row reflects
     * the change immediately. (The Firebase child_changed
     * listener in feature 112 will also fire, but a direct
     * repaint gives a snappier UX.) */
    var node = qs('[data-mid="' + mid + '"]');
    if (node) {
      var m = getMessage(mid);
      if (m) safeCall('renderMessage', [mid, m, false]);
    }

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-reaction-toggled', {
        detail: { messageId: mid, emoji: emoji, chatId: chatId }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * OPEN PICKER — main entry
   * ============================================================
   * Preserved 1:1 from the original openReactions(mid):
   *   • render the six emoji buttons into #rxPicker
   *   • open #ovReactions with the inline z-index bump
   *   • each button click → close overlay + toggle reaction
   * ============================================================ */
  function openReactions(mid) {
    if (!mid) return false;

    /* Admin-support chats have no reactions tree. */
    if (window.chatIsAdminSupport) return false;

    var picker = qs('#rxPicker');
    if (!picker) return false;

    /* ---- Render buttons --------------------------------- */
    picker.innerHTML = RX.map(function (r) {
      return '<button data-rx="' + r + '">' + r + '</button>';
    }).join('');

    /* ---- Open overlay ----------------------------------- */
    safeCall('openOverlay', ['ovReactions']);
    var ov = qs('#ovReactions');
    if (ov) ov.style.zIndex = PICKER_Z;

    /* ---- Wire clicks ------------------------------------ */
    qsa('[data-rx]', picker).forEach(function (b) {
      b.addEventListener('click', async function () {
        safeCall('closeOverlay', ['ovReactions']);
        var r = b.getAttribute('data-rx');
        await toggleReaction(mid, r);
      });
    });

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openReactions          = openReactions;
  window.toggleMessageReaction  = toggleReaction;
  window.myMessageReaction      = myReaction;
  window.countMessageReaction   = countReaction;
  window.summaryMessageReaction = summary;

  window.SaikoMsgReactions = {
    RX: RX.slice(),
    open: openReactions,
    toggle: toggleReaction,
    myReaction: myReaction,
    countReaction: countReaction,
    summary: summary
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 137 — msg-reactions ready');
  } catch (e) {}

})();