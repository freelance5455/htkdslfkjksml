/* ============================================================
 * FEATURE:        Search in Chat
 * FEATURE NUMBER: 147
 * FILE:           js/chat/147-chat-search.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the "search inside the currently open chat" flow.
 *   Provides a toggleable search bar (#chatSearchWrap) with a
 *   text input (#chatSearchInput) and a close button
 *   (#chatSearchClose). As the user types, every rendered
 *   bubble in #chatBody is filtered in-place by a
 *   case-insensitive substring match on its text content.
 *
 *   Public functions:
 *     toggleChatSearch()      → show/hide the bar + focus input
 *     openChatSearch()        → show the bar + focus (idempotent)
 *     closeChatSearch()       → hide the bar + reset filter
 *     filterChatMessages(q)   → apply a query to the bubble set
 *     getCurrentQuery()       → last applied query (lowercased,
 *                                trimmed)
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     function toggleChatSearch(){
 *       const w = $('#chatSearchWrap'); w.classList.toggle('hidden');
 *       if(!w.classList.contains('hidden')) $('#chatSearchInput').focus();
 *       else {
 *         $('#chatSearchInput').value = '';
 *         filterChatMessages('');
 *       }
 *     }
 *     $('#chatSearchClose').addEventListener('click', ()=>{
 *       $('#chatSearchWrap').classList.add('hidden');
 *       $('#chatSearchInput').value='';
 *       filterChatMessages('');
 *     });
 *     $('#chatSearchInput').addEventListener('input',
 *       e => filterChatMessages(e.target.value));
 *
 *     function filterChatMessages(q){
 *       q = (q||'').toLowerCase().trim();
 *       $$('#chatBody .bubble').forEach(b => {
 *         if(!q){ b.style.display = ''; return; }
 *         b.style.display =
 *           b.textContent.toLowerCase().indexOf(q) !== -1 ? '' : 'none';
 *       });
 *     }
 *
 *   Notes on the semantics preserved:
 *     • Filtering is purely visual (inline style.display). The
 *       bubbles remain in the DOM with their listeners intact —
 *       nothing is destroyed and reattached.
 *     • An empty query restores every bubble by clearing the
 *       inline display property (b.style.display = '').
 *     • The match is on the FULL textContent of the bubble
 *       (including sender name in group chats, timestamps,
 *       reaction labels). This is exactly what the original
 *       did — no per-part filtering.
 *     • Chat-close resets the search bar (feature 112's
 *       openChatById already clears it). Feature 147's
 *       closeChatSearch() is safe to call at any time.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT
 *       toggleChatSearch()
 *       #chatSearchClose click handler
 *       #chatSearchInput 'input' handler
 *       filterChatMessages(q)
 *
 * DEPENDENCIES (loaded earlier):
 *   - t(key)              js/nav/046-i18n.js (unused here but
 *                         loaded early for callers)
 *
 * DOM ELEMENTS USED:
 *   #chatSearchWrap   (the bar wrapper)
 *   #chatSearchInput  (text input)
 *   #chatSearchClose  (✕ close button)
 *   #chatBody         (bubble container)
 *   #chatBody .bubble (filterable elements)
 *
 * FIREBASE PATHS:
 *   none — purely visual filtering.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.toggleChatSearch         (original name preserved)
 *   window.openChatSearch           (additive)
 *   window.closeChatSearch          (additive)
 *   window.filterChatMessages       (original name preserved)
 *   window.SaikoChatSearch = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var currentQuery = '';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ============================================================
   * FILTER — the core routine
   * ============================================================
   * Preserved 1:1 from the original filterChatMessages(q).
   * ============================================================ */
  function filterChatMessages(qRaw) {
    var q = String(qRaw || '').toLowerCase().trim();
    currentQuery = q;

    var bubbles = qsa('#chatBody .bubble');
    for (var i = 0; i < bubbles.length; i++) {
      var b = bubbles[i];
      if (!q) {
        /* Empty query → restore every bubble --------------- */
        b.style.display = '';
        continue;
      }
      var text = (b.textContent || '').toLowerCase();
      b.style.display = (text.indexOf(q) !== -1) ? '' : 'none';
    }
  }

  /* ============================================================
   * OPEN — show the bar + focus
   * ============================================================ */
  function openChatSearch() {
    var w = qs('#chatSearchWrap');
    if (!w) return false;
    w.classList.remove('hidden');

    var input = qs('#chatSearchInput');
    if (input && typeof input.focus === 'function') {
      try { input.focus(); } catch (e) {}
    }
    return true;
  }

  /* ============================================================
   * CLOSE — hide the bar + reset filter
   * ============================================================ */
  function closeChatSearch() {
    var w = qs('#chatSearchWrap');
    if (w) w.classList.add('hidden');

    var input = qs('#chatSearchInput');
    if (input) input.value = '';

    filterChatMessages('');
    return true;
  }

  /* ============================================================
   * TOGGLE — preserved 1:1 from the original
   * ============================================================ */
  function toggleChatSearch() {
    var w = qs('#chatSearchWrap');
    if (!w) return false;

    w.classList.toggle('hidden');
    if (!w.classList.contains('hidden')) {
      /* Now visible → focus the input ---------------------- */
      var input = qs('#chatSearchInput');
      if (input && typeof input.focus === 'function') {
        try { input.focus(); } catch (e) {}
      }
    } else {
      /* Now hidden → clear input + reset filter ----------- */
      var input2 = qs('#chatSearchInput');
      if (input2) input2.value = '';
      filterChatMessages('');
    }
    return true;
  }

  /* ============================================================
   * GETTERS
   * ============================================================ */
  function getCurrentQuery() { return currentQuery; }

  function isOpen() {
    var w = qs('#chatSearchWrap');
    return !!(w && !w.classList.contains('hidden'));
  }

  /* ============================================================
   * BIND — wire the two static controls
   * ============================================================ */
  var bound = false;

  function bind() {
    if (bound) return true;

    var closeBtn = qs('#chatSearchClose');
    if (closeBtn && closeBtn.dataset.chatSearchBound !== '1') {
      closeBtn.dataset.chatSearchBound = '1';
      closeBtn.addEventListener('click', closeChatSearch);
    }

    var input = qs('#chatSearchInput');
    if (input && input.dataset.chatSearchBound !== '1') {
      input.dataset.chatSearchBound = '1';
      input.addEventListener('input', function (e) {
        filterChatMessages(e && e.target ? e.target.value : '');
      });
    }

    bound = true;
    return true;
  }

  function unbind() {
    var closeBtn = qs('#chatSearchClose');
    if (closeBtn) {
      closeBtn.removeEventListener('click', closeChatSearch);
      delete closeBtn.dataset.chatSearchBound;
    }
    var input = qs('#chatSearchInput');
    if (input) {
      /* Anonymous handler — clone-and-swap to detach. */
      var clone = input.cloneNode(true);
      clone.removeAttribute('data-chat-search-bound');
      input.parentNode && input.parentNode.replaceChild(clone, input);
    }
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.toggleChatSearch   = toggleChatSearch;
  window.openChatSearch     = openChatSearch;
  window.closeChatSearch    = closeChatSearch;
  window.filterChatMessages = filterChatMessages;

  window.SaikoChatSearch = {
    toggle: toggleChatSearch,
    open: openChatSearch,
    close: closeChatSearch,
    filter: filterChatMessages,
    getQuery: getCurrentQuery,
    isOpen: isOpen,
    bind: bind,
    unbind: unbind
  };

  /* ============================================================
   * AUTO-BIND
   * The search bar is static in index.html, so binding at DOM
   * ready is safe.
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 147 — chat-search ready');
  } catch (e) {}

})();