/* ============================================================
 * FEATURE:        Chat Nickname
 * FEATURE NUMBER: 152
 * FILE:           js/chat/152-chat-nickname.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the per-chat, per-viewer nickname system. Every user
 *   can rename any other member of a chat for their own eyes
 *   only — the nickname is stored under
 *
 *       chatNicknames/{chatId}/{myUid}/{targetUid}
 *
 *   so it never leaks to the other side.
 *
 *   Responsibilities:
 *
 *     1. LIVE MAP
 *          window.chatNicknames — the whole chatNicknames tree.
 *          A live listener on the root keeps the map fresh so
 *          every consumer (chat header, group info, mention
 *          rendering, inbox list) sees the latest nickname
 *          without reloading.
 *
 *     2. GETTER
 *          getNickname(chatId, targetUid) — returns my nickname
 *          for that target in that chat, or null.
 *
 *     3. SETTER
 *          setNickname(chatId, targetUid, nick) — write or
 *          remove. Empty / null / whitespace nick removes the
 *          entry and toasts t('nickname_removed'). A non-empty
 *          nick writes { nick, at: now() } and toasts
 *          t('nickname_saved').
 *
 *     4. LISTENER LIFECYCLE
 *          startListener() / detachListener() — clean attach /
 *          detach for the boot orchestrator and logout teardown.
 *
 *   Behaviour preserved 1:1 from the original §10b block:
 *
 *     let chatNicknames = {};
 *     listenNicknames(){
 *       chatNicknamesRef = db.ref('chatNicknames');
 *       chatNicknamesCb = chatNicknamesRef.on('value', s => {
 *         chatNicknames = s.val() || {};
 *         if(currentNav === 'inbox') renderInbox();
 *         if(currentChatId) refreshChatHeaderNames();
 *       });
 *     }
 *     getNickname(chatId, targetUid){
 *       const c = chatNicknames && chatNicknames[chatId];
 *       if(!c) return null;
 *       const mine = c[myUid];
 *       if(!mine) return null;
 *       const entry = mine[targetUid];
 *       if(!entry) return null;
 *       return (typeof entry === 'string') ? entry
 *                                          : (entry && entry.nick) || null;
 *     }
 *     async setNickname(chatId, targetUid, nick){
 *       const v = (nick == null) ? '' : String(nick).trim();
 *       if(!v){
 *         await db.ref('chatNicknames/'+chatId+'/'+myUid+'/'+targetUid)
 *                 .remove().catch(()=>{});
 *         toast(t('nickname_removed'),'ok');
 *       } else {
 *         await db.ref('chatNicknames/'+chatId+'/'+myUid+'/'+targetUid)
 *                 .set({ nick: v, at: now() }).catch(()=>{});
 *         toast(t('nickname_saved'),'ok');
 *       }
 *     }
 *
 *   Notes on the semantics preserved:
 *     • The entry may be a bare string (older builds) OR an
 *       object { nick, at } — the getter accepts both.
 *     • The map is a single listener on the root, not per-chat.
 *       Firebase keeps the payload small because nicknames are
 *       sparse.
 *     • Admin-support chats share the same map — the source
 *       did not special-case them.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §10b CHAT NICKNAMES
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - renderInbox              js/inbox/111-inbox-list.js
 *   - refreshChatHeaderNames   js/chat/148-chat-header.js
 *   - toast                    js/nav/042-toast.js
 *   - t(key) / now()           helpers
 *
 * DOM ELEMENTS USED:
 *   none — pure state + Firebase. Consumers react via the
 *   listener callbacks (renderInbox / refreshChatHeaderNames).
 *
 * FIREBASE PATHS:
 *   chatNicknames                              (listen)
 *   chatNicknames/{chatId}/{myUid}/{targetUid} (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.chatNicknames              (live map)
 *   window.listenNicknames            (original name preserved)
 *   window.getNickname                (original name preserved)
 *   window.setNickname                (original name preserved)
 *   window.detachNicknamesListener    (additive)
 *   window.SaikoChatNickname = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * STATE
   * ============================================================ */
  var chatNicknamesRef = null;
  var chatNicknamesCb  = null;

  window.chatNicknames = window.chatNicknames || {};

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function timeNow() {
    try { if (typeof now === 'function') return now(); } catch (e) {}
    return Date.now();
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[chat-nickname] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================
   * Preserved 1:1 from the original listenNicknames():
   *   • attach a single value listener on the root
   *   • refresh the local map
   *   • re-render the inbox when the user is on that tab
   *   • refresh the open chat's header when a chat is active
   * ============================================================ */
  function startListener() {
    if (chatNicknamesRef && chatNicknamesCb) return true;

    var fbDb = getDB();
    if (!fbDb) return false;

    chatNicknamesRef = fbDb.ref('chatNicknames');
    chatNicknamesCb = chatNicknamesRef.on('value', function (s) {
      window.chatNicknames = s.val() || {};

      /* Nudge the inbox if the user is looking at it -------- */
      if (typeof window.currentNav === 'string' &&
          window.currentNav === 'inbox') {
        safeCall('renderInbox');
      }

      /* Refresh the open chat's header + group-bubble labels */
      if (window.currentChatId) {
        safeCall('refreshChatHeaderNames', [window.currentChatId]);
      }
    });
    return true;
  }

  function detachListener() {
    if (chatNicknamesRef && chatNicknamesCb) {
      try { chatNicknamesRef.off('value', chatNicknamesCb); } catch (e) {}
    }
    chatNicknamesRef = null;
    chatNicknamesCb  = null;
    window.chatNicknames = {};
    return true;
  }

  /* ============================================================
   * GETTER
   * ============================================================
   * Preserved 1:1 from the original getNickname():
   *   • reads only the current user's slice of the tree
   *   • returns null when the chat / target has no nickname
   *   • accepts both the legacy string entry and the current
   *     { nick, at } object entry
   * ============================================================ */
  function getNickname(chatId, targetUid) {
    if (!chatId || !targetUid) return null;

    var me = getMyUid();
    if (!me) return null;

    var c = window.chatNicknames && window.chatNicknames[chatId];
    if (!c) return null;

    var mine = c[me];
    if (!mine) return null;

    var entry = mine[targetUid];
    if (!entry) return null;

    if (typeof entry === 'string') return entry;
    if (entry && typeof entry === 'object') return entry.nick || null;
    return null;
  }

  /* ============================================================
   * SETTER
   * ============================================================
   * Preserved 1:1 from the original setNickname():
   *   • empty / null / whitespace → remove + toast 'removed'
   *   • non-empty                 → set { nick, at } + toast 'saved'
   *   • both writes are best-effort (`catch(()=>{})`)
   * ============================================================ */
  async function setNickname(chatId, targetUid, nick) {
    if (!chatId || !targetUid) return false;

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    var v = (nick == null) ? '' : String(nick).trim();
    var ref = fbDb.ref('chatNicknames/' + chatId + '/' + me + '/' + targetUid);

    try {
      if (!v) {
        /* === Remove ===================================== */
        await ref.remove();
        safeToast(T('nickname_removed'), 'ok');
      } else {
        /* === Set ======================================== */
        await ref.set({ nick: v, at: timeNow() });
        safeToast(T('nickname_saved'), 'ok');
      }
    } catch (err) {
      /* Original swallowed the error. A missing write is
       * silently ignored; the listener will still show the
       * previous value if the write failed. */
      return false;
    }

    /* Notify subscribers (additive) ------------------------ */
    try {
      window.dispatchEvent(new CustomEvent('saiko:nickname-changed', {
        detail: { chatId: chatId, targetUid: targetUid, nick: v }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * ADDITIVE HELPERS
   * ============================================================ */
  function hasNickname(chatId, targetUid) {
    return !!getNickname(chatId, targetUid);
  }

  function getMap() { return window.chatNicknames; }

  function getMyNicknamesForChat(chatId) {
    if (!chatId) return {};
    var me = getMyUid();
    if (!me) return {};
    var c = window.chatNicknames && window.chatNicknames[chatId];
    if (!c) return {};
    return c[me] || {};
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.listenNicknames         = startListener;
  window.detachNicknamesListener = detachListener;
  window.getNickname             = getNickname;
  window.setNickname             = setNickname;

  window.SaikoChatNickname = {
    startListener: startListener,
    detachListener: detachListener,
    get: getNickname,
    set: setNickname,
    has: hasNickname,
    getMap: getMap,
    getMyNicknamesForChat: getMyNicknamesForChat
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 152 — chat-nickname ready');
  } catch (e) {}

})();