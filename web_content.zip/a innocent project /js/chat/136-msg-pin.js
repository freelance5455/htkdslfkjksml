/* ============================================================
 * FEATURE:        Message Pin / Unpin
 * FEATURE NUMBER: 136
 * FILE:           js/chat/136-msg-pin.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for pinning and unpinning a chat message.
 *   Extracts the "pin" branch that lives inline inside feature
 *   145's openMessageMenu() so any future surface (message
 *   list, long-press sheet, chat info) can trigger the same
 *   flow.
 *
 *   Responsibilities:
 *
 *     1. PIN
 *          pinMessage(mid)
 *            — chats/{chatId}/pinned = mid
 *            — window.pinnedMsgId = mid
 *            — loadPinned() to render the pin bar (feature 112)
 *            — toast t('message_pinned')
 *
 *     2. UNPIN
 *          unpinMessage()
 *            — chats/{chatId}/pinned = remove
 *            — window.pinnedMsgId = null
 *            — hide #pinBar
 *            — toast t('message_unpinned')
 *
 *     3. TOGGLE
 *          togglePin(mid)
 *            — if the same mid is already pinned → unpin
 *            — otherwise → pin
 *
 *     4. PREDICATE
 *          isPinned(mid) — true when the message is the
 *                          currently pinned message of the
 *                          active chat.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'pin') {
 *       if (pinnedMsgId === mid) {
 *         await db.ref('chats/'+cid+'/pinned').remove().catch(()=>{});
 *         pinnedMsgId = null;
 *         $('#pinBar').classList.add('hidden');
 *         toast(t('message_unpinned'), 'ok');
 *       } else {
 *         await db.ref('chats/'+cid+'/pinned').set(mid).catch(()=>{});
 *         pinnedMsgId = mid;
 *         loadPinned();
 *         toast(t('message_pinned'), 'ok');
 *       }
 *     }
 *
 *   Notes on the semantics preserved:
 *     • Only one message per chat can be pinned — pinning a
 *       different message overwrites the previous pin (the
 *       original did not guard against that; the chat meta
 *       listener in feature 112 syncs the pin bar on every
 *       change).
 *     • Both writes are `.catch(() => {})` best-effort — a
 *       network hiccup never surfaces an error toast.
 *     • The pin bar itself is rendered by feature 112's
 *       loadPinned(); this module only writes state and calls
 *       that renderer.
 *     • Admin-support chats are NOT special-cased — the pinned
 *       pointer is stored under chats/{chatId}/pinned for
 *       every chat type, matching the original.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openMessageMenu() → case 'pin'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                     js/core/firebase-init.js
 *   - window.currentChatId   feature 112 (live)
 *   - window.pinnedMsgId     feature 112 (live)
 *   - loadPinned             feature 112 (renderer)
 *   - toast                  js/nav/042-toast.js
 *   - t(key)                 js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   #pinBar — toggled .hidden when unpinning
 *
 * FIREBASE PATHS:
 *   chats/{chatId}/pinned    (set / remove)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.pinMessage          (new — canonical)
 *   window.unpinMessage        (new — canonical)
 *   window.togglePinMessage    (new — canonical)
 *   window.isPinnedMessage     (new — canonical)
 *   window.SaikoMsgPin = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[msg-pin] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ============================================================
   * PREDICATE — isPinnedMessage(mid)
   * ============================================================
   * True when the given mid matches the currently pinned
   * message of the active chat.
   * ============================================================ */
  function isPinnedMessage(mid) {
    if (!mid) return false;
    return window.pinnedMsgId === mid;
  }

  /* ============================================================
   * PIN — main write path
   * ============================================================
   * Preserved 1:1 from the original else-branch:
   *   chats/{chatId}/pinned = mid
   *   window.pinnedMsgId    = mid
   *   loadPinned()
   *   toast t('message_pinned')
   * ============================================================ */
  async function pinMessage(mid) {
    if (!mid) return false;

    var chatId = window.currentChatId;
    var fbDb = getDB();
    if (!chatId || !fbDb) return false;

    /* Already the pinned message → no-op ---------------- */
    if (window.pinnedMsgId === mid) return false;

    try {
      await fbDb.ref('chats/' + chatId + '/pinned').set(mid);
    } catch (e) {
      /* Original swallowed write errors silently. */
      return false;
    }

    window.pinnedMsgId = mid;
    safeCall('loadPinned');
    safeToast(T('message_pinned'), 'ok');

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-pin-changed', {
        detail: { messageId: mid, chatId: chatId, pinned: true }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * UNPIN — remove the pinned pointer
   * ============================================================
   * Preserved 1:1 from the original if-branch:
   *   chats/{chatId}/pinned = remove
   *   window.pinnedMsgId    = null
   *   hide #pinBar
   *   toast t('message_unpinned')
   * ============================================================ */
  async function unpinMessage() {
    var chatId = window.currentChatId;
    var fbDb = getDB();
    if (!chatId || !fbDb) return false;

    var previous = window.pinnedMsgId;

    try {
      await fbDb.ref('chats/' + chatId + '/pinned').remove();
    } catch (e) {
      /* Silent — matches original. */
      return false;
    }

    window.pinnedMsgId = null;

    var bar = qs('#pinBar');
    if (bar) bar.classList.add('hidden');

    safeToast(T('message_unpinned'), 'ok');

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:message-pin-changed', {
        detail: { messageId: previous, chatId: chatId, pinned: false }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * TOGGLE — dispatch on current state
   * ============================================================
   * Preserved 1:1 from the original outer branch:
   *   if (pinnedMsgId === mid) → unpin
   *   else                     → pin
   * ============================================================ */
  async function togglePin(mid) {
    if (!mid) return false;
    if (isPinnedMessage(mid)) return unpinMessage();
    return pinMessage(mid);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.pinMessage        = pinMessage;
  window.unpinMessage      = unpinMessage;
  window.togglePinMessage  = togglePin;
  window.isPinnedMessage   = isPinnedMessage;

  window.SaikoMsgPin = {
    pin: pinMessage,
    unpin: unpinMessage,
    toggle: togglePin,
    isPinned: isPinnedMessage,
    getPinned: function () { return window.pinnedMsgId || null; }
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 136 — msg-pin ready');
  } catch (e) {}

})();