/* ============================================================
 * FEATURE:        Emoji Panel (500+ Emoji)
 * FEATURE NUMBER: 160
 * FILE:           js/chat/160-emoji-panel.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the emoji picker that slides up above the chat input
 *   (#emojiPanel) and is triggered by #btnEmoji. Each button
 *   appends its character to the current value of #chatInput
 *   and keeps focus on the input so the user can continue
 *   typing.
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     const EMOJIS = [ ...500+ emojis... ];
 *
 *     function buildEmojiPanel(){
 *       const p = $('#emojiPanel');
 *       if (p.dataset.built) return;
 *       p.innerHTML = EMOJIS.map(e => '<button type="button">'+e+'</button>').join('');
 *       p.querySelectorAll('button').forEach(b => {
 *         b.addEventListener('click', () => {
 *           const i = $('#chatInput'); i.value += b.textContent; i.focus();
 *         });
 *       });
 *       p.dataset.built = '1';
 *     }
 *
 *     $('#btnEmoji').addEventListener('click', () => {
 *       buildEmojiPanel();
 *       $('#emojiPanel').classList.toggle('hidden');
 *     });
 *
 *   Notes on the semantics preserved:
 *     • The panel is populated on first open only (the
 *       `dataset.built` flag guards against rebuilding).
 *     • Clicking an emoji does NOT close the panel — the user
 *       can insert several emojis in a row (matches the
 *       original).
 *     • Focus is returned to the input after each insert so
 *       the on-screen keyboard does not flicker on mobile.
 *     • No categories, no search, no recently-used — the
 *       original had a single flat grid.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → const EMOJIS, buildEmojiPanel(),
 *                        #btnEmoji click handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - none — pure DOM
 *
 * DOM ELEMENTS USED:
 *   #emojiPanel  (grid container)
 *   #btnEmoji    (toggle button)
 *   #chatInput   (insert target)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.EMOJIS              (original name preserved)
 *   window.buildEmojiPanel     (original name preserved)
 *   window.SaikoEmojiPanel = { … }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * EMOJI LIST
   * ============================================================
   * Preserved byte-for-byte from the original §22 EMOJIS array.
   * The order is intentional (smileys → gestures → people →
   * hearts → symbols → transport → sports → flags), and no
   * emoji has been added or removed.
   * ============================================================ */
  var EMOJIS = [
    /* Smileys & Emotion ---------------------------------- */
    '😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','🙃','😉','😌','😍','🥰','😘','😗','😙','😚',
    '😋','😛','😝','😜','🤪','🤨','🧐','🤓','😎','🤩','🥳','😏','😒','😞','😔','😟','😕','🙁','☹️','😣',
    '😖','😫','😩','🥺','😢','😭','😤','😠','😡','🤬','🤯','😳','🥵','🥶','😱','😨','😰','😥','😓','🤗',
    '🤔','🤭','🤫','🤥','😶','😐','😑','😬','🙄','😯','😦','😧','😮','😲','🥱','😴','🤤','😪','😵','🤐',
    '🥴','🤢','🤮','🤧','😷','🤒','🤕','🤑','🤠','😈','👿','👹','👺','🤡','💩','👻','💀','☠️','👽','👾',
    '🤖','🎃','😺','😸','😹','😻','😼','😽','🙀','😿','😾',

    /* Gestures & Body ------------------------------------ */
    '👋','🤚','🖐','✋','🖖','👌','🤏','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','☝️','👍','👎','✊',
    '👊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦵','🦶','👂','🦻','👃','🧠',
    '🦷','🦴','👀','👁','👅','👄','💋','🩸',

    /* Hearts & Symbols ----------------------------------- */
    '❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝','💟',
    '☮️','✝️','☪️','🕉','☸️','✡️','🔯','🕎','☯️','☦️','🛐','⛎','♈','♉','♊','♋','♌','♍','♎','♏',
    '♐','♑','♒','♓','🆔','⚛️','🉑','☢️','☣️','📴','📳','🈶','🈚','🈸','🈺','🈷️','✴️','🆚','💮','🉐',
    '㊙️','㊗️','🈴','🈵','🈹','🈲','🅰️','🅱️','🆎','🆑','🅾️','🆘','❌','⭕','🛑','⛔','📛','🚫','💯','💢',
    '♨️','🚷','🚯','🚳','🚱','🔞','📵','🚭','❗','❕','❓','❔','‼️','⁉️','🔅','🔆','〽️','⚠️','🚸','🔱',
    '⚜️','🔰','♻️','✅','🈯','💹','❇️','✳️','❎','🌐','💠','Ⓜ️','🌀','💤','🏧','🚾','♿','🅿️','🈳','🈂️',
    '🛂','🛃','🛄','🛅','🚹','🚺','🚼','🚻','🚮','🎦','📶','🈁','🔣','ℹ️','🔤','🔡','🔠','🆖','🆗','🆙',
    '🆒','🆕','🆓'
  ];

  /* ============================================================
   * STATE
   * ============================================================ */
  var bound = false;

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function qs(sel) { return document.querySelector(sel); }

  /* ============================================================
   * BUILD PANEL
   * ============================================================
   * Preserved 1:1 from the original buildEmojiPanel():
   *   • idempotent via dataset.built flag
   *   • injects one <button type="button"> per emoji
   *   • wires each button to append its character to #chatInput
   *     and refocus the input
   * ============================================================ */
  function buildEmojiPanel() {
    var p = qs('#emojiPanel');
    if (!p) return false;
    if (p.dataset.built === '1') return true;

    p.innerHTML = EMOJIS.map(function (e) {
      return '<button type="button">' + e + '</button>';
    }).join('');

    var buttons = p.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      (function (b) {
        b.addEventListener('click', function () {
          var input = qs('#chatInput');
          if (!input) return;
          input.value = (input.value || '') + b.textContent;
          try { input.focus(); } catch (e) {}
        });
      })(buttons[i]);
    }

    p.dataset.built = '1';
    return true;
  }

  /* ============================================================
   * TOGGLE — open / close the panel
   * ============================================================
   * Preserved 1:1 from the original #btnEmoji click handler:
   *   buildEmojiPanel();
   *   $('#emojiPanel').classList.toggle('hidden');
   * ============================================================ */
  function togglePanel() {
    buildEmojiPanel();
    var p = qs('#emojiPanel');
    if (!p) return false;
    p.classList.toggle('hidden');
    return true;
  }

  /* ============================================================
   * SHOW / HIDE — additive explicit helpers
   * ============================================================ */
  function showPanel() {
    buildEmojiPanel();
    var p = qs('#emojiPanel');
    if (!p) return false;
    p.classList.remove('hidden');
    return true;
  }

  function hidePanel() {
    var p = qs('#emojiPanel');
    if (!p) return false;
    p.classList.add('hidden');
    return true;
  }

  function isOpen() {
    var p = qs('#emojiPanel');
    return !!(p && !p.classList.contains('hidden'));
  }

  /* ============================================================
   * INSERT — additive programmatic insert
   * ============================================================
   * Appends an emoji to the chat input (used by any future
   * caller that wants to inject a character programmatically).
   * ============================================================ */
  function insert(emoji) {
    if (!emoji) return false;
    var input = qs('#chatInput');
    if (!input) return false;
    input.value = (input.value || '') + String(emoji);
    try { input.focus(); } catch (e) {}
    return true;
  }

  /* ============================================================
   * BIND — wire the #btnEmoji click
   * ============================================================ */
  function bind() {
    if (bound) return true;

    var btn = qs('#btnEmoji');
    if (btn && btn.dataset.emojiBound !== '1') {
      btn.dataset.emojiBound = '1';
      btn.addEventListener('click', function (e) {
        if (e && typeof e.preventDefault === 'function') e.preventDefault();
        togglePanel();
      });
    }

    bound = true;
    return true;
  }

  function unbind() {
    var btn = qs('#btnEmoji');
    if (btn) {
      var clone = btn.cloneNode(true);
      clone.removeAttribute('data-emoji-bound');
      btn.parentNode && btn.parentNode.replaceChild(clone, btn);
    }
    bound = false;
    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.EMOJIS          = EMOJIS.slice();
  window.buildEmojiPanel = buildEmojiPanel;

  window.SaikoEmojiPanel = {
    EMOJIS: EMOJIS.slice(),
    build: buildEmojiPanel,
    toggle: togglePanel,
    show: showPanel,
    hide: hidePanel,
    isOpen: isOpen,
    insert: insert,
    bind: bind,
    unbind: unbind,
    COUNT: EMOJIS.length
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, { once: true });
  } else {
    bind();
  }

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 160 — emoji-panel ready (' + EMOJIS.length + ' emojis)');
  } catch (e) {}

})();