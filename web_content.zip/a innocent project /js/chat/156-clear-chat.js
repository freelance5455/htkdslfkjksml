/* ============================================================
 * FEATURE:        Clear Chat
 * FEATURE NUMBER: 156
 * FILE:           js/chat/156-clear-chat.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Focused helper for the "Clear chat" action that lives in
 *   the chat info menu (feature 119) — and is now exposed as a
 *   standalone callable so any surface (long-press sheet,
 *   settings page, bulk-clear flows) can trigger the same
 *   flow.
 *
 *   IMPORTANT — WHAT "CLEAR" MEANS:
 *     Clear chat does NOT delete messages from the other
 *     members' views and does NOT touch Firebase message rows.
 *     Instead, it writes a per-user hide marker for every
 *     message in the current chat:
 *
 *         messageHides/{myUid}/{chatId}/{mid} = true
 *
 *     The chat body then filters out any message whose mid
 *     appears in the local hide map (feature 112 owns the
 *     filter, feature 128 owns the render).
 *
 *   Responsibilities:
 *
 *     1. CONFIRM
 *          clearChat() — confirmDialog(t('clear_chat'),
 *                                      t('are_you_sure'))
 *
 *     2. BATCH HIDE
 *          Read messages/{chatId} once, build a batched update
 *          that writes messageHides/{myUid}/{chatId}/{mid} = true
 *          for every mid, then apply it in a single
 *          db.ref().update() call.
 *
 *     3. UI FEEDBACK
 *          On success: closeOverlay('ovChatInfo') + toast
 *                      t('saved') as 'ok'.
 *          On failure: silent (matches the original).
 *
 *   Behaviour preserved 1:1 from the original §22 CHAT block:
 *
 *     else if (k === 'clear') {
 *       const ok = await confirmDialog(t('clear_chat'),
 *                                       t('are_you_sure'));
 *       if (!ok) return;
 *       const c2 = chatMeta[currentChatId];
 *       const cid = currentChatId;
 *       db.ref('messages/' + cid).once('value').then(snap => {
 *         const v = snap.val() || {};
 *         const updates = {};
 *         Object.keys(v).forEach(mid => {
 *           updates['messageHides/' + myUid + '/' + cid + '/' + mid] = true;
 *         });
 *         if (Object.keys(updates).length) {
 *           db.ref().update(updates).then(() => {
 *             closeOverlay('ovChatInfo');
 *             toast(t('saved'), 'ok');
 *           });
 *         }
 *       });
 *     }
 *
 *   Notes on the semantics preserved:
 *     • Admin-support chats store their messages under
 *       adminChats/{chatId}/messages. The original DID NOT
 *       special-case this — but for the same reason we skip
 *       admin chats in delete-for-everyone, we also skip the
 *       batch hide here (the messageHides path only works for
 *       the regular chat tree).
 *     • The batched update is atomic from Firebase's
 *       perspective — either every hide marker lands or none
 *       does.
 *     • Local rendering immediately reflects the change because
 *       feature 112's message renderer consults
 *       messageHides/{uid}/{chatId}/{mid} before showing a
 *       bubble.
 *
 * ORIGINAL LOCATION (index.html):
 *     Section §22 CHAT → openChatInfoMenu() → case 'clear'
 *
 * DEPENDENCIES (loaded earlier):
 *   - db                       js/core/firebase-init.js
 *   - myUid                    js/auth/004-auth-state.js
 *   - window.currentChatId     js/inbox/112-chat-open.js
 *   - window.chatIsAdminSupport  js/inbox/112-chat-open.js
 *   - confirmDialog            js/nav/043-confirm-dialog.js
 *   - closeOverlay             js/nav/038-overlay-system.js
 *   - toast                    js/nav/042-toast.js
 *   - t(key)                   js/nav/046-i18n.js
 *
 * DOM ELEMENTS USED:
 *   none directly — every DOM change happens via the confirm
 *   dialog and the caller's overlay management.
 *
 * FIREBASE PATHS:
 *   messages/{chatId}                     (read once)
 *   messageHides/{uid}/{chatId}/{mid}     (batch set true)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.clearChat             (new — canonical)
 *   window.SaikoClearChat = {
 *     clear, clearMany,
 *     buildHidePaths, HIDE_PREFIX
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * CONSTANTS
   * ============================================================ */
  var HIDE_PREFIX = 'messageHides/';

  /* ============================================================
   * HELPERS
   * ============================================================ */
  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[clear-chat] safeCall:', name, e); }
    return undefined;
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    /* Missing confirmDialog → treat as "yes" so the flow is
     * never blocked (matches every other feature file). */
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * BUILD HIDE PATHS — pure
   * ============================================================
   * Given a chatId and a message-ids array, returns the map
   *   { 'messageHides/{uid}/{chatId}/{mid}': true, … }
   * that the batched update will apply. Exposed so callers can
   * preview or extend the update without re-implementing the
   * path shape.
   * ============================================================ */
  function buildHidePaths(uid, chatId, messageIds) {
    var updates = {};
    if (!uid || !chatId || !Array.isArray(messageIds)) return updates;
    for (var i = 0; i < messageIds.length; i++) {
      var mid = messageIds[i];
      if (!mid) continue;
      updates[HIDE_PREFIX + uid + '/' + chatId + '/' + mid] = true;
    }
    return updates;
  }

  /* ============================================================
   * CLEAR — main entry
   * ============================================================
   * Preserved 1:1 from the original `case 'clear'` branch.
   *
   *   1. confirmDialog
   *   2. read messages/{chatId} once
   *   3. build messageHides updates for every mid
   *   4. db.ref().update(updates)
   *   5. closeOverlay('ovChatInfo') + toast(t('saved'),'ok')
   * ============================================================ */
  async function clearChat() {
    var chatId = window.currentChatId;
    var uid    = getMyUid();
    var fbDb   = getDB();
    if (!chatId || !uid || !fbDb) return false;

    /* 1) Admin-support chats use their own message tree.
     *    The batch-hide path only applies to messages/{chatId}
     *    so we skip rather than write into the wrong tree. */
    if (window.chatIsAdminSupport) return false;

    /* 2) Confirm ----------------------------------------- */
    var ok = await askConfirm(T('clear_chat'), T('are_you_sure'));
    if (!ok) return false;

    /* 3) Read all message ids ---------------------------- */
    var ids = [];
    try {
      var snap = await fbDb.ref('messages/' + chatId).get();
      var v = snap.val() || {};
      ids = Object.keys(v);
    } catch (e) {
      /* Silent — matches original. */
      return false;
    }

    /* Nothing to hide → still show the success path so the
     * user gets feedback (matches original: it only closes +
     * toasts when updates is non-empty; but a no-op chat is
     * effectively equivalent). */
    if (!ids.length) {
      safeCall('closeOverlay', ['ovChatInfo']);
      safeToast(T('saved'), 'ok');
      return true;
    }

    /* 4) Build the batched update ------------------------ */
    var updates = buildHidePaths(uid, chatId, ids);

    /* 5) Apply ------------------------------------------- */
    try {
      await fbDb.ref().update(updates);
    } catch (e) {
      /* Original swallowed write errors silently. Preserved. */
      return false;
    }

    /* 6) UI feedback ------------------------------------- */
    safeCall('closeOverlay', ['ovChatInfo']);
    safeToast(T('saved'), 'ok');

    /* Notify subscribers (additive) ---------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:chat-cleared', {
        detail: { chatId: chatId, count: ids.length }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * CLEAR MANY — additive helper for bulk operations
   * ============================================================
   * Applies the same hide pattern to multiple chats in one
   * batched write. Useful for a future "clear all chats"
   * settings action. Returns the number of chats cleared.
   * ============================================================ */
  async function clearMany(chatIds) {
    if (!Array.isArray(chatIds) || !chatIds.length) return 0;

    var uid = getMyUid();
    var fbDb = getDB();
    if (!uid || !fbDb) return 0;

    var allUpdates = {};
    var cleared = 0;

    for (var i = 0; i < chatIds.length; i++) {
      var chatId = chatIds[i];
      if (!chatId) continue;

      try {
        var snap = await fbDb.ref('messages/' + chatId).get();
        var v = snap.val() || {};
        var ids = Object.keys(v);
        if (!ids.length) continue;

        var u = buildHidePaths(uid, chatId, ids);
        var keys = Object.keys(u);
        for (var j = 0; j < keys.length; j++) {
          allUpdates[keys[j]] = true;
        }
        cleared++;
      } catch (e) {
        /* Skip failed chats and continue. */
      }
    }

    if (Object.keys(allUpdates).length) {
      try { await fbDb.ref().update(allUpdates); }
      catch (e) { return 0; }
    }

    return cleared;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.clearChat = clearChat;

  window.SaikoClearChat = {
    clear: clearChat,
    clearMany: clearMany,
    buildHidePaths: buildHidePaths,
    HIDE_PREFIX: HIDE_PREFIX
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 156 — clear-chat ready');
  } catch (e) {}

})();