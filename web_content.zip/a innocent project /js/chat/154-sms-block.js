/* ============================================================
 * FEATURE:        SMS Block
 * FEATURE NUMBER: 154
 * FILE:           js/chat/154-sms-block.js
 * ACTION:         REPLACE (adds reverse-check helper for enforcement)
 * ============================================================ */

(function () {
  'use strict';

  var smsBlockRef = null;
  var smsBlockCb  = null;

  window.smsBlockedUsers = window.smsBlockedUsers || {};

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function safeToast(msg, kind) {
    try { if (typeof toast === 'function') toast(msg, kind); } catch (e) {}
  }
  function askConfirm(title, text) {
    try {
      if (typeof window.confirmDialog === 'function') {
        return window.confirmDialog(title, text);
      }
    } catch (e) {}
    return Promise.resolve(true);
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try { return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null; }
    catch (e) { return null; }
  }

  /* ============================================================
   * PREDICATE — isSmsBlocked(uid)
   * I have blocked this user.
   * ============================================================ */
  function isSmsBlocked(uid) {
    if (!uid) return false;
    return !!window.smsBlockedUsers[uid];
  }

  /* ============================================================
   * REVERSE PREDICATE — has the PEER blocked me?
   * Used by 112-chat-open.js (sendMessage) to reject writes to a
   * peer who has SMS-blocked the current user.
   * ============================================================ */
  async function isSmsBlockedByPeer(peerUid, myUidOverride) {
    if (!peerUid) return false;
    var myUid = myUidOverride || getMyUid();
    if (!myUid) return false;
    if (peerUid === myUid) return false;

    var fbDb = getDB();
    if (!fbDb) return false;

    try {
      var snap = await fbDb.ref('smsBlocks/' + peerUid + '/' + myUid).get();
      return snap.exists();
    } catch (e) {
      return false;
    }
  }

  /* ============================================================
   * LISTENER LIFECYCLE
   * ============================================================ */
  function startListener() {
    if (smsBlockRef && smsBlockCb) return true;

    var fbDb = getDB();
    var uid  = getMyUid();
    if (!fbDb || !uid) return false;

    smsBlockRef = fbDb.ref('smsBlocks/' + uid);
    smsBlockCb  = smsBlockRef.on('value', function (s) {
      window.smsBlockedUsers = s.val() || {};
      try {
        window.dispatchEvent(new CustomEvent('saiko:sms-block-changed', {
          detail: { map: window.smsBlockedUsers }
        }));
      } catch (e) {}
    });
    return true;
  }

  function detachListener() {
    if (smsBlockRef && smsBlockCb) {
      try { smsBlockRef.off('value', smsBlockCb); } catch (e) {}
    }
    smsBlockRef = null;
    smsBlockCb  = null;
    window.smsBlockedUsers = {};
    return true;
  }

  /* ============================================================
   * TOGGLE — write path
   * ============================================================ */
  async function toggleSmsBlock(uid) {
    if (!uid) return false;

    var me = getMyUid();
    var fbDb = getDB();
    if (!me || !fbDb) return false;

    var ref = fbDb.ref('smsBlocks/' + me + '/' + uid);

    try {
      if (isSmsBlocked(uid)) {
        await ref.remove();
        safeToast(T('unblocked'), 'ok');
      } else {
        var ok = await askConfirm(T('sms_block'), T('block_sms_confirm'));
        if (!ok) return false;
        await ref.set(true);
        safeToast(T('sms_blocked'), 'ok');
      }
    } catch (err) {
      return false;
    }

    try {
      window.dispatchEvent(new CustomEvent('saiko:sms-block-changed', {
        detail: { targetUid: uid, blocked: isSmsBlocked(uid) }
      }));
    } catch (e) {}

    return true;
  }

  function getMap() { return window.smsBlockedUsers; }
  function getCount() { return Object.keys(window.smsBlockedUsers || {}).length; }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.isSmsBlocked              = isSmsBlocked;
  window.isSmsBlockedByPeer        = isSmsBlockedByPeer;
  window.toggleSmsBlock            = toggleSmsBlock;
  window.startSmsBlockedListener   = startListener;
  window.detachSmsBlockedListener  = detachListener;

  window.SaikoSmsBlock = {
    isBlocked: isSmsBlocked,
    isBlockedByPeer: isSmsBlockedByPeer,
    toggle: toggleSmsBlock,
    startListener: startListener,
    detachListener: detachListener,
    getMap: getMap,
    getCount: getCount
  };

  try { console.debug('[boot] feature 154 — sms-block ready (with reverse-check)'); } catch (e) {}
})();