/* ============================================================
 * SUPPORTING FILE (NON-NUMBERED)
 * FILE:   js/chat/chat-themes-core.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Chat-theme subsystem core. Owns:
 *     • CHAT_THEMES    — array of 15 theme descriptors
 *     • CHAT_THEME_KEY — localStorage key prefix
 *     • applyChatTheme(chatId)  — pushes theme colours into
 *                                 CSS custom properties
 *     • getThemeId / setThemeId / getThemeById / getThemeList
 *
 *   This is the modular extraction of §2 THEMES from the
 *   original single-file build. Every chat-related module
 *   (feature 128+, 153, 021) reads CHAT_THEMES and calls
 *   applyChatTheme() — so this file must load before them.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §2 THEMES
 *       const CHAT_THEMES = [ … 15 objects … ];
 *       const CHAT_THEME_KEY = 'saiko_chat_theme_';
 *   Section §22 CHAT
 *       function applyChatTheme(chatId) { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   none  (pure constants + DOM custom-property writers)
 *
 * DOM ELEMENTS USED:
 *   document.documentElement      (CSS custom properties)
 *   #chatBody      (inline background, if open)
 *   #chatInputBar  (inline background, if open)
 *   #replyBar      (inline background, if open)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : 'saiko_chat_theme_<chatId>'  (read + write)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.CHAT_THEMES
 *   window.CHAT_THEME_KEY
 *   window.applyChatTheme
 *   window.SaikoChatThemesCore = {
 *     CHAT_THEMES, CHAT_THEME_KEY,
 *     applyChatTheme,
 *     getThemeId, setThemeId,
 *     getThemeById, getThemeList,
 *     clearThemeVariables
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * CHAT_THEMES — 15 themes, EXACT copy from original §2.
   * Order preserved, field names preserved.
   * ---------------------------------------------------------- */
  var CHAT_THEMES = [
    { id:'default',  name:'Default',     me:'#7c5cff', you:'#1c2030', meText:'#ffffff', youText:'#eef1f8', bg:'#0a0b10', input:'#101219' },
    { id:'midnight', name:'Midnight',    me:'#374151', you:'#1f2937', meText:'#f9fafb', youText:'#f9fafb', bg:'#0b1020', input:'#111827' },
    { id:'ocean',    name:'Ocean',       me:'#0ea5e9', you:'#0c4a6e', meText:'#ffffff', youText:'#e0f2fe', bg:'#04202f', input:'#062f42' },
    { id:'forest',   name:'Forest',      me:'#16a34a', you:'#14532d', meText:'#ffffff', youText:'#dcfce7', bg:'#04180e', input:'#07281a' },
    { id:'sunset',   name:'Sunset',      me:'#f97316', you:'#7c2d12', meText:'#ffffff', youText:'#ffedd5', bg:'#2b0f05', input:'#3b1507' },
    { id:'lavender', name:'Lavender',    me:'#a78bfa', you:'#312e81', meText:'#ffffff', youText:'#ede9fe', bg:'#150f2e', input:'#1e1741' },
    { id:'rose',     name:'Rose',        me:'#f43f5e', you:'#4c0519', meText:'#ffffff', youText:'#ffe4e6', bg:'#20040c', input:'#2e0712' },
    { id:'emerald',  name:'Emerald',     me:'#059669', you:'#064e3b', meText:'#ffffff', youText:'#d1fae5', bg:'#031a14', input:'#05271d' },
    { id:'cyber',    name:'Cyber',       me:'#06b6d4', you:'#083344', meText:'#ffffff', youText:'#cffafe', bg:'#04161c', input:'#062430' },
    { id:'minimal',  name:'Minimal',     me:'#e5e7eb', you:'#f3f4f6', meText:'#111827', youText:'#111827', bg:'#fafafa', input:'#ffffff' },
    { id:'mono',     name:'Mono',        me:'#404040', you:'#262626', meText:'#fafafa', youText:'#fafafa', bg:'#0a0a0a', input:'#141414' },
    { id:'neon',     name:'Neon',        me:'#22ff88', you:'#0b1d15', meText:'#001b0d', youText:'#b9ffd8', bg:'#030d08', input:'#06170f' },
    { id:'sky',      name:'Sky',         me:'#38bdf8', you:'#082f49', meText:'#ffffff', youText:'#e0f2fe', bg:'#03192b', input:'#052338' },
    { id:'coffee',   name:'Coffee',      me:'#92400e', you:'#3f1d0c', meText:'#fef3c7', youText:'#fef3c7', bg:'#1a0e05', input:'#241408' },
    { id:'dpurple',  name:'Dark Purple', me:'#5b21b6', you:'#2e1065', meText:'#ffffff', youText:'#ede9fe', bg:'#100425', input:'#190a35' }
  ];

  /* ----------------------------------------------------------
   * CHAT_THEME_KEY — localStorage key prefix.
   * Full key: 'saiko_chat_theme_' + chatId
   * ---------------------------------------------------------- */
  var CHAT_THEME_KEY = 'saiko_chat_theme_';

  /* ----------------------------------------------------------
   * getThemeById — safe lookup
   * ---------------------------------------------------------- */
  function getThemeById(id) {
    for (var i = 0; i < CHAT_THEMES.length; i++) {
      if (CHAT_THEMES[i].id === id) return CHAT_THEMES[i];
    }
    return CHAT_THEMES[0]; // default
  }

  function getThemeList() {
    return CHAT_THEMES.slice();
  }

  /* ----------------------------------------------------------
   * getThemeId — read stored theme id for a chat
   * ---------------------------------------------------------- */
  function getThemeId(chatId) {
    if (!chatId) return 'default';
    try {
      var v = localStorage.getItem(CHAT_THEME_KEY + chatId);
      if (v) return v;
    } catch (e) {}
    return 'default';
  }

  /* ----------------------------------------------------------
   * setThemeId — persist the theme id for a chat
   * Returns true on success, false otherwise.
   * ---------------------------------------------------------- */
  function setThemeId(chatId, themeId) {
    if (!chatId || !themeId) return false;
    try {
      localStorage.setItem(CHAT_THEME_KEY + chatId, themeId);
      return true;
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * clearThemeVariables — remove all chat-theme CSS vars.
   * Preserved from detachChat() in the original:
   *   document.documentElement.style.removeProperty('--bubble-me');
   *   … etc
   * Called when a chat closes so the rest of the app is not
   * tinted by the last chat's palette.
   * ---------------------------------------------------------- */
  function clearThemeVariables() {
    var root = document.documentElement;
    if (!root) return;
    root.style.removeProperty('--bubble-me');
    root.style.removeProperty('--bubble-you');
    root.style.removeProperty('--bubble-me-text');
    root.style.removeProperty('--bubble-you-text');
    root.style.removeProperty('--chat-bg');
    root.style.removeProperty('--chat-input-bg');
  }

  /* ----------------------------------------------------------
   * applyChatTheme — write the selected theme's colours into
   * the CSS custom properties + directly onto the chat DOM
   * containers (as the original does).
   *
   * Preserved 1:1 from original applyChatTheme(chatId).
   * ---------------------------------------------------------- */
  function applyChatTheme(chatId) {
    var themeId = getThemeId(chatId);
    var theme = getThemeById(themeId);

    var root = document.documentElement;
    if (!root) return;

    /* 1) Custom properties ---------------------------------- */
    root.style.setProperty('--bubble-me', theme.me);
    root.style.setProperty('--bubble-you', theme.you);
    root.style.setProperty('--bubble-me-text', theme.meText);
    root.style.setProperty('--bubble-you-text', theme.youText || 'var(--text)');
    root.style.setProperty('--chat-bg', theme.bg);
    root.style.setProperty('--chat-input-bg', theme.input);

    /* 2) Direct inline styles on live chat containers ------- *
     *  (Original did this so themes apply instantly even if
     *   a CSS var somehow didn't cascade.)
     * ------------------------------------------------------ */
    var body = document.getElementById('chatBody');
    if (body) body.style.background = theme.bg;

    var bar = document.getElementById('chatInputBar');
    if (bar) bar.style.background = theme.input;

    var rb = document.getElementById('replyBar');
    if (rb) rb.style.background = theme.input;

    /* 3) Notify subscribers -------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:chat-theme-applied', {
        detail: { chatId: chatId, themeId: themeId, theme: theme }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * EXPOSE on window
   * ---------------------------------------------------------- */
  window.CHAT_THEMES = CHAT_THEMES;
  window.CHAT_THEME_KEY = CHAT_THEME_KEY;
  window.applyChatTheme = applyChatTheme;

  window.SaikoChatThemesCore = {
    CHAT_THEMES: CHAT_THEMES,
    CHAT_THEME_KEY: CHAT_THEME_KEY,
    applyChatTheme: applyChatTheme,
    getThemeId: getThemeId,
    setThemeId: setThemeId,
    getThemeById: getThemeById,
    getThemeList: getThemeList,
    clearThemeVariables: clearThemeVariables
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] chat-themes-core ready');
  } catch (e) {}

})();