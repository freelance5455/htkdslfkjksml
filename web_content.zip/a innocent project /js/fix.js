/* ============================================================
 * SAIKO BULLETPROOF FIX — v1
 * FILE: js/_fix.js
 * PURPOSE:
 *   1. Guarantee window.prefs exists
 *   2. Guarantee applyPrefs / savePrefs exist
 *   3. Detect if 040-settings-router.js is loaded
 *   4. If not loaded → dynamically load it
 *   5. If file missing  → install fallback router
 *      (Appearance + Language fully working)
 *   6. Show on-screen status banner
 * ============================================================ */
(function () {
  'use strict';

  console.log('[fix] starting — v1');

  /* ============================================================
   * PART 1 — PREFS GUARANTEE
   * ============================================================ */
  var DEFAULT_PREFS = {
    accent: '#7c5cff', scale: 50, dark: true, lang: 'en',
    showOnline: true, showLastSeen: true, callPerm: 'everyone',
    showReadReceipts: true, enterToSend: true, autoDownload: true,
    notifSound: false, reducedMotion: false, dataSaver: false,
    performanceMode: false, e2eEnabled: true, typingIndicator: true,
    appLock: false, appLockPin: '', feedMode: 'latest',
    storyPrivacy: 'public', autoDeleteMsgs: 'off', profileTheme: 'default'
  };

  function ensurePrefs() {
    if (typeof window.prefs !== 'object' || window.prefs === null) {
      window.prefs = {};
    }
    var stored = {};
    try {
      var raw = localStorage.getItem('saiko_prefs_v7');
      if (raw) stored = JSON.parse(raw) || {};
    } catch (e) {}
    Object.keys(DEFAULT_PREFS).forEach(function (k) {
      if (typeof window.prefs[k] === 'undefined') {
        window.prefs[k] = (typeof stored[k] !== 'undefined') ? stored[k] : DEFAULT_PREFS[k];
      }
    });
  }

  function hexA(hex, a) {
    var h = String(hex || '#7c5cff').replace('#', '');
    var f = h.length === 3 ? h.split('').map(function (c) { return c + c; }).join('') : h;
    var n = parseInt(f, 16) || 0;
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  function applyPrefs() {
    var p = window.prefs || DEFAULT_PREFS;
    var root = document.documentElement;
    if (!root) return;
    root.style.setProperty('--accent', p.accent || DEFAULT_PREFS.accent);
    root.style.setProperty('--accent-soft', hexA(p.accent || DEFAULT_PREFS.accent, 0.16));
    root.style.setProperty('--accent-line', hexA(p.accent || DEFAULT_PREFS.accent, 0.45));
    var s = Number(p.scale);
    if (!isFinite(s) || s < 1) s = 50;
    if (s > 100) s = 100;
    root.style.setProperty('--scale', (0.55 + s / 100 * 0.9).toFixed(3));
    if (document.body) {
      document.body.classList.toggle('light', !p.dark);
      document.body.classList.toggle('reduced-motion', !!p.reducedMotion);
    }
    root.lang = p.lang || 'en';
  }

  function savePrefs() {
    try {
      localStorage.setItem('saiko_prefs_v7', JSON.stringify(window.prefs || {}));
    } catch (e) {}
  }

  ensurePrefs();
  if (typeof window.applyPrefs !== 'function') window.applyPrefs = applyPrefs;
  if (typeof window.savePrefs !== 'function') window.savePrefs = savePrefs;
  try { applyPrefs(); } catch (e) {}

  /* ============================================================
   * PART 2 — SMALL HELPERS
   * ============================================================ */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function T(k) {
    try { if (typeof window.t === 'function') return window.t(k); } catch (e) {}
    return k;
  }
  function qs(s, r) { return (r || document).querySelector(s); }
  function qsa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function openOverlaySafe(id) {
    try {
      if (typeof window.openOverlay === 'function') { window.openOverlay(id); return; }
    } catch (e) {}
    var o = document.getElementById(id);
    if (o) o.classList.add('open');
  }

  /* ============================================================
   * PART 3 — FALLBACK RENDERERS
   * ============================================================ */
  var PRESETS = ['#7c5cff','#2ecc8f','#ff5c6c','#3aa0ff','#ff9f43','#e84393',
                 '#00cec9','#a55eea','#fdcb6e','#e17055','#0984e3','#fd79a8'];

  var LANGS = [
    { code:'en', name:'English',    native:'English' },
    { code:'hi', name:'Hindi',      native:'हिन्दी' },
    { code:'es', name:'Spanish',    native:'Español' },
    { code:'fr', name:'French',     native:'Français' },
    { code:'de', name:'German',     native:'Deutsch' },
    { code:'pt', name:'Portuguese', native:'Português' },
    { code:'ru', name:'Russian',    native:'Русский' },
    { code:'ar', name:'Arabic',     native:'العربية' },
    { code:'zh', name:'Chinese',    native:'中文' },
    { code:'ja', name:'Japanese',   native:'日本語' },
    { code:'ko', name:'Korean',     native:'한국어' },
    { code:'id', name:'Indonesian', native:'Bahasa Indonesia' },
    { code:'tr', name:'Turkish',    native:'Türkçe' },
    { code:'bn', name:'Bengali',    native:'বাংলা' },
    { code:'ur', name:'Urdu',       native:'اردو' },
    { code:'it', name:'Italian',    native:'Italiano' },
    { code:'nl', name:'Dutch',      native:'Nederlands' },
    { code:'pl', name:'Polish',     native:'Polski' },
    { code:'th', name:'Thai',       native:'ไทย' },
    { code:'vi', name:'Vietnamese', native:'Tiếng Việt' },
    { code:'fa', name:'Persian',    native:'فارسی' },
    { code:'sw', name:'Swahili',    native:'Kiswahili' }
  ];

  function renderAppearance() {
    var p = window.prefs;
    var accent = String(p.accent || '#7c5cff');
    var swatches = PRESETS.map(function (c) {
      var sel = accent.toLowerCase() === c.toLowerCase() ? ' sel' : '';
      return '<div class="swatch' + sel + '" data-c="' + c + '" style="background:' + c + '"></div>';
    }).join('');
    return '<div class="sec-title">' + esc(T('appearance') || 'Appearance / Color') + '</div>' +
      '<div class="swatches" id="swatches">' + swatches + '</div>' +
      '<div class="field"><label>Custom Color</label>' +
        '<input type="color" id="accentPick" value="' + esc(accent) + '">' +
      '</div>' +
      '<button class="btn solid block" id="accentSave">' + esc(T('save') || 'Save') + '</button>' +
      '<div class="sec-title" style="margin-top:1rem">' + esc(T('dark_mode') || 'Dark Mode') + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (p.dark ? 'active' : '') + '" id="darkOn">' + esc(T('on') || 'ON') + '</button>' +
        '<button class="btn ' + (!p.dark ? 'active' : '') + '" id="darkOff">' + esc(T('off') || 'OFF') + '</button>' +
      '</div>' +
      '<div class="sec-title">' + esc(T('ui_size') || 'UI Size') + '</div>' +
      '<div style="text-align:center;font-weight:800;font-size:1.4rem" id="sizeVal">' +
        esc(String(p.scale || 50)) + '%' +
      '</div>' +
      '<input type="range" min="1" max="100" value="' + esc(String(p.scale || 50)) + '" id="sizeRange">';
  }

  function wireAppearance() {
    var pick = qs('#accentPick');
    qsa('#swatches .swatch').forEach(function (s) {
      s.addEventListener('click', function () {
        var c = s.getAttribute('data-c');
        if (pick) pick.value = c;
        window.prefs.accent = c;
        window.savePrefs();
        window.applyPrefs();
        qsa('#swatches .swatch').forEach(function (x) { x.classList.toggle('sel', x === s); });
      });
    });
    if (pick) {
      pick.addEventListener('input', function () {
        window.prefs.accent = pick.value; window.applyPrefs();
      });
      pick.addEventListener('change', function () {
        window.prefs.accent = pick.value; window.savePrefs(); window.applyPrefs();
      });
    }
    var saveBtn = qs('#accentSave');
    if (saveBtn) {
      saveBtn.addEventListener('click', function () {
        if (pick) window.prefs.accent = pick.value;
        window.savePrefs(); window.applyPrefs();
        try { if (typeof window.toast === 'function') window.toast(T('saved') || 'Saved', 'ok'); } catch (e) {}
      });
    }
    var dOn = qs('#darkOn');
    if (dOn) dOn.addEventListener('click', function () {
      window.prefs.dark = true; window.savePrefs(); window.applyPrefs();
      dOn.classList.add('active');
      var d2 = qs('#darkOff'); if (d2) d2.classList.remove('active');
    });
    var dOff = qs('#darkOff');
    if (dOff) dOff.addEventListener('click', function () {
      window.prefs.dark = false; window.savePrefs(); window.applyPrefs();
      dOff.classList.add('active');
      var d2 = qs('#darkOn'); if (d2) d2.classList.remove('active');
    });
    var r = qs('#sizeRange');
    if (r) {
      r.addEventListener('input', function () {
        window.prefs.scale = Number(r.value);
        var v = qs('#sizeVal'); if (v) v.textContent = window.prefs.scale + '%';
        window.applyPrefs();
      });
      r.addEventListener('change', function () { window.savePrefs(); });
    }
  }

  function renderLanguage() {
    var cur = window.prefs.lang || 'en';
    var rows = LANGS.map(function (l) {
      var sel = cur === l.code ? ' sel' : '';
      var check = cur === l.code ? '<span class="ic">✓</span>' : '';
      return '<div class="lang-item' + sel + '" data-lang="' + l.code + '">' +
               '<span>' + esc(l.native) +
                 ' <span class="muted" style="font-size:.75rem">(' + esc(l.name) + ')</span>' +
               '</span>' + check +
             '</div>';
    }).join('');
    return '<div class="searchbar">' +
        '<span class="ic">🔍</span>' +
        '<input type="search" id="langSearch" placeholder="' +
          esc(T('search_lang_ph') || 'Search language...') + '">' +
      '</div>' +
      '<div id="langList">' + rows + '</div>';
  }

  function wireLanguage() {
    qsa('#langList [data-lang]').forEach(function (n) {
      n.addEventListener('click', function () {
        window.prefs.lang = n.getAttribute('data-lang');
        window.savePrefs();
        if (typeof window.applyPrefs === 'function') window.applyPrefs();
        if (typeof window.applyI18n === 'function') window.applyI18n();
        try { if (typeof window.buildNavIcons === 'function') window.buildNavIcons(); } catch (e) {}
        try {
          var body = qs('#settingPageBody');
          if (body) { body.innerHTML = renderLanguage(); wireLanguage(); }
        } catch (e) {}
        try { if (typeof window.toast === 'function') window.toast(T('saved') || 'Saved', 'ok'); } catch (e) {}
      });
    });
    var s = qs('#langSearch');
    if (s) {
      s.addEventListener('input', function () {
        var q = (s.value || '').toLowerCase();
        qsa('#langList [data-lang]').forEach(function (n) {
          var code = n.getAttribute('data-lang');
          var l = null;
          for (var i = 0; i < LANGS.length; i++) {
            if (LANGS[i].code === code) { l = LANGS[i]; break; }
          }
          if (!l) return;
          n.style.display = (!q ||
            l.name.toLowerCase().indexOf(q) !== -1 ||
            l.native.toLowerCase().indexOf(q) !== -1) ? '' : 'none';
        });
      });
    }
  }

  function renderGeneric(key) {
    return '<div class="sec-title">' + esc(T(key) || key) + '</div>' +
      '<div class="empty"><p>' + esc(T('no_data') || 'No data') + '</p></div>';
  }

  /* ============================================================
   * PART 4 — FALLBACK ROUTER INSTALL
   * ============================================================ */
  var _fallbackInstalled = false;

  function installFallbackRouter() {
    if (_fallbackInstalled) return true;
    _fallbackInstalled = true;

    console.log('[fix] installing FALLBACK openSettingPage (appearance + language)');

    window.openSettingPage = function (key) {
      var titleEl = qs('#settingPageTitle');
      var body = qs('#settingPageBody');
      if (!body) { console.warn('[fix] #settingPageBody not found'); return false; }
      if (titleEl) titleEl.textContent = T(key) || key;

      if (key === 'appearance') {
        body.innerHTML = renderAppearance();
        openOverlaySafe('ovSettingPage');
        wireAppearance();
        return true;
      }
      if (key === 'language') {
        body.innerHTML = renderLanguage();
        openOverlaySafe('ovSettingPage');
        wireLanguage();
        return true;
      }
      body.innerHTML = renderGeneric(key);
      openOverlaySafe('ovSettingPage');
      return true;
    };

    return true;
  }

  /* ============================================================
   * PART 5 — DETECT & LOAD 040-settings-router.js
   * ============================================================ */
  function hasRouterScriptTag() {
    var scripts = document.getElementsByTagName('script');
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].src || '';
      if (src.indexOf('040-settings-router.js') !== -1) return true;
    }
    return false;
  }

  function showBanner(text, ok) {
    try {
      var old = document.getElementById('__fix_banner');
      if (old) old.remove();
      var b = document.createElement('div');
      b.id = '__fix_banner';
      b.style.cssText = 'position:fixed;left:.7rem;right:.7rem;bottom:5rem;padding:.6rem .8rem;' +
        'border-radius:.7rem;font-weight:700;font-size:.76rem;z-index:99999;text-align:center;' +
        'box-shadow:0 6px 20px rgba(0,0,0,.4);' +
        (ok ? 'background:#2ecc8f;color:#062014;' : 'background:#ff5c6c;color:#fff;');
      b.textContent = text;
      document.body.appendChild(b);
      setTimeout(function () { try { b.remove(); } catch (e) {} }, 6000);
    } catch (e) {}
  }

  function checkAndFix() {
    var hasTag = hasRouterScriptTag();
    var hasFn  = typeof window.openSettingPage === 'function';

    console.log('[fix] hasRouterScriptTag:', hasTag, '| openSettingPage defined:', hasFn);

    if (hasTag && hasFn) {
      console.log('[fix] ✓ original router present — nothing to do');
      showBanner('✓ Fix active — original router OK', true);
      return;
    }

    if (!hasTag) {
      console.log('[fix] 040-settings-router.js script tag MISSING — loading dynamically');
      try {
        var s = document.createElement('script');
        s.src = 'js/nav/040-settings-router.js';
        s.onload = function () {
          console.log('[fix] ✓ dynamically loaded 040-settings-router.js');
          setTimeout(function () {
            if (typeof window.openSettingPage === 'function') {
              showBanner('✓ Fix loaded router dynamically', true);
            } else {
              installFallbackRouter();
              showBanner('✓ Fix installed fallback', true);
            }
          }, 300);
        };
        s.onerror = function () {
          console.warn('[fix] ✗ failed to load 040-settings-router.js — installing fallback');
          installFallbackRouter();
          showBanner('⚠ Router file missing — fallback installed', false);
        };
        (document.body || document.head || document.documentElement).appendChild(s);

        setTimeout(function () {
          if (typeof window.openSettingPage !== 'function') {
            console.log('[fix] router still not loaded after 1.5s — installing fallback');
            installFallbackRouter();
            showBanner('⚠ Router not loaded — fallback installed', false);
          }
        }, 1500);
      } catch (e) {
        console.warn('[fix] script injection failed', e);
        installFallbackRouter();
      }
      return;
    }

    if (hasTag && !hasFn) {
      console.log('[fix] tag present but openSettingPage not defined — installing fallback');
      installFallbackRouter();
      showBanner('⚠ Router broken — fallback installed', false);
      return;
    }
  }

  /* ============================================================
   * PART 6 — RUN
   * ============================================================ */
  function run() {
    setTimeout(checkAndFix, 800);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  } else {
    run();
  }

  console.log('[fix] _fix.js armed');

})();