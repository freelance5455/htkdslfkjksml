/* ============================================================
 * FEATURE:        Offline Popup (Boot-time) — v2
 * FILE:           js/games/026-offline-popup.js
 * ACTION:         REPLACE (v2 — cache-then-open flow)
 * ============================================================ */

(function () {
  'use strict';

  var OVERLAY_ID   = 'ovOfflinePopup';
  var BOOT_WAIT_MS = 1000;
  var Z_INDEX      = 9990;

  var _overlayEl = null;
  var _shown = false;
  var _busy  = false;

  /* ============ HELPERS ============ */
  function isOnline() {
    try { return !!navigator.onLine; } catch (e) { return true; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[offline-popup] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ============================================================
   * OVERLAY BUILD
   * ============================================================ */
  function buildOverlay() {
    if (_overlayEl && _overlayEl.parentNode) return _overlayEl;

    var ov = document.createElement('div');
    ov.id = OVERLAY_ID;
    ov.style.cssText =
      'position:fixed;inset:0;z-index:' + Z_INDEX + ';' +
      'background:radial-gradient(900px 500px at 20% -10%,rgba(124,92,255,.22),transparent 60%),' +
      'radial-gradient(900px 500px at 110% 110%,rgba(58,160,255,.16),transparent 60%),' +
      'rgba(5,8,16,.92);' +
      'backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);' +
      'display:none;align-items:center;justify-content:center;' +
      'padding:1.2rem;';

    ov.innerHTML =
      '<div style="' +
        'max-width:22rem;width:100%;' +
        'background:linear-gradient(180deg,#131a2e 0%,#0c1526 100%);' +
        'border:1px solid rgba(124,92,255,.3);' +
        'border-radius:1.4rem;padding:1.6rem 1.3rem 1.4rem;' +
        'box-shadow:0 20px 60px rgba(0,0,0,.6),0 0 0 1px rgba(58,160,255,.1) inset;' +
        'text-align:center;animation:__offPop .38s cubic-bezier(.2,.9,.3,1.2);' +
      '">' +

        '<div style="' +
          'width:4.2rem;height:4.2rem;border-radius:50%;margin:0 auto .9rem;' +
          'background:linear-gradient(135deg,rgba(124,92,255,.22),rgba(58,160,255,.15));' +
          'border:1.5px solid rgba(124,92,255,.4);' +
          'display:flex;align-items:center;justify-content:center;' +
          'box-shadow:0 0 24px rgba(124,92,255,.3);' +
        '">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="#a5b0c5" stroke-width="1.9" ' +
          'stroke-linecap="round" stroke-linejoin="round" style="width:2rem;height:2rem">' +
            '<path d="M5 12.5a10 10 0 0 1 14 0"/>' +
            '<path d="M8.5 16a5 5 0 0 1 7 0"/>' +
            '<circle cx="12" cy="20" r=".6" fill="#a5b0c5" stroke="none"/>' +
            '<path d="m3 3 18 18" stroke="#ff5c6c"/>' +
          '</svg>' +
        '</div>' +

        '<div style="font-size:1.25rem;font-weight:800;color:#fff;letter-spacing:-.01em;margin-bottom:.35rem">' +
          'You are offline' +
        '</div>' +

        '<div style="font-size:.82rem;color:#8b93a7;line-height:1.45;margin-bottom:1.2rem">' +
          'No internet connection detected. You can still play offline games while we wait.' +
        '</div>' +

        '<button id="ovOfflinePlay" style="' +
          'display:flex;align-items:center;justify-content:center;gap:.5rem;' +
          'width:100%;padding:.85rem 1rem;border-radius:1rem;' +
          'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
          'color:#fff;font-size:.92rem;font-weight:800;' +
          'border:none;cursor:pointer;letter-spacing:.01em;' +
          'box-shadow:0 8px 24px rgba(124,92,255,.5);' +
          'transition:transform .14s ease;' +
          '-webkit-tap-highlight-color:transparent;' +
        '">' +
          '<span style="font-size:1.1rem">🎮</span>' +
          '<span id="ovOfflinePlayLabel">Play Offline Game</span>' +
        '</button>' +

        '<button id="ovOfflineClose" style="' +
          'margin-top:.7rem;background:none;border:none;' +
          'color:#8b93a7;font-size:.78rem;font-weight:600;' +
          'cursor:pointer;padding:.4rem .6rem;border-radius:.6rem;' +
          'transition:color .18s;' +
          '-webkit-tap-highlight-color:transparent;' +
        '">Continue anyway</button>' +

      '</div>' +

      '<style>' +
        '@keyframes __offPop{' +
          'from{opacity:0;transform:translateY(1rem) scale(.96);}' +
          'to{opacity:1;transform:none;}' +
        '}' +
      '</style>';

    document.body.appendChild(ov);
    _overlayEl = ov;

    /* ---- Play button → ensure cache then open ---- */
    var playBtn = ov.querySelector('#ovOfflinePlay');
    if (playBtn) {
      playBtn.addEventListener('click', function () {
        handlePlayClick(playBtn);
      });
    }

    /* ---- Close link ---- */
    var closeBtn = ov.querySelector('#ovOfflineClose');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () { hide(); });
    }

    return ov;
  }

  /* ============================================================
   * PLAY CLICK — smart flow
   * ============================================================ */
  async function handlePlayClick(btnEl) {
    if (_busy) return;
    _busy = true;

    var labelEl = _overlayEl ? _overlayEl.querySelector('#ovOfflinePlayLabel') : null;
    var origLabel = labelEl ? labelEl.textContent : 'Play Offline Game';

    try {
      if (btnEl) {
        btnEl.style.pointerEvents = 'none';
        btnEl.style.opacity = '.85';
      }
      if (labelEl) labelEl.textContent = 'Preparing…';

      /* 1) Do we already have cached games? */
      var hasCache = false;
      try {
        if (window.SaikoOfflineGames && typeof window.SaikoOfflineGames.list === 'function') {
          var cached = await window.SaikoOfflineGames.list();
          hasCache = !!(cached && cached.length);
        }
      } catch (e) {}

      /* 2) No cache + online → fetch it now (bypassing throttle) */
      if (!hasCache && navigator.onLine &&
          window.SaikoOfflineGames &&
          typeof window.SaikoOfflineGames.ensureGamesCached === 'function') {
        if (labelEl) labelEl.textContent = 'Downloading games…';
        try {
          await window.SaikoOfflineGames.ensureGamesCached();
        } catch (e) {}
      }

      /* 3) Hide popup + open the offline games modal */
      hide();

      if (typeof window.openOfflineGames === 'function') {
        window.openOfflineGames();
      } else {
        var fb = document.getElementById('offlineGameBtn');
        if (fb) fb.click();
      }

      /* If we were offline AND no cache, warn the user */
      if (!hasCache && !navigator.onLine) {
        setTimeout(function () {
          safeToast('Connect internet once to download games', 'err');
        }, 400);
      }
    } catch (e) {
      console.warn('[offline-popup] play error', e);
      safeToast('Unable to load games', 'err');
    } finally {
      _busy = false;
      if (btnEl) {
        btnEl.style.pointerEvents = '';
        btnEl.style.opacity = '';
      }
      if (labelEl) labelEl.textContent = origLabel;
    }
  }

  /* ============================================================
   * SHOW / HIDE
   * ============================================================ */
  function show() {
    if (_shown) return false;
    if (isOnline()) return false;
    if (!document.body) return false;

    var ov = buildOverlay();
    ov.style.display = 'flex';
    _shown = true;
    return true;
  }

  function hide() {
    if (!_overlayEl) return false;
    _overlayEl.style.display = 'none';
    _shown = false;
    return true;
  }

  function isShown() { return _shown; }

  /* ============================================================
   * NETWORK EVENTS
   * ============================================================ */
  function onOnline() {
    hide();
    /* Also trigger a fresh cache on reconnect */
    if (window.SaikoOfflineGames && typeof window.SaikoOfflineGames.cache === 'function') {
      setTimeout(function () {
        try { window.SaikoOfflineGames.cache(); } catch (e) {}
      }, 1500);
    }
  }

  function onOffline() {
    setTimeout(function () {
      var splash = document.getElementById('splash');
      var lock = document.getElementById('lockScreen');
      var splashShowing = splash && !splash.classList.contains('hide');
      var lockShowing = lock && !lock.classList.contains('hidden');

      if (!splashShowing && !lockShowing) {
        show();
      }
    }, 300);
  }

  /* ============================================================
   * BOOT
   * ============================================================ */
  function boot() {
    setTimeout(function () {
      if (!isOnline()) {
        var lock = document.getElementById('lockScreen');
        var lockShowing = lock && !lock.classList.contains('hidden');

        if (!lockShowing) {
          show();
        } else {
          var checkLock = setInterval(function () {
            var stillLocked = lock && !lock.classList.contains('hidden');
            if (!stillLocked) {
              clearInterval(checkLock);
              if (!isOnline()) show();
            }
          }, 600);
        }
      }
    }, BOOT_WAIT_MS);

    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    /* Trigger a background cache on boot if online + logged in */
    setTimeout(function () {
      if (!navigator.onLine) return;
      if (!window.myUid) return;
      if (window.SaikoOfflineGames && typeof window.SaikoOfflineGames.cache === 'function') {
        try { window.SaikoOfflineGames.cache(); } catch (e) {}
      }
    }, 3000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.SaikoOfflinePopup = {
    show: show,
    hide: hide,
    isShown: isShown,
    isOnline: isOnline,
    forcePlay: function () { handlePlayClick(null); }
  };

  try {
    console.debug('[boot] feature 026 — offline-popup ready (v2)');
  } catch (e) {}

})();