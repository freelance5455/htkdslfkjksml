/* ============================================================
 * GAMES CORE — Premium Neon Gaming UI (v2)
 * FILE:   js/games/024-games-core.js
 * ACTION: REPLACE (v2 — premium redesign, functionality preserved)
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * 1. INJECT PREMIUM CSS (scoped to .gs-* classes)
   * ============================================================ */
  (function injectGamesCSS() {
    if (document.getElementById('__saiko_games_css_v2')) return;
    var s = document.createElement('style');
    s.id = '__saiko_games_css_v2';
    s.textContent =
      /* --- Page wrapper --- */
      '#page-games{padding:.7rem .8rem 6rem;}' +

      /* --- Header --- */
      '.gs-header{display:flex;align-items:center;gap:.75rem;margin:.2rem 0 1rem;}' +
      '.gs-header-icon{' +
        'width:2.8rem;height:2.8rem;border-radius:.85rem;flex:0 0 auto;' +
        'background:linear-gradient(135deg,#7c5cff,#3aa0ff);' +
        'display:flex;align-items:center;justify-content:center;color:#fff;' +
        'box-shadow:0 8px 22px rgba(124,92,255,.35);' +
      '}' +
      '.gs-header-icon svg{width:1.5rem;height:1.5rem;}' +
      '.gs-header-titles{flex:1;min-width:0;}' +
      '.gs-header-title{font-size:1.55rem;font-weight:800;letter-spacing:-.02em;line-height:1.1;color:#fff;}' +
      '.gs-header-sub{font-size:.74rem;color:#8b93a7;margin-top:.15rem;}' +
      '.gs-xp-badge{' +
        'display:inline-flex;align-items:center;gap:.4rem;' +
        'padding:.45rem .75rem;border-radius:1rem;' +
        'background:linear-gradient(135deg,rgba(255,176,32,.18),rgba(255,92,108,.15));' +
        'border:1px solid rgba(255,176,32,.35);' +
        'color:#ffb020;font-size:.72rem;font-weight:700;' +
        'white-space:nowrap;' +
      '}' +
      '.gs-xp-badge svg{width:.9rem;height:.9rem;}' +

      /* --- Search bar --- */
      '.gs-search{' +
        'display:flex;align-items:center;gap:.55rem;' +
        'padding:.7rem .85rem;border-radius:1rem;' +
        'background:rgba(22,34,54,.65);' +
        'border:1px solid rgba(124,92,255,.18);' +
        'margin-bottom:.85rem;' +
        'backdrop-filter:blur(8px);' +
      '}' +
      '.gs-search svg{width:1.05rem;height:1.05rem;color:#8b93a7;flex:0 0 auto;}' +
      '.gs-search input{' +
        'flex:1;background:transparent;border:none;outline:none;' +
        'font-size:.88rem;color:#eef1f8;min-width:0;' +
      '}' +
      '.gs-search input::placeholder{color:#6b7285;}' +
      '.gs-search .gs-filter-icon{color:#7c5cff;opacity:.85;}' +

      /* --- Category pills --- */
      '.gs-cats{' +
        'display:flex;gap:.4rem;overflow-x:auto;padding-bottom:.6rem;margin-bottom:.9rem;' +
        'scrollbar-width:none;-webkit-overflow-scrolling:touch;' +
      '}' +
      '.gs-cats::-webkit-scrollbar{display:none;}' +
      '.gs-cat{' +
        'display:inline-flex;align-items:center;gap:.35rem;' +
        'padding:.5rem .85rem;border-radius:1rem;' +
        'background:rgba(22,34,54,.6);' +
        'border:1px solid rgba(124,92,255,.15);' +
        'color:#8b93a7;font-size:.76rem;font-weight:600;' +
        'white-space:nowrap;flex:0 0 auto;cursor:pointer;' +
        'transition:all .18s ease;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
      '}' +
      '.gs-cat svg{width:.9rem;height:.9rem;}' +
      '.gs-cat:active{transform:scale(.94);}' +
      '.gs-cat.sel{' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'color:#fff;border-color:transparent;' +
        'box-shadow:0 6px 18px rgba(124,92,255,.45);' +
      '}' +

      /* --- Hero banner --- */
      '.gs-hero{' +
        'position:relative;border-radius:1.15rem;overflow:hidden;' +
        'margin-bottom:1.1rem;min-height:11rem;' +
        'background:linear-gradient(135deg,#1a1040 0%,#2a1a6e 45%,#1e3a8a 100%);' +
        'border:1px solid rgba(124,92,255,.25);' +
        'box-shadow:0 10px 30px rgba(30,20,80,.55);' +
        'padding:1.1rem 1rem;' +
        'display:flex;align-items:center;' +
      '}' +
      '.gs-hero::before{' +
        'content:"";position:absolute;inset:0;pointer-events:none;' +
        'background:radial-gradient(circle at 80% 50%,rgba(124,92,255,.35),transparent 55%);' +
      '}' +
      '.gs-hero-content{position:relative;z-index:2;max-width:60%;}' +
      '.gs-hero-chip{' +
        'display:inline-flex;align-items:center;gap:.35rem;' +
        'padding:.28rem .6rem;border-radius:1rem;' +
        'background:rgba(124,92,255,.28);' +
        'border:1px solid rgba(124,92,255,.5);' +
        'color:#c4b5ff;font-size:.65rem;font-weight:700;' +
        'margin-bottom:.55rem;letter-spacing:.02em;' +
      '}' +
      '.gs-hero-chip svg{width:.75rem;height:.75rem;}' +
      '.gs-hero-title{' +
        'font-size:1.25rem;font-weight:800;color:#fff;' +
        'line-height:1.15;margin:0 0 .35rem;letter-spacing:-.02em;' +
      '}' +
      '.gs-hero-sub{' +
        'font-size:.72rem;color:#a5b0c5;line-height:1.35;' +
        'margin:0 0 .8rem;' +
      '}' +
      '.gs-hero-btn{' +
        'display:inline-flex;align-items:center;gap:.4rem;' +
        'padding:.5rem .85rem;border-radius:.75rem;' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'color:#fff;border:none;font-size:.76rem;font-weight:700;' +
        'cursor:pointer;box-shadow:0 6px 18px rgba(124,92,255,.5);' +
        'transition:transform .14s ease;' +
        '-webkit-tap-highlight-color:transparent;' +
      '}' +
      '.gs-hero-btn:active{transform:scale(.94);}' +
      '.gs-hero-btn svg{width:.85rem;height:.85rem;}' +
      '.gs-hero-art{' +
        'position:absolute;right:-1rem;top:50%;transform:translateY(-50%);' +
        'width:46%;max-width:11rem;opacity:.95;pointer-events:none;z-index:1;' +
      '}' +
      '.gs-hero-art svg{width:100%;height:auto;display:block;' +
        'filter:drop-shadow(0 0 20px rgba(124,92,255,.6));}' +

      /* --- Section heading --- */
      '.gs-section{' +
        'display:flex;align-items:center;justify-content:space-between;' +
        'margin:.5rem 0 .7rem;padding:0 .1rem;' +
      '}' +
      '.gs-section-title{' +
        'display:inline-flex;align-items:center;gap:.4rem;' +
        'font-size:1rem;font-weight:800;color:#fff;letter-spacing:-.01em;' +
      '}' +
      '.gs-section-title svg{width:1.05rem;height:1.05rem;color:#ffb020;}' +
      '.gs-section-action{' +
        'display:inline-flex;align-items:center;gap:.3rem;' +
        'font-size:.74rem;font-weight:700;color:#7c5cff;' +
        'background:none;border:none;padding:.3rem .5rem;' +
        'border-radius:.6rem;cursor:pointer;' +
        '-webkit-tap-highlight-color:transparent;' +
      '}' +
      '.gs-section-action:active{background:rgba(124,92,255,.15);}' +
      '.gs-section-action svg{width:.85rem;height:.85rem;}' +

      /* --- Grid --- */
      '.gs-grid{' +
        'display:grid;gap:.65rem;' +
        'grid-template-columns:repeat(auto-fill,minmax(9.5rem,1fr));' +
        'margin-bottom:1.1rem;' +
      '}' +

      /* --- Game card --- */
      '.gs-card{' +
        'position:relative;border-radius:1rem;overflow:hidden;' +
        'background:linear-gradient(180deg,#131a2e 0%,#0f1729 100%);' +
        'border:1px solid rgba(124,92,255,.14);' +
        'cursor:pointer;' +
        'transition:transform .16s ease,border-color .2s ease;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
        'display:flex;flex-direction:column;' +
      '}' +
      '.gs-card:active{transform:scale(.97);border-color:rgba(124,92,255,.4);}' +
      '.gs-card-img{' +
        'position:relative;width:100%;aspect-ratio:1/1;' +
        'background:#0a0f1e;overflow:hidden;flex:0 0 auto;' +
        'display:flex;align-items:center;justify-content:center;' +
      '}' +
      '.gs-card-img img{' +
        'width:100%;height:100%;object-fit:cover;display:block;' +
      '}' +
      '.gs-card-img .gs-fallback{' +
        'color:#4a5570;display:flex;align-items:center;justify-content:center;' +
        'width:100%;height:100%;' +
      '}' +
      '.gs-card-img .gs-fallback svg{width:2rem;height:2rem;}' +
      '.gs-card-badge{' +
        'position:absolute;top:.4rem;left:.4rem;z-index:2;' +
        'padding:.2rem .45rem;border-radius:.55rem;' +
        'font-size:.6rem;font-weight:800;color:#fff;' +
        'display:inline-flex;align-items:center;gap:.2rem;' +
        'letter-spacing:.02em;' +
        'backdrop-filter:blur(4px);' +
      '}' +
      '.gs-badge-popular{background:linear-gradient(135deg,#ff9f43,#ff7a1a);}' +
      '.gs-badge-trending{background:linear-gradient(135deg,#3aa0ff,#2563eb);}' +
      '.gs-badge-hot{background:linear-gradient(135deg,#ff5c6c,#e63946);}' +
      '.gs-card-body{' +
        'padding:.55rem .6rem .6rem;display:flex;flex-direction:column;gap:.15rem;flex:1;' +
      '}' +
      '.gs-card-name{' +
        'font-size:.82rem;font-weight:700;color:#fff;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.2;' +
      '}' +
      '.gs-card-cat{' +
        'font-size:.66rem;color:#8b93a7;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;' +
        'line-height:1.2;' +
      '}' +
      '.gs-card-foot{' +
        'display:flex;align-items:center;justify-content:space-between;' +
        'margin-top:.35rem;gap:.3rem;' +
      '}' +
      '.gs-card-players{' +
        'font-size:.62rem;color:#8b93a7;' +
        'display:inline-flex;align-items:center;gap:.2rem;' +
        'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;' +
      '}' +
      '.gs-card-players svg{width:.7rem;height:.7rem;flex:0 0 auto;}' +
      '.gs-card-play{' +
        'width:1.75rem;height:1.75rem;border-radius:50%;flex:0 0 auto;' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'display:flex;align-items:center;justify-content:center;color:#fff;' +
        'box-shadow:0 4px 12px rgba(124,92,255,.5);' +
      '}' +
      '.gs-card-play svg{width:.85rem;height:.85rem;margin-left:1px;}' +

      /* --- My Games card --- */
      '.gs-mygames{' +
        'display:flex;align-items:center;gap:.75rem;' +
        'padding:.9rem 1rem;border-radius:1.1rem;margin-bottom:.6rem;' +
        'background:linear-gradient(135deg,rgba(124,92,255,.22) 0%,rgba(58,160,255,.15) 100%);' +
        'border:1px solid rgba(124,92,255,.3);' +
        'cursor:pointer;transition:transform .15s ease;' +
        '-webkit-tap-highlight-color:transparent;user-select:none;' +
        'box-shadow:0 6px 20px rgba(30,20,80,.4);' +
      '}' +
      '.gs-mygames:active{transform:scale(.98);}' +
      '.gs-mygames-icon{' +
        'width:2.6rem;height:2.6rem;border-radius:.85rem;flex:0 0 auto;' +
        'background:linear-gradient(135deg,#7c5cff,#5b3df0);' +
        'display:flex;align-items:center;justify-content:center;color:#fff;' +
        'box-shadow:0 6px 16px rgba(124,92,255,.5);' +
      '}' +
      '.gs-mygames-icon svg{width:1.35rem;height:1.35rem;}' +
      '.gs-mygames-titles{flex:1;min-width:0;}' +
      '.gs-mygames-title{font-size:.95rem;font-weight:800;color:#fff;}' +
      '.gs-mygames-sub{font-size:.72rem;color:#a5b0c5;margin-top:.1rem;}' +
      '.gs-mygames-arrow{color:#7c5cff;flex:0 0 auto;}' +
      '.gs-mygames-arrow svg{width:1.1rem;height:1.1rem;}' +

      /* --- Empty --- */
      '.gs-empty{' +
        'display:flex;flex-direction:column;align-items:center;gap:.55rem;' +
        'padding:2.6rem 1rem;color:#8b93a7;text-align:center;' +
      '}' +
      '.gs-empty svg{width:2.6rem;height:2.6rem;opacity:.5;}' +

      /* --- Narrow screens --- */
      '@media (max-width:360px){' +
        '.gs-grid{grid-template-columns:repeat(auto-fill,minmax(8.5rem,1fr));gap:.5rem;}' +
        '.gs-card-name{font-size:.78rem;}' +
        '.gs-hero{padding:.9rem .85rem;min-height:10rem;}' +
        '.gs-hero-title{font-size:1.1rem;}' +
      '}';
    (document.head || document.documentElement).appendChild(s);
  })();

  /* ============================================================
   * 2. HELPERS
   * ============================================================ */
  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function fmtDate(ts) {
    try { return window.fmtDate(ts); } catch (e) {}
    return ts ? new Date(ts).toLocaleDateString() : '—';
  }
  function svgIcon(n, f) { try { return window.svgIcon(n, f) || ''; } catch (e) { return ''; } }
  function timeNow() { try { return window.now(); } catch (e) { return Date.now(); } }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function getDB() {
    try { if (window.db) return window.db; } catch (e) {}
    return null;
  }

  /* Inline SVG helpers for design (games-only) */
  function iconGamepad(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
      'stroke-linecap="round" stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<rect x="2" y="6" width="20" height="12" rx="4"/>' +
      '<path d="M6 12h4M8 10v4M16 11h.01M18 13h.01"/></svg>';
  }
  function iconSearch(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>';
  }
  function iconFilter(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<path d="M3 6h18M6 12h12M10 18h4"/></svg>';
  }
  function iconStar(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.6" ' +
      'stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
  }
  function iconArrowRight(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<path d="M5 12h14M12 5l7 7-7 7"/></svg>';
  }
  function iconPlay(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="currentColor" width="' + s + '" height="' + s + '">' +
      '<path d="M7 5v14l12-7z"/></svg>';
  }
  function iconCrown(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="currentColor" width="' + s + '" height="' + s + '">' +
      '<path d="M3 18h18l-1-9-5 4-3-6-3 6-5-4z"/></svg>';
  }
  function iconUsers(size) {
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
      'stroke-linecap="round" stroke-linejoin="round" width="' + s + '" height="' + s + '">' +
      '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 21a6.5 6.5 0 0 1 13 0"/>' +
      '<path d="M17 5.5a3.2 3.2 0 0 1 0 6.4M22 21a6.5 6.5 0 0 0-4-6"/></svg>';
  }
  function iconHeroArt() {
    return '<svg viewBox="0 0 240 180" xmlns="http://www.w3.org/2000/svg">' +
      '<defs>' +
      '<linearGradient id="gsBody" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="#3a3a52"/>' +
      '<stop offset="100%" stop-color="#15172a"/>' +
      '</linearGradient>' +
      '<linearGradient id="gsAccent" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0%" stop-color="#7c5cff"/>' +
      '<stop offset="100%" stop-color="#3aa0ff"/>' +
      '</linearGradient>' +
      '<radialGradient id="gsGlow" cx="50%" cy="50%" r="50%">' +
      '<stop offset="0%" stop-color="#7c5cff" stop-opacity=".7"/>' +
      '<stop offset="100%" stop-color="#7c5cff" stop-opacity="0"/>' +
      '</radialGradient>' +
      '</defs>' +
      '<ellipse cx="120" cy="130" rx="100" ry="34" fill="url(#gsGlow)"/>' +
      '<rect x="30" y="55" width="180" height="80" rx="42" fill="url(#gsBody)" ' +
      'stroke="#7c5cff" stroke-width="1.5" stroke-opacity=".55"/>' +
      '<circle cx="80" cy="80" r="14" fill="#1a1c2e" stroke="#7c5cff" stroke-width="1.4"/>' +
      '<circle cx="80" cy="80" r="6" fill="#0c0d17"/>' +
      '<rect x="52" y="72" width="6" height="14" rx="2" fill="#7c5cff"/>' +
      '<rect x="46" y="78" width="18" height="4" rx="2" fill="#7c5cff"/>' +
      '<circle cx="176" cy="70" r="6" fill="url(#gsAccent)"/>' +
      '<circle cx="160" cy="86" r="6" fill="#3aa0ff"/>' +
      '<circle cx="192" cy="86" r="6" fill="#7c5cff"/>' +
      '<circle cx="176" cy="102" r="6" fill="#ff5c6c"/>' +
      '<rect x="98" y="88" width="44" height="6" rx="3" fill="#0c0d17" opacity=".6"/>' +
      '<circle cx="120" cy="42" r="5" fill="#ffb020"/>' +
      '<circle cx="60" cy="40" r="3" fill="#3aa0ff" opacity=".8"/>' +
      '<circle cx="190" cy="45" r="4" fill="#7c5cff" opacity=".85"/>' +
      '<circle cx="150" cy="30" r="2.5" fill="#ff5c6c" opacity=".7"/>' +
      '</svg>';
  }

  /* ============================================================
   * 3. STATE (preserved)
   * ============================================================ */
  var gamesRef = null, gamesCb = null;
  window.gamesCache = Array.isArray(window.gamesCache) ? window.gamesCache : [];

  var gameFilter = { cat: 'all', q: '', tab: 'all' };
  window.gameFilter = gameFilter;

  window.recentPlayed = (function () {
    try { return JSON.parse(localStorage.getItem('saiko_recent_games') || '[]'); }
    catch (e) { return []; }
  })();

  /* ============================================================
   * 4. DETACH
   * ============================================================ */
  function detachGames() {
    if (gamesRef && gamesCb) {
      try { gamesRef.off('value', gamesCb); } catch (e) {}
    }
    gamesRef = null;
    gamesCb = null;
    window.gamesCache = [];
  }

  /* ============================================================
   * 5. START LISTENER
   * ============================================================ */
  function startGames() {
    if (gamesRef && gamesCb) return true;
    var fbDb = getDB();
    if (!fbDb) return false;

    gamesRef = fbDb.ref('games');
    gamesCb = gamesRef.on('value', function (snap) {
      var v = snap.val() || {};
      window.gamesCache = Object.keys(v)
        .map(function (k) { return Object.assign({ id: k }, v[k]); })
        .filter(function (g) {
          return g && g.published !== false && !g.deleted && g.status !== 'maintenance';
        })
        .sort(function (a, b) {
          return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0);
        });

      if (typeof window.currentNav === 'string' && window.currentNav === 'games') {
        renderGames();
      }

      safeCall('cacheOfflineGames');
    }, function (err) {
      var page = qs('#page-games');
      if (page) page.innerHTML = '<div class="banner">' + esc(err.message) + '</div>';
    });
    return true;
  }

  /* ============================================================
   * 6. CATEGORIES
   * ============================================================ */
  function gameCategories() {
    var set = {};
    window.gamesCache.forEach(function (g) { if (g.category) set[g.category] = true; });
    return Object.keys(set);
  }

  /* ============================================================
   * 7. HERO BANNER (static design element — no functionality removed)
   * ============================================================ */
  function buildHeroBanner() {
    return '<div class="gs-hero">' +
      '<div class="gs-hero-content">' +
        '<div class="gs-hero-chip">' + iconGamepad(14) + ' <span>Play Together</span></div>' +
        '<div class="gs-hero-title">Discover Amazing<br>Games</div>' +
        '<div class="gs-hero-sub">Explore, play and compete with friends. New games added regularly!</div>' +
        '<button class="gs-hero-btn" id="gsHeroExplore">Explore Now ' + iconArrowRight(14) + '</button>' +
      '</div>' +
      '<div class="gs-hero-art">' + iconHeroArt() + '</div>' +
    '</div>';
  }

  /* ============================================================
   * 8. GAME CARD — Premium design (uses NEW gs-* classes)
   *    Existing .game-card class is preserved for search results
   * ============================================================ */
  function gameCardHTML(g) {
    var hasImg = g.thumbnail && String(g.thumbnail).trim().length > 0;
    var imgHTML = hasImg
      ? '<img src="' + esc(g.thumbnail) + '" loading="lazy" alt="" ' +
        'onerror="this.parentNode.innerHTML=\'<div class=&quot;gs-fallback&quot;>' +
        iconGamepad(32).replace(/"/g, '&quot;') + '</div>\'">'
      : '<div class="gs-fallback">' + iconGamepad(32) + '</div>';

    /* Badges — only when data supports (never fake) */
    var badgesHTML = '';
    var badgeList = [];
    if (g.popular === true)  badgeList.push({ t: 'Popular',  c: 'gs-badge-popular'  });
    if (g.trending === true) badgeList.push({ t: 'Trending', c: 'gs-badge-trending' });
    if (g.hot === true)      badgeList.push({ t: 'Hot',      c: 'gs-badge-hot'      });
    if (badgeList.length) {
      var bd = badgeList[0];
      badgesHTML = '<span class="gs-card-badge ' + bd.c + '">' + esc(bd.t) + '</span>';
    }

    /* Players count — only if data present */
    var playersHTML = '';
    var players = Number(g.players);
    if (isFinite(players) && players > 0) {
      playersHTML = '<span class="gs-card-players">' +
        iconUsers(12) +
        ' <span>' + fmtPlayers(players) + ' playing</span>' +
      '</span>';
    }

    /* Category / description line */
    var catLine = g.category || g.description || '';
    if (catLine && catLine.length > 40) catLine = catLine.slice(0, 40) + '…';

    return '<div class="gs-card" data-game="' + esc(g.id) + '">' +
      '<div class="gs-card-img">' +
        badgesHTML +
        imgHTML +
      '</div>' +
      '<div class="gs-card-body">' +
        '<div class="gs-card-name">' + esc(g.title || 'Game') + '</div>' +
        (catLine ? '<div class="gs-card-cat">' + esc(catLine) + '</div>' : '') +
        '<div class="gs-card-foot">' +
          playersHTML +
          '<span class="gs-card-play">' + iconPlay(14) + '</span>' +
        '</div>' +
      '</div>' +
    '</div>';
  }

  function fmtPlayers(n) {
    n = Number(n) || 0;
    if (n < 1000) return String(n);
    if (n < 1000000) return (n / 1000).toFixed(n < 10000 ? 1 : 0).replace(/\.0$/, '') + 'K';
    return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  }

  /* ============================================================
   * 9. RENDER GAMES PAGE (Premium layout)
   * ============================================================ */
  function renderGames() {
    var page = qs('#page-games');
    if (!page) return;

    /* ---------- Header ---------- */
    var header =
      '<div class="gs-header">' +
        '<div class="gs-header-icon">' + iconGamepad(24) + '</div>' +
        '<div class="gs-header-titles">' +
          '<div class="gs-header-title">' + esc(T('games')) + '</div>' +
          '<div class="gs-header-sub">Play • Compete • Have Fun ✨</div>' +
        '</div>' +
        '<div class="gs-xp-badge">' + iconCrown(14) + ' <span>Play &amp; Earn XP</span></div>' +
      '</div>';

    /* ---------- Search ---------- */
    var searchBar =
      '<div class="gs-search">' +
        iconSearch(18) +
        '<input type="search" id="gameSearch" placeholder="' +
          esc(T('search_games') || 'Search games...') + '" value="' + esc(gameFilter.q) + '">' +
        '<span class="gs-filter-icon">' + iconFilter(18) + '</span>' +
      '</div>';

    /* ---------- Categories (All + Featured + dynamic cats) ---------- */
    var cats = gameCategories();
    var catsHTML = '<div class="gs-cats" id="gsCats">';

    /* All */
    catsHTML += '<div class="gs-cat ' + (gameFilter.cat === 'all' && gameFilter.tab === 'all' ? 'sel' : '') +
      '" data-gcat="all" data-gtab="all">' + iconGamepad(14) + ' <span>' + esc(T('all')) + '</span></div>';

    /* Featured */
    catsHTML += '<div class="gs-cat ' + (gameFilter.tab === 'featured' ? 'sel' : '') +
      '" data-gtab="featured">' + iconStar(14) + ' <span>Featured</span></div>';

    /* Dynamic categories */
    cats.forEach(function (c) {
      var isSel = (gameFilter.cat === c) ? ' sel' : '';
      catsHTML += '<div class="gs-cat' + isSel + '" data-gcat="' + esc(c) + '">' +
        '<span>' + esc(c) + '</span></div>';
    });

    catsHTML += '</div>';

    /* ---------- Build list ---------- */
    var list = window.gamesCache.slice();

    if (gameFilter.cat !== 'all') {
      list = list.filter(function (g) { return g.category === gameFilter.cat; });
    }
    if (gameFilter.tab === 'featured') {
      list = list.filter(function (g) { return g.featured; });
    } else if (gameFilter.tab === 'played') {
      list = window.recentPlayed.map(function (id) {
        return window.gamesCache.find(function (g) { return g.id === id; });
      }).filter(Boolean);
    }

    var q = (gameFilter.q || '').toLowerCase().trim();
    if (q) {
      list = list.filter(function (g) {
        return ((g.title || '') + ' ' + (g.description || '')).toLowerCase().indexOf(q) !== -1;
      });
    }

    /* ---------- Empty state ---------- */
    if (!window.gamesCache.length) {
      page.innerHTML = header +
        '<div class="gs-empty">' + iconGamepad(40) + '<p>' + esc(T('no_games')) + '</p></div>';
      return;
    }

    /* ---------- Compose page ---------- */
    var gridHTML;
    if (!list.length) {
      gridHTML = '<div class="gs-empty">' + iconGamepad(40) +
        '<p>' + esc(T('no_games')) + '</p></div>';
    } else {
      gridHTML = '<div class="gs-grid">' +
        list.map(gameCardHTML).join('') +
      '</div>';
    }

    page.innerHTML =
      header +
      searchBar +
      catsHTML +
      buildHeroBanner() +
      '<div class="gs-section">' +
        '<div class="gs-section-title">' + iconStar(17) + ' <span>Featured Games</span></div>' +
        '<button class="gs-section-action" id="gsViewAll">' +
          'View All ' + iconArrowRight(14) +
        '</button>' +
      '</div>' +
      gridHTML +
      '<div class="gs-mygames" id="gsMyGames">' +
        '<div class="gs-mygames-icon">' + iconGamepad(24) + '</div>' +
        '<div class="gs-mygames-titles">' +
          '<div class="gs-mygames-title">My Games</div>' +
          '<div class="gs-mygames-sub">View your played games, progress and stats</div>' +
        '</div>' +
        '<div class="gs-mygames-arrow">' + iconArrowRight(18) + '</div>' +
      '</div>';

    /* ---------- Wire search (preserved) ---------- */
    var s = qs('#gameSearch');
    if (s) {
      var debounceFn = window.debounce || function (fn, ms) {
        var tm;
        return function () {
          var a = arguments, c = this;
          clearTimeout(tm);
          tm = setTimeout(function () { fn.apply(c, a); }, ms);
        };
      };
      s.addEventListener('input', debounceFn(function (e) {
        gameFilter.q = e.target.value;
        renderGames();
        /* Restore focus + caret after re-render */
        setTimeout(function () {
          var inp = qs('#gameSearch');
          if (inp) {
            inp.focus();
            try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (err) {}
          }
        }, 0);
      }, 200));
    }

    /* ---------- Wire category & tab clicks ---------- */
    qsa('[data-gcat]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        var cat = n.getAttribute('data-gcat');
        var tab = n.getAttribute('data-gtab');
        if (tab !== null && tab !== undefined) {
          gameFilter.tab = tab;
          gameFilter.cat = 'all';
        } else {
          gameFilter.cat = cat;
          gameFilter.tab = 'all';
        }
        renderGames();
      });
    });

    qsa('[data-gtab]', page).forEach(function (n) {
      if (n.hasAttribute('data-gcat')) return; /* already wired above */
      n.addEventListener('click', function () {
        gameFilter.tab = n.getAttribute('data-gtab');
        gameFilter.cat = 'all';
        renderGames();
      });
    });

    /* ---------- Wire "View All" (→ Featured tab) ---------- */
    var va = qs('#gsViewAll');
    if (va) {
      va.addEventListener('click', function () {
        gameFilter.tab = 'featured';
        gameFilter.cat = 'all';
        renderGames();
        setTimeout(function () {
          try { window.scrollTo({ top: 220, behavior: 'smooth' }); } catch (e) {}
        }, 60);
      });
    }

    /* ---------- Wire "Explore Now" (→ Featured tab) ---------- */
    var hx = qs('#gsHeroExplore');
    if (hx) {
      hx.addEventListener('click', function () {
        gameFilter.tab = 'featured';
        gameFilter.cat = 'all';
        renderGames();
        setTimeout(function () {
          try { window.scrollTo({ top: 260, behavior: 'smooth' }); } catch (e) {}
        }, 60);
      });
    }

    /* ---------- Wire "My Games" (→ recently played) ---------- */
    var mg = qs('#gsMyGames');
    if (mg) {
      mg.addEventListener('click', function () {
        gameFilter.tab = 'played';
        gameFilter.cat = 'all';
        renderGames();
        setTimeout(function () {
          try { window.scrollTo({ top: 260, behavior: 'smooth' }); } catch (e) {}
        }, 60);
      });
    }

    /* ---------- Wire game cards (preserved) ---------- */
    qsa('[data-game]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        openGame(n.getAttribute('data-game'));
      });
    });
  }

  /* ============================================================
   * 10. OPEN GAME (preserved 1:1)
   * ============================================================ */
  function openGame(id) {
    var g = window.gamesCache.find(function (x) { return x.id === id; });
    if (!g) return;

    var titleEl = qs('#gameTitle');
    if (titleEl) titleEl.textContent = g.title || 'Game';

    var wrap = qs('#gameFrameWrap');
    if (!wrap) return;
    wrap.innerHTML = '';

    var frame = document.createElement('iframe');
    frame.setAttribute('allow', 'fullscreen; autoplay; gamepad; microphone; camera; clipboard-write');
    frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-pointer-lock allow-orientation-lock');

    if (g.url) {
      frame.src = g.url;
    } else if (g.code) {
      frame.srcdoc = g.code;
    } else {
      frame.srcdoc = '<body style="font-family:sans-serif;color:#fff;background:#111;display:flex;align-items:center;justify-content:center;height:100vh">No game content</body>';
    }

    wrap.appendChild(frame);
    safeCall('openOverlay', ['ovGame']);

    /* Recent played */
    window.recentPlayed = [id].concat(window.recentPlayed.filter(function (x) { return x !== id; })).slice(0, 20);
    try { localStorage.setItem('saiko_recent_games', JSON.stringify(window.recentPlayed)); } catch (e) {}

    /* Counter */
    var fbDb = getDB();
    if (fbDb) {
      fbDb.ref('gamePlays/' + id).transaction(function (v) { return (Number(v) || 0) + 1; }).catch(function () {});
    }

    /* XP + daily */
    safeCall('awardXp', ['game_played', 3]);
    safeCall('bumpDaily', ['game', 1]);
  }

  /* ============================================================
   * 11. BIND FULLSCREEN BUTTON (preserved)
   * ============================================================ */
  var _fullBound = false;
  function bindFullscreen() {
    if (_fullBound) return;
    _fullBound = true;

    var btn = qs('#btnGameFull');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var w = qs('#gameFrameWrap');
      if (!w) return;
      try {
        if (!document.fullscreenElement) {
          if (w.requestFullscreen) {
            var p = w.requestFullscreen();
            if (p && p.catch) p.catch(function () {
              safeCall('toast', [T('not_supported'), 'err']);
            });
          } else {
            safeCall('toast', [T('not_supported'), 'err']);
          }
        } else {
          document.exitFullscreen();
        }
      } catch (e) {
        safeCall('toast', [T('not_supported'), 'err']);
      }
    });
  }

  /* ============================================================
   * 12. EXPORTS (preserved + extended)
   * ============================================================ */
  window.startGames       = startGames;
  window.detachGames      = detachGames;
  window.gameCategories   = gameCategories;
  window.renderGames      = renderGames;
  window.gameCardHTML     = gameCardHTML;
  window.openGame         = openGame;

  window.SaikoGames = {
    start: startGames,
    detach: detachGames,
    render: renderGames,
    categories: gameCategories,
    open: openGame,
    getCache: function () { return window.gamesCache; }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindFullscreen, { once: true });
  } else {
    bindFullscreen();
  }

  try { console.debug('[boot] games-core ready (v2 — premium neon UI)'); } catch (e) {}
})();