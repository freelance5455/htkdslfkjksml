/* ============================================================
 * FEATURE:        Offline Games (IndexedDB) — v4
 * FILE:           js/games/025-offline-games.js
 * ACTION:         REPLACE (v4 — thumbnail blob cache + skip logging)
 * ============================================================ */

(function () {
  'use strict';

  var DB_NAME    = 'innocentsaiko_offline';
  var DB_VERSION = 1;
  var STORE      = 'games';
  var CACHE_FLAG = 'saiko_offline_cache_v1';
  var CACHE_THROTTLE_MS = 60 * 1000;
  var THUMB_MAX_BYTES   = 500 * 1024;   // skip blobs > 500 KB
  var THUMB_FETCH_TIMEOUT_MS = 10000;

  /* ============ HELPERS ============ */
  function qs(sel) { return document.querySelector(sel); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function svgIcon(n, f) { try { return window.svgIcon(n, f) || ''; } catch (e) { return ''; } }
  function timeAgo(ts) { try { return window.timeAgo(ts); } catch (e) { return ''; } }
  function timeNow() { try { return window.now(); } catch (e) { return Date.now(); } }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
  }
  function getDB() {
    try { if (window.db) return window.db; } catch (e) {}
    return null;
  }
  function isOnline() {
    try { return !!navigator.onLine; } catch (e) { return true; }
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }

  /* ============ STATE ============ */
  var _caching = false;
  var _lastCacheAt = 0;
  var _thumbUrlCache = {};   /* gameId -> objectURL (in-memory only) */

  /* ============ OPEN DB ============ */
  function openOfflineDB() {
    return new Promise(function (resolve, reject) {
      try {
        var req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = function () {
          var db = req.result;
          if (!db.objectStoreNames.contains(STORE)) {
            db.createObjectStore(STORE, { keyPath: 'id' });
          }
        };
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
      } catch (e) {
        reject(e);
      }
    });
  }

  /* ============================================================
   * THUMBNAIL BLOB HELPERS
   * ============================================================ */
  function withTimeout(promise, ms) {
    return Promise.race([
      promise,
      new Promise(function (_, reject) {
        setTimeout(function () { reject(new Error('timeout')); }, ms);
      })
    ]);
  }

  async function fetchThumbnailBlob(url) {
    if (!url || typeof url !== 'string') return null;
    if (!/^https?:\/\//i.test(url)) return null;

    try {
      var res = await withTimeout(fetch(url, { mode: 'cors' }), THUMB_FETCH_TIMEOUT_MS);
      if (!res || !res.ok) return null;

      var blob = await res.blob();
      if (!blob) return null;
      if (!blob.type || blob.type.indexOf('image/') !== 0) return null;
      if (blob.size > THUMB_MAX_BYTES) {
        try { console.debug('[offline-games] thumbnail too large, skipped:', url, blob.size); } catch (e) {}
        return null;
      }
      return blob;
    } catch (e) {
      return null;
    }
  }

  /* Return a displayable URL for a game's thumbnail.
   * Uses blob object URL when available (works offline),
   * falls back to the original URL (works online only). */
  function getThumbUrl(game) {
    if (!game) return '';
    if (game.thumbnailBlob) {
      if (_thumbUrlCache[game.id]) return _thumbUrlCache[game.id];
      try {
        var url = URL.createObjectURL(game.thumbnailBlob);
        _thumbUrlCache[game.id] = url;
        return url;
      } catch (e) {
        /* fall through */
      }
    }
    return game.thumbnail || '';
  }

  function revokeThumbUrls() {
    Object.keys(_thumbUrlCache).forEach(function (id) {
      try { URL.revokeObjectURL(_thumbUrlCache[id]); } catch (e) {}
    });
    _thumbUrlCache = {};
  }

  /* ============================================================
   * CACHE GAMES
   * ============================================================ */
  async function cacheOfflineGames() {
    if (_caching) return false;

    var fbDb = getDB();
    if (!fbDb) return false;
    if (!isOnline()) return false;

    var nowTs = Date.now();
    var flagSet = false;
    try { flagSet = localStorage.getItem(CACHE_FLAG) === '1'; } catch (e) {}
    if (flagSet && (nowTs - _lastCacheAt) < CACHE_THROTTLE_MS) {
      return false;
    }

    _caching = true;
    _lastCacheAt = nowTs;

    try {
      /* ---- 1. Fetch all games from Firebase ---- */
      var snap = await fbDb.ref('games').get();
      var v = snap.val() || {};

      var allGames = Object.keys(v).map(function (k) {
        return Object.assign({ id: k }, v[k]);
      });

      /* ---- 2. Filter cacheable ones + log reasons ---- */
      var skipped = [];
      var games = allGames.filter(function (g) {
        if (!g) { skipped.push({ id: '?', reason: 'null entry' }); return false; }
        if (g.published === false) { skipped.push({ id: g.id, title: g.title, reason: 'published === false (draft)' }); return false; }
        if (g.deleted) { skipped.push({ id: g.id, title: g.title, reason: 'deleted === true' }); return false; }
        if (g.status === 'maintenance') { skipped.push({ id: g.id, title: g.title, reason: 'status === "maintenance"' }); return false; }
        if (g.code && String(g.code).trim().length > 0) return true;
        if (g.url && !/^https?:\/\//i.test(g.url)) return true;
        skipped.push({
          id: g.id,
          title: g.title,
          reason: 'no inline code + external/empty url = ' + (g.url || '(empty)')
        });
        return false;
      });

      /* ---- 3. Debug log — visible in console ---- */
      try {
        console.debug('[offline-games] Fetched ' + allGames.length +
                      ' games → ' + games.length + ' cacheable, ' +
                      skipped.length + ' skipped');
        skipped.forEach(function (s) {
          console.debug('[offline-games] SKIP: "' + (s.title || s.id) +
                        '" — reason: ' + s.reason);
        });
      } catch (e) {}

      /* ---- 4. Read existing records so we can reuse thumbnails ---- */
      var existingMap = {};
      try {
        var existingList = await listOfflineGames();
        (existingList || []).forEach(function (r) {
          if (r && r.id) existingMap[r.id] = r;
        });
      } catch (e) {}

      /* ---- 5. Fetch thumbnails in parallel ---- */
      var thumbBlobs = {};   /* gameId -> Blob */
      try {
        var thumbPromises = games.map(function (g) {
          if (!g.thumbnail) return Promise.resolve();

          var old = existingMap[g.id];
          /* Reuse old blob if URL hasn't changed */
          if (old && old.thumbnail === g.thumbnail && old.thumbnailBlob) {
            thumbBlobs[g.id] = old.thumbnailBlob;
            return Promise.resolve();
          }

          return fetchThumbnailBlob(g.thumbnail).then(function (blob) {
            if (blob) thumbBlobs[g.id] = blob;
          }).catch(function () {});
        });
        await Promise.all(thumbPromises);
      } catch (e) {}

      /* ---- 6. Write to IndexedDB ---- */
      await new Promise(function (resolve, reject) {
        openOfflineDB().then(function (db) {
          var tx = db.transaction(STORE, 'readwrite');
          var store = tx.objectStore(STORE);

          games.forEach(function (g) {
            var data = {
              id: g.id,
              title: g.title || 'Game',
              thumbnail: g.thumbnail || '',
              description: g.description || '',
              category: g.category || '',
              updatedAt: g.updatedAt || g.createdAt || nowTs,
              cached: nowTs
            };
            if (g.code && String(g.code).trim().length > 0) {
              data.code = g.code;
            } else if (g.url && !/^https?:\/\//i.test(g.url)) {
              data.code = g.url;
            }
            if (thumbBlobs[g.id]) {
              data.thumbnailBlob = thumbBlobs[g.id];
            }
            try { store.put(data); } catch (e) {}
          });

          tx.oncomplete = function () { resolve(true); };
          tx.onerror = function () { reject(tx.error || new Error('tx error')); };
          tx.onabort = function () { reject(new Error('tx aborted')); };
        }).catch(function (err) { reject(err); });
      });

      try { localStorage.setItem(CACHE_FLAG, '1'); } catch (e) {}
      try {
        console.debug('[offline-games] cached', games.length, 'games (' +
                      Object.keys(thumbBlobs).length + ' thumbnails stored)');
      } catch (e) {}

      try {
        window.dispatchEvent(new CustomEvent('saiko:offline-games-cached', {
          detail: { count: games.length }
        }));
      } catch (e) {}

      return games.length;
    } catch (e) {
      try { console.warn('[offline-games] cache failed:', e); } catch (e2) {}
      return false;
    } finally {
      _caching = false;
    }
  }

  /* ============================================================
   * ENSURE
   * ============================================================ */
  async function ensureGamesCached() {
    var existing = [];
    try { existing = await listOfflineGames(); } catch (e) {}
    if (existing && existing.length > 0) return existing;

    if (!isOnline()) return [];

    _lastCacheAt = 0;
    try { await cacheOfflineGames(); } catch (e) {}

    try { return await listOfflineGames(); } catch (e) { return []; }
  }

  /* ============ LIST ============ */
  async function listOfflineGames() {
    try {
      var db = await openOfflineDB();
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var store = tx.objectStore(STORE);
        var req = store.getAll();
        req.onsuccess = function () { resolve(req.result || []); };
        req.onerror = function () { reject(req.error); };
      });
    } catch (e) {
      return [];
    }
  }

  /* ============ WAIT FOR CACHE IDLE ============ */
  function waitForCacheIdle(timeoutMs) {
    return new Promise(function (resolve) {
      var start = Date.now();
      function check() {
        if (!_caching) return resolve(true);
        if (Date.now() - start > (timeoutMs || 20000)) return resolve(false);
        setTimeout(check, 200);
      }
      check();
    });
  }

  /* ============ GET ONE ============ */
  async function getOfflineGame(id) {
    try {
      var db = await openOfflineDB();
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var store = tx.objectStore(STORE);
        var req = store.get(id);
        req.onsuccess = function () { resolve(req.result || null); };
        req.onerror = function () { reject(req.error); };
      });
    } catch (e) {
      return null;
    }
  }

  /* ============================================================
   * RENDER — thumbnail with blob fallback
   * ============================================================ */
  function renderThumb(g) {
    var src = getThumbUrl(g);

    if (!src) {
      return svgIcon('game');
    }

    /* Image on top of a placeholder — if image fails, placeholder stays visible */
    return (
      '<span style="position:absolute;inset:0;display:flex;align-items:center;' +
      'justify-content:center;color:var(--muted);">' + svgIcon('game') + '</span>' +
      '<img src="' + esc(src) + '" alt="" loading="lazy" ' +
        'style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;" ' +
        'onerror="this.style.display=\'none\';">'
    );
  }

  /* ============================================================
   * OPEN OFFLINE GAMES MODAL
   * ============================================================ */
  async function openOfflineGames() {
    safeCall('openOverlay', ['ovOfflineGames']);

    var list = qs('#offlineGamesList');
    if (!list) return;

    /* If cache is running, wait for it */
    if (_caching) {
      list.innerHTML =
        '<div class="loading-row">' +
          '<span class="spinner"></span>' +
          'Downloading games...' +
        '</div>';
      await waitForCacheIdle(20000);
    }

    var games = await listOfflineGames();

    /* If empty and online, force-fetch */
    if ((!games || !games.length) && isOnline()) {
      list.innerHTML =
        '<div class="loading-row">' +
          '<span class="spinner"></span>' +
          'Fetching games...' +
        '</div>';

      try {
        _lastCacheAt = 0;
        await cacheOfflineGames();
      } catch (e) {}

      games = await listOfflineGames();
    }

    if (!games || !games.length) {
      list.innerHTML =
        '<div class="empty">' +
          '<span class="ic">' + svgIcon('game') + '</span>' +
          '<p>No offline games available.</p>' +
          '<p class="mini" style="margin-top:.4rem;opacity:.75">' +
            'Admin must publish at least one HTML game. Connect once to download.' +
          '</p>' +
        '</div>';
      return;
    }

    /* Fresh set of blob URLs */
    revokeThumbUrls();

    list.innerHTML = games.map(function (g) {
      return '<div class="offline-game-card" data-ogame="' + esc(g.id) + '">' +
        '<div class="thumb" style="position:relative;">' + renderThumb(g) + '</div>' +
        '<div class="grow">' +
          '<div class="name" style="font-weight:700">' + esc(g.title) + '</div>' +
          '<div class="mini ellipsis">' + esc(g.description || '') + '</div>' +
          '<div class="mini" style="margin-top:.2rem">✓ Cached ' + esc(timeAgo(g.cached)) + '</div>' +
        '</div>' +
        '<span class="chip">▶ ' + esc(T('play')) + '</span>' +
      '</div>';
    }).join('');

    var cards = list.querySelectorAll('[data-ogame]');
    for (var i = 0; i < cards.length; i++) {
      (function (card) {
        card.addEventListener('click', function () {
          playOfflineGame(card.getAttribute('data-ogame'));
        });
      })(cards[i]);
    }
  }

  /* ============ PLAY OFFLINE GAME ============ */
  async function playOfflineGame(id) {
    var g = await getOfflineGame(id);
    if (!g) {
      safeToast(T('error'), 'err');
      return;
    }

    var titleEl = qs('#gameTitle');
    if (titleEl) titleEl.textContent = g.title || 'Game';

    var wrap = qs('#gameFrameWrap');
    if (!wrap) return;
    wrap.innerHTML = '';

    var frame = document.createElement('iframe');
    frame.setAttribute('allow', 'fullscreen; autoplay; gamepad');
    frame.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-forms allow-popups allow-pointer-lock allow-orientation-lock');
    frame.srcdoc = g.code || '<body style="color:#fff;background:#111;display:flex;align-items:center;justify-content:center;height:100vh">No content</body>';

    wrap.appendChild(frame);

    safeCall('closeOverlay', ['ovOfflineGames']);
    safeCall('openOverlay', ['ovGame']);

    window.recentPlayed = [id].concat((window.recentPlayed || []).filter(function (x) { return x !== id; })).slice(0, 20);
    try { localStorage.setItem('saiko_recent_games', JSON.stringify(window.recentPlayed)); } catch (e) {}
  }

  /* ============================================================
   * AUTH-SCREEN BUTTON
   * ============================================================ */
  var _authBtnBound = false;
  function bindAuthButton() {
    if (_authBtnBound) return;
    var btn = qs('#offlineGameBtn');
    if (!btn) return;
    _authBtnBound = true;

    btn.addEventListener('click', async function () {
      var orig = btn.innerHTML;
      try {
        btn.disabled = true;
        btn.innerHTML = '<span>' + esc(T('loading')) + '…</span>';
      } catch (e) {}

      try { await ensureGamesCached(); } catch (e) {}

      try {
        btn.disabled = false;
        btn.innerHTML = orig;
      } catch (e) {}

      openOfflineGames();
    });
  }

  /* ============================================================
   * AUTO-CACHE
   * ============================================================ */
  function tryAutoCache(reason) {
    if (!isOnline()) return;
    setTimeout(function () {
      cacheOfflineGames().catch(function () {});
    }, reason === 'login' ? 800 : 2200);
  }

  /* ============ EXPORTS ============ */
  window.openOfflineDB      = openOfflineDB;
  window.cacheOfflineGames  = cacheOfflineGames;
  window.ensureGamesCached  = ensureGamesCached;
  window.listOfflineGames   = listOfflineGames;
  window.getOfflineGame     = getOfflineGame;
  window.openOfflineGames   = openOfflineGames;
  window.playOfflineGame    = playOfflineGame;

  window.SaikoOfflineGames = {
    openDB: openOfflineDB,
    cache: cacheOfflineGames,
    ensureGamesCached: ensureGamesCached,
    list: listOfflineGames,
    get: getOfflineGame,
    open: openOfflineGames,
    play: playOfflineGame,
    isCaching: function () { return _caching; }
  };

  /* ============ AUTO BIND ============ */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bindAuthButton, { once: true });
  } else {
    bindAuthButton();
  }

  try {
    window.addEventListener('saiko:login', function () { tryAutoCache('login'); });
  } catch (e) {}

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      tryAutoCache('boot');
    }, { once: true });
  } else {
    tryAutoCache('boot');
  }

  /* ============================================================
   * AUTO-REFRESH OVERLAY
   * ============================================================ */
  try {
    window.addEventListener('saiko:offline-games-cached', function () {
      var ov = document.getElementById('ovOfflineGames');
      if (ov && ov.classList.contains('open')) {
        openOfflineGames();
      }
    });
  } catch (e) {}

  /* Free blob URLs when page unloads */
  try {
    window.addEventListener('pagehide', revokeThumbUrls);
  } catch (e) {}

  /* ============ BOOT LOG ============ */
  try { console.debug('[boot] offline-games ready (v4 — thumbnail blob cache + skip logging)'); } catch (e) {}
})();