/* ============================================================
 * FEATURE:        Overlay Open/Close/History System
 * FEATURE NUMBER: 038
 * FILE:           js/nav/038-overlay-system.js
 * ACTION:         REPLACE (z-index auto-boost added)
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function safeCall(fnName, args) {
    try {
      var fn = window[fnName];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {
      console.warn('[overlays] safeCall failed for', fnName, e);
    }
    return undefined;
  }

  function safeReplaceRoot() {
    try { history.replaceState({ view: 'root' }, ''); } catch (e) {}
  }

  function safePushState(state) {
    try { history.pushState(state || { view: 'overlay' }, ''); } catch (e) {}
  }

  /* ============================================================
   * getMaxOpenZIndex — find the highest z-index among every
   * currently-open overlay OR full-screen view. Used by open()
   * to place a new overlay above everything already on screen.
   * ============================================================ */
  function getMaxOpenZIndex() {
    var max = 0;
    qsa('.overlay.open').forEach(function (el) {
      var z = parseInt(window.getComputedStyle(el).zIndex, 10);
      if (!isNaN(z) && z > max) max = z;
    });
    var specialIds = ['ovSplitComments', 'ovReelSplit', 'ovStoryViewer', 'ovReels', 'settingsSidebar'];
    for (var i = 0; i < specialIds.length; i++) {
      var el2 = document.getElementById(specialIds[i]);
      if (el2 && el2.classList.contains('open')) {
        var z2 = parseInt(window.getComputedStyle(el2).zIndex, 10);
        if (!isNaN(z2) && z2 > max) max = z2;
      }
    }
    return max;
  }

  /* ============================================================
   * OPEN
   * ============================================================ */
  function open(id) {
    var o = document.getElementById(id);
    if (!o) return false;
    var maxZ = getMaxOpenZIndex();
    if (maxZ > 0) o.style.zIndex = String(maxZ + 5);
    o.classList.add('open');
    if (!o.dataset.historyPushed) {
      o.dataset.historyPushed = '1';
      pushState();
    }
    return true;
  }

  /* ============================================================
   * CLOSE
   * ============================================================ */
  function close(id) {
    var o = document.getElementById(id);
    if (!o) return false;
    o.classList.remove('open');
    o.style.zIndex = '';
    delete o.dataset.historyPushed;
    return true;
  }

  /* ============================================================
   * CLOSE ALL
   * ============================================================ */
  function closeAll() {
    qsa('.overlay').forEach(function (o) {
      o.classList.remove('open');
      o.style.zIndex = '';
      try { delete o.dataset.historyPushed; } catch (e) {}
    });

    var side = document.getElementById('settingsSidebar');
    if (side) side.classList.remove('open');

    var mask = document.getElementById('sidebarMask');
    if (mask) mask.classList.remove('open');

    var sv = document.getElementById('ovStoryViewer');
    if (sv) sv.classList.remove('open');

    var rl = document.getElementById('ovReels');
    if (rl) rl.classList.remove('open');

    var rs = document.getElementById('ovReelSplit');
    if (rs) rs.classList.remove('open');

    var ps = document.getElementById('ovSplitComments');
    if (ps) ps.classList.remove('open');

    var svs = document.getElementById('storyViewersSheet');
    if (svs) svs.classList.remove('open');
  }

  /* ============================================================
   * PUSH STATE
   * ============================================================ */
  function pushState() {
    safePushState({ view: 'overlay' });
  }

  /* ============================================================
   * INTROSPECTION
   * ============================================================ */
  function isOpen(id) {
    var o = document.getElementById(id);
    return !!(o && o.classList.contains('open'));
  }

  function anyOpen() {
    return qsa('.overlay.open').length > 0;
  }

  function getTopMost() {
    var open = qsa('.overlay.open');
    if (!open.length) return null;
    var top = open[0];
    var topZ = -1;
    open.forEach(function (o) {
      var z = parseInt(window.getComputedStyle(o).zIndex, 10);
      var zz = isNaN(z) ? 55 : z;
      if (zz >= topZ) {
        topZ = zz;
        top = o;
      }
    });
    return top;
  }

  /* ============================================================
   * DATA-CLOSE DELEGATION
   * ============================================================ */
  function onDocumentClick(e) {
    var c = e.target && e.target.closest ? e.target.closest('[data-close]') : null;
    if (c) {
      var id = c.getAttribute('data-close');
      if (id === 'ovChat')          safeCall('detachChat');
      if (id === 'ovComments')      safeCall('detachCommentsListener');
      if (id === 'ovSplitComments') safeCall('closePostSplit');
      if (id === 'ovReelSplit')     safeCall('closeReelSplit');
      close(id);
      return;
    }

    if (e.target && e.target.id === 'ovReactions') {
      close('ovReactions');
      return;
    }
    if (e.target && e.target.id === 'ovMsgMenu') {
      close('ovMsgMenu');
      return;
    }
  }

  /* ============================================================
   * POPSTATE
   * ============================================================ */
  function onPopState() {
    var sv = qs('#ovStoryViewer');
    var rl = qs('#ovReels');
    var rs = qs('#ovReelSplit');
    var ps = qs('#ovSplitComments');

    var svOpen = !!(sv && sv.classList.contains('open'));
    var rlOpen = !!(rl && rl.classList.contains('open'));
    var rsOpen = !!(rs && rs.classList.contains('open'));
    var psOpen = !!(ps && ps.classList.contains('open'));
    var opens  = qsa('.overlay.open');

    if (psOpen) {
      safeCall('closePostSplit');
      safePushState({ view: 'root' });
      return;
    }
    if (rsOpen) {
      safeCall('closeReelSplit');
      safePushState({ view: 'root' });
      return;
    }
    if (svOpen) {
      safeCall('closeStoryViewer');
      safePushState({ view: 'root' });
      return;
    }
    if (rlOpen) {
      safeCall('closeReels');
      safePushState({ view: 'root' });
      return;
    }
    if (opens.length) {
      var top = getTopMost();
      if (top) {
        var id = top.id;
        if (id === 'ovChat')     safeCall('detachChat');
        if (id === 'ovComments') safeCall('detachCommentsListener');
        close(id);
      }
      safePushState({ view: 'root' });
      return;
    }

    var side = qs('#settingsSidebar');
    if (side && side.classList.contains('open')) {
      side.classList.remove('open');
      var mask = qs('#sidebarMask');
      if (mask) mask.classList.remove('open');
      safePushState({ view: 'root' });
      return;
    }
  }

  /* ============================================================
   * BIND / UNBIND
   * ============================================================ */
  var _bound = false;
  var _popstateWired = false;

  function bind(root) {
    var scope = root || document;
    if (!_bound) {
      scope.addEventListener('click', onDocumentClick);
      _bound = true;
    }
    if (!_popstateWired) {
      window.addEventListener('popstate', onPopState);
      _popstateWired = true;
    }
    safeReplaceRoot();
    return true;
  }

  function unbind(root) {
    var scope = root || document;
    if (_bound) {
      scope.removeEventListener('click', onDocumentClick);
      _bound = false;
    }
    if (_popstateWired) {
      window.removeEventListener('popstate', onPopState);
      _popstateWired = false;
    }
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openOverlay      = open;
  window.closeOverlay     = close;
  window.closeAllOverlays = closeAll;
  window.pushOverlayState = pushState;

  window.SaikoOverlays = {
    open: open,
    close: close,
    closeAll: closeAll,
    pushState: pushState,
    isOpen: isOpen,
    anyOpen: anyOpen,
    getTopMost: getTopMost,
    getMaxOpenZIndex: getMaxOpenZIndex,
    bind: bind,
    unbind: unbind
  };

  /* ============================================================
   * AUTO-BIND
   * ============================================================ */
  bind();

  try {
    console.debug('[boot] feature 038 — overlay-system ready (z-index auto-boost)');
  } catch (e) {}

})();