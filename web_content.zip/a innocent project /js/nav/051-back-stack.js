/* ============================================================
 * FEATURE:        Back Stack (Overlay Stack + Pause/Resume)
 * FEATURE NUMBER: 051
 * FILE:           js/nav/051-back-stack.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   - Let overlays stack (don't close underlying overlay)
 *   - Pause background videos when a new overlay opens on top
 *   - Resume when top overlay closes
 *   - One back press = close ONE topmost overlay
 * ============================================================ */

(function () {
  'use strict';

  var SCAN_MS = 250;

  /* Overlays that need special handling */
  var OVERLAY_IDS = [
    'ovReels', 'ovStoryViewer', 'ovReelSplit', 'ovSplitComments',
    'ovChat', 'ovProfile', 'ovVisitors', 'ovVisitorDetail',
    'ovCollection', 'ovUserList', 'ovSearch', 'ovComments',
    'ovCallHistory', 'ovSaved', 'ovHashtag', 'ovTrending',
    'ovLeaderboard', 'ovMissions', 'ovPinBoard', 'ovRestricted',
    'ovSettings', 'ovReport', 'ovViewer', 'ovGroup', 'ovPicker',
    'ovComposer', 'ovGame', 'ovOfflineGames', 'ovNewReel',
    'ovReelUpload', 'ovNewChat', 'ovNewGroup', 'ovGroupInfo',
    'ovChatInfo', 'ovMsgMenu', 'ovReactions', 'ovConfirm',
    'ovCall', 'ovStoryCreate', 'ovRestrictionRequest'
  ];

  /* Which overlays need their video paused when covered? */
  var PAUSE_HOOKS = {
    'ovReels': function () {
      try {
        var v = window.reelsActiveVideo;
        if (v && !v.paused) {
          try { v.pause(); } catch (e) {}
          window.__reelsBackgroundPaused = true;
        }
      } catch (e) {}
    },
    'ovStoryViewer': function () {
      try {
        var stage = document.getElementById('storyStage');
        if (!stage) return;
        var v = stage.querySelector('video');
        if (v && !v.paused) {
          try { v.pause(); } catch (e) {}
          window.__storyBackgroundPaused = true;
        }
      } catch (e) {}
    },
    'ovReelSplit': function () {
      try {
        var v = document.getElementById('rsVideo');
        if (v && !v.paused) {
          try { v.pause(); } catch (e) {}
          window.__reelSplitBackgroundPaused = true;
        }
      } catch (e) {}
    }
  };

  var RESUME_HOOKS = {
    'ovReels': function () {
      if (!window.__reelsBackgroundPaused) return;
      window.__reelsBackgroundPaused = false;
      if (window.__userPausedReels) return;
      try {
        var v = window.reelsActiveVideo;
        if (v && v.paused && v.isConnected) {
          try {
            var p = v.play();
            if (p && p.catch) p.catch(function () {});
          } catch (e) {}
        }
      } catch (e) {}
    },
    'ovStoryViewer': function () {
      if (!window.__storyBackgroundPaused) return;
      window.__storyBackgroundPaused = false;
      if (window.storyProgressPaused) return;
      try {
        var stage = document.getElementById('storyStage');
        if (!stage) return;
        var v = stage.querySelector('video');
        if (v && v.paused) {
          try {
            var p = v.play();
            if (p && p.catch) p.catch(function () {});
          } catch (e) {}
        }
      } catch (e) {}
    },
    'ovReelSplit': function () {
      if (!window.__reelSplitBackgroundPaused) return;
      window.__reelSplitBackgroundPaused = false;
      try {
        var v = document.getElementById('rsVideo');
        if (v && v.paused) {
          try {
            var p = v.play();
            if (p && p.catch) p.catch(function () {});
          } catch (e) {}
        }
      } catch (e) {}
    }
  };

  /* Get z-index of an element */
  function zOf(el) {
    if (!el) return 0;
    var z = parseInt(window.getComputedStyle(el).zIndex, 10);
    return isNaN(z) ? 0 : z;
  }

  /* Return currently-open overlays, sorted topmost-first */
  function getOpenStack() {
    var stack = [];
    for (var i = 0; i < OVERLAY_IDS.length; i++) {
      var id = OVERLAY_IDS[i];
      var el = document.getElementById(id);
      if (!el) continue;
      if (!el.classList.contains('open')) continue;
      stack.push({ id: id, el: el, z: zOf(el) });
    }
    stack.sort(function (a, b) { return b.z - a.z; });
    return stack;
  }

  /* Also detect dynamically-created overlays not in OVERLAY_IDS */
  function getDynamicOverlays() {
    var list = [];
    var all = document.querySelectorAll('.overlay.open, .reels-feed.open, .story-viewer.open, .reel-split.open');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (!el.id) continue;
      if (OVERLAY_IDS.indexOf(el.id) !== -1) continue;
      list.push({ id: el.id, el: el, z: zOf(el) });
    }
    return list;
  }

  function getAllStack() {
    return getOpenStack().concat(getDynamicOverlays()).sort(function (a, b) {
      return b.z - a.z;
    });
  }

  /* Pause all overlays below the topmost */
  function pauseBelowTop() {
    var stack = getAllStack();
    if (stack.length < 2) return;

    var top = stack[0];
    for (var i = 1; i < stack.length; i++) {
      var id = stack[i].id;
      if (PAUSE_HOOKS[id]) {
        try { PAUSE_HOOKS[id](); } catch (e) {}
      }
    }
  }

  /* Resume topmost overlay if it was background-paused */
  function resumeTop() {
    var stack = getAllStack();
    if (!stack.length) return;
    var top = stack[0];
    if (RESUME_HOOKS[top.id]) {
      try { RESUME_HOOKS[top.id](); } catch (e) {}
    }
  }

  /* One periodic scan does both: pause-below-top and resume-top */
  var _lastTopId = null;

  function scan() {
    var stack = getAllStack();
    if (!stack.length) {
      /* Nothing open — clear flags so next open starts fresh */
      window.__reelsBackgroundPaused = false;
      window.__storyBackgroundPaused = false;
      window.__reelSplitBackgroundPaused = false;
      _lastTopId = null;
      return;
    }

    var topId = stack[0].id;

    /* If top changed → resume new top */
    if (_lastTopId !== topId) {
      resumeTop();
      _lastTopId = topId;
    }

    /* Pause everything below the top */
    if (stack.length > 1) {
      for (var i = 1; i < stack.length; i++) {
        var id = stack[i].id;
        if (PAUSE_HOOKS[id]) {
          try { PAUSE_HOOKS[id](); } catch (e) {}
        }
      }
    }
  }

  setInterval(scan, SCAN_MS);

  /* Also scan immediately after any overlay action */
  ['openOverlay', 'closeOverlay'].forEach(function (name) {
    var orig = window[name];
    if (typeof orig === 'function') {
      window[name] = function () {
        var r = orig.apply(this, arguments);
        setTimeout(scan, 60);
        return r;
      };
    }
  });

  /* Manual API */
  window.SaikoBackStack = {
    scan: scan,
    getStack: getAllStack,
    pauseBelowTop: pauseBelowTop,
    resumeTop: resumeTop
  };

  try {
    console.debug('[boot] feature 051 — back-stack ready');
  } catch (e) {}
})();