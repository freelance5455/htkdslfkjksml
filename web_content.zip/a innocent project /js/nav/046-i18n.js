/* ============================================================
 * SUPPORTING FILE (FEATURE 046 — i18n Core)
 * FILE:   js/nav/046-i18n.js
 * ACTION: CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Core internationalisation subsystem. Owns:
 *     • I18N      — string table (English base + 21 fallbacks
 *                   that copy the English table, matching the
 *                   original source exactly)
 *     • LANGUAGES — array of 22 language descriptors
 *     • t(key)    — translator (falls back to en → key)
 *     • applyI18n(root) — walks the DOM updating any
 *                   [data-i18n] textContent and
 *                   [data-i18n-ph] placeholder attributes.
 *
 *   The base English table is copied byte-for-byte from the
 *   original §4 i18n block. Non-English fallbacks use
 *   Object.assign({}, I18N.en) so any missing key transparently
 *   resolves to English, exactly as in the source.
 *
 *   Also exposes window.LANGUAGES and window.I18N so any
 *   module (notably feature 019's language picker) can read
 *   them without redeclaring.
 *
 * ORIGINAL LOCATION (index.html):
 *   Section §4 i18n — everything from `const I18N = {...}`
 *   through `applyI18n` function definition.
 *
 * DEPENDENCIES (loaded earlier):
 *   - window.prefs (prefs-core.js) — t() reads prefs.lang
 *
 * DOM ELEMENTS USED:
 *   any element with [data-i18n] or [data-i18n-ph]
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none directly (prefs.lang read via prefs-core)
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.I18N
 *   window.LANGUAGES
 *   window.t
 *   window.applyI18n
 *   window.SaikoI18n = { I18N, LANGUAGES, t, apply, get, setLang }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * I18N — English base table
   * Copied byte-for-byte from the original §4 block.
   * ---------------------------------------------------------- */
  var I18N = {
    en: {
      app_name: "InnocentSaiko", tagline: "Chat • Play • Connect",
      login: "Login", signup: "Sign Up", email: "Email", password: "Password", name: "Name",
      login_btn: "Login", signup_btn: "Create Account",
      home: "Home", inbox: "Inbox", games: "Games", notifications: "Alerts", settings: "Settings", profile: "Profile",
      search: "Search", search_users: "Search Users", search_users_ph: "Search by name...",
      type_to_search: "Type a name to search", no_results: "No users found",
      loading: "Loading...", error: "Something went wrong", retry: "Retry",
      create_post: "Create Post", edit_profile: "Edit Profile", start_chat: "Start Chat",
      posts: "Posts", photos: "Photos", write_something: "What's on your mind?",
      publish: "Publish", cancel: "Cancel", add_image: "Add Image", image: "Image",
      like: "Like", comment: "Comment", share: "Share", comments: "Comments",
      write_comment: "Write a comment...", reply: "Reply", reply_to: "Reply to", send: "Send",
      new_chat: "New Chat", new_group: "New Group", group_name: "Group Name",
      group_image: "Group Image", create: "Create", create_group: "Create Group",
      members: "Members", add_members: "Add Members",
      type_message: "Type a message...", emoji: "Emoji", voice_message: "Voice message",
      record: "Record", stop: "Stop",
      call: "Call", video_call: "Video Call", incoming_call: "Incoming call",
      accept: "Accept", reject: "Reject", end_call: "End", calling: "Calling...", ringing: "Ringing...",
      connected: "Connected", call_ended: "Call ended",
      mark_all_read: "Mark all read", no_notifications: "No notifications yet", admin: "Admin",
      appearance: "Appearance / Color", ui_size: "UI Size", dark_mode: "Dark Mode",
      language: "Language", profile_settings: "Profile Settings", logout: "Logout",
      on: "ON", off: "OFF", save: "Save", saved: "Saved", bio: "Bio",
      dob: "Date of Birth", relationship: "Relationship Status", joining: "Joining Date",
      search_language: "Search language",
      confirm_logout: "Are you sure you want to logout?",
      yes: "Yes", no: "No", ok: "OK", delete: "Delete", are_you_sure: "Are you sure?",
      uploading: "Uploading...", please_wait: "Please wait...",
      no_posts: "No posts yet", no_chats: "No chats yet", no_games: "No games published yet",
      play: "Play", fullscreen: "Fullscreen", close: "Close",
      not_supported: "This feature is not supported on this browser",
      permission_denied: "Permission denied",
      select_users: "Select Users", done: "Done", edit: "Edit", delete_post: "Delete post",
      single: "Single", group: "Group", you: "You", new_message: "New message",
      liked_your_post: "liked your post", commented_on: "commented on your post",
      replied_to: "replied to your comment", members_count: "members",
      search_lang_ph: "Search language...",
      total_posts: "Posts", total_photos: "Photos",
      bio_ph: "Tell something about yourself", change_photo: "Change Photo",
      save_changes: "Save Changes", upload_failed: "Upload failed",
      login_failed: "Login failed", signup_failed: "Signup failed", fill_all: "Please fill all fields",
      config_missing: "Firebase/Cloudinary config missing.",
      call_failed: "Call failed", no_answer: "No answer", user_busy: "User busy",
      typing: "typing...", online: "Online", offline: "Offline",
      delivered: "Delivered", read: "Read", description: "Description",
      submit: "Submit", report: "Report", remove: "Remove",
      block: "Block", unblock: "Unblock", blocked_users: "Blocked Users",
      blocked: "Blocked", unblocked: "Unblocked", user_blocked: "User blocked",
      privacy: "Privacy", notification_settings: "Notifications",
      chat_settings: "Chat", call_settings: "Calls", media: "Media", about: "About",
      online_status_visibility: "Online status visibility",
      last_seen_visibility: "Last seen visibility",
      call_permission: "Who can call me",
      everyone: "Everyone", nobody: "Nobody",
      message_settings: "Message settings",
      show_read_receipts: "Show read receipts", enter_to_send: "Enter to send",
      auto_download_media: "Auto-download media", clear_cache: "Clear cache",
      version: "Version", developer: "Developer",
      mute: "Mute", unmute: "Unmute", muted: "Muted", pin: "Pin", unpin: "Unpin",
      pinned: "Pinned", copy: "Copy", copied: "Copied", forward: "Forward",
      delete_for_me: "Delete for me", delete_for_everyone: "Delete for everyone",
      react: "React", message_deleted: "This message was deleted",
      search_chat: "Search in chat", minimize: "Minimize", expand: "Expand",
      speaker: "Speaker", screen_share: "Screen Share", stop_share: "Stop Share",
      switch_camera: "Switch Camera", camera: "Camera",
      call_history: "Call History", missed_call: "Missed call",
      outgoing: "Outgoing", incoming: "Incoming",
      reconnecting: "Reconnecting...", connection_failed: "Connection failed",
      featured: "Featured", recent: "Recently added", recent_played: "Recently played",
      categories: "Categories", all: "All", search_games: "Search games...",
      report_sent: "Report submitted", hide_post: "Hide post", hidden: "Hidden",
      view_profile: "View Profile", share_profile: "Share Profile",
      edit_post: "Edit post", edit_comment: "Edit comment", delete_comment: "Delete comment",
      copy_text: "Copy text", leave_group: "Leave group", rename_group: "Rename group",
      change_image: "Change image", make_admin: "Make admin",
      remove_admin: "Remove admin", remove_member: "Remove member",
      add: "Add", leave: "Leave", group_info: "Group Info", no_groups: "No groups yet",
      see_all: "See all", show_less: "Show less", hide: "Hide", clear: "Clear",
      sending: "Sending", failed: "Failed", tap_retry: "Tap to retry",
      network_offline: "You are offline", network_back: "Back online",
      refresh: "Refresh", pull_refresh: "Pull to refresh",
      camera_on: "Camera on", camera_off: "Camera off",
      mic_on: "Mic on", mic_off: "Mic off", screen_sharing: "Screen sharing",
      pick_reason: "Select a reason", reason_spam: "Spam",
      reason_abuse: "Abuse or harassment", reason_inappropriate: "Inappropriate content",
      reason_fake: "Fake account", reason_other: "Other",
      reply_hint: "Replying to", cancel_reply: "Cancel reply",
      blocked_list_empty: "No blocked users",
      more: "More", less: "Less", load_more: "Load more", no_more: "No more",
      new_posts: "New posts", account_blocked: "Your account is temporarily restricted",
      suspended_until: "Suspended until", edited: "edited",
      select: "Select", select_all: "Select all", unselect_all: "Unselect all",
      tap_to_change: "Tap to change", save_prefs: "Preferences saved",
      chat_muted: "Chat muted", chat_unmuted: "Chat unmuted",
      message_pinned: "Message pinned", message_unpinned: "Message unpinned",
      message_forwarded: "Message forwarded", profile_shared: "Profile link copied",
      invalid_file: "Invalid file type", file_too_large: "File is too large",
      login_required: "Please login first",
      forgot_password: "Forgot password?",
      reset_sent: "Password reset email sent",
      reset_failed: "Could not send reset email",
      screen_share_unsupported: "Screen sharing is not supported by this browser/device.",
      screen_share_cancelled: "Screen share cancelled.",
      screen_share_denied: "Screen share permission denied.",
      screen_share_no_source: "No screen or window selected.",
      screen_share_unreadable: "Screen source could not be captured.",
      screen_share_secure: "Screen sharing requires a secure (HTTPS) connection.",
      account: "Account", accessibility: "Accessibility",
      reduced_motion: "Reduce motion", data_usage: "Data usage", storage: "Storage",
      change_password: "Change password", change_email: "Change email",
      password_changed: "Password updated", email_changed: "Verification email sent",
      pinned_posts: "Pinned posts", no_media: "No media",
      camera_permission: "Camera permission required",
      mic_permission: "Microphone required",
      you_are_offline: "You are offline", please_retry: "Please try again",
      report_user: "Report user", report_post: "Report post",
      report_comment: "Report comment", report_message: "Report message",
      reacted_to: "reacted to your message", added_to_group: "added you to a group",
      no_more_posts: "No more posts", loading_more: "Loading more...",
      saved_posts: "Saved Posts", bookmark: "Save", unbookmark: "Unsave",
      trending: "Trending", leaderboard: "Leaderboard",
      missions: "Missions", xp: "XP", level: "Level", badges: "Badges",
      stories: "Stories", reels: "Reels", visitors: "Visitors",
      hashtag: "Hashtag", create_story: "Create Story",
      add_story: "Add Story", my_story: "My Story",
      viewers: "viewers", no_stories: "No stories yet",
      upload_video: "Upload video", video: "Video",
      no_reels: "No reels yet", my_missions: "Daily Missions",
      mission_done: "Completed", rank: "Rank", no_visitors: "No visitors yet",
      video_too_long: "Video exceeds maximum duration",
      video_too_big: "Video exceeds maximum size",
      chat_theme: "Chat Theme", chat_with_admins: "Chat with Admins",
      admin_support: "Admin Support",
      too_many_images: "Too many images (max {n})",
      add_video: "Add Video", add_images: "Add Images",
      for_you: "For You", latest: "Latest",
      feed_empty: "No posts yet — be the first!",
      composer_hint: "Up to 10 images per post",
      e2e_encrypted: "End-to-end encrypted", e2e_secure_chat: "Secure chat",
      drafts: "Drafts", draft_saved: "Draft saved",
      storage_manager: "Storage Manager", data_saver: "Data Saver",
      performance_mode: "Performance Mode", activity_center: "Activity Center",
      insights: "Insights", smart_feed: "Smart Feed",
      pinboard: "Pinboard", recently_viewed: "Recently Viewed",
      content_mute: "Mute Content", mute_author: "Mute author",
      unmute_author: "Unmute author", pinned: "Pinned",
      unpin_post: "Unpin post", pin_post: "Pin post",
      max_pins: "Maximum 3 pinned items",
      reply_with_mention: "Replying to", tap_double_like: "Double-tap to like",
      long_press_react: "Long-press to react",
      claim: "Claim", story_viewers: "Viewers",
      no_viewers: "No viewers yet", download: "Download",
      saved_to_device: "Saved to device",
      opening_image: "Opening image in new tab",
      user_offline_notified: "User is offline — call request saved.",
      recipient_offline: "Recipient is offline",
      story_reply_sent: "Reply sent", story_reacted: "Reaction added",
      group_call: "Group Call",
      chat_info: "Chat Info", theme: "Theme",
      username_set: "Username Set", sms_block: "SMS Block", call_block: "Call Block",
      blocked_sms: "Blocked from sending messages",
      blocked_calls: "Blocked from calling",
      block_sms_confirm: "Block this user from sending you messages?",
      block_call_confirm: "Block this user from calling you?",
      calls_blocked: "User blocked from calling",
      sms_blocked: "User blocked from messaging",
      set_nickname: "Set Nickname", nickname: "Nickname",
      nickname_hint: "Only visible to you in this chat",
      remove_nickname: "Remove nickname",
      nickname_saved: "Nickname saved", nickname_removed: "Nickname removed",
      reply_to_story: "Replying to your Story", your_story: "your Story",
      popular: "Popular", my_interests: "My Interests",
      recent_searches: "Recent Searches", clear_all: "Clear all",
      add_highlight: "Add to Highlight", highlights: "Highlights",
      new_highlight: "New Highlight", highlight_name: "Highlight name",
      star_message: "Star message", unstar_message: "Unstar message",
      starred: "Starred", auto_delete: "Auto-delete messages",
      auto_delete_off: "Off", auto_delete_24h: "24 hours",
      auto_delete_7d: "7 days", auto_delete_90d: "90 days",
      clear_chat: "Clear chat", create_poll: "Create poll",
      poll_question: "Question", poll_option: "Option",
      add_option: "Add option", remove_option: "Remove option",
      poll_created: "Poll created",
      weekly_missions: "Weekly Missions", streak: "Streak",
      day_streak: "day streak", achievements: "Achievements",
      achievement_unlocked: "Achievement unlocked",
      cover_photo: "Cover Photo", change_cover: "Change Cover",
      collections: "Collections", new_collection: "New Collection",
      collection_name: "Collection name", add_to_collection: "Add to Collection",
      watch_later: "Watch Later", reels_history: "Reels History",
      saved_reels: "Saved Reels",
      backup: "Backup & Recovery", export_data: "Export My Data",
      backup_info: "Backup info", restore: "Restore",
      login_activity: "Login Activity", active_sessions: "Active Sessions",
      logout_other: "Logout other sessions",
      app_lock: "App Lock", app_lock_hint: "Set a 4-digit PIN to secure the app",
      set_pin: "Set PIN", confirm_pin: "Confirm PIN",
      pin_set: "PIN set successfully", pin_removed: "PIN removed",
      wrong_pin: "Wrong PIN", enter_pin: "Enter your PIN",
      muted_users: "Muted Users", admin_list: "Admin List",
      admin_activity: "Admin Activity", no_admin_activity: "No admin activity",
      featured_posts: "Featured Posts", feature_post: "Feature on profile",
      unfeature_post: "Remove from featured",
      user_list: "User List", following_not: "Not a follow system",
      select_reason: "Select reason", reason_hate: "Hate speech",
      report_target_user: "user", report_target_post: "post",
      report_target_reel: "reel", report_target_comment: "comment",
      report_target_message: "message",
      only_pinned_3: "Only 3 items can be pinned",
      created: "Created", view_all: "View all", no_data: "No data",
      message_starred: "Message starred", message_unstarred: "Message unstarred",
      edit_reel: "Edit reel", delete_reel: "Delete reel",
      copy_caption: "Copy caption", reel_caption: "Caption",
      save_to_collection: "Save to collection",
      saved_to_collection: "Saved to collection",
      removed_from_collection: "Removed from collection",
      create_collection_first: "Create a collection first",
      watched: "watched", now_watching: "Now watching",
      show_more: "Show more", back: "Back",
      settings_saved: "Settings saved", failed_to_save: "Failed to save",
      username: "Username", display_name: "Display name",
      cover: "Cover", theme_color: "Theme color", profile_theme: "Profile theme",
      media_not_supported: "Media not supported", link_copied: "Link copied",
      pin_to_highlight: "Pin to highlight",
      unpin_from_highlight: "Unpin from highlight",
      choose_highlight: "Choose highlight",
      close_friends: "Close Friends",
      close_friends_hint: "Only your close friends can see this",
      public: "Public",
      select_close_friends: "Select Close Friends",
      added_to_close: "Added to close friends",
      removed_from_close: "Removed from close friends",
      play_offline: "Play Offline Game", offline_games: "Offline Games",
      no_offline_games: "No offline games available. Connect once to cache games.",
      restricted_posts: "Restricted Posts", restricted: "Restricted",
      request_review: "Request Review", review_request_sent: "Review request sent",
      restriction_reason: "Restriction reason", suspended_on: "Suspended on",
      current_status: "Current status", pending_review: "Pending review",
      group_call_waiting: "Waiting for participants...",
      join_call: "Join call", call_joined: "Joined call",
      participants: "Participants",
      offline_call_saved: "User is offline. Call request saved.",
      load_more_replies: "Load more replies", showing_replies: "replies"
    }
  };

  /* ----------------------------------------------------------
   * LANGUAGES — 22 descriptors, original order preserved.
   * ---------------------------------------------------------- */
  var LANGUAGES = [
    { code: 'en', name: 'English',    native: 'English' },
    { code: 'hi', name: 'Hindi',      native: 'हिन्दी' },
    { code: 'es', name: 'Spanish',    native: 'Español' },
    { code: 'fr', name: 'French',     native: 'Français' },
    { code: 'de', name: 'German',     native: 'Deutsch' },
    { code: 'pt', name: 'Portuguese', native: 'Português' },
    { code: 'ru', name: 'Russian',    native: 'Русский' },
    { code: 'ar', name: 'Arabic',     native: 'العربية' },
    { code: 'zh', name: 'Chinese',    native: '中文' },
    { code: 'ja', name: 'Japanese',   native: '日本語' },
    { code: 'ko', name: 'Korean',     native: '한국어' },
    { code: 'id', name: 'Indonesian', native: 'Bahasa Indonesia' },
    { code: 'tr', name: 'Turkish',    native: 'Türkçe' },
    { code: 'bn', name: 'Bengali',    native: 'বাংলা' },
    { code: 'ur', name: 'Urdu',       native: 'اردو' },
    { code: 'it', name: 'Italian',    native: 'Italiano' },
    { code: 'nl', name: 'Dutch',      native: 'Nederlands' },
    { code: 'pl', name: 'Polish',     native: 'Polski' },
    { code: 'th', name: 'Thai',       native: 'ไทย' },
    { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt' },
    { code: 'fa', name: 'Persian',    native: 'فارسی' },
    { code: 'sw', name: 'Swahili',    native: 'Kiswahili' }
  ];

  /* ----------------------------------------------------------
   * Fallback languages copy the English table.
   * Preserved 1:1 from the original forEach block.
   * ---------------------------------------------------------- */
  ['hi','es','fr','de','pt','ru','ar','zh','ja','ko',
   'id','tr','bn','ur','it','nl','pl','th','vi','fa','sw'].forEach(function (code) {
    if (!I18N[code]) I18N[code] = Object.assign({}, I18N.en);
  });

  /* ----------------------------------------------------------
   * t(key) — translator
   * Preserved 1:1 from the original.
   * Reads prefs.lang; falls back to en; falls back to key.
   * ---------------------------------------------------------- */
  function getLang() {
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs && window.prefs.lang) {
        return window.prefs.lang;
      }
    } catch (e) {}
    return 'en';
  }

  function t(key) {
    var lang = getLang();
    var L = I18N[lang];
    if (L && L[key] != null) return L[key];
    return I18N.en[key] != null ? I18N.en[key] : key;
  }

  /* ----------------------------------------------------------
   * applyI18n(root)
   * Preserved 1:1 from the original.
   * Walks [data-i18n] → textContent, [data-i18n-ph] → placeholder
   * ---------------------------------------------------------- */
  function applyI18n(root) {
    var scope = root || document;
    var nodesText = scope.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodesText.length; i++) {
      nodesText[i].textContent = t(nodesText[i].getAttribute('data-i18n'));
    }
    var nodesPh = scope.querySelectorAll('[data-i18n-ph]');
    for (var j = 0; j < nodesPh.length; j++) {
      nodesPh[j].setAttribute('placeholder', t(nodesPh[j].getAttribute('data-i18n-ph')));
    }
  }

  /* ----------------------------------------------------------
   * setLang — programmatic setter used by feature 019 and
   * future tools. Persists and re-applies translations.
   * ---------------------------------------------------------- */
  function setLang(code) {
    if (!code || !I18N[code]) return false;
    try {
      if (typeof window.prefs !== 'undefined' && window.prefs) {
        window.prefs.lang = code;
      }
    } catch (e) {}
    try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {}
    applyI18n();
    return true;
  }

  /* ----------------------------------------------------------
   * EXPOSE on window
   * ---------------------------------------------------------- */
  window.I18N = I18N;
  window.LANGUAGES = LANGUAGES;
  window.t = t;
  window.applyI18n = applyI18n;

  window.SaikoI18n = {
    I18N: I18N,
    LANGUAGES: LANGUAGES,
    t: t,
    apply: applyI18n,
    get: getLang,
    setLang: setLang
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 046 — i18n core ready');
  } catch (e) {}

})();