/* ============================================================
 * FEATURE:        Bottom Navigation
 * FEATURE NUMBER: 036
 * FILE:           js/nav/036-bottom-nav.js
 * ACTION:         REPLACE (Batch 9 — extended buildNavIcons)
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the bottom nav bar and also mounts every static icon
 *   across the app that the reference single-file build mounted
 *   inside buildNavIcons() — search, chat header buttons,
 *   composer controls, call controls, sidebar close, viewer
 *   actions, etc.
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  var PAGES = ['home', 'inbox', 'games', 'notifications', 'profile'];

  var NAV_ICONS = {
    home:          'home',
    inbox:         'chat',
    games:         'game',
    notifications: 'bell',
    settings:      'gear',
    profile:       'user'
  };

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  function safeCall(fnName, args) {
    try {
      var fn = window[fnName];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {
      console.warn('[bottom-nav] safeCall failed for', fnName, e);
    }
    return undefined;
  }

  /* ----------------------------------------------------------
   * NAV CHANGE SUBSCRIBERS
   * ---------------------------------------------------------- */
  var navHandlers = new Set();

  function onNavChange(fn)  { if (typeof fn === 'function') navHandlers.add(fn); }
  function offNavChange(fn) { navHandlers.delete(fn); }

  function emitNav(nav, prev) {
    navHandlers.forEach(function (fn) {
      try { fn(nav, prev); } catch (e) { console.warn(e); }
    });
    try {
      window.dispatchEvent(new CustomEvent('saiko:navigate', {
        detail: { nav: nav, previous: prev }
      }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * Global state getters/setters
   * ---------------------------------------------------------- */
  function getCurrent() {
    return (typeof window.currentNav === 'string') ? window.currentNav : 'home';
  }

  function setCurrent(nav) {
    window.currentNav = nav;
  }

  /* ============================================================
   * BUILD NAV ICONS — EXTENDED (Batch 9 fix)
   * ============================================================
   * 1. Mount SVG on every #bottomNav .nav-btn's .ni holder.
   * 2. Also mount SVG on the full set of static icon buttons
   *    that the reference single-file build mounted inside its
   *    buildNavIcons() — search, chat header, composer, etc.
   *    Same set, same order, same guards (only when empty).
   * ============================================================ */
  function buildNavIcons(root) {
    var scope = root || document;

    /* 1) Bottom nav icons ---------------------------------- */
    qsa('#bottomNav .nav-btn', scope).forEach(function (btn) {
      var k = btn.getAttribute('data-nav');
      var holder = btn.querySelector('.ni');
      if (holder && typeof window.svgIcon === 'function') {
        if (!holder.innerHTML.trim()) {
          holder.innerHTML = window.svgIcon(NAV_ICONS[k] || 'info');
        }
      }
    });

    /* 2) Static buttons — same set as the reference --------- */
    var set = function (sel, icon) {
      var n = qs(sel, scope);
      if (n && !n.innerHTML.trim() && typeof window.svgIcon === 'function') {
        n.innerHTML = window.svgIcon(icon);
      }
    };

    /* Topbar + chat header -------------------------------- */
    set('#btnSearch',     'search');
    set('#btnVoiceCall',  'phone');
    set('#btnVideoCall',  'video');
    set('#btnChatInfo',   'info');

    /* Chat composer --------------------------------------- */
    set('#btnEmoji',      'emoji');
    set('#btnAttach',     'image');
    set('#btnMic',        'mic');
    set('#btnSend',       'send');
    set('#btnSendComment','send');

    /* Other overlays -------------------------------------- */
    set('#btnGameFull',    'expand');
    set('#sidebarClose',   'close');
    set('#viewerShare',    'share');
    set('#viewerDownload', 'download');

    /* Mini call ------------------------------------------- */
    set('#miniMute',   'micOff');
    set('#miniExpand', 'expand');
    set('#miniEnd',    'phoneOff');

    /* Story / Reels --------------------------------------- */
    set('#storyClose',       'close');
    set('#reelsClose',       'back');
    set('#reelsUpload',      'plus');
    set('#rsSendComment',    'send');
    set('#splitSendComment', 'send');
    set('#storyReplySend',   'send');

    /* Any element with [data-close] ----------------------- */
    qsa('[data-close]', scope).forEach(function (b) {
      if (!b.innerHTML.trim() && typeof window.svgIcon === 'function') {
        b.innerHTML = window.svgIcon('close');
      }
    });
  }

  /* ----------------------------------------------------------
   * NAVIGATE
   * ---------------------------------------------------------- */
  function navigate(nav) {
    if (nav === 'settings') {
      safeCall('openSettingsSidebar');
      return;
    }

    var prev = getCurrent();
    setCurrent(nav);

    qsa('#bottomNav .nav-btn').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-nav') === nav);
    });

    PAGES.forEach(function (p) {
      var s = document.getElementById('page-' + p);
      if (s) s.classList.toggle('hidden', p !== nav);
    });

    if (nav === 'inbox')         safeCall('renderInbox');
    if (nav === 'games')         safeCall('renderGames');
    if (nav === 'notifications') safeCall('renderNotifications');
    if (nav === 'profile')       safeCall('renderProfilePage');
    if (nav === 'home')          safeCall('renderFeed');

    try { window.scrollTo({ top: 0, behavior: 'auto' }); } catch (e) {}

    if (prev !== nav) emitNav(nav, prev);
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bar = qs('#bottomNav', scope);
    if (!bar) return false;
    if (bar.dataset.bottomNavBound === '1') return true;
    bar.dataset.bottomNavBound = '1';

    bar.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('.nav-btn') : null;
      if (!b) return;
      navigate(b.getAttribute('data-nav'));
    });

    buildNavIcons(scope);
    return true;
  }

  function unbind(root) {
    var scope = root || document;
    var bar = qs('#bottomNav', scope);
    if (!bar) return;
    var clone = bar.cloneNode(true);
    clone.removeAttribute('data-bottom-nav-bound');
    bar.parentNode && bar.parentNode.replaceChild(clone, bar);
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.currentNav     = getCurrent();
  window.navigate       = navigate;
  window.buildNavIcons  = buildNavIcons;

  window.SaikoBottomNav = {
    PAGES: PAGES.slice(),
    NAV_ICONS: Object.assign({}, NAV_ICONS),
    navigate: navigate,
    bind: bind,
    unbind: unbind,
    buildNavIcons: buildNavIcons,
    getCurrent: getCurrent,
    setCurrent: setCurrent,
    onNavChange: onNavChange,
    offNavChange: offNavChange
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { bind(); }, { once: true });
  } else {
    bind();
  }

  try {
    console.debug('[boot] feature 036 — bottom-nav ready (extended icons)');
  } catch (e) {}

})();