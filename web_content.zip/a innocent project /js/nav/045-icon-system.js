/* ============================================================
 * FEATURE:        SVG Icon System
 * FEATURE NUMBER: 045
 * FILE:           js/nav/045-icon-system.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   The single source of truth for every inline SVG icon in
 *   the app. Every button, nav item, sheet row, action,
 *   reaction picker, settings entry, call control, story
 *   control, and card decoration draws its graphic from this
 *   module.
 *
 *   Provides three primitives:
 *
 *     ICONS
 *       70 named icon definitions. Each value is the inner
 *       markup of a 24×24 viewBox — typically one or more
 *       <path> / <circle> / <rect> elements using the
 *       stroke-based "Feather"-style grammar. Preserved
 *       byte-for-byte from the original source.
 *
 *     svgIcon(name, fill)
 *       Wraps the icon markup in a <span class="ic">…</span>
 *       container with an inner <svg viewBox="0 0 24 24">.
 *       When `fill` is truthy the wrapper gains the `.fill`
 *       modifier which switches the CSS to `fill: currentColor`
 *       and drops the stroke. Unknown names fall back to
 *       ICONS.info.
 *
 *     mountIcons(root)
 *       Walk every element with a `[data-icon]` attribute
 *       inside `root` (defaults to the whole document) and
 *       inject the corresponding svgIcon() markup into its
 *       innerHTML, then add the `.ic` class to the element.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §3 ICONS — the ICONS object plus svgIcon() and
 *     mountIcons() helpers.
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure string templates
 *
 * DOM ELEMENTS USED:
 *   any element carrying a [data-icon] attribute (only read
 *   when mountIcons is called)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.ICONS                  (original name preserved)
 *   window.svgIcon                (original name preserved)
 *   window.mountIcons             (original name preserved)
 *   window.SaikoIcons = {
 *     ICONS, svgIcon, mountIcons,
 *     has, names
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ============================================================
   * ICONS — 70 named icons, preserved byte-for-byte from the
   * original §3 block. Do NOT reformat or reorder — some
   * legacy callers may rely on the shape of the markup (e.g.
   * tests or dev tooling that visually diffs icons).
   * ============================================================ */
  var ICONS = {
    home:'<path d="M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
    chat:'<path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/>',
    game:'<rect x="2" y="6" width="20" height="12" rx="4"/><path d="M6 12h4M8 10v4M16 11h.01M18 13h.01"/>',
    bell:'<path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    gear:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.5-2.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z"/>',
    user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>',
    heart:'<path d="M20.8 5.6a5 5 0 0 0-7.1 0L12 7.3l-1.7-1.7a5 5 0 1 0-7.1 7.1l8.8 8.8 8.8-8.8a5 5 0 0 0 0-7.1z"/>',
    comment:'<path d="M21 11.5a8 8 0 0 1-8 8H7l-4 3v-5.4A8 8 0 1 1 21 11.5z"/>',
    share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
    send:'<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    mic:'<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M8 22h8"/>',
    micOff:'<path d="M9 9v3a3 3 0 0 0 5.1 2.1M15 9.3V5a3 3 0 0 0-5.9-.7"/><path d="M5 11a7 7 0 0 0 10.5 6.1M19 11v1a7 7 0 0 1-.6 2.8M12 18v4M8 22h8"/><path d="m2 2 20 20"/>',
    phone:'<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2 4.2 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    video:'<path d="m23 7-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    videoOff:'<path d="M16 16v2a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2m4 0h5a2 2 0 0 1 2 2v2"/><path d="m23 7-4 3 4 3V7z"/><path d="m2 2 20 20"/>',
    phoneOff:'<path d="M10.7 13.3a16 16 0 0 0 3.4 2.6l1.3-1.1a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.8.7A2 2 0 0 1 22 17v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-4.3-3.7M5.6 9.3a19.8 19.8 0 0 1-3.6-5A2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9"/><path d="m2 2 20 20"/>',
    back:'<path d="M19 12H5M12 19l-7-7 7-7"/>',
    close:'<path d="M18 6 6 18M6 6l12 12"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    users:'<circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M17 4a4 4 0 0 1 0 8M22 21a7 7 0 0 0-4-6.3"/>',
    logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
    palette:'<circle cx="12" cy="12" r="9"/><circle cx="9" cy="9" r="1.2"/><circle cx="15" cy="9" r="1.2"/><circle cx="9.5" cy="15" r="1.2"/>',
    size:'<path d="M3 7V5h18v2M12 5v14M8 19h8"/>',
    moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/>',
    play:'<path d="M6 4l14 8-14 8z"/>',
    expand:'<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/>',
    shrink:'<path d="M8 3v3a2 2 0 0 1-2 2H3M16 3v3a2 2 0 0 0 2 2h3M8 21v-3a2 2 0 0 0-2-2H3M16 21v-3a2 2 0 0 1 2-2h3"/>',
    emoji:'<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5a4.5 4.5 0 0 0 7 0"/><circle cx="9" cy="9.5" r="1"/><circle cx="15" cy="9.5" r="1"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/>',
    check:'<path d="m20 6-11 11-5-5"/>',
    info:'<circle cx="12" cy="12" r="9"/><path d="M12 16v-5M12 8h.01"/>',
    arrow:'<path d="M9 6l6 6-6 6"/>',
    flag:'<path d="M4 15V3h13l-2 5 2 5H4zM4 21v-6"/>',
    eyeOff:'<path d="M17.9 17.9A10.4 10.4 0 0 1 12 20c-7 0-10-8-10-8a18.5 18.5 0 0 1 5.1-6M9.9 4.2A10.9 10.9 0 0 1 12 4c7 0 10 8 10 8a18.6 18.6 0 0 1-2.2 3.2M14.1 14.1a3 3 0 1 1-4.2-4.2"/><path d="m2 2 20 20"/>',
    block:'<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
    copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    forward:'<path d="m15 17 5-5-5-5M20 12H9a4 4 0 0 0-4 4v3"/>',
    reply:'<path d="M9 17 4 12l5-5"/><path d="M4 12h11a5 5 0 0 1 5 5v2"/>',
    edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    pin:'<path d="M12 17v5M9 3h6l-1 6 3 3H7l3-3z"/>',
    unpin:'<path d="M12 17v5M9 3h6l-1 6 3 3H7l3-3z"/><path d="m2 2 20 20"/>',
    speaker:'<path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
    speakerOff:'<path d="M11 5 6 9H2v6h4l5 4z"/><path d="m22 9-6 6M16 9l6 6"/>',
    screen:'<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
    switchCam:'<path d="M23 19V8l-3-2h-4l-1.5 2H15"/><path d="M1 8v11l3 2h4l1.5-2H9"/><circle cx="12" cy="13" r="3"/>',
    minimize:'<path d="M4 14h6v6M20 10h-6V4M14 10l7-7M10 14l-7 7"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    lock:'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    wifi:'<path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0M12 20h.01"/>',
    star:'<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>',
    refresh:'<path d="M21 12a9 9 0 1 1-2.6-6.4M21 3v6h-6"/>',
    stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
    bookmark:'<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"/>',
    fire:'<path d="M12 22c4 0 6-2.7 6-6 0-4.5-6-14-6-14S6 11.5 6 16c0 3.3 2 6 6 6z"/><path d="M12 22c1.7 0 3-1.3 3-3 0-2-3-6-3-6s-3 4-3 6c0 1.7 1.3 3 3 3z"/>',
    trophy:'<path d="M6 4h12v3a6 6 0 0 1-12 0zM6 4H4v2a3 3 0 0 0 3 3M18 4h2v2a3 3 0 0 1-3 3M9 17h6M12 13v4M8 21h8"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
    eye:'<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    film:'<rect x="2" y="3" width="20" height="18" rx="2"/><path d="M7 3v18M17 3v18M2 8h5M2 16h5M17 8h5M17 16h5"/>',
    server:'<rect x="2" y="3" width="20" height="8" rx="2"/><rect x="2" y="13" width="20" height="8" rx="2"/><path d="M6 7h.01M6 17h.01"/>',
    download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5M12 15V3"/>',
    at:'<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.9 7.9"/>',
    bar:'<path d="M12 20V10M18 20V4M6 20v-4"/>',
    list:'<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    thumbsUp:'<path d="M7 10v12M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88z"/>',
    folder:'<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    key:'<path d="M21 2l-2 2m-7.6 7.6a5 5 0 1 0-3 3L7 17l-3 3 1.5 1.5L8 19l2-2 3-3 1-1a5 5 0 0 0 3.4-3.4"/><circle cx="16.5" cy="7.5" r=".5"/>',
    alert:'<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>'
  };

  /* ============================================================
   * svgIcon — build a wrapped icon string
   * Preserved 1:1 from the original source.
   *
   *   name — key in ICONS (unknown names fall back to 'info')
   *   fill — when truthy, wrapper gets the `.fill` modifier
   *          (CSS switches the svg to fill:currentColor and
   *          removes the stroke)
   * ============================================================ */
  function svgIcon(name, fill) {
    var p = ICONS[name] || ICONS.info;
    return '<span class="ic' + (fill ? ' fill' : '') + '">' +
             '<svg viewBox="0 0 24 24">' + p + '</svg>' +
           '</span>';
  }

  /* ============================================================
   * mountIcons — replace [data-icon] placeholders
   * Preserved 1:1 from the original source.
   *
   * For every element inside `root` (default: document) that
   * carries a `data-icon="<name>"` attribute:
   *   • set its innerHTML to svgIcon(name)
   *   • add the `.ic` class to the element itself
   *
   * This is used in the initial boot to hydrate static
   * placeholders declared in index.html (e.g. empty nav
   * buttons whose icons are injected at runtime).
   * ============================================================ */
  function mountIcons(root) {
    var scope = root || document;
    var nodes = scope.querySelectorAll('[data-icon]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      try {
        el.innerHTML = svgIcon(el.getAttribute('data-icon'));
        el.classList.add('ic');
      } catch (e) {
        /* Swallow — a broken node should not abort the loop. */
      }
    }
  }

  /* ============================================================
   * Introspection helpers (additive — do not change behaviour)
   * ============================================================ */

  function has(name) {
    return !!name && Object.prototype.hasOwnProperty.call(ICONS, name);
  }

  function names() {
    return Object.keys(ICONS);
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */

  /* Original globals — preserved so every existing call site
   * (there are hundreds across the codebase) continues to
   * work with no changes. */
  window.ICONS      = ICONS;
  window.svgIcon    = svgIcon;
  window.mountIcons = mountIcons;

  window.SaikoIcons = {
    ICONS: ICONS,
    svgIcon: svgIcon,
    mountIcons: mountIcons,
    has: has,
    names: names
  };

  /* ============================================================
   * BOOT LOG
   * ============================================================ */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 045 — icon-system ready (' + names().length + ' icons)');
  } catch (e) {}

})();