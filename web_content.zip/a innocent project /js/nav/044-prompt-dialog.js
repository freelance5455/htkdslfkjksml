/* ============================================================
 * FEATURE:        Prompt Dialog
 * FEATURE NUMBER: 044
 * FILE:           js/nav/044-prompt-dialog.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Promise-based text-input modal. Unlike confirmDialog
 *   (feature 043) which uses a static overlay already
 *   present in index.html, promptDialog builds its own
 *   overlay entirely in JavaScript and removes it on close.
 *
 *   Public function (used by ~15 sibling modules):
 *     promptDialog(title, defValue, placeholder)
 *       → Promise<string | null>
 *         • resolve(inputValue) when user taps OK or Enter
 *         • resolve(null)       when user taps Cancel or Esc
 *
 *   Behaviour preserved 1:1 from original §5 UTILITIES
 *   promptDialog():
 *
 *     1. Create <div class="overlay open"> with inline styles
 *        background:rgba(0,0,0,.6) and z-index:150.
 *     2. Fill innerHTML with:
 *          <div class="confirm-box" style="padding:1rem">
 *            <h3 style="margin:0 0 .6rem">[title]</h3>
 *            <input class="input" id="__promptInput"
 *                   style="margin-bottom:.8rem"
 *                   value="[defValue]"
 *                   placeholder="[placeholder]">
 *            <div class="btns">
 *              <button class="btn ghost" id="__promptCancel">Cancel</button>
 *              <button class="btn solid" id="__promptOk">OK</button>
 *            </div>
 *          </div>
 *        All dynamic text (title/defValue/placeholder) is HTML-
 *        escaped via esc() before injection.
 *     3. Append overlay to <body>.
 *     4. After 50 ms, focus the input.
 *     5. Bind click handlers on OK / Cancel; bind keydown on
 *        the input for Enter (→ value) and Escape (→ null).
 *     6. finish(v) removes the overlay from the DOM and
 *        resolves the promise.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §5 UTILITIES → function promptDialog() { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   - esc(str)   → js/core/utils.js  (local fallback provided)
 *
 * DOM ELEMENTS USED:
 *   dynamically created; IDs:
 *     __promptInput, __promptCancel, __promptOk
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.promptDialog            (original name preserved)
 *   window.SaikoPromptDialog = {
 *     show, isOpen, close,
 *     on, off
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */

  /* HTML-escape helper — prefers the shared util, falls back
   * to a local implementation that matches the global output
   * for &, <, >, ", '.  (Original promptDialog used esc()
   * from the shared scope; we keep that but stay robust if
   * the util has not loaded yet.) */
  function esc(str) {
    try {
      if (typeof window.esc === 'function') return window.esc(str);
    } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Module state — one active prompt at a time.
   * ---------------------------------------------------------- */
  var _active = null;   /* { overlay, resolve, input, onOk, onCancel, onKey } */
  var listeners = new Set();

  /* ----------------------------------------------------------
   * Emit helper — additive subscriber notification.
   * ---------------------------------------------------------- */
  function emit(kind, payload) {
    listeners.forEach(function (fn) {
      try { fn(kind, payload); } catch (e) { console.warn(e); }
    });
    try {
      window.dispatchEvent(new CustomEvent(kind, { detail: payload }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * TEARDOWN — detach listeners + remove overlay from DOM.
   * ---------------------------------------------------------- */
  function teardown(state) {
    var s = state || _active;
    if (!s) return;
    try { if (s.input  && s.onKey)    s.input.removeEventListener('keydown', s.onKey); } catch (e) {}
    try { if (s.overlay && s.onOk)    s.overlay.querySelector('#__promptOk').removeEventListener('click', s.onOk); } catch (e) {}
    try { if (s.overlay && s.onCancel) s.overlay.querySelector('#__promptCancel').removeEventListener('click', s.onCancel); } catch (e) {}
    try { if (s.overlay && s.overlay.parentNode) s.overlay.parentNode.removeChild(s.overlay); } catch (e) {}
    if (_active === s) _active = null;
  }

  /* ----------------------------------------------------------
   * SHOW — main entry point.
   * Preserved 1:1 from original promptDialog().
   * ---------------------------------------------------------- */
  function show(title, defValue, placeholder) {
    return new Promise(function (resolve) {
      /* 1) Auto-dismiss any previously open prompt ---------- */
      if (_active) {
        var prev = _active;
        teardown(prev);
        try { prev.resolve(null); } catch (e) {}
        emit('saiko:prompt-replaced', { title: title });
      }

      /* 2) Build the overlay element ------------------------ */
      var ov = document.createElement('div');
      ov.className = 'overlay open';
      ov.style.cssText = 'background:rgba(0,0,0,.6);z-index:150';
      ov.innerHTML =
        '<div class="confirm-box" style="padding:1rem">' +
          '<h3 style="margin:0 0 .6rem">' + esc(title) + '</h3>' +
          '<input class="input" id="__promptInput" ' +
                 'style="margin-bottom:.8rem" ' +
                 'value="' + esc(defValue || '') + '" ' +
                 'placeholder="' + esc(placeholder || '') + '">' +
          '<div class="btns">' +
            '<button class="btn ghost" id="__promptCancel">Cancel</button>' +
            '<button class="btn solid" id="__promptOk">OK</button>' +
          '</div>' +
        '</div>';

      /* 3) Attach to <body> --------------------------------- */
      document.body.appendChild(ov);

      /* 4) Focus input after 50 ms -------------------------- */
      var inp = ov.querySelector('#__promptInput');
      if (inp) {
        setTimeout(function () {
          try { if (inp.isConnected) inp.focus(); } catch (e) {}
        }, 50);
      } else {
        /* Input missing — resolve immediately to avoid hang. */
        try { if (ov.parentNode) ov.parentNode.removeChild(ov); } catch (e) {}
        resolve(null);
        return;
      }

      /* 5) Internal completion routine ---------------------- */
      function finish(v) {
        var state = _active;
        teardown(state);
        emit('saiko:prompt-closed', {
          value: (v == null) ? null : String(v)
        });
        try { resolve(v); } catch (e) {}
      }

      /* 6) Bind handlers ------------------------------------ */
      var onOk = function () { finish(inp.value); };
      var onCancel = function () { finish(null); };
      var onKey = function (e) {
        if (!e) return;
        if (e.key === 'Enter') {
          e.preventDefault();
          finish(inp.value);
        } else if (e.key === 'Escape') {
          e.preventDefault();
          finish(null);
        }
      };

      var okBtn = ov.querySelector('#__promptOk');
      var cnBtn = ov.querySelector('#__promptCancel');
      if (okBtn) okBtn.addEventListener('click', onOk);
      if (cnBtn) cnBtn.addEventListener('click', onCancel);
      inp.addEventListener('keydown', onKey);

      /* 7) Stash the active state --------------------------- */
      _active = {
        overlay:  ov,
        input:    inp,
        resolve:  resolve,
        onOk:     onOk,
        onCancel: onCancel,
        onKey:    onKey
      };

      /* 8) Notify subscribers ------------------------------- */
      emit('saiko:prompt-opened', {
        title:       String(title || ''),
        defValue:    String(defValue || ''),
        placeholder: String(placeholder || '')
      });
    });
  }

  /* ----------------------------------------------------------
   * isOpen — true when a prompt is currently awaiting input.
   * ---------------------------------------------------------- */
  function isOpen() {
    return !!_active;
  }

  /* ----------------------------------------------------------
   * close — programmatic dismiss (resolves null).
   * Useful for logout / navigation teardown so pending
   * prompts do not leak.
   * ---------------------------------------------------------- */
  function close() {
    if (_active) {
      var s = _active;
      teardown(s);
      emit('saiko:prompt-closed', { value: null });
      try { s.resolve(null); } catch (e) {}
      return true;
    }
    return false;
  }

  /* ----------------------------------------------------------
   * SUBSCRIBERS
   * ---------------------------------------------------------- */
  function on(fn)  { if (typeof fn === 'function') listeners.add(fn); }
  function off(fn) { listeners.delete(fn); }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global name preserved — features 010 (PIN),
   * 133 (msg edit), 120 (group rename), 227 (collection name),
   * 201 (highlight name), 040 admin reply, and any other
   * caller continues to work with no changes. */
  window.promptDialog = show;

  window.SaikoPromptDialog = {
    show: show,
    isOpen: isOpen,
    close: close,
    on: on,
    off: off
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 044 — prompt-dialog ready');
  } catch (e) {}

})();