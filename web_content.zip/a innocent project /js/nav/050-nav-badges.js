/* ============================================================
 * FEATURE:        Nav Badges
 * FEATURE NUMBER: 050
 * FILE:           js/nav/050-nav-badges.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the two numeric badges that sit on the bottom nav:
 *
 *     #navInboxBadge   — total unread chat messages across all
 *                        chats (sum of chats/{id}/unread/{me})
 *     #navBadge        — total unread notifications
 *
 *   In the original single-file build both badges were set by
 *   inline snippets living inside their respective listener
 *   callbacks:
 *
 *     • startInbox()    → let total = 0;
 *                         Object.keys(unreadMap).forEach(k =>
 *                            total += (unreadMap[k]||0));
 *                         const b = $('#navInboxBadge');
 *                         if(b) b.textContent = total
 *                            ? (total > 99 ? '99+' : String(total))
 *                            : '';
 *
 *     • startNotifs()   → const unread = notifCache.filter(
 *                            n => !n.read).length;
 *                         const badge = $('#navBadge');
 *                         if(badge) badge.textContent = unread
 *                            ? (unread > 99 ? '99+' : String(unread))
 *                            : '';
 *
 *   This feature extracts that pattern into a single module so
 *   both listeners can call one canonical setter, and future
 *   modules can push badge updates without duplicating the
 *   '99+' formatting logic.
 *
 *   ORIGINAL BEHAVIOUR PRESERVED 1:1:
 *     • Empty string when count is 0 — the CSS rule
 *         .nav-btn .badge:empty { display:none; }
 *       hides the badge automatically.
 *     • '99+' shown when count exceeds 99.
 *     • Numbers shown as-is (String(count)) otherwise.
 *     • Negative / NaN inputs are treated as 0.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §19 NOTIFICATIONS → startNotifs() inline badge
 *     Section §20 INBOX         → updateInboxBadge()
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure DOM (badges are static in index.html)
 *
 * DOM ELEMENTS USED:
 *   #navBadge, #navInboxBadge
 *
 * FIREBASE PATHS:
 *   none directly — the listeners that compute counts and call
 *   setNotifBadge / setInboxBadge live in their own features
 *   (101 notifications, 113 chat meta).
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.updateInboxBadge          (original name preserved)
 *   window.SaikoNavBadges = {
 *     setNotifBadge, setInboxBadge, clearAll,
 *     getNotifCount, getInboxCount,
 *     format, MAX
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — match the original '99+' threshold.
   * ---------------------------------------------------------- */
  var MAX = 99;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  /* ----------------------------------------------------------
   * Internal cached counts (additive — used by getters and
   * does not affect DOM writes).
   * ---------------------------------------------------------- */
  var _notifCount = 0;
  var _inboxCount = 0;

  /* ----------------------------------------------------------
   * format(count)
   * Preserved 1:1 from the original source:
   *   0 or negative or NaN  → ''
   *   > MAX                 → '99+'
   *   otherwise             → String(count)
   * ---------------------------------------------------------- */
  function format(count) {
    var n = Number(count);
    if (!isFinite(n) || n <= 0) return '';
    if (n > MAX) return MAX + '+';
    /* Ensure integer display — the original callers always
     * passed integer sums so this was implicit; we make it
     * explicit for defensive robustness. */
    return String(Math.floor(n));
  }

  /* ----------------------------------------------------------
   * SET NOTIF BADGE
   * Writes the formatted value into #navBadge. The original
   * used this exact node id and set textContent to either the
   * formatted count or ''. CSS handles hiding on empty.
   * ---------------------------------------------------------- */
  function setNotifBadge(count) {
    _notifCount = (Number(count) > 0 && isFinite(count)) ? Math.floor(Number(count)) : 0;
    var badge = qs('#navBadge');
    if (!badge) return false;
    badge.textContent = format(_notifCount);
    return true;
  }

  /* ----------------------------------------------------------
   * SET INBOX BADGE
   * Writes the formatted value into #navInboxBadge.
   * ---------------------------------------------------------- */
  function setInboxBadge(count) {
    _inboxCount = (Number(count) > 0 && isFinite(count)) ? Math.floor(Number(count)) : 0;
    var badge = qs('#navInboxBadge');
    if (!badge) return false;
    badge.textContent = format(_inboxCount);
    return true;
  }

  /* ----------------------------------------------------------
   * updateInboxBadge(map)
   * Original name preserved. In the original source this
   * function read the module-scoped `unreadMap` directly and
   * computed the total. In the modular build the caller
   * passes the same map (or a pre-computed total) so this
   * module stays free of cross-module state.
   *
   * Two call signatures are supported for convenience:
   *
   *   updateInboxBadge()                → uses cached count
   *                                       (does nothing new)
   *   updateInboxBadge(unreadMapObject) → sums the values
   *                                       and writes the badge
   *   updateInboxBadge(number)          → treats as total
   * ---------------------------------------------------------- */
  function updateInboxBadge(arg) {
    /* 1) No argument → re-apply cached count -------------- */
    if (arg == null) {
      return setInboxBadge(_inboxCount);
    }

    /* 2) Numeric argument → treat as total ------------------ */
    if (typeof arg === 'number') {
      return setInboxBadge(arg);
    }

    /* 3) Object argument → sum its numeric values ----------- */
    if (typeof arg === 'object') {
      var total = 0;
      var keys = Object.keys(arg || {});
      for (var i = 0; i < keys.length; i++) {
        var v = Number(arg[keys[i]]);
        if (isFinite(v) && v > 0) total += v;
      }
      return setInboxBadge(total);
    }

    /* 4) Anything else → reset to 0 ------------------------ */
    return setInboxBadge(0);
  }

  /* ----------------------------------------------------------
   * CLEAR ALL
   * Empties both badges. Used by logout / teardown so the
   * next user does not briefly see stale counts.
   * ---------------------------------------------------------- */
  function clearAll() {
    setNotifBadge(0);
    setInboxBadge(0);
    return true;
  }

  /* ----------------------------------------------------------
   * GETTERS — read the cached counts (additive)
   * ---------------------------------------------------------- */
  function getNotifCount() { return _notifCount; }
  function getInboxCount() { return _inboxCount; }

  /* ----------------------------------------------------------
   * EVENT SUBSCRIBERS (additive)
   *
   * Feature 101 (notifications) and feature 113 (chat meta)
   * may prefer to fire CustomEvents instead of calling the
   * setters directly. We listen for both so either wiring
   * style works:
   *
   *   'saiko:notif-unread'   detail = { count }
   *   'saiko:inbox-unread'   detail = { count }
   *                         or { map: { chatId: n, … } }
   * ---------------------------------------------------------- */
  function onNotifUnread(e) {
    try {
      var d = e && e.detail;
      if (d && typeof d.count === 'number') setNotifBadge(d.count);
    } catch (err) {}
  }

  function onInboxUnread(e) {
    try {
      var d = e && e.detail;
      if (!d) return;
      if (typeof d.count === 'number') setInboxBadge(d.count);
      else if (d.map && typeof d.map === 'object') updateInboxBadge(d.map);
    } catch (err) {}
  }

  try {
    window.addEventListener('saiko:notif-unread', onNotifUnread);
    window.addEventListener('saiko:inbox-unread', onInboxUnread);
  } catch (e) {}

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so any existing caller of
   * updateInboxBadge() continues to work unchanged. */
  window.updateInboxBadge = updateInboxBadge;

  window.SaikoNavBadges = {
    setNotifBadge: setNotifBadge,
    setInboxBadge: setInboxBadge,
    updateInboxBadge: updateInboxBadge,
    clearAll: clearAll,
    getNotifCount: getNotifCount,
    getInboxCount: getInboxCount,
    format: format,
    MAX: MAX
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 050 — nav-badges ready');
  } catch (e) {}

})();