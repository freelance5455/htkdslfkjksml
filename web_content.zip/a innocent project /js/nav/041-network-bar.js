/* ============================================================
 * FEATURE:        Network Status Bar
 * FEATURE NUMBER: 041
 * FILE:           js/nav/041-network-bar.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the thin strip at the very top of the viewport
 *   (#netBar) that briefly slides down to inform the user
 *   about connectivity changes.
 *
 *   Two independent sources feed this bar:
 *
 *     1. BROWSER EVENTS
 *          window 'online'  / 'offline'
 *        Also runs one immediate check on bind in case the
 *        page was loaded while offline.
 *        Text:
 *          online  → t('network_back')
 *          offline → t('network_offline')
 *        Auto-hide after 2600 ms.
 *
 *     2. FIREBASE REALTIME DATABASE
 *          db.ref('.info/connected')
 *        First fire is SKIPPED (it just marks the listener as
 *        initialised). Subsequent fires:
 *          connected     → t('network_back')     + hide 2s
 *          disconnected  → t('reconnecting')     + persistent
 *        The persistent 'reconnecting' state is intentional:
 *        it stays visible until a 'back online' arrives.
 *
 *   Class toggles on #netBar:
 *     .show    → slide down (transform: translateY(0))
 *     .online  → green palette (var(--ok))
 *     missing  → amber palette (var(--warn))
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §32 NETWORK → the `networkSetup()` IIFE.
 *
 * DEPENDENCIES (loaded earlier):
 *   - t(key)     → js/nav/046-i18n.js
 *   - db         → js/core/firebase-init.js   (optional)
 *
 * DOM ELEMENTS USED:
 *   #netBar
 *
 * FIREBASE PATHS:
 *   .info/connected        (read + listen)
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoNetworkBar = {
 *     start, stop,
 *     show, hide,
 *     bind, unbind,
 *     isOnline,
 *     getBar
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — preserved from the original IIFE.
   * ---------------------------------------------------------- */
  var HIDE_MS_BROWSER  = 2600;   // window online/offline auto-hide
  var HIDE_MS_FIREBASE = 2000;   // firebase connected auto-hide

  /* ----------------------------------------------------------
   * Module state
   * ---------------------------------------------------------- */
  var _firebaseInited = false;   // mirrors the original `inited` flag
  var _hideTimer = null;
  var _connRef = null;
  var _connCb = null;
  var _browserBound = false;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  function getBar() { return qs('#netBar'); }

  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }

  /* ----------------------------------------------------------
   * HIDE TIMER
   * Centralised so the persistent-Firebase-disconnected path
   * can cancel any pending auto-hide scheduled by a previous
   * browser event.
   * ---------------------------------------------------------- */
  function clearHideTimer() {
    if (_hideTimer) {
      clearTimeout(_hideTimer);
      _hideTimer = null;
    }
  }

  function scheduleHide(ms) {
    clearHideTimer();
    _hideTimer = setTimeout(function () {
      _hideTimer = null;
      var bar = getBar();
      if (bar) bar.classList.remove('show');
    }, ms);
  }

  /* ----------------------------------------------------------
   * SHOW / HIDE
   * Shared primitives used by all callers.
   *
   *   show(text, isOnline, autoHideMs)
   *     - text      : label to set on the bar
   *     - isOnline  : when true adds `.online` (green palette),
   *                   when false removes it (amber palette)
   *     - autoHideMs: when a positive number, schedules the bar
   *                   to slide back up after that many ms.
   *                   Pass 0 (or omit) for a persistent bar
   *                   (used by the reconnecting state).
   * ---------------------------------------------------------- */
  function show(text, isOnline, autoHideMs) {
    var bar = getBar();
    if (!bar) return false;

    bar.textContent = text;

    if (isOnline) bar.classList.add('online');
    else          bar.classList.remove('online');

    bar.classList.add('show');

    if (autoHideMs && autoHideMs > 0) {
      scheduleHide(autoHideMs);
    } else {
      clearHideTimer();
    }
    return true;
  }

  function hide() {
    clearHideTimer();
    var bar = getBar();
    if (bar) bar.classList.remove('show');
  }

  /* ----------------------------------------------------------
   * isOnline — best-effort current state. Prefers the browser
   * signal since the Firebase flag is asynchronous.
   * ---------------------------------------------------------- */
  function isOnline() {
    try { return !!navigator.onLine; } catch (e) { return true; }
  }

  /* ----------------------------------------------------------
   * BROWSER ONLINE/OFFLINE HANDLER
   * Preserved 1:1 from the original `update()` function.
   * ---------------------------------------------------------- */
  function onBrowserNetworkChange() {
    var on = isOnline();
    show(
      on ? T('network_back') : T('network_offline'),
      on,
      HIDE_MS_BROWSER
    );
  }

  /* ----------------------------------------------------------
   * FIREBASE .info/connected HANDLER
   * Preserved 1:1 from the original `.info/connected` listener:
   *   - first fire → skip (just mark initialised)
   *   - disconnected → t('reconnecting') persistent amber
   *   - connected    → t('network_back') + green, 2s auto-hide
   * ---------------------------------------------------------- */
  function onFirebaseConnectedChange(snap) {
    /* Skip first fire — matches original `if(!inited){...}` */
    if (!_firebaseInited) {
      _firebaseInited = true;
      return;
    }

    var on = snap.val();

    if (!on) {
      /* Persistent reconnecting indicator ----------------- */
      show(T('reconnecting'), false, 0);
    } else {
      show(T('network_back'), true, HIDE_MS_FIREBASE);
    }
  }

  /* ----------------------------------------------------------
   * START
   * Attaches browser listeners + initial check + Firebase
   * listener. Idempotent via `_browserBound` and the firebase
   * ref guard.
   * ---------------------------------------------------------- */
  function start() {
    /* 1) Browser online/offline listeners ------------------ */
    if (!_browserBound) {
      window.addEventListener('online',  onBrowserNetworkChange);
      window.addEventListener('offline', onBrowserNetworkChange);
      _browserBound = true;
    }

    /* 2) Immediate check — mirrors original
     *    `if(!navigator.onLine) update();`
     *    Runs the notify path only when the page loaded
     *    offline. */
    if (!isOnline()) {
      onBrowserNetworkChange();
    }

    /* 3) Firebase .info/connected ------------------------- */
    var fbDb = getDB();
    if (fbDb && !_connRef) {
      try {
        _connRef = fbDb.ref('.info/connected');
        _connCb = _connRef.on('value', onFirebaseConnectedChange, function (err) {
          /* Listener errors are non-fatal; the browser
           * online/offline events still drive the bar. */
          console.warn('[network-bar] .info/connected error', err);
        });
      } catch (e) {
        _connRef = null;
        _connCb = null;
      }
    }

    return true;
  }

  /* ----------------------------------------------------------
   * STOP — detach every listener + clear timers
   * ---------------------------------------------------------- */
  function stop() {
    if (_browserBound) {
      window.removeEventListener('online',  onBrowserNetworkChange);
      window.removeEventListener('offline', onBrowserNetworkChange);
      _browserBound = false;
    }

    if (_connRef && _connCb) {
      try { _connRef.off('value', _connCb); } catch (e) {}
    }
    _connRef = null;
    _connCb = null;
    _firebaseInited = false;

    clearHideTimer();
    hide();

    return true;
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   *
   * This feature has no interactive controls, so `bind()` just
   * calls start(). Kept for API parity with the other feature
   * modules.
   * ---------------------------------------------------------- */
  function bind() { return start(); }
  function unbind() { return stop(); }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoNetworkBar = {
    start: start,
    stop: stop,
    show: show,
    hide: hide,
    bind: bind,
    unbind: unbind,
    isOnline: isOnline,
    getBar: getBar
  };

  /* ----------------------------------------------------------
   * AUTO-START
   * The original IIFE ran immediately when the script tag
   * executed. We keep that behaviour but wait for DOM ready
   * if the script is loaded in <head> — the browser listeners
   * are safe to attach immediately, but we delay the first
   * `update()` call (which needs #netBar) until the DOM is
   * available.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      start();
    }, { once: true });
  } else {
    start();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 041 — network-bar ready');
  } catch (e) {}

})();