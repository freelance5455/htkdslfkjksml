/* ============================================================
 * FEATURE:        Toast Notifications
 * FEATURE NUMBER: 042
 * FILE:           js/nav/042-toast.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the ephemeral toast notification system. A toast is
 *   a small card that appears above the bottom nav, plays a
 *   subtle entrance animation, holds for ~2.2 s, fades out
 *   over 0.3 s, then is removed from the DOM.
 *
 *   Public function (used by 40+ sibling modules):
 *     toast(message, kind)
 *       kind = ''       → neutral card
 *       kind = 'ok'     → green accent border/text
 *       kind = 'err'    → red   accent border/text
 *
 *   Behaviour preserved 1:1 from original §5 UTILITIES toast():
 *
 *     1. find #toastWrap; abort silently if missing
 *     2. create <div class="toast [kind]"> with textContent
 *        set to the raw message (NO HTML parsing — matches
 *        original; callers must pre-escape if needed)
 *     3. append to #toastWrap
 *     4. after 2200 ms → start fade-out via inline styles:
 *            opacity: 0
 *            transform: translateY(.5rem)
 *            transition: .3s
 *     5. after 2600 ms → remove the node from the DOM
 *
 *   Additional (additive, does NOT change original behaviour):
 *     • toast.ok(msg)          — shortcut for (msg, 'ok')
 *     • toast.err(msg)         — shortcut for (msg, 'err')
 *     • toast.clear()          — remove all currently visible
 *     • toast.count()          — number of live toasts
 *     • SaikoToast.on/off()    — subscribe/unsubscribe events
 *         'saiko:toast-shown'   { message, kind }
 *         'saiko:toast-removed' { message, kind }
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §5 UTILITIES → function toast(msg, kind) { … }
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure DOM, zero cross-module dependencies
 *
 * DOM ELEMENTS USED:
 *   #toastWrap  (container; static in index.html)
 *   .toast      (dynamic child)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.toast                  (original name preserved)
 *   window.SaikoToast = {
 *     show, ok, err, clear, count,
 *     on, off
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — preserved from the original source.
   * ---------------------------------------------------------- */
  var FADE_START_MS = 2200;   // when the fade-out begins
  var REMOVE_MS     = 2600;   // when the node is removed
  var FADE_DURATION = '.3s';  // transition duration string

  /* ----------------------------------------------------------
   * Module state
   * ---------------------------------------------------------- */
  var liveToasts = [];            // tracking list (additive)
  var listeners = new Set();      // 'saiko:toast-*' subscribers

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function getWrap() {
    return document.getElementById('toastWrap');
  }

  function emit(kind, payload) {
    listeners.forEach(function (fn) {
      try { fn(kind, payload); } catch (e) { console.warn(e); }
    });
    /* Also dispatch a CustomEvent on window for non-module code. */
    try {
      window.dispatchEvent(new CustomEvent(kind, { detail: payload }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * SHOW — the main entry point.
   * Preserved 1:1 from original §5 UTILITIES toast().
   * ---------------------------------------------------------- */
  function show(message, kind) {
    var wrap = getWrap();
    if (!wrap) return false;

    var el = document.createElement('div');
    el.className = 'toast' + (kind ? ' ' + kind : '');
    /* Preserved: original used textContent, NOT innerHTML.
     * This means toast() never renders HTML — callers who
     * need to show user-provided strings must pre-escape. */
    el.textContent = (message == null) ? '' : String(message);

    wrap.appendChild(el);

    /* Track for count()/clear() (additive; does not affect
     * the visual behaviour of the original). */
    var entry = { el: el, message: String(message || ''), kind: kind || '' };
    liveToasts.push(entry);

    /* Notify subscribers — additive event. */
    emit('saiko:toast-shown', { message: entry.message, kind: entry.kind });

    /* 1) Schedule the fade-out ------------------------------- */
    setTimeout(function () {
      try {
        el.style.opacity = '0';
        el.style.transform = 'translateY(.5rem)';
        el.style.transition = FADE_DURATION;
      } catch (e) {}
    }, FADE_START_MS);

    /* 2) Schedule the removal -------------------------------- */
    setTimeout(function () {
      try { if (el.parentNode) el.parentNode.removeChild(el); } catch (e) {}
      /* Remove from the tracking list --------------------- */
      var idx = liveToasts.indexOf(entry);
      if (idx !== -1) liveToasts.splice(idx, 1);
      emit('saiko:toast-removed', { message: entry.message, kind: entry.kind });
    }, REMOVE_MS);

    return true;
  }

  /* ----------------------------------------------------------
   * SHORTCUTS (additive)
   * ---------------------------------------------------------- */
  function ok(message)  { return show(message, 'ok'); }
  function err(message) { return show(message, 'err'); }

  /* ----------------------------------------------------------
   * CLEAR — remove every currently visible toast immediately.
   * Not present in the original; useful for logout / teardown
   * and for tests. Safe no-op when nothing is live.
   * ---------------------------------------------------------- */
  function clear() {
    var wrap = getWrap();
    if (wrap) {
      /* Remove every .toast child (including ones added by
       * other code paths we did not track). */
      var nodes = wrap.querySelectorAll('.toast');
      for (var i = 0; i < nodes.length; i++) {
        try { wrap.removeChild(nodes[i]); } catch (e) {}
      }
    }
    liveToasts.length = 0;
    return true;
  }

  /* ----------------------------------------------------------
   * COUNT — number of live toasts.
   * ---------------------------------------------------------- */
  function count() {
    return liveToasts.length;
  }

  /* ----------------------------------------------------------
   * SUBSCRIBERS
   * ---------------------------------------------------------- */
  function on(fn)  { if (typeof fn === 'function') listeners.add(fn); }
  function off(fn) { listeners.delete(fn); }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so every existing call site
   * (there are 40+ across the codebase) continues to work. */
  window.toast = show;

  /* Attach convenience shortcuts to the same function object so
   * `toast.ok('…')` and `toast.err('…')` work everywhere the
   * global is used, without introducing a second API surface. */
  window.toast.ok    = ok;
  window.toast.err   = err;
  window.toast.clear = clear;
  window.toast.count = count;

  window.SaikoToast = {
    show: show,
    ok: ok,
    err: err,
    clear: clear,
    count: count,
    on: on,
    off: off
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 042 — toast ready');
  } catch (e) {}

})();