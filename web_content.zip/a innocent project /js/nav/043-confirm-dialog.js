/* ============================================================
 * FEATURE:        Confirm Dialog
 * FEATURE NUMBER: 043
 * FILE:           js/nav/043-confirm-dialog.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Promise-based yes/no modal. Owns the #ovConfirm overlay
 *   (backdrop + .confirm-box card with #confirmTitle,
 *   #confirmText, #confirmYes, #confirmNo buttons).
 *
 *   Public function (used by ~30 sibling modules):
 *     confirmDialog(title, text) → Promise<boolean>
 *       • resolves true  → user tapped Yes
 *       • resolves false → user tapped No
 *
 *   Behaviour preserved 1:1 from original §5 UTILITIES
 *   confirmDialog():
 *
 *     1. New Promise; resolver captured.
 *     2. Set #confirmTitle.textContent = title
 *        Set #confirmText.textContent  = text || ''
 *     3. Add .open to #ovConfirm (slides/fades in via CSS).
 *     4. Attach 'click' handlers on #confirmYes / #confirmNo.
 *     5. On either tap:
 *          - remove .open from #ovConfirm
 *          - removeEventListener on BOTH buttons
 *          - resolve(value)
 *
 *   Safety additions (do NOT change original behaviour):
 *     • If any of the required DOM nodes are missing, resolve
 *       false immediately (prevents callers from hanging).
 *     • If confirmDialog is invoked again while a previous
 *       dialog is still open, the previous promise is
 *       resolved with false before the new one is set up
 *       (prevents an orphaned listener from firing later).
 *     • Escape key resolves false (accessibility bonus).
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §5 UTILITIES → function confirmDialog() { … }
 *     Section §11 NAV      → #ovConfirm markup (static HTML)
 *
 * DEPENDENCIES (loaded earlier):
 *   none — pure DOM
 *
 * DOM ELEMENTS USED:
 *   #ovConfirm, #confirmTitle, #confirmText,
 *   #confirmYes, #confirmNo
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.confirmDialog          (original name preserved)
 *   window.SaikoConfirmDialog = {
 *     show, isOpen, close,
 *     on, off
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qs(sel) { return document.querySelector(sel); }

  /* ----------------------------------------------------------
   * Module state — one active dialog at a time.
   * ---------------------------------------------------------- */
  var _activeResolve = null;      // resolver of the currently open dialog
  var _yesHandler = null;
  var _noHandler = null;
  var _keyHandler = null;
  var listeners = new Set();

  /* ----------------------------------------------------------
   * Emit helper — additive subscriber notification.
   * ---------------------------------------------------------- */
  function emit(kind, payload) {
    listeners.forEach(function (fn) {
      try { fn(kind, payload); } catch (e) { console.warn(e); }
    });
    try {
      window.dispatchEvent(new CustomEvent(kind, { detail: payload }));
    } catch (e) {}
  }

  /* ----------------------------------------------------------
   * TEARDOWN — detach listeners, remove .open, clear state.
   * Shared by the yes-path, no-path, escape-path, and the
   * "auto-dismiss previous" path.
   * ---------------------------------------------------------- */
  function teardown() {
    var yes = qs('#confirmYes');
    var no  = qs('#confirmNo');
    var ov  = qs('#ovConfirm');

    if (yes && _yesHandler) {
      try { yes.removeEventListener('click', _yesHandler); } catch (e) {}
    }
    if (no && _noHandler) {
      try { no.removeEventListener('click', _noHandler); } catch (e) {}
    }
    if (_keyHandler) {
      try { document.removeEventListener('keydown', _keyHandler); } catch (e) {}
    }
    if (ov) {
      try { ov.classList.remove('open'); } catch (e) {}
    }

    _yesHandler = null;
    _noHandler = null;
    _keyHandler = null;
  }

  /* ----------------------------------------------------------
   * SHOW — main entry point.
   * Preserved 1:1 from original confirmDialog().
   * ---------------------------------------------------------- */
  function show(title, text) {
    return new Promise(function (resolve) {
      /* 1) Auto-dismiss any previously open dialog ---------- */
      if (_activeResolve) {
        try { _activeResolve(false); } catch (e) {}
        teardown();
        _activeResolve = null;
        emit('saiko:confirm-replaced', { title: title, text: text });
      }

      /* 2) Locate required nodes ---------------------------- */
      var ov = qs('#ovConfirm');
      var titleEl = qs('#confirmTitle');
      var textEl  = qs('#confirmText');
      var yes = qs('#confirmYes');
      var no  = qs('#confirmNo');

      /* If the modal skeleton is not in the DOM, resolve
       * immediately so callers never hang. */
      if (!ov || !titleEl || !textEl || !yes || !no) {
        resolve(false);
        return;
      }

      /* 3) Populate content --------------------------------- */
      titleEl.textContent = (title == null) ? '' : String(title);
      textEl.textContent  = (text  == null) ? '' : String(text);

      /* 4) Show overlay ------------------------------------- */
      ov.classList.add('open');

      /* 5) Bind handlers ------------------------------------ */
      _yesHandler = function () { done(true); };
      _noHandler  = function () { done(false); };

      yes.addEventListener('click', _yesHandler);
      no.addEventListener('click', _noHandler);

      /* 6) Escape key → resolve false ----------------------- */
      _keyHandler = function (e) {
        if (e && e.key === 'Escape') {
          e.preventDefault();
          done(false);
        }
      };
      document.addEventListener('keydown', _keyHandler);

      /* 7) Stash resolver for auto-dismiss on next call ----- */
      _activeResolve = resolve;

      /* 8) Notify subscribers ------------------------------- */
      emit('saiko:confirm-opened', {
        title: String(title || ''),
        text: String(text || '')
      });

      /* --- internal completion routine --------------------- */
      function done(value) {
        var v = !!value;
        teardown();
        var r = _activeResolve;
        _activeResolve = null;
        emit('saiko:confirm-closed', { value: v });
        if (r) {
          try { r(v); } catch (e) {}
        }
      }
    });
  }

  /* ----------------------------------------------------------
   * isOpen — true when a dialog is currently awaiting an
   * answer.
   * ---------------------------------------------------------- */
  function isOpen() {
    return !!_activeResolve;
  }

  /* ----------------------------------------------------------
   * close — programmatic dismiss (resolves false).
   * Useful for logout / navigation teardown so pending
   * dialogs do not leak.
   * ---------------------------------------------------------- */
  function close() {
    if (_activeResolve) {
      var r = _activeResolve;
      teardown();
      _activeResolve = null;
      emit('saiko:confirm-closed', { value: false });
      try { r(false); } catch (e) {}
      return true;
    }
    return false;
  }

  /* ----------------------------------------------------------
   * SUBSCRIBERS
   * ---------------------------------------------------------- */
  function on(fn)  { if (typeof fn === 'function') listeners.add(fn); }
  function off(fn) { listeners.delete(fn); }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global name preserved — every caller in the
   * codebase (features 008, 058, 073, 084, 123, 224, 031,
   * 040, …) continues to work with no changes. */
  window.confirmDialog = show;

  window.SaikoConfirmDialog = {
    show: show,
    isOpen: isOpen,
    close: close,
    on: on,
    off: off
  };

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 043 — confirm-dialog ready');
  } catch (e) {}

})();