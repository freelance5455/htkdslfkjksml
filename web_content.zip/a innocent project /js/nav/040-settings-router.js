/* ============================================================
 * SETTINGS ROUTER — SELF-CONTAINED (Batch 11 fix)
 * FILE:   js/nav/040-settings-router.js
 * ACTION: REPLACE (Appearance + Language made bulletproof)
 * ============================================================ */

(function () {
  'use strict';

  /* ============ HELPERS ============ */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); }
    catch (e) { console.warn('[settings-router] safeCall:', name, e); }
    return undefined;
  }
  function safeToast(msg, kind) {
    try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {}
  }
  function askConfirm(t1, t2) {
    try { if (typeof window.confirmDialog === 'function') return window.confirmDialog(t1, t2); } catch (e) {}
    return Promise.resolve(true);
  }
  function askPrompt(t1, d, p) {
    try { if (typeof window.promptDialog === 'function') return window.promptDialog(t1, d, p); } catch (e) {}
    return Promise.resolve(null);
  }
  function getDB() { try { return window.db || null; } catch (e) { return null; } }
  function getAuth() { try { return window.auth || null; } catch (e) { return null; } }
  function getUid() { return window.myUid || null; }
  function getPrefs() { try { return window.prefs || {}; } catch (e) { return {}; } }
  function savePrefs() { try { if (typeof window.savePrefs === 'function') window.savePrefs(); } catch (e) {} }
  function applyPrefs() { try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {} }
  function avatarHTML(url, name, cls) {
    try { if (typeof window.avatarHTML === 'function') return window.avatarHTML(url, name, cls); }
    catch (e) {}
    var c = cls || 'av-88';
    var init = (name || '?').trim().charAt(0).toUpperCase() || '?';
    if (url) return '<img class="avatar ' + c + '" src="' + esc(url) + '" alt="">';
    return '<div class="avatar ' + c + '">' + esc(init) + '</div>';
  }
  function timeAgo(ts) { try { return window.timeAgo(ts); } catch (e) { return ''; } }
  function fmtDate(ts) { try { return window.fmtDate(ts); } catch (e) { return ''; } }

  /* ============ OVERLAY HELPERS ============ */
  function openOverlaySafe(id) {
    try {
      if (typeof window.openOverlay === 'function') { window.openOverlay(id); return; }
    } catch (e) {}
    var o = document.getElementById(id);
    if (o) o.classList.add('open');
  }
  function closeOverlaySafe(id) {
    try {
      if (typeof window.closeOverlay === 'function') { window.closeOverlay(id); return; }
    } catch (e) {}
    var o = document.getElementById(id);
    if (o) o.classList.remove('open');
  }

  /* ============================================================
   * FALLBACK DATA (used if external sources are missing)
   * ============================================================ */
  var FALLBACK_LANGS = [
    { code:'en', name:'English',    native:'English' },
    { code:'hi', name:'Hindi',      native:'हिन्दी' },
    { code:'es', name:'Spanish',    native:'Español' },
    { code:'fr', name:'French',     native:'Français' },
    { code:'de', name:'German',     native:'Deutsch' },
    { code:'pt', name:'Portuguese', native:'Português' },
    { code:'ru', name:'Russian',    native:'Русский' },
    { code:'ar', name:'Arabic',     native:'العربية' },
    { code:'zh', name:'Chinese',    native:'中文' },
    { code:'ja', name:'Japanese',   native:'日本語' },
    { code:'ko', name:'Korean',     native:'한국어' },
    { code:'id', name:'Indonesian', native:'Bahasa Indonesia' },
    { code:'tr', name:'Turkish',    native:'Türkçe' },
    { code:'bn', name:'Bengali',    native:'বাংলা' },
    { code:'ur', name:'Urdu',       native:'اردو' },
    { code:'it', name:'Italian',    native:'Italiano' },
    { code:'nl', name:'Dutch',      native:'Nederlands' },
    { code:'pl', name:'Polish',     native:'Polski' },
    { code:'th', name:'Thai',       native:'ไทย' },
    { code:'vi', name:'Vietnamese', native:'Tiếng Việt' },
    { code:'fa', name:'Persian',    native:'فارسی' },
    { code:'sw', name:'Swahili',    native:'Kiswahili' }
  ];

  var FALLBACK_PRESETS = [
    '#7c5cff','#2ecc8f','#ff5c6c','#3aa0ff','#ff9f43','#e84393',
    '#00cec9','#a55eea','#fdcb6e','#e17055','#0984e3','#fd79a8'
  ];

  function getLanguages() {
    try {
      if (typeof window.LANGUAGES !== 'undefined' &&
          Array.isArray(window.LANGUAGES) &&
          window.LANGUAGES.length) {
        return window.LANGUAGES;
      }
    } catch (e) {}
    return FALLBACK_LANGS;
  }

  /* ============================================================
   * PAGE RENDERERS
   * ============================================================ */

  /* ---------- ACCOUNT ---------- */
  function renderAccount() {
    var user = getAuth() && getAuth().currentUser;
    var email = (user && user.email) || '';
    return '<div class="sec-title">' + esc(T('account')) + '</div>' +
      '<div class="field"><label>' + esc(T('email')) + '</label>' +
        '<input class="input" id="accEmail" type="email" value="' + esc(email) + '"></div>' +
      '<button class="btn ghost block" id="accEmailBtn" style="margin-bottom:.8rem">' + esc(T('change_email')) + '</button>' +
      '<div class="field"><label>' + esc(T('password')) + '</label>' +
        '<input class="input" id="accPass" type="password" placeholder="••••••••"></div>' +
      '<button class="btn ghost block" id="accPassBtn">' + esc(T('change_password')) + '</button>' +
      '<button class="btn danger block" id="accLogout" style="margin-top:1.2rem">' + esc(T('logout')) + '</button>';
  }
  function wireAccount() {
    var emailBtn = qs('#accEmailBtn');
    if (emailBtn) emailBtn.addEventListener('click', async function () {
      var v = qs('#accEmail').value.trim();
      if (!v) { safeToast(T('fill_all'), 'err'); return; }
      try {
        await getAuth().currentUser.updateEmail(v);
        safeToast(T('email_changed'), 'ok');
      } catch (e) { safeToast(e.message || T('error'), 'err'); }
    });
    var passBtn = qs('#accPassBtn');
    if (passBtn) passBtn.addEventListener('click', async function () {
      var v = qs('#accPass').value;
      if (!v || v.length < 6) { safeToast(T('fill_all'), 'err'); return; }
      try {
        await getAuth().currentUser.updatePassword(v);
        qs('#accPass').value = '';
        safeToast(T('password_changed'), 'ok');
      } catch (e) { safeToast(e.message || T('error'), 'err'); }
    });
    var logoutBtn = qs('#accLogout');
    if (logoutBtn) logoutBtn.addEventListener('click', function () {
      safeCall('doLogout');
    });
  }

  /* ---------- PROFILE SETTINGS ---------- */
  function renderProfileSettings() {
    var p = window.myProfile || {};
    var bio = p.bio || '';
    return '<div class="prof-head" style="padding-top:.4rem">' +
        '<div id="psAvatar">' + avatarHTML(p.photo, p.name, 'av-88') + '</div>' +
        '<button class="btn sm ghost" id="psPhotoBtn">' + esc(T('change_photo')) + '</button>' +
        '<input type="file" id="psPhotoFile" accept="image/*" class="hidden">' +
      '</div>' +
      '<div class="field"><label>' + esc(T('name')) + '</label>' +
        '<input class="input" id="psName" maxlength="40" value="' + esc(p.name || '') + '"></div>' +
      '<div class="field"><label>' + esc(T('username')) + '</label>' +
        '<input class="input" id="psUser" maxlength="30" value="' + esc(p.username || '') + '"></div>' +
      '<div class="field"><label>' + esc(T('dob')) + '</label>' +
        '<input class="input" id="psDob" type="date" value="' + esc(p.dob || '') + '"></div>' +
      '<div class="field"><label>' + esc(T('relationship')) + '</label>' +
        '<input class="input" id="psRel" maxlength="40" value="' + esc(p.relationship || '') + '"></div>' +
      '<div class="field"><label>' + esc(T('bio')) + '</label>' +
        '<textarea class="input" id="psBio" maxlength="99">' + esc(bio) + '</textarea>' +
        '<div class="counter"><span id="bioCount">' + bio.length + '</span>/99</div></div>' +
      '<button class="btn solid block lg" id="psSave">' + esc(T('save_changes')) + '</button>';
  }
  function wireProfileSettings() {
    var bio = qs('#psBio');
    if (bio) bio.addEventListener('input', function () {
      if (bio.value.length > 99) bio.value = bio.value.slice(0, 99);
      qs('#bioCount').textContent = bio.value.length;
    });

    var photoBtn = qs('#psPhotoBtn');
    if (photoBtn) photoBtn.addEventListener('click', function () { qs('#psPhotoFile').click(); });

    var photoFile = qs('#psPhotoFile');
    if (photoFile) photoFile.addEventListener('change', async function (e) {
      var f = e.target.files && e.target.files[0];
      if (!f) return;
      try {
        safeToast(T('uploading'));
        var comp = f;
        if (typeof window.compressImage === 'function') comp = await window.compressImage(f, 600, 0.85);
        var url = null;
        if (typeof window.cloudinaryUpload === 'function') url = await window.cloudinaryUpload(comp, 'avatar.jpg');
        if (!url) throw new Error(T('upload_failed'));
        await getDB().ref('users/' + getUid() + '/photo').set(url);
        var w = qs('#psAvatar'); if (w) w.innerHTML = avatarHTML(url, window.myProfile.name, 'av-88');
        safeToast(T('saved'), 'ok');
      } catch (err) { safeToast(err.message || T('error'), 'err'); }
    });

    var saveBtn = qs('#psSave');
    if (saveBtn) saveBtn.addEventListener('click', async function () {
      var name = qs('#psName').value.trim();
      var username = qs('#psUser').value.trim();
      var dob = qs('#psDob').value;
      var rel = qs('#psRel').value.trim();
      var bio2 = qs('#psBio').value;

      if (!name) { safeToast(T('fill_all'), 'err'); return; }
      if (bio2.length < 1 || bio2.length > 99) { safeToast(T('fill_all'), 'err'); return; }

      saveBtn.disabled = true;
      try {
        await getDB().ref('users/' + getUid()).update({
          name: name,
          searchName: name.toLowerCase(),
          username: username,
          dob: dob,
          relationship: rel,
          bio: bio2,
          updatedAt: Date.now()
        });
        safeToast(T('saved'), 'ok');
        closeOverlaySafe('ovSettingPage');
        safeCall('renderProfilePage');
      } catch (e) { safeToast(e.message || T('error'), 'err'); }
      finally { saveBtn.disabled = false; }
    });
  }

  /* ---------- PRIVACY ---------- */
  function renderPrivacy() {
    var p = getPrefs();
    var sp = p.storyPrivacy === 'close' ? 'close' : 'public';
    return '<div class="sec-title">' + esc(T('privacy')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.showOnline ? 'active' : '') + '" id="pvOnline">' +
        esc(T('online_status_visibility')) + ': ' + esc(p.showOnline ? T('on') : T('off')) + '</button></div>' +
      '<div class="toggle-row"><button class="btn ' + (p.showLastSeen ? 'active' : '') + '" id="pvLastSeen">' +
        esc(T('last_seen_visibility')) + ': ' + esc(p.showLastSeen ? T('on') : T('off')) + '</button></div>' +
      '<div class="toggle-row"><button class="btn ' + (p.typingIndicator ? 'active' : '') + '" id="pvTyping">' +
        'Typing indicator: ' + esc(p.typingIndicator ? T('on') : T('off')) + '</button></div>' +
      '<div class="field"><label>' + esc(T('call_permission')) + '</label>' +
        '<select class="input" id="pvCallPerm">' +
          '<option value="everyone"' + (p.callPerm === 'everyone' ? ' selected' : '') + '>' + esc(T('everyone')) + '</option>' +
          '<option value="nobody"' + (p.callPerm === 'nobody' ? ' selected' : '') + '>' + esc(T('nobody')) + '</option>' +
        '</select></div>' +
      '<div class="field"><label>Story Privacy</label>' +
        '<select class="input" id="pvStoryPrivacy">' +
          '<option value="public"' + (sp === 'public' ? ' selected' : '') + '>' + esc(T('public')) + '</option>' +
          '<option value="close"' + (sp === 'close' ? ' selected' : '') + '>' + esc(T('close_friends')) + '</option>' +
        '</select></div>' +
      '<button class="btn solid block" id="pvSave">' + esc(T('save')) + '</button>';
  }
  function wirePrivacy() {
    function toggleBtn(id, key) {
      var btn = qs(id);
      if (!btn) return;
      btn.addEventListener('click', function () {
        var p = getPrefs();
        p[key] = !p[key];
        savePrefs();
        btn.classList.toggle('active', !!p[key]);
      });
    }
    toggleBtn('#pvOnline', 'showOnline');
    toggleBtn('#pvLastSeen', 'showLastSeen');
    toggleBtn('#pvTyping', 'typingIndicator');

    var save = qs('#pvSave');
    if (save) save.addEventListener('click', async function () {
      var p = getPrefs();
      p.callPerm = qs('#pvCallPerm').value;
      p.storyPrivacy = qs('#pvStoryPrivacy').value;
      savePrefs();
      try {
        if (getDB() && getUid()) {
          await getDB().ref('users/' + getUid() + '/privacy').set({
            showOnline: p.showOnline,
            showLastSeen: p.showLastSeen,
            callPerm: p.callPerm,
            typing: p.typingIndicator
          });
        }
      } catch (e) {}
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- NOTIFICATIONS ---------- */
  function renderNotifSettings() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('notification_settings')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.notifSound ? 'active' : '') + '" id="nsSound">' +
        esc(T('notification_settings')) + ': ' + esc(p.notifSound ? T('on') : T('off')) + '</button></div>' +
      '<button class="btn solid block" id="nsMarkAll" style="margin-top:1rem">' + esc(T('mark_all_read')) + '</button>';
  }
  function wireNotifSettings() {
    var s = qs('#nsSound');
    if (s) s.addEventListener('click', function () {
      var p = getPrefs(); p.notifSound = !p.notifSound; savePrefs();
      s.classList.toggle('active', p.notifSound);
      s.textContent = T('notification_settings') + ': ' + T(p.notifSound ? 'on' : 'off');
    });
    var m = qs('#nsMarkAll');
    if (m) m.addEventListener('click', function () {
      safeCall('markAllRead');
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- APPEARANCE (Batch 11 fix) ---------- */
  function renderAppearance() {
    var p = getPrefs();
    var accent = String(p.accent || '#7c5cff');
    var scale  = Number(p.scale);
    if (!isFinite(scale) || scale < 1) scale = 50;
    if (scale > 100) scale = 100;

    var swatchesHTML = FALLBACK_PRESETS.map(function (c) {
      var sel = (accent.toLowerCase() === c.toLowerCase()) ? ' sel' : '';
      return '<div class="swatch' + sel + '" data-c="' + c + '" style="background:' + c + '"></div>';
    }).join('');

    return '<div class="sec-title">' + esc(T('appearance')) + '</div>' +
      '<div class="swatches" id="swatches">' + swatchesHTML + '</div>' +
      '<div class="field"><label>Custom</label>' +
        '<input type="color" id="accentPick" value="' + esc(accent) + '"></div>' +
      '<button class="btn solid block" id="accentSave">' + esc(T('save')) + '</button>' +
      '<div class="sec-title" style="margin-top:1rem">' + esc(T('dark_mode')) + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (p.dark ? 'active' : '') + '" id="darkOn">' + esc(T('on')) + '</button>' +
        '<button class="btn ' + (!p.dark ? 'active' : '') + '" id="darkOff">' + esc(T('off')) + '</button>' +
      '</div>' +
      '<div class="sec-title">' + esc(T('ui_size')) + '</div>' +
      '<div style="text-align:center;font-weight:800;font-size:1.4rem" id="sizeVal">' + esc(String(scale)) + '%</div>' +
      '<input type="range" min="1" max="100" value="' + esc(String(scale)) + '" id="sizeRange">';
  }
  function wireAppearance() {
    /* Swatches ------------------------------------------------ */
    var swatchWrap = qs('#swatches');
    var pick = qs('#accentPick');

    if (swatchWrap) {
      qsa('.swatch', swatchWrap).forEach(function (s) {
        s.addEventListener('click', function () {
          try {
            var c = s.getAttribute('data-c');
            if (pick) pick.value = c;

            var p = getPrefs();
            p.accent = c;
            savePrefs();
            applyPrefs();

            qsa('#swatches .swatch').forEach(function (x) {
              x.classList.toggle('sel', x === s);
            });
          } catch (e) { console.warn('[settings-router] swatch click', e); }
        });
      });
    }

    /* Custom color picker ------------------------------------ */
    if (pick) {
      pick.addEventListener('input', function () {
        try {
          var p = getPrefs();
          p.accent = pick.value;
          applyPrefs();
        } catch (e) { console.warn('[settings-router] accent input', e); }
      });
    }

    /* Save button -------------------------------------------- */
    var saveBtn = qs('#accentSave');
    if (saveBtn) {
      saveBtn.addEventListener('click', function () {
        try {
          var p = getPrefs();
          if (pick) p.accent = pick.value;
          savePrefs();
          applyPrefs();
          safeToast(T('saved'), 'ok');
        } catch (e) { safeToast(T('error'), 'err'); }
      });
    }

    /* Dark mode toggles -------------------------------------- */
    var dOn = qs('#darkOn');
    if (dOn) {
      dOn.addEventListener('click', function () {
        try {
          var p = getPrefs();
          p.dark = true;
          savePrefs();
          applyPrefs();
          dOn.classList.add('active');
          var off = qs('#darkOff'); if (off) off.classList.remove('active');
        } catch (e) { console.warn('[settings-router] darkOn', e); }
      });
    }
    var dOff = qs('#darkOff');
    if (dOff) {
      dOff.addEventListener('click', function () {
        try {
          var p = getPrefs();
          p.dark = false;
          savePrefs();
          applyPrefs();
          dOff.classList.add('active');
          var on = qs('#darkOn'); if (on) on.classList.remove('active');
        } catch (e) { console.warn('[settings-router] darkOff', e); }
      });
    }

    /* UI scale slider ---------------------------------------- */
    var r = qs('#sizeRange');
    if (r) {
      r.addEventListener('input', function () {
        try {
          var p = getPrefs();
          p.scale = Number(r.value);
          var valEl = qs('#sizeVal'); if (valEl) valEl.textContent = p.scale + '%';
          applyPrefs();
          savePrefs();
        } catch (e) { console.warn('[settings-router] sizeRange', e); }
      });
    }
  }

  /* ---------- LANGUAGE (Batch 11 fix) ---------- */
  function renderLanguage() {
    var p = getPrefs();
    var langs = getLanguages();

    var rows = langs.map(function (l) {
      var isSel = (p.lang === l.code);
      var sel = isSel ? ' sel' : '';
      var mark = isSel ? '<span class="ic">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
        '<path d="m20 6-11 11-5-5"/></svg></span>' : '';
      return '<div class="lang-item' + sel + '" data-lang="' + esc(l.code) + '">' +
        '<span>' + esc(l.native) +
          ' <span class="muted" style="font-size:.75rem">(' + esc(l.name) + ')</span>' +
        '</span>' + mark +
      '</div>';
    }).join('');

    return '<div class="searchbar">' +
        '<span class="ic">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
          'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
          '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>' +
        '</span>' +
        '<input type="search" id="langSearch" placeholder="' + esc(T('search_language')) + '">' +
      '</div>' +
      '<div id="langList">' + rows + '</div>';
  }
  function wireLanguage() {
    /* Row clicks --------------------------------------------- */
    qsa('#langList [data-lang]').forEach(function (n) {
      n.addEventListener('click', function () {
        try {
          var code = n.getAttribute('data-lang');
          if (!code) return;

          var p = getPrefs();
          p.lang = code;
          savePrefs();

          try { if (typeof window.applyI18n === 'function') window.applyI18n(); } catch (e) {}
          try { if (typeof window.applyPrefs === 'function') window.applyPrefs(); } catch (e) {}

          safeToast(T('saved'), 'ok');

          /* Re-render this page so the .sel + ✓ state updates */
          openSettingPage('language');
        } catch (e) { console.warn('[settings-router] language row', e); }
      });
    });

    /* Search filter ----------------------------------------- */
    var s = qs('#langSearch');
    if (s) {
      s.addEventListener('input', function () {
        try {
          var q = s.value.toLowerCase();
          var langs = getLanguages();
          qsa('#langList [data-lang]').forEach(function (n) {
            var code = n.getAttribute('data-lang');
            var l = langs.find(function (x) { return x.code === code; });
            if (!l) return;
            n.style.display = (!q ||
              l.name.toLowerCase().indexOf(q) !== -1 ||
              l.native.toLowerCase().indexOf(q) !== -1) ? '' : 'none';
          });
        } catch (e) { console.warn('[settings-router] language search', e); }
      });
    }
  }

  /* ---------- CHAT SETTINGS ---------- */
  function renderChatSettings() {
    var p = getPrefs();
    var ad = p.autoDeleteMsgs || 'off';
    return '<div class="sec-title">' + esc(T('chat_settings')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.showReadReceipts ? 'active' : '') + '" id="csRead">' +
        esc(T('show_read_receipts')) + ': ' + esc(p.showReadReceipts ? T('on') : T('off')) + '</button></div>' +
      '<div class="toggle-row"><button class="btn ' + (p.enterToSend ? 'active' : '') + '" id="csEnter">' +
        esc(T('enter_to_send')) + ': ' + esc(p.enterToSend ? T('on') : T('off')) + '</button></div>' +
      '<div class="toggle-row"><button class="btn ' + (p.e2eEnabled ? 'active' : '') + '" id="csE2E">' +
        esc(T('e2e_encrypted')) + ': ' + esc(p.e2eEnabled ? T('on') : T('off')) + '</button></div>' +
      '<div class="field"><label>' + esc(T('auto_delete')) + '</label>' +
        '<select class="input" id="csAutoDel">' +
          '<option value="off"' + (ad === 'off' ? ' selected' : '') + '>' + esc(T('auto_delete_off')) + '</option>' +
          '<option value="86400000"' + (ad === '86400000' ? ' selected' : '') + '>24 hours</option>' +
          '<option value="604800000"' + (ad === '604800000' ? ' selected' : '') + '>7 days</option>' +
          '<option value="7776000000"' + (ad === '7776000000' ? ' selected' : '') + '>90 days</option>' +
        '</select></div>';
  }
  function wireChatSettings() {
    function toggleBtn(id, key, labelKey) {
      var btn = qs(id);
      if (!btn) return;
      btn.addEventListener('click', function () {
        var p = getPrefs();
        p[key] = !p[key];
        savePrefs();
        btn.classList.toggle('active', p[key]);
        btn.textContent = T(labelKey) + ': ' + T(p[key] ? 'on' : 'off');
      });
    }
    toggleBtn('#csRead',  'showReadReceipts', 'show_read_receipts');
    toggleBtn('#csEnter', 'enterToSend',      'enter_to_send');
    toggleBtn('#csE2E',   'e2eEnabled',       'e2e_encrypted');

    var ad = qs('#csAutoDel');
    if (ad) ad.addEventListener('change', function () {
      var p = getPrefs(); p.autoDeleteMsgs = ad.value; savePrefs();
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- CALL SETTINGS ---------- */
  function renderCallSettings() {
    return '<div class="sec-title">' + esc(T('call_settings')) + '</div>' +
      '<div class="card">' +
        '<div class="row" style="justify-content:space-between;padding:.3rem 0"><span class="muted">WebRTC</span><b>' + (window.RTCPeerConnection ? '✔' : '✖') + '</b></div>' +
        '<div class="row" style="justify-content:space-between;padding:.3rem 0"><span class="muted">getUserMedia</span><b>' + ((navigator.mediaDevices && navigator.mediaDevices.getUserMedia) ? '✔' : '✖') + '</b></div>' +
      '</div>' +
      '<button class="btn solid block" id="csHistory" style="margin-top:.6rem">' + esc(T('call_history')) + '</button>';
  }
  function wireCallSettings() {
    var h = qs('#csHistory');
    if (h) h.addEventListener('click', function () {
      closeOverlaySafe('ovSettingPage');
      safeCall('openCallHistory');
    });
  }

  /* ---------- STORIES ---------- */
  function renderStoriesSettings() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('stories')) + '</div>' +
      '<div class="field"><label>Default privacy</label>' +
        '<select class="input" id="stPriv">' +
          '<option value="public"' + (p.storyPrivacy !== 'close' ? ' selected' : '') + '>' + esc(T('public')) + '</option>' +
          '<option value="close"' + (p.storyPrivacy === 'close' ? ' selected' : '') + '>' + esc(T('close_friends')) + '</option>' +
        '</select></div>' +
      '<button class="btn solid block" id="stSave">' + esc(T('save')) + '</button>';
  }
  function wireStoriesSettings() {
    var s = qs('#stSave');
    if (s) s.addEventListener('click', function () {
      var p = getPrefs(); p.storyPrivacy = qs('#stPriv').value; savePrefs();
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- REELS ---------- */
  function renderReelsSettings() {
    return '<div class="sec-title">' + esc(T('reels')) + '</div>' +
      '<button class="btn ghost block" id="reelsHistBtn">' + esc(T('reels_history')) + '</button>' +
      '<button class="btn ghost block" id="reelsSaveBtn" style="margin-top:.5rem">' + esc(T('saved_reels')) + '</button>';
  }
  function wireReelsSettings() {
    var h = qs('#reelsHistBtn');
    if (h) h.addEventListener('click', function () {
      closeOverlaySafe('ovSettingPage');
      safeCall('openReelsHistory');
    });
    var s = qs('#reelsSaveBtn');
    if (s) s.addEventListener('click', function () {
      closeOverlaySafe('ovSettingPage');
      safeCall('openSaved');
    });
  }

  /* ---------- MEDIA ---------- */
  function renderMedia() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('media')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.autoDownload ? 'active' : '') + '" id="mdAuto">' +
        esc(T('auto_download_media')) + ': ' + esc(p.autoDownload ? T('on') : T('off')) + '</button></div>' +
      '<button class="btn ghost block" id="mdClear" style="margin-top:.8rem">' + esc(T('clear_cache')) + '</button>';
  }
  function wireMedia() {
    var a = qs('#mdAuto');
    if (a) a.addEventListener('click', function () {
      var p = getPrefs(); p.autoDownload = !p.autoDownload; savePrefs();
      a.classList.toggle('active', p.autoDownload);
      a.textContent = T('auto_download_media') + ': ' + T(p.autoDownload ? 'on' : 'off');
    });
    var c = qs('#mdClear');
    if (c) c.addEventListener('click', async function () {
      var ok = await askConfirm(T('clear_cache'), T('are_you_sure'));
      if (!ok) return;
      try {
        window.recentPlayed = []; localStorage.removeItem('saiko_recent_games');
        window.reelsHistory = []; localStorage.removeItem('saiko_reels_history');
        if ('caches' in window) {
          var keys = await caches.keys();
          await Promise.all(keys.map(function (k) { return caches.delete(k); }));
        }
      } catch (e) {}
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- DATA SAVER ---------- */
  function renderDataSaver() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('data_saver')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.dataSaver ? 'active' : '') + '" id="dsTog">' +
        esc(T('data_saver')) + ': ' + esc(p.dataSaver ? T('on') : T('off')) + '</button></div>';
  }
  function wireDataSaver() {
    var b = qs('#dsTog');
    if (b) b.addEventListener('click', function () {
      var p = getPrefs(); p.dataSaver = !p.dataSaver; savePrefs();
      b.classList.toggle('active', p.dataSaver);
      b.textContent = T('data_saver') + ': ' + T(p.dataSaver ? 'on' : 'off');
    });
  }

  /* ---------- BACKUP ---------- */
  function renderBackup() {
    return '<div class="sec-title">' + esc(T('backup')) + '</div>' +
      '<div class="card"><div class="mini">Export your profile, chats, and preferences as a JSON file.</div></div>' +
      '<button class="btn solid block" id="backupExport" style="margin-top:.6rem">' + esc(T('export_data')) + '</button>';
  }
  function wireBackup() {
    var b = qs('#backupExport');
    if (b) b.addEventListener('click', async function () {
      try {
        var snap = await getDB().ref('users/' + getUid()).get();
        var chatSnap = await getDB().ref('userChats/' + getUid()).get();
        var data = {
          exportedAt: new Date().toISOString(),
          uid: getUid(),
          profile: snap.val(),
          chats: chatSnap.val(),
          prefs: getPrefs()
        };
        var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = 'innocentsaiko-backup-' + Date.now() + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(function () { URL.revokeObjectURL(url); }, 3000);
        safeToast(T('saved_to_device'), 'ok');
      } catch (e) { safeToast(e.message || T('error'), 'err'); }
    });
  }

  /* ---------- STORAGE MANAGER ---------- */
  function renderStorage() {
    var total = 0;
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        var v = localStorage.getItem(k) || '';
        total += (k.length + v.length) * 2;
      }
    } catch (e) {}
    return '<div class="sec-title">' + esc(T('storage_manager')) + '</div>' +
      '<div class="card"><div class="row" style="justify-content:space-between">' +
        '<span class="muted">Used</span><b>' + (total / 1024).toFixed(1) + ' KB</b>' +
      '</div></div>' +
      '<button class="btn ghost block" id="stClear" style="margin-top:.6rem">Clear cache</button>' +
      '<button class="btn ghost block" id="stClearSeen" style="margin-top:.5rem">Clear seen stories</button>';
  }
  function wireStorage() {
    var c = qs('#stClear');
    if (c) c.addEventListener('click', async function () {
      var ok = await askConfirm('Clear cache', T('are_you_sure'));
      if (!ok) return;
      Object.keys(localStorage).forEach(function (k) {
        if (k.indexOf('saiko_reel_viewed_') === 0 || k.indexOf('saiko_recent_') === 0) {
          localStorage.removeItem(k);
        }
      });
      safeToast(T('saved'), 'ok');
      openSettingPage('storage_manager');
    });
    var cs = qs('#stClearSeen');
    if (cs) cs.addEventListener('click', function () {
      Object.keys(localStorage).forEach(function (k) {
        if (k.indexOf('saiko_story_seen_') === 0) localStorage.removeItem(k);
      });
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- BLOCKED USERS ---------- */
  function renderBlockedUsers() {
    var blocked = window.blockedUsers || {};
    var ids = Object.keys(blocked);
    if (!ids.length) {
      return '<div class="empty"><span class="ic"></span><p>' + esc(T('blocked_list_empty')) + '</p></div>';
    }
    return ids.map(function (uid) {
      var u = (typeof window.findUser === 'function' ? window.findUser(uid) : null) || { name: 'User', photo: '' };
      return '<div class="user-card">' +
        avatarHTML(u.photo, u.name, 'av-40') +
        '<div class="grow"><div class="name">' + esc(u.name) + '</div></div>' +
        '<button class="btn sm ghost" data-unblock="' + esc(uid) + '">' + esc(T('unblock')) + '</button>' +
      '</div>';
    }).join('');
  }
  function wireBlockedUsers() {
    qsa('[data-unblock]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var uid = b.getAttribute('data-unblock');
        try { await getDB().ref('blockedUsers/' + getUid() + '/' + uid).remove(); } catch (e) {}
        safeToast(T('unblocked'), 'ok');
        openSettingPage('blocked_users');
      });
    });
  }

  /* ---------- MUTED USERS ---------- */
  function renderMutedUsers() {
    var muted = window.mutedAuthors || {};
    var ids = Object.keys(muted);
    if (!ids.length) {
      return '<div class="empty"><span class="ic"></span><p>' + esc(T('no_data')) + '</p></div>';
    }
    return ids.map(function (uid) {
      var u = (typeof window.findUser === 'function' ? window.findUser(uid) : null) || { name: 'User', photo: '' };
      return '<div class="user-card">' +
        avatarHTML(u.photo, u.name, 'av-40') +
        '<div class="grow"><div class="name">' + esc(u.name) + '</div></div>' +
        '<button class="btn sm ghost" data-unmute="' + esc(uid) + '">' + esc(T('unmute_author')) + '</button>' +
      '</div>';
    }).join('');
  }
  function wireMutedUsers() {
    qsa('[data-unmute]').forEach(function (b) {
      b.addEventListener('click', async function () {
        var uid = b.getAttribute('data-unmute');
        try { await getDB().ref('mutedAuthors/' + getUid() + '/' + uid).remove(); } catch (e) {}
        safeToast(T('unmute_author'), 'ok');
        openSettingPage('muted_users');
      });
    });
  }

  /* ---------- APP LOCK ---------- */
  function renderAppLock() {
    var p = getPrefs();
    var on = !!p.appLock;
    return '<div class="sec-title">' + esc(T('app_lock')) + '</div>' +
      '<div class="card"><div class="mini">' + esc(T('app_lock_hint')) + '</div></div>' +
      '<button class="btn ' + (on ? 'danger' : 'solid') + ' block" id="alToggle" style="margin-top:.6rem">' +
        (on ? 'Remove PIN' : T('set_pin')) +
      '</button>';
  }
  function wireAppLock() {
    var btn = qs('#alToggle');
    if (!btn) return;
    btn.addEventListener('click', async function () {
      var p = getPrefs();
      if (p.appLock) {
        p.appLock = false; p.appLockPin = ''; savePrefs();
        safeToast(T('pin_removed'), 'ok');
        openSettingPage('app_lock');
        return;
      }
      var p1 = await askPrompt(T('set_pin'), '', '4 digits');
      if (!p1 || !/^\d{4}$/.test(p1)) { safeToast(T('wrong_pin'), 'err'); return; }
      var p2 = await askPrompt(T('confirm_pin'), '', '4 digits');
      if (p1 !== p2) { safeToast(T('wrong_pin'), 'err'); return; }
      p.appLock = true; p.appLockPin = p1; savePrefs();
      safeToast(T('pin_set'), 'ok');
      openSettingPage('app_lock');
    });
  }

  /* ---------- LOGIN ACTIVITY ---------- */
  function renderLoginActivity() {
    return '<div class="sec-title">' + esc(T('login_activity')) + '</div>' +
      '<div id="sessList"><div class="loading-row"><span class="spinner"></span>' + esc(T('loading')) + '</div></div>' +
      '<button class="btn danger block" id="logoutOther" style="margin-top:.8rem">' + esc(T('logout_other')) + '</button>';
  }
  function wireLoginActivity() {
    var box = qs('#sessList');
    if (!box || !getDB()) return;
    getDB().ref('userSessions/' + getUid()).get().then(function (s) {
      var v = s.val() || {};
      var mySess = null;
      try { mySess = sessionStorage.getItem('saiko_session_id'); } catch (e) {}
      var list = Object.keys(v).map(function (k) { return Object.assign({ id: k }, v[k]); })
                                 .sort(function (a, b) { return (b.last || 0) - (a.last || 0); });
      if (!list.length) { box.innerHTML = '<div class="mini">—</div>'; return; }
      box.innerHTML = list.map(function (x) {
        var current = x.id === mySess;
        return '<div class="session-item">' +
          '<span class="ic"></span>' +
          '<div class="grow">' +
            '<div style="font-weight:700;font-size:.82rem">' + (current ? 'This device' : esc(String(x.ua || '').slice(0, 40))) + '</div>' +
            '<div class="mini">' + esc(timeAgo(x.last)) + '</div>' +
          '</div>' +
        '</div>';
      }).join('');
    }).catch(function () {
      box.innerHTML = '<div class="mini">—</div>';
    });
    var lo = qs('#logoutOther');
    if (lo) lo.addEventListener('click', async function () {
      var ok = await askConfirm(T('logout_other'), T('are_you_sure'));
      if (!ok) return;
      var mySess = null;
      try { mySess = sessionStorage.getItem('saiko_session_id'); } catch (e) {}
      try {
        var snap = await getDB().ref('userSessions/' + getUid()).get();
        var v = snap.val() || {};
        var updates = {};
        Object.keys(v).forEach(function (k) {
          if (k !== mySess) updates['userSessions/' + getUid() + '/' + k] = null;
        });
        if (Object.keys(updates).length) await getDB().ref().update(updates);
      } catch (e) {}
      safeToast(T('saved'), 'ok');
    });
  }

  /* ---------- ACCESSIBILITY ---------- */
  function renderAccessibility() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('accessibility')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.reducedMotion ? 'active' : '') + '" id="acMotion">' +
        esc(T('reduced_motion')) + ': ' + esc(p.reducedMotion ? T('on') : T('off')) + '</button></div>';
  }
  function wireAccessibility() {
    var b = qs('#acMotion');
    if (b) b.addEventListener('click', function () {
      var p = getPrefs(); p.reducedMotion = !p.reducedMotion; savePrefs();
      b.classList.toggle('active', p.reducedMotion);
      b.textContent = T('reduced_motion') + ': ' + T(p.reducedMotion ? 'on' : 'off');
      applyPrefs();
    });
  }

  /* ---------- PERFORMANCE MODE ---------- */
  function renderPerformanceMode() {
    var p = getPrefs();
    return '<div class="sec-title">' + esc(T('performance_mode')) + '</div>' +
      '<div class="toggle-row"><button class="btn ' + (p.performanceMode ? 'active' : '') + '" id="pfTog">' +
        esc(T('performance_mode')) + ': ' + esc(p.performanceMode ? T('on') : T('off')) + '</button></div>';
  }
  function wirePerformanceMode() {
    var b = qs('#pfTog');
    if (b) b.addEventListener('click', function () {
      var p = getPrefs(); p.performanceMode = !p.performanceMode; savePrefs();
      b.classList.toggle('active', p.performanceMode);
      b.textContent = T('performance_mode') + ': ' + T(p.performanceMode ? 'on' : 'off');
    });
  }

  /* ---------- ADMIN LIST ---------- */
  function renderAdminList() {
    return '<div class="sec-title">' + esc(T('admin_list')) + '</div>' +
      '<div id="adminListBody"><div class="loading-row"><span class="spinner"></span>' + esc(T('loading')) + '</div></div>';
  }
  function wireAdminList() {
    var body = qs('#adminListBody');
    if (!body || !getDB()) return;
    getDB().ref('admins').get().then(function (s) {
      var v = s.val() || {};
      var ids = Object.keys(v);
      if (!ids.length) { body.innerHTML = '<div class="empty"><p>' + esc(T('no_data')) + '</p></div>'; return; }
      body.innerHTML = ids.map(function (uid) {
        var a = v[uid] || {};
        var u = (typeof window.findUser === 'function' ? window.findUser(uid) : null) || { name: a.name || 'Admin', photo: a.photo || '' };
        return '<div class="user-card">' +
          avatarHTML(u.photo, u.name, 'av-40') +
          '<div class="grow"><div class="name">' + esc(u.name || 'Admin') + '</div>' +
            '<div class="mini">' + esc(a.role || 'admin') + '</div></div>' +
        '</div>';
      }).join('');
    }).catch(function () { body.innerHTML = '<div class="empty"><p>' + esc(T('no_data')) + '</p></div>'; });
  }

  /* ---------- ADMIN ACTIVITY ---------- */
  function renderAdminActivity() {
    return '<div class="sec-title">' + esc(T('admin_activity')) + '</div>' +
      '<div id="adminActBody"><div class="loading-row"><span class="spinner"></span>' + esc(T('loading')) + '</div></div>';
  }
  function wireAdminActivity() {
    var body = qs('#adminActBody');
    if (!body || !getDB()) return;
    getDB().ref('adminActivity').orderByChild('createdAt').limitToLast(100).get().then(function (s) {
      var v = s.val() || {};
      var list = Object.keys(v).map(function (k) { return Object.assign({ id: k }, v[k]); })
                                 .sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });
      if (!list.length) { body.innerHTML = '<div class="empty"><p>' + esc(T('no_admin_activity')) + '</p></div>'; return; }
      body.innerHTML = list.map(function (l) {
        return '<div class="log-item">' +
          '<b>' + esc(l.name || 'User') + '</b> · ' + esc(l.action || '') +
          '<div class="tm">' + esc(timeAgo(l.createdAt)) + '</div>' +
        '</div>';
      }).join('');
    }).catch(function () { body.innerHTML = '<div class="empty"><p>' + esc(T('no_data')) + '</p></div>'; });
  }

  /* ---------- ABOUT ---------- */
  function renderAbout() {
    return '<div class="sec-title">' + esc(T('about')) + '</div>' +
      '<div class="card" style="text-align:center;padding:1.2rem">' +
        '<div class="brand-logo" style="margin:0 auto .6rem">' +
          '<img src="https://i.ibb.co/mFYtJvRL/file-0000000024f48211b152c5f12db975f9.png" alt="" class="logo-img">' +
        '</div>' +
        '<div style="font-weight:800;font-size:1rem">' + esc(T('app_name')) + '</div>' +
        '<div class="muted" style="margin-top:.2rem">' + esc(T('tagline')) + '</div>' +
        '<div class="muted" style="margin-top:.6rem">Version: 8.0.0</div>' +
        '<div class="muted" style="margin-top:.3rem">Developer: Innocent😗Saiko😈</div>' +
      '</div>';
  }
  function wireAbout() {}

  /* ============================================================
   * PAGE MAP
   * ============================================================ */
  var PAGE_MAP = {
    account:               { render: renderAccount,          wire: wireAccount },
    profile_settings:      { render: renderProfileSettings,  wire: wireProfileSettings },
    privacy:               { render: renderPrivacy,          wire: wirePrivacy },
    notification_settings: { render: renderNotifSettings,    wire: wireNotifSettings },
    appearance:            { render: renderAppearance,       wire: wireAppearance },
    language:              { render: renderLanguage,         wire: wireLanguage },
    chat_settings:         { render: renderChatSettings,     wire: wireChatSettings },
    call_settings:         { render: renderCallSettings,     wire: wireCallSettings },
    stories:               { render: renderStoriesSettings,  wire: wireStoriesSettings },
    reels:                 { render: renderReelsSettings,    wire: wireReelsSettings },
    media:                 { render: renderMedia,            wire: wireMedia },
    data_saver:            { render: renderDataSaver,        wire: wireDataSaver },
    backup:                { render: renderBackup,           wire: wireBackup },
    storage_manager:       { render: renderStorage,          wire: wireStorage },
    blocked_users:         { render: renderBlockedUsers,     wire: wireBlockedUsers },
    muted_users:           { render: renderMutedUsers,       wire: wireMutedUsers },
    app_lock:              { render: renderAppLock,          wire: wireAppLock },
    login_activity:        { render: renderLoginActivity,    wire: wireLoginActivity },
    accessibility:         { render: renderAccessibility,    wire: wireAccessibility },
    performance_mode:      { render: renderPerformanceMode,  wire: wirePerformanceMode },
    admin_list:            { render: renderAdminList,        wire: wireAdminList },
    admin_activity:        { render: renderAdminActivity,    wire: wireAdminActivity },
    about:                 { render: renderAbout,            wire: wireAbout }
  };

  /* ============================================================
   * MAIN ROUTER
   * ============================================================ */
  function openSettingPage(key) {
    if (!key) return false;

    console.debug('[settings-router] openSettingPage:', key);

    var titleEl = qs('#settingPageTitle');
    if (titleEl) {
      var label = T(key);
      titleEl.textContent = label || key;
    }

    var body = qs('#settingPageBody');
    if (!body) {
      console.warn('[settings-router] #settingPageBody not found');
      return false;
    }

    var entry = PAGE_MAP[key];
    if (!entry) {
      console.warn('[settings-router] no PAGE_MAP entry for:', key);
      body.innerHTML = '<div class="empty"><p>' + esc(T('error')) + '</p></div>';
      openOverlaySafe('ovSettingPage');
      return false;
    }

    try {
      var html = entry.render();
      body.innerHTML = (typeof html === 'string') ? html : '';
    } catch (e) {
      console.warn('[settings-router] render failed:', key, e);
      body.innerHTML = '<div class="empty"><p>' + esc(T('error')) + '</p></div>';
    }

    openOverlaySafe('ovSettingPage');

    try {
      if (typeof entry.wire === 'function') entry.wire();
    } catch (e) {
      console.warn('[settings-router] wire failed:', key, e);
    }

    try {
      window.dispatchEvent(new CustomEvent('saiko:setting-page-opened', {
        detail: { key: key }
      }));
    } catch (e) {}

    return true;
  }

  /* ============================================================
   * EXPORTS
   * ============================================================ */
  window.openSettingPage = openSettingPage;

  window.SaikoSettingsRouter = {
    open: openSettingPage,
    register: function (key, renderFn, wireFn) {
      if (!key || typeof renderFn !== 'function') return false;
      PAGE_MAP[key] = { render: renderFn, wire: wireFn || function () {} };
      return true;
    },
    has: function (key) { return Object.prototype.hasOwnProperty.call(PAGE_MAP, key); },
    keys: function () { return Object.keys(PAGE_MAP); },
    PAGE_MAP: PAGE_MAP
  };

  try {
    console.debug('[boot] settings-router (batch 11) ready — ' +
      Object.keys(PAGE_MAP).length + ' pages');
  } catch (e) {}
})();