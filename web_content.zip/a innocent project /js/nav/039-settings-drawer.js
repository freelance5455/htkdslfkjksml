/* ============================================================
 * FEATURE:        Settings Sidebar Drawer
 * FEATURE NUMBER: 039
 * FILE:           js/nav/039-settings-drawer.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the right-side settings drawer (#settingsSidebar) and
 *   its dimmed backdrop (#sidebarMask).
 *
 *   Responsibilities (preserved 1:1 from the original
 *   single-file build):
 *
 *     1. ITEM LIST
 *        Renders the exact ordered list of side-items:
 *          account, profile_settings, privacy,
 *          notification_settings, appearance, language,
 *          chat_settings, call_settings, stories, reels,
 *          media, data_saver, backup, storage_manager,
 *          blocked_users, muted_users, app_lock,
 *          login_activity, accessibility, performance_mode,
 *          [admin_list, admin_activity]  (admins only),
 *          about, logout
 *        Each entry uses the exact icon key from the original
 *        source (lock, user, shield, bell, palette, globe,
 *        chat, phone, eye, film, image, wifi, server, server,
 *        block, micOff, key, eye, eyeOff, star, shield, list,
 *        info, logout).
 *
 *     2. OPEN / CLOSE
 *        openSettingsSidebar()  → render + open + wire
 *        close()                → close drawer + mask
 *
 *     3. ITEM CLICK FLOW
 *        Close drawer + mask, then:
 *          • logout → window.doLogout() (feature 008)
 *          • any other key → after 180 ms,
 *                            window.openSettingPage(key)
 *                            (feature 040)
 *
 *     4. BACKDROP DISMISS
 *        Clicking #sidebarMask closes the drawer. The
 *        #sidebarClose (✕) button also closes it.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §11 NAV / §30 SETTINGS
 *       function openSettingsSidebar() { … }
 *       $('#sidebarMask').addEventListener('click', …)
 *
 * DEPENDENCIES (loaded earlier):
 *   - svgIcon(name)     → js/nav/045-icon-system.js
 *   - t(key)            → js/nav/046-i18n.js
 *   - esc(str)          → js/core/utils.js (local fallback)
 *   - myProfile         → js/auth/004-auth-state.js
 *   - window.doLogout   → js/auth/008-logout.js
 *   - window.openSettingPage → js/nav/040-settings-router.js
 *
 * DOM ELEMENTS USED:
 *   #settingsSidebar, #sidebarMask, #sidebarBody, #sidebarClose
 *   .side-item[data-set]
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.openSettingsSidebar   (original name preserved)
 *   window.SaikoSettingsDrawer = {
 *     ITEMS, ADMIN_ITEMS,
 *     open, close,
 *     render, bind, unbind,
 *     getItems, isOpen
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Items list — order and icon keys preserved byte-for-byte
   * from the original openSettingsSidebar() source.
   * ---------------------------------------------------------- */
  var ITEMS = [
    { k: 'account',               i: 'lock'    },
    { k: 'profile_settings',      i: 'user'    },
    { k: 'privacy',               i: 'shield'  },
    { k: 'notification_settings', i: 'bell'    },
    { k: 'appearance',            i: 'palette' },
    { k: 'language',              i: 'globe'   },
    { k: 'chat_settings',         i: 'chat'    },
    { k: 'call_settings',         i: 'phone'   },
    { k: 'stories',               i: 'eye'     },
    { k: 'reels',                 i: 'film'    },
    { k: 'media',                 i: 'image'   },
    { k: 'data_saver',            i: 'wifi'    },
    { k: 'backup',                i: 'server'  },
    { k: 'storage_manager',       i: 'server'  },
    { k: 'blocked_users',         i: 'block'   },
    { k: 'muted_users',           i: 'micOff'  },
    { k: 'app_lock',              i: 'key'     },
    { k: 'login_activity',        i: 'eye'     },
    { k: 'accessibility',         i: 'eyeOff'  },
    { k: 'performance_mode',      i: 'star'    }
  ];

  /* Admin-only items inserted between performance_mode and
   * about — exactly as the original spread operator did. */
  var ADMIN_ITEMS = [
    { k: 'admin_list',     i: 'shield' },
    { k: 'admin_activity', i: 'list'   }
  ];

  /* Trailing items — always present. */
  var TRAILING_ITEMS = [
    { k: 'about',  i: 'info'   },
    { k: 'logout', i: 'logout' }
  ];

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * SVG icon resolver — prefers the shared module, falls back
   * to an empty string so layout never breaks.
   * ---------------------------------------------------------- */
  function icon(name) {
    try {
      if (typeof window.svgIcon === 'function') return window.svgIcon(name);
    } catch (e) {}
    return '';
  }

  /* ----------------------------------------------------------
   * Safe optional-global invoker
   * ---------------------------------------------------------- */
  function safeCall(fnName, args) {
    try {
      var fn = window[fnName];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {
      console.warn('[settings-drawer] safeCall failed for', fnName, e);
    }
    return undefined;
  }

  /* ----------------------------------------------------------
   * Admin check — mirrors the original one-liner:
   *   myProfile && (myProfile.isAdmin === true ||
   *                 myProfile.admin === true)
   * ---------------------------------------------------------- */
  function isAdmin() {
    try {
      var p = (typeof window.myProfile !== 'undefined') ? window.myProfile : null;
      return !!(p && (p.isAdmin === true || p.admin === true));
    } catch (e) {
      return false;
    }
  }

  /* ----------------------------------------------------------
   * getItems — returns the current ordered list. Used both
   * for rendering and for external introspection (e.g. tests,
   * migration tools).
   * ---------------------------------------------------------- */
  function getItems() {
    var list = ITEMS.slice();
    if (isAdmin()) list = list.concat(ADMIN_ITEMS);
    list = list.concat(TRAILING_ITEMS);
    return list;
  }

  /* ----------------------------------------------------------
   * RENDER
   * Returns the exact HTML for one side-item:
   *
   *   <div class="side-item" data-set="<k>">
   *     <span class="ic">svgIcon(i)</span>
   *     <div class="grow" style="font-weight:650;font-size:.9rem">
   *       t(k) || k
   *     </div>
   *     <span class="ic" style="color:var(--muted)">arrow</span>
   *   </div>
   *
   * The label falls back to the raw key when i18n returns the
   * same key (i.e. no translation). This matches the original
   * `esc(t(it.k) || it.k)` expression.
   * ---------------------------------------------------------- */
  function renderItemHTML(it) {
    var label = T(it.k);
    if (!label) label = it.k;

    return (
      '<div class="side-item" data-set="' + esc(it.k) + '">' +
        '<span class="ic">' + icon(it.i) + '</span>' +
        '<div class="grow" style="font-weight:650;font-size:.9rem">' +
          esc(label) +
        '</div>' +
        '<span class="ic" style="color:var(--muted)">' + icon('arrow') + '</span>' +
      '</div>'
    );
  }

  function render() {
    var body = qs('#sidebarBody');
    if (!body) return false;
    var items = getItems();
    body.innerHTML = items.map(renderItemHTML).join('');
    return true;
  }

  /* ----------------------------------------------------------
   * ITEM CLICK FLOW
   * Preserved 1:1 from the original:
   *
   *   k = data-set
   *   close drawer + mask
   *   if k === 'logout' → doLogout() ; return
   *   setTimeout(() => openSettingPage(k), 180)
   * ---------------------------------------------------------- */
  function onItemClick(e) {
    var node = e.target && e.target.closest ? e.target.closest('[data-set]') : null;
    if (!node) return;
    var k = node.getAttribute('data-set');
    if (!k) return;

    /* 1) Close the drawer visually first ------------------- */
    close();

    /* 2) Route the click ----------------------------------- */
    if (k === 'logout') {
      safeCall('doLogout');
      return;
    }

    /* Small delay so the drawer close animation can finish
     * before the settings page opens — exactly 180 ms in the
     * original source. */
    setTimeout(function () {
      safeCall('openSettingPage', [k]);
    }, 180);
  }

  /* ----------------------------------------------------------
   * OPEN / CLOSE
   * ---------------------------------------------------------- */
  function open() {
    /* 1) Render fresh list (admin items depend on myProfile,
     *    which may have changed since last open) ------------ */
    render();

    /* 2) Wire item clicks (idempotent — the body is replaced
     *    every open, so delegation is attached on the body
     *    itself and never duplicated) ----------------------- */
    bind();

    /* 3) Open drawer + backdrop ---------------------------- */
    var side = qs('#settingsSidebar');
    if (side) side.classList.add('open');

    var mask = qs('#sidebarMask');
    if (mask) mask.classList.add('open');

    return true;
  }

  function close() {
    var side = qs('#settingsSidebar');
    if (side) side.classList.remove('open');

    var mask = qs('#sidebarMask');
    if (mask) mask.classList.remove('open');

    return true;
  }

  function isOpen() {
    var side = qs('#settingsSidebar');
    return !!(side && side.classList.contains('open'));
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   *
   * Two delegation layers:
   *   1. #sidebarBody  — delegated [data-set] click flow.
   *      Attached on the parent body which persists across
   *      re-renders, so a single listener covers every
   *      current and future side-item.
   *
   *   2. #sidebarMask  — backdrop click → close
   *      #sidebarClose — ✕ button click → close
   *
   * All three are idempotent via dataset guards.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var bound = false;

    /* 1) Item click flow (delegated on #sidebarBody) ------- */
    var body = qs('#sidebarBody', scope);
    if (body && body.dataset.settingsDrawerBound !== '1') {
      body.dataset.settingsDrawerBound = '1';
      body.addEventListener('click', onItemClick);
      bound = true;
    }

    /* 2) Backdrop dismiss ---------------------------------- */
    var mask = qs('#sidebarMask', scope);
    if (mask && mask.dataset.settingsDrawerBound !== '1') {
      mask.dataset.settingsDrawerBound = '1';
      mask.addEventListener('click', close);
      bound = true;
    }

    /* 3) Explicit ✕ close button --------------------------- */
    var closeBtn = qs('#sidebarClose', scope);
    if (closeBtn && closeBtn.dataset.settingsDrawerBound !== '1') {
      closeBtn.dataset.settingsDrawerBound = '1';
      closeBtn.addEventListener('click', close);
      bound = true;
    }

    return bound;
  }

  function unbind(root) {
    var scope = root || document;

    var body = qs('#sidebarBody', scope);
    if (body) {
      body.removeEventListener('click', onItemClick);
      delete body.dataset.settingsDrawerBound;
    }

    var mask = qs('#sidebarMask', scope);
    if (mask) {
      mask.removeEventListener('click', close);
      delete mask.dataset.settingsDrawerBound;
    }

    var closeBtn = qs('#sidebarClose', scope);
    if (closeBtn) {
      closeBtn.removeEventListener('click', close);
      delete closeBtn.dataset.settingsDrawerBound;
    }
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original name preserved — called from navigate('settings')
   * in feature 036 and from any other module that wants to
   * pop the drawer. */
  window.openSettingsSidebar = open;

  window.SaikoSettingsDrawer = {
    ITEMS: ITEMS.slice(),
    ADMIN_ITEMS: ADMIN_ITEMS.slice(),
    TRAILING_ITEMS: TRAILING_ITEMS.slice(),
    open: open,
    close: close,
    render: render,
    bind: bind,
    unbind: unbind,
    getItems: getItems,
    isOpen: isOpen
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * The mask and close button are static in index.html, so we
   * can safely bind their click handlers right away. The
   * sidebar body click delegation is attached on the first
   * open() — but if #sidebarBody already exists (it does in
   * index.html), binding here too is harmless and makes the
   * drawer responsive even before the first open() call.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 039 — settings-drawer ready');
  } catch (e) {}

})();