/* ============================================================
 * FEATURE:        Top Bar (Logo + Search Button)
 * FEATURE NUMBER: 037
 * FILE:           js/nav/037-topbar.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Owns the persistent top header (.topbar) and its two
 *   interactive responsibilities:
 *
 *     1. ICON MOUNTING
 *        Mounts the search icon on #btnSearch (the button
 *        itself is static HTML in index.html). The original
 *        buildNavIcons() mounted this icon; in the modular
 *        build feature 036 scopes icon-mounting to the
 *        bottom nav only, so this feature mounts its own
 *        topbar icon.
 *
 *     2. SEARCH OPEN FLOW
 *        Binds the #btnSearch click to the canonical search-
 *        overlay setup sequence:
 *          • openOverlay('ovSearch')
 *          • clear #globalSearchInput
 *          • reset searchTab to 'users'
 *          • refresh tab chip .sel classes to match
 *          • call showSearchIdle()      (feature 091/096)
 *          • call attachSearchListener() (feature 091)
 *          • focus #globalSearchInput after 250 ms
 *
 *   The topbar's logo (<div class="logo"> + <div class="mark">
 *   + <span id="appTitle">) is decorative in the original
 *   source — it has NO click handler. This module therefore
 *   does NOT bind any logo interaction; it only preserves the
 *   static markup via renderFragment() in case a caller wants
 *   to re-mount the header.
 *
 *   GLOBAL STATE — CROSS-MODULE:
 *     The original topbar click handler set `searchTab`
 *     (a module-scoped var in the search section). Dozens of
 *     search routines read it. We promote it to
 *     `window.searchTab` — the same pattern used for
 *     `window.currentNav` in feature 036. The search module
 *     (features 091–100) will read/write this global.
 *     An additive event 'saiko:topbar-search-opened' is
 *     emitted after the flow completes.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §11 NAV → topbar markup + buildNavIcons() set() call
 *     Section §14 USER CACHE / SEARCH → the #btnSearch click
 *                                       handler
 *
 * DEPENDENCIES (loaded earlier):
 *   - t(key)          → js/nav/046-i18n.js
 *   - svgIcon(name)   → js/nav/045-icon-system.js
 *   - esc(str)        → js/core/utils.js (local fallback)
 *   - openOverlay     → js/nav/038-overlay-system.js
 *   - showSearchIdle, attachSearchListener → search module
 *                                            (safely callable)
 *
 * DOM ELEMENTS USED:
 *   .topbar, .logo, .mark, #appTitle, #btnSearch
 *   #ovSearch, #globalSearchInput, #searchTabs, .chip[data-stab]
 *
 * FIREBASE PATHS:
 *   none directly — the search module handles Firebase reads.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoTopbar = {
 *     renderFragment,
 *     mountIcon,
 *     bind, unbind,
 *     openSearch,
 *     getSearchTab, setSearchTab
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants
   * ---------------------------------------------------------- */
  var DEFAULT_SEARCH_TAB = 'users';
  var FOCUS_DELAY_MS = 250;

  /* ----------------------------------------------------------
   * Local DOM helpers
   * ---------------------------------------------------------- */
  function qs(sel, root)  { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  /* ----------------------------------------------------------
   * i18n resolver
   * ---------------------------------------------------------- */
  function T(key) {
    try { if (typeof t === 'function') return t(key); } catch (e) {}
    return key;
  }

  /* ----------------------------------------------------------
   * HTML-escape helper (local fallback)
   * ---------------------------------------------------------- */
  function esc(str) {
    try { if (typeof window.esc === 'function') return window.esc(str); } catch (e) {}
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }

  /* ----------------------------------------------------------
   * Safe optional-global invoker
   * ---------------------------------------------------------- */
  function safeCall(fnName, args) {
    try {
      var fn = window[fnName];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {
      console.warn('[topbar] safeCall failed for', fnName, e);
    }
    return undefined;
  }

  /* ----------------------------------------------------------
   * GLOBAL SEARCH TAB STATE
   * Promoted from the original module-scoped `searchTab` so
   * the search module (features 091–100) and this topbar
   * module can share the same value without tight coupling.
   * ---------------------------------------------------------- */
  if (typeof window.searchTab !== 'string') {
    window.searchTab = DEFAULT_SEARCH_TAB;
  }

  function getSearchTab() {
    return (typeof window.searchTab === 'string')
      ? window.searchTab
      : DEFAULT_SEARCH_TAB;
  }

  function setSearchTab(tab) {
    if (typeof tab !== 'string' || !tab) return false;
    window.searchTab = tab;
    return true;
  }

  /* ----------------------------------------------------------
   * RENDER FRAGMENT
   * Returns the exact topbar markup that lives in index.html:
   *
   *   <header class="topbar">
   *     <div class="logo">
   *       <div class="mark"><img … class="logo-img"></div>
   *       <span id="appTitle">InnocentSaiko</span>
   *     </div>
   *     <button class="icon-btn" id="btnSearch" aria-label="Search"></button>
   *   </header>
   *
   * The logo image URL is resolved dynamically (LOGO_URL global
   * → <link rel="icon"> → hard-coded fallback) — same strategy
   * used by feature 014's splash-rebuild.
   * ---------------------------------------------------------- */
  function pickLogoUrl() {
    try {
      if (typeof window.LOGO_URL === 'string' && window.LOGO_URL) return window.LOGO_URL;
    } catch (e) {}
    try {
      var link = document.querySelector('link[rel="icon"]');
      if (link && link.href) return link.href;
    } catch (e) {}
    return 'https://i.ibb.co/mFYtJvRL/file-0000000024f48211b152c5f12db975f9.png';
  }

  function renderFragment() {
    var logo = pickLogoUrl();
    var title = T('app_name');

    return (
      '<header class="topbar">' +
        '<div class="logo">' +
          '<div class="mark">' +
            '<img src="' + esc(logo) + '" alt="" class="logo-img">' +
          '</div>' +
          '<span id="appTitle">' + esc(title) + '</span>' +
        '</div>' +
        '<button class="icon-btn" id="btnSearch" aria-label="Search"></button>' +
      '</header>'
    );
  }

  /* ----------------------------------------------------------
   * MOUNT ICON
   * Original buildNavIcons() mounted the search icon via
   *   set('#btnSearch','search')
   * which only ran when #btnSearch.innerHTML was empty. We
   * preserve that guard here.
   * ---------------------------------------------------------- */
  function mountIcon(root) {
    var scope = root || document;
    var btn = qs('#btnSearch', scope);
    if (!btn) return false;
    if (btn.innerHTML && btn.innerHTML.trim()) return true;
    if (typeof window.svgIcon !== 'function') return false;
    btn.innerHTML = window.svgIcon('search');
    return true;
  }

  /* ----------------------------------------------------------
   * OPEN SEARCH FLOW
   * Preserved 1:1 from the original #btnSearch click handler.
   * ---------------------------------------------------------- */
  function openSearch() {
    /* 1) Open the overlay ---------------------------------- */
    try {
      if (typeof window.openOverlay === 'function') {
        window.openOverlay('ovSearch');
      } else {
        var ov = document.getElementById('ovSearch');
        if (ov) ov.classList.add('open');
      }
    } catch (e) {}

    /* 2) Clear the input ----------------------------------- */
    var input = qs('#globalSearchInput');
    if (input) input.value = '';

    /* 3) Reset search tab to 'users' ----------------------- */
    setSearchTab(DEFAULT_SEARCH_TAB);
    qsa('#searchTabs .chip').forEach(function (c) {
      c.classList.toggle('sel', c.getAttribute('data-stab') === DEFAULT_SEARCH_TAB);
    });

    /* 4) Show idle state ----------------------------------- */
    safeCall('showSearchIdle');

    /* 5) Attach search listener ---------------------------- */
    safeCall('attachSearchListener');

    /* 6) Focus input after a short delay ------------------- */
    setTimeout(function () {
      var inp = qs('#globalSearchInput');
      if (inp && typeof inp.focus === 'function') {
        try { inp.focus(); } catch (e) {}
      }
    }, FOCUS_DELAY_MS);

    /* 7) Notify subscribers -------------------------------- */
    try {
      window.dispatchEvent(new CustomEvent('saiko:topbar-search-opened', {
        detail: { tab: DEFAULT_SEARCH_TAB }
      }));
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * BIND / UNBIND
   * Wires #btnSearch click. Idempotent via dataset guard.
   * Also mounts the search icon on bind.
   * ---------------------------------------------------------- */
  function bind(root) {
    var scope = root || document;
    var btn = qs('#btnSearch', scope);

    /* Mount icon even if the button itself is not yet bindable
     * (e.g. this file loaded before topbar HTML exists). */
    mountIcon(scope);

    if (!btn) return false;
    if (btn.dataset.topbarBound === '1') return true;
    btn.dataset.topbarBound = '1';

    btn.addEventListener('click', openSearch);
    return true;
  }

  function unbind(root) {
    var scope = root || document;
    var btn = qs('#btnSearch', scope);
    if (!btn) return;
    btn.removeEventListener('click', openSearch);
    delete btn.dataset.topbarBound;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoTopbar = {
    renderFragment: renderFragment,
    mountIcon: mountIcon,
    bind: bind,
    unbind: unbind,
    openSearch: openSearch,
    getSearchTab: getSearchTab,
    setSearchTab: setSearchTab
  };

  /* ----------------------------------------------------------
   * AUTO-BIND
   * Topbar lives in index.html so it exists at parse time.
   * Auto-bind for consistency with the other feature modules.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      bind();
    }, { once: true });
  } else {
    bind();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 037 — topbar ready');
  } catch (e) {}

})();