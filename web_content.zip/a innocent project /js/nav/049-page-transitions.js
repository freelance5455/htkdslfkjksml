/* ============================================================
 * FEATURE:        Page Transitions
 * FEATURE NUMBER: 049
 * FILE:           js/nav/049-page-transitions.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Provides programmatic control over the fade + slide
 *   animation used when switching between the five top-level
 *   pages (home, inbox, games, notifications, profile) that
 *   live inside `.pages #pagesRoot`.
 *
 *   In the original single-file build this animation was
 *   purely CSS-driven via:
 *
 *       .page { animation: fade .28s ease; }
 *       @keyframes fade {
 *         from { opacity: 0; transform: translateY(.5rem); }
 *         to   { opacity: 1; transform: none; }
 *       }
 *
 *   Every time a page was revealed (removing the `.hidden`
 *   class), the browser replayed the CSS animation because
 *   the `.page` selector matched the newly-visible node.
 *
 *   In the modular build the same CSS still lives in
 *   `css/shell/pages.css`, but having a JS helper lets us:
 *
 *     • Force-restart the animation when a page is re-shown
 *       without ever being hidden (e.g. `navigate('home')`
 *       called while already on home).
 *     • Optionally wait for the fade-out to finish before
 *       swapping `.hidden`, giving a smooth in/out feel.
 *     • Inject the keyframes + `.page` rule as a fallback if
 *       the CSS module has not been loaded yet (so the
 *       transition still works during early migration).
 *
 *   NOTE ON BEHAVIOUR PARITY:
 *     The original source did NOT have a fade-out phase; the
 *     old page simply became `.hidden` and the new page's
 *     fade-in played on top of the swap. To remain byte-for-
 *     byte behaviour-compatible, `runIn()` and `swap()`
 *     default to the ORIGINAL instantaneous swap and only
 *     replay the fade-in. An opt-in `runOutAndIn()` helper is
 *     provided for callers who explicitly want a two-phase
 *     transition; nothing in the app uses it by default.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §11 NAV → `.page` animation in the <style> block
 *     Section §11 NAV → navigate() toggles `.hidden`
 *
 * DEPENDENCIES (loaded earlier):
 *   none  (pure DOM + CSS keyframes; runs with or without the
 *          external stylesheet)
 *
 * DOM ELEMENTS USED:
 *   .page             (all five top-level page sections)
 *   #pagesRoot        (container — used for scoping)
 *
 * FIREBASE PATHS:
 *   none
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.SaikoPageTransitions = {
 *     runIn, runOut, swap, runOutAndIn,
 *     restart, hideAll, getPages,
 *     injectCSS, DURATION_MS
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — match the original CSS timings.
   * ---------------------------------------------------------- */
  var DURATION_MS = 280;   /* .page { animation: fade .28s ease } */
  var EASING      = 'ease';
  var TRANSLATE_Y = '.5rem';

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function qsa(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }

  /* ----------------------------------------------------------
   * getPages() — return every .page node inside #pagesRoot.
   * Falls back to a document-wide query if the container is
   * missing (defensive).
   * ---------------------------------------------------------- */
  function getPages() {
    var root = document.getElementById('pagesRoot');
    if (root) return qsa('.page', root);
    return qsa('.page');
  }

  /* ----------------------------------------------------------
   * injectCSS()
   * Adds the original keyframes + `.page` rule to the document
   * head ONLY if they are not already present. This keeps the
   * animation working when the external stylesheet has not
   * loaded yet, and is a no-op once the real CSS is in place.
   *
   * The injected rule intentionally matches the original
   * declaration byte-for-byte.
   * ---------------------------------------------------------- */
  var _cssInjected = false;
  function injectCSS() {
    if (_cssInjected) return false;
    if (document.getElementById('__saiko_page_transitions')) return false;

    var style = document.createElement('style');
    style.id = '__saiko_page_transitions';
    style.textContent =
      '.page{animation:fade ' + (DURATION_MS / 1000) + 's ' + EASING + ';}' +
      '@keyframes fade{from{opacity:0;transform:translateY(' + TRANSLATE_Y + ');}to{opacity:1;transform:none;}}';

    (document.head || document.documentElement).appendChild(style);
    _cssInjected = true;
    return true;
  }

  /* ----------------------------------------------------------
   * restart(pageEl)
   * Forces the browser to replay the fade animation on a
   * single page element by removing the animation, forcing a
   * reflow, and re-adding it. This is the trick that lets us
   * replay the animation on a page that was never `.hidden`.
   *
   * No-op if `pageEl` is missing or not a `.page`.
   * ---------------------------------------------------------- */
  function restart(pageEl) {
    if (!pageEl || !pageEl.classList || !pageEl.classList.contains('page')) {
      return false;
    }
    try {
      /* 1) Suspend the animation ---------------------------- */
      pageEl.style.animation = 'none';
      /* 2) Force reflow so the browser registers the change - */
      /* eslint-disable-next-line no-unused-expressions */
      void pageEl.offsetHeight;
      /* 3) Resume the stylesheet animation ------------------ */
      pageEl.style.animation = '';
    } catch (e) {
      return false;
    }
    return true;
  }

  /* ----------------------------------------------------------
   * runIn(pageEl)
   * Reveal a page by removing `.hidden`, then replay the
   * fade-in animation. This mirrors the original swap where
   * navigate() removed `.hidden` and the CSS animation played
   * automatically on the newly-visible node.
   *
   * Runs even if `injectCSS()` has never been called, since
   * the external stylesheet usually provides the animation.
   * ---------------------------------------------------------- */
  function runIn(pageEl) {
    if (!pageEl) return false;
    try {
      pageEl.classList.remove('hidden');
    } catch (e) {
      return false;
    }
    restart(pageEl);
    return true;
  }

  /* ----------------------------------------------------------
   * runOut(pageEl)
   * Hide a page by adding `.hidden`. Matches the original
   * instantaneous hide — no fade-out phase.
   * ---------------------------------------------------------- */
  function runOut(pageEl) {
    if (!pageEl) return false;
    try {
      pageEl.classList.add('hidden');
    } catch (e) {
      return false;
    }
    return true;
  }

  /* ----------------------------------------------------------
   * swap(fromEl, toEl)
   * Convenience: hide `fromEl`, reveal `toEl` with a fade-in.
   * This is the shape feature 036 (bottom nav) uses every time
   * navigate() is called. It preserves the original timing
   * exactly — both class toggles happen in the same frame.
   * ---------------------------------------------------------- */
  function swap(fromEl, toEl) {
    if (fromEl && fromEl !== toEl) runOut(fromEl);
    if (toEl) runIn(toEl);
    return true;
  }

  /* ----------------------------------------------------------
   * runOutAndIn(fromEl, toEl, onDone)
   * OPT-IN two-phase transition. Fades the outgoing page out
   * over DURATION_MS / 2, then swaps `.hidden` and fades the
   * incoming page in.
   *
   * Not used by any default code path — provided for callers
   * that explicitly want a smoother transition. Falls through
   * to the instantaneous swap if anything goes wrong.
   * ---------------------------------------------------------- */
  function runOutAndIn(fromEl, toEl, onDone) {
    /* Defensive: if `fromEl` is missing, just run the
     * incoming page (matches swap semantics). */
    if (!fromEl || fromEl === toEl) {
      if (toEl) runIn(toEl);
      if (typeof onDone === 'function') {
        try { onDone(); } catch (e) {}
      }
      return true;
    }

    var half = Math.max(1, Math.round(DURATION_MS / 2));

    try {
      /* 1) Fade out ----------------------------------------- */
      fromEl.style.transition = 'opacity ' + (half / 1000) + 's ' + EASING +
                                ', transform ' + (half / 1000) + 's ' + EASING;
      fromEl.style.opacity = '0';
      fromEl.style.transform = 'translateY(' + TRANSLATE_Y + ')';
    } catch (e) {
      /* If inline styling fails, fall back to the simple swap. */
      return swap(fromEl, toEl);
    }

    /* 2) After half-duration, hide + reveal ---------------- */
    setTimeout(function () {
      try {
        fromEl.style.transition = '';
        fromEl.style.opacity = '';
        fromEl.style.transform = '';
      } catch (e) {}

      runOut(fromEl);
      if (toEl) runIn(toEl);

      if (typeof onDone === 'function') {
        try { onDone(); } catch (e) {}
      }
    }, half);

    return true;
  }

  /* ----------------------------------------------------------
   * hideAll()
   * Adds `.hidden` to every `.page`. Mirrors the state
   * navigate() leaves behind when the target page does not
   * exist yet (e.g. boot before any renderer has run).
   * ---------------------------------------------------------- */
  function hideAll() {
    getPages().forEach(function (p) {
      try { p.classList.add('hidden'); } catch (e) {}
    });
    return true;
  }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */
  window.SaikoPageTransitions = {
    runIn: runIn,
    runOut: runOut,
    swap: swap,
    runOutAndIn: runOutAndIn,
    restart: restart,
    hideAll: hideAll,
    getPages: getPages,
    injectCSS: injectCSS,
    DURATION_MS: DURATION_MS
  };

  /* ----------------------------------------------------------
   * AUTO-INJECT
   * Ensure the fade keyframes are present even if the
   * external stylesheet has not loaded yet. No-op once the
   * real CSS is in place.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectCSS, { once: true });
  } else {
    injectCSS();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 049 — page-transitions ready');
  } catch (e) {}

})();