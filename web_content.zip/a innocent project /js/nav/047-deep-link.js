/* ============================================================
 * FEATURE:        Deep Link Handling
 * FEATURE NUMBER: 047
 * FILE:           js/nav/047-deep-link.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Parses the URL hash and routes the user to the correct
 *   in-app destination. Supported hash forms (all preset by
 *   the original source):
 *
 *     #u-<uid>          → openUserProfile(uid)
 *     #post-<postId>    → openPostSplit(postId)
 *     #reel-<reelId>    → openReels(reelId)
 *     #tag-<hashtag>    → openHashtag(tag)
 *
 *   Behaviour preserved 1:1 from original §34 DEEP LINK:
 *
 *     handleHash():
 *       - read location.hash
 *       - switch on the prefix
 *       - setTimeout(targetFn, 600) so the app has time to
 *         boot before the destination opens
 *       - self-close guard: #u-<myUid> is ignored (would
 *         otherwise trigger navigate('profile') from inside
 *         openUserProfile, which is fine, but the original
 *         skip keeps behaviour stable)
 *
 *   Triggers:
 *     1. On script load — one initial check (mirrors the
 *        original `setTimeout(handleHash, 800)` called from
 *        the boot IIFE; here we schedule that same 800 ms
 *        first-run kick ourselves).
 *     2. On every 'hashchange' event — so links shared while
 *        the app is already running are honoured live.
 *
 *   ORIGINAL LOCATION (index.html):
 *     Section §34 DEEP LINK → function handleHash() { … }
 *     Section §35 BOOT      → setTimeout(handleHash, 800)
 *     Section §35 BOOT      → window.addEventListener(
 *                              'hashchange', handleHash)
 *
 * DEPENDENCIES (loaded earlier):
 *   - openUserProfile   → js/profile/*       (safely-called)
 *   - openPostSplit     → js/feed/067-post-split.js
 *                                            (safely-called)
 *   - openReels         → js/reels/211-reels-feed.js
 *                                            (safely-called)
 *   - openHashtag       → js/feed/080-hashtag-open.js
 *                                            (safely-called)
 *   - myUid             → js/auth/004-auth-state.js
 *
 * DOM ELEMENTS USED:
 *   none  (all routing is done via globally exposed helpers)
 *
 * FIREBASE PATHS:
 *   none directly — the destination helpers own their data.
 *
 * localStorage  : none
 * sessionStorage: none
 * IndexedDB     : none
 *
 * EXPORTS (global):
 *   window.handleHash              (original name preserved)
 *   window.SaikoDeepLink = {
 *     handle, parse, start, stop,
 *     isRunning
 *   }
 * ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
   * Constants — preserved from the original source.
   * ---------------------------------------------------------- */
  var INITIAL_DELAY_MS = 800;   // boot kick (original §35)
  var ROUTE_DELAY_MS   = 600;   // per-route dispatch (original §34)

  /* ----------------------------------------------------------
   * Module state
   * ---------------------------------------------------------- */
  var _hashListener = null;
  var _bootTimer = null;
  var _started = false;

  /* ----------------------------------------------------------
   * Local helpers
   * ---------------------------------------------------------- */
  function safeCall(fnName, args) {
    try {
      var fn = window[fnName];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) {
      console.warn('[deep-link] safeCall failed:', fnName, e);
    }
    return undefined;
  }

  function getMyUid() {
    try {
      return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null;
    } catch (e) { return null; }
  }

  /* ----------------------------------------------------------
   * PARSE — extract { type, value } from the current hash.
   * Returns null when the hash does not match any known route.
   *
   * Kept pure so callers can introspect what the current URL
   * would route to (useful for tests and future analytics).
   * ---------------------------------------------------------- */
  function parse(hash) {
    var h = (typeof hash === 'string') ? hash : (location.hash || '');

    if (h.indexOf('#u-') === 0) {
      var uid = h.slice(3);
      if (uid) return { type: 'user', value: uid };
    }

    if (h.indexOf('#post-') === 0) {
      var pid = h.slice(6);
      if (pid) return { type: 'post', value: pid };
    }

    if (h.indexOf('#reel-') === 0) {
      var rid = h.slice(6);
      if (rid) return { type: 'reel', value: rid };
    }

    if (h.indexOf('#tag-') === 0) {
      var tag = h.slice(5);
      if (tag) return { type: 'hashtag', value: tag };
    }

    return null;
  }

  /* ----------------------------------------------------------
   * HANDLE — main entry point.
   * Preserved 1:1 from original handleHash().
   *
   * The setTimeout(ROUTE_DELAY_MS) delay is intentional —
   * the destination overlays (profile, post split, reels,
   * hashtag) call into their own modules that need a moment
   * to be ready after a cold boot or after the current
   * overlay teardown settles.
   * ---------------------------------------------------------- */
  function handle() {
    var route = parse();
    if (!route) return false;

    /* #u-<myUid> — the original skipped self-profile deep
     * links because the app is already showing them (or
     * because openUserProfile itself would bounce to the
     * profile tab). Preserve that guard. */
    if (route.type === 'user') {
      var me = getMyUid();
      if (me && route.value === me) return false;
    }

    /* Dispatch via setTimeout so the app has time to settle
     * before we pop an overlay. Matches the original timing
     * exactly. */
    setTimeout(function () {
      switch (route.type) {
        case 'user':    safeCall('openUserProfile', [route.value]); break;
        case 'post':    safeCall('openPostSplit',   [route.value]); break;
        case 'reel':    safeCall('openReels',       [route.value]); break;
        case 'hashtag': safeCall('openHashtag',     [route.value]); break;
        default: break;
      }
    }, ROUTE_DELAY_MS);

    return true;
  }

  /* ----------------------------------------------------------
   * START — attach hashchange listener + one initial boot kick
   * ---------------------------------------------------------- */
  function start() {
    if (_started) return true;
    _started = true;

    /* 1) Live hashchange routing --------------------------- */
    _hashListener = function () { handle(); };
    try {
      window.addEventListener('hashchange', _hashListener);
    } catch (e) {
      _hashListener = null;
      _started = false;
      return false;
    }

    /* 2) Initial boot kick --------------------------------- *
     * Original scheduled setTimeout(handleHash, 800) from the
     * boot IIFE. We replicate that here so the file is
     * self-sufficient — no external caller needs to remember
     * to kick the first hash parse.
     * ------------------------------------------------------ */
    try {
      _bootTimer = setTimeout(function () {
        _bootTimer = null;
        handle();
      }, INITIAL_DELAY_MS);
    } catch (e) {}

    return true;
  }

  /* ----------------------------------------------------------
   * STOP — detach the listener + cancel any pending boot kick
   * ---------------------------------------------------------- */
  function stop() {
    if (_hashListener) {
      try { window.removeEventListener('hashchange', _hashListener); } catch (e) {}
      _hashListener = null;
    }
    if (_bootTimer) {
      try { clearTimeout(_bootTimer); } catch (e) {}
      _bootTimer = null;
    }
    _started = false;
    return true;
  }

  function isRunning() { return _started; }

  /* ----------------------------------------------------------
   * PUBLIC API
   * ---------------------------------------------------------- */

  /* Original global — preserved so external modules that
   * already call window.handleHash() (e.g. tests, admin tools,
   * future re-entry paths) continue to work unchanged. */
  window.handleHash = handle;

  window.SaikoDeepLink = {
    handle: handle,
    parse: parse,
    start: start,
    stop: stop,
    isRunning: isRunning
  };

  /* ----------------------------------------------------------
   * AUTO-START
   * The original boot IIFE wired this at document load. We do
   * the same — attach at DOM ready if still loading, else
   * immediately.
   * ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      start();
    }, { once: true });
  } else {
    start();
  }

  /* ----------------------------------------------------------
   * BOOT LOG
   * ---------------------------------------------------------- */
  try {
    // eslint-disable-next-line no-console
    console.debug('[boot] feature 047 — deep-link ready');
  } catch (e) {}

})();