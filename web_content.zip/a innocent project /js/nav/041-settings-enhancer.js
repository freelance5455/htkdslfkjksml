/* ============================================================
 * SAIKO SETTINGS MASTER — v4 (2025)
 * FILE: js/nav/041-settings-enhancer.js
 *
 * Provides complete, working pages for:
 *   • Appearance / Color  — 12 swatches + custom picker
 *   • UI Size             — live % slider
 *   • Dark Mode           — ON / OFF
 *   • Language            — 22 languages + search bar
 *
 * On language change  → deep re-render of entire app
 * On color change     → CSS vars → whole UI recolours
 * Bulletproof prefs   → self-contained, ignores missing modules
 * Hijacks openSettingPage for the 4 keys above; other keys
 * fall through to the original 040-settings-router.js
 * ============================================================ */
(function () {
  'use strict';

  var VERSION = 'v4-master-2025';
  console.log('[settings-master] loading', VERSION);

  /* ============================================================
   * 1. BULLETPROOF PREFS
   * ============================================================ */
  var DEFAULT_PREFS = {
    accent: '#7c5cff',
    scale: 50,
    dark: true,
    lang: 'en',
    showOnline: true,
    showLastSeen: true,
    callPerm: 'everyone',
    showReadReceipts: true,
    enterToSend: true,
    autoDownload: true,
    notifSound: false,
    reducedMotion: false,
    dataSaver: false,
    performanceMode: false,
    e2eEnabled: true,
    typingIndicator: true,
    appLock: false,
    appLockPin: '',
    feedMode: 'latest',
    storyPrivacy: 'public',
    autoDeleteMsgs: 'off',
    profileTheme: 'default'
  };

  function ensurePrefs() {
    if (typeof window.prefs !== 'object' || window.prefs === null) window.prefs = {};
    var stored = {};
    try { stored = JSON.parse(localStorage.getItem('saiko_prefs_v7') || '{}') || {}; } catch (e) {}
    Object.keys(DEFAULT_PREFS).forEach(function (k) {
      if (typeof window.prefs[k] === 'undefined') {
        window.prefs[k] = (typeof stored[k] !== 'undefined') ? stored[k] : DEFAULT_PREFS[k];
      }
    });
  }

  function hexA(hex, a) {
    var h = String(hex || '#7c5cff').replace('#', '');
    var f = h.length === 3 ? h.split('').map(function (c) { return c + c; }).join('') : h;
    var n = parseInt(f, 16) || 0;
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  function saveNow() {
    try { localStorage.setItem('saiko_prefs_v7', JSON.stringify(window.prefs || {})); } catch (e) {}
    try {
      if (typeof window.savePrefs === 'function' && window.savePrefs !== saveNow) window.savePrefs();
    } catch (e) {}
  }

  function applyNow() {
    var p = window.prefs || DEFAULT_PREFS;
    var root = document.documentElement;
    if (!root) return;

    var accent = p.accent || DEFAULT_PREFS.accent;
    root.style.setProperty('--accent', accent);
    root.style.setProperty('--accent-soft', hexA(accent, 0.16));
    root.style.setProperty('--accent-line', hexA(accent, 0.45));
    root.style.setProperty('--bubble-me', accent);
    root.style.setProperty('--bubble-me-text', '#ffffff');

    var s = Number(p.scale);
    if (!isFinite(s) || s < 1) s = 50;
    if (s > 100) s = 100;
    root.style.setProperty('--scale', (0.55 + s / 100 * 0.9).toFixed(3));

    if (document.body) {
      document.body.classList.toggle('light', !p.dark);
      document.body.classList.toggle('reduced-motion', !!p.reducedMotion);
    }
    root.lang = p.lang || 'en';

    try {
      if (typeof window.applyPrefs === 'function' && window.applyPrefs !== applyNow) window.applyPrefs();
    } catch (e) {}
  }

  ensurePrefs();
  if (typeof window.savePrefs !== 'function') window.savePrefs = saveNow;
  if (typeof window.applyPrefs !== 'function') window.applyPrefs = applyNow;
  try { applyNow(); } catch (e) {}

  /* ============================================================
   * 2. TRANSLATION TABLE
   * ============================================================
   * English is the base. Other languages override as many keys
   * as we have translations for. Anything not overridden falls
   * back to English automatically via deepT().
   * ============================================================ */
  var EXTRA = {
    hi: {
      app_name: 'इनोसेंटसाईको',
      tagline: 'चैट • खेलें • जुड़ें',
      login: 'लॉग इन', signup: 'साइन अप', email: 'ईमेल', password: 'पासवर्ड', name: 'नाम',
      login_btn: 'लॉग इन', signup_btn: 'खाता बनाएं',
      home: 'होम', inbox: 'इनबॉक्स', games: 'गेम्स', notifications: 'सूचनाएं', settings: 'सेटिंग्स', profile: 'प्रोफाइल',
      search: 'खोजें', search_users: 'उपयोगकर्ता खोजें', search_users_ph: 'नाम से खोजें...',
      type_to_search: 'नाम टाइप करें', no_results: 'कोई उपयोगकर्ता नहीं मिला',
      loading: 'लोड हो रहा है...', error: 'कुछ गलत हो गया', retry: 'पुनः प्रयास',
      create_post: 'पोस्ट बनाएं', edit_profile: 'प्रोफाइल संपादित करें', start_chat: 'चैट शुरू करें',
      posts: 'पोस्ट', photos: 'फ़ोटो', write_something: 'क्या सोच रहे हैं?',
      publish: 'प्रकाशित करें', cancel: 'रद्द करें', add_image: 'छवि जोड़ें', image: 'छवि',
      like: 'पसंद', comment: 'टिप्पणी', share: 'साझा', comments: 'टिप्पणियाँ',
      write_comment: 'टिप्पणी लिखें...', reply: 'जवाब', reply_to: 'जवाब दें', send: 'भेजें',
      new_chat: 'नई चैट', new_group: 'नया समूह', group_name: 'समूह का नाम',
      group_image: 'समूह की छवि', create: 'बनाएं', create_group: 'समूह बनाएं',
      members: 'सदस्य', add_members: 'सदस्य जोड़ें',
      type_message: 'संदेश टाइप करें...', emoji: 'इमोजी', voice_message: 'वॉयस संदेश',
      call: 'कॉल', video_call: 'वीडियो कॉल', incoming_call: 'आने वाली कॉल',
      accept: 'स्वीकार', reject: 'अस्वीकार', end_call: 'समाप्त', calling: 'कॉल हो रही है...',
      ringing: 'बज रहा है...', connected: 'जुड़ा', call_ended: 'कॉल समाप्त',
      mark_all_read: 'सभी पढ़ा हुआ चिह्नित करें', no_notifications: 'अभी कोई सूचना नहीं', admin: 'एडमिन',
      appearance: 'रंग-रूप / रंग', ui_size: 'UI आकार', dark_mode: 'डार्क मोड',
      language: 'भाषा', profile_settings: 'प्रोफाइल सेटिंग्स', logout: 'लॉग आउट',
      on: 'चालू', off: 'बंद', save: 'सहेजें', saved: 'सहेजा गया', bio: 'बायो',
      dob: 'जन्म तिथि', relationship: 'रिश्ते की स्थिति', joining: 'जुड़ने की तारीख',
      search_language: 'भाषा खोजें', search_lang_ph: 'भाषा खोजें...',
      confirm_logout: 'क्या आप लॉग आउट करना चाहते हैं?',
      yes: 'हाँ', no: 'नहीं', ok: 'ठीक है', delete: 'हटाएं', are_you_sure: 'क्या आप सुनिश्चित हैं?',
      uploading: 'अपलोड हो रहा है...', please_wait: 'कृपया प्रतीक्षा करें...',
      no_posts: 'अभी कोई पोस्ट नहीं', no_chats: 'अभी कोई चैट नहीं', no_games: 'अभी कोई गेम नहीं',
      play: 'खेलें', fullscreen: 'पूर्ण स्क्रीन', close: 'बंद करें',
      select_users: 'उपयोगकर्ता चुनें', done: 'हो गया', edit: 'संपादित करें', delete_post: 'पोस्ट हटाएं',
      group: 'समूह', you: 'आप', new_message: 'नया संदेश',
      members_count: 'सदस्य', total_posts: 'पोस्ट', total_photos: 'फ़ोटो',
      change_photo: 'फ़ोटो बदलें', save_changes: 'परिवर्तन सहेजें', upload_failed: 'अपलोड विफल',
      online: 'ऑनलाइन', offline: 'ऑफ़लाइन', description: 'विवरण',
      submit: 'जमा करें', report: 'रिपोर्ट', remove: 'हटाएं',
      block: 'ब्लॉक', unblock: 'अनब्लॉक', blocked_users: 'ब्लॉक किए गए',
      privacy: 'गोपनीयता', notification_settings: 'सूचनाएं',
      chat_settings: 'चैट', call_settings: 'कॉल', media: 'मीडिया', about: 'के बारे में',
      mute: 'म्यूट', unmute: 'अनम्यूट', pin: 'पिन', unpin: 'अनपिन',
      copy: 'कॉपी', copied: 'कॉपी किया', forward: 'फॉरवर्ड',
      delete_for_me: 'मेरे लिए हटाएं', delete_for_everyone: 'सभी के लिए हटाएं',
      react: 'प्रतिक्रिया', message_deleted: 'यह संदेश हटा दिया गया',
      call_history: 'कॉल इतिहास', missed_call: 'छूटी कॉल',
      featured: 'फ़ीचर्ड', recent: 'हाल ही में', all: 'सभी', search_games: 'गेम खोजें...',
      hide_post: 'पोस्ट छिपाएं', hidden: 'छिपा हुआ',
      edit_post: 'पोस्ट संपादित करें', edit_comment: 'टिप्पणी संपादित करें', delete_comment: 'टिप्पणी हटाएं',
      copy_text: 'टेक्स्ट कॉपी करें', leave_group: 'समूह छोड़ें', rename_group: 'समूह का नाम बदलें',
      change_image: 'छवि बदलें', make_admin: 'एडमिन बनाएं',
      remove_admin: 'एडमिन हटाएं', remove_member: 'सदस्य हटाएं',
      group_info: 'समूह जानकारी', more: 'और', less: 'कम',
      load_more: 'और लोड करें', no_more_posts: 'और पोस्ट नहीं',
      saved_posts: 'सहेजी गई पोस्ट', bookmark: 'सहेजें', unbookmark: 'अनसेव',
      trending: 'ट्रेंडिंग', leaderboard: 'लीडरबोर्ड',
      missions: 'मिशन', xp: 'XP', level: 'स्तर', badges: 'बैज',
      stories: 'स्टोरीज़', reels: 'रील्स', visitors: 'आगंतुक',
      hashtag: 'हैशटैग', create_story: 'स्टोरी बनाएं',
      add_story: 'स्टोरी जोड़ें', my_story: 'मेरी स्टोरी',
      viewers: 'दर्शक', no_stories: 'अभी कोई स्टोरी नहीं', video: 'वीडियो',
      no_reels: 'अभी कोई रील नहीं', my_missions: 'दैनिक मिशन',
      mission_done: 'पूरा हुआ', rank: 'रैंक', no_visitors: 'अभी कोई आगंतुक नहीं',
      chat_theme: 'चैट थीम', chat_with_admins: 'एडमिन से चैट करें',
      admin_support: 'एडमिन सहायता', add_video: 'वीडियो जोड़ें', add_images: 'छवियाँ जोड़ें',
      for_you: 'आपके लिए', latest: 'नवीनतम', feed_empty: 'अभी कोई पोस्ट नहीं — पहले बनें!',
      e2e_encrypted: 'एंड-टू-एंड एन्क्रिप्टेड', e2e_secure_chat: 'सुरक्षित चैट',
      storage_manager: 'स्टोरेज मैनेजर', data_saver: 'डेटा सेवर',
      performance_mode: 'प्रदर्शन मोड',
      claim: 'प्राप्त करें', story_viewers: 'दर्शक', no_viewers: 'अभी कोई दर्शक नहीं', download: 'डाउनलोड',
      saved_to_device: 'डिवाइस में सहेजा गया', opening_image: 'नए टैब में खोल रहा है',
      story_reply_sent: 'जवाब भेजा गया', story_reacted: 'प्रतिक्रिया जोड़ी गई', group_call: 'समूह कॉल',
      chat_info: 'चैट जानकारी', theme: 'थीम',
      sms_block: 'SMS ब्लॉक', call_block: 'कॉल ब्लॉक',
      set_nickname: 'उपनाम सेट करें', nickname: 'उपनाम',
      nickname_saved: 'उपनाम सहेजा गया', nickname_removed: 'उपनाम हटाया गया',
      popular: 'लोकप्रिय', recent_searches: 'हाल की खोजें', clear_all: 'सभी साफ़ करें',
      add_highlight: 'हाइलाइट में जोड़ें', highlights: 'हाइलाइट्स',
      star_message: 'संदेश स्टार करें', unstar_message: 'स्टार हटाएं',
      starred: 'स्टार किया', auto_delete: 'संदेश स्वतः हटाएं',
      clear_chat: 'चैट साफ़ करें', weekly_missions: 'साप्ताहिक मिशन', streak: 'स्ट्रीक',
      day_streak: 'दिन की स्ट्रीक', achievements: 'उपलब्धियां',
      cover_photo: 'कवर फ़ोटो', change_cover: 'कवर बदलें',
      collections: 'संग्रह', new_collection: 'नया संग्रह', collection_name: 'संग्रह का नाम',
      watch_later: 'बाद में देखें', reels_history: 'रील इतिहास', saved_reels: 'सहेजी रील्स',
      backup: 'बैकअप और रिकवरी', export_data: 'डेटा निर्यात करें',
      login_activity: 'लॉगिन गतिविधि', active_sessions: 'सक्रिय सत्र', logout_other: 'अन्य सत्र लॉग आउट',
      app_lock: 'ऐप लॉक', app_lock_hint: 'ऐप सुरक्षित करने के लिए 4 अंकों का PIN सेट करें',
      set_pin: 'PIN सेट करें', confirm_pin: 'PIN की पुष्टि करें',
      pin_set: 'PIN सेट हो गया', pin_removed: 'PIN हटा दिया गया',
      wrong_pin: 'गलत PIN', enter_pin: 'अपना PIN दर्ज करें',
      muted_users: 'म्यूट किए गए उपयोगकर्ता',
      feature_post: 'प्रोफाइल पर फ़ीचर करें', unfeature_post: 'फ़ीचर्ड से हटाएं',
      account: 'खाता', accessibility: 'पहुँच', reduced_motion: 'गति कम करें',
      change_password: 'पासवर्ड बदलें', change_email: 'ईमेल बदलें',
      password_changed: 'पासवर्ड अपडेट हुआ', email_changed: 'सत्यापन ईमेल भेजा गया',
      pinned_posts: 'पिन किए गए पोस्ट', no_media: 'कोई मीडिया नहीं',
      you_are_offline: 'आप ऑफ़लाइन हैं', please_retry: 'कृपया पुनः प्रयास करें',
      no_more_posts: 'और पोस्ट नहीं', loading_more: 'और लोड हो रहा है...',
      create_post_btn: 'पोस्ट बनाएं',
      restrictions: 'प्रतिबंध', restricted_posts: 'प्रतिबंधित पोस्ट', request_review: 'समीक्षा का अनुरोध करें'
    },
    es: {
      home: 'Inicio', inbox: 'Bandeja', games: 'Juegos', notifications: 'Alertas',
      settings: 'Ajustes', profile: 'Perfil', appearance: 'Apariencia / Color',
      ui_size: 'Tamaño de UI', dark_mode: 'Modo oscuro', language: 'Idioma',
      save: 'Guardar', cancel: 'Cancelar', login: 'Iniciar sesión', signup: 'Registrarse',
      email: 'Correo', password: 'Contraseña', name: 'Nombre',
      on: 'SÍ', off: 'NO', logout: 'Cerrar sesión',
      search_language: 'Buscar idioma', search_lang_ph: 'Buscar idioma...'
    },
    fr: {
      home: 'Accueil', inbox: 'Boîte', games: 'Jeux', notifications: 'Alertes',
      settings: 'Paramètres', profile: 'Profil', appearance: 'Apparence / Couleur',
      ui_size: 'Taille UI', dark_mode: 'Mode sombre', language: 'Langue',
      save: 'Enregistrer', cancel: 'Annuler', login: 'Connexion', signup: "S'inscrire",
      email: 'E-mail', password: 'Mot de passe', name: 'Nom',
      on: 'OUI', off: 'NON', logout: 'Déconnexion',
      search_language: 'Rechercher langue', search_lang_ph: 'Rechercher langue...'
    },
    de: {
      home: 'Start', inbox: 'Posteingang', games: 'Spiele', notifications: 'Hinweise',
      settings: 'Einstellungen', profile: 'Profil', appearance: 'Aussehen / Farbe',
      ui_size: 'UI-Größe', dark_mode: 'Dunkelmodus', language: 'Sprache',
      save: 'Speichern', cancel: 'Abbrechen', login: 'Anmelden', signup: 'Registrieren',
      email: 'E-Mail', password: 'Passwort', name: 'Name',
      on: 'EIN', off: 'AUS', logout: 'Abmelden',
      search_language: 'Sprache suchen', search_lang_ph: 'Sprache suchen...'
    },
    pt: {
      home: 'Início', inbox: 'Caixa', games: 'Jogos', notifications: 'Alertas',
      settings: 'Configurações', profile: 'Perfil', appearance: 'Aparência / Cor',
      ui_size: 'Tamanho UI', dark_mode: 'Modo escuro', language: 'Idioma',
      save: 'Salvar', cancel: 'Cancelar', on: 'SIM', off: 'NÃO', logout: 'Sair',
      search_language: 'Buscar idioma', search_lang_ph: 'Buscar idioma...'
    },
    ru: {
      home: 'Главная', inbox: 'Входящие', games: 'Игры', notifications: 'Уведомления',
      settings: 'Настройки', profile: 'Профиль', appearance: 'Внешний вид / Цвет',
      ui_size: 'Размер UI', dark_mode: 'Тёмный режим', language: 'Язык',
      save: 'Сохранить', cancel: 'Отмена', on: 'ВКЛ', off: 'ВЫКЛ', logout: 'Выйти',
      search_language: 'Поиск языка', search_lang_ph: 'Поиск языка...'
    },
    ar: {
      home: 'الرئيسية', inbox: 'الوارد', games: 'الألعاب', notifications: 'التنبيهات',
      settings: 'الإعدادات', profile: 'الملف', appearance: 'المظهر / اللون',
      ui_size: 'حجم الواجهة', dark_mode: 'الوضع الداكن', language: 'اللغة',
      save: 'حفظ', cancel: 'إلغاء', on: 'تشغيل', off: 'إيقاف', logout: 'خروج',
      search_language: 'ابحث عن لغة', search_lang_ph: 'ابحث عن لغة...'
    },
    zh: {
      home: '首页', inbox: '收件箱', games: '游戏', notifications: '通知',
      settings: '设置', profile: '资料', appearance: '外观 / 颜色',
      ui_size: '界面大小', dark_mode: '深色模式', language: '语言',
      save: '保存', cancel: '取消', on: '开', off: '关', logout: '退出',
      search_language: '搜索语言', search_lang_ph: '搜索语言...'
    },
    ja: {
      home: 'ホーム', inbox: '受信トレイ', games: 'ゲーム', notifications: '通知',
      settings: '設定', profile: 'プロフィール', appearance: '外観 / 色',
      ui_size: 'UIサイズ', dark_mode: 'ダークモード', language: '言語',
      save: '保存', cancel: 'キャンセル', on: 'オン', off: 'オフ', logout: 'ログアウト',
      search_language: '言語を検索', search_lang_ph: '言語を検索...'
    },
    ko: {
      home: '홈', inbox: '받은편지함', games: '게임', notifications: '알림',
      settings: '설정', profile: '프로필', appearance: '모양 / 색상',
      ui_size: 'UI 크기', dark_mode: '다크 모드', language: '언어',
      save: '저장', cancel: '취소', on: '켜기', off: '끄기', logout: '로그아웃',
      search_language: '언어 검색', search_lang_ph: '언어 검색...'
    },
    id: {
      home: 'Beranda', inbox: 'Kotak Masuk', games: 'Game', notifications: 'Notifikasi',
      settings: 'Pengaturan', profile: 'Profil', appearance: 'Tampilan / Warna',
      ui_size: 'Ukuran UI', dark_mode: 'Mode Gelap', language: 'Bahasa',
      save: 'Simpan', cancel: 'Batal', on: 'AKTIF', off: 'MATI', logout: 'Keluar',
      search_language: 'Cari bahasa', search_lang_ph: 'Cari bahasa...'
    },
    tr: {
      home: 'Ana Sayfa', inbox: 'Gelen Kutusu', games: 'Oyunlar', notifications: 'Bildirimler',
      settings: 'Ayarlar', profile: 'Profil', appearance: 'Görünüm / Renk',
      ui_size: 'Arayüz Boyutu', dark_mode: 'Koyu Mod', language: 'Dil',
      save: 'Kaydet', cancel: 'İptal', on: 'AÇIK', off: 'KAPALI', logout: 'Çıkış',
      search_language: 'Dil ara', search_lang_ph: 'Dil ara...'
    },
    bn: {
      home: 'হোম', inbox: 'ইনবক্স', games: 'গেমস', notifications: 'বিজ্ঞপ্তি',
      settings: 'সেটিংস', profile: 'প্রোফাইল', appearance: 'চেহারা / রং',
      ui_size: 'UI আকার', dark_mode: 'ডার্ক মোড', language: 'ভাষা',
      save: 'সংরক্ষণ', cancel: 'বাতিল', on: 'চালু', off: 'বন্ধ', logout: 'লগ আউট',
      search_language: 'ভাষা খুঁজুন', search_lang_ph: 'ভাষা খুঁজুন...'
    },
    ur: {
      home: 'ہوم', inbox: 'ان باکس', games: 'گیمز', notifications: 'اطلاعات',
      settings: 'ترتیبات', profile: 'پروفائل', appearance: 'ظاہری شکل / رنگ',
      ui_size: 'UI سائز', dark_mode: 'ڈارک موڈ', language: 'زبان',
      save: 'محفوظ کریں', cancel: 'منسوخ', on: 'آن', off: 'آف', logout: 'لاگ آؤٹ',
      search_language: 'زبان تلاش کریں', search_lang_ph: 'زبان تلاش کریں...'
    },
    it: {
      home: 'Home', inbox: 'Posta', games: 'Giochi', notifications: 'Avvisi',
      settings: 'Impostazioni', profile: 'Profilo', appearance: 'Aspetto / Colore',
      ui_size: 'Dimensione UI', dark_mode: 'Modalità scura', language: 'Lingua',
      save: 'Salva', cancel: 'Annulla', on: 'ON', off: 'OFF', logout: 'Esci',
      search_language: 'Cerca lingua', search_lang_ph: 'Cerca lingua...'
    },
    nl: {
      home: 'Start', inbox: 'Postvak', games: 'Spellen', notifications: 'Meldingen',
      settings: 'Instellingen', profile: 'Profiel', appearance: 'Uiterlijk / Kleur',
      ui_size: 'UI-grootte', dark_mode: 'Donkere modus', language: 'Taal',
      save: 'Opslaan', cancel: 'Annuleren', on: 'AAN', off: 'UIT', logout: 'Uitloggen',
      search_language: 'Taal zoeken', search_lang_ph: 'Taal zoeken...'
    },
    pl: {
      home: 'Główna', inbox: 'Skrzynka', games: 'Gry', notifications: 'Powiadomienia',
      settings: 'Ustawienia', profile: 'Profil', appearance: 'Wygląd / Kolor',
      ui_size: 'Rozmiar UI', dark_mode: 'Tryb ciemny', language: 'Język',
      save: 'Zapisz', cancel: 'Anuluj', on: 'WŁ', off: 'WYŁ', logout: 'Wyloguj',
      search_language: 'Szukaj języka', search_lang_ph: 'Szukaj języka...'
    },
    th: {
      home: 'หน้าแรก', inbox: 'กล่องข้อความ', games: 'เกม', notifications: 'การแจ้งเตือน',
      settings: 'การตั้งค่า', profile: 'โปรไฟล์', appearance: 'รูปลักษณ์ / สี',
      ui_size: 'ขนาด UI', dark_mode: 'โหมดมืด', language: 'ภาษา',
      save: 'บันทึก', cancel: 'ยกเลิก', on: 'เปิด', off: 'ปิด', logout: 'ออกจากระบบ',
      search_language: 'ค้นหาภาษา', search_lang_ph: 'ค้นหาภาษา...'
    },
    vi: {
      home: 'Trang chủ', inbox: 'Hộp thư', games: 'Trò chơi', notifications: 'Thông báo',
      settings: 'Cài đặt', profile: 'Hồ sơ', appearance: 'Giao diện / Màu',
      ui_size: 'Kích thước UI', dark_mode: 'Chế độ tối', language: 'Ngôn ngữ',
      save: 'Lưu', cancel: 'Hủy', on: 'BẬT', off: 'TẮT', logout: 'Đăng xuất',
      search_language: 'Tìm ngôn ngữ', search_lang_ph: 'Tìm ngôn ngữ...'
    },
    fa: {
      home: 'خانه', inbox: 'صندوق', games: 'بازی‌ها', notifications: 'اعلانات',
      settings: 'تنظیمات', profile: 'پروفایل', appearance: 'ظاهر / رنگ',
      ui_size: 'اندازه رابط', dark_mode: 'حالت تاریک', language: 'زبان',
      save: 'ذخیره', cancel: 'لغو', on: 'روشن', off: 'خاموش', logout: 'خروج',
      search_language: 'جستجوی زبان', search_lang_ph: 'جستجوی زبان...'
    },
    sw: {
      home: 'Nyumbani', inbox: 'Kikasha', games: 'Michezo', notifications: 'Arifa',
      settings: 'Mipangilio', profile: 'Wasifu', appearance: 'Muonekano / Rangi',
      ui_size: 'Ukubwa wa UI', dark_mode: 'Hali ya giza', language: 'Lugha',
      save: 'Hifadhi', cancel: 'Ghairi', on: 'IMEWASHWA', off: 'IMEZIMWA', logout: 'Toka',
      search_language: 'Tafuta lugha', search_lang_ph: 'Tafuta lugha...'
    }
  };

  function mergeTranslations() {
    if (typeof window.I18N !== 'object' || !window.I18N) window.I18N = { en: {} };
    if (!window.I18N.en) window.I18N.en = {};
    Object.keys(EXTRA).forEach(function (code) {
      if (!window.I18N[code]) window.I18N[code] = {};
      /* Fill missing keys with English so nothing shows raw key */
      Object.keys(window.I18N.en).forEach(function (k) {
        if (typeof window.I18N[code][k] === 'undefined') {
          window.I18N[code][k] = window.I18N.en[k];
        }
      });
      /* Apply our overrides */
      Object.keys(EXTRA[code]).forEach(function (k) {
        window.I18N[code][k] = EXTRA[code][k];
      });
    });
  }

  /* Deep translator — always uses prefs.lang */
  function deepT(key) {
    var lang = (window.prefs && window.prefs.lang) || 'en';
    var L = (window.I18N && window.I18N[lang]) || {};
    var E = (window.I18N && window.I18N.en) || {};
    if (typeof L[key] !== 'undefined' && L[key] !== null) return L[key];
    if (typeof E[key] !== 'undefined' && E[key] !== null) return E[key];
    return key;
  }

  /* Merge and override t globally */
  mergeTranslations();
  window.t = deepT;
  window.saikoT = deepT;

  /* ============================================================
   * 3. DEEP RE-RENDER ON LANGUAGE CHANGE
   * ============================================================ */
  function safeCall(name, args) {
    try {
      if (typeof window[name] === 'function') return window[name].apply(window, args || []);
    } catch (e) { console.warn('[settings-master] safeCall', name, e); }
    return undefined;
  }

  function rerenderAll() {
    console.log('[settings-master] deep re-render');

    /* Static text */
    safeCall('applyI18n');

    /* Nav */
    safeCall('buildNavIcons');

    /* Page title */
    try { document.title = deepT('app_name') || document.title; } catch (e) {}

    /* Refresh every main page renderer */
    safeCall('renderProfilePage');
    safeCall('renderNotifications');
    safeCall('renderInbox');
    safeCall('renderGames');
    safeCall('renderStoriesBar');
    safeCall('renderFeed', [false]);

    /* Sidebar re-render if open */
    try {
      var side = document.getElementById('settingsSidebar');
      if (side && side.classList.contains('open') && typeof window.openSettingsSidebar === 'function') {
        window.openSettingsSidebar();
      }
    } catch (e) {}

    /* Chat header */
    try { if (window.currentChatId) safeCall('refreshChatHeaderNames'); } catch (e) {}

    /* Subscribers */
    try {
      window.dispatchEvent(new CustomEvent('saiko:language-changed', {
        detail: { lang: window.prefs.lang }
      }));
    } catch (e) {}
  }

  /* ============================================================
   * 4. HELPER — QUERY
   * ============================================================ */
  function qs(s, r) { return (r || document).querySelector(s); }
  function qsa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function toastOk(msg) {
    try { if (typeof window.toast === 'function') window.toast(msg, 'ok'); } catch (e) {}
  }
  function openOverlaySafe(id) {
    try { if (typeof window.openOverlay === 'function') { window.openOverlay(id); return; } } catch (e) {}
    var o = document.getElementById(id); if (o) o.classList.add('open');
  }

  /* ============================================================
   * 5. PAGE — LANGUAGE
   * ============================================================ */
  var LANG_LIST = [
    { code:'en', name:'English',    native:'English' },
    { code:'hi', name:'Hindi',      native:'हिन्दी' },
    { code:'es', name:'Spanish',    native:'Español' },
    { code:'fr', name:'French',     native:'Français' },
    { code:'de', name:'German',     native:'Deutsch' },
    { code:'pt', name:'Portuguese', native:'Português' },
    { code:'ru', name:'Russian',    native:'Русский' },
    { code:'ar', name:'Arabic',     native:'العربية' },
    { code:'zh', name:'Chinese',    native:'中文' },
    { code:'ja', name:'Japanese',   native:'日本語' },
    { code:'ko', name:'Korean',     native:'한국어' },
    { code:'id', name:'Indonesian', native:'Bahasa Indonesia' },
    { code:'tr', name:'Turkish',    native:'Türkçe' },
    { code:'bn', name:'Bengali',    native:'বাংলা' },
    { code:'ur', name:'Urdu',       native:'اردو' },
    { code:'it', name:'Italian',    native:'Italiano' },
    { code:'nl', name:'Dutch',      native:'Nederlands' },
    { code:'pl', name:'Polish',     native:'Polski' },
    { code:'th', name:'Thai',       native:'ไทย' },
    { code:'vi', name:'Vietnamese', native:'Tiếng Việt' },
    { code:'fa', name:'Persian',    native:'فارسی' },
    { code:'sw', name:'Swahili',    native:'Kiswahili' }
  ];

  function renderLanguagePage() {
    var cur = window.prefs.lang || 'en';
    var rows = LANG_LIST.map(function (l) {
      var sel = cur === l.code ? ' sel' : '';
      var check = cur === l.code
        ? '<span class="ic" style="color:var(--accent);font-weight:800">✓</span>'
        : '';
      return '<div class="lang-item' + sel + '" data-lang="' + l.code + '">' +
               '<span>' + esc(l.native) +
                 ' <span class="muted" style="font-size:.75rem">(' + esc(l.name) + ')</span>' +
               '</span>' + check + '</div>';
    }).join('');

    return '<div class="searchbar">' +
             '<span class="ic">🔍</span>' +
             '<input type="search" id="langSearch" placeholder="' +
               esc(deepT('search_lang_ph') || 'Search language...') + '">' +
           '</div>' +
           '<div id="langList">' + rows + '</div>';
  }

  function wireLanguagePage() {
    qsa('#langList [data-lang]').forEach(function (n) {
      n.addEventListener('click', function () {
        var code = n.getAttribute('data-lang');
        console.log('[settings-master] language →', code);
        window.prefs.lang = code;
        saveNow();
        applyNow();
        rerenderAll();
        setTimeout(function () {
          var body = qs('#settingPageBody');
          if (body) { body.innerHTML = renderLanguagePage(); wireLanguagePage(); }
        }, 60);
        toastOk(deepT('saved') || 'Saved');
      });
    });

    var s = qs('#langSearch');
    if (s) s.addEventListener('input', function () {
      var q = (s.value || '').toLowerCase();
      qsa('#langList [data-lang]').forEach(function (n) {
        var code = n.getAttribute('data-lang');
        var l = null;
        for (var i = 0; i < LANG_LIST.length; i++) {
          if (LANG_LIST[i].code === code) { l = LANG_LIST[i]; break; }
        }
        if (!l) return;
        n.style.display = (!q ||
          l.name.toLowerCase().indexOf(q) !== -1 ||
          l.native.toLowerCase().indexOf(q) !== -1) ? '' : 'none';
      });
    });
  }

  /* ============================================================
   * 6. PAGE — APPEARANCE
   * ============================================================ */
  var PRESETS = ['#7c5cff','#2ecc8f','#ff5c6c','#3aa0ff','#ff9f43','#e84393',
                 '#00cec9','#a55eea','#fdcb6e','#e17055','#0984e3','#fd79a8'];

  function renderAppearancePage() {
    var p = window.prefs;
    var accent = String(p.accent || '#7c5cff');
    var swatches = PRESETS.map(function (c) {
      var sel = accent.toLowerCase() === c.toLowerCase() ? ' sel' : '';
      return '<div class="swatch' + sel + '" data-c="' + c + '" style="background:' + c + '"></div>';
    }).join('');

    return '<div class="sec-title">' + esc(deepT('appearance') || 'Appearance / Color') + '</div>' +
      '<div class="swatches" id="swatches">' + swatches + '</div>' +
      '<div class="field"><label>Custom Color</label>' +
        '<input type="color" id="accentPick" value="' + esc(accent) + '">' +
      '</div>' +
      '<button class="btn solid block" id="accentSave">' + esc(deepT('save') || 'Save') + '</button>' +
      '<div class="sec-title" style="margin-top:1rem">' + esc(deepT('dark_mode') || 'Dark Mode') + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (p.dark ? 'active' : '') + '" id="darkOn">' + esc(deepT('on') || 'ON') + '</button>' +
        '<button class="btn ' + (!p.dark ? 'active' : '') + '" id="darkOff">' + esc(deepT('off') || 'OFF') + '</button>' +
      '</div>' +
      '<div class="sec-title">' + esc(deepT('ui_size') || 'UI Size') + '</div>' +
      '<div style="text-align:center;font-weight:800;font-size:1.4rem" id="sizeVal">' +
        esc(String(p.scale || 50)) + '%' +
      '</div>' +
      '<input type="range" min="1" max="100" value="' + esc(String(p.scale || 50)) + '" id="sizeRange">';
  }

  function wireAppearancePage() {
    var pick = qs('#accentPick');

    qsa('#swatches .swatch').forEach(function (s) {
      s.addEventListener('click', function () {
        var c = s.getAttribute('data-c');
        if (pick) pick.value = c;
        window.prefs.accent = c;
        saveNow(); applyNow();
        qsa('#swatches .swatch').forEach(function (x) { x.classList.toggle('sel', x === s); });
      });
    });

    if (pick) {
      pick.addEventListener('input', function () {
        window.prefs.accent = pick.value; applyNow();
      });
      pick.addEventListener('change', function () {
        window.prefs.accent = pick.value; saveNow(); applyNow();
      });
    }

    var saveBtn = qs('#accentSave');
    if (saveBtn) saveBtn.addEventListener('click', function () {
      if (pick) window.prefs.accent = pick.value;
      saveNow(); applyNow();
      toastOk(deepT('saved') || 'Saved');
    });

    var dOn = qs('#darkOn');
    if (dOn) dOn.addEventListener('click', function () {
      window.prefs.dark = true; saveNow(); applyNow();
      dOn.classList.add('active');
      var d2 = qs('#darkOff'); if (d2) d2.classList.remove('active');
    });
    var dOff = qs('#darkOff');
    if (dOff) dOff.addEventListener('click', function () {
      window.prefs.dark = false; saveNow(); applyNow();
      dOff.classList.add('active');
      var d2 = qs('#darkOn'); if (d2) d2.classList.remove('active');
    });

    var r = qs('#sizeRange');
    if (r) {
      r.addEventListener('input', function () {
        window.prefs.scale = Number(r.value);
        var v = qs('#sizeVal'); if (v) v.textContent = window.prefs.scale + '%';
        applyNow();
      });
      r.addEventListener('change', function () { saveNow(); });
    }
  }

  /* ============================================================
   * 7. PAGE — UI SIZE (standalone)
   * ============================================================ */
  function renderUiSizePage() {
    return '<div class="sec-title">' + esc(deepT('ui_size') || 'UI Size') + '</div>' +
      '<div class="card" style="text-align:center">' +
        '<div style="font-size:1.6rem;font-weight:800" id="sizeVal">' +
          esc(String(window.prefs.scale || 50)) + '%' +
        '</div>' +
      '</div>' +
      '<input type="range" min="1" max="100" value="' +
        esc(String(window.prefs.scale || 50)) + '" id="sizeRange">' +
      '<div class="row" style="justify-content:space-between;font-size:.72rem;color:var(--muted)">' +
        '<span>1%</span><span>100%</span>' +
      '</div>' +
      '<button class="btn solid block" id="sizeSave" style="margin-top:1rem">' +
        esc(deepT('save') || 'Save') + '</button>';
  }

  function wireUiSizePage() {
    var r = qs('#sizeRange');
    if (r) {
      r.addEventListener('input', function () {
        window.prefs.scale = Number(r.value);
        var v = qs('#sizeVal'); if (v) v.textContent = window.prefs.scale + '%';
        applyNow();
      });
      r.addEventListener('change', function () { saveNow(); });
    }
    var s = qs('#sizeSave');
    if (s) s.addEventListener('click', function () {
      saveNow(); toastOk(deepT('saved') || 'Saved');
    });
  }

  /* ============================================================
   * 8. PAGE — DARK MODE (standalone)
   * ============================================================ */
  function renderDarkPage() {
    return '<div class="sec-title">' + esc(deepT('dark_mode') || 'Dark Mode') + '</div>' +
      '<div class="toggle-row">' +
        '<button class="btn ' + (window.prefs.dark ? 'active' : '') + '" id="darkOn">' + esc(deepT('on') || 'ON') + '</button>' +
        '<button class="btn ' + (!window.prefs.dark ? 'active' : '') + '" id="darkOff">' + esc(deepT('off') || 'OFF') + '</button>' +
      '</div>';
  }

  function wireDarkPage() {
    var dOn = qs('#darkOn');
    if (dOn) dOn.addEventListener('click', function () {
      window.prefs.dark = true; saveNow(); applyNow();
      dOn.classList.add('active');
      var d2 = qs('#darkOff'); if (d2) d2.classList.remove('active');
    });
    var dOff = qs('#darkOff');
    if (dOff) dOff.addEventListener('click', function () {
      window.prefs.dark = false; saveNow(); applyNow();
      dOff.classList.add('active');
      var d2 = qs('#darkOn'); if (d2) d2.classList.remove('active');
    });
  }

  /* ============================================================
   * 9. HIJACK openSettingPage (install once)
   * ============================================================ */
  function installOnce() {
    if (window.__SAIKO_SETTINGS_MASTER_INSTALLED) return true;
    window.__SAIKO_SETTINGS_MASTER_INSTALLED = true;

    var original = window.openSettingPage;

    var wrapped = function (key) {
      var titleEl = qs('#settingPageTitle');
      var body = qs('#settingPageBody');
      if (!body) return false;

      if (titleEl) titleEl.textContent = deepT(key) || key;

      if (key === 'language') {
        body.innerHTML = renderLanguagePage();
        openOverlaySafe('ovSettingPage');
        wireLanguagePage();
        return true;
      }
      if (key === 'appearance') {
        body.innerHTML = renderAppearancePage();
        openOverlaySafe('ovSettingPage');
        wireAppearancePage();
        return true;
      }
      if (key === 'ui_size') {
        body.innerHTML = renderUiSizePage();
        openOverlaySafe('ovSettingPage');
        wireUiSizePage();
        return true;
      }
      if (key === 'dark_mode') {
        body.innerHTML = renderDarkPage();
        openOverlaySafe('ovSettingPage');
        wireDarkPage();
        return true;
      }

      /* Everything else → original router */
      if (typeof original === 'function' && original !== wrapped) {
        try { return original.call(window, key); }
        catch (e) { console.warn('[settings-master] original router failed', key, e); }
      }

      /* Absolute fallback */
      body.innerHTML =
        '<div class="sec-title">' + esc(deepT(key) || key) + '</div>' +
        '<div class="empty"><p>' + esc(deepT('no_data') || 'No data') + '</p></div>';
      openOverlaySafe('ovSettingPage');
      return true;
    };

    window.openSettingPage = wrapped;
    console.log('[settings-master] ✓ hijacked openSettingPage (' + VERSION + ')');
    return true;
  }

  /* Poll until original router has defined openSettingPage */
  var attempts = 0;
  function pollInstall() {
    attempts++;
    if (typeof window.openSettingPage === 'function') {
      installOnce();
      return;
    }
    if (attempts < 40) setTimeout(pollInstall, 100);
    else { installOnce(); }
  }
  pollInstall();

  /* ============================================================
   * 10. AUTO-APPLY ON BOOT
   * ============================================================ */
  function boot() {
    try { applyNow(); } catch (e) {}
    setTimeout(function () { try { rerenderAll(); } catch (e) {} }, 800);
    console.log('[settings-master] ✓ ready —',
                'prefs:', Object.keys(window.prefs || {}).length,
                'keys | lang:', window.prefs.lang,
                '| accent:', window.prefs.accent);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }

  window.SaikoSettingsMaster = {
    VERSION: VERSION,
    install: installOnce,
    rerenderAll: rerenderAll,
    applyNow: applyNow,
    saveNow: saveNow,
    t: deepT,
    LANG_LIST: LANG_LIST.slice()
  };

})();