/* ============================================================
 * PAGE RENDERERS — PROFILE + USER PROFILE + EXTRAS
 * FILE:   js/pages/page-renderers.js
 * ACTION: REPLACE (v5 — overlay stacking for back navigation)
 * ============================================================ */

(function () {
  'use strict';

  function qs(sel, root) { return (root || document).querySelector(sel); }
  function qsa(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function T(k) { try { if (typeof t === 'function') return t(k); } catch (e) {} return k; }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeAgo(ts) { try { return window.timeAgo(ts); } catch (e) { return ''; } }
  function fmtDate(ts) {
    try { return window.fmtDate(ts); } catch (e) {}
    return ts ? new Date(ts).toLocaleDateString() : '—';
  }
  function fmtTime(ts) { try { return window.fmtTime(ts); } catch (e) { return ''; } }
  function timeNow() { try { return window.now(); } catch (e) { return Date.now(); } }
  function svgIcon(n, f) { try { return window.svgIcon(n, f) || ''; } catch (e) { return ''; } }
  function avatarHTML(url, name, cls, uid) {
    try { if (typeof window.avatarHTML === 'function') return window.avatarHTML(url, name, cls, uid); } catch (e) {}
    var c = cls || 'av-40';
    var init = (name || '?').trim().charAt(0).toUpperCase() || '?';
    if (url) return '<img class="avatar ' + c + '" src="' + esc(url) + '" alt="">';
    return '<div class="avatar ' + c + '">' + esc(init) + '</div>';
  }
  function safeCall(name, args) {
    try { var fn = window[name]; if (typeof fn === 'function') return fn.apply(window, args || []); } catch (e) {}
    return undefined;
  }
  function safeToast(msg, kind) { try { if (typeof window.toast === 'function') window.toast(msg, kind); } catch (e) {} }
  function safeConfirm(t1, t2) {
    try { if (typeof window.confirmDialog === 'function') return window.confirmDialog(t1, t2); } catch (e) {}
    return Promise.resolve(true);
  }
  function findUser(uid) { try { return window.findUser(uid); } catch (e) { return null; } }
  function countLikes(pid) { try { return window.countLikes(pid); } catch (e) { return 0; } }
  function isVisiblePost(p) { try { return window.isVisiblePost(p); } catch (e) { return !!p; } }
  function postsCache() { return Array.isArray(window.postsCache) ? window.postsCache : []; }
  function reelsCache() { return Array.isArray(window.reelsCache) ? window.reelsCache : []; }
  function myUid() { return window.myUid || ''; }
  function myProfile() { return window.myProfile || {}; }

  function levelFromXp(xp) {
    xp = Number(xp) || 0;
    return Math.max(1, Math.floor(Math.sqrt(xp / 50)) + 1);
  }
  function xpForLevel(lv) {
    return Math.pow(lv - 1, 2) * 50;
  }

  var BADGES = [
    { id: 'first_post',  ic: '📝', name: 'First Post',        test: function (p) { return (p.posts || 0) >= 1; } },
    { id: 'social',      ic: '💬', name: 'Conversationalist', test: function (p) { return (p.comments || 0) >= 10; } },
    { id: 'liked',       ic: '❤️', name: 'Popular',            test: function (p) { return (p.likes || 0) >= 25; } },
    { id: 'gamer',       ic: '🎮', name: 'Gamer',              test: function (p) { return (p.games || 0) >= 5; } },
    { id: 'veteran',     ic: '🏅', name: 'Veteran',            test: function (p) { return (p.level || 1) >= 5; } },
    { id: 'storyteller', ic: '📸', name: 'Storyteller',        test: function (p) { return (p.stories || 0) >= 3; } },
    { id: 'creator',     ic: '🎬', name: 'Creator',            test: function (p) { return (p.reels || 0) >= 2; } }
  ];

  if (typeof window.profileTab === 'undefined') window.profileTab = 'posts';
  if (typeof window.visitorsCache === 'undefined') window.visitorsCache = {};
  if (typeof window.recentPlayed === 'undefined') {
    try { window.recentPlayed = JSON.parse(localStorage.getItem('saiko_recent_games') || '[]'); }
    catch (e) { window.recentPlayed = []; }
  }

  /* ============ EXTRAS LISTENERS ============ */
  function startExtrasListeners() {
    if (!window.db || !myUid() || window.__extrasListeners) return;
    window.__extrasListeners = true;

    window.__extrasRef = window.db.ref('profileVisits/' + myUid());
    window.__extrasRef.on('value', function (s) {
      window.visitorsCache = s.val() || {};
      if (window.currentNav === 'profile') renderProfilePage();
    }, function (err) {
      window.__extrasListeners = false;
    });
  }

  function tryStartExtras() {
    if (window.__extrasListeners) return true;
    if (!window.db) return false;
    if (!window.myUid) return false;
    try {
      startExtrasListeners();
      return !!window.__extrasListeners;
    } catch (e) {
      return false;
    }
  }

  (function retryExtras() {
    var tries = 0;
    function tick() {
      tries++;
      if (tryStartExtras()) return;
      if (tries < 40) setTimeout(tick, 500);
    }
    tick();
  })();

  window.addEventListener('saiko:login', function () {
    window.__extrasListeners = false;
    try {
      if (window.__extrasRef) { window.__extrasRef.off(); window.__extrasRef = null; }
    } catch (e) {}
    setTimeout(tryStartExtras, 300);
    setTimeout(tryStartExtras, 1000);
    setTimeout(tryStartExtras, 2500);
  });

  window.addEventListener('saiko:navigate', function (e) {
    if (e && e.detail && e.detail.nav === 'profile') {
      tryStartExtras();
    }
  });

  /* ============ PROFILE PAGE ============ */
  function renderProfilePage() {
    var mp = myProfile();
    if (!mp || !mp.uid) return;
    var page = qs('#page-profile');
    if (!page) return;

    if (window.profileTab === 'missions' ||
        window.profileTab === 'leaderboard' ||
        window.profileTab === 'collections' ||
        window.profileTab === 'restricted') {
      window.profileTab = 'posts';
    }

    var uid = myUid();
    var pc = postsCache();
    var rc = reelsCache();

    var mine = pc.filter(function (p) { return p.uid === uid && isVisiblePost(p); });
    var photoPosts = mine.filter(function (p) { return p.image || (p.images && p.images.length); });
    var myReels = rc.filter(function (r) { return r.uid === uid; });

    var xp = Number(mp.xp) || 0;
    var lv = levelFromXp(xp);
    var nextXp = xpForLevel(lv + 1);
    var curBase = xpForLevel(lv);
    var pct = Math.min(100, Math.round(((xp - curBase) / Math.max(1, nextXp - curBase)) * 100));

    var visits = Object.keys(window.visitorsCache || {}).length;

    var earnedBadges = BADGES.filter(function (b) {
      try {
        return b.test({
          posts: mine.length,
          comments: 0,
          likes: 0,
          games: (window.recentPlayed || []).length,
          level: lv,
          stories: 0,
          reels: myReels.length
        });
      } catch (e) { return false; }
    });

    var totalLikes = pc.filter(function (p) { return p.uid === uid; })
                       .reduce(function (s, p) { return s + countLikes(p.id); }, 0);

    var restrictedCount = 0;
    try {
      pc.forEach(function (p) {
        if (p.uid === uid && p.suspended === true) restrictedCount++;
      });
    } catch (e) {}

    page.innerHTML =
      '<div class="cover-wrap" id="coverWrap">' +
        (mp.cover ? '<img src="' + esc(mp.cover) + '" alt="">' : '') +
        '<span class="cover-edit" id="coverEdit">📷</span>' +
      '</div>' +
      '<div class="prof-head" style="padding-top:0">' +
        '<div id="myAvatarWrap" style="margin-top:-2.4rem">' +
          avatarHTML(mp.photo, mp.name, 'av-88') +
        '</div>' +
        '<div class="nm">' + esc(mp.name || 'User') + '</div>' +
        '<div class="bio">' + esc(mp.bio || '—') + '</div>' +
        '<div class="xp-wrap">' +
          '<div class="row" style="justify-content:space-between;font-size:.72rem;color:var(--muted)">' +
            '<span>Lv ' + lv + '</span><span>' + xp + ' XP</span>' +
          '</div>' +
          '<div class="xp-bar"><i style="width:' + pct + '%"></i></div>' +
          (mp.streak ? '<div class="mini" style="text-align:center;margin-top:.3rem">🔥 ' + esc(String(mp.streak)) + ' ' + esc(T('day_streak')) + '</div>' : '') +
        '</div>' +
        '<div class="stat-row">' +
          '<div class="stat"><b>' + mine.length + '</b>' + esc(T('total_posts')) + '</div>' +
          '<div class="stat"><b>' + photoPosts.length + '</b>' + esc(T('total_photos')) + '</div>' +
          '<div class="stat"><b>' + myReels.length + '</b>' + esc(T('reels')) + '</div>' +
          '<div class="stat"><b>' + totalLikes + '</b>' + esc(T('like')) + '</div>' +
          '<div class="stat" id="openVisitors"><b>' + visits + '</b>' + esc(T('visitors')) + '</div>' +
        '</div>' +
        '<div class="row" style="gap:.55rem;margin-top:.7rem;flex-wrap:wrap;justify-content:center">' +
          '<button class="btn sm solid" id="profCreate">+ ' + esc(T('create_post')) + '</button>' +
          '<button class="btn sm ghost" id="profEdit">' + esc(T('edit_profile')) + '</button>' +
          '<button class="btn sm ghost" id="profShare">' + esc(T('share_profile')) + '</button>' +
          '<button class="btn sm ghost" id="profSaved">' + esc(T('saved_posts')) + '</button>' +
          '<button class="btn sm ghost" id="profPinned">📌 ' + esc(T('pinned_posts')) + '</button>' +
          '<button class="btn sm ghost" id="profRestricted">🛡 ' + esc(T('restricted_posts')) + (restrictedCount ? ' (' + restrictedCount + ')' : '') + '</button>' +
        '</div>' +
        (earnedBadges.length
          ? '<div class="badge-row">' + earnedBadges.map(function (b) {
              return '<div class="badge on" title="' + esc(b.name) + '">' + b.ic + '</div>';
            }).join('') + '</div>'
          : '') +
      '</div>' +
      '<div style="padding:0 .8rem 1.5rem">' +
        '<div class="card" style="padding:.7rem">' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('dob')) + '</span><b>' + esc(mp.dob || '—') + '</b></div>' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('relationship')) + '</span><b>' + esc(mp.relationship || '—') + '</b></div>' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('joining')) + '</span><b>' + esc(fmtDate(mp.createdAt)) + '</b></div>' +
        '</div>' +
        '<div class="ptabs" id="profileTabs">' +
          '<span class="chip ' + (window.profileTab === 'posts' ? 'sel' : '') + '" data-ptab="posts">' + esc(T('posts')) + '</span>' +
          '<span class="chip ' + (window.profileTab === 'photos' ? 'sel' : '') + '" data-ptab="photos">' + esc(T('photos')) + '</span>' +
          '<span class="chip ' + (window.profileTab === 'reels' ? 'sel' : '') + '" data-ptab="reels">' + esc(T('reels')) + '</span>' +
          '<span class="chip ' + (window.profileTab === 'saved' ? 'sel' : '') + '" data-ptab="saved">' + esc(T('saved_posts')) + '</span>' +
          '<span class="chip ' + (window.profileTab === 'collections' ? 'sel' : '') + '" data-ptab="collections">' + esc(T('collections')) + '</span>' +
          '<span class="chip ' + (window.profileTab === 'restricted' ? 'sel' : '') + '" data-ptab="restricted">' + esc(T('restricted_posts')) + '</span>' +
          '<span class="chip" data-ptab="missions">' + esc(T('missions')) + '</span>' +
          '<span class="chip" data-ptab="leaderboard">' + esc(T('leaderboard')) + '</span>' +
        '</div>' +
        '<div id="profTabContent"></div>' +
      '</div>';

    var box = qs('#profTabContent');

    function renderTab() {
      if (!box) return;

      if (window.profileTab === 'photos') {
        if (!photoPosts.length) {
          box.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('image') + '</span><p>' + esc(T('no_media')) + '</p></div>';
        } else {
          var html = '<div class="grid2">';
          photoPosts.forEach(function (p) {
            var arr = Array.isArray(p.images) && p.images.length ? p.images : (p.image ? [p.image] : []);
            arr.forEach(function (src) {
              html += '<img src="' + esc(src) + '" data-gopen2="' + esc(p.id) + '" data-gsrc="' + esc(src) + '" loading="lazy">';
            });
          });
          html += '</div>';
          box.innerHTML = html;
          qsa('[data-gopen2]', box).forEach(function (n) {
            n.addEventListener('click', function () {
              var post = pc.find(function (x) { return x.id === n.getAttribute('data-gopen2'); });
              if (!post) return;
              var arr = Array.isArray(post.images) && post.images.length ? post.images : (post.image ? [post.image] : []);
              safeCall('openGallery', [arr, arr.indexOf(n.getAttribute('data-gsrc')), post.id]);
            });
          });
        }
      } else if (window.profileTab === 'reels') {
        if (!myReels.length) {
          box.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('film') + '</span><p>' + esc(T('no_reels')) + '</p></div>';
        } else {
          box.innerHTML = myReels.map(function (r) {
            var likes = (window.reelLikes && window.reelLikes[r.id]) ? Object.keys(window.reelLikes[r.id]).length : 0;
            return '<div class="card" data-reelopen="' + esc(r.id) + '">' +
              '<video src="' + esc(r.url) + '" style="width:100%;max-height:16rem;object-fit:cover;border-radius:.7rem" muted playsinline preload="metadata"></video>' +
              '<div class="row" style="margin-top:.4rem;justify-content:space-between">' +
                '<span class="mini">❤️ ' + likes + ' · ▶ ' + (r.views || 0) + '</span>' +
                '<span class="mini">' + esc(timeAgo(r.createdAt)) + '</span>' +
              '</div>' +
            '</div>';
          }).join('');
          qsa('[data-reelopen]', box).forEach(function (n) {
            n.addEventListener('click', function () { safeCall('openReels', [n.getAttribute('data-reelopen')]); });
          });
        }
      } else if (window.profileTab === 'saved') {
        var ids = Object.keys(window.savedPosts || {});
        var list = ids.map(function (id) { return pc.find(function (p) { return p.id === id; }); }).filter(Boolean);
        if (!list.length) {
          box.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('bookmark') + '</span><p>' + esc(T('no_posts')) + '</p></div>';
        } else {
          box.innerHTML = list.map(function (p) {
            try { if (typeof window.postHTML === 'function') return window.postHTML(p); } catch (e) {}
            return '';
          }).join('');
          safeCall('wirePostInteractions', [box]);
          safeCall('paintPostCounts');
          safeCall('observePostVideos', [box]);
        }
      } else if (window.profileTab === 'collections') {
        safeCall('openCollections');
      } else if (window.profileTab === 'restricted') {
        openRestrictedPosts();
      } else if (window.profileTab === 'missions') {
        openMissions();
      } else if (window.profileTab === 'leaderboard') {
        openLeaderboard();
      } else {
        if (!mine.length) {
          box.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('image') + '</span><p>' + esc(T('no_posts')) + '</p></div>';
        } else {
          box.innerHTML = mine.map(function (p) {
            try { if (typeof window.postHTML === 'function') return window.postHTML(p); } catch (e) {}
            return '';
          }).join('');
          safeCall('wirePostInteractions', [box]);
          safeCall('paintPostCounts');
          safeCall('observePostVideos', [box]);
        }
      }
    }

    renderTab();

    qsa('[data-ptab]', page).forEach(function (n) {
      n.addEventListener('click', function () {
        var newTab = n.getAttribute('data-ptab');

        if (newTab === 'missions') {
          if (typeof window.openMissions === 'function') window.openMissions();
          return;
        }
        if (newTab === 'leaderboard') {
          if (typeof window.openLeaderboard === 'function') window.openLeaderboard();
          return;
        }
        if (newTab === 'collections') {
          if (typeof window.openCollections === 'function') window.openCollections();
          return;
        }
        if (newTab === 'restricted') {
          if (typeof window.openRestrictedPosts === 'function') window.openRestrictedPosts();
          return;
        }

        window.profileTab = newTab;
        qsa('[data-ptab]', page).forEach(function (x) { x.classList.toggle('sel', x === n); });
        renderTab();
      });
    });

    var ov = qs('#openVisitors');
    if (ov) ov.addEventListener('click', function () { openVisitors(); });

    var pc1 = qs('#profCreate'); if (pc1) pc1.addEventListener('click', function () { safeCall('openComposer'); });
    var pe = qs('#profEdit'); if (pe) pe.addEventListener('click', function () { safeCall('openSettingPage', ['profile_settings']); });
    var ps = qs('#profShare'); if (ps) ps.addEventListener('click', function () { shareProfile(); });
    var psa = qs('#profSaved'); if (psa) psa.addEventListener('click', function () { safeCall('openSaved'); });
    var pp = qs('#profPinned'); if (pp) pp.addEventListener('click', function () { openPinboard(); });
    var pr = qs('#profRestricted'); if (pr) pr.addEventListener('click', function () { openRestrictedPosts(); });

    var wrap = qs('#myAvatarWrap');
    if (wrap) wrap.addEventListener('click', function () {
      if (mp.photo) safeCall('openViewer', [mp.photo]);
    });

    var coverEdit = qs('#coverEdit');
    if (coverEdit) coverEdit.addEventListener('click', function () {
      var inp = document.createElement('input');
      inp.type = 'file'; inp.accept = 'image/*';
      inp.addEventListener('change', async function () {
        var f = inp.files && inp.files[0]; if (!f) return;
        try {
          safeToast(T('uploading'));
          var comp = f;
          if (typeof window.compressImage === 'function') comp = await window.compressImage(f, 1200, 0.82);
          var url = null;
          if (typeof window.cloudinaryUpload === 'function') url = await window.cloudinaryUpload(comp, 'cover.jpg');
          if (!url) throw new Error('Upload failed');
          await window.db.ref('users/' + uid + '/cover').set(url);
          safeToast(T('saved'), 'ok');
        } catch (e) { safeToast(e.message || T('upload_failed'), 'err'); }
      });
      inp.click();
    });
  }

  /* ============ SHARE PROFILE ============ */
  async function shareProfile() {
    var mp = myProfile();
    var url = location.origin + location.pathname + '#u-' + myUid();
    var text = (mp.name || '') + ' · ' + T('app_name');
    try {
      if (navigator.share) await navigator.share({ title: T('app_name'), text: text, url: url });
      else if (navigator.clipboard) {
        await navigator.clipboard.writeText(text + '\n' + url);
        safeToast(T('profile_shared'), 'ok');
      } else safeToast(url);
    } catch (e) {}
  }

  /* ============ VISITORS ============ */
  async function recordVisit(uid) {
    if (!uid || uid === myUid()) return;
    if (!window.db) return;
    try {
      var ts = timeNow();

      try {
        var histRef = window.db.ref('profileVisitHistory/' + uid + '/' + myUid()).push();
        await histRef.set({ at: ts, by: myUid() });
      } catch (e) {}

      var ref = window.db.ref('profileVisits/' + uid + '/' + myUid());
      var snap = await ref.get();
      var cur = snap.val();
      if (cur && (ts - (cur.at || 0) < 3600000)) return;
      await ref.set({ at: ts, by: myUid() });
      try { window.bumpDaily && window.bumpDaily('visit', 1); } catch (e) {}
    } catch (e) {}
  }

  function openVisitors() {
    safeCall('openOverlay', ['ovVisitors']);
    var body = qs('#visitorsBody');
    if (!body) return;

    var list = Object.keys(window.visitorsCache || {}).map(function (u) {
      return { uid: u, at: window.visitorsCache[u] ? window.visitorsCache[u].at : 0 };
    }).sort(function (a, b) { return (b.at || 0) - (a.at || 0); });

    if (!list.length) {
      body.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('eye') + '</span><p>' + esc(T('no_visitors')) + '</p></div>';
      return;
    }

    body.innerHTML = list.map(function (v) {
      var u = findUser(v.uid) || { name: 'User', photo: '' };
      return '<div class="user-card" data-vuid="' + esc(v.uid) + '">' +
        avatarHTML(u.photo, u.name, 'av-40', v.uid) +
        '<div class="grow">' +
          '<div class="name">' + esc(u.name) + '</div>' +
          '<div class="mini">' + esc(timeAgo(v.at)) + '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    qsa('[data-vuid]', body).forEach(function (n) {
      n.addEventListener('click', function () {
        var vid = n.getAttribute('data-vuid');
        if (!vid) return;
        /* Do NOT close ovVisitors — stack visitor detail on top so back returns here */
        if (typeof window.openVisitorDetail === 'function') {
          window.openVisitorDetail(vid);
        } else {
          openUserProfile(vid);
        }
      });
    });
  }

  /* ============ MISSIONS ============ */
  function openMissions() {
    safeCall('openOverlay', ['ovMissions']);
    var body = qs('#missionsBody');
    if (!body) return;

    body.innerHTML = '<div class="loading-row"><span class="spinner"></span>' + esc(T('loading')) + '</div>';

    var uid = myUid();
    if (!window.db || !uid) { body.innerHTML = '<div class="empty"><p>Not ready</p></div>'; return; }

    var today = new Date().toISOString().slice(0, 10);
    var wk = 'w_' + Math.floor(timeNow() / (7 * 86400000));

    Promise.all([
      window.db.ref('dailyStats/' + uid + '/' + today).get(),
      window.db.ref('missionClaims/' + uid + '/' + today).get(),
      window.db.ref('xpLog/' + uid + '/' + today).get(),
      window.db.ref('weeklyStats/' + uid + '/' + wk).get(),
      window.db.ref('weeklyClaims/' + uid + '/' + wk).get()
    ]).then(function (results) {
      var st       = results[0].val() || {};
      var claims   = results[1].val() || {};
      var xpToday  = Number(results[2].val()) || 0;
      var wkSt     = results[3].val() || {};
      var wkClaims = results[4].val() || {};

      var missions = [
        { id:'m_login',      label:'Daily login',            target:1,  cur:Number(st.login||0),       xp:10 },
        { id:'m_post',       label:'Create a post',          target:1,  cur:Number(st.post||0),        xp:5  },
        { id:'m_post3',      label:'Create 3 posts today',   target:3,  cur:Number(st.post||0),        xp:15 },
        { id:'m_like',       label:'Like 5 posts',           target:5,  cur:Number(st.like||0),        xp:5  },
        { id:'m_like20',     label:'Like 20 posts',          target:20, cur:Number(st.like||0),        xp:20 },
        { id:'m_comment',    label:'Comment 3 times',        target:3,  cur:Number(st.comment||0),     xp:10 },
        { id:'m_msg',        label:'Send 10 chat messages',  target:10, cur:Number(st.message||0),     xp:10 },
        { id:'m_img',        label:'Send an image in chat',  target:1,  cur:Number(st.chat_image||0),  xp:15 },
        { id:'m_voice',      label:'Send a voice message',   target:1,  cur:Number(st.voice||0),       xp:15 },
        { id:'m_call',       label:'Complete a call',        target:1,  cur:Number(st.call||0),        xp:15 },
        { id:'m_reel',       label:'Watch 5 Reels',          target:5,  cur:Number(st.reel_watch||0),  xp:10 },
        { id:'m_reellike',   label:'React to a Reel',        target:1,  cur:Number(st.reel_like||0),   xp:5  },
        { id:'m_story',      label:'Watch 3 Stories',        target:3,  cur:Number(st.story_watch||0), xp:10 },
        { id:'m_storyreact', label:'React to a Story',       target:1,  cur:Number(st.story_react||0), xp:10 },
        { id:'m_game',       label:'Play a game',            target:1,  cur:Number(st.game||0),        xp:3  },
        { id:'m_game5',      label:'Play 5 games',           target:5,  cur:Number(st.game||0),        xp:15 },
        { id:'m_save',       label:'Save a post',            target:1,  cur:Number(st.save||0),        xp:5  },
        { id:'m_visit',      label:'Visit 3 profiles',       target:3,  cur:Number(st.visit||0),       xp:10 }
      ];
      var weekly = [
        { id:'w_post10', label:'Create 10 posts this week',  target:10, cur:Number(wkSt.post||0),    xp:50 },
        { id:'w_msg50',  label:'Send 50 messages this week', target:50, cur:Number(wkSt.message||0), xp:50 },
        { id:'w_call5',  label:'Complete 5 calls this week', target:5,  cur:Number(wkSt.call||0),    xp:50 },
        { id:'w_like50', label:'Like 50 posts this week',    target:50, cur:Number(wkSt.like||0),    xp:50 }
      ];

      body.innerHTML =
        '<div class="sec-title">' + esc(T('my_missions')) + '</div>' +
        '<div class="card"><div class="mini">Today\'s XP: <b>' + xpToday + '</b></div></div>' +
        missions.map(function (m) {
          var pct2 = Math.min(100, Math.round((m.cur / m.target) * 100));
          var done = m.cur >= m.target;
          var claimed = !!claims[m.id];
          return '<div class="mission ' + (done ? 'done' : '') + '">' +
            '<span class="ic" style="color:var(--accent)">' + svgIcon(done ? 'check' : 'target') + '</span>' +
            '<div class="grow">' +
              '<div style="font-weight:700;font-size:.86rem">' + esc(m.label) + '</div>' +
              '<div class="bar"><i style="width:' + pct2 + '%"></i></div>' +
              '<div class="mini" style="margin-top:.2rem">' + m.cur + '/' + m.target + ' · +' + m.xp + ' XP</div>' +
            '</div>' +
            (done
              ? (claimed
                  ? '<span class="chip">' + esc(T('mission_done')) + '</span>'
                  : '<button class="btn sm solid" data-claim="' + esc(m.id) + '" data-xp="' + m.xp + '">' + esc(T('claim')) + '</button>')
              : '') +
          '</div>';
        }).join('') +
        '<div class="sec-title">' + esc(T('weekly_missions')) + '</div>' +
        weekly.map(function (m) {
          var pct2 = Math.min(100, Math.round((m.cur / m.target) * 100));
          var done = m.cur >= m.target;
          var claimed = !!wkClaims[m.id];
          return '<div class="mission ' + (done ? 'done' : '') + '">' +
            '<span class="ic" style="color:var(--accent)">' + svgIcon(done ? 'check' : 'star') + '</span>' +
            '<div class="grow">' +
              '<div style="font-weight:700;font-size:.86rem">' + esc(m.label) + '</div>' +
              '<div class="bar"><i style="width:' + pct2 + '%"></i></div>' +
              '<div class="mini" style="margin-top:.2rem">' + m.cur + '/' + m.target + ' · +' + m.xp + ' XP</div>' +
            '</div>' +
            (done
              ? (claimed
                  ? '<span class="chip">' + esc(T('mission_done')) + '</span>'
                  : '<button class="btn sm solid" data-wclaim="' + esc(m.id) + '" data-xp="' + m.xp + '">' + esc(T('claim')) + '</button>')
              : '') +
          '</div>';
        }).join('');

      qsa('[data-claim]', body).forEach(function (b) {
        b.addEventListener('click', function () {
          claimMission(b.getAttribute('data-claim'), Number(b.getAttribute('data-xp')) || 0, false);
        });
      });
      qsa('[data-wclaim]', body).forEach(function (b) {
        b.addEventListener('click', function () {
          claimMission(b.getAttribute('data-wclaim'), Number(b.getAttribute('data-xp')) || 0, true);
        });
      });
    }).catch(function () {
      body.innerHTML = '<div class="empty"><p>' + esc(T('error')) + '</p></div>';
    });
  }

  /* ============ CLAIM MISSION ============ */
  async function claimMission(missionId, xp, weekly) {
    if (!missionId) return false;
    var uid = myUid();
    var fbDb = window.db;
    if (!uid || !fbDb) return false;

    var today = new Date().toISOString().slice(0, 10);
    var wk = 'w_' + Math.floor(timeNow() / (7 * 86400000));
    var path = weekly
      ? ('weeklyClaims/' + uid + '/' + wk + '/' + missionId)
      : ('missionClaims/' + uid + '/' + today + '/' + missionId);

    var ref = fbDb.ref(path);
    try {
      var snap = await ref.get();
      if (snap.exists()) { safeToast(T('mission_done')); return false; }

      await ref.set({ at: timeNow(), xp: xp });

      await fbDb.ref('users/' + uid + '/xp')
        .transaction(function (cur) { return (Number(cur) || 0) + xp; });

      await fbDb.ref('xpLog/' + uid + '/' + today)
        .transaction(function (v) { return (Number(v) || 0) + xp; });

      var notifRef = fbDb.ref('notifications/' + uid).push();
      await notifRef.set({
        id: notifRef.key,
        type: 'mission',
        fromName: T('app_name'),
        text: T('mission_done') + ' +' + xp + ' XP',
        createdAt: timeNow(),
        read: false
      });

      safeToast('+' + xp + ' XP', 'ok');
      openMissions();
      return true;
    } catch (e) {
      safeToast(e.message || T('error'), 'err');
      return false;
    }
  }

  /* ============ LEADERBOARD ============ */
  function openLeaderboard() {
    safeCall('openOverlay', ['ovLeaderboard']);
    var body = qs('#leaderboardBody');
    if (!body) return;
    body.innerHTML = '<div class="loading-row"><span class="spinner"></span>' + esc(T('loading')) + '</div>';
    if (!window.db) { body.innerHTML = '<div class="empty"><p>Not ready</p></div>'; return; }

    window.db.ref('users').orderByChild('xp').limitToLast(50).once('value').then(function (snap) {
      var v = snap.val() || {};
      var list = Object.keys(v).map(function (k) { return Object.assign({ uid: k }, v[k]); })
                                 .sort(function (a, b) { return (b.xp || 0) - (a.xp || 0); });
      if (!list.length) { body.innerHTML = '<div class="empty"><p>' + esc(T('no_results')) + '</p></div>'; return; }
      body.innerHTML = list.map(function (u, i) {
        return '<div class="lb-item ' + (i < 3 ? 'top' + (i + 1) : '') + '" data-luid="' + esc(u.uid) + '">' +
          '<div class="lb-rank">' + (i + 1) + '</div>' +
          avatarHTML(u.photo, u.name, 'av-40', u.uid) +
          '<div class="grow"><div class="name">' + esc(u.name || 'User') + '</div>' +
            '<div class="mini">Lv ' + levelFromXp(u.xp) + '</div></div>' +
          '<div class="chip">' + esc(String(u.xp || 0)) + ' XP</div>' +
        '</div>';
      }).join('');
      qsa('[data-luid]', body).forEach(function (n) {
        n.addEventListener('click', function () {
          safeCall('closeOverlay', ['ovLeaderboard']);
          openUserProfile(n.getAttribute('data-luid'));
        });
      });
    }).catch(function () { body.innerHTML = '<div class="empty"><p>' + esc(T('error')) + '</p></div>'; });
  }

  /* ============ PINBOARD ============ */
  function openPinboard() {
    safeCall('openOverlay', ['ovPinBoard']);
    var body = qs('#pinBoardBody');
    if (!body) return;
    var mp = myProfile();
    var pin = mp.pinnedPosts || {};
    var pc = postsCache();
    var list = Object.keys(pin).map(function (id) { return pc.find(function (p) { return p.id === id; }); }).filter(Boolean);
    if (!list.length) { body.innerHTML = '<div class="empty"><p>' + esc(T('no_posts')) + '</p></div>'; return; }
    body.innerHTML = list.map(function (p) {
      try { if (typeof window.postHTML === 'function') return window.postHTML(p); } catch (e) {}
      return '';
    }).join('');
    safeCall('wirePostInteractions', [body]);
    safeCall('paintPostCounts');
    safeCall('observePostVideos', [body]);
  }

  /* ============ RESTRICTED POSTS ============ */
  function openRestrictedPosts() {
    safeCall('openOverlay', ['ovRestricted']);
    if (typeof window.renderRestrictedPosts === 'function') {
      window.renderRestrictedPosts();
    } else {
      renderRestricted();
    }
  }

  function renderRestricted() {
    var body = qs('#restrictedBody');
    if (!body) return;
    var pc = postsCache();
    var uid = myUid();
    var list = pc.filter(function (p) {
      return p.uid === uid && p.suspended === true;
    }).sort(function (a, b) { return (b.suspendedAt || b.createdAt || 0) - (a.suspendedAt || a.createdAt || 0); });

    if (!list.length) {
      body.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('shield') + '</span><p>No restricted posts</p></div>';
      return;
    }

    body.innerHTML = list.map(function (p) {
      var reason = p.suspendReason || 'Violated community guidelines';
      var since = p.suspendedAt || p.createdAt;
      return '<div class="card">' +
        '<span class="restricted-badge">' + svgIcon('alert') + ' ' + esc(T('restricted')) + '</span>' +
        (p.text ? '<div class="post-text" style="margin-top:.5rem">' + esc(String(p.text).slice(0, 220)) + '</div>' : '') +
        '<div class="mini" style="margin-top:.4rem"><b>' + esc(T('restriction_reason')) + ':</b> ' + esc(reason) + '</div>' +
        '<div class="mini"><b>' + esc(T('suspended_on')) + ':</b> ' + esc(fmtDate(since)) + '</div>' +
        '<button class="btn sm solid" data-rr-open="' + esc(p.id) + '" style="margin-top:.6rem">' + esc(T('request_review')) + '</button>' +
      '</div>';
    }).join('');

    qsa('[data-rr-open]', body).forEach(function (n) {
      n.addEventListener('click', function () { openRestrictionRequest(n.getAttribute('data-rr-open')); });
    });
  }

  /* ============ RESTRICTION REQUEST ============ */
  function openRestrictionRequest(postId) {
    if (!postId) return;
    var pc = postsCache();
    var p = pc.find(function (x) { return x.id === postId; });
    if (!p) return;
    var rrTitle = qs('#rrTitle');
    var rrPreview = qs('#rrPostPreview');
    var rrReason = qs('#rrReason');
    var rrMsg = qs('#rrMessage');
    var rrCancel = qs('#rrCancel');
    var rrSubmit = qs('#rrSubmit');
    if (rrTitle) rrTitle.textContent = T('request_review');
    if (rrPreview) rrPreview.textContent = String(p.text || '').slice(0, 120) || '(no text)';
    if (rrReason) rrReason.textContent = p.suspendReason || 'Violated community guidelines';
    if (rrMsg) rrMsg.value = '';
    safeCall('openOverlay', ['ovRestrictionRequest']);

    if (rrCancel) rrCancel.onclick = function () { safeCall('closeOverlay', ['ovRestrictionRequest']); };
    if (rrSubmit) rrSubmit.onclick = async function () {
      var msg = rrMsg ? rrMsg.value.trim() : '';
      try {
        var ref = window.db.ref('restrictionRequests').push();
        await ref.set({
          requestId: ref.key,
          uid: myUid(),
          userName: (myProfile().name || ''),
          postId: postId,
          reason: p.suspendReason || '',
          message: msg || 'Please review my suspended post.',
          createdAt: timeNow(),
          status: 'pending',
          reviewedBy: '', reviewedAt: 0, adminReply: ''
        });
        safeCall('closeOverlay', ['ovRestrictionRequest']);
        safeToast(T('review_request_sent'), 'ok');
      } catch (e) { safeToast(e.message || T('error'), 'err'); }
    };
  }

  /* ============ USER PROFILE ============ */
  async function openUserProfile(uid) {
    if (!uid) return;
    if (uid === myUid()) { safeCall('navigate', ['profile']); return; }

    var body = qs('#profileViewBody');
    if (!body) return;
    body.innerHTML = '<div style="padding:1rem"><div class="skeleton" style="height:6rem"></div></div>';
    safeCall('openOverlay', ['ovProfile']);
    recordVisit(uid);

    var u = findUser(uid);
    if (!u && window.db) {
      try {
        var s = await window.db.ref('users/' + uid).get();
        u = s.val();
        if (u) u = Object.assign({ uid: uid }, u);
      } catch (e) {}
    }
    if (!u) { body.innerHTML = '<div class="empty"><p>' + esc(T('no_results')) + '</p></div>'; return; }

    var blocked = false;
    try { blocked = window.iBlocked ? window.iBlocked(uid) : !!(window.blockedUsers && window.blockedUsers[uid]); } catch (e) {}

    var isOn = window.onlineUsers && window.onlineUsers[uid];
    var sub = isOn ? T('online') : (u.lastSeen ? T('offline') + ' · ' + timeAgo(u.lastSeen) : T('offline'));

    var pc = postsCache();
    var posts = pc.filter(function (p) { return p.uid === uid && !p.suspended; })
                  .sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); });
    var photoPosts = posts.filter(function (p) { return p.image || (p.images && p.images.length); });

    var xp = Number(u.xp) || 0;
    var lv = levelFromXp(xp);
    var totalLikes = posts.reduce(function (s, p) { return s + countLikes(p.id); }, 0);

    body.innerHTML =
      '<div class="cover-wrap">' + (u.cover ? '<img src="' + esc(u.cover) + '" alt="">' : '') + '</div>' +
      '<div class="prof-head" style="padding-top:0">' +
        '<div id="upAvatarWrap" style="margin-top:-2.4rem">' + avatarHTML(u.photo, u.name, 'av-88', uid) + '</div>' +
        '<div class="nm">' + esc(u.name || 'User') + '</div>' +
        '<div class="muted">' + esc(sub) + '</div>' +
        '<div class="bio">' + esc(u.bio || '—') + '</div>' +
        '<div class="xp-wrap">' +
          '<div class="row" style="justify-content:space-between;font-size:.72rem;color:var(--muted)">' +
            '<span>Lv ' + lv + '</span><span>' + xp + ' XP</span>' +
          '</div>' +
          '<div class="xp-bar"><i style="width:100%"></i></div>' +
        '</div>' +
        '<div class="stat-row">' +
          '<div class="stat"><b>' + posts.length + '</b>' + esc(T('total_posts')) + '</div>' +
          '<div class="stat"><b>' + photoPosts.length + '</b>' + esc(T('total_photos')) + '</div>' +
          '<div class="stat"><b>' + totalLikes + '</b>' + esc(T('like')) + '</div>' +
        '</div>' +
        '<div class="row" style="gap:.5rem;margin-top:.7rem;flex-wrap:wrap;justify-content:center">' +
          '<button class="btn solid" id="upChat">' + esc(T('start_chat')) + '</button>' +
          '<button class="btn ghost sm" id="upCall">' + esc(T('call')) + '</button>' +
          '<button class="btn ghost sm" id="upVideo">' + esc(T('video_call')) + '</button>' +
          '<button class="btn ghost sm" id="upBlock">' + esc(blocked ? T('unblock') : T('block')) + '</button>' +
          '<button class="btn ghost sm" id="upReport">' + esc(T('report')) + '</button>' +
          '<button class="btn ghost sm" id="upShare">' + esc(T('share_profile')) + '</button>' +
        '</div>' +
      '</div>' +
      '<div style="padding:0 .8rem 1.5rem">' +
        '<div class="card" style="padding:.7rem">' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('dob')) + '</span><b>' + esc(u.dob || '—') + '</b></div>' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('relationship')) + '</span><b>' + esc(u.relationship || '—') + '</b></div>' +
          '<div class="row" style="justify-content:space-between;padding:.35rem 0"><span class="muted">' + esc(T('joining')) + '</span><b>' + esc(fmtDate(u.createdAt)) + '</b></div>' +
        '</div>' +
        '<div class="sec-title">' + esc(T('posts')) + '</div>' +
        '<div id="upPosts"></div>' +
      '</div>';

    var postsBox = qs('#upPosts');
    if (postsBox) {
      if (!posts.length) {
        postsBox.innerHTML = '<div class="empty"><span class="ic">' + svgIcon('image') + '</span><p>' + esc(T('no_posts')) + '</p></div>';
      } else {
        postsBox.innerHTML = posts.map(function (p) {
          try { if (typeof window.postHTML === 'function') return window.postHTML(p); } catch (e) {}
          return '';
        }).join('');
        safeCall('wirePostInteractions', [postsBox]);
        safeCall('paintPostCounts');
        safeCall('observePostVideos', [postsBox]);
      }
    }

    var upChat = qs('#upChat');
    if (upChat) upChat.addEventListener('click', function () { safeCall('closeOverlay', ['ovProfile']); safeCall('startDirectChat', [uid]); });
    var upCall = qs('#upCall');
    if (upCall) upCall.addEventListener('click', function () { safeCall('startCall', [uid, 'audio', u.name, u.photo]); });
    var upVideo = qs('#upVideo');
    if (upVideo) upVideo.addEventListener('click', function () { safeCall('startCall', [uid, 'video', u.name, u.photo]); });
    var upBlock = qs('#upBlock');
    if (upBlock) upBlock.addEventListener('click', function () { safeCall('toggleBlock', [uid]) || safeCall('blockUser', [uid]); });
    var upReport = qs('#upReport');
    if (upReport) upReport.addEventListener('click', function () { safeCall('openReport', ['user', uid, null]); });
    var upShare = qs('#upShare');
    if (upShare) upShare.addEventListener('click', function () {
      var url = location.origin + location.pathname + '#u-' + uid;
      if (navigator.share) navigator.share({ title: T('app_name'), text: u.name, url: url }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(url).then(function () { safeToast(T('link_copied'), 'ok'); }).catch(function () {});
      else safeToast(url);
    });

    var wrap2 = qs('#upAvatarWrap');
    if (wrap2) wrap2.addEventListener('click', function () { if (u.photo) safeCall('openViewer', [u.photo]); });
  }

  /* ============ EXPOSE ============ */
  window.renderProfilePage      = renderProfilePage;
  window.openUserProfile        = openUserProfile;
  window.shareProfile           = shareProfile;
  window.openVisitors           = openVisitors;
  window.recordVisit            = recordVisit;
  window.openMissions           = openMissions;
  window.claimMission           = claimMission;
  window.openLeaderboard        = openLeaderboard;
  window.openPinboard           = openPinboard;
  window.openRestrictedPosts    = openRestrictedPosts;
  window.renderRestrictedPosts  = renderRestricted;
  window.openRestrictionRequest = openRestrictionRequest;
  window.levelFromXp            = levelFromXp;
  window.xpForLevel             = xpForLevel;

  window.SaikoPages = {
    renderProfilePage: renderProfilePage,
    openUserProfile: openUserProfile,
    openVisitors: openVisitors,
    openMissions: openMissions,
    claimMission: claimMission,
    openLeaderboard: openLeaderboard,
    openPinboard: openPinboard,
    openRestrictedPosts: openRestrictedPosts,
    levelFromXp: levelFromXp,
    xpForLevel: xpForLevel
  };

  try { console.debug('[boot] page-renderers ready (v5 — overlay stacking)'); } catch (e) {}
})();