/* ============================================================
 * FEATURE:        Visitor Detail Page
 * FILE:           js/pages/visitor-detail.js
 * ACTION:         CREATE
 * ------------------------------------------------------------
 * PURPOSE:
 *   Naya overlay #ovVisitorDetail jab user Profile Visitors list
 *   me kisi visitor pe click kare. Isme:
 *     • Visitor ka profile card + "View Profile" button
 *     • Neeche poori visit history — date + time + timeAgo
 * ============================================================ */

(function () {
  'use strict';

  function qs(s, r) { return (r || document).querySelector(s); }
  function qsa(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  function T(k) {
    try { if (typeof t === 'function') return t(k); } catch (e) {}
    return k;
  }
  function esc(s) {
    try { if (typeof window.esc === 'function') return window.esc(s); } catch (e) {}
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
    });
  }
  function timeNow() {
    try { if (typeof window.now === 'function') return window.now(); } catch (e) {}
    return Date.now();
  }
  function fmtDate(ts) {
    try { if (typeof window.fmtDate === 'function') return window.fmtDate(ts); }
    catch (e) {}
    if (!ts) return '—';
    try { return new Date(ts).toLocaleDateString(); } catch (e) { return '—'; }
  }
  function fmtTime(ts) {
    try { if (typeof window.fmtTime === 'function') return window.fmtTime(ts); }
    catch (e) {}
    if (!ts) return '';
    try { return new Date(ts).toLocaleTimeString(); } catch (e) { return ''; }
  }
  function timeAgo(ts) {
    try { if (typeof window.timeAgo === 'function') return window.timeAgo(ts); }
    catch (e) {}
    return '';
  }
  function findUser(uid) {
    try { if (typeof window.findUser === 'function') return window.findUser(uid); }
    catch (e) {}
    return null;
  }
  function avatarHTML(url, name, cls, uid) {
    try {
      if (typeof window.avatarHTML === 'function') {
        return window.avatarHTML(url, name, cls, uid);
      }
    } catch (e) {}
    return '';
  }
  function svgIcon(name, fill) {
    try { return window.svgIcon(name, fill) || ''; } catch (e) { return ''; }
  }
  function safeCall(name, args) {
    try {
      var fn = window[name];
      if (typeof fn === 'function') return fn.apply(window, args || []);
    } catch (e) { console.warn('[visitor-detail] safeCall:', name, e); }
    return undefined;
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db) return db; } catch (e) {}
    return null;
  }
  function getMyUid() {
    try {
      return (typeof window.myUid !== 'undefined' && window.myUid) ? window.myUid : null;
    } catch (e) { return null; }
  }

  /* ============================================================
   * OPEN — main entry point
   * ============================================================ */
  async function openVisitorDetail(visitorUid) {
    if (!visitorUid) return false;

    var body = qs('#visitorDetailBody');
    if (!body) {
      console.warn('[visitor-detail] #visitorDetailBody missing');
      return false;
    }

    safeCall('openOverlay', ['ovVisitorDetail']);

    body.innerHTML =
      '<div class="loading-row">' +
        '<span class="spinner"></span>' +
        esc(T('loading') || 'Loading...') +
      '</div>';

    var me = getMyUid();
    var u = findUser(visitorUid) || { name: 'User', photo: '' };

    /* ---- Load full visit history ---- */
    var entries = [];
    var fbDb = getDB();

    if (fbDb && me) {
      try {
        var snap = await fbDb.ref('profileVisitHistory/' + me + '/' + visitorUid).get();
        var v = snap.val() || {};
        entries = Object.keys(v).map(function (k) {
          var item = v[k] || {};
          return {
            id: k,
            at: Number(item.at) || 0
          };
        }).filter(function (x) { return x.at > 0; })
          .sort(function (a, b) { return b.at - a.at; });
      } catch (e) {
        console.warn('[visitor-detail] history read failed', e);
      }

      /* Fallback — agar history empty hai (purana data), summary se 1 entry dikha do */
      if (!entries.length) {
        try {
          var sumSnap = await fbDb.ref('profileVisits/' + me + '/' + visitorUid).get();
          var sum = sumSnap.val();
          if (sum && sum.at) {
            entries.push({ id: '_summary', at: Number(sum.at) });
          }
        } catch (e) {}
      }
    }

    /* ---- Build history list HTML ---- */
    var historyHTML;
    if (!entries.length) {
      historyHTML =
        '<div class="empty" style="padding:1.4rem .6rem">' +
          '<span class="ic">' + svgIcon('eye') + '</span>' +
          '<p>No visits recorded yet</p>' +
        '</div>';
    } else {
      historyHTML = entries.map(function (x) {
        var d = fmtDate(x.at);
        var t = fmtTime(x.at);
        var ago = timeAgo(x.at);
        return (
          '<div class="hist-item">' +
            '<span class="ic" style="color:var(--accent)">' + svgIcon('clock') + '</span>' +
            '<div class="grow">' +
              '<div style="font-weight:700;font-size:.86rem">' +
                esc(d) + ' · ' + esc(t) +
              '</div>' +
              '<div class="mini">' + esc(ago) + '</div>' +
            '</div>' +
          '</div>'
        );
      }).join('');
    }

    /* ---- Compose the page ---- */
    body.innerHTML =
      '<div class="prof-head" style="padding:1rem .8rem .4rem">' +
        '<div id="vdAvatarWrap" style="cursor:pointer">' +
          avatarHTML(u.photo, u.name, 'av-88', visitorUid) +
        '</div>' +
        '<div class="nm" style="margin-top:.4rem">' + esc(u.name || 'User') + '</div>' +
        (u.bio ? '<div class="bio">' + esc(u.bio) + '</div>' : '') +
        '<button class="btn solid block" id="vdOpenProfile" ' +
                'style="max-width:18rem;margin-top:.7rem">' +
          esc(T('view_profile') || 'View Profile') +
        '</button>' +
      '</div>' +
      '<div style="padding:.4rem .8rem 1.4rem">' +
        '<div class="sec-title">Visit History (' + entries.length + ')</div>' +
        historyHTML +
      '</div>';

    /* ---- Wire "View Profile" button ---- */
    var openBtn = qs('#vdOpenProfile');
    if (openBtn) {
      openBtn.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovVisitorDetail']);
        setTimeout(function () {
          safeCall('openUserProfile', [visitorUid]);
        }, 150);
      });
    }

    /* ---- Wire avatar click → profile ---- */
    var avWrap = qs('#vdAvatarWrap');
    if (avWrap) {
      avWrap.addEventListener('click', function () {
        safeCall('closeOverlay', ['ovVisitorDetail']);
        setTimeout(function () {
          safeCall('openUserProfile', [visitorUid]);
        }, 150);
      });
    }

    return true;
  }

  /* ============================================================
   * PUBLIC API
   * ============================================================ */
  window.openVisitorDetail = openVisitorDetail;

  window.SaikoVisitorDetail = {
    open: openVisitorDetail
  };

  try {
    console.debug('[boot] visitor-detail ready');
  } catch (e) {}
})();