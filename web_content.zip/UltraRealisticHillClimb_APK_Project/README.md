# Ultra Realistic Hill Climb - Android APK Project

This project wraps the supplied single-file HTML game in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

The generated APK will be under `app/build/outputs/apk/`.
