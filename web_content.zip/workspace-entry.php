<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';

/** Execute a legacy workspace implementation from its clean folder URL. */
function anonymoux_workspace_entry(string $sourceFile, string $routeKey, string $navKey): void
{
    $requestPath = parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    $scriptDirectory = rtrim(str_replace('\\', '/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
    $isDirectIndex = is_string($requestPath) && str_ends_with(rtrim($requestPath, '/'), '/index.php');
    $isDirectoryWithoutSlash = is_string($requestPath) && $scriptDirectory !== '' && $requestPath === $scriptDirectory;
    if ($isDirectIndex || $isDirectoryWithoutSlash) {
        $canonical = app_base_path() . trim($navKey, '/');
        if (!str_contains(basename($navKey), '.')) $canonical .= '/';
        $query = (string)($_SERVER['QUERY_STRING'] ?? '');
        if ($query !== '') $canonical .= '?' . $query;
        header('Location: ' . $canonical, true, 301);
        exit;
    }
    if (!defined('ANONYMOUX_WORKSPACE_INCLUDE')) define('ANONYMOUX_WORKSPACE_INCLUDE', true);
    $platformBaseHref = app_base_path();
    $workspaceRoute = $routeKey;
    $workspaceNavKey = $navKey;
    require __DIR__ . '/' . $sourceFile;
}
