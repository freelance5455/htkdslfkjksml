# Carreira de Craque v1.62.36 — Serie A TIM

## Implementado
- Adicionada a Serie A TIM ao menu Ligas → Europa.
- Incluídos os 20 clubes enviados pelo usuário: Atalanta, Bologna, Cagliari, Como, Fiorentina, Frosinone, Genoa, Inter, Juventus, Lazio, Lecce, Milan, Monza, Napoli, Parma, Roma, Sassuolo, Torino, Udinese e Venezia.
- Integrados os endereços de escudos fornecidos pelo usuário ao cadastro visual dos clubes.
- Adicionada a seleção de Itália no fluxo de criação de carreira e seleção dos 20 clubes profissionais.
- Carreira italiana inicia com calendário de 38 rodadas (turno e returno), 380 partidas, classificação e identificação correta da competição.
- Incluída a avaliação individual de estrelas dos clubes italianos.
- Criado roteamento de imprensa italiano para La Gazzetta dello Sport, com equipe de jornalistas própria, separado de GE, Sky Sports e MARCA.
- A Serie A TIM é preservada ao iniciar novas temporadas e ao restaurar uma carreira italiana.

## Observações
- Os links de escudos foram integrados conforme enviados. Como parte deles aponta para páginas e não para arquivos de imagem diretos, o navegador pode exibir o escudo alternativo caso o endereço não entregue uma imagem.
- Esta atualização adiciona clubes, competição e estrutura de carreira; não inclui ainda elencos licenciados completos nem uniformes italianos.
- Não foram apagadas carreiras salvas nesta atualização.
