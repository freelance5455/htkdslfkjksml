<?php
session_start();
require_once __DIR__ . '/includes.php';
if (is_logged_in()) { header('Location: dashboard.php'); exit; }
$pageTitle = 'Главная';
include __DIR__ . '/header.php';
?>
<section class="hero">
  <div class="eyebrow">ТЕСТОВЫЙ ПРОЕКТ · PHP</div>
  <h1>Твой сайт.<br><span>Твои правила.</span></h1>
  <p>Небольшой многостраничный сайт с регистрацией, авторизацией и личным кабинетом. Можно загрузить на PHP-хостинг.</p>
  <div class="actions"><a class="btn primary" href="register.php">Создать аккаунт</a><a class="btn secondary" href="login.php">Войти</a></div>
</section>
<section class="features">
  <article class="feature"><div class="feature-icon">01</div><h3>Аккаунт</h3><p>Регистрация и вход с проверкой пароля.</p></article>
  <article class="feature"><div class="feature-icon">02</div><h3>Несколько страниц</h3><p>Главная, о проекте, вход, регистрация и кабинет.</p></article>
  <article class="feature"><div class="feature-icon">03</div><h3>Личный кабинет</h3><p>Приветствие и данные текущего пользователя.</p></article>
</section>
<?php include __DIR__ . '/footer.php'; ?>