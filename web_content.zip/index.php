<?php
declare(strict_types=1);
require_once __DIR__ . '/app/bootstrap.php';
workspace_legacy_redirect('realtime/');
require_once __DIR__ . '/app/auth.php';
require_once __DIR__ . '/app/voice.php';
require_once __DIR__ . '/app/credits.php';
$user = auth_require_user();
$realtimeCreditRate=billing_price('realtime')??10;
$topbarBalance = voice_wallet_balance((int)$user['id']);
$csrf = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
$model25Enabled=platform_model_enabled('lucy-2.5'); $model26Enabled=platform_model_enabled('lucy-2.6');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#111318">
  <base href="<?=htmlspecialchars((string)($platformBaseHref ?? '/'), ENT_QUOTES, 'UTF-8')?>">
  <title>ANONYMOUX STUDIOS — Realtime Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="icon" type="image/png" sizes="32x32" href="assets/branding/favicon-32.png"><link rel="apple-touch-icon" href="assets/branding/anonymoux-icon-192.png">
  <link rel="stylesheet" href="assets/style.css?v=2.6.2">
  <link rel="stylesheet" href="assets/navigation.css?v=2.6.2">
  <link rel="stylesheet" href="assets/platform-pages.css?v=2.6.2">
<link rel="stylesheet" href="assets/visual-refresh.css?v=2.6.2">
  <link rel="stylesheet" href="assets/glass-notifications.css?v=2.6.2">
  <link rel="stylesheet" href="assets/anonymoux-red-overrides.css?v=2.6.2"><link rel="stylesheet" href="assets/theme-system.css?v=2.6.2"></head>
<body>
  <div class="studio-layout" id="studioLayout">
    <aside class="studio-sidebar" id="studioSidebar" aria-label="Primary navigation">
      <a class="sidebar-brand" href="dashboard.php" aria-label="ANONYMOUX STUDIOS dashboard"><img class="sidebar-brand-logo" src="assets/branding/anonymoux-icon-192.png" alt="ANONYMOUX emblem"><span><strong>ANONYMOUX</strong><small>STUDIOS</small></span></a>
      <nav class="sidebar-nav" aria-label="Workspace navigation">
        <div class="sidebar-caption sidebar-caption-primary">DASHBOARD</div>
        <a class="sidebar-link" href="dashboard.php"><span class="nav-icon" data-icon="grid"></span><span>Dashboard</span></a>
        <div class="sidebar-caption nav-section-caption">CREATIVE WORKSPACES</div>
        <a class="sidebar-link" href="image/"><span class="nav-icon" data-icon="image"></span><span>Image Studio</span></a>
        <a class="sidebar-link" href="video/"><span class="nav-icon" data-icon="film"></span><span>Video Edit Studio</span></a>
        <a class="sidebar-link" href="realtime/" aria-current="page"><span class="nav-icon" data-icon="cpu"></span><span>Realtime Studio</span><span class="nav-state">LIVE</span></a>
        <a class="sidebar-link" href="lip-sync/"><span class="nav-icon" data-icon="audio-lines"></span><span>Lip Sync Studio</span></a>
        <div class="sidebar-caption nav-section-caption">AI CREATION</div>
        <a class="sidebar-link" href="voice/"><span class="nav-icon" data-icon="audio"></span><span>Voice Cloning Studio</span></a>
        <a class="sidebar-link" href="agents/"><span class="nav-icon" data-icon="bot"></span><span>AI Agent Studio</span></a>
        <a class="sidebar-link" href="agents/?section=whatsapp#whatsapp-deployments"><span class="nav-icon" data-icon="phone-call"></span><span>WhatsApp Deployments</span></a>
        <div class="sidebar-caption nav-section-caption">YOUR LIBRARY</div>
        <a class="sidebar-link" href="projects.php"><span class="nav-icon" data-icon="folder"></span><span>Projects</span></a>
        <a class="sidebar-link" href="assets.php"><span class="nav-icon" data-icon="layers"></span><span>Assets</span></a>
        <a class="sidebar-link" href="history.php"><span class="nav-icon" data-icon="history"></span><span>History</span></a>
        <div class="sidebar-caption nav-section-caption">ACCOUNT</div>
        <a class="sidebar-link" href="credits.php"><span class="nav-icon" data-icon="wallet"></span><span>Buy Credits</span></a>
        <a class="sidebar-link" href="tools-tutorials.php"><span class="nav-icon" data-icon="book-open"></span><span>Tools &amp; Tutorials</span></a>
        <a class="sidebar-link" href="settings.php"><span class="nav-icon" data-icon="settings"></span><span>Settings</span></a>
        <?php if(($user['role']??'')==='admin'): ?><div class="sidebar-caption nav-section-caption">ADMINISTRATION</div><a class="sidebar-link" href="admin.php"><span class="nav-icon" data-icon="settings"></span><span>Admin console</span></a><?php endif; ?>
      </nav>
      <div class="sidebar-bottom"><span class="sidebar-status-dot"></span><span class="sidebar-account-copy"><strong><?=htmlspecialchars($user['name'],ENT_QUOTES,'UTF-8')?></strong><small><?=htmlspecialchars(ucfirst((string)($user['role']??'member')),ENT_QUOTES,'UTF-8')?> account</small></span><form class="sidebar-logout-form" method="post" action="logout.php"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><button type="submit" aria-label="Sign out" title="Sign out">↗</button></form></div>
    </aside>
    <button class="sidebar-backdrop" id="sidebarBackdrop" type="button" aria-label="Close navigation"></button>
    <div class="studio-main">
    <header class="topbar">
      <button class="nav-toggle" id="navToggle" type="button" aria-label="Open navigation" aria-expanded="false"><span></span><span></span><span></span></button>
      <div class="topbar-spacer" aria-hidden="true"></div>
      <div class="topbar-right">
        <div class="topbar-notifications" data-notification-center><button class="notification-bell" type="button" aria-label="Notifications" aria-expanded="false" aria-controls="notificationPanel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg><span class="notification-count" hidden>0</span></button><section class="notification-panel" id="notificationPanel" aria-label="Notifications"><div class="notification-panel-head"><strong>Notifications</strong><span class="notification-panel-actions"><button type="button" data-read-all>Mark all read</button><button class="notification-sound-toggle" type="button" aria-label="Mute notification sound">♫</button></span></div><div class="notification-list"><div class="notification-empty">Loading notifications…</div></div></section></div>
        <button class="theme-toggle" id="themeToggle" type="button" aria-label="Switch color theme" title="Switch color theme"><span class="theme-icon">☼</span></button>
        <a class="topbar-balance-chip" href="credits.php" aria-label="Wallet balance: <?=number_format($topbarBalance)?> credits"><span class="balance-chip-label">BALANCE</span><strong><?=number_format($topbarBalance)?></strong><small>credits</small></a>
        <div class="connection-pill" id="connectionPill"><span class="status-dot"></span><span id="connectionText">Ready to connect</span></div>
        <button class="icon-button reset-top" id="resetBtn" type="button" title="Reset workspace" aria-label="Reset workspace">↺</button>
      </div>
    </header>

    <main class="main-content">
      <section class="intro-row">
        <div>
          <div class="eyebrow"><span class="eyebrow-line"></span> LIVE VIDEO TRANSFORMATION</div>
          <h1>Your realtime <em>creative studio.</em></h1>
          <p class="intro-copy">Choose a model, shape your look, and transform your live camera feed.</p>
        </div>
        <div class="studio-tag"><span class="pulse-dot"></span> WEBRTC WORKSPACE</div>
      </section>

      <div class="config-warning" id="configWarning" hidden>
        <strong>Decart is not configured.</strong>
        <span>Add your permanent API key to <code>config.local.php</code> on the server. The key is never sent to the browser.</span>
      </div>

      <section class="workspace-section" id="realtimeWorkspace" aria-labelledby="workspaceHeading">
        <div class="workspace-title-row"><div><div class="eyebrow"><span class="eyebrow-line"></span> LIVE PREVIEW</div><h2 id="workspaceHeading">Realtime workspace</h2></div><div class="camera-permission" id="cameraPermission"><span class="permission-dot"></span><span>Camera permission: checking…</span></div></div>
        <div class="video-grid">
          <div class="video-panel">
            <div class="video-panel-header"><span><i class="frame-number">A</i> INPUT</span><span class="frame-status" id="inputFrameStatus">CAMERA OFF</span></div>
            <div class="video-stage" id="inputStage"><video id="inputVideo" autoplay muted playsinline></video><div class="video-empty" id="inputEmpty"><span class="camera-icon">◎</span><strong>Camera input</strong><small>Your live camera feed appears here</small></div><span class="video-live-label" id="inputLiveLabel" hidden>LIVE INPUT</span></div>
          </div>
          <div class="video-panel output-panel">
            <div class="video-panel-header"><span><i class="frame-number output-number">B</i> TRANSFORMED OUTPUT</span><span class="frame-status output-frame-status" id="outputFrameStatus">WAITING FOR SESSION</span></div>
            <div class="video-stage output-stage" id="outputStage"><video id="outputVideo" autoplay muted playsinline></video><div class="video-empty output-empty" id="outputEmpty"><span class="output-spark">✳</span><strong>Your transformed output</strong><small>Start a session to see Decart’s live result</small></div><span class="video-live-label" id="outputLiveLabel" hidden>LIVE OUTPUT</span><button class="fullscreen-button" id="fullscreenOutputBtn" type="button" aria-label="Fullscreen transformed output" title="Fullscreen output">⛶</button></div>
          </div>
        </div>
        <div class="workspace-controls panel">
          <div class="control-main"><button class="outline-button open-camera-button" id="openCameraBtn" type="button">◎ Open camera</button><button class="primary-button start-button" id="startBtn" type="button">▶ Start transformation</button><button class="outline-button stop-button" id="stopBtn" type="button" disabled>■ Stop</button><button class="outline-button" id="pauseBtn" type="button" disabled>Ⅱ Pause input</button></div>
          <div class="control-secondary"><button class="outline-button" id="switchCameraBtn" type="button" disabled>⇄ Switch camera</button><span class="video-only-note">Video-only session · microphone not requested</span></div>
          <div class="session-message" id="sessionMessage" role="status" aria-live="polite">Ready. Select your model and prompt, then start transformation.</div><button class="outline-button small-button" id="retryRealtimeBilling" type="button" hidden>Retry realtime billing</button><p class="video-only-note">Rate: <?=number_format($realtimeCreditRate)?> credits per provider-billed active second. Credits are settled when Decart returns the session's billed_seconds.</p>
        </div>
      </section>


      <section class="panel model-panel" aria-labelledby="modelHeading">
        <div class="section-heading compact-heading">
          <div><span class="section-index">01</span><h2 id="modelHeading">Choose your model</h2></div>
          <span class="section-hint">Select the engine for this session</span>
        </div>
        <div class="model-grid" id="modelGrid">
          <button class="model-card model-choice" type="button" data-model="lucy-2.5" aria-pressed="false" <?=$model25Enabled?'':'disabled'?>>
            <strong>Lucy 2.5</strong><span class="model-select-indicator"><?=$model25Enabled?'Choose':'Disabled by admin'?></span>
          </button>
          <button class="model-card model-choice <?=$model26Enabled?'selected':''?>" type="button" data-model="lucy-2.6" aria-pressed="<?=$model26Enabled?'true':'false'?>" <?=$model26Enabled?'':'disabled'?>>
            <strong>Lucy 2.6</strong><span class="model-select-indicator"><?=$model26Enabled?'Selected ✓':'Disabled by admin'?></span>
          </button>
        </div>
      </section>

      <section class="panel realtime-pricing-note" aria-labelledby="realtimePricingHeading">
        <div class="section-heading compact-heading"><div><span class="section-index">BILLING</span><h2 id="realtimePricingHeading">Realtime usage &amp; pricing</h2></div><span class="section-hint">720p · Decart published rates</span></div>
        <p><strong>Provider cost:</strong> Lucy 2.5 and Lucy 2.6 standard realtime generation are listed at <strong>US$0.02 per active second</strong>. Fast mode is listed at <strong>US$0.04 per second</strong> where supported; Fast mode is not exposed as a selectable option in this workspace.</p>
        <p class="muted-copy"><strong>Billing:</strong> Realtime usage is charged at the configured ANON credit rate using Decart's returned billed_seconds, not a browser timer. If Decart does not return measured seconds, the session is marked pending and no estimated charge is made. Ensure your wallet has enough credits before starting.</p>
      </section>

      <section class="panel prompt-library-panel" aria-labelledby="libraryHeading">
        <div class="section-heading library-heading">
          <div><span class="section-index">02</span><h2 id="libraryHeading">Prompt library</h2><span class="count-badge" id="promptCount">Loading</span></div>
          <div class="library-actions">
            <button class="outline-button small-button" id="managePromptsBtn" type="button">Manage prompts</button>
            <button class="scroll-button" id="promptPrev" type="button" aria-label="Scroll prompts left">←</button>
            <button class="scroll-button" id="promptNext" type="button" aria-label="Scroll prompts right">→</button>
          </div>
        </div>
        <div class="library-toolbar">
          <label class="search-box"><span>⌕</span><input id="promptSearch" type="search" placeholder="Search prompt styles" autocomplete="off"></label>
          <select id="promptCategory" aria-label="Filter prompts by category"><option value="all">All categories</option></select>
        </div>
        <div class="prompt-strip" id="promptStrip" tabindex="0" aria-label="Horizontally scrollable prompt library">
          <div class="empty-state inline-empty">Loading prompt library…</div>
        </div>
        <p class="library-footnote">Tap a prompt card to place its text in the editor below. You can then customize it before applying.</p>
      </section>

      <section class="panel reference-panel" aria-labelledby="referenceHeading">
        <div class="section-heading compact-heading">
          <div><span class="section-index">03</span><h2 id="referenceHeading">Reference image</h2></div>
          <span class="supported-label"><span class="green-dot"></span> Supported by Lucy 2.5 &amp; 2.6</span>
        </div>
        <div class="reference-content">
          <div class="reference-preview" id="referencePreviewWrap">
            <div class="reference-placeholder" id="referencePlaceholder"><span class="image-placeholder-icon">▧</span><strong>No reference selected</strong><small>Upload a JPG, PNG, or WebP image</small></div>
            <img id="referencePreview" alt="Selected reference image preview" hidden>
          </div>
          <div class="reference-details">
            <div class="reference-copy"><strong>Guide the transformation with an image</strong><p>Use a character, garment, object, or visual reference. The image is stored privately by this workspace and sent to Decart when you start or update the session.</p></div>
            <div class="reference-meta" id="referenceMeta" hidden><span id="referenceFileName"></span><span id="referenceDimensions"></span></div>
            <div class="reference-actions">
              <label class="outline-button upload-button" for="referenceFile">＋ Choose image</label>
              <input class="visually-hidden" id="referenceFile" type="file" accept="image/jpeg,image/png,image/webp">
              <label class="outline-button camera-upload-button" for="referenceCameraFile">▣ Use camera</label>
              <input class="visually-hidden" id="referenceCameraFile" type="file" accept="image/jpeg,image/png,image/webp" capture="environment">
              <button class="text-button danger-text" id="removeReferenceBtn" type="button" hidden>Remove</button>
            </div>
            <div class="upload-status" id="referenceStatus" role="status" aria-live="polite">JPEG, PNG or WebP · Recommended 512 × 512 or larger · Up to 5 MB</div>
            <div class="progress-track" id="uploadProgressTrack" hidden><span id="uploadProgress"></span></div>
            <p class="reference-capability-note">Reference strength controls are not shown because the documented Lucy realtime API does not expose a reference-strength parameter.</p>
          </div>
        </div>
      </section>

      <section class="panel prompt-editor-panel" aria-labelledby="promptHeading">
        <div class="section-heading compact-heading">
          <div><span class="section-index">04</span><h2 id="promptHeading">Transformation prompt</h2></div>
          <label class="enhance-toggle"><input id="enhancePrompt" type="checkbox" checked><span class="toggle-track"></span><span>Enhance prompt</span></label>
        </div>
        <textarea id="promptInput" maxlength="2000" rows="3" placeholder="Describe the transformation… e.g. Transform me into a cinematic fantasy character while preserving my expressions and movements."></textarea>
        <div class="editor-footer">
          <span class="input-note"><span class="green-dot"></span> Prompt updates are sent to the active Decart session.</span>
          <div class="editor-actions"><span class="char-count" id="charCount">0 / 2000</span><button class="primary-button apply-button" id="applyPromptBtn" type="button" disabled>Apply prompt <span>↗</span></button></div>
        </div>
      </section>

      <section class="footer-note"><span class="footer-mark">A</span><span>ANONYMOUX REALTIME STUDIO</span><span class="footer-separator">·</span><span>Built for live creativity</span></section>
    </main>
  </div>

  <dialog class="prompt-dialog" id="promptDialog" aria-labelledby="dialogTitle">
    <form method="dialog" class="dialog-top"><div><span class="eyebrow">PROMPT MANAGEMENT</span><h2 id="dialogTitle">Your prompt library</h2></div><button class="dialog-close" value="cancel" aria-label="Close prompt manager">×</button></form>
    <div class="dialog-toolbar"><p>Built-in prompts are read-only. Your custom prompts can be edited, duplicated, or deleted.</p><button class="primary-button small-button" id="newPromptBtn" type="button">＋ New prompt</button></div>
    <div class="managed-prompts" id="managedPrompts"><div class="empty-state">Loading prompts…</div></div>
    <form id="promptForm" class="prompt-form" hidden>
      <input type="hidden" id="editPromptId">
      <div class="form-heading"><strong id="promptFormTitle">Create custom prompt</strong><button type="button" class="text-button" id="cancelPromptEdit">Cancel</button></div>
      <label>Title<input id="customPromptTitle" maxlength="180" required placeholder="e.g. Neon portrait"></label>
      <label>Description<input id="customPromptDescription" maxlength="500" placeholder="Short description"></label>
      <label>Category<select id="customPromptCategory"><option>Cinematic</option><option>Anime</option><option>Realistic</option><option>Fantasy</option><option>Cyberpunk</option><option>Professional</option><option>Fashion</option><option>Character Transformation</option><option>Cartoon</option><option>Creative Effects</option></select></label>
      <label>Prompt text<textarea id="customPromptText" rows="4" maxlength="2000" required placeholder="Write the complete instruction sent to Decart…"></textarea></label>
      <div class="form-actions"><button class="primary-button" type="submit">Save prompt</button></div>
    </form>
  </dialog>
  <div class="toast-region" id="toastRegion" aria-live="polite" aria-atomic="true"></div><div class="notification-toasts" aria-live="polite" aria-atomic="false"></div>

  <script>window.ANONYMOUX_APP = { csrfToken: "<?= $csrf ?>", apiBase: "api" };</script>
  <script src="assets/navigation.js?v=2.5.9" defer></script>
  <script src="assets/notifications.js?v=2.5.8" defer></script>
  <script type="module" src="assets/app.js?v=2.5.9"></script>
    </div>
  </div>
</body>
</html>
