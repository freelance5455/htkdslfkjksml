PROUD RANI — WEB APP

Open index.html in a browser. This is a self-contained web/PWA version designed to be packaged into an APK by a ZIP-to-APK / WebView builder.

Included:
- Splash / branding
- Home dashboard
- SOS emergency flow (opens phone dialer for 112)
- Incident reporting UI
- Safe places map-style screen
- Resources & Help
- Community feed
- Profile
- Proud Rani logo

This demo does not automatically submit reports or transmit location. Those features require a backend and explicit permissions.
