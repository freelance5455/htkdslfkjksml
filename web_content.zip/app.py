import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from config import PORT
from ai import ask_gemini
from actions import open_app, youtube_search, battery_status, torch, vibrate, clipboard
from voice import listen_once, speak

HISTORY = []
LOCK = threading.Lock()

def handle_command(text):
    raw = text.strip()
    low = raw.lower()
    if not raw:
        return "Please say or type a command."
    if low in ("battery", "battery status", "फोन की बैटरी", "बैटरी"):
        return battery_status()
    if low in ("turn on torch", "torch on", "flashlight on", "torch चालू करो", "टॉर्च चालू करो"):
        return torch(True)
    if low in ("turn off torch", "torch off", "flashlight off", "torch बंद करो", "टॉर्च बंद करो"):
        return torch(False)
    if low in ("vibrate", "vibration"):
        return vibrate()
    if low in ("read clipboard", "clipboard"):
        return clipboard()
    for prefix in ("open ", "ओपन ", "खोलो "):
        if low.startswith(prefix):
            return open_app(raw[len(prefix):].strip())
    for prefix in ("play ", "youtube ", "यूट्यूब पर ", "गाना चलाओ "):
        if low.startswith(prefix):
            query = raw[len(prefix):].strip()
            return youtube_search(query)
    if "youtube" in low and any(w in low for w in ("play", "search", "song", "music")):
        query = raw.replace("youtube", "").replace("play", "").strip()
        return youtube_search(query or raw)
    with LOCK:
        answer = ask_gemini(raw, HISTORY)
        HISTORY.extend([{"role": "user", "text": raw},
                        {"role": "assistant", "text": answer}])
        del HISTORY[:-16]
    return answer

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/":
            try:
                with open("web/index.html", "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except OSError:
                self._send(500, {"reply": "Dashboard file missing."})
        elif path == "/health":
            self._send(200, {"status": "online", "name": "AppsFuture AI"})
        else:
            self._send(404, {"reply": "Not found"})

    def do_POST(self):
        if urlparse(self.path).path != "/api/command":
            self._send(404, {"reply": "Not found"})
            return
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 12000:
                self._send(413, {"reply": "Request too large"})
                return
            data = json.loads(self.rfile.read(size).decode("utf-8"))
            command = str(data.get("command", "")).strip()
            if data.get("voice"):
                command = listen_once()
                if command.startswith(("Speech input", "I did not hear")):
                    self._send(200, {"reply": command})
                    return
            reply = handle_command(command)
            speak(reply)
            self._send(200, {"reply": reply, "heard": command})
        except Exception as exc:
            self._send(500, {"reply": f"Internal error: {exc}"})

    def log_message(self, *_):
        pass

if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"\n  APPSFUTURE AI ONLINE\n  Open http://127.0.0.1:{PORT} in your phone browser\n  Press Ctrl+C to stop.\n")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nJARVIS signing off.")
        server.server_close()
