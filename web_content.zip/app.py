"""
शालेय पोषण आहार (MDM) - ऑक्टोबर 2026 (आजपर्यंतची दैनिक नोंद व प्रपत्र ब)
Run this script to add today's entry and automatically update the Excel file!
Usage:
    python3 app.py                  -> Generates Excel up to today
    python3 app.py add 2026-10-14 13 5 -> Adds an entry for today and updates Excel immediately
"""

import sys
import json
import os
from datetime import datetime
import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

DATA_FILE = "october_entries.json"

# Default starter entries for October 2026 up to today (14/10/2026)
DEFAULT_OCT_ENTRIES = [
    {"date": "2026-10-01", "std15": 13, "std68": 5},
    {"date": "2026-10-03", "std15": 13, "std68": 5},
    {"date": "2026-10-05", "std15": 12, "std68": 5},
    {"date": "2026-10-06", "std15": 13, "std68": 4},
    {"date": "2026-10-07", "std15": 13, "std68": 5},
    {"date": "2026-10-08", "std15": 11, "std68": 5},
    {"date": "2026-10-09", "std15": 13, "std68": 5},
    {"date": "2026-10-12", "std15": 13, "std68": 5},
    {"date": "2026-10-13", "std15": 13, "std68": 5},
    {"date": "2026-10-14", "std15": 13, "std68": 5}
]

ITEMS = [
    {"no": 1, "name": "तांदूळ", "norm15": 0.10, "norm68": 0.15, "open15": 57.30, "recv15": 50.0, "open68": 40.55, "recv68": 30.0},
    {"no": 2, "name": "मुगडाळ", "manual15": 0.96, "manual68": 0.60, "open15": -2.96, "recv15": 3.0, "open68": 1.16, "recv68": 1.0},
    {"no": 3, "name": "तुरडाळ", "manual15": 0.48, "manual68": 0.30, "open15": -3.50, "recv15": 2.0, "open68": 1.30, "recv68": 1.0},
    {"no": 4, "name": "मसूर डाळ", "manual15": 0.48, "manual68": 0.30, "open15": -2.37, "recv15": 2.0, "open68": -0.836, "recv68": 1.0},
    {"no": 5, "name": "मटकी", "manual15": 0.72, "manual68": 0.15, "open15": -3.08, "recv15": 2.0, "open68": 2.70, "recv68": 1.0},
    {"no": 6, "name": "वाटाणा", "manual15": 1.20, "manual68": 0.75, "open15": 2.27, "recv15": 3.0, "open68": 6.45, "recv68": 2.0},
    {"no": 7, "name": "हरभरा", "manual15": 0.48, "manual68": 0.30, "open15": -6.16, "recv15": 3.0, "open68": -0.96, "recv68": 1.0},
    {"no": 8, "name": "मुग", "manual15": 0.48, "manual68": 0.30, "open15": -2.90, "recv15": 2.0, "open68": 1.48, "recv68": 1.0},
    {"no": 9, "name": "चवळी", "manual15": 1.04, "manual68": 0.30, "open15": -4.46, "recv15": 2.0, "open68": -0.09, "recv68": 1.0},
    {"no": 10, "name": "मसाला", "norm15": 0.0003, "norm68": 0.0005, "open15": 0.389, "recv15": 0.2, "open68": 0.477, "recv68": 0.2},
    {"no": 11, "name": "मीठ", "norm15": 0.003, "norm68": 0.004, "open15": 7.213, "recv15": 2.0, "open68": 6.762, "recv68": 1.0},
    {"no": 12, "name": "हळद", "norm15": 0.0002, "norm68": 0.0003, "open15": 0.781, "recv15": 0.2, "open68": 0.812, "recv68": 0.2},
    {"no": 13, "name": "जिरे", "norm15": 0.0002, "norm68": 0.0003, "open15": 0.759, "recv15": 0.2, "open68": 1.092, "recv68": 0.2},
    {"no": 14, "name": "मोहरी", "norm15": 0.0002, "norm68": 0.0003, "open15": 0.759, "recv15": 0.2, "open68": 1.492, "recv68": 0.2},
    {"no": 15, "name": "सोयाबीन तेल", "norm15": 0.00548, "norm68": 0.00724, "open15": -3.23, "recv15": 5.0, "open68": 5.811, "recv68": 3.0},
    {"no": 16, "name": "मिरची पावडर", "norm15": 0.0003, "norm68": 0.0005, "open15": 0.783, "recv15": 0.2, "open68": 1.387, "recv68": 0.2},
    {"no": 17, "name": "सोयावडी", "manual15": 0.28, "manual68": 0.06, "open15": 2.44, "recv15": 1.0, "open68": 0.94, "recv68": 1.0}
]

FUEL_RATE_15 = 2.08
FUEL_RATE_68 = 3.11


def load_entries():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_OCT_ENTRIES


def save_entries(entries):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def generate_excel_up_to_today(entries=None, output_filename="MDM_Prapatra_B_October_2026.xlsx"):
    if entries is None:
        entries = load_entries()

    # Sort chronologically
    entries.sort(key=lambda x: x["date"])

    working_days = len(entries)
    total_plates_15 = sum(int(e["std15"]) for e in entries)
    total_plates_68 = sum(int(e["std68"]) for e in entries)
    latest_date = entries[-1]["date"] if entries else "2026-10-14"
    # Format date to DD/MM/YYYY
    d_obj = datetime.strptime(latest_date, "%Y-%m-%d")
    report_date_str = d_obj.strftime("%d/%m/%Y")

    school = {
        "name": "जि.प. उर्दू शाळा बोर्गी",
        "kendra": "बोर्गी",
        "taluka": "जत",
        "dist": "सांगली",
        "roll15": 13,
        "roll68": 5,
        "month": "ऑक्टोबर 2026 (आजपर्यंत)",
        "report_date": report_date_str
    }

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    # ----------------------------------------------------
    # SHEET 1: दैनिक उपस्थिती नोंद (Daily Register)
    # ----------------------------------------------------
    ws_daily = wb.create_sheet(title="दैनिक उपस्थिती नोंद")
    ws_daily.cell(1, 1, f"शालेय पोषण आहार (MDM) दैनिक उपस्थिती नोंद - माहे ऑक्टोबर 2026 (आजपर्यंत)").font = Font(size=12, bold=True)
    ws_daily.cell(2, 1, f"शाळा: {school['name']} | केंद्र: {school['kendra']} | तालुका: {school['taluka']} | अहवाल दिनांक: {report_date_str}")
    
    headers_daily = ["अ.क्र.", "दिनांक", "इ. १ ते ५ ताटे", "इ. ६ ते ८ ताटे", "एकूण ताटे", "तांदूळ वापर (kg)", "शेरा"]
    for c_idx, h in enumerate(headers_daily, 1):
        cell = ws_daily.cell(4, c_idx, h)
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    for r_idx, item in enumerate(entries, start=5):
        s15 = int(item["std15"])
        s68 = int(item["std68"])
        tot = s15 + s68
        rice_kg = round((s15 * 0.1) + (s68 * 0.15), 2)
        ws_daily.cell(r_idx, 1, r_idx - 4).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 2, item["date"]).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 3, s15).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 4, s68).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 5, tot).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 6, rice_kg).alignment = Alignment(horizontal="center")
        ws_daily.cell(r_idx, 7, "अन्न शिजवून दिले")

    # Summary Row in Daily Sheet
    sum_row = len(entries) + 5
    ws_daily.cell(sum_row, 2, "एकूण (आजपर्यंत):").font = Font(bold=True)
    ws_daily.cell(sum_row, 3, total_plates_15).font = Font(bold=True)
    ws_daily.cell(sum_row, 4, total_plates_68).font = Font(bold=True)
    ws_daily.cell(sum_row, 5, total_plates_15 + total_plates_68).font = Font(bold=True)
    ws_daily.cell(sum_row, 6, round((total_plates_15 * 0.1) + (total_plates_68 * 0.15), 2)).font = Font(bold=True)

    ws_daily.column_dimensions['A'].width = 8
    ws_daily.column_dimensions['B'].width = 14
    ws_daily.column_dimensions['C'].width = 16
    ws_daily.column_dimensions['D'].width = 16
    ws_daily.column_dimensions['E'].width = 14
    ws_daily.column_dimensions['F'].width = 18
    ws_daily.column_dimensions['G'].width = 20

    # ----------------------------------------------------
    # FUNCTION TO POPULATE PRAPATRA B (SHEETS '1 to 5' & '6 to 8')
    # ----------------------------------------------------
    def populate_sheet(ws, group):
        is_primary = (group == "primary")
        title = "राष्ट्रीय मध्यान्ह भोजन योजना कार्यक्रम - प्रपत्र ब (इ. १ ते ५)" if is_primary else "राष्ट्रीय मध्यान्ह भोजन योजना कार्यक्रम - प्रपत्र ब (इ. ६ ते ८)"
        roll = school["roll15"] if is_primary else school["roll68"]
        tot_plates = total_plates_15 if is_primary else total_plates_68
        fuel_rate = FUEL_RATE_15 if is_primary else FUEL_RATE_68
        num_prefix = "१" if is_primary else "४"
        fuel_prefix = "२" if is_primary else "५"
        cook_prefix = "३" if is_primary else "६"

        ws.cell(1, 1, title).font = Font(name="Calibri", size=12, bold=True)
        ws.cell(2, 1, f"शाळेचे नाव- {school['name']}")
        ws.cell(2, 5, f"केंद्र - {school['kendra']}")
        ws.cell(2, 7, f"तालुका - {school['taluka']}")
        ws.cell(2, 9, f"जिल्हा - {school['dist']}")

        ws.cell(3, 2, "पटसंख्या - इ.१ ते५ -" if is_primary else "पटसंख्या - इ.६ ते८ -")
        ws.cell(3, 4, roll)

        ws.cell(4, 2, "महिन्यातील एकूण उपस्थित विद्यार्थी-")
        ws.cell(4, 7, "एकूण कार्यदिवस-")
        ws.cell(4, 9, working_days)

        ws.cell(5, 2, "तांदूळ प्राप्त दिनांक व पावती क्रमांक -")
        ws.cell(5, 7, "अन्न शिजवून देलेले दिवस -")
        ws.cell(5, 9, working_days)

        ws.cell(6, 2, "धान्यादी वस्तू प्राप्त दिनांक व पावती क्रमांक -")
        ws.cell(6, 7, f"माहे - ऑक्टोबर 2026 (दि. {report_date_str} पर्यंत)")

        headers = [
            "अ.क्र.", "वस्तूचे नाव ", "मागील शिल्लक वस्तू (किलोग्रॅम)", 
            "चालू महिन्यात प्राप्त वस्तू (किलोग्रॅम)", "एकूण वस्तू (३-४)(किलो ग्रॅम)", 
            "अन्न शिजवण्यासाठी वापरलेल्या वस्तू (किलोग्रॅम)", "शिल्लक वस्तू (५-६)(किलो ग्रॅम)", 
            "पुढील २ महिन्यांसाठी मागणी (किलोग्रॅम)", "शेरा"
        ]
        for col_idx, h in enumerate(headers, 1):
            cell = ws.cell(7, col_idx, h)
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        for col_idx in range(1, 10):
            ws.cell(8, col_idx, col_idx).alignment = Alignment(horizontal="center")

        for idx, item in enumerate(ITEMS, start=9):
            ws.cell(idx, 1, item["no"]).alignment = Alignment(horizontal="center")
            ws.cell(idx, 2, item["name"])

            open_val = item["open15"] if is_primary else item["open68"]
            recv_val = item["recv15"] if is_primary else item["recv68"]
            ws.cell(idx, 3, open_val)
            ws.cell(idx, 4, recv_val)
            ws.cell(idx, 5, f"=C{idx}+D{idx}")

            if "norm15" in item and is_primary:
                ws.cell(idx, 6, f"=E29*{item['norm15']}")
            elif "norm68" in item and not is_primary:
                ws.cell(idx, 6, f"=E29*{item['norm68']}")
            else:
                ratio = working_days / 23.0
                manual_full = item["manual15"] if is_primary else item["manual68"]
                ws.cell(idx, 6, round(manual_full * ratio, 2))

            ws.cell(idx, 7, f"=E{idx}-F{idx}")

        ws.cell(28, 2, "मागणी नोंदवताना शाळेकडे वीस दिवसांचा साठा शिल्लक राहील याची दक्षता घेऊन मागणी नोंदवावी, आवश्यकतेपेक्षा जास्त साठा करून धान्य खराब होणार नाही याची दक्षता घ्यावी ")
        
        ws.cell(29, 2, f"{num_prefix})  महिन्यातील आजपर्यंत एकूण ताटांची संख्या ")
        ws.cell(29, 5, tot_plates)  # Actual sum of attendance up to today

        ws.cell(30, 2, f"{fuel_prefix}) इंधन व भाजीपाल्यासाठी खर्च केलेले अनुदान रु: ")
        ws.cell(30, 5, f"=E29*{fuel_rate}")
        ws.cell(30, 6, "(ताटाची संख्या×दर) (शासनस्तरावरून निश्चित केल्यानुसार)")

        ws.cell(31, 2, f"{cook_prefix}) स्वयंपाकी तथा मदतनीस मानधन रु:2500  (२५००× नेमलेल्या स्वयंपाकी तथा मदतनीस संख्या )")

        ws.cell(32, 1, "प्रमाणित करण्यात येते कि, वर नमूद केलेली माहिती दैनंदिन नोंदवही वरुन घेतलेली आहे. ती तपासली आहे व बरोबर आहे.")
        
        ws.cell(34, 1, "दिनांक ")
        ws.cell(34, 2, report_date_str)
        ws.cell(34, 5, "मुख्याध्यापक /सचिव")
        ws.cell(34, 8, "केंद्र प्रमुख ")

        ws.cell(35, 5, "शालेय व्यवस्थापन समिती ")
        ws.cell(35, 8, f"केंद्र {school['kendra']}")

        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 24
        ws.column_dimensions['C'].width = 16
        ws.column_dimensions['D'].width = 16
        ws.column_dimensions['E'].width = 16
        ws.column_dimensions['F'].width = 18
        ws.column_dimensions['G'].width = 16
        ws.column_dimensions['H'].width = 16
        ws.column_dimensions['I'].width = 12

    ws15 = wb.create_sheet(title="1 to 5")
    populate_sheet(ws15, "primary")

    ws68 = wb.create_sheet(title="6 to 8")
    populate_sheet(ws68, "upper")

    wb.save(output_filename)
    print(f"✅ Excel file updated up to today ({report_date_str}): {output_filename} (कार्यदिवस: {working_days}, ताटे: १-५ = {total_plates_15}, ६-८ = {total_plates_68})")
    return output_filename


def add_entry(date_str, std15, std68):
    entries = load_entries()
    idx = next((i for i, item in enumerate(entries) if item["date"] == date_str), -1)
    if idx >= 0:
        entries[idx] = {"date": date_str, "std15": int(std15), "std68": int(std68)}
    else:
        entries.append({"date": date_str, "std15": int(std15), "std68": int(std68)})
    save_entries(entries)
    generate_excel_up_to_today(entries)


if __name__ == "__main__":
    if len(sys.argv) >= 5 and sys.argv[1] == "add":
        add_entry(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        generate_excel_up_to_today()
