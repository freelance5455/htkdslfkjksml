import os, io, smtplib, sqlite3
from datetime import datetime
from email.message import EmailMessage
from functools import wraps

from flask import Flask, request, redirect, url_for, session, render_template, flash, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")
DB = os.getenv("DATABASE", "repair_business.db")

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS settings (
        id INTEGER PRIMARY KEY CHECK(id=1),
        business_name TEXT NOT NULL DEFAULT 'DUNN TECH REPAIRS',
        tagline TEXT DEFAULT 'Phone • Computer • Laptop • Printer • Software',
        phone TEXT DEFAULT '',
        email TEXT DEFAULT '',
        address TEXT DEFAULT '',
        currency TEXT DEFAULT 'R'
    );
    CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT NOT NULL DEFAULT 'General',
        description TEXT DEFAULT '',
        price REAL NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT DEFAULT '',
        email TEXT DEFAULT '',
        address TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS repairs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        device TEXT NOT NULL,
        issue TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Received',
        notes TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        invoice_no TEXT UNIQUE NOT NULL,
        device TEXT DEFAULT '',
        subtotal REAL NOT NULL DEFAULT 0,
        total REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Unpaid',
        FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL
    );
    CREATE TABLE IF NOT EXISTS invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        description TEXT NOT NULL,
        qty REAL NOT NULL DEFAULT 1,
        price REAL NOT NULL DEFAULT 0,
        FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
    );
    """)
    if not conn.execute("SELECT 1 FROM settings WHERE id=1").fetchone():
        conn.execute("INSERT INTO settings(id) VALUES(1)")
    if not conn.execute("SELECT 1 FROM admins LIMIT 1").fetchone():
        conn.execute(
            "INSERT INTO admins(username,password_hash) VALUES(?,?)",
            ("admin", generate_password_hash(os.getenv("ADMIN_PASSWORD", "admin123")))
        )
    if not conn.execute("SELECT 1 FROM services LIMIT 1").fetchone():
        conn.executemany(
            "INSERT INTO services(name,category,description,price) VALUES(?,?,?,?)",
            [
                ("Phone Diagnostics", "Phone", "Full phone fault diagnosis", 150),
                ("Laptop/PC Diagnostics", "Computer", "Hardware and software diagnosis", 200),
                ("Printer Repair", "Printer", "Printer diagnosis and repair", 250),
                ("Software Installation", "Software", "OS/software installation and setup", 200),
                ("Virus/Malware Removal", "Software", "System cleanup and security check", 250),
            ]
        )
    conn.commit()
    conn.close()

init_db()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def globals():
    conn = db()
    settings = conn.execute("SELECT * FROM settings WHERE id=1").fetchone()
    conn.close()
    return {"settings": settings}

@app.route("/")
def home():
    conn = db()
    services = conn.execute("SELECT * FROM services ORDER BY category,name").fetchall()
    conn.close()
    return render_template("index.html", services=services)

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = db()
        admin = conn.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
        conn.close()
        if admin and check_password_hash(admin["password_hash"], password):
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def dashboard():
    conn = db()
    stats = {
        "services": conn.execute("SELECT COUNT(*) c FROM services").fetchone()["c"],
        "customers": conn.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"],
        "repairs": conn.execute("SELECT COUNT(*) c FROM repairs").fetchone()["c"],
        "invoices": conn.execute("SELECT COUNT(*) c FROM invoices").fetchone()["c"],
        "revenue": conn.execute("SELECT COALESCE(SUM(total),0) x FROM invoices WHERE status='Paid'").fetchone()["x"],
    }
    recent = conn.execute("""
        SELECT r.*, c.name customer_name
        FROM repairs r LEFT JOIN customers c ON c.id=r.customer_id
        ORDER BY r.id DESC LIMIT 8
    """).fetchall()
    conn.close()
    return render_template("admin.html", stats=stats, recent=recent)

@app.route("/admin/settings", methods=["GET","POST"])
@admin_required
def settings_page():
    conn = db()
    if request.method == "POST":
        conn.execute("""
            UPDATE settings SET business_name=?, tagline=?, phone=?, email=?, address=?, currency=?
            WHERE id=1
        """, tuple(request.form.get(k,"") for k in ["business_name","tagline","phone","email","address","currency"]))
        conn.commit()
        flash("Business settings updated.", "success")
    settings = conn.execute("SELECT * FROM settings WHERE id=1").fetchone()
    conn.close()
    return render_template("settings.html", settings=settings)

@app.route("/admin/password", methods=["POST"])
@admin_required
def change_password():
    current = request.form.get("current","")
    new = request.form.get("new","")
    if len(new) < 6:
        flash("New password must be at least 6 characters.", "error")
        return redirect(url_for("settings_page"))
    conn = db()
    admin = conn.execute("SELECT * FROM admins WHERE id=?", (session["admin_id"],)).fetchone()
    if not check_password_hash(admin["password_hash"], current):
        conn.close()
        flash("Current password is incorrect.", "error")
        return redirect(url_for("settings_page"))
    conn.execute("UPDATE admins SET password_hash=? WHERE id=?",
                 (generate_password_hash(new), session["admin_id"]))
    conn.commit(); conn.close()
    flash("Password changed.", "success")
    return redirect(url_for("settings_page"))

@app.route("/admin/services", methods=["GET","POST"])
@admin_required
def services():
    conn = db()
    if request.method == "POST":
        sid = request.form.get("id")
        data = (request.form.get("name",""), request.form.get("category","General"),
                request.form.get("description",""), float(request.form.get("price",0) or 0))
        if sid:
            conn.execute("UPDATE services SET name=?,category=?,description=?,price=? WHERE id=?", (*data, sid))
        else:
            conn.execute("INSERT INTO services(name,category,description,price) VALUES(?,?,?,?)", data)
        conn.commit()
        flash("Service saved.", "success")
    rows = conn.execute("SELECT * FROM services ORDER BY category,name").fetchall()
    conn.close()
    return render_template("services.html", services=rows)

@app.route("/admin/services/delete/<int:sid>", methods=["POST"])
@admin_required
def delete_service(sid):
    conn = db(); conn.execute("DELETE FROM services WHERE id=?", (sid,)); conn.commit(); conn.close()
    return redirect(url_for("services"))

@app.route("/admin/customers", methods=["GET","POST"])
@admin_required
def customers():
    conn = db()
    if request.method == "POST":
        conn.execute("INSERT INTO customers(name,phone,email,address) VALUES(?,?,?,?)",
                     tuple(request.form.get(k,"") for k in ["name","phone","email","address"]))
        conn.commit(); flash("Customer added.", "success")
    rows = conn.execute("SELECT * FROM customers ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("customers.html", customers=rows)

@app.route("/admin/repairs", methods=["GET","POST"])
@admin_required
def repairs():
    conn = db()
    if request.method == "POST":
        conn.execute("""
            INSERT INTO repairs(customer_id,device,issue,status,notes,created_at)
            VALUES(?,?,?,?,?,?)
        """, (
            request.form.get("customer_id") or None, request.form.get("device",""),
            request.form.get("issue",""), request.form.get("status","Received"),
            request.form.get("notes",""), datetime.now().strftime("%Y-%m-%d %H:%M")
        ))
        conn.commit(); flash("Repair job added.", "success")
    rows = conn.execute("""
        SELECT r.*, c.name customer_name, c.phone customer_phone
        FROM repairs r LEFT JOIN customers c ON c.id=r.customer_id
        ORDER BY r.id DESC
    """).fetchall()
    cust = conn.execute("SELECT * FROM customers ORDER BY name").fetchall()
    conn.close()
    return render_template("repairs.html", repairs=rows, customers=cust)

@app.route("/admin/repairs/<int:rid>/status", methods=["POST"])
@admin_required
def repair_status(rid):
    conn = db()
    conn.execute("UPDATE repairs SET status=? WHERE id=?", (request.form.get("status"), rid))
    conn.commit(); conn.close()
    return redirect(url_for("repairs"))

@app.route("/admin/invoices", methods=["GET","POST"])
@admin_required
def invoices():
    conn = db()
    customers = conn.execute("SELECT * FROM customers ORDER BY name").fetchall()
    services = conn.execute("SELECT * FROM services ORDER BY name").fetchall()
    if request.method == "POST":
        customer_id = request.form.get("customer_id") or None
        device = request.form.get("device","")
        descriptions = request.form.getlist("description[]")
        qtys = request.form.getlist("qty[]")
        prices = request.form.getlist("price[]")
        items = []
        for d,q,p in zip(descriptions, qtys, prices):
            if d.strip():
                qty = float(q or 1); price = float(p or 0)
                items.append((d.strip(), qty, price))
        if not items:
            flash("Add at least one invoice item.", "error")
        else:
            subtotal = sum(q*p for _,q,p in items)
            invoice_no = "INV-" + datetime.now().strftime("%Y%m%d%H%M%S")
            cur = conn.execute("""
                INSERT INTO invoices(customer_id,invoice_no,device,subtotal,total,created_at,status)
                VALUES(?,?,?,?,?,?,?)
            """, (customer_id, invoice_no, device, subtotal, subtotal,
                  datetime.now().strftime("%Y-%m-%d %H:%M"), "Unpaid"))
            iid = cur.lastrowid
            conn.executemany(
                "INSERT INTO invoice_items(invoice_id,description,qty,price) VALUES(?,?,?,?)",
                [(iid,d,q,p) for d,q,p in items]
            )
            conn.commit()
            flash(f"Invoice {invoice_no} created.", "success")
            conn.close()
            return redirect(url_for("invoices"))
    rows = conn.execute("""
        SELECT i.*, c.name customer_name, c.email customer_email
        FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id
        ORDER BY i.id DESC
    """).fetchall()
    conn.close()
    return render_template("invoices.html", invoices=rows, customers=customers, services=services)

@app.route("/admin/invoices/<int:iid>/paid", methods=["POST"])
@admin_required
def mark_paid(iid):
    conn = db(); conn.execute("UPDATE invoices SET status='Paid' WHERE id=?", (iid,)); conn.commit(); conn.close()
    return redirect(url_for("invoices"))

def invoice_pdf_bytes(iid):
    conn = db()
    inv = conn.execute("""
        SELECT i.*, c.name customer_name, c.phone customer_phone, c.email customer_email, c.address customer_address
        FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE i.id=?
    """, (iid,)).fetchone()
    if not inv:
        conn.close(); abort(404)
    items = conn.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (iid,)).fetchall()
    settings = conn.execute("SELECT * FROM settings WHERE id=1").fetchone()
    conn.close()

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    w,h = A4
    y = h - 55
    c.setFont("Helvetica-Bold", 20); c.drawString(45,y,settings["business_name"])
    c.setFont("Helvetica", 9); y -= 18
    c.drawString(45,y,settings["tagline"] or "")
    c.drawRightString(w-45,y,f"INVOICE {inv['invoice_no']}")
    y -= 25
    c.drawString(45,y,settings["address"] or ""); y -= 14
    c.drawString(45,y,f"Phone: {settings['phone']}   Email: {settings['email']}")
    y -= 30
    c.setFont("Helvetica-Bold", 11); c.drawString(45,y,"Bill To")
    c.setFont("Helvetica",10); y -= 16
    c.drawString(45,y,inv["customer_name"] or "Walk-in Customer"); y -= 14
    c.drawString(45,y,inv["customer_phone"] or ""); y -= 14
    c.drawString(45,y,inv["customer_email"] or ""); y -= 28
    c.setFont("Helvetica-Bold",10)
    c.drawString(45,y,"Description"); c.drawString(330,y,"Qty"); c.drawString(390,y,"Price"); c.drawRightString(w-45,y,"Total")
    y -= 15
    c.setFont("Helvetica",10)
    for item in items:
        total = item["qty"] * item["price"]
        c.drawString(45,y,item["description"][:42])
        c.drawString(330,y,str(item["qty"]))
        c.drawString(390,y,f"{settings['currency']}{item['price']:.2f}")
        c.drawRightString(w-45,y,f"{settings['currency']}{total:.2f}")
        y -= 17
        if y < 90:
            c.showPage(); y = h-55
    y -= 8
    c.setFont("Helvetica-Bold",12)
    c.drawRightString(w-45,y,f"TOTAL: {settings['currency']}{inv['total']:.2f}")
    y -= 25
    c.setFont("Helvetica",9)
    c.drawString(45,y,f"Status: {inv['status']}   Created: {inv['created_at']}")
    c.save()
    buf.seek(0)
    return buf

@app.route("/admin/invoices/<int:iid>/pdf")
@admin_required
def invoice_pdf(iid):
    return send_file(invoice_pdf_bytes(iid), mimetype="application/pdf",
                     as_attachment=True, download_name=f"invoice-{iid}.pdf")

@app.route("/admin/invoices/<int:iid>/email", methods=["POST"])
@admin_required
def email_invoice(iid):
    conn = db()
    inv = conn.execute("""
        SELECT i.*, c.email customer_email, c.name customer_name
        FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id WHERE i.id=?
    """, (iid,)).fetchone()
    conn.close()
    if not inv or not inv["customer_email"]:
        flash("Customer does not have an email address.", "error")
        return redirect(url_for("invoices"))

    host=os.getenv("SMTP_HOST"); port=int(os.getenv("SMTP_PORT","587"))
    user=os.getenv("SMTP_USER"); password=os.getenv("SMTP_PASSWORD")
    sender=os.getenv("SMTP_FROM", user or "")
    if not host or not user or not password:
        flash("SMTP is not configured. Add SMTP settings to .env.", "error")
        return redirect(url_for("invoices"))

    msg=EmailMessage()
    msg["Subject"]=f"Invoice {inv['invoice_no']}"
    msg["From"]=sender
    msg["To"]=inv["customer_email"]
    msg.set_content(f"Hello {inv['customer_name'] or 'Customer'},\n\nPlease find your invoice {inv['invoice_no']} attached.\n\nRegards,\n{os.getenv('SMTP_FROM_NAME','Repair Business')}")
    pdf=invoice_pdf_bytes(iid).read()
    msg.add_attachment(pdf, maintype="application", subtype="pdf", filename=f"{inv['invoice_no']}.pdf")
    try:
        with smtplib.SMTP(host,port) as server:
            server.starttls()
            server.login(user,password)
            server.send_message(msg)
        flash("Invoice emailed successfully.", "success")
    except Exception as e:
        flash(f"Email failed: {e}", "error")
    return redirect(url_for("invoices"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT","5000")), debug=False)
