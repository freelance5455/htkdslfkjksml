import os
import webview

html_path = os.path.abspath("index.html")
window = webview.create_window(
    title="个人所得税",
    url=f"file:///{html_path}",
    width=430,
    height=860,
    resizable=True
)
webview.start()
