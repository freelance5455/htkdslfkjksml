import os, sqlite3, secrets, datetime
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_socketio import SocketIO, join_room, leave_room, emit
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR=os.path.dirname(os.path.abspath(__file__))
DB_PATH=os.environ.get("EQUAROOM_DB", os.path.join(APP_DIR,"equaroom.db"))
app=Flask(__name__)
app.config["SECRET_KEY"]=os.environ.get("SECRET_KEY", secrets.token_hex(32))
socketio=SocketIO(app, cors_allowed_origins="*", async_mode="threading")

def db():
    c=sqlite3.connect(DB_PATH)
    c.row_factory=sqlite3.Row
    return c

def init_db():
    c=db()
    c.executescript("""
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'student', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS classrooms(id INTEGER PRIMARY KEY, title TEXT NOT NULL, subject TEXT, description TEXT, code TEXT UNIQUE NOT NULL, teacher_id INTEGER NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(teacher_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS enrollments(id INTEGER PRIMARY KEY, classroom_id INTEGER NOT NULL, user_id INTEGER NOT NULL, joined_at TEXT NOT NULL, UNIQUE(classroom_id,user_id), FOREIGN KEY(classroom_id) REFERENCES classrooms(id), FOREIGN KEY(user_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY, classroom_id INTEGER NOT NULL, author_id INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(classroom_id) REFERENCES classrooms(id));
    CREATE TABLE IF NOT EXISTS assignments(id INTEGER PRIMARY KEY, classroom_id INTEGER NOT NULL, title TEXT NOT NULL, instructions TEXT, due_date TEXT, points INTEGER DEFAULT 100, created_at TEXT NOT NULL, FOREIGN KEY(classroom_id) REFERENCES classrooms(id));
    CREATE TABLE IF NOT EXISTS submissions(id INTEGER PRIMARY KEY, assignment_id INTEGER NOT NULL, student_id INTEGER NOT NULL, answer TEXT NOT NULL, submitted_at TEXT NOT NULL, grade INTEGER, feedback TEXT, UNIQUE(assignment_id,student_id), FOREIGN KEY(assignment_id) REFERENCES assignments(id), FOREIGN KEY(student_id) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY, classroom_id INTEGER NOT NULL, user_id INTEGER NOT NULL, meeting_id TEXT NOT NULL, joined_at TEXT NOT NULL, UNIQUE(classroom_id,user_id,meeting_id));
    """)
    c.commit(); c.close()
init_db()

def current_user():
    uid=session.get("uid")
    if not uid: return None
    c=db(); u=c.execute("SELECT id,name,email,role FROM users WHERE id=?",(uid,)).fetchone(); c.close()
    return dict(u) if u else None

def login_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        if not current_user(): return jsonify({"error":"Please sign in first."}),401
        return fn(*a,**kw)
    return wrapped

def teacher_required(fn):
    @wraps(fn)
    def wrapped(*a,**kw):
        u=current_user()
        if not u: return jsonify({"error":"Please sign in first."}),401
        if u["role"] not in ("teacher","admin"): return jsonify({"error":"Teacher access required."}),403
        return fn(*a,**kw)
    return wrapped

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def rowdict(r): return dict(r) if r else None

@app.route("/")
def index(): return render_template("index.html")

@app.get("/api/me")
def me():
    u=current_user()
    return jsonify({"user":u})

@app.post("/api/register")
def register():
    data=request.get_json(silent=True) or {}
    name=(data.get("name") or "").strip()
    email=(data.get("email") or "").strip().lower()
    password=data.get("password") or ""
    role=data.get("role","student")
    if not name or not email or len(password)<8: return jsonify({"error":"Enter your name, valid email, and password (at least 8 characters)."}),400
    if role not in ("student","teacher"): role="student"
    c=db()
    try:
        cur=c.execute("INSERT INTO users(name,email,password,role,created_at) VALUES(?,?,?,?,?)",(name,email,generate_password_hash(password),role,now()))
        c.commit(); session["uid"]=cur.lastrowid
        return jsonify({"user":current_user()})
    except sqlite3.IntegrityError: return jsonify({"error":"That email is already registered."}),409
    finally: c.close()

@app.post("/api/login")
def login():
    d=request.get_json(silent=True) or {}; email=(d.get("email") or "").strip().lower()
    c=db(); u=c.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone(); c.close()
    if not u or not check_password_hash(u["password"],d.get("password") or ""): return jsonify({"error":"Email or password is incorrect."}),401
    session["uid"]=u["id"]; return jsonify({"user":current_user()})

@app.post("/api/logout")
def logout(): session.clear(); return jsonify({"ok":True})

@app.get("/api/dashboard")
@login_required
def dashboard():
    u=current_user(); c=db()
    classes=c.execute("""SELECT cl.*,u.name teacher_name,
       (SELECT COUNT(*) FROM enrollments e WHERE e.classroom_id=cl.id) student_count
       FROM classrooms cl JOIN users u ON u.id=cl.teacher_id
       WHERE cl.teacher_id=? OR cl.id IN (SELECT classroom_id FROM enrollments WHERE user_id=?)
       ORDER BY cl.id DESC""",(u["id"],u["id"])).fetchall()
    c.close()
    return jsonify({"user":u,"classrooms":[dict(x) for x in classes]})

@app.post("/api/classrooms")
@teacher_required
def create_class():
    d=request.get_json(silent=True) or {}; title=(d.get("title") or "").strip()
    if not title: return jsonify({"error":"Class name is required."}),400
    u=current_user(); code=secrets.token_urlsafe(5).replace("-","").replace("_","")[:8].upper()
    c=db(); cur=c.execute("INSERT INTO classrooms(title,subject,description,code,teacher_id,created_at) VALUES(?,?,?,?,?,?)",(title,(d.get("subject") or "").strip(),(d.get("description") or "").strip(),code,u["id"],now()))
    cid=cur.lastrowid; c.execute("INSERT INTO enrollments(classroom_id,user_id,joined_at) VALUES(?,?,?)",(cid,u["id"],now())); c.commit(); c.close()
    return jsonify({"id":cid,"code":code})

@app.post("/api/classrooms/join")
@login_required
def join_class():
    d=request.get_json(silent=True) or {}; code=(d.get("code") or "").strip().upper(); u=current_user(); c=db()
    cl=c.execute("SELECT id FROM classrooms WHERE code=?",(code,)).fetchone()
    if not cl: c.close(); return jsonify({"error":"Class code not found."}),404
    try: c.execute("INSERT INTO enrollments(classroom_id,user_id,joined_at) VALUES(?,?,?)",(cl["id"],u["id"],now())); c.commit()
    except sqlite3.IntegrityError: pass
    c.close(); return jsonify({"ok":True})

def get_class_access(c,cid,u):
    cl=c.execute("SELECT cl.*,us.name teacher_name FROM classrooms cl JOIN users us ON us.id=cl.teacher_id WHERE cl.id=?",(cid,)).fetchone()
    if not cl: return None,False
    enrolled=c.execute("SELECT 1 FROM enrollments WHERE classroom_id=? AND user_id=?",(cid,u["id"])).fetchone()
    return cl, bool(enrolled or cl["teacher_id"]==u["id"] or u["role"]=="admin")

@app.get("/api/classrooms/<int:cid>")
@login_required
def class_detail(cid):
    u=current_user(); c=db(); cl,ok=get_class_access(c,cid,u)
    if not cl: c.close(); return jsonify({"error":"Class not found."}),404
    if not ok: c.close(); return jsonify({"error":"Join this class to view it."}),403
    posts=c.execute("SELECT p.*,u.name author_name FROM posts p JOIN users u ON u.id=p.author_id WHERE classroom_id=? ORDER BY p.id DESC",(cid,)).fetchall()
    assignments=c.execute("SELECT * FROM assignments WHERE classroom_id=? ORDER BY id DESC",(cid,)).fetchall()
    members=c.execute("SELECT u.id,u.name,u.email,u.role FROM enrollments e JOIN users u ON u.id=e.user_id WHERE e.classroom_id=? ORDER BY u.name",(cid,)).fetchall()
    c.close()
    return jsonify({"classroom":dict(cl),"posts":[dict(x) for x in posts],"assignments":[dict(x) for x in assignments],"members":[dict(x) for x in members],"is_teacher":u["id"]==cl["teacher_id"] or u["role"]=="admin"})

@app.post("/api/classrooms/<int:cid>/posts")
@login_required
def add_post(cid):
    u=current_user(); d=request.get_json(silent=True) or {}; body=(d.get("body") or "").strip()
    if not body: return jsonify({"error":"Write a message first."}),400
    c=db(); cl,ok=get_class_access(c,cid,u)
    if not ok: c.close(); return jsonify({"error":"You are not a member of this class."}),403
    c.execute("INSERT INTO posts(classroom_id,author_id,body,created_at) VALUES(?,?,?,?)",(cid,u["id"],body,now())); c.commit(); c.close(); return jsonify({"ok":True})

@app.post("/api/classrooms/<int:cid>/assignments")
@teacher_required
def add_assignment(cid):
    u=current_user(); d=request.get_json(silent=True) or {}; title=(d.get("title") or "").strip()
    if not title: return jsonify({"error":"Assignment title is required."}),400
    c=db(); cl,ok=get_class_access(c,cid,u)
    if not ok or cl["teacher_id"]!=u["id"]: c.close(); return jsonify({"error":"Only the class teacher can post assignments."}),403
    c.execute("INSERT INTO assignments(classroom_id,title,instructions,due_date,points,created_at) VALUES(?,?,?,?,?,?)",(cid,title,(d.get("instructions") or "").strip(),d.get("due_date") or "",max(1,min(1000,int(d.get("points") or 100))),now())); c.commit(); c.close(); return jsonify({"ok":True})

@app.post("/api/assignments/<int:aid>/submit")
@login_required
def submit(aid):
    u=current_user(); d=request.get_json(silent=True) or {}; answer=(d.get("answer") or "").strip()
    if not answer: return jsonify({"error":"Enter your answer or work link."}),400
    c=db(); a=c.execute("SELECT * FROM assignments WHERE id=?",(aid,)).fetchone()
    if not a: c.close(); return jsonify({"error":"Assignment not found."}),404
    _,ok=get_class_access(c,a["classroom_id"],u)
    if not ok: c.close(); return jsonify({"error":"Join the class first."}),403
    if u["role"] in ("teacher","admin"): c.close(); return jsonify({"error":"Teacher accounts cannot submit student work."}),403
    c.execute("""INSERT INTO submissions(assignment_id,student_id,answer,submitted_at) VALUES(?,?,?,?)
      ON CONFLICT(assignment_id,student_id) DO UPDATE SET answer=excluded.answer,submitted_at=excluded.submitted_at,grade=NULL,feedback=NULL""",(aid,u["id"],answer,now()))
    c.commit(); c.close(); return jsonify({"ok":True})

@app.get("/api/assignments/<int:aid>/submissions")
@login_required
def submissions(aid):
    u=current_user(); c=db(); a=c.execute("SELECT * FROM assignments WHERE id=?",(aid,)).fetchone()
    if not a: c.close(); return jsonify({"error":"Assignment not found."}),404
    cl,ok=get_class_access(c,a["classroom_id"],u)
    if not ok: c.close(); return jsonify({"error":"No access."}),403
    if cl["teacher_id"]!=u["id"] and u["role"]!="admin": c.close(); return jsonify({"error":"Teacher access required."}),403
    rows=c.execute("SELECT s.*,u.name student_name,u.email FROM submissions s JOIN users u ON u.id=s.student_id WHERE assignment_id=? ORDER BY submitted_at DESC",(aid,)).fetchall(); c.close()
    return jsonify({"submissions":[dict(r) for r in rows]})

@app.post("/api/submissions/<int:sid>/grade")
@teacher_required
def grade(sid):
    u=current_user(); d=request.get_json(silent=True) or {}; c=db()
    s=c.execute("SELECT s.*,a.classroom_id,a.points FROM submissions s JOIN assignments a ON a.id=s.assignment_id WHERE s.id=?",(sid,)).fetchone()
    if not s: c.close(); return jsonify({"error":"Submission not found."}),404
    cl=c.execute("SELECT teacher_id FROM classrooms WHERE id=?",(s["classroom_id"],)).fetchone()
    if cl["teacher_id"]!=u["id"] and u["role"]!="admin": c.close(); return jsonify({"error":"Only the teacher can grade."}),403
    try: gradeval=int(d.get("grade"))
    except: c.close(); return jsonify({"error":"Grade must be a number."}),400
    if gradeval<0 or gradeval>s["points"]: c.close(); return jsonify({"error":f"Grade must be between 0 and {s['points']}."}),400
    c.execute("UPDATE submissions SET grade=?,feedback=? WHERE id=?",(gradeval,(d.get("feedback") or "").strip(),sid)); c.commit(); c.close(); return jsonify({"ok":True})

@app.post("/api/classrooms/<int:cid>/attendance")
@login_required
def attendance(cid):
    u=current_user(); d=request.get_json(silent=True) or {}; meeting=(d.get("meeting_id") or "").strip()
    c=db(); cl,ok=get_class_access(c,cid,u)
    if not ok: c.close(); return jsonify({"error":"No access to class."}),403
    if not meeting: c.close(); return jsonify({"error":"Missing meeting ID."}),400
    c.execute("INSERT OR IGNORE INTO attendance(classroom_id,user_id,meeting_id,joined_at) VALUES(?,?,?,?)",(cid,u["id"],meeting,now())); c.commit(); c.close(); return jsonify({"ok":True})

@socketio.on("join_meeting")
def meeting_join(data):
    u=current_user()
    if not u: emit("meeting_error",{"message":"Sign in to join the meeting."}); return
    room=str((data or {}).get("room","")).strip()
    try: cid=int((data or {}).get("classroom_id"))
    except: cid=0
    if not room or not cid: emit("meeting_error",{"message":"Invalid meeting link."}); return
    c=db(); cl,ok=get_class_access(c,cid,u); c.close()
    if not ok: emit("meeting_error",{"message":"You are not enrolled in this class."}); return
    join_room(room)
    emit("peer_joined",{"sid":request.sid,"name":u["name"],"user_id":u["id"]},to=room,include_self=False)
    emit("meeting_joined",{"room":room,"user_id":u["id"],"name":u["name"]})
    emit("meeting_presence",{"name":u["name"],"user_id":u["id"],"action":"joined"},to=room)
@socketio.on("leave_meeting")
def meeting_leave(data):
    room=str((data or {}).get("room","")).strip()
    if room:
        leave_room(room); emit("meeting_presence",{"action":"left"},to=room)
@socketio.on("webrtc_signal")
def webrtc_signal(data):
    room=str((data or {}).get("room","")).strip(); target=(data or {}).get("target"); payload=(data or {}).get("payload")
    if room and target and payload: emit("webrtc_signal",{"from":request.sid,"payload":payload},to=target)

if __name__=="__main__":
    port=int(os.environ.get("PORT","5000"))
    socketio.run(app,host="0.0.0.0",port=port,debug=False,allow_unsafe_werkzeug=True)
