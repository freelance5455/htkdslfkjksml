import os
from flask import Flask, render_template, redirect, url_for, request, flash, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    with app.app_context():
        from models import School, User, Learner, Mark, Attendance, StaffAttendance, LessonPlan
        db.create_all()

    @app.route('/')
    def index():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        return redirect(url_for('login'))

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            email = request.form.get('email')
            password = request.form.get('password')
            user = User.query.filter_by(email=email).first()
            if user and check_password_hash(user.password_hash, password):
                login_user(user)
                if user.role == 'Subordinate Staff':
                    return redirect(url_for('clock_in'))
                return redirect(url_for('dashboard'))
            flash('Invalid email or password', 'danger')
        return render_template('login.html')

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('login'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        if current_user.role == 'Subordinate Staff':
            return redirect(url_for('clock_in'))
        
        # Gather metrics based on school_id (Multi-tenancy isolation)
        school_id = current_user.school_id
        learners_count = Learner.query.filter_by(school_id=school_id).count()
        staff_count = User.query.filter_by(school_id=school_id).count()
        
        return render_template('dashboard.html', learners_count=learners_count, staff_count=staff_count)

    # Feature 9: Staff Attendance & Clock-In / Clock-Out
    @app.route('/staff/clock', methods=['GET', 'POST'])
    @login_required
    def clock_in():
        today = date.today()
        record = StaffAttendance.query.filter_by(user_id=current_user.id, date=today).first()
        
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'in' and not record:
                new_rec = StaffAttendance(user_id=current_user.id, school_id=current_user.school_id, date=today, clock_in=datetime.now().time())
                db.session.add(new_rec)
                db.session.commit()
                flash('Successfully clocked in for today.', 'success')
            elif action == 'out' and record and not record.clock_out:
                record.clock_out = datetime.now().time()
                db.session.commit()
                flash('Successfully clocked out. Record is now locked.', 'success')
            else:
                flash('Invalid clock-in/out state or already completed for today.', 'warning')
            return redirect(url_for('clock_in'))
            
        return render_template('staff_clock.html', record=record, today=today)

    # Feature 11: Secure Database Export (Admin / Principal only)
    @app.route('/admin/export-db')
    @login_required
    def export_db():
        if current_user.role not in ['Principal', 'Admin']:
            flash('Access denied. Admin or Principal role required.', 'danger')
            return redirect(url_for('dashboard'))
        
        db_path = os.path.join(os.getcwd(), 'instance', 'school_platform.db')
        if os.path.exists(db_path):
            return send_file(db_path, as_attachment=True, download_name=f'school_db_backup_{date.today()}.db')
        flash('Database file not found.', 'warning')
        return redirect(url_for('dashboard'))

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, port=5000)
