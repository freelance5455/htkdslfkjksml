from flask import Flask, render_template, request, jsonify
import sqlite3
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DB_PATH = APP_DIR / "prices.db"

app = Flask(__name__)

def connect_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                price REAL NOT NULL CHECK(price >= 0)
            )
        """)

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/items")
def get_items():
    with connect_db() as conn:
        rows = conn.execute("SELECT id, name, price FROM items ORDER BY name COLLATE NOCASE").fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/items")
def save_item():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    try:
        price = float(data.get("price"))
        if not name or price < 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify(error="Enter an item name and a valid price of 0 or more."), 400

    with connect_db() as conn:
        existing = conn.execute("SELECT id FROM items WHERE name = ? COLLATE NOCASE", (name,)).fetchone()
        if existing:
            conn.execute("UPDATE items SET name = ?, price = ? WHERE id = ?", (name, price, existing["id"]))
            item_id = existing["id"]
            message = "Existing item price updated."
        else:
            cur = conn.execute("INSERT INTO items (name, price) VALUES (?, ?)", (name, price))
            item_id = cur.lastrowid
            message = "Item saved successfully."
    return jsonify(message=message, id=item_id)

@app.put("/api/items/<int:item_id>")
def update_item(item_id):
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    try:
        price = float(data.get("price"))
        if not name or price < 0:
            raise ValueError()
    except (TypeError, ValueError):
        return jsonify(error="Enter an item name and a valid price."), 400
    try:
        with connect_db() as conn:
            conn.execute("UPDATE items SET name = ?, price = ? WHERE id = ?", (name, price, item_id))
    except sqlite3.IntegrityError:
        return jsonify(error="Another item already uses that name."), 409
    return jsonify(message="Item updated.")

@app.delete("/api/items/<int:item_id>")
def delete_item(item_id):
    with connect_db() as conn:
        conn.execute("DELETE FROM items WHERE id = ?", (item_id,))
    return jsonify(message="Item deleted.")

if __name__ == "__main__":
    init_db()
    print("Automatic Price Calculator is running at http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)