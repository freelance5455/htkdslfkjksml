import os,sqlite3,hashlib,secrets
from datetime import datetime,timezone
from flask import Flask,request,jsonify,send_from_directory,g,session
app=Flask(__name__,static_folder="web",static_url_path="")
app.secret_key=os.environ.get("KALYANI_SECRET_KEY",secrets.token_hex(32))
DB=os.path.join(os.path.dirname(__file__),"kalyani.db")
def db():
    if "db" not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row
    return g.db
@app.teardown_appcontext
def close(x):
    d=g.pop("db",None)
    if d:d.close()
def init():
    d=db(); d.executescript('''CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);
CREATE TABLE IF NOT EXISTS workers(id TEXT PRIMARY KEY,name TEXT,phone TEXT,role TEXT,joined TEXT,created TEXT);
CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY,worker_id TEXT,kind TEXT,ts TEXT,lat REAL,lng REAL);
CREATE TABLE IF NOT EXISTS lunch(id INTEGER PRIMARY KEY,worker_id TEXT,kind TEXT,ts TEXT);
CREATE TABLE IF NOT EXISTS production(id INTEGER PRIMARY KEY,worker_id TEXT,work_type TEXT,qty REAL,rate REAL,earned REAL,ts TEXT);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,worker_id TEXT,amount REAL,category TEXT,note TEXT,ts TEXT);
CREATE TABLE IF NOT EXISTS locations(id INTEGER PRIMARY KEY,worker_id TEXT,lat REAL,lng REAL,accuracy REAL,ts TEXT);''')
    if not d.execute("select 1 from settings where k='password'").fetchone():
        d.execute("insert into settings values('password',?)",(hashlib.sha256(b'2011').hexdigest(),));d.commit()
init()
def now():return datetime.now(timezone.utc).isoformat()
def ok():
    return session.get("admin")==True
def out(r):return dict(r) if r else None
@app.get("/")
def home():return send_from_directory("web","index.html")
@app.post("/api/login")
def login():
    p=str(request.json.get("password",""));h=hashlib.sha256(p.encode()).hexdigest()
    good=h==db().execute("select v from settings where k='password'").fetchone()["v"]
    if good:session["admin"]=True
    return jsonify(ok=good)
@app.post("/api/logout")
def logout():session.clear();return jsonify(ok=True)
@app.post("/api/password")
def password():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json; d=db();old=hashlib.sha256(str(x["old"]).encode()).hexdigest()
    if old!=d.execute("select v from settings where k='password'").fetchone()["v"]:return jsonify(error="incorrect password"),400
    d.execute("update settings set v=? where k='password'",(hashlib.sha256(str(x["new"]).encode()).hexdigest(),));d.commit();return jsonify(ok=True)
@app.get("/api/workers")
def workers():
    if not ok():return jsonify(error="unauthorized"),401
    return jsonify([out(x) for x in db().execute("select * from workers order by name")])
@app.post("/api/workers")
def add():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;wid=x["id"].strip().upper()
    try:db().execute("insert into workers values(?,?,?,?,?,?)",(wid,x["name"],x.get("phone",""),x.get("role",""),x.get("joined",""),now()));db().commit()
    except sqlite3.IntegrityError:return jsonify(error="Worker ID already exists"),400
    return jsonify(ok=True)
@app.get("/api/workers/<wid>")
def worker(wid):
    if not ok():return jsonify(error="unauthorized"),401
    d=db();w=d.execute("select * from workers where id=?",(wid.upper(),)).fetchone()
    if not w:return jsonify(error="not found"),404
    p=d.execute("select * from production where worker_id=? order by ts desc",(wid.upper(),)).fetchall()
    m=d.execute("select * from payments where worker_id=? order by ts desc",(wid.upper(),)).fetchall()
    a=d.execute("select * from attendance where worker_id=? order by ts desc",(wid.upper(),)).fetchall()
    l=d.execute("select * from locations where worker_id=? order by ts desc limit 1",(wid.upper(),)).fetchone()
    return jsonify(worker=out(w),production=[out(x) for x in p],payments=[out(x) for x in m],attendance=[out(x) for x in a],location=out(l))
@app.post("/api/attendance")
def att():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;db().execute("insert into attendance(worker_id,kind,ts,lat,lng) values(?,?,?,?,?)",(x["worker_id"].upper(),x["kind"],now(),x.get("lat"),x.get("lng")));db().commit();return jsonify(ok=True)
@app.post("/api/lunch")
def lunch():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;db().execute("insert into lunch(worker_id,kind,ts) values(?,?,?)",(x["worker_id"].upper(),x["kind"],now()));db().commit();return jsonify(ok=True)
@app.post("/api/production")
def prod():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;q=float(x["qty"]);r=float(x["rate"]);e=q*r
    db().execute("insert into production(worker_id,work_type,qty,rate,earned,ts) values(?,?,?,?,?,?)",(x["worker_id"].upper(),x["work_type"],q,r,e,now()));db().commit();return jsonify(earned=e)
@app.post("/api/payment")
def pay():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;db().execute("insert into payments(worker_id,amount,category,note,ts) values(?,?,?,?,?)",(x["worker_id"].upper(),float(x["amount"]),x.get("category","Payment to Worker"),x.get("note",""),now()));db().commit();return jsonify(ok=True)
@app.post("/api/location")
def loc():
    if not ok():return jsonify(error="unauthorized"),401
    x=request.json;db().execute("insert into locations(worker_id,lat,lng,accuracy,ts) values(?,?,?,?,?)",(x["worker_id"].upper(),x["lat"],x["lng"],x.get("accuracy"),now()));db().commit();return jsonify(ok=True)
@app.get("/api/locations")
def locations():
    if not ok():return jsonify(error="unauthorized"),401
    q='''select w.id,w.name,l.lat,l.lng,l.ts from workers w left join locations l on l.id=(select id from locations z where z.worker_id=w.id order by z.ts desc limit 1) order by w.name'''
    return jsonify([out(x) for x in db().execute(q)])
if __name__=="__main__":
    from waitress import serve;serve(app,host="0.0.0.0",port=int(os.environ.get("PORT",8080)))
