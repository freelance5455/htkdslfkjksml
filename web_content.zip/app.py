from flask import Flask, render_template, request, jsonify
import sympy as sp

app=Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/solve",methods=["POST"])
def solve():
    data=request.get_json(silent=True) or {}
    problem=str(data.get("problem","")).strip()
    if not problem:
        return jsonify({"answer":"Masalani yozing!"})
    try:
        expr=problem.replace("^","**").replace("√","sqrt")
        x=sp.Symbol("x")
        if "=" in expr:
            left,right=expr.split("=",1)
            result=sp.solve(sp.Eq(sp.sympify(left),sp.sympify(right)),x)
        else:
            result=sp.simplify(sp.sympify(expr))
        return jsonify({"answer":str(result)})
    except Exception:
        return jsonify({"answer":"Bu misolni hozircha tushunmadim."})

if __name__=="__main__":
    app.run(host="127.0.0.1",port=5000,debug=False)
