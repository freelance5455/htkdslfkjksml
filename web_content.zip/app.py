from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# In-memory storage for demo purposes
db = {
    "registered_users": {},
    "otps": {},
    "call_logs": [
        {"caller": "Unknown Spam", "number": "+91 98765 43210", "time": "2 mins ago", "summary": "AI picked up. Caller claimed to be bank offering a loan. AI declined.", "type": "spam"},
        {"caller": "Delivery Executive", "number": "+91 87654 32109", "time": "15 mins ago", "summary": "Package delivered at front door.", "type": "safe"},
    ]
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/send-otp', methods=['POST'])
def send_otp():
    data = request.json
    phone = data.get('phone')
    if not phone:
        return jsonify({"success": False, "message": "Phone number is required."}), 400
    
    # Generate random 4-digit OTP
    otp = str(random.randint(1000, 9999))
    db['otps'][phone] = otp
    
    return jsonify({"success": True, "message": f"OTP sent successfully!", "debug_otp": otp})

@app.route('/api/verify-otp', methods=['POST'])
def verify_otp():
    data = request.json
    phone = data.get('phone')
    user_otp = data.get('otp')
    
    if db['otps'].get(phone) == user_otp:
        db['registered_users'][phone] = True
        return jsonify({"success": True, "message": "Verification successful!"})
    
    return jsonify({"success": False, "message": "Invalid OTP. Please try again."}), 400

@app.route('/api/calls', methods=['GET'])
def get_calls():
    return jsonify({"success": True, "calls": db['call_logs']})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
