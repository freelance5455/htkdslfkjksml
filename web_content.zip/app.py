import os, tempfile, subprocess, shutil
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory, send_file
import requests
from dotenv import load_dotenv

load_dotenv()
BASE=Path(__file__).resolve().parent
app=Flask(__name__)
KEY=os.getenv("ELEVENLABS_API_KEY","").strip()
MAX_MB=int(os.getenv("MAX_UPLOAD_MB","500"))

VOICES=[
("Indian Female 1",os.getenv("VOICE_INDIAN_FEMALE_1","")),
("Indian Female 2",os.getenv("VOICE_INDIAN_FEMALE_2","")),
("Indian Female 3",os.getenv("VOICE_INDIAN_FEMALE_3","")),
("Indian Male 1",os.getenv("VOICE_INDIAN_MALE_1","")),
("Indian Male 2",os.getenv("VOICE_INDIAN_MALE_2","")),
("American Female 1",os.getenv("VOICE_AMERICAN_FEMALE_1","")),
("American Female 2",os.getenv("VOICE_AMERICAN_FEMALE_2","")),
("American Male 1",os.getenv("VOICE_AMERICAN_MALE_1","")),
("American Male 2",os.getenv("VOICE_AMERICAN_MALE_2","")),
]

def key():
 if not KEY: raise RuntimeError("ELEVENLABS_API_KEY .env में सेट नहीं है।")
def check_size(path):
 mb=os.path.getsize(path)/1024/1024
 if mb>MAX_MB: raise ValueError(f"File {MAX_MB} MB से बड़ी है।")

@app.get("/")
def home(): return send_from_directory(BASE,"index.html")

@app.get("/api/voices")
def voices():
 return jsonify(voices=[{"name":n,"id":i} for n,i in VOICES if i])

@app.post("/api/transcribe")
def transcribe():
 path=None
 try:
  key()
  f=request.files.get("file")
  if not f:return jsonify(error="Video file नहीं मिली।"),400
  suffix=Path(f.filename).suffix or ".mp4"
  with tempfile.NamedTemporaryFile(delete=False,suffix=suffix) as t:
   f.save(t.name);path=t.name
  check_size(path)
  with open(path,"rb") as fh:
   r=requests.post("https://api.elevenlabs.io/v1/speech-to-text",
     headers={"xi-api-key":KEY},
     files={"file":(f.filename,fh,f.mimetype or "application/octet-stream")},
     data={"model_id":"scribe_v2"},timeout=1800)
  if not r.ok:return jsonify(error="Speech-to-Text API error: "+r.text[:700]),r.status_code
  d=r.json()
  return jsonify(text=d.get("text",""),language=d.get("language_code",""))
 except Exception as e:return jsonify(error=str(e)),500
 finally:
  if path:
   try:os.unlink(path)
   except OSError:pass

@app.post("/api/tts")
def tts():
 path=None;out=None
 try:
  key();d=request.get_json(silent=True) or {}
  text=str(d.get("text","")).strip();vid=str(d.get("voice_id","")).strip()
  speed=max(.7,min(1.2,float(d.get("speed",1))));pitch=max(-6,min(6,int(d.get("pitch",0))));volume=max(0,min(1,float(d.get("volume",1))))
  if not text:return jsonify(error="Script खाली है।"),400
  if not vid:return jsonify(error="Voice ID configured नहीं है।"),400
  r=requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{vid}?output_format=mp3_44100_128",
   headers={"xi-api-key":KEY,"Content-Type":"application/json"},
   json={"text":text,"model_id":"eleven_multilingual_v2"},timeout=1800)
  if not r.ok:return jsonify(error="TTS API error: "+r.text[:700]),r.status_code
  with tempfile.NamedTemporaryFile(delete=False,suffix=".mp3") as t:t.write(r.content);path=t.name
  if shutil.which("ffmpeg"):
   with tempfile.NamedTemporaryFile(delete=False,suffix=".mp3") as t:out=t.name
   # Pitch in semitones; speed is applied while preserving the requested duration change.
   pf=2**(pitch/12)
   filters=f"asetrate=44100*{pf},aresample=44100,atempo={speed},volume={volume}"
   p=subprocess.run(["ffmpeg","-y","-i",path,"-filter:a",filters,"-codec:a","libmp3lame","-b:a","128k",out],capture_output=True)
   if p.returncode==0:
    os.unlink(path);path=None
    resp=send_file(out,mimetype="audio/mpeg",download_name="ai-voice.mp3")
    @resp.call_on_close
    def clean(): 
     try:os.unlink(out)
     except OSError:pass
    return resp
  resp=send_file(path,mimetype="audio/mpeg",download_name="ai-voice.mp3")
  @resp.call_on_close
  def clean2():
   try:os.unlink(path)
   except OSError:pass
  return resp
 except Exception as e:return jsonify(error=str(e)),500
 finally:
  pass

@app.post("/api/merge-video")
def merge_video():
 vpath=apath=out=None
 try:
  if not shutil.which("ffmpeg"):return jsonify(error="FFmpeg installed नहीं है। Final video processing के लिए FFmpeg चाहिए।"),500
  v=request.files.get("video");a=request.files.get("audio")
  if not v or not a:return jsonify(error="Video और audio दोनों चाहिए।"),400
  sound=request.form.get("original_sound","mute")
  mode=request.form.get("audio_mode","fit")
  vs=Path(v.filename).suffix or ".mp4";asuf=Path(a.filename).suffix or ".mp3"
  with tempfile.NamedTemporaryFile(delete=False,suffix=vs) as t:v.save(t.name);vpath=t.name
  with tempfile.NamedTemporaryFile(delete=False,suffix=asuf) as t:a.save(t.name);apath=t.name
  check_size(vpath);check_size(apath)
  with tempfile.NamedTemporaryFile(delete=False,suffix=".mp4") as t:out=t.name
  # Determine video duration and audio duration.
  def duration(p):
   q=subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","default=noprint_wrappers=1:nokey=1",p],capture_output=True,text=True)
   return float(q.stdout.strip())
  vd=duration(vpath);ad=duration(apath)
  if vd<=0 or ad<=0:raise RuntimeError("Video/audio duration नहीं पढ़ी जा सकी।")
  # For "fit", tempo is chosen to make audio exactly video length.
  # FFmpeg atempo accepts 0.5..2.0 per filter; chain multiple filters for wider ratios.
  ratio=ad/vd  # audio speed multiplier needed: new duration = ad/ratio = vd
  filters=[]
  remaining=ratio
  while remaining<0.5:
   filters.append("atempo=0.5");remaining/=0.5
  while remaining>2:
   filters.append("atempo=2");remaining/=2
  filters.append(f"atempo={remaining}")
  af=",".join(filters)
  if mode=="fit":
   if sound=="mute":
    cmd=["ffmpeg","-y","-i",vpath,"-i",apath,"-map","0:v:0","-map","1:a:0","-vf","setpts=PTS","-af",af,"-c:v","libx264","-preset","veryfast","-c:a","aac","-b:a","128k","-shortest",out]
   else:
    # Keep original audio quiet while mixing new audio; here we use 30% original.
    cmd=["ffmpeg","-y","-i",vpath,"-i",apath,"-filter_complex",f"[1:a]{af}[new];[0:a]volume=0.3[orig];[orig][new]amix=inputs=2:duration=first:dropout_transition=2[a]","-map","0:v:0","-map","[a]","-c:v","libx264","-preset","veryfast","-c:a","aac","-b:a","128k",out]
  else:
   if sound=="mute":
    cmd=["ffmpeg","-y","-i",vpath,"-i",apath,"-map","0:v:0","-map","1:a:0","-c:v","libx264","-preset","veryfast","-c:a","aac","-b:a","128k","-shortest",out]
   else:
    cmd=["ffmpeg","-y","-i",vpath,"-i",apath,"-filter_complex","[0:a]volume=0.3[orig];[orig][1:a]amix=inputs=2:duration=first:dropout_transition=2[a]","-map","0:v:0","-map","[a]","-c:v","libx264","-preset","veryfast","-c:a","aac","-b:a","128k",out]
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=3600)
  if p.returncode!=0:raise RuntimeError("FFmpeg error: "+p.stderr[-900:])
  resp=send_file(out,mimetype="video/mp4",download_name="final-video.mp4")
  @resp.call_on_close
  def cleanup():
   for pth in (vpath,apath,out):
    try:os.unlink(pth)
    except OSError:pass
  return resp
 except Exception as e:
  for pth in (vpath,apath,out):
   if pth:
    try:os.unlink(pth)
    except OSError:pass
  return jsonify(error=str(e)),500

if __name__=="__main__":
 app.run(host=os.getenv("HOST","0.0.0.0"),port=int(os.getenv("PORT","5000")),debug=False)
