import uuid
import time
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# In-memory storage (für die Sitzung / bis der Server neu gestartet wird)
# Struktur: { user_id: { "name": str, "contacts": [contact_id, ...] } }
users = {}

# Struktur: { "id1_id2": [ { "sender_id": str, "sender_name": str, "text": str, "time": str }, ... ] }
chats = {}


def get_chat_key(id1, id2):
    return "_".join(sorted([id1, id2]))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/register", methods=["POST"])
def register():
    data = request.json or {}
    name = data.get("name", "").strip()
    existing_id = data.get("user_id", "").strip()

    if not name:
        return jsonify({"error": "Bitte gib einen Namen ein."}), 400

    # Falls der Nutzer schon eine ID im Browser gespeichert hat, wiederverwenden
    if existing_id and existing_id in users:
        users[existing_id]["name"] = name
        user_id = existing_id
    else:
        # Kurze, leicht abtippbare 8-stellige ID generieren (z.B. A1B2-C3D4)
        raw = uuid.uuid4().hex[:8].upper()
        user_id = f"{raw[:4]}-{raw[4:]}"
        users[user_id] = {
            "name": name,
            "contacts": []
        }

    return jsonify({
        "user_id": user_id,
        "name": users[user_id]["name"]
    })


@app.route("/api/state/<user_id>", methods=["GET"])
def get_state(user_id):
    if user_id not in users:
        return jsonify({"error": "Benutzer nicht gefunden"}), 404

    user = users[user_id]
    contacts_info = []
    for cid in user["contacts"]:
        if cid in users:
            chat_key = get_chat_key(user_id, cid)
            chat_msgs = chats.get(chat_key, [])
            last_msg = chat_msgs[-1]["text"] if chat_msgs else "Noch keine Nachrichten"
            last_time = chat_msgs[-1]["time"] if chat_msgs else ""
            contacts_info.append({
                "id": cid,
                "name": users[cid]["name"],
                "last_msg": last_msg,
                "last_time": last_time
            })

    return jsonify({
        "user_id": user_id,
        "name": user["name"],
        "contacts": contacts_info
    })


@app.route("/api/add_contact", methods=["POST"])
def add_contact():
    data = request.json or {}
    user_id = data.get("user_id", "").strip()
    target_id = data.get("target_id", "").strip().upper()

    if user_id not in users:
        return jsonify({"error": "Eigene Sitzung ungültig."}), 404
    if not target_id:
        return jsonify({"error": "Bitte gib eine ID ein."}), 400
    if target_id == user_id:
        return jsonify({"error": "Du kannst dich nicht selbst hinzufügen."}), 400
    if target_id not in users:
        return jsonify({"error": "Diese ID existiert nicht (Nutzer muss zuerst seinen Namen eingeben)."}), 404

    # Gegenseitig zu den Kontakten hinzufügen, damit beide den Chat sehen
    if target_id not in users[user_id]["contacts"]:
        users[user_id]["contacts"].append(target_id)
    if user_id not in users[target_id]["contacts"]:
        users[target_id]["contacts"].append(user_id)

    return jsonify({
        "success": True,
        "contact": {
            "id": target_id,
            "name": users[target_id]["name"]
        }
    })


@app.route("/api/messages/<user_id>/<target_id>", methods=["GET"])
def get_messages(user_id, target_id):
    if user_id not in users or target_id not in users:
        return jsonify({"error": "Ungültige IDs"}), 404

    chat_key = get_chat_key(user_id, target_id)
    return jsonify({
        "messages": chats.get(chat_key, [])
    })


@app.route("/api/send", methods=["POST"])
def send_message():
    data = request.json or {}
    user_id = data.get("user_id", "").strip()
    target_id = data.get("target_id", "").strip()
    text = data.get("text", "").strip()

    if user_id not in users or target_id not in users:
        return jsonify({"error": "Ungültige Benutzer-ID"}), 404
    if not text:
        return jsonify({"error": "Nachricht ist leer"}), 400

    # Sicherstellen, dass beide einander in der Kontaktliste haben
    if target_id not in users[user_id]["contacts"]:
        users[user_id]["contacts"].append(target_id)
    if user_id not in users[target_id]["contacts"]:
        users[target_id]["contacts"].append(user_id)

    chat_key = get_chat_key(user_id, target_id)
    if chat_key not in chats:
        chats[chat_key] = []

    msg = {
        "sender_id": user_id,
        "sender_name": users[user_id]["name"],
        "text": text,
        "time": time.strftime("%H:%M")
    }
    chats[chat_key].append(msg)

    return jsonify({"success": True, "message": msg})


if __name__ == "__main__":
    # host="0.0.0.0" erlaubt den Zugriff von anderen Handys im selben WLAN/Netzwerk
    app.run(host="0.0.0.0", port=5000, debug=True)
