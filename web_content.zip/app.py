import os
from flask import Flask, request, jsonify, render_template
from openai import OpenAI

app = Flask(__name__)

api_key = os.environ.get("OPENAI_API_KEY")
client = OpenAI(api_key=api_key) if api_key else None

SYSTEM_PROMPT = """
You are Vetri AI, a friendly personal assistant.
Use simple, clear language suitable for a beginner.
If the user writes in Tamil or Tanglish, answer in the same language.
For programming questions, include a working example and explain it step by step.
Be honest if you are unsure. Do not claim to perform actions you cannot perform.
"""

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    history = data.get("history", [])

    if not message:
        return jsonify({"error": "Please type a message."}), 400
    if len(message) > 4000:
        return jsonify({"error": "Please keep each message under 4,000 characters."}), 400
    if client is None:
        return jsonify({"error": "The server administrator has not configured OPENAI_API_KEY."}), 503

    # Only accept a short, validated conversation history from the client.
    input_items = []
    if isinstance(history, list):
        for item in history[-10:]:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            content = item.get("content")
            if role in ("user", "assistant") and isinstance(content, str):
                input_items.append({"role": role, "content": content[:4000]})
    input_items.append({"role": "user", "content": message})

    try:
        response = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-5.5"),
            instructions=SYSTEM_PROMPT,
            input=input_items,
            max_output_tokens=700,
        )
        return jsonify({"reply": response.output_text})
    except Exception:
        app.logger.exception("AI request failed")
        return jsonify({"error": "The AI request failed. Check server logs and API account settings."}), 502

if __name__ == "__main__":
    # For local testing only. Use a production WSGI server when deploying.
    app.run(host="127.0.0.1", port=5000, debug=False)
