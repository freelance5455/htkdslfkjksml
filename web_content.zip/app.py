"""FX Trader desktop app: a local web UI. Run:  python app.py   (or double-click 'Run FX Trader.bat')

Only uses the packages already in requirements.txt. Listens on 127.0.0.1 only.
"""
import json
import math
import re
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import numpy as np
import pandas as pd

from fx_trader.backtest import run_backtest
from fx_trader.config import Config
from fx_trader.data import load_csv, synthetic_prices, to_hourly
from fx_trader.strategy import STRATEGIES

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
INDEX = ROOT / "web" / "index.html"
PORT = 8765
MAX_UPLOAD = 400 * 1024 * 1024
JOBS: dict = {}


def clean(o):
    """Make numpy/pandas values JSON-safe (NaN/inf -> None)."""
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        return None if (math.isnan(o) or math.isinf(o)) else float(o)
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, (pd.Timestamp,)):
        return o.strftime("%Y-%m-%d %H:%M")
    return o


def list_csvs():
    out = []
    for folder in (ROOT, DATA):
        for f in sorted(folder.glob("*.csv")):
            if not f.name.lower().startswith("trades"):
                out.append(str(f.relative_to(ROOT)))
    return out


def resolve_csv(name: str) -> Path:
    p = (ROOT / name).resolve()
    if p.suffix.lower() != ".csv" or ROOT not in p.parents:
        raise ValueError("Pick a .csv file from the project folder.")
    if not p.exists():
        raise FileNotFoundError(f"File not found: {name}")
    return p


def verdict(m, demo, rows):
    notes = []
    if demo:
        notes.append(("warn", "Demo data: artificial prices, only useful to test the app. These numbers mean nothing for real trading."))
    pf, tr = m.get("profit_factor"), m.get("trades", 0)
    if tr < 30:
        notes.append(("warn", f"Only {tr} trades: too few to judge anything."))
    elif pf is not None and pf < 1.0:
        notes.append(("bad", f"No edge found: profit factor {pf:.2f} (below 1.0 means it loses money after costs). Do not trade this setup."))
    elif pf is not None and pf < 1.2:
        notes.append(("warn", f"Marginal: profit factor {pf:.2f} is within the range luck and costs can explain."))
    elif pf is not None:
        notes.append(("good", f"Profit factor {pf:.2f}. Promising, but verify on other pairs and other years before trusting it."))
    if m.get("max_drawdown_pct", 0) < -30:
        notes.append(("bad", f"Max drawdown {m['max_drawdown_pct']:.0f}%: far more loss than most people can stick with."))
    return notes


def run_job(jid, p):
    job = JOBS[jid]
    try:
        cfg = Config(pair=p.get("pair", "EURUSD").upper(), risk_per_trade=float(p["risk"]) / 100,
                     spread_pips=float(p["spread"]), sl_atr_mult=float(p["sl_atr"]), rr=float(p["rr"]),
                     dd_halve=float(p["dd_halve"]) / 100, dd_stop=float(p["dd_stop"]) / 100)
        demo = p["source"] == "__demo__"
        job["stage"] = "Loading data"
        df = synthetic_prices(int(p.get("bars", 20000))) if demo else load_csv(str(resolve_csv(p["source"])))
        df, resampled = to_hourly(df)
        name = p["strategy"]
        strat = STRATEGIES[name](cfg) if name == "brain" else STRATEGIES[name]()
        job["stage"] = "Training model and simulating trades" if name != "trend" else "Simulating trades"
        d = strat.prepare(df)
        sig = strat.signals(d)
        job["stage"] = "Simulating trades"
        res = run_backtest(d, sig, cfg)

        eq = res.equity
        step = max(1, len(eq) // 900)
        eqs = eq.iloc[::step]
        dd = (eq / eq.cummax() - 1) * 100
        dds = dd.iloc[::step]
        dated = isinstance(eq.index, pd.DatetimeIndex)
        years = []
        if dated:
            g = eq.groupby(eq.index.year).agg(["first", "last"])
            years = [{"year": int(y), "ret": float((r["last"] / r["first"] - 1) * 100)} for y, r in g.iterrows()]
        tr = res.trades
        job["trades_df"] = tr
        job["result"] = clean({
            "metrics": res.metrics,
            "equity": {"x": [str(t)[:10] for t in eqs.index] if dated else list(range(len(eqs))), "y": eqs.round(2).tolist()},
            "drawdown": dds.round(2).tolist(),
            "years": years,
            "trades": tr.tail(300).to_dict("records") if len(tr) else [],
            "notes": verdict(res.metrics, demo, len(d)),
            "info": {"bars": len(d), "resampled": resampled, "strategy": name,
                     "first": str(d.index[0])[:10] if dated else "", "last": str(d.index[-1])[:10] if dated else ""},
        })
        job["status"] = "done"
    except Exception as e:  # report to UI
        job["status"] = "error"
        job["error"] = f"{type(e).__name__}: {e}"
        traceback.print_exc()


class Handler(BaseHTTPRequestHandler):
    server_version = "FXTrader"

    def log_message(self, *a):
        pass

    def _ok_host(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(clean(body)).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._ok_host():
            return self._send(403, {"error": "forbidden"})
        u = urlparse(self.path)
        if u.path == "/":
            return self._send(200, INDEX.read_text(encoding="utf-8"), "text/html; charset=utf-8")
        if u.path == "/api/files":
            return self._send(200, {"files": list_csvs(), "strategies": list(STRATEGIES)})
        if u.path == "/api/job":
            job = JOBS.get(parse_qs(u.query).get("id", [""])[0])
            if not job:
                return self._send(404, {"error": "unknown job"})
            out = {"status": job["status"], "stage": job.get("stage", ""), "elapsed": time.time() - job["t0"]}
            if job["status"] == "done":
                out["result"] = job["result"]
            if job["status"] == "error":
                out["error"] = job["error"]
            return self._send(200, out)
        if u.path == "/api/trades.csv":
            job = JOBS.get(parse_qs(u.query).get("id", [""])[0])
            if not job or job.get("trades_df") is None:
                return self._send(404, {"error": "no trades"})
            return self._send(200, job["trades_df"].to_csv(index=False), "text/csv",
                              {"Content-Disposition": "attachment; filename=trades.csv"})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._ok_host() or self.headers.get("X-FX") != "1":
            return self._send(403, {"error": "forbidden"})
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        if u.path == "/api/run":
            p = json.loads(self.rfile.read(n) or b"{}")
            jid = uuid.uuid4().hex[:10]
            JOBS[jid] = {"status": "running", "stage": "Starting", "t0": time.time()}
            threading.Thread(target=run_job, args=(jid, p), daemon=True).start()
            return self._send(200, {"id": jid})
        if u.path == "/api/upload":
            if n > MAX_UPLOAD:
                return self._send(413, {"error": "File too large (max 400 MB)."})
            name = re.sub(r"[^A-Za-z0-9._-]", "_", Path(parse_qs(u.query).get("name", ["upload.csv"])[0]).name)
            if not name.lower().endswith(".csv"):
                return self._send(400, {"error": "Only .csv files."})
            dest = DATA / name
            left = n
            with open(dest, "wb") as f:
                while left > 0:
                    chunk = self.rfile.read(min(1 << 20, left))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            return self._send(200, {"saved": str(dest.relative_to(ROOT))})
        self._send(404, {"error": "not found"})


def main():
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print(f"Port {PORT} is busy. Is FX Trader already running? Opening it in your browser.")
        webbrowser.open(f"http://127.0.0.1:{PORT}")
        return
    url = f"http://127.0.0.1:{PORT}"
    print(f"FX Trader is running at {url}\nKeep this window open. Press Ctrl+C to quit.")
    if "--no-browser" not in sys.argv:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
