# Feature map

| Feature | Prototype status | Notes |
|---|---|---|
| Custom HUD | Interactive preview | Demonstration overlay inside the prototype page |
| FPS counter | Simulated | Decorative sample value; not connected to Minecraft rendering |
| Keystrokes / CPS | Simulated | Demo keys react to keyboard presses only while the prototype page is focused |
| Click GUI | Functional UI | Toggles preview widgets and settings |
| Custom crosshair | Functional preview | Select from dot, plus, and ring |
| Animations / effects | Included | CSS gradients, particles, hover and panel transitions |

## Potential next steps

For a Bedrock-compatible content package, separate supported texture/UI overrides into a resource pack and test against the exact game build. Keep standalone companion UI features separate from in-game functionality unless a supported platform integration exists.
