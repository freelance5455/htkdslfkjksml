# Obsidian — Bedrock Client UI Prototype

An original, Flarial-inspired *visual prototype* for an Android Minecraft Bedrock client concept. This project is a standalone web UI mockup: it does **not** inject into Minecraft, modify the game APK, or provide actual in-game overlays.

## Preview / run

1. Extract the ZIP.
2. Open `index.html` in a modern browser on Android or desktop.
3. Use the top-right menu icon to open the Click GUI.
4. Toggle HUD widgets, switch themes, adjust crosshair style, and preview animations.

For a local web server on a computer, run:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000`.

## Included prototype features

- Original Obsidian dark-glass UI and cyan/violet accents
- Custom HUD preview with health, armor, coordinates, and status panels
- Simulated FPS counter (decorative sample value, not measured from Minecraft)
- Keystrokes and CPS preview (UI demo only; does not read game input)
- Click GUI with functional toggles
- Custom crosshair selector and live preview
- Animated gradients, particles, glow and transitions
- Responsive layout for phone screens

## Compatibility limitations

- Target concept: Minecraft Bedrock 26.60 on Android.
- This ZIP is a standalone UI prototype, not a `.mcpack`, APK, launcher, or native Bedrock client.
- Bedrock resource packs can change supported textures and some UI resources, but cannot independently provide an arbitrary floating click GUI, real FPS telemetry, live keystroke/CPS tracking, or code injection.
- Actual integration would require platform- and version-specific implementation, and some capabilities may not be exposed by Bedrock on Android.
- Compatibility with modified/cracked game builds cannot be guaranteed. This project does not bypass licensing, authentication, or game protections.

## Files

- `index.html` — full standalone prototype
- `README.md` — this guide
- `docs/FEATURES.md` — feature map and future integration notes

No third-party client branding or assets are included; Obsidian is an original concept name.
