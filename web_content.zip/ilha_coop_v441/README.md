# ILHA COOP v3.7

Protótipo 3D de battle royale para navegador móvel (usar em orientação horizontal).

## Novidades da v3.7
- Personagens com mais camadas de equipamento 3D: gola, ombreiras, braçadeiras, joelheiras, bolsas, tiras e detalhes de rosto/cabelo.
- Lobby com prévia 3D real do personagem selecionado, em pedestal iluminado e com animação idle suave; substitui o emoji como elemento principal.
- A prévia 3D acompanha a classe escolhida e retorna corretamente ao cenário de partida ao iniciar uma rodada.

## Recursos mantidos da v3.6
- HUD reorganizado com posições padrão mais espaçadas para reduzir sobreposição entre joystick, tiro, pulo, agachar, recarregar, cura, coleta e habilidades.
- Editor de HUD continua disponível; a nova versão usa uma chave de salvamento separada para aplicar o novo layout padrão sem apagar configurações antigas.
- Painel de configurações ampliado: sensibilidade, aceleração, precisão e assistência de mira, vibração, música, efeitos, áudio, qualidade gráfica, FPS, sombras, coleta automática e dicas.
- Preferências compatíveis são salvas localmente no navegador.
- Botão de saída/desistência durante a partida, com confirmação e retorno ao lobby.
- Loja com itens de demonstração, saldo de moedas e compra local simulada.
- Eventos e missões com cartões informativos e botão para voltar ao lobby.

## Limitações importantes
- Loja, eventos, missões, moedas e preferências são locais/demonstrativos; não existe servidor, conta online, compras reais ou sincronização entre dispositivos.
- Opções gráficas/FPS e mira são apresentadas na interface; nem todas controlam ainda parâmetros reais do motor.
- O jogo segue como protótipo Three.js, não um produto comercial nem uma cópia de Free Fire.


## v3.8 — corpo e movimentação
- Personagem reconstruído com proporções atléticas, tronco definido, ombros mais largos e membros articulados.
- Animações de caminhada/corrida, balanço de braços e pernas, agachamento e salto com gravidade simples.
- Corrida ativada ao empurrar o analógico até perto do limite.
- Câmera aproximada mais um pouco, com enquadramento de terceira pessoa.
- Continua sendo um protótipo Three.js: não usa rig profissional, captura de movimento ou animações externas.

## v3.9 — identidade visual de entrada e seleção de classe
- Tela inicial redesenhada a partir da arte de referência enviada: cenário panorâmico, painel de acesso à direita, login e entrada como visitante.
- Removido o botão visual "Começar jogo" da tela inicial; a entrada segue por login ou visitante e depois seleção de classe.
- Tela de seleção reorganizada com seis artes de classe em cartões grandes, seleção destacada e painel com função/habilidades.
- Adicionadas seis miniaturas de raça na faixa inferior para escolher Humano, Elfo, Fada, Goblin, Anão ou Elfo Sombrio.
- Artes recortadas das imagens de referência fornecidas nesta conversa e incluídas localmente em `assets/`; não dependem de links externos para carregar.
- As imagens são ilustrações 2D para a interface de seleção. O personagem controlável e a prévia do lobby continuam usando o modelo 3D procedural do protótipo; os recortes não substituem um rig 3D profissional.
- A tela inicial usa a arte enviada como fundo e substitui a área de chamada original por um painel próprio com login/visitante. Não há autenticação online real.


## Versão 4.0
- Loja, Eventos e Missões agora abrem em páginas próprias de tela inteira, separadas visualmente do lobby, com navegação de voltar.
- Loja ampliada com categorias visuais e itens demonstrativos; moedas e compras permanecem locais ao protótipo.
- Preservada a correção de transição para iniciar partidas da versão 3.9.1.


## v4.2
Lobby 3D aprimorado com companheiro ao lado do personagem, plataforma com halo, cristais flutuantes animados e enquadramento de câmera mais amplo. Mantidas as páginas independentes de Loja, Eventos e Missões e a transição de partida da v3.9.1.


## Atualização 4.3 — refinamento visual
- Personagens com equipamento em camadas: placas, fivelas, bolsas, reforços e detalhes metálicos.
- Animação adicional de capa e micro movimentos de cabeça para dar mais vida aos personagens.
- Pequeno ajuste de resolução interna para telas de maior densidade, mantendo limite para desempenho móvel.


## Correção 4.4.1 — estabilidade e desempenho móvel
- Reconstruída a partir da versão 4.3, preservando a inicialização e o fluxo de login conhecidos.
- Ajustes conservadores de resolução interna e tipo/tamanho de sombra para dispositivos móveis.
- Renderização suspensa quando a aba fica oculta.
- Não foram alterados o sistema de login, a criação dos mapas nem a transição para a partida.

## v4.5 — personagem e áudio (qualidade visual)
- Personagem reconstruído com proporções mais agressivas (ombros largos, cintura marcada, pernas alongadas).
- Cabeça com olhos, nariz, cabelo e detalhes por classe (máscara do Assassino, elmo do Guerreiro, halo do Curandeiro, chifres do Druida, capuz do Mago).
- Mãos visíveis, botas mais volumosas, placas e rebites metálicos.
- Ciclo de caminhada/corrida mais natural: fase oposta de pernas, flexão de joelho, balanço de braços, rotação do tronco e bounce.
- Idle vivo com respiração e micro movimento de cabeça.
- Sons de passo (walk e run), pulo e aterrissagem via Web Audio (ruído + tom).
- Capa com sway mais pronunciado.

## v4.6 — combate, câmera e feedback (estilo Free Fire)
- Câmera mais próxima, no ombro direito, com lerp mais responsivo e recuperação de recoil.
- Crosshair central + hit marker branco + flash vermelho de dano recebido.
- Tiro com muzzle flash, faíscas no impacto, recoil de câmera e pose de mira nos braços.
- Toast de eliminação e som de eliminação.
- Lobby com iluminação key/fill/rim, enquadramento cinematográfico e idle animado nos personagens.
- Passos, pulo e aterrissagem (v4.5) mantidos.

## v4.7 — fase 2: drop do avião + câmera Free Fire
- Entrada completa: contagem → avião → salto → queda livre → paraquedas → pouso.
- Queda livre com steering pelo joystick; paraquedas manual (botão ou auto perto do chão).
- Pouso em área aberta (evita nascer dentro de casa).
- Câmera no solo mais próxima, ombro direito, FOV dinâmico.
- Câmera aérea dedicada durante o drop.
- Personagens ocultos na cutscene do avião.

## v4.8 — fase 3: HUD e feedback de combate
- Kill feed no canto superior direito.
- Números de dano flutuantes ao acertar.
- Barras de HP/EP mais visíveis + barra de escudo quando ativo.
- Bússola no topo e timer da partida.
- Aviso de zona com modo perigo + vinheta nas bordas fora da safe zone.
- Recarga automática no seco + toque no indicador de munição; banner RECARREGANDO.
- Dica de loot no chão.
- Slots de arma com contador de munição.

## v4.9 — bots inteligentes + loot + polimento
- Bots com personalidade: aggressive, passive, lurker (nomes, HP e precisão diferentes).
- IA: chase, kite, hunt, patrol; strafe em combate; fogem para a zona.
- Tiro dos bots com chance realista por distância.
- Loot com beacon, anel e flutuação; drops ao eliminar bots.
- Mais loot no mapa (regiões + casas).
- Collect com mensagens claras e melhor alcance.

## v5.0 — tamanho FF, armas no chão, lobby emotes, performance
- Personagem maior na partida (scale 1.35) + câmera mais próxima; mira mais alta.
- Sem arma inicial; arsenal ampliado (Pistola, USP, MP5, MP40, UMP, AK, M4, Shotgun, AWP, Kar98) com munição por tipo.
- Seleção de classe com imagens visíveis + preview grande.
- Lobby: personagem bem maior; toque abre emotes funcionais (acenar, dançar, etc.).
- Performance: menos bots (12), pixel ratio menor no mobile, sombras off no mobile, loot anim só perto.
- HUD mais próximo do layout Free Fire.
