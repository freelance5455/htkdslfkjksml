const CACHE_NAME = 'mp-milk-v25';
const ASSETS = ['./index.html', './manifest.json', './mp_milk_logo.jpg'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE_NAME).then(c => c.addAll(ASSETS)));
});
self.addEventListener('fetch', e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
