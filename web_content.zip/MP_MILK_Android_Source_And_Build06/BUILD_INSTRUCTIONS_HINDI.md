# MP Milk – ZIP से APK बनाने की आसान गाइड (Developer: MP_Choudhary)

## इस ZIP फाइल के अंदर क्या है?
1. `www/index.html` — आपका पूरा **MP Milk** ऐप (जिसमें मदन पटेल की 39 शिफ्ट • 228.1 L का हिसाब और Asha MPO के भाव पहले से सेट हैं)।
2. `www/mp_milk_logo.jpg` — MP Milk का नया ऑफिशियल गोल लोगो।
3. `config.xml` — मोबाइल से सीधे Zip-to-APK (Cordova / VoltBuilder / WebIntoApp) बनाने की कॉन्फ़िगरेशन फाइल।
4. `android_studio_project/` — Android APK का पूरा Java व Manifest सोर्स कोड (बिना Camera और बिना Firebase के)।

## मोबाइल पर ZIP से APK कैसे बनाएं?
- **तरीका 1 (WebIntoApp / VoltBuilder):** इस `MP_MILK_Android_Source_And_Build.zip` को अपलोड करें, ऐप का नाम `MP Milk` रखें और 1 क्लिक में `.apk` डाउनलोड कर लें।
- **तरीका 2 (Termux / Cordova):** `cordova create mpmilk com.mpmilk.dairyhisab "MP Milk"` चलाकर `www` फोल्डर कॉपी करें और `cordova build android` से APK बनाएं।
