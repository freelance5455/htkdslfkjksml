// Adaptadores de inferência online compatíveis com a API Chat Completions.
export const PRESETS = {
  pollinations: { url: 'https://text.pollinations.ai/openai', model: 'openai' },
  huggingface: { url: 'https://router.huggingface.co/v1/chat/completions', model: 'Qwen/Qwen2.5-7B-Instruct' },
  custom: { url: '', model: '' }
};

export const localReady = () => false;
export async function loadLocal() {
  throw new Error('Esta edição utiliza inteligência online. Configure um provedor nas Configurações.');
}

export async function chat(cfg, messages, onText = () => {}, signal) {
  if (cfg.mode !== 'online') throw new Error('O modo desta edição é online.');
  if (!cfg.url) throw new Error('Configure a URL do provedor nas Configurações.');
  if (!cfg.model) throw new Error('Informe o identificador do modelo nas Configurações.');

  const headers = { 'Content-Type': 'application/json', 'Accept': 'text/event-stream, application/json' };
  if (cfg.key?.trim()) headers.Authorization = 'Bearer ' + cfg.key.trim();

  const response = await fetch(cfg.url.trim(), {
    method: 'POST', headers, signal,
    body: JSON.stringify({
      model: cfg.model.trim(),
      messages,
      stream: true,
      temperature: 0.5,
      max_tokens: Number(cfg.maxTokens) || 350
    })
  });

  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    throw new Error(`Provedor respondeu HTTP ${response.status}. ${detail}`);
  }
  if (!response.body) return await response.text();

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '', output = '';
  const consume = line => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith(':') || !trimmed.startsWith('data:')) return;
    const data = trimmed.slice(5).trim();
    if (data === '[DONE]') return;
    try {
      const obj = JSON.parse(data);
      const delta = obj.choices?.[0]?.delta?.content;
      const full = obj.choices?.[0]?.message?.content;
      const piece = typeof delta === 'string' ? delta : (typeof full === 'string' && !output ? full : '');
      if (piece) { output += piece; onText(output); }
    } catch { /* ignora fragmentos SSE incompletos */ }
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() || '';
    lines.forEach(consume);
  }
  buffer += decoder.decode();
  if (buffer) consume(buffer);
  if (!output) throw new Error('O provedor não retornou texto. Confira modelo, URL e chave de API.');
  return output;
}
