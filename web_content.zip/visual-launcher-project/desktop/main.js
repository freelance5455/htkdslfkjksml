'use strict';

const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execFile } = require('child_process');
const { Readable, Transform } = require('stream');
const { pipeline } = require('stream/promises');
const extractZip = require('extract-zip');
const tar = require('tar');
const { Client, Authenticator } = require('minecraft-launcher-core');

const MANIFEST_URL = 'https://launchermeta.mojang.com/mc/game/version_manifest_v2.json';
const NICK_RE = /^[A-Za-z0-9_]{3,16}$/;

const userData = app.getPath('userData');
const settingsFile = path.join(userData, 'settings.json');
const manifestCache = path.join(userData, 'versions-cache.json');
const runtimeDir = path.join(userData, 'runtime');

let win = null;
let busy = false;
const versionUrls = new Map();
const logBuffer = [];

/* ---------- утилиты ---------- */

function send(channel, data) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, data);
}

function status(stage, text, pct = null) {
  send('launch:status', { stage, text, pct });
}

function log(text) {
  for (const line of String(text).split(/\r?\n/)) {
    if (!line) continue;
    logBuffer.push(line);
    if (logBuffer.length > 2000) logBuffer.shift();
    send('log', line);
  }
}

function friendly(e) {
  const msg = String((e && e.message) || e);
  if (/fetch failed|ENOTFOUND|ECONNRESET|ETIMEDOUT|EAI_AGAIN|aborted|timeout/i.test(msg)) {
    return 'Нет соединения с интернетом. Проверь сеть и попробуй ещё раз.';
  }
  if (/ENOSPC/.test(msg)) return 'Не хватает места на диске.';
  if (/EACCES|EPERM/.test(msg)) return 'Нет доступа к папке игры. Выбери другую папку в настройках.';
  return msg;
}

async function fetchJson(url, ms = 15000) {
  const res = await fetch(url, { signal: AbortSignal.timeout(ms) });
  if (!res.ok) throw new Error(`Сервер ответил ${res.status}`);
  return res.json();
}

/* ---------- настройки ---------- */

function defaults() {
  const totalGb = os.totalmem() / 1024 ** 3;
  return {
    device: '',
    edition: 'java',
    nickname: 'Player',
    version: '',
    memoryGb: totalGb >= 12 ? 4 : 2,
    snapshots: false,
    gameDir: path.join(userData, 'minecraft'),
  };
}

function loadSettings() {
  try {
    return { ...defaults(), ...JSON.parse(fs.readFileSync(settingsFile, 'utf8')) };
  } catch {
    return defaults();
  }
}

function saveSettings(s) {
  fs.mkdirSync(path.dirname(settingsFile), { recursive: true });
  fs.writeFileSync(settingsFile, JSON.stringify(s, null, 2));
}

/* ---------- версии ---------- */

function slimManifest(data) {
  const versions = data.versions
    .filter((v) => v.type === 'release' || v.type === 'snapshot')
    .map((v) => {
      versionUrls.set(v.id, v.url);
      return { id: v.id, type: v.type };
    });
  return { latest: data.latest, versions };
}

async function getVersionMeta(id, gameDir) {
  const local = path.join(gameDir, 'versions', id, `${id}.json`);
  try {
    return JSON.parse(fs.readFileSync(local, 'utf8'));
  } catch {
    /* локальной копии нет, берём с сервера */
  }
  if (!versionUrls.has(id)) {
    try {
      slimManifest(JSON.parse(fs.readFileSync(manifestCache, 'utf8')));
    } catch {
      slimManifest(await fetchJson(MANIFEST_URL));
    }
  }
  const url = versionUrls.get(id);
  if (!url) throw new Error(`Версия ${id} не найдена.`);
  return fetchJson(url);
}

/* ---------- Java ---------- */

function javaBinName() {
  return process.platform === 'win32' ? 'java.exe' : 'java';
}

function findJava(dir, depth = 0) {
  if (depth > 5) return null;
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return null;
  }
  if (path.basename(dir) === 'bin') {
    const f = entries.find((e) => e.isFile() && e.name === javaBinName());
    if (f) return path.join(dir, f.name);
  }
  for (const e of entries) {
    if (e.isDirectory()) {
      const r = findJava(path.join(dir, e.name), depth + 1);
      if (r) return r;
    }
  }
  return null;
}

async function download(url, dest, onPct) {
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok || !res.body) throw new Error(`Сервер ответил ${res.status}`);
  const total = Number(res.headers.get('content-length')) || 0;
  let got = 0;
  let last = -1;
  const counter = new Transform({
    transform(chunk, _enc, cb) {
      got += chunk.length;
      if (total) {
        const p = Math.floor((got / total) * 100);
        if (p !== last) {
          last = p;
          onPct(p);
        }
      }
      cb(null, chunk);
    },
  });
  await pipeline(Readable.fromWeb(res.body), counter, fs.createWriteStream(dest));
}

async function ensureJavaExact(major) {
  const dir = path.join(runtimeDir, `java-${major}`);
  const existing = findJava(dir);
  if (existing) return existing;

  const osName = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = { x64: 'x64', arm64: 'aarch64', ia32: 'x32' }[process.arch];
  if (!osName || !arch) throw new Error('Для этой системы нельзя автоматически установить Java.');

  const isZip = process.platform === 'win32';
  const archive = path.join(runtimeDir, `java-${major}.${isZip ? 'zip' : 'tar.gz'}`);
  const tmp = `${dir}.tmp`;
  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${osName}/${arch}/jre/hotspot/normal/eclipse`;

  fs.mkdirSync(runtimeDir, { recursive: true });
  log(`[launcher] Скачиваю Java ${major}: ${url}`);
  status('java', `Скачиваю Java ${major}`, 0);
  await download(url, archive, (p) => status('java', `Скачиваю Java ${major}`, p));

  status('java', `Распаковываю Java ${major}`);
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  if (isZip) await extractZip(archive, { dir: tmp });
  else await tar.x({ file: archive, cwd: tmp });

  fs.rmSync(dir, { recursive: true, force: true });
  fs.renameSync(tmp, dir);
  fs.rmSync(archive, { force: true });

  const bin = findJava(dir);
  if (!bin) throw new Error('Java скачана, но не найдена после распаковки.');
  if (!isZip) fs.chmodSync(bin, 0o755);
  return bin;
}

async function ensureJava(major) {
  try {
    return await ensureJavaExact(major);
  } catch (e) {
    // Java 16 больше не обновляется и может отсутствовать; версия 17 запускает те же игры.
    if (major === 16) {
      log('[launcher] Java 16 недоступна, беру Java 17');
      return ensureJavaExact(17);
    }
    throw e;
  }
}

/* ---------- запуск игры ---------- */

const PROGRESS_LABELS = {
  assets: 'Загружаю ресурсы',
  classes: 'Загружаю библиотеки',
  'classes-custom': 'Загружаю библиотеки',
  natives: 'Распаковываю системные файлы',
  'assets-copy': 'Копирую ресурсы',
};

ipcMain.handle('game:launch', async () => {
  if (busy) return { ok: false, error: 'Игра уже запускается.' };
  busy = true;
  send('launch:state', { state: 'preparing' });

  try {
    const s = loadSettings();
    if (!NICK_RE.test(s.nickname)) throw new Error('Ник: 3–16 символов, латиница, цифры и _.');
    if (!s.version) throw new Error('Выбери версию игры.');
    fs.mkdirSync(s.gameDir, { recursive: true });

    status('prepare', 'Проверяю версию');
    const meta = await getVersionMeta(s.version, s.gameDir);
    const major = (meta.javaVersion && meta.javaVersion.majorVersion) || 8;
    const javaPath = await ensureJava(major);
    log(`[launcher] Java ${major}: ${javaPath}`);

    const launcher = new Client();
    let lastKey = '';
    launcher.on('progress', (p) => {
      if (!p || !p.total) return;
      const pct = Math.floor((p.task / p.total) * 100);
      const key = `${p.type}:${pct}`;
      if (key === lastKey) return;
      lastKey = key;
      status('game', PROGRESS_LABELS[p.type] || 'Готовлю игру', pct);
    });
    launcher.on('debug', (l) => log(`[mclc] ${l}`));
    launcher.on('data', (l) => log(l));
    launcher.on('close', (code) => {
      busy = false;
      log(`[launcher] Игра закрылась, код ${code}`);
      const error = code === 0 || code == null ? null : `Игра закрылась с ошибкой (код ${code}). Подробности в журнале.`;
      send('launch:state', { state: 'idle', error });
    });

    const authorization = await Authenticator.getAuth(s.nickname);
    status('game', 'Загружаю файлы игры', 0);

    const proc = await launcher.launch({
      authorization,
      root: s.gameDir,
      javaPath,
      version: { number: s.version, type: meta.type || 'release' },
      memory: { max: `${s.memoryGb}G`, min: '1G' },
      customArgs: ['-XX:+UseG1GC', '-XX:MaxGCPauseMillis=50'],
    });
    if (!proc) throw new Error('Игра не запустилась. Подробности в журнале.');

    status('running', 'Игра запущена');
    send('launch:state', { state: 'running' });
    return { ok: true };
  } catch (e) {
    busy = false;
    log(`[launcher] Ошибка: ${(e && e.stack) || e}`);
    const error = friendly(e);
    send('launch:state', { state: 'idle', error });
    return { ok: false, error };
  }
});

/* ---------- Bedrock Edition (Windows) ---------- */

const BEDROCK_PACKAGE = 'Microsoft.MinecraftUWP';

// true — установлен, false — не найден, null — проверить не удалось
function bedrockInstalled() {
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      [
        '-NoProfile',
        '-NonInteractive',
        '-Command',
        `if (Get-AppxPackage -Name ${BEDROCK_PACKAGE}) { 'yes' } else { 'no' }`,
      ],
      { timeout: 20000, windowsHide: true },
      (err, out) => {
        if (err) return resolve(null);
        const v = String(out).trim();
        resolve(v === 'yes' ? true : v === 'no' ? false : null);
      }
    );
  });
}

ipcMain.handle('bedrock:launch', async (_e, opts) => {
  if (process.platform !== 'win32') {
    return {
      ok: false,
      error: 'Bedrock Edition для ПК работает только в Windows 10 и 11. На этой системе запусти Java Edition.',
    };
  }
  const force = !!(opts && opts.force);
  if (!force) {
    const installed = await bedrockInstalled();
    log(`[launcher] Bedrock установлен: ${installed === null ? 'не удалось проверить' : installed}`);
    if (installed === false) {
      return {
        ok: false,
        notInstalled: true,
        error: 'Bedrock Edition не найден. Установи его из Microsoft Store и войди в аккаунт, на котором куплена игра.',
      };
    }
  }
  try {
    await shell.openExternal('minecraft://');
    log('[launcher] Отправлена команда запуска Bedrock (minecraft://)');
    return { ok: true };
  } catch (e) {
    log(`[launcher] Ошибка запуска Bedrock: ${(e && e.message) || e}`);
    return { ok: false, error: 'Не удалось открыть Bedrock Edition. Запусти игру из меню «Пуск» один раз и повтори.' };
  }
});

ipcMain.handle('bedrock:store', () => shell.openExternal('ms-windows-store://search/?query=Minecraft'));

/* ---------- остальные IPC ---------- */

ipcMain.handle('versions:list', async () => {
  try {
    const data = await fetchJson(MANIFEST_URL);
    fs.mkdirSync(userData, { recursive: true });
    fs.writeFileSync(manifestCache, JSON.stringify(data));
    return { ok: true, ...slimManifest(data) };
  } catch {
    try {
      const cached = JSON.parse(fs.readFileSync(manifestCache, 'utf8'));
      return { ok: true, offline: true, ...slimManifest(cached) };
    } catch {
      return { ok: false, error: 'Не удалось получить список версий. Проверь интернет.' };
    }
  }
});

ipcMain.handle('settings:get', () => loadSettings());

ipcMain.handle('settings:set', (_e, patch = {}) => {
  const next = loadSettings();
  if (patch.edition === 'java' || patch.edition === 'bedrock') next.edition = patch.edition;
  if (patch.device === 'pc' || patch.device === 'phone') next.device = patch.device;
  if (typeof patch.nickname === 'string') next.nickname = patch.nickname.trim().slice(0, 16);
  if (typeof patch.version === 'string') next.version = patch.version;
  if (Number.isFinite(patch.memoryGb)) next.memoryGb = Math.min(64, Math.max(1, Math.round(patch.memoryGb)));
  if (typeof patch.snapshots === 'boolean') next.snapshots = patch.snapshots;
  if (typeof patch.gameDir === 'string' && patch.gameDir) next.gameDir = patch.gameDir;
  saveSettings(next);
  return next;
});

ipcMain.handle('sys:info', () => ({
  totalGb: os.totalmem() / 1024 ** 3,
  platform: process.platform,
}));

ipcMain.handle('log:get', () => logBuffer.slice());

ipcMain.handle('dialog:pickDir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths[0] ? null : r.filePaths[0];
});

ipcMain.handle('shell:openDir', async () => {
  const dir = loadSettings().gameDir;
  fs.mkdirSync(dir, { recursive: true });
  await shell.openPath(dir);
});

ipcMain.on('win:minimize', () => win && win.minimize());
ipcMain.on('win:close', () => win && win.close());

/* ---------- окно ---------- */

function createWindow() {
  win = new BrowserWindow({
    width: 1040,
    height: 660,
    minWidth: 860,
    minHeight: 560,
    frame: false,
    show: false,
    backgroundColor: '#0e1116',
    title: 'Visual Launcher',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  win.on('closed', () => {
    win = null;
  });
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
  app.whenReady().then(createWindow);
  app.on('window-all-closed', () => app.quit());
}
