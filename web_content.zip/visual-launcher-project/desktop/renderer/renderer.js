'use strict';

const $ = (s) => document.querySelector(s);
const NICK_RE = /^[A-Za-z0-9_]{3,16}$/;

const el = {
  welcome: $('#welcome'),
  app: $('#app'),
  version: $('#version'),
  vtype: $('#vtype'),
  nick: $('#nick'),
  nickHint: $('#nick-hint'),
  play: $('#play'),
  status: $('#status-text'),
  retry: $('#retry'),
  store: $('#store'),
  force: $('#force'),
  bar: $('#bar'),
  progress: $('.progress'),
  edJava: $('#ed-java'),
  edBedrock: $('#ed-bedrock'),
  javaOnly: $('#java-only'),
  bedrockOnly: $('#bedrock-only'),
  bedrockNote: $('#bedrock-note'),
  mem: $('#mem'),
  memOut: $('#mem-out'),
  snapshots: $('#snapshots'),
  dir: $('#dir'),
  dirWarn: $('#dir-warn'),
  deviceName: $('#device-name'),
  changeDevice: $('#change-device'),
  log: $('#log'),
};

let settings = {};
let device = null; // 'pc' | 'phone'
let edition = 'java'; // выбор на компьютере; на телефоне всегда Bedrock
let versions = [];
let latest = null;
let versionsReady = false;
let versionsLoading = false;
let busy = false;
let runToken = 0;

const effectiveEdition = () => (device === 'phone' ? 'bedrock' : edition);

/* ---------- сохранение настроек ---------- */

let pending = {};
let saveTimer = null;

function flush() {
  clearTimeout(saveTimer);
  const patch = pending;
  pending = {};
  return Object.keys(patch).length ? api.setSettings(patch) : Promise.resolve();
}

function save(patch) {
  Object.assign(settings, patch);
  Object.assign(pending, patch);
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flush, 150);
}

/* ---------- статус, кнопка, прогресс ---------- */

function setStatus(text, bad = false) {
  el.status.textContent = text || '';
  el.status.classList.toggle('bad', bad);
}

function setBar(pct) {
  const v = Math.max(0, Math.min(100, pct || 0));
  el.bar.style.width = `${v}%`;
  el.progress.classList.toggle('on', v > 0);
}

function updatePlay(label) {
  const java = effectiveEdition() === 'java';
  const ready = !java || (NICK_RE.test(el.nick.value) && versionsReady && !!el.version.value);
  el.play.disabled = busy || !ready;
  if (label !== undefined) el.play.textContent = label;
}

function setBusy(value, label) {
  busy = value;
  el.version.disabled = value || !versionsReady;
  el.nick.disabled = value;
  el.edJava.disabled = value;
  el.edBedrock.disabled = value;
  el.changeDevice.disabled = value;
  updatePlay(value ? label : 'Играть');
}

function resetExtras() {
  el.retry.hidden = true;
  el.store.hidden = true;
  el.force.hidden = true;
}

/* ---------- экраны ---------- */

function showView(name) {
  document.querySelectorAll('.nav button').forEach((b) => {
    if (b.dataset.view === name) b.setAttribute('aria-current', 'page');
    else b.removeAttribute('aria-current');
  });
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('is-active', v.id === `view-${name}`));
  if (name === 'log') renderLog();
}

document.querySelectorAll('.nav button').forEach((btn) => {
  btn.addEventListener('click', () => showView(btn.dataset.view));
});

$('#btn-min').addEventListener('click', () => api.minimize());
$('#btn-close').addEventListener('click', () => api.close());

function render() {
  const bedrock = effectiveEdition() === 'bedrock';
  el.javaOnly.hidden = bedrock;
  el.bedrockOnly.hidden = !bedrock;
  el.edJava.setAttribute('aria-pressed', String(edition === 'java'));
  el.edBedrock.setAttribute('aria-pressed', String(edition === 'bedrock'));
  el.bedrockNote.textContent =
    device === 'phone'
      ? 'Откроет Minecraft, установленный на телефоне. Версия и аккаунт берутся из самой игры.'
      : 'Откроет игру, установленную из Microsoft Store. Версия, ник и аккаунт берутся из самой игры. Работает только в Windows 10 и 11.';
  el.store.textContent = device === 'phone' ? 'Открыть Google Play' : 'Открыть Microsoft Store';
  el.deviceName.textContent =
    device === 'phone' ? 'Телефон: только Bedrock Edition' : 'Компьютер: Java Edition и Bedrock Edition';
  updatePlay();
}

function applyEdition(next, persist) {
  edition = next;
  resetExtras();
  setStatus('');
  setBar(0);
  if (persist) save({ edition: next });
  render();
  if (effectiveEdition() === 'java' && !versionsReady) loadVersions();
}

el.edJava.addEventListener('click', () => !busy && applyEdition('java', true));
el.edBedrock.addEventListener('click', () => !busy && applyEdition('bedrock', true));

/* ---------- выбор устройства ---------- */

function detectDevice() {
  const mobileUA = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '');
  const touchNarrow = window.matchMedia && window.matchMedia('(pointer: coarse) and (max-width: 700px)').matches;
  return mobileUA || touchNarrow ? 'phone' : 'pc';
}

function showWelcome() {
  const guess = detectDevice();
  document.querySelectorAll('.choice').forEach((c) => {
    c.querySelector('.suggest').hidden = c.dataset.device !== guess;
  });
  el.app.hidden = true;
  el.welcome.hidden = false;
}

document.querySelectorAll('.choice').forEach((c) => {
  c.addEventListener('click', () => {
    save({ device: c.dataset.device });
    startApp(c.dataset.device);
  });
});

el.changeDevice.addEventListener('click', () => {
  if (!busy) showWelcome();
});

function startApp(d) {
  device = d;
  document.body.dataset.device = d;
  el.welcome.hidden = true;
  el.app.hidden = false;
  resetExtras();
  setStatus('');
  setBar(0);
  showView('play');
  render();
  if (effectiveEdition() === 'java' && !versionsReady) loadVersions();
}

/* ---------- версии (Java) ---------- */

function renderVersions() {
  const list = versions.filter((v) => settings.snapshots || v.type === 'release');
  el.version.replaceChildren(...list.map((v) => new Option(v.id, v.id)));
  const pick =
    (list.find((v) => v.id === settings.version) || {}).id ||
    (latest && list.some((v) => v.id === latest.release) ? latest.release : '') ||
    (list[0] && list[0].id) ||
    '';
  if (pick) {
    el.version.value = pick;
    if (pick !== settings.version) save({ version: pick });
  }
  updateTag();
  updatePlay();
}

function updateTag() {
  const v = versions.find((x) => x.id === el.version.value);
  const snap = !!v && v.type === 'snapshot';
  el.vtype.textContent = snap ? 'Снапшот' : 'Релиз';
  el.vtype.classList.toggle('snap', snap);
}

async function loadVersions() {
  if (versionsLoading) return;
  versionsLoading = true;
  const javaVisible = () => effectiveEdition() === 'java';
  el.retry.hidden = true;
  if (javaVisible()) setStatus('Загружаю список версий…');

  let res;
  try {
    res = await api.listVersions();
  } catch (e) {
    res = { ok: false, error: 'Не удалось получить список версий. Проверь интернет.' };
  }
  versionsLoading = false;

  if (!res.ok) {
    versionsReady = false;
    el.version.disabled = true;
    if (javaVisible()) {
      setStatus(res.error, true);
      el.retry.hidden = false;
    }
    updatePlay();
    return;
  }
  versions = res.versions;
  latest = res.latest;
  versionsReady = true;
  el.version.disabled = busy;
  if (javaVisible() && !busy) setStatus(res.offline ? 'Нет интернета: показан сохранённый список версий.' : '');
  renderVersions();
}

el.retry.addEventListener('click', loadVersions);

el.version.addEventListener('change', () => {
  save({ version: el.version.value });
  updateTag();
});

/* ---------- ник ---------- */

function checkNick() {
  const v = el.nick.value;
  const ok = NICK_RE.test(v);
  const showBad = !ok && v.length > 0;
  el.nick.classList.toggle('bad', showBad);
  el.nickHint.classList.toggle('bad', showBad);
  el.nickHint.textContent = showBad ? '3–16 символов: латиница, цифры и _' : '';
  if (ok) save({ nickname: v });
  updatePlay();
}
el.nick.addEventListener('input', checkNick);

/* ---------- запуск ---------- */

async function launchBedrock(force) {
  const token = ++runToken;
  resetExtras();
  setBusy(true, 'Запускаю…');
  setStatus('Открываю Minecraft…');

  let r;
  try {
    r = await api.launchBedrock({ force: !!force });
  } catch (e) {
    r = { ok: false, error: 'Не удалось запустить игру. Подробности в журнале.' };
  }

  if (r.ok) {
    setStatus('Minecraft запускается. Это окно можно свернуть.');
    setTimeout(() => {
      if (token !== runToken) return;
      setBusy(false);
      setStatus('');
    }, 6000);
    return;
  }
  setBusy(false);
  setStatus(r.error || 'Не удалось запустить игру.', true);
  el.store.hidden = !r.notInstalled;
  el.force.hidden = !(r.notInstalled && device === 'pc');
}

async function launchJava() {
  runToken++;
  resetExtras();
  await flush();
  setBusy(true, 'Подготовка…');
  setStatus('Начинаю…');
  setBar(0);
  let r;
  try {
    r = await api.launch();
  } catch (e) {
    r = { ok: false, error: 'Не удалось запустить игру. Подробности в журнале.' };
  }
  if (!r.ok) {
    setBusy(false);
    setBar(0);
    setStatus(r.error, true);
  }
}

el.play.addEventListener('click', () => {
  if (busy || el.play.disabled) return;
  if (effectiveEdition() === 'bedrock') launchBedrock(false);
  else launchJava();
});

el.force.addEventListener('click', () => !busy && launchBedrock(true));
el.store.addEventListener('click', () => api.openStore());

api.on('launch:status', ({ text, pct }) => {
  setStatus(pct == null ? text : `${text} ${pct}%`);
  if (pct != null) setBar(pct);
});

api.on('launch:state', ({ state, error }) => {
  if (state === 'preparing') {
    setBusy(true, 'Подготовка…');
  } else if (state === 'running') {
    setBusy(true, 'Игра запущена');
    setBar(100);
  } else {
    setBusy(false);
    setBar(0);
    setStatus(error || '', !!error);
  }
});

/* ---------- настройки ---------- */

el.mem.addEventListener('input', () => {
  el.memOut.textContent = `${el.mem.value} ГБ`;
  save({ memoryGb: Number(el.mem.value) });
});

el.snapshots.addEventListener('change', () => {
  save({ snapshots: el.snapshots.checked });
  renderVersions();
});

function showDir(dir) {
  el.dir.textContent = dir;
  el.dirWarn.hidden = !/[^\x20-\x7E]/.test(dir || '');
}

$('#open-dir').addEventListener('click', () => api.openGameDir());
$('#pick-dir').addEventListener('click', async () => {
  const dir = await api.pickDir();
  if (!dir) return;
  save({ gameDir: dir });
  showDir(dir);
});

/* ---------- журнал ---------- */

const logLines = [];
let logQueued = false;

function renderLog() {
  el.log.textContent = logLines.join('\n');
  el.log.scrollTop = el.log.scrollHeight;
}

api.on('log', (line) => {
  logLines.push(line);
  if (logLines.length > 1500) logLines.shift();
  if (logQueued || !$('#view-log').classList.contains('is-active')) return;
  logQueued = true;
  requestAnimationFrame(() => {
    logQueued = false;
    renderLog();
  });
});

$('#log-clear').addEventListener('click', () => {
  logLines.length = 0;
  renderLog();
});

$('#log-copy').addEventListener('click', async () => {
  const btn = $('#log-copy');
  try {
    await navigator.clipboard.writeText(logLines.join('\n'));
    btn.textContent = 'Скопировано';
    setTimeout(() => (btn.textContent = 'Скопировать'), 1500);
  } catch (e) {
    btn.textContent = 'Не удалось скопировать';
    setTimeout(() => (btn.textContent = 'Скопировать'), 2000);
  }
});

/* ---------- старт ---------- */

(async function init() {
  let sys = { totalGb: 8 };
  try {
    [settings, sys] = await Promise.all([api.getSettings(), api.sysInfo()]);
  } catch (e) {
    settings = {};
  }
  edition = settings.edition === 'bedrock' ? 'bedrock' : 'java';

  el.nick.value = settings.nickname || 'Player';
  const memMax = Math.max(2, Math.min(16, Math.floor((sys.totalGb || 8) * 0.75)));
  el.mem.max = String(memMax);
  el.mem.value = String(Math.min(settings.memoryGb || 4, memMax));
  el.memOut.textContent = `${el.mem.value} ГБ`;
  el.snapshots.checked = !!settings.snapshots;
  showDir(settings.gameDir || '');

  try {
    (await api.getLog()).forEach((l) => logLines.push(l));
  } catch (e) {
    /* журнал пока пуст */
  }

  checkNick();
  if (settings.device === 'pc' || settings.device === 'phone') startApp(settings.device);
  else showWelcome();
})();
