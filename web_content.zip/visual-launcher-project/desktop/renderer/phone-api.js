'use strict';

/*
 * Мост для телефона. В Electron объект window.api уже создан файлом preload.js,
 * и этот файл ничего не делает. В Android-приложении (WebView) есть только
 * AndroidBridge, поэтому здесь собирается такой же api: настройки хранятся
 * в localStorage, а запуск игры идёт через AndroidBridge.
 */
(function () {
  if (window.api) return;

  const bridge = window.AndroidBridge;
  const KEY = 'visual-launcher-settings';
  const base = {
    device: '', edition: 'bedrock', nickname: 'Player', version: '',
    memoryGb: 4, snapshots: false, gameDir: '',
  };

  function read() {
    try {
      return Object.assign({}, base, JSON.parse(localStorage.getItem(KEY) || '{}'));
    } catch (e) {
      return Object.assign({}, base);
    }
  }
  function write(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* хранилище недоступно */ }
  }

  window.api = {
    getSettings: async () => read(),
    setSettings: async (patch) => {
      const s = Object.assign(read(), patch);
      write(s);
      return s;
    },
    sysInfo: async () => ({ totalGb: 4, platform: bridge ? 'android' : 'web' }),
    listVersions: async () => ({ ok: false, error: 'Java Edition на телефоне недоступна.' }),
    launch: async () => ({ ok: false, error: 'Java Edition на телефоне не запускается. Выбери Bedrock.' }),
    getLog: async () => [],
    pickDir: async () => null,
    openGameDir: async () => {},
    minimize() {},
    close() {},
    on: () => () => {},
    launchBedrock: async () => {
      if (!bridge) return { ok: false, error: 'Запуск работает только в приложении для Android.' };
      let r;
      try { r = String(bridge.launchBedrock()); } catch (e) { r = 'error'; }
      if (r === 'ok') return { ok: true };
      if (r === 'missing') {
        return { ok: false, notInstalled: true, error: 'Minecraft Bedrock не найден. Установи его из Google Play.' };
      }
      return { ok: false, error: 'Не удалось открыть Minecraft. Запусти игру вручную один раз и повтори.' };
    },
    openStore: async () => {
      if (bridge) bridge.openStore();
    },
  };
})();
