@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo Не найден Node.js. Установи его с https://nodejs.org и запусти этот файл снова.
  pause
  exit /b 1
)

if not exist node_modules (
  echo Устанавливаю зависимости. Это нужно один раз, подожди пару минут...
  call npm install
  if errorlevel 1 (
    echo Не удалось установить зависимости. Проверь интернет и попробуй снова.
    pause
    exit /b 1
  )
)

call npm start
