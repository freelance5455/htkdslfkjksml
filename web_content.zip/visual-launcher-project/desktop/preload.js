'use strict';

const { contextBridge, ipcRenderer } = require('electron');

const EVENTS = new Set(['launch:status', 'launch:state', 'log']);

contextBridge.exposeInMainWorld('api', {
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  listVersions: () => ipcRenderer.invoke('versions:list'),
  sysInfo: () => ipcRenderer.invoke('sys:info'),
  launch: () => ipcRenderer.invoke('game:launch'),
  launchBedrock: (opts) => ipcRenderer.invoke('bedrock:launch', opts),
  openStore: () => ipcRenderer.invoke('bedrock:store'),
  getLog: () => ipcRenderer.invoke('log:get'),
  pickDir: () => ipcRenderer.invoke('dialog:pickDir'),
  openGameDir: () => ipcRenderer.invoke('shell:openDir'),
  minimize: () => ipcRenderer.send('win:minimize'),
  close: () => ipcRenderer.send('win:close'),
  on: (channel, cb) => {
    if (!EVENTS.has(channel)) return () => {};
    const handler = (_e, data) => cb(data);
    ipcRenderer.on(channel, handler);
    return () => ipcRenderer.removeListener(channel, handler);
  },
});
