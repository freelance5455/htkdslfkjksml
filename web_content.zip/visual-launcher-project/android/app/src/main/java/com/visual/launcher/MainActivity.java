package com.visual.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Показывает тот же интерфейс, что и версия для компьютера (папка desktop/renderer),
 * и даёт ему мост AndroidBridge для запуска Minecraft Bedrock.
 */
public class MainActivity extends Activity {
    private static final String BEDROCK = "com.mojang.minecraftpe";
    private static final int BACKGROUND = 0xFF0E1116;

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);

        web = new WebView(this);
        web.setBackgroundColor(BACKGROUND);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("AndroidBridge");
            web.destroy();
        }
        super.onDestroy();
    }

    /** Методы вызываются из JavaScript. Возвращают "ok", "missing" или "error". */
    private class Bridge {
        @JavascriptInterface
        public String launchBedrock() {
            try {
                final Intent launch = getPackageManager().getLaunchIntentForPackage(BEDROCK);
                if (launch == null) return "missing";
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(launch);
                        } catch (Exception ignored) {
                            // игра не открылась; пользователь увидит, что экран не сменился
                        }
                    }
                });
                return "ok";
            } catch (Exception e) {
                return "error";
            }
        }

        @JavascriptInterface
        public void openStore() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + BEDROCK)));
                    } catch (ActivityNotFoundException e) {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://play.google.com/store/apps/details?id=" + BEDROCK)));
                    }
                }
            });
        }
    }
}
