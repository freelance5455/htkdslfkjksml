VISUAL LAUNCHER
===============

Папки:
  desktop  версия для компьютера (Windows)
  android  версия для телефона (Android)

Оба приложения используют один и тот же интерфейс: desktop/renderer.
При первом запуске приложение спрашивает, где ты играешь: на компьютере или на телефоне.

КОМПЬЮТЕР
  1. Установи Node.js: https://nodejs.org
  2. Открой папку desktop и запусти start.bat
     (при первом запуске он сам установит всё нужное, это займёт пару минут).
  Java Edition: лаунчер сам скачает нужную Java и игру.
  Bedrock Edition: лаунчер откроет игру, установленную из Microsoft Store.

ТЕЛЕФОН (APK)
  1. Установи Android Studio: https://developer.android.com/studio
  2. File > Open и выбери папку android. Дождись конца синхронизации Gradle.
     Важно: папка desktop должна лежать рядом с папкой android, как в этом архиве.
  3. Build > Build Bundle(s) / APK(s) > Build APK(s).
     Готовый файл: android/app/build/outputs/apk/debug/app-debug.apk
  4. Перекинь APK на телефон и установи (разреши установку из неизвестных источников).
  Без Android Studio: загрузи эту папку в новый репозиторий на github.com, открой вкладку
  Actions > Build APK > Run workflow. Через пару минут APK можно скачать из раздела Artifacts.
  На телефоне доступна только Bedrock Edition: Minecraft должен быть установлен из Google Play.

ЕСЛИ ЧТО-ТО НЕ РАБОТАЕТ
  Компьютер: открой вкладку «Журнал» и скопируй её содержимое.
  Телефон: скопируй текст ошибки из Android Studio (вкладка Build).
