(function () {
  var A = window.App, $ = A.$, esc = A.esc;
  if (!A.init({ nav: 'map' })) return;
  var here = null;

  function paintMap(pos, label) {
    var box = $('#map-box');
    if (!pos) {
      box.innerHTML = '<div class="h-full flex flex-col items-center justify-center text-center px-6 gap-3"><div class="size-14 rounded-full bg-primary/15 text-primary flex items-center justify-center"><iconify-icon icon="solar:map-point-wave-bold" width="28" height="28"></iconify-icon></div><p class="text-sm font-extrabold">Konumun henüz alınmadı</p><button type="button" id="locate" class="h-11 px-5 rounded-2xl bg-primary text-primary-foreground text-sm font-extrabold">Konumumu bul</button></div>';
      $('#locate').addEventListener('click', locate);
      return;
    }
    box.innerHTML = '<iframe title="Harita" class="w-full h-full border-0" loading="lazy" src="' + A.osmEmbed(pos.lat, pos.lng) + '"></iframe>' +
      '<a href="' + A.osmLink(pos.lat, pos.lng) + '" target="_blank" rel="noopener" class="absolute bottom-2 right-2 h-8 px-3 rounded-full bg-card/95 border border-border text-[11px] font-extrabold flex items-center gap-1"><iconify-icon icon="solar:map-point-wave-bold" width="14" height="14"></iconify-icon>Büyük haritada aç</a>';
  }
  function locate() {
    var b = $('#locate'); if (b) { b.disabled = true; b.textContent = 'Aranıyor…'; }
    return A.getPosition().then(function (p) { here = p; paintMap(p); renderAll(); return p; })
      .catch(function (e) { A.toast(e.message, 'error'); paintMap(null); });
  }

  function renderShare() {
    var s = A.myShare(), box = $('#share-box');
    if (s) {
      var left = Math.max(1, Math.round((s.until - Date.now()) / 60000));
      box.innerHTML = '<div class="flex items-center gap-2 mb-3"><span class="relative flex size-3"><span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span><span class="relative inline-flex rounded-full size-3 bg-accent"></span></span><span class="text-sm font-extrabold">Canlı konum paylaşılıyor</span><span class="ml-auto text-xs font-bold text-accent-foreground">Kalan: ' + (left >= 60 ? Math.floor(left / 60) + ' sa ' + (left % 60) + ' dk' : left + ' dk') + '</span></div>' +
        '<button type="button" id="stop-share" class="w-full h-12 rounded-2xl bg-destructive/10 text-destructive border border-destructive/20 font-extrabold text-sm">Paylaşımı durdur</button>';
      $('#stop-share').addEventListener('click', function () { A.stopShare(); A.toast('Konum paylaşımı durduruldu'); renderShare(); renderAll(); });
    } else {
      box.innerHTML = '<p class="text-xs text-muted-foreground font-semibold mb-3">Konumunu gizlilik ayarına göre arkadaşlarınla paylaş. İstediğin an durdurabilirsin.</p>' +
        '<button type="button" id="start-share" class="w-full h-12 rounded-2xl bg-primary text-primary-foreground font-extrabold text-sm flex items-center justify-center gap-2"><iconify-icon icon="solar:map-point-wave-bold" width="20" height="20"></iconify-icon>Canlı konum paylaş</button>';
      $('#start-share').addEventListener('click', openShare);
    }
  }
  function openShare() {
    var s = A.sheet(A.sheetHeader('Ne kadar süre paylaşılsın?') +
      '<div class="space-y-2">' + [[15, '15 dakika'], [60, '1 saat'], [480, '8 saat']].map(function (o) {
        return '<button type="button" data-min="' + o[0] + '" class="w-full h-12 rounded-2xl bg-input border border-border px-4 text-sm font-extrabold text-left flex items-center justify-between">' + o[1] + '<iconify-icon icon="solar:alt-arrow-right-linear" width="16" height="16"></iconify-icon></button>';
      }).join('') + '</div>', { noFocus: true });
    s.el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-min]'); if (!b) return;
      b.disabled = true;
      A.getPosition().then(function (p) {
        here = p; A.startShare(+b.getAttribute('data-min'), p); s.close();
        A.toast('Canlı konum paylaşılıyor'); paintMap(p); renderShare(); renderAll();
      }).catch(function (err) { A.toast(err.message, 'error'); b.disabled = false; });
    });
  }

  function renderPrivacy() {
    var u = A.me();
    var txt = { best: 'Sadece seçili en iyi arkadaşlar', all: 'Tüm arkadaşların', ghost: 'Hayalet modu (kimse göremez)' }[u.privacy] || '';
    $('#privacy-text').textContent = txt;
  }
  function renderAll() {
    renderPrivacy();
    var me = A.me(), list = [];
    A.friends().forEach(function (f) {
      if (!f.linked) return;
      var s = A.shareOf(f.id);
      if (s && A.canSee(me.id, f.id)) list.push({ f: f, s: s });
    });
    var box = $('#friends-loc');
    $('#loc-count').textContent = list.length ? list.length + ' kişi' : '';
    if (!list.length) {
      box.innerHTML = '<p class="text-sm font-semibold text-muted-foreground text-center py-6">Şu an seninle konum paylaşan kimse yok.</p>';
      return;
    }
    box.innerHTML = list.map(function (x) {
      var d = here ? ' • ' + A.fmtDist(A.distance(here, x.s)) + ' uzakta' : '';
      return '<div class="flex items-center gap-3 p-3 rounded-2xl bg-input border border-border"><img src="' + A.avatar(x.f) + '" class="size-11 rounded-full object-cover ring-2 ring-accent" alt="" />' +
        '<div class="min-w-0 flex-1"><p class="font-heading font-extrabold text-sm truncate">' + esc(x.f.name) + '</p><p class="text-[11px] text-muted-foreground font-semibold">' + A.fmtRel(x.s.updated) + ' güncellendi' + d + '</p></div>' +
        '<a href="' + A.osmLink(x.s.lat, x.s.lng) + '" target="_blank" rel="noopener" class="h-9 px-3 rounded-xl bg-card border border-border text-xs font-extrabold flex items-center">Haritada gör</a>' +
        '<a href="chat.html?id=' + encodeURIComponent(x.f.id) + '" class="size-9 rounded-xl bg-primary text-primary-foreground flex items-center justify-center" aria-label="Mesaj"><iconify-icon icon="solar:chat-round-dots-bold" width="18" height="18"></iconify-icon></a></div>';
    }).join('');
  }

  $('#back-btn').addEventListener('click', function () { location.href = 'home.html'; });
  $('#privacy-link').addEventListener('click', function () { location.href = 'profile.html#privacy'; });
  A.onChange(function () { renderShare(); renderAll(); });
  setInterval(renderShare, 30000);
  var s0 = A.myShare();
  paintMap(s0 ? { lat: s0.lat, lng: s0.lng } : null);
  if (s0) here = { lat: s0.lat, lng: s0.lng };
  renderShare(); renderAll();
})();
