// On-device AI and document parsers. All document text and prompts remain in this WebView.
window.shwaniLoadPdfLibrary = async function () {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const workerUrl = await import('pdfjs-dist/legacy/build/pdf.worker.mjs?url');
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl.default;
  return pdfjs;
};
window.shwaniExtractDocx = async function (file) {
  const mammothModule = await import('mammoth/mammoth.browser');
  const mammoth = mammothModule.default || mammothModule;
  const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
  return result.value || '';
};
window.shwaniCreateLocalModel = async function (modelId, onProgress) {
  const webllm = await import('@mlc-ai/web-llm');
  return webllm.CreateMLCEngine(modelId, {
    appConfig: { ...webllm.prebuiltAppConfig, cacheBackend: 'indexeddb' },
    initProgressCallback: onProgress,
  });
};
