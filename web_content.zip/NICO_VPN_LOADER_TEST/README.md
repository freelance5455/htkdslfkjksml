# NICO VPN LOADER — Educational Test Project

This is an Android Studio source project. The complete UI is in one file:
`app/src/main/assets/index.html` (HTML, CSS and JavaScript together).

## What works
- WebView loads the single-file HTML interface.
- Open Free Fire download page button opens the user-provided MediaFire URL.
- Floating menu uses Android's overlay permission and displays a separate demo panel.
- Demo controls update the UI only.

## Important limitations
- Connect is a visual demo toggle; this project does not create a VPN tunnel.
- It does not launch or inject into the Free Fire process.
- `nicomod.so` is not loaded or executed. The static inspection report is provided separately.
- The MediaFire link opens a download page; it does not directly launch an installed game.

## Build APK
1. Extract the ZIP.
2. Open the `NICO_VPN_LOADER_TEST` folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build APK(s)**.
5. The debug APK is normally created under `app/build/outputs/apk/debug/`.

A local Android SDK and compatible Gradle/Android Gradle Plugin installation are required. This source has not been compiled or device-tested here.
