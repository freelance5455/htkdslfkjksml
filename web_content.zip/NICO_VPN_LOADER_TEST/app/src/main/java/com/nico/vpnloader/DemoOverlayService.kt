package com.nico.vpnloader

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class DemoOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var panel: LinearLayout? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.rgb(25, 28, 38))
        }
        fun item(label: String, color: Int = Color.WHITE, action: (() -> Unit)? = null) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(color); setPadding(8, 9, 8, 9)
            if (action != null) setOnClickListener { action() }
        }
        box.addView(item("NICO EDUCATIONAL MENU", Color.rgb(255, 90, 80)))
        box.addView(item("Overlay demo: ACTIVE", Color.rgb(100, 230, 150)))
        box.addView(item("PING: sample display only", Color.LTGRAY))
        box.addView(item("AIM / ESP: NOT AVAILABLE", Color.LTGRAY))
        box.addView(item("CLOSE MENU", Color.WHITE) { stopSelf() })
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 140 }
        panel = box
        windowManager?.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let { try { windowManager?.removeView(it) } catch (_: Exception) { } }
        panel = null
        super.onDestroy()
    }
}
