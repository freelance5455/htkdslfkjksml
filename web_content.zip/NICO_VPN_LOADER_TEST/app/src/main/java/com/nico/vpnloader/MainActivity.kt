package com.nico.vpnloader

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val ffPage = "https://www.mediafire.com/file/h7z10asgbdibld0/Free+Fire+1.132.1+India.apks/file"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(9, 11, 18)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "Native")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    inner class AndroidBridge {
        @JavascriptInterface fun openFfPage() {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ffPage))) }
        }
        @JavascriptInterface fun enableOverlay() {
            runOnUiThread {
                if (Settings.canDrawOverlays(this@MainActivity)) startOverlay()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        @JavascriptInterface fun stopOverlay() {
            runOnUiThread { stopService(Intent(this@MainActivity, DemoOverlayService::class.java)) }
        }
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow Display over other apps, then tap Enable Floating Menu", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, DemoOverlayService::class.java))
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
