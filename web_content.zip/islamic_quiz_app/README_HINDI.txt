ISLAMIC QUIZ - PROJECT PREVIEW
================================

Is ZIP mein:
- www/index.html : chalne wala mobile-friendly quiz prototype
- package.json aur capacitor.config.json : Android wrapper banane ke liye starter files

Zaroori sach:
1. Yeh abhi Play Store par upload karne layak AAB/APK nahin hai.
2. Guest mode aur coins is device ke browser mein save hote hain.
3. Login/Register screen demo hai; real online accounts/database nahin.
4. Coin Shop ke buttons demo hain; paise charge nahin karte.
5. Real money purchases ke liye Google Play Billing, backend purchase verification,
   privacy policy, testing aur Android signing setup karna hoga.
6. Quiz question bank filhal sample hai; public release se pehle knowledgeable reviewer
   se Islamic content verify karwayen.
7. Android build ke liye Node.js, Android Studio/SDK, Capacitor setup aur signing
   ki zaroorat hogi. package.json se dependencies install karke Android platform add
   aur signed AAB build karna hoga.

Quick preview:
- www/index.html ko browser mein open karein.
- Best experience: phone browser ya desktop mobile preview.
