SANJEEVLIFT V2

A mobile-first gym record tracker / PWA prototype.

Added in V2:
- Automatic Epley estimated 1RM
- Exercise-specific strength graph
- PR detection + animated PR modal + optional browser notification
- Rest timer with vibration where supported
- Repeat previous workout / repeat last workout
- Exercise search
- Workout calendar with workout days
- Weekly/monthly reps charts
- Total volume, sets and reps metrics
- JSON backup and restore
- Local device storage
- Profile
- Polished red/charcoal animations and responsive mobile UI

How to use:
1. Open index.html in a modern browser.
2. For PWA install/offline behavior, serve this folder from HTTPS or localhost.
3. Use Settings > Export Backup regularly.

Note: browser localStorage is device/browser specific. Cloud sync is not included yet; it can be added later with an account/database backend.
