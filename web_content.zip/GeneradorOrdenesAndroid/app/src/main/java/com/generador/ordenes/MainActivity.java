package com.generador.ordenes;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No se pudo abrir el selector de archivos", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidApp");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void abrirWhatsApp(String texto) {
            runOnUiThread(() -> {
                String url = "https://wa.me/?text=" + Uri.encode(texto == null ? "" : texto);
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.setPackage("com.whatsapp");
                    startActivity(i);
                } catch (Exception e) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(i);
                    } catch (Exception ex) {
                        Toast.makeText(MainActivity.this, "No se pudo abrir WhatsApp", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void compartirTexto(String texto) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, texto == null ? "" : texto);
                startActivity(Intent.createChooser(i, "Enviar orden"));
            });
        }

        @JavascriptInterface
        public void compartirImagen(String dataUrl, String fileName, String texto) {
            executor.execute(() -> {
                try {
                    File file = guardarImagen(dataUrl, fileName);
                    Uri uri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", file);

                    runOnUiThread(() -> {
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType("image/jpeg");
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        share.putExtra(Intent.EXTRA_TEXT, texto == null ? "" : texto);
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                        // Primero intenta abrir WhatsApp directamente.
                        try {
                            share.setPackage("com.whatsapp");
                            startActivity(share);
                        } catch (Exception e) {
                            // Si no está instalado, muestra las apps disponibles.
                            share.setPackage(null);
                            startActivity(Intent.createChooser(share, "Enviar imagen de la orden"));
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "No se pudo preparar la imagen: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }

        @JavascriptInterface
        public void imprimirImagen(String dataUrl) {
            executor.execute(() -> {
                try {
                    String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
                    byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) throw new IOException("Imagen inválida");
                    runOnUiThread(() -> imprimirBitmap(bitmap));
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                            "No se pudo preparar la impresión: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            });
        }
    }

    private File guardarImagen(String dataUrl, String fileName) throws IOException {
        String base64 = dataUrl.substring(dataUrl.indexOf(',') + 1);
        byte[] bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT);
        File dir = new File(getCacheDir(), "ordenes");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("No se pudo crear la carpeta temporal");
        String safeName = (fileName == null || fileName.trim().isEmpty()) ? "orden.jpg" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
        File file = new File(dir, safeName);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(bytes);
        }
        return file;
    }

    private void imprimirBitmap(Bitmap bitmap) {
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        PrintAttributes attrs = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
                .setResolution(new PrintAttributes.Resolution("orden", "Orden", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();
        pm.print("Orden de trabajo", new ImagePrintAdapter(bitmap), attrs);
    }

    private static class ImagePrintAdapter extends PrintDocumentAdapter {
        private final Bitmap bitmap;
        private PrintAttributes attributes;

        ImagePrintAdapter(Bitmap bitmap) { this.bitmap = bitmap; }

        @Override
        public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes,
                             CancellationSignal cancellationSignal, LayoutResultCallback callback, android.os.Bundle extras) {
            attributes = newAttributes;
            if (cancellationSignal.isCanceled()) {
                callback.onLayoutCancelled();
                return;
            }
            PrintDocumentInfo info = new PrintDocumentInfo.Builder("orden.jpg")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build();
            callback.onLayoutFinished(info, true);
        }

        @Override
        public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                            CancellationSignal cancellationSignal, WriteResultCallback callback) {
            PdfDocument pdf = new PdfDocument();
            try {
                int pageWidth = attributes.getMediaSize().getWidthMils() * 72 / 1000;
                int pageHeight = attributes.getMediaSize().getHeightMils() * 72 / 1000;
                if (pageWidth <= 0) pageWidth = 612;
                if (pageHeight <= 0) pageHeight = 792;

                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
                PdfDocument.Page page = pdf.startPage(pageInfo);
                Canvas canvas = page.getCanvas();
                canvas.drawColor(Color.WHITE);

                float maxW = pageWidth * 0.80f;
                float maxH = pageHeight * 0.98f;
                float scale = Math.min(maxW / bitmap.getWidth(), maxH / bitmap.getHeight());
                float w = bitmap.getWidth() * scale;
                float h = bitmap.getHeight() * scale;
                float left = (pageWidth - w) / 2f;
                float top = 8f;

                Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                canvas.drawBitmap(bitmap, null, new android.graphics.RectF(left, top, left + w, top + h), paint);
                pdf.finishPage(page);
                pdf.writeTo(new FileOutputStream(destination.getFileDescriptor()));
                callback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            } catch (Exception e) {
                callback.onWriteFailed(e.getMessage());
            } finally {
                pdf.close();
                try { destination.close(); } catch (Exception ignored) {}
                bitmap.recycle();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
