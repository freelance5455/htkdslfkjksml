# Generador de Órdenes — Android

Proyecto Android Studio que empaqueta la versión HTML de la app dentro de un WebView.

## Abrir
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Espera a que Gradle sincronice.
4. Conecta un Android o usa un emulador.
5. Ejecuta `app`.

## APK
En Android Studio: Build > Build APK(s).

La app web está en `app/src/main/assets/index.html`.
