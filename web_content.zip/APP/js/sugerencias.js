
document.addEventListener("DOMContentLoaded", () => {
  const questionSection = document.getElementById("question-section");
  const yesSection = document.getElementById("yes-section");
  const noSection = document.getElementById("no-section");

  const yesButton = document.getElementById("yes-button");
  const noButton = document.getElementById("no-button");
  const restartButton = document.getElementById("restart-button");

  function showResult(section) {
    // Ocultar la pregunta y todas las respuestas.
    questionSection.hidden = true;
    yesSection.hidden = true;
    noSection.hidden = true;

    // Mostrar la respuesta seleccionada.
    section.hidden = false;

    // Mostrar el botón para volver a responder.
    restartButton.hidden = false;

    // Llevar al usuario al comienzo del contenido.
    section.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }

  yesButton.addEventListener("click", () => {
    showResult(yesSection);
  });

  noButton.addEventListener("click", () => {
    showResult(noSection);
  });

  restartButton.addEventListener("click", () => {
    // Regresar a la pregunta inicial.
    yesSection.hidden = true;
    noSection.hidden = true;
    restartButton.hidden = true;
    questionSection.hidden = false;

    questionSection.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });

  console.log("Página de Sugerencias cargada correctamente.");
});
