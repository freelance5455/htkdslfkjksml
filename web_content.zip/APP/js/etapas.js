
document.addEventListener("DOMContentLoaded", () => {
  const nutritionMenu = document.getElementById("nutrition-menu");

  const sectionIds = [
    "prenatal-section",
    "newborn-section",
    "infant-section",
    "early-childhood-section",
    "preschool-section",
    "school-section"
  ];

  const sections = {
    "nutrition-menu": nutritionMenu
  };

  sectionIds.forEach((id) => {
    sections[id] = document.getElementById(id);
  });

  // Mostrar el menú o la etapa seleccionada.
  function showSection(targetId) {
    const target = sections[targetId];

    if (!target) return;

    Object.values(sections).forEach((section) => {
      if (section) {
        section.hidden = true;
      }
    });

    target.hidden = false;
  }

  // Abrir una etapa desde el menú.
  document.querySelectorAll("[data-show]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.show);
    });
  });

  // Volver al menú de las seis etapas.
  document.querySelectorAll("[data-back]").forEach((button) => {
    button.addEventListener("click", () => {
      showSection(button.dataset.back);
    });
  });

  // Comprobar que todas las secciones existan.
  const missingSections = Object.entries(sections)
    .filter(([, section]) => !section)
    .map(([id]) => id);

  if (missingSections.length > 0) {
    console.error(
      "No se encontraron las siguientes secciones:",
      missingSections
    );
  }

  console.log("Sección de etapas lista.");
});
