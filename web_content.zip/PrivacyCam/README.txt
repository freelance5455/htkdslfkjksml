1. Установи Android Studio (бесплатно): developer.android.com/studio
2. File > Open > выбери папку PrivacyCam, дождись Gradle Sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk. Скопируй на телефон и установи.
