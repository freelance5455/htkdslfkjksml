#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
PORT="${PORT:-7700}"
printf '\nAsimAI is being served at: http://localhost:%s\n' "$PORT"
printf 'Keep this window open. Press Ctrl+C to stop the local server.\n\n'
exec python3 -m http.server "$PORT" --bind 0.0.0.0
