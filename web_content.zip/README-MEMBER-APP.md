# MESH Member App — Separate Package

This ZIP contains the member-facing HTML/CSS/JavaScript frontend extracted from the combined MESH project. `index.html` is at the ZIP root for easier APK-wrapper setup.

## Important
- This is a web app package, not a compiled APK. Use your chosen HTML-to-APK/WebView builder to create the Android APK.
- The app continues to use the existing Firebase project configured in `js/firebase.js`. Do not create a new Firebase project unless you intend to migrate the backend.
- Keep the original combined MESH ZIP as the source for shared Firebase backend deployment (Firestore rules, Storage rules, and Cloud Functions). Do not deploy a separate set of rules from this frontend-only ZIP.
- Authentication, content, and notifications still require network access and the existing Firebase project.
- For an APK, configure the wrapper to load the included `index.html` and allow network access. Test login, navigation, uploads, and notifications on a test device before releasing.
