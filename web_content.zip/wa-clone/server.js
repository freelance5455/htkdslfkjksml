const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto'),os=require('os');
const PORT=process.env.PORT||3000,DB=path.join(__dirname,'data.json'),UP=path.join(__dirname,'uploads'),PUB=path.join(__dirname,'public');
fs.mkdirSync(UP,{recursive:true});
let db={users:{},groups:{},channels:{},stories:[],msgs:[]};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DB,'utf8')))}catch{}
let tm;const save=()=>{clearTimeout(tm);tm=setTimeout(()=>fs.writeFile(DB,JSON.stringify(db),()=>{}),300)};
const rid=()=>crypto.randomBytes(6).toString('hex'),hash=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
const txt=(v,n)=>String(v||'').trim().slice(0,n),pub=u=>({id:u.id,name:u.name,bio:u.bio,avatar:u.avatar});
const serial=()=>{let s;do s=String(Math.floor(1e9+Math.random()*9e9));while(db.users[s]);return s};
const img=d=>{const m=/^data:image\/(png|jpe?g|webp|gif);base64,(.+)$/.exec(d||'');if(!m)return null;const f=rid()+'.'+m[1].replace('jpeg','jpg');fs.writeFileSync(path.join(UP,f),Buffer.from(m[2],'base64'));return'/u/'+f};
const sse=new Set(),ping=()=>sse.forEach(r=>r.write('data: 1\n\n'));
setInterval(()=>sse.forEach(r=>r.write(':\n\n')),25000);
const R={
'POST /api/register':(u,b)=>{const name=txt(b.name,30),pw=String(b.pw||'');if(!name||pw.length<4)throw'Nama wajib diisi dan sandi minimal 4 karakter';const id=serial(),salt=rid(),token=rid()+rid();db.users[id]={id,name,bio:'Halo, saya pakai WA Clone',avatar:null,salt,hash:hash(pw,salt),token};return{token,id}},
'POST /api/login':(u,b)=>{const x=db.users[txt(b.id,20)];if(!x||x.hash!==hash(String(b.pw||''),x.salt))throw'Nomor seri atau sandi salah';return{token:x.token,id:x.id}},
'GET /api/sync':u=>{const gs=Object.values(db.groups).filter(g=>g.members.includes(u.id)),gi=gs.map(g=>g.id);return{me:u.id,users:Object.values(db.users).map(pub),groups:gs,channels:Object.values(db.channels),stories:db.stories.filter(s=>Date.now()-s.ts<864e5),msgs:db.msgs.filter(m=>m.from===u.id||m.to===u.id||gi.includes(m.to)||db.channels[m.to]).slice(-2000)}},
'PUT /api/me':(u,b)=>{if(b.name)u.name=txt(b.name,30)||u.name;if(b.bio!=null)u.bio=txt(b.bio,140);if(b.avatar)u.avatar=img(b.avatar)||u.avatar},
'POST /api/msg':(u,b)=>{const to=String(b.to),g=db.groups[to],c=db.channels[to];if(!(db.users[to]&&to!==u.id||g&&g.members.includes(u.id)||c&&c.owner===u.id))throw'Tidak bisa mengirim ke tujuan ini';const text=txt(b.text,2000),im=img(b.img);if(!text&&!im)throw'Pesan kosong';db.msgs.push({id:rid(),from:u.id,to,text,img:im,q:b.q?txt(b.q,120):null,ts:Date.now()})},
'POST /api/story':(u,b)=>{const im=img(b.img);if(!im)throw'Foto story wajib dipilih';db.stories.push({id:rid(),from:u.id,img:im,text:txt(b.text,200),ts:Date.now()})},
'POST /api/group':(u,b)=>{const id='g'+rid();db.groups[id]={id,name:txt(b.name,30)||'Grup baru',members:[u.id,...[].concat(b.members||[]).filter(m=>db.users[m]&&m!==u.id)]}},
'POST /api/channel':(u,b)=>{const id='c'+rid(),name=txt(b.name,30);if(!name)throw'Nama saluran wajib diisi';db.channels[id]={id,name,desc:txt(b.desc,100),owner:u.id}}
};
const mime={'.html':'text/html;charset=utf-8','.css':'text/css;charset=utf-8','.js':'text/javascript;charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.gif':'image/gif'};
http.createServer((q,s)=>{
const url=q.url.split('?')[0],J=(c,o)=>{s.writeHead(c,{'Content-Type':'application/json'});s.end(JSON.stringify(o))};
if(url==='/events'){s.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});s.write(':ok\n\n');sse.add(s);return q.on('close',()=>sse.delete(s))}
if(url.startsWith('/api/')){const fn=R[q.method+' '+url];if(!fn)return J(404,{err:'Tidak ditemukan'});let body='';q.on('data',c=>{body+=c;if(body.length>9e6)q.destroy()});
q.on('end',()=>{try{const u=Object.values(db.users).find(x=>x.token&&x.token===(q.headers.authorization||'').slice(7));if(!u&&!/register|login/.test(url))throw'Sesi habis, silakan masuk lagi';const out=fn(u,body?JSON.parse(body):{})||{ok:1};if(q.method!=='GET'){save();ping()}J(200,out)}catch(e){J(400,{err:typeof e==='string'?e:'Permintaan tidak valid'})}});return}
const f=path.join(url.startsWith('/u/')?UP:PUB,path.basename(url)||'index.html');
fs.readFile(f,(e,d)=>{if(e){s.writeHead(404);return s.end('404')}s.writeHead(200,{'Content-Type':mime[path.extname(f)]||'application/octet-stream'});s.end(d)})
}).listen(PORT,'0.0.0.0',()=>{let ips=[];try{ips=Object.values(os.networkInterfaces()).flat().filter(i=>i.family==='IPv4'&&!i.internal).map(i=>'http://'+i.address+':'+PORT)}catch{}
console.log('WA Clone jalan!\nBuka di HP ini : http://localhost:'+PORT+(ips.length?'\nDari WiFi sama : '+ips.join('  '):''))});
