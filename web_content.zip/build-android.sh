#!/usr/bin/env bash
# ==============================================================================
# Task Pro Earning 2 - Production Android Build Script (build-android.sh)
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=============================================================================="
echo "🚀 Starting Task Pro Earning 2 Android Release Build Pipeline"
echo "=============================================================================="

# 1. Clean the project
echo "🧹 [1/5] Cleaning previous build outputs..."
rm -rf dist
rm -rf android/app/build
rm -rf android/app/src/main/assets/public

# 2. Build the production web application
echo "📦 [2/5] Building production React bundle (npm run build)..."
npm run build

# 3. Synchronize Capacitor Android project
echo "🔄 [3/5] Synchronizing Capacitor Android project (npx cap sync android)..."
npx cap sync android

# 4. Verify assets mapping in Capacitor structure
echo "🔍 [4/5] Verifying Capacitor assets mapping..."
ASSETS_DIR="android/app/src/main/assets/public"
if [ ! -f "$ASSETS_DIR/index.html" ]; then
    echo "❌ Error: $ASSETS_DIR/index.html was not found! Mapping failed."
    exit 1
fi
echo "✅ Assets correctly mapped: $ASSETS_DIR/index.html is ready."

# 5. Build and sign release APK using Gradle
echo "⚙️ [5/5] Generating signed release APK with Gradle wrapper..."
(
    cd android
    chmod +x gradlew
    ./gradlew assembleRelease
)

# Verification & Summary
RELEASE_APK="android/app/build/outputs/apk/release/app-release.apk"
DOWNLOAD_APK="public/downloads/Task-Earn-Pro-2.apk"

if [ -f "$RELEASE_APK" ] && [ -f "$DOWNLOAD_APK" ]; then
    APK_SIZE=$(ls -lh "$DOWNLOAD_APK" | awk '{print $5}')
    SHA256=$(sha256sum "$DOWNLOAD_APK" | awk '{print $1}')

    echo "=============================================================================="
    echo "🎉 SUCCESS: Signed Release APK successfully created!"
    echo "   - Gradle Output: $RELEASE_APK"
    echo "   - Web Public URL: $DOWNLOAD_APK"
    echo "   - APK Size: $APK_SIZE"
    echo "   - SHA-256: $SHA256"
    echo "   - Package ID: com.subhodip.taskearnpro"
    echo "   - Min SDK: 21 (Android 5.0+)"
    echo "   - Target SDK: 34 (Android 14/15/16 ready)"
    echo "=============================================================================="
else
    echo "❌ Error: Release APK was not found at expected location!"
    exit 1
fi
