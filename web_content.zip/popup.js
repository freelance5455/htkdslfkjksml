
"use strict";

// ============================================
// RAP ALARM 4.0 - ANDROID / WEB APP VERSION
// ============================================

const WORKER_URL = "https://rap-alarm.kevinnewmen.workers.dev";

const DEFAULT_USER_ID = "2300021427";
const DEFAULT_GOAL = 4000;
const DEFAULT_VOLUME = 100;

const REQUEST_TIMEOUT_MS = 15000;
const REFRESH_INTERVAL_MS = 5000;
const STORAGE_KEY = "rapAlarmSettings";

const $ = id => document.getElementById(id);

let refreshTimer = null;
let dismissedGoalDisplay = false;
let monitoring = false;
let dismissingAlarm = false;
let refreshing = false;

// ============================================
// FORMATTING
// ============================================

function formatNumber(value) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return "—";
    }

    return Math.round(number).toLocaleString();
}

function formatDate(value) {
    if (!value) {
        return "Never";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return date.toLocaleString();
}

// ============================================
// STATUS AND ERRORS
// ============================================

function showError(message) {
    const box = $("errorBox");

    if (!box) return;

    box.textContent = message;
    box.classList.add("show");
}

function clearError() {
    const box = $("errorBox");

    if (!box) return;

    box.textContent = "";
    box.classList.remove("show");
}

function setStatus(message, type = "normal") {
    $("statusText").textContent = message;

    const dot = $("statusDot");

    dot.classList.remove("online", "warning");

    if (type === "online") {
        dot.classList.add("online");
    }

    if (type === "warning") {
        dot.classList.add("warning");
    }
}

function setMonitoringState(value) {
    monitoring = value === true;

    $("startButton").disabled = monitoring;
    $("stopButton").disabled = !monitoring;

    if (monitoring) {
        setStatus("Monitoring", "online");
    } else {
        setStatus("Not monitoring");
    }
}

// ============================================
// VALIDATION
// ============================================

function getSettings() {
    const userId = $("userId").value.trim();
    const rapGoal = Number($("rapGoal").value);

    if (!/^\d{1,20}$/.test(userId)) {
        throw new Error("Enter a valid numeric Roblox User ID.");
    }

    if (!Number.isSafeInteger(rapGoal) || rapGoal < 1) {
        throw new Error("Enter a valid RAP goal.");
    }

    return {
        userId,
        rapGoal
    };
}

// ============================================
// LOCAL SETTINGS STORAGE
// ============================================

function saveSettings() {
    const settings = {
        userId: $("userId").value.trim(),
        rapGoal: Number($("rapGoal").value),
        volume: Number($("volume").value)
    };

    try {
        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(settings)
        );
    } catch (error) {
        showError(`Could not save settings: ${error.message}`);
    }
}

function loadSettings() {
    let settings = {};

    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (saved) {
            settings = JSON.parse(saved);

            if (!settings || typeof settings !== "object") {
                settings = {};
            }
        }
    } catch (error) {
        console.error("Could not load saved settings:", error);
        settings = {};
    }

    const savedUserId = String(settings.userId || "");

    $("userId").value =
        /^\d{1,20}$/.test(savedUserId)
            ? savedUserId
            : DEFAULT_USER_ID;

    const savedGoal = Number(settings.rapGoal);

    $("rapGoal").value =
        Number.isSafeInteger(savedGoal) && savedGoal > 0
            ? savedGoal
            : DEFAULT_GOAL;

    const savedVolume = Number(settings.volume);

    const volume =
        Number.isFinite(savedVolume)
            ? Math.max(0, Math.min(200, savedVolume))
            : DEFAULT_VOLUME;

    $("volume").value = String(volume);
    $("volumeText").textContent = `${volume}%`;
}

// ============================================
// CLOUDFLARE API
// ============================================

async function apiRequest(path, options = {}) {
    const controller = new AbortController();

    const timeout = setTimeout(() => {
        controller.abort();
    }, REQUEST_TIMEOUT_MS);

    try {
        const requestOptions = {
            method: options.method || "GET",
            headers: {
                "Accept": "application/json"
            },
            cache: "no-store",
            signal: controller.signal
        };

        if (options.body !== undefined) {
            requestOptions.headers["Content-Type"] = "application/json";
            requestOptions.body = JSON.stringify(options.body);
        }

        const response = await fetch(
            `${WORKER_URL}${path}`,
            requestOptions
        );

        const responseText = await response.text();

        let data;

        try {
            data = responseText ? JSON.parse(responseText) : {};
        } catch {
            throw new Error(
                `Cloudflare returned invalid JSON. HTTP ${response.status}.`
            );
        }

        if (!response.ok) {
            throw new Error(
                data.error ||
                data.message ||
                `Cloudflare request failed. HTTP ${response.status}.`
            );
        }

        if (data.ok === false) {
            throw new Error(
                data.error ||
                data.message ||
                "Cloudflare reported an error."
            );
        }

        return data;

    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error("Cloudflare request timed out.");
        }

        if (error instanceof TypeError) {
            throw new Error(
                "Could not connect to Cloudflare. Check your internet connection and Worker CORS settings."
            );
        }

        throw error;

    } finally {
        clearTimeout(timeout);
    }
}

function extractState(response) {
    if (response.state && typeof response.state === "object") {
        return response.state;
    }

    if (response.data && typeof response.data === "object") {
        return response.data;
    }

    return response;
}

// ============================================
// RAP DISPLAY
// ============================================

function updateStatistics(data) {
    const rap = Number(data.rap);
    const goal = Number(data.goal);

    const validRap =
        data.rap !== null &&
        data.rap !== undefined &&
        Number.isFinite(rap);

    const validGoal =
        data.goal !== null &&
        data.goal !== undefined &&
        Number.isFinite(goal) &&
        goal > 0;

    $("currentRap").textContent =
        validRap ? formatNumber(rap) : "—";

    $("goalValue").textContent =
        validGoal ? formatNumber(goal) : formatNumber(DEFAULT_GOAL);

    let remaining = null;

    if (validRap && validGoal) {
        remaining = Math.max(0, goal - rap);
    } else if (
        data.remaining !== null &&
        data.remaining !== undefined &&
        Number.isFinite(Number(data.remaining))
    ) {
        remaining = Number(data.remaining);
    }

    $("remainingRap").textContent =
        remaining === null ? "—" : formatNumber(remaining);

    const count = Number(data.limitedCount);

    $("limitedCount").textContent =
        data.limitedCount !== null &&
        data.limitedCount !== undefined &&
        Number.isFinite(count)
            ? formatNumber(count)
            : "—";

    let progress = 0;

    if (validRap && validGoal) {
        progress = Math.min(
            100,
            Math.max(0, (rap / goal) * 100)
        );
    }

    $("progressFill").style.width = `${progress}%`;
    $("progressText").textContent = `${Math.round(progress)}%`;

    $("lastChecked").textContent =
        `Last checked: ${formatDate(data.lastChecked)}`;

    const reached =
        data.goalReached === true ||
        (validRap && validGoal && rap >= goal);

    if (reached) {
        if (data.alarmDismissed === true) {
            dismissedGoalDisplay = true;
        } else if (data.alarmDismissed === false) {
            dismissedGoalDisplay = false;
        }

        $("alarmBox").classList.toggle(
            "show",
            !dismissedGoalDisplay
        );
    } else {
        dismissedGoalDisplay = false;
        $("alarmBox").classList.remove("show");
    }
}

function resetStatistics() {
    $("currentRap").textContent = "—";
    $("goalValue").textContent = formatNumber(DEFAULT_GOAL);
    $("remainingRap").textContent = "—";
    $("limitedCount").textContent = "—";

    $("progressFill").style.width = "0%";
    $("progressText").textContent = "0%";

    $("lastChecked").textContent = "Last checked: Never";

    $("alarmBox").classList.remove("show");

    dismissedGoalDisplay = false;
}

// ============================================
// CHECK CLOUDFLARE STATUS
// ============================================

async function refreshStatus(showErrors = false) {
    if (refreshing) {
        return;
    }

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        if (showErrors) {
            showError(error.message);
        }

        return;
    }

    refreshing = true;

    try {
        const response = await apiRequest(
            `/api/status?userId=${encodeURIComponent(settings.userId)}`
        );

        const data = extractState(response);

        clearError();

        setMonitoringState(data.monitoring === true);

        if (
            data.monitoring === true &&
            Number(data.goal) > 0
        ) {
            $("rapGoal").value = String(data.goal);
        }

        updateStatistics(data);
        saveSettings();

    } catch (error) {
        setStatus("Cloudflare connection failed", "warning");

        if (showErrors) {
            showError(error.message);
        }

    } finally {
        refreshing = false;
    }
}

// ============================================
// START MONITORING
// ORIGINAL WORKING LOGIC PRESERVED
// ============================================

async function startMonitoring() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    $("startButton").disabled = true;
    setStatus("Starting monitoring...", "warning");

    try {
        saveSettings();

        const response = await apiRequest(
            "/api/start",
            {
                method: "POST",
                body: {
                    userId: settings.userId,
                    rapGoal: settings.rapGoal
                }
            }
        );

        const data = extractState(response);

        dismissedGoalDisplay = false;

        setMonitoringState(data.monitoring !== false);

        if (data.rap !== undefined) {
            updateStatistics({
                ...data,
                goal: data.goal || settings.rapGoal
            });
        }

        await refreshStatus(true);

    } catch (error) {
        setMonitoringState(false);
        showError(error.message);

    } finally {
        $("startButton").disabled = monitoring;
    }
}

// ============================================
// DISMISS ALARM DISPLAY
// Monitoring stays ON.
// Sends RAP Alarm Stop to the phone.
// ============================================

async function dismissAlarm() {
    if (dismissingAlarm) {
        return;
    }

    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    dismissingAlarm = true;

    $("dismissAlarm").disabled = true;
    $("dismissAlarm").textContent = "Stopping phone alarm...";

    try {
        await apiRequest(
            "/api/dismiss",
            {
                method: "POST",
                body: {
                    userId: settings.userId
                }
            }
        );

        dismissedGoalDisplay = true;
        $("alarmBox").classList.remove("show");

        clearError();

        setStatus(
            monitoring
                ? "Monitoring — alarm dismissed"
                : "Not monitoring",
            monitoring ? "online" : "normal"
        );

        await refreshStatus(false);

    } catch (error) {
        showError(
            `Could not dismiss the phone alarm: ${error.message}`
        );

    } finally {
        dismissingAlarm = false;

        $("dismissAlarm").disabled = false;
        $("dismissAlarm").textContent = "Dismiss Alarm Display";
    }
}

// ============================================
// STOP MONITORING
// ORIGINAL WORKING LOGIC PRESERVED
// ============================================

async function stopMonitoring() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    $("stopButton").disabled = true;
    setStatus("Stopping monitoring...", "warning");

    try {
        await apiRequest(
            "/api/stop",
            {
                method: "POST",
                body: {
                    userId: settings.userId
                }
            }
        );

        setMonitoringState(false);
        resetStatistics();
        clearError();

    } catch (error) {
        showError(error.message);
        await refreshStatus(false);

    } finally {
        $("stopButton").disabled = !monitoring;
    }
}

// ============================================
// MANUAL RAP CHECK
// ============================================

async function manualCheck() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    setStatus("Checking RAP...", "warning");

    try {
        await apiRequest(
            "/api/check",
            {
                method: "POST",
                body: {
                    userId: settings.userId
                }
            }
        );

        await refreshStatus(true);

    } catch (error) {
        showError(error.message);
        await refreshStatus(false);
    }
}

// ============================================
// TABS
// ============================================

function setupTabs() {
    document.querySelectorAll(".tab").forEach(button => {
        button.addEventListener("click", () => {
            document.querySelectorAll(".tab").forEach(tab => {
                tab.classList.remove("active");
            });

            button.classList.add("active");

            const tab = button.dataset.tab;

            $("rapPanel").classList.toggle(
                "hidden",
                tab !== "rap"
            );

            $("tradingPanel").classList.toggle(
                "hidden",
                tab !== "trading"
            );

            $("adsPanel").classList.toggle(
                "hidden",
                tab !== "ads"
            );
        });
    });
}

// ============================================
// SETTINGS SCREEN
// ============================================

function setupSettings() {
    const settingsButton = $("settingsButton");
    const settingsOverlay = $("settingsOverlay");
    const closeSettings = $("closeSettings");
    const doneSettings = $("doneSettings");

    function openSettings() {
        if (!settingsOverlay) return;

        settingsOverlay.classList.add("show");
        settingsOverlay.setAttribute("aria-hidden", "false");
    }

    function closeSettingsPage() {
        if (!settingsOverlay) return;

        settingsOverlay.classList.remove("show");
        settingsOverlay.setAttribute("aria-hidden", "true");
    }

    settingsButton?.addEventListener("click", openSettings);
    closeSettings?.addEventListener("click", closeSettingsPage);
    doneSettings?.addEventListener("click", closeSettingsPage);

    settingsOverlay?.addEventListener("click", event => {
        if (event.target === settingsOverlay) {
            closeSettingsPage();
        }
    });

    document.addEventListener("keydown", event => {
        if (
            event.key === "Escape" &&
            settingsOverlay?.classList.contains("show")
        ) {
            closeSettingsPage();
        }
    });

    // ========================================
    // ANDROID SETTINGS SHORTCUTS
    // ========================================

    const androidSettings = {
        "notification": "android.settings.NOTIFICATION_SETTINGS",
        "battery": "android.settings.BATTERY_SAVER_SETTINGS",
        "wifi": "android.settings.WIFI_SETTINGS",
        "network": "android.settings.WIRELESS_SETTINGS",
        "app": "android.settings.APPLICATION_SETTINGS"
    };

    document.querySelectorAll("[data-android-setting]").forEach(button => {
        button.addEventListener("click", () => {
            const setting = button.dataset.androidSetting;

            // App-specific settings require a known package name
            // and Android wrapper support.
            if (
                setting === "app-details" ||
                setting === "app-permissions" ||
                setting === "app-notification" ||
                setting === "app-battery"
            ) {
                showError(
                    "This shortcut requires the Android app package name and native wrapper support."
                );
                return;
            }

            const action = androidSettings[setting];

            if (!action) {
                showError("This Android settings shortcut is not supported.");
                return;
            }

            // Android WebView wrappers may support intent URLs.
            // Ordinary browser previews may not.
            const intentUrl =
                `intent:#Intent;action=${action};end`;

            try {
                window.location.href = intentUrl;
            } catch (error) {
                showError(
                    `Could not open Android Settings: ${error.message}`
                );
            }
        });
    });
}

// ============================================
// EVENTS
// ============================================

function setupEvents() {
    $("startButton").addEventListener(
        "click",
        startMonitoring
    );

    $("stopButton").addEventListener(
        "click",
        stopMonitoring
    );

    $("dismissAlarm").addEventListener(
        "click",
        dismissAlarm
    );

    $("volume").addEventListener("input", () => {
        $("volumeText").textContent =
            `${$("volume").value}%`;

        saveSettings();
    });

    $("userId").addEventListener("change", async () => {
        clearError();
        resetStatistics();

        setMonitoringState(false);
        saveSettings();

        await refreshStatus(true);
    });

    $("rapGoal").addEventListener("change", () => {
        saveSettings();
    });

    setupTabs();
    setupSettings();
}

// ============================================
// INITIALIZATION
// ============================================

async function initialize() {
    setupEvents();

    loadSettings();
    resetStatistics();

    await refreshStatus(true);

    if (refreshTimer !== null) {
        clearInterval(refreshTimer);
    }

    refreshTimer = setInterval(() => {
        refreshStatus(false);
    }, REFRESH_INTERVAL_MS);
}

document.addEventListener(
    "DOMContentLoaded",
    initialize
);
