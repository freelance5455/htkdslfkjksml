document.addEventListener('DOMContentLoaded', function () {

    const emailListInput = document.getElementById('emailList');
    const passwordInput = document.getElementById('passwordInput');
    const emailCount = document.getElementById('emailCount');
    const startBtn = document.getElementById('startBtn');
    const statusDiv = document.getElementById('statusMsg');
    const successPanel = document.getElementById('successPanel');
    const successList = document.getElementById('successList');
    const successCountText = document.getElementById('successCountText');
    const copyBtn = document.getElementById('copyBtn');
    const resetBtn = document.getElementById('resetBtn');

    const deleteListBtn = document.getElementById('deleteListBtn');       // TOP: email list
    const deleteResultsBtn = document.getElementById('deleteResultsBtn'); // BOTTOM: saved results

    const STORAGE_KEY = "hbx_insta_auto_v9";

    // Load saved inputs
    try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            const d = JSON.parse(saved);
            if (d.emails) emailListInput.value = d.emails;
            if (d.password) passwordInput.value = d.password;
        }
    } catch (e) {}

    function updateCount() {
        const val = emailListInput.value.trim();
        emailCount.textContent = val ? val.split('\n').filter(l => l.trim()).length : 0;
    }
    emailListInput.addEventListener('input', updateCount);
    updateCount();

    function autoSave() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify({
                emails: emailListInput.value,
                password: passwordInput.value,
                savedAt: Date.now()
            }));
        } catch (e) {}
    }
    emailListInput.addEventListener('input', autoSave);
    passwordInput.addEventListener('input', autoSave);

    // ══════════════════════════════════════════════════════
    // ⭐ DOUBLE-CLICK CONFIRM HELPER (mobile-safe)
    // ══════════════════════════════════════════════════════
    function attachDoubleConfirm(btn, originalText, onConfirm) {
        let armed = false;
        let timer = null;

        btn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();

            if (!armed) {
                // First click — arm
                armed = true;
                btn.textContent = '⚠️ CLICK AGAIN TO CONFIRM';
                btn.style.background = 'linear-gradient(135deg, #f59e0b, #fbbf24)';
                btn.style.color = '#000';
                btn.style.transform = 'scale(1.05)';

                timer = setTimeout(() => {
                    armed = false;
                    btn.textContent = originalText;
                    btn.style.background = '';
                    btn.style.color = '';
                    btn.style.transform = '';
                }, 3000);

                console.log("⚠️ Delete armed — click again within 3s");
            } else {
                // Second click — execute
                clearTimeout(timer);
                armed = false;
                btn.textContent = originalText;
                btn.style.background = '';
                btn.style.color = '';
                btn.style.transform = '';

                console.log("✅ Delete confirmed");
                onConfirm();
            }
        });
    }

    // ══════════════════════════════════════════════════════
    // 🗑️ TOP BUTTON — DELETE EMAIL LIST
    // ══════════════════════════════════════════════════════
    attachDoubleConfirm(deleteListBtn, '🗑️ DELETE EMAIL', function () {
        // Clear textarea + password
        emailListInput.value = '';
        passwordInput.value = '';
        updateCount();

        // Clear localStorage auto-save
        try {
            localStorage.removeItem(STORAGE_KEY);
        } catch (e) {}

        statusDiv.className = "status";
        statusDiv.textContent = "🗑️ Email list cleared";
        console.log("🗑️ [TOP] Email list cleared");
    });

    // ══════════════════════════════════════════════════════
    // 🗑️ BOTTOM BUTTON — DELETE SAVED RESULTS
    // ══════════════════════════════════════════════════════
    attachDoubleConfirm(deleteResultsBtn, '🗑️ DELETE SAVED LIST', function () {
        chrome.storage.local.set({
            savedResults: [],
            successEmails: [],
            currentUsername: ""
        }, () => {
            successPanel.classList.remove('show');
            statusDiv.className = "status";
            statusDiv.textContent = "🗑️ Saved results cleared";
            console.log("🗑️ [BOTTOM] Saved results cleared");
        });
    });

    // ==========================================
    // ✅ SUCCESS PANEL
    // ==========================================
    function showSuccessPanel(results) {
        if (!results || results.length === 0) {
            successPanel.classList.remove('show');
            return;
        }
        successPanel.classList.add('show');
        successCountText.textContent = "Total: " + results.length + " accounts";
        successList.innerHTML = '';
        results.forEach((r, i) => {
            const div = document.createElement('div');
            div.textContent = (i + 1) + ". " + (r.username || "?") + " | " + (r.email || "?");
            successList.appendChild(div);
        });
        statusDiv.className = "status success";
        statusDiv.textContent = "✅ " + results.length + " account(s) done!";
    }

    function loadResults() {
        chrome.storage.local.get(['savedResults', 'successEmails'], (data) => {
            let results = data.savedResults || [];

            if (results.length === 0 && data.successEmails && data.successEmails.length > 0) {
                results = data.successEmails.map(e => ({
                    username: "?",
                    password: "?",
                    fullcookie: "",
                    email: e
                }));
            }

            if (results.length > 0) showSuccessPanel(results);
            else successPanel.classList.remove('show');
        });
    }

    loadResults();
    setInterval(loadResults, 1000);

    chrome.storage.onChanged.addListener((changes, ns) => {
        if (ns === 'local') {
            if (changes.savedResults || changes.successEmails) loadResults();
        }
    });

    // ==========================================
    // ✅ COPY ALL
    // ==========================================
    copyBtn.addEventListener('click', function () {
        chrome.storage.local.get(['savedResults'], async (data) => {
            const results = data.savedResults || [];

            if (results.length === 0) {
                copyBtn.textContent = "❌ No results";
                setTimeout(() => copyBtn.textContent = "📋 COPY ALL", 2000);
                return;
            }

            const lines = results.map(r => {
                const username = r.username || "?";
                const password = r.password || "?";
                const cookie = r.fullcookie || "?";
                const email = r.email || "?";
                return `${username}\t${password}\t${cookie}\t${email}`;
            });

            const text = lines.join("\n");
            console.log("📋 Copying " + results.length + " accounts");

            try {
                await navigator.clipboard.writeText(text);
                copyBtn.textContent = "✅ COPIED " + results.length + "!";
                setTimeout(() => copyBtn.textContent = "📋 COPY ALL", 2500);
            } catch (e) {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                try {
                    document.execCommand('copy');
                    copyBtn.textContent = "✅ COPIED " + results.length + "!";
                    setTimeout(() => copyBtn.textContent = "📋 COPY ALL", 2500);
                } catch (err) {
                    copyBtn.textContent = "❌ Copy failed";
                    setTimeout(() => copyBtn.textContent = "📋 COPY ALL", 2000);
                }
                document.body.removeChild(ta);
            }
        });
    });

    // ==========================================
    // ✅ RESET — double-click confirm
    // ==========================================
    attachDoubleConfirm(resetBtn, '🗑️ CLEAR & RESET (all)', function () {
        // Clear inputs
        emailListInput.value = '';
        passwordInput.value = '';
        updateCount();
        try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}

        // Clear chrome.storage
        chrome.storage.local.set({
            savedResults: [],
            successEmails: [],
            isRunning: false,
            currentIndex: 0,
            currentUsername: "",
            usedUsernames: []
        }, () => {
            successPanel.classList.remove('show');
            statusDiv.className = "status";
            statusDiv.textContent = "✅ Reset complete — ready to start";
            console.log("🗑️ Everything cleared");
        });
    });

    // ==========================================
    // ✅ START
    // ==========================================
    startBtn.addEventListener('click', function () {
        const emailInput = emailListInput.value;
        const passwordVal = passwordInput.value.trim();

        const emails = emailInput.split('\n').map(l => l.trim()).filter(l => l);

        if (emails.length === 0) {
            statusDiv.className = "status error";
            statusDiv.textContent = "⚠️ Enter at least one email";
            return;
        }
        if (passwordVal === "") {
            statusDiv.className = "status error";
            statusDiv.textContent = "⚠️ Enter password";
            return;
        }

        autoSave();

        const accounts = emails.map(email => email + ':' + passwordVal);

        chrome.storage.local.set({
            savedResults: [],
            successEmails: [],
            currentUsername: ""
        }, () => {
            statusDiv.className = "status";
            statusDiv.textContent = "Saving...";
            successPanel.classList.remove('show');

            chrome.storage.local.set({
                accounts: accounts,
                currentIndex: 0,
                isRunning: true,
                totalAccounts: accounts.length
            }, function () {
                if (chrome.runtime.lastError) {
                    statusDiv.className = "status error";
                    statusDiv.textContent = "Error: " + chrome.runtime.lastError.message;
                    return;
                }

                statusDiv.className = "status success";
                statusDiv.textContent = "✅ Started! Opening Instagram...";

                chrome.tabs.create({
                    url: "https://www.instagram.com/accounts/login/?mtn"
                }, () => setTimeout(() => window.close(), 800));
            });
        });
    });
});