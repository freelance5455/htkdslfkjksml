"use strict";

// ============================================
// RAP ALARM 4.0 - CLOUDFLARE CONNECTION
// ============================================

const WORKER_URL = "https://rap-alarm.kevinnewmen.workers.dev";

const DEFAULT_USER_ID = "2300021427";
const DEFAULT_GOAL = 4000;
const DEFAULT_VOLUME = 100;

const REQUEST_TIMEOUT_MS = 15000;
const REFRESH_INTERVAL_MS = 5000;

const $ = id => document.getElementById(id);

let refreshTimer = null;
let dismissedGoalDisplay = false;
let monitoring = false;
let dismissingAlarm = false;

// ============================================
// FORMATTING
// ============================================

function formatNumber(value) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return "—";
    }

    return Math.round(number).toLocaleString();
}

function formatDate(value) {
    if (!value) return "Never";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return date.toLocaleString();
}

// ============================================
// STATUS AND ERRORS
// ============================================

function showError(message) {
    const box = $("errorBox");

    if (!box) return;

    box.textContent = message;
    box.classList.add("show");
}

function clearError() {
    const box = $("errorBox");

    if (!box) return;

    box.textContent = "";
    box.classList.remove("show");
}

function setStatus(message, type = "normal") {
    $("statusText").textContent = message;

    const dot = $("statusDot");

    dot.classList.remove("online", "warning");

    if (type === "online") {
        dot.classList.add("online");
    }

    if (type === "warning") {
        dot.classList.add("warning");
    }
}

function setMonitoringState(value) {
    monitoring = value;

    $("startButton").disabled = value;
    $("stopButton").disabled = !value;

    if (value) {
        setStatus("Monitoring", "online");
    } else {
        setStatus("Not monitoring");
    }
}

// ============================================
// VALIDATION
// ============================================

function getSettings() {
    const userId = $("userId").value.trim();
    const rapGoal = Number($("rapGoal").value);

    if (!/^\d+$/.test(userId)) {
        throw new Error("Enter a valid numeric Roblox User ID.");
    }

    if (!Number.isSafeInteger(rapGoal) || rapGoal < 1) {
        throw new Error("Enter a valid RAP goal.");
    }

    return {
        userId,
        rapGoal
    };
}

// ============================================
// CLOUDFLARE API
// ============================================

async function apiRequest(path, options = {}) {
    const controller = new AbortController();

    const timeout = setTimeout(() => {
        controller.abort();
    }, REQUEST_TIMEOUT_MS);

    try {
        const response = await fetch(
            `${WORKER_URL}${path}`,
            {
                method: options.method || "GET",

                headers: {
                    "Accept": "application/json",

                    ...(options.body
                        ? { "Content-Type": "application/json" }
                        : {})
                },

                body: options.body
                    ? JSON.stringify(options.body)
                    : undefined,

                cache: "no-store",
                signal: controller.signal
            }
        );

        const responseText = await response.text();

        let data;

        try {
            data = responseText
                ? JSON.parse(responseText)
                : {};
        } catch {
            throw new Error(
                `Cloudflare returned invalid JSON. HTTP ${response.status}.`
            );
        }

        if (!response.ok) {
            throw new Error(
                data.error ||
                data.message ||
                `Cloudflare request failed. HTTP ${response.status}.`
            );
        }

        if (data.ok === false) {
            throw new Error(
                data.error ||
                data.message ||
                "Cloudflare reported an error."
            );
        }

        return data;

    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error("Cloudflare request timed out.");
        }

        if (error instanceof TypeError) {
            throw new Error(
                "Could not connect to Cloudflare. Check your internet connection and Worker CORS settings."
            );
        }

        throw error;

    } finally {
        clearTimeout(timeout);
    }
}

function extractState(response) {
    if (response.state && typeof response.state === "object") {
        return response.state;
    }

    if (response.data && typeof response.data === "object") {
        return response.data;
    }

    return response;
}

// ============================================
// RAP DISPLAY
// ============================================

function updateStatistics(data) {
    const rap = Number(data.rap);
    const goal = Number(data.goal);

    const validRap = Number.isFinite(rap);
    const validGoal = Number.isFinite(goal) && goal > 0;

    $("currentRap").textContent = validRap
        ? formatNumber(rap)
        : "—";

    $("goalValue").textContent = validGoal
        ? formatNumber(goal)
        : formatNumber(DEFAULT_GOAL);

    let remaining = null;

    if (validRap && validGoal) {
        remaining = Math.max(0, goal - rap);
    } else if (Number.isFinite(Number(data.remaining))) {
        remaining = Number(data.remaining);
    }

    $("remainingRap").textContent =
        remaining === null
            ? "—"
            : formatNumber(remaining);

    const count = Number(data.limitedCount);

    $("limitedCount").textContent =
        Number.isFinite(count)
            ? formatNumber(count)
            : "—";

    let progress = 0;

    if (validRap && validGoal) {
        progress = Math.min(
            100,
            Math.max(0, (rap / goal) * 100)
        );
    }

    $("progressFill").style.width = `${progress}%`;

    $("progressText").textContent =
        `${Math.round(progress)}%`;

    $("lastChecked").textContent =
        `Last checked: ${formatDate(data.lastChecked)}`;

    const reached =
        data.goalReached === true ||
        (validRap && validGoal && rap >= goal);

    if (reached) {
        if (data.alarmDismissed === true) {
            dismissedGoalDisplay = true;
        } else if (data.alarmDismissed === false) {
            dismissedGoalDisplay = false;
        }

        if (dismissedGoalDisplay) {
            $("alarmBox").classList.remove("show");
        } else {
            $("alarmBox").classList.add("show");
        }

    } else {
        dismissedGoalDisplay = false;
        $("alarmBox").classList.remove("show");
    }
}

function resetStatistics() {
    $("currentRap").textContent = "—";
    $("goalValue").textContent = formatNumber(DEFAULT_GOAL);
    $("remainingRap").textContent = "—";
    $("limitedCount").textContent = "—";

    $("progressFill").style.width = "0%";
    $("progressText").textContent = "0%";

    $("lastChecked").textContent = "Last checked: Never";

    $("alarmBox").classList.remove("show");

    dismissedGoalDisplay = false;
}

// ============================================
// SAVE AND LOAD SETTINGS
// ============================================

async function saveSettings() {
    const settings = {
        userId: $("userId").value.trim(),
        rapGoal: Number($("rapGoal").value),
        volume: Number($("volume").value)
    };

    await chrome.storage.local.set({
        rapAlarmSettings: settings
    });
}

async function loadSettings() {
    const result = await chrome.storage.local.get(
        "rapAlarmSettings"
    );

    const settings = result.rapAlarmSettings || {};

    $("userId").value =
        settings.userId || DEFAULT_USER_ID;

    $("rapGoal").value =
        settings.rapGoal || DEFAULT_GOAL;

    const volume = Number.isFinite(Number(settings.volume))
        ? Number(settings.volume)
        : DEFAULT_VOLUME;

    $("volume").value = Math.max(
        0,
        Math.min(200, volume)
    );

    $("volumeText").textContent =
        `${$("volume").value}%`;
}

// ============================================
// CHECK CLOUDFLARE STATUS
// ============================================

async function refreshStatus(showErrors = false) {
    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        if (showErrors) showError(error.message);
        return;
    }

    try {
        const response = await apiRequest(
            `/api/status?userId=${encodeURIComponent(settings.userId)}`
        );

        const data = extractState(response);

        clearError();

        setMonitoringState(data.monitoring === true);

        if (
            data.monitoring === true &&
            Number(data.goal) > 0
        ) {
            $("rapGoal").value = String(data.goal);
        }

        updateStatistics(data);

        await saveSettings();

    } catch (error) {
        setStatus("Cloudflare connection failed", "warning");

        if (showErrors) {
            showError(error.message);
        }
    }
}

// ============================================
// START MONITORING
// ============================================

async function startMonitoring() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    $("startButton").disabled = true;

    setStatus("Starting monitoring...", "warning");

    try {
        await saveSettings();

        const response = await apiRequest(
            "/api/start",
            {
                method: "POST",

                body: {
                    userId: settings.userId,
                    rapGoal: settings.rapGoal
                }
            }
        );

        const data = extractState(response);

        dismissedGoalDisplay = false;

        setMonitoringState(
            data.monitoring !== false
        );

        if (data.rap !== undefined) {
            updateStatistics({
                ...data,
                goal: data.goal || settings.rapGoal
            });
        }

        await refreshStatus(true);

    } catch (error) {
        setMonitoringState(false);
        showError(error.message);

    } finally {
        $("startButton").disabled = monitoring;
    }
}

// ============================================
// DISMISS ALARM DISPLAY
// Does NOT stop RAP monitoring.
// Sends RAP Alarm Stop to the phone.
// ============================================

async function dismissAlarm() {
    if (dismissingAlarm) return;

    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    dismissingAlarm = true;

    $("dismissAlarm").disabled = true;
    $("dismissAlarm").textContent = "Stopping phone alarm...";

    try {
        await apiRequest(
            "/api/dismiss",
            {
                method: "POST",

                body: {
                    userId: settings.userId
                }
            }
        );

        dismissedGoalDisplay = true;

        $("alarmBox").classList.remove("show");

        clearError();

        setStatus(
            monitoring
                ? "Monitoring — alarm dismissed"
                : "Not monitoring"
        );

        await refreshStatus(false);

    } catch (error) {
        showError(
            `Could not dismiss the phone alarm: ${error.message}`
        );

    } finally {
        dismissingAlarm = false;

        $("dismissAlarm").disabled = false;
        $("dismissAlarm").textContent = "Dismiss Alarm Display";
    }
}

// ============================================
// STOP MONITORING
// Stops RAP monitoring and sends phone stop.
// ============================================

async function stopMonitoring() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    $("stopButton").disabled = true;

    setStatus("Stopping monitoring...", "warning");

    try {
        await apiRequest(
            "/api/stop",
            {
                method: "POST",

                body: {
                    userId: settings.userId
                }
            }
        );

        setMonitoringState(false);

        resetStatistics();

        clearError();

    } catch (error) {
        showError(error.message);

        await refreshStatus(false);
    }
}

// ============================================
// MANUAL RAP CHECK
// ============================================

async function manualCheck() {
    clearError();

    let settings;

    try {
        settings = getSettings();
    } catch (error) {
        showError(error.message);
        return;
    }

    setStatus("Checking RAP...", "warning");

    try {
        await apiRequest(
            "/api/check",
            {
                method: "POST",

                body: {
                    userId: settings.userId
                }
            }
        );

        await refreshStatus(true);

    } catch (error) {
        showError(error.message);
        await refreshStatus(false);
    }
}

// ============================================
// TABS
// ============================================

function setupTabs() {
    document.querySelectorAll(".tab").forEach(button => {
        button.addEventListener("click", () => {
            document.querySelectorAll(".tab").forEach(tab => {
                tab.classList.remove("active");
            });

            button.classList.add("active");

            const tab = button.dataset.tab;

            $("rapPanel").classList.toggle(
                "hidden",
                tab !== "rap"
            );

            $("tradingPanel").classList.toggle(
                "hidden",
                tab !== "trading"
            );

            $("adsPanel").classList.toggle(
                "hidden",
                tab !== "ads"
            );
        });
    });
}

// ============================================
// EVENTS
// ============================================

function setupEvents() {
    $("startButton").addEventListener(
        "click",
        startMonitoring
    );

    $("stopButton").addEventListener(
        "click",
        stopMonitoring
    );

    $("dismissAlarm").addEventListener(
        "click",
        dismissAlarm
    );

    $("volume").addEventListener("input", async () => {
        $("volumeText").textContent =
            `${$("volume").value}%`;

        await saveSettings();
    });

    $("userId").addEventListener("change", async () => {
        clearError();
        resetStatistics();

        await saveSettings();
        await refreshStatus(true);
    });

    $("rapGoal").addEventListener(
        "change",
        saveSettings
    );

    setupTabs();
}

// ============================================
// INITIALIZATION
// ============================================

async function initialize() {
    setupEvents();

    try {
        await loadSettings();
    } catch (error) {
        showError(
            `Could not load settings: ${error.message}`
        );
    }

    resetStatistics();

    await refreshStatus(true);

    if (refreshTimer) {
        clearInterval(refreshTimer);
    }

    refreshTimer = setInterval(() => {
        refreshStatus(false);
    }, REFRESH_INTERVAL_MS);
}

document.addEventListener(
    "DOMContentLoaded",
    initialize
);