const D={enabled:false,boost:48,drive:0,echo:0,delay:110,feedback:0,bass:0,presence:100,treble:0,reverb:0,echoFx:0,chorus:0,distortion:0,tremolo:0,compressor:50,flanger:0};
const $=id=>document.getElementById(id);
function send(m){chrome.tabs.query({active:true,currentWindow:true},t=>{if(t[0]?.id)chrome.tabs.sendMessage(t[0].id,m).catch(()=>{})})}
function save(k,v){const val=Number(v);chrome.storage.local.set({[k]:val});send({type:"VD_SET",key:k,value:val})}
const labels={boost:"boostOut",drive:"driveOut",echo:"echoOut",delay:"delayOut",feedback:"feedbackOut",bass:"bassOut",presence:"presenceOut",treble:"trebleOut",reverb:"reverbOut",echoFx:"echoFxOut",chorus:"chorusOut",distortion:"distortionOut",tremolo:"tremoloOut",compressor:"compressorOut",flanger:"flangerOut"};
function unit(k,v){return ["boost","bass","treble"].includes(k)?v+" dB":k==="delay"?v+" ms":v+"%"}
chrome.storage.local.get(D,c=>{
 Object.keys(labels).forEach(k=>{if($(k)){$(k).value=c[k]??D[k];$(labels[k]).textContent=unit(k,$(k).value)}});
 const e=!!c.enabled;$("status").textContent=e?"● PROCESSOR ON":"● PROCESSOR OFF";$ ("toggle").textContent=e?"MIC PROCESSOR OFF":"MIC PROCESSOR ON";$ ("sentStatus").textContent=e?"🟡 WAITING FOR CALL — SPEAK TO TEST":"⚫ PROCESSOR OFF";
});
$("toggle").onclick=()=>chrome.storage.local.get({enabled:false},c=>{const e=!c.enabled;chrome.storage.local.set({enabled:e});send({type:"VD_ENABLE",enabled:e});$("status").textContent=e?"● PROCESSOR ON":"● PROCESSOR OFF";$("toggle").textContent=e?"MIC PROCESSOR OFF":"MIC PROCESSOR ON";$("sentStatus").textContent=e?"🟡 WAITING FOR CALL — SPEAK TO TEST":"⚫ PROCESSOR OFF"});
chrome.storage.onChanged.addListener((changes,area)=>{if(area==="local"&&changes.callOutputStatus){$("sentStatus").textContent="● "+changes.callOutputStatus.newValue;}});
Object.keys(labels).forEach(k=>{if($(k))$(k).oninput=e=>{$(labels[k]).textContent=unit(k,e.target.value);save(k,e.target.value)}});
const P={clean:{boost:12,drive:0,echo:0,delay:110,feedback:0,bass:0,presence:100,treble:0,reverb:0,echoFx:0,chorus:0,distortion:0,tremolo:0,compressor:35,flanger:0},loud:{boost:54,drive:100,echo:0,delay:110,feedback:0,bass:6,presence:110,treble:6,reverb:0,echoFx:0,chorus:0,distortion:100,tremolo:0,compressor:0,flanger:0},echo:{boost:12,drive:0,echo:0,delay:180,feedback:45,bass:0,presence:100,treble:2,reverb:15,echoFx:45,chorus:0,distortion:0,tremolo:0,compressor:40,flanger:0},stage:{boost:15,drive:0,echo:0,delay:110,feedback:0,bass:3,presence:105,treble:3,reverb:20,echoFx:0,chorus:10,distortion:0,tremolo:0,compressor:60,flanger:0}};
document.querySelectorAll("[data-p]").forEach(b=>b.onclick=()=>Object.entries(P[b.dataset.p]).forEach(([k,v])=>{if($(k)){$(k).value=v;$(labels[k]).textContent=unit(k,v);save(k,v)}}));
$("test").onclick=()=>send({type:"VD_TEST"});
