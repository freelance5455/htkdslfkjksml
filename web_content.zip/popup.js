/* Hurairah Pro V2 — popup controller */
(function () {
  "use strict";

  var HOST = /(market-qx\.(trade|pro|net)|qxbroker\.(com|net)|quotex\.io)/i;
  var statusEl = document.getElementById("status");

  function setStatus(message, isError) {
    statusEl.textContent = message;
    statusEl.className = "status" + (isError ? " err" : "");
  }

  function launch() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !tab.id) {
        setStatus("Open your Quotex chart first.", true);
        return;
      }
      if (!HOST.test(tab.url || "")) {
        setStatus("Open a Quotex / QXBroker page first.", true);
        return;
      }

      setStatus("Injecting secure engine…");
      var done = function () {
        if (chrome.runtime.lastError) {
          setStatus("Reload the page, then launch again.", true);
          return;
        }
        setStatus("Engine active. Close this menu.");
      };

      if (chrome.scripting && chrome.scripting.executeScript) {
        var target = { tabId: tab.id, allFrames: true };
        chrome.scripting.insertCSS({ target: target, files: ["content.css"] }, function () {
          chrome.scripting.executeScript({ target: target, files: ["content.js"] }, done);
        });
      } else {
        chrome.tabs.insertCSS(tab.id, { file: "content.css", allFrames: true }, function () {
          chrome.tabs.executeScript(tab.id, { file: "content.js", allFrames: true }, done);
        });
      }
    });
  }

  document.getElementById("openBot").addEventListener("click", launch);
  launch();
})();
