# HTML2APK STUDIO PRO

Chuyển dự án HTML/CSS/JS thành APK Android thật (WebView + Android Gradle Plugin).
Luồng: **Upload → Configure → Build → Download**.

```
html2apk-studio-pro/
├── index.html              Mode A: frontend 1 file (mở trực tiếp hoặc host ở đâu cũng được)
├── server/                 Mode B: API + build worker
│   ├── server.js           HTTP API, hàng đợi, giới hạn, dọn file, CORS, API key
│   ├── worker.js           Kiểm tra gói → sinh dự án Android → Gradle → apksigner/aapt2 verify
│   ├── shared/             zip.js + android-template.js (dùng chung với frontend)
│   ├── public/index.html   Frontend được server phục vụ tại "/"
│   ├── Dockerfile          JDK 17 + Android SDK 34 + build-tools 34 + Gradle 8.7
│   └── package.json        Không có dependency, không cần npm install
├── sample-project/         Dự án HTML mẫu để test
└── tests/                  Script test đã chạy
```

## Cái gì chạy ở đâu

| Chức năng | Chạy ở |
|---|---|
| Upload HTML / ZIP, giải nén an toàn, kiểm tra cấu trúc | Trình duyệt |
| Live Preview (phone/tablet/desktop, bắt lỗi JS) | Trình duyệt, iframe sandbox |
| Cấu hình APK, sinh icon 5 mật độ, splash | Trình duyệt |
| Xuất Android Project (build bằng GitHub Actions / Android Studio) | Trình duyệt |
| **Biên dịch APK, ký, xác minh** | **Build server** (cần JDK + Android SDK + Gradle) |
| Ghi kết quả vào ClickUp Task | Build server + `CLICKUP_API_TOKEN` |

Trình duyệt và ClickUp không chạy được Gradle/Android SDK, nên APK chỉ có thể sinh ra trên build server hoặc qua GitHub Actions.

## Chạy build server (Mode B)

```bash
cd server
docker build -t html2apk .            # ~10-15 phút lần đầu, tải SDK + cache dependency
docker run -d --name html2apk -p 8787:8787 \
  --memory 4g --cpus 2 --pids-limit 512 \
  -e BUILD_API_KEY="chuoi-bi-mat-dai" \
  -e ALLOWED_ORIGINS="https://app-cua-ban.com" \
  -v html2apk-data:/data html2apk
```
Mở `http://localhost:8787` → giao diện tự nhận server. Hoặc mở `index.html` ở nơi khác, vào bước Build, dán URL server + API key.

Không dùng Docker: cài JDK 17, Android SDK (platforms;android-34, build-tools;34.0.0), Gradle 8.7, đặt `ANDROID_HOME`, rồi `node worker.js --warmup && node server.js` (Node ≥ 18).

### Biến môi trường

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `PORT`, `HOST` | 8787, 0.0.0.0 | Địa chỉ lắng nghe |
| `DATA_DIR` | ./data | Nơi lưu job tạm và APK |
| `BUILD_API_KEY` | (trống) | Bật xác thực `Authorization: Bearer <key>` |
| `ALLOWED_ORIGINS` | `*` | Danh sách origin CORS, phân tách dấu phẩy. Production phải đặt |
| `MAX_UPLOAD_MB` | 40 | Giới hạn gói upload |
| `BUILD_TIMEOUT_SEC` | 900 | Giết build quá giờ |
| `BUILD_CONCURRENCY` | 1 | Số build chạy song song |
| `MAX_QUEUE` | 20 | Số build chờ tối đa |
| `RETENTION_HOURS` | 24 | Sau thời gian này xóa APK + log |
| `RATE_LIMIT_PER_HOUR` | 30 | Số build / IP / giờ |
| `H2A_KEYSTORE`, `H2A_KEYSTORE_PASSWORD`, `H2A_KEY_ALIAS`, `H2A_KEY_PASSWORD` | | Ký bản Release. Mount keystore vào container, không đưa vào image hay frontend |
| `H2A_GRADLE_OFFLINE` | 1 (trong Docker) | Build không truy cập mạng, dùng cache từ bước warmup |
| `CLICKUP_API_TOKEN` | | Cho phép comment kết quả vào ClickUp Task |
| `PUBLIC_BASE_URL` | | URL công khai của server, để chèn link tải APK vào comment ClickUp |

Tạo keystore release:
```bash
keytool -genkeypair -v -keystore release.jks -alias app -keyalg RSA -keysize 2048 -validity 10000
docker run ... -v $PWD/release.jks:/run/secrets/release.jks:ro \
  -e H2A_KEYSTORE=/run/secrets/release.jks -e H2A_KEYSTORE_PASSWORD=... -e H2A_KEY_ALIAS=app -e H2A_KEY_PASSWORD=... html2apk
```

## API contract

| Method | Path | Mô tả |
|---|---|---|
| GET | `/api/health` | `{ canBuild, toolchain:{ready, missing[]}, releaseSigning, authRequired, clickup, limits, queue }` |
| POST | `/api/builds` | Body `application/zip` (gói bên dưới) → `201 { id, status }` |
| GET | `/api/builds/:id?since=N` | `{ status, stage, stageTimes, startedAt, finishedAt, durationMs, queuePosition, logs[], nextLogIndex, error, result }` |
| HEAD/GET | `/api/builds/:id/apk` | APK (chỉ khi `status=success` và file còn). Header `X-APK-SHA256` |
| DELETE | `/api/builds/:id` | Hủy nếu đang chạy, xóa toàn bộ file |
| POST | `/api/builds/:id/clickup` | `{ taskId }` → comment kết quả vào Task |

`status`: queued · running · success · failed · canceled
`stage`: waiting · preparing · compiling · packaging · verifying · done
Lỗi: `{ error: { code, message, hint } }`. Mã thường gặp: `TOOLCHAIN_MISSING`, `INVALID_CONFIG`, `NO_ENTRY`, `DISALLOWED_FILES`, `PATH_TRAVERSAL`, `GRADLE_FAILED`, `SIGNATURE_INVALID`, `METADATA_MISMATCH`, `NO_RELEASE_KEY`, `TIMEOUT`.

Gói build (ZIP):
```
config.json                       { appName, packageName, versionName, versionCode, orientation, theme,
                                    minSdk, permissions[], splashColor, entry, buildType }
www/**                            tài nguyên web (whitelist phần mở rộng)
icons/mipmap-<density>/ic_launcher.png, ic_launcher_round.png   (tùy chọn)
```
`success` chỉ được đặt khi: Gradle exit 0, file APK tồn tại, `apksigner verify` pass, `aapt2 dump badging` khớp package/version với cấu hình.

## Bảo mật

- ZIP: chặn `../`, đường dẫn tuyệt đối, symlink, file có mật khẩu, ZIP64; giới hạn số file/dung lượng; kiểm tra kích thước giải nén + CRC (chống zip bomb). Áp dụng cả ở trình duyệt và server.
- Server **không** nhận Gradle/Java từ người dùng: dự án Android luôn sinh lại từ `config.json` đã validate. Người dùng chỉ góp tài nguyên web (whitelist) + PNG.
- Worker chạy user không root trong container, Gradle offline, timeout, giới hạn RAM/CPU/PID qua Docker.
- APK: `WebViewAssetLoader` (tắt file:// và content://), chặn cleartext HTTP, chặn mixed content, link ngoài mở bằng trình duyệt, chỉ khai báo quyền được chọn, quyền nhạy cảm hỏi lúc chạy, `allowBackup=false`.
- API key so sánh constant-time, không lưu trong trình duyệt. Lịch sử build ở localStorage chỉ chứa metadata.

## ClickUp

- Hiển thị: đính kèm `index.html` vào Task hoặc tạo Embed view trỏ tới `https://server-cua-ban/`.
- Nhận dự án: tải file đính kèm của Task rồi Upload ở bước Import (frontend không tự đọc file của ClickUp).
- Ghi kết quả: đặt `CLICKUP_API_TOKEN` (personal token) ở server; nhiều người dùng thì làm ClickUp OAuth app và lưu token phía server.

## Không chạy server: GitHub Actions

Bước Build → **Xuất Android Project** → giải nén → đẩy lên repo GitHub → tab Actions → workflow "Build APK" → tải APK debug ở Artifacts.

## Test đã chạy

- `tests/gen.js`: sinh dự án 3 cấu hình, parse toàn bộ XML, compile `MainActivity.java` bằng javac với stub Android API.
- `tests/api_test.js`: đọc ZIP deflate, chặn zip-slip, giới hạn dung lượng, POST build, validate cấu hình, 415, DELETE.
- `tests/ui.js`: Playwright: import mẫu/ZIP lỗi/ZIP độc, preview + điều hướng + bắt lỗi JS, validate form, xuất Android project, luồng build (server thiếu toolchain và server giả lập).
- **Chưa chạy**: build Gradle thật và `docker build` (môi trường phát triển không có Internet/Android SDK). Lần chạy thật đầu tiên là ở máy bạn.
