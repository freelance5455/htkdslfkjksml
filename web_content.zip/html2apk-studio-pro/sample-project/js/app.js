const KEY = 'viec-hom-nay';
const list = document.getElementById('list');
let items = JSON.parse(localStorage.getItem(KEY) || '[]');
function save() { localStorage.setItem(KEY, JSON.stringify(items)); }
function render() {
  list.innerHTML = '';
  items.forEach((it, i) => {
    const li = document.createElement('li');
    li.className = it.done ? 'done' : '';
    const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = it.done; cb.style.flex = '0';
    cb.onchange = () => { it.done = cb.checked; save(); render(); };
    const sp = document.createElement('span'); sp.textContent = it.text;
    const del = document.createElement('button'); del.textContent = 'Xóa'; del.onclick = () => { items.splice(i, 1); save(); render(); };
    li.append(cb, sp, del); list.appendChild(li);
  });
}
document.getElementById('f').addEventListener('submit', (e) => {
  e.preventDefault();
  const t = document.getElementById('t');
  if (!t.value.trim()) return;
  items.unshift({ text: t.value.trim(), done: false }); t.value = ''; save(); render();
});
render();