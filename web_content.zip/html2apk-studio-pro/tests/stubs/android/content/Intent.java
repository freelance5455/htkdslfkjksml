package android.content; public class Intent { public static final String ACTION_VIEW="v"; public Intent(String a, android.net.Uri u){} }
