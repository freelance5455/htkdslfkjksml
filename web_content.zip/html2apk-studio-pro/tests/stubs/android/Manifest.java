package android; public final class Manifest { public static final class permission { public static final String CAMERA="c",RECORD_AUDIO="r",ACCESS_FINE_LOCATION="f",ACCESS_COARSE_LOCATION="co"; } }
