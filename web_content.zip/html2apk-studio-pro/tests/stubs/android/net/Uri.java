package android.net; public abstract class Uri { public abstract String getHost(); }
