const T=require('../server/shared/android-template.js'); const fs=require('fs'); const path=require('path');
const cases=[
 Object.assign(T.defaultConfig(),{appName:`Tôi's "App" @home & <x>`.replace(/[<>]/g,''),packageName:'vn.dainghia.faceapp',permissions:['INTERNET','CAMERA','RECORD_AUDIO','ACCESS_FINE_LOCATION','VIBRATE'],theme:'system',entry:'pages/main page.html'}),
 Object.assign(T.defaultConfig(),{theme:'dark',orientation:'portrait'}),
 Object.assign(T.defaultConfig(),{theme:'light',orientation:'landscape',minSdk:21,buildType:'release'}),
];
cases.forEach((c,i)=>{ const dir=`/tmp/gen${i}`; fs.rmSync(dir,{recursive:true,force:true}); for(const f of T.generateAndroidProject(c)){ const p=path.join(dir,f.path); fs.mkdirSync(path.dirname(p),{recursive:true}); fs.writeFileSync(p,f.data);} console.log('gen',i,'ok'); });
const bad=[{packageName:'Com.Example'},{packageName:'com.class.app'},{versionCode:0},{minSdk:19},{splashColor:'red'},{entry:'../x.html'},{permissions:['READ_SMS']},{appName:''}];
bad.forEach(b=>{ const e=T.validateConfig(Object.assign(T.defaultConfig(),b)); console.log(JSON.stringify(b),'->',e.length?e[0].message:'NO ERROR (BUG)'); });
