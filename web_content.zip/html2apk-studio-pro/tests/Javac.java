import javax.tools.*; public class Javac { public static void main(String[] a){ int r=ToolProvider.getSystemJavaCompiler().run(null,null,null,a); System.exit(r);} }
