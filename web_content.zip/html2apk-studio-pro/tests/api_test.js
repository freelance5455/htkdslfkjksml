const Z=require('../server/shared/zip.js'); const T=require('../shared/android-template.js'); const zlib=require('zlib'); const fs=require('fs');
const base='http://localhost:8787';
(async()=>{
  // 1. zip reader: python deflate zip
  const inflate=(c,n)=>new Uint8Array(zlib.inflateRawSync(c,{maxOutputLength:Math.max(1,n)}));
  const ok=await Z.readZip(fs.readFileSync('/tmp/proj_ok.zip'),{inflateRaw:inflate});
  console.log('read ok zip:', ok.map(e=>e.path).join(', '));
  try{ await Z.readZip(fs.readFileSync('/tmp/proj_evil.zip'),{inflateRaw:inflate}); console.log('EVIL NOT BLOCKED (BUG)'); }catch(e){ console.log('evil zip blocked:', e.code, e.message); }
  // zip bomb-ish: declared size mismatch -> craft by limits
  try{ await Z.readZip(fs.readFileSync('/tmp/proj_ok.zip'),{inflateRaw:inflate,limits:{maxTotalBytes:100}}); }catch(e){ console.log('limit enforced:', e.code); }
  // roundtrip writer -> python check later
  fs.writeFileSync('/tmp/rt.zip', Z.createZip([{path:'a/b.txt',data:'xin chào'},{path:'c.bin',data:new Uint8Array([0,1,2,255])}]));
  // 2. POST bundle
  const bundle=Z.createZip([{path:'config.json',data:JSON.stringify(T.defaultConfig())},{path:'www/index.html',data:'<!doctype html><h1>Hi</h1>'}]);
  let r=await fetch(base+'/api/builds',{method:'POST',headers:{'Content-Type':'application/zip'},body:bundle}); const j=await r.json(); console.log('POST', r.status, j);
  for(let i=0;i<20;i++){ await new Promise(s=>setTimeout(s,300)); const s=await (await fetch(base+'/api/builds/'+j.id)).json(); if(s.status!=='queued'&&s.status!=='running'){ console.log('final:', s.status, s.stage, JSON.stringify(s.error)); console.log(s.logs.join('\n')); break; } }
  r=await fetch(base+'/api/builds/'+j.id+'/apk',{method:'HEAD'}); console.log('HEAD apk ->', r.status);
  // 3. invalid config
  const bad=Z.createZip([{path:'config.json',data:JSON.stringify(Object.assign(T.defaultConfig(),{packageName:'Bad Name'}))},{path:'www/index.html',data:'x'},{path:'www/evil.sh',data:'rm -rf'}]);
  r=await fetch(base+'/api/builds',{method:'POST',headers:{'Content-Type':'application/zip'},body:bad}); const j2=await r.json();
  await new Promise(s=>setTimeout(s,800)); const s2=await (await fetch(base+'/api/builds/'+j2.id)).json(); console.log('bad config ->', s2.status, s2.error.code, s2.error.message);
  // 4. wrong content-type, delete
  r=await fetch(base+'/api/builds',{method:'POST',headers:{'Content-Type':'text/plain'},body:'x'}); console.log('text/plain ->', r.status);
  r=await fetch(base+'/api/builds/'+j2.id,{method:'DELETE'}); console.log('DELETE ->', r.status, fs.existsSync('/tmp/h2a-data/jobs/'+j2.id));
})();
