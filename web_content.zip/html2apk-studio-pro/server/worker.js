#!/usr/bin/env node
/**
 * HTML2APK STUDIO PRO: build worker.
 *
 * Chạy: node worker.js <jobDir>          (jobDir chứa bundle.zip)
 *       node worker.js --warmup          (build thử để tải sẵn dependency Gradle, dùng khi dựng Docker image)
 *
 * Giao thức stdout cho server (mỗi dòng):
 *   @@STAGE <preparing|compiling|packaging|verifying>
 *   @@ERROR {"code","message","hint"}
 *   @@RESULT {"fileName","size","sha256",...}
 *   (dòng khác = log thật từ worker/Gradle)
 *
 * Bảo mật: worker KHÔNG nhận file Gradle/Java từ người dùng. Dự án Android luôn được
 * sinh lại từ config.json đã kiểm tra; người dùng chỉ đóng góp tài nguyên web (www/) và PNG icon.
 */
'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const zlib = require('zlib');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

const Zip = require('./shared/zip.js');
const Tpl = require('./shared/android-template.js');

const LIMITS = {
  maxFiles: 3000,
  maxFileBytes: 30 * 1024 * 1024,
  maxTotalBytes: 120 * 1024 * 1024,
};

function out(line) { process.stdout.write(line + '\n'); }
function stage(s) { out('@@STAGE ' + s); }
function log(msg) { out('[worker] ' + msg); }

class BuildError extends Error {
  constructor(code, message, hint) { super(message); this.code = code; this.hint = hint || ''; }
}

// ---------- Toolchain ----------

function findAndroidSdk() {
  const cands = [process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT, path.join(os.homedir(), 'Android/Sdk'), '/opt/android-sdk'].filter(Boolean);
  return cands.find((p) => fs.existsSync(path.join(p, 'platforms'))) || null;
}

function findBuildTool(sdk, name) {
  const btDir = path.join(sdk, 'build-tools');
  if (!fs.existsSync(btDir)) return null;
  const versions = fs.readdirSync(btDir).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
  for (const v of versions) {
    const p = path.join(btDir, v, name);
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function which(cmd) {
  const r = spawnSync(process.platform === 'win32' ? 'where' : 'which', [cmd], { encoding: 'utf8' });
  return r.status === 0 ? r.stdout.split('\n')[0].trim() : null;
}

/** Kiểm tra đủ công cụ build. Dùng chung cho /api/health. */
function checkToolchain() {
  const sdk = findAndroidSdk();
  const platform = sdk ? fs.existsSync(path.join(sdk, 'platforms', 'android-' + Tpl.TOOLCHAIN.compileSdk)) : false;
  const gradle = process.env.GRADLE_BIN || which('gradle');
  const javac = which('javac');
  const apksigner = sdk ? findBuildTool(sdk, 'apksigner') : null;
  const aapt2 = sdk ? findBuildTool(sdk, 'aapt2') : null;
  const missing = [];
  if (!javac) missing.push('JDK 17 (javac)');
  if (!sdk) missing.push('Android SDK (ANDROID_HOME)');
  else if (!platform) missing.push('platforms;android-' + Tpl.TOOLCHAIN.compileSdk);
  if (!gradle) missing.push('Gradle ' + Tpl.TOOLCHAIN.gradle);
  if (!apksigner || !aapt2) missing.push('build-tools ' + Tpl.TOOLCHAIN.buildTools + ' (apksigner, aapt2)');
  return { ready: missing.length === 0, missing, sdk, gradle, javac, apksigner, aapt2, platform };
}

// ---------- PNG fallback (icon mặc định nếu gói không có icon) ----------

function solidPng(size, rgb) {
  const crcTable = [];
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crcTable[n] = c >>> 0; }
  const crc = (buf) => { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, data) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
    const td = Buffer.concat([Buffer.from(type), data]);
    const c = Buffer.alloc(4); c.writeUInt32BE(crc(td));
    return Buffer.concat([len, td, c]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 2; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const row = Buffer.alloc(1 + size * 3);
  for (let x = 0; x < size; x++) { row[1 + x * 3] = rgb[0]; row[2 + x * 3] = rgb[1]; row[3 + x * 3] = rgb[2]; }
  const raw = Buffer.concat(Array.from({ length: size }, () => row));
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}

function isPng(buf) {
  return buf.length > 24 && buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
}

// ---------- Chạy lệnh và stream log ----------

function run(cmd, args, opts) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, Object.assign({ stdio: ['ignore', 'pipe', 'pipe'] }, opts));
    let tail = '';
    const onData = (prefix) => (buf) => {
      const text = buf.toString('utf8');
      tail = (tail + text).slice(-20000);
      for (const line of text.split(/\r?\n/)) {
        if (!line) continue;
        if (opts && opts.onLine) opts.onLine(line);
        out(prefix + line);
      }
    };
    child.stdout.on('data', onData(''));
    child.stderr.on('data', onData(''));
    child.on('error', (err) => resolve({ code: -1, tail: String(err) }));
    child.on('close', (code) => resolve({ code, tail }));
  });
}

function gradleHint(tail) {
  if (/SDK location not found|ANDROID_HOME/i.test(tail)) return 'Worker chưa cấu hình ANDROID_HOME. Kiểm tra Docker image / biến môi trường.';
  if (/Could not resolve|Could not GET|No cached version/i.test(tail)) return 'Gradle không tải được dependency. Nếu chạy offline, cần build image với bước warmup; nếu online, kiểm tra mạng của worker.';
  if (/AAPT|Android resource linking failed/i.test(tail)) return 'Lỗi tài nguyên Android (icon/tên app). Thử icon PNG vuông khác hoặc đổi App Name.';
  if (/OutOfMemory|Java heap space/i.test(tail)) return 'Worker thiếu RAM. Tăng bộ nhớ container (tối thiểu 3 GB).';
  if (/Duplicate resources|duplicate/i.test(tail)) return 'Có tài nguyên trùng tên. Kiểm tra file trùng tên khác hoa/thường trong dự án.';
  return 'Xem log Gradle ở trên để biết chi tiết.';
}

// ---------- Build chính ----------

async function build(jobDir, opts) {
  opts = opts || {};
  const t0 = Date.now();
  stage('preparing');

  const tc = checkToolchain();
  // 1. Đọc và kiểm tra gói
  const bundlePath = path.join(jobDir, 'bundle.zip');
  if (!fs.existsSync(bundlePath)) throw new BuildError('NO_BUNDLE', 'Không tìm thấy gói dự án.');
  const entries = await Zip.readZip(fs.readFileSync(bundlePath), {
    limits: LIMITS,
    inflateRaw: (comp, expected) => new Uint8Array(zlib.inflateRawSync(comp, { maxOutputLength: Math.max(1, expected) })),
  });
  log(`Đọc gói: ${entries.length} file.`);

  const cfgEntry = entries.find((e) => e.path === 'config.json');
  if (!cfgEntry) throw new BuildError('NO_CONFIG', 'Gói thiếu config.json.', 'Tạo gói bằng HTML2APK STUDIO PRO.');
  let config;
  try { config = JSON.parse(Buffer.from(cfgEntry.data).toString('utf8')); }
  catch (e) { throw new BuildError('BAD_CONFIG', 'config.json không phải JSON hợp lệ.'); }
  // Chỉ giữ đúng các trường đã biết.
  const def = Tpl.defaultConfig();
  config = Object.keys(def).reduce((acc, k) => { acc[k] = config[k]; return acc; }, {});
  const errs = Tpl.validateConfig(config);
  if (errs.length) throw new BuildError('INVALID_CONFIG', errs.map((e) => e.message).join(' '), 'Sửa cấu hình ở bước Configure.');
  log(`Cấu hình: ${config.packageName} v${config.versionName} (${config.versionCode}), minSdk ${config.minSdk}, ${config.buildType}.`);

  const www = [];
  const rejected = [];
  for (const e of entries) {
    if (!e.path.startsWith('www/')) continue;
    const rel = e.path.slice(4);
    if (!rel) continue;
    if (!Tpl.isAllowedAsset(rel)) { rejected.push(rel); continue; }
    www.push({ rel, data: e.data });
  }
  if (rejected.length) throw new BuildError('DISALLOWED_FILES', 'Gói chứa loại file không được phép: ' + rejected.slice(0, 10).join(', '), 'Chỉ đóng gói tài nguyên web (html, css, js, ảnh, font, media).');
  if (!www.some((f) => f.rel === config.entry)) throw new BuildError('NO_ENTRY', `Không tìm thấy file HTML chính "${config.entry}" trong gói.`, 'Chọn lại file HTML chính ở bước Import.');
  log(`Tài nguyên web: ${www.length} file, trang chính ${config.entry}.`);

  const icons = {};
  for (const density of Object.keys(Tpl.DENSITIES)) {
    for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
      const e = entries.find((x) => x.path === `icons/${density}/${name}`);
      if (e) {
        if (!isPng(Buffer.from(e.data)) || e.data.length > 1024 * 1024) throw new BuildError('BAD_ICON', `Icon ${density}/${name} không phải PNG hợp lệ.`);
        icons[`${density}/${name}`] = Buffer.from(e.data);
      }
    }
  }
  if (Object.keys(icons).length === 0) log('Gói không có icon, dùng icon màu mặc định.');

  if (config.buildType === 'release' && !process.env.H2A_KEYSTORE) {
    throw new BuildError('NO_RELEASE_KEY', 'Bản release cần khóa ký nhưng server chưa cấu hình keystore.', 'Chọn Debug để test, hoặc cấu hình H2A_KEYSTORE / H2A_KEYSTORE_PASSWORD / H2A_KEY_ALIAS / H2A_KEY_PASSWORD trên server.');
  }

  if (!tc.ready) {
    throw new BuildError('TOOLCHAIN_MISSING', 'Máy build thiếu: ' + tc.missing.join(', ') + '.', 'Chạy backend bằng Docker image kèm theo (đã có JDK 17, Android SDK 34, Gradle), hoặc xuất Android Project và build bằng GitHub Actions / Android Studio.');
  }

  // 2. Sinh dự án Android
  const proj = path.join(jobDir, 'android');
  fs.rmSync(proj, { recursive: true, force: true });
  for (const f of Tpl.generateAndroidProject(config)) {
    const p = path.join(proj, f.path);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, f.data);
  }
  const assetsRoot = path.join(proj, 'app/src/main/assets/www');
  for (const f of www) {
    const p = path.join(assetsRoot, f.rel);
    if (!p.startsWith(assetsRoot + path.sep)) throw new BuildError('PATH_TRAVERSAL', 'Đường dẫn tài nguyên không hợp lệ: ' + f.rel);
    fs.mkdirSync(path.dirname(p), { recursive: true });
    fs.writeFileSync(p, f.data);
  }
  for (const [density, px] of Object.entries(Tpl.DENSITIES)) {
    const dir = path.join(proj, 'app/src/main/res', density);
    fs.mkdirSync(dir, { recursive: true });
    const sq = icons[`${density}/ic_launcher.png`] || solidPng(px, [76, 110, 245]);
    const rd = icons[`${density}/ic_launcher_round.png`] || sq;
    fs.writeFileSync(path.join(dir, 'ic_launcher.png'), sq);
    fs.writeFileSync(path.join(dir, 'ic_launcher_round.png'), rd);
  }
  fs.writeFileSync(path.join(proj, 'local.properties'), 'sdk.dir=' + tc.sdk.replace(/\\/g, '\\\\') + '\n');
  log('Đã tạo cấu trúc dự án Android.');

  // 3. Gradle
  stage('compiling');
  const task = config.buildType === 'release' ? 'assembleRelease' : 'assembleDebug';
  const args = [task, '--no-daemon', '--console=plain', '--warning-mode=summary'];
  if (process.env.H2A_GRADLE_OFFLINE === '1' && !opts.online) args.push('--offline');
  const env = {
    PATH: process.env.PATH,
    HOME: process.env.HOME || os.homedir(),
    JAVA_HOME: process.env.JAVA_HOME || '',
    ANDROID_HOME: tc.sdk,
    ANDROID_SDK_ROOT: tc.sdk,
    GRADLE_USER_HOME: process.env.GRADLE_USER_HOME || path.join(os.homedir(), '.gradle'),
    GRADLE_OPTS: '-Xmx2g -Dorg.gradle.daemon=false',
  };
  if (config.buildType === 'release') {
    for (const k of ['H2A_KEYSTORE', 'H2A_KEYSTORE_PASSWORD', 'H2A_KEY_ALIAS', 'H2A_KEY_PASSWORD']) env[k] = process.env[k] || '';
  }
  log('gradle ' + args.join(' '));
  let packagingSeen = false;
  const res = await run(tc.gradle, args, {
    cwd: proj,
    env,
    onLine: (line) => {
      if (!packagingSeen && /> Task :app:package(Debug|Release)\b/.test(line)) { packagingSeen = true; stage('packaging'); }
    },
  });
  if (res.code !== 0) throw new BuildError('GRADLE_FAILED', `Gradle kết thúc với mã lỗi ${res.code}.`, gradleHint(res.tail));
  if (!packagingSeen) stage('packaging');

  // 4. Xác minh APK
  stage('verifying');
  const type = config.buildType;
  const apkDir = path.join(proj, 'app/build/outputs/apk', type);
  const apkPath = path.join(apkDir, `app-${type}.apk`);
  if (!fs.existsSync(apkPath)) {
    const found = fs.existsSync(apkDir) ? fs.readdirSync(apkDir).join(', ') : '(không có thư mục)';
    throw new BuildError('NO_APK', 'Gradle chạy xong nhưng không có APK đã ký. Tìm thấy: ' + found, type === 'release' ? 'Bản release chưa được ký: kiểm tra keystore.' : '');
  }
  const apk = fs.readFileSync(apkPath);
  if (apk.length < 1024 || apk[0] !== 0x50 || apk[1] !== 0x4b) throw new BuildError('BAD_APK', 'File đầu ra không phải APK hợp lệ.');

  const sign = await run(tc.apksigner, ['verify', '--print-certs', apkPath], {});
  if (sign.code !== 0) throw new BuildError('SIGNATURE_INVALID', 'apksigner verify thất bại: APK chưa được ký hợp lệ.', 'Kiểm tra cấu hình keystore.');
  const certMatch = /Signer #1 certificate DN: (.+)/.exec(sign.tail);

  const badging = spawnSync(tc.aapt2, ['dump', 'badging', apkPath], { encoding: 'utf8' });
  if (badging.status !== 0) throw new BuildError('BADGING_FAILED', 'aapt2 không đọc được APK.', badging.stderr || '');
  const m = /package: name='([^']+)' versionCode='(\d+)' versionName='([^']*)'/.exec(badging.stdout);
  if (!m) throw new BuildError('BADGING_FAILED', 'Không đọc được thông tin package từ APK.');
  if (m[1] !== config.packageName || Number(m[2]) !== config.versionCode || m[3] !== config.versionName) {
    throw new BuildError('METADATA_MISMATCH', `APK có ${m[1]} ${m[3]} (${m[2]}) không khớp cấu hình.`);
  }
  const sdkM = /sdkVersion:'(\d+)'/.exec(badging.stdout);
  log(`Xác minh: package=${m[1]} versionName=${m[3]} versionCode=${m[2]} minSdk=${sdkM ? sdkM[1] : '?'}`);

  const sha256 = crypto.createHash('sha256').update(apk).digest('hex');
  const fileName = `${Tpl.slugify(config.appName)}-${config.versionName}-${type}.apk`;
  const outDir = path.join(jobDir, 'out');
  fs.mkdirSync(outDir, { recursive: true });
  fs.copyFileSync(apkPath, path.join(outDir, fileName));
  if (!opts.keepProject) fs.rmSync(proj, { recursive: true, force: true });

  const result = {
    fileName,
    size: apk.length,
    sha256,
    packageName: m[1],
    versionName: m[3],
    versionCode: Number(m[2]),
    minSdk: sdkM ? Number(sdkM[1]) : config.minSdk,
    buildType: type,
    signer: type === 'debug' ? 'Android Debug key (chỉ để test)' : (certMatch ? certMatch[1].trim() : 'release key'),
    buildMs: Date.now() - t0,
  };
  out('@@RESULT ' + JSON.stringify(result));
  return result;
}

async function warmup() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'h2a-warmup-'));
  const cfg = Tpl.defaultConfig();
  const zip = Zip.createZip([
    { path: 'config.json', data: JSON.stringify(cfg) },
    { path: 'www/index.html', data: '<!doctype html><title>warmup</title><h1>OK</h1>' },
  ]);
  fs.writeFileSync(path.join(dir, 'bundle.zip'), zip);
  await build(dir, { online: true });
  fs.rmSync(dir, { recursive: true, force: true });
  log('Warmup xong: dependency Gradle đã được cache.');
}

module.exports = { checkToolchain, build };

if (require.main === module) {
  const arg = process.argv[2];
  const p = arg === '--warmup' ? warmup() : build(path.resolve(arg || '.'));
  p.then(() => process.exit(0)).catch((err) => {
    const code = err.code || 'INTERNAL';
    out('@@ERROR ' + JSON.stringify({ code, message: err.message, hint: err.hint || '' }));
    process.exit(2);
  });
}
