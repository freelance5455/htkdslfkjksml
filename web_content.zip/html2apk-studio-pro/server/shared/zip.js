/*!
 * H2AZip: trình đọc/ghi ZIP tối giản, không phụ thuộc thư viện.
 * Chạy được cả trên trình duyệt (window.H2AZip) và Node.js (require).
 *
 * - Ghi: phương thức STORE (không nén) + CRC32, đủ cho gói build/dự án Android.
 * - Đọc: STORE và DEFLATE (giải nén do caller cung cấp qua opts.inflateRaw).
 * - Bảo mật: chặn path traversal (../), đường dẫn tuyệt đối, symlink, file mã hóa,
 *   giới hạn số file / dung lượng từng file / tổng dung lượng (chống zip bomb),
 *   kiểm tra CRC và kích thước sau giải nén.
 */
(function (root) {
  'use strict';

  const CRC_TABLE = (function () {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(u8) {
    let c = 0xffffffff;
    for (let i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  }

  const enc = new TextEncoder();
  const dec = new TextDecoder('utf-8');

  function toU8(data) {
    if (typeof data === 'string') return enc.encode(data);
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    throw new TypeError('Kiểu dữ liệu không hỗ trợ cho ZIP');
  }

  class ZipError extends Error {
    constructor(code, message, hint) {
      super(message);
      this.name = 'ZipError';
      this.code = code;
      this.hint = hint || '';
    }
  }

  /** Chuẩn hóa đường dẫn trong ZIP, ném lỗi nếu nguy hiểm. */
  function sanitizePath(name) {
    if (typeof name !== 'string' || name.length === 0) throw new ZipError('BAD_PATH', 'Tên file rỗng trong ZIP.');
    if (name.indexOf('\0') !== -1) throw new ZipError('BAD_PATH', 'Tên file chứa ký tự NUL: ' + JSON.stringify(name));
    const n = name.replace(/\\/g, '/');
    if (n.startsWith('/') || /^[a-zA-Z]:/.test(n)) {
      throw new ZipError('ABSOLUTE_PATH', 'ZIP chứa đường dẫn tuyệt đối: ' + name, 'Nén lại dự án từ thư mục gốc, không dùng đường dẫn tuyệt đối.');
    }
    const parts = [];
    for (const seg of n.split('/')) {
      if (seg === '' || seg === '.') continue;
      if (seg === '..') {
        throw new ZipError('PATH_TRAVERSAL', 'ZIP chứa đường dẫn vượt thư mục (../): ' + name, 'File ZIP này có thể độc hại hoặc bị nén sai. Nén lại từ thư mục dự án.');
      }
      parts.push(seg);
    }
    if (parts.length === 0) throw new ZipError('BAD_PATH', 'Đường dẫn không hợp lệ: ' + name);
    return parts.join('/') + (n.endsWith('/') ? '/' : '');
  }

  function dosDateTime(d) {
    const time = ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | ((d.getSeconds() / 2) & 31);
    const date = (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31);
    return { time, date };
  }

  /**
   * Tạo ZIP (STORE). entries: [{ path: 'a/b.txt', data: string|Uint8Array, executable?: bool }]
   * Trả về Uint8Array.
   */
  function createZip(entries) {
    if (entries.length > 65000) throw new ZipError('TOO_MANY_FILES', 'Quá nhiều file để đóng gói.');
    const { time, date } = dosDateTime(new Date());
    const chunks = [];
    const central = [];
    let offset = 0;
    const seen = new Set();

    for (const e of entries) {
      const path = sanitizePath(e.path);
      if (seen.has(path)) throw new ZipError('DUPLICATE', 'Trùng đường dẫn: ' + path);
      seen.add(path);
      const name = enc.encode(path);
      const data = toU8(e.data);
      const crc = crc32(data);

      const lh = new Uint8Array(30 + name.length);
      const lv = new DataView(lh.buffer);
      lv.setUint32(0, 0x04034b50, true);
      lv.setUint16(4, 20, true);
      lv.setUint16(6, 0x0800, true); // UTF-8 names
      lv.setUint16(8, 0, true); // STORE
      lv.setUint16(10, time, true);
      lv.setUint16(12, date, true);
      lv.setUint32(14, crc, true);
      lv.setUint32(18, data.length, true);
      lv.setUint32(22, data.length, true);
      lv.setUint16(26, name.length, true);
      lv.setUint16(28, 0, true);
      lh.set(name, 30);
      chunks.push(lh, data);

      const ch = new Uint8Array(46 + name.length);
      const cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true);
      cv.setUint16(4, (3 << 8) | 20, true); // made by: UNIX
      cv.setUint16(6, 20, true);
      cv.setUint16(8, 0x0800, true);
      cv.setUint16(10, 0, true);
      cv.setUint16(12, time, true);
      cv.setUint16(14, date, true);
      cv.setUint32(16, crc, true);
      cv.setUint32(20, data.length, true);
      cv.setUint32(24, data.length, true);
      cv.setUint16(28, name.length, true);
      cv.setUint32(38, (((e.executable ? 0o100755 : 0o100644) << 16) >>> 0), true);
      cv.setUint32(42, offset, true);
      ch.set(name, 46);
      central.push(ch);

      offset += lh.length + data.length;
      if (offset > 0xffffffff) throw new ZipError('TOO_LARGE', 'Gói vượt 4 GB, không hỗ trợ.');
    }

    let cdSize = 0;
    for (const c of central) cdSize += c.length;
    const eocd = new Uint8Array(22);
    const ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true);
    ev.setUint16(8, entries.length, true);
    ev.setUint16(10, entries.length, true);
    ev.setUint32(12, cdSize, true);
    ev.setUint32(16, offset, true);

    const total = offset + cdSize + 22;
    const out = new Uint8Array(total);
    let p = 0;
    for (const c of chunks) { out.set(c, p); p += c.length; }
    for (const c of central) { out.set(c, p); p += c.length; }
    out.set(eocd, p);
    return out;
  }

  const DEFAULT_LIMITS = {
    maxFiles: 3000,
    maxFileBytes: 30 * 1024 * 1024,
    maxTotalBytes: 120 * 1024 * 1024,
  };

  /**
   * Đọc ZIP. opts.inflateRaw(compressed: Uint8Array, expectedSize: number) => Promise<Uint8Array>|Uint8Array
   * Trả về [{ path, data: Uint8Array }] (chỉ file, bỏ thư mục).
   */
  async function readZip(buf, opts) {
    opts = opts || {};
    const limits = Object.assign({}, DEFAULT_LIMITS, opts.limits || {});
    const u8 = toU8(buf);
    if (u8.length < 22) throw new ZipError('NOT_ZIP', 'File quá nhỏ, không phải ZIP hợp lệ.');
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);

    let eocd = -1;
    const stop = Math.max(0, u8.length - 22 - 65535);
    for (let i = u8.length - 22; i >= stop; i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new ZipError('NOT_ZIP', 'Không phải file ZIP hợp lệ.', 'Kiểm tra lại file, hoặc nén lại dự án bằng công cụ nén mặc định của hệ điều hành.');

    const count = dv.getUint16(eocd + 10, true);
    const cdSize = dv.getUint32(eocd + 12, true);
    const cdOff = dv.getUint32(eocd + 16, true);
    if (count === 0xffff || cdOff === 0xffffffff) throw new ZipError('ZIP64', 'ZIP64 chưa được hỗ trợ.', 'Giảm dung lượng dự án hoặc nén lại bằng chế độ ZIP thường.');
    if (cdOff + cdSize > u8.length) throw new ZipError('CORRUPT', 'ZIP bị hỏng (central directory vượt kích thước file).');
    if (count > limits.maxFiles) throw new ZipError('TOO_MANY_FILES', `ZIP có ${count} mục, vượt giới hạn ${limits.maxFiles}.`, 'Xóa node_modules, file build, file thừa trước khi nén.');

    const out = [];
    let total = 0;
    let p = cdOff;
    for (let i = 0; i < count; i++) {
      if (p + 46 > u8.length || dv.getUint32(p, true) !== 0x02014b50) throw new ZipError('CORRUPT', 'ZIP bị hỏng (central directory sai cấu trúc).');
      const madeBy = dv.getUint16(p + 4, true);
      const flags = dv.getUint16(p + 8, true);
      const method = dv.getUint16(p + 10, true);
      const crc = dv.getUint32(p + 16, true);
      const csize = dv.getUint32(p + 20, true);
      const usize = dv.getUint32(p + 24, true);
      const nlen = dv.getUint16(p + 28, true);
      const xlen = dv.getUint16(p + 30, true);
      const clen = dv.getUint16(p + 32, true);
      const ext = dv.getUint32(p + 38, true);
      const loff = dv.getUint32(p + 42, true);
      const rawName = dec.decode(u8.subarray(p + 46, p + 46 + nlen));
      p += 46 + nlen + xlen + clen;

      const isDir = rawName.endsWith('/') || rawName.endsWith('\\');
      const path = sanitizePath(rawName);
      if (flags & 1) throw new ZipError('ENCRYPTED', 'ZIP có file được mã hóa bằng mật khẩu: ' + path, 'Nén lại không đặt mật khẩu.');
      const unixMode = (madeBy >> 8) === 3 ? ext >>> 16 : 0;
      if ((unixMode & 0o170000) === 0o120000) throw new ZipError('SYMLINK', 'ZIP chứa symbolic link: ' + path, 'Thay symlink bằng file thật rồi nén lại.');
      if (isDir) continue;

      if (usize > limits.maxFileBytes) throw new ZipError('FILE_TOO_LARGE', `File ${path} (${usize} byte) vượt giới hạn ${limits.maxFileBytes} byte.`, 'Nén ảnh/video lại hoặc tải chúng từ mạng.');
      total += usize;
      if (total > limits.maxTotalBytes) throw new ZipError('TOTAL_TOO_LARGE', 'Tổng dung lượng sau giải nén vượt giới hạn.', 'Giảm dung lượng tài nguyên.');

      if (loff + 30 > u8.length || dv.getUint32(loff, true) !== 0x04034b50) throw new ZipError('CORRUPT', 'ZIP bị hỏng (local header sai): ' + path);
      const lnlen = dv.getUint16(loff + 26, true);
      const lxlen = dv.getUint16(loff + 28, true);
      const start = loff + 30 + lnlen + lxlen;
      if (start + csize > u8.length) throw new ZipError('CORRUPT', 'ZIP bị cắt cụt: ' + path);
      const comp = u8.subarray(start, start + csize);

      let data;
      if (method === 0) data = comp.slice();
      else if (method === 8) {
        if (typeof opts.inflateRaw !== 'function') throw new ZipError('NO_INFLATE', 'Không có bộ giải nén DEFLATE.');
        try { data = await opts.inflateRaw(comp, usize); }
        catch (err) { throw new ZipError('INFLATE_FAILED', 'Giải nén thất bại cho ' + path + ': ' + (err && err.message ? err.message : err)); }
      } else throw new ZipError('UNSUPPORTED_METHOD', `Phương thức nén ${method} không hỗ trợ (${path}).`, 'Dùng ZIP chuẩn (Deflate hoặc Store).');

      if (data.length !== usize) throw new ZipError('SIZE_MISMATCH', 'Kích thước sau giải nén không khớp: ' + path + ' (nghi zip bomb hoặc file hỏng).');
      if (crc32(data) !== crc) throw new ZipError('CRC_MISMATCH', 'Sai CRC, file hỏng: ' + path);
      out.push({ path, data });
    }
    return out;
  }

  /** Bộ giải nén cho trình duyệt dùng DecompressionStream, dừng nếu vượt kích thước khai báo. */
  async function browserInflateRaw(comp, expected) {
    if (typeof DecompressionStream === 'undefined') throw new Error('Trình duyệt không hỗ trợ DecompressionStream');
    const ds = new DecompressionStream('deflate-raw');
    const writer = ds.writable.getWriter();
    writer.write(comp).catch(function () {});
    writer.close().catch(function () {});
    const reader = ds.readable.getReader();
    const parts = [];
    let size = 0;
    for (;;) {
      const r = await reader.read();
      if (r.done) break;
      size += r.value.length;
      if (size > expected) { reader.cancel().catch(function () {}); throw new Error('dữ liệu giải nén vượt kích thước khai báo'); }
      parts.push(r.value);
    }
    const out = new Uint8Array(size);
    let o = 0;
    for (const part of parts) { out.set(part, o); o += part.length; }
    return out;
  }

  const api = { crc32, createZip, readZip, sanitizePath, browserInflateRaw, ZipError, DEFAULT_LIMITS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.H2AZip = api;
})(typeof self !== 'undefined' ? self : this);
