/*!
 * H2ATemplate: sinh dự án Android (WebView + Android Gradle Plugin) từ cấu hình.
 * Dùng chung cho frontend (xuất Android project) và build worker (build APK thật),
 * nên dự án tải xuống và dự án server build là một.
 *
 * Nội dung web được phục vụ qua androidx.webkit.WebViewAssetLoader tại
 * https://appassets.androidplatform.net/assets/www/ (không bật file:// access).
 */
(function (root) {
  'use strict';

  const TOOLCHAIN = {
    agp: '8.5.2',
    gradle: '8.7',
    compileSdk: 34,
    targetSdk: 34,
    buildTools: '34.0.0',
    webkit: '1.11.0',
  };

  /** Quyền Android cho phép bật. Không quyền nào được bật tự động. */
  const PERMISSIONS = {
    INTERNET: { label: 'Internet', sensitive: false, desc: 'Tải tài nguyên/API từ mạng. Không cần nếu app chạy offline hoàn toàn.' },
    CAMERA: { label: 'Camera', sensitive: true, desc: 'Cho getUserMedia({video}). Hỏi người dùng lúc chạy.' },
    RECORD_AUDIO: { label: 'Micro', sensitive: true, desc: 'Cho getUserMedia({audio}). Hỏi người dùng lúc chạy.' },
    ACCESS_FINE_LOCATION: { label: 'Vị trí chính xác', sensitive: true, desc: 'Cho navigator.geolocation. Hỏi người dùng lúc chạy.' },
    VIBRATE: { label: 'Rung', sensitive: false, desc: 'Cho navigator.vibrate().' },
  };

  /** Phần mở rộng tài nguyên web được đóng gói. File khác bị loại để tránh đóng gói nhầm binary/script hệ thống. */
  const ALLOWED_EXT = [
    'html', 'htm', 'css', 'js', 'mjs', 'json', 'txt', 'md', 'csv', 'xml', 'map', 'wasm', 'webmanifest',
    'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'bmp',
    'woff', 'woff2', 'ttf', 'otf', 'eot',
    'mp3', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'flac', 'mp4', 'webm', 'ogv', 'vtt',
    'glb', 'gltf', 'bin', 'pdf',
  ];

  const DENSITIES = { 'mipmap-mdpi': 48, 'mipmap-hdpi': 72, 'mipmap-xhdpi': 96, 'mipmap-xxhdpi': 144, 'mipmap-xxxhdpi': 192 };

  const JAVA_KEYWORDS = new Set(('abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while true false null var record yield').split(' '));

  function defaultConfig() {
    return {
      appName: 'My Web App',
      packageName: 'com.example.mywebapp',
      versionName: '1.0.0',
      versionCode: 1,
      orientation: 'auto',
      theme: 'system',
      minSdk: 24,
      permissions: [],
      splashColor: '#0B0D12',
      entry: 'index.html',
      buildType: 'debug',
    };
  }

  function extOf(path) {
    const m = /\.([a-z0-9]+)$/i.exec(path);
    return m ? m[1].toLowerCase() : '';
  }

  function isAllowedAsset(path) {
    return ALLOWED_EXT.indexOf(extOf(path)) !== -1;
  }

  /** Kiểm tra cấu hình. Trả về [{field, message}] (rỗng = hợp lệ). */
  function validateConfig(c) {
    const errs = [];
    const add = (field, message) => errs.push({ field, message });
    if (!c || typeof c !== 'object') return [{ field: '*', message: 'Thiếu cấu hình.' }];

    if (typeof c.appName !== 'string' || !c.appName.trim()) add('appName', 'App Name không được để trống.');
    else if (c.appName.length > 50) add('appName', 'App Name tối đa 50 ký tự.');
    else if (/[-\u001f<>]/.test(c.appName)) add('appName', 'App Name không được chứa ký tự điều khiển hoặc < >.');

    if (typeof c.packageName !== 'string' || !/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(c.packageName)) {
      add('packageName', 'Package Name phải dạng com.tencongty.tenapp: chữ thường, số, gạch dưới, ít nhất 2 phần, mỗi phần bắt đầu bằng chữ.');
    } else if (c.packageName.length > 100) add('packageName', 'Package Name quá dài.');
    else {
      const bad = c.packageName.split('.').find((s) => JAVA_KEYWORDS.has(s));
      if (bad) add('packageName', `"${bad}" là từ khóa Java, không dùng làm một phần của Package Name.`);
    }

    if (typeof c.versionName !== 'string' || !/^[0-9A-Za-z][0-9A-Za-z.\-_+]{0,31}$/.test(c.versionName)) add('versionName', 'Version Name dạng 1.0.0 (chữ, số, . - _ +, tối đa 32 ký tự).');
    if (!Number.isInteger(c.versionCode) || c.versionCode < 1 || c.versionCode > 2100000000) add('versionCode', 'Version Code là số nguyên từ 1 đến 2100000000, mỗi bản cập nhật phải tăng.');
    if (['portrait', 'landscape', 'auto'].indexOf(c.orientation) === -1) add('orientation', 'Orientation không hợp lệ.');
    if (['light', 'dark', 'system'].indexOf(c.theme) === -1) add('theme', 'Theme không hợp lệ.');
    if (!Number.isInteger(c.minSdk) || c.minSdk < 21 || c.minSdk > TOOLCHAIN.targetSdk) add('minSdk', `Min SDK từ 21 đến ${TOOLCHAIN.targetSdk}.`);
    if (!Array.isArray(c.permissions) || c.permissions.some((p) => !Object.prototype.hasOwnProperty.call(PERMISSIONS, p))) add('permissions', 'Danh sách quyền có giá trị không hợp lệ.');
    else if (new Set(c.permissions).size !== c.permissions.length) add('permissions', 'Quyền bị trùng.');
    if (typeof c.splashColor !== 'string' || !/^#[0-9A-Fa-f]{6}$/.test(c.splashColor)) add('splashColor', 'Màu splash dạng #RRGGBB.');
    if (typeof c.entry !== 'string' || !/^[A-Za-z0-9_\-./ ]+\.html?$/.test(c.entry) || c.entry.split('/').some((s) => s === '..' || s === '' || s === '.')) add('entry', 'File HTML chính không hợp lệ.');
    if (['debug', 'release'].indexOf(c.buildType) === -1) add('buildType', 'Build type phải là debug hoặc release.');
    return errs;
  }

  function xmlEscape(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /** Escape chuỗi cho res/values/strings.xml (Android thêm luật riêng cho ' " @ ?). */
  function androidString(s) {
    let v = xmlEscape(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/&quot;/g, '\\&quot;');
    if (/^[@?]/.test(v)) v = '\\' + v;
    return v;
  }

  function javaString(s) {
    return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  function gradleString(s) {
    return String(s).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\$/g, '\\$');
  }

  function encodeUrlPath(p) {
    return p.split('/').map(encodeURIComponent).join('/');
  }

  function manifest(c) {
    const perms = c.permissions.slice();
    const lines = [];
    for (const p of perms) {
      lines.push(`    <uses-permission android:name="android.permission.${p}" />`);
      if (p === 'ACCESS_FINE_LOCATION') lines.push('    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />');
      if (p === 'RECORD_AUDIO') lines.push('    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />');
    }
    if (perms.indexOf('CAMERA') !== -1) lines.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
    if (perms.indexOf('ACCESS_FINE_LOCATION') !== -1) lines.push('    <uses-feature android:name="android.hardware.location.gps" android:required="false" />');
    const orient = { portrait: 'portrait', landscape: 'sensorLandscape', auto: 'unspecified' }[c.orientation];
    return `<?xml version="1.0" encoding="utf-8"?>
<!-- Sinh tự động bởi HTML2APK STUDIO PRO. Chỉ khai báo quyền bạn đã chọn. -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
${lines.join('\n')}${lines.length ? '\n' : ''}
    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:usesCleartextTraffic="false"
        android:theme="@style/AppTheme">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="${orient}"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize|keyboardHidden|uiMode">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;
  }

  function mainActivity(c) {
    const has = (p) => (c.permissions.indexOf(p) !== -1 ? 'true' : 'false');
    const startUrl = 'https://appassets.androidplatform.net/assets/www/' + encodeUrlPath(c.entry);
    return `package ${c.packageName};

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Activity duy nhất: hiển thị nội dung web trong assets/www qua WebViewAssetLoader.
 * Sinh tự động bởi HTML2APK STUDIO PRO.
 */
public class MainActivity extends Activity {

    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "${javaString(startUrl)}";

    // Chỉ những quyền được chọn lúc cấu hình mới có thể được cấp cho trang web.
    private static final boolean CAMERA_ENABLED = ${has('CAMERA')};
    private static final boolean MIC_ENABLED = ${has('RECORD_AUDIO')};
    private static final boolean LOCATION_ENABLED = ${has('ACCESS_FINE_LOCATION')};

    private static final int REQ_WEB_PERMISSION = 1001;
    private static final int REQ_GEO_PERMISSION = 1002;

    private WebView webView;
    private PermissionRequest pendingWebRequest;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setGeolocationEnabled(LOCATION_ENABLED);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ASSET_HOST.equals(uri.getHost())) {
                    return false;
                }
                // Link ngoài: mở bằng trình duyệt/app hệ thống thay vì trong WebView.
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    // Không có app nào mở được link này.
                }
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleWebPermission(request);
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                handleGeoPermission(origin, callback);
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }
    }

    private boolean isGranted(String permission) {
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        }
        return true; // Android 5.x: quyền được cấp lúc cài đặt.
    }

    private void handleWebPermission(PermissionRequest request) {
        if (!ASSET_HOST.equals(request.getOrigin().getHost())) {
            request.deny();
            return;
        }
        List<String> androidPerms = new ArrayList<>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && CAMERA_ENABLED) {
                androidPerms.add(Manifest.permission.CAMERA);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && MIC_ENABLED) {
                androidPerms.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (androidPerms.isEmpty()) {
            request.deny();
            return;
        }
        List<String> missing = new ArrayList<>();
        for (String p : androidPerms) {
            if (!isGranted(p)) missing.add(p);
        }
        if (missing.isEmpty()) {
            grantAllowed(request);
            return;
        }
        if (pendingWebRequest != null) {
            pendingWebRequest.deny();
        }
        pendingWebRequest = request;
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(missing.toArray(new String[0]), REQ_WEB_PERMISSION);
        }
    }

    private void grantAllowed(PermissionRequest request) {
        List<String> grant = new ArrayList<>();
        for (String res : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && CAMERA_ENABLED && isGranted(Manifest.permission.CAMERA)) {
                grant.add(res);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && MIC_ENABLED && isGranted(Manifest.permission.RECORD_AUDIO)) {
                grant.add(res);
            }
        }
        if (grant.isEmpty()) {
            request.deny();
        } else {
            request.grant(grant.toArray(new String[0]));
        }
    }

    private void handleGeoPermission(String origin, GeolocationPermissions.Callback callback) {
        if (!LOCATION_ENABLED) {
            callback.invoke(origin, false, false);
            return;
        }
        if (isGranted(Manifest.permission.ACCESS_FINE_LOCATION)) {
            callback.invoke(origin, true, false);
            return;
        }
        pendingGeoOrigin = origin;
        pendingGeoCallback = callback;
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GEO_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_WEB_PERMISSION && pendingWebRequest != null) {
            grantAllowed(pendingWebRequest);
            pendingWebRequest = null;
        } else if (requestCode == REQ_GEO_PERMISSION && pendingGeoCallback != null) {
            boolean ok = isGranted(Manifest.permission.ACCESS_FINE_LOCATION) || isGranted(Manifest.permission.ACCESS_COARSE_LOCATION);
            pendingGeoCallback.invoke(pendingGeoOrigin, ok, false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
`;
  }

  function themeXml(parent, c) {
    return `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="${parent}">
        <item name="android:windowBackground">@drawable/splash</item>
        <item name="android:statusBarColor">@color/splash_bg</item>
        <item name="android:navigationBarColor">@color/splash_bg</item>
    </style>
</resources>
`;
  }

  function readme(c) {
    return `# ${c.appName} (Android project)

Sinh bởi HTML2APK STUDIO PRO. Đây là MÃ NGUỒN Android, chưa phải APK.
Package: ${c.packageName} · Version ${c.versionName} (${c.versionCode}) · minSdk ${c.minSdk} · targetSdk ${TOOLCHAIN.targetSdk}

Nội dung web: app/src/main/assets/www/ (trang chính: ${c.entry})

## Cách 1: GitHub Actions (không cần cài gì)
1. Tạo repo GitHub mới, đẩy toàn bộ thư mục này lên (giữ nguyên .github/).
2. Vào tab Actions, chạy workflow "Build APK" (tự chạy khi push).
3. Tải APK trong mục Artifacts của lần chạy.

## Cách 2: Android Studio
1. File > Open, chọn thư mục này.
2. Nếu được hỏi Gradle, chọn dùng gradle-wrapper.properties (Gradle ${TOOLCHAIN.gradle}).
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
APK debug nằm ở app/build/outputs/apk/debug/app-debug.apk

## Cách 3: Dòng lệnh (đã có JDK 17, Android SDK 34, Gradle ${TOOLCHAIN.gradle})
    export ANDROID_HOME=/duong/dan/android-sdk
    gradle assembleDebug

## Bản release (ký bằng khóa của bạn)
Đặt biến môi trường rồi chạy \`gradle assembleRelease\`:
H2A_KEYSTORE, H2A_KEYSTORE_PASSWORD, H2A_KEY_ALIAS, H2A_KEY_PASSWORD
Không commit keystore hay mật khẩu vào repo.
`;
  }

  function workflow() {
    return `name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 30
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - uses: android-actions/setup-android@v3
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '${TOOLCHAIN.gradle}'
      - name: Build debug APK
        run: gradle assembleDebug --no-daemon --console=plain
      - uses: actions/upload-artifact@v4
        with:
          name: apk-debug
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
`;
  }

  /**
   * Sinh file dự án Android (chỉ file text). Tài nguyên web và icon PNG do caller thêm:
   *   app/src/main/assets/www/<...>
   *   app/src/main/res/mipmap-<density>/ic_launcher.png và ic_launcher_round.png
   * Trả về [{ path, data }].
   */
  function generateAndroidProject(c) {
    const errs = validateConfig(c);
    if (errs.length) {
      const e = new Error('Cấu hình không hợp lệ: ' + errs.map((x) => x.message).join(' '));
      e.code = 'INVALID_CONFIG';
      e.details = errs;
      throw e;
    }
    const pkgPath = c.packageName.replace(/\./g, '/');
    const files = [];
    const add = (path, data) => files.push({ path, data });

    add('settings.gradle', `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = 'WebApp'
include ':app'
`);
    add('build.gradle', `plugins {
    id 'com.android.application' version '${TOOLCHAIN.agp}' apply false
}
`);
    add('gradle.properties', `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
`);
    add('gradle/wrapper/gradle-wrapper.properties', `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-${TOOLCHAIN.gradle}-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);
    add('.gitignore', `.gradle/
build/
app/build/
local.properties
*.keystore
*.jks
.idea/
`);
    add('app/build.gradle', `plugins {
    id 'com.android.application'
}

android {
    namespace '${gradleString(c.packageName)}'
    compileSdk ${TOOLCHAIN.compileSdk}

    defaultConfig {
        applicationId '${gradleString(c.packageName)}'
        minSdk ${c.minSdk}
        targetSdk ${TOOLCHAIN.targetSdk}
        versionCode ${c.versionCode}
        versionName '${gradleString(c.versionName)}'
    }

    // Khóa ký release đọc từ biến môi trường của máy build, KHÔNG nằm trong mã nguồn.
    def ks = System.getenv('H2A_KEYSTORE')
    signingConfigs {
        release {
            if (ks) {
                storeFile file(ks)
                storePassword System.getenv('H2A_KEYSTORE_PASSWORD')
                keyAlias System.getenv('H2A_KEY_ALIAS')
                keyPassword System.getenv('H2A_KEY_PASSWORD')
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled false
            if (ks) {
                signingConfig signingConfigs.release
            }
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    androidResources {
        // Không bỏ qua file bắt đầu bằng "_" hoặc thư mục ẩn hợp lệ của web app.
        ignoreAssetsPattern '!.svn:!.git:!.ds_store:!*.scc:!CVS:!thumbs.db:!picasa.ini:!*~'
    }
}

dependencies {
    implementation 'androidx.webkit:webkit:${TOOLCHAIN.webkit}'
}
`);
    add('app/proguard-rules.pro', '# Không bật minify cho WebView wrapper.\n');
    add('app/src/main/AndroidManifest.xml', manifest(c));
    add(`app/src/main/java/${pkgPath}/MainActivity.java`, mainActivity(c));
    add('app/src/main/res/values/strings.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${androidString(c.appName)}</string>
</resources>
`);
    add('app/src/main/res/values/colors.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="splash_bg">${c.splashColor.toUpperCase()}</color>
</resources>
`);
    add('app/src/main/res/drawable/splash.xml', `<?xml version="1.0" encoding="utf-8"?>
<!-- Màn hình chờ: nền màu + icon ở giữa, hiển thị tới khi WebView vẽ xong. -->
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@color/splash_bg" />
    <item android:gravity="center">
        <bitmap android:gravity="center" android:src="@mipmap/ic_launcher" />
    </item>
</layer-list>
`);
    const light = 'android:Theme.Material.Light.NoActionBar';
    const dark = 'android:Theme.Material.NoActionBar';
    if (c.theme === 'light') add('app/src/main/res/values/themes.xml', themeXml(light, c));
    else if (c.theme === 'dark') add('app/src/main/res/values/themes.xml', themeXml(dark, c));
    else {
      add('app/src/main/res/values/themes.xml', themeXml(light, c));
      add('app/src/main/res/values-night/themes.xml', themeXml(dark, c));
    }
    add('.github/workflows/build-apk.yml', workflow());
    add('README.md', readme(c));
    add('h2a-config.json', JSON.stringify(c, null, 2) + '\n');
    return files;
  }

  function slugify(s) {
    return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/gi, 'd').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'app';
  }

  function suggestPackageName(appName) {
    let s = slugify(appName).replace(/-/g, '');
    if (!/^[a-z]/.test(s)) s = 'app' + s;
    if (JAVA_KEYWORDS.has(s)) s = s + 'app';
    return 'com.example.' + s.slice(0, 40);
  }

  const api = { TOOLCHAIN, PERMISSIONS, ALLOWED_EXT, DENSITIES, defaultConfig, validateConfig, generateAndroidProject, isAllowedAsset, extOf, slugify, suggestPackageName, xmlEscape, androidString };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.H2ATemplate = api;
})(typeof self !== 'undefined' ? self : this);
