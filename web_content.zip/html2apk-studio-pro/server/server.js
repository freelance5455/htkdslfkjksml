#!/usr/bin/env node
/**
 * HTML2APK STUDIO PRO: API server (Node.js >= 18, không cần npm install).
 *
 * API
 *   GET    /api/health                   Trạng thái server + toolchain + giới hạn
 *   POST   /api/builds                   Body: application/zip (gói từ frontend) -> { id }
 *   GET    /api/builds/:id?since=N       Trạng thái, stage, log từ dòng N, kết quả
 *   GET    /api/builds/:id/apk           Tải APK (chỉ khi build thành công và file tồn tại)
 *   HEAD   /api/builds/:id/apk           Kiểm tra file tồn tại + dung lượng
 *   DELETE /api/builds/:id               Hủy (nếu đang chạy) và xóa mọi file của build
 *   POST   /api/builds/:id/clickup       { taskId } -> comment kết quả vào ClickUp Task (nếu server có token)
 *   GET    /                             Phục vụ frontend (public/index.html)
 *
 * Biến môi trường: xem README.md.
 */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { checkToolchain } = require('./worker.js');

const CFG = {
  port: Number(process.env.PORT || 8787),
  host: process.env.HOST || '0.0.0.0',
  dataDir: path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data')),
  maxUploadBytes: Number(process.env.MAX_UPLOAD_MB || 40) * 1024 * 1024,
  buildTimeoutMs: Number(process.env.BUILD_TIMEOUT_SEC || 900) * 1000,
  concurrency: Math.max(1, Number(process.env.BUILD_CONCURRENCY || 1)),
  maxQueue: Number(process.env.MAX_QUEUE || 20),
  ttlMs: Number(process.env.RETENTION_HOURS || 24) * 3600 * 1000,
  apiKey: process.env.BUILD_API_KEY || '',
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim()).filter(Boolean),
  rateLimitPerHour: Number(process.env.RATE_LIMIT_PER_HOUR || 30),
  clickupToken: process.env.CLICKUP_API_TOKEN || '',
  publicBaseUrl: (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, ''),
};

const JOBS_DIR = path.join(CFG.dataDir, 'jobs');
fs.mkdirSync(JOBS_DIR, { recursive: true });

/** @type {Map<string, any>} */
const jobs = new Map();
const queue = [];
const running = new Map(); // id -> child process
const MAX_LOG_LINES = 4000;

// ---------- Lưu trạng thái job ----------

function jobDir(id) { return path.join(JOBS_DIR, id); }

function persist(job) {
  const { logs, ...meta } = job;
  fs.writeFileSync(path.join(jobDir(job.id), 'job.json'), JSON.stringify(meta));
  fs.writeFileSync(path.join(jobDir(job.id), 'build.log'), logs.join('\n'));
}

function loadJobs() {
  for (const id of fs.readdirSync(JOBS_DIR)) {
    try {
      const meta = JSON.parse(fs.readFileSync(path.join(jobDir(id), 'job.json'), 'utf8'));
      const logFile = path.join(jobDir(id), 'build.log');
      meta.logs = fs.existsSync(logFile) ? fs.readFileSync(logFile, 'utf8').split('\n') : [];
      meta.logOffset = meta.logOffset || 0;
      if (meta.status === 'queued' || meta.status === 'running') {
        meta.status = 'failed';
        meta.error = { code: 'SERVER_RESTARTED', message: 'Server khởi động lại khi build đang chạy.', hint: 'Bấm Build lại.' };
        meta.finishedAt = Date.now();
      }
      jobs.set(id, meta);
    } catch (e) {
      fs.rmSync(jobDir(id), { recursive: true, force: true });
    }
  }
}

function addLog(job, line) {
  job.logs.push(line);
  if (job.logs.length > MAX_LOG_LINES) {
    const drop = job.logs.length - MAX_LOG_LINES;
    job.logs.splice(0, drop);
    job.logOffset += drop;
  }
}

function publicJob(job, since) {
  const from = Math.max(0, (Number(since) || 0) - job.logOffset);
  return {
    id: job.id,
    status: job.status, // queued | running | success | failed | canceled
    stage: job.stage, // waiting | preparing | compiling | packaging | verifying | done
    stageTimes: job.stageTimes,
    createdAt: job.createdAt,
    startedAt: job.startedAt || null,
    finishedAt: job.finishedAt || null,
    durationMs: job.startedAt ? (job.finishedAt || Date.now()) - job.startedAt : null,
    queuePosition: job.status === 'queued' ? queue.indexOf(job.id) + 1 : 0,
    error: job.error || null,
    result: job.result || null,
    logs: job.logs.slice(from),
    nextLogIndex: job.logOffset + job.logs.length,
    logTruncated: job.logOffset > 0 && (Number(since) || 0) < job.logOffset,
  };
}

// ---------- Hàng đợi build ----------

function pump() {
  while (running.size < CFG.concurrency && queue.length) {
    const id = queue.shift();
    const job = jobs.get(id);
    if (job && job.status === 'queued') startJob(job);
  }
}

function setStage(job, s) {
  job.stage = s;
  job.stageTimes[s] = Date.now();
}

function startJob(job) {
  job.status = 'running';
  job.startedAt = Date.now();
  setStage(job, 'preparing');
  addLog(job, `[server] Bắt đầu build ${job.id}`);

  const child = spawn(process.execPath, [path.join(__dirname, 'worker.js'), jobDir(job.id)], {
    cwd: __dirname,
    env: process.env,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  running.set(job.id, child);
  let buf = '';
  const onData = (chunk) => {
    buf += chunk.toString('utf8');
    let idx;
    while ((idx = buf.indexOf('\n')) !== -1) {
      const line = buf.slice(0, idx).replace(/\r$/, '');
      buf = buf.slice(idx + 1);
      if (line.startsWith('@@STAGE ')) { setStage(job, line.slice(8).trim()); addLog(job, `[stage] ${job.stage}`); }
      else if (line.startsWith('@@RESULT ')) { try { job.result = JSON.parse(line.slice(9)); } catch (e) { /* bỏ qua */ } }
      else if (line.startsWith('@@ERROR ')) { try { job.error = JSON.parse(line.slice(8)); } catch (e) { job.error = { code: 'INTERNAL', message: line }; } }
      else addLog(job, line);
    }
  };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);

  const timer = setTimeout(() => {
    addLog(job, `[server] Quá thời gian ${CFG.buildTimeoutMs / 1000}s, dừng build.`);
    job.error = { code: 'TIMEOUT', message: 'Build vượt quá thời gian cho phép.', hint: 'Giảm dung lượng dự án hoặc tăng BUILD_TIMEOUT_SEC.' };
    child.kill('SIGKILL');
  }, CFG.buildTimeoutMs);

  child.on('close', (code) => {
    clearTimeout(timer);
    running.delete(job.id);
    job.finishedAt = Date.now();
    if (job.status === 'canceled') { /* đã xử lý ở DELETE */ }
    else if (code === 0 && job.result && fs.existsSync(path.join(jobDir(job.id), 'out', job.result.fileName))) {
      job.status = 'success';
      setStage(job, 'done');
      addLog(job, `[server] Build thành công: ${job.result.fileName} (${job.result.size} byte)`);
    } else {
      job.status = 'failed';
      if (!job.error) job.error = { code: 'WORKER_EXIT', message: `Worker kết thúc với mã ${code}.`, hint: 'Xem log.' };
      if (code === 0 && !job.error) job.error = { code: 'NO_OUTPUT', message: 'Worker báo xong nhưng không thấy APK.' };
      addLog(job, `[server] Build thất bại: ${job.error.message}`);
    }
    fs.rmSync(path.join(jobDir(job.id), 'bundle.zip'), { force: true });
    if (fs.existsSync(jobDir(job.id))) persist(job);
    pump();
  });
}

// ---------- HTTP helpers ----------

function corsHeaders(req) {
  const origin = req.headers.origin;
  const h = { Vary: 'Origin' };
  if (CFG.allowedOrigins.includes('*')) h['Access-Control-Allow-Origin'] = '*';
  else if (origin && CFG.allowedOrigins.includes(origin)) h['Access-Control-Allow-Origin'] = origin;
  h['Access-Control-Allow-Methods'] = 'GET, POST, DELETE, HEAD, OPTIONS';
  h['Access-Control-Allow-Headers'] = 'Authorization, Content-Type';
  h['Access-Control-Expose-Headers'] = 'Content-Length, Content-Disposition, X-APK-SHA256';
  h['Access-Control-Max-Age'] = '600';
  return h;
}

const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
};

function send(req, res, status, body, extra) {
  const isJson = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
  const data = isJson ? JSON.stringify(body) : body;
  res.writeHead(status, Object.assign({}, SEC_HEADERS, corsHeaders(req), isJson ? { 'Content-Type': 'application/json; charset=utf-8' } : {}, extra || {}));
  res.end(req.method === 'HEAD' ? undefined : data);
}

function fail(req, res, status, code, message, hint) {
  send(req, res, status, { error: { code, message, hint: hint || '' } });
}

function authorized(req) {
  if (!CFG.apiKey) return true;
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  const a = Buffer.from(token);
  const b = Buffer.from(CFG.apiKey);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const hits = new Map();
function rateLimited(req) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < 3600e3);
  if (arr.length >= CFG.rateLimitPerHour) { hits.set(ip, arr); return true; }
  arr.push(now);
  hits.set(ip, arr);
  return false;
}

function readJson(req, max) {
  return new Promise((resolve, reject) => {
    let size = 0; const parts = [];
    req.on('data', (c) => { size += c.length; if (size > max) { reject(new Error('too large')); req.destroy(); } else parts.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(parts).toString('utf8') || '{}')); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

// ---------- Route handlers ----------

async function createBuild(req, res) {
  if (rateLimited(req)) return fail(req, res, 429, 'RATE_LIMITED', 'Quá nhiều lượt build từ địa chỉ này.', 'Thử lại sau ít phút.');
  const ct = (req.headers['content-type'] || '').split(';')[0].trim();
  if (ct !== 'application/zip') return fail(req, res, 415, 'BAD_CONTENT_TYPE', 'Body phải là application/zip.');
  const len = Number(req.headers['content-length'] || 0);
  if (len > CFG.maxUploadBytes) return fail(req, res, 413, 'TOO_LARGE', `Gói vượt ${CFG.maxUploadBytes / 1048576} MB.`, 'Giảm dung lượng ảnh/video.');
  const waiting = [...jobs.values()].filter((j) => j.status === 'queued').length;
  if (waiting >= CFG.maxQueue) return fail(req, res, 503, 'QUEUE_FULL', 'Hàng đợi build đang đầy.', 'Thử lại sau.');

  const id = crypto.randomUUID();
  const dir = jobDir(id);
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, 'bundle.zip');
  const ws = fs.createWriteStream(file);
  let size = 0;
  let aborted = false;
  req.on('data', (c) => {
    size += c.length;
    if (size > CFG.maxUploadBytes && !aborted) {
      aborted = true;
      ws.destroy();
      fs.rmSync(dir, { recursive: true, force: true });
      fail(req, res, 413, 'TOO_LARGE', 'Gói vượt giới hạn dung lượng.');
      req.destroy();
    }
  });
  req.pipe(ws);
  ws.on('finish', () => {
    if (aborted) return;
    if (size < 22) { fs.rmSync(dir, { recursive: true, force: true }); return fail(req, res, 400, 'EMPTY', 'Gói rỗng.'); }
    const job = { id, status: 'queued', stage: 'waiting', stageTimes: { waiting: Date.now() }, createdAt: Date.now(), logs: [], logOffset: 0, uploadBytes: size };
    jobs.set(id, job);
    addLog(job, `[server] Nhận gói ${size} byte, vào hàng đợi.`);
    persist(job);
    queue.push(id);
    pump();
    send(req, res, 201, { id, status: job.status });
  });
}

function apkPathFor(job) {
  if (!job || job.status !== 'success' || !job.result) return null;
  const p = path.join(jobDir(job.id), 'out', job.result.fileName);
  return fs.existsSync(p) ? p : null;
}

function serveApk(req, res, job) {
  const p = apkPathFor(job);
  if (!p) return fail(req, res, 404, 'NO_APK', 'Không có APK cho build này (chưa thành công hoặc đã hết hạn lưu trữ).');
  const stat = fs.statSync(p);
  res.writeHead(200, Object.assign({}, SEC_HEADERS, corsHeaders(req), {
    'Content-Type': 'application/vnd.android.package-archive',
    'Content-Length': stat.size,
    'Content-Disposition': `attachment; filename="${job.result.fileName}"`,
    'X-APK-SHA256': job.result.sha256,
  }));
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(p).pipe(res);
}

function deleteJob(req, res, job) {
  const child = running.get(job.id);
  if (child) { job.status = 'canceled'; child.kill('SIGKILL'); }
  const qi = queue.indexOf(job.id);
  if (qi !== -1) queue.splice(qi, 1);
  jobs.delete(job.id);
  fs.rmSync(jobDir(job.id), { recursive: true, force: true });
  send(req, res, 200, { deleted: job.id });
}

async function postToClickUp(req, res, job) {
  if (!CFG.clickupToken) return fail(req, res, 501, 'CLICKUP_DISABLED', 'Server chưa cấu hình CLICKUP_API_TOKEN.', 'Đặt token ở biến môi trường của server, không bao giờ ở frontend.');
  let body;
  try { body = await readJson(req, 4096); } catch (e) { return fail(req, res, 400, 'BAD_JSON', 'Body JSON không hợp lệ.'); }
  const taskId = String(body.taskId || '').trim();
  if (!/^[A-Za-z0-9_-]{4,40}$/.test(taskId)) return fail(req, res, 400, 'BAD_TASK_ID', 'Task ID không hợp lệ.');
  const r = job.result;
  const lines = job.status === 'success'
    ? [`✅ HTML2APK build thành công: ${r.fileName}`, `Package: ${r.packageName} · ${r.versionName} (${r.versionCode}) · ${(r.size / 1048576).toFixed(2)} MB`, `SHA-256: ${r.sha256}`]
    : [`❌ HTML2APK build thất bại: ${job.error ? job.error.message : job.status}`];
  if (job.status === 'success' && CFG.publicBaseUrl) lines.push(`Tải APK: ${CFG.publicBaseUrl}/api/builds/${job.id}/apk`);
  try {
    const resp = await fetch(`https://api.clickup.com/api/v2/task/${encodeURIComponent(taskId)}/comment`, {
      method: 'POST',
      headers: { Authorization: CFG.clickupToken, 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment_text: lines.join('\n'), notify_all: false }),
    });
    if (!resp.ok) return fail(req, res, 502, 'CLICKUP_ERROR', `ClickUp trả về ${resp.status}.`, 'Kiểm tra Task ID và quyền của token.');
    send(req, res, 200, { ok: true });
  } catch (e) {
    fail(req, res, 502, 'CLICKUP_UNREACHABLE', 'Không kết nối được ClickUp API.');
  }
}

function health(req, res) {
  const tc = checkToolchain();
  send(req, res, 200, {
    ok: true,
    service: 'html2apk-studio-pro',
    version: '1.0.0',
    canBuild: tc.ready,
    toolchain: { ready: tc.ready, missing: tc.missing, androidSdk: !!tc.sdk, platform: tc.platform, gradle: !!tc.gradle, javac: !!tc.javac, apksigner: !!tc.apksigner, aapt2: !!tc.aapt2 },
    releaseSigning: !!process.env.H2A_KEYSTORE,
    authRequired: !!CFG.apiKey,
    clickup: !!CFG.clickupToken,
    limits: { maxUploadMB: CFG.maxUploadBytes / 1048576, buildTimeoutSec: CFG.buildTimeoutMs / 1000, retentionHours: CFG.ttlMs / 3600e3 },
    queue: { running: running.size, waiting: queue.length, concurrency: CFG.concurrency },
  });
}

function serveFrontend(req, res) {
  const p = path.join(__dirname, 'public', 'index.html');
  if (!fs.existsSync(p)) return fail(req, res, 404, 'NO_FRONTEND', 'Chưa có public/index.html.');
  send(req, res, 200, fs.readFileSync(p), { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    const parts = url.pathname.split('/').filter(Boolean);
    if (req.method === 'OPTIONS') return send(req, res, 204, '');
    if ((req.method === 'GET' || req.method === 'HEAD') && (url.pathname === '/' || url.pathname === '/index.html')) return serveFrontend(req, res);
    if (parts[0] !== 'api') return fail(req, res, 404, 'NOT_FOUND', 'Không tìm thấy.');
    if (parts[1] === 'health' && req.method === 'GET') return health(req, res);
    if (!authorized(req)) return fail(req, res, 401, 'UNAUTHORIZED', 'Thiếu hoặc sai API key.', 'Nhập API key ở phần Build Server.');
    if (parts[1] !== 'builds') return fail(req, res, 404, 'NOT_FOUND', 'Không tìm thấy.');
    if (parts.length === 2 && req.method === 'POST') return createBuild(req, res);

    const id = parts[2];
    if (!id || !/^[0-9a-f-]{36}$/.test(id)) return fail(req, res, 400, 'BAD_ID', 'Build ID không hợp lệ.');
    const job = jobs.get(id);
    if (!job) return fail(req, res, 404, 'NO_BUILD', 'Không tìm thấy build (có thể đã bị xóa hoặc hết hạn).');
    if (parts.length === 3 && req.method === 'GET') return send(req, res, 200, publicJob(job, url.searchParams.get('since')));
    if (parts.length === 3 && req.method === 'DELETE') return deleteJob(req, res, job);
    if (parts[3] === 'apk' && (req.method === 'GET' || req.method === 'HEAD')) return serveApk(req, res, job);
    if (parts[3] === 'clickup' && req.method === 'POST') return postToClickUp(req, res, job);
    fail(req, res, 405, 'METHOD_NOT_ALLOWED', 'Phương thức không hỗ trợ.');
  } catch (err) {
    console.error(err);
    if (!res.headersSent) fail(req, res, 500, 'INTERNAL', 'Lỗi server.');
  }
});

// Dọn build hết hạn
setInterval(() => {
  const now = Date.now();
  for (const job of jobs.values()) {
    if (job.finishedAt && now - job.finishedAt > CFG.ttlMs) {
      jobs.delete(job.id);
      fs.rmSync(jobDir(job.id), { recursive: true, force: true });
    }
  }
}, 10 * 60 * 1000).unref();

loadJobs();
server.listen(CFG.port, CFG.host, () => {
  const tc = checkToolchain();
  console.log(`HTML2APK API: http://${CFG.host}:${CFG.port}  (toolchain ${tc.ready ? 'sẵn sàng' : 'THIẾU: ' + tc.missing.join(', ')})`);
  if (CFG.allowedOrigins.includes('*')) console.log('Cảnh báo: ALLOWED_ORIGINS=* (chỉ nên dùng khi dev).');
});
