import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  ReceiptText,
  PieChart,
  HandCoins,
  PiggyBank,
  BarChart3,
  Settings as SettingsIcon,
  Plus,
  Lock,
  Download,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  WifiOff,
} from 'lucide-react';
import {
  Transaction,
  Budget,
  Debt,
  DebtRepayment,
  SavingsGoal,
  SavingsContribution,
  Category,
  AppSettings,
  TransactionType,
  DebtType,
} from './types';
import { db, DEFAULT_SETTINGS } from './db/indexedDB';
import { getCurrentMonthKey } from './utils/currency';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { usePWAInstall } from './hooks/usePWAInstall';

// Views
import { DashboardView } from './components/DashboardView';
import { TransactionsView } from './components/TransactionsView';
import { BudgetView } from './components/BudgetView';
import { UdhaarView } from './components/UdhaarView';
import { SavingsView } from './components/SavingsView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';

// Modals
import { TransactionModal } from './components/TransactionModal';
import { DebtModal } from './components/DebtModal';
import { RepaymentModal } from './components/RepaymentModal';
import { BudgetModal } from './components/BudgetModal';
import { SavingsGoalModal } from './components/SavingsGoalModal';
import { SavingsContributionModal } from './components/SavingsContributionModal';
import { AndroidExportModal } from './components/AndroidExportModal';
import { SelfTestModal } from './components/SelfTestModal';
import { PinLockScreen } from './components/PinLockScreen';

export default function App() {
  const isOnline = useOnlineStatus();
  const { isInstallable, install } = usePWAInstall();

  // Navigation state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [activeMonth, setActiveMonth] = useState<string>(getCurrentMonthKey());

  // Database records
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [debtRepayments, setDebtRepayments] = useState<DebtRepayment[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);
  const [savingsContributions, setSavingsContributions] = useState<SavingsContribution[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isDataLoaded, setIsDataLoaded] = useState<boolean>(false);

  // Security & Lock State
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [pinModalMode, setPinModalMode] = useState<'unlock' | 'setup' | 'change' | null>(null);

  // Modals state
  const [isTxModalOpen, setIsTxModalOpen] = useState<boolean>(false);
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [defaultTxType, setDefaultTxType] = useState<TransactionType>('expense');

  const [isDebtModalOpen, setIsDebtModalOpen] = useState<boolean>(false);
  const [selectedDebt, setSelectedDebt] = useState<Debt | null>(null);
  const [defaultDebtType, setDefaultDebtType] = useState<DebtType>('lent');

  const [isRepaymentModalOpen, setIsRepaymentModalOpen] = useState<boolean>(false);
  const [repaymentDebt, setRepaymentDebt] = useState<Debt | null>(null);

  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState<boolean>(false);
  const [selectedBudget, setSelectedBudget] = useState<Budget | null>(null);

  const [isGoalModalOpen, setIsGoalModalOpen] = useState<boolean>(false);
  const [selectedGoal, setSelectedGoal] = useState<SavingsGoal | null>(null);

  const [isContribModalOpen, setIsContribModalOpen] = useState<boolean>(false);
  const [contribGoal, setContribGoal] = useState<SavingsGoal | null>(null);

  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);
  const [isSelfTestModalOpen, setIsSelfTestModalOpen] = useState<boolean>(false);

  // Success Feedback Toast
  const [toastMsg, setToastMsg] = useState<string>('');

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(''), 3000);
  };

  // Fetch all database records
  const loadAllData = useCallback(async () => {
    try {
      const [txs, bgs, dbs, dreps, sgoals, scontribs, cats, appSet] = await Promise.all([
        db.getTransactions(),
        db.getBudgets(),
        db.getDebts(),
        db.getAll<DebtRepayment>('debt_repayments'),
        db.getSavingsGoals(),
        db.getAll<SavingsContribution>('savings_contributions'),
        db.getCategories(),
        db.getSettings(),
      ]);

      setTransactions(txs);
      setBudgets(bgs);
      setDebts(dbs);
      setDebtRepayments(dreps);
      setSavingsGoals(sgoals);
      setSavingsContributions(scontribs);
      setCategories(cats);
      setSettings(appSet);

      if (appSet.activeMonth) {
        setActiveMonth(appSet.activeMonth);
      }

      // Check PIN lock on boot
      if (appSet.pinEnabled && appSet.pinHash) {
        setIsLocked(true);
        setPinModalMode('unlock');
      }

      setIsDataLoaded(true);
    } catch (err) {
      console.error('Failed to load local IndexedDB data:', err);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Inactivity & Visibility Auto-Lock
  useEffect(() => {
    if (!settings.pinEnabled || !settings.pinHash) return;

    let timeoutId: NodeJS.Timeout;

    const resetTimer = () => {
      if (settings.autoLockMinutes > 0) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          setIsLocked(true);
          setPinModalMode('unlock');
        }, settings.autoLockMinutes * 60 * 1000);
      }
    };

    const handleVisibility = () => {
      if (document.hidden) {
        if (settings.autoLockMinutes === 0) {
          setIsLocked(true);
          setPinModalMode('unlock');
        }
      } else {
        resetTimer();
      }
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keydown', resetTimer);
    window.addEventListener('touchstart', resetTimer);
    document.addEventListener('visibilitychange', handleVisibility);

    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      window.removeEventListener('touchstart', resetTimer);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [settings.pinEnabled, settings.pinHash, settings.autoLockMinutes]);

  // Transaction Handlers
  const handleSaveTransaction = async (
    item: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
  ) => {
    await db.saveTransaction(item);
    await loadAllData();
    showToast(item.id ? 'Transaction updated successfully.' : 'New transaction recorded.');
  };

  const handleDeleteTransaction = async (id: string) => {
    await db.deleteTransaction(id);
    await loadAllData();
    showToast('Transaction removed.');
  };

  // Category Handler
  const handleAddCategory = async (cat: Omit<Category, 'id'>) => {
    const created = await db.saveCategory(cat);
    await loadAllData();
    showToast(`Category "${created.name}" created.`);
    return created;
  };

  // Udhaar Handlers
  const handleSaveDebt = async (
    item: Omit<Debt, 'id' | 'createdAt' | 'updatedAt' | 'repaidAmountPaisa' | 'status'> & {
      id?: string;
    }
  ) => {
    await db.saveDebt(item);
    await loadAllData();
    showToast('Udhaar debt record saved.');
  };

  const handleDeleteDebt = async (id: string) => {
    await db.deleteDebt(id);
    await loadAllData();
    showToast('Debt record deleted.');
  };

  const handleSaveRepayment = async (repayment: {
    debtId: string;
    amountPaisa: number;
    date: string;
    paymentMethod: any;
    note?: string;
  }) => {
    await db.addDebtRepayment(repayment);
    await loadAllData();
    showToast('Repayment recorded and remaining balance updated.');
  };

  const handleDeleteRepayment = async (repaymentId: string, debtId: string) => {
    await db.deleteDebtRepayment(repaymentId, debtId);
    await loadAllData();
    showToast('Repayment deleted.');
  };

  // Budget Handlers
  const handleSaveBudget = async (
    item: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
  ) => {
    await db.saveBudget(item);
    await loadAllData();
    showToast('Monthly budget updated.');
  };

  const handleDeleteBudget = async (id: string) => {
    await db.deleteBudget(id);
    await loadAllData();
    showToast('Budget deleted.');
  };

  // Savings Handlers
  const handleSaveGoal = async (
    goal: Omit<SavingsGoal, 'id' | 'createdAt' | 'updatedAt' | 'savedAmountPaisa' | 'isCompleted'> & {
      id?: string;
    }
  ) => {
    await db.saveSavingsGoal(goal);
    await loadAllData();
    showToast('Savings target saved.');
  };

  const handleDeleteGoal = async (id: string) => {
    await db.deleteSavingsGoal(id);
    await loadAllData();
    showToast('Savings goal deleted.');
  };

  const handleSaveContribution = async (contrib: {
    goalId: string;
    type: 'deposit' | 'withdrawal';
    amountPaisa: number;
    date: string;
    note?: string;
  }) => {
    await db.addSavingsContribution(contrib);
    await loadAllData();
    showToast(contrib.type === 'deposit' ? 'Savings deposited!' : 'Funds withdrawn.');
  };

  // Settings Handlers
  const handleUpdateSettings = async (patch: Partial<AppSettings>) => {
    const updated = await db.updateSettings(patch);
    setSettings(updated);
    showToast('Settings saved.');
  };

  const handleLoadDemoData = async () => {
    await db.loadRealisticDemoData();
    await loadAllData();
    showToast('Loaded realistic Pakistani financial records.');
  };

  const handleClearAllData = async () => {
    await db.clearAllData();
    await loadAllData();
    showToast('All records wiped.');
  };

  if (!isDataLoaded) {
    return (
      <div className="min-h-screen bg-[#0B110E] flex flex-col items-center justify-center text-center p-4">
        <div className="w-16 h-16 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 animate-pulse">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h2 className="text-lg font-bold text-white tracking-tight">Pocket Hisab Pro</h2>
        <p className="text-xs text-gray-400 mt-1">Initializing offline IndexedDB storage...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B110E] text-white flex flex-col font-sans">
      {/* Offline Status Badge */}
      {!isOnline && (
        <div className="bg-amber-600/90 text-white text-[11px] font-semibold py-1 px-4 text-center flex items-center justify-center gap-1.5 sticky top-0 z-50">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Airplane / Offline Mode active — Working safely from local IndexedDB</span>
        </div>
      )}

      {/* Top App Bar (Ergonomic 3-Zone Top Bar Contract) */}
      <header className="sticky top-0 z-30 bg-[#0B110E]/90 backdrop-blur-md border-b border-[#1E2E23] px-4 sm:px-8 py-3.5 flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center shadow-md shadow-emerald-900/30">
            <span className="text-white font-black text-base">₨</span>
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight leading-none">
              Pocket Hisab Pro
            </h1>
            <span className="text-[10px] text-emerald-400 font-medium">Offline Personal Ledger</span>
          </div>
        </div>

        {/* Zone 2: Navigation Links on Desktop (Tablet/Laptop) */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold text-gray-400">
          {[
            { id: 'dashboard', label: 'Dashboard' },
            { id: 'transactions', label: 'Transactions' },
            { id: 'budget', label: 'Monthly Budget' },
            { id: 'udhaar', label: 'Udhaar Manager' },
            { id: 'savings', label: 'Savings Goals' },
            { id: 'reports', label: 'Analytics' },
            { id: 'settings', label: 'Settings' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`hover:text-white transition-colors cursor-pointer ${
                activeTab === tab.id ? 'text-emerald-400 border-b-2 border-emerald-400 pb-0.5' : ''
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2">
          {/* PWA Install Button if available */}
          {isInstallable && (
            <button
              onClick={install}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install App</span>
            </button>
          )}

          {/* Android APK Exporter Button */}
          <button
            onClick={() => setIsAndroidModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142018] hover:bg-[#1C2C22] border border-[#233527] text-gray-200 text-xs font-semibold transition-colors cursor-pointer"
            title="Android APK & Project"
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Android APK</span>
          </button>

          {/* Fast Lock Screen Trigger if PIN enabled */}
          {settings.pinEnabled && (
            <button
              onClick={() => {
                setIsLocked(true);
                setPinModalMode('unlock');
              }}
              className="p-2 rounded-xl bg-[#142018] hover:bg-[#1C2C22] border border-[#233527] text-gray-300 hover:text-white transition-colors"
              title="Lock Application Now"
            >
              <Lock className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 md:p-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            activeMonth={activeMonth}
            setActiveMonth={(m) => {
              setActiveMonth(m);
              handleUpdateSettings({ activeMonth: m });
            }}
            transactions={transactions}
            budgets={budgets}
            debts={debts}
            categories={categories}
            onOpenAddTransaction={(t) => {
              setDefaultTxType(t || 'expense');
              setSelectedTx(null);
              setIsTxModalOpen(true);
            }}
            onOpenAddUdhaar={() => {
              setDefaultDebtType('lent');
              setSelectedDebt(null);
              setIsDebtModalOpen(true);
            }}
            onSelectTransaction={(tx) => {
              setSelectedTx(tx);
              setIsTxModalOpen(true);
            }}
            onNavigateToTab={(tab) => setActiveTab(tab)}
            onLoadDemoData={handleLoadDemoData}
          />
        )}

        {activeTab === 'transactions' && (
          <TransactionsView
            transactions={transactions}
            categories={categories}
            activeMonth={activeMonth}
            onEditTransaction={(tx) => {
              setSelectedTx(tx);
              setIsTxModalOpen(true);
            }}
            onDeleteTransaction={handleDeleteTransaction}
            onOpenAddTransaction={(t) => {
              setDefaultTxType(t || 'expense');
              setSelectedTx(null);
              setIsTxModalOpen(true);
            }}
          />
        )}

        {activeTab === 'budget' && (
          <BudgetView
            activeMonth={activeMonth}
            setActiveMonth={(m) => {
              setActiveMonth(m);
              handleUpdateSettings({ activeMonth: m });
            }}
            budgets={budgets}
            transactions={transactions}
            categories={categories}
            onOpenBudgetModal={(b) => {
              setSelectedBudget(b || null);
              setIsBudgetModalOpen(true);
            }}
            onDeleteBudget={handleDeleteBudget}
          />
        )}

        {activeTab === 'udhaar' && (
          <UdhaarView
            debts={debts}
            debtRepayments={debtRepayments}
            onOpenAddDebt={(t) => {
              setDefaultDebtType(t || 'lent');
              setSelectedDebt(null);
              setIsDebtModalOpen(true);
            }}
            onEditDebt={(d) => {
              setSelectedDebt(d);
              setIsDebtModalOpen(true);
            }}
            onDeleteDebt={handleDeleteDebt}
            onOpenRepaymentModal={(d) => {
              setRepaymentDebt(d);
              setIsRepaymentModalOpen(true);
            }}
            onDeleteRepayment={handleDeleteRepayment}
          />
        )}

        {activeTab === 'savings' && (
          <SavingsView
            goals={savingsGoals}
            contributions={savingsContributions}
            onOpenCreateGoal={() => {
              setSelectedGoal(null);
              setIsGoalModalOpen(true);
            }}
            onEditGoal={(g) => {
              setSelectedGoal(g);
              setIsGoalModalOpen(true);
            }}
            onDeleteGoal={handleDeleteGoal}
            onOpenContributionModal={(g) => {
              setContribGoal(g);
              setIsContribModalOpen(true);
            }}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            transactions={transactions}
            categories={categories}
            activeMonth={activeMonth}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onTriggerPinSetup={() => setPinModalMode('setup')}
            onTriggerPinChange={() => setPinModalMode('change')}
            onOpenAndroidExport={() => setIsAndroidModalOpen(true)}
            onOpenSelfTest={() => setIsSelfTestModalOpen(true)}
            onLoadDemoData={handleLoadDemoData}
            onClearAllData={handleClearAllData}
            onRefreshAllData={loadAllData}
          />
        )}
      </main>

      {/* Floating Action Button (FAB) for Instant Transaction Entry */}
      <button
        onClick={() => {
          setDefaultTxType('expense');
          setSelectedTx(null);
          setIsTxModalOpen(true);
        }}
        className="fixed bottom-20 right-5 sm:bottom-8 sm:right-8 z-40 w-14 h-14 rounded-2xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white flex items-center justify-center shadow-xl shadow-emerald-500/30 transition-all cursor-pointer group"
        title="Add Transaction"
      >
        <Plus className="w-7 h-7 group-hover:rotate-90 transition-transform duration-200" />
      </button>

      {/* Mobile Bottom Tab Bar (Navigation Anchor with Thumb Zone Ergonomics) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0F1713]/95 backdrop-blur-lg border-t border-[#1E2E23] pb-safe">
        <div className="grid grid-cols-5 items-center h-16">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center h-full transition-colors ${
              activeTab === 'dashboard' ? 'text-emerald-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight mt-1">Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex flex-col items-center justify-center h-full transition-colors ${
              activeTab === 'transactions' ? 'text-emerald-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <ReceiptText className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight mt-1">Hisab</span>
          </button>

          <button
            onClick={() => setActiveTab('budget')}
            className={`flex flex-col items-center justify-center h-full transition-colors ${
              activeTab === 'budget' ? 'text-emerald-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <PieChart className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight mt-1">Budget</span>
          </button>

          <button
            onClick={() => setActiveTab('udhaar')}
            className={`flex flex-col items-center justify-center h-full transition-colors ${
              activeTab === 'udhaar' ? 'text-emerald-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <HandCoins className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight mt-1">Udhaar</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex flex-col items-center justify-center h-full transition-colors ${
              activeTab === 'settings' ? 'text-emerald-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <SettingsIcon className="w-5 h-5" />
            <span className="text-[10px] font-medium tracking-tight mt-1">More</span>
          </button>
        </div>
      </nav>

      {/* Floating Success Toast */}
      {toastMsg && (
        <div className="fixed bottom-24 sm:bottom-10 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-[#17271E] border border-emerald-500/40 text-emerald-300 px-4 py-2.5 rounded-2xl shadow-xl text-xs font-semibold animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* PIN Lock Screen Modal (if locked or setting up PIN) */}
      {isLocked && pinModalMode && (
        <PinLockScreen
          mode={pinModalMode}
          settings={settings}
          onSuccess={(newHash, newSalt) => {
            if (pinModalMode === 'unlock') {
              setIsLocked(false);
              setPinModalMode(null);
            } else if (newHash && newSalt) {
              handleUpdateSettings({
                pinEnabled: true,
                pinHash: newHash,
                pinSalt: newSalt,
              });
              setIsLocked(false);
              setPinModalMode(null);
              showToast('Security PIN successfully saved.');
            }
          }}
          onCancel={
            pinModalMode !== 'unlock'
              ? () => {
                  setPinModalMode(null);
                }
              : undefined
          }
        />
      )}

      {/* Transaction Modal */}
      <TransactionModal
        isOpen={isTxModalOpen}
        onClose={() => setIsTxModalOpen(false)}
        onSave={handleSaveTransaction}
        initialTransaction={selectedTx}
        categories={categories}
        onAddCategory={handleAddCategory}
        defaultType={defaultTxType}
      />

      {/* Debt Modal */}
      <DebtModal
        isOpen={isDebtModalOpen}
        onClose={() => setIsDebtModalOpen(false)}
        onSave={handleSaveDebt}
        initialDebt={selectedDebt}
        defaultType={defaultDebtType}
      />

      {/* Repayment Modal */}
      <RepaymentModal
        isOpen={isRepaymentModalOpen}
        onClose={() => {
          setIsRepaymentModalOpen(false);
          setRepaymentDebt(null);
        }}
        debt={repaymentDebt}
        onSave={handleSaveRepayment}
      />

      {/* Budget Modal */}
      <BudgetModal
        isOpen={isBudgetModalOpen}
        onClose={() => {
          setIsBudgetModalOpen(false);
          setSelectedBudget(null);
        }}
        onSave={handleSaveBudget}
        initialBudget={selectedBudget}
        activeMonth={activeMonth}
        categories={categories}
      />

      {/* Savings Goal Modal */}
      <SavingsGoalModal
        isOpen={isGoalModalOpen}
        onClose={() => {
          setIsGoalModalOpen(false);
          setSelectedGoal(null);
        }}
        onSave={handleSaveGoal}
        initialGoal={selectedGoal}
      />

      {/* Savings Contribution Modal */}
      <SavingsContributionModal
        isOpen={isContribModalOpen}
        onClose={() => {
          setIsContribModalOpen(false);
          setContribGoal(null);
        }}
        goal={contribGoal}
        onSave={handleSaveContribution}
      />

      {/* Android Export & Kotlin Project Modal */}
      <AndroidExportModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      {/* Self-Test & Automated Verification Modal */}
      <SelfTestModal
        isOpen={isSelfTestModalOpen}
        onClose={() => setIsSelfTestModalOpen(false)}
        onRefreshParent={loadAllData}
      />
    </div>
  );
}
