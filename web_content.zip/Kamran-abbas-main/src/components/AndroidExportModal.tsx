import React, { useState } from 'react';
import { X, Smartphone, Download, Copy, Check, Terminal, ExternalLink, ShieldCheck, Code, Layers } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface AndroidExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidExportModal: React.FC<AndroidExportModalProps> = ({ isOpen, onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'pwa' | 'capacitor' | 'native_compose'>('pwa');
  const { isInstallable, install } = usePWAInstall();

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const capacitorCommands = `# 1. Install Capacitor dependencies
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor project
npx cap init "Pocket Hisab Pro" com.pockethisab.pro --web-dir dist

# 3. Build optimized offline production web bundle
npm run build

# 4. Add native Android platform
npx cap add android

# 5. Sync and launch in Android Studio to generate release/debug APK
npx cap sync
npx cap open android
# Inside Android Studio: Click Build -> Build Bundle(s) / APK(s) -> Build APK(s)`;

  const kotlinRoomDatabase = `package com.pockethisab.pro.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.pockethisab.pro.data.local.dao.*
import com.pockethisab.pro.data.local.entity.*

@Database(
    entities = [
        TransactionEntity::class,
        BudgetEntity::class,
        DebtEntity::class,
        DebtRepaymentEntity::class,
        SavingsGoalEntity::class,
        CategoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PocketHisabDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun budgetDao(): BudgetDao
    abstract fun debtDao(): DebtDao
    abstract fun savingsGoalDao(): SavingsGoalDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        const val DATABASE_NAME = "pocket_hisab_pro.db"
    }
}`;

  const kotlinTransactionEntity = `package com.pockethisab.pro.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey
    val id: String,
    val type: String, // "income" or "expense"
    val amountPaisa: Long, // Integer paisa: 100 Paisa = 1 PKR
    val category: String,
    val paymentMethod: String, // "cash", "bank", "other"
    val date: String, // YYYY-MM-DD
    val time: String? = null,
    val note: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)`;

  const kotlinTransactionDao = `package com.pockethisab.pro.data.local.dao

import androidx.room.*
import com.pockethisab.pro.data.local.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY date DESC, createdAt DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE date LIKE :monthPrefix || '%' ORDER BY date DESC")
    fun getTransactionsByMonth(monthPrefix: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("SELECT SUM(amountPaisa) FROM transactions WHERE type = 'income' AND date LIKE :month || '%'")
    suspend fun getTotalIncomeByMonth(month: String): Long?

    @Query("SELECT SUM(amountPaisa) FROM transactions WHERE type = 'expense' AND date LIKE :month || '%'")
    suspend fun getTotalExpenseByMonth(month: String): Long?
}`;

  const buildGradleKts = `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.kapt)
}

android {
    namespace = "com.pockethisab.pro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pockethisab.pro"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)

    // Room Database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    kapt(libs.androidx.room.compiler)
}`;

  const downloadAllAndroidFiles = () => {
    const combinedSource = `// POCKET HISAB PRO - NATIVE ANDROID JETPACK COMPOSE & ROOM DB PACKAGE
// Application ID: com.pockethisab.pro
// Currency: Pakistani Rupees (PKR / Rs.) with Integer Paisa

==================================================
1. build.gradle.kts
==================================================
${buildGradleKts}

==================================================
2. PocketHisabDatabase.kt
==================================================
${kotlinRoomDatabase}

==================================================
3. TransactionEntity.kt
==================================================
${kotlinTransactionEntity}

==================================================
4. TransactionDao.kt
==================================================
${kotlinTransactionDao}
`;
    const blob = new Blob([combinedSource], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'PocketHisabPro_Android_Kotlin_Room_Source.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl bg-[#0F1713] border border-[#233527] rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-4 px-6 pb-4 border-b border-[#1E2E23] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Android APK & Native Deployment
              </h3>
              <p className="text-xs text-gray-400">
                Package ID: <code className="text-emerald-400">com.pockethisab.pro</code>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Runtime Status Notice */}
        <div className="bg-[#142018] border-b border-[#1E2E23] px-6 py-3">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <p className="text-xs text-gray-300 leading-relaxed">
              <strong className="text-emerald-400 font-semibold">Offline-First Architecture: </strong>
              The web app currently runs with persistent IndexedDB storage. You can install it
              directly onto your Android phone as a standalone PWA, or compile the native APK using
              the provided Kotlin Room project or Capacitor CLI.
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-3 p-2 bg-[#121D16] border-b border-[#1E2E23] gap-1">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'pwa'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Install on Android (PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('capacitor')}
            className={`py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'capacitor'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Capacitor APK Build</span>
          </button>
          <button
            onClick={() => setActiveTab('native_compose')}
            className={`py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'native_compose'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Kotlin & Room Code</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#142018] border border-[#233527]">
                <h4 className="text-sm font-semibold text-white mb-1">
                  Direct Android Home-Screen Installation
                </h4>
                <p className="text-xs text-gray-400 leading-relaxed mb-4">
                  Pocket Hisab Pro is configured with an offline Service Worker and Android Web App
                  Manifest. It runs completely offline without an internet connection in fullscreen
                  standalone mode.
                </p>

                {isInstallable ? (
                  <button
                    onClick={install}
                    className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install Pocket Hisab Pro to Android Home Screen</span>
                  </button>
                ) : (
                  <div className="p-3 rounded-xl bg-[#1A2920] border border-[#2A4031] text-xs text-emerald-300">
                    <strong>How to install on Android Chrome:</strong>
                    <ol className="list-decimal ml-4 mt-1.5 space-y-1 text-gray-300">
                      <li>Tap the 3 dots menu (⋮) in Chrome at top right.</li>
                      <li>Select <strong>Add to Home Screen</strong> or <strong>Install App</strong>.</li>
                      <li>Tap <strong>Install</strong>. Pocket Hisab Pro will appear in your app launcher!</li>
                    </ol>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs text-gray-400">
                <div className="p-3 rounded-xl bg-[#142018] border border-[#233527]">
                  <strong className="text-gray-200 block mb-1">✓ Offline-Ready</strong>
                  All transactions and balances persist in IndexedDB without cellular data.
                </div>
                <div className="p-3 rounded-xl bg-[#142018] border border-[#233527]">
                  <strong className="text-gray-200 block mb-1">✓ Edge-to-Edge</strong>
                  Optimized for Android gesture navigation and dark mode displays.
                </div>
              </div>
            </div>
          )}

          {activeTab === 'capacitor' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-gray-300 uppercase tracking-wider">
                  Generate .apk with Capacitor
                </h4>
                <button
                  onClick={() => copyToClipboard(capacitorCommands, 'cap')}
                  className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-medium"
                >
                  {copiedKey === 'cap' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'cap' ? 'Copied' : 'Copy Commands'}</span>
                </button>
              </div>

              <div className="relative rounded-2xl bg-[#090E0B] border border-[#1E2E23] p-4 font-mono text-xs text-emerald-300 overflow-x-auto leading-relaxed">
                <pre>{capacitorCommands}</pre>
              </div>

              <p className="text-xs text-gray-400">
                Running these commands turns the web codebase into an official release/debug{' '}
                <code className="text-emerald-400">.apk</code> or <code className="text-emerald-400">.aab</code>{' '}
                ready for side-loading or Google Play Store release.
              </p>
            </div>
          )}

          {activeTab === 'native_compose' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-semibold text-gray-300 uppercase tracking-wider">
                    Kotlin Jetpack Compose + Room Database
                  </h4>
                  <p className="text-[11px] text-gray-400">
                    Native architecture matching all Room entities & DAOs.
                  </p>
                </div>
                <button
                  onClick={downloadAllAndroidFiles}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Kotlin Code</span>
                </button>
              </div>

              {/* Code Snippet Box */}
              <div className="space-y-3">
                <div>
                  <span className="text-[11px] font-semibold text-emerald-400 block mb-1">
                    PocketHisabDatabase.kt (Room)
                  </span>
                  <div className="rounded-xl bg-[#090E0B] border border-[#1E2E23] p-3 font-mono text-[11px] text-gray-300 max-h-36 overflow-y-auto">
                    <pre>{kotlinRoomDatabase}</pre>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-semibold text-emerald-400 block mb-1">
                    TransactionEntity.kt (Entity with Long Paisa)
                  </span>
                  <div className="rounded-xl bg-[#090E0B] border border-[#1E2E23] p-3 font-mono text-[11px] text-gray-300 max-h-36 overflow-y-auto">
                    <pre>{kotlinTransactionEntity}</pre>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-semibold text-emerald-400 block mb-1">
                    TransactionDao.kt (Flow & Kotlin Coroutines)
                  </span>
                  <div className="rounded-xl bg-[#090E0B] border border-[#1E2E23] p-3 font-mono text-[11px] text-gray-300 max-h-36 overflow-y-auto">
                    <pre>{kotlinTransactionDao}</pre>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#1E2E23] bg-[#0C140F] flex items-center justify-between">
          <span className="text-[11px] text-gray-400">
            Pocket Hisab Pro v1.0.0 · com.pockethisab.pro
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-[#16231A] hover:bg-[#1E2E23] border border-[#233527] text-white text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
