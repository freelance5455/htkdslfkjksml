import React, { useState, useEffect } from 'react';
import { X, Calendar, User, Phone, FileText, Check } from 'lucide-react';
import { Debt, DebtType } from '../types';
import { parseRupeesToPaisa, paisaToRupees } from '../utils/currency';

interface DebtModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (debt: Omit<Debt, 'id' | 'createdAt' | 'updatedAt' | 'repaidAmountPaisa' | 'status'> & { id?: string }) => Promise<void>;
  initialDebt?: Debt | null;
  defaultType?: DebtType;
}

export const DebtModal: React.FC<DebtModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialDebt,
  defaultType = 'lent',
}) => {
  const [type, setType] = useState<DebtType>(defaultType);
  const [personName, setPersonName] = useState<string>('');
  const [contactNumber, setContactNumber] = useState<string>('');
  const [amountInput, setAmountInput] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [dueDate, setDueDate] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (initialDebt) {
        setType(initialDebt.type);
        setPersonName(initialDebt.personName);
        setContactNumber(initialDebt.contactNumber || '');
        setAmountInput(paisaToRupees(initialDebt.originalAmountPaisa).toString());
        setDate(initialDebt.date);
        setDueDate(initialDebt.dueDate || '');
        setNotes(initialDebt.notes || '');
      } else {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const d = String(now.getDate()).padStart(2, '0');

        setType(defaultType);
        setPersonName('');
        setContactNumber('');
        setAmountInput('');
        setDate(`${y}-${m}-${d}`);
        setDueDate('');
        setNotes('');
      }
      setError('');
    }
  }, [isOpen, initialDebt, defaultType]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!personName.trim()) {
      setError("Please enter the person's name.");
      return;
    }

    const paisa = parseRupeesToPaisa(amountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid amount greater than 0.');
      return;
    }

    if (!date) {
      setError('Please select the date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        id: initialDebt ? initialDebt.id : undefined,
        personName: personName.trim(),
        contactNumber: contactNumber.trim() || undefined,
        type,
        originalAmountPaisa: paisa,
        date,
        dueDate: dueDate.trim() || undefined,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save debt record.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white tracking-tight">
              {initialDebt ? 'Edit Udhaar Record' : 'New Udhaar / Debt Entry'}
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Segmented Type Toggle */}
          <div className="grid grid-cols-2 p-1 bg-[#16231A] rounded-xl mt-3 border border-[#233527]">
            <button
              type="button"
              onClick={() => setType('lent')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                type === 'lent'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Money I Lent (Receivable)
            </button>
            <button
              type="button"
              onClick={() => setType('borrowed')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                type === 'borrowed'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Money I Borrowed (Payable)
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Person Name */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center gap-1">
              <User className="w-3.5 h-3.5" /> Person or Party Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Tariq Bhai, Hamza Khan, Shopkeeper..."
              value={personName}
              onChange={(e) => setPersonName(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Phone / Contact */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5" /> Phone Number (Optional)
            </label>
            <input
              type="tel"
              placeholder="0300-1234567"
              value={contactNumber}
              onChange={(e) => setContactNumber(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Original Amount (Rs. / PKR) *
            </label>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="0"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Date & Due Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Date Given / Taken *
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" /> Expected Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" /> Notes / Agreement Details
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Promised to return after 1st salary, split repair bill..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500 resize-none"
            />
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{initialDebt ? 'Update Record' : 'Save Udhaar Record'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
