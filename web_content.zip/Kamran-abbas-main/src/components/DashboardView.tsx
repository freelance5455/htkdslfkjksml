import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronLeft,
  ChevronRight,
  HandCoins,
  PiggyBank,
  Sparkles,
} from 'lucide-react';
import { Transaction, Budget, Debt, Category } from '../types';
import {
  formatPKR,
  formatMonthName,
  shiftMonthKey,
  formatDisplayDate,
} from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface DashboardViewProps {
  activeMonth: string;
  setActiveMonth: (month: string) => void;
  transactions: Transaction[];
  budgets: Budget[];
  debts: Debt[];
  categories: Category[];
  onOpenAddTransaction: (type?: 'income' | 'expense') => void;
  onOpenAddUdhaar: () => void;
  onSelectTransaction: (tx: Transaction) => void;
  onNavigateToTab: (tab: string) => void;
  onLoadDemoData: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  activeMonth,
  setActiveMonth,
  transactions,
  budgets,
  debts,
  categories,
  onOpenAddTransaction,
  onOpenAddUdhaar,
  onSelectTransaction,
  onNavigateToTab,
  onLoadDemoData,
}) => {
  // Filter transactions for current month
  const monthTransactions = transactions.filter((t) => t.date.startsWith(activeMonth));

  // Financial calculations in Paisa
  const totalIncomePaisa = monthTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const totalExpensePaisa = monthTransactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const netSavingsPaisa = totalIncomePaisa - totalExpensePaisa;

  // Overall lifetime balance
  const lifetimeIncomePaisa = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const lifetimeExpensePaisa = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const availableBalancePaisa = lifetimeIncomePaisa - lifetimeExpensePaisa;

  // Monthly Budget calculations
  const totalBudget = budgets.find((b) => b.month === activeMonth && b.category === '_total_');
  const budgetLimitPaisa = totalBudget ? totalBudget.amountPaisa : 0;
  const budgetPercentUsed =
    budgetLimitPaisa > 0 ? Math.round((totalExpensePaisa / budgetLimitPaisa) * 100) : 0;
  const remainingBudgetPaisa = Math.max(0, budgetLimitPaisa - totalExpensePaisa);

  // Category breakdown
  const categoryExpenses: Record<string, number> = {};
  monthTransactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categoryExpenses[t.category] = (categoryExpenses[t.category] || 0) + t.amountPaisa;
    });

  const sortedCategories = Object.entries(categoryExpenses)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5);

  // Daily Spending Trend for Chart (Current Month Days 1..31)
  const daysInMonth = 31;
  const dailySpending: number[] = new Array(daysInMonth).fill(0);
  monthTransactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      const day = parseInt(t.date.split('-')[2], 10);
      if (day >= 1 && day <= daysInMonth) {
        dailySpending[day - 1] += t.amountPaisa;
      }
    });

  const maxDailySpend = Math.max(...dailySpending, 1);

  // Udhaar overview
  const totalLentOwedPaisa = debts
    .filter((d) => d.type === 'lent' && d.status !== 'settled')
    .reduce((sum, d) => sum + (d.originalAmountPaisa - d.repaidAmountPaisa), 0);

  const totalBorrowedOwedPaisa = debts
    .filter((d) => d.type === 'borrowed' && d.status !== 'settled')
    .reduce((sum, d) => sum + (d.originalAmountPaisa - d.repaidAmountPaisa), 0);

  const recentTransactions = transactions.slice(0, 6);

  return (
    <div className="space-y-6 pb-12">
      {/* Month Navigation Strip */}
      <div className="flex items-center justify-between bg-[#142018] border border-[#233527] rounded-2xl px-4 py-2.5">
        <button
          onClick={() => setActiveMonth(shiftMonthKey(activeMonth, -1))}
          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
          title="Previous Month"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <span className="text-sm font-bold text-white tracking-tight">
            {formatMonthName(activeMonth)}
          </span>
          <span className="text-[10px] text-emerald-400 block font-medium">Monthly Ledger</span>
        </div>

        <button
          onClick={() => setActiveMonth(shiftMonthKey(activeMonth, 1))}
          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
          title="Next Month"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Main Balance Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#064E3B] via-[#047857] to-[#022C22] p-6 text-white shadow-xl shadow-emerald-950/30 border border-emerald-500/30">
        {/* Subtle decorative shield glow */}
        <div className="absolute top-0 right-0 -mt-6 -mr-6 w-44 h-44 rounded-full bg-emerald-400/10 blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-emerald-200 tracking-wider uppercase flex items-center gap-1.5">
            <Wallet className="w-3.5 h-3.5" /> Total Available Balance
          </span>
          <span className="text-[11px] font-mono text-emerald-200 bg-emerald-900/40 px-2 py-0.5 rounded-md border border-emerald-500/20">
            Offline Secured
          </span>
        </div>

        <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums text-white my-1">
          {formatPKR(availableBalancePaisa)}
        </div>

        <div className="grid grid-cols-3 gap-2 mt-6 pt-4 border-t border-emerald-500/20">
          <div>
            <span className="text-[10px] text-emerald-200 block font-medium">Month Income</span>
            <span className="text-xs sm:text-sm font-bold text-white tabular-nums">
              {formatPKR(totalIncomePaisa)}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-emerald-200 block font-medium">Month Expenses</span>
            <span className="text-xs sm:text-sm font-bold text-white tabular-nums">
              {formatPKR(totalExpensePaisa)}
            </span>
          </div>
          <div>
            <span className="text-[10px] text-emerald-200 block font-medium">Net Cashflow</span>
            <span
              className={`text-xs sm:text-sm font-bold tabular-nums ${
                netSavingsPaisa >= 0 ? 'text-emerald-200' : 'text-rose-300'
              }`}
            >
              {formatPKR(netSavingsPaisa, 'Rs.', 'prefix', { includeSign: true })}
            </span>
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => onOpenAddTransaction('expense')}
          className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] border border-[#233527] transition-all cursor-pointer active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-950/60 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-2 group-hover:scale-105 transition-transform">
            <ArrowUpRight className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-white">Add Expense</span>
          <span className="text-[10px] text-gray-500">Kharcha</span>
        </button>

        <button
          onClick={() => onOpenAddTransaction('income')}
          className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] border border-[#233527] transition-all cursor-pointer active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-2 group-hover:scale-105 transition-transform">
            <ArrowDownLeft className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-white">Add Income</span>
          <span className="text-[10px] text-gray-500">Aamdani</span>
        </button>

        <button
          onClick={onOpenAddUdhaar}
          className="flex flex-col items-center justify-center p-3.5 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] border border-[#233527] transition-all cursor-pointer active:scale-95 group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-950/60 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-2 group-hover:scale-105 transition-transform">
            <HandCoins className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-white">Add Udhaar</span>
          <span className="text-[10px] text-gray-500">Debt Entry</span>
        </button>
      </div>

      {/* Monthly Budget Progress Card */}
      {budgetLimitPaisa > 0 ? (
        <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white">Monthly Expense Budget</span>
              {budgetPercentUsed >= 100 ? (
                <span className="text-[10px] font-semibold text-rose-400 bg-rose-950/60 border border-rose-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> Exceeded!
                </span>
              ) : budgetPercentUsed >= 80 ? (
                <span className="text-[10px] font-semibold text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> 80% Warning
                </span>
              ) : null}
            </div>
            <button
              onClick={() => onNavigateToTab('budget')}
              className="text-[11px] text-emerald-400 hover:underline font-medium"
            >
              Manage
            </button>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-[#0E1611] rounded-full h-3 overflow-hidden p-0.5 border border-[#233527]">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetPercentUsed >= 100
                  ? 'bg-rose-500'
                  : budgetPercentUsed >= 80
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(budgetPercentUsed, 100)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs tabular-nums text-gray-400 pt-1">
            <span>
              Spent: <strong className="text-white">{formatPKR(totalExpensePaisa)}</strong> (
              {budgetPercentUsed}%)
            </span>
            <span>
              Remaining: <strong className="text-emerald-400">{formatPKR(remainingBudgetPaisa)}</strong>
            </span>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-2xl bg-[#142018] border border-[#233527] flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-white">No Monthly Budget Set</h4>
            <p className="text-[11px] text-gray-400">
              Set a monthly limit to receive 80% warning and over-budget alerts.
            </p>
          </div>
          <button
            onClick={() => onNavigateToTab('budget')}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Set Budget
          </button>
        </div>
      )}

      {/* Udhaar Quick Snapshot */}
      {(totalLentOwedPaisa > 0 || totalBorrowedOwedPaisa > 0) && (
        <div className="grid grid-cols-2 gap-3">
          <div
            onClick={() => onNavigateToTab('udhaar')}
            className="p-4 rounded-2xl bg-[#142018] border border-[#233527] cursor-pointer hover:border-emerald-500/40 transition-colors"
          >
            <span className="text-[10px] text-emerald-400 uppercase font-semibold tracking-wider block">
              Mujhe Milna Hai (Lent)
            </span>
            <span className="text-lg font-bold text-white tabular-nums block mt-1">
              {formatPKR(totalLentOwedPaisa)}
            </span>
            <span className="text-[10px] text-gray-400">Total Money Owed to Me</span>
          </div>

          <div
            onClick={() => onNavigateToTab('udhaar')}
            className="p-4 rounded-2xl bg-[#142018] border border-[#233527] cursor-pointer hover:border-amber-500/40 transition-colors"
          >
            <span className="text-[10px] text-amber-400 uppercase font-semibold tracking-wider block">
              Maine Dena Hai (Borrowed)
            </span>
            <span className="text-lg font-bold text-white tabular-nums block mt-1">
              {formatPKR(totalBorrowedOwedPaisa)}
            </span>
            <span className="text-[10px] text-gray-400">Total Money I Owe</span>
          </div>
        </div>
      )}

      {/* Spending Trend Bar Chart (Daily Spending for Active Month) */}
      {totalExpensePaisa > 0 && (
        <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527]">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">Daily Spending Trend</h3>
              <p className="text-[10px] text-gray-400">Daily expenses for {formatMonthName(activeMonth)}</p>
            </div>
            <span className="text-xs font-bold text-rose-400 tabular-nums">
              Total: {formatPKR(totalExpensePaisa)}
            </span>
          </div>

          {/* Bar Chart Slices */}
          <div className="h-28 flex items-end gap-1 pt-4 pb-1">
            {dailySpending.map((amount, idx) => {
              const heightPercent = maxDailySpend > 0 ? (amount / maxDailySpend) * 100 : 0;
              const hasSpend = amount > 0;
              return (
                <div
                  key={idx}
                  className="flex-1 flex flex-col items-center group relative h-full justify-end"
                >
                  {/* Tooltip on hover */}
                  {hasSpend && (
                    <div className="absolute bottom-full mb-1 hidden group-hover:flex flex-col items-center z-20 pointer-events-none">
                      <div className="bg-black/90 text-[10px] text-white px-2 py-1 rounded border border-gray-700 whitespace-nowrap tabular-nums">
                        Day {idx + 1}: {formatPKR(amount)}
                      </div>
                    </div>
                  )}
                  <div
                    className={`w-full rounded-t transition-all ${
                      hasSpend
                        ? 'bg-emerald-500 group-hover:bg-emerald-400'
                        : 'bg-[#1C2C22] opacity-40'
                    }`}
                    style={{ height: `${Math.max(heightPercent, hasSpend ? 12 : 4)}%` }}
                  />
                  {(idx + 1 === 1 || (idx + 1) % 5 === 0) && (
                    <span className="text-[9px] text-gray-500 mt-1">{idx + 1}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Category Breakdown (Top Expenses) */}
      {sortedCategories.length > 0 && (
        <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white tracking-tight">Top Expense Categories</h3>
            <button
              onClick={() => onNavigateToTab('reports')}
              className="text-[11px] text-emerald-400 hover:underline font-medium"
            >
              Full Analytics
            </button>
          </div>

          <div className="space-y-3">
            {sortedCategories.map(([catName, amountPaisa]) => {
              const categoryObj = categories.find((c) => c.name === catName);
              const percentage =
                totalExpensePaisa > 0 ? Math.round((amountPaisa / totalExpensePaisa) * 100) : 0;
              const color = categoryObj?.color || '#10B981';

              return (
                <div key={catName} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${color}25` }}
                      >
                        <CategoryIcon
                          name={categoryObj?.icon || 'MoreHorizontal'}
                          color={color}
                          className="w-3.5 h-3.5"
                        />
                      </div>
                      <span className="font-medium text-gray-200">{catName}</span>
                    </div>
                    <div className="text-right tabular-nums">
                      <span className="font-bold text-white">{formatPKR(amountPaisa)}</span>
                      <span className="text-gray-400 text-[11px] ml-1.5">({percentage}%)</span>
                    </div>
                  </div>
                  <div className="w-full bg-[#0E1611] rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{ width: `${percentage}%`, backgroundColor: color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Recent Transactions List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-tight">Recent Transactions</h3>
          <button
            onClick={() => onNavigateToTab('transactions')}
            className="text-[11px] text-emerald-400 hover:underline font-medium"
          >
            View All ({transactions.length})
          </button>
        </div>

        {recentTransactions.length > 0 ? (
          <div className="space-y-2">
            {recentTransactions.map((tx) => {
              const cat = categories.find((c) => c.name === tx.category);
              const isIncome = tx.type === 'income';

              return (
                <div
                  key={tx.id}
                  onClick={() => onSelectTransaction(tx)}
                  className="p-3.5 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] border border-[#233527] flex items-center justify-between cursor-pointer transition-colors active:scale-[0.99]"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{
                        backgroundColor: isIncome ? '#064E3B40' : '#88133740',
                      }}
                    >
                      <CategoryIcon
                        name={cat?.icon || (isIncome ? 'TrendingUp' : 'TrendingDown')}
                        color={isIncome ? '#10B981' : '#F43F5E'}
                        className="w-5 h-5"
                      />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-semibold text-white truncate">{tx.category}</h4>
                      <p className="text-[10px] text-gray-400 truncate">
                        {tx.note || formatDisplayDate(tx.date)}
                        {tx.paymentMethod && ` · ${tx.paymentMethod.toUpperCase()}`}
                      </p>
                    </div>
                  </div>

                  <div className="text-right shrink-0 tabular-nums">
                    <span
                      className={`text-xs sm:text-sm font-bold block ${
                        isIncome ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isIncome ? '+' : '-'} {formatPKR(tx.amountPaisa)}
                    </span>
                    <span className="text-[10px] text-gray-500">{formatDisplayDate(tx.date)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 rounded-3xl bg-[#142018] border border-dashed border-[#233527] text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-950/60 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">No Transactions Recorded Yet</h4>
              <p className="text-xs text-gray-400 max-w-xs mx-auto mt-1">
                Pocket Hisab Pro is 100% offline. Add your first income or expense to start your
                financial ledger.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => onOpenAddTransaction('expense')}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-semibold transition-colors"
              >
                + Add First Transaction
              </button>
              <button
                onClick={onLoadDemoData}
                className="px-3.5 py-2 rounded-xl bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-emerald-300 text-xs font-medium transition-colors"
              >
                Load Realistic Demo Data
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
