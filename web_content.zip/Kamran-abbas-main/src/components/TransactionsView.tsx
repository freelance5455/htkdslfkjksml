import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Trash2,
  Edit2,
  Calendar,
  X,
  CreditCard,
  Banknote,
  Smartphone,
  ChevronDown,
  ArrowUpDown,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import { Transaction, TransactionType, PaymentMethod, Category } from '../types';
import { formatPKR, formatDisplayDate, paisaToRupees } from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface TransactionsViewProps {
  transactions: Transaction[];
  categories: Category[];
  activeMonth: string;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => Promise<void>;
  onOpenAddTransaction: (type?: TransactionType) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  categories,
  activeMonth,
  onEditTransaction,
  onDeleteTransaction,
  onOpenAddTransaction,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedType, setSelectedType] = useState<'all' | TransactionType>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>('all');
  const [selectedMonth, setSelectedMonth] = useState<string>(activeMonth);
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'highest' | 'lowest'>('newest');

  // Transaction Detail / Delete Confirmation Modal
  const [activeTx, setActiveTx] = useState<Transaction | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Available unique months from transactions
  const availableMonths = useMemo(() => {
    const set = new Set<string>();
    set.add(activeMonth);
    transactions.forEach((t) => {
      const ym = t.date.substring(0, 7);
      if (ym) set.add(ym);
    });
    return Array.from(set).sort().reverse();
  }, [transactions, activeMonth]);

  // Filtering and Sorting
  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((t) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchCat = t.category.toLowerCase().includes(q);
          const matchNote = t.note?.toLowerCase().includes(q);
          const matchAmount = (t.amountPaisa / 100).toString().includes(q);
          if (!matchCat && !matchNote && !matchAmount) return false;
        }

        // Type
        if (selectedType !== 'all' && t.type !== selectedType) return false;

        // Category
        if (selectedCategory !== 'all' && t.category !== selectedCategory) return false;

        // Payment Method
        if (selectedPaymentMethod !== 'all' && t.paymentMethod !== selectedPaymentMethod)
          return false;

        // Month
        if (selectedMonth !== 'all' && !t.date.startsWith(selectedMonth)) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          const dtA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
          const dtB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
          return dtB - dtA;
        }
        if (sortBy === 'oldest') {
          const dtA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
          const dtB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
          return dtA - dtB;
        }
        if (sortBy === 'highest') {
          return b.amountPaisa - a.amountPaisa;
        }
        if (sortBy === 'lowest') {
          return a.amountPaisa - b.amountPaisa;
        }
        return 0;
      });
  }, [
    transactions,
    searchQuery,
    selectedType,
    selectedCategory,
    selectedPaymentMethod,
    selectedMonth,
    sortBy,
  ]);

  // Summary Metrics for filtered set
  const filteredIncomePaisa = filteredTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const filteredExpensePaisa = filteredTransactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const filteredNetPaisa = filteredIncomePaisa - filteredExpensePaisa;

  // CSV Export Function
  const exportToCSV = () => {
    const headers = [
      'Transaction ID',
      'Date',
      'Time',
      'Type',
      'Category',
      'Amount (PKR)',
      'Payment Method',
      'Note',
    ];

    const rows = filteredTransactions.map((t) => [
      t.id,
      t.date,
      t.time || '',
      t.type.toUpperCase(),
      `"${t.category.replace(/"/g, '""')}"`,
      paisaToRupees(t.amountPaisa).toFixed(2),
      t.paymentMethod.toUpperCase(),
      `"${(t.note || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `PocketHisab_Transactions_${selectedMonth !== 'all' ? selectedMonth : 'All'}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async () => {
    if (!activeTx) return;
    setIsDeleting(true);
    try {
      await onDeleteTransaction(activeTx.id);
      setShowDeleteConfirm(false);
      setActiveTx(null);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Search & Month Filter Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          {/* Search Input */}
          <div className="flex-1 relative rounded-2xl bg-[#142018] border border-[#233527] p-2.5 flex items-center">
            <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
            <input
              type="text"
              placeholder="Search category, note, or amount..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs text-white placeholder-gray-500 focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Month Selector */}
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="bg-[#142018] border border-[#233527] text-xs text-white rounded-2xl px-3 py-2.5 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="all">All Months</option>
            {availableMonths.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>

          {/* CSV Export Button */}
          <button
            onClick={exportToCSV}
            disabled={filteredTransactions.length === 0}
            className="p-2.5 rounded-2xl bg-[#142018] border border-[#233527] hover:bg-[#1C2C22] text-gray-300 hover:text-white transition-colors disabled:opacity-40 cursor-pointer"
            title="Export to CSV"
          >
            <Download className="w-4 h-4" />
          </button>
        </div>

        {/* Type Segmented Buttons */}
        <div className="grid grid-cols-3 p-1 bg-[#142018] rounded-xl border border-[#233527]">
          <button
            onClick={() => setSelectedType('all')}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedType === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            All Types ({transactions.length})
          </button>
          <button
            onClick={() => setSelectedType('expense')}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedType === 'expense'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Expenses Only
          </button>
          <button
            onClick={() => setSelectedType('income')}
            className={`py-1.5 text-xs font-semibold rounded-lg transition-all ${
              selectedType === 'income'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Income Only
          </button>
        </div>

        {/* Category & Payment Method Sub-filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-[#142018] border border-[#233527] text-gray-300 rounded-xl px-2.5 py-1.5 focus:outline-none shrink-0"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name} ({c.type})
              </option>
            ))}
          </select>

          <select
            value={selectedPaymentMethod}
            onChange={(e) => setSelectedPaymentMethod(e.target.value)}
            className="bg-[#142018] border border-[#233527] text-gray-300 rounded-xl px-2.5 py-1.5 focus:outline-none shrink-0"
          >
            <option value="all">All Payment Methods</option>
            <option value="cash">Cash (Naqad)</option>
            <option value="bank">Bank / IBFT</option>
            <option value="other">Digital / Wallet</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#142018] border border-[#233527] text-gray-300 rounded-xl px-2.5 py-1.5 focus:outline-none shrink-0 ml-auto"
          >
            <option value="newest">Sort: Newest First</option>
            <option value="oldest">Sort: Oldest First</option>
            <option value="highest">Sort: Highest Amount</option>
            <option value="lowest">Sort: Lowest Amount</option>
          </select>
        </div>
      </div>

      {/* Filtered Financial Summary Strip */}
      <div className="p-3.5 rounded-2xl bg-[#142018] border border-[#233527] flex items-center justify-between text-xs tabular-nums">
        <div>
          <span className="text-gray-400 text-[10px] block">Matching Entries</span>
          <span className="font-bold text-white">{filteredTransactions.length} records</span>
        </div>
        <div>
          <span className="text-gray-400 text-[10px] block">Filtered Income</span>
          <span className="font-bold text-emerald-400">+{formatPKR(filteredIncomePaisa)}</span>
        </div>
        <div>
          <span className="text-gray-400 text-[10px] block">Filtered Expenses</span>
          <span className="font-bold text-rose-400">-{formatPKR(filteredExpensePaisa)}</span>
        </div>
        <div>
          <span className="text-gray-400 text-[10px] block">Net Difference</span>
          <span
            className={`font-bold ${filteredNetPaisa >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}
          >
            {formatPKR(filteredNetPaisa, 'Rs.', 'prefix', { includeSign: true })}
          </span>
        </div>
      </div>

      {/* Transactions List */}
      {filteredTransactions.length > 0 ? (
        <div className="space-y-2">
          {filteredTransactions.map((tx) => {
            const cat = categories.find((c) => c.name === tx.category);
            const isIncome = tx.type === 'income';

            return (
              <div
                key={tx.id}
                onClick={() => setActiveTx(tx)}
                className="p-3.5 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] border border-[#233527] flex items-center justify-between cursor-pointer transition-colors active:scale-[0.99]"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{
                      backgroundColor: isIncome ? '#064E3B40' : '#88133740',
                    }}
                  >
                    <CategoryIcon
                      name={cat?.icon || (isIncome ? 'TrendingUp' : 'TrendingDown')}
                      color={isIncome ? '#10B981' : '#F43F5E'}
                      className="w-5 h-5"
                    />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-semibold text-white truncate">{tx.category}</h4>
                    <p className="text-[10px] text-gray-400 truncate">
                      {tx.note ? `${tx.note} · ` : ''}
                      {tx.paymentMethod.toUpperCase()}
                      {tx.time ? ` · ${tx.time}` : ''}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0 tabular-nums">
                  <span
                    className={`text-xs sm:text-sm font-bold block ${
                      isIncome ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isIncome ? '+' : '-'} {formatPKR(tx.amountPaisa)}
                  </span>
                  <span className="text-[10px] text-gray-500">{formatDisplayDate(tx.date)}</span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-8 rounded-3xl bg-[#142018] border border-dashed border-[#233527] text-center space-y-3">
          <p className="text-xs text-gray-400">No transactions matching your active filter criteria.</p>
          <button
            onClick={() => onOpenAddTransaction('expense')}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-semibold"
          >
            + Add New Transaction
          </button>
        </div>
      )}

      {/* Transaction Detail & Actions Drawer/Modal */}
      {activeTx && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
          <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl overflow-hidden shadow-2xl animate-slide-up">
            {/* Modal Header */}
            <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23] flex items-center justify-between">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                Transaction Details
              </span>
              <button
                onClick={() => {
                  setActiveTx(null);
                  setShowDeleteConfirm(false);
                }}
                className="p-1 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div className="text-center py-2">
                <span
                  className={`text-3xl font-extrabold tabular-nums block ${
                    activeTx.type === 'income' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {activeTx.type === 'income' ? '+' : '-'} {formatPKR(activeTx.amountPaisa)}
                </span>
                <span className="text-xs font-medium text-gray-400 mt-1 block">
                  {activeTx.type === 'income' ? 'Income (Aamdani)' : 'Expense (Kharcha)'}
                </span>
              </div>

              <div className="rounded-2xl bg-[#142018] border border-[#233527] p-4 space-y-3 text-xs">
                <div className="flex justify-between py-1 border-b border-[#1E2E23]">
                  <span className="text-gray-400">Category:</span>
                  <span className="font-semibold text-white">{activeTx.category}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#1E2E23]">
                  <span className="text-gray-400">Date & Time:</span>
                  <span className="font-semibold text-white">
                    {formatDisplayDate(activeTx.date)} {activeTx.time && `at ${activeTx.time}`}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#1E2E23]">
                  <span className="text-gray-400">Payment Method:</span>
                  <span className="font-semibold text-white uppercase">
                    {activeTx.paymentMethod}
                  </span>
                </div>
                {activeTx.note && (
                  <div className="py-1">
                    <span className="text-gray-400 block mb-1">Note:</span>
                    <p className="text-gray-200 bg-[#0C130F] p-2.5 rounded-xl border border-[#1E2E23] leading-relaxed">
                      {activeTx.note}
                    </p>
                  </div>
                )}
              </div>

              {/* Delete Confirmation prompt if clicked */}
              {showDeleteConfirm ? (
                <div className="p-4 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-center space-y-3">
                  <p className="text-xs font-semibold text-rose-300">
                    Are you sure you want to permanently delete this transaction?
                  </p>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowDeleteConfirm(false)}
                      className="flex-1 py-2 rounded-xl bg-[#1E2E23] text-gray-300 text-xs font-medium"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleDelete}
                      disabled={isDeleting}
                      className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
                    >
                      {isDeleting ? 'Deleting...' : 'Confirm Delete'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="flex-1 py-3 rounded-xl border border-rose-900/60 bg-rose-950/30 hover:bg-rose-950/50 text-rose-400 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Delete</span>
                  </button>
                  <button
                    onClick={() => {
                      onEditTransaction(activeTx);
                      setActiveTx(null);
                    }}
                    className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>Edit Transaction</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
