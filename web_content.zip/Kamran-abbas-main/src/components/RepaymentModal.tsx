import React, { useState, useEffect } from 'react';
import { X, Calendar, Check, Banknote, CreditCard, Smartphone } from 'lucide-react';
import { Debt, PaymentMethod } from '../types';
import { formatPKR, parseRupeesToPaisa, paisaToRupees } from '../utils/currency';

interface RepaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  debt: Debt | null;
  onSave: (repayment: {
    debtId: string;
    amountPaisa: number;
    date: string;
    paymentMethod: PaymentMethod;
    note?: string;
  }) => Promise<void>;
}

export const RepaymentModal: React.FC<RepaymentModalProps> = ({
  isOpen,
  onClose,
  debt,
  onSave,
}) => {
  const [amountInput, setAmountInput] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [note, setNote] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && debt) {
      const remainingPaisa = Math.max(0, debt.originalAmountPaisa - debt.repaidAmountPaisa);
      // Pre-fill with remaining amount for convenience
      setAmountInput(paisaToRupees(remainingPaisa).toString());

      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const d = String(now.getDate()).padStart(2, '0');
      setDate(`${y}-${m}-${d}`);
      setPaymentMethod('cash');
      setNote('');
      setError('');
    }
  }, [isOpen, debt]);

  if (!isOpen || !debt) return null;

  const remainingPaisa = Math.max(0, debt.originalAmountPaisa - debt.repaidAmountPaisa);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const paisa = parseRupeesToPaisa(amountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid repayment amount.');
      return;
    }

    if (paisa > remainingPaisa) {
      setError(
        `Repayment amount (${formatPKR(paisa)}) cannot exceed the remaining balance (${formatPKR(
          remainingPaisa
        )}).`
      );
      return;
    }

    if (!date) {
      setError('Please select a payment date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        debtId: debt.id,
        amountPaisa: paisa,
        date,
        paymentMethod,
        note: note.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to record repayment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">Record Repayment</h3>
              <p className="text-xs text-gray-400 mt-0.5">{debt.personName}</p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Balance Status Banner */}
        <div className="bg-[#142018] border-b border-[#1E2E23] p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-gray-400 uppercase tracking-wider block">
              Original Amount
            </span>
            <span className="text-sm font-semibold text-gray-300">
              {formatPKR(debt.originalAmountPaisa)}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-emerald-400 uppercase tracking-wider block font-medium">
              Remaining Balance
            </span>
            <span className="text-base font-bold text-emerald-400">
              {formatPKR(remainingPaisa)}
            </span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Amount Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-gray-400">Repayment Amount (PKR) *</label>
              <button
                type="button"
                onClick={() => setAmountInput(paisaToRupees(remainingPaisa).toString())}
                className="text-[11px] text-emerald-400 hover:underline font-medium"
              >
                Pay Full ({formatPKR(remainingPaisa)})
              </button>
            </div>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                max={paisaToRupees(remainingPaisa)}
                placeholder="0"
                autoFocus
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Payment Method</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'cash', label: 'Cash', icon: Banknote },
                { id: 'bank', label: 'Bank', icon: CreditCard },
                { id: 'other', label: 'Digital', icon: Smartphone },
              ].map((pm) => {
                const Icon = pm.icon;
                const isSelected = paymentMethod === pm.id;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                    className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl text-xs font-medium border transition-all ${
                      isSelected
                        ? 'bg-[#1B2F22] border-emerald-500 text-emerald-400'
                        : 'bg-[#142018] border-[#223528] text-gray-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{pm.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Repayment Date *
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Note */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Note (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Received via JazzCash / Cash in hand..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>Confirm Repayment</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
