import React, { useState, useEffect } from 'react';
import { Lock, Fingerprint, Delete, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { hashPin, verifyPin, authenticateBiometric } from '../utils/security';
import { AppSettings } from '../types';

interface PinLockScreenProps {
  mode: 'unlock' | 'setup' | 'change';
  settings: AppSettings;
  onSuccess: (newPinHash?: string, newSalt?: string) => void;
  onCancel?: () => void;
}

export const PinLockScreen: React.FC<PinLockScreenProps> = ({
  mode,
  settings,
  onSuccess,
  onCancel,
}) => {
  const [pin, setPin] = useState<string>('');
  const [confirmPin, setConfirmPin] = useState<string>('');
  const [step, setStep] = useState<'enter' | 'confirm' | 'current'>(
    mode === 'change' ? 'current' : 'enter'
  );
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isShaking, setIsShaking] = useState<boolean>(false);

  const targetLength = 4;

  const triggerVibrate = (pattern: number | number[] = 30) => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(pattern);
      } catch {
        // Ignore if unsupported
      }
    }
  };

  // Try biometric on initial mount if unlock mode and biometric enabled
  useEffect(() => {
    if (mode === 'unlock' && settings.biometricEnabled) {
      handleBiometric();
    }
  }, [mode, settings.biometricEnabled]);

  const handleBiometric = async () => {
    const passed = await authenticateBiometric();
    if (passed) {
      triggerVibrate(50);
      onSuccess();
    }
  };

  const handleKeyPress = (num: string) => {
    if (pin.length < targetLength) {
      triggerVibrate(20);
      const nextPin = pin + num;
      setPin(nextPin);
      setErrorMsg('');

      if (nextPin.length === targetLength) {
        processPin(nextPin);
      }
    }
  };

  const handleDelete = () => {
    if (pin.length > 0) {
      triggerVibrate(20);
      setPin(pin.slice(0, -1));
      setErrorMsg('');
    }
  };

  const triggerError = (msg: string) => {
    triggerVibrate([50, 50, 50]);
    setErrorMsg(msg);
    setIsShaking(true);
    setTimeout(() => {
      setIsShaking(false);
      setPin('');
    }, 600);
  };

  const processPin = async (completedPin: string) => {
    if (mode === 'unlock') {
      if (!settings.pinHash || !settings.pinSalt) {
        onSuccess();
        return;
      }
      const isValid = await verifyPin(completedPin, settings.pinHash, settings.pinSalt);
      if (isValid) {
        triggerVibrate(60);
        onSuccess();
      } else {
        triggerError('Incorrect PIN. Please try again.');
      }
    } else if (mode === 'setup') {
      if (step === 'enter') {
        setConfirmPin(completedPin);
        setStep('confirm');
        setPin('');
      } else if (step === 'confirm') {
        if (completedPin === confirmPin) {
          const { hash, salt } = await hashPin(completedPin);
          triggerVibrate(60);
          onSuccess(hash, salt);
        } else {
          triggerError('PINs do not match. Restarting setup.');
          setStep('enter');
          setConfirmPin('');
        }
      }
    } else if (mode === 'change') {
      if (step === 'current') {
        if (!settings.pinHash || !settings.pinSalt) {
          setStep('enter');
          setPin('');
          return;
        }
        const isValid = await verifyPin(completedPin, settings.pinHash, settings.pinSalt);
        if (isValid) {
          setStep('enter');
          setPin('');
        } else {
          triggerError('Current PIN is incorrect.');
        }
      } else if (step === 'enter') {
        setConfirmPin(completedPin);
        setStep('confirm');
        setPin('');
      } else if (step === 'confirm') {
        if (completedPin === confirmPin) {
          const { hash, salt } = await hashPin(completedPin);
          triggerVibrate(60);
          onSuccess(hash, salt);
        } else {
          triggerError('New PINs do not match. Try again.');
          setStep('enter');
          setConfirmPin('');
        }
      }
    }
  };

  const getTitle = () => {
    if (mode === 'unlock') return 'Enter App PIN';
    if (mode === 'change' && step === 'current') return 'Enter Current PIN';
    if (step === 'enter') return 'Create 4-Digit PIN';
    return 'Confirm Your PIN';
  };

  const getSubtitle = () => {
    if (mode === 'unlock') return 'Pocket Hisab Pro is secured offline.';
    if (mode === 'change' && step === 'current') return 'Verify your identity before changing.';
    if (step === 'enter') return 'Choose a secure PIN to protect your financial records.';
    return 'Re-enter the same 4-digit PIN to confirm.';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#070D0A] px-4 py-6">
      <div className="w-full max-w-sm flex flex-col items-center text-center">
        {/* Brand Icon Shield */}
        <div className="w-16 h-16 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4 shadow-lg shadow-emerald-950/40">
          <Lock className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-bold text-white tracking-tight">{getTitle()}</h2>
        <p className="text-xs text-gray-400 mt-1 max-w-[280px]">{getSubtitle()}</p>

        {/* PIN Dots Display */}
        <div
          className={`flex items-center justify-center gap-4 my-8 transition-transform ${
            isShaking ? 'animate-shake' : ''
          }`}
        >
          {Array.from({ length: targetLength }).map((_, idx) => (
            <div
              key={idx}
              className={`w-4 h-4 rounded-full transition-all duration-200 ${
                idx < pin.length
                  ? 'bg-emerald-400 scale-110 shadow-sm shadow-emerald-400/50'
                  : 'bg-gray-800 border border-gray-700'
              }`}
            />
          ))}
        </div>

        {errorMsg && (
          <div className="flex items-center gap-1.5 text-xs text-rose-400 mb-4 animate-fade-in">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[280px] my-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              className="h-14 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] active:scale-95 border border-[#233527] text-white text-xl font-semibold transition-all flex items-center justify-center select-none cursor-pointer"
            >
              {digit}
            </button>
          ))}

          {/* Biometric or Empty */}
          {mode === 'unlock' && settings.biometricEnabled ? (
            <button
              type="button"
              onClick={handleBiometric}
              className="h-14 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] active:scale-95 border border-[#233527] text-emerald-400 text-sm font-medium transition-all flex flex-col items-center justify-center gap-0.5 select-none cursor-pointer"
              title="Use Biometrics"
            >
              <Fingerprint className="w-6 h-6" />
              <span className="text-[10px]">Biometric</span>
            </button>
          ) : (
            <div className="h-14" />
          )}

          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            className="h-14 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] active:scale-95 border border-[#233527] text-white text-xl font-semibold transition-all flex items-center justify-center select-none cursor-pointer"
          >
            0
          </button>

          <button
            type="button"
            onClick={handleDelete}
            className="h-14 rounded-2xl bg-[#142018] hover:bg-[#1A2A20] active:scale-95 border border-[#233527] text-gray-300 transition-all flex items-center justify-center select-none cursor-pointer"
            title="Delete digit"
          >
            <Delete className="w-6 h-6" />
          </button>
        </div>

        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="mt-6 text-xs text-gray-400 hover:text-white py-2 px-4 transition-colors"
          >
            Cancel
          </button>
        )}
      </div>
    </div>
  );
};
