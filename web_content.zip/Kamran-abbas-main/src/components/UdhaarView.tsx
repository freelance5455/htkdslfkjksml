import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  HandCoins,
  Phone,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  Edit2,
  Trash2,
  History,
  X,
  User,
} from 'lucide-react';
import { Debt, DebtRepayment, DebtType, DebtStatus } from '../types';
import { formatPKR, formatDisplayDate } from '../utils/currency';

interface UdhaarViewProps {
  debts: Debt[];
  debtRepayments: DebtRepayment[];
  onOpenAddDebt: (type?: DebtType) => void;
  onEditDebt: (debt: Debt) => void;
  onDeleteDebt: (id: string) => Promise<void>;
  onOpenRepaymentModal: (debt: Debt) => void;
  onDeleteRepayment: (repaymentId: string, debtId: string) => Promise<void>;
}

export const UdhaarView: React.FC<UdhaarViewProps> = ({
  debts,
  debtRepayments,
  onOpenAddDebt,
  onEditDebt,
  onDeleteDebt,
  onOpenRepaymentModal,
  onDeleteRepayment,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'lent' | 'borrowed' | 'settled'>('all');
  const [historyDebt, setHistoryDebt] = useState<Debt | null>(null);
  const [debtToDelete, setDebtToDelete] = useState<Debt | null>(null);

  // Financial totals in Paisa
  const totalLentOwedPaisa = debts
    .filter((d) => d.type === 'lent' && d.status !== 'settled')
    .reduce((sum, d) => sum + (d.originalAmountPaisa - d.repaidAmountPaisa), 0);

  const totalBorrowedOwedPaisa = debts
    .filter((d) => d.type === 'borrowed' && d.status !== 'settled')
    .reduce((sum, d) => sum + (d.originalAmountPaisa - d.repaidAmountPaisa), 0);

  const netUdhaarPaisa = totalLentOwedPaisa - totalBorrowedOwedPaisa;

  // Filtered debts
  const filteredDebts = useMemo(() => {
    return debts.filter((d) => {
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = d.personName.toLowerCase().includes(q);
        const matchNotes = d.notes?.toLowerCase().includes(q);
        const matchPhone = d.contactNumber?.includes(q);
        if (!matchName && !matchNotes && !matchPhone) return false;
      }

      if (filterType === 'lent') return d.type === 'lent' && d.status !== 'settled';
      if (filterType === 'borrowed') return d.type === 'borrowed' && d.status !== 'settled';
      if (filterType === 'settled') return d.status === 'settled';

      return true;
    });
  }, [debts, searchQuery, filterType]);

  const debtRepaymentsForHistory = useMemo(() => {
    if (!historyDebt) return [];
    return debtRepayments.filter((r) => r.debtId === historyDebt.id);
  }, [historyDebt, debtRepayments]);

  return (
    <div className="space-y-5 pb-12">
      {/* Udhaar Top Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        {/* Money I Lent (Receivable) */}
        <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527] relative overflow-hidden">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-emerald-400 font-semibold uppercase tracking-wider">
              Mujhe Milna Hai
            </span>
            <div className="w-6 h-6 rounded-lg bg-emerald-950/70 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ArrowDownLeft className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {formatPKR(totalLentOwedPaisa)}
          </div>
          <span className="text-[10px] text-gray-400 mt-1 block">
            Money I Lent (Receivable)
          </span>
        </div>

        {/* Money I Borrowed (Payable) */}
        <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527] relative overflow-hidden">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] text-amber-400 font-semibold uppercase tracking-wider">
              Maine Dena Hai
            </span>
            <div className="w-6 h-6 rounded-lg bg-amber-950/70 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-xl font-bold text-white tabular-nums">
            {formatPKR(totalBorrowedOwedPaisa)}
          </div>
          <span className="text-[10px] text-gray-400 mt-1 block">
            Money I Borrowed (Payable)
          </span>
        </div>
      </div>

      {/* Net Position Banner */}
      <div className="p-3.5 rounded-2xl bg-[#101A13] border border-[#1E2E23] flex items-center justify-between text-xs tabular-nums">
        <span className="text-gray-400">Net Udhaar Balance:</span>
        <span
          className={`font-bold ${netUdhaarPaisa >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}
        >
          {netUdhaarPaisa >= 0 ? 'In Profit (Net Receivable): ' : 'In Debt (Net Payable): '}
          {formatPKR(Math.abs(netUdhaarPaisa))}
        </span>
      </div>

      {/* Search & Actions Bar */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="flex-1 relative rounded-2xl bg-[#142018] border border-[#233527] p-2.5 flex items-center">
            <Search className="w-4 h-4 text-gray-400 mr-2 shrink-0" />
            <input
              type="text"
              placeholder="Search by person name or notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-xs text-white placeholder-gray-500 focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            onClick={() => onOpenAddDebt('lent')}
            className="px-3.5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs rounded-2xl shadow-md shadow-emerald-500/20 flex items-center gap-1.5 transition-all shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Udhaar</span>
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="grid grid-cols-4 p-1 bg-[#142018] rounded-xl border border-[#233527] text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`py-1.5 font-semibold rounded-lg transition-all ${
              filterType === 'all'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            All ({debts.length})
          </button>
          <button
            onClick={() => setFilterType('lent')}
            className={`py-1.5 font-semibold rounded-lg transition-all ${
              filterType === 'lent'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Lent
          </button>
          <button
            onClick={() => setFilterType('borrowed')}
            className={`py-1.5 font-semibold rounded-lg transition-all ${
              filterType === 'borrowed'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Borrowed
          </button>
          <button
            onClick={() => setFilterType('settled')}
            className={`py-1.5 font-semibold rounded-lg transition-all ${
              filterType === 'settled'
                ? 'bg-gray-700 text-white shadow-sm'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Settled
          </button>
        </div>
      </div>

      {/* Debts List */}
      {filteredDebts.length > 0 ? (
        <div className="space-y-3">
          {filteredDebts.map((d) => {
            const isLent = d.type === 'lent';
            const remainingPaisa = Math.max(0, d.originalAmountPaisa - d.repaidAmountPaisa);
            const percentRepaid =
              d.originalAmountPaisa > 0
                ? Math.round((d.repaidAmountPaisa / d.originalAmountPaisa) * 100)
                : 100;

            return (
              <div
                key={d.id}
                className="p-4 rounded-3xl bg-[#142018] border border-[#233527] space-y-3 transition-colors"
              >
                {/* Top Row: Person & Status */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        isLent
                          ? 'bg-emerald-950/70 border border-emerald-500/30 text-emerald-400'
                          : 'bg-amber-950/70 border border-amber-500/30 text-amber-400'
                      }`}
                    >
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{d.personName}</h4>
                      <div className="flex items-center gap-2 text-[10px] text-gray-400">
                        <span className={isLent ? 'text-emerald-400 font-medium' : 'text-amber-400 font-medium'}>
                          {isLent ? 'Money I Lent' : 'Money I Borrowed'}
                        </span>
                        {d.contactNumber && (
                          <>
                            <span>·</span>
                            <a
                              href={`tel:${d.contactNumber}`}
                              className="text-gray-300 hover:underline flex items-center gap-0.5"
                            >
                              <Phone className="w-2.5 h-2.5" />
                              {d.contactNumber}
                            </a>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className="shrink-0">
                    {d.status === 'settled' ? (
                      <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Settled
                      </span>
                    ) : d.status === 'partially_paid' ? (
                      <span className="text-[10px] font-semibold text-amber-400 bg-amber-950/60 border border-amber-500/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Partially Paid
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-gray-300 bg-gray-800/80 border border-gray-700 px-2 py-0.5 rounded-full">
                        Pending
                      </span>
                    )}
                  </div>
                </div>

                {/* Amount Matrix */}
                <div className="grid grid-cols-3 gap-2 p-2.5 rounded-2xl bg-[#0D1510] border border-[#1E2E23] text-xs tabular-nums">
                  <div>
                    <span className="text-[10px] text-gray-500 block">Total Amount</span>
                    <span className="font-semibold text-gray-300">
                      {formatPKR(d.originalAmountPaisa)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 block">Repaid</span>
                    <span className="font-semibold text-emerald-400">
                      {formatPKR(d.repaidAmountPaisa)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 block">Remaining</span>
                    <span
                      className={`font-bold ${
                        remainingPaisa === 0
                          ? 'text-gray-400'
                          : isLent
                          ? 'text-emerald-400'
                          : 'text-amber-400'
                      }`}
                    >
                      {formatPKR(remainingPaisa)}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-[#0E1611] rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      remainingPaisa === 0 ? 'bg-emerald-500' : 'bg-emerald-400'
                    }`}
                    style={{ width: `${percentRepaid}%` }}
                  />
                </div>

                {/* Dates & Notes */}
                <div className="flex items-center justify-between text-[10px] text-gray-400 pt-0.5">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-gray-500" />
                    Given: {formatDisplayDate(d.date)}
                    {d.dueDate && ` · Due: ${formatDisplayDate(d.dueDate)}`}
                  </span>
                  {d.notes && <span className="text-gray-300 truncate max-w-[140px] italic">"{d.notes}"</span>}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-1 border-t border-[#1E2E23]">
                  {d.status !== 'settled' && (
                    <button
                      onClick={() => onOpenRepaymentModal(d)}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1 transition-colors cursor-pointer"
                    >
                      <HandCoins className="w-3.5 h-3.5" />
                      <span>Record Payment</span>
                    </button>
                  )}

                  <button
                    onClick={() => setHistoryDebt(d)}
                    className="p-2 rounded-xl bg-[#1C2C22] hover:bg-[#25392D] text-gray-300 hover:text-white transition-colors"
                    title="Repayment History"
                  >
                    <History className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onEditDebt(d)}
                    className="p-2 rounded-xl bg-[#1C2C22] hover:bg-[#25392D] text-gray-300 hover:text-white transition-colors"
                    title="Edit Record"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setDebtToDelete(d)}
                    className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 text-rose-400 transition-colors"
                    title="Delete Record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-8 rounded-3xl bg-[#142018] border border-dashed border-[#233527] text-center space-y-3">
          <p className="text-xs text-gray-400">No udhaar / debt records found matching your filter.</p>
          <button
            onClick={() => onOpenAddDebt('lent')}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-semibold"
          >
            + Add New Udhaar Record
          </button>
        </div>
      )}

      {/* Repayments History Modal */}
      {historyDebt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#0F1713] border border-[#233527] max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
            <div className="pt-4 px-6 pb-4 border-b border-[#1E2E23] flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">Repayment History</h3>
                <p className="text-xs text-gray-400">{historyDebt.personName}</p>
              </div>
              <button
                onClick={() => setHistoryDebt(null)}
                className="p-1.5 rounded-lg text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-3">
              {debtRepaymentsForHistory.length > 0 ? (
                debtRepaymentsForHistory.map((rep) => (
                  <div
                    key={rep.id}
                    className="p-3.5 rounded-2xl bg-[#142018] border border-[#233527] flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-emerald-400 block tabular-nums">
                        +{formatPKR(rep.amountPaisa)}
                      </span>
                      <span className="text-[10px] text-gray-400">
                        {formatDisplayDate(rep.date)} · {rep.paymentMethod.toUpperCase()}
                        {rep.note ? ` · ${rep.note}` : ''}
                      </span>
                    </div>

                    <button
                      onClick={async () => {
                        await onDeleteRepayment(rep.id, historyDebt.id);
                      }}
                      className="text-gray-500 hover:text-rose-400 p-1.5 transition-colors"
                      title="Undo / Delete Repayment"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              ) : (
                <p className="text-center text-xs text-gray-400 py-6">
                  No repayments recorded yet for this entry.
                </p>
              )}
            </div>

            <div className="p-4 border-t border-[#1E2E23] bg-[#0C140F] flex items-center justify-end">
              <button
                onClick={() => setHistoryDebt(null)}
                className="px-4 py-2 rounded-xl bg-[#16231A] text-white text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {debtToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#0F1713] border border-[#233527] p-6 text-center space-y-4">
            <h4 className="text-sm font-bold text-white">Delete Udhaar Record</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Are you sure you want to permanently delete the record for{' '}
              <strong className="text-white">{debtToDelete.personName}</strong> and all associated
              repayment entries?
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setDebtToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#233527] text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  await onDeleteDebt(debtToDelete.id);
                  setDebtToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
