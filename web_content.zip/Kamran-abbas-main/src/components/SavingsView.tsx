import React, { useState } from 'react';
import {
  Plus,
  PiggyBank,
  CheckCircle2,
  Calendar,
  ArrowDownLeft,
  ArrowUpRight,
  Edit2,
  Trash2,
  Target,
} from 'lucide-react';
import { SavingsGoal, SavingsContribution } from '../types';
import { formatPKR, formatDisplayDate } from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface SavingsViewProps {
  goals: SavingsGoal[];
  contributions: SavingsContribution[];
  onOpenCreateGoal: () => void;
  onEditGoal: (goal: SavingsGoal) => void;
  onDeleteGoal: (id: string) => Promise<void>;
  onOpenContributionModal: (goal: SavingsGoal) => void;
}

export const SavingsView: React.FC<SavingsViewProps> = ({
  goals,
  onOpenCreateGoal,
  onEditGoal,
  onDeleteGoal,
  onOpenContributionModal,
}) => {
  const [goalToDelete, setGoalToDelete] = useState<SavingsGoal | null>(null);

  const totalSavedAcrossGoalsPaisa = goals.reduce((sum, g) => sum + g.savedAmountPaisa, 0);
  const totalTargetAcrossGoalsPaisa = goals.reduce((sum, g) => sum + g.targetAmountPaisa, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-[#142018] border border-[#233527] relative overflow-hidden space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <PiggyBank className="w-4 h-4" /> Total Disciplined Savings
          </span>
          <span className="text-[11px] text-gray-400">
            {goals.filter((g) => g.isCompleted).length} of {goals.length} Goals Achieved
          </span>
        </div>

        <div className="text-3xl font-extrabold text-white tabular-nums">
          {formatPKR(totalSavedAcrossGoalsPaisa)}
        </div>

        <div className="flex items-center justify-between text-xs text-gray-400 pt-2 border-t border-[#1E2E23]">
          <span>Combined Target: {formatPKR(totalTargetAcrossGoalsPaisa)}</span>
          <button
            onClick={onOpenCreateGoal}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Goal</span>
          </button>
        </div>
      </div>

      {/* Goals List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-tight">Active Financial Targets</h3>
          <span className="text-xs text-gray-400">{goals.length} Goals</span>
        </div>

        {goals.length > 0 ? (
          <div className="space-y-3">
            {goals.map((goal) => {
              const percent =
                goal.targetAmountPaisa > 0
                  ? Math.min(100, Math.round((goal.savedAmountPaisa / goal.targetAmountPaisa) * 100))
                  : 100;
              const remainingPaisa = Math.max(0, goal.targetAmountPaisa - goal.savedAmountPaisa);

              return (
                <div
                  key={goal.id}
                  className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                        <CategoryIcon name={goal.categoryIcon || 'Target'} className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white flex items-center gap-2">
                          <span>{goal.name}</span>
                          {goal.isCompleted && (
                            <span className="text-[10px] text-emerald-400 bg-emerald-950/70 border border-emerald-500/30 px-2 py-0.5 rounded-full flex items-center gap-1 font-medium">
                              <CheckCircle2 className="w-3 h-3" /> Achieved!
                            </span>
                          )}
                        </h4>
                        <div className="flex items-center gap-2 text-[10px] text-gray-400 mt-0.5">
                          {goal.targetDate && (
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" /> Target: {formatDisplayDate(goal.targetDate)}
                            </span>
                          )}
                          {goal.notes && <span>· {goal.notes}</span>}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => onEditGoal(goal)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setGoalToDelete(goal)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Amounts & Progress */}
                  <div className="space-y-1.5 pt-1">
                    <div className="flex items-center justify-between text-xs tabular-nums">
                      <span className="font-bold text-emerald-400">
                        {formatPKR(goal.savedAmountPaisa)}{' '}
                        <span className="text-gray-400 font-normal">
                          / {formatPKR(goal.targetAmountPaisa)}
                        </span>
                      </span>
                      <span className="text-gray-400 font-semibold">{percent}%</span>
                    </div>

                    <div className="w-full bg-[#0E1611] rounded-full h-2.5 overflow-hidden p-0.5 border border-[#233527]">
                      <div
                        className="h-full rounded-full bg-emerald-500 transition-all duration-500"
                        style={{ width: `${percent}%` }}
                      />
                    </div>

                    <div className="text-[10px] text-gray-400 text-right tabular-nums">
                      {remainingPaisa > 0 ? (
                        <span>{formatPKR(remainingPaisa)} needed to reach goal</span>
                      ) : (
                        <span className="text-emerald-400 font-medium">Goal 100% Funded!</span>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 flex items-center gap-2 border-t border-[#1E2E23]">
                    <button
                      onClick={() => onOpenContributionModal(goal)}
                      className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                      <span>Deposit Savings</span>
                    </button>
                    <button
                      onClick={() => onOpenContributionModal(goal)}
                      className="flex-1 py-2.5 rounded-xl bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-gray-300 hover:text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      <span>Withdraw</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 rounded-3xl bg-[#142018] border border-dashed border-[#233527] text-center space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-950/60 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">No Savings Goals Set</h4>
              <p className="text-xs text-gray-400 max-w-xs mx-auto mt-0.5">
                Keep money aside for an Emergency Fund, Hajj/Umrah, Home, or Laptop without
                affecting your ledger.
              </p>
            </div>
            <button
              onClick={onOpenCreateGoal}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold text-xs transition-colors"
            >
              + Create First Savings Goal
            </button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {goalToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#0F1713] border border-[#233527] p-6 text-center space-y-4">
            <h4 className="text-sm font-bold text-white">Delete Savings Goal</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Are you sure you want to delete <strong className="text-white">{goalToDelete.name}</strong>?
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setGoalToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#233527] text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  await onDeleteGoal(goalToDelete.id);
                  setGoalToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
