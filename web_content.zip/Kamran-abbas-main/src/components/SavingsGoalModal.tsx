import React, { useState, useEffect } from 'react';
import { X, Check, Target, Calendar, FileText } from 'lucide-react';
import { SavingsGoal } from '../types';
import { parseRupeesToPaisa, paisaToRupees } from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface SavingsGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (goal: Omit<SavingsGoal, 'id' | 'createdAt' | 'updatedAt' | 'savedAmountPaisa' | 'isCompleted'> & { id?: string }) => Promise<void>;
  initialGoal?: SavingsGoal | null;
}

const AVAILABLE_ICONS = [
  'ShieldCheck',
  'Target',
  'PiggyBank',
  'Home',
  'Car',
  'Plane',
  'GraduationCap',
  'Baby',
  'Sparkles',
  'Wallet',
];

export const SavingsGoalModal: React.FC<SavingsGoalModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialGoal,
}) => {
  const [name, setName] = useState<string>('');
  const [targetAmountInput, setTargetAmountInput] = useState<string>('');
  const [targetDate, setTargetDate] = useState<string>('');
  const [categoryIcon, setCategoryIcon] = useState<string>('PiggyBank');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (initialGoal) {
        setName(initialGoal.name);
        setTargetAmountInput(paisaToRupees(initialGoal.targetAmountPaisa).toString());
        setTargetDate(initialGoal.targetDate || '');
        setCategoryIcon(initialGoal.categoryIcon || 'PiggyBank');
        setNotes(initialGoal.notes || '');
      } else {
        setName('');
        setTargetAmountInput('');
        setTargetDate('');
        setCategoryIcon('PiggyBank');
        setNotes('');
      }
      setError('');
    }
  }, [isOpen, initialGoal]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please provide a goal name.');
      return;
    }

    const paisa = parseRupeesToPaisa(targetAmountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid target amount.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        id: initialGoal ? initialGoal.id : undefined,
        name: name.trim(),
        targetAmountPaisa: paisa,
        targetDate: targetDate.trim() || undefined,
        categoryIcon,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save savings goal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white tracking-tight">
              {initialGoal ? 'Edit Savings Goal' : 'New Savings Goal'}
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Goal Name */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center gap-1">
              <Target className="w-3.5 h-3.5" /> Goal Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Emergency Fund, New Laptop, Umrah, Car Down Payment..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Target Amount */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Target Amount (Rs. / PKR) *
            </label>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="250000"
                value={targetAmountInput}
                onChange={(e) => setTargetAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Target Date */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Target Date (Optional)
            </label>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Icon Picker */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-2">Choose Icon</label>
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {AVAILABLE_ICONS.map((iconName) => {
                const isSelected = categoryIcon === iconName;
                return (
                  <button
                    key={iconName}
                    type="button"
                    onClick={() => setCategoryIcon(iconName)}
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border transition-all ${
                      isSelected
                        ? 'bg-emerald-600 border-emerald-400 text-white shadow-md'
                        : 'bg-[#142018] border-[#223528] text-gray-400 hover:text-white'
                    }`}
                  >
                    <CategoryIcon name={iconName} className="w-5 h-5" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5" /> Description / Plan
            </label>
            <input
              type="text"
              placeholder="e.g. Save Rs. 20,000 every month consistently..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{initialGoal ? 'Update Goal' : 'Create Goal'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
