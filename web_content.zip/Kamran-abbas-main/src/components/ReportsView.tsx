import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  PieChart,
  Calendar,
  TrendingUp,
  TrendingDown,
  ArrowUpDown,
  Filter,
} from 'lucide-react';
import { Transaction, Category } from '../types';
import {
  formatPKR,
  formatMonthName,
  getCurrentMonthKey,
  shiftMonthKey,
  paisaToRupees,
} from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface ReportsViewProps {
  transactions: Transaction[];
  categories: Category[];
  activeMonth: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  transactions,
  categories,
  activeMonth,
}) => {
  const [reportType, setReportType] = useState<'month' | 'custom'>('month');
  const [selectedMonth, setSelectedMonth] = useState<string>(activeMonth);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Transactions filtered for report
  const reportTransactions = useMemo(() => {
    if (reportType === 'month') {
      return transactions.filter((t) => t.date.startsWith(selectedMonth));
    }
    return transactions.filter((t) => {
      if (startDate && t.date < startDate) return false;
      if (endDate && t.date > endDate) return false;
      return true;
    });
  }, [transactions, reportType, selectedMonth, startDate, endDate]);

  // Income vs Expense
  const totalIncomePaisa = reportTransactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const totalExpensePaisa = reportTransactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amountPaisa, 0);

  const netSavingsPaisa = totalIncomePaisa - totalExpensePaisa;
  const savingsRate =
    totalIncomePaisa > 0 ? Math.round((netSavingsPaisa / totalIncomePaisa) * 100) : 0;

  // Expense Category Breakdown
  const categoryTotals: Record<string, number> = {};
  reportTransactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amountPaisa;
    });

  const sortedCategories = Object.entries(categoryTotals).sort(([, a], [, b]) => b - a);

  // Income Category Breakdown
  const incomeCategoryTotals: Record<string, number> = {};
  reportTransactions
    .filter((t) => t.type === 'income')
    .forEach((t) => {
      incomeCategoryTotals[t.category] = (incomeCategoryTotals[t.category] || 0) + t.amountPaisa;
    });

  const sortedIncomeCategories = Object.entries(incomeCategoryTotals).sort(([, a], [, b]) => b - a);

  // Past 6 Months Comparison for Bar Chart
  const past6MonthsData = useMemo(() => {
    const list: Array<{
      monthKey: string;
      label: string;
      incomePaisa: number;
      expensePaisa: number;
    }> = [];

    let current = activeMonth;
    for (let i = 0; i < 6; i++) {
      const monthTxs = transactions.filter((t) => t.date.startsWith(current));
      const inc = monthTxs
        .filter((t) => t.type === 'income')
        .reduce((sum, t) => sum + t.amountPaisa, 0);
      const exp = monthTxs
        .filter((t) => t.type === 'expense')
        .reduce((sum, t) => sum + t.amountPaisa, 0);

      list.unshift({
        monthKey: current,
        label: formatMonthName(current).split(' ')[0].substring(0, 3),
        incomePaisa: inc,
        expensePaisa: exp,
      });

      current = shiftMonthKey(current, -1);
    }
    return list;
  }, [transactions, activeMonth]);

  const maxMonthValue = Math.max(
    ...past6MonthsData.map((d) => Math.max(d.incomePaisa, d.expensePaisa)),
    1
  );

  return (
    <div className="space-y-6 pb-12">
      {/* Controls Bar */}
      <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527] space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            Financial Analytics
          </h3>

          <div className="flex items-center gap-1 bg-[#0E1611] p-1 rounded-xl border border-[#233527]">
            <button
              onClick={() => setReportType('month')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                reportType === 'month'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              By Month
            </button>
            <button
              onClick={() => setReportType('custom')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                reportType === 'custom'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Custom Date
            </button>
          </div>
        </div>

        {reportType === 'month' ? (
          <div>
            <label className="text-[11px] text-gray-400 block mb-1">Select Analysis Month:</label>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full bg-[#0E1611] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] text-gray-400 block mb-1">Start Date:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-[#0E1611] border border-[#233527] rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] text-gray-400 block mb-1">End Date:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-[#0E1611] border border-[#233527] rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
              />
            </div>
          </div>
        )}
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527]">
          <span className="text-[10px] text-emerald-400 font-semibold uppercase block">
            Total Income
          </span>
          <div className="text-sm sm:text-base font-bold text-white tabular-nums mt-1">
            {formatPKR(totalIncomePaisa)}
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527]">
          <span className="text-[10px] text-rose-400 font-semibold uppercase block">
            Total Expenses
          </span>
          <div className="text-sm sm:text-base font-bold text-white tabular-nums mt-1">
            {formatPKR(totalExpensePaisa)}
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-[#142018] border border-[#233527]">
          <span className="text-[10px] text-gray-400 font-semibold uppercase block">
            Savings Rate
          </span>
          <div
            className={`text-sm sm:text-base font-bold tabular-nums mt-1 ${
              savingsRate >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {savingsRate}%
          </div>
        </div>
      </div>

      {/* 6-Month Income vs. Expense Comparison Chart */}
      <div className="p-6 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              6-Month Cashflow Comparison
            </h4>
            <p className="text-[10px] text-gray-400">Monthly Income (Green) vs Expense (Red)</p>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500" /> Income
            </span>
            <span className="flex items-center gap-1.5 text-rose-400">
              <span className="w-2.5 h-2.5 rounded bg-rose-500" /> Expense
            </span>
          </div>
        </div>

        {/* Visual Bar Columns */}
        <div className="h-36 flex items-end justify-between gap-3 pt-4 border-b border-[#1E2E23] pb-2">
          {past6MonthsData.map((item) => {
            const incHeight = maxMonthValue > 0 ? (item.incomePaisa / maxMonthValue) * 100 : 0;
            const expHeight = maxMonthValue > 0 ? (item.expensePaisa / maxMonthValue) * 100 : 0;

            return (
              <div key={item.monthKey} className="flex-1 flex flex-col items-center h-full justify-end">
                <div className="flex items-end gap-1 w-full justify-center h-full">
                  {/* Income bar */}
                  <div
                    className="w-3 rounded-t bg-emerald-500 transition-all"
                    style={{ height: `${Math.max(incHeight, 4)}%` }}
                    title={`Income: ${formatPKR(item.incomePaisa)}`}
                  />
                  {/* Expense bar */}
                  <div
                    className="w-3 rounded-t bg-rose-500 transition-all"
                    style={{ height: `${Math.max(expHeight, 4)}%` }}
                    title={`Expense: ${formatPKR(item.expensePaisa)}`}
                  />
                </div>
                <span className="text-[10px] font-medium text-gray-400 mt-2">{item.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expense Categories Breakdown */}
      <div className="p-6 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
          Expense Category Breakdown
        </h4>

        {sortedCategories.length > 0 ? (
          <div className="space-y-3">
            {sortedCategories.map(([catName, amountPaisa]) => {
              const catObj = categories.find((c) => c.name === catName);
              const pct =
                totalExpensePaisa > 0 ? Math.round((amountPaisa / totalExpensePaisa) * 100) : 0;
              const color = catObj?.color || '#10B981';

              return (
                <div key={catName} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${color}25` }}
                      >
                        <CategoryIcon
                          name={catObj?.icon || 'MoreHorizontal'}
                          color={color}
                          className="w-3.5 h-3.5"
                        />
                      </div>
                      <span className="font-medium text-white">{catName}</span>
                    </div>
                    <div className="tabular-nums text-right">
                      <span className="font-bold text-white">{formatPKR(amountPaisa)}</span>
                      <span className="text-gray-400 text-[11px] ml-1.5">({pct}%)</span>
                    </div>
                  </div>

                  <div className="w-full bg-[#0E1611] rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{ width: `${pct}%`, backgroundColor: color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-gray-400 text-center py-4">
            No expenses found in selected period.
          </p>
        )}
      </div>

      {/* Income Sources Breakdown */}
      {sortedIncomeCategories.length > 0 && (
        <div className="p-6 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
            Income Sources Breakdown
          </h4>

          <div className="space-y-3">
            {sortedIncomeCategories.map(([catName, amountPaisa]) => {
              const catObj = categories.find((c) => c.name === catName);
              const pct =
                totalIncomePaisa > 0 ? Math.round((amountPaisa / totalIncomePaisa) * 100) : 0;
              const color = catObj?.color || '#10B981';

              return (
                <div key={catName} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${color}25` }}
                      >
                        <CategoryIcon
                          name={catObj?.icon || 'TrendingUp'}
                          color={color}
                          className="w-3.5 h-3.5"
                        />
                      </div>
                      <span className="font-medium text-white">{catName}</span>
                    </div>
                    <div className="tabular-nums text-right">
                      <span className="font-bold text-emerald-400">+{formatPKR(amountPaisa)}</span>
                      <span className="text-gray-400 text-[11px] ml-1.5">({pct}%)</span>
                    </div>
                  </div>

                  <div className="w-full bg-[#0E1611] rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300 bg-emerald-500"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
