import React, { useState } from 'react';
import {
  Lock,
  Fingerprint,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  Smartphone,
  ShieldCheck,
  CheckCircle2,
  FileSpreadsheet,
  Info,
  Clock,
  Sparkles,
  Play,
} from 'lucide-react';
import { AppSettings, BackupData } from '../types';
import { db } from '../db/indexedDB';
import { isBiometricAvailable } from '../utils/security';

interface SettingsViewProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => Promise<void>;
  onTriggerPinSetup: () => void;
  onTriggerPinChange: () => void;
  onOpenAndroidExport: () => void;
  onOpenSelfTest: () => void;
  onLoadDemoData: () => void;
  onClearAllData: () => void;
  onRefreshAllData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onTriggerPinSetup,
  onTriggerPinChange,
  onOpenAndroidExport,
  onOpenSelfTest,
  onLoadDemoData,
  onClearAllData,
  onRefreshAllData,
}) => {
  const [showClearConfirm, setShowClearConfirm] = useState<boolean>(false);
  const [clearInputConfirm, setClearInputConfirm] = useState<string>('');
  const [importStatus, setImportStatus] = useState<string>('');
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // JSON Backup Export
  const handleExportBackup = async () => {
    setIsExporting(true);
    try {
      const backup = await db.exportCompleteBackup();
      const jsonStr = JSON.stringify(backup, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const nowStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `PocketHisabPro_Backup_${nowStr}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export backup failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  // JSON Backup File Restore
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus('Reading backup file...');
    try {
      const text = await file.text();
      const backup: BackupData = JSON.parse(text);

      if (!backup.appName || !backup.data) {
        throw new Error('Invalid Pocket Hisab Pro backup file.');
      }

      const res = await db.importBackup(backup, 'replace');
      setImportStatus(
        `Successfully restored ${res.stats.transactions} transactions, ${res.stats.debts} debts, and ${res.stats.budgets} budgets.`
      );
      onRefreshAllData();
      setTimeout(() => setImportStatus(''), 5000);
    } catch (err: any) {
      setImportStatus(`Restore error: ${err?.message || 'Failed to parse JSON file'}`);
    }
    // reset input
    e.target.value = '';
  };

  // Toggle PIN
  const handleTogglePin = async () => {
    if (settings.pinEnabled) {
      // disable pin
      await onUpdateSettings({ pinEnabled: false, pinHash: undefined, pinSalt: undefined });
    } else {
      // open pin setup
      onTriggerPinSetup();
    }
  };

  // Toggle Biometric
  const handleToggleBiometric = async () => {
    const isAvail = await isBiometricAvailable();
    if (!isAvail && !settings.biometricEnabled) {
      alert('Biometric authentication is not supported by your current browser / device.');
      return;
    }
    await onUpdateSettings({ biometricEnabled: !settings.biometricEnabled });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* App & Security Summary */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-[#122017] to-[#0A120E] border border-[#233527] space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">Pocket Hisab Pro</h3>
            <span className="text-xs text-emerald-400 font-medium">
              Version 1.0.0 · Offline-First Engine
            </span>
          </div>
        </div>
        <p className="text-xs text-gray-300 leading-relaxed">
          Zero data leaves your device. All calculations, transactions, udhaar, and budgets are
          stored locally inside an encrypted IndexedDB sandbox.
        </p>
      </div>

      {/* Android Native APK & Kotlin Export */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <div>
              <h4 className="text-xs font-bold text-white">Android APK & Native Project</h4>
              <p className="text-[10px] text-gray-400">
                PWA installer, Capacitor APK commands, & Kotlin Room code
              </p>
            </div>
          </div>
          <button
            onClick={onOpenAndroidExport}
            className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
          >
            Open Exporter
          </button>
        </div>
      </div>

      {/* Automated Verification Suite */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Play className="w-5 h-5 text-emerald-400" />
            <div>
              <h4 className="text-xs font-bold text-white">Automated Self-Test Suite</h4>
              <p className="text-[10px] text-gray-400">
                10 automated unit tests for math, DB, budgets, and offline integrity
              </p>
            </div>
          </div>
          <button
            onClick={onOpenSelfTest}
            className="px-3.5 py-2 bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-emerald-300 font-semibold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Run Tests
          </button>
        </div>
      </div>

      {/* Currency Settings */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Currency Display</h4>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-[11px] text-gray-400 block mb-1">Currency Symbol:</label>
            <select
              value={settings.currencySymbol}
              onChange={(e) =>
                onUpdateSettings({ currencySymbol: e.target.value as 'Rs.' | 'PKR' })
              }
              className="w-full bg-[#0E1611] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="Rs.">Rs. (Pakistani Rupees)</option>
              <option value="PKR">PKR (ISO 4217)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-gray-400 block mb-1">Symbol Position:</label>
            <select
              value={settings.symbolPosition}
              onChange={(e) =>
                onUpdateSettings({ symbolPosition: e.target.value as 'prefix' | 'suffix' })
              }
              className="w-full bg-[#0E1611] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
            >
              <option value="prefix">Prefix (Rs. 5,000)</option>
              <option value="suffix">Suffix (5,000 Rs.)</option>
            </select>
          </div>
        </div>
      </div>

      {/* PIN & Biometric Security */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
          Security & Privacy
        </h4>

        {/* PIN Toggle */}
        <div className="flex items-center justify-between py-1">
          <div className="flex items-center gap-2.5">
            <Lock className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-xs font-semibold text-white block">4-Digit App PIN Lock</span>
              <span className="text-[10px] text-gray-400">
                {settings.pinEnabled ? 'PIN lock active' : 'Disabled'}
              </span>
            </div>
          </div>
          <button
            onClick={handleTogglePin}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.pinEnabled ? 'bg-emerald-500' : 'bg-gray-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                settings.pinEnabled ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        {settings.pinEnabled && (
          <div className="pt-2 flex items-center justify-between border-t border-[#1E2E23]">
            <span className="text-xs text-gray-400">Modify existing security PIN:</span>
            <button
              onClick={onTriggerPinChange}
              className="text-xs text-emerald-400 hover:underline font-semibold"
            >
              Change PIN
            </button>
          </div>
        )}

        {/* Biometric Toggle */}
        <div className="flex items-center justify-between py-1 border-t border-[#1E2E23]">
          <div className="flex items-center gap-2.5">
            <Fingerprint className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-xs font-semibold text-white block">
                Fingerprint / Face Unlock
              </span>
              <span className="text-[10px] text-gray-400">Android WebAuthn Biometrics</span>
            </div>
          </div>
          <button
            onClick={handleToggleBiometric}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.biometricEnabled ? 'bg-emerald-500' : 'bg-gray-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                settings.biometricEnabled ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        {/* Auto Lock Timeout */}
        <div className="flex items-center justify-between py-1 border-t border-[#1E2E23]">
          <div className="flex items-center gap-2.5">
            <Clock className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-xs font-semibold text-white block">Auto-Lock Inactivity</span>
              <span className="text-[10px] text-gray-400">Lock screen automatically</span>
            </div>
          </div>
          <select
            value={settings.autoLockMinutes}
            onChange={(e) => onUpdateSettings({ autoLockMinutes: parseInt(e.target.value, 10) })}
            className="bg-[#0E1611] border border-[#233527] rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
          >
            <option value="0">Immediately on Exit</option>
            <option value="1">After 1 Minute</option>
            <option value="5">After 5 Minutes</option>
            <option value="15">After 15 Minutes</option>
            <option value="-1">Disabled</option>
          </select>
        </div>
      </div>

      {/* Backup and Restore */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
          Backup & Data Portability
        </h4>

        {importStatus && (
          <div className="p-3 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-medium">
            {importStatus}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleExportBackup}
            disabled={isExporting}
            className="py-3 px-3 rounded-2xl bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export JSON Backup</span>
          </button>

          <label className="py-3 px-3 rounded-2xl bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer text-center">
            <Upload className="w-4 h-4 text-emerald-400" />
            <span>Restore JSON File</span>
            <input
              type="file"
              accept=".json"
              onChange={handleImportFile}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Demo & Reset Controls */}
      <div className="p-5 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider">Data Operations</h4>

        <div className="space-y-2.5">
          <button
            onClick={onLoadDemoData}
            className="w-full py-3 rounded-2xl bg-[#1C2C22] hover:bg-[#25392D] border border-[#2D4535] text-emerald-300 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Load Realistic Demo Data (PKR)</span>
          </button>

          <button
            onClick={() => setShowClearConfirm(true)}
            className="w-full py-3 rounded-2xl bg-rose-950/30 hover:bg-rose-950/60 border border-rose-900/50 text-rose-400 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>Reset / Wipe All Local Data</span>
          </button>
        </div>
      </div>

      {/* Double Confirmation Modal for Wipe */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#0F1713] border border-rose-500/40 p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-950/80 border border-rose-500/30 flex items-center justify-center text-rose-400 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <h4 className="text-base font-bold text-white">Reset All Application Data?</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              This will permanently delete all your transactions, budgets, udhaar debts, and
              savings goals from this device. This cannot be undone.
            </p>

            <div className="space-y-1 text-left">
              <label className="text-[10px] text-gray-400 block font-medium">
                Type <strong>DELETE</strong> to confirm:
              </label>
              <input
                type="text"
                placeholder="DELETE"
                value={clearInputConfirm}
                onChange={(e) => setClearInputConfirm(e.target.value)}
                className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white text-center font-bold tracking-widest focus:outline-none focus:border-rose-500"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  setShowClearConfirm(false);
                  setClearInputConfirm('');
                }}
                className="flex-1 py-2.5 rounded-xl border border-[#233527] text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                disabled={clearInputConfirm.trim() !== 'DELETE'}
                onClick={() => {
                  onClearAllData();
                  setShowClearConfirm(false);
                  setClearInputConfirm('');
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold disabled:opacity-40"
              >
                Permanently Wipe
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
