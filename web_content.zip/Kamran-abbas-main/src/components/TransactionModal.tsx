import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, CreditCard, Banknote, Smartphone, Plus, Check } from 'lucide-react';
import { Transaction, TransactionType, PaymentMethod, Category } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { parseRupeesToPaisa, paisaToRupees } from '../utils/currency';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<void>;
  initialTransaction?: Transaction | null;
  categories: Category[];
  onAddCategory: (category: Omit<Category, 'id'>) => Promise<Category>;
  defaultType?: TransactionType;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialTransaction,
  categories,
  onAddCategory,
  defaultType = 'expense',
}) => {
  const [type, setType] = useState<TransactionType>(defaultType);
  const [amountInput, setAmountInput] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Custom Category Modal / Inline
  const [showNewCatInput, setShowNewCatInput] = useState<boolean>(false);
  const [newCatName, setNewCatName] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      if (initialTransaction) {
        setType(initialTransaction.type);
        setAmountInput(paisaToRupees(initialTransaction.amountPaisa).toString());
        setCategory(initialTransaction.category);
        setPaymentMethod(initialTransaction.paymentMethod);
        setDate(initialTransaction.date);
        setTime(initialTransaction.time || '12:00');
        setNote(initialTransaction.note || '');
      } else {
        const now = new Date();
        const y = now.getFullYear();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const d = String(now.getDate()).padStart(2, '0');
        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');

        setType(defaultType);
        setAmountInput('');
        const matchingCats = categories.filter((c) => c.type === defaultType);
        setCategory(matchingCats.length > 0 ? matchingCats[0].name : '');
        setPaymentMethod('cash');
        setDate(`${y}-${m}-${d}`);
        setTime(`${hh}:${mm}`);
        setNote('');
      }
      setError('');
      setShowNewCatInput(false);
      setNewCatName('');
    }
  }, [isOpen, initialTransaction, defaultType, categories]);

  if (!isOpen) return null;

  const currentTypeCategories = categories.filter((c) => c.type === type);

  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    const available = categories.filter((c) => c.type === newType);
    if (!available.some((c) => c.name === category)) {
      setCategory(available.length > 0 ? available[0].name : '');
    }
  };

  const handleCreateCategory = async () => {
    if (!newCatName.trim()) return;
    try {
      const created = await onAddCategory({
        name: newCatName.trim(),
        type,
        icon: 'Sparkles',
        color: type === 'income' ? '#10B981' : '#F43F5E',
      });
      setCategory(created.name);
      setNewCatName('');
      setShowNewCatInput(false);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const paisa = parseRupeesToPaisa(amountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid amount greater than 0.');
      return;
    }

    if (!category) {
      setError('Please select or specify a category.');
      return;
    }

    if (!date) {
      setError('Please select a transaction date.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        id: initialTransaction ? initialTransaction.id : undefined,
        type,
        amountPaisa: paisa,
        category,
        paymentMethod,
        date,
        time,
        note: note.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const setDateToToday = () => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    setDate(`${y}-${m}-${d}`);
  };

  const setDateToYesterday = () => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const y = yesterday.getFullYear();
    const m = String(yesterday.getMonth() + 1).padStart(2, '0');
    const d = String(yesterday.getDate()).padStart(2, '0');
    setDate(`${y}-${m}-${d}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-lg bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header with Grab Handle on mobile */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white tracking-tight">
              {initialTransaction ? 'Edit Transaction' : 'New Transaction'}
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Segmented Type Toggle */}
          <div className="grid grid-cols-2 p-1 bg-[#16231A] rounded-xl mt-3 border border-[#233527]">
            <button
              type="button"
              onClick={() => handleTypeChange('expense')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                type === 'expense'
                  ? 'bg-rose-500 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Expense (Kharcha)
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('income')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all ${
                type === 'income'
                  ? 'bg-emerald-500 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              Income (Aamdani)
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Amount Input with PKR Indicator */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Amount (Rs. / PKR) *
            </label>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="0"
                autoFocus
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Category Selection Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-gray-400">Category *</label>
              <button
                type="button"
                onClick={() => setShowNewCatInput(!showNewCatInput)}
                className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-medium"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Custom Category</span>
              </button>
            </div>

            {showNewCatInput && (
              <div className="flex gap-2 mb-3 p-2 rounded-xl bg-[#17261D] border border-[#283E2F]">
                <input
                  type="text"
                  placeholder="Category Name..."
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  className="flex-1 bg-transparent text-xs text-white placeholder-gray-500 focus:outline-none px-2"
                />
                <button
                  type="button"
                  onClick={handleCreateCategory}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium rounded-lg"
                >
                  Save
                </button>
              </div>
            )}

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-40 overflow-y-auto pr-1">
              {currentTypeCategories.map((cat) => {
                const isSelected = category === cat.name;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.name)}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl text-center border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-950/60 border-emerald-500 text-white shadow-sm'
                        : 'bg-[#142018] border-[#223528] text-gray-400 hover:text-gray-200 hover:border-gray-600'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center mb-1"
                      style={{ backgroundColor: `${cat.color}25` }}
                    >
                      <CategoryIcon name={cat.icon} color={cat.color} className="w-4 h-4" />
                    </div>
                    <span className="text-[11px] font-medium leading-tight truncate w-full">
                      {cat.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Payment Method
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'cash', label: 'Cash (Naqad)', icon: Banknote },
                { id: 'bank', label: 'Bank / IBFT', icon: CreditCard },
                { id: 'other', label: 'Wallet / Digital', icon: Smartphone },
              ].map((pm) => {
                const Icon = pm.icon;
                const isSelected = paymentMethod === pm.id;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                    className={`flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl text-xs font-medium border transition-all ${
                      isSelected
                        ? 'bg-[#1B2F22] border-emerald-500 text-emerald-400'
                        : 'bg-[#142018] border-[#223528] text-gray-400 hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{pm.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Time Picker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-gray-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" /> Date
                </label>
                <div className="flex gap-1.5 text-[10px]">
                  <button
                    type="button"
                    onClick={setDateToToday}
                    className="text-emerald-400 hover:underline"
                  >
                    Today
                  </button>
                  <span>·</span>
                  <button
                    type="button"
                    onClick={setDateToYesterday}
                    className="text-gray-400 hover:underline"
                  >
                    Yesterday
                  </button>
                </div>
              </div>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Time
              </label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Description / Note */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Note or Description (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Grocery from Imtiaz, car repair, freelance project..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>{initialTransaction ? 'Update Record' : 'Save Transaction'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
