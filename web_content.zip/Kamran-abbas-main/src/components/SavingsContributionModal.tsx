import React, { useState, useEffect } from 'react';
import { X, Check, ArrowDownLeft, ArrowUpRight, Calendar } from 'lucide-react';
import { SavingsGoal } from '../types';
import { formatPKR, parseRupeesToPaisa } from '../utils/currency';

interface SavingsContributionModalProps {
  isOpen: boolean;
  onClose: () => void;
  goal: SavingsGoal | null;
  onSave: (contribution: {
    goalId: string;
    type: 'deposit' | 'withdrawal';
    amountPaisa: number;
    date: string;
    note?: string;
  }) => Promise<void>;
}

export const SavingsContributionModal: React.FC<SavingsContributionModalProps> = ({
  isOpen,
  onClose,
  goal,
  onSave,
}) => {
  const [type, setType] = useState<'deposit' | 'withdrawal'>('deposit');
  const [amountInput, setAmountInput] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && goal) {
      setType('deposit');
      setAmountInput('');
      const now = new Date();
      const y = now.getFullYear();
      const m = String(now.getMonth() + 1).padStart(2, '0');
      const d = String(now.getDate()).padStart(2, '0');
      setDate(`${y}-${m}-${d}`);
      setNote('');
      setError('');
    }
  }, [isOpen, goal]);

  if (!isOpen || !goal) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const paisa = parseRupeesToPaisa(amountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid amount.');
      return;
    }

    if (type === 'withdrawal' && paisa > goal.savedAmountPaisa) {
      setError(
        `Withdrawal (${formatPKR(paisa)}) cannot exceed current savings (${formatPKR(
          goal.savedAmountPaisa
        )}).`
      );
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        goalId: goal.id,
        type,
        amountPaisa: paisa,
        date,
        note: note.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to update goal funds.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">Update Goal Funds</h3>
              <p className="text-xs text-gray-400 mt-0.5">{goal.name}</p>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Type Segmented Control */}
          <div className="grid grid-cols-2 p-1 bg-[#16231A] rounded-xl mt-3 border border-[#233527]">
            <button
              type="button"
              onClick={() => setType('deposit')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                type === 'deposit'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <ArrowDownLeft className="w-4 h-4" />
              <span>Add Savings</span>
            </button>
            <button
              type="button"
              onClick={() => setType('withdrawal')}
              className={`py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                type === 'withdrawal'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <ArrowUpRight className="w-4 h-4" />
              <span>Withdraw Funds</span>
            </button>
          </div>
        </div>

        {/* Current State */}
        <div className="bg-[#142018] border-b border-[#1E2E23] px-6 py-3 flex items-center justify-between">
          <span className="text-xs text-gray-400">Current Saved Balance:</span>
          <span className="text-sm font-bold text-emerald-400">
            {formatPKR(goal.savedAmountPaisa)} / {formatPKR(goal.targetAmountPaisa)}
          </span>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Amount */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              {type === 'deposit' ? 'Deposit Amount (PKR) *' : 'Withdrawal Amount (PKR) *'}
            </label>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="10000"
                autoFocus
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" /> Date *
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Note */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Note (Optional)</label>
            <input
              type="text"
              placeholder="e.g. Transferred from monthly bonus..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`flex-1 py-3 rounded-xl font-bold text-xs text-white shadow-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                type === 'deposit'
                  ? 'bg-emerald-500 hover:bg-emerald-400 shadow-emerald-500/20'
                  : 'bg-amber-600 hover:bg-amber-500 shadow-amber-600/20'
              }`}
            >
              <Check className="w-4 h-4" />
              <span>{type === 'deposit' ? 'Confirm Deposit' : 'Confirm Withdrawal'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
