import React from 'react';
import {
  Briefcase,
  Store,
  Laptop,
  Gift,
  Home,
  TrendingUp,
  PlusCircle,
  Utensils,
  Car,
  GraduationCap,
  Smartphone,
  ShoppingBag,
  Zap,
  HeartPulse,
  Film,
  Users,
  Building,
  HeartHandshake,
  MoreHorizontal,
  Wallet,
  ShieldCheck,
  Target,
  Plane,
  Baby,
  PiggyBank,
  Sparkles,
} from 'lucide-react';

interface CategoryIconProps {
  name: string;
  className?: string;
  color?: string;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ name, className = 'w-5 h-5', color }) => {
  const iconProps = {
    className,
    style: color ? { color } : undefined,
  };

  switch (name) {
    case 'Briefcase':
      return <Briefcase {...iconProps} />;
    case 'Store':
      return <Store {...iconProps} />;
    case 'Laptop':
      return <Laptop {...iconProps} />;
    case 'Gift':
      return <Gift {...iconProps} />;
    case 'Home':
      return <Home {...iconProps} />;
    case 'TrendingUp':
      return <TrendingUp {...iconProps} />;
    case 'PlusCircle':
      return <PlusCircle {...iconProps} />;
    case 'Utensils':
      return <Utensils {...iconProps} />;
    case 'Car':
      return <Car {...iconProps} />;
    case 'GraduationCap':
      return <GraduationCap {...iconProps} />;
    case 'Smartphone':
      return <Smartphone {...iconProps} />;
    case 'ShoppingBag':
      return <ShoppingBag {...iconProps} />;
    case 'Zap':
      return <Zap {...iconProps} />;
    case 'HeartPulse':
      return <HeartPulse {...iconProps} />;
    case 'Film':
      return <Film {...iconProps} />;
    case 'Users':
      return <Users {...iconProps} />;
    case 'Building':
      return <Building {...iconProps} />;
    case 'HeartHandshake':
      return <HeartHandshake {...iconProps} />;
    case 'ShieldCheck':
      return <ShieldCheck {...iconProps} />;
    case 'Target':
      return <Target {...iconProps} />;
    case 'Plane':
      return <Plane {...iconProps} />;
    case 'Baby':
      return <Baby {...iconProps} />;
    case 'PiggyBank':
      return <PiggyBank {...iconProps} />;
    case 'Wallet':
      return <Wallet {...iconProps} />;
    case 'Sparkles':
      return <Sparkles {...iconProps} />;
    default:
      return <MoreHorizontal {...iconProps} />;
  }
};
