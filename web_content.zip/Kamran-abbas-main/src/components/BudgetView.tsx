import React, { useState } from 'react';
import {
  PieChart,
  Plus,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Trash2,
  CheckCircle2,
} from 'lucide-react';
import { Budget, Transaction, Category } from '../types';
import { formatPKR, formatMonthName, shiftMonthKey } from '../utils/currency';
import { CategoryIcon } from './CategoryIcon';

interface BudgetViewProps {
  activeMonth: string;
  setActiveMonth: (month: string) => void;
  budgets: Budget[];
  transactions: Transaction[];
  categories: Category[];
  onOpenBudgetModal: (budget?: Budget) => void;
  onDeleteBudget: (id: string) => Promise<void>;
}

export const BudgetView: React.FC<BudgetViewProps> = ({
  activeMonth,
  setActiveMonth,
  budgets,
  transactions,
  categories,
  onOpenBudgetModal,
  onDeleteBudget,
}) => {
  const [budgetToDelete, setBudgetToDelete] = useState<Budget | null>(null);

  // Month transactions
  const monthTransactions = transactions.filter((t) => t.date.startsWith(activeMonth));
  const monthExpenses = monthTransactions.filter((t) => t.type === 'expense');

  // Month budgets
  const monthBudgets = budgets.filter((b) => b.month === activeMonth);
  const totalBudget = monthBudgets.find((b) => b.category === '_total_');
  const categoryBudgets = monthBudgets.filter((b) => b.category !== '_total_');

  // Total month spending
  const totalSpentPaisa = monthExpenses.reduce((sum, t) => sum + t.amountPaisa, 0);

  // Total budget metrics
  const totalBudgetLimitPaisa = totalBudget ? totalBudget.amountPaisa : 0;
  const totalPercentUsed =
    totalBudgetLimitPaisa > 0 ? Math.round((totalSpentPaisa / totalBudgetLimitPaisa) * 100) : 0;
  const totalRemainingPaisa = Math.max(0, totalBudgetLimitPaisa - totalSpentPaisa);

  // Category spending map
  const categorySpentMap: Record<string, number> = {};
  monthExpenses.forEach((t) => {
    categorySpentMap[t.category] = (categorySpentMap[t.category] || 0) + t.amountPaisa;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Month Navigation Strip */}
      <div className="flex items-center justify-between bg-[#142018] border border-[#233527] rounded-2xl px-4 py-2.5">
        <button
          onClick={() => setActiveMonth(shiftMonthKey(activeMonth, -1))}
          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
          title="Previous Month"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="text-center">
          <span className="text-sm font-bold text-white tracking-tight">
            {formatMonthName(activeMonth)}
          </span>
          <span className="text-[10px] text-emerald-400 block font-medium">Budget Targets</span>
        </div>

        <button
          onClick={() => setActiveMonth(shiftMonthKey(activeMonth, 1))}
          className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
          title="Next Month"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Overall Budget Overview Card */}
      {totalBudget ? (
        <div className="p-6 rounded-3xl bg-[#142018] border border-[#233527] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider block">
                Overall Monthly Limit
              </span>
              <div className="text-2xl font-bold text-white tabular-nums mt-0.5">
                {formatPKR(totalBudget.amountPaisa)}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenBudgetModal(totalBudget)}
                className="p-2 rounded-xl bg-[#1C2C22] hover:bg-[#25392D] text-gray-300 hover:text-white transition-colors"
                title="Edit Budget"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setBudgetToDelete(totalBudget)}
                className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-950/70 text-rose-400 transition-colors"
                title="Delete Budget"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Status Alert if >=80% or >=100% */}
          {totalPercentUsed >= 100 ? (
            <div className="p-3 rounded-2xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>
                <strong>Budget Exceeded!</strong> You have spent {totalPercentUsed}% of your
                allocated monthly budget limit.
              </span>
            </div>
          ) : totalPercentUsed >= 80 ? (
            <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
              <span>
                <strong>80% Threshold Warning!</strong> You have used {totalPercentUsed}% of your
                total limit. Only {formatPKR(totalRemainingPaisa)} remaining.
              </span>
            </div>
          ) : null}

          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs tabular-nums text-gray-400">
              <span>{totalPercentUsed}% Utilized</span>
              <span>{formatPKR(totalRemainingPaisa)} Left</span>
            </div>
            <div className="w-full bg-[#0E1611] rounded-full h-3 overflow-hidden p-0.5 border border-[#233527]">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  totalPercentUsed >= 100
                    ? 'bg-rose-500'
                    : totalPercentUsed >= 80
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${Math.min(totalPercentUsed, 100)}%` }}
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-xs tabular-nums pt-1 border-t border-[#1E2E23]">
            <span className="text-gray-400">Total Spent this Month:</span>
            <span className="font-bold text-white">{formatPKR(totalSpentPaisa)}</span>
          </div>
        </div>
      ) : (
        <div className="p-6 rounded-3xl bg-[#142018] border border-dashed border-[#233527] text-center space-y-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-950/60 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
            <PieChart className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">No Overall Budget for {formatMonthName(activeMonth)}</h4>
            <p className="text-xs text-gray-400 max-w-xs mx-auto mt-0.5">
              Set an overall monthly spending ceiling to stay on top of your financial goals.
            </p>
          </div>
          <button
            onClick={() => onOpenBudgetModal()}
            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold text-xs transition-colors"
          >
            + Set Overall Budget
          </button>
        </div>
      )}

      {/* Category-Specific Budgets Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-tight">Category-Specific Budgets</h3>
          <button
            onClick={() => onOpenBudgetModal()}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Category Limit</span>
          </button>
        </div>

        {categoryBudgets.length > 0 ? (
          <div className="space-y-3">
            {categoryBudgets.map((b) => {
              const spentPaisa = categorySpentMap[b.category] || 0;
              const percentUsed =
                b.amountPaisa > 0 ? Math.round((spentPaisa / b.amountPaisa) * 100) : 0;
              const remainingPaisa = Math.max(0, b.amountPaisa - spentPaisa);
              const catObj = categories.find((c) => c.name === b.category);

              return (
                <div
                  key={b.id}
                  className="p-4 rounded-2xl bg-[#142018] border border-[#233527] space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${catObj?.color || '#10B981'}25` }}
                      >
                        <CategoryIcon
                          name={catObj?.icon || 'MoreHorizontal'}
                          color={catObj?.color || '#10B981'}
                          className="w-4 h-4"
                        />
                      </div>
                      <div>
                        <h4 className="text-xs font-semibold text-white">{b.category}</h4>
                        <span className="text-[10px] text-gray-400 tabular-nums">
                          Budget: {formatPKR(b.amountPaisa)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onOpenBudgetModal(b)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1C2C22] transition-colors"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setBudgetToDelete(b)}
                        className="p-1.5 rounded-lg text-gray-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Category Progress Bar */}
                  <div className="w-full bg-[#0E1611] rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        percentUsed >= 100
                          ? 'bg-rose-500'
                          : percentUsed >= 80
                          ? 'bg-amber-500'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(percentUsed, 100)}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-[11px] tabular-nums text-gray-400">
                    <span>
                      Spent: <strong className="text-white">{formatPKR(spentPaisa)}</strong> (
                      {percentUsed}%)
                    </span>
                    <span>
                      Remaining: <strong className="text-emerald-400">{formatPKR(remainingPaisa)}</strong>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-[#142018] border border-dashed border-[#233527] text-center text-xs text-gray-400">
            No category budgets created for this month. Set individual limits for Food, Fuel, or
            Utilities to prevent overspending.
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {budgetToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#0F1713] border border-[#233527] p-6 text-center space-y-4">
            <h4 className="text-sm font-bold text-white">Delete Budget</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              Are you sure you want to delete the budget for{' '}
              <strong className="text-white">
                {budgetToDelete.category === '_total_' ? 'Overall Monthly' : budgetToDelete.category}
              </strong>
              ?
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setBudgetToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-[#233527] text-gray-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  await onDeleteBudget(budgetToDelete.id);
                  setBudgetToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
