import React, { useState, useEffect } from 'react';
import { X, Check } from 'lucide-react';
import { Budget, Category } from '../types';
import { parseRupeesToPaisa, paisaToRupees } from '../utils/currency';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (budget: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }) => Promise<void>;
  initialBudget?: Budget | null;
  activeMonth: string;
  categories: Category[];
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialBudget,
  activeMonth,
  categories,
}) => {
  const [category, setCategory] = useState<string>('_total_');
  const [amountInput, setAmountInput] = useState<string>('');
  const [month, setMonth] = useState<string>(activeMonth);
  const [error, setError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const expenseCategories = categories.filter((c) => c.type === 'expense');

  useEffect(() => {
    if (isOpen) {
      if (initialBudget) {
        setCategory(initialBudget.category);
        setAmountInput(paisaToRupees(initialBudget.amountPaisa).toString());
        setMonth(initialBudget.month);
      } else {
        setCategory('_total_');
        setAmountInput('');
        setMonth(activeMonth);
      }
      setError('');
    }
  }, [isOpen, initialBudget, activeMonth]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const paisa = parseRupeesToPaisa(amountInput);
    if (!paisa || paisa <= 0) {
      setError('Please enter a valid monthly budget amount.');
      return;
    }

    setIsSubmitting(true);
    try {
      await onSave({
        id: initialBudget ? initialBudget.id : undefined,
        month,
        category,
        amountPaisa: paisa,
      });
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to save budget.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full sm:max-w-md bg-[#0F1713] border border-[#233527] sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-slide-up">
        {/* Header */}
        <div className="pt-3 px-6 pb-4 border-b border-[#1E2E23]">
          <div className="w-12 h-1.5 bg-gray-700 rounded-full mx-auto mb-3 sm:hidden" />
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white tracking-tight">
              {initialBudget ? 'Edit Monthly Budget' : 'Set Monthly Budget'}
            </h3>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-[#1A281F] transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Month Input */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">Budget Month</label>
            <input
              type="month"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              required
            />
          </div>

          {/* Category Scope */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Budget Target Scope
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full bg-[#142018] border border-[#233527] rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              <option value="_total_">★ Overall Total Monthly Budget</option>
              <optgroup label="Specific Categories">
                {expenseCategories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </optgroup>
            </select>
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Budget Limit (PKR) *
            </label>
            <div className="relative rounded-2xl bg-[#142018] border border-[#233527] focus-within:border-emerald-500 transition-colors p-3 flex items-center">
              <span className="text-emerald-400 font-bold text-xl mr-2">₨</span>
              <input
                type="number"
                step="any"
                min="0"
                placeholder="50000"
                autoFocus
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                className="w-full bg-transparent text-2xl font-bold text-white placeholder-gray-600 focus:outline-none tabular-nums"
                required
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-3 flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-[#243729] text-gray-400 hover:text-white font-medium text-xs transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              <span>Save Budget</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
