/**
 * Pocket Hisab Pro - Offline Local Security Utilities
 * Uses Web Crypto API for salted PIN hashing and WebAuthn for Android Biometrics.
 * Zero plain text storage. Zero cloud exposure.
 */

// Generate a cryptographically secure random hex salt
export function generateSalt(length = 16): string {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// Compute salted SHA-256 hash using the Web Crypto API
export async function hashPin(
  pin: string,
  existingSalt?: string
): Promise<{ hash: string; salt: string }> {
  const salt = existingSalt || generateSalt();
  const encoder = new TextEncoder();
  const data = encoder.encode(`PocketHisabPro:${salt}:${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hash = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  return { hash, salt };
}

// Verify a user entered PIN against stored hash
export async function verifyPin(
  enteredPin: string,
  storedHash: string,
  storedSalt: string
): Promise<boolean> {
  if (!enteredPin || !storedHash || !storedSalt) return false;
  const { hash } = await hashPin(enteredPin, storedSalt);
  return hash === storedHash;
}

// Check if device supports Biometric Authentication (Android Fingerprint / Face Unlock / Windows Hello / Touch ID)
export async function isBiometricAvailable(): Promise<boolean> {
  try {
    if (
      typeof window !== 'undefined' &&
      window.PublicKeyCredential &&
      typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function'
    ) {
      return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
  } catch (err) {
    console.warn('Biometric availability check failed:', err);
  }
  return false;
}

// Prompt Biometric verification using WebAuthn credential assertion
export async function authenticateBiometric(): Promise<boolean> {
  try {
    if (!window.PublicKeyCredential) return false;

    // Challenge for local assertion
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);

    // Dummy user ID for credential creation/assertion
    const userId = new Uint8Array(16);
    crypto.getRandomValues(userId);

    // Perform verification request
    const credential = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: 'Pocket Hisab Pro' },
        user: {
          id: userId,
          name: 'user@pockethisab.pro',
          displayName: 'Pocket Hisab User',
        },
        pubKeyCredParams: [{ alg: -7, type: 'public-key' }, { alg: -257, type: 'public-key' }],
        authenticatorSelection: {
          authenticatorAttachment: 'platform',
          userVerification: 'required',
        },
        timeout: 60000,
      },
    });

    return !!credential;
  } catch (err) {
    console.warn('Biometric authentication failed or canceled:', err);
    return false;
  }
}
