/**
 * Currency & Precision Math Utilities for Pakistani Rupee (PKR / Rs.)
 * Uses integer paisa arithmetic to eliminate floating point issues.
 */

export function paisaToRupees(paisa: number): number {
  if (isNaN(paisa)) return 0;
  return paisa / 100;
}

export function rupeesToPaisa(rupees: number): number {
  if (isNaN(rupees)) return 0;
  return Math.round(rupees * 100);
}

/**
 * Format paisa into localized Pakistani Rupee string.
 * Example: 1540000 paisa -> "Rs. 15,400"
 */
export function formatPKR(
  paisa: number,
  symbol: 'Rs.' | 'PKR' = 'Rs.',
  position: 'prefix' | 'suffix' = 'prefix',
  options?: { showDecimals?: boolean; includeSign?: boolean }
): string {
  const isNegative = paisa < 0;
  const absPaisa = Math.abs(paisa);
  const rupees = absPaisa / 100;

  // Format with thousands separator
  const hasDecimals = absPaisa % 100 !== 0 || options?.showDecimals;
  const formattedNumber = rupees.toLocaleString('en-PK', {
    minimumFractionDigits: hasDecimals ? 2 : 0,
    maximumFractionDigits: 2,
  });

  const sign = isNegative ? '-' : options?.includeSign ? '+' : '';
  const textWithSymbol =
    position === 'prefix'
      ? `${sign}${symbol} ${formattedNumber}`
      : `${sign}${formattedNumber} ${symbol}`;

  return textWithSymbol;
}

/**
 * Safely parse numeric input string to paisa, rejecting negatives and invalids
 */
export function parseRupeesToPaisa(input: string | number): number | null {
  if (typeof input === 'number') {
    if (isNaN(input) || input <= 0) return null;
    return Math.round(input * 100);
  }

  const clean = input.trim().replace(/,/g, '');
  if (!clean || !/^\d+(\.\d{1,2})?$/.test(clean)) {
    return null;
  }

  const val = parseFloat(clean);
  if (isNaN(val) || val <= 0) return null;
  return Math.round(val * 100);
}

/**
 * Get current year-month key in YYYY-MM format
 */
export function getCurrentMonthKey(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `${year}-${month}`;
}

/**
 * Format YYYY-MM into readable month and year, e.g. "October 2026"
 */
export function formatMonthName(monthKey: string): string {
  if (!monthKey || !monthKey.includes('-')) return '';
  const [year, month] = monthKey.split('-').map(Number);
  const date = new Date(year, month - 1, 1);
  return date.toLocaleDateString('en-PK', { month: 'long', year: 'numeric' });
}

/**
 * Shift month by offset (-1 for previous, +1 for next)
 */
export function shiftMonthKey(monthKey: string, offset: number): string {
  const [year, month] = monthKey.split('-').map(Number);
  const date = new Date(year, month - 1 + offset, 1);
  const newYear = date.getFullYear();
  const newMonth = String(date.getMonth() + 1).padStart(2, '0');
  return `${newYear}-${newMonth}`;
}

/**
 * Format ISO date string into readable date: "28 Oct 2026" or "Today"
 */
export function formatDisplayDate(dateStr: string): string {
  if (!dateStr) return '';
  const [y, m, d] = dateStr.split('T')[0].split('-').map(Number);
  const date = new Date(y, m - 1, d);

  const today = new Date();
  const isToday =
    today.getFullYear() === y &&
    today.getMonth() === m - 1 &&
    today.getDate() === d;

  if (isToday) return 'Today';

  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const isYesterday =
    yesterday.getFullYear() === y &&
    yesterday.getMonth() === m - 1 &&
    yesterday.getDate() === d;

  if (isYesterday) return 'Yesterday';

  return date.toLocaleDateString('en-PK', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}
