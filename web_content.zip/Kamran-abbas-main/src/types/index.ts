/**
 * Pocket Hisab Pro - Domain Type Definitions
 * All monetary amounts are internally stored in Paisa (1 Rupee = 100 Paisa)
 * to ensure 100% precision with zero IEEE-754 floating-point rounding errors.
 */

export type TransactionType = 'income' | 'expense';
export type PaymentMethod = 'cash' | 'bank' | 'other';

export interface Transaction {
  id: string;
  type: TransactionType;
  amountPaisa: number; // Stored in Paisa (e.g. 50000 = Rs. 500.00)
  category: string;
  paymentMethod: PaymentMethod;
  date: string; // Format: YYYY-MM-DD
  time?: string; // Format: HH:mm
  note?: string;
  createdAt: number;
  updatedAt: number;
}

export interface Category {
  id: string;
  name: string;
  type: TransactionType;
  icon: string; // Lucide icon name
  color: string;
  isCustom?: boolean;
}

export interface Budget {
  id: string;
  month: string; // Format: YYYY-MM
  category: string; // '_total_' for overall budget or specific category name
  amountPaisa: number;
  createdAt: number;
  updatedAt: number;
}

export type DebtType = 'lent' | 'borrowed';
// lent = Money I Lent to someone (Mujhe wapis milna hai / Receivable)
// borrowed = Money I Borrowed from someone (Maine wapis dena hai / Payable)

export type DebtStatus = 'pending' | 'partially_paid' | 'settled';

export interface Debt {
  id: string;
  personName: string;
  contactNumber?: string;
  type: DebtType;
  originalAmountPaisa: number;
  repaidAmountPaisa: number;
  date: string; // YYYY-MM-DD
  dueDate?: string; // YYYY-MM-DD
  notes?: string;
  status: DebtStatus;
  createdAt: number;
  updatedAt: number;
}

export interface DebtRepayment {
  id: string;
  debtId: string;
  amountPaisa: number;
  date: string; // YYYY-MM-DD
  paymentMethod: PaymentMethod;
  note?: string;
  createdAt: number;
}

export interface SavingsGoal {
  id: string;
  name: string;
  targetAmountPaisa: number;
  savedAmountPaisa: number;
  targetDate?: string;
  categoryIcon: string;
  notes?: string;
  isCompleted: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface SavingsContribution {
  id: string;
  goalId: string;
  type: 'deposit' | 'withdrawal';
  amountPaisa: number;
  date: string;
  note?: string;
  createdAt: number;
}

export interface AppSettings {
  currencySymbol: 'Rs.' | 'PKR';
  symbolPosition: 'prefix' | 'suffix';
  theme: 'emerald' | 'midnight' | 'forest';
  pinEnabled: boolean;
  pinHash?: string;
  pinSalt?: string;
  biometricEnabled: boolean;
  autoLockMinutes: number; // 0 = immediate on blur/hide, 1, 5, 15, -1 = disabled
  lastActiveTimestamp: number;
  initialSetupComplete: boolean;
  activeMonth: string; // YYYY-MM
}

export interface BackupData {
  version: number;
  appName: string;
  exportedAt: string;
  data: {
    transactions: Transaction[];
    budgets: Budget[];
    debts: Debt[];
    debtRepayments: DebtRepayment[];
    savingsGoals: SavingsGoal[];
    savingsContributions: SavingsContribution[];
    categories: Category[];
    settings: Partial<AppSettings>;
  };
}
