import {
  Transaction,
  Budget,
  Debt,
  DebtRepayment,
  SavingsGoal,
  SavingsContribution,
  Category,
  AppSettings,
  BackupData,
  TransactionType,
  DebtType,
  DebtStatus,
} from '../types';
import { getCurrentMonthKey } from '../utils/currency';

const DB_NAME = 'PocketHisabPro_DB';
const DB_VERSION = 1;

export const DEFAULT_CATEGORIES: Category[] = [
  // Income Categories
  { id: 'cat_inc_1', name: 'Salary', type: 'income', icon: 'Briefcase', color: '#10B981' },
  { id: 'cat_inc_2', name: 'Business', type: 'income', icon: 'Store', color: '#3B82F6' },
  { id: 'cat_inc_3', name: 'Freelancing', type: 'income', icon: 'Laptop', color: '#8B5CF6' },
  { id: 'cat_inc_4', name: 'Gift / Eidi', type: 'income', icon: 'Gift', color: '#EC4899' },
  { id: 'cat_inc_5', name: 'Rental / Property', type: 'income', icon: 'Home', color: '#F59E0B' },
  { id: 'cat_inc_6', name: 'Investments', type: 'income', icon: 'TrendingUp', color: '#14B8A6' },
  { id: 'cat_inc_7', name: 'Other Income', type: 'income', icon: 'PlusCircle', color: '#6B7280' },

  // Expense Categories
  { id: 'cat_exp_1', name: 'Food & Dining', type: 'expense', icon: 'Utensils', color: '#EF4444' },
  { id: 'cat_exp_2', name: 'Transport & Fuel', type: 'expense', icon: 'Car', color: '#F97316' },
  { id: 'cat_exp_3', name: 'Education & Fees', type: 'expense', icon: 'GraduationCap', color: '#8B5CF6' },
  { id: 'cat_exp_4', name: 'Mobile & Internet', type: 'expense', icon: 'Smartphone', color: '#06B6D4' },
  { id: 'cat_exp_5', name: 'Shopping & Clothes', type: 'expense', icon: 'ShoppingBag', color: '#EC4899' },
  { id: 'cat_exp_6', name: 'Utility Bills', type: 'expense', icon: 'Zap', color: '#EAB308' },
  { id: 'cat_exp_7', name: 'Health & Medical', type: 'expense', icon: 'HeartPulse', color: '#10B981' },
  { id: 'cat_exp_8', name: 'Entertainment', type: 'expense', icon: 'Film', color: '#6366F1' },
  { id: 'cat_exp_9', name: 'Family & Home', type: 'expense', icon: 'Users', color: '#14B8A6' },
  { id: 'cat_exp_10', name: 'Rent & House', type: 'expense', icon: 'Building', color: '#64748B' },
  { id: 'cat_exp_11', name: 'Charity & Zakat', type: 'expense', icon: 'HeartHandshake', color: '#059669' },
  { id: 'cat_exp_12', name: 'Other Expense', type: 'expense', icon: 'MoreHorizontal', color: '#9CA3AF' },
];

export const DEFAULT_SETTINGS: AppSettings = {
  currencySymbol: 'Rs.',
  symbolPosition: 'prefix',
  theme: 'emerald',
  pinEnabled: false,
  biometricEnabled: false,
  autoLockMinutes: 5,
  lastActiveTimestamp: Date.now(),
  initialSetupComplete: true,
  activeMonth: getCurrentMonthKey(),
};

class IndexedDBClient {
  private db: IDBDatabase | null = null;
  private dbPromise: Promise<IDBDatabase> | null = null;

  public async getDB(): Promise<IDBDatabase> {
    if (this.db) return this.db;
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Transactions Store
        if (!db.objectStoreNames.contains('transactions')) {
          const txStore = db.createObjectStore('transactions', { keyPath: 'id' });
          txStore.createIndex('by_date', 'date', { unique: false });
          txStore.createIndex('by_type', 'type', { unique: false });
          txStore.createIndex('by_category', 'category', { unique: false });
        }

        // Budgets Store
        if (!db.objectStoreNames.contains('budgets')) {
          const bStore = db.createObjectStore('budgets', { keyPath: 'id' });
          bStore.createIndex('by_month', 'month', { unique: false });
          bStore.createIndex('by_month_category', ['month', 'category'], { unique: true });
        }

        // Debts (Udhaar) Store
        if (!db.objectStoreNames.contains('debts')) {
          const dStore = db.createObjectStore('debts', { keyPath: 'id' });
          dStore.createIndex('by_person', 'personName', { unique: false });
          dStore.createIndex('by_type', 'type', { unique: false });
          dStore.createIndex('by_status', 'status', { unique: false });
        }

        // Debt Repayments Store
        if (!db.objectStoreNames.contains('debt_repayments')) {
          const drStore = db.createObjectStore('debt_repayments', { keyPath: 'id' });
          drStore.createIndex('by_debtId', 'debtId', { unique: false });
        }

        // Savings Goals Store
        if (!db.objectStoreNames.contains('savings_goals')) {
          db.createObjectStore('savings_goals', { keyPath: 'id' });
        }

        // Savings Contributions Store
        if (!db.objectStoreNames.contains('savings_contributions')) {
          const scStore = db.createObjectStore('savings_contributions', { keyPath: 'id' });
          scStore.createIndex('by_goalId', 'goalId', { unique: false });
        }

        // Categories Store
        if (!db.objectStoreNames.contains('categories')) {
          const cStore = db.createObjectStore('categories', { keyPath: 'id' });
          cStore.createIndex('by_type', 'type', { unique: false });
        }

        // Settings Store
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }
      };

      request.onsuccess = async (event: Event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        await this.seedDefaultsIfNeeded();
        resolve(this.db);
      };

      request.onerror = (event: Event) => {
        console.error('IndexedDB open error:', (event.target as IDBOpenDBRequest).error);
        reject((event.target as IDBOpenDBRequest).error);
      };
    });

    return this.dbPromise;
  }

  private async seedDefaultsIfNeeded(): Promise<void> {
    const cats = await this.getAll<Category>('categories');
    if (cats.length === 0) {
      for (const cat of DEFAULT_CATEGORIES) {
        await this.put('categories', cat);
      }
    }

    const settingsObj = await this.get<{ key: string; value: AppSettings }>('settings', 'app_settings');
    if (!settingsObj) {
      await this.put('settings', { key: 'app_settings', value: DEFAULT_SETTINGS });
    }
  }

  // Generic Helpers
  private async executeTransaction<T>(
    storeName: string,
    mode: IDBTransactionMode,
    operation: (store: IDBObjectStore) => IDBRequest
  ): Promise<T> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      const request = operation(store);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
      tx.onerror = () => reject(tx.error);
    });
  }

  public async getAll<T>(storeName: string): Promise<T[]> {
    const db = await this.getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  public async get<T>(storeName: string, key: IDBValidKey): Promise<T | undefined> {
    return this.executeTransaction<T>(storeName, 'readonly', (store) => store.get(key));
  }

  public async put<T>(storeName: string, value: T): Promise<T> {
    await this.executeTransaction(storeName, 'readwrite', (store) => store.put(value));
    return value;
  }

  public async delete(storeName: string, key: IDBValidKey): Promise<void> {
    await this.executeTransaction(storeName, 'readwrite', (store) => store.delete(key));
  }

  public async clearStore(storeName: string): Promise<void> {
    await this.executeTransaction(storeName, 'readwrite', (store) => store.clear());
  }

  // --- Transactions API ---
  public async getTransactions(): Promise<Transaction[]> {
    const txs = await this.getAll<Transaction>('transactions');
    return txs.sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
      const dateB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
      return dateB - dateA; // newest first
    });
  }

  public async saveTransaction(
    item: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
  ): Promise<Transaction> {
    const now = Date.now();
    const id = item.id || `tx_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const tx: Transaction = {
      ...item,
      id,
      createdAt: (item as any).createdAt || now,
      updatedAt: now,
    };
    await this.put('transactions', tx);
    return tx;
  }

  public async deleteTransaction(id: string): Promise<void> {
    await this.delete('transactions', id);
  }

  // --- Budgets API ---
  public async getBudgets(month?: string): Promise<Budget[]> {
    const all = await this.getAll<Budget>('budgets');
    if (!month) return all;
    return all.filter((b) => b.month === month);
  }

  public async saveBudget(
    item: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }
  ): Promise<Budget> {
    const now = Date.now();
    // Check if an entry for this month & category already exists to avoid duplicate
    const all = await this.getAll<Budget>('budgets');
    const existing = all.find((b) => b.month === item.month && b.category === item.category);

    const id = item.id || (existing ? existing.id : `b_${now}_${Math.random().toString(36).substring(2, 7)}`);
    const budget: Budget = {
      ...item,
      id,
      createdAt: existing ? existing.createdAt : now,
      updatedAt: now,
    };
    await this.put('budgets', budget);
    return budget;
  }

  public async deleteBudget(id: string): Promise<void> {
    await this.delete('budgets', id);
  }

  // --- Udhaar / Debt API ---
  public async getDebts(): Promise<Debt[]> {
    const debts = await this.getAll<Debt>('debts');
    return debts.sort((a, b) => b.createdAt - a.createdAt);
  }

  public async saveDebt(
    item: Omit<Debt, 'id' | 'createdAt' | 'updatedAt' | 'repaidAmountPaisa' | 'status'> & {
      id?: string;
      repaidAmountPaisa?: number;
      status?: DebtStatus;
    }
  ): Promise<Debt> {
    const now = Date.now();
    const id = item.id || `debt_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const repaid = item.repaidAmountPaisa ?? 0;
    
    let status: DebtStatus = 'pending';
    if (repaid >= item.originalAmountPaisa && item.originalAmountPaisa > 0) {
      status = 'settled';
    } else if (repaid > 0) {
      status = 'partially_paid';
    }

    const debt: Debt = {
      id,
      personName: item.personName.trim(),
      contactNumber: item.contactNumber?.trim(),
      type: item.type,
      originalAmountPaisa: item.originalAmountPaisa,
      repaidAmountPaisa: repaid,
      date: item.date,
      dueDate: item.dueDate,
      notes: item.notes?.trim(),
      status: item.status || status,
      createdAt: (item as any).createdAt || now,
      updatedAt: now,
    };

    await this.put('debts', debt);
    return debt;
  }

  public async deleteDebt(id: string): Promise<void> {
    await this.delete('debts', id);
    // Also delete associated repayments
    const reps = await this.getAll<DebtRepayment>('debt_repayments');
    for (const r of reps) {
      if (r.debtId === id) {
        await this.delete('debt_repayments', r.id);
      }
    }
  }

  public async getDebtRepayments(debtId: string): Promise<DebtRepayment[]> {
    const all = await this.getAll<DebtRepayment>('debt_repayments');
    return all.filter((r) => r.debtId === debtId).sort((a, b) => b.createdAt - a.createdAt);
  }

  public async addDebtRepayment(
    item: Omit<DebtRepayment, 'id' | 'createdAt'>
  ): Promise<{ repayment: DebtRepayment; updatedDebt: Debt }> {
    const now = Date.now();
    const id = `rep_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const repayment: DebtRepayment = {
      ...item,
      id,
      createdAt: now,
    };
    await this.put('debt_repayments', repayment);

    // Recalculate debt repaid total
    const debt = await this.get<Debt>('debts', item.debtId);
    if (!debt) throw new Error('Debt record not found');

    const allReps = await this.getDebtRepayments(item.debtId);
    const totalRepaid = allReps.reduce((sum, r) => sum + r.amountPaisa, 0);

    let status: DebtStatus = 'pending';
    if (totalRepaid >= debt.originalAmountPaisa) {
      status = 'settled';
    } else if (totalRepaid > 0) {
      status = 'partially_paid';
    }

    const updatedDebt: Debt = {
      ...debt,
      repaidAmountPaisa: totalRepaid,
      status,
      updatedAt: now,
    };
    await this.put('debts', updatedDebt);

    return { repayment, updatedDebt };
  }

  public async deleteDebtRepayment(repaymentId: string, debtId: string): Promise<Debt> {
    await this.delete('debt_repayments', repaymentId);
    const debt = await this.get<Debt>('debts', debtId);
    if (!debt) throw new Error('Debt record not found');

    const allReps = await this.getDebtRepayments(debtId);
    const totalRepaid = allReps.reduce((sum, r) => sum + r.amountPaisa, 0);

    let status: DebtStatus = 'pending';
    if (totalRepaid >= debt.originalAmountPaisa) {
      status = 'settled';
    } else if (totalRepaid > 0) {
      status = 'partially_paid';
    }

    const updatedDebt: Debt = {
      ...debt,
      repaidAmountPaisa: totalRepaid,
      status,
      updatedAt: Date.now(),
    };
    await this.put('debts', updatedDebt);
    return updatedDebt;
  }

  // --- Savings Goals API ---
  public async getSavingsGoals(): Promise<SavingsGoal[]> {
    const goals = await this.getAll<SavingsGoal>('savings_goals');
    return goals.sort((a, b) => b.createdAt - a.createdAt);
  }

  public async saveSavingsGoal(
    item: Omit<SavingsGoal, 'id' | 'createdAt' | 'updatedAt' | 'savedAmountPaisa' | 'isCompleted'> & {
      id?: string;
      savedAmountPaisa?: number;
      isCompleted?: boolean;
    }
  ): Promise<SavingsGoal> {
    const now = Date.now();
    const id = item.id || `goal_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const saved = item.savedAmountPaisa ?? 0;
    const isCompleted = item.isCompleted ?? saved >= item.targetAmountPaisa;

    const goal: SavingsGoal = {
      ...item,
      id,
      savedAmountPaisa: saved,
      isCompleted,
      createdAt: (item as any).createdAt || now,
      updatedAt: now,
    };
    await this.put('savings_goals', goal);
    return goal;
  }

  public async deleteSavingsGoal(id: string): Promise<void> {
    await this.delete('savings_goals', id);
    const contribs = await this.getAll<SavingsContribution>('savings_contributions');
    for (const c of contribs) {
      if (c.goalId === id) {
        await this.delete('savings_contributions', c.id);
      }
    }
  }

  public async getSavingsContributions(goalId: string): Promise<SavingsContribution[]> {
    const all = await this.getAll<SavingsContribution>('savings_contributions');
    return all.filter((c) => c.goalId === goalId).sort((a, b) => b.createdAt - a.createdAt);
  }

  public async addSavingsContribution(
    item: Omit<SavingsContribution, 'id' | 'createdAt'>
  ): Promise<{ contribution: SavingsContribution; updatedGoal: SavingsGoal }> {
    const now = Date.now();
    const id = `scon_${now}_${Math.random().toString(36).substring(2, 7)}`;
    const contribution: SavingsContribution = {
      ...item,
      id,
      createdAt: now,
    };
    await this.put('savings_contributions', contribution);

    const goal = await this.get<SavingsGoal>('savings_goals', item.goalId);
    if (!goal) throw new Error('Goal not found');

    const allContribs = await this.getSavingsContributions(item.goalId);
    let netSavedPaisa = 0;
    for (const c of allContribs) {
      if (c.type === 'deposit') {
        netSavedPaisa += c.amountPaisa;
      } else {
        netSavedPaisa = Math.max(0, netSavedPaisa - c.amountPaisa);
      }
    }

    const updatedGoal: SavingsGoal = {
      ...goal,
      savedAmountPaisa: netSavedPaisa,
      isCompleted: netSavedPaisa >= goal.targetAmountPaisa,
      updatedAt: now,
    };
    await this.put('savings_goals', updatedGoal);

    return { contribution, updatedGoal };
  }

  public async deleteSavingsContribution(contribId: string, goalId: string): Promise<SavingsGoal> {
    await this.delete('savings_contributions', contribId);
    const goal = await this.get<SavingsGoal>('savings_goals', goalId);
    if (!goal) throw new Error('Goal not found');

    const allContribs = await this.getSavingsContributions(goalId);
    let netSavedPaisa = 0;
    for (const c of allContribs) {
      if (c.type === 'deposit') {
        netSavedPaisa += c.amountPaisa;
      } else {
        netSavedPaisa = Math.max(0, netSavedPaisa - c.amountPaisa);
      }
    }

    const updatedGoal: SavingsGoal = {
      ...goal,
      savedAmountPaisa: netSavedPaisa,
      isCompleted: netSavedPaisa >= goal.targetAmountPaisa,
      updatedAt: Date.now(),
    };
    await this.put('savings_goals', updatedGoal);
    return updatedGoal;
  }

  // --- Categories API ---
  public async getCategories(type?: TransactionType): Promise<Category[]> {
    const all = await this.getAll<Category>('categories');
    if (!type) return all;
    return all.filter((c) => c.type === type);
  }

  public async saveCategory(cat: Omit<Category, 'id'> & { id?: string }): Promise<Category> {
    const id = cat.id || `custom_cat_${Date.now()}`;
    const newCat: Category = { ...cat, id, isCustom: true };
    await this.put('categories', newCat);
    return newCat;
  }

  // --- Settings API ---
  public async getSettings(): Promise<AppSettings> {
    const res = await this.get<{ key: string; value: AppSettings }>('settings', 'app_settings');
    return res ? { ...DEFAULT_SETTINGS, ...res.value } : DEFAULT_SETTINGS;
  }

  public async updateSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
    const current = await this.getSettings();
    const updated = { ...current, ...patch };
    await this.put('settings', { key: 'app_settings', value: updated });
    return updated;
  }

  // --- Backup & Restore ---
  public async exportCompleteBackup(): Promise<BackupData> {
    const transactions = await this.getAll<Transaction>('transactions');
    const budgets = await this.getAll<Budget>('budgets');
    const debts = await this.getAll<Debt>('debts');
    const debtRepayments = await this.getAll<DebtRepayment>('debt_repayments');
    const savingsGoals = await this.getAll<SavingsGoal>('savings_goals');
    const savingsContributions = await this.getAll<SavingsContribution>('savings_contributions');
    const categories = await this.getAll<Category>('categories');
    const settings = await this.getSettings();

    // Sanitize settings: do not export sensitive pin hash/salt in backup for portability
    const safeSettings = { ...settings };
    delete safeSettings.pinHash;
    delete safeSettings.pinSalt;

    return {
      version: 1,
      appName: 'Pocket Hisab Pro',
      exportedAt: new Date().toISOString(),
      data: {
        transactions,
        budgets,
        debts,
        debtRepayments,
        savingsGoals,
        savingsContributions,
        categories,
        settings: safeSettings,
      },
    };
  }

  public async importBackup(
    backup: BackupData,
    mode: 'replace' | 'merge' = 'replace'
  ): Promise<{ success: boolean; stats: { transactions: number; debts: number; budgets: number; goals: number } }> {
    if (!backup || !backup.data) {
      throw new Error('Invalid backup file structure.');
    }

    if (mode === 'replace') {
      await this.clearStore('transactions');
      await this.clearStore('budgets');
      await this.clearStore('debts');
      await this.clearStore('debt_repayments');
      await this.clearStore('savings_goals');
      await this.clearStore('savings_contributions');
    }

    let txCount = 0;
    if (Array.isArray(backup.data.transactions)) {
      for (const tx of backup.data.transactions) {
        if (tx.id && tx.amountPaisa && tx.type && tx.date) {
          await this.put('transactions', tx);
          txCount++;
        }
      }
    }

    let bCount = 0;
    if (Array.isArray(backup.data.budgets)) {
      for (const b of backup.data.budgets) {
        if (b.id && b.month && b.amountPaisa) {
          await this.put('budgets', b);
          bCount++;
        }
      }
    }

    let dCount = 0;
    if (Array.isArray(backup.data.debts)) {
      for (const d of backup.data.debts) {
        if (d.id && d.personName && d.originalAmountPaisa) {
          await this.put('debts', d);
          dCount++;
        }
      }
    }

    if (Array.isArray(backup.data.debtRepayments)) {
      for (const r of backup.data.debtRepayments) {
        if (r.id && r.debtId) {
          await this.put('debt_repayments', r);
        }
      }
    }

    let gCount = 0;
    if (Array.isArray(backup.data.savingsGoals)) {
      for (const g of backup.data.savingsGoals) {
        if (g.id && g.name && g.targetAmountPaisa) {
          await this.put('savings_goals', g);
          gCount++;
        }
      }
    }

    if (Array.isArray(backup.data.savingsContributions)) {
      for (const sc of backup.data.savingsContributions) {
        if (sc.id && sc.goalId) {
          await this.put('savings_contributions', sc);
        }
      }
    }

    if (Array.isArray(backup.data.categories)) {
      for (const cat of backup.data.categories) {
        if (cat.id && cat.name) {
          await this.put('categories', cat);
        }
      }
    }

    return {
      success: true,
      stats: {
        transactions: txCount,
        debts: dCount,
        budgets: bCount,
        goals: gCount,
      },
    };
  }

  public async clearAllData(): Promise<void> {
    await this.clearStore('transactions');
    await this.clearStore('budgets');
    await this.clearStore('debts');
    await this.clearStore('debt_repayments');
    await this.clearStore('savings_goals');
    await this.clearStore('savings_contributions');
    await this.clearStore('categories');
    await this.seedDefaultsIfNeeded();
  }

  /**
   * Load realistic sample data for testing and demonstrations
   */
  public async loadRealisticDemoData(): Promise<void> {
    await this.clearAllData();

    const currentMonth = getCurrentMonthKey();
    const [yearStr, monthStr] = currentMonth.split('-');
    const y = parseInt(yearStr, 10);
    const m = parseInt(monthStr, 10);

    const pad = (n: number) => String(n).padStart(2, '0');
    const makeDate = (day: number) => `${y}-${pad(m)}-${pad(day)}`;

    // Demo Transactions in PKR (represented in Paisa)
    const demoTransactions: Array<Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>> = [
      {
        type: 'income',
        amountPaisa: 28500000, // Rs. 285,000
        category: 'Salary',
        paymentMethod: 'bank',
        date: makeDate(1),
        time: '09:30',
        note: 'Monthly Senior Engineer salary transfer',
      },
      {
        type: 'income',
        amountPaisa: 6500000, // Rs. 65,000
        category: 'Freelancing',
        paymentMethod: 'bank',
        date: makeDate(8),
        time: '14:20',
        note: 'Upwork mobile app milestone payout',
      },
      {
        type: 'expense',
        amountPaisa: 5500000, // Rs. 55,000
        category: 'Rent & House',
        paymentMethod: 'bank',
        date: makeDate(2),
        time: '10:00',
        note: 'Apartment rent paid via IBFT',
      },
      {
        type: 'expense',
        amountPaisa: 1850000, // Rs. 18,500
        category: 'Food & Dining',
        paymentMethod: 'cash',
        date: makeDate(4),
        time: '18:45',
        note: 'Imtiaz Super Market monthly grocery shopping',
      },
      {
        type: 'expense',
        amountPaisa: 840000, // Rs. 8,400
        category: 'Transport & Fuel',
        paymentMethod: 'cash',
        date: makeDate(6),
        time: '11:15',
        note: 'Total PARCO car full petrol tank fill',
      },
      {
        type: 'expense',
        amountPaisa: 1250000, // Rs. 12,500
        category: 'Utility Bills',
        paymentMethod: 'bank',
        date: makeDate(10),
        time: '16:00',
        note: 'K-Electric electricity bill via 1Link',
      },
      {
        type: 'expense',
        amountPaisa: 420000, // Rs. 4,200
        category: 'Mobile & Internet',
        paymentMethod: 'other',
        date: makeDate(12),
        time: '20:10',
        note: 'Nayatel optical fiber package paid via Nayapay',
      },
      {
        type: 'expense',
        amountPaisa: 750000, // Rs. 7,500
        category: 'Charity & Zakat',
        paymentMethod: 'cash',
        date: makeDate(15),
        time: '13:00',
        note: 'Monthly ration support donation to needy family',
      },
      {
        type: 'expense',
        amountPaisa: 920000, // Rs. 9,200
        category: 'Health & Medical',
        paymentMethod: 'cash',
        date: makeDate(18),
        time: '19:30',
        note: 'Doctor consultation and routine pharmacy medicine',
      },
      {
        type: 'expense',
        amountPaisa: 1100000, // Rs. 11,000
        category: 'Shopping & Clothes',
        paymentMethod: 'bank',
        date: makeDate(20),
        time: '17:40',
        note: 'Alkaram / Khaadi winter casual kurtas',
      },
    ];

    for (const tx of demoTransactions) {
      await this.saveTransaction(tx);
    }

    // Demo Budgets for current month
    await this.saveBudget({
      month: currentMonth,
      category: '_total_',
      amountPaisa: 16000000, // Overall budget Rs. 160,000
    });
    await this.saveBudget({
      month: currentMonth,
      category: 'Food & Dining',
      amountPaisa: 3000000, // Rs. 30,000
    });
    await this.saveBudget({
      month: currentMonth,
      category: 'Transport & Fuel',
      amountPaisa: 1500000, // Rs. 15,000
    });
    await this.saveBudget({
      month: currentMonth,
      category: 'Utility Bills',
      amountPaisa: 1500000, // Rs. 15,000
    });

    // Demo Udhaar / Debts
    const d1 = await this.saveDebt({
      personName: 'Hamza Khan (Colleague)',
      contactNumber: '0300-1234567',
      type: 'lent', // Money I Lent (Receivable)
      originalAmountPaisa: 2500000, // Rs. 25,000
      date: makeDate(5),
      dueDate: makeDate(30),
      notes: 'Lent for car maintenance emergency. Promised by end of month.',
    });

    // Partial repayment of Rs. 10,000 on Hamza's loan
    await this.addDebtRepayment({
      debtId: d1.id,
      amountPaisa: 1000000, // Rs. 10,000
      date: makeDate(14),
      paymentMethod: 'bank',
      note: 'Partial IBFT transfer received',
    });

    await this.saveDebt({
      personName: 'Tariq Electronics Store',
      contactNumber: '0321-9876543',
      type: 'borrowed', // Money I Borrowed (Payable)
      originalAmountPaisa: 1500000, // Rs. 15,000
      date: makeDate(9),
      dueDate: makeDate(28),
      notes: 'Split AC repair parts installment due.',
    });

    // Demo Savings Goal
    const g1 = await this.saveSavingsGoal({
      name: 'Emergency Rainy Day Fund',
      targetAmountPaisa: 50000000, // Rs. 500,000
      categoryIcon: 'ShieldCheck',
      targetDate: `${y + 1}-06-30`,
      notes: '6 months living expenses reserve kept in high-yield account.',
    });

    await this.addSavingsContribution({
      goalId: g1.id,
      type: 'deposit',
      amountPaisa: 15000000, // Rs. 150,000
      date: makeDate(3),
      note: 'Initial deposit from project bonus',
    });

    await this.addSavingsContribution({
      goalId: g1.id,
      type: 'deposit',
      amountPaisa: 3500000, // Rs. 35,000
      date: makeDate(16),
      note: 'Monthly disciplined savings transfer',
    });
  }
}

export const db = new IndexedDBClient();
