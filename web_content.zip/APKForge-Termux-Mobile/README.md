# APKForge Mobile v4 (Accès Dossiers Automatique)

## Installation dans Termux
1. Copiez ce dossier dans `Download` sur votre téléphone.
2. Ouvrez Termux et tapez :
```bash
cd ~/storage/downloads/APKForge-Termux-Mobile
chmod +x install.sh
./install.sh
npm start
```
3. Ouvrez `http://localhost:3000` dans votre navigateur ou recompilez `index.html` en APK.

## Nouveautés v4
- Demande automatique des permissions `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE` et `MANAGE_EXTERNAL_STORAGE` (Accès à tous les fichiers sous Android 11+) dès l'ouverture de l'APK.
- Pont natif `AndroidBridge.checkStoragePermission()` et `AndroidBridge.requestStoragePermission()` intégré dans `index.html`.
- Copie automatique de l'APK compilé directement dans `/sdcard/Download`.
