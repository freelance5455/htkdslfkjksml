const express = require('express');
const multer = require('multer');
const AdmZip = require('adm-zip');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const app = express();
const upload = multer({ dest: 'uploads/' });
const PORT = 3000;

app.use(express.static('public'));
app.use('/output', express.static('output'));

['uploads', 'work', 'output'].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

app.post('/build', upload.fields([{ name: 'sourceFile', maxCount: 1 }, { name: 'iconFile', maxCount: 1 }]), (req, res) => {
  try {
    const sourceFile = req.files['sourceFile']?.[0];
    if (!sourceFile) return res.status(400).json({ error: 'Aucun fichier source reçu.' });

    const appName = (req.body.appName || 'Mon App').replace(/"/g, '');
    const packageId = (req.body.packageId || 'com.apkforge.app').replace(/[^a-zA-Z0-9._]/g, '');
    const version = (req.body.version || '1.0.0').replace(/[^0-9.]/g, '');

    const buildId = 'build_' + Date.now();
    const buildDir = path.join(__dirname, 'work', buildId);
    const assetsDir = path.join(buildDir, 'assets', 'www');
    const resDir = path.join(buildDir, 'res');
    const drawableDir = path.join(resDir, 'drawable');
    const pkgPath = packageId.replace(/\./g, '/');
    const srcDir = path.join(buildDir, 'src', pkgPath);
    const objDir = path.join(buildDir, 'obj');
    const binDir = path.join(buildDir, 'bin');

    [assetsDir, drawableDir, srcDir, objDir, binDir].forEach(d => fs.mkdirSync(d, { recursive: true }));

    // Extract HTML or ZIP
    if (sourceFile.originalname.toLowerCase().endsWith('.zip')) {
      const zip = new AdmZip(sourceFile.path);
      zip.extractAllTo(assetsDir, true);
    } else {
      fs.copyFileSync(sourceFile.path, path.join(assetsDir, 'index.html'));
    }

    // Handle Icon
    const iconFile = req.files['iconFile']?.[0];
    if (iconFile) {
      fs.copyFileSync(iconFile.path, path.join(drawableDir, 'ic_launcher.png'));
    } else {
      // Minimal valid 1x1 PNG fallback
      const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
      fs.writeFileSync(path.join(drawableDir, 'ic_launcher.png'), Buffer.from(pngBase64, 'base64'));
    }

    // AndroidManifest.xml with full Storage Permissions (READ/WRITE + MANAGE_EXTERNAL_STORAGE)
    const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${packageId}"
    android:versionCode="1"
    android:versionName="${version}">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="33" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />

    <application
        android:label="${appName}"
        android:icon="@drawable/ic_launcher"
        android:requestLegacyExternalStorage="true"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;
    fs.writeFileSync(path.join(buildDir, 'AndroidManifest.xml'), manifestXml);

    // MainActivity.java with automatic runtime permission request + All Files Access + File Chooser + Download Bridge
    const mainActivityJava = `package ${packageId};

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 1001;
    private static final int STORAGE_PERM_REQ = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestAllStoragePermissions();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
                if (url.startsWith("blob:")) {
                    String js = "javascript:(function(){" +
                        "var xhr=new XMLHttpRequest();xhr.open('GET','" + url + "',true);xhr.responseType='blob';" +
                        "xhr.onload=function(){if(this.status==200){var r=new FileReader();r.readAsDataURL(this.response);" +
                        "r.onloadend=function(){AndroidBridge.saveBase64File(r.result,'download.bin');};}};xhr.send();})()";
                    webView.loadUrl(js);
                } else if (url.startsWith("data:")) {
                    saveDataUrl(url, "download.bin");
                }
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    public boolean hasStoragePermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            return Environment.isExternalStorageManager();
        } else if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
                   checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    public void requestAllStoragePermissions() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                    startActivity(intent);
                }
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (!hasStoragePermission()) {
                requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                }, STORAGE_PERM_REQ);
            }
        }
    }

    private void saveDataUrl(String dataUrl, String filename) {
        try {
            String base64Data = dataUrl.substring(dataUrl.indexOf(",") + 1);
            byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
            File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File outFile = new File(downloads, filename);
            FileOutputStream fos = new FileOutputStream(outFile);
            fos.write(bytes);
            fos.close();
            Toast.makeText(this, "Enregistré dans Téléchargements : " + filename, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erreur sauvegarde : " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public class AndroidBridge {
        @JavascriptInterface
        public boolean checkStoragePermission() {
            return hasStoragePermission();
        }

        @JavascriptInterface
        public void requestStoragePermission() {
            runOnUiThread(() -> requestAllStoragePermissions());
        }

        @JavascriptInterface
        public void saveBase64File(String dataUrl, String filename) {
            runOnUiThread(() -> saveDataUrl(dataUrl, filename));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQ) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
`;
    fs.writeFileSync(path.join(srcDir, 'MainActivity.java'), mainActivityJava);

    const androidJar = path.join(__dirname, 'sdk', 'android.jar');
    const unsignedApk = path.join(binDir, 'app.unsigned.apk');
    const safeAppName = appName.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'app';
    const finalApkName = `${safeAppName}-v${version}.apk`;
    const finalApkPath = path.join(__dirname, 'output', finalApkName);

    // 1. Package resources & assets
    execSync(`aapt package -f -m -J "${srcDir}" -M "${path.join(buildDir, 'AndroidManifest.xml')}" -S "${resDir}" -A "${path.join(buildDir, 'assets')}" -I "${androidJar}" -F "${unsignedApk}"`);

    // 2. Compile Java
    execSync(`ecj -d "${objDir}" -classpath "${androidJar}" -sourcepath "${path.join(buildDir, 'src')}" "${path.join(srcDir, 'MainActivity.java')}"`);

    // 3. Convert to Dalvik bytecode
    execSync(`dx --dex --output="${path.join(binDir, 'classes.dex')}" "${objDir}"`);

    // 4. Add classes.dex to APK
    execSync(`cd "${binDir}" && zip -uj "${unsignedApk}" classes.dex`);

    // 5. Generate debug keystore if missing & Sign APK
    const keystorePath = path.join(__dirname, 'debug.keystore');
    if (!fs.existsSync(keystorePath)) {
      execSync(`keytool -genkeypair -v -keystore "${keystorePath}" -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=APKForge,O=Android,C=US"`);
    }
    execSync(`apksigner sign --ks "${keystorePath}" --ks-pass pass:android --key-pass pass:android --out "${finalApkPath}" "${unsignedApk}"`);

    // Also copy directly to Android Downloads folder if available
    const androidDownloads = '/sdcard/Download';
    if (fs.existsSync(androidDownloads)) {
      fs.copyFileSync(finalApkPath, path.join(androidDownloads, finalApkName));
    }

    res.json({
      success: true,
      apkName: finalApkName,
      downloadUrl: `/output/${finalApkName}`
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`APKForge Mobile v4 actif sur http://localhost:${PORT}`);
});
