#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "=== Installation de APKForge Mobile v4 (Accès Dossiers Auto) ==="
termux-setup-storage || true
pkg update -y && pkg upgrade -y
pkg install -y nodejs openjdk-17 wget unzip zip aapt apksigner dx ecj

mkdir -p sdk
if [ ! -f sdk/android.jar ]; then
  echo "Téléchargement de android.jar (API 33)..."
  wget -q --show-progress https://github.com/Sable/android-platforms/raw/master/android-33/android.jar -O sdk/android.jar
fi

npm install
echo "=== Installation terminée ! Lancez avec : npm start ==="
