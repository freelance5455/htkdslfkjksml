# Bombe Lite

Aplicativo web instalável (PWA), com atalhos para WhatsApp, Minecraft, YouTube, Google, Play Store e páginas da internet. Interface responsiva inspirada na imagem de referência enviada.

## Como testar

Abra `index.html` num navegador. Para instalar como app no Android, publique a pasta num endereço HTTPS e abra no Chrome; escolha **Instalar app** ou **Adicionar à tela inicial**.

## Atalhos

- WhatsApp e Minecraft tentam abrir o app instalado por seus esquemas (`whatsapp://send` e `minecraft://`). Se não abrirem, o Bombe Lite direciona para o site oficial.
- YouTube, Google, Play Store e Sites abrem os respectivos endereços oficiais; o Android pode encaminhar alguns links para os aplicativos instalados.
- Jogos, ferramentas e ajustes demonstram a navegação do Bombe Lite. Os controles de Wi‑Fi e Bluetooth são apenas visuais e não alteram configurações do aparelho.

## Limite importante

Este pacote é um PWA, não um APK/launcher Android nativo. Navegadores não podem listar nem abrir com garantia qualquer app instalado. Para abrir qualquer app diretamente, seria necessário compilar um launcher Android nativo com integração própria. O funcionamento dos esquemas também depende de o app estar instalado e registrar esse endereço no Android.
