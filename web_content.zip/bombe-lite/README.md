# Bombe Lite

Protótipo web responsivo baseado na referência enviada: tela inicial, menu principal, atalhos de aplicativos, jogos, ferramentas e configurações demonstrativas.

## Teste
Abra `index.html` em um navegador moderno. Para instalação como PWA no Android, a pasta precisa ser hospedada por HTTPS; depois, abra no Chrome e escolha **Instalar app** ou **Adicionar à tela inicial**.

## O que funciona
- Navegação entre início, apps, jogos, ferramentas e configurações.
- Alternâncias demonstrativas de Wi‑Fi, Bluetooth e som, salvas no aparelho via `localStorage`.
- Layout adaptável a celular, tablet e desktop.
- Manifesto e cache básico para PWA.

## Limite técnico
É um protótipo web instalável, não um launcher Android nativo. Não substitui a tela inicial do sistema, não altera conexões reais do aparelho e não inicia apps nativos. Para essas funções, seria necessário desenvolver e assinar um APK Android com permissões adequadas.
