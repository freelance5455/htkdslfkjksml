const CACHE_NAME = "repquest-shell-v2";
const APP_SHELL = ["./", "./index.html", "./style.css", "./app.js", "./manifest.json", "./icon.svg"];
self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll(APP_SHELL);
    // Vite hashes production bundles; discover those exact URLs from the built HTML.
    const htmlResponse = await fetch(new URL("./", self.registration.scope));
    const html = await htmlResponse.text();
    const references = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map((match) => match[1]);
    const assets = references.map((reference) => new URL(reference, self.registration.scope))
      .filter((url) => url.origin === self.location.origin && url.href !== new URL("./sw.js", self.registration.scope).href);
    await Promise.all(assets.map((url) => cache.add(url.href)));
    const manifestUrl = assets.find((url) => url.pathname.endsWith(".json"));
    if (manifestUrl) {
      const manifestResponse = await cache.match(manifestUrl.href);
      if (manifestResponse) {
        const manifest = await manifestResponse.json();
        const icons = (manifest.icons || []).map((icon) => new URL(icon.src, manifestUrl));
        await Promise.all(icons.filter((url) => url.origin === self.location.origin).map((url) => cache.add(url.href)));
      }
    }
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET" || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(request).then((cached) => cached || fetch(request).then((response) => {
    if (response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
    }
    return response;
  }).catch(() => caches.match("./index.html"))));
});
