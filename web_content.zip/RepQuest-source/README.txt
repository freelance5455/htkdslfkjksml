RepQuest v1.1 — código fuente y versión de producción

EJECUTAR EL CÓDIGO FUENTE
1. Instala Python 3 si aún no está instalado.
2. Abre una terminal dentro de esta carpeta (donde está este README).
3. Ejecuta: python3 -m http.server 8000
4. Abre http://localhost:8000 en el navegador.

Usa un servidor HTTP local para que el navegador cargue los módulos y active
el service worker. No abras index.html directamente mediante file://.

PUBLICAR LA VERSIÓN YA COMPILADA
El contenido de dist/public es la versión estática lista para servir. Para
alojarla, publica los archivos que contiene en la raíz de un hosting estático.

USAR EN UNA APLICACIÓN ANDROID CON WEBVIEW
La carpeta web/ incluida en este ZIP contiene index.html y todos sus recursos
con rutas relativas para que se abra como:
https://appassets.androidplatform.net/web/index.html

Copia la carpeta web/ dentro de la carpeta assets de tu proyecto Android
(normalmente app/src/main/assets/web/), de modo que index.html quede en
assets/web/index.html. Si tu WebView usa otra ruta de assets, conserva la
correspondencia con /web/index.html. Después vuelve a compilar e instalar la
aplicación Android. Este proyecto no incluye el código nativo ni genera el APK.

RepQuest no necesita dependencias de npm ni un backend para ejecutarse. Los
datos de entrenamiento se guardan localmente en el navegador.
