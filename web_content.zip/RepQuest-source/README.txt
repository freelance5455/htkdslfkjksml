RepQuest — código fuente y versión de producción

EJECUTAR EL CÓDIGO FUENTE
1. Instala Python 3 si aún no está instalado.
2. Abre una terminal dentro de esta carpeta (donde está este README).
3. Ejecuta: python3 -m http.server 8000
4. Abre http://localhost:8000 en el navegador.

El servidor HTTP local permite que el navegador cargue los módulos y active el
service worker. No abras index.html directamente mediante file://.

PUBLICAR LA VERSIÓN YA COMPILADA
El contenido de dist/public es una versión estática lista para servir. Para
alojarla, publica los archivos que contiene en la raíz de un hosting estático.

RepQuest no necesita dependencias de npm ni un backend para ejecutarse. Los
datos de entrenamiento se guardan localmente en el navegador.
