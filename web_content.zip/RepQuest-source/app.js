const STORAGE_KEY = "repquest.local.v1";
const SCHEMA_VERSION = 2;
const LEGACY_SCHEMA_VERSION = 1;
const STREAK_WINDOW_MS = 24 * 60 * 60 * 1000;
const INITIAL_START_DATE = "2026-10-06";
const DEFAULT_PLAN = {
  pushups: { sets: 4, reps: 4 },
  situps: { sets: 2, reps: 30 }
};
const main = document.querySelector("#main-content");
const dialogBackdrop = document.querySelector("#dialog-backdrop");
const dialogPanel = document.querySelector("#dialog-panel");
const celebration = document.querySelector("#celebration");
const importInput = document.querySelector("#import-file");
let activeView = "camino";
let openedSession = null;
let dialogReturnFocus = null;
let installPrompt = null;
let toastTimer = null;
let storageWarning = "";
let shouldPersistLoadedState = false;

function freshState() {
  return {
    schemaVersion: SCHEMA_VERSION,
    startDate: INITIAL_START_DATE,
    initialMarks: { pushupsMax: 6, situps60Seconds: 40 },
    sessions: [],
    plans: { "1": structuredClone(DEFAULT_PLAN), "2": structuredClone(DEFAULT_PLAN), "3": structuredClone(DEFAULT_PLAN), "4": structuredClone(DEFAULT_PLAN), "5": structuredClone(DEFAULT_PLAN) },
    drafts: {},
    streak: 0,
    bestStreak: 0,
    lastBaseCompletedAt: null,
    settings: { blockSize: 5 }
  };
}

function loadState() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return freshState();
    const parsed = JSON.parse(stored);
    if (parsed?.schemaVersion === LEGACY_SCHEMA_VERSION) {
      const migrated = migrateLegacyState(parsed);
      if (migrated) {
        shouldPersistLoadedState = true;
        return migrated;
      }
    }
    if (!validateState(parsed)) {
      storageWarning = "Los datos guardados no son válidos. Puedes importar un respaldo correcto o restablecer el progreso.";
      return freshState();
    }
    return parsed;
  } catch {
    storageWarning = "No se pudieron leer los datos guardados. Comprueba el almacenamiento de este dispositivo.";
    return freshState();
  }
}
let state = loadState();
if (shouldPersistLoadedState) persist();

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    storageWarning = "";
    return true;
  } catch {
    storageWarning = "No se pudieron guardar los cambios. Libera espacio en el dispositivo e inténtalo de nuevo.";
    return false;
  }
}
function positiveInteger(value) { return Number.isSafeInteger(value) && value > 0; }
function validExercise(exercise) { return Boolean(exercise && positiveInteger(exercise.sets) && positiveInteger(exercise.reps)); }
function validPlan(plan) { return Boolean(plan && validExercise(plan.pushups) && validExercise(plan.situps)); }
function validExtraExercise(exercise, allowEmptyName = false) {
  return Boolean(exercise && typeof exercise.name === "string" && exercise.name.length <= 80 &&
    (allowEmptyName || exercise.name.trim().length > 0) && positiveInteger(exercise.sets) &&
    (exercise.type === "reps" || exercise.type === "duration") && positiveInteger(exercise.amount) &&
    typeof exercise.completed === "boolean");
}
function validDraft(draft) {
  return Boolean(draft && validPlan(draft) && typeof draft.pushupsDone === "boolean" &&
    typeof draft.situpsDone === "boolean" && Array.isArray(draft.extraExercises) &&
    draft.extraExercises.every((exercise) => validExtraExercise(exercise, true)));
}
function validDate(value) {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.valueOf()) && date.toISOString().slice(0, 10) === value;
}
function validDateTime(value) {
  if (typeof value !== "string" || Number.isNaN(Date.parse(value))) return false;
  return new Date(value).toISOString() === value;
}
function validLegacyDraft(draft) {
  return Boolean(draft && validPlan(draft) && typeof draft.pushupsDone === "boolean" && typeof draft.situpsDone === "boolean");
}
function validateLegacyState(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  if (value.schemaVersion !== LEGACY_SCHEMA_VERSION || !validDate(value.startDate)) return false;
  if (!value.initialMarks || !positiveInteger(value.initialMarks.pushupsMax) || !positiveInteger(value.initialMarks.situps60Seconds)) return false;
  if (!Array.isArray(value.sessions) || !value.plans || typeof value.plans !== "object" || Array.isArray(value.plans) || !value.drafts || typeof value.drafts !== "object" || Array.isArray(value.drafts)) return false;
  if (!Number.isSafeInteger(value.streak) || value.streak < 0 || !Number.isSafeInteger(value.bestStreak) || value.bestStreak < value.streak) return false;
  if (!value.settings || value.settings.blockSize !== 5) return false;
  for (const [day, plan] of Object.entries(value.plans)) if (!/^[1-9]\d*$/.test(day) || !validPlan(plan)) return false;
  for (const [day, draft] of Object.entries(value.drafts)) if (!/^[1-9]\d*$/.test(day) || !validLegacyDraft(draft)) return false;
  for (let index = 0; index < value.sessions.length; index += 1) {
    const session = value.sessions[index];
    if (!session || session.day !== index + 1 || session.block !== Math.ceil(session.day / 5) ||
        !validDate(session.completedOn) || !validPlan(session.exercises) ||
        session.pushupsDone !== true || session.situpsDone !== true) return false;
  }
  return value.streak === value.sessions.length && value.bestStreak >= value.streak;
}
function migrateLegacyState(value) {
  if (!validateLegacyState(value)) return null;
  const sessions = value.sessions.map((session) => ({
    ...session,
    completedAt: new Date(`${session.completedOn}T12:00:00`).toISOString(),
    extraExercises: []
  }));
  const lastBaseCompletedAt = sessions.at(-1)?.completedAt ?? null;
  let migratedStreak = sessions.length ? 1 : 0;
  for (let index = sessions.length - 1; index > 0; index -= 1) {
    const gap = Date.parse(sessions[index].completedAt) - Date.parse(sessions[index - 1].completedAt);
    if (gap < 0 || gap > STREAK_WINDOW_MS) break;
    migratedStreak += 1;
  }
  const elapsed = lastBaseCompletedAt ? Date.now() - Date.parse(lastBaseCompletedAt) : Infinity;
  const streak = elapsed >= 0 && elapsed <= STREAK_WINDOW_MS ? migratedStreak : 0;
  return {
    ...value,
    schemaVersion: SCHEMA_VERSION,
    sessions,
    drafts: Object.fromEntries(Object.entries(value.drafts).map(([day, draft]) => [
      day,
      { ...draft, extraExercises: [] }
    ])),
    streak,
    lastBaseCompletedAt
  };
}
function validateState(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  if (value.schemaVersion !== SCHEMA_VERSION || !validDate(value.startDate)) return false;
  if (!value.initialMarks || !positiveInteger(value.initialMarks.pushupsMax) || !positiveInteger(value.initialMarks.situps60Seconds)) return false;
  if (!Array.isArray(value.sessions) || !value.plans || typeof value.plans !== "object" || Array.isArray(value.plans) || !value.drafts || typeof value.drafts !== "object" || Array.isArray(value.drafts)) return false;
  if (!Number.isSafeInteger(value.streak) || value.streak < 0 || !Number.isSafeInteger(value.bestStreak) || value.bestStreak < value.streak) return false;
  if (!value.settings || value.settings.blockSize !== 5 ||
      (value.lastBaseCompletedAt !== null && !validDateTime(value.lastBaseCompletedAt))) return false;
  for (const [day, plan] of Object.entries(value.plans)) if (!/^[1-9]\d*$/.test(day) || !validPlan(plan)) return false;
  for (const [day, draft] of Object.entries(value.drafts)) if (!/^[1-9]\d*$/.test(day) || !validDraft(draft)) return false;
  for (let index = 0; index < value.sessions.length; index += 1) {
    const session = value.sessions[index];
    if (!session || session.day !== index + 1 || session.block !== Math.ceil(session.day / 5) || !validDate(session.completedOn) ||
        !validDateTime(session.completedAt) || !validPlan(session.exercises) ||
        !Array.isArray(session.extraExercises) || !session.extraExercises.every((exercise) => validExtraExercise(exercise)) ||
        session.pushupsDone !== true || session.situpsDone !== true) return false;
  }
  const lastSession = value.sessions.at(-1);
  return value.bestStreak >= value.streak &&
    (lastSession ? value.lastBaseCompletedAt === lastSession.completedAt : value.lastBaseCompletedAt === null);
}

function countCompleted() { return state.sessions.length; }
function nextDay() { return countCompleted() + 1; }
function visibleNodeCount() { return Math.max(5, Math.ceil(nextDay() / 5) * 5); }
function sessionBlock(day) { return Math.ceil(day / 5); }
function getPlan(day) {
  const key = String(day);
  if (!state.plans[key]) state.plans[key] = structuredClone(DEFAULT_PLAN);
  return structuredClone(state.plans[key]);
}
function getDraft(day) {
  const existing = state.drafts[String(day)];
  if (existing) return { ...structuredClone(existing), extraExercises: structuredClone(existing.extraExercises ?? []) };
  const plan = getPlan(day);
  return { ...plan, pushupsDone: false, situpsDone: false, extraExercises: [] };
}
function currentStreak() {
  if (!state.lastBaseCompletedAt) return 0;
  const elapsed = Date.now() - Date.parse(state.lastBaseCompletedAt);
  return elapsed > STREAK_WINDOW_MS ? 0 : state.streak;
}
function expireStreakIfNeeded() {
  const streak = currentStreak();
  if (streak === state.streak) return false;
  state.streak = streak;
  persist();
  return true;
}
function formatDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return new Intl.DateTimeFormat("es-ES", { day: "numeric", month: "short", year: "numeric" }).format(date);
}
function localDateISO(date = new Date()) {
  const pad = (part) => String(part).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}
function setView(view) {
  activeView = view;
  document.querySelectorAll(".nav-button").forEach((button) => {
    if (button.dataset.view === view) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  render();
  main.focus({ preventScroll: true });
}

function render() {
  expireStreakIfNeeded();
  document.querySelector("#top-streak").textContent = `Racha: ${state.streak} sesiones`;
  if (activeView === "camino") renderPathway();
  if (activeView === "progreso") renderProgress();
  if (activeView === "ajustes") renderSettings();
  if (storageWarning) showStatus(storageWarning, true);
}

function renderPathway() {
  const completed = countCompleted();
  const count = visibleNodeCount();
  const nodes = Array.from({ length: count }, (_, index) => index + 1);
  const xPositions = [50, 67, 51, 34, 48, 64, 49, 33, 51, 67];
  const yStart = 73;
  const spacing = 128;
  const height = yStart * 2 + Math.max(0, count - 1) * spacing;
  const points = nodes.map((day, index) => ({ x: xPositions[(day - 1) % xPositions.length], y: yStart + index * spacing }));
  const paths = points.slice(0, -1).map((point, index) => {
    const next = points[index + 1];
    const midpoint = (point.y + next.y) / 2;
    return `<path class="${index < completed ? "path-progress" : "path-line"}" d="M ${point.x} ${point.y} C ${point.x} ${midpoint}, ${next.x} ${midpoint}, ${next.x} ${next.y}"/>`;
  }).join("");
  const nodeMarkup = nodes.map((day, index) => {
    const status = day <= completed ? "completed" : day === completed + 1 ? "available" : "locked";
    const label = status === "completed" ? "COMPLETADO" : status === "available" ? "SIGUIENTE" : "BLOQUEADO";
    const symbol = status === "completed" ? "✓" : status === "available" ? "＋" : '<span class="lock-mark" aria-hidden="true"></span>';
    const description = status === "completed" ? "completado" : status === "available" ? "disponible" : "bloqueado";
    const top = points[index].y - 36;
    const button = status === "locked" ? "button" : "button";
    return `<button type="${button}" class="path-node ${status}" style="left:${points[index].x}%;top:${top}px" data-node-day="${day}" data-status="${status}" aria-label="Día ${day}, ${description}" aria-disabled="${status === "locked"}" data-testid="node-${day}">
      <span class="node-symbol">${symbol}</span><span class="node-number">Día ${day}</span><span class="node-caption">${label}</span>
    </button>`;
  }).join("");
  main.innerHTML = `
    <section class="page-heading"><p class="eyebrow">CAMINO · BLOQUE ${sessionBlock(nextDay())}</p><h1>Un paso cada vez.</h1><p class="page-subtitle">Cada nodo es una sesión. Descansa cuando lo necesites; el camino te espera.</p></section>
    <section class="hero-panel" aria-label="Tu siguiente entrenamiento">
      <div class="hero-copy"><strong>${completed ? `Vas por el día ${nextDay()}` : "Tu primera sesión te espera"}</strong><p>Completa el nodo naranja para abrir el siguiente tramo de tu camino.</p></div>
      <div class="hero-icon" aria-hidden="true"><span class="hero-spark">✳</span></div>
    </section>
    <section class="pathway-wrap" aria-label="Camino de entrenamiento">
      <div class="pathway-head"><h2>Tu camino</h2><span>${completed} ${completed === 1 ? "sesión" : "sesiones"} completadas</span></div>
      <div class="pathway" style="height:${height}px">
        <svg class="path-svg" viewBox="0 0 100 ${height}" preserveAspectRatio="none" aria-hidden="true">${paths}</svg>
        ${nodeMarkup}
      </div>
      <div class="path-tail"><span class="path-tail-mark"></span><span>El progreso crece con cada sesión.</span></div>
    </section>
    <div id="view-status"></div>`;
  main.querySelectorAll("[data-node-day]").forEach((button) => button.addEventListener("click", () => {
    const day = Number(button.dataset.nodeDay);
    if (button.dataset.status === "locked") {
      showInline("Completa el día anterior para desbloquear este entrenamiento.", true);
      return;
    }
    openSession(day, button.dataset.status === "completed");
  }));
  const activeNode = main.querySelector(".path-node.available");
  if (activeNode && completed > 0) requestAnimationFrame(() => activeNode.scrollIntoView({ block: "center", behavior: "smooth" }));
}

function renderProgress() {
  const completed = countCompleted();
  const totalNodes = visibleNodeCount();
  const progressPercent = Math.round((completed / Math.max(1, totalNodes)) * 100);
  const history = state.sessions.slice().reverse().map((session) => {
    const extras = (session.extraExercises ?? []).map((exercise) =>
      `${escapeHtml(exercise.name)} ${exercise.sets}×${exercise.amount}${exercise.type === "duration" ? " s" : " repeticiones"} · ${exercise.completed ? "realizado" : "pendiente"}`
    );
    return `<article class="history-item" aria-label="Día ${session.day}, completado ${formatDate(session.completedOn)}">
      <div class="history-check" aria-hidden="true">✓</div>
      <div><div class="history-title">Día ${session.day} <span class="history-block">· Bloque ${session.block}</span></div>
      <div class="history-detail">Flexiones ${session.exercises.pushups.sets}×${session.exercises.pushups.reps}<br>Abdominales ${session.exercises.situps.sets}×${session.exercises.situps.reps}${extras.length ? `<br><strong>Extras:</strong> ${extras.join("<br>")}` : ""}</div></div>
      <time class="history-date" datetime="${session.completedOn}">${formatDate(session.completedOn)}</time>
    </article>`;
  }).join("");
  main.innerHTML = `
    <section class="page-heading"><p class="eyebrow">TU RECORRIDO</p><h1>El progreso se nota.</h1><p class="page-subtitle">Sesión a sesión, sin prisa y con constancia.</p></section>
    <section class="stats-grid" aria-label="Estadísticas">
      <article class="stat-card"><div class="stat-label"><span class="stat-symbol flame" aria-hidden="true">↗</span> Racha actual</div><div class="stat-value">${state.streak}<span class="stat-unit">sesiones</span></div></article>
      <article class="stat-card"><div class="stat-label"><span class="stat-symbol trophy" aria-hidden="true">★</span> Mejor racha</div><div class="stat-value">${state.bestStreak}<span class="stat-unit">sesiones</span></div></article>
      <article class="stat-card"><div class="stat-label"><span class="stat-symbol check" aria-hidden="true">✓</span> Días completados</div><div class="stat-value">${completed}</div></article>
      <article class="stat-card"><div class="stat-label"><span class="stat-symbol bars" aria-hidden="true">▥</span> Progreso total</div><div class="stat-value">${completed}<span class="stat-unit">/ ${totalNodes} sesiones</span></div><div class="progress-track" role="progressbar" aria-label="Progreso total" aria-valuemin="0" aria-valuemax="${totalNodes}" aria-valuenow="${completed}"><div class="progress-fill" style="width:${progressPercent}%"></div></div></article>
    </section>
    <section class="content-card"><div class="section-title" style="margin:0 0 10px"><h2>Marcas iniciales</h2><span>Tu punto de partida</span></div>
      <div class="marks-grid"><div class="mark-box"><div class="mark-label">Flexiones máximas</div><div class="mark-value">${state.initialMarks.pushupsMax} repeticiones</div></div><div class="mark-box"><div class="mark-label">Abdominales en 60 segundos</div><div class="mark-value">${state.initialMarks.situps60Seconds} repeticiones</div></div></div>
    </section>
    <div class="section-title"><h2>Historial de sesiones</h2><span>${completed} ${completed === 1 ? "registro" : "registros"}</span></div>
    ${completed ? `<section class="history-list" aria-label="Historial inmutable">${history}</section>` : `<section class="empty-state"><span class="empty-illustration" aria-hidden="true">○</span><strong>Aquí empieza tu historia</strong><p>Al terminar tu primera sesión, aparecerá aquí con su fecha y resultados.</p></section>`}
    <div id="view-status" hidden></div>`;
}

function renderSettings() {
  const canInstall = Boolean(installPrompt);
  main.innerHTML = `
    <section class="page-heading"><p class="eyebrow">EN ESTE DISPOSITIVO</p><h1>Tus datos, bajo tu control.</h1><p class="page-subtitle">RepQuest guarda el camino en este dispositivo. Exporta una copia para conservarlo.</p></section>
    <section class="settings-stack">
      <article class="settings-row"><div class="settings-copy"><strong>Exportar datos</strong><p>Descarga un respaldo completo y portable en formato JSON.</p></div><button class="button small" id="export-button" data-testid="export-data">EXPORTAR</button></article>
      <article class="settings-row"><div class="settings-copy"><strong>Importar datos</strong><p>Restaura un respaldo RepQuest válido. Primero se comprobará todo el archivo.</p></div><button class="button secondary small" id="import-button" data-testid="import-data">IMPORTAR</button></article>
      <article class="settings-row"><div class="settings-copy"><strong>Instalar RepQuest</strong><p id="install-description">${canInstall ? "Añade la aplicación a la pantalla de inicio." : "Si tu navegador lo permite, usa «Instalar aplicación» en el menú del navegador."}</p></div><button class="button secondary small" id="install-button">${canInstall ? "INSTALAR" : "CÓMO INSTALAR"}</button></article>
      <div id="view-status"></div>
      <section class="app-info"><strong>RepQuest v1.1</strong><br><strong>Uso sin conexión</strong><br>Después de la primera carga, la aplicación almacena sus archivos esenciales para abrirse sin conexión. Tus sesiones se guardan localmente y no se envían a ningún servidor.<br><br><strong>Inicio del camino:</strong> ${formatDate(state.startDate)} · <strong>Bloques:</strong> 5 sesiones.</section>
      <article class="settings-row"><div class="settings-copy"><strong>Restablecer progreso</strong><p>Borra sesiones, rachas y borradores guardados en este dispositivo.</p></div><button class="button danger small" id="reset-button" data-testid="reset-progress">BORRAR</button></article>
    </section>`;
  main.querySelector("#export-button").addEventListener("click", exportData);
  main.querySelector("#import-button").addEventListener("click", () => importInput.click());
  main.querySelector("#reset-button").addEventListener("click", openResetConfirmation);
  main.querySelector("#install-button").addEventListener("click", installApplication);
}

function showStatus(text, isError = false) {
  const target = document.querySelector("#view-status");
  if (!target) return;
  target.className = `status-note${isError ? " error" : ""}`;
  target.textContent = text;
  target.hidden = false;
}
function showInline(text, isError = false) {
  const target = document.querySelector("#view-status");
  if (target) {
    target.className = `status-note${isError ? " error" : ""}`;
    target.textContent = text;
    target.hidden = false;
  } else {
    showCelebration(text, "", false);
  }
}
function showCelebration(title, detail, success = true) {
  celebration.innerHTML = `<strong>${escapeHtml(title)}</strong>${detail ? `<p>${escapeHtml(detail)}</p>` : ""}`;
  celebration.style.background = success ? "" : "#fff0eb";
  celebration.style.color = success ? "" : "#a34331";
  celebration.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { celebration.hidden = true; }, 4400);
}

function openSession(day, readOnly) {
  if (readOnly && day > countCompleted()) return;
  if (!readOnly && day !== nextDay()) return;
  openedSession = { day, readOnly };
  dialogReturnFocus = document.activeElement;
  renderDialog();
  dialogBackdrop.hidden = false;
  document.body.style.overflow = "hidden";
  dialogPanel.querySelector(".dialog-close").focus();
}
function renderExtraExercises(exercises, readOnly) {
  if (!exercises.length) {
    return `<p class="extra-empty">${readOnly ? "No se añadieron ejercicios extra en esta sesión." : "Opcionales. Solo las flexiones y los abdominales son necesarios para guardar la sesión."}</p>`;
  }
  return exercises.map((exercise, index) => {
    const amountLabel = exercise.type === "duration" ? "Duración (segundos)" : "Repeticiones";
    if (readOnly) {
      return `<article class="extra-item ${exercise.completed ? "extra-done" : ""}">
        <div class="extra-readonly-title">${escapeHtml(exercise.name)} <span>${exercise.completed ? "COMPLETADO" : "PENDIENTE"}</span></div>
        <div class="extra-readonly-detail">${exercise.sets} ${exercise.sets === 1 ? "serie" : "series"} × ${exercise.amount} ${exercise.type === "duration" ? "segundos" : exercise.amount === 1 ? "repetición" : "repeticiones"}</div>
      </article>`;
    }
    return `<article class="extra-item" data-extra-index="${index}">
      <div class="extra-item-head"><strong>Ejercicio extra ${index + 1}</strong><button class="button secondary small remove-extra" type="button" data-remove-extra="${index}" aria-label="Quitar ejercicio extra ${index + 1}">Quitar</button></div>
      <div class="extra-fields">
        <label class="extra-field extra-name-field"><span class="field-label">Nombre</span><input class="extra-text-input" type="text" maxlength="80" placeholder="Ej. Plancha" value="${escapeHtml(exercise.name)}" data-extra-field="name" aria-label="Nombre del ejercicio extra ${index + 1}"></label>
        <label class="extra-field"><span class="field-label">Series</span><input class="extra-number-input" type="number" inputmode="numeric" min="1" step="1" value="${exercise.sets}" data-extra-field="sets" aria-label="Series del ejercicio extra ${index + 1}"></label>
        <label class="extra-field"><span class="field-label">Medida</span><select class="extra-select" data-extra-field="type" aria-label="Medida del ejercicio extra ${index + 1}">
          <option value="reps" ${exercise.type === "reps" ? "selected" : ""}>Repeticiones</option>
          <option value="duration" ${exercise.type === "duration" ? "selected" : ""}>Duración</option>
        </select></label>
        <label class="extra-field"><span class="field-label" data-extra-amount-label="${index}">${amountLabel}</span><input class="extra-number-input" type="number" inputmode="numeric" min="1" step="1" value="${exercise.amount}" data-extra-field="amount" aria-label="${amountLabel} del ejercicio extra ${index + 1}"></label>
      </div>
      <label class="check-row"><input type="checkbox" data-extra-field="completed" ${exercise.completed ? "checked" : ""}><span>Ejercicio extra completado</span></label>
    </article>`;
  }).join("");
}
function renderDialog(message = "") {
  const { day, readOnly } = openedSession;
  const session = readOnly ? state.sessions[day - 1] : null;
  const draft = readOnly ? session.exercises : getDraft(day);
  const extraExercises = readOnly ? (session.extraExercises ?? []) : (draft.extraExercises ?? []);
  const pushupsDone = readOnly ? session.pushupsDone : draft.pushupsDone;
  const situpsDone = readOnly ? session.situpsDone : draft.situpsDone;
  const block = readOnly ? session.block : sessionBlock(day);
  const field = (key, label, value) => `<label><span class="field-label">${label}</span><input class="number-input" type="number" inputmode="numeric" min="1" step="1" required value="${value}" data-exercise="${key}" ${readOnly ? "readonly" : ""} aria-label="${label}"></label>`;
  dialogPanel.innerHTML = `
    <div class="dialog-top"><div><p class="eyebrow">BLOQUE ${block} · ${readOnly ? "SESIÓN GUARDADA" : "ENTRENAMIENTO"}</p><h2 id="dialog-title">Día ${day}</h2><p id="dialog-description">${readOnly ? `Completado el ${formatDate(session.completedOn)}. Consulta tus resultados.` : "Ajusta la rutina base y añade ejercicios opcionales si quieres."}</p></div><button class="icon-button dialog-close" type="button" aria-label="Cerrar">×</button></div>
    ${readOnly ? `<div class="readonly-callout">✓ Esta sesión está guardada y no se puede modificar.</div>` : ""}
    <section class="exercise-card"><div class="exercise-heading"><span class="exercise-mark" aria-hidden="true">F</span> FLEXIONES</div><div class="inputs-row">${field("pushups", "Series", draft.pushups.sets)}${field("pushups", "Repeticiones", draft.pushups.reps)}</div><label class="check-row"><input type="checkbox" data-done="pushups" ${pushupsDone ? "checked" : ""} ${readOnly ? "disabled" : ""}><span>Flexiones completadas</span></label></section>
    <section class="exercise-card"><div class="exercise-heading"><span class="exercise-mark abs" aria-hidden="true">A</span> ABDOMINALES</div><div class="inputs-row">${field("situps", "Series", draft.situps.sets)}${field("situps", "Repeticiones", draft.situps.reps)}</div><label class="check-row"><input type="checkbox" data-done="situps" ${situpsDone ? "checked" : ""} ${readOnly ? "disabled" : ""}><span>Abdominales completados</span></label></section>
    <section class="exercise-card extra-section"><div class="exercise-heading"><span class="exercise-mark extra-mark" aria-hidden="true">＋</span> EJERCICIOS EXTRA · OPCIONALES</div>
      <div class="extra-exercise-list">${renderExtraExercises(extraExercises, readOnly)}</div>
      ${readOnly ? "" : `<button class="button secondary add-extra-button" type="button" id="add-extra-exercise">Añadir ejercicio</button>`}
    </section>
    <p class="dialog-message" role="status" aria-live="polite">${escapeHtml(message)}</p>
    <div class="dialog-actions">${readOnly ? `<button class="button secondary wide dialog-close" type="button">CERRAR</button>` : `<button class="button wide" type="button" id="save-session" data-testid="save-session">GUARDAR SESIÓN</button>`}</div>`;
  dialogPanel.querySelectorAll(".dialog-close").forEach((button) => button.addEventListener("click", closeDialog));
  if (readOnly) return;
  dialogPanel.querySelectorAll(".number-input").forEach((input) => input.addEventListener("input", saveDraftFromForm));
  dialogPanel.querySelectorAll("[data-done]").forEach((input) => input.addEventListener("change", saveDraftFromForm));
  dialogPanel.querySelectorAll("[data-extra-field]").forEach((input) => {
    input.addEventListener(input.type === "checkbox" || input.tagName === "SELECT" ? "change" : "input", saveDraftFromForm);
  });
  dialogPanel.querySelectorAll(".extra-select").forEach((select) => select.addEventListener("change", () => {
    const item = select.closest(".extra-item");
    const index = item.dataset.extraIndex;
    const label = item.querySelector(`[data-extra-amount-label="${index}"]`);
    const type = select.value;
    label.textContent = type === "duration" ? "Duración (segundos)" : "Repeticiones";
    const amount = item.querySelector('[data-extra-field="amount"]');
    amount.setAttribute("aria-label", `${label.textContent} del ejercicio extra ${Number(index) + 1}`);
    saveDraftFromForm();
  }));
  dialogPanel.querySelector("#add-extra-exercise").addEventListener("click", addExtraExercise);
  dialogPanel.querySelectorAll("[data-remove-extra]").forEach((button) => button.addEventListener("click", () => removeExtraExercise(Number(button.dataset.removeExtra))));
  dialogPanel.querySelector("#save-session").addEventListener("click", completeSession);
  dialogPanel.addEventListener("keydown", trapDialogTab);
}
function saveDraftFromForm() {
  const day = String(openedSession.day);
  const draft = readFormDraft();
  // Keep temporarily empty/invalid numeric input in the editor, but only persist schema-valid drafts.
  if (validDraft(draft)) {
    state.drafts[day] = draft;
    state.plans[day] = { pushups: { ...draft.pushups }, situps: { ...draft.situps } };
    persist();
  } else if (state.drafts[day]) {
    state.drafts[day].pushupsDone = draft.pushupsDone;
    state.drafts[day].situpsDone = draft.situpsDone;
    persist();
  }
}
function addExtraExercise() {
  saveDraftFromForm();
  const day = String(openedSession.day);
  const draft = state.drafts[day] ?? getDraft(Number(day));
  draft.extraExercises.push({ name: "", sets: 3, type: "reps", amount: 10, completed: false });
  state.drafts[day] = draft;
  persist();
  renderDialog();
  const newName = dialogPanel.querySelector(`[data-extra-index="${draft.extraExercises.length - 1}"] [data-extra-field="name"]`);
  newName?.focus();
}
function removeExtraExercise(index) {
  saveDraftFromForm();
  const day = String(openedSession.day);
  const draft = state.drafts[day] ?? getDraft(Number(day));
  draft.extraExercises.splice(index, 1);
  state.drafts[day] = draft;
  persist();
  renderDialog();
}
function completeSession() {
  if (openedSession.day !== nextDay()) {
    renderDialog("Esta sesión ya no está disponible. Abre el siguiente nodo del camino.");
    return;
  }
  const draft = getDraft(openedSession.day);
  const inputs = [...dialogPanel.querySelectorAll(".number-input")];
  const values = inputs.map((input) => input.value);
  if (values.some((value) => value.trim() === "" || !/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value)))) {
    renderDialog("Introduce series y repeticiones como números enteros positivos.");
    return;
  }
  const current = readFormDraft();
  if (!current.pushupsDone || !current.situpsDone) {
    renderDialog("Completa ambos ejercicios antes de continuar.");
    return;
  }
  if (!validPlan(current)) {
    renderDialog("Revisa los valores: deben ser números enteros positivos.");
    return;
  }
  const extraExercises = current.extraExercises.map((exercise) => ({ ...exercise, name: exercise.name.trim() }));
  if (extraExercises.some((exercise) => exercise.completed && !validExtraExercise(exercise))) {
    renderDialog("Completa el nombre y los datos del ejercicio extra marcado como realizado.");
    return;
  }
  const savedExtraExercises = extraExercises.filter((exercise) => validExtraExercise(exercise));
  const day = openedSession.day;
  const previousState = structuredClone(state);
  const completedAt = new Date().toISOString();
  const elapsedSinceBase = state.lastBaseCompletedAt ? Date.parse(completedAt) - Date.parse(state.lastBaseCompletedAt) : Infinity;
  const nextStreak = elapsedSinceBase >= 0 && elapsedSinceBase <= STREAK_WINDOW_MS ? state.streak + 1 : 1;
  state.plans[String(day)] = { pushups: { ...current.pushups }, situps: { ...current.situps } };
  state.sessions.push({
    day, block: sessionBlock(day), completedOn: localDateISO(new Date(completedAt)), completedAt,
    exercises: { pushups: { ...current.pushups }, situps: { ...current.situps } },
    pushupsDone: true, situpsDone: true, extraExercises: savedExtraExercises
  });
  state.streak = nextStreak;
  state.lastBaseCompletedAt = completedAt;
  state.bestStreak = Math.max(state.bestStreak, state.streak);
  delete state.drafts[String(day)];
  if (day + 4 <= visibleNodeCount()) {
    for (let next = 1; next <= visibleNodeCount() + 5; next += 1) {
      if (!state.plans[String(next)]) state.plans[String(next)] = structuredClone(DEFAULT_PLAN);
    }
  }
  if (!persist()) {
    const saveError = storageWarning;
    state = previousState;
    renderDialog(`No se pudo guardar el entrenamiento. ${saveError}`);
    return;
  }
  closeDialog();
  setView("camino");
  const blockComplete = day % 5 === 0;
  showCelebration(blockComplete ? "¡Bloque completado!" : "¡Entrenamiento completado!", blockComplete ? `¡Bloque ${sessionBlock(day)} completado! Racha: ${state.streak} sesiones. El camino continúa.` : `Has completado tu entrenamiento. Racha: ${state.streak} sesiones.`);
  requestAnimationFrame(() => main.querySelector(".path-node.available")?.scrollIntoView({ block: "center", behavior: "smooth" }));
}
function readFormDraft() {
  const inputs = [...dialogPanel.querySelectorAll(".number-input")];
  const val = (exercise, name) => Number(inputs.find((input) => input.dataset.exercise === exercise && input.getAttribute("aria-label") === name)?.value);
  return {
    pushups: { sets: val("pushups", "Series"), reps: val("pushups", "Repeticiones") },
    situps: { sets: val("situps", "Series"), reps: val("situps", "Repeticiones") },
    pushupsDone: Boolean(dialogPanel.querySelector('[data-done="pushups"]')?.checked),
    situpsDone: Boolean(dialogPanel.querySelector('[data-done="situps"]')?.checked),
    extraExercises: [...dialogPanel.querySelectorAll(".extra-item[data-extra-index]")].map((item) => ({
      name: item.querySelector('[data-extra-field="name"]').value,
      sets: Number(item.querySelector('[data-extra-field="sets"]').value),
      type: item.querySelector('[data-extra-field="type"]').value,
      amount: Number(item.querySelector('[data-extra-field="amount"]').value),
      completed: Boolean(item.querySelector('[data-extra-field="completed"]').checked)
    }))
  };
}
function closeDialog() {
  dialogBackdrop.hidden = true;
  document.body.style.overflow = "";
  openedSession = null;
  if (dialogReturnFocus instanceof HTMLElement && dialogReturnFocus.isConnected) dialogReturnFocus.focus();
  dialogReturnFocus = null;
}
function trapDialogTab(event) {
  if (event.key === "Escape") closeDialog();
  if (event.key !== "Tab") return;
  const focusable = [...dialogPanel.querySelectorAll("button:not(:disabled),input:not(:disabled)")];
  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
  else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
}
function openResetConfirmation() {
  openedSession = { type: "reset" };
  dialogReturnFocus = document.activeElement;
  dialogPanel.innerHTML = `<div class="dialog-top"><div><p class="eyebrow">ACCIÓN PERMANENTE</p><h2 id="dialog-title">¿Borrar el camino?</h2><p id="dialog-description">¿Seguro que quieres borrar todo tu progreso?</p></div><button class="icon-button dialog-close" type="button" aria-label="Cerrar">×</button></div><div class="dialog-actions"><button class="button secondary" id="cancel-reset">CANCELAR</button><button class="button danger" id="confirm-reset" data-testid="confirm-reset">BORRAR PROGRESO</button></div>`;
  dialogBackdrop.hidden = false;
  document.body.style.overflow = "hidden";
  dialogPanel.querySelector(".dialog-close").addEventListener("click", closeDialog);
  dialogPanel.querySelector("#cancel-reset").addEventListener("click", closeDialog);
  dialogPanel.addEventListener("keydown", trapDialogTab);
  dialogPanel.querySelector(".dialog-close").focus();
  dialogPanel.querySelector("#confirm-reset").addEventListener("click", () => {
    const previousState = state;
    state = freshState();
    if (!persist()) {
      state = previousState;
      closeDialog();
      render();
      showStatus(storageWarning, true);
      return;
    }
    closeDialog();
    render();
    showStatus("Progreso restablecido. Tu camino empieza de nuevo en el Día 1.");
  });
}

function exportData() {
  const payload = { app: "RepQuest", version: SCHEMA_VERSION, exportedAt: new Date().toISOString(), data: state };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `repquest-respaldo-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(url);
  showStatus("Respaldo exportado correctamente.");
}
function getBackupState(payload) {
  if (!payload || typeof payload !== "object" || Array.isArray(payload) || payload.app !== "RepQuest" ||
      typeof payload.exportedAt !== "string" || Number.isNaN(Date.parse(payload.exportedAt))) return null;
  if (payload.version === SCHEMA_VERSION && validateState(payload.data)) return payload.data;
  if (payload.version === LEGACY_SCHEMA_VERSION && validateLegacyState(payload.data)) return migrateLegacyState(payload.data);
  return null;
}
importInput.addEventListener("change", async () => {
  const file = importInput.files?.[0];
  if (!file) return;
  try {
    const parsed = JSON.parse(await file.text());
    const importedState = getBackupState(parsed);
    if (!importedState) throw new Error("El archivo no cumple el formato RepQuest o contiene datos inconsistentes.");
    const previousState = state;
    state = importedState;
    if (!persist()) {
      state = previousState;
      throw new Error(storageWarning);
    }
    activeView = "camino";
    render();
    showStatus("Respaldo importado correctamente. Tu camino se ha restaurado.");
  } catch (error) {
    showStatus(error instanceof SyntaxError ? "No se pudo leer el JSON. Selecciona un respaldo válido." : error.message || "No se pudo importar el archivo.", true);
  } finally {
    importInput.value = "";
  }
});
async function installApplication() {
  if (!installPrompt) {
    showStatus("La instalación depende del navegador. Abre el menú y elige «Instalar aplicación» o «Añadir a pantalla de inicio».");
    return;
  }
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  render();
}
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event;
  if (activeView === "ajustes") render();
});
window.addEventListener("appinstalled", () => {
  installPrompt = null;
  if (activeView === "ajustes") render();
});

document.querySelectorAll(".nav-button").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
dialogBackdrop.addEventListener("click", (event) => { if (event.target === dialogBackdrop) closeDialog(); });
window.setInterval(() => {
  if (expireStreakIfNeeded()) render();
}, 60 * 1000);
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && expireStreakIfNeeded()) render();
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {
    showInline("No se pudo activar el modo sin conexión. La aplicación sigue disponible mientras esta pestaña esté abierta.", true);
  }));
}
render();
