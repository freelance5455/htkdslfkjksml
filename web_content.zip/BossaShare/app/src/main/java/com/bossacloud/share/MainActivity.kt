package com.bossacloud.share

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.IntentCompat
import java.io.FileInputStream

/** Servidor Pingvin Share. */
const val BASE_URL = "http://bossacloud.ddns.net:3030"

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private val shared = mutableListOf<Uri>()

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uris = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        chooserCallback?.onReceiveValue(uris)
        chooserCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = object : WebViewClient() {
            // Sirve el logo desde los assets de la app (la página usa el origen del servidor).
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (request.url.path == "/__app/logo.png") {
                    return WebResourceResponse("image/png", null, assets.open("logo.png"))
                }
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams,
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = callback
                return try {
                    chooser.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    chooserCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        if (savedInstanceState == null) handleIntent(intent)

        // La página se sirve "como si" viniera del servidor: así las llamadas a /api
        // son del mismo origen (sin CORS) y las cookies de sesión funcionan.
        val html = assets.open("index.html").bufferedReader().use { it.readText() }
        web.loadDataWithBaseURL("$BASE_URL/", html, "text/html", "utf-8", null)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
        web.evaluateJavascript("window.onShared && window.onShared()", null)
    }

    /** Archivos recibidos desde el menú Compartir de Android. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_SEND ->
                listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
            else -> emptyList()
        }
        if (uris.isNotEmpty()) synchronized(shared) { shared.clear(); shared.addAll(uris) }
    }

    /** Funciones que el HTML puede llamar como `Android.xxx()`. */
    inner class Bridge {
        @JavascriptInterface
        fun sharedCount(): Int = synchronized(shared) { shared.size }

        @JavascriptInterface
        fun clearShared() = synchronized(shared) { shared.clear() }

        @JavascriptInterface
        fun sharedName(i: Int): String {
            val uri = synchronized(shared) { shared.getOrNull(i) } ?: return "archivo"
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (n >= 0) c.getString(n)?.let { return it }
                }
            }
            return uri.lastPathSegment ?: "archivo"
        }

        @JavascriptInterface
        fun sharedSize(i: Int): Double {
            val uri = synchronized(shared) { shared.getOrNull(i) } ?: return 0.0
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val s = c.getColumnIndex(OpenableColumns.SIZE)
                    if (s >= 0 && !c.isNull(s)) return c.getLong(s).toDouble()
                }
            }
            return (contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L).toDouble()
        }

        /** Devuelve un trozo del archivo compartido codificado en base64. */
        @JavascriptInterface
        fun sharedChunk(i: Int, offset: Double, length: Int): String {
            val uri = synchronized(shared) { shared.getOrNull(i) } ?: return ""
            val pfd = contentResolver.openFileDescriptor(uri, "r") ?: return ""
            ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input ->
                val start = offset.toLong()
                try {
                    (input as FileInputStream).channel.position(start)
                } catch (e: Exception) {
                    var left = start
                    while (left > 0) {
                        val s = input.skip(left)
                        if (s <= 0) break
                        left -= s
                    }
                }
                val buf = ByteArray(length)
                var read = 0
                while (read < length) {
                    val n = input.read(buf, read, length - read)
                    if (n < 0) break
                    read += n
                }
                return Base64.encodeToString(buf, 0, read, Base64.NO_WRAP)
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, "Compartir enlace"))
            }
        }

        @JavascriptInterface
        fun copy(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("enlace", text))
                Toast.makeText(this@MainActivity, "Enlace copiado", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun open(url: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        }
    }
}
