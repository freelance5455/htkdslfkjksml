# BossaShare (Android + HTML)

App Android cuya interfaz es una página **HTML** (`app/src/main/assets/index.html`) mostrada en un WebView.
Sube y comparte archivos con tu servidor **Pingvin Share** en `http://bossacloud.ddns.net:3030`.

## Estructura
- `app/src/main/assets/index.html` → toda la interfaz y la lógica (login, subida, lista de envíos). Edítala como una web normal.
- `app/src/main/java/.../MainActivity.kt` → WebView, selector de archivos y puente para recibir archivos del menú Compartir.

## Qué hace
- Inicio de sesión con tu usuario de Pingvin Share (la sesión queda en las cookies del WebView).
- Elegir archivos del móvil **o recibirlos desde el menú Compartir de Android**.
- Crea un envío, sube por trozos de 2 MB y genera el enlace; compartir / copiar / abrir / borrar.

## Compilar
1. Android Studio (Ladybug o más reciente) → `File > Open` → carpeta `BossaShare`.
2. Sincroniza Gradle, conecta el móvil y pulsa **Run** (o `Build > Build APK(s)`).

## Notas
- El servidor usa **http sin cifrar**: usuario, contraseña y archivos viajan en claro. Lo ideal es poner HTTPS
  y cambiar `BASE_URL` en `MainActivity.kt` a `https://...`.
- La página se carga con el servidor como origen base, así las llamadas a `/api` no tienen problemas de CORS.
- Endpoints usados (de la documentación pública de Pingvin Share, sin probar contra tu servidor):
  `/api/auth/signIn`, `/api/auth/token`, `/api/auth/signOut`, `/api/shares`, `/api/shares/:id/files`, `/api/shares/:id/complete`.
- No soporta cuentas con verificación en dos pasos (TOTP) ni envíos inversos.
