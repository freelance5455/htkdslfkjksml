Version 4.41 – Teilen-Fehler werden sichtbar gemeldet; kein automatischer Download-Fallback mehr. Der Teilen-Aufruf übergibt nur die JSON-Datei. Abbrechen aktualisiert den Sicherungszeitpunkt nicht.

Version 4.39 – Backup-Dialog für schmale Handybildschirme neu angeordnet: Export- und Teilen-Schaltflächen stehen in zwei Spalten, Beschriftungen umbrechen sauber und der Dialog nutzt den verfügbaren Bildschirmplatz besser.

SCHICHTPLANER – VERSION 4.41
===========================

Aktueller Stand
---------------
- Speicherschutz: Die App fragt beim Start beim Browser nach dauerhaftem Speicher und zeigt den Status in App-Info an. Regelmäßige JSON-Backups bleiben wichtig.
- Backup teilen: Auf unterstützten Geräten kann das JSON-Backup über die Android-Teilen-Funktion geteilt werden.
- Gehaltsabgleich: Bruttobeträge aus der Abrechnung lassen sich je Monat speichern, mit der Schätzung vergleichen und im JSON-Backup sichern.
- Backup-Format Version 3; Importe der Formate Version 1 und 2 werden weiterhin unterstützt.
- Browserbasierte HTML/PWA-Version; keine native Android-APK.

Versionspflege
--------------
Die Versionsnummer dieser Ausgabe lautet 4.41 und ist in App-Info, Manifest,
Service-Worker-Cache, README, ZIP-Dateiname und Projektordner einheitlich geführt.

Änderungsverlauf (neueste Version zuerst)
-----------------------------------------
Version 4.41
- Teilen-Aufruf vereinfacht: Es wird nur die JSON-Datei übergeben.
- Bei einem Fehler erscheint die konkrete Browser-Fehlermeldung statt eines automatischen Downloads.
- Abbruch bleibt ohne Fehlermeldung und ohne Aktualisierung des Sicherungszeitpunkts.

Version 4.40
- Fehlerbehandlung beim Teilen ergänzt; zuvor lösten Dateifreigabe-Fehler einen Fallback zum Download aus.
- Abbruch des Teilen-Dialogs blieb ohne Fehlermeldung und ohne Aktualisierung des Sicherungszeitpunkts.

Version 4.39
- Backup-Dialog für schmale Handybildschirme kompakter angeordnet.

Version 4.38
- Dauerhaften Speicher anfragen und den Schutzstatus in App-Info anzeigen.
- JSON-Backups über die Teilen-Funktion teilen, sofern der Browser Dateifreigabe unterstützt.
- Monatlichen Bruttobetrag aus der Gehaltsabrechnung speichern, Differenz anzeigen und in Backup, CSV und Monatsbericht berücksichtigen.
- Backup-Format auf Version 3 erweitert; ältere Backup-Versionen 1 und 2 bleiben importierbar.

Version 4.33
- Wochentag steht links neben dem Datumsfeld in derselben Zeile.
- Die Aktionsleiste mit „Speichern“ bleibt beim Scrollen im Dialog am unteren
  Rand sichtbar.

Version 4.22
- Beschäftigungsmodell (Minijob, Teilzeit, Vollzeit oder sonstige Beschäftigung)
  in „Arbeitszeit & Lohn“.
- Verdienstwarnungen erscheinen nur beim Beschäftigungsmodell Minijob.

Version 4.20
- Jahresauswertung mit Monatsdiagrammen für Bruttoverdienst und vergütete Stunden
  sowie Jahres-/Monatsübersicht für Grundlohn und Zuschläge.
- Monatsbericht über „Backup & Daten“ drucken oder im Druckdialog als PDF speichern.
- PDF-Ausgabe ohne Internetverbindung und ohne externe Bibliothek über die
  Druckfunktion des Browsers.

Version 4.18
- Bundesland in „Einstellungen > Feiertage“ auswählbar; Feiertagsliste und
  Zuschlagsberechnung richten sich nach der Auswahl.

Version 4.17
- PWA-Icons in 192 × 192 und 512 × 512, einschließlich Maskable-Icon.
- Service-Worker-Cache aktualisiert; ältere Schichtplaner-Caches werden beim
  Aktivieren entfernt.
- Sichtbare Tastatur-Fokusmarkierungen, Tastaturbedienung für Kalendertage und
  zugängliche Labels.
- CSV-Export des angezeigten Monats (Semikolon-getrennt, UTF-8-BOM für Excel),
  einschließlich Stunden und Lohnaufschlüsselung.

Version 4.16
- „Design“ steht an vierter Stelle in den Einstellungen.
- Farbprüfung der fünf dunklen Designs: Flächen, Eingabefelder, Hinweise,
  Warnungen, Kalender, Dialoge, Vorlagen und Navigation verwenden abgestimmte
  Designfarben; feste blaue Akzente in anderen Farbpaletten wurden entfernt.

Version 4.12
- Menüpunkt „Berechnung & Hinweise“ aus den Einstellungen entfernt.
- Berechnungslogik und gespeicherte Schichtdaten bleiben unverändert.
- Service-Worker-Cache aktualisiert.

Version 4.11
- Vorhandene Einträge lassen sich über „Kopieren“ auf mehrere Tage übertragen;
  bereits vorhandene identische Einträge werden übersprungen.
- Backup-Import prüft Format, Datums- und Zeitangaben, IDs, Schichtvorlagen,
  Pausen sowie wichtige Einstellungsgrenzen.
- Vor dem Ersetzen vorhandener Daten wird eine Sicherheitskopie als JSON exportiert;
  bei Speicherfehlern wird eine Wiederherstellung des bisherigen Datenstands versucht.
- Service-Worker-Cache aktualisiert.

Version 4.0
- Normale Schichten zählen automatisch; eine Ist-Bestätigung ist nicht mehr nötig.
- Urlaub und Krankheit können pro Datum eingetragen werden und zählen mit den
  festgelegten vergüteten Stunden. Standardstunden sind einstellbar und pro Eintrag
  anpassbar.
- „Unbezahlt ausgefallen“ zählt mit 0 Stunden und 0 Euro.
- Monats- und Jahresübersicht sowie Jahresdiagramm berücksichtigen alle Einträge.
- Vorhandene Daten und Backups bleiben erhalten.

Version 3.2
- Doppelte Verknüpfungen zu Backup und Schichtvorlagen im Menü „Mehr“ entfernt.
  Beide Funktionen bleiben unter „Einstellungen“ verfügbar.

Frühere Basisversion 3.0 (historisch zusammengefasst)
- Mobiloptimierter Dialog für Schichtvorlagen mit Name, Farbe, Beginn, Ende, Pause
  und Auswahl, ob die Pause bezahlt wird.
- Änderungen an einer einzelnen Schicht ändern nicht automatisch die Vorlage.
- Kalenderdarstellung und Navigation wurden für schmale Displays optimiert;
  unter anderem Schichtnamen in Tageskacheln, zentrierte Beschriftung und ein
  „Heute“-Button zum Zurückspringen in den aktuellen Monat.
- SVG-Symbole in der unteren Navigationsleiste wurden auf einheitliche Maße gebracht.

Installation und Nutzung auf Android
------------------------------------
1. ZIP-Datei herunterladen und entpacken.
2. „index.html“ in Chrome oder einem anderen modernen Browser öffnen.
3. Je nach Browser-Sicherheitsregeln kann für Service Worker und die PWA-Funktion
   ein lokaler Webserver oder Hosting (z. B. GitHub Pages/Netlify) erforderlich sein.

Hinweis: Die App speichert ihre Daten lokal im jeweiligen Browser. Bei Browserwechsel,
Löschen der Browserdaten oder Gerätewechsel können Daten verloren gehen. Daher
regelmäßig ein manuelles JSON-Backup exportieren und sicher aufbewahren.
