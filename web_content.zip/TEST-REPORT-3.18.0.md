# RISEUP 3.18.0 — Recurring Daily Side Tasks

## Changes
- Side tasks are now fixed recurring daily tasks, like core tasks.
- Completing each active side task awards XP once per day: easy 5, medium 7, hard 10.
- Side tasks reset by date-keyed completion records; no manual daily recreation is required.
- Side tasks have no missed-task penalty and do not affect the core-task streak.
- Users can add, rename, change difficulty, and deactivate side tasks.
- Existing active side tasks migrate once into recurring definitions; old XP ledger entries are preserved.

## Preserved
- Core tasks: +20 XP per completion and −20 XP per missed task, with streak reset.
- Existing ranks, level progression, goals, spiritual path, collection, artwork and sound settings.

## Validation
- Static JavaScript syntax and UI assertions.
- PWA cache/version checks.
- Gameplay and XP audit tests.
- Artwork and sound tests.
- No physical Android device/APK test was performed.
