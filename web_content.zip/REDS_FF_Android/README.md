# REDS FF — Android project

Projeto Android simples que empacota uma interface local em WebView. É um painel demonstrativo de treino/configurações; não modifica o Free Fire, não automatiza a mira e não inclui cheats.

## Como gerar APK
1. Extraia o ZIP.
2. Abra a pasta `REDS_FF_Android` no Android Studio.
3. Aguarde a sincronização do Gradle. Use JDK 17.
4. Se o Android Studio solicitar, instale Android SDK Platform 35 e aceite as atualizações sugeridas.
5. Para um APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- Este ZIP contém o código-fonte do projeto, não um APK já compilado.
- Não requer permissão de internet.
- Os controles da interface funcionam localmente e são apenas demonstrativos.
