# تشغيل AMAZON GAZA الحقيقي

## أسهل تشغيل محلي
1. عدّل كلمة مرور PostgreSQL في `docker-compose.yml`.
2. أنشئ hash لكلمة مرور المؤسس:
   `node apps/api/scripts/make-founder-hash.mjs`
3. ضع قيمتي salt/hash في البيئة.
4. ضع `JWT_SECRET` قويًا.
5. إذا أردت AI حقيقيًا، ضع `GEMINI_API_KEY` على الخادم فقط.
6. شغّل:
   `docker compose up --build`
7. افتح:
   `http://localhost:4000`

قاعدة البيانات تُنشأ من `database/schema.sql` ثم `database/seed.sql` عند إنشاء volume جديد.

## نشر عام
استخدم `render.yaml` كنقطة بداية لخدمة Node + PostgreSQL. بعد النشر، ضع أسرار المؤسس وAI في Environment Variables على الخادم، وليس داخل HTML.

## مهم
- الدفع عبر Jawwal Pay/Paltel Pay ليس ادعاءً بأنه متصل ماليًا حتى يتم إدخال بيانات التاجر الرسمية وwebhooks.
- AI يعمل فقط عند توفر مفتاح مزود AI.
- الموقع يعمل عبر الإنترنت فقط.
