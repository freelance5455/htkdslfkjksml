const $ = s => document.querySelector(s);
const messagesEl = $("#messages"), welcome = $("#welcome"), promptEl = $("#prompt");
let chats = [];
try { chats = JSON.parse(localStorage.getItem("aira_chats") || "[]"); } catch (_) { chats = []; }
let currentId = null, holdTimer = null, suppressClick = false;
let airaUser = { name: "" };
try {
  const savedProfile = JSON.parse(localStorage.getItem("aira_profile") || "null");
  if (savedProfile && typeof savedProfile.name === "string") airaUser.name = savedProfile.name;
} catch (_) {}

function cleanUsername(value) {
  return (value || "").trim().replace(/\s+/g, " ").slice(0, 24);
}
function enterAsGuest(name) {
  const username = cleanUsername(name);
  if (!username) {
    alert("Escribí un nombre de usuario para continuar.");
    return;
  }
  airaUser.name = username;
  // Only the display name is saved locally. No email or password is stored.
  localStorage.setItem("aira_profile", JSON.stringify({ name: username, mode: "guest" }));
  $("#entryScreen").classList.remove("visible");
  $("#mainApp").hidden = false;
  const heading = $("#welcomeHeading");
  if (heading) heading.innerHTML = `Hola, <em>${escapeHTML(username)}</em>.`;
  updateProfileUI();
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[char]));
}
function showEntryPanel(panel) {
  $("#entryChoices").hidden = panel !== "choices";
  $("#accountForm").hidden = panel !== "account";
  $("#guestForm").hidden = panel !== "guest";
}


function save() {
  try { localStorage.setItem("aira_chats", JSON.stringify(chats)); }
  catch (error) { console.warn("No se pudo guardar el historial", error); }
  renderHistory();
}
function current() { return chats.find(c => c.id === currentId); }

function newChat() {
  const chat = { id: Date.now().toString() + Math.random().toString(16).slice(2,6), title: "Nuevo chat", messages: [], pinned: false, archived: false };
  chats.unshift(chat); currentId = chat.id; save(); renderChat(); closeMenu(); promptEl.focus();
}
function selectChat(id) {
  const chat = chats.find(c => c.id === id);
  if (!chat) return;
  currentId = id; renderChat(); renderHistory(); closeMenu();
}
function renderHistory() {
  const el = $("#history");
  if (!el) return;
  el.innerHTML = "";
  const active = chats.filter(c => !c.archived).sort((a,b) => Number(!!b.pinned)-Number(!!a.pinned));
  const archived = chats.filter(c => c.archived);
  function section(label, list) {
    if (!list.length) return;
    const heading=document.createElement("div"); heading.className="side-label"; heading.textContent=label; el.appendChild(heading);
    list.forEach(chat => {
      const row=document.createElement("div"); row.className="history-item";
      const b=document.createElement("button"); b.type="button"; b.className="history-chat"+(chat.id===currentId?" active":"");
      if(chat.pinned&&!chat.archived){const pin=document.createElement("span");pin.className="pin-mark";pin.textContent="◆";b.appendChild(pin);}
      const title=document.createElement("span");title.className="history-title";title.textContent=chat.title||"Nuevo chat";b.appendChild(title);
      b.addEventListener("click",()=>{if(suppressClick){suppressClick=false;return;}selectChat(chat.id);});
      b.addEventListener("pointerdown",e=>{
        if(e.pointerType==="mouse"&&e.button!==0)return;
        suppressClick=false; clearTimeout(holdTimer);
        holdTimer=setTimeout(()=>{suppressClick=true;showChatMenu(chat,b);},600);
      });
      ["pointerup","pointerleave","pointercancel"].forEach(type=>b.addEventListener(type,()=>clearTimeout(holdTimer)));
      b.addEventListener("contextmenu",e=>{e.preventDefault();suppressClick=true;clearTimeout(holdTimer);showChatMenu(chat,b);});
      row.appendChild(b);el.appendChild(row);
    });
  }
  section("CHATS",active); section("ARCHIVADOS",archived);
}
function renderChat() {
  messagesEl.innerHTML="";
  const chat=current();
  welcome.style.display=(!chat||!chat.messages.length)?"block":"none";
  if(!chat)return;
  chat.messages.forEach(m=>addBubble(m.role,m.text,false));
  $("#conversation").scrollTop=$("#conversation").scrollHeight;
}
function addBubble(role,text,scroll=true) {
  const row=document.createElement("div");row.className="message "+role;
  const icon=document.createElement("div");icon.className="msg-icon";icon.textContent=role==="assistant"?"✦":"TÚ";
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;
  row.append(icon,bubble);
  if(role==="assistant" && localStorage.getItem("aira_voice_enabled")!=="false" && "speechSynthesis" in window && "SpeechSynthesisUtterance" in window){
    const voiceButton=document.createElement("button");
    voiceButton.type="button";
    voiceButton.className="voice-button";
    voiceButton.setAttribute("aria-label","Escuchar respuesta de AIRA");
    voiceButton.title="Escuchar con la voz de AIRA";
    voiceButton.textContent="🔊";
    voiceButton.addEventListener("click",()=>speakAira(text,voiceButton));
    row.appendChild(voiceButton);
  }
  messagesEl.appendChild(row);
  if(scroll)$("#conversation").scrollTop=$("#conversation").scrollHeight;
}

function speakAira(text,button){
  if(!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)){
    alert("Tu navegador no permite reproducir voz. Probá con Chrome actualizado.");
    return;
  }
  if(window.speechSynthesis.speaking){
    window.speechSynthesis.cancel();
    document.querySelectorAll(".voice-button").forEach(b=>b.classList.remove("speaking"));
    if(button.dataset.active==="yes"){button.dataset.active="no";return;}
  }
  const clean=(text||"").replace(/\*\*(.*?)\*\*/g,"$1").replace(/https?:\/\/\S+/g,"").replace(/[💚✨✦]/g,"").trim();
  const utterance=new SpeechSynthesisUtterance(clean);
  utterance.lang="es-AR";
  utterance.rate=Number(localStorage.getItem("aira_voice_rate") || "0.96");
  utterance.pitch=1.12;
  const voices=window.speechSynthesis.getVoices();
  const spanish=voices.filter(v=>/^es([-_]|$)/i.test(v.lang));
  const feminine=spanish.find(v=>/female|femen|mujer|woman|sofia|sabina|helena|lucia|monica|paulina|zira/i.test(v.name));
  utterance.voice=feminine || spanish.find(v=>/ar|es-|es_/i.test(v.lang)) || spanish[0] || null;
  button.dataset.active="yes";
  button.classList.add("speaking");
  utterance.onend=()=>{button.dataset.active="no";button.classList.remove("speaking");};
  utterance.onerror=()=>{button.dataset.active="no";button.classList.remove("speaking");};
  window.speechSynthesis.speak(utterance);
}
function normalize(s) {
  return (s||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[¿?¡!.,;:]/g," ").replace(/\s+/g," ").trim();
}
function calculate(q) {
  const m=q.match(/(?:cuanto es|cuanto da|calcula|resuelve)?\s*(-?\d+(?:[.,]\d+)?)\s*([+\-*x/÷])\s*(-?\d+(?:[.,]\d+)?)/);
  if(!m)return null;
  const a=Number(m[1].replace(",",".")),b=Number(m[3].replace(",","."));
  let r;
  switch(m[2]){case "+":r=a+b;break;case "-":r=a-b;break;case "*":case "x":r=a*b;break;case "/":case "÷":if(b===0)return "No se puede dividir por cero.";r=a/b;break;}
  return "El resultado es **"+Number(r.toFixed(8))+"**.";
}
function answer(input) {
  const q=normalize(input);
  const calc=calculate(q); if(calc)return calc;

  const rules=[
    [/^(hola|holaa|buenas|buen dia|buenas tardes|buenas noches|hey|que onda)\b/,`¡Hola${airaUser.name ? " " + airaUser.name : ""}! 💚 Soy AIRA. Todavía estoy en una beta sin conexión a una IA real, pero puedo responder varias preguntas frecuentes, hacer cuentas sencillas y ayudarte con ideas. ¿Qué querés saber?`],
    [/(quien sos|quien eres|que sos|que eres|presentate)/,"Soy AIRA, un asistente digital en desarrollo, creado como producto de PLÉYADES. En esta beta funciono con respuestas locales y reglas sencillas; todavía no tengo un modelo de IA conectado."],
    [/(que podes hacer|que puedes hacer|para que servis|como me ayudas|tus funciones)/,"Por ahora puedo responder preguntas frecuentes, explicar conceptos generales, resolver cuentas simples, dar ideas, ayudarte a estudiar y ordenar proyectos. Todavía no puedo buscar en Internet ni aprender de cada conversación."],
    [/(quien te creo|quien te hizo|empresa|pleyades)/,"AIRA es el asistente y PLÉYADES es la compañía que estamos usando como identidad matriz del proyecto."],
    [/(que significa aira|significado de aira)/,"AIRA es el nombre elegido para este asistente. Como significado de marca propusimos “Asistente Inteligente y Adaptativo”. Es una interpretación creativa, no una sigla oficial."],
    [/(como estas|todo bien|como va)/,"¡Funcionando y lista para probar! Todavía soy una versión básica, pero cada prueba nos ayuda a mejorar AIRA. 💚"],
    [/(gracias|muchas gracias|te agradezco)/,"¡De nada! 💚 Si algo no sale bien, contame qué pasó y lo mejoramos."],
    [/(chau|adios|hasta luego|nos vemos)/,"¡Hasta la próxima! Cuando vuelvas, AIRA va a estar lista para otra prueba."],
    [/(que es la inteligencia artificial|que es ia|define ia)/,"La inteligencia artificial (IA) es un área de la informática que crea sistemas capaces de realizar tareas como reconocer patrones, comprender lenguaje o generar contenido. No todos los sistemas de IA funcionan igual: algunos usan reglas y otros modelos entrenados con grandes cantidades de datos."],
    [/(como funciona la inteligencia artificial|como aprende una ia)/,"Muchos sistemas de IA se entrenan con ejemplos. Durante el entrenamiento ajustan sus parámetros para reconocer patrones y producir resultados. Después, al recibir una consulta, usan lo aprendido para generar una respuesta. Esta beta de AIRA todavía no usa ese tipo de modelo."],
    [/(que es un algoritmo|define algoritmo)/,"Un algoritmo es una serie ordenada de pasos para resolver un problema o realizar una tarea. Una receta de cocina, por ejemplo, puede verse como un algoritmo."],
    [/(que es internet|como funciona internet)/,"Internet es una red mundial de redes y dispositivos que intercambian información usando reglas comunes, como el conjunto de protocolos TCP/IP. La web es uno de los servicios que funciona sobre Internet."],
    [/(que es la fotosintesis|como hacen las plantas su alimento)/,"La fotosíntesis es el proceso por el que plantas, algas y algunas bacterias usan energía de la luz para transformar agua y dióxido de carbono en sustancias orgánicas. En las plantas también se libera oxígeno."],
    [/(que es la gravedad|por que caen las cosas)/,"La gravedad es una interacción de atracción entre cuerpos con masa. En la Tierra hace que los objetos sean atraídos hacia su centro y explica, por ejemplo, por qué caen cuando los soltamos."],
    [/(capital de argentina|capital argentina)/,"La capital de Argentina es la Ciudad Autónoma de Buenos Aires."],
    [/(capital de francia|capital francia)/,"La capital de Francia es París."],
    [/(cuantos planetas|planetas del sistema solar|nombra los planetas)/,"En el sistema solar hay ocho planetas: Mercurio, Venus, Tierra, Marte, Júpiter, Saturno, Urano y Neptuno."],
    [/(formula del agua|de que esta hecha el agua)/,"La fórmula química del agua es H₂O: cada molécula tiene dos átomos de hidrógeno y uno de oxígeno."],
    [/(que es un atomo|define atomo)/,"Un átomo es la unidad básica de un elemento químico. Está formado por un núcleo con protones y neutrones, rodeado por electrones."],
    [/(que es una celula|define celula)/,"La célula es la unidad estructural y funcional básica de los seres vivos. Algunos organismos tienen una sola célula y otros están formados por muchas."],
    [/(ayudame a estudiar|como estudio|tecnica de estudio)/,"Probá este método: 1) leé un tema corto; 2) cerrá el apunte y explicalo con tus palabras; 3) anotá lo que no recordaste; 4) repasalo después de un rato. Si me pasás el tema, puedo prepararte preguntas de práctica."],
    [/(resumime|hacer un resumen|como resumo)/,"¡Sí! Pegá el texto o mandame el contenido que querés resumir. Puedo convertirlo en un resumen breve, una lista de ideas principales o una versión para exponer."],
    [/(traduci|traduccion|como se dice .* en ingles)/,"Puedo ayudar con traducciones sencillas. Escribí la frase y decime a qué idioma querés pasarla."],
    [/(dame ideas|ideas para|no se que crear)/,"Tres ideas para empezar: 1) una app que organice tareas en pequeños pasos; 2) un juego de preguntas para aprender algo nuevo; 3) un diario de ideas con etiquetas y búsqueda. Si me decís qué te interesa, las adapto."],
    [/(que es programacion|como empezar a programar|aprender a programar)/,"Programar es escribir instrucciones para que una computadora realice tareas. Para empezar, podés aprender HTML y CSS para interfaces, y JavaScript para agregar interacción. Lo mejor es construir un proyecto pequeño y practicar una cosa por vez."],
    [/(que es el cambio climatico|calentamiento global)/,"El cambio climático es una modificación a largo plazo de las temperaturas y los patrones del clima. Actualmente, el calentamiento observado se debe principalmente a las emisiones humanas de gases de efecto invernadero."],
    [/(que es la democracia|define democracia)/,"La democracia es una forma de organización política en la que la ciudadanía participa en las decisiones públicas, directamente o mediante representantes elegidos, dentro de un marco de derechos y leyes."],
    [/(que hora es)/,"No tengo acceso confiable al reloj del dispositivo desde esta versión de prueba. Podés consultar la hora que muestra tu teléfono."],
    [/(estas conectada|tenes internet|tienes internet|podes buscar)/,"No. Esta beta responde sin conexión mediante una pequeña base de respuestas y reglas. Todavía no puede consultar Internet ni conectarse a servicios externos."],
    [/(por que no respondes|no entendes|respuesta incorrecta)/,"Todavía tengo una comprensión muy limitada: detecto palabras y temas frecuentes, no interpreto cualquier frase como lo haría un modelo de IA. Probá reformular la pregunta o decime el tema con más detalle."]
  ];
  for(const [pattern,response] of rules) if(pattern.test(q)) return response;

  if(q.includes("porque")||q.startsWith("por que ")) return "Buena pregunta. En esta beta todavía no puedo razonar sobre cualquier tema. Si me das un poco más de contexto, puedo intentar relacionarla con una de mis respuestas frecuentes.";
  if(q.startsWith("que es ")||q.startsWith("que significa ")) return "Puedo intentar explicarlo, pero ese concepto todavía no está en mi pequeña base de conocimientos. ¿En qué materia o contexto aparece? Así puedo orientarte mejor.";
  if(q.startsWith("como ")||q.startsWith("como hago ")) return "Puedo ayudarte a pensarlo paso a paso, aunque esta versión tiene conocimientos limitados. Contame qué querés lograr y qué intentaste hasta ahora.";
  return "Entiendo lo que me decís: “"+input+"”.\n\nTodavía no tengo un modelo de IA conectado. En esta beta puedo responder preguntas frecuentes, explicar algunos conceptos y resolver cuentas sencillas. Probá preguntarme “¿qué es la gravedad?”, “¿quién sos?” o “¿cuánto es 24 × 3?”.";
}
function send(text) {
  text=(text||"").trim();if(!text)return;
  if(!current())newChat();
  const chat=current();chat.archived=false;
  chat.messages.push({role:"user",text});
  if(chat.messages.length===1)chat.title=text.slice(0,30)+(text.length>30?"…":"");
  save();welcome.style.display="none";addBubble("user",text);
  promptEl.value="";promptEl.style.height="auto";
  const typing=document.createElement("div");typing.className="typing";typing.textContent="AIRA está pensando…";messagesEl.appendChild(typing);
  $("#sendBtn").disabled=true;
  setTimeout(()=>{
    typing.remove();
    const result=answer(text);
    // Basic markdown emphasis for the local demo, escaped before insertion.
    chat.messages.push({role:"assistant",text:result});save();addBubble("assistant",result);
    $("#sendBtn").disabled=false;
  },450);
}
function closeChatMenu(){
  const m=$("#chatActionMenu");if(m)m.remove();
  document.removeEventListener("pointerdown",outsideMenu,true);
  document.removeEventListener("keydown",menuKey);
}
function menuKey(e){if(e.key==="Escape")closeChatMenu();}
function outsideMenu(e){const m=$("#chatActionMenu");if(m&&!m.contains(e.target))closeChatMenu();}
function showChatMenu(chat,anchor){
  closeChatMenu();
  const menu=document.createElement("div");menu.id="chatActionMenu";menu.className="chat-action-menu";
  function addAction(label,icon,fn,danger=false){
    const b=document.createElement("button");b.type="button";b.className=danger?"danger":"";
    const ic=document.createElement("span");ic.className="action-icon";ic.textContent=icon;
    const tx=document.createElement("span");tx.textContent=label;b.append(ic,tx);
    b.addEventListener("click",e=>{e.stopPropagation();fn();});menu.appendChild(b);
  }
  addAction(chat.pinned?"Desanclar chat":"Anclar chat","◆",()=>{
    chat.pinned=!chat.pinned;save();closeChatMenu();
  });
  addAction(chat.archived?"Desarchivar chat":"Archivar chat","▤",()=>{
    chat.archived=!chat.archived;
    if(chat.archived&&currentId===chat.id){currentId=chats.find(c=>!c.archived&&c.id!==chat.id)?.id||null;renderChat();}
    save();closeChatMenu();
  });
  addAction("Borrar chat","⌫",()=>{
    menu.innerHTML="";
    const question=document.createElement("p");question.className="delete-question";question.textContent="¿Borrar este chat? No se puede deshacer.";menu.appendChild(question);
    const controls=document.createElement("div");controls.className="delete-controls";
    const cancel=document.createElement("button");cancel.type="button";cancel.textContent="Cancelar";cancel.onclick=closeChatMenu;
    const confirm=document.createElement("button");confirm.type="button";confirm.className="danger";confirm.textContent="Borrar";
    confirm.onclick=()=>{
      chats=chats.filter(c=>c.id!==chat.id);
      if(currentId===chat.id){currentId=chats.find(c=>!c.archived)?.id||null;renderChat();}
      save();closeChatMenu();
    };
    controls.append(cancel,confirm);menu.appendChild(controls);
    const r=anchor.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(r.left,innerWidth-202))+"px";menu.style.top=Math.max(8,Math.min(r.bottom+5,innerHeight-menu.offsetHeight-8))+"px";
  },true);
  document.body.appendChild(menu);
  const r=anchor.getBoundingClientRect();
  menu.style.left=Math.max(8,Math.min(r.left,innerWidth-202))+"px";
  menu.style.top=Math.max(8,Math.min(r.bottom+5,innerHeight-menu.offsetHeight-8))+"px";
  document.addEventListener("pointerdown",outsideMenu,true);
  document.addEventListener("keydown",menuKey);
}

$("#showAccount").addEventListener("click",()=>showEntryPanel("account"));
$("#showGuest").addEventListener("click",()=>showEntryPanel("guest"));
$("#backFromAccount").addEventListener("click",()=>showEntryPanel("choices"));
$("#backFromGuest").addEventListener("click",()=>showEntryPanel("choices"));
$("#guestForm").addEventListener("submit",event=>{
  event.preventDefault();
  enterAsGuest($("#guestUsername").value);
});
$("#accountForm").addEventListener("submit",event=>{
  event.preventDefault();
  const email=$("#accountEmail").value.trim();
  const password=$("#accountPassword").value;
  const username=$("#accountUsername").value;
  if(!email || !password || !cleanUsername(username)){
    alert("Completá el correo, la contraseña de prueba y el nombre de usuario.");
    return;
  }
  // This is intentionally a demo-only flow. Credentials are neither sent nor saved.
  $("#accountPassword").value="";
  alert("El inicio de sesión real todavía no está habilitado. Por seguridad, AIRA no guardó ni envió tu correo ni tu contraseña. Vas a entrar en modo invitado para probar la beta.");
  enterAsGuest(username);
});


function updateProfileUI(){
  const name=airaUser.name || "Invitado";
  $("#aboutBtn").textContent=name.slice(0,1).toUpperCase();
  $("#profileAvatar").textContent=name.slice(0,1).toUpperCase();
  $("#profileNameInput").value=airaUser.name;
  $("#profileMode").textContent="Cuenta de invitado · Este dispositivo";
}
function showAccountTab(tab){
  document.querySelectorAll(".account-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  document.querySelectorAll(".account-panel").forEach(p=>p.classList.remove("active"));
  const panel=$("#"+tab+"Panel");
  if(panel)panel.classList.add("active");
}
document.querySelectorAll(".account-tab").forEach(button=>{
  button.addEventListener("click",()=>showAccountTab(button.dataset.tab));
});
$("#aboutBtn").onclick=()=>{
  updateProfileUI();
  showAccountTab("profile");
  $("#aboutModal").classList.add("open");
  $("#overlay").classList.add("open");
};
$("#saveProfileName").addEventListener("click",()=>{
  const name=cleanUsername($("#profileNameInput").value);
  if(!name){alert("Escribí un nombre de usuario.");return;}
  airaUser.name=name;
  localStorage.setItem("aira_profile",JSON.stringify({name,mode:"guest"}));
  updateProfileUI();
  const heading=$("#welcomeHeading");
  if(heading && welcome.style.display!=="none")heading.innerHTML=`Hola, <em>${escapeHTML(name)}</em>.`;
  closeAccountModal();
});
function closeAccountModal(){
  $("#aboutModal").classList.remove("open");
  $("#overlay").classList.remove("open");
}
$("#logoutButton").addEventListener("click",()=>{
  closeAccountModal();
  localStorage.removeItem("aira_profile");
  airaUser.name="";
  $("#mainApp").hidden=true;
  showEntryPanel("choices");
  $("#entryScreen").classList.add("visible");
});
$("#voiceEnabled").checked=localStorage.getItem("aira_voice_enabled")!=="false";
$("#voiceRate").value=localStorage.getItem("aira_voice_rate")||"0.96";
$("#reduceMotion").checked=localStorage.getItem("aira_reduce_motion")==="true";
$("#voiceEnabled").addEventListener("change",e=>{
  localStorage.setItem("aira_voice_enabled",String(e.target.checked));
  if(!e.target.checked && "speechSynthesis" in window)window.speechSynthesis.cancel();
});
$("#voiceRate").addEventListener("change",e=>localStorage.setItem("aira_voice_rate",e.target.value));
$("#reduceMotion").addEventListener("change",e=>{
  localStorage.setItem("aira_reduce_motion",String(e.target.checked));
  document.documentElement.classList.toggle("reduce-motion",e.target.checked);
});
if($("#reduceMotion").checked)document.documentElement.classList.add("reduce-motion");
$("#clearHistoryButton").addEventListener("click",()=>{
  if(!confirm("¿Borrar todos los chats? Esta acción no se puede deshacer."))return;
  chats=[];currentId=null;localStorage.removeItem("aira_chats");renderHistory();renderChat();
  closeAccountModal();
});

$("#chatForm").addEventListener("submit",e=>{e.preventDefault();send(promptEl.value);});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,130)+"px";});
$("#newChat").onclick=newChat;
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>send(b.dataset.prompt));
function closeMenu(){$("#sidebar").classList.remove("open");$("#overlay").classList.remove("menu-open");}
$("#menuBtn").onclick=()=>{$("#sidebar").classList.add("open");$("#overlay").classList.add("menu-open");};
$("#overlay").onclick=()=>{closeMenu();$("#aboutModal").classList.remove("open");$("#overlay").classList.remove("open");closeChatMenu();};
$("#closeModal").onclick=()=>{$("#aboutModal").classList.remove("open");$("#overlay").classList.remove("open");};
if(chats.length){currentId=chats.find(c=>!c.archived)?.id||chats[0].id;renderHistory();renderChat();}else renderHistory();
showEntryPanel("choices");
updateProfileUI();
setTimeout(()=>$("#entryScreen").classList.add("visible"),2050);
