AIRA — PLÉYADES | BETA 0.9

NOVEDADES
- Se corrigió el paquete ZIP y se creó una ruta nueva de descarga.
- El botón circular del perfil abre un centro con tres secciones: Perfil, Ajustes y Acerca de.
- Perfil: ver y cambiar el nombre de usuario, y cerrar sesión del perfil local.
- Ajustes: activar/desactivar los botones de voz, elegir velocidad de voz, reducir animaciones y borrar todos los chats.
- El nombre se guarda localmente y AIRA lo usa en el saludo.
- El historial y las preferencias se guardan en este dispositivo.

IMPORTANTE
- Esta beta sigue funcionando como prototipo local.
- El acceso por correo y contraseña todavía no está conectado a un servidor. No introduzcas contraseñas reales.
- No hay sincronización en la nube ni cuentas reales.
- La voz utiliza las voces disponibles en el navegador/Android.

CÓMO PROBAR
1. Descargá y extraé AIRA_Beta_0.9.zip.
2. Abrí index.html en Chrome.
3. Entrá como invitado y elegí tu nombre.
4. Tocá el círculo con tu inicial, arriba a la derecha.
5. Probá Perfil, Ajustes y Acerca de.
