AIRA — PLÉYADES | BETA 0.6

Esta beta incluye una interfaz de chat local y una animación de entrada con el símbolo de AIRA.

NOVEDADES
- La presentación inicial muestra solamente la animación de la estrella.
- El historial permite anclar, archivar/desarchivar y borrar chats.
- Borrar muestra una confirmación propia dentro de la aplicación.
- Respuestas locales de prueba para saludos, identidad de AIRA, preguntas frecuentes, conceptos escolares, consejos de estudio y operaciones matemáticas sencillas.

IMPORTANTE
AIRA todavía NO está conectada a un modelo de IA. Las respuestas provienen de reglas y respuestas predefinidas en el dispositivo. No tiene razonamiento general, acceso a Internet ni información actualizada. No introduzcas datos privados.

CÓMO PROBAR EN ANDROID
1. Extrae el ZIP en una carpeta nueva.
2. Abre index.html con Chrome o tu navegador.
3. Prueba: “¿Quién sos?”, “¿Qué es la gravedad?”, “¿Cuántos planetas hay?” y “¿Cuánto es 24 x 3?”.
4. Para administrar un chat, mantén presionado su nombre en el historial.

El historial se guarda localmente en el navegador del dispositivo.

BETA 0.7 — ANIMACIÓN Y VOZ
- Se quitó la imagen estática que aparecía antes de la animación. La presentación comienza directamente con las piezas animadas y termina en el logo original.
- Las respuestas de AIRA ahora muestran un botón de altavoz. Al tocarlo, el navegador/Android lee la respuesta con una voz española de tono algo más agudo y prioriza una voz femenina si el dispositivo ofrece una.
- La voz depende de las voces instaladas en Android y del navegador; puede variar entre teléfonos. No es todavía una voz propia generada por AIRA ni una conexión a un servicio de voz.
