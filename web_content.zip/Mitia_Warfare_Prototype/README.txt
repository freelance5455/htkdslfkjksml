MITIA WARFARE — prototype 0.1

Ity dia prototype 3D voalohany mandeha amin'ny navigateur, fa tsy APK ary tsy mbola multiplayer.

Fampiasana:
1. Esory (extract) ny ZIP.
2. Sokafy index.html amin'ny navigateur manana Internet.
3. Mila Internet ilay Three.js CDN rehefa mampiditra ny 3D library.
4. Ahodino mitsivalana ny finday. Ny orientation lock dia mety tsy eken'ny navigateur; raha izany dia ahodino tanana.
5. Raha tsy mandeha ny fanokafana file:// amin'ny navigateur sasany, dia mila ampiasaina ny web hosting na local server.

Efa ao:
- tontolo 3D tsotra
- fijery olona voalohany
- joystick finday, swipe hijerena
- safidy bots 1/5/10/15/20 (bots demo)
- safidy fahasarotana (AI mbola tsotra)
- safidy fitaovam-piadiana (fisehoana demo)
- fanomezana 10 points rehefa mamono bot
- anarana azo omena ny mpilalao sy ny bots, miseho ambonin'ny bots
- bots afaka manenjika sy manao fanafihana tsotra amin'ny mpilalao
- lisitry ny maty sy ny namono azy (kill feed)
- bokotra FIRE sy JUMP

Tsy mbola ao:
- tena online multiplayer / LAN
- server sy room system
- AI bots feno sy collision/physics matotra
- APK Android
- sarintany sy fitaovam-piadiana maro tena vita

Dingana manaraka: manangana server multiplayer (ohatra WebSocket) ary avy eo manomana packaging Android. Aza lazaina ho lalao vita na online izy ity.
