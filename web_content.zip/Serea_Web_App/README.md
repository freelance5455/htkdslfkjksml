# Séréa — version web à empaqueter en APK

Cette version est une application web autonome conçue pour être empaquetée dans un APK avec un outil compatible HTML/ZIP-to-APK.

## Fonctions
- Calendrier mensuel
- Souvenir par date : titre, message, photo
- Thème clair/sombre mémorisé
- Enregistrement local dans le navigateur/WebView
- Demande de permission de notification et vérification des rappels quand l'application est ouverte

## Limites importantes
- Les rappels ne sont pas garantis lorsque l'application est fermée ou en arrière-plan.
- Les données sont stockées localement et peuvent être effacées par la désinstallation, l'effacement des données ou certains changements de WebView.
- Cette version est une alternative pratique pour créer une application installable sans PC; elle n'est pas une compilation du projet Kotlin natif.
- Teste soigneusement l'outil de conversion et ne désactive pas Play Protect pour installer un APK si tu n'es pas sûr de sa provenance.

## Procédure conseillée depuis Android
1. Télécharge `Serea_Web_App.zip`.
2. Ouvre le site officiel APK Maker : https://www.apkmaker.dev/
3. Choisis l'outil de conversion **HTML & ZIP to APK Builder** (et non le convertisseur natif Kotlin).
4. Téléverse le ZIP, nomme l'application `Séréa` et choisis un identifiant de paquet si demandé, par exemple `com.serea.romance.web`.
5. Génère l'APK puis télécharge-le.
6. Android peut demander d'autoriser l'installation depuis le navigateur ou le gestionnaire de fichiers. N'autorise que le fichier que tu viens de générer depuis le service choisi.
7. Après installation, ouvre Séréa et teste la sauvegarde d'un souvenir.

Si l'outil ou le site a changé, suis ses instructions officielles et vérifie les frais/limites affichés avant de confirmer.
