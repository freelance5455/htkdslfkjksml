VIJETHA ACADEMY — MULTI-DEVICE ANDROID SETUP PACK
=================================================

IMPORTANT CURRENT STATUS
------------------------
This ZIP contains the existing Vijayatha Academy web prototype plus a secure-minded Supabase database schema and setup instructions. The current index.html still uses browser-local storage for its existing forms/admin demo. Shared multi-device data will NOT work until the Supabase project is created and the app's data handlers are connected to it. This pack does not claim that backend is already live.

A. CREATE THE FREE SUPABASE BACKEND
-----------------------------------
1. In a browser, create a Supabase account and a new project at https://supabase.com.
2. Choose a project name such as vijetha-academy. Save the database password privately; do not send it in chat.
3. Open SQL Editor in the Supabase dashboard.
4. Open supabase/schema.sql from this ZIP, copy all SQL, paste it in SQL Editor, and run it.
5. Open Project Settings > API. Copy the Project URL and the publishable/anon key (safe for client-side use when RLS is configured).
6. Do NOT use or share the service_role/secret key in the app.
7. Create the first admin in Authentication > Users (invite/create user with email and password).
8. Copy that user's UUID. In SQL Editor run this, replacing the UUID:
   insert into public.admin_profiles(user_id, display_name)
   values ('PASTE-ADMIN-USER-UUID-HERE', 'Academy Admin');
   Only add trusted admin accounts to admin_profiles. This table controls admin permissions.
9. In Storage, create a public bucket named academy-media. Then run the four Storage policy statements commented at the bottom of schema.sql (uncomment/copy them into SQL Editor). Public read is for academy media; only authenticated admins should upload/delete.

B. NON-SECRET CONFIGURATION NEEDED FOR INTEGRATION
--------------------------------------------------
- Supabase Project URL
- Supabase publishable/anon key
- Admin sign-in email (not password)
- App/package name preference (suggested: com.vijetha.academy)
- Whether you have a Firebase project for Android push notifications (yes/no)

Do not send: account passwords, Supabase service_role key, Firebase service account JSON/private key, or payment credentials.

C. FREE HOSTING (SOURCE WEBSITE USED BY ANDROID WEBVIEW)
--------------------------------------------------------
The website needs to be hosted on HTTPS before it can reliably use browser APIs and push services. Common free static hosting choices include GitHub Pages, Cloudflare Pages, or Netlify. Upload the contents of the vijetha_academy_app folder (index.html and assets folder) as the site files. Then test the HTTPS URL on a phone.

D. ANDROID APP
--------------
For Android-only delivery, wrap the hosted HTTPS site in an Android WebView or Capacitor app. The package/application ID can be com.vijetha.academy. Build/signing an APK/AAB requires an Android build environment (Android Studio/Gradle or a compatible cloud builder). The ZIP itself is source code, not an already signed APK.

E. PUSH NOTIFICATIONS
---------------------
For real push notifications when the app is closed, use Firebase Cloud Messaging (FCM) for Android plus a trusted server/Edge Function. The app must request notification permission once, register an FCM token, and save it to push_subscriptions. Admin publishing news or toppers should call a server-side Edge Function that sends FCM notifications. Never put Firebase service account credentials in HTML or the APK. The Supabase Edge Function folder is a placeholder for this secure server-side step; push is not active until Firebase/FCM is configured.

F. FEATURES TO CONNECT TO THE SHARED DATABASE
---------------------------------------------
- admissions: public insert; admin-only read/update
- news, toppers, books, photos: public read; admin-only management
- feature_requests and feature_votes: shared requests/votes
- academy-media Storage bucket: shared logo/poster images
- push_subscriptions: notification device tokens

G. DEMO PASSWORD WARNING
------------------------
The current prototype has a demo password in client-side JavaScript. That is NOT secure for production. Replace it with Supabase Auth before distributing a public build. Never rely on a password embedded in HTML/JavaScript to protect the admin panel.
