// Copy this to config.js and fill in values from Supabase Dashboard > Project Settings > API.
// The anon/publishable key is intended for browser/mobile clients. NEVER put a service_role key here.
window.VIJETHA_SUPABASE_CONFIG = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  anonKey: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY'
};
