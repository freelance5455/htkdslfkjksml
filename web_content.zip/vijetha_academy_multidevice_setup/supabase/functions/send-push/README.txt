FCM PUSH FUNCTION PLACEHOLDER
=============================
A production Edge Function should accept an authenticated admin action, validate that the caller is an academy admin, fetch FCM tokens server-side, and send notifications using Firebase Admin credentials stored as Supabase secrets. Do not place service-account JSON, FCM server credentials, or Supabase service-role keys in client-side files. Push delivery is not active in this starter until the function is implemented and configured.
