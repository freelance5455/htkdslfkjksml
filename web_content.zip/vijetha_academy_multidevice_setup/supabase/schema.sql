-- Vijayatha Academy Supabase schema
-- Run in Supabase Dashboard > SQL Editor after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.admin_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Academy Admin',
  created_at timestamptz not null default now()
);

create or replace function public.is_academy_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.admin_profiles a where a.user_id = auth.uid()); $$;
revoke all on function public.is_academy_admin() from public;
grant execute on function public.is_academy_admin() to anon, authenticated;

create table if not exists public.admissions (
  id uuid primary key default gen_random_uuid(),
  student_name text not null,
  father_name text,
  phone text not null,
  class_name text not null,
  seen boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.news (
  id uuid primary key default gen_random_uuid(), title text not null, body text not null,
  created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table if not exists public.toppers (
  id uuid primary key default gen_random_uuid(), name text not null, exam text not null,
  marks text not null, created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table if not exists public.books (
  id uuid primary key default gen_random_uuid(), title text not null, price numeric(10,2) not null check (price >= 0),
  seller text not null, link text not null, description text, created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(), image_url text not null, alt_text text not null default '',
  sort_order integer not null default 0, created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table if not exists public.feature_requests (
  id uuid primary key default gen_random_uuid(), title text not null, details text,
  status text not null default 'pending' check (status in ('pending','reviewed','planned','done')),
  admin_response text, created_at timestamptz not null default now(), created_by uuid references auth.users(id)
);
create table if not exists public.feature_votes (
  id uuid primary key default gen_random_uuid(), request_id uuid not null references public.feature_requests(id) on delete cascade,
  voter_key text not null, created_at timestamptz not null default now(), unique(request_id, voter_key)
);
create table if not exists public.push_subscriptions (
  id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade,
  token text not null unique, platform text not null default 'android', created_at timestamptz not null default now()
);

alter table public.admin_profiles enable row level security;
alter table public.admissions enable row level security;
alter table public.news enable row level security;
alter table public.toppers enable row level security;
alter table public.books enable row level security;
alter table public.photos enable row level security;
alter table public.feature_requests enable row level security;
alter table public.feature_votes enable row level security;
alter table public.push_subscriptions enable row level security;

-- Admin profiles are private; admins can see their own profile.
create policy "admins read own profile" on public.admin_profiles for select to authenticated using (user_id = auth.uid());
-- Admission PII can be submitted publicly but is only readable/manageable by admins.
create policy "public submit admission" on public.admissions for insert to anon, authenticated with check (true);
create policy "admins manage admissions" on public.admissions for all to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
-- Public content is readable by everyone; only admins can change it.
create policy "public read news" on public.news for select to anon, authenticated using (true);
create policy "admins manage news" on public.news for all to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
create policy "public read toppers" on public.toppers for select to anon, authenticated using (true);
create policy "admins manage toppers" on public.toppers for all to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
create policy "public read books" on public.books for select to anon, authenticated using (true);
create policy "admins manage books" on public.books for all to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
create policy "public read photos" on public.photos for select to anon, authenticated using (true);
create policy "admins manage photos" on public.photos for all to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
create policy "public read feature requests" on public.feature_requests for select to anon, authenticated using (true);
create policy "public submit feature request" on public.feature_requests for insert to anon, authenticated with check (true);
create policy "admins manage feature requests" on public.feature_requests for update, delete to authenticated using (public.is_academy_admin()) with check (public.is_academy_admin());
create policy "public read votes" on public.feature_votes for select to anon, authenticated using (true);
create policy "public vote on requests" on public.feature_votes for insert to anon, authenticated with check (true);
create policy "admins read subscriptions" on public.push_subscriptions for select to authenticated using (public.is_academy_admin());
create policy "users register own push token" on public.push_subscriptions for insert to authenticated with check (user_id = auth.uid());
create policy "users update own push token" on public.push_subscriptions for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Storage: create a PUBLIC bucket named academy-media in Dashboard > Storage.
-- Public read is fine for academy posters/logos. Restrict upload/delete to authenticated admins.
-- Add these policies after creating the bucket:
-- insert into storage.buckets (id, name, public) values ('academy-media','academy-media',true) on conflict (id) do nothing;
-- create policy "public view academy media" on storage.objects for select to anon, authenticated using (bucket_id = 'academy-media');
-- create policy "admins upload academy media" on storage.objects for insert to authenticated with check (bucket_id = 'academy-media' and public.is_academy_admin());
-- create policy "admins update academy media" on storage.objects for update to authenticated using (bucket_id = 'academy-media' and public.is_academy_admin()) with check (bucket_id = 'academy-media' and public.is_academy_admin());
-- create policy "admins delete academy media" on storage.objects for delete to authenticated using (bucket_id = 'academy-media' and public.is_academy_admin());
