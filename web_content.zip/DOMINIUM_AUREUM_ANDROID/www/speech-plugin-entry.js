import { SpeechRecognition } from '@capacitor-community/speech-recognition';

// Bridge used by the inline app script. The native plugin handles Android microphone permission.
window.DOMINIUM_SpeechRecognition = SpeechRecognition;
