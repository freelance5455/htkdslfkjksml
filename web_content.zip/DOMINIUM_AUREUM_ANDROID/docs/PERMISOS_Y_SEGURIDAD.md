# Permisos y Seguridad — DOMINIUM AUREUM

## Permisos solicitados (mínimos)

| Permiso | Uso | Cuándo se solicita |
|---------|-----|--------------------|
| `RECORD_AUDIO` | Dictado de voz para crear clientes nuevos | Solo al pulsar el botón de dictado dentro de NUEVO |
| `READ_CONTACTS` (o Contacts Picker) | Selector nativo de un solo contacto | Solo al pulsar "Seleccionar contacto" |
| `POST_NOTIFICATIONS` | Recordatorios locales | Solo si el usuario activa notificaciones |
| `INTERNET` / `ACCESS_NETWORK_STATE` | Supabase | Automático |

**No se solicitan**: CALL_PHONE, SEND_SMS, ACCESS_FINE_LOCATION, READ_EXTERNAL_STORAGE completo, WRITE_CALENDAR (se usa Intent).

## Medidas de seguridad implementadas
- Contraseña local hasheada con SHA-256 (sin default inseguro `123456`).
- Clave `service_role` de Supabase **nunca** incluida en el cliente.
- Solo se usa la clave pública (`sb_publishable_...`) con RLS activado.
- Datos locales en `localStorage` (o Preferences de Capacitor en producción).
- Validación de entradas en el formulario.
- HTTPS obligatorio para Supabase.
- Solicitud contextual de permisos + manejo de denegación.
- El reconocimiento de voz no se habilita al editar clientes ni en otras pantallas.
- Protección contra XSS básica (textos escapados en renderizado).

## Política de privacidad (resumen)
La aplicación almacena localmente y sincroniza (con Supabase) datos de clientes (nombre, teléfono opcional, montos, litros, observaciones y recordatorios). No se venden datos. El micrófono solo se usa cuando el usuario inicia el dictado dentro del registro de un cliente nuevo. El selector de contactos solo lee el contacto elegido.

## Google Play
- Target SDK ≥ 34/35 (actualizar según fecha de publicación).
- Declarar uso de permisos en el Play Console.
- Proporcionar política de privacidad completa en la ficha de la app.
- No se afirma certificación automática; el usuario debe completar el proceso de revisión.
