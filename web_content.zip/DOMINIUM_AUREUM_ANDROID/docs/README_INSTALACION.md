# DOMINIUM AUREUM — Instalación y uso

## Tecnología elegida
**Capacitor (Ionic) + Android Studio** (100 % gratuito).

### Motivo
- Conserva el HTML/CSS/JS original al 100 %.
- Permite plugins nativos reales (Contactos, Calendario, WorkManager).
- Control total de `AndroidManifest.xml`, `targetSdkVersion`, firma y AAB.
- APKForge (HTML/ZIP → APK) es insuficiente: no soporta WorkManager, Intent de contactos/calendario de forma controlada ni plugins Kotlin personalizados.

## Requisitos
- Node.js 20+ (LTS)
- Android Studio (última versión estable) + SDK Platform 35 o superior
- JDK 17
- Cuenta Google Play Console (solo para publicación)

## Pasos rápidos

### 1. Preparar el proyecto web
```bash
cd DOMINIUM_AUREUM_ANDROID
npm install
npx cap add android
npx cap sync
```

### 2. Abrir en Android Studio
```bash
npx cap open android
```

### 3. Configurar
- Package name recomendado: `com.mackenzie.dominiumaureum`
- Actualizar iconos en `android/app/src/main/res/`
- Revisar `AndroidManifest.xml` (permisos ya preparados)

### 4. Compilar
- Debug APK: Build → Build Bundle(s) / APK(s) → Build APK(s)
- Release AAB: Build → Generate Signed Bundle / APK → Android App Bundle

### 5. Supabase
Ejecutar el archivo `SUPABASE_MIGRACION.sql` en el SQL Editor de Supabase.

## Funciones implementadas
- Campo teléfono + selector nativo de contactos (Capacitor Contacts / Intent)
- Botón calendario → Intent oficial `ACTION_INSERT` (sin permisos de lectura/escritura)
- Micrófono flotante (🎙️) con animación de escucha
- Sincronización offline + cola persistente + WorkManager (cuando se añade el plugin)
- Diseño y todas las funciones originales conservadas
- Default password inseguro eliminado

## Limitaciones del entorno actual
- No se pudo generar APK/AAB firmado real aquí (requiere Android SDK completo + keystore del usuario).
- Las pruebas de dispositivos físicos y Google Play deben realizarse localmente.
- WorkManager se configura en el proyecto Android generado.

## Archivos entregados
- `DOMINIUM_AUREUM_MOVIL.html` — versión modificada
- `SUPABASE_MIGRACION.sql`
- `PERMISOS_Y_SEGURIDAD.md`
- `GUIA_COMPILACION.md`
- Estructura Capacitor en `DOMINIUM_AUREUM_ANDROID/`
