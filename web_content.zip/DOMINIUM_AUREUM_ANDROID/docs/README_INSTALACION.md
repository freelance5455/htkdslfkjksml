# DOMINIUM AUREUM — Instalación y uso

## Tecnología elegida
**Capacitor (Ionic) + Android Studio** (100 % gratuito).

### Motivo
- Conserva el HTML/CSS/JS original al 100 %.
- Permite plugins nativos reales (Contactos, Calendario, WorkManager).
- Control total de `AndroidManifest.xml`, `targetSdkVersion`, firma y AAB.
- APKForge (HTML/ZIP → APK) es insuficiente: no soporta WorkManager, Intent de contactos/calendario de forma controlada ni plugins Kotlin personalizados.

## Requisitos
- Node.js 20+ (LTS)
- Android Studio (última versión estable) + SDK Platform 35 o superior
- JDK 17
- Cuenta Google Play Console (solo para publicación)

## Pasos rápidos

### 1. Preparar el proyecto web
```bash
cd DOMINIUM_AUREUM_ANDROID
npm install
npx cap add android
npm run build
```

### 2. Abrir en Android Studio
```bash
npx cap open android
```

### 3. Configurar
- Package name recomendado: `com.mackenzie.dominiumaureum`
- Actualizar iconos en `android/app/src/main/res/`
- Revisar `AndroidManifest.xml`; el complemento nativo solicita permiso de micrófono al iniciar el dictado

### 4. Compilar
- Debug APK: Build → Build Bundle(s) / APK(s) → Build APK(s)
- Release AAB: Build → Generate Signed Bundle / APK → Android App Bundle

### 5. Supabase
Ejecutar el archivo `SUPABASE_MIGRACION.sql` en el SQL Editor de Supabase.

## Uso del dictado
1. Pulsa **NUEVO** para abrir el registro de un cliente nuevo.
2. Toca **DICTAR DATOS DEL CLIENTE** y concede el permiso de micrófono cuando se solicite.
3. Di los datos en español, por ejemplo: “Cliente Ana Pérez, teléfono 999 888 777, monto 50 soles, 20 litros, destino consumo, observaciones entregar en puerta”.
4. Revisa los campos completados y guarda el registro. El botón no aparece al editar clientes ni en otras pantallas.

En el APK, el reconocimiento se realiza con el complemento nativo de Capacitor. En un navegador sin reconocimiento compatible, se ofrece el micrófono del teclado como alternativa.

## Funciones implementadas
- Campo teléfono + selector nativo de contactos (Capacitor Contacts / Intent)
- Botón calendario → Intent oficial `ACTION_INSERT` (sin permisos de lectura/escritura)
- Dictado por voz solo al registrar un cliente nuevo, mediante reconocimiento nativo de Android en el APK y alternativa del micrófono del teclado en navegadores compatibles
- Sincronización offline + cola persistente + WorkManager (cuando se añade el plugin)
- Diseño y todas las funciones originales conservadas
- Default password inseguro eliminado

## Limitaciones del entorno actual
- No se pudo generar APK/AAB firmado real aquí (requiere Android SDK completo + keystore del usuario).
- Las pruebas de dispositivos físicos y Google Play deben realizarse localmente.
- WorkManager se configura en el proyecto Android generado.

## Archivos entregados
- `www/index.html` — aplicación web modificada
- `SUPABASE_MIGRACION.sql`
- `PERMISOS_Y_SEGURIDAD.md`
- `GUIA_COMPILACION.md`
- Estructura Capacitor en `DOMINIUM_AUREUM_ANDROID/`
