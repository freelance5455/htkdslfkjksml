# Guía de compilación — DOMINIUM AUREUM (Capacitor)

## 1. Entorno
- Windows / macOS / Linux
- Node.js 20 LTS
- Android Studio Ladybug o posterior
- Android SDK 35+, Build-Tools 35, Platform-Tools
- JDK 17

## 2. Inicializar proyecto Capacitor
```bash
mkdir dominium-aureum && cd dominium-aureum
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npm install @capacitor/contacts @capacitor/preferences @capacitor/network
# Opcional WorkManager / background
npm install @capawesome/capacitor-background-task   # o plugin WorkManager community

npx cap init "DOMINIUM AUREUM" "com.mackenzie.dominiumaureum"
# Copiar DOMINIUM_AUREUM_MOVIL.html como www/index.html
npx cap add android
npx cap sync
```

## 3. Configuración Android
Editar `android/app/build.gradle`:
```gradle
android {
    compileSdk 35
    defaultConfig {
        minSdk 26
        targetSdk 35
        versionCode 1
        versionName "1.0.0"
    }
}
```

`AndroidManifest.xml` (añadir solo lo necesario):
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<!-- Contacts: preferir ContactsContract.Contacts.CONTENT_URI picker -->
```

## 4. Compilar APK de prueba
```bash
npx cap open android
# En Android Studio: Run o Build → Build APK(s)
```

## 5. AAB firmado para Google Play
1. Generar keystore (una sola vez):
```bash
keytool -genkey -v -keystore dominium-release.keystore -alias dominium -keyalg RSA -keysize 2048 -validity 10000
```
2. Configurar `android/key.properties` y firmar en Android Studio (Generate Signed Bundle).

## 6. WorkManager (sincronización en segundo plano)
Implementar un Worker en Kotlin que lea la cola local (Preferences o SQLite) y ejecute la lógica de `syncNow` cuando haya red. Registrar con restricciones `NetworkType.CONNECTED`. No usar servicio permanente.

## 7. Verificación
- Probar offline → online
- Selector de contactos
- Intent de calendario
- Micrófono flotante
- Recordatorios
- Persistencia tras reinicio
