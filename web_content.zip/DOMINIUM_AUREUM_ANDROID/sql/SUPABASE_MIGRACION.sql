-- ============================================================
-- DOMINIUM AUREUM — Migración segura Supabase
-- Fecha: 2026-11-24
-- Añade columna telefono a la tabla registros
-- Compatible con registros existentes (nullable)
-- No elimina ni reemplaza tablas ni políticas RLS
-- ============================================================

-- 1. Añadir columna telefono (nullable para no romper registros antiguos)
ALTER TABLE public.registros
  ADD COLUMN IF NOT EXISTS telefono text;

-- 2. Comentario de documentación
COMMENT ON COLUMN public.registros.telefono IS 'Número telefónico del cliente (opcional). Formato libre o E.164.';

-- 3. Índice opcional para búsquedas por teléfono (no obligatorio)
CREATE INDEX IF NOT EXISTS idx_registros_telefono
  ON public.registros (telefono)
  WHERE telefono IS NOT NULL AND deleted_at IS NULL;

-- 4. Verificar (ejecutar manualmente si se desea)
-- SELECT column_name, data_type, is_nullable
-- FROM information_schema.columns
-- WHERE table_schema = 'public' AND table_name = 'registros'
-- ORDER BY ordinal_position;

-- IMPORTANTE:
-- - Las políticas RLS existentes se mantienen intactas.
-- - El cliente JS ya actualiza SELECT / upsert con la nueva columna.
-- - No se requiere cambio de generation ni limpieza de datos.
