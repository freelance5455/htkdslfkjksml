(() => {
  "use strict";
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
  const SESSION_SIZE = 20;

  const $ = (id) => document.getElementById(id);
  const setupPanel = $("setupPanel");
  const gamePanel = $("gamePanel");
  const resultsPanel = $("resultsPanel");
  const levelSelect = $("levelSelect");
  const currentLetter = $("currentLetter");
  const progressFill = $("progressFill");
  const progressTrack = $("progressTrack");
  const attemptLabel = $("attemptLabel");
  const remainingLabel = $("remainingLabel");
  const encouragement = $("encouragement");

  let deck = [];
  let answers = [];
  let index = 0;
  let selectedLevel = "Z";
  let sessionActive = false;

  alphabet.forEach((letter) => {
    const option = document.createElement("option");
    option.value = letter;
    option.textContent = letter;
    levelSelect.appendChild(option);
  });
  levelSelect.value = "Z";

  function shuffle(items) {
    const result = [...items];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  function startSession() {
    selectedLevel = levelSelect.value;
    const availableLetters = alphabet.slice(0, alphabet.indexOf(selectedLevel) + 1);
    // Repeat the available range when it contains fewer than 20 letters,
    // so every session always has exactly 20 attempts.
    const pool = [];
    while (pool.length < SESSION_SIZE) pool.push(...availableLetters);
    deck = shuffle(pool).slice(0, SESSION_SIZE);
    answers = [];
    index = 0;
    sessionActive = true;
    setupPanel.classList.add("hidden");
    resultsPanel.classList.add("hidden");
    gamePanel.classList.remove("hidden");
    showCurrentCard();
  }

  function showCurrentCard() {
    if (index >= deck.length) return showResults();
    currentLetter.textContent = deck[index];
    attemptLabel.textContent = `المحاولة ${index + 1} من ${SESSION_SIZE}`;
    remainingLabel.textContent = `بقيت ${SESSION_SIZE - index} محاولة`;
    const progress = (index / SESSION_SIZE) * 100;
    progressFill.style.width = `${progress}%`;
    progressTrack.setAttribute("aria-valuenow", String(index));
    encouragement.textContent = index === 0
      ? "خذ وقتك، ثم اختر إجابتك."
      : "أنت تقوم بعمل رائع، واصل المحاولة!";
    $("knowButton").disabled = false;
    $("dontKnowButton").disabled = false;
  }

  function recordAnswer(known) {
    if (!sessionActive || index >= deck.length) return;
    answers.push({ letter: deck[index], known, number: index + 1 });
    index += 1;
    if (index >= SESSION_SIZE) {
      progressFill.style.width = "100%";
      progressTrack.setAttribute("aria-valuenow", "20");
      attemptLabel.textContent = `اكتملت ${SESSION_SIZE} محاولة`;
      remainingLabel.textContent = "أحسنت!";
      window.setTimeout(showResults, 180);
    } else {
      showCurrentCard();
    }
  }

  function addResultTile(container, answer, known) {
    const tile = document.createElement("div");
    tile.className = `result-tile ${known ? "known" : "covered"}`;
    tile.setAttribute("title", known ? `الحرف ${answer.letter} — عرفته` : "حرف لم تتمكن من معرفته");
    if (known) {
      tile.textContent = answer.letter;
      tile.setAttribute("aria-label", `الحرف ${answer.letter}`);
    } else {
      // Deliberately do not place the missed letter in the DOM or reveal it.
      tile.textContent = "؟";
      tile.classList.add("covered");
      tile.setAttribute("aria-label", "بطاقة مغطاة");
    }
    container.appendChild(tile);
  }

  function showResults() {
    sessionActive = false;
    gamePanel.classList.add("hidden");
    setupPanel.classList.add("hidden");
    resultsPanel.classList.remove("hidden");

    const known = answers.filter((answer) => answer.known);
    const unknown = answers.filter((answer) => !answer.known);
    const percent = Math.round((known.length / SESSION_SIZE) * 100);

    $("knownCount").textContent = known.length;
    $("unknownCount").textContent = unknown.length;
    $("scorePercent").textContent = `${percent}%`;
    $("knownSectionCount").textContent = known.length;
    $("unknownSectionCount").textContent = unknown.length;
    $("resultTitle").textContent = percent === 100 ? "ممتاز! لقد عرفت كل الحروف!" :
      percent >= 70 ? "عمل رائع، أنت تتقدّم!" :
      percent >= 40 ? "بداية جميلة، واصل التدريب!" : "كل محاولة تعلّم جديد!";
    $("resultSubtitle").textContent = `عرفت ${known.length} من أصل ${SESSION_SIZE} محاولة.`;
    $("resultBadge").textContent = percent >= 70 ? "★" : "✦";

    const knownCards = $("knownCards");
    const unknownCards = $("unknownCards");
    knownCards.replaceChildren();
    unknownCards.replaceChildren();
    known.forEach((answer) => addResultTile(knownCards, answer, true));
    unknown.forEach((answer) => addResultTile(unknownCards, answer, false));

    if (known.length === 0) knownCards.innerHTML = '<p class="muted small">لا توجد بطاقات في هذه المجموعة بعد. جرّب من جديد!</p>';
    if (unknown.length === 0) unknownCards.innerHTML = '<p class="muted small">رائع! لم تبقَ بطاقات تحتاج إلى مراجعة.</p>';
    resultsPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function returnToSetup() {
    sessionActive = false;
    gamePanel.classList.add("hidden");
    resultsPanel.classList.add("hidden");
    setupPanel.classList.remove("hidden");
    setupPanel.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  $("startButton").addEventListener("click", startSession);
  $("knowButton").addEventListener("click", () => recordAnswer(true));
  $("dontKnowButton").addEventListener("click", () => recordAnswer(false));
  $("newSessionButton").addEventListener("click", startSession);
  $("changeLevelButton").addEventListener("click", returnToSetup);
  $("restartTop").addEventListener("click", () => {
    if (sessionActive && !window.confirm("هل تريد إنهاء الجلسة الحالية والبدء من جديد؟")) return;
    returnToSetup();
  });
  $("quitButton").addEventListener("click", () => {
    if (!sessionActive) return;
    if (window.confirm("هل تريد عرض النتيجة الآن؟ ستُحتسب المحاولات التي أجبت عنها فقط.")) {
      deck = deck.slice(0, index);
      showResults();
    }
  });
})();