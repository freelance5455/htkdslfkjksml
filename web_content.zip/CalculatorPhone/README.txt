Calculator phone version

Open index.html on your phone browser. It works offline after the files are on the phone.
For an app-like icon, open it from a hosted HTTPS page and choose Add to Home Screen.
