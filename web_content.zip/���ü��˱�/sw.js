const CACHE_NAME = "book-v1";
const FILES = ["./", "./index.html", "./app.js", "./manifest.json"];

self.addEventListener("install", function(event){
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache){
      return cache.addAll(FILES);
    }).then(function(){
      self.skipWaiting();
    })
  );
});

self.addEventListener("activate", function(event){
  event.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", function(event){
  event.respondWith(
    caches.match(event.request).then(function(res){
      return res || fetch(event.request);
    })
  );
});
