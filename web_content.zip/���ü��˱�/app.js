// 初始化数据库
let db = new Dexie("AccountBookDB");
db.version(1).stores({
  books: "id",
  categories: "id, type",
  accounts: "id",
  records: "id, bookId, type, time, categoryId, accountId"
});

// 全局变量
let currentOperate = ""; // book / cat / acc
let editRecordId = null;

// 初始化默认数据（首次打开自动创建）
async function initDefaultData(){
  let bookCount = await db.books.count();
  if(bookCount === 0){
    await db.books.add({id:crypto.randomUUID(), name:"日常账本"});
  }
  let catCount = await db.categories.count();
  if(catCount === 0){
    await db.categories.bulkAdd([
      {id:crypto.randomUUID(), name:"餐饮", type:"expense"},
      {id:crypto.randomUUID(), name:"交通", type:"expense"},
      {id:crypto.randomUUID(), name:"工资", type:"income"},
      {id:crypto.randomUUID(), name:"红包", type:"income"}
    ]);
  }
  let accCount = await db.accounts.count();
  if(accCount === 0){
    await db.accounts.bulkAdd([
      {id:crypto.randomUUID(), name:"现金"},
      {id:crypto.randomUUID(), name:"微信"},
      {id:crypto.randomUUID(), name:"支付宝"}
    ]);
  }
}

// 渲染全部下拉选项
async function renderAllSelect(){
  await renderBookSelect();
  await renderCategorySelect();
  await renderAccountSelect();
  await renderFilterSelect();
}

// 渲染账本下拉
async function renderBookSelect(){
  let list = await db.books.toArray();
  let sel = document.getElementById("bookSel");
  let filterSel = document.getElementById("filterBook");
  sel.innerHTML = "";
  filterSel.innerHTML = "<option value=''>全部账本</option>";
  for(let i=0;i<list.length;i++){
    let opt1 = document.createElement("option");
    opt1.value = list[i].id;
    opt1.innerText = list[i].name;
    sel.appendChild(opt1);

    let opt2 = document.createElement("option");
    opt2.value = list[i].id;
    opt2.innerText = list[i].name;
    filterSel.appendChild(opt2);
  }
}

// 渲染分类下拉（根据收支自动筛选）
async function renderCategorySelect(){
  let type = document.getElementById("typeSel").value;
  let list = await db.categories.where("type").equals(type).toArray();
  let sel = document.getElementById("catSel");
  sel.innerHTML = "";
  for(let i=0;i<list.length;i++){
    let opt = document.createElement("option");
    opt.value = list[i].id;
    opt.innerText = list[i].name;
    sel.appendChild(opt);
  }
}

// 渲染账户下拉
async function renderAccountSelect(){
  let list = await db.accounts.toArray();
  let sel = document.getElementById("accSel");
  sel.innerHTML = "";
  for(let i=0;i<list.length;i++){
    let opt = document.createElement("option");
    opt.value = list[i].id;
    opt.innerText = list[i].name;
    sel.appendChild(opt);
  }
}

// 筛选栏下拉
async function renderFilterSelect(){
  let catList = await db.categories.toArray();
  let accList = await db.accounts.toArray();
  let catSel = document.getElementById("filterCat");
  let accSel = document.getElementById("filterAcc");

  catSel.innerHTML = "<option value=''>全部分类</option>";
  for(let i=0;i<catList.length;i++){
    let opt = document.createElement("option");
    opt.value = catList[i].id;
    opt.innerText = catList[i].name;
    catSel.appendChild(opt);
  }

  accSel.innerHTML = "<option value=''>全部账户</option>";
  for(let i=0;i<accList.length;i++){
    let opt = document.createElement("option");
    opt.value = accList[i].id;
    opt.innerText = accList[i].name;
    accSel.appendChild(opt);
  }
}

// 切换收支，自动刷新分类
document.getElementById("typeSel").addEventListener("change", async function(){
  await renderCategorySelect();
});

// 新增账本/分类/账户 按钮
document.getElementById("openBookBtn").addEventListener("click", function(){
  currentOperate = "book";
  document.getElementById("catTypeSel").style.display = "none";
});
document.getElementById("openCatBtn").addEventListener("click", function(){
  currentOperate = "cat";
  document.getElementById("catTypeSel").style.display = "block";
});
document.getElementById("openAccBtn").addEventListener("click", function(){
  currentOperate = "acc";
  document.getElementById("catTypeSel").style.display = "none";
});

// 确认添加新项目
document.getElementById("addItemBtn").addEventListener("click", async function(){
  let name = document.getElementById("newName").value.trim();
  if(name === ""){
    alert("名称不能为空");
    return;
  }
  let newId = crypto.randomUUID();
  if(currentOperate === "book"){
    await db.books.add({id:newId, name:name});
  }else if(currentOperate === "cat"){
    let catType = document.getElementById("catTypeSel").value;
    await db.categories.add({id:newId, name:name, type:catType});
  }else if(currentOperate === "acc"){
    await db.accounts.add({id:newId, name:name});
  }
  document.getElementById("newName").value = "";
  await renderAllSelect();
  alert("添加成功");
});

// 保存流水（新增/编辑共用）
document.getElementById("saveBtn").addEventListener("click", async function(){
  let bookId = document.getElementById("bookSel").value;
  let type = document.getElementById("typeSel").value;
  let yuan = parseFloat(document.getElementById("yuanInput").value || 0);
  let cents = Math.round(yuan * 100);
  let catId = document.getElementById("catSel").value;
  let accId = document.getElementById("accSel").value;
  let remark = document.getElementById("remarkInput").value.trim();

  if(cents <= 0){
    alert("金额必须大于0");
    return;
  }

  let recordData = {
    bookId: bookId,
    type: type,
    cents: cents,
    time: Date.now(),
    categoryId: catId,
    accountId: accId,
    remark: remark
  };

  if(editRecordId){
    // 编辑模式
    recordData.id = editRecordId;
    await db.records.put(recordData);
    editRecordId = null;
  }else{
    // 新增模式
    recordData.id = crypto.randomUUID();
    await db.records.add(recordData);
  }

  // 清空表单
  document.getElementById("yuanInput").value = "";
  document.getElementById("remarkInput").value = "";

  await loadRecordList();
  await calcMonthStat();
});

// 加载流水列表（带筛选条件）
async function loadRecordList(){
  let filterBook = document.getElementById("filterBook").value;
  let filterType = document.getElementById("filterType").value;
  let filterCat = document.getElementById("filterCat").value;
  let filterAcc = document.getElementById("filterAcc").value;
  let filterMonth = document.getElementById("filterMonth").value;

  let query = db.records.orderBy("time").reverse();

  // 多条件筛选
  if(filterBook) query = query.where("bookId").equals(filterBook);
  if(filterType) query = query.where("type").equals(filterType);
  if(filterCat) query = query.where("categoryId").equals(filterCat);
  if(filterAcc) query = query.where("accountId").equals(filterAcc);

  // 月份筛选
  if(filterMonth){
    let start = new Date(filterMonth + "-01").getTime();
    let end = new Date(filterMonth + "-31 23:59:59").getTime();
    query = query.where("time").between(start, end);
  }

  let list = await query.limit(100).toArray();
  let listDom = document.getElementById("list");
  listDom.innerHTML = "";

  for(let i=0;i<list.length;i++){
    let r = list[i];
    let book = await db.books.get(r.bookId);
    let cat = await db.categories.get(r.categoryId);
    let acc = await db.accounts.get(r.accountId);
    let yuan = (r.cents / 100).toFixed(2);
    let cls = r.type === "expense" ? "red" : "green";
    let prefix = r.type === "expense" ? "-" : "+";

    let div = document.createElement("div");
    div.className = "item";
    div.innerHTML = `
      <div>
        <div>${book?.name}｜${cat?.name}</div>
        <div style="font-size:13px;color:#666">${acc?.name} ${r.remark}</div>
      </div>
      <div class="edit-del">
        <span class="${cls}">${prefix}${yuan}</span>
        <button data-id="${r.id}" class="edit-btn" style="width:auto;padding:4px 6px">编辑</button>
        <button data-id="${r.id}" class="del-btn" style="width:auto;padding:4px 6px;background:#999">删除</button>
      </div>
    `;
    listDom.appendChild(div);
  }

  // 绑定编辑删除事件
  let editBtns = document.querySelectorAll(".edit-btn");
  let delBtns = document.querySelectorAll(".del-btn");
  for(let i=0;i<editBtns.length;i++){
    editBtns[i].addEventListener("click", async function(){
      let rid = this.dataset.id;
      let record = await db.records.get(rid);
      editRecordId = rid;
      // 回填表单
      document.getElementById("bookSel").value = record.bookId;
      document.getElementById("typeSel").value = record.type;
      document.getElementById("yuanInput").value = (record.cents/100).toFixed(2);
      await renderCategorySelect();
      document.getElementById("catSel").value = record.categoryId;
      document.getElementById("accSel").value = record.accountId;
      document.getElementById("remarkInput").value = record.remark;
      window.scrollTo(0,0);
    });
  }
  for(let i=0;i<delBtns.length;i++){
    delBtns[i].addEventListener("click", async function(){
      let rid = this.dataset.id;
      if(confirm("确定删除这条记录？")){
        await db.records.delete(rid);
        await loadRecordList();
        await calcMonthStat();
      }
    });
  }
}

// 月度收支统计
async function calcMonthStat(){
  let now = new Date();
  let monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  let records = await db.records.where("time").aboveOrEqual(monthStart).toArray();

  let incomeCents = 0;
  let expenseCents = 0;
  for(let i=0;i<records.length;i++){
    let r = records[i];
    if(r.type === "income") incomeCents += r.cents;
    if(r.type === "expense") expenseCents += r.cents;
  }
  let balanceCents = incomeCents - expenseCents;

  document.getElementById("sumIncome").innerText = (incomeCents/100).toFixed(2);
  document.getElementById("sumExpense").innerText = (expenseCents/100).toFixed(2);
  document.getElementById("sumBalance").innerText = (balanceCents/100).toFixed(2);
}

// 查询按钮
document.getElementById("searchBtn").addEventListener("click", async function(){
  await loadRecordList();
});

// 导出全库备份JSON
document.getElementById("exportBtn").addEventListener("click", async function(){
  let backupData = {
    books: await db.books.toArray(),
    categories: await db.categories.toArray(),
    accounts: await db.accounts.toArray(),
    records: await db.records.toArray()
  };
  let blob = new Blob([JSON.stringify(backupData,null,2)], {type:"application/json"});
  let url = URL.createObjectURL(blob);
  let a = document.createElement("a");
  a.href = url;
  a.download = "记账备份_"+new Date().toLocaleDateString()+".json";
  a.click();
  URL.revokeObjectURL(url);
});

// 导入恢复备份
document.getElementById("importFile").addEventListener("change", async function(e){
  let file = e.target.files[0];
  if(!file) return;
  let reader = new FileReader();
  reader.onload = async function(ev){
    let json = JSON.parse(ev.target.result);
    await db.transaction("rw", db.books, db.categories, db.accounts, db.records, async function(){
      await db.books.clear();
      await db.categories.clear();
      await db.accounts.clear();
      await db.records.clear();
      await db.books.bulkAdd(json.books);
      await db.categories.bulkAdd(json.categories);
      await db.accounts.bulkAdd(json.accounts);
      await db.records.bulkAdd(json.records);
    });
    alert("数据导入完成！");
    await renderAllSelect();
    await loadRecordList();
    await calcMonthStat();
  };
  reader.readAsText(file);
});

// 程序入口
async function boot(){
  await initDefaultData();
  await renderAllSelect();
  await loadRecordList();
  await calcMonthStat();
}
boot();
