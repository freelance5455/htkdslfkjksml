// BUG STORE 게임 목록 스크립트
// 게임을 추가하거나 수정할 때는 apps.json을 편집하면 됩니다.

const gameList = document.getElementById("gameList");
const searchInput = document.getElementById("searchInput");
const statusBox = document.getElementById("status");
const gameCount = document.getElementById("gameCount");

let allGames = [];

function setStatus(message = "") {
  statusBox.textContent = message;
}

function makeElement(tag, className, text) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function getIconPath(gameName) {
  // 게임 이름이 '돌 키우기'라면 gi/돌 키우기.png를 자동으로 찾습니다.
  // 웹 브라우저는 폴더 파일을 자동으로 검색할 수 없으므로 파일명을 규칙에 맞춰 넣어야 합니다.
  return "gi/" + gameName + ".png";
}

function createGameCard(game) {
  const card = makeElement("article", "game-card");
  const cover = makeElement("div", "cover");
  const image = document.createElement("img");
  image.alt = (game.name || "게임") + " 아이콘";
  image.src = getIconPath(game.name || "");
  image.onerror = () => {
    image.onerror = null;
    image.src = "gi/기본.png";
    image.onerror = () => {
      image.remove();
      cover.append(makeElement("span", "cover-placeholder", "BUG"));
    };
  };
  cover.append(image);

  const body = makeElement("div", "card-body");
  const top = makeElement("div", "card-top");
  top.append(
    makeElement("h3", "", game.name || "이름 없는 게임"),
    makeElement("span", "version", "v" + (game.version || "1.0.0"))
  );
  const description = makeElement("p", "description", game.description || "설명이 없습니다.");
  const button = makeElement("button", "install-btn", "설치");
  button.type = "button";

  button.addEventListener("click", () => {
    const url = (game.downloadUrl || "").trim();
    if (!url) {
      setStatus("이 게임에는 APK 다운로드 주소가 등록되지 않았습니다. apps.json을 확인해 줘.");
      return;
    }
    if (!/^https:\/\//i.test(url)) {
      setStatus("보안을 위해 HTTPS 다운로드 주소를 사용해 줘.");
      return;
    }

    // 웹사이트 상태에서는 APK를 다운로드합니다.
    // Android APK 변환기를 사용할 경우, 해당 변환기가 제공하는 네이티브 설치 연결 기능을 별도로 설정해야 합니다.
    // 일반 웹페이지에서는 다운로드 후 설치 화면을 자동으로 띄울 수 없습니다.
    button.disabled = true;
    button.textContent = "다운로드 시작...";
    setStatus(game.name + " 다운로드를 준비하는 중입니다.");

    const link = document.createElement("a");
    link.href = url;
    link.download = "";
    link.rel = "noopener";
    document.body.append(link);
    link.click();
    link.remove();

    button.disabled = false;
    button.textContent = "다시 다운로드";
    setStatus("다운로드를 시작했어. Android 설치 화면은 변환기에서 제공하는 설치 기능이 있어야 자동으로 열 수 있어.");
  });

  body.append(top, description, button);
  card.append(cover, body);
  return card;
}

function renderGames() {
  const query = searchInput.value.trim().toLocaleLowerCase();
  const filtered = allGames.filter(game =>
    String(game.name || "").toLocaleLowerCase().includes(query)
  );

  gameList.replaceChildren();
  gameCount.textContent = allGames.length + "개의 게임";

  if (allGames.length === 0) {
    gameList.append(makeElement("div", "empty", "지금은 게임이 등록되지 않은 상태입니다."));
    return;
  }
  if (filtered.length === 0) {
    gameList.append(makeElement("div", "empty", "검색 결과가 없습니다."));
    return;
  }
  filtered.forEach(game => gameList.append(createGameCard(game)));
}

async function loadGames() {
  try {
    const response = await fetch("apps.json");
    if (!response.ok) throw new Error("apps.json을 읽을 수 없습니다.");
    const data = await response.json();
    if (!Array.isArray(data)) throw new Error("apps.json은 배열 형식이어야 합니다.");
    allGames = data;
    setStatus("");
    renderGames();
  } catch (error) {
    allGames = [];
    gameList.replaceChildren();
    gameCount.textContent = "목록 오류";
    setStatus("게임 목록을 불러오지 못했어. 로컬 파일로 직접 열었다면 GitHub Pages 같은 웹 호스팅에서 확인해 줘.");
  }
}

searchInput.addEventListener("input", renderGames);
document.addEventListener("keydown", event => {
  if (event.key === "/" && document.activeElement !== searchInput) {
    event.preventDefault();
    searchInput.focus();
  }
});

loadGames();
