# BUG STORE (HTML 버전)

이 프로젝트는 HTML/CSS/JavaScript로 만든 정적 게임 스토어입니다. Android Studio 프로젝트가 아니라, 나중에 HTML-to-APK 변환기에 넣을 수 있는 웹 파일 묶음입니다.

## 폴더 구조

```text
BUG_STORE_HTML/
├── index.html
├── style.css
├── app.js
├── apps.json
├── README.md
└── gi/
    ├── 기본.png
    └── 게임이름.png
```

## 1. 웹사이트 실행하기

### 권장: GitHub Pages로 확인하기
브라우저에서 `index.html`을 파일로 직접 열면 브라우저 보안 정책 때문에 `apps.json`을 읽지 못할 수 있습니다. GitHub Pages로 올리거나 로컬 웹서버에서 실행하는 걸 권장합니다.

### GitHub에 올리는 방법
1. GitHub에 로그인하고 **New repository**를 누릅니다.
2. 저장소 이름을 `bug-store` 등으로 정하고 생성합니다.
3. 저장소에서 **Add file → Upload files**를 선택합니다.
4. 이 폴더 안의 파일과 `gi` 폴더를 업로드합니다. ZIP 파일 자체만 올리는 것이 아니라 압축을 풀어 안에 든 파일들을 올려야 합니다.
5. **Commit changes**를 누릅니다.
6. 저장소의 **Settings → Pages**로 이동합니다.
7. Build and deployment에서 **Deploy from a branch**를 고르고 Branch는 `main`, 폴더는 `/(root)`로 설정한 뒤 저장합니다.
8. 잠시 기다리면 GitHub Pages 주소가 표시됩니다. 그 주소로 사이트를 열어 확인합니다.

## 2. 게임 추가하기 — `apps.json`

파일 위치: `apps.json` (프로젝트 최상위 폴더)

처음에는 아래처럼 비어 있습니다.

```json
[]
```

게임을 추가하려면 아래 예시처럼 바꿉니다.

```json
[
  {
    "id": "stone-grow",
    "name": "돌 키우기",
    "description": "돌을 키우는 게임",
    "version": "1.0.0",
    "downloadUrl": "https://github.com/계정이름/저장소이름/releases/download/태그이름/stone-grow.apk"
  }
]
```

항목 설명:
- `id`: 게임을 구분하는 고유한 값. 게임마다 다르게 작성합니다.
- `name`: 카드에 표시할 게임 이름.
- `description`: 게임 설명.
- `version`: 표시할 버전.
- `downloadUrl`: 실제 APK 파일을 내려받을 수 있는 HTTPS 주소.

예시 URL은 형식 예시일 뿐입니다. 실제 GitHub 계정, 저장소, Release 태그, APK 파일 이름으로 바꿔야 합니다.

## 3. APK를 GitHub Releases에 올리는 방법

1. APK 파일을 올릴 GitHub 저장소를 만들거나 기존 저장소를 엽니다.
2. **Releases → Create a new release**를 선택합니다.
3. 태그를 예를 들어 `stone-grow-v1.0.0`으로 입력합니다.
4. 제목을 작성하고 APK 파일을 첨부합니다.
5. **Publish release**를 누릅니다.
6. 게시된 Release 페이지에서 첨부된 APK 파일의 다운로드 링크를 복사합니다.
7. 복사한 주소를 `apps.json`의 `downloadUrl`에 넣습니다.
8. `apps.json`을 저장하고 GitHub에 다시 업로드/커밋합니다.

APK 파일은 인터넷에서 접근 가능한 실제 파일이어야 합니다. 저장소 페이지 주소나 Release 설명 페이지 주소를 `downloadUrl`에 넣으면 안 됩니다.

## 4. 게임 아이콘 넣기

아이콘 폴더: `gi/`

1. PNG 이미지를 준비합니다.
2. 게임 이름과 정확히 같은 이름으로 저장합니다. 예: `돌 키우기.png`
3. `apps.json`의 `name`이 `돌 키우기`이면 자동으로 `gi/돌 키우기.png`를 표시합니다.
4. 아이콘이 없으면 `gi/기본.png`를 사용합니다.

파일 이름의 띄어쓰기까지 일치해야 합니다. 웹 브라우저는 폴더를 자동으로 검색하지 않으므로 이름 규칙을 지켜야 합니다.

## 5. HTML을 APK로 변환하기

나중에 사용할 HTML-to-APK 변환기에서 이 프로젝트의 `index.html`을 시작 파일로 지정하거나, `index.html`, `style.css`, `app.js`, `apps.json`, `gi/` 폴더를 함께 포함하세요.

변환기마다 입력 방식이 다르므로 해당 변환기의 안내를 따라야 합니다. HTML 파일만 APK로 포장한다고 자동 설치 기능이 생기는 것은 아닙니다.

- 현재 HTML 버전의 `설치` 버튼은 APK 다운로드를 시작합니다.
- 웹페이지 자체는 Android의 설치 화면을 강제로 자동 실행할 수 없습니다.
- 변환기가 Android 네이티브 브리지/다운로드 후 설치 인텐트 기능을 지원한다면 그 기능을 별도로 연결해야 합니다.
- Android는 사용자가 시스템 설치 화면에서 최종 승인을 해야 합니다.

## 6. 자주 생기는 문제

- **게임 목록이 비어 있음:** `apps.json`을 확인합니다. 비어 있는 `[]`는 정상이며, 게임이 등록되지 않았다는 안내가 표시됩니다.
- **목록 오류:** JSON 쉼표, 따옴표, 괄호를 확인합니다. `apps.json`은 반드시 유효한 JSON이어야 합니다.
- **APK가 다운로드되지 않음:** URL을 브라우저에서 직접 열어 실제 APK 파일이 다운로드되는지 확인합니다.
- **아이콘이 안 보임:** `gi/게임이름.png`의 이름과 `apps.json`의 `name`이 정확히 같은지 확인합니다.
- **파일을 직접 열었을 때 목록이 안 나옴:** `fetch("apps.json")`가 `file://`에서 차단될 수 있습니다. GitHub Pages에 올려 확인합니다.

## 보안 주의
외부 APK를 설치하기 전 출처를 확인하세요. APK 다운로드 주소는 HTTPS를 사용하고, Android의 보안 경고를 무시하도록 사용자에게 안내하지 마세요.
