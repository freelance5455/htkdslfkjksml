const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;

// Load .env without external packages.
const envPath = path.join(ROOT, ".env");
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

function send(res, status, data, type = "application/json; charset=utf-8") {
  res.writeHead(status, { "Content-Type": type, "Cache-Control": "no-store" });
  res.end(type.startsWith("application/json") ? JSON.stringify(data) : data);
}
function getLanIPs() {
  const out = [];
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const item of entries || []) {
      if (item.family === "IPv4" && !item.internal) out.push(item.address);
    }
  }
  return out;
}
const mime = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json; charset=utf-8", ".png":"image/png", ".svg":"image/svg+xml" };

const server = http.createServer(async (req, res) => {
  if (req.method === "POST" && req.url === "/api/chat") {
    if (!process.env.XAI_API_KEY) return send(res, 400, { error: "Не найден XAI_API_KEY. Заполни файл .env." });
    let raw = "";
    req.on("data", chunk => { raw += chunk; if (raw.length > 1_000_000) req.destroy(); });
    req.on("end", async () => {
      try {
        const body = JSON.parse(raw || "{}");
        const message = String(body.message || "").slice(0, 8000);
        const mode = String(body.mode || "kind");
        const level = String(body.level || "A1");
        const web = Boolean(body.web);
        if (!message.trim()) return send(res, 400, { error: "Напиши сообщение." });

        const personalities = {
          kind: "Ты добрый, терпеливый и поддерживающий преподаватель английского.",
          strict: "Ты строгий, но уважительный преподаватель. Требуешь внимательности, исправляешь ошибки прямо, никогда не унижаешь и не оскорбляешь ученика.",
          funny: "Ты юморной преподаватель английского. Используешь лёгкие добрые шутки, но не отвлекаешь от обучения.",
          pro: "Ты профессиональный и спокойный преподаватель английского, объясняешь ясно и структурированно."
        };
        const instructions = `Ты Lingua AI — безопасный дружелюбный репетитор английского для подростка. Уровень ученика: ${level}. Характер: ${personalities[mode] || personalities.kind}
Отвечай преимущественно по-русски, а примеры и практику давай на английском. Объясняй ошибки без стыда и насмешек. Подстраивай сложность под уровень. В конце ответа предложи одно короткое упражнение, если это уместно. Не утверждай, что проверил произношение, если получил только текст.`;
        const payload = {
          model: process.env.XAI_MODEL || "grok-4.7",
          instructions,
          input: [{ role: "user", content: message }],
          store: false,
          max_output_tokens: 900
        };
        if (web) payload.tools = [{ type: "web_search" }];

        const api = await fetch("https://api.x.ai/v1/responses", {
          method: "POST",
          headers: { "Authorization": `Bearer ${process.env.XAI_API_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const result = await api.json().catch(() => ({}));
        if (!api.ok) {
          const msg = result.error?.message || result.message || `xAI вернул ошибку ${api.status}`;
          return send(res, api.status, { error: msg });
        }
        let answer = result.output_text || "";
        if (!answer && Array.isArray(result.output)) {
          answer = result.output.flatMap(x => x.content || []).map(x => x.text || "").filter(Boolean).join("\n");
        }
        const citations = [];
        for (const item of (result.output || [])) {
          for (const c of (item.content || [])) {
            if (c.annotations) for (const a of c.annotations) if (a.url) citations.push({ title: a.title || a.url, url: a.url });
          }
        }
        send(res, 200, { answer: answer || "Не удалось получить текстовый ответ.", citations });
      } catch (e) {
        send(res, 500, { error: "Ошибка сервера: " + e.message });
      }
    });
    return;
  }

  if (req.method === "GET" && req.url === "/api/status") {
    return send(res, 200, { configured: Boolean(process.env.XAI_API_KEY), model: process.env.XAI_MODEL || "grok-4.7" });
  }
  const requested = req.url === "/" ? "/index.html" : decodeURIComponent(req.url.split("?")[0]);
  const full = path.normalize(path.join(ROOT, requested));
  if (!full.startsWith(ROOT)) return send(res, 403, { error: "Forbidden" });
  fs.readFile(full, (err, data) => {
    if (err) return send(res, 404, "Not found", "text/plain; charset=utf-8");
    send(res, 200, data, mime[path.extname(full)] || "application/octet-stream");
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("\\nLingua AI запущен!");
  console.log(`На этом компьютере: http://localhost:${PORT}`);
  for (const ip of getLanIPs()) console.log(`На телефоне в той же Wi-Fi сети: http://${ip}:${PORT}`);
  console.log("Не публикуй этот адрес в открытом интернете. Остановить: Ctrl+C\\n");
});
