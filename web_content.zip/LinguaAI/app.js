const $ = id => document.getElementById(id);
const chat = $("chat");
let listening = false, recognition = null;

function addBubble(text, who="bot", citations=[]) {
  const el = document.createElement("div");
  el.className = "bubble " + who;
  el.textContent = text;
  if (citations.length) {
    const wrap = document.createElement("div");
    wrap.style.marginTop = "10px";
    citations.forEach(c => {
      const a = document.createElement("a");
      a.href = c.url; a.target = "_blank"; a.rel = "noopener noreferrer";
      a.textContent = "Источник: " + (c.title || c.url);
      a.style.display = "block"; wrap.appendChild(a);
    });
    el.appendChild(wrap);
  }
  chat.appendChild(el); chat.scrollTop = chat.scrollHeight; return el;
}
async function status() {
  try {
    const r = await fetch("/api/status"); const d = await r.json();
    $("status").textContent = d.configured ? "Grok подключён" : "Нужен API-ключ";
    $("status").style.color = d.configured ? "#91f2be" : "#ffd28a";
  } catch { $("status").textContent = "Сервер недоступен"; }
}
async function sendMessage(text) {
  if (!text.trim()) return;
  addBubble(text, "user");
  const wait = addBubble("Думаю…", "bot");
  $("send").disabled = true;
  try {
    const r = await fetch("/api/chat", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,mode:$("mode").value,level:$("level").value,web:$("web").checked})});
    const d = await r.json();
    wait.remove();
    if (!r.ok) throw new Error(d.error || "Ошибка запроса");
    const answer = d.answer || "Пустой ответ.";
    addBubble(answer, "bot", d.citations || []);
    if ("speechSynthesis" in window) {
      const utter = new SpeechSynthesisUtterance(answer);
      utter.lang = "en-US"; utter.rate = 0.92;
      // Set Russian voice for mostly Russian explanations when available; user can change device voice.
      speechSynthesis.cancel(); speechSynthesis.speak(utter);
    }
  } catch(e) { wait.textContent = "Ошибка: " + e.message; }
  finally { $("send").disabled = false; }
}
$("form").addEventListener("submit", e => {e.preventDefault(); const t=$("message").value; $("message").value=""; sendMessage(t);});
document.querySelectorAll("[data-prompt]").forEach(b => b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
function setupMic() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { $("voiceInfo").textContent = "В этом браузере распознавание речи недоступно. Попробуй Chrome."; $("mic").disabled = true; return; }
  recognition = new SR(); recognition.lang = "en-US"; recognition.interimResults = false; recognition.maxAlternatives = 1;
  recognition.onresult = e => { const t=e.results[0][0].transcript; $("message").value=t; $("voiceInfo").textContent="Распознано: "+t; };
  recognition.onerror = e => {$("voiceInfo").textContent="Микрофон: "+e.error; listening=false; $("mic").textContent="🎙️ Говорить";};
  recognition.onend = () => {listening=false; $("mic").textContent="🎙️ Говорить";};
  $("mic").addEventListener("click",()=>{
    if (!listening) { try {recognition.start(); listening=true; $("mic").textContent="⏹ Остановить"; $("voiceInfo").textContent="Слушаю… Говори по-английски."; } catch {} }
    else recognition.stop();
  });
}
status(); setupMic();
