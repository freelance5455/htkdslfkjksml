@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js не найден. Установи Node.js LTS с https://nodejs.org/
  pause
  exit /b 1
)
if not exist .env (
  copy .env.example .env >nul
  echo Создан файл .env. Открой его Блокнотом и вставь свой Grok API-ключ.
  notepad .env
  echo После сохранения закрой Блокнот и снова запусти START_WINDOWS.bat.
  pause
  exit /b 0
)
node server.js
pause
