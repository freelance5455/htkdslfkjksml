# CYBERNEX ACADEMY v2 — Dedicated lesson experience

## Run locally
Open `index.html` in a modern browser. For best results, serve this folder through a simple static web host. `lesson.html?id=lesson-01` opens the first dedicated lesson.

## Included
- 56 individual lessons across all 7 requested learning levels
- Each lesson has learning objectives, a detailed explanation of 7 sections, a real-world style example, practical demonstration, important notes, 3 MCQs with explanations and homework
- Lesson sidebar, lesson search, previous/next navigation
- Browser-local completion tracking and quiz feedback
- Responsive mobile and desktop design
- Hinglish teaching direction with English technical terminology
- Defensive and permission-based practice boundaries

## Content note
Each lesson's detailed explanation is authored as a topic-specific learning guide with reusable professional learning principles. Word count is displayed on each lesson page. The lesson content is designed as a strong teaching draft; an instructor should review, enrich and localize it before commercial delivery.

## Production limitations
This is a static frontend package. It does NOT yet provide secure accounts, cloud database, server-side progress, admin dashboard, video/PDF hosting, assignment uploads, verified certificates, payment gateway, email or WhatsApp delivery. Browser localStorage is only a local demo and must not be used as secure student identity or payment storage.

For production, connect a backend such as Supabase or a custom API with row-level security, role-based access, secure file storage, server-side quiz/progress records, payment webhooks, audit logging and HTTPS. Publish verified instructor details, fee schedule, privacy policy, terms and contact information. All labs must remain isolated and explicitly authorized.
