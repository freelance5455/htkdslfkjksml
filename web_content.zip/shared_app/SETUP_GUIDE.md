# Setup Guide: Shared College Attendance App

This takes about 30 to 45 minutes. It uses Google Sheets (the database) and Google Apps Script (the app). Everything is free with a Google account.

## Step 1: Create the sheet
1. Go to sheets.google.com and create a blank spreadsheet. Name it "College Attendance".
2. Menu: Extensions > Apps Script. A code editor opens.
3. Delete the default code. Paste the contents of Code.gs.
4. Click the "+" next to Files, choose HTML, name it exactly Index (not Index.html). Paste the contents of Index.html.
5. Click Save (disk icon).

## Step 2: Create the three sheets
1. In the editor, choose the function dropdown, select setup, and click Run.
2. Approve the permissions prompt (Advanced > Go to project, if Google shows a warning, because it is your own script).
3. Go back to the spreadsheet. Tabs Users, Subjects and Attendance now exist with headers.

## Step 3: Set passwords
For each user, you need a password hash, not a plain password.
1. In the editor, choose makeHash from the dropdown and enter the password in the code (replace the text inside the brackets in the function call, or call it from the Run menu after adding a test line).
   Simplest method: in the editor, add a line at the bottom: makeHash("choose-a-password") and Run makeHash.
2. View > Logs (or Execution log) shows a long code, for example abc123...=.
3. Copy it into the password_hash column of the Users sheet for that user.
4. Repeat for every user and remove the test line afterwards.

## Step 4: Add users and subjects
1. Paste rows from templates/Users.csv into the Users tab (replace the example names and IDs with real ones, one row per student, teacher, and coordinator).
2. Paste rows from templates/Subjects.csv into the Subjects tab, using the real teacher IDs and semester numbers.
3. Leave the Attendance tab empty except for its header row.

## Step 5: Publish the app
1. In the editor: Deploy > New deployment.
2. Type: Web app. Execute as: Me. Who has access: Anyone with the link (for a college, choose "Anyone within your organisation" if you use a Google Workspace account).
3. Click Deploy, approve permissions, and copy the Web app URL.
4. Send that URL to your friends. Each person logs in with their ID and password.

## Step 6: Test before sharing
- Log in as a student: check that subjects and percentages appear.
- Log in as a teacher: open a class, mark students, save, and reopen to check that marks are kept.
- Log in as the coordinator: check the summary table.
- Try a wrong password and confirm it is rejected.

## Updating the app later
After changing code, use Deploy > Manage deployments > Edit > New version, so the link stays the same.

## Known limits (state these in your report)
- Passwords are hashed (SHA-256) but there is no password reset or account lockout.
- Anyone with the link can reach the login page; only the login protects the data.
- Google Sheets is fine for one department (roughly up to a few hundred students), not for a whole university.
- The app does not handle exam results, fees, or biometric or ERP integration.
- Attendance is only as accurate as the teacher's marking.
