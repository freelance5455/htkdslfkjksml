# College Attendance App - Shared Version

Files:
- Code.gs: Server logic (paste into Apps Script)
- Index.html: The web page (paste as an HTML file named Index in Apps Script)
- SETUP_GUIDE.md: Step-by-step setup, about 30 to 45 minutes
- templates/Users.csv, Subjects.csv, Attendance.csv: Sheet templates to copy into the spreadsheet

Roles: Student (view own attendance and alerts below 75%), Teacher (mark one class per day), Coordinator (department summary).
Start with SETUP_GUIDE.md.
