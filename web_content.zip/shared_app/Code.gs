/**
 * College Attendance App - server side (Google Apps Script)
 * Data lives in the Google Sheet this script is attached to.
 * Sheets required: Users, Subjects, Attendance (created by setup()).
 */

const MIN_PERCENT = 75;

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('College Attendance')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ---------- Setup and helpers ----------

// Run once from the Apps Script editor: creates the three sheets with headers.
function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const needed = {
    Users: ['user_id', 'name', 'role', 'semester', 'password_hash'],
    Subjects: ['subject_code', 'subject_name', 'teacher_id', 'semester'],
    Attendance: ['date', 'subject_code', 'student_id', 'status', 'marked_by']
  };
  Object.keys(needed).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    if (sh.getLastRow() === 0) sh.appendRow(needed[name]);
  });
  Logger.log('Setup complete. Now add users and subjects.');
}

// Run from the editor to turn a password into the hash stored in the Users sheet.
// View > Logs shows the output.
function makeHash(password) {
  Logger.log(hashPassword(password));
}

function hashPassword(password) {
  return Utilities.base64Encode(
    Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(password))
  );
}

function rows(sheetName) {
  const values = SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(sheetName).getDataRange().getValues();
  const headers = values.shift();
  return values.map(r => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = r[i]);
    return obj;
  });
}

// Every call re-checks the user's ID and password on the server.
function verify(auth) {
  if (!auth || !auth.id || !auth.password) throw new Error('Not logged in');
  const user = rows('Users').find(u => String(u.user_id) === String(auth.id));
  if (!user || user.password_hash !== hashPassword(auth.password)) {
    throw new Error('Wrong ID or password');
  }
  return user;
}

// ---------- Functions called from the web page ----------

function login(auth) {
  try {
    const user = verify(auth);
    return { ok: true, user: { id: String(user.user_id), name: user.name, role: user.role, semester: String(user.semester) } };
  } catch (e) {
    return { ok: false, message: e.message };
  }
}

// Student: own attendance per subject
function getStudentSummary(auth) {
  const user = verify(auth);
  if (user.role !== 'student') throw new Error('Students only');
  const subjects = rows('Subjects').filter(s => String(s.semester) === String(user.semester));
  const att = rows('Attendance').filter(a => String(a.student_id) === String(user.user_id));
  const result = subjects.map(s => {
    const recs = att.filter(a => a.subject_code === s.subject_code);
    const present = recs.filter(a => a.status === 'P').length;
    return {
      code: s.subject_code,
      name: s.subject_name,
      attended: present,
      total: recs.length,
      percent: recs.length ? Math.round(present / recs.length * 1000) / 10 : null
    };
  });
  return { name: user.name, subjects: result, minPercent: MIN_PERCENT };
}

// Teacher: classes assigned to this teacher
function getTeacherClasses(auth) {
  const user = verify(auth);
  if (user.role !== 'teacher') throw new Error('Teachers only');
  return rows('Subjects')
    .filter(s => String(s.teacher_id) === String(user.user_id))
    .map(s => ({ code: s.subject_code, name: s.subject_name, semester: String(s.semester) }));
}

// Teacher: students in a class, plus today's saved marks if any
function getRoster(auth, subjectCode, date) {
  const user = verify(auth);
  if (user.role !== 'teacher') throw new Error('Teachers only');
  const subject = rows('Subjects').find(s => s.subject_code === subjectCode);
  if (!subject || String(subject.teacher_id) !== String(user.user_id)) throw new Error('Not your class');
  const students = rows('Users')
    .filter(u => u.role === 'student' && String(u.semester) === String(subject.semester))
    .map(u => ({ id: String(u.user_id), name: u.name }));
  const saved = rows('Attendance').filter(a => a.subject_code === subjectCode && String(a.date) === date);
  const presentIds = saved.filter(a => a.status === 'P').map(a => String(a.student_id));
  return { students: students, presentIds: presentIds, alreadySaved: saved.length > 0 };
}

// Teacher: save one class session (replaces any earlier save for the same date and class)
function saveAttendance(auth, subjectCode, date, presentIds) {
  const user = verify(auth);
  if (user.role !== 'teacher') throw new Error('Teachers only');
  const subject = rows('Subjects').find(s => s.subject_code === subjectCode);
  if (!subject || String(subject.teacher_id) !== String(user.user_id)) throw new Error('Not your class');

  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Attendance');
  const data = sh.getDataRange().getValues();
  // Delete old rows for this class and date, bottom to top so row numbers stay correct
  for (let i = data.length - 1; i >= 1; i--) {
    if (String(data[i][0]) === date && data[i][1] === subjectCode) sh.deleteRow(i + 1);
  }
  const students = rows('Users').filter(u => u.role === 'student' && String(u.semester) === String(subject.semester));
  const newRows = students.map(u => [
    date, subjectCode, String(u.user_id),
    presentIds.map(String).indexOf(String(u.user_id)) >= 0 ? 'P' : 'A',
    String(user.user_id)
  ]);
  if (newRows.length) sh.getRange(sh.getLastRow() + 1, 1, newRows.length, 5).setValues(newRows);
  return { ok: true, saved: newRows.length };
}

// Coordinator: each subject's average and number of students below the minimum
function getCoordinatorReport(auth) {
  const user = verify(auth);
  if (user.role !== 'coordinator') throw new Error('Coordinators only');
  const att = rows('Attendance');
  return rows('Subjects').map(s => {
    const students = rows('Users').filter(u => u.role === 'student' && String(u.semester) === String(s.semester));
    let below = 0, total = 0;
    students.forEach(st => {
      const recs = att.filter(a => a.subject_code === s.subject_code && String(a.student_id) === String(st.user_id));
      if (!recs.length) return;
      const pct = recs.filter(a => a.status === 'P').length / recs.length * 100;
      total += pct;
      if (pct < MIN_PERCENT) below++;
    });
    const counted = students.filter(st => att.some(a => a.subject_code === s.subject_code && String(a.student_id) === String(st.user_id))).length;
    return {
      code: s.subject_code,
      name: s.subject_name,
      average: counted ? Math.round(total / counted * 10) / 10 : null,
      belowMinimum: below
    };
  });
}
