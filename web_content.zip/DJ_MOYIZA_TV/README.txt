DJ MOYIZA TV - prototype web en ligne
1. Décompressez le ZIP.
2. Ouvrez index.html dans Chrome.
3. Les boutons ouvrent les sites/recherches vidéo en ligne.
4. Dans Chrome, menu ⋮ > Ajouter à l'écran d'accueil.
Ce prototype n'est pas un APK natif. Les liens recherchent les contenus et les flux directs ne sont pas garantis.
