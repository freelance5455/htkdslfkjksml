DJ MOYIZA TV — Prototype web mobile
1. Décompressez le ZIP sur votre téléphone.
2. Ouvrez index.html avec Chrome.
3. Pour une installation type application, utilisez le menu Chrome > Ajouter à l'écran d'accueil.
Ce prototype n'est pas un APK et ne contient pas de flux TV. Les flux doivent être ajoutés depuis des sources officielles autorisées.
