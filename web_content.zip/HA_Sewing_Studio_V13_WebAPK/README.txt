HA Sewing Studio V13 - Web APK Builder Package

Upload this ZIP to a service that accepts an HTML/ZIP website and packages it as an Android APK.
Entry file: index.html
Offline app: Yes (the app is self-contained in index.html).

Suggested app name: HA Sewing Studio V13
Package/app ID for a separate test build (if the service asks): com.hasewingstudio.v13
