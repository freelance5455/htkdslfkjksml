# สร้าง APK โดยไม่ต้องติดตั้ง Android Studio

โปรเจกต์นี้มี GitHub Actions สำหรับสร้าง APK ให้อัตโนมัติ

## วิธีใช้
1. สร้าง Repository ใหม่ใน GitHub
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์โปรเจกต์นี้เข้า Repository
3. เปิดแท็บ `Actions`
4. เลือก `Build Monee APK`
5. กด `Run workflow`
6. เมื่อเสร็จ เปิดรายการงานที่รัน แล้วดาวน์โหลด Artifact ชื่อ `Monee-v1.0.0-APK`
7. แตก ZIP ที่ GitHub ให้มา จะได้ `Monee-v1.0.0-debug.apk`
8. ส่ง APK เข้าโทรศัพท์แล้วติดตั้ง

Android อาจถามสิทธิ์ "ติดตั้งแอปที่ไม่รู้จัก" สำหรับแอปที่ใช้เปิดไฟล์ APK
