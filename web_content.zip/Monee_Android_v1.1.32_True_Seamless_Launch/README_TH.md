# Monee Android v1.0.0

แอปรายรับ-รายจ่ายส่วนตัวสำหรับ Android แบบ Offline-first

## มีอะไรในเวอร์ชันนี้
- เพิ่ม / แก้ไข / ลบ รายรับและรายจ่าย
- แยกข้อมูลเป็นรายเดือน
- เพิ่มและลบหมวดหมู่เอง
- Dashboard สรุปรายรับ รายจ่าย และยอดคงเหลือ
- วิเคราะห์รายจ่ายตามหมวดหมู่
- Dark Mode
- สำรองข้อมูลเป็น JSON ผ่าน Android file picker
- กู้คืนข้อมูลจากไฟล์ JSON
- IndexedDB เก็บข้อมูลอยู่ในเครื่อง
- ไม่มี Google Sheet
- ไม่มี Login
- ไม่ต้องใช้อินเทอร์เน็ตระหว่างใช้งาน

## วิธี Build APK
1. ติดตั้ง Android Studio รุ่นปัจจุบัน
2. เปิดโฟลเดอร์ `Monee_Android_v1.0.0`
3. ถ้า Android Studio ขอ SDK ให้ติดตั้ง Android SDK Platform 37
4. รอ Gradle Sync
5. เมนู `Build` > `Build App Bundles or APKs` > `Build APKs`
6. ไฟล์จะอยู่ที่:
   `app/build/outputs/apk/debug/app-debug.apk`

สำหรับใช้ในมือถือของตัวเอง สามารถติดตั้ง debug APK ได้เลย
โดย Android อาจขออนุญาต "ติดตั้งแอปที่ไม่รู้จัก" สำหรับแอป Files/Browser ที่ใช้เปิด APK

## Release APK
เมื่อต้องการ APK แบบเซ็นชื่อ:
`Build` > `Generate Signed App Bundle or APK` > `APK`

เก็บ keystore ไว้ให้ดี เพราะต้องใช้ key เดิมเมื่อต้องการอัปเดตแอปเวอร์ชันถัดไป


## วิธีที่ 2: Build บน GitHub อัตโนมัติ
มี Workflow อยู่ที่ `.github/workflows/build-apk.yml`
อ่านขั้นตอนได้ที่ `BUILD_APK_GITHUB_TH.md`

Workflow ใช้ Java 17, Android API 37, Build Tools 36.0.0 และ Gradle 9.6.0
