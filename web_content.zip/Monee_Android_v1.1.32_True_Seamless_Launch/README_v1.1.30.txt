Monee v1.1.30 — System Splash Clean

- Android 12+ mandatory system splash no longer shows the standalone centered app icon.
- System splash uses the same soft mint background as Monee Splash B.
- System splash icon is transparent and animation duration is set to 0.
- MainActivity remains the launcher; no extra SplashActivity is used.
- Cute Splash B, Mali typography, app layout, data logic and finance features are unchanged.
