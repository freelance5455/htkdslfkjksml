Monee v1.1.32 — True Seamless Launch

- Fix Android 12+ system splash falling back to the app icon on some Samsung devices.
- Replace transparent splash icon drawable with a valid solid vector matching the splash background.
- Keep native Cute Soft splash as the first visible branded frame.
- Remove the premature setTheme() override in MainActivity.
- Correct GitHub Actions APK/artifact names to v1.1.32.
- No finance data, layout, or business logic changes.
