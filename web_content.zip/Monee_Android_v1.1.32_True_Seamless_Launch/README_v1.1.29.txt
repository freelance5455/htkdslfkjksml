Monee v1.1.29 — Corrected Splash Typography
- Restores all in-app typography exactly to the v1.1.27 baseline.
- Splash text uses the same Mali font stack as the app UI.
- Cute bouncing-dot loading is retained.
- Android native launch shows brand icon briefly, then the HTML splash handles all text for consistent typography.
- No finance/data logic changes.
