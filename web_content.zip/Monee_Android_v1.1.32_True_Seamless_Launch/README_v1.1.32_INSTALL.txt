Monee v1.1.32
Build/install this APK, then uninstall the previous Monee build first if Android keeps an old launch snapshot.
The GitHub artifact name for this version is Monee-v1.1.32-APK.
