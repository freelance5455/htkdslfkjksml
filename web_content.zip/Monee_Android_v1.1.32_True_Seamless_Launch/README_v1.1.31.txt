Monee v1.1.31 — Seamless Launch

- Android 12+ system splash uses the same mint tone with a transparent system icon.
- A native splash matching the Cute Soft B screen is shown immediately while WebView initializes.
- Native splash remains until Monee data/UI is ready, preventing the white/blank launch frame.
- Existing Home font, layout, data logic, and Quick Add behavior are unchanged.
