# Monee currently does not minify release builds.
