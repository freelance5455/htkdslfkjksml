# TEST REPORT — VICE MOMENT FINDER ULTIMATE v2.0.0

Every number below comes from a run executed while preparing this release (Node v22, Playwright Chromium, Linux cloud container). Nothing is reported as passed unless it was executed. **No real Android device and no APK/WebView was available, so none of that was tested** (section 4).

## 1. Automated unit tests — `npm test` (Node built-in runner, no installs)

| File | What it covers | Tests |
|---|---|---|
| `test/engine.test.js` | (original, kept) timestamp parsing/rounding, SRT/VTT/pasted formats, 8-hour detection, padding, dedupe, chunk boundaries, ranking, exports, CSV injection, 100k-cue file | 46 |
| `test/engine2.test.js` | 6 new categories (EN/Hinglish/Devanagari), lone "lol/omg/wtf" rejected, multi-line and dialogue context, intensity, mixed-language, `recordWindow` (clamp/floor/ceil/Shorts-fit), no invented timestamps, evidence split, visual markers, long transcript | 16 |
| `test/creator.test.js` | titles in 3 languages for every category, determinism, hashtags, length limits, user edits, markup stripping, 15 copy fields, combined copy, CSV safety | 12 |
| `test/loader.test.js` | file type/size/empty checks, Hindi/Devanagari round-trip, BOM, UTF-16, binary, invalid UTF-8, same file twice, files in sequence, 5 MB decode | 10 |
| `test/store.test.js` | save, list, restore, delete, clear-all, compact storage, update-in-place, validation errors, name cleaning, 100-project limit, Hindi round-trip, no-IndexedDB fallback | 11 |
| `test/server.test.js` | (original) file serving, security headers, path traversal, symlinks, methods | 8 |
| `test/static.test.js` | see section 2 | 18 |

**Latest full run result:** see the line "Final run" at the bottom of this file.

Limits of this layer: the storage tests use an in-memory backend (Node has no IndexedDB); the real IndexedDB is covered in section 3. Detection quality is tested on synthetic streams I generated, not on your real streams.

## 2. Static tests (`test/static.test.js`)

These read the shipped files; they do not run a browser. They check: manifest fields and icon sizes; **every public file is in the service-worker cache list and exists**; install does not force `skipWaiting`, uses `cache: 'reload'` and has the `SKIP_WAITING` update message; script load order (engine → creator → loader → store → app); required controls exist in `index.html` and are used by `app.js`; every `$('id')` in `app.js` exists in the HTML; every tab has a view; the file picker is a real `<input type=file>` laid over the button, with no `accept` filter, no label forwarding, change+input listeners and a reset for re-picking the same file; worker.js wiring; modules expose the functions the app calls; no `innerHTML`/`eval`/`document.write` in any of the 7 scripts; no inline script/style/handlers and a strict CSP; no network calls in any module; only `store.js` touches IndexedDB; no keys/secrets; `_headers` CSP equals the server CSP; version 2.0.0 in package.json, service worker and docs; no missing referenced files; no development leftovers in `public/`; README mentions the required topics.

## 3. Real-browser tests — `npm run test:browser` (`tools/run-browser-checks.js`)

Playwright + desktop **Chromium** emulating a phone: 360×780 viewport, touch enabled, an **Android Chrome user-agent**. This is *not* a real phone.

**Latest result: 52 passed, 0 failed.**

- **File picker:** a real *touch tap* on the visible button opens the file chooser; no narrow `accept` filter; Hindi `.srt` text arrives in the box byte-for-byte; filename/status shown; analysis starts automatically; **same file selected 2× and 3×** works; Hinglish `.vtt`, `.txt`, and a 6-hour `.srt` in sequence; rejected with friendly messages: empty file, `.png`, binary named `.txt`, file over 10 MB, non-UTF-8 text, text with no timestamps; a good file still loads after errors; manual paste still works with correct `&t=70s` link; "Paste from clipboard" works; an 8-hour transcript loads through the worker and, being over the display limit, is analysed from memory with a clear status.
- **App:** dashboard tiles; selecting moments updates counters; padding buttons change the record window; creator panel with Hindi/Hinglish titles; copy of one field and of everything (real clipboard); CSV and TXT downloads; Shorts plan list, edited title, checklist progress, selected-CSV export.
- **Storage (real IndexedDB):** save, survive a page reload, restore (moments, selection, edited title, checklist), delete with two-tap confirmation, clear-all with two-tap confirmation.
- **Safety:** visual markers labelled "given by you"; `<img onerror>` / `<script>` inside a transcript is shown as text and never runs; **zero requests to any other website**.
- **PWA:** Chrome's installability check returned no errors; service worker active and caching; **offline (network cut): the app reloads and analyses**; update flow: "new version is ready" bar appears, after "Update now" only the new cache remains and the new file contents are served.

Bugs found by these tests and fixed during this release: padding buttons overflowed at 360 px; the page reloaded needlessly on the very first visit; a new service-worker version could install a stale HTTP-cached file; a very large text box froze the page (now capped at 500,000 characters, larger text is kept in memory); `store.save()` threw synchronously on validation errors instead of returning a rejected promise (found by `store.test.js`, so the Save button would have shown nothing).

Not covered here: Firefox/Safari, other Chrome versions, a real file manager (Playwright injects the file into the chooser), real touch-keyboard behaviour, `display-mode: standalone` rendering (the manifest requests it and Chrome's installability check passed, but the installed window itself was not opened).

## 4. Android-specific testing

| Item | Status |
|---|---|
| Real Android phone (Vivo V17 Pro) in Chrome | **NOT tested** |
| Installed PWA on a real phone (standalone window) | **NOT tested** |
| Android Chrome file picker with a real `.srt` in Downloads | **NOT tested** (emulated only; see section 3) |
| Android WebView / HTML-to-APK converter file chooser (`onShowFileChooser`) | **NOT tested**. The app cannot fix a wrapper that lacks it; see README |
| APK | **Not built** (no Android SDK in the build environment) |
| Performance/memory on 8 GB phone | **NOT tested** (8-hour synthetic file analysed in well under a second on a desktop container) |

Please try on your phone: (1) choose a real `.srt`, (2) install from Chrome, (3) turn on airplane mode and reopen the app. If any of that fails, tell me exactly what you see.

## 5. Final run

Run on the extracted release ZIP itself (not the working folder), 2026-11-21:

- `npm test`: **121 tests, 121 passed, 0 failed, 0 skipped** (46 + 16 + 12 + 10 + 11 + 8 + 18).
- `npm run test:browser`: **52 passed, 0 failed**.
- Failing tests remaining: **none**. Real Android / WebView / APK: **not tested** (section 4).
