# TEST REPORT - VICE MOMENT FINDER v1.0.0
Generated from real runs on 2026-11-22 (Node v22.23.5, Chromium via Playwright, FFmpeg present).

## Summary
| Suite | Command | Result |
|---|---|---|
| Unit + backend (YouTube **simulated**) | `npm test` | **55 / 55 passed**, 0 failed, 0 skipped |
| Browser, Chromium with Android Chrome profile (Pixel 7: 412x915, touch, Android UA; YouTube **simulated**) | `npm run test:browser` | **23 / 23 passed** |
| Real YouTube | `npm run live -- <link>` | **NOT RUN** - the build environment cannot reach YouTube (DNS failure). Run it yourself. |
| Real Android phone | - | **NOT RUN** |

## What is simulated vs real
- **Simulated:** every YouTube response (watch page, caption track, oEmbed, Google API) comes from `tests/helpers/mock-youtube.js`. Transcript content comes from a synthetic Hinglish GTA fixture (`tests/fixtures/hinglish-gta.srt`, 5 planted moments with known timestamps).
- **Real:** the parsing, engine, scoring, boundaries, IndexedDB persistence, service worker, offline behaviour, downloads and layout all ran for real in Chromium. The FFmpeg clip test ran real FFmpeg.
- **Not covered:** the live YouTube site, real phones, real Hindi stream captions, installing the PWA through Chrome's install prompt (only manifest + active service worker + precache were verified).

## Acceptance criteria (spec section 20)
| # | Criterion | Evidence | Status |
|---|---|---|---|
| 1 | Paste a valid YouTube link | browser: TEST 1 + link flow | Passed |
| 2 | Retrieve metadata | simulated oEmbed (server + browser) | Passed (simulated); live unverified |
| 3 | Automatically retrieve captions | simulated (server + browser) | Passed (simulated); **live unverified** |
| 4 | Normalise timestamps | transcript tests (sort, repair, rolling-caption collapse) | Passed |
| 5 | Identify contextual moments | engine tests (context, keyword-only rejection, Hindi) | Passed on fixtures |
| 6 | Accurate start/end | engine fixture check vs planted truth; boundary tests | Passed on fixture |
| 7 | Rank and explain | score = documented weighted sum test; card shows reason + breakdown | Passed |
| 8 | Save and restore | browser: IndexedDB save, reload, reopen, edits + saved moments kept | Passed |
| 9 | Navigate to moment on YouTube | browser: link `youtu.be/ID?t=` matches shown start | Passed |
| 10 | Unavailable transcripts, nothing fabricated | server: 4 failure types + network; browser: no-captions, backend down, offline | Passed |
| 11 | Unsupported clipping, no fake download | browser: no clip/download button, reason shown | Passed |
| 12 | Works on Android Chrome | emulated profile only | **Partially verified** (emulation, not a real phone) |

## Bugs the tests found and that were fixed
1. `adjustBounds` could return end = start = 0 when the end was dragged far below the start.
2. Hindi title options sometimes had no Devanagari (quoted-line titles).
3. Small buttons were 38px tall (now 44px minimum).
4. An invalid link showed "Transcript could not be retrieved" instead of "That link will not work".
5. The service worker answered /api/ requests itself and called any backend failure "offline", even for a separate backend URL. It now leaves API calls alone.
6. A test fixture video id was 12 characters (test bug).

## Test inventory
### Unit + backend (55)
```
ok 1 - presets match the spec ranges
ok 2 - adjustBounds: arithmetic, clamping and minimum length
ok 3 - timestamp range label
ok 4 - clip capability never claims YouTube downloading
ok 5 - shell quoting and ffmpeg command text
ok 6 - REAL ffmpeg: generated command produces a clip of the requested length
ok 7 - creator pack has 3 Hindi + 3 Hinglish titles, hook, description, caption and hashtags
ok 8 - quotes come from the real line and profanity is never put into titles
ok 9 - titles never claim things the transcript does not show
ok 10 - every category produces titles; suggestTitle is the first Hinglish title
ok 11 - finds every planted moment in the synthetic Hinglish fixture, with sensible timestamps
ok 12 - does not invent moments in calm filler (no moment starts in the calm stretches)
ok 13 - every moment carries all required fields
ok 14 - scoring is transparent: score equals the documented weighted sum (no audio -> audio weight dropped)
ok 15 - context matters: an ordinary sentence becomes the punchline because laughter follows it
ok 16 - keywords alone are not enough: casual mentions of police/glitch in calm explanation produce nothing
ok 17 - Hindi (Devanagari) transcript is analysed, including laughter and exclamations
ok 18 - boundaries avoid cutting dialogue: window starts/ends on whole transcript lines near pauses
ok 19 - duration presets change window length; recommendations are not hard limits
ok 20 - duplicate / overlap detection
ok 21 - maxMoments and minScore are respected; weak moments are not padded in
ok 22 - empty / tiny transcripts give honest notes, not fake results
ok 23 - audio: re-ranks existing candidates but never creates a moment on its own
ok 24 - performance: an 8-hour, ~10k line transcript analyses quickly
ok 25 - health endpoint reports capabilities
ok 26 - TEST 3 (simulated): captions are retrieved, normalised and carry the real timeline
ok 27 - explicit language: English manual track selected; missing language is reported, not faked
ok 28 - TEST 10 (simulated): failed retrieval gives a specific reason and NO transcript text
ok 29 - network failure is reported as NETWORK
ok 30 - invalid video id -> 400
ok 31 - owner OAuth path: good token uses the official API; bad/expired tokens fall back honestly
ok 32 - PUBLIC_CAPTIONS=off disables the unofficial provider and says so
ok 33 - meta endpoint (oEmbed)
ok 34 - rate limiting and method checks
ok 35 - static files: app shell served, service worker not cached, path traversal blocked
ok 36 - player response extraction survives braces inside strings; track picking order
ok 37 - settings: defaults, merge, persistence, corrupt data and blocked storage
ok 38 - history: newest first, de-duplicated by video, capped
ok 39 - newProject + JSON export contain everything needed to restore
ok 40 - IndexedDB unavailable gives a readable error
ok 41 - PWA files: manifest is valid and the service worker precaches every shipped file
ok 42 - timestamp helpers
ok 43 - SRT: parses cues, strips tags/BOM, decodes entities, keeps Hindi (Devanagari)
ok 44 - VTT: header, NOTE blocks, cue ids, settings, short timestamps and voice tags
ok 45 - plain text: bracketed, ranged and two-line formats (the format from the spec)
ok 46 - format auto-detection and honest warnings
ok 47 - json3 and timedtext XML (YouTube formats)
ok 48 - normalize: sorts, repairs bad ends, never moves start times, drops empties
ok 49 - normalize: collapses rolling auto-caption repeats but not unrelated sentences
ok 50 - language detection: Hindi, Hinglish, English
ok 51 - exports: SRT round-trips and TXT is timestamped
ok 52 - parses standard URL formats and extracts the video id
ok 53 - reads start time from t= / start=
ok 54 - rejects invalid, foreign and look-alike URLs
ok 55 - link builders
```
### Browser (23)
```
PASS  Android profile is active (mobile UA, touch)
PASS  TEST 1: home screen shows URL input, Analyse, Paste, Clear, 4 nav tabs
PASS  mobile layout: no horizontal overflow at 412px and 320px, tap targets >= 44px
PASS  invalid URLs are rejected with a clear message and no request is made
PASS  TESTS 2-7, 9: link -> metadata -> captions -> moments with timestamps, score, reason, title, YouTube link
PASS  TEST 11: no fake Download/Generate-clip button when no authorised local file
PASS  edit timestamps: nudge changes the window, is marked edited and the link follows
PASS  save moment, creator ideas (3 Hindi + 3 Hinglish titles)
PASS  category filters narrow the list
PASS  transcript viewer: search, highlight, moment badges, click-through links
PASS  manual transcript correction is possible (Edit line control exists)
PASS  exports: timestamps TXT, analysis JSON, transcript TXT and SRT download real content
PASS  TEST 8: project is saved to IndexedDB and survives a reload (restore, saved moment + edit kept)
PASS  rename and delete project
PASS  History tab lists the analysed video
PASS  TEST 10: video with no captions -> honest failure, no moments, fallbacks offered
PASS  fallback: SRT file import works through the file picker input (Android picker path)
PASS  fallback: pasted timestamped Hinglish transcript is analysed
PASS  backend unreachable is explained (static hosting without backend URL)
PASS  TEST 12/PWA: manifest, installable icons, service worker active
PASS  offline: shell loads, saved projects open, transcript fetch says offline (no fake success)
PASS  settings tab renders without overflow and has install help
PASS  no uncaught JavaScript errors during the whole run
```
Spec items mapped: URL parsing, video ID extraction, transcript normalisation, SRT/VTT parsing, Hindi + Hinglish handling, timestamp maths, context detection, duplicate detection, scoring, clip boundaries, IndexedDB persistence, project restoration, mobile responsiveness, PWA (manifest, service worker, offline), failed retrieval.
