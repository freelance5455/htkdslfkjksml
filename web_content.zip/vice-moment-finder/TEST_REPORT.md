# VICE MOMENT FINDER - Test report

Run on 2026-11-20 with Node v22 and Google Chrome (headless) on Linux. These are the real outputs of the runs, not a summary from memory.

## Result

| Run | Result |
|---|---|
| Automated tests (npm test) | **63 passed, 0 failed** |
| Real-browser check (node tools/browser-check.js, phone-sized 360x740 headless Chrome) | **25 of 25 passed** |

## About the four items from the earlier project

The original files could not be recovered, so I could not look at the old code or the old 30/31 report. This is a rebuild, and I did not reproduce the original failures. What I did instead is write tests for the same kinds of problem, and all pass:

| Earlier item | What is tested now |
|---|---|
| 471 vs 472 cue count | Files of exactly 471 and 472 cues are counted exactly; same count with CRLF, BOM, no trailing newline, and missing blank lines between cues; index numbers never leak into text |
| Timestamp rounding | Fractional milliseconds (e.g. 1:00:00.999) parse exactly; starts round down and ends round up; 300 random fractional cases stay within 1 second of the true time and never inside the real cue |
| Traversal security test | 27 attack paths (../, encoded, double-encoded, backslash, null byte, dotfiles, //) plus a symlink escape test; none return any file outside public/. No test was weakened. |
| 30/31 report | Replaced by the 63-test suite below |

## What was NOT tested

- A real Android phone (Vivo V17 Pro) or other Chrome versions. The browser check is desktop Chrome emulating a 360px phone screen.
- A live deployment (nothing is deployed yet).
- Tapping "Install app" on a phone. Chrome's own install check reported no blockers and the install button appeared, but the install itself was not performed.
- Detection quality on your real streams and real Hindi/Hinglish auto-captions. Tests use synthetic 8-hour transcripts with planted moments.
- Stage B (optional AI) and Stage C (chat / video samples): not built.

## Real-browser check output

```
PASS page title
PASS engine loaded in browser
PASS no horizontal scroll at 360px - scrollWidth=360
PASS service worker active
PASS manifest parsed by Chrome - []
PASS Chrome reports no install blockers - []
PASS file name shown
PASS moments rendered from the uploaded 8-hour SRT - 3 cards
PASS open link is a real YouTube timestamp link - https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=9008s
PASS card shows "not visually verified"
PASS analysed panel explains the scope
PASS category filter chips created - All (3) | Streamer rage (1) | Police chase (2) | Car crash (1) | Viral reaction (1)
PASS filter reduces the list - 1 of 3
PASS stream-order sort is ascending - 1:00:02, 2:30:08, 3:53:16
PASS CSV export has a header and one row per moment - rank,category,moment_start,moment_end,record_start,record_en
PASS TXT export produced
PASS empty input gives a clear message
PASS transcript with no timestamps gives a clear error
PASS look-alike link is rejected
PASS link without transcript explains it cannot be analysed
PASS HTML in a transcript is shown as text and does not run
PASS app opens offline from the service worker cache
PASS offline badge shown
PASS analysis works while offline
PASS no JavaScript errors in the console

25 of 25 browser checks passed. Output: /tmp/claude-0/-home-claude/b5f26238-5c34-5fb8-b4fe-f118704243a3/scratchpad/browser
```

## Full automated test output

```
100k-cue file: 8.2 MB, 104702 cues, parse+analyse 463 ms
✔ parseTimestamp: all supported shapes (0.968308ms)
✔ parseTimestamp: rejects invalid values (0.194329ms)
✔ formatTime: always H:MM:SS and floors fractions (0.098708ms)
✔ SRT: 471 and 472 cues are counted exactly (cue-count regression) (5.903071ms)
✔ SRT: count is the same with no trailing newline, CRLF, BOM or missing blank lines (10.916018ms)
✔ SRT: index numbers never leak into cue text when blank lines are missing (0.466674ms)
✔ SRT: multi-line cues, tags and entities are cleaned (0.154042ms)
✔ SRT: fractional milliseconds survive parsing exactly (0.096743ms)
✔ SRT: out-of-order cues are sorted and a warning is given (0.623145ms)
✔ VTT: header, NOTE/STYLE blocks, ids, short timestamps and settings (0.262004ms)
✔ VTT: YouTube rolling caption repeats are merged, real repeats kept (0.238553ms)
✔ Pasted: inline timestamps, brackets, dashes and timestamp-on-its-own-line layouts (0.405926ms)
✔ Pasted: a long silence gap does not stretch a cue past 10 seconds (0.073575ms)
✔ Parsing: friendly errors for empty, binary and timestamp-less input (0.383158ms)
✔ validateFileMeta: type and size limits (0.207412ms)
✔ validateText: rejects text over the size limit (0.050987ms)
✔ extractVideoId: accepts real YouTube URL shapes (0.543871ms)
✔ extractVideoId: rejects look-alike hosts, bad ids and dangerous schemes (0.188878ms)
✔ youtubeLink: builds &t=Ns links, floors fractions, refuses bad ids (0.067472ms)
✔ Detection: finds every planted moment in an 8-hour stream, with the right category (55.882578ms)
✔ Detection: ordinary talking produces no moments (no false alarms) (20.404436ms)
✔ Detection: never pads the list with weak guesses (26.212587ms)
✔ Detection: first-pass category samples (0.633117ms)
✔ Detection: laughter markers and shouting count as evidence (0.212977ms)
✔ Detection: Hindi (Devanagari) and Hinglish words, and the language switch (1.096881ms)
✔ Detection: matched words are whole words (no matches inside other words) (0.122463ms)
✔ Detection: Object prototype names in a transcript cannot break scoring (0.065991ms)
✔ Rounding: starts floor, ends ceil, never inside the real cue (0.105911ms)
✔ Rounding: whole-second boundaries are not shifted (0.052233ms)
✔ Rounding: many random fractional times stay within one second of the truth (4.193722ms)
✔ Padding: 10, 12 and 15 seconds, and out-of-range values are clamped to 10-15 (0.258922ms)
✔ Padding: the window never starts before 0:00:00 or ends after the transcript (0.076178ms)
✔ Padding: a recording window is about 24 seconds longer than the moment (37.984765ms)
✔ Honesty: every moment start/end is a real cue time; nothing is claimed as visually verified (37.02304ms)
✔ Honesty: with no video link, no link is invented (0.280634ms)
✔ Duplicates: nearby hits become one moment, distant hits stay separate (0.170743ms)
✔ Duplicates: mergeMoments merges overlapping and keeps the best score (0.167522ms)
✔ Chunking: a moment on a chunk boundary appears once; chunk size does not lose moments (83.015934ms)
✔ Ranking: moments are returned best first with ranks 1..N and a count limit (21.546168ms)
✔ Options: count is clamped to 1-50 and bad input falls back to defaults (84.490942ms)
✔ End to end: 8-hour SRT and VTT files give the same moments as the raw cues (159.296511ms)
✔ Large file: 100,000 cues parse and analyse in a few seconds (520.092874ms)
✔ Large file: more cues than the limit is refused with a clear message (220.703245ms)
✔ Export TXT: includes times, links and the honest scope line (29.580943ms)
✔ Export CSV: correct columns and row count; commas, quotes, newlines and Hindi round-trip (0.556249ms)
✔ Export CSV: spreadsheet formula injection is neutralised (0.274971ms)
✔ Server: serves the app files with correct types (23.521597ms)
✔ Server: security headers are present (2.108741ms)
✔ Server: path traversal is blocked (nothing outside public/ is ever returned) (8.600894ms)
✔ Server: malformed URLs, directories and unknown types are rejected (5.478256ms)
✔ Server: only GET and HEAD are allowed (2.38911ms)
✔ Server: a symlink inside public/ cannot be used to read files outside it (7.257441ms)
✔ Server: resolveSegments unit checks (0.679336ms)
✔ Server: the code holds no hard-coded keys or secrets (0.232849ms)
✔ PWA: manifest has the fields Chrome needs to offer installation (1.049038ms)
✔ PWA: every file the service worker caches exists (0.330604ms)
✔ PWA: index.html links the manifest, icons, viewport and scripts (0.151947ms)
✔ Dashboard: all required controls exist (0.955729ms)
✔ Security: browser code never uses innerHTML, eval or document.write (0.527686ms)
✔ Security: no inline scripts or inline event handlers; strict page security policy (0.376719ms)
✔ Security: external links open safely and the app makes no network requests of its own (0.437167ms)
✔ Security: no API keys or secrets in any shipped file (0.469389ms)
✔ Security: the _headers file policy matches the server policy (2.152465ms)
ℹ tests 63
ℹ suites 0
ℹ pass 63
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1545.094924
```
