// VICE MOMENT FINDER backend: zero dependencies. Serves the PWA and two small JSON endpoints.
//   GET /api/health
//   GET /api/meta?v=<videoId>
//   GET /api/transcript?v=<videoId>&lang=auto|hi|en   (optional header x-yt-access-token for your own videos)
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { CaptionError, config, getMeta, getTranscript } from './captions.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const VERSION = '1.0.0';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};

export function createServer({ fetchImpl = fetch, env = process.env, rateLimit = 40 } = {}) {
  const hits = new Map(); // ip -> [timestamps]
  const allowOrigin = env.ALLOWED_ORIGIN || '*';

  const limited = (ip) => {
    const now = Date.now();
    const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
    arr.push(now);
    hits.set(ip, arr);
    if (hits.size > 5000) hits.clear();
    return arr.length > rateLimit;
  };

  const json = (res, status, body) => {
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'access-control-allow-origin': allowOrigin,
      'access-control-allow-headers': 'x-yt-access-token, content-type',
      'x-content-type-options': 'nosniff',
    });
    res.end(JSON.stringify(body));
  };

  async function api(req, res, url) {
    if (req.method === 'OPTIONS') return json(res, 204, {});
    if (req.method !== 'GET') return json(res, 405, { ok: false, error: { code: 'METHOD', message: 'GET only.' } });
    const ip = req.socket.remoteAddress || 'unknown';
    if (url.pathname !== '/api/health' && limited(ip)) {
      return json(res, 429, { ok: false, error: { code: 'RATE_LIMIT', message: 'Too many requests. Wait a minute and retry.', hint: '' } });
    }
    try {
      if (url.pathname === '/api/health') {
        return json(res, 200, { ok: true, version: VERSION, capabilities: config(env) });
      }
      const v = url.searchParams.get('v') || '';
      if (url.pathname === '/api/meta') return json(res, 200, { ok: true, meta: await getMeta(v, { fetchImpl }) });
      if (url.pathname === '/api/transcript') {
        const lang = (url.searchParams.get('lang') || 'auto').slice(0, 12).replace(/[^A-Za-z-]/g, '') || 'auto';
        const token = req.headers['x-yt-access-token'];
        const out = await getTranscript(v, { lang, accessToken: typeof token === 'string' ? token : undefined, fetchImpl, env });
        return json(res, out.ok ? 200 : (out.error.code === 'INVALID_URL' ? 400 : 200), out);
      }
      return json(res, 404, { ok: false, error: { code: 'NOT_FOUND', message: 'Unknown endpoint.' } });
    } catch (err) {
      if (err instanceof CaptionError) return json(res, err.status, { ok: false, error: err.toJSON() });
      return json(res, 500, { ok: false, error: { code: 'SERVER_ERROR', message: 'Unexpected server error.', hint: 'Try again.' } });
    }
  }

  async function serveStatic(req, res, url) {
    let rel = decodeURIComponent(url.pathname);
    if (rel.endsWith('/')) rel += 'index.html';
    const file = path.resolve(ROOT, `.${rel}`);
    if (file !== ROOT && !file.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
    try {
      const st = await stat(file);
      if (!st.isFile()) throw new Error('not a file');
      const body = await readFile(file);
      const ext = path.extname(file).toLowerCase();
      res.writeHead(200, {
        'content-type': MIME[ext] || 'application/octet-stream',
        'cache-control': file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=300',
        'x-content-type-options': 'nosniff',
      });
      res.end(req.method === 'HEAD' ? undefined : body);
    } catch {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('Not found');
    }
  }

  return http.createServer((req, res) => {
    let url;
    try { url = new URL(req.url, 'http://localhost'); } catch { res.writeHead(400); return res.end('Bad request'); }
    if (url.pathname.startsWith('/api/')) return api(req, res, url);
    return serveStatic(req, res, url);
  });
}

// Run directly: node server/server.js
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT) || 8080;
  const host = process.env.HOST || '0.0.0.0';
  createServer().listen(port, host, () => {
    const cfg = config();
    console.log(`VICE MOMENT FINDER v${VERSION}`);
    console.log(`Open on this device:  http://localhost:${port}`);
    console.log(`Public captions: ${cfg.publicCaptions ? 'ON (unofficial, may be blocked)' : 'OFF'}`);
    console.log('Press Ctrl+C to stop.');
  });
}
