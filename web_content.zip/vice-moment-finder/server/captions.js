// Transcript + metadata acquisition. Modular providers, honest failure reasons, never fabricates text.
//
// Providers (tried in this order):
//   1. owner-api       Official YouTube Data API v3 captions.list / captions.download. Needs the person's own
//                      OAuth access token and only works for videos they own or may edit (Google's rule).
//   2. public-captions The same caption tracks the public YouTube player offers for public videos.
//                      NOT an official API: it can break, may be blocked on data-centre IPs, and is switchable
//                      off with PUBLIC_CAPTIONS=off.
//
// All network access goes through an injectable fetch so tests can run without touching YouTube.
import { parseJson3, parseSRT, parseTimedTextXml, normalizeSegments } from '../public/js/transcript.js';

const UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';
const ID_RE = /^[A-Za-z0-9_-]{11}$/;

export class CaptionError extends Error {
  constructor(code, message, hint = '', status = 502) {
    super(message);
    this.code = code;
    this.hint = hint;
    this.status = status;
  }
  toJSON() { return { code: this.code, message: this.message, hint: this.hint }; }
}

const wrapNetwork = async (fn) => {
  try { return await fn(); } catch (err) {
    if (err instanceof CaptionError) throw err;
    const timedOut = err?.name === 'TimeoutError' || err?.name === 'AbortError';
    throw new CaptionError('NETWORK', timedOut ? 'YouTube did not answer in time.' : `Could not reach YouTube (${err?.cause?.code || err?.message || 'network error'}).`, 'Check your connection and press Retry.', 504);
  }
};

/* ---------- player response extraction (pure) ---------- */

/** Pull the JSON object assigned to ytInitialPlayerResponse out of a watch-page HTML string. */
export function extractPlayerResponse(html) {
  const marker = 'ytInitialPlayerResponse';
  let idx = html.indexOf(marker);
  while (idx !== -1) {
    const eq = html.indexOf('=', idx + marker.length);
    const brace = eq === -1 ? -1 : html.indexOf('{', eq);
    if (brace !== -1 && brace - eq < 6) {
      let depth = 0;
      let inStr = false;
      let esc = false;
      for (let i = brace; i < html.length; i++) {
        const c = html[i];
        if (inStr) {
          if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false;
        } else if (c === '"') inStr = true;
        else if (c === '{') depth++;
        else if (c === '}' && --depth === 0) {
          try { return JSON.parse(html.slice(brace, i + 1)); } catch { break; }
        }
      }
    }
    idx = html.indexOf(marker, idx + marker.length);
  }
  return null;
}

export function tracksFromPlayerResponse(pr) {
  const list = pr?.captions?.playerCaptionsTracklistRenderer?.captionTracks || [];
  return list.map((t) => ({
    lang: t.languageCode,
    name: t.name?.simpleText || t.name?.runs?.map((r) => r.text).join('') || t.languageCode,
    kind: t.kind === 'asr' ? 'asr' : 'manual',
    baseUrl: t.baseUrl,
  })).filter((t) => t.lang && t.baseUrl);
}

/** Preference: manual in wanted language > auto in wanted language > manual hi/en > auto hi/en > first. */
export function pickTrack(tracks, preferred = 'auto') {
  if (!tracks.length) return null;
  const base = (l) => String(l || '').toLowerCase().split('-')[0];
  const want = preferred && preferred !== 'auto' ? [base(preferred)] : [];
  const order = [...want, 'hi', 'en'];
  for (const lang of order) {
    const m = tracks.find((t) => base(t.lang) === lang && t.kind === 'manual');
    if (m) return m;
    const a = tracks.find((t) => base(t.lang) === lang && t.kind === 'asr');
    if (a) return a;
    if (want.length && lang === want[0]) return null; // explicit language requested but missing
  }
  return tracks[0];
}

export function playabilityError(pr) {
  const ps = pr?.playabilityStatus;
  if (!ps || ps.status === 'OK') return null;
  const reason = ps.reason || ps.messages?.join(' ') || '';
  if (/not a bot|sign in to confirm|confirm you.?re not/i.test(reason)) {
    return new CaptionError('BOT_CHECK', 'YouTube asked this server to prove it is not a bot, so captions were not served.', 'This happens a lot on cloud servers. Run the backend on your own phone (Termux) or paste/import the transcript instead.', 429);
  }
  if (ps.status === 'LOGIN_REQUIRED') {
    return new CaptionError('LOGIN_REQUIRED', `This video needs a signed-in account (${reason || 'age or privacy restriction'}).`, 'If it is your own video, use the owner OAuth token option; otherwise paste or import the transcript.', 403);
  }
  return new CaptionError('VIDEO_UNAVAILABLE', `Video unavailable${reason ? `: ${reason}` : '.'}`, 'Check that the link is public and still exists.', 404);
}

/* ---------- providers ---------- */

async function getText(fetchImpl, url, init = {}, timeoutMs = 12000) {
  const res = await wrapNetwork(() => fetchImpl(url, { ...init, signal: AbortSignal.timeout(timeoutMs) }));
  return { res, text: await wrapNetwork(() => res.text()) };
}

export async function publicCaptionsProvider(videoId, { lang = 'auto', fetchImpl = fetch } = {}) {
  const { res, text: html } = await getText(fetchImpl, `https://www.youtube.com/watch?v=${videoId}&hl=en&bpctr=9999999999&has_verified=1`, {
    headers: { 'user-agent': UA, 'accept-language': 'en-US,en;q=0.9', cookie: 'CONSENT=YES+1; SOCS=CAI' },
  });
  if (!res.ok) throw new CaptionError('NETWORK', `YouTube answered with HTTP ${res.status}.`, 'Try again in a moment.', 502);
  if (/consent\.youtube\.com|before you continue to youtube/i.test(html) && !html.includes('ytInitialPlayerResponse')) {
    throw new CaptionError('CONSENT_WALL', 'YouTube showed a cookie-consent page instead of the video.', 'Open the video once in your browser, or paste/import the transcript.', 502);
  }
  const pr = extractPlayerResponse(html);
  if (!pr) throw new CaptionError('PAGE_FORMAT', 'Could not read video data from the YouTube page (its format may have changed).', 'Update the app or paste/import the transcript.', 502);
  const pe = playabilityError(pr);
  if (pe) throw pe;

  const details = pr.videoDetails || {};
  const meta = {
    id: videoId,
    title: details.title || '',
    channel: details.author || '',
    durationSec: details.lengthSeconds ? Number(details.lengthSeconds) : null,
    isLive: Boolean(details.isLiveContent && details.isLive),
    thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    url: `https://www.youtube.com/watch?v=${videoId}`,
  };
  const tracks = tracksFromPlayerResponse(pr);
  if (!tracks.length) {
    throw Object.assign(new CaptionError('NO_CAPTIONS', 'This video has no captions available (the owner has not enabled them and YouTube has not generated automatic ones).', 'Paste the transcript or import an SRT/VTT file instead.', 404), { meta });
  }
  const chosen = pickTrack(tracks, lang);
  if (!chosen) {
    throw Object.assign(new CaptionError('LANG_NOT_AVAILABLE', `No caption track in "${lang}". Available: ${tracks.map((t) => `${t.lang}${t.kind === 'asr' ? ' (auto)' : ''}`).join(', ')}.`, 'Choose another language or use Auto.', 404), { meta, availableTracks: tracks.map(({ baseUrl, ...r }) => r) });
  }

  const trackUrl = new URL(chosen.baseUrl);
  if (!/(^|\.)youtube\.com$/.test(trackUrl.hostname)) throw new CaptionError('PAGE_FORMAT', 'Unexpected caption address; refusing to fetch it.', '', 502);
  trackUrl.searchParams.set('fmt', 'json3');
  const { res: cres, text: body } = await getText(fetchImpl, trackUrl.toString(), { headers: { 'user-agent': UA, 'accept-language': 'en-US,en;q=0.9', cookie: 'CONSENT=YES+1' } });
  if (!cres.ok || !body.trim()) {
    throw Object.assign(new CaptionError('CAPTIONS_BLOCKED', `YouTube listed captions but did not serve them (HTTP ${cres.status}${body.trim() ? '' : ', empty body'}).`, 'This is common from cloud IPs. Run the backend on your phone (Termux) or paste/import the transcript.', 502), { meta });
  }
  let segments = [];
  try { segments = parseJson3(body); } catch { segments = parseTimedTextXml(body); }
  segments = normalizeSegments(segments);
  if (!segments.length) throw Object.assign(new CaptionError('CAPTIONS_EMPTY', 'The caption track was empty.', 'Paste or import a transcript instead.', 502), { meta });

  return {
    source: 'public-captions',
    meta,
    track: { lang: chosen.lang, name: chosen.name, kind: chosen.kind },
    availableTracks: tracks.map(({ baseUrl, ...r }) => r),
    segments,
  };
}

/** Official API: only for videos the signed-in person may edit. Token comes per request and is never stored. */
export async function ownerApiProvider(videoId, { lang = 'auto', accessToken, fetchImpl = fetch } = {}) {
  if (!accessToken) throw new CaptionError('NO_TOKEN', 'No OAuth token supplied.', '', 401);
  const auth = { authorization: `Bearer ${accessToken}` };
  const { res, text } = await getText(fetchImpl, `https://www.googleapis.com/youtube/v3/captions?part=snippet&videoId=${videoId}`, { headers: auth });
  if (res.status === 401) throw new CaptionError('TOKEN_INVALID', 'Google rejected the OAuth token (it may have expired - they last about an hour).', 'Create a new token and paste it in Settings.', 401);
  if (res.status === 403) throw new CaptionError('CAPTION_ACCESS_DENIED', 'Caption access denied: the official API only lets you download captions of videos you own or can edit.', 'For other videos use public captions or paste/import the transcript.', 403);
  if (!res.ok) throw new CaptionError('OWNER_API_FAILED', `YouTube API error (HTTP ${res.status}).`, '', 502);
  let items = [];
  try { items = JSON.parse(text).items || []; } catch { /* handled below */ }
  const tracks = items.map((i) => ({ id: i.id, lang: i.snippet?.language, name: i.snippet?.name || i.snippet?.language, kind: i.snippet?.trackKind === 'ASR' ? 'asr' : 'manual' })).filter((t) => t.id && t.lang);
  if (!tracks.length) throw new CaptionError('NO_CAPTIONS', 'This video has no caption tracks.', 'Paste or import a transcript instead.', 404);
  const chosen = pickTrack(tracks.map((t) => ({ ...t, baseUrl: t.id })), lang);
  if (!chosen) throw new CaptionError('LANG_NOT_AVAILABLE', `No caption track in "${lang}".`, 'Choose another language or Auto.', 404);
  const { res: dres, text: srt } = await getText(fetchImpl, `https://www.googleapis.com/youtube/v3/captions/${encodeURIComponent(chosen.id)}?tfmt=srt`, { headers: auth });
  if (dres.status === 403) throw new CaptionError('CAPTION_ACCESS_DENIED', 'Caption download denied for this video (you must own it or have edit rights).', '', 403);
  if (!dres.ok) throw new CaptionError('OWNER_API_FAILED', `Caption download failed (HTTP ${dres.status}).`, '', 502);
  const segments = normalizeSegments(parseSRT(srt));
  if (!segments.length) throw new CaptionError('CAPTIONS_EMPTY', 'The caption track was empty.', '', 502);
  return {
    source: 'owner-api',
    meta: { id: videoId },
    track: { lang: chosen.lang, name: chosen.name, kind: chosen.kind },
    availableTracks: tracks.map(({ id, ...r }) => r),
    segments,
  };
}

/** Official oEmbed (no key needed): title, channel, thumbnail. No duration. */
export async function oembedMeta(videoId, { fetchImpl = fetch } = {}) {
  const url = `https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}&format=json`;
  const { res, text } = await getText(fetchImpl, url, { headers: { 'user-agent': UA } }, 8000);
  if (res.status === 404 || res.status === 401 || res.status === 403) {
    throw new CaptionError('VIDEO_UNAVAILABLE', 'Video unavailable: it may be private, removed or not embeddable.', 'Check that the link is public.', 404);
  }
  if (!res.ok) throw new CaptionError('NETWORK', `YouTube answered with HTTP ${res.status}.`, '', 502);
  const j = JSON.parse(text);
  return {
    id: videoId, title: j.title || '', channel: j.author_name || '', durationSec: null,
    thumbnail: j.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    url: `https://www.youtube.com/watch?v=${videoId}`,
  };
}

/* ---------- orchestration ---------- */

export function config(env = process.env) {
  return {
    publicCaptions: String(env.PUBLIC_CAPTIONS || 'on').toLowerCase() !== 'off',
    ownerApi: true,
  };
}

/**
 * Try providers in order. Returns { ok:true, ... } or { ok:false, error, tried:[...] }.
 * The error shown is the most informative one (a specific reason beats a generic one).
 */
export async function getTranscript(videoId, { lang = 'auto', accessToken, fetchImpl = fetch, env = process.env } = {}) {
  if (!ID_RE.test(videoId || '')) return { ok: false, error: new CaptionError('INVALID_URL', 'Invalid video id.', '', 400).toJSON(), tried: [] };
  const cfg = config(env);
  const tried = [];
  let best = null;
  let meta = null;
  const remember = (err, source) => {
    tried.push({ source, code: err.code, message: err.message });
    if (err.meta) meta = err.meta;
    const rank = { VIDEO_UNAVAILABLE: 5, NO_CAPTIONS: 5, LANG_NOT_AVAILABLE: 5, BOT_CHECK: 4, LOGIN_REQUIRED: 4, CAPTIONS_BLOCKED: 4, CAPTION_ACCESS_DENIED: 3, TOKEN_INVALID: 3 };
    if (!best || (rank[err.code] || 1) > (rank[best.code] || 1)) best = err;
  };

  if (accessToken) {
    try { return { ok: true, ...(await ownerApiProvider(videoId, { lang, accessToken, fetchImpl })), tried }; } catch (err) { remember(err, 'owner-api'); }
  }
  if (cfg.publicCaptions) {
    try { return { ok: true, ...(await publicCaptionsProvider(videoId, { lang, fetchImpl })), tried }; } catch (err) { remember(err, 'public-captions'); }
  } else {
    tried.push({ source: 'public-captions', code: 'DISABLED', message: 'Public caption retrieval is switched off on this server (PUBLIC_CAPTIONS=off).' });
  }
  if (!best) best = new CaptionError('NO_PROVIDER', 'No automatic transcript source is enabled on this server.', 'Paste or import the transcript instead, or enable PUBLIC_CAPTIONS.', 501);
  return { ok: false, error: best.toJSON ? best.toJSON() : { code: 'FAILED', message: String(best.message) }, tried, meta };
}

export async function getMeta(videoId, { fetchImpl = fetch } = {}) {
  if (!ID_RE.test(videoId || '')) throw new CaptionError('INVALID_URL', 'Invalid video id.', '', 400);
  return oembedMeta(videoId, { fetchImpl });
}
