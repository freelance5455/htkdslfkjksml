'use strict';
// Helpers that build fake livestream transcripts for the tests.

function pad(n, w) {
  return String(n).padStart(w, '0');
}

function srtTime(ms) {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return pad(h, 2) + ':' + pad(m, 2) + ':' + pad(s, 2) + ',' + pad(ms % 1000, 3);
}

function vttTime(ms) {
  return srtTime(ms).replace(',', '.');
}

function makeSrt(cues, opts) {
  const o = opts || {};
  const eol = o.eol || '\n';
  const parts = cues.map((c, i) => i + 1 + eol + srtTime(c.startMs) + ' --> ' + srtTime(c.endMs) + eol + c.text);
  return parts.join(o.noBlankLines ? eol : eol + eol) + (o.trailingNewline === false ? '' : eol);
}

function makeVtt(cues) {
  return 'WEBVTT\n\n' + cues.map((c, i) => 'cue' + i + '\n' + vttTime(c.startMs) + ' --> ' + vttTime(c.endMs) + ' align:start\n' + c.text).join('\n\n') + '\n';
}

// Neutral sentences that contain none of the words the detector looks for.
const FILLER = [
  'so we are going to the shop to buy some food now',
  'let me check the map for a second',
  'okay the next mission is at the pier',
  'I think we should take the left road here',
  'the weather is nice in the city today',
  'welcome back everyone thanks for joining the stream',
  'we need to save some money before the weekend',
  'this building has a really nice view of the water',
  'give me a moment while I change the radio station',
  'alright I will park the car near the garage',
  'the shop owner is talking about the delivery',
  'let us finish this job and then take a short break',
];

function makeStream(opts) {
  const o = opts || {};
  const durationMs = (o.hours || 8) * 3600000;
  const planted = (o.planted || []).slice().sort((a, b) => a.atMs - b.atMs);
  const cues = [];
  let t = 0;
  let seed = 12345;
  const rnd = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  let pi = 0;
  let k = 0;
  while (t < durationMs) {
    if (pi < planted.length && t >= planted[pi].atMs) {
      const p = planted[pi++];
      let at = p.atMs;
      for (const line of p.lines) {
        cues.push({ startMs: at, endMs: at + (line.durMs || 2500), text: line.text });
        at += (line.durMs || 2500) + 300;
      }
      t = Math.max(t, at);
      continue;
    }
    const dur = 2000 + Math.floor(rnd() * 2500);
    cues.push({ startMs: t, endMs: t + dur, text: FILLER[k++ % FILLER.length] });
    t += dur + 200;
  }
  return cues;
}

module.exports = { srtTime, vttTime, makeSrt, makeVtt, makeStream, FILLER };
