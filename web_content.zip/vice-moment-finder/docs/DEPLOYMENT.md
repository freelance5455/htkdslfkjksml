# Deployment and free configuration

There are two parts: the **frontend** (static files in `public/`) and the **backend** (`server/server.js`, plain Node 18+, no packages). The backend also serves the frontend, so one process is enough.

## Option A (recommended): run it on your phone
See ANDROID_SETUP.md. Cost: Rs 0. Best chance of working because requests come from your own home/mobile connection.

## Option B: static frontend on free hosting + backend elsewhere
1. Upload the **contents of `public/`** to any free static host (GitHub Pages, Cloudflare Pages, Netlify, etc.). Free plans and limits change, so check the host's current terms.
2. Open the hosted app -> **Settings -> Backend URL** and enter where your backend runs (for example `http://localhost:8080` while Termux is running).
3. If the backend is on a different address, set `ALLOWED_ORIGIN=https://your-frontend-address` before starting it (default is `*`).

Without any backend the hosted app still works fully for **pasted / imported transcripts**, saved projects and offline use. Only automatic fetching needs the backend.

## Option C: a free cloud host for the backend
Any host that can run `node server/server.js` works (`PORT` is respected). Be realistic:
- Free tiers change and sleep when idle; check the provider's pricing page yourself. No free tier is promised here.
- **YouTube frequently refuses requests from data-centre IPs** ("confirm you are not a bot"). The app reports this as `BOT_CHECK` and falls back to paste/import. Phone hosting avoids most of this.

## Environment variables
| Name | Default | Meaning |
|---|---|---|
| `PORT` | 8080 | Port |
| `HOST` | 0.0.0.0 | Bind address (use `127.0.0.1` to keep it private) |
| `PUBLIC_CAPTIONS` | on | `off` disables the unofficial public-caption provider (only the official owner API remains) |
| `ALLOWED_ORIGIN` | * | CORS origin for a separately hosted frontend |

## Where captions come from (important, read once)
1. **Official YouTube Data API (owner-api).** Works only for videos **you own or can edit** (Google's rule). Needs a Google OAuth *access token*:
   1. Go to https://developers.google.com/oauthplayground
   2. In "Step 1" enter the scope `https://www.googleapis.com/auth/youtube.force-ssl`, click **Authorize APIs**, sign in with the channel's Google account.
   3. Click **Exchange authorization code for tokens** and copy the **Access token** (starts `ya29.`).
   4. Paste it in **Settings -> Google OAuth access token**. It expires in about an hour; repeat when needed.
   The token stays in your browser and is sent only to your own backend, which forwards it to Google for that request. It is never stored on the server.
2. **Public captions (public-captions).** The same caption tracks the YouTube player shows for public videos. This is **not an official API**: it can break when YouTube changes its pages, may be blocked, and you are responsible for using it within YouTube's terms and only on videos you are entitled to analyse. Turn it off with `PUBLIC_CAPTIONS=off`.
3. **Manual**: paste text or import SRT / VTT / TXT. Always available, works offline.

If none works, the app says why and never invents transcript text.

## Updating
Replace the files and restart. The service worker updates the cached app shell automatically (bump `CACHE` in `public/sw.js` if you change shell files and want to force it).
