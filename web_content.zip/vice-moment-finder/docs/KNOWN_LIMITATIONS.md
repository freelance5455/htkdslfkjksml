# Known limitations (honest list)

1. **Live YouTube retrieval was not verified in the build environment** (it has no access to YouTube). Retrieval logic is tested against simulated YouTube responses only. Run `npm run live -- <link>` on your phone to confirm. YouTube can change its pages at any time and break the unofficial public-caption provider.
2. **Not tested on a real Android phone.** Tests ran in desktop Chromium emulating an Android Chrome profile (screen size, touch, user-agent). Please try it on your Vivo V17 Pro and report problems.
3. **No official API gives captions of other people's videos.** The official route is owner-only. Everything else is best effort.
4. **Videos without captions cannot be analysed** unless you import a transcript. The app does not do speech-to-text (that needs large models or paid services).
5. **Auto-generated Hindi captions are imperfect** (Hindi in Latin or Devanagari script, missed words, no laughter markers). Detection quality follows caption quality. Gameplay events that nobody speaks about are invisible to a transcript-only engine.
6. **The engine is rule-based**, tuned with a synthetic Hinglish GTA fixture. It found all planted moments there; real streams are messier. The score is only a ranking aid and does **not** predict views.
7. **Audio analysis** needs a local file you supply, runs in the browser (large files may be slow/heavy on a phone), measures loudness only and can only re-rank moments already found. It cannot reliably tell shouting from music.
8. **Clipping**: the app never downloads from YouTube. Clip commands are offered only after you attach your own file and confirm you have the rights; the app produces an FFmpeg command, it does not run FFmpeg on your phone.
9. **"Play here"** uses YouTube's embedded player, which some videos disallow; the "Preview on YouTube" link always works.
10. **Phone hosting**: Termux must stay running; Android may stop it in the background without a wakelock.
11. Offline mode keeps the app, saved projects and transcripts. Fetching a new transcript needs internet.
12. No APK is included. If you package the PWA with a converter, point it at a hosted or localhost URL; test the result yourself.
