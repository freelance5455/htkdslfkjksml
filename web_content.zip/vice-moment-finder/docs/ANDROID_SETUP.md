# Android setup (beginner, free, ~10 minutes)

The most reliable way is to run the small backend **on your own phone** with Termux. YouTube often blocks cloud servers but rarely blocks a phone on your normal internet.

## 1. Install Termux
Install **Termux from F-Droid** (f-droid.org). The Play Store version is outdated and will not work well.

## 2. Install Node.js
Open Termux and paste, one line at a time:
```
pkg update -y
pkg install -y nodejs unzip
termux-setup-storage
```
Tap **Allow** when Android asks for storage access.

## 3. Put the app on your phone
1. Download the ZIP (`VICE-MOMENT-FINDER-v1.0.0.zip`) to your phone's **Downloads** folder.
2. In Termux:
```
cd ~
unzip ~/storage/downloads/VICE-MOMENT-FINDER-v1.0.0.zip
cd vice-moment-finder
npm start
```
You should see `Open on this device: http://localhost:8080`.

## 4. Use it
1. Open **Chrome** and go to `http://localhost:8080`.
2. Chrome menu (three dots) -> **Install app** (or Add to Home screen).
3. Keep Termux running in the background (pull down the notification and tap **Acquire wakelock**, so Android does not stop it).
4. Next time: open Termux, run `cd ~/vice-moment-finder && npm start`, then open the app.

## 5. Daily workflow
1. Copy your replay link from YouTube, open VICE MOMENT FINDER, tap **Paste**, then **Analyse video**.
2. Open each moment with **Preview on YouTube**, screen-record, edit in VN Editor.
3. Tap **Save moment** on the good ones. Everything is saved on your phone.

## If the transcript cannot be fetched
The app tells you the exact reason and gives you these fallbacks:
- **Retry**.
- **Open video on YouTube** -> description -> **Show transcript** -> copy -> paste into the app.
- Import a `.srt` / `.vtt` / `.txt` file (button *Choose transcript file*).

## Check your setup (optional)
```
npm run live -- https://youtu.be/YOUR_VIDEO_ID
```
Shows whether metadata and captions really come through, and how many moments are found.

## Tips
- Live replays only have captions after YouTube has finished processing them (can take hours after a stream ends). Hindi auto-captions are often imperfect; the engine tolerates that but timestamps and wording follow the captions.
- To stop the server press **Ctrl+C** in Termux (volume-down + C).
