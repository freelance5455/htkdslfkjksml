// REAL YouTube check (run this on your own phone/PC, it needs internet):  npm run live -- <youtube link>
// Prints what the backend can actually retrieve for that video. Nothing is simulated here.
import { parseYouTubeUrl } from '../public/js/url.js';
import { getMeta, getTranscript } from '../server/captions.js';
import { analyzeTranscript } from '../public/js/engine.js';
import { fmtTime } from '../public/js/util.js';

const parsed = parseYouTubeUrl(process.argv[2] || '');
if (!parsed.ok) { console.error(`Bad link: ${parsed.message}\nUsage: npm run live -- https://youtu.be/XXXXXXXXXXX`); process.exit(2); }
console.log(`Video ID: ${parsed.id}`);
try { const m = await getMeta(parsed.id); console.log(`Metadata: OK  "${m.title}" by ${m.channel}`); } catch (e) { console.log(`Metadata: FAILED  ${e.code || ''} ${e.message}`); }
const t = await getTranscript(parsed.id, { lang: process.env.LANG_PREF || 'auto', accessToken: process.env.YT_TOKEN });
if (!t.ok) {
  console.log(`Transcript: FAILED  ${t.error.code}: ${t.error.message}`);
  if (t.error.hint) console.log(`  Hint: ${t.error.hint}`);
  for (const x of t.tried) console.log(`  tried ${x.source}: ${x.code}`);
  process.exit(1);
}
console.log(`Transcript: OK  source=${t.source} track=${t.track.lang}${t.track.kind === 'asr' ? ' (auto)' : ''} lines=${t.segments.length}`);
const a = analyzeTranscript(t.segments, { maxMoments: 10 }, { game: 'GTA' });
console.log(`Moments found: ${a.moments.length}`);
for (const m of a.moments) console.log(`  #${String(m.rank).padStart(2, '0')} ${fmtTime(m.start)} - ${fmtTime(m.end)}  ${m.score}/100  ${m.categoryLabel}  "${m.excerpt.slice(0, 60)}"`);
