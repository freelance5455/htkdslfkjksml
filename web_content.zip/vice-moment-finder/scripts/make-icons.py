#!/usr/bin/env python3
"""Generate the PNG app icons (needs Pillow). Run: python3 scripts/make-icons.py"""
from PIL import Image, ImageDraw
import os
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'icons')

def lerp(a, b, t): return tuple(int(a[i] + (b[i]-a[i])*t) for i in range(3))
PINK, CYAN, BG = (255, 43, 214), (25, 227, 255), (11, 11, 18)

def make(size, maskable=False):
    S = size * 4  # supersample
    img = Image.new('RGB', (S, S), BG)
    d = ImageDraw.Draw(img)
    scale = 0.62 if maskable else 1.0  # keep the mark inside the maskable safe zone
    def P(x, y):
        c = S/2
        return (c + (x/512*S - c)*scale, c + (y/512*S - c)*scale)
    pts = [P(118, 150), P(256, 380), P(394, 150)]
    w = int(58/512*S*scale)
    steps = 120
    for seg in range(2):
        a, b = pts[seg], pts[seg+1]
        for i in range(steps):
            t = i/steps
            x, y = a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t
            col = lerp(PINK, CYAN, (seg*steps+i)/(2*steps))
            d.ellipse((x-w/2, y-w/2, x+w/2, y+w/2), fill=col)
    cx, cy = P(256, 420)
    r = 16/512*S*scale
    d.ellipse((cx-r, cy-r, cx+r, cy+r), fill=CYAN)
    img = img.resize((size, size), Image.LANCZOS)
    if not maskable:  # rounded corners for "any" icons
        mask = Image.new('L', (size*4, size*4), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, size*4, size*4), radius=int(size*4*0.22), fill=255)
        mask = mask.resize((size, size), Image.LANCZOS)
        out = Image.new('RGBA', (size, size), (0, 0, 0, 0)); out.paste(img, (0, 0), mask); return out
    return img.convert('RGBA')

make(192).save(os.path.join(OUT, 'icon-192.png'))
make(512).save(os.path.join(OUT, 'icon-512.png'))
make(512, maskable=True).save(os.path.join(OUT, 'icon-maskable-512.png'))
print('icons written')
