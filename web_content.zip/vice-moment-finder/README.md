# VICE MOMENT FINDER

Finds entertaining moments in long GTA livestream replays, **from a transcript**, and gives you exact YouTube timestamps. It runs on your phone in Chrome, costs nothing, and uploads nothing.

> **Important honesty notes**
> - This is a **rebuild**. The original project files could not be recovered, so this is not the old code. I could not inspect the old bugs; the tests below guard against the same *kinds* of problems.
> - **Stage A only** is built: free transcript analysis + installable PWA. Stage B (optional AI) and Stage C (chat / video samples) are **not built yet**.
> - It analyses **transcript wording only**. It cannot watch the video. Visual events (glitches, crashes) are guessed from what the streamer said.
> - It has been tested with automated tests and a phone-sized headless Chrome, but **not on a real Vivo V17 Pro**, and it is **not deployed anywhere yet**.

## What is in this folder

```
vice-moment-finder/
  public/            <- THE APP. This is the only folder you need to host.
    index.html       page layout
    styles.css       neon charcoal/pink/purple/cyan theme
    app.js           buttons, results, copy, export
    engine.js        the analysis engine (parsing, scoring, timestamps, links, export)
    sw.js            service worker (offline support)
    manifest.webmanifest, favicon.svg, icons/   install-as-app files
    _headers         security headers for Netlify / Cloudflare Pages
  server.js          optional tiny server (only serves public/)
  test/ testkit/     automated tests (63 tests)
  tools/             icon maker + real-browser check (optional)
  package.json       test/start commands
  TEST_REPORT.md     results of the test runs
```

## How to use it (workflow)

1. Open the app in Chrome.
2. Paste the replay link (only used to build clickable timestamps).
3. Choose a transcript file (.srt, .vtt, .txt) or paste a timestamped transcript.
4. Pick language (Auto is fine), number of moments (10-50) and record padding (10-15 s).
5. Tap **Analyse**.
6. For each moment: **Open in YouTube**, **Copy time**, **Copy record window**, **Copy description**.
7. Screen-record the window, edit in VN Editor, publish.

Each result shows: moment start/end, record start/end (with padding), category, a short quote of what was said, why it may be entertaining, a confidence score and the evidence. Confidence is a rough guide from the words only and never goes above 92%.

**Getting a transcript** (a YouTube link alone cannot be analysed, because YouTube does not let this app read the video):
- Your own stream: YouTube Studio (open in Chrome, menu ⋮, "Desktop site"), open the video, Subtitles; look for an .srt / .vtt download.
- Any video with a transcript: on the YouTube website tap "...more", then "Show transcript", select the text, copy, paste into the app. May not work for every video or phone.
- Auto-captions can be wrong, so treat results as a shortlist.

## Install on your Android phone (once it is hosted)

1. Open the app's web address in Chrome.
2. Tap the ⋮ menu (top right) and tap **Install app** (or **Add to Home screen**), then **Install**.
3. Open it from the new home-screen icon. After the first visit it opens and analyses **offline**; YouTube links still need internet.

## Hosting it for free

The app is static files, so any free static host works; you only upload the **public** folder. I have **not** deployed it, so these are options, not verified steps. Tell me which one you want and I will walk you through it one tap at a time.

| Host | Free? | Notes |
|---|---|---|
| Cloudflare Pages | Free tier | Reads `_headers` for extra security |
| Netlify | Free tier | Reads `_headers`; limits can change |
| GitHub Pages | Free for public repos | Ignores `_headers` (the page's own built-in security rule still applies) |

Free tiers have usage limits and can change. The app does all analysis on your phone, so hosting only serves the page files.

## Running the tests (optional, needs Node.js 18+ on a computer)

```
npm test                       # 63 automated tests
node tools/browser-check.js    # optional: needs Google Chrome; runs the app in a phone-sized browser
```

## How detection works (Stage A)

- Reads SRT, VTT and pasted transcripts, keeping the original timestamps (integer milliseconds, no rounding drift).
- Scores each line with word lists for English, romanised Hindi (Hinglish) and Devanagari Hindi, plus emphatic delivery (CAPS, "!!!", stretched words, repeated words, `[Laughter]`).
- Looks at a 20-second window around each line, so several signals together score higher than one word.
- Works through the transcript in 30-minute chunks, then merges duplicates (moments within 20 seconds of each other count as one).
- Moment times are taken from real transcript lines. Starts are rounded **down** and ends **up** to the whole second, so a window never starts late or ends early.
- If the transcript has few strong signals, you get fewer moments. It never pads the list.

Language choice: **Auto** uses every word list. **English** uses English only. **Hindi** and **Hinglish** use the shared gaming words plus Hindi/Hinglish words (Hindi adds Devanagari; Hinglish adds English phrases). Differences between Hindi and Hinglish are small.

## Safety and privacy

- Nothing is uploaded and nothing is saved. No cookies, no storage, no network calls from the app.
- File type (.srt/.vtt/.txt), size (10 MB) and line-count (200,000) limits; binary files are refused.
- Transcript text is only ever shown as plain text, so a malicious transcript cannot run code.
- Links are only built from a validated 11-character video ID on real YouTube addresses.
- CSV export neutralises spreadsheet formula tricks.
- The server only serves files from `public/` (path-traversal and symlink protected); the page has a strict content-security policy.
- No API keys exist in the code. No permissions are requested (no camera, microphone, location, notifications).

## Known limitations

- Transcript text only: no video, audio or chat replay analysis, so nothing is "visually verified".
- Hindi/Hinglish auto-captions are often inaccurate, which lowers quality. The word lists were written by me, not trained on your streams, so expect some misses and some false alarms; the confidence score and quotes help you skip them quickly.
- Not tested on a real Android phone or on Chrome versions other than the one used for testing.
- After you update the app files, change `CACHE_VERSION` in `public/sw.js` so phones fetch the new version.
- Stage B (optional AI ranking) and Stage C (chat/video samples) are not built.
