# VICE MOMENT FINDER ULTIMATE — v2.0.0

Finds entertaining moments in long GTA livestream replays **from a transcript**, gives exact YouTube timestamps, and helps you turn them into Shorts. It is a free, offline-capable web app (PWA) built for Android Chrome. Nothing is uploaded, there are no accounts, no API keys, no ads and no tracking.

> **Read this first (honest limits)**
> - It reads **transcript text only**. It cannot watch video or hear audio. Visual events (glitch, crash) are *guessed from what was said* unless you add a marker yourself.
> - Titles, hooks and captions come from **fixed local templates, not AI**.
> - It has been tested with automated tests and in a phone-sized desktop Chromium. It has **not been tested on a real Android phone, in the installed PWA on a phone, or inside any APK/WebView wrapper**. See `TEST_REPORT.md`.
> - **No APK is included.** See "APK" below.

## Features

**Analysis (works offline, on your phone)**
- Reads `.srt`, `.vtt`, `.txt` files and pasted timestamped text; English, Hindi (Devanagari), Hinglish and mixed transcripts.
- 16 categories: funny, rage, glitch, police chase, car crash, unexpected death, crazy gameplay, funny conversation, surprise, viral reaction, roast/insults, argument, emotional, unexpected discovery, suspicious, epic.
- Context-aware scoring: a lone "lol / omg / wtf / shit" is **not** a moment; several signal lines in a row, shouting, repeated words and fast back-and-forth raise the score.
- 4–8 hour streams are processed in 30-minute chunks in a background worker so the page does not freeze. Duplicates within 20 s are merged.
- Integer-millisecond timestamps. Starts are rounded **down**, ends **up**. Moment times always come from real transcript lines; nothing is invented.
- Evidence is separated into **transcript evidence**, **visual evidence** (only if you typed a marker) and **unverified inference**.

**Creator assistant (local templates)**
- Shorts title, English / Hinglish / Hindi titles, opening hook, caption, description, hashtags, why it is interesting, editing style, start/end point, sound-effect ideas, zoom ideas, recording window.
- Copy button for every field and a "copy everything" button.
- Shorts-length badge for recording windows of 20–35 s; padding adjustable per moment (0–60 s).

**Shorts workflow**
- Tick moments → **Shorts plan** tab: stream order, editable title / caption / notes, checklist (opened, screen-recorded, edited in VN Editor, published), progress counter.
- Export all moments or only the selected plan as **TXT** or **CSV** (spreadsheet-formula safe), or copy the whole plan.

**Projects (saved on this phone only)**
- Save, restore, delete, and delete-all (two-tap confirmation). Stored in the browser's IndexedDB, including your transcript, selections, edits and checklist.

**Dashboard**: total moments, selected, strong (70%+), average confidence, Shorts-length count, top 3.

**PWA**: installable, standalone, offline app shell, versioned cache, "Update now" bar when a new version is ready, first-use guide.

## Using it

1. Open the app. 2. Paste the replay link (only used for clickable timestamps). 3. Tap **Choose .srt / .vtt / .txt file** (or **Paste from clipboard**, or paste into the box). 4. Tap **Analyse** (this happens automatically after a file loads unless you untick it). 5. Open **Moments**, tick the ones you want, open **Shorts plan**. 6. Open each timestamp in YouTube, screen-record, edit in VN Editor, publish.

**Getting a transcript** — a YouTube link alone cannot be analysed (YouTube does not let this app read the video).
- Your own stream: YouTube Studio (Chrome → ⋮ → Desktop site) → the video → Subtitles → download `.srt`/`.vtt` if offered.
- Any video with a transcript: YouTube site → "…more" → "Show transcript" → select, copy → **Paste from clipboard**.
- Auto-captions (especially Hindi/Hinglish) can be wrong; treat results as a shortlist.

**Supported files**: `.srt`, `.vtt`, `.txt` up to 10 MB, UTF-8 (UTF-16 with a byte-order mark also works). Transcripts over about 500,000 characters are analysed from memory instead of being shown in the text box (a huge text box is slow on phones); the status line tells you.

## Install on Android (Chrome) — the supported way

The app must be served from a web address (HTTPS, or `localhost`).

**Option A — free hosting (recommended):** upload only the **`public/`** folder to a free static host (Cloudflare Pages, Netlify or GitHub Pages — free tiers exist but limits can change; these steps are not verified by me). Open the address in Chrome → ⋮ → **Install app** → Install.

**Option B — run it on the phone with Termux:** install Termux from F-Droid, then `pkg install nodejs unzip`, `termux-setup-storage`, unzip this archive, `cd vice-moment-finder`, `node server.js`, and open `http://localhost:8080` in Chrome → ⋮ → **Install app**. The server must be running when you open it the first time; after the first visit the app works offline from its cache.

**Option C — on a computer:** `npm start`, then open `http://localhost:8080`.

## Offline

After the first visit the service worker caches every app file (`engine.js`, `creator.js`, `loader.js`, `store.js`, `worker.js`, `app.js`, styles, icons…). Analysis, saving and exporting work with no internet. Opening YouTube links needs internet.

**Updating:** when you change any app file, change `CACHE_VERSION` in `public/sw.js`. Phones then show "A new version is ready — Update now". The old cache is deleted on update.

## If the file button does nothing (Android WebView / APK wrappers)

In Chrome and the installed PWA the button is a real `<input type="file">` laid invisibly on top of the visible button, with no `accept` filter (Android can grey out `.srt` files when an unknown extension is listed). This is tested in desktop Chromium with an Android user-agent and touch emulation.

An "HTML → APK" converter wraps the page in an Android **WebView**. A WebView only opens the file picker if the wrapper app implements `WebChromeClient.onShowFileChooser` (and, on some Android versions, storage/media permission). **Many converters do not, and no JavaScript can fix that** — the tap simply does nothing. I could not test any converter. What to do:
1. Use **Paste from clipboard** (or paste into the box) — this does not need file access (if the WebView blocks clipboard reads, press-and-hold in the box → Paste).
2. Or install from Chrome (Option A/B), which uses real Chrome.
3. Or build the APK with a **Trusted Web Activity** tool such as PWABuilder (free), which runs in Chrome, not WebView, so the file picker works. Not tested by me.
The app shows a yellow note when it detects it is inside a WebView.

## APK

No APK was built: the cloud environment this was built in has no Android SDK and cannot download one. Use Option A, then (optional, free) paste your hosted address into pwabuilder.com and choose Android. A hosted address is required.

## Visual intelligence (what exists and what does not)

There is **no automatic video analysis**. Free, Android-compatible options exist (sampling frames from a *local* video file with `<video>` + `<canvas>`, simple frame-difference scene-change detection), but they need a local copy of the video (YouTube cannot be read), are slow on 4–8 hour files on an 8 GB phone, and were not built because they could not be tested reliably here. What exists today is the data model (`evidence.transcript / visual / inference`) and **visual markers you type** (`1:23:45 crash car flipped`; tags crash, glitch, police, death, funny, reaction, epic, scene). Moments with a marker inside them are labelled *"visual marker given by you"* and get a small confidence boost; the app never claims to have seen anything itself.

## Project layout

```
public/          THE APP (host this folder)
  index.html styles.css app.js          screen
  engine.js                             parsing, scoring, windows, exports, visual markers
  creator.js                            local title/hook/caption/hashtag templates
  loader.js                             file checks + UTF-8/UTF-16 decoding
  store.js                              IndexedDB projects (+ memory fallback for tests)
  worker.js                             runs analysis off the main thread
  sw.js manifest.webmanifest icons/ favicon.svg _headers
server.js        optional tiny static server (serves public/ only)
test/            automated + static tests (npm test)
tools/           run-browser-checks.js (real Chromium, optional), make-icons.py
testkit/         fake-stream generator used by tests
```

## Running the tests

```
npm test               # unit + static tests (Node 18+, no installs)
npm run test:browser   # real Chromium run; needs Playwright + Chromium installed
```

## Privacy and security

No uploads, no cookies, no analytics, no external requests from the app. Transcript text is only ever inserted as plain text (never HTML). Strict Content-Security-Policy (no inline scripts, no eval). CSV export neutralises spreadsheet formulas. YouTube links are built only from a validated 11-character video ID on real YouTube hosts. Saved projects live only in this browser; clearing Chrome's site data erases them — export TXT/CSV for anything important.

## Known limitations

- Transcript wording only; no video, audio, chat replay or automatic visual detection.
- The word lists were written by hand, not trained on your streams: expect misses and some false alarms. Confidence is a rough guide and never exceeds 92% from text alone (96% with your own visual marker).
- Hindi/Hinglish auto-captions are often inaccurate, which lowers quality.
- Titles/captions are templates; they will repeat across similar moments.
- Not tested on a real Android phone, the installed PWA, an APK or any WebView.
- Video titles are not fetched (needs the internet and a YouTube key).
- Saved projects are per browser; they are not synced between devices.
- The Chrome install prompt requires HTTPS or localhost.
