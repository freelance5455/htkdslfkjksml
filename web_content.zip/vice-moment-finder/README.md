# VICE MOMENT FINDER
**Find the Moments. Create the Shorts.**

Paste a YouTube link -> the app tries to fetch the transcript automatically -> finds the funniest / most exciting moments -> gives you exact start and end timestamps you can open on YouTube.

Built for Hindi / Hinglish GTA streams. Free: no paid service, no account, no database server, **zero npm dependencies**.

## What it does
- Link input (watch, youtu.be, /live/, /shorts/), paste and clear buttons, video preview, metadata.
- **Automatic transcript retrieval** with honest failure reasons and fallbacks (paste text, import SRT/VTT/TXT).
- Moment engine written in plain JavaScript (no AI key needed): reads the transcript with context (laughter *after* a line makes the line funny, build-up -> punchline -> reaction), Hindi, Devanagari, Hinglish and English.
- 6 categories: funny, surprise, gaming action, emotional, viral dialogue, story moments.
- Score out of 100 with a visible breakdown. It is a **ranking score inside one transcript, not a views prediction**.
- Adjustable boundaries (+/- seconds or typed hh:mm:ss), Short / Standard / Extended presets, duplicate and overlap removal.
- Creator assistant: 3 Hindi + 3 Hinglish titles, hook, description, hashtags, caption (built only from the real transcript text, no profanity in titles).
- Transcript viewer: search, highlighted moments, tap a time to open YouTube there, fix lines manually.
- Projects saved on the phone (IndexedDB): reopen, rename, delete, export JSON / TXT / SRT / timestamps.
- Installable PWA that works offline for saved projects.
- Optional: loudness analysis and FFmpeg clip commands for **your own** local file. The app never downloads from YouTube and never shows a fake Download button.

## Quick start (Android, free)
Read **docs/ANDROID_SETUP.md** (about 10 minutes, copy-paste commands).

On a computer: install Node.js 18+, unzip, then
```
npm start
```
and open http://localhost:8080.

## Check that real YouTube retrieval works for you
```
npm run live -- https://youtu.be/YOUR_VIDEO_ID
```
This is a real network test (the build environment could not reach YouTube, so this was **not** verified against live YouTube; see TEST_REPORT.md).

## Tests
```
npm test            # 55 unit + backend tests (YouTube simulated)
npm run test:browser # 23 Chromium checks with an Android Chrome profile (needs Playwright)
```

## Folder map
```
public/            the PWA (index.html, styles.css, sw.js, manifest, icons, js/)
public/js/engine.js      moment detection + scoring + boundaries
public/js/transcript.js  SRT / VTT / text / json3 parsing, normalising, language detection
public/js/creator.js     titles, hooks, hashtags
public/js/store.js       IndexedDB projects + localStorage settings
server/            tiny Node backend (serves the app + /api/meta + /api/transcript)
tests/             automated tests and fixtures
docs/              guides
```

## Documentation
- docs/ANDROID_SETUP.md - beginner guide
- docs/DEPLOYMENT.md - free hosting and configuration (incl. OAuth for your own videos)
- docs/KNOWN_LIMITATIONS.md - read this before you rely on it
- TEST_REPORT.md - what was actually run and what was not
