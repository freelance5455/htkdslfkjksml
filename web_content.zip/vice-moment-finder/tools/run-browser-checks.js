'use strict';
/*
 * Real-browser test (Playwright + Chromium, phone-sized, Android Chrome user-agent).
 * NOT part of `npm test` because it needs Playwright and a browser installed.
 * Usage: node tools/run-browser-checks.js [outputFolder]
 * It starts the app server itself, drives the real screen, and prints PASS/FAIL lines plus a JSON summary.
 */
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer } = require('../server.js');
const { makeSrt, makeVtt, makeStream } = require('../testkit/gen.js');

let playwright;
try { playwright = require('playwright'); } catch (e) {
  console.error('Playwright is not installed here, so this browser test cannot run.');
  process.exit(2);
}

const OUT = path.resolve(process.argv[2] || fs.mkdtempSync(path.join(os.tmpdir(), 'vmf-bt-')));
fs.mkdirSync(OUT, { recursive: true });
const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail: detail || '' });
  console.log((ok ? 'PASS ' : 'FAIL ') + name + (detail ? ' - ' + detail : ''));
}

const H = 3600000;
const PLANTED = [
  { atMs: 1 * H + 5000, lines: [{ text: 'bhai police aa gayi bhaago bhaago' }, { text: 'five stars wanted chase chal rahi hai' }] },
  { atMs: 2 * H + 10250, lines: [{ text: 'WTF! no no no' }, { text: 'my car crashed boom' }] },
  { atMs: 3 * H, lines: [{ text: 'पुलिस पीछे पड़ गई भागो भागो' }] },
];

function writeFiles(dir) {
  const cues = makeStream({ hours: 6, planted: PLANTED });
  const f = {};
  f.srt = path.join(dir, 'stream.srt'); fs.writeFileSync(f.srt, makeSrt(cues));
  f.vtt = path.join(dir, 'stream.vtt'); fs.writeFileSync(f.vtt, makeVtt(cues));
  f.txt = path.join(dir, 'pasted.txt');
  fs.writeFileSync(f.txt, '0:00:05 so we are starting\n0:01:10 bhai police aa gayi bhaago bhaago\n0:01:14 five stars chase chal rahi hai\n0:03:00 okay\n');
  f.hindi = path.join(dir, 'hindi.srt');
  fs.writeFileSync(f.hindi, '1\n00:00:05,000 --> 00:00:08,000\nपुलिस पीछे पड़ गई भागो भागो\n\n2\n00:00:20,000 --> 00:00:22,000\nठीक है\n');
  f.hinglish = path.join(dir, 'hinglish.vtt');
  fs.writeFileSync(f.hinglish, 'WEBVTT\n\n00:00:05.000 --> 00:00:08.000\nbhai ye kya hua gaadi ulat gayi blast ho gaya\n\n00:00:30.000 --> 00:00:32.000\nokay\n');
  f.empty = path.join(dir, 'empty.srt'); fs.writeFileSync(f.empty, '');
  f.png = path.join(dir, 'photo.png'); fs.writeFileSync(f.png, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0, 0, 0, 1, 2, 3]));
  f.fakeTxt = path.join(dir, 'binary.txt'); fs.writeFileSync(f.fakeTxt, Buffer.from([0x50, 0x4b, 3, 4, 0, 0, 0, 0, 1, 2, 3]));
  f.big = path.join(dir, 'huge.txt'); fs.writeFileSync(f.big, Buffer.alloc(10 * 1024 * 1024 + 10, 97));
  f.latin1 = path.join(dir, 'latin1.txt'); fs.writeFileSync(f.latin1, Buffer.from([0x30, 0x3a, 0x30, 0x35, 0x20, 0xe9, 0xe9, 0xe9, 0x20, 0xff, 0xfe, 0xfd]));
  f.noCues = path.join(dir, 'nocues.txt'); fs.writeFileSync(f.noCues, 'just some words with no timestamps at all');
  f.huge100k = path.join(dir, 'long.srt');
  fs.writeFileSync(f.huge100k, makeSrt(makeStream({ hours: 8, planted: PLANTED })));
  return f;
}

async function main() {
  const dir = path.join(OUT, 'files');
  fs.mkdirSync(dir, { recursive: true });
  const F = writeFiles(dir);

  const server = createServer(path.join(__dirname, '..', 'public'));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + server.address().port + '/';

  const browser = await playwright.chromium.launch();
  const context = await browser.newContext({
    viewport: { width: 360, height: 780 },
    deviceScaleFactor: 1,
    isMobile: true,
    hasTouch: true,
    userAgent: 'Mozilla/5.0 (Linux; Android 11; V1955A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    permissions: ['clipboard-read', 'clipboard-write'],
    acceptDownloads: true,
  });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  const requests = [];
  page.on('request', (r) => requests.push(r.url()));

  await page.goto(base);
  await page.waitForSelector('#analyseBtn');
  check('Page loads, no JavaScript errors', errors.length === 0, errors.join(' | '));
  check('First-use guide is shown on first visit', await page.isVisible('#firstUse'));
  await page.screenshot({ path: path.join(OUT, '01-input.png') });

  // ---- Real tap on the visible file button opens the file chooser ----
  await page.locator('.file-wrap').scrollIntoViewIfNeeded();
  const box = await page.locator('.file-btn').boundingBox();
  const [chooser] = await Promise.all([
    page.waitForEvent('filechooser', { timeout: 5000 }),
    page.touchscreen.tap(box.x + box.width / 2, box.y + box.height / 2),
  ]);
  check('Tapping the visible "Choose file" button opens the real file chooser (touch tap)', !!chooser);
  check('File chooser is not restricted by a narrow accept filter', (await page.getAttribute('#fileInput', 'accept')) === null);
  await chooser.setFiles(F.hindi);
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden, null, { timeout: 8000 }).catch(() => {});
  const hindiBack = await page.inputValue('#pasteArea');
  check('Hindi .srt: Devanagari text arrives in the transcript box unchanged', hindiBack === fs.readFileSync(F.hindi, 'utf8'));
  check('Hindi .srt: analysis started automatically and found a moment', (await page.textContent('#dTotal')) === '1', await page.textContent('#dTotal'));
  check('Filename and status shown', /Loaded: hindi\.srt/.test(await page.textContent('#fileName')), await page.textContent('#fileName'));

  async function pick(file) {
    await page.click('.tab[data-view="input"]');
    const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.locator('#fileInput').click({ force: true })]);
    await fc.setFiles(file);
  }
  async function settle() { await page.waitForTimeout(700); }

  // ---- same file twice ----
  await pick(F.hindi); await settle();
  check('Selecting the SAME file a second time loads it again', /Loaded: hindi\.srt/.test(await page.textContent('#fileName')));
  await page.evaluate(() => { document.querySelector('#fileName').textContent = 'reset'; });
  await pick(F.hindi); await settle();
  check('Same file a third time still fires', /Loaded: hindi\.srt/.test(await page.textContent('#fileName')));

  // ---- other formats, sequential ----
  await page.click('.tab[data-view="input"]');
  await page.uncheck('#autoRun');
  await pick(F.hinglish); await settle();
  check('VTT (Hinglish) loads', /Loaded: hinglish\.vtt .*VTT/.test(await page.textContent('#fileName')), await page.textContent('#fileName'));
  await pick(F.txt); await settle();
  check('TXT loads and replaces the previous file', /Loaded: pasted\.txt/.test(await page.textContent('#fileName')) && (await page.inputValue('#pasteArea')).includes('police aa gayi'));
  await pick(F.srt); await settle();
  check('Multiple files in sequence: 6-hour SRT loads', /Loaded: stream\.srt/.test(await page.textContent('#fileName')));
  await page.click('#analyseBtn');
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden, null, { timeout: 20000 });
  const total = await page.textContent('#dTotal');
  check('Analysis after a loaded file finds the planted moments', Number(total) >= 3, 'moments=' + total);

  // ---- bad files ----
  const bad = [
    ['empty file', F.empty, /empty/i],
    ['wrong type (.png)', F.png, /not a \.srt/i],
    ['binary content named .txt', F.fakeTxt, /binary/i],
    ['oversized (>10 MB)', F.big, /bigger than 10 MB/i],
    ['not valid UTF-8 text', F.latin1, /UTF-8/i],
  ];
  for (const [label, file, re] of bad) {
    await pick(file); await settle();
    const msg = await page.textContent('#status');
    check('Rejected: ' + label + ' with a friendly message', re.test(msg), msg);
  }
  await pick(F.noCues); await settle();
  await page.click('#analyseBtn'); await settle();
  check('Text without timestamps gives a clear error', /No timestamped lines/.test(await page.textContent('#status')), await page.textContent('#status'));
  await pick(F.hindi); await settle();
  check('After errors, a good file still loads', /Loaded: hindi\.srt/.test(await page.textContent('#fileName')));

  // ---- manual paste ----
  await page.fill('#pasteArea', '0:00:05 so we are starting\n0:01:10 bhai police aa gayi bhaago bhaago\n0:01:14 five stars chase chal rahi hai\n0:03:00 okay');
  await page.fill('#urlInput', 'https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  await page.click('#analyseBtn');
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden && document.querySelector('#dTotal').textContent !== '0', null, { timeout: 8000 });
  check('Manual paste still works and builds YouTube links', (await page.locator('a.open').first().getAttribute('href')).includes('v=dQw4w9WgXcQ&t=70s'), await page.locator('a.open').first().getAttribute('href'));

  // ---- clipboard paste button ----
  await page.evaluate(() => navigator.clipboard.writeText('0:00:10 oh my god crash crashed boom\n0:00:40 okay'));
  await page.click('.tab[data-view="input"]');
  await page.click('#pasteClipBtn');
  await settle();
  check('"Paste from clipboard" fills the transcript box', (await page.inputValue('#pasteArea')).includes('crashed boom'));

  // ---- long transcript through worker ----
  await page.check('#autoRun');
  const t0 = Date.now();
  await pick(F.huge100k);
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden && document.querySelector('#dTotal').textContent !== '0', null, { timeout: 60000 });
  check('8-hour transcript analysed from a file (worker)', true, (Date.now() - t0) + ' ms incl. load');
  check('A very large transcript is kept in memory (box stays empty, status says so)', (await page.inputValue('#pasteArea')) === '' && /analysed from memory/.test(await page.textContent('#fileName')), await page.textContent('#fileName'));
  await page.screenshot({ path: path.join(OUT, '02-results.png') });

  // ---- dashboard & selection ----
  check('Dashboard shows total, strong, average and shorts counts', (await page.textContent('#dAvg')).endsWith('%'));
  const boxes = page.locator('.m-select input');
  await boxes.nth(0).check(); await boxes.nth(1).check();
  check('Ticking moments updates the Selected tile and tab counter', (await page.textContent('#dSelected')) === '2' && (await page.textContent('#planCount')) === '2');

  // ---- padding control ----
  const before = await page.locator('.moment').first().locator('.m-times').textContent();
  await page.locator('.moment').first().locator('.pad-row .btn', { hasText: '+5' }).click();
  const after = await page.locator('.moment').first().locator('.m-times').textContent();
  check('Custom padding changes the recording window', before !== after, before + ' -> ' + after);

  // ---- creator assistant + copy ----
  await page.locator('.moment').first().locator('details.creator summary').click();
  await page.locator('.moment').first().locator('.f-label', { hasText: 'HINDI TITLE' }).waitFor({ timeout: 5000 }).catch(() => {});
  check('Creator assistant shows Shorts, Hindi and Hinglish titles', await page.locator('.moment').first().locator('.f-label', { hasText: 'HINDI TITLE' }).isVisible());
  await page.locator('.moment').first().locator('.field', { hasText: 'SHORTS TITLE' }).locator('button').click();
  const clip = await page.evaluate(() => navigator.clipboard.readText());
  check('Copy button for one field puts that text on the clipboard', clip.length > 5, clip);
  await page.locator('.moment').first().locator('button', { hasText: 'Copy everything below' }).click();
  const all = await page.evaluate(() => navigator.clipboard.readText());
  check('Combined copy includes title, hook, hashtags', /Shorts title:/.test(all) && /Hashtags:/.test(all) && /Opening hook:/.test(all));

  // ---- exports ----
  const [d1] = await Promise.all([page.waitForEvent('download'), page.click('#exportCsv')]);
  const csv = fs.readFileSync(await d1.path(), 'utf8');
  check('Export CSV downloads a file with a header and rows', /^﻿rank,category/.test(csv) && csv.split('\r\n').length > 3);
  const [d2] = await Promise.all([page.waitForEvent('download'), page.click('#exportTxt')]);
  check('Export TXT downloads', /VICE MOMENT FINDER/.test(fs.readFileSync(await d2.path(), 'utf8')));

  // ---- Shorts plan ----
  await page.click('.tab[data-view="plan"]');
  check('Shorts plan lists the 2 selected moments', (await page.locator('#planList .moment').count()) === 2);
  await page.locator('#planList .moment').first().locator('input[type="text"]').fill('My custom title');
  await page.locator('#planList .moment').first().locator('.checklist input').nth(3).check();
  check('Progress counter follows the checklist', (await page.textContent('#planProgress')).startsWith('1 / 2'), await page.textContent('#planProgress'));
  const [d3] = await Promise.all([page.waitForEvent('download'), page.click('#planCsv')]);
  const pcsv = fs.readFileSync(await d3.path(), 'utf8');
  check('Selected-moments CSV uses the edited title and has 2 rows', pcsv.includes('My custom title') && pcsv.trim().split('\r\n').length === 3);
  await page.screenshot({ path: path.join(OUT, '03-plan.png') });

  // ---- projects (real IndexedDB) ----
  await page.click('.tab[data-view="projects"]');
  await page.fill('#projName', 'Test stream');
  await page.click('#saveProjBtn');
  await page.waitForFunction(() => /Saved/.test(document.querySelector('#projMsg').textContent), null, { timeout: 5000 });
  check('Save project (IndexedDB)', (await page.locator('#projList li').count()) === 1);
  await page.reload();
  await page.waitForSelector('#analyseBtn');
  await page.click('.tab[data-view="projects"]');
  await page.waitForSelector('#projList li');
  check('Saved project survives a page reload', (await page.locator('#projList li').count()) === 1);
  await page.locator('#projList li button', { hasText: 'Restore' }).click();
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden, null, { timeout: 5000 });
  check('Restore brings back moments and selection', Number(await page.textContent('#dTotal')) >= 3 && (await page.textContent('#dSelected')) === '2');
  await page.click('.tab[data-view="plan"]');
  check('Restore brings back edited title and checklist', (await page.locator('#planList input[type="text"]').first().inputValue()) === 'My custom title' && (await page.textContent('#planProgress')).startsWith('1 / 2'));
  await page.click('.tab[data-view="projects"]');
  const delBtn = page.locator('#projList li button', { hasText: 'Delete' });
  await delBtn.click();
  check('Delete needs a second tap (confirmation)', (await page.locator('#projList li').count()) === 1);
  await delBtn.click();
  await page.waitForFunction(() => document.querySelectorAll('#projList li').length === 0, null, { timeout: 5000 });
  check('Delete project', true);
  await page.click('.tab[data-view="results"]');
  await page.click('.tab[data-view="projects"]');
  await page.click('#saveProjBtn');
  await page.waitForFunction(() => document.querySelectorAll('#projList li').length === 1, null, { timeout: 5000 });
  await page.click('#clearAllBtn');
  check('Clear all asks for confirmation first', (await page.locator('#projList li').count()) === 1);
  await page.click('#clearAllBtn');
  await page.waitForFunction(() => document.querySelectorAll('#projList li').length === 0, null, { timeout: 5000 });
  check('Clear all saved data', true);

  // ---- visual markers ----
  await page.click('.tab[data-view="input"]');
  await page.fill('#pasteArea', '0:00:10 oh my god my car crashed boom\n0:00:40 okay');
  await page.click('summary:has-text("visual markers")');
  await page.fill('#visualArea', '0:00:11 crash car flipped');
  await page.click('#analyseBtn');
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden, null, { timeout: 8000 });
  await settle();
  check('User-supplied visual marker is labelled as yours', /visual marker given by you/.test(await page.textContent('#list')));

  // ---- security: transcript cannot inject markup ----
  await page.click('.tab[data-view="input"]');
  await page.fill('#pasteArea', '0:00:10 <img src=x onerror=window.__pwned=1> <script>window.__pwned=1</script> crash crashed boom\n0:00:40 okay');
  await page.fill('#visualArea', '');
  await page.click('#analyseBtn');
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden && document.querySelector('#list .moment'), null, { timeout: 8000 });
  await settle();
  check('Markup inside a transcript is shown as text, never executed', (await page.evaluate(() => window.__pwned)) === undefined && (await page.locator('#list img').count()) === 0);

  // ---- network: the app itself makes no outside requests ----
  const outside = requests.filter((u) => !u.startsWith(base) && !u.startsWith('blob:') && !u.startsWith('data:'));
  check('No requests to any other website', outside.length === 0, outside.join(', '));

  // ---- PWA: manifest, installability, offline ----
  const cdp = await context.newCDPSession(page);
  const inst = await cdp.send('Page.getInstallabilityErrors');
  check('Chrome reports no installability errors', inst.installabilityErrors.length === 0, JSON.stringify(inst.installabilityErrors));
  await page.evaluate(() => navigator.serviceWorker.ready);
  const keys = await page.evaluate(() => caches.keys());
  check('Service worker is active and cached files exist', keys.length === 1 && keys[0].startsWith('vmf-v'), keys.join(','));
  await page.reload();
  await page.waitForFunction(() => navigator.serviceWorker.controller);
  await context.setOffline(true);
  await page.reload();
  await page.waitForSelector('#analyseBtn');
  await page.fill('#pasteArea', '0:00:10 oh my god my car crashed boom\n0:00:40 okay');
  await page.click('#analyseBtn');
  await page.waitForFunction(() => !document.querySelector('#view-results').hidden && document.querySelector('#dTotal').textContent !== '0', null, { timeout: 8000 });
  check('Offline: app loads and analyses with no network (service worker + worker.js cached)', true);
  await context.setOffline(false);
  await page.screenshot({ path: path.join(OUT, '04-offline-results.png') });

  await browser.close();
  server.close();

  /* ---- cache update test with a copied app folder ---- */
  const copy = path.join(OUT, 'app-copy');
  fs.cpSync(path.join(__dirname, '..', 'public'), copy, { recursive: true });
  const server2 = createServer(copy);
  await new Promise((r) => server2.listen(0, '127.0.0.1', r));
  const base2 = 'http://127.0.0.1:' + server2.address().port + '/';
  const browser2 = await playwright.chromium.launch();
  const ctx2 = await browser2.newContext({ viewport: { width: 360, height: 780 } });
  const p2 = await ctx2.newPage();
  await p2.goto(base2);
  await p2.evaluate(() => navigator.serviceWorker.ready);
  await p2.reload();
  await p2.waitForFunction(() => navigator.serviceWorker.controller);
  const swPath = path.join(copy, 'sw.js');
  fs.writeFileSync(swPath, fs.readFileSync(swPath, 'utf8').replace("'vmf-v2.0.0'", "'vmf-v2.0.1'"));
  fs.appendFileSync(path.join(copy, 'styles.css'), '\n/* v2.0.1 marker */\n');
  await p2.evaluate(() => navigator.serviceWorker.getRegistration().then((r) => r.update()));
  await p2.waitForSelector('#updateBar:not([hidden])', { timeout: 8000 }).catch(() => {});
  check('Update available: the "new version is ready" bar appears', await p2.isVisible('#updateBar'));
  await Promise.all([p2.waitForNavigation({ timeout: 8000 }).catch(() => {}), p2.click('#updateBtn')]);
  await p2.waitForSelector('#analyseBtn');
  await p2.waitForFunction(() => navigator.serviceWorker.controller);
  const keys2 = await p2.evaluate(() => caches.keys());
  check('After updating, only the new cache remains (old cache deleted)', keys2.length === 1 && keys2[0] === 'vmf-v2.0.1', keys2.join(','));
  const css = await p2.evaluate(() => fetch('styles.css').then((r) => r.text()));
  check('After updating, the new file contents are served', css.includes('v2.0.1 marker'));
  await browser2.close();
  server2.close();

  const failed = results.filter((r) => !r.ok);
  fs.writeFileSync(path.join(OUT, 'browser-results.json'), JSON.stringify(results, null, 2));
  console.log('\nBROWSER TESTS: ' + (results.length - failed.length) + ' passed, ' + failed.length + ' failed. Output: ' + OUT);
  process.exit(failed.length ? 1 : 0);
}

main().catch((e) => { console.error('Browser test crashed:', e); process.exit(1); });
