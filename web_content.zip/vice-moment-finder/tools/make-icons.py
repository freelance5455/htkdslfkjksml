"""Regenerates the app icons. Needs Python 3 and Pillow (pip install pillow).
Normal use of the app does NOT need this; the PNG files are already included."""
from PIL import Image, ImageDraw
import os

OUT = os.path.join(os.path.dirname(__file__), "..", "public", "icons")
BG = (18, 18, 23, 255)
PINK = (255, 46, 151, 255)
PURPLE = (168, 85, 247, 255)
CYAN = (34, 229, 255, 255)


def make(size, content_scale, path):
    s = size * 4  # draw large, then shrink for smooth edges
    img = Image.new("RGBA", (s, s), BG)
    d = ImageDraw.Draw(img)
    u = s * content_scale / 64.0
    ox = oy = s * (1 - content_scale) / 2

    def pt(x, y):
        return (ox + x * u, oy + y * u)

    # big "V"
    d.polygon([pt(8, 10), pt(20, 10), pt(32, 38), pt(44, 10), pt(56, 10), pt(37, 52), pt(27, 52)], fill=PINK)
    # purple inner stripe
    d.polygon([pt(22, 10), pt(26, 10), pt(32, 25), pt(38, 10), pt(42, 10), pt(32, 33)], fill=PURPLE)
    # cyan underline
    d.rounded_rectangle([pt(14, 56)[0], pt(14, 56)[1], pt(50, 60)[0], pt(50, 60)[1]], radius=u * 2, fill=CYAN)
    img = img.resize((size, size), Image.LANCZOS).convert("RGB")
    img.save(path, "PNG", optimize=True)


os.makedirs(OUT, exist_ok=True)
make(192, 0.92, os.path.join(OUT, "icon-192.png"))
make(512, 0.92, os.path.join(OUT, "icon-512.png"))
make(512, 0.62, os.path.join(OUT, "icon-maskable-512.png"))  # content kept inside the safe zone
print("icons written to", os.path.abspath(OUT))
