'use strict';
/*
 * Optional real-browser check (needs Google Chrome or Chromium installed on the computer running it).
 * Starts the app, opens it in a phone-sized headless Chrome, runs an analysis, checks the install
 * ability and offline mode, and saves screenshots. Usage: node tools/browser-check.js [outputFolder]
 */
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn, execSync } = require('node:child_process');
const { createServer } = require('../server.js');
const { makeSrt, makeStream } = require('../testkit/gen.js');

const OUT = path.resolve(process.argv[2] || path.join(os.tmpdir(), 'vmf-browser-check'));
fs.mkdirSync(OUT, { recursive: true });

function findChrome() {
  for (const c of ['google-chrome', 'chromium', 'chromium-browser', 'chrome']) {
    try { execSync('which ' + c, { stdio: 'ignore' }); return c; } catch (e) { /* next */ }
  }
  throw new Error('Chrome or Chromium not found');
}

function getJson(port, p) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port, path: p }, (res) => {
      let b = '';
      res.on('data', (d) => (b += d));
      res.on('end', () => { try { resolve(JSON.parse(b)); } catch (e) { reject(e); } });
    }).on('error', reject);
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function main() {
  const results = [];
  const check = (name, ok, detail) => { results.push({ name, ok: !!ok, detail }); console.log((ok ? 'PASS ' : 'FAIL ') + name + (detail ? ' - ' + detail : '')); };

  const server = createServer(path.join(__dirname, '..', 'public'));
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const appPort = server.address().port;
  const base = 'http://127.0.0.1:' + appPort + '/';

  const PLANTED = [
    { atMs: 3600000 + 5000, lines: [{ text: 'bhai police aa gayi bhaago bhaago' }, { text: 'five stars wanted chase chal rahi hai' }] },
    { atMs: 9000000 + 10250, lines: [{ text: 'WTF! no no no' }, { text: 'my car crashed boom' }] },
    { atMs: 14000000, lines: [{ text: 'पुलिस पीछे पड़ गई भागो भागो' }] },
  ];
  const srt = makeSrt(makeStream({ hours: 8, planted: PLANTED }));
  const srtPath = path.join(OUT, 'stream.srt');
  fs.writeFileSync(srtPath, srt);

  const debugPort = 9300 + Math.floor(Math.random() * 500);
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'vmf-chrome-'));
  const chrome = spawn(findChrome(), ['--headless=new', '--no-sandbox', '--disable-gpu', '--remote-debugging-port=' + debugPort, '--user-data-dir=' + profile, '--window-size=360,800', 'about:blank'], { stdio: 'ignore' });

  let ws;
  try {
    let targets;
    for (let i = 0; i < 50; i++) {
      try { targets = await getJson(debugPort, '/json'); if (targets.find((t) => t.type === 'page')) break; } catch (e) { /* wait */ }
      await sleep(200);
    }
    const page = targets.find((t) => t.type === 'page');
    ws = new WebSocket(page.webSocketDebuggerUrl);
    await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
    let id = 0;
    const pending = new Map();
    const consoleErrors = [];
    ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); return; }
      if (msg.method === 'Runtime.exceptionThrown') consoleErrors.push(JSON.stringify(msg.params.exceptionDetails.exception || msg.params.exceptionDetails.text).slice(0, 300));
      if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') consoleErrors.push(msg.params.args.map((a) => a.value || a.description).join(' ').slice(0, 300));
      if (msg.method === 'Log.entryAdded' && msg.params.entry.level === 'error') consoleErrors.push(msg.params.entry.text + ' ' + (msg.params.entry.url || ''));
    };
    const send = (method, params) => new Promise((resolve) => { const i = ++id; pending.set(i, resolve); ws.send(JSON.stringify({ id: i, method, params: params || {} })); });
    const evalJs = async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true }); if (r.result.exceptionDetails) throw new Error(JSON.stringify(r.result.exceptionDetails).slice(0, 300)); return r.result.result.value; };
    const shot = async (name) => { const r = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }); fs.writeFileSync(path.join(OUT, name), Buffer.from(r.result.data, 'base64')); };

    await send('Page.enable'); await send('Runtime.enable'); await send('Log.enable'); await send('DOM.enable'); await send('Network.enable');
    await send('Emulation.setDeviceMetricsOverride', { width: 360, height: 740, deviceScaleFactor: 2, mobile: true });
    await send('Page.navigate', { url: base });
    await sleep(1500);

    check('page title', (await evalJs('document.title')) === 'VICE MOMENT FINDER');
    check('engine loaded in browser', await evalJs('typeof window.ViceEngine === "object" && typeof ViceEngine.analyze === "function"'));
    check('no horizontal scroll at 360px', await evalJs('document.documentElement.scrollWidth <= window.innerWidth'), 'scrollWidth=' + (await evalJs('document.documentElement.scrollWidth')));
    await shot('1-home.png');

    // service worker + install ability
    let swReady = false;
    for (let i = 0; i < 20 && !swReady; i++) { swReady = await evalJs('navigator.serviceWorker.getRegistration().then(r => !!(r && r.active))'); if (!swReady) await sleep(300); }
    check('service worker active', swReady);
    const manifest = await send('Page.getAppManifest');
    check('manifest parsed by Chrome', manifest.result && manifest.result.data && !(manifest.result.errors || []).length, JSON.stringify(manifest.result.errors || []));
    const inst = await send('Page.getInstallabilityErrors');
    check('Chrome reports no install blockers', inst.result && (inst.result.installabilityErrors || []).length === 0, JSON.stringify(inst.result && inst.result.installabilityErrors));

    // file upload through a real file input
    const doc = await send('DOM.getDocument');
    const node = await send('DOM.querySelector', { nodeId: doc.result.root.nodeId, selector: '#fileInput' });
    await send('DOM.setFileInputFiles', { files: [srtPath], nodeId: node.result.nodeId });
    await evalJs('document.getElementById("urlInput").value = "https://youtu.be/dQw4w9WgXcQ"; document.getElementById("urlInput").dispatchEvent(new Event("change")); void 0');
    check('file name shown', /stream\.srt/.test(await evalJs('document.getElementById("fileName").textContent')));
    await evalJs('document.getElementById("analyseBtn").click(); void 0');
    let n = 0;
    for (let i = 0; i < 40 && n === 0; i++) { await sleep(250); n = await evalJs('document.querySelectorAll("#list .moment").length'); }
    check('moments rendered from the uploaded 8-hour SRT', n >= 3, n + ' cards');
    const first = await evalJs('(() => { const c = document.querySelector("#list .moment"); return { text: c.textContent, href: c.querySelector("a.open").href }; })()');
    check('open link is a real YouTube timestamp link', /^https:\/\/www\.youtube\.com\/watch\?v=dQw4w9WgXcQ&t=\d+s$/.test(first.href), first.href);
    check('card shows "not visually verified"', /not visually verified/.test(first.text));
    check('analysed panel explains the scope', /No video, audio or chat replay was analysed/.test(await evalJs('document.getElementById("analysedList").textContent')));
    const chips = await evalJs('Array.from(document.querySelectorAll("#filters .chip")).map(c => c.textContent)');
    check('category filter chips created', chips.length >= 3, chips.join(' | '));
    await evalJs('document.querySelectorAll("#filters .chip")[1].click(); void 0');
    const filtered = await evalJs('document.querySelectorAll("#list .moment").length');
    check('filter reduces the list', filtered >= 1 && filtered <= n, filtered + ' of ' + n);
    await evalJs('document.querySelectorAll("#filters .chip")[0].click(); void 0');
    await evalJs('document.getElementById("sortSelect").value = "time"; document.getElementById("sortSelect").dispatchEvent(new Event("change")); void 0');
    const order = await evalJs('Array.from(document.querySelectorAll("#list .moment .m-times div:first-child")).map(d => d.textContent.replace("MOMENT", "").split(" ")[0])');
    const secs = order.map((t) => t.split(':').reduce((a, b) => a * 60 + Number(b), 0));
    check('stream-order sort is ascending', secs.every((v, i) => i === 0 || v >= secs[i - 1]), order.join(', '));
    await evalJs('document.getElementById("results").scrollIntoView(); void 0');
    await sleep(300);
    await shot('2-results.png');

    // exports: capture the blob text that would be downloaded
    const csv = await evalJs(`(async () => { let captured; const orig = URL.createObjectURL; URL.createObjectURL = (b) => { captured = b; return orig.call(URL, b); }; document.getElementById("exportCsv").click(); URL.createObjectURL = orig; return captured ? await captured.text() : null; })()`);
    check('CSV export has a header and one row per moment', csv && csv.split('\r\n').filter(Boolean).length === n + 1, csv && csv.split('\r\n')[0].slice(0, 60));
    const txt = await evalJs(`(async () => { let captured; const orig = URL.createObjectURL; URL.createObjectURL = (b) => { captured = b; return orig.call(URL, b); }; document.getElementById("exportTxt").click(); URL.createObjectURL = orig; return captured ? await captured.text() : null; })()`);
    check('TXT export produced', txt && /VICE MOMENT FINDER - suggested moments/.test(txt));

    // bad inputs
    await evalJs('document.getElementById("clearBtn").click(); void 0');
    await evalJs('document.getElementById("analyseBtn").click(); void 0');
    await sleep(200);
    check('empty input gives a clear message', /Choose a transcript/.test(await evalJs('document.getElementById("status").textContent')));
    await evalJs('document.getElementById("pasteArea").value = "hello with no times"; document.getElementById("analyseBtn").click(); void 0');
    await sleep(500);
    check('transcript with no timestamps gives a clear error', /No timestamped lines/.test(await evalJs('document.getElementById("status").textContent')));
    await evalJs('document.getElementById("pasteArea").value = ""; document.getElementById("urlInput").value = "https://youtube.com.evil.com/watch?v=dQw4w9WgXcQ"; document.getElementById("urlInput").dispatchEvent(new Event("change")); void 0');
    check('look-alike link is rejected', /does not look like a YouTube link/.test(await evalJs('document.getElementById("urlMsg").textContent')));
    await evalJs('document.getElementById("urlInput").value = "https://youtu.be/dQw4w9WgXcQ"; document.getElementById("analyseBtn").click(); void 0');
    await sleep(300);
    check('link without transcript explains it cannot be analysed', /link alone cannot be analysed/.test(await evalJs('document.getElementById("status").textContent')));

    // pasted transcript with an XSS attempt must show as text, not run
    // real tags are stripped by the parser; entity-encoded tags decode to literal text, which must be shown as text
    const xss = '0:00:05 &lt;img src=x onerror="window.__pwned=1"&gt; crashed boom\n0:00:40 okay then\n';
    await evalJs('document.getElementById("pasteArea").value = ' + JSON.stringify(xss) + '; document.getElementById("analyseBtn").click(); void 0');
    await sleep(600);
    check('HTML in a transcript is shown as text and does not run', (await evalJs('!window.__pwned && document.querySelectorAll("#list img").length === 0')) && /<img src=x/.test(await evalJs('document.querySelector("#list .m-desc").textContent')));

    // offline reload
    await send('Network.emulateNetworkConditions', { offline: true, latency: 0, downloadThroughput: 0, uploadThroughput: 0 });
    await send('Page.navigate', { url: base });
    await sleep(1500);
    check('app opens offline from the service worker cache', (await evalJs('document.title')) === 'VICE MOMENT FINDER');
    check('offline badge shown', /Offline/.test(await evalJs('document.getElementById("netBadge").textContent')));
    await evalJs('document.getElementById("pasteArea").value = "0:00:05 crashed boom\\n0:00:40 okay then"; document.getElementById("analyseBtn").click(); void 0');
    await sleep(600);
    check('analysis works while offline', (await evalJs('document.querySelectorAll("#list .moment").length')) === 1);
    await shot('3-offline.png');

    check('no JavaScript errors in the console', consoleErrors.length === 0, consoleErrors.join(' || '));
  } finally {
    try { ws && ws.close(); } catch (e) { /* ignore */ }
    chrome.kill('SIGKILL');
    server.close();
    await sleep(300);
    try { fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch (e) { /* temp folder; safe to leave */ }
  }
  const failed = results.filter((r) => !r.ok);
  fs.writeFileSync(path.join(OUT, 'browser-check.json'), JSON.stringify(results, null, 2));
  console.log('\n' + (results.length - failed.length) + ' of ' + results.length + ' browser checks passed. Output: ' + OUT);
  process.exit(failed.length ? 1 : 0);
}

main().catch((e) => { console.error(e); process.exit(2); });
