'use strict';
/*
 * VICE MOMENT FINDER - tiny static file server (no dependencies).
 * It only serves the files inside ./public and nothing else.
 * The app itself runs entirely in the browser; this server is optional
 * (you can also host the public/ folder on any free static host).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data:",
  "connect-src 'self'",
  "manifest-src 'self'",
  "worker-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'none'",
  "frame-ancestors 'none'",
].join('; ');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

const MAX_URL_LENGTH = 2048;

function send(res, status, body, extra) {
  const headers = Object.assign(
    {
      'Content-Type': 'text/plain; charset=utf-8',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-store',
    },
    extra || {}
  );
  res.writeHead(status, headers);
  res.end(body);
}

// Turn a request URL into a list of safe path segments, or an error status.
function resolveSegments(rawUrl) {
  if (typeof rawUrl !== 'string' || rawUrl.length > MAX_URL_LENGTH) return { status: 414 };
  if (rawUrl[0] !== '/') return { status: 400 };
  const rawPath = rawUrl.split('?')[0].split('#')[0];
  let decoded;
  try {
    decoded = decodeURIComponent(rawPath);
  } catch (e) {
    return { status: 400 };
  }
  if (decoded.indexOf('\0') !== -1 || decoded.indexOf('\\') !== -1) return { status: 400 };
  if (decoded === '/') return { segments: ['index.html'] };
  if (decoded.endsWith('/')) return { status: 404 };
  const segments = decoded.split('/').filter((s) => s !== '');
  for (const seg of segments) {
    if (seg === '.' || seg === '..') return { status: 400 };
    if (seg[0] === '.') return { status: 404 }; // no dotfiles
  }
  if (!segments.length) return { status: 404 };
  return { segments };
}

function createServer(rootDir) {
  const root = path.resolve(rootDir);
  const realRoot = fs.realpathSync(root);

  const server = http.createServer((req, res) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return send(res, 405, 'Method not allowed', { Allow: 'GET, HEAD' });
    }
    const r = resolveSegments(req.url);
    if (r.status) return send(res, r.status, r.status === 414 ? 'URL too long' : r.status === 400 ? 'Bad request' : 'Not found');

    const ext = path.extname(r.segments[r.segments.length - 1]).toLowerCase();
    const type = MIME[ext];
    if (!type) return send(res, 404, 'Not found');

    const candidate = path.join(root, ...r.segments);
    if (!candidate.startsWith(root + path.sep)) return send(res, 403, 'Forbidden');

    fs.realpath(candidate, (err, real) => {
      if (err) return send(res, 404, 'Not found');
      if (!real.startsWith(realRoot + path.sep)) return send(res, 403, 'Forbidden'); // symlink escape
      fs.stat(real, (err2, st) => {
        if (err2 || !st.isFile()) return send(res, 404, 'Not found');
        const noCache = r.segments.length === 1 && (r.segments[0] === 'sw.js' || r.segments[0] === 'index.html');
        res.writeHead(200, {
          'Content-Type': type,
          'Content-Length': st.size,
          'X-Content-Type-Options': 'nosniff',
          'Referrer-Policy': 'no-referrer',
          'Cross-Origin-Opener-Policy': 'same-origin',
          'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
          'Content-Security-Policy': CSP,
          'Cache-Control': noCache ? 'no-cache' : 'public, max-age=3600',
        });
        if (req.method === 'HEAD') return res.end();
        const stream = fs.createReadStream(real);
        stream.on('error', () => res.destroy());
        stream.pipe(res);
      });
    });
  });
  server.on('clientError', (err, socket) => {
    if (socket.writable) socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
  });
  return server;
}

module.exports = { createServer, resolveSegments, CSP, MIME };

if (require.main === module) {
  const port = parseInt(process.env.PORT || '8080', 10);
  const host = process.env.HOST || '127.0.0.1';
  createServer(path.join(__dirname, 'public')).listen(port, host, () => {
    console.log('VICE MOMENT FINDER running at http://' + host + ':' + port + '/');
    console.log('Press Ctrl+C to stop.');
  });
}
