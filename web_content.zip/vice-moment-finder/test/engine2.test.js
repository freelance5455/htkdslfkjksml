'use strict';
// Tests for the ULTIMATE engine upgrades: new categories, context-aware scoring, record windows, visual markers.
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../public/engine.js');
const { makeStream, makeSrt } = require('../testkit/gen.js');

const cue = (startMs, text, durMs) => ({ startMs, endMs: startMs + (durMs || 2500), text });
const analyse = (cues, o) => E.analyze(cues, o || {});

test('New categories: each one can be detected from its own wording (English, Hinglish, Devanagari)', () => {
  const samples = {
    roast: ['you idiot skill issue you clown', 'tu noob hai ullu ka pattha', 'तू उल्लू है गधा'],
    argument: ['shut up you are wrong liar', 'chup kar teri galti hai', 'चुप कर तेरी गलती है'],
    emotional: ["i am sorry i love you guys thank you so much", 'maaf karna bahut yaad aayega dil toot gaya', 'शुक्रिया दिल टूट गया'],
    discovery: ['found it secret room hidden easter egg', 'mil gaya ye dekho chhupa hua', 'मिल गया ये देखो'],
    suspicious: ['that is sus who is that something is off', 'kaun hai peeche koi kuch gadbad', 'कोई है कुछ गड़बड़'],
    epic: ['we did it we won mission passed', 'jeet gaye kar diya maza aa gaya', 'जीत गए कर दिया'],
  };
  for (const [cat, texts] of Object.entries(samples)) {
    for (const t of texts) {
      const r = analyse([cue(60000, t), cue(90000, 'okay then')]);
      assert.equal(r.moments.length, 1, cat + ': ' + t);
      assert.ok(r.moments[0].categories.includes(cat), cat + ' missing for "' + t + '" got ' + r.moments[0].categories);
    }
  }
  const ids = E.CATEGORIES.map((c) => c.id);
  for (const id of ['roast', 'argument', 'emotional', 'discovery', 'suspicious', 'epic']) assert.ok(ids.includes(id), id);
});

test('Context: a lone "lol / omg / wtf / shit" is NOT a moment, but the same word with real context is', () => {
  for (const w of ['lol', 'omg', 'wtf', 'shit', 'fuck', 'bruh', 'wow', 'lmao']) {
    const r = analyse([cue(60000, w), cue(90000, 'okay then')]);
    assert.equal(r.moments.length, 0, 'lone "' + w + '" should not be a moment');
  }
  const withContext = analyse([cue(60000, 'lol wait what'), cue(63000, 'that was so funny lmao'), cue(90000, 'okay')]);
  assert.equal(withContext.moments.length, 1);
  const shouted = analyse([cue(60000, 'WTF!!!'), cue(90000, 'okay')]);
  assert.equal(shouted.moments.length, 1, 'shouted WTF!!! has emphasis and is kept');
});

test('Context: several signal lines in a row score higher than one', () => {
  const one = analyse([cue(60000, 'crashed'), cue(90000, 'okay')]).moments[0];
  const three = analyse([cue(60000, 'crashed'), cue(62000, 'exploded'), cue(64000, 'wrecked'), cue(90000, 'okay')]).moments[0];
  assert.ok(three.score > one.score);
});

test('Dialogue: quick short back-and-forth with a question around a signal adds score', () => {
  const plain = analyse([cue(60000, 'who is that'), cue(70000, 'okay then')]).moments[0];
  const banter = analyse([
    cue(60000, 'who is that?'), cue(61000, 'idk man'), cue(62000, 'bro what'), cue(63000, 'no way'), cue(64000, 'sus'), cue(90000, 'okay then'),
  ]).moments[0];
  assert.ok(banter.score > plain.score, banter.score + ' vs ' + plain.score);
});

test('Intensity: low, medium and high are assigned from the score', () => {
  const weak = analyse([cue(60000, 'stuck'), cue(61000, 'lag'), cue(90000, 'ok')]);
  const strong = analyse([cue(60000, 'WTF!!! crashed exploded blew up'), cue(62000, 'NO NO NO my car crashed boom'), cue(64000, 'oh my god'), cue(90000, 'ok')]);
  for (const r of [weak, strong]) for (const m of r.moments) assert.ok(['low', 'medium', 'high'].includes(m.intensity));
  assert.equal(strong.moments[0].intensity, 'high');
});

test('Mixed-language transcript: English, Hinglish and Devanagari moments are all found in one file', () => {
  const cues = [
    cue(60000, 'five stars the cops started a chase'),
    cue(300000, 'bhai gaadi ulat gayi blast ho gaya'),
    cue(600000, 'पुलिस पीछे पड़ गई भागो भागो'),
    cue(900000, 'okay then'),
  ];
  const r = analyse(cues, { language: 'auto' });
  assert.equal(r.moments.length, 3);
});

test('recordWindow: padding 0-60 s, floors the start, ceils the end, stays inside the stream', () => {
  const m = { startMs: 100500, endMs: 110250 };
  const w12 = E.recordWindow(m, 12, 500000, 'dQw4w9WgXcQ');
  assert.equal(w12.recStartSec, 88); // floor(88.5)
  assert.equal(w12.recEndSec, 123); // ceil(122.25)
  assert.equal(w12.recDurationSec, 35);
  assert.equal(w12.shortsFit, true);
  assert.match(w12.recLink, /v=dQw4w9WgXcQ&t=88s$/);
  assert.equal(E.recordWindow(m, 0, 500000).recDurationSec, 11); // floor(100.5)=100 to ceil(110.25)=111
});

test('recordWindow: clamps absurd values and never goes below 0:00:00 or past the transcript end', () => {
  const m = { startMs: 4000, endMs: 9000 };
  const a = E.recordWindow(m, 999, 20000);
  assert.equal(a.padSec, 60);
  assert.equal(a.recStartSec, 0);
  assert.equal(a.recEndSec, 20);
  const b = E.recordWindow(m, -5, 20000);
  assert.equal(b.padSec, 0);
  const c = E.recordWindow(m, 'abc', 20000);
  assert.equal(c.padSec, 12);
  assert.equal(E.recordWindow(m, 12, 20000, 'bad id').recLink, null);
});

test('recordWindow: shortsFit is true only for 20-35 second windows', () => {
  assert.equal(E.recordWindow({ startMs: 100000, endMs: 105000 }, 5, 999999).shortsFit, false); // 15 s
  assert.equal(E.recordWindow({ startMs: 100000, endMs: 105000 }, 10, 999999).shortsFit, true); // 25 s
  assert.equal(E.recordWindow({ startMs: 100000, endMs: 105000 }, 20, 999999).shortsFit, false); // 45 s
});

test('Timestamps: every moment boundary is a real cue time (nothing invented) with the new engine', () => {
  const cues = makeStream({ hours: 3, planted: [{ atMs: 3600000 + 777, lines: [{ text: 'we did it jeet gaye' }, { text: 'WTF! crashed boom' }] }] });
  const r = E.analyze(cues, { count: 20 });
  const starts = new Set(cues.map((c) => c.startMs));
  const ends = new Set(cues.map((c) => c.endMs));
  for (const m of r.moments) {
    assert.ok(starts.has(m.startMs), 'start ' + m.startMs);
    assert.ok(ends.has(m.endMs), 'end ' + m.endMs);
    assert.equal(m.startSec, Math.floor(m.startMs / 1000));
    assert.equal(m.endSec, Math.ceil(m.endMs / 1000));
  }
});

test('Evidence is separated into transcript, visual and inference, and visual is empty by default', () => {
  const m = analyse([cue(60000, 'crashed boom'), cue(90000, 'ok')]).moments[0];
  assert.ok(Array.isArray(m.evidence.transcript) && m.evidence.transcript.length > 0);
  assert.deepEqual(m.evidence.visual, []);
  assert.ok(m.evidence.inference.length > 0);
  assert.equal(m.evidence.visuallyVerified, false);
});

test('Visual markers: parsing accepts timestamps with a tag, rejects junk', () => {
  const p = E.parseVisualMarkers('1:02:03 crash car flipped\n[0:10] reaction\nnot a marker\n\n00:00:05.500 glitch\n9:99 crash');
  assert.equal(p.markers.length, 3);
  assert.equal(p.markers[0].ms, 3723000);
  assert.equal(p.markers[0].tag, 'crash');
  assert.equal(p.markers[2].ms, 5500);
  assert.ok(p.rejected.length >= 1);
  assert.deepEqual(E.parseVisualMarkers(null).markers, []);
});

test('Visual markers: attach only inside a moment, labelled as user-supplied, never claimed as detected', () => {
  const r = analyse([cue(60000, 'my car crashed boom'), cue(300000, 'five stars police chase'), cue(500000, 'ok')]);
  const markers = E.parseVisualMarkers('0:01:01 crash car flipped').markers;
  const out = E.attachVisualMarkers(r.moments, markers);
  const crash = out.find((m) => m.categories.includes('crash'));
  const police = out.find((m) => m.categories.includes('police'));
  assert.ok(crash.evidence.visual.length === 1);
  assert.equal(crash.evidence.visual[0].source, 'user-supplied marker');
  assert.match(crash.evidenceText, /visual marker given by you/);
  assert.ok(crash.confidence > r.moments.find((m) => m.categories.includes('crash')).confidence);
  assert.deepEqual(police.evidence.visual, []);
  assert.equal(police.evidence.visuallyVerified, false);
  assert.ok(crash.confidence <= 96);
});

test('Duplicates with new categories: one moment for a burst, separate moments far apart', () => {
  const cues = [cue(60000, 'found it secret room'), cue(62000, 'hidden easter egg found it'), cue(400000, 'we did it we won'), cue(900000, 'ok')];
  const r = analyse(cues);
  assert.equal(r.moments.length, 2);
});

test('Weak vs strong: strong multi-signal moments outrank weak single-signal ones', () => {
  const cues = [cue(60000, 'stuck'), cue(61000, 'lag'), cue(300000, 'WTF!!! my car crashed boom the car blew up'), cue(302000, 'NO NO NO'), cue(900000, 'ok')];
  const r = analyse(cues);
  assert.ok(r.moments.length >= 1);
  assert.ok(r.moments[0].startMs >= 300000 - 5000);
});

test('Long transcript with the new scoring: 8 hours analysed quickly and planted moments still found', () => {
  const H = 3600000;
  const cues = makeStream({ hours: 8, planted: [
    { atMs: 1 * H + 5000, lines: [{ text: 'bhai police aa gayi bhaago bhaago' }, { text: 'five stars wanted chase' }] },
    { atMs: 7 * H + 5000, lines: [{ text: 'we did it jeet gaye maza aa gaya' }, { text: 'WTF! crashed boom' }] },
  ] });
  const t0 = Date.now();
  const r = E.analyze(cues, { count: 50 });
  assert.ok(Date.now() - t0 < 5000);
  assert.equal(r.moments.length, 2);
  const srt = makeSrt(cues);
  assert.ok(srt.length > 100000);
});
