'use strict';
// Checks on the PWA files and on the safety of the browser code.
// These read the source files; they do NOT replace a test on a real phone.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const PUBLIC = path.join(__dirname, '..', 'public');
const read = (f) => fs.readFileSync(path.join(PUBLIC, f), 'utf8');

function pngSize(file) {
  const b = fs.readFileSync(path.join(PUBLIC, file));
  assert.equal(b.slice(1, 4).toString(), 'PNG', file + ' is not a PNG');
  return [b.readUInt32BE(16), b.readUInt32BE(20)];
}

test('PWA: manifest has the fields Chrome needs to offer installation', () => {
  const m = JSON.parse(read('manifest.webmanifest'));
  assert.equal(m.name, 'VICE MOMENT FINDER');
  assert.ok(m.short_name && m.short_name.length <= 12);
  assert.equal(m.display, 'standalone');
  assert.ok(m.start_url);
  assert.match(m.theme_color, /^#[0-9a-f]{6}$/i);
  assert.match(m.background_color, /^#[0-9a-f]{6}$/i);
  const sizes = m.icons.map((i) => i.sizes);
  assert.ok(sizes.includes('192x192'));
  assert.ok(sizes.includes('512x512'));
  assert.ok(m.icons.some((i) => i.purpose === 'maskable'));
  for (const icon of m.icons) {
    const [w, h] = pngSize(icon.src);
    assert.equal(w + 'x' + h, icon.sizes, icon.src);
    assert.equal(icon.type, 'image/png');
  }
});

test('PWA: every file the service worker caches exists', () => {
  const sw = read('sw.js');
  const list = /var ASSETS = \[([\s\S]*?)\];/.exec(sw);
  assert.ok(list, 'ASSETS list not found');
  const files = list[1].match(/'([^']+)'/g).map((s) => s.slice(1, -1));
  assert.ok(files.length >= 8);
  for (const f of files) {
    if (f === './') continue;
    assert.ok(fs.existsSync(path.join(PUBLIC, f)), 'missing cached file: ' + f);
  }
  // every app file the page or worker loads must be cached, or the app breaks offline
  for (const f of ['index.html', 'styles.css', 'engine.js', 'creator.js', 'loader.js', 'store.js', 'worker.js', 'app.js', 'manifest.webmanifest', 'favicon.svg']) {
    assert.ok(files.includes(f), 'not in the service worker cache list: ' + f);
  }
  for (const f of fs.readdirSync(PUBLIC)) {
    if (/\.(js|css|html|webmanifest|svg)$/.test(f) && f !== 'sw.js') assert.ok(files.includes(f), 'public/' + f + ' is not cached for offline use');
  }
  assert.ok(!/skipWaiting\(\)\s*;?\s*\}\)\s*\)?\s*;?\s*$/m.test(sw.split("addEventListener('message'")[0]), 'install must not force skipWaiting');
  assert.match(sw, /SKIP_WAITING/, 'update flow needs the SKIP_WAITING message');
  assert.match(sw, /cache: 'reload'/, 'install must bypass the HTTP cache');
  assert.match(sw, /CACHE_VERSION/);
  assert.match(sw, /url\.origin !== self\.location\.origin/, 'must ignore other websites');
});

test('PWA: index.html links the manifest, icons, viewport and scripts', () => {
  const html = read('index.html');
  assert.match(html, /<link rel="manifest" href="manifest\.webmanifest">/);
  assert.match(html, /<meta name="viewport" content="width=device-width, initial-scale=1/);
  assert.match(html, /<meta name="theme-color"/);
  const order = ['engine.js', 'creator.js', 'loader.js', 'store.js', 'app.js'];
  let last = -1;
  for (const f of order) {
    const i = html.indexOf('<script src="' + f + '"></script>');
    assert.ok(i > last, f + ' must be loaded, in this order: ' + order.join(', '));
    last = i;
  }
  assert.match(html, /<link rel="apple-touch-icon"/);
});

test('Dashboard: all required controls exist', () => {
  const html = read('index.html');
  for (const id of ['urlInput', 'fileInput', 'pasteArea', 'langSelect', 'countSelect', 'padSelect', 'analyseBtn', 'filters', 'list', 'exportTxt', 'exportCsv', 'analysed']) {
    assert.ok(html.includes('id="' + id + '"'), 'missing #' + id);
  }
  for (const lang of ['auto', 'hinglish', 'hindi', 'english']) assert.ok(html.includes('value="' + lang + '"'), lang);
  const app = read('app.js');
  for (const id of ['urlInput', 'fileInput', 'pasteArea', 'langSelect', 'countSelect', 'padSelect', 'analyseBtn', 'filters', 'list', 'exportTxt', 'exportCsv', 'analysed', 'analysedList', 'results', 'status', 'urlMsg', 'fileName', 'clearBtn', 'sortSelect', 'toast', 'netBadge', 'installBtn',
    'pasteClipBtn', 'autoRun', 'visualArea', 'dashboard', 'dTotal', 'dSelected', 'dStrong', 'dAvg', 'dShorts', 'dStatus', 'dTop', 'selAllBtn', 'selNoneBtn',
    'planList', 'planTxt', 'planCsv', 'planCopy', 'planProgress', 'planCount', 'projName', 'saveProjBtn', 'projMsg', 'projList', 'clearAllBtn',
    'firstUse', 'dismissFirst', 'updateBar', 'updateBtn', 'webviewNote', 'noResults', 'noPlan', 'noProj']) {
    assert.ok(html.includes('id="' + id + '"') && app.includes("$('" + id + "')"), 'app.js / html mismatch for #' + id);
  }
});

test('Security: browser code never uses innerHTML, eval or document.write', () => {
  for (const f of ['app.js', 'engine.js', 'sw.js', 'creator.js', 'loader.js', 'store.js', 'worker.js']) {
    const code = read(f);
    assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML/.test(code), f + ' uses HTML injection APIs');
    assert.ok(!/\beval\s*\(/.test(code), f + ' uses eval');
    assert.ok(!/new Function\s*\(/.test(code), f + ' uses new Function');
    assert.ok(!/document\.write/.test(code), f + ' uses document.write');
  }
});

test('Security: no inline scripts or inline event handlers; strict page security policy', () => {
  const html = read('index.html');
  assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>/i.test(html), 'inline <script> found');
  assert.ok(!/\son[a-z]+\s*=/i.test(html), 'inline event handler found');
  assert.ok(!/<style[\s>]/i.test(html), 'inline <style> found');
  assert.ok(!/\sstyle\s*=/i.test(html), 'inline style attribute found');
  const csp = /Content-Security-Policy" content="([^"]+)"/.exec(html);
  assert.ok(csp, 'page has no security policy');
  assert.match(csp[1], /default-src 'self'/);
  assert.match(csp[1], /script-src 'self'/);
  assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(csp[1].replace(/'self'/g, '')), 'policy is too loose');
});

test('Security: external links open safely and the app makes no network requests of its own', () => {
  const app = read('app.js');
  assert.match(app, /rel: 'noopener noreferrer'/);
  assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(app), 'app.js makes network calls');
  assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(read('engine.js')), 'engine.js makes network calls');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(app), 'app.js must store data only through store.js');
  for (const f of ['engine.js', 'creator.js', 'loader.js', 'worker.js']) {
    assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(read(f)), f + ' makes network calls');
    assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(read(f)), f + ' stores data');
  }
  const storeJs = read('store.js');
  assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource|document\.cookie|sessionStorage/.test(storeJs), 'store.js must stay local');
  assert.ok(/indexedDB/.test(storeJs), 'store.js should use IndexedDB');
  assert.ok(!/\bfetch\s*\(/.test(read('sw.js').replace(/fetch\(new Request|fetch\(req\)/g, '')), 'sw.js may only fetch its own app files');
  const html = read('index.html');
  assert.ok(!/(?:src|href)="https?:\/\//.test(html), 'page loads something from another website');
});

test('Security: no API keys or secrets in any shipped file', () => {
  for (const f of ['app.js', 'engine.js', 'sw.js', 'creator.js', 'loader.js', 'store.js', 'worker.js', 'index.html', 'manifest.webmanifest', '_headers']) {
    const t = read(f);
    assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(t), f);
    assert.ok(!/\bsk-[A-Za-z0-9_-]{20,}/.test(t), f);
    assert.ok(!/api[_-]?key\s*[:=]\s*['"][A-Za-z0-9]/i.test(t), f);
  }
});

test('Security: the _headers file policy matches the server policy', () => {
  const { CSP } = require('../server.js');
  const headers = read('_headers');
  assert.ok(headers.includes('Content-Security-Policy: ' + CSP), '_headers CSP differs from server.js');
});

/* ---------------- architecture and release checks ---------------- */
test('Architecture: every $(\'id\') used by app.js exists in index.html (no dead handlers)', () => {
  const html = read('index.html');
  const app = read('app.js');
  const ids = new Set((app.match(/\$\('([A-Za-z0-9_-]+)'\)/g) || []).map((m) => /'([^']+)'/.exec(m)[1]));
  assert.ok(ids.size > 40);
  for (const id of ids) assert.ok(html.includes('id="' + id + '"'), 'app.js uses #' + id + ' but index.html has none');
});

test('Architecture: every tab points at a real view, and every view has a tab', () => {
  const html = read('index.html');
  const tabs = (html.match(/data-view="([a-z]+)"/g) || []).map((m) => /"([a-z]+)"/.exec(m)[1]);
  const views = (html.match(/id="view-([a-z]+)"/g) || []).map((m) => /view-([a-z]+)/.exec(m)[1]);
  assert.deepEqual(tabs.slice().sort(), views.slice().sort());
  assert.match(read('app.js'), /var VIEWS = \['input', 'results', 'plan', 'projects', 'guide'\]/);
});

test('Architecture: the file picker is a real input on top of the button, with no restrictive accept filter', () => {
  const html = read('index.html');
  const css = read('styles.css');
  const tag = /<input id="fileInput"[^>]*>/.exec(html)[0];
  assert.match(tag, /type="file"/);
  assert.ok(!/accept=/.test(tag), 'accept filters can grey out .srt files on Android');
  assert.ok(!/display:\s*none|hidden/.test(tag), 'the input must not be display:none');
  assert.match(css, /\.file-real\s*\{[^}]*position:\s*absolute[^}]*opacity:\s*0/s);
  assert.ok(!/<label[^>]*for="fileInput"/.test(html), 'label forwarding is less reliable in WebViews');
  const app = read('app.js');
  assert.match(app, /addEventListener\('change', onFilePicked\)/);
  assert.match(app, /addEventListener\('input', onFilePicked\)/);
  assert.match(app, /input\.value = ''/, 'the chooser must be reset so the same file can be picked again');
});

test('Architecture: worker.js loads the engine and answers with ok/message', () => {
  const w = read('worker.js');
  assert.match(w, /importScripts\('engine\.js'\)/);
  assert.match(w, /postMessage\(\{ ok: true/);
  assert.match(w, /postMessage\(\{ ok: false/);
  assert.match(read('app.js'), /new Worker\('worker\.js'\)/);
});

test('Architecture: browser modules expose the globals app.js needs (and work in Node)', () => {
  const E = require('../public/engine.js'), C = require('../public/creator.js'), L = require('../public/loader.js'), S = require('../public/store.js');
  for (const f of ['analyze', 'parseTranscript', 'recordWindow', 'parseVisualMarkers', 'attachVisualMarkers', 'csvCell', 'toCSV', 'toTXT', 'extractVideoId', 'formatTime']) assert.equal(typeof E[f], 'function', 'ViceEngine.' + f);
  for (const f of ['suggest', 'fields', 'combined']) assert.equal(typeof C[f], 'function', 'ViceCreator.' + f);
  for (const f of ['checkMeta', 'decodeBytes', 'describe']) assert.equal(typeof L[f], 'function', 'ViceLoader.' + f);
  for (const f of ['createStore', 'memoryBackend', 'idbBackend']) assert.equal(typeof S[f], 'function', 'ViceStore.' + f);
  assert.equal(typeof S.prefs.get, 'function');
  const app = read('app.js');
  for (const g of ['ViceEngine', 'ViceCreator', 'ViceLoader', 'ViceStore']) assert.ok(app.includes('window.' + g), g);
});

test('Release: version is 2.0.0 everywhere it appears', () => {
  const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8'));
  assert.equal(pkg.version, '2.0.0');
  assert.match(read('sw.js'), /var CACHE_VERSION = 'vmf-v2\.0\.0';/);
  const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
  assert.match(readme, /2\.0\.0/);
  assert.match(fs.readFileSync(path.join(__dirname, '..', 'TEST_REPORT.md'), 'utf8'), /2\.0\.0/);
});

test('Release: every local file referenced by index.html, the manifest and styles exists', () => {
  const html = read('index.html');
  for (const m of html.matchAll(/(?:src|href)="([^"#?]+)"/g)) {
    if (/^https?:/.test(m[1])) continue;
    assert.ok(fs.existsSync(path.join(PUBLIC, m[1])), 'index.html references missing file ' + m[1]);
  }
  const manifest = JSON.parse(read('manifest.webmanifest'));
  for (const i of manifest.icons) assert.ok(fs.existsSync(path.join(PUBLIC, i.src)), i.src);
  assert.ok(fs.existsSync(path.join(PUBLIC, manifest.start_url === './' ? 'index.html' : manifest.start_url)));
});

test('Release: no development leftovers inside public/ (maps, backups, notes, node_modules)', () => {
  for (const f of fs.readdirSync(PUBLIC, { recursive: true })) {
    assert.ok(!/\.(map|bak|orig|log|tmp)$|node_modules|\.DS_Store|debug\./i.test(String(f)), 'leftover: ' + f);
  }
});

test('Release: README documents the file formats, offline use, Android install and the WebView limit', () => {
  const readme = fs.readFileSync(path.join(__dirname, '..', 'README.md'), 'utf8');
  for (const needle of ['.srt', '.vtt', '.txt', 'offline', 'Install app', 'WebView', 'Known limitations']) assert.ok(readme.includes(needle), 'README lacks: ' + needle);
});
