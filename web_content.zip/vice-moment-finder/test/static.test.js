'use strict';
// Checks on the PWA files and on the safety of the browser code.
// These read the source files; they do NOT replace a test on a real phone.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const PUBLIC = path.join(__dirname, '..', 'public');
const read = (f) => fs.readFileSync(path.join(PUBLIC, f), 'utf8');

function pngSize(file) {
  const b = fs.readFileSync(path.join(PUBLIC, file));
  assert.equal(b.slice(1, 4).toString(), 'PNG', file + ' is not a PNG');
  return [b.readUInt32BE(16), b.readUInt32BE(20)];
}

test('PWA: manifest has the fields Chrome needs to offer installation', () => {
  const m = JSON.parse(read('manifest.webmanifest'));
  assert.equal(m.name, 'VICE MOMENT FINDER');
  assert.ok(m.short_name && m.short_name.length <= 12);
  assert.equal(m.display, 'standalone');
  assert.ok(m.start_url);
  assert.match(m.theme_color, /^#[0-9a-f]{6}$/i);
  assert.match(m.background_color, /^#[0-9a-f]{6}$/i);
  const sizes = m.icons.map((i) => i.sizes);
  assert.ok(sizes.includes('192x192'));
  assert.ok(sizes.includes('512x512'));
  assert.ok(m.icons.some((i) => i.purpose === 'maskable'));
  for (const icon of m.icons) {
    const [w, h] = pngSize(icon.src);
    assert.equal(w + 'x' + h, icon.sizes, icon.src);
    assert.equal(icon.type, 'image/png');
  }
});

test('PWA: every file the service worker caches exists', () => {
  const sw = read('sw.js');
  const list = /var ASSETS = \[([\s\S]*?)\];/.exec(sw);
  assert.ok(list, 'ASSETS list not found');
  const files = list[1].match(/'([^']+)'/g).map((s) => s.slice(1, -1));
  assert.ok(files.length >= 8);
  for (const f of files) {
    if (f === './') continue;
    assert.ok(fs.existsSync(path.join(PUBLIC, f)), 'missing cached file: ' + f);
  }
  assert.match(sw, /CACHE_VERSION/);
  assert.match(sw, /url\.origin !== self\.location\.origin/, 'must ignore other websites');
});

test('PWA: index.html links the manifest, icons, viewport and scripts', () => {
  const html = read('index.html');
  assert.match(html, /<link rel="manifest" href="manifest\.webmanifest">/);
  assert.match(html, /<meta name="viewport" content="width=device-width, initial-scale=1/);
  assert.match(html, /<meta name="theme-color"/);
  assert.match(html, /<script src="engine\.js"><\/script>/);
  assert.match(html, /<script src="app\.js"><\/script>/);
  assert.match(html, /<link rel="apple-touch-icon"/);
});

test('Dashboard: all required controls exist', () => {
  const html = read('index.html');
  for (const id of ['urlInput', 'fileInput', 'pasteArea', 'langSelect', 'countSelect', 'padSelect', 'analyseBtn', 'filters', 'list', 'exportTxt', 'exportCsv', 'analysed']) {
    assert.ok(html.includes('id="' + id + '"'), 'missing #' + id);
  }
  for (const lang of ['auto', 'hinglish', 'hindi', 'english']) assert.ok(html.includes('value="' + lang + '"'), lang);
  const app = read('app.js');
  for (const id of ['urlInput', 'fileInput', 'pasteArea', 'langSelect', 'countSelect', 'padSelect', 'analyseBtn', 'filters', 'list', 'exportTxt', 'exportCsv', 'analysed', 'analysedList', 'results', 'status', 'urlMsg', 'fileName', 'clearBtn', 'sortSelect', 'toast', 'netBadge', 'installBtn']) {
    assert.ok(html.includes('id="' + id + '"') && app.includes("$('" + id + "')"), 'app.js / html mismatch for #' + id);
  }
});

test('Security: browser code never uses innerHTML, eval or document.write', () => {
  for (const f of ['app.js', 'engine.js', 'sw.js']) {
    const code = read(f);
    assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML/.test(code), f + ' uses HTML injection APIs');
    assert.ok(!/\beval\s*\(/.test(code), f + ' uses eval');
    assert.ok(!/new Function\s*\(/.test(code), f + ' uses new Function');
    assert.ok(!/document\.write/.test(code), f + ' uses document.write');
  }
});

test('Security: no inline scripts or inline event handlers; strict page security policy', () => {
  const html = read('index.html');
  assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>/i.test(html), 'inline <script> found');
  assert.ok(!/\son[a-z]+\s*=/i.test(html), 'inline event handler found');
  assert.ok(!/<style[\s>]/i.test(html), 'inline <style> found');
  assert.ok(!/\sstyle\s*=/i.test(html), 'inline style attribute found');
  const csp = /Content-Security-Policy" content="([^"]+)"/.exec(html);
  assert.ok(csp, 'page has no security policy');
  assert.match(csp[1], /default-src 'self'/);
  assert.match(csp[1], /script-src 'self'/);
  assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(csp[1].replace(/'self'/g, '')), 'policy is too loose');
});

test('Security: external links open safely and the app makes no network requests of its own', () => {
  const app = read('app.js');
  assert.match(app, /rel: 'noopener noreferrer'/);
  assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(app), 'app.js makes network calls');
  assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|sendBeacon|EventSource/.test(read('engine.js')), 'engine.js makes network calls');
  assert.ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(app), 'app stores data in the browser');
  const html = read('index.html');
  assert.ok(!/(?:src|href)="https?:\/\//.test(html), 'page loads something from another website');
});

test('Security: no API keys or secrets in any shipped file', () => {
  for (const f of ['app.js', 'engine.js', 'sw.js', 'index.html', 'manifest.webmanifest', '_headers']) {
    const t = read(f);
    assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(t), f);
    assert.ok(!/\bsk-[A-Za-z0-9_-]{20,}/.test(t), f);
    assert.ok(!/api[_-]?key\s*[:=]\s*['"][A-Za-z0-9]/i.test(t), f);
  }
});

test('Security: the _headers file policy matches the server policy', () => {
  const { CSP } = require('../server.js');
  const headers = read('_headers');
  assert.ok(headers.includes('Content-Security-Policy: ' + CSP), '_headers CSP differs from server.js');
});
