'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createServer, resolveSegments } = require('../server.js');

const PUBLIC = path.join(__dirname, '..', 'public');
const SERVER_JS = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
const PACKAGE_JSON = fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8');

function listen(server) {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}

// http.request sends the path exactly as written (unlike fetch, which tidies "..").
function request(port, reqPath, method) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: reqPath, method: method || 'GET' }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    req.end();
  });
}

let server;
let port;
test.before(async () => {
  server = createServer(PUBLIC);
  port = await listen(server);
});
test.after(() => server.close());

test('Server: serves the app files with correct types', async () => {
  const cases = [
    ['/', 'text/html'],
    ['/index.html', 'text/html'],
    ['/engine.js', 'text/javascript'],
    ['/app.js', 'text/javascript'],
    ['/sw.js', 'text/javascript'],
    ['/styles.css', 'text/css'],
    ['/manifest.webmanifest', 'application/manifest+json'],
    ['/icons/icon-192.png', 'image/png'],
    ['/favicon.svg', 'image/svg+xml'],
  ];
  for (const [p, type] of cases) {
    const r = await request(port, p);
    assert.equal(r.status, 200, p);
    assert.ok(r.headers['content-type'].startsWith(type), p + ' -> ' + r.headers['content-type']);
  }
  const home = await request(port, '/');
  assert.match(home.body, /VICE <span>MOMENT<\/span> FINDER/);
  const withQuery = await request(port, '/index.html?x=1#frag');
  assert.equal(withQuery.status, 200);
});

test('Server: security headers are present', async () => {
  const r = await request(port, '/');
  assert.equal(r.headers['x-content-type-options'], 'nosniff');
  assert.match(r.headers['content-security-policy'], /default-src 'self'/);
  assert.match(r.headers['content-security-policy'], /script-src 'self'/);
  assert.match(r.headers['content-security-policy'], /frame-ancestors 'none'/);
  assert.equal(r.headers['referrer-policy'], 'no-referrer');
  assert.match(r.headers['permissions-policy'], /camera=\(\)/);
  const sw = await request(port, '/sw.js');
  assert.equal(sw.headers['cache-control'], 'no-cache');
});

test('Server: path traversal is blocked (nothing outside public/ is ever returned)', async () => {
  const attacks = [
    '/../server.js',
    '/../package.json',
    '/..%2fserver.js',
    '/%2e%2e/server.js',
    '/%2e%2e%2fserver.js',
    '/..%5cserver.js',
    '/%2e%2e%5cserver.js',
    '/....//server.js',
    '/%252e%252e/server.js',
    '/%252e%252e%252fserver.js',
    '/icons/../../server.js',
    '/icons/%2e%2e/%2e%2e/server.js',
    '/./../server.js',
    '//server.js',
    '///etc/passwd',
    '/..;/server.js',
    '/index.html%00.png',
    '/%00',
    '/engine.js%00../../server.js',
    '/..\\server.js',
    '/%c0%ae%c0%ae/server.js',
    '/.env',
    '/.git/config',
    '/icons/.hidden.png',
    '/../test/server.test.js',
    '/etc/passwd',
    '/../../../../../../etc/passwd',
  ];
  for (const a of attacks) {
    const r = await request(port, a);
    assert.ok([400, 403, 404].includes(r.status), a + ' -> ' + r.status);
    assert.ok(!r.body.includes('createServer'), a + ' leaked server.js');
    assert.ok(!r.body.includes('"scripts"'), a + ' leaked package.json');
    assert.ok(!r.body.includes('root:'), a + ' leaked /etc/passwd');
  }
});

test('Server: malformed URLs, directories and unknown types are rejected', async () => {
  assert.equal((await request(port, '/%E0%A4%A')).status, 400);
  assert.equal((await request(port, '/%')).status, 400);
  assert.equal((await request(port, '/icons/')).status, 404);
  assert.equal((await request(port, '/icons')).status, 404);
  assert.equal((await request(port, '/nothing-here.js')).status, 404);
  assert.equal((await request(port, '/server.js')).status, 404, 'server.js is outside public/');
  assert.equal((await request(port, '/' + 'a'.repeat(3000))).status, 414);
});

test('Server: only GET and HEAD are allowed', async () => {
  for (const m of ['POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']) {
    const r = await request(port, '/', m);
    assert.equal(r.status, 405, m);
    assert.equal(r.headers.allow, 'GET, HEAD');
  }
  const head = await request(port, '/', 'HEAD');
  assert.equal(head.status, 200);
  assert.equal(head.body, '');
});

test('Server: a symlink inside public/ cannot be used to read files outside it', async () => {
  const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'vmf-outside-'));
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'vmf-root-'));
  fs.writeFileSync(path.join(outside, 'secret.txt'), 'TOP-SECRET-DATA');
  fs.writeFileSync(path.join(root, 'ok.txt'), 'fine');
  fs.symlinkSync(path.join(outside, 'secret.txt'), path.join(root, 'link.txt'));
  fs.symlinkSync(outside, path.join(root, 'dirlink'));
  const s = createServer(root);
  const p = await listen(s);
  try {
    assert.equal((await request(p, '/ok.txt')).body, 'fine');
    for (const url of ['/link.txt', '/dirlink/secret.txt']) {
      const r = await request(p, url);
      assert.ok([403, 404].includes(r.status), url + ' -> ' + r.status);
      assert.ok(!r.body.includes('TOP-SECRET-DATA'), url + ' leaked the secret');
    }
  } finally {
    s.close();
    fs.rmSync(outside, { recursive: true, force: true });
    fs.rmSync(root, { recursive: true, force: true });
  }
});

test('Server: resolveSegments unit checks', () => {
  assert.deepEqual(resolveSegments('/').segments, ['index.html']);
  assert.deepEqual(resolveSegments('/icons/icon-192.png').segments, ['icons', 'icon-192.png']);
  assert.deepEqual(resolveSegments('/a//b.js').segments, ['a', 'b.js']);
  assert.equal(resolveSegments('/../x.js').status, 400);
  assert.equal(resolveSegments('/%2e%2e/x.js').status, 400);
  assert.equal(resolveSegments('/a%5cb.js').status, 400);
  assert.equal(resolveSegments('/a%00.js').status, 400);
  assert.equal(resolveSegments('relative.js').status, 400);
  assert.equal(resolveSegments('http://evil.example/x.js').status, 400);
  assert.equal(resolveSegments('/.hidden').status, 404);
  assert.equal(resolveSegments('/' + 'a'.repeat(3000)).status, 414);
});

test('Server: the code holds no hard-coded keys or secrets', () => {
  for (const text of [SERVER_JS, PACKAGE_JSON]) {
    assert.ok(!/AIza[0-9A-Za-z_-]{20,}/.test(text));
    assert.ok(!/sk-[A-Za-z0-9]{20,}/.test(text));
  }
});
