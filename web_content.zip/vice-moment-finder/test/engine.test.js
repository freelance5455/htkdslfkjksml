'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../public/engine.js');
const { makeSrt, makeVtt, makeStream, FILLER } = require('../testkit/gen.js');

const H = 3600000;
const M = 60000;
const S = 1000;

function cue(startMs, text, durMs) {
  return { startMs, endMs: startMs + (durMs || 2500), text };
}

/* ---------------- timestamps ---------------- */
test('parseTimestamp: all supported shapes', () => {
  assert.equal(E.parseTimestamp('00:01:02,500'), 62500);
  assert.equal(E.parseTimestamp('1:02:03'), 3723000);
  assert.equal(E.parseTimestamp('02:03'), 123000);
  assert.equal(E.parseTimestamp('00:00:01.5'), 1500);
  assert.equal(E.parseTimestamp('00:00:01,05'), 1050);
  assert.equal(E.parseTimestamp('00:00:01,999'), 1999);
  assert.equal(E.parseTimestamp('75:30'), 4530000);
  assert.equal(E.parseTimestamp('07:59:59,999'), 8 * H - 1);
});

test('parseTimestamp: rejects invalid values', () => {
  for (const bad of ['abc', '1:75', '00:61:00', '', '12', '1:2:3', '00:00:61', null]) {
    assert.equal(E.parseTimestamp(bad), null, String(bad));
  }
});

test('formatTime: always H:MM:SS and floors fractions', () => {
  assert.equal(E.formatTime(0), '0:00:00');
  assert.equal(E.formatTime(59.9), '0:00:59');
  assert.equal(E.formatTime(3600), '1:00:00');
  assert.equal(E.formatTime(7 * 3600 + 5 * 60 + 9), '7:05:09');
  assert.equal(E.formatTime(-5), '0:00:00');
});

/* ---------------- parsing and cue counts ---------------- */
function plain(n) {
  return Array.from({ length: n }, (_, i) => cue(i * 3000, 'line number ' + i));
}

test('SRT: 471 and 472 cues are counted exactly (cue-count regression)', () => {
  for (const n of [471, 472]) {
    const r = E.parseTranscript(makeSrt(plain(n)));
    assert.equal(r.format, 'srt');
    assert.equal(r.cues.length, n);
    assert.equal(r.stats.timingLines, n);
  }
});

test('SRT: count is the same with no trailing newline, CRLF, BOM or missing blank lines', () => {
  const base = plain(472);
  const variants = {
    noTrailingNewline: makeSrt(base, { trailingNewline: false }),
    crlf: makeSrt(base, { eol: '\r\n' }),
    bom: '﻿' + makeSrt(base),
    noBlankLines: makeSrt(base, { noBlankLines: true }),
  };
  for (const [name, text] of Object.entries(variants)) {
    const r = E.parseTranscript(text);
    assert.equal(r.cues.length, 472, name);
    assert.equal(r.cues[471].text, 'line number 471', name);
    assert.equal(r.cues[0].text, 'line number 0', name);
  }
});

test('SRT: index numbers never leak into cue text when blank lines are missing', () => {
  const r = E.parseTranscript(makeSrt(plain(50), { noBlankLines: true }));
  for (const c of r.cues) assert.ok(!/\d+$/.test(c.text.replace(/line number \d+$/, '')), c.text);
  assert.equal(r.cues[9].text, 'line number 9');
});

test('SRT: multi-line cues, tags and entities are cleaned', () => {
  const text = '1\n00:00:01,000 --> 00:00:03,000\n<i>hello</i> &amp; welcome\nsecond {\\an8}line\n\n2\n00:00:04,000 --> 00:00:05,000\nok\n';
  const r = E.parseTranscript(text);
  assert.equal(r.cues.length, 2);
  assert.equal(r.cues[0].text, 'hello & welcome second line');
});

test('SRT: fractional milliseconds survive parsing exactly', () => {
  const r = E.parseTranscript('1\n01:00:00,999 --> 01:00:05,001\nhello there\n');
  assert.equal(r.cues[0].startMs, 3600999);
  assert.equal(r.cues[0].endMs, 3605001);
});

test('SRT: out-of-order cues are sorted and a warning is given', () => {
  const text = '1\n00:00:10,000 --> 00:00:11,000\nb\n\n2\n00:00:05,000 --> 00:00:06,000\na\n';
  const r = E.parseTranscript(text);
  assert.deepEqual(r.cues.map((c) => c.text), ['a', 'b']);
  assert.ok(r.warnings.some((w) => /time order/.test(w)));
});

test('VTT: header, NOTE/STYLE blocks, ids, short timestamps and settings', () => {
  const text = 'WEBVTT - title\n\nNOTE this is a comment\n\nSTYLE\n::cue { color: red }\n\nintro\n00:01.500 --> 00:03.000 align:start position:0%\nhello\n\n01:00:00.250 --> 01:00:02.000\nwow <c.colorE5E5E5>nice</c>\n';
  const r = E.parseTranscript(text);
  assert.equal(r.format, 'vtt');
  assert.equal(r.cues.length, 2);
  assert.equal(r.cues[0].startMs, 1500);
  assert.equal(r.cues[1].startMs, 3600250);
  assert.equal(r.cues[1].text, 'wow nice');
});

test('VTT: YouTube rolling caption repeats are merged, real repeats kept', () => {
  const rolling =
    'WEBVTT\n\n00:00:01.000 --> 00:00:03.000\nhello everyone\n\n00:00:03.000 --> 00:00:03.010\nhello everyone\n\n00:00:03.010 --> 00:00:05.000\nhello everyone\nwelcome to the stream\n\n00:00:05.000 --> 00:00:05.010\nwelcome to the stream\n';
  const r = E.parseTranscript(rolling);
  assert.deepEqual(r.cues.map((c) => c.text), ['hello everyone', 'welcome to the stream']);
  const real = E.parseTranscript('WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nno\n\n00:00:02.000 --> 00:00:03.000\nno\n\n00:00:03.000 --> 00:00:04.000\nno\n');
  assert.equal(real.cues.length, 3, 'a streamer saying "no" three times keeps three cues');
});

test('Pasted: inline timestamps, brackets, dashes and timestamp-on-its-own-line layouts', () => {
  const inline = E.parseTranscript('0:00:05 so we start\n0:00:09 - garage time\n[1:02:03] later on\n');
  assert.equal(inline.format, 'pasted');
  assert.deepEqual(inline.cues.map((c) => c.startMs), [5000, 9000, 3723000]);
  assert.equal(inline.cues[1].text, 'garage time');
  const own = E.parseTranscript('0:00\nhello everyone\n0:03\nwelcome\nto the stream\n0:07\nbye\n');
  assert.equal(own.cues.length, 3);
  assert.equal(own.cues[1].text, 'welcome to the stream');
  assert.equal(own.cues[0].endMs, 3000);
  assert.equal(own.cues[2].endMs, 7000 + 4000);
});

test('Pasted: a long silence gap does not stretch a cue past 10 seconds', () => {
  const r = E.parseTranscript('0:00:00 first\n0:05:00 second\n');
  assert.equal(r.cues[0].endMs, 10000);
});

test('Parsing: friendly errors for empty, binary and timestamp-less input', () => {
  assert.throws(() => E.parseTranscript(''), /empty/i);
  assert.throws(() => E.parseTranscript('   \n  '), /empty/i);
  assert.throws(() => E.parseTranscript('abc\u0000def'), /binary/i);
  assert.throws(() => E.parseTranscript('just some words with no times at all'), /timestamped/i);
  assert.throws(() => E.parseTranscript(12345), /No transcript/);
});

/* ---------------- file validation and size limits ---------------- */
test('validateFileMeta: type and size limits', () => {
  assert.equal(E.validateFileMeta({ name: 'stream.SRT', size: 1000 }), true);
  assert.equal(E.validateFileMeta({ name: 'a.vtt', size: E.LIMITS.maxBytes }), true);
  assert.throws(() => E.validateFileMeta({ name: 'a.vtt', size: E.LIMITS.maxBytes + 1 }), /larger/);
  assert.throws(() => E.validateFileMeta({ name: 'virus.exe', size: 10 }), /\.srt/);
  assert.throws(() => E.validateFileMeta({ name: 'x.html', size: 10 }), /\.srt/);
  assert.throws(() => E.validateFileMeta({ name: 'noext', size: 10 }), /\.srt/);
  assert.throws(() => E.validateFileMeta({ name: 'a.srt', size: 0 }), /empty/);
  assert.throws(() => E.validateFileMeta({ name: 'a.srt', size: NaN }), /size/);
});

test('validateText: rejects text over the size limit', () => {
  assert.throws(() => E.parseTranscript('0:00:01 x\n' + 'a'.repeat(E.LIMITS.maxBytes)), /larger/);
});

/* ---------------- YouTube links ---------------- */
test('extractVideoId: accepts real YouTube URL shapes', () => {
  const id = 'dQw4w9WgXcQ';
  const ok = [
    'https://www.youtube.com/watch?v=' + id,
    'https://youtube.com/watch?v=' + id + '&t=100s',
    'http://m.youtube.com/watch?v=' + id,
    'https://youtu.be/' + id,
    'https://youtu.be/' + id + '?si=abc',
    'https://www.youtube.com/live/' + id + '?feature=share',
    'https://www.youtube.com/embed/' + id,
    'https://www.youtube.com/shorts/' + id,
    'https://music.youtube.com/watch?v=' + id,
    'youtube.com/watch?v=' + id,
    '  ' + id + '  ',
  ];
  for (const u of ok) assert.equal(E.extractVideoId(u), id, u);
});

test('extractVideoId: rejects look-alike hosts, bad ids and dangerous schemes', () => {
  const id = 'dQw4w9WgXcQ';
  const bad = [
    'https://youtube.com.evil.com/watch?v=' + id,
    'https://evil.com/watch?v=' + id,
    'https://notyoutube.com/watch?v=' + id,
    'https://youtu.be.evil.com/' + id,
    'javascript:alert(1)',
    'data:text/html,hi',
    'ftp://youtube.com/watch?v=' + id,
    'https://www.youtube.com/watch?v=short',
    'https://www.youtube.com/watch?v=' + id + 'EXTRA',
    'https://www.youtube.com/watch',
    'https://www.youtube.com/watch?v=<script>x</script>',
    '',
    null,
    'a'.repeat(400),
  ];
  for (const u of bad) assert.equal(E.extractVideoId(u), null, String(u).slice(0, 60));
});

test('youtubeLink: builds &t=Ns links, floors fractions, refuses bad ids', () => {
  assert.equal(E.youtubeLink('dQw4w9WgXcQ', 3600), 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=3600s');
  assert.equal(E.youtubeLink('dQw4w9WgXcQ', 3600.999), 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=3600s');
  assert.equal(E.youtubeLink('dQw4w9WgXcQ', -4), 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=0s');
  assert.equal(E.youtubeLink('bad id', 5), null);
  assert.equal(E.youtubeLink('"><script>', 5), null);
});

/* ---------------- detection ---------------- */
function lines(...texts) {
  return texts.map((t, i) => ({ text: t, durMs: 2500 }));
}

const PLANTED = [
  { atMs: 1 * H + 10 * M + 5 * S + 500, lines: lines('bhai police aa gayi bhaago bhaago', 'five stars wanted yaar helicopter bhi aa gaya', 'chase chal rahi hai') },
  { atMs: 2 * H + 30 * M + 10 * S + 250, lines: lines('WTF! no no no', 'my car crashed boom the whole car blew up') },
  { atMs: 3 * H + 45 * M, lines: lines('haha hahaha I am dying lol', 'that was so funny bro what') },
  { atMs: 5 * H + 5 * M + 30 * S, lines: lines('glitch! what happened I am flying', 'how did that happen I am stuck under the map') },
  { atMs: 6 * H + 20 * M + 40 * S, lines: lines('mar gaya yaar headshot', 'I died he sniped me') },
];

function near(m, atMs, tolMs) {
  return m.startMs >= atMs - tolMs && m.startMs <= atMs + tolMs;
}

test('Detection: finds every planted moment in an 8-hour stream, with the right category', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  assert.ok(cues.length > 6000, 'stream has ' + cues.length + ' cues');
  const r = E.analyze(cues, { count: 20, videoId: 'dQw4w9WgXcQ' });
  const expectations = [
    [PLANTED[0].atMs, 'police'],
    [PLANTED[1].atMs, 'crash'],
    [PLANTED[2].atMs, 'funny'],
    [PLANTED[3].atMs, 'glitch'],
    [PLANTED[4].atMs, 'death'],
  ];
  for (const [at, cat] of expectations) {
    const m = r.moments.find((x) => near(x, at, 6000));
    assert.ok(m, 'moment near ' + E.formatTime(at / 1000) + ' was not found');
    assert.ok(m.categories.includes(cat), 'expected ' + cat + ' in ' + m.categories.join(',') + ' near ' + E.formatTime(at / 1000));
  }
});

test('Detection: ordinary talking produces no moments (no false alarms)', () => {
  const cues = makeStream({ hours: 4, planted: [] });
  const r = E.analyze(cues, { count: 30 });
  assert.equal(r.moments.length, 0);
  assert.ok(r.notes.some((n) => /Only 0/.test(n)));
});

test('Detection: never pads the list with weak guesses', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  const r = E.analyze(cues, { count: 50 });
  assert.equal(r.moments.length, 5);
});

test('Detection: first-pass category samples', () => {
  const samples = {
    funny: 'hahaha lmao that is hilarious',
    rage: 'what the fuck are you kidding me',
    glitch: 'glitch glitched I fell through the map',
    police: 'five stars the cops started a chase',
    crash: 'crashed smashed flipped exploded',
    death: 'I died headshot wasted',
    crazy: 'insane clutch no way unbelievable',
    surprise: 'wait what oh my god out of nowhere',
  };
  for (const [cat, text] of Object.entries(samples)) {
    const r = E.analyze([cue(60000, text), cue(80000, 'nothing here')], {});
    assert.equal(r.moments.length, 1, cat);
    assert.ok(r.moments[0].categories.includes(cat), cat + ' got ' + r.moments[0].categories);
  }
});

test('Detection: laughter markers and shouting count as evidence', () => {
  const r1 = E.analyze([cue(1000, '[Laughter]'), cue(4000, 'hmm okay')], {});
  assert.equal(r1.moments.length, 1);
  assert.equal(r1.moments[0].category, 'funny');
  const r2 = E.analyze([cue(1000, 'NOOOO WHAT IS THAT!!!'), cue(4000, 'hmm okay')], {});
  assert.equal(r2.moments.length, 1);
  assert.ok(r2.moments[0].categories.includes('viral'));
});

test('Detection: Hindi (Devanagari) and Hinglish words, and the language switch', () => {
  const deva = [cue(5000, 'पुलिस पीछे पड़ गई भागो भागो'), cue(9000, 'ठीक है')];
  assert.equal(E.analyze(deva, { language: 'hindi' }).moments.length, 1);
  assert.equal(E.analyze(deva, { language: 'auto' }).moments.length, 1);
  assert.equal(E.analyze(deva, { language: 'english' }).moments.length, 0);
  const hinglish = [cue(5000, 'bhai wo pakda gaya bhago bhago'), cue(9000, 'okay')];
  assert.equal(E.analyze(hinglish, { language: 'hinglish' }).moments.length, 1);
  assert.equal(E.analyze(hinglish, { language: 'hindi' }).moments.length, 1);
  assert.equal(E.analyze(hinglish, { language: 'english' }).moments.length, 0);
  // "police" is a shared gaming word, so it is found in every language mode
  const shared = [cue(5000, 'police police chase'), cue(9000, 'okay')];
  for (const language of ['auto', 'english', 'hindi', 'hinglish']) assert.equal(E.analyze(shared, { language }).moments.length, 1, language);
  assert.ok(E.analyze(deva, {}).stats.script.devanagariRatio > 0.9);
});

test('Detection: matched words are whole words (no matches inside other words)', () => {
  const r = E.analyze([cue(1000, 'the scrimmage was a cropped dead-end bugle'), cue(5000, 'okay')], {});
  assert.equal(r.moments.length, 0, JSON.stringify(r.moments.map((m) => m.evidence.matchedTerms)));
});

test('Detection: Object prototype names in a transcript cannot break scoring', () => {
  const r = E.analyze([cue(1000, 'constructor __proto__ toString hasOwnProperty crash'), cue(5000, 'okay')], {});
  assert.equal(r.moments.length, 1);
});

/* ---------------- timestamps, rounding, padding ---------------- */
function rounded(startMs, endMs, extra) {
  const cues = [cue(startMs - 60000, 'okay then'), { startMs, endMs, text: 'crashed' }, cue(endMs + 60000, 'okay then')];
  return E.analyze(cues.concat(extra || []), { videoId: 'dQw4w9WgXcQ', padSec: 12 }).moments[0];
}

test('Rounding: starts floor, ends ceil, never inside the real cue', () => {
  const m = rounded(3600999, 3605001);
  assert.equal(m.startSec, 3600);
  assert.equal(m.endSec, 3606);
  assert.equal(m.recStartSec, 3588); // 3600.999 - 12 = 3588.999 -> 3588
  assert.equal(m.recEndSec, 3618); // 3605.001 + 12 = 3617.001 -> 3618
  assert.equal(m.startText, '1:00:00');
  assert.equal(m.endText, '1:00:06');
  assert.ok(m.link.endsWith('&t=3600s'));
  assert.ok(m.recLink.endsWith('&t=3588s'));
});

test('Rounding: whole-second boundaries are not shifted', () => {
  const m = rounded(7200000, 7203000);
  assert.equal(m.startSec, 7200);
  assert.equal(m.endSec, 7203);
  assert.equal(m.recStartSec, 7188);
  assert.equal(m.recEndSec, 7215);
});

test('Rounding: many random fractional times stay within one second of the truth', () => {
  let seed = 7;
  const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
  for (let i = 0; i < 300; i++) {
    const start = 120000 + Math.floor(rnd() * 7 * H);
    const end = start + 1000 + Math.floor(rnd() * 5000);
    const m = rounded(start, end);
    assert.ok(m.startSec * 1000 <= start && start - m.startSec * 1000 < 1000, 'start ' + start);
    assert.ok(m.endSec * 1000 >= end && m.endSec * 1000 - end < 1000, 'end ' + end);
    assert.ok(m.recStartSec * 1000 <= start - 12000 && start - 12000 - m.recStartSec * 1000 < 1000, 'rec start ' + start);
    assert.ok(m.recEndSec * 1000 >= end + 12000 && m.recEndSec * 1000 - end - 12000 < 1000, 'rec end ' + end);
  }
});

test('Padding: 10, 12 and 15 seconds, and out-of-range values are clamped to 10-15', () => {
  const at = 600000;
  const mk = (padSec) => E.analyze([cue(at - 60000, 'okay'), cue(at, 'crashed', 3000), cue(at + 60000, 'okay')], { padSec }).moments[0];
  assert.equal(mk(10).recStartSec, 590);
  assert.equal(mk(10).recEndSec, 613);
  assert.equal(mk(12).recStartSec, 588);
  assert.equal(mk(15).recStartSec, 585);
  assert.equal(mk(15).recEndSec, 618);
  assert.equal(mk(5).recStartSec, 590, 'clamped up to 10');
  assert.equal(mk(99).recStartSec, 585, 'clamped down to 15');
  assert.equal(mk('abc').recStartSec, 588, 'default 12');
});

test('Padding: the window never starts before 0:00:00 or ends after the transcript', () => {
  const early = E.analyze([cue(3000, 'crashed'), cue(40000, 'okay')], {}).moments[0];
  assert.equal(early.recStartSec, 0);
  const late = E.analyze([cue(1000, 'okay'), cue(100000, 'crashed', 2000)], {}).moments[0];
  assert.equal(late.recEndSec, 102);
});

test('Padding: a recording window is about 24 seconds longer than the moment', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  const r = E.analyze(cues, { padSec: 12 });
  for (const m of r.moments) {
    const momentLen = m.endSec - m.startSec;
    assert.ok(m.recDurationSec >= momentLen + 23 && m.recDurationSec <= momentLen + 26, m.recDurationSec + ' vs ' + momentLen);
    assert.ok(m.endMs - m.startMs <= E.MAX_MOMENT_MS + 5000, 'moment too long');
  }
});

/* ---------------- honesty: no invented timestamps ---------------- */
test('Honesty: every moment start/end is a real cue time; nothing is claimed as visually verified', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  const starts = new Set(cues.map((c) => c.startMs));
  const ends = new Set(cues.map((c) => c.endMs));
  const r = E.analyze(cues, { videoId: 'dQw4w9WgXcQ' });
  assert.ok(r.moments.length > 0);
  for (const m of r.moments) {
    assert.ok(starts.has(m.startMs), 'start ' + m.startMs + ' is not a cue start');
    assert.ok(ends.has(m.endMs), 'end ' + m.endMs + ' is not a cue end');
    assert.equal(m.evidence.visuallyVerified, false);
    assert.equal(m.evidence.chatChecked, false);
    assert.equal(m.evidence.source, 'transcript');
    assert.match(m.evidenceText, /not visually verified/);
    assert.ok(m.confidence > 0 && m.confidence <= 92, 'confidence ' + m.confidence);
    assert.ok(m.description.length > 0 && m.why.length > 0);
    assert.ok(m.link.startsWith('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t='));
  }
});

test('Honesty: with no video link, no link is invented', () => {
  const r = E.analyze([cue(1000, 'crashed'), cue(9000, 'okay')], {});
  assert.equal(r.moments[0].link, null);
  assert.ok(r.notes.some((n) => /No valid YouTube link/.test(n)));
  const bad = E.analyze([cue(1000, 'crashed'), cue(9000, 'okay')], { videoId: 'nope' });
  assert.equal(bad.moments[0].link, null);
});

/* ---------------- duplicates and chunking ---------------- */
test('Duplicates: nearby hits become one moment, distant hits stay separate', () => {
  const near = E.analyze([cue(100000, 'crashed boom'), cue(105000, 'it blew up'), cue(112000, 'wrecked'), cue(200000, 'okay')], {});
  assert.equal(near.moments.length, 1);
  const far = E.analyze([cue(100000, 'crashed boom'), cue(400000, 'it blew up'), cue(800000, 'okay')], {});
  assert.equal(far.moments.length, 2);
  const edge = E.analyze([cue(100000, 'crashed', 2000), cue(130000, 'crashed', 2000), cue(200000, 'okay')], {});
  assert.equal(edge.moments.length, 2, '28 s apart is outside the 20 s duplicate gap');
});

test('Duplicates: mergeMoments merges overlapping and keeps the best score', () => {
  const mk = (startMs, endMs, score, cat) => ({ startMs, endMs, score, categories: [cat], terms: [cat], primary: cat, mergedFrom: 1 });
  const merged = E.mergeMoments([mk(0, 5000, 2, 'funny'), mk(3000, 8000, 5, 'crash'), mk(60000, 65000, 1, 'death')]);
  assert.equal(merged.length, 2);
  assert.equal(merged[0].score, 5);
  assert.deepEqual(merged[0].categories.sort(), ['crash', 'funny']);
  assert.equal(merged[0].mergedFrom, 2);
  assert.equal(E.mergeMoments([]).length, 0);
});

test('Chunking: a moment on a chunk boundary appears once; chunk size does not lose moments', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED.concat([{ atMs: 2 * H, lines: lines('crashed boom', 'blew up wrecked') }]) });
  const whole = E.analyze(cues, { count: 50, chunkMs: 24 * H });
  const tiny = E.analyze(cues, { count: 50, chunkMs: 60000 });
  const boundary = E.analyze(cues, { count: 50, chunkMs: 2 * H });
  assert.equal(whole.stats.chunks, 1);
  assert.ok(tiny.stats.chunks > 400);
  assert.equal(tiny.moments.length, whole.moments.length);
  assert.equal(boundary.moments.length, whole.moments.length);
  assert.deepEqual(tiny.moments.map((m) => m.startMs).sort(), whole.moments.map((m) => m.startMs).sort());
  const starts = whole.moments.map((m) => m.startMs);
  assert.equal(new Set(starts).size, starts.length);
});

test('Ranking: moments are returned best first with ranks 1..N and a count limit', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  const r = E.analyze(cues, { count: 3 });
  assert.equal(r.moments.length, 3);
  assert.deepEqual(r.moments.map((m) => m.rank), [1, 2, 3]);
  assert.ok(r.moments[0].score >= r.moments[1].score && r.moments[1].score >= r.moments[2].score);
});

test('Options: count is clamped to 1-50 and bad input falls back to defaults', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  assert.equal(E.analyze(cues, { count: 0 }).options.count, 1);
  assert.equal(E.analyze(cues, { count: 999 }).options.count, 50);
  assert.equal(E.analyze(cues, { count: 'x' }).options.count, 20);
  assert.equal(E.analyze(cues, { language: 'klingon' }).options.language, 'auto');
  assert.throws(() => E.analyze([], {}), /no transcript lines/i);
  assert.throws(() => E.analyze(null, {}), /no transcript lines/i);
});

/* ---------------- end to end with files ---------------- */
test('End to end: 8-hour SRT and VTT files give the same moments as the raw cues', () => {
  const cues = makeStream({ hours: 8, planted: PLANTED });
  const direct = E.analyze(cues, { videoId: 'dQw4w9WgXcQ' });
  for (const text of [makeSrt(cues), makeSrt(cues, { eol: '\r\n' }), makeVtt(cues)]) {
    const parsed = E.parseTranscript(text);
    assert.equal(parsed.cues.length, cues.length);
    const r = E.analyze(parsed.cues, { videoId: 'dQw4w9WgXcQ' });
    assert.deepEqual(r.moments.map((m) => [m.startSec, m.recStartSec, m.recEndSec]), direct.moments.map((m) => [m.startSec, m.recStartSec, m.recEndSec]));
  }
});

/* ---------------- large inputs ---------------- */
test('Large file: 100,000 cues parse and analyse in a few seconds', () => {
  const cues = makeStream({ hours: 100, planted: PLANTED });
  const text = makeSrt(cues);
  assert.ok(text.length > 4 * 1024 * 1024, 'file is ' + text.length + ' bytes');
  assert.ok(text.length < E.LIMITS.maxBytes);
  const t0 = process.hrtime.bigint();
  const parsed = E.parseTranscript(text);
  const r = E.analyze(parsed.cues, { count: 30 });
  const ms = Number(process.hrtime.bigint() - t0) / 1e6;
  console.log('    100k-cue file: ' + (text.length / 1048576).toFixed(1) + ' MB, ' + parsed.cues.length + ' cues, parse+analyse ' + Math.round(ms) + ' ms');
  assert.equal(parsed.cues.length, cues.length);
  assert.ok(r.moments.length >= 5);
  assert.ok(ms < 15000, 'took ' + ms + ' ms');
});

test('Large file: more cues than the limit is refused with a clear message', () => {
  const big = [];
  for (let i = 0; i < E.LIMITS.maxCues + 1; i++) big.push(i + ':00:01 x');
  const lines2 = Array.from({ length: E.LIMITS.maxCues + 1 }, (_, i) => '0:00:01 x' + i).join('\n');
  assert.ok(lines2.length < E.LIMITS.maxBytes);
  assert.throws(() => E.parseTranscript(lines2), /more than/);
});

/* ---------------- export ---------------- */
test('Export TXT: includes times, links and the honest scope line', () => {
  const r = E.analyze(makeStream({ hours: 8, planted: PLANTED }), { videoId: 'dQw4w9WgXcQ' });
  const txt = E.toTXT(r, { source: 'stream.srt', videoId: 'dQw4w9WgXcQ' });
  assert.match(txt, /transcript text only; no video, audio or chat was analysed/);
  assert.match(txt, /Source: stream\.srt/);
  assert.equal((txt.match(/^#\d+ /gm) || []).length, r.moments.length);
  assert.match(txt, /Moment: 1:10:0\d - /);
  assert.match(txt, /Link: https:\/\/www\.youtube\.com\/watch\?v=dQw4w9WgXcQ&t=\d+s/);
});

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (ch === '"') q = false;
      else cell += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\r') { /* skip */ }
    else if (ch === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  return rows;
}

test('Export CSV: correct columns and row count; commas, quotes, newlines and Hindi round-trip', () => {
  const cues = [cue(5000, 'she said "crash, boom"\nnext line पुलिस crashed'), cue(40000, 'okay')];
  const r = E.analyze(cues, { videoId: 'dQw4w9WgXcQ' });
  const rows = parseCsv(E.toCSV(r));
  assert.equal(rows.length, 1 + r.moments.length);
  assert.equal(rows[0].length, 16);
  assert.ok(rows.every((x) => x.length === 16));
  assert.equal(rows[1][2], r.moments[0].startText);
  assert.equal(rows[1][6], String(r.moments[0].startSec));
  assert.match(rows[1][11], /पुलिस/);
  assert.match(rows[1][11], /"crash, boom"/);
});

test('Export CSV: spreadsheet formula injection is neutralised', () => {
  const r = E.analyze([cue(5000, '=HYPERLINK("http://evil","x") crashed'), cue(60000, '+cmd|calc crashed', 2000), cue(200000, '@SUM(1) crashed'), cue(400000, '-2+3 crashed')], {});
  const rows = parseCsv(E.toCSV(r));
  assert.ok(rows.length >= 4);
  for (const row of rows.slice(1)) assert.ok(!/^[=+\-@]/.test(row[11]), 'description starts with ' + row[11][0]);
});
