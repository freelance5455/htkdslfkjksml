'use strict';
// Transcript file loading logic: types, sizes, encodings, Hindi text.
const test = require('node:test');
const assert = require('node:assert/strict');
const L = require('../public/loader.js');
const E = require('../public/engine.js');

const bytes = (s) => new Uint8Array(Buffer.from(s, 'utf8'));
const throwsCode = (fn, code) => assert.throws(fn, (e) => e instanceof L.LoadError && e.code === code && e.userMessage.length > 10, code);

test('checkMeta: .srt, .vtt and .txt (any letter case) are accepted', () => {
  for (const n of ['a.srt', 'A.SRT', 'b.vtt', 'c.txt', 'my stream.final.Txt']) L.checkMeta(n, 100);
});

test('checkMeta: wrong types, empty, oversized and unreadable sizes get friendly errors', () => {
  throwsCode(() => L.checkMeta('photo.png', 10), 'bad-type');
  throwsCode(() => L.checkMeta('noextension', 10), 'bad-type');
  throwsCode(() => L.checkMeta('a.srt', 0), 'empty');
  throwsCode(() => L.checkMeta('a.srt', L.MAX_BYTES + 1), 'too-big');
  throwsCode(() => L.checkMeta('a.srt', NaN), 'bad-size');
  L.checkMeta('a.srt', L.MAX_BYTES);
});

test('decodeBytes: Hindi / Devanagari / Hinglish text survives exactly', () => {
  const text = '1\n00:00:05,000 --> 00:00:08,000\nपुलिस पीछे पड़ गई भागो भागो 😂\n\n2\n00:00:20,000 --> 00:00:22,000\nbhai ye kya hua\n';
  assert.equal(L.decodeBytes(bytes(text)), text);
});

test('decodeBytes: UTF-8 byte-order mark is removed; UTF-16 files with a mark are decoded', () => {
  assert.equal(L.decodeBytes(Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), Buffer.from('0:00:05 hello')])), '0:00:05 hello');
  const le = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from('0:00:05 नमस्ते', 'utf16le')]);
  assert.equal(L.decodeBytes(le), '0:00:05 नमस्ते');
  const be = Buffer.from(le.slice(2)).swap16();
  assert.equal(L.decodeBytes(Buffer.concat([Buffer.from([0xfe, 0xff]), be])), '0:00:05 नमस्ते');
});

test('decodeBytes: empty, whitespace-only, binary and invalid UTF-8 are refused', () => {
  throwsCode(() => L.decodeBytes(new Uint8Array(0)), 'empty');
  throwsCode(() => L.decodeBytes(bytes('   \n\n  ')), 'empty');
  throwsCode(() => L.decodeBytes(new Uint8Array([0x50, 0x4b, 3, 4, 0, 0, 1])), 'binary');
  throwsCode(() => L.decodeBytes(new Uint8Array([0x30, 0xe9, 0xe9, 0xff])), 'encoding');
});

test('decodeBytes works on an ArrayBuffer as well as a Uint8Array', () => {
  const buf = Buffer.from('0:00:05 hello', 'utf8');
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  assert.equal(L.decodeBytes(ab), '0:00:05 hello');
});

test('describe: format guess and line count', () => {
  assert.equal(L.describe('WEBVTT\n\n00:00:01.000 --> 00:00:02.000\nhi').format, 'VTT');
  assert.equal(L.describe('1\n00:00:01,000 --> 00:00:02,000\nhi').format, 'SRT');
  assert.equal(L.describe('0:00:01 hi\n0:00:03 yo').format, 'plain text');
  assert.equal(L.describe('a\nb\nc').lines, 3);
});

test('Same file twice / several files in a row: decoding is repeatable and independent', () => {
  const a = bytes('0:00:05 bhai police aa gayi bhaago bhaago\n0:01:00 ok');
  const b = bytes('0:00:05 crashed boom\n0:01:00 ok');
  const t1 = L.decodeBytes(a); const t2 = L.decodeBytes(a); const t3 = L.decodeBytes(b);
  assert.equal(t1, t2);
  assert.notEqual(t1, t3);
});

test('Loaded Hindi / Hinglish / VTT / TXT text goes straight into the engine and is analysed', () => {
  const files = {
    hindi: '1\n00:00:05,000 --> 00:00:08,000\nपुलिस पीछे पड़ गई भागो भागो\n\n2\n00:00:20,000 --> 00:00:22,000\nठीक है\n',
    hinglish: 'WEBVTT\n\n00:00:05.000 --> 00:00:08.000\nbhai ye kya hua gaadi ulat gayi blast ho gaya\n\n00:00:30.000 --> 00:00:32.000\nokay\n',
    txt: '0:00:05 so we are starting\n0:01:10 bhai police aa gayi bhaago bhaago\n0:01:14 five stars chase chal rahi hai\n0:03:00 okay\n',
  };
  for (const [name, t] of Object.entries(files)) {
    const text = L.decodeBytes(bytes(t));
    const parsed = E.parseTranscript(text);
    const r = E.analyze(parsed.cues, {});
    assert.equal(r.moments.length, 1, name);
  }
});

test('A large (5 MB) transcript decodes quickly', () => {
  const line = '00:00:05,000 --> 00:00:08,000\nsome neutral words here\n\n';
  const big = bytes(line.repeat(Math.ceil((5 * 1024 * 1024) / line.length)));
  const t0 = Date.now();
  const text = L.decodeBytes(big);
  assert.ok(text.length > 5 * 1024 * 1024 - 100);
  assert.ok(Date.now() - t0 < 3000);
});
