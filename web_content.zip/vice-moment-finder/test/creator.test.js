'use strict';
// Creator assistant: titles, hooks, captions, hashtags, copy text and exports.
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../public/engine.js');
const C = require('../public/creator.js');

const cue = (startMs, text) => ({ startMs, endMs: startMs + 2500, text });
function moment(text, o) {
  const r = E.analyze([cue(100000, text), cue(130000, 'okay then')], Object.assign({ videoId: 'dQw4w9WgXcQ' }, o || {}));
  return r.moments[0];
}
const DEVA = /[ऀ-ॿ]/;

test('Titles: every category has English, Hinglish and Hindi (Devanagari) titles', () => {
  for (const id of C.TEMPLATE_CATEGORIES) {
    const s = C.suggest({ rank: 1, startMs: 100000, category: id, categories: [id], categoryLabel: id, startText: '0:01:40', endText: '0:01:50', recStartText: '0:01:28', recEndText: '0:02:02', recDurationSec: 34, shortsFit: true, why: 'x' });
    assert.ok(s.titles.english.length > 5, id);
    assert.ok(s.titles.hinglish.length > 5, id);
    assert.match(s.titles.hindi, DEVA, id + ' Hindi title must be Devanagari');
    assert.doesNotMatch(s.titles.english, DEVA, id);
    assert.ok(s.hook.length > 3, id);
    assert.ok(s.sfx.length >= 1 && s.zoom.length > 5 && s.editingStyle.length > 20, id);
  }
});

test('Templates exist for every engine category (none falls back silently)', () => {
  for (const c of E.CATEGORIES) assert.ok(C.TEMPLATE_CATEGORIES.includes(c.id), 'no template for ' + c.id);
});

test('Suggestions are deterministic: the same moment always gives the same text', () => {
  const m = moment('five stars the cops started a chase');
  assert.deepEqual(C.suggest(m), C.suggest(m));
});

test('Different moments can get different titles (variety)', () => {
  const seen = new Set();
  for (let i = 0; i < 12; i++) seen.add(C.suggest({ rank: i + 1, startMs: 100000 + i * 37000, category: 'crash', categories: ['crash'], categoryLabel: 'Car crash', startText: '0:00:00', endText: '0:00:10', recStartText: '0:00:00', recEndText: '0:00:20', recDurationSec: 20, shortsFit: true, why: '' }).titles.english);
  assert.ok(seen.size >= 2);
});

test('Hashtags: start with #, unique, at most 10, include GTA and Shorts, category tags added', () => {
  const m = moment('five stars the cops started a chase');
  const tags = C.hashtagsFor(m);
  assert.ok(tags.length <= 10);
  assert.equal(new Set(tags).size, tags.length);
  for (const t of tags) assert.match(t, /^#[A-Za-z0-9]+$/);
  assert.ok(tags.includes('#GTA') && tags.includes('#Shorts'));
  assert.ok(tags.includes('#PoliceChase'));
});

test('Caption and title lengths are limited; user edits override suggestions', () => {
  const m = moment('my car crashed boom');
  const long = 'x'.repeat(500);
  const s = C.suggest(m, { title: long, caption: long });
  assert.ok(Array.from(s.titles.shorts).length <= 100);
  assert.ok(Array.from(s.caption).length <= 300);
  const s2 = C.suggest(m, { title: 'My own title', caption: 'My own caption' });
  assert.equal(s2.titles.shorts, 'My own title');
  assert.equal(s2.caption, 'My own caption');
});

test('Safety: angle brackets from edits are stripped so titles are never markup', () => {
  const m = moment('my car crashed boom');
  const s = C.suggest(m, { title: '<img src=x onerror=alert(1)> hi', caption: '<script>x</script>' });
  assert.ok(!/[<>]/.test(s.titles.shorts + s.caption));
  assert.equal(C.safe('a<b>c', 10), 'abc');
});

test('Length note follows the recording window (too short / good / too long)', () => {
  const base = { rank: 1, startMs: 1000, category: 'funny', categories: ['funny'], categoryLabel: 'Funny moment', startText: '0:00:01', endText: '0:00:05', recStartText: '0:00:00', recEndText: '0:00:20', why: '' };
  assert.match(C.suggest(Object.assign({ recDurationSec: 12, shortsFit: false }, base)).editingStyle, /only 12 seconds/);
  assert.match(C.suggest(Object.assign({ recDurationSec: 30, shortsFit: true }, base)).editingStyle, /good Shorts length/);
  assert.match(C.suggest(Object.assign({ recDurationSec: 50, shortsFit: false }, base)).editingStyle, /trim it to 20-35 seconds/);
});

test('Honesty: the output says it is template-based, not AI, and not based on the screen', () => {
  const s = C.suggest(moment('my car crashed boom'));
  assert.match(s.note, /fixed templates/);
  assert.match(s.note, /not from AI/);
});

test('Copy fields: 15 individually copyable fields, and a combined copy containing all of them', () => {
  const s = C.suggest(moment('my car crashed boom'));
  const f = C.fields(s);
  assert.equal(f.length, 15);
  for (const [key, label, text] of f) assert.ok(key && label && typeof text === 'string' && text.length > 0, key);
  const all = C.combined(s);
  for (const [, label, text] of f) assert.ok(all.includes(label + ': ' + text.split('\n')[0]), label);
});

test('Recording window text matches the moment (start/end points)', () => {
  const m = moment('my car crashed boom');
  const s = C.suggest(m);
  assert.ok(s.startPoint.includes(m.recStartText));
  assert.ok(s.endPoint.includes(m.recEndText));
  assert.ok(s.recordWindow.includes(m.recStartText) && s.recordWindow.includes(m.recEndText));
});

test('Export: CSV cells from creator text are protected against spreadsheet formulas', () => {
  assert.equal(E.csvCell('=HYPERLINK("x")'), '"\'=HYPERLINK(""x"")"');
  assert.equal(E.csvCell('+1'), '"\'+1"');
  assert.equal(E.csvCell('सामान्य, "text"'), '"सामान्य, ""text"""');
});
