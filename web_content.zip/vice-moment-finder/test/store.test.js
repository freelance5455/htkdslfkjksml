'use strict';
// Local project storage logic (memory backend). The real IndexedDB backend is exercised in tools/run-browser-checks.js.
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../public/engine.js');
const S = require('../public/store.js');

const cue = (startMs, text) => ({ startMs, endMs: startMs + 2500, text });
function project(over) {
  const result = E.analyze([cue(100000, 'my car crashed boom'), cue(400000, 'five stars police chase'), cue(900000, 'ok')], {});
  result.parse = { format: 'srt', warnings: [], cues: new Array(1000).fill({}) }; // cues must NOT be stored
  return Object.assign({ name: 'Stream 1', url: 'https://youtu.be/dQw4w9WgXcQ', videoId: 'dQw4w9WgXcQ', source: 'a.srt', transcriptText: 'hello', selected: { 1: true }, edits: { 1: { title: 'T', notes: 'N', pad: 14, check: { opened: true } } }, result }, over || {});
}

test('Save and list: a saved project appears with its moment and selection counts', async () => {
  const st = S.createStore(S.memoryBackend());
  const r = await st.save(project());
  assert.ok(r.id);
  const list = await st.list();
  assert.equal(list.length, 1);
  assert.equal(list[0].name, 'Stream 1');
  assert.equal(list[0].moments, 2);
  assert.equal(list[0].selected, 1);
});

test('Reload and restore: everything needed to restore the screen comes back unchanged', async () => {
  const st = S.createStore(S.memoryBackend());
  const p = project();
  const { id } = await st.save(p);
  const back = await st.load(id);
  assert.deepEqual(back.result.moments, p.result.moments);
  assert.equal(back.videoId, 'dQw4w9WgXcQ');
  assert.equal(back.transcriptText, 'hello');
  assert.deepEqual(back.selected, { 1: true });
  assert.equal(back.edits['1'].title, 'T');
  assert.equal(back.edits['1'].pad, 14);
  assert.equal(back.edits['1'].check.opened, true);
});

test('Storage is compact: the parsed cue list is not stored, only the format and warnings', async () => {
  const st = S.createStore(S.memoryBackend());
  const { id } = await st.save(project());
  const back = await st.load(id);
  assert.equal(back.result.parse.cues, undefined);
  assert.equal(back.result.parse.format, 'srt');
});

test('Saving again with the same id updates the project instead of adding another', async () => {
  const st = S.createStore(S.memoryBackend());
  const a = await st.save(project());
  await st.save(project({ id: a.id, name: 'Renamed' }));
  const list = await st.list();
  assert.equal(list.length, 1);
  assert.equal(list[0].name, 'Renamed');
});

test('Delete removes one project and leaves the others', async () => {
  const st = S.createStore(S.memoryBackend());
  const a = await st.save(project({ name: 'A' }));
  await st.save(project({ name: 'B' }));
  await st.remove(a.id);
  const list = await st.list();
  assert.deepEqual(list.map((x) => x.name), ['B']);
  await assert.rejects(() => st.load(a.id), /not found/);
});

test('Clear all removes every project', async () => {
  const st = S.createStore(S.memoryBackend());
  await st.save(project({ name: 'A' }));
  await st.save(project({ name: 'B' }));
  await st.clearAll();
  assert.equal((await st.list()).length, 0);
});

test('Validation: no analysis, oversized transcript and damaged records give clear errors', async () => {
  const st = S.createStore(S.memoryBackend());
  await assert.rejects(() => st.save({ name: 'x' }), /no analysis/i);
  await assert.rejects(() => st.save(project({ transcriptText: 'a'.repeat(7 * 1024 * 1024) })), /too large/);
  const b = S.memoryBackend();
  await b.put({ id: 'bad', name: 'x' });
  await assert.rejects(() => S.createStore(b).load('bad'), /damaged/);
});

test('Names are cleaned (no markup) and limited; empty names get a default', async () => {
  const st = S.createStore(S.memoryBackend());
  await st.save(project({ name: '<b>Hi</b>   there' }));
  await st.save(project({ name: '' }));
  await st.save(project({ name: 'x'.repeat(300) }));
  const names = (await st.list()).map((x) => x.name);
  assert.ok(names.includes('bHi/b there'));
  assert.ok(names.includes('Untitled project'));
  assert.ok(names.every((n) => Array.from(n).length <= 80));
});

test('Limit: more than 100 saved projects is refused with a clear message', async () => {
  const st = S.createStore(S.memoryBackend());
  const p = project();
  for (let i = 0; i < S.MAX_PROJECTS; i++) await st.save(Object.assign({}, p, { id: 'id' + i }));
  await assert.rejects(() => st.save(Object.assign({}, p, { id: 'extra' })), /Delete one first/);
  await st.save(Object.assign({}, p, { id: 'id5', name: 'update ok' }));
});

test('Hindi project names and notes round-trip', async () => {
  const st = S.createStore(S.memoryBackend());
  const { id } = await st.save(project({ name: 'स्ट्रीम १', edits: { 1: { notes: 'ज़ूम इन करो' } } }));
  const back = await st.load(id);
  assert.equal(back.name, 'स्ट्रीम १');
  assert.equal(back.edits['1'].notes, 'ज़ूम इन करो');
});

test('Without IndexedDB (plain Node) the store falls back to memory and says so; prefs never throw', () => {
  const st = S.createStore();
  assert.equal(st.kind, 'memory');
  assert.equal(S.idbBackend(), null);
  assert.equal(S.prefs.get('x'), null);
  assert.equal(typeof S.prefs.set('x', 1), 'boolean');
});
