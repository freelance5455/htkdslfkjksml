// Backend tests. YouTube is SIMULATED (tests/helpers/mock-youtube.js); nothing here touches the real YouTube.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from '../server/server.js';
import { extractPlayerResponse, pickTrack, tracksFromPlayerResponse } from '../server/captions.js';
import { makeMockFetch, offlineFetch, VIDEO_OK, VIDEO_NOCAP, VIDEO_PRIVATE, VIDEO_BOT, VIDEO_BLOCKED } from './helpers/mock-youtube.js';

async function withServer(opts, fn) {
  const server = createServer(opts);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try { await fn(base); } finally { await new Promise((r) => server.close(r)); }
}
const get = async (base, p, headers = {}) => { const r = await fetch(base + p, { headers }); return { status: r.status, body: await r.json(), headers: r.headers }; };

test('health endpoint reports capabilities', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const r = await get(b, '/api/health');
    assert.equal(r.body.ok, true);
    assert.equal(typeof r.body.capabilities.publicCaptions, 'boolean');
  });
});

test('TEST 3 (simulated): captions are retrieved, normalised and carry the real timeline', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const r = await get(b, `/api/transcript?v=${VIDEO_OK}&lang=auto`);
    assert.equal(r.body.ok, true);
    assert.equal(r.body.source, 'public-captions');
    assert.equal(r.body.track.lang, 'hi', 'Hindi preferred in auto mode');
    assert.ok(r.body.segments.length > 50);
    const s = r.body.segments;
    assert.ok(s.every((x) => x.end > x.start && typeof x.text === 'string' && x.text.length));
    assert.ok(s.every((x, i) => i === 0 || x.start >= s[i - 1].start), 'sorted by start');
    assert.ok(r.body.availableTracks.length === 2 && !('baseUrl' in r.body.availableTracks[0]), 'internal URLs not leaked');
  });
});

test('explicit language: English manual track selected; missing language is reported, not faked', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const en = await get(b, `/api/transcript?v=${VIDEO_OK}&lang=en`);
    assert.equal(en.body.track.lang, 'en');
    assert.equal(en.body.track.kind, 'manual');
    const fr = await get(b, `/api/transcript?v=${VIDEO_OK}&lang=fr`);
    assert.equal(fr.body.ok, false);
    assert.equal(fr.body.error.code, 'LANG_NOT_AVAILABLE');
    assert.equal(fr.body.segments, undefined);
  });
});

test('TEST 10 (simulated): failed retrieval gives a specific reason and NO transcript text', async () => {
  const cases = [
    [VIDEO_NOCAP, 'NO_CAPTIONS'],
    [VIDEO_PRIVATE, 'VIDEO_UNAVAILABLE'],
    [VIDEO_BOT, 'BOT_CHECK'],
    [VIDEO_BLOCKED, 'CAPTIONS_BLOCKED'],
  ];
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    for (const [id, code] of cases) {
      const r = await get(b, `/api/transcript?v=${id}`);
      assert.equal(r.body.ok, false, id);
      assert.equal(r.body.error.code, code, id);
      assert.ok(r.body.error.message.length > 20);
      assert.equal(r.body.segments, undefined, 'never fabricates segments');
      assert.ok(Array.isArray(r.body.tried) && r.body.tried.length >= 1);
    }
  });
});

test('network failure is reported as NETWORK', async () => {
  await withServer({ fetchImpl: offlineFetch }, async (b) => {
    const r = await get(b, `/api/transcript?v=${VIDEO_OK}`);
    assert.equal(r.body.ok, false);
    assert.equal(r.body.error.code, 'NETWORK');
    assert.match(r.body.error.message, /Could not reach YouTube/);
  });
});

test('invalid video id -> 400', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const r = await get(b, '/api/transcript?v=short');
    assert.equal(r.status, 400);
    assert.equal(r.body.error.code, 'INVALID_URL');
    const m = await get(b, '/api/meta?v=<script>');
    assert.equal(m.status, 400);
  });
});

test('owner OAuth path: good token uses the official API; bad/expired tokens fall back honestly', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const good = await get(b, `/api/transcript?v=${VIDEO_OK}`, { 'x-yt-access-token': 'GOOD' });
    assert.equal(good.body.source, 'owner-api');
    assert.ok(good.body.segments.length > 50);
    const expired = await get(b, `/api/transcript?v=${VIDEO_OK}`, { 'x-yt-access-token': 'EXPIRED' });
    assert.equal(expired.body.source, 'public-captions');
    assert.ok(expired.body.tried.some((t) => t.source === 'owner-api' && t.code === 'TOKEN_INVALID'));
    const denied = await get(b, `/api/transcript?v=${VIDEO_NOCAP}`, { 'x-yt-access-token': 'NOPE' });
    assert.equal(denied.body.ok, false);
    assert.ok(denied.body.tried.some((t) => t.code === 'CAPTION_ACCESS_DENIED'));
  });
});

test('PUBLIC_CAPTIONS=off disables the unofficial provider and says so', async () => {
  await withServer({ fetchImpl: makeMockFetch(), env: { PUBLIC_CAPTIONS: 'off' } }, async (b) => {
    const r = await get(b, `/api/transcript?v=${VIDEO_OK}`);
    assert.equal(r.body.ok, false);
    assert.ok(r.body.tried.some((t) => t.code === 'DISABLED'));
    const ok = await get(b, `/api/transcript?v=${VIDEO_OK}`, { 'x-yt-access-token': 'GOOD' });
    assert.equal(ok.body.ok, true, 'owner API still works');
  });
});

test('meta endpoint (oEmbed)', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const r = await get(b, `/api/meta?v=${VIDEO_OK}`);
    assert.equal(r.body.meta.title, 'GTA RP Live Stream Replay');
    const p = await get(b, `/api/meta?v=${VIDEO_PRIVATE}`);
    assert.equal(p.body.error.code, 'VIDEO_UNAVAILABLE');
  });
});

test('rate limiting and method checks', async () => {
  await withServer({ fetchImpl: makeMockFetch(), rateLimit: 3 }, async (b) => {
    for (let i = 0; i < 3; i++) assert.equal((await get(b, `/api/meta?v=${VIDEO_OK}`)).status, 200);
    assert.equal((await get(b, `/api/meta?v=${VIDEO_OK}`)).status, 429);
    const post = await fetch(`${b}/api/health`, { method: 'POST' });
    assert.equal(post.status, 405);
  });
});

test('static files: app shell served, service worker not cached, path traversal blocked', async () => {
  await withServer({ fetchImpl: makeMockFetch() }, async (b) => {
    const idx = await fetch(`${b}/`);
    assert.equal(idx.status, 200);
    assert.match(await idx.text(), /VICE MOMENT FINDER/);
    const sw = await fetch(`${b}/sw.js`);
    assert.equal(sw.headers.get('cache-control'), 'no-cache');
    const man = await fetch(`${b}/manifest.webmanifest`);
    assert.match(man.headers.get('content-type'), /manifest\+json/);
    const evil = await fetch(`${b}/..%2F..%2Fpackage.json`);
    assert.ok([403, 404].includes(evil.status));
    assert.equal((await fetch(`${b}/nope.txt`)).status, 404);
  });
});

test('player response extraction survives braces inside strings; track picking order', () => {
  const html = '<script>var ytInitialPlayerResponse = {"a":"}{","captions":{"playerCaptionsTracklistRenderer":{"captionTracks":[{"baseUrl":"https://www.youtube.com/x","languageCode":"en","name":{"simpleText":"English"}}]}}};var z=1;</script>';
  const pr = extractPlayerResponse(html);
  assert.equal(pr.a, '}{');
  assert.equal(tracksFromPlayerResponse(pr)[0].lang, 'en');
  assert.equal(extractPlayerResponse('<html>none</html>'), null);
  const t = [{ lang: 'en', kind: 'manual' }, { lang: 'hi', kind: 'asr' }, { lang: 'hi', kind: 'manual' }];
  assert.equal(pickTrack(t, 'auto').kind, 'manual');
  assert.equal(pickTrack(t, 'auto').lang, 'hi');
  assert.equal(pickTrack(t, 'de'), null);
  assert.equal(pickTrack([], 'auto'), null);
});
