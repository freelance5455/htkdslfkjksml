import test from 'node:test';
import assert from 'node:assert/strict';
import { pickQuote, suggestCreatorPack, suggestTitle } from '../public/js/creator.js';

const base = { start: 192, end: 223, peakText: 'Hahaha pagal hai ye NPC!', peakOffset: 25, firstText: 'Dekho main is NPC ko bolta hoon', excerpt: 'Dekho main is NPC ko bolta hoon. Hahaha pagal hai ye NPC!', category: 'funny', secondary: null };

test('creator pack has 3 Hindi + 3 Hinglish titles, hook, description, caption and hashtags', () => {
  const p = suggestCreatorPack(base, { game: 'GTA', channel: 'VICE CLIPS', videoTitle: 'Replay', videoId: 'dQw4w9WgXcQ' });
  assert.equal(p.titlesHindi.length, 3);
  assert.equal(p.titlesHinglish.length, 3);
  assert.ok(p.titlesHindi.every((t) => /[\u0900-\u097F]/.test(t)), 'Hindi titles contain Devanagari');
  assert.match(p.description, /youtu\.be\/dQw4w9WgXcQ\?t=192/);
  assert.ok(p.hashtags.includes('#Shorts') && p.hashtags.includes('#GTA') && p.hashtags.includes('#VICECLIPS'));
  assert.ok(p.caption.length > 0 && p.hook.text.length > 0);
});

test('quotes come from the real line and profanity is never put into titles', () => {
  assert.equal(pickQuote('Hahaha pagal hai ye NPC!'), 'Hahaha pagal hai ye NPC!');
  assert.equal(pickQuote('saala ye bhosdi wala mission'), '');
  assert.equal(pickQuote('bhai fuck this game'), '');
  assert.equal(pickQuote('ok'), '', 'single words are not quotes');
  assert.ok(pickQuote('a '.repeat(60)).length <= 42);
  const bad = suggestCreatorPack({ ...base, peakText: 'chutiya game hai ye' }, { game: 'GTA' });
  for (const t of [...bad.titlesHindi, ...bad.titlesHinglish]) assert.doesNotMatch(t, /chutiya/i);
});

test('titles never claim things the transcript does not show', () => {
  const p = suggestCreatorPack({ ...base, category: 'action', peakText: 'Bhaago bhaago!', excerpt: 'Bhaago bhaago! gaadi tez chalao' }, { game: 'GTA' });
  const all = [...p.titlesHindi, ...p.titlesHinglish].join(' ');
  assert.doesNotMatch(all, /police|पुलिस/i, 'no police claim without police words');
  assert.doesNotMatch(all, /GTA\s?6/i);
  const withPolice = suggestCreatorPack({ ...base, category: 'action', excerpt: 'Arre police aa gayi peeche', peakText: 'Arre police aa gayi' }, { game: 'GTA' });
  assert.match([...withPolice.titlesHinglish].join(' '), /police/i);
});

test('every category produces titles; suggestTitle is the first Hinglish title', () => {
  for (const category of ['funny', 'surprise', 'action', 'emotion', 'dialogue', 'story']) {
    const m = { ...base, category };
    assert.equal(suggestCreatorPack(m, { game: 'GTA' }).titlesHinglish.length, 3, category);
    assert.equal(suggestTitle(m, { game: 'GTA' }), suggestCreatorPack(m, { game: 'GTA' }).titlesHinglish[0]);
  }
});
