import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PRESETS, adjustBounds, clipCapability, editorInstructions, ffmpegCommand, shq, timestampRange } from '../public/js/clip.js';

test('presets match the spec ranges', () => {
  assert.deepEqual([PRESETS.short.min, PRESETS.short.max], [15, 25]);
  assert.deepEqual([PRESETS.standard.min, PRESETS.standard.max], [25, 40]);
  assert.deepEqual([PRESETS.extended.min, PRESETS.extended.max], [40, 60]);
});

test('adjustBounds: arithmetic, clamping and minimum length', () => {
  assert.deepEqual(adjustBounds({ start: 192, end: 223 }, { startDelta: -5, endDelta: 5 }), { start: 187, end: 228, duration: 41 });
  assert.equal(adjustBounds({ start: 2, end: 30 }, { startDelta: -10 }).start, 0);
  assert.equal(adjustBounds({ start: 10, end: 30 }, { endDelta: 100 }, 60).end, 60);
  const squeezed = adjustBounds({ start: 10, end: 20 }, { endDelta: -30 });
  assert.ok(squeezed.end >= squeezed.start + 1, 'end never crosses start');
  const pushed = adjustBounds({ start: 10, end: 20 }, { startDelta: 30 }, 100);
  assert.ok(pushed.end >= pushed.start + 1);
});

test('timestamp range label', () => assert.equal(timestampRange(192, 223.4), '00:03:12 - 00:03:43'));

test('clip capability never claims YouTube downloading', () => {
  assert.equal(clipCapability({}).available, false);
  assert.match(clipCapability({}).reason, /does not download videos from YouTube/);
  assert.equal(clipCapability({ hasLocalFile: true }).available, false);
  assert.equal(clipCapability({ hasLocalFile: true, ownershipConfirmed: true }).available, true);
  assert.equal(clipCapability({ ownershipConfirmed: true }).available, false);
});

test('shell quoting and ffmpeg command text', () => {
  assert.equal(shq("it's"), `'it'\\''s'`);
  const cmd = ffmpegCommand("my stream's.mp4", 192, 223.5, { outName: 'a.mp4' });
  assert.match(cmd, /^ffmpeg -ss 192 -i 'my stream'\\''s\.mp4' -t 31\.5 /);
  assert.match(ffmpegCommand('in.mp4', 5, 9, { mode: 'copy' }), /-c copy/);
  assert.match(editorInstructions('dQw4w9WgXcQ', 10, 40), /youtu\.be\/dQw4w9WgXcQ\?t=10/);
});

const ffmpegOk = spawnSync('ffmpeg', ['-version']).status === 0;
test('REAL ffmpeg: generated command produces a clip of the requested length', { skip: !ffmpegOk && 'ffmpeg not installed' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vmf-'));
  const src = path.join(dir, 'src.mp4');
  execFileSync('ffmpeg', ['-v', 'error', '-f', 'lavfi', '-i', 'testsrc=duration=20:size=160x120:rate=15', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=20', '-shortest', '-c:v', 'libx264', '-c:a', 'aac', src]);
  const out = path.join(dir, 'clip.mp4');
  const cmd = ffmpegCommand(src, 5, 12, { outName: out }).replace(/^ffmpeg/, 'ffmpeg -v error -y');
  execFileSync('sh', ['-c', cmd]);
  const dur = Number(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', out]).toString().trim());
  assert.ok(Math.abs(dur - 7) < 0.5, `clip duration ${dur}`);
});
