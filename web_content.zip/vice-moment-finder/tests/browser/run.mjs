// Real Chromium tests (Playwright) with an Android Chrome profile (Pixel 7: 412x915, touch, Android user-agent).
// YouTube is SIMULATED by the backend's injectable fetch (tests/helpers/mock-youtube.js).
// This is NOT a real-phone test: see TEST_REPORT.md for what is and is not covered.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from '../../server/server.js';
import { makeMockFetch, VIDEO_OK, VIDEO_NOCAP, FIXTURE_SRT } from '../helpers/mock-youtube.js';

const require = createRequire(import.meta.url);
let playwright;
try { playwright = require('playwright'); } catch { playwright = require('/usr/lib/node_modules/playwright'); }
const { chromium, devices } = playwright;

const results = [];
let failures = 0;
async function check(name, fn) {
  try { await fn(); results.push({ name, ok: true }); console.log(`  PASS  ${name}`); } catch (err) {
    failures++; results.push({ name, ok: false, error: String(err.message).split('\n')[0] }); console.log(`  FAIL  ${name}\n        ${String(err.message).split('\n')[0]}`);
  }
}
const assert = (c, msg) => { if (!c) throw new Error(msg || 'assertion failed'); };

const server = createServer({ fetchImpl: makeMockFetch(), rateLimit: 10000 });
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${server.address().port}`;

const browser = await chromium.launch();
const context = await browser.newContext({ ...devices['Pixel 7'], acceptDownloads: true, serviceWorkers: 'allow' });
await context.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: base }).catch(() => {});
const page = await context.newPage();
const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push(e.message));

const noOverflow = () => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
const goTab = async (t) => { await page.click(`nav.tabs [data-tab="${t}"]`); };
const analyse = async (id) => {
  await page.fill('#url', `https://www.youtube.com/watch?v=${id}`);
  await page.click('button[data-act="analyse"]');
};

console.log('VICE MOMENT FINDER browser tests (Chromium, Android Chrome profile)');
await page.goto(base);

await check('Android profile is active (mobile UA, touch)', async () => {
  const ua = await page.evaluate(() => navigator.userAgent);
  assert(/Android/.test(ua) && /Mobile/.test(ua), ua);
  assert(await page.evaluate(() => navigator.maxTouchPoints > 0), 'no touch');
});

await check('TEST 1: home screen shows URL input, Analyse, Paste, Clear, 4 nav tabs', async () => {
  for (const s of ['#url', 'button[data-act="analyse"]', 'button[data-act="paste"]', 'button[data-act="clear"]']) assert(await page.locator(s).isVisible(), s);
  const tabs = await page.locator('nav.tabs button').allTextContents();
  assert(tabs.join(',') === 'Home,Projects,History,Settings', tabs.join(','));
  assert(/Find the Moments\. Create the Shorts\./.test(await page.textContent('.sub')));
});

await check('mobile layout: no horizontal overflow at 412px and 320px, tap targets >= 44px', async () => {
  assert(await noOverflow(), 'overflow at 412');
  await page.setViewportSize({ width: 320, height: 640 });
  assert(await noOverflow(), 'overflow at 320');
  const small = await page.evaluate(() => [...document.querySelectorAll('button, .btn, nav.tabs button, input')].filter((e) => e.offsetParent && e.getBoundingClientRect().height < 40).map((e) => e.outerHTML.slice(0, 60)));
  assert(small.length === 0, `small targets: ${small.join(' | ')}`);
  await page.setViewportSize({ width: 412, height: 915 });
});

await check('invalid URLs are rejected with a clear message and no request is made', async () => {
  let called = false;
  page.on('request', (r) => { if (r.url().includes('/api/transcript')) called = true; });
  await page.fill('#url', 'https://example.com/watch?v=abcDEF12345');
  await page.click('button[data-act="analyse"]');
  await page.waitForSelector('section.alert.err');
  assert(/will not work/i.test(await page.textContent('section.alert.err')));
  assert(!called, 'backend called for an invalid URL');
  await page.click('button[data-act="clear"]');
});

await check('TESTS 2-7, 9: link -> metadata -> captions -> moments with timestamps, score, reason, title, YouTube link', async () => {
  await analyse(VIDEO_OK);
  await page.waitForSelector('.moment', { timeout: 15000 });
  const n = await page.locator('.moment').count();
  assert(n >= 5, `moments: ${n}`);
  const body = await page.textContent('main');
  assert(/Retrieved automatically/.test(body), 'transcript status');
  assert(/GTA RP Live Stream Replay/.test(body) && /VICE CLIPS Test/.test(body), 'metadata shown');
  const first = page.locator('.moment').first();
  const t = await first.textContent();
  assert(/MOMENT #01/.test(t) && /\d+\/100/.test(t) && /Why:/.test(t) && /Start/.test(t) && /End/.test(t) && /seconds/.test(t), 'card fields');
  const href = await first.locator('a:has-text("Preview on YouTube")').getAttribute('href');
  const m = href.match(/youtu\.be\/abcDEF12345\?t=(\d+)/);
  assert(m, `link: ${href}`);
  const startShown = (await first.locator('.times b').first().textContent()).trim();
  const [h, mi, s] = startShown.split(':').map(Number);
  assert(h * 3600 + mi * 60 + s === Number(m[1]) || Math.abs(h * 3600 + mi * 60 + s - Number(m[1])) <= 1, `shown ${startShown} vs link t=${m[1]}`);
  assert(await noOverflow(), 'overflow on dashboard');
});

await check('TEST 11: no fake Download/Generate-clip button when no authorised local file', async () => {
  const txt = (await page.locator('.moment').allTextContents()).join(' ');
  assert(!/Generate clip|Download clip|Download video/i.test(txt), 'fake clip button');
  assert(await page.locator('[data-act="ffmpeg"]').count() === 0, 'ffmpeg button visible');
  assert(/does not download videos from YouTube/i.test(await page.textContent('main')), 'reason missing');
});

await check('edit timestamps: nudge changes the window, is marked edited and the link follows', async () => {
  const card = page.locator('.moment').first();
  const before = await card.locator('.times b').first().textContent();
  await card.locator('[data-act="edit"]').click();
  await page.locator('.moment').first().locator('button[data-which="start"][data-d="-5"]').click();
  const after = await page.locator('.moment').first().locator('.times b').first().textContent();
  assert(before !== after, `${before} -> ${after}`);
  assert(await page.locator('.moment').first().locator('.chip:has-text("edited")').count() === 1, 'edited chip');
});

await check('save moment, creator ideas (3 Hindi + 3 Hinglish titles)', async () => {
  await page.locator('.moment').first().locator('[data-act="save"]').click();
  await page.waitForSelector('.moment [data-act="save"].primary');
  await page.locator('.moment').first().locator('[data-act="creator"]').click();
  const panel = await page.locator('.moment').first().locator('.panel').last().textContent();
  assert(/[\u0900-\u097F]/.test(panel), 'Devanagari titles');
  assert(/#Shorts/.test(panel) && /hook/i.test(panel), 'hashtags + hook');
});

await check('category filters narrow the list', async () => {
  const all = await page.locator('.moment').count();
  const chips = page.locator('.chip[data-act="filter"]:not([data-k="all"])');
  assert(await chips.count() >= 1, 'no category chips');
  await chips.first().click();
  assert(await page.locator('.moment').count() <= all, 'filter did not narrow');
  await page.click('.chip[data-k="all"]');
});

await check('transcript viewer: search, highlight, moment badges, click-through links', async () => {
  await page.click('.chip[data-act="dtab"][data-k="transcript"]');
  await page.waitForSelector('#tvlist .seg');
  assert(await page.locator('#tvlist .seg.in').count() >= 1, 'no highlighted moment rows');
  await page.fill('#tvq', 'police');
  assert(await page.locator('#tvlist mark').count() >= 1, 'no search highlight');
  const href = await page.locator('#tvlist a.ts').first().getAttribute('href');
  assert(/youtu\.be\/abcDEF12345\?t=\d+/.test(href), href);
  await page.fill('#tvq', '');
  assert(await noOverflow(), 'overflow in transcript');
});

await check('manual transcript correction is possible (Edit line control exists)', async () => {
  assert(await page.locator('#tvlist [data-act="editseg"]').count() >= 1);
});

await check('exports: timestamps TXT, analysis JSON, transcript TXT and SRT download real content', async () => {
  await page.click('.chip[data-act="dtab"][data-k="export"]');
  const grab = async (act) => { const [d] = await Promise.all([page.waitForEvent('download'), page.click(`[data-act="${act}"]`)]); return { name: d.suggestedFilename(), text: fs.readFileSync(await d.path(), 'utf8') }; };
  const j = await grab('dl-json');
  const parsed = JSON.parse(j.text);
  assert(parsed.project.analysis.moments.length >= 5 && parsed.project.savedMoments.length === 1, 'json content');
  const srt = await grab('dl-srt');
  assert(/^1\r?\n\d\d:\d\d:\d\d,\d{3} --> /.test(srt.text) && srt.name.endsWith('.srt'), 'srt');
  const txt = await grab('dl-txt');
  assert(/\d\d:\d\d:\d\d/.test(txt.text), 'txt');
  const ts = await grab('dl-ts');
  assert(/#01 {2}\d\d:\d\d:\d\d - \d\d:\d\d:\d\d/.test(ts.text), 'timestamps');
});

await check('TEST 8: project is saved to IndexedDB and survives a reload (restore, saved moment + edit kept)', async () => {
  const n = await page.evaluate(async () => (await window.__vmf.store.list()).length);
  assert(n === 1, `projects in IndexedDB: ${n}`);
  await page.reload();
  await goTab('projects');
  await page.waitForSelector('[data-act="open-project"]');
  await page.click('[data-act="open-project"]');
  await page.waitForSelector('.moment');
  assert(await page.locator('.moment').first().locator('.chip:has-text("edited")').count() === 1, 'edit lost');
  await page.click('.chip[data-act="dtab"][data-k="saved"]');
  assert(await page.locator('main article.card').count() === 1, 'saved moment lost');
  const stored = await page.evaluate(async () => { const p = (await window.__vmf.store.list())[0]; return { lines: p.transcript.segments.length, moments: p.analysis.moments.length, url: p.url, videoId: p.videoId }; });
  assert(stored.lines > 50 && stored.moments >= 5 && stored.videoId === 'abcDEF12345', JSON.stringify(stored));
});

await check('rename and delete project', async () => {
  await goTab('projects');
  await page.click('[data-act="rename-project"]');
  await page.fill('#modal input', 'My GTA replay');
  await page.click('#modal [data-x="ok"]');
  await page.waitForSelector('text=My GTA replay');
  await page.reload();
  await goTab('projects');
  await page.waitForSelector('[data-act="open-project"]');
  assert(await page.locator('text=My GTA replay').count() >= 1, 'rename not persisted');
});

await check('History tab lists the analysed video', async () => {
  await goTab('history');
  await page.waitForTimeout(300);
  assert(/abcDEF12345|My GTA replay|GTA RP/.test(await page.textContent('main')));
});

await check('TEST 10: video with no captions -> honest failure, no moments, fallbacks offered', async () => {
  await goTab('home');
  await page.click('[data-act="newvideo"]').catch(() => {});
  await analyse(VIDEO_NOCAP);
  await page.waitForSelector('section.alert.err');
  const t = await page.textContent('section.alert.err');
  assert(/no captions/i.test(t), t.slice(0, 120));
  assert(await page.locator('.moment').count() === 0, 'moments shown without a transcript');
  assert(await page.locator('section.alert.err [data-act="analyse"]').count() === 1, 'no Retry');
  assert(await page.locator('section.alert.err a:has-text("Open video on YouTube")').count() === 1, 'no open-video link');
  assert(await page.locator('#tfile').count() === 1 && await page.locator('#tpaste').count() === 1, 'no import fallback');
  assert(/Retrieved automatically/.test(await page.textContent('main')) === false, 'false success');
});

await check('fallback: SRT file import works through the file picker input (Android picker path)', async () => {
  await page.setInputFiles('#tfile', { name: 'stream.srt', mimeType: 'application/x-subrip', buffer: Buffer.from(FIXTURE_SRT) });
  await page.waitForSelector('.moment', { timeout: 15000 });
  assert(/Imported manually/.test(await page.textContent('main')), 'source label');
});

await check('fallback: pasted timestamped Hinglish transcript is analysed', async () => {
  await page.click('[data-act="newvideo"]');
  const text = [
    '00:00:03 - 00:00:06', 'Bhai main police ki gaadi le raha hoon.', '',
    '00:00:06 - 00:00:10', 'Ye kya glitch ho gaya? Hahaha pagal hai ye game!', '',
    '00:00:10 - 00:00:14', 'Arre bhai bachao bachao, police peeche padi hai!', '',
  ].join('\n');
  await page.locator('details summary').first().click().catch(() => {});
  await page.fill('#tpaste', text);
  await page.click('[data-act="analyse-paste"]');
  await page.waitForSelector('h2', { timeout: 10000 });
  await page.waitForTimeout(500);
  assert(/Imported manually|moment/i.test(await page.textContent('main')), (await page.textContent('main')).slice(0, 300));
});

await check('backend unreachable is explained (static hosting without backend URL)', async () => {
  await page.click('[data-act="newvideo"]').catch(() => {});
  await page.evaluate(() => window.__vmf.settings.set({ backendUrl: 'http://127.0.0.1:1' })); // nothing listens here
  await analyse(VIDEO_OK);
  await page.waitForSelector('section.alert.err');
  const em = await page.textContent('section.alert.err');
  assert(/Could not reach the transcript service/.test(em), em.replace(/\s+/g, ' ').slice(0, 200));
  await page.evaluate(() => window.__vmf.settings.set({ backendUrl: '' }));
});

await check('TEST 12/PWA: manifest, installable icons, service worker active', async () => {
  const man = await page.evaluate(async () => (await fetch(document.querySelector('link[rel=manifest]').href)).json());
  assert(man.display === 'standalone' && man.icons.length >= 3, 'manifest');
  const state = await page.evaluate(async () => { const r = await navigator.serviceWorker.ready; return r.active?.state; });
  assert(state === 'activated', `sw ${state}`);
  const cached = await page.evaluate(async () => (await (await caches.open('vmf-shell-v1')).keys()).length);
  assert(cached >= 15, `cached files ${cached}`);
});

await check('offline: shell loads, saved projects open, transcript fetch says offline (no fake success)', async () => {
  await page.reload();
  await page.evaluate(() => navigator.serviceWorker.ready);
  await context.setOffline(true);
  await page.reload();
  await page.waitForSelector('#url');
  assert(await page.locator('#net').isVisible(), 'offline badge');
  await goTab('projects');
  await page.waitForSelector('[data-act="open-project"]');
  await page.locator('[data-act="open-project"]').first().click();
  await page.waitForSelector('.moment');
  await page.click('.chip[data-act="dtab"][data-k="transcript"]');
  await page.waitForSelector('#tvlist .seg');
  await page.click('[data-act="newvideo"]').catch(() => {});
  await goTab('home');
  await page.click('[data-act="newvideo"]').catch(() => {});
  await analyse(VIDEO_OK);
  await page.waitForSelector('section.alert.err');
  assert(/offline/i.test(await page.textContent('section.alert.err')), 'offline message');
  assert(await page.locator('.moment').count() === 0, 'moments from nowhere');
  await context.setOffline(false);
});

await check('settings tab renders without overflow and has install help', async () => {
  await goTab('settings');
  await page.waitForSelector('[data-set]');
  assert(await noOverflow(), 'overflow in settings');
  assert(/install/i.test(await page.textContent('main')), 'install instructions');
});

await check('no uncaught JavaScript errors during the whole run', async () => {
  assert(pageErrors.length === 0, pageErrors.join(' | '));
});

await browser.close();
await new Promise((r) => server.close(r));
const pass = results.filter((r) => r.ok).length;
console.log(`\n${pass}/${results.length} browser checks passed`);
fs.writeFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'last-run.json'), JSON.stringify({ at: new Date().toISOString(), pass, total: results.length, results }, null, 2));
process.exit(failures ? 1 : 0);
