import test from 'node:test';
import assert from 'node:assert/strict';
import { detectLanguage, normalizeSegments, parseJson3, parsePlain, parseSRT, parseTimedTextXml, parseTranscript, parseVTT, toSRT, toTXT } from '../public/js/transcript.js';
import { fmtSrtTime, fmtTime, parseTimestamp } from '../public/js/util.js';

const SRT = `\uFEFF1
00:00:03,000 --> 00:00:06,000
Bhai main police ki gaadi le raha hoon.

2
00:00:06,000 --> 00:00:10,500
<i>Ye kya</i> glitch ho gaya?
second line

3
01:02:03,250 --> 01:02:05,000
अरे यार &amp; क्या बात है
`;

test('timestamp helpers', () => {
  assert.equal(parseTimestamp('00:03:12'), 192);
  assert.equal(parseTimestamp('3:12'), 192);
  assert.equal(parseTimestamp('01:02:03,500'), 3723.5);
  assert.equal(parseTimestamp('1h2m3s'), 3723);
  assert.equal(parseTimestamp('90'), 90);
  assert.equal(parseTimestamp('00:61:00'), null);
  assert.equal(parseTimestamp('abc'), null);
  assert.equal(fmtTime(192.4), '00:03:12');
  assert.equal(fmtTime(3723), '01:02:03');
  assert.equal(fmtSrtTime(3723.25), '01:02:03,250');
});

test('SRT: parses cues, strips tags/BOM, decodes entities, keeps Hindi (Devanagari)', () => {
  const segs = parseSRT(SRT);
  assert.equal(segs.length, 3);
  assert.deepEqual(segs[0], { start: 3, end: 6, text: 'Bhai main police ki gaadi le raha hoon.' });
  assert.equal(segs[1].text, 'Ye kya glitch ho gaya? second line');
  assert.equal(segs[2].start, 3723.25);
  assert.equal(segs[2].text, 'अरे यार & क्या बात है');
});

test('VTT: header, NOTE blocks, cue ids, settings, short timestamps and voice tags', () => {
  const vtt = `WEBVTT

NOTE this is a comment

intro
00:03.000 --> 00:06.000 align:start position:0%
<v Rahul>Hello &amp; welcome</v>

00:00:06.000 --> 00:00:09.000
Second <c.colorE5E5E5>cue</c>
`;
  const segs = parseVTT(vtt);
  assert.equal(segs.length, 2);
  assert.deepEqual(segs[0], { start: 3, end: 6, text: 'Hello & welcome', speaker: 'Rahul' });
  assert.equal(segs[1].text, 'Second cue');
});

test('plain text: bracketed, ranged and two-line formats (the format from the spec)', () => {
  const twoLine = parsePlain('00:00:03 - 00:00:06\n"Bhai main police ki gaadi le raha hoon."\n\n00:00:06 - 00:00:10\n"Ye kya glitch ho gaya?"\n');
  assert.deepEqual(twoLine, [
    { start: 3, end: 6, text: 'Bhai main police ki gaadi le raha hoon.' },
    { start: 6, end: 10, text: 'Ye kya glitch ho gaya?' },
  ]);
  const single = parsePlain('[0:03] pehli line\n[0:09] doosri\nlambi line\n1:02:03 teesri');
  assert.equal(single.length, 3);
  assert.equal(single[1].text, 'doosri lambi line');
  assert.equal(single[1].end, 3723 > 9 + 12 ? 21 : 3723, 'inferred end is capped (no 1-hour captions)');
  assert.equal(single[2].start, 3723);
});

test('format auto-detection and honest warnings', () => {
  assert.equal(parseTranscript(SRT).format, 'srt');
  assert.equal(parseTranscript('WEBVTT\n\n00:01.000 --> 00:02.000\nhi').format, 'vtt');
  const none = parseTranscript('just some words without any times');
  assert.equal(none.segments.length, 0);
  assert.match(none.warnings[0], /No timestamps found/);
  assert.equal(parseTranscript('').segments.length, 0);
});

test('json3 and timedtext XML (YouTube formats)', () => {
  const j = parseJson3({ events: [{ tStartMs: 1500, dDurationMs: 2000, segs: [{ utf8: 'Ye kya ' }, { utf8: 'ho gaya' }] }, { tStartMs: 4000 }, { tStartMs: 5000, dDurationMs: 1000, segs: [{ utf8: '\n' }] }] });
  assert.deepEqual(j, [{ start: 1.5, end: 3.5, text: 'Ye kya ho gaya' }]);
  const x = parseTimedTextXml('<?xml version="1.0"?><transcript><text start="1.2" dur="2.5">Hello &amp;#39;you&amp;#39;</text><text start="5" dur="1">bye</text></transcript>');
  assert.equal(x.length, 2);
  assert.equal(x[0].start, 1.2);
  assert.equal(x[0].end, 3.7);
  const p = parseTimedTextXml('<timedtext><body><p t="1000" d="2000">Namaste</p></body></timedtext>');
  assert.deepEqual(p, [{ start: 1, end: 3, text: 'Namaste' }]);
  assert.equal(parseTranscript(JSON.stringify({ events: [{ tStartMs: 0, dDurationMs: 1000, segs: [{ utf8: 'x y' }] }] })).format, 'json3');
});

test('normalize: sorts, repairs bad ends, never moves start times, drops empties', () => {
  const out = normalizeSegments([
    { start: 10, end: 8, text: 'late' }, { start: 2, end: 4, text: '  first  ' }, { start: 5, end: 6, text: '   ' }, { start: NaN, end: 1, text: 'bad' },
  ]);
  assert.deepEqual(out.map((s) => [s.start, s.text]), [[2, 'first'], [10, 'late']]);
  assert.ok(out[1].end > out[1].start);
});

test('normalize: collapses rolling auto-caption repeats but not unrelated sentences', () => {
  const out = normalizeSegments([
    { start: 0, end: 2, text: 'bhai ye kya hai' },
    { start: 2, end: 4, text: 'bhai ye kya hai yaar kamaal hai' },
    { start: 4, end: 6, text: 'bhai ye kya hai yaar kamaal hai' },
    { start: 10, end: 12, text: 'bilkul alag baat' },
  ]);
  assert.deepEqual(out.map((s) => s.text), ['bhai ye kya hai', 'yaar kamaal hai', 'bilkul alag baat']);
  assert.equal(out[0].start, 0);
  assert.equal(out[1].start, 2);
});

test('language detection: Hindi, Hinglish, English', () => {
  const hi = [{ text: 'अरे भाई ये क्या हो गया मैंने तो पुलिस की गाड़ी ले ली थी' }];
  const hinglish = [{ text: 'Bhai main police ki gaadi le raha hoon aur ye kya glitch ho gaya yaar, abhi dekho kaise hai' }];
  const mixed = [{ text: 'अरे bhai ye GTA glitch क्या है यार lets go' }];
  const en = [{ text: 'So today we are going to play the game and see what happens next in the mission' }];
  assert.equal(detectLanguage(hi).code, 'hi');
  assert.equal(detectLanguage(hinglish).code, 'hinglish');
  assert.equal(detectLanguage(mixed).code, 'hinglish');
  assert.equal(detectLanguage(en).code, 'en');
  assert.equal(detectLanguage([{ text: 'hi' }]).code, 'unknown');
});

test('exports: SRT round-trips and TXT is timestamped', () => {
  const segs = parseSRT(SRT);
  const again = parseSRT(toSRT(segs));
  assert.deepEqual(again.map((s) => [s.start, s.end, s.text]), segs.map((s) => [s.start, s.end, s.text]));
  assert.match(toTXT(segs), /^\[00:00:03\] Bhai main police/);
});
