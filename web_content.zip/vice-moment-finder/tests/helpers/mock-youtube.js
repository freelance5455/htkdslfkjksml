// SIMULATED YouTube responses for tests. Nothing here talks to the real YouTube.
// It mimics the shape of: watch page HTML (ytInitialPlayerResponse), the json3 caption track, and oEmbed.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseSRT } from '../../public/js/transcript.js';

const here = path.dirname(fileURLToPath(import.meta.url));
export const FIXTURE_SRT = fs.readFileSync(path.join(here, '..', 'fixtures', 'hinglish-gta.srt'), 'utf8');

export const VIDEO_OK = 'abcDEF12345'; // has Hindi auto + English manual captions
export const VIDEO_NOCAP = 'nocaps00001';
export const VIDEO_PRIVATE = 'private0001';
export const VIDEO_BOT = 'botcheck001';
export const VIDEO_BLOCKED = 'blocked0001';

const json3 = () => JSON.stringify({
  events: parseSRT(FIXTURE_SRT).map((s) => ({ tStartMs: Math.round(s.start * 1000), dDurationMs: Math.round((s.end - s.start) * 1000), segs: [{ utf8: s.text }] })),
});

const playerResponse = (id, extra = {}) => ({
  playabilityStatus: { status: 'OK' },
  videoDetails: { videoId: id, title: 'GTA RP Live Stream Replay', author: 'VICE CLIPS Test', lengthSeconds: '555', isLiveContent: true, isLive: false },
  ...extra,
});

const watchHtml = (pr) => `<!doctype html><html><head><title>x</title></head><body><script>var ytInitialPlayerResponse = ${JSON.stringify(pr)};var meta = {"a":"}{"};</script></body></html>`;

export function makeMockFetch({ log = [] } = {}) {
  return async (input, init = {}) => {
    const url = String(input);
    log.push(url);
    const res = (body, status = 200) => new Response(body, { status });
    const u = new URL(url);

    if (u.hostname === 'www.youtube.com' && u.pathname === '/watch') {
      const id = u.searchParams.get('v');
      if (id === VIDEO_OK) {
        return res(watchHtml(playerResponse(id, {
          captions: { playerCaptionsTracklistRenderer: { captionTracks: [
            { baseUrl: `https://www.youtube.com/api/timedtext?v=${id}&lang=hi&kind=asr`, languageCode: 'hi', kind: 'asr', name: { simpleText: 'Hindi (auto-generated)' } },
            { baseUrl: `https://www.youtube.com/api/timedtext?v=${id}&lang=en`, languageCode: 'en', name: { simpleText: 'English' } },
          ] } },
        })));
      }
      if (id === VIDEO_NOCAP) return res(watchHtml(playerResponse(id)));
      if (id === VIDEO_PRIVATE) return res(watchHtml({ playabilityStatus: { status: 'ERROR', reason: 'Video unavailable' } }));
      if (id === VIDEO_BOT) return res(watchHtml({ playabilityStatus: { status: 'LOGIN_REQUIRED', reason: 'Sign in to confirm you’re not a bot' } }));
      if (id === VIDEO_BLOCKED) {
        return res(watchHtml(playerResponse(id, { captions: { playerCaptionsTracklistRenderer: { captionTracks: [
          { baseUrl: `https://www.youtube.com/api/timedtext?v=${id}&lang=hi`, languageCode: 'hi', name: { simpleText: 'Hindi' } },
        ] } } })));
      }
      return res('<html>nothing</html>');
    }
    if (u.hostname === 'www.youtube.com' && u.pathname === '/api/timedtext') {
      const id = u.searchParams.get('v');
      if (id === VIDEO_BLOCKED) return res('', 200); // listed but empty body
      return res(json3());
    }
    if (u.hostname === 'www.youtube.com' && u.pathname === '/oembed') {
      const target = new URL(u.searchParams.get('url')).searchParams.get('v');
      if (target === VIDEO_PRIVATE) return res('Unauthorized', 401);
      return res(JSON.stringify({ title: 'GTA RP Live Stream Replay', author_name: 'VICE CLIPS Test', thumbnail_url: `https://i.ytimg.com/vi/${target}/hqdefault.jpg` }));
    }
    if (u.hostname === 'www.googleapis.com' && u.pathname === '/youtube/v3/captions') {
      const auth = init.headers?.authorization;
      if (auth !== 'Bearer GOOD') return res('{}', auth === 'Bearer EXPIRED' ? 401 : 403);
      return res(JSON.stringify({ items: [{ id: 'CAP1', snippet: { language: 'hi', name: '', trackKind: 'standard' } }] }));
    }
    if (u.hostname === 'www.googleapis.com' && u.pathname.startsWith('/youtube/v3/captions/')) return res(FIXTURE_SRT);
    return res('not mocked', 404);
  };
}

export const offlineFetch = async () => { throw Object.assign(new TypeError('fetch failed'), { cause: { code: 'ENOTFOUND' } }); };
