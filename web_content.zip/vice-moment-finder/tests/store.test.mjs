// Settings / history / project record logic (pure parts). Real IndexedDB persistence is covered by the browser tests.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULT_SETTINGS, createHistory, createSettings, exportProjectJSON, newProject, openDb } from '../public/js/store.js';

const mem = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };

test('settings: defaults, merge, persistence, corrupt data and blocked storage', () => {
  const st = mem();
  const s = createSettings(st);
  assert.deepEqual(s.all(), DEFAULT_SETTINGS);
  s.set({ game: 'GTA V', maxMoments: 15 });
  assert.equal(createSettings(st).get('game'), 'GTA V');
  assert.equal(createSettings(st).get('channel'), DEFAULT_SETTINGS.channel);
  st.setItem('vmf.settings', '{not json');
  assert.deepEqual(createSettings(st).all(), DEFAULT_SETTINGS);
  const blocked = { getItem() { throw new Error('denied'); }, setItem() { throw new Error('denied'); }, removeItem() { throw new Error('denied'); } };
  assert.doesNotThrow(() => createSettings(blocked).set({ game: 'x' }));
  assert.deepEqual(createSettings(blocked).all(), DEFAULT_SETTINGS);
});

test('history: newest first, de-duplicated by video, capped', () => {
  const h = createHistory(mem(), 3);
  h.add({ videoId: 'a' }); h.add({ videoId: 'b' }); h.add({ videoId: 'a' }); h.add({ videoId: 'c' }); h.add({ videoId: 'd' });
  assert.deepEqual(h.list().map((x) => x.videoId), ['d', 'c', 'a']);
  h.clear();
  assert.deepEqual(h.list(), []);
});

test('newProject + JSON export contain everything needed to restore', () => {
  const p = newProject({ url: 'https://youtu.be/abcDEF12345', videoId: 'abcDEF12345', meta: { title: 'T' }, transcript: { segments: [{ start: 1, end: 2, text: 'hi' }] }, analysis: { moments: [] } });
  assert.equal(p.name, 'T');
  assert.ok(p.id.startsWith('prj'));
  const back = JSON.parse(exportProjectJSON(p));
  assert.equal(back.app, 'VICE MOMENT FINDER');
  assert.deepEqual(back.project.transcript.segments, [{ start: 1, end: 2, text: 'hi' }]);
  assert.deepEqual(['savedMoments', 'edits', 'creator'].map((k) => k in back.project), [true, true, true]);
  assert.equal(newProject({ videoId: 'x'.repeat(11), transcript: {}, analysis: {} }).name, `Video ${'x'.repeat(11)}`);
  assert.equal(newProject({ transcript: {}, analysis: {} }).name, 'Pasted transcript');
});

test('IndexedDB unavailable gives a readable error', async () => {
  await assert.rejects(() => openDb(null), /IndexedDB is not available/);
});

test('PWA files: manifest is valid and the service worker precaches every shipped file', () => {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
  const man = JSON.parse(fs.readFileSync(path.join(root, 'manifest.webmanifest'), 'utf8'));
  assert.equal(man.display, 'standalone');
  assert.ok(man.start_url && man.name && man.short_name);
  const sizes = man.icons.map((i) => i.sizes);
  assert.ok(sizes.includes('192x192') && sizes.includes('512x512'));
  assert.ok(man.icons.some((i) => /maskable/.test(i.purpose || '')));
  for (const i of man.icons) assert.ok(fs.existsSync(path.join(root, i.src)), `icon ${i.src} exists`);
  const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
  const shipped = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : shipped.push(path.relative(root, path.join(d, e.name)))));
  walk(root);
  for (const f of shipped.filter((f) => f !== 'sw.js')) assert.ok(sw.includes(`'./${f}'`), `service worker precaches ${f}`);
});
