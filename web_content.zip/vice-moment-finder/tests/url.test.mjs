import test from 'node:test';
import assert from 'node:assert/strict';
import { parseYouTubeUrl, shortLink, watchUrl, embedUrl, isVideoId } from '../public/js/url.js';

const ID = 'dQw4w9WgXcQ';

test('parses standard URL formats and extracts the video id', () => {
  const cases = [
    [`https://www.youtube.com/watch?v=${ID}`, 'watch'],
    [`https://youtube.com/watch?v=${ID}&feature=share`, 'watch'],
    [`https://m.youtube.com/watch?v=${ID}`, 'watch'],
    [`https://youtu.be/${ID}`, 'short-link'],
    [`https://youtu.be/${ID}?si=abc123`, 'short-link'],
    [`https://www.youtube.com/live/${ID}?feature=share`, 'live'],
    [`https://www.youtube.com/shorts/${ID}`, 'shorts'],
    [`https://www.youtube.com/embed/${ID}`, 'embed'],
    [`youtube.com/watch?v=${ID}`, 'watch'],
    [`  https://youtu.be/${ID}  `, 'short-link'],
    [ID, 'id'],
  ];
  for (const [input, kind] of cases) {
    const r = parseYouTubeUrl(input);
    assert.equal(r.ok, true, input);
    assert.equal(r.id, ID, input);
    assert.equal(r.kind, kind, input);
  }
});

test('reads start time from t= / start=', () => {
  assert.equal(parseYouTubeUrl(`https://youtu.be/${ID}?t=90`).startSeconds, 90);
  assert.equal(parseYouTubeUrl(`https://youtu.be/${ID}?t=1m30s`).startSeconds, 90);
  assert.equal(parseYouTubeUrl(`https://www.youtube.com/watch?v=${ID}&t=1h2m3s`).startSeconds, 3723);
  assert.equal(parseYouTubeUrl(`https://youtu.be/${ID}`).startSeconds, null);
});

test('rejects invalid, foreign and look-alike URLs', () => {
  const bad = [
    '', '   ', 'hello world', 'https://example.com/watch?v=' + ID,
    'https://youtube.com.evil.com/watch?v=' + ID, 'https://evil.com/youtu.be/' + ID,
    'https://www.youtube.com/watch', 'https://www.youtube.com/watch?v=short',
    'https://www.youtube.com/playlist?list=PL123', 'https://www.youtube.com/@somechannel',
    'ftp://youtube.com/watch?v=' + ID, 'javascript:alert(1)', 'https://youtu.be/',
  ];
  for (const b of bad) {
    const r = parseYouTubeUrl(b);
    assert.equal(r.ok, false, `should reject: ${b}`);
    assert.ok(r.message && r.code, 'has code + message');
  }
});

test('link builders', () => {
  assert.equal(shortLink(ID, 192.7), `https://youtu.be/${ID}?t=192`);
  assert.equal(watchUrl(ID, 5), `https://www.youtube.com/watch?v=${ID}&t=5s`);
  assert.equal(watchUrl(ID), `https://www.youtube.com/watch?v=${ID}`);
  assert.match(embedUrl(ID, 10.2, 40.1), /youtube-nocookie\.com\/embed\/dQw4w9WgXcQ\?start=10.*end=41/);
  assert.equal(isVideoId(ID), true);
  assert.equal(isVideoId('x'), false);
});
