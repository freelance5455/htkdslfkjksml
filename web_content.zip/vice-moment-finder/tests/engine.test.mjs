import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { analyzeTranscript, isDuplicate, WEIGHTS, SCORE_SCALE } from '../public/js/engine.js';
import { parseTranscript } from '../public/js/transcript.js';
import { analyzeSamples } from '../public/js/audio.js';

const rd = (f) => fs.readFileSync(new URL(`./fixtures/${f}`, import.meta.url), 'utf8');
const { segments } = parseTranscript(rd('hinglish-gta.srt'));
const truth = JSON.parse(rd('hinglish-gta.truth.json'));
const overlaps = (m, t) => Math.min(m.end, t.end) - Math.max(m.start, t.start) > 0;

// NOTE: this fixture is SYNTHETIC (written for these tests). It proves the engine's behaviour on known
// planted moments; it is not evidence of accuracy on real streams.

test('finds every planted moment in the synthetic Hinglish fixture, with sensible timestamps', () => {
  const { moments } = analyzeTranscript(segments);
  for (const t of truth) {
    const hit = moments.find((m) => overlaps(m, t));
    assert.ok(hit, `missing planted moment: ${t.name}`);
    assert.ok(hit.start <= t.start + 1.5 && hit.start >= t.start - 16, `${t.name}: start ${hit.start} vs ${t.start}`);
    assert.ok(hit.end >= t.end - 3 && hit.end <= t.end + 4, `${t.name}: end ${hit.end} vs ${t.end}`);
  }
});

test('does not invent moments in calm filler (no moment starts in the calm stretches)', () => {
  const { moments } = analyzeTranscript(segments);
  assert.ok(moments.length <= truth.length + 1, `expected about ${truth.length}, got ${moments.length}`);
  for (const m of moments) assert.ok(truth.some((t) => overlaps(m, t)), `false positive at ${m.start.toFixed(1)}s: ${m.peakText}`);
});

test('every moment carries all required fields', () => {
  const { moments } = analyzeTranscript(segments, {}, { game: 'GTA', channel: 'VICE CLIPS' });
  assert.ok(moments.length >= 4);
  for (const m of moments) {
    assert.ok(m.end > m.start);
    assert.ok(Math.abs(m.duration - (m.end - m.start)) < 1e-9);
    assert.ok(m.category && m.categoryLabel);
    assert.ok(m.excerpt.length > 0);
    assert.ok(m.reason.length > 20);
    assert.ok(Number.isInteger(m.score) && m.score >= 0 && m.score <= 100);
    assert.ok(m.title.length > 0);
    assert.ok(m.rank >= 1);
    for (const k of Object.keys(WEIGHTS)) assert.ok(k in m.breakdown, `breakdown.${k}`);
  }
  const scores = moments.map((m) => m.score);
  assert.deepEqual(scores, [...scores].sort((a, b) => b - a), 'ranked best first');
});

test('scoring is transparent: score equals the documented weighted sum (no audio -> audio weight dropped)', () => {
  const { moments } = analyzeTranscript(segments);
  for (const m of moments) {
    const keys = Object.keys(WEIGHTS).filter((k) => m.breakdown[k] != null);
    assert.ok(!keys.includes('audio'));
    const wsum = keys.reduce((a, k) => a + WEIGHTS[k], 0);
    const raw = keys.reduce((a, k) => a + WEIGHTS[k] * m.breakdown[k], 0) / wsum;
    assert.ok(Math.abs(m.score - Math.round(100 * Math.min(1, raw * SCORE_SCALE))) <= 1, `score ${m.score} vs recomputed`);
  }
});

test('context matters: an ordinary sentence becomes the punchline because laughter follows it', () => {
  const mk = (withLaugh) => {
    const segs = [];
    let t = 0;
    const add = (text, d = 3) => { segs.push({ start: t, end: t + d, text }); t += d + 0.4; };
    for (let i = 0; i < 6; i++) add('Toh abhi hum mission ke liye jaa rahe hain aur thoda sa rasta baaki hai.');
    add('Maine uski gaadi par apna naam likh diya matlab ab ye meri hai.');
    if (withLaugh) add('Hahaha bhai ye kya kar diya tune', 2.2); else add('Chalo aage badhte hain thoda sa.', 2.2);
    for (let i = 0; i < 6; i++) add('Phir hum seedha jaayenge aur dekhenge ki aage kya hota hai yahan.');
    return segs;
  };
  const withL = analyzeTranscript(mk(true));
  const without = analyzeTranscript(mk(false));
  assert.equal(without.moments.length, 0, 'same ordinary sentence alone is not a moment');
  assert.equal(withL.moments.length, 1);
  const m = withL.moments[0];
  assert.ok(m.signals.some((s) => s.key === 'punchline'), 'punchline signal fired');
  assert.match(m.excerpt, /apna naam likh diya/, 'the ordinary set-up line is included in the clip');
});

test('keywords alone are not enough: casual mentions of police/glitch in calm explanation produce nothing', () => {
  const segs = [];
  let t = 0;
  for (let i = 0; i < 40; i++) {
    const text = i % 2 ? 'Aaj hum dekhenge ki glitch kaise kaam karta hai aur police ka scene kaise banta hai game mein.' : 'Pehle thoda settings badal lete hain phir hum mission start karenge aur dekhenge kya hota hai.';
    segs.push({ start: t, end: t + 5, text });
    t += 5.5;
  }
  assert.equal(analyzeTranscript(segs).moments.length, 0);
});

test('Hindi (Devanagari) transcript is analysed, including laughter and exclamations', () => {
  const segs = [];
  let t = 0;
  const add = (text, d = 3) => { segs.push({ start: t, end: t + d, text }); t += d + 0.4; };
  for (let i = 0; i < 8; i++) add('तो दोस्तों आज हम फिर से खेल शुरू करते हैं और देखते हैं आगे क्या होता है।');
  add('मैंने उस आदमी को बोला कि भाई मुझे अपनी गाड़ी दे दे।');
  add('अरे ये क्या हुआ?! उसने सच में दे दी!', 2.4);
  add('हाहा हाहा पागल है ये!', 2);
  for (let i = 0; i < 8; i++) add('तो दोस्तों अब हम आगे चलते हैं और मिशन पूरा करते हैं यहाँ से।');
  const { moments } = analyzeTranscript(segs);
  assert.equal(moments.length, 1);
  assert.match(moments[0].excerpt, /हाहा/);
  assert.ok(moments[0].score >= 50);
});

test('boundaries avoid cutting dialogue: window starts/ends on whole transcript lines near pauses', () => {
  const { moments } = analyzeTranscript(segments);
  const starts = segments.map((s) => s.start);
  const ends = segments.map((s) => s.end);
  for (const m of moments) {
    assert.ok(starts.some((s) => Math.abs(m.start - (s - 0.3)) < 0.01 || Math.abs(m.start - 0) < 0.01), 'start sits at a line start');
    assert.ok(ends.some((e) => Math.abs(m.end - (e + 0.5)) < 0.01), 'end sits at a line end');
  }
});

test('duration presets change window length; recommendations are not hard limits', () => {
  const short = analyzeTranscript(segments, { preset: 'short' }).moments;
  const ext = analyzeTranscript(segments, { preset: 'extended' }).moments;
  const avg = (a) => a.reduce((x, m) => x + m.duration, 0) / a.length;
  assert.ok(avg(short) <= avg(ext) + 1e-9);
  for (const m of short) assert.ok(m.duration <= 25 * 1.35 + 1);
});

test('duplicate / overlap detection', () => {
  const a = { start: 10, end: 40, peak: 30 };
  assert.equal(isDuplicate(a, { start: 20, end: 50, peak: 45 }), true, 'heavy overlap');
  assert.equal(isDuplicate(a, { start: 100, end: 130, peak: 120 }), false, 'far apart');
  assert.equal(isDuplicate(a, { start: 45, end: 70, peak: 33 }), true, 'same peak instant');
  const { moments } = analyzeTranscript(segments, { minScore: 0 });
  for (let i = 0; i < moments.length; i++) for (let j = i + 1; j < moments.length; j++) assert.equal(isDuplicate(moments[i], moments[j]), false);
});

test('maxMoments and minScore are respected; weak moments are not padded in', () => {
  assert.equal(analyzeTranscript(segments, { maxMoments: 2 }).moments.length, 2);
  assert.equal(analyzeTranscript(segments, { minScore: 99 }).moments.length, 0);
  const none = analyzeTranscript(segments, { minScore: 99 });
  assert.ok(none.stats.notes.some((n) => /No moment passed/.test(n)));
});

test('empty / tiny transcripts give honest notes, not fake results', () => {
  assert.deepEqual(analyzeTranscript([]).moments, []);
  assert.match(analyzeTranscript([]).stats.notes[0], /empty/);
  assert.match(analyzeTranscript([{ start: 0, end: 1, text: 'hi' }]).stats.notes[0], /too short/);
});

test('audio: re-ranks existing candidates but never creates a moment on its own', () => {
  const sr = 100;
  const total = Math.ceil(segments.at(-1).end) + 5;
  const loud = new Float32Array(total * sr).fill(0).map((_, i) => 0.02 * Math.sin(i / 3));
  // very loud burst inside a CALM stretch (no transcript evidence there): 20s..25s
  for (let i = 20 * sr; i < 25 * sr; i++) loud[i] = 0.9 * Math.sin(i / 2);
  const windows = analyzeSamples(loud, sr);
  const base = analyzeTranscript(segments);
  const withAudio = analyzeTranscript(segments, { audio: windows });
  assert.equal(withAudio.stats.audioUsed, true);
  assert.equal(withAudio.moments.length, base.moments.length, 'loud calm stretch did not become a moment');
  assert.ok(!withAudio.moments.some((m) => m.start >= 15 && m.end <= 30));
  assert.ok(withAudio.moments.every((m) => m.breakdown.audio != null));
  assert.match(withAudio.moments[0].audio.note, /Loudness only/);
});

test('performance: an 8-hour, ~10k line transcript analyses quickly', () => {
  const segs = [];
  let t = 0;
  for (let i = 0; i < 10000; i++) {
    const text = i % 400 === 0 ? 'Hahaha bhai ye kya hua?! Arre yaar kamaal ho gaya!' : 'Toh ab hum aage badhte hain aur dekhte hain ki mission mein kya hota hai.';
    segs.push({ start: t, end: t + 2.5, text });
    t += 2.9;
  }
  const t0 = performance.now();
  const r = analyzeTranscript(segs, { maxMoments: 50 });
  const ms = performance.now() - t0;
  assert.ok(ms < 8000, `took ${ms.toFixed(0)}ms`);
  assert.ok(r.moments.length >= 10);
});
