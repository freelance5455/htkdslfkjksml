/*
 * VICE MOMENT FINDER — analysis engine (Stage A: free transcript analysis).
 * Runs unchanged in the browser (window.ViceEngine) and in Node (require).
 * No dependencies, no network access, nothing is stored or uploaded.
 *
 * All times are handled as integer milliseconds. Seconds shown to the user
 * are produced by floor (starts) or ceil (ends) so a window never begins
 * later, or ends earlier, than the real transcript cue it came from.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ViceEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ */
  /* Limits and constants                                                */
  /* ------------------------------------------------------------------ */
  const LIMITS = {
    maxBytes: 10 * 1024 * 1024, // 10 MB per file / pasted text
    maxCues: 200000,
    maxInputChars: 300,
    allowedExtensions: ['.srt', '.vtt', '.txt'],
  };
  const WINDOW_MS = 20000; // look-ahead window used to score one moment
  const MAX_MOMENT_MS = 30000; // a single moment never spans more than this
  const LEAD_IN_MS = 5000; // include the previous cue if it is this close
  const DEDUPE_GAP_MS = 20000; // moments closer than this count as duplicates
  const MIN_SCORE = 1.0;
  const MAX_CONFIDENCE = 92; // transcript text alone can never be "certain"
  const PASTED_MAX_CUE_MS = 10000;
  const PASTED_LAST_CUE_MS = 4000;

  const CATEGORIES = [
    { id: 'funny', label: 'Funny moment' },
    { id: 'rage', label: 'Streamer rage' },
    { id: 'glitch', label: 'Glitch' },
    { id: 'police', label: 'Police chase' },
    { id: 'crash', label: 'Car crash' },
    { id: 'death', label: 'Unexpected death' },
    { id: 'crazy', label: 'Crazy gameplay' },
    { id: 'conversation', label: 'Funny conversation' },
    { id: 'surprise', label: 'Surprise' },
    { id: 'viral', label: 'Viral reaction' },
    { id: 'roast', label: 'Roast / insults' },
    { id: 'argument', label: 'Argument' },
    { id: 'emotional', label: 'Emotional moment' },
    { id: 'discovery', label: 'Unexpected discovery' },
    { id: 'suspicious', label: 'Suspicious situation' },
    { id: 'epic', label: 'Epic reaction' },
  ];
  const CAT_ORDER = new Map(CATEGORIES.map((c, i) => [c.id, i]));
  const CAT_LABEL = new Map(CATEGORIES.map((c) => [c.id, c.label]));

  const WHY = {
    funny: 'Laughter or joking language here, which often marks a funny beat.',
    rage: 'Frustration or swearing, which may be a rage moment.',
    glitch: 'Words like "glitch", "stuck" or "what happened" suggest something broke in an odd way.',
    police: 'Police or chase vocabulary, likely a chase or an escape.',
    crash: 'Crash, flip or explosion words, likely a vehicle crash or blast.',
    death: 'Death or kill words, possibly an unexpected death.',
    crazy: 'Excited reaction to a close call or a skilful play.',
    conversation: 'Back-and-forth banter, joking or arguing with someone.',
    surprise: 'Sudden surprise reactions such as "wait what".',
    viral: 'Loud, emphatic reaction (capitals, exclamations, repeated words), good Shorts material.',
    roast: 'Insults or teasing aimed at someone, which often makes a roast clip.',
    argument: 'Fast back-and-forth with disagreement words, possibly an argument.',
    emotional: 'Emotional words (sad, sorry, thank you, proud), possibly a heartfelt or dramatic beat.',
    discovery: 'Finding or noticing something unexpected ("found it", "look at this", "secret").',
    suspicious: 'Suspicious or sneaky wording ("sus", "something is off", "who is that").',
    epic: 'Big hype or celebration after a win or a great play.',
  };

  /* ------------------------------------------------------------------ */
  /* Word lists                                                          */
  /* Groups: [weight, language, [terms]]                                 */
  /* language: x = shared gaming words, en = English phrases,            */
  /*           hn = romanised Hindi (Hinglish), hi = Devanagari          */
  /* ------------------------------------------------------------------ */
  const LEXICON = {
    funny: [
      [1.3, 'x', ['lmao', 'lmfao', 'rofl', 'hilarious', 'cant stop laughing', "can't stop laughing"]],
      [1.0, 'x', ['lol', 'bruh moment', 'bro what', 'im dying', "i'm dying", 'so funny', "that's funny", 'thats funny']],
      [0.6, 'x', ['bruh', 'laughing', 'funny', 'comedy']],
      [1.0, 'hn', ['kitna funny', 'hasi', 'hansi']],
      [0.6, 'hn', ['mazak', 'mazaak', 'hasna', 'kya bakwas', 'pagal']],
      [1.0, 'hi', ['हा हा', 'हाहा']],
      [0.8, 'hi', ['हंसी', 'हँसी']],
      [0.6, 'hi', ['मज़ाक', 'मजाक', 'पागल', 'कॉमेडी']],
    ],
    rage: [
      [1.4, 'x', ['what the fuck', 'wtf', 'bullshit']],
      [1.0, 'en', ['what the hell', 'are you kidding me', "you've got to be kidding", 'i hate this', 'i quit', 'rage']],
      [0.9, 'x', ['fuck', 'fucking']],
      [0.7, 'x', ['idiot', 'stupid', 'shit']],
      [0.5, 'en', ['damn', 'come on', 'seriously', 'so annoying']],
      [1.0, 'hn', ['bsdk', 'bhosdike', 'bhenchod', 'behenchod', 'madarchod', 'dimag kharab', 'pagal hai kya']],
      [0.9, 'hn', ['chutiya', 'gaand', 'tang aa gaya', 'gussa']],
      [0.7, 'hn', ['bc', 'mc', 'kya bakchodi']],
      [0.5, 'hn', ['saala', 'sala', 'kutta', 'bakwas', 'bekar', 'kya kar raha hai']],
      [1.0, 'hi', ['दिमाग खराब', 'पागल है क्या']],
      [0.8, 'hi', ['गुस्सा']],
      [0.6, 'hi', ['बकवास', 'साला', 'कुत्ता']],
    ],
    glitch: [
      [1.4, 'x', ['glitch', 'glitched', 'glitching', 'fell through the map']],
      [1.2, 'x', ['bugged', 'teleported', 'under the map', 'how did that happen']],
      [1.0, 'x', ['invisible', 'ragdoll']],
      [0.9, 'x', ['bug', 'teleport']],
      [0.7, 'x', ['flying', 'floating', 'physics', 'what happened']],
      [0.5, 'x', ['stuck', 'lag', 'lagging', 'frozen', 'broken']],
      [1.3, 'hn', ['bug ho gaya', 'gayab ho gaya']],
      [1.0, 'hn', ['ye kya hua', 'yeh kya hua', 'ye kaise hua', 'kaise hua', 'gayab']],
      [0.8, 'hn', ['hawa mein', 'ud raha', 'ud gaya', 'atak gaya']],
      [0.6, 'hn', ['atka', 'kya hua']],
      [1.4, 'hi', ['ग्लिच']],
      [1.0, 'hi', ['ये क्या हुआ', 'कैसे हुआ', 'गायब']],
      [0.9, 'hi', ['बग', 'उड़ गया', 'उड़ रहा']],
      [0.6, 'hi', ['क्या हुआ']],
    ],
    police: [
      [1.3, 'x', ['five stars', '5 stars', 'lose the cops', 'spike strip']],
      [1.2, 'x', ['chase', 'chasing', 'chased', 'pit maneuver', 'roadblock']],
      [1.1, 'x', ['swat', 'getaway', 'busted']],
      [1.0, 'x', ['police', 'cops', 'arrested']],
      [0.9, 'x', ['cop', 'helicopter', 'escaped']],
      [0.8, 'x', ['wanted', 'escape', 'lost them']],
      [0.6, 'x', ['stars']],
      [1.2, 'hn', ['police aa gayi', 'police pichhe', 'gaadi bhagao']],
      [1.1, 'hn', ['police wale', 'pakda gaya']],
      [1.0, 'hn', ['bhaag', 'bhago', 'bhaagna', 'pichhe pad', 'jail']],
      [0.7, 'hn', ['pakad', 'bhag', 'heli', 'thana']],
      [1.0, 'hi', ['पुलिस', 'भागो', 'पीछे पड़', 'हेलीकॉप्टर']],
      [0.9, 'hi', ['जेल']],
      [0.7, 'hi', ['पकड़', 'भाग']],
    ],
    crash: [
      [1.3, 'x', ['crashed', 'blew up', 'totaled', 'wrecked']],
      [1.2, 'x', ['crash', 'crashing', 'smashed', 'flipped', 'exploded', 'rolled over', 'rammed', 'oh no my car']],
      [1.0, 'x', ['explosion', 'explode', 'collision', 'head on', 'accident', 'blow up']],
      [0.8, 'x', ['boom', 'smash', 'flip']],
      [0.5, 'x', ['my car']],
      [1.3, 'hn', ['takkar maar']],
      [1.2, 'hn', ['thok diya', 'ulat gaya', 'takkar']],
      [1.0, 'hn', ['tod diya', 'blast', 'dhamaka']],
      [0.8, 'hn', ['thok', 'tuut gaya']],
      [0.5, 'hn', ['gaadi', 'gadi']],
      [1.2, 'hi', ['ठोक दिया', 'टक्कर']],
      [1.0, 'hi', ['पलट', 'धमाका', 'ब्लास्ट']],
      [0.8, 'hi', ['ठोक', 'टूट गया']],
      [0.5, 'hi', ['गाड़ी']],
    ],
    death: [
      [1.3, 'x', ['ran him over', 'mar gaya', 'mar gya', 'mar gayi']],
      [1.2, 'x', ['wasted', 'headshot', 'one shotted', 'i died', 'run over']],
      [1.0, 'x', ['died', 'im dead', "i'm dead", 'sniped', 'downed', 'he died', 'shot me', 'rest in peace']],
      [0.9, 'x', ['dead', 'killed', 'one shot', 'murdered', 'shot him']],
      [0.6, 'x', ['die', 'rip', 'respawn']],
      [0.5, 'x', ['kill']],
      [1.2, 'hn', ['mar gaye', 'mara gaya', 'maar diya', 'dead ho gaya', 'khatam ho gaya']],
      [1.0, 'hn', ['uda diya', 'shaheed']],
      [0.9, 'hn', ['maut', 'khatam']],
      [0.5, 'hn', ['mara']],
      [1.3, 'hi', ['मर गया', 'मर गई']],
      [1.2, 'hi', ['मर गए', 'मार दिया']],
      [1.0, 'hi', ['शहीद']],
      [0.9, 'hi', ['खत्म', 'मौत']],
    ],
    crazy: [
      [1.3, 'x', ['insane shot', 'bal bal bach']],
      [1.2, 'x', ['insane', 'clutch', 'what a shot', 'just made it']],
      [1.1, 'x', ['no way', 'kya shot', 'bach gaya', 'ghazab', 'gajab']],
      [1.0, 'x', ['unbelievable', 'stunt', 'so lucky', 'dodged', 'that was close', 'kamaal', 'zabardast', 'bawal', 'dhaansu', 'dhansu', 'jhakaas', 'paisa vasool', 'cinema']],
      [0.9, 'x', ['crazy', 'kya baat', 'how did he', 'kya maara', 'bacha liya']],
      [0.8, 'x', ['so close', 'ramp', 'goated', 'jugaad']],
      [0.6, 'x', ['perfectly', 'lucky', 'barely', 'jumped', "let's go", 'lets go', 'cracked']],
      [0.5, 'x', ['perfect', 'jump', 'legend']],
      [1.1, 'hi', ['गज़ब', 'गजब', 'बच गया']],
      [1.0, 'hi', ['कमाल', 'ज़बरदस्त', 'जबरदस्त', 'बवाल', 'धांसू', 'झक्कास']],
    ],
    conversation: [
      [0.9, 'x', ['prank', 'roast', 'roasting']],
      [0.8, 'x', ['wait wait', 'banter', 'just kidding', 'kasam se', 'bakchodi', 'bakchod', 'kya bol raha', 'gyan mat', 'mazak mat']],
      [0.6, 'x', ['joke', 'kidding', 'i swear', 'jhooth', 'chup kar']],
      [0.5, 'x', ['no you', 'dare', 'trust me', 'jk', 'arre bhai', 'bhai sun', 'sach me', 'gyaan']],
      [0.3, 'x', ['bro', 'dude', 'bhai', 'yaar', 'suno', 'hold on']],
      [0.8, 'hi', ['बकचोदी', 'मज़ाक मत']],
      [0.7, 'hi', ['कसम']],
      [0.6, 'hi', ['झूठ', 'चुप कर']],
      [0.3, 'hi', ['भाई', 'यार', 'सुनो']],
    ],
    surprise: [
      [1.2, 'x', ['holy shit', 'out of nowhere', 'where did that come from', 'no no no', 'baap re', 'are baap re', 'kahan se aaya', 'kidhar se aaya']],
      [1.1, 'x', ['wait what', 'oh shit', "didn't expect", 'did not expect', 'oh teri']],
      [1.0, 'x', ['omg', 'oh my god', 'what was that', 'wait wait wait', 'achanak', 'achaanak', "i can't believe", 'cant believe', 'ye kya tha', 'yeh kya tha', 'ye kya ho raha', 'yeh kya ho raha']],
      [0.9, 'x', ['whoa', 'woah', 'unexpected', 'oh my gosh', 'what is happening', "what's happening", 'dar gaya main']],
      [0.8, 'x', ['holy', 'oh god', 'shock', 'hey bhagwan', 'kya hai ye']],
      [0.7, 'x', ['wow', 'suddenly', 'dar gaya']],
      [0.6, 'x', ['what the', 'arre', 'oh no', 'bhai kya', 'oh bhai']],
      [0.4, 'x', ['huh']],
      [1.1, 'hi', ['अरे बाप रे', 'बाप रे', 'कहाँ से आया']],
      [1.0, 'hi', ['अचानक', 'ये क्या था', 'ये क्या हो रहा']],
      [0.9, 'hi', ['ओह तेरी']],
      [0.8, 'hi', ['हे भगवान']],
      [0.6, 'hi', ['अरे']],
    ],
    viral: [
      [1.3, 'x', ['going viral', 'viral']],
      [1.2, 'x', ['clip it', 'clip that', 'clip kar', 'clip bana']],
      [1.0, 'x', ['chat is going crazy', 'chat pagal']],
      [0.9, 'x', ['pog', 'poggers', 'clipped']],
      [0.8, 'x', ['sheesh']],
      [0.6, 'x', ['clip', 'chat dekho']],
      [1.3, 'hi', ['वायरल']],
      [0.8, 'hi', ['क्लिप']],
    ],
    roast: [
      [1.1, 'x', ['you idiot', 'you clown', 'skill issue', 'noob', 'trash player', 'you suck', 'get good', 'ratio']],
      [0.8, 'x', ['clown', 'loser', 'dumbass', 'useless', 'pathetic', 'bot', 'tatti', 'chapri']],
      [1.0, 'hn', ['tu noob hai', 'tera dimag', 'ullu', 'ullu ka pattha', 'gadha', 'nalayak', 'nikamma', 'tatti player', 'bhikari']],
      [0.7, 'hn', ['chomu', 'bewakoof', 'bewakuf', 'paagal', 'lodu', 'bakra']],
      [0.9, 'hi', ['उल्लू', 'गधा', 'नालायक', 'निकम्मा', 'बेवकूफ']],
    ],
    argument: [
      [1.0, 'x', ['shut up', 'you are wrong', "you're wrong", 'no you', 'liar', 'i told you', 'not my fault', 'your fault', 'stop it']],
      [0.8, 'x', ['why did you', 'what did you do', 'how dare', 'give it back', 'that is mine']],
      [1.0, 'hn', ['chup kar', 'teri galti', 'meri galti nahi', 'maine bola tha', 'jhooth mat bol', 'bakwas band kar', 'tu chup']],
      [0.7, 'hn', ['kyun kiya', 'kyu kiya', 'tune kya kiya', 'wapas de', 'mera hai']],
      [0.9, 'hi', ['चुप कर', 'तेरी गलती', 'मेरी गलती नहीं', 'झूठ मत बोल']],
    ],
    emotional: [
      [1.1, 'x', ['i am sorry', "i'm sorry", 'rest in peace', 'i love you guys', 'thank you so much', 'i am proud', 'miss you', 'i cannot believe it', 'tears']],
      [0.8, 'x', ['crying', 'sad', 'heartbroken', 'emotional', 'goosebumps', 'touched']],
      [1.0, 'hn', ['maaf karna', 'bahut yaad', 'dil toot', 'aankhon mein aansu', 'rona aa gaya', 'emotional ho gaya', 'tera shukriya']],
      [0.7, 'hn', ['aansu', 'rona', 'shukriya', 'dhanyavaad']],
      [0.9, 'hi', ['आँसू', 'रोना आ गया', 'दिल टूट', 'शुक्रिया', 'धन्यवाद']],
    ],
    discovery: [
      [1.2, 'x', ['found it', 'i found a', 'secret room', 'hidden', 'easter egg', 'what is this place']],
      [1.0, 'x', ['look at this', 'check this out', 'did you see that', 'never seen this', 'first time seeing']],
      [0.7, 'x', ['secret', 'discover', 'discovered', 'noticed', 'interesting']],
      [1.1, 'hn', ['mil gaya', 'ye dekho', 'yeh dekho', 'dekho dekho', 'ye kya mila', 'chhupa hua', 'chhipa hua', 'naya mila']],
      [0.7, 'hn', ['dekho', 'mila', 'dikh gaya']],
      [1.0, 'hi', ['मिल गया', 'ये देखो', 'देखो देखो', 'छुपा हुआ']],
    ],
    suspicious: [
      [1.1, 'x', ['that is sus', 'thats sus', "that's sus", 'who is that', 'something is off', 'something is wrong', 'is he following me', 'is someone there', 'behind me']],
      [0.8, 'x', ['sus', 'suspicious', 'sketchy', 'weird guy', 'creepy', 'following me']],
      [1.0, 'hn', ['koi hai', 'kaun hai', 'peeche koi', 'piche koi', 'kuch gadbad', 'shak ho raha', 'mujhe shak']],
      [0.7, 'hn', ['gadbad', 'shak', 'dar lag raha']],
      [1.0, 'hi', ['कोई है', 'कौन है', 'कुछ गड़बड़', 'शक हो रहा']],
    ],
    epic: [
      [1.2, 'x', ['we did it', 'we won', 'victory', 'mission passed', 'finally', 'lets gooo', "let's gooo", 'goat']],
      [1.0, 'x', ['legendary', 'epic', 'what a play', 'that was sick', 'so clean', 'too easy', 'gg']],
      [0.7, 'x', ['clean', 'sick', 'nice one', 'well played']],
      [1.1, 'hn', ['jeet gaye', 'jeet gaya', 'mission pass', 'hum jeet', 'kar diya', 'kaam ho gaya', 'maza aa gaya', 'full paisa vasool']],
      [0.7, 'hn', ['jeet', 'badhiya', 'mast']],
      [1.0, 'hi', ['जीत गए', 'जीत गया', 'कर दिया', 'मज़ा आ गया', 'मजा आ गया']],
    ],
  };

  // Spelling-flexible words (laughs, elongated shouts), matched per token.
  const REGEX_TERMS = [
    { re: /^(?:ha){2,}h?$/, cat: 'funny', weight: 1.2, text: 'haha', lang: 'x' },
    { re: /^(?:he){2,}h?$/, cat: 'funny', weight: 0.8, text: 'hehe', lang: 'x' },
    { re: /^l+o+l+$/, cat: 'funny', weight: 1.0, text: 'lol', lang: 'x' },
    { re: /^lma+o+$/, cat: 'funny', weight: 1.3, text: 'lmao', lang: 'x' },
    { re: /^no{3,}$/, cat: 'surprise', weight: 1.0, text: 'nooo', lang: 'x' },
  ];

  const LANG_ALLOW = {
    auto: new Set(['x', 'en', 'hn', 'hi']),
    english: new Set(['x', 'en']),
    hindi: new Set(['x', 'hi', 'hn']),
    hinglish: new Set(['x', 'hn', 'en']),
  };

  /* ------------------------------------------------------------------ */
  /* Errors                                                              */
  /* ------------------------------------------------------------------ */
  class TranscriptError extends Error {
    constructor(message, code) {
      super(message);
      this.name = 'TranscriptError';
      this.code = code || 'invalid';
      this.userMessage = message;
    }
  }

  /* ------------------------------------------------------------------ */
  /* Time helpers                                                        */
  /* ------------------------------------------------------------------ */
  function parseTimestamp(str) {
    const m = /^(?:(\d{1,3}):)?(\d{1,2}):(\d{2})(?:[.,](\d{1,3}))?$/.exec(String(str).trim());
    if (!m) return null;
    const hasHours = m[1] !== undefined;
    const h = hasHours ? parseInt(m[1], 10) : 0;
    const mi = parseInt(m[2], 10);
    const s = parseInt(m[3], 10);
    if (s > 59) return null;
    if (hasHours && mi > 59) return null;
    const ms = m[4] ? parseInt((m[4] + '00').slice(0, 3), 10) : 0;
    return ((h * 60 + mi) * 60 + s) * 1000 + ms;
  }

  function pad2(n) {
    return n < 10 ? '0' + n : String(n);
  }

  function formatTime(seconds) {
    const t = Math.max(0, Math.floor(Number(seconds) || 0));
    const h = Math.floor(t / 3600);
    const m = Math.floor((t % 3600) / 60);
    const s = t % 60;
    return h + ':' + pad2(m) + ':' + pad2(s);
  }

  /* ------------------------------------------------------------------ */
  /* YouTube helpers                                                     */
  /* ------------------------------------------------------------------ */
  const ID_RE = /^[A-Za-z0-9_-]{11}$/;
  const YT_HOSTS = new Set([
    'youtube.com',
    'www.youtube.com',
    'm.youtube.com',
    'music.youtube.com',
    'www.youtube-nocookie.com',
    'youtu.be',
  ]);

  function isValidVideoId(id) {
    return typeof id === 'string' && ID_RE.test(id);
  }

  function extractVideoId(input) {
    if (typeof input !== 'string') return null;
    const s = input.trim();
    if (!s || s.length > LIMITS.maxInputChars) return null;
    if (ID_RE.test(s)) return s;
    let url;
    try {
      url = new URL(/^https?:\/\//i.test(s) ? s : 'https://' + s);
    } catch (e) {
      return null;
    }
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return null;
    const host = url.hostname.toLowerCase();
    if (!YT_HOSTS.has(host)) return null;
    let id = null;
    if (host === 'youtu.be') {
      id = url.pathname.split('/')[1] || null;
    } else if (url.pathname === '/watch') {
      id = url.searchParams.get('v');
    } else {
      const m = /^\/(?:live|embed|shorts|v)\/([^/?#]+)/.exec(url.pathname);
      id = m ? m[1] : null;
    }
    return isValidVideoId(id) ? id : null;
  }

  function youtubeLink(videoId, seconds) {
    if (!isValidVideoId(videoId)) return null;
    return 'https://www.youtube.com/watch?v=' + videoId + '&t=' + Math.max(0, Math.floor(seconds)) + 's';
  }

  /* ------------------------------------------------------------------ */
  /* Input validation                                                    */
  /* ------------------------------------------------------------------ */
  function validateFileMeta(meta) {
    const name = String((meta && meta.name) || '');
    const size = Number(meta && meta.size);
    const dot = name.lastIndexOf('.');
    const ext = dot >= 0 ? name.slice(dot).toLowerCase() : '';
    if (!LIMITS.allowedExtensions.includes(ext)) {
      throw new TranscriptError('Please choose a .srt, .vtt or .txt transcript file.', 'bad-type');
    }
    if (!Number.isFinite(size) || size < 0) {
      throw new TranscriptError('Could not read the file size.', 'bad-size');
    }
    if (size === 0) throw new TranscriptError('That file is empty.', 'empty');
    if (size > LIMITS.maxBytes) {
      throw new TranscriptError(
        'That file is larger than ' + LIMITS.maxBytes / 1024 / 1024 + ' MB. A transcript of an 8-hour stream is usually under 2 MB, so this is probably the wrong file.',
        'too-big'
      );
    }
    return true;
  }

  function validateText(text) {
    if (typeof text !== 'string') throw new TranscriptError('No transcript text was provided.', 'empty');
    if (text.length > LIMITS.maxBytes) {
      throw new TranscriptError('That text is larger than ' + LIMITS.maxBytes / 1024 / 1024 + ' MB.', 'too-big');
    }
    if (text.indexOf('\u0000') !== -1) {
      throw new TranscriptError('That does not look like a text transcript (it contains binary data).', 'binary');
    }
    if (!text.trim()) throw new TranscriptError('The transcript is empty.', 'empty');
    return true;
  }

  /* ------------------------------------------------------------------ */
  /* Transcript parsing                                                  */
  /* ------------------------------------------------------------------ */
  const TS_SRC = '(?:\\d{1,3}:)?\\d{1,2}:\\d{2}(?:[.,]\\d{1,3})?';
  const ARROW_RE = new RegExp('^\\s*(' + TS_SRC + ')\\s*-->\\s*(' + TS_SRC + ')(?:\\s.*)?$');
  const ARROW_ANY_RE = new RegExp('^\\s*' + TS_SRC + '\\s*-->', 'm');
  const PASTED_RE = new RegExp('^\\s*[\\[(]?(' + TS_SRC + ')[\\])]?\\s*(?:[-\\u2013\\u2014:|]\\s*)?(.*)$');

  const ENTITIES = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&nbsp;': ' ', '&quot;': '"', '&#39;': "'" };

  function cleanCueText(s) {
    return s
      .replace(/<\/?[a-zA-Z][^>]*>/g, '')
      .replace(/<\d{1,3}:\d{2}[^>]*>/g, '')
      .replace(/\{\\[^}]*\}/g, '')
      .replace(/&(?:amp|lt|gt|nbsp|quot|#39);/g, (e) => ENTITIES[e])
      .replace(/[ \t]+/g, ' ')
      .trim();
  }

  function parseArrowFormat(text, stats) {
    const lines = text.split('\n');
    const raw = [];
    let cur = null;
    const flush = () => {
      if (cur) raw.push(cur);
      cur = null;
    };
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const m = ARROW_RE.exec(line);
      if (m) {
        // Malformed file without a blank line between cues: the previous cue's
        // last line may really be this cue's index number. Remove it.
        if (cur && cur.lines.length > 1 && /^\d+$/.test(cur.lines[cur.lines.length - 1].trim())) {
          cur.lines.pop();
        }
        flush();
        stats.timingLines++;
        const s = parseTimestamp(m[1]);
        const e = parseTimestamp(m[2]);
        cur = { startMs: s, endMs: e, lines: [] };
        continue;
      }
      if (!cur) continue;
      if (line.trim() === '') {
        flush();
      } else {
        const cleaned = cleanCueText(line);
        if (cleaned) cur.lines.push(cleaned);
      }
    }
    flush();
    return raw;
  }

  // YouTube "rolling" auto-captions repeat the previous line in the next cue.
  // Only multi-line cues are treated this way, so a streamer who really says
  // the same single line twice ("no" ... "no") keeps both cues.
  function removeRollingRepeats(raw, stats) {
    const out = [];
    let prev = null;
    for (const cue of raw) {
      let lines = cue.lines;
      const placeholder = cue.endMs - cue.startMs <= 50; // YouTube's 10 ms filler cues
      if (prev && (prev.lines.length >= 2 || lines.length >= 2 || placeholder)) {
        const fresh = lines.filter((l) => prev.lines.indexOf(l) === -1);
        if (fresh.length === 0) {
          stats.repeatDropped++;
          const last = out[out.length - 1];
          if (last && cue.endMs > last.endMs) last.endMs = cue.endMs;
          prev = cue;
          continue;
        }
        if (fresh.length !== lines.length) stats.repeatTrimmed++;
        lines = fresh;
      }
      out.push({ startMs: cue.startMs, endMs: cue.endMs, text: lines.join(' ') });
      prev = cue;
    }
    return out;
  }

  function parsePastedFormat(text) {
    const lines = text.split('\n');
    const raw = [];
    let cur = null;
    for (const line of lines) {
      const m = PASTED_RE.exec(line);
      const ms = m ? parseTimestamp(m[1]) : null;
      if (m && ms !== null) {
        if (cur) raw.push(cur);
        cur = { startMs: ms, parts: [] };
        const rest = cleanCueText(m[2]);
        if (rest) cur.parts.push(rest);
      } else if (cur) {
        const t = cleanCueText(line);
        if (t) cur.parts.push(t);
      }
    }
    if (cur) raw.push(cur);
    const cues = [];
    for (let i = 0; i < raw.length; i++) {
      const c = raw[i];
      const text2 = c.parts.join(' ').trim();
      if (!text2) continue;
      const nextStart = i + 1 < raw.length ? raw[i + 1].startMs : null;
      let endMs;
      if (nextStart === null) endMs = c.startMs + PASTED_LAST_CUE_MS;
      else endMs = Math.min(Math.max(nextStart, c.startMs), c.startMs + PASTED_MAX_CUE_MS);
      cues.push({ startMs: c.startMs, endMs, text: text2 });
    }
    return cues;
  }

  function parseTranscript(input) {
    validateText(input);
    let text = input.replace(/^﻿/, '').replace(/\r\n?/g, '\n');
    const stats = { timingLines: 0, emptyDropped: 0, repeatDropped: 0, repeatTrimmed: 0, outOfOrder: false };
    const warnings = [];
    let format;
    let cues;
    if (/^\s*WEBVTT/.test(text)) format = 'vtt';
    else if (ARROW_ANY_RE.test(text)) format = 'srt';
    else format = 'pasted';

    if (format === 'pasted') {
      cues = parsePastedFormat(text);
    } else {
      const raw = parseArrowFormat(text, stats);
      const valid = [];
      for (const c of raw) {
        if (c.startMs === null || c.endMs === null) continue;
        if (c.lines.length === 0) {
          stats.emptyDropped++;
          continue;
        }
        valid.push({ startMs: c.startMs, endMs: Math.max(c.endMs, c.startMs), lines: c.lines });
      }
      cues = removeRollingRepeats(valid, stats);
    }

    if (cues.length === 0) {
      throw new TranscriptError(
        'No timestamped lines were found. Use an .srt/.vtt file or paste lines that start with a time such as 1:23:45 or 00:01:23,500.',
        'no-cues'
      );
    }
    if (cues.length > LIMITS.maxCues) {
      throw new TranscriptError('That transcript has more than ' + LIMITS.maxCues + ' lines, which is more than this tool accepts.', 'too-many');
    }
    for (let i = 1; i < cues.length; i++) {
      if (cues[i].startMs < cues[i - 1].startMs) {
        stats.outOfOrder = true;
        break;
      }
    }
    if (stats.outOfOrder) {
      cues = cues
        .map((c, i) => ({ c, i }))
        .sort((a, b) => a.c.startMs - b.c.startMs || a.i - b.i)
        .map((x) => x.c);
      warnings.push('Some lines were out of time order, so they were sorted by time.');
    }
    if (stats.emptyDropped) warnings.push(stats.emptyDropped + ' timed line(s) had no text and were skipped.');
    if (stats.repeatDropped + stats.repeatTrimmed) {
      warnings.push('Repeated caption lines (common in YouTube auto-captions) were merged.');
    }
    return { format, cues, warnings, stats };
  }

  /* ------------------------------------------------------------------ */
  /* Scoring                                                             */
  /* ------------------------------------------------------------------ */
  function tokenize(str) {
    const norm = String(str).normalize('NFC').toLowerCase().replace(/[’‘`]/g, "'");
    const raw = norm.match(/[\p{L}\p{M}\p{N}']+/gu) || [];
    const out = [];
    for (const t of raw) {
      const c = t.replace(/^'+|'+$/g, '');
      if (c) out.push(c);
    }
    return out;
  }

  const indexCache = new Map();
  function getIndex(language) {
    const key = LANG_ALLOW[language] ? language : 'auto';
    if (indexCache.has(key)) return indexCache.get(key);
    const allowed = LANG_ALLOW[key];
    const byFirst = new Map();
    for (const cat of Object.keys(LEXICON)) {
      for (const group of LEXICON[cat]) {
        const weight = group[0];
        const lang = group[1];
        if (!allowed.has(lang)) continue;
        for (const term of group[2]) {
          const tokens = tokenize(term);
          if (!tokens.length) continue;
          if (!byFirst.has(tokens[0])) byFirst.set(tokens[0], []);
          byFirst.get(tokens[0]).push({ cat, weight, tokens, text: term });
        }
      }
    }
    for (const list of byFirst.values()) list.sort((a, b) => b.tokens.length - a.tokens.length);
    const regexes = REGEX_TERMS.filter((r) => allowed.has(r.lang));
    const idx = { byFirst, regexes };
    indexCache.set(key, idx);
    return idx;
  }

  const CAPS_IGNORE = new Set(['GTA', 'FPS', 'NPC', 'USA', 'OK', 'PC', 'AI', 'RP', 'HD', 'TV', 'UK', 'SUV']);
  const LAUGH_MARK_RE = /\[(?:laughter|laughs|laughing|applause|cheering)\]|\((?:laughter|laughs|laughing)\)|\*(?:laughs|laughing)\*|[\u{1F602}\u{1F923}\u{1F606}]/iu;
  const CAT_CUE_CAP = 2.5;
  // Interjections that are said constantly. One of these alone, with nothing around it, is not a moment.
  const GENERIC_REACTIONS = new Set([
    'lol', 'lmao', 'lmfao', 'rofl', 'omg', 'wtf', 'shit', 'fuck', 'fucking', 'bruh', 'wow', 'damn', 'holy', 'huh', 'haha', 'hehe',
    'nooo', 'oh my god', 'oh my gosh', 'what the', 'oh no', 'arre', 'bc', 'mc', 'pog', 'poggers', 'sheesh', 'bullshit', 'oh shit',
    'holy shit', 'stupid', 'idiot', 'seriously', 'come on', 'bro', 'dude', 'bhai', 'yaar', 'whoa', 'woah', 'bro what', 'bruh moment',
  ]);

  function scoreCue(cue, index) {
    const cats = {};
    const terms = [];
    let any = false;
    const add = (cat, w, label) => {
      cats[cat] = Math.min(CAT_CUE_CAP, (cats[cat] || 0) + w);
      if (label && terms.indexOf(label) === -1) terms.push(label);
      any = true;
    };
    const tokens = tokenize(cue.text);

    let i = 0;
    while (i < tokens.length) {
      const cands = index.byFirst.get(tokens[i]);
      let matchedLen = 0;
      if (cands) {
        for (const e of cands) {
          if (matchedLen && e.tokens.length < matchedLen) break;
          let ok = i + e.tokens.length <= tokens.length;
          for (let k = 1; ok && k < e.tokens.length; k++) if (tokens[i + k] !== e.tokens[k]) ok = false;
          if (ok) {
            matchedLen = e.tokens.length;
            add(e.cat, e.weight, e.text);
          }
        }
      }
      if (!matchedLen) {
        const t = tokens[i];
        if (t.length <= 14) {
          for (const r of index.regexes) {
            if (r.re.test(t)) {
              add(r.cat, r.weight, r.text);
              break;
            }
          }
        }
      }
      i += matchedLen || 1;
    }

    if (LAUGH_MARK_RE.test(cue.text)) add('funny', 1.4, '[laughter]');

    // Emphatic delivery: exclamations, SHOUTING, stretched words, repeated words.
    const text = cue.text;
    const excl = Math.min(3, (text.match(/!/g) || []).length);
    let caps = 0;
    for (const w of text.match(/\b[A-Z]{3,}\b/g) || []) if (!CAPS_IGNORE.has(w)) caps++;
    caps = Math.min(3, caps);
    let stretch = 0;
    for (const t of tokens) if (t.length >= 4 && /([a-z])\1{2,}/.test(t)) stretch++;
    stretch = Math.min(3, stretch);
    let repeat = 0;
    for (let a = 2; a < tokens.length; a++) {
      if (tokens[a] === tokens[a - 1] && tokens[a] === tokens[a - 2] && tokens[a].length > 1) {
        repeat = 1;
        break;
      }
    }
    const viral = Math.min(2, 0.35 * excl + 0.4 * caps + 0.4 * stretch + 0.5 * repeat);
    if (viral >= 0.35) {
      cats.viral = Math.min(CAT_CUE_CAP, (cats.viral || 0) + viral);
      any = true;
    }
    const isQuestion = /[?？]/.test(text);
    return any ? { cats, terms, emphasis: viral, question: isQuestion, tokenCount: tokens.length } : null;
  }

  function scoreAll(cues, index) {
    const hits = new Map();
    for (let i = 0; i < cues.length; i++) {
      const h = scoreCue(cues[i], index);
      if (h) hits.set(i, h);
    }
    return hits;
  }

  function windowAt(cues, hits, i) {
    const n = cues.length;
    const t0 = cues[i].startMs;
    const sums = {};
    let j = i;
    let hitCount = 0;
    let allGeneric = true;
    let anyEmphasis = false;
    let shortCues = 0;
    let questions = 0;
    while (j < n && cues[j].startMs < t0 + WINDOW_MS) {
      const h = hits.get(j);
      if (h) {
        hitCount++;
        for (const c in h.cats) sums[c] = (sums[c] || 0) + h.cats[c];
        for (const t of h.terms) if (!GENERIC_REACTIONS.has(t)) allGeneric = false;
        if (h.emphasis >= 0.35) anyEmphasis = true;
      }
      if (cues[j].text && Array.from(cues[j].text.split(/\s+/)).length <= 7) shortCues++;
      if (/[?？]/.test(cues[j].text)) questions++;
      j++;
    }
    let base = 0;
    let distinct = 0;
    for (const c in sums) {
      let s = Math.min(sums[c], 3);
      if (c === 'conversation' || c === 'argument' || c === 'roast') s *= 0.6;
      sums[c] = s;
      base += s;
      if (s >= 0.5) distinct++;
    }
    let score = base + 0.35 * Math.min(Math.max(distinct - 1, 0), 3);
    if (base > 0 && (j - i) / (WINDOW_MS / 1000) >= 0.6) score += 0.25;

    // Context 1: fast back-and-forth (many short lines, with a question) around a signal.
    if (base > 0 && shortCues >= 4 && questions >= 1 && hitCount >= 1) {
      score += 0.3;
      sums.conversation = (sums.conversation || 0) + 0.6;
    }
    // Context 2: a lone generic interjection (one "lol", one "omg") with nothing around it is not a moment.
    if (hitCount === 1 && allGeneric && !anyEmphasis) score *= 0.55;
    // Context 3: several lines carrying signal in a row is stronger than one loud line.
    if (hitCount >= 3) score += 0.2;
    return { score, sums, endIdx: j, hitCount, anyEmphasis };
  }

  function truncate(str, max) {
    const chars = Array.from(str);
    return chars.length > max ? chars.slice(0, max).join('').trimEnd() + '…' : str;
  }

  function buildMoment(cues, hits, i, w) {
    // last hit cue inside the window that still keeps the moment under the cap
    let lastHit = i;
    for (let j = i; j < w.endIdx; j++) {
      if (hits.has(j) && cues[j].endMs - cues[i].startMs <= MAX_MOMENT_MS) lastHit = j;
    }
    let startIdx = i;
    if (startIdx > 0 && cues[startIdx].startMs - cues[startIdx - 1].startMs <= LEAD_IN_MS) startIdx--;
    const startMs = cues[startIdx].startMs;
    const endMs = Math.max(cues[lastHit].endMs, startMs);

    const catEntries = Object.keys(w.sums)
      .map((c) => [c, w.sums[c]])
      .sort((a, b) => b[1] - a[1] || CAT_ORDER.get(a[0]) - CAT_ORDER.get(b[0]));
    let categories = catEntries.filter((e) => e[1] >= 0.6).map((e) => e[0]).slice(0, 3);
    if (!categories.length && catEntries.length) categories = [catEntries[0][0]];

    const terms = [];
    const parts = [];
    for (let j = startIdx; j <= lastHit; j++) {
      parts.push(cues[j].text);
      const h = hits.get(j);
      if (h) for (const t of h.terms) if (terms.indexOf(t) === -1) terms.push(t);
    }
    return {
      startMs,
      endMs,
      score: w.score,
      categories,
      primary: categories[0] || 'surprise',
      terms: terms.slice(0, 6),
      excerpt: truncate(parts.join(' '), 180),
      cueStart: startIdx,
      cueEnd: lastHit,
      hitCount: w.hitCount || 1,
      hasEmphasis: !!w.anyEmphasis,
      mergedFrom: 1,
    };
  }

  function conflicts(a, b, gapMs) {
    return a.startMs - gapMs < b.endMs && b.startMs - gapMs < a.endMs;
  }

  function mergeMoments(list, gapMs) {
    const gap = gapMs === undefined ? DEDUPE_GAP_MS : gapMs;
    const sorted = list.slice().sort((a, b) => b.score - a.score || a.startMs - b.startMs);
    const kept = [];
    for (const m of sorted) {
      const k = kept.find((x) => conflicts(x, m, gap));
      if (k) {
        k.mergedFrom += m.mergedFrom || 1;
        for (const c of m.categories) if (k.categories.indexOf(c) === -1 && k.categories.length < 3) k.categories.push(c);
        for (const t of m.terms) if (k.terms.indexOf(t) === -1 && k.terms.length < 6) k.terms.push(t);
      } else {
        kept.push(Object.assign({}, m, { categories: m.categories.slice(), terms: m.terms.slice() }));
      }
    }
    return kept;
  }

  function selectFromChunk(cues, hits, lo, hi, limit) {
    const cands = [];
    for (let i = lo; i < hi; i++) {
      if (!hits.has(i)) continue;
      const w = windowAt(cues, hits, i);
      if (w.score >= MIN_SCORE) cands.push({ i, w });
    }
    cands.sort((a, b) => b.w.score - a.w.score || a.i - b.i);
    const selected = [];
    for (const c of cands) {
      if (selected.length >= limit) break;
      const m = buildMoment(cues, hits, c.i, c.w);
      if (selected.some((s) => conflicts(s, m, DEDUPE_GAP_MS))) continue;
      selected.push(m);
    }
    return { moments: selected, candidates: cands.length };
  }

  function makeChunks(cues, chunkMs) {
    const chunks = [];
    let lo = 0;
    let chunkStart = cues[0].startMs;
    for (let i = 1; i < cues.length; i++) {
      if (cues[i].startMs >= chunkStart + chunkMs) {
        chunks.push({ lo, hi: i });
        lo = i;
        chunkStart = cues[i].startMs;
      }
    }
    chunks.push({ lo, hi: cues.length });
    return chunks;
  }

  function confidenceFor(score) {
    return Math.min(MAX_CONFIDENCE, Math.round(100 * (1 - Math.exp(-score / 3.2))));
  }

  function clamp(v, lo, hi, dflt) {
    const n = Number(v);
    if (!Number.isFinite(n)) return dflt;
    return Math.min(hi, Math.max(lo, n));
  }

  function normalizeOptions(opts) {
    const o = opts || {};
    return {
      language: LANG_ALLOW[o.language] ? o.language : 'auto',
      count: Math.round(clamp(o.count, 1, 50, 20)),
      padSec: Math.round(clamp(o.padSec, 10, 15, 12)),
      chunkMs: Math.round(clamp(o.chunkMs, 60000, 24 * 3600 * 1000, 30 * 60 * 1000)),
      videoId: isValidVideoId(o.videoId) ? o.videoId : null,
    };
  }

  function detectScript(cues) {
    let dev = 0;
    let latin = 0;
    const step = Math.max(1, Math.floor(cues.length / 2000));
    for (let i = 0; i < cues.length; i += step) {
      for (const ch of cues[i].text) {
        if (/[ऀ-ॿ]/.test(ch)) dev++;
        else if (/[A-Za-z]/.test(ch)) latin++;
      }
    }
    const total = dev + latin;
    return { devanagariRatio: total ? dev / total : 0, latinRatio: total ? latin / total : 0 };
  }

  function intensityFor(score, emphasis) {
    if (score >= 4 || (score >= 3 && emphasis)) return 'high';
    if (score >= 2.2) return 'medium';
    return 'low';
  }

  // Recording window for a moment with any padding from 0 to 60 seconds.
  function recordWindow(m, padSec, lastEndMs, videoId) {
    const pad = Math.round(clamp(padSec, 0, 60, 12));
    const padMs = pad * 1000;
    const last = Number.isFinite(lastEndMs) ? lastEndMs : m.endMs + padMs;
    const recStartMs = Math.max(0, m.startMs - padMs);
    const recEndMs = Math.min(Math.max(last, m.endMs), m.endMs + padMs);
    const recStartSec = Math.floor(recStartMs / 1000);
    const recEndSec = Math.ceil(recEndMs / 1000);
    return {
      padSec: pad,
      recStartSec,
      recEndSec,
      recStartText: formatTime(recStartSec),
      recEndText: formatTime(recEndSec),
      recDurationSec: recEndSec - recStartSec,
      recLink: youtubeLink(videoId, recStartSec),
      shortsFit: recEndSec - recStartSec >= 20 && recEndSec - recStartSec <= 35,
    };
  }

  function finalize(m, rank, o, lastEndMs) {
    const startSec = Math.floor(m.startMs / 1000);
    const endSec = Math.ceil(m.endMs / 1000);
    const rw = recordWindow(m, o.padSec, lastEndMs, o.videoId);
    const conf = confidenceFor(m.score);
    const why = m.categories.map((c) => WHY[c]).slice(0, 2);
    if (m.categories.length >= 2) why.push('Several kinds of signal appear together, which raises confidence.');
    if (m.hitCount >= 3) why.push('Several lines in a row carry signal, so it is more than one loud word.');
    why.push('Based on transcript wording only. Open it to confirm what happens on screen.');
    const evidence = {
      source: 'transcript',
      method: 'keyword and context scoring',
      matchedTerms: m.terms.slice(),
      transcript: m.terms.slice(),
      visual: [],
      inference: ['Category and "why" are guessed from wording; nothing was seen or heard.'],
      visuallyVerified: false,
      chatChecked: false,
    };
    return {
      rank,
      category: m.primary,
      categoryLabel: CAT_LABEL.get(m.primary),
      categories: m.categories.slice(),
      startMs: m.startMs,
      endMs: m.endMs,
      startSec,
      endSec,
      recStartSec: rw.recStartSec,
      recEndSec: rw.recEndSec,
      startText: formatTime(startSec),
      endText: formatTime(endSec),
      recStartText: rw.recStartText,
      recEndText: rw.recEndText,
      recDurationSec: rw.recDurationSec,
      shortsFit: rw.shortsFit,
      intensity: intensityFor(m.score, m.hasEmphasis),
      description: m.excerpt,
      why: why.join(' '),
      confidence: conf,
      score: Math.round(m.score * 100) / 100,
      evidence,
      evidenceText:
        'Transcript only' + (m.terms.length ? ' · matched: ' + m.terms.join(', ') : '') + ' · not visually verified',
      link: youtubeLink(o.videoId, startSec),
      recLink: rw.recLink,
      mergedFrom: m.mergedFrom,
    };
  }

  function analyze(cues, opts) {
    if (!Array.isArray(cues) || cues.length === 0) {
      throw new TranscriptError('There are no transcript lines to analyse.', 'no-cues');
    }
    const o = normalizeOptions(opts);
    const index = getIndex(o.language);
    const hits = scoreAll(cues, index);
    const chunks = makeChunks(cues, o.chunkMs);
    const perChunkLimit = Math.max(o.count * 3, 30);
    let all = [];
    let candidates = 0;
    for (const ch of chunks) {
      const r = selectFromChunk(cues, hits, ch.lo, ch.hi, perChunkLimit);
      candidates += r.candidates;
      all = all.concat(r.moments);
    }
    const merged = mergeMoments(all, DEDUPE_GAP_MS);
    const top = merged.slice(0, o.count);
    const lastEndMs = cues.reduce((mx, c) => (c.endMs > mx ? c.endMs : mx), 0);
    const moments = top.map((m, i) => finalize(m, i + 1, o, lastEndMs));
    const firstMs = cues[0].startMs;
    const notes = [];
    if (moments.length < o.count) {
      notes.push(
        'Only ' + moments.length + ' moment(s) had strong enough signals in the transcript text. Nothing was added just to fill the list.'
      );
    }
    if (!o.videoId) notes.push('No valid YouTube link was given, so timestamps are shown without clickable links.');
    return {
      moments,
      notes,
      stats: {
        cueCount: cues.length,
        firstMs,
        lastMs: lastEndMs,
        durationSec: Math.max(0, Math.round((lastEndMs - firstMs) / 1000)),
        hitCues: hits.size,
        candidateWindows: candidates,
        chunks: chunks.length,
        language: o.language,
        padSec: o.padSec,
        requested: o.count,
        script: detectScript(cues),
      },
      options: o,
    };
  }


  /* ------------------------------------------------------------------ */
  /* Visual markers (user-supplied). This engine never looks at video.   */
  /* A marker is a line such as "1:23:45 crash car flipped".             */
  /* ------------------------------------------------------------------ */
  const VISUAL_TAGS = {
    crash: ['crash'], glitch: ['glitch'], police: ['police'], death: ['death'], funny: ['funny'],
    scene: [], explosion: ['crash'], chase: ['police'], reaction: ['viral', 'surprise'], kill: ['death'], bug: ['glitch'], epic: ['epic', 'crazy'],
  };

  function parseVisualMarkers(text) {
    const out = [];
    const bad = [];
    if (typeof text !== 'string') return { markers: out, rejected: bad };
    const lines = text.replace(/\r\n?/g, '\n').split('\n').slice(0, 5000);
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      const m = /^[\[(]?((?:\d{1,3}:)?\d{1,2}:\d{2}(?:[.,]\d{1,3})?)[\])]?\s*[-:|]?\s*([A-Za-z]+)?\s*(.*)$/.exec(line);
      const ms = m ? parseTimestamp(m[1]) : null;
      if (ms === null) {
        bad.push(line.slice(0, 40));
        continue;
      }
      const tag = (m[2] || 'scene').toLowerCase();
      out.push({ ms, tag: Object.prototype.hasOwnProperty.call(VISUAL_TAGS, tag) ? tag : 'scene', note: cleanCueText(m[3] || '').slice(0, 120) });
    }
    return { markers: out, rejected: bad };
  }

  // Attach user-supplied markers that fall inside a moment (plus 5 s). Returns new moment objects.
  function attachVisualMarkers(moments, markers) {
    return moments.map((m) => {
      const near = (markers || []).filter((k) => k.ms >= m.startMs - 5000 && k.ms <= m.endMs + 5000);
      if (!near.length) return m;
      const visual = near.slice(0, 5).map((k) => ({ at: formatTime(Math.floor(k.ms / 1000)), tag: k.tag, note: k.note, source: 'user-supplied marker' }));
      const agrees = near.some((k) => (VISUAL_TAGS[k.tag] || []).some((c) => m.categories.indexOf(c) !== -1));
      const evidence = Object.assign({}, m.evidence, { visual, visuallyVerified: true, visualSource: 'user-supplied markers (not detected by this app)' });
      const confidence = Math.min(96, m.confidence + (agrees ? 8 : 3));
      return Object.assign({}, m, {
        confidence,
        evidence,
        evidenceText: m.evidenceText.replace('not visually verified', 'visual marker given by you: ' + visual.map((v) => v.tag + ' @' + v.at).join(', ')),
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* Export                                                              */
  /* ------------------------------------------------------------------ */
  function csvCell(v) {
    if (typeof v === 'number') return String(v);
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // stop spreadsheet formula injection
    return '"' + s.replace(/"/g, '""') + '"';
  }

  function toCSV(result) {
    const head = [
      'rank',
      'category',
      'moment_start',
      'moment_end',
      'record_start',
      'record_end',
      'moment_start_sec',
      'moment_end_sec',
      'record_start_sec',
      'record_end_sec',
      'confidence_percent',
      'description',
      'why',
      'evidence',
      'youtube_link',
      'record_start_link',
    ];
    const rows = [head.join(',')];
    for (const m of result.moments) {
      rows.push(
        [
          m.rank,
          m.categoryLabel,
          m.startText,
          m.endText,
          m.recStartText,
          m.recEndText,
          m.startSec,
          m.endSec,
          m.recStartSec,
          m.recEndSec,
          m.confidence,
          m.description,
          m.why,
          m.evidenceText,
          m.link || '',
          m.recLink || '',
        ]
          .map(csvCell)
          .join(',')
      );
    }
    return rows.join('\r\n') + '\r\n';
  }

  function toTXT(result, meta) {
    const info = meta || {};
    const s = result.stats;
    const lines = [];
    lines.push('VICE MOMENT FINDER - suggested moments');
    if (info.source) lines.push('Source: ' + info.source);
    if (info.videoId) lines.push('Video: https://www.youtube.com/watch?v=' + info.videoId);
    lines.push(
      'Analysed: ' + s.cueCount + ' transcript lines covering ' + formatTime(s.durationSec) + ' (transcript text only; no video, audio or chat was analysed).'
    );
    lines.push('Recording padding: ' + s.padSec + ' seconds before and after each moment.');
    lines.push('');
    for (const m of result.moments) {
      lines.push('#' + m.rank + ' ' + m.categoryLabel + ' (' + m.confidence + '% confidence)');
      lines.push('  Moment: ' + m.startText + ' - ' + m.endText);
      lines.push('  Record: ' + m.recStartText + ' - ' + m.recEndText + ' (' + m.recDurationSec + 's)');
      lines.push('  What was said: ' + m.description);
      lines.push('  Why: ' + m.why);
      lines.push('  Evidence: ' + m.evidenceText);
      if (m.link) lines.push('  Link: ' + m.link);
      lines.push('');
    }
    return lines.join('\n');
  }

  return {
    LIMITS,
    CATEGORIES,
    WINDOW_MS,
    MAX_MOMENT_MS,
    DEDUPE_GAP_MS,
    TranscriptError,
    parseTimestamp,
    formatTime,
    isValidVideoId,
    extractVideoId,
    youtubeLink,
    validateFileMeta,
    validateText,
    parseTranscript,
    tokenize,
    scoreCue,
    getIndex,
    mergeMoments,
    analyze,
    detectScript,
    recordWindow,
    parseVisualMarkers,
    attachVisualMarkers,
    cleanCueText,
    csvCell,
    toCSV,
    toTXT,
  };
});
