/*
 * VICE MOMENT FINDER - transcript file loading helpers.
 * Pure logic (no page access) so it can be tested in Node and reused in the browser.
 * Decodes bytes as UTF-8 (also UTF-16 with a byte-order mark), so Hindi / Devanagari text survives.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ViceLoader = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const MAX_BYTES = 10 * 1024 * 1024;
  const ALLOWED = ['.srt', '.vtt', '.txt'];
  // Text above this many characters is analysed from memory instead of being placed in the text box,
  // because a multi-megabyte text box is slow on low-RAM phones.
  const MAX_SHOW_CHARS = 500000;

  class LoadError extends Error {
    constructor(message, code) {
      super(message);
      this.name = 'LoadError';
      this.code = code;
      this.userMessage = message;
    }
  }

  function extOf(name) {
    const n = String(name || '');
    const d = n.lastIndexOf('.');
    return d >= 0 ? n.slice(d).toLowerCase() : '';
  }

  function checkMeta(name, size) {
    if (ALLOWED.indexOf(extOf(name)) === -1) {
      throw new LoadError('"' + String(name || 'That file').slice(0, 60) + '" is not a .srt, .vtt or .txt file. Choose a transcript file, or paste the text instead.', 'bad-type');
    }
    if (size === 0) throw new LoadError('That file is empty (0 bytes).', 'empty');
    if (!Number.isFinite(size) || size < 0) throw new LoadError('Could not read the size of that file.', 'bad-size');
    if (size > MAX_BYTES) {
      throw new LoadError('That file is bigger than 10 MB. A transcript of an 8-hour stream is usually under 2 MB, so this is probably the wrong file.', 'too-big');
    }
  }

  // bytes: ArrayBuffer or Uint8Array
  function decodeBytes(bytes) {
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    if (u8.length === 0) throw new LoadError('That file is empty (0 bytes).', 'empty');
    let enc = 'utf-8';
    let start = 0;
    if (u8.length >= 2 && u8[0] === 0xff && u8[1] === 0xfe) { enc = 'utf-16le'; start = 2; }
    else if (u8.length >= 2 && u8[0] === 0xfe && u8[1] === 0xff) { enc = 'utf-16be'; start = 2; }
    else if (u8.length >= 3 && u8[0] === 0xef && u8[1] === 0xbb && u8[2] === 0xbf) { start = 3; }
    // Binary files (images, zips, documents) contain zero bytes; real UTF-8 text does not.
    if (enc === 'utf-8') {
      const probe = Math.min(u8.length, 8192);
      for (let i = 0; i < probe; i++) {
        if (u8[i] === 0) throw new LoadError('That does not look like a text file (it contains binary data). Choose a .srt, .vtt or .txt transcript.', 'binary');
      }
    }
    let text;
    try {
      text = new TextDecoder(enc, { fatal: true }).decode(u8.subarray(start));
    } catch (e) {
      throw new LoadError('This file is not valid UTF-8 text. Open it in a text editor, save it as UTF-8, and try again.', 'encoding');
    }
    text = text.replace(/^﻿/, '');
    if (!text.trim()) throw new LoadError('That file has no text in it.', 'empty');
    return text;
  }

  // Quick summary shown after loading: format guess and line count.
  function describe(text) {
    const lines = text.split(/\r\n|\r|\n/).length;
    let format = 'plain text';
    if (/^\s*WEBVTT/.test(text)) format = 'VTT';
    else if (/-->/.test(text)) format = 'SRT';
    return { lines, format, chars: text.length };
  }

  return { MAX_BYTES, MAX_SHOW_CHARS, ALLOWED, LoadError, extOf, checkMeta, decodeBytes, describe };
});
