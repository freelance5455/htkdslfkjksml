/* Service worker: caches the app files so the app opens and analyses offline.
   Change CACHE_VERSION whenever you change any app file so phones pick up the update.
   Files are served from the versioned cache only (never mixed between versions). A new version waits until
   the person taps "Update now" in the app, then takes over and the page reloads. */
'use strict';
var CACHE_VERSION = 'vmf-v2.0.0';
var ASSETS = [
  './',
  'index.html',
  'styles.css',
  'engine.js',
  'creator.js',
  'loader.js',
  'store.js',
  'worker.js',
  'app.js',
  'manifest.webmanifest',
  'favicon.svg',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png'
];

self.addEventListener('install', function (event) {
  // No skipWaiting here: the page decides when to switch (see the "Update now" message below).
  // cache: 'reload' skips the browser's own HTTP cache, so a new version never installs a stale copy of a file.
  event.waitUntil(
    caches.open(CACHE_VERSION).then(function (c) {
      return Promise.all(ASSETS.map(function (a) {
        return fetch(new Request(a, { cache: 'reload' })).then(function (res) {
          if (!res.ok) throw new Error('Could not cache ' + a);
          return c.put(a, res);
        });
      }));
    })
  );
});

self.addEventListener('message', function (event) {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k !== CACHE_VERSION; }).map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // never touch YouTube or other sites
  event.respondWith(
    caches.open(CACHE_VERSION).then(function (cache) {
      return cache.match(req, { ignoreSearch: true }).then(function (cached) {
        if (cached) return cached;
        return fetch(req).then(function (res) {
          if (res && res.ok) cache.put(req, res.clone());
          return res;
        }).catch(function () {
          return req.mode === 'navigate' ? cache.match('index.html') : Response.error();
        });
      });
    })
  );
});
