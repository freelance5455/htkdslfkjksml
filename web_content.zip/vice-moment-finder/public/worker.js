/* Runs the analysis off the main thread so the page stays responsive on long transcripts. */
'use strict';
importScripts('engine.js');
self.onmessage = function (ev) {
  var d = ev.data || {};
  try {
    var parsed = self.ViceEngine.parseTranscript(d.text);
    var result = self.ViceEngine.analyze(parsed.cues, d.options);
    result.parse = { format: parsed.format, warnings: parsed.warnings };
    self.postMessage({ ok: true, result: result });
  } catch (e) {
    self.postMessage({ ok: false, message: (e && (e.userMessage || e.message)) || 'Analysis failed.' });
  }
};
