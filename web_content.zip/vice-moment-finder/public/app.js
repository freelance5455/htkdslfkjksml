/* VICE MOMENT FINDER - screen logic. All transcript text is shown as plain text, never as page markup. */
(function () {
  'use strict';
  var E = window.ViceEngine;
  var $ = function (id) { return document.getElementById(id); };

  var state = { result: null, videoId: null, source: '', filter: 'all', sort: 'score', file: null, installEvent: null };

  function el(tag, opts, children) {
    var n = document.createElement(tag);
    opts = opts || {};
    if (opts.cls) n.className = opts.cls;
    if (opts.text !== undefined) n.textContent = opts.text;
    if (opts.attrs) for (var k in opts.attrs) n.setAttribute(k, opts.attrs[k]);
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function setMsg(node, text, kind) {
    node.textContent = text || '';
    node.className = 'msg' + (kind ? ' ' + kind : '');
  }

  var toastTimer = null;
  function toast(text) {
    var t = $('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 1800);
  }

  function copyText(text) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      return ok;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return fallback(); });
    }
    return Promise.resolve(fallback());
  }

  function copyWithToast(text, label) {
    copyText(text).then(function (ok) { toast(ok ? label + ' copied' : 'Could not copy. Press and hold the text instead.'); });
  }

  /* ---------- link ---------- */
  function readVideo() {
    var v = $('urlInput').value.trim();
    var msg = $('urlMsg');
    if (!v) { state.videoId = null; setMsg(msg, ''); return null; }
    var id = E.extractVideoId(v);
    state.videoId = id;
    if (id) setMsg(msg, 'Video ID found: ' + id, 'ok');
    else setMsg(msg, 'That does not look like a YouTube link. Timestamps will be shown without clickable links.', 'warn');
    return id;
  }

  /* ---------- file ---------- */
  $('fileInput').addEventListener('change', function (ev) {
    var f = ev.target.files && ev.target.files[0];
    state.file = null;
    if (!f) { $('fileName').textContent = 'No file chosen.'; return; }
    try {
      E.validateFileMeta({ name: f.name, size: f.size });
      state.file = f;
      $('fileName').textContent = 'Chosen: ' + f.name + ' (' + Math.max(1, Math.round(f.size / 1024)) + ' KB)';
      setMsg($('status'), '');
    } catch (e) {
      $('fileName').textContent = 'No file chosen.';
      ev.target.value = '';
      setMsg($('status'), e.userMessage || e.message, 'err');
    }
  });

  $('clearBtn').addEventListener('click', function () {
    state.file = null;
    $('fileInput').value = '';
    $('pasteArea').value = '';
    $('fileName').textContent = 'No file chosen.';
    setMsg($('status'), '');
  });

  $('urlInput').addEventListener('change', readVideo);

  /* ---------- analyse ---------- */
  function readTranscriptText() {
    if (state.file) {
      state.source = state.file.name;
      if (state.file.text) return state.file.text();
      return new Promise(function (resolve, reject) {
        var r = new FileReader();
        r.onload = function () { resolve(String(r.result)); };
        r.onerror = function () { reject(new Error('Could not read that file.')); };
        r.readAsText(state.file);
      });
    }
    var t = $('pasteArea').value;
    state.source = 'pasted transcript';
    return Promise.resolve(t);
  }

  function run() {
    var btn = $('analyseBtn');
    var status = $('status');
    var videoId = readVideo();
    var hasInput = !!state.file || $('pasteArea').value.trim() !== '';
    if (!hasInput) {
      setMsg(status, videoId || $('urlInput').value.trim()
        ? 'A YouTube link alone cannot be analysed here. Choose a transcript file or paste one in step 2.'
        : 'Choose a transcript file or paste a timestamped transcript first.', 'err');
      return;
    }
    btn.disabled = true;
    setMsg(status, 'Analysing…');
    new Promise(function (r) { setTimeout(r, 30); })
      .then(readTranscriptText)
      .then(function (text) {
        if (text.indexOf('�') !== -1 && (text.match(/�/g) || []).length > 20) {
          throw new E.TranscriptError('This file does not look like UTF-8 text. Re-save it as UTF-8 and try again.', 'encoding');
        }
        var parsed = E.parseTranscript(text);
        var result = E.analyze(parsed.cues, {
          language: $('langSelect').value,
          count: parseInt($('countSelect').value, 10),
          padSec: parseInt($('padSelect').value, 10),
          videoId: videoId
        });
        result.parse = parsed;
        state.result = result;
        state.filter = 'all';
        render();
        setMsg(status, result.moments.length + ' moment(s) found.', 'ok');
        $('analysed').scrollIntoView({ behavior: 'smooth', block: 'start' });
      })
      .catch(function (e) {
        setMsg(status, (e && (e.userMessage || e.message)) || 'Something went wrong.', 'err');
      })
      .then(function () { btn.disabled = false; });
  }
  $('analyseBtn').addEventListener('click', run);

  /* ---------- render ---------- */
  var LANG_NAMES = { auto: 'Auto', hinglish: 'Hinglish', hindi: 'Hindi', english: 'English' };

  function li(label, value) {
    return el('li', {}, [el('b', { text: label + ': ' }), document.createTextNode(value)]);
  }

  function renderAnalysed() {
    var r = state.result;
    var s = r.stats;
    var ul = $('analysedList');
    clear(ul);
    ul.appendChild(li('Source', state.source + ' (' + r.parse.format.toUpperCase() + ' format)'));
    ul.appendChild(li('Transcript lines', s.cueCount + ' lines, ' + E.formatTime(Math.floor(s.firstMs / 1000)) + ' to ' + E.formatTime(Math.ceil(s.lastMs / 1000))));
    ul.appendChild(li('Method', 'Transcript wording only (keyword and context scoring on this phone). No video, audio or chat replay was analysed, so nothing here is visually verified.'));
    ul.appendChild(li('Language list', LANG_NAMES[s.language] + (s.script.devanagariRatio > 0.3 ? ' (transcript is mostly Devanagari script)' : '')));
    ul.appendChild(li('Lines with a signal', s.hitCues + ' of ' + s.cueCount + ', processed in ' + s.chunks + ' chunk(s)'));
    r.parse.warnings.concat(r.notes).forEach(function (w) { ul.appendChild(li('Note', w)); });
    $('analysed').hidden = false;
  }

  function visibleMoments() {
    var list = state.result.moments.filter(function (m) {
      return state.filter === 'all' || m.categories.indexOf(state.filter) !== -1;
    });
    if (state.sort === 'time') list = list.slice().sort(function (a, b) { return a.startMs - b.startMs; });
    return list;
  }

  function renderFilters() {
    var box = $('filters');
    clear(box);
    var counts = {};
    state.result.moments.forEach(function (m) { m.categories.forEach(function (c) { counts[c] = (counts[c] || 0) + 1; }); });
    function chip(id, label, count) {
      var b = el('button', { cls: 'chip', text: label + ' (' + count + ')', attrs: { type: 'button', 'aria-pressed': String(state.filter === id) } });
      b.addEventListener('click', function () { state.filter = id; renderFilters(); renderList(); });
      box.appendChild(b);
    }
    chip('all', 'All', state.result.moments.length);
    E.CATEGORIES.forEach(function (c) { if (counts[c.id]) chip(c.id, c.label, counts[c.id]); });
  }

  function actionBtn(label, onClick) {
    var b = el('button', { cls: 'btn ghost', text: label, attrs: { type: 'button' } });
    b.addEventListener('click', onClick);
    return b;
  }

  function card(m) {
    var conf = el('span', { cls: 'm-conf' }, [document.createTextNode(m.confidence + '% confidence'), el('span', { cls: 'bar', attrs: { 'aria-hidden': 'true' } }, [el('i')])]);
    conf.querySelector('i').style.width = m.confidence + '%';
    var head = el('div', { cls: 'm-head' }, [
      el('span', { cls: 'm-rank', text: '#' + m.rank }),
      el('span', { cls: 'm-cat', text: m.categoryLabel }),
      conf
    ]);
    var times = el('div', { cls: 'm-times' }, [
      el('div', {}, [el('b', { text: 'MOMENT' }), document.createTextNode(m.startText + ' → ' + m.endText)]),
      el('div', {}, [el('b', { text: 'RECORD' }), document.createTextNode(m.recStartText + ' → ' + m.recEndText + ' (' + m.recDurationSec + 's)')])
    ]);
    var desc = el('p', { cls: 'm-desc', text: '“' + m.description + '”', attrs: { dir: 'auto' } });
    var actions = el('div', { cls: 'm-actions' });
    var open;
    if (m.link) {
      open = el('a', { cls: 'btn link open', text: 'Open in YouTube at ' + m.startText, attrs: { href: m.link, target: '_blank', rel: 'noopener noreferrer' } });
    } else {
      open = el('a', { cls: 'btn link open', text: 'Add a YouTube link to open', attrs: { 'aria-disabled': 'true', role: 'link' } });
    }
    actions.appendChild(open);
    actions.appendChild(actionBtn('Copy time', function () { copyWithToast(m.startText, 'Time'); }));
    actions.appendChild(actionBtn('Copy record window', function () { copyWithToast(m.recStartText + ' - ' + m.recEndText, 'Window'); }));
    actions.appendChild(actionBtn('Copy description', function () { copyWithToast(m.categoryLabel + ' at ' + m.startText + ': ' + m.description, 'Description'); }));
    if (m.recLink) {
      var rec = el('a', { cls: 'btn ghost', text: 'Open at record start', attrs: { href: m.recLink, target: '_blank', rel: 'noopener noreferrer' } });
      actions.appendChild(rec);
    }
    return el('li', { cls: 'moment' }, [
      head, times, desc,
      el('p', { cls: 'm-why', text: m.why }),
      el('p', { cls: 'm-evid', text: 'Evidence: ' + m.evidenceText }),
      actions
    ]);
  }

  function renderList() {
    var box = $('list');
    clear(box);
    var list = visibleMoments();
    if (!list.length) {
      box.appendChild(el('li', { cls: 'empty', text: state.result.moments.length ? 'No moments in this category.' : 'No moments had strong enough signals in this transcript. Try a different language setting, or check that the transcript has real speech text.' }));
      return;
    }
    list.forEach(function (m) { box.appendChild(card(m)); });
  }

  function render() {
    renderAnalysed();
    renderFilters();
    renderList();
    $('results').hidden = false;
  }

  $('sortSelect').addEventListener('change', function (ev) { state.sort = ev.target.value; if (state.result) renderList(); });

  /* ---------- export ---------- */
  function download(name, mime, text) {
    var blob = new Blob([text], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
  }
  function baseName() { return 'vice-moments-' + (state.videoId || 'transcript'); }
  $('exportTxt').addEventListener('click', function () {
    if (!state.result) return;
    download(baseName() + '.txt', 'text/plain;charset=utf-8', E.toTXT(state.result, { source: state.source, videoId: state.videoId }));
  });
  $('exportCsv').addEventListener('click', function () {
    if (!state.result) return;
    download(baseName() + '.csv', 'text/csv;charset=utf-8', '﻿' + E.toCSV(state.result));
  });

  /* ---------- online badge, install, service worker ---------- */
  function net() {
    var b = $('netBadge');
    var on = navigator.onLine !== false;
    b.textContent = on ? 'Online' : 'Offline: analysis still works';
    b.className = 'badge' + (on ? '' : ' off');
  }
  window.addEventListener('online', net);
  window.addEventListener('offline', net);
  net();

  window.addEventListener('beforeinstallprompt', function (ev) {
    ev.preventDefault();
    state.installEvent = ev;
    $('installBtn').hidden = false;
  });
  $('installBtn').addEventListener('click', function () {
    var ev = state.installEvent;
    if (!ev) return;
    ev.prompt();
    ev.userChoice.then(function () { state.installEvent = null; $('installBtn').hidden = true; });
  });
  window.addEventListener('appinstalled', function () { $('installBtn').hidden = true; });

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function () { /* app still works without it */ });
    });
  }
})();
