/* VICE MOMENT FINDER ULTIMATE - screen logic. All transcript text is shown as plain text, never as page markup. */
(function () {
  'use strict';
  var E = window.ViceEngine;
  var C = window.ViceCreator;
  var L = window.ViceLoader;
  var S = window.ViceStore;
  var $ = function (id) { return document.getElementById(id); };

  var CHECKS = [
    ['opened', 'Opened in YouTube'],
    ['recorded', 'Screen recorded'],
    ['edited', 'Edited in VN Editor'],
    ['published', 'Published on VICE CLIPS']
  ];

  var state = {
    result: null, videoId: null, source: '', filter: 'all', sort: 'score',
    installEvent: null, hiddenText: null, selected: {}, edits: {}, projectId: null,
    view: 'input', busy: false, lastFile: null, lastFileAt: 0
  };
  var store = null;

  /* ---------- small helpers ---------- */
  function el(tag, opts, children) {
    var n = document.createElement(tag);
    opts = opts || {};
    if (opts.cls) n.className = opts.cls;
    if (opts.text !== undefined) n.textContent = opts.text;
    if (opts.attrs) for (var k in opts.attrs) n.setAttribute(k, opts.attrs[k]);
    (children || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function setMsg(node, text, kind) {
    node.textContent = text || '';
    node.className = 'msg' + (kind ? ' ' + kind : '');
  }

  var toastTimer = null;
  function toast(text) {
    var t = $('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  function copyText(text) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.setAttribute('readonly', '');
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      return ok;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return fallback(); });
    }
    return Promise.resolve(fallback());
  }
  function copyWithToast(text, label) {
    copyText(text).then(function (ok) { toast(ok ? label + ' copied' : 'Could not copy. Press and hold the text instead.'); });
  }

  /* ---------- tabs ---------- */
  var VIEWS = ['input', 'results', 'plan', 'projects', 'guide'];
  function showView(name) {
    state.view = name;
    VIEWS.forEach(function (v) { $('view-' + v).hidden = v !== name; });
    var tabs = document.querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) tabs[i].setAttribute('aria-pressed', String(tabs[i].getAttribute('data-view') === name));
    if (name === 'plan') renderPlan();
    if (name === 'projects') refreshProjects();
    window.scrollTo(0, 0);
  }
  (function () {
    var tabs = document.querySelectorAll('.tab');
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener('click', function (ev) { showView(ev.currentTarget.getAttribute('data-view')); });
    }
  })();

  /* ---------- link ---------- */
  function readVideo() {
    var v = $('urlInput').value.trim();
    var msg = $('urlMsg');
    if (!v) { state.videoId = null; setMsg(msg, ''); return null; }
    var id = E.extractVideoId(v);
    state.videoId = id;
    if (id) setMsg(msg, 'Video ID found: ' + id, 'ok');
    else setMsg(msg, 'That does not look like a YouTube link. Timestamps will be shown without clickable links.', 'warn');
    return id;
  }
  $('urlInput').addEventListener('change', readVideo);

  /* ---------- transcript text ---------- */
  function setTranscript(text, name) {
    state.source = name;
    if (text.length <= L.MAX_SHOW_CHARS) {
      $('pasteArea').value = text;
      state.hiddenText = null;
    } else {
      $('pasteArea').value = '';
      state.hiddenText = text;
    }
  }
  function getTranscript() {
    var shown = $('pasteArea').value;
    if (state.hiddenText && shown.trim() === '') return state.hiddenText;
    return shown;
  }
  $('pasteArea').addEventListener('input', function () {
    state.hiddenText = null;
    state.source = 'pasted transcript';
  });

  /* ---------- file picking (the Android bug fix) ---------- */
  function readFileBytes(f) {
    if (f.arrayBuffer) return f.arrayBuffer();
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(new L.LoadError('Could not read that file. Try copying it to Downloads and choosing it again.', 'read')); };
      r.readAsArrayBuffer(f);
    });
  }

  function handleFile(f) {
    var status = $('status');
    var label = $('fileName');
    return new Promise(function (resolve) { resolve(L.checkMeta(f.name, f.size)); })
      .then(function () {
        label.textContent = 'Reading ' + f.name + '…';
        return readFileBytes(f);
      })
      .then(function (bytes) {
        var text = L.decodeBytes(bytes);
        var d = L.describe(text);
        setTranscript(text, f.name);
        label.textContent = 'Loaded: ' + f.name + ' (' + Math.max(1, Math.round(f.size / 1024)) + ' KB, ' + d.lines.toLocaleString() + ' lines, ' + d.format + ')' +
          (state.hiddenText ? '. Too large to show in the box; it will be analysed from memory.' : '.');
        setMsg(status, '');
        return true;
      })
      .catch(function (e) {
        label.textContent = 'No file loaded.';
        setMsg(status, (e && (e.userMessage || e.message)) || 'Could not load that file.', 'err');
        return false;
      });
  }

  function onFilePicked(ev) {
    var input = ev.target;
    var f = input.files && input.files[0];
    if (!f) return;
    // Some Android versions fire both "input" and "change" for the same pick.
    var now = Date.now();
    if (state.lastFile === f && now - state.lastFileAt < 800) return;
    state.lastFile = f;
    state.lastFileAt = now;
    handleFile(f).then(function (ok) {
      // Clear the chooser so picking the SAME file again fires a new change event.
      try { input.value = ''; } catch (e) { /* ignore */ }
      state.lastFile = null;
      if (ok && $('autoRun').checked) run();
    });
  }
  $('fileInput').addEventListener('change', onFilePicked);
  $('fileInput').addEventListener('input', onFilePicked);

  $('pasteClipBtn').addEventListener('click', function () {
    var status = $('status');
    if (!navigator.clipboard || !navigator.clipboard.readText) {
      setMsg(status, 'This browser cannot read the clipboard from a button. Press and hold inside the box below and choose Paste.', 'warn');
      return;
    }
    navigator.clipboard.readText().then(function (t) {
      if (!t || !t.trim()) { setMsg(status, 'The clipboard is empty. Copy the transcript first.', 'warn'); return; }
      setTranscript(t, 'pasted transcript');
      $('fileName').textContent = 'Pasted ' + t.length.toLocaleString() + ' characters from the clipboard.';
      setMsg(status, '');
    }).catch(function () {
      setMsg(status, 'Clipboard access was blocked. Press and hold inside the box below and choose Paste.', 'warn');
    });
  });

  $('clearBtn').addEventListener('click', function () {
    state.hiddenText = null;
    $('fileInput').value = '';
    $('pasteArea').value = '';
    $('fileName').textContent = 'No file chosen.';
    setMsg($('status'), '');
  });

  (function webviewNote() {
    var ua = navigator.userAgent || '';
    var wv = /; wv\)/.test(ua) || (/Android/.test(ua) && /Version\/\d+\.\d+/.test(ua) && /Chrome\//.test(ua));
    if (!wv) return;
    var n = $('webviewNote');
    n.hidden = false;
    n.textContent = 'This looks like an app wrapper (WebView), not Chrome. If the file button does nothing, the wrapper does not support choosing files and JavaScript cannot fix that. Use "Paste from clipboard", or install the app from Chrome.';
  })();

  /* ---------- analysis ---------- */
  function analyseText(text, options) {
    return new Promise(function (resolve, reject) {
      function sync() {
        try {
          var parsed = E.parseTranscript(text);
          var r = E.analyze(parsed.cues, options);
          r.parse = { format: parsed.format, warnings: parsed.warnings };
          resolve(r);
        } catch (e) { reject(e); }
      }
      if (typeof Worker === 'undefined') { setTimeout(sync, 30); return; }
      var w;
      try { w = new Worker('worker.js'); } catch (e) { setTimeout(sync, 30); return; }
      var done = false;
      w.onmessage = function (ev) {
        done = true; w.terminate();
        if (ev.data && ev.data.ok) resolve(ev.data.result);
        else reject(new E.TranscriptError((ev.data && ev.data.message) || 'Analysis failed.', 'analysis'));
      };
      w.onerror = function () { if (done) return; done = true; w.terminate(); setTimeout(sync, 0); };
      w.postMessage({ text: text, options: options });
    });
  }

  function run() {
    if (state.busy) return;
    var btn = $('analyseBtn');
    var status = $('status');
    var videoId = readVideo();
    var text = getTranscript();
    if (!text || !text.trim()) {
      setMsg(status, videoId || $('urlInput').value.trim()
        ? 'A YouTube link alone cannot be analysed here. Choose a transcript file or paste one in step 2.'
        : 'Choose a transcript file or paste a timestamped transcript first.', 'err');
      return;
    }
    if (!state.source) state.source = 'pasted transcript';
    state.busy = true;
    btn.disabled = true;
    setMsg(status, 'Analysing…');
    var options = {
      language: $('langSelect').value,
      count: parseInt($('countSelect').value, 10),
      padSec: parseInt($('padSelect').value, 10),
      videoId: videoId
    };
    analyseText(text, options)
      .then(function (result) {
        var markers = E.parseVisualMarkers($('visualArea').value);
        if (markers.markers.length) result.moments = E.attachVisualMarkers(result.moments, markers.markers);
        if (markers.rejected.length) result.notes.push(markers.rejected.length + ' visual marker line(s) were ignored (no valid time at the start).');
        state.result = result;
        state.filter = 'all';
        state.selected = {};
        state.edits = {};
        state.projectId = null;
        state.transcriptForSave = text;
        render();
        setMsg(status, result.moments.length + ' moment(s) found.', 'ok');
        showView('results');
      })
      .catch(function (e) {
        setMsg(status, (e && (e.userMessage || e.message)) || 'Something went wrong.', 'err');
      })
      .then(function () { state.busy = false; btn.disabled = false; });
  }
  $('analyseBtn').addEventListener('click', run);

  /* ---------- derived moment view (custom padding) ---------- */
  function editOf(rank) {
    var k = String(rank);
    if (!state.edits[k]) state.edits[k] = { title: '', caption: '', notes: '', pad: null, check: {} };
    return state.edits[k];
  }
  function viewOf(m) {
    var e = state.edits[String(m.rank)];
    var pad = e && e.pad !== null && e.pad !== undefined ? e.pad : state.result.options.padSec;
    var rw = E.recordWindow(m, pad, state.result.stats.lastMs, state.videoId);
    return Object.assign({}, m, rw, { link: m.link });
  }
  function suggestionFor(m) {
    var e = state.edits[String(m.rank)] || {};
    return C.suggest(viewOf(m), { title: e.title, caption: e.caption });
  }
  function selectedMoments() {
    return state.result.moments
      .filter(function (m) { return state.selected[String(m.rank)]; })
      .sort(function (a, b) { return a.startMs - b.startMs; });
  }

  /* ---------- results render ---------- */
  var LANG_NAMES = { auto: 'Auto', hinglish: 'Hinglish', hindi: 'Hindi', english: 'English' };
  function li(label, value) {
    return el('li', {}, [el('b', { text: label + ': ' }), document.createTextNode(value)]);
  }

  function renderAnalysed() {
    var r = state.result;
    var s = r.stats;
    var ul = $('analysedList');
    clear(ul);
    ul.appendChild(li('Source', state.source + ' (' + r.parse.format.toUpperCase() + ' format)'));
    ul.appendChild(li('Transcript lines', s.cueCount + ' lines, ' + E.formatTime(Math.floor(s.firstMs / 1000)) + ' to ' + E.formatTime(Math.ceil(s.lastMs / 1000))));
    ul.appendChild(li('Method', 'Transcript wording only (keyword and context scoring on this phone). No video, audio or chat replay was analysed. Visual evidence appears only where you typed a marker.'));
    ul.appendChild(li('Language list', LANG_NAMES[s.language] + (s.script.devanagariRatio > 0.3 ? ' (transcript is mostly Devanagari script)' : '')));
    ul.appendChild(li('Lines with a signal', s.hitCues + ' of ' + s.cueCount + ', processed in ' + s.chunks + ' chunk(s)'));
    r.parse.warnings.concat(r.notes).forEach(function (w) { ul.appendChild(li('Note', w)); });
    $('analysed').hidden = false;
  }

  function renderDashboard() {
    var ms = state.result.moments;
    var strong = ms.filter(function (m) { return m.confidence >= 70; }).length;
    var avg = ms.length ? Math.round(ms.reduce(function (a, m) { return a + m.confidence; }, 0) / ms.length) : 0;
    var shorts = ms.filter(function (m) { return viewOf(m).shortsFit; }).length;
    var sel = Object.keys(state.selected).filter(function (k) { return state.selected[k]; }).length;
    $('dTotal').textContent = String(ms.length);
    $('dSelected').textContent = String(sel);
    $('dStrong').textContent = String(strong);
    $('dAvg').textContent = avg + '%';
    $('dShorts').textContent = String(shorts);
    $('planCount').textContent = String(sel);
    $('dStatus').textContent = 'Analysis complete: ' + state.result.stats.cueCount.toLocaleString() + ' lines from ' + state.source + '. Confidence is a rough guide from wording only.';
    var top = $('dTop');
    clear(top);
    ms.slice().sort(function (a, b) { return b.confidence - a.confidence; }).slice(0, 3).forEach(function (m) {
      top.appendChild(el('li', {}, [el('span', { text: m.categoryLabel }), el('span', { cls: 't-time', text: m.startText + ' · ' + m.confidence + '%' })]));
    });
    $('dashboard').hidden = false;
  }

  function visibleMoments() {
    var list = state.result.moments.filter(function (m) {
      return state.filter === 'all' || m.categories.indexOf(state.filter) !== -1;
    });
    if (state.sort === 'time') list = list.slice().sort(function (a, b) { return a.startMs - b.startMs; });
    return list;
  }

  function renderFilters() {
    var box = $('filters');
    clear(box);
    var counts = {};
    state.result.moments.forEach(function (m) { m.categories.forEach(function (c) { counts[c] = (counts[c] || 0) + 1; }); });
    function chip(id, label, count) {
      var b = el('button', { cls: 'chip', text: label + ' (' + count + ')', attrs: { type: 'button', 'aria-pressed': String(state.filter === id) } });
      b.addEventListener('click', function () { state.filter = id; renderFilters(); renderList(); });
      box.appendChild(b);
    }
    chip('all', 'All', state.result.moments.length);
    E.CATEGORIES.forEach(function (c) { if (counts[c.id]) chip(c.id, c.label, counts[c.id]); });
  }

  function actionBtn(label, onClick, extra) {
    var b = el('button', { cls: 'btn ghost' + (extra ? ' ' + extra : ''), text: label, attrs: { type: 'button' } });
    b.addEventListener('click', onClick);
    return b;
  }

  function fieldBlock(label, text) {
    var box = el('div', { cls: 'field' }, [
      el('span', { cls: 'f-label', text: label.toUpperCase() }),
      el('div', { cls: 'f-text', text: text, attrs: { dir: 'auto' } })
    ]);
    box.appendChild(actionBtn('Copy ' + label.toLowerCase(), function () { copyWithToast(text, label); }));
    return box;
  }

  function fillCreator(box, m) {
    clear(box);
    var c = suggestionFor(m);
    box.appendChild(el('p', { cls: 'hint', text: c.note }));
    var all = actionBtn('Copy everything below', function () { copyWithToast(C.combined(c), 'All creator text'); }, 'full');
    box.appendChild(all);
    C.fields(c).forEach(function (f) { box.appendChild(fieldBlock(f[1], f[2])); });
  }

  function padControls(m, afterChange) {
    var out = el('output', { text: '' });
    function refresh() {
      var v = viewOf(m);
      out.textContent = v.padSec + 's pad';
    }
    function bump(d) {
      var e = editOf(m.rank);
      var cur = e.pad !== null && e.pad !== undefined ? e.pad : state.result.options.padSec;
      e.pad = Math.max(0, Math.min(60, cur + d));
      refresh();
      afterChange();
    }
    refresh();
    var row = el('div', { cls: 'pad-row' }, [el('span', { cls: 'hint', text: 'Padding:' })]);
    [['−5', -5], ['−1', -1]].forEach(function (p) { row.appendChild(actionBtn(p[0], function () { bump(p[1]); }, 'small')); });
    row.appendChild(out);
    [['+1', 1], ['+5', 5]].forEach(function (p) { row.appendChild(actionBtn(p[0], function () { bump(p[1]); }, 'small')); });
    return row;
  }

  function badges(m, v) {
    var b = el('div', { cls: 'm-badges' });
    b.appendChild(el('span', { cls: 'pill' + (m.intensity === 'high' ? ' hot' : ''), text: 'Intensity: ' + m.intensity }));
    if (v.shortsFit) b.appendChild(el('span', { cls: 'pill good', text: 'Shorts length' }));
    if (m.evidence && m.evidence.visual && m.evidence.visual.length) b.appendChild(el('span', { cls: 'pill vis', text: 'Visual marker (yours)' }));
    m.categories.slice(1).forEach(function (c) { b.appendChild(el('span', { cls: 'pill', text: c })); });
    return b;
  }

  function card(m) {
    var v = viewOf(m);
    var conf = el('span', { cls: 'm-conf' }, [document.createTextNode(m.confidence + '% confidence'), el('span', { cls: 'bar', attrs: { 'aria-hidden': 'true' } }, [el('i')])]);
    conf.querySelector('i').style.width = m.confidence + '%';
    var head = el('div', { cls: 'm-head' }, [
      el('span', { cls: 'm-rank', text: '#' + m.rank }),
      el('span', { cls: 'm-cat', text: m.categoryLabel }),
      conf
    ]);
    var timesBox = el('div', { cls: 'm-times' });
    function drawTimes() {
      var vv = viewOf(m);
      clear(timesBox);
      timesBox.appendChild(el('div', {}, [el('b', { text: 'MOMENT' }), document.createTextNode(m.startText + ' → ' + m.endText)]));
      timesBox.appendChild(el('div', {}, [el('b', { text: 'RECORD' }), document.createTextNode(vv.recStartText + ' → ' + vv.recEndText + ' (' + vv.recDurationSec + 's)')]));
    }
    drawTimes();
    var desc = el('p', { cls: 'm-desc', text: '“' + m.description + '”', attrs: { dir: 'auto' } });

    var sel = el('input', { attrs: { type: 'checkbox', 'aria-label': 'Add moment ' + m.rank + ' to Shorts plan' } });
    sel.checked = !!state.selected[String(m.rank)];
    sel.addEventListener('change', function () {
      state.selected[String(m.rank)] = sel.checked;
      renderDashboard();
    });
    var selRow = el('label', { cls: 'm-select' }, [sel, el('span', { text: 'Add to Shorts plan' })]);

    var actions = el('div', { cls: 'm-actions' });
    function openLink(href, text, full) {
      var a = el('a', { cls: 'btn link' + (full ? ' open' : ''), text: text, attrs: { href: href, target: '_blank', rel: 'noopener noreferrer' } });
      a.addEventListener('click', function () { editOf(m.rank).check.opened = true; });
      return a;
    }
    if (m.link) actions.appendChild(openLink(m.link, 'Open in YouTube at ' + m.startText, true));
    else actions.appendChild(el('a', { cls: 'btn link open', text: 'Add a YouTube link to open', attrs: { 'aria-disabled': 'true', role: 'link' } }));
    actions.appendChild(actionBtn('Copy time', function () { copyWithToast(m.startText, 'Time'); }));
    actions.appendChild(actionBtn('Copy record window', function () { var vv = viewOf(m); copyWithToast(vv.recStartText + ' - ' + vv.recEndText, 'Window'); }));
    actions.appendChild(actionBtn('Copy description', function () { copyWithToast(m.categoryLabel + ' at ' + m.startText + ': ' + m.description, 'Description'); }));
    if (v.recLink) actions.appendChild(el('a', { cls: 'btn ghost', text: 'Open at record start', attrs: { href: v.recLink, target: '_blank', rel: 'noopener noreferrer' } }));

    var details = el('details', { cls: 'creator' }, [el('summary', { text: 'Creator assistant: titles, hook, caption, edit tips' })]);
    var body = el('div');
    details.appendChild(body);
    details.addEventListener('toggle', function () { if (details.open) fillCreator(body, m); });

    var pad = padControls(m, function () {
      drawTimes();
      if (details.open) fillCreator(body, m);
      renderDashboard();
    });

    return el('li', { cls: 'moment' }, [
      head, badges(m, v), timesBox, desc,
      el('p', { cls: 'm-why', text: m.why }),
      el('p', { cls: 'm-evid', text: 'Evidence: ' + m.evidenceText }),
      pad, selRow, actions, details
    ]);
  }

  function renderList() {
    var box = $('list');
    clear(box);
    var list = visibleMoments();
    if (!list.length) {
      box.appendChild(el('li', { cls: 'empty', text: state.result.moments.length ? 'No moments in this category.' : 'No moments had strong enough signals in this transcript. Try a different language setting, or check that the transcript has real speech text.' }));
      return;
    }
    list.forEach(function (m) { box.appendChild(card(m)); });
  }

  function render() {
    renderAnalysed();
    renderDashboard();
    renderFilters();
    renderList();
    $('results').hidden = false;
    $('noResults').hidden = true;
  }

  $('sortSelect').addEventListener('change', function (ev) { state.sort = ev.target.value; if (state.result) renderList(); });
  $('selAllBtn').addEventListener('click', function () {
    if (!state.result) return;
    visibleMoments().forEach(function (m) { state.selected[String(m.rank)] = true; });
    renderList(); renderDashboard();
  });
  $('selNoneBtn').addEventListener('click', function () {
    if (!state.result) return;
    visibleMoments().forEach(function (m) { state.selected[String(m.rank)] = false; });
    renderList(); renderDashboard();
  });

  /* ---------- Shorts plan ---------- */
  function planCard(m) {
    var e = editOf(m.rank);
    var v = viewOf(m);
    var sug = C.suggest(v, {});
    var title = el('input', { attrs: { type: 'text', maxlength: '100', 'aria-label': 'Shorts title for moment ' + m.rank, placeholder: sug.titles.shorts } });
    title.value = e.title || '';
    title.addEventListener('input', function () { e.title = title.value; });
    var cap = el('textarea', { cls: 'notes', attrs: { rows: '2', maxlength: '300', 'aria-label': 'Caption for moment ' + m.rank, placeholder: sug.caption } });
    cap.value = e.caption || '';
    cap.addEventListener('input', function () { e.caption = cap.value; });
    var notes = el('textarea', { cls: 'notes', attrs: { rows: '2', maxlength: '500', 'aria-label': 'Clip notes for moment ' + m.rank, placeholder: 'Clip notes (e.g. "cut the first 3 s, add zoom")' } });
    notes.value = e.notes || '';
    notes.addEventListener('input', function () { e.notes = notes.value; });

    var timesBox = el('div', { cls: 'm-times' });
    function drawTimes() {
      var vv = viewOf(m);
      clear(timesBox);
      timesBox.appendChild(el('div', {}, [el('b', { text: 'RECORD' }), document.createTextNode(vv.recStartText + ' → ' + vv.recEndText + ' (' + vv.recDurationSec + 's)')]));
      timesBox.appendChild(el('div', {}, [el('b', { text: 'MOMENT' }), document.createTextNode(m.startText + ' → ' + m.endText)]));
    }
    drawTimes();

    var checklist = el('ul', { cls: 'checklist' });
    CHECKS.forEach(function (c) {
      var cb = el('input', { attrs: { type: 'checkbox' } });
      cb.checked = !!e.check[c[0]];
      cb.addEventListener('change', function () { e.check[c[0]] = cb.checked; updateProgress(); });
      checklist.appendChild(el('li', {}, [el('label', {}, [cb, el('span', { text: c[1] })])]));
    });

    var actions = el('div', { cls: 'm-actions' });
    if (v.link) {
      var a = el('a', { cls: 'btn link open', text: 'Open in YouTube at ' + m.startText, attrs: { href: v.link, target: '_blank', rel: 'noopener noreferrer' } });
      a.addEventListener('click', function () { e.check.opened = true; });
      actions.appendChild(a);
    }
    actions.appendChild(actionBtn('Copy time', function () { copyWithToast(m.startText, 'Time'); }));
    actions.appendChild(actionBtn('Copy record window', function () { var vv = viewOf(m); copyWithToast(vv.recStartText + ' - ' + vv.recEndText, 'Window'); }));
    actions.appendChild(actionBtn('Copy title + caption', function () {
      var s2 = suggestionFor(m);
      copyWithToast(s2.titles.shorts + '\n' + s2.caption, 'Title and caption');
    }));
    actions.appendChild(actionBtn('Remove from plan', function () {
      state.selected[String(m.rank)] = false;
      renderPlan(); renderDashboard();
    }));

    return el('li', { cls: 'moment' }, [
      el('div', { cls: 'm-head' }, [el('span', { cls: 'm-rank', text: '#' + m.rank }), el('span', { cls: 'm-cat', text: m.categoryLabel }), el('span', { cls: 'm-conf', text: m.confidence + '%' })]),
      timesBox,
      el('p', { cls: 'm-desc', text: '“' + m.description + '”', attrs: { dir: 'auto' } }),
      padControls(m, drawTimes),
      el('label', { cls: 'field-label', text: 'Shorts title (leave empty to use the suggestion)' }), title,
      el('label', { cls: 'field-label', text: 'Caption' }), cap,
      el('label', { cls: 'field-label', text: 'Clip notes' }), notes,
      checklist, actions
    ]);
  }

  function updateProgress() {
    if (!state.result) { $('planProgress').textContent = '0 / 0 published'; return; }
    var sel = selectedMoments();
    var done = sel.filter(function (m) { return editOf(m.rank).check.published; }).length;
    $('planProgress').textContent = done + ' / ' + sel.length + ' published';
  }

  function renderPlan() {
    var box = $('planList');
    clear(box);
    if (!state.result) { $('noPlan').hidden = false; updateProgress(); return; }
    var sel = selectedMoments();
    $('noPlan').hidden = sel.length > 0;
    sel.forEach(function (m) { box.appendChild(planCard(m)); });
    updateProgress();
  }

  /* ---------- exports ---------- */
  function download(name, mime, text) {
    var blob = new Blob([text], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    toast('Export started. If nothing downloads, use "Copy whole plan" instead.');
  }
  function baseName() { return 'vice-moments-' + (state.videoId || 'transcript'); }
  function viewResult(moments) {
    return { moments: moments.map(viewOf), notes: state.result.notes, stats: state.result.stats, options: state.result.options };
  }
  $('exportTxt').addEventListener('click', function () {
    if (!state.result) return;
    download(baseName() + '.txt', 'text/plain;charset=utf-8', E.toTXT(viewResult(state.result.moments), { source: state.source, videoId: state.videoId }));
  });
  $('exportCsv').addEventListener('click', function () {
    if (!state.result) return;
    download(baseName() + '.csv', 'text/csv;charset=utf-8', '﻿' + E.toCSV(viewResult(state.result.moments)));
  });

  function planRows() {
    return selectedMoments().map(function (m) {
      var v = viewOf(m);
      var s = suggestionFor(m);
      var e = editOf(m.rank);
      var done = CHECKS.filter(function (c) { return e.check[c[0]]; }).map(function (c) { return c[1]; }).join('; ');
      return { m: m, v: v, s: s, e: e, done: done };
    });
  }
  function planText() {
    var lines = ['VICE MOMENT FINDER - Shorts plan', 'Source: ' + state.source];
    if (state.videoId) lines.push('Video: https://www.youtube.com/watch?v=' + state.videoId);
    lines.push('Transcript-only analysis; categories are guesses from wording.', '');
    planRows().forEach(function (r) {
      lines.push('#' + r.m.rank + ' ' + r.m.categoryLabel + ' (' + r.m.confidence + '% confidence)');
      lines.push('  Moment: ' + r.m.startText + ' - ' + r.m.endText);
      lines.push('  Record: ' + r.v.recStartText + ' - ' + r.v.recEndText + ' (' + r.v.recDurationSec + 's, padding ' + r.v.padSec + 's)');
      lines.push('  Title: ' + r.s.titles.shorts);
      lines.push('  Hinglish: ' + r.s.titles.hinglish);
      lines.push('  Hindi: ' + r.s.titles.hindi);
      lines.push('  Hook: ' + r.s.hook);
      lines.push('  Caption: ' + r.s.caption);
      lines.push('  Hashtags: ' + r.s.hashtags.join(' '));
      lines.push('  Edit: ' + r.s.editingStyle);
      if (r.e.notes) lines.push('  Notes: ' + r.e.notes);
      lines.push('  Done: ' + (r.done || 'nothing yet'));
      if (r.v.link) lines.push('  Link: ' + r.v.link);
      lines.push('');
    });
    return lines.join('\n');
  }
  function planCsv() {
    var head = ['rank', 'category', 'moment_start', 'moment_end', 'record_start', 'record_end', 'padding_sec', 'shorts_title', 'hinglish_title', 'hindi_title', 'hook', 'caption', 'hashtags', 'notes', 'done', 'confidence_percent', 'youtube_link', 'record_start_link'];
    var rows = [head.join(',')];
    planRows().forEach(function (r) {
      rows.push([r.m.rank, r.m.categoryLabel, r.m.startText, r.m.endText, r.v.recStartText, r.v.recEndText, r.v.padSec,
        r.s.titles.shorts, r.s.titles.hinglish, r.s.titles.hindi, r.s.hook, r.s.caption, r.s.hashtags.join(' '), r.e.notes, r.done,
        r.m.confidence, r.v.link || '', r.v.recLink || ''].map(E.csvCell).join(','));
    });
    return rows.join('\r\n') + '\r\n';
  }
  function needSelection() {
    if (!state.result || !selectedMoments().length) { toast('Select at least one moment first.'); return true; }
    return false;
  }
  $('planTxt').addEventListener('click', function () { if (!needSelection()) download(baseName() + '-plan.txt', 'text/plain;charset=utf-8', planText()); });
  $('planCsv').addEventListener('click', function () { if (!needSelection()) download(baseName() + '-plan.csv', 'text/csv;charset=utf-8', '﻿' + planCsv()); });
  $('planCopy').addEventListener('click', function () { if (!needSelection()) copyWithToast(planText(), 'Plan'); });

  /* ---------- projects ---------- */
  function initStore() {
    try { store = S.createStore(); } catch (e) { store = null; }
  }
  function defaultName() {
    var base = state.videoId ? 'Video ' + state.videoId : (state.source || 'Analysis');
    return base + ' · ' + new Date().toLocaleDateString();
  }
  function snapshot() {
    return {
      id: state.projectId,
      name: $('projName').value || defaultName(),
      url: $('urlInput').value,
      videoId: state.videoId,
      source: state.source,
      settings: { language: $('langSelect').value, count: $('countSelect').value, pad: $('padSelect').value },
      transcriptText: state.transcriptForSave || getTranscript(),
      visualText: $('visualArea').value,
      selected: state.selected,
      edits: state.edits,
      result: state.result
    };
  }
  $('saveProjBtn').addEventListener('click', function () {
    var msg = $('projMsg');
    if (!state.result) { setMsg(msg, 'Analyse a transcript first, then save it.', 'warn'); return; }
    if (!store) { setMsg(msg, 'Saving is not available in this browser.', 'err'); return; }
    store.save(snapshot()).then(function (r) {
      state.projectId = r.id;
      setMsg(msg, 'Saved "' + r.name + '" on this phone.', 'ok');
      refreshProjects();
    }).catch(function (e) { setMsg(msg, (e && e.message) || 'Could not save.', 'err'); });
  });

  function restore(id) {
    store.load(id).then(function (p) {
      state.result = p.result;
      state.projectId = p.id;
      state.videoId = p.videoId;
      state.source = p.source;
      state.selected = p.selected || {};
      state.edits = p.edits || {};
      state.filter = 'all';
      state.transcriptForSave = p.transcriptText || '';
      $('urlInput').value = p.url || '';
      $('visualArea').value = p.visualText || '';
      $('projName').value = p.name;
      var st = p.settings || {};
      if (st.language) $('langSelect').value = st.language;
      if (st.count) $('countSelect').value = st.count;
      if (st.pad) $('padSelect').value = st.pad;
      if (p.transcriptText) setTranscript(p.transcriptText, p.source);
      readVideo();
      render();
      showView('results');
      toast('Restored "' + p.name + '"');
    }).catch(function (e) { setMsg($('projMsg'), (e && e.message) || 'Could not restore that project.', 'err'); });
  }

  var armed = null;
  function arm(btn, idleText, confirmText, action) {
    btn.addEventListener('click', function () {
      if (armed === btn) { armed = null; btn.textContent = idleText; btn.classList.remove('confirm'); action(); return; }
      armed = btn;
      btn.textContent = confirmText;
      btn.classList.add('confirm');
      setTimeout(function () { if (armed === btn) { armed = null; btn.textContent = idleText; btn.classList.remove('confirm'); } }, 5000);
    });
  }

  function refreshProjects() {
    var ul = $('projList');
    clear(ul);
    if (!store) { $('noProj').hidden = false; $('noProj').textContent = 'Saving is not available in this browser.'; return; }
    store.list().then(function (items) {
      $('noProj').hidden = items.length > 0;
      $('noProj').textContent = 'No saved projects yet.';
      items.forEach(function (it) {
        var del = el('button', { cls: 'btn small ghost danger', text: 'Delete', attrs: { type: 'button' } });
        del.style.width = 'auto';
        arm(del, 'Delete', 'Tap again to delete', function () {
          store.remove(it.id).then(function () { if (state.projectId === it.id) state.projectId = null; refreshProjects(); toast('Deleted'); });
        });
        var open = actionBtn('Restore', function () { restore(it.id); }, 'small');
        ul.appendChild(el('li', {}, [
          el('b', { text: it.name }),
          el('span', { cls: 'hint', text: it.moments + ' moments · ' + it.selected + ' selected · saved ' + new Date(it.savedAt).toLocaleString() }),
          el('div', { cls: 'p-actions' }, [open, del])
        ]));
      });
    }).catch(function (e) { setMsg($('projMsg'), (e && e.message) || 'Could not read saved projects.', 'err'); });
  }
  arm($('clearAllBtn'), 'Delete all saved projects', 'Tap again: delete ALL saved projects', function () {
    if (!store) return;
    store.clearAll().then(function () { state.projectId = null; refreshProjects(); toast('All saved projects deleted'); });
  });

  /* ---------- first-use guide ---------- */
  (function () {
    if (S.prefs.get('guideDismissed') !== '1') $('firstUse').hidden = false;
    $('dismissFirst').addEventListener('click', function () { S.prefs.set('guideDismissed', '1'); $('firstUse').hidden = true; });
  })();

  /* ---------- online badge, install, service worker ---------- */
  function net() {
    var b = $('netBadge');
    var on = navigator.onLine !== false;
    b.textContent = on ? 'Online' : 'Offline: analysis still works';
    b.className = 'badge' + (on ? '' : ' off');
  }
  window.addEventListener('online', net);
  window.addEventListener('offline', net);
  net();

  window.addEventListener('beforeinstallprompt', function (ev) {
    ev.preventDefault();
    state.installEvent = ev;
    $('installBtn').hidden = false;
  });
  $('installBtn').addEventListener('click', function () {
    var ev = state.installEvent;
    if (!ev) return;
    ev.prompt();
    ev.userChoice.then(function () { state.installEvent = null; $('installBtn').hidden = true; });
  });
  window.addEventListener('appinstalled', function () { $('installBtn').hidden = true; });

  function offerUpdate(worker) {
    $('updateBar').hidden = false;
    $('updateBtn').onclick = function () { worker.postMessage('SKIP_WAITING'); };
  }
  if ('serviceWorker' in navigator) {
    var reloading = false;
    // On the very first visit the new worker "claims" the page; that must NOT reload it (it would wipe what was typed).
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (reloading || !hadController) return;
      reloading = true;
      window.location.reload();
    });
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').then(function (reg) {
        if (reg.waiting && navigator.serviceWorker.controller) offerUpdate(reg.waiting);
        reg.addEventListener('updatefound', function () {
          var nw = reg.installing;
          if (!nw) return;
          nw.addEventListener('statechange', function () {
            if (nw.state === 'installed' && navigator.serviceWorker.controller) offerUpdate(nw);
          });
        });
        if (reg.update) reg.update().catch(function () { /* offline is fine */ });
      }).catch(function () { /* app still works without it */ });
    });
  }

  initStore();
  window.__vmf = { state: state, run: run };
})();
