// Small shared helpers (work in browser and Node).

export const pad = (n, w = 2) => String(Math.trunc(n)).padStart(w, '0');

/** Seconds -> "HH:MM:SS" (rounded to whole seconds). */
export function fmtTime(sec) {
  let s = Math.max(0, Math.round(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  s -= h * 3600;
  const m = Math.floor(s / 60);
  s -= m * 60;
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

/** Seconds -> SRT style "HH:MM:SS,mmm". */
export function fmtSrtTime(sec) {
  const total = Math.max(0, Math.round((Number(sec) || 0) * 1000));
  const ms = total % 1000;
  const s = Math.floor(total / 1000);
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)},${pad(ms, 3)}`;
}

/**
 * Parse many timestamp spellings into seconds, or null if not a timestamp.
 * Accepts: 1:02:03  02:03  00:00:03,500  00:00:03.5  1h2m3s  90s  75 (plain seconds)
 */
export function parseTimestamp(input) {
  if (input == null) return null;
  const str = String(input).trim();
  if (!str) return null;
  let m = str.match(/^(?:(\d{1,3}):)?(\d{1,2}):(\d{1,2})(?:[.,](\d{1,3}))?$/);
  if (m) {
    const h = m[1] ? Number(m[1]) : 0;
    const min = Number(m[2]);
    const s = Number(m[3]);
    if (min > 59 || s > 59) return null;
    const frac = m[4] ? Number('0.' + m[4]) : 0;
    return h * 3600 + min * 60 + s + frac;
  }
  m = str.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+(?:\.\d+)?)s?)?$/i);
  if (m && (m[1] || m[2] || m[3])) {
    return (Number(m[1] || 0) * 3600) + (Number(m[2] || 0) * 60) + Number(m[3] || 0);
  }
  return null;
}

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

export function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

export function median(arr) {
  if (!arr.length) return 0;
  const a = [...arr].sort((x, y) => x - y);
  const mid = a.length >> 1;
  return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
}

export function percentile(arr, p) {
  if (!arr.length) return 0;
  const a = [...arr].sort((x, y) => x - y);
  const idx = clamp(Math.floor((p / 100) * (a.length - 1)), 0, a.length - 1);
  return a[idx];
}

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
