// Moment detection engine - deterministic, runs fully in the browser, no AI key needed.
//
// How it works (and what it is NOT):
//  1. Every transcript line gets a "peak potential" from SEVERAL signals: laughter patterns, stretched or
//     shouted words, repetition, speech-pace jumps against the local average, short exclaimed lines, and
//     lexicon hits (Hindi / Hinglish / English). Keywords are only one input.
//  2. A second pass looks at CONTEXT: calm set-up -> sudden reaction, ordinary line -> laughter that follows
//     (so the ordinary line becomes the punchline), pause -> burst, escalation chains, question -> answer.
//  3. Local maxima become candidates. Each gets natural boundaries (build-up, punchline, reaction, pauses).
//  4. Candidates are scored with a transparent weighted breakdown and de-duplicated.
// The score ranks moments inside THIS transcript. It does not predict YouTube performance.
import { categoryLabel } from './categories.js';
import { getPreset } from './clip.js';
import { audioForRange } from './audio.js';
import { suggestTitle } from './creator.js';
import { APPLAUSE_RE, LAUGH_RE, NOISE_ONLY_RE, countHits } from './lexicon.js';
import { clamp, median, percentile } from './util.js';

export const DEFAULT_OPTIONS = {
  preset: 'standard',
  maxMoments: 20,
  minScore: 35,
  gapBreak: 1.8, // seconds of silence that normally ends a scene
};

/** Transparent weights. Audio weight is dropped (and the rest re-normalised) when no audio was analysed. */
export const WEIGHTS = {
  humor: 0.22, surprise: 0.16, emotion: 0.16, dialogue: 0.12,
  context: 0.12, independence: 0.08, hook: 0.08, audio: 0.06,
};
/** Display stretch only (does not change ranking), so good moments are not all stuck near 60. */
export const SCORE_SCALE = 1.2;

const WEAK = new Set([
  'kya', 'kaise', 'yaar', 'bhai', 'car', 'star', 'win', 'yes', 'help', 'dar', 'mast', 'logic', 'drama', 'weird',
  'please', 'plz', 'online', 'bug', 'mission', 'so', 'but', 'then', 'par', 'tab', 'phir', 'fir', 'matlab',
  'dekho', 'has', 'hans', 'maar', 'tod', 'jump', 'jet', 'boom', 'believe', 'suddenly', 'seriously', 'sala',
  'saala', 'क्या', 'कैसे', 'यार',
]);
const weighted = (hits) => hits.words.reduce((a, w) => a + (WEAK.has(w) ? 0.4 : 1), 0);

const ACRONYMS = new Set(['GTA', 'NPC', 'FPS', 'OMG', 'WTF', 'LOL', 'LMAO', 'USA', 'PS', 'PC', 'HD', 'RP']);
const CONTINUATION = new Set(['aur', 'toh', 'isliye', 'fir', 'phir', 'lekin', 'magar', 'and', 'so', 'but', 'because', 'तो', 'और', 'लेकिन', 'इसलिए']);
const SENTENCE_END = /[.?!।…]["')\]]*$/;

const SIGNAL_TEXT = {
  laughter: ['Laughter in or right after the line', 3],
  punchline: ['An ordinary-sounding line is followed by laughter, so it reads as the punchline', 3],
  setup_reaction: ['Calm set-up followed by a short, exclaimed reaction', 2.5],
  pause_then_burst: ['A pause is followed by a sudden burst of speech', 2],
  reaction_chain: ['Several strong lines in a row (escalation)', 2],
  question_answer: ['A question is answered immediately with an exclamation', 1.5],
  repeat: ['Repeated words (like "nahi nahi nahi") suggest panic or disbelief', 1.5],
  pace: ['Speaking pace jumped well above the local average', 1.5],
  action_words: ['Gameplay-event words (police, crash, blast, chase...)', 1.5],
  surprise_words: ['Surprise wording (arre, kya, wow...)', 1.2],
  emotion_words: ['Strong emotional wording', 1.2],
  funny_words: ['Funny wording', 1.2],
  stretched: ['Stretched or shouted words', 1],
  turn_taking: ['Quick back-and-forth between speakers', 1],
};

/* ---------- per-segment features ---------- */
function featuresFor(seg) {
  const txt = seg.text;
  const noiseOnly = NOISE_ONLY_RE.test(txt) && !LAUGH_RE.test(txt) && !APPLAUSE_RE.test(txt);
  const clean = txt.replace(/\[[^\]]*\]/g, ' ').trim();
  const words = clean.toLowerCase().match(/[\p{L}\p{M}']+/gu) || [];
  const dur = Math.max(0.6, seg.end - seg.start);
  const laughRe = new RegExp(LAUGH_RE.source, 'gi');
  const laugh = noiseOnly ? 0 : Math.max((txt.match(laughRe) || []).length, countHits('laughter', txt).count);
  const f = {
    noiseOnly,
    words: words.length,
    dur,
    wps: words.length / dur,
    laugh,
    applause: APPLAUSE_RE.test(txt) ? 1 : 0,
    excl: (txt.match(/[!！]/g) || []).length,
    q: (txt.match(/[?？]/g) || []).length,
    caps: (txt.match(/\b[A-Z]{3,}\b/g) || []).filter((w) => !ACRONYMS.has(w)).length,
    elong: (txt.match(/([A-Za-z])\1{2,}/g) || []).length,
    repeat: 0,
    funny: noiseOnly ? 0 : weighted(countHits('funny', clean)),
    surprise: noiseOnly ? 0 : weighted(countHits('surprise', clean)),
    action: noiseOnly ? 0 : weighted(countHits('action', clean)),
    emotion: noiseOnly ? 0 : weighted(countHits('emotion', clean)),
    narrative: noiseOnly ? 0 : countHits('narrative', clean).count,
    endsSentence: SENTENCE_END.test(txt.trim()),
    firstWord: words[0] || '',
  };
  // repeated word run: "nahi nahi nahi" -> 1, "nahi nahi" -> 0.5
  let run = 1;
  for (let i = 1; i < words.length; i++) {
    run = words[i] === words[i - 1] ? run + 1 : 1;
    f.repeat = Math.max(f.repeat, run >= 3 ? 1 : run === 2 && words[i].length > 2 ? 0.5 : 0);
  }
  return f;
}

function basePotential(f, burst) {
  if (f.noiseOnly) return 0;
  const shortPunch = f.words > 0 && f.words <= 7 && (f.excl > 0 || f.surprise >= 1 || f.emotion >= 1) ? 1 : 0;
  const p =
    0.35 * Math.min(1, f.laugh) +
    0.2 * Math.min(1, f.funny / 2) +
    0.3 * Math.min(1, f.surprise / 2) +
    0.15 * Math.min(1, f.action / 3) +
    0.25 * Math.min(1, f.emotion / 2) +
    0.2 * Math.min(1, f.excl / 2) +
    0.15 * Math.min(1, f.elong) +
    0.1 * Math.min(1, f.caps / 2) +
    0.2 * f.repeat +
    0.15 * burst +
    0.15 * shortPunch +
    0.1 * f.applause;
  return Math.min(2, p);
}

/* ---------- helpers ---------- */
export function overlapSeconds(a, b) {
  return Math.max(0, Math.min(a.end, b.end) - Math.max(a.start, b.start));
}
/** Two moments are duplicates when they overlap noticeably or their peaks are almost the same instant. */
export function isDuplicate(a, b) {
  const minDur = Math.max(1, Math.min(a.end - a.start, b.end - b.start));
  return overlapSeconds(a, b) / minDur > 0.2 || Math.abs((a.peak ?? a.start) - (b.peak ?? b.start)) < 8;
}

const soft = (x, k) => 1 - Math.exp(-Math.max(0, x) / k);

/* ---------- main ---------- */
export function analyzeTranscript(segmentsIn, options = {}, ctx = {}) {
  const opt = { ...DEFAULT_OPTIONS, ...options };
  const preset = getPreset(opt.preset);
  const segs = (segmentsIn || []).filter((s) => s && s.text);
  const notes = [];
  const stats = {
    segments: segs.length,
    durationSec: segs.length ? Math.max(...segs.map((s) => s.end)) : 0,
    audioUsed: false,
    preset: preset.key,
    notes,
  };
  if (segs.length < 3) {
    notes.push(segs.length ? 'The transcript is too short to analyse (fewer than 3 lines).' : 'The transcript is empty.');
    return { moments: [], stats };
  }

  const n = segs.length;
  const F = segs.map(featuresFor);
  const punctRatio = F.filter((f) => f.endsSentence).length / n;
  if (punctRatio < 0.05) notes.push('This transcript has almost no punctuation (typical for auto-captions). Boundaries rely on pauses and may be less tidy; check them before clipping.');

  // local speech-pace baseline (median words/second within +-45s)
  const burst = new Array(n).fill(0);
  let lo = 0;
  let hi = 0;
  for (let i = 0; i < n; i++) {
    while (segs[lo].start < segs[i].start - 45) lo++;
    while (hi < n && segs[hi].start <= segs[i].start + 45) hi++;
    const base = median(F.slice(lo, hi).filter((f) => f.words >= 2).map((f) => f.wps));
    if (F[i].words >= 4 && base > 0) burst[i] = clamp((F[i].wps / Math.max(0.5, base) - 1.3) / 1.2, 0, 1);
  }

  // pass 1: base potential
  const P0 = F.map((f, i) => basePotential(f, burst[i]));
  const sig = Array.from({ length: n }, () => new Set());

  // pass 2: context adjustments
  const P1 = P0.slice();
  for (let i = 0; i < n; i++) {
    const s = segs[i];
    const f = F[i];
    if (f.noiseOnly) continue;
    if (f.laugh) sig[i].add('laughter');
    if (f.repeat >= 0.5) sig[i].add('repeat');
    if (burst[i] > 0.3) sig[i].add('pace');
    if (f.action >= 1) sig[i].add('action_words');
    if (f.surprise >= 1) sig[i].add('surprise_words');
    if (f.emotion >= 1) sig[i].add('emotion_words');
    if (f.funny >= 1) sig[i].add('funny_words');
    if (f.elong || f.caps) sig[i].add('stretched');

    const gapBefore = i === 0 ? Infinity : s.start - segs[i - 1].end;
    // calm set-up -> short strong reaction
    const setup = [i - 1, i - 2].some((j) => j >= 0 && s.start - segs[j].end <= 5 && F[j].words >= 6 && P0[j] < 0.25);
    if (setup && P0[i] >= 0.45 && f.words <= 8) { P1[i] += 0.3; sig[i].add('setup_reaction'); }
    // ordinary line followed by laughter -> the ordinary line is the punchline
    if (!f.laugh && f.words >= 3 && P0[i] < 0.6) {
      const laughNext = [i + 1, i + 2].some((j) => j < n && F[j].laugh && segs[j].start - s.end <= 4);
      if (laughNext) { P1[i] += 0.45; sig[i].add('punchline'); }
    }
    if (gapBefore >= 2 && P0[i] >= 0.45) { P1[i] += 0.1; sig[i].add('pause_then_burst'); }
    if (i + 2 < n && P0[i + 1] >= 0.3 && P0[i + 2] >= 0.3 && P0[i] >= 0.3) { P1[i] += 0.15; sig[i].add('reaction_chain'); }
    if (i > 0 && F[i - 1].q && s.start - segs[i - 1].end <= 4 && f.words <= 8 && f.excl) { P1[i] += 0.15; sig[i].add('question_answer'); }
    if (i > 0 && s.speaker && segs[i - 1].speaker && s.speaker !== segs[i - 1].speaker && s.start - segs[i - 1].end <= 3 && P0[i] >= 0.3) {
      P1[i] += 0.1; sig[i].add('turn_taking');
    }
    P1[i] = Math.min(2.5, P1[i]);
  }

  // candidate peaks: strong and locally maximal within +-6s
  const positive = P1.filter((x) => x > 0.15);
  const T = clamp(percentile(positive, 70), 0.4, 0.7);
  const peaks = [];
  for (let i = 0; i < n; i++) {
    if (P1[i] < T) continue;
    let isMax = true;
    for (let j = i - 1; j >= 0 && segs[i].start - segs[j].start <= 6; j--) if (P1[j] >= P1[i]) { isMax = false; break; }
    for (let j = i + 1; isMax && j < n && segs[j].start - segs[i].start <= 6; j++) if (P1[j] > P1[i]) isMax = false;
    if (isMax) peaks.push(i);
  }

  const gapAfter = (k) => (k + 1 < n ? segs[k + 1].start - segs[k].end : Infinity);
  const startsNaturally = (k) => k === 0 || segs[k].start - segs[k - 1].end >= 0.6 || F[k - 1].endsSentence;
  const endsNaturally = (k) => k === n - 1 || gapAfter(k) >= 0.6 || F[k].endsSentence;

  function buildWindow(p) {
    let s = p;
    let e = p;
    // build-up: keep energetic lines plus at most two calm set-up lines (the calm chatter before is not part of the scene)
    let calmUsed = 0;
    while (s > 0) {
      const prev = segs[s - 1];
      if (segs[s].start - prev.end > opt.gapBreak) break;
      if (segs[p].start - prev.start > preset.preMax) break;
      if (P0[s - 1] < 0.2) {
        if (calmUsed >= 2) break;
        calmUsed++;
      }
      s--;
    }
    while (e < n - 1) {
      const next = segs[e + 1];
      if (next.start - segs[e].end > opt.gapBreak) break;
      if (next.end - segs[p].end > preset.postMax) break;
      if (segs[e].end - segs[p].end >= 3.5 && P1[e + 1] < 0.25 && endsNaturally(e)) break;
      e++;
    }
    for (let extra = 0; extra < 2 && e < n - 1 && !endsNaturally(e) && gapAfter(e) <= opt.gapBreak; extra++) e++;

    const dur = () => segs[e].end - segs[s].start;
    // too short: add context while the dialogue stays continuous
    // (only up to 60% of the recommendation: padding a naturally short scene with unrelated chatter is worse than a short clip)
    for (let guard = 0; dur() < preset.min * 0.6 && guard < 40; guard++) {
      const canBack = s > 0 && segs[s].start - segs[s - 1].end <= opt.gapBreak * 1.5;
      const canFwd = e < n - 1 && gapAfter(e) <= opt.gapBreak * 1.5;
      if (!canBack && !canFwd) break;
      if (canBack && (!canFwd || segs[p].start - segs[s].start <= segs[e].end - segs[p].end)) s--; else e++;
    }
    // too long: trim far edges but keep set-up and reaction around the peak (up to 1.35x the recommendation)
    const hardMax = preset.max * 1.35;
    for (let guard = 0; dur() > hardMax && guard < 200; guard++) {
      const early = segs[p].start - segs[s].start;
      const late = segs[e].end - segs[p].end;
      if (s < p && early >= late) s++; else if (e > p) e--; else if (s < p) s++; else break;
    }
    return [s, e];
  }

  const candidates = [];
  for (const p of peaks) {
    const [s, e] = buildWindow(p);
    const start = Math.max(0, segs[s].start - 0.3);
    const end = segs[e].end + 0.5;
    const idx = [];
    for (let k = s; k <= e; k++) idx.push(k);

    const agg = (fn) => idx.reduce((a, k) => a + fn(k), 0);
    const flags = new Set(idx.flatMap((k) => [...sig[k]]));
    const laughSegs = agg((k) => (F[k].laugh ? 1 : 0));
    const funnyHits = agg((k) => F[k].funny);
    const surpriseHits = agg((k) => F[k].surprise);
    const emotionHits = agg((k) => F[k].emotion);
    const actionHits = agg((k) => F[k].action);
    const exclSegs = agg((k) => (F[k].excl ? 1 : 0));
    const capsElong = agg((k) => F[k].caps + F[k].elong);
    const repeat = Math.max(...idx.map((k) => F[k].repeat));
    const burstMax = Math.max(...idx.map((k) => burst[k]));
    const hasQ = idx.some((k) => F[k].q && F[k].excl) || idx.some((k) => /[?？]\s*[!！]|[!！]\s*[?？]/.test(segs[k].text));
    const hasSetup = s < p;
    const hasReaction = e > p || F[p].laugh > 0;
    const turn = flags.has('question_answer') || flags.has('turn_taking');

    const humor = soft(0.9 * Math.min(laughSegs, 3) + 0.5 * funnyHits + (flags.has('punchline') ? 1 : 0) + (flags.has('setup_reaction') ? 0.4 : 0), 1.6);
    const surprise = soft(0.7 * surpriseHits + (flags.has('pause_then_burst') ? 0.5 : 0) + (hasQ ? 0.5 : 0) + 0.4 * Math.min(2, capsElong) + (flags.has('reaction_chain') ? 0.4 : 0), 1.4);
    const emotion = soft(0.6 * emotionHits + 0.5 * Math.min(2, exclSegs) + 0.4 * Math.min(2, F[p].caps + capsElong * 0.5) + 0.4 * repeat + 0.6 * burstMax + 0.3 * idx.some((k) => F[k].applause), 1.5);
    const pf = F[p];
    const dialogue = Math.min(1,
      (pf.words > 0 && pf.words <= 10 && (pf.excl || pf.q || pf.surprise >= 1 || pf.emotion >= 1) ? 0.5 : 0) +
      (hasSetup && F[s].words >= 6 ? 0.2 : 0) + 0.15 * repeat * 2 + (turn ? 0.2 : 0));
    let continuous = true;
    for (let k = s; k < e; k++) if (segs[k + 1].start - segs[k].end > opt.gapBreak) continuous = false;
    const dur = end - start;
    const context = (hasSetup ? 0.35 : 0) + (hasReaction ? 0.3 : 0) + (continuous ? 0.2 : 0) + (dur >= preset.min * 0.8 && dur <= preset.max * 1.35 ? 0.15 : 0);
    const independence = (startsNaturally(s) ? 0.4 : 0) + (endsNaturally(e) ? 0.3 : 0) + (CONTINUATION.has(F[s].firstWord) ? 0 : 0.3);
    const firstTwo = idx.slice(0, 2);
    const hook = Math.min(1,
      0.6 * Math.min(1, Math.max(...firstTwo.map((k) => P1[k])) / 0.9) +
      (F[s].excl || F[s].q ? 0.2 : 0) + (F[s].words > 0 && F[s].words <= 8 ? 0.2 : 0));

    let audio = null;
    let audioInfo = null;
    if (options.audio && options.audio.length) {
      audioInfo = audioForRange(options.audio, start, end);
      if (audioInfo) {
        const textSignal = Math.max(humor, surprise, emotion);
        // Audio can only re-rank moments that already have text evidence.
        audio = audioInfo.score * (textSignal < 0.25 ? 0.3 : 1);
        stats.audioUsed = true;
      }
    }

    const sub = { humor, surprise, emotion, dialogue, context, independence, hook, audio };
    const used = Object.keys(WEIGHTS).filter((k) => sub[k] != null);
    const wsum = used.reduce((a, k) => a + WEIGHTS[k], 0);
    const raw = used.reduce((a, k) => a + WEIGHTS[k] * sub[k], 0) / wsum;
    const score = Math.round(100 * clamp(raw * SCORE_SCALE, 0, 1));

    const strengths = {
      funny: humor, surprise, action: soft(actionHits, 2.2), emotion, dialogue,
      story: Math.min(1, (hasSetup && hasReaction && continuous ? 0.4 : 0) + 0.1 * agg((k) => Math.min(2, F[k].narrative)) + (turn ? 0.2 : 0) + (dur >= 20 ? 0.2 : 0)) * 0.8,
    };
    const order = ['funny', 'surprise', 'action', 'emotion', 'dialogue', 'story'];
    const ranked = order.slice().sort((a, b) => strengths[b] - strengths[a] || order.indexOf(a) - order.indexOf(b));
    const category = ranked[0];
    const secondary = strengths[ranked[1]] >= 0.7 * strengths[category] && strengths[ranked[1]] > 0.2 ? ranked[1] : null;

    const signalKeys = [...flags].sort((a, b) => (SIGNAL_TEXT[b]?.[1] || 0) - (SIGNAL_TEXT[a]?.[1] || 0));
    const signals = signalKeys.filter((k) => SIGNAL_TEXT[k]).map((k) => ({ key: k, text: SIGNAL_TEXT[k][0] }));
    const top = signals.slice(0, 3).map((x) => x.text);
    if (audioInfo && audioInfo.jumpDb >= 6) top.push(`Audio got about ${audioInfo.jumpDb} dB louder than the surrounding minute (loudness only)`);
    const reason = (top.length ? top.join('; ') : 'Moderate energy compared with the rest of the transcript') +
      `. Window starts at the ${hasSetup ? 'set-up' : 'first line'} and ends ${hasReaction ? 'after the reaction' : 'at a natural pause'}.`;

    const excerptFull = idx.map((k) => segs[k].text).join(' ');
    candidates.push({
      start, end, duration: end - start, peak: segs[p].start,
      peakText: segs[p].text, peakOffset: segs[p].start - start, firstText: segs[s].text,
      excerpt: excerptFull.length > 260 ? `${excerptFull.slice(0, 257)}...` : excerptFull,
      category, secondary, categoryLabel: categoryLabel(category, secondary),
      score, breakdown: Object.fromEntries(Object.entries(sub).map(([k, v]) => [k, v == null ? null : Number(v.toFixed(3))])),
      signals, reason, audio: audioInfo, segmentRange: [s, e],
    });
  }

  // best first, then drop duplicates / overlaps
  if (opt.debug) { stats.debugP = P1.map((v, i) => [Number(segs[i].start.toFixed(1)), Number(v.toFixed(2)), P0[i] === P1[i] ? '' : 'adj']); stats.debugT = T; }
  if (opt.debug) stats.debugCandidates = candidates.map((c) => ({ start: c.start, end: c.end, score: c.score, peakText: c.peakText }));
  candidates.sort((a, b) => b.score - a.score || a.start - b.start);
  const kept = [];
  for (const c of candidates) {
    if (c.score < opt.minScore) continue;
    if (kept.some((k) => isDuplicate(k, c))) continue;
    kept.push(c);
    if (kept.length >= opt.maxMoments) break;
  }
  kept.forEach((m, i) => {
    m.rank = i + 1;
    m.id = `m_${Math.round(m.start * 10)}`;
    m.title = suggestTitle(m, ctx);
    m.edited = false;
  });
  if (!kept.length) notes.push('No moment passed the minimum score. Try lowering "Minimum score" in Settings, or check that the transcript has real conversation.');
  if (!stats.audioUsed) notes.push('Audio analysis was not used (transcript-only). Attach your own audio/video file in Settings to add a loudness signal.');
  return { moments: kept, stats };
}
