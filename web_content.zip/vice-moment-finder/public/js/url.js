// YouTube URL parsing and video-id extraction.
import { parseTimestamp } from './util.js';

const ID_RE = /^[A-Za-z0-9_-]{11}$/;
const HOSTS = new Set([
  'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com',
  'youtube-nocookie.com', 'www.youtube-nocookie.com',
]);

export const isVideoId = (s) => ID_RE.test(String(s || ''));

/**
 * Parse a YouTube URL (or bare 11-char id).
 * Returns { ok:true, id, kind, startSeconds, url } or { ok:false, code, message }.
 * kind: 'watch' | 'short-link' | 'live' | 'shorts' | 'embed' | 'id'
 */
export function parseYouTubeUrl(input) {
  const raw = String(input ?? '').trim();
  if (!raw) return fail('EMPTY', 'Paste a YouTube link first.');
  if (isVideoId(raw)) return ok(raw, 'id', null);

  let u;
  try {
    u = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`);
  } catch {
    return fail('INVALID_URL', 'That does not look like a valid link.');
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') {
    return fail('INVALID_URL', 'Only http(s) YouTube links are supported.');
  }
  const host = u.hostname.toLowerCase();
  const start = parseStart(u);

  if (host === 'youtu.be') {
    const id = u.pathname.split('/').filter(Boolean)[0];
    return isVideoId(id) ? ok(id, 'short-link', start) : fail('INVALID_URL', 'Could not find a video id in that youtu.be link.');
  }
  if (!HOSTS.has(host)) return fail('INVALID_URL', 'That link is not a YouTube link.');

  const parts = u.pathname.split('/').filter(Boolean);
  if (parts[0] === 'watch') {
    const id = u.searchParams.get('v');
    return isVideoId(id) ? ok(id, 'watch', start) : fail('INVALID_URL', 'This watch link has no valid video id (v=...).');
  }
  if (['live', 'shorts', 'embed', 'v'].includes(parts[0])) {
    const kind = parts[0] === 'v' ? 'embed' : parts[0];
    return isVideoId(parts[1]) ? ok(parts[1], kind, start) : fail('INVALID_URL', `Could not find a video id in that /${parts[0]}/ link.`);
  }
  return fail('INVALID_URL', 'Unsupported YouTube link. Use a watch, youtu.be, live or shorts link of a single video.');
}

function parseStart(u) {
  const t = u.searchParams.get('t') ?? u.searchParams.get('start');
  if (!t) return null;
  return parseTimestamp(t);
}
const ok = (id, kind, startSeconds) => ({
  ok: true, id, kind, startSeconds,
  url: `https://www.youtube.com/watch?v=${id}`,
});
const fail = (code, message) => ({ ok: false, code, message });

export const watchUrl = (id, sec) =>
  `https://www.youtube.com/watch?v=${id}${sec != null ? `&t=${Math.max(0, Math.floor(sec))}s` : ''}`;
export const shortLink = (id, sec) =>
  `https://youtu.be/${id}${sec != null ? `?t=${Math.max(0, Math.floor(sec))}` : ''}`;
export const thumbnailUrl = (id) => `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
export const embedUrl = (id, start, end) => {
  const q = new URLSearchParams({ start: String(Math.max(0, Math.floor(start || 0))), rel: '0', playsinline: '1' });
  if (end != null) q.set('end', String(Math.ceil(end)));
  return `https://www.youtube-nocookie.com/embed/${id}?${q}`;
};
