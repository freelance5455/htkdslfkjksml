// Small UI helpers. No prompt()/confirm()/alert(): they do not work inside many Android WebView/APK wrappers.
import { escapeHtml } from './util.js';

let toastTimer;
export function toast(msg, ms = 2400) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = msg;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, ms);
}

function openModal(html) {
  const m = document.getElementById('modal');
  m.innerHTML = `<div class="box" role="dialog" aria-modal="true">${html}</div>`;
  m.hidden = false;
  return m;
}
const closeModal = () => { const m = document.getElementById('modal'); m.hidden = true; m.innerHTML = ''; };

export function askText(title, value = '', okLabel = 'Save') {
  return new Promise((resolve) => {
    const m = openModal(`<h2>${escapeHtml(title)}</h2><input type="text" id="mi" value="${escapeHtml(value)}" maxlength="120">
      <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-x="no">Cancel</button><button class="btn primary" data-x="ok">${escapeHtml(okLabel)}</button></div>`);
    const input = m.querySelector('#mi');
    input.focus(); input.select();
    const done = (v) => { closeModal(); resolve(v); };
    m.onclick = (e) => {
      const x = e.target.closest('[data-x]')?.dataset.x;
      if (x === 'ok') done(input.value.trim() || null);
      else if (x === 'no' || e.target === m) done(null);
    };
    input.onkeydown = (e) => { if (e.key === 'Enter') done(input.value.trim() || null); };
  });
}

export function askConfirm(message, okLabel = 'Delete') {
  return new Promise((resolve) => {
    const m = openModal(`<p>${escapeHtml(message)}</p>
      <div class="row" style="margin-top:12px;justify-content:flex-end"><button class="btn" data-x="no">Cancel</button><button class="btn danger" data-x="ok">${escapeHtml(okLabel)}</button></div>`);
    m.onclick = (e) => {
      const x = e.target.closest('[data-x]')?.dataset.x;
      if (x === 'ok') { closeModal(); resolve(true); } else if (x === 'no' || e.target === m) { closeModal(); resolve(false); }
    };
  });
}

export async function copyText(text) {
  try {
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); return true; }
  } catch { /* fall through to legacy copy */ }
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.setAttribute('readonly', '');
  ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
  document.body.appendChild(ta);
  ta.select();
  let ok = false;
  try { ok = document.execCommand('copy'); } catch { ok = false; }
  ta.remove();
  return ok;
}

export function downloadText(filename, text, mime = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/** Read a user-picked file as text. FileReader fallback for browsers where Blob.text() misbehaves. */
export function readFileText(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result || ''));
    fr.onerror = () => reject(new Error('Could not read that file.'));
    fr.readAsText(file);
  });
}
