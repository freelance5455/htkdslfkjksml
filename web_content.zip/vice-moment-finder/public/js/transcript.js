// Transcript parsing, normalisation, language detection and export.
// Segment shape: { start:number, end:number, text:string, speaker?:string }
import { fmtSrtTime, fmtTime, parseTimestamp } from './util.js';

const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'" };
export function decodeEntities(s) {
  return String(s ?? '')
    .replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
      const k = e.toLowerCase();
      if (k[0] === '#') {
        const code = k[1] === 'x' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10);
        return Number.isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : m;
      }
      return ENTITIES[k] ?? m;
    });
}

const cleanCueText = (s) =>
  decodeEntities(String(s).replace(/<[^>]+>/g, '').replace(/\{\\[^}]*\}/g, ''))
    .replace(/\s+/g, ' ')
    .trim();

const TS = '(?:\\d{1,3}:)?\\d{1,2}:\\d{2}(?:[.,]\\d{1,3})?';
const TIMING_RE = new RegExp(`(${TS})\\s*-->\\s*(${TS})`);

/** SRT parser. */
export function parseSRT(text) {
  const blocks = String(text ?? '').replace(/^﻿/, '').replace(/\r\n?/g, '\n').split(/\n{2,}/);
  const segments = [];
  for (const block of blocks) {
    const lines = block.split('\n');
    const idx = lines.findIndex((l) => TIMING_RE.test(l));
    if (idx < 0) continue;
    const m = lines[idx].match(TIMING_RE);
    const start = parseTimestamp(m[1]);
    const end = parseTimestamp(m[2]);
    const body = lines.slice(idx + 1).join(' ');
    const text = cleanCueText(body);
    if (start == null || end == null || !text) continue;
    segments.push({ start, end, text });
  }
  return segments;
}

/** WebVTT parser (handles header, NOTE/STYLE blocks, cue ids, settings, <v Speaker>). */
export function parseVTT(text) {
  const blocks = String(text ?? '').replace(/^﻿/, '').replace(/\r\n?/g, '\n').split(/\n{2,}/);
  const segments = [];
  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed || /^WEBVTT/.test(trimmed) || /^(NOTE|STYLE|REGION)\b/.test(trimmed)) continue;
    const lines = block.split('\n');
    const idx = lines.findIndex((l) => TIMING_RE.test(l));
    if (idx < 0) continue;
    const m = lines[idx].match(TIMING_RE);
    const start = parseTimestamp(m[1]);
    const end = parseTimestamp(m[2]);
    const rawBody = lines.slice(idx + 1).join(' ');
    const voice = rawBody.match(/<v(?:\.[^\s>]+)?\s+([^>]+)>/);
    const text = cleanCueText(rawBody);
    if (start == null || end == null || !text) continue;
    const seg = { start, end, text };
    if (voice) seg.speaker = voice[1].trim();
    segments.push(seg);
  }
  return segments;
}

/**
 * Pasted / TXT transcripts. Supports:
 *   [00:03:12] text            00:03:12 text            3:12 - text
 *   00:03:12 - 00:03:16 text   and the two-line form:  "00:00:03 - 00:00:06" then text on next line
 */
export function parsePlain(text) {
  const lines = String(text ?? '').replace(/^﻿/, '').replace(/\r\n?/g, '\n').split('\n');
  const T = '(?:\\d{1,3}:)?\\d{1,2}:\\d{2}(?:[.,]\\d{1,3})?';
  const range = new RegExp(`^[\\s\\[(]*(${T})[\\s\\])]*(?:-->|-|–|—|to)\\s*[\\[(]?(${T})[\\])]?\\s*[:\\-–—]?\\s*(.*)$`, 'i');
  const single = new RegExp(`^[\\s\\[(]*(${T})[\\s\\])]*[:\\-–—]?\\s*(.*)$`);
  const out = [];
  let cur = null;
  const flush = () => { if (cur && cur.text.trim()) out.push(cur); cur = null; };
  for (const line of lines) {
    const raw = line.trim();
    if (!raw) { flush(); continue; }
    let m = raw.match(range);
    if (m) {
      flush();
      cur = { start: parseTimestamp(m[1]), end: parseTimestamp(m[2]), text: m[3] || '', hasEnd: true };
      continue;
    }
    m = raw.match(single);
    if (m) {
      flush();
      cur = { start: parseTimestamp(m[1]), end: null, text: m[2] || '', hasEnd: false };
      continue;
    }
    if (cur) cur.text += (cur.text ? ' ' : '') + raw;
  }
  flush();
  const segs = out.filter((s) => s.start != null);
  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    if (s.end == null || s.end <= s.start) {
      const next = segs[i + 1];
      s.end = next && next.start > s.start ? Math.min(next.start, s.start + 12) : s.start + 4;
    }
    s.text = cleanCueText(s.text.replace(/^["“”']|["“”']$/g, ''));
    delete s.hasEnd;
  }
  return segs.filter((s) => s.text);
}

/** YouTube "json3" caption payload (fmt=json3). */
export function parseJson3(data) {
  const obj = typeof data === 'string' ? JSON.parse(data) : data;
  const segments = [];
  for (const ev of obj?.events ?? []) {
    if (!Array.isArray(ev.segs) || ev.tStartMs == null) continue;
    const text = cleanCueText(ev.segs.map((s) => s.utf8 ?? '').join(''));
    if (!text) continue;
    const start = ev.tStartMs / 1000;
    const dur = ev.dDurationMs != null ? ev.dDurationMs / 1000 : 3;
    segments.push({ start, end: start + dur, text });
  }
  return segments;
}

/** YouTube timedtext XML (<transcript><text start dur> or srv3 <p t d>). */
export function parseTimedTextXml(xml) {
  const segments = [];
  const s = String(xml ?? '');
  let m;
  const textRe = /<text\s+[^>]*?start="([\d.]+)"(?:[^>]*?dur="([\d.]+)")?[^>]*>([\s\S]*?)<\/text>/g;
  while ((m = textRe.exec(s))) {
    const text = cleanCueText(m[3]);
    if (!text) continue;
    const start = Number(m[1]);
    segments.push({ start, end: start + (m[2] ? Number(m[2]) : 3), text });
  }
  if (segments.length) return segments;
  const pRe = /<p\s+[^>]*?t="(\d+)"(?:[^>]*?d="(\d+)")?[^>]*>([\s\S]*?)<\/p>/g;
  while ((m = pRe.exec(s))) {
    const text = cleanCueText(m[3]);
    if (!text) continue;
    const start = Number(m[1]) / 1000;
    segments.push({ start, end: start + (m[2] ? Number(m[2]) / 1000 : 3), text });
  }
  return segments;
}

/** Detect the format and parse. Returns { segments, format, warnings }. */
export function parseTranscript(text) {
  const t = String(text ?? '');
  const warnings = [];
  let format;
  let segments;
  if (/^﻿?\s*WEBVTT/.test(t)) { format = 'vtt'; segments = parseVTT(t); }
  else if (TIMING_RE.test(t)) { format = 'srt'; segments = parseSRT(t); }
  else if (/^\s*[{[]/.test(t) && /"events"\s*:/.test(t)) {
    format = 'json3';
    try { segments = parseJson3(t); } catch { segments = []; }
  } else if (/<(transcript|timedtext)\b/.test(t)) { format = 'xml'; segments = parseTimedTextXml(t); }
  else { format = 'plain'; segments = parsePlain(t); }
  if (!segments.length) {
    warnings.push(
      format === 'plain'
        ? 'No timestamps found. Each line needs a time like 00:03:12 (or [3:12]) at the start.'
        : `The ${format.toUpperCase()} data contained no readable captions.`,
    );
  }
  return { segments: normalizeSegments(segments), format, warnings };
}

/**
 * Normalise: sort, validate, repair bad ends, collapse "rolling" auto-caption repeats.
 * Original start times are never changed; unrelated sentences are never merged.
 */
export function normalizeSegments(input, { dedupeRolling = true } = {}) {
  const segs = (input || [])
    .map((s) => ({
      ...s,
      start: Number(s.start),
      end: Number(s.end),
      text: cleanCueText(s.text ?? ''),
    }))
    .filter((s) => Number.isFinite(s.start) && s.start >= 0 && s.text)
    .sort((a, b) => a.start - b.start || a.end - b.end);

  for (let i = 0; i < segs.length; i++) {
    const s = segs[i];
    if (!Number.isFinite(s.end) || s.end <= s.start) {
      const next = segs[i + 1];
      s.end = next && next.start > s.start ? Math.min(next.start, s.start + 6) : s.start + 3;
    }
  }
  if (!dedupeRolling) return segs;

  const out = [];
  let lastFull = ''; // full text of the previous cue as captioned (before rolling words were trimmed)
  for (const s of segs) {
    const prev = out[out.length - 1];
    const b = s.text.toLowerCase();
    if (prev) {
      const near = s.start - prev.end <= 0.6;
      if (near && b === lastFull) { prev.end = Math.max(prev.end, s.end); continue; }
      if (near && b.startsWith(lastFull + ' ')) { // rolling caption: new cue repeats previous words first
        const rest = s.text.slice(lastFull.length).trim();
        lastFull = b;
        out.push({ ...s, text: rest });
        continue;
      }
    }
    lastFull = b;
    out.push({ ...s });
  }
  return out.filter((s) => s.text);
}

/** Language label from the text itself. */
const HINGLISH_MARKERS = new Set([
  'bhai', 'yaar', 'kya', 'hai', 'hain', 'nahi', 'nahin', 'mera', 'meri', 'tera', 'teri', 'aap', 'tum', 'main', 'mai',
  'ho', 'gaya', 'gayi', 'raha', 'rahi', 'rahe', 'toh', 'to', 'aur', 'ye', 'yeh', 'woh', 'vo', 'abhi', 'kaise', 'kyun',
  'kyu', 'accha', 'acha', 'chalo', 'arre', 'are', 'bhi', 'thoda', 'bahut', 'bohot', 'matlab', 'sab', 'kuch', 'phir',
  'fir', 'wala', 'wali', 'gaadi', 'dekh', 'dekho', 'chal', 'mat', 'lo', 'de', 'ka', 'ki', 'ke', 'ko', 'se', 'pe', 'par',
]);
export function detectLanguage(segments) {
  const text = (segments || []).map((s) => s.text).join(' ');
  const deva = (text.match(/[ऀ-ॿ]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  const letters = deva + latin;
  if (letters < 20) return { code: 'unknown', label: 'Unknown', devanagariRatio: 0, hinglishHits: 0 };
  const devanagariRatio = deva / letters;
  const words = text.toLowerCase().match(/[a-z']+/g) || [];
  const hits = words.filter((w) => HINGLISH_MARKERS.has(w)).length;
  const density = words.length ? hits / words.length : 0;
  let code;
  if (devanagariRatio > 0.7) code = 'hi';
  else if (devanagariRatio > 0.15) code = 'hinglish';
  else if (density > 0.18) code = 'hinglish';
  else code = 'en';
  const label = { hi: 'Hindi', hinglish: 'Hinglish', en: 'English', unknown: 'Unknown' }[code];
  return { code, label, devanagariRatio: Number(devanagariRatio.toFixed(3)), hinglishHits: hits };
}

export function toSRT(segments) {
  return segments
    .map((s, i) => `${i + 1}\n${fmtSrtTime(s.start)} --> ${fmtSrtTime(s.end)}\n${s.text}\n`)
    .join('\n');
}

export function toTXT(segments) {
  return segments.map((s) => `[${fmtTime(s.start)}] ${s.speaker ? s.speaker + ': ' : ''}${s.text}`).join('\n') + '\n';
}
