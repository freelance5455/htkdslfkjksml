// Creator assistant: titles, hook, description, hashtags, caption.
// Everything is built from the moment's own transcript text. No invented events.
import { categoryLabel } from './categories.js';
import { countHits } from './lexicon.js';
import { fmtTime } from './util.js';
import { shortLink } from './url.js';

const PROFANE = /(fuck|shit|chutiy|bhosd|madarch|behench|gaand|\blund\b|randi|harami|\bmc\b|\bbc\b|मादर|बहन\s?चो|चूतिया|भोसड़)/i;

/** A short, safe, non-profane quote from the peak line, or '' if none is suitable. */
export function pickQuote(text, max = 42) {
  const t = String(text || '').replace(/\[[^\]]*\]|\([^)]*\)/g, '').replace(/\s+/g, ' ').trim();
  if (!t || PROFANE.test(t)) return '';
  const words = t.split(' ');
  if (words.length < 2) return '';
  let q = '';
  for (const w of words) {
    if ((q + ' ' + w).trim().length > max) break;
    q = (q + ' ' + w).trim();
  }
  return q.replace(/[,;:\-–—]+$/, '').trim();
}

function actionNoun(words) {
  const w = words.join(' ');
  if (/police|cop|swat|पुलिस/.test(w)) return { hi: 'पुलिस वाला सीन', en: 'police wala scene' };
  if (/crash|टक्कर/.test(w)) return { hi: 'क्रैश', en: 'crash' };
  if (/blast|explo|boom|bomb|धमाका/.test(w)) return { hi: 'धमाका', en: 'blast' };
  if (/chase|bhaag|bhago|bhaago|भागो/.test(w)) return { hi: 'चेज़', en: 'chase' };
  if (/glitch|bug/.test(w)) return { hi: 'ग्लिच', en: 'glitch' };
  return { hi: 'एक्शन', en: 'action' };
}

function emotionTone(text) {
  if (countHits('emotion', text).words.some((w) => /bachao|dar|darr|help|बचाओ|डर/.test(w))) return 'fear';
  if (/(jeet|win|lets go|let's go|chicken dinner|zabardast|kamaal|shabash|जीत|कमाल|शाबाश)/i.test(text)) return 'celebrate';
  if (/(gussa|bakwas|tang|frustrat|गुस्सा|बकवास)/i.test(text)) return 'frustration';
  return 'reaction';
}

/**
 * @param moment  engine moment (needs start,end,category,peakText,excerpt,duration, peakOffset?)
 * @param ctx     { game, channel, videoTitle, videoId }
 */
export function suggestCreatorPack(moment, ctx = {}) {
  const game = (ctx.game || '').trim() || 'Game';
  const channel = (ctx.channel || '').trim();
  const q = pickQuote(moment.peakText);
  const text = `${moment.excerpt || ''} ${moment.peakText || ''}`;
  const cat = moment.category || 'funny';
  const an = actionNoun(countHits('action', text).words);
  const tone = emotionTone(text);

  const T = {
    funny: {
      hi: [`${game} में हुआ ये मज़ेदार पल 😂`, 'इस रिएक्शन पर हंसी आ ही जाएगी 😂', q ? `“${q}” 😂` : `${game} में ये पल देखिए 😂`],
      en: [`${game} mein ye kya ho gaya 😂`, 'Is reaction pe hasi aa hi jayegi 😂', q ? `“${q}” 😂` : `${game} ka ek funny moment 😂`],
    },
    surprise: {
      hi: [`${game} में अचानक ये क्या हुआ? 😱`, 'इसकी उम्मीद किसी को नहीं थी 😮', q ? `“${q}” 😱` : `${game} में ये देखकर चौंक गया 😮`],
      en: [`${game} mein achanak ye kya hua? 😱`, 'Iska andaza kisi ko nahi tha 😮', q ? `“${q}” 😱` : `${game} mein ye dekh ke shock lag gaya 😮`],
    },
    action: {
      hi: [`${game} में ${an.hi} 🔥`, `${an.hi} और ये रिएक्शन 🔥`, q ? `“${q}” 🔥` : `${game} का एक्शन पल 🎮`],
      en: [`${game} mein ${an.en} 🔥`, `${an.en} aur ye reaction 🔥`, q ? `“${q}” 🔥` : `${game} ka action moment 🎮`],
    },
    emotion: {
      hi: [`इस पल का रिएक्शन देखिए 🎮`, `${game} खेलते हुए ये रिएक्शन आ ही गया`, q ? `“${q}” 😤` : `${game} का भावुक पल 🎮`],
      en: [`Is moment ka reaction dekho 🎮`, `${game} khelte hue ye reaction aa hi gaya`, q ? `“${q}” 😤` : `${game} ka ${{ fear: 'dar wala', celebrate: 'celebration', frustration: 'gusse wala', reaction: 'reaction' }[tone]} moment 🎮`],
    },
    dialogue: {
      hi: [q ? `“${q}” 🗣️` : `${game} की ये लाइन 🗣️`, 'इस डायलॉग को सुनिए 🎧', `${game} स्ट्रीम की एक यादगार लाइन`],
      en: [q ? `“${q}” 🗣️` : `${game} ki ye line 🗣️`, 'Is dialogue ko suno 🎧', `${game} stream ki ek yaadgaar line`],
    },
    story: {
      hi: [`${game} में पूरा सीन एक ही क्लिप में 🎬`, 'शुरू से आख़िर तक ये पल देखिए 🎬', q ? `“${q}” 🎬` : `${game} का एक छोटा सा किस्सा 🎬`],
      en: [`${game} mein poora scene ek hi clip mein 🎬`, 'Shuru se end tak ye moment dekho 🎬', q ? `“${q}” 🎬` : `${game} ka ek chhota sa kissa 🎬`],
    },
  };
  const set = T[cat] || T.funny;
  // A quoted title keeps the real spoken words; add a Devanagari tag so every Hindi option reads as Hindi.
  const HI_TAG = { funny: 'मज़ेदार पल', surprise: 'चौंकाने वाला पल', action: 'एक्शन पल', emotion: 'रिएक्शन', dialogue: 'यादगार लाइन', story: 'पूरा सीन' };
  set.hi = set.hi.map((t) => (/[\u0900-\u097F]/.test(t) ? t : `${t} - ${HI_TAG[cat] || HI_TAG.funny}`));

  const peakOffset = moment.peakOffset ?? 0;
  const dur = Math.max(1, moment.end - moment.start);
  const latePeak = peakOffset / dur >= 0.4;
  const firstLine = moment.firstText || '';
  const hook = {
    startAt: moment.start,
    text: latePeak && (cat === 'funny' || cat === 'surprise')
      ? 'On-screen text idea: "Wait for the reaction 👀"'
      : firstLine
        ? `Open on the line: “${pickQuote(firstLine, 60) || firstLine.slice(0, 60)}”`
        : 'Open on the first line of the clip.',
  };

  const hashtags = [...new Set([
    '#Shorts', game !== 'Game' ? `#${game.replace(/\W+/g, '')}` : '#Gaming', '#GamingShorts', '#HindiGaming',
    cat === 'funny' ? '#Funny' : cat === 'action' ? '#GameAction' : cat === 'dialogue' ? '#Dialogue' : '#GamingMoments',
    ...(channel ? [`#${channel.replace(/\W+/g, '')}`] : []),
  ])].slice(0, 8);

  const label = categoryLabel(cat, moment.secondary);
  const link = ctx.videoId ? shortLink(ctx.videoId, moment.start) : '';
  const description = [
    `${label} moment${ctx.videoTitle ? ` from "${ctx.videoTitle}"` : ''} (${fmtTime(moment.start)} - ${fmtTime(moment.end)}).`,
    link ? `Full stream: ${link}` : '',
  ].filter(Boolean).join(' ');

  const caption = `${set.en[0]}${channel ? ` | ${channel}` : ''}`;

  return {
    titlesHindi: set.hi,
    titlesHinglish: set.en,
    description,
    hashtags,
    hook,
    caption,
  };
}

export const suggestTitle = (moment, ctx) => suggestCreatorPack(moment, ctx).titlesHinglish[0];
