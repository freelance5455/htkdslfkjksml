// Hindi / Hinglish / English lexicons used as ONE input among several signals.
// Romanised entries are matched on word boundaries; Devanagari entries by substring.
// Intensity words are only used to detect emotion - they are never copied into titles.

export const LEX = {
  laughter: [
    'haha', 'hahaha', 'hehe', 'lol', 'lmao', 'rofl', 'hasi', 'hans', 'hass', 'has has',
    'हाहा', 'हा हा', 'हहह', 'हंसी', 'हँसी', '😂', '🤣', '😆',
  ],
  funny: [
    'pagal', 'bewakoof', 'bakwas', 'mazak', 'mazaak', 'joke', 'comedy', 'funny', 'hasna', 'majedaar', 'mast',
    'khatarnak', 'bhai kya', 'kya logic', 'logic', 'nautanki', 'drama', 'ajeeb', 'weird', 'chutiya', 'chomu',
    'पागल', 'बकवास', 'मज़ाक', 'मजाक', 'मज़ेदार', 'अजीब',
  ],
  surprise: [
    'wow', 'omg', 'oh my god', 'oh shit', 'holy', 'no way', 'what the', 'wtf', 'seriously', 'sach mein', 'sachi',
    'kya', 'ye kya', 'yeh kya', 'ye kaise', 'kaise', 'kasam se', 'unbelievable', 'believe', 'arre', 'are yaar',
    'ye kya ho gaya', 'kya ho gaya', 'kya ho raha', 'ho kya raha', 'kahan se', 'kidhar se', 'achanak', 'suddenly',
    'अरे', 'क्या', 'ये क्या', 'यह क्या', 'कैसे', 'वाह', 'अचानक', 'ओह',
  ],
  action: [
    'police', 'cop', 'cops', 'chase', 'crash', 'blast', 'explode', 'explosion', 'boom', 'gaadi', 'gadi', 'car', 'bike',
    'truck', 'helicopter', 'tank', 'jet', 'fight', 'shoot', 'shooting', 'goli', 'sniper', 'rocket', 'bomb', 'swat',
    'army', 'wasted', 'busted', 'mission failed', 'wanted', 'star', 'bhaag', 'bhago', 'bhaago', 'jump', 'gir gaya',
    'gir gayi', 'mar gaya', 'mar gayi', 'maar', 'udaa', 'ud gaya', 'tod', 'heist', 'parachute', 'glitch', 'bug',
    'पुलिस', 'गाड़ी', 'गाडी', 'भागो', 'धमाका', 'गोली', 'मर गया', 'टक्कर', 'हेलीकॉप्टर',
  ],
  emotion: [
    'bachao', 'dar', 'darr', 'help', 'nahi nahi', 'ruko', 'ruk ja', 'gussa', 'bakwas', 'frustrat', 'tang', 'pareshan',
    'yaar', 'saala', 'sala', 'damn', 'shit', 'fuck', 'bhai', 'please', 'plz', 'lets go', "let's go", 'yes', 'yess',
    'jeet', 'jeet gaye', 'win', 'winner', 'chicken dinner', 'ho gaya', 'ho gya', 'zabardast', 'kamaal', 'shabash',
    'jhakaas', 'ek number', 'maza aa gaya', 'mazza', 'rona', 'dukh', 'bach gaya', 'bach gayi',
    'बचाओ', 'डर', 'गुस्सा', 'यार', 'जीत', 'ज़बरदस्त', 'कमाल', 'शाबाश', 'मज़ा आ गया', 'बच गया',
  ],
  narrative: [
    'pehle', 'phir', 'fir', 'tab', 'tabhi', 'uske baad', 'suno', 'ek baar', 'scene', 'matlab', 'dekho', 'isliye',
    'because', 'then', 'so', 'but', 'lekin', 'magar', 'par',
    'पहले', 'फिर', 'तब', 'सुनो', 'मतलब', 'देखो', 'लेकिन',
  ],
  game: [
    'gta', 'vice city', 'los santos', 'franklin', 'michael', 'trevor', 'cj', 'lucky', 'mission', 'cheat',
    'wanted level', 'online', 'lobby', 'npc', 'respawn',
  ],
  // Words that make a sentence "ordinary talk" (set-up) rather than a reaction.
  filler: ['umm', 'uh', 'matlab', 'basically', 'toh', 'ok', 'okay', 'accha', 'acha', 'haan', 'hmm'],
};

const isDeva = (s) => /[ऀ-ॿ]/.test(s) || /[\u{1F300}-\u{1FAFF}]/u.test(s);

const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function compile(list) {
  const latin = list.filter((w) => !isDeva(w)).map(escRe);
  const other = list.filter(isDeva);
  const latinRe = latin.length ? new RegExp(`(?<![a-z0-9])(?:${latin.join('|')})(?![a-z0-9])`, 'gi') : null;
  return { latinRe, other };
}

const COMPILED = Object.fromEntries(Object.entries(LEX).map(([k, v]) => [k, compile(v)]));

/** Count distinct lexicon matches of a category in text (case-insensitive). */
export function countHits(category, text) {
  const c = COMPILED[category];
  if (!c) return { count: 0, words: [] };
  const found = new Set();
  const lower = String(text || '').toLowerCase();
  if (c.latinRe) for (const m of lower.matchAll(c.latinRe)) found.add(m[0]);
  for (const w of c.other) if (lower.includes(w.toLowerCase())) found.add(w);
  return { count: found.size, words: [...found] };
}

// Laughter patterns that are not plain words ("hahaaa", "hehehe", "ahahaha", "[Laughter]").
export const LAUGH_RE = /(?<![a-z])(?:a?(?:ha){2,}h?a*|he(?:he)+|hah+a+h*|ah(?:ah)+a?h*)(?![a-z])|\[(?:laughter|laughing|हँसी|हंसी)\]|हा(?:हा)+|😂|🤣/i;
export const APPLAUSE_RE = /\[(?:applause|cheering|तालियां|तालियाँ)\]/i;
export const NOISE_ONLY_RE = /^\s*[[(♪♫].*[\])♪♫]\s*$/; // [Music], (noise), ♪ ... ♪
