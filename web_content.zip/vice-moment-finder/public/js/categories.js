// Moment categories (A-F from the spec).
export const CATEGORIES = {
  funny: { key: 'funny', code: 'A', label: 'Funny' },
  surprise: { key: 'surprise', code: 'B', label: 'Surprise' },
  action: { key: 'action', code: 'C', label: 'Gaming Action' },
  emotion: { key: 'emotion', code: 'D', label: 'Emotional Reaction' },
  dialogue: { key: 'dialogue', code: 'E', label: 'Viral Dialogue' },
  story: { key: 'story', code: 'F', label: 'Story Moment' },
};
export const CATEGORY_KEYS = Object.keys(CATEGORIES);
export const categoryLabel = (key, secondary) =>
  CATEGORIES[key] ? CATEGORIES[key].label + (secondary && CATEGORIES[secondary] ? ` / ${CATEGORIES[secondary].label}` : '') : 'Moment';
