// Clip presets, boundary editing, links and the (optional) local FFmpeg helper.
import { clamp, fmtTime } from './util.js';
import { embedUrl, shortLink, watchUrl } from './url.js';

/** Recommended durations (seconds). Recommendations, not hard limits. */
export const PRESETS = {
  short: { key: 'short', label: 'Short (15-25s)', min: 15, max: 25, preMax: 12, postMax: 7 },
  standard: { key: 'standard', label: 'Standard (25-40s)', min: 25, max: 40, preMax: 20, postMax: 10 },
  extended: { key: 'extended', label: 'Extended (40-60s)', min: 40, max: 60, preMax: 32, postMax: 14 },
};

export const getPreset = (key) => PRESETS[key] || PRESETS.standard;

/**
 * Manually adjust a moment's bounds. Clamped to [0, videoDuration]; end is always >= start + 1s.
 * Returns a new { start, end, duration }.
 */
export function adjustBounds({ start, end }, { startDelta = 0, endDelta = 0 } = {}, videoDuration = Infinity) {
  const max = Number.isFinite(videoDuration) && videoDuration > 0 ? videoDuration : Infinity;
  let s = clamp(start + startDelta, 0, max);
  let e = clamp(end + endDelta, 0, max);
  if (e < s + 1) {
    // Keep the start where the user put it and push the end to the 1-second minimum.
    e = Math.min(max, s + 1);
    if (e < s + 1) s = Math.max(0, e - 1);
  }
  return { start: s, end: e, duration: e - s };
}

export const durationLabel = (start, end) => `${Math.round(end - start)}s`;

export const timestampRange = (start, end) => `${fmtTime(start)} - ${fmtTime(end)}`;

/** Link helpers used by the UI. */
export const momentLink = (videoId, start) => shortLink(videoId, start);
export const momentWatchLink = (videoId, start) => watchUrl(videoId, start);
export const momentEmbed = (videoId, start, end) => embedUrl(videoId, start, end);

/** POSIX shell single-quote escaping. */
export const shq = (s) => `'${String(s).replace(/'/g, `'\\''`)}'`;

/**
 * FFmpeg command for a file the user OWNS / is authorised to use (a local file, never a YouTube download).
 * Re-encode mode is frame-accurate; copy mode is instant but cuts on keyframes.
 */
export function ffmpegCommand(inputName, start, end, { outName, mode = 'reencode' } = {}) {
  const s = Math.max(0, start);
  const dur = Math.max(1, end - start);
  const out = outName || `clip_${fmtTime(s).replace(/:/g, '-')}.mp4`;
  const t = (n) => Number(n.toFixed(3));
  if (mode === 'copy') {
    return `ffmpeg -ss ${t(s)} -i ${shq(inputName)} -t ${t(dur)} -c copy ${shq(out)}`;
  }
  return `ffmpeg -ss ${t(s)} -i ${shq(inputName)} -t ${t(dur)} -c:v libx264 -preset veryfast -crf 23 -c:a aac -b:a 128k ${shq(out)}`;
}

/**
 * Is clipping genuinely possible? Only when the user supplied a local media file AND confirmed
 * they have the right to use it. YouTube-only projects never qualify (we never download from YouTube).
 */
export function clipCapability({ hasLocalFile = false, ownershipConfirmed = false } = {}) {
  if (!hasLocalFile) {
    return {
      available: false,
      reason: 'Clipping is unavailable: this app does not download videos from YouTube. Attach your own local video file (one you own or are authorised to use) in Settings to get FFmpeg clip commands.',
    };
  }
  if (!ownershipConfirmed) {
    return { available: false, reason: 'Confirm that you own this file or are authorised to use it to enable clip commands.' };
  }
  return { available: true, reason: '' };
}

/** Plain instructions for using timestamps in an external editor. */
export function editorInstructions(videoId, start, end) {
  return [
    `1. Open the original video at ${shortLink(videoId, start)}.`,
    `2. The moment runs ${fmtTime(start)} to ${fmtTime(end)} (${Math.round(end - start)} seconds).`,
    '3. If you own the video, export your own source file and trim these exact timestamps in your editor (for example VN Editor).',
    '4. Do not re-upload other people\'s content without permission.',
  ].join('\n');
}
