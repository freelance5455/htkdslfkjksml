// OPTIONAL audio excitement analysis. Only runs on audio the user supplies (a local file).
// Audio can re-rank moments the transcript already found; it never creates a moment on its own.

/** Pure function: analyse mono samples. Returns one entry per window. */
export function analyzeSamples(samples, sampleRate, { windowSec = 1 } = {}) {
  const win = Math.max(1, Math.floor(sampleRate * windowSec));
  const out = [];
  for (let off = 0; off < samples.length; off += win) {
    const end = Math.min(samples.length, off + win);
    if (end - off < win / 2 && out.length) break; // ignore a tiny trailing sliver
    let sum = 0;
    let peak = 0;
    let zc = 0;
    let prev = samples[off];
    for (let i = off; i < end; i++) {
      const v = samples[i];
      sum += v * v;
      const a = Math.abs(v);
      if (a > peak) peak = a;
      if ((v >= 0) !== (prev >= 0)) zc++;
      prev = v;
    }
    const n = end - off;
    const rms = Math.sqrt(sum / n);
    out.push({
      t: off / sampleRate,
      rms,
      db: 20 * Math.log10(rms + 1e-9),
      peak,
      zcr: zc / n, // crude spectral proxy: informational only, never used alone
    });
  }
  return out;
}

const median = (a) => {
  if (!a.length) return 0;
  const s = [...a].sort((x, y) => x - y);
  return s[s.length >> 1];
};

/**
 * Excitement for a time range, relative to the surrounding loudness (so a loud game mix does not
 * make everything look exciting). Components: loudness jump over local median, sustained energy,
 * and peak crest. Returns { score:0..1, jumpDb, peakDb, loudnessOnly:true } or null if no data.
 */
export function audioForRange(windows, start, end, { contextSec = 60 } = {}) {
  if (!windows || !windows.length) return null;
  const inRange = windows.filter((w) => w.t >= start - 0.5 && w.t < end);
  if (!inRange.length) return null;
  const around = windows.filter((w) => w.t >= start - contextSec && w.t < end + contextSec);
  const baseDb = median(around.map((w) => w.db));
  const maxDb = Math.max(...inRange.map((w) => w.db));
  const jumpDb = maxDb - baseDb;
  const loudShare = inRange.filter((w) => w.db - baseDb > 4).length / inRange.length;
  const peakCrest = Math.max(...inRange.map((w) => w.peak));
  const jumpScore = Math.min(1, Math.max(0, (jumpDb - 3) / 12));
  const score = Math.min(1, 0.65 * jumpScore + 0.25 * Math.min(1, loudShare * 2) + 0.1 * (peakCrest > 0.5 ? 1 : 0));
  return {
    score: Number(score.toFixed(3)),
    jumpDb: Number(jumpDb.toFixed(1)),
    peakDb: Number(maxDb.toFixed(1)),
    // Loudness cannot tell shouting from laughter from an explosion in the game mix. Say so.
    note: 'Loudness only: cannot distinguish shouting, laughter or in-game sound.',
  };
}

/**
 * Browser: decode a user-supplied audio/video file to mono samples at a low sample rate.
 * Guarded by size because decodeAudioData holds the whole file in memory.
 */
export async function analyzeFile(file, { maxBytes = 300 * 1024 * 1024, sampleRate = 8000, windowSec = 1 } = {}) {
  if (!file) throw new Error('No file selected.');
  if (file.size > maxBytes) {
    throw new Error(`File is ${(file.size / 1048576).toFixed(0)} MB. Audio analysis is limited to ${(maxBytes / 1048576).toFixed(0)} MB on a phone; extract just the audio (m4a/mp3) or a shorter part first.`);
  }
  const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AC) throw new Error('This browser has no Web Audio support.');
  const ctx = new AC({ sampleRate });
  try {
    const buf = await ctx.decodeAudioData(await file.arrayBuffer());
    const ch = buf.numberOfChannels;
    const len = buf.length;
    const mono = new Float32Array(len);
    for (let c = 0; c < ch; c++) {
      const data = buf.getChannelData(c);
      for (let i = 0; i < len; i++) mono[i] += data[i] / ch;
    }
    return { windows: analyzeSamples(mono, buf.sampleRate, { windowSec }), duration: buf.duration };
  } catch (err) {
    throw new Error(`Could not decode audio from this file (${err?.message || 'unsupported format'}).`);
  } finally {
    ctx.close?.();
  }
}
