// Persistence: IndexedDB for projects, localStorage for settings + recent-video history.
import { uid } from './util.js';

const DB_NAME = 'vice-moment-finder';
const DB_VERSION = 1;
const STORE = 'projects';

export function openDb(idb = globalThis.indexedDB) {
  return new Promise((resolve, reject) => {
    if (!idb) { reject(new Error('IndexedDB is not available in this browser.')); return; }
    const req = idb.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Could not open the local database.'));
    req.onblocked = () => reject(new Error('The local database is blocked by another tab. Close other tabs of this app and retry.'));
  });
}

const tx = (db, mode, fn) => new Promise((resolve, reject) => {
  const t = db.transaction(STORE, mode);
  const store = t.objectStore(STORE);
  let result;
  Promise.resolve(fn(store)).then((r) => { result = r; }).catch(reject);
  t.oncomplete = () => resolve(result);
  t.onerror = () => reject(t.error || new Error('Database error.'));
  t.onabort = () => reject(t.error || new Error('Database transaction aborted.'));
});
const wrap = (req) => new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });

export function createProjectStore(idb = globalThis.indexedDB) {
  let dbPromise;
  const db = () => (dbPromise ||= openDb(idb));
  return {
    async save(project) {
      const d = await db();
      const rec = { ...project, updatedAt: Date.now() };
      await tx(d, 'readwrite', (s) => wrap(s.put(rec)));
      return rec;
    },
    async get(id) {
      const d = await db();
      return (await tx(d, 'readonly', (s) => wrap(s.get(id)))) || null;
    },
    async list() {
      const d = await db();
      const all = await tx(d, 'readonly', (s) => wrap(s.getAll()));
      return (all || []).sort((a, b) => b.updatedAt - a.updatedAt);
    },
    async remove(id) {
      const d = await db();
      await tx(d, 'readwrite', (s) => wrap(s.delete(id)));
    },
    async rename(id, name) {
      const cur = await this.get(id);
      if (!cur) throw new Error('Project not found.');
      return this.save({ ...cur, name: String(name).trim() || cur.name });
    },
    async clear() {
      const d = await db();
      await tx(d, 'readwrite', (s) => wrap(s.clear()));
    },
  };
}

/** Project record. `savedMoments` holds snapshots so saved moments survive re-analysis. */
export function newProject({ name, url = '', videoId = '', meta = {}, transcript, analysis }) {
  const now = Date.now();
  return {
    id: uid('prj'),
    name: name || meta.title || (videoId ? `Video ${videoId}` : 'Pasted transcript'),
    createdAt: now,
    updatedAt: now,
    url, videoId, meta,
    transcript, // { segments, source, track, language, format }
    analysis, // { moments, stats, options, analysedAt }
    savedMoments: [],
    edits: {}, // momentId -> { start, end }
    creator: {}, // momentId -> creator pack
  };
}

export function exportProjectJSON(project) {
  return JSON.stringify({ app: 'VICE MOMENT FINDER', exportedAt: new Date().toISOString(), project }, null, 2);
}

/* ---------- settings (localStorage) ---------- */
export const DEFAULT_SETTINGS = {
  backendUrl: '',
  language: 'auto',
  game: 'GTA',
  channel: 'VICE CLIPS',
  preset: 'standard',
  maxMoments: 20,
  minScore: 35,
  ownerToken: '',
};

export function createSettings(storage = globalThis.localStorage) {
  const KEY = 'vmf.settings';
  const read = () => {
    try { return { ...DEFAULT_SETTINGS, ...JSON.parse(storage?.getItem(KEY) || '{}') }; } catch { return { ...DEFAULT_SETTINGS }; }
  };
  return {
    all: read,
    get: (k) => read()[k],
    set(patch) {
      const next = { ...read(), ...patch };
      try { storage?.setItem(KEY, JSON.stringify(next)); } catch { /* storage full/blocked: keep running */ }
      return next;
    },
    reset() { try { storage?.removeItem(KEY); } catch { /* ignore */ } },
  };
}

/* ---------- recent videos (localStorage) ---------- */
export function createHistory(storage = globalThis.localStorage, max = 50) {
  const KEY = 'vmf.history';
  const read = () => { try { return JSON.parse(storage?.getItem(KEY) || '[]'); } catch { return []; } };
  return {
    list: read,
    add(entry) {
      const rest = read().filter((h) => h.videoId !== entry.videoId || !entry.videoId);
      const next = [{ ...entry, at: Date.now() }, ...rest].slice(0, max);
      try { storage?.setItem(KEY, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    },
    clear() { try { storage?.removeItem(KEY); } catch { /* ignore */ } },
  };
}
