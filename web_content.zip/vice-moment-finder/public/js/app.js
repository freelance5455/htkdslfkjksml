// VICE MOMENT FINDER - UI controller.
import { analyzeTranscript } from './engine.js';
import { analyzeFile } from './audio.js';
import { CATEGORIES, CATEGORY_KEYS } from './categories.js';
import { PRESETS, adjustBounds, clipCapability, editorInstructions, ffmpegCommand, momentEmbed, momentLink, timestampRange } from './clip.js';
import { suggestCreatorPack } from './creator.js';
import { createHistory, createProjectStore, createSettings, exportProjectJSON, newProject } from './store.js';
import { detectLanguage, parseTranscript, toSRT, toTXT } from './transcript.js';
import { askConfirm, askText, copyText, downloadText, readFileText, toast } from './ui.js';
import { escapeHtml as esc, fmtTime, parseTimestamp } from './util.js';
import { parseYouTubeUrl, thumbnailUrl, watchUrl } from './url.js';

const settings = createSettings();
const history = createHistory();
const store = createProjectStore();
const view = document.getElementById('view');

const state = {
  tab: 'home', mode: 'input', url: '', steps: null, failure: null, notice: null, busy: false,
  project: null, dashTab: 'moments', filter: 'all', sort: 'score', open: {},
  tvQuery: '', tvPage: 0, local: { file: null, confirmed: false }, audioWindows: null, audioStatus: '',
  projects: null, installEvt: null, backendStatus: '',
};

const TV_PAGE = 150;
const pad2 = (n) => String(n).padStart(2, '0');

/* ---------------- helpers ---------------- */
const backend = () => (settings.get('backendUrl') || '').trim().replace(/\/+$/, '');
const ctx = () => ({ game: settings.get('game'), channel: settings.get('channel'), videoTitle: state.project?.meta?.title || state.project?.name || '', videoId: state.project?.videoId || '' });
const engineOptions = () => ({
  preset: settings.get('preset'), maxMoments: Number(settings.get('maxMoments')) || 20, minScore: Number(settings.get('minScore')) || 35,
  audio: state.audioWindows || undefined,
});

async function fetchJson(path, headers = {}) {
  const res = await fetch(`${backend()}${path}`, { headers, signal: AbortSignal.timeout(45000) });
  let body;
  try { body = await res.json(); } catch { throw new Error(`The server answered with HTTP ${res.status} but not valid data.`); }
  return body;
}

const effective = (p, m) => {
  const e = p.edits?.[m.id];
  const start = e ? e.start : m.start;
  const end = e ? e.end : m.end;
  return { ...m, start, end, duration: end - start, edited: Boolean(e) };
};
const momentsOf = (p) => (p?.analysis?.moments || []).map((m) => effective(p, m));
const persist = async () => {
  if (!state.project) return;
  try { state.project = await store.save(state.project); } catch (err) { toast(`Could not save locally: ${err.message}`, 4000); }
};

function setStep(i, status, detail = '') {
  if (!state.steps) return;
  state.steps[i] = { ...state.steps[i], status, detail };
  if (state.tab === 'home' && state.mode === 'input') renderSteps();
}
const mkSteps = () => ['Check the link', 'Video info', 'Transcript', 'Find moments', 'Save project'].map((label) => ({ label, status: 'pending', detail: '' }));

/* ---------------- analysis flow ---------------- */
async function startAnalysis() {
  if (state.busy) return;
  const parsed = parseYouTubeUrl(state.url);
  state.notice = null;
  if (!parsed.ok) {
    state.steps = null;
    state.failure = { error: { code: parsed.code, message: parsed.message, hint: 'Example: https://youtu.be/XXXXXXXXXXX or https://www.youtube.com/watch?v=XXXXXXXXXXX' }, videoId: null, retry: false };
    render();
    return;
  }
  state.busy = true;
  state.failure = null;
  state.steps = mkSteps();
  setStep(0, 'done', `Video ID ${parsed.id}`);
  setStep(1, 'running');
  setStep(2, 'running');
  render();

  if (navigator.onLine === false) {
    setStep(1, 'skipped', 'Offline');
    setStep(2, 'failed', 'You are offline');
    state.failure = { error: { code: 'OFFLINE', message: 'You are offline, so the transcript cannot be fetched automatically.', hint: 'Saved projects still open offline. You can also paste or import a transcript below.' }, videoId: parsed.id, url: parsed.url, retry: true };
    state.busy = false;
    render();
    return;
  }

  const token = settings.get('ownerToken');
  const headers = token ? { 'x-yt-access-token': token } : {};
  const metaP = fetchJson(`/api/meta?v=${parsed.id}`).then((j) => {
    if (j.ok) { setStep(1, 'done', j.meta.title || 'Found'); return j.meta; }
    setStep(1, 'skipped', j.error?.message || 'Not available');
    return null;
  }).catch(() => { setStep(1, 'skipped', 'Could not reach backend'); return null; });

  let tr;
  try {
    tr = await fetchJson(`/api/transcript?v=${parsed.id}&lang=${encodeURIComponent(settings.get('language'))}`, headers);
  } catch (err) {
    tr = { ok: false, error: { code: 'BACKEND_UNREACHABLE', message: `Could not reach the transcript service${backend() ? ` at ${backend()}` : ' on this site'} (${err.message}).`, hint: 'If this app is on static hosting, set "Backend URL" in Settings. Otherwise paste/import the transcript below.' } };
  }
  const oembed = await metaP;
  if (!tr.ok) {
    setStep(2, 'failed', tr.error?.message || 'Failed');
    const meta = { ...(oembed || {}), ...(tr.meta || {}) };
    state.failure = { error: tr.error, videoId: parsed.id, url: parsed.url, meta, retry: true, tried: tr.tried };
    state.busy = false;
    render();
    return;
  }
  setStep(2, 'done', `${tr.segments.length} lines, ${tr.track?.lang || '?'}${tr.track?.kind === 'asr' ? ' (auto-generated)' : ''}`);
  const meta = { ...(oembed || {}), ...(tr.meta || {}) };
  await finishProject({
    parsed, meta, segments: tr.segments,
    transcript: { source: tr.source, track: tr.track, availableTracks: tr.availableTracks, format: 'captions' },
  });
}

async function finishProject({ parsed, meta, segments, transcript, name }) {
  state.steps ||= mkSteps();
  setStep(3, 'running');
  const language = detectLanguage(segments);
  const videoId = parsed?.id || '';
  const fakeProject = { meta, name, videoId };
  state.project = fakeProject; // ctx() reads title/id
  const analysis = { ...analyzeTranscript(segments, engineOptions(), ctx()), options: { ...engineOptions(), audio: undefined }, analysedAt: Date.now() };
  setStep(3, 'done', `${analysis.moments.length} moment${analysis.moments.length === 1 ? '' : 's'}`);
  setStep(4, 'running');
  const project = newProject({
    name, url: parsed?.url || '', videoId, meta: meta || {},
    transcript: { ...transcript, segments, language },
    analysis,
  });
  state.project = project;
  project.creator = Object.fromEntries(analysis.moments.map((m) => [m.id, suggestCreatorPack(m, ctx())]));
  try {
    state.project = await store.save(project);
    setStep(4, 'done', 'Saved on this device');
  } catch (err) {
    setStep(4, 'failed', `Not saved: ${err.message}`);
    toast('Moments found, but saving on this device failed.', 4000);
  }
  history.add({ videoId, url: project.url, title: project.name });
  state.busy = false;
  state.failure = null;
  state.mode = 'dashboard';
  state.dashTab = 'moments';
  state.filter = 'all';
  state.open = {};
  state.tvPage = 0;
  state.tvQuery = '';
  render();
}

async function analyseText(text, sourceLabel, fileName) {
  const { segments, format, warnings } = parseTranscript(text);
  if (!segments.length) {
    state.notice = { kind: 'err', text: warnings[0] || 'No transcript lines were found.' };
    render();
    return;
  }
  const parsed = parseYouTubeUrl(state.url);
  const vid = parsed.ok ? parsed : (state.failure?.videoId ? { id: state.failure.videoId, url: state.failure.url } : null);
  const meta = state.failure?.meta || {};
  const name = meta.title || (fileName ? fileName.replace(/\.[^.]+$/, '') : (vid ? `Video ${vid.id}` : 'Pasted transcript'));
  state.busy = true;
  state.notice = null;
  state.steps = mkSteps();
  setStep(0, vid ? 'done' : 'skipped', vid ? `Video ID ${vid.id}` : 'No video link (timestamps will not link to YouTube)');
  setStep(1, 'skipped', 'Not needed');
  setStep(2, 'done', `${segments.length} lines imported (${format.toUpperCase()})`);
  await finishProject({ parsed: vid, meta, segments, name, transcript: { source: sourceLabel, format, track: null } });
}

async function reanalyse() {
  const p = state.project;
  if (!p) return;
  const analysis = { ...analyzeTranscript(p.transcript.segments, engineOptions(), ctx()), options: { ...engineOptions(), audio: undefined }, analysedAt: Date.now() };
  const keepEdits = {};
  for (const m of analysis.moments) if (p.edits?.[m.id]) keepEdits[m.id] = p.edits[m.id];
  p.analysis = analysis;
  p.edits = keepEdits;
  p.creator = Object.fromEntries(analysis.moments.map((m) => [m.id, suggestCreatorPack(effective(p, m), ctx())]));
  await persist();
  state.open = {};
  toast(`Re-analysed: ${analysis.moments.length} moments`);
  render();
}

/* ---------------- rendering ---------------- */
function render() {
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === state.tab));
  const fn = { home: renderHome, projects: renderProjects, history: renderHistory, settings: renderSettings }[state.tab];
  fn();
}

const statusDot = (s) => `<span class="dot ${s}" aria-hidden="true"></span>`;
function stepsHtml() {
  if (!state.steps) return '';
  return `<ol class="steps">${state.steps.map((s) => `<li>${statusDot(s.status)}<div><b>${esc(s.label)}</b>${s.detail ? `<div class="muted small">${esc(s.detail)}</div>` : ''}</div></li>`).join('')}</ol>`;
}
function renderSteps() {
  const el = document.getElementById('steps');
  if (el) el.innerHTML = stepsHtml();
}

function renderHome() {
  if (state.mode === 'dashboard' && state.project?.analysis) return renderDashboard();
  const parsed = state.url ? parseYouTubeUrl(state.url) : null;
  const f = state.failure;
  view.innerHTML = `
  <section class="card">
    <h2>Paste a YouTube link</h2>
    <label class="field" for="url">Video, live replay or Shorts link</label>
    <input id="url" type="url" inputmode="url" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="https://youtu.be/..." value="${esc(state.url)}">
    <div class="row" style="margin-top:10px">
      <button class="btn small" data-act="paste">Paste</button>
      <button class="btn small" data-act="clear">Clear</button>
      <span class="grow"></span>
      <button class="btn primary" data-act="analyse" ${state.busy ? 'disabled' : ''}>Analyse video</button>
    </div>
    <div id="preview">${previewHtml(parsed)}</div>
  </section>
  <div id="steps-wrap">${state.steps ? `<section class="card"><h2>Progress</h2><div id="steps">${stepsHtml()}</div></section>` : ''}</div>
  ${state.notice ? `<div class="alert ${state.notice.kind === 'err' ? 'err' : 'warn'}">${esc(state.notice.text)}</div>` : ''}
  ${f ? failureHtml(f) : ''}
  <section class="card">
    <details ${f ? 'open' : ''}>
      <summary>Already have a transcript? Paste it or import a file</summary>
      <p class="muted small">Works without the internet backend. Formats: SRT, VTT, or plain lines like <code>00:03:12 text</code> / <code>[3:12] text</code>.</p>
      <div class="row">
        <label class="btn cyan filebtn">Choose transcript file<input id="tfile" type="file"></label>
      </div>
      <label class="field" for="tpaste">Or paste the transcript</label>
      <textarea id="tpaste" placeholder="00:00:03 - 00:00:06&#10;Bhai main police ki gaadi le raha hoon.&#10;&#10;00:00:06 - 00:00:10&#10;Ye kya glitch ho gaya?"></textarea>
      <div class="row" style="margin-top:10px"><button class="btn primary" data-act="analyse-paste" ${state.busy ? 'disabled' : ''}>Analyse pasted transcript</button></div>
    </details>
  </section>`;
}

function previewHtml(parsed) {
  if (!parsed) return '';
  if (!parsed.ok) return `<p class="alert err" style="margin-top:10px">${esc(parsed.message)}</p>`;
  return `<div style="margin-top:12px"><img class="thumb" src="${thumbnailUrl(parsed.id)}" alt="Video thumbnail" loading="lazy">
    <p class="muted small" style="margin:6px 0 0">Video ID <b>${esc(parsed.id)}</b>${parsed.startSeconds ? ` - link starts at ${fmtTime(parsed.startSeconds)}` : ''}</p></div>`;
}

function failureHtml(f) {
  const e = f.error || {};
  return `<section class="alert err">
    <b>${esc(f.videoId ? 'Transcript could not be retrieved automatically' : 'That link will not work')}</b>
    <div style="margin-top:6px">${esc(e.message || 'Unknown problem.')}</div>
    ${e.hint ? `<div class="muted small" style="margin-top:6px">${esc(e.hint)}</div>` : ''}
    ${f.tried?.length ? `<details><summary>Technical details</summary>${f.tried.map((t) => `<div class="small">${esc(t.source)}: ${esc(t.code)} - ${esc(t.message)}</div>`).join('')}</details>` : ''}
    ${f.videoId ? `<div class="actions">
      ${f.retry ? '<button class="btn small" data-act="analyse">Retry</button>' : ''}
      <a class="btn small" href="${watchUrl(f.videoId)}" target="_blank" rel="noopener">Open video on YouTube</a>
    </div>
    <details><summary>How to copy YouTube's own transcript</summary>
      <ol class="small"><li>Open the video on YouTube (button above).</li><li>Tap the description, then "Show transcript" (if the video has one).</li><li>Select the lines, copy, and paste them into the box below.</li></ol>
      <p class="small muted">Some videos have no transcript at all. Then no tool can fabricate one honestly: use a caption file or your own subtitles.</p></details>` : ''}
  </section>`;
}

/* ---------- dashboard ---------- */
function renderDashboard() {
  const p = state.project;
  const ms = momentsOf(p);
  const stats = p.analysis.stats || {};
  const tr = p.transcript;
  const src = { 'public-captions': 'Retrieved automatically (public YouTube captions)', 'owner-api': 'Retrieved automatically (official API, your own video)' }[tr.source] || `Imported manually (${tr.source})`;
  const m = p.meta || {};
  const cap = clipCapability({ hasLocalFile: Boolean(state.local.file), ownershipConfirmed: state.local.confirmed });
  const counts = Object.fromEntries(CATEGORY_KEYS.map((k) => [k, ms.filter((x) => x.category === k).length]));

  view.innerHTML = `
  <div class="row" style="margin-bottom:10px">
    <button class="btn small" data-act="newvideo">&larr; New video</button>
    <span class="grow"></span>
    <button class="btn small" data-act="rename-current">Rename</button>
  </div>
  <section class="card">
    ${p.videoId ? `<img class="thumb" src="${esc(m.thumbnail || thumbnailUrl(p.videoId))}" alt="" loading="lazy">` : ''}
    <h2 style="margin-top:10px">${esc(p.name)}</h2>
    <div class="muted small">${[m.channel, m.durationSec ? `Length ${fmtTime(m.durationSec)}` : (stats.durationSec ? `Transcript covers ${fmtTime(stats.durationSec)}` : '')].filter(Boolean).map(esc).join(' - ')}</div>
    ${p.videoId ? `<div class="actions"><a class="btn small cyan" href="${watchUrl(p.videoId)}" target="_blank" rel="noopener">Open on YouTube</a></div>` : '<p class="muted small">No video link attached, so timestamps cannot open YouTube.</p>'}
  </section>
  <section class="card">
    <h3 style="margin-top:0">TRANSCRIPT STATUS</h3>
    <div class="alert ok" style="margin:0">${esc(src)}</div>
    <p class="muted small" style="margin:8px 0 0">${tr.segments.length} lines - language: ${esc(tr.language?.label || 'Unknown')}${tr.track ? ` - track ${esc(tr.track.lang)}${tr.track.kind === 'asr' ? ' (auto-generated, may contain mistakes)' : ''}` : ''}</p>
  </section>
  <section class="card">
    <h3 style="margin-top:0">ANALYSIS</h3>
    <p class="small" style="margin:0"><b>${ms.length}</b> moment${ms.length === 1 ? '' : 's'} - preset ${esc((PRESETS[stats.preset] || PRESETS.standard).label)} - ${stats.audioUsed ? 'with audio loudness' : 'transcript only'}</p>
    ${(stats.notes || []).map((n) => `<p class="muted small" style="margin:6px 0 0">${esc(n)}</p>`).join('')}
    <p class="muted small" style="margin:8px 0 0">Scores rank moments within this transcript. They do not predict YouTube views.</p>
    <div class="actions"><button class="btn small" data-act="reanalyse">Re-analyse with current settings</button></div>
  </section>
  <div class="filters" role="tablist">
    ${[['moments', `Moments (${ms.length})`], ['transcript', 'Transcript'], ['saved', `Saved (${p.savedMoments?.length || 0})`], ['export', 'Export']].map(([k, l]) => `<button class="chip ${state.dashTab === k ? 'on' : ''}" data-act="dtab" data-k="${k}">${l}</button>`).join('')}
  </div>
  ${state.dashTab === 'moments' ? momentsHtml(p, ms, counts, cap) : ''}
  ${state.dashTab === 'transcript' ? transcriptHtml(p, ms) : ''}
  ${state.dashTab === 'saved' ? savedHtml(p) : ''}
  ${state.dashTab === 'export' ? exportHtml(p, ms, cap) : ''}`;
  if (state.dashTab === 'transcript') renderTranscriptList();
}

function momentsHtml(p, ms, counts, cap) {
  let list = ms.filter((x) => state.filter === 'all' || x.category === state.filter || x.secondary === state.filter);
  list = list.slice().sort(state.sort === 'time' ? (a, b) => a.start - b.start : (a, b) => b.score - a.score);
  const filters = `<div class="filters">
    <button class="chip ${state.filter === 'all' ? 'on' : ''}" data-act="filter" data-k="all">All (${ms.length})</button>
    ${CATEGORY_KEYS.filter((k) => counts[k]).map((k) => `<button class="chip ${state.filter === k ? 'on' : ''}" data-act="filter" data-k="${k}">${esc(CATEGORIES[k].label)} (${counts[k]})</button>`).join('')}
    <span class="chip" style="margin-left:auto">Sort:</span>
    <button class="chip ${state.sort === 'score' ? 'on' : ''}" data-act="sort" data-k="score">Score</button>
    <button class="chip ${state.sort === 'time' ? 'on' : ''}" data-act="sort" data-k="time">Time</button>
  </div>`;
  if (!ms.length) return `${filters}<div class="alert warn">No moments passed the minimum score. Lower "Minimum score" in Settings and re-analyse, or check the transcript. The app does not invent moments.</div>`;
  const note = !cap.available ? `<p class="muted small">${esc(cap.reason)}</p>` : '';
  return `${filters}${list.map((m) => momentCard(p, m, cap)).join('')}${note}`;
}

const BD_LABELS = [['humor', 'Humor'], ['surprise', 'Surprise'], ['emotion', 'Emotion'], ['dialogue', 'Dialogue'], ['context', 'Context'], ['independence', 'Standalone'], ['hook', 'Hook'], ['audio', 'Audio']];

function momentCard(p, m, cap) {
  const id = esc(m.id);
  const saved = (p.savedMoments || []).some((s) => s.id === m.id);
  const o = state.open[m.id] || {};
  const vid = p.videoId;
  const pack = p.creator?.[m.id];
  const ranges = `${fmtTime(m.start)} - ${fmtTime(m.end)}`;
  return `<article class="card moment" data-id="${id}">
    <div class="head"><h3>MOMENT #${pad2(m.rank)}</h3><span class="score" title="Internal ranking score, not a view prediction">${m.score}/100</span></div>
    <div class="row" style="margin-top:6px"><span class="chip">${esc(m.categoryLabel)}</span>${m.edited ? '<span class="chip on">edited</span>' : ''}</div>
    <div class="times"><span>Start <b>${fmtTime(m.start)}</b></span><span>End <b>${fmtTime(m.end)}</b></span><span><b>${Math.round(m.duration)}</b> seconds</span></div>
    <div class="quote">&ldquo;${esc(m.excerpt)}&rdquo;</div>
    <div class="muted small"><b>Why:</b> ${esc(m.reason)}</div>
    <div class="title-sugg">&#127916; ${esc(pack?.titlesHinglish?.[0] || m.title)}</div>
    <div class="actions">
      ${vid ? `<a class="btn small cyan" href="${momentLink(vid, m.start)}" target="_blank" rel="noopener">Preview on YouTube</a>
      <button class="btn small" data-act="inapp" data-id="${id}">${o.inapp ? 'Hide player' : 'Play here'}</button>` : ''}
      <button class="btn small" data-act="edit" data-id="${id}">Edit timestamps</button>
      <button class="btn small ${saved ? 'primary' : ''}" data-act="save" data-id="${id}">${saved ? '&#9733; Saved' : '&#9734; Save moment'}</button>
      <button class="btn small" data-act="copyts" data-id="${id}">Copy timestamps</button>
      <button class="btn small" data-act="creator" data-id="${id}">Creator ideas</button>
      ${cap.available ? `<button class="btn small" data-act="ffmpeg" data-id="${id}">Clip command</button>` : ''}
    </div>
    ${o.inapp && vid ? `<iframe class="preview" src="${momentEmbed(vid, m.start, m.end)}" title="Moment preview" allow="encrypted-media; picture-in-picture" allowfullscreen loading="lazy"></iframe>` : ''}
    ${o.edit ? editPanel(m) : ''}
    ${o.creator ? creatorPanel(p, m) : ''}
    ${o.ffmpeg && cap.available ? ffmpegPanel(m) : ''}
    <details><summary>Score breakdown</summary>
      ${BD_LABELS.map(([k, l]) => { const v = m.breakdown?.[k]; return `<div class="bd"><span>${l}</span><div class="bar"><i style="width:${v == null ? 0 : Math.round(v * 100)}%"></i></div><span>${v == null ? 'n/a' : Math.round(v * 100)}</span></div>`; }).join('')}
      <p class="muted small">Weights: humor 22, surprise 16, emotion 16, dialogue 12, context 12, standalone 8, hook 8, audio 6 (audio is left out when no audio was analysed).</p>
      <p class="muted small">Window ${esc(ranges)}. Copy-ready: <code>${esc(timestampRange(m.start, m.end))}</code></p>
    </details>
  </article>`;
}

function editPanel(m) {
  const id = esc(m.id);
  const nudges = (which) => [-5, -1, 1, 5].map((d) => `<button class="btn small" data-act="nudge" data-id="${id}" data-which="${which}" data-d="${d}">${d > 0 ? '+' : ''}${d}s</button>`).join('');
  return `<div class="panel">
    <label class="field">Start (hh:mm:ss)</label>
    <div class="row"><input type="text" style="max-width:130px" data-act="settime" data-id="${id}" data-which="start" value="${fmtTime(m.start)}" inputmode="numeric" aria-label="Start time">${nudges('start')}</div>
    <label class="field">End (hh:mm:ss)</label>
    <div class="row"><input type="text" style="max-width:130px" data-act="settime" data-id="${id}" data-which="end" value="${fmtTime(m.end)}" inputmode="numeric" aria-label="End time">${nudges('end')}</div>
    <p class="muted small">Duration ${Math.round(m.duration)}s. Recommended: Short 15-25s, Standard 25-40s, Extended 40-60s. These are suggestions, not limits.</p>
    <button class="btn small" data-act="resetedit" data-id="${id}">Reset to detected times</button>
  </div>`;
}

function creatorPanel(p, m) {
  const pack = p.creator?.[m.id] || suggestCreatorPack(m, ctx());
  const id = esc(m.id);
  const line = (txt, k) => `<div class="row" style="margin:6px 0"><span class="grow">${esc(txt)}</span><button class="btn small" data-act="copycreator" data-id="${id}" data-k="${k}">Copy</button></div>`;
  return `<div class="panel">
    <b>Hindi titles</b>${pack.titlesHindi.map((t, i) => line(t, `hi${i}`)).join('')}
    <b>Hinglish titles</b>${pack.titlesHinglish.map((t, i) => line(t, `en${i}`)).join('')}
    <b>Opening hook</b>${line(pack.hook.text, 'hook')}
    <b>Description</b>${line(pack.description, 'desc')}
    <b>Caption</b>${line(pack.caption, 'caption')}
    <b>Hashtags</b>${line(pack.hashtags.join(' '), 'tags')}
    <p class="muted small">Titles are built from the actual line in the clip. Check them before posting: they never claim events the transcript does not show.</p>
  </div>`;
}

function ffmpegPanel(m) {
  const name = state.local.file?.name || 'input.mp4';
  return `<div class="panel"><b>FFmpeg (for your own file: ${esc(name)})</b>
    <pre class="cmd">${esc(ffmpegCommand(name, m.start, m.end))}</pre>
    <button class="btn small" data-act="copyffmpeg" data-id="${esc(m.id)}">Copy command</button>
    <p class="muted small">Run it in Termux or on a computer with FFmpeg. This app never downloads from YouTube.</p></div>`;
}

/* ---------- transcript tab ---------- */
function transcriptHtml(p, ms) {
  return `<section class="card">
    <label class="field" for="tvq">Search transcript</label>
    <input id="tvq" type="search" placeholder="Search words..." value="${esc(state.tvQuery)}">
    <div class="row" style="margin-top:8px"><span class="muted small grow" id="tvinfo"></span>
      <button class="btn small" data-act="tvprev">Prev</button><button class="btn small" data-act="tvnext">Next</button></div>
    <p class="muted small">Pink rows belong to a detected moment. Tap a time to open YouTube there. Tap Edit to fix a line, then Re-analyse.</p>
    <button class="btn small" data-act="reanalyse">Re-analyse</button>
  </section><div class="card" id="tvlist" style="padding:4px"></div>`;
}

function renderTranscriptList() {
  const p = state.project;
  const el = document.getElementById('tvlist');
  if (!el || !p) return;
  const ms = momentsOf(p).sort((a, b) => a.start - b.start);
  const q = state.tvQuery.trim().toLowerCase();
  const all = p.transcript.segments.map((s, i) => ({ s, i }));
  const rows = q ? all.filter(({ s }) => s.text.toLowerCase().includes(q)) : all;
  const pages = Math.max(1, Math.ceil(rows.length / TV_PAGE));
  state.tvPage = Math.min(Math.max(0, state.tvPage), pages - 1);
  const slice = rows.slice(state.tvPage * TV_PAGE, (state.tvPage + 1) * TV_PAGE);
  const info = document.getElementById('tvinfo');
  if (info) info.textContent = `${rows.length} line${rows.length === 1 ? '' : 's'} - page ${state.tvPage + 1}/${pages}`;
  const hl = (t) => {
    const safe = esc(t);
    if (!q) return safe;
    const re = new RegExp(esc(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    return safe.replace(re, (m) => `<mark>${m}</mark>`);
  };
  el.innerHTML = slice.length ? slice.map(({ s, i }) => {
    const m = ms.find((x) => s.start >= x.start - 0.01 && s.start < x.end);
    const link = p.videoId ? `<a class="ts" href="${momentLink(p.videoId, s.start)}" target="_blank" rel="noopener">${fmtTime(s.start)}</a>` : `<span class="ts">${fmtTime(s.start)}</span>`;
    return `<div class="seg ${m ? 'in' : ''}">${link}<div class="tx">${hl(s.text)}${m ? ` <span class="badge">moment #${pad2(m.rank)}</span>` : ''}</div><button class="btn small" data-act="editseg" data-i="${i}" aria-label="Edit line">Edit</button></div>`;
  }).join('') : '<p class="muted" style="padding:12px">No matching lines.</p>';
}

/* ---------- saved / export ---------- */
function savedHtml(p) {
  const list = p.savedMoments || [];
  if (!list.length) return '<div class="card muted">No saved moments yet. Tap &#9734; Save moment on any card.</div>';
  return list.map((s) => `<article class="card"><b>${esc(s.title || 'Moment')}</b>
    <div class="times"><span>${fmtTime(s.start)} - ${fmtTime(s.end)}</span><span>${Math.round(s.end - s.start)}s</span><span>${esc(s.categoryLabel || '')}</span></div>
    <div class="quote">&ldquo;${esc(s.excerpt || '')}&rdquo;</div>
    <div class="actions">${p.videoId ? `<a class="btn small cyan" href="${momentLink(p.videoId, s.start)}" target="_blank" rel="noopener">Open on YouTube</a>` : ''}
    <button class="btn small" data-act="copysaved" data-id="${esc(s.id)}">Copy timestamps</button>
    <button class="btn small danger" data-act="unsave" data-id="${esc(s.id)}">Remove</button></div></article>`).join('');
}

function exportHtml(p, ms, cap) {
  return `<section class="card">
    <div class="actions" style="margin-top:0">
      <button class="btn" data-act="copyall">Copy all timestamps</button>
      <button class="btn" data-act="dl-ts">Download timestamps (.txt)</button>
      <button class="btn" data-act="dl-json">Analysis (.json)</button>
      <button class="btn" data-act="dl-txt">Transcript (.txt)</button>
      <button class="btn" data-act="dl-srt">Transcript (.srt)</button>
    </div>
    ${!cap.available ? `<p class="muted small" style="margin-top:12px">${esc(cap.reason)}</p>
    <details><summary>Using the timestamps in an external editor</summary><pre class="cmd">${esc(ms[0] ? editorInstructions(p.videoId || 'VIDEO_ID', ms[0].start, ms[0].end) : 'Run an analysis first.')}</pre></details>` : '<p class="muted small" style="margin-top:12px">Clip commands are enabled for your attached file. Use "Clip command" on a moment card.</p>'}
  </section>`;
}

const timestampLines = (p) => momentsOf(p).sort((a, b) => a.start - b.start)
  .map((m) => `#${pad2(m.rank)}  ${fmtTime(m.start)} - ${fmtTime(m.end)}  (${Math.round(m.duration)}s)  [${m.categoryLabel}]  ${m.score}/100  ${p.creator?.[m.id]?.titlesHinglish?.[0] || m.title}${p.videoId ? `\n     ${momentLink(p.videoId, m.start)}` : ''}`).join('\n');

const safeName = (s) => String(s || 'project').replace(/[^\w\-]+/g, '_').slice(0, 50) || 'project';

/* ---------- projects / history / settings ---------- */
async function renderProjects() {
  view.innerHTML = '<div class="card muted">Loading projects...</div>';
  let list = [];
  try { list = await store.list(); } catch (err) {
    view.innerHTML = `<div class="alert err">Saved projects are unavailable: ${esc(err.message)}</div>`;
    return;
  }
  state.projects = list;
  view.innerHTML = `<h2>Projects</h2>${list.length ? list.map((p) => `<article class="card" data-pid="${esc(p.id)}">
    <b>${esc(p.name)}</b>
    <div class="muted small">${p.analysis?.moments?.length || 0} moments - ${p.transcript?.segments?.length || 0} lines - ${new Date(p.updatedAt).toLocaleString()}</div>
    <div class="actions"><button class="btn small primary" data-act="open-project" data-pid="${esc(p.id)}">Open</button>
      <button class="btn small" data-act="rename-project" data-pid="${esc(p.id)}">Rename</button>
      <button class="btn small" data-act="export-project" data-pid="${esc(p.id)}">Export JSON</button>
      <button class="btn small danger" data-act="delete-project" data-pid="${esc(p.id)}">Delete</button></div></article>`).join('')
    : '<div class="card muted">No saved projects yet. Analyse a video from Home and it will appear here. Works offline.</div>'}`;
}

async function renderHistory() {
  view.innerHTML = '<div class="card muted">Loading...</div>';
  let projects = [];
  try { projects = await store.list(); } catch { /* shown below */ }
  const recent = history.list();
  const saved = projects.flatMap((p) => (p.savedMoments || []).map((s) => ({ p, s })));
  view.innerHTML = `<h2>Recent videos</h2>
  ${recent.length ? recent.map((h) => {
    const proj = projects.find((p) => p.videoId && p.videoId === h.videoId);
    return `<article class="card"><b>${esc(h.title || h.videoId || 'Pasted transcript')}</b><div class="muted small">${new Date(h.at).toLocaleString()}</div>
      <div class="actions">${proj ? `<button class="btn small primary" data-act="open-project" data-pid="${esc(proj.id)}">Open saved project</button>` : ''}
      ${h.url ? `<button class="btn small" data-act="reanalyse-url" data-url="${esc(h.url)}">Analyse again</button>` : ''}</div></article>`;
  }).join('') + '<button class="btn small danger" data-act="clear-history">Clear recent list</button>' : '<div class="card muted">Nothing yet.</div>'}
  <h2 style="margin-top:18px">Saved moments (all projects)</h2>
  ${saved.length ? saved.map(({ p, s }) => `<article class="card"><b>${esc(s.title || 'Moment')}</b>
    <div class="muted small">${esc(p.name)}</div>
    <div class="times"><span>${fmtTime(s.start)} - ${fmtTime(s.end)}</span><span>${Math.round(s.end - s.start)}s</span></div>
    <div class="actions">${p.videoId ? `<a class="btn small cyan" href="${momentLink(p.videoId, s.start)}" target="_blank" rel="noopener">Open on YouTube</a>` : ''}
    <button class="btn small" data-act="copyrange" data-s="${s.start}" data-e="${s.end}">Copy timestamps</button></div></article>`).join('') : '<div class="card muted">Saved moments from every project will appear here.</div>'}`;
}

function renderSettings() {
  const s = settings.all();
  const cap = clipCapability({ hasLocalFile: Boolean(state.local.file), ownershipConfirmed: state.local.confirmed });
  const standalone = window.matchMedia?.('(display-mode: standalone)').matches;
  view.innerHTML = `<h2>Settings</h2>
  <section class="card"><h3 style="margin-top:0">TRANSCRIPT SERVICE</h3>
    <label class="field" for="s-backend">Backend URL (leave empty if you opened this app from the backend itself)</label>
    <input id="s-backend" type="url" data-set="backendUrl" value="${esc(s.backendUrl)}" placeholder="http://localhost:8080">
    <div class="row" style="margin-top:8px"><button class="btn small" data-act="check-backend">Check backend</button><span class="muted small" id="bstatus">${esc(state.backendStatus)}</span></div>
    <label class="field" for="s-lang">Caption language</label>
    <select id="s-lang" data-set="language">${[['auto', 'Auto (Hindi, then English)'], ['hi', 'Hindi'], ['en', 'English']].map(([v, l]) => `<option value="${v}" ${s.language === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
    <label class="field" for="s-token">Optional: Google OAuth access token (only for videos you own)</label>
    <input id="s-token" type="password" data-set="ownerToken" value="${esc(s.ownerToken)}" autocomplete="off" placeholder="ya29...">
    <p class="muted small">Stays in this browser and is sent only to your own backend. Tokens expire in about an hour. See the README for how to get one.</p>
  </section>
  <section class="card"><h3 style="margin-top:0">DETECTION</h3>
    <label class="field" for="s-preset">Clip length preset</label>
    <select id="s-preset" data-set="preset">${Object.values(PRESETS).map((p) => `<option value="${p.key}" ${s.preset === p.key ? 'selected' : ''}>${esc(p.label)}</option>`).join('')}</select>
    <label class="field" for="s-max">Maximum moments (5-50)</label>
    <input id="s-max" type="number" min="5" max="50" data-set="maxMoments" value="${esc(s.maxMoments)}">
    <label class="field" for="s-min">Minimum score (10-80)</label>
    <input id="s-min" type="number" min="10" max="80" data-set="minScore" value="${esc(s.minScore)}">
    <label class="field" for="s-game">Game name used in titles</label>
    <input id="s-game" type="text" data-set="game" value="${esc(s.game)}">
    <label class="field" for="s-chan">Channel name used in captions/hashtags</label>
    <input id="s-chan" type="text" data-set="channel" value="${esc(s.channel)}">
    <p class="muted small">Changes apply on the next analysis or "Re-analyse".</p>
  </section>
  <section class="card"><h3 style="margin-top:0">OPTIONAL: YOUR OWN AUDIO / VIDEO FILE</h3>
    <p class="muted small">Attach a file you own or may use. It stays on this device. It enables (a) an audio loudness signal that can re-rank moments and (b) FFmpeg clip commands. It never creates moments by itself and cannot tell shouting from laughter or game noise.</p>
    <div class="row"><label class="btn cyan filebtn">Choose audio/video file<input id="mfile" type="file"></label></div>
    <p class="small" id="mname">${state.local.file ? esc(state.local.file.name) : 'No file attached.'}</p>
    <label class="row small" style="gap:8px"><input type="checkbox" id="own" ${state.local.confirmed ? 'checked' : ''} style="width:22px;height:22px"> I own this file or am authorised to use it</label>
    <div class="row" style="margin-top:8px"><button class="btn small" data-act="audio-analyse" ${state.local.file ? '' : 'disabled'}>Analyse loudness${state.project ? ' and re-rank' : ''}</button></div>
    <p class="muted small" id="astatus">${esc(state.audioStatus)}</p>
    <p class="muted small">${esc(cap.available ? 'Clip commands are enabled.' : cap.reason)}</p>
  </section>
  <section class="card"><h3 style="margin-top:0">INSTALL AS AN APP</h3>
    ${standalone ? '<p class="small">Already running as an installed app.</p>' : `${state.installEvt ? '<button class="btn primary" data-act="install">Install app</button>' : ''}
    <p class="muted small">Android Chrome: open the menu (three dots) and choose "Install app" or "Add to Home screen". Saved projects and transcripts then open offline. Fetching a new transcript always needs internet.</p>`}
  </section>
  <section class="card"><h3 style="margin-top:0">DATA</h3>
    <p class="muted small">Everything is stored on this device only. No account.</p>
    <button class="btn small danger" data-act="wipe">Delete all projects and history</button>
  </section>`;
}

/* ---------------- events ---------------- */
function findMoment(id) {
  const p = state.project;
  if (!p) return null;
  const m = p.analysis.moments.find((x) => x.id === id);
  return m ? effective(p, m) : null;
}

function setEdit(id, patch) {
  const p = state.project;
  const base = findMoment(id);
  if (!base) return;
  const dur = p.meta?.durationSec || p.analysis.stats?.durationSec || Infinity;
  const next = adjustBounds(base, patch, dur);
  p.edits = { ...p.edits, [id]: { start: next.start, end: next.end } };
  const eff = effective(p, p.analysis.moments.find((x) => x.id === id));
  p.creator = { ...p.creator, [id]: suggestCreatorPack(eff, ctx()) };
  const sm = (p.savedMoments || []).find((s) => s.id === id);
  if (sm) { sm.start = next.start; sm.end = next.end; }
  persist();
  render();
}

const creatorText = (pack, k) => (k.startsWith('hi') ? pack.titlesHindi[Number(k[2])] : k.startsWith('en') ? pack.titlesHinglish[Number(k[2])]
  : { hook: pack.hook.text, desc: pack.description, caption: pack.caption, tags: pack.hashtags.join(' ') }[k]);

async function onClick(e) {
  const t = e.target.closest('[data-act],[data-tab]');
  if (!t) return;
  if (t.dataset.tab) { state.tab = t.dataset.tab; render(); window.scrollTo(0, 0); return; }
  const act = t.dataset.act;
  const id = t.dataset.id;
  const p = state.project;
  switch (act) {
    case 'paste': {
      try {
        const text = await navigator.clipboard.readText();
        if (text) { state.url = text.trim(); render(); } else toast('Clipboard is empty.');
      } catch { toast('Could not read the clipboard. Long-press the box and paste.', 3500); }
      break;
    }
    case 'clear': state.url = ''; state.failure = null; state.steps = null; state.notice = null; render(); break;
    case 'analyse': startAnalysis(); break;
    case 'analyse-paste': {
      const text = document.getElementById('tpaste')?.value || '';
      if (!text.trim()) { state.notice = { kind: 'err', text: 'Paste a transcript first.' }; render(); break; }
      analyseText(text, 'pasted text');
      break;
    }
    case 'newvideo': state.mode = 'input'; state.steps = null; state.failure = null; render(); break;
    case 'rename-current': {
      const name = await askText('Rename project', p.name);
      if (name) { p.name = name; await persist(); render(); }
      break;
    }
    case 'dtab': state.dashTab = t.dataset.k; render(); break;
    case 'filter': state.filter = t.dataset.k; render(); break;
    case 'sort': state.sort = t.dataset.k; render(); break;
    case 'reanalyse': reanalyse(); break;
    case 'inapp': case 'edit': case 'creator': case 'ffmpeg': {
      const key = act === 'inapp' ? 'inapp' : act;
      state.open[id] = { ...(state.open[id] || {}), [key]: !state.open[id]?.[key] };
      render();
      break;
    }
    case 'nudge': setEdit(id, { [`${t.dataset.which}Delta`]: Number(t.dataset.d) }); break;
    case 'resetedit': {
      const edits = { ...p.edits }; delete edits[id]; p.edits = edits;
      const base = p.analysis.moments.find((x) => x.id === id);
      if (base) p.creator = { ...p.creator, [id]: suggestCreatorPack(base, ctx()) };
      const sm = (p.savedMoments || []).find((s) => s.id === id);
      if (sm && base) { sm.start = base.start; sm.end = base.end; }
      await persist(); render();
      break;
    }
    case 'save': {
      const m = findMoment(id);
      const has = (p.savedMoments || []).some((s) => s.id === id);
      p.savedMoments = has ? p.savedMoments.filter((s) => s.id !== id)
        : [...(p.savedMoments || []), { id, start: m.start, end: m.end, title: p.creator?.[id]?.titlesHinglish?.[0] || m.title, excerpt: m.excerpt, categoryLabel: m.categoryLabel, score: m.score }];
      await persist(); render();
      toast(has ? 'Removed from saved' : 'Saved');
      break;
    }
    case 'unsave': p.savedMoments = p.savedMoments.filter((s) => s.id !== id); await persist(); render(); break;
    case 'copyts': { const m = findMoment(id); toast(await copyText(timestampRange(m.start, m.end)) ? `Copied ${timestampRange(m.start, m.end)}` : 'Copy failed'); break; }
    case 'copysaved': { const s = p.savedMoments.find((x) => x.id === id); toast(await copyText(timestampRange(s.start, s.end)) ? 'Copied' : 'Copy failed'); break; }
    case 'copyrange': toast(await copyText(timestampRange(Number(t.dataset.s), Number(t.dataset.e))) ? 'Copied' : 'Copy failed'); break;
    case 'copycreator': { const pack = p.creator?.[id] || suggestCreatorPack(findMoment(id), ctx()); toast(await copyText(creatorText(pack, t.dataset.k)) ? 'Copied' : 'Copy failed'); break; }
    case 'copyffmpeg': { const m = findMoment(id); toast(await copyText(ffmpegCommand(state.local.file?.name || 'input.mp4', m.start, m.end)) ? 'Command copied' : 'Copy failed'); break; }
    case 'copyall': toast(await copyText(timestampLines(p)) ? 'All timestamps copied' : 'Copy failed'); break;
    case 'dl-ts': downloadText(`${safeName(p.name)}_timestamps.txt`, timestampLines(p) + '\n'); break;
    case 'dl-json': downloadText(`${safeName(p.name)}_analysis.json`, exportProjectJSON(p), 'application/json'); break;
    case 'dl-txt': downloadText(`${safeName(p.name)}_transcript.txt`, toTXT(p.transcript.segments)); break;
    case 'dl-srt': downloadText(`${safeName(p.name)}_transcript.srt`, toSRT(p.transcript.segments)); break;
    case 'tvprev': state.tvPage--; renderTranscriptList(); break;
    case 'tvnext': state.tvPage++; renderTranscriptList(); break;
    case 'editseg': {
      const seg = p.transcript.segments[Number(t.dataset.i)];
      const text = await askText(`Edit line at ${fmtTime(seg.start)}`, seg.text);
      if (text) { seg.text = text; p.transcript.corrected = true; await persist(); renderTranscriptList(); toast('Saved. Tap Re-analyse to refresh moments.'); }
      break;
    }
    case 'open-project': {
      const proj = await store.get(t.dataset.pid);
      if (!proj) { toast('Project not found.'); break; }
      state.project = proj; state.mode = 'dashboard'; state.tab = 'home'; state.dashTab = 'moments'; state.filter = 'all'; state.open = {}; state.tvQuery = ''; state.tvPage = 0;
      render();
      break;
    }
    case 'rename-project': {
      const proj = await store.get(t.dataset.pid);
      const name = await askText('Rename project', proj?.name || '');
      if (name) { await store.rename(t.dataset.pid, name); if (state.project?.id === t.dataset.pid) state.project.name = name; render(); }
      break;
    }
    case 'export-project': { const proj = await store.get(t.dataset.pid); if (proj) downloadText(`${safeName(proj.name)}_project.json`, exportProjectJSON(proj), 'application/json'); break; }
    case 'delete-project': {
      if (await askConfirm('Delete this project from this device?')) {
        await store.remove(t.dataset.pid);
        if (state.project?.id === t.dataset.pid) { state.project = null; state.mode = 'input'; }
        render();
      }
      break;
    }
    case 'reanalyse-url': state.url = t.dataset.url; state.tab = 'home'; state.mode = 'input'; state.steps = null; render(); startAnalysis(); break;
    case 'clear-history': history.clear(); render(); break;
    case 'check-backend': {
      state.backendStatus = 'Checking...';
      document.getElementById('bstatus').textContent = state.backendStatus;
      try {
        const j = await fetchJson('/api/health');
        state.backendStatus = j.ok ? `Backend OK (v${j.version}). Public captions: ${j.capabilities.publicCaptions ? 'on' : 'off'}.` : 'Backend answered but reported a problem.';
      } catch (err) { state.backendStatus = `Cannot reach the backend (${err.message}).`; }
      const el = document.getElementById('bstatus'); if (el) el.textContent = state.backendStatus;
      break;
    }
    case 'audio-analyse': {
      const st = document.getElementById('astatus');
      st.textContent = 'Decoding audio... this can take a while on a phone.';
      try {
        const { windows, duration } = await analyzeFile(state.local.file);
        state.audioWindows = windows;
        state.audioStatus = `Audio analysed (${fmtTime(duration)}).`;
        if (state.project) await reanalyse();
      } catch (err) { state.audioStatus = err.message; }
      if (document.getElementById('astatus')) document.getElementById('astatus').textContent = state.audioStatus;
      break;
    }
    case 'install': {
      const ev = state.installEvt;
      if (ev) { ev.prompt(); await ev.userChoice; state.installEvt = null; render(); }
      break;
    }
    case 'wipe':
      if (await askConfirm('Delete ALL saved projects and the recent list?', 'Delete all')) {
        await store.clear(); history.clear(); state.project = null; state.mode = 'input'; toast('Everything deleted.'); render();
      }
      break;
    default: break;
  }
}

async function onChange(e) {
  const t = e.target;
  if (t.id === 'tfile' && t.files?.[0]) {
    const f = t.files[0];
    try {
      const text = await readFileText(f);
      if (!text.trim()) throw new Error('That file is empty.');
      await analyseText(text, `file: ${f.name}`, f.name);
    } catch (err) { state.notice = { kind: 'err', text: err.message }; render(); }
    t.value = '';
    return;
  }
  if (t.id === 'mfile' && t.files?.[0]) {
    state.local.file = t.files[0];
    state.audioStatus = '';
    renderSettings();
    return;
  }
  if (t.id === 'own') { state.local.confirmed = t.checked; renderSettings(); return; }
  if (t.dataset.set) {
    let v = t.value;
    if (t.dataset.set === 'maxMoments') v = Math.min(50, Math.max(5, Number(v) || 20));
    if (t.dataset.set === 'minScore') v = Math.min(80, Math.max(10, Number(v) || 35));
    settings.set({ [t.dataset.set]: v });
    toast('Saved');
    return;
  }
  if (t.dataset.act === 'settime') {
    const sec = parseTimestamp(t.value);
    const m = findMoment(t.dataset.id);
    if (sec == null || !m) { toast('Use hh:mm:ss, for example 00:03:12'); render(); return; }
    const which = t.dataset.which;
    setEdit(t.dataset.id, which === 'start' ? { startDelta: sec - m.start } : { endDelta: sec - m.end });
  }
}

function onInput(e) {
  const t = e.target;
  if (t.id === 'url') {
    state.url = t.value;
    const prev = document.getElementById('preview');
    if (prev) prev.innerHTML = previewHtml(state.url ? parseYouTubeUrl(state.url) : null);
  } else if (t.id === 'tvq') {
    state.tvQuery = t.value;
    state.tvPage = 0;
    renderTranscriptList();
  }
}

view.addEventListener('click', onClick);
view.addEventListener('change', onChange);
view.addEventListener('input', onInput);
document.querySelector('.tabs').addEventListener('click', onClick);

/* ---------------- boot ---------------- */
const net = document.getElementById('net');
const syncNet = () => { net.hidden = navigator.onLine !== false; };
window.addEventListener('online', syncNet);
window.addEventListener('offline', syncNet);
syncNet();
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); state.installEvt = e; if (state.tab === 'settings') render(); });

const q = new URLSearchParams(location.search);
if (q.get('url') || q.get('v')) state.url = q.get('url') || `https://youtu.be/${q.get('v')}`;

if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
  navigator.serviceWorker.register('sw.js').catch(() => { /* app still works without offline cache */ });
}
window.__vmf = { state, startAnalysis, analyseText, store, settings }; // handy for automated tests
render();
