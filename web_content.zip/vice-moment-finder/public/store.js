/*
 * VICE MOMENT FINDER - local project storage.
 * Saves analyses on THIS phone only (IndexedDB). Nothing is uploaded.
 * The storage engine is swappable so the logic can be tested without a browser
 * (see memoryBackend); the real IndexedDB backend is checked in a real browser.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ViceStore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const DB_NAME = 'vice-moment-finder';
  const STORE = 'projects';
  const MAX_PROJECTS = 100;
  const MAX_TRANSCRIPT_CHARS = 6 * 1024 * 1024;
  const FORMAT_VERSION = 2;

  function memoryBackend() {
    const m = new Map();
    const clone = (v) => JSON.parse(JSON.stringify(v));
    return {
      kind: 'memory',
      put: (rec) => Promise.resolve(void m.set(rec.id, clone(rec))),
      get: (id) => Promise.resolve(m.has(id) ? clone(m.get(id)) : null),
      getAll: () => Promise.resolve(Array.from(m.values()).map(clone)),
      remove: (id) => Promise.resolve(void m.delete(id)),
      clear: () => Promise.resolve(void m.clear()),
    };
  }

  function idbBackend(factory) {
    const idb = factory || (typeof indexedDB !== 'undefined' ? indexedDB : null);
    if (!idb) return null;
    let dbPromise = null;
    function open() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve, reject) => {
        const req = idb.open(DB_NAME, 1);
        req.onupgradeneeded = () => {
          if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE, { keyPath: 'id' });
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error || new Error('Could not open local storage.'));
        req.onblocked = () => reject(new Error('Local storage is blocked by another tab.'));
      });
      dbPromise.catch(() => { dbPromise = null; });
      return dbPromise;
    }
    function tx(mode, fn) {
      return open().then(
        (db) =>
          new Promise((resolve, reject) => {
            const t = db.transaction(STORE, mode);
            const os = t.objectStore(STORE);
            const r = fn(os);
            t.oncomplete = () => resolve(r && 'result' in r ? r.result : undefined);
            t.onerror = () => reject(t.error || new Error('Local storage error.'));
            t.onabort = () => reject(t.error || new Error('Local storage was stopped (the phone may be out of space).'));
          })
      );
    }
    return {
      kind: 'indexeddb',
      put: (rec) => tx('readwrite', (os) => os.put(rec)),
      get: (id) => tx('readonly', (os) => os.get(id)).then((v) => v || null),
      getAll: () => tx('readonly', (os) => os.getAll()).then((v) => v || []),
      remove: (id) => tx('readwrite', (os) => os.delete(id)),
      clear: () => tx('readwrite', (os) => os.clear()),
    };
  }

  function newId() {
    return 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function cleanName(n) {
    const s = String(n || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim();
    return (Array.from(s).slice(0, 80).join('') || 'Untitled project');
  }

  // Keep only what is needed to restore a screen. Large parse data (every cue) is not stored.
  function pack(project, opts) {
    const o = opts || {};
    const p = project || {};
    if (!p.result || !Array.isArray(p.result.moments)) throw new Error('There is no analysis to save yet.');
    const text = typeof p.transcriptText === 'string' && o.includeTranscript !== false ? p.transcriptText : '';
    if (text.length > MAX_TRANSCRIPT_CHARS) throw new Error('The transcript is too large to save with the project.');
    const result = {
      moments: p.result.moments,
      notes: p.result.notes || [],
      stats: p.result.stats,
      options: p.result.options,
      parse: p.result.parse ? { format: p.result.parse.format, warnings: p.result.parse.warnings || [] } : { format: 'unknown', warnings: [] },
    };
    return {
      id: p.id || newId(),
      formatVersion: FORMAT_VERSION,
      name: cleanName(p.name),
      savedAt: new Date().toISOString(),
      url: String(p.url || '').slice(0, 300),
      videoId: p.videoId || null,
      source: String(p.source || '').slice(0, 200),
      settings: p.settings || {},
      transcriptText: text,
      visualText: String(p.visualText || '').slice(0, 200000),
      selected: p.selected || {},
      edits: p.edits || {},
      result,
    };
  }

  function createStore(backend) {
    const b = backend || idbBackend() || memoryBackend();
    return {
      kind: b.kind,
      save(project, opts) {
        // Always return a promise, even for validation errors, so callers can use .catch().
        return Promise.resolve().then(() => pack(project, opts)).then((rec) => b.getAll().then((all) => {
          const exists = all.some((r) => r.id === rec.id);
          if (!exists && all.length >= MAX_PROJECTS) throw new Error('You have ' + MAX_PROJECTS + ' saved projects. Delete one first.');
          return b.put(rec).then(() => ({ id: rec.id, name: rec.name, savedAt: rec.savedAt }));
        }));
      },
      list() {
        return b.getAll().then((all) =>
          all
            .map((r) => ({
              id: r.id,
              name: r.name,
              savedAt: r.savedAt,
              moments: r.result && r.result.moments ? r.result.moments.length : 0,
              selected: Object.keys(r.selected || {}).filter((k) => r.selected[k]).length,
              source: r.source,
              hasTranscript: !!r.transcriptText,
            }))
            .sort((x, y) => (x.savedAt < y.savedAt ? 1 : -1))
        );
      },
      load(id) {
        return b.get(id).then((r) => {
          if (!r) throw new Error('That project was not found.');
          if (!r.result || !Array.isArray(r.result.moments)) throw new Error('That saved project is damaged.');
          return r;
        });
      },
      remove(id) {
        return b.remove(id);
      },
      clearAll() {
        return b.clear();
      },
    };
  }

  // Tiny per-phone preferences (e.g. "welcome card dismissed"). Never throws; works without storage.
  const prefs = {
    get(key) {
      try { return typeof localStorage !== 'undefined' ? localStorage.getItem('vmf.' + key) : null; } catch (e) { return null; }
    },
    set(key, value) {
      try { if (typeof localStorage !== 'undefined') localStorage.setItem('vmf.' + key, String(value)); return true; } catch (e) { return false; }
    },
  };

  return { prefs, createStore, memoryBackend, idbBackend, pack, DB_NAME, STORE, MAX_PROJECTS, FORMAT_VERSION };
});
