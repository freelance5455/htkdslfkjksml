/*
 * VICE MOMENT FINDER - creator assistant (local templates).
 * This is NOT an AI. It fills fixed templates from a moment's category, intensity and timing,
 * so the same moment always gives the same suggestions. Nothing is sent anywhere.
 * Runs in the browser (window.ViceCreator) and in Node (require).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ViceCreator = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // Per category: english / hinglish / hindi titles, hooks and one editing note set.
  const T = {
    funny: {
      en: ['This GTA moment had me DYING', 'Wait for the ending… GTA funny moment', 'GTA RP gone completely wrong'],
      hn: ['Hasi ruk hi nahi rahi 😂 GTA funny moment', 'Ye GTA moment dekh ke hasna mat 😂', 'GTA mein ye kya ho gaya 😂'],
      hi: ['जीटीए का सबसे मज़ेदार पल 😂', 'हँसी रोकना मुश्किल है 😂 GTA', 'ये GTA वाला पल देखकर हँस पड़ोगे'],
      hook: ['Wait for it…', 'Ye dekh ke hasi aa jayegi', 'Nobody expected this'],
      style: 'Keep it tight: start 1-2 seconds before the setup, cut dead air, add a quick caption on the punchline.',
      sfx: ['laugh track / "ba dum tss" rimshot on the punchline', 'short record-scratch on the setup'],
      zoom: 'Slow zoom-in on the setup, snap zoom on the punchline.',
    },
    rage: {
      en: ['GTA rage moment you cannot miss', 'He completely lost it in GTA', 'GTA rage quit speedrun'],
      hn: ['GTA mein gussa control se bahar 😡', 'Itna gussa kyun aaya? GTA rage', 'GTA rage moment, dimag kharab ho gaya'],
      hi: ['GTA में गुस्सा काबू से बाहर 😡', 'इतना गुस्सा क्यों आया? GTA रेज', 'GTA रेज मोमेंट'],
      hook: ['Watch his reaction…', 'Ye gussa dekho', 'This is where it all went wrong'],
      style: 'Start right before the trigger event, keep the loudest line in the middle, bleep or mute strong swearing if needed for monetisation.',
      sfx: ['bass hit on the loudest line', 'censor beep over swearing if needed'],
      zoom: 'Punch-in zoom on the loudest words.',
    },
    glitch: {
      en: ['GTA glitch that should not exist', 'How did this even happen in GTA?', 'Broken GTA physics moment'],
      hn: ['GTA mein ye kaisa glitch hai? 😳', 'Ye kaise hua GTA mein?', 'GTA ka sabse ajeeb glitch'],
      hi: ['GTA का सबसे अजीब ग्लिच 😳', 'ये कैसे हुआ GTA में?', 'GTA में ये क्या हो गया'],
      hook: ['Look at what happens…', 'Ye kaise hua?', 'This is not supposed to happen'],
      style: 'Show the glitch itself for at least 3 seconds. A replay in slow motion after the reaction works well. Confirm the glitch on screen first - the transcript only suggests it.',
      sfx: ['"error" / glitch sound on the moment it happens', 'whoosh on the replay'],
      zoom: 'Zoom into the glitching object, then back out to show the whole scene.',
    },
    police: {
      en: ['Escaping 5 stars in GTA', 'GTA police chase gone crazy', 'He outran every cop in GTA'],
      hn: ['5 star police se kaise bache? GTA chase', 'GTA police chase pagal ho gayi', 'Police ko chakma diya GTA mein'],
      hi: ['GTA में 5 स्टार पुलिस से कैसे बचे', 'GTA पुलिस चेज़ का पागलपन', 'पुलिस को चकमा दिया GTA में'],
      hook: ['5 stars… can he escape?', 'Police peeche pad gayi', 'Watch this chase'],
      style: 'Fast cuts, keep the driving shots, end on the escape or the bust. Add a wanted-level callout in the caption.',
      sfx: ['siren swell', 'tyre screech on sharp turns'],
      zoom: 'Quick zoom at each near-miss.',
    },
    crash: {
      en: ['Worst GTA crash ever', 'This GTA crash was INSANE', 'GTA car flipped and exploded'],
      hn: ['GTA ka sabse bada crash 💥', 'Gaadi ka kya haal kar diya GTA mein', 'Ye crash dekh ke pasina aa jayega'],
      hi: ['GTA का सबसे बड़ा क्रैश 💥', 'गाड़ी का क्या हाल कर दिया GTA में', 'ये क्रैश देखकर होश उड़ जाएंगे'],
      hook: ['Watch the car…', 'Ye gaadi ka kya hua', 'Wait for the impact'],
      style: 'Cut to the approach, hit the crash, and replay it once in slow motion. End on the reaction line.',
      sfx: ['impact boom on the crash', 'bass drop', 'ringing ears effect after explosion'],
      zoom: 'Zoom out on the approach, snap-zoom on the impact.',
    },
    death: {
      en: ['The most unexpected GTA death', 'He did NOT see that coming', 'GTA death you have to see'],
      hn: ['GTA mein ye kaisi maut thi 😭', 'Isne socha bhi nahi tha ye hoga', 'GTA ki sabse ajeeb death'],
      hi: ['GTA की सबसे अजीब मौत 😭', 'इसने सोचा भी नहीं था ये होगा', 'GTA में ये क्या हो गया'],
      hook: ['He had no idea…', 'Ye kisne socha tha?', 'Wait for it'],
      style: 'Show the moment before so the surprise lands, freeze-frame on the death, then the reaction.',
      sfx: ['"wasted" style sting', 'record-scratch', 'sad trombone'],
      zoom: 'Slow push-in before the death, hold on the reaction.',
    },
    crazy: {
      en: ['Insane GTA clutch moment', 'How did he survive that?', 'GTA skill shot you will not believe'],
      hn: ['GTA mein kya shot maara bhai 🔥', 'Ye bach kaise gaya?', 'GTA clutch moment, kamaal kar diya'],
      hi: ['GTA में क्या शॉट मारा भाई 🔥', 'ये बच कैसे गया?', 'GTA क्लच मोमेंट, कमाल कर दिया'],
      hook: ['Watch this shot…', 'Bach gaya kaise?', 'No way he did that'],
      style: 'Show the full play in one cut, replay the best 2 seconds slowed, end on the celebration line.',
      sfx: ['cinematic rise into the play', 'airhorn on the clutch'],
      zoom: 'Follow the action, snap zoom at the key moment.',
    },
    conversation: {
      en: ['GTA RP conversation that went off the rails', 'The funniest GTA chat ever', 'Wait until you hear what he said'],
      hn: ['GTA RP ki baat-cheet pagal ho gayi 😂', 'Is conversation ka end dekho', 'Bhai ne kya bol diya GTA mein'],
      hi: ['GTA RP की बातचीत बेकाबू हो गई 😂', 'इस बातचीत का अंत देखो', 'भाई ने ये क्या बोल दिया'],
      hook: ['Listen to this…', 'Suno ye kya bola', 'The way he said it…'],
      style: 'Add captions for every line (viewers watch muted). Trim silences, keep the best 3-4 exchanges.',
      sfx: ['subtle pop on each caption', 'rimshot on the punchline'],
      zoom: 'Alternate light zooms between the speakers if both are visible.',
    },
    surprise: {
      en: ['He was NOT ready for this in GTA', 'GTA jumpscare moment', 'Where did that come from?!'],
      hn: ['Achanak ye kya aa gaya GTA mein 😱', 'GTA mein dar gaya main', 'Kahan se aaya ye?'],
      hi: ['अचानक ये क्या आ गया GTA में 😱', 'GTA में डर गया मैं', 'ये कहाँ से आया?'],
      hook: ['Wait for the surprise…', 'Achanak kya hua?', 'Nobody saw it coming'],
      style: 'Start calm, cut on the surprise, keep the reaction line. Do not over-explain.',
      sfx: ['jump-scare hit on the surprise', 'riser before it'],
      zoom: 'Hard zoom on the surprise.',
    },
    viral: {
      en: ['The clip chat will not stop talking about', 'GTA moment going viral', 'You have to see this reaction'],
      hn: ['Chat ne pagal kar diya is clip pe 🔥', 'Ye GTA clip viral hone wali hai', 'Is reaction ko dekho'],
      hi: ['चैट इस क्लिप पर पागल हो गया 🔥', 'ये GTA क्लिप वायरल होने वाली है', 'इस रिएक्शन को देखो'],
      hook: ['Watch his reaction…', 'Ye reaction dekho', 'Chat went crazy'],
      style: 'Open on the loudest line, add large captions, keep it under 30 seconds.',
      sfx: ['bass hit on the loud line', 'crowd cheer'],
      zoom: 'Constant slow zoom to keep energy.',
    },
    roast: {
      en: ['The roast that ended him in GTA', 'GTA roast session is brutal', 'He got ROASTED in GTA'],
      hn: ['Aisi roast GTA mein pehli baar dekhi 🔥', 'GTA mein bhai ki band baj gayi', 'Roast ka level dekho'],
      hi: ['ऐसा रोस्ट GTA में पहली बार देखा 🔥', 'GTA में भाई की बैंड बज गई', 'रोस्ट का लेवल देखो'],
      hook: ['He did NOT hold back…', 'Ye roast dekho', 'Listen to this roast'],
      style: 'Captions on every insult, leave a beat of silence after the best line.',
      sfx: ['"ooooh" crowd', 'airhorn on the best insult'],
      zoom: 'Zoom on the target character after each line.',
    },
    argument: {
      en: ['GTA argument that escalated fast', 'They would not stop arguing in GTA', 'Who was right? GTA argument'],
      hn: ['GTA mein jhagda shuru ho gaya 😤', 'Kaun sahi tha? GTA ki behes', 'Jhagda itna kyun badh gaya'],
      hi: ['GTA में झगड़ा शुरू हो गया 😤', 'कौन सही था? GTA की बहस', 'झगड़ा इतना क्यों बढ़ गया'],
      hook: ['It started with this…', 'Kaun galat tha?', 'Watch it escalate'],
      style: 'Keep the escalation in order, caption both sides, end on the loudest line or the awkward silence.',
      sfx: ['tension riser', 'record-scratch on the turning point'],
      zoom: 'Cut between speakers; slow zoom at peak anger.',
    },
    emotional: {
      en: ['An emotional GTA moment nobody expected', 'This GTA moment hit different', 'GTA wholesome moment'],
      hn: ['GTA mein dil ko chhu lene wala pal 🥺', 'Ye GTA moment emotional kar gaya', 'GTA ka sabse wholesome moment'],
      hi: ['GTA में दिल को छू लेने वाला पल 🥺', 'ये GTA मोमेंट इमोशनल कर गया', 'GTA का सबसे प्यारा पल'],
      hook: ['Wait for the ending…', 'Ye dil chhu gaya', 'Nobody expected this'],
      style: 'Slower pacing, soft music under it, keep the full sentence uncut.',
      sfx: ['soft piano', 'gentle swell'],
      zoom: 'Very slow push-in. No snap zooms.',
    },
    discovery: {
      en: ['He found something strange in GTA', 'Hidden GTA secret nobody knew', 'GTA easter egg discovery'],
      hn: ['GTA mein ye kya mil gaya? 👀', 'GTA ka chhupa hua raaz', 'Ye jagah kisi ko nahi pata'],
      hi: ['GTA में ये क्या मिल गया? 👀', 'GTA का छुपा हुआ राज़', 'ये जगह किसी को नहीं पता'],
      hook: ['Look what he found…', 'Ye dekho kya mila', 'Nobody knows about this'],
      style: 'Build curiosity first, reveal late, show the thing clearly for 3+ seconds.',
      sfx: ['mystery chime on the reveal', 'whoosh to the object'],
      zoom: 'Zoom to the discovered object.',
    },
    suspicious: {
      en: ['Something was very wrong in GTA', 'This GTA player was SUS', 'Who was following him in GTA?'],
      hn: ['GTA mein kuch gadbad thi 👀', 'Ye bande ne shak paida kar diya', 'Peeche kaun tha GTA mein?'],
      hi: ['GTA में कुछ गड़बड़ थी 👀', 'इस बंदे ने शक पैदा कर दिया', 'पीछे कौन था GTA में?'],
      hook: ['Something is off here…', 'Kuch gadbad hai', 'Look behind him'],
      style: 'Hold tension, use a circle highlight or arrow on the suspicious thing, reveal at the end.',
      sfx: ['low drone', 'heartbeat before the reveal'],
      zoom: 'Slow push-in toward the suspicious thing.',
    },
    epic: {
      en: ['Epic GTA win', 'He actually pulled it off in GTA', 'GTA victory you have to see'],
      hn: ['GTA mein jeet ka maza hi alag hai 🏆', 'Kar hi diya bhai ne GTA mein', 'GTA ki epic jeet'],
      hi: ['GTA में जीत का मज़ा ही अलग है 🏆', 'कर ही दिया भाई ने GTA में', 'GTA की एपिक जीत'],
      hook: ['He actually did it…', 'Kar diya bhai ne', 'Watch to the end'],
      style: 'Build the tension, cut on the win, hold the celebration for 2 seconds.',
      sfx: ['victory fanfare', 'cheer'],
      zoom: 'Wide shot for the win, then push-in on the celebration.',
    },
  };

  const BASE_TAGS = ['#GTA', '#GTA5', '#GTAV', '#Shorts', '#GTARP', '#ViceClips'];
  const CAT_TAGS = {
    funny: ['#FunnyMoments', '#GTAFunny'], rage: ['#Rage', '#GamingRage'], glitch: ['#Glitch', '#GTAGlitch'],
    police: ['#PoliceChase', '#5Stars'], crash: ['#CarCrash', '#GTACrash'], death: ['#Fail', '#UnexpectedDeath'],
    crazy: ['#Clutch', '#Insane'], conversation: ['#RP', '#Banter'], surprise: ['#Jumpscare', '#Unexpected'],
    viral: ['#Viral', '#Reaction'], roast: ['#Roast', '#Savage'], argument: ['#Argument', '#Drama'],
    emotional: ['#Wholesome', '#Emotional'], discovery: ['#Secret', '#Discovery'], suspicious: ['#Sus', '#Mystery'],
    epic: ['#Epic', '#Win'],
  };

  const FALLBACK = 'surprise';

  function pick(list, seed) {
    return list[Math.abs(seed) % list.length];
  }

  function seedOf(m) {
    return (Number(m.startMs) | 0) + (Number(m.rank) | 0) * 7;
  }

  function fmtDur(sec) {
    return Math.max(0, Math.round(sec)) + ' seconds';
  }

  // Remove characters that break titles / spreadsheets; never keeps markup.
  function safe(text, max) {
    const t = String(text || '').replace(/[<>]/g, '').replace(/\s+/g, ' ').trim();
    const chars = Array.from(t);
    return chars.length > max ? chars.slice(0, max - 1).join('').trimEnd() + '…' : t;
  }

  function hashtagsFor(m, extra) {
    const out = [];
    const add = (t) => { if (t && out.indexOf(t) === -1) out.push(t); };
    ['#GTA', '#GTA5', '#Shorts'].forEach(add);
    (m.categories || [m.category]).forEach((c) => (CAT_TAGS[c] || []).forEach(add));
    BASE_TAGS.forEach(add);
    (extra || []).forEach(add);
    return out.slice(0, 10);
  }

  /*
   * Build creator suggestions for one moment.
   * `edits` (optional) lets the user's own title/caption/notes override a suggestion.
   */
  function suggest(m, edits) {
    const e = edits || {};
    const cat = T[m.category] ? m.category : FALLBACK;
    const t = T[cat];
    const seed = seedOf(m);
    const titles = {
      english: pick(t.en, seed),
      hinglish: pick(t.hn, seed),
      hindi: pick(t.hi, seed),
    };
    titles.shorts = titles.english;
    const hook = pick(t.hook, seed + 1);
    const hashtags = hashtagsFor(m);
    const rec = m.recStartText + ' to ' + m.recEndText + ' (' + fmtDur(m.recDurationSec) + ')';
    const caption = safe(titles.hinglish, 100) + ' ' + hashtags.slice(0, 4).join(' ');
    const description = [
      titles.english + '.',
      'Clip from the VICE CLIPS GTA livestream, around ' + m.startText + '.',
      'Category: ' + m.categoryLabel + '.',
      '',
      hashtags.join(' '),
    ].join('\n');
    const lengthNote = m.shortsFit
      ? 'Recording window is ' + fmtDur(m.recDurationSec) + ', a good Shorts length.'
      : m.recDurationSec < 20
      ? 'Window is only ' + fmtDur(m.recDurationSec) + '; raise the padding if you want about 20-35 seconds.'
      : 'Window is ' + fmtDur(m.recDurationSec) + '; trim it to 20-35 seconds while editing for Shorts.';
    const out = {
      category: m.categoryLabel,
      titles: {
        shorts: safe(e.title || titles.shorts, 100),
        english: titles.english,
        hinglish: titles.hinglish,
        hindi: titles.hindi,
      },
      hook,
      caption: safe(e.caption || caption, 300),
      description,
      hashtags,
      why: m.why,
      editingStyle: t.style + ' ' + lengthNote,
      startPoint: m.recStartText + ' (recording start; the moment itself begins at ' + m.startText + ')',
      endPoint: m.recEndText + ' (recording end; the moment itself ends at ' + m.endText + ')',
      sfx: t.sfx.slice(),
      zoom: t.zoom,
      recordWindow: rec,
      note: 'Suggestions come from fixed templates for the category, not from AI, and are not based on what is on screen.',
    };
    return out;
  }

  // Individual copyable fields: [key, label, text]
  function fields(c) {
    return [
      ['shorts', 'Shorts title', c.titles.shorts],
      ['english', 'English title', c.titles.english],
      ['hinglish', 'Hinglish title', c.titles.hinglish],
      ['hindi', 'Hindi title', c.titles.hindi],
      ['hook', 'Opening hook', c.hook],
      ['caption', 'Caption', c.caption],
      ['description', 'Description', c.description],
      ['hashtags', 'Hashtags', c.hashtags.join(' ')],
      ['why', 'Why interesting', c.why],
      ['editing', 'Editing style', c.editingStyle],
      ['start', 'Start point', c.startPoint],
      ['end', 'End point', c.endPoint],
      ['sfx', 'Sound effects', c.sfx.join('; ')],
      ['zoom', 'Zoom / emphasis', c.zoom],
      ['window', 'Recording window', c.recordWindow],
    ];
  }

  function combined(c) {
    return fields(c).map((f) => f[1] + ': ' + f[2]).join('\n');
  }

  return { suggest, fields, combined, hashtagsFor, safe, TEMPLATE_CATEGORIES: Object.keys(T) };
});
