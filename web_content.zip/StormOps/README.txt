طريقة طلوع الـ APK (من غير ما تنزل أي حاجة على الكمبيوتر):
1) اعمل حساب مجاني على github.com وعمل Repository جديد.
2) ارفع كل محتويات الفولدر ده (مع فولدر .github).
3) افتح تبويب Actions > Build APK > Run workflow، استنى دقيقتين.
4) نزّل ملف StormOps-APK من الـ Artifacts، فك الضغط وهتلاقي app-debug.apk، ثبّته على موبايلك.

أو افتح الفولدر في Android Studio واضغط Build > Build APK(s).
