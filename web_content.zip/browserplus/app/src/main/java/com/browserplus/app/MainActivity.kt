package com.browserplus.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.*
import android.view.ViewGroup
import android.graphics.Color
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private var adBlockEnabled = true
    private val blockedHosts = setOf("doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com", "adnxs.com", " taboola.com", "outbrain.com", "adroll.com", "ads.yahoo.com")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(16,24,39)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(8,8,8,8) }
        address = EditText(this).apply {
            hint = "اكتب رابط الموقع أو ابحث"; singleLine = true; textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setBackgroundColor(Color.rgb(37,49,69)); setPadding(14,0,14,0)
        }
        val go = Button(this).apply { text = "اذهب"; setOnClickListener { openAddress() } }
        top.addView(address, LinearLayout.LayoutParams(0, 48, 1f)); top.addView(go)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER }
        fun control(label: String, action: () -> Unit) { controls.addView(Button(this).apply { text = label; setOnClickListener { action() } }, LinearLayout.LayoutParams(0, 48, 1f)) }
        control("رجوع") { if (web.canGoBack()) web.goBack() }
        control("تقدم") { if (web.canGoForward()) web.goForward() }
        control("تحديث") { web.reload() }
        control("الرئيسية") { web.loadUrl("file:///android_asset/index.html") }
        control("حجب الإعلانات") { adBlockEnabled = !adBlockEnabled; itSafeLabel() }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString() ?: return false
                    address.setText(url)
                    return false
                }
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    if (adBlockEnabled) {
                        val host = request?.url?.host?.lowercase() ?: ""
                        if (blockedHosts.any { host == it.trim() || host.endsWith("." + it.trim()) })
                            return WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), "")
                    }
                    return super.shouldInterceptRequest(view, request)
                }
                override fun onPageFinished(view: WebView?, url: String?) { if (url != null && !url.startsWith("file:")) address.setText(url) }
            }
        }
        root.addView(top); root.addView(controls)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun itSafeLabel() { Toast.makeText(this, if (adBlockEnabled) "تم تشغيل حجب الإعلانات" else "تم إيقاف حجب الإعلانات", Toast.LENGTH_SHORT).show() }

    private fun openAddress() {
        var text = address.text.toString().trim()
        if (text.isBlank()) return
        if (!text.contains(".") || text.contains(" ")) text = "https://www.google.com/search?q=" + android.net.Uri.encode(text)
        else if (!text.startsWith("http://") && !text.startsWith("https://")) text = "https://$text"
        web.loadUrl(text)
    }

    // Applies a real HTTP/HTTPS proxy to WebView when supported by the Android System WebView.
    private fun applyProxy(host: String, port: Int) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            Toast.makeText(this, "ميزة البروكسي غير مدعومة في إصدار WebView الحالي", Toast.LENGTH_LONG).show(); return
        }
        val config = ProxyConfig.Builder().addProxyRule("$host:$port").build()
        ProxyController.getInstance().setProxyOverride(config, Executor { it.run() }) {
            runOnUiThread { Toast.makeText(this, "تم تطبيق إعداد البروكسي", Toast.LENGTH_SHORT).show() }
        }
    }
}
