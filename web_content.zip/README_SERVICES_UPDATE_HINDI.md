Growth Saller - Services update

Changes:
- Added Instagram Reel Views, Post Likes and Followers.
- Added Facebook Post Likes, Video Views and Page Followers.
- Added YouTube Video Views, Video Likes and Subscribers.
- Added TikTok Video Views, Video Likes and Followers.
- Added colored platform marks to service cards in local mode and Firebase mode.

Important:
- Prices are sample/configurable prices, not verified supplier rates.
- This source only creates a local order record in local fallback mode. It does not itself deliver views, likes or followers. Actual delivery requires a legitimate service provider/integration and backend.
- If Firebase is configured, active service documents must also exist in Firestore `services` collection for the Firebase-mode catalogue. Local fallback service list does not automatically seed Firestore.
- These are recognizable platform marks made with text/CSS, not official downloadable trademark artwork.
- Build/test in APKForge after import; this ZIP is not a compiled APK.
