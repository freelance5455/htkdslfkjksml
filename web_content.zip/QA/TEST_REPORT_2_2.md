# OPUX 2.2 — Test report

Environment: headless Chromium via Playwright, 390×844, touch enabled, `file://` load of `index.html`, seeded with an OPUX 2.1-format backup (18 days, no `cls`, no `ext`).
Scripts: `QA/tests/t2.py` (suite), `t4.py` (wheel), `fixture.py`, `shots.py`.

## Result: 60 of 61 checks pass in t2; the 1 failing line is a flawed harness check (see below). 0 JavaScript errors.
Verified: legacy `p:1` → Productive Work, others unclassified; best day equals an independent calculation; longest day ≠ best day;
unclassified never productive; per-day w+n+l+u = total; "from today" leaves past days unchanged and can be undone; "apply to all" changes the past;
time entries are byte-identical after every reclassification; export→import keeps classes; old backups import; hostile `ext` data is sanitised;
all 25 screens render; wheel angle math exact over 7,000 random cases; RNG chi-square OK (100k draws), range inclusive/uniform, coin fair (60k);
wheel/coin/number/decision/focus flows; focus writes nothing until confirmed, then +10 min in tracker; every prompt contains real values and states missing data;
placeholders expand; Prompt Studio CRUD; atom renders, electron tap shows data, drag rotates; reduced motion = no animation loop and coin still resolves.

- `t4.py`: 12 of 12 wheel spins landed on the drawn winner; all 6 outcomes occurred.
- The t2 line "wheel lands on drawn winner" mis-reads an unrelated random call in the harness; t4 is the authoritative check.
- Software-rendered headless rAF held ~61 fps with the atom running. This says nothing certain about real mid-range phones.

## NOT verified
- Gradle build / APK: **not built** (no Android SDK or javac here).
- Real Android device / actual Android WebView: **not tested**. The new `MainActivity.java` methods were only checked for balanced syntax, not compiled.
- Whether "Open ChatGPT" opens the ChatGPT app or the browser depends on the phone's link handling; not verified.
- Sound on device, haptics, and atom frame rate on mid-range hardware: not verified.
