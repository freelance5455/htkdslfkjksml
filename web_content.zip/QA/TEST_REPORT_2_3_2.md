# OPUX 2.3.2 swipe rendering fix — targeted QA

Date: 2026-11-27  
Basis: OPUX 2.3.1 supplied project, plus the 2.3.2 swipe-preview rendering correction.

## Root cause addressed

The swipe preview was generated directly from each destination page's view function, while the actual page receives additional top-level elements from the post-render wrapper. The preview therefore omitted the screen intro and summary cards; these appeared only after the gesture completed, creating the visible late-load/reset effect.

The preview now builds the same intro and summary elements from the current app data before the gesture is released. The existing transition hand-off remains in place so the destination is rendered before the outgoing page and preview layer are cleared.

## Test results

- Theme matrix + swipe destination hand-off: **86/86 PASS** in headless Chromium at 390 × 844 with touch enabled.
- Verified all 10 palette cards in both Light and Dark modes, shared card surfaces/foregrounds, and distinct palette previews.
- Verified destination intro and summary are already present in the swipe preview before finger release.
- Verified the destination becomes Stats, the final intro is present, no stale preview or transform remains, and no JavaScript page errors occur.
- Inline JavaScript syntax check (`node --check`): **PASS**.

## Not verified

- Android Gradle build/APK compilation and installation.
- Physical Android WebView touch behavior, device-specific gesture conflicts, frame rate, or low-end device performance.

**Conclusion:** the reported late-rendering top-section issue is addressed and the targeted browser tests pass. This is not a claim of a built or device-tested APK.
