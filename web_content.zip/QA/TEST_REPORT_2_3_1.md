# OPUX 2.3.1 targeted QA report

Date: 2026-11-27  
Environment: headless Chromium, Playwright, 390–430 px mobile viewport, synthetic in-memory app state. The HTML was loaded into a browser page using `set_content`; tests exercise the actual app JavaScript and CSS, but not Android WebView.

## Changes verified

1. Theme CSS selectors are scoped to `html[data-t=...]`, preventing the palette buttons' own `data-t` attributes from applying app theme variables to the cards.
2. All ten palettes render in both appearance modes. The cards share one surface and foreground per mode, and each card retains its own unique preview gradient.
3. Swipe completion now renders the destination before removing the outgoing panel's translation and the temporary peek layer. The destination's top intro is present after transition and no stale transform/peek remains.

## Test results

| Suite | Result |
|---|---:|
| Existing swipe, motion, RDBD, colour-picker and Branch regressions | 39/39 PASS |
| Theme matrix + swipe destination hand-off | 84/84 PASS |
| Midnight splitting/data regressions (UTC, America/New_York, Asia/Karachi, Europe/London) | 56/56 PASS |
| **Total** | **179/179 PASS** |

Additional checks: inline JavaScript syntax (`node --check`) PASS; no JavaScript page errors in the targeted suites. Visual screenshots for Light and Dark modes are included in this folder.

## Not verified

- Android Gradle compilation / APK generation / installation: not performed. This environment has no Gradle executable or Gradle wrapper in the supplied project.
- Physical Android touch feel, OEM gesture conflicts, Android WebView rendering, low-end frame rate, and real-device memory/performance: not tested.
- The tests cannot guarantee that every OEM WebView version behaves identically to desktop Chromium.

**Conclusion:** the targeted browser regressions pass. This is not a claim of a successfully built or device-tested APK.
