import json, sys, datetime
from playwright.sync_api import sync_playwright
HTML='file:///home/claude/OPUX_2_2/app/src/main/assets/index.html'
legacy=open('legacy.json').read()
errs=[];res=[]
def ok(n,c,info=''):
  res.append((n,bool(c))); print(('PASS ' if c else 'FAIL ')+n+(' '+str(info) if (info!='' and not c) else ''))
with sync_playwright() as p:
  b=p.chromium.launch()
  ctx=b.new_context(viewport={'width':390,'height':844},has_touch=True,device_scale_factor=2)
  ctx.add_init_script("if(!sessionStorage.getItem('seeded')){localStorage.setItem('h24v1',%s);sessionStorage.setItem('seeded','1')}"%json.dumps(legacy))
  pg=ctx.new_page()
  pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
  pg.on('console',lambda m:errs.append('CONSOLE '+m.text) if m.type=='error' else None)
  pg.goto(HTML);pg.wait_for_timeout(3000);pg.evaluate("document.getElementById('opux-boot')&&document.getElementById('opux-boot').remove()")
  E=pg.evaluate
  days0=E("JSON.stringify(S.days)")
  # --- productivity
  ok('legacy p:1 -> Productive Work',E("S.acts[0].cls==='w'&&S.acts[1].cls===undefined"))
  exp=E("recDays().map(d=>[d,S.days[d].filter(e=>e.act==='a0').reduce((s,e)=>s+e.min,0)]).sort((a,b)=>b[1]-a[1])[0][1]")
  ok('most productive = max Study minutes',E("pxBest(recDays()).b.w")==exp)
  ok('longest tracked day is not auto-best',E("(()=>{const d=recDays().sort((a,b)=>tot(b)-tot(a))[0];return pxBest(recDays()).b.d!==d})()"))
  ok('unclassified not productive',E("aggCls(recDays()).u>0&&aggCls(recDays()).w===recDays().reduce((s,d)=>s+prod(d),0)"))
  ok('t = w+n+l+u each day',E("recDays().every(d=>{const c=dayCls(d);return Math.abs(c.t-(c.w+c.n+c.l+c.u))<1e-6})"))
  # reclassify with history: from today only
  E("go('pr')");pg.wait_for_timeout(300)
  idx=2 # Entertainment
  E("clsPick(2,'l')");pg.wait_for_timeout(200)
  ok('sheet shown for history change',E("SHO===1&&!!document.querySelector('#md .sheet')"))
  past=E("dayCls(add(todayS(),-2)).l")
  E("applyClsGo('a2','l','from')");pg.wait_for_timeout(200)
  ok('from-today keeps past unchanged',E("dayCls(add(todayS(),-2)).l")==past==0)
  ok('today now leisure',E("dayCls(todayS()).l")>0)
  ok('history entry logged',E("X().cl.length")==1)
  E("clsLogDel(0)") if False else None
  pg.once('dialog',lambda d:d.accept());E("clsLogDel(0)");pg.wait_for_timeout(100)
  ok('undo from-history restores',E("X().cl.length")==0 and E("dayCls(todayS()).l")==0)
  E("clsPick(2,'l')");E("applyClsGo('a2','l','all')")
  ok('apply-all changes past',E("dayCls(add(todayS(),-2)).l")>0)
  ok('time entries untouched by reclassify',E("JSON.stringify(S.days)")==days0)
  ok('p flag synced (w only)',E("S.acts.every(a=>a.p===(curCls(a)==='w'?1:0))"))
  # new activity classification
  E("S.acts.push({id:'aT',n:'Chem',c:'#ff0000',p:0});clsPick(S.acts.length-1,'w')")
  ok('no-history class applies silently',E("curCls(S.acts[S.acts.length-1])==='w'")and E("SHO===0"))
  # export/import roundtrip
  ex=E("JSON.stringify(S)")
  r=E("(()=>{const o=clean(JSON.parse(JSON.stringify(S)));return typeof o==='object'&&o.acts.find(a=>a.id==='a2').cls==='l'&&JSON.stringify(o.days)===JSON.stringify(S.days)})()")
  ok('export->import keeps cls and days',r)
  ok('old backup w/o ext imports',E("typeof clean(%s)==='object'"%legacy))
  ok('hostile ext sanitised',E("(()=>{const o=clean(Object.assign((%s),{ext:{cl:[{a:'<x>',d:'bad',c:'z'}],wh:[{id:'q',o:[{id:'1',t:'<b>'}]}],fx:{on:1,dur:99999,a:''}}}));return o.ext.cl.length===0&&o.ext.fx.on===0&&o.ext.fx.dur<=480})()"%legacy))
  # --- other screens render
  views=['ho','st','hi','rc','mo','se','so','th','br','rd','pr','pl','pw','pc','pn','pd','pt','pf','ai','aid','aip','ait','aiw','ais','tr']
  bad=[]
  for v in views:
    E("tab('ho')");E("V.v==='ho'");E("go('%s')"%v if v not in ['ho','st','hi','rc','mo'] else "tab('%s')"%v);pg.wait_for_timeout(250)
    if not E("document.querySelector('#app').innerText.length>20"): bad.append(v)
  ok('all screens render',not bad,bad)
  # --- wheel
  E("tab('ho');go('pw')");pg.wait_for_timeout(300)
  ok('wheel canvas drawn',E("(()=>{const c=$('#wcv');return c&&c.width>100})()"))
  chi=E("(()=>{const n=5,c=Array(n).fill(0),N=100000;for(let i=0;i<N;i++)c[rint(n)]++;const e=N/n;return c.reduce((s,x)=>s+(x-e)**2/e,0)})()")
  ok('rint unbiased (chi2 df4 <18.5)',chi<18.5,chi)
  ok('rint non-power-of-2 bounds',E("(()=>{let m=0,M=0;for(let i=0;i<50000;i++){const v=rint(7);m=Math.min(m,v);M=Math.max(M,v)}return m===0&&M===6})()"))
  E("X().rm='on';X().cn.h=[]; window._r=[];window._ri=rint;window.rint=function(n){const v=window._ri(n);window._r.push(v);return v}")
  mism=0
  for i in range(4):
    E("W22.sp=false;wheelSpin()");pg.wait_for_timeout(1500)
    w=E("[W22.res&&W22.res.i,(_r.find(q=>q[0]===curWheel().o.length)||[0,-1])[1],wIdx(W22.rot,curWheel().o.length)]")
    E("_r.length=0")
    if not(w[0]==w[1]==w[2]): mism+=1
  ok('wheel lands on drawn winner (4 spins)',mism==0,w)
  E("window.rint=window._ri;X().rm='auto'")
  # geometry check without animation across many wheel sizes
  geo=E("(()=>{const T=Math.PI*2;let bad=0;for(let n=2;n<=24;n++)for(let t=0;t<300;t++){const win=Math.floor(Math.random()*n),seg=T/n,u=.1+.8*Math.random(),target=-(win+u)*seg;let end=Math.random()*50+5*T;end+=((target-end)%T+T)%T;if(wIdx(end,n)!==win)bad++}return bad})()")
  ok('wheel angle math exact (7k cases)',geo==0,geo)
  E("wheelAdd()") 
  E("document.querySelector('#wnew').value='Third';wheelAdd()");ok('wheel add option',E("curWheel().o.length")==3)
  E("wheelOpt(2,'Maybe')");ok('wheel edit option',E("curWheel().o[2].t")=='Maybe')
  E("wheelDel(2)");ok('wheel remove option',E("curWheel().o.length")==2)
  E("wheelTpl('study')");ok('template wheel uses Productive Work activities',E("curWheel().n==='What should I study?'&&curWheel().o.some(o=>o.t==='Study')"),E("JSON.stringify(curWheel())"))
  ok('wheels persisted',E("JSON.parse(localStorage.getItem('h24v1')).ext.wh.length")>=2)
  # --- coin
  E("go('pc')") if E("V.v")!='pc' else None
  E("tab('ho');go('pc')");pg.wait_for_timeout(300)
  E("X().cn.h=[];save()")
  E("CN.n=1;coinFlip()");pg.wait_for_timeout(2300)
  ok('coin flip logged',E("X().cn.h.length")==1)
  ok('coin face transform matches result',E("(()=>{const r=X().cn.h[0].t,tr=$('#coin')&&$('#coin').style.transform;return tr.includes(r==='T'?'180':'(0')})()"))
  E("CN.n=10;coinFlip()");pg.wait_for_timeout(9000)
  ok('10-flip series logged',E("X().cn.h.length")==11,E("X().cn.h.length"))
  c=E("(()=>{let h=0,N=60000;for(let i=0;i<N;i++)h+=rint(2);return h/N})()");ok('coin fair (60k)',abs(c-.5)<.01,c)
  pg.once('dialog',lambda d:d.accept());E("coinReset()");ok('coin reset',E("X().cn.h.length")==0)
  # --- random number
  E("tab('ho');go('pn')");E("X().rn.min=-3;X().rn.max=4;save()")
  cnt=E("(()=>{const c={};for(let i=0;i<40000;i++){const v=X().rn.min+rint(X().rn.max-X().rn.min+1);c[v]=(c[v]||0)+1}return c})()")
  ok('rng range inclusive & uniform',sorted(map(int,cnt.keys()))==list(range(-3,5)) and all(abs(v-5000)<400 for v in cnt.values()),cnt)
  E("render();document.querySelector('#rnmin').value=9;document.querySelector('#rnmax').value=2");ok('rng rejects min>max',E("rnSet()")==False)
  # --- decision picker
  E("tab('ho');go('pd')");E("DP.items=['A','B','C'];X().pk.last='A\\nB\\nC';render();$('#dpn').value='Set1';dpSave()")
  ok('decision set saved',E("X().pk.list.length")==1)
  # --- focus
  E("tab('ho');go('pf')");E("fsStart('a0')");pg.wait_for_timeout(1200)
  ok('focus running',E("X().fx.on===1&&fsElapsed()>1000"))
  E("fsPause()");a=E("fsElapsed()");pg.wait_for_timeout(600);ok('pause stops clock',abs(E("fsElapsed()")-a)<5)
  E("fsResume()");before=E("tot(todayS())")
  E("fsFinish()");ok('no tracker write before confirm',E("tot(todayS())")==before)
  E("$('#fsm').value=10;fsConfirm()");pg.wait_for_timeout(200)
  ok('confirm records to tracker (+10)',abs(E("tot(todayS())")-before-10)<1e-6 and E("X().fs.length")==1)
  # --- AI prompts use real data
  E("tab('ho');go('aid');V.ai.dbOn=0;render()");ok('brief shows button before prompt',E("!$('#aip')"));E("V.ai.dbOn=1;render()");pg.wait_for_timeout(300)
  t=E("$('#aip').value");d=E("dayCls(todayS())")
  ok('daily brief has real tracked',('Tracked: %dh %02dm'%(int(d['t'])//60,int(d['t'])%60)) in t,t[:200])
  ok('daily brief has focus session',('10m' in t) and 'Focus' in t or 'focus' in t.lower())
  ok('daily brief says no task list',"no task list" in t)
  E("V.ai.pd=7;go('aip')") if False else None
  E("tab('ho');go('aip')");pg.wait_for_timeout(200);t=E("$('#aip').value");ok('analysis has daily rows',t.count('|')>20 and 'CHANGE VS THE PREVIOUS' in t)
  E("tab('ho');go('aiw')");pg.wait_for_timeout(200);t=E("$('#aip').value");ok('weekly has strongest/weakest',('Strongest day' in t) and ('Weakest recorded day' in t) and 'MISSING DATA' in t)
  E("V.ai.wk=-30;render()");ok('empty week -> empty state not fake prompt',E("!$('#aip')"))
  E("V.ai.wk=0;tab('ho');go('ait')");E("V.ai.tb.t='Physics mock exam';render()");t=E("$('#aip').value");ok('task breakdown prompt',('Physics mock exam' in t) and 'first action' in t.lower())
  # studio
  E("tab('ho');go('ais')");ok('starter prompts seeded',E("X().pr.length")==5)
  E("promptEdit('');$('#pen').value='Mine';$('#pec').value='Study';$('#peb').value='Hi {{most_productive_day}} {{nope}}';promptSave()")
  ok('create prompt',E("X().pr.some(p=>p.n==='Mine')"))
  E("promptUse(X().pr.find(p=>p.n==='Mine').id)");t=E("$('#aip').value");ok('placeholder expanded, unknown left',('Most productive day:' in t) and '{{nope}}' in t,t)
  E("closeSheet()")
  pg.once('dialog',lambda d:d.accept());E("promptDel(X().pr.find(p=>p.n==='Mine').id)");ok('delete prompt',not E("X().pr.some(p=>p.n==='Mine')"))
  # copy
  ctx.grant_permissions(['clipboard-read','clipboard-write'])
  ok('copyText returns',E("copyText('abc')")in(True,False,None))
  # --- Home atom
  E("tab('ho')");pg.wait_for_timeout(1800)
  ok('atlas canvas present',E("!!document.querySelector('.atlas-cv')&&ATL.W>100"))
  box=pg.evaluate("(()=>{const r=document.querySelector('.atlas-cv').getBoundingClientRect();return[r.left,r.top,r.width,r.height]})()")
  hit=E("(()=>{const e=ATL.el[0].p;return[e[0],e[1]]})()")
  pg.mouse.click(box[0]+hit[0],box[1]+hit[1]);pg.wait_for_timeout(300)
  ok('tap electron shows info',E("document.getElementById('atlas-tip').classList.contains('on')&&document.getElementById('atlas-tip').innerText.length>3"))
  y0=E("ATL.yaw");pg.mouse.move(box[0]+30,box[1]+box[3]-20);pg.mouse.down();pg.mouse.move(box[0]+150,box[1]+box[3]-20,steps=8);pg.mouse.up();pg.wait_for_timeout(100)
  ok('drag rotates view',abs(E("ATL.yaw")-y0)>.3)
  pg.screenshot(path='s_home2.png')
  # frame rate
  fps=E("new Promise(r=>{let n=0,t0=performance.now();const f=()=>{n++;if(performance.now()-t0>2000)r(n/2);else requestAnimationFrame(f)};f()})");print('rAF fps (headless, software):',fps)
  ok('data not mutated by any feature (days superset)',E("Object.keys(JSON.parse(%s)).every(d=>JSON.stringify(S.days[d]).length>0)"%json.dumps(days0)))
  print('JS errors:',errs)
  # reduced motion
  ctx2=b.new_context(viewport={'width':390,'height':844},reduced_motion='reduce')
  ctx2.add_init_script("localStorage.setItem('h24v1',%s)"%json.dumps(legacy))
  p2=ctx2.new_page();p2.on('pageerror',lambda e:errs.append('RM PAGEERR '+str(e)));p2.goto(HTML);p2.wait_for_timeout(2500);p2.evaluate("document.getElementById('opux-boot')&&document.getElementById('opux-boot').remove()")
  p2.wait_for_timeout(500)
  ok('reduced motion: atom static (no rAF loop)',p2.evaluate("ATL.rm===true&&ATL.raf===0"))
  p2.evaluate("go('pc')");p2.wait_for_timeout(200)
  p2.evaluate("coinFlip()");p2.wait_for_timeout(900);ok('reduced motion: coin still resolves',p2.evaluate("X().cn.h.length===1"))
  ok('rm override setting',p2.evaluate("(X().rm='off',RM()===false)"))
  ok('no js errors',not errs,errs)
  b.close()
print('\n%d/%d passed'%(sum(1 for _,c in res if c),len(res)))
