from playwright.sync_api import sync_playwright
from pathlib import Path
PROJECT=Path(__file__).resolve().parents[2]
html=(PROJECT/'app/src/main/assets/index.html').read_text(encoding='utf-8')
results=[]
def check(name, ok, detail=''):
    results.append(bool(ok)); print(('PASS ' if ok else 'FAIL ')+name+((' — '+str(detail)) if detail and not ok else ''))
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    page=ctx.new_page(); errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html,wait_until='load'); page.wait_for_timeout(1200)
    page.evaluate("document.getElementById('opux-boot')?.remove(); tab('mo'); go('th')")
    page.wait_for_timeout(100)
    names=['graphite','midnight','daylight','paper','classic','ocean','sunset','neon','forest','pastel']
    for mode in ['dark','light']:
        page.evaluate(f"setThemeMode('{mode}')")
        for name in names:
            page.evaluate(f"setThemePalette('{name}')")
            vals=page.evaluate("""()=>{const b=[...document.querySelectorAll('.th button')];const cs=b.map(x=>getComputedStyle(x));const root=getComputedStyle(document.documentElement);return {count:b.length,bg:new Set(cs.map(x=>x.backgroundColor)).size,fg:new Set(cs.map(x=>x.color)).size,swatches:new Set(b.map(x=>getComputedStyle(x.querySelector('span')).backgroundImage)).size,rootBg:root.backgroundColor,rootTx:root.getPropertyValue('--tx').trim(),labels:b.map(x=>x.innerText.trim())}}""")
            check(f'{mode}/{name}: all 10 palette cards render', vals['count']==10 and len(vals['labels'])==10)
            check(f'{mode}/{name}: palette cards share one surface', vals['bg']==1, vals['bg'])
            check(f'{mode}/{name}: palette card labels share readable foreground', vals['fg']==1 and vals['fg']!='rgba(0, 0, 0, 0)', vals['fg'])
            check(f'{mode}/{name}: all ten previews retain distinct palette colours', vals['swatches']==10, vals['swatches'])
    # Swipe completion: destination page should already be in #app before peek is removed.
    page.evaluate("tab('ho')")
    cdp=ctx.new_cdp_session(page)
    cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':340,'y':430}]})
    for x in [310,280,250,220,190,160]:
        cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':430}]}); page.wait_for_timeout(18)
    cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
    page.wait_for_timeout(650)
    state=page.evaluate("""()=>({view:V.v,heading:document.querySelector('#screen-intro')?.innerText||'',summary:!!document.querySelector('#screen-summary'),peek:!!document.querySelector('#pg-peek'),transform:document.querySelector('#app').style.transform,opacity:document.querySelector('#app').style.opacity})""")
    check('swipe destination becomes Stats',state['view']=='st',state)
    check('destination top intro is present after transition','PATTERNS & SIGNAL' in state['heading'],state['heading'])
    check('swipe leaves no stale peek or transform',not state['peek'] and state['transform']=='')
    check('no JavaScript page errors',not errors,errors)
    b.close()
print(f'{sum(results)}/{len(results)} passed')
