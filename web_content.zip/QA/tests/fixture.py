import json, datetime, random
random.seed(7)
today=datetime.date.today()
acts=[{"id":"a0","n":"Study","c":"#3b82f6","p":1},{"id":"a1","n":"Sleep","c":"#22c55e","p":0},{"id":"a2","n":"Entertainment","c":"#f97316","p":0},{"id":"a3","n":"Namaz","c":"#a855f7","p":0},{"id":"a4","n":"Meals","c":"#eab308","p":0},{"id":"a5","n":"Other","c":"#cbd5e1","p":0},{"id":"a6","n":"Wasted","c":"#6b7280","p":0},{"id":"a7","n":"Project","c":"#14b8a6","p":0}]
days={}
for i in range(0,21):
    d=today-datetime.timedelta(days=i)
    if i in (3,9,10): continue          # gaps = days with no record
    ent=[]
    rem=1440
    for a,lo,hi in [("a1",360,520),("a0",0,300),("a7",0,180),("a2",20,240),("a4",40,90),("a3",20,40),("a6",0,60),("a5",0,60)]:
        m=min(rem,random.randrange(lo,hi+1,5)) if hi>lo else 0
        if m>0: ent.append({"act":a,"min":m,"note":"note %s"%a if a=="a0" else ""}); rem-=m
    days[d.isoformat()]=ent
# a day that is the longest tracked but NOT the most productive
d=(today-datetime.timedelta(days=15)).isoformat()
days[d]=[{"act":"a1","min":480,"note":""},{"act":"a2","min":600,"note":""},{"act":"a6","min":300,"note":""},{"act":"a0","min":60,"note":""}]
state={"acts":acts,"days":days,"theme":"graphite","unit":"hm","notif":0,"timer":None,"st":480,"clock":"24","dateFmt":"long"}
json.dump(state,open("legacy.json","w"))
print(len(days),"days; today",today)
