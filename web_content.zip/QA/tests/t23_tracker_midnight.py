import json
from playwright.sync_api import sync_playwright
res=[]
def ok(n,c,i=''):
    res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,'' if c else i)
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for tz in ['UTC','America/New_York','Asia/Karachi','Europe/London']:
    ctx=b.new_context(timezone_id=tz,viewport={'width':390,'height':800})
    pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.set_content(open('/mnt/data/opux_work/app/src/main/assets/index.html',encoding='utf-8').read(),wait_until='load');pg.wait_for_timeout(1500)
    E=pg.evaluate
    T=lambda y,m,d,h,mi=0:f"new Date({y},{m-1},{d},{h},{mi}).getTime()"
    r=E(f"splitSpan({T(2026,11,13,23)},{T(2026,11,14,1)})")
    ok(tz+' 23:00->01:00 =1h+1h',r==[{'d':'2026-11-13','min':60},{'d':'2026-11-14','min':60}],r)
    r=E(f"splitSpan({T(2026,11,13,22)},{T(2026,11,16,2)})")
    ok(tz+' multi-day',[x['d'] for x in r]==['2026-11-13','2026-11-14','2026-11-15','2026-11-16'] and [x['min'] for x in r]==[120,1440,1440,120],r)
    r=E(f"splitSpan({T(2028,2,28,23,30)},{T(2028,3,1,0,30)})")
    ok(tz+' leap day',[x['d'] for x in r]==['2028-02-28','2028-02-29','2028-03-01'] and r[1]['min']==1440,r)
    r=E(f"splitSpan({T(2026,12,31,23,45)},{T(2027,1,1,0,15)})")
    ok(tz+' year change',r==[{'d':'2026-12-31','min':15},{'d':'2027-01-01','min':15}],r)
    r=E(f"splitSpan({T(2026,11,13,10)},{T(2026,11,13,12)})")
    ok(tz+' same day single',r==[{'d':'2026-11-13','min':120}],r)
    r=E(f"splitSpan({T(2026,11,13,12)},{T(2026,11,13,12)})")
    ok(tz+' zero span empty',r==[])
    r=E("(()=>{const a=new Date(2026,2,8,22).getTime(),b=new Date(2026,2,9,2).getTime();const s=splitSpan(a,b);return [s,(b-a)/60000]})()")
    ok(tz+' DST-safe sum',abs(sum(x['min'] for x in r[0])-r[1])<0.01,r)
    # end-to-end timer stop crossing midnight
    E("""(()=>{S.days={};const R0=Date.now;const st=new Date(2026,10,13,23,0).getTime(),en=new Date(2026,10,14,1,0).getTime();
      Date.now=()=>en;S.timer={a:'a0',d:'2026-11-14',t:st};stopT();Date.now=R0})()""")
    d=E("JSON.stringify([S.days['2026-11-13'],S.days['2026-11-14'],S.timer])")
    ok(tz+' stopT split 1h/1h',d=='[[{"act":"a0","min":60,"note":"Timer"}],[{"act":"a0","min":60,"note":"Timer"}],null]',d)
    # prior content preserved, post-midnight piece placed at front
    E("""(()=>{S.days={'2026-11-14':[{act:'a1',min:300,note:''}],'2026-11-13':[{act:'a1',min:1000,note:''}]};
      const en=new Date(2026,10,14,1,0).getTime();Date.now=()=>en;S.timer={a:'a0',d:'x',t:new Date(2026,10,13,23,0).getTime()};stopT()})()""")
    d=E("[S.days['2026-11-13'].map(e=>e.min),S.days['2026-11-14'].map(e=>e.min),tot('2026-11-13'),tot('2026-11-14')]")
    ok(tz+' existing kept, order',d==[[1000,60],[60,300],1060,360],d)
    # day full clamp (no overflow)
    E("""(()=>{S.days={'2026-11-13':[{act:'a1',min:1430,note:''}]};const en=new Date(2026,10,14,1,0).getTime();Date.now=()=>en;S.timer={a:'a0',d:'x',t:new Date(2026,10,13,23,0).getTime()};window.alert=()=>{};stopT()})()""")
    d=E("[tot('2026-11-13'),tot('2026-11-14')]")
    ok(tz+' clamp at 24h',d==[1440,60],d)
    # check-in strict, crossing midnight
    E("""(()=>{S.days={};const en=new Date(2026,10,14,1,0).getTime();Date.now=()=>en;V.v='ho';render();openCheckin(true);$('#ci-hours').value=2;$('#ci-minutes').value=0;$('#ci-act').value='a1';ciPreview();window.__pv=$('#ci-split').textContent;saveCheckin()})()""")
    d=E("[S.days['2026-11-13'],S.days['2026-11-14'],__pv]")
    ok(tz+' check-in split',d[0][0]['min']==60 and d[1][0]['min']==60 and 'crosses midnight' in d[2],d)
    # strict failure writes nothing
    E("""(()=>{S.days={'2026-11-13':[{act:'a1',min:1430,note:''}]};const en=new Date(2026,10,14,1,0).getTime();Date.now=()=>en;openCheckin(true);$('#ci-hours').value=2;$('#ci-minutes').value=0;saveCheckin()})()""")
    d=E("[tot('2026-11-13'),tot('2026-11-14'),$('#ci-error').textContent]")
    ok(tz+' strict rejects, nothing written',d[0]==1430 and d[1]==0 and 'free' in d[2],d)
    # focus segments across midnight with a pause
    E("""(()=>{S.days={};X().fs=[];const f=X().fx;f.on=1;f.a='a0';f.dur=120;f.acc=0;f.dn=0;f.sg=[[new Date(2026,10,13,23,0).getTime(),new Date(2026,10,13,23,30).getTime()],[new Date(2026,10,14,0,30).getTime(),new Date(2026,10,14,1,30).getTime()]];f.acc=90*60000;f.run=0;
      openSheet('<input id=fsm><p id=fse></p>');$('#fsm').value=90;fsConfirm()})()""")
    d=E("[S.days['2026-11-13'],S.days['2026-11-14'],X().fs.map(s=>[s.d,s.min])]")
    ok(tz+' focus segments (pause not counted)',d[0][0]['min']==30 and d[1][0]['min']==60 and d[2]==[['2026-11-13',30],['2026-11-14',60]],d)
    ok(tz+' no page errors',not errs,errs)
    ctx.close()
  b.close()
print(sum(res),'/',len(res))
