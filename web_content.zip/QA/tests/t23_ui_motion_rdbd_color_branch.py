import json
from playwright.sync_api import sync_playwright
res=[]
def ok(n,c,i=''):
    res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,'' if c else i)
URL='file:///home/claude/src/app/src/main/assets/index.html'
with sync_playwright() as p:
  b=p.chromium.launch()
  ctx=b.new_context(viewport={'width':390,'height':800},has_touch=True,is_mobile=True)
  pg=ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append(m.text) if m.type=='error' else None)
  pg.goto(URL);pg.wait_for_timeout(1500);pg.evaluate("document.getElementById('opux-boot')&&document.getElementById('opux-boot').remove()")
  E=pg.evaluate;cdp=ctx.new_cdp_session(pg)
  def touch(pts,final=True):
      cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':pts[0][0],'y':pts[0][1]}]})
      for x,y in pts[1:]:
          cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':y}]});pg.wait_for_timeout(16)
      return
  def end(): cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]})
  def path(x0,y0,dx,dy,n=10): return [(x0+dx*i/n,y0+dy*i/n) for i in range(n+1)]
  E("V.v='ho';render()");pg.wait_for_timeout(300)
  # 1 mid-drag: page follows finger, peek exists
  touch(path(330,400,-192,0));
  tr=E("document.getElementById('app').style.transform");pk=E("!!document.getElementById('pg-peek')")
  ok('page follows finger (transform tracks drag)','-1' in tr and 'translate3d' in tr,tr);ok('destination peek layer present',pk)
  pkx=E("document.getElementById('pg-peek').style.transform");ok('peek enters from right',0<float(pkx.split('(')[1].split('px')[0])<390,pkx)
  end();pg.wait_for_timeout(700)
  ok('long drag completes -> Stats',E("V.v")=='st',E("V.v"));ok('layers cleaned',E("!document.getElementById('pg-peek')&&!document.getElementById('app').style.transform"))
  # 2 short slow drag cancels
  touch(path(300,400,-50,0));end();pg.wait_for_timeout(700)
  ok('short drag cancels, stays on Stats',E("V.v")=='st');ok('cancel restores position',E("document.getElementById('app').style.transform")=='' )
  # 3 fast flick completes
  touch([(330,400),(300,400),(270,400),(240,400),(210,400)]);end();pg.wait_for_timeout(700)
  ok('fast flick completes (velocity)',E("V.v")=='hi',E("V.v"))
  # 4 swipe back direction
  touch(path(60,400,230,0));end();pg.wait_for_timeout(700)
  ok('swipe right goes to previous tab',E("V.v")=='st',E("V.v"))
  # 5 vertical drag does not navigate
  touch(path(200,300,10,-150));end();pg.wait_for_timeout(500)
  ok('vertical gesture ignored',E("V.v")=='st')
  # 6 edge: first tab rubber band, no nav
  E("tab('ho')");pg.wait_for_timeout(300)
  touch(path(100,400,200,0));mid=E("document.getElementById('app').style.transform");end();pg.wait_for_timeout(600)
  ok('first tab: rubber-band only, no nav',E("V.v")=='ho' and not E("!!document.getElementById('pg-peek')"),mid)
  # 7 subpage swipe-right = back
  E("go('se')");pg.wait_for_timeout(500)
  touch(path(60,400,230,0));end();pg.wait_for_timeout(700)
  ok('sub-page swipe right goes back',E("V.v")=='ho',E("V.v"))
  # 8 inputs excluded
  E("go('se')");pg.wait_for_timeout(500)
  pt=E("(()=>{const i=document.querySelector('#app input[type=number],#app select');const r=i.getBoundingClientRect();return [r.left+10,r.top+r.height/2]})()")
  touch(path(pt[0],pt[1],200,0));end();pg.wait_for_timeout(600)
  ok('swipe starting on input/select ignored',E("V.v")=='se',E("V.v"))
  # 9 modal open blocks
  E("tab('ho')");pg.wait_for_timeout(300);E("openSheet('<p>x</p>')")
  touch(path(300,300,-200,0));end();pg.wait_for_timeout(500);ok('no swipe while dialog open',E("V.v")=='ho');E("closeSheet()")
  # 10 touchcancel
  touch(path(330,400,-120,0),False);cdp.send('Input.dispatchTouchEvent',{'type':'touchCancel','touchPoints':[]});pg.wait_for_timeout(700)
  ok('touchcancel leaves clean state',E("V.v")=='ho' and not E("!!document.getElementById('pg-peek')") and E("document.getElementById('app').style.transform")=='')
  # toast + alert
  E("toast('https://example.com/x updated')");ok('URL toast sanitised',E("document.querySelector('#toast span').textContent")=='Changes saved',E("document.querySelector('#toast span').textContent"))
  E("alert('Import failed: bad file')");ok('alert -> visible error toast',E("document.getElementById('toast').dataset.k")=='err')
  # RDBD
  E("""(()=>{X().rd.e=[{id:'q1',d:'2026-03-05',t:'Quote one',a:'Me',k:'q'},{id:'n1',d:'2026-04-09',t:'A long note '.repeat(30),a:'',k:'n'},{id:'n2',d:'2026-04-10',t:'Short note',a:'',k:'n'}];save();RDM=false;go('rd')})()""");pg.wait_for_timeout(500)
  t=E("document.getElementById('app').innerText")
  ok('quote date shown','Written' in t and '2026' in t and 'MARCH 5' in t.upper() or 'MAR' in t.upper(),t[:300])
  ok('notes visible in view mode with dates',E("document.querySelectorAll('.rd-note').length")==2 and 'April 9, 2026' in t and 'April 10, 2026' in t)
  ok('note expands on tap',E("(()=>{const n=document.querySelector('.rd-note:not(.short)');n.click();return n.classList.contains('open')})()"))
  ok('RETURN DAY BY DAY title text unchanged (CSS uppercase untouched)',E("[...document.querySelectorAll('#app small')].some(s=>s.textContent==='Return Day By Day')") and E("document.querySelector('#app h2').textContent")=='Return, day by day.')
  E("RDM=true;RE='n1';render()");ok('edit keeps original date',E("(()=>{$('#rt').value='edited';rdSave();return X().rd.e.find(e=>e.id==='n1').d})()")=='2026-04-09')
  # colour picker
  E("tab('mo');go('se')");pg.wait_for_timeout(400)
  before=E("S.acts.map(a=>a.c).join()")
  E("openColorPick(0)");pg.wait_for_timeout(300);ok('picker opens with 24 swatches',E("document.querySelectorAll('.cp-sw').length")==24)
  ok('current color marked selected or custom',E("document.querySelectorAll('.cp-sw.on').length")>=0)
  E("cpSet('#ec4899')");ok('selected state updates',E("document.querySelector('.cp-sw.on').getAttribute('aria-label')")=='#ec4899')
  E("cpSave()");pg.wait_for_timeout(200);after=E("S.acts.map(a=>a.c).join()")
  ok('only edited activity changed',before.split(',')[1:]==after.split(',')[1:] and after.split(',')[0]=='#ec4899',after)
  ok('stored hex passes validator',E("clean(JSON.parse(JSON.stringify(S)))")!=None and E("typeof clean(JSON.parse(JSON.stringify(S)))")=='object')
  E("openColorPick(-1);cpSet('#14b8a6');cpSave();$('#na').value='Gym';addA()");ok('new activity keeps chosen colour',E("S.acts[S.acts.length-1].c")=='#14b8a6')
  ok('motion setting present',E("!!document.getElementById('motion-settings')"))
  E("setMo('off')");ok('motion off stored + applied',E("S.ext.mo")=='off' and E("document.documentElement.dataset.mo")=='off');E("setMo('full')")
  # persistence round trip with ext.mo + backup
  ok('export/import round-trip keeps mo',E("(()=>{const o=clean(JSON.parse(JSON.stringify(S)));return typeof o==='object'&&o.ext.mo==='full'})()"))
  # branch
  E("go('br')");pg.wait_for_timeout(300);E("""(()=>{$('#bn').value='T';newBr(3)})()""");pg.wait_for_timeout(900)
  ok('branch renders nodes',E("document.querySelectorAll('#bg g[data-id]').length")>=4)
  ok('breathing class applied (full)',E("document.querySelectorAll('#bg .in.br').length")>=4)
  ok('flow overlays present',E("document.querySelectorAll('#bg path.fl').length")>=3)
  E("selNode(curB().nodes[1].id)");pg.wait_for_timeout(500)
  ok('selection highlights edge + neighbour',E("document.querySelectorAll('#bg path.ed.hot').length")>=1 and E("document.querySelectorAll('#bg .in.nb,#bg .in.sl').length")>=2 and E("document.getElementById('bg').classList.contains('has-sel')"))
  E("closeSP();beginBranchEdit()");pg.wait_for_timeout(300);pos0=E("curB().nodes.map(n=>[n.x,n.y])")
  E("setLay('tree')");pg.wait_for_timeout(250);mid=E("curB().nodes.map(n=>[n.x,n.y])");pg.wait_for_timeout(900)
  pos1=E("curB().nodes.map(n=>[n.x,n.y])")
  ok('layout change animates (intermediate positions)',mid!=pos0 and mid!=pos1)
  ok('layout settles + data intact',len(pos1)==len(pos0) and E("curB().lay")=='tree' and E("curB().nodes.length")==len(pos0))
  E("setMo('lite')");pg.wait_for_timeout(200);E("drawBW()");ok('balanced mode: no ambient breathing',E("document.querySelectorAll('#bg .in.br').length")==0)
  ok('no page errors',not errs,errs)
  b.close()
print(sum(res),'/',len(res))
