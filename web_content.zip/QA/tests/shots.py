import json
from playwright.sync_api import sync_playwright
HTML='file:///home/claude/OPUX_2_2/app/src/main/assets/index.html'
legacy=open('legacy.json').read()
with sync_playwright() as p:
  b=p.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844},device_scale_factor=1.5,has_touch=True)
  ctx.add_init_script("localStorage.setItem('h24v1',%s)"%json.dumps(legacy))
  pg=ctx.new_page();pg.on('pageerror',lambda e:print('ERR',e));pg.goto(HTML);pg.wait_for_timeout(2500);E=pg.evaluate
  E("document.getElementById('opux-boot')&&document.getElementById('opux-boot').remove()")
  def shot(n,js,wait=700,full=False):
    E(js);pg.wait_for_timeout(wait);pg.screenshot(path='v_%s.png'%n,full_page=full)
  shot('home',"tab('ho')",2000)
  shot('pr',"go('pr')",400)
  shot('pl',"tab('mo');go('pl')",800)
  shot('pw',"go('pw')",800)
  shot('pc',"tab('mo');go('pl');go('pc')",800)
  shot('ai',"tab('mo');go('ai')",500)
  shot('aid',"go('aid')",500)
  shot('pf',"tab('mo');go('pl');go('pf')",500)
  shot('se',"tab('mo');go('se')",500,True)
  b.close()
