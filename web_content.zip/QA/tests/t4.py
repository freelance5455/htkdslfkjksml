import json
from playwright.sync_api import sync_playwright
HTML='file:///home/claude/src/app/src/main/assets/index.html'
legacy=open('legacy.json').read()
with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',);ctx=b.new_context(viewport={'width':390,'height':844})
  ctx.add_init_script("localStorage.setItem('h24v1',%s)"%json.dumps(legacy))
  pg=ctx.new_page();pg.goto(HTML);pg.wait_for_timeout(2500);E=pg.evaluate
  E("document.getElementById('opux-boot')&&document.getElementById('opux-boot').remove()")
  E("go('pw');X().rm='on';curWheel().o=['A','B','C','D','E','F'].map(t=>({id:uid(),t}));save();render();window._r=[];window._ri=rint;window.rint=function(n){const v=window._ri(n);window._r.push([n,v]);return v}");pg.wait_for_timeout(300)
  bad=0;seen=set()
  for i in range(12):
    E("_r.length=0;wheelSpin()");pg.wait_for_timeout(1500)
    draw=E("_r.find(q=>q[0]===6)[1]");res=E("W22.res&&W22.res.i");idx=E("wIdx(W22.rot,6)");seen.add(res)
    if not(draw==res==idx): bad+=1;print('MISMATCH',draw,res,idx)
  print('mismatches',bad,'of 12; distinct winners',sorted(seen))
  b.close()
