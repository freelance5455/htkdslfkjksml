"""2.3.3: swipe preview must match the committed page; nav highlight must follow the swipe."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image, ImageChops
import io
PROJECT=Path(__file__).resolve().parents[2]
html=(PROJECT/'app/src/main/assets/index.html').read_text(encoding='utf-8')
legacy=(Path(__file__).parent/'legacy.json').read_text()
res=[]
def check(n,ok,d=''):
    res.append(bool(ok)); print(('PASS ' if ok else 'FAIL ')+n+((' — '+str(d)) if d and not ok else ''))
SEL="""()=>{const r=document.querySelector('#pg-peek .pg-in')||document.querySelector('#app');return [...r.children].map(c=>[Math.round(c.getBoundingClientRect().top),Math.round(c.getBoundingClientRect().height)])}"""
with sync_playwright() as p:
    b=p.chromium.launch(args=['--no-sandbox'])
    ctx=b.new_context(viewport={'width':360,'height':800},has_touch=True,is_mobile=True)
    ctx.add_init_script("localStorage.setItem('h24v1',%s)"%json.dumps(legacy))
    pg=ctx.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.set_content(html,wait_until='load'); pg.wait_for_timeout(2500)
    pg.evaluate("document.getElementById('opux-boot')?.remove()"); cdp=ctx.new_cdp_session(pg)
    def touch(t,x=None): cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[{'x':x,'y':430}] if x is not None else []})
    nav=lambda: pg.evaluate("[...document.querySelectorAll('#nav .on')].map(x=>x.dataset.v)")
    PRI=['ho','st','hi','rc','mo']
    for i in range(4):
        a,z=PRI[i],PRI[i+1]
        for direction,(s,d,f,t) in (('fwd',(a,z,320,40)),('back',(z,a,40,320))):
            pg.evaluate(f"tab('{s}')"); pg.wait_for_timeout(600)
            touch('touchStart',f); 
            for k in range(1,9): touch('touchMove',f+(t-f)*k/8); pg.wait_for_timeout(16)
            peek=pg.evaluate(SEL); n_mid=nav()
            touch('touchEnd'); pg.wait_for_timeout(900)
            real=pg.evaluate(SEL)
            check(f'{s}->{d}: preview layout equals committed layout',peek==real,(peek,real))
            check(f'{s}->{d}: nav highlight already on destination before release',n_mid==[d],n_mid)
            check(f'{s}->{d}: final nav + view correct',nav()==[d] and pg.evaluate('V.v')==d)
    # cancelled swipe restores nav highlight
    pg.evaluate("tab('ho')"); pg.wait_for_timeout(500)
    touch('touchStart',320)
    for k in range(1,9): touch('touchMove',320-30*k); pg.wait_for_timeout(16)
    touch('touchMove',100); pg.wait_for_timeout(16)   # past halfway
    mid=nav()
    for k in range(5): touch('touchMove',100+40*k); pg.wait_for_timeout(16)
    touch('touchEnd'); pg.wait_for_timeout(800)
    check('cancelled swipe: stays on Home with Home highlighted',pg.evaluate('V.v')=='ho' and nav()==['ho'],(nav(),pg.evaluate('V.v')))
    check('cancelled swipe: no peek / transform left',pg.evaluate("!document.querySelector('#pg-peek')&&document.querySelector('#app').style.transform===''&&!document.querySelector('#app').classList.contains('pg-top')"))
    # no flat background painted over the page gradient on tab swipes
    pg.evaluate("tab('st')"); pg.wait_for_timeout(500); touch('touchStart',320)
    for k in range(1,6): touch('touchMove',320-30*k); pg.wait_for_timeout(16)
    bgA=pg.evaluate("getComputedStyle(document.querySelector('#app')).backgroundColor"); bgP=pg.evaluate("getComputedStyle(document.querySelector('#pg-peek')).backgroundColor")
    check('tab swipe leaves page gradient visible (panels transparent)',bgA=='rgba(0, 0, 0, 0)' and bgP=='rgba(0, 0, 0, 0)',(bgA,bgP))
    touch('touchEnd'); pg.wait_for_timeout(700)
    check('no JavaScript page errors',not errs,errs)
    b.close()
print(f'{sum(res)}/{len(res)} passed')
