# OPUX 2.1 QA report

Environment: headless Chromium, 390 × 844 viewport, synthetic localStorage fixture. These are browser tests, not Android-device tests.

| Test | Result |
|---|---|
| JavaScript syntax check | PASS |
| Legacy tracker data load and total calculation | PASS |
| Home screen and live local clock | PASS |
| Check-in modal and explicit activity selection | PASS |
| Check-in save (90 minutes) | PASS |
| Hour/minute manual entry (2h 15m = 135 minutes) | PASS |
| Overdue check-in prompt | PASS |
| 30-minute snooze | PASS |
| Check-in interval setting (60 → 90 minutes) | PASS |
| Branch View/Edit, Save/Cancel | PASS |
| Date format setting | PASS |
| RDBD automatic progression and edit interruption | PASS |
| Secondary screen render sweep | PASS |
| JavaScript page errors / console errors | 0 / 0 |

Not tested: Android Gradle build, APK installation, real Android WebView, sensors, file chooser/export, audio, haptics, and low-end device frame rate.
