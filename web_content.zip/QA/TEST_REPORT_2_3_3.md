# OPUX 2.3.3 — swipe/tab-transition glitch fixes

Basis: supplied 2.3.2 project. Reproduced in headless Chromium (360×800, touch) by replaying a swipe and sampling frames.

## Glitches found and fixed
1. **Layout jump when a swipe commits (6–13 px, Home: 129 px).** The preview layer (`#pg-peek`) was not covered by the `#app>h2`, `#app>.cd`, `#app .sg`, `#app .dp`, `#app h2 em` and `#app` padding rules, so headings, segmented controls and cards were different sizes in the preview. The preview now carries identical rules.
2. **Home preview missing blocks.** The check-in card (and the "Productive share" row) are injected after render, so Home appeared to load late. They are now mirrored in the preview (shared `checkinCardInner()`), as are the Tracker/History productivity card, the Tracker "Add hours / minutes" button and a correctly sized Tracker board placeholder.
3. **Bottom-bar highlight lagged.** The nav stayed on the old tab until release. It now switches at 50% swipe progress and restores on cancel.
4. **Page gradient flashed off.** Panels painted a flat `--bg` over the body gradient for the whole drag. Tab swipes now use transparent panels; only back-swipes use an opaque cover.

## Results
- `test_swipe_parity_2_3_3.py` (new): 28/28 PASS — preview layout == committed layout for all 8 adjacent tab swipes, nav highlight before release, cancel restores state, no stale layers, no JS errors.
- `test_theme_swipe_regressions.py`: 84/84. `t23_ui_motion_rdbd_color_branch.py`: 39/39. `t23_tracker_midnight.py`: 56/56.
- `node --check` on inline script: PASS.

## Not verified / known limits
- Not built or run on an Android device/WebView. Frame drops in the screen recording (stalls at tab switches) are device-performance related and cannot be measured in headless Chromium.
- Settings (`se`) as a back-swipe destination still omits three sections appended at the page bottom; no visible content shifts.
- The thin white vertical bar at the screen's left edge seen in the recording could not be reproduced here.
- The Tracker board preview is a blank placeholder of the correct size (not the live canvas).
