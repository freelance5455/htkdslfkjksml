GB STUDY — Android-friendly standalone build

Open GB_STUDY_Standalone.html in Chrome or another browser. All CSS, JavaScript and the app logo are embedded in the HTML, so it does not need separate image/CSS files.

Changes in this version:
- Admin can add a platform icon by uploading a photo OR pasting a direct image URL.
- Platform cards are narrower (about 1 cm inset on each side) with smaller icons/arrows and text wrapping to prevent overlap.
- External platform links use a direct anchor fallback in a new tab; Telegram join button remains a direct HTTPS link and opens in a new tab.
- Telegram popup defaults to every page load; admin can still change this in Settings.
- ZIP is designed to remain under 5 MB.

Demo admin password: ChangeMe123!

Important:
- The demo saves admin changes in this browser/device only. A public multi-user app needs a backend and real authentication.
- A website cannot force every Android browser to launch the standalone external browser or Telegram app; the browser/device decides that. This build avoids blocking the direct HTTPS link, and Telegram should open in Telegram when installed or in the browser otherwise.
- For best results, open the HTML in Chrome or a browser that permits local HTML files. If a file manager's preview blocks links, use the browser's Open with option.
