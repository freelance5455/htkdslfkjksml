package com.camstream.mobile

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*
import android.graphics.Typeface

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: View? = null
    companion object { @Volatile var frame="gaming"; @Volatile var frameColor="#ff4264"; private const val CHANNEL="cam_overlay" }
    override fun onCreate() { super.onCreate(); wm=getSystemService(WINDOW_SERVICE) as WindowManager; createChannel(); startForeground(91, notification()) }
    override fun onStartCommand(intent:Intent?, flags:Int, startId:Int):Int { if(intent?.action=="SHOW") showOverlay(); return START_STICKY }
    private fun notification():Notification {
        val stop=PendingIntent.getService(this,2,Intent(this,OverlayService::class.java).setAction("STOP"),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setContentTitle("CAM STREAM MOBILE").setContentText("Floating controls are active").setSmallIcon(android.R.drawable.presence_video_online).addAction(Notification.Action.Builder(null,"Close overlay",stop).build()).setOngoing(true).build()
    }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){ val c=NotificationChannel(CHANNEL,"Floating recorder controls",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
    private fun showOverlay() {
        if(view!=null)return
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,10,12,10); setBackground(shape(Color.argb(238,12,17,29),frameColor.toColor(),14)) }
        val top=TextView(this).apply { text="CAM  •  RECORDER"; setTextColor(Color.WHITE); textSize=12f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setPadding(2,2,2,9) }
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        fun control(label:String, action:()->Unit):TextView = TextView(this).apply { text=label; setTextColor(Color.WHITE); textSize=12f; gravity=Gravity.CENTER; setPadding(10,12,10,12); setOnClickListener{action()} }
        row.addView(control("REC") { Toast.makeText(this,"Start recording from the app dashboard",Toast.LENGTH_SHORT).show() })
        row.addView(control("Ⅱ") { Toast.makeText(this,"Pause control selected",Toast.LENGTH_SHORT).show() })
        row.addView(control("×") { stopSelf() })
        root.addView(top); root.addView(row)
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18; y=180 }
        var sx=0f; var sy=0f; var ox=0; var oy=0
        top.setOnTouchListener { _,e -> when(e.action){ MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=lp.x;oy=lp.y;true}; MotionEvent.ACTION_MOVE->{lp.x=ox-(e.rawX-sx).toInt();lp.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(root,lp);true};else->false} }
        view=root
        try { wm.addView(root,lp) } catch (_:Exception) { view=null; stopSelf() }
    }
    private fun shape(bg:Int,stroke:Int,r:Float)=GradientDrawable().apply{setColor(bg);setCornerRadius(r);setStroke(3,stroke)}
    private fun String.toColor():Int=try{Color.parseColor(this)}catch(_:Exception){Color.RED}
    override fun onDestroy(){ view?.let{try{wm.removeView(it)}catch(_:Exception){}};view=null;super.onDestroy() }
    override fun onBind(intent:Intent?)=null
}
