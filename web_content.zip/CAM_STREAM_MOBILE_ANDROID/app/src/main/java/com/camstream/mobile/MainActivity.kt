package com.camstream.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }
        web.addJavascriptInterface(OverlayBridge(this), "AndroidOverlay")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 700)
        } else startOverlay()
    }
    private fun startOverlay() {
        startForegroundService(Intent(this, OverlayService::class.java).setAction("SHOW"))
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==700 && Settings.canDrawOverlays(this)) startOverlay()
        else if(requestCode==700) Toast.makeText(this,"Overlay permission is required",Toast.LENGTH_LONG).show()
    }
    inner class OverlayBridge(private val activity: MainActivity) {
        @JavascriptInterface fun requestOverlay() { runOnUiThread { enableOverlay() } }
        @JavascriptInterface fun setFrame(name:String) { OverlayService.frame=name }
        @JavascriptInterface fun setFrameColor(color:String) { OverlayService.frameColor=color }
        @JavascriptInterface fun hideOverlay() { runOnUiThread { stopService(Intent(activity,OverlayService::class.java)) } }
    }
}
