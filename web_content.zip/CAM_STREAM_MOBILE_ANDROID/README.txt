CAM STREAM MOBILE — Android source project
=========================================
This is an Android Studio/Gradle project, not a standalone HTML file.

The app embeds the CAM STREAM MOBILE interface in a WebView and includes a native Android
foreground service that displays draggable floating controls over other apps.

IMPORTANT:
- First open Settings in the app and tap ENABLE OVERLAY.
- Android opens its system permission screen. Allow "Display over other apps".
- The overlay controls are a native system overlay.
- This starter overlay is a floating control panel. It does not yet connect its REC/PAUSE
  buttons to MediaProjection recording; the HTML browser recorder remains a separate capture
  flow. A real native recorder needs MediaProjection consent and foreground recording service.
- Face-camera preview is not rendered in the overlay service yet; camera preview inside the
  app remains in the WebView. This project establishes actual system-wide floating controls.

Build with Android Studio / compatible Gradle builder, JDK 17, Android SDK 35.
