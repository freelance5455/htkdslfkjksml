/* ==========================================================================
   exams.js — exams & deadlines section
   ========================================================================== */

function openExamModal(existing) {
  const e = existing || { name: '', subjectId: '', date: todayISO(), time: '09:00', description: '' };
  const body = `
    <div class="form-row"><label>Exam Name</label><input type="text" id="f-name" value="${escapeHTML(e.name)}" placeholder="e.g. Midterm Exam"></div>
    <div class="form-row"><label>Subject</label><select id="f-subject">${subjectOptionsHTML(e.subjectId)}</select></div>
    <div class="form-grid-2">
      <div class="form-row"><label>Date</label><input type="date" id="f-date" value="${e.date}"></div>
      <div class="form-row"><label>Time</label><input type="time" id="f-time" value="${e.time}"></div>
    </div>
    <div class="form-row"><label>Description</label><textarea id="f-desc">${escapeHTML(e.description)}</textarea></div>
  `;
  openGenericModal(existing ? 'Edit Exam' : 'Add Exam', body, () => {
    const name = document.getElementById('f-name').value.trim();
    if (!name) { showToast('Exam name is required', 'error'); return false; }
    const payload = {
      name,
      subjectId: document.getElementById('f-subject').value || null,
      date: document.getElementById('f-date').value || todayISO(),
      time: document.getElementById('f-time').value || '09:00',
      description: document.getElementById('f-desc').value.trim()
    };
    if (existing) {
      Object.assign(existing, payload);
    } else {
      App.data.exams.push({ id: genId('exam'), ...payload });
    }
    App.save();
    renderExams();
    showToast(existing ? 'Exam updated' : 'Exam added', 'success');
  });
}

function deleteExam(id) {
  App.data.exams = App.data.exams.filter(e => e.id !== id);
  App.save();
  renderExams();
  showToast('Exam deleted', 'info');
}

function renderExams() {
  const panel = document.getElementById('examListPanel');
  const sorted = App.data.exams.slice().sort((a, b) => new Date(`${a.date}T${a.time}`) - new Date(`${b.date}T${b.time}`));

  if (sorted.length === 0) {
    panel.innerHTML = `<div class="empty-state"><div class="icon">🎯</div>No exams added yet. Add one to see its countdown here.</div>`;
    return;
  }

  panel.innerHTML = sorted.map(e => {
    const subj = App.data.subjects.find(s => s.id === e.subjectId);
    const label = examCountdownLabel(e.date, e.time);
    const badgeClass = label === 'Passed' ? 'badge-low' : (label === 'Today' || label === 'Tomorrow') ? 'badge-high' : 'badge-medium';
    return `
      <div class="list-row" data-id="${e.id}">
        <div class="grow">
          <div class="title">${escapeHTML(e.name)}</div>
          <div class="meta">
            ${subj ? `<span class="subject-dot" style="background:${subj.color}"></span>${escapeHTML(subj.name)} · ` : ''}
            ${fmtDate(e.date)} at ${e.time}${e.description ? ' · ' + escapeHTML(e.description) : ''}
          </div>
        </div>
        <span class="badge ${badgeClass}">${label}</span>
        <div class="actions">
          <button class="icon-btn" data-action="edit">✏️</button>
          <button class="icon-btn" data-action="delete">🗑</button>
        </div>
      </div>`;
  }).join('');

  panel.querySelectorAll('.list-row').forEach(row => {
    const id = row.dataset.id;
    const exam = App.data.exams.find(e => e.id === id);
    row.querySelector('[data-action="edit"]').addEventListener('click', () => openExamModal(exam));
    row.querySelector('[data-action="delete"]').addEventListener('click', () => {
      if (confirm(`Delete "${exam.name}"?`)) deleteExam(id);
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addExamBtn').addEventListener('click', () => openExamModal(null));
});
