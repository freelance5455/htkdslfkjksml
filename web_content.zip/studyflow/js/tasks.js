/* ==========================================================================
   tasks.js — task management section
   ========================================================================== */

let taskFilter = 'all';
let taskSearchTerm = '';

function toggleTaskComplete(taskId) {
  const task = App.data.tasks.find(t => t.id === taskId);
  if (!task) return;
  task.completed = !task.completed;
  App.save();
}

function deleteTask(taskId) {
  App.data.tasks = App.data.tasks.filter(t => t.id !== taskId);
  App.save();
  renderTasks();
  showToast('Task deleted', 'info');
}

function subjectOptionsHTML(selectedId) {
  const opts = ['<option value="">No subject</option>'];
  App.data.subjects.forEach(s => opts.push(`<option value="${s.id}" ${s.id === selectedId ? 'selected' : ''}>${escapeHTML(s.name)}</option>`));
  return opts.join('');
}

function openTaskModal(existingTask) {
  const t = existingTask || { title: '', subjectId: '', date: todayISO(), priority: 'medium', estMinutes: 30, description: '', completed: false };
  const body = `
    <div class="form-row"><label>Title</label><input type="text" id="f-title" value="${escapeHTML(t.title)}" placeholder="e.g. Finish algebra worksheet"></div>
    <div class="form-grid-2">
      <div class="form-row"><label>Date</label><input type="date" id="f-date" value="${t.date}"></div>
      <div class="form-row"><label>Subject</label><select id="f-subject">${subjectOptionsHTML(t.subjectId)}</select></div>
    </div>
    <div class="form-grid-2">
      <div class="form-row"><label>Priority</label>
        <select id="f-priority">
          <option value="low" ${t.priority === 'low' ? 'selected' : ''}>Low</option>
          <option value="medium" ${t.priority === 'medium' ? 'selected' : ''}>Medium</option>
          <option value="high" ${t.priority === 'high' ? 'selected' : ''}>High</option>
        </select>
      </div>
      <div class="form-row"><label>Estimated Minutes</label><input type="number" id="f-est" min="0" value="${t.estMinutes}"></div>
    </div>
    <div class="form-row"><label>Description</label><textarea id="f-desc">${escapeHTML(t.description)}</textarea></div>
  `;
  openGenericModal(existingTask ? 'Edit Task' : 'Add Task', body, () => {
    const title = document.getElementById('f-title').value.trim();
    if (!title) { showToast('Title is required', 'error'); return false; }
    const payload = {
      title,
      date: document.getElementById('f-date').value || todayISO(),
      subjectId: document.getElementById('f-subject').value || null,
      priority: document.getElementById('f-priority').value,
      estMinutes: parseInt(document.getElementById('f-est').value, 10) || 0,
      description: document.getElementById('f-desc').value.trim()
    };
    if (existingTask) {
      Object.assign(existingTask, payload);
    } else {
      App.data.tasks.push({ id: genId('task'), completed: false, ...payload });
    }
    App.save();
    renderTasks();
    showToast(existingTask ? 'Task updated' : 'Task added', 'success');
  });
}

function filteredTasks() {
  const today = todayISO();
  let list = App.data.tasks.slice();
  if (taskFilter === 'today') list = list.filter(t => t.date === today);
  else if (taskFilter === 'upcoming') list = list.filter(t => t.date > today && !t.completed);
  else if (taskFilter === 'completed') list = list.filter(t => t.completed);
  else if (taskFilter === 'high') list = list.filter(t => t.priority === 'high');

  if (taskSearchTerm) {
    const q = taskSearchTerm.toLowerCase();
    list = list.filter(t => t.title.toLowerCase().includes(q) || (t.description || '').toLowerCase().includes(q));
  }
  return list.sort((a, b) => a.date.localeCompare(b.date));
}

function renderTasks() {
  const list = filteredTasks();
  const panel = document.getElementById('taskListPanel');

  if (list.length === 0) {
    panel.innerHTML = `<div class="empty-state"><div class="icon">✅</div>No tasks found. Try a different filter or add a new task.</div>`;
  } else {
    panel.innerHTML = list.map(t => {
      const subj = App.data.subjects.find(s => s.id === t.subjectId);
      return `
      <div class="list-row" data-id="${t.id}">
        <div class="check ${t.completed ? 'checked' : ''}" data-action="toggle"></div>
        <div class="grow">
          <div class="title ${t.completed ? 'done' : ''}">${escapeHTML(t.title)}</div>
          <div class="meta">
            ${subj ? `<span class="subject-dot" style="background:${subj.color}"></span>${escapeHTML(subj.name)} · ` : ''}
            ${fmtDate(t.date)} · ${minutesToHM(t.estMinutes)}
          </div>
        </div>
        <span class="badge badge-${t.priority}">${t.priority}</span>
        <div class="actions">
          <button class="icon-btn" data-action="edit">✏️</button>
          <button class="icon-btn" data-action="delete">🗑</button>
        </div>
      </div>`;
    }).join('');
  }

  panel.querySelectorAll('.list-row').forEach(row => {
    const id = row.dataset.id;
    const task = App.data.tasks.find(t => t.id === id);
    row.querySelector('[data-action="toggle"]').addEventListener('click', () => { toggleTaskComplete(id); renderTasks(); });
    row.querySelector('[data-action="edit"]').addEventListener('click', () => openTaskModal(task));
    row.querySelector('[data-action="delete"]').addEventListener('click', () => {
      if (confirm('Delete this task?')) deleteTask(id);
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addTaskBtn').addEventListener('click', () => openTaskModal(null));

  document.getElementById('taskSearch').addEventListener('input', (e) => {
    taskSearchTerm = e.target.value;
    renderTasks();
  });

  document.querySelectorAll('#view-tasks .chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('#view-tasks .chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      taskFilter = chip.dataset.filter;
      renderTasks();
    });
  });
});
