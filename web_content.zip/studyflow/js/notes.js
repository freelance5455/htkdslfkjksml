/* ==========================================================================
   notes.js — notes section
   ========================================================================== */

let noteSearchTerm = '';

function openNoteModal(existing) {
  const n = existing || { title: '', subjectId: '', content: '' };
  const body = `
    <div class="form-row"><label>Title</label><input type="text" id="f-title" value="${escapeHTML(n.title)}" placeholder="e.g. Derivative rules"></div>
    <div class="form-row"><label>Subject</label><select id="f-subject">${subjectOptionsHTML(n.subjectId)}</select></div>
    <div class="form-row"><label>Content</label><textarea id="f-content" style="min-height:140px;">${escapeHTML(n.content)}</textarea></div>
  `;
  openGenericModal(existing ? 'Edit Note' : 'Add Note', body, () => {
    const title = document.getElementById('f-title').value.trim();
    if (!title) { showToast('Title is required', 'error'); return false; }
    const now = new Date().toISOString();
    const payload = {
      title,
      subjectId: document.getElementById('f-subject').value || null,
      content: document.getElementById('f-content').value.trim(),
      updatedAt: now
    };
    if (existing) {
      Object.assign(existing, payload);
    } else {
      App.data.notes.push({ id: genId('note'), createdAt: now, ...payload });
    }
    App.save();
    renderNotes();
    showToast(existing ? 'Note updated' : 'Note added', 'success');
  });
}

function deleteNote(id) {
  App.data.notes = App.data.notes.filter(n => n.id !== id);
  App.save();
  renderNotes();
  showToast('Note deleted', 'info');
}

function filteredNotes() {
  let list = App.data.notes.slice();
  if (noteSearchTerm) {
    const q = noteSearchTerm.toLowerCase();
    list = list.filter(n => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q));
  }
  return list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

function renderNotes() {
  const grid = document.getElementById('notesGrid');
  const list = filteredNotes();

  if (list.length === 0) {
    grid.innerHTML = `<div class="empty-state"><div class="icon">📝</div>No notes found. Add your first note!</div>`;
    return;
  }

  grid.innerHTML = list.map(n => {
    const subj = App.data.subjects.find(s => s.id === n.subjectId);
    return `
      <div class="note-card" data-id="${n.id}">
        <div style="display:flex; justify-content:space-between; align-items:start;">
          <h4>${escapeHTML(n.title)}</h4>
          <div class="actions">
            <button class="icon-btn" data-action="edit">✏️</button>
            <button class="icon-btn" data-action="delete">🗑</button>
          </div>
        </div>
        ${subj ? `<div class="meta" style="margin-bottom:6px;"><span class="subject-dot" style="background:${subj.color}"></span>${escapeHTML(subj.name)}</div>` : ''}
        <p>${escapeHTML(n.content)}</p>
        <div class="meta" style="margin-top:8px;">Updated ${fmtDate(n.updatedAt.slice(0, 10))}</div>
      </div>`;
  }).join('');

  grid.querySelectorAll('.note-card').forEach(card => {
    const id = card.dataset.id;
    const note = App.data.notes.find(n => n.id === id);
    card.querySelector('[data-action="edit"]').addEventListener('click', (e) => { e.stopPropagation(); openNoteModal(note); });
    card.querySelector('[data-action="delete"]').addEventListener('click', (e) => {
      e.stopPropagation();
      if (confirm(`Delete "${note.title}"?`)) deleteNote(id);
    });
    card.addEventListener('click', () => openNoteModal(note));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('addNoteBtn').addEventListener('click', () => openNoteModal(null));
  document.getElementById('noteSearch').addEventListener('input', (e) => {
    noteSearchTerm = e.target.value;
    renderNotes();
  });
});
